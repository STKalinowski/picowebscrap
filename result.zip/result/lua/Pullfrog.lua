function _init()
	cartdata("pullfrog2")
	t=0
	t_ded=0
	jmp_bttn=❎
	tng_bttn=🅾️
	roman=split"i,ii,iii,iv,v,vi,vii,viii,ix,x,xi,xii,xiii,xiv,xv,xvi,xvii,xviii,xix,xx,xxi,xxii,xxiii,xxiv,xxv,xxvi,xxvii,xxviii,xxix,xxx"
	max_dy=4
	vcntr=61
	dirx=split"-1,1,0,0,1,1,-1,-1"
	diry=split"0,0,-1,1,-1,1,1,-1"
	--debug={}
	parts={}
	fadeperc=0.5
	
	--dset(0,0)
	frogs_unlck=dget(0)>0 and dget(0) or 1

	i_store=0
	i_menu=0
	
	--frog typs
	nms=split"frog,simon,g☉nz"
	jmps=split".65,.56,.28"
 accs=split".15,.2,.1"
 gravs=split".15,.19,.03"
 gravs_comp=split".083,0.12,0.03"
 frictions=split".85,.4,1.6"
 tongs_m=split"20,30,20"
 tongs_spd=split"6,9,7"
 tongs_wait=split".11,1,.12"
	
	--levels
	jmp_arr=split"0,.06,.15,.2,.27,.34"
	tong_arr=split"0,8,13,18,23,28"
	gravs_arr={
		split"0,.005,.01,.015,.02,.025",
		split"0,.004,.008,.012,0.016,0.02",
		split"0,0,.005,.01,.015,0.017"
	}
	
	-- wait speed until new piece spwn
	pc_spd_spwn=split".0041,.0042,.0043,.0044,.0045,.0046,.0047,.0048,.0049,.0050,.0051,.0052,.0053,.0054,.0056,.0057,.0058,.0059,.0060,.0062,.0064,.0066,.0068,.0070,.0072,.0075,.0077,.0080,.0082,.0085,.0087,.0090,.0092,.0095,.0097,.01"
	-- wait speed until piece move
	pc_spd_dy=split".15,.20,.22,.23,.24,.25,.26,.27,.28,.29,.30,.31,.33,.35,.37,.39,.41,.43,.45,.47,.49,.51,.53,.55,.57,.59,.61,.63,.65,.67,.69,.71,.73,.75,.77,.79,.81,.83,.85,.87,.89,.91,.93,.95,.97,.99,1"
	-- pixels the pieces move
	pc_dy={1}
	
	music(0)
	_upd=u_title
	_drw=d_title
end

function _update60()
	doparts()
	_upd()
end

function _draw()
	_drw()
	checkfade()

--	cursor(4,4)
--	color(8)
--	for txt in all(debug) do
--		print(txt)
--	end
end

function start_game()
	music(4,10)
	reload(0x2000,0x2000,0x1000)
	door_spwned=false
	mask_r=190
	rmod=2
	ded_x=64
	ded_y=64
	door=nil

	pc_count=0
	
	store_shake=0
	
	eyes=frogs_unlck > 2 and 5 or 0
	lines=0
	tong_blocks=0
	tong_lvl=0--#jmp_arr-1
	jmp_lvl=0--#jmp_arr-1
	
	flash_lines={}
	flash_cols={}

	i_pieces()
	i_states()
	p_t=1
	pieces={}
	broken={}
	parts={}
	f=nil
	
	rnd_pos={}
	last_pos=nil
	last_piece=nil
	pos_t=0
		
	spwn_map()
	shift_lines()
	check_cols()
	i_menu=flr(rnd(frogs_unlck))+1
	_upd=u_game
	_drw=d_game
end

function spwn_map()
	local typ=i_menu%frogs_unlck
	typ+=1

	for y=0,15 do
		for x=0,15 do
			local tl=mget(x,y)
			if tl==016 then
				i_frog(typ,x*8,y*8)
				mset(x,y,0)
			elseif tl==032 then
				i_frog(typ,x*8,y*8)
				mset(x,y,0)
			elseif tl==48 then
				i_frog(typ,x*8,y*8)
				mset(x,y,0)
			end
		end
	end
	
	if not f then
		i_frog(typ,5*8,2*8)
	end
end

function d_map()
	d_map_pieces()
	local coors = getmapcoords(2)
	map(coors.x,coors.y)
	coors= getmapcoords(1)
	map(coors.x,coors.y)
	coors= getmapcoords(3)
	map(coors.x,coors.y)
end

function d_map_pieces()
	for x=0,15 do
		for y=0,15 do
			local l=get_flash_line(y)
			local c=get_flash_col(x)
			if l then
				--★
				if flr((time()*10)%2) != 0then
					pal(10,7)
					pal(9,10)
					pal(4,9)
					pal(2,4)
				end
			elseif c then
				pal(9,8)
			end
			map(x,y,x*8,y*8,1,1)
			pal()
		end
	end
end

function get_flash_line(y)
	for l in all(flash_lines) do
		if(l.y==y)return l
	end
	return nil
end

function get_pc_dy()
	return pc_dy[min(lines+1,#pc_dy)]
end

function get_spd_spwn()
	return pc_spd_spwn[min(lines+1,#pc_spd_spwn)]
end

function get_pc_spd_dy()
	return pc_spd_dy[min(lines+1,#pc_spd_dy)]
end
-->8
--screens--

function u_title()
	if btnp(⬆️) and btnp(🅾️) then
		jmp_bttn=jmp_bttn==❎ and 🅾️ or ❎
		tng_bttn=tng_bttn==🅾️ and ❎ or 🅾️
		sfx(54)
	elseif btnp(❎) or btnp(🅾️) then
		--menu button
		t=0
		sfx(58)
		music(-1,100)
		fadeout()
		start_game()
	end
	
	if(frogs_unlck < 2)return
	if btnp(➡️) then
		i_menu+=1
		sfx(55)
	elseif btnp(⬅️) then
		sfx(55)
		i_menu-=1
	end
end

function d_title()
	cls()
	local coors = getmapcoords(7)
	map(coors.x,coors.y)
	coors = getmapcoords(6)
	map(coors.x,coors.y)
	
	local txt="press ❎/🅾️ to play"
	local x = hcntr(txt)
	local y = vcntr
	local plt = {9,10}
	local c = plt[flr((time()*5)%#plt)+1]
	print(txt,x-2,y+27,c)
	txt="@afk_mario  ★  @eljovenpaul"
	x = hcntr(txt)
	
	oprint8(txt,x,y+61,13,0)
	sspr(0,96,48,16,23,(sin(time())*2.1)+34,48*2,16*2)

	if(frogs_unlck < 2)return

	local s=get_frame({16,18},15,time()*100)
	s+=(i_menu%frogs_unlck)*16
	spr(s,60,77)
	print("⬅️",48,79,c)
	print("➡️",74,79,c)
end

function u_gover()
	if btnp(❎) then
		sfx(58)
		fadeout()
		music(0)
		_upd=u_title
		_drw=d_title
	end
end

function d_gover()
	--cls()
	
	local w=87
	local h1=90
	local h2=19
	local x=22
	local y=4
	local y2=h1+y+4
	
	dbox(x,y,w,h1,13,0)

	dbox(69,y2,40,10,13,0)
	print("lines "..lines,72,y2+3,9)
	
	for i=1,#ded_msg do
		local l=ded_msg[i]
		local x=hcntr(l)+3
		local y=i*6+4
		print(l,x,y,9)
	end
	
	local sy=y2-h2-3+min(0,sin(time()))
	local s=23
	s+=(f.typ-1)*16
	spr(s,x+7,sy+8)
	spr(172,x+4,sy+10)
	spr(172,x+11,sy+10,1,1,true)
	spr(173,x+9,sy+5)
	local txt="-"..nms[f.typ].." "..roman[mid(1,t_ded,30)]
	print(txt,6+w-#txt*4,y2-h2+6,9)
end

function u_game()
 for i=0,3 do
  --flip()
 end

	t+=1
	local skip_pc=f.state=="ded" and f.tick>0.1
	if(not skip_pc)u_pieces()
	u_frog()
	if(door)u_door()
end

function d_game()
	cls()
	d_map()
	
	for b in all(broken) do
		d_broken(b)
	end

	for p in all(pieces) do
		d_piece(p,true)
	end

	d_frog()
	
	u_clear_lines()
	for part in all(parts) do
		d_part(part)
	end
	
	if last_pos and last_piece then
		pos_t=min(1,pos_t+get_pc_spd_dy()/16)
		local x=last_pos*8
		spr(152,x,0,last_piece < 3 and 1 or 2,1)
		
		if pos_t==1 then
			last_post=nil
			last_piece=nil
		end
		--line(x,0,x+7,0,8)
	end
	
	d_hud()
end

function d_hud()
	spr(141,107,4,3,2)--box1
	spr(2,108,4)--jmp
	print(digits2(jmp_lvl),117,6,10)
	
	spr(141,107,15,3,2)--box2
	spr(3,108,15)--tng
	print(digits2(tong_lvl),117,17,10)
	
	-- triangle
	spr(167,109,81,2,2)
	
	spr(136,108,107,3,1)--lines
	spr(141,107,112,3,3)--box3
	print((lines%3).."/3",111,114,10)
	
	--★
	local __y=97
	spr(141,107,__y,3,2)
	print(digits2(lines,4),109,__y+2,9)

	--★
	spr(get_eye_s(0),108,33)
	spr(get_eye_s(1),118,33)

	spr(get_eye_s(2),113,39)

	spr(get_eye_s(3),108,45)
	spr(get_eye_s(4),118,45)
end

function get_eye_s(i)
	if(i < eyes)return 5
	return 151
end

function pal_store(i)
	if(i != i_store%3)return
	pal(9,15)
	pal(10,7)
	pal(4,9)
end

function u_store()
	t=min(1,t+0.025)
	if(t!=1)return
	
	if store_flsh then
		store_flsh=max(0,store_flsh-0.05)
		
		if(store_flsh!=0)return
		_upd=u_game
		_drw=d_game
		store_flsh=nil
		music(4,10)
		if frogs_unlck<3 and not door_spwned and eyes >4 then
			spwn_door()
		end
	end
	
	if btnp(➡️) then
		i_store+=1
		sfx(55)
	elseif btnp(⬅️) then
		sfx(55)
		i_store-=1
	elseif btnp(❎) or btnp(🅾️) then
		local i=i_store%3
		
		local yes=false
		if(i==0)then
		 yes=jmp_lvl< #jmp_arr-1
			if yes then
				jmp_lvl=min(#jmp_arr-1,jmp_lvl+1)
				if jmp_lvl==1 then
					ng_unlock_medal(14)
				elseif jmp_lvl==#jmp_arr-1 then
					ng_unlock_medal(15)
				end
			end
		elseif(i==1)then
			yes=tong_lvl< #tong_arr-1
			if yes then
				tong_lvl=min(#tong_arr-1,tong_lvl+1)
				if tong_lvl==1 then
					ng_unlock_medal(16)
				elseif tong_lvl==#tong_arr-1 then
					ng_unlock_medal(17)
				end
			end
		elseif(i==2)then
		 yes=eyes<5
			if yes then
				eyes=min(5,eyes+1)
				if eyes==1 then
					ng_unlock_medal(18)
				elseif eyes==5 then
					ng_unlock_medal(19)
				end
			end
		end
		
		if yes then
			sfx(52)
			store_flsh=1
		else
			sfx(53)
			store_shake+=1
		end
	end
end

function d_store()
	d_game()
	store_shake=max(0,store_shake-.125)
	local x=14
	x-=(2-rnd(4)*store_shake)
	local h=min(50,lerp(0,50,t*4))
	
	dbox(x,34,87,h,13,0)
	if(t<0.25)return
	
	spr(29,x+1,36+sin(time())*1.5,3,3)
	
	print("you've cleared",x+26,40,9)
	print("3 lines!",x+26,47,10)
	print("select a reward",x+26,54,8)
	
	pal_store(0)
	spr(139,x+26,68,2,2)
	spr(jmp_lvl< #jmp_arr-1 and 2 or 169,x+28,70)--jmp
	pal()
	
	pal_store(1)
	spr(139,x+41,68,2,2)
	spr(tong_lvl< #tong_arr-1 and 3 or 169,x+43,70)--tong
	pal()
	
	pal_store(2)
	spr(139,x+56,68,2,2)
	spr(eyes< 5 and 5 or 169,x+58,71)--eyes
	pal()
	
	if(store_flsh)return
	spr(6,27+x+(i_store%3)*15,60)--arrow
end


function u_ded_mask()
	if mask_r==0 then
		_upd=u_gover
		_drw=d_gover
		local i=flr(rnd(#ded_msgs)+1)
		ded_msg=ded_msgs[i]
		if(i==3)ng_unlock_medal(10)
		music(3)
	end
end

function d_ded_mask()
	putmask()
	putmask()
end

function u_save()
	t=min(1,t+0.025)
	if(t!=1)return
	
	if btnp(❎) or btnp(🅾️) then
		destroy_door()
		_upd=u_game
		_drw=d_game
	end
end

function d_save()
	d_game()
	
	local i=frogs_unlck
	
	local y=20
	local x=12
	local mh=80
	local h=min(mh,lerp(0,mh,t*4))
	dbox(x,y,87,h,13,0)
	
	local txt="you did it"
	local tx=hcntr(txt)-8
	print(txt,tx,30,9)
	
	txt="the door has been"
	tx=hcntr(txt)-8
	print(txt,tx,36,9)

	txt="opened"
	tx=hcntr(txt)-8
	print(txt,tx,42,9)
	
	local s=get_frame({16,18},15,time()*100)
	s+=(i-1)*16
	spr(s,50,60)
	
	txt=nms[i]
	tx=hcntr(txt)-8
	print(txt,tx,80,9)
	
	txt="is free"
	tx=hcntr(txt)-8
	print(txt,tx,86,9)
end
-->8
--states--

function i_states()
	f_states = {
		jump={
			spd=1,
			ani={19},
			_ini=i_jump,
			_upd=u_jump,
		},
		fall={
			spd=1,
			ani={20},
			_upd=u_fall,
		},
		slide={
			spd=1,
			ani={21},
			_upd=u_slide,
		},
		move={
			spd=10,
			ani={16,18},
			_upd=u_move,
		},
		idle={
			spd=15,
			ani={16,17},
			_upd=u_idle,
		},
		squash={
			spd=1,
			ani={21},
			_ini=i_squash,
			_upd=u_squash,
		},
		ded={
			spd=1,
			ani={22},
			_ini=i_ded,
			_upd=u_ded,
		}
	}
end
	
function f_setstate(state)
	if(state==f.state)return
	f.prevstate=f.state or state
	f.state=state
	f.tick=0
	f.friction=.85
	local nstate = f_states[state]

	if nstate._ini then
		nstate._ini()
	end
	nstate._upd()
end

function check_jump()
	local down = f_bttm_coll()

	if
		(down or f.coyote > 0)
		and f.btnreleased
	then
		f.canjump=true
	else
		f.canjump=false
	end

	if f.canjump and btn(jmp_bttn) then
		f_setstate("jump")
		return true
	end
	return false
end

function check_ded()
	local down = f_bttm_coll()
	local tc = f_top_coll()
	
	if down and tc then
		f_setstate("ded")
		return true
	end
	
	return false
end

function check_fall()
	local down = f_bttm_coll()
	
	if not down then
		f_setstate("fall")
		return true
	end
		
	return false
end

function check_slide()
	if(btn(⬅️) or btn(➡️))return false
	if(f.dx == 0)return false
	f_setstate("slide")
	return true
end

function i_ded()
	sfx(59)
	music(-1,0.5)
	t_ded+=1
	if t_ded==1 then
		ng_unlock_medal(7)
	elseif t_ded==10 then
		ng_unlock_medal(8)
	elseif t_ded==30 then
		ng_unlock_medal(9)
	end
end

function u_ded()
	f.tick=min(1,f.tick+.06)
	if f.tick==1 then
		t=0
		ded_x=f.x
		ded_y=f.y
		mask_r=128+32
		_upd=u_ded_mask
		_drw=d_ded_mask
	end
end

--idle
function u_idle()
	if(check_jump())return
	if(check_fall())return
	
	if btn(⬅️) or btn(➡️) then
		f_setstate("move")
	end
end

--move
function u_move()
	if(check_jump())return
	if(check_fall())return
	if(check_slide())return
	
	if not btn(⬅️) and not btn(➡️) then
		f_setstate("slide")
	end
	
	f.tick=min(1,f.tick+.125)
	if f.tick==1 then
		sfx(61)
		f.tick=0
	end
end

--slide
function u_slide()
	if(check_jump())return
	if(check_fall())return

	if btn(⬅️) or btn(➡️) then
		f_setstate("move")
	elseif (abs(f.dx) < .2) then
		f.dx=0
		f_setstate("idle")
	end
end

--squash
function i_squash()
	f.coyote=5
	f.friction=0.58
	f.tick=5
	sfx(62)
	if f.piece then
		spawn_impact(f.x,f.y+1,0,f.piece.spd,f.flp,{6,6,13})
	else
		spawn_impact(f.x,f.y,0,0,f.flp,{6,6,13})
	end
end

function u_squash()
	if(check_jump())return
	if(check_fall())return
-- if(check_slide())return

	--land momentum loss
	if f.tick < 4 then
		f.friction=0.85
	end

	f.tick=max(0,f.tick-1)

	if f.tick==0 then
		--★
		if btn(⬅️) or btn(➡️) then
			f_setstate("move")
		else
			f_setstate("idle")
		end
	end
end

--fall
function u_fall()
	if(check_jump())return
	-- jump assist
	if btn(jmp_bttn) then
		f.gravity=gravs_comp[f.typ]
	else
		f.gravity=gravs[f.typ]
	end

	f.coyote=max(0,f.coyote-1)
	f.dy=limit_speed(f.dy,max_dy)

	local down = f_bttm_coll()
	
	if down then
		f_setstate("squash")
	end
end

--jump
function i_jump()
	sfx(63)
	spawn_dust(f.x,f.y,{13,5,1})
	if 
		(f.coyote > 0 and 
		f.prevstate == "fall") or
		f.piece
	then
		f.dy = f.gravity
	end
	f.piece=nil
	f.coyote=0
	f.canjump=false
	f.btnreleased=false
	f.tick=4
end

function u_jump()
	if f_top_coll() then
		f_setstate("fall")
		f.dy=f.gravity
		return true
	end

	if f.tick > 0 and btn(jmp_bttn) then
		f.dy-=f.jmp+jmp_arr[jmp_lvl+1]
		f.dy=limit_speed(f.dy,max_dy)
	end

	if(jmp_to_fall())return
	f.tick=max(0,f.tick-1)
end

function jmp_to_fall()
	local down = f_bttm_coll()

	if f.dy > 0 then
		f_setstate("fall")
		return true
	end
	
	if down and f.tick == 0 then
		f_setstate("squash")
	end
	return false
end
-->8
--frog--

function i_frog(typ,x,y)
	f={
		typ=typ,
		w=8,
		h=8,
		x=x,
		y=y,
		dx=0,
		dy=0,
		acc=accs[typ],
		jmp=jmps[typ],
		canjump=false,
		btnreleased=true,
		btnreleasedtng=true,
		gravity=gravs[typ],
		friction=frictions[typ],
		tick=0,
		coyote=0,
		colls={},
	}

	--left
	f.colls.l=addraycoll(0,3,4,4)
	
	--right
	f.colls.r=addraycoll(6,3,4,4)

	--top
	f.colls.tr=addraycoll(1,2,2,1)
	f.colls.tc=addraycoll(3,2,2,0)
	f.colls.tl=addraycoll(4,2,2,1)
	
	--bottom
	f.colls.bottom=addraycoll(1,8,2,4)
	
	f_setflp(false)
	f_setstate("idle")
end

function u_frog()
	local state = f_states[f.state]
	if(check_ded()) return state._upd()
	
	u_tong()
	
	--physics
	f.dy+=f.gravity+gravs_arr[f.typ][jmp_lvl+1]
	f.dx*=f.friction
	
	if(abs(f.dx)<.002)f.dx=0

	do_btn()

	-- return gravity to defult
	-- before the state upd
	f.gravity=gravs[f.typ]

	state._upd()

	if f_vrt_coll_next() then
		f_vrt_swipe()
	else
		f.y += f.dy
	end

	if f_hrz_coll() then
		f.dx=0
	else
		f.x += f.dx
	end

	u_colls()
	corner_correction()
end

function d_frog()
	if(not f) return
	local state = f_states[f.state]
	local ani = state.ani
	local spd = state.spd
	local typ = f.typ
	local s = get_frame(ani,spd)+(typ-1)*16

	spr(s,f.x,f.y,1,1,f.flp)
	if(f.tong) d_tong()
end

function f_setflp(flp)
	f.flp= flp
	f.ox = flp and 0 or 1
	f.oy = 0
end

function do_btn()
	--tongue sfx
	if 
		btnp(tng_bttn) and 
		not f.tong and
		f.btnreleasedtng 
	then
		sfx(57)
		spwn_tong()
		f.btnreleasedtng=false
	end

	--controls
	if btn(⬅️) then
		f.dx-=f.acc
		f_setflp(true)
	end

	if btn(➡️) then
		f.dx+=f.acc
		f_setflp(false)
	end
	
	if(not btn(jmp_bttn))f.btnreleased=true
	
	if(not btn(tng_bttn))f.btnreleasedtng=true
end

function f_hrz_coll()
	local l = f.colls.l.iscoll
	local r = f.colls.r.iscoll
	return(l and f.dx<0)or (r and f.dx>0)
end

function f_top_coll()
	return f.colls.tc.iscoll
end

function f_bttm_coll()
	return f.colls.bottom.iscoll and f.state!="jump"
end

function f_hrz_coll_next()
	local left = coll_next(f.colls.l)
	local right = coll_next(f.colls.r)
	return left or right
end

function f_top_coll_next()
	local tc = coll_next(f.colls.tc)
	return tc
end

function f_bttm_coll_next()
	return coll_next(f.colls.bottom) and f.state!="jump"
end

function f_vrt_coll_next()
	return f_bttm_coll_next() or
		f_top_coll_next()
end

function coll_next(c)
	local x=f.x+f.ox+f.dx
	local y=f.y+f.oy+f.dy
	local mp=is_coll_map(x,y,c)
	local pc=is_coll_piece(x,y,c)
	return mp or pc
end

function u_colls()
	local x,y=f.x+f.ox,f.y+f.oy
	local is_door=false
	if door then
		is_door=is_coll_door(f.x,f.y,8,8)
	end
	if is_door then
		t=0
		local cnt=frogs_unlck
		if(cnt<4) then
			frogs_unlck+=1
			if(frogs_unlck==2)ng_unlock_medal(12)
			if(frogs_unlck==3)ng_unlock_medal(13)
			dset(0, frogs_unlck)
			sfx(51)
			_upd=u_save
			_drw=d_save
		end
	
	end
	for i,c in pairs(f.colls) do
		local mp=is_coll_map(x,y,c)
		local pc=is_coll_piece(x,y,c)
		c.iscoll = mp or pc
	end
	if f.state != "jump" then
		f_attach_bottom_piece()
	end
	f_attach_top_piece()
end

function f_attach_bottom_piece()
	local x=f.x+f.ox
	local y=f.y+f.oy
	
	local c=f.colls.bottom
	local pc=is_coll_piece(x,y,c)

	f.piece=pc
	if(pc) f.dy=pc.dy
end

function f_attach_top_piece()
	local x=f.x+f.ox+f.dx
	local y=f.y+f.oy+f.dy
	
	local c=f.colls.tc
	local pc=is_coll_piece(x,y,c)

	f.tpc=pc
end

function f_vrt_swipe()
	local fy=f.y+f.dy
	local t=0
	
	while t < 1 do
		u_colls()
		if f_bttm_coll() then
			f.dy = 0
			if (not f.piece) f.y=flr(f.y)
			return
		end
		
		if f_top_coll() then
			if f.tpc then
				f.y+=f.tpc.dy
				f.dy=f.tpc.dy * flr(f.tpc.spd)
				--f.dy=f.gravity
			else
				-- f.y+=1
			end
			return
		end
		
		f.y=lerp(f.y,fy,t)
		t+=0.125
	end
end

function f_hrz_swipe()
	local fx=f.x+f.dx
	local t=0
	
	while t < 1 do
		u_colls()
		if f_hrz_coll() then
			f.dx = 0
			f.x=flr(f.x)
			return
		end
		f.x=lerp(f.x,fx,t)
		t+=0.125
	end
end

function corner_correction()
	local tr = f.colls.tr.iscoll
	local tl = f.colls.tl.iscoll

	if(tr and not tl) f.x+=1
	if(not tr and tl) f.x-=1
end
-->8
--colissions

function is_solid(x,y,f)
	local f = f or 0
	if f==0 then
		if(x < 1 or x > 13)return true
		if(y < -2)return true
	end
	return fget(mget(x,y),f)
end

function is_coll_map(x,y,coll)
	local flag=0
	local x1 = x+coll.x1
	local y1 = y+coll.y1
	local x2 = x+coll.x2
	local y2 = y+coll.y2
	
	x1/=8
	y1/=8
	x2/=8
	y2/=8
	
	local a=is_solid(x1,y1)
	local b=is_solid(x1,y2)
	local c=is_solid(x2,y1)
	local d=is_solid(x2,y2)
	
	if _door then
		a=a or is_solid(x1,y1,3)
		b=b or is_solid(x1,y2,3)
		c=c or is_solid(x2,y1,3)
		d=d or is_solid(x2,y2,3)
	end
	
	return a or b or c or d
end

function is_coll_map_point(x,y,f)
	local x = x\8
	local y = y\8
	
	return is_solid(x,y,f)
end

function is_coll_piece(x,y,coll)
	local ax1 = x+coll.x1
	local ay1 = y+coll.y1
	local ax2 = x+coll.x2
	local ay2 = y+coll.y2
	
	for p in all(pieces) do
		for b in all(p.blocks) do
			local v=p.v+(b.v*8)
			local bx1=v.x
			local by1=v.y
			local bx2=bx1+8
			local by2=by1+8
			local iscol=box_box(ax1,ay1,ax2,ay2,bx1,by1,bx2,by2)
			if(iscol) return p
		end
	end
	
	return nil
end

function is_coll_pieces_point(x,y)
	local x=flr(x)
	local y=flr(y)
	
	for p in all(pieces) do
		for b in all(p.blocks) do
			local v=p.v+(b.v*8)
			local iscol=point_box(
				x,
				y,
				v.x-1, --x1
				v.y-1, --y1
				v.x+9,--x2
				v.y+9 --y2
			)
			if(iscol) then
			 return p
			end
		end
	end
	return nil
end

function is_coll_pvp(pb,v)
	local v=v or pb.v
	for pa in all(pieces) do
		if pa!=pb then 
			for ba in all(pa.blocks) do
				for bb in all(pb.blocks) do
					local iscol=block_vs_block(pa.v,v,ba.v,bb.v)
					if(iscol)return iscol
				end
			end
		end
	end
	return nil
end

function block_vs_block(pa,pb,ba,bb)
	local a=pa+(ba*8)
	local b=pb+(bb*8)
	
	local is_col=box_box(
			a.x,
			a.y,
			a.x+8,
			a.y+8,
			
			b.x,
			b.y,
			b.x+8,
			b.y+8
	)
	if(is_col)return pa
	return nil
end

function piece_map(p,_v)
	local _v=_v or p.v
	--return false
	for b in all(p.blocks) do
		local v=b.v*8
		local coll={
			x1=v.x,
			x2=v.x+7,
			y1=v.y,
			y2=v.y+8,
		}
		local iscol=is_coll_map(_v.x,_v.y,coll)
		if(iscol)return true
	end
	return false
end

function point_box(x,y,x1,y1,x2,y2)
	return x < x2 and
								x > x1 and
								y < y2 and
								y > y1
end

function box_box(ax1,ay1,ax2,ay2,bx1,by1,bx2,by2)
		return ax1 < bx2 and
									ax2 > bx1 and
									ay1 < by2 and
									ay2 > by1
end

function addraycoll(x,y,d,l)
	local coll = {
		typ=2,
		x1=x,
		y1=y,
		x2=x+dirx[d]*l,
		y2=y+diry[d]*l,
	}
	return coll
end

function is_coll_door(x,y,w,h)
	return box_box(
		x,y,
		x+w,y+h,
		door.x*8,door.y*8,
		door.x*8+16,door.y*8+16
	)
end
-->8
--pieces--

function i_pieces()
	pieces_typ={
		{{64},{}},--1
		{{67},{83}},--2
		{{80,81},{}},--3
		{{68,69},{84}},--4
		{{71},{87,88}},--5
		{{-1,70},{85,86}},--6
		{{65,66},{-1,82}},--7
		{{73,74},{89,90}},--8
	}
end

function get_piece_w(typ)
	local p=pieces_typ[typ]
	return #p[1]>#p[2] and #p[1] or #p[2]
end

function add_piece(typ,x,y)
	local p = {
		v=v2:new(x,y),
		dy=get_pc_dy(),
		spd=get_pc_spd_dy(),
		t=0,
		blocks={},
	}
	
	local blocks=pieces_typ[typ]

	for i=1,#blocks do
		for j=1,#blocks[i] do
			local s=blocks[i][j]
			if s > 0 then
				local x=j-1
				local y=i-1
				--collider
	
				add(p.blocks,{
					s=s,
					v=v2:new(x,y)
					})
			end
		end
	end
	
	add(pieces,p)
	return p
end

function u_pieces()
	for p in all(pieces) do
		u_piece(p)
	end
	p_t=min(p_t+get_spd_spwn(),1)
	--enable pieces
	if p_t == 1 then
		local x=get_rnd_x()
		local typ=get_rnd_piece(x)
		last_piece=typ
		last_pos=x
		pos_t=0
		add_piece(typ,x*8,-16)
		p_t=0
	end
end

function u_piece(p)
	if p.freeze then
		p.dy=0
		local is_colp=is_coll_pvp(p)
		if is_colp then
			p.freeze=false
--			p.v.y+=pc_dy
			p.t=1
--			p.v.y+=pc_dy
			p.dy=get_pc_dy()
		end
	end

	if p.n then
		local nxt=mov_to(p.v,p.n,1,0)
		local is_colp=is_coll_pvp(p,nxt)
		is_colp=is_colp or piece_map(p,nxt)
		if not is_colp then
			p.v=nxt
		end
	
		if p.v == p.n or is_colp then
			p.n=nil
			p.t=1
			p.dy=get_pc_dy()
			p.freeze=false
		end
	else
		p.t = min(1,p.t+p.spd)
		if(p.t != 1)return
		p.v.y += p.dy
		p.t=0
	end

	local iscolm=piece_map(p)

	if iscolm then
		del(pieces,p)
		if(f.pc==p) f.pc=nil
		if(f.tpc==p) f.tpc=nil
		
		for b in all(p.blocks) do
			local v=p.v+(b.v*8)
			v.x\=8
			v.y\=8
			if v.y < 0 then
				--ded column
				ng_unlock_medal(11)
				t=0
				ded_x=v.x*8
				ded_y=8
				mask_r=128+32
				_upd=u_ded_mask
				_drw=d_ded_mask
				return
			end
			mset(v.x,v.y,b.s)
		end
		
		shift_lines()
		clear_lines()
		check_cols()
	end
end

function get_rnd_piece(x)
	if(x>11)return rnd({1,2})
	return flr(rnd(#pieces_typ)+1)
end

function get_rnd_x()
	--return 9
	if #rnd_pos == 0 then
		for i=1,12 do
			add(rnd_pos,i)
		end
		add(rnd_pos,1)
	end
	
	local x=0
	if rnd() < .2 then
		x=mid(1,f.x\8,12)
	else
		x=rnd(rnd_pos)
		del(rnd_pos,x)
	end
	return x
end

function d_piece(p)
	pal(4,3)
	pal(9,11)
	for b in all(p.blocks) do
		d_block(p,b)
	end
	pal()
end

function d_block(p,b)
	local s=b.s
	local v=p.v+(b.v*8)
	spr(s,v.x,v.y)
--	
--	local x1=v.x-1
--	local y1=v.y-1
--	local x2=x1+9
--	local y2=y1+9
--	
--	rect(x1,y1,x2,y2,8)
end

function add_broken(x,y)
	local bp={
		x=x,
		y=y,
	}
	add(broken,bp)
	return bp
end

function get_broken(x,y)
	for b in all(broken) do
		if b.x==x and b.y==y then
			return b
		end
	end
	return nil
end

function d_broken(b)
	spr(96,b.x*8,b.y*8)
end

--★
function get_piece_i(_p)
	local tile=_p[1][1]
	for i=1, #pieces_typ do
		local p=pieces_typ[i]
		if(p[1][1]==tile)return i
	end
	return nil
end

function get_piece_typ(tile)
	for p in all(pieces_typ) do
		for y=1,#p do
			for x=1,#p[y] do
				if(p[y][x]==tile)return {p,x,y}
			end
		end
	end
	return nil
end

function clear_lines()
	local didclr=false
	for y=0,14 do
		if not get_flash_line(y) then
			local cl=true
			for x=1,12 do
				cl=fget(mget(x,y),1) and cl
			end
			if cl then
				didclr=true
				clear_line(y)
			end
		end
	end
	if(didclr)sfx(54)
end

function clear_line(y)
	add(flash_lines,{y=y,t=0})
end

function u_clear_lines()
	local ld=0
	local didclr=false
	for l in all(flash_lines)do
		l.t=min(1,l.t+0.05)
		if l.t==1 then
			for x=1,12 do
				destroy_block(x,l.y)
			end
			ld+=1
			del(flash_lines,l)
			didclr=true
		end
	end
	
	if(not didclr)return
	shift_lines()
	check_cols()
	lines_badge(lines,ld)
	
	local prv=lines\3
	local nxt=(lines+ld)\3
	local show=nxt > prv and nxt > 0
	local cmplt=jmp_lvl>=#jmp_arr-1 and 
	tong_lvl>=#tong_arr-1 and
	eyes >= 5

	show = show and not cmplt
	lines += ld
	
	update_pc_speed()
	
	if show then
		t=0
		_upd=u_store
		_drw=d_store
		music(2)
	end
end

function shift_lines()
	for y=14,0,-1 do
		for x=1,12 do
			if(not piece_has_bttm(x,y)) then
				spwn_piece_by_tile(x,y)
			end
		end
	end
end

function piece_has_bttm(_x,_y)
	local tl=mget(_x,_y)

	if(not fget(tl,1))return true

	local p,px,py=unpack(get_piece_typ(tl))
	local ox,oy=0,0
	_x-=px-1
	_y-=py-1

	for y=1,#p do
		for x=1,#p[y] do
			local atl=p[y][x]
			if atl != -1 then
				local r=p[y+1] and p[y+1] or {}
				local _tl=r[x] and r[x] or -1
				if _tl == -1 then
					if(is_solid(_x+x-1,_y+y))return true
				end
			end  
		end
	end

	
	return false
end

function spwn_piece_by_tile(x,y)
	local tl=mget(x,y)
	local p,px,py=unpack(get_piece_typ(tl))
	local i=get_piece_i(p)
	destroy_piece(x,y)
	x-=px-1
	y-=py-1
	add_piece(i,x*8,y*8)
end

function destroy_piece(_x,_y)
	local tl=mget(_x,_y)
	local p,px,py=unpack(get_piece_typ(tl))
	_x-=px-1
	_y-=py-1
	
	for y=1, #p do
		for x=1, #p[y] do
			if p[y][x] != -1 then
				local nx,ny=_x+x-1,_y+y-1
				local b = get_broken(nx,ny)
				if(b)del(broken,b)
				mset(nx,ny,0)
			end
		end
	end
end

function destroy_block(_x,_y)
	local tl=mget(_x,_y)-64
	tl=tl<11 and tl or tl-5

	local transform={
		{{2,2}},--65-1
		{{1,1},{4,1}},--66-2
		{{4,1}},--67-3
		{{2,1},{4,1}},--68-4
		{{1,2}},--69-5
		{{7,3}},--70-6
		{{4,3}},--71-7
		{},--72-8
		{{-1,6}},--73-9
		{{1,5}},--74-10
		{{2,1}},--80-11
		{{1,1}},--81-12
		{{8,3}},--82-13
		{{3,1}},--83-14
		{{3,3}},--84-15
		{{5,2}},--85-16
		{{3,1},{1,1}},--86-17
		{{3,1},{2,1}},--87-18
		{{8,2}},--88-19
		{{3,7}},--89-20
		{{8,4}},--90-21
	}
	
	mset(_x,_y,0)
	
	local b = get_broken(_x,_y)
	if(b)del(broken,b)
	
	for t in all(transform[tl]) do
		local d,typ=unpack(t)
	
		local p=pieces_typ[typ]
		local nx,ny=_x,_y
		
		if d > 0 then
			nx+=dirx[d]
			ny+=diry[d]
		end

		for y=1, #p do
			for x=1, #p[y] do
				local ntl= p[y][x]
				if ntl != -1 then
					mset(nx+x-1,ny+y-1,ntl)
				end
			end
		end
		
	end
end
 
function update_pc_speed()
	for p in all(pieces) do
		p.dy=get_pc_dy()
		p.spd=get_pc_spd_dy()
	end
end
	
function get_flash_col(x)
	for c in all(flash_cols) do
		if(c==x)return c
	end
	return nil
end

function check_cols()
	for x=1,12 do
		local col=get_flash_col(x)
		if
		 fget(mget(x,0),1) or
		 fget(mget(x,1),1)
	 then
			if not col then
				add(flash_cols,x)
			end
		else
			if col then
			 del(flash_cols,col)
			end
		end
	end
end
-->8
--juice--

function addpart(typ,x,y,mage,carr,dx,dy)
	local dx = dx or 0
	local dy = dy or 0
	local part = {
		typ=typ,
		x=x,
		y=y,
		c=0,
		carr=carr,
		age=0,
		mage=mage,
		dx=dx,
		dy=dy
	}
	if(typ == 1) part.r = rnd(2)+1
	add(parts,part)
	return part
end

function doparts()
	for i=#parts,1,-1 do
		u_part(parts[i])
	end
end

function spawn_dust(_x,_y,carr)
	local spd={.15,.15,.1}
	local ox={0,1,0}
	for i=1,3 do
		local x = _x+4+ox[i]
		local y = _y+7
		local dx=dirx[i]*spd[i]
		local dy=diry[i]*spd[i]
		local mage=20
		addpart(0,x,y,mage,carr,dx,dy)
	end
end

function spawn_impact(_x,_y,_dx,_dy,flp,carr)
	local spd={.05,.15}
	local mage=15
	
	--left
	for i=1,2 do
		local x=flp and _x+1 or _x+2
		local y=_y+7
		local dx=dirx[1]*spd[i]+_dx
		local dy=diry[1]*spd[i]+_dy
		addpart(0,x,y,mage,carr,dx,dy)
	end
	
	--right
	for i=1,2 do
		local x=flp and _x+5 or _x+6
		local y=_y+7
		local dx=dirx[2]*spd[i]+_dx
		local dy=diry[2]*spd[i]+_dy
		addpart(0,x,y,mage,carr,dx,dy)
	end
end

function u_part(part)
	part.age += 1

	if part.age >= part.mage then
		del(parts,part)
		return
	end
	
	part.x += part.dx
	part.y += part.dy

	-- update colors
	if #part.carr==1 then
			part.c = part.carr[1]
	else
		local ci=part.age/part.mage
		ci=1+flr(ci*#part.carr)
		part.c = part.carr[ci]
	end
	
	-- update radius
	if part.typ == 1 then
		local ci=part.age/part.mage
		ci=1+flr(ci*#part.rarr)
		part.r = part.rarr[ci]
	end
	
end

function d_part(part)
	local x,y,c,r,typ=part.x,part.y,part.c,part.r,part.typ
	if typ == 0 then
		pset(x,y,c)
	elseif typ == 1 then
		circfill(x,y,r,c)
	end
end
-->8
--tong

function spwn_tong()
	local b =getbutt()
	if(b<0) b=f.flp and 1 or 2
	
	local mx=tongs_m[f.typ]+tong_arr[tong_lvl+1]

	local d=v2:new(dirx[b],diry[b])
	local fg=v2:new(f.x,f.y)
	local trgt=get_tong_offset(fg+d*mx)
	local state=f.state
	local v=get_start_tong()
	
	if state=="jump" then
		trgt.y-=2
	elseif state=="fall" then
		trgt.y+=2
	end

	f.tong={
		spd=tongs_spd[f.typ],
		tick=0,
		v=v,
		trgt=trgt,
		mx=mx,
		state="fwd",
		waitspd=tongs_wait[f.typ],
		d=d,
		b=b
	}
	
end

function u_tong()
	local tong=f.tong
	if(not tong)return
	local d=tong.d*8
	local state=tong.state
		
	local a=get_start_tong()
	local v,pc=tong.v,tong.pc

	if state=="fwd" then
		mov_tong_fwd()
	elseif state=="wait" then
		tong.tick=min(tong.tick+tong.waitspd,1)
		if tong.tick == 1 then
			tong.state="back"
			tong.tick=0
			mov_piece_tong()
		end
	elseif state=="back" then
		tong.tick=min(tong.tick+0.125,1)
		mov_tong_back()
	end

--	local nv=tong.v-a
--	nv=nv:clamp(tong.mx)
--	tong.v=nv+a
end

function d_tong()
	if f.typ==1 then
		d_mouth()
	end
	d_line()
end

function d_mouth()
	local tong=f.tong
	local a=get_start_tong()-1

	rectfill(a.x,a.y,a.x+3,a.y+1,2)
end

function d_line()
	local tong=f.tong
	
	local a=get_start_tong()
	local b=tong.v
	local c=b-a
	local n=c:norm()
	local d=n*2

	if f.typ<3 then
		circfill(b.x-d.x,b.y-d.y,2,8)
	end
	line(a.x,a.y,b.x,b.y,f.typ==3 and 10 or 8)
end

function get_start_tong()
	local smll=s==2or s==4or s==5or s==7
	
	local x1=f.x + (f.flp and -2 or 0)
	local y1=f.y + (smll and 1 or 0)

	return v2:new(x1+4,y1+4)
end

function get_tong_offset(v)
	local smll=s==2or s==4or s==5or s==7
	local ox = f.flp and 2 or 4
	local oy = smll and 4 or 3
	local o=v2:new(ox,oy)
	return o+v
end

function hit_map(v)
	local x=v.x\8
	local y=v.y\8
	local tile=mget(x,y)
	local b=get_broken(x,y)
	
	if(not b) return add_broken(x,y)
	
	del(broken,b)
	destroy_block(x,y)
	tong_blocks+=1
	if tong_blocks == 50 then
		ng_unlock_medal(6)
	end
	sfx(56)
	shift_lines()
end


function mov_tong_fwd()
	local tong=f.tong
	local mx=tong.mx
	local spd=tong.spd
	
	local a=get_start_tong()
	local trgt=tong.trgt

	local tmp=mov_to(tong.v,trgt,spd)
	local iscol=false
	
	for i=1,4 do
		if 
			tong_vs_map(tong.v) or 
			tong_vs_pieces(tong.v) 
		then
			tong.state="wait"
			tong.tick=0
			tong.t=tong.v
			return
		end
		tong.v=mov_to(tong.v,tmp,spd/4,0)
	end

	local c=a-tong.v
	local m=c:mag()
	
	if m > tong.mx or tong.v==trgt then
		tong.state="wait"
		tong.tick=0
	end
end

function mov_tong_back()
	local tong=f.tong
	local a=get_start_tong()
	local spd=tong.spd
	
	tong.v=mov_to(tong.v,a,spd)
	
	if f.tick==1 or tong.v == a then
		f.tong=nil
	end
end

function mov_to(a,b,spd,toler)
	local toler=toler or 2
	local c=b-a
	local d=a+(c:norm()*spd)
	
	local e=b-d
	local m=e:mag()
	
	if(m < spd)return b
	return d
end

function tong_vs_map(v)
	local iscol=is_coll_map_point(
		v.x,v.y
	)
	
	if(not iscol)return false

	iscol=is_coll_map_point(
		v.x,v.y,1
	)
	if(iscol)hit_map(v)
	return true
end

function tong_vs_pieces(v)
	local iscol=is_coll_pieces_point(
		v.x,v.y
	)
	
	if(not iscol)return false

	f.tong.pc=iscol
	f.tong.pc.freeze=true
	return true
end

function mov_piece_tong()
	local tong=f.tong
	local d,pc=tong.d*8,tong.pc
	
	if(not pc)return
	
	local a=get_start_tong()
	
	local mx=10
	-- if direction is diagonal 
	if(f.tong.b > 4)mx+=1
	pc.freeze=false
	if((a-tong.v):mag()<mx) then
		pc.n=nil
		pc.t=0
		pc.dy=get_pc_dy()
		tong.pc=nil
	else
		pc.n=pc.v-d
		pc.t=0
		ng_unlock_medal(20)
	end
end
-->8
--tools--

function getbutt()
	if btn(0) then--0
		if(btn(2))return 8--2
		if(btn(3))return 7--3
		return 1--0
	end
	
	if btn(1) then
		if(btn(2))return 5--13
		if(btn(3))return 6--14
		return 2--12
	end
	
	if(btn(2))return 3--32
	if(btn(3))return 4--43
	
	return -1
end

function limit_speed(num,maximum)
	return mid(-maximum,num,maximum)
end

function get_frame(ani,speed,_t)
	local _t= _t or t 
	local speed = speed or 15
	return ani[flr(_t/speed)%#ani+1]
end

function getmapcoords(l)
	return {x=(l%8)*16,y=(l\8)*16}
end

function lerp(a,b,t)
	return a*(1-t)+b*t
end

function hcntr(s)
	return 64-#s*2
end

function oprint8(_t,_x,_y,_c,_c2)
	for i=1,8 do
		print(_t,_x+dirx[i],_y+diry[i],_c2)
	end
	print(_t,_x,_y,_c)
end

function dofade()
	local _t=fadeperc
	local c =_t>.5 and 0 or 0
	
	for i=0,8 do
		for j=0,8 do
			local x = i*16
			local osc1=sin(_t+i*0.1)
			local osc2=sin((_t)+j*0.03)
			local y = j*16+osc1*10
			circfill(x,y,osc2*15,c)
		end
	end
end

function wait(_wait)
	repeat
		_wait-=1
		flip()
	until _wait<0
end

function checkfade(spd)
	if (spd==nil) spd=0.01
	if fadeperc>0 then
		fadeperc=max(fadeperc-spd,0)
		dofade()
	end
end

function fadeout(spd,_wait)
	if (spd==nil) spd=0.01
	if (_wait==nil) _wait=0
	fadeperc=0
	local lmt=0.6

	repeat
		fadeperc=min(fadeperc+spd,lmt)
		dofade(0)
		flip()
	until fadeperc==lmt
	wait(_wait)
end

function dbox(x,y,w,h,fg,bg,bt)
	--bg
	rectfill(x+1,y+1,x+w,y+h,bg)
	
	--top border
	line(x+2,y,x+w-2,y,fg)
	--topleft corner
	pset(x+1,y+1,fg)
	--left border
	line(x,y+2,x,y+h-2,fg)
	--bottom left corner
	pset(x+1,y+h-1,fg)
	--topright corner
	pset(x+w-1,y+1,fg)
	--bottomright corner
	pset(x+w-1,y+h-1,fg)
	--right border
	line(x+w,y+2,x+w,y+h-2,fg)
	--bottom-border
	line(x+2,y+h,x+w-2,y+h,fg)
end

function digits2(n,d)
	local d=d or 2
	local n=tostr(n)
	while(#n<d) do
		n="0"..n
	end
	return n
end

function putmask()
 for x=0,1,1 do
  for y=0,1,1 do
   circ(ded_x+x,ded_y+y,mask_r,0) 
  end
 end
 --draw a slightly smaller circle
 mask_r=max(0,mask_r-rmod)
end
-->8
-- vector2
v2={}
function v2:new(x,y)
	v={}
	v.x=x or 0
	v.y=y or 0
	
	setmetatable(v,self)
	self.__index=self
	return v
end

function v2.__add(a,b)
	if type(b) == "number" then
		return v2:new(a.x+b,a.y+b)
	end
	return v2:new(a.x+b.x,a.y+b.y)
end

function v2.__sub(a, b)
	if type(b) == "number" then
		return v2:new(a.x-b,a.y-b)
	end
	return v2:new(a.x-b.x,a.y-b.y)
end

function v2.__mul(a, b)
	if type(a) == "number" then
		return v2:new(b.x*a,b.y*a)
	elseif type(b) == "number" then
		return v2:new(a.x*b,a.y*b)
	end
	return a.x * b.x + a.y * b.y
end

function v2.__div(a,b)
	if type(a) == "number" then
		return v2:new(b.x/a,b.y/a)
	elseif type(b) == "number" then
		return v2:new(a.x/b,a.y/b)
	end
end

function v2.__eq(a,b)
	return a.x==b.x and a.y==b.y
end

function v2:mag()
	return sqrt((self.x*self.x)+(self.y*self.y))
end

function v2:norm()
	return self/self:mag()
end

function v2:clamp(mx)
	local m=self:mag()
	local n=self:norm()

	local f=min(m,mx)
	return n*f
end

function v2:lerp(a,b,t)
	return v2:new(
		lerp(a.x,b.x,t),
		lerp(a.y,b.y,t)
	)
end
-->8
--door

function spwn_door()
	local x=6
	local y=13
	local w=2
	local h=2
	door_spwned=true
	--sfx()
	spawn_dust(x*8,y*8,{13,5,1})
	door=v2:new(x,y)
end

function u_door()
	local x,y=door.x,door.y
	destroy_block(x,y)
	mset(x,y,110)
	destroy_block(x+1,y)
	mset(x+1,y,111)
	destroy_block(x,y+1)
	mset(x,y+1,126)
	destroy_block(x+1,y+1)
	mset(x+1,y+1,127)
end

function destroy_door()
	if(not door)return
	local x,y=door.x,door.y
	mset(x,y,0)
	mset(x+1,y,0)
	mset(x,y+1,0)
	mset(x+1,y+1,0)
	door=nil
	spawn_dust(x*8,y*8,{13,5,1})
	shift_lines()
end
-->8
ded_msgs={
	split"and so my sad tale,comes to a sad end.,,i have failed to,protect this land.,,i find solace only,in hope that future,generations will,take up this noble,cause.",
	split("did you know?|you can pull the|falling pieces|diagonally!||so, try not to get|crushed","|"),
	split"-lime treat-,-1cup condensed milk,-1cup evaporated milk,-1cup lime juice,(blend this),,-pour on pie crust,-freeze 3 hrs ⧗,enjoy! 😐",
	split('okay...|i really thought|i was the one.||welp!you know what|they say:|"twice the pride,|double the fall"',"|"),
	split("i have failed, just|like my ancestors.||oh well.|guess i should've|prepared for this.||oh wait i did!|my son shall follow|my footsteps.","|"),
	split("did i just get|crushed by a falling|cactus?|no, cacti have spines||what was i doing in|a desert?||i have a lot|of questions.","|"),
	split"i used to chill with,my friends in the,pond back home.,,suppose those days,are gone forever.,,i didn't want any of,this.",
	split'"five ☉s to open",i read that on a,fortune fly once.,,what does that even,mean?,,i only have two,eyes!what do you,want from me?',
	split",,,,,oh no!",
	split",,,,,☉ ",
	split",,,,don't be dyin' just,to read these.,,something strange,could happen.",
	split"the blocks fall,i pull the blocks,i lick the blocks,lines clear the,blocks.,,and it starts all,over again.,,is there no end?",
	split",,,,i heard the game,virush is pretty,fun!",
	split",,,,press f to pay,respects",
	split("||||alas!|death, the ultimate|mimir","|")
}
-->8
--newgrounds

ng_medals=split"1,9,13,14,8,7,15,16,18,6,17,19,20,3,11,5,10,2,12,4"

function ng_unlock_medal(medal_i)
	local medal_number=ng_medals[medal_i]
--	local has=false
--	for d in all(debug) do
--		if(d==medal_number)has=true
--	end
--	if not has then
--		add(debug,medal_number)
--	end
	if (peek(0x5f81)!=0) memset(0x5f80,0,128)
	poke(0x5f80,2)
	for i=2,127 do
		if peek(0x5f80+i)==0 then
			poke(0x5f80+i,medal_number)
			break
		end
	end
end

function lines_badge(lns,delta)

	for i=0,delta do
		lns += 1
		if lns == 1 then
			ng_unlock_medal(1)
		elseif lns == 10 then
			ng_unlock_medal(2)
		elseif lns == 50 then
			ng_unlock_medal(3)
		elseif lns == 120 then
			ng_unlock_medal(4)
		end
	end
	
	if delta == 2 then
		ng_unlock_medal(5)
		-- clear 2 lines simmultaneusly 
	end 
end