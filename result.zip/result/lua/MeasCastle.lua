-- mea's castle v1.11
-- by astorek86
function _init()
 cartdata("astorek86_meascastle_1")
 -- no auto-repeat delay btnp
 --poke(0x5f5c,-1)
 menuitem(1, "…swap ❎/🅾️", swap_controls)
 menuitem(2, "…del save+reset", mea_del)
 
 init_mainmenu()
end

function init_mainmenu()
 ssave,fullcolltable,actors,dpal,killer_tile,fader,faderval,ctl_o_pressed,ctl_x_pressed,ctl_4,ctl_5,konami_code_active,konami_code,konami_i,clscolor,song,prev_song,camx,camy,player_tilex,player_tiley,powerup_text,winner,t_running,t_frames,t_secs,t_mins,t_hrs,t_deaths=nil,split("16,17,78,79,92,93,94,95,108,109,77,7"),{},split("0,1,1,2,1,13,6,4,4,9,3,13,1,13,14"),40,nil,nil,false,false,4,5,false,split("2,2,3,3,0,1,0,1,5,4"),1,0,-2,-2,0,0,0,0,"",false,false,0,0,0,0,0
 pal(14,0)
 if dget"0"==0 then
  menu_init(40,101,{
   "new game",
   "credits",
  },mainmenu_finish)
 else
  menu_init(40,97,{
   "continue",
   "new game",
   "credits",
  },mainmenu_finish)
 end
-- make_torch(9,11)
-- make_torch(12,11)
 make_fade(1,0,-.05)
 play_music"7"
 camx,camy,upd,draw=0,0,upd_mainmenu,draw_mainmenu
-- map_to_actor(true)
 make_torch(2,9)
 make_torch(13,9)
 if dget(14)==1 then
  dset(14,0)
  swap_controls()
 end
end

function mainmenu_finish(c)
 if c==#menu_t-1 then
  init_fade2credits()
 else
  if(c==1)dset(0,0)
  init_fade2game()
 end
end

function init_game()
 map_to_actor() -- reset actors
 play_music(0,0,12)
 
-- make_debugger()
 camx_old,camy_old,upd,draw = 0,0,upd_game,draw_game
 mea_load()
end

function init_powerup_screen(f)
 starshower = make_starshower()
 play_music(-1,0)
 sfx"6"
 powerup_timer,clscolor,powerup_text,upd,draw=0,1,f.text,upd_powerup_screen,draw_powerup_screen
 del(actors,f)
-- make_fade(0,.25,.0100)
 make_fade(0,.25,.01)
 ssave=make_save(player)
end

function init_winner()
 play_music(8,0)
 actors,flashy_text,flashy_color={},0,flr(rnd(16))
 if t_hrs < 10 then
  t_hrs = "0"..t_hrs
 end
 if t_mins < 10 then
  t_mins = "0"..t_mins
 end
 if t_secs < 10 then
  t_secs = "0"..t_secs
 end
 winner,upd,draw=false,upd_winner,draw_winner
end

function init_fade2credits(nomusic)
 sfx"18"
 make_fade(0,1,.1)
 upd=upd_fade2credits
 if not nomusic then
  music"-1"
  draw=draw_fade2credits
 else
  draw=draw_winner
 end
end

function init_credits()
 play_music"8"
 actors,flashy_color,flashy_text,upd,draw={},flr(rnd(16)),0,upd_credits,draw_credits
end

function init_fade2game()
 music"-1"
 sfx"18"
 fade2game_timer,upd,draw=0,upd_fade2game,draw_fade2game
end

function init_fade2mainmenu()
 music"-1"
 sfx"18"
 make_fade(0,1,.1)
 upd,draw=upd_fade2mainmenu,draw_fade2mainmenu
end
-->8
-- upds
function _update60()
btn_l,btn_r,btn_u,btn_d,btn_o,btn_x,btn_l1,btn_r1,btn_u1,btn_d1 = btn(0),btn(1),btn(2),btn(3),btn(ctl_4),btn(ctl_5),btnp(0),btnp(1),btnp(2),btnp(3)

 if (btn_o or btn_o1) and btn_o_pressed then
  btn_o1 = false
 end
 if (btn_o or btn_o1) and not btn_o_pressed then
  btn_o_pressed,btn_o1,btn_o = true,true,true
 end
 if btn_o_pressed and not (btn_o or btn_o1) then
  btn_o_pressed = false
 end

 if (btn_x or btn_x1) and btn_x_pressed then
  btn_x1 = false
 end
 if (btn_x or btn_x1) and not btn_x_pressed then
  btn_x_pressed,btn_x1,btn_x = true,true,true
 end
 if btn_x_pressed and not (btn_x or btn_x1) then
  btn_x_pressed = false
 end


-- btn_o1 = btnp(ctl_4)
-- btn_x1 = btnp(ctl_5)
 upd()
 
 if t_running then
  t_frames=(t_frames+1)%60
  if t_frames==0 then
   t_secs = (t_secs+1)%60
   if t_secs==0 then
    t_mins = (t_mins+1)%60
    if t_mins==0 then
     t_hrs+=1
    end
   end
  end
 end
end

function upd_mainmenu()
 do_actors"upd"
 menu_upd()
 if(fader)return
 if btn_l1 or btn_r1 or
  btn_u1 or btn_d1 or
  btn_o1 or btn_x1 then
   if btn(konami_code[konami_i]) then
    konami_i+=1
    if konami_i>#konami_code then
     sfx"15"
     konami_code_active = not konami_code_active
    end
   else
    konami_i=1
   end
 end
end

function upd_game()
 player.used_treadmill=false
 player_tilex,player_tiley,camx,camy = flr(player.x/8)*8,flr(player.y/8)*8,flr((player.x+3)/128)*128,flr((player.y+3)/128)*128
 if camx!=camx_old or camy!=camy_old then
  camx_old,camy_old = camx,camy
  reload()
  map_to_actor(true)
 end
 do_actors"anim"
 do_actors"upd2"
 do_actors"upd"
end

function upd_powerup_screen()
 upd_starshower(starshower)
 if(ssave)ssave:upd()
 if powerup_timer==149 then
  powerup_text=powerup_text.."\n\n🅾️ or ❎ to continue..."
 end
 if powerup_timer==150 then
  make_fade(.25,0,-.01)
  if btn_o1 or btn_x1 then
   sfx"7"
   clscolor=0
   if not winner then
    play_music(0)
   else
    player.fade=true
    make_fade(.25,1,.005)
   end
   del_starshower(starshower)
   upd,draw = upd_game,draw_game
  end
 else
  powerup_timer=powerup_timer+1
 end
end

function upd_winner()
 flashy_text=(flashy_text+1)%5
 if flashy_text==0 then
  flashy_color = flr(rnd(16))
 end
 if not fader and (btn_o1 or btn_x1) then
  sfx"18"
  init_fade2credits(true)
  --init_credits()
 end
end

function upd_credits()
 flashy_text=(flashy_text+1)%10
 if flashy_text==0 then
  flashy_color = flr(rnd(16))
 end
 if btn_o1 or btn_x1 then
--  make_fade(0,1,.1)
  init_fade2mainmenu()
 end
end

function upd_fade2credits()
 if not fader then
  make_fade(1,0,-.1)
  init_credits()
 end
end

function upd_fade2mainmenu()
 if not fader then
  make_fade(1,0,-.1)
  init_mainmenu()
 end
end

function upd_fade2game()
 fade2game_timer+=.0175
 
 if fade2game_timer>=1 then
  actors,player={},nil
  reload()
  t_running,t_frames,t_secs,t_mins,t_hrs,t_deaths = true,0,0,0,0,0
  make_fade(1,0,-.05)
  init_game()
 end
end

-->8
-- draws
function _draw()
 draw()
 if(fader)fader:draw()
 if(fader)fader:upd()
end

function draw_mainmenu()
 camera(0,0)
 cls"0"
 map()
 rectfill(32,71,95,79,0)
 color"1"
 cursor(40,72)
 print"mEA'S cASTLE"
 color"3"
 cursor(40,73)
 print"mEA'S cASTLE"
 do_actors"draw"
 rectfill(48,120,127,126,1)
 print("bY aSTOREK86, V1.11",51,121,5)
 rectfill(32,96,95,119,1)
 rect(32,95,95,119,0)

 palt(0,false)
 rectfill(38,80,89,94,1)
-- rect(37,80,90,95,5)
 cursor(40,82)
 color"0"
 print"  ⬆️    z/🅾️\n⬅️⬇️➡️  x/❎"
 palt()
 color"15"
 menu_draw()
end

function draw_game()
 camera(0,0)
 cls(clscolor)
 do_actors"predraw"
-- camx = flr((player.x+3)/128)*128
-- camy = flr((player.y+3)/128)*128
 camera(camx,camy)
 map(0,0,0,0,128,64)
 do_actors"draw"
 
 if player.fade and not fader then
  init_winner()
  make_fade(1,0,-.05)
 end
end

function draw_powerup_screen()

-- pal(14,0)
-- if(fader)fader:draw()
 draw_game()
-- pal(14,0)
-- fadepal(nil,faderval)
 player:draw()
 fadepal(0,true)

-- cls(clscolor)
-- map(0,0,0,0,128,64)
-- do_actors("draw")
 camera(0,0)
 rectfill(10,37,117,85,0)
 rect(10,37,117,85,10)
 line(10,73,117,73,10)
 color"7"
 cursor(20,41)
 print(powerup_text)
 fadepal(faderval,true)
 if(ssave)ssave:draw()
end

function draw_winner()
 cls"1"
 camera(0,0)
-- map(32,32)
 map()
 cursor(30,60)
 color(flashy_color)
 print"congratulations!"
 cursor(45,70)
 color"9"
 print"your time:"
 color"10"
 print(t_hrs..":"..t_mins..":"..t_secs.."."..t_frames)
 color"9"
 print"\ndeaths:"
 color"10"
 print(t_deaths)
 color"15"
 print("thank you so much for\n   playing my game!\n have a nice day! :)",20,108)
end

function draw_credits()
 cls"1"
 camera(0,0)
-- map(32,32)
 map()
 cursor(30,50)
 color(flashy_color)
 print"credits:"
 color"15"
 cursor(15,60)
 print"- @GRUBER_MUSIC for his\nawesome music-contribution!\n- @ZEP and the whole PICO8-\nCOMMUNITY, including\nDEV_QUEST and KRYSTMAN!\n- MASAKADO for putting the\ngame to speedrun.com!\n- everyone else i forgot^^"
 cursor(15,110)
 color"7"
 print"- of course: thanks to YOU\nfor playing the game! :)"
--[[
 print"- @GRUBER_MUSIC for his\nawesome music contribution\nin the pico8-community"
 cursor(15,80)
 print"- @ZEP for pico8, a\ngreat fantasy console"
 cursor(15,94)
 print"- the whole COMMUNITY!\nyou are all awesome^^"
--]]
end

function draw_fade2game()
 draw_mainmenu()
 fadepal(fade2game_timer)
end

function draw_fade2mainmenu()
 draw_credits()
end

function draw_fade2credits()
 draw_mainmenu()
end

-->8
-- actorlib
function do_actors(cmd)
 for v in all(actors) do
  v[cmd](v)
 end
end

function disable_actors(cmd)
 for v in all(actors) do
  v[cmd] = nothing
 end
end

function swap_actorfunc(a,b)
 for v in all(actors) do
  v[a], v[b] = v[b], v[a]
 end
end

function nothing()
end

function draw_actor(f)
 if (not is_on_cam(f))return
 spr(f.s,f.x,f.y,flr(f.w/8)+1,flr(f.h/8)+1,f.sx,f.sy)
end

function anim_actor(f)
 if (not is_on_cam(f))return
 if f==player or player.timestop_count<=200 then
  if f.dy==0 and f.dx!=0 then
	  f._spr_s+=1
	  if f._spr_s==f.spr_speed then
	   f._spr_s=0
 	  f._spr_i=f._spr_i%#f.spr_walk+1
	   f.s=f.spr_walk[f._spr_i]
	  end
 	elseif f.dx==0 or f.dy!=0 then
	  f._spr_s=0
	  f._spr_i=1
 	 if f.dy>0 and not is_solid(f,0,1) then
	   f.s=f.spr_fall
	  elseif f.dy<0 then
	   f.s=f.spr_fly
 	 else
 	  if f.s==18 and f.dy>.9 then
     make_dusk(f.x,f.y+4)
     if f.play_stomp then
      f.sx=not f.sx
      make_dusk(f.x,f.y+4)
      f.sx=not f.sx
      if(not f.fade)sfx"11"
      f.play_stomp=false
      f.dy=0
     end
    end
	   f.s=f.spr_walk[1]
	  end
 	end
 else
  -- nothing
 end
end

function make_actor(x,y,s)
  x,y,s=x or 0,y or 0,s or 0
  return add(actors, {
  x=x or 0,
  y=y or 0,
  s=s or 0,
  w=7,
  h=7,
  ox=0,
  oy=0,
  sx=false,
  sy=false,
  dx=0,
  dy=0,
  my_camx=flr(x/128)*128,
  my_camy=flr(y/128)*128,
  spr_walk={s or 0},
  spr_fall=s or 0,
  spr_fly=s or 0,
  spr_speed=7,
  _spr_i=1,
  _spr_s=0,
  predraw = nothing,
  draw = draw_actor,
  upd = nothing,
  upd2 = nothing,
  anim = nothing,
  upd_backup = nothing,
  })
end

-- player
--------------------------------
function jump_player(f,d,nocheck)
-- d=d or 1.55
 d=d or f.jump_height
 nocheck=nocheck or false
 local jump_allowed=false
-- if not nocheck and f.can_walljump and not is_solid(f,0,0,3) and not is_solid(f,0,1,{0,5}) then
 if f.coyote_fall==12 and not nocheck and f.can_walljump and not is_solid(f,0,0,3) and not is_solid_down(f,0,1,{0,5}) then
  if is_solid_left_down(f,-1) then
   f.dx,d,jump_allowed=2.5,d*.9,true
  elseif is_solid_right_down(f,1) then
   f.dx,d,jump_allowed=-2.5,d*.9,true
  end
 end

-- if nocheck or f.dy>=0 and not is_solid(f,0,-f.h-d) then
 if nocheck or f.dy>=0 then
  if (nocheck or is_solid_down(f,0,1,{0,5}) or is_solid_down(f,0,0,5) or f.coyote>0) and not is_solid(f,0,-2) then
   jump_allowed=true
  end
 end
 
 if not jump_allowed then
  if f.can_doublejump and not f.did_doublejump and not is_solid(f,0,-2) then
   f.did_doublejump=true
   sfx"14"
   f.dy=-d
   make_dusk(f.x,f.y+4)
   return
  end
 end
 
 if jump_allowed then
  if(not winner)sfx"0"
  f.dy=-d
  make_dusk(f.x,f.y+4)
  f.did_doublejump,f.coyote,f.coyote_fall=false,0,0
 end
end

function upd_player_gameover(f)
 f.go_timer+=1
 f.s=f.go_timer%5==0 and 59 or 34
 -- timer is over:
 if f.go_timer==60 then
  make_fade(.25,0,-.05)
  f.x,f.y,f.play_stomp,f.dx,f.dy,f.s,f.sx,f.anim,f.upd,f.upd_backup,f.gameover = f.checkpoint_x,f.checkpoint_y,false,0,0,1,false,anim_player,upd_player,nothing,false
  reload()
  init_game()
 end
end

function upd_player(f)
 f.my_camx = flr((player.x+3)/128)*128
 f.my_camy = flr((player.y+3)/128)*128

 -- check blocks:
 -- spikes (from down)
 if f.dy>0.37 and is_solid(f,0,0,1) and not is_solid(f,0,0,7) then
  f.gameover = true
 end
 
 -- spikes (from up)
 if f.dy<0 and is_solid(f,0,0,6) and not is_solid(f,0,0,7) then
  f.gameover = true
 end
 
 -- spikes (from side)
 if is_solid(f,0,0,7) then
  if f.dx>0 and is_solid(f,0,0,6) then
   f.gameover = true
  elseif f.dx<0 and is_solid(f,0,0,1) then
   f.gameover = true
  end
 end
 
 if f.gameover and konami_code_active then
  f.gameover = false
 end
 
 if f.y>509 then
  f.gameover = true
 end
 
 if f.gameover then
  t_deaths+=1
  f.coyote_fall=0
  mea_save()
--  f.anim = nothing
  f.s,f.go_timer=34,0
  disable_actors("upd")
  disable_actors("anim")
  player.timestop_count=0
  pal()
  pal(14,0)
  sfx"4"
  make_fade(0,.25,.05)
  f.upd = upd_player_gameover
  
  if f.checkpoint then
   fire_checkanim(f.checkpoint)
   f.checkpoint.anim=anim_always
  end
  
  return
 end
 
 -- check inputs
 local nx=0
 if btn_l then
  f.sx,nx=true,-1
 end
 if btn_r then
  f.sx=false
  nx+=1
 end
 if btn_o1 then
--  f.is_ducking=false
  stop_ducking()
 end
 if f.can_timestop and btn_d and btn_x then
  if f.timestop_count==0 then
   make_stop_time()
  elseif f.timestop_count<=200 then
   sfx"36"
  end
 end

 -- soundeffect if using timer 
 if player.timestop_count>0 then
  player.timestop_count-=1
  if player.timestop_count==0 then
   sfx"35"
   make_player_sparkle()
  end
 end

 if f.is_ducking then
  f.oy,f.h,f.accdx,f.maxdx=4,3,.1,.5
  if(f.dx!=0)f._d+=1
  if f._d==0 or f._d==14 then
   f._d,f.s=0,19
  elseif f._d==7 then
   f.s=33
   if(f.dx!=0)sfx"1"
  end
 else
  f.oy,f.h,f.accdx,f.maxdx,f._d=1,6,.15,1.08,0
 end
 if f.dx>f.maxdx or f.dx<-f.maxdx then
  f.dx=f.dx*.8
 else
  f.dx=mid(-f.maxdx,f.dx+f.accdx*nx,f.maxdx)
 end

 repeat 
  f.dx=reduce(f.dx,f.friction)
 until not is_solid(f,f.dx)

 f.x+=f.dx
 
 if btn_o1 then
  f.coyote_fall=12
 end
 
-- if btn_o1 and not f.is_ducking then
 if (btn_o1 or f.coyote_fall>0) and not f.is_ducking then
  jump_player(f)
 end
 f.coyote_fall=max(0,f.coyote_fall-1)


 -- gravity; but only if player
 -- isn't touching an "upper":
 if not is_solid(f,0,0,4) or player.timestop_count>=200 then
  f.dy+=f.gravity
 end
 
 if not f.play_stomp and f.dy>2.2 then
  f.play_stomp=true
 elseif f.play_stomp and f.dy<0 then
  f.play_stomp=false
 end
 
 -- player touches "upper"?
 -- min-speed!
 if is_solid(f,0,0,4) and player.timestop_count<200 then
  if f.dy>-.5 and f.dy<5 then
   if f.dy<=0 then
    f.dy=-.5
   else
    f.dy=.5
   end
  end
 end
 
 while is_solid(f,0,f.dy) or
 (f.dy>0 and is_solid_down(f,0,f.dy,{5})) do
  f.dy=reduce(f.dy,f.gravity)
 end
 
 if f.dy<-.5 and not btn_o then
  f.dy=min(-.5,f.dy+f.gravity)
 end

 if f.s==50 and is_solid(f,0,0,3) then
  sfx"19"
  make_rset(f.x+(f.sx and 2 or 5),f.y,0,1,3)
 end
 
 if f.s==50 and f.dy>.2 and not is_solid(f,0,0,3) then
  f.dy=f.dy*.9
  if(f.dy>.9)sfx"19"
 end
 
 if f.dy>=0 and is_solid_down(f,0,1,{0,5}) then
  f.y,f.dy,f.did_doublejump,f.coyote=flr(f.y),0,false,7
 else
 	f.y+=f.dy
 	f.coyote=max(0,f.coyote-1)
 end
end

function anim_player(f)
 if f.dy==0 then
  if is_solid(f,0,0,4) then
   f.s=17
  elseif btn_d and not btn_u then
   f.is_ducking=true
   if(f.s!=19 and f.s!=33)f.s=19
--  elseif btn_u and not btn_d and f.dx==0 then
--  	f.s=20
  elseif not f.is_ducking and btn_u and not btn_d then
   if f.dx==0 and f.s!=54 then
    f.s=20
   elseif not f.is_ducking and f.s!=54 then
    f.spr_walk=split("12,13,14,15")
    anim_actor(f)
   end
  else
   stop_ducking()
--   f.is_ducking=false
--   f.spr_walk={1,2,3,4}
   if not f.is_ducking then

    if f.dx==0 and ((f.sx and not is_solid_left(f,-1,1,{0,5})) or (not f.sx and not is_solid_right(f,1,1,{0,5}))) then
     f.s=54
    else
     if(f.s==54)f.s=1
     anim_actor(f)
    end
   end
  end
 else
  stop_ducking()
--  f.is_ducking=false
--  f.spr_walk={1,2,3,4}
  if (btn_l and is_solid_left_down(f,-1) and f.sx) or (btn_r and is_solid_right_down(f,1) and not f.sx) then
   if f.dy>0 and not (btn_l and btn_r) then
    f.s=50
   else
    f.s=f.spr_fly
   end
   if f.dy>.4 and not (btn_l and btn_r) then
    f._anim_dusk2=(f._anim_dusk2+1)%5
    if f._anim_dusk2==0 then
     make_dusk2(f.x,f.y,f.sx)
    end
   end
  else
   anim_actor(f)
  end
 end
end

function make_player(x,y)
 local f=make_actor(x*8,y*8,1)

 f.play_stomp,f.fade,f.checkpoint_x,f.checkpoint_y,f.checkpoint,f.coyote,f.coyote_fall,f.accdx,f.friction,f.maxdx,f.gravity,f.ox,f.w,f.spr_walk,f.spr_fly,f.spr_fall,f.spr_speed,f._d,f.is_ducking,f.gameover,f._anim_dusk2,f.jump_height,f.can_walljump,f.can_doublejump,f.can_timestop,f.has_key,f.timestop_count,f.did_doublejump,f.anim,f.upd,f.draw=false,false,f.x,f.y,nil,0,0,.15,.08,1.08,.06,2,3,split("1,2,3,4"),17,18,7,0,false,false,0,1.2,false,false,false,false,0,false,anim_player,upd_player,draw_player
-- f.jump_height = 1.55
-- f.can_walljump = true
-- f.can_doublejump = true
-- f.can_timestop = true
-- f.has_key = true

 return f
end

function draw_player(f)
 if not f.fade then
  fadepal(0,true)
 end
 if f.did_doublejump then
  pal(8,2)
 end
 draw_actor(f)
 if f.did_doublejump then
  pal(2,8)
 end
 if not f.fade then
  fadepal(faderval,true)
 end
end

-- torch
--------------------------------
function upd_torch(f)
 if (not is_on_cam(f))return
 f.t=(f.t+.1)%2
end

function draw_torch(f)
 if (not is_on_cam(f))return
 fillp(f.c)
 circfill(f.x+4,f.y,4+f.t,10)
 fillp(█)
 draw_actor(f)
end

function make_torch(x,y)
 local f=make_actor(x*8,y*8,49)
-- f.t=rnd()
 f.t=0
-- f.c=rnd({⧗,★,⌂,🐱})
 f.c,f.draw,f.upd=😐,draw_torch,upd_torch
 return f
end


-- trampoline
--------------------------------
function upd_trampoline(f)
 if (not is_on_cam(f))return
 if is_touching_player(f) then
  jump_player(player,2.31,true)
  sfx"2"
  f.upd = t_trampoline
 end
end

function t_trampoline(f)
 f.t+=1
 if(f.t==3)f.s=22
 if(f.t==5)f.s=21
 if(f.t==25)f.s=22
 if(f.t==35)f.s=23
 if f.t==45 then
  f.t,f.upd=0,upd_trampoline
 end
end

function make_trampoline(x,y)
-- local f=make_actor(flr(x/8)*8,flr(y/8)*8,23)
 local f=make_actor(x*8,y*8,23)
 f.ox,f.w,f.oy,f.h,f.t,f.upd=1,5,5,1,0,upd_trampoline
 return f
end

-- dust
--------------------------------
function upd_dusk(f)
 f.t+=1
 if(f.s<=41)f.x+=f.dx
 if(f.t%f.spd==0)f.s+=1
 if(f.s==42 or f.s==68)del(actors,f)
end

function make_dusk(x,y,spd)
 if(player.timestop_count>=200)return
 
 local f=make_actor(x,y,38)
 f.spd,f.sx,f.t,f.upd=spd or 5,player.sx,0,upd_dusk
 f.dx=f.sx and -.25 or .25
 return f
end

function make_dusk2(x,y,sx,spd)
 if(player.timestop_count>=200)return
 local f=make_dusk(x,y,spd)
 f.sx,f.s=sx,64
 return f
end

-- 3er_idle
function upd_3er_idle(f)
-- if (not is_on_cam(f))return
 f.t-=1
 if f.t==0 then
  f.t=9
  f.q-=1
  if f.q==2 then
   f.s=27
  elseif f.q==1 then
   f.s=11
  elseif f.q==0 then
   f.draw = nothing
  elseif f.q==-27 then
   f.s=11
   f.draw = draw_actor
  elseif f.q==-28 then
   f.s=27
  elseif f.q==-29 then
   f.s=43
  elseif f.q==-30 then
   if not is_touching_player(f) then
    make_3er(f.x/8,f.y/8,mget(f.x/8,f.y/8)==60 and 42 or 58)
    del(actors,f)
   else
    if same_screen_as_player(f) then
     sfx"3"
    end
    f.q=3
   end
  end
 end
end

function make_3er_idle(f)
 local f=make_actor(f.x,f.y,f.s)
 f.s_orig = f.s
 f.s,f.t,f.q,f.upd=43,9,3,upd_3er_idle
 return f
end

-- 3er_active
--------------------------------
function draw_3er_active(f)
 if (not is_on_cam(f))return
 if f.q>=0 then
  rect(f.x+(7-f.i),f.y+(7-f.i),f.x+f.i,f.y+f.i,7)
 end
end

function upd_3er_active(f)
-- if (not is_on_cam(f))return
 f.t-=1
 if f.t==0 then
  f.t=15
  f.i-=1
  if f.i<4 then
   f.i=7
   f.q-=1
   if f.q==2 then
    mset(f.x/8,f.y/8,26)
    if same_screen_as_player(f) then
     sfx"3"
    end
   elseif f.q==1 then
    mset(f.x/8,f.y/8,10)
    if same_screen_as_player(f) then
     sfx"3"
    end
   elseif f.q==0 then
    mset(f.x/8,f.y/8,f.s==42 and 60 or 59)
    make_3er_idle(f)
    del(actors,f)
   end
  end
 end
end

function make_3er_active(f)
 local f=make_actor(f.x,f.y,f.s)
 f.i,f.t,f.q,f.draw,f.upd=7,15,3,draw_3er_active,upd_3er_active
 sfx"3"
 return f
end

-- 3er-block-solid
--------------------------------
function upd_3er(f)
-- if (not is_on_cam(f))return
 if player.dy>=0 and is_touching_player(f) then
  f.s=f.s_orig
  make_3er_active(f)
  del(actors,f)
 end
end

function draw_3er(f)
end

function make_3er(x,y,v)
 local f=make_actor(x*8,y*8,42)
 mset(f.x/8,f.y/8,42)
 f.s_orig,f.oy,f.upd,f.draw,f.timer=v,-1,upd_3er,nothing,0
 return f 
end

-- stars
--------------------------------
function draw_star(f)
 pset(f.x,f.y,f.clr)
end

function upd_star(f)
 f.x+=f.speed
 if f.x>127 then
  del(actors,f)
  make_star()
 end
end

function make_star()
 local f=make_actor(rnd(128),rnd(128))
 f.draw,f.predraw,f.upd,f.speed,f.clr=nothing,draw_star,upd_star,rnd(1)+1,2
 return f
end

-- uppers
--------------------------------
function draw_upper(f)
 if (not is_on_cam(f))return
 if not f.disabled then
  draw_actor(f)
 end
end

function upd_upper(f)
 if (not is_on_cam(f))return
 if f.disabled and is_touching_player(f) then
  f.disabled,f.anim = false,anim_actor
 elseif not f.disabled and not is_touching_player(f) then
  f.disabled,f.anim,f._spr_s = true,nothing,f.spr_speed-1
 end
end

function make_upper(x,y)
 local f=make_actor(x*8,y*8,68)
 f.disabled = true
 -- trick animationsystem
 f.spr_walk,f.dx,f.spr_speed=split("69,70,71"),1,8
 f._spr_s,f.h,f.upd,f.draw=f.spr_speed-1,6,upd_upper,draw_upper
 return f
end

-- player-sparkles
function upd_player_sparkle(f)
 f.x,f.y=player.x,player.y
 upd_sparkle(f)
 f.timer3+=1
 if f.timer3==30 then
  pal()
  pal(14,0)
  del(actors,f)
 end
end

function make_player_sparkle()
 local f=make_sparkle(player.x,player.y)
 f.timer3=0
 f.upd = upd_player_sparkle
 return f
end

-- sparkles
--------------------------------
function upd_sparkle(f)
 if player.checkpoint_x == f.x and player.checkpoint_y == f.y then
  return
 end
 f.timer1=(f.timer1+1)%3
 if f.timer1==0 then
  f.stars_x = get4rnd()
  f.stars_y = get4rnd()
 end
end

function draw_sparkle(f)
 if (not is_on_cam(f))return
 if player.checkpoint_x == f.x and player.checkpoint_y == f.y then
  return
 end
 for i=1,3 do
  pset(f.x+f.stars_x[i],f.y+f.stars_y[i],15)
 end
end

function make_sparkle(x,y)
 local f=make_actor(x,y,0)
 f.stars_x,f.stars_y,f.timer1,f.draw,f.upd=get4rnd(),get4rnd(),0,draw_sparkle,upd_sparkle
 return f
end

-- powerup
--------------------------------
function draw_powerup(f)
 if (not is_on_cam(f))return
 f.y+=f.iy
 draw_actor(f)
 f.y-=f.iy
-- for i=1,3 do
--  pset(f.x+f.stars_x[i],f.y+f.stars_y[i],15)
-- end
end

function upd_powerup(f)
 if (not is_on_cam(f))return
-- f.timer1=(f.timer1+1)%3
-- if f.timer1==0 then
--  f.stars_x = get4rnd()
--  f.stars_y = get4rnd()
-- end
 
 f.timer2=(f.timer2+1)%10
 if f.timer2==0 then
  f.iy+=f.way
  if(f.iy==2 or f.iy==-2)f.way=-f.way
 end
 
 if is_touching_player(f) then
  player.checkpoint_x,player.checkpoint_y,player.checkpoint=f.x,f.y,nil
  f.callback()
  killer_tile=killer_tile/2
  if(not winner)mea_save()
  init_powerup_screen(f)
 end
end

function make_powerup(x,y,s,text,cb)
 local f=make_actor(x*8,y*8,s)
 f.upd,f.draw,f.timer2,f.iy,f.way,f.callback,f.text=upd_powerup,draw_powerup,0,0,1,cb,text
 make_sparkle(f.x,f.y)
 return f
end

-- highjump
--------------------------------
function make_highjump_powerup(x,y)
 return make_powerup(x,y,73,
  "      highjump-\n      artifact!\n\n  press and hold 🅾️\n   to jump higher",
  function()
   player.jump_height=1.55
  end)
end

function make_key_powerup(x,y)
 return make_powerup(x,y,101,
  "         key-\n      artifact!\n\n     doors aren't\n    closed anymore",
  function()
   player.has_key = true
   local gfg
   for iy=0,63 do
    for ix=0,127 do
     gfg=mget(ix,iy)
     if gfg==100 then
      mset(ix,iy,32)
     elseif gfg==43 then
      mset(ix,iy,7)
     end
    end
   end
  end)
end
 

-- cup
--------------------------------
function make_cup(x,y)
 return make_powerup(x,y,80,
  "\n    the legendary\n     cup of hope!\n\n    you found it!",
  function()
   dset(0,0)
   t_running = false
   winner = true
  end)
end

-- walljump
--------------------------------
function make_walljump_powerup(x,y)
 return make_powerup(x,y,74,
  "      walljump-\n      artifact!\n\npress 🅾️ while touching\n a wall to jump again",
  function()
   player.can_walljump = true
  end)
end

-- doublejump
--------------------------------
function make_doublejump_powerup(x,y)
 return make_powerup(x,y,75,
  "      doublejump-\n       artifact!\n\n   on air, press 🅾️\n    to jump again",
  function()
   player.can_doublejump = true
  end)
end

-- timestopper
function make_timestopper_powerup(x,y)
 return make_powerup(x,y,76,
  "      timestop-\n      artifact!\n\n hold ⬇️ and press ❎\n     to stop time",
  function()
   player.can_timestop = true
  end)
end

-- rader (red quader)
--------------------------------
function upd2_rader(f)
 if is_touching_player(f) then
  player.gameover=true
 end
end

function upd_rader(f)
 if (not is_on_cam(f))return
 if is_solid(f,f.dx,f.dy,{0,2}) then
  f.dy=-f.dy
  f.dx=-f.dx
 else
  f.x+=f.dx
  f.y+=f.dy
  f.rset_timer+=1
  if (f.rset_timer>10 and rnd()<.05) or f.rset_timer==20 then
   make_rset(f.x+rnd(8),f.y+rnd(8),f.dx,f.dy)
   f.rset_timer=0
  end
 end
end

function make_rader(x,y,v)
 local f=make_actor(x*8,y*8,28)
 f.rset_timer=0
 if v==9 or v==30 then
  f.dx=.5
 else
  f.dy=.5
 end
 if v<=9 then
  v=32
 else
  v=0
 end
 mset(x,y,v)
 f.upd = upd_rader
 f.upd2 = upd2_rader
 return f
end

-- checkpoint
--------------------------------
function fire_checkanim(f)
 f.s,f._spr_i,f.dx,f._spr_s=114,2,1,0
 f.spr_speed=6
end

function upd_checkpoint(f)
 if (not is_on_cam(f))return
 if f.dx==0 and is_touching_player(f) then
  if f.x==player.checkpoint_x and f.y==player.checkpoint_y then
  else
   sfx"15"
   fire_checkanim(f)
   f.spr_speed=3
   make_save(f)
   player.checkpoint_x,player.checkpoint_y,player.checkpoint = f.x,f.y,f
   mea_save()
  end
 elseif f._spr_i!=1 and f.s==113 then
-- elseif f.dx!=0 and f.s==113 then
  f.dx,f._spr_i,f._spr_s=0,1,0
 end
end

function anim_always(f)
 local bbbackup=player.timestop_count
 player.timestop_count=0
 anim_actor(f)
 player.timestop_count=bbbackup
end

function make_checkpoint(x,y)
 local f=make_actor(x*8,y*8,113)
 f.spr_walk = split("113,114,115,116,117,118,119,120,121,122,122,122,121,120,119,118,117,116,115,114,113")
 f.spr_speed=3
 f.upd2 = upd_checkpoint
 f.upd_backup = upd_checkpoint
 f.anim = anim_always
 make_sparkle(f.x,f.y)
 if f.x==player.checkpoint_x and f.y==player.checkpoint_y then
  player.checkpoint=f
 end
 return f
end

-- starshower
--------------------------------
function del_starshower(f)
 for i=1,#f.t do
  del(actors, f.t[i])
 end
 del(actors, f)
end

function upd_starshower(f)
 for i=1,#f.t do
  f.t[i].upd(f.t[i])
 end
end

function make_starshower()
 local f=make_actor()
 f.draw = nothing
-- f.upd = upd_starshower
 f.t = {}
 local fx,fy,t=camx/8,camy/8,8
 for y=fy+5,fy+10 do
  for x=fx+1,fx+14 do
   f.t[#f.t+1] = make_sparkle(x*8,y*8)
  end
 end
 return f
end

-- bullets
--------------------------------
function upd2_bullet(f)
 if is_touching_player(f) then
  player.gameover = true
 end
end

function upd_bullet(f)
-- if (not is_on_cam(f))return
 f.x+=f.dx
 f.y+=f.dy

  f.rset_timer+=1
  if (f.rset_timer>10 and rnd()<.05) or f.rset_timer==20 then
   make_rset(f.x+rnd(3),f.y+rnd(3),f.dx,f.dy)
   f.rset_timer=0
  end
 
 if is_solid(f) then
  if f.dx<0 then
   f.sx=true
  elseif f.dx>0 then
   f.x-=5
  end
  make_dusk2(f.x-1,f.y-1,f.sx,3)
  del(actors,f)
 end
end

function draw_bullet(f)
-- if (not is_on_cam(f))return
 circfill(f.x-f.dx,f.y-f.dy+1,1,5)
 circfill(f.x,f.y+1,1,8)
 --draw_actor(f)
end

function make_bullet(x,y,dx,dy)
 local f=make_actor(x,y,0)
 f.rset_timer,f.w,f.ox,f.h,f.dx,f.dy,f.draw,f.upd,f.upd2=0,2,-1,2,dx or 0,dy or 0,draw_bullet,upd_bullet,upd2_bullet
  -- only play soundeffect if
  -- player can see the cannon
 if same_screen_as_player(f) then
  sfx"16"
 end
 return f
end

-- cannon
--------------------------------
function upd_cannon(f)
 if (not is_on_cam(f))return
 f.timer=(f.timer+1)%f.timebreak
 if f.timebreak-f.timer==20 then
  f.s+=16
 end
 if f.timer==0 then
  f.s-=16
  make_bullet(f.x,f.y,f.dx,f.dy)
 end
end

function draw_cannon(f)
 spr(f.s,f.ox,f.oy)
end

function make_cannon(x,y)
 local f=make_actor(x*8,y*8)
 
 f.draw,f.ox,f.oy,f.upd=draw_cannon,f.x,f.y,upd_cannon
 local v = mget(x,y)
 f.s=v
 if v==78 or v==94 then
  f.dx=-1
  f.x-=2
 elseif v==79 or v==95 then
  f.dx=1
  f.x+=8
 elseif v==92 or v==108 then
  f.dy=-1
  f.y-=2
  f.x+=4
 elseif v==93 or v==109 then
  f.dy=1
  f.y+=7
  f.x+=4
 end
 if v==94 or v==95 or v==108 or v==109 then
  f.timebreak = 60
  mset(x,y,v-16)
  f.s-=16
 else
  f.timebreak = 90
 end
 f.camx,f.camy,f.timer = flr(f.x/128)*128,flr(f.y/128)*128,0
 return f
end

-- stoptimer
--------------------------------
function upd_stop_time(f)
 if player.timestop_count==200 then
  swap_actorfunc("upd", "upd_backup")
  player.upd,player.upd_backup = player.upd_backup, player.upd
  play_music(prev_song)
  pal()
  pal(14,0)
  del(actors,f)
 end
end

function make_stop_time(t)
 if t and t<=200 then return end
 local f=make_actor(0,0,0)
 color_dark()
 f.draw = nothing
 player.timestop_count=t or 360
 f.upd = upd_stop_time
 swap_actorfunc("upd", "upd_backup")
 player.upd,player.upd_backup = player.upd_backup, player.upd
 f.upd, f.upd_backup = f.upd_backup, f.upd
 play_music(6)
 return f
end

-- rombie (red zombie)
--------------------------------
function upd2_rombie(f)
 if is_touching_player(f) then
  player.gameover=true
 end
end

function shoot_rombie(f)
 f.shoot_timer-=1
 if f.shoot_timer==30 then
--  if f.sx
  make_bullet(f.sx and f.x or f.x+7,f.y+2,f.sx and -1 or 1)
 end
 if f.shoot_timer==0 then
  f.anim,f.upd = anim_actor,upd_rombie
 end
end

function upd_rombie(f)
 if (not is_on_cam(f))return
 if is_solid(f,f.dx,0,{0,2}) then
  f.turn = true
 elseif is_solid_left(f,f.dx,1,{0,5}) and is_solid_right(f,f.dx,1,{0,5}) then
  f.x+=f.dx
 else
  if is_solid(f,0,1) then
   f.turn=true
  else
   f.y+=1
  end
 end
 if f.turn then
  f.dx,f.sx,f.turn=-f.dx,not f.sx,false
 end
 if flr(f.y/8)*8 == player_tiley then
  f.camx = flr(f.x/128)*128
  if camx==f.camx then
   if f.sx and player.x<f.x or
   not f.sx and player.x>f.x then
    f.anim,f.s,f.shoot_timer,f.upd=nothing,57,60,shoot_rombie
   end
  end
 end
 
end

function make_rombie(x,y)
 local f=make_actor(x*8,y*8,55)
 f.w,f.ox,f.spr_walk,f.spr_speed,f.anim,f.dx,f.turn,f.upd,f.upd2=3,2,{55,56},10,anim_actor,.1,false,upd_rombie,upd2_rombie
 return f
end

-- treadmill
--------------------------------
function upd_laufband(f)
 if (not is_on_cam(f))return
 if not player.used_treadmill and is_touching_player(f) then
  if not is_solid(player,player.dx+f.dx) then
   player.x+=f.dx
   player.used_treadmill = true
  end
 end
end

function make_laufband(x,y,left)
 local f=make_actor(x*8,y*8,96)
 f.spr_walk = split("96,97,98")
 f.oy=-1
 if left then
  f._spr_i=-x%3
 else
  f._spr_i=x%3
 end
 if(left)f.sx=true
 f.dx=left and -.6 or .6
 f.anim,f.upd = anim_actor,upd_laufband
 return r
end

-- musicstopper
function upd_musicstopper(f)
 if (not is_on_cam(f))return
 if is_touching_player(f) then
  music(-1,6000)
  player.can_walljump,player.can_doublejump,player.can_timestop,player.has_key,t_running = false,false,false,false,false
  del(actors,f)
 end
end

function make_musicstopper(x,y)
 local f=make_actor(x*8,y*8,0)
 f.draw,f.upd,f.upd_backup,f.upd2 = nothing,upd_musicstopper,upd_musicstopper,upd_musicstopper
 return f
end

-- edge-tile - thanks to
-- youtube-user "dev quest"
-- for the tutorial!
-- https://www.youtube.com/watch?v=rwdlsqpykbc
function edgedraw(f)
 sspr(f.x,f.y,f.w,f.h,f.dx,f.dy)
end

function make_sspr(id,ox,oy,w,h,dx,dy)
 local x,y=(id%16)*8+ox,(id\16)*8+oy
 local f=make_actor(x,y)
 f.w,f.h,f.dx,f.dy,f.draw=w,h,dx,dy,edgedraw
 return f 
end

-- rset
--------------------------------
function upd_rset(f)
 f.t-=1
 f.x+=f.dx
 f.y+=f.dy
 if(fget(mget(f.x/8,f.y/8),0))f.t=0
 if(f.t<=0)del(actors,f)
end

function draw_rset(f)
 pset(f.x,f.y,f.c)
end

function make_rset(x,y,dx,dy,c)
 local f=make_actor(x,y)
 f.dx,f.dy=rnd(abs(dx)),rnd(abs(dy))
 if(dx<0)f.dx=-f.dx
 if(dy<0)f.dy=-f.dy
 if(f.dx==0)f.dx=-rnd(.1)+.05
 if(f.dy==0)f.dy=-rnd(.1)+.05
 f.t=ceil(rnd()*50+50)
 f.upd=upd_rset
 f.draw=draw_rset
 f.c=c or 13
 return f
end

-- fade-in/-out
-- (no actor!!!!!!!)
--------------------------------
function draw_fade(f)
 fadepal(f.start)
end

function upd_fade(f)
 f.start+=f.step
 if f.start<0 or f.start>1 then
  f.kill=true
 elseif (not f.reverse and f.start>=f.bend) or (f.reverse and f.start<=f.bend) then
  f.kill=true
 end
 if f.kill then
  f,fader=nil,nil
 end
end

function make_fade(bbstart,bbend,bbstep)
 local f={}
 f.kill,f.start,f.bend,f.step = false,bbstart or 0,bbend or 1,bbstep or .1
 if f.start>f.bend then
  f.reverse=true
 else
  f.reverse=false
 end
 f.draw,f.upd,fader = draw_fade,upd_fade,f
end

-- draw_saver
function draw_save(f)
 camera()
 print("\#1SAVED",mid(1,f.x-5,108),f.y-6,(f.t/30)+6)
 camera(camx,camy)
end

function upd_save(f)
 f.t+=1
 if f.t==60 then
  del(actors, f)
  ssave=nil
 end
end

function make_save(v)
 local f=make_actor(v.x%128,v.y%128)
 f.draw,f.t,f.upd,f.upd_backup = draw_save,0,upd_save,upd_save
 return f
end
-->8
-- solids
function _solid(x,y,s)
 s=s or {0}
 if(type(s) != "table")s={s}
 for i=1,#s do
  if(fget(mget(x/8,y/8),s[i]))return true
 end
 return false
end

function _solid2(x1,y1,x2,y2,s)
 return _solid(x1,y1,s) or
  _solid(x2,y2,s)
end

function _solid4(x1,y1,x2,y2,s)
 return _solid2(x1,y1,x2,y2,s) or
  _solid2(x1,y2,x2,y1,s)
end

function _obj_to_solid(f,ox,oy)
 ox,oy=ox or 0,oy or 0
 local x,y=f.x+f.ox+ox,f.y+f.oy+oy
 return x,y,x+f.w,y+f.h
end

function is_solid(f,ox,oy,s)
 local x1,y1,x2,y2 = _obj_to_solid(f,ox,oy)
 return _solid4(x1,y1,x2,y2,s)
end

function is_solid_left(f,ox,oy,s)
 local x1,y1,x2,y2 = _obj_to_solid(f,ox,oy)
 return _solid2(x1,y1,x1,y2,s)
end

function is_solid_right(f,ox,oy,s)
 local x1,y1,x2,y2 = _obj_to_solid(f,ox,oy)
 return _solid2(x2,y1,x2,y2,s)
end

function is_solid_right_down(f,ox,oy,s)
 local x1,y1,x2,y2 = _obj_to_solid(f,ox,oy)
 return _solid(x2,y2,s)
end

function is_solid_left_down(f,ox,oy,s)
 local x1,y1,x2,y2 = _obj_to_solid(f,ox,oy)
 return _solid(x1,y2,s)
end

function is_solid_down(f,ox,oy,s)
 return is_solid_left_down(f,ox,oy,s) or
  is_solid_right_down(f,ox,oy,s)
end
-->8
-- helpers
function map_to_actor(is_scene)
 local minx,maxx,miny,maxy=0,127,0,63
 if is_scene then
  minx,miny=camx/8,camy/8
  maxx,maxy=minx+15,miny+15
 end
 
 actors = {}
 local v
 -- very first: player
 if player then
  add(actors,player)
--  player.timestop_count=0
--  pal()
--  pal(14,0)
 else
  for y=miny,maxy do
   for x=minx,maxx do
    v=mget(x,y)
    if v==1 then
     player = make_player(x,y)
    end
   end
  end
 end

 -- first-first: edges
 if is_scene then
  local left,right
  for y=miny,maxy do
   for x=minx,maxx do
    if full(x,y) then
     left,right=false,false
     -- left side tile
     if not full(x-1,y) then
      if x-1>=minx then
       make_sspr(105,0,0,4,8,x*8,y*8)
       left=true
      end
     else
      -- inside corner
      if not full(x-1,y+1) then
       if x-1>=minx and y+1<=maxy then
        make_sspr(106,0,4,4,4,x*8,y*8+4)
       end
      end
      if not full(x-1,y-1) then
       if x-1>=minx and y-1>=miny then
        make_sspr(106,0,0,4,4,x*8,y*8)
       end
      end
     end
     -- right side tile
     if not full(x+1,y) then
      if x+1<=maxx then
       make_sspr(105,4,0,4,8,x*8+4,y*8)
       right=true
      end
     else
      -- inside corner
      if not full(x+1,y+1) then
       if x+1<=maxx and y+1<=maxy then
        make_sspr(106,4,4,4,4,x*8+4,y*8+4)
       end
      end
      if not full(x+1,y-1) then
       if x+1<=maxx and y-1>=miny then
        make_sspr(106,4,0,4,4,x*8+4,y*8)
       end
      end
     end
     -- ground tile (top)
     if not full(x,y-1) then
      if y-1>=miny then
        make_sspr(104,0,0,8,4,x*8,y*8)
       -- outside corner
       if right then
        make_sspr(107,4,0,4,4,x*8+4,y*8)
       end
       if left then
        make_sspr(107,0,0,4,4,x*8,y*8)
       end
      end
     end
     -- ceiling tile (bottom)
     if not full(x,y+1) then
      if y+1<=maxy then
        make_sspr(104,0,4,8,4,x*8,y*8+4)
       -- outside corner
       if right then
        make_sspr(107,4,4,4,4,x*8+4,y*8+4)
       end
       if left then
        make_sspr(107,0,4,4,4,x*8,y*8+4)
       end
      end
     end
     
     
--     mset(x,y,7)
--     make_tile(x,y)
--     make_sspr(16,0,0,8,8,x*8,y*8)
    end
   end
  end
 end

 -- first: platforms
 srand"1"
 for y=miny,maxy do
  for x=minx,maxx do
   v=mget(x,y)
   -- tile-floor
   if v==16 and flr(rnd(killer_tile))==0 then
    mset(x,y,flr(rnd(5))+86)
   -- tile-background
   elseif v==32 and flr(rnd(killer_tile))==0 then
    mset(x,y,flr(rnd(5))+81)
   -- player (just delete tile)
   elseif v==1 then
    mset(x,y,0)
   -- torch
   elseif v==48 then
    mset(x,y,32)
    make_torch(x,y)
   -- trampoline (bg)
   elseif v==24 then
    mset(x,y,32)
    make_trampoline(x,y)
   -- trampoline
   elseif v==23 then
    mset(x,y,0)
    make_trampoline(x,y)
   -- 3er-block
   elseif v==42 or v==58 then
    make_3er(x,y,v)
   -- uppers
   elseif v==68 then
    make_upper(x,y)
   -- highjump-powerup
   elseif v==73 then
    mset(x,y,0)
    if player and player.jump_height==1.55 then
    else
     make_highjump_powerup(x,y)
    end
   -- walljump-powerup
   elseif v==74 then
    mset(x,y,0)
    if player and player.can_walljump then
    else
     make_walljump_powerup(x,y)
    end
   -- doublejump-powerup
   elseif v==75 then
    mset(x,y,0)
    if player and player.can_doublejump then
    else
     make_doublejump_powerup(x,y)
    end
   -- timestopper-powerup
   elseif v==76 then
    mset(x,y,0)
    if player and player.can_timestop then
    else
     make_timestopper_powerup(x,y)
    end
   -- key-powerup (yes, really)
   elseif v==101 then
   mset(x,y,0)
   if player and player.has_key then
   else
    make_key_powerup(x,y)
   end
   -- door
   elseif v==100 then
    if player and player.has_key then
     mset(x,y,32)
    end
   -- blocker (new in 1.10)
   elseif v==43 then
    if player then
     if player.has_key then
      mset(x,y,7)
     else
      mset(x,y,32)
     end
    end
   -- enemy-stopper
   elseif v==31 or v==47 then
    mset(x,y,v==31 and 59 or 60)
   -- cannon
   elseif v==78 or v==79 or v==92 or v==93 or v==94 or v==95 or v==108 or v==109 then
    make_cannon(x,y)
   -- checkpoints
   elseif v==112 or v==113 then
    mset(x,y,v==112 and 32 or 0)
    make_checkpoint(x,y)
   -- cup of suffer :)
   elseif v==80 then
    mset(x,y,0)
    make_cup(x,y)
   -- musicstopper
   elseif v==102 then
    mset(x,y,0)
    make_musicstopper(x,y)
   -- performance-test:
   -- 800 actors = 90% cpu
--   elseif y>61 or x>127 then
--    make_trampoline(x,y)
--    make_torch(x,y)
   end
  end
 end

 -- 2nd: enemies 
 for y=miny,maxy do
  for x=minx,maxx do
   v=mget(x,y)
   -- raders
   if v==8 or v==9 or v==29 or v==30 then
    make_rader(x,y,v)
   -- rombies
   elseif v==55 or v==56 or v==25 then
    mset(x,y,v==55 and 0 or 32)
    make_rombie(x,y)
   -- treadmills
   elseif v>=96 and v<= 99 then
    make_laufband(x,y,v==99)
   end
  end
 end
 
 -- move player to last pos 
 del(actors,player)
 add(actors,player)

 -- create stars 
 create_stars()

 -- restore timestop
 if player and player.timestop_count>0 then
  make_stop_time(player.timestop_count)
 end
end

function reduce(ret,value)
 if(ret>0)return max(0,ret-value)
 return min(0,ret+value)
end

function color_dark()
 poke4(0x5f10,0x8382.8180)
 poke4(0x5f14,0x8786.8584)
 poke4(0x5f18,0x8b8a.8988)
 poke4(0x5f1c,0x8f8e.8d8c)
end


function is_touching_player(f)
 return player.x+player.ox+player.w>=f.x+f.ox and player.x+player.ox-1<=f.x+f.ox+f.w and player.y+player.oy+player.h>=f.y+f.oy and player.y+player.oy-1<=f.y+f.oy+f.h
end

function get4rnd()
 return {rnd(8),rnd(8),rnd(8),rnd(8)}
end

function play_music(id,arg1,arg2)
 if id != song then
  prev_song = song
  song=id
  music(song,arg1)
 end
end

function same_screen_as_player(f)
 return camx==flr(f.x/128)*128 and camy==flr(f.y/128)*128
end

function stop_ducking()
 if not is_solid(player,0,-3) then
  player.is_ducking = false
  player.spr_walk = split("1,2,3,4")
 end
end

function is_on_cam(f)
 return f.my_camx == camx and f.my_camy == camy
end

function swap_controls()
 ctl_4,ctl_5=ctl_5,ctl_4
 konami_code[9], konami_code[10] = konami_code[10], konami_code[9]
 if dget(14)==0 then
  dset(14,1)
 else
  dset(14,0)
 end
end

function create_stars()
 for i=1,20 do
  make_star()
 end
end

function full(x,y)
 local v=mget(x,y)
 for f in all(fullcolltable) do
  if f==v then
   return true
  end
 end
 return false
end

-->8
-- menuengine
function menu_init(x,y,t,f)
 menu_timer,menu_x,menu_y,menu_t,menu_finish,menu_pos=0.0,x,y,t,f,0
end

function menu_upd()
 menu_timer=(menu_timer+.05)%2
 if btnp"2" then
  menu_pos-=1
  sfx"10"
  if(menu_pos<0)menu_pos=#menu_t-1
 end
 if btnp"3" then
  menu_pos+=1
  sfx"10"
  if(menu_pos>#menu_t-1)menu_pos=0
 end
 if btnp(ctl_4) then
  menu_finish(menu_pos)
  sfx"18"
 end
end

function menu_draw()
 for y=0,#menu_t-1 do
  print("  "..menu_t[y+1], menu_x,menu_y+y*8)
 end
 spr(0,menu_x+menu_timer,menu_y+menu_pos*8)
end
-->8
-- fadepal by krystman
-- https://www.lexaloffle.com/bbs/?tid=28306
function fadepal(_perc,skipsave)
 local p,kmax,col,j,k=flr(mid(0,_perc,1)*100)
 for j=1,15 do
  col = j
  kmax=(p+(j*1.46))/22
  for k=1,kmax do
   col=dpal[col]
  end
  pal(j,col)
 end
 pal(14,0)
 if(not skipsave)faderval=_perc
end
-->8
-- savestates
function mea_save()
 dset(0, 1)  -- save exist=1
 dset(1,player.checkpoint_x)
 dset(2,player.checkpoint_y)
 dset(3,player.jump_height)
 dset(4,player.can_walljump and 1 or 0)
 dset(5,player.can_doublejump and 1 or 0)
 dset(6,player.can_timestop and 1 or 0)
 dset(7,player.has_key and 1 or 0)
 dset(8,t_frames)
 dset(9,t_secs)
 dset(10,t_mins)
 dset(11,t_hrs)
 dset(12,t_deaths)
 dset(13,killer_tile)
 -- do not use 14=swap-xz!
end

function mea_load()
 if dget"0"==1 then -- save exist?
  player.checkpoint_x,player.x,player.checkpoint_y,player.y,player.jump_height,player.can_walljump,player.can_doublejump,player.can_timestop,player.has_key,t_frames,t_secs,t_mins,t_hrs,t_deaths,killer_tile = dget"1",dget"1",dget"2",dget"2",dget"3",dget"4"==1 and true or false,dget"5"==1 and true or false,dget"6"==1 and true or false,dget"7"==1 and true or false,dget"8",dget"9",dget"10",dget"11",dget"12",dget"13"
 end
end

function mea_del()
 dset(0,0)
 reload()
 reset()
 init_mainmenu()
end