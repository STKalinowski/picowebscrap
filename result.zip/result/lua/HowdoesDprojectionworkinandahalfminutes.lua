--setup/running
function _init()
	srand(1)
	init_palettes()
	points={}
	vpoints={}
	for i=1,5do
		points[i]={}
		points[i].x=cos(i/5)*5
		points[i].y=sin(i/5)*5
		vpoints[i]={}
		vpoints[i].x=points[i].x
		vpoints[i].y=points[i].y
	end
	px=0
	py=0
	pr=.25
	vpr=pr
	l=20
	currentscene=1
	scenestart=0
	currenttext=1
	textstart=0
	scene=scenes[currentscene]
	text=subtitles[currenttext]
end

function t() 
	return time()
end

function _update60()
	while text!=nil and t()-textstart>text.duration do
		currenttext+=1
		textstart=t()
		text=subtitles[currenttext]
	end
	while scene!=nil and t()-scenestart>scene.duration do
		currentscene+=1
		scenestart=t()
		scene=scenes[currentscene]
	end
	if(scene==nil)stop()
end

function _draw()
	cls()
	camera(-64,-64)
	for s in all(scene.backgrounds) do
		s(5)
	end
	scene.draw(t()-scenestart,currentscene)
	for s in all(scene.overlays) do
		s(5)
	end
	if(currentscene>1)rectfill(-64,45,64,64,8)
	if text!=nil then
		local cy=55-#text.lines*3
		for line in all(text.lines) do
			local cx=-line.len*2
			for part in all(line.parts) do
				print(part[1],
					cx,cy,
					part[2] or 2)
				cx+=#part[1]*4
			end
			cy+=6
		end
	end
	print("@VALERADHD",-20,39,1)
end

-->8
--animations

lengths={}

function intro(t)
	s1="how does 3d projection work?"
	s2="(IN 2.5 MINUTES)"
	print(s1,-#s1*2,39-12.5,7)
	print(s2,-#s2*2,39-6.5,6)
end

function introbackground(t)
	local i,s=1,0
	while(i<#introscenes and s+introscenes[i].duration<t*3.5) do
		i+=1
		s+=introscenes[i].duration
		if(introscenes[i].duration==0) introscenes[i].draw()
	end
	for s in all(introscenes[i].backgrounds) do
		s(5)
	end
	if(i!=#introscenes)introscenes[i].draw(t*3.5-s) else introscenes[i].draw(t*2-s/3.5*2)
	for s in all(introscenes[i].overlays) do
		s(5)
	end
end

function delay(t) end

function playersymbol(t)
	pal(palettes[min(flr(t*8),8)])
	print("웃",px*32-4,py*32-3,7)
	pal()
end

function playerdot(t)
	t=easeinovershoot(mid(0,t*2,1))
	local r=lerp(2,0,t)
	circfill(px*32,py*32,r,7)
end

function playerdir(t)
	if t<1 then
		t=easeoutovershoot(mid(0,t*2,1))
		l=lerp(0,20,t)
	end
	if l<4 then
		line(px*8,py*8,px*8+cos(vpr)*l,
			py*8+sin(vpr)*l,14)
	else
		arrow(px*8,py*8,px*8+cos(vpr)*l,
				py*8+sin(vpr)*l,14)
	end
end

tr=nil
sr=0
function playerlook(t)
	if(tr==nil) tr=pr sr=pr
	if t%.55<.02 then
		tr=pr+rnd()-.5
		sr=pr
	else
		t=easeinoutquart(
			mid(0,1,(t%.55)*2)
		)
		pr=lerp(sr,tr,t)
		vpr=pr
	end
end

function points(t)
	for i,p in pairs(vpoints) do
		local t=easeoutovershoot(
			t-i/8
		)
		t=mid(0,t,1)
		local r=lerp(-1,1,t)
		circfill(p.x*8,p.y*8,r,10)
	end
end

function walls(t)
	for i=1,#vpoints do
		local p1x,p1y=
			vpoints[i].x*8,
			vpoints[i].y*8
		local ni=i%#points+1
		local p2x,p2y=
			vpoints[ni].x*8,
			vpoints[ni].y*8
		local cx,cy=
			lerp(p1x,p2x,.5),
			lerp(p1y,p2y,.5)
		local t=easeoutquart(
			mid(0,t,1)
		)
		
		line(cx,cy,
			lerp(cx,p1x,t),
			lerp(cy,p1y,t),
			i
		)
		line(cx,cy,
			lerp(cx,p2x,t),
			lerp(cy,p2y,t),
			i
		)
	end
end

function minimap(t)
	t=easeinoutquart(
		mid(0,1,t*2)
	)
	scale=lerp(128,32,t)
	camera(-scale/2,-scale/2)
	rectfill(-scale/2,-scale/2,scale/2,scale/2,0)
	line(px*scale/16,py*scale/16,
			px*scale/4+cos(pr)*lerp(20,5,t),
			py*scale/4+sin(pr)*lerp(20,5,t),14)
	for i=1,#points do
		local p1x,p1y=
			points[i].x*scale/16,
			points[i].y*scale/16
		local ni=i%#points+1
		local p2x,p2y=
			points[ni].x*scale/16,
			points[ni].y*scale/16
		line(p1x,p1y,p2x,p2y,i)
		circfill(p1x,p1y,t,10)
	end
	rect(-scale/2,-scale/2,scale/2,scale/2,3)
	camera(-64,-64)
end

function rotpoints(t)
	local t=easeinoutquart(
		mid(0,1,t)
	)
	vpr=lerp(pr,.25,t)
	for i=1,#vpoints do
		local px,py=
			points[i].x,
			points[i].y
		vpoints[i].x=px*cos(vpr-pr)-py*sin(vpr-pr)
		vpoints[i].y=px*sin(vpr-pr)+py*cos(vpr-pr)
	end
end

function clipplane(t)
	t=easeoutquart(mid(0,1,t*2))
	dashline(0,0,-64*t,0)
	dashline(0,0,64*t,0)
end

function dist(t)
	local i=0
	for p in all(vpoints) do
		local t=mid(0,t*3-i,1)
		t=easeoutquart(t)
		local px,py=p.x*8,p.y*8
		
		local cy=py/2
		
		local c=p.y>0 and 8 or 12
		
		if t>0 then
			--diagonals
			line(px,0,
				px+2,2*sgn(cy),
				c)
			line(px,py,
				px+2,py-2*sgn(cy),
				c)
			
			--lines to midpoint
			line(
				px+2,2*sgn(cy),
				px+2,lerp(2*sgn(cy),flr(cy),t),
				c)
			line(
				px+2,py-2*sgn(cy),
				px+2,lerp(py-2*sgn(cy),ceil(cy),t),
				c)
			
		end
		
		if t==1 then
			print(-(p.y\.01)/100,px+4,cy-3,c)
		end
		i+=1
	end
end

function clipwalls(t)
	cpoints={}
	for i=1,#vpoints do
		cpoints[i]={}
		cpoints[i].x=vpoints[i].x
		cpoints[i].y=vpoints[i].y
	end
	for i=1,#cpoints do
		local p1x,p1y=
			vpoints[i].x,
			vpoints[i].y
		local ni=i%#points+1
		local p2x,p2y=
			vpoints[ni].x,
			vpoints[ni].y
		
		local dx,dy=
			p2x-p1x,
			p2y-p1y
		
		if p1y<-.01 or p2y<-.01 then
			if p1y>-.01 then
				cpoints[i].x+=dx*(-.01-p1y)/dy
				cpoints[i].y=-.01
			end
			if p2y>-.01 then
				cpoints[ni].x+=dx*(-.01-p2y)/dy
				cpoints[ni].y=-.01
			end
		end
	end
end

function clippedwalls(t)
	t=easeoutquart(mid(0,t,1))
	for i=1,#cpoints do
		local p1x,p1y=
			vpoints[i].x*8,
			vpoints[i].y*8
		local ni=i%#points+1
		local p2x,p2y=
			vpoints[ni].x*8,
			vpoints[ni].y*8
		
		local cx,cy=
			lerp(p1x,cpoints[i].x*8,t),
			lerp(p1y,cpoints[i].y*8,t)
		
		if p1y>-.01 and p2y>-.01 then
			local cx,cy=
				lerp(p1x,p2x,.5),
				lerp(p1y,p2y,.5)
			if t<.98 then
				line(cx,cy,
					lerp(p1x,cx,t),
					lerp(p1y,cy,t),
					i
				)
				line(cx,cy,
					lerp(p2x,cx,t),
					lerp(p2y,cy,t),
					i
				)
			end
		else
			local c2x,c2y=
				lerp(p2x,cpoints[ni].x*8,t),
				lerp(p2y,cpoints[ni].y*8,t)
			line(cx,cy,
			c2x,c2y,
			i)
		end
		circfill(
			cx,cy,
			1,10
		)
	end
end

function scaledown(t)
	t=easeoutquart(mid(0,t,1))
	local scale=8
	for i=1,#cpoints do
		local p1x,p1y=
			vpoints[i].x*scale,
			vpoints[i].y*scale
		local ni=i%#points+1
		local p2x,p2y=
			vpoints[ni].x*scale,
			vpoints[ni].y*scale
		
		local cx,cy=
			scrpoints[i].x*scale,
			scrpoints[i].y*scale
		local c2x,c2y=
			scrpoints[ni].x*scale,
			scrpoints[ni].y*scale
		
		if p1y<-.01 or p2y<-.01 then
			line(cx,cy,
				c2x,c2y,
				i)
		end
		
		circfill(
			cx,cy,
			1,10
		)
	end
end

function prepscreenpoints(t)
	scrpoints={}
	for i=1,#points do
		scrpoints[i]={}
		scrpoints[i].x=cpoints[i].x
		scrpoints[i].y=cpoints[i].y
	end
end

function divx(t)
	t=easeinoutquart(mid(0,t/2,1))
	for i=1,#scrpoints do
		local fx=cpoints[i].x/
			-cpoints[i].y
		
		scrpoints[i].x=
			lerp(cpoints[i].x,fx,t)
	end
end

function scaleup(t)
	t=easeinoutquart(mid(0,t,1))
	local scalex=lerp(8,64,t)
	local scaley=8
	for i=1,#cpoints do
		local p1x,p1y=
			vpoints[i].x,
			vpoints[i].y
		local ni=i%#points+1
		local p2x,p2y=
			vpoints[ni].x,
			vpoints[ni].y
		
		local cx,cy=
			scrpoints[i].x*scalex,
			scrpoints[i].y*scaley
		local c2x,c2y=
			scrpoints[ni].x*scalex,
			scrpoints[ni].y*scaley
		
		if p1y<0 or p2y<0 then
			_line(cx,cy,
				c2x,c2y,
				i)
		end
		
		circfill(
			cx,cy,
			1,10
		)
	end
end

function endplayerclip(t) 
	if(t<.5) circfill(0,0,.1,6)
--	local dt=easeoutovershoot(mid(0,t,1))
--	local dl=lerp(20,0,dt)
--	line(px*8,py*8,px*8+cos(vpr)*dl,
--		py*8+sin(vpr)*dl,9)
	playerdir(.25-t)
	clipplane(.5-t)
end

function projectdown(t)
	t=easeinoutquart(mid(0,t,1))
	local scalex=64
	local scaley=lerp(8,0,t)
	for i=1,#cpoints do
		local p1x,p1y=
			vpoints[i].x,
			vpoints[i].y
		local ni=i%#points+1
		local p2x,p2y=
			vpoints[ni].x,
			vpoints[ni].y
		
		local cx,cy=
			scrpoints[i].x*scalex,
			scrpoints[i].y*scaley
		local c2x,c2y=
			scrpoints[ni].x*scalex,
			scrpoints[ni].y*scaley
		
		if p1y<-.01 or p2y<-.01 then
			_line(cx,cy,
				c2x,c2y,
				i)
		end
		
		circfill(cx,cy,lerp(1,.1,t),10)
	end
end

function extrudepoints(t)
	local scalex=64
	local scaley=0
	for i=1,#cpoints do
		local p1x,p1y=
			cpoints[i].x,
			cpoints[i].y
		local ni=i%#points+1
		local p2x,p2y=
			cpoints[ni].x,
			cpoints[ni].y
		
		local cx,cy=
			scrpoints[i].x*scalex,
			scrpoints[i].y*scaley
		local c2x,c2y=
			scrpoints[ni].x*scalex,
			scrpoints[ni].y*scaley
		
		if p1y<-.01 or p2y<-.01 then
			_line(cx,cy,
				c2x,c2y,
				i)
		end
		
		if cx>-64 and c2x<64 then
			local t1,t2,b1,b2=
				(1/p1y)<<6,(1/p2y)<<6,
				(-1/p1y)<<6,(-1/p2y)<<6
			
			local tp=easeoutovershoot(
				mid(0,t*4,1)
			)
			_line(
				cx,0,
				cx,lerp(0,t1,tp),
				10)
			_line(
				cx,0,
				cx,lerp(0,b1,tp),
				10)
		end
	end
end

function walltops(t)
	local scalex=64
	local scaley=0
	for i=1,#cpoints do
		local p1x,p1y=
			cpoints[i].x,
			cpoints[i].y
		local ni=i%#points+1
		local p2x,p2y=
			cpoints[ni].x,
			cpoints[ni].y
		
		local cx,cy=
			scrpoints[i].x*scalex,
			scrpoints[i].y*scaley
		local c2x,c2y=
			scrpoints[ni].x*scalex,
			scrpoints[ni].y*scaley
		
		if cx>-64 and c2x<64 then
			local t1,t2,b1,b2=
				(1/p1y)<<6,(1/p2y)<<6,
				(-1/p1y)<<6,(-1/p2y)<<6
			
			local cenx=lerp(cx,c2x,.5)
			local tt=easeinoutquart(
				mid(0,(t)*2,1)
			)
			_line(cx,t1,
				lerp(cx,cenx,tt),
				lerp(t1,t2,tt/2),
				10)
			_line(c2x,t2,
				lerp(c2x,cenx,tt),
				lerp(t2,t1,tt/2),
				10)
			_line(cx,b1,
				lerp(cx,cenx,tt),
				lerp(b1,b2,tt/2),
				10)
			_line(c2x,b2,
				lerp(c2x,cenx,tt),
				lerp(b2,b1,tt/2),
				10)
		end
	end
end

function drawfloorsky(t)
	rectfill(
		-64,easeoutquart(mid(0,1,t))*64,
		64,0,13)
	rectfill(-64,0,
		64,-easeoutquart(mid(0,1,t))*64,
		6)
end

function drawfinal(t)
	rectfill(
		-64,64,
		64,0,13)
	rectfill(-64,0,
		64,-64,
		6)
	for i=1,#points do
		local ni=i%#points+1
		drawwall(points[ni],points[i],i,t)
	end
	local tw=mid(0,1,t-1)
	if tw<1 then
		walltops(1-tw)
		extrudepoints(1-tw)
	end
end

function introdrawfinal(t)
	rectfill(
		-64,64,
		64,0,13)
	rectfill(-64,0,
		64,-64,
		6)
	for i=1,#points do
		local ni=i%#points+1
		drawwall(points[ni],points[i],i,t)
	end
end

function drawwall(p1,p2,wc,timer)
	local tx1,ty1,tx2,ty2=
		p1.x-px, p1.y-py,
		p2.x-px, p2.y-py
		
	local c,s=cos(pr),sin(pr)
	local rx1,ry1,rx2,ry2=
		c*ty1-s*tx1,
		s*ty1+c*tx1,
		c*ty2-s*tx2,
		s*ty2+c*tx2
	
	if ry1>0 or ry2>0 then 
		if ry1<0.05 then
			local slope=
				(ry2-ry1)/(rx2-rx1)
			rx1=rx2-((ry2-.05)/slope)
			ry1=0.05
		end
		if ry2<0.05 then
			local slope=
				(ry2-ry1)/(rx2-rx1)
			rx2=rx1-((ry1-.05)/slope)
			ry2=0.05
		end
		
		local t1,t2=(1/ry1)<<6,(1/ry2)<<6
		local sx1,sx2=
			(rx1/ry1)<<6,(rx2/ry2)<<6
		
		local startx,endx=
			flr(mid(-64,sx1,64)),
			mid(-64,sx2,64)
		
		for i=startx,endx do
			local t=(i-sx1)/(sx2-sx1)
			local b=lerp(t1,t2,t)
			
			local bot=b
			local timer=mid(0,1,
				timer-(64-abs(i))/64
			)
			
			timer=easeoutquart(timer)
			
			bot=lerp(0,bot,timer)
			
			rectfill(i,bot,i,-bot,wc)
		end
	end
end
-->8
--compositing
--set of different animation
--functions, with their 
--duration and any other
--scenes to draw before them
scenes={
	{
		draw=introbackground,
		duration=6,
		backgrounds={},
		overlays={intro}
	},
	{ --player explanation
		draw=delay,
		duration=.5,
		backgrounds={},
		overlays={}
	},
	{
		draw=playersymbol,
		duration=3,
		backgrounds={},
		overlays={},
	},
	{
		draw=delay,
		duration=.5,
		backgrounds={playersymbol},
		overlays={},
	},--end player explanation
	{ --player dot
		draw=delay,
		duration=1.5,
		backgrounds={playersymbol},
		overlays={},
	},
	{ 
		draw=playerdot,
		duration=6,
		backgrounds={},
		overlays={}
	},
	{ 
		draw=delay,
		duration=1.5,
		backgrounds={playerdot}
	}, --end player dot
	{ --delay for reading direction text
		draw=delay,
		duration=2,
		backgrounds={playerdot}
	},
	{
		draw=playerdir,
		duration=1.25,
		backgrounds={},
		overlays={playerdot}
	},
	{ 
		draw=playerlook,
		duration=2.75,
		backgrounds={playerdir},
		overlays={playerdot}
	},
	{
		draw=delay,
		duration=1.5,
		backgrounds={playerdir,playerdot}
	}, --finish direction
	{ --barren text
		draw=playerlook,
		duration=2.75,
		backgrounds={playerdir,playerdot}
	}, 
	{
		draw=delay,
		duration=2.05,
		backgrounds={playerdir,playerdot}
	},
	{
		draw=delay,
		duration=1.7,
		backgrounds={playerdir,playerdot}
	},--end barren text
	{ --points
		draw=delay,
		duration=2,
		backgrounds={playerdir,playerdot}
	},
	{
		draw=points,
		duration=5,
		backgrounds={playerdir,playerdot},
		overlays={}
	},
	{ 
		draw=delay,
		duration=.5,
		backgrounds={playerdir,playerdot,points},
		overlays={}
	},--end points
	{ --walls
		draw=delay,
		duration=3,
		backgrounds={playerdir,playerdot,points},
		overlays={}
	},
	{
		draw=walls,
		duration=1,
		backgrounds={playerdir,playerdot},
		overlays={points}
	},
	{
		draw=delay,
		duration=3.5,
		backgrounds={playerdir,playerdot,walls,points}
	},--end walls
	{ --explanation
		draw=delay,
		duration=6,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={}
	},--end explanation
	{ --minimap
		draw=delay,
		duration=2,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={}
	},
	{
		draw=minimap,
		duration=2,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={}
	},
	{ 
		draw=delay,
		duration=2,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={minimap}
	}, --end minimap
	{ --rotation upward
		draw=delay,
		duration=2,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={minimap}
	},
	{
		draw=rotpoints,
		duration=1,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={minimap}
	},
	{ 
		draw=delay,
		duration=4.5,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={minimap}
	}, --end rotation upward
	{ --clip plane
		draw=delay,
		duration=5,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={minimap}
	},
	{
		draw=clipplane,
		duration=.5,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={minimap}
	},
	{
		draw=delay,
		duration=7,
		backgrounds={playerdir,playerdot,walls,points,clipplane},
		overlays={minimap}
	}, --end clip plane
	{ --distance
		draw=delay,
		duration=3.5,
		backgrounds={playerdir,playerdot,walls,points,clipplane},
		overlays={minimap}
	},
	{
		draw=dist,
		duration=3,
		backgrounds={playerdir,playerdot,walls,points,clipplane},
		overlays={minimap}
	},
	{
		draw=delay,
		duration=3.5,
		backgrounds={playerdir,playerdot,walls,points,clipplane},
		overlays={dist,minimap}
	}, --end distance
	{ --clipping walls
		draw=clipwalls,
		duration=7,
		backgrounds={playerdir,playerdot,walls,points,clipplane},
		overlays={minimap}
	},
	{
		draw=clippedwalls,
		duration=2,
		backgrounds={playerdir,playerdot},
		overlays={clipplane,minimap}
	},
	{ 
		draw=delay,
		duration=3,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={clippedwalls,minimap}
	}, --end clipping walls
	{ --divx
		draw=prepscreenpoints,
		duration=7.5,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={clippedwalls,minimap}
	},
	{
		draw=divx,
		duration=2,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={scaledown,minimap}
	},
	{ 
		draw=delay,
		duration=3.5,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={scaledown,minimap}
	}, --end divx
	{--scale up
		draw=delay,
		duration=5.5,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={scaledown,minimap}
	},
	{
		draw=scaleup,
		duration=2,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={minimap}
	},--end scale up
	{--project down
		draw=delay,
		duration=2,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={scaleup,minimap}
	},
	{
		draw=endplayerclip,
		duration=1,
		backgrounds={},
		overlays={scaleup,minimap}
	},
	{ 
		draw=projectdown,
		duration=1,
		backgrounds={},
		overlays={minimap}
	},
	{
		draw=delay,
		duration=2,
		backgrounds={projectdown},
		overlays={minimap}	
	},--end project down
	{ --extrude points
		draw=delay,
		duration=3,
		backgrounds={projectdown},
		overlays={minimap}
	},
	{
		draw=extrudepoints,
		duration=2,
		background={},
		overlays={minimap}
	}, --end extrude points
	{--draw tops
		draw=delay,
		duration=2.5,
		background={},
		overlays={extrudepoints,minimap}
	},
	{
		draw=walltops,
		duration=2,
		background={},
		overlays={extrudepoints,minimap}
	},--end draw tops
	{--fill
		draw=drawfloorsky,
		duration=1,
		backgrounds={},
		overlays={extrudepoints,walltops,minimap}	
	},
	{
		draw=drawfinal,
		duration=2,
		backgrounds={},
		overlays={minimap}
	},
	{
		draw=playerlook,
		duration=5,
		backgrounds={drawfinal},
		overlays={minimap}
	},--done!
}

introscenes={
	{
		draw=playersymbol,
		duration=.25,
		backgrounds={},
		overlays={},
	},
	{ 
		draw=playerdot,
		duration=.5,
		backgrounds={},
		overlays={}
	},
	{
		draw=playerdir,
		duration=.5,
		backgrounds={},
		overlays={playerdot}
	},
	{
		draw=points,
		duration=1,
		backgrounds={playerdir,playerdot},
		overlays={}
	},
	{
		draw=walls,
		duration=1,
		backgrounds={playerdir,playerdot},
		overlays={points}
	},
	{
		draw=minimap,
		duration=.5,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={}
	},
	{
		draw=rotpoints,
		duration=1,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={minimap}
	},
	{
		draw=clipplane,
		duration=.5,
		backgrounds={playerdir,playerdot,walls,points},
		overlays={minimap}
	},
	{ --clipping walls
		draw=clipwalls,
		duration=0,
		backgrounds={playerdir,playerdot,walls,points,clipplane},
		overlays={minimap}
	},
	{
		draw=clippedwalls,
		duration=1,
		backgrounds={playerdir,playerdot},
		overlays={clipplane,minimap}
	},
	{ --divx
		draw=prepscreenpoints,
		duration=0,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={clippedwalls,minimap}
	},
	{
		draw=divx,
		duration=2,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={scaledown,minimap}
	},
	{
		draw=scaleup,
		duration=1,
		backgrounds={playerdir,playerdot,clipplane},
		overlays={minimap}
	},--end scale up
	{
		draw=endplayerclip,
		duration=1,
		backgrounds={},
		overlays={scaleup,minimap}
	},
	{ 
		draw=projectdown,
		duration=1,
		backgrounds={},
		overlays={minimap}
	},
	{
		draw=drawfloorsky,
		duration=2,
		backgrounds={},
		overlays={minimap}	
	},
	{
		draw=introdrawfinal,
		duration=3,
		backgrounds={},
		overlays={minimap}
	}
}

-->8
--text
--monster of a function that splits a list of text parts
--with an optional color parameter into a set of lines
--cut at the 32 character mark (or before), with the same 
--color parameters, as well as the length of each line.
function splitlines(...)
	args={...}
	lines={{len=0,parts={}}}
	currline=1
	for i=1,#args do
		if(type(args[i])!="string") goto done
		local part=args[i]
		local col=args[i+1]
		if not col or type(col)!="number" then
			col=2
		end
		local words=split(part," ",false)
		local r=""
		local space=""
		for w in all(words) do
			local l=lines[currline]
			if l.len+#r+#w+#space<32 then
				r..=space
				r..=w
				space=" "
			else
				add(l.parts,{r,col})
				l.len+=#r
				r=w..space
				space=""
				add(lines,{len=0,parts={}})
				currline+=1
			end
		end
		add(lines[currline].parts,{r,col})
		lines[currline].len+=#r
		r=""
		::done::
	end
	return lines
end

subtitles={
	{
		lines=splitlines(),
		duration=6,
	},
	{
		lines=splitlines("first we need a ","player",7,"."),
		duration=4
	},
	{
		lines=splitlines(
			"we just need to know about their ",
			"position",7,
			", so we'll just place a ",
			"dot",7,
			"."
		),
		duration=9
	},
	{
		lines=splitlines(
			"we also need to know about their ",
			"direction",14,
			", so let's put an ",
			"arrow ",14,
			"to show that."
		),
		duration=7.5
	},
	{
		lines=splitlines(
			"this area is looking a little barren, let's add some"," scenery.",15
		),
		duration=6
	},
	{
		lines=splitlines(
			"first, let's add some ",
			"points",10,
			". these will be the ",
			"corners",10,
			" of our room."
		),
		duration=7.5
	},
	{
		lines=splitlines(
			"next, let's connect these points with ",
			"lines",4,
			". these will represent our ",
			"walls",4,
			"."
		),
		duration=7.5
	},
	{
		lines=splitlines(
			"now we have a ",
			"player",7,
			", their ",
			"direction",14,
			", and some ",
			"scenery",15,
			". let's start making it 3d."
		),
		duration=6
	},
	{
		lines=splitlines(
			"let's remember this ",
			"image",11,
			". it will be in the ",
			"top left",11,
			" corner."
		),
		duration=6
	},
	{
		lines=splitlines(
			"first, let's rotate the ",
			"world",15,
			" so that the ",
			"player",7,
			" is ",
			"facing",14,
			" upwards."
		),
		duration=7.5
	},
	{
		lines=splitlines(
			"now we will draw the ",
			"camera plane,",6,
			"a line perpendicular to the ",
			"look direction",14,
			"."
		),
		duration=7.5
	},
	{
		lines=splitlines(
			"because our ",
			"look direction",14,
			" is straight up, it's just a horizontal line."
		),
		duration=5
	},
	{
		lines=splitlines(
			"the next thing we need is the",
			" distance ",12,
			"of each point to the ",
			"camera  plane.",6
		),
		duration=6.5
	},
	{
		lines=splitlines(
			"because we rotated everything, this is just the ",
			"y value",12,
			" of each ",
			"point",10,
			"."
		),
		duration=4.75
	},
	{
		lines=splitlines(
			"negative values",9,
			" will mess up our math later, so let's fix those."
		),
		duration=4.5
	},
	{
		lines=splitlines(
			"we need to cut any ",
			"walls",4,
			" going through the ",
			"camera plane,",6,
			"and remove any behind it."
		),
		duration=7.5
	},
	{
		lines=splitlines(
			"in a perspective projection, things ",
			"close to us ",12,
			"get larger, and things ",
			"further away",12,
			" shrink."
		),
		duration=6
	},
	{
		lines=splitlines(
			"we can emulate this by dividing the x values of the ",
			"points",10,
			" by their ","distance",12," from the camera."
		),
		duration=7.5
	},
	{
		lines=splitlines(
			"this looks odd, but we're almost done. the hard part is over."
		),
		duration=3
	},
	{
		lines=splitlines(
			"next we need to scale up the x values to fit the screen properly."
		),
		duration=4.5
	},
	{
		lines=splitlines(
			"all of the main math is done. now we bring these lines down to the center of the screen,"
		),
		duration=6
	},
	{
		lines=splitlines(
			"extrude the ","points",10," up based on their ",
			"distance",12,
			" from the camera,"
		),
		duration=5
	},
	{
		lines=splitlines(
			"draw lines for the tops of the ",
			"walls",4
		),
		duration=4.5
	},
	{
		lines=splitlines("and fill!"),
		duration=20
	}
}
-->8
--subpixel drawing functions
_circ=circ
function circ(x,y,r,c)
	x=x or 0 y=y or 0 r=r or 4
	c=c or 6
	local p=6.3*r
	for i=-.001,.26,1/p do
		pset(x+cos(i)*r,y+sin(i)*r,c)
		pset(x-cos(i)*r,y+sin(i)*r,c)
		pset(x+cos(i)*r,y-sin(i)*r,c)
		pset(x-cos(i)*r,y-sin(i)*r,c)
	end
end

_circfill=circfill
function circfill(x,y,r,c)
	x=x or 0 y=y or 0
	r=r or 4
	c=c or 6
	local p=6.3*r
	for i=-.001,.25,1/p do
		rect(x+cos(i)*r,y+sin(i)*r,x-cos(i)*r,y+sin(i)*r,c)
		rect(x+cos(i)*r,y-sin(i)*r,x-cos(i)*r,y-sin(i)*r,c)
	end
end

_line=line
function line(x1,y1,x2,y2,c)
	x1=x1 or 0 y1=y1 or 0
	x2=x2 or 0 y2=y2 or 0 
	c=c or 6
	local dx,dy=x2-x1,y2-y1
	local llen=max(abs(dx),abs(dy))
	local sx,sy=dx/llen,dy/llen
	local cx,cy=x1,y1
	for i=0,max(abs(dx),abs(dy)) do
		pset(cx,cy,c)
		cx+=sx cy+=sy
	end
end

function dashline(x1,y1,x2,y2,c)
	x1=x1 or 0 y1=y1 or 0 
	x2=x2 or 0 y2=y2 or 0 
	c=c or 6
	local dx,dy=x2-x1,y2-y1
	local llen=max(abs(dx),abs(dy))
	local sx,sy=dx/llen,dy/llen
	local cx,cy=x1,y1
	for i=0,max(abs(dx),abs(dy)) do
		local t=cx/sx
		if(abs(dy)>abs(dx))t=cy/sy
		if(t%5<2.5)pset(cx,cy,c)
		cx+=sx cy+=sy
	end
end

function arrow(x1,y1,x2,y2,c)
	line(x1,y1,x2,y2,c)
	local d=atan2(x1-x2,y1-y2)
	line(x2,y2,x2+cos(d+.125)*4,y2+sin(d+.125)*4,c)
	line(x2,y2,x2+cos(d-.125)*4,y2+sin(d-.125)*4,c)
end
-->8
--easing functions
--taken from https://www.lexaloffle.com/bbs/?tid=40577
function easeoutovershoot(t)
	t-=1
	return 1+2.7*t*t*t+1.7*t*t
end

function easeinovershoot(t)
	return 2.7*t*t*t-1.7*t*t
end

function easeinquart(t)
	return t*t*t*t
end

function easeoutquart(t)
	t-=1
	return 1-t*t*t*t
end

function easeinoutquart(t)
	if t<.5 then
		return 8*t*t*t*t
	else
		t-=1
		return (1-8*t*t*t*t)
	end
end

function lerp(a,b,t)
	return a+(b-a)*t
end

-->8
--utilities
function init_palettes()
	palettes={}
	for i=0,7do
		palettes[i]={}
		for j=0,15 do
			palettes[i][j]=sget(j,7-i)
		end
	end
end