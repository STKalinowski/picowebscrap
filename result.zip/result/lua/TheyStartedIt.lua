--they started it
--(c) fistfulofsquid

debug={}

p1 = {}
lrs = {}
als = {}
exp = {}
smoke = {}
shake = 0
stars = {}
powerups = {}
wave = 0
pu_drop_timer=1600
xlife_timer=0

max_wave=20
max_lives=5
max_missiles=5

flash = nil
ui_y = 0

wt_max=200
wave_timer=-1
wave_score=0
warp=0

bonus=0

titles = {}
scrn = {}

function _init()
	create_blobs()
	create_stars()
	show_titles()
end

-------------------------
-- title
-------------------------

function rnd_blob(b)
		a=rnd(1000)/1000
		r=100+rnd(40)
		b.x=cos(a)*r+64
		b.y=sin(a)*r+64
		b.r=rnd(10)+6
		spd=(rnd(9)+2)/30
		b.dx=-cos(a)*spd
		b.dy=-sin(a)*spd
		b.col=1
		return b
end

function create_blobs()
	titles.blobs={}
	for i=1,160 do
		add(titles.blobs,rnd_blob({}))
	end
end

function show_titles()
	titles.ty=-60
	titles.oy=150
	scrn.update=update_titles
	scrn.draw=draw_titles
end

function hide_titles()
	update_stars()
	update_blobs(0.96,false)
	
	if titles.ty>-59 then
		titles.ty+=(-60-titles.ty)*0.06
		titles.oy+=(150-titles.oy)*0.06
	else
		new_game()
	end
end

function update_titles()
	update_stars()
	
	if titles.ty<30 then
		titles.ty+=(30-titles.ty)*0.06
	end
	
	if titles.oy>90 then
		titles.oy+=(90-titles.oy)*0.06
	end
	
	if btnp(5) then
		scrn.update=hide_titles
	end

	update_blobs(0.99,true)
end

function update_blobs(s,reset)
	for b in all(titles.blobs) do
		b.x+=b.dx
		b.y+=b.dy
		
		if b.x+b.r>0 and b.x-b.r<127 and b.y+b.r>0 and b.y-b.r<127 then
			b.r*=s
		end
		
		if b.r<1.5 and reset then rnd_blob(b) end
	end
end

function draw_titles()
 rectfill(0,0,127,127,0)
	draw_stars()
	
	for b in all(titles.blobs) do
		if b.r > 1.1 then
			circfill(b.x,b.y,b.r,b.col)
		end
	end

 waggle(64,2,titles.ty,16,4)
 
 draw_pressmsg("to play",35,titles.oy)
end

function draw_pressmsg(s,x,y)
	c=(sin(time()*0.8)+1)*7+1
	print("press ❎ "..s,x,y,c)
	print("press    "..s,x,y,14)
end

function waggle(s,x,y,sx,sy)
	local t = time()*0.8
	local cols={1,2,0,1,2,0}
	
	for i=1,7 do
		c=cols[i]
		rx = x+cos(t*0.4)*4
		ry = y+sin(t*0.4)*6
		sprc(s,rx,ry,sx,sy,c)
		t+=0.2
	end

	spr(s,rx,ry,sx,sy)
end

-- util

function rndi(n)
	return flr(rnd(n))
end

function dbg(s)
	add(debug,s)
end

function dbg_draw()
	y=0
	for s in all(debug) do
		print(s,4,y,7)
		y+=6
	end
end

function palc(c)
	for i=1,15 do pal(i,c) end
end

function palr()
	for i=1,15 do pal(i,i) end
end

function sprc(s,x,y,sx,sy,c)
	palc(c)
	spr(s,x,y,sx,sy)
	palr()
end

function printc(s,y,c)
	x=64-(#s*0.5)*4-1
	print(s,x,y,c)
end

-------------------------
-- game
-------------------------

function create_stars()
	for i=1,20 do
		local s = {}
		s.x = rnd(127)
		s.y = rnd(127)
		s.dy = 0.5 + (rnd(100) * 0.01)
		if s.dy>1.45 then
			s.dy=4
		end
		if s.dy < 1.2 then
			s.col=1
 	else
 		s.col=7
		end
		add(stars,s)
	end
end

function new_game()
	scrn.update=update_game
	scrn.draw=draw_game

 shake=0
	ui_y=-20
 
	p1.score=0
	p1.lives=4
	p1.dead=false
	p1.dead_timer=-1
	p1.missiles=3
	p1.twin_lasers=false
	p1.max_shields=2

	new_life(p1)
	p1.y=1000
	
	for a in all(als) do del(als,a) end

	wave=0
	warp_speed()
end

function create_anim(s)
	anim={}
	anim.s=s
	anim.t=0
	anim.d=10+rndi(4)
	anim.i=1
	return anim
end

function next_wave()
	wave+=1
	bonus=100
	wave_score=0

	if (wave>=5) then
		p1.twin_lasers=true
	end
	
	n=128+((wave-1)%max_wave)

	x=(n%16)*8
	y=flr(n/16)*8
	i=1
	for sy=0,7 do
		for sx=0,7 do
			c=sget(x+sx,y+sy)
			if c>0 then
				a={}
				a.id=i
				a.hurt=0
				a.x=sx*7*2+11
				a.ty=sy*7*2+20
			
				if c==11 then
					a.sprite=3
					a.shield=1
					a.anim=create_anim({3,19})
					a.update=au_zigzag
					a.fire_time=rnd(80)*10
					a.scr=50

				elseif c==8 then
					a.sprite=4
					a.shield=2
					a.anim=create_anim({4,20})
					a.update=au_zigzag
					a.kill=ak_drop_bomb
					a.fire_time=rnd(80)*10
					a.scr=100
					
				elseif c==12 then
					a.sprite=8
					a.shield=4
					a.anim=create_anim({8,24})
					a.update=au_lissajous
					a.t=(a.ty-60)/2	--used for offset later
					au_lissajous(a)
					a.ty=a.y
					a.scr=150

				elseif c==14 then
					a.sprite=11
					a.shield=6
					a.state=0
					a.update=au_pinkeye
					a.scr=200
					
				elseif c==10 then
					a.sprite=21
					a.shield=8
					a.update=au_golden
					a.fire_time=rnd(80)*10
					a.scr=250
				end

				a.y=a.ty-128-abs(a.x-64)*6-((128-a.ty))
			
				add(als,a)
				i+=1
			end
		end
	end
end

function create_laser(p,x,s)
 local l = {}
	l.y = p.y + 8
	l.x = x + rnd(2) - 1
	l.sprite = s
	add(lrs, l)
end

function fire_laser(p)
 if p.f_elapsed == 0 then
		if p.twin_lasers then
			create_laser(p,p.x-2,16)
			create_laser(p,p.x+2,16)
		else
			create_laser(p,p.x,2)
		end
		
		sfx(0)
		p.f_elapsed = 1
	end
end

function nearest_alien(y,ymax)
	local r=nil
	local ymin=0
	for a in all(als) do
		if a.y>ymin and a.y<ymax then
			ymax=a.y
			r=a
		end
	end
	return r
end

function anim_update(a)
	a.t+=1
	if a.t>a.d then
		a.t=0
		a.i+=1
		if a.i>#a.s then a.i=1 end
	end
	return a.s[a.i]
end

function create_missile(x,y,trg)
  local l = {}
		l.x = x
		l.y = y
		l.target=trg
		if trg.x>x then
			l.ang=0
		else
			l.ang=0.5
		end
		l.spd = 0.4 + rnd(5)/10
		l.timer=0
		l.sprite=5
		l.update=upd_missile
		
		sfx(8)
		
		return l
end

function fire_missile(p)
 if p.missiles > 0 then
 	p.missiles-=1
 	
		x = p.x + 3
		y = p.y + 4
		
		trg = nearest_alien(p.y,80)
		if trg==nil then
			trg={}
			trg.x=40+rnd(48)
			trg.y=40+rnd(30)
		end

		l=create_missile(x,y,trg)
		l.tcol=2
		l.explode=missile_explode
		if p.dx>0 then
			l.ang=0
		elseif p.dx<0 then
			l.ang=0.5
		end
		
		add(lrs, l)
	end
end

function upd_missile(m)
	dx=m.target.x-m.x
	dy=m.target.y-m.y
	tang=atan2(dx,dy)
	
	dist=sqrt(dx*dx+dy*dy)
	
	da=tang-m.ang
	if da!=0 then	
		if dist<10 then
			turn=0.03
		elseif dist<50 then
			turn=0.01
		else
			turn=0.005
		end
		
		av=sgn(da)*turn

		if da>0.5 then av=-av end
	
		m.ang+=av
		if m.ang<0 then m.ang+=1 end
		if m.ang>1 then m.ang-=1 end
	end

	m.x+=cos(m.ang)*m.spd
	m.y+=sin(m.ang)*m.spd
	if m.spd<2 then m.spd+=0.1 end
	
	missile_trail(m)
	
	m.timer+=1
	if m.timer>300 then
	 explode(m.x,m.y,4+rnd(4),10)
  add_smoke(m.x,m.y,5)
  shake=10
  del(lrs,m)
		sfx(2)
	end
end

function missile_explode(m)
	flash_screen(10,10)
 explode(m.x,m.y,20,14)
 explode(m.x+10,m.y+10,10,7)
 explode(m.x-5,m.y+5,10,7)
 add_smoke(m.x,m.y,5,14)
 shake=20
	sfx(2)

	for a in all(als) do
	 dx=m.x-a.x
	 dy=m.y-a.y
		if (dx*dx+dy*dy)<1000 then
			kill_alien(a,3)
		end
	end
end

function drop_bomb(a)
 local b = {}
 b.x=a.x
 b.y=a.y
 b.sprite=10
 b.update=au_bomb
 b.shield=1
 b.hurt=0
 b.scr=10
	add(als,b)
	sfx(3,3)
end

function trail(p)
 if rnd(4)>2	then
		local s = {}
		s.x = p1.x+4
		s.y = p1.y+12
		if warp>0 then
 		s.ttl = 20
 		s.col = 8
			s.dx = (rndi(5) - 2)*0.2
			s.dy = (2 + rnd(3)) * 0.2
 	else
 		s.ttl = 15
 		s.col = 2
			s.dx = (rndi(3) - 1)*0.3
			s.dy = (1 + rnd(4)) * 0.1
 	end
		add(smoke,s)
	end
end

function bomb_trail(b,col,dy,ttl)
 if rnd(4)>2	then
		local s = {}
		s.x = b.x+4
		s.y = b.y+3
		s.dx = (rndi(3) - 1)*0.3
		s.dy = -(1 + rnd(4)) * dy
		s.ttl = 15
		s.col = col
		add(smoke,s)
	end
end

function missile_trail(m)
 if rnd(4)>1	then
		local s = {}
		s.x = m.x+4
		s.y = m.y+4
		
		ang=m.ang+((rnd(10)-5)/20)
		s.dx = -cos(ang) * 0.1
		s.dy = -sin(ang) * 0.1
		s.ttl = 20
		s.col = m.tcol
		add(smoke,s)
	end
end

function warp_speed()
 wave_timer=wt_max
	sfx(4,3)
end

function new_life(p)
	p.lives-=1
	p.dead=false
	p.x=60
	p.y=140
	p.dx=0
	p.f_elapsed=0
	p.inv=200

	p.shield=p.max_shields
	p.shield_timer=0
end

function can_hit_ship(p)
	return p.inv<=0 and not p.dead
end

function calc_bonus()
 s=wave_score*(bonus*0.01)
	return flr(s*0.1)*5
end

function update_game()
	if not p1.dead then
	 trail(p1)

		pty=102
		if p1.y>pty then
			p1.y -= (p1.y - pty)*0.1
			if p1.y<pty+1 then p1.y=pty end
			
		else
			p1.dx*=0.82
			
			if btn(1) and p1.dx < 4 then p1.dx+=0.5 end
			if btn(0) and p1.dx > -4 then p1.dx-=0.5 end
			if btn(5) then fire_laser(p1) end
			if btnp(4) then fire_missile(p1) end

			p1.x+=p1.dx
			if p1.x>120 then
				p1.x=120
			elseif p1.x<0 then 
				p1.x=0
			end
		
		 if p1.f_elapsed > 0 then
 			p1.f_elapsed+=1
 			if p1.f_elapsed>10 then
 				p1.f_elapsed=0
 			end
 		end
		end
		
		if p1.shield_timer>0 then
			p1.shield_timer-=1
		end
		
		if p1.inv>0 then p1.inv-=1 end
 else
 	if p1.dead_timer == 0 then
 		if p1.lives>0 then
	 		new_life(p1)
	 	else
	 		game_over()
	 	end
 	else
 		p1.dead_timer-=1
 		if p1.dead_timer > 120 and rnd(15)<2 then
 		 ex=p1.x+rnd(8)
 		 ey=p1.y+rnd(8)
    explode(ex,ey,4+rnd(4),10)
    add_smoke(ex,ey,5)
    shake=p1.dead_timer-120
 		end
 	end
	end

 for l in all(lrs) do
 	if l.update!=nil then
 		l.update(l)
 	else
			l.y-=6
			if l.y < 0 then
			 ey=l.y + rnd(20)
			 explode(l.x+4,ey,5,9)
			 add_smoke(l.x+4,ey-2,2)
				del(lrs,l)
			end
 	end
	end

 for pu in all(powerups) do
 	if collide(pu.x, pu.y, 8, 8, p1.x, p1.y, 8, 16) then
 		pu.action(pu)
 		del(powerups,pu)
 		flash_screen(10,14)
 		sfx(9)
 		explode(pu.x+4,pu.y+4,15,7)
 	else
	 	pu.y+=0.7
	 	pu.x+=sin(pu.y*0.1)
	 	bomb_trail(pu,4,0.4,25)

	 	if pu.y>128 then
	 		del(powerups,pu)
	 	end
	 end
 end

	if #als==0 and wave_timer<0 then
		warp_speed()
	end
	
	if wave_timer==0 then	
		sfx(-1,3)
		next_wave()

		wave_timer=-1
		warp=0
		
	elseif wave_timer>0 then
 	wave_timer-=1
 	if wave_timer<40 then
 		warp-=0.5
 	elseif wave_timer>wt_max-40 then
 		warp+=0.5
 	end

		if bonus>0 then
			if wave_timer%2==0 then
			
				pre=calc_bonus()
				bonus-=2
				if bonus<0 then bonus=0 end
				post=calc_bonus()
				
				add_score(pre-post)
			end
		end
	end
 
 can_hit=can_hit_ship(p1)
 
	for a in all(als) do
		if a.anim!=nil then
			a.sprite=anim_update(a.anim)
		end

		coly=p1.y+4
		if p1.shield>0 then coly-=10 end
			
		if a.ty!=nil then
		 bomb_trail(a,1,0.1,20)

			dy=a.ty-a.y
			a.y+=dy*0.05
			if a.y>=a.ty-1 then
				a.y=a.ty
				a.ty=nil
			end
		
		else
			a.update(a)
			if a.y>128 then
				del(als,a)
			elseif can_hit and collide(a.x, a.y, 8, 8, p1.x, coly, 8, 12) then
				kill_alien(a,1)
				ship_hit(p1)
			end
		end
		
		for l in all(lrs) do
			if collide(l.x + 4, l.y, 2, 2, a.x, a.y, 8, 8) then
				if l.explode!=nil then
					l.explode(l)
				else
					kill_alien(a,1)
				end
					
				del(lrs,l)
			end
		end
			
		if a.hurt>0 then a.hurt-=1 end
	end
	
	for e in all(exp) do
		e.ttl-=1
		if (e.ttl <= 0) then
			del(exp,e) 
		end
	end

	for s in all(smoke) do
		s.ttl-=1
		s.x+=s.dx
		s.y+=s.dy
		if (s.ttl <= 0) then
			del(smoke,s)
		end
	end
	
	if pu_drop_timer>0 then
		pu_drop_timer-=1
	end

	if xlife_timer>0 then
		xlife_timer-=1
	end
	
	if warp==0 and bonus>0 then
		bonus-=0.1
		if bonus<0 then bonus=0 end
	end
	
	update_stars()
end

function update_stars()
	for s in all(stars) do
		s.y+=s.dy + (warp*0.3)
		if s.y > 127 then
			s.y=-10
			s.x=rnd(127)
		end
	end
end

function game_over()
	scrn.update=update_gameover
	scrn.draw=draw_gameover
end

function update_gameover()
	update_game()
	if btnp(5) then
		show_titles()
	end
end

function draw_gameover()
	draw_game()
	waggle(32,24,30,10,2)
	printc("the galaxy is safe once more..",60,12)
 draw_pressmsg("in shame",33,68)
 
	printc("(c) joe trewin",100,7)
	printc("http://fistfulofsquid.com",108,7)
	printc("@joeyspacerocks",116,7)
end

function ship_hit(p)
	if p.shield>0 then
	 sfx(10)
	 p.shield-=1
	 p.shield_timer=10
	 flash_screen(5,8)
	 
	else
	 explode(p.x+4,p.y,16,7)
	 explode(p.x+4,p.y,9,10)
	 add_smoke(p.x+4,p.y,5)
	 p.dead=true
	 p.dead_timer=200
	 p.f_elapsed=0
	 sfx(5,1)
	 sfx(6,2)
	end
end

function explode(x, y, ttl, col)
  e = {}
  e.x = x
  e.y = y
  e.ttl = ttl
  e.col = col
  add(exp, e)
end

function add_smoke(x,y,amt,col)
	if col==null then col=5 end
 for i=1,amt do
 	s = {}
 	s.x = x
 	s.y = y
 	s.dx = (rnd(10) - 5) * 0.14
 	s.dy = (rnd(10) - 5) * 0.14
 	s.ttl = rnd(20)+amt*8
	 s.col = col
 	add(smoke, s)
 end
end

function pua_missile(pu)
	if p1.missiles < max_missiles then
		p1.missiles+=1
	end
end

function pua_shield(pu)
	p1.shield=p1.max_shields
end

function drop_powerup(x,y,sprite,action)
	pu={}
	pu.x=x
	pu.y=y
	pu.sprite=sprite
	pu.action=action
	add(powerups,pu)
end

function kill_alien(a,dmg)
	add_smoke(a.x+4,a.y,5)
	a.shield-=dmg

	if a.shield>0 then
		a.hurt=10
		sfx(10)
	
	else
	 explode(a.x+4,a.y,9,10)
	 del(als, a)
	 shake=4
	 sfx(rnd(2) + 1,1)
 
	 if a.kill!=nil then
	 	a.kill(a)
	 end
 
		add_score(a.scr)
		wave_score+=a.scr

		if pu_drop_timer==0 then
			pu_drop_timer=600
			
			t=rndi(2)
			if t==0 then
				drop_powerup(a.x,a.y,12,pua_missile)
			elseif t==1 then
				drop_powerup(a.x,a.y,13,pua_shield)
			end
		end
	end
end

function add_score(n)
	s1=shl(p1.score)/30000
	p1.score+=shr(n,16)
	s2=shl(p1.score)/30000

	if p1.score>0 and p1.lives<max_lives and s2>s1 then
		p1.lives+=1
		sfx(11)
		xlife_timer=40
	end
end

function draw_stars()
	for s in all(stars) do
	 sy2=s.y-(s.dy+warp*0.3)*2
	 c=s.col
	 if warp==0 and s.col==7 then c=13 end
		line(s.x,s.y,s.x,sy2,c)
	end
end

function clear_screen(f)
	if f==nil or f.timer<0 then
	 rectfill(0,0,127,127,0)
	else
	 rectfill(0,0,127,127,f.col)
		f.timer-=1
	end
end

function flash_screen(timer, col)
	flash={}
	flash.timer=timer
	flash.col=col
end

function draw_banner(msg,timer,tmax,col)
	buffer=50
	banh=4

	if timer<22+buffer then
		d=timer-buffer
	else
		d=tmax-timer-buffer
	end

	if d>0 then
		h=min(banh,(d-16)*0.75)
	
		if d<16 then
			line(0,64,d*4,64,8)
			line(127,64,127-d*4,64,col)
	
		else
			rectfill(0,64-h,127,64+h,col)
			rect(-1,64-h-2,128,64+h+2,7)
		end

		if h>=2 then
			x1=100-(timer*0.5)
			print(msg,x1,62,7)
		end
	end
end

function draw_game()
	clear_screen(flash)
	
	draw_stars()

	for s in all(smoke) do
		circfill(s.x, s.y, s.ttl * 0.2, s.col)
	end

 for l in all(lrs) do	
		spr(l.sprite, l.x, l.y)
 end

 local py = p1.y 
 if p1.f_elapsed>0 and p1.f_elapsed<5 then
		spr(9, p1.x, p1.y-7)
 end

	if not p1.dead and (p1.inv<=0 or p1.inv%6<3) then
		if p1.shield_timer>0 then
			y=py+2+p1.shield_timer*2
			r=p1.shield_timer+15
			circfill(p1.x+4,y-2,r,7)
			circfill(p1.x+4,y,r,2)
			circfill(p1.x+4,y+10,r*1.15,0)
			palc(8)
			spr(1, p1.x, py, 1, 2)
			palr()
		else
			spr(1, p1.x, py, 1, 2)
		end
 end
 
 t=time()
	for a in all(als) do
		if a.draw==nil then
			if a.hurt>0 then
				sx=(a.sprite%16)*8
				sy=flr(a.sprite/16)*8
				f=1+a.hurt/10
				w=8*f
				h=8*f
				x=a.x-(w-8)*0.5
				y=a.y-(h-8)*0.5
				
				palc(7)
				sspr(sx,sy,8,8,x,y,w,h)
				palr()
			else
				spr(a.sprite, a.x, a.y)
			end
		else
			a.draw(a)
		end
	end

 for pu in all(powerups) do
 	spr(pu.sprite,pu.x,pu.y)
	end
	
	for e in all(exp) do
		circfill(e.x, e.y, e.ttl * 2, e.col)
	end
	
	draw_ui()

	if warp>0 then
		b=calc_bonus()
		
		if bonus>0 then
			printc("+"..b,18,7)
		end
		
		nw=wave+1
		draw_banner("wave "..nw,wave_timer,wt_max,8)
	end

	if (shake > 0) then
		camera(rnd(4) - 2, rnd(4) - 2)
		shake-=1
	else
		camera(0,0)
	end
end

function draw_ui()
	if ui_y<1 then
		ui_y += (1-ui_y)*0.06
		if ui_y>0.5 then ui_y=1 end
	end

	print("scr",58,ui_y,12)
	ppad(p1.score,8,48,ui_y+7,7)

	print("lvs",8,ui_y,12)
	local ly=ui_y+8
	local lx=14-p1.lives*2.5
	for i=1,p1.lives do
		if i==p1.lives and xlife_timer>0 then
			if xlife_timer%8<4 then
				palc(8)
				spr(22,lx,ly)
				palr()
			end
		else
			spr(22,lx,ly)
		end
		lx+=5
	end

	print("wav",102,ui_y,12)
	if wave<10 then
		print("0",104,ui_y+7,8)
		print(wave,108,ui_y+7,7)
	else
		print(wave,104,ui_y+7,7)
	end
	
	if bonus>=20 or bonus%2<1 then
		bw=31
		bx1=64-bw*0.5
		line(bx1,ui_y+15,bx1+bw,ui_y+15,1)
		
		if bonus>0 then
			cols={8,9,10,7}
			col=cols[flr(bonus/25)+1]
			bx2=bx1+flr(bw*bonus*0.01)
			line(bx1,ui_y+15,bx2,ui_y+15,col)
		end
	end
		
	local my=128-8
	local mx=0
	for i=1,p1.missiles do
		x=(ui_y*i)-mx+i*5
		spr(6,x,my)
	end

	local sx=120
	for i=1,p1.shield do
		x=(-ui_y*i)+sx-i*3
		spr(7,x,my)
	end
end

function ppad(n,l,x,y,col)
 local s = ""
 local v = abs(n)
 while v>0 do
  s = shl(v % 0x0.000a, 16)..s
  v /= 10
  l-=1
 end

	for i=1,l do
		print("0",x,y,8)
		x+=4
	end

	if n!=0 then
		print(s,x,y,col)
	end
end

function collide(x1, y1, w1, h1, x2, y2, w2, h2)
	return x1 + w1 > x2
			 and x1 < x2 + w2
			 and y1 + h1 > y2
			 and y1 < h2 + y2 
end

function au_lissajous(a)
	b=2

 local t = (a.t + a.id * 0.4) * 0.08
	a.x = (30 + b * 10) * sin(t * 3 + b * 3 + 0.5) + 64
	a.y = a.t*2 + (b * 10) * sin(t * b * 2) + 30

	a.t += 1/60
end

function au_zigzag(a)
	local t = (time() + a.id * 2.1) * 0.03
	a.x += sin(t * 10) * 0.1
	
	if sin(t*20)>0 then
		a.y += 0.1
	 bomb_trail(a,3,0.4,25)
	end

	if a.y>p1.y-10 then
		a.y+=3
	else
		a.fire_time-=1
		if a.fire_time<=0 then
			drop_bomb(a)
			a.fire_time=1000
		end
	end
end

function au_golden(a)
	local t = (time() + a.id * 2.1) * 0.03
	a.x += sin(t * 10) * 0.1
	
	if sin(t*20)>0 then
		a.y += 0.1
	 bomb_trail(a,9,0.4,25)
	end

	if a.y>p1.y-10 then
		a.y+=3
	else
		a.fire_time-=1
		if a.fire_time<=0 then
			trg={}
			trg.x=p1.x
			trg.y=p1.y
			m=create_missile(a.x+4,a.y+4,trg)
			m.hurt=0
			m.shield=1
			m.tcol=10
			m.scr=50
			add(als,m)

			a.fire_time=1000
		end
	end
end

function au_pinkeye(a)
	local t1 = (time()+a.id*74)
	if a.state==0 then
		if a.y>p1.y-10 then
			a.y+=3
		elseif a.y>5 and flr(t1)%13==0 then
			a.state=1
		else
			local t = (time() + a.id * 2.1) * 0.03
			a.x+=sin(t * 10) * 0.1
			if sin(t*20)>0 then
				a.y += 0.1
			end
		end
		
	elseif a.state==1 then
		a.ly=a.y+6
		a.draw=ad_pe_laser
		a.timer=100
		a.state=2
		sfx(7,2)
		
	elseif a.state==2 then	
		if can_hit_ship(p1) and collide(p1.x+2,p1.y+4,4,8, a.x,a.y,1,a.ly-a.y) then
				ship_hit(p1)
		end
	
		a.y-=0.1
		if a.ly<128 then
			a.ly+=6
			add_smoke(a.x,a.ly-4,5,1)
			add_smoke(a.x,a.ly,2,10)
		else
			add_smoke(a.x,a.ly,2,10)
		end

		a.timer-=1
		if a.timer<=0 then
			a.state=0
			a.draw=nil
	  sfx(-1,2)
		end
	end
end

function ad_pe_laser(a)
	offx=rnd(3)-1
	spr(27,a.x+offx,a.y)

	x=a.x+3+offx
	y1=a.y+6
	y2=a.ly
	
	delta=a.timer

	if delta>80 then
		line(x,y1,x,y2,8)
		line(x+1,y1,x+1,y2,8)
	else
		line(x-1,y1,x-1,y2,14)
		line(x,y1,x,y2,7)
		line(x+1,y1,x+1,y2,7)
		line(x+2,y1,x+2,y2,14)
	end
end

function au_bomb(a)
 a.x+=sin(a.y*0.1)
 a.y+=1
 bomb_trail(a,8,0.3,15)
end

function ak_drop_bomb(a)
	if #als > 0 and rnd(20)<8 then
		drop_bomb(a)
	end
end

-------------------------
function _update60()
	debug={}
	scrn.update()
end

function _update()
   _update60()
   _update_buttons()
   _update60()
end

function _draw()
	scrn.draw()
	dbg_draw()
end
if(_update60)_update=function()_update60()_update60()end