-- solar
-- hike

function _init()

 cls()
-- rectfill(0,16,127,127-32,1)
-- color(7)
 v={}
 foreach(
  {-33,-26,0,0,4,12,28,46},
  function(y)
 --  line(0,127-24-54+y,127,127-24-54+y)
 		add(v, 127-24-54+y)
  end
 )

 f=0-- flr(rnd(8))*32 -- todo. weird stuff happens when this number is too big and it's probably because it's overflowing. i noticed blinking acting weird, "going backwards"

 blinkstarts={0,0}
	wordcounts={0,0}

	fadv=-1

end

function _update()

 if(btnp(0)) fadv+=.1
 if(btnp(1)) fadv-=.1
 if(btnp(3)) fadv=-1 pal()

 f+=fadv--0.9
	fabs=flr(abs(f))

end

function _draw()

-- camera(32,0)
 camxglobal=flr(sin(f/200)*12.9+48)
 camy=flr(sin(f/150)*4.9+7)
 camera(camxglobal,camy)
	clipy1=v[1]
	clipy2=v[7]+3+99
	clip(0,clipy1,128,clipy2)
	reps=32

 if(fabs%16==0) sfx(6+flr(rnd(4)))
	

--	pal()
	palt()

	-- clouds
	rectfill(0,v[1]-64,255,v[2],13)
	rectfill(0,v[2],255,v[3],1)
 pal(5,13)
 for i=0,(reps-1) do
  spr(2+flr(i/3)%3, (i*8+f/8)%256,v[2])
 end
 pal(5,5)

	-- water distant
	f2 = flr(f/16)%2
	palt(0, false)
-- for i=0,15 do
--  sspr(8,(i+f2)%2*4, 8,4, i*8,v[3])
-- end

	-- water close
 for i=0,(reps-1) do
  sspr(8,8+(i+f2)%2*4, 8,4, i*8,v[4])
 end

	-- water
	rectfill(0,v[5],255,v[6],12)
 palt()
	palt(5, true)
	f3 = flr(f/2)%2
	if f3%2==0 then
	 pal(6,12)
	else
  pal(7,12)
	 --	 pal(6,10)
--	 palt(6,true)
	end
--	palt(6, true)
 for i=0,(reps-1) do
  spr(2,i*8,v[5]-2)
 end
 pal(6,6)
 pal(7,7)

 palt()
-- pal()
	rectfill(0,v[6],255,v[8]+64,3)
	rectfill(0,v[8]+3,255,v[8]+64,5)

	-- far grass blades
 for i=0,(reps-1) do
		if i%2==0 or i%3==0 or i%5==0 or i%9==0 then
   sspr(8*6,(i/5)%2*4, 8,4, (i*8+f*1)%256,v[6]-1)
 	end
 end

 -- trees
 for i=2,(reps/2-1) do
		if i%7==0 or i%5==0 then
	  sspr(8*11,0, 16,16, (i*5+f*1)%256,v[3]-19+14+(i%4)*2, 16,16)
 	end
		if i%4==0 or i%7==0 then
	  sspr(8*11,0, 16,16, (i*14+f*1)%256,v[3]-16+15-(i%2), 16,16)
 	end
 end

 -- rocks
 for i=0,(reps/2-1) do
		if i%3==0 or i%5==0 or i%7==0  then
	  sspr((3+(i%2))*16+8,0, 16,16, (i*16+f*2)%256,v[7])
		end
 end

	-- path edge
 palt(5,true)
 pal(6,5)
 pal(7,5)
 for i=0,(reps-1) do
  spr(2+flr(i/3)%3, (i*8+f*2)%256,v[8]-1)
 end
	palt()
 pal(6,6)
 pal(7,7)

 -- grass blades
 for i=0,(reps-1) do
		if i%2==0 or i%3==0 or i%5==0 or i%9==0 then
	  sspr(8*6,(i/4)%2*3, 8,3, (i*8+f*2)%256,v[7]+15)
 	end
 end

function drawcat(xoff,phase,male,skincol,collarcol,bagcol)

	off=v[6]-abs(sin((f+phase)/32)*7.8)
	offlag=v[6]-abs(sin(((f+phase)+.5)/32)*8.8)
	offt0=v[6]-abs(sin(((f+phase)+1)/32)*11.8)
	offt1=v[6]-abs(sin(((f+phase)+1.2)/32)*12.8)
	offt2=v[6]-abs(sin(((f+phase)+1.5)/32)*12.8)
	offt3=v[6]-abs(sin(((f+phase)+2)/32)*12.8)

	camx=camxglobal-xoff -flr(sin((f+phase*25)/200)*2) -- -16
 camera(camx,camy)

	-- 0: forward, 1: left, 2: right
	headpos = 0 -- todo
if male==0 and fabs%256<64 then
 headpos=1
end
if male==1 and fabs%320<64 then
 headpos=2
end

	pal(7,skincol)
	pal(12,collarcol)
	pal(8,bagcol)

	color(7)
 --tail
	circfill(34, offt3+18, 5)
	circfill(36, offt3+17, 5)
	circfill(38, offt2+16, 4)
	circfill(41, offt2+16, 4)
	circfill(46, offt1+18, 4)
	circfill(48, offt1+21, 4)
 circfill(49, offt1+23, 4)
 circfill(50, offt1+27, 4)
 circfill(49, offt1+32, 4)
 circfill(49, offt1+35, 4)
 circfill(48, offt1+38, 4)
 circfill(48, offt1+41, 4)
 circfill(54, offt0+44, 10)

	--bag
	clip(0-camx+47,offlag+18-camy,30,32)
	circfill(74, offlag+38, 27, 8)
	clip(0,clipy1,128,clipy2)

	color(7)

	--body
 --shoulders
	circfill(73, off+25, 7)
	if male==0 then
 	--breast
 	circfill(75, off+31, 7)
 	--hips
 	circfill(65, offlag+52, 12)
 	circfill(64, offlag+53, 12)
 else
 	--breast
 	circfill(75, off+29, 4)
 	--hips
 	circfill(64, offlag+49, 9)
 	circfill(64, offlag+52, 10)
 end
	--arm
	clip(0-camx+48,0-camy,30,off+33)
	circfill(77, off+40, 22)
	clip(0-camx+48,off+33-camy,30,10)
	circfill(77, off+28, 22)
	clip(0,clipy1,128,clipy2)
	line(59,off+41,68,offlag+46,5)
	line(66,off+34,69,offlag+37,5)
	line(66,off+34,70,off+30,5)
	--hand
	sspr(8*2,8*1, 8*2,8*2, 67,offlag+36)
	line(72,off+18,76,off+22,8)
	line(73,off+18,77,off+22,8)
	line(76,off+23,75,offlag+35,8)
	line(77,off+23,76,offlag+35,8)

	--collar
	line(72,off+16,80,off+18,12)
	line(70,off+16,80,off+19,12)
	line(70,off+17,80,off+20,12)
	line(70,off+18,78,off+20,12)

	off=v[6]-abs(sin(((f+phase)+.33)/32)*8.8)+1
	
	color(7)
	--skull
	circfill(80, off-2, 20)
	--cheek
	circfill(89, off+9, 10)
	--ear
 if headpos==1 then
	 pal(14,skincol)
	 sspr(8*4,8*2, 8*3,8*2, 74,off-28)
	 pal(14,14)
 elseif headpos==2 then
	 sspr(8*4,8*2, 8*3,8*2, 75,off-27, 8*3,8*2)
	 sspr(8*7,8*2, 8*2,8*2, 68,off-31)
 else
	 sspr(8*13,0, 8*3,8*2, 75,off-28)
 end
if headpos==1 then
	--pointy bit
	sspr(8*13,0, 8*1,8*2, 61,off+1)
elseif headpos==2 then
	--pointy bit
	sspr(8*13,0, 8*1,8*2, 60,off-1)
else
	--pointy bit
	sspr(8*13,0, 8*1,8*2, 58,off-2)
end

	color(0)

if headpos~=1 then

	if fabs%(128*(1+male*1.66))==0 or fabs%(312*(1+male*1.66))==0 then
	 blinkstarts[male+1]=fabs
	end	

	blink = (fabs-blinkstarts[male+1])%224

 if headpos==2 then

  if blink<2 then
 		--eyes closed
   --l eye top
   line(93,off+8,97,off+8)
   --r eye top
   line(75,off+4,84,off+6)
  elseif blink<4 then
 		--eyes opening
 	 --l eye pupil
  	line(94,off+3,93,off+8)
  	line(95,off+3,94,off+7)
   --l eye top
   line(93,off+3,98,off+3)
 	 --r eye pupil
  	line(77,off,76,off+5)
  	line(78,off,77,off+4)
   --r eye top
   line(75,off-1,85,off+1)
 	else
 	 --eyes open
 	 --l eye pupil
  	line(94,off+2,93,off+8)
  	line(95,off+2,94,off+7)
   --l eye top
   line(94,off+2,98,off+2)
 	 --r eye pupil
  	line(77,off-1,76,off+5)
  	line(78,off-1,77,off+4)
--looking forward
--  	line(83,off+1,82,off+7)
--  	line(84,off+1,83,off+6)
   --r eye top
   line(76,off-2,85,off)
 	end

 else

  if blink<2 then
			--eyes closed
  	--eye top
  	line(88,off+4,94,off+7)
 	elseif blink<4 then
 		--eyes opening
  	--eye top
  	line(89,off+1,96,off+4)
   --eye pupil
  	line(94,off+4,93,off+8)
  	line(95,off+4,94,off+7)
 	else
 	 --eyes open
 	 --eye pupil
  	line(95,off+2,93,off+8)
  	line(96,off+2,94,off+7)
   --eye top
   line(90,off,97,off+2)
 	end

 end

end

 --nose
	if headpos==2 then
 	circfill(90,off+10,1)
	 line(89,off+9,91,off+9)
	elseif headpos==0 then
 	circfill(100,off+10,1)
	 line(99,off+9,101,off+9)
	end
 --mouth
--if headpos==2 then
--	if male==0 then
--  line(77,off+12,81,off+14)
-- else
--  line(76,off+13,81,off+14)
-- end
if true then
 mouthxoff=0
 if (headpos==2) mouthxoff-=5
 pal(5,0)
	if (
	  (male==0 and fabs%256>20 and fabs%256<160)
	  or (male==1 and fabs%256>175)
  ) and (
   fabs%12<8
   or fabs%30>22
  )
--  and fabs%909>120
--  and fabs%710>95
  and fabs%190>35
	then
  if fabs%3==0 or fabs%4==0 then
			if(fabs%5==0 or fabs%6==0) wordcounts[male+1]+=1
			wordcounts[1-male+1]=0
 	 if(male==0) then
    sfx(0+flr(fabs/(flr(fabs/(50+fabs%5))%3))%3, 2)
 	 else
    sfx(3+flr(fabs/(flr(fabs/60)%3))%3, 2)
 	 end
 	end
 	if(headpos~=1) spr(46+flr(fabs/2)%2,83+mouthxoff,off+13)
 else
 	if(headpos~=1) spr(46,83+mouthxoff,off+13)
 	if male==0 then
--  	line(86,off+13,90,off+15)
 	else
--  	line(85,off+14,90,off+15)
 	end
	end
	pal(5,5)
end

	if male==0 then
 	color(14)
  if headpos==2 then
 	 --blush
	  line(67,off+2,69,off+2)
	  line(68,off+3,70,off+3)
  elseif headpos==0 then
 	 --blush
	  line(77,off+5,80,off+5)
	  line(78,off+6,81,off+6)
  end
	end

	pal(7,7)
	pal(12,12)
	pal(8,8)

end

--drawcat(80,6,1,6,13,4) --(8
drawcat(54,3,1,15,8,2) --(32
drawcat(12,0,0,7,12,1) --(8

	-- bottom border
	camera()
	rectfill(0,v[8],255,v[8]+64,0)

 -- subtitles
 for i=1,2 do
  cursor(0+4, v[8]+6)
  if i==1 then
   color(7)
  else
   color(15)
  end
		string = ""
  for j=1,min(flr(wordcounts[i]/6),3) do
   print("meow meow meow meow meow meow", 0+4, v[8]+6+6*(j-1))
  end  
  for j=1,(wordcounts[i]%6) do
   string = string.."meow "
  end  
		print(string, 0+4, v[8]+6+6*min(flr(wordcounts[i]/6),3))
 end

 --fun
	if btnp(2) then -- flr(f)%128==0 then
		for i=1,15 do
 	 pal(i, flr(rnd(16)), 1)
		end
	end
	

end
