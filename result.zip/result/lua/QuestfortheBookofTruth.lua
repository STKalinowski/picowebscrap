--quest for the book of truth
--by mush
xs={x=0,y=0,s=0}
function xs:new(s)
self.__index=self
return setmetatable(s or {},self)
end
function xs:dw(ax,ay)
if not self.xi then
if self.pal then
set_pal(self.pal)
end
spr(self.s,ax+self.x,ay+self.y,1,1,self.f,self.vf)
r_p()
end
if self.fk then
self.xi=not self.xi
end
end
function nss(num)
return {xs:new({s=num})}
end
function nps(num,x,y)
return xs:new({s=num,x=x,y=y})
end
function ns(num)
return nps(num,0,0)
end
function set_pal(p)
for i=0,15 do
pal(i,p[i+1])
end
end
ac={x=0,y=0,w=7,h=7,sp={},
vel=0,dir=0,max_vel=3,acc=0}
function ac:new(a)
self.__index=self
return setmetatable(a or {},self)
end
function ac:dw()
for s in all(self.sp) do
s:dw(self.x,self.y)
end
end
function ac:up()
self.dir=self.dir%1
self.vel+=self.acc
self.vel=clamp(self.vel,0,self.max_vel)
self:move_x()
self:move_y()
end
function ac:clip_out()
if self:is_in_wall() and tr_z==0 then
for i=1,8 do
if (wrpt(self.x+i,self.y,self)) return
if (wrpt(self.x-i,self.y,self)) return
if (wrpt(self.x,self.y+i,self)) return
if (wrpt(self.x,self.y-i,self)) return
end
end
end
function ac:p_a(a)
self.dir=atan2(a.x-self.x,a.y-self.y)
end
function ac:dist_to(a)
local xd,yd=abs(self.x-a.x),abs(self.y-a.y)
return sqrt(xd*xd+yd*yd)
end
function ac:move_x()
self.x+=cos(self.dir)*self.vel
if self:is_in_wall() then
self.x=on8(self.x+4)
return false
end
return true
end
function ac:move_y()
self.y+=sin(self.dir)*self.vel
if self:is_in_wall() then
self.y=on8(self.y+4)
return false
end
return true
end
function ac:is_in_wall()
return is_solid(self.x,self.y)
or is_solid(self.x+self.w+0.8,self.y)
or is_solid(self.x,self.y+self.h+0.8)
or is_solid(self.x+self.w+0.8,self.y+self.h+0.8)
end
function ac:iaf()
return iaf(self.x,self.y)
and iaf(self.x+self.w+0.8,self.y)
and iaf(self.x,self.y+self.h+0.8)
and iaf(self.x+self.w+0.8,self.y+self.h+0.8)
end
function ac:kill_outside_room()
if self.x<cam_x-8 or self.y<cam_y-8 or self.x>cam_x+128 or self.y>cam_y+128 then
self.dead=true
end
end
function ac:hit(wp,dam)
end
function ac:fall()
if (tr_x!=0 or tr_y!=0) return
add(acs,o_f:new({x=self.x,y=self.y+2}))
self.dead=true
sfx(16)
end
function ac:is_on_hole()
return mget((self.x+4)/8,(self.y+4)/8)==206
end
function ac:be_plr_sword()
self.x,self.y=plr.x+self.dist*cos(self.dir),plr.y+self.dist*sin(self.dir)
end
function ac:swing()
self.rel_dir=(self.rel_dir+self.move_spd)%1
self.dir=(plr.sdir+self.rel_dir)%1
self.l-=1
end
function ac:inta(a)
for i in all(self.sp) do
for j in all (a.sp) do
if sp_intersect(i.s,j.s,i.x+self.x,j.x+a.x,i.y+self.y,j.y+a.y,i.f,j.f,i.vf,j.vf) then
return true
end
end
end
return false
end
function sp_overlap(ax,bx,ay,by)
if ax+8<bx then return false end
if bx+8<ax then return false end
if ay+8<by then return false end
if by+8<ay then return false end
return true
end
function sp_intersect(as,bs,ax,bx,ay,by,af,bf,avf,bvf)
if not sp_overlap(ax,bx,ay,by) then return false end
rectfill(0,0,16,8,0)
spr(as,0,0,1,1,af,avf)
spr(bs,8,0,1,1,bf,avf)
x_dif=bx-ax
y_dif=by-ay
for x=max(0,x_dif),min(7,7+x_dif) do
for y=max(0,y_dif),min(7,7+y_dif) do
a_pix=pget(x,y)
b_pix=pget(8+x-x_dif,y-y_dif)
if a_pix!=0 and b_pix!=0 then
return true
end
end
end
return false
end
exn=ac:new({size=0,col=7,fk=true})
function exn:up()
self.size+=0.2
if self.size>4 then
self.dead=true
end
end
function exn:dw()
circfill(self.x,self.y,self.size,self.col)
end
bomb=ac:new({time=120,s1=44,s2=43})
function bomb:st()
self.sp=nss(42)
self.x=plr.x+6*cos(plr.dir)
self.y=plr.y+6*sin(plr.dir)
end
function bomb:up()
self.time-=1
if self.time<30 then
if (self.time%6==0) self:shu()
elseif self.time<60 then
if (self.time%10==0) self:shu()
end
if self.time<=0 then
self:ex()
elseif self:is_on_hole() and self.time<110 then
self:fall()
end
end
function bomb:shu()
local s=self.sp[1]
if s.s==self.s1 then
s.s=self.s2
else
s.s=self.s1
end
end
function bomb:ex()
self:boom()
for a in all(acs) do
if a.x>=self.x-10 and a.x<self.x+18 and a.y>=self.y-10 and a.y<self.y+18 then
a:hit(self,10)
end
end
sfx(7)
self.dead=true
bomb_destroy(self.x,self.y)
end
function bomb:boom()
for i=0,25 do
add_ac(
exn:new({x=self.x+rnd(15)-4,y=self.y+rnd(15)-4,
size=rnd(3),col=6+rnd(2)})
)
end
end
telebomb=bomb:new({s1=46,s2=47})
function telebomb:st()
bomb.st(self)
self.sp=nss(45)
self:clip_out()
end
function telebomb:ex()
self:boom()
wrpt(self.x,self.y)
sfx(6)
self.dead=true
end
arrow=ac:new({l=-1,xs_m=0})
function arrow:up()
if self.s==nil then
local mod=self.xs_m
if self.dir==0 then
self.sp=ns(36+mod)
self.h=2
elseif self.dir==0.25 then
self.sp=ns(37+mod)
self.w=2
elseif self.dir==0.5 then
self.sp=ns(36+mod)
self.sp.f=true
self.h=2
elseif self.dir==0.75 then
self.sp=ns(37+mod)
self.sp.vf=true
self.w=2
else
self.sp=xs:new()
end
self.sp={self.sp}
end
if self.l>0 then
self.l-=1
if self.l<30 then
self.sp.xi=self.l%2==0
end
if self.l==0 then
self.dead=true
end
end
local move_sp=2
if self.gng then
if self.dir==0 then
self.x+=move_sp
elseif self.dir==0.25 then
self.y-=move_sp
elseif self.dir==0.5 then
self.x-=move_sp
elseif self.dir==0.75 then
self.y+=move_sp
end
if not self:iaf() then
self:hit_wall()
end
self:h_e()
end
self:kill_outside_room()
end
function arrow:hit_wall()
self.gng,self.l=false,120
self:gw()
end
function arrow:h_e()
for a in all(acs) do
if a.is_en and self:inta(a) then
a:hit(self,2)
self.dead=true
end
end
end
function arrow:gw()
if self.dir==0 then
self.x=on8(self.x)+1
elseif self.dir==0.25 then
self.y=on8(self.y+4)-3
elseif self.dir==0.5 then
self.x=on8(self.x+4)-1
elseif self.dir==0.75 then
self.y=on8(self.y)
end
end
b_a=arrow:new({xs_m=2})
function b_a:hit_wall()
arrow.hit_wall(self)
self:boom()
end
function b_a:boom()
self.dead=true
local b=bomb:new({x=self.x,y=self.y})
b.sp=nss(42)
b.time=0
add_ac(b)
end
function b_a:h_e()
for a in all(acs) do
if a.is_en and self:inta(a) then
self:boom()
end
end
end
t_a=arrow:new({xs_m=4})
function t_a:hit_wall()
self.gng=false
self:gw()
if self.dir==0 or self.dir==0.5 then
self.dead=wrpt(self.x,self.y-3)
else
self.dead=wrpt(self.x-2,self.y)
end
if (self.dead) sfx(6)
arrow.hit_wall(self)
end
function t_a:h_e()
end
en=ac:new({hit_t=0,is_en=true,hp=1})
function en:up()
ac.up(self)
self.hit_t=max(self.hit_t-1,0)
for i in all(self.sp) do
i.fk=self.hit_t>0
if not i.fk then
i.xi=false
end
end
if self.hit_t==0 and self.hp<=0 then
self.dead=true
if rnd(100)<=25 then
local heart=heart:new({x=self.x,y=self.y})
add_ac(heart)
end
end
self.x,self.y=clamp(self.x,0,120),clamp(self.y,0,120)
if self:is_on_hole() then
self:fall()
end
end
function en:st()
for s in all(self.sp) do
if self.dif==2 then
s.pal=opal
elseif self.dif==3 then
s.pal=gpal
end
end
self.hp=self.dif*2
end
function en:hit(wp,dam)
if self.hit_t>0 then return end
self.hp-=dam
if self.hp<=0 then
self:ex()
else
sfx(4)
self:p_a(wp)
self.dir+=0.5
self.vel,self.acc,self.hit_t=1.5,-0.1,11
end
end
function ac:ex()
for i=0,8 do
add_ac(
exn:new({x=self.x+rnd(7),y=self.y+rnd(7),
size=-rnd(5),col=6+rnd(2)})
)
end
self.hit_t=20
sfx(3)
self.vel,self.acc=0,0
end
function en:cmn()
return self.hit_t==0
end
sl=en:new({dam=3,hp=3,h=7,la_t=0,la_sp=0})
function sl:st()
self.sp=nss(64)
en.st(self)
end
function sl:up()
if self:cmn() then
if self.vel>0 then
self.vel=max(0,self.vel-0.4)
else
self:p_a(plr)
self.la_t+=self.la_sp
self.la_sp+=0.01
self.sp[1].s=64+(self.la_t%10)/5
if self.la_t>=100 then
self.vel,self.la_t,self.la_sp,self.sp[1].s=5,self.dif*10,0,65
end
end
end
self.sp[1].y=-abs(self.vel)
en.up(self)
end
gob=en:new({dam=3,hp=3,h=7,c=0})
function gob:st()
self.sp,self.dir,self.an,self.an_cg={ns(84),nps(83,0,-3)},self:rnd_dir(),rnd(0.5)-0.25,0.01
en.st(self)
end
function gob:rnd_dir()
return flr(rnd(4))/4
end
function gob:up()
if self:cmn() then
d=self:dist_to(plr)
if d<48 and d>8 then
self:p_a(plr)
self.dir+=self.an
self.an+=self.an_cg
if (self.an>0.25 or self.an<-0.25) self.an_cg*=-1
else
self.dir+=self.an_cg
end
self.sp[2].s=80+((self.dir+0.125)%1)*4
self.vel=self.dif/5
self.c+=self.vel
if self.c>4 then
local s=self.sp[1].s
self.sp[1].s=169 - s
if s==84 then
self.sp[1].f=not self.sp[1].f
end
self.c=0
end
end
en.up(self)
end
ga=ac:new({sp={ns(66),nps(67,8,0),nps(68,4,-8)}})
function ga:up()
if plr.y<self.y+8 then
self.dead=true
sfx(26)
end
end
bk=ac:new({sp=nss(79)})
function bk:up()
if self:inta(plr) then
won=true
music(13)
end
end
heart=ac:new({mom=0.2,dm=0.1,t=0,sp=nss(17)})
function heart:up()
if self.mom<1 then
self.y-=self.mom
self.mom+=0.2
elseif self.dm<0.6 then
self.y+=self.dm
self.dm+=0.1
end
if self:inta(plr) then
self.dead=true
sfx(8)
hp+=6
end
end
sw=en:new({dam=0,t=0,sp=nss(115)})
function sw:up()
if self.t>0 then
self.t-=1
end
end
function sw:hit()
if self.t==0 then
sw_bl()
self:ex()
self.t=20
bl_up=not bl_up
end
end
o_sw=sw:new({sp=nss(116)})
function o_sw:up()
end
function o_sw:hit()
if self.t==0 then
self.sp=nss(114)
self.t=20
self:ex()
if mx>=4 then
mset(5,3,237)
mset(9,3,252)
for i=21,25 do
mset(i,3,0)
end
else
rooms[0][0]="5u5t5t5v5t4q4p4p4p4p4p4o5t5v5t5v59595959595a5p5p745p5p58595959594p4p4p564p571r6k507u0s554p4p4p4p5p5p5l1m5n5q0s0s0s0s1r5o5p5p5p5p4u4v1r0s1r0s0s0s0s0s0s0s1r4u4v4u4v4u4v0s0s1c1c0s1s0s0sbe0s1r4u4v99999999991j1k9999999999999999999p9p9p9p9p1j1k9p9p9p9p9p9p9p9p9p82828282821j1k8282828282828282828i948i8i8i1j1k8i8i8i8i948i8i8i8i8i8i9e89891j1k8989898989898989898i848o1s0s0c0c0s1r4u4v4u4v0s1c1c8i8j8o0s0s0s0s0s0s1s0s1r0s0t1t1t948j8o4u4v0s1r0s0s1c1c0s0s4u4v0c8i8j8o484949494a0t1t1t0r484949498i8j8o4o5t5u5t4q0t1t1t0r4o5t5v5t"
bd_c=6
end
end
end
pf=ac:new({l=0,sp=nss(18)})
function pf:up()
if self.l==0 then
self.sp[1].s=18
end
self.l+=1
if self.l%5==0 then
self.sp[1].s+=1
end
if self.l>=20 then
self.dead,plr.dead,plr.x,plr.y,plr.sdir=true,false,plr.entry_x,plr.entry_y,plr.entry_dir
add_ac(plr)
sfx(17)
end
end
o_f=pf:new()
function o_f:up()
if self.l==0 then
self.sp[1].s=20
end
self.l+=1
if self.l%5==0 then
self.sp[1].s+=1
end
if self.l>=10 then
self.dead=true
end
end
function ati(name,s)
add(inv,it:new({name=name,s=s,id=name}))
while inv[1].name!=name do
next_it()
end
end
get_it=ac:new({l=0})
function get_it:up()
local list={2,1,27,4,2,23,5,3,23,5,2,26,6,0,28,7,3,23}
local s=d_it
for i=1,18,3 do
if mx==list[i] and my==list[i+1] then
s=list[i+2]
end
end
self.sp=nss(s)
self.x,self.y=on8(plr.x+4),plr.y-14
self.l+=1
if self.l==1 then
names={"bow and arrows","bombs","teleport rod","bomb arrows","teleport arrows","telebombs"}
if s==23 then
keys+=1
elseif s==54 then
max_hp+=6
hp=max_hp
else
got[s]=true
ati(names[s-25],s+32)
end
elseif self.l>90 then
gi=nil
play_music(current_music)
end
end
it=ac:new({name="sword",s=57,id="sword"})
function _init()
acs,hp,prev_hp,show_hp,max_hp,won_t,deaths,keys,prev_hp_time,mx,my,mi,sd,tc,f_c,bl_up,inv,ml,ti,got={},21,21,21,21,0,0,0,0,1,3,0,0,0,0,false,{},{},true,{}
r_p()
mx_c,my_c,map_dw_x_c,map_dw_y_c,cam_x,cam_y,cam_w,cam_h,it_sw_oft,tr_x,tr_y,tr_z=0,0,0,0,0,0,128,128,0,0,0,0
plr_init()
imoc,it_menu_open=-1,false
add(inv,it:new())
init_rooms()
poke(0x5f2c,3)
for i=0,1.6,0.2 do
add(ml,i)
add(ml,-i)
end
end
function play_music(x)
current_music=x
music(x)
end
function on8(n)
return flr8(n)*8
end
function flr8(n)
return flr(n/8)
end
function load_cr(load_enemies)
lr(mx,my,0,0,load_enemies)
plr.set_entry=false
end
function load_cr_below()
lr(mx,my,0,16,true)
end
function init_rooms()
rooms={}
for i= 0,7 do
rooms[i]={}
end
rooms[0]={ "8i8j8o585959595a0t1t1v0r585959478i8j8o554p4p4p570t1t1t0r554p4p4o948j8o5o5p5p5p5q0t1u1t0r5o5p5p4o8i8j989999999999991j1k999999994o8i8j9o9p9p9p9p9p9p1j1k9p9p9p9p4o8i8k828282828282821j1k828282834o89898989899f8i8i9e1j1k9f8i948j4o4v4u4v1s0t1i1i1i1i0b0c8q858i8j4o4u4v0s1c1d1h1h1h1h0r1s8q8h8i8j4o9999991j1k9a91939899999a8h8i8j4o9p9p9p1j1k9q8h8j9o9p9p9q8h8i8j4o8282821j1k828l8k828282828l948j4o8i9e891j1k899f8i8i948i8i8i8i8j4o898n0t1t0b0s8m89898989898989894o4v1r1r0c0s0s0s0s0s1r0s1r4u4v4s4o4u4v1s0s1r0s0s1r0s0s1s0s0s4u4v4o017l01j902df","4v4s1r0s0s0s0s0s0s0s0s0s0s4s4s4o4u4v0s0s0s0s0s0s1s0s0s1r0s4u4v584v0s1s1r0s4u4v0s0s1r0s1s0s0s0s554u4v0s0s4u4v0s4849494a0s0s1r0s554v4u4v0s0s1r484n4u4v4q1s0s1r0s5o4u4v4u4v0s0s4o4u4v465a0s0s0s0s0s4v4u4v0s1s0s5859595a571c1c1c1c1c4u4v4u4v0s0s554p4p575q1v1t1t1u1t4v4u4v4u4v0s5o5p5p5q0t1t0b0c0c0c4u4v4u4v0s1c1c1c1c1c1d1t0r0s1r0s4v4u4v0s0t1t1u1t1t1v1t1v0r0s0s4u4u4v0s1r0t1t0b0c0c0c0c0c1r0s4u4v4v4u4v0s0t1v0r0s1s4u4v0s0s0s0s4u4u4v0s0s0t1t0r0s0s0s4u4v1r0s4u4v4v4u4v1r0t1u0r0s1r0s0s0s0s0s1r4u4u4v0s0s0t1t0r0s4u4v4u4v4u4v4u4v01pp117l01o6","4v4s1r0s0t1t0r1r4s4u4v4u4v4u4v4u4u4v1r0s1d1u0r0s4u4v4u4v4u4v4u4v4v4u4v0t1t1t0r0s484949494a4u4v4u4u4v0s0t1v0b1r0s4o5t5u5t4q5r4u4v4v4u4v0t1t1b0s0s585959595a4u4v4u4u4v0s0t1t1u0r1r554p564p575r4u4v4v4u4v0s0d1t0r0s5o5l1m5n5q4u4v4u4u4v4u4v0t1v0r4u4v1s1c1s4u4v4u4v4v4u4v0s0t1t1b0s0s1d1t0r0s4u4v4u4u4v4u4v0t1t1v0r0t1t1v0r4u4v4u4v4v4u4v4u4v0c0c0s0s0c0c4u4v4u4v4u4u4v4u4v4u4v4u4v4u4v4u4v4u4v4u4v999999999999999999999999999999999p9p9p9p9p9p9p9p9p9p9p9p9p9p9p9p828282828282828282828282828282828i8i948i8i8i948i8i8i8i948i8i948i12ag","5u5t5t5v5t4q4p4p4p4p4p4o5t5v5t5v59595959595a5p5p745p5p58595959594p4p4p564p571r6k507u0s554p4p4p4p5p5p5l1m5n5q0s0s0s0s1r5o5p5p5p5p4u4v1r0s1r0s0s0s0s0s0s0s1r4u4v4u4v4u4v0s0s1c1c0s1s0s0s9g0s1r4u4v999999999999999999999999999999999p9p9p9p9p9p9p9p9p9p9p9p9p9p9p9p828282828282828282828282828282828i948i8i8i8i8i8i8i8i8i948i8i8i8i8i8i9e898989898989898989898989898i848o1s0s0c0c0s1r4u4v4u4v0s1c1c8i8j8o0s0s0s0s0s0s1s0s1r0s0t1t1t948j8o4u4v0s1r0s0s1c1c0s0s4u4v0c8i8j8o484949494a0t1t1t0r484949498i8j8o4o5t5u5t4q0t1t1t0r4o5t5v5t"}
rooms[1]={ "5t5v5t5u5t5t5t5t5v5t5t5u5t5t5t5t5t46595959595959595959595959475t5t4q4p4p4p4p4p4p4p4p4p4p4p4p4o5t5t4q4p4p4p4p4p4p4p4p4p4p4p4p4o5t5u4q5p4p4p4p5p5p5p5p4p4p4p5p4o5v5t4q8q8p8p8p8o0s0s8q8p8p8p8o4o5u5t4q8q9p9p9p8o8s8s8q9p9p9p8o4o5t4c4q8q818283985j5k9a8182838o4o5t5r4q8q8h948j9o5j5k9q8h948j8o4o5v4s4q8q8h8i8k825j5k828l8i8j8o4o5t4s4q8m898989891j1k898989898n4o5t5r4q4u4v1r0s1r0s0s0s1r4u4v4s4o4c4s4q1s0s0s0s0s0s0s1r0s1s4u4v4o4s4s4m494a0s1c0s484949494949494n5r4s4s5r4q0t1t0r4o5r4s4s4s4s5r4s4s5r4s4s4q0t1u0r4o4s4u4v4u4v4u4v4u","4s4s5r4q0s0c0s4o4s5r4u4v4u4v4u4v5959595a0s1c0s585959474u4v4659594p4p4p570t1u0r554p4p5859595a4p4p4p4p4p570t1t0r554p4p554p4p574p4p5p5p5p5q0s0c0s5o5p5p554p4p575p5p0s0s0s1r0s1c0s0s0s1s5o5p5p5q1s0s1c1c0s0s1d1t1b1c0s0s1c1c0s0s1c1c1t1v0r0t1t1u1t1t0r0t1t1v0r0t1u1t0c0c0s0t1t1t0b0c0s0s0c0c0s0s0c0c0s1r0s0t1t1t0r0s0s0s0s0s0s0s0s0s4v0s0s0t1v0b0s0s0s4u4v0s1r0s0s4u4u4v0s0s0c0s1c1c0s0s0s0s0s0s4u4v4v0s0s0s0s0t1t1t1b0s0s0s0s0s0s4u4u4v0s1r0s0t1t1t1t0r1r0s1s0s4u4v4v4u4v0s0s0s0d1t1u0r0s0s0s4u4v4u4u4v4u4v4u4v0t1t1t0r4u4v4u4v4u4v01eg","4v4u4v4u4v4s0t1t1t0r4s4u4v4u4v4u4u4v4u4v4u4v0t1u1t0r4u4v4u4v4u4v4v4u4v4u4v0s0t1t1t0r0s4u4v4u4v4u4u4v4u4v1r0s0t1t0b0s0s0s4u4v4u4v4v4u4v0s0s1s0s0d0r0s1s1r0s4u4v4u4u4v0s0s0s0s0s0t1b0s0s0s0s0s4u4v4v0s0s0s4u4v0s1d1t0r4u4v0s4u4v4u4u4v0s1s0s0s1d1t1u1b0s0s0s0s4u4v4v0s0s0s0s0t1t1t1t1t0r0s0s4u4v4u4u4v0s1r0s0t1u1t1t1v0r0s1r0s4u4v4v4u4v1s0s0s0c0c0c0c0s0s1s4u4v4u4u4v8699999999999999870s4u4v4u4v99999a9p9p9p9p9p9p9p9899999999999p9p9q818282828282839o9p9p9p9p9p8282828l8i8i948i8i8k8282828282828i8i948i8i8i8i8i8i8i8i948i8i8i8i","5u5t5v5t5u5t5t5v5t5t5t5t5u5t5v5t595959595959595959595959595959594p4p4p4p4p4p4p4p4p4p4p4p4p4p4p4p5p5p5p5p5p5p5p5p5p5p5p5p5p5p5p5p4v4u4v0s1c1c0s1r0s0s1s4u4v0s0s1r4u4v0s0t1t1u0r0s0s1r0s0s1s1r0s0s999999991j1k999999999999999999999p9p9p9p1j1k9p9p9p9p9p9p9p9p9p9p828282821j1k828282828282828282828i948i8i1j1k8i8i948i8i8i8i948i8i898989891j1k898989898989898989891c1c1c1d1t1u1b1c1c1c1c1c1c1c1c1c1u1t1t1t1v1t1t1t1v1t1t1t1t1t1t1v0c0c0c4u4v0c0c0c0c0c0c4u4v0c0c0c494949494949494949494949494949495t5t5t5t5t5t5t5t5t5t5t5t5t5t5t5t019g12f9"}
rooms[2]={ "5t4q0t1t0r0s8q8h8i8j8o0s0s0s4u4v5t4q0s0c0s1c8q8h948j8o0s1r0s0s4u5u4q4u4v0t401i1i1i1i1i1s6s1s4u4v5t4q1c1c1d401h1h1h1h1h0s1r0s0s4u5v4q869999999a9192939899999999995t4q8q9p9p9p9q8h948j9o9p9p9p9p9p5t4q8q818282828l8i8k8282828282825u4q8q8h8i948i8i8i8i8i8i8i948i8i5t4q8m898989898989898989898989895t4q0s1c1c1c1c1c1c1c1c1c1c1c1c1c5v4q0t1t1u1t1t1t1t1t1v1t1t1t1v1t4c4q0s0c0c0c0c0c0c0c0d1t0b0c0c0c4s4m494949494a0s0s1r0t1t0r1r0s0s4s4s4s4s4s4s4q4u4v0s0t1t0r0s4u4v4u4v4u4v4u4v4q4s4u4v0t1u0r4u4v4u4v4u4v4u4v465a4u4v0s0t1t0r0s4u4v01mk026k1156","4u4v4u4v465a574s4s0s0t1t0r0s4s4u595959595a57574u4v0s0t1u0r0s4u4v4p4p4p4p57575q4s4u4v0s0c0s4u4v4u4p4p4p4p575q4u4v0s0s0s1c0s1s4u4v5p5p5p5p5q4u4v1s0s0s0t1t0r1r0s0s0s0s0s1c1c1c1c1c0s0s1d1t1b1c1c1c1c1c1d1t1t1t1v1t0r0t1t1v1t1t1u1t1t1v1t1t0b0c0c0c0s0s0c0c0c0c0c0c0c0c0c0c0s0s0s0s0s0s86999999870s0s1r1s0s0s1r869999999a9p9p9p98994v0s0s1r0s0s8q9p9p9p9q8182839o9p4u4v0s0s1c0s8q818282828l948k82824v4u4v0t1t0r8q8h8i849e9f858i8i8i4u4v0s0t1v0r8q8h8i8j989a8h8i8i8i4v0s1s0t1t0r8q8h8i8j9o9q8h8i8i944u4v0s0t1t0r8q8h948k82828l8i8i8i01hc117l","4v4s0s0t1v0r8q8h8i948i8i8i8i8i8i4u4v0s0t1t0r8q8h8i8i8i8i8i8i8i8i4v0s1r0t1t0r8q8h8i5e4949495f8i944u4v0s0t1u0r8q8h8i4o5t5u5t4q8i8i4v0s0s0s0d0r8q8h84585959595a858i4u4v0s1s0t0r8q8h8j554p564p578h8i4v4u4v0s1d0r8q8h8j555l1m5n5q9f8i4u4v0s0t1t0r8q8h8j958o0r4u4v8q854v0s1r0t1u0r8q8h8j9o8o0r0s6s8q8h4u4v0s0t0b1r8q8h8k838o1b1c1d8q8h4v4u4v0s0s0s8q8h8i8j989999999a8h4u4v4u4v0s1s8q8h948j9o9p9p9p9q8h9999999999999a8h8i8k82828282828l9p9p9p9p9p9p9q8h8i8i8i8i8i8i8i8i828282828282828l8i8i8i8i948i8i8i8i8i948i8i8i8i8i948i8i8i8i8i8i8i124g","5t5t5t5t4q4p4p4p4o5t5t5t5t5t5t5t595959595a8p8p8p58595959595959594p4p4p4p579p9p9p554p4p4p4p4p4p4p5p5p5p5p5q8182835o5p5p5p5p5p5p5p0s0s1r0s1i1i1i1i1i0s1r0s0s1s0s0s1r0s0s0s1h1h1h1h1h0s0s0s0s0s0s0s999999999a9192939899870s0s0s0s0s9p9p9p9p9q8h8i8j9o9p8o0s0s0s4u4v82828282828l948k82838o1s0s1r0s4u8i948i8i8i8i8i8i8i8j8o0s0s0s4u4v8989898989899f8i8i8j8o0s1r0s0s4u1c1c1c1c4u4v8q858i8j8o0s0s0s4u4v1t1u1t1t0r0s8q8h8i8j8o1r1r0s0s4u0c0c0d1t0r0s8q8h948j8o1s1r1r4u4v494a0t1t0r0s8q8h8i8j8o1r1r0s0s4u5t4q0t1u0r0s8q8h8i8j8o1r0s0s4u4v129o03ok02b811nb"}
rooms[3]={ "4u4v0s0s1s0s0t1v1t0r0s1s0s0s58594v0s1r0s0s0s0t1t1t0r0s0s1r0s554p4u4v0s0s0s4u4v0c0c4u4v0s0s0s554p4v4u4v0s1r0s0s0s0s0s0s1r4u4v5o5p999999999999991j1k999999999999999p9p9p9p9p9p9p1j1k9p9p9p9p9p9p9p828282828282821j1k828282828282828i8i948i8i8i8i1j1k8i8i8i948i8i8i898989898989891j1k898989898989891c0s1r0s0s1r0s0s0s0s0s0s4u4v4u4v1t0r0s0s0s0s0s1c1c0s1s0s0s4u4v4u0c0s0s4u4v0s0t1u1t0r1r0s0s0s4u4v0s0s0s0s0s1s0t1t1t0r0s0s0s0s0s4u4u4v1r0s0s0s0t1t1t0r0s4u4v0s4u4v4v0s0s0s0s0s0t1t1u0r0s0s0s1r0s4u4u4v0s0s1r0s0t1t1t0r0s1r0s0s4u4v01fc12no","4v4s0s0s0s0s0t1t1t0r0s0s0s0s4u4v4u4v0s1r0s1r0t1u1t1b0s1r0s0s0s4u4v4u4v0s0s0s0t1t1t1t0r0s0s0s4u4v4u4v0s0s0s4u4v0d1t1v0r0s0s4u4v4u0s0s0s1r4u4v1s0s0d1t0r0s1r0s4u4v1c1c0s0s0s1c1c1c0s0c0s0s0s4u4v4u1u1t1b1r0t1t1u1t1b0s0s1r0s0s4u4v0c0c0c0s0s0d1t1t1t0r0s4u4v0s0s4u0s1r0s0s0s1r0c0c0c0s4u4v1r0s4u4v99999999870s0s1c1c0s1r0s0s4u4v4u9p9p9p9p8o1c1d1t1u0r0s0s4u4v4u4v828282838o1t1t1t1t869999999999998i8i8i8j8o1u1t1t1v8q9p9p9p9p9p9p8i948i8j98991j1k999a8182828282828i8i8i8j9o9p1j1k9p9q8h8i8i8i948i8i8i948k82821j1k82828l8i8i8i8i8i12c811je12p8","8i8i8i8i8i8i1j1k8i8i8i8i8i8i8i8i8i948i9e89891j1k899f8i8i948i8i8i8i8i848o0s1r0s0s0s8q858i8i8i8i8i8i8i8j8o0s0s0s0s1r8q8h8i8i8i948i8i9e898n0s1s0s86999a8h8i8i8i8i8i848o0s0s0s0s0s8q9p9q8h8i948i8i8i8j8o0s0s0s0s1r8q81828l8i8i8i8i8i8j8o0s4u4v0s0s8q8h948i8i8i8i8i8i8j8o0s0s0s0s1c8q8h8i8i9e89899f8i8j9899870s0t1t1i1i1i1i1i40408q858j9o9p8o1s0t1t1h1h1h1h1h40408q8h8k82838o1c1d1u8q9192938o6s0c8q8h8i8i8j989999999a8h8i8j8o1r1s8q8h8i948j9o9p9p9p9q8h8i8j9899999a8h8i8i8k82828282828l8i8j9o9p9p9q8h8i8i8i8i8i8i8i8i8i948k828282828l129711fj","5t5u5t5t5t5t5t5t5t5t5t5t5t5t5t5t595959475u46595959475t5t5u5t5t5v4p4p4p58595a4p4p4p4o5t5t5t5t5t5t5p5p5p554p575p5p5p4o5t5v5t5t5t5t0s0s0d5o5p5q1t1t1t5859595959475t0s0s1r0c0d1t1t1v1t554p564p4p4o5t0s0s0s0s0s0d1t1t1t5o5l1m5n5p4o5t4u4v0s0s1r0t1t1t1t1t1b1c0s1s4o5t4v4u4v0s0s0t1t1t1t1t1t1t0r0s4o5t4u4v0s1r0s1d1t0b0c0c0d1t1b0s4o5t4v4u4v0s0t1t1t0r4u4v0t1t1t0r4o5v4v4u4v0s0t1t1t1b1c1c1d1t1t0r4o5t4u4v0s0s0t1t1t1t1t1t1t1v1t0r4o5t4u4v0s0s0s0c0d1t1t1t1t1t0b0s4o5u4v4u4v0s1s0s0t1v1t0b0c0c0s0s4o5t4u4v0s0s0s0s0t1t1t0r0s1r0s0s4o5t118l12ea11hi"}
rooms[4]={ "6062632465626262626262626262617v66706j3c6l6i6i6i6i6i6i6i6i71697v66672c2c2c2c2cau2c2c2c2c2c68697v66672c2c2c2c2cau2c2c2caf2c68697v66672c2c2c2c2cau2c2c2c2c2c68697v667g727272727272727b2c2c2c68697v6g7i7i7i7i7i7i7i6b672c2c2c68697v6e6e6e6e6e6e6e6e66672v2v2v68697v60626262626262626r672c2c2c68697v66706i6i6i6i6i6i6i7r2c2c2c68697v66672c2c2c2c2cau2c2c2c2c2c68697v66672c2c2c2c2cau2c2c2c2c2c68697v66672c2c2c2c2cau2c2c2c2c2c68697v667g733t7572727272727272727h697v6g7i7j3k7l7i7i7i7i7i7i7i7i7i6h7v7v7v7v3v7v7v7v7v7v7v7v7v7v7v7v7v","606263246562626262626262617v7v7v66706j3c6l6i6i6i6i6i6i71697v7v7v66672c2c2c2c2c2v2c2c2c68697v7v7v66672c2c2c2c2c2v2c6t2c68697v7v7v66672c2c2c2c2c2v2c2c2c68697v7v7v667g7272727272727272727h697v7v7v6g7i7i7i7i7i7i7i7i7i7i7i6h7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v606262626262626262626262617v7v7v66706i6i6i6i6i6i6i6i6i71697v7v7v66672c2c2c2c2c2c2c2c2c6o6p7v7v7v66672caf2c2c2c2c2c2c2c3d393v7v7v66672c2c2c2c2c2c2c2c2c7o7p7v7v7v667g7272733t75727272727h697v7v7v6g7i7i7i7j3k7l7i7i7i7i7i6h7v7v7v7v7v7v7v7v3v7v7v7v7v7v7v7v7v","6062626262626324656262626262617v66706i6i6i6i6j3c6l6i6i6i6i71697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c7a7272727b2c2c2c68697v66672c2c2c686a7i6b672c2c2c68697v66672c2c2c68697v66672c2c2c68697v66672c2c2c686q626r672c2c2c68697v66672c2c2c7q6i6i6i7r2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2d2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v667g72727272727272727272727h697v6g7i7i7i7i7i7i7i7i7i7i7i7i7i6h7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v01me1169","606262626262617v606262626262617v66706i6i6i71697v66706i6i6i71697v66672c2c2c6o6p7v6m6n2c2d2c6o6p7v66672c2c2c78797v76772c2c2c3d393v66672c2c2c7o7p7v7m7n2c2c2c7o7p7v66672c2c2c686q626r672c2c2c68697v66672c2c2c7q6i6i6i7r2c2c2c68697v66672e2e2e2e2e2e2e2e2e2e2e68697v66672c2c2c2e2e2e2e2e2e2e2e68697v66672c2c2c2e2e2e2c2c2e2e2e68697v66672c2c2c2e2e2e2cbf2e2e2e68697v66672c2c2c2e2e2e2c2c7a72727h697v66672c2c2c2e2e2e2e2e686a7i7i6h7v667g733t7572727272727h697v7v7v7v6g7i7j3k7l7i7i7i7i7i7i6h7v7v7v7v7v7v7v3v7v7v7v7v7v7v7v7v7v7v7v7v"}
rooms[5]={ "7v7v7v7v60626262626263246562617v7v7v7v7v66706i6i6i6i6j3c6l71697v7v7v7v7v66672c2c2c2c2c2c2c68697v7v7v7v7v66672c2c2c2c2c2c2c68697v606262626r672c2c2c2c2c2c2c68697v66706i6i6i7r2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c6o6p7v66672c2c2c2c2c2c2c2c2c2c2c3d393v66672c2c2c2c2c2c2c2c2c2c2c7o7p7v66672c2c2c2c2c2c2c7a7272727h697v66672c2c2c2c2c2c2c686a7i7i7i6h7v66672c2c2c2c2c2c2c68697v7v7v7v7v66672c2c2c2c2c2c2c68697v7v7v7v7v667g733t75727272727h697v7v7v7v7v6g7i7j3k7l7i7i7i7i7i6h7v7v7v7v7v7v7v7v3v7v7v7v7v7v7v7v7v7v7v7v7v13k803ai","6062632465626262626262626262617v66706j3c6l6i6i6i6i6i6i6i6i71697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c6t2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672e2e2e2e2v2v2v7a7272727h697v66672c2c2c2e2c2c2c686a7i7i7i6h7v66672caf2c2e2c2c2c68697v6e7v7v7v66672c2c2c2e2c2c2c686q626262617v66672e2e2e2eauauau7q6i6i6i71697v6m6n2c2c2c2c2c2c2c2c2c2c2c6o6p7v363s2c2c2c2c2c2c2c2c2c2c2c3d393v7m7n2c2c2c2c2c2c2c2c2c2c2c7o7p7v667g72727272727272727272727h697v6g7i7i7i7i7i7i7i7i7i7i7i7i7i6h7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v11ee","6062626262626262626262626262617v66706i6i6i6i6i6i6i6i6i6i6i71697v66672c2c2c2e2e2c2c2c2c2c2e68697v66672c2c2c2e2e2c2c2c2c2c2e68697v66672c2c2c2e2e2c2c2c2c2c2e68697v66672c2c2c7a7272727b2c2c2c68697v66672c2c2c686a7i6b672c2c2c6o6p7v66672c2c2c68697v66672c2c2c3d393v66672c2c2c686q626r672c2c2c7o7p7v66672c2c2c7q6i6i6i7r2c2c2c68697v66672e2c2c2c2c6t2e2e2c2c2c68697v66672e2c2c2c2c2c2e2e2c2c2c68697v66672e2c2c2c2c2c2e2e2c2c2c68697v667g72727272727272727272727h697v6g7i7i7i7i7i7i7i7i7i7i7i7i7i6h7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v11i6136d","6062626262626262626262626262617v66706i6i6i6i6i6i6i6i6i6i6i71697v6m6n2cau2c2c2e2e2c2c2c2c2c68697v363s2cau2c2c2e2e2c2c2c2c2c68697v7m7n2cau2c2c2e2e2c2c2c2c2c68697v66672e2e40402e2e2c2c2c2c2c68697v66672e2e2c2c2e2eaf2c2c2c2c68697v66672e2e2c2c2e2e2e2e2c2c2c68697v66672e2e2c2c2e2e2e2e2c2c2c68697v66672e2e2v2v2c2c2cauau2c2c68697v66672e2e2v2v2c2c2cauau2c2c68697v66672e2e2e2e2e2e2e2e2c2c2c68697v66672e2e2e2e2e2e2e2e2c2c2c68697v667g7272727272727272733t757h697v6g7i7i7i7i7i7i7i7i7i7j3k7l7i6h7v7v7v7v7v7v7v7v7v7v7v7v3v7v7v7v7v"}
rooms[6]={ "7v7v7v7v606263246562617v7v7v7v7v7v7v7v7v66706j3c6l71697v7v7v7v7v7v7v7v7v66672c2c2c686q626262617v7v7v7v7v66672c2c2c7q6i6i6i71697v606262626r672c2c2c2c2c2c2c68697v66706i6i6i7r2c2c2c2c2c2c2c68697v6m6n2c2c2c2c2c2c2c2c2c2c2c68697v363s2c2c2c2c2c2c2c2c2c2c2c68697v7m7n2c2c2c2c2c2c2c2c2c2c2c68697v667g7272727b2c2c2c2c2c2c2c68697v6g7i7i7i6b672c2c2c2c2c2c2c68697v7v7v7v7v66672c2c2c7a7272727h697v7v7v7v7v66672c2c2c686a7i7i7i6h7v7v7v7v7v667g733t757h697v7v7v7v7v7v7v7v7v6g7i7j3k7l7i6h7v7v7v7v7v7v7v7v7v7v7v7v3v7v7v7v7v7v7v7v7v13ma13mi","6062626262626324656262626262617v66706i6i6i6i6j3c6l6i6i6i6i71697v66672c2c2c2c2c2c2c2c2c2c2c6o6p7v66672c2c2c2c2c2c2c2c2c2c2c3d393v66672c2c2c2c2c2c2c2c2c2c2c7o7p7v66672c2c2c2c2c2c2c2c7a72727h697v66672c2c2c2c2c2c2c2c686a7i7i6h7v66672c2c2c2c2c2c2c2c68697v7v7v7v66672c2c2c2e2e2c2e2e686q6262617v66672c2c2c2e2e2v2e2e7q6i6i71697v6m6n2c2c2c2e2e2c2e2e2c2caf68697v363s2c2c2c2e2eau2e2e7a72727h697v7m7n2c2c2c2e2e2c2e2e686a7i7i6h7v667g72727272733t75727h697v7v7v7v6g7i7i7i7i7i7j3k7l7i7i6h7v7v7v7v7v7v7v7v7v7v7v3v7v7v7v7v7v7v7v7v136a13f9","7v7v7v6062626324656262617v7v7v7v7v7v7v66706i6j3c6l6i71697v7v7v7v7v7v7v66672c2c2c2c2c68697v7v7v7v6062626r672c2c2c2c2c686q6262617v66706i6i7r2c2c2c2c2c7q6i6i71697v66672c2c2c2c2c2c2c2c2c2c2c68697v6m6n2c2c2c2c2c2c2c2c2c2c2c68697v363s2c2c2c2c2caf2c2c2c2d2c68697v7m7n2c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v667g72727b2c2c2c2c2c7a72727h697v6g7i7i6b672c2c2c2c2c686a7i7i6h7v7v7v7v66672c2c2c2c2c68697v7v7v7v7v7v7v667g72727272727h697v7v7v7v7v7v7v6g7i7i7i7i7i7i7i6h7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v03em","7v7v7v7v606262626262617v7v7v7v7v7v7v7v7v66706i6i6i71697v7v7v7v7v7v7v7v7v66672c2c2c68697v7v7v7v7v606262626r672c6t2c686q626262617v66706i6i6i7r2c2c2c7q6i6i6i71697v66672c2c2c2c2c2c2c2cau2c2c68697v66672c2c2c2c2c2c2c2cau2c2c6o6p7v66672caf2c2c2c2c2c2cau2c2c3d393v66672c2c2c2c2c2c2c2cau2c2c7o7p7v66672c2c2c2c2c2c2c2cau2c2c68697v667g7272727b2e2e2e7a7272727h697v6g7i7i7i6b672c2c2c686a7i7i7i6h7v7v7v7v7v66672c2c2c68697v7v7v7v7v7v7v7v7v667g733t757h697v7v7v7v7v7v7v7v7v6g7i7j3k7l7i6h7v7v7v7v7v7v7v7v7v7v7v7v3v7v7v7v7v7v7v7v7v"}
rooms[7]={ "7v7v7v7v606263246562617v7v7v7v7v7v7v7v7v66706j3c6l71697v7v7v7v7v7v7v7v7v66672c2c2c68697v7v7v7v7v606262626r672c2c2c686q626262617v66706i6i6i7r2c2c2c7q6i6i6i71697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c2c2c2c2c2c2c2c2c68697v66672c2c2c7a7272727b2c2c2c68697v66672c2c2c686a7i6b672c2c2c68697v667g7272727h697v667g733t757h697v6g7i7i7i7i7i6h7v6g7i7j3k7l7i6h7v7v7v7v7v7v7v7v7v7v7v7v3v7v7v7v7v13ec13mi036h","606262626262617v606263246562617v66706i6i6i71697v66706j3c6l71697v6m6n2c2c2c6o6p7v6m6n2c2c2c68697v363s2c2c2c78797v76772c2c2c68697v7m7n2c2c2c7o7p7v7m7n2c2c2c68697v66672c2c2c68697v66672c2c2c68697v66672c2c2c68697v66672c2c2c68697v66672e2e2e68697v66672c2c2c68697v66672c2c2c686q626r672c2c2c68697v66672c2c2c7q6i6i6i7r2c2c2c68697v66672c2c2c2c2c2e2c2c2c2c2c68697v66672cbf2c2c2c2e2c2c2c2c2c68697v66672c2c2c2c2c2e2c2c2c2c2c68697v667g7272727272727272733t757h697v6g7i7i7i7i7i7i7i7i7i7j3k7l7i6h7v7v7v7v7v7v7v7v7v7v7v7v3v7v7v7v7v","606262626262617v606263246562617v66706i6i6i71697v66706j3c6l71697v66672e6t2e6o6p7v6m6n2c2c2c68697v66672c2c2c78797v76772caf2c68697v66672c2cbf7o7p7v7m7n2c2c2c68697v6667au7a727h697v66672c2c2c68697v6667au686a7i6h7v66672c2c2c68697v66672c68697v7v7v66672c2c2c68697v66672c686q62617v66672c2c2c68697v66672c7q6i716q626r672c2c2c68697v66672c2c2c7q6i6i6i7r2c2c2c68697v66672e2v2v2c2c2c2c2c2c2c2c68697v66672e2v2v2c2c2c2c2c2e2e2e68697v667g72727272727272727272727h697v6g7i7i7i7i7i7i7i7i7i7i7i7i7i6h7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v","606262626262613v3v3v3v3v3v3v3v3v66706i6i6i71693v3v3v3v3v3v3v3v3v66672c2c2c68693v3v3v3v3v3v3v3v3v66672c2c2c68693v606262626262613v66672c2c2c68693v66706i6i6i71693v66672c2c2c68693v66672c2c2c68693v6m6n2c2c2c686q626r672c2d2c68693v363s2c2c2c7q6i6i6i7r2c2c2c68693v7m7n2c2c2c2c2c2c2c2c2c2c2c68693v66672c2c2c2c2c2c2c2c2c2c2c68693v66672c2c2c2c2c2c2c2c2c2c2c68693v66672c2c2c2c2c2c2c2c2c2c2c68693v66672c2c2c2c2c2c2c2c2c2c2c68693v667g72727272733t75727272727h693v6g7i7i7i7i7i7j3k7l7i7i7i7i7i6h3v3v3v3v3v3v3v3v3v3v3v3v3v3v3v3v3v136611ei016m01mm"}
chests={}
for i=0,7 do
chests[i]={}
rooms[i][0]=rooms[i][4]
end
end
function lr(rm_x,rm_y,x,y,there_are_enemies)
d_it=54
string=rooms[rm_x][rm_y]
local i=1
for j=y,y+15 do
for k=x,x+15 do
local num1,num2=cti(cat(string,i)),cti(cat(string,i+1))
local num=num2+num1*32
mset(k,j,num%128+128)
mset(k+16,j,flr(num/128))
i+=2
end
end
acs,plr.sword,plr.tro,plr.bow={plr,hand},nil,nil
if there_are_enemies then
if rm_x==1 and rm_y==1 then
add_ac(ga:new({x=56,y=72}))
add_ac(ga:new({x=56,y=56}))
add_ac(bk:new({x=60,y=44}))
for i=0,keys*2 do
mset(23,10-i,0)
mset(24,10-i,0)
end
end
load_enemies(rm_x,rm_y)
for i=0,15 do
for j=0,15 do
tile=mget(i,j)
if tile==207 then
s=sw:new({x=i*8,y=j*8})
add(acs,s)
elseif tile==239 or tile==176 then
s=o_sw:new({x=i*8,y=j*8})
add(acs,s)
end
end
end
end
if bl_up then
sw_bl()
end
if (chests[rm_x][rm_y]) o_c(y)
end
function load_enemies(rm_x,rm_y)
m=rooms[rm_x][rm_y]
for i=513,#m,4 do
props={x=4*cti(cat(m,i+2)),y=4*cti(cat(m,i+3)),dif=cti(cat(m,i+1))}
a=sl:new(props)
if cat(m,i)=="0" then
a=gob:new(props)
end
a:st()
add(acs,a)
end
end
function _update60()
if ti then
if btnp(4) or btnp(5) then
ti,ti_count,tr_z=false,1,150
sfx(33)
end
return
end
if ti_count then
ti_count+=1
if (ti_count%4==0) apply_pal_pset(dpal)
if ti_count>16 then
poke(0x5f2c,0)
load_cr()
plr:animate_sp()
ti_count=false
end
return
end
if won then
won_t+=1
if won_t==16 then
apply_pal_pset(dpal)
if (sd<10) sd="0"..sd
end
return
end
if bd_c then
mset(5,bd_c,179)
mset(6,bd_c,180)
mset(21,bd_c,0)
mset(22,bd_c,0)
if (bd_c%1<0.05) sfx(37)
bd_c+=0.05
if bd_c>=11 then
bd_c=nil
end
return
end
tc+=1
if tc>=60 then
sd+=1
tc=0
if sd>=60 then
mi+=1
sd=0
end
end
if f_a then
if f_c%48==0 then
fs_cg=nil
if btnp(1) and #inv>=4  then
fs_cg=4
elseif btnp(0) and #inv>=4 then
fs_cg=-4
elseif btnp(4) then
f_a=false
if f_c==0 then
f_r,m1,m2=29,26,27
elseif f_c==48 then
f_r,m1,m2=31,27,28
else
f_r,m1,m2=30,26,28
end
d_it=f_r
rfi(m1)
rfi(m2)
sci()
elseif btnp(5) then
f_a=false
end
end
if (fs_cg) f_c=(f_c+fs_cg)%144
return
end
ins=mx>3
if (up_trs()) return
if dap then
up_death_animation()
else
if up_it_menu() then
if not gi then
if not d_it2 then
for a in all(acs) do
a:up()
if a.dead then
del(acs,a)
end
end
else
d_it=d_it2
d_it2=nil
sci()
end
else
gi:up()
end
sort_acs_by_y()
if btnp(5) then
it_menu_open=true
end
end
up_hp()
local num_enemies=0
for i in all(acs) do
if i.is_en then
num_enemies+=1
end
end
if show_hp<=0 then
dap,dapc=true,0
deaths+=1
music(-1)
sfx(15)
end
end
end
function sci()
gi=get_it:new()
music(12)
end
function rfi(num)
for i in all(inv) do
if i.s-32==num then
del(inv,i)
end
end
end
function go_to_zero(num,aps)
if num>aps then
return num-aps
elseif num<-aps then
return num+aps
end
return 0
end
function up_trs()
local sx,sy,sz=tr_x,tr_y,tr_z
tr_x,tr_y=go_to_zero(tr_x,6),go_to_zero(tr_y,6)
if tr_z>0 then
tr_z-=6
if tr_z==150 then
position_plr()
cam_x,cam_y=-4-cam_x,-4-cam_y
end
if tr_z<=0 then
load_cr(true)
if ins then
play_music(5)
else
play_music(0)
end
end
end
return sx!=tr_x or sy!=tr_y or sz!=tr_z
end
function position_plr()
for i=0,15 do
for j=0,15 do
local tile=mget(i,j)
if tile==182 then
plr.x,plr.y=i*8,j*8+2
elseif tile==205 then
plr.x,plr.y=i*8-4,j*8+4
end
end
end
plr.dir,plr.sdir=0.75,0.75
plr:animate_sp()
end
function up_death_animation()
dapc+=1
if dapc<=16 then
if dapc%4==0 then
apply_pal_pset(dpal)
end
elseif dapc==32 then
tr_z,hp,dapc,dap,plr.x,plr.y,plr.hit_t,plr.fk_t,cam_x,cam_y,mx,my=150,max_hp,0,false,60,64,0,0,0,0,1,3
load_cr()
end
end
function add_ac(a)
add(acs,a)
end
function sort_acs_by_y()
new_acs={}
for i=1,#acs do
lowest=acs[1]
for j in all(acs) do
if j.y<lowest.y then
lowest=j
end
end
add(new_acs,lowest)
del(acs,lowest)
end
acs=new_acs
end
function bomb_destroy(x,y)
for i=flr8(x-12),flr8(x+12) do
for j=flr8(y-12),flr8(y+12) do
if i>=0 and j>=0 and i<16 and j<16 and fget(mget(i+mx_c,j+my_c),3) then
mset(i+mx_c,j+my_c,144)
mset(i+mx_c+16,j+my_c,0)
end
end
end
end
function d_d(d1,d2)
dif=abs(d1-d2)
if dif>0.5 then
dif=1-dif
end
return dif
end
function clamp(val,min,max)
if (val>max) return max
if (val<min) return min
return val
end
function is_solid(x,y)
x,y=clamp(x,0,cam_w-4),clamp(y,0,cam_h-4)
solidity=mget(16+x/8,my_c+y/8)
return solidity!=0
end
function iaf(x,y)
if (x<0 or y<0 or x>cam_w or y>cam_h) return true
solidity=mget(16+x/8,my_c+y/8)
return solidity!=1
end
function up_it_menu()
if it_sw_oft==0 then
if it_menu_open then
imoc=min(14,imoc+2)
else
imoc=max(-1,imoc-2)
end
if (imoc<=-1) return true
cam_x,cam_y=(imoc)/2,-(imoc)/2
if ins then
cam_x-=4
cam_y-=4
end
if btnp(4) or btnp(5) then
it_menu_open=false
end
if #inv>1 then
if btnp(3) then
it_sw_oft=-0.5
elseif btnp(2) then
it_sw_oft=0.5
end
end
else
if it_sw_oft<0 then
it_sw_oft-=0.15
else
it_sw_oft+=0.15
end
if it_sw_oft<=-1 then
it_sw_oft=0
next_it()
elseif it_sw_oft>=1 then
it_sw_oft=0
prev_it()
end
end
return false
end
function up_hp()
if show_hp<hp then
show_hp+=1
elseif show_hp>hp then
show_hp-=1
end
if prev_hp_time==0 then
if show_hp<prev_hp then
prev_hp-=0.5
else
prev_hp=show_hp
end
else
prev_hp_time-=1
end
hp=clamp(hp,0,max_hp)
show_hp=max(show_hp,0)
end
function dam_hp(amount)
hp-=amount
prev_hp_time=60
end
function sw_bl()
for i=0,15 do
for j=0,15 do
tile=mget(i,j)
if tile==222 then
mset(i,j,223)
mset(i+16,j,0)
elseif tile==223 then
mset(i,j,222)
mset(i+16,j,2)
end
end
end
end
function o_c(y)
for i=0,15 do
for j=y,y+15 do
tile=mget(i,j)
if tile==220 then
mset(i,j,112)
elseif tile==221 then
mset(i,j,113)
end
end
end
end
function p_w(s,dir,base)
s.f=d_d(0,dir)>0.25
s.vf=d_d(0.25,dir)>0.25
s.s=base+1
if d_d(0.25,dir)<0.0625
or d_d(0.75,dir)<0.0625 then
s.s=base+2
end
if d_d(0,dir)<0.0625
or d_d(0.5,dir)<0.0625 then
s.s=base
end
end
function plr_init()
plr_head=nps(1,0,-4)
plr_arm1=ns(6)
plr_arm2=ns(6)
plr_body=xs:new()
plr=ac:new({x=60,y=64,h=7,max_vel=0.9,sdir=0.75,dir=0.75,
aro=0.5,arm_length=4.5,aas=true,
hit_t=0,fk_t=0,holes_dist=0,
sp={
plr_body,
plr_arm1,
plr_arm2,
plr_head
}})
add_ac(plr)
function plr:up()
if self.hit_t<=0 then
if self.fk_t<=0 then
for i in all(self.sp) do
i.fk=false
i.xi=false
end
end
self.acc=0.4
local old_dir=self.dir
if btn(0) then
if btn(2) then
self.dir=0.375
elseif btn(3) then
self.dir=0.625
else
self.dir=0.5
end
elseif btn(1) then
plr_head.f=false
if btn(2) then
self.dir=0.125
elseif btn(3) then
self.dir=0.875
else
self.dir=0
end
else
if btn(2) then
self.dir=0.25
elseif btn(3) then
self.dir=0.75
else
self.acc=-0.6
end
end
if self.aas then
self.aro+=self.vel/100
if self.aro>=0.6 then
self.aas=false
end
else
self.aro-=self.vel/100
if self.aro<=0.4 then
self.aas=true
end
end
if self.vel==0 then
self.arm_length=4.5
self.aro=0.5
end
self.vel-=d_d(self.dir,old_dir)
it_id=inv[1].id
if it_id=="sword" and can_use_it() then
if self.sword==nil then
self.sword=new_sword(self.dir)
self.sdir=self.dir
add_ac(self.sword)
sfx(1)
elseif self.sword.l==0 then
self.sword.move_spd=-self.sword.move_spd
self.sword.end_frames=6
self.sword.l=10
self.sword.dist=10
sfx(1)
end
elseif it_id=="teleport rod" and can_use_it() then
if self.tro==nil then
self.sdir=flr(self.dir/0.25)*0.25
self.tro=new_tro(self.dir)
add_ac(self.tro)
sfx(1)
end
elseif it_id=="bow and arrows" and can_use_it() and not self.bow then
self:do_bow(0)
elseif it_id=="bomb arrows" and can_use_it() and not self.bow then
self:do_bow(1)
elseif it_id=="teleport arrows" and can_use_it() and not self.bow then
self:do_bow(2)
elseif can_use_it() and (it_id=="bombs" or it_id=="telebombs") then
local b=bomb:new({x=self.x,y=self.y})
if it_id=="telebombs" then
b=telebomb:new({x=self.x,y=self.y})
end
b:st()
add_ac(b)
inv[1].use_t=90
inv[1].use_t_max=90
end
if (self.sword and self.sword.dead) self.sword=nil
if (self.tro and self.tro.dead) self.tro=nil
if (self.bow and self.bow.dead) self.bow=nil
if not self.sword and not self.tro and not self.bow and self.hit_t==0 then
self.sdir=self.dir
end
for i in all(inv) do
if i.use_t then
if i.use_t>0 then
i.use_t-=1
else
i.use_t=nil
end
end
end
if self.fk_t<=0 then
for i in all(acs) do
if i.is_en and self:inta(i) and i.dam>0 then
self:p_a(i)
self.dir,self.vel,self.hit_t,self.fk_t,self.acc=0.5,2,15,60,0.5
dam_hp(i.dam)
sfx(32)
break
end
end
end
else
self.hit_t-=1
for i in all(self.sp) do
i.fk=true
end
if self.hit_t==0 then
self.dir=self.sdir
end
end
if self.fk_t>0 then
self.fk_t-=1
for i in all(self.sp) do
i.fk=true
end
end
self:animate_sp()
ac.up(self)
self:clip_out()
if not self.set_entry and self.x>10 and self.y>10 and self.x<cam_w-18 and self.y<cam_h-18 then
self.entry_x,self.entry_y,self.entry_dir,self.set_entry=self.x,self.y,self.dir,true
end
self:fall_down_holes()
self.holes_dist=0
self:tr_rooms()
if self.sdir==0.25 and self.y%8==0 then
local tile=mget(flr8(self.x+4),self.y/8-1)
if tile==220 or tile==221 then
o_c(0)
sci()
chests[mx][my]=true
elseif tile==160 or tile==212 or tile==254 then
self.y+=0.1
if f_r then
rfi(f_r)
f_r,self.vel,d_it,d_it2=nil,0,m1,m2
sci()
else
self.vel,f_a=0,true
if (not got[26]) f_c=48
if (not got[27]) f_c=96
end
end
end
end
function plr:do_bow(arrow_num)
self.sdir=flr(self.dir/0.25)*0.25
self.bow=new_bow(self.sdir,arrow_num)
add_ac(self.bow)
end
function can_use_it()
return btnp(4) and not inv[1].use_t
end
function plr:fall_down_holes()
num_holes=0
for i=-1,1,2 do
for j=-1,1,2 do
tile=mget((self.x+3+i*self.holes_dist)/8,(self.y+3+j*self.holes_dist)/8)
if tile==206 then
num_holes+=1
end
end
end
if num_holes>=2 then
if hp>3 then
self.dead=true
add_ac(pf:new({x=self.x,y=self.y}))
end
dam_hp(3)
self.hit_t,self.fk_t,self.vel,self.acc=15,60,0,0
sfx(16)
end
end
function plr:tr_rooms()
if self.y>cam_y+cam_h-4 then
load_cr_below()
self.y-=cam_h
my+=1
tr_y=128
load_cr(true)
elseif self.y<cam_y-4 then
load_cr_below()
self.y+=cam_h
my-=1
tr_y=-128
load_cr(true)
elseif self.x>cam_x+cam_w-4 then
load_cr_below()
self.x-=cam_w
mx+=1
tr_x=128
load_cr(true)
elseif self.x<cam_x-4 then
load_cr_below()
self.x+=cam_w
mx-=1
tr_x=-128
load_cr(true)
else
tile=mget((self.x+4)/8,(self.y+4)/8)
if self.y%8==0 and tile==182 then
load_cr_below()
mx+=4
tr_z=300
music(-1)
sfx(19)
load_cr()
elseif tile==205 then
load_cr_below()
mx-=4
tr_z=300
music(-1)
sfx(19)
load_cr()
end
end
end
function plr:animate_sp()
local head_dir=self.sdir
plr_head.s=3
plr_head.f=false
if head_dir>0.8125 and head_dir<0.9375 then
plr_head.s=2
elseif head_dir>0.6875 then
plr_head.s=1
elseif head_dir>0.5625 then
plr_head.s=2
plr_head.f=true
elseif head_dir>0.4375 then
plr_head.f=true
elseif head_dir>0.3125 then
plr_head.s=4
plr_head.f=true
elseif head_dir>0.1875 then
plr_head.s=5
elseif head_dir>0.0625 then
plr_head.s=4
end
local arm_dif=0.35
local length=self.arm_length
local arm1_an=(self.aro+self.sdir-arm_dif)%1
plr_arm1.x=flr(3+cos(arm1_an)*length)
plr_arm1.y=flr((5+sin(arm1_an)*length)/2.5)
if self.hit_t==0 then
plr_arm1.xi=(d_d(0.75,arm1_an)>0.3)
end
local arm2_an=(self.aro+self.sdir+arm_dif)%1
plr_arm2.x=flr(3+cos(arm2_an)*length)
plr_arm2.y=flr((5+sin(arm2_an)*length)/2.5)
if self.hit_t==0 then
plr_arm2.xi=(d_d(0.75,arm2_an)>0.3)
end
if not plr_arm2.xi then
plr_arm2.xi=self.sword!=nil or self.tro!=nil or self.bow!=nil
end
if not plr_arm1.xi then
plr_arm1.xi=self.bow!=nil and self.bow.l==-1
end
plr_body.f=self.aro>0.5
plr_body.s=0
if abs(self.aro-0.5)>0.05 then
plr_body.s=16
end
end
function plr:move_x()
local st_y=self.y
list=ml
if (plr.dir*4)%1!=0 then
list={0}
end
for i in all(list) do
self.y=st_y+i
if (ac.move_x(self)) return
end
self.y=st_y
end
function plr:move_y()
local st_x=self.x
list=ml
if (plr.dir*4)%1!=0 then
list={0}
end
for i in all(ml) do
self.x=st_x+i
if (ac.move_y(self)) return
end
self.x=st_x
end
hand=ac:new({sp={nps(6,4,4)}})
function hand:up()
if plr.sword!=nil then
self.x=plr.x+5*cos(plr.sword.dir)-2
self.y=plr.y+4*sin(plr.sword.dir)-2
elseif plr.tro!=nil then
self.x=plr.x+5*cos(plr.tro.dir)-2
self.y=plr.y+4*sin(plr.tro.dir)-2
else
self.x=-2000
end
end
add_ac(hand)
end
function new_sword(direc)
local sb=ns(48)
sword=ac:new({l=11,dist=10,end_frames=6,dir=0,rel_dir=-0.2,
move_spd=0.035,sp={sb},bl=sb})
function sword:up()
if self.l>0 then
self:swing()
else
if self.end_frames>0 then
self.end_frames-=1
else
self.dead=true
end
end
self:be_plr_sword()
p_w(self.bl,self.dir,48)
for i in all(acs) do
if i:inta(self) then
i:hit(plr,2)
end
end
end
return sword
end
function new_tro(direc)
local sb=ns(51)
teleport=ac:new({l=6,dist=9,end_frames=6,dir=0,rel_dir=-0.2,
move_spd=0.035,sp={sb},bl=sb})
function teleport:up()
local bl=self.bl
local can_warp=not is_solid(self.x+4,self.y+4)
if self.l>0 then
self:swing()
else
if self.end_frames>0 then
self.end_frames-=1
elseif self.end_frames==0 then
self.sp=copy_sp(plr.sp)
add(self.sp,bl)
self.end_frames=-1
elseif not btn(4) then
self.dead=true
if can_warp then
wrpt(self.x,self.y)
sfx(6)
end
plr.dir=plr.sdir
end
end
for i in all(self.sp) do
if i!=bl then
if can_warp then
i.pal=grpal
else
i.pal=drpal
end
end
end
self:be_plr_sword()
p_w(bl,self.dir,51)
if self.l==0 then
for i in all(self.sp) do
i.fk=true
end
sb.fk=false
local px,py=plr.x,plr.y
if plr.sdir==0 then
self.x,self.y,sb.x=px+16,py,-8
elseif plr.sdir==0.25 then
self.x,self.y,sb.y=px,py-16,8
elseif plr.sdir==0.5 then
self.x,self.y,sb.x=px-16,py,8
elseif plr.sdir==0.75 then
self.x,self.y,sb.y=px,py+16,-8
end
end
end
return teleport
end
function wrpt(x,y,a)
if (not a) a=plr
x,y=clamp(x,0,cam_w-8),clamp(y,0,cam_h-8)
if (is_solid(x+4,y+4)) return false
if a==plr then
for i=0,20 do
add_ac(
exn:new({x=a.x+rnd(7),y=a.y+rnd(12)-4,
size=rnd(5),col=6+rnd(2)})
)
end
end
a.x,a.y,a.holes_dist=x,y,1.5
return true
end
function new_bow(direc,arrow_type)
local sb=ns(32)
local cd,ar=30,arrow:new({dir=direc})
if arrow_type==1 then
ar=b_a:new({dir=direc})
cd=120
elseif arrow_type==2 then
ar=t_a:new({dir=direc})
cd=90
end
add_ac(ar)
bow=ac:new({l=-1,dist=4,dir=direc,
move_spd=0.035,sp={sb},bl=sb,
arrow=ar,cd=cd})
function bow:up()
local bl=self.bl
if self.l>0 then
self.l-=1
elseif self.l==0 then
self.dead=true
plr.dir=plr.sdir
elseif not btn(4) then
self.l=6
self.dist-=2
self.bl.s+=1
self.arrow.gng=true
inv[1].use_t=self.cd
inv[1].use_t_max=self.cd
sfx(4)
end
for i in all(self.sp) do
if i!=bl then
if can_warp then
i.pal=gpal
else
i.pal=drpal
end
end
end
self:be_plr_sword()
bl.f=d_d(0,self.dir)>0.25
bl.vf=d_d(0.25,self.dir)>0.25
if self.l<0 then
bl.s=34
if d_d(0.25,self.dir)<0.0625
or d_d(0.75,self.dir)<0.0625 then
bl.s=34
end
if d_d(0,self.dir)<0.0625
or d_d(0.5,self.dir)<0.0625 then
bl.s=32
end
self.arrow.x=self.x
self.arrow.y=self.y+0.01
if self.dir==0 or self.dir==0.5 then
self.arrow.y+=3
else
self.arrow.x+=2
end
end
end
return bow
end
function next_it()
for i=1,#inv do
inv[i-1]=inv[i]
end
inv[#inv]=inv[0]
inv[0]=nil
end
function prev_it()
for i=2,#inv do
next_it()
end
end
function copy_sp(list)
local nl={}
for k,v in pairs(list) do
nl[k]=v:new()
end
return nl
end
function cat(s,i)
return sub(s,i,i)
end
function cti(c)
for i=0,31 do
if cat("0123456789abcdefghijklmnopqrstuv",i+1)==c then
return i
end
end
end
function s_t_a(s)
-- a={}
-- for i=1,#s+1 do
-- add(a,cti(cat(s,i)))
-- end
a=split(s)
return a
end
grpal=s_t_a("0,3,5,3,5,5,6,7,11,11,11,11,11,6,6,7")
opal=s_t_a("0,2,5,4,5,5,6,7,9,9,9,9,9,6,6,7")
gpal=s_t_a("0,5,5,5,5,5,7,7,7,7,7,7,7,7,7,7")
drpal=s_t_a("0,2,5,2,5,5,6,8,8,8,8,8,8,6,6,8")
dpal=s_t_a("0,0,0,5,2,0,5,6,2,4,9,3,1,5,2,15")
function _draw()
if ti_count then return end
if won and won_t>2 then
if won_t>64 then
print("      congratulations!\n\n       you have found\n     the book of truth!\n\n\n\n\n\n\n\n\n\n      your time: " .. mi .. ":" .. sd .."\n         deaths: "..deaths,8,14,7)
end
return
end
if dap and dapc>=4 then
plr:dw()
else
cls()
local add_x,add_y=0,0
local is_tr=tr_x!=0 or tr_y!=0 or tr_z>150
if is_tr then
my_c=16
if tr_y>0 then
add_y=128
elseif tr_y<0 then
add_y=-128
end
if tr_x>0 then
add_x=128
elseif tr_x<0 then
add_x=-128
end
camera(cam_x-tr_x+add_x,cam_y-tr_y+add_y)
dw_map()
my_c=0
end
camera(cam_x-tr_x,cam_y-tr_y)
if (tr_z<=150) dw_map()
for a in all(acs) do
a:dw()
end
if (gi!=nil) gi:dw()
if is_tr then
my_c=16
camera(cam_x-tr_x+add_x,cam_y-tr_y+add_y)
dmtl()
my_c=0
end
camera(cam_x-tr_x,cam_y-tr_y)
if (tr_z<=150) dmtl()
camera()
dw_it_menu()
dw_hp()
if ti then
cls()
for i=0,63 do
for j=0,31 do
pset(i,j,mget(i,j))
pset(i,j+32,mget(i+64,j))
end
end
end
if tr_z>0 then
rectfill(tr_z-172,0,tr_z,128,0)
end
end
if f_a then
rectfill(0,68,127,100,0)
s="          fusion altar\n\n\n\n 🅾️ - fuse items   ❎ - go back"
if  #inv>=4 then
s="          fusion altar\n\n  ⬅️                       ➡️\n\n 🅾️ - fuse items   ❎ - go back"
end
print(s,0,69,7)
camera(f_c,0)
for i=0,5 do
spr(106+i,36+48*i,80)
end
end
end
function r_p()
pal()
palt(0,false)
palt(14,true)
end
function dw_map()
map(mx_c,my_c,map_dw_x_c,map_dw_y_c,16,16)
end
function dmtl()
for x=mx_c,mx_c+15 do
for y=my_c,my_c+15 do
local til=mget(x,y)
local xv,yv=(x-mx_c)*8,(y-my_c)*8
if til==158 then
spr(142,xv,yv-8)
elseif til==159 then
spr(143,xv,yv-8)
end
if y==my_c+15 then
til1=mget(x-1,y)
til2=mget(x+1,y)
if (til1==159 or til1==158 or x==mx_c) and (til2==159 or til2==158 or x==mx_c+15) then
if til==159 then
spr(142,xv,yv)
elseif til==158 then
spr(143,xv,yv)
end
end
end
end
end
if ins or tr_z>150 then
rectfill(-4,-4,128,-1,0)
rectfill(-4,-4,-1,128,0)
end
map(mx_c,my_c,map_dw_x_c,map_dw_y_c,16,16,128)
end
function dw_it_menu()
local a_m=127-imoc
rectfill(0,-1,127,imoc,0)
rectfill(128,0,a_m,127,5)
line(a_m,0,a_m,127,7)
line(0,imoc,a_m,imoc,7)
name=inv[1].name
print(name,110-4*#name,imoc-10,7)
rectfill(115,1,126,12,0)
pos=0
for i in all(inv) do
x=117
if pos>0 then
x=131-imoc
end
y=((pos+it_sw_oft)*128/#inv+3)%128
rectfill(x-1,y-1,x+8,y+8,0)
if i.use_t then
fraction=(1-(i.use_t/i.use_t_max))*9
rectfill(x-1,y+fraction,x+8,y+8,13)
end
spr(i.s,x,y)
pos+=1
end
rect(115,1,126,12,1)
for i=1,keys do
spr(55,i*8-6,imoc-11)
end
end
function dw_hp()
local i3,i7=imoc+3,imoc+7
rectfill(2,i3,3+max_hp,i7,0)
rectfill(2,i3,2+prev_hp,i7,10)
rectfill(2,i3,2+show_hp,i7,8)
rectfill(2,imoc+6,2+show_hp,i7,2)
rect(2,i3,3+max_hp,i7,5)
end
function apply_pal(p)
for i=0,15 do
pal(i,p[i+1],1)
end
end
function apply_pal_pset(p)
for x=0,127 do
for y=0,127 do
local col=pget(x,y)
pset(x,y,p[col+1])
end
end
end