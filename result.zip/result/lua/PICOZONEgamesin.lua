--picozone
--17-in-1 collab cart
cartdata"17in1jam"
function nx(i)
j=0::_:: 
cls()p(nc[i],22,35,15)p("your score: "..nb.." ❎",28,75)flip()m()
if(not btn(5))j=1 goto _
if(j<1)goto _
if (nb>nh) poke4(0x5e01,nb)
warp()
j=0::✽:: 
cls()p("  picozone - the 16 anomalies\n\n\n\n      brought to you by:",3,5,15)
p("         elneil\n\ndollarone    viza\nunclesporky  platformalist\nhodge        johanpeitz\nkometbomb    p01 / gruber",14,42)
p("tombrinton   2darray\nelgregos     liquidream\nenargy       egordorichev\n\n\n\n  thanks for playing!\n",14,78)
rect(0,0,127,127)
p("♥", 100, 114,8)
flip()
if(not btn(5))j=1 goto ✽
if(j<1)goto ✽
run()
end
function _init()
warp()
b={} -- planet
c={} -- flame
e=all
f=flr
g=128 -- gas
l=0 -- xtals
m=camera
n=17 -- game#
o={} -- xtals
p=print
q={} -- alien
r=rnd
s=0 -- spd
x=0
y=0
na={}for i=1,16 do add(na,i)end
nb=0 -- score
nc={" all anomalies found!\n\nyou are the winner  😐","you're out of fuel!\n\n please try again."}
nd={}
a=r() -- ang
nh=peek4"0x5e01"
-- planets
for i=1,4 do
k=(i-1%2)*.125
for j=0,3 do
h=na[f(r(#na))+1]del(na,h)
add(b,{i*cos(k+j/4)*110,i*sin(k+j/4)*110,f(r(15)+1),h})
end
end
-- xtals
for i in e(b) do
for j=0,2 do
h=(r()+j)*.33
k=r(20)+30
add(o,{i[1]+k*cos(h),i[2]+k*sin(h)})
end
end
-- aliens
for i in e(o)do
for j=0,2 do
h=(r()+j)*.33
k=r(8)+10
add(q,{i[1]+k*cos(h),i[2]+k*sin(h)})
end
end
--stars
for i=1,16 do add(nd,{f(r(128)),f(r(128))})end
ref={q,o}
end
function _update()
	u[n]()	
end
function _draw()
	d[n]()
end
--------------------init functions
t={
function() 
mx,mx2,mbf,mlx,mt,mps,memx,mtx,mbx,mby,mvx,mvy=56,56,{},0,0,{},0,0,64,32,rnd()>0.5 and -1 or 1,1
end,-- lateris
--------------------
function() 
fq,fh,fr,fa,ft,fv,fs=0,0,{},1,0,{},143
fm='press 🅾️ to fish!'
for i=1,15 do make_wave() end
end,-- fishing
--------------------
function() 
lpx,lpy,ltc,lpm=7,6,f(r"3")+3,0
for i=0,31 do
for j=0,31 do
mset(i,j,mget(i%16+32,j%16))
end
end
lmx,lmy=f(r"16"),f(r"16")
repeat
ltx,lty=f(r"12")+lmx+2,f(r"12")+lmy+2
until mget(ltx,lty)==0
while mget(lpx+lmx,lpy+lmy)>0 do
lpy-=1
end
end,-- treasure
--------------------
function() g_lvl=0 g_init() end,-- gregos
--------------------
function() 	ww={{x=35,y=30},{x=30,y=30}}
wh,wt=ww[1],ww[2]
wh.c,wax,way,wtime=wt,64,68,90
music(8)end,-- worm
--------------------
function()   tg,tx,ty,tv,td,tcc,tcn,ts,tb,tn=false,8,8,30,60,0,3+ceil(rnd"6"),0,{},{} end,--bug collector
--------------------
function() 
music(16)pt,pn,pm=0,0xfffe,1
end,--dirt
--------------------
function() 	
ka,kgo,kar,krv,kx,ky,kdx,kdy=.25,0,.25,0,56,330,0,0
for j=0,47 do
for i=0,31 do
local t=sget(i/2+64,j/2+64)
local ft=sget(t%4*2+72+i%2,88+flr(t/4)*2+j%2)
mset(i,j,ft>0 and ft%4+flr(ft/4)*16+136)
end
end
end,--thrust
--------------------
function()  at,ad,ag,al=0xffff,0,0,30 end,--rungeon
--------------------
function()  
palt(0,false)
palt(3,true)
music"4"
dst,dend,dbob,dbd,dbt,dscore,dnum,dd,dpigs=
75,100,8,0,false,0,0,0,{}
for i=1,4 do
dip(i)
end
dnd()
end,--birb
--------------------
function() 
ea,et,etm,es,exd,eg,ew,ebt,epy,epd,eps=1,80,80,0,.25,0,{},false,64,0,164
sfx"39"
for h=2,6 do
er(h*20+7)
end
end,--flop
--------------------
function()palt(0,false)palt(11,true)ua,ut,up,uc={},0,0,0
ua[1]={130,60,60,30}for h=2,6 do
ua[h]={131,128,128,149}end
music"55"end,--pants
function()sx,sy,sl,ss,sw=120,8,1,false,128
palt(0,false)palt(14,true)music"52"end,
--rpg
function()rt,rl,rp,rd,rb,rs=45,1,rw,101,0xffff,"         ⬆️ to draw gun\n         ❎ to shoot"end,
--alien
function()cls"1"dx,dm,dp,dd,dq,dw,ds,dc,dl,dr,du=60,24,212,0,60,700,0,{},{},{},{1,10,9,15,4,3,11,6,13,2,8,0}for di=0,128 do dc[di],dl[di],dr[di]=60,20,111 end;music"60"
end,--lake
function()nl,nm,nn,np,nq,nr,ns,nt,nu,nw,nz=3.25,0,19,{{128}},0,{},0,1,0,{},{"⬅️","➡️","⬆️","⬇️"}sfx(56,3)end,
--teapot
}
--------------------update functions
u={
function() end, -- lateris (no code)
--------------------
function()
if btnp"4" then
if fa>=13 then
pal()
ret(min(fh,128))
end
if fn then
fn,fr[fa],fm,fs=false,3,"got it! ♥",159
fh+=11
sfx"23"
fa+=1
elseif not fg then
fg,ft,fm,fs=true,60+rnd"3"*60,'',143
else
fn=false
fg=false
fr[fa]=8
fa+=1
fm,fs="too soon! :(\npress 🅾️",158
sfx"22"
end
end
if (fg or fn) ft-=1
if ft<=0 then
if fg then
fg,fn,ft=false,true,15
elseif fn then
fr[fa],fn,fm,fs=8,false,"miss!",158
fa+=1
sfx"22"
end
end
if fe then
fe-=1
if fe<=0 then
fm,fe,fs=nil,nil,143
end
end
end,-- fishing
--------------------
function()
local x,y=lpx,lpy
if lpm>1 then
lt-=1 
if lpm<4 then
if (lt%5==0) lpm+=1 
if (lpm>3) lpm=2
end
if lt<1 and lpm>1 and lpm<4 then
lpm=0
sfx(0xffff,0)
if ltx==x+lmx and lty==y+lmy then
done(128,"found treasure!")
else
ltc-=1
if ltc>0 then
lpm,lt,lrs=4,50,126
if ltx==x+lmx then
lrs=127
elseif lty==y+lmy then
lrs=125
end
if (ltx>x+lmx) lrfx=true
if (lty<y+lmy) lrfy=true
else
done(0,"  time's up!")
end
end
elseif lt<1 then
lpm=0
end
else
lrfx,lrfy,lpm=false,false,0
lpm=0 
for k=0,1 do
if(btnp(k))x+=k*2-1
if(btnp(k+2))y+=k*2-1
end
if (btnp"4") lpm=2 lt=50 sfx(13,0)
if not fget(mget(lmx+x,lmy+y),0) then 
x,y=mid(x,15),mid(y,15)
if (x+y!=lpx+lpy) lpm=1 sfx"12"
lpx,lpy=x,y
end
end
end,-- treasure
--------------------	
function()
if(btn"0")g_pl.a+=.02
if(btn"1")g_pl.a-=.02
if(btn"4"and g_pll>5)add(g_mobs,{t=1,x=g_bx,y=g_by,r=1,a=g_pl.a,s=2,d=50})g_pl.s-=.2 g_pll-=1 sfx(26)
if(btnp"5")ret(g_lvl*7)
g_pl.s*=.98
cls(g_colr"0")
for mobn=#g_mobs,1,-1 do
local mob=g_mobs[mobn]
for m2=#g_mobs,mobn+1,-1 do
local mob2=g_mobs[m2]
local ts=mob.t+mob2.t
local dx,dy=mob.x-mob2.x,mob.y-mob2.y
if mob.r+mob2.r>=sqrt(dx*dx+dy*dy)then
if(ts>=6)sfx"25"g_pll-=1
if ts==3 then
sfx"24"
mob.r*=.5
if mob.r<2 then
del(g_mobs,mob)
else
mob2.r,mob2.t,mob2.s=mob.r,2,mob.s
end
end
end
end
mob.x+=cos(mob.a)*mob.s
mob.x%=128
mob.y+=sin(mob.a)*mob.s
mob.y%=128
circfill(mob.x,mob.y,mob.r,g_colr(mob.t))
if mob.t==1 then
mob.d-=1
if(mob.d<0)del(g_mobs,mob)
end
end
g_bx,g_by,g_pll=g_pl.x+cos(g_pl.a)*g_pl.r*1.5,g_pl.y+sin(g_pl.a)*g_pl.r*1.5,mid(0,g_pll,100)
circfill(g_bx,g_by,2,g_colr"1")
p("ishiharoid   level "..g_lvl.."\n\n⬅️➡️🅾️play   ❎quit",13,105,g_colr"3")
if(#g_mobs<2)g_lvl+=1 g_init()sfx"27"
if(g_pll<=0)g_init()
rect(13,111,13+g_pll,115)
g_pll+=.1
end, -- gregos
--------------------
function()
wtime-=.0333
if(wtime<0xfffd)ret(#ww*3.5)
if(wtime<0)return
cls"1"
map"64"
if(abs(wh.x-wax)+abs(wh.y-way)<5)repeat wax=rnd"128"way=rnd"128"until 0==mget(wax/8+64,way/8)wn={x=wt.x,y=wt.y+1}add(ww,wn)wt.c,wt=wn,wn
local ix,iy=0,0
if (btn"0") ix-=.28
if (btn"1") ix+=.28
if (btn"2") iy-=.28
if (btn"3") iy+=.28
for k=1,6 do
wh.x+=ix
wh.y+=iy
for i,w in pairs(ww) do
for j=i-1,1,0xffff do
if (ww[j].x<w.x) break
ww[j+1],i=ww[j],j
end
ww[i]=w
end
for i,w in pairs(ww) do
local wx,wy,c=w.x,w.y
for j=i-1,#ww do
c=j==i and w.c
if j>i then
c=ww[j]
if(c.x>wx+5)break
end
local dx,dy
if (mget(wx/8+64,wy/8)>0)dx=wx%8-4 dy=wy%8-4
if (c) dx=c.x-wx dy=c.y-wy
if dx then
local d=sqrt(dx*dx+dy*dy)
local t1=j==i and .2 or .5
if d<5 or i==j then
//d=sqrt(d)
local e=(c and d*.5-2.5 or 2)/d
dx*=e
dy*=e
if(c)c.x-=dx-dx*t1 c.y-=dy-dy*t1
w.x+=dx*t1
w.y+=dy*t1
end
end
end
spr(w==wh and 81 or 65,wx-3,wy-3)
end
end
spr(66,wax-2,way-2)
?"snakeworm (2darray)        ⧗"..flr(wtime),2,121,15
end,-- worm
--------------------
function()
tv+=1
if tv>29 then
td-=1
local b={}
::redo::
b.x,b.y=3+flr(rnd"10"),4+flr(rnd"8")
for i=1,#tb do
if((tb[i].x==b.x and tb[i].y==b.y) or (b.x==tx and b.y==ty)) goto redo
end
tv,b.t,b.tt=0,0,30+flr(rnd"120")
add(tb,b)
end
if(td<1)tg=true
if(td<0xfffe) ret(ts*8)
if not tg then
if(tcc==tcn)sfx"10";ts+=1;tn={};tcn=3+ceil(rnd"6")
if(btnp"1" and tx<12)tx+=1
if(btnp"0" and tx>3)tx-=1
if(btnp"3" and ty<11)ty+=1
if(btnp"2" and ty>4)ty-=1
if(btnp"5") tn={}
if(btnp()>0) sfx"11"
end
end,--bug collector	
--------------------
function()
m(0xffc0,0xffc8)ps=f(128-pt/100)
if(pm>5)rectfill(0xffc0,0xffd0,64,0xfff0,0)sspr(56,32,8,8,0xffc8,0xffd2,32,32)pp("\\o/ you won $"..ps.."\n\n❎ to continue",0xfff0,0xffd8,7)return btnp"5"and ret(ps)
cls"4"for z=0xffc0,192 do
i=z/256w=sin(i+pm%2*i)v=32+16*w+8*sin(i*3)-4*sin(i*(2+pm))circ(v*cos(i),v*sin(i),7+3*w,5)
?"ˇ",64*sin(v),z
v+=16+v%.4*139spr(68+z%2,v*cos(i),v*sin(i)-8)end
v=mget(pget(px,py),16)/3-4
if pn<pm then
pn+=.02 ptl,pl,pgs,pa,px,py,pb=1337,1,{},.2,32,0,0
else
sfx(16,3,pt%6+v*8)pt+=1ptl+=1py-=v*cos(pa)px+=v*sin(pa)
if(btn"0")pa+=.01
if(btn"1")pa-=.01
end
spr(72,44,0xfff8)spr(72,16)pgs[ptl]={a=pa,x=px,y=py}for i=2674,0,0xfac7 do
h=pgs[ptl-i] if(h!=nil)pal(8,i<1 and 8or 12)v=h.a%1spr(84+sgn(.5-v)*v%.5*16,h.x-4,h.y-4,1,1,v<.5)end
v=24/min(1,pm-pn)sspr(64,32,32,8,v*0xfffe.1,v/0xfffd.3-26,v*4,v)pp("  lap "..pl.."/3\ntrack "..pm.."/5\n time "..(pt/100).."\"\n    $ "..ps.."\n\ndirt★racing (p01+gruber)",0xffc2,35,7)v=pb-atan2(px,py)
if(v>.9)pl+=1ptl=pl*1337
if(pl>3)pm+=1
pb-=v
end,-- dirt
--------------------
function()
if kgo<1 then
if(btn"0")ka+=.02
if(btn"1")ka-=.02
if(btn"2")sfx(21) krv+=sin(kar-ka)*.00052 kdx+=cos(ka)/40 kdy+=sin(ka)/40
kar+=krv
krv*=.99
kdy+=.01
kx+=kdx
ky+=kdy
end
kgo=max(0,kgo-1)
if(kgo==1 or ky<8)ret(102-ky/3)
end,--thrust
--------------------	
function() 
if at<0 then
if (btnp"5") a_make_level()
return
end
if (al<1) return 
at+=1
v,w=apx,apy
if (btnp"2") apy-=1
if (btnp"3") apy+=1
if (btnp"0") apx-=1
if (btnp"1") apx+=1 
if a_pmget(32) then
apx,apy=v,w
elseif a_pmget(51) then
a_make_level()
elseif a_pmget(35) then
ag+=1
sfx"0"
elseif a_pmget(50) then
ag+=10
sfx"0"
elseif a_pmget(33) then
al+=10
sfx"1"  
elseif a_pmget(34) then
al-=5
sfx"2"
mset(apx,apy,50)
apx,apy=v,w
end
mset(v,w)
mset(apx,apy,49)
if (at%30==0) al-=1
end,--rungeon
--------------------
function()
for i=1,4 do
dpigs[i].timer=max(0,dpigs[i].timer-1)
end
if dst<0 then
dbob-=1
if dbob<1 then
dbob,dbt=17,false
end
dt+=1
if dt==45 then
if dn!=0 then
if dpigs[dn].fd==df then
dip(dn)
dscore+=4
sfx(7,3,16,7)
else
sfx(7,3,8,7)
end
end
if dnum>=32 then
dend=50
else
dnd()
end
end
dlx,dly=0,0
if dn==1 then
dly=0xffff
elseif dn==2 then
dly=1
elseif dn==3 then
dlx=0xffff
elseif dn==4 then
dlx=1
else
dlx,dly=0xffff,1
if dx>51 and dx<72 then
dn=dbd
if dbd!=0 then
dbt=true
sfx(7,3,0,7)
end
end
end
dx+=dlx*2.9
dy+=dly*2.9
dbd=0
if btn"0" then dbd=3
elseif btn"1" then dbd=4
elseif btn"2" then dbd=1
elseif btn"3" then dbd=2
end
if(dend<100) dend-=1
if(dend<0) ret(dscore)
else
dst-=1
end
end,--birb
-------------------- 
function()		
if ea == 1 then
if (ee() and btnp"4")	eg,ea=0,2	sfx"-1"
elseif ea == 2 then
em_ep()
foreach(ew,em_ew)
if (et>0) et-=1 else local q=ceil((es+1)/5) exd,etm=q/4,80/q et,es=etm,es+1 sfx"38" er(128)
elseif ea ==3 then
if ee() and
btnp"4" then
if (es>16) es=16
ret(es*8)
end
end
end,--flop	
--------------------	
function()--pants
ux,uy=ua[1][2],ua[1][3]
ut+=1
if (btn"0" and ux>0) ua[1][2]-=1
if (btn"1" and ux<120) ua[1][2]+=1
if (btn"2" and uy>0) ua[1][3]-=1
if (btn"3" and uy<112) ua[1][3]+=1
for h=0,270 do
pal(6,h%2*7+6)spr(144,h%17*8,f(h/17)*8)
end
srand"0"for h=1,up do
spr(145,r"120",r"120")
end
srand(ut)for h=0,128 do
for i in e(ua) do
j,k,v,w=i[1],i[2],i[3],i[4]
if v==h then
spr(j,k,v,1,2,ut%30<15 and j<161)if j>159 then
if btn"4" and abs(k-ux)<9 and abs(v-uy)<9 then
if (uc<1 and ((j==160 and uy>v) or (j==162 and uy<v) or (j==161 and ux>k) or (j==163 and ux<k))) uc=ut+90
i[1],i[4]=131,ut+30
up+=1sfx"43"
end
if (ut>w) i[4]=ut+r(30)+30-(up*1.5) i[1]=(j+1)%4+160
end
if (j==131 and ut>w) i[1],i[2],i[3],i[4]=160,f(r(104)+8),f(r(96)+8),ut+30
end
end
end
if (ut<150) pp("        pants thief\n\npress 🅾️ to steal pants when\n standing behind a citizen.\n\n     don't get caught!",9,20,10)
if (uc>0) pp("you were caught!\npants stolen: "..up,33,64,10)
if (ut-uc==0xffff) ret(up*3)
pp("pants thief (@unclesporky)",2,121,7)end,--pants
--------------------	
function() --rpg
if mget(sx,sy)<206 or mget(sx,sy)>235 then
srand"6"for i=0,15 do
for j=0,15 do
spr(f(r"4"+204),i*8,j*8)end
end
map(106,14,32,32,8,16)rectfill(41,57,78,78,2)rect(42,58,77,77,9)spr(238,48,64)spr(239,64,64)sh=16+5*sl
if sx==120 then
pp("   hero, slay the lich! kill\n  monsters to level up. visit\n   towns for healing and aid.\nyour health drains as you move!",3,23,10)elseif sx==125 then
pp("use this sword to slay the lich!",1,29,10)ss=true
elseif sx>126 then
rectfill(0,0,128,128,2)sw=sl*6
sh=0
if sx==128 then
pp("you have died.",37,29,7)else
if ss==true then
pp("you have saved the world!",15,29,7)else
pp("   the lich destroys you.\nnext time seek out a weapon!",11,29,7)end
end
else
pp("welcome! your wounds are healed.",1,29,10)end
pp("press 🅾️ to continue",25,89,7)
if (btnp"4" and sx>126)ret(sw)
if (btnp"4")sy+=1
else
map(f(sx/16)*16,f(sy/16)*16,0,0,16,16)if mget(sx,sy)==223 then
rectfill(0,0,128,128,8)sfx"47"mset(sx,sy,mget(sx,sy+1))sl+=1
end
spr(238,sx%16*8,sy%16*8)
if(btnp"0"and mget(sx-1,sy)<253)sx-=1 sh-=1
if(btnp"1"and mget(sx+1,sy)<253)sx+=1 sh-=1
if(btnp"2"and mget(sx,sy-1)<253)sy-=1 sh-=1
if(btnp"3"and mget(sx,sy+1)<253)sy+=1 sh-=1
end
if(sh==1)sx=128
pp("lv "..sl.." hp",2,2,10)rectfill(35,3,sh+35,5,8)
if(ss==true)spr(252,1,8)
pp("micro rpg (@unclesporky)",2,121,7)
end,
--------------------
function() --alien
rt-=1
rp""   
?rs,0,109,0
?"alien shootout (@viza)",2,121,7
flip""end,--alien
--------------------
function() --lake
if ds==0 then dm+=3;for di=125,128 do dt=(dm/10+20)*(0.0572*cos(4.667*3*dm)+0.0218*cos(12.22*3*dm))dl[di],dr[di]=20+dm/160+dt,110-dm/155+dt end;for di=0,125 do dl[di],dr[di]=dl[di+3],dr[di+3]end;if pget(dx,38)==5 or pget(dx+2,40)==5 or pget(dx+4,38)==5 or pget(dx+2,40)==0 then ds,d_g=f(dm/5626*100), " crash!"if ds>99 then ds,d_g=128,"congrats!"end end;dp=(dp+1)%3
if(btn"0")dd-=0.1 
if(btn"1")dd+=0.1 
dx+=min(max(dd,-1.5),1.5);for di=4,2,-1 do dc[di]=dc[di-1]end;dc[1]=dx;if dw-dm<-150 then dw+=308;dq=30+dm%50 end elseif btn"5"then ret(ds)end 
end,--lake
--------------------
function()nq+=1
for i in e(nr)do
i[1]+=i[3]i[2]-=i[4]i[4]-=1.2
if(i[2]>130)del(nr,i)end
if(#np<1 and nm==0 and #nr<1)sfx(-1,3)ret(nu*7)
nm=max(nm-.03,0)for i in e(np)do
i[1]-=1
h=i[1]
if(h<20)del(np,i)nm=.25
if(h>45 and h<57 and ns==1.9)nu+=1 del(np,i)for i=1,9 do add(nr,{58,83,r(8)-4,r"9",1})sfx(58)end
end
if(nq%65<1 and nn>0)add(np,{128})nn-=1
ns=max(ns-.3,0)if #nw<1 then
for i=1,nl do add(nw,f(r"4"))end
end
if(btnp(nw[nt]))sfx(59,2)nt+=1
if nt>#nw then
sfx(57)nw={}nt=1 nl=min(nl+.25,8)ns=1.9
end
end,-- teapot
--------------------
function() --meta
if(g<1 and s==0)nx(2)
if(#b<1)nx(1)
for i in e(c) do
i[3]*=.9
if(i[3] < 1) del(c,i)
end
if(btn(0))a+=.02
if(btn(1))a-=.02
if btn(2)and g>0 then
if(#c<4) then
j=a-.55+r(.1) 
i=4+r(2)
add(c,{x+(i*cos(j)),y+(i*sin(j)),r(3)})
end
sfx(62)
g=max(g-.3,0)
s=min(s+.1,3)
else
s*=.95
end
x+=s*cos(a)
y+=s*sin(a)
m(x-64,y-64)
--check xtals
for i in e(o) do
if(abs(x-i[1])<5 and abs(y-i[2])<5)del(o,i)sfx(63)l+=1
end
for i in e(q) do
if(abs(x-i[1])<5 and abs(y-i[2])<5)sfx(61,1,r(11))g-=1
end
for i in e(b) do
if(abs(x-i[1])<7 and abs(y-i[2])<7 and l>2)del(b,i) l-=3 n=i[4] --[[n=16]] warp() t[n]()m()
end
end--meta
}
--------------------draw functions
d={
function()
mt+=1
cls()rect(0,0,127,127,1)
if(mtx==3)rectfill(2,2,125,125,1)
?"lateris (@egordorichev)",2,121,1
spr(12,mx,115+mtx,2,1)spr(12,mx2,-1-mtx,2,1,false,true)mmx=0
if(btn(⬅️))mmx=-1
if(btn(➡️))mmx+=1
mx=mid(2,110,mmx*2+mx)if mt>30 then
if mlx~=mmx then
add(mbf,{mmx,mt+mt/20})mlx=mmx
end
for m in e(mbf) do
if m[2]<=mt then
memx=m[1]del(mbf,m)end
end
mx2=mid(2,110,memx*2+mx2)mbx+=mvx
mby+=mvy
msc=flr(mid((mt-30)/8,0,128))if mbx<4 or mbx>123 then
sfx(32)mvx*=-1
elseif mby<4 or mby>120 or msc==128 then
ret(msc)
end
mtx=max(0,mtx-mtx*0.1-0.05)if pget(mbx+mvx*2,mby+mvy*2)>1 then
mvy*=-1
if (mby>4 and mby<120) sfx(32,0)
mtx=3
end
if #mps>32 then
del(mps,mps[1])end
add(mps,{mbx+rnd(4)-2,mby+rnd(4)-2})else
mx2=mid(2,110,mmx*2+mx2)end
mv,mr=mbx,mby
for i=#mps,1,-1 do
mn=mps[i]line(mn[1],mn[2],mv,mr,i%8+7)line(mn[1],mn[2]-1,mv,mr-1,i%8+8)mv,mr=mn[1],mn[2]end
spr(14,mbx-2,mby-2)
end,-- lateris
--------------------
function()
cls(12)
palt(0,false)
palt(11,true)
rectfill(0,96,127,127,1)
sspr(112,64,8,8,0,84,64,32)
--clouds
for k,c in pairs(fv) do
for i=0,3 do
local x,y=c.x+i*3,c.y+i%2
circfill(x,y+95,c.r,13)
circfill(x-12,y,c.r*6,7)
end
c.x-=c.r
fv[k].x%=140
end
spr(140,24,56,2,4)
spr(fs,30,62)
--?'chances:'
for i=1,12 do
?'●',25+i*7,0,fr[i] or 0
end
if fg then
?sub('...',1,ft%20/5),26,43
line(56,50,80,107,7)
line(38,80,56,50,0)
end
if fn and ft%15<7 then
?'press 🅾️',30,43
line(48,46,80,107,7)
line(38,80,48,46,0)
end
if fm then
?fm,68-#fm*2,32
end
?"'simple fishin' (@enargy)",3,122,7
fq+=.005
for i=1,12 do
memcpy(0x7980+i*0x40,0x7980+cos(fq)*i+i*0x40,0x40)
end
if fm=="got it! ♥" then
pal(12,fa)
pal(10,fa+1)
spr(174,64,48,2,1)
end
end,-- fishing
--------------------
function()
srand(lmx)
cls"3"
palt(0,false)
for i=1,40 do
?"ˇ",r"128",r"128",11
end
map(lmx,lmy,0,0,16,16)
local n=lpm<4 and 76+lpm or lrs
spr(n,lpx*8,lpy*8,1,1,lrfx,lrfy)
pp("treasure hunt (liquidream)",2,121,7)
end,-- treasure
--------------------
function() end,--gregos (no code)
--------------------
function() end,-- worm (no code)
--------------------
function() 
cls()
map(48,0,0,0,16,16)
if tg then
?"final score:"..ts,35,61,rnd"15"
else
foreach(tb,tmb)
spr(25,tx*8,ty*8)
tcc=0
for i=1,#tn do
tcc+=tn[i]
?"❎",23,20,1
spr(8+tn[i],23+i*8,19)
end
?tcc.."/"..tcn,93,20,6
?"points:"..ts.."\t\t\t\t\ttime:"..td,24,104
?"bug collector (brintown)",2,121,1
end
end,-- bug collector	
--------------------
function() end,-- dirt (no code here)
--------------------
function()
cls()
camera(kx-64,ky-64+4*sin(rnd(kgo)))
map(0,0,0,0,32,48)
local ax,ay,bx,by=cos(kar)*10.656+kx,
sin(kar)*10.656+ky,
cos(kar)*0xfffb.328+kx,
sin(kar)*0xfffb.328+ky
-- pod collision check
for i=0,35 do
if(kgo<1 and pget(bx+i%6-3,by+i/6-3)>0)sfx(20)kgo=30
end
-- draw pod	 
circ(bx,by,3+rnd(kgo),6)
for col=0,1 do
for i=0,16,2 do
local h="0x"..sub("063345748394c5d306",i,i+2)
local r,d=h%16+rnd(kgo),h/256+ka
kpx,kpy,kgx,kgy=kgx,kgy,ax+cos(d)*r,ay+sin(d)*r
--draw line on col>1 and i>1
if(col*i>0)line(kgx,kgy,kpx,kpy,7)
--check collision on col<1
if(col+kgo<1 and pget(kgx,kgy)>0)sfx(20)kgo=30
end
end
if(kgo<1)line(ax,ay,bx,by,5)
camera()
pp("picothrust (kometbomb)",2,121,12)
end,-- thrust
--------------------
function() 
cls()
if (aox) spr(48,aox*8,aoy*8)
map()
if at<0 then
?"◆ rungeon ◆",38,40,7
?"wounded but greedy",28,63,6
?"descend in search of riches",10,70,13
spr(48,48,86,4,1)
?"❎",60,98
return
end
if (at<20 and at%4==0) circ(apx*8+3,apy*8+3,4+at/2) 
?"depth: "..ad.."   gold: "..ag.."   life: "..al
?"rungeon (johan peitz)",0,123
if al<1 then
rectfill(0,32,127,47,0)
?"you died "..ag.." gold richer. (❎)",8,37,10
color"8"
if (btnp"5") ret(ag)
end
end,--rungeon
--------------------
function()
cls"3"
for i=1,4 do
if i==1 then
px,py,fp=56,17,false
elseif i==2 then
px,py,fp=56,112,true
elseif i==3 then
px,py,fp=1,60,false
elseif i==4 then
px,py,fp=112,60,true
end
spr(132,px,py,2,2,fp)
if dpigs[i].timer==0 then
circfill(px+7,py-9,8,15)
spr(dpigs[i].fd+19,px+4,py-12)
end
end
spr(df+19,dx,dy)
spr(164,48,59-flr(dbob/9),4,2,dbt)
pp("  birbserve          (hodge)",2,121,14)
end, -- birb
--------------------
function()	
cls"7"
rectfill(0,20,127,107,5)
if ea == 1 then
sspr(32,24,27,4,10,54,108,16)
?"🅾️ flop",48,74,7
else
spr(eps,14,epy)
foreach(ew,ed_ew)
end
i,j=es,62
if (ea==3) i,j="🅾️ quit",48 
?i,j,112,5
?"♥♥flopger♥♥ (platformalist)",2,121
end,--flop
--------------------
function()end,--pants
function()end,--rpg
function()end,--alien
--------------------
function()--lake
cls"5"for di=0,127 do for dj=-2,4,2 do if dm+di>5625 then dj=0 end;line(dl[di],di-dj,dr[di],di+dj,du[f((dm+di+489)/512)])end end;for dk=1,4 do spr(196,dc[dk],32-dk*8)end;spr(dp+212,dx,32)spr(215,dq,dw-dm)spr(231,dq+33,dw-dm+99)p(f(dm/5626*100).."%",112,113,7)if ds>0 then p(d_g,48,46)if ds>dget"9"then dset(9,ds)end;p("     score: "..ds.."\n\n      hi: "..dget"9".."\n\npress \x97 to return",28,64)end;p("lake of black gold (@dollarone)",2,121)	
end,--lake
--------------------
function()cls"1"for i=1,50 do
j=r"128"k=r"128"line(j,k,j+2,k+3,5)end
if(r()<.005)cls"10"
for i in e(nr)do
spr(240+f(r"3"),i[1],i[2])end
spr(192+f(ns)*2,45,56,2,3)for i in e(np)do spr(243,i[1],72)end
spr(243,20,128+55*sin(nm))line(29,80,128,80,7)pset(56,81)for i=1,#nw do
if(i<nt)color"10"else color"9"
p(nz[nw[i]+1],45+i*9,30)end
p("press",30,30,7)p("teapot vandal (@elneil)",2,121)p("hits: "..nu,1,1)p("remaining: "..nn,76,1)end,--teapot
--------------------
function()--meta 
cls()
for i in e(nd) do
pset(((i[1]-(x%128)+128)%128)+x-65,((i[2]-(y%128)+128)%128)+y-65,5+r(2))
end
fillp(shl(r(32767),1)+r(2))
-- planets
for i in e(b) do
circfill(i[1]-2,i[2]-2,5,i[3])
j="come\n in!" if (l<3) j="need\n 3◆"
p(j,i[1]-9,i[2]+7,7)
end
-- smoke
for i in e(c) do
circfill(i[1],i[2],i[3],r(16))
end
fillp()
--xtals/mons
for i=1,2 do
for j in e(ref[i])do
spr(228+i,j[1]-2,j[2]-2)
end
end
-- player
spr(228,x-3,y-3)
pset(f(x)+.5+2*cos(a),f(y)+.5+2*sin(a),1)
if(x==0 and y==0)sspr(32,120,32,8,-48,-45,96,24)p("the 16 anomalies\n\n\n\npress ⬆️ to fly!\n\n  hiscore: "..nh,-32,-15,15)
--hud
rectfill(f(x)-64,f(y)+56,f(x)+g-64,f(y)+62,8+(g*.03))
p("fuel",f(x)-63,f(y)+57,0)
p("sector ["..10+f((x+125)/250)..","..10+f((y+125)/250).."]",f(x)-63,f(y)+50,7)
for i=1,min(l,7) do p("◆",f(x)+i*6-5,f(y)+50)end
p("✽:"..16-#b,f(x)+45,f(y)+50)
end--meta
}
-----------------------------------------------------

function ret(k)
k=flr(mid(0,k,128))
music"-1"palt""nb+=k
g=min(128,g+k)
n=17
m()
i=120
sfx(33+min(k,1))
while i>0 do 
cls()
?"you found "..k.." tons of fuel.",14,50,7
flip()
i-=1
end
reload()
warp()
end

--------------------dev globals
function tmb(b)
if(b.tt>0)b.tt-=1
if(b.tt==0 and b.t==0)b.t=ceil(rnd"3");b.tt=-1
spr(8+b.t,b.x*8,b.y*8)
if b.x==tx and b.y==ty then
if b.t>0 then
if b.t<4 then
add(tn,b.t);del(tb,b)
sfx"9"
end
else
sfx"8"
b.t,b.tt=16,30
if(ts>0)ts-=1
end
end
if(b.tt==0 and b.t==16)del(tb,b)
end

function a_make_level()
at=0
ad+=1
reload()
for i=0,3 do
local r,mx,my=flr(rnd"8"),(i%2)*8,1+flr(i/2)*7
for x=0,7 do
for y=0,6 do
if (sget(r*8+x,y)>0) mset(mx+x,my+y,32)
end
end
end
a_rmset"48" 
apx,apy=flr(arx),flr(ary)
aox,aoy=apx,apy
a_rmset"51" 
a_rmset"33"
for i=0,ad do
a_rmset"34" 
a_rmset"35" 
end
sfx"3"
end

function a_rmset(tid)
arx,ary=rnd"16",rnd"14"+1
if (mget(arx,ary)==0) return mset(arx,ary,tid)
a_rmset(tid)
end

function a_pmget(id)
return mget(apx,apy)==id
end



function rg()
cls"4"
rectfill(0,0,128,64,12)
for i=2,6 do local y=i*i+64
line(0,y,128,y,15)
end
end
function ra()
local o=12+sin(rt/100)*2 sspr(64,96,8,16,32,o,30,50)
if sin(rt/60)<0then sspr(72,96,8,16,62,o,30,50)
else sspr(88,96,8,16,62,o,30,50)
end
sspr(64,112,16,16,32,60,60,50)
end
function re()
local s=2^(rl-1)rs="           score: "..s
if rt<-60 then ret(s)
end
end
function rw()
if rt<=0 then
rt,rp,rs=90,r_sc,"           duel: "..rl.."/7"
end
rg""
if rl>1 then sspr(80,120, 16,8, 32,70, 60,30)
sspr(88,112, 8,8, 69,128-rt, 45,45)
end
end

function r_sc()
rg""
for i=10,rt,30 do circfill(10,i, 7, 10)
end ra""
if rt==10 then
rt,rp,rs = 100,r_ss,"        ⬆️ to draw gun"
end
end
function r_ss()
local b=128*(((rd-rt)*(rl+2))/100)^1.8
rg"" ra""
if rt<0 then rs=""
if rl==8 then sspr(80,120, 16,8, 32,70, 60,30)
music"58"
rp=re
elseif not (rb>70 and rb<90) then
cls"8"
sfx"48"
sspr(80,96, 16,16, 32,10, 60,50)
sspr(64,112, 16,16, 32,60, 60,50)
sspr(80,112, 8,8, 34,36, 30,30)
music"59"
rp=re
else
rt,rd,rp,rb=45,101,rw,0xffff
music"57"
end
end
if rd>100 then
if btn"2" then
rd=rt
end 
else
rectfill(0,0,128,7,1)rectfill(70,0,90,7,11)
?"❎",77,1,7
local p = rb>=0 and rb or b
line(p,0,p,9,10)
sspr(88,112, 8,8, 69,83, 45,45)
if btnp"5" then
sfx"48"
sspr(80,112, 8,8, 55,54, 60,60)
rb,rt=b,0 rl+=1
end
end
end



function pp(h,i,j,k)
?h,i-1,j,0
?h,i+1,j
?h,i,j-1
?h,i,j+1
?h,i,j,k
end

function em_ep()
eps=36
if (btn"4") eps=37
if (btn"4" and ebt==false) sfx"36" epd,ebt=-2.5,true
if (epd<2) epd+=.25 else epd=2
epy+=epd
if (epy<19 or epy>103)	ed() 
if (btn"4"==false)	ebt=false
end

function ee()
if (eg<15) eg+=1 else return true
end

function em_ew(v)
if (v.y>15)	v.y-=v.v else v.y=110
if (v.x>-8)	v.x-=exd else del(ew,v)
if	v.x>21 or
v.x<11 or
v.y>epy+5 or
v.y+5<epy then
else
ed() 
end
end

function ed()
ea=3
sfx"37"
end

function ed_ew(v)
spr(38,v.x,v.y)
end

function er(j)
local q=rnd()
for i=1,3 do	
add(ew,{x=j,y=i*32,v=q})
end
end

function dip(n)
dpigs[n]={fd=ceil(r"4");timer=12}
end

function dnd()
dx,dy,dt,dn,df=136,0xfff8,0,0,dpigs[ceil(r"4")].fd
dnum+=1
end

function draw_pig(pn)
if pn==1 then
px,py,fp=56,17,false
elseif pn==2 then
px,py,fp=56,112,true
elseif pn==3 then
px,py,fp=1,60,false
elseif pn==4 then
px,py,fp=112,60,true
end

spr(4,px,py,2,2,fp)

if dpigs[pn].timer==0 then
circfill(px+7,py-9,8,15)
spr(dfood[dpigs[pn].fd],px+4,py-12)
end
end

function g_init()
g_pl,g_pll={t=4,x=64,y=64,r=3,a=.25,s=0},100
g_mobs={g_pl}
for n=1,g_lvl do
add(g_mobs,{t=2,x=r"100"-50,y=r"100"-50,a=r(),s=r".5"+.1,r=r"10"+5})
end
end


function g_colr(n)
return sget(g_lvl%16,n+64)
end


function done(n,txt)
pp(txt,35,50,10) 
for i=1,75 do 
flip() 
end
ret(n)
end

function warp()
sfx"14"
for w=1,16 do
cls()
for v=0,8191 do
poke(0x6000+v,rnd"256")
end
flip()
end
end

function make_wave()
add(fv,{x=130,y=rnd"18",r=rnd"1"})
end

