--alpine ascent
--by tyler r. davis
--version 1.1
--game loop
g={
--globals
	grav=0.2
}
timer=0
counter=0
anim_timer=0

function _init()
		scene="menu"
	bg_x=0
	bg_y=0
	bg_color=12
	
	
end

function _update()
	if scene=="menu" then
		update_menu()
	elseif scene=="start" then
		scene="game"
		music(0)
		map_setup()
		player_setup()
		camera_init()
		
		--testing
		--p.x=96*8
 	--p.y=4*8
 	--camx=96*8
 	--camy=0
 	
 	scene="game"
	
	elseif scene=="game" then
		update_player()
		camera_update()
		coins_update()
		counter+=1
		if counter==30 and not winflag.collected then
			counter=0
			timer+=1
		end
	end
end

function _draw()
	if scene=="game" then
		draw_map()
		draw_coins()
		draw_player()
		pal(5,5,0)
		pal(6,6,0)
		rectfill(camx+1,camy+120,camx+128,camy+127,5)
		rectfill(camx+1,camy+120,camx+p.maxstam,camy+127,0)
		rectfill(camx+1,camy+120,camx+p.stam,camy+127,3)
		if (magma_collide())	rectfill((camx+p.stam),camy+120,camx+p.stam,camy+127,8)
		score_string=tostr(p.score+p.coin_score)..""..minutes(timer)
		rect(camx+0,camy+120,camx+127,camy+127,7)
		line(camx+14,camy+120,camx+14,camy+127,7)
		line(camx+28,camy+120,camx+28,camy+127,7)
		line(camx+42,camy+120,camx+42,camy+127,7)
		line(camx+56,camy+120,camx+56,camy+127,7)
		line(camx+70,camy+120,camx+70,camy+127,7)
		line(camx+84,camy+120,camx+84,camy+127,7)
		line(camx+98,camy+120,camx+98,camy+127,7)
		line(camx+112,camy+120,camx+112,camy+127,7)
		rectfill(camx,camy+113,camx+32,camy+119,0)
		print("🅾️:",camx+1, camy+114,3)
		circ(camx+15,camy+116,2,3)
		circ(camx+22,camy+116,2,3)
		circ(camx+29,camy+116,2,3)
		if (p.stamcoin>0) circfill(camx+15,camy+116,2,3)
		if (p.stamcoin>1) circfill(camx+22,camy+116,2,3)
		if (p.stamcoin>2) circfill(camx+29,camy+116,2,3)
		rectfill((camx+(16*8)-(#score_string*4))-1,camy+113,camx+128,camy+119,0)	
		print(score_string, camx+(16*8)-(#score_string*4), camy+114,7)
		pal(5,pal5,0)
		pal(6,pal6,0)
	
		if winflag.collected then
		print('you sent it!',(camx+64-(12*2))+1,(7*8),0)
		print('you sent it!',camx+64-(12*2),7*8,10)
		print('score:'..p.score+p.coin_score,(camx+64-(12*2))+1,(11*8),0)
		print('score:'..p.score+p.coin_score,camx+64-(12*2),11*8,10)
		print('time:'..minutes(timer),(camx+64-(12*2))+1,(12*8),0)
		print('time:'..minutes(timer),camx+64-(12*2),12*8,10)
		if p.no_green_coins then
			print('without using green coins',(camx+64-(25*2))+1,(8*8),0)
			print('without using green coins',camx+64-(25*2),8*8,10)	
		end
		if p.never_fell then
			print('without falling',(camx+64-(15*2))+1,(9*8),0)
			print('without falling',camx+64-(15*2),9*8,10)	
		end
		if p.all_coins then
			print('and collected all coins',(camx+64-(23*2))+1,(10*8),0)
			print('and collected all coins',camx+64-(23*2),10*8,10)	
		else if p.no_gold_coins then
			print('without gold coins',(camx+64-(18*2))+1,(10*8),0)
			print('without gold coins',camx+64-(18*2),10*8,10)	
		end
	end
	end
	end

end	
-->8
--map code
function map_setup()
	solid=0
	climbable=1
	magma=2
	ice=3
	coin=4
	stamcoin=5
	bumper=6
	obsidian=7
	
	bg_x=0
	bg_y=0
	bg_color=12
	pal5=5
	pal6=6
	
end

function draw_map()
	anim_timer+=1
	cls(bg_color)
	map(112,0,bg_x,bg_y,128,512)
	map(0,0,0,0,128,64)
	if camx>383 then
		for x=0,127 do
			for y=0,64 do
				tile=mget(x,y)
				flag=fget(tile,magma)
				if flag then
					--print('flagged!',camx+10, camy+10,0)
					if anim_timer%15==0 then
						if tile==29 then
						 mset(x,y,45)
						elseif tile==45 then
					 	mset(x,y,29)
						elseif tile==30 then
						 mset(x,y,46)
						elseif tile==46 then
						 mset(x,y,30)
						elseif tile==11 then
						 mset(x,y,12)
						elseif tile==12 then
						 mset(x,y,11)
						end
					end
				end
			end
	end
	end
end

function coins_update()
 animate_item(coin1, 36, 38)
 coin_collect(coin1)
 animate_item(coin2, 36, 38)
 coin_collect(coin2)
 animate_item(coin3, 36, 38)
 coin_collect(coin3)
 animate_item(coin4, 36, 38)
 coin_collect(coin4)
 animate_item(coin5, 36, 38)
 coin_collect(coin5)
 animate_item(coin6, 36, 38)
 coin_collect(coin6)
 animate_item(stam_coin1, 20, 22)
 stam_collect(stam_coin1)
 animate_item(stam_coin2, 20, 22)
 stam_collect(stam_coin2)
 stam_collect(stam_coin3)
 animate_item(stam_coin3, 20, 22)
 stam_collect(stam_coin4)
 animate_item(stam_coin4, 20, 22)
 stam_collect(stam_coin5)
 animate_item(stam_coin5, 20, 22)
 stam_collect(stam_coin6)
 animate_item(stam_coin6, 20, 22)
 stam_collect(stam_coin7)
 animate_item(stam_coin7, 20, 22)
 stam_collect(stam_coin8)
 animate_item(stam_coin8, 20, 22)
 stam_collect(stam_coin9)
 animate_item(stam_coin9, 20, 22)
 stam_collect(stam_coin10)
 animate_item(stam_coin10, 20, 22)
 stam_collect(stam_coin11)
 animate_item(stam_coin11, 20, 22)
 stam_collect(stam_coin12)
 animate_item(stam_coin12, 20, 22)
 
end

function coin_collect(coin)
	if intersects_box_box(coin.x,coin.y,8,8,p.x,p.y,8,8) then
  if not coin.collected then
   p.maxstam+=14
  	coin.collected=true
  	sfx(3)
  	p.coin_score+=100
  end
 end
end
 
function stam_collect(coin)
	if intersects_box_box(coin.x,coin.y,8,8,p.x,p.y,8,8) then
  if not coin.collected then
  	if (p.stamcoin<3) p.stamcoin+=1
  	coin.collected=true
  	sfx(3)
  	p.coin_score+=100
  
  end
  
 end
end

function reset_stam_coins()

end

function draw_coins()
	if (not coin1.collected) spr(coin1.sprite,coin1.x,coin1.y,1,1,true)
	if (not coin2.collected) spr(coin2.sprite,coin2.x,coin2.y,1,1,true)
	if (not coin3.collected) spr(coin3.sprite,coin3.x,coin3.y,1,1,true)
	if (not coin4.collected) spr(coin4.sprite,coin4.x,coin4.y,1,1,true)
	if (not coin5.collected) spr(coin5.sprite,coin5.x,coin5.y,1,1,true)
	if (not coin6.collected) spr(coin6.sprite,coin6.x,coin6.y,1,1,true)
	
	if (not stam_coin1.collected) spr(stam_coin1.sprite,stam_coin1.x,stam_coin1.y,1,1,true)
	if (not stam_coin2.collected) spr(stam_coin2.sprite,stam_coin2.x,stam_coin2.y,1,1,true)
	if (not stam_coin3.collected) spr(stam_coin3.sprite,stam_coin3.x,stam_coin3.y,1,1,true)
	if (not stam_coin4.collected) spr(stam_coin4.sprite,stam_coin4.x,stam_coin4.y,1,1,true)
	if (not stam_coin5.collected) spr(stam_coin5.sprite,stam_coin5.x,stam_coin5.y,1,1,true)
	if (not stam_coin6.collected) spr(stam_coin6.sprite,stam_coin6.x,stam_coin6.y,1,1,true)
	if (not stam_coin7.collected) spr(stam_coin7.sprite,stam_coin7.x,stam_coin7.y,1,1,true)
	if (not stam_coin8.collected) spr(stam_coin8.sprite,stam_coin8.x,stam_coin8.y,1,1,true)
	if (not stam_coin8.collected) spr(stam_coin8.sprite,stam_coin8.x,stam_coin8.y,1,1,true)
	if (not stam_coin9.collected) spr(stam_coin9.sprite,stam_coin9.x,stam_coin9.y,1,1,true)
	if (not stam_coin10.collected) spr(stam_coin10.sprite,stam_coin10.x,stam_coin10.y,1,1,true)
	if (not stam_coin11.collected) spr(stam_coin11.sprite,stam_coin11.x,stam_coin11.y,1,1,true)
	if (not stam_coin12.collected) spr(stam_coin12.sprite,stam_coin12.x,stam_coin12.y,1,1,true)
	spr(winflag.sprite,winflag.x,winflag.y,1,1,false)
	
	end

-->8
--player code
function player_setup()
	p={}
	p.x=6*8
	p.y=62*8
	--for testing
	--p.x=96*8
 --p.y=4*8
	--
	p.dx=0
	p.dy=0
	p.w=8
	p.h=8
	p.alt=0
	p.max_dx=1
	p.max_dy=2
	p.sprite=49
	p.timer=0 --animation timer
	p.stam=56
	p.maxstam=56
	--p.maxstam=112
	p.stamtarget=p.stam
	p.stamcoin=0
	p.score=0
	p.coin_score=0
	p.face=false --false is right
	p.ct = 0 --jump timer
	p.acc=0.3 --accelration
	p.dcc=0.6 --deceleration
	--jump
	p.air_dcc=1
	p.jump_pressed=0
	p.is_pressed=false
	p.jump_speed=1.9
	p.ticks_down=0
	p.hold_time=0
	p.max_hold=12
	p.min_hold=5
	p.released=true
	p.grounded=true
	p.air_time=0
	--climb
	p.climbing=false
	p.climb_acc=0.3
	p.climb_time=0
	p.ice_time=0
	
	--win condition
	p.never_fell=true
	p.all_coins=false
	p.no_gold_coins=true
	p.no_green_coins=true
	p.time='0'
end

	


function draw_player()
	spr(p.sprite,p.x,p.y,1,1,p.face)
end

function update_player()
--check for climbable wall
	if climb_collide() and p.stam>0 and not obsidian_collide() then
		p.climbing=true
		p.dy=0
	end
		
	if bumper_top_collide() then
		if (p.dy>0) p.dy*=-2
		p.dx*=2
	end
		
	--jumping
	if btn(❎) and p.stam>1 and not winflag.collected then
	
	 local on_ground=(p.grounded or p.air_time<5)
		local new_jump=p.ticks_down<10
		
		---increment stamina
		if p.ticks_down==0 and on_ground then
		-- p.stam-=14
			p.stamtarget=p.stam-14
		
		end

		
		p.ticks_down+=1
		
		--initial jump
		if p.hold_time>0 or (on_ground and new_jump) or (p.climbing and new_jump) then
			p.hold_time+=1
		
			if p.hold_time<p.max_hold then
				--stop climbing
				if p.climbing and p.hold_time<5 then
					p.climbing=false
					p.climb_time=0
				--push away from wall
					if (not p.face) p.dx-=p.acc/2
					if (p.face) p.dx+=p.acc/2
				end
				--add height
				p.dy=-p.jump_speed
				p.air_time+=1
				if (p.ticks_down==1 and new_jump) sfx(0)
			end
		end
		
				--minimum jump height
	elseif (not btn(❎) and p.hold_time>0 and p.hold_time<p.min_hold) then
		p.dy=-p.jump_speed
		p.hold_time+=1
	else --end jump
		p.hold_time=0
		p.is_pressed=false
		p.ticks_down=0
	end
	
	--walking
	if btn(⬅️) and not winflag.collected and not p.climbing then
		p.dx-=p.acc
		p.face=true
		animate(p, 49, 51, 4)
	elseif btn(➡️) and not winflag.collected and not p.climbing then
		p.dx+=p.acc
		p.face=false
		animate(p, 49, 51, 4)
	else
	--decelerate
		if p.grounded then
			p.dx*=p.dcc
		else
			p.dx*=p.air_dcc
		end
	end
	
	--cap speed
	p.dx=mid(-p.max_dx,p.dx,p.max_dx)

--	move horizontally
	if not wall_collide() and not p.climbing then 
		if (not p.climbing) p.x+=p.dx
	end
	
	--floor collision
	if floor_collide() then
	--if touching the ground, reset jump time
		p.y=flr((p.y)/8)*8
		p.grounded=true
		if (p.air_time>0) sfx(1)
		p.air_time=0
		--increment_stam(p.maxstam)
		p.stamtarget=p.maxstam

	elseif not floor_collide() and not p.climbing then	
	---apply graviaty while in air
		p.grounded=false
		p.sprite=54
		p.air_time+=1
		p.dy+=g.grav
		p.dy=mid(-p.max_dy,p.dy,p.max_dy)		
	end
	
	--ceiling collision
	if not ceiling_collide() and not p.climbing then
	--move vertically
		p.y+=p.dy
	elseif ceiling_collide() then
		--halt upward movement, begin descent
		p.dy=0
		p.dy+=g.grav
		p.y+=p.dy
		p.hold_time=26
		p.hold_time=26
	end
	
	
--climbing
	if p.climbing and p.stam>0 then
		if (p.climb_time<2)	p.sprite=52
		p.climb_time+=1
		p.dy=0
		p.dx=0
		p.air_time=0
		--ice
		if ice_collide() then 
			p.ice_time+=1
			if p.ice_time>15 then
				p.dy=g.grav+.2
				p.y+=p.dy
			end
		else
			p.ice_time=0
		end	
		if magma_collide() then
			p.stamtarget-=0.1
		end
		
	--	if obsidian_collide() then
			
	--	end
		
		
	----fix problem with climbing facing left
		if btn(⬆️) then
			---test for top of ledge
			--if at top, jump onto ledge
			--if not, climb up
		if ledge_collide() then
				p.climbing=false
				p.climb_time=0
				p.dy+=-1.8
				if (p.face) p.dx+=-0.5	else p.dx+=0.5
				move_player()
		elseif ceiling_collide() then 
			p.dy=0
		else
				if (not obsidian_collide()) climb_up()
				p.stamtarget-=0.1
				animate(p, 52, 53, 5)
				p.y+=p.dy
				p.dx=0
			end

		elseif btn(⬇️) then
		--test for bottom of ledge
		--if so, fall, if not, climb
			if climb_drop() then
				p.climbing=false
				p.climb_time=0
				if (p.face) p.dx=p.acc else p.dx=-p.acc
				p.x+=p.dx
			end
			if floor_collide() then
			--check for floor below
			--if so, drop
				p.climbing=false
				p.climb_time=0
				p.sprite=49
				if (p.face) p.dx=p.acc*2 else p.dx=-p.acc*2
				p.x+=p.dx
			else
				climb_down()
				p.stamtarget-=0.1
				animate(p, 52, 53, 5)
				p.y+=p.dy
				p.dx=0
			end
		elseif btn(➡️) then
	 	if p.face and p.climbing then
				p.climbing=false
				p.sprite=49
				p.climb_time=0
				p.x+=0.5
			end
		elseif btn(⬅️) then
			if (not p.face) and p.climbing then
				p.climbing=false
				p.sprite=49
				p.climb_time=0
				p.x-=0.5
			end
		else
			p.dy*=p.dcc
			p.sprite=52
		end
	elseif p.climbing and p.stam<1 then
		p.climbing=false
		if (p.face) p.dx=p.acc else p.dx=-p.acc
		p.x+=p.dx
	end
	if floor_collide() then
		ground_player()
	end
	
	--stamina
	increment_stam(p.stamtarget)
	if (p.stam<1) p.never_fell=false
	--coin
	if btnp(🅾️) and p.stamcoin>0 then
		if p.stamtarget<p.maxstam then
			p.stamcoin-=1
			p.stamtarget=p.maxstam
			if (p.no_green_coins) p.no_green_coins=false
		end
	end
	
	--stamina
	increment_stam(p.stamtarget)
	
	--score
	set_alt()
	set_score()
	if (p.coin_score>1) p.no_gold_coins=false
	if (p.coin_score>1799) p.all_coins=true

	
	--level transition
	if p.y<8 then
		p.x+=16*8
		p.y+=(62*8)-2
		camx+=16*8
		camy=49*8
		bg_y=0
		bg_x+=16*8
		if camx>511 and camx<767 then
			bg_color=2
			bg_y=32*8
			--pal(5,0,0)
			pal5=0
			--pal(6,5,0)
			pal6=5
			music(5)
		elseif camx>767 then
			bg_color=1
			--pal(5,5,0)
			pal5=5
			pal6=6
			--pal(6,6,0)
			bg_y=32*8
			music(0)
		end
	elseif p.y>64*8 then
		p.x-=16*8
		p.y-=(63*8)+2
		camx-=16*8
		camy=8
		bg_x-=16*8

		if camx<511 then
			bg_color=12
			bg_y=0
			pal(5,5,0)
			pal(6,6,0)
		end
	end
	
	--ending
	is_ending()
end
-->8
--functions

function floor_collide()
	--returns true if  collides
	--check bottom corners of player
    local v1=mget((p.x+2)/8,(p.y+8)/8)
    local v2=mget((p.x+5)/8,(p.y+8)/8)
    if p.dy>=0 then
    	if fget(v1,0) or fget(v2,0) then
    		return true
    	end
    end
end

function wall_collide()
	local xoffset=-1
	if p.dx>0 then xoffset=8 end
	local h=mget((p.x+xoffset)/8,(p.y+7)/8)
	if fget(h,solid) then
		return true
	end
end

function climb_collide()		
	local xoffset=-1
	if not p.face then xoffset=8 end
	local h=mget((p.x+xoffset)/8,(p.y+2)/8)
	if fget(h,climbable) then
			return true
	else
		return false
	end
end

function magma_collide()		
	local xoffset=-1
	if not p.face then xoffset=8 end
	local h=mget((p.x+xoffset)/8,(p.y+2)/8)
	if fget(h,magma) and p.climbing then
		return true
	else
		return false
	end
end

function obsidian_collide()		
	local xoffset=-1
	if not p.face then xoffset=8 end
	local h=mget((p.x+xoffset)/8,(p.y+2)/8)
	if fget(h,obsidian) then
		return true
	else
		return false
	end
end

function ice_collide()		
	local xoffset=-1
	if not p.face then xoffset=8 end
	local h=mget((p.x+xoffset)/8,(p.y+6)/8)
	if fget(h,ice) then
		return true
	else
		return false
	end
end

function ledge_collide()		
	local xoffset=-2
	if (not p.face) xoffset=9
	local h=mget((p.x+xoffset)/8,(p.y-1)/8)
	if not fget(h,solid) then
		return true
	else
		return false
	end
end

function ceiling_collide()
 v=mget((p.x+4)/8,(p.y)/8)
   
    --only check for ceilings when
    --moving up
  if p.dy<=0 then
  --look for solid tile
    if fget(v,solid) then
   		return true
    end
  end
end

function climb_floor_collide()
	local xoffset=8
	if (p.face) xoffset=0
	local h=mget((p.x+4)/8,(p.y+9)/8)
	if fget(h,solid) then
		return true
	else
		return false
	end
end

function move_player()
	p.y+=p.dy
	if (not p.climbing) p.x+=p.dx
end
function ground_player()
		p.climbing=false
		p.climb_time=0
		p.grounded=true
		p.y=flr((p.y)/8)*8
end
function climb_drop()
	local xoffset=9
	if (p.face) xoffset=-1
	local h=mget((p.x+xoffset)/8,(p.y+9)/8)
	local h2=mget((p.x+4)/8,(p.y)/8)
	if not fget(h,solid) then
				return true
			else
				return false
			end
end

function bumper_side_collide()		
	local xoffset=0
	if not p.face then xoffset=7 end
	local h=mget((p.x+xoffset)/8,(p.y-4)/8)
  
	if fget(h,bumper) then
		return true
	else
		return	false
	end
end

function bumper_top_collide()
	--local h=mget((p.x+7)/8,(p.y+4)/8)
	local h2=mget((p.x+4)/8,(p.y+4)/8)
	if fget(h2,bumper) then
 	return true
 else
 	return false
 end
end

function move_left()
	p.dx-=p.acc
	p.face=true
	p.sprite+=1
	if p.sprite>50 then
		p.sprite=49
	end
end

function move_right()
	p.dx+=p.acc
	p.face=false
	p.sprite+=1
	if p.sprite>50 then
		p.sprite=49
	end
end

function climb_up()
	p.dy-=p.climb_acc
	p.dx=0
end

function climb_down()
	p.dy+=p.climb_acc
	p.dx=0
end



--point to box intersection.
function intersects_point_box(px,py,x,y,w,h)
 if flr(px)>=flr(x) and flr(px)<flr(x+w) and
            flr(py)>=flr(y) and flr(py)<flr(y+h) then
        return true
    else
        return false
    end
end

function intersects_box_box(
    x1,y1,
    w1,h1,
    x2,y2,
    w2,h2)

    local xd=x1-x2
    local xs=w1*0.5+w2*0.5
    if abs(xd)>=xs then return false end

    local yd=y1-y2
    local ys=h1*0.5+h2*0.5
    if abs(yd)>=ys then return false end
    return true
end


--square root.
function sqr(a) return a*a end

--round to the nearest whole number.
function round(a) return flr(a+0.5) end


--
--animate functions
--
function animate(character, firstsprite, lastsprite, speed)
	character.timer+=1
	if character.timer%speed==0 then
		character.sprite+=1
		if (character.sprite>lastsprite) character.sprite=firstsprite
	end
end

function animate_item(character, firstsprite, lastsprite, speed)
	character.timer+=1
	if character.timer==4 then
		character.sprite+=1
		character.timer=0
	end
	if (character.sprite>lastsprite) character.sprite=firstsprite
end



--
--camera functions
--
function camera_init()
	--testin
	camx=0
	camy=49*8
 --camy=0*8
 --640
	--camx=384
	camera(camx,camy)
	bg_x=camx
	
end
function camera_update()
 if	p.y<camy+(10*8) then
		if camy>8 then
		 camy-=1
		 bg_y-=0.7
		end
	elseif p.y>camy+(13*8)then
		if camy<49*8 then
		 camy+=2
		 bg_y+=0.9
		end
	elseif camy>49*8 then
		camy=49*8
	end
	camera(camx,camy)	
end

--
--hud functions
--

function increment_stam(target)
	if (p.stam<target) p.stam+=1
	if (p.stam>target) p.stam-=1
end


function set_alt()

	p.alt=((p.y-495)*-1)+(496*(camx/128))
	
end

function set_score()
	if round(p.alt/2)>p.score then
		p.score+=round((p.alt/2)-p.score)
	end
end

function is_ending()
	if p.x>(95*8) and p.y<(20*8) then
		if (p.all_coins) winflag.sprite=55
		if (p.never_fell) winflag.sprite=39	
		if (p.no_gold_coins==true) winflag.sprite=41	
		if (p.all_coins and p.never_fell) winflag.sprite=62	
		if (flag_collide()) winflag.collected=true
		if (winflag.collected) end_game()
	end
end

function flag_collide()
		if intersects_box_box(winflag.x+3,winflag.y,5,8,p.x,p.y,8,8) then
  	return true
  else
  	return false
  end
end

function end_game()
	p.dx=0
	p.dy=0
	final_score()
	if winflag.y>winflag.target then
 			 winflag.y-=1 
	end
end

function final_score()
	print("you win",camx+10,camy+10,6)
	test=true
end

function minutes(seconds)
 local minutes = seconds\60
	seconds=seconds%60
	if (seconds<10) seconds="0"..seconds
 local string= " "..minutes..":"..seconds 
	return string	
end
-->8
--items
coin1={}
coin1.x=5*8
coin1.y=25*8
coin1.sprite=36
coin1.timer=0
coin1.collected=false

coin2={}
coin2.x=20*8
coin2.y=22*8
coin2.sprite=36
coin2.timer=0
coin2.collected=false

coin3={}
coin3.x=(43*8)+4
coin3.y=30*8
coin3.sprite=36
coin3.timer=0
coin3.collected=false

coin4={}
coin4.x=(50*8)
coin4.y=24*8
coin4.sprite=36
coin4.timer=0
coin4.collected=false

coin5={}
coin5.x=(67*8)
coin5.y=28*8
coin5.sprite=36
coin5.timer=0
coin5.collected=false

coin6={}
coin6.x=(92*8)
coin6.y=14*8
coin6.sprite=36
coin6.timer=0
coin6.collected=false

stam_coin1={}
stam_coin1.x=28
stam_coin1.y=50*8
stam_coin1.sprite=20
stam_coin1.timer=0
stam_coin1.collected=false

stam_coin2={}
stam_coin2.x=(9*8)-5
stam_coin2.y=36*8
stam_coin2.sprite=20
stam_coin2.timer=0
stam_coin2.collected=false

stam_coin3={}
stam_coin3.x=(25*8)-5
stam_coin3.y=47*8
stam_coin3.sprite=20
stam_coin3.timer=0
stam_coin3.collected=false

stam_coin4={}
stam_coin4.x=(25*8)-4
stam_coin4.y=(16*8)+4
stam_coin4.sprite=20
stam_coin4.timer=0
stam_coin4.collected=false

stam_coin5={}
stam_coin5.x=(44*8)-4
stam_coin5.y=(57*8)+4
stam_coin5.sprite=20
stam_coin5.timer=0
stam_coin5.collected=false

stam_coin6={}
stam_coin6.x=(33*8)+4
stam_coin6.y=(24*8)+4
stam_coin6.sprite=20
stam_coin6.timer=0
stam_coin6.collected=false

stam_coin7={}
stam_coin7.x=51*8
stam_coin7.y=61*8
stam_coin7.sprite=20
stam_coin7.timer=0
stam_coin7.collected=false

stam_coin8={}
stam_coin8.x=51*8
stam_coin8.y=(10*8)+4
stam_coin8.sprite=20
stam_coin8.timer=0
stam_coin8.collected=false

stam_coin9={}
stam_coin9.x=(78*8)-4
stam_coin9.y=(46*8)-4
stam_coin9.sprite=20
stam_coin9.timer=0
stam_coin9.collected=false

stam_coin10={}
stam_coin10.x=(67*8)
stam_coin10.y=(12*8)-4
stam_coin10.sprite=20
stam_coin10.timer=0
stam_coin10.collected=false

stam_coin11={}
stam_coin11.x=(81*8)+4
stam_coin11.y=(45*8)
stam_coin11.sprite=20
stam_coin11.timer=0
stam_coin11.collected=false

stam_coin12={}
stam_coin12.x=(92*8)
stam_coin12.y=(26*8)
stam_coin12.sprite=20
stam_coin12.timer=0
stam_coin12.collected=false

winflag={}
winflag.x=(103*8)-1
winflag.y=(6*8)-1
winflag.sprite=23
winflag.timer=0
winflag.collected=false
winflag.target=(4*8)

-->8
---bugs
--camera still scrolls down too fast/wrong
--spike blocks not functioning properly?

--to do:

-->8
--menu functions
function update_menu()
	cls(bg_color)
	map(112,32,bg_x,bg_y,128,512)
	bg_y-=0.1
	if (bg_y<-180) bg_y=0
	print('press ❎ to start',(0+64-(17*2))+1,(10*8),0)
	print('press ❎ to start',0+64-(17*2),10*8,10)
	spr(64,0+64-(15*2),5*8,9,4) 	
	print("1.1", 1,1,0)
	if btnp(❎) then
		scene="start"
	end
end