-- delunky
-- by @johanpeitz

-- a demake of spelunky created for demakejam 2018
-- special thanks to
-- * derek yu (@mossmouth) for creating spelunky
-- * matt hughson (@matthughson) for platformer starter kit
-- * darius kazemi (@tinysubversions) for great info on map generation
-- * frederic souchu (fsouchu) for pico-8 token optimisation help


--debug=false
--debug_at_top=false

function _init()
 --extcmd("rec")
 swap_state(title_state)
end

-->8
--------------------------------
-- play state 
--------------------------------

-- entity modes
-- 0 idle/ground/inair
-- 1 ladder
-- 2 ledge
-- 3 fainted
-- 4 dead

function init_play()
 menuitem(1, "accept defeat", function() damage_entity(pl,nil,99) end)
 shake(0,0)

 make_player(0,0)

 level=1
 start_next_level(level)
end

function start_next_level(level)
 max_jumps,jumps_left,ok_to_jump = 1,1,false
 particles,items,new_items,entities={},{},{},{}

 -- ratios
 local snake_ratio=    0.1+level*0.05
 local bat_ratio=      0.1+level*0.1
 local spider_ratio=       level*0.1
 local spike_ratio=    0.3+level*0.2
 local trap_ratio=     0.1+level*0.15
 local treasure_ratio= 0.1+level*0.01
 local help_count=       2

 -- make map
 local m=make_map()
 
 -- build dungeon
 cls()
 local num_rooms={12,12,12,8}
 for y=0,3 do
  for x=0,3 do
   local room_type=m[x+1][y+1] 
   -- copy room to screen
   local ry=room_type
   local rx=flr(rnd(num_rooms[1+ry])) 
   if (ry==0 and rx==11) num_rooms[1]=11 -- only one idol room please
   if (room_type==5) then -- dbl drop 
    rx,ry=9+flr(rnd(3)), 2
   end
   if (room_type==6) then -- exit
    rx,ry=9+flr(rnd(3)), 3
   end
   if (x+1!=m[5] or y+1!=m[6]) pal(7,0)
   sspr(0+rx*10,96+ry*8,10,8,x*10,y*8,10,8,chance(0.3))
   pal()
  end
 end

 -- populate tilemap
 for x=0,41 do 
  for y=0,33 do
   -- clear current data
   mset(x+1,y+1,0)

   -- set new data
   local c=pget(x,y)
   if (c==4) mset(x+1,y+1,3) -- stone
   if (c==9 and chance(0.5)) mset(x+1,y+1,3) -- rnd stone

   if (c==8 and chance(trap_ratio)) then -- arrow trap
    local d=1
    if (pget(x-1,y)==0) d=-1
    mset(x+1,y+1,16)
    make_arrow_trap(x+1,y+1,d)
   end 
   if (c==12 and chance(spike_ratio)) mset(x+1,y+1,35) -- spikes
   if (c==7) mset(x+1,y+1,1) -- entry
   if (c==6) mset(x+1,y+1,17) -- exit
   if (c==13) mset(x+1,y+1,30) -- ladder
   if (c==5) mset(x+1,y+1,14) -- ladder floor
   if (c==14 and chance(bat_ratio)) then -- bat
    local b=make_entity((x+1)*8+4,(y+1)*8+4,entities)
    add_params({
     spr=85,
     fs=8,
     name="bat",
     update=bat_update,
     on_roofhit=bat_roofhit,
     ix=0.5,
     iy=0.5,
     mode=0 --hang
    },b)
   end
   -- help(crate/damsel) or stone or gap
   if (c==15 and help_count>0) then
    if (chance(0.1)) then 
     help_count+=1
     if (chance(0.5)) then
      local help=make_item(x+1,y,57)
      help.y+=4
      help.h, help.name, help.on_hit = 8, "crate", crate_break
     else
      make_damsel(x+1,y)
     end 
   elseif (chance(0.5)) then
     mset(x+1,y+1,3)
    end
   end
   -- spider
   if (c==10 and chance(spider_ratio)) make_spider((x+1)*8+4,(y+1)*8+4,0)
   --snake
   if (c==11 and chance(snake_ratio)) make_snake((x+1)*8+4,(y+1)*8+4)
   if (c==3) then -- altar
    mset(x,y-5,78)
    mset(x+1,y-5,79)
    mset(x,y-4,94)
    mset(x+1,y-4,95)
    mset(x,y-3,0)
    mset(x+1,y-3,0)
    mset(x,y-2,110)
    mset(x+1,y-2,111)
    mset(x,y-1,127)
    mset(x+1,y-1,127)

    mset(x,y+1,32) 
    mset(x+1,y+1,33) 
    local idol=make_item(x,y,44)
    idol.x+=5
    idol.y-=4
    add_params({
     name="idol",
     h=8,
     value=100,
     on_grab=grab_idol,
     trap=true,
     big=true
    },idol)
   end
  end
 end

 -- make frame
 for x=0,41 do
  mset(x,0,3)
  mset(x,33,3)
 end
 for y=0,33 do
  mset(0,y,3) 
  mset(41,y,3)
 end 
 
 -- place gold
 for x=1,40 do
  for y=1,32 do
  
   if (mget(x,y)==3) then
    local n=is_free(mget(x,y-1))
    local s=not is_dirt(mget(x,y+1))

    -- can place item=
    if ((n and s) or (n and y>0)) then
     if (chance(treasure_ratio)) then
      make_gold(x,y-1,62+rnd(2)) -- gold
     elseif (chance(0.02)) then
       if (chance(0.6)) then
        make_item(x,y-1,29) -- stone
       else 
        local e=make_item(x,y-1,28) -- pot
        e.on_landed,e.on_sidecol,e.on_hit=pot_break,pot_break,pot_break
       end
     end
    end
    
    --have gold inside? 
    if (chance(0.1)) then
     mset(x,y,mget(x,y)+16)
    elseif (chance(0.05) and not s) then
     -- place a block
     mset(x,y,47)
    end 

   end
   
   -- background tiles
   if (mget(x,y)==0 and chance(0.2)) then
    mset(x,y,48+rnd(3))
   end

  end
 end 
 
 -- fix tile look
 auto_tile(0,0,48,34)

 -- parse level
 for x=0,41 do
  for y=0,33 do
   local tile=mget(x,y)
   -- player
   if (tile==1) then
    pl.x,pl.y = x*8+4, y*8+4
    camx,camy = pl.x-64, pl.y-64
    add(entities,pl)
   end
   -- gold
   if (tile==62 or tile==63) then
    make_gold(x,y,tile)
    mset(x,y,0)
   end
   -- item 
   if (tile==28 or tile==29) then
    make_item(x,y,tile)
    mset(x,y,0)
   end
  end
 end

end


function make_spider(x,y,mode)
 local s=make_entity(x,y,entities)
 add_params({spr=82,name="spider",update=spider_update,
  on_landed=spider_landed, 
  on_sidecol=spider_sidecol,
  mode=mode },s)

 if (mode==1) activate_spider(s)
end

function make_snake(x,y)
 local s=make_entity(x,y,entities)
 add_params({name="snake",fs=8,spr=80,frames=2,delay=5,
  dir=(chance(0.5) and 1 or -1),g=0.5,
  update=snake_update, on_sidecol=snake_sidecol
  },s)
 s.dx=s.dir/2
end

function spider_sidecol(e)
 e.dx=e.odx
end

function shake(len,pwr) 
 screenshake,screenshake_pwr=len,pwr
end

function is_free(tile)
 if(tile==0 or tile ==48 or tile ==49) return true
 return false
end

function is_dirt(tile)
 if((tile>=2 and tile<=5) or (tile>=18 and tile<=21)) return true
 return false
end

function auto_tile(sx,sy,w,h)
 for x=sx,sx+w-1 do
  for y=sy,sy+h-1 do
   local tile=mget(x,y)
   if (is_dirt(tile)) then
    local n=not is_dirt(mget(x,y-1))
    local s=not is_dirt(mget(x,y+1))
    local has_gold=(tile>15 and 16 or 0)
    if (n and s) then
     mset(x,y,5+has_gold)
    else
     if (n) mset(x,y,2+has_gold)
     if (s) mset(x,y,4+has_gold)
    end
   end

  end
 end

end

function make_player(tx,ty)
 pl=make_entity(tx*8+4,ty*8+4,entities)
 add_params({name="player",
  jumpable=false,
  g=0.5,
  spr=64,
  frames=2,
  fs=8,
  mode=0,
  draw=draw_player,
  on_landed=player_landed,
  on_air=player_fall,
  hits_from_above=true,
  collides_with_player=false,
  money=0,
  health=3,
  kills=3,
  dead_timer=0,
  grab_cooldown=0,
  whip=0,
  holding=1,
  item=nil, 
  stowed=nil,
  bombs={},
  ropes={}
 },pl)

 add_ropes(3)
 add_bombs(3)
end

function add_bombs(amnt)
 for i=1,amnt do
  local b=make_bomb(0,0)
  add(pl.bombs,b)
  del(items,b)  
 end
end

function add_ropes(amnt)
 for i=1,amnt do
  local b=make_rope(0,0)
  add(pl.ropes,b)
  del(items,b)  
 end
end

function crate_break(e)
 del(e.tbl,e)
 for i=0,6 do
  local e=make_entity(e.x,e.y,particles)
  add_params({
   spr=104,ix=1,g=0.3,col=false,
   dir=sgn(rnd()-0.5),
   dx=rnd(2)-1,
   dy=-rnd(1),
   life=5+rnd(5)
   },e)
 end

 local e=make_entity(e.x,e.y,items)
 e.spr=39+flr(rnd(2))
 e.g, e.can_take, e.value = 0.5,true, (e.spr==39 and -1 or -2)
end

function pot_break(e,whipped)
 if (abs(e.odx)>2 or abs(e.ody)>2 or whipped) then
  del(e.tbl,e)
  local r=rnd()
  if (r<0.2) then
   make_snake(e.x,e.y)
  elseif (r<0.4) then
   make_spider(e.x,e.y,1)
  elseif (r<0.6) then
   make_gold(e.x/8,e.y/8,60+rnd(4))
  end

  for i=0,6 do
   local e=make_entity(e.x,e.y,particles)
   add_params({
    spr=103,ix=1,g=0.3,col=false,
    dir=sgn(rnd()-0.5),
    dx=rnd(2)-1,
    dy=-1-rnd(2),
    life=5+rnd(5)
    },e)
  
  end
 end
end

function make_arrow_trap(tx,ty,d)
 local e=make_entity(tx*8+4,ty*8+4,entities)
 add_params({
  name="arrow trap",
  spr=34,
  dir=d, 
  col = false,
  update=update_arrow_trap,
  ammo=1
  },e)
end

function is_triggering_arrow_trap(at,e)
 local dist=48 -- 6 tiles
 if (e.dx!=0 or e.dy!=0) then
  local in_range=false
  if (at.dir>0 and e.x>at.x and e.x<at.x+dist) in_range=true
  if (at.dir<0 and e.x<at.x and e.x>at.x-dist) in_range=true
  if (in_range) then
   if (e.y>=at.y-5 and e.y<=at.y+3) then
    return true -- fire!
   end
  end
 end
 return false
end

function update_arrow_trap(at)
 if (at.ammo==0) return
 --update_entity(e)
 for e in all(items) do
  if (is_triggering_arrow_trap(at,e)) then
   fire_arrow(at)
   return
  end
 end

 for e in all(entities) do
  if (is_triggering_arrow_trap(at,e)) then
   fire_arrow(at)
   return
  end
 end

end

function fire_arrow(at)
 sfx(3)
 at.ammo-=1
 local e=make_entity(at.x+at.dir*7,at.y,new_items)
 add_params({
  name="arrow",
  spr=43,
  h = 4,
  dir=at.dir,
  dy=-1,
  dx=7*at.dir, 
  ix=0.98,
  g = 0.5,

  knock_down=true,
  damage = 2,

  use=item_throw,
  drop=item_drop,
  on_landed=item_landed,
  on_sidecol=item_sidecol,
  can_grab=true

 },e)
end

function spider_update(e)
 local dx=pl.x-e.x
 
 if (e.health>0) then
  if (e.mode==0) then
   if (pl.y>e.y and abs(dx)<8) activate_spider(e)
  else
   if (e.jump_delay>0) e.jump_delay-=1
   if (e.jump_delay<=0 and not e.inair) then
    e.spr=84
    e.dx, e.dy = dx/20, -rnd(3)-3
   end
  end
 end

 update_entity(e)
end

function activate_spider(e)
 e.mode,e.spr=1,84
 e.g, e.ix, e.jump_delay = 0.5, 1, 5
end

function spider_landed(e)
 e.jump_delay=5+rnd(10)
 e.spr=83
 e.dx=0
end

function bat_update(e) 
 local dx, dy = pl.x-e.x, pl.y-e.y+4
 local d=sqrt(dx*dx+dy*dy)
 local a=atan2(dx,dy)

 if (e.health>0) then
 
  if (e.mode==0) then -- hang
   if (d<48 and pl.health>0 and e.y<pl.y+1) then
    e.spr, e.frames, e.frame=86,2,1
    e.mode=1
   end
  elseif (e.mode==1) then -- track
   e.dx, e.dy = 0.5*cos(a), 0.5*sin(a)
   e.dir=sgn(e.dx)

   if (d>80 or pl.health<=0) e.mode=2
  else -- return to ceiling
   e.dy-=0.2
  end
 end

 update_entity(e) 
end

function bat_roofhit(e)
 if (e.mode!=2) return
 e.spr=85
 e.frame, e.frames = 0,0
 e.mode=0
 e.dx,e.dy=0,0
end

function snake_update(e)
 e.delay-=1

 if (e.bleed_timer>0) then
  --e.dx=0
  e.fs, e.frames=9999, 1
  e.spr=102
  e.delay=99
 end

 if (e.delay<0) then
  if (chance(0.1)) then
   e.dx=0
   e.delay=15+rnd(60)
  else
   e.dir=(chance(0.5) and 1 or -1)
   e.dx=0.2*e.dir
   e.ix=1
   e.delay=60+rnd(60)
  end
 end

 if (not e.inair and fget(mget((e.x+e.dir*2)/8,e.y/8+1))==0) then
  e.dir=-e.dir
  e.dx=-e.dx
 end
 update_entity(e)
end

function snake_sidecol(e)
 e.delay=0
end

function check_item_exit(e)
 if (fget(mget(e.x/8,(e.y-4)/8),7)) then
  if (e.name=="idol") pl.money+=e.value
  del(e.tbl,e)
  pl.item=nil
  switch_to_whip()
  sfx(7)
 end
end

function grab_idol(idol)
 if (idol.trap) then
  idol.trap=false
  -- make boulder
  local e=make_entity(-100,-100,entities)
  add_params({
   name="boulder",
   flip_on_hit=false,
   knock_down=true,
   jumpable=false,
   spr=74,
   fs=2,
   frames=2,
   tw=2,
   th=2,
   ix=1,
   dy=0,
   g=1,

   damage=99,
   health=9999,

   w=16,
   h=16,
    
   spawnx=idol.x-1,
   spawny=idol.y-24,
   delay=60,
   update=boulder_update,
   on_landed=boulder_landed

  },e)

  shake(e.delay,3)
 end
end

function boulder_update(e)
 if (e.delay>0) then
  e.delay-=1
  if (e.delay==0) then
   e.x,e.y = e.spawnx,e.spawny
   e.dy=0.01

   e.dir=sgn(pl.x-e.x)
   shake(2,6)
   e.dropped=false
  end
 else
  local bx=e.x/8+e.dir
  local by=e.y/8
  local tiles=0
  if (fget(mget(bx,by),0)) then crush_tile(bx,by,e.dx) tiles+=1 end
  if (fget(mget(bx,by-1),0)) then crush_tile(bx,by-1,e.dx) tiles+=1 end
  e.dx-=0.20*tiles*sgn(e.dx)
  update_entity(e) 
  if (tiles>0) then
   auto_tile(bx,by-2,1,4)
   shake(3,3)
   sfx(6)
  end

  if (abs(e.dx)<0.6 and e.dy==0) then
   local tx=e.x/8
   local ty=e.y/8-1
   mset(tx,ty,74)
   mset(tx+1,ty,75)
   mset(tx,ty+1,90)
   mset(tx+1,ty+1,91)
   del(e.tbl,e)
  end
 end
end

function crush_tile(tx,ty,v)
 -- check for gold
 local tile=mget(tx,ty)
 if (tile>=18 and tile<=21) make_gold_pieces(tx,ty)

 -- remove tile
 mset(tx,ty,0)

 -- particles
 local amnt=3+rnd(3)
 for i=1,amnt do
  local p=make_entity(tx*8,ty*8,particles)
  add_params({
   spr=120+rnd(2),
   ix=0.98,
   dx=v*(1+rnd(1)),
   dy=-1-rnd(1),
   g=0.3,
   life=20+rnd(10),
   col=false
  },p)
  
 end
end

function boulder_landed(e)   
 if (not e.dropped) then
  e.dx=3*e.dir 
  e.dropped=true
 end
 shake(6,6)
 sfx(6)
end

function make_gold(tx,ty,tile)
 local e=make_entity(tx*8+4,ty*8+4,items)
 e.spr=flr(tile)
 e.g,e.value,e.can_take=0.5,5,true
 if (e.spr==60 or e.spr==62) e.value*=3
 return e
end

function make_item(tx,ty,tile)
 local e=make_entity(tx*8+4,ty*8+3,items)
 add_params({
  name="#"..tile,
  spr=tile,
  ix=0.98,
  g=0.5,
  h=4,
  use=item_throw,
  drop=item_drop,
  on_landed=item_landed,
  on_sidecol=item_sidecol,
  can_grab=true
 },e)
 e.y+=4
 return e
end


function item_sidecol(e) 
 e.dx=-e.odx*0.5
 if (abs(e.dx)<0.1) e.dx=0
end

function item_landed(e) 
 e.dx*=0.3
 if (abs(e.dx)<0.2) e.dx=0
 if (abs(e.ody)>2) then
  e.dy=-e.ody*0.3
 else
  e.dx=0
 end
end

function item_throw(e)
 e.cooldown,e.damage=3,1
 e.dx=pl.dir*(pl.dy<0 and 3 or 4)
 e.dy=(pl.dy<0 and -5 or -2)
 pl.item=nil
 switch_to_whip()
 sfx(3)
end

function item_drop(e)
 e.cooldown,e.dy=3,-1
 e.dx=pl.dir/2 
 pl.item=nil
 switch_to_whip()
 sfx(3)
end

function make_damsel(x,y)
 local di=make_item(x,y,11)
 di.name="damsel"
 di.y+=4
 di.h,di.big=8 ,true

 local de=make_entity(di.x,di.y,entities)
 de.name="damsel"
 de.spr=16
 de.collides_with_player=false
 de.update=damsel_e_update
 de.item=di
 de.health=3
 de.damage=0

 di.entity=de

 local p={
  g=0.5,
  ix=0.98
 }

 add_params(p,di)
 add_params(p,de)
end

function damsel_e_update(e)
 update_entity(e)

 e.x=e.item.x
 e.y=e.item.y

 -- dead?
 if (e.health<1) e.item.spr=13

 -- at gate?
 if (fget(mget(e.x/8,(e.y-4)/8),7)) then
  pl.health+=1
  del(e.tbl,e)
  del(e.item.tbl,e.item)
  pl.item=nil
  switch_to_whip()
  sfx(7)
 end
 
end

function make_bomb(tx,ty)
 local e=make_item(tx,ty,25)
 add_params({
  name="bomb",
  h=4,
  use=bomb_throw,
  drop=bomb_drop,
  update=bomb_update,
  timer=0
 },e)
 return e
end

local hitarea={ {0,0,1,0,0},
                {0,1,1,1,0}, 
                {1,1,1,1,1}, 
                {0,1,1,1,0}, 
                {0,0,1,0,0} }
function bomb_update(e)
 if (e.timer>0) then
  e.timer-=1
  e.spr=26+flr(e.timer/2)%2
  if (e.timer==0) then
   e.life=1
   -- explode
   shake(5,6)
   make_explosion(e.x-8,e.y-8)
   -- destroy entities & tiles
   local ex=flr(e.x/8)
   local ey=flr(e.y/8)
   for x=1,5 do
    for y=1,5 do
     if (hitarea[x][y]==1) then
      local tx=ex+x-3
      local ty=ey+y-3
      --entities
      for e2 in all(entities) do
       if (abs(tx*8+4-e2.x)<9 and abs(ty*8+4-e2.y)<9) damage_entity(e2,nil,99,0)
      end
      --tile
      local tile=mget(tx,ty)
      if (tile>=2 and tile<=5) mset(tx,ty,0)
      if (tile==47 or tile==35 or tile==36) mset(tx,ty,0)
      if (tile>=18 and tile<=21) then
       mset(tx,ty,0)
       make_gold_pieces(tx,ty)
      end
     end
    end
   end
   auto_tile(ex-2,ey-3,5,7)
  end
 end

 update_entity(e)
end

function make_gold_pieces(tx,ty)
 local amnt=rnd(3)+1
 for i=1,amnt do
  local g=make_gold(tx,ty,60+rnd(2))
  add_params({
   dx=rnd(5)-3,
   dy=rnd(5)-3,
   g=0.5,
   ix=0.98,
   can_take=true,
   inair=true
  },g)
 end
end

function bomb_throw(e)
 bomb_activate(e)
 item_throw(e)
end

function bomb_drop(e)
 bomb_activate(e)
 item_drop(e)
end

function bomb_activate(e)
 e.spr=26
 e.timer=60
 e.can_grab=false
end

function make_explosion(x,y)
 sfx(5)
 -- dirt
 local amnt=8+rnd(8)
 for i=1,amnt do
  local e=make_entity(x+rnd(24),y-8+rnd(32),particles)
  add_params({
   spr=118+rnd(2),
   dir=sgn(rnd(2)-1),
   dy=rnd(0.6)+0.4,
   g=0.1,
   life=10+rnd(4),
   col=false,
  },e)
 end

 -- smalls
 amnt=8+rnd(8)
 for i=1,amnt do
  local e=make_entity(x+8,y+8,particles)
  local a=rnd(0.7)-0.1
  local f=2+rnd(2)
  add_params({
   spr=112,
   dir=sgn(rnd(2)-1),
   dx=f*cos(a),
   dy=f*sin(a),
   ix=0.95,
   g=0.3,
   fs=2+flr(rnd(3)),
   frames=6,
   col=false
  },e)
  e.life=e.fs*e.frames-1
 end

 -- big
 local e=make_entity(x,y,particles)
 add_params({
  dir=sgn(rnd(2)-1),
  spr=144,
  tw=3,
  th=3,
  fs=2,
  frames=3,
  col=false  
 },e)
 e.life=e.fs*e.frames-1
end

function make_rope(tx,ty)
 local e=make_item(tx,ty,41)
 add_params({
  name="rope",
  use=rope_throw,
  drop=rope_drop,
  activated=false,
  on_roofhit=rope_roof_hit,
  on_landed=rope_on_landed,
  update=rope_update,
  steps=0,
  h=8,
  flip_on_hit=false
 },e)
 return e
end

function rope_update(e)
 if (e.activated) then
  local tx=flr(e.x/8)
  local ty=flr(e.y/8)
  if (mget(tx,ty)!=31 and mget(tx,ty)!=15) then
   if (e.steps==0 and e.dy>0) then
    mset(tx,ty,15)
   else
    mset(tx,ty,31)
   end
   e.steps+=1
   if (e.steps==8) then
    e.on_roofhit(e)
   end
  end
 end
 update_entity(e)
end

function rope_drop(e)
 -- can drop?
 local tx=flr((e.x+pl.dir*4)/8)+pl.dir*0
 local ty=flr(e.y/8)
 local ty2=flr(e.y/8)+1

 if (not is_solid(tx,ty) and not is_solid(tx,ty2)) then
  add_params({
   x=tx*8+4,
   spr=31,
   dy=4,
   dir=1,
   g=0,
   activated=true
  },e)
  pl.item=nil
  switch_to_whip()
 else
  -- do nothing. item_drop(e)
 end
end

function rope_throw(e)
  sfx(3)
  -- adjust position
  e.x=flr(e.x/8)*8+4
  e.y-=5

  -- make sure there is nothing direcly on top
  if (fget(mget(e.x/8,e.y/8),0)) then
   return
  end

  -- drop it
  e.spr=15
  e.dy=-4
  e.dir=1
  e.g=0
  e.activated=true
  pl.item=nil
  switch_to_whip()
end

function rope_on_landed(e)
 del(items,e)
end

function rope_roof_hit(e)
 mset(flr(e.x/8),flr(e.y/8),(e.dy>0 and 31 or 15))
 del(items,e)
end

function player_fall()
 jumps_left=max(0,jumps_left-1)
end

function player_faint()
 pl.bleed_timer=(pl.health==0 and 60 or 30)
 pl.faint_timer=pl.bleed_timer

 if (pl.mode==4) return

 pl.mode, pl.spr = 3, 68
 pl.frame, pl.frames = 0,1

 if (pl.item!=nil and pl.holding==1) then
  pl.item.drop(pl.item)
  pl.item=nil
 end
end 

function player_landed(e)
 jumps_left=max_jumps

 local impact=0
 if (pl.ody>=8) impact+=1
 if (pl.ody>=11) impact+=1
 if (pl.ody>=13) impact+=97

 if (impact>0) then
  damage_entity(pl,nil,impact)
  player_faint()
 end

 if (pl.mode==3) then -- fainted
  -- bounce
  if (pl.ody>3) then
   pl.dy=-0.3*pl.ody
  end
 end
end

function drop_from_ledge()
 add_params({mode=0,spr=64,frames=2,dx=-pl.dir,grab_cooldown=5},pl)
end

ok_to_jump, ok_to_crouch = true,true

maxdy=0
function update_play()
 -- add for additional 18 tokens
 --if (btnp(0,1)) extcmd("rec") 
 --if (btnp(3,1)) extcmd("video")

 if (not btn(⬆️)) ok_to_jump=true
 if (not btn(⬇️)) ok_to_crouch=true

 -- mode 0 = idle/ground/jump
 if (pl.mode==0) then
  if (pl.item!=nil and pl.item.name=="idol") check_item_exit(pl.item)

  if (btnp(🅾️)) switch_item()

  if (pl.grab_cooldown>0) pl.grab_cooldown-=1
 
  pl.grab=false
  -- left/right
  if (btn(⬅️)) then 
   pl.dx-=2 pl.dir=-1 pl.grab=true
  end
  if (btn(➡️)) then
   pl.dx+=2 pl.dir=1 pl.grab=true
  end
  
  -- whip?
  if (btnp(❎) and pl.item==nil) then
   pl.whip=10
   sfx(0)
  end
  if (pl.whip>0) pl.whip-=1

  -- use item?
  if (btnp(❎) and pl.item!=nil) then
   if (btn(⬇️)) then
    pl.item.drop(pl.item)
    ok_to_crouch=false
   else
    pl.item.use(pl.item)
   end
  end
  
  -- jump / grab climable
  if (btn(⬆️)) then
   -- check for climbables
   if (fget(mget(pl.x/8,pl.y/8),2)) then
    pl.mode=1
    pl.dx=0
   elseif (fget(mget(pl.x/8,pl.y/8),7)) then
    --exit_level()
    level+=1
    start_next_level(level)
   elseif (jumps_left>0 and ok_to_jump) then
    -- regular jump
    pl.dy=-3.2
    jumps_left-=1
    pl.inair=true
    ok_to_jump=false
    sfx(4)
   end
  end

  -- climb down
  if (btn(⬇️)) then
   -- check for climbables
   if (fget(mget(pl.x/8,(pl.y+4)/8),2)) then
    pl.mode=1
    pl.dx=0
    pl.y+=1
   end
  end

 elseif (pl.mode==1) then 
  -- mode 1 = climbing
  pl.whip=0
  pl.dy=0
  pl.spr=70

  pl.x+=(8*flr(pl.x/8)+4 - pl.x)*0.4

  if (btn(⬆️)) pl.dy=-1
  if (btn(⬇️)) pl.dy=1

  local drop=false
  if (btn(⬅️)) then 
   pl.dx-=2 pl.dir=-1 
   drop=true
  end
  if (btn(➡️)) then
   pl.dx+=2 pl.dir=1 
   drop=true
  end
   
  -- still on climbable?
  if (not fget(mget(pl.x/8,(pl.y-2)/8),2) and not fget(mget(pl.x/8,(pl.y+3)/8),2)) drop=true

  if (drop) then
   add_params({
    inair=true,
    mode=0,
    spr=64,
    frame=0,
    frames=2
   },pl)
   ok_to_jump=false
  end
 
 elseif (pl.mode==2) then
  -- mode 2 = ledge 
   
  -- drop big items om ledge
  --if (pl.item and pl.holding==1 and pl.item.big) then
  -- pl.item.drop(pl.item)
  -- pl.item=nil
  --end

  add_params({
   whip=0,
   dx=0,
   dy=0,
   spr=69,
   frame=0,
   frames=1
  },pl)

  if (btn(⬆️) and ok_to_jump) then
   add_params({
    mode=0,
    spr=64,
    frame=0,
    frames=2,
    dy=-1
   },pl)
  
   ok_to_jump=false
  end

  if (btn(⬇️)) drop_from_ledge()  

 elseif (pl.mode==3) then 
  -- mode 3 = fainted
  pl.whip=0

  pl.faint_timer-=1
  if (pl.faint_timer==0) then
   if (pl.health>0) then
    pl.spr=64
    pl.frames=2
    pl.ix=0
    pl.mode=0
   else
    --dead
    pl.mode=4
   end
  end 

  -- tears, not uses any more
  --[[
  if (pl.dy==0 and rnd()<0.99 and pl.health>0) then
   local e=make_entity(pl.x,pl.y+3,particles)
   add_params({
    spr=96+flr(rnd(3)),
    dy=-1,
    dx=(rnd()<0.5 and -1 or 1)/2,
    ix=1,
    g=0.2,
    life=7+flr(rnd(4)),
    col=false
   },e)
  end
  ]]--
 elseif (pl.mode==4) then
   -- mode 4 = dead
   pl.dead_timer+=1
   if (btnp(❎) and pl.dead_timer>15) swap_state(title_state)
 end
 
 -- idle anim
 --if (pl.mode==0) then
 -- pl.spr=64
 -- if (abs(pl.dx)==0) pl.spr=(pl.inair==false and 66 or 64)
 --end
 
 for e in all (items) do
  if (e.inair==true) then 
   -- check for impact with entities
   for e2 in all (entities) do
    if (e.cooldown==0 or e2!=pl) then
     local v=sqrt(e.dx*e.dx+e.dy*e.dy)
     if (v>3 and abs(e2.x-e.x)<5 and 
         abs(e2.y-e.y)<5) then
      if (not(e.name=="rope" and e2==pl) and e.name!=e2.name) then
       damage_entity(e2,e)
       if (e.flip_on_hit) e.dx=-e2.dx/2
      end
     end
    end
   end
  end

  -- instant pickup?
  if (e.can_take) then
   if (abs(pl.x-e.x)<4 and abs(pl.y-e.y)<4) then
    if (e.value!=nil) then
     sfx(7)
     if (e.value==-2) add_bombs(3)
     if (e.value==-1) add_ropes(3)
     if (e.value>0) pl.money+=e.value
    end
    del(items,e)
   end    
  end

  if (e!=pl.item) then
   -- pickup item?
   if (pl.mode==0 and btn(⬇️) and
       e.can_grab and
       not pl.inair and
       abs(pl.x-e.x)<5 and 
       abs(pl.y-e.y)<5 and
       ok_to_crouch) then
    if (pl.stowed_item!=nil) then 
     add(items,pl.stowed_item)
     set_item_to_player_pos(pl.stowed_item)
     pl.stowed_item.inair=true
     pl.stowed_item=nil
    end
    if (pl.holding==2) then
     del(items,pl.item)
     add(pl.bombs,pl.item)
    end
    if (pl.holding==3) then
     del(items,pl.item)
     add(pl.ropes,pl.item)
    end
    
    pl.item=e  
    pl.holding=1
    ok_to_crouch=false
    if (e.on_grab) e.on_grab(e)
   end

   e.update(e)

  end

  -- check whip
  if (pl.whip>0) then
   if (abs(pl.x+8*pl.dir-e.x)<6 and 
       abs(pl.y-e.y+2)<8 and e.on_hit) then 
    e.on_hit(e,true) 
    pl.whip=0
   end
  end

 end
 
 for e1 in all (entities) do
  -- e2e collision
  for e2 in all (entities) do
   if (e1!=e2 and e1.damage>=0 and (e1.collides_with_player or e2.collides_with_player )) then
    if (abs(e2.x-e1.x)<(e2.w+e1.w)/2-2 and 
        abs(e2.y-e1.y)<(e2.h+e1.h)/2-2) then
     e2e_coll(e1,e2)
    end
   end
  end  

  -- spikes?
  if (e1.inair and e1.health>0 and e1.name!="bat") then
   local tx=flr(e1.x/8)
   local ty=flr((e1.y+3)/8)
   if (e1.dy>0 and fget(mget(tx,ty),3)) then
    mset(tx,ty,36)
    damage_entity(e1,nil,99)
   end
  end


  -- check whip
  if (e1!=pl and pl.whip>0) then
   if (abs(pl.x+8*pl.dir-e1.x)<6 and 
       abs(pl.y-e1.y)<6 and
       e1.bleed_timer==0) then 
    damage_entity(e1,nil,1,pl.dir,-1)  
   end
  end

  -- update it
  e1.update(e1)
 end

 if (pl.item!=nil) then
  set_item_to_player_pos(pl.item)
 end
    
 for e in all (particles) do
  e.update(e)
 end

 -- add new items
 for e in all(new_items) do
  add(items,e)
 end
 new_items={}
end

function bleed(x,y)
 local e=make_entity(x,y,particles)
 add_params({
  spr=99,
  dx=rnd(4)-2,
  dy=-1-rnd(),
  ix=0.95,
  g=0.5,
  fs=3+flr(rnd(3)),
  frames=3,
  col=false
 },e)
 e.life=e.fs*e.frames-1
end

-- e1 hits e2
function e2e_coll(e1,e2)
 --debug_str=e1.name.."+"..e2.name

 -- no hit if already bleeding
 if (e1.bleed_timer>0 or e2.bleed_timer>0) return

 local over,under=e1,e2
 if (e2.y<e1.y) then
  over=e2
  under=e1
 end

  -- if coming from above
 if (over.hits_from_above and over.inair and over.dy>0 and under.jumpable) then
   damage_entity(under,over,0,-3)
   if (over.flip_on_hit) over.dy=-3
 else
  -- regular hit only if player or boulder is involved
  if (over==pl or over.name=="boulder") damage_entity(over,under,1*sgn(over.x-under.x),-1)
  if (under==pl or over.name=="boulder") damage_entity(under,over,1*sgn(under.x-over.x),-1)
 end
end

function damage_entity(e1,e2,impact,dx,dy)
 if (e2!=nil) then
  e1.health-=e2.damage
  if (e1.flip_on_hit) e1.dx=3*sgn(e1.x-e2.x)
 else
  e1.health-=impact
 end
  
 if (dx) e1.dx+=dx
 if (dy and e1.flip_on_hit) then
  e1.inair=true
  e1.dy+=dy
 end

 if (e1.health<=0 and e1!=pl) then
  e1.ix=0.7
  pl.kills+=1
 end

 e1.dy, e1.bleed_timer =- 3, 30

 if (e1==pl) then
  if ((e2 and e2.knock_down) or pl.health<=0) then
   player_faint()
  elseif (pl.mode==2) then
   drop_from_ledge()
  end
 end
 sfx(1)
end

function set_item_to_player_pos(e)
 e.x, e.y = pl.x+pl.dir*3, pl.y+pl.frame-1-e.h/2+4
 e.dir=pl.dir
end

function switch_to_whip()
 pl.holding=1

 -- use stowed item if any
 if (pl.stowed_item!=nil) then
  pl.item=pl.stowed_item
  pl.stowed_item=nil
  add(items,pl.item)
 else
  pl.item=nil
 end
end

function switch_item()
  if (pl.item and pl.item.big) return
  -- handle current item
  if (pl.holding==1) then
   if (pl.item!=nil) then
    -- stow away
    del(items,pl.item)
    pl.stowed_item=pl.item
    pl.item=nil
   end
  end
  if (pl.holding==2) then
   add(pl.bombs,pl.item)
   del(items,pl.item)
   pl.item=nil
  end
  if (pl.holding==3) then
   add(pl.ropes,pl.item)
   del(items,pl.item)
   pl.item=nil
  end   
   
  -- check for next item
  pl.holding+=1
  if (pl.holding==2 and #pl.bombs==0) pl.holding+=1
  if (pl.holding==3 and #pl.ropes==0) pl.holding+=1
  if (pl.holding>3) pl.holding-=3
 
  -- set next item
  -- whip/item
  if (pl.holding==1) then
   pl.item=nil
   switch_to_whip()
  end
  -- bombs
  if (pl.holding==2) then
   pl.item=pl.bombs[1]
   add(items,pl.item)
   pl.item.tbl=items
   del(pl.bombs,pl.item)
  end
  --ropes
  if (pl.holding==3) then
   pl.item=pl.ropes[1]
   add(items,pl.item)
   pl.item.tbl=items
   del(pl.ropes,pl.item)
  end
   
  
end

function die(tile)
 add_params({
  mode=99,

  spr=68,
  frame=0,
  frames=1,
  dy=0.4,
  dx=0,
  t=0
 },pl)
end

function draw_player()
 draw_entity(pl)
 if (pl.whip>0) then
  local s=122
  if (pl.whip<9) s=123
  if (pl.whip<9) s=124
  spr(s,pl.x+pl.dir*6-4,pl.y-4+pl.frame%2,1,1,pl.dir==-1)
 end
end

function draw_play()
 cls()
 
 local lx,ly=pl.x-camx,pl.y-camy

 -- pan camera but give player some room to move around in
 if (lx<48) camx-=2
 if (lx>80) camx+=2
 if (ly<48) camy+=(ly-48)*0.5
 if (ly>80) camy+=(ly-80)*0.5

 local sx,sy=0,0
 if (screenshake>0) then
  screenshake-=1
  sx=rnd(screenshake_pwr)-screenshake_pwr/2
  sy=rnd(screenshake_pwr)-screenshake_pwr/2
 end

 -- lock camera inside map (and shake if needed)
 camera(min(208,max(camx,0))+sx,
        min(144,max(camy,0))+sy)
 --camera(camx+sx,camy+sy)
 
 map(0,0,0,0,50,34)

 for e in all (entities) do
  e.draw(e)
 end
 
 for e in all (items) do
  e.draw(e)
 end

 for e in all (particles) do
  e.draw(e)
 end
 
 -- hud
 camera()
 spro(25,0,4,0)
 printo(#pl.bombs,11,3,7,0)
 spro(41,21,0,0)
 printo(#pl.ropes,31,3,7,0)
 spro(62,45,0,0)
 printo(pl.money*10,56,3,7,0)

 for i=1,pl.health do
  spro(42,128-i*9,2,0)
 end

 -- instructions, 10 seconds, first level
 if (pl.t<300 and level==1) then
  rectfill(0,114,127,127,1)
  print("arrows - move, jump, and climb",4,115,7)
  print(" z / x - use and handle items",4,122,7)
 end

 -- game over
 if (pl.mode==4) then
  local y=max(44,128-pl.dead_timer)
  printo("game over",        46,y,7,1)
  printo("depth: "..level,   42,y+20,7,1)
  printo(" gold: "..pl.money*10,42,y+28,7,1)
  printo("kills: "..pl.kills,42,y+36,7,1)
 end
end

function spro(id,dx,dy,oc)
 for i=0,15 do 
  pal(i,oc) 
 end
  
 for x=-1,1 do
  for y=-1,1 do
   spr(id,dx+x,dy+y)
  end
 end
 pal()
 spr(id,dx,dy)
end

play_state = {
 name = "play",
 init = init_play,
 update = update_play,
 draw = draw_play
}

----
-- title screen
----

function init_title()
 bgy,t=0,0
 menuitem(1)
end

function update_title()
 bgy-=0.5
 if (bgy<-256) bgy=0
 t+=1
 if (btnp(❎)) swap_state(play_state)
end

function draw_title()
 cls()
 map(112,0,0,bgy)
 map(112,0,0,bgy+256)

 pal(4,2)
 spr(185,36,33,7,1)
 pal()
 spr(185,36,32,7,1)

 prints("-endless descent-",30,42,2,1)
 prints("press ❎",48,64,(t%32<16 and 4 or 2),1)
 prints("a demake by @johanpeitz",18,120,2,1)
end

title_state = {
 name = "title",
 init = init_title,
 update = update_title,
 draw = draw_title
}

-->8
--------------------------------
-- core functions 
--------------------------------
--debug_str=""

--------------------------------
-- state swapping 
--------------------------------
state, next_state, change_state = {}, {}, false

function swap_state(s)
 next_state, change_state = s, true
end

--------------------------------
-- _base functions 
--------------------------------
function _update()
 if (change_state) then
  state, change_state = next_state, false
  state.init()
 end

 state.update() 
end

function _draw()
 state.draw()
 
 -- debug, 175 tokens
 --[[
 if (debug) then
  camera()
  
  local str = state.name .. " "
    
  if (btn(0)) str = str .. "⬅️"
  if (btn(1)) str = str .. "➡️"
  if (btn(2)) str = str .. "⬆️"
  if (btn(3)) str = str .. "⬇️"
  if (btn(4)) str = str .. "🅾️"
  if (btn(5)) str = str .. "❎"  

  str = str .. " " .. debug_str
  
  local mr = stat(0)/1024

  local ypos = 121
  if (debug_at_top) ypos=0
  rectfill(0,ypos,127,ypos+6,8)
  
  line(1, ypos+2, 8, ypos+2, 1)
  line(1, ypos+2, 1+min(7*stat(1),7), ypos+2, (stat(1)>1 and 8 or 12))
  
  line(1, ypos+4, 8, ypos+4, 2)
  line(1, ypos+4, 1+min(7*mr,7), ypos+4, (mr>1 and 8 or 14))
  print(str,10,ypos+1,15)

  debug_str = ""
 end
 ]]--
 
end

-->8
--------------------------------
-- utilities
--------------------------------

function chance(a)
 return rnd()<a
end

function add_params(src,dst)
 for k,v in pairs(src) do
  dst[k]=v
 end
end

function is_solid(tx,ty)
 return fget(mget(tx,ty),0)
end

--check if pushing into side tile and resolve.
--requires self.dx,self.x,self.y, and 
--assumes tile flag 0 == solid
--assumes sprite size of 8x8
function collide_side(self)

 local offset=4--self.w/3
 local data={}
 for i=-(self.h/3),(self.h/3),2 do -- used to be .w???
 --if self.dx>0 then
  t=mget((self.x+(offset))/8,(self.y+i)/8)
  if fget(t,0) then
   self.odx=self.dx
   self.dx=0
   self.x=(flr(((self.x+(offset))/8))*8)-(offset)
   data.tile=t
   data.tx=flr((self.x+(offset))/8)
   data.ty=flr((self.y+i)/8)
   return data
  end
 --elseif self.dx<0 then
  t=mget((self.x-(offset))/8,(self.y+i)/8)
  if fget(t,0) then
   self.odx=self.dx
   self.dx=0
   self.x=(flr((self.x-(offset))/8)*8)+8+(offset)
   data.tile=t
   data.tx=flr((self.x-(offset))/8-1)
   data.ty=flr((self.y+i)/8)
   return data
  end
-- end
 end
 --didn't hit a solid tile.
 return nil
end

--check if standing on air
function should_fall(self)
 if (self.inair) return true
 local air=true
 for i=-(self.w/3),(self.w/3),2 do
  local newty=flr((self.y+(self.h/2)+1)/8)
  local tile=mget((self.x+i)/8,newty)
  if (fget(tile,0) or fget(tile,1)) then
   air=false
  end
 end
 return air
end

--check if pushing into floor tile and resolve.
--requires self.dx,self.x,self.y,self
--assumes tile flag 0 or 1 == solid
function collide_floor(self)
 --only check for ground when falling.
 if self.dy<0 then
  return false
 end
 local landed=false
 --check for collision at multiple points along the bottom
 --of the sprite: left, center, and right.
 for i=-(self.w/3),(self.w/3),2 do
  local newty=flr((self.y+(self.h/2))/8)
  local tile=mget((self.x+i)/8,newty)
  if fget(tile,0) then
   landed=true
  end
  if (fget(tile,1) and pl.mode!=1) then
   if (self.lastty<newty) landed=true
  end
 end

 if (landed) then
  self.ody=self.dy
  self.dy=0
  self.y=(flr((self.y+(self.h/2))/8)*8)-(self.h/2)
 end

 return landed
end

--check if pushing into roof tile and resolve.
--requires self.dy,self.x,self.y, and 
--assumes tile flag 0 == solid
function collide_roof(self)
 --check for collision at multiple points along the top
 --of the sprite: left, center, and right.
 local collided=false
 for i=-(self.w/3),(self.w/3),2 do
  if fget(mget((self.x+i)/8,(self.y-(self.h/2))/8),0) then
   self.dy=0
   self.y=flr((self.y-(self.h/2))/8)*8+8+(self.h/2)
   collided=true
  end
 end
 return collided
end


function prints(str,x,y,c1,c2)
 print(str,x,y+1,c2)
 print(str,x,y,c1)
end

function printo(str,x,y,c1,c2)
-- for i=-1,1 do
--  for j=-1,1 do
   print(str,x+1,y,c2)
   print(str,x,y+1,c2)
   print(str,x-1,y,c2)
   print(str,x,y-1,c2)
--  end
-- end
 print(str,x,y,c1)
end
-->8
--------------------------------
-- entities 
--------------------------------

-- create and add entity
function make_entity(x,y,t)
 local e={
  name="unknown",
  x = x,
  y = y,
  dx=0,
  dy=0,-- delta movement
  ix=0,
  iy=1, -- inertia
  spr = 0 ,
  dir = 1,
  life = 0,
  col=true,
  lastty=-1,
  jumpable=true,
  hits_from_above=false,
  flip_on_hit=true,
  knock_down=false ,
  collides_with_player=true,

  health=1,
  damage=1,
  cooldown=0,

  bleed_timer=0,
  faint_timer=0 ,

  draw = draw_entity,
  update = update_entity,

  t = 0,
  w=8,
  h=8,
  g=0,
  t=0,
  tw=1,
  th = 1,
  frame=0,
  frames = 0,
  fs = 4,
  tbl=t

 }
 

 add(e.tbl,e)

 return e
end

function update_entity_x(e)
 e.x += e.dx
 e.dx *= e.ix
end

function update_entity_y(e)
 if (e.inair or not e.col) then
  e.y += e.dy
  e.dy = min(e.dy+e.g,13)
  e.dy *= e.iy
 end
end

function update_entity(e)
 if (e.cooldown>0) e.cooldown-=1

 update_entity_x(e)
 if (e.col) then
  d=collide_side(e)
  if (d!=nil) then
   -- stick to ledge?
   if (e.grab and e.mode==0 and e.inair and e.dy>0 and pl.grab_cooldown==0) then
    local f=fget(mget(d.tx,d.ty-1))    
    local dist=abs(e.y-d.ty*8)
    if ((band(f,1) or band(f,3)) and dist<2) then
     e.y, e.dy, e.mode = d.ty*8, 0, 2
    
    end
   end
   
   -- callback
   if (e.on_sidecol!=nil) e.on_sidecol(e)
  end
 end
 
 -- store last tile y
 e.lastty=flr((e.y+(e.h/2)-0.01)/8)
 update_entity_y(e)
 
 newty=flr((e.y+(e.h/2))/8)
 
 if (e.col) then
  local ody=e.dy
  if (collide_floor(e)) then
   if (e.inair==true and e.on_landed != nil) then
    e.ody=ody
    e.on_landed(e)
   end
   e.inair=false
  else
   local toair=false
   if (e.inair==false and e.dy==0) then
    if (should_fall(e)) then
     if (e.inair==false and e.on_air!=nil) e.on_air(e)
     e.inair=true
    end
   else
    if (e.inair==false and e.on_air!=nil) e.on_air(e)
    e.inair=true
   end
  end

  if (collide_roof(e)) then
   if (e.on_roofhit) e.on_roofhit(e)
  end
 end
 
 update_entity_a(e)

 if (e.bleed_timer>0) then
  e.bleed_timer-=1
  if (chance(0.5)) bleed(e.x,e.y+4)
  if (e.bleed_timer<=0 and e.health<=0) then
   del(e.tbl,e)
  end
 end

end

function update_entity_a(e)
 e.t+=1

 if (e.frames>0) then
  if (e.t % e.fs == 0) e.frame += 1
  if (e.frame==e.frames) e.frame=0
 end 

 if (e.life>0 and e.t>e.life) then
  del(e.tbl,e)
 end
end

function draw_entity(e)
 spr(e.spr+e.frame*e.tw,
  e.x-e.w/2, e.y-e.h/2, 
  e.tw, e.th,
  e.dir==-1)
  -- print(e.cooldown.."  "..e.life,e.x-3,e.y-5,7)
end

-->8
-- map generation
 -- make map
function make_map()
 
 local rx,ry = 1+flr(rnd(4)), 1
 local srx,sry = rx,ry
 local m={{0,0,0,0},
          {0,0,0,0},
          {0,0,0,0},
          {0,0,0,0},srx,sry}

 local done=false
 
 -- start room
 m[rx][ry]=1
  
 while(not done) do
  local lrx=rx
  local lry=ry
  local down=false

  -- move to free spot
  local tryagain=true
  while(tryagain) do
   tryagain=false
   local r=flr(rnd(5))
   
   if (r<2) rx-=1 -- 0&1
   if (r>2) rx+=1 -- 3&4
   if (r==2) then
    ry+=1
    down=true
   end
     
   if (rx<1) then 
    rx=1 ry+=1
    down=true
   end
   if (rx>4) then
    rx=4 ry+=1
    down=true
   end
  
   if (m[rx][ry]!=0 and ry<5) then
    rx,ry = lrx,lry
    tryagain=true
   end 
  end
  
  if (down) then
   if (m[lrx][lry-1]==2 or m[lrx][lry-1]==5) then
    if (ry<5) m[lrx][lry]=5
   else
    m[lrx][lry]=2
   end
   m[rx][ry]=3
  else
   m[rx][ry]=1
  end

  if (ry>4) done=true

 end

 m[rx][4]=6

 return m
end

