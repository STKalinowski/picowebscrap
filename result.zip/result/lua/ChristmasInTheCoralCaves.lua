-- christmas in the coral caves
-- by kittenm4ster for advent 2019
-- intro art by aubrianne
-- px9 gfx compression by zep

actor = {}
actor.__index = actor

function new_actor(w, h, flipoffset, anims)
	return setmetatable({
		x = 28,
		y = 0,
		vx = 0,
		vy = 0,
		w = w,
		h = h,
		dirx = 1,
		diry = -1,
		friction = .98,
		elasticity = .25,
		maxvx = 1,
		maxvy = 1,
		flipoffset = flipoffset,
		anims = anims,
		anim = anims.default,
		old = {},
		inventory = {}
  }, actor)
end

function actor:choose_anim()
	if self.isturning then
		return 'turn'
	end

	if self.movingy and not self.movingx then
		if self.diry == -1 then
			return 'up'
		else
			return 'down'
		end
	end

	if self.movingx and state == state_game then
		if self.anim ~= self.anims.swim then
			self.swimframe = 0
		end
		return 'swim'
	end
	if self.anim == self.anims.swim and (self.swimframe < 2 or
		 self.anim:get_index() ~= 5) then
		return 'swim'
	end

	return 'default'
end

function get_hitbox(self)
	return {
		x1 = self.x,
		y1 = self.y,
		x2 = self.x + self.w - 1,
		y2 = self.y + self.h - 1,
	}
end

function overlap(a, b)
	return flr(a.x2) >= flr(b.x1) and
				 flr(a.x1) <= flr(b.x2) and
				 flr(a.y2) >= flr(b.y1) and
				 flr(a.y1) <= flr(b.y2)
end

function fmget1(x, y)
	return fget(mget(x, y), 1)
end

function actor:collide(x, y)
	local x1 = x / 8
	local x2 = (x + self.w - 1) / 8
	local y1 = y / 8
	local y2 = (y + self.h - 1) / 8
	local xmid = (x + (self.w / 2)) / 8
	local ymid = (y + (self.h / 2)) / 8

	local nw = fmget1(x1, y1)
	local ne = fmget1(x2, y1)
	local se = fmget1(x2, y2)
	local sw = fmget1(x1, y2)
	local n = fmget1(xmid, y1)
	local e = fmget1(x2, ymid)
	local s = fmget1(xmid, y2)
	local w = fmget1(x1, ymid)

	local solid = nw or ne or se or sw or n or e or s or w
	if not solid then
		return false
	end

	local slidex
	if self.diry == -1 then
		if ne and not nw then
			slidex = -1
		elseif nw and not ne then
			slidex = 1
		end
	elseif self.diry == 1 then
		if se and not sw then
			slidex = -1
		elseif sw and not se then
			slidex = 1
		end
	end

	local slidey
	if self.dirx == -1 then
		if sw and not nw then
			slidey = -1
		elseif nw and not sw then
			slidey = 1
		end
	elseif self.dirx == 1 then
		if se and not ne then
			slidey = -1
		elseif ne and not se then
			slidey = 1
		end
	end

	return true, slidex, slidey
end

function actor:apply_physics()
	if not self.movingx then
		self.vx *= self.friction
		if abs(self.vx) < 0.09 then
			self.vx = 0
		end
	end
	if not self.movingy then
		self.vy *= self.friction
		if abs(self.vy) < 0.09 then
			self.vy = 0
		end
	end

	self.vx = mid(-self.maxvx, self.vx, self.maxvx)
	self.vy = mid(-self.maxvy, self.vy, self.maxvy)

	local testx = self.x + self.vx
	local testy = self.y + self.vy

	local hit, slidex, slidey = self:collide(testx, self.y)
	if hit then
		self.vx = -self.vx * self.elasticity
		if slidey then
			if sgn(self.vy) ~= sgn(slidey) or abs(self.vy) < 0.2 then
				self.vy += slidey * 0.1
			end
		end
	else
		self.x = testx
	end

	local hit, slidex, slidey = self:collide(self.x, testy)
	if hit then
		self.vy = -self.vy * self.elasticity
		if slidex then
			if sgn(self.vx) ~= sgn(slidex) or abs(self.vx) < 0.2 then
				self.vx += slidex * 0.1
			end
		end
	else
		self.y = testy
	end

	if self.y < 0 then
		self.y = 0
		self.vy = 0
	end
end

function actor:pick_up_items()
	local hitbox = get_hitbox(self)
	for _, item in pairs(items) do
		if overlap(hitbox, get_hitbox(item)) then
			pick_up_item(item, self)
		end
	end
end

function actor:update()
	if state == state_game then
		self:apply_physics()
	end

	if self.anim == self.anims.turn and self.anim:is_done() then
		self.isturning = false
	end

	local a = self:choose_anim()
	self.anim = self.anims[a]

	if self.anim ~= self.old.anim then
		self.anim:reset()
	end

	if self.anim == self.anims.swim then
		local oldframe = self.swimframe
		local d = max(.17, abs(self.vx) * .11)

		self.swimframe += d
		if flr(self.swimframe) > flr(oldframe) then
			self.anim:update(true)
		end
	end

	self.anim:update()

	if self == player then
		self:pick_up_items()
		update_hat()
	end
end

function draw_actor(a)
	local anim = a.anim
	local props = anim:get_frame_props()
	local x, y = add_coords(a, a.offset, props.offset)
	local flipx = (a.dirx == 1) or props.flipx
	if flipx and a.flipoffset then
		x += a.flipoffset
	end

	if a.palette then
		apply_palette(a.palette)
	end

	if props.palette then
		apply_palette(props.palette)
	end

	local f = props.sprf or a.sprf or spr2
	f(anim:get_index(), x, y, anim.w, anim.h, flipx, props.flipy, a.scale)

	pal()
end

function actor:draw()
	if self == player then
		if self.diry == -1 then
			pal(5, 0)
			pal(6, 7)
		elseif self.diry == 1 then
			pal(5, 7)
			pal(6, 0)
		end
	end

	draw_actor(self)

	for n in all(hatnodes) do
		pset(n.x, n.y, n.c)
	end
end

function get_speech_pos(npc)
	local pos = {
		x = npc.x + flr(npc.w / 2) - 1,
		y = npc.y - 2
	}
	return add_coords(pos, npc.speechoffset)
end

function can_give_gift_to(npc)
	local entry = inv_entries[npc.gift]
	return entry and entry.held and
				 (not npc.giftcount or entry.count == npc.giftcount)
end

function new_action_func(x, y, npc)
	return function()
		cam.target2 = npc
		local oldinvdir = invdir
		invdir = -1
		sfx(63)

		player.diry = sgn(y - player.y)
		local dirx = sgn(x - player.x)
		if dirx ~= player.dirx then
			player.dirx = dirx
			player.isturning = true
			player.anims.turn:reset()
		end

		if can_give_gift_to(npc) then
			state = state_gift
			npc:giftfunc()
			npc.hasgift = true
			inv_entries[npc.gift].held = false
			invcount -= 1
			deliverycount += 1
			wait(15)
		end

		say_npc_lines(npc)

		invdir = oldinvdir
		cam.target2 = nil

		if npc.post_action then
			npc.post_action()
		end
	end
end

function say_npc_lines(npc)
	local x, y = get_speech_pos(npc)
	local lines = npc.hasgift and npc.lines2 or npc.lines1

	state = state_speech
	cam.target2 = npc

	say_lines(x, y, lines)

	cam.target2 = nil
	postspeechtimer = new_timer(15)
end

function say_lines(x, y, lines)
	speechw = 0

	for txt in all(lines) do
		speech = {
			txt = txt,
			x = x,
			y = y,
			timer = new_timer(2),
			donetimer = new_timer(120),
			i = 0
		}
		repeat
			yield()
			if btnp(4) and not speech.isdone then
				speech.i = #speech.txt
			end
		until btnp(4) and speech.isdone
	end

	speech = nil
end

function update_speech(s)
	if not s.isdone and s.i == #s.txt then
		s.isdone = true
		s.donetimer:reset()
	end

	local w = txtw(s.txt)
	if s.isdone then
		speechw = w
		s.donetimer:update()
	end
	speechw = approach(w, speechw, .4)
	if speechw ~= w then
		return
	end

	if s.timer:update() and s.i < #s.txt then
		s.timer:reset()
		s.i += 1
	end
end

function draw_speech(s, c, showprompt)
	local w = speechw
	local x1 = s.x - flr(w / 2) - 2
	local y1, y2 = s.y - 10, s.y - 2

	x1 = mid(cam.x - 0, x1, cam.x + 127 - w - 3)

	local x2 = x1 + w + 3

	rectfill(x1, y1 + 1, x2, y2 - 1, c)
	rectfill(x1 + 1, y1, x2 - 1, y2, c)

	pal(1, c)
	spr(71, s.x - 1, s.y - 1)
	palt()

	print(sub(s.txt, 1, s.i), x1 + 2, y1 + 2, 7)

	if showprompt and s.isdone and s.donetimer:is_done() then
		local offset = t() * 2 % 2
		print('🅾️', x2 - 1, y2 - 1 + offset, 7)
	end
end

anim = {}
anim.__index = anim

function new_anim(w, h, indexes, delay, loop, frameprops)
	return setmetatable({
		w = w,
		h = h,
    indexes = indexes,
    i = 1,
    timer = new_timer(delay),
    loop = loop or false,
		frameprops = frameprops or {},
  }, anim)
end

function anim:update(force)
  if self.timer:update() or force then
    self.timer:reset()

    if self.i < #self.indexes then
      self.i += 1
			return true
    elseif self.loop then
      self:reset()
			return true
    end
  end
end

function anim:get_index()
  return self.indexes[self.i]
end

function anim:get_frame_props()
	return self.frameprops[self.i] or {}
end

function anim:reset()
  self.i = 1
  self.timer:reset()
end

function anim:sync_with(other)
	self.i = other.i
	self.timer.v = other.timer.v
end

function anim:is_done()
  return self.i == #self.indexes and self.timer:is_done()
end

hatnodes = {}
for i = 1, 4 do
	hatnodes[i] = {x = 0, y = 0, c = i == 4 and 7 or 8}
end

function update_hat()
	local anchorx = player.x + 6
	if player.dirx == 1 then
		anchorx -= 5
	end

	local xo = player.anim.hatxoffset
	if xo then
		anchorx += (xo[player.anim.i] * player.dirx)
	end

	hatnodes[1].x = flr(anchorx)
	hatnodes[1].y = flr(mid(player.y - 3, hatnodes[1].y, player.y - 2))

	for i = 1, #hatnodes - 1 do
		drag(hatnodes[i], hatnodes[i + 1])
	end
end

function drag(a, b)
  local dx, dy = a.x - b.x, a.y - b.y
  local angle = atan2(dx, dy)
  b.x = a.x - cos(angle)
  b.y = a.y - sin(angle)
end

function update_inventory()
	if invcount == 0 then
		invdir = -1
	end

	local dest = (invdir == 1 and invy_max or invy_min)

	invy = approach(dest, invy, .3)
	invy = mid(invy_min, invy, invy_max)

	local w = get_inv_width()
	invw = approach(w, invw, .2)
end

function draw_inventory()
	local x1 = 64 - (invw / 2)
	local x2 = x1 + invw - 1

	camera(0, -invy)

	pal(1, 0)
	spr2(78, x1, 0, 1, 2)
	rectfill(x1 + 8, 0, x1 + invw - 6, 7, 0)
	rectfill(x1 + 2, 8, x2 - 3, 8, 7)
	spr2(79, x2 - 7, 0, 1, 2)
	pal()

	local x = x1 + 3
	for entry in all(player.inventory) do
		local actor = entry.actor
		local entryw = actor.w + (entry.count and 8 or 0)

		if entry.held and x + entryw < x1 + invw - 2 then
			actor.x = x
			actor.y = 7 - actor.h
			draw_actor(actor)
			x += actor.w

			if entry.count then
				x += 1
				spr2(45, x, 4)
				x += 4
				print(entry.count, x, 2, 7)
				x += 3
			end

			x += 3
		end
	end
end

function get_inv_width()
	local w, i = 6, 0

	for _, entry in pairs(player.inventory) do
		i += 1
		if entry.held then
			w += entry.actor.w
			if entry.count then
				w += 8
			end
			if i > 1 then
				w += 3
			end
		end
	end

	return max(10, w)
end

function make_item_bubbles(item)
	for y = item.y - 1, item.y + item.h, 2 do
		for x = item.x - 1, item.x + item.w, 2 do
			add_tmpbubble(x, y)
		end
	end
end

function pick_up_item(item, actor)
	item:on_get(actor)
	del(items, item)

	item.scale = 1
	add(shrinks, item)

	make_item_bubbles(item)

	local y = item.y - 8
	add(itemtexts, {
		x = item.x,
		y = y,
		origy = y,
		dsty = y - 10,
		txt = '+ ' .. item.name,
		c = 7
	})

	sfx(62, 0)
end

function add_inventory(k)
	local entry = inv_entries[k]

	if not entry.held then
		entry.held = true
		add(player.inventory, entry)
		invcount += 1
	end

	if entry.count then
		entry.count += 1
	end

	if invcount == 1 then
		invdir = 1
	end
end

function new_coin(pos)
	local props = {flipx = true, offset = {x = -1, y = 0}}
	return {
		name = 'coin',
		x = pos.x,
		y = pos.y,
		offset = {x = -1, y = -1},
		w = 5,
		h = 5,
		anim = new_anim(1, 1, {121, 89, 121, 89}, 30, true, 
			{[3] = props, [4] = props}
		),
		on_get = function (self, actor)
			del(coins, self)
			add_sparkle(self.x, self.y)
			add_inventory('coin')
		end
	}
end

function new_mitten(pos)
	return {
		name = 'mitten',
		x = pos.x,
		y = pos.y,
		offset = {x = -2, y = -2},
		w = 4,
		h = 4,
		anim = new_anim(1, 1, {13}, 0),
		on_get = function (self, actor)
			del(mittens, self)
			add_inventory('mitten')
		end
	}
end

function new_pb(pos)
	local props = {flipx = true}
	local pbanim = new_anim(
		1,
		1,
		{0, 16, 32, 48, 48, 32, 16, 0, 0, 0, 0, 0, 0, 0},
		10,
		true,
		{[5] = props, [6] = props, [7] = props}
	)
	return {
		name = 'peanut butter',
		x = pos.x,
		y = pos.y,
		offset = {x = -2, y = -2},
		w = 4,
		h = 6,
		anim = pbanim,
		on_get = function (self, actor)
			add_inventory('pb')
		end,
	}
end

function new_glove(pos)
	return {
		name = 'rubber glove',
		x = pos.x,
		y = pos.y,
		w = 10,
		h = 6,
		anim = new_anim(2, 1, {46}, 0),
		on_get = function (self, actor)
			add_inventory('glove')
		end,
	}
end

function new_hat(pos)
	return {
		name = 'hat',
		x = pos.x,
		y = pos.y,
		w = 8,
		h = 5,
		anim = new_anim(1, 1, {29}, 0),
		on_get = function (self, actor)
			add_inventory('hat')
		end,
	}
end

function new_sunglasses(pos)
	return {
		name = 'sunglasses',
		x = pos.x,
		y = pos.y,
		w = 16,
		h = 4,
		anim = new_anim(2, 1, {62}, 0),
		palette = {[1] = 0},
		on_get = function (self, actor)
			add_inventory('sunglasses')
		end,
	}
end

function new_diamond(pos)
	local fo = {x = -1, y = 1}
	return {
		name = 'diamond',
		x = pos.x,
		y = pos.y,
		offset = {x = -1, y = -1},
		w = 5,
		h = 7,
		palette = {[7] = 8, [14] = 8},
		anim = new_anim(1, 1, {61, 61, 61, 61, 61, 61, 61, 61, 61}, 8, true, 
			{
				[6] = {palette = {[7] = 7}},
				[7] = {palette = {[14] = 7}},
				[8] = {palette = {[14] = 7}, flipx = true, flipy = true, offset = fo},
				[9] = {palette = {[7] = 7}, flipx = true, flipy = true, offset = fo},
			}
		),
		on_get = function (self, actor)
			del(diamonds, self)
			add_sparkle(self.x + 3, self.y + 3)
			add_inventory('diamond')
		end
	}
end

light_palette = {9, 10, 11, 12, 14}
itemtext_fadepal = {7, 7, 7, 7, 6, 6, 6, 13, 13, 5}
invy_min = -10
invy_max = 0
state_intro = 0
state_game = 1
state_speech = 2
state_gift = 3
state_outro = 4

function _init()
	pal(5, 131, 1)
	init_gfx()
	actors = {}
	coroutines = {}

	fish = new_actor(8, 7, -6, {
		default = new_anim(2, 2, {43, 1, 43, 43}, 60, true),
		swim = new_anim(2, 2, {3, 5, 7, 5}, 99, true),
		turn = new_anim(2, 2, {33, 35, 37}, 6),
		down = new_anim(2, 2, {39, 41}, 10, true),
		up = new_anim(2, 2, {9, 11}, 10, true),
	})
	fish.anims.turn.hatxoffset = {
		[1] = 4,
		[2] = 4,
		[3] = 1
	}
	fish.vy = .3
	fish.offset = {x = -1, y = -3}
	player = fish

	inv_entries = {
		coin = {actor = new_coin({}), count = 0},
		diamond = {actor = new_diamond({}), count = 0},
		mitten = {actor = new_mitten({}), count = 0},
		pb = {actor = new_pb({})},
		glove = {actor = new_glove({})},
		hat = {actor = new_hat({})},
		sunglasses = {actor = new_sunglasses({})},
	}
	inv_entries.pb.actor.anim.i = 4
	inv_entries.diamond.actor.anim.i = 6

	invdir = -1
	invy = -10
	invw = 0
	invcount = 0
	deliverycount = 0

	add(actors, fish)

	cam = {
		x = 0,
		y = 0,
		xmargin = 48,
		ymargin = 32,
		minx = 0,
		maxx = (mapw * 8) - 128,
		miny = 0,
		maxy = (maph * 8) - 128,
	}

	items = {}
	shrinks = {}

	kelptimer = new_timer(60)
	kelpanims = {}
	mapanims = {}
	spriteanims = {}
	coins = {}
	mittens = {}
	diamonds = {}
	sparkles = {}
	tmpbubbles = {}
	itemtexts = {}

	lightgroups = {}
	lighttimer = new_timer(40)

	init_npcs()
	init_map()

	bubbles = {}
	for i = 1, 150 do
		local b = {}
		reset_bubble(b)
		b.y = rnd(maph * 8)
		add(bubbles, b)
	end

	shadowtimer = new_timer(60)
	shadowx = 2

	postspeechtimer = new_timer(1)

	cr(function()
		while true do
			set_arp(11, 0x0020)
			repeat yield() until (stat(24) == 9 and stat(23) >= 13) or stat(24) >= 10
			set_arp(22, 0x0060)
			repeat yield() until (stat(24) == 17 and stat(23) >= 27) or stat(24) < 10
		end
	end)

	state = state_intro
	init_intro()
end

function _update60()
	process_input()

  for cr in all(coroutines) do
    if costatus(cr) ~= 'dead' then
      assert(coresume(cr))
    else
      del(coroutines, cr)
    end
  end

	if state == state_game then
		prompt = get_active_prompt()
	end

	if state ~= state_intro and state ~= state_outro then
		for _, a in pairs(actors) do
			a.old.anim = a.anim
			a:update()
		end

		update_map()
		if state ~= state_cutscene then
			update_camera()
		end
		update_inventory()
		foreach(items, update_item)
		foreach(shrinks, update_shrink)
		foreach(bubbles, update_bubble)
		foreach(sparkles, update_sparkle)
		foreach(tmpbubbles, update_tmpbubble)
		foreach(itemtexts, update_itemtext)
		update_lights()
		update_shadows()
	elseif state == state_outro then
		update_outro()
	end

	if speech then
		update_speech(speech)
	end
end

function _draw()
	if state == state_intro then
		draw_intro()
	elseif state == state_outro then
		draw_outro()
	else
		draw_game()
	end

	if screenfadev then
		fade(screenfadev)
	end
end

function draw_game()
	cls(1)

	camera(cam.x, cam.y)
	draw_shadows()
	camera()
	distort_bg()

	camera(cam.x, cam.y)
	spr2(14, t() * 6, 313, 2, 1)

	for c in all(bubbles) do
		circ(c.x, c.y, c.r, 3)
	end
	foreach(tmpbubbles, draw_tmpbubble)

	map(0, 0, 0, 0, mapw, maph, 0x1)
	for a in all(spriteanims) do
		draw_actor(a)
	end

	player:draw()

 	local floaty = flr(t()) % 2
	camera(cam.x, cam.y - floaty)
	foreach(items, draw_actor)
	foreach(shrinks, draw_actor)
	camera(cam.x, cam.y)

	map(0, 0, 0, 0, mapw, maph, 0x4)
	foreach(sparkles, draw_actor)
	draw_lights()
	foreach(itemtexts, draw_itemtext)

	camera()
	if state ~= state_cutscene then
		draw_inventory()
	end

	camera(cam.x, cam.y)
	if speech then
		draw_speech(speech, 0)
	end
	if state ~= state_cutscene and prompt then
		draw_prompt(prompt)
	end

	pal(5, 131, 1)
end

function cr(func)
	add(coroutines, cocreate(func))
end

function update_shadows()
	if shadowtimer:update() then
		shadowtimer:reset()
		shadowx = rnd_choice({-2, 2})
	end
end

function process_input()
	if state == state_game then
		if btnp(5) then
			invdir = -invdir
		end

		control_player()
	end
end

function get_active_prompt()
	if not postspeechtimer:update() then
		return
	end

	if deliverycount == 6 and not npcs.note then
		cr(play_note_cutscene)
	end

	local playerbox = get_hitbox(player)

	for _, npc in pairs(npcs) do
		local box = npc.actionbox
		if box and overlap(playerbox, box) then
			local x, y = get_speech_pos(npc)
			local txt = '🅾️ ' .. (npc.verb or 'talk')
			if can_give_gift_to(npc) then
				txt = '🅾️ give ' .. npc.gift .. (npc.giftcount and 's' or '')
			end

			return {
				x = x,
				y = y - 8,
				txt = txt,
				func = new_action_func(x, y, npc)
			}
		end
	end
end

function control_player()
	local d = .07

	player.movingx = false
	player.movingy = false

	if btn(0) then
		if player.dirx ~= -1 then
			player.isturning = true
			player.anims.turn:reset()
		end
		if (player.vx > 0) d *= 3
		player.vx -= d
		player.dirx = -1
		player.movingx = true
	elseif btn(1) then
		if player.dirx ~= 1 then
			player.isturning = true
			player.anims.turn:reset()
		end
		if (player.vx < 0) d *= 3
		player.vx += d
		player.dirx = 1
		player.movingx = true
	end

	d = .07
	if btn(2) then
		player.movingy = -1
		if player.diry ~= -1 then
			player.diry = -1
		end
		if (player.vy > 0) d *= 3
		player.vy -= d
	elseif btn(3) then
		player.movingy = 1
		if player.diry ~= 1 then
			player.diry = 1
		end
		if (player.vy < 0) d *= 3
		player.vy += d
	end

	if state == state_game and prompt and btnp(4) then
		cr(function()
			local f = prompt.func
			prompt = nil
			f()
			if state ~= state_outro then
				state = state_game
			end
		end)
	end
end

function cam_follow(actor)
	local dest = {x = cam.x, y = cam.y}

	local x1 = cam.x + cam.xmargin
	local x2 = cam.x + 127 - cam.xmargin
	if actor.x < x1 then
		dest.x = actor.x - cam.xmargin
	end
	if actor.x + actor.w > x2 then
		dest.x = actor.x + actor.w + cam.xmargin - 127
	end

	local y1 = cam.y + cam.ymargin
	local y2 = cam.y + 127 - cam.ymargin
	if actor.y < y1 then
		dest.y = actor.y - cam.ymargin
	end
	if actor.y + actor.h > y2 then
		dest.y = actor.y + actor.h + cam.ymargin - 127
	end

	return dest
end

function avg_pos(a, b)
	return {
		x = (a.x + b.x) / 2,
		y = (a.y + b.y) / 2
	}
end

function update_camera()
	local dest = cam_follow(player)

	cam.x = dest.x
	cam.y = dest.y

	if cam.target2 then
 		local dest2 = cam_follow(cam.target2)
 		dest = avg_pos(dest, dest2)

		dest.x = mid(cam.minx, dest.x, cam.maxx)
		dest.y = mid(cam.miny, dest.y, cam.maxy)

		cam.x = approach(dest.x, cam.x, .085)
		cam.y = approach(dest.y, cam.y, .085)
	end

	cam.x = mid(cam.minx, cam.x, cam.maxx)
	cam.y = mid(cam.miny, cam.y, cam.maxy)
end

function update_map()
	if kelptimer:update() then
		kelptimer:reset()

		for _, k in pairs(kelpanims) do
			k.i += 1
			k.i %= #k.frames
			local s = k.frames[k.i + 1]
			mset(k.mx, k.my, s)
		end
	end

	for _, a in pairs(mapanims) do
		if a.anim:update() then
			apply_mapanim(a)
		end
	end

	for _, a in pairs(spriteanims) do
		a.anim:update()
	end
end

function apply_mapanim(a)
	mset_block(a.anim:get_index(), a.anim.w, a.anim.h, a.mx, a.my)
end

function update_bubble(b)
	b.vx += rnd_int(-2, 2) * .005
	b.x += b.vx
	b.y += b.vy

	if b.y < 0 then
		reset_bubble(b)
	end
end

function reset_bubble(b)
	b.r = rnd_choice({0, 0, 1})
	b.x = rnd(mapw * 8)
	b.y = maph * 8
	b.vx = 0
	b.vy = (b.r == 1 and -0.8 or -0.7)
end

function add_sparkle(x, y)
	add(sparkles, {
		x = x,
		y = y,
		offset = {x = -1, y = -1},
		anim = new_anim(1, 1, {30, 31}, 5)
	})
end

function update_sparkle(s)
	s.anim:update()
	if s.anim:is_done() then
		del(sparkles, s)
	end
end

function draw_shadows()
	for c = 0, 15 do
		pal(c, 5)
	end

	map(0, 0, 0, 2, mapw, maph, 0x1)
	map(0, 0, shadowx, 0, mapw, maph, 0x1)

	pal()
end

function distort_bg()
	local offset = (shadowtimer.v < 30) and 1 or 0

	for x = 0 + (cam.x % 2), 127, 2 do
		local x2 = x + offset
		rectfill(x2, 0, x2, 127, 1)
	end

	for y = 0 + (cam.y % 2), 127, 2 do
		local y2 = y + offset
		rectfill(0, y2, 127, y2, 1)
	end
end

function update_item(item)
	item.anim:update()
end

function update_shrink(item)
	if item.scale > 0 then
		if not item.ox then
			item.ox = item.x
			item.oy = item.y
		end

		item.scale -= .1

		local w = item.anim.w * 8
		local h = item.anim.h * 8
		local scaledw = w * item.scale
		local scaledh = h * item.scale
		item.x = item.ox + ((w - scaledw) / 2)
		item.y = item.oy + ((h - scaledh) / 2)
	else
		del(shrinks, item)
	end
end

function update_lights()
	if lighttimer:update() then
		lighttimer:reset()

		for _, lights in pairs(lightgroups) do
			for i = 1, #lights - 1 do
				lights[i].c = lights[i + 1].c
			end
			lights[#lights].c = rnd_choice(light_palette)
		end
	end
end

function draw_lights()
	for lights in all(lightgroups) do
		for i = 1, #lights do
			local l = lights[i]

			if i < #lights then
				local l2 = lights[i + 1]
				line(l.x, l.y, l2.x, l2.y, 3)
			end
			circfill(l.x, l.y + 2, 1, l.flash and 7 or l.c)
		end
	end
end

function update_itemtext(t)
	t.y = approach(t.dsty, t.y, .024)
	t.c = itemtext_fadepal[flr(t.origy - t.y) + 1]
	if t.y == t.dsty then
		del(itemtexts, t)
	end
end

function draw_itemtext(t)
	cprint(t.txt, t.x, t.y, t.c, 1)
end

function draw_prompt(p)
	local offset = t() * 2 % 2
	cprint(p.txt, p.x, p.y + offset, 7, 1, true)
end

function get_fade_col(c, fadev)
	return sget(32 + c, 31 - flr(7 * fadev))
end

function fade(v)
	for c = 1, 15 do
		pal(c, get_fade_col(c, v), 1)
	end
end

function fade_out(delay)
	for i = 10, 0, -1 do
		screenfadev = i / 10
		wait(delay or 3)
	end
end

function fade_in(delay)
	for i = 0, 10 do
		screenfadev = i / 10
		wait(delay or 3)
	end
	screenfadev = nil
end

function apply_palette(p)
	for k, v in pairs(p) do pal(k, v) end
end

function approach(dest, v, speed)
	if abs(dest - v) < 1 then
		return dest
	end
	return v + ((dest - v) * speed)
end

function cprint(s, x, y, c, bg, clamp)
	local halfw = flr(txtw(s) / 2)
	local x = x - halfw
	if clamp then
		x = mid(cam.x, x, cam.x + 127 - (halfw * 2))
	end

	if bg then
		for yo = -1, 1 do
			for xo = -1, 1 do
				if yo ~= 0 or xo ~= 0 then
					print(s, x + xo, y + yo, bg)
				end
			end
		end
	end

	print(s, x, y, c)
end

function rnd_choice(t)
	return t[rnd_int(1, #t)]
end

function del_rnd_choice(t)
	return del(t, rnd_choice(t))
end

function rnd_int(a, b)
	return flr(rnd((b + 1) - a)) + a
end

function txtw(txt)
	local txt, w = tostr(txt), 0
	for i = 1, #txt do
		local c = sub(txt, i, i)
		w += ((c == '🅾️' or c == '★' or c == '♥') and 8 or 4)
	end
	return max(0, w - 1)
end

function add_coords(...)
	local x, y = 0, 0

	for _, a in pairs({...}) do
		if a then
			x += a.x
			y += a.y
		end
	end

	return x, y
end

function spr_xy(s)
  return (s % 16) * 8, flr(s / 16) * 8
end

function wait(n)
	for i = 1, n do yield() end
end

function init_map()
	local spots, keyspots = {}, {}
	for my = 1, maph - 2 do
		for mx = 1, mapw - 2 do
			local s = mget(mx, my)
			local pos = {x = mx * 8, y = my * 8}
			if s == 36 then
				add(spots, pos)
			elseif s == 120 then
				add(keyspots, {x = pos.x + 4, y = pos.y + 4})
			end
		end
	end

	for i = 1, 9 do
		local c = new_coin(del_rnd_choice(spots))
		add(coins, c)
		add(items, c)
	end

	for i = 1, 5 do
		local m = new_mitten(del_rnd_choice(spots))
		add(mittens, m)
		add(items, m)
	end

	for i = 1, 7 do
		local d = new_diamond(del_rnd_choice(spots))
		add(diamonds, d)
		add(items, d)
	end

	add(items, new_pb(del_rnd_choice(keyspots)))
	add(items, new_glove(del_rnd_choice(keyspots)))
	add(items, new_hat(del_rnd_choice(keyspots)))
	add(items, new_sunglasses(del_rnd_choice(keyspots)))

	add_lights(20, 17, '11112125562333322215')
	add_lights(26, 3, '1522222222343')
	add_lights(106, 54, '1122222622522233')
	add_lights(57, 58, '256222262333')
	add_lights(114, 1, '22226222122332322')
	add_lights(68, 19, '2122322322323337774488414')

	for my = 0, maph - 1 do
		for mx = 0, mapw - 1 do
			local s = mget(mx, my)
			if s == 11 or s == 12 then
				add_kelpanim(mx, my, {11, 12}, s)
			elseif s == 41 or s == 43 then
				add_kelpanim(mx, my, {41, 43}, s)
				add_kelpanim(mx, my + 1, {57, 59}, s)
				add_kelpanim(mx + 1, my + 1, {58, 60}, s)
			elseif s == 124 or s == 27 then
				add_kelpanim(mx, my, {124, 27}, s)
				add_kelpanim(mx + 1, my, {125, 28}, s)
			end
		end
	end
end

function add_kelpanim(mx, my, frames, i)
	add(kelpanims, {mx = mx, my = my, frames = frames, i = i})
end

function add_lights(mx, my, dirs)
	local path = {{mx = mx, my = my}}
	for i = 1, #dirs do
		local d = tonum(sub(dirs, i, i))
		mx, my = add_dir(mx, my, d)
		add(path, {mx = mx, my = my})
	end

	local group = {}
	for p in all(path) do
		local mx, my = p.mx, p.my

		local n, nc = get_neighbors(mx, my, 0x1, 8)
		if nc == 3 and my == 0 then
			nc = 4
			n[1] = true
		end

		local x, y = mx * 8, my * 8
		if block_is_empty(mx, my, 1, 1) then
			if n[1] then
				y -= 2
			elseif n[8] or n[5] then
				y -= 3
			end
		end

		add(group, {x = x, y = y, c = rnd_choice(light_palette)})
	end
	add(lightgroups, group)
end

mapw = 128
maph = 32 * 2

dir_map = {
	{x = 0, y = -1},
	{x = 1, y = 0},
	{x = 0, y = 1},
	{x = -1, y = 0},
	{x = 1, y = -1},
	{x = 1, y = 1},
	{x = -1, y = 1},
	{x = -1, y = -1},
}

function add_dir(x, y, d)
	local o = dir_map[d]
	return x + o.x, y + o.y
end

function block_is_empty(mx, my, mw, mh)
	for y = my, my + (mh or 1) - 1 do
		for x = mx, mx + (mw or 1) - 1 do
			if mget(x, y) ~= 0 then
				return false
			end
		end
	end

	return true
end

function get_neighbors(x, y, flags, dircount)
  local neighbors = {}
	local count = 0

	for i = 1, dircount or 4 do
		local offset = dir_map[i]
		local v = false
		local s = mget(x + offset.x, y + offset.y)
		if band(fget(s), flags) > 0 then
			v = true
			count += 1
		end
		neighbors[i] = v
	end

	return neighbors, count
end

function mset_block(s, w, h, mx, my)
	for ty = my, my + h - 1 do
		for tx = mx, mx + w - 1 do
			mset(tx, ty, s)
			s += 1
		end
		s -= w
		s += 16
	end
end

function init_npcs()
	npcs = {}

	npcs.crab = {
		x = 504,
		y = 488,
		w = 16,
		h = 8,
		gift = 'hat',
		mapanim = {mx = 63, my = 61, anim = new_anim(2, 2, {1, 3}, 40, true)},
		actionbox = {x1 = 475, y1 = 468, x2 = 532, y2 = 509},
		speechoffset = {x = 0, y = 6},
		lines1 = {'nice hat.', 'never worn one myself.'},
		lines2 = {'a hat!', "it's...", 'even better than i imagined!'},
		giftfunc = function (self)
			local hatanim = new_anim(1, 1, {29, 29}, 40, true, {
				[2] = {
					offset = {x = 0, y = -1}
				}
			})
			hatanim:sync_with(self.mapanim.anim)
			add(spriteanims, {anim = hatanim, x = 508, y = 492})
			self.speechoffset = {x = 0, y = 1}
		end
	}

	npcs.jellyfish = {
		x = 248,
		y = 24,
		w = 16,
		h = 16,
		gift = 'pb',
		mapanim = {mx = 31, my = 3, anim = new_anim(2, 2, {84, 86}, 40, true)},
		actionbox = {x1 = 213, y1 = 20, x2 = 260, y2 = 50},
		lines1 = {'whaaat are you santa now??', "i'm so jelly"},
		lines2 = {'peanut butter!', 'this is great!', 'wait till i tell breadfish!'},
		giftfunc = function (self)
			local pbhatanim = new_anim(1, 1, {48, 48}, 40, true, {
				[2] = {
					offset = {x = 0, y = 1}
				}
			})
			pbhatanim:sync_with(self.mapanim.anim)
			add(spriteanims, {anim = pbhatanim, x = 252, y = 16})
			self.speechoffset = {x = 0, y = -4}
		end
	}

	npcs.eel = {
		x = 848,
		y = 424,
		w = 16,
		h = 16,
		gift = 'glove',
		mapanim = {mx = 106, my = 53, anim = new_anim(2, 2, {96, 98}, 45, true)},
		actionbox = {x1 = 840, y1 = 412, x2 = 910, y2 = 442},
		giftfunc = function (self)
			add(mapanims, {
				mx = 107, my = 54,
				anim = new_anim(1, 1, {116}, 0, true)
			})
			eeltailanim.anim.indexes = {117, 118}
			apply_mapanim(eeltailanim)
		end,
		speechoffset = {x = 5, y = -1},
		lines1 = {'*zap*', 'jk'},
		lines2 = {'a rubber glove!', 'now i can shake hands...', 'without it being a prank!'}
	}

	npcs.starkid = {
		x = 192,
		y = 152, 
		w = 8,
		h = 8,
		speechoffset = {x = -19, y = -8},
		gift = 'mitten',
		giftcount = 5,
		mapanim = {mx = 24, my = 19, anim = new_anim(1, 1, {68, 69, 68}, 20, true)},
		lines1 = {'is it just me...', 'or does junior look cold?'},
		lines2 = {'atta boy, junior!', "it's important to stay warm."},
		actionbox = {x1 = 183, y1 = 122, x2 = 222, y2 = 150},
		giftfunc = function (self)
			local blinkprops = {palette = {[1] = 9}}
			del(mapanims, self.mapanim)
			mset(24, 19, 16)
			add(spriteanims, {
				x = 189,
				y = 144,
				palette = {[1] = 2},
				anim = new_anim(
					2,
					2,
					{32, 32, 32, 32, 32, 32, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34},
					15,
					true,
					{[14] = blinkprops, [18] = blinkprops}
				),
				sprf = spr
			})
		end
	}

	npcs.ray = {
		x = 960,
		y = 24,
		w = 32,
		h = 32,
		gift = 'sunglasses',
		actionbox = {x1 = 932, y1 = 23, x2 = 978, y2 = 49},
		speechoffset = {x = -1, y = 0},
		lines1 = {"how's it floatin'?", 'sure is sunny today!'},
		lines2 = {'radical!', 'thanks, little fish!'},
		giftfunc = function (self)
			local glassesanim = new_anim(2, 1, {62, 62}, 50, true, {
				[2] = {offset = {x = 0, y = 1}}
			})
			glassesanim:sync_with(rayanim1.anim)
			add(spriteanims, {anim = glassesanim, x = 967, y = 28, palette = {[1] = 0}})
		end
	}

	-- ray anims
	local rayframeprops = {[2] = {offset = {x = 0, y = 1}}} 
	local palette = {[1] = 0}
	rayanim1 = add(spriteanims, {
		x = 968,
		y = 24,
		anim = new_anim(2, 4, {6, 6}, 50, true, rayframeprops),
		palette = palette,
		sprf = spr
	})
	add(spriteanims, {
		x = 960,
		y = 32,
		anim = new_anim(1, 2, {21, 9}, 50, true, rayframeprops),
		palette = palette,
		sprf = spr
	})
	add(spriteanims, {
		x = 984,
		y = 32,
		anim = new_anim(1, 2, {24, 10}, 50, true, rayframeprops),
		palette = palette,
		sprf = spr
	})

	npcs.shark = {
		x = 528,
		y = 168,
		w = 56,
		h = 16,
		gift = 'diamond',
		giftcount = 7,
		actionbox = {x1 = 504, y1 = 164, x2 = 528, y2 = 200},
		speechoffset = {x = -22, y = 1},
		lines1 = {'ahoy!', 'got any sevens?'},
		lines2 = {'wow!', 'seven of diamonds!', 'thanks, santa!',},
		giftfunc = function (self)
			local s = '101010101000101'
			local i = 1
			for y = 0, 4 do
				for x = 0, 2 do
					if sub(s, i, i) == '1' then
						add(items, new_diamond({
							x = self.x + 40 + (x * 5), 
							y = self.y + 1 + (y * 5)
						}))
					end
					i += 1
				end
			end
		end
	}
	local sharkframeprops = {
		[1] = {sprf = spr},
		[2] = {sprf = spr2}
	}
	add(spriteanims, { -- body
		x = 536,
		y = 168,
		anim = new_anim(2, 2, {14, 110}, 40, true, sharkframeprops)
	})
	add(spriteanims, { -- tail
		x = 552,
		y = 168,
		anim = new_anim(2, 2, {46}, 40, true),
		sprf = spr
	})
	add(spriteanims, { -- top of head
		x = 528,
		y = 168,
		anim = new_anim(1, 1, {13, 124}, 40, true, sharkframeprops)
	})
	add(spriteanims, { -- bottom of head
		x = 528,
		y = 176,
		anim = new_anim(1, 1, {29, 125}, 40, true, sharkframeprops)
	})

	for _, npc in pairs(npcs) do
		if npc.mapanim then
			add(mapanims, npc.mapanim)
		end
	end

	-- stardad
	add(mapanims, {mx = 21, my = 18, anim = new_anim(2, 2, {64, 66}, 40, true)})

	eeltailanim = {mx = 108, my = 54, anim = new_anim(1, 1, {0, 104}, 45, true)}
	add(mapanims, eeltailanim)
end

function play_note_cutscene()
	npcs.note = {
		x = 28,
		y = 13,
		w = 8,
		h = 16,
		verb = 'read',
		actionbox = {x1 = 29, y1 = 10, x2 = 50, y2 = 30},
		lines1 = {
			'dear fish,',
			'thx 4 ur help!',
			'♥santa',
			'p.s. you can keep the hat.',
			'i\'ve got tons of those.'
		},
		post_action = function()
			wait(15)
			state = state_outro
			init_outro()
		end
	}
	local noteanim = add(spriteanims, {
		x = 22,
		y = -23,
		anim = new_anim(2, 3, {76, 76}, 50, true, {
			[2] = {offset = {x = 0, y = -1}}
		}),
	})

	state = state_cutscene

	fade_out()
	local oldcamx, oldcamy = cam.x, cam.y
	cam.x, cam.y = 0, 0
	fade_in()
	repeat
		noteanim.y = approach(0, noteanim.y, .09)
		noteanim.anim:reset()
		yield()
	until flr(noteanim.y) == 0
	wait(240)
	fade_out()
	cam.x, cam.y = oldcamx, oldcamy
	fade_in()

	state = state_game
end

outro_y = 100
outro_buffer_addr = 2162

function init_outro()
	camera()
	for y = 0, 127 do
		for x = 0, 127 do
			local c = pget(x, y)
			pset(x, y, get_fade_col(c, .5))
		end
	end
	flip()
	write_to_buffer()
	screenfadev = nil

	dolphin = {
		x = 56,
		y = 128,
		anims = {
			default = new_anim(2, 2, {74}, 8, true),
			talk = new_anim(2, 2, {74, 106}, 8, true),
		},
		palette = {[1] = 0}
	}
	dolphin.anim = dolphin.anims.default

	cr(run_outro)
end

function run_outro()
	repeat
		dolphin.y = approach(112, dolphin.y, .09)
		yield()
	until flr(dolphin.y) == 112

	wait(15)
	local coincount = inv_entries.coin.count
	local lines = {
		'this has been...',
		'~christmas in the coral caves~',
		'by kittenm4ster',
		'aubrianne drew the intro art!',
		'special thanks to zep for px9',
		'you found ' .. coincount .. '/9 coins!',
		'unfortunately...',
		'the concept of currency...',
		'does not exist in fish society.',
		'but you did a ' .. (coincount == 9 and '★perfect★' or 'great') .. ' job!',
		'thanks for playing!',
		'merry xmas!',
	}

	say_lines(dolphin.x + 7, dolphin.y - 2, lines)
	wait(15)
	music(-1, 3000)
	fade_out()
	cls()
	pal()
	screenfadev, dolphin = nil
end

function update_outro()
	if dolphin then
		if speech then
			dolphin.anim = dolphin.anims.talk
		end

		if dolphin.anim:is_done() then
			if not speech or speech.isdone then
				dolphin.anim = dolphin.anims.default
			end
		end

		dolphin.anim:update()
	end
end

function write_to_buffer()
	for y = outro_y, 127 do
		local offset = y * 64
		memcpy(outro_buffer_addr + offset, 0x6000 + offset, 64)
	end
end

function draw_buffer()
	for y = outro_y, 127 do
		local offset = y * 64
		memcpy(0x6000 + offset, outro_buffer_addr + offset, 64)
	end
end

function draw_outro()
	if dolphin then
		draw_buffer()
		spr(45, dolphin.x - 8, dolphin.y, 1, 2)
		draw_actor(dolphin)
		if speech then
			draw_speech(speech, 10)
			pal(10, 131, 1)
		end
	end
end

function set_arp(len, effect)
	for s = 1, 7 do
		poke(sfx_addr(s) + 65, len)
		for n = 0, 31 do
			local addr = sfx_addr(s) + (n * 2) + 1
			poke(addr, bor(band(peek(addr), 0b10001111), effect))
		end
	end
end

function sfx_addr(n)
  return 0x3200 + (68 * n)
end

function add_tmpbubble(x, y)
	add(tmpbubbles, {
		x = x,
		y = y,
		r = .1,
		vy = rnd(.25),
		vx = rnd_int(-1, 1) / 12
	})
end

function update_tmpbubble(b)
	b.vy -= .01

	if b.r < 1 then
		b.r += rnd(.01)
	end

	b.x += b.vx
	b.y += b.vy

	if b.y < 0 then
		del(tmpbubbles, b)
	end
end

function draw_tmpbubble(b)
	circ(b.x, b.y, b.r, 5)
end

timer = {}
timer.__index = timer

function new_timer(frames)
  return setmetatable({len = frames, v = frames}, timer)
end

function timer:reset()
  self.v = self.len
end

function timer:update()
  if self.v > 1 then
    self.v -= 1
  else
    return true
  end
end

function timer:is_done()
	return self.v == 1
end

-- px9 decompress by zep
function px9_decomp(x0,y0,src,vget,vset)
	local function vlist_val(l, val)
		for i=1,#l do
			if l[i]==val then
				for j=i,2,-1 do
					l[j]=l[j-1]
				end
				l[1] = val
				return i
			end
		end
	end

	local cache,cache_bits=0,0
	function getval(bits)
		if cache_bits<16 then
			cache+=lshr(peek2(src),16-cache_bits)
			cache_bits+=16
			src+=2
		end
		local val=lshr(shl(cache,32-bits),16-bits)
		cache=lshr(cache,bits)
		cache_bits-=bits
		return val
	end

	function gn1()
		local bits,tot=1,1

		while 1 do
			local mx,vv=2^bits-1,
				getval(bits)
			tot+=vv
			bits+=1
			if (vv<mx) return tot
		end
	end

	local w,h,b,
	el,pr,x,y,splen,mode =
		gn1(),gn1(),gn1(),
		{},{},0,0,0

	for i=1,gn1() do
		add(el,getval(b))
	end
	for y=y0,y0+h-1 do
		for x=x0,x0+w-1 do
			splen-=1
			
			if splen<1 then
				splen,mode=gn1(),not mode
			end
			
			local a= y>y0 and vget(x,y-1) or 0
			
			local l=pr[a]
			if not l then
				l={}
				for e in all(el) do
					add(l,e)
				end
				pr[a]=l
			end
			
			local idx=mode and 1 or gn1()+1
			local v=l[idx]

			vlist_val(l, v)
			vlist_val(el, v)
			
			vset(x,y,v)
			
			x+=1
			y+=flr(x/w)
			x%=w
		end
	end
end

swap_addr = 22528--0x5e00 - (64 * 8 * 3)

function spr2(n, x, y, w, h, flipx, flipy, scale)
	w = w or 1
	h = h or 1

	local addr1 = spr_addr(n)
	local addr2 = 0x4300 + spr_addr(n)
	local rowlen = w * 4
	local rowcount = h * 8

	local sw, sh
	if scale then
		sw, sh = w * 8, h * 8
		rowlen = sw / 2
		rowcount = sh
	end

	for i = 0, (rowcount - 1) * 64, 64 do
		assert(swap_addr + i + rowlen - 1 < 0x5e00)
		memcpy(swap_addr + i, addr1 + i, rowlen)
		memcpy(addr1 + i, addr2 + i, rowlen)
	end
	
	if scale then
		local sx, sy = spr_xy(n)
		local dw, dh = 8 * scale, 8 * scale
		sspr(sx, sy, sw, sh, x, y, dw, dh, flipx)
	else
		spr(n, x, y, w, h, flipx, flipy)
	end

	for i = 0, (rowcount - 1) * 64, 64 do
		memcpy(addr1 + i, swap_addr + i, rowlen)
	end
end

function spr_addr(n)
	return (flr(n / 16) * 512) + ((n % 16) * 4)
end

function init_intro()
	camera()
	cls()
	pal()
	screenfadev = 0
	fade(0)
	px9_decomp(0, 21, intro_addr, pget, pset)

	music(20)

	cr(function()
		fade_in(4)
		wait(30)

		local lines = {
			"ho there, fish!",
			"i could really use your help!",
			"sorry, no time to explain...",
			"can you do ol' santa a favor?",
		}
		santa_say(lines)

		wait(15)
		say_lines(90, 15, {'...', '*bloop*'})
		wait(15)

		lines = {
			'i\'ll take that as a "yes".',
			'*ahem*',
			'by the power vested in me...'
		}
		santa_say(lines)

		wait(30)
		showintrohat = true
		sfx(61)
		wait(60)

		lines = {
			"you are the santa now.",
			"go to the coral caves, and...",
			"i'm sure you'll figure it out!",
			"thanks again! gotta run!",
		}
		santa_say(lines)

		fade_out()
		state = state_game
		music(2)

		fade_in()
	end)
end

function santa_say(lines)
	santaspeech = true
	say_lines(16, 13, lines)
	santaspeech = false
end

function draw_intro()
	rectfill(0, 0, 127, 20, 0)

	if showintrohat then
		spr2(64, 77, 23, 7, 2)
		spr2(96, 77, 23 + 16, 7, 2)
		spr2(71, 110, 23 + 32, 3, 2)
		spr2(103, 110, 23 + 48, 3, 2)
	end

	if speech then
		draw_speech(speech, santaspeech and 2 or 3, true)
		if santaspeech then
			spr(70, 15, 1)
			rectfill(15, 12, 17, 13, 0)
		end
	end
end


function init_gfx()
	for c = 1, 15 do
		pal(c, 0, 1)
	end

	local spr1_src_addr = 0
	local spr2_src_addr = 1327
	local intro_src_addr = 2326
	local intro_src_len = 872

	intro_addr = 0x4300 + 4096

	memcpy(intro_addr, intro_src_addr, intro_src_len)

	camera()
	cls()
	px9_decomp(0, 0, spr2_src_addr, pget, pset)
	memcpy(0x4300, 0x6000, 4096)

	cls()
	px9_decomp(0, 0, spr1_src_addr, pget, pset)
	memcpy(0x0, 0x6000, 4095)
end

