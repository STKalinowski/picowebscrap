--
cartdata("belliott_parlor_crater")
saves = {
    528, -- playerx
    50, -- playery
    1, -- player lvl
    3, -- player maxhp
    {   0, -- sword
        0, -- dodge roll
        0, -- double jump
        0, -- reserved
        0, -- bomb bag
        0, -- float bombs
        0, -- power glove
    },
    1, -- player strength
    {
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
          --0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1
        --1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    }, -- beacons
    1, -- player level,
    1, -- total bombs
    1, -- max bombs
} 
_g = {
    v='V1.0.0', --version
    g=0.05, --gravity
    mg=1.5, --max gravity,
    p1=nil, --easy acess to player 1 object
    debug='',
    camx=03*8-64,
    camy=09*8.5-64,
    s=0,    -- scenes 0=title, 1=game, 2=death
    l=1,    -- current level (cart)
    sel=1,  --menu selection
    fs=0,   --fade max
    fc=0,  --fade count
    pd=false,
    w=0, --wait counter
    wr=0, --wait ready (callback)
    msg='',
    lore='',
    hlp='',
    lup=100, -- level up number base
    lum=.27, -- level up modifier
    st=false, -- is the story displaying on the title page
    stm=500, -- amount of time between the title and the story being displayed
    stmr=500, --story timer default value
    mtr = 75, -- max timer
    t = 75, -- current timer
    tf = 60, -- timer frames
    ti = 0, -- timer iterator
    eg = '', --endgame text (when in ship)
    dt = 'you died', -- text that appears on the death/victory screen
    bid = 1, -- beacon id
    mp = false, -- music playing
    bl = 23, -- beacons left
    dcdt = 120, -- death countdown timer
} 

function set_fade(d,c)
    _g.fs,_g.fc = d, c
end

function draw_fade()
    if _g.fs~=0 then
        if _g.fc~=0 then
            local r = 0
            if (_g.fc>0) r = (_g.fc/_g.fs)*8
            if (_g.fc<0) r = 8+(_g.fc/_g.fs)*8

            for y=0, 16 do
                for x=0, 16 do
                    circfill(x*8+4, y*8+4, r, 0)
                end
            end

            if (_g.fc>0) _g.fc-=.5
            if (_g.fc < 0) _g.fc +=.5
        end
    end
end

function spawn_objects()
    for ty=0,64 do
        for tx=0,128 do
            local tile = mget( tx, ty )
            local flag = fget( tile ) == 4
            
            if flag then
                local t,w,h,m =  spawnables[tile][1],spawnables[tile][2],spawnables[tile][3],spawnables[tile][4]
                init_object(t, tx*8, ty*8, w, h, nil, m)
            end
        end
    end
end

function check_hits(ax, ay, aw, ah, bx, by, bw, bh)
    if ax <= (bx + bw)
    and (ax + aw) >= bx
    and ay <= (by + bh) 
    and (ay + ah) >= by
    then
        return true
    else
        return false
    end
end

function check_hits_point(x, y, obj)
    if
        x > obj.x
        and x < obj.x+obj.w
        and y > obj.y
        and y < obj.y+obj.h
    then
        return true
    else
        return false
    end
end

function player_dead()
    if _g.s==1 then
        if _g.w > 0 then
            _g.w -= 1
            if _g.w == 1 then
                set_fade(8,-8)
            end
        else
            if (_g.fc==0) _g.s = 2
        end
    end
end

function draw_ui()
    local hp = _g.p1.hp
    color(7)
    for i=1, hp do
        sspr( 32, 16, 4, 4, 5*i , 2, 4, 4 , false, false )
    end
    if saves[5][5] == 1 then
        sspr( 16, 4, 4, 4, 5, 9, 4, 4 , false, false )
        print(''..saves[9], 12, 8)
    end

    --[[sspr( 96, 4, 4, 4, 100, 3, 4, 4 , false, false )
    local bl = get_beacons()
    print(''..tostr(bl), 107, 2)]]

    color()

end

function load_last_save()
    local o = 0
    _g.bid,_g.t,_g.ti = 1,_g.mtr,0
   
    -- don't use i, instead just add 1 o each time. do i~=5 and i~=7 first, then do those
        for i=1, #saves do
            if i~=5 and i~=7 then
                saves[i] = dget(o)
                o+=1
            end
        end
        for j=1, #saves[5] do
            saves[5][j] = dget(o)
            o+=1
        end
        for k=1,#saves[7] do
            saves[7][k] = dget(o)
            o+=1
        end
    _g.l = saves[3]
    reload(0x2000, 0x2000, 0x1000)
    music(-1)
    spawn_objects()
    init_object(player, saves[1], saves[2], 4, 4)
    _g.camx, _g.camy,input.o[3],_g.s  = saves[1]-48,saves[2]-48, true, 1
    set_fade(8,8)
    _g.mp = false
end

function save_game()
    local o = 0
    _g.bid,_g.t,_g.ti = 1,_g.mtr,0
    for i=1, #saves do
        if i~=5 and i~=7 then
            dset(o, saves[i])
            o+=1
        end
    end
    for j=1, #saves[5] do
        dset(o, saves[5][j])
        o+=1
    end
    for k=1,#saves[7] do
        dset(o, saves[7][k])
        o+=1
    end
end

function smoke(this)
    for i=1, 6 do
        local sx,sy,r,c = rnd(2)-1,rnd(2)-1,rnd(4)+4,rnd(100) > 50 and 6 or 7
        init_particle(this.x+this.w/2, this.y+this.h/2, sx, sy, r, c, 1, false)
    end
end

function countdown()
    local t,tf,ti = _g.t,_g.tf,_g.ti
    if (ti % tf == 0) _g.t-=1
    _g.ti += 1
    if (ti == tf) _g.ti = 0
    if t < 0 and (--[[ti % tf == flr(rnd(tf)) or]] ti % tf == 0) then
        local p1 = _g.p1
        local x,y,c = flr(p1.x+rnd(128)-64),flr(p1.y+rnd(128)-64),rnd(100)>50 and 9 or 10               
        exploder(x,y,c)
        _g.tf = _g.tf > 10 and _g.tf-1 or 10
    end
end

function get_beacons()
    local bl = 0
    foreach(objects, function(obj)
        if (obj.type==beacon) bl+=1
    end)
    --[[for k=1,#saves[7] do
        if (saves[7][k] == 1) bl +=1
    end]]
    return bl
end

function exploder(x, y, c)
    sfx(6)
    --[[init_particle(x, y, .1, .1, 8, c, .5, true)
    init_particle(x, y, -.1, .1, 8, c, .5, true)
    init_particle(x, y, .1, -.1, 8, c, .5, true)
    init_particle(x, y, -.1, -.1, 8, c, .5, true)]]
    init_particle(x, y, .5, 0, 6, 7, .25, true)
    init_particle(x, y, -.5, 0, 6, 7, .25, true)
    init_particle(x, y, 0, .5, 6, 7, .25, true)
    init_particle(x, y, 0, -.5, 6, 7, .25, true)
end

function play(i)
    if _g.mp == false then
        music(i)
        _g.mp = true
    end
end 
text=
{
    "attack: \x97",
    "dodge-roll: \x83+\x8E",
    "sword-boost: \x94+\x97",
    "4",
    "place bomb: \x83+\x97",
    "bombs upgraded!",
    "you found a power glove!",
    "debug_8",
    "mission objective: find and  destroy all abandoned mining  beacons.",
    "roll past hazards and        enemies to avoid damage.",
    "thick brush can be cleared   with your sword.",
    "roll when landing to avoid   fall damage.",
    "strike upward to gain more   height when jumping. ",
    "some blocks can be pushed    with the power glove.",
    "modified bombs defy gravity.",
    "bombs can be used to destroy inactive mining beacons.",
    "max hp increased!",
    "bomb capacity increased!",
    "hp restored",
    "progress saved"
}
--[[lore=
{
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "hp rESTORED",
    "11",
    "12",
    "13",
    "14",
    "pROGRESS sAVED",
    "16",
    "17",
    "18",
    "19",
    "20"
}]] 
input=
{
    l={0,true,false},
    r={1,true,false},
    u={2,true,false},
    d={3,true,false},
    o={5,false,false},
    x={4,true,false},
    l2={6,true,false},
    r2={7,true,false},
    u2={8,true,false},
    d2={9,true,false},
    o2={10,false,false},
    x2={11,true,false}
} 
modules = {
    --1
function(this)

    if this.cf == 31 then
        if this.at==2 and this.cb then
            this.ca,this.pi=9,true
        else
            this.cb = false
        end
    end

    if not this.pi
        then
        this.ix = btn(input.r[1]) and 1 or (btn(input.l[1]) and -1 or 0)
        if this.ix ~= 0 then 
            modules[9](this)
        else
            modules[3](this)
        end

        if this.sx ~= 0 then
            this.ca=2
            if (this.og and this.at==1 and (this.cf==3 or this.cf==7)) sfx(0)
        else
            this.ca=1
        end

        if this.sy > 0 and not this.og and not this.wj then
            if this.cf >= 20 or not btn(input.o[1]) then
                this.ca=5
            else
                this.ca=4
            end
        elseif this.sy < 0 and not this.og then
            this.ca=3
        end

        --wallslide
        --[[if ((fget( mget( (this.x+this.w+.5)/8, (this.y+1)/8 ), 0 )
        and fget( mget( (this.x+this.w+.5)/8, (this.y+this.h-1)/8 ), 0 ))
        or (fget( mget( (this.x-.5)/8, (this.y+1)/8 ), 0 )
        and fget( mget( (this.x-.5)/8, (this.y+this.h-1)/8 ), 0 )
        ))
        and not this.og
        and this.sy > 0
        and saves[5][4]==1
        then
            if (btn(input.r[1]) or btn(input.l[1])) this.sy = .5
            this.wj = true
            this.ca=7
            this.ft = 0
        else
            this.wj = false
        end]]

        --jump
        if btn(input.o[1]) 
        and (this.og 
        or this.jt < this.jg)
        and not btn(input.d[1])
        and input.o[2]
        then
            modules[4](this)
            this.jt,this.og,input.o[2] = this.jg,false,false
            sfx(2)
        end

        --wally
        --[[if btnp(input.o[1]) 
        and (this.wj and input.o[2])
        and not btn(input.d[1]) 
        then

            if this.wj 
            and fget( mget( (this.x+this.w+.5)/8, (this.y+1)/8 ), 0 )
            and fget( mget( (this.x+this.w+.5)/8, (this.y+this.h-1)/8 ), 0 )
            and input.o[2]
            then
                --this.runtimer = 10
                --this.x -= 2
                this.sx = -this.rs
                this.rmovelocktimer = 10
                input.o[2] = false
                this.dj = true
                modules[4](this)
                this.sy += .4
            elseif this.wj 
            and fget( mget( (this.x-.5)/8, (this.y+1)/8 ), 0 )
            and fget( mget( (this.x-.5)/8, (this.y+this.h-1)/8 ), 0 )
            and input.o[2]
            then
                --this.x += 2
                this.sx = this.rs
                this.lmovelocktimer = 10
                --this.runtimer = 10
                this.dj = true
                input.o[2] = false
                modules[4](this)
                this.sy += .4
            end
        end]]

        --doublejump
        --[[if btnp(input.o[1]) 
        and this.sy > -.5
        and not this.dj 
        and input.o[2]
        and not this.wj
        and not btn(input.d[1])
        and saves[7] == 1
        then
            modules[4](this)
            this.dj = true
        end]]--

        --roll
        if btnp(input.o[1])
        and btn(input.d[1])
        and input.o[2]
        and this.og 
        and this.rcdt == 0
        and saves[5][2] == 1
        then
            input.o[2],this.rcdt,this.ca,this.pi,this.sx,this.rol = false,40,6,true,this.f*this.rs*this.rls,true
            sfx(3)
        else
            this.rol = false
        end
    
    end
    

    --attack
    if btnp(input.x[1]) 
    and this.ata 
    and input.x[2]
    and saves[5][1] == 1
    and this.cdt == 0
    and not btn(input.d[1])
    then
        this.pi,input.x[2],this.ata,this.dj = true,false,false,true
        if (this.og) this.sx = 0
        if btn(input.u[1]) then
            this.ca,this.ft=10,0
        else
            this.ca=8
        end
    end

    if (this.ca>=6 and this.cf==this.an[this.ca][2][2] and this.at==this.an[this.ca][1] ) this.pi = false

    if this.ca==8 then
        if this.cf > 26 then
            if (this.cf == 27 and this.at==0) init_object(slash, this.x, this.y-4, 8, 8, this)
        else
            if btn(input.u[1]) then
                this.ca=10
            end
        end
        if this.cf > 23 then
            if btnp(input.x[1]) then
                input.x[2],this.cb,this.cdt = false,true,20
            end
        end
    end

    if this.ca==9 then
        if this.cf == 32 and this.at==1 then
            this.sx = this.ls*this.f
            init_object(slash, this.x, this.y-4, 8,8, this)
        end
    end

    if this.ca==10 then
        -- sword boost
        if this.cf > 26 then
            if saves[5][3] == 1 then
                this.sy = -.5
                this.ft=0
            end
            this.og = false
            if (this.cf == 27 and this.at==0) init_object(slash, this.x, this.y-4, 8, 8, this)
        end
    end

    if this.ca==11 then
        
        if this.cf > 26 then
            this.og = false
            if (this.cf == 27 and this.at==0) init_object(slash, this.x, this.y, 8, 8, this)
        end
    end

    if (this.sy < 0 and not btn(input.o[1]) and not this.b ) this.sy +=.1 
    if (this.og) this.ata = true

    --bombs
    if btnp(input.x[1]) 
    and this.ata 
    and input.x[2]
    and saves[5][5] == 1
    and this.cdt == 0
    and btn(input.d[1])
    and saves[9] > 0
    then
        init_object(bomb, this.x, this.y, 4, 4, this)
        sfx(7)
        saves[9] -= 1
        this.bcdt = 200
    end

    if saves[9] < saves[10] and this.bcdt == 0 then
        this.bcdt = 200
        saves[9]+=1
    end

end ,   --2
function(this)
    --gravity
if not this.og and this.s then
    if this.sy < _g.mg then
        this.sy += _g.g*this.rg
    else 
        this.sy = _g.mg*this.rg
    end
    if this.sy > 0 and not this.og and this.rg==1 then
        this.ft += 1
    end
end     --collisions
this.cx,this.cy = 0,0
--horizontal collisions
local bs = this.sx >0 and this.w or 0
if (fget( mget( (this.x+bs+this.sx)/8, (this.y+1)/8 ), 0 ) or 
fget( mget( (this.x+bs+this.sx)/8, (this.y+this.h-1)/8 ), 0 )) and
this.s
then
    while (fget( mget( (this.x+bs+this.sx)/8, (this.y+1)/8 ), 0 ) or 
    fget( mget( (this.x+bs+this.sx)/8, (this.y+this.h-1)/8 ), 0 )) do
        this.x-=.01*sgn(this.sx)
    end
    this.cx,this.sx = this.f,0
end
this.x += this.sx

--vertical collisions
local bs,hd = this.sy > 0 and this.h or 0,this.sy > 0 and 0 or 1
if (fget( mget( (this.x)/8, (this.y+bs+this.sy+hd)/8 ), 0 ) or 
fget( mget( (this.x+this.w-1)/8, (this.y+bs+this.sy+hd)/8 ), 0 ))
and this.s
then
    if this.sy < 0 then
        --[[while (fget( mget( (this.x)/8, (this.y+bs+this.sy+hd)/8 ), 0 ) or 
        fget( mget( (this.x+this.w-1)/8, (this.y+bs+this.sy+hd)/8 ), 0 )) do
            this.y-=1*sgn(this.sy)
        end]]
        this.y = flr((this.y+bs+this.sy+hd)/8)*8+7
    else 
        this.y = flr((this.y+bs+this.sy+hd)/8)*8-this.h
    end
    this.cy,this.sy = this.sy > 0 and 1 or -1, 0
end

this.y += this.sy


if (fget( mget( (this.x)/8, (this.y+this.h+1)/8 ), 0 ) or 
fget( mget( (this.x+this.w-1)/8, (this.y+this.h+1)/8 ), 0 )) and
this.s
then
    if this.ft > this.fd then
        this.fg,this.fdm = true,flr((this.ft - this.fd)/10)+1
    end
    if (this.ft > 1) sfx(2)
    this.ft,this.og,this.b,this.dj,this.jt = 0,true,false,false,0
else
    this.og = false
    this.jt += 1
end

if this.fg then
    this.fgt -= 1
    if this.rol
    then
        this.fg,this.fgt = false,this.fgtm
        this.fdm-=2
        if (this.fdm<0) this.fdm=0
        this.hp -= this.fdm
        this.fdm = 0
    end
    if this.fgt == 0 then
        this.ifr,thispi,this.sy,this.fdm,this.fg,this.fgt= this.mif,true,-1.25,0,false,this.fgtm
        this.hp -= this.fdm
    end
    
end

if (fget( mget( (this.x+bs+this.sx)/8, (this.y+1)/8 ), 5 ) or 
fget( mget( (this.x+bs+this.sx)/8, (this.y+this.h-1)/8 ), 5 ) or 
fget( mget( (this.x)/8, (this.y+bs+this.sy-4)/8 ), 5 ) or 
fget( mget( (this.x+this.w-1)/8, (this.y+bs+this.sy-4)/8 ), 5 )) and
this.rol == false
then
    this.hp = 0
end 
end ,   --3
function(this)
    this.sx *= this.fr
    if abs(this.sx) < .025 then 
        this.sx = 0
    end
end ,   --4
function(this)
    this.sy = -this.js
end ,   --5
function(this)
    if this.at == 0 then       
        local start_frame, end_frame = this.an[this.ca][2][1],this.an[this.ca][2][2]
        this.cf += 1
        if (this.cf > end_frame or this.cf < start_frame) this.cf = start_frame
        this.cfx, this.cfy, this.at = (( this.cf ) % ( 8/this.w * 16)) * this.w,flr( this.cf / ( 8/this.w * 16) ) * this.h,this.an[this.ca][1]
    else
        this.at -= 1
        if (this.cf == this.an[this.ca][2][2] and this.at == 0) this.ca=1 
    end
end ,   --6
function(this)
    if (this.cdt > 0) this.cdt -= 1
    if (this.rcdt > 0) this.rcdt -= 1
    if (this.bcdt > 0) this.bcdt -= 1
end ,   --7
function(this)
    if (this.k) del(objects, this)
    if (this.cf == this.an[this.ca][2][2] and this.at == this.an[this.ca][1]) this.k = true
end ,   --8
function(this)
    if (this.cx ~= 0) this.ix = this.cx*-1
end ,   --9
function(this)
    this.f = this.ix
    if this.sx < this.rs
    and this.ix == 1
    then 
        if this.rmovelocktimer == 0 then
            this.sx += .1 
        else
            this.rmovelocktimer -= 1
        end
    elseif this.sx > -this.rs 
    and this.ix == -1
    then 
        if this.lmovelocktimer == 0 then
            this.sx -= .1 
        else
            this.lmovelocktimer -= 1
        end
    end
    if abs(this.sx) > this.rs and this.og then
        if this.runtimer == 0 then
            this.sx*=.99 
        else
            this.runtimer -=1
        end
    else
        this.runtimer = this.runtime
    end
end ,   --10
function(this)
    local left,right = fget( mget( (this.x+1)/8, (this.y+this.h+1)/8 ), 0 ),fget( mget( (this.x+this.w-1)/8, (this.y+this.h+1)/8 ), 0 ) 
    if (left and not right and this.og) this.ix = -1
    if (not left and right and this.og) this.ix = 1
end ,   --11
function(this)
    local cx,cy,tx,ty,dx,dy,amount = _g.camx,_g.camy,this.x-64,this.y-64-32,30,20,.07
    local lerpx, lerpy = (tx - cx) * amount,(ty - cy) * amount
    if abs(lerpx) < 1 then lerpx = 1*sgn(lerpx) end
    if abs(lerpy) < 1 then lerpy = 1*sgn(lerpy) end
    _g.camx, _g.camy = cx + lerpx,cy + lerpy
    if abs(tx-cx) <= .75 then _g.camx = tx end
    if abs(ty-cy) <= .75 then _g.camy = ty end
    if _g.camy < 0 then _g.camy = 0 end
    if _g.camy+128 > 64*8 then _g.camy = 64*8-128 end
    if _g.camx < 0 then _g.camx = 0 end
    if _g.camx+128 > 128*8 then _g.camx = 128*8-128 end
end ,   --12
function(this)
    this.sy -= _g.g
    this.ft = 0
end ,   --13
function(this)
    if this.sy < this.rs
    and this.iy == 1
    then 
        this.sy += .1 
    elseif this.sy > -this.rs 
    and this.iy == -1
    then 
        this.sy -= .1 
    end
    if (abs(this.sy) > this.rs) this.sy *= .95
end ,   --14
function(this)
    if (this.cy ~= 0) this.iy = this.cy*-1
end ,   --15
function(this)
    local p1 = _g.p1
    this.ca,this.ifr=this.mod-4,0
    if check_hits(
        this.x,
        this.y,
        this.w,
        this.h,
        p1.x,
        p1.y,
        p1.w,
        p1.h
    )
    then
        sfx(9)
        if this.mod == 13 and p1.hp < saves[4] then
            p1.hp+=1
        elseif this.mod == 14 and saves[9] < saves[10] then
            saves[9] += 1
        end
        del(objects, this)
    end
end ,   --16
function(this)
    if this.cdt == 0 and this.og then
        this.f = flr(rnd(100))>50 and 1 or -1
        if (this.ix ~= 0) this.f = this.ix
        this.ca=2 --ca=2 needs to be the jump animation!
        this.sx = this.rs*this.f
        this.sy = -this.js
        this.cdt = flr(rnd(120))+60
        
    else
        if this.sx > 0 then this.sx -= .01 end
        if this.sx < 0 then this.sx += .01 end
        if abs(this.sx) < .1 then this.sx = 0 end
    end
    if not this.og and this.sy > 0 then this.ca=3 end -- fall needs to be ca=3
end ,   --17
function(this)
    this.x += this.rs*this.ix
    this.y += sin(this.x/20)*1.25;
    this.life-=1
    if (this.life == 0 or this.x > 1024 or this.x < 0) this.hp=0
end ,   --18
function(this)
    this.hp-=1
    if (this.sy < 0) this.sy = 0
    if this.hp <= 0 then
        local x,y,c=this.x+this.w/2,this.y+this.h/2,rnd(100)>50 and 9 or 10
        exploder(x,y,c)
        del(objects, this)
    end
end ,   --19
function(this)
    this.x,this.y = this.inx,this.iny
end ,   --20
function(this)
    local p1 = _g.p1
    _g.eg=''
    this.ifr=0
    if check_hits(
        this.x+1,
        this.y+1,
        this.w-1,
        this.h-1,
        p1.x+1,
        p1.y+4,
        p1.w-1,
        p1.h-4
    )
    then
        local bl = _g.bl
        
        if bl == 0 then
            _g.dt,_g.mp = 'mission complete\nthanks for playing!', false

            player_dead()
            
        else
            _g.eg = bl..' beacons remaining'
        end
    end
end ,   --21
function(this)
    
    if this.hp <= 0 then
        local x,y=this.x,this.y
        smoke(this)
        sfx(4)
        if (this == _g.p1) then 
            _g.pd,_g.pd=true,60
        end
        if this.p ~= nil then
            if (this.p.type == beacon) this.p.ec-=1
        end
        if rnd(100)<50 and this.type ~= pickup and this.type ~= player then
            if rnd(100)>33 then
                init_object(pickup, this.x, this.y-4, 4, 4, nil, 13)
            --[[else
                init_object(pickup, this.x, this.y-4, 4, 4, nil, 14)]]
            end
        end

        if (this.type == beacon) then
            saves[7][this.id]=0
        end

        del(objects, this)
    end
end ,   --22
function(this)
    local p1 = _g.p1
    if check_hits(
        this.x,
        this.y,
        this.w,
        this.h,
        p1.x,
        p1.y,
        p1.w,
        p1.h
    ) and p1.ifr == 0
    and p1.ca~=6 
    then
        p1.ifr= p1.mif
        p1.pi = true
        p1.sy = -1.25
        p1.hp -= this.str
        sfx(1)
    end
end ,   --23
function(this)
    if this.ifr > 0 then
        this.ifr -= 1
    end
    if (this.ifr == this.mif-10) this.pi = false
end ,   --24
function(this)
    this.cr -=this.ds
    if (this.cr<=.1) del(objects, this)
end ,   --25
function(this)
    local p1 = _g.p1
    if (this.x == saves[1] and this.y == saves[2]) this.act = true
    if check_hits(
        this.x,
        this.y,
        this.w,
        this.h,
        p1.x,
        p1.y,
        p1.w,
        p1.h
    )
    then
        _g.hlp='\x94'
        if btnp(input.u[1]) and p1.og then
            _g.hlp=''
            foreach(objects, function(obj)
                if (obj.type==this.type) obj.act = false
            end)
            this.act = true
            saves[1] = this.x
            saves[2] = this.y
            saves[3] = _g.l
            saves[4] = p1.mhp
            saves[6] = p1.str
            saves[9] = saves[10]
            
            save_game()
            local msg = 0
            if (this.type == ship) msg+=1
            
            _g.msg=text[20]
            --_g.lore=lore[15+msg]
            objects={}
            init_object(player, saves[1], saves[2], 4, 4)
            spawn_objects()
            music(-1)
        end
    end
    if (this.act == true and this.type ~= ship) then
        this.ca=2
        if rnd(100) > 80 then
            --x,y,sx, sy, r, c, d, h
            c = rnd(100)>50 and 3 or 11
            init_particle(this.x+2+(rnd(4)-2), this.y-(rnd(2)+1)+1, 0, rnd(100)/100*-1, 1, c, .1, false)
            --init_object(smoke, this.x+2+(rnd(4)-2), this.y-(rnd(2)+1), 1.5, .25, nil, 2)
        end
    end
end ,   --26
function(this)
    if (this.cdt==0) del(objects, this)
end ,   --27
function(this)
    foreach(objects, function(obj)
        if check_hits(
            this.x,
            this.y,
            this.w,
            this.h,
            obj.x,
            obj.y,
            obj.w,
            obj.h
        ) and obj.ifr == 0
        and obj ~= this.p
        and obj ~= this
        and obj.push == nil
        then
            obj.ifr,obj.pi,obj.ag = obj.mif,true,true
            obj.hp -= this.p.str
            sfx(1)
            if this.ca==1 or this.ca==2 then
                obj.sy = -.25
                if (obj.ix == this.f) obj.ix = -this.f
                obj.sx= 0 
            elseif this.ca==3 then
                obj.sy= 0 
                if not obj.ag then
                    obj.sy += this.rs*obj.rs*-12
                else
                    obj.sy += this.rs*obj.rs*-5
                end
            elseif this.ca==4 then
                obj.sy= 0 
                if not obj.ag then
                    obj.sy += this.rs*obj.rs*12
                else
                    obj.sy += this.rs*obj.rs*5
                end
                this.p.b=true
                this.p.sy = -this.p.js*.75
                this.ft = 0
            end
            
        end
    end)
    
end ,   --28
function(this)
    if this.ag and this.ifr==0 then
        this.ix,this.iy,this.f = 0,0,sgn(_g.p1.x - this.x) 
        this.sx += sgn(_g.p1.x - this.x)*this.ars
        if (this.sx > this.rs) this.sx = this.rs  
    end
end ,   --29
function(this)
    local p1 = _g.p1
    this.ifr=0
    if check_hits(
        this.x,
        this.y,
        this.w,
        this.h,
        p1.x,
        p1.y,
        p1.w,
        p1.h
    ) 
    then
        _g.hlp='\x94'
        if btnp(input.u[1]) then
            _g.hlp,mod='',this.mod
            --saves[5][mod],_g.msg,_g.lore = 1,text[mod],lore[mod]
            saves[5][mod],_g.msg = 1,text[mod]
            music(-1)
            music(0)
        end
    end
    if (saves[5][this.mod]==1) del(objects, this)
end ,   --30
function(this)
    this.ca,this.ifr=this.mod-6,0
    local p1 = _g.p1
    if check_hits(
        this.x,
        this.y,
        this.w,
        this.h,
        p1.x,
        p1.y,
        p1.w,
        p1.h
    )
    then
        _g.hlp='\x94'
        if btnp(input.u[1]) then
            _g.hlp=''
            local mod = this.mod
            music(-1)
            music(0)
            if (mod==8) then 
                _g.p1.mhp+=1
                _g.p1.hp=_g.p1.mhp
            end
            if mod==9 then
                --_g.p1.str+=1
                saves[10]+=1
                
            end
            if (mod==10) _g.p1.hp=_g.p1.mhp

            --_g.msg,_g.lore,saves[7][this.id]=text[mod],lore[mod],0
            _g.msg,saves[7][this.id]=text[mod+9],0
            del(objects, this)
        end
    end
end ,   --31
    nil--include _modules/m_boss.lua
,   --32
    nil--include _modules/m_boss_float.lua
,   --33
    nil--include _modules/m_boss_v_move.lua
,   --34
    nil--include _modules/m_orbit.lua
,   --35
function(this)
    local p1 = _g.p1
    this.ifr=0
    if check_hits(
        this.x,
        this.y,
        this.w,
        this.h,
        p1.x,
        p1.y,
        p1.w,
        p1.h
    )
    then
        _g.hlp='\x94'
        if btnp(input.u[1]) then
            _g.hlp=''
            --mod,_g.msg,_g.lore = this.mod+8,text[mod],lore[mod]
            mod = this.mod+8
            _g.msg = text[mod]
        end
    end
end ,   --36
    nil --include _modules/m_coin.lua
,   --37
    nil --include _modules/m_levelup.lua
,   --38
function(this)
    local x,y,cr = this.x,this.y,this.cr
    bounds = 
    {
        { x-cr, y-cr },
        { x+cr, y-cr },
        { x-cr, y+cr },
        { x+cr, y+cr },
        { x, y-cr },
        { x, y+cr },
        { x-cr, y },
        { x+cr, y }
    }
    
    for k, v in pairs(bounds) do
        local gx, gy, nx, ny = flr(v[1]/8), flr(v[2]/8), v[1]-(v[1]%8)+4, v[2]-(v[2]%8)+4
        if fget( mget( gx, gy ), this.mget ) then
             mset( gx, gy, 0 )
             init_particle(nx, ny, .25, .25, 3, 7, .25)
             init_particle(nx, ny, -.25, .25, 3, 7, .25)
             init_particle(nx, ny, .25, -.25, 3, 7, .25)
             init_particle(nx, ny, -.25, -.25, 3, 7, .25)
            
        end
        
    end
    
end ,   --39
function(this)
    this.ifr=0
    foreach(objects, function(obj)

        local bs = obj.sx > 0 and obj.w or 0
        --horizontal
        if  check_hits_point(obj.x+bs+obj.sx, obj.y+1, this)
            or check_hits_point(obj.x+bs+obj.sx, obj.y+obj.h-1, this)
            and obj ~= this.p
            and obj ~= this
        then
            obj.x = ((this.x+this.w/2)-obj.w/2)+(this.w/2*-obj.f)+(obj.w/2*-obj.f)
            if obj.type==waver then obj.hp=0 end
            --if (btn(input.l[1])) obj.x+=1
            if this.push and _g.p1 == obj and saves[5][7] == 1 then
                this.x+=obj.f
                local bs3 = obj.sx > 0 and this.w or 0
                while (fget( mget( (this.x+bs3+this.sx)/8, (this.y+1)/8 ), 0 ) or 
                fget( mget( (this.x+bs3+this.sx)/8, (this.y+this.h-1)/8 ), 0 )) do
                    this.x-=.01*obj.f
                end
            end
            obj.sx = 0
        end

        bs = obj.sy > 0 and obj.h or 0
        if  check_hits_point(obj.x, obj.y+bs+obj.sy, this)
            or check_hits_point(obj.x+obj.w-1, obj.y+bs+obj.sy, this)
            and obj ~= this.p
            and obj ~= this
        then
            if obj.type==waver then obj.hp=0 end
            if (obj.sy > 0) then
                obj.y,obj.og,obj.ft = this.y-obj.h,true,0
            elseif (obj.sy < 0) then
                obj.y = this.y+this.h
            end
            obj.sy = 0
        end

    end)
   
end ,   --40
function(this)
    if this.cdt == 0 and this.ec <= this.mec and this.act ~= true then
        if this.mod > 1 then
            local t,r = {walker, dropper, hopper, flyer, waver}, rnd(100)>50 and 8 or -12

            init_object(t[this.mod-1], this.x+this.w/2+r, this.y, 4, 4, this, 1)
        end
        this.ec+=1
        this.cdt = 200
    end
end ,   --41
    nil --include _modules/m_all_dangerous.lua
,   --42
function(this)
    foreach(objects, function(obj)
        if check_hits(
            this.x,
            this.y,
            this.w,
            this.h,
            obj.x,
            obj.y,
            obj.w,
            obj.h
        ) and obj.ifr == 0
        and obj ~= this
        and obj ~= this.p
        and obj.s
        and obj.type ~= this.type
        then
            if(this.ca == 1) this.ca = 2
            if this.ca == 3 and obj.rol ~= true then
                obj.ifr,obj.pi= obj.mif,true
                obj.hp -= this.str
                if this.kb then
                    obj.sy,obj.sx = -1.25,-.5*this.f
                end
            end
        end
    end)
    if (this.ca == 2 and this.cf==63) then
        this.ca,this.cdt=3,100
    end
    if (this.cdt > 1) this.ca=3
    if (this.cdt == 1) this.ca=4
    if(this.ifr>0 and this.ca==1)this.ca=2
end ,  --43
function(this)
    local p1 = _g.p1
    this.ft=0
    if check_hits(
        this.x-8,
        this.y,
        this.w+8,
        this.h+40,
        p1.x,
        p1.y,
        p1.w,
        p1.h
    ) and p1.ifr == 0
    and p1.ca~=6 
    then
        this.rg=1
        this.fy=true
    end
end } 
objects,runtime,movelock = {}, 25, 10
function init_object(type, x,  y, w, h, p, mod)
    local obj = {
        type = type,
        x=x,
        y=y,
        inx=x,       --initx
        iny=y,       --inity
        w=w,
        h=h,
        str=1,
        hp=6,
        mhp=6,      --max hp
        mod=mod or 1,    --object modifier
        ag=false,   --aggro
        ars=.005,   --aggro runspeed
        ix=0,       --input x (left or right)
        iy=0,       --input y (up or down)
        p=p or nil, --parent object
        rs=.5,      --run speed
        rls=2,    --roll speed
        ls=.325,    --lungespeed
        sx=0,       --x speed
        sy=0,       --y speed
        s=true,     --solid
        og=false,   --onground
        dj=false,   --doublejump
        wj=false,   --wall jump
        jt=0,       --jumptick
        jg=10,      --jump grace period (after walking off ledge)
        js=0,       --jump speed(height)
        cx=0,       --horizontal collision
        cy=0,       --vertical collision
        cb=false,   --combo
        fr=.8,      --friction
        f=1,        --facing
        fy=false,   --flipy
        ca=1,       --current animation
        cf=1,       --current frame
        cfx = 0,    --current frame x
        cfy = 0,    --current frame y
        at=0,       --animation tick
        ifr=0,      --invincibility frames
        mif=20,     --max Iframes
        cdt=0,      --cooldown timer
        rcdt=0,     -- roll cooldown timer
        ata=true,   --attackair?
        vrx=32,     --horizontal vision range
        vry=32,     --vertical vision range
        b=false,    --is bouncing off of enemy
        m={},        --modules
        coins=true,  --coins on death
        runtime = 25,-- how long object can sprint
        runtimer = runtime, -- countdown timer
        movelock = 10, -- prevent pushing back during walljump
        lmovelocktimer = movelock, -- timer for left movement lock
        rmovelocktimer = movelock, -- timer for right movement lock
        ft=0, -- fall timer
        fd=50, --fall distance before injury
        fdm=0, --fall damage
        fg=false, --grace period to roll out of a fall
        fgtm=8, -- grace period max (for reset)
        fgt=6, --timer for the grace period
        rol=false, --is the object roll-doding?
        ds=.1, --diminish speed for particles
        sb=false, --solid block
        rg=1,    --for reverse gravity set to -1
        kb=true,  --kickback when hurt
        des=0, --destroyed = 1
        bcdt=0,
    }
    obj.update=function()
        obj.oy = 0
        if obj.sy > 0 then
            obj.iy = 1
        elseif obj.sy < 0 then
            obj.iy = -1
        end
        for i=1, #obj.m do
            modules[ obj.m[ i ] ](obj)
        end
    end
    obj.draw=function()
        if obj.ifr > obj.mif-5 then
            for i=0, 15 do
                pal(i, 7)
            end
            sspr( obj.cfx, obj.cfy, obj.w, obj.h, obj.x , obj.y, obj.w, obj.h , (obj.f==-1), obj.fy )
            pal()
        elseif obj.ifr % 2 == 0 then
                sspr( obj.cfx, obj.cfy, obj.w, obj.h, obj.x , obj.y, obj.w, obj.h , (obj.f==-1), obj.fy )
        end
    end
    if (obj.type ~= nil) obj.type.init(obj)
    if (obj.hp > 0) add(objects, obj)
    
    return obj
end

player=
{
    init=function(this)
        this.m = {1,2,5,6,11,21,23}
        this.js=1.35
        _g.p1 = this
        this.mif=45
        this.mhp=saves[4]
        this.hp=this.mhp
        this.str=saves[6]
        this.xp=saves[7]
        this.plv=saves[8]
        this.exit=false
        this.coins=false
        smoke(this)
        music(3)
        this.an=
		{
			{ -- 1 idle
				1,
				{0,0},
			},
			{ -- 2 run
				4,
				{1,8},
            },
            { -- 3 jump
                1,
                {17,17}
            },
            { -- 4 flip
                4,
                {18,20}
            },
            { -- 5 fall
                1,
                {21,21}
            },
            { -- 6 roll
				2,
				{9,16},
            },
            { -- 7 wallslide
                1,
                {22,22}
            },
            { -- 8 attack 1
                2,
                {23,31}
            },
            { -- 9 attack 2
                2,
                {32,35}
            },
            { -- 10 attack up
                2,
                {23,31}
            },
            { -- 11 attack down
                2,
                {23,31}
            }
        }
    end,
} bomb = {
    init=function(this)
        if saves[5][6] == 1 then
            this.m={12,2,5,6,18,19,23}
        else
            this.m={2,5,6,18,23}
        end
        this.hp,this.ln,this.ag,this.coins=100,false,true,false
        this.an=
        {
            { --idle
                6,
                {36,37}
            },
        }
        if (this.p~=nil) add(this.p.ch, this)
    end
} slash = {
    init=function(this)
        this.m={2,5,7,27,38}
        this.s = false
        this.mget=6
        this.cr=4
        this.an={
            { -- atk 1
                3,
                {16,19}
            },
            { -- atk 2
                3,
                {20,23},
            },
            { --atk up
                3,
                {24,27},
            },
            { -- atk down
                3,
                {24,27},
            }
        }
        sfx(5)
        this.f = this.p.f
        this.x = (this.p.x+(this.p.w/2)-(this.w/2))+(this.f*this.w/2)
        if (this.p.ca==8 or this.p.ca == 9) this.sx = this.f*.5
        if this.p.ca == 9 then
            this.ca=2
            this.x = (this.p.x+(this.p.w/2)-(this.w/2))+(this.f*this.w/4)
        end
        if this.p.ca == 10 then
            this.ca=3
            this.x = this.p.x+(this.p.w/2)-(this.w/2)
            this.sy = -.75
        end
        if this.p.ca == 11 then
            this.ca=4
            this.fy = true
            this.x = this.p.x+(this.p.w/2)-(this.w/2)
            this.sy = .75
        end
    end
} push = {
    init=function(this)
        this.m={2,3,5,39}
        --this.y-=8
        this.push=true
        this.an=
        {
            {
                1,
                {57,57}
            },
        }
    end
} beacon = {
    init=function(this)
        this.m,this.hp,this.mif,this.ec,this.mec,this.inx,this.iny,this.act,this.id={5,6,19,21,23,25,40},1000,45,0,5,this.inx+2,this.iny+4,false,_g.bid
        _g.bid+=1
        this.an=
        {
            {
                3,
                {54,55}
            },
            {
                3,
                {56,57}
            }
        }
        if (this.x == saves[1] and this.y == saves[2]) this.act = true
        if (this.mod == 3 ) this.mec = 2
        if (saves[7][this.id]==0) this.hp=0
    end
} pickup = {
    init=function(this)
        this.id = _g.bid
        _g.bid+=1
        if (this.mod <= 7) this.m = {5,6,21,23,29}
        this.y+=4
        this.x+=2
        this.hp=1000
        this.an={
            {
                4,
                {60,63}
            },
            {
                4,
                {52,53}
            },
            {
                4,
                {50,51}
            },
            {
                4,
                {58,59}
            },
            {
                4,
                {58,59}
            },
            {
                4,
                {58,59}
            },
            {
                4,
                {136,136}
            },
            {
                4,
                {36,36}
            },
            {
                4,
                {136,136}
            },
            {
                4,
                {36,36}
            }

        }
        if this.mod>=8 and this.mod<=12 then
            this.m = {2,5,21,30}
        end
        if this.mod>=13 and this.mod<=14 then
            this.cdt=200
            this.hp,this.m = 500,{2,5,6,15,21,26}
        end
        if (saves[7][this.id]==0) this.hp=0
    end
} message={
    init=function(this)
        this.m={5,35}
        this.y+=4
        this.hp=10000
        this.an={
            {
                4,
                {46,49}
            }
        }
        
    end
} walker = {
    init=function(this)

        this.m = {2,5,6,8,9,21,22,23,28}
        smoke(this)
        this.ix = 1
        this.rs = (rnd(15)+5)/100
        this.hp = 2
        this.ix = rnd(100)>50 and 1 or -1
        this.an=
        {
            { -- walk
                8,
                {88,91}
            }
        }
    end
} riser = {
    init=function(this)

        this.m = {2,5,6,8,21,23,42}
        --if (this.mod==2) this.m = {2,5,6,8,9,15,21,22,23}
        this.ix = 1
        this.rs = .15
        this.hp = 2
        this.y-=1
        this.ix = rnd(100)>50 and 1 or -1
        this.an=
        {
            { -- dormant
                4,
                {60,60}
            },
            { -- rise
                1,
                {60,63}
            },
            { -- wait
                4,
                {63,63}
            }
            ,
            { -- sink
                4,
                {62,62}
            }
        }
    end
} dropper = {
    init=function(this)
        this.m,this.ix,this.rs,this.hp,this.rg = {2,5,6,8,9,21,22,23,28,43},rnd(100)>50 and 1 or -1,(rnd(15)+5)/100,1,-1
        smoke(this)
        this.an=
        {
            { -- walk
                8,
                {120,123}
            }
        }
    end
} hopper = {
    init=function(this)
        this.m,this.rs,this.js,this.hp={2,5,6,8,16,21,22,23},.5,1,1
        if (this.mod==3) then
            this.f = -1
            this.inx+=4
        end
        smoke(this)
        this.iny+=4
        this.an=
        {
            { --idle
                0,
                {128,128}
            },
            { -- jump
                3,
                {129,131}
            },
            { -- fall
                1,
                {131,131}
            },
            { --lob
                10,
                {168,168}
            }
        }
    end,
} flyer ={
    init=function(this)
        this.m,this.kb,this.hp,this.ix,this.iy,this.rs={12,2,5,6,8,9,14,13,21,22,23},false,2,rnd(100)>50 and 1 or -1,rnd(100)>50 and 1 or -1,.2
        smoke(this)
        this.an=
        {
            { --flying
                2,
                {132,135}
            }
        }
    end
} waver = {
    init=function(this)

        this.m = {5,17,21,22,23}--6,8,9,17,21,22,23,28}
        --if (this.mod==2) this.m = {2,5,6,8,9,15,21,22,23}
        this.rs = .4
        this.hp = 1
        this.ix = _g.p1.x > this.x and 1 or -1
        this.f = _g.p1.x < this.x and 1 or -1
        this.life=1000
        this.s=true
        this.y = _g.p1.y + rnd(16)-8
        smoke(this)
        this.an=
        {
            { -- walk
                16,
                {137,138}
            }
        }
    end
} ship={
    init=function(this)
        this.m,this.act={5,20,25},false
        this.y+=8
        this.an=
        {
            { 
                4,
                {42,42}
            }
        }

    end
} 
spawnables = 
{
    {message,4,4,1},     --1  <^
    {message,4,4,2},     --2  ^^
    {message,4,4,3},     --3  ^>
    {message,4,4,4},     --4  <
    {message,4,4,5},     --5  >
    {message,4,4,6},     --6  <v
    {message,4,4,7},     --7  vv
    {message,4,4,8},     --8  v>
    {beacon,4,4,1},      --9 -- save beacon
    {push,8,8,1},        --10
    {pickup,4,4,1},      --11 --sword
    {pickup,4,4,2},      --12 --dodge roll
    {pickup,4,4,3},      --13 --doublejump
    {pickup,4,4,4},      --14 --reserved
    {pickup,4,4,5},      --15 --bomb bag
    {pickup,4,4,6},      --16 --float bombs
    {pickup,4,4,7},      --17 --strength glove
    {pickup,4,4,8},      --18 -- maxhp up
    {pickup,4,4,9},      --19 -- max bombs up
    {pickup,4,4,10},     --20 -- restore hp
    {beacon,4,4,2},      --21 -- walker emitter
    {riser,4,8,1},       --22 --riser
    {dropper,4,4,1},     --23 --dropper
    {beacon,4,4,3},      --24 --dropper emitter
    {hopper,4,4,1},      --25 --hopper
    {beacon,4,4,4},      --26 --hopper emitter
    {flyer,4,4,1},       --27 --flyer
    {pickup,4,4,13},     --28 --health
    {pickup,4,4,14},     --29 --bomb pickup
    {beacon,4,4,5},      --30 --flyer emitter
    {beacon,4,4,6},      --31 --waver emitter
    {ship,8,8,1},        --32 --ship
}

particles = {}
function init_particle(x,y,sx, sy, r, c, d, h)
    local par = {
        x = x,
        y = y,
        sx = sx,
        sy = sy,
        r = r,
        c = c or 7,
        d = d or .1, -- diminish speed
        h = h or false -- does this particle hurt?
    }
    par.update=function()
        par.x+=par.sx
        par.y+=par.sy
        if (par.r>0) par.r-=par.d
        if (par.r<=0) del(particles, par)
        if (h) par.explode(par)
    end
    par.draw=function()
        circfill(par.x, par.y, par.r, par.c)
    end
    par.explode=function(this)
        local x,y,cr,p1 = this.x,this.y,this.r, _g.p1
        foreach(objects, function(obj)
            if check_hits(
                x,
                y,
                r,
                r,
                obj.x,
                obj.y,
                obj.w,
                obj.h
            ) and obj.ifr == 0 
            and obj.s
            and obj.type ~= pickup
            then
                obj.ifr= obj.mif
                obj.pi = true
                if (obj.type~=push) obj.sy = -1.25
                obj.hp -= 2
                if (obj.type == beacon and obj.act == false) obj.hp -= 1000
            end
        end)
        bounds = 
        {
            { x-cr, y-cr },
            { x+cr, y-cr },
            { x-cr, y+cr },
            { x+cr, y+cr },
            { x, y-cr },
            { x, y+cr },
            { x-cr, y },
            { x+cr, y }
        }
            

        for k, v in pairs(bounds) do
            if fget( mget( flr(v[1]/8), flr(v[2]/8) ), 7 ) then
                mset( flr(v[1]/8), flr(v[2]/8), 0 )
                for i=1, 6 do
                    local sx,sy,r,c = rnd(2)-1,rnd(2)-1,rnd(8)+4,rnd(100) > 50 and 6 or 7
                    --x,y,sx, sy, r, c, d, h
                    init_particle(flr(v[1]), flr(v[2]), sx, sy, r, c, 1, false)
                end
            end
            
        end
    end
    add(particles, par)
    return par
end 
--

function _init()end

function _update60()
    --key released!
    for k,v in pairs(input) do
        if (not btn(v[1]) and v[3]) v[2] = true 
        v[3] = false
    end

    if _g.s==0 then
play(1)
if btn(input.o[1]) and btn(input.x[1]) then
        input.o[2],input.x[2] = false,false
        music(-1)
    if dget(0) ~= 0 then 
        load_last_save() 
    else
        save_game()
        load_last_save()
    end
    --[[save_game()
    load_last_save()]]
end
menuitem(1,'clear save data', function() 
    for i=0, 63 do
        dset(i,0)
    end
end)

    elseif _g.s==1 then
_g.hlp,_g.bl='',get_beacons()
foreach(objects, function(obj)
    --only update if object is reasonably near the player
    if (
        abs(_g.camx+64-obj.x)<128 and
        abs(_g.camy+64-obj.y)<128
    ) or obj.ag
    then
        obj.update(obj)
    end
end)

foreach(particles, function(par)
    par.update(par)
end)

if _g.pd then
    _g.dcdt-=1
    if _g.dcdt == 0 then
        player_dead()
    end
end

if _g.bl==0 then
    play(4)
    countdown() 
end

menuitem(1, 'load last save', function()
    objects={} 
    load_last_save() 
end)
    elseif _g.s==2 then
objects,particles,_g.pd,_g.t,_g.tf,_g.dcdt = {},{},false,_g.mtr,60,120
play(2)
if btn(input.o[1]) and btn(input.x[1]) then
    input.o[2],input.x[2] = false,false
    music(-1)
if dget(0) ~= 0 then 
    load_last_save() 
else
    save_game()
    load_last_save()
end
--[[save_game()
load_last_save()]]
end
menuitem(1,'clear save data', function() 
for i=0, 63 do
    dset(i,0)
end
end)
    elseif _g.s==4 then

if btn(input.o[1]) or btn(input.x[1]) then
    if (btn(input.o[1])) input.o[2] = false
    if (btn(input.x[1])) input.x[2] = false
    _g.s=1
    _g.msg = ''
    --_g.lore = ''
    music(3)
end     end

    if (_g.msg ~= '') _g.s=4
    
    --previous frame keys down
    for k,v in pairs(input) do
        v[3] = btn(v[1])
    end
    
    --[[_g.debug = ''
    for i=0, 63 do
        _g.debug = _g.debug..dget(i)..','
        if(i%10==0 and i~=0) _g.debug = _g.debug..'\n'
    end
    --_g.debug = dget(16)]]
end

function _draw()
    cls()
    
    if _g.s==0 then
spr(43, 40, 16, 5, 1)
spr(59, 80, 16, 1, 1)

color(7)
print('\x8e+\x97: play',42,60)
color()

print('2018 BRADLEY ELLIOTT', 2, 121, 1)
print(_g.v, 90, 121, 1)     elseif _g.s==1 or _g.s==4 then
if _g.s==4 then
    dim_pal = {0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1}
    for i=0, 15 do
        c = i>5 and 1 or 0
        pal(i, c)
    end
end
camera(_g.camx, _g.camy)
map(0, 0, 0, 0, 128, 128, 3)
foreach(objects, function(obj)
    obj.draw(obj)
end)

foreach(particles, function(par)
    par.draw(par)
end)

map(0, 0, 0, 0, 128, 128, 16)

if (_g.hlp ~= '') print(_g.hlp, _g.p1.x-1.5, _g.p1.y-8,7)

camera()

draw_ui()

color(7)
if _g.bl==0 then 
    if (_g.t >= 0) print('defense systems activated\nget back to the ship! '.._g.t, 6,50) else print(0, 10,50)
end
if _g.eg ~= '' then
    sspr( 92, 4, 4, 4, 5, 16, 4, 4 , false, false )
    print(_g.eg, 12,15)
end

print(_g.debug, 5,30)
color()     elseif _g.s==2 then
color(7)
print(_g.dt, 24, 16)
print('\x8e+\x97: continue', 42, 60)
color()

    end
    if _g.s==4 then

--local msg_lines,lore_lines = flr(#_g.msg/30)+1, flr(#_g.lore/30)+1
local msg_lines = flr(#_g.msg/30)+1
cursor(4,64-((msg_lines)*2*6/2))
pal()
color(13)
--[[for i=0, lore_lines-1 do
    local substr=sub(_g.lore, i*30, i*30+29)
    --print('                              ')
    print(substr)
end]]
color(7)
for i=0, msg_lines-1 do
    local substr=sub(_g.msg, i*30, i*30+29)
    print('                              ')
    print(substr)
end
    end

    draw_fade()
    
    --print(_g.debug, 8, 16, 7)

end