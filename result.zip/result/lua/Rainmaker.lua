-- rainmaker
-- benjamin / castpixel

xmax=16*6  
ymax=16*4
di4={1,0,0,1,-1,0,0,-1}
bloom=6

function _init()
 t=0
 ft=0
 jump_max=1
 jump=1
 ents={}
 supp={}
 erase={}
 flowers={}
 freezes={}
 
 stars=0
 lightning=0
 flower=0 
 timer=99
 jumping=false
 col_morph=5
 music(2)
 
 for i=0,xmax*ymax-1 do  
  supp[i+1]=0
  x=i%xmax
  y=flr(i/xmax)  
  flowers[x+1]={ 
   n=0,
   t=rand(10)
  }
  fr=mget(x,y)
  
  if fr>32 then

   if fr==106 then
    e=mke(fr,x*8+4,y*8+4)
    e.layer=2   
    e.upd=upd_spark
    e.px=x
    e.py=y
   else
    spawn_bonus(x,y,fr-64)
   end
   mset(x,y,0)
  end
  
  check_cloud_border(x,y)
 end
 
 hero=mke(32,360,-64)
 --hero=mke(32,360,384)
 hero.we=0.5
 hero.we=0.07
 hero.ray=5
 hero.upd=upd_hero
 intro=0
 
 rectfill(0,0,128,128,0)
 --cls()
 title="rainmaker" 
 print(title,0,0,7)
 tm=#title*4
 tts={}
 ttd={}
 for n=0,tm*5-1 do
  tts[n+1]=pget(n%tm,flr(n/tm))
  ttd[n+1]=rnd(256)
 end
 cls()

end

function start_game()

 ready=false
 intro=nil
 fdt=min(t,128)
 timer=99
 hero.we=0.5
 music(-1,1500)
 col_morph=nil
end

function draw_title(t)
 pal() 
 k=0  
 for k=0,tm*5-1 do
  n=tts[k+1]
  px=k%tm
  py=flr(k/tm)
  sz=min(((t+4)/128)*2+0.1,2)
  ec=max(1-(t-108-px/2)/8,0)
  s=3
  l=0
  if n>=7 then
   if (rnd(48)<1 or ec==0 )  and n<11 then
    tts[k+1]+=1
   end
   col=sget(min(n-4,6),24)
   delta=ttd[k+1]
   an=((t+px+py/2)%120)/120
   x=4+px+cos(an)*8*ec
   y=2+py+sin(an)*3*(ec)
   x+=(delta%16)*ec
   y+=flr(delta/16)*ec
   circfill(x*s,y*s,sz,col)
  end 
  k+=1
 end

 
end

function upd_spark(e)

 di=1
 if e.gdi then
  di=(e.gdi+1)%4
 else
		seek_anchor(e)
 end
 
 
 d=gdi(di)  
 
 -- check touch ground
 touch=0
 for i=0,1 do
  nx=e.px+d.x*i
  ny=e.py+d.y*i
  if psld(nx,ny,e.gdi) then
   touch+=1 
  end
 end
 if touch==0 then
  kill(e)
  spawn_bonus(e.px,e.py,1)
  exp=mke(0,e.x,e.y)
  exp.dre=explode
  exp.life=10
  sfx(19)
  dst=dist(hero,e)
  an=atan2(ddx,ddy)
  pow= max(0,1-dst/64)*24
  hero.vx=cos(an)*pow
  hero.vy=sin(an)*pow  
 end

 kt=t%8
 if kt==0 then
  e.px+=d.x
  e.py+=d.y
  if e.gdi and psld(e.px,e.py,di) then
   e.gdi=(e.gdi+1)%4 
  end   
  if e.gdi and not psld(e.px,e.py,e.gdi) then
   e.gdi=(e.gdi-1)%4
  end   
 end  
 
 e.x=e.px*8+d.x*kt+4
 e.y=e.py*8+d.y*kt+4
 e.fr=103+t%4 
 ddx=e.x-hero.x
 ddy=e.y-hero.y
 if abs(ddx)+abs(ddy) < 8 then
  sfx(34)
  pause(spark_death)
  col_morph=0
  hero.hfr=14 
  hero.vy=-1
  hero.upd=nil
  hero.layer=2
  hero.we=0.1
  hero.frict=1
 end
end

function explode(e)
 cc=1-e.life/10
 for i=0,2 do
  circ(e.x,e.y,cc*160-i*32,sget(i,24))
 end
 
 --irc(e.x,e.y,cc*128,7)
 
 
end

function rand(n)
 return flr(rnd(n))
end

function spawn_bonus(x,y,type)
 b=mke(64+type,x*8+4,y*8+4)
 b.float=true
 b.upd=function(e)
  e.flh=nil
  if t%16<2 then e.flh=12 end  
  dddd=dist(hero,e)
  if dist(hero,e)<8 then
   grab(e.fr-64)
   sfx(36)
   del(ents,e)
  end  
 end
end

function grab(type)

 if type==0 then
  stars+=1
 
 elseif type==1 then
  lightning+=1
 elseif type==2 then
  sci=mke(73,-4,124)
  sci.layer=3
  sci.upd=upd_cut
 elseif type==3 then
  jump_max+=1
 elseif type==4 then
  e=mke(0,0,0)
  e.upd=function()
   if t%2==0 and timer<99 then
    timer+=1
    sfx(16)
   end
  end
  e.life=50
  
  --timer=min((timer+25),99)
 end
end

function pause(f)
 ft=0
 add(freezes,f)
 parts={}
end


function upd_cut(e)

 -- anim scissor
 if ft%2==0 then
  sci.fr+=1
  if sci.fr==76 then 
   sci.fr-=3
  end
 end 
 sci.x+=3 
 sx=flr((sci.x+hero.x-64)/8)
 fl=flowers[1+sx]

 if fl and  fl.n>= bloom then
  
  sfx(38)
  flower+=1
  e=mke(fl.t+83,sci.x,sci.y+2-fl.n)
  e.we=-0.1
  e.layer=3
  e.n=fl.n
  e.blink=true
  e.life=14
  e.dre=function(e)
   line(e.x,e.y+2,e.x,e.y+e.n-1,11)
  end
  add(parts,e) 
  fl.n=1  
 end

 
 --for e in all(parts) do
 -- upe(e)
 --end
 
 if sci.x>132 then
  kill(sci)
  del(freezes,upd_cut)
 end
 
end

function dist(a,b)
 ddx=a.x-b.x
 ddy=a.y-b.y
 return abs(ddx)+abs(ddy)
end

function seek_anchor(e)
 for di=0,3 do
  if psld(e.px,e.py,di) then    
   e.gdi=di
   e.lost=0
  end
 end
end






function spark_death()
 
 if col_morph and ft<8 then
  col_morph=1-col_morph
 else  
  col_morph=nil
  upe(hero)
  d=ft-20
  if d>0 then
   col_morph=2+d/4
   if d>16 then
    --freeze=function() end
    run()
   end
  end
 end  
end

function fall_fade()
 if ft>64 then
  col_morph=3+flr((ft-64)/16)
 end
 
 if ft==127 then
  run()
 end
end

function psld(px,py,di)
 if di then
  local d=gdi(di)
  px+=d.x
  py+=d.y
 end
 return sld(px*8,py*8,false)
end

function gdi(di)
 return { x=di4[1+di*2], y=di4[2+di*2] }
end



function mke(fr,x,y)
 e={
  x=x, y=y, fr=fr, vis=true,
  vx=0,vy=0,frict=1,flip=false,
  we=0,ray=4,layer=1, size=1
 }
 add(ents,e)
 return e
end

function upd_hero(e) 
 

 -- phys
 ray=e.ray 
 local l=e.x-ray
 local tp=e.y-ray
 local r=e.x+ray-1
 local b=e.y+ray-1
 ng=sld(e.x,b+1) or sld(l,b+1) or sld(r,b+1)
 if ng != e.ground then
  e.ground=ng
  if ng then
   jump=0
  end
 end
  
 --
 e.vx*=0.95
 function move(inc)
  dx=mid(-3,dx+inc*2,3)
  e.walking=true
  if (inc==1)==e.flip then
   e.flip= not e.flip
  end
 end 
 --ready
 if intro then
  sum=0
  for i=0,5 do
   if btn(i) then sum+=1 end
  end
  if sum>0 then
   if ready then
    start_game()
   end
  else
   ready=true
  end
  
 else
  control(e)
	end
 
 e.fr=nil
 e.hfr=0
 e.frict=0.92
 
 if e.grip and not e.ground then
  e.hfr=13
 elseif e.ground then    
  if e.walking then   
   e.hfr=flr((t%28)/4)  
  end
 else
  e.hfr=11
  if e.vy>-1 then
   e.hfr=12
   if e.vy>1 or intro then
    e.hfr=8+flr((t%12)/4)
   end
  end
 end

 -- bounce x
 s=sgn(dx)
 cx=l
 if s>0 then cx=r end  
 e.grip=nil
 xcol=true
 while sld(cx+dx,tp) or sld(cx+dx,b) do
  dx-=s
  e.vx=0
  e.grip=s
  e.vy*=0.9
 end 
 xcol=false
 
 -- bounce y
 s=sgn(dy)
 cy=tp
 if s>0 then cy=b end  
 while sld(l,cy+dy) or sld(r,cy+dy) do
  dy-=s
  e.vy=0
 end 
 
end

function control(e)
 e.walking=nil
 if btn(0) then move(-1) end
 if btn(1) then move(1) end
 if btn(4) and e.vy>=0 then  
  if jump<jump_max or e.ground or e.grip then
   jump+=1
   e.vy=-8
   dy=e.vy
   sfx(33)
   if e.grip and sld(e.x+e.grip*5,e.y-5) then
    e.vx-=e.grip*6
    dx-=e.grip*6
   end  
  end 
	end
end


function check_cloud_border(x,y)
 if mget(x,y)==16 then
  return
 end 
 n=0
 for di=0,3 do
  local px=x+di4[di*2+1]
  local py=y+di4[di*2+2]
  if mget(px,py)==16 then
   n+=2^di
  end
 end
 mset(x,y,n) 
end



function upe(e)
 
 e.ox=e.x
 e.oy=e.y
 e.vy+=e.we
 e.vx*=e.frict
 e.vy*=e.frict 
 dx=e.vx
 dy=e.vy
 if e.upd then e.upd(e) end
 --if e.phys then
 -- upd_phys(e)
 --end
 
 e.x+=dx
 e.y+=dy
 
 if e.life then
  e.life-=1
  if e.blink then
   e.vis= not(e.life<=8 and ft%3==0)
  end
  if e.life<=0 then
   kill(e)
  end
 end
 
end
function kill(e)
 if e.on_death then e.on_death(e) end
 del(ents,e)
end

function is_in(px,py)
 return px>=0 and py>=0 and px<xmax and py<ymax
end

function sld(x,y,kl)
 if kl==nil then kl=true end 

 px=flr(x/8)
 py=flr(y/8)
 if not is_in(px,py) then
  return false 
 end
 
 -- here
 pi=1+py*xmax+px 
 solid=mget(px,py)==16  
 if kl and solid and not intro then  
  burst(px,py)
 end
 return solid or supp[pi]>0
end

function loop(f)
 e=mke(nil,0,0)
 e.upd=f
 
end

function burst(px,py)
 pi=1+py*xmax+px 
 if supp[pi]!=0 then return end
 sfx(32)
 add(erase,pi)
 supp[pi]=6
 if xcol and hero.ground and mget(px,py-1)!=16 then 
  supp[pi]=0
 end
 
 mset(px,py,0)
 check_cloud_border(px,py)
 for di=0,3 do
  check_cloud_border(px+di4[1+di*2],py+di4[2+di*2])
 end  
 
 for i=0,3 do
  pop(px,py)
 end


 -- raindrop
 py+=1
 while mget(px,py)==16 do
  py+=1
 end
 e=mke(102,px*8+rnd(8),py*8)
 e.we=(5+rnd(5))/100
 e.frict=0.98
 e.life=36
 e.on_death=function(e)
  local i=1+flr(e.x/8)
  flowers[i].n+=1
 end
 
end

function upd_erase()
 for pi in all(erase) do
  n=supp[pi]
  supp[pi]=n-1
  
  px=(pi-1)%xmax
  py=flr((pi-1)/xmax)
  
  if n<6 then
   pop(px,py) 
  end
  
  if supp[pi]<0 then
   del(erase,pi)
  end
 end
end

function pop(px,py)

 --log(#ents)
 if #ents>128 and t%2==0 then
  return 
 end

 e=mke(0,px*8+rnd(8),py*8+rnd(8))
 k=flr(rnd(2))
   
 e.we=-0.1-rnd(0.2)
 e.frict=0.98
 e.life=8+rnd(8)
 e.layer=k*2   
 e.col=14+k
 e.dre=function(e)
  circfill(e.x,e.y,1+e.life/4,e.col)
 end 
end

function _update()
 ft+=1
 if #freezes>0 then
  freezes[1]()
  return
 end 
 t+=1
 if t%24==0 and timer>0 then
  timer-=1
  if timer==0 then
   for e in all(ents) do
    if e.fr==68 then
     e.fr-=2
    end
   end
  end
 end
 
 -- fade
 if falling then  
  fall_fade()
  
 elseif hero.y>ymax*8+64 then
  falling=true
  music(11)
  ft=0
 elseif col_morph then
  if t%32==0 then
   col_morph-=1
   if col_morph==1 then
    col_morph=nil
   end
  end  
 end

 
 upd_erase()
 foreach(ents,upe) 
 
 --check_win

 win_conditions={
  stars>=3,
  lightning>=3,
  flower>=20,
  timer>0
 }
 
 if not wray then
  win=0
  for w in all(win_conditions) do
   if w then win+=1 end
  end
 
  if win>=3 then 
  
   pause(win_game)
   sfx(17)
   wray=0
   rain={}
   for i=0,64 do
    p={}
    p.x=rnd(128)
    p.y=rnd(128)
    p.c=i/32
    add(rain,p)
   end
  end
 end
end   

function win_game()
 
 if ft>40 then
  col_morph=min(7+(ft-40)/8,11)
 end
 
 if col_morph==11 and _draw!=draw_congrat then
  _draw=draw_congrat
  music(0)
  ft=0
 end 
 
 for i=0,5 do
  if ft>100 and btnp(i) then
   run()
  end
 end
 
end

function draw_congrat()
 
 col=sget(0+mid(0,ft/4-8,3),24)
 rectfill(0,0,128,128,col)   
 for p in all(rain) do 
  vx=2*(1+p.c)
  vy=4*(1+p.c)
  col=6
  if p.c>1 then col=7 end
  line(p.x-8,p.y-8,p.x+vx-8,p.y+vy-8,col)
  p.x=(p.x+vx)%136
  p.y=(p.y+vy)%136      
 end
 by=max(128-ft*2,24)+cos((ft%40)/40)*2
 sspr(104,8,24,40,52,by)
 
 if ft>60 then
  for k=0,1 do
   col=sget((ft%16)/2,25)
   if k==0 then col=1 end
   print("congratulations",37-k,93-k,col)
  end
 end
end

function _draw()
 cls()
 pal()
 if col_morph then
  for i=0,15 do
   pal(i,sget(96+i,48+col_morph))
  end
 end

 -- sky
 rectfill(0,0,128,128,13) --13
 
 -- bg
 for dx=0,1 do for dy=0,1 do
  x=(-hero.x/2+t/2)%256
  y=(-hero.y/2)%128
  x-=dx*256
  y-=dy*128
  map(96,0,x,y,32,16)  
 end end
 
 -- camera
 cx=hero.x-64
 cy=8+hero.y-64  
 camera(cx,cy)
 
 bg=true
 layer=0
 foreach(ents,dre)
 layer=1
 foreach(ents,dre)

 for x=0,xmax-1 do
  py=gdy(x*8)
  map(x,0,x*8,py,1,ymax)
 end
 
 layer=2
 foreach(ents,dre) 
 
 
 --
 if spark then
  circ(spark.px*8,spark.py*8,ft*16,7)
 end
 
 camera()
 
 
 -- inter 
 if not intro then  
  camera(cx,0)
  for x=0,xmax-1 do
   fl=flowers[x+1]
   n=fl.n
   spr(115+min(n,6),x*8,120)
   bx=x*8+4
   top=126-n
   bdx=sin(((ft+x)%40)/40)*sqrt(n/4)
   line(bx,126,bx+bdx,top,11)
   fr=83+fl.t
   if n>=bloom then
    if n==bloom then fr=107 end
    spr(fr,bx+bdx-4,top-4)
   end
  end
  camera() 
  draw_inter()
	 if fdt then
   fdt-=1
   draw_title(fdt)
   if fdt==0 then fdt=nil end
  end  
  
 else
  draw_title(t) 
 end
 
  
 --for i=0,jump_max-2 do
 -- fr=69
 -- if jump>=i+2 then
 --  fr+=1
 -- end
 -- spr(fr,120-i*8,1)
 --end
 
 -- front layer (no cam)
 layer=3
 foreach(ents,dre)  
 
 pal()
 
 y=0
 for msg in all(log_msg) do  
  print(msg,0,y,7)
  y+=8
 end 
end

function draw_inter()
rectfill(0,0,128,9,13)
 lim={stars,lightning}
 for i=0,1 do
  x=1
  if win_conditions[i+1] and win>=3 then 
   apal(8+ft%7)
  end
  for k=0,2 do
   px=x
   if i==1 then
    px=120-px
   end   
   fr=69+i   
   if k<lim[i+1] then
    fr+=2
   end
   spr(fr,px,1)
   x+=10
  end
  apal()
 end
 
 
 count={flower,timer} 
 x=50
 for k=0,1 do  
  if win_conditions[k+3] and win>=3 then 
   apal(8+ft%7)
  end 
  n=""..count[k+1]
  if #n==1 then n="0"..n end
  print(n,x,3,7)
  spr(99+k,x+6,1)
  x+=16
  apal()
 end
 
 jmax=jump_max-jump
 for i=1,jmax do
  spr(101,57+i*6-jmax*3,9)
 end

end


function pr(str,x,y)
  for k=0,1 do  
   print(str,x,y+1-k,2+5*k) 
  end
end

function gdy(x)
 k=60
 --return sin(((t+flr(x/8)*2)%k)/k)*3
 return 0
end

function dre(e)
 if e.layer != layer or not e.vis then return end
 if e.dre then e.dre(e) end
 x=e.x-e.ray
 y=e.y-e.ray
 fr=e.fr
 if e.walking and fr==49 then
  y-=1
 end
 y+=gdy(x)
 if e.float then
  y+=cos((t%40)/40)*2-2
 end
 if e.flh then
  apal(e.flh)
 end
 if fr then
  spr(fr,x,y,e.size,e.size,e.flip)
 end
 if e.hfr then
  
  hpx=e.hfr%8
  hpy=flr(e.hfr/8)
  if e.hfr==7 or e.hfr==9 then 
   y-=1 
  end
  sspr(8+hpx*12,8+hpy*12,12,12,x-2,y-3,12,12,e.flip)
  
 end 
 
 apal()
end

function apal(n)
 if col_morph then return end
 if n==nil then pal() return end
 for i=0,15 do
  pal(i,n)
 end
 
end

log_msg={}
function log(str)
 add(log_msg,str)
 if #log_msg > 14 then
  del(log_msg,log_msg[1])
 end
end