--see https://www.lexaloffle.com/bbs/?tid=29028

--tay marching from:http://jamie-wong.com/2016/07/15/ray-marching-signed-distance-functions/

---------------------------rgb routines by electricgryphon-----------------------------------
---------------------------------------------------------------------------------------------

pico_palette={
{0x0.0,0x0.0,0x0.0},
{0x.20,0x.33,0x.7b},
{0x.7e,0x.25,0x.53},
{0x.00,0x.90,0x.3d},
{0x.ab,0x.52,0x.36},
{0x.34,0x.36,0x.35},
{0x.c2,0x.c3,0x.c7},
{0x.ff,0x.f1,0x.e8},
{0x.ff,0x.00,0x.4d},
{0x.ff,0x.9b,0x.00},
{0x.ff,0x.e7,0x.27},
{0x.00,0x.e2,0x.32},
{0x.29,0x.ad,0x.ff},
{0x.84,0x.70,0x.a9},
{0x.ff,0x.77,0x.a8},
{0x.ff,0x.d6,0x.c5}
}

extended_palette={}
function generate_extended_palette()
	for c1=0,15 do
		for c2=c1,15 do
			--split_plot(c1*2,c2*2,c1,c2)
			
			local dr= (pico_palette[c1+1][1]-pico_palette[c2+1][1])
			local dg= (pico_palette[c1+1][2]-pico_palette[c2+1][2])
			local db= (pico_palette[c1+1][3]-pico_palette[c2+1][3])
			
			local dist=sqrt(dr*dr+dg*dg+db*db)
			
			--magic number to keep flashing from being too bad
			if(dist<.7)then
			
				
				local r= (pico_palette[c1+1][1]+pico_palette[c2+1][1])/2
				local g= (pico_palette[c1+1][2]+pico_palette[c2+1][2])/2
				local b= (pico_palette[c1+1][3]+pico_palette[c2+1][3])/2
				
				add(extended_palette,{r,g,b,c1,c2})
			end
		end
	end
end

clut={}
function generate_clut()

	for r=0,0xf do
		clut[r]={}
		for g=0,0xf do
			clut[r][g]={}
			for b=0,0xf do
				c1,c2=nearest_extended_palette(r/16,g/16,b/16)
				clut[r][g][b]={c1,c2}
			end
		end
	end
end



--return the nearest palette color
--and return the error in r,g,b 
function nearest_palette(red,green,blue)
	local min_dist=10

	for i=1,16 do
		local red_error=pico_palette[i][1]-red
		local green_error=pico_palette[i][2]-green
		local blue_error=pico_palette[i][3]-blue

		local dist=red_error*red_error+green_error*green_error+blue_error*blue_error
		if(dist<min_dist)then
			min_dist=dist min_color=i
		end
	end
	return min_color-1
end

function nearest_extended_palette(red,green,blue)
	local min_dist=10

	for i=1,#extended_palette do
		local red_error=extended_palette[i][1]-red
		local green_error=extended_palette[i][2]-green
		local blue_error=extended_palette[i][3]-blue

		local dist=red_error*red_error+green_error*green_error+blue_error*blue_error
		if(dist<min_dist)then
			min_dist=dist
			min_index=i
		end
	end
	return extended_palette[min_index][4],extended_palette[min_index][5]
end
			
local bayer={{ 0/64,32/64,8/64,40/64,2/64,34/64,10/64,42/64},
{48/64,16/64,56/64,24/64,50/64,18/64,58/64,26/64},
{12/64,44/64,4/64,36/64,14/64,46/64,6/64,38/64},
{60/64,28/64,52/64,20/64,62/64,30/64,54/64,22/64},
{ 3/64,35/64,11/64,43/64,1/64,33/64,9/64,41/64},
{51/64,19/64,59/64,27/64,49/64,17/64,57/64,25/64},
{15/64,47/64,7/64,39/64,13/64,45/64,5/64,37/64},
{63/64,31/64,55/64,23/64,61/64,29/64,53/64,21/64}}



--function color_bayer_plot(x,y,r,g,b,w)
--	local red_error=.5-abs(r-.5)
--	local green_error=.5-abs(g-.5)
--	local blue_error=.5-abs(b-.5)
--	if(w)then
--	rectfill(x,y,x+w,y+w,nearest_palette(r+(bayer[x%8+1][y%8+1]*red_error)-red_error/2,
--							g+(bayer[x%8+1][y%8+1]*green_error)-green_error/2,
--							b+(bayer[x%8+1][y%8+1]*blue_error)-blue_error/2))
--	else
--	pset(x,y,nearest_palette(r+(bayer[x%8+1][y%8+1]*red_error)-red_error/2,
--							g+(bayer[x%8+1][y%8+1]*green_error)-green_error/2,
--							b+(bayer[x%8+1][y%8+1]*blue_error)-blue_error/2))
--	end
--end

g_color_address=0
g_display_address=0x6000


function clear_memory_screen()
	--memset(g_display_address,0,0x2000)
	--reload (0x0000,0x0000,0x2000)
	memset(0x200,0,0x1e00)
end

function set_base_color(color)
	g_color_address=flr(color/4)*128+(color%4)*16
end

function shade_fill(sx,y,ex,color_brightness)

	sx=flr(sx)
	ex=flr(ex)
	y=flr(y)

	--sx=mid(sx,0,127)
	--ex=mid(ex,0,127)
	--sy=mid(sy,0,127)
	if(sx>ex)sx,ex=ex,sx
	
	if(sx>127)return false
	if(ex<0)return false
	if(y>127)return false
	if(y<0)return false
	
	sx=max(0,sx)
	ex=min(127,ex)
	
	if(y%2==1)color_brightness+=64
	local v=peek(g_color_address+color_brightness)
	local start_a=g_display_address+y*64+flr(shr(sx,1))
	local len=flr(shr(ex,1))-flr(shr(sx,1))
	if(sx%2==1)then
		poke(start_a,bor(band(peek(start_a),0x000f),band(v,0x00f0)))
		memset(start_a+1,v,len-1)
	else
		memset(start_a,v,len)
	end

	local end_address=start_a+len
	if(ex%2==0)then
		poke(end_address,bor(band(peek(end_address),0x00f0),band(v,0x000f)))
	else
		poke(end_address,v)
	end
end


function color_bayer_plot(x,y,r,g,b,w)
	--rectfill(x,y,x+w,y+w,r*16)
	r=min(r,1)
	shade_fill(x,y,x,r*15)
end



function extended_color_bayer_plot(x,y,r,g,b)
	local red_error=.5-abs(r-.5)
	local green_error=.5-abs(g-.5)
	local blue_error=.5-abs(b-.5)
	
	r=r+(bayer[x%8+1][y%8+1]*red_error)-red_error/2
	g=g+(bayer[x%8+1][y%8+1]*green_error)-green_error/2
	b=b+(bayer[x%8+1][y%8+1]*blue_error)-blue_error/2
	
	r=mid(r,0,0x0.f)
	g=mid(g,0,0x0.f)
	b=mid(b,0,0x0.f)
	
	t=clut[shl(band(r,0x0000.f000),4)][shl(band(g,0x0000.f000),4)][shl(band(b,0x0000.f000),4)]

	--c1,c2=nearest_extended_palette(r+(bayer[x%8+1][y%8+1]*red_error)-red_error/2,
	--						g+(bayer[x%8+1][y%8+1]*green_error)-green_error/2,
	--						b+(bayer[x%8+1][y%8+1]*blue_error)-blue_error/2)

	split_plot(x,y,t[1],t[2])
end

function split_plot(x,y,c1,c2)
	sset(x,y,c1)
	c2=c2%16
	
	if(y<64)then
		adr=0x2000+flr(x/2)+y*64
	else
		adr=0x4300+flr(x/2)+(y-64)*64
	end
		val=peek(adr)
		if(x%2==0)then
			poke(adr,bor(band(val,0x00f0.0000),c2))
		else
			poke(adr,bor(band(val,0x000f.0000),shl(c2,4)))
		end

end

high_state=false
function flip_high_color()
	if(high_state==false)then
		memcpy( 0x6000, 0x0000, 0x2000)
		high_state=true
	else
		memcpy( 0x6000, 0x2000, 0x1000)
		memcpy( 0x7000, 0x4300, 0x1000)
		high_state=false
	end
end


function clear_high_color()
	memset(0x2000,0,0x1000)
	memset(0x4300,0,0x1000)
	memset(0x6000,0,0x2000)

end

------------------------------------------------------------vectors-----------------

-- vector addition is '+','-'
function v3_add(p1,p2)
  return {p1[1]+p2[1], p1[2]+p2[2], p1[3]+p2[3]}
end

function v3_sub(p1,p2)
  return {p1[1]-p2[1], p1[2]-p2[2], p1[3]-p2[3]}
end

-- unitary minus  (e.g in the expression f(-p))
function v3_unm(p)
  return {-p[1], -p[2], -p[3]}
end

-- scalar multiplication and division is '*' and '/' respectively
function v3_mul(s,p)
  return { s*p[1], s*p[2], s*p[3] }
end

function v3_div(p,s)
  return{ p[1]/s, p[2]/s, p[3]/s }
end

-- dot product is '..'
function v3_dot(p1,p2)
  return p1[1]*p2[1] + p1[2]*p2[2] + p1[3]*p2[3]
end

-- cross product is '^'
function v3_cross(p1,p2)
   return{
     p1[2]*p2[3] - p1[3]*p2[2],
     p1[3]*p2[1] - p1[1]*p2[3],
     p1[1]*p2[2] - p1[2]*p2[1]
   }
end

function v3_normalize(p)
  local l = v3_len(p)
  return({ p[1]/l,p[2]/l,p[3]/l})
  
  
end

function v3_translate(pt,x,y,z)
   pt[1] = pt[1] + x
   pt[2] = pt[2] + y
   pt[3] = pt[3] + z 
end



function v3_to_string(p)
	return(""..p[1]..","..p[2]..","..p[3])
end

local function sqr(x) return x*x end

function v3_len(p)
  return sqrt(p[1]*p[1] + p[2]*p[2] + p[3]*p[3])
end

function estimate_normal(p)
	normal = v3_normalize({
		scene_sdf({p[1]+epsilon,p[2],p[3]})-scene_sdf({p[1]-epsilon,p[2],p[3]}),
		scene_sdf({p[1],p[2]+epsilon,p[3]})-scene_sdf({p[1],p[2]-epsilon,p[3]}),
		scene_sdf({p[1],p[2],p[3]+epsilon})-scene_sdf({p[1],p[2],p[3]-epsilon})
	})
	return normal
end
------------------------------------end vectors------------------------------------------------





-----------------------------shapes---------------------------------------------------------

function sphere_sdf(p,s)
	return v3_len(p)-s
end

function box_sdf(p,b)
	return v3_len({max(0,abs(p[1])-b[1]),max(0,abs(p[2])-b[2]),max(0,abs(p[3])-b[3])})
end

function cheap_box_sdf(p,b)

	local x=abs(p[1])-b[1]
	local y=abs(p[2])-b[2]
	local z=abs(p[3])-b[3]
	
	return max(max(x,y),z)

end

function round_box_sdf(p,b,r)
	return v3_len({max(0,abs(p[1])-b[1]),max(0,abs(p[2])-b[2]),max(0,abs(p[3])-b[3])})-r
end

function plane_sdf(p,n)
	return v3_dot(p,n)
end

function ground_sdf(p,d)
	if(d>0) return(-p[2])
	return(p[2])
end

function torus_sdf(p,tx,ty)
	x1=sqrt(p[1]*p[1]+p[3]*p[3])-tx
	y1=p[2]
	return sqrt(x1*x1+y1*y1)-ty
end

function cylinder_sdf(p,r)

	return sqrt(p[1]*p[1]+p[3]*p[3])-r

end

function capped_cylinder_sdf(p,r,h)
	d=sqrt(p[1]*p[1]+p[3]*p[3])-r
	
	d=max(d,abs(p[2])-h)
	return d

end

function cone_sdf(p,r,h)

	qx = sqrt(p[1]*p[1]+p[3]*p[3])
	qy= p[2]
	
	tipx=qx
	tipy=qy-h
	
	len = sqrt(h*h+r*r)
	mantle_dir_x=h/len
	mantle_dir_y=r/len
	
	mantle=mantle_dir_x*tipx+mantle_dir_y*tipy
	d= max(mantle,-qy)
	
	projected = tipx*mantle_dir_y-mantle_dir_x*tipy
	
	if((qy>h) and (projected>len))then

		d=max(d,sqrt(tipx*tipx+tipy*tipy))
	end
	
	if((qx>r)and(projected>len))then
		local x=qx-r
		local y=qy
		d=max(d,sqrt(x*x+y*y))
	end
	
	
	return d
end

----------------------------transform------------------------------------------------

function	intersect_sdf(dist_a,dist_b)
	return max(dist_a,dist_b)
end

function	union_sdf(dist_a,dist_b)
	return min(dist_a,dist_b)
end

function difference_sdf(dist_a,dist_b)
	return max(dist_a,-dist_b)
end

function blend_sdf(dist_a,dist_b,k)
	h=mid(0.5+0.5*(dist_b-dist_a)/k,0,1)
	return lerp(dist_b,dist_a,h)-k*h*(1-h)
	
end

function op_rep(p,c)
	return{p[1]%c[1]-.5*c[1],p[2]%c[2]-.5*c[2],p[3]%c[3]-.5*c[3]}

end

--the item that you want to pattern should be in the -z location
function mod_polar(p,rep)
	angle =1/rep
	--p[1]-=1
	local a= atan2(p[1],-p[3])+angle/2
	local r= sqrt(p[3]*p[3]+p[1]*p[1])
	local c = flr(a/angle)
	--r=1
	a = a%angle- angle/2
	local px  =sin(a)*r
	local pz=cos(a)*r
	local py=p[2]
	
	return{px,py,pz}
end

function lerp(a,b,alpha)
  return a*(1.0-alpha)+b*alpha
end

function generate_matrix_transform(xa,ya,za)

	
	local sx=sin(xa)
	local sy=sin(ya)
	local sz=sin(za)
	local cx=cos(xa)
	local cy=cos(ya)
	local cz=cos(za)
	
	mat00=cz*cy
	mat10=-sz
	mat20=cz*sy
	mat01=cx*sz*cy+sx*sy
	mat11=cx*cz
	mat21=cx*sz*sy-sx*cy
	mat02=sx*sz*cy-cx*sy
	mat12=sx*cz
	mat22=sx*sz*sy+cx*cy

	return{ {mat00,mat01,mat02},
			{mat10,mat11,mat12},
			{mat20,mat21,mat22}
			}
end



function rotate_point(p,mat)	
	return {(p[1])*mat[1][1]+(p[2])*mat[2][1]+(p[3])*mat[3][1],(p[1])*mat[1][2]+(p[2])*mat[2][2]+(p[3])*mat[3][2],(p[1])*mat[1][3]+(p[2])*mat[2][3]+(p[3])*mat[3][3]}
end

function translate_point(p,v)
	return v3_sub(p,v)
end

function translate(p,t)
	x=p[1]+t[1]
	y=p[2]+t[2]
	z=p[3]+t[3]
	return {x,y,z}
end

function rotate_y(p,a)
	local x = p[1]*cos(a) - p[3]*sin(a)
	local z = p[3]*cos(a) + p[1]*sin(a)
	return {x,p[2],z}
end

---------------------------------begin trace--------------------------------------------------
sphere_list={}




k_screen_height=127
k_screen_width=127
k_screen_center_h=64
k_screen_center_v=64
k_max_steps=256
k_infinity=128
epsilon=.025
min_step=.03
k_fog=false

function trace_rays()
	local sx
	local sy
	local sz
	local x
	local y
	
	local sc
	
	
	
	local sz=1
	local w=0
	local count=0
	for j=0,1 do
		for i=0,1 do
			if(i==0 and j==0)then w=1 else w=0 end
			for sy=0+j,k_screen_height,2 do
				for sx=0+i,k_screen_width,2 do
					 ray={1.4*(sx-k_screen_center_h)/k_screen_width,1.4*(sy-k_screen_center_v)/k_screen_height,1.2}
					 ray=v3_normalize(ray)
					--
					--
					 depth,intersect_point=march_ray(ray,camera)
					if(depth<k_infinity)then
						--normal = estimate_normal(intersect_point)
						local r,g,b=shade(intersect_point,depth)
						color_bayer_plot(sx,sy,r,g,b,w)
					else

							color_bayer_plot(sx,sy,mid(0,1,sy/72),0,0,w)
							--pset(sx,sy,12)

					end
					--flip()
					count+=1
				end
				
				if(count>200)then count=0 flip() end
				
				
			end
			--flip()
			
		end
	end
		
end

function march_ray(direction,start_point)
	--if(start_point==nil)return k_infinity
	local depth=0
	local smallest_step=k_infinity
	
	--last_intersect_point={}
			
	for i=0,k_max_steps do
		 intersect_point=v3_add(start_point,v3_mul(depth,direction))
		local dist=scene_sdf(intersect_point)
		
		if(dist<smallest_step)smallest_step=dist
		
		if(dist<0)then
			return depth,last_intersect_point,smallest_step
		end
		
		if(dist<min_step)then
			return depth,intersect_point,smallest_step
		end
		
		
	
		depth+=dist
		
		if(depth>=k_infinity)then
			return k_infinity,last_intersect_point,smallest_step
		end
		last_intersect_point=intersect_point
	end
	
	return k_infinity,last_intersect_point,smallest_step

end

------------------------------shading-------------------------------------------------------


light_v=v3_normalize({.1,-.2,-.1})
ambient=.08
base_color=.8
specular_color=.8
fog_color=0x.cc
fog_depth=15

function	shade(intersect_point,depth)
	--if(intersect_point==nil)return 0,0,0
	local normal = estimate_normal(intersect_point)
	local shadow_ray = v3_mul(-1,light_v)

	
	--intersection_point={0,0,0}
	--figure out shadows
	local first_obst_dist,isect,smallest_step=march_ray(light_v,v3_add(intersect_point,v3_mul(.25,normal)))
	
	
	

	if(first_obst_dist<30)then
		shadow=.01
	else
	
		
		shadow=1
		--if(smallest_step<.25)then
		--	shadow=mid(smallest_step*4+.01,0,1)
		--end
	end
	

	local diffuse = max(v3_dot(normal,light_v),0)
	local half_direction = v3_normalize(v3_add(light_v,{0,0,-1}))
	local specular = min( max(v3_dot(half_direction,normal),0)^16,1)
	local bright = min(1,base_color*diffuse+specular_color*specular)
	local fog_dist=depth/fog_depth
	
	--k_infinity/depth)*fog_color+(1-k_infinity/depth)*bright
	
	bright*=shadow
	
	bright+=ambient
	if(k_fog)bright=lerp(bright,fog_color,fog_dist)
	
	
	
	return bright,bright,bright
	
end


---------------------------scene---------------------------------------------------------------


function init_scene_sdf()
	camera={0,-.5+rnd(.25),-6.5+rnd(.25)}
	box_rotate=generate_matrix_transform(rnd(.25),.125+rnd(.25),0)
	cam_matrix=generate_matrix_transform(-.125+rnd(.15),0,0)
	torus_transform=generate_matrix_transform(.15+rnd(.2),.4+rnd(.2),rnd(.25))
	cylinder_rotate=generate_matrix_transform(-.125,-.08,.05)
	flute_rotate=generate_matrix_transform(0,.125,0)
	eye_rotate=generate_matrix_transform(.25,0,0)
	
	twist_rotate=generate_matrix_transform(0,0,0)
	
	sponge_rotate=generate_matrix_transform(.03+rnd(.5),-.1+rnd(.5),0)
	
	g_sponge_scale=.75+rnd(.5)
	build_height= 2+rnd(2)
	build_rot=rnd(1)
	build_densityx=3+rnd(3)
	build_densityy=3+rnd(3)
	window_width=rnd(.2)+.2
	window_density=.8+rnd(.4)
	build_x=.3+rnd(.5)
	build_y=.3+rnd(.5)
	
	t_rep_x=rnd(3)+4
	t_rep_y=rnd(3)+4
	
	
end


function carb_sdf(p)
	cylinder1=capped_cylinder_sdf(p,.75,.5)
	cylinder2=capped_cylinder_sdf(p,.6,.75)
	cylinder3=capped_cylinder_sdf(p,.3,1.1)
	
	cylinder=blend_sdf(cylinder1,cylinder2,.5)
	cylinder=blend_sdf(cylinder,cylinder3,.5)
end

function column_sdf(p)




		top=capped_cylinder_sdf(translate_point(p,{0,-1,0}),.4,.05)
		bottom=capped_cylinder_sdf(translate_point(p,{0,.90,0}),.4,.05)
		
		
		middle=capped_cylinder_sdf(p,.3,1)
		flute_p=p
		
		
		
		--for i=1,8 do
		--	flute_p = rotate_point(flute_p,flute_rotate)
		--	
		--	middle=difference_sdf(middle,flute)
		--end
		flute_p=mod_polar(p,8)
		flute_p=translate(flute_p,{0,0,-.3})
		flute=capped_cylinder_sdf(flute_p,.05,1)
		middle=difference_sdf(middle,flute)
		
		local column=blend_sdf(top,middle,.1)
		column=blend_sdf(column,bottom,.1)
		return column

	
end

function cap_sdf(p)
	--
	np=mod_polar(p,16)
	
	p=translate(p,{0,1,0})
	base=ground_sdf(translate(p,{0,.05,0}),1)
	top=sphere_sdf(p,2.7)
	
	
	inner=sphere_sdf(p,2.5)
	top=difference_sdf(top,inner)
	top=difference_sdf(top, ground_sdf(translate(p,{0,1.0,0}),-1))
	--
	
	--
	top = difference_sdf(top,base)
	np=translate(np,{0,1.5,0})
	np=rotate_point(np,eye_rotate)
	cutter=cylinder_sdf(np,.3)
	top=difference_sdf(top,cutter)
	
	
	
	
	return top
end



function building_sdf(p)
	local building = cheap_box_sdf(p,{build_x,build_height,build_x})
	p=op_rep(p,{window_density,window_density,window_density})
	local window = cheap_box_sdf(p,{window_width,window_width,window_width})
	building=difference_sdf(building,window)
	
	return building
end



function twist_sdf(p)
	--p=rotate_point(p,twist_rotate)
	
	p=rotate_y(p,p[2]/12)
	p=translate(p,{0,1,0})
	
	return box_sdf(p,{.8,2.5,.8})
end

function sponge(p,scale)
	local d=box_sdf(p,{1,1,1})
	local s=g_sponge_scale
	--local scale=4
	
	for i=1,3 do
		local ax=(p[1]*s)%2-1
		local ay=(p[2]*s)%2-1
		local az=(p[3]*s)%2-1
		
		s*=scale 
		
		local rx=abs(1-scale*abs(ax))
		local ry=abs(1-scale*abs(ay))
		local rz=abs(1-scale*abs(az))
		
		 da = max(rx,ry)
		 db = max(ry,rz)
		 dc = max(rz,rx)
		 c= (min(da,min(db,dc))-1)/s
		 d=max(d,c)
		
	
	end
	
	return d
	
end

function dead_city_sdf(p)
	p=rotate_y(p,build_rot)
	
	ground = ground_sdf(translate_point(p,{0,1,0}),1)
	p=op_rep(p,{build_densityx,0,build_densityy})
	build=building_sdf(p)
	return union_sdf(ground,build)
end

function twist_tower_sdf(p)
	p=rotate_y(p,.1)
	ground = ground_sdf(translate_point(p,{0,1,0}),1)
	twist=twist_sdf(p)
	return union_sdf(ground,twist)
end

function torus_beach(p)
	ground = ground_sdf(translate_point(p,{0,1.9,0}),1)
	p=rotate_point(p,torus_transform)
	p=op_rep(p,{0,t_rep_x,t_rep_y})
	torus=torus_sdf(p,1.8,.4)
	return blend_sdf(ground,torus,2)
end

function temple_sdf(p)
	p=rotate_y(p,.1)
	
	ground = ground_sdf(translate_point(p,{0,1,0}),1)
	
	cap=cap_sdf(p)
	
	
	p=mod_polar(p,8)
	p=translate(p,{0,0,-2.5})
	
	columns = column_sdf(p)
	
	
	return union_sdf(union_sdf(ground,columns),cap)
end

function sponge_world_sdf(p)
	camera = {0,0,-3}
	light_v=v3_normalize({.08,-.2,-.25})
	p=rotate_point(p,sponge_rotate)
	return sponge(p,5)
end

scene_list={
sponge_world_sdf,
dead_city_sdf,
torus_beach,
--twist_tower_sdf
}
cur_scene=1

function scene_sdf(p)
	--return sponge(p,3)
	return scene_list[cur_scene](p)
	
end



----------------------------------------------------------------------------------------------

function _init()
	
	cur_frame=0
	cls()
	clear_high_color()

	
	generate_extended_palette()
	generate_clut()
	
	--generate_cam_matrix_transform(0,0,0)
	--init_scene_sdf()
	--trace_rays()
	--init_scene_sdf()
	--trace_rays()
	
end

function update_60()

	

end

--function _update60()
--end



function _draw()

	
	if(btn(4) or cur_frame==0 or cur_frame>600)then
		--cls()
		cur_scene=flr(rnd(#scene_list))+1
		cur_frame=0
		set_base_color(flr(rnd(15)+1))
		init_scene_sdf()
		trace_rays()
		
		--cur_scene+=1
		--
		--if(cur_scene>#scene_list)cur_scene=1
		
	end
	
	--print("z for next image",4,120,8)
	

	cur_frame+=1
end


