-- video poker
-- by kittenm4ster

-- global constants
cardw = 20
cardh = 28
handsize = 5
maxbet = 5
prizes = {
  [9] = {n = 'royal flush',     p = 250},
  [8] = {n = 'straight flush',  p =  50},
  [7] = {n = 'four of a kind',  p =  25},
  [6] = {n = 'full house',      p =   9},
  [5] = {n = 'flush',           p =   6},
  [4] = {n = 'straight',        p =   4},
  [3] = {n = 'three of a kind', p =   3},
  [2] = {n = 'two pair',        p =   2},
  [1] = {n = 'jacks or better', p =   1}
}

function _init()
  create_deck()
  create_hand()
  dealbutton = create_button()
  fliptimer = create_timer(2)
  cointimer = create_timer(2)
  pressbuttonflash = create_timer(2, false)
  betflash = create_timer(9, true)

  winflash = create_timer(5, true)
  winflash.n = 0
  winflash.cardindex = 0

  -- attempt to load previously saved data
  if not load_game() then
    -- start a new game
    coins = 100
    bet = 1
  end

  dispcoins = coins
  cam = {y = 0, dir = 0}
  set_state('intro')
end

function load_game()
  if cartdata('kittenm4ster_vidpoker') then
    local savedcoins = dget(0)
    local savedbet = dget(1)

    if savedcoins > 0 then
      -- resume from saved game
      coins = savedcoins
      bet = savedbet

      return true
    end
  end
end

function _update()
  rnd(52) -- spin the rng

  update_buttons()
  process_input()
  postupdate_buttons()

  update_dealer()
  update_camera()
  update_flipstate()
  update_betflash()
  update_winflash()
  update_coins()

  if state == 'intro' then
    update_pressbutton()
  end

  if state == 'award' and dispcoins == coins then
    set_state('bet')
  end
end

function _draw()
  cls()
  camera(0, cam.y)

  draw_bg()
  draw_schedule()
  draw_hand()
  if state == 'intro' then
    draw_pressbutton()
  else
    draw_dealbutton()
    draw_bet()
    draw_coins()
  end

  if (state == 'award' or state == 'bet') and prizeindex then
    draw_prize()
  end
end

function assess()
  cards = {}
  for slot in all(hand) do
    add(cards, slot.card)
  end

  local str8a, str8b = straight()
  local flush = flush()
  local threeoak = find_rank_matches(3)

  if str8a and flush then
    if str8a == 10 and str8b == 14 then
      return 9, cards -- royal flush
    else
      return 8, cards -- straight flush
    end
  end

  -- four of a kind
  local r = find_rank_matches(4)
  if r then
    return 7, r
  end

  -- full house
  if threeoak then
    local pair = find_rank_matches(2, threeoak[1].rank)
    if pair then
      return 6, merge(threeoak, pair)
    end
  end

  if flush then
    return 5, cards
  elseif str8a then
    return 4, cards
  elseif threeoak then
    return 3, threeoak
  end

  -- two pair
  local m1 = find_rank_matches(2)
  if m1 then
    local m2 = find_rank_matches(2, m1[1].rank)
    if m2 then
      return 2, merge(m1, m2)
    end
  end

  -- jacks or better
  local oldrank
  for c in all(cards) do
    if c.rank >= 11 then
      for d in all(cards) do
        if d ~= c and d.rank == c.rank then
          return 1, {c, d}
        end
      end
    end
  end
end

function bg_print(s, x, y, c, bg)
  local w = (#s * 4) - 1
  rectfill(x, y, x + w, y + 5, bg)
  print(s, x, y, c)
end

function flash_red()
  local flash = false

  while true do
    pal(8, flash and 0 or 8, 1)
    for i = 1, 15 do
      yield()
    end
    flash = not flash
  end
end

function block(frames)
  for i = 1, frames do
    coresume(flash_red_cr)
    flip()
  end
end

function cash_out()
  flash_red_cr = cocreate(flash_red)

  local chmask = 0b00001111
  poke(0x5f40, chmask) -- half speed
  poke(0x5f43, chmask) -- low-pass
  music(5)
  poke(0x5f2c, 2)

  local vouchercode = get_voucher_code()
  bg_print('error printing voucher', 0, 0, 7, 0)
  bg_print(vouchercode, 0, 6, 7, 0)
  block(16)

  bg_print('check printer cable', 0, 12, 8, 0)
  block(5 * 30)

  bg_print('clearing cache...', 0, 18, 7, 0)

  -- reset saved progress
  coins = 0
  save_coins()
  pal(3, 15, 1)
  block(8)

  bg_print('done', 68, 18, 7, 0)
  block(1 * 30)

  bg_print('rebooting...', 0, 24, 7, 0)
  block(2 * 30)
  rectfill(0, 0, 127, 127, 0)
  block(2)
  run()
end

function clave()
  return shr(band(peek(0x3200 + (68 * 13) + (stat(20) * 2) + 1), 14), 1) > 0
end

function clear_holds()
  for i = 1, handsize do
    local slot = hand[i]
    slot.hold = false
    slot.button.on = false
    if slot.card then
      slot.card.flash = false
    end
  end
end

function create_button()
  return {on = false, down = false}
end

function create_deck()
  deck = {}
  local i = 0
  for s = 1, 4 do
    for r = 2, 14 do
      i += 1
      deck[i] = {suit = s, rank = r}
    end
  end
  decksize = 52
end

function create_hand()
  hand = {}
  for i = 1, handsize do
    hand[i] = {
      card = nil,
      flip = {state = 2, dir = 0},
      hold = false,
      button = create_button()
    }
  end
end

function create_timer(delay, on)
  return {
    delay = delay,
    value = 0,
    on = on,

    update =
      function(self)
        if self.value and self.value > 0 then
          self.value -= 1
        else
          self.value = self.delay
          if self.on ~= nil then
            self.on = not self.on
          end
          return true
        end
      end
  }
end

function deal()
  for i = 1, handsize do
    local slot = hand[i]
    if slot.card == nil then
      slot.card = take_card_from_deck()
    end
  end
end

function dealtxt(txt)
  for i = 1, handsize do
    hand[i].card = {suit = 1, rank = txt[i]}
  end
end

function discard()
  for i = 1, handsize do
    local slot = hand[i]
    if not slot.hold then
      slot.card = nil
    end
  end
end

function downbeat()
  -- return true if the intro music is at a good measure for flipping the intro
  -- cards
  return stat(20) == 0 or stat(20) == 16
end

function draw_bet()
  local x, y = 10, 8
  pal()
  color(10)
  if betflash.on and state == 'bet' then
    if bet > 1 then
      spr(10, x + 15, y)
    end
    if bet < maxbet then
      spr(10, x + 20, y, 1, 1, true)
    end
  end
  print('bet: ' .. bet, x, y)
end

function draw_bg()
  pal()
  for y = -128, 128, 16 do
    for x = 0, 128, 16 do
      spr(11, x, y, 2, 2)
    end
  end
end

function draw_card(c, x, y, flipstate)
  local mx, my
  my = 0

  x -= 6
  y -= 6

  if flipstate == 1 then
    mx = 4
    my = 5
  elseif flipstate == 2 then
    mx = 0
    my = 5
  elseif c.suit == 3 then
    mx = 0
  elseif c.suit == 1 then
    mx = 4
  elseif c.suit == 2 then
    mx = 8
  elseif c.suit == 4 then
    mx = 12
  end

  pal()
  pal(1, 0)
  if c.flash then
    pal(7, 14)
  end
  mapdraw(mx, my, x, y, 4, 5)

  if flipstate == 0 then
    local r = c.rank
    if c.rank == 10 then
      x -= 2
    else
      local t = {}
      for i = 1, 10 do
        t[i] = i
      end
      t[11] = 'j'
      t[12] = 'q'
      t[13] = 'k'
      t[14] = 'a'
      if t[c.rank] then
        r = t[c.rank]
      end
    end

    print(r, x + 19, y + 9, 0)
  end
end

function draw_coins()
  local x, y = 114, 8
  local offset = nlen(dispcoins) * 4
  pal()
  color(10)
  if state == 'bet' and coins < bet and dealbutton.down then
    color(8)
  end
  print(dispcoins, x - offset, y)
  spr(9, x, y - 3)
end

function draw_cursor(x, y)
  pal()
  spr(23, x, y)
end

function draw_dealbutton()
  local x, y = 48, 97
  local mx, my

  mx = dealbutton.down and 12 or 8
  if state == 'hold' or state == 'draw' then
    my = 7
  else
    my = 5
  end

  pal()
  mapdraw(mx, my, x, y, 4, 2)

  if sel == 6 and state ~= 'award' then
    draw_cursor(x + 12, y + 14)
  end
end

function draw_hand()
  local x, y = 10, 50
  if cam.y < -(128 - y) then
    return
  end

  for i = 1, handsize do
    local card = hand[i].card
    local flipstate = 2

    if card then
      flipstate = hand[i].flip.state
    else
      card = {suit = nil, rank = nil}
    end

    draw_card(card, x, y, flipstate)

    if state == 'hold' or state == 'draw' then
      draw_hold_button(hand[i].button, x, y + cardh + 2)
    end

    if state == 'hold' then
      if i == sel then
        draw_cursor(x + 6, y + cardh + 8)
      end
    end

    x += cardw + 2
  end
end

function draw_hold_button(button, x, y)
  pal()
  if not button.on then
    pal(10, 6)
    pal(4, 5)
  end

  n = button.down and 54 or 38
  spr(n, x - 6, y, 4, 1)
end

function update_pressbutton()
  if clave() then
    pressbuttonflash.on = true
    reset_timer(pressbuttonflash)
  end
  if pressbuttonflash.on then
    pressbuttonflash:update()
  end
end

function draw_pressbutton()
  color(pressbuttonflash.on and 10 or 12)
  print('press 🅾️', 48, 100)
end

function draw_prize()
  local x, y = 64, 25
  local prize = prizes[prizeindex]

  local len = #prize.n
  local offset = (((len * 4) - 1) / 2)

  pal()
  color(winflash.c)
  pal(10, winflash.c)

  print(prize.n, x - offset, y)

  y += 8

  local width = (nlen(payout) * 4) + 4
  offset = width / 2

  print(payout, x - offset, y)
  spr(9, x + offset - 4, y - 3)
end

function draw_schedule()
  if cam.y == 0 then
    return
  end

  local x, y = 20, -84

  for i = 9, 1, -1 do
    local prize = prizes[i]

    color(prizeindex == i and winflash.c or 10)
    print(prize.n, x, y)

    local n = get_payout(i)
    local px = x + (22 * 4) - (nlen(n) * 4) + 1
    print(n, px, y)

    y += 8
  end
end

function find_rank_matches(count, ignorerank)
  local r
  for c in all(cards) do
    r = {c}
    if c.rank ~= ignorerank then
      local matches = 0
      for d in all(cards) do
        if d ~= c and d.rank == c.rank then
          add(r, d)
          matches += 1
          if matches + 1 == count then
            return r
          end
        end
      end
    end
  end
end

function flip_card(i)
  local f = hand[i].flip
  if f.state == 0 then
    f.dir = 1
  elseif f.state == 2 then
    f.dir = -1
  end
end

function flush()
  local ok = true
  local suit = cards[1].suit
  for c in all(cards) do
    if c.suit ~= suit then
      ok = false
      break
    end
  end
  return ok
end

function get_payout(i)
  -- if the hand is a royal flush with max bet
  if i == 9 and bet == maxbet then
    return 4000
  end

  return prizes[i].p * bet
end

function get_voucher_code()
  local code = ''

  for i = 1, 18 do
    code = code .. tostr(rnd_int(0, 9))
    if i < 18 then
      if i == 2 or (i > 4 and (i + 2) % 4 == 0) then
        code = code .. '-'
      end
    end
  end

  return code
end

function hide()
  for i = 1, handsize do
    local f = hand[i].flip

    -- if this card slot is not held
    if not hand[i].hold then
      -- if this slot is face up and not already flipping
      if f.state == 0 and f.dir == 0 then
        flip_card(i)
        return false
      end

      -- if this slot is not done flipping
      if f.state ~= 2 then
        return false
      end
    end
  end

  return true
end

function merge(t1, t2)
  for e in all(t2) do add(t1, e) end
  return t1
end

function nlen(n)
  if n < 10 then
    return 1
  elseif n < 100 then
    return 2
  elseif n < 1000 then
    return 3
  elseif n < 10000 then
    return 4
  elseif n < 100000 then
    return 5
  end
end

function postupdate_buttons()
  for i = 1, handsize do
    local button = hand[i].button
    if button.wasdown and not button.down then
      if button.on then
        sfx(4)
      else
        sfx(3)
      end
    end
  end
end

function process_input()
  if btn(2) then -- up
    if not upwaspushed then
      if state == 'bet' or sel ~= 6 then
        cam.dir = -1
      end

      if state == 'hold' then
        if sel == 6 then
          sel = 3
        end
      end
    end
    upwaspushed = true
  else
    upwaspushed = false
  end
  if btn(3) then -- down
    if not downwaspushed then
      cam.dir = 1

      if cam.y >= -16 then
        sel = 6
      end
    end
    downwaspushed = true
  else
    downwaspushed = false
  end

  if state == 'bet' then
    if btnp(0) then -- left
      if bet > 1 then
        sfx(1)
        bet -= 1
        save_bet()
        update_betflash(true)
      end
    end
    if btnp(1) then -- right
      if bet < maxbet then
        sfx(1)
        bet += 1
        save_bet()
        update_betflash(true)
      end
    end
  end

  if state == 'intro' and btn(4) then
    set_state('start')
  end

  if cam.y < 0 then
    -- do not process any further input
    return
  end

  if state == 'hold' and btn(5) then
    sel = 6
    set_state('draw')
    quickdraw = true
  else
    quickdraw = false
  end

  if state ~= 'award' then
    if (sel == 6 and btn(4)) or quickdraw then
      if push_button(dealbutton) then
        if state == 'bet' then
          if coins >= bet then
            set_state('deal')
          else
            sfx(5)
          end
        elseif state == 'hold' then
          set_state('draw')
        end
      end
    end
  end

  if state == 'hold' then
    if btnp(0) then -- left
      if sel == 6 then
        sel = 2
      elseif sel > 1 then
        sel -= 1
      end
    end
    if btnp(1) then -- right
      if sel == 6 then
        sel = 4
      elseif sel < 5 then
        sel += 1
      end
    end

    if btn(4) and sel ~= 6 then
      local b = hand[sel].button
      if push_button(b) then
        if b.on then
          sfx(3)
        else
          sfx(4)
        end
        hand[sel].hold = b.on
      end
    end
  end

  if btn(4) then
    btn4wasdown = true
  else
    btn4wasdown = false
  end
end

function push_button(b)
  if not btn4wasdown or b.wasdown then
    b.down = true
  end

  if not btn4wasdown then
    b.wasdown = true
    b.on = not b.on
    return true
  end
end

function reset_timer(t)
  t.value = t.delay
end

function rnd_int(min, max)
  return flr(rnd((max + 1) - min)) + min
end

function save_coins()
  dset(0, coins)
end

function save_bet()
  dset(1, bet)
end

function set_state(s)
  if s == 'intro' then
    music(5)
    dealstep = -5
  elseif s == 'start' then
    music(-1, 5)
    dealstep = -1
  elseif s == 'bet' then
    menuitem(1, 'cash out', cash_out)
    sel = 6
  elseif s == 'deal' then
    menuitem(1) -- remove "cash out"
    music(-1, 5)
    sfx(6, 3)
    coins -= bet
    save_coins()
    clear_holds()
    wincards = nil
    dealstep = 0
    prizeindex = nil
  elseif s == 'draw' then
    sfx(7)
    dealstep = 1
  elseif s == 'award' then
    reset_timer(winflash)
    winflash.on = true
    winflash.n = 0
    winflash.cardindex = 0
  end

  state = s
end

function show()
  for i = 1, handsize do
    local f = hand[i].flip

    -- if this slot is face down and not already flipping
    if f.state == 2 and f.dir == 0 then
      flip_card(i)
      return false
    end

    -- if this slot is not done flipping
    if f.state ~= 0 then
      return false
    end
  end

  return true
end

function straight()
  local a, b
  for c in all(cards) do
    if c.rank == 14 then
      a = 1
    else
      a = c.rank
    end
    b = a

    local foundnext
    repeat
      foundnext = false
      for d in all(cards) do
        if d.rank == b + 1 then
          b = d.rank
          foundnext = true
          break
        end
      end
    until foundnext == false

    if (b - a) + 1 == 5 then
      return a, b
    end
  end
end

function take_card_from_deck()
  local index = flr(rnd(decksize)) + 1

  -- copy the card
  local card = {
    suit = deck[index].suit,
    rank = deck[index].rank
  }

  -- shift the other cards over, removing the card from the deck
  for i = index, decksize - 1 do
    deck[i] = deck[i + 1]
  end
  deck[decksize] = nil
  decksize -= 1

  return card
end

function update_betflash(reset)
  if reset then
    betflash.on = true
    reset_timer(betflash)
  end
  betflash:update()
end

function update_buttons()
  for i = 1, handsize do
    local button = hand[i].button
    button.wasdown = button.down
    button.down = false
  end

  dealbutton.wasdown = dealbutton.down
  dealbutton.down = false
end

function update_camera()
  local dest
  if cam.dir == -1 then
    dest = -107
  elseif cam.dir == 1 then
    dest = 0
  end

  if not dest then
    return
  end

  local speed = (dest - cam.y) * .5
  if speed < -20 then
    speed = -20
  end

  cam.y += speed

  if dest < 0 and cam.y <= dest then
    cam.y = dest
    cam.dir = 0
  end

  if cam.y >= -.5 then
    cam.y = 0
    cam.dir = 0
  end
end

function update_coins()
  if not cointimer:update() then
    return
  end

  if dispcoins < coins then
    dispcoins += 1
    sfx(2)
  elseif dispcoins > coins then
    dispcoins -= 1
  end
end

function update_dealer()
  if dealstep == -5 then
    dealtxt({'v', 'i', 'd', 'e', 'o'})
    if show() and downbeat() then
      dealstep += 1
    end
  elseif dealstep == -4 then
    if hide() and downbeat() then
      dealtxt({'p', 'o', 'k', 'e', 'r'})
      dealstep += 1
    end
  elseif dealstep == -3 then
    if show() and downbeat() then
      dealstep += 1
    end
  elseif dealstep == -2 then
    if hide() and downbeat() then
      dealstep = -5
    end
  elseif dealstep == -1 then
    if hide() then
      set_state('bet')
    end
  elseif dealstep == 0 then
    create_deck()
    dealstep += 1
  elseif dealstep == 1 then
    if hide() then
      discard()
      deal()
      dealstep += 1
    end
  elseif dealstep == 2 then
    if show() then
      dealstep += 1
    end
  elseif dealstep == 3 then
    if state == 'deal' then
      state = 'hold'
    elseif state == 'draw' then
      prizeindex, wincards = assess()
      if prizeindex then
        if prizeindex > 1 then
          music((prizeindex == 9) and 20 or 9, 0, 7)
        else
          sfx(8)
        end
        payout = get_payout(prizeindex)
        coins += payout
        save_coins()
      end
      set_state('award')
    end
  end
end

function update_flipstate()
  if not fliptimer:update() then
    return
  end

  for i = 1, handsize do
    local f = hand[i].flip
    if f.dir == 1 then
      if f.state < 2 then
        f.state += 1
      else
        f.dir = 0
      end
    end
    if f.dir == -1 then
      if f.state > 0 then
        f.state -= 1
      else
        f.dir = 0
      end
    end
    if f.dir ~= 0 and f.state == 1 then
      sfx(0)
    end
  end
end

function update_winflash()
  local f = winflash
  if f.n >= 122 and not f.on then
    return
  end

  if f:update() then
    if wincards and f.n < 100 then
      if f.cardindex > 0 then
        wincards[f.cardindex].flash = false
      end
      f.cardindex += 1
      if f.cardindex > #wincards then
        f.cardindex = 1
      end

      if f.cardindex == 1 and f.n >= 11 and state ~= 'award' then
        f.n = 100
      else
        wincards[f.cardindex].flash = true
        if f.n == 99 then
          f.n = 0
        end
      end
    end

    f.n += 1
    f.c = (f.on and 12 or 10)

    if f.n == 122 then
      if prizeindex and prizeindex > 1 then
        f.n = 0
        f.cardindex = 0
      end
    end
  end
end