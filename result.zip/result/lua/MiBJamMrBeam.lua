
lz_spend=0.5
refill_spd=1.5
refill_dist=32
wmax=0
for i=0,64 do 
 if(mget(25,i)>0) wmax+=1 
 if(mget(24,i)>0) force_wave=i
 
end

function _init()
 
 t=0
 ents={}
 lines={}
 dls={}
 comp={}
 shds={}
 for i=0,wmax do add(comp,0) end
 sel=0
 menu()
 
end

function menu()
 dls={}
 music(1)
 draw=dmen
 upd=umen
 
 free=1
 ec=2 ts=6 
 ma=(128-ts*8-(ts-1)*ec)/2
 
 buts={}
 for i=0,wmax-1 do
  n=comp[i+1]
  if free>0 then
    if(n!=3) free-=1
    if(n==0) n=1
  end
  if(n==3) free+=1
  
  e=mke()
  e.x=ma+(i%ts)*(8+ec)
  e.y=ma+flr(i/ts)*(8+ec)
  e.fr=73+n
  e.id=i
  add(buts,e)
 end 
end

function umen()

 pok=1
 k=0
 if(btnp(0)) k=-1
 if(btnp(1)) k=1
 if(btnp(2)) k=-ts
 if(btnp(3)) k=ts
 
 
 n=mid(0,sel+k,ts*ts-1)
 
 b=buts[1+n]
 if(b!=nil and b.fr!=73 ) sel=n
 
 lvl=b.id
 if( force_wave ) lvl=force_wave
 if btnp(4) then
  for i=0,32 do
   f=mget(25+i,lvl)
   mset(i,16,f)
  end
  start()
 end
end

function dmen()
 b=buts[1+sel]
 pal(7,3+(t%3)*4)
 sspr(72,40,10,10,b.x-5,b.y-5)
 pal()
 
 pf={"go","ni","pul","ma","del","gru"}
 sf={"mar","jo","ka","tir","on","ch"}
 name=pf[1+sel%ts]..sf[1+flr(sel/ts)]
 print(name,ma-5,ma-11,12)
 
 for i=0,2 do
  ec=4-i*4
  print("mr.beam 2015",40+hr(ec),2+hr(ec),2+i*6)
 end
 c={
  "help us now",
  "we need the 32 files back",
  "this hard drive is all...",
  "...that remain of mankind",
 }
 cursor(20,100)
 print(c[cyc(4,32)+1],20,100,rand(15))
 
end

function start()
 pok=0
 music(-1)
 ents={}
 bads={}
 --
 upd=ugam
 draw=dgam
 msg=nil
 dead=nil
 energy=100
 
 -- hero
 h=mke()
 h.cd=0
 h.fr=17
 h.x,h.y=64,64
 h.u=ctrl
 h.ca,h.sa=0,0
 h.dr=function(e)
  
  d=4
  for i=0,1 do
   x=(h.x-4)+h.ca*(1+(d-1)*i)
   y=(h.y-4)+h.sa*(1+(d-1)*i)+1
   spr(18,x,y)
  end
  
  for i=0,1 do
   c=4+6*i
   c=13-7*i
   x=h.x+h.ca*2
   y=h.y+h.sa*2-i
   line(x-1,y,x+h.ca*d,y+h.sa*d,c)
  end
  
  
 end
 
 -- trg
 trg=mke()
 trg.fr=32
 trg.x=64
 trg.y=64
 trg.u=function(e)
  trg.fr=32
  if(btn(4)) trg.fr+=1
  if(refill) trg.fr=34+cyc(2,2)
  chk_bnc(e)
 end
 imp(trg,nil,0.3)
 

 -- doors
 doors={}
 for x=0,15 do for y=0,15 do
  f=mget(x,y)
  if(f==81) then
   d={}
   d.x=x*8+4
   d.y=y*8+4
   d.open=0
   d.k=0 d.t=0
   if(x==0)  d.di=0
   if(y==15) d.di=1
   if(x==15) d.di=2
   if(y==1)  d.di=3
   add(doors,d)
  end
 end end

 final=nil
 si=0
 script()

end

function script()
 k=mget(si,16)
 si+=1
 mult=max(1,mget(si,16)-191)
 if(mult>10) mult=1
 
 -- end
 if k==0 then
  final=1
  return
 end
 -- pause
 if k==213 then
  psc=dl(200,script)
  return
 end
 -- spawn
 if k<100 then
  d=gfdo()
  if d!=nil then
   d.mt=k-4
   d.k=gc(d.mt,1)*mult
   if(force!=nil) d.mt=force
   d.t=40
   n=mget(18,1+d.mt)-191
  end
 end
 script()
end

function gc(mt,k)
 return mget(17+k,1+mt)-191
end

function ugam()
 --if(psc) log(psc.t,1)
 --doors
 foreach(doors,udo)
 
 -- bounce
 grid={}
 sub=4
 gm=shr(128,sub)
 
 
 for i=1,gm*gm do gg={} add(grid,gg) end
 for e in all(ents) do 
  if e.fam==1 and e.t>e.lt then 
   px=flr(shr(e.x,sub))
   py=flr(shr(e.y,sub))
   add(grid[px*gm+py+1],e)
   npx=flr(shr(e.x-8,sub))
   npy=flr(shr(e.y-8,sub))
   if npx!=px or npy!=py then
    add(grid[npx*gm+npy+1],e)
   end
  end
 end
 
 
 for g in all(grid) do
  bounce_grp(g)
 end
 
 

 if count(bads)==0 then
  for d in all(doors) do
   if(d.k>0) return
  end
  if(psc) psc.t=0
  if final then
   final=nil
   dl(30,finish)
  end
 end
end

function bounce_grp(c)
 for a in all(c) do
  for b in all(c) do
   if(a!=b) bounce(a,b)
  end
 end
end


function finish()
 sfx(-1,3)
 clear("well done!")
 music(3)
 comp[lvl+1]=3
end

function clear(str)
 ents={}
 h.lx=nil
 upd=nil
 msg=str
 dl(120,menu)
 t=0
end

function dgam()
 -- map
 for x=0,15 do for y=0,15 do
  f=mget(x,y)
  if(f==81) f=0
  spr(f,x*8,y*8)
 end end
 -- doors
 foreach(doors,ddo)
 -- energy
 rect(0,0,127,6,7)
 c=energy/100
 bg=1
 if energy==0 and not dead then 
  if(t%8==0) sfx(17)
  bg=2+(t%2)*6
 end
 rectfill(1,2,126,5,bg)
 if(energy>0) rectfill(1,2,126*c,5,12)

 clp()
 
 if msg then
  print(msg,44,70-t/10,12+cyc(4,4))
  return
 end
 if(dead) return
 
 
 -- trg zone
 if energy < 100 and not refill then
  if not btn(4) or energy==0 then
   c=1
   if(energy==0) c=2+cyc(2,2)*6
   circ(trg.x,trg.y,refill_dist-2,c)
  end
 end
 -- laser
 if h.lx then
  for z=0,8 do
   k=(z+5)%9
   dx=k%3-1
   dy=flr(k/3)-1
   c=12
   if(z==8) c=7
   line(h.cx+dx,h.cy+dy,h.lx+dx,h.ly+dy,c)
  end
  spr(48+t%2,h.lx-4,h.ly-4)
 else
 
  dx=trg.x-h.cx
  dy=trg.y-h.cy
  if refill then
   for k=0,1 do
    x=h.cx
    y=h.cy
    mx=6
    for i=1,mx do
     nx=h.cx+dx*(i/mx)
     ny=h.cy+dy*(i/mx)
     if i<mx then
      nx+=rand(4)-2
      ny+=rand(4)-2
     end
     line(x,y,nx,ny,12-k*5)
     x=nx y=ny
    end
   end
  else 
   mx=8
   for i=1,mx do
    x=h.cx+dx*i/(mx+1)
    y=h.cy+dy*i/(mx+1)
    pset(x,y,1)
   end
  end
 end
 
end

function clp() clip(3,11,122,114) end


function gfdo()
 for i=0,80 do
  d=doors[rand(6)+1]
  if(d.k==0) return d
 end
end

function rand(n) return flr(rnd(n)) end

function udo(d)

 d.t-=1
 if t%4==0 then
  if(d.k==0 and d.open>0 and d.t<0 ) d.open-=1
  if(d.k>0 and d.open<4 ) d.open+=1
 end 
 
 if(d.k==0) return
 if(d.t>0) return
 d.t=12
 
 o=gd(d.di)
 m=mkm(d.mt)
 m.x=d.x-o.x*8
 m.y=d.y-o.y*8
 m.vx=o.x*0.5
 m.vy=o.y*0.5
 m.an=d.di/4
 m.lt=e.t+30
 m.hd=d.last
 
 d.last=m
 d.k-=1
 
 if d.k==0 then
  if(m.hd) m.q=1
  d.last=nil
  d.t=12
 end
end

function mkm(t)
 e=mke()
 e.an=rnd(1)
 e.mt=t
 e.hp=mget(17,1+e.mt)-191
 e.spd=(mget(19,1+e.mt)-191)/4
 e.fam=1
 e.hcol=1
 e.fr=20
 e.va=0

 if t==0 then
  e.u=function(e)
   chk_hd(e)
   if e.hd then 
    fol(e,e.hd)
   else
    fol(e,h)
   end
  end
 end
 
 if t==1 then
  e.u=function(e)
   e.spd=0.2+(energy/100)
   fol(e,h)
  end
 end
 
 if t==2 then
  
  e.u=function(e)
   dx=h.x-e.x
   dy=h.y-e.y
   tol=12+dy/10
   if abs(dx)<tol and dy>2 then
    e.fr=6
    e.vx=0
    e.x+=dx*0.1
    e.vy+=0.25
    if(e.stand) sfx(14)
    e.stand=nil
   else
    if(dy<0) e.y-=0.5
    e.stand=1
    wander(e)
    chk_bnc(e)
   end
  end
 end 
 
 if t==3 then
  e.u=usushi
 end
 
 if t==4 then
  e.u=function(e) fol(e,h) end
 end
 
 if t==5 then
  
  e.dt=rand(240)
  e.u=function(e)
   e.f=0.7
   if(e.t%16==0 and e.t>80 ) do
    fire(e,0.1)
    sfx(5)
   end
   if (e.t+e.dt)%240<120 then
    wander(e)
    chk_bnc(e)
    return
   end
   tx=128-h.x
   ty=128-h.y
   e.vx+=(tx-e.x)*0.01
   e.vy+=(ty-e.y)*0.01
   recal(e)
  end
 end
 
 if t==6 then
  e.u=function(e)
  
   lm=34-count(bads)
  
   if dis(e,h)>lm+32 then
    fol(e,h) 
    return
   end
   if dis(e,h)<lm then
    fol(e,h) 
    e.an+=0.5
    uphys(e)
    return
   end
   wander(e)
   chk_bnc(e)
  end
 end
 
 if t==7 then
  e.u=function(e)
   if e.t%120==0 then
    sfx(18)
    b=fire(e,0.02)
    b.r+=1
    b.od=mxpl
    b.fr=nil
    b.u=function(e)
     adl(e.x,e.y,e.ox,e.oy,3,3)
     kout(e)
    end
    b.acc=0.1
   end
   chk_hd(e)
   if e.hd then 
    fol(e,e.hd)
   else
    wander(e)
    chk_bnc(e)
   end
  end
 end
 
 add(bads,e)
 return e
end

function dis(a,b)
 dx=a.x-b.x
 dy=a.y-b.y
 return max(abs(dx),abs(dy))
end

function fire(e,ra)
 
 b=mke()
 b.fr=18
 b.r=2
 b.hcol=1
 b.spd=1
 setpos(b,e.x,e.y)

 b.an=atan2(h.y-b.y,h.x-b.x)
 b.an+=rnd(ra*2)-ra
 uphys(b)
 
 b.u=function(e)
  e.fr=115+e.t%8
		kout(e)
 end
 return b
 
end
function kout(e)
 if is_out(e.x,e.y,6) then
  kl(e)
 end
end
function usushi(e)
 chk_hd(e)
 c=(t%60)/60
 e.spd=1+cos(c)*0.5
 if e.hd then 
  fol(e,e.hd)
 else
  wander(e)
  chk_bnc(e)
 end
end

function chk_hd(e)

 if e.hd then
  if(e.hd.dead) e.hd=nil
 else
  if(e.t%80!=0) return
  lim=16
  
  for b in all(bads) do
   dx=b.x-e.x
   dy=b.y-e.y
   if b!=e and b.mt==e.mt and b.q and abs(dx)<lim and abs(dy)<lim then
    r=b.hd
    while r!=nil and r!=e do r=r.hd end
    if r!=e then
     b.q=nil
     e.hd=b
    end
   end
  end
 end
end

function fol(e,trg)
 
 dx=trg.x-e.x
 dy=trg.y-e.y
 r=e.r+trg.r
 if( dx*dx+dy*dy > r*r ) e.an=atan2(dy,dx)
 uphys(e)
end

function wander(e)
 if(not e.va) e.va=0
 
 e.va+=(rnd(2)-1)/100
 e.va*=0.92
 e.an+=e.va
 uphys(e)
end
function uphys(e)
 imp(e,e.an,e.spd,1)
end

function bounce(a,b)
 r=a.r+b.r
 dx=a.x-b.x
 dy=a.y-b.y
 if(abs(dx)>r or abs(dy)>r) return
 d=(r-sqrt(dx*dx+dy*dy))*0.5
 if(d<=0) return
 an=atan2(dy,dx)
 ca=cos(an)*d
 sa=sin(an)*d
 a.x+=ca a.y+=sa
 b.x-=ca b.y-=sa
end

function ddo(d)

 f=min(d.open,3)
 s=d.di%2
 o=gd(d.di)
 ax=abs(o.x)
 ay=abs(o.y)
 x=24+f*ax*2+s*8
 y=32+f*ay*2
 ww=8-ax*6 hh=8-ay*6
 tx=d.x-ww/2-o.x*2
 ty=d.y-hh/2-o.y*2
 sspr(x,y,ww,hh,tx,ty)
 
end

function gd(di)
 c={1,0,0,-1,-1,0,0,1}
 o={}
 o.x=c[1+di*2]
 o.y=c[1+di*2+1]
 return o
end

function ctrl(e)
 h.cd-=1
 h.fr=17
 -- canon
 dx=trg.x-h.x
 dy=trg.y-h.y
 h.an=atan2(dy,dx)
 h.ca=cos(h.an)
 h.sa=sin(h.an)
 h.cx=h.x+h.ca*4
 h.cy=h.y+h.sa*4-1
  
 -- control
 quiet = not btn(4)
 if h.lx and (quiet or energy==0 ) then
  stop_laser()
  h.lx=nil
 end

 if(btn(0)) move(-1,0)
 if(btn(1)) move(1,0)
 if(btn(2)) move(0,-1)
 if(btn(3)) move(0,1)
 if(btn(4) and energy>0 ) laser()
 recal(e)
 
 
 --refill
 if sqrt(dx*dx+dy*dy)<refill_dist and quiet and energy<100 then
   energy=min(energy+refill_spd,100)
   if( not refill ) sfx(4,3)
   refill=1
 else
  if(refill) then
   refill=nil
   if(not h.lx) sfx(-1,3)
  end
 end

end

function move(dx,dy)
 spd=1.5
 h.x+=dx*spd
 h.y+=dy*spd
 
 h.fr=123+flr((t%16)/4)
end


function laser()
 if(h.lx==nil) sfx(1,3)
 energy=max(energy-lz_spend,0)
 
 x=h.cx
 y=h.cy
 
 b=nil
 while(not b and not is_out(x,y,3)) do
  x+=h.ca*3
  y+=h.sa*3
  b=bcol(x,y)
  if b then
   if b.mt==2 and b.y<h.y then
    b.shell=1
    sfx(15)
   else
    hit(b,0.2)
   end
  end
 end
 while is_out(x,y,3) do
  x-=h.ca
  y-=h.sa
 end
 h.lx=x
 h.ly=y 
  
end

function stop_laser()
 sfx(-1,3)
 for i=0,8 do
  c=rnd(1)
  e=mke()
  s=1+rnd(12)
  e.x=h.cx+(h.lx-h.cx)*c
  e.y=h.cy+(h.ly-h.cy)*c
  e.vx=h.ca*s
  e.vy=h.sa*s
  e.f=0.92
  e.li=5+rnd(15)
  e.dr= function(e)
   pset(e.x,e.y,7)
  end
 end
end


function hit(b,k)
sfx(2,1)
 b.hp-=k
 b.shk=2
 if(b.hp<=0) xpl(b)
 
end

function xpl(e)
 pok=1
 shk=4
 kl(e)
 adc(e.x,e.y,4,24,1,2)
 
 k=mget(20,1+e.mt,3)
 if k>0 then
  sfx(16)
  s=mkm(k-4)
  s.x=e.x s.y=e.y
  return
 end
 sfx(3)
 adc(e.x,e.y,1,8,3,1,1)
 
end

function bcol(x,y)
 for b in all(bads) do
  r=b.r
  dx=x-b.x dy=y-b.y
  if abs(dx)<r and abs(dy)<r then
   if(dx*dx+dy*dy<r*r) return b
  end
 end
end


function adl(x,y,ex,ey,g,li)
 l={} l.x=x l.y=y 
 l.ex=ex l.ey=ey
 l.g=g l.li=li
 add(lines,l)
end

function is_out(x,y,ma)
 return x<ma or x>128-ma or y<8+ma or y>128-ma
end

function imp(e,a,s,r) 
 if(a==nil) a=rnd(1)
 if(r) e.vx=0 e.vy=0
 e.vx+=cos(a)*s
 e.vy+=sin(a)*s
end

function chk_bnc(e)
 ox=e.x
 oy=e.y
 recal(e)
 if(ox!=e.x) e.vx*=-1
 if(oy!=e.y) e.vy*=-1
 if(e.an) e.an=atan2(e.vy,e.vx)
 
end

function recal(e)
 r=e.r+2
 if is_out(e.x,e.y,r) then
  e.x=mid(r,e.x,128-r)
  e.y=mid(r+8,e.y,128-r)
 end
end


function mke()
 e={}
 e.x=0 e.y=0 e.vx=0 e.vy=0
 e.f=1 e.fr=0 e.t=0 e.lt=0 e.r=4
 add(ents,e)
 return e
end
function setpos(e,x,y)
 e.x=x e.y=y e.ox=x e.oy=y
end

function disq(a,b,r)
 if(r==nil) r=0
 r+=a.r+b.r
 dx=a.x-b.x
 dy=a.y-b.y
 if abs(dx)<r and abs(dy)<r then
  return dx*dx+dy*dy<r*r
 end 
 return false
end

function hxpl()
 sfx(7)
 kl(h)
 adc(h.x,h.y,4,64,0,2)
 kl(trg)
 adc(trg.x,trg.y,4,16,0,2)
 
 --bullets
 for e in all(ents) do
  if(e.hcol and e.fam!=1) kl(e)
 end
 
 ---blast
 for b in all(bads) do
  kl(b)
  for i=0,2 do
   bx=b.x+hr(i*8)
   by=b.y+hr(i*8)
   z=4-i
   e=adc(b.x,b.y,z,z/2,0,1+rnd(1),1)
   dx=e.x-h.x
   dy=e.y-h.y
   an=atan2(dy,dx)
   spd=16/max(1,sqrt(dx*dx+dy*dy))
   spd+=rnd(6)
   imp(e,an,spd)
  end
 end 
 -- parts
 mx=32
 for i=0,mx do
  e=mke()
  setpos(e,h.x,h.y)
  imp(e,i/mx,8)
  c=rnd(1)
  e.f=0.5+(1-c*c)*0.47
  e.li=10+rand(15)
  e.u=function(e)
   adl(e.x,e.y,e.ox,e.oy,4,4)
  end
 end
end

function hr(k) return rnd(k*2)-k end

trc=0

function adc(x,y,sr,er,g,md,fl)
 if(er==nil) er=sr
 if(g==nil) g=0
 if(md==nil) md=1
 e=mke()
 e.fl=fl
 e.x=x
 e.y=y
 e.li=8*md
 e.dr=function(e)
  c=sget(8+e.li/md,g)  
  co=e.li/(8*md)  
  co=1-co*co
  f=circ
  if(e.fl) f=circfill
  f(e.x,e.y,sr+(er-sr)*co,c)
 end
 return e
end

function upe(e)
 e.t+=1
 
 if(e.fam==1) e.fr=4+e.mt+flr((e.t%16)/4)*16
  
 if e.hcol and not dead then
  if disq(e,h,-3) then
   if(comp[lvl+1]<2) comp[lvl+1]=2
   sfx(6)
   pause=20
   dead=1
   sfx(-1,3)
   h.u=nil
   h.dr=function(e)
    if(t%4<2) circfill(e.x-1,e.y-1,3.5,8)
   end
   if(e.od) kl(e)
   dl(2,hxpl)
   dl(40,function() 
    clear("gameover")
    music(0)
   end)
   for b in all(bads) do b.shk=nil end
   return
  end
 end
 
 if(e.u and e.t>e.lt) e.u(e)
 
 if e.acc then
  e.spd+=e.acc
  uphys(e)
 end
 
 e.ox=e.x
 e.oy=e.y
 e.x+=e.vx
 e.y+=e.vy
 e.vx*=e.f
 e.vy*=e.f
 if e.shk then
  e.shk*=0.75
  if(e.shk<1) e.shk=nil
 end
 if e.li then
  e.li-=1
  if(e.li<=0) kl(e)
 end
end

function dre(e)
 x=e.x-4
 y=e.y-4
 if e.shk then
  x+=rnd(e.shk*2)-e.shk
  y+=rnd(e.shk*2)-e.shk
 end
 
 if e.shk then 
  for i=0,15 do pal(i,8+rand(8)) end
 end 
 if( e.t<e.lt ) clip(0,8,127,119)
 if e.shell then
  e.shell=nil
  k=1+cyc(2,2)
  for i=0,2 do
   pal(sget(16+i,0),sget(16+i,k))
  end
 end
 
 spr(e.fr,x,y)
 if(e.dr!=nl) e.dr(e)
 
 pal() clp()
end

function cyc(n,tmp)
 return flr( (t%(n*tmp))/tmp )
end

function mxpl(e)
 adc(e.x,e.y,6,8,1,1.5,1)
 shk=4
 sfx(19)
end

function kl(e)
 if(e.fam==1) del(bads,b)
 if(e.hd) e.hd.q=1
 if(e.od!=nil) e.od(e)
 e.dead=1
 del(ents,e)
end

function drl(l)
 line(l.x,l.y,l.ex,l.ey,sget(8+l.li,l.g))
 l.li-=1
 if(l.li<0) del(lines,l)

end

function sqrt(n)
 local i = 0
 while(i*i <= n) do 
  i+=1
 end
 i-=1
 local d = n-i*i
 local p = d/(2*i)
 local a = i+p
 return a -(p*p)/(2*a)
end

function atan2(dy,dx)
 local q=0.125
 local a=0
 local ay=abs(dy)
 if( ay == 0 ) ay = 0.001 
 if( dx >= 0 ) then
  local r = (dx-ay)/(dx+ay)
  a=q-r*q
 else
  local r=(dx+ay)/(ay-dx)
  a=q*3-r*q
 end
 if(dy>0)a=-a 
 return a
end

function dl(t,f)
 d={} d.f=f d.t=t
 add(dls,d)
 return d
end

function _update()
 t=t+1
 --log(trc)
 if pause then
  pause-=1
  if(pause<=0) pause=nil
  return
 end
 
 if(upd) upd()
 foreach(ents,upe)

 for d in all(dls) do
  d.t-=1
  if d.t<=0 then
   del(dls,d)
   d.f()
  end
 end  
end

function _draw()
 cls()
 
 if shk then
 
  --camera(rnd(shk*2)-shk,rnd(shk*2)-shk)
 	sns=(t%2)*2-1
 	camera(0,sns*shk)
 	shk*=0.5
 	if(shk<1) shk=nil
 end
 
 if(draw) draw()
 foreach(lines,drl)
	foreach(ents,dre)
 camera()
 
 clip()
	
	if pok then
  
  pok*=0.75
  
  gf=function() return 0x6000+rand(6000) end
  
  f=gf()
  memcpy(f,f+8*pok,100)
  f=rand(600)
  if(rand(8)==0) memcpy(0x6000+f,0x6000+f+rand(3)*pok,100)
   
  cs=cos((t%60)/60)
  cs*=pok
  for i=0,100 do
   b=0x6000+i*80
   c=i/100
   le=70
   memcpy(b,b+i%(1+cs),le)
  end
  
  
 end
	
	
	k=0
	cursor(0,0)
	color(7)
	for s in all(ltx) do	   
	 print(s)
	 k+=1
	 if(k==14) break
	end
	 
 
end

ltx={}

function log(n,cl)
 if(cl) ltx={}
 add(ltx,n) 
end


