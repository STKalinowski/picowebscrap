--Flip Knight
--by st33d


--globals

--flags
f_player = shl(1, 0)--us
f_wall = shl(1, 1)--hard surface
f_trap = shl(1, 2)--area we scan for ids
f_up = shl(1, 3)--hard surface only when going down
f_down = shl(1, 4)--hard surface only when going up
f_crate = shl(1, 5)--pushable box, causes bugs
f_enemy = shl(1, 6)--baddies
--pico 8 doesn't use flags this high, so it works for out-of-bounds
f_outside = shl(1, 8)
f_out = f_outside
the_end_y =-256

function boring(...)
  local args,n = {...},0
  for f in all(args) do
    n=bor(n,f)
  end
  return n
end

f_char_thru = boring(f_player,f_enemy,f_trap,f_up,f_down)
f_down_thru = boring(f_player,f_enemy,f_trap,f_down)
f_up_thru = boring(f_player,f_enemy,f_trap,f_up)

--physical objects
blox = {}--physics list
spawned = {}--new objects
graveyard = {}--waiting to be reanimated
dropdamp = 0.98--default falling friction
grav = 0.37--set g on a blok to simulate gravity
gravdir = 1--current gravity direction
minmove = 0.1--avoid micro-sliding, floating point error can lead to phasing
speedlimit = 8--arcade gravity
stars = {}

--heat map to push the chasers apart
enemyhot={}
hotdelay=10

us = nil--the player
them = {}--enemies
fx = {}

--add to print out debug
debug = {}
-- prev room offset, used only when wrapping the map
prevroomx,prevroomy = 0,0
-- the coordinates of the upper left corner of the camera
cam_x,cam_y = 0,0
frames=0

-- screen shake offset
shkx,shky = 0,0
-- screen shake speed
shkdelay,shkxt,shkyt=2,2,2


-- CLASSES
-- based on https://github.com/jonstoler/class.lua
-- i removed the getter setters, no idea if that
-- broke it but it seems to still work
classdef = {}

-- default (empty) constructor
function classdef:init(...) end

-- create a subclass
function classdef:extend(obj)
  local obj = obj or {}
  local function copytable(table, destination)
    local table = table or {}
    local result = destination or {}
    for k, v in pairs(table) do
      if not result[k] then
        if type(v) == "table" and k ~= "__index" and k ~= "__newindex" then
          result[k] = copytable(v)
        else
          result[k] = v
        end
      end
    end
    return result
  end
  copytable(self, obj)
  obj._ = obj._ or {}
  local mt = {}
  -- create new objects directly, like o = object()
  mt.__call = function(self, ...)
    return self:new(...)
  end
  setmetatable(obj, mt)
  return obj
end

-- create an instance of an object with constructor parameters
function classdef:new(...)
  local obj = self:extend({})
  if obj.init then obj:init(...) end
  return obj
end

function class(attr)
  attr = attr or {}
  return classdef:extend(attr)
end

-- Utilities

-- for when you need to send a list of stuff to print
function joinstr(...)
  local args = {...}
  local s = ""
  for i in all(args) do
    if type(i)=="boolean" then
      i = i and "true" or "false"
    end
    if s == "" then
      s = i
    else
      s = s..","..i
    end
  end
  return s
end

--print to debug
function debugp(...)
  add(debug,joinstr(...))
end

-- method is a function(c,r)
function forinrect(x,y,w,h,method)
  for c=x,(x+w)-1 do
    for r=y,(y+h)-1 do
      method(c,r)
    end
  end
end

function allmap(method)
  forinrect(0,0,16*8,16*4,method)
end

function add2(obj, ...)
  local args = {...}
  for table in all(args) do
    add(table, obj)
  end
end

function pick1(a,b)
  if(rnd(2)>1)return a
  return b
end

--tween a position - used for camera pans
tween = class()
-- sx,sy: start tx,ty:target, method:easing function, delay:total frames
function tween:init(sx,sy,tx,ty,method,delay)
  self.x,self.y,self.sx,self.sy = sx,sy,sx,sy
  self.cx,self.cy,self.method,self.t,self.delay = tx-sx,ty-sy,method,0,delay
  self.done = false
end

function tween:main()
  self.x,self.y = self.method(self.t,self.sx,self.cx,self.delay),self.method(self.t,self.sy,self.cy,self.delay)
  --add(debug,self.x)
  self.t+=1
  if(self.t >= self.delay) self.done = true
end
--http://gizma.com/easing/
--time,startvalue,change,duration
function ease_linear(t,b,c,d)
  return c*t/d+b
end
function ease_incubic(t,b,c,d)
  t /= d
  return c*t*t*t+b
end
function ease_outcubic(t,b,c,d)
  t /= d
  t-=1
  return c*(t*t*t+1)+b
end

--map sections (rooms)
rooms = {}
function getroom(c,r)
  --escape
  if(r<0 and rooms[c..","..r]) return rooms[c..","..r]
  --wrap
  if(c<0)c=7--we wrap at 8 rooms
  if(c>7)c=0
  if(r<0)r=3--we wrap at 4 rooms
  if(r>3)r=0
  local k = c..","..r
  if rooms[k] then
    return rooms[k]
  end
  return nil
end
currentroom = nil
prevroom = nil





--init----------------------
function _init()
  -- find and spawn player
  local usc,usr = 0,0
  local function makeus(x,y,force)
    local look=mget(x,y)
    --sword player, nosword, egg
    if look==1 or look==4 or look==54 or look==98 or force then
      if look==98 then
        look=1
        gravdir=-1
      end
      us = player(x,y,look==4,look==54)
      mset(x,y,0)
      usc,usr=flr(x/16),flr(y/16)
    end
  end
  allmap(makeus)

  --spawn at the starting room if i left no player on the map
  -- if(not us) makeus(10,36,true)
  add(blox, us)

  --rooms are defined by tile 96, there are 128x64 tiles to search
  local roomfind,roomrpl=16,3
  local function makerooms(x,y)
    if(mget(x,y)==roomfind) then
      --got a corner of a room
      local c,r,w,h = flr(x/16),flr(y/16),1,1
      --get the width, look for next room or end of this one
      for lx=x+16,x+128,16 do
        if(mget(lx,y)==roomfind or mget(lx-1,y)==roomfind) break
        w+=1
      end
      --get the height
      for ly=y+16,y+64,16 do
        if(mget(x,ly)==roomfind or mget(x,ly-1)==roomfind) break
        h+=1
      end
      room(c,r,w,h)
      --tile roomfind is for me to look at, change the corners to roomrpl
      mset(x,y,roomrpl)
      mset(x+w*16-1,y,roomrpl)
      mset(x+w*16-1,y+h*16-1,roomrpl)
      mset(x,y+h*16-1,roomrpl)

    end
  end
  allmap(makerooms)
  -- set currentroom
  currentroom = getroom(usc,usr)
  cam_x,cam_y=usc*128,usr*128
  --currentroom = getroom(0,0)
  currentroom:enter()
  us.coyote=1
  us:movey(gravdir*2)
  --exit room
  exitroom=room(3,-10,1,10)
  
end

--update----------------------
function _update()

  --end flight
  if ending and us.y < -4*64 then
    us.y+=128
    cam_y+=128
  end
  
  -- clear colision data
  for a in all(blox) do
    a.touchx,a.touchy = nil,nil
  end
  
  -- simulate
  us:upd()--player 1st for feels
  
  if us.goroom then
    prevroom = currentroom
    prevroom:exit()
    prevroom:movephantoms(prevroomx,prevroomy)
    currentroom = us.goroom
    us.goroom = nil
    if(prevroom==currentroom)prevroom:resetspawned()
    currentroom:enter()
    camtween = tween(
      cam_x+(prevroomx*8),cam_y+(prevroomy*8),us.goroomc*128,us.goroomr*128,ease_linear,30
    )
    --cam_go_x,cam_go_y = ship.goroomc*128,ship.goroomr*128
  end
  
  for a in all(blox) do
    if(a ~= us and a.active) a:upd()
  end
  
  -- garbage collect
  local good,i = {},1
  for a in all(blox) do
    if a.active then
      good[i] = a
      i += 1
    end
  end
  -- add spawned
  for a in all(spawned) do
    if a.active then
      good[i] = a
      i += 1
    end
  end
  blox,spawned = good,{}
  
  frames+=1
  
end

--draw----------------------
function _draw()
  cls()

  -- update camera position
  if camtween then
    camtween:main()
    cam_x,cam_y = camtween.x,camtween.y
    if camtween.done then
      camtween = nil
      if prevroom then
        if(prevroom~=currentroom)prevroom:resetspawned()
        prevroom:clearphantoms()
        prevroom = nil
      end
    end
  else
    local x,y = us:cam()
    local f = 0.5
    local scroll_x,scroll_y = (x-cam_x)*f,(y-cam_y)*f
    cam_x += scroll_x
    cam_y += scroll_y
  end
  camera(cam_x+shkx, cam_y+shky)
  if ending then
    drawstars()
    rectfill(cam_x,0,cam_x+128,128,0)
  end
  -- camera(0,0)
  -- map(0,0,0,0,16,16)
  -- draw room
  currentroom:draw()
  if(prevroom) prevroom:draw(prevroomx,prevroomy)
  -- draw backfx
  -- backfx = draw_active(backfx)
  -- draw actors
  -- bullets = draw_active(bullets)

  -- respawn warnings
  if us.respawncount > 0 then
    for a in all(graveyard) do
      local ax,ay = centertile(a.sc,a.sr)
      circ(ax,ay,us.respawncount/2,8)
    end
    local x,y = centertile(us.sc,us.sr)
    circ(x,y,us.respawncount+2,11)
    circ(x,y,us.respawncount,10)
  end

  --debug heat map
  -- currentroom:iterate(function(c,r)
  --   local h = enemyhot[c..","..r] or -hotdelay
  --   if frames-h < hotdelay then
  --     local tall = hotdelay - (frames-h)
  --     rectfill(c*8+1,(r+1)*8-tall,c*8+5,r*8+7,2)
  --   end
  -- end)


  them = draw_active(them)
  -- player
  if(us.active)us:draw()
  -- us:drawdbg()
  -- draw fx
  fx = draw_active(fx)

  --update screen shake
  if shkxt > 0 then
    shkxt-=1
    if shkxt == 0 then
      local sn = sgn(shkx)
      if sn > 0 then
        shkx = -shkx
      else
        shkx= -(shkx+1)
      end
      shkxt=shkdelay
    end
  end
  if shkyt > 0 then
    shkyt-=1
    if shkyt == 0 then
      local sn = sgn(shky)
      if sn > 0 then
        shky = -shky
      else
        shky= -(shky+1)
      end
      shkyt=shkdelay
    end
  end

  if ending then
    print("the end",cam_x+64-12,us.y+the_end_y,7)
    if(the_end_y<-24)the_end_y+=1
  end

  -- print out values added to debug
  local total,ty,good=#debug,0,{}
  for i=1,total do
    local s = debug[i]
    print(s,1+cam_x,1+cam_y+ty,7)
    ty += 8
    if(i > total-15) add(good, s)
  end
  debug = good

  -- -- draw blox
  -- for a in all(blox) do
  --   if a.active then a:draw() end
  -- end
  
  -- -- print out values added to debug
  -- local total,ty,good=#debug,0,{}
  -- for i=1,total do
  --   local s = debug[i]
  --   print(s,1+cam_x,1+cam_y+ty,7)
  --   ty += 8
  --   if(i > total-15) add(good, s)
  -- end
  -- debug = good
  
end

-- garbage collect drawings on the fly
function draw_active(table)
  local good,i = {},1
  for a in all(table) do
    if a.active then
      a:draw()
      -- if(a.drawdbg) a:drawdbg()
      good[i] = a
      i += 1
    end
  end
  return good
end
-- set screen shake
function shake(x,y)
  if(abs(x)>abs(shkx)) shkx,shkxt=x,shkdelay+1
  if(abs(y)>abs(shky)) shky,shkyt=y,shkdelay+1
end



-- draw stars
function drawstars()
  for st in all(stars) do
    local x,y,v,c = st.x,st.y,st.v,st.c
    
    y+=v

    if(x<cam_x+0)x+=128
    if(x>cam_x+127)x-=128
    if(y<cam_y+0)y+=128
    if(y>cam_y+127)y-=128
    pset(x,y,c)
    st.x,st.y=x,y
  end
end


--Engine
-- aabb recursive moving entity
blok = class()
blokn = 0--track instances of blok for debugging

-- x,y,w,h: bounds
-- flag: a pico 8 map flag
-- ignore: flags we want this blok to ignore
-- sp: sprite
function blok:init(x,y,w,h,flag,ignore,sp)
  self.active,self.x,self.y,self.w,self.h,self.flag,self.ignore,self.sp=
    true,x or 0,y or 0,w or 8,h or 8,flag or 0,ignore or 0,sp or 1
  self.vx,self.vy,self.dx,self.dy,self.touchx,self.touchy=
    0,0,0,0,nil,nil
  --up/downignore is set by the player object to allow it to jump thru ledges
  self.downignore,self.upignore = nil,nil
  --mom = floor, g = gravity, coyote = read as being on floor
  self.mom,self.g,self.coyote = nil,0,0
  blokn+=1
  self.n=blokn
end

--update
function blok:upd()
  --move x, then y, allowing us to slide off walls
  --avoid micro-sliding, floating point error can cause phasing
  if abs(self.vx) > 0.1 then
    self:movex(self.vx)
  end
  if abs(self.vy) > 0.1 then
    self:movey(self.vy)
  end
  --apply damping
  self.vx*=self.dx
  self.vy*=self.dy
  --fall
  if abs(self.g)~=0 then
    if not self.mom then
      self.vy+=self.g
      if(abs(self.vy)>speedlimit) self.vy=sgn(self.vy)*speedlimit
      if(self.coyote>0) self.coyote-=1
    else
      if self.coyote==0 and band(self.mom.flag,f_outside)==0 then
        self:dustflr(self.w+4)
        sfx(0)
      end
      self.coyote=3
    end
  end
end

function blok:movex(v)
  local x,y,w,h = self.x,self.y,self.w,self.h
  local edge,obstacles = v>0 and x+w or x,{}
  if v>0 then
    obstacles=getobstacles(x+w,y,v,h,self.ignore,self)
    sort(obstacles,rightwards)
  elseif v<0 then
    obstacles=getobstacles(x+v,y,abs(v),h,self.ignore,self)
    sort(obstacles,leftwards)
  end
  if #obstacles>0 then
    ob = obstacles[1];
    local obedge=v>0 and ob.x or ob.x+ob.w
    local shdmove = (edge+v)-obedge--how far should it move?
    self.touchx=ob
    v -= shdmove
  end
  
  self.x+=v
  
  --have i lost a parent?
  if self.mom then
    local p=self.mom
    if self.x>=p.x+p.w or self.x+self.w<=p.x then
      self.mom = nil
    end
  end
  
  return v
end

--jumping up thru ledges and moving plaforms
--makes this bit very hacky
function blok:movey(v)
  local x,y,w,h = self.x,self.y,self.w,self.h
  local edge,obstacles = v>0 and y+h or y,{}
  if v>0 then
    --ledge landing hack when moving down
    obstacles=getobstacles(x,y+h,w,v,self.downignore or self.ignore,self)
    sort(obstacles,downwards)
  elseif v<0 then
    --ledge landing hack when moving up
    obstacles=getobstacles(x,y+v,w,abs(v),self.upignore or self.ignore,self)
    sort(obstacles,upwards)
  end
  if #obstacles>0 then
    for ob in all(obstacles) do
      local obedge=v>0 and ob.y or ob.y+ob.h
      --break if v reduced to no overlap
      if (v>0 and obedge > edge+v) or (v<0 and obedge < edge+v) then break end
      --how far should it move?
      local shdmove,skip = (edge+v)-obedge,false
        --is there a special rule for landing on it?
      if v>0 and self.downignore then
        --skip this block if we were below its top
        if y+h>ob.y then skip=true end
      end
      if v<0 and self.upignore then
        --skip this block if we were above its bottom
        if y<ob.y+ob.h then skip=true end
      end
      if not skip then
        self.touchy=ob
        v -= shdmove
        --floor?
        if shdmove > 0 and self.g > 0 then
          self.mom=ob
          self.vy=0--cancel velocity
        end
        if shdmove < 0 and self.g < 0 then
          self.mom=ob
          self.vy=0--cancel velocity
        end
        --quit or shdmove will work in reverse
        if(abs(v)<000.1)break
      end
    end
  end
  
  self.y+=v
  
  --have i lost a parent?
  if self.mom then
    if self.g > 0 and self.y+self.h<self.mom.y then
      self.mom=nil
    end
    if self.g < 0 and self.mom.y+self.mom.h<self.y then
      self.mom=nil
    end
  end
  
  return v
end

function blok:death(src)--source of death
  self.active=false
end

function blok:draw(sp,offx,offy)
  local sp,offx,offy = sp or self.sp,offx or -4,offy or -4
  local x,y=offx+self.x+self.w*0.5,offy+self.y+self.h*0.5
  spr(sp,x,y,1,1,self.flipx,self.flipy)
end

function blok:drawdbg()
  rect(self.x,self.y,self.x+self.w-1,self.y+self.h-1,3)
 if self.mom then
   local m=self.mom
   line(self.x+self.w/2,self.y+self.h/2,m.x+m.w/2,m.y+m.h/2,3)
 end
 print(self.n,self.x,self.y-8,7)
end

function blok:center()
  return self.x+self.w*0.5,self.y+self.h*0.5
end

-- function blok:intersectsblok(a)
--   return not (a.x>=self.x+self.w or a.y>=self.y+self.h or self.x>=a.x+a.w or self.y>=a.y+a.h)
-- end

function blok:intersects(x,y,w,h)
  return not (x>=self.x+self.w or y>=self.y+self.h or self.x>=x+w or self.y>=y+h)
end

-- function blok:contains(x,y)
--   return x>=self.x and y>=self.y and x<self.x+self.w or y<self.y+self.h
-- end

--this fails at long distance
--the overflow causes 0,0,0 to be returned, watch for it
-- function blok:normalto(bx,by)
--   local ax,ay = self:center()
--   local vx,vy = (bx-ax),(by-ay)
--   local len = sqrt(vx*vx+vy*vy)
--   if(len > 0) return vx/len,vy/len,len
--   return 0,0,0
-- end

--x,y:position or x is an blok, v:speed, d:damping
-- function blok:moveto(x,y,v,d)
--   local tx,ty,len = self:normalto(x,y)
--   if(v > len) v = len
--   self.vx,self.vy,self.dx,self.dy = tx*v,ty*v,d,d
-- end

function blok:phantom()
  return spcopy(self.x+self.w*0.5,self.y+self.h*0.5,self.sp,fx,0,self.flipx,self.flipy)
end

function blok:dustflr(w)
  for i=1,w do
    dust(
      -w*0.5+self.x+self.w*0.5+rnd(w),
      self.y+((self.g>0) and self.h-1 or -1)+rnd(2),
      2,pick1(6,7)
    )
  end
end

-- function blok:dustx()
--   dust((self.flipx and self.x+self.w or self.x),
--           self.y+self.h/2+rnd(self.h/2),
--           2,pick1(6,7))
-- end
 
-- function blok:dusty()
--   dust(self.x+self.w/2,self.y+self.h,2,pick1(6,7))
-- end

-- collision utils

function cemterintile(x,y,c,r)
  return flr(x*0.125)==c and flr(y*0.125)==r
end

function intile(o,c,r)
  return o.x>=c*8 and o.y>=r*8 and o.x+o.w<=(c+1)*8 and o.y+o.h<=(r+1)*8 
end

function centertile(c,r,w,h)
  w,h = (w or 0),(h or 0)
  return (4+c*8)-w*0.5,(4+r*8)-h*0.5
end

function gettile(x,y)
  return flr(x*0.125),flr(y*0.125)
end

-- function intersectsmap(x,y,w,h)
--   local xmin, ymin = flr(x/8),flr(y/8)
--   local xmax, ymax = flr((x+w-0.0001)/8),flr((y+h-0.0001)/8)
--   for c=xmin,xmax do
--     for r=ymin,ymax do
--       if (fget(mget(c,r))>0) then
--         return true
--       end
--     end
--   end
--   return false
-- end

--return a table of objects describing tiles on the map
--ignore: do not return anything with this flag
--result: a table of results to add to
function mapobjects(x,y,w,h,ignore,result)
  result,ignore = result or {},ignore or 0
  local xmin, ymin = flr(x/8),flr(y/8)
  -- have to deduct a tiny amount, or we end up looking at a neighbour
  local xmax, ymax = flr((x+w-0.0001)/8),flr((y+h-0.0001)/8)
  local rxmin,rymin,rxmax,rymax = currentroom.x,currentroom.y,currentroom.x+currentroom.w-1,currentroom.y+currentroom.h-1

  for c=xmin,xmax do
    for r=ymin,ymax do
      --bounds check
      if c<rxmin or r<rymin or c>rxmax or r>rymax then
        add(result, {x=c*8,y=r*8,w=8,h=8,flag=f_out,sp=0})
      else
        local sp=mget(c,r)
        local f = fget(sp)
        if f > 0 and band(f, ignore) == 0 then
          add(result, {x=c*8,y=r*8,w=8,h=8,flag=f,sp=sp})
        end
      end
    end
  end
  return result
end

--return all blox or tiles in an area,
--excluding source from the list and anything with a flag it ignores
--tiles returned are basic versions of blox
function getobstacles(x,y,w,h,ignore,source)
  local result = {}
  ignore = ignore or 0
  mapobjects(x,y,w,h,ignore,result)
  for a in all(blox) do
    if a ~= source and a.active then
      if band(ignore, a.flag)==0 and a:intersects(x,y,w,h) then
        add(result, a)
      end
    end
  end
  return result
end

-- sorting comparators
function rightwards(a,b)
  return a.x>b.x
end
function leftwards(a,b)
  return a.x<b.x
end
function downwards(a,b)
  return a.y>b.y
end
function upwards(a,b)
  return a.y<b.y
end

--insertion sort
function sort(a,cmp)
  for i=1,#a do
    local j = i
    while j > 1 and cmp(a[j-1],a[j]) do
        a[j],a[j-1] = a[j-1],a[j]
    j = j - 1
    end
  end
end

--it's you murphy
player = blok:extend()

function player:init(c,r,nosword,egg)
  self.sc, self.sr = c,r -- spawn column & row
  c,r = c*8,r*8+1
  blok.init(self,c,r,6,6,f_player,f_char_thru,1)
  self.dx,self.dy,self.speed,self.g=
    0.5,dropdamp,1,grav*gravdir
  self.goroom,self.goroomc,self.goroomr=nil,0,0
  self.enterroomwait,self.respawncount=0,0
  self.flipy,self.sword,self.lockjump,self.nosword,self.egg = false,false,false,nosword or egg,egg
  self.sg,self.sflipy,self.ssword=self.g,self.flipy,self.sword--spawn settings
  self.camlook,self.flipignore,self.getsword=0,0,0
  self.downignore,self.upignore=f_down_thru,f_up_thru
  self.cangravswitch=true
  if(egg)self.eggcount=4
end

function player:upd()

  if self.enterroomwait > 0 then
    self.enterroomwait-=1
    return
  end
  if self.respawncount > 0 then
    self.respawncount-=1
    if self.respawncount == 0 then
      self:respawn()
      debrisblok(self,80,5,1)
      debrisblok(self,81,3,2)
      squode(self.x+self.w*0.5,self.y+self.h*0.5,4,11)
      debrisblok(self,68,7,3)
      
      for a in all(them) do
        a:respawn(true)--reset all
      end
      for a in all(graveyard) do
        a:respawn()--and all the dead come back too!
      end
      frames=0
      enemyhot={}
      graveyard = {}
      sfx(9)
    else
      return
    end
  end
  if self.getsword>0 then
    self.getsword-=1
    if self.getsword==0 then
      splode(self.x+self.w*0.5,self.y+self.h*0.5,8,9,fx,10)
      self.nosword=false
      shake(0,2)
      sfx(12)
    end
    return
  end

  --sword check
  if self.sword then
    local chk = getobstacles(self.x,(self.g>0) and (self.y+self.h)-2 or self.y-8,self.w,10,f_player)
    --found a trap
    for o in all(chk) do
      local c,r,sp = flr(o.x*0.125),flr(o.y*0.125),o.sp
      --destructible
      if sp == 19 or sp == 20 then
        mset(c,r,sp+64)
        debristile(c,r,80,3,2)
        debristile(c,r,81,3,1)
        squode(c*8+4,r*8+4,4,3,fx,11)
        shake(0,1)
        sfx(3)
      --enemies
      elseif sp==21 or sp==23 or sp==61 then
        o:death()
      --flip grav switch
      elseif (sp==34 or sp==50) and self.cangravswitch then
        if (sp==34 and self.g<0) or (sp==50 and self.g>0) then
          squode(c*8+4,r*8+4,4,12)
          sfx(2)
          gravdir = -gravdir
          --flip g for all
          for b in all(blox) do
            if b~=us and b.g~=0 then
              b.g,b.flipy,b.mom,b.vy=-b.g,b.g>0,nil,0
            elseif b.sp==23 then--flyer
              b.flipy=gravdir<0
            end
          end
          --change all grav switch
          local nsp=(sp==34) and 50 or 34
          allmap(function(c,r)
            local s = mget(c,r)
            if(s==sp) mset(c,r,nsp)
          end)
          --no gravswitching till next jump
          self.cangravswitch=false
        end
      end
    end
  end

  --trap check
  local traps = getobstacles(self.x,self.y,self.w,self.h,bnot(bor(f_trap,f_enemy)))
  -- found a trap
  for o in all(traps) do
    local c,r,sp = flr(o.x*0.125),flr(o.y*0.125),o.sp
    local x,y = self:center()
    
    --spikes
    if sp == 14 or sp == 15 or sp == 30 or sp == 31 then
      if(cemterintile(x,y,c,r)) self:death(o)
    --enemies
    elseif band(o.flag, f_enemy) > 0 then
      --sword pickup is special enemy
      if o.sp==6 then
        self.getsword=60
        o.active=false
        sfx(11)
        --overwrite respawn of sword with empty
        add(currentroom.spawned,{c=o.sc,r=o.sr,sp=0})
        return
      else
        if (not self.sword or o.sp==40 or o.sp==25)self:death(o)
      end
    --flip line
    elseif sp==38 then
      if self.flipignore==0 and not self.mom and cemterintile(x,y,c,r) then
        self.g=-self.g
        self.flipy=not self.flipy
        self.vy=self.g*3
        self.flipignore=4--need to escape trap collision
        sfx(8)
      end
    elseif sp==53 then
      ending=true
      speedlimit=4
    end

  end
  
  --EGG!!-------------------------
  if self.egg then
    if btnp(0) or btnp(1) or btnp(4) or btnp(5) then
      local strong=5-self.eggcount
      shake(strong*((self.eggcount%2)==0 and -1 or 1),0)
      debrisrect(self.x-3,self.y-11,10,10,81,strong*2,strong*0.25)
      debrisrect(self.x-3,self.y-11,10,10,80,strong,strong*0.5)
      self.eggcount-=1
      sfx(5)
      if self.eggcount==0 then
        self.egg=nil
        self.vy = -self.g*8
        self.mom,self.coyote=nil,0
        sfx(3)
      end
    end
  else
    -- move
    if btn(0) then
      self.vx -= self.speed
      self.flipx=true
    end
    if btn(1) then
      self.vx += self.speed
      self.flipx=false
    end
    --jump!
    local jumppress=(btn(4) or btn(5))
    if(not jumppress or abs(self.vy)>3) self.lockjump=false
    if self.coyote>0 and jumppress and not self.lockjump then
      if self.nosword then
        self.vy = -self.g*8
        sfx(10)
      else
        self:dustflr(self.w+6)
        self.g = -self.g
        self.vy = self.g*3
        self.sword=true
        self.cangravswitch=true
        sfx(1)
      end
      self.mom,self.coyote,self.lockjump=nil,0,true
    end
  end

  --simulate

  blok.upd(self)

  -- collision
  --player moves diagonally so we need to check both axes
  self:reacttouch(self.touchx)
  if(self.goroom)return
  self:reacttouch(self.touchy)
  if self.goroom then
    self.mom=nil
    return
  end

  --cancel accumulated speed when pushing
  if(self.touchx) self.vx=0
  if self.touchy then
    self.vy=0
    self.sword=false
    self.flipy=self.g<0
  end
  
  --call crumble
  if(self.mom and self.mom.crumble) self.mom:crumble()
  
  if self.flipignore>0 then self.flipignore-=1 end

end

function player:respawn(touch)
  self.x,self.y,self.active=self.sc*8,self.sr*8,true
  self.touchx,self.touchy,self.mom = nil,nil,nil
  self.g,self.flipy,self.sword=self.sg,self.sflipy,self.ssword
  self.vx,self.vy,self.camlook=0,0,0
  add(blox,self)
end

--can we beat up the player?
function player:ready()
  return self.enterroomwait == 0 and self.active
end

--where does the camera go?
function player:cam()
  local x,y = self:center()
  if(not self.active) x,y = centertile(self.sc,self.sr)
  self.camlook+=sgn(self.g)*2
  if(abs(self.camlook)>12)self.camlook=12*sgn(self.camlook)
  y+=self.camlook
  --if(abs(self.vy)>0) y+=sgn(self.g)*4
  --handle any size room of 128px units
  x = min(max(x-64, currentroom.x*8), -128+(currentroom.x+currentroom.w)*8)
  y = min(max(y-64, currentroom.y*8), -128+(currentroom.y+currentroom.h)*8)
  return x,y
end

--get wrecked
function player:death(src)
  if(not self.active)return
  self.respawncount,self.active = 30,false
  local x,y = self:center()
  -- burst(scirc,x,y,2,{8,9,10},20,3,0.8)
  debrisblok(self,69,7,2)
  debrisblok(self,68,5,1)

  splode(x,y,8,10)
  shake(0,4)
  sfx(7)
  -- sfx(-1,0)
  -- sfx(10)
  x,y = self:cam()
  camtween = tween(cam_x,cam_y,x,y,ease_outcubic,30)
end

--called after movement to react to each axis
function player:reacttouch(touch)
  if touch then
    -- trigger exit
    -- not prevroom: not animating the previous room
    if band(touch.flag, f_outside) > 0 and not prevroom then
      local tc,tr = gettile(touch.x+touch.w*0.5,touch.y+touch.h*0.5)
      local c,r = flr(tc*0.0625),flr(tr*0.0625)--n/16
      local room = getroom(c,r)
      
      if ending then
        f_out=f_wall
        --generate the stars
        for i=1,100 do
          local v,c = rnd(0.75),1
          if(v > 0.5) c=5
          add(stars, {x=cam_x+rnd(127),y=-128+cam_y+rnd(127),v=v,c=c} )
        end
      end

      if room then
        prevroomx,prevroomy=0,0
        -- push into next room
        if(touch.x>=self.x+self.w) self.x+=self.w
        if(touch.x+touch.w<=self.x) self.x-=self.w
        if(touch.y>=self.y+self.h) self.y+=self.h
        if(touch.y+touch.h<=self.y) self.y-=self.h
        -- map wrap
        if self.x>=1024 then--8 rooms
          self.x-=1024
          c-=8
          tc-=128
          prevroomx=-128
        end
        if self.x+self.w<=0 then
          self.x+=1024
          c+=8
          tc+=128
          prevroomx=128
        end
        if self.y>=512 then--4 rooms
          self.y-=512
          r-=4
          tr-=64
          prevroomy=-64
        end
        if self.y+self.h<=0 and room~=exitroom then
          self.y+=512
          r+=4
          tr+=64
          prevroomy=64
        end
        self.goroomc,self.goroomr,self.sc,self.sr = c,r,tc,tr
        self.sg,self.sflipy,self.ssword=self.g,self.flipy,self.sword
        -- reset frames/blokn to avoid overflow
        self.goroom,self.enterroomwait,frames,blokn=room,30,0,1
        enemyhot={}
        self.touch,self.touchx,self.touchy,self.camlook=nil,nil,nil,0
        -- sfx(-1,0)--stop shooting sound
        return
      end
    elseif band(touch.flag, f_wall) == 0 and band(touch.flag, f_enemy) > 0 then
      --add(debug, joinstr(touch.flag,f_wall,band(touch.flag,f_player_shot)))
      self:death(touch)
      return
    end
  end
end

function player:draw(sp)
  local x,y=self:center()
  if self.egg then
    x+=-shkx
    spr(54,x-8,y-4)
    spr(55,x,y-4)
    spr(48,x-8,y-12)
    spr(49,x,y-12)
    return
  end
  local framen=((frames/2)%2);
  if self.getsword>0 then
    circfill(x-1,y-1,7+framen,4)
    circfill(x-1,y-1,5+framen,9)
    circ(x,y,self.getsword,10)
    circ(x,y,self.getsword+2,9)
  end  
  sp = sp or self.sp
  local offx,offy,flipy=-4,-3,self.flipy
  if(self.nosword)sp=4
  if self.sword then
    if flipy then offy-=2 end
    blok.draw(self,32+framen,offx,offy+(flipy and 8 or -8))
    blok.draw(self,17+framen,offx,offy)
  else
    if not flipy then offy-=2 end
    local f=((abs(self.vx)>0.1) and framen or 0)
    if(self.coyote==0)f=1
    blok.draw(self,sp+f,offx,offy)
  end
end

--enemies
enemy = blok:extend()

function enemy:init(c,r,sp,dirx,diry)
  self.sc, self.sr = c,r -- spawn column & row
  c,r = c*8,r*8
  self.speed=1
  blok.init(self,c,r,6,6,f_enemy,f_char_thru,sp)
  self.dx,self.dy,self.speed,self.g=
    0,dropdamp,1,grav*gravdir
  self.dirx,self.diry,self.sdirx,self.sdiry=dirx,diry,dirx,diry
  self.flipy=(self.g<0)
  self.downignore,self.upignore=f_down_thru,f_up_thru
  if sp==21 or sp==25 or sp== 61 then--walker
    self.flipx,self.coyote=dirx<0,2
    self:movey(gravdir*2)
  elseif sp==23 or sp==40 or sp==6 then--flyer
    self.g,self.dy=0,0
  end
end


function enemy:upd()

  if(not us:ready()) return
  local cx,cy = self:center()

  if self.sp==61 then--chaser

    local c,r = gettile(cx,cy)
    local k = c..","..r
    local h = enemyhot[k] or -hotdelay

    if frames-h>hotdelay then
      if us.x+us.w<self.x then
        self.dirx=-1
        self.flipx=true
      elseif us.x>self.x+self.w then
        self.dirx=1
        self.flipx=false
      end
    end
    enemyhot[k]=frames

  else
    --direction command check
    local floor = mapobjects(self.x,self.y,self.w,self.h,bnot(f_trap))
    if #floor > 0 then
      -- found a trap
      local f = floor[1]
      local c,r,s = flr(f.x/8),flr(f.y/8),f.sp
      -- is it a dir command?
      if s>=8 and s<=11 then
        -- dir commands start at 8
        local x,y,n=0,0,s-8
        if n==0 then
          x=-1
        elseif n==1 then
          x=1
        elseif n==2 then
          y=-1
        elseif n==3 then
          y=1
        end
        if intile(self,c,r) then
          if self.g==0 then--flyer
            self.dirx,self.diry=x,y
          else
            if dirx~=0 then--walker
              self.dirx=x
              self.flipx=(x<0)
            end
          end
        end
      end
    end
  end
  -- move
  local sp,speed = self.sp,self.speed
  
  self.vx = speed * self.dirx
  if self.g==0 then
    self.vy = speed * self.diry
  end
  blok.upd(self)
  -- turn around when bump
  if self.touchx then
    if sgn(self.touchx.x+self.touchx.w*0.5-cx)==self.dirx then
      self.dirx = -self.dirx
      if(self.g~=0)self.flipx=(self.dirx<0)
    end
  elseif self.touchy then
    if self.g==0 then
      if sgn(self.touchy.y+self.touchy.h*0.5-cy)==self.diry then
        self.diry = -self.diry
      end
    else
      --kill on outside
      if band(self.touchy.flag,f_outside)>0 then
        self:death()
      end
    end
  end

end

--can use this to reset an enemy as well
function enemy:respawn(just_reset)
  if(self.sp==6)return--sword pickup
  if(just_reset)splode(self.x+self.w*0.5,self.y+self.h*0.5,4,2,fx,8)
  self.active,self.touch,self.touchx,self.touchy,self.mom=true,nil,nil,nil,nil
  self.x,self.y = centertile(self.sc,self.sr,self.w,self.h)
  self.dirx,self.diry=self.sdirx,self.sdiry
  if self.g~=0 then
    self.g=abs(self.g)*gravdir
    self.flipy=(self.g<0)
  end
  if(not just_reset)add2(self,blox,them)
  squode(self.x+self.w*0.5,self.y+self.h*0.5,4,14)
end

function enemy:death(src)
  self.active=false
  debrisblok(self,96,7,2)
  debrisblok(self,97,5,1)
  local x,y=self:center()
  splode(x,y,6,8)
  sfx(4)
  shake(0,2)
  add(graveyard, self)
end


function enemy:draw(sp)
  sp = sp or self.sp
  local offx,offy,flipy=-4,-3,self.flipy
  local f=(frames/3)%2;
  if self.g==0 then
    if sp==40 then
      blok.draw(self,sp+(flr(frames/2)%4))
    else
      blok.draw(self,sp+f,offx,offy)
    end
  else
    if self.g>0 then offy-=2 end
    if(self.coyote==0)f=1
    blok.draw(self,sp+f,offx,offy)
  end
end

crumbleflr = blok:extend()

function crumbleflr:init(c,r,sp,w)
  self.sc,self.sr=c,r
  blok.init(self,c*8,r*8,w,8,f_wall,0,sp)
  self.crumbling=false
  self.count=30
end

function crumbleflr:crumble()
  if(not self.crumbling)self.crumbling=true 
end

function crumbleflr:upd()
  if self.crumbling then
    self.count-=1
    if self.count==28 then
      debrisblok(self,64,self.w/4)
      debrisblok(self,80,self.w/8)
      sfx(5)
    end
    if self.count<=0 then
      self.flag=f_trap
      for b in all(blox) do
        if(b.mom==self)b.mom=nil
      end
      self.count,self.crumbling=-60,false
      debrisblok(self,64,self.w/2)
      debrisblok(self,80,self.w/8)
      sfx(6)
    end
  elseif self.count<0 then
    self.count+=1
    if self.count>=0 then
      local obs=getobstacles(self.x, self.y, self.w, self.h)
      if #obs==1 then
        self:respawn()
      else
        self.count=-1
      end
    end
  end
end

function crumbleflr:phantom()
  if self.w==8 then
    return blok.phantom(self)
  else
    local temp,sp={islist=true},self.sp
    if(self.count<=28)sp+=1
    if self.count<=0 then
      sp+=1
      if(self.count>-5)sp-=1
    end
    for x=self.x,self.x+self.w-8,8 do
      add(temp,spcopy(x+4,self.y+4,sp,fx,0))
    end
    return temp
  end
end

function crumbleflr:respawn(just_reset)
  self.flag,self.count=f_wall,30
end

function crumbleflr:draw(sp)
  local sp,y=self.sp,self.y
  if(self.count<=28)sp+=1
  if self.count<=0 then
    sp+=1
    if(self.count>-5)sp-=1
  end
  for x=flr(self.x),self.x+self.w-8,8 do
    spr(sp,x,y)
  end
  --line(self.x,self.y,0,0)
end

--gravity affected slab
slab = blok:extend()

function slab:init(c,r,sp)
  self.sc, self.sr = c,r
  c,r = c*8,r*8
  blok.init(self,c,r,8,8,f_wall,boring(f_trap,f_up,f_down),sp)
  self.dx,self.dy,self.g=
  0,dropdamp,grav*gravdir
  self.downignore = bor(f_trap,f_down)
  self.upignore = bor(f_trap,f_up)
  self.flipy=(self.g<0)
  self.coyote=1
end

function slab:mergeslab(o)
  if o.y < self.y then
    self.y=o.y
  end
  self.h+=o.h
  o.active=false
  -- debugp(self.y,self.h,self.n,o.n)
end

function slab:pushslab(vy)
  self:movey(vy)
  if(self.touchy)self:chkkill()
end

function slab:upd()
  blok.upd(self)
  if(self.touchy) self:chkkill()
end

function slab:chkkill()
  if self.touchy.death then
    if band(self.touchy.flag,bor(f_wall,f_ledge_thru))==0 then
      self.touchy:death(self)
      self.touchy,self.mom=nil,nil
    elseif self.touchy.mergeslab then
      self:mergeslab(self.touchy)
      self.touchy,self.mom=nil,nil
    end
  end
end

function slab:respawn(just_reset)
  --does not respawn
end

function slab:phantom()
  if self.h==8 then
    return blok.phantom(self)
  else
    local temp={islist=true}
    for y=flr(self.y),self.y+self.h-8,8 do
      add(temp,spcopy(self.x+4,y+4,self.sp,fx,0,self.flipx,self.flipy))
    end
    return temp
  end
end

function slab:draw(sp)
  local sp,y=self.sp,self.y
  if(not self.mom)sp+=1
  for y=flr(self.y),self.y+self.h-8,8 do
    spr(sp,self.x,y,1,1,self.flipx,self.flipy)
  end
  --line(self.x,self.y,0,0)
end

room = class()

-- default room size is 16x16 tiles, there are 8x4 rooms, 128x64 tiles
function room:init(c,r,cw,ch)
  -- c,r,cw,ch is the room slot position and size
  c,r,cw,ch=c or 0,r or 0,cw or 1,ch or 1
  -- x,y,w,h are measurements in tiles
  local x,y,w,h = c*16,r*16,cw*16,ch*16
  self.c,self.r,self.x,self.y,self.w,self.h,self.cw,self.ch=
    c,r,x,y,w,h,cw,ch
  for i=c,c+(cw-1) do
    for j=r,r+(ch-1) do
      rooms[i..","..j] = self
    end
  end
  self.spawned,self.phantoms = {},{}
end

function room:enter()
  local function create(c,r)
    local sp = mget(c,r)
    local flag = fget(sp)
    --enemies
    if band(flag, f_enemy) > 0 then
      self:to_reset(c,r,sp)
      local x,y=0,0
      if inrange(sp,44,46) then
        if(sp==44)x=-1
        if(sp==45)y=-1
        if(sp==46)y=1
        sp=40
      elseif inrange(sp,58,60) then
        if(sp==58)x=-1
        if(sp==59)y=-1
        if(sp==60)y=1
        sp=23
      elseif sp==56 then
        x=-1
        sp=21
      elseif sp==57 then
        x=-1
        sp=25
      elseif sp==6 then
        --sword pickup
      else
        x=1
      end          
      add2(enemy(c,r,sp,x,y), blox, them)
      -- mset(c,r,114)
    --grav slab
    elseif sp == 36 then
      self:to_reset(c,r,sp)
      add2(slab(c,r,sp), blox, them)
    --flip line
    elseif sp == 38 then
      blinky(c,r,sp,39,fx,10,self)
    --crumble floor
    elseif sp == 27 then
      --expand by reading ahead rightwards
      local x,w=c,0
      while(mget(x,r)==sp)do
        self:to_reset(x,r,sp)
        x+=1
        w+=8
      end
      add2(crumbleflr(c,r,sp,w),blox,them)
    end
  end
  self:iterate(create)
  --dock slabs to floor
  for b in all(blox) do
    if b.pushslab and b.active then
      while(not b.mom) do
        b:pushslab(16*8*gravdir)
      end
    end
  end
end

function inrange(n,a,b)
  return n >= a and n <= b
end

function room:to_reset(c,r,sp)
  mset(c,r,0)
  add(self.spawned,{c=c,r=r,sp=sp})
end

function room:exit()
  fx={}
  --create images of spawned monsters
  local p = self.phantoms
  for a in all(them) do
    a.active=false
    local phantom = a:phantom()
    if phantom.islist then
      del(phantom, true)
      for o in all(phantom) do
        add(p, o)
      end
    else
      add(p, phantom)
    end
  end
  graveyard = {}--empty for new respawns
end

--when wrapping we fake the room position, so phantoms come too
function room:movephantoms(c,r)
  c*=8
  r*=8
  for a in all(self.phantoms) do
    a.x+=c
    a.y+=r
  end
end

function room:clearphantoms()
  for a in all(self.phantoms) do
    a.active = false
  end
  self.phantoms = {}
end

function room:resetspawned()
  for a in all(self.spawned) do
    mset(a.c,a.r,a.sp)
  end
  self.spawned = {}
end

-- method is a function(c,r)
function room:iterate(method)
  local x,y,w,h = self.x,self.y,self.w,self.h
  for c=x,(x+w)-1 do
    for r=y,(y+h)-1 do
      method(c,r)
    end
  end
end

--change all a tiles to b tiles
-- function room:swapsp(a,b)
--   self:iterate(function(c,r)
--     local sp = mget(c,r)
--     if(sp==a) mset(c,r,b)
--   end)
-- end

function room:draw(offx,offy)
  --offset, for when faking wrap
  offx,offy=offx or 0,offy or 0
  map(self.x, self.y, (self.x+offx)*8, (self.y+offy)*8, self.w, self.h)
end
  
-- function room:contains(x,y,w,h)
--   local rx,ry,rw,rh = self.x*8,self.y*8,self.w*8,self.h*8
--   return not (x + w <= rx or y + h <= ry or rx + rw <= x or ry + rh <= y)
-- end

-- function room:inside(x,y,w,h)
--   local rx,ry,rw,rh = self.x*8,self.y*8,self.w*8,self.h*8
--   return x >= rx and y >= ry and x + w <= rx + rw and y + h <= ry + rh
-- end

-- function room:onborder(x,y)
--   local rx,ry,rw,rh = self.x,self.y,self.w,self.h
--   return x == rx or y == ry or x == rx+rw-1 or y == ry+rh-1
-- end

-- just a sprite from the sheet
spcopy = class()
function spcopy:init(x,y,sp,table,t,flipx,flipy)
  self.active,self.x,self.y,self.sp,table,self.t,self.flipx,self.flipy=
    true,x or 64,y or 64,sp or 1,table or fx,t or 0,flipx,flipy
  -- add to a list for drawing
  add(table, self)
end
function spcopy:draw(sp)
  sp = sp or self.sp
  spr(self.sp,-4+self.x,-4+self.y,1,1,self.flipx,self.flipy)
  if self.t > 0 then
    self.t-=1
    if self.t == 0 then
      self.active=false
    end
  end
end
--for flashing map tiles
blinky=spcopy:extend()
function blinky:init(c,r,spa,spb,table,t,room)
  self.c,self.r,self.spa,self.spb,self.delay,self.room=
    c,r,spa,spb,t,room or currentroom
  spcopy.init(self,c*8,r*8,spa,table,t)
end
function blinky:draw()--6733
  if (self.t <= 0) self.t=self.delay
  if self.t > self.delay*0.5 then
    spr(self.spa,self.x,self.y)
  else
    spr(self.spb,self.x,self.y)
  end
  self.t-=1
  --garbage collect when room changes or spa ~= mget(c,r)
  if(self.room ~= currentroom or mget(self.c,self.r) ~= self.spa) self.active=false
end

dust=class()
function dust:init(x,y,r,c)
  self.active,self.x,self.y,self.r,self.c=true,x,y,r,c
  add(fx,self)
end
function dust:draw()
  circfill(self.x,self.y,self.r,self.c)
  self.r-=0.2
  self.y+=0.1
  if(self.r<=0) self.active=false
end

-- bang
splode = class()
function splode:init(x,y,r,col,table,colw)
  self.active,self.x,self.y,self.r,self.t,self.col,self.colw,table=
    true,x or 64,y or 64,r or 8,0,col or 7,colw or 7,table or fx
  -- add to a list for drawing
  add(table, self)
end
function splode:draw()
  local t,x,y,r,col,colw = flr(self.t*0.5),self.x,self.y,self.r,self.col,self.colw
  if t == 0 then
    --black frame to make it pop
    circfill(x,y,r,colw)
    circfill(x,y,r-1,0)
  elseif t < 2 then
    --full
    circfill(x,y,r,col)
    circfill(x,y,r-1,colw)
  else
    --shrink
    if t <= r then
      for rf=t,r do
        if rf==r then
          circ(x,y,rf,col)
        else
          circ(x,y,rf,colw)
        end
      end
    else
      self.active = false
    end
  end
  self.t+=1
end

--square splode
squode = splode:extend()
function squode:init(x,y,r,col,table,colw)
  splode.init(self,x,y,r,col,table,colw)
end
function squode:draw()
  local t,x,y,r,col,colw = flr(self.t*0.5),self.x,self.y,self.r,self.col,self.colw
  if t == 0 then
    --black frame to make it pop
    squarfill(x,y,r,colw)
    squarfill(x,y,r-1,0)
  elseif t < 2 then
    --full
    squarfill(x,y,r,col)
    squarfill(x,y,r-1,colw)
  else
    --shrink
    if t <= r then
      for rf=t,r do
        if rf==r then
          squar(x,y,rf,col)
        else
          squar(x,y,rf,colw)
        end
      end
    else
      self.active = false
    end
  end
  self.t+=1
end
function squar(x,y,s,c)
  rect(x-s,y-s,x+s,y+s,c)
end
function squarfill(x,y,s,c)
  rectfill(x-s,y-s,x+s,y+s,c)
end

debris=class()
function debris:init(x,y,sp,vx,vy)
  self.active,self.x,self.y,self.sp,self.vx,self.vy,self.flipx=
    true,x,y,sp,vx,vy,(rnd(2)>1 and true or false)
end
function debris:draw()
  spr(self.sp,self.x,self.y,1,1,self.flipx)
  self.x+=self.vx
  self.y+=self.vy
  --apply damping
  self.vx*=dropdamp
  self.vy*=dropdamp
  self.vy+=grav*gravdir
  if (gravdir>0 and self.y>cam_y+128 or gravdir<0 and self.y<cam_y) self.active=false
end

function debristile(c,r,sp,num,pwr)
  debrisrect(c*8,r*8,8,8,sp,num,pwr)
end
function debrisblok(b,sp,num,pwr)
  debrisrect(b.x,b.y,b.w,b.h,sp,num,pwr)
end
function debrisrect(x,y,w,h,sp,num,pwr)
  pwr=pwr or 1
  for i=1,num do
    add(fx,debris(x+rnd(w),y+rnd(h),sp,-2+rnd(4),(1+rnd(1))*-gravdir*pwr))
  end
end

