--valdi:beginnings
--ldjam 42 - tom brinton
--todo:
--x fix level reset
--x particle anims 
--x  got jewel
--x  beamed up
--x  when stuck
--x add automaton valdi

gamemode="title"

w=0
h=0
m={}
level={}

level[1]={}
level[1].w=3
level[1].h=3
level[1].m={{1,2,1},
            {1,2,1},
            {1,2,1}}
level[1].s={1,2}
level[1].k={{2,2}}
level[1].e={4,2}

level[2]={}
level[2].w=4
level[2].h=4
level[2].m={{2,1,1,1},
            {1,3,3,1},
            {1,3,3,1},
            {3,1,1,2}}
level[2].s={4,4}
level[2].k={{1,1}}
level[2].e={4,5}

level[3]={}
level[3].w=5
level[3].h=5
level[3].m={{1,3,1,1,3},
            {1,0,1,0,1},
            {1,1,2,1,1},
            {1,0,1,0,1},
            {3,1,1,1,3}}
level[3].s={1,1}
level[3].k={{1,5}}
level[3].e={6,3}



level[4]={}
level[4].w=5
level[4].h=6
level[4].m={{0,3,1,3,1,3},
            {3,1,3,1,3,0},
            {3,1,1,2,3,0},
            {3,1,3,1,3,0},
            {0,3,1,3,1,3}}
level[4].s={2,2}
level[4].k={{2,4},{4,4}}
level[4].e={6,5}

level[5]={}
level[5].w=4
level[5].h=10
level[5].m={{1,1,2,1,1,1,1,1,1,1},
            {1,0,1,0,3,0,1,0,1,3},
            {1,0,1,0,3,0,1,0,1,1},
            {1,1,1,0,1,1,2,1,1,1}}
level[5].s={1,1}
level[5].k={{4,1},{4,3},{1,2},{1,4},{1,7},{4,6},{1,9},{4,8}}
level[5].e={5,10}

level[6]={}
level[6].w=6
level[6].h=6
level[6].m={{1,1,1,1,1,0},
            {1,0,1,0,1,0},
            {1,2,1,1,1,1},
            {0,1,0,3,0,1},
            {1,1,1,2,1,1},
            {3,0,3,0,3,0}}
level[6].s={3,2}
level[6].k={{5,3}}
level[6].e={7,5}
level[6].a={3,4}

level[7]={}
level[7].w=6
level[7].h=7
level[7].m={{1,1,3,1,3,1,1},
            {3,1,0,1,1,1,3},
            {1,1,1,1,1,1,1},
            {3,1,1,1,1,1,3},
            {1,1,1,1,1,1,1},
            {3,1,3,1,3,1,3}}
level[7].s={1,1}
level[7].k={{3,3},{3,5},{5,3},{5,5}}
level[7].e={7,6}
level[7].a={2,2}

level[8]={}
level[8].w=5
level[8].h=5
level[8].m={{1,1,3,0,0},
            {1,0,1,0,0},
            {3,1,1,1,1},
            {0,0,1,0,3},
            {0,0,1,1,1}}
level[8].s={1,1}
level[8].k={{5,3}}
level[8].e={6,5}
level[8].a={3,5}

level[9]={}
level[9].w=6
level[9].h=5
level[9].m={{0,1,0,1,0},
            {1,1,0,1,0},
            {1,1,0,1,1},
            {0,1,0,3,1},
            {0,1,0,0,1},
            {0,3,0,0,1}}
level[9].s={1,2}
level[9].k={{3,1}}
level[9].e={7,2}
level[9].a={1,4}

level[10]={}
level[10].w=7
level[10].h=7
level[10].m={{1,1,1,3,1,1,1},
            {1,3,0,1,0,3,1},
            {1,0,0,3,0,0,1},
            {1,0,1,2,1,0,3},
            {1,0,0,3,0,0,1},
            {1,3,0,1,0,3,1},
            {1,1,1,1,1,1,0}}
level[10].s={1,7}
level[10].k={{4,1},{7,4}}
level[10].e={7,7}
level[10].a={4,4}

level[11]={}
level[11].w=2
level[11].h=5
level[11].m={{1,3,2,2,1},
            {1,3,2,1,1}}
level[11].s={1,1}
level[11].k={{1,5}}
level[11].e={3,3}
level[11].a={2,1}

level[12]={}
level[12].w=3
level[12].h=3
level[12].m={{2,2,1},
            {2,2,1},
            {0,2,0}}
level[12].s={1,1}
level[12].k={{1,3}}
level[12].e={4,2}
level[12].a={3,2}

level[13]={}
level[13].w=4
level[13].h=3
level[13].m={
            {3,1,3},
            {2,2,2},
            {2,0,1},
            {1,1,1}
            }
level[13].s={2,2}
level[13].k={{2,1},{2,3},{4,1},{4,3}}
level[13].e={3,2}
level[13].a={1,2}

level[14]={}
level[14].w=4
level[14].h=8
level[14].m={
            {0,1,1,0,1,1,1,0},
            {1,1,1,1,1,0,3,0},
            {0,1,0,0,1,1,1,1},
            {0,1,1,1,1,0,0,1}
            }
level[14].s={2,1}
level[14].k={{4,2},{3,5}}
level[14].e={5,8}
level[14].a={1,2}

level[15]={}
level[15].w=5
level[15].h=10
level[15].m={
            {1,1,1,1,0,0,3,3,3,3},
            {1,2,1,1,0,0,3,1,1,3},
            {2,2,2,3,0,0,3,2,2,0},
            {1,2,1,1,0,0,3,1,1,3},
            {1,1,1,1,0,0,3,3,3,3}
            }
level[15].s={3,1}
level[15].k={{1,1},{1,3},{5,1},{5,3}}
level[15].e={3,5}
level[15].a={4,8}



drops={}
lev=1

p={}
p.x=0
p.y=0
p.sx=0
p.sy=0
p.d=1
p.s=5

at={}
at.x=0
at.y=0
at.sx=0
at.sy=0
at.d=1
at.s=37
at.active=false

keys={}

ex={}
ex.x=0
ex.y=0

particles={}

bgcol=1
drawh=1


function _init()
 music(0)
end

function _update()
 if gamemode=="title" then
    bgcol=1
	if btnp(4) then
	 lev=1
	 gamemode="play"
	 loadlevel()
	 sfx(3)
	 
	end
 elseif gamemode=="play" then
	bgcol=1
	 foreach(keys,getkey)
	 
	 checkstuck()
	 moveplayer()
	 checkwin()
	 if btnp(4) then
	  sfx(4)
	  createparticles(p.x,p.y,15,14)
	  stuckanim()
	  loadlevel()
	 end

 elseif gamemode=="win" then
    bgcol=3
	if btnp(4) then
	 gamemode="title"
	 sfx(3)
	 
	end
	if rnd(100) >95 then
	 createparticles(rnd(8),rnd(16),30,11)
	end
 end

 
end


function _draw()
 cls(bgcol)
 drawwaves()
 if gamemode=="title" then
	map(0,0,39,48,6,3)
	print("z to begin",43,80,0)
 elseif gamemode=="play" then
	 foreach(drops,drawdrop)
	 drawmap()
	 foreach(particles,drawparticle)
	 for d = 1,h do
	  drawh=d
	  foreach(keys,drawkey)
	  if drawh == p.y then drawplayer(p) end
	  if at.active and drawh==at.y then drawplayer(at) end
	 end
	 print("level "..lev.."/"..#level, 4,4,6)
 elseif gamemode=="win" then
    foreach(particles,drawparticle)
    map(0,3,32,48,8,3)
	print("z to restart",40,80,0)
 end
 
end

function drawwaves()
wy=32
g=t()/8
for wx=0,135,4 do
 for wy = 0,128,32 do
	 --fillp(0b0100101000010000.1)

	 fillp(0b0000011010010000.1)

	 circfill(wx,wy+8*sin(wx/127+g),7,0)
	 fillp()
 end
end
end

function drawmap()
 for i=1,w do
 for j=1,h do
  mx=(48-(w*8))+i*16
  my=(56-(h*4))+j*8
  if m[i][j]==1 then
   spr (3,mx,my,2,2)
  elseif m[i][j]==2 then
   spr (1,mx,my,2,2)
  elseif m[i][j]==3 then
   spr (11,mx,my,2,2)
  end
 end
 end
 --draw exit
 if not keysgot() then
	 spr(13,(48-(w*8))+ex.x*16,(56-(h*4))+ex.y*8,2,2)
 else
	 spr(32,(48-(w*8))+ex.x*16,(56-(h*4))+ex.y*8,2,2)
 end
end

function drawkey(k)
 if not k.got and k.y==drawh then
  spr (23,(48-(w*8))+k.x*16,(56-(h*4))+k.y*8,2,1)
  spr (34,(48-(w*8))+k.x*16,(44-(h*4))+k.y*8+(sin(k.x*g/7)*3),2,2)
 end
end

function drawplayer(p)
 if p.sx<p.x*16 then p.sx+=4 end
 if p.sx>p.x*16 then p.sx-=4 end
 if p.sy<p.y*8 then p.sy+=4 end
 if p.sy>p.y*8 then p.sy-=4 end
 spr (7,(48-(w*8))+p.x*16,(56-(h*4))+p.y*8,2,1)
 if p.d==1 then
 spr (p.s,(48-(w*8))+p.sx,(44-(h*4))+p.sy,2,2)
 else
 spr (p.s,(48-(w*8))+p.sx,(44-(h*4))+p.sy,2,2,true,false)
 
 end
end

function moveplayer()
 if btnp(⬆️) and isground(p.x,p.y-1) then
  createdrop()
  p.y-=1
  moveauto(0,-1)
 elseif btnp(⬇️) and isground(p.x,p.y+1) then
  createdrop()
  p.y+=1
  moveauto(0,1)
 elseif btnp(⬅️) and isground(p.x-1,p.y)then
  createdrop()
  p.x-=1
  p.d=0
  moveauto(-1,0)
 elseif btnp(➡️) and isground(p.x+1,p.y)then
  createdrop()
  p.x+=1
  p.d=1
  moveauto(1,0)
 end
end

function moveauto(ax,ay)
 if isground(at.x+ax,at.y+ay) then
  autodrop()
  at.x+=ax
  at.y+=ay
  
 end
 at.d=p.d
end

function getkey(key)
 if p.x==key.x and p.y==key.y and not key.got then
  key.got=true
  sfx(5)
  createparticles(p.x,p.y,30,11)
 end 
end

function keysgot()
 for key in all(keys) do
  if not key.got then return false end
 end
 return true
end

function isground(gx,gy)
 if at.active and gx==at.x and gy==at.y then
  return false
 end
 
 if gx>0 and gy>0 and gx<=w and gy<=h and m[gx][gy]!=0 then return true end
 if keysgot() and gx==ex.x and gy==ex.y then
  return true
 end
 
 return false
end

function checkwin()
 if p.x==ex.x and p.y==ex.y then
  if lev==#level then
   gamemode="win"
   
   return
  end
  sfx(3)
  createparticles(p.x,p.y,50,3)
  winanim()
  lev+=1
  loadlevel()
 end
end

function winanim()
 for i=1,35 do
  if i>15 then
  	p.y-=1
  end
  _draw()
  drawplayer(p)
  flip()
 end
 for i=1,15 do
  for j=1,500 do
   rx=flr(rnd(127))
   ry=flr(rnd(127))
   circfill(rx,ry,i,0)
  end
  flip()
 end
end

function checkstuck()
 if not isground(p.x,p.y) then goto _ end
 if isground(p.x-1,p.y) then return end
 if isground(p.x+1,p.y) then return end
 if isground(p.x,p.y-1) then return end
 if isground(p.x,p.y+1) then return end
 ::_::
 sfx(4)
 createparticles(p.x,p.y,15,14)
 stuckanim()
 loadlevel()
end

function stuckanim()
 bgcol=2
 for i=1,15 do
  _draw()
  flip()
 end
 for i=1,20 do
 _draw()
 for i=1,5 do
  ly=ceil(rnd(127))
  line(ceil(rnd(64)-32),ly,ceil(rnd(64))+96,ly,ceil(rnd(2))+5)
 end
 flip()
 end
 bgcol=1
end

function loadlevel()
 w=level[lev].w
 h=level[lev].h
 clear(keys)
 clear(drops)
 clear(particles)
 clear(m)
 m=deepcopy(level[lev].m)
 p.x=level[lev].s[1]
 p.sx=p.x*16
 p.y=level[lev].s[2]
 p.sy=p.y*8
 for key in all(level[lev].k) do
  local k={}
  k.x=key[1]
  k.y=key[2]
  k.got=false
  add(keys,k)
 end
 ex.x=level[lev].e[1]
 ex.y=level[lev].e[2]
 if level[lev].a then
  at.active=true
  at.x=level[lev].a[1]
  at.sx=at.x*16
  at.y=level[lev].a[2]
  at.sy=at.y*8
 else
  at.active=false
 end
end

function createdrop()
 
 if m[p.x][p.y]==1 then
  sfx(1)
  m[p.x][p.y]=0
  local d={}
  d.x=(48-(w*8))+p.x*16
  d.y=(56-(h*4))+p.y*8
  d.ys=rnd(.4)+.4
  d.s=3
  add(drops,d)
 elseif m[p.x][p.y]==3 then
  sfx(2)
  for i=1,w do
  for j=1,h do
   if m[i][j]==3 then
    m[i][j]=0
    local d={}
    d.x=(48-(w*8))+i*16
    d.y=(56-(h*4))+j*8
    d.ys=rnd(.4)+.4
    d.s=11
    add(drops,d)
   end
  end
  end
 else
  sfx(0)
 end
end

function autodrop()
 if at.x>w or at.y>h then return end
 if m[at.x][at.y]==1 then
  sfx(1)
  m[at.x][at.y]=0
  local d={}
  d.x=(48-(w*8))+at.x*16
  d.y=(56-(h*4))+at.y*8
  d.ys=rnd(.4)+.4
  d.s=3
  add(drops,d)
 elseif m[at.x][at.y]==3 then
  sfx(2)
  for i=1,w do
  for j=1,h do
   if m[i][j]==3 then
    m[i][j]=0
    local d={}
    d.x=(48-(w*8))+i*16
    d.y=(56-(h*4))+j*8
    d.ys=rnd(.4)+.4
    d.s=11
    add(drops,d)
   end
  end
  end
 else
  --sfx(0)
 end
end

function drawdrop(d)
 d.ys*=1.3
 d.y+=d.ys
 if d.y >128 then del(drops,d) end
 spr(d.s,d.x,d.y,2,2)
end

function createparticles(x,y,num,col)
 x=(48-(w*8))+x*16+8
 y=(56-(h*4))+y*8+4
 for i=1,num do
  local pt={}
  pt.x=x
  pt.y=y
  pt.xs=rnd(4)-2
  pt.ys=rnd(4)-2
  pt.col=col
  pt.size = ceil(rnd(6))
  add(particles,pt)
 end
end

function drawparticle(pt)
 pt.size-=.2
 pt.x+=pt.xs
 pt.y+=pt.ys
 pt.xs*=.95
 pt.ys*=.95
 if pt.size<0 then del(particles,pt) end
 circfill(pt.x,pt.y,pt.size,pt.col)
end

function clear(table)
for k in all(table) do
 del(table,k)
end
end

function deepcopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in pairs(orig) do
            copy[deepcopy(orig_key)] = deepcopy(orig_value)
        end
        setmetatable(copy, deepcopy(getmetatable(orig)))
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end