function _init()
-- earth was a bad choice

--global values
	tick=0
	mtick=0
	camy=0
	camx=0
	motion=true
	flash=false
	blkscreen=false
	sprt={}
	road={}
	emy={}
	spwn={}
	deb={}
	exp={}
	texts={}
	conv={}
	pole={}
	pwrln={}
	intsec={}
	tree={}
	cloud={}
	debug = ""
	grav = 0.4
	maxfall = 8
	pal(14,0)
	mode=0
	phase=0
	ctrl=false
	mtimer=0
	spking=false
	tapped=false
	btntap=false
	floor=101
	musicon=true
--create layers
	lyr={}
	for i=0,4 do
		add(lyr,{})
	end

--create roads
	for i=0,16 do
		r= newspr(0,-4+i*8,98,8,8,{5,6,7,8},1,false,false,true,2)
		add (road,r)
	end
	


--create player
	p1= newspr(0,50,floor-1,7,8,{1,2,3,4},2,false,false,false,3)
	p1.acc = 1
	p1.dec = 0.8
	p1.mspd = 3
	p1.gnd=false
	p1.life=600
	p1.lifmx=600
	p1.combo=0
	p1.mxcombo=0
	p1.airtm=0
	p1.mxairtm=0
	
--create arrow
	arw = newspr(2,p1.x,1,7,3,{15},1,false,false,false,5)		

	
--create lifebackround
	lifbac = newspr(4,0,0,16,3,{62},0,false,false,false,5)		



--create progress
	prog=newspr(5,3,116,3,3,{98},0,false,false,true,2)
	prog.xstart=2
	prog.ystart=117
	prog.level=0
	prog.bgndy=128
	prog.dist=0
	prog.mov=false
	prog.vis=true
	

--create spawners 
	newspwn(0,0,-16,95,0,10,10,0,0,100,25,1,false,false)
	newspwn(1,0,128,92,0,10,10,0,0,100,25,-1,true,false)
	newspwn(2,1,-16,40,20,10,10,0,0,100,25,1,true,true)
	newspwn(3,1,128,40,20,10,10,0,0,100,25,-1,false,true)	
	newspwn(4,2,-16,65,10,10,10,0,0,100,50,1,true,false)
	newspwn(5,2,128,65,10,10,10,0,0,100,50,-1,false,false)
	newspwn(6,3,-16,10,10,20,10,0,0,100,25,1,true,true)
	newspwn(7,3,128,10,10,30,10,0,0,100,25,-1,false,true)
	
--create tank
	tank=newemy(4,-16,0,92,0,true,true)

--create title text
	t0 =	newtxt(0,0,20,"",7)
	t1 =	newtxt(1,0,44,"",7)
	t2 = newtxt(2,0,0,"",7)
	t3 = newtxt(3,0,0,"",7)
	t4 = newtxt(4,-50,105,"",7)
	t4.state=0
	t4.timer=0
	t5 = newtxt(5,128,105,"",7)
	t5.state=0
	t5.timer=0
	t6 =	newtxt(0,0,-110,"by zachary katz",6)
	t7 =	newtxt(0,0,-100,"zacharykatzgames.com",6)
	t8 =	newtxt(0,0,-20,"the end",6)
	t9 = newtxt(2,0,0,"",7)
	t10 = newtxt(3,0,0,"",7)
--	t11 = newtxt(0,0,-80,"music by benwiley4000",6)
--create conversations
	dialog={}
	dialog.intro1={
		"earth was a bad choice!",
		"",
		"what was i thinking?",
		"",
		"these people haven't even been",
		"out of their own solar system.",
		"i just wanted some r and r.",
		"",
		"i didn't think i'd be",
		"hunted down like a monster."
	}
	dialog.intro2={
		"i must make it back to my ship.",
		"",
		"i don't know if i can make it.",
		""
	}
	dialog.intro3={
		"i have limited energy.",
		"",
		"i only use energy when running.",
		"",
		"if this bar drops to zero,",
		"i'm done for.",
		"the earthlings are coming.",
		"",
		"their primative weapons won't",
		"damage my trilithium plating.",
		"but they may be able to",
		"pop me into the air.",
		"if i'm in the air",
		"i don't use any energy.",
		"use left and right to move me.",
		""
	}
	
	dialog.l1={
		"that was kind of fun.",
		"",
		"but i have to stay focused.",
		"",
		"just keep me in the air.",
		""
	}

	dialog.l2={
		"ugh... it's still so far away.",
		"",
		"the longer i run,",
		"the faster my energy drains."

	}

	dialog.l3={
		"these humans don't give up.",
		""
	}
	dialog.l4={
		"looks like the humans",
		"have some more toys.",
		"as long as i'm powered up,",
		"they can't hurt me."
	}
	dialog.l5={
		"it's a bit ironic...",
		"",
		"there's no way i could make",
		"it to my ship if they stopped."
	}
	dialog.l6={
	"once i'm near my ship",
	"i can wirelessly draw enegry.",
	"i hope i make it",
	""
	}
	dialog.l7={
		"i'm so tired, but so close.",
		"",
		"i can't give up now.",
		""
	}
	dialog.l8={
		"christ... is that a tank?",
		""
	}	
	dialog.l9={
		"almost there.",
		"i can see my ship.",
		"but... what is that?",
		"",
		"someone's towing it!",
		""
	}
	dialog.ending={		
		"it's over.",
		"",		
		"you messed with the wrong", 
		"planet buddy.",
		"we're taking your ship",
		"",
		"and prescribing you a",
		"dose of earth justice."
	}
			debugmode=false
--debug only
	if (debugmode) then
		phase=10
		ctrl=true
		p1.vis=true
		lifbac.vis=true
		prog.bgndy=112
		prog.dist=0
		prog.level=9
	end
end


function _update()
	tick+=1
	if (motion) mtick+=1
	tick %=32768
	mtick %=32768

--	debug=phase
	if(phase==0) then
		t0.txt="earth was a bad choice"
		t1.txt="press any key to begin"
		t0.vis=true
		t1.vis=true
		phase=1
	elseif (phase==1) then
		if (btntap) then
			t0.vis=false
			t1.vis=false
			p1.x=0
			p1.dx=3
			p1.y=50
			p1.dy=-3
			p1.vis=true
			mtimer=50
			phase=2
		end
	elseif (phase==2) then
		if mtimer==0 then
			newconv(dialog.intro1,t2,t3)
			phase=3
		end
	elseif (phase==3) then
		if not (spking) then
			phase = 4
			mtimer=20
		end
	elseif (phase==4) then
		if (prog.bgndy>112)prog.bgndy -=1
		if (mtimer==0 and prog.bgndy==112) then
			phase=5
			newconv(dialog.intro2,t2,t3)
		end
	elseif (phase==5) then
		if (not spking) then
			phase = 6
			lifbac.vis=true
			newconv(dialog.intro3,t2,t3)
		end
	elseif (phase==6) then
		if not (spking) then

			mtimer = 20
			phase = 7
			if (musicon)	music(9,100,3)
		end
	elseif (phase==7) then	
		if (mtimer==0) then
			phase = 8
			ctrl = true
			mtimer=60
			t0.txt="level "..prog.level+1
			t0.vis = true
			t0.y=-5
		end
	elseif (phase==8) then
		if (t0.y<20) t0.y+=1
		if (mtimer==0) then
			phase = 9
			if (prog.level==0) then
				setspwn(0,true,65,30,8,12,false)
				setspwn(1,true,30,65,12,8,false)
--				setspwn(3,true,45,75,15,6,false)
			elseif(prog.level==1) then
				setspwn(0,true,80,40,6,8,false)
				setspwn(1,true,25,80,12,10,false)
				setspwn(2,true,60,100,12,8,false)
				setspwn(3,true,80,80,10,12,false)
			elseif(prog.level==2) then
				setspwn(0,true,120,50,6,12,false)
				setspwn(1,true,40,100,12,12,false)
				setspwn(2,true,20,70,12,10,false)
				setspwn(3,true,60,50,12,12,false)
--				setspwn(5,true,125,80,4,8,false)
			
			elseif(prog.level==3) then	
				setspwn(0,true,100,75,6,12,false)
				setspwn(1,true,150,20,12,12,false)
				setspwn(2,true,70,70,10,8,false)
				setspwn(3,true,90,50,10,8,false)
--				setspwn(4,true,140,80,4,8,false)
				setspwn(5,true,100,150,8,8,false)
						
--not done yet
			elseif(prog.level==4) then	
				setspwn(0,true,75,75,6,12,false)
				setspwn(1,true,100,50,12,12,false)
				setspwn(2,true,70,70,8,8,true)
				setspwn(3,true,90,50,6,8,false)
				setspwn(4,true,140,80,8,8,false)
				setspwn(5,true,100,150,6,9,false)
						
			elseif(prog.level==5) then	
				setspwn(0,true,130,75,6,12,false)
				setspwn(1,true,160,50,12,12,false)
				setspwn(2,true,40,70,8,8,true)
				setspwn(3,true,60,20,6,8,true)
				setspwn(4,true,180,50,8,8,false)
				setspwn(5,true,100,110,9,8,false)
						
			elseif(prog.level==6) then	
				setspwn(0,true,30,80,6,12,false)
				setspwn(1,true,80,40,12,12,false)
				setspwn(2,true,40,120,8,8,true)
				setspwn(3,true,80,90,6,8,true)
				setspwn(4,true,140,80,7,10,false)
				setspwn(5,true,100,150,4,12,false)
				setspwn(6,true,100,150,10,8,false)
				setspwn(7,true,200,150,10,8,false)						

			elseif(prog.level==7) then	
				setspwn(0,true,75,75,6,12,false)
				setspwn(1,true,100,50,12,12,false)
				setspwn(2,true,70,70,11,8,true)
				setspwn(3,true,90,50,8,11,true)
				setspwn(4,true,120,80,12,6,false)
				setspwn(5,true,100,150,8,8,false)
				setspwn(6,true,50,200,14,7,true)
				setspwn(7,true,150,50,10,14,true)

			elseif(prog.level==8)then	
				setspwn(0,true,150,100,8,12,false)
				setspwn(1,true,200,50,12,12,false)
				setspwn(2,true,150,100,10,12,true)
				setspwn(3,true,100,110,12,11,true)
				setspwn(4,true,140,80,10,8,false)
				setspwn(5,true,90,150,6,12,false)
				setspwn(6,true,90,50,12,12,true)
				setspwn(7,true,60,80,10,20,true)
				tank.act=true


			elseif(prog.level==9) then	
				setspwn(0,true,75,75,6,12,false)
				setspwn(1,true,100,50,12,12,false)
				setspwn(2,true,70,70,8,15,true)
				setspwn(3,true,90,50,16,4,true)
				setspwn(4,true,140,80,10,5,false)
				setspwn(5,true,100,150,7,8,false)
				setspwn(6,true,100,150,8,14,true)
				setspwn(7,true,100,150,16,12,true)
				tank.act=true
			end
			pausespwn(false)
			prog.mov=true
		end
	elseif (phase==9) then	
		if (t0.y>-5) then
			t0.y-=1
		else
			t0.vis=false
		end
		if (not prog.mov) then
			phase=10
			pausespwn(true)
		else 
			if (p1.gnd) p1.life-=1.5+prog.level/5
			if (p1.life<=0) phase=-1
		end
	elseif (phase==10) then
		if (p1.gnd and #emy==1 and tank.mode==0) then
			phase=11
			ctrl=false
			mtimer=50
		end
	elseif (phase==11) then
		if (prog.level==10) then
			phase=13			
			lifbac.vis=false
			boss=newemy(8,128,0,floor-70,0,false,false)
			ship=newemy(10,128,0,floor-50,0,false,false)		
			tank.x-=1
		end
		if (p1.life>=p1.lifmx) then
			if mtimer==0 then
				if (prog.level<10) then
					newconv(dialog["l"..prog.level],t2,t3)
					phase=12
				end
			end
			p1.life=p1.lifmx
		else
			p1.life+=10
		end
	elseif (phase==12) then	
		if not (spking) then
			phase=6
		end
	elseif (phase==13) then	
		if (prog.bgndy<128) prog.bgndy+=1
		if (boss.x <=90) then
			phase=14
			boss.dx=0
			newconv(dialog.ending,t9,t10)
			prog.vis=false
		else
			boss.dx=-0.5
		end
	elseif (phase==14) then	
		if not (spking) then
			ctrl=true			
			phase = 15
		end
	elseif (phase==15) then	
		if (boss.y<-150) then
			phase=16
			boss.dy=0
			boss.mode=1
		else
			boss.dy=-2
			boss.starty=boss.y
		end
	elseif (phase==16) then	
		camy=mid(0,-200,p1.y-93)
		if (flr(rnd(100))==0) boss.y=-151
		if (flr(rnd(100))==1) boss.y=-150
	elseif (phase==17) then
		camy=mid(0,-200,p1.y-93)
		stopmotion()
		ctrl=false
		phase=18
	elseif(phase==18) then
		camy=mid(0,-200,p1.y-93)
		if (ship.y+ship.h>=floor+2) then
			ship.y=floor-ship.h+2
			ship.dy=0
			if (p1.gnd) phase=19 ctrl=true
		else
			ship.dy+=grav
			ship.dy=min(ship.dy,maxfall)
		end
	elseif (phase==19) then
		if (p1.x>ship.x+4) phase=20
	elseif (phase==20) then
		music(-1)
		p1.vis=false
		ctrl=false
		mtimer=20
		phase=21
	elseif (phase==21) then
		if(mtimer==0) then
		camx=1
		phase=22
		mtimer=20
		end
	elseif (phase==22) then
		camx=-camx
		if (mtimer==0) then
		phase=23
		sfx(6,3)
		end
	elseif (phase==23) then
		camx=-camx
		if (ship.y>50) then
			ship.dy-=0.05
		else
			phase=24
			mtimer=200
			ship.dy=0
		end
	elseif (phase==24) then
		camx=-camx
		ship.y+=(-1+flr(rnd(3)))
		if (mtimer==200 or mtimer==120 or mtimer==60 or mtimer==40 or mtimer==30 or	mtimer==20 or	mtimer==10) flash=true sfx(7)
		if (mtimer==0) then
			sfx(8)
			sfx(-1,3)
			flash=true
			ship.vis=false
			phase=25
			camx=0
			mship={}
			mship.x=128
			mship.y=60
			mship.dx=-10
			mship.dy=-5
			mtimer=80
		end
	elseif (phase==25) then
		if (mtimer==0) then
			t0.txt="highest combo: "..p1.mxcombo
			t0.y=-65
			t1.txt="most airtime: "..((flr((p1.mxairtm/30+0.5)*10))/10).."s"
			t1.y=-55
			t0.vis=true
			t1.vis=true
			t6.vis=true
			t7.vis=true
			t8.vis=true
--			t11.vis=true
			t0.col=6
			t1.col=6
			phase=26
		end
	elseif (phase==26) then
		if (camy<-128) then
			phase=27
		else
			camy-=1	
		end
	elseif (phase==27) then
		if (btntab) then
	
		end
	elseif (phase==28) then
	elseif (phase==29) then
	elseif (phase==-1) then
		prog.mov=false	
		ctrl=false
		pausespwn(true)
		p1.aset={51}
		phase=-2
		music(-1)
		p1.dx=0
	elseif (phase==-2) then
		if (p1.x<-200) then
			phase=-3
			blkscreen=true
			t1.txt="press any key to retry"
			t1.vis=true
			p1.dx=0
			for e in all(emy)do
				if (e.id~=4) del(emy,e)
			end
		elseif (p1.dx>-2) then
			p1.dx-=0.05
		end
	elseif (phase==-3) then
		if (btntap) then
			t1.vis=false
			p1.x=0
			p1.dx=2
			p1.y=50
			p1.dy=-3
			phase=6
			prog.dist=0
			blkscreen=false
		 pausespwn(false)
		 ctrl=true
		 p1.life=p1.lifmx
		end
 
	end


	if (mtimer>0) then
		mtimer -= 1
	end
	
--controls	
	if ((btnp(4) and btn(5)) or (btn(4) and btnp(5))) then
		if (musicon) then
			musicon=false
			music(-1)
		else
			musicon=true
			music(9,100,3)
		end
	end

	local btndwn=false
	for b=0,5 do
		if (btn(b))	btndwn=true
	end
	
	if (btndwn) then
		if (not tapped) then
			btntap=true
			tapped=true
		else
			btntap=false
		end
	else
		tapped=false
		btntap=false
	end
	

	if (btn(0) and ctrl) then
		p1.dx-=p1.acc

		if (phase==19) then
			p1.mir=true
			p1.aset={1,2,3,4}
			p1.aspd=2
		else
			if (p1.vis and p1.gnd and p1.life>0) then
				if (tick%7==0) sfx(0,2)
			end		
		end
	elseif (p1.vis and btn(1) and ctrl) then
		p1.dx+=p1.acc
		if (phase==19) then
			p1.mir=false
			p1.aset={1,2,3,4}
			p1.aspd=2
		else
			if (p1.vis and p1.gnd and p1.life>0) then
				if (tick%5==0) sfx(0,2)
			end
		end
	else
		if (phase==19) then
			p1.aset={16}
			p1.aspd=0
			p1.afrm=0
		else
			if (p1.vis and p1.gnd and p1.life>0) then
				if (tick%6==0) sfx(0,2)
			end
		end		
		if (p1.life>0) then
			if (abs(p1.dx)>p1.dec) then
				p1.dx-=sgn(p1.dx)*p1.dec
			else
				p1.dx = 0
			end
		end
	end


--player behavior
	p1.dx = mid(p1.dx,p1.mspd,-p1.mspd)

	if (p1.x+p1.dx<0 and p1.life>0) then
		p1.dx=-(p1.x)
	end

	if (p1.x+p1.dx>128-p1.w) then
		p1.dx = (128-p1.w)-p1.x
	end

	p1.dy += grav
	p1.dy = min(p1.dy,maxfall)

	if (p1.y+p1.dy+p1.h>=floor) then
		p1.dy = (floor-p1.h)-p1.y
	end

	if (p1.y+p1.dy<-p1.h and phase<13) then
		arw.vis=true 
		arw.x=p1.x+p1.dx
		arw.aset={15}
		if (p1.y+p1.dy<-20) then
			arw.aset={52}
		end
		if (p1.y+p1.dy<-30) then
			arw.aset={53}
		end
	else
		arw.vis=false
	end

--spawner behavior	
	for s in all(spwn) do
		if (s.act and not s.pause) then
			if s.wait<=0 then
				newemy(s.eid,s.x,((s.dx+rnd(s.dxmod))/10)*s.dirc,s.y+rnd(s.ymod),s.dy+rnd(s.dymod),s.flip,s.fire)
				s.wait = flr(s.rt+rnd(s.rtmod))
			else
				s.wait-=1
			end
		end
	end

--enemy behavior

	for e in all(emy) do
		if (e.id==1 or e.id==2)	sfx(4,3)
		if (e.id==3 or e.id==8)	sfx(5,3)		
		if (e.id == 1) then
			if (flr(rnd(10))==0) then
--				expsnd()
			else
				e.dy=0
			end
			if (e.fire and abs(e.firex-e.x)<5) then
				for i=-0.05,0.05,0.05 do
					newemy(5,e.x,sin(ang(e,p1)+i),e.y,cos(ang(e,p1)+i),false,false)				
				end
				e.fire = false
			end
		end
		if (e.id == 2) then
			e.y=e.starty+20*sin((tick+e.dly)%100/100)
		end
		if (e.id == 3) then
			if (e.fire and abs(p1.x-e.x)<5) then
				newemy(6,e.x,0,e.y,0,false,false)				
				e.fire = false
			end
			if (flr(rnd(10))==0) then
				expsnd()
			else
				e.dy=0
			end
		end
		if (e.id == 4 and e.act) then
			if (e.mode==0 and not e.pause) then
				if (e.tmr<=0) then
					e.mode=1
					e.dx=0.5
				else
					e.tmr-=1
				end
			elseif (e.mode==1) then
				if (e.x+e.dx>=1) then
					e.mode=2
					e.tmr=15
					e.dx=0
				end
			elseif (e.mode==2) then	
				if (e.tmr<=0) then
					e.mode=3
					newemy(7,e.x+e.w,0,e.y+1,0,false,false)				
					e.tmr=10
				else
					e.tmr-=1
				end
			elseif (e.mode==3) then	
				if (e.tmr<=0) then
					e.mode=4
					e.dx=-0.5
				else
					e.tmr-=1
				end
			elseif (e.mode==4) then
				if (e.x+e.dx<=-16) then
					e.mode=0
					e.tmr=50
					e.dx=0
				end
			end
		end
		if (e.id == 6) then
			e.dy += grav/2
			e.dy = min(e.dy,maxfall)
		end
		if (e.id ==7) then
			if angcw(e.ang,ang(e,p1)) then
				e.ang+=0.005
			else
				e.ang-=0.005
			end
			e.ang%=1
			e.dx = sin(e.ang)
			e.dy = cos(e.ang)
			e.aset = {37+flr(atan2(e.dy,e.dx)*8+0.5)%8}			
		end
		if (e.id ==8) then
			if (flr(rnd(30))==0) then
				e.y+=1	
			end
			if (flr(rnd(30))==0) then
				e.y-=1
			end
			e.y=mid(e.y,e.starty-1,e.starty+1)
			if (e.mode==1) then
				e.timer=60+flr(rnd(0))
				e.mode=2
			elseif (e.mode==2) then
				if (e.timer==0) then
					e.mode=1
				else
					e.timer-=1
					if (p1.y>e.y) then
						if (e.timer%10==0) then
							newemy(9,e.x,-(0.5),e.y,-(2),false,false)				
						elseif (e.timer%10==5) then
							newemy(9,e.x,-(1),e.y,-(2),false,false)				
						end
					end
				end
			elseif (e.mode==3) then
				e.timer=60+flr(rnd(0))
				e.mode=4
			elseif (e.mode==4) then
				if (e.timer==0) then
					e.mode=3
				else
					e.timer-=1
					if (e.timer%6==0 and p1.y>e.y) then
						newemy(9,e.x,-(0.5+e.timer/50),e.y,-(2),false,false)				
					end
				end
			elseif (e.mode==5) then
				e.timer=60
				e.mode=6
			elseif (e.mode==6) then
				if (e.timer==0) then
					e.mode=5
				else
					e.timer-=1
					if (e.timer%10==0 and p1.y>e.y) then
						if (e.timer<30) then
							newemy(9,e.x,-(1.25),e.y,-(2),false,false)				
						elseif (e.timer <60) then
							newemy(9,e.x,-(0.5),e.y,-(2),false,false)				
						end
					end
				end			
			elseif (e.mode==10) then
				if (e.vis) then
					e.vis=false
				else
					e.vis=true
				end
				if (p1.gnd) then
					e.vis=true
					if (e.hp==2) then
						e.mode=3
					elseif (e.hp==1) then
						e.mode=5
					end
				end
			end
		end
		if (e.id==9) then
			e.dy += grav/2
			e.dy = min(e.dy,maxfall+1)
		end
		if (e.y+e.h>floor and e.id~=0 and e.id~=10) then
			newexp(0,e.x+e.w/2,e.y+e.h/2)
			del(emy,e)
			del(sprt,e)
			expsnd()
		end
		if (e.y<-6 or e.x<-18 or e.x>144) then
			if (e.id<8) then
				del(emy,e)
				del(sprt,e)
			end
		end

		if (col(p1,e)) and p1.life>0 then
			if (e.id~=10) then
				p1.dy=min(-e.vpwr,p1.dy)
				p1.dx=e.hpwr*sin(ang(e,p1))
			end
			if (e.id==8) then
				p1.dx=-e.hpwr
				if (e.mode<10) then
					e.hp-=1			
					expsnd()
				end
				if (e.hp==0) then
					phase=17
					del(emy,e)
					del(sprt,e)
					newdeb(e.x,e.y,e.w,e.h,ang(p1,e),1)
					for i=0,3 do 
						newexp(0,e.x+e.w*(0.25*i),e.y+e.h/2)
					end					
				else
					e.mode=10
					newdeb(e.x+16,e.y,4,4,ang(p1,e),1)
				end
			elseif (e.id==10) then
				if (phase~=19) then
					p1.dx=-e.hpwr
				end
			elseif (e.id~=4) then
				expsnd()
				p1.combo+=1
				if (e.id<=3) then
					newdeb(e.x,e.y,e.w,e.h,ang(p1,e),1)
				end
				if (e.id>=1 and e.id<=3) then
					newexp(1,e.x+e.w/2,e.y+e.h/2)
				else
					newexp(0,e.x+e.w/2,e.y+e.h/2)
				end

				del(emy,e)
				del(sprt,e)
			else
					p1.dx=e.hpwr			
			end
		end

--		for p in all(pole) do 
--			if (mid(p.midx,e.x,e.x+e.w)==p.midx) 
--			and (mid(p.midy,e.y,e.y+e.h)==p.midy) then
--				if (e.id>=1 and e.id<=3) then
-- 				newexp(1,e.x+e.w/2,e.y+e.h/2)
--			else
--					newexp(0,e.x+e.w/2,e.y+e.h/2)
--				end
--				newdeb(e.x,e.y,e.w,e.h,1,1)
--				del(emy,e)
--				del(sprt,e)
--			end
--		end
	end
	
--ship behavior
	if (phase>=13 and phase<=15) then
		ship.x=boss.x+3
		ship.y=boss.y+20
	end

--debris behavior
	for p in all(deb) do
		p.dy += grav/2
		p.dy = min(p.dy,maxfall)
		if (p.y>floor-2) then
			p.dy=(-flr(p.dy*0.5))
			if (motion) then
				p.dx=-2
			else
				p.dx=0			
			end
		end
		if (p.y+p.dy>128 or p.x+p.dx<-4) then
			del(deb,p)
			del(sprt,p)
		end
	end
	

	
--explosions behavior
	for ex in all(exp) do
		local frm=ex.aset[ex.afrm+1]
		if (frm==118 or frm==110) then
			del(exp,ex)
			del(sprt,ex)
		end
	end

	
--progress behavior

	if (prog.mov) prog.dist+=1
	if (prog.dist>=900) then
		prog.level+=1
		prog.dist=0
		prog.mov=false
	end
	prog.x=prog.xstart+prog.level*12+(prog.dist/75)
	prog.y=prog.bgndy+3




--cloud behavior
	if (phase>12 and motion and flr(rnd(30))==0) then
		if (flr(rnd(2))==0) then
			c=newspr(13,128,-(16+rnd(200)),16,16,{206},0,false,false,true,4)
		else
			c=newspr(13,128,-(16+rnd(200)),16,16,{238},0,false,false,true,4)
		end
		add(cloud,c)
		c.dx=-(2+rnd(1))

	end
	for c in all(cloud) do
		if (c.x<-16) then
			del(sprt,c)
			del(cloud,c)
		end
	end

--tree behavior
	if (#tree==0 and flr(rnd(1000))==8) then
		newtree(flr(rnd(20)))
	end
	
	for t in all(tree) do
		if (motion)		t.x-=0.5
		if (t.x+32*(t.w+1)<0) del(tree,t)
	end

--intersection behavior
	if (#intsec==0 and flr(rnd(1000))==8) then
		newintsec(100)
	end
	
	for int in all(intsec) do
		if (motion) int.x-=1
		if (int.x+int.w+64<0) del(intsec,int)
	end
	
--powerline behavior	
	if (prog.mov and #pole==0 and flr(rnd(1000))==8) then
		power()
	end

	for pl in all(pwrln) do
		if (motion) pl.x-=2
		for p in all(pole) do
			if (pl.x<0 and p.id==7) then
				del(sprt,p)
				del(pole,p)
			end
			if (p.id==8 and p.x+p.w<-40) then
				del(sprt,p)
				del(pole,p)
				del(sprt,pl)
				del(pwrln,pl)
			end
		end
	end

--sprite movement and animiation
	for s in all(sprt) do
		if (tick%s.aspd==0) then
			s.afrm = (s.afrm+1)%#s.aset		
		end
		s.y+=s.dy
		s.x+=s.dx
	end

--check for grounded player
	if (p1.y+p1.h>=100) then
		if (not p1.gnd and p1.dy<=0) then
			p1.gnd = true
			p1.dec = 0.8
			p1.mspd= 4
			p1.acc = 1
			p1.aset={1,2,3,4}
			if (p1.airtm>240 and phase<13) then
				p1.mxairtm=max(p1.mxairtm,p1.airtm)
				t5.txt=((flr((p1.airtm/30+0.5)*10))/10).."s airtime"
				t5.vis=true
			end
			p1.airtm=0
			if (p1.combo>9 and phase<13) then
				p1.mxcombo=max(p1.combo,p1.mxcombo)
				t4.txt=p1.combo.." hit combo"
				t4.vis=true
			end
			p1.combo=0
		end
	else
		p1.airtm+=1
		if (p1.gnd) then
			p1.gnd = false
			p1.dec = 0.05
			p1.acc = 0.4
			p1.mspd=5
			if (p1.dx<=0) then
				p1.aset={17,18,19,20}
			else
				p1.aset={20,19,18,17}
			end
		end
	end

--lifebar behavior
	lifbac.x=p1.x+p1.h+2
	lifbac.y=p1.y-4


--conversation behavior

	if (spking) then
		if (conv.state==1) then
			if (conv.t1.txt~=conv.lset[conv.lid]) then
				conv.t1.txt=sub(conv.lset[conv.lid],0,#conv.t1.txt+2)
				conv.t1.tlen = #conv.lset[conv.lid]*4
			else
				conv.state=2
				conv.lid+=1
			end
		elseif(conv.state==2) then
			if(conv.t2.txt~=conv.lset[conv.lid]) then
				conv.t2.txt=sub(conv.lset[conv.lid],0,#conv.t2.txt+2)
				conv.t2.tlen = #conv.lset[conv.lid]*4		
			else
				conv.state=3
			end
		elseif(conv.state==3) then
			if (btntap) then
				if (conv.lct>conv.lid) then
					conv.state=1
					conv.lid+=1
					conv.t1.txt=""
					conv.t2.txt=""
				else
					conv.state=0
					conv.t1.vis=false
					conv.t2.vis=false
					spking=false
				end
			end
		end
	end
	
	
--text behavior	
	if (t4.vis) then
		if (t4.state==0) then
			t4.x+=6
			if(t4.x>=2) then
			t4.x=2
			t4.state=1
			t4.timer=75
			end
		elseif(t4.state==1) then
			if t4.timer<=0 then
				t4.state=2
			else
				t4.timer-=1
			end
		elseif(t4.state==2) then
			t4.x-=6
			if(t4.x<=-50) then
				t4.x=-50
				t4.state=0
				t4.vis=false
			end
		end
	end


	if (t5.vis) then
		if (t5.state==0) then
			t5.tlen=#t5.txt*4
			t5.x-=6
			if(t5.x<=128-2-t5.tlen) then
			t5.x=128-2-t5.tlen
			t5.state=1
			t5.timer=75
			end
		elseif(t5.state==1) then
			if t5.timer<=0 then
				t5.state=2
			else
				t5.timer-=1
			end
		elseif(t5.state==2) then
			t5.x+=6
			if(t5.x>128) then
				t5.x=128
				t5.state=0
				t5.vis=false
			end
		end
	end
	
	if (t2.vis) then
		t2.x = mid(2,127-t2.tlen,p1.x-t2.tlen/2)
		t2.y = p1.y-32
	end
	if (t3.vis) then
		t3.x = mid(2,127-t3.tlen,p1.x-t3.tlen/2)
		t3.y = p1.y-24
	end	
	
	if (t9.vis) then
		t9.x = mid(2,127-t9.tlen,100-t9.tlen)
		t9.y = 15
	end

	if (t10.vis) then
		t10.x = mid(2,127-t10.tlen,100-t10.tlen)
		t10.y = 23
	end

	for t in all(texts) do
		if (t.id<=1 or t.id >=6) then
			t.x=(128-(#t.txt*4))/2
		end
	end
end

function _draw()
	cls()
	camera(camx,camy)
--draw sky
	rectfill(camx-2,camy,camx+129,camy+127,1)

--draw stars
	for i=0,2 do
		map(0,0,0-mtick%8192/64,(camy*0.8)-64+64*i,16,8)
		map(0,0,128-mtick%8192/64,(camy*0.8)-64+64*i,16,8)

	end
--draw ground
	rectfill(-2,72,129,127,5)

--draw mini ship
	if (phase==25) then
		circfill(mship.x,mship.y,2,0)
		circ(mship.x,mship.y,2,7)
		mship.x+=mship.dx
		mship.y+=mship.dy
		
	end

--draw mountains
	map(32,0,-(mtick%1024)/8,40,16,3)
	map(32,0,128-(mtick%1024)/8,40,16,3)
	map(16,0,-(mtick%512)/4,48,16,4)
	map(16,0,128-(mtick%512)/4,48,16,4)
	map(16,5,-(mtick%384)/3,80,16,1)
	map(16,5,128-(mtick%384)/3,80,16,1)

--draw trees
	for t in all(tree) do
		spr(224,t.x,t.y,1,2)
		for i=0,t.w do
			spr(225,t.x+8+(16*i),t.y,2,2)			
		end
		spr(227,t.x+24+(16*t.w),t.y,1,2)			
	end

--draw intersection
	for int in all(intsec) do
		for i=-10,10 do
		line (int.x,88,(int.x/32)*64-64+i,100,1)
		line (int.x+int.w,88,96+int.w+(int.x/32)*64-64+i,100,1)
		line (int.x,88,int.x+int.w,88,1)
		end		
	end

--draw powerlines
	for pl in all(pwrln) do
	map(32,5,pl.x,pl.y,16,5)
		for p in all(pole) do
			if (p.id==8) then
				line(pl.x+128,pl.y+2,p.x,p.y+9,0)
				line(p.x+38+p.w,112,p.x+p.w,p.y+12,0)
				p.midx=(pl.x+128+p.x)/2
				p.midy=(pl.y+2+p.y+9)/2
			else
				line(pl.x,pl.y+2,p.x+p.w,p.y+9,0)
				line(p.x-30,112,p.x,p.y+12,0)
				p.midx=(pl.x+p.x+p.w)/2
				p.midy=(pl.y+2+p.y+9)/2
			end
		end
	end

--draw boss cables
	if (phase>=13 and phase <=16) then
		line (boss.x+4,boss.y+5,ship.x+2,ship.y+5,7)
		line (boss.x+15,boss.y+5,ship.x+12,ship.y+7,7)
		line (boss.x+27,boss.y+5,ship.x+23,ship.y+5,7)
	end

--draw progress
	if (prog.vis) then
		rectfill(0,prog.bgndy,127,prog.bgndy+16,13)
		rectfill(1,prog.bgndy+1,126,prog.bgndy+14,0)
		map(32,3,prog.xstart+2,prog.bgndy+5,16,1)
	end



	for i=1,5 do
		lyr[i]={}
	end
	
--	for s in all(sprt) do
--		add(lyr[s.z],s)
--	end
	
	for i=1,#sprt do
		add(lyr[sprt[i].z],i)
	end

	for l in all(lyr) do
		for i in all(l) do
			s = sprt[i]
			if (s.vis) then
				f = s.aset[s.afrm+1]
				local xoff=0
				if (s.mir) then
					xoff=(8-s.w%8)%8
				end
				spr(f,s.x-xoff,s.y,flr(1+(s.w-1)/8),flr(1+(s.h-1)/8),s.mir,s.flip)
--				rect(s.x,s.y,s.x+s.w,s.y+s.h,8)
			end
		end
	end


--draw lifebar

	if (lifbac.vis and p1.life>0) then
		line(lifbac.x+1,lifbac.y+1,lifbac.x+1+p1.life/p1.lifmx*13,lifbac.y+1,8)
	end

--draw blackscreen
	if (blkscreen) rectfill(0,0,127,127,0)

--draw texts
	for t in all(texts) do
		if (t.vis) then
			print(t.txt,t.x,t.y,t.col)
		end
	end

--draw speaking line
	if (t3.vis) then
		line(p1.x+p1.w/2,p1.y-4,p1.x+p1.w/2,t3.y+8,7)
	end

--flash
	if (flash) then
		rectfill(0,0,127,127,7)
		flash=false
	end

	for e in all(emy) do
--	print(e.id)

	end
	print(debug,0,0)
--	for a,b in pairs() do

--end
end

--text creator
function newtxt(id,x,y,txt,col)
	t={}
	t.id=id
	t.x=x
	t.y=y
	t.txt=txt
	t.tlen=0
	t.col=col
	t.vis=false
 add(texts,t)
 return t
end

--sprite creator
function newspr(id,x,y,w,h,aset,aspd,flipx,flipy,vis,z)
	s={}
	s.id = id
	s.x = x
	s.dx = 0
	s.dy = 0
	s.y = y
	s.w = w
	s.h = h
	s.afrm = 0
	s.aspd = aspd
	s.aset = aset
	s.mir = flipx
	s.flip = flipy
	s.vis = vis
	s.z = z
	add(sprt,s)
	return s
end

--spawner creator
function newspwn(id,eid,x,y,ymod,dx,dxmod,dy,dymod,rt,rtmod,dirc,flipx,fire)
	s={}
	s.act=false
	s.pause=false
	s.id=id
	s.eid=eid
	s.x=x
	s.y=y
	s.ymod=ymod
	s.dirc=dirc
	s.dx=dx
	s.dxmod=dxmod
	s.dy=dy
	s.dymod=dymod
	s.rt=rt
	s.rtmod=rtmod
	s.wait=0
	s.flip=flipx
	s.fire=fire
	add(spwn,s)
end

--enemy creator
function newemy(eid,x,dx,y,dy,flipx,fire)
	if (eid == 0) then
		e=newspr(1,x,y,8,7,{9,10},2,flipx,false,true,3)
		e.id = eid
		e.vpwr = 6
		e.hpwr = 2
		e.dx=dx
		e.dy=dy
		if (dx<0) then
			e.z=2
		else
			e.z=4
		end
		add (emy,e)
	end
	if (eid == 1) then
		e=newspr(1,x,y,11,8,{11,13},2,flipx,false,true,3)
		e.id = eid
		e.vpwr = 5.5
		e.hpwr = 3
		e.dx=dx
		e.dy=dy
		e.fire=fire
		e.firex=(64-sgn(dx)*40)+(sgn(dx)*rnd(60))
		add (emy,e)
	end
	if (eid == 2) then
		e=newspr(1,x,y,12,6,{33,35},2,flipx,false,true,3)
		e.id = eid
		e.vpwr = 5
		e.hpwr = 4
		e.dx=dx
		e.dy=dy
		e.starty=y
		e.timer=0
		e.dly = rnd(50)
		add (emy,e)
	end
	if (eid == 3) then
		e=newspr(1,x,y,15,7,{29},2,flipx,false,true,3)
		e.id = eid
		e.vpwr = 6
		e.hpwr = 3
		e.dx=dx
		e.dy=dy
		e.fire=fire
		add (emy,e)
	end
	if (eid == 4) then
		e=newspr(1,x,y,16,8,{56,58,60},2,false,false,true,2)

		e.act = false
		e.pause=false
		e.id = eid
		e.vpwr = 2
		e.hpwr = 5
		e.dx=0
		e.dy=0
		e.mode=0
		e.tmr=50
		add (emy,e)
	end
	if (eid == 5) then
		e=newspr(1,x,y,5,5,{21},0,flipx,false,true,3)
		e.id = eid
		e.dx = dx
		e.dy = dy
		e.vpwr = 2
		e.hpwr = 1
		e.aset = {21+flr(atan2(e.dy,e.dx)*8+0.5)%8}
		add (emy,e)
	end
	if (eid == 6) then
		e=newspr(1,x,y,4,6,{31},0,flipx,false,true,3)
		e.id = eid
		e.dx = dx
		e.dy = dy
		e.vpwr = 7
		e.hpwr = 2
		add (emy,e)
	end
	if (eid == 7) then
		e=newspr(1,x,y,4,4,{37},0,flipx,false,true,3)
		e.id = eid
		e.dx = dx
		e.dy = dy
		e.vpwr = 7.8
		e.hpwr = 2
		e.ang = 0.75
		add (emy,e)
	end
	if (eid == 8) then
		e=newspr(1,x,y,32,9,{64,68},2,flipx,false,true,3)
		e.id = eid
		e.dx = dx
		e.dy = dy
		e.vpwr = 1
		e.hpwr = 5
		e.mode=0
		e.starty=y
		e.hp=3
		add (emy,e)
	end
	if (eid == 9) then
		e=newspr(1,x,y,8,8,{49,50},3,flipx,false,true,3)
		e.id = eid
		e.dx = dx
		e.dy = dy
		e.vpwr = 6
		e.hpwr = 1
		add (emy,e)
	end
	if (eid == 10) then
		e=newspr(1,x,y,26,30,{198},0,flipx,false,true,3)
		e.id = eid
		e.dx = dx
		e.dy = dy
		e.vpwr = 0
		e.hpwr = 3
		add (emy,e)
	end
	return e
end
	
--collision
function col(sprt1,sprt2)
	if (sprt1.x<(sprt2.x+sprt2.w) and
		(sprt1.x+sprt1.w)>sprt2.x and
		sprt1.y<(sprt2.y+sprt2.h) and
		(sprt1.y+sprt1.h)>sprt2.y) then
		return true
	else
		return false
	end
end


function newexp(type,x,y)
	if (type==0) then
		e=newspr(0,x-4,y-4,8,8,{112,113,114,115,116,117,118},1,false,false,true,4)
	else
		e=newspr(0,x-8,y-8,16,16,{74,76,78,104,106,108,110},1,false,false,true,4)					
	end
	add(exp,e)
end

function newdeb(x,y,w,h,ang,cone)
	for i=0,(w*h)/4 do
		d=newspr(0,x+rnd(w),y+rnd(h),1,1,{45+flr(rnd(3))},0,false,false,true,4)
		d.dx=3*((sin(ang))+(-cone/2+rnd(cone)))
		d.dy=3*((cos(ang))+(-cone/2+rnd(cone)))
		add(deb,d)
 end
end

--angle
function ang(o1,o2)
	x1=o1.x+o1.w/2
	x2=o2.x+o2.w/2
	y1=o1.y+o1.h/2
	y2=o2.y+o2.h/2
	return(atan2(y2-y1,x2-x1))
end

--cw or ccw ang check
function angcw(a1,a2)
	test=a1-a2
	if (a1<a2) then
		if (abs(a1-a2)<0.5) then
			return true
		else
			return false
		end
	else
		if (abs(a1-a2)<0.5) then
			return false
		else
			return true
		end
	end
end

function newconv(c,t1,t2)
	conv.lset=c
	conv.lct=#c
	conv.t1=t1
	conv.t2=t2
	conv.lid=1
	conv.state=1
	t1.vis=true
	t1.txt=""
	t2.vis=true
	t2.txt=""
	spking=true
end



function setspwn(id,act,rt,rtmod,dx,dxmod,fire)
	for s in all(spwn) do
		if (s.id==id) then
			s.act=act
			s.rt=rt
			s.rtmod=rtmod
			s.fire=fire
			s.dx=dx
			s.dxmod=dxmod
			s.wait=rnd(rtmod)
		end
	end
end

function newintsec(w)
	i={}
	i.w=w
	i.x=128
	add(intsec,i)
end

function power()
	p=newspr(7,128,88,16,24,{196},0,false,false,true,4)
	p.dx=-8
	p.off= 15
	p.midx=0
	p.midy=0
	add(pole,p)
	p=newspr(8,128*8,88,16,24,{196},0,true,false,true,4)
	p.dx=-8
	p.off=-5
	add(pole,p)
	pl={}
	pl.x=128
	pl.y=72
	add(pwrln,pl)

end

function newtree(w)
--create trees
		t={}
		t.w=w
		t.x=128
		t.y=68
		add (tree,t)

end

function pausespwn(pause)
	for s in all(spwn) do
		s.pause=pause
	end
	tank.pause=pause
end

function stopmotion()
	motion = false
	for r in all(road) do
		r.aspd=0
	end
end

function expsnd()
	sfx(1+flr(rnd(3)),2)
end