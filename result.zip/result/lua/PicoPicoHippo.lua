--to do

--scores

--game over screen
--game logic


cur_frame=0

k_title_screen_mode=1
k_game_start_mode=2
k_play_game_mode=3
k_game_over_mode=4
game_mode = k_title_screen_mode

screen_left=18
screen_right=110
screen_top=18
screen_bottom=110

friction = .01

winner=4

k_num_pellets=30

wait_timer=0
wait_limit=30


particle_list={}
function new_particle(tile,w,h,x,y,vx,vy,g,life)
	a={}
	a.tile=tile
	a.x=x
	a.y=y
	a.vx=vx
	a.vy=vy
	a.g=g
	a.h=h
	a.w=w
	a.life=life
	add(particle_list,a)
end

function update_particles()
	for a in all(particle_list) do
		
		a.vy+=a.g
		a.x+=a.vx
		a.y+=a.vy
		a.life-=1
		if(a.life<0)then del(particle_list,a) end
	end
end

function draw_particles()
	for a in all(particle_list) do
		spr(a.tile,a.x,a.y,a.w,a.h)
	end

end

pellet_list={}
function new_pellet(x,y,vx,vy,rad,fixed)
	p={}
	p.x=x
	p.y=y
	p.vx=vx
	p.vy=vy
	p.rad=rad
	p.collide=false
	p.collide_x=0
	p.collide_y=0
	p.mass=rad
	p.active=true
	if(fixed!=nil)then
		p.fixed= fixed
	else
		p.fixed=false
	end
	
	add(pellet_list,p)
	return p
end


blue_hippo={}
blue_hippo.head_start_x=16
blue_hippo.head_start_y=64
blue_hippo.dir_x=1
blue_hippo.dir_y=0
blue_hippo.head_dx=0
blue_hippo.head_dy=0
blue_hippo.head_vx=0
blue_hippo.head_vy=0
blue_hippo.head_max_extend=20
blue_hippo.head_max_y=0
blue_hippo.in_mouth=0
blue_hippo.score=0
blue_hippo.head_pellet=new_pellet(0,0,0,0,8,true)

green_hippo={}
green_hippo.head_start_x=112
green_hippo.head_start_y=64
green_hippo.dir_x=-1
green_hippo.dir_y=0
green_hippo.head_dx=0
green_hippo.head_dy=0
green_hippo.head_vx=0
green_hippo.head_vy=0
green_hippo.head_max_extend=20
green_hippo.head_max_y=0
green_hippo.in_mouth=0
green_hippo.score=0
green_hippo.head_pellet=new_pellet(0,0,0,0,8,true)

red_hippo={}
red_hippo.head_start_x=64
red_hippo.head_start_y=16
red_hippo.dir_x=0
red_hippo.dir_y=1
red_hippo.head_dx=0
red_hippo.head_dy=0
red_hippo.head_vx=0
red_hippo.head_vy=0
red_hippo.head_max_extend=20
red_hippo.head_max_y=0
red_hippo.in_mouth=0
red_hippo.score=0
red_hippo.head_pellet=new_pellet(0,0,0,0,8,true)


yellow_hippo={}
yellow_hippo.head_start_x=64
yellow_hippo.head_start_y=112
yellow_hippo.dir_x=0
yellow_hippo.dir_y=-1
yellow_hippo.head_dx=0
yellow_hippo.head_dy=0
yellow_hippo.head_vx=0
yellow_hippo.head_vy=0
yellow_hippo.head_max_extend=20
yellow_hippo.head_max_y=0
yellow_hippo.in_mouth=0
yellow_hippo.score=0
yellow_hippo.head_pellet=new_pellet(0,0,0,0,8,true)



function draw_pellet(the_pellet)
	if(not the_pellet.fixed)then

	circfill(the_pellet.x,the_pellet.y,the_pellet.rad,6)
	circfill(the_pellet.x-1,the_pellet.y-1,3,7)
	
	--line(the_pellet.x,the_pellet.y,the_pellet.x+the_pellet.vx*4,the_pellet.y+the_pellet.vy*4,0)
	
	end
	
end

function update_pellet(the_pellet)

	if(the_pellet.fixed==false)then

		--reign things in when balls start going too fast
		if(the_pellet.vx*the_pellet.vx+the_pellet.vy*the_pellet.vy>the_pellet.rad*the_pellet.rad)then 
			the_pellet.vx*=.5
			the_pellet.vy*=.5
		end
		

		--end
		
		the_pellet.vx*=(1-friction)
		the_pellet.vy*=(1-friction)
		
		--len = (dx*dx+dy*dy)
		if(the_pellet.x<60+rnd(8))then the_pellet.vx+=.02
		else the_pellet.vx-=.02
		end
		if(the_pellet.y<60+rnd(8))then the_pellet.vy+=.02
		else the_pellet.vy-=.02
		end
		--if(the_pellet.y<64)then the_pellet.y+=.2
		--else the_pellet.y-=.2
		--end
		
		
		
		
		
		--vector to center
		the_pellet.x+=the_pellet.vx
		the_pellet.y+=the_pellet.vy
	end
end

function handle_wall_collide(the_pellet)

	if(not the_pellet.fixed) then
		if( ((the_pellet.x+the_pellet.vx+the_pellet.rad)>screen_right) or ((the_pellet.x+the_pellet.vx-the_pellet.rad)<screen_left))then the_pellet.vx=-the_pellet.vx 
		sfx(2,-1)
		end
		if( ((the_pellet.y+the_pellet.vy+the_pellet.rad)>screen_bottom) or ((the_pellet.y+the_pellet.vy-the_pellet.rad)<screen_top))then the_pellet.vy=-the_pellet.vy 
		sfx(2,-1)
		end
		
		the_pellet.x=mid(the_pellet.x,screen_left+the_pellet.rad,screen_right-the_pellet.rad)
		the_pellet.y=mid(the_pellet.y,screen_top+the_pellet.rad,screen_bottom-the_pellet.rad)
	end
end

function check_bbox_collide(pa,pb)
	if( (pa.x-pa.rad < pb.x+pb.rad) and
		(pa.x+pa.rad > pb.x-pb.rad) and
		(pa.y-pa.rad < pb.y+pb.rad) and
		(pa.y+pa.rad > pb.y-pb.rad)) then
			return true
		else
			return false
		end
		
end

function check_circ_collide(pa,pb)
	dist2= (pb.x-pa.x)*(pb.x-pa.x) + (pb.y-pa.y)*(pb.y-pa.y)
	if(dist2<= ((pa.rad+pb.rad)*(pa.rad+pb.rad)))then 
		collide_x = pa.x+(pb.x-pa.x)*(pa.rad/(pa.rad+pb.rad))
		collide_y =  pa.y+(pb.y-pa.y)*(pa.rad/(pa.rad+pb.rad))
		return true, collide_x, collide_y
	else
		return false
	end

end


--this naive collision method worked better than i would have thought
--check how far the balls have penetrated eachother and then create a restore
--vector that will keep them from touching. share this restore vector
--between the balls based on their mass or fixed status. this simulates
--glancing blows as well.
function	handle_rigid_collide(pa,pb)
	
	if(pa.active and pb.active ) then
		
		if( (pa.vx-pb.vx)*(pa.vx-pb.vx)+(pa.vy-pb.vy)*(pa.vy-pb.vy) > 2 )then
			sfx(0,-1)
		elseif( (pa.vx-pb.vx)*(pa.vx-pb.vx)+(pa.vy-pb.vy)*(pa.vy-pb.vy) > 1 )then
			sfx(1,-1)
		elseif( (pa.vx-pb.vx)*(pa.vx-pb.vx)+(pa.vy-pb.vy)*(pa.vy-pb.vy) > .25 )then
			sfx(2,-1)
		end
	
		dist = sqrt((pb.x-pa.x)*(pb.x-pa.x) + (pb.y-pa.y)*(pb.y-pa.y))
		rigid_dist = pa.rad + pb.rad
		rest_mag = rigid_dist-dist 
		
		rest_x = (pa.x-pb.x)/dist
		rest_y = (pa.y-pb.y)/dist
		
		percent_a = pb.mass/(pb.mass+pa.mass)
		percent_b = 1-percent_a
		if(pa.fixed) then percent_a=0 percent_b=1 end
		if(pb.fixed) then percent_a=1 percent_b=0 end
		
		
		pa.vx+=rest_x*rest_mag*percent_a
		pa.vy+=rest_y*rest_mag*percent_a
		pb.vx+=-rest_x*rest_mag*percent_b
		pb.vy+=-rest_y*rest_mag*percent_b
	
	end

end


function reset_pellet(the_pellet)
	the_pellet.collide=false

end

function handle_pellets()
	foreach(pellet_list,reset_pellet)

	
	for cur_pellet=1, #pellet_list do
		for check_pellet=cur_pellet+1, #pellet_list do
		pa=pellet_list[cur_pellet]
		pb=pellet_list[check_pellet]
			if(check_bbox_collide( pa,pb))then
				circ_collide, collide_x,collide_y = check_circ_collide(pa,pb)
				if(circ_collide)then
					pa.collide=true
					--handle_ball_collide(pa,pb)
					handle_rigid_collide(pa,pb)
					--pb.collide=true
					--pa.collide_x=collide_x
					--pa.collide_y=collide_y
				end
			end
		end
	end
	
	foreach(pellet_list,handle_wall_collide)
	
	foreach(pellet_list,update_pellet)
end



function shadow_palate()
	pal(1,13)
	pal(2,13)
	pal(3,13)
	pal(4,13)
	pal(5,13)
	pal(6,13)
	pal(7,13)
	pal(8,13)
	pal(9,13)
	pal(10,13)
	pal(11,13)
	pal(12,13)
	pal(13,13)
	pal(14,13)
	pal(15,13)	
end

function green_palate()
	pal(12,11)
	pal(6,10)
	pal(13,3)
	pal(1,5)
end

function red_palate()
	pal(12,8)
	pal(6,14)
	pal(13,4)
	pal(1,2)
end

function yellow_palate()
	pal(12,9)
	pal(6,10)
	pal(13,4)
	pal(1,2)
end




function	draw_blue_hippo(shadow)
	
	--draw neck
	spr(20,blue_hippo.head_start_x-8+blue_hippo.head_dx,blue_hippo.head_start_y+blue_hippo.head_dy-8,1,2)
	spr(20,blue_hippo.head_start_x-16+blue_hippo.head_dx,blue_hippo.head_start_y+blue_hippo.head_dy-8,1,2)
	spr(20,blue_hippo.head_start_x-24+blue_hippo.head_dx,blue_hippo.head_start_y+blue_hippo.head_dy-8,1,2)
	
	if(shadow==true or blue_hippo.head_pellet.active) then
	spr(5,blue_hippo.head_start_x+blue_hippo.head_dx,blue_hippo.head_start_y+blue_hippo.head_dy-16,3,4)
	else
	
	
	spr(5,blue_hippo.head_start_x+blue_hippo.head_dx-2,blue_hippo.head_start_y-1+blue_hippo.head_dy-16,1,4)
	spr(6,blue_hippo.head_start_x+blue_hippo.head_dx+6,blue_hippo.head_start_y-2+blue_hippo.head_dy-16,1,4)
	spr(7,blue_hippo.head_start_x+blue_hippo.head_dx+14,blue_hippo.head_start_y-3+blue_hippo.head_dy-16,1,4)
	--spr(8,blue_hippo.head_start_x+blue_hippo.head_dx+22,blue_hippo.head_start_y-4+blue_hippo.head_dy-16,1,4)
	end
	
	--draw_body
	spr(0,blue_hippo.head_start_x-32,blue_hippo.head_start_y-16,4,4)
end

function	draw_green_hippo(shadow)
	
	--draw neck
	spr(20,green_hippo.head_start_x+green_hippo.head_dx,green_hippo.head_start_y+green_hippo.head_dy-8,1,2)
	spr(20,green_hippo.head_start_x+8+green_hippo.head_dx,green_hippo.head_start_y+green_hippo.head_dy-8,1,2)
	spr(20,green_hippo.head_start_x+16+green_hippo.head_dx,green_hippo.head_start_y+green_hippo.head_dy-8,1,2)
	
	if(shadow==true or green_hippo.head_pellet.active) then
	spr(5,green_hippo.head_start_x-24+green_hippo.head_dx,green_hippo.head_start_y+green_hippo.head_dy-16,3,4,true,false)
	else
		spr(5,green_hippo.head_start_x-6+green_hippo.head_dx,green_hippo.head_start_y+green_hippo.head_dy-1-16,1,4,true,false)
		spr(6,green_hippo.head_start_x-14+green_hippo.head_dx,green_hippo.head_start_y+green_hippo.head_dy-2-16,1,4,true,false)
		spr(7,green_hippo.head_start_x-22+green_hippo.head_dx,green_hippo.head_start_y+green_hippo.head_dy-3-16,1,4,true,false)
		--spr(8,green_hippo.head_start_x-30+green_hippo.head_dx,green_hippo.head_start_y+green_hippo.head_dy-4-16,1,4,true,false)
	end
	
	--draw_body
	spr(0,green_hippo.head_start_x,green_hippo.head_start_y-16,4,4,true,false)
end

function	draw_red_hippo(shadow)
	
	--draw neck
	spr(129,red_hippo.head_start_x-8+red_hippo.head_dx,red_hippo.head_start_y-8+red_hippo.head_dy,2,1,false,false)
	spr(129,red_hippo.head_start_x-8+red_hippo.head_dx,red_hippo.head_start_y-16+red_hippo.head_dy,2,1,false,false)
	spr(129,red_hippo.head_start_x-8+red_hippo.head_dx,red_hippo.head_start_y-24+red_hippo.head_dy,2,1,false,false)
	
	if(shadow==true or red_hippo.head_pellet.active) then
	spr(144,red_hippo.head_start_x-16+red_hippo.head_dx,red_hippo.head_start_y+16+red_hippo.head_dy-16,4,4,false,false)
	else
		spr(144,red_hippo.head_start_x-16+red_hippo.head_dx,red_hippo.head_start_y-1+red_hippo.head_dy,4,1,false,false)
		spr(160,red_hippo.head_start_x-16+red_hippo.head_dx,red_hippo.head_start_y-2+8+red_hippo.head_dy,4,1,false,false)
		spr(176,red_hippo.head_start_x-16+red_hippo.head_dx,red_hippo.head_start_y-3+16+red_hippo.head_dy,4,1,false,false)
	end
	--end
	
	--draw_body
	spr(64,red_hippo.head_start_x-16,red_hippo.head_start_y-32,4,4,false,false)
end

function	draw_yellow_hippo(shadow)
	
	--draw neck
	spr(129,yellow_hippo.head_start_x-8+yellow_hippo.head_dx,yellow_hippo.head_start_y+yellow_hippo.head_dy,2,1)
	spr(129,yellow_hippo.head_start_x-8+yellow_hippo.head_dx,yellow_hippo.head_start_y+8+yellow_hippo.head_dy,2,1)
	spr(129,yellow_hippo.head_start_x-8+yellow_hippo.head_dx,yellow_hippo.head_start_y+16+yellow_hippo.head_dy,2,1)
	
	if(shadow==true or yellow_hippo.head_pellet.active) then
	spr(144,yellow_hippo.head_start_x-16+yellow_hippo.head_dx,yellow_hippo.head_start_y-16+yellow_hippo.head_dy-16,4,4,false,true)
	else
		spr(144,yellow_hippo.head_start_x-16+yellow_hippo.head_dx,yellow_hippo.head_start_y+1-8+yellow_hippo.head_dy,4,1,false,true)
		spr(160,yellow_hippo.head_start_x-16+yellow_hippo.head_dx,yellow_hippo.head_start_y+2-16+yellow_hippo.head_dy,4,1,false,true)
		spr(176,yellow_hippo.head_start_x-16+yellow_hippo.head_dx,yellow_hippo.head_start_y+3-24+yellow_hippo.head_dy,4,1,false,true)
	end
	--end
	
	--draw_body
	spr(64,yellow_hippo.head_start_x-16,yellow_hippo.head_start_y,4,4,false,true)
end


function	update_hippo(the_hippo)
	
	the_hippo.head_vx=mid(the_hippo.head_vx,-3,3)
	the_hippo.head_vy=mid(the_hippo.head_vy,-3,3)

	the_hippo.head_dx+=the_hippo.head_vx
	the_hippo.head_dy+=the_hippo.head_vy
	
	
	if(the_hippo.dir_x!=0)then
		if(the_hippo.head_dx*the_hippo.dir_x>the_hippo.head_max_extend)then the_hippo.head_dx=the_hippo.head_max_extend*the_hippo.dir_x the_hippo.head_vx=0 end
		if(the_hippo.head_dx*the_hippo.dir_x<0)then the_hippo.head_dx=0 the_hippo.head_vx=0 end
	end
	
	if(the_hippo.dir_y!=0)then
		if(the_hippo.head_dy*the_hippo.dir_y>the_hippo.head_max_extend)then the_hippo.head_dy=the_hippo.head_max_extend*the_hippo.dir_y the_hippo.head_vy=0 end
		if(the_hippo.head_dy*the_hippo.dir_y<0)then the_hippo.head_dy=0 the_hippo.head_vy=0 end
	end
	
	the_hippo.head_pellet.x=the_hippo.head_start_x+the_hippo.head_dx+16*the_hippo.dir_x
	the_hippo.head_pellet.y=the_hippo.head_start_y+the_hippo.head_dy+16*the_hippo.dir_y
	
	the_hippo.head_pellet.vx=the_hippo.head_vx
	the_hippo.head_pellet.vy=the_hippo.head_vy
	
	the_hippo.head_pellet.active=true
	if( (the_hippo.dir_y==0 and the_hippo.head_dx/the_hippo.head_max_extend*the_hippo.dir_x>.75)
		or (the_hippo.dir_x==0 and the_hippo.head_dy/the_hippo.head_max_extend*the_hippo.dir_y>.75)
	
		)then
		the_hippo.head_pellet.active=false
		
		if( (the_hippo.dir_y==0 and the_hippo.head_vx*the_hippo.dir_x<0)
		    or (the_hippo.dir_x==0 and the_hippo.head_vy*the_hippo.dir_y<0))then
			--grab near balls
			for pellet in all(pellet_list) do
				if(pellet.active and not pellet.fixed and check_circ_collide(the_hippo.head_pellet,pellet))then
					del(pellet_list,pellet)
					sfx(3,-1)
					the_hippo.in_mouth+=1
				end
			end
		end
	end
	
	if( (the_hippo.dir_y==0 and the_hippo.head_vx*the_hippo.dir_x>0)
		or (the_hippo.dir_x==0 and the_hippo.head_vy*the_hippo.dir_x>0))then
		if(the_hippo.in_mouth>0)then
			for i=1, the_hippo.in_mouth do
				new_pellet(the_hippo.head_pellet.x,the_hippo.head_pellet.y,the_hippo.head_pellet.vx,the_hippo.head_pellet.vy,4)
			end
			the_hippo.in_mouth=0
		end
	end
	
	if( (the_hippo.dir_y==0 and the_hippo.head_dx==0)
		or (the_hippo.dir_x==0 and the_hippo.head_dy==0))then
			the_hippo.score+=the_hippo.in_mouth
			the_hippo.in_mouth=0
	end
end


function handle_buttons()
	--head.vx=0
	--head.vy=0
	if(btn(0))then blue_hippo.head_vx+=.4 else blue_hippo.head_vx-=.4 end
	
	if(btn(1))then green_hippo.head_vx-=.4 else green_hippo.head_vx+=.4 end
	
	if(btn(2))then red_hippo.head_vy+=.4 else red_hippo.head_vy-=.4 end
	
	if(btn(3))then yellow_hippo.head_vy-=.4 else yellow_hippo.head_vy+=.4 end
	--if(btn(1))then head.vx=1 end
	--if(btn(2))then head.vy=-1 end
	--if(btn(3))then head.vy=1 end
	
	
end

function draw_field_back()

	rectfill(0,0,127,127,14)
	
	rectfill(screen_left,screen_top,screen_right-1,screen_bottom+1,15)
	

	
	spr(8,screen_left,screen_top)
	spr(24,screen_left,screen_top+8)
	
	spr(8,screen_right-8,screen_top,1,1,true,false)
	spr(24,screen_right-8,screen_top+8,1,1,true,false)
	sspr(64+7,0,1,8,screen_left+8,screen_top,screen_right-screen_left-16,8)
	
	spr(40,screen_left,screen_bottom-8+2)
	spr(40,screen_right-8,screen_bottom-8+2,1,1,true,false)

	sspr(64+7,16,1,8,screen_left+8,screen_bottom-8+2,screen_right-screen_left-16,8)
	
	
end



function draw_scores()
	pal()
	print(blue_hippo.score,2,82+1,13)
	print(blue_hippo.score,2,82,7)
	
	print(green_hippo.score,screen_right+2,42+1,13)
	print(green_hippo.score,screen_right+2,42,7)
	
	print(yellow_hippo.score,82,screen_bottom+4+1,13)
	print(yellow_hippo.score,82,screen_bottom+4,7)
	
	print(red_hippo.score,40,screen_top-8+1,13)
	print(red_hippo.score,40,screen_top-8,7)

end

function handle_game_start()
	if(#pellet_list<k_num_pellets and rnd(100)<30)then
		if(rnd(1)>0.5)then start_x=screen_left+8 else start_x=screen_right-8 end
		if(rnd(1)>0.5)then start_y=screen_top+8 else start_y=screen_bottom-8 end
		
		new_pellet(start_x,start_y,rnd(2)-1,rnd(2)-1,4,false)
	end
	
	if(#pellet_list==k_num_pellets)then
		game_mode=k_game_play_mode
		
		blue_hippo.score=0
		green_hippo.score=0
		red_hippo.score=0
		yellow_hippo.score=0
		
		new_particle(202,6,4,40+2,80+4,0,-5,.2,200)
		new_particle(9,6,4,40,80,0,-5,.2,200)
	end

end

function _init()

	--game_mode=k_title_screen_mode

	

	
	--new_pellet(32,68,2,0,8)
	--new_pellet(100,64,0,0,8)
	
	--blue_head=new_pellet(64,100,0,0,8,true)
	blue_body=new_pellet(8,64,0,0,16,true)
	green_body=new_pellet(120,64,0,0,16,true)
	red_body=new_pellet(64,8,0,0,16,true)
	yellow_body=new_pellet(64,120,0,0,16,true)
	--head.mass=200
	
		--new_pellet(rnd(screen_right-screen_left)+screen_left,rnd(screen_bottom-screen_top)+screen_top,rnd(4)-2,rnd(4)-2)
end

music_playing=false
function _update()
		cur_frame+=1
		update_particles()
		
		if(game_mode==k_game_play_mode)then
			wait_timer=0
		--if(cur_frame%4==0)then
			handle_buttons()
			
			update_hippo(blue_hippo)
			update_hippo(green_hippo)
			update_hippo(red_hippo)
			update_hippo(yellow_hippo)
			handle_pellets()
			
			if(#pellet_list==8)then game_mode=k_game_over_mode wait_timer=0 end
		end
	--	end
		if(game_mode==k_title_screen_mode and music_playing==false)then
			music(0,30)-- [n [fade_len [channel_mask]]]
			music_playing=true
			
		end
		if(game_mode==k_title_screen_mode)then
			wait_timer+=1
			if(wait_timer>wait_limit and (btnp(1) or btnp(2) or btnp(3) or btnp(0)))then 
			music_playing=false
			music(-1,60)
			game_mode=k_game_start_mode
			end
		end
		
		if(game_mode==k_game_start_mode)then
			handle_game_start()
			handle_pellets()
		end
		
		if(game_mode==k_game_over_mode) then 
			wait_timer+=1
			blue_hippo.head_vx=-1
			green_hippo.head_vx=1
			red_hippo.head_vy=-1
			yellow_hippo.head_vy=1
		
			update_hippo(blue_hippo)
			update_hippo(green_hippo)
			update_hippo(red_hippo)
			update_hippo(yellow_hippo)
			
			high_score=0
			high_score=max(blue_hippo.score,high_score)
			high_score=max(green_hippo.score,high_score)
			high_score=max(red_hippo.score,high_score)
			high_score=max(yellow_hippo.score,high_score)
		
			if(blue_hippo.score==high_score)then
				winner=1
			elseif(green_hippo.score==high_score)then winner=2
			elseif(red_hippo.score==high_score)then winner=3
			elseif(yellow_hippo.score==high_score)then winner=4
			end
			
			if(rnd(100)<90) then new_particle(winner*16-1,1,1,64,64,rnd(4)-2,-rnd(4),.2,50) end
			
			if(wait_timer>wait_limit and (btnp(1) or btnp(2) or btnp(3) or btnp(0)))then game_mode=k_title_screen_mode wait_timer=0 end
		end
	
	--if(check_bbox_collide(pellet_list[1],pellet_list[2]))then pellet_list[1].collide=true end
end

function draw_winner()
	if(winner==1)then color=12 text="blue wins"
	elseif(winner==2) then color = 11 text="green wins"
	elseif(winner==3) then color = 8 text="red wins"
	elseif(winner==4) then color = 9 text="yellow wins"
	end

	rectfill(64-25+1,64-10+2,64+25+1,64+10+2,13)
	rectfill(64-25,64-10,64+25,64+10,7)
	rect(64-25,64-10,64+25,64+10,color)
	
	print(text,64-#text/2*4+1,64-2,color)
end

function _draw()
	
	pal()

	draw_field_back()
	
	
	
	camera(-1,-2)
	shadow_palate()
	
	foreach(pellet_list,draw_pellet)
	
	
	
	draw_blue_hippo(true)
	draw_green_hippo(true)
	draw_red_hippo(true)
	draw_yellow_hippo(true)
	
	camera()
	pal()
			

	--draw_hippo_body(0,32)
	
	foreach(pellet_list,draw_pellet)

	
	draw_blue_hippo(false)
	green_palate()
	draw_green_hippo(false)
	red_palate()
	draw_red_hippo(false)
	yellow_palate()
	draw_yellow_hippo(false)
	
	draw_scores()
	
	if(game_mode==k_title_screen_mode)then
		pal(7,13)
		spr(69,19+2+sin(cur_frame/30+.05)*4,23+3,10,4)
		spr(69,27+2+sin(cur_frame/30+.1)*4,45+3,10,4)	
		spr(132,17+2+sin(cur_frame/30)*4,75+3,12,4)
		
		pal()
		spr(69,19+sin(cur_frame/30+.05)*4,23,10,4)
		spr(69,27+sin(cur_frame/30+.1)*4,45,10,4)	
		spr(132,17+sin(cur_frame/30)*4,75,12,4)
		
		
	end
	
	
	draw_particles()
	
	if(game_mode==k_game_over_mode)then
		draw_winner()
	end
	
	--print("cpu:"..stat(1),0,0,7)
	--print("blue:"..blue_hippo.score,0,8,0)
	--print("mouth:"..blue_hippo.in_mouth,0,16,0)
end
