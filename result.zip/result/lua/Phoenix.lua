-- phoenix 0.80
-- 2021 paul hammond

-- debug
--debug_stats=false
version="0.80"

-- cartridge data
cartdata("phammond_phoenix_80_p8")

-- movement
d_none=0
d_up=1
d_right=2
d_down=3
d_left=4

xinc={[0]=0,0,1,0,-1}
yinc={[0]=0,-1,0,1,0}

-- enums
gs_titles=0 -- game state
gs_game=3

tm_normal=0 -- title mode
tm_scoring=1

s_playing=0 -- session state
s_lostlife=1
s_levelstart=2
s_levelcomplete=3
s_gamecomplete=4
s_gameover=9

ps_normal=0 -- player state
ps_dying=1

bs_spawning=0 -- bird state
bs_formation=1
bs_diving=2

phs_spawning=0 -- phoenix state
phs_formation=1
phs_egg=2
phs_unspawning=3
phs_hatching=4

et_bird=0 -- entity type
et_phoenix=1
et_bullet=2
et_bomb=3
et_mothership=10

-- sfx and music
sfx_shipexplode=0
sfx_fire=1
sfx_explode1=2
sfx_bonuslife=3
sfx_levelcleared=4
sfx_explode2=5
sfx_gameover=6
sfx_winghit=7
sfx_shield=8
sfx_playerspawn=9
sfx_swoop1=10
sfx_swoop2=11
sfx_swoop3=12
sfx_bird_m=13
sfx_bird_d=14
sfx_bird_w=15
sfx_bird_s=16
--sfx_bonuslife

music_titles=0
music_levelintro1=56
music_levelintro2=40

-- other
hiscore=dget(0)
input={}

-- titles
title_text="2021 paul hammond (@paulhamx) ◆ testing by finn ◆ many thanks to paul niven (@nivz) for the logo ◆ use ❎ to fire 🅾️ to raise your shields. shields take several seconds to recharge"

function _init()
 -- enable keyboard
 poke(24365,1)

 -- palette
 poke(0x5f2e,1) 
 --[[
 pal(2,128+14,1)
 pal(3,128+10,1)
 pal(4,128+13,1)
 pal(5,128+1,1)
 pal(9,128+9,1)
 pal(11,138,1)
 --pal(8,136,1)
 pal(15,128+12,1)
 ]]--
 
 --palette_default={[0]=1,142,138,141,129,6,7,8,137,10,138,12,13,14,140}
 palette_default={[0]=0,1,142,139,141,129,6,7,8,137,10,138,12,13,14,140}
 pal(palette_default,1)
 palette_reset={[0]=0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
 
 -- initialise
 reset_titles()

 -- hi score
 if (hiscore<=0) hiscore=50
 
 -- stars
 srand(14)
 stars={}
 for i=1,100 do
  local fast=rnd(100)<50
  local s={x=rnd(128),y=rnd(128),speed=iif(fast,0.5,0.33),size=1,c=iif(fast,1,5)}
  add(stars,s)
 end 
 srand()
end

function reset_titles()
 flash=false
 state=gs_titles
 titlecounter=-40
 titlecounter2=0
 titlemode=tm_normal

 -- new hi score?
 if player and player.score>hiscore then
  hiscore=player.score

  -- save
  dset(0,hiscore)
 end

 -- initialise game so we can draw behind titles
 game_reset()

 -- sfx and music
 sfx(-1)
 music(music_titles)
 
 -- transition
 transition:start()
end

function _update60()
 -- counters
 flash=(time()*3)%2<1
 
 -- input (global just cos)
 input_update(input)
 
 -- update
 if state==gs_titles then
  -- titles
  update_titles()
 else
   -- game
  game_update() 

  if (gameover) reset_titles()
 end

 -- transition
 transition:update()
 
 -- quit game?
 if (kb("q")) gameover=true
end

function _draw()
 if state==gs_titles then
  draw_titles()
 else
  game_draw()
 end

 -- transition
 transition:draw()
end

function update_titles()
 -- game in demo mode
 game_update() 
 
 -- start game?
 if btnp(5) then
  state=gs_game
  game_reset()
 end

 -- counters
 titlecounter=(titlecounter+1)%1000
 titlecounter2+=1
 
 if btnp(4) then
  if titlemode==tm_scoring then
   titlemode=tm_normal
   titlecounter2=0
  else
   titlemode=tm_scoring
   titlecounter2=920
  end
 end
 
 -- switch title modes
 if titlecounter2==920 then
  titlemode=tm_scoring
  
  -- transition
  transition:start()  
 elseif titlecounter2==1300 then
  titlemode=tm_normal
  titlecounter=-40
  titlecounter2=0

  -- reset demo
  game_reset()
  
  -- transition
  transition:start()  
 end
end

function draw_titles()
 if titlemode==tm_normal then
  -- game in background
  game_draw()
 else
  -- scoring
  cls(0)
  
  -- stars
  stars_draw()
  
  -- entity scores
  local y=34
  
  spr(140,40,y,2,2)
  prints("20-80",64,y+5,8)
  y+=18
  
  spr(8,33,y,2,2)
  spr(8,44,y,2,2,true,false)
  prints("200",64,y+5,8)
  y+=18
  
  spr(106,36,y,3,2)  
  prints("100-800",64,y+5,8)
  y+=18
  
  spr(212,44,y+4)  
  prints("1000-9000",64,y+5,8)
 end
 
 -- high score
 if(titlecounter2>60) printc("hi "..pad0(hiscore,5).."0",2,8)

 -- logo
 draw_logo()
 
 -- message
 if (titlemode==tm_normal) prints(title_text,128-titlecounter,121,12)
 
 -- controls
 if (flash) printc("❎ start",108,7,true)
 
 -- version
 --if (time()<2) print(version,112,1,7)
end

function draw_logo()
 map(0,5,27,6,10,3)
end
-->8
-- game

function game_reset()
 -- initialise
 gameover=false
 level=0
 lives=3
 
 -- demo?
 demo=state==gs_titles
 if (demo) level=flr(rnd(4))
 
 -- clear music
 if (not demo) music(-1)
 
 -- objects
 player=player_create()

 -- reset level
 game_resetlevel(true)
end

function game_resetlevel(advance)
 -- advance?
 if advance then
  level+=1
  
  -- level properties
  birdspeedmultiplier=1
  formationx=0
  formationy=0
  formationdir=1
  formationspeed=1/6
  formationcounter=0
  
  mothership = nil  
  
  -- objects
  entities={}  
 end
 levelresolved=1+(level-1)%5
 round=(level-1)\5
 maxformationspeed=1
 phoenixnearbottom=false
 
 -- level properties
 countbirds=0
 countbullets=0
 countbombs=0
 countdiving=0
 counthatched=0
 
 nextsfxtime=0
 
 gamecompletebonus=0
 phoenixlevel=levelresolved==3 or levelresolved==4
 mothershiplevel=levelresolved==5
 formationdelaytime=30
 maxbombs=3+min(round,5)
 maxplayerbullets=iif(levelresolved==2,2,1)
 message=""

 -- objects
 particles={}
 player_resetlevel(player)
 
 -- define formation and palette
 if levelresolved==1 then
  -- birds 1
  if level>5 then
   formation={0,5,2,4,2,6,4,3,4,5,6,2,8,1,9,0,-2,4,-2,6,-4,3,-4,5,-6,2,-8,1,-9,0}
  else
   formation={5,0,7,1,9,2,9,3.5,7,4.5,5,5.5,3,6.5,0,6.5,0,4.5,-5,0,-7,1,-9,2,-9,3.5,-7,4.5,-5,5.5,-3,6.5}
  end
  palette={[10]=10,[12]=12,[14]=14,[15]=15}
 elseif levelresolved==2 then
  -- birds 2
  if level>5 then
   formation={0,0,2,1,4,2,6,3,8,4,6,5,4,6,2,7,0,7,-2,1,-4,2,-6,3,-8,4,-6,5,-4,6,-2,7}
  else
   formation={0,1,0,2,0,4,0,5.5,2,0,2,3,4,2,6,1,8,2,9,4,-2,0,-2,3,-4,2,-6,1,-8,2,-9,4}
  end
  palette={[10]=14,[12]=12,[14]=3,[15]=10}
 elseif levelresolved==3 then
  -- phoenixes 1
  formation={-6,0,-4,1.5,-2,3,0,4.5,2,6,4,7.5,6,9}
  palette={[10]=10,[12]=12,[14]=14,[15]=15}
 elseif levelresolved==4 then
  -- phoenixes 2
  formation={-6,0,-6,3,-6,6,-6,9,6,1.5,6,4.5,6,7.5,6,10.5}
  palette={[10]=10,[12]=14,[14]=14,[15]=15}
 elseif levelresolved==5 then
  -- mothership (with birds)
  formationdelaytime=90
  if level>5 then
   formation={0,0,0,6.5,2,0,4,1,6,2,8,3,2,6.5,4,6.5,6,6.5,-2,0,-4,1,-6,2,-8,3,-2,6.5,-4,6.5,-6,6.5}
  else
   formation={0,0,2,0.5,4,1,6,1.5,8,2,-2,0.5,-4,1,-6,1.5,-8,2}  
  end
  palette={[10]=14,[12]=12,[14]=3,[15]=10}
 end

 -- add/ reset mothership
 if mothershiplevel and advance then
  mothership=mothership_create()
  add(entities,mothership)
 end
 
 -- reset formation?
 if not advance then
  -- do not recreate formation
  formationdelaytime=0
 
  if (phoenixlevel) game_formation_reset()
 end
 
 -- finalise
 if advance and not demo then
  game_setstate(s_levelstart)
 else
  game_setstate(s_playing)
 end
 
 -- transition
 --if (advance and not demo) transition:start()
 
 -- sfx
 sfx(-1)
end

function game_formation_create()

--[[
if false then
local b=bird_create(64,10+6.5*6.5)  
add(entities,b)
b=bird_create(64,10+0*6.5)  
add(entities,b)
return
end
]]--

 birdspeedmultiplier=1
 formationx=0
 formationdir=1

 for i=1,#formation,2 do
  local fx,fy=formation[i],formation[i+1]
  local b
  
  if phoenixlevel then
   b=phoenix_create(65+fx*5,-8+fy*7)  
  else
   b=bird_create(64+fx*5,10+fy*6.5)  
  end
  
  add(entities,b)
 end
end

function game_formation_reset()
 --formationy=0
 formationdir=-1
 formationspeed=0.5
 maxformationspeed=1
 
 for e in all(entities) do
  if e.type==et_phoenix then
   if (e.state!=phs_egg) entity_setstate(e,phs_unspawning)
  end
 end
end

function game_setstate(s,c)
 gamestate=s
 gstatecount=c or 0
end

function game_update()
 -- initialise
 bombdropped=false -- only one bomb can be dropped per cycle
 
 -- stars
 stars_update()
 
 -- #########
 -- formation
 -- #########
 if gamestate!=s_levelstart then
  -- allow for double (or faster anyway) speed
  local loops=1
  if (birdspeedmultiplier==2 and gstatecount%2==0) loops=2
  
  for i=1,loops do
   -- formation position
   if formationdelaytime==0 then
    if phoenixlevel then
     -- =============
     -- phoenix level
     -- =============
     formationy+=formationspeed
     
     formationspeed+=formationdir/20
     if phoenixnearbottom then
      formationdir=1
      formationspeed=1.5
     elseif formationspeed>=maxformationspeed then
      formationdir=-1
     elseif formationspeed<=-1 then
      formationdir=1
     end
     
     -- sfx
     if gamestate==s_playing and nextsfxtime<=0 then
      local n=rnd(10)
      local se=sfx_swoop1
      nextsfxtime=70
      if n>8 then
       se=sfx_swoop2
       nextsfxtime=50
      elseif n>5 then
       se=sfx_swoop3
       nextsfxtime=100
      end
      gsfx(se,1)
     end
     
     -- gradually drop down
     if gstatecount>400 and gstatecount%45==1 then
      maxformationspeed+=0.1
      if maxformationspeed>=2 then
       maxformationspeed=1
      end
     end
    else
     -- ==========
     -- bird level
     -- ==========
     formationx+=formationdir*formationspeed
     
     -- prevent rounding errors since we must know that each complete formation cycle takes 339 game cycles
     if abs(formationx)<0.1 and formationdir==1 then
      --printh("formation return length="..formationcounter)
      formationx=0
      formationcounter=0
     else
      -- more of a debugging tool to prove that the formation takes 339 cycles
      formationcounter+=1
     end
     
     -- note: these values give an exact formation return cycle of 339 moves
     if formationx<=-14 then
      formationdir=1
     elseif formationx>=14 then
      formationdir=-1
     end
     
     -- start dive?
     if gstatecount%30==25 and rnd(10)<3+min(3,round) then
      birds_dive()
     end
    end
   end
   
   -- entities
   countbirds=0
   countdiving=0
   counthatched=0
   phoenixnearbottom=false
   
   for e in all(entities) do
    -- allow for double-speed birds
    -- note: actually, slower than double speed
    if i==1 or e.type==et_bird then
     e:update()
    end
    
    -- always test bullet hits otherwise when birds are double-speed, they may travel through the birds
    if (e.type==et_bullet) e:testcollisions()
    
    -- count/ flags
    if e.type==et_bird then
     countbirds+=1
     if (e.state==bs_diving) countdiving+=1
    elseif e.type==et_phoenix then
     if (e.y>100 or e.y<-10) phoenixnearbottom=true
     if (e.state==phs_formation) counthatched+=1
    end   
    
    if not e.active then
     del(entities,e)
     
     -- counts
     if e.type==et_bullet then
      countbullets-=1
     elseif e.type==et_bomb then
      countbombs-=1
     end
    end
   end
  end 
 end

 if gamestate==s_levelstart then
  -- ###########
  -- level start
  -- ###########
  if gstatecount==1 then
   if levelresolved==1 then
    -- scroll stars in from top
    for s in all(stars) do
     s.y-=140
    end
    
    if (level==1) message="player 1"
    
    -- music
    if round%2==0 then
     music(music_levelintro1)
    else
     music(music_levelintro2)
    end
   elseif levelresolved==2 then
    -- first wave cleared so start play immediatly
    game_setstate(s_playing)
   end
  elseif gstatecount==200 or (levelresolved>1 and gstatecount==90) then
   game_setstate(s_playing)
  end
 elseif gamestate==s_playing then
  -- #######
  -- playing
  -- #######
  if gstatecount==1 then
   message=""
   
   -- sfx
   gsfx(sfx_playerspawn,3)   
  end

  -- player
  if (not demo) player_update(player)
  
  -- respawn birds if all dead on mothership level
  if mothershiplevel and countbirds==0 and gamecompletebonus==0 and formationdelaytime<=0 then
   formationdelaytime=60
  end
  
  -- add formation
  if formationdelaytime>0 then
   formationdelaytime-=1
   
   if formationdelaytime==0 then
    game_formation_create()
    gstatecount=1
   end
  end
  
  -- double bird speed?
  if (countbirds==1 or (countbirds<4+round and gstatecount>900)) and levelresolved!=5 then
   birdspeedmultiplier=2
  end
  
  -- particles
  particles_update()
  
  -- level cleared?
  if formationdelaytime<=0 and player.state==ps_normal and #entities==0 and #particles==0 then
   game_setstate(s_levelcomplete)
  end
 elseif gamestate==s_levelcomplete then
  -- ##############
  -- level complete
  -- ##############
  if gstatecount==1 then
   -- sfx
   --sfx(sfx_levelcleared)
  elseif gstatecount==30 then
   -- next level
   game_resetlevel(true)   
  end
 elseif gamestate==s_gamecomplete then
  -- #############
  -- game complete
  -- #############
  if gstatecount==1 then
   message=gamecompletebonus.."0"
   
   -- bonus
   player_scoreadd(gamecompletebonus)
   
   -- sfx
   --sfx(sfx_levelcleared)
  elseif gstatecount==120 then
   -- next level
   game_resetlevel(true)   
  end  
 elseif gamestate==s_lostlife then
  -- #########
  -- lost life
  -- #########
  if gstatecount>=15 and not phoenixnearbottom then
   lives-=1
   if lives==0 then
    game_setstate(s_gameover)
   else
    game_resetlevel(false)
   end
  end
 elseif gamestate==s_gameover then
  -- #########
  -- game over
  -- #########
  if gstatecount==1 then
   message="game over"
   
   -- sfx
   sfx(sfx_gameover)
  elseif gstatecount==260 then
   gameover=true
  end
 end
 
 -- other
 player.displayscore=move(player.displayscore,player.score,2)
 
 -- counters
 if (nextsfxtime>0) nextsfxtime-=1
 gstatecount+=1
end

function game_draw()
 cls(0)

 -- stars
 stars_draw()
 
 -- offset in demo mode to accomodate logo
 if (demo) camera(0,-26)
 
 if gamestate==s_levelstart then
  -- ###########
  -- level start
  -- ###########
  if phoenixlevel then
   -- asterisk fill as per arcade version
   local n=1+flr(gstatecount/2)
   
   if (n<20) clip(64-4*n,67-6*n,8*n,12*n)
   for y=1,22 do
    print("********************************",0,2+y*6,12)
   end
   clip()
   if n>20 then
    n-=20
    rectfill(64-n*4,3+64-n*6,63+n*4,3+64+n*6,0)
   end
  end
 elseif gamestate==s_playing or gamestate==s_lostlife then
  -- #######
  -- playing
  -- #######
  -- entities
  pal(palette)
  for e in all(entities) do
   e:draw()
  end
  pal(palette_reset)

  -- player
  if (not demo) player_draw(player)
    
  -- particles
  pal(palette)
  particles_draw()
  pal(palette_reset)
 end
 
 -- score panel
 if (not demo) game_draw_scorepanel()
 
 -- message
 if message then
  printc(message,52,8)
 end
 
 pal(4,4)
 
 camera()
end

function game_draw_scorepanel()
 pal(1,0)
 
 -- score
 prints("p1",1,1,12)
 if flash and player.score>hiscore then
 else
  prints(pad0(flr(player.displayscore),5).."0",10,1,8)
 end
 
 -- hi score
 prints("hi",46,1,12)
 prints(pad0(hiscore,5).."0",56,1,8)
 
 -- level
 spr(2,84,0)
 prints(level,93,1,9)
 
 -- shield available
 --if player.shieldtime<=-240 and flash then
 -- spr(3,100,0)
 --end
 
 -- lives
 for i=1,lives do
  spr(1,122-i*3,0)
 end
 
 pal(1,1)

end



-- player
function player_create()
 local s={
  score=0,
  displayscore=0,
  frames={202,204,206,204},
  speed=0.75,
 }

 player_resetlevel(s)
 
 return s
end

function player_resetlevel(s)
 -- reset
 s.x=64
 s.y=119
 s.moved=false
 s.shieldtime=-210
 
 entity_setstate(s,ps_normal)
end

function player_update(s)
 -- dying?
 if s.state==ps_dying then
  s.statecount+=1
  if s.statecount>=120 and countdiving==0  then
   game_setstate(s_lostlife)
  end
  
  return
 end
 
 -- speed
 local speed=s.speed
 if (player.shieldtime>0) speed*=0.33
 
 -- move
 local oldx=s.x
 if input.left then
  s.x-=speed
 elseif input.right then
  s.x+=speed
 end
 s.x=mid(5,s.x,123)
 s.moved=s.x!=oldx
 
 -- fire
 if input.fire2hit and countbullets<maxplayerbullets and player.shieldtime<=0 then
  bullet_add(s)
  
  -- sfx
  sfx(sfx_fire,3)
 end
 
 -- raise shield
 if input.fire1hit and s.shieldtime==-240 then
  s.shieldtime=45
  
  -- sfx
  sfx(sfx_shield,3)  
 end
 
 -- hit rectangle (centred)
 if s.shieldtime>0 then
  s.hitrect=rectc(s.x,s.y,8,8) 
 else
  s.hitrect=rectc(s.x,s.y,6,6) 
 end
 
 -- collision checks
 for e in all(entities) do
  if e.type==et_bomb or e.type==et_bird or e.type==et_phoenix then
   if rectsoverlap(e.hitrect,s.hitrect) then
    if s.shieldtime>0 then
     -- destroy
     e:destroy()
     
     -- low score to discourage use of shiled as a weapon
     if e.type!=et_bomb then
      player_scoreadd(2)
     end
    else
     -- destroy player
     entity_setstate(s,ps_dying)
    end
   end
  end
  
  -- mothership collision (i.e., too low)
  if mothershiplevel and mothership.y>=109 then
  -- destroy player
  entity_setstate(s,ps_dying)   
  end
  
  if s.state==ps_dying then
   -- particles
   particles_add(player.x,player.y,18,8,true,false)
   
   -- sfx
   sfx(sfx_shipexplode,3)
   
   break
  end
 end
 
 -- counters
 s.statecount+=1 
 if (s.shieldtime>-240) s.shieldtime-=1
end

function player_draw(s)
 if (s.state==ps_dying) return
 
 -- ship
 local f=s.frames[1+flr(s.x/4)%#s.frames]
 if (not s.moved) f=202
 spr(f,s.x-7,s.y-7,2,2)

 -- shield
 if s.shieldtime>0 then
  local r=iif(s.shieldtime%10<5,9,8)
  circ(s.x,s.y+1,r-2,12)
 end
 
 -- spawning
 if s.state==ps_normal and s.statecount<25 then
  --fillp(0b0101101001011010.1)
  local r=50-s.statecount*2
  circfill(s.x,s.y,r,8)
  --fillp()
  --circfill(s.x,s.y,r-2,8)
 end
 
 --if (s.hitrect) rect(s.hitrect.x,s.hitrect.y,s.hitrect.x+s.hitrect.w,s.hitrect.y+s.hitrect.h,11) 
end

function player_scoreadd(v)
 local oldscore=player.score
 
 player.score+=v
 
 if (player.score>=1000 and oldscore<1000) or (player.score>=2000 and oldscore<2000) then
  lives+=1
  
  -- sfx
  sfx(sfx_bonuslife)
 end
end



-- particles
function particles_add(x,y,count,colour,large,downward)
 for i=1,count do
  if (#particles>100) return
  
  add(particles,{x=x-4+rnd(8),y=y-4+rnd(8),colour=colour,ttl=80,dx=0.5-rnd(1),dy=-rnd(1)*iif(downward,0.25,1),r=iif(large,2+rnd(2),1.5)})
  --add(particles,{x=x,y=y,colour=colour,ttl=60,dx=0.5-rnd(1),dy=-rnd(1),r=iif(large,1.5,0.5)})
 end
end

function particles_draw()
  for p in all(particles) do
  circfill(p.x,p.y,p.r,p.colour)
 end
end

function particles_update()
 for p in all(particles) do
  p.x+=p.dx
  p.y+=p.dy
  p.dy+=0.03--0.05
  p.r-=0.04
  p.ttl-=1
  if (p.ttl<=0 or p.r<=0) del(particles,p)
 end
end



-- stars
function stars_draw()
 for s in all(stars) do
  if s.spr then
   spr(s.spr,s.x,s.y,s.size,s.size)
  else
   pset(s.x,s.y,s.c)
  end
 end
end

function stars_update()
 for s in all(stars) do
  s.y+=s.speed
  if s.y>148 then
   s.y-=168
   if (s.spr) s.x=rnd(112)
  end
 end
end



-- entity
function entity_setstate(s,st,c)
 s.state=st
 s.statecount=c or 0
end



-- bird
function bird_create(x,y)
 local s={
  type=et_bird,
  active=true, 
  fx=x,
  fy=y,
  
  update=bird_update,
  draw=bird_draw,
  reset=bird_reset,
  destroy=bird_destroy
 }

 -- reset
 bird_reset(s)
 
 return s
end

function bird_reset(s)
 s.x=s.fx
 s.y=s.fy
 s.hitwidth=1
 
 s.frame=-1
 s.framesize=1
 s.rotation=0
 
 s.soaring=false
 
 --s.divepattern=nil
 --s.divepatternpos=0
 --s.diveinstuction=nil
 --s.divepatterncounter=0
 
 entity_setstate(s,bs_spawning)
end

function bird_update(s)
 local walkingframe=1+flr(gstatecount/10)%#anim_bird_formation
 local soaringframe=1+flr(s.statecount/4)%#anim_bird_soaring

 if s.state==bs_spawning then
  -- ========
  -- spawning
  -- ========
  local i=1+flr((s.statecount/2))  
  
  hitwidth=3
  
  if i>#anim_bird_spawning then
   entity_setstate(s,bs_formation)
  else
   -- animation
   s.frame=anim_bird_spawning[i]
  end
 end
 
 if s.state==bs_formation then
  -- =========
  -- formation
  -- =========
  s.x=s.fx+formationx
  s.y=s.fy
  
  -- animation
  s.framesize=2
  s.frame=anim_bird_formation[walkingframe]
  s.rotation=0
  
  -- hit width is based on frame
  s.hitwidth=bird_formation_hitwidths[walkingframe]
 elseif s.state==bs_diving then
  -- ======
  -- diving
  -- ======
  if s.statecount==0 then
   s.hitwidth=6
   s.framesize=2
   
   -- reset for new dive
   s.divepatternpos=0
   s.diveinstuction=nil
   s.divepatterncounter=0
   s.rotation=0
   
   s.divedebugcounter=0
   s.divedebugstartx=s.x
   s.divedebugstarty=s.y
   s.divedebugpoints={}
   --printh("dive start="..s.divedebugstartx..","..s.divedebugstarty)
  end
  
  -- initialise
  s.soaring=false
  
  -- next instruction?
  while(true) do
   if s.divepatterncounter==0 then
    s.divepatternpos+=1
    if s.divepatternpos>#s.divepattern then
     -- back into formation
     entity_setstate(s,bs_formation)
     
     -- debug
     --printh("dive end="..s.x..","..s.y)
     --printh("difference="..(s.divedebugstartx-s.x)..","..(s.divedebugstarty-s.y))
     --printh("dive cycles="..s.divedebugcounter)
     
     break
    else
     -- next instruction
     local instruction=s.divepattern[s.divepatternpos]
     --printh("instruction="..instruction)
     
     -- parse
     local arr=split(instruction)
     s.diveinstuction=arr[1]
     s.divepatterncounter=tonum(arr[2])
     if #arr>2 then
      s.diveparam1=tonum(arr[3])
     else
      s.diveparam1=nil
     end
     
     -- immediate action?
     if s.diveinstuction=="a" then
      -- -----------------------------
      -- angle (45 degree increments)
      -- -----------------------------
      s.rotation=s.divepatterncounter
      s.divepatterncounter=0       
     elseif s.diveinstuction=="r" then
      -- -----------------------------
      -- rotate (45 degree increments)
      -- -----------------------------
      s.rotation=flr((s.rotation+s.divepatterncounter)%8)
      s.divepatterncounter=0
     end
     
     -- sfx
     if nextsfxtime<=0 then
      if s.diveinstuction=="m" then
       gsfx(sfx_bird_m,2)
      elseif s.diveinstuction=="s" then
       gsfx(sfx_bird_s,2)
      elseif s.diveinstuction=="d" then
       gsfx(sfx_bird_d,2)
      elseif s.diveinstuction=="w" then
       gsfx(sfx_bird_w,2)
      end
      
      nextsfxtime=10
     end
    end
   end
   
   if (s.divepatterncounter!=0) break   
  end
  
  local rotation=1+flr(s.rotation%8)  
  
  -- handle dive instruction
  if s.state==bs_diving then
   -- soaring (worth extra points to shoot)
   s.soaring=s.diveinstuction=="s"
  
   if s.diveinstuction=="d" then
    -- ----
    -- drop
    -- ----
    local speed=1
      
    s.y+=speed*sgn(s.divepatterncounter)
    
    -- animation
    s.frame=32
    
    -- counter
    s.divepatterncounter=move(s.divepatterncounter,0,speed)
    
    -- rotate?
    if s.divepatterncounter==0 then
     -- finished so reset rotation
     s.rotation=0
    else
     s.rotation+=0.25*sgn(s.divepatterncounter)
    end
   elseif s.diveinstuction=="m" then
    -- ------------------------------------
    -- move (in current rotation direction)
    -- ------------------------------------
    dx=-sin(s.rotation/8)
    dy=-cos(s.rotation/8)
    local speed=1
      
    s.x+=dx*speed
    s.y+=dy*speed
    
    -- animation
    s.frame=32
    
    -- counter
    --printh("speed="..speed)
    --printh("s.divepatterncounter="..s.divepatterncounter)
    s.divepatterncounter=move(s.divepatterncounter,0,speed)
    
    -- rotate?
    if s.diveparam1 then
     s.rotation+=s.diveparam1
    end
   elseif s.diveinstuction=="s" then
    -- ----
    -- soar
    -- ----
    local speed=1
      
    s.x+=speed*sgn(s.divepatterncounter)
    s.y-=speed
    
    -- animation
    s.frame=anim_bird_soaring[soaringframe]

    -- set rotation in case we need to switch moves (and to assist with animation)
    if s.divepatterncounter<0 then
     s.rotation=7
    else
     s.rotation=1
    end
    
    -- counter
    s.divepatterncounter=move(s.divepatterncounter,0,speed)
   elseif s.diveinstuction=="w" then
    -- -----------------------------
    -- walking (as per in formation)
    -- -----------------------------
    s.x+=sgn(s.divepatterncounter)*formationspeed
    
    -- animation
    s.frame=anim_bird_formation[walkingframe]
    
    -- counter
    s.divepatterncounter=move(s.divepatterncounter,0,formationspeed)
   end
  end
  
  -- debug
  s.divedebugcounter+=1
  add(s.divedebugpoints,{s.x,s.y})
 end
 
 -- drop bomb
 -- note: by using gstatecount, the same bird is more likely to drop multiple bombs, like in the arcade version
 local n=iif(s.state==bs_diving,2,20) 
 if not demo and s.state!=bs_spawning and gstatecount%30<10 and rnd(n)<1 then
  bomb_add(s,2)
 end
 
 -- hit rectangle (centred)
 s.hitrect=rectc(s.x,s.y,s.hitwidth,8)
 
 -- counters
 s.statecount+=1 
end

function bird_draw(s)
 local f=s.frame
 local flipx,flipy=false,false
 local rotation=1+flr((s.rotation+0.5)%8)
 
 -- rotation
 if f<16 then
  -- soaring
  flipx=s.rotation==1
 elseif f==32 or f==33 then
  -- rotated dive (1 or 2-frames)
  f=({32,36,40,36,32,36,40,36})[rotation]
  if (s.frame==33) f+=2
  flipx=({false,false,false,false,false,true,true,true})[rotation]
  flipy=({false,false,false,true,true,true,false,false})[rotation]
 end
 
 spr(f,s.x-4*s.framesize,s.y-4*s.framesize,s.framesize,s.framesize,flipx,flipy)
 
 -- debug
 --[[
 if false then
  if s.divedebugpoints then
   for i in all(s.divedebugpoints) do
    pset(i[1],i[2],8)
   end
  end
  rect(s.fx+formationx-3,s.fy-3,s.fx+formationx+3,s.fy+3,9) 
  --if (s.hitrect) rect(s.hitrect.x,s.hitrect.y,s.hitrect.x+s.hitrect.w,s.hitrect.y+s.hitrect.h,11) 
 end
 ]]--
end



-- birds
function birds_dive()
 if countdiving>level or player.state!=ps_normal then
  return
 end

 -- initialise
 local added=0
 local maxdivecount=4+min(5,round)

 -- get dive pattern (different set defined for each of the 3 bird levels)
 local patternset=dive_patterns[levelresolved]
 local pattern=patternset[1+flr(rnd(#patternset))]

 -- dive
 for e in all(entities) do
  if countdiving>=maxdivecount then
   break
  elseif e.type==et_bird and e.state==bs_formation and (added==0 or rnd(10)<1) then
   -- dive
   entity_setstate(e,bs_diving)
   e.divepattern=pattern
   
   added+=1
   countdiving+=1
   
   -- perfect circle (just for the hell of it)?
   if rnd(20)<1 then
    e.divepattern={"a,2","m,339,0.02359"}
    break
   end
  end
 end
end

function bird_destroy(s)
 s.active=false
 
 -- particles
 particles_add(s.x,s.y,12,8,false)

 -- sfx
 sfx(sfx_explode1,2)
end


-- phoenix
function phoenix_create(x,y)
 local s={
  type=et_phoenix,
  index=#entities,
  active=true, 
  
  fx=x,
  fy=y,
  
  update=phoenix_update,
  draw=phoenix_draw,
  reset=phoenix_reset,
  destroy=phoenix_destroy
 }

 -- reset
 phoenix_reset(s)
 
 return s
end

function phoenix_reset(s)
 s.x=s.fx
 s.y=s.fy
 
 s.hitwidth=1
 
 s.speed=0.1
 s.xdir=1
  
 s.leftwingspawntime=0
 s.rightwingspawntime=0
 s.frame=-1
 
 entity_setstate(s,phs_spawning)
 
 -- ensure spawning and movement isn't quite in sync
 s.statecount=s.index*10
 s.maxspeed=1.5--4+s.index/20 
end


function phoenix_update(s)

 local speed=s.speed

 if s.state==phs_spawning then
  -- ========
  -- spawning
  -- ========
  local i=1+flr((s.statecount/20))  
  
  if i>#anim_phoenix_spawning then
   entity_setstate(s,phs_egg)
  else
   -- animation
   s.spawnwidth=1
   s.frame=anim_phoenix_spawning[i]

   -- hit rect is based on frame
   s.hitwidth=min(i/4,4)
  end
 elseif s.state==phs_egg then
  -- ===
  -- egg
  -- ===
  s.hitwidth=4
  
  if s.statecount>=90 and gamestate==s_playing then
   entity_setstate(s,phs_hatching)
  end
  
  -- animation
  s.spawnwidth=1  
  s.frame=70+flr((s.statecount/2)%2)
 elseif s.state==phs_hatching then
  -- ========
  -- hatching
  -- ========
  s.hitwidth=4
  
  local i=1+flr((s.statecount/10))  
  
  if i>#anim_phoenix_hatching then
   entity_setstate(s,phs_formation)
  else
   -- slow down
   speed*=0.15
   
   -- animation
   s.spawnwidth=2
   s.frame=anim_phoenix_hatching[i]
  end
 elseif s.state==phs_unspawning then
  -- ==========
  -- unspawning
  -- ==========
  s.hitwidth=4
  
  local i=1+flr((s.statecount/10))  
  
  if i>#anim_phoenix_hatching then
   entity_setstate(s,phs_egg)
  else
    -- animation
   s.spawnwidth=2
   s.frame=anim_phoenix_unspawning[i]
  end  
 end
 
 if s.state==phs_formation then
  -- =========
  -- formation
  -- =========
  s.hitwidth=24
  
  -- return to egg form?
  if (s.leftwingspawntime==0 and s.rightwingspawntime==0 and s.statecount%240==239 and rnd(1)<0.5) entity_setstate(s,phs_unspawning)
  
  -- random change of direction
  if (rnd(100)<1+round*3) s.xdir*=-1

  -- drop bomb
  -- note: by using gstatecount, the same bird is more likely to drop multiple bombs, like in the arcade version
  if gstatecount%30<10 and rnd(2)<1 then
   bomb_add(s,2)
  end

  -- animation
  if s.statecount<10 then
   s.frame=100
  else
   s.frame=anim_phoenix_flapping[1+flr((s.statecount/9)%#anim_phoenix_flapping)]
  end
 end
  
 -- always moving side-to-side
 s.x+=speed
 s.speed+=s.xdir/20
 s.speed=mid(-s.maxspeed,s.speed,s.maxspeed)
 if s.x>=110-s.maxspeed*10 then
  s.xdir=-1
 elseif s.x<=16+s.maxspeed*10 then
  s.xdir=1
 end
 
 -- y position is always fixed relative to start position
 s.y=s.fy+formationy
 while (s.y>128) do s.y-=140 end
 
 -- hit rectangle
 if s.state==phs_formation then
  -- left aligned
  local sx,w=s.x-10,20
  if s.leftwingspawntime>0 then
   sx+=8
   w-=8
  end
  if s.rightwingspawntime>0 then
   w-=8
  end
  s.hitrect=rectl(sx,s.y-4,w,8)
 else
  -- centred
  s.hitrect=rectc(s.x,s.y,s.hitwidth,8)
 end
  
 -- counters
 s.statecount+=1 
 if (s.leftwingspawntime>0) s.leftwingspawntime-=1
 if (s.rightwingspawntime>0) s.rightwingspawntime-=1
end

function phoenix_draw(s)
 if s.state==phs_formation then
  -- always draw in 3 parts
  local x,y=s.x-11,s.y-7
  local f,flipx
  
  -- left wing
  if s.leftwingspawntime==0 then
   f=s.frame
  elseif s.leftwingspawntime<60 then
   f=96+flr(s.leftwingspawntime/20)
  else
   f=-1
  end  
  if (f!=-1) spr(f,x,y,1,2)
  x+=8
  
  -- body
  spr(s.frame+1,x,y,1,2)
  x+=8
  
  -- right wing
  if s.rightwingspawntime==0 then
   f=s.frame+2
  elseif s.rightwingspawntime<60 then
   f=96+flr(s.rightwingspawntime/20)
   flipx=true
  else
   f=-1
  end  
  if (f!=-1) spr(f,x,y,1,2,flipx,false)
 elseif s.spawnwidth==2 then
  spr(s.frame,s.x-7,s.y-3,2,1)
 else
  spr(s.frame,s.x-3,s.y-3)
 end
 
 --if (s.hitrect) rect(s.hitrect.x,s.hitrect.y,s.hitrect.x+s.hitrect.w,s.hitrect.y+s.hitrect.h,11)
end

function phoenix_destroy(s)
 s.active=false
 
 -- particles
 particles_add(s.x,s.y,8,8,false)
 particles_add(s.x,s.y,8,9,false)

 -- sfx
 sfx(sfx_explode1)
end



-- bullet
function bullet_add(player)
 local s={
  type=et_bullet,
  active=true,
  x=player.x,
  y=player.y-1,
  
  speed=5,
  collisionradius=1,
  
  draw=bullet_draw,
  update=bullet_update,
  testcollisions=bullet_testcollisions
 }
 
 add(entities,s)
 
 -- count
 countbullets+=1
end

function bullet_update(s)
 s.y-=s.speed
 
 -- hit rectangle (centred)
 s.hitrect=rectc(s.x,s.y,2,4) 
 
 -- finished?
 if (s.y<-12) s.active=false
end

function bullet_draw(s)
 line(s.x,s.y-1,s.x,s.y+1,7)
 
 --if (s.hitrect) rect(s.hitrect.x,s.hitrect.y,s.hitrect.x+s.hitrect.w,s.hitrect.y+s.hitrect.h,11) 
end

function bullet_testcollisions(s)
 -- entity collisions
 for e in all(entities) do
  if not e.hitrect then
   -- entity not yet fully initialised
  elseif e.type==et_bird then
   -- ====
   -- bird
   -- ====
   if rectsoverlap(s.hitrect,e.hitrect) then
    e:destroy()
    s.active=false
    
    -- calculate score based on distance from player
    local d=distance(e,player)
    local sc=mid(2,flr((110-d)/10),8)
    if (e.soaring) sc=20

    -- fireball
    if e.soaring then
     fireball_add(e,sc.."0")
    end

    -- add score
    player_scoreadd(sc)    
    
    break
   end
  elseif e.type==et_phoenix then
   -- =======
   -- phoenix
   -- =======
   if rectsoverlap(s.hitrect,e.hitrect) then
    -- calculate score
    local d=distance(e,player)
    local sc=mid(5,flr((110-d)/7),10)
    
    -- body or wing hit?
    if s.x<=e.x-4 then
     -- left wing
     if e.leftwingspawntime==0 then
      e.leftwingspawntime=180
      
      -- score
      player_scoreadd(sc)

      -- particles
      particles_add(e.x-8,e.y,8,12,false)
      particles_add(e.x-8,e.y,4,8,false)
     
      -- sfx
      sfx(sfx_winghit)
     end
    elseif s.x>=e.x+4 then
     -- right wing
     if e.rightwingspawntime==0 then
      e.rightwingspawntime=180
      
      -- score
      player_scoreadd(sc)

     -- particles
     particles_add(e.x+8,e.y,8,12,false)
     particles_add(e.x+8,e.y,4,8,false)
      
      -- sfx
      sfx(sfx_winghit)      
     end
    else
     -- body
     e:destroy()
     s.active=false

     -- fireball?
     if e.leftwingspawntime<=0 and e.rightwingspawntime<=0 then
      sc*=8
      fireball_add(e,sc.."0")
     else
      sc*=2
     end
     
     -- score
     player_scoreadd(sc)    
    end

    break
   end
  elseif e.type==et_mothership then
   -- ==========
   -- mothership
   -- ==========
   if rectsoverlap(s.hitrect,e.hitrect) then
    if e:hit(s) then
     s.active=false
    end
   end
  end
 end
end



-- fireball
function fireball_add(e,text)
 local s={
  type=et_fireball,
  active=true, 
  x=e.x,
  y=e.y,
  dist=0,
  text=text,
  
  update=fireball_update,
  draw=fireball_draw
 }
 
 add(entities,s)
end

function fireball_update(s)
 s.dist+=3
 if (s.dist>130) s.active=false
 
 particles_add(s.x-s.dist+8,s.y,1,8)
 particles_add(s.x-s.dist+8,s.y,1,9)
 --particles_add(s.x-s.dist,s.y,2,7)
 
 particles_add(s.x+s.dist-8,s.y,1,8)
 particles_add(s.x+s.dist-8,s.y,1,9)
 --particles_add(s.x+s.dist,s.y,2,7) 
end

function fireball_draw(s)
 -- text
 if (s.text) print(s.text,s.x-#s.text*2,s.y-2,8)

 spr(4,s.x-s.dist,s.y-7,2,2)
 spr(6,s.x+s.dist,s.y-7,2,2)
end



-- mothership
function mothership_create()
 local s={
  type=et_mothership,
  active=true,
  x=64,
  y=-24,
  h=48,
  
  alienactive=true,
  
  hitwidth=104,
  columns={},
  belt={},
  beltpos=0,
  
  statecount=0,
  
  update=mothership_update,
  draw=mothership_draw,
  hit=mothership_hit
 }
 
 -- create destructible columns (the orange bottom of the ship)
 for x=1,26 do
  local c={x=8+x*4,y=8,w=4}
  c.h=({2,4,7,9,11,12,13,14,15,15,16,16,16,16,16,16,15,15,14,13,12,11,9,7,4,2})[x]
  c.starth=c.h
  
  add(s.columns,c)
 end
 
 -- create centre belt
 for x=0,27 do
  local b={active=true,frame=192,x=8+x*4,y=2,w=4,h=4,hits=0}
  if (x%2<1) b.frame=208
  
  add(s.belt,b) 
 end

 return s
end

function mothership_update(s)
 -- drop?
 if s.alienactive then
  if gamestate==s_playing then
   if s.statecount<68 then
    s.y+=1
   elseif s.statecount%100==99 then
    s.y+=1
   end
  elseif gamestate==s_lostlife then
   -- move up a bit if too low
   if (s.y>70) s.y-=1
  end
 end
 
 -- centre belt
 if s.statecount%3==0 then
  for b in all(s.belt) do
   b.x+=1
   if (b.x>112) b.x-=108
  end
 end
 
 -- alien drop bomb
 if s.alienactive and s.statecount>80 and s.statecount%30<10 and rnd(8)<1 then
  bomb_add(s,3)
 end
 
 -- alien destroyed
 if not s.alienactive then
  if s.statecount==90 then
   game_setstate(s_gamecomplete)
  end
 end

 -- hit rectangles (centred)
 s.hitrect=rectc(s.x,s.y,s.hitwidth,s.h)
 s.alienhitrect=rectc(s.x,s.y-2,8,12)
 
 -- counters
 s.statecount+=1 
end

function mothership_draw(s)
 -- top of ship
 map(0,0,20,s.y-20,14,4)
 spr(231,54,s.y-16)
 spr(231,65,s.y-16)
 local f=flr(s.statecount/10)%6
 spr(232+f,54,s.y-22) 
 spr(232+f,66,s.y-22,1,1,true,false) 
 
 -- alien
 if s.alienactive then
  --spr(231+flr((s.statecount/10))%6,60,s.y-9,1,2)
  spr(195+f,60,s.y-13,1,2)
  --spr(231,59,s.y-9,1,2)
 end
 
 -- destructible columns
 for c in all(s.columns) do
  if c.h>0 then
   rectfill(c.x,s.y+c.y,c.x+c.w-1,s.y+c.y+c.h-1,9)
   if c.h!=c.starth then
    pset(c.x+1,s.y+c.y+c.h-1,0)
    pset(c.x+3,s.y+c.y+c.h-1,0)
   end
  end
 end
 
 -- centre belt
 clip(12,0,104,128)
 for b in all(s.belt) do
  if (b.active) spr(b.frame,b.x,s.y+b.y)
 end
 clip()
 
 --if (s.hitrect) rect(s.hitrect.x,s.hitrect.y,s.hitrect.x+s.hitrect.w,s.hitrect.y+s.hitrect.h,11) 
 --if (s.alienhitrect) rect(s.alienhitrect.x,s.alienhitrect.y,s.alienhitrect.x+s.alienhitrect.w,s.alienhitrect.y+s.alienhitrect.h,11) 
 
 -- finalise
 --camera()
end

function mothership_hit(s,bullet)
 -- destructible columns
 for c in all(s.columns) do
  if c.h>0 and bullet.x>=c.x and bullet.x<c.x+c.w and bullet.y<=s.y+c.y+c.h then
   c.h-=1
   
   -- particles
   particles_add(bullet.x,bullet.y,2,9,false,true)
   
   -- sfx
   
   
   return true
  end
 end
 
 -- centre belt
 for b in all(s.belt) do
  if b.active and bullet.x>=b.x and bullet.x<b.x+b.w and bullet.y<=s.y+b.y+b.h then
   b.hits+=1
   if b.hits==2 then
    b.active=false
   else
    b.frame+=1
   end
   
   -- particles
   particles_add(bullet.x,bullet.y,2,4,false,true)
   
   -- sfx
   
   
   return true
  end
 end
 
 -- alien
 if s.alienactive and rectsoverlap(s.alienhitrect,bullet.hitrect) then
  s.alienactive=false
  s.statecount=0
    
  -- particles
  particles_add(s.x,s.y,40,4,true,false)
  
  -- calculate bonus
  gamecompletebonus=mid(1,mothership.y*9,900)
  
  -- sfx
  sfx(sfx_shipexplode)
  
  -- destroy all other entities
  for e in all(entities) do
   if e.type!=et_mothership then
    e.active=false
    particles_add(e.x,e.y,8,7,false,false)
   end
  end
 end
 
 -- not hit
 return false
end



-- bomb
function bomb_add(entity,offsety)
 -- can we drop a bomb?
 if bombdropped or gamecompletebonus>0 or gstatecount%2==0 or gstatecount<60 or gamestate!=s_playing or player.state!=ps_normal or countbombs>=maxbombs then
  return
 end

 local s={
  type=et_bomb,
  active=true,
  x=entity.x,
  y=entity.y-2+(offsety or 0),
  
  speed=1.6,--75,--1.5,
  
  draw=bomb_draw,
  update=bomb_update,
  destroy=bomb_destroy
 }
 
 add(entities,s)
 
 -- count
 countbombs+=1 
 
 -- prevent multiple bombs being dropped per cycle
 bombdropped=true
end

function bomb_update(s)
 s.y+=s.speed
 
 -- hit rectangle (centred)
 s.hitrect=rectc(s.x,s.y,1,3) 
 
 -- finished?
 if (s.y>130) s.active=false
end

function bomb_draw(s)
 line(s.x,s.y-1,s.x,s.y+1,7)
 
 --if (s.hitrect) rect(s.hitrect.x,s.hitrect.y,s.hitrect.x+s.hitrect.w,s.hitrect.y+s.hitrect.h,11) 
end

function bomb_destroy(s)
 s.active=false
 
 particles_add(s.x,s.y,4,7,false,false) 
end
-->8
-- helper

function gsfx(s,c)
 if (not demo) sfx(s,c)
end

function rectl(x,y,w,h)
 return {x=x,y=y,w=w,h=h}
end

function rectc(x,y,w,h)
 return {x=x-w/2,y=y-h/2,w=w,h=h}
end

function pad0(n,l)
 local s="0000000000"..n
 return sub(s,#s-l+1)
end

function lerp(a,b,t) 
 return a*(1-t)+b*t
end

function kb(k)
 return stat(30) and stat(31)==k
end

function lerp(a,b,t) 
 return a*(1-t)+b*t
end

function iif(c,t,f)
 if c then
  return t
 else
  return f
 end
end

function move(c,d,s)
 if (c<d) return min(c+s,d)
 if (c>d) return max(c-s,d)
 return c
end

function printc(s,y,c,shad,sc)
 -- detect wide characters
 local offx=0
 for i=1,#s do
  if (ord(sub(s,i,i))>134) offx+=2
 end

 local x=64-offx-#s*2
 if shad then
  prints(s,x,y,c,sc) 	
 else
  ? s,x,y,c
	end
end

function prints(s,x,y,c,sc)
 for y1=-1,1 do
  for x1=-1,1 do
   ? s,x+x1,y+y1,sc or 0
  end
 end

	? s,x,y,c
end

function rectsoverlap(e1,e2,e1offsetx,e1offsety)
 if (e1offsetx==nil) e1offsetx=0
 if (e1offsety==nil) e1offsety=0
 return (e1.x+e1offsetx)<e2.x+e2.w and e2.x<e1.x+e1.w+e1offsetx and (e1.y+e1offsety)<e2.y+e2.h and e2.y<e1.y+e1.h+e1offsety
end

function distance(e1,e2)
 local dx=e1.x-e2.x
 local dy=e1.y-e2.y
 return sqrt(dx^2+dy^2)
end



-- input
function input_update(s)
 s.moved=false
 local olddir=s.dir
 
 s.up=btn(2)
 s.down=btn(3)
 s.left=btn(0)
 s.right=btn(1)
 s.fire1=btn(4)
 s.fire2=btn(5)
 s.fire1hit=s.fire1 and not s.fire1old
 s.fire2hit=s.fire2 and not s.fire2old
 
 if s.up then
  s.dir=d_up
 elseif s.right then
  s.dir=d_right
 elseif s.down then
  s.dir=d_down
 elseif s.left then
  s.dir=d_left
 else
  s.dir=d_none
 end
 
 s.moved=s.dir!=olddir
 s.fire1old=s.fire1
 s.fire2old=s.fire2
 
 -- fire 2 held down n/a if moving
 if (s.fire2downtime==nil) s.fire2downtime=0
 if s.fire2 and s.dir==d_none then
  s.fire2downtime+=1 
 else
  s.fire2downtime=0
 end
end
-->8
-- effects

-- transition
transition={
 
 start=function(self,colour) 
  self.value=-8
 end,
 
 draw=function(self)
  if self.value<128 then
   fillp(0b0101101001011010.1)
   rectfill(0,self.value,128,128,0)
   fillp()
   rectfill(0,self.value+8,128,128,0)
  end
 end,
 
 update=function(self)
  if (self.value<128) self.value+=3
 end
}
-->8
-- data

-- animation
anim_bird_spawning={142,143,158,159}
anim_bird_formation={136,138,140,138}
anim_bird_soaring={8,10,12,14,12,10}

bird_formation_hitwidths={7,9,11,9}

anim_phoenix_spawning={64,64,64,64,65,65,66,66,67,67,68,68,68,68,68}
anim_phoenix_unspawning={82,80,78,76,74}
anim_phoenix_hatching={74,76,78,80,82}
anim_phoenix_flapping={100,103,106,109,106,103}

-- dive patterns (instruction, count)
--  * walk
--    * w,14          (walk 14px to the right, use a negative number for left)
--  * drop
--    * d,10          (drop 10 while spinning)
--  * move
--    * m,10          (move 10px in current rotation direction)
--    * m,10,0.1      (move 10px in current rotation direction while rotating 0.1 each cycle)
--  * rotate
--    * r,2           (rotate without moving where number is the number of 45 degree intervals)
--  * angle
--    * a,2           (like rotate but not relative to the current angle)
--  * soar
--    * s,-20         (soar 20 pixels up to the left)
--
-- note: each must return to start position (within 1px) after 339 cycles although anything from 300 is okay if soaring back and y position is pretty close

dive_patterns={}

-- level 1
dive_patterns[1]={
 -- zig-zag
 {"a,0","m,20,0.2","d,16","a,5","m,17","a,3","m,17","a,5","m,17","a,3","m,17","m,20,-0.15","w,-12","d,8","w,11","s,-46","s,20"},
 
 -- loopy
 {"a,2","m,2","a,7","m,15,-0.025","m,20,-0.2","m,20,0.2","m,60,-0.1","m,32,-0.2","m,40,-0.12","m,40,0.15","d,54","a,2","m,1","s,20","s,-17","s,19"},
 {"a,2","m,12","a,7","m,120,-0.05","m,40,0.2","m,30,0.1","m,20,0.01","m,15,0.1","m,15,0.2","s,15","s,-15","s,12","s,-24","w,-3.4"},

 -- weave along the bottom
 {"d,20","a,2","m,80,0.1","m,20,0.2","m,20,-0.2","m,20","m,50,0.1","m,-30,-0.075","m,-45,0.125","s,20","s,-17","s,18"},
 
 -- harder patterns
 {"a,1","m,20,0.2","a,4","m,40,-0.2","d,38","a,3","m,30,-0.1","m,30,-0.2","m,30,0.2","m,40,-0.1","m,20,-0.075","w,-4","s,20","s,-20","s,13","s,-13"},
 {"a,6","m,10,-0.1","a,3","m,12","a,5","m,12","a,3","m,12","a,5","m,12","a,3","m,12","a,5","m,12","m,40,0.2","d,13","a,4","m,50,-0.1","s,-20","m,40,0.15","a,5","m,20","m,20,0.1","s,-13","s,40"}
}

-- level 2
dive_patterns[2]={
 {"a,0","m,20,0.2","d,16","a,5","m,17","a,3","m,17","a,5","m,17","a,3","m,17","m,20,-0.15","w,-12","d,8","w,11","s,-46","s,20"},
 {"d,20","a,2","m,80,0.1","m,20,0.2","m,20,-0.2","m,20","m,50,0.1","m,-30,-0.075","m,-45,0.125","s,20","s,-17","s,18"},

 {"a,2","m,90,0.0275","m,60,0.15","m,100,0.05","m,40,0.25","a,6","m,-14","s,-27"},
 {"a,6","m,90,-0.0275","m,60,-0.15","m,100,-0.05","m,40,-0.25","a,2","m,14","s,27"},
 
 {"a,6","m,20","m,60,-0.075","d,30","w,10","a,2","m,50,-0.05","w,8","d,8","w,-4","s,-30","s,6"},
 {"a,2","m,20","m,60,0.075","d,30","w,-10","a,6","m,50,0.05","w,-8","d,8","w,4","s,30","s,-6"},
 
 {"a,1","m,20,0.2","a,4","m,40,-0.2","d,38","a,3","m,30,-0.1","m,30,-0.2","m,30,0.2","m,40,-0.1","m,20,-0.075","w,-4","s,20","s,-20","s,13","s,-13"},
 {"a,6","m,10,-0.1","a,3","m,12","a,5","m,12","a,3","m,12","a,5","m,12","a,3","m,12","a,5","m,12","m,40,0.2","d,13","a,4","m,50,-0.1","s,-20","m,40,0.15","a,5","m,20","m,20,0.1","s,-13","s,40"},
 
 {"a,6","m,8,-0.1","d,20","a,4","m,20,0.1","m,30,-0.1","m,20,0.3","s,20","a,2","m,40,0.04","m,30,0.1","s,-20","s,20","m,40,0.125","d,10","s,-12","s,12","s,-12","s,16","s,-10"},
}

-- level 5
dive_patterns[5]={
 {"a,2","m,90,0.0275","m,60,0.15","m,100,0.05","m,40,0.25","a,6","m,-14","s,-27"},
 {"a,6","m,10,-0.1","a,3","m,12","a,5","m,12","a,3","m,12","a,5","m,12","a,3","m,12","a,5","m,12","m,40,0.2","d,13","a,4","m,50,-0.1","s,-20","m,40,0.15","a,5","m,20","m,20,0.1","s,-13","s,40"},
 {"a,6","m,8,-0.1","d,20","a,4","m,20,0.1","m,30,-0.1","m,20,0.3","s,20","a,2","m,40,0.04","m,30,0.1","s,-20","s,20","m,40,0.125","d,10","s,-12","s,12","s,-12","s,16","s,-10"},

 -- double length (680 cycles)
 {"a,2","m,12,0.1","m,20,0.2","m,60,-0.075","m,80,0.055","m,40,0.1","s,20","a,2","m,40,0.05","m,30,-0.08","s,10","s,-40","a,6","m,50,-0.05","m,30,0.1","s,-20","a,0","m,20,0.2","m,60,0.08","a,2","m,41","s,30","s,-10","s,14","m,53,0.135"},
 
}
