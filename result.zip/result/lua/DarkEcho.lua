-- dark echo
-- by rac7 games

-- tweaky things
line_fade_speed = 4
min_tap_waves = 4
max_tap_waves = 20
tap_lifetime = 3
move_spd = 0.4
sound_spd = 1.1
nme_spd = 0.375
footstep_interval = 13
nme_radius = 7

-- stupidity
sure=true
nope=false

-- initialization
time_til_fade=line_fade_speed
sounds = {}
enemies = {}
areas = {}
ticks = 0
tap_down_time = -1
footstep_counter = 0
time_til_footstep = footstep_interval
dude = {}
totally_dead = nope
won_teh_game = nope
is_sneaking = nope
should_fade = sure
nme_rad_sqr = nme_radius*nme_radius
level = nil
death_time = -1
game_state = 0
ticks_in_state = 0

-- tests
show_perf_hud = nope
skip_to_game = nope
level_index=1

-- constants
sfx_big_tap=02
sfx_med_tap=03
sfx_small_tap=04
sfx_death=10
sfx_win=06
sfx_left_step_jason=35
sfx_right_step_jason=36
sfx_left_step_jesse=00
sfx_right_step_jesse=01
music_ambient=00
music_nme=01
area_exit = 0
area_trap = 1
area_trigger = 2
area_water = 3
greyscale = {0,5,6,7}

function _init()
	cls()
	color(7)

	if(skip_to_game) then
		goto_state(1)
	else 
		goto_state(0)
	end
	music(music_ambient,2000,0xe)
end

function _update()
	update_scheduler()
	if update_func != nil then
		update_func()
	end
	ticks+=1
	ticks_in_state+=1
end

function _draw()
	if draw_func != nil then
		draw_func()
	end
end

function goto_state(state)
	cls()
	pal()
	game_state = state
	ticks_in_state = 0
	local do_fade=sure
	if state == 0 then
		update_func = update_title
		draw_func = draw_title
	elseif state == 1 then
		update_func = update_game
		draw_func = draw_game
		start_level(level_index)
		do_fade=sure
	elseif state == 2 then
		update_func = nil
		draw_func = draw_win
		do_fade=sure
	elseif state == 3 then
		update_func = nil
		draw_func = draw_text
	end
	
	if do_fade then
		set_screen_fade(3)
		fade_in(10)
	end
end 

-- title stuff

pressed_title=nope
function update_title()
	if pressed_title then
		
	else
		if(bor(btn()) > 0) then
			pressed_title = sure
			--next_level()
			schedule_evt(20,fade_out,10)
			schedule_evt(50,next_level)
			sfx(13)
		end
	end
end

function draw_title()
	cls()
	local s = 1
	local e = 10
	local t = ticks
	for x=1,16 do
		pal(x,fade_inout(s,e,t*0.3+x),0)
	end
	local sc=1
	local dw=81*sc
	local dh=16*sc*1.4
	local dx=(128-dw)*0.5
	local dy=50-dh*0.5
	sspr(0,8,81,16,dx,dy,dw,dh)
	for x=1,16 do
		pal(x,x,0)
	end
	local c = fade_inout(1,10,ticks_in_state*0.5)
	
	if pressed_title then
		if ticks%4<2 then 
			c=7 
		else 
			c=5
		end
	end
	print("press button",64-12*2,90,c)
	spr(15,24,121)
	print("1982 rac7 megacorp",34,122,7)

	grain_fx()
end

-- text stuff

function show_text(txt)
	text = txt
	goto_state(3)
	sfx(14)
	schedule_evt(90, function()
		sfx(15)
		fade_out(10)
	end)
	schedule_evt(100, function()
		goto_state(1)
	end)
end

function draw_text()
	local len = #text
	local x = 64-len*2
	local y = 60
	print(text, x, y, 7)
end

-- win stuff

function draw_win()
	rectfill(0,0,128,128,7)
	local dt = flr(ticks_in_state/5)
	local c = 7
	if dt==10 then
		c = 6
	elseif dt==11 then
		c = 5
	elseif dt>11 then
	 c = 0
	end
	print("you will never escape",24,60,c)
	
	if dt>30 and ticks%20<10 then
		print("thanks for playing!",64-18*2,72)
	end
end

-- game stuff

function update_game()
	if(totally_dead) then
			update_dead_dude() 
		elseif(won_teh_game) then
			update_win()
		else
			update_dude()
		end
		foreach(sounds, update_sound)
		foreach(enemies, update_nme)
end

function draw_game()
	if(should_fade) game_fade()
	draw_dude()
	foreach(sounds, draw_sound)
	foreach(enemies, draw_nme)
	if show_perf_hud then
		perf_hud()
	end
end

function next_level()
	show_text(level_names[level_index])
end

function start_level(lvl)
	level = levels[lvl]
	dude.x = level.start.x
	dude.y = level.start.y
	totally_dead = nope
	won_teh_game = nope
	should_fade = sure
	nmes_engaged = 0
	clear_level()
	
	-- compromise!
	if rnd(2) < 1 then
	sfx_left_step=sfx_left_step_jesse
	sfx_right_step=sfx_right_step_jesse
else
	sfx_left_step=sfx_left_step_jason
	sfx_right_step=sfx_right_step_jason
end
	
	for nme in all(level.nmes) do
		make_nme(nme.x, nme.y)
	end
	
	for a in all(level.areas) do
		make_area(a)
	end
	
	make_sound_burst(dude.x, dude.y,5,6,7)
end

function clear_level()
	sounds = {}
	enemies = {}
	areas = {}
	stuck_lines = {}
	tapping=nope
end

-- dude stuff

function update_dude()
	dude.last_x = dude.x
	dude.last_y = dude.y
	
	dude.is_moving = 
			band(btn(),0xf)>0
			
	if (btn(0,0)) dude.x-=move_spd
	if (btn(1,0)) dude.x+=move_spd
	if (btn(2,0)) dude.y-=move_spd
	if (btn(3,0)) dude.y+=move_spd
	
	if dude.is_moving then
		dude_collision()
	end
	
	-- tap
	if (btn(4,0)) then
		if not tapping then
			tap_down_time=ticks
			end
		tapping = sure
	elseif(tapping) then
		dude_tap(ticks - tap_down_time)
		tapping = nope
	end
	
	-- sneak
	is_sneaking = btn(5,0)
	if(is_sneaking) then
		footstep_counter=8
	end
	
	-- areas
	local area = get_area(dude.x,dude.y)
	if(area != nil) then
		if area.type == 0 then
			dude_reach_exit()
		elseif area.type == 1 then
			kill_dude()
		elseif area.type == 2 then
			-- trigger
		elseif area.type == 3 then
			-- water
		end
	end
end

function dude_collision()
	local did_recollide = nope
	::recollide::
	local hit = intersect_walls(
			dude.last_x, dude.last_y,
			dude.x, dude.y
	)
	if hit != nil then
		local vel = v2normalize(
				dude.x-dude.last_x,
				dude.y-dude.last_y
				)
		-- project it and recollide
		local p = v2project(dude.x,dude.y,
												hit.wall[1],
												hit.wall[2],
												hit.wall[3],
												hit.wall[4]
												)
		-- this works around a weird
		--  with v2project
		-- 2lazy2fix
		if v2len(dude.x-p.x,dude.y-p.y) < 2
				and not did_recollide then
			local f = v2normalize(
					dude.x-p.x,dude.y-p.y)
			dude.x = p.x - f.x
			dude.y = p.y - f.y
			did_recollide = sure
			goto recollide
		else
			dude.x = hit.x-vel.x*1
			dude.y = hit.y-vel.y*1
		end
	end
end

function dude_tap(str)
	str = min(max_tap_waves, str)
	str = max(min_tap_waves, str)
	local lifetime = str*tap_lifetime
	make_sound_burst(
			dude.x,dude.y,
			str,
			lifetime,
			7)
	local vol = str/max_tap_waves
	if vol < 0.33 then
		sfx(sfx_small_tap)
	elseif vol < 0.66 then
		sfx(sfx_med_tap)
	else
		sfx(sfx_big_tap)
	end
end

function draw_dude()
	--circ(dude.x,dude.y,1,7)
	if(dude.is_moving and 
			not is_sneaking) then
		time_til_footstep-=1
	end
	
	if(time_til_footstep<=0
			and not is_sneaking) then
		time_til_footstep+=footstep_interval
		make_sound_burst(
				dude.x,dude.y,7,35,7
		)
		if footstep_counter%2==0 then
			sfx(sfx_left_step,0)
		else
			sfx(sfx_right_step,0)
		end
		footstep_counter+=1
	end
end

function dude_reach_exit()
 won_teh_game = sure
 win_time = ticks
	should_fade = nope
	dude.is_moving = nope
	make_sound_burst(dude.x,dude.y,
			40,500,7)
			
	music(-1)
	sfx(sfx_win)
end

function update_win()
	local dt = ticks-win_time
	if(dt == 60) then
			clear_level()
			flash_screen(7)
	elseif(dt == 70) then
			if(level_index >= count(levels)) then
					goto_state(2)
					return
			else
					flash_screen(6)
			end
	elseif(dt == 75) then
			flash_screen(5)
	elseif(dt == 80) then
			flash_screen(0)
	elseif(dt == 100) then
		music(music_ambient,2000,0xe)
		level_index+=1
		next_level()
	end
end


function kill_dude()
	if totally_dead 
				or won_teh_game then 
		return 
	end
	
	totally_dead = sure
	should_fade = nope
	dude.is_moving = nope
	death_time = ticks
	make_sound_burst(dude.x,dude.y,
			40,500,8)
	music(-1)
	sfx(sfx_death,0)
	sfx(11,1)
	sfx(12,2)
end

function update_dead_dude()
	local dt = ticks-death_time
	if(dt == 20) then
	elseif(dt == 90) then
			clear_level()
	elseif(dt>90 and dt < 100)then
			
			flash_screen(8)
	elseif(dt == 100) then
		cls()
		music(music_ambient,2000,0xe)
		start_level(level_index)
	end
end

-- sound stuff

function make_sound_burst(
		x,y,num_waves,life,color
		)
	angle = rnd(1/num_waves)
	for i=1,num_waves do
		angle += 1/num_waves
		local vx = cos(angle)
		local vy = sin(angle)
		make_sound(
				x,y,vx,vy,life,color)
	end
end

function make_sound(
		x,y,vx,vy,life,color
		)
	local s = {}
	s.x = x
	s.y = y
	s.vx = vx*sound_spd
	s.vy = vy*sound_spd
	s.last_x = x
	s.last_y = y
	s.life = life
	s.maxlife = life
	s.color = color
	s.origin_x = x
	s.origin_y = y
	s.time = ticks
	add(sounds, s)
end

function update_sound(s)
	s.last_x = s.x
	s.last_y = s.y
	s.x+=s.vx
	s.y+=s.vy
	s.life-=1
	if(s.life<0) del(sounds,s)
	
	local hit = intersect_walls(
			s.last_x,s.last_y,s.x,s.y
	)
	if(hit != nil) then
		s.x = hit.x
		s.y = hit.y
		sound_bounce(s,hit.wall)
	end
end

function sound_bounce(s,l)
	local normal = v2normalize(
			-(l[4] - l[2]),
			l[3] - l[1]
	)
	local dot = v2dot(
			normal.x,normal.y,
			s.vx,s.vy
	)
	-- move line back a tiny bit
	-- so it wont get stuck
	s.x -= s.vx * 0.001
	s.y -= s.vy * 0.001
	s.vx += normal.x * dot * -2
	s.vy += normal.y * dot * -2
end

function draw_sound(s)
	local clr = s.color
	local area = get_area(s.x,s.y)
	
	if(area != nil) then
		clr = area.color
		if should_fade then
			add(stuck_lines,{
					x0=s.last_x,
					y0=s.last_y,
					x1=s.x,
					y2=s.y,
					color=clr,
					life=3,
					super_thick=clr==7
			})
		end
	end
	
	line(s.last_x, s.last_y,
		 s.x, s.y, clr)
end

-- for making lines in areas
-- stay around longer
stuck_lines = {}
function draw_stuck_lines()
	for s in all(stuck_lines) do
		line(s.x0,s.y0,
							s.x1,s.y2,
							s.color)
		if s.super_thick then
			line(s.x0-1,s.y0-1,
								s.x1+1,s.y2+1,
								s.color)
		end
		s.life-=1
		if s.life <= 0 then
			del(stuck_lines, s)
		end
	end
end

-- enemy junk

function make_nme(x,y)
	local nme = {x=x,y=y}
	nme.target=nil
	nme.targettime = 0
	add(enemies, nme)
end

function update_nme(nme)

	local dx,dy,d,n
	
	for s in all(sounds) do
		dx = s.x - nme.x
		dy = s.y - nme.y
		if s.color != 8 and 
					v2sqrlen(dx,dy) 
					< nme_rad_sqr then
			if s.time >= nme.targettime then
				if nme.target == nil then
					start_nme_music()
				end
				nme.target = {x=s.origin_x, y=s.origin_y}
				nme.targettime = s.time
			end
			del(sounds, s)
			break
		end
	end
	
	if nme.target != nil then
		dx=nme.target.x-nme.x
		dy=nme.target.y-nme.y
		d = v2len(dx,dy)
		if d < nme_spd then
			nme.x = nme.target.x
			nme.y = nme.target.y
			nme.target = nil
			stop_nme_music()
		else
			n = v2normalize(dx,dy)
			nme.x += n.x * nme_spd
			nme.y += n.y * nme_spd
		end
	end
	
	-- if touch dude, kill dude.
	dx=dude.x-nme.x
	dy=dude.y-nme.y
	if v2sqrlen(dx, dy)
				<= nme_rad_sqr then
		kill_dude()
	end
end

function draw_nme(nme)
	if(ticks%2==0 and 
				nme.target != nil) then
		make_sound_burst(
				nme.x,nme.y,5,7,8)
	end
end

nmes_engaged = 0
function start_nme_music()
	nmes_engaged+=1
	if nmes_engaged == 1 
				and not won_teh_game
				and not totally_dead then
		music(music_nme, 500,0xc)
	end
end

function stop_nme_music()
	nmes_engaged-=1
	if nmes_engaged <= 0 and
			not won_teh_game and
			not totally_dead then
		nmes_engaged = 0
		music(music_ambient, 2000, 0xe)
	end
end

-- areas

function make_area(a)
	local area = {
		type=a[1],
		sx=a[2],
		sy=a[3],
		ex=a[2]+a[4],
		ey=a[3]+a[5]
	}
	
	area.color = area_color(area.type)
	
	add(areas, area)
end

function get_area(x, y)
	for area in all(areas) do
		if(x >= area.sx and 
					y >= area.sy and
					x <= area.ex and
					y <= area.ey) then
			return area
		end
	end
	
	return nil
end

function area_color(type)
	if type == 1 then
		return 8
	end
	return 7
end

-- full screen fx

function game_fade()
	time_til_fade-=1
	if time_til_fade <= 0 then
		time_til_fade = line_fade_speed
		
		local x = 0
		local y = 0
		while y < 128 do
			x = 0
			while x < 128 do
				val =	pget(x,y)
				if(val == 0) then
					goto skip
				elseif(val == 8) then
					val = 0
				elseif(val > 5) then
					val-=1
				elseif(val == 5) then
					val = 0
				end
				pset(x,y,val)
				::skip::
				x+=1
			end
			y+=1
		end
		
		draw_stuck_lines()
	end
end

function flash_screen(colour)
	rectfill(0,0,128,128,colour)
end

function fade_inout(hold,time,p)
	local spd = 1/(1-hold/time)
	local val = (p%time)/time
	if val < 0.5 then
		val *= 2
	else
		val = 1 - (val - 0.5)*2
	end
	
	val *= spd
	
	return greyscale[1+min(3,flr(val*3))]
end

function set_screen_fade(val)
-- 0 = no fade. 3 = pure black.
	pal(7,greyscale[max(1,4-val)],1)
	pal(6,greyscale[max(1,3-val)],1)
	pal(5,greyscale[max(1,2-val)],1)
end

function fade_out(dur)
	schedule(dur, function(t) 
		set_screen_fade(flr(0+3*(t/dur)))
	end)
end

function fade_in(dur)
	schedule(dur, function(t)
		set_screen_fade(flr(4-4*(t/dur)))
	end)
end

function grain_fx()
	if(rnd(10)<1) then
		pset(rnd(128),rnd(128), 5+rnd(3))
	end
end

-- maaaaaath

function v2dot(x0,y0,x1,y1)
	return x0*x1+y0*y1
end

function v2normalize(x,y)
	local l = v2len(x, y)
	if(l == 0) return {x=0,y=0}
	return {x=x/l,y=y/l}
end

function v2len(x,y)
	local v = x*x+y*y
	return sqrt(v)
end

function v2sqrlen(x,y)
	return x*x+y*y
end

function v2project(x,y,x0,y0,x1,y1)
		local px,py
		
		-- i think this has severe
		-- precision issues, oh well
		
		local n = v2normalize(x1-x0,y1-y0)
		local dp = v2dot(x-x0,y-y0,n.x,n.y)
		px=x0+ dp* n.x
		py=y0+ dp * n.y
		
		return {
			x=px,
			y=py
		}
end

function intersect(
		x0,y0,x1,y1,x2,y2,x3,y3
		)
	local s1x,s1y,s2x,s2y,d,s,t
	
	s1x = x1-x0
	s1y = y1-y0
	s2x = x3-x2
	s2y = y3-y2
	
	d=(-s2x*s1y+s1x*s2y)
	if(d == 0) return nil
	
	s=(-s1y*(x0-x2)+s1x*(y0-y2))/d
	t=(s2x*(y0-y2)-s2y*(x0-x2))/d
	
	if(s>=0 and s<=1 and t>=0 and t<=1) then
		return {
				x=x0+t*s1x,
				y=y0+t*s1y
		}
	end
	
	return nil
end

function intersect_walls(
			x0, y0, x1, y1
			)
	-- todo: partition
	for l in all(level.walls) do
		local hit = intersect(
				x0,y0,x1,y1,
				l[1],l[2],l[3],l[4]
				)
		if hit != nil then
			hit.wall = l
			return hit
		end
	end
	
	return nil
end

-- scheduler !

scheduler = {}

function update_scheduler()
	for item in all(scheduler) do
		local is_evt = item.evt
		local time_up = item.ticks == ticks
		if not is_evt or
					time_up then
			if item.func != nil then
				if item.param != nil then
					item.func(item.param)
				else
					item.func(ticks-item.start)
				end
			end
		end
		if time_up then
			del(scheduler, item)
		end
	end
end

-- schedule a one-time event
function schedule_evt(wait,func,param)
	add(scheduler,{
			func=func,
			ticks=ticks+wait,
			start=ticks,
			evt=sure,
			param=param
	})
end

-- schedule something continuous
function schedule(wait,func)
	add(scheduler,{
			func=func,
			ticks=ticks+wait,
			start=ticks,
			evt=nope
	})
end

-- utilzzz

pd = {accum=0,avg=0}
pd_ticks=0
function perf_hud()
pd_ticks+=1
	local cpu = flr(stat(1)*100)
	if pd_ticks%30==0 then
		pd.min = 9999
		pd.max = 0
		pd.avg = flr(pd.accum / 30)
		pd.accum = 0
	end
	pd.accum += cpu
	pd.min = min(cpu,pd.min)
	pd.max = max(cpu,pd.max)
	rectfill(0,0,27,28,0)
	print("avg "..pd.avg,0,0,7)
	print("min "..pd.min,0,8,7)
	print("max "..pd.max,0,16,7)
	print("mem "..flr(stat(0)),0,24,7)
end

-- sqrt fix


sqrt0 = sqrt
function sqrt(n)
  if (n <= 0) return 0
  if (n >= 32761) return 181.0
  return sqrt0(n)
end

-- level data

level_one={
walls={
 {119.45,52.1,119.5,61.5},
 {119.5,61.5,119.55,76.15},
 {8.05,76.1,8.05,61.5},
 {8.05,61.5,8.05,52.05},
 {119.55,76.15,8.05,76.1},
 {8.05,52.05,119.45,52.1},
},
start={
 x=17.45,y=64.2
},
nmes={
},
areas={
 {0,101.85,52.05,17.700000000000003,24.10000000000001},
},
}

level_one_half={
walls={
 {120.75,26,100,26},
 {100,26,100,52.1},
 {36.25,52.1,8.05,52.05},
 {8.05,52.05,8.05,61.5},
 {8.05,61.5,8.05,76.1},
 {8.05,76.1,36.25,76.15},
 {57,52.1,57,26},
 {57,26,36.25,26},
 {36.25,26,36.25,52.1},
 {36.25,103,57,103},
 {100,103,120.75,103},
 {100,52.1,57,52.1},
 {36.25,76.15,36.25,103},
 {57,103,57,76.15},
 {57,76.15,100,76.15},
 {100,76.15,100,103},
 {120.75,103,120.75,26},
},
start={
 x=17.45,y=64.2
},
nmes={
},
areas={
 {0,98.1,16.55,23.950000000000003,24.099999999999998},
},
}

level_two={
walls={
 {116.3,83.55,123,5.85},
 {50.65,43.25,30.9,43.25},
 {30.9,43.25,46.2,77.5},
 {46.2,77.5,50.65,43.25},
 {72.35,43.25,78.8,77.5},
 {2.6,5.85,10.45,83.15},
 {69,124.3,79.3,101.2},
 {53.35,124.3,69,124.3},
 {41.7,101.55,53.35,124.3},
 {90.95,43.25,72.35,43.25},
 {78.8,77.5,90.95,43.25},
 {123,5.85,2.6,5.85},
 {10.45,83.15,41.7,101.55},
 {79.3,101.2,116.3,83.55},
},
start={
 x=61.05,y=115.1
},
nmes={
},
areas={
 {0,50.65,5.85,20.65,37.5},
 {1,46.2,43.35,32.599999999999994,34.15},
},
}

level_three={
walls={
 {108,32,108,48},
 {124,80,108,80},
 {124,64,124,12},
 {44,48,44,28},
 {64,12,64,32},
 {20,64,28,72},
 {20,28,20,64},
 {44,28,20,28},
 {64,104,56,108},
 {56,108,44,108},
 {12,108,12,124},
 {28,108,12,108},
 {96,108,88,104},
 {108,108,96,108},
 {88,104,64,104},
 {124,124,124,80},
 {108,80,108,108},
 {28,72,28,108},
 {44,64,124,64},
 {44,108,44,64},
 {108,48,44,48},
 {64,32,108,32},
 {12,124,124,124},
 {124,12,64,12},
},
start={
 x=73.95,y=22.5
},
nmes={
 {x=37.05,y=37.3},
 {x=17.3,y=115.1},
},
areas={
 {0,108,80,16,16},
},
}

level_four={
walls={
 {116.3,83.55,123,5.85},
 {2.6,5.85,10.45,83.15},
 {41.7,101.55,53.35,124.3},
 {53.35,124.3,69,124.3},
 {69,124.3,79.3,101.2},
 {123,5.85,2.6,5.85},
 {10.45,83.15,41.7,101.55},
 {79.3,101.2,116.3,83.55},
},
start={
 x=61.05,y=115.1
},
nmes={
 {x=34.7,y=59.2},
 {x=90.6,y=60.65},
 {x=60.8,y=49.6},
},
areas={
 {0,2,3,122.95,20.2},
 {1,-12.7,-1.8,32.599999999999994,96.64999999999999},
 {1,107.2,-1.8,32.60000000000001,96.64999999999999},
},
}

level_enemy={
walls={
 {103.7,29.35,103.7,8.3},
 {103.65,38.65,103.7,30.75},
 {103.7,30.75,103.7,29.35},
 {103.65,92.45,119.15,76.85},
 {119.15,76.85,119.15,54.15},
 {119.15,54.15,103.65,38.65},
 {79.65,30.75,79.6,38.95},
 {8.25,8.3,8.25,30.75},
 {64.35,54.15,64.35,76.85},
 {64.35,76.85,79.6,92.1},
 {8.25,30.75,79.65,30.75},
 {79.6,38.95,64.35,54.15},
 {103.7,8.3,8.25,8.3},
 {79.6,92.1,79.6,121.25},
 {79.6,121.25,103.65,121.25},
 {103.65,121.25,103.65,92.45},
},
start={
 x=19.45,y=18.95
},
nmes={
 {x=91.85,y=72.5},
},
areas={
 {0,79.85,104.9,23.950000000000003,24.099999999999994},
},
}

levels = {
level_one,
level_one_half,
level_two,
level_enemy,
level_three,
level_four
}

level_names = {
"you are alone",
"there is no escape",
"there is only death",
"the darkness hungers",
"you cannot stop it",
"one day you will understand",
}

-- hello!!