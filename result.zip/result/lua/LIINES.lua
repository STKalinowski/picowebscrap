-- liines
-- by szczm_/samar
colors={
  {fg=14, bg=8, dk=2},
  {fg=15, bg=9, dk=5},
  {fg=6, bg=12, dk=1},
}

function _init()
  srand()
  music()

  dt=0
  maxcpu={cpu=0}
  
  scenes={
    c64screen, --0
    function(tt) distort(tt, c64screen) end,
    phantomtitle,
    function(tt) distort(tt, phantomtitle) end,
    cubemaybe,
    cubemaybe, --5
    bezier,
    bezier,
    md_font,
    scribble,
    md_font2,  --10
    scribble2,
    voronoi,
    voronoi,
    heightmap,
    heightmap, --15
    smash,
    smash,
    smash,
    smash,
    starwars,  --20
    starwars,
    starwars,
    starwars,
    starwars,
    starwars,  --25
    function(tt) distort(tt, starwars) end,
    credits,
    function(tt) explode(tt, credits) end,
  }
end

-- 60 fps
function _update60()
end

tpb=60

function _draw()
--  cls()

--  parallax=sin(t*4)*5
  parallax=0
  
  local i=stat(24)+1
  local scene=scenes[i]
  
  c=colors[1+i%#colors]
  
  beat=(1-(stat(26)%tpb)/tpb)^2
  
  if scene~=old_scene then
    old_scene=scene
    dt=t()
    srand(i)
    _cls(c.bg)
  end

  local tt=t()-dt
  
  if scene then scene(tt,i)
  else
    _cls()
    color(7)
    pal()
    repeat until false
--    print("time: "..t())
    stop()
  end
  
  if (stat(1) > maxcpu.cpu or t()>maxcpu.t+2) maxcpu={ cpu=stat(1),t=t() }

  if not true then
    camera()
    print("cpu "..flr(maxcpu.cpu*100).."%",2,2,1)
--    print("cpu "..flr(stat(1)*100).."%",2,2,1)
--    print("mem "..flr(stat(0)),2,9,1)
  end
end

function clamp(x,a,b)
  return max(a,min(b,x))
end

-- thanks amd
function smoothstep(a,b,t)
  local x=clamp((t-a) / (b-a), 0, 1)
  return x*x*(3-2*x)
end

_str="abcdefghijklmnopqrstuvwxyz/647*'&-!19+.:"
_ker={
  ["i"]=3,
  [" "]=4,
  ["/"]=6,
  ["'"]=3,
  ["!"]=3,
  ["1"]=5,
  ["."]=3,
  [":"]=3,
}
_stc={}
for i=1,#_str do
  _stc[sub(_str,i,i)]=i-1
end

function font(str,x,y,col,alpha,aflip)
  local _w,_g=7,6
  if (flr(x)%2==0) _w,_g=_g,_w
  if (aflip) _w,_g=_g,_w

  pal(_w,col)
  
  if alpha then
    palt(_g,true)
  else
    pal(_g,col)
  end
  
  for i=1,#str do
    local c=sub(str,i,i)
    local ind=_stc[c]
        
    if ind then
      local s=5+ind%11+flr(ind/11)*16
      spr(s,x,y)
    end
    
    local ker=_ker[c]
    
    x+=(ker and ker or 9)
  end
    
  pal()
  
  return x
end
-->8
function c64screen(t)
  _cls(13)
  rectfill(8,8,119,119,1)
  print("**** pico-8 lua v5.2 ****",14,12,13)
  print("32k+2mb ram system",29,22,13)
  print((8192-6039).." tokens left",33,30,13)
  print("ready.",9,40,13)
  
  rectfill(8,46,12,51,(t%.6<.3) and 13 or 1)
end

function distort(t, func)
--  local __cls=cls
--  cls=_cls
  
  func(t+rnd(5))
  
  g=t

  for i=1,rnd(g)^2*10 do
    memcpy(0x6000,0x4000+rnd(0x4000),8192)
  end
  
--  cls,_cls=__cls,cls
end

_cls=cls

--[[
function cls(col)
  clsf=clsf or 0
  clsf=(clsf+1)%2
  local cc=col*16+col
  
  for i=clsf,127,2 do
    memset(0x6000+i*0x40,cc,0x40)
  end
end
]]--

function flex(count)
  camera()

  for i=1,rnd(count or 20) do
--    circ(rnd(128),rnd(128),(rnd()^2)*2,7)
  end
end

function reflex(count)
--  camera()

  for i=1,rnd(count or 20) do
--    pset(rnd(128),rnd(128),c.dk)
  end
end

function phantomtitle(t)
  c=colors[flr(1+t*9%#colors)]
  
  if not col3d then
    col3d=0
  end
  
  _cls(c.bg)
  
  reflex()
  
  camera(parallax,0)
  
  for i=1,30 do
    y=-t*50+i*10+100
    yy=(y-64)*1.3+64

    fillp(0x55555555+.5)
    line(8,y,120,y,c.fg)
    
    fillp(0x33333333+.5)
    line(-4,yy,8,y,c.fg)
    line(120,y,132,yy,c.fg)
  end
  
  fillp()
  
  camera(parallax/4,0)
    
  for i=0,4 do
    pal(7,c.fg)
    sspr(i*8,0,8,32,16+i*20,30+t*3/2+1,16,64)
--    pal()
    pal(7,0)
    sspr(i*8,0,8,32,16+i*20,30,16,64)
  end
  
  pal()
  
  flex()
end

function bezier(t)
--  c=colors[1]

  cls(c.bg)

  for i=0,15 do
    y=-(t*50)%16+i*16

    fillp(-0x8421-.5)
    line(0,y,128,y,c.fg)
  end

  
  reflex(50)
  
  camera(-64+parallax,-64)
  
  if not bp then
    srand(6)
    bp={}
    bp_count=40

    for i=1,bp_count do
      local x,y,z=rnd(160)-80,rnd(160)-80,rnd(160)-80
        
      bp[i]={
        x=x,
        y=y,
        z=z
      }
    end
  end
    
  local count=bp_count-1
  local start=bp_count+1
  
  -- tutaj eksploduje  
  local tt=.1+t/8
  
  local st,ct=sin(t/4),cos(t/4)
  
  while count>0 do
    local limit=start+count-1
    local r=1+4*(1-count/40)
    
    for i=start,limit do
      local p1,p2=bp[i-count-1],bp[i-count]
      
      bp[i]={
        x=p1.x*(1-tt)+p2.x*tt,
        y=p1.y*(1-tt)+p2.y*tt,
        z=p1.z*(1-tt)+p2.z*tt
      }
      
      local x,y,z=bp[i].x,bp[i].y,bp[i].z
      x=x*ct-z*st
      x*=(1+beat*.166)
      y*=(1+beat*.166)
      
      if count%2==0 then
--        circfill(x,y,4-abs(x+y)/16,7)
        circfill(x,y,r,7)
              
        if i~=start then
          local t,u,v=bp[i-1].x,bp[i-1].y,bp[i-1].z
          t=t*ct-v*st
        
  			     fillp(0x5a5a+.5)
          line(x,y,t,u,c.fg)
          fillp()
        end
      end
    end
    
    start+=count
    count-=1
  end
  
  flex()
end

function cubemaybe(t)
--  c=colors[2]

  cls(c.bg)
  
  for i=0,15 do
    y=-(t*50)%16+i*16

    fillp(-0x1248-.5)
    line(0,y,128,y,c.fg)
  end
  
  reflex(50)
  
  camera(-64+parallax,-64)
  
  local step=.02
  local size=45
  
  local t1=smoothstep(1,1.9,t)
  local t2=smoothstep(2.8,3.7,t)
  local t3=smoothstep(4.6,5.5,t)
  local t4=smoothstep(6.4,7.3,t)
  
  size+=(t2-t3)*10
  size+=beat*6
  
  local cs=cos(0.12)
  local cflip
   
  for i=-.4,.4,.1 do
    dy=(t1-t4)*i*(2+(t2-t3)*.55)*cs*size*1.1
    ds=size*cos(i*(t2-t3)/2)
    ds2=size*cos((i-step)*(t2-t3)/2)
    local cs2=ds2*cs
    local cs=ds*cs
    cflip=not cflip
    local col=(cflip and 7 or c.fg)
    fillp(cflip and 0 or 0x5555+.5)
    
    for j=0,1,step do
      x,y=cos(j),sin(j)
      u,v=cos(j+step),sin(j+step)
      
      if t3>0 then
        
        local skim=0.15*t3+sin(t)*.1*(t3-t4)
        local c=(t3-t4)*((t*i*.1))%1+t
        x+=sin(j*3-c)*skim
        y+=cos(j*3-c)*skim
        u+=sin((j+step)*3-c)*skim
        v+=cos((j+step)*3-c)*skim
      end
      
      y+=cos(x+t*2-j+i*(t1-t4))*.03
      v+=cos(u+t*2-j+step+i*(t1-t4))*.03
      
--      fillp((dflip%8<1 and 0x5a5a or 0x0)+.5)
      line(x*ds,y*cs+dy,u*ds,v*cs+dy,col)
    end
  end
  
--  dflip+=1

  fillp()
  flex()
end

function heightmap(t)
--  c=colors[3]
  
  if not hmap then
    hmap={}
    size=16
    s=6
    h=size*s/2
    
    for y=1,size do
      hmap[y]={}
      
      for x=1,size do
        hmap[y][x]=rnd()
      end
    end
  end

  _cls(c.bg)
  
  for i=0,15 do
    y=-(t*50)%16+i*16

    fillp(-0xf000-.5)
    line(y,0,y,128,c.fg)
  end
  fillp()
  
  reflex(50)
  
  local t1=smoothstep(2,3,t)
  local t2=smoothstep(4,5,t)
  local t3=smoothstep(6,7,t)
  local t4=cos(max(t-5))
  
  camera(-64+parallax,-64)
--  camera(4,4)

--  local s=s*(1+t3)
  local size2=size/2
  
  local h=h
  
  local height=7*t1+t3*20+10*beat
  local cx=cos(.1)
  local sx=sin(.1)
  
  local cy=cos(t/12)
  local sy=sin(t/12)

  for j=1,size do
    for i=1,size do
      local ii,jj=i-.5,j-.5
      local x,z=ii,jj
      local y=sin(hmap[i][j]+t)
      
      local r=cos(abs(ii/size+jj/size)+t)
      local xx,yy=(ii-size2)*sin(ii/size)+size2,ii*cos(t4*((ii+1)/size-.5))

      y=y*(1-t2)+r*t2
--      y=y*(1-t3)+yy*t3
      y*=height
      
      x=x*(1-t3)+xx*t3
      x,z=x*s-h,z*s-h

      
      x,z=x*cy-z*sy,x*sy+z*cy
      z,y=z*cx-y*sx,z*sx+y*cx
--      x*=1+z/128
--      z*=1+z/128
      
      if i<size then
        local ii=ii+1
        local u,w=ii,jj
        local v=sin(hmap[i+1][j]+t)
              
        r=cos(abs(ii/size+jj/size)+t)
        local xx,yy=(ii-size2)*sin(ii/size)+size2,ii*cos(t4*((ii+1)/size-.5))
        
        v=v*(1-t2)+r*t2
--        v=v*(1-t3)+yy*t3
        v*=height

        u=u*(1-t3)+xx*t3
        u,w=u*s-h,w*s-h
      
        u,w=u*cy-w*sy,u*sy+w*cy
        w,v=w*cx-v*sx,w*sx+v*cx
--        u*=1+w/128
--        w*=1+w/128
      
        line(x,z,u,w,7)
      end
      
      if j<size then
        local jj=jj+1
        local u,w=ii,jj
        local v=sin(hmap[i][j+1]+t)
        
        r=cos(abs(ii/size+jj/size)+t)
        local xx,yy=(ii-size2)*sin(ii/size)+size2,ii*cos(t4*((ii+1)/size-.5))
      
        v=v*(1-t2)+r*t2
--        v=v*(1-t3)+yy*t3
        v*=height

        u=u*(1-t3)+xx*t3
        u,w=u*s-h,w*s-h

        u,w=u*cy-w*sy,u*sy+w*cy
        w,v=w*cx-v*sx,w*sx+v*cx
--        u*=1+w/128
--        w*=1+w/128
        
        line(x,z,u,w,7)
      end
    end
  end
  
  flex()
end

function assign_circumcircle(t, assign_r)
  -- https://gist.github.com/mutoo/5617691
  local a,b,c=voro[t.a],voro[t.b],voro[t.c]

  local bax=b.x-a.x--a
  local bay=b.y-a.y--b
  local cax=c.x-a.x--c
  local cay=c.y-a.y--d
  local e=bax*(a.x+b.x)+bay*(a.y+b.y)
  local f=cax*(a.x+c.x)+cay*(a.y+c.y)
  local g=2*(bax*(c.y-b.y)-bay*(c.x-b.x))
     
  local minx,miny,dx,dy

--[[  if abs(g) < 0.001 then
    minx=min(a.x,min(b.x,c.x))
    miny=min(a.y,min(b.y,c.y))
    dx=(max(a.x,max(b.x,c.x))-minx)*0.5
    dy=(max(a.y,max(b.y,c.y))-miny)*0.5
    t.dx=minx+dx
    t.dy=miny+dy
    if (assign_r) t.dr=dx*dx+dy*dy
  else]]--
    t.dx=(cay*e-bay*f)/g
    t.dy=(bax*f-cax*e)/g
    
    if assign_r then
      dx=t.dx-a.x
      dy=t.dy-a.y
      t.dr=dx*dx+dy*dy
    end
--  end
end

function voronoi(t)
--  c=colors[1]
  
  if not voro then
    srand(10)
    
    voro={}
    size=16
    speed=.1/60
    
    for i=1,size do      
      local x,y=rnd(2)-1,rnd(2)-1
    
      voro[i]={
        x=sgn(x)*x^2,
        y=sgn(y)*y^2,
 							u=rnd(2)-1,
 							v=rnd(2)-1
      }
    end
    
    voro[1].x=-.1
    voro[1].y=0
    voro[2].x= .1
    voro[2].y=0
    
    voro[-2]={ x=-4, y=-4 }
    voro[-1]={ x= 6, y=-4 }
    voro[ 0]={ x=-4, y= 6 }
  end
  
  local voro=voro

  local tt=max(t-3)
    
  local voroc=min(#voro,2+#voro*(tt/3)^3)
    
  _cls(c.bg)


  for i=0,15 do
    y=-(t*50)%16+i*16

    fillp(-0x1111-.5)
    line(0,y,128,y,c.fg)
  end
  fillp()
  
  camera(-64+parallax,-64)  
  

  local ss=32 
  local s=40+10*beat
  
  color(7)
    
  for i=1,voroc do
    local v=voro[i]
        
    v.x=v.x+v.u*speed
    v.y=v.y+v.v*speed
    
    if (abs(v.x)>1) v.x=min(1,max(0,v.x)) v.u*=-1
    if (abs(v.y)>1) v.y=min(1,max(0,v.y)) v.v*=-1
    
    pset(v.x*ss,v.y*ss)
  end
  
  
    local tris={
      { a=-2, b=-1, c=0 },
    }

    for i=1,voroc do
      local tr={}
      local v=voro[i]

      for j=1,#tris do
        local t=tris[j]
        
        if not t.dr then
          assign_circumcircle(t, true)
        end

        if (t.dx-v.x)*(t.dx-v.x)+(t.dy-v.y)*(t.dy-v.y) < t.dr then
          add(tr,t)
        end
      end
      
      edg={}
      
      for j=1,#tr do
        local t=tr[j]
        del(tris,t)
        
        local a,b
                
        a,b=t.a,t.b
        if (b<a) a,b=b,a
        edg[a]=(edg[a] or {})
        edg[a][b]=(edg[a][b] or 0)+1
        
        a,b=b,t.c
        if (b<a) a,b=b,a
        edg[a]=(edg[a] or {})
        edg[a][b]=(edg[a][b] or 0)+1
        
        a,b=b,t.a
        if (b<a) a,b=b,a
        edg[a]=(edg[a] or {})
        edg[a][b]=(edg[a][b] or 0)+1
      end

      for a,_ in pairs(edg) do
        for b,_ in pairs(_) do
          if _==1 then
            add(tris, {
              a=a,
              b=b,
              c=i
            })
          end
        end
      end
    end

--[[    
    for t in all(tris) do
      if (t.a<1 or t.b<1 or t.c<1) del(tris,t)
    end
]]--
      
  rect(-s,-s,s,s,c.fg)
  fillp(0x5a5a+.5)
  rect(-s-3,-s-3,s+3,s+3,7)
  fillp()
    
  for t in all(tris) do

    if not t.dr then
      assign_circumcircle(t,false)
    end
        
--[[
    local cc=c
    local a,b,c=voro[t.a],voro[t.b],voro[t.c]

   fillp(0x5a5a+.5)
    line(a.x*s,a.y*s,b.x*s,b.y*s,cc.fg)
    line(b.x*s,b.y*s,c.x*s,c.y*s,cc.fg)
    line(c.x*s,c.y*s,a.x*s,a.y*s,cc.fg)
   fillp()
]]--

  end
  
  clip(64-s,64-s,s*2,s*2)
  
  color(c.fg)
  
  for i=1,#tris-1 do
    local t1=tris[i]
    local a={t1.a,t1.b,t1.c}
        
    for j=i+1,#tris do
      local t2=tris[j]
      
      local b={t2.a,t2.b,t2.c}
      local d={}
      
      for k=1,3 do
        for l=1,3 do
          if (a[k]==b[l]) add(d,a[k])
        end
      end
      
      if #d==2 then
        local a,b=voro[c[1]],voro[c[2]]
        
        line(
          flr(t1.dx*ss),
          flr(t1.dy*ss),
          flr(t2.dx*ss),
          flr(t2.dy*ss)
        )
      end
    end
  end  
  
  clip()
--  rect(-s,-s,s,s,7)

  flex()
end

rocket={
{ x=106.26, y=232.82 },
{ x=105.35, y=232.26 },
{ x=87.36, y=201.18 },
{ x=115.08, y=169.75 },
{ x=115.08, y=169.75 },
{ x=115.29, y=169.47 },
{ x=115.57, y=168.98 },
{ x=115.78, y=168.98 },
{ x=115.78, y=168.98 },
{ x=115.99, y=168.98 },
{ x=116.27, y=169.47 },
{ x=116.48, y=169.75 },
{ x=116.48, y=169.75 },
{ x=144.06, y=201.11 },
{ x=126.98, y=232.05 },
{ x=126.7, y=232.68 },
{ x=126.7, y=232.68 },
{ x=126.56, y=233.1 },
{ x=107.87, y=233.8 },
{ x=106.26, y=232.82 },
{ x=132.3, y=212.03 },
{ x=133.14, y=208.53 },
{ x=147.28, y=229.11 },
{ x=145.53, y=247.17 },
{ x=145.53, y=247.17 },
{ x=144.83, y=237.37 },
{ x=126.56, y=231.91 },
{ x=128.52, y=229.11 },
{ x=128.52, y=229.11 },
{ x=129.99, y=226.87 },
{ x=131.46, y=215.39 },
{ x=132.3, y=212.03 },
{ x=100.03, y=212.03 },
{ x=99.19, y=208.53 },
{ x=85.05, y=229.11 },
{ x=86.8, y=247.17 },
{ x=86.8, y=247.17 },
{ x=87.5, y=237.37 },
{ x=105.77, y=231.91 },
{ x=103.81, y=229.11 },
{ x=103.81, y=229.11 },
{ x=102.34, y=226.87 },
{ x=100.87, y=215.39 },
{ x=100.03, y=212.03 },
{ x=106.61, y=181.72 },
{ x=111.23, y=183.75 },
{ x=121.73, y=183.68 },
{ x=125.44, y=181.72 },
{ x=125.86, y=235.06 },
{ x=125.16, y=238.63 },
{ x=121.45, y=238.49 },
{ x=115.99, y=238.49 },
{ x=115.99, y=238.49 },
{ x=110.53, y=238.49 },
{ x=105.77, y=238.63 },
{ x=106.12, y=235.06 },
{ x=106.12, y=235.06 },
{ x=106.4, y=232.19 },
{ x=110.95, y=233.8 },
{ x=115.99, y=233.45 },
{ x=115.99, y=233.45 },
{ x=122.15, y=232.96 },
{ x=126.49, y=231.98 },
{ x=125.86, y=235.06 },
}

alien={
{ x=30.754, y=2.715 },
{ x=59.804, y=1.875 },
{ x=83.954, y=41.985 },
{ x=32.994, y=79.015 },
{ x=32.994, y=79.015 },
{ x=-5.716, y=56.895 },
{ x=-7.116, y=7.195 },
{ x=30.754, y=2.715 },
{ x=8.914, y=33.935 },
{ x=18.294, y=33.375 },
{ x=25.574, y=36.245 },
{ x=29.564, y=44.155 },
{ x=29.564, y=44.155 },
{ x=19.134, y=51.295 },
{ x=12.204, y=48.005 },
{ x=8.914, y=33.935 },
{ x=56.654, y=33.935 },
{ x=47.274, y=33.375 },
{ x=39.994, y=36.245 },
{ x=36.004, y=44.155 },
{ x=36.004, y=44.155 },
{ x=46.364, y=51.295 },
{ x=53.294, y=48.005 },
{ x=56.654, y=33.935 },
{ x=26.274, y=62.985 },
{ x=30.404, y=66.835 },
{ x=34.674, y=67.045 },
{ x=39.154, y=62.985 },
}

function scribble2(t)
--  c=colors[2]
  
  local a=alien
  
  if not bez_scr then
    bez_scr={}
    
    aa=4
    ai=#a/aa
    seg=0.05
    
    mod_xy=function(x,y,p)
      local fp=p.p+p.j
      local t1=1-2*smoothstep(2.2,2.7,p.t)^2
      local t2=smoothstep(-0.3,.7,p.t-fp*.1)

      x*=1.3
      y*=1.3
     
      if p.p>=2 and p.p<=5 then
        local tt=smoothstep(0,.9,sin(clamp(p.t*2,3,4)))
        y-=55
        y+=9*sin(y/50)*tt
        y+=55
      end

      if p.p==6 then
        y-=80
        y*=sin((x-27)/64)*t1
        y+=t1*5
        y+=80
      end
      
      local x6,y6=x/128+y/128,y/128
      
      x+=sin(x6-p.j*.2+p.t)*(.5*beat*6)
      y+=sin(y6+p.t)*1.5
      
      local dx,dy=44-cos(fp/5)*128,54-sin(fp/5)*128
--      dx+=sin(x6+p.t)*20
--      dy+=sin(y6+p.t)*20
      
      x=dx*(1-t2)+x*t2
      y=dy*(1-t2)+y*t2
      
      return x,y
    end
  end
  
  local b=bez_scr

  cc=cc or 0
  cc=(cc+1)%5
  
  cls(0)
  reflex()
  
  camera(-20,-10)
  

  for k=0,ai-1 do
    for i=1,aa do
      b[i]=a[k*4+i]
    end
    
    if k<2 then
      color(9+cc)

--      fillp(0xf0f0+.5)
    else
      color(7)
      fillp()
    end    
    
    local x,y=b[1].x,b[1].y
    x,y=mod_xy(x,y,{j=0,t=t,p=k})
    line(x,y,x,y)
    
    for j=0,1,seg do
      local cnt=aa-1
      local sta=aa+1
  
      while cnt>0 do
        for i=sta,sta+cnt-1 do
          
          local p1,p2=b[i-cnt-1],b[i-cnt]

          b[i]=(b[i] or {}) 
           
          b[i].x=p1.x*(1-j)+p2.x*j
          b[i].y=p1.y*(1-j)+p2.y*j
        end    
        sta+=cnt
        cnt-=1
      end
   
      local x,y=b[#b].x,b[#b].y      
      x,y=mod_xy(x,y,{j=j,t=t,p=k})
      line(x,y)
    end
  end
  
  flex()
end

function scribble(t)
--  c=colors[2]
  
  local a=rocket
  
  if not bez_scr2 then
    bez_scr2={}
    
    aa=4
    ai=#a/aa
    seg=0.1
    
    mod_xy=function(x,y,p)
      local fp=p.p+p.j
      local t1=1-2*smoothstep(2.2,2.7,p.t)^2
      local t2=smoothstep(-0.3,.7,p.t-fp*.1)

      x*=1.3
      y*=1.3

--[[     
      if p.p>=2 and p.p<=5 then
        local tt=smoothstep(0,.9,sin(clamp(p.t*2,3,4)))
        y-=55
        y+=9*sin(y/50)*tt
        y+=55
      end
]]--

--[[
      if p.p==6 then
        y-=80
        y*=sin((x-27)/64)*t1
        y+=t1*5
        y+=80
      end
]]--
      
      local x6,y6=x/128+y/128,y/128
      
      x+=sin(x6-p.j+p.t)/2
      y+=sin(y6+p.t)*(1.5+beat*4)
      
      local dx,dy=124-cos(fp/5)*128,264-sin(fp/5)*128
--      dx+=sin(x6+p.t)*20
--      dy+=sin(y6+p.t)*20
      
      x=dx*(1-t2)+x*t2
      y=dy*(1-t2)+y*t2
      
      return x,y
    end
  end
  
  local b=bez_scr2
  local t=t

  cls(c.bg)
  reflex()
  
  camera(86,210)
  

  for k=0,ai-1 do
    for i=1,aa do
      b[i]=a[k*4+i]
    end
    
    if k>=12 and k<=13 then
      color(c.fg)
      fillp(0x5a5a+.5)
    else
      color(7)
      fillp()
    end    
    
    local x,y=b[1].x,b[1].y
    x,y=mod_xy(x,y,{j=0,t=t,p=k})
    line(x,y,x,y)
    
    for j=0,1,seg do
      local cnt=aa-1
      local sta=aa+1
  
      while cnt>0 do
        for i=sta,sta+cnt-1 do
          
          local p1,p2=b[i-cnt-1],b[i-cnt]

          b[i]=(b[i] or {}) 
           
          b[i].x=p1.x*(1-j)+p2.x*j
          b[i].y=p1.y*(1-j)+p2.y*j
        end    
        sta+=cnt
        cnt-=1
      end
   
      local x,y=b[#b].x,b[#b].y      
      x,y=mod_xy(x,y,{j=j,t=t,p=k})
      line(x,y)
    end
  end
  
  flex()
end


function md_font(t)
--  c=colors[3]
  c=colors[flr(1+t*9%#colors)]
  
  _cls(c.bg)
  camera()
  reflex()
  
  local t=t+beat*.1

  for y=1,13 do  
    local x
    
    if y%2==1 then
      x=0-t*80
    else
      x=-700+t*80
    end
    
    local alp=flr(y)%2==0
    local col=alp and c.fg or 7
    local y=9*y-3

    for i=1,7 do
      x=font("moonshine dragons ",x,y,col,alp)
    end
  end
  
--  flex()
end

function md_font2(t)
--  c=colors[3]
  c=colors[flr(1+t*9%#colors)]
  
  _cls(c.bg)
  camera()
  reflex()
  
  local t=t+beat*.1

  for y=1,13 do  
    local x
    
    if y%2==0 then
      x=0-t*80
    else
      x=-700+t*80
    end
    
    local alp=flr(y)%2==0
    local col=alp and c.fg or 7
    local y=9*y-3

    for i=1,7 do
      x=font("moonshine people ",x,y,col,alp)
    end
  end
  
--  flex()
end

function smash(t)
  if not smash_pt then
    smash_pt={}

    local _x1,_y1=0,32
    local _x2,_y2=73,87
    local _w=flr((_x2-_x1)/2)
    local _h=flr((_y2-_y1)/2)
    for y=_y1,_y2 do
      for x=_x1,_x2 do
        local c=sget(x,y)
        if (c>0) add(smash_pt,{x=x-_x1-_w,y=y-_y1-_h,u=0,v=0})
      end
    end

    _cls()
    font("samar",0,0,7)
    
    smash_pt2={}

    local _x1,_y1=0,0
    local _x2,_y2=5*9,8
    local _w=flr((_x2-_x1)/2)
    local _h=flr((_y2-_y1)/2)
    for y=_y1,_y2 do
      for x=_x1,_x2 do
        local c=pget(x,y)
        if (c>0) add(smash_pt2,{x=x-_x1-_w,y=y-_y1-_h+24,u=0,v=0})
      end
    end
    
    local _x1,_y1=76,32
    local _x2,_y2=127,77
    local _w=flr((_x2-_x1)/2)
    local _h=flr((_y2-_y1)/2)
    for y=_y1,_y2 do
      for x=_x1,_x2 do
        local c=sget(x,y)
        if (c>0) add(smash_pt2,{x=x-_x1-_w,y=y-_y1-_h-8,u=0,v=0})
      end
    end
  end
  
  local smash_pt=smash_pt
  local smash_pt2=smash_pt2
  
  cls(c.bg)
  
  reflex()
    
  camera(-64,-64)
  
  local tt=t-beat*.15
  
  local t1=smoothstep(1,1,tt)
  local t2=smoothstep(3,4,tt)
  local t3=smoothstep(5,6,tt)
  local t4=smoothstep(7,8,tt)
  
  local t5=smoothstep(8.5,10.5,tt)
  local t6=smoothstep(10.5,12.5,tt)
  local t7=smoothstep(12.5,14.5,tt)
  
  local t8=smoothstep(14.5,15.5,tt)
  
--  local col=(t5>0 and c.dk or 7)
  local col=7
  
  local spt=#smash_pt
  spt-=(t4+t8)*spt/2
  
  for i=1,spt do
    local p=smash_pt[i]
    local di=i/spt
    
    if (t1-t2)>0 then
      p.v+=6/60
    elseif t3>0 then
      p.u+=rnd(.5)-.25
      p.v+=rnd(.5)-.25
    end
    
    if t2>0 and t3==0 then
      local tt2=max(t2-di+.5)
      if (tt2>.45) tt2=1
      
      local p2=smash_pt2[1+i%#smash_pt2]
      p.x=p.x*(1-tt2)+p2.x*tt2
      p.y=p.y*(1-tt2)+p2.y*tt2
      p.u=0
      p.v=0
    elseif t4>0 then
      local tt4=max(t4-di+.5)
      if (tt4>.5) tt4=1
      
      local x2=cos(tt/2+di)*52
      local y2=sin(tt/2+di)*52
      p.x=p.x*(1-tt4)+x2*tt4
      p.y=p.y*(1-tt4)+y2*tt4
    end
    
    p.x+=p.u*(1-beat)
    p.y+=p.v*(1-beat)
    
    if (t1-t2)>0 and p.y>63 then
      p.y=63
      
      p.v*=-(0.2+(0.5*rnd()))
      p.u=rnd(abs(p.v))-abs(p.v)/2
      if (abs(p.v)<.05) p.v=0 p.u=0
    end
    
    pset(p.x,p.y,col)
  end
  
  if flr(t5)~=t5 then
    font("aarhus",-25,-16,7)
    font("alcatraz",-32,-3,7)
    font("conspiracy",-40,10,7)
  elseif flr(t6)~=t6 then
    font("elysium",-20,10,7)
    font("fairlight",-40,-3,7)
    font("jumalauta",-40,-16,7)
  elseif flr(t7)~=t7 then
    font("logicoma",-26,-16,7)
    font("shine/xplsv",-44,-3,7)
    font("still",-17,10,7)
  end

  flex()
end

gratki={
"aberration creations",
"abnormal",
"abyss connection",
"active",
"afrika",
"agenda",
"agony",
"albion",
"algotech",
"almagest",
"alpha flight",
"altair",
"arise",
"arsenic",
"artline designs",
"artstate",
"ate bit",
"atlantis",
"asphyxia",
"avatar",
"bauknecht",
"black sun",
"blazon",
"bliss",
"blues muz'",
"bonzai",
"booze design",
"boz desing",
"c64 club berlin",
"camelot",
"cascade",
"christopherjam",
"censor design",
"charged",
"chorus",
"chromance",
"code 7",
"cosine",
"covert bitops",
"crest",
"danish gold",
"dark lords of chaos",
"datadoor",
"darklite",
"defame",
"dual crew",
"dekadence",
"delta machine",
"delysid",
"desire",
"dienstagstreff",
"digital excess",
"dinasours",
"dmagic",
"draco",
"dream",
"dreamweb",
"elude",
"excess",
"exclusive on",
"extend",
"f*a*i*c",
"faith",
"fatum",
"f4cg",
"finnish gold",
"floppy",
"focus",
"forces of evil",
"fossil",
"fraction",
"funkentstort",
"genesis project",
"glance",
"hack n' trade",
"hitmen",
"hoaxers",
"hokuto force",
"horizon",
"house designs",
"hvsc crew",
"inflexion",
"k&a plus",
"kryo",
"laxity",
"lemonspawn",
"lepsi de",
"lethargy",
"level 64",
"light",
"loonies",
"maniacs of noise",
"masters' design group",
"mayday!",
"megastyle",
"mcm designs",
"motiv 8",
"multistyle labs",
"nah-kolor",
"nan design",
"no name",
"noop",
"noice",
"nostalgia",
"offence",
"omg",
"onslaught",
"oxyron",
"padua",
"panda design",
"panoramic designs",
"people of liberty",
"performers",
"plush",
"pond",
"poo-brain",
"presence",
"profik",
"prosonix",
"priorart",
"protovision",
"psytronik",
"pvm",
"quadtrip",
"quartet",
"rabenauge",
"radwar",
"razor 1911",
"rasterdream",
"react",
"red sector incorporated",
"resource",
"role",
"really proud lamers",
"shape",
"sidrip alliance",
"siesta",
"singular crew",
"style",
"success+the ruling company",
"taboo",
"tempest",
"the dreams",
"the judges",
"the new dimension",
"the solution",
"triad",
"tristar & red sector inc.",
"tropyx",
"underground domain inc.",
"vibrants",
"victory",
"viruz",
"vision",
"vulture design",
"w.f.m.h.",
"warriors of the wasteland",
"wrath designs",
"x-ample architectures",
"xenon",
"xentax",
}

function starwars(t)
--  c=colors[flr(1+t*9%#colors)]
  
  _cls(c.bg)
  tpb=30
  
  reflex()
  
  camera(parallax,0)
  
  for i=1,80 do
    y=-t*40+i*10+128
    yy=(y-64)*1.3+64+8*beat

    fillp(0x55555555+.5)
    line(8,y,120,y,c.fg)
    
    fillp(0x33333333+.5)
    line(-4,yy,8,y,c.fg)
    line(120,y,132,yy,c.fg)
  end
  
  camera()
  fillp()  
  for i=1,#gratki do
    local w=#gratki[i]*2
    local yy=110+9*i-65*t
    
    if clamp(yy,-20,150)==yy then
    
      rectfill(64-w-2,yy-2,64+w,yy+6,c.bg)
      
      for y=-1,1 do for x=-1,1 do
        print(gratki[i],64-w+x,yy+y,c.fg)
      end end
    
      print(gratki[i],64-w,yy,0)
    end
  end
end

function credits(t)
  cls(0)
  camera()
  
  cc=cc or 0
  cc=(cc+1)%4

  pal(7,9+cc)
  
  for i=0,4 do
    sspr(i*8,0,8,32,16+i*20,24,16,64)
  end
  
  print("code/msx: szczm",28,98,8+cc)
  print("gfx: isildur",48,105,8+cc)

--  font("code: szczm",20,95,9+cc)
--  font("support: isildur",10,105,9+cc)
end

function explode(tt, func)
  if not expt then
    expt={}
    
    cls()
    camera()
    pal()
    fillp()
    srand()
    
    func()
    
    for y=0,127 do for x=0,127 do
      local c=pget(x,y)
      if (c>0) add(expt,{x=x,y=y,u=rnd(4)-2,v=rnd(4)-2})
    end end
  end
  
  cls()
  
  local t=clamp(3.2-tt*4,0,1)^.5*#expt
  
  for i=1,t do
    local p=expt[i]

    p.u*=.98
    p.v*=.98
  
    p.x+=p.u
    p.y+=p.v
    
    pset(p.x,p.y,9+rnd(4))
  end
end