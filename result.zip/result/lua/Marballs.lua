-- marballs
-- by lucatron

--general constants
sw = 24 --main tile sprite width
sh = sw/2 --height
tc = (sqrt(2)*128)/sw + 1 --tile capacity along diagonal, for checking if tiles are onscreen
cntdwn = 25 --countdown length
t = 0 --stage frame, resets on level start
tg = 0 --global frame count

--character/player
c_x = 0 c_y = 0 c_z = 0 --pos (pixel)
c_mx = 0 c_my = 0 --pos (map)
c_vx = 0 c_vy = 0 --velocity
c_vz = 0
c_vmin = 0.01 c_vmax = 3 --max speeds
c_acc = 0.43 c_deacc = 0.92 --acceleration
c_av = 3 --jump speed
c_g = 0.3 --gravity acceleartion
c_aacc = 0.12 c_adeacc = 0.99 --air acceleration

--map
m_x = 0 --x tile of map
m_w = 32 --width/height
m_h = 32
m_tc = {{3,11}, --tile colours
        {13,6}, --for each lvl
        {4,15}} 
m_name = {"rolling", --level names
          "jumping",
          "routing"}
m_hs = {999,999,999} --highscores
m_dhs = {7.89,17.76,16.36} --dev highscore
m_nhs = false --if new highscore
lvls = 3 --number of levels

--g_paused menu
p_c = 0 --cursor
p_xo = 26 --x/y offset
p_yo = 60
p_vo = 12 --vertical offset
p_to = (64-p_yo)/2 --text offset
p_sh = 1 --border width

--sound channels
sd_menu = 0
sd_roll = 0
sd_jump = -1
sd_music = 2 + 4 + 8
sd_songs = {11,1,19} --songs for each level

---boot animation logo
--table turned out to be less
--effecient so was not used here
l_pww = 45 --pinwheel width
--actually quite cpu intensive
--so pww>45 starts getting laggy
l_pws = 180 --pinwheel slowness
l_pwy = 30 --pinwheel y-pos
l_lsm = 2 --logo size multiple
l_ly = 88 --logo y-pos
l_len = 115 --length of animation
l_wait = 30 --length of blackscreen wait

--title constants/variables
t_sm = 3 --title width multiplye
t_xs = 1 --x bg speed
t_ys = 0.2 --y bg sped
t_sy = 0 --sin motion of y
t_w = 42 --drawn board width/2
t_res = 1 --resolution of boar

--transition
tr_go = false --if transitioning
tr_t = 0 --g_timer
tr_l = 32 --length of fade
tr_p = 10 --length of pause
tr_to = -1 --where to fade to
tr_tog = 0 --to game
tr_tos = 1 --to scoreboard
tr_tot = 2 --to menu

--game conditions
g_lvl_end = false --if beaten level
g_lvl_death = false
g_paused = false
lvl = 0 --level number
g_timer = 0 --g_timer
g_flp = false --flipper

game_state = 0 --variables
gs_boot = 0 --booting
gs_title = 1 --main menu
gs_game = 2 --ingame
gs_score = 3 --scorebaord


-----------------
--debug settings
debug = false --turn on/off

if debug then
 l_len = 2
 l_wait = 2
 tr_l = 4
 tr_p = 4
 cntdwn = 4
 for i=0,lvls-1 do
  mset(2+m_w*i,0,17)
 end
end


---------------------
--general functions--

--return sign of n
function sign(n)
 if (n < 0) return -1
 return 1
end

--round float n to d places
function round(n,d)
 return flr(n*10^d)/10^d
end

--print with simple "3d" shadow
function prn(st,x,y,col)
 print(st,x,y+1,5)
 print(st,x,y,col)
end


---------------------
--loading functions--

--change level
function load_level(newlvl)
 game_state = gs_game
 lvl = newlvl
 m_x = m_w*lvl --update map pos
 reset_level()
 music(-1)
 music(sd_songs[lvl+1],tr_l*40,sd_music)
end


function load_title()
 game_state = gs_title
 t = 0
 music(-1)
 music(15,2000)
end

function load_scoreboard()
 game_state = gs_score
 music(-1)
 music(11,tr_l*40)
end

--initialize ball
function init_ball()
 c_x = 0
 c_y = sw/2
 c_z = 0
 c_mx = m_x
 c_my = 0
 c_vx = 0
 c_vy = 0
 c_vz = 0
end

--restart the level
function reset_level()
 if g_lvl_end then
  music(-1)
  music(sd_songs[lvl+1],tr_l*40,sd_music)
 end

 init_ball()
 g_paused  = false
 g_lvl_end = false
 g_lvl_death = false
 g_flp = false
 g_timer = 0
 t = 0
 m_nhs = false
 p_c = 0
end


function _init()
 game_state = gs_boot
end


---------------------
--drawing functions--


--bootup logo
function draw_logo() 
--stick
 sspr(64,8,8,8,56,2+l_pwy,16,50)
 
--make angle
--note polynomial of t, which accelerates it
 a = (t+0.04*t^2)%l_pws/(l_pws-1)
 
--precalculate trig functions
 cosa = cos(a)
 sina = sin(a)
 
--iterate over square
--centered on (0,0)
 for x=-l_pww/2,l_pww/2-1 do
 for y=-l_pww/2,l_pww/2-1 do
  --rotate x,y coords around (0,0)
  x2 = cosa*x - sina*y
  y2 = sina*x + cosa*y
  
  --if in square
  if (abs(x2) <= l_pww/2 and
      abs(y2) <= l_pww/2) then
   --get related pixel colour
   col = sget(x2/l_pww*8  + 68,
              y2/l_pww*8 + 4)
   if col~=0 then
    pset(x+64, y+l_pwy,col)
   end
  end
 end
 end
 
 --the white axle
 circfill(64,l_pwy,3,7)
 
 --company name
 sspr(72,0,32,16,
      64-16*l_lsm,l_ly,
      32*l_lsm,16*l_lsm)
end

--title screen
function draw_title()
 --draw perspective map thing
 --precalculate stuff
 sa = sin(t/120%1) ca = cos(t/120%1) --trig stuff
 p = 0.45 + 0.12*sa --perspective ratio (1=vertical,0=horizontal)
 ip = 1/p --inverse of p
 maxw = t_w*sqrt(2) --max width (that a pixel could be draw)
 maxh = t_w*sqrt(2)*p --max height
 
 for x=-maxw,maxw,t_res do
  for y=-maxh,maxh,t_res do
   --rotate coords around 0,0
   rx = ca*x - sa*y*ip
   ry = sa*x + ca*y*ip
   --if in square
   if abs(rx) <= t_w and
      abs(ry) <= t_w then
    --get realtive tile
    tilx = flr((rx+t_w)/(t_w/16)+m_w)
    tily = flr((ry+t_w)/(t_w/16))
    til = mget(tilx,tily)
    
    --if an actual tile
    if til!=0 then
     --get checkerboard colour
     col = 11
     if ((tilx+tily)%2 == 0) col = 3
     px = x + 64
     py = y + 70
     --top
     rectfill(px,py,
             px+t_res,py+t_res,
             col)
     --shadow
     rectfill(px,py+5,
              px+t_res,py+t_res,
              1)
    end
   end
  end
 end
 
 --title name
 pal()
 sspr(8,24,40,8,
      64-20*t_sm,10,
      40*t_sm,8*t_sm)
 
 --press start text
 prn("press z/x to begin",
       28,110,7)
end


function draw_transition()
 --first half of wipe
 if tr_t < tr_l then
  y = tr_t/(tr_l)*127
  rectfill(0,0,127,y,0)
 --blackscreen pause
 elseif tr_t < tr_l + tr_p then
  rectfill(0,0,127,127,0)
 --second halfe wipe
 else
  y = (tr_t-tr_l-tr_p)/(tr_l)*127
  rectfill(0,y,127,127,0)
 end
end

--ingame background
function draw_bg()
 --circle radius
 rad = 12+8*cos(tg/500%1)
 --distance between each circle
 step = rad*3
 
 --note iteration starts at 64
 --to give centred zoom
 for x=64,127+rad,step do
  for y=64,127+rad,step do
   circfill(x,y,rad,1)
   circfill(128-x,128-y,rad,1)
   circfill(128-x,y,rad,1)
   circfill(x,128-y,rad,1)
  end
 end
end

--draw level tiles
function draw_iso_map()
 --iterate over map tiles
 for y=0,m_h-1 do
 for x=0,m_w-1 do
 
  --if a tile
  --and if onscreen (fast approx)
  if (mget(x+m_x,y) ~= 0 and
      abs(c_mx-x-m_x) < tc and
      abs(c_my-y) < tc) then
   --get isometric coords
   rx = m_w-1 + x - y
   ry = (x + y)/2
   --get pixel coords, which
   --centres map on player
   px = rx*sh - m_h*sh + 64 - c_x
   py = ry*sh + 64 - c_y/2
  
   --get tile type
   til = mget(x+m_x,y)
   pal()
   
   --select tile coluors
   --normal tile
   if (til == 1) then
    col = m_tc[lvl+1][1]
    if ((x+y)%2==0) col = m_tc[lvl+1][2]
    pal(2,col)
    pal(3,col)
   --blue flipper
   elseif (til == 5) then
    pal(2,12)
    pal(3,12)
    if (g_flp) palt(3,true)
   --red flipper
   elseif (til == 21) then
    pal(2,9)
    pal(3,9)
    if (not g_flp) palt(3,true)
   --b/w checker finish
   elseif (til == 17) then
    pal(2,6)
    pal(3,7)
   end
   
   --draw the sprite
   sspr(16,0,sw,sh,px,py)
  end
 end
 end
end


function draw_player()
 --shadow
 pal(1,0)
 --if small or big shadow
 n = 37
 if (c_z>6) n = 36
 spr(n,60,60)
 pal()
 --ball
 spr(32,60,56-c_z)
 --shimmer, some magic numbers
 --here to get a feel
 spr(33 + 0.15*(c_x+0.6*c_y)%3,60,56-c_z)
end

--draw the menu
function draw_g_paused()
 rectfill(p_xo-p_sh,p_yo+p_vo-p_sh,
  128-p_xo+p_sh,128-p_yo+p_vo+p_sh, 0)
 rectfill(p_xo,p_yo+p_vo,
  128-p_xo,128-p_yo+p_vo, 13)
 
 ty = p_yo+p_to+p_vo
 
 if g_lvl_death then
  prn("restart",50,ty,10)
 else
  --option 1
  col = 7
  if (p_c==0) col = 10
  s="resume"
  if (g_lvl_end) s="next lvl"
  prn(s,p_xo+p_to,ty,col)
  
  --option 2
  col = 7
  if (p_c==1) col = 10
  prn("restart",100-p_xo,ty,col)
 end
end

--level timer
function draw_timer()
 sec = g_timer/30
 str = "time: "..flr(sec/60)
     ..":"..round(sec%60,2)
 if m_nhs then
  str = str.."  new best time!"
 end
 --flash on level end
 col = 7
 if g_lvl_end and t%20 < 10 then
  col = 6
 end
 
 prn(str,2,3,col)
end

--starting countdown g_timer
function draw_countdown()
 cd_sm = 2 --size multiplyer
 
 --get y of spr. this is... yeah...
 if (t%cntdwn < cntdwn/3) then
  y = -8*cd_sm+t%cntdwn/cntdwn*50*3
 else 
  y = -8*cd_sm+cntdwn/3%cntdwn/cntdwn*50*3
 end
 
 if t <= cntdwn then --ready?
  sspr(48,16,32,8,
       64-cd_sm*16,y,
       32*cd_sm,8*cd_sm)
 else --go!
  sspr(48,24,16,8,
      64-cd_sm*8,y,
      16*cd_sm,8*cd_sm)
 end
end


function draw_scoreboard()
 prn("congratulations!",32,15,9)
 
 --level times
 for i=0,lvls-1 do
  y = 40+i*12
 
  --level number, coloured like
  --the tile in the level
  prn("lvl "..i+1,4,y,m_tc[i+1][2])
  --level name
  prn("'"..m_name[i+1].."'",32,y,7)
  --level time
  --if you beat my time :)
  col = 6
  if (m_hs[i+1] < m_dhs[i+1]) col = 10
  prn(m_hs[i+1],76,y,col)
 end
 
 prn("press z/x to continue",22,118,7)
end


function _draw()
 --reset
 pal()
 rectfill(0,0,127,127,0)
 
 --main menu
 if game_state == gs_boot then
  if (t<=l_len) draw_logo()
  
 --title screen
 elseif game_state == gs_title then
  draw_title()
  
 --ingame
 elseif game_state == gs_game then
  --bg 
  draw_bg()
 
  --board
  draw_iso_map()
 
  --player
  draw_player()
 
  --in game menu
  if (g_paused) draw_g_paused()
 
  --g_timer
  draw_timer()
  
  --countdown
  if (t<=2*cntdwn) draw_countdown()
 
 --scoreboard
 elseif game_state == gs_score then
  draw_scoreboard()
 end
 
 if (tr_go) draw_transition()
 
 if (debug) print("cpu: "..stat(1),2,10,7)
end


-------------------
--update functions

--update if ingame
function update_game() 
 ------
 --live
 if not g_paused and
    t > cntdwn then

  --update g_timer
  g_timer += 1
  
  -----------------------
  ----inputs for movement 
  ---jump
  if c_z != 0 then
   c_z += c_vz
   c_vz -= c_g
  end
  if btn(4) and c_z==0 then 
   c_vz = c_av
   c_z += c_vz
   sfx(6,sd_jump)
   g_flp = not g_flp
  end
  if (c_z < 0) then
   c_z=0
   sfx(7,sd_jump)
  end
  
  ---cardinal movement
  --get acc for ground or air
  acc = c_acc
  deacc = c_deacc
  if c_z~=0 then 
   acc = c_aacc
   deacc = c_adeacc
  end
  
  --add acc to velocity
  if btn(1) then c_vx += acc
  elseif btn(0) then c_vx -= acc
  else c_vx *= deacc
  end
  if btn(3) then c_vy += acc
  elseif btn(2) then c_vy -= acc
  else c_vy *= deacc
  end
 
  --apply velocity
  if (abs(c_vx) > c_vmax) c_vx = sign(c_vx)*c_vmax
  if (abs(c_vy) > c_vmax) c_vy = sign(c_vy)*c_vmax
  c_x += c_vx
  c_y += c_vy
  
  --play rolling sound effect
  if (c_z==0) then
   vel = abs(c_vx)+abs(c_vy)
   if vel > c_vmax*1.4  then
    sfx(4,sd_roll)
   elseif vel > c_vmax*0.7  then
    sfx(0,sd_roll)
   elseif vel > c_vmax*0.1 then
    sfx(1,sd_roll)
   end
  end
 
--------------
--menu control
 elseif g_paused then
  --move menu cursor
  if (btnp(0)) p_c += 1
  if (btnp(1)) p_c -= 1
  if btnp(0) or btnp(1) and
      not g_lvl_death then
   sfx(10,sd_menu)
  end
  
  p_c = p_c%2
  
  --death menu
  --just reset
  if g_lvl_death then
   p_c = 0
   if btnp(4) then
    reset_level()
   end
  
  --level complete menu
  --next level and reset
  elseif g_lvl_end then
   if btnp(4) and p_c == 0 then
    tr_go = true
    --if beat last level,
    --go to scoreboard
    if lvl == lvls-1 then
     tr_to = tr_tos
    --otherwise go to next lvl
    else
     tr_to = tr_tog
    end
   end
   if btnp(4) and p_c == 1 then
    reset_level()
   end
  
  --user controlled pause menu
  --reseume and reset
  else
   if btnp(4) and p_c == 0 then
    g_paused = false
    sfx(9,sd_menu)
   elseif btnp(4) and p_c == 1 then
    reset_level()
   end
  end
 end
 
 --activate pause
 if btnp(5) and not g_paused and
    t > cntdwn then
  g_paused = true
  p_c = 0
  sfx(8,sd_menu)
 end
 
 ------------------------
 --check tile iteractions
 
 --update isometric pos of ball
 c_mx = flr((c_x + c_y)/sw) + m_x
 c_my = flr((c_y - c_x)/sw)
 
 --current tile type
 til = mget(c_mx,c_my)
 
 --if offmap
 if ((c_mx < m_x or
     c_mx > m_x + m_w - 1 or
     til == 0 or
     (til == 5 and g_flp) or
     (til == 21 and not g_flp)) and
     c_z == 0 and
     not g_paused) then
  g_lvl_death = true
  g_paused = true
  sfx(11,sd_menu)
 
 --if at map finish
 elseif (til == 17 and
         c_z == 0 and
         not g_lvl_end and
         not g_lvl_death) then
  music(-1)
  music(0,0,sd_music)
  c_vy = 0
  c_vx = 0
  c_vz = 0
  g_lvl_end = true
  g_paused = true
  if round(g_timer/30,2) < m_hs[lvl+1] then
   m_hs[lvl+1] = round(g_timer/30,2)
   m_nhs = true
  end
 end
end

function update_transition()
 tr_t += 1
 
 --if at pause point
 if tr_t == tr_l + 1 then
  --transition to game
  if tr_to == tr_tog then
   if game_state == gs_title then
    load_level(0)
   else
    load_level(lvl + 1)
   end
  --transition to scoreboard
  elseif tr_to == tr_tos then
   load_scoreboard()
  --transition to menu
  elseif tr_to == tr_tot then
   load_title()
  end
  
 --if transition has ended
 elseif tr_t == tr_l*2 + tr_p then
  tr_go = false
  tr_t = 0
  tr_to = -1
 end
end


function _update()
 --bootscreen
 if game_state == gs_boot then
  --if logo and wait has ended
  --go to title screen
  if t == l_len + l_wait then
   load_title()
  end
   
 --ttlescreen
 elseif game_state == gs_title then
  if (btn(4) or btn(5))
     and not tr_go then
   music(-1,tr_l*30)
   sfx(9,0)
   tr_go = true
   tr_to = tr_tog
  end
 
 --ingame
 elseif game_state == gs_game and
        not tr_go then
  update_game()
 
 --scoreboard
 elseif game_state == gs_score and
        not tr_go then
  if btnp(4) or btnp(5) then
   tr_go = true
   tr_to = tr_tot
   music(-1,tr_l*30)
   sfx(9,0)
  end
 end
 
 --transiion update
 if (tr_go) update_transition()
 
 --frame counters
 if not tr_go then
  t += 1 --stage frame
  tg += 1 --global frame
 end
end