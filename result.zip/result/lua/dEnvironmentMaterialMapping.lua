
function cosine(a) return cos(a/360) end
function sine(a) return sin(-a/360) end
function cotangent(a) return cosine(a)/sine(a) end

function m4id() return { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 } end

function m4clone(m)
  return { m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15], m[16] }
end

function v3crs(ux, uy, uz, vx, vy, vz)
  return uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx
end

function v3len(vx, vy, vz) return sqrt(vx*vx+vy*vy+vz*vz) end

function v3nrm(x, y, z)
  local len = v3len(x, y, z)
  return x/len, y/len, z/len, len
end

function m4mul(m1, m2)
  return {
    m1[1]*m2[1]+m1[2]*m2[5]+m1[3]*m2[9]+m1[4]*m2[13],
    m1[1]*m2[2]+m1[2]*m2[6]+m1[3]*m2[10]+m1[4]*m2[14],
    m1[1]*m2[3]+m1[2]*m2[7]+m1[3]*m2[11]+m1[4]*m2[15],
    m1[1]*m2[4]+m1[2]*m2[8]+m1[3]*m2[12]+m1[4]*m2[16],
    m1[5]*m2[1]+m1[6]*m2[5]+m1[7]*m2[9]+m1[8]*m2[13],
    m1[5]*m2[2]+m1[6]*m2[6]+m1[7]*m2[10]+m1[8]*m2[14],
    m1[5]*m2[3]+m1[6]*m2[7]+m1[7]*m2[11]+m1[8]*m2[15],
    m1[5]*m2[4]+m1[6]*m2[8]+m1[7]*m2[12]+m1[8]*m2[16],
    m1[9]*m2[1]+m1[10]*m2[5]+m1[11]*m2[9]+m1[12]*m2[13],
    m1[9]*m2[2]+m1[10]*m2[6]+m1[11]*m2[10]+m1[12]*m2[14],
    m1[9]*m2[3]+m1[10]*m2[7]+m1[11]*m2[11]+m1[12]*m2[15],
    m1[9]*m2[4]+m1[10]*m2[8]+m1[11]*m2[12]+m1[12]*m2[16],
    m1[13]*m2[1]+m1[14]*m2[5]+m1[15]*m2[9]+m1[16]*m2[13],
    m1[13]*m2[2]+m1[14]*m2[6]+m1[15]*m2[10]+m1[16]*m2[14],
    m1[13]*m2[3]+m1[14]*m2[7]+m1[15]*m2[11]+m1[16]*m2[15],
    m1[13]*m2[4]+m1[14]*m2[8]+m1[15]*m2[12]+m1[16]*m2[16]
  }
end

function perspective(a, n, f)
  local cot_a = cotangent(0.5*a)
  return { cot_a, 0, 0, 0, 0, cot_a, 0, 0, 0, 0, -(f+n)/(n-f), -(2*f*n)/(n-f), 0, 0, -1, 0 }
end

function translate(tx, ty, tz)
  return { 1, 0, 0, tx, 0, 1, 0, ty, 0, 0, 1, tz, 0, 0, 0, 1 }
end

function rotate_x(a)
  local ca, sa = cosine(a), sine(a)
  return { 1, 0, 0, 0, 0, ca, -sa, 0, 0, sa, ca, 0, 0, 0, 0, 1 }
end

function rotate_y(a)
  local ca, sa = cosine(a), sine(a)
  return { ca, 0, sa, 0, 0, 1, 0, 0, -sa, 0, ca, 0, 0, 0, 0, 1 }
end

function rotate_z(a)
  local ca, sa = cosine(a), sine(a)
  return { ca, -sa, 0, 0, sa, ca, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 }
end

function tex_tri(x1, y1, z1, u1, v1, x2, y2, z2, u2, v2, x3, y3, z3, u3, v3)
  if (y1>y2) x1, y1, z1, u1, v1, x2, y2, z2, u2, v2 = x2, y2, z2, u2, v2, x1, y1, z1, u1, v1
  if (y1>y3) x1, y1, z1, u1, v1, x3, y3, z3, u3, v3 = x3, y3, z3, u3, v3, x1, y1, z1, u1, v1
  if (y2>y3) x2, y2, z2, u2, v2, x3, y3, z3, u3, v3 = x3, y3, z3, u3, v3, x2, y2, z2, u2, v2

  z1, z2, z3 = 1/z1, 1/z2, 1/z3
  u1 *= z1 v1 *= z1
  u2 *= z2 v2 *= z2
  u3 *= z3 v3 *= z3

  local dy1, dy2, dy3 = y2-y1+1, y3-y1+1, y3-y2+1
  local lx, lz, rx, rz, lu, ru, lv, rv,
    dx1, dz1, du1, dv1, dx2, dz2, du2, dv2, dx3, dz3, du3, dv3,
    x1, u1, v1, x2, u2, v2, w, s1, t1, s2, t2 =
    x1, z1, x1, z1, u1, u1, v1, v1,
    (x2-x1)/dy1, (z2-z1)/dy1, (u2-u1)/dy1, (v2-v1)/dy1,
    (x3-x1)/dy2, (z3-z1)/dy2, (u3-u1)/dy2, (v3-v1)/dy2,
    (x3-x2)/dy3, (z3-z2)/dy3, (u3-u2)/dy3, (v3-v2)/dy3

  for y=y1,y2 do
    x1, x2 = flr(lx), flr(rx)
    w, s1, t1, s2, t2 = abs(x2-x1)+1, lu/lz, lv/lz, ru/rz, rv/rz
    tline(x1, y, x2, y, s1, t1, (s2-s1)/w, (t2-t1)/w)
    lx += dx1 lz += dz1 lu += du1 lv += dv1
    rx += dx2 rz += dz2 ru += du2 rv += dv2
  end

  for y=y2+1,y3 do
    x1, x2 = flr(lx), flr(rx)
    w, s1, t1, s2, t2 = abs(x2-x1)+1, lu/lz, lv/lz, ru/rz, rv/rz
    tline(x1, y, x2, y, s1, t1, (s2-s1)/w, (t2-t1)/w)
    lx += dx3 lz += dz3 lu += du3 lv += dv3
    rx += dx2 rz += dz2 ru += du2 rv += dv2
  end

  return y3-y1+1
end

function calc_normals(coords, indices)
  local function calc_nrm(x1, y1, z1, x2, y2, z2, x3, y3, z3)
    -- shift coords because of small triangles in bunny object
    return v3nrm(v3crs(shl(x2-x1, 4), shl(y2-y1, 4), shl(z2-z1, 4),
                       shl(x3-x1, 4), shl(y3-y1, 4), shl(z3-z1, 4)))
  end

  local normals = {}

  for i=1,#coords do normals[i] = { 0, 0, 0, 0 } end

  for _,face in pairs(indices) do
    local i0, i1, i2 = face[1], face[2], face[3]
    local v0, v1, v2 = coords[i0], coords[i1], coords[i2]
    local nx, ny, nz = calc_nrm(v0[1], v0[2], v0[3], v1[1], v1[2], v1[3], v2[1], v2[2], v2[3])
    normals[i0][1] += nx normals[i0][2] += ny normals[i0][3] += nz normals[i0][4] += 1
    normals[i1][1] += nx normals[i1][2] += ny normals[i1][3] += nz normals[i1][4] += 1
    normals[i2][1] += nx normals[i2][2] += ny normals[i2][3] += nz normals[i2][4] += 1
  end

  for i,nrm in pairs(normals) do
    nrm[1], nrm[2], nrm[3] = v3nrm(nrm[1]/nrm[4], nrm[2]/nrm[4], nrm[3]/nrm[4])
  end

  return normals
end

function load_mesh(addr)
  addr = addr or 0
  local read_int = function() -- 12 bits per int
    local val
    if addr-flr(addr) == 0 then val = band(peek2(addr), 0x0fff)
    else val = shr(band(peek2(flr(addr)), 0xfff0), 4) end
    addr += 1.5
    return val
  end

  local read_flt = function() -- 16 bits per float
    local val
    if addr-flr(addr) == 0 then val = shr(peek2(addr), 8)
    else val = shr(shl(band(peek4(flr(addr)), 0x000f.fff0), 12), 8) end
    addr += 2
    return val
  end

  numv, numf = read_int(), read_int()
  coords, indices = {}, {}

  printh('bunny: '..numv..' '..numf)

  for i=1,numv do coords[i] = { read_flt(), read_flt(), read_flt() } end
  for i=1,numf do indices[i] = { read_int(), read_int(), read_int() } end

  return coords, indices
end

function torus(rad1, rad2, stacks, slices)
  rad1, rad2, stacks, slices = rad1 or 1.0, rad2 or 0.5, stacks or 8, slices or 8

  local id1, id2, id3, id4, idx, cuv, suv
  local uv, uoff, voff = 0, 360/stacks, 360/slices
  local circle, coords, indices = {}, {}, {}

  for i=1,slices do
    circle[i] = { 0, rad1+rad2*cosine(uv), rad2*sine(uv) }
    uv += voff
  end

  idx, uv = 1, 0
  for i=1,stacks do
    for j=1,slices do
      cuv, suv = cosine(uv), sine(uv)
      coords[idx] = {
        circle[j][1]*cuv-circle[j][2]*suv,
        circle[j][1]*suv+circle[j][2]*cuv,
        circle[j][3] }
      idx += 1
    end
    uv += uoff
  end

  idx = 1
  for i=0,stacks-1 do
    for j=0,slices-1 do
      id1, id2, id3, id4 =
        i*slices+(j+1)%slices+1,
        i*slices+j+1,
        ((i+1)%stacks)*slices+j+1,
        ((i+1)%stacks)*slices+(j+1)%slices+1
      indices[idx], indices[idx+1] = { id1, id2, id3 }, { id1, id3, id4 }
      idx += 2
    end
  end

  return coords, indices
end

projection = perspective(45, 1.0, 10.0)
verts, indices = load_mesh(5120)
normals = calc_normals(verts, indices)
tverts, uvs = {}, {}

function _init()
  printh(#verts..' '..#indices)

  for k,v in pairs({ [0]=0, 2, 1, 5, 128, 129, 130, 3, 133, 13, 131, 141, 15, 134, 6, 7 }) do pal(k, v, 1) end
  for i=1,#verts do tverts[i], uvs[i] = { 0, 0 }, { 0, 0, 0 } end

  palt(0, false)
end

roty = 0

function _update()
  roty -= 2
end

function _draw()
  cls()

  local queue, halfsz, tris, lines, mv, mvp, nrm, tvtx, tnrm, x, y, z, px, py, pz, pw, nx, ny, nz, vtx1, vtx2, vtx3 =
    {}, 5, 0, 0, m4mul(translate(0, 0, -3.8), rotate_y(roty))
  mvp = m4mul(projection, mv)

  for i,vtx in pairs(verts) do
    nrm, tvtx, uv = normals[i], tverts[i], uvs[i]
    x, y, z = vtx[1], vtx[2], vtx[3]
    px, py, pz, pw = mvp[1]*x+mvp[2]*y+mvp[3]*z+mvp[4],
                     mvp[5]*x+mvp[6]*y+mvp[7]*z+mvp[8],
                     mvp[9]*x+mvp[10]*y+mvp[11]*z+mvp[12],
                     1.0/(mvp[13]*x+mvp[14]*y+mvp[15]*z+mvp[16])
    px *= pw; py *= pw; pz *= pw
    tvtx[1], tvtx[2], tvtx[3] = flr(64*px+64.5), flr(64.5-64*py), pz

    nx, ny, nz = nrm[1], nrm[2], nrm[3]
    uv[1], uv[2] = halfsz+halfsz*(mv[1]*nx+mv[2]*ny+mv[3]*nz),
                   halfsz-halfsz*(mv[5]*nx+mv[6]*ny+mv[7]*nz)
  end

  for _,face in pairs(indices) do
    vtx1, vtx2, vtx3 = tverts[face[1]], tverts[face[2]], tverts[face[3]]
    local x1, y1, z1, x2, y2, z2, x3, y3, z3 =
      vtx1[1], vtx1[2], vtx1[3],
      vtx2[1], vtx2[2], vtx2[3],
      vtx3[1], vtx3[2], vtx3[3]

    if (x2-x1)*(y3-y1)-(y2-y1)*(x3-x1) < 0.0 then
      local uv1, uv2, uv3 = uvs[face[1]], uvs[face[2]], uvs[face[3]]
      tris += 1
      queue[tris] = {
        depth=flr(511.5*(0.333*(z1+z2+z3)+1)),
        draw=function()
          lines += tex_tri(x1, y1, z1, uv1[1], uv1[2], x2, y2, z2, uv2[1], uv2[2], x3, y3, z3, uv3[1], uv3[2])
        end
      }

    end
  end

  local function rsort(data, len, key, digits, base)
    digits = digits or 2
    base = base or 32

    local buffer1, buffer2, idx, count, exp =
      data, {}, {}, {}, 1

    for i=1,digits do
      for i=0,base-1 do count[i] = 0 end

      for i=1,len do
        idx[i] = flr(buffer1[i][key]/exp)%base
        count[idx[i]] += 1
      end

      for i=1,base-1 do count[i] += count[i-1] end

      for i=len,1,-1 do
        buffer2[count[idx[i]]] = buffer1[i]
        count[idx[i]] -= 1
      end

      buffer1, buffer2 = buffer2, buffer1
      exp *= base
    end

    if digits%2 == 1 then
      for i=1,len do data[i] = buffer1[i] end
    end
  end

  rsort(queue, #queue, 'depth')
  for _,prim in pairs(queue) do prim.draw() end

  print('cpu:' .. flr(stat(1)*100+0.5) .. '% ' .. stat(7) .. ' fps ' .. flr(stat(0)+0.5) .. 'kib', 5, 5)
  print('tris:'..tris..' lines:'..lines, 5, 12)
end
