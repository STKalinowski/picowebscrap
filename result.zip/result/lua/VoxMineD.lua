
--srand(3)


vox_map = {	}
user_map={}

		
player_x=0
player_y=0
player_h=68
dir_x=0
dir_y=0
dir_angle=.75
plane_x=0
plane_y=0
last_player_x=player_x
last_player_y=player_y
last_player_h=player_h
laser_power={1,2,4}
battery_power={1000,3000,10000}
battery_level=1
player_energy=battery_power[battery_level]
player_gold=600

laser_level=2
jump_jet_level=0

far_scan_on=false
laser_selected=true



k_screen_width=128

player_vh=0
player_vx=0
player_vy=0


mouse_map_x =false
mouse_map_y =false
mouse_map_z =false



k_rem = 1
k_add = 2
player_mode=k_rem
player_block = 9

function vec3_sub(a,b)
	return {a[1]-b[1],a[2]-b[2],a[3]-b[3]}
end
function vec3_add(a,b)
	return {a[1]+b[1],a[2]+b[2],a[3]+b[3]}
end
function vec3_scale(a,s)
	return {a[1]*s,a[2]*s,a[3]*s}
end

function pause(len)
	for i=0,len do
		flip()
	end
end

--3d mapping functions

function hash_3d(x,y,z)
	return flr(x*31+y*37+z*41)
end
rand_list={}
k_rand_list_length=5000
for i=0,k_rand_list_length-1 do
	rand_list[i]=rnd(1)
end

function rand_3d(x,y,z)
	return rand_list[hash_3d(x,y,z)%k_rand_list_length]
end


function smooth_3d_noise(x,y,z,scale)
	x/=scale
	y/=scale
	z/=scale
	
	local xl=flr(x)
	local xr=xl+1
	local dx=x%1
	local yl=flr(y)
	local yr=yl+1
	local dy=y%1
	local zl=flr(z)
	local zr=zl+1
	local dz=z%1
	
	local rand_list=rand_list
	local k_rand_list_length=k_rand_list_length
	
	--unrolled hash 3d function here
	local a=rand_list[flr(xl*31+yl*37+zl*41)%k_rand_list_length]
	local b=rand_list[flr(xl*31+yl*37+zr*41)%k_rand_list_length]
	local c=rand_list[flr(xl*31+yr*37+zr*41)%k_rand_list_length]
	local d=rand_list[flr(xl*31+yr*37+zl*41)%k_rand_list_length]
	                                                    --
	local e=rand_list[flr(xr*31+yl*37+zl*41)%k_rand_list_length]
	local f=rand_list[flr(xr*31+yl*37+zr*41)%k_rand_list_length]
	local g=rand_list[flr(xr*31+yr*37+zr*41)%k_rand_list_length]
	local h=rand_list[flr(xr*31+yr*37+zl*41)%k_rand_list_length]
	
	local ad=a+(d-a)*dy
	local bc=b+(c-b)*dy
	local abcd=ad+(bc-ad)*dz
	
	local eh=e+(h-e)*dy
	local fg=f+(g-f)*dy
	local efgh=eh+(fg-eh)*dz
	
	return(abcd+(efgh-abcd)*dx)
	
	
	
	
end

--start gryphon color library----------------------------

gray_patterns={	 0b0.1000000000000000,
				 0b0.1000000000100000,
				 0b0.1000000010100000,
				 0b0.1010000010100000,
				 0b0.1010010010100000,
				 0b0.1010010010100001,
				 0b0.1010010010100101,
				 0b0.1010010110100101,
				 0b0.1110010110100101,
				 0b0.1110010110110101,
				 0b0.1110010111110101,
				 0b0.1111010111110101,
				 0b0.1111010111110111,
				 0b0.1111110111110111,
				 0b0.1111110111111111,
				 0b0.1111111111111111}
				 
				 
pico_palette={
{0,0,0},
{.11,.17,.33},
{.49,.15,.33},
{0,.53,.32},
{.67,.32,.21},
{.37,.34,.31},
{.76,.76,.78},
{1,.95,.91},
{1,0,.3},
{1,.64,0},
{1,.93,.15},
{0,.89,.21},
{.16,.68,1},
{.51,.46,.61},
{1,.47,.66},
{1,.80,.67}
}
				 
function set_color_and_pattern(c1,c2,mix)
	local color = bor(0x1000,shl(c2,4))
	local color = bor(color,c1)
	return bor(color,gray_patterns[ flr(mix)])
end

function color_compare(rgb1,rgb2)
	--use ccir luminosity
	local luma1 = rgb1[1]*.299+rgb1[2]*.587+rgb1[3]*.114
	local luma2 = rgb2[1]*.299+rgb2[2]*.587+rgb2[3]*.114
	local lumadiff=luma1-luma2
	local diff = vec3_sub(rgb1,rgb2)
	return (diff[1]*diff[1]*0.299 + diff[2]*diff[2]*.587 + diff[3]*diff[3]*.114)*.75+lumadiff*lumadiff
end	

function find_mix(target_color,color_list)
	
	local min_dist=100
	local pico_palette=pico_palette
	
	local best_fc = 0
	local best_bc = 0
	local best_mix = 1
	
	--target_color[1]=min(1,target_color[1])
	--target_color[2]=min(1,target_color[2])
	--target_color[3]=min(1,target_color[3])
	
	for fc in all(color_list) do
		for bc in all(color_list) do
			for mix=1,8 do
				local c1=pico_palette[fc+1]
				local c2=pico_palette[bc+1]
				
				local right_mix = (16-mix)/16
				local left_mix = mix/16
				
				
				local result_color = {c1[1]*left_mix+c2[1]*right_mix,c1[2]*left_mix+c2[2]*right_mix,c1[3]*left_mix+c2[3]*right_mix}
				
				
				
				local dist=color_compare(result_color,target_color)
				dist+=color_compare(c1,c2)*.02
				if(dist<min_dist)then
					best_fc=fc
					best_bc=bc
					best_mix=mix
					min_dist=dist
				end
			end
		end
	end
	
	return set_color_and_pattern(best_bc,best_fc,best_mix)
	
end

shade_palette={}
function build_palette(fade_color,fade_brightness)
	local saturate = 12 -- allow for some oversaturation to white
	
	--keep to colors that mix nicely
	local allowed_colors={
	{0},				--0		
	{0,1,5,13},			--1
	{0,1,2,4,8,13},		--2
	{0,1,3,11,12},		--3
	{0,1,2,4,5,14,15},	--4
	{0,1,2,5,13,15},	--5
	{0,1,5,6,13,7},		--6
	{0,1,5,13,6,7},		--7
	{0,1,2,8,4,14},		--8
	{0,1,5,4,9,10,7},	--9
	{0,1,5,4,9,10,7},	--10
	{0,1,3,11,7},		--11
	{0,1,3,12,7},		--12
	{0,1,2,5,13,6},		--13
	{0,1,2,5,4,14,7},	--14
	{0,1,5,13,6,15,7},--15
	{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15} --all
	}
	
	--background fades to this color
	local background_color
	local target_color
	
	if(fade_color!=nil)background_color=vec3_scale(pico_palette[fade_color+1],fade_brightness)
	cls()
	center_print("init color palette",64,122,7)
	
	for j=1,16 do -- color
		shade_palette[j-1]={}
		for i=0,15 do --brightness oversaturate after value of 10
			
			
		
			if(fade_color==nil)then
				shade_palette[j-1][i]=find_mix({pico_palette[j][1]*i/saturate,pico_palette[j][2]*i/saturate,pico_palette[j][3]*i/saturate},allowed_colors[j])
			else
				target_color = vec3_scale(vec3_sub(pico_palette[j],background_color),i/saturate)
				target_color = vec3_add(background_color,target_color)
				shade_palette[j-1][i]=find_mix(target_color,allowed_colors[17])
			end
			
			rectfill(i*8,(j-1)*8,(i+1)*8-2,(j)*8-2,shade_palette[j-1][i])
			
		end
	end
end

------------end gryphon color library---------------------------

--ui/mouse library demo
--by musurca

-- [start ui library]
mouse={}

b_up=0
b_down=1


mcursor_x=0
mcursor_y=0
mcursor_w=0
mcursor_h=0
function mouse_init(spr_index,w,h)
 poke(0x5f2d, 1)
 
 mcursor_x=(spr_index%16)*8
 mcursor_y=flr(spr_index/16)*8
 mcursor_w=w
 mcursor_h=h
 
 mouse.x=63
 mouse.y=63
 mouse.prevx=mouse.x
 mouse.prevy=mouse.y
 mouse.startx=mouse.x
 mouse.starty=mouse.y
end

function mouse_update() 
 local kx=stat(32)
 local ky=stat(33)
  mouse.prevx=mouse.x
  mouse.prevy=mouse.y
  mouse.prev_state=mouse.state
 
  mouse.startx=kx
  mouse.starty=ky
  mouse.x=kx
  mouse.y=ky
 --end
 
 local mdown=(stat(34)>0)
 
  if mdown then 
   mouse.state=b_down
  else
   mouse.state=b_up
  end
  
  return
 end
 
-- [end ui library]




-----------------start voxel raycast library------------------------

--start of code from lodev tutorial
--https://lodev.org/cgtutor/raycasting.html
--then expanded to work work with voxels



function draw_map()

	--local max_perp_wall_dist=1

	local player_x=player_x
	local player_h=player_h
	local x_start=22
	local x_end=127-2
	local step=2
	local player_view_min=flr(player_h)
	
	local max_depth=view_span_width-1

	local offset=2 --how far below feet can you see
	local player_y=player_y
	local vox_map=vox_map

	
	local rect_width_delta=step-1
	local ray_dir_x = (dir_x-plane_x)
	local ray_dir_y = (dir_y-plane_y)
	
	local step_ray_dir_x=plane_x/k_screen_width*2*step
	local step_ray_dir_y=plane_y/k_screen_width*2*step
		
	local player_offset=((player_h%1)*64+16)
	
	local face_brightness={14,11,7,5,15,4}
	local shade_palette = shade_palette
	local map_width=map_width
	local mouse = mouse
	local mx=flr(mouse.x/step)*step
	local my=mouse.y
	
	local last_mouse_map_x=mouse_map_x
	local last_mouse_map_y=mouse_map_y
	local last_mouse_map_z=mouse_map_z
	local last_mouse_map_side=mouse_map_side
	
	mouse_map_x=false
	mouse_map_y=false
	mouse_map_z=false
	--
	for x=x_start,x_end,step do

		local map_x=flr(player_x)
		local map_y=flr(player_y)
		local side_dist_x
		local side_dist_y
		
		
		
		
		local delta_dist_x = abs(1/ray_dir_x)
		local delta_dist_y = abs(1/ray_dir_y)	

		--resolve an overflow error if the ray_dir is small
		if(abs(ray_dir_x)<.001)delta_dist_x=1000
		if(abs(ray_dir_y)<.001)delta_dist_y=1000
		
		local perp_wall_dist		
		local step_x
		local step_y
		local side
		
		--calculate initial step and initial side distance
		if(ray_dir_x<0)then step_x=-1 side_dist_x = (player_x-map_x)*delta_dist_x 
		else step_x=1 side_dist_x = (map_x+1-player_x)*delta_dist_x  shift_x=0 end
		if(ray_dir_y<0)then step_y=-1 side_dist_y = (player_y-map_y)*delta_dist_y
		else step_y=1 side_dist_y = (map_y+1-player_y)*delta_dist_y shift_y=0 end		
		--wall sprites are turned off
		--local wall_x=player_x%1
		--local wall_y=player_y%1
		local depth=0
		local val	


		
		local x_strip={}
		x_strip[0]={} --keeps us from going out of bounds
		while(depth<max_depth)do
			
			side=1
			depth+=1
			x_strip[depth]={}
			local cur_depth=x_strip[depth]

			if(side_dist_x<side_dist_y)then
				side_dist_x+=delta_dist_x
				map_x+=step_x
				
				--wall sprites are turned off
				if(ray_dir_x>0)then side=3 cur_depth.wall_x=0 else side=1 cur_depth.wall_x=1 end
				if(ray_dir_x>0)then side=3 else side=1  end
				perp_wall_dist=(map_x-player_x+shr(1-step_x,1))/ray_dir_x
				
				
				cur_depth.wall_y=(player_y+perp_wall_dist*ray_dir_y)%1
				
			else
				side_dist_y+=delta_dist_y
				map_y+=step_y
				

				if(ray_dir_y>0)then side=4 cur_depth.wall_y=1 else side=2 cur_depth.wall_y=0 end
				if(ray_dir_y>0)then side=4 else side=2  end
				perp_wall_dist=(map_y-player_y+shr(1-step_y,1))/ray_dir_y
				cur_depth.wall_x=(player_x+perp_wall_dist*ray_dir_x)%1
			end
			--resulve an overflow if the perp wall distance is small
			perp_wall_dist=mid(perp_wall_dist,.01,12)
			cur_depth.world_base=64+player_offset/perp_wall_dist  
			
			cur_depth.inv_perp_wall=64/perp_wall_dist

			cur_depth.side=side
			cur_depth.perp_wall_dist=perp_wall_dist	
			cur_depth.map_x=map_x
			cur_depth.map_y=map_y
			cur_depth.map_z_base=player_view_min-offset
			cur_min_h=-flr(perp_wall_dist/2)-2
			cur_max_h=-cur_min_h
			cur_depth.min_h=cur_min_h
			cur_depth.max_h=cur_max_h

			for i=cur_min_h,cur_max_h do
				local z_slice=(player_view_min+i)%map_height
				if(vox_map[z_slice]==nil)then val=0
				else
						val=vox_map[z_slice][map_x%map_width][map_y%map_width]
				end
				cur_depth[i]=val

			end	
		end

		local color

			for depth=max_depth,1,-1 do
				local cur_block=x_strip[depth]
				local last_block=x_strip[depth+1]
				local perp_wall_dist = cur_block.perp_wall_dist
				local z_step = cur_block.inv_perp_wall
				local span_top
				local span_bottom
				local depth_bright=1-cur_block.perp_wall_dist/max_depth
				local step_fade=1-depth/max_depth
				
				
				
				--have a bug with cieling turning off too early right above head
				for i=cur_block.min_h,cur_block.max_h do	
					if(cur_block[i]!=0)then
						local cur_object=object_list[cur_block[i]]
						local mouse_hit=false
						local cur_map_x=cur_block.map_x
						local cur_map_y=cur_block.map_y
						local cur_map_z=cur_block.map_z_base+i+2
						local cur_map_side=cur_block.side
					
						span_top=cur_block.world_base-z_step*i
						span_bottom=span_top+z_step
						local front_block=x_strip[depth-1][i]
						local target_block = (last_mouse_map_z==cur_map_z and last_mouse_map_x==cur_map_x and last_mouse_map_y==cur_map_y)
						if((front_block==0 or front_block==nil))then
							if( mx==x and my>span_top and my<span_bottom)mouse_hit=true
							
							
								color=shade_palette[cur_object[2]][ flr( depth_bright*face_brightness[cur_block.side]) ]
							
								
							--if( last_mouse_map_side==cur_map_side and last_mouse_map_z==cur_map_z and last_mouse_map_x==cur_map_x and last_mouse_map_y==cur_map_y)color=shade_palette[cur_object[2]][ flr( .9*face_brightness[cur_block.side]) ]
							if( last_mouse_map_side==cur_map_side and target_block)color=shade_palette[cur_object[2]][ flr( .9*face_brightness[cur_block.side]) ]
							
							--if(mouse.x==x)
							rectfill(x,span_top,x+rect_width_delta,span_bottom,color)
							if(target_block and currently_mining)then
								local block_mid=(span_top+span_bottom)/2
								local block_delta=(span_top-block_mid)--*(abs(sin(cur_block.wall_x/2)+sin(cur_block.wall_y/2)))*sin(cur_frame/30)
								local time_delta=abs(sin(cur_frame/40))
								
								for c_scale=1,0,-.2 do
									local shade= flr(sin(c_scale-cur_frame/20)*7.5+7.5)
									rectfill(x,block_mid+block_delta*c_scale,x+rect_width_delta-1,block_mid-block_delta*c_scale,shade_palette[9][shade])
								end
							end
							if(cur_object[3]!=false )then
								palt(14,true)
								
								if(cur_block.side==1 or cur_block.side==3)sspr(cur_object[3]%16*8+cur_block.wall_y*16,flr(cur_object[3]/16)*8,1,16,x,span_top,step,z_step)
								if(cur_block.side==2 or cur_block.side==4)sspr(cur_object[3]%16*8+cur_block.wall_x*16,flr(cur_object[3]/16)*8,1,16,x,span_top,step,z_step)
								
								palt(14,false)
							end
							
							--if(cur_block.wall_x>.25)rectfill(x,span_top+z_step*.25,x+rect_width_delta,span_bottom-z_step*.25,7)
							
						end
						if(last_block!=nil)then					
							--draw floors and cielings
							if(span_top>64)then
								--check if there is a block above us
								if(cur_block[i+1]==0)then
									
									local last_block_top = last_block.world_base-last_block.inv_perp_wall*i
									if( mx==x and my<span_top and my>last_block_top)mouse_hit=true cur_map_side=5
									
									color=shade_palette[cur_object[2]][ flr( step_fade*face_brightness[5]) ]
									if( last_mouse_map_side==5 and  target_block)color=shade_palette[cur_object[2]][ flr( .9*face_brightness[5]) ]
									if(cur_block[i]==24)color=shade_palette[10][flr(step_fade*.5*(sin(-cur_frame/40+(abs(cur_map_x)+abs(cur_map_y))/10)+1.5)*15)]
									rectfill(x,span_top,x+rect_width_delta,last_block_top,color)
									
									if(target_block and currently_mining)then

										local shade= flr(-sin(cur_frame/20)*7.5+7.5)
										rectfill(x,span_top,x,last_block_top,shade_palette[9][shade])
									
									end
									
								end
							end
							
							if(span_bottom<64)then	
								--check if there is a block beneath us
								if(cur_block[i-1]==0)then
									local last_block_bottom = last_block.world_base-last_block.inv_perp_wall*(i-1)
									if( mx==x and my>span_bottom and my<last_block_bottom)cur_map_side=6 mouse_hit=true
									
									color=shade_palette[cur_object[2]][ flr( step_fade*face_brightness[6]) ]
									if( last_mouse_map_side==6 and target_block)color=shade_palette[cur_object[2]][ flr( .9*face_brightness[6]) ]
									rectfill(x,span_bottom,x+rect_width_delta,last_block_bottom,color)
									
									if(target_block and currently_mining)then

										local shade= flr(-sin(cur_frame/20)*7.5+7.5)
										rectfill(x,span_bottom,x+rect_width_delta,last_block_bottom,shade_palette[9][shade])
									
									end
								end
							end

							if(mouse_hit)then
								mouse_map_x=cur_map_x
								mouse_map_y=cur_map_y
								mouse_map_z=cur_map_z
								mouse_map_side=cur_map_side
							end
						end
						
						
						
					end
					
				end	
			end

			ray_dir_x+=step_ray_dir_x
			ray_dir_y+=step_ray_dir_y
		
	end
	
	

	if(mouse_map_x!=false)print(mouse_map_x..","..mouse_map_y..","..mouse_map_z,64,0,15)
	
end







function check_square(x,y,z)
	return vox_map[flr(z)%map_height][flr(x)%map_width][flr(y)%map_width]
end

function check_collision(x,y,z,r,step,count)
	
	local v
	if(step==nil)step=0 count=0
	
	for i=0,count do
		v=check_square(x+r,y-r,z+i*step) if(v!=0)return v
		v=check_square(x+r,y+r,z+i*step) if(v!=0)return v
		v=check_square(x-r,y-r,z+i*step) if(v!=0)return v
		v=check_square(x-r,y+r,z+i*step) if(v!=0)return v
	end
	return false
	

end 


function handle_buttons()
	local player_radius=.4
	
	--player_h=min(-1.5,player_h)
	if(btn(0) or btn(0,1))dir_angle+=-.007
	if(btn(1) or btn(1,1))dir_angle+=.007
	
	dir_x=cos(dir_angle)
	dir_y=sin(dir_angle)
	
	local player_acel=.015
	local player_max_speed=.15
	
	if(btn(2) or btn(2,1))player_vx+=dir_x*player_acel player_vy+=dir_y*player_acel player_energy-=.2
	if(btn(3) or btn(3,1))player_vx+=-dir_x*player_acel player_vy+=-dir_y*player_acel player_energy-=.2
	
	
	player_vx*=.93
	player_vy*=.93
	
	speed= (player_vx*player_vx+player_vy*player_vy)^.5
	if(speed>player_max_speed)then
		player_vx/=speed/player_max_speed
		player_vy/=speed/player_max_speed
	end
	
	
	plane_x=cos(dir_angle+.25)
	plane_y=sin(dir_angle+.25)
	
	player_vh-=.02
	
	
	
	
	
	local hit=0
	can_jump=false


	if(check_collision(player_x+player_vx,player_y,player_h,.4,.5,3))player_vx=0

	player_x+=player_vx
	if(check_collision(player_x,player_y+player_vy,player_h,.4,.5,3))player_vy=0
	player_y+=player_vy
	
	
	if(check_collision(player_x,player_y,player_h+player_vh,.4))player_vh=0 can_jump=true
	--if(player_h+player_vh<1)player_h=1 player_vh=0 can_jump=true
	if(player_vh>0 and check_collision(player_x,player_y,player_h+player_vh+1.5,.4))player_vh=0
	if( (btn(4) or btn(4,1)))then
		if( can_jump)then
			player_vh=.25
			player_energy-=2
		else
			player_vh+=.005*jump_jet_level
			player_energy-=.6
		end
	end
	player_vh=mid(player_vh,-.4,.4)
	
	--if( (btn(4) or btn(4,1)))player_vh=.25
	
	if(check_square(player_x,player_y,player_h-1)==24) then player_energy+=max((battery_power[battery_level]-player_energy)/60,.5) end
	player_energy=mid(player_energy,-1,battery_power[battery_level])
	player_h+=player_vh
	
	
	
	
end



--block_name,block_color,block_image,block_icon,placeable,tool?,value,mine_time
k_object_name=1
k_object_color=2
k_object_image=3
k_object_icon=4
k_object_placeable=5
k_object_tool=6
k_object_minable_by=7
k_object_craft_recipe=7



object_list=
{
{"dirt"			,4,	false	,32,true,false,0,15}, --1
{"grass"		,11,false	,33,true,false,0,15}, --2
{"light_stone"	,6,false	,34,true,false,.5,30}, --3
{"stone"		,5,	false	,35,true,false,.5,30}, --4
{"copper ore"	,6,	6		,36,false,false,10,50}, --5
{"iron ore"		,6,	2		,37,false,false,15,50}, --6
{"coal ore"		,5,	8		,38,false,false,15,50}, --7
{"gold ore"		,6,	4		,39,false,false,60,75}, --8
{"laser-1"	,0,false	,40,false,true,80},--9
{"laser-2"	,0,false	,40,false,true,800},--10
{"laser-3"	,0,false	,40,false,true,1600},--11
{"battery-1"	,0,false	,44,false,true,120},--12
{"battery-2"	,0,false	,44,false,true,600},--13
{"battery-3"	,0,false	,44,false,true,1200},--14
{"far view"	,1,false	,45,false,true,350},--15
{"jump jet-1"	,0,false	,46,false,true,120},--16
{"jump jet-2"	,0,false	,46,false,true,900},--17
{"jump jet-3"	,0,false	,46,false,true,1800},--18
{"gps"	,0,false	,47,false,true,600},--19
{"diamond"	,6,14	,50,false,false,200,150},--20
{"ruby"	,6,64	,51,false,false,80,100},--21
{"emerald"	,6,66	,52,false,false,80,100},--22
{"store"	,6,68,53,false,false,0,10000}, --23
{"charging"	,10,false,53,false,false,0,10000}, --24
{"red"	,8,false,53,true,false,0,50}, --25

}


tool_inventory={}

k_wood_pick=9
k_bronze_pick=10



selected_item=k_wood_pick




inventory={}


function add_to_inventory(object_index,qty)
	qty=qty or 1
	local object=object_list[object_index]
	--is item in inventory
	if(inventory[object_index]!=nil)then
		inventory[object_index].qty+=qty
	else
		cur_item={}
		cur_item.name=object[1]
		cur_item.qty=qty
		cur_item.icon=object[4]
		cur_item.index=object_index
		inventory[object_index]=cur_item
	end

	--update_inventory_ui()

end

function map_function(x,y,z)
	
	local user_block=read_user_block(x,y,z)
	if(user_block!=nil)return user_block
	local surf=smooth_3d_noise(x,y,z,10)
	if(surf<.25)return 0

	
	if(z==60)then if(rand_3d(x,y,z)>.15)then return 2 else return 1 end end --grass
	if(z<60 and z>=58) return 1 --dirt
	
	
	
	local ore=4
	chance=rand_3d(x,y,z)
	--local chance=surf*mid(-(z-64)/32,0,1)
	if(chance<.25)ore=3
	if(chance<.05)ore=6
	if(chance<.03)ore=7
	if(chance<.02)ore=8
	if(chance<.008)ore=21 --emerald
	if(chance<.004)ore=22 --ruby
	if(chance<.002)ore=20 --diamond
	
	
	local h=smooth_3d_noise(x,y,4,15)*20-8
	
	
	
	
	
	if(z<58)then
		return ore
	end
	
	if(z-60<h)then
		return ore	
	end
	
	
	
	return 0
end


 map_height = 16
 map_width = 64
 k_view_span_width=7
 k_view_span_min_h=-4
 k_view_span_max_h=6
 
 k_zoom_view_span_width=9
 k_zoom_view_span_min_h=-6
 k_zoom_view_span_max_h=8
 
 view_span_width=k_view_span_width
 view_span_min_h=k_view_span_min_h
 view_span_max_h=k_view_span_max_h
 --was planning on having a zoom function to see further at a lower framerate or when stopped
 
function init_map()
	
	local v
	--z,x,y
	for i=0,map_height do
		vox_map[i]={}
		for x=0,map_width-1 do
			vox_map[i][x]={}
			for y=0,map_width-1 do				
				vox_map[i][x][y]=0
			end
	
		end

	end
	
	--draw starting world
	
	
	draw_starting_world()

end

function draw_starting_world()
	for x=-view_span_width,view_span_width do
		for y=-view_span_width,view_span_width do
			for z=view_span_min_h,view_span_max_h do
				local m=flr(player_x+x)
				local n=flr(player_y+y)
				local p=flr(player_h+z)
				local vox_m=m%map_width
				local vox_n=n%map_width
				local vox_p=p%map_height
				vox_map[vox_p][vox_m][vox_n]=map_function(m,n,p)
			end
		end
	end
end

function write_user_block(x,y,z,val)
	if(user_map[z]==nil)user_map[z]={}
	if(user_map[z][x]==nil)user_map[z][x]={}
	user_map[z][x][y]=val
end

function read_user_block(x,y,z)
	
	if(user_map[z]==nil)return nil
	if(user_map[z][x]==nil)return nil
	return user_map[z][x][y]

end

function create_start()
	local rad=2
	local z=180
	while(map_function(0,0,z)==0 and map_function(4,0,z)==0 and map_function(4,4,z)==0)do
		z-=1
	end
	
	for i=-rad,rad do
		for j=-rad,rad do
			
			
				write_user_block(i,j,z,24)
				for k=z+1,z+3 do
				write_user_block(i,j,k,0)
				end
			
		end
	end
	
	write_user_block(0,2,z+2,23)
	write_user_block(0,2,z+1,25)
	write_user_block(1,2,z+2,25)
	write_user_block(-1,2,z+2,25)
	write_user_block(0,2,z+3,25)
	write_user_block(0,3,z+2,25)
	player_h=z+2
end

dirty_x_plus=0
dirty_x_minus=0
dirty_y_plus=0
dirty_y_minus=0
dirty_z_plus=0
dirty_z_minus=0

function dynamic_world_update()
	--this is a bit of a dog's breakfast here
	--splitting the map refresh between 2 frames
	local player_x=flr(player_x)
	local player_y=flr(player_y)
	local player_h=flr(player_h)
	local move_x=last_player_x-player_x
	local move_y=last_player_y-player_y
	local move_z=last_player_h-player_h
	local map_width=map_width
	local map_height=map_height
	local view_span_short=view_span_width
	local user_block
	local vox_map=vox_map
	local view_span_min_h=view_span_min_h
	local view_span_max_h=view_span_max_h
	
	if(move_x>0)then dirty_x_plus=2 elseif(move_x<0)then dirty_x_minus=2 end
	if(move_y>0)then dirty_y_plus=2 elseif(move_y<0)then dirty_y_minus=2 end
	if(move_z>0)then dirty_z_plus=2 elseif(move_z<0)then dirty_z_minus=2 end
	
	if(dirty_x_plus>0)then
		local x=-view_span_short
		if(dirty_x_plus==2)then
			for y=-view_span_short+1,view_span_short,2 do
				local m=player_x+x
				local n=player_y+y
				local vox_m=m%map_width
				local vox_n=n%map_width
				for z=view_span_min_h,view_span_max_h do
				local p=player_h+z
					vox_map[p%map_height][vox_m][vox_n]=map_function(m,n,p)					
				end
			end
		else --last frame
			for y=-view_span_short,view_span_short,2 do
				local m=last_player_x+x
				local n=last_player_y+y
				local vox_m=m%map_width
				local vox_n=n%map_width
				for z=view_span_min_h,view_span_max_h do
				local p=last_player_h+z
					vox_map[p%map_height][vox_m][vox_n]=map_function(m,n,p)					
				end
			end
		end
		dirty_x_plus-=1
	end
	if(dirty_x_minus>0)then
		local x=view_span_short
		if(dirty_x_minus==2)then
			for y=-view_span_short+1,view_span_short,2 do
				local m=player_x+x
				local n=player_y+y
				local vox_m=m%map_width
				local vox_n=n%map_width
				for z=view_span_min_h,view_span_max_h do
				local p=player_h+z
					vox_map[p%map_height][vox_m][vox_n]=map_function(m,n,p)					
				end
			end
		else --last frame
			for y=-view_span_short,view_span_short,2 do
				local m=last_player_x+x
				local n=last_player_y+y
				local vox_m=m%map_width
				local vox_n=n%map_width
				for z=view_span_min_h,view_span_max_h do
				local p=last_player_h+z
					vox_map[p%map_height][vox_m][vox_n]=map_function(m,n,p)					
				end
			end
		end
		dirty_x_minus-=1
	end
	
	
	if(dirty_y_plus>0)then
		local y=-view_span_short
		if(dirty_y_plus==2)then
			for x=-view_span_short+1,view_span_short,2 do
				local m=player_x+x
				local n=player_y+y
				local vox_m=m%map_width
				local vox_n=n%map_width
				for z=view_span_min_h,view_span_max_h do
				local p=player_h+z
					vox_map[p%map_height][vox_m][vox_n]=map_function(m,n,p)					
				end
			end
		else --last frame
			for x=-view_span_short,view_span_short,2 do
				local m=last_player_x+x
				local n=last_player_y+y
				local vox_m=m%map_width
				local vox_n=n%map_width
				for z=view_span_min_h,view_span_max_h do
				local p=last_player_h+z
					vox_map[p%map_height][vox_m][vox_n]=map_function(m,n,p)					
				end
			end
		end
		dirty_y_plus-=1
	end
	if(dirty_y_minus>0)then
		local y=view_span_short
		if(dirty_y_minus==2)then
			for x=-view_span_short+1,view_span_short,2 do
				local m=player_x+x
				local n=player_y+y
				local vox_m=m%map_width
				local vox_n=n%map_width
				for z=view_span_min_h,view_span_max_h do
				local p=player_h+z
					vox_map[p%map_height][vox_m][vox_n]=map_function(m,n,p)					
				end
			end
		else --last frame
			for x=-view_span_short,view_span_short,2 do
				local m=last_player_x+x
				local n=last_player_y+y
				local vox_m=m%map_width
				local vox_n=n%map_width
				for z=view_span_min_h,view_span_max_h do
				local p=last_player_h+z
					vox_map[p%map_height][vox_m][vox_n]=map_function(m,n,p)					
				end
			end
		end
		dirty_y_minus-=1
	end
	
	if(dirty_z_minus>0)then
		local z=view_span_max_h
		if(dirty_z_minus==2)then
			local p=player_h+z
			local vox_p=p%map_height
			for x=-view_span_short+1,view_span_short,2 do
				for y=-view_span_short,view_span_short do
					local m=player_x+x
					local n=player_y+y
					local vox_m=m%map_width
					local vox_n=n%map_width
					vox_map[vox_p][m%map_width][n%map_width]=map_function(m,n,p)
				end
			end
		else
			local p=last_player_h+z
			local vox_p=p%map_height
			for x=-view_span_short,view_span_short,2 do
				for y=-view_span_short,view_span_short do
					local m=last_player_x+x
					local n=last_player_y+y
					local vox_m=m%map_width
					local vox_n=n%map_width
					vox_map[vox_p][m%map_width][n%map_width]=map_function(m,n,p)
				end
			end
		end
		dirty_z_minus-=1
	end
	if(dirty_z_plus>0)then
		local z=view_span_min_h
		if(dirty_z_plus==2)then
			local p=player_h+z
			local vox_p=p%map_height
			for x=-view_span_short+1,view_span_short,2 do
				for y=-view_span_short,view_span_short do
					local m=player_x+x
					local n=player_y+y
					local vox_m=m%map_width
					local vox_n=n%map_width
					vox_map[vox_p][m%map_width][n%map_width]=map_function(m,n,p)
				end
			end
		else
			local p=last_player_h+z
			local vox_p=p%map_height
			for x=-view_span_short,view_span_short,2 do
				for y=-view_span_short,view_span_short do
					local m=last_player_x+x
					local n=last_player_y+y
					local vox_m=m%map_width
					local vox_n=n%map_width
					vox_map[vox_p][m%map_width][n%map_width]=map_function(m,n,p)
				end
			end
		end
		dirty_z_plus-=1
	end
	
	last_player_x=player_x
	last_player_y=player_y
	last_player_h=player_h
end



block_timer=0
currently_mining=false
function handle_mouse_click()

	
	if(mouse.x>20)then
			nz=mouse_map_z
			nx=mouse_map_x
			ny=mouse_map_y
	
			if( mouse.state==b_up)then
				block_timer=0
				currently_mining=false
			end
			if( mouse.prev_state==b_up and mouse.state==b_down)then
				if(mouse_map_x!=false)then
					if(vox_map[mouse_map_z%map_height][mouse_map_x%map_width][mouse_map_y%map_width]==23)then
						game_mode=k_mode_store
						
					elseif(not laser_selected and object_list[selected_item][k_object_placeable]==true and mouse_map_x!=false)then

								if(mouse_map_side==5)nz+=1
								if(mouse_map_side==6)nz-=1
								if(mouse_map_side==1)nx+=1
								if(mouse_map_side==3)nx-=1
								if(mouse_map_side==2)ny+=1
								if(mouse_map_side==4)ny-=1
							if(inventory[selected_item].qty>0 and mouse_map_x!=false)then
									inventory[selected_item].qty-=1

									vox_map[nz%map_height][nx%map_width][ny%map_width]=selected_item
									if(check_collision(player_x,player_y,player_h,.4,.5,3))then
										vox_map[nz%map_height][nx%map_width][ny%map_width]=0
									else
										write_user_block(nx,ny,nz,selected_item)
									end
							end
					end
				end
			elseif(mouse.state==b_down)then
				currently_mining=false
					if(mouse_map_x!=false and laser_selected)then

					
						local object_index= vox_map[mouse_map_z%map_height][mouse_map_x%map_width][mouse_map_y%map_width]
							block_timer+=1
							currently_mining=true
							player_energy-=.25
							local mine_length=object_list[object_index][8]/laser_power[laser_level]
							
							local color=7
							circ(mouse.x,mouse.y,10,color)
							circ(mouse.x,mouse.y,7,color)				
							for c=0,1,.25 do
								local a=(block_timer/mine_length/2+c)
								local dy=sin(a)
								local dx=cos(a)			
								line(dx*7+mouse.x,dy*7+mouse.y,dx*12+mouse.x,dy*12+mouse.y,color)		
								line(mouse.x,mouse.y,-dy*7+mouse.x,-dx*7+mouse.y,color)
							end
							
							if(block_timer>mine_length)then
								vox_map[mouse_map_z%map_height][mouse_map_x%map_width][mouse_map_y%map_width]=0
								write_user_block(mouse_map_x,mouse_map_y,mouse_map_z,0)
								add_to_inventory(object_index)
								block_timer=0
							end
					end
				
				
			end
		end
end

function tri_line(x1,y1,z1,x2,y2,z2,c)
	sx1=(x1-64)/z1+64
	sy1=(y1-64)/z1+64
	sx2=(x2-64)/z2+64
	sy2=(y2-64)/z2+64
	
	line(sx1,sy1,sx2,sy2,c)
end

function draw_mouse()



	if(not currently_mining)then
		local color=7
		line(mouse.x-4,mouse.y,mouse.x+4,mouse.y,color)
		line(mouse.x,mouse.y-4,mouse.x,mouse.y+4,color)
	end
end



function center_print(text,x,y,c)
	print(text,x-#text*4/2,y,c)
end
k_none=0
k_click=1
k_hover=2
k_down=3
function click_in_rect(x1,y1,x2,y2)
	local state=k_none
	if(mouse.x>x1 and mouse.x<x2 and mouse.y>y1 and mouse.y<y2)then
		state=k_hover
		if(mouse.state==b_up and mouse.prev_state==b_down)then
			state=k_click
		elseif(mouse.state==b_down)then
			state=k_down
		end
	end
	return state
end

store_scroll=0
function handle_store()
	
	fillp()
	palt(0,true)
	rectfill(32,16,127-32,127-16,0)
	rect(32,16,127-32,127-16,7)
	center_print("store",64,18,7)
	
	--scroll bar
	rectfill(95,16,103,99,0)
	rect(95,16,103,99,7)
	spr(48,97,18)
	spr(49,97,94)
	if(click_in_rect(95,16,103,22)==k_down)store_scroll-=1
	
	if(click_in_rect(95,93,103,99)==k_down)store_scroll+=1
	
	store_scroll=mid(store_scroll,0,40)
	clip(33,26,62,73)
	--rectfill(0,0,127,127,8)
	
	
	local count=-1
	for i,item in pairs(object_list) do
		if(item[k_object_tool])then
			count+=1
			local name=item[1]
			local cost=item[7]
			local name_x=34
			local cost_x=80
			local item_y=28+count*8-store_scroll
			
			if( inventory[i]==nil)then
				print(name,name_x,item_y,6)
				print(cost,cost_x,item_y,6)
				
				if(mouse.x>32 and mouse.x<95 and mouse.y>item_y and mouse.y<item_y+8)then
					if(mouse.state==b_up)then
						print(name,name_x,item_y,7)
						
						if(mouse.prev_state==b_down)then
							if(player_gold>cost)then
								add_to_inventory(i)
								player_gold-=cost
							end

						end
						
					else
						print(name,name_x,item_y,9)
					end
					
				end
				
			else
				print(name,name_x,item_y,5)
				print("out",cost_x,item_y,5)
			end		
		end
	end
	clip()
	
	rectfill(32,99,95,111,5)
	rect(32,99,95,111,7)
	if(mouse.x>32 and mouse.x<95 and mouse.y>99 and mouse.y<111)then
		if(mouse.state==b_down)then
		rectfill(33,100,94,110,6)
			
		else
			if(mouse.prev_state==b_down)game_mode=k_mode_play
		end
	end
	center_print("exit",64,103,7)
	
	--handle inventory updates
	if(inventory[9]!=nil)laser_level=1 
	if(inventory[10]!=nil)laser_level=2 
	if(inventory[11]!=nil)laser_level=3 
	block_remove_time=laser_power[laser_level]
	
	if(inventory[12] !=nil)battery_level=1
	if(inventory[13]!=nil)battery_level=2
	if(inventory[14]!=nil)battery_level=3
	
	if(inventory[16] !=nil)jump_jet_level=1
	if(inventory[17]!=nil) jump_jet_level=2
	if(inventory[18]!=nil) jump_jet_level=3
	
	
	if(cur_frame%2==0)sell_items()
end

function sell_items()
	for i,item in pairs(object_list) do
		if(not item[k_object_tool])then
			if(inventory[i]!=nil)then
				if(inventory[i].qty>0)then
					inventory[i].qty-=1
					player_gold+=item[7]
				end
			end
		end
	end
end

function handle_hud()

	--for i=0,6 do spr(64,4,i*8) end
	--spr(80,4,48)
	--spr(81,12,48)
	
	rectfill(0,0,127,12,0)
	rect(0,0,127,12,7)
	rectfill(0,13,20,127,0)
	rect(0,12,20,127,7)
	
	palt(0,false)
	palt(14,true)
	local i_count=0
	local t_count=0
	for i,item in pairs(object_list) do
		if(not item[k_object_tool])then
			if(inventory[i]!=nil)then
				if(inventory[i].qty>0)then
					local r_top=i_count*11+12
					local r_bot=r_top+11
					local r_left=0
					local r_right=20
					
					rect(r_left,r_top,r_right,r_bot,7)
					local state=click_in_rect(r_left,r_top,r_right,r_bot)
					local c=6
					if(state==k_click)selected_item=i
					if(state==k_hover)rectfill(r_left+1,r_top+1,r_right-1,r_bot-1,1)
					if(selected_item==i)rectfill(r_left+1,r_top+1,r_right-1,r_bot-1,6) c=0 laser_selected=false
				
					spr(item[4],r_left+2,r_top+2)
					print(inventory[i].qty,r_left+12,r_top+5,c)
					i_count+=1
				end
			end
		else
			
			
			
			
			
		end
	end
	
	
	
	--laser
	local c=7
	--rectfill(0,106,20,127,0)
	if(click_in_rect(0,106,20,127)==k_click)laser_selected=true selected_item=-1
	
	if(laser_selected)rectfill(0,106,20,127,6) c=0
	
	rect(0,106,20,127,7)
	
	spr(40,2,110)
	if(laser_level==1)spr(41,10,110)
	if(laser_level==2)spr(42,10,110)
	if(laser_level==3)spr(43,10,110)
	print("l"..laser_level,7,118,c)
	
	
	
	
	
	
	print("e:"..flr(player_energy),30,4,11)
	print("$"..player_gold,3,4,10)
	
	
	--battery
	spr(44,88,3)
	print("l"..battery_level,99,4,7)
	--rect(77,0,95,11,7)
	--jump jet
	spr(46,108,3)
	print("l"..jump_jet_level,118,4,7)
	--rect(95,0,114,11,7)
	--far scan
	if(inventory[15]!=nil)spr(45,78,3)
	--gps
	if(inventory[19]!=nil)then
		spr(47,68,3)
		rectfill(79,12,127,20,0)
		rect(79,12,127,20,7)
		center_print(flr(player_x)..","..flr(player_y)..","..flr(player_h),105,14,7)
	end
end

function project_point(x,y,z)
	local sx=(-x+y*.5)*2+73
	local sy=(y*.75-z+x*.25)*2+70
	return sx,sy
end

function project_line(x1,y1,z1,x2,y2,z2,c)
	sx1,sy1=project_point(x1,y1,z1)
	sx2,sy2=project_point(x2,y2,z2)
	line(sx1,sy1-1,sx2,sy2-1,c)
end

fv_width=15
fv_height=8
function init_far_view()
	cls(0)

	
	--for i=0,32 do
	--	rectfill(0,i*4,127,i*4+3,shade_palette[7][flr(sin(i/64)*8+8)])
    --
	--end
	fillp()
	handle_hud()
	fv_y=-fv_width
	fv_end=fv_width
	game_mode=k_mode_far_view
	
	project_line(-15,-15,8,15,-15,8,7)
	project_line(-15,-15,-8,15,-15,-8,7)
	project_line(-15,-15,-8,-15,-15,8,7)
	project_line(15,-15,-8,15,-15,8,7)
	
	project_line(15,-15,-8,15,15,-8,7)
	project_line(-15,-15,-8,-15,15,-8,7)
	project_line(-15,15,-8,15,15,-8,7)
	
	project_line(-15,15,-8,-15,15,8,7)
	project_line(-15,15,8,-15,-15,8,7)
	
	
end

function draw_far_view()
	 
	
	local player_x=flr(player_x)
	local player_y=flr(player_y)
	local player_h=flr(player_h)
	
	
	
	--for y=-fv_width,fv_width do
	--for y=cur_frame%30-1-15,cur_frame%30+1-15 do
	--y=cur_frame%30-1-15
	if(fv_y<fv_end)then
	for x=-fv_width,fv_width do
		
			for z=-8,8 do
				local m=player_x+x
				local n=player_y+fv_y
				local p=player_h+z
				local vox_m=m%map_width
				local vox_n=n%map_width
				local vox_p=p%map_height
				local v=map_function(m,n,p)
				local sx,sy=project_point(x,fv_y,z)
				
				
				if(v!=0)then
					local color1 = shade_palette[object_list[v][2]][ 14 ]
					local color2 = shade_palette[object_list[v][2]][ 5 ]
					local color3 = shade_palette[object_list[v][2]][ 2 ]
					
					
					
					
					rectfill(sx,sy,sx+1,sy+1,color2)
					rectfill(sx,sy-1,sx+1,sy-1,color1)
					rectfill(sx-1,sy,sx-1,sy+1,color3)
					
					--rectfill(sx,sy,sx+1,sy+1,color1)
					--rectfill(sx-2,sy,sx-1,sy+1,color2)
					--rectfill(sx-2,sy+3,sx+2,sy+4,color3)
				end
				--flip()
			end
			fillp()
			sxa,sya=project_point(0,0,0)
			sx,sy=project_point(dir_x*3,dir_y*3,0)
			circ(sxa,sya,2,7)
			
			
			line(sxa,sya,sx,sy,7)
			circ(sx,sy,1,7)
			
			--flip()
		end
		
	end	
	fv_y+=1
	
	center_print("far view activated",73,120,11)
	
	---end
	---fillp()
	--line(fsx1,fsy1,fsx2,fsy2,7)
	--line(fsx3,fsy3,fsx4,fsy4,7)
	--line(fsx1,fsy1,fsx3,fsy3,7)
	--line(fsx2,fsy2,fsx4,fsy4,7)
end

function init_dead()
	dead_timer=30
	game_mode=k_mode_dead
end

function handle_dead()
	if(dead_timer>0)then
		rectfill(0,0,127,127,shade_palette[9][flr(rnd(16))])
		fillp()
		handle_hud()
		player_h+=.5
		dynamic_world_update()
		draw_map()
		
		
		center_print("system fail",73,64,7)
		center_print("emergency recovery",73,70,7)
		
	end
	if(dead_timer==0)then
		player_x=0
		player_y=0
		player_h=80
		init_map()
		dynamic_world_update()
		player_energy=100
		player_gold=flr(player_gold/4)
		game_mode=k_mode_play
	end
	dead_timer-=1
end

function init_title_screen()
	cls(0)
	title_x=0
	title_y=0
	title_z=64
	game_mode=k_mode_title_screen
	
	sspr(0,82,70,43,29,4)
	
	for x=-32,32 do
		draw_column(x)
		--flip()
	end
	
	
end

function draw_column(x)
	local object_list=object_list
	local title_y=title_y
	local title_x=title_x
	local title_z=title_z
	for y=-10,14 do
		
			for z=-8,10 do
				local v=map_function(x+title_x,y+title_y,z+title_z)
				if(v!=0)then
				local color1 = shade_palette[object_list[v][2]][ 14 ]
				local color2 = shade_palette[object_list[v][2]][ 5 ]
				
				
				sx=x*2+64
				sy=y*1-z*2+80
				
				
				rectfill(sx,sy,sx+1,sy,color1)
				rectfill(sx,sy+1,sx+2,sy+2,color2)
				
				end
			end
			
	end
end

function handle_title_screen()

	--move screen chunk 2 pixels to left
	
	--for screen_mem=0x6c00+16,0x7fc0,64 do
	--	memcpy(screen_mem,screen_mem+1,32)
	--end
	--rectfill(96,48,98,127,0)
	--draw_column(16)
	
	for screen_mem=0x6c00,32192,64 do
		memcpy(screen_mem,screen_mem+1,64)
	end
	rectfill(126,48,127,127,0)
	draw_column(31)
	
	center_print("z:start  x:instructions",64,120,7)
	
	title_x+=1
	
	if(btnp(4))game_mode=k_mode_play
	if(btnp(5))init_instructions()

end

function init_instructions()
	game_mode=k_mode_instructions
	add_to_inventory(1,3)
	i_counter=0
	cls(1)
end

function double_rect(x1,y1,x2,y2,c1,c2)
	rectfill(x1,y1,x2,y2,c2)
	rect(x1,y1,x2,y2,c1)
end

function handle_instructions()
	cls()
	fillp()
	handle_hud()
	
	if(i_counter==0)double_rect(8,34,114,66,7,0)print("s,e: turn left and right\ne,d: forward and back\nlshift or z:jump\nx: far-view (if purchased)\nmouse: mine or place block",10,36,7)
	if(i_counter==1)double_rect(30,102,118,116,7,0) print("click to select laser\nmine with left mouse",32,104,7) line(30,110,16,110,7) 
	if(i_counter==2)double_rect(30,14,118,28,7,0) print("click to select block\nplace with left mouse",32,16,7) line(30,18,16,18,7) 
	if(i_counter==3)double_rect(30,14,118,28,7,0) print("money for store\nore+gems auto-sell",32,16,7) line(30,18,20,8,7) 
	if(i_counter==4)double_rect(30,14,120,28,7,0) print("energy depletes\nrecharge on glow-block",32,16,7) line(40,14,40,10,7) 
	if(i_counter==5)double_rect(30,14,120,22,7,0) print("battery capacity level",32,16,7) line(100,14,100,10,7) 
	if(i_counter==6)double_rect(42,14,125,28,7,0) print("jump jet boost level\nhold z to hover",44,16,7) line(120,14,120,10,7) 
	
	print("z: next instruction",52,122,7)
	if( btnp(4))i_counter+=1
	if(i_counter==7)init_title_screen()
	
end


k_mode_play = 1
k_mode_inventory = 2
k_mode_store=3
k_mode_far_view=4
k_mode_dead=5
k_mode_title_screen=6
k_mode_instructions=7

game_mode=k_mode_play

function _init()
	cls()
	cur_frame=0
	
	

	
	mouse_init(0,8,8)
	
	srand(2)
	palt(0,false)
	poke(0x5f34, 1) -- set fill pattern mode
	build_palette()
	
	

	

	add_to_inventory(9)
	add_to_inventory(12)
	


	create_start()
	init_map()
	--build_store_ui()
	
	init_title_screen()
	--init_instructions()
end



function _update()
	last_mouse=mouse
	mouse_update()
	
	if(game_mode==k_mode_play)then
		handle_buttons()
		
		dynamic_world_update()
		
		
		
		
	end--end game mode play
	
end

speed_chart={}
for i=0,29 do speed_chart[i]=0 end
function _draw()
	cur_frame+=1
	
	--rectfill(0,0,127,127,0)
	
	if(game_mode==k_mode_title_screen)then
		handle_title_screen()
	end
	
	if(game_mode==k_mode_instructions)then
		handle_instructions()
	end
	
	if(game_mode==k_mode_play)then
		cls(0)
		--rectfill(16,65,127,127,0)
		-----
		--for i=0,16 do
		--	rectfill(16,64-i*4,127,64-i*4+3,shade_palette[1][flr(1/i*16)+2])
		--end
		

    
		draw_map()
		fillp(0)
		handle_mouse_click()
		
		--rectfill(0,0,15,127,0)
		
			
		if(player_energy<0)init_dead()
    
		handle_hud()
		draw_mouse()
		if(btn(5) and inventory[15]!=nil)init_far_view()
		--if(btn(5))init_dead()
	end
	if(game_mode==k_mode_store)then
		cls(0)
		draw_map()
		fillp(0)
		handle_hud()
		handle_store()
		draw_mouse()
	end
	
	if(game_mode==k_mode_far_view)then
		
		draw_far_view()
		if(not btn(5))game_mode=k_mode_play
		
	end
		
	if(game_mode==k_mode_dead)then
		handle_dead()
	end
	
	
		
	
	--rectfill(100,20,127,30,0)
	--print(stat(1),100,20,8)
	
	--speed_chart[cur_frame%30]=stat(1)
	--for i=0,29 do
	--	rectfill(i+64,127,i+64,127-30,1)
	--	rectfill(i+64,127,i+64,127-speed_chart[i]*30,8)
	--end	
	
	--print(stat(0),0,118,8)
	---pause(2)
	

end
