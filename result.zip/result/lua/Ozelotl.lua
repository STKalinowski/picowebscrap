-- ozelotl v1.0
-- by catzpaw
--[[

★★key assignment★★

cursor:move
[x]xv:fire
[o]zc:purge

★★mission★★

 assault enemy's
communication hubs and
gather boss' information.
 when enough information
is accumulated,head on to
the boss and defeat it!

★★weapons★★

[x]fire
rapid-fire:
  quick-fireing gun
power shell:
  slow but powerful!
wide shot:
  bullets spread forward
3way shot:
  foward and diagonally
  backward plasma balls
circular:
  rotating plasma balls
  and forward shot

[o]purge
 detach equipped weapon
and detonate for destroy
all enemies and bullets.

★★score multiplier★★

shield remains:
 99-90 1x  49-40 6x
 89-80 2x  39-30 7x
 79-70 3x  29-20 8x
 69-60 4x  19-10 9x
 59-50 5x   9-1 10x

★★★★

you can do:
★to play the game
★share screenshots and videos
★modding
 (you must change the
  cartdata name)

you cannot do:
★resell copy of the game
★diversion of the content
 (without lua source code)


(c)2019 catzpaw

]]
mdy,lbf,hss,dp,sv,ll,clc,shk,mus,si,mm,ph,fc,lpx,lpy,gh=
.2, 0,  16, 0, 0, -1,1,  0,  255,0, 1, 0, 0, 0,  0,  0
udp,   ip,udu,mi,lv,mp,mp2,sp2,msx,msy,msa,msc,sh,dco,co,w1,w2,w3=
0x4300,0, 0,  1, 1, 0, 512,1,  63, 144,0,  0,  59,0,  0, 0, 0, 0
nrc,  scm,sc1,sc2,sc3,hs1,hs2,hs3,ls1,ls2,ls3,gsp,gsa,gsc,gsn,gsw=
false,5,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0
cll,bs,fg,bg,fx,pb,en,eb,gsv,gsm={},{},{},{},{},{},{},{},{},{}
udl,udi,esl,esi,gsl,gsi,ddl,ddi,sdl,sdi,tdl={},{},{},{},{},{},{},{},{},{},{}
pt={-160.5,24415.5,24410.5,23130.5,23050.5,2570.5,2560.5,0.5,-161,24415,24410,23130,23050,2570,2560,-23130.5,-3855.5,3855.5}pt[0]=-.5

function _init()
 cartdata("czp_ozelotl")
 if dget(63)~=255 then dset(2,1)dset(3,49)dset(63,255) end
 pre()
end
function _update()
 si=max(si-1,0)
 if ph<20 then
  if ph==0 then usp()
  elseif ph==10 then utt()
  elseif ph==11 or ph==12 then ugo()
  elseif ph==13 or ph==14 then gsx()foreach(fx,ufx)
  end
 else
  if sh>0 and ph~=20 then
   gsx()
  elseif sh<-999 and fc>120 then
   wcl(4)ph,fc=11,0
   return
  end
  if ph==20 then
   if fc<30 then msy=128+sin(fc/80)*40
   else ph=22 end
  else ups()end
  if ph<30 then if ph==22 then gbs()end
  elseif ph<40 then gcl()end
  foreach(bg,ubg)foreach(fg,ufg)
  foreach(pb,upb)foreach(en,uen)
  foreach(eb,ueb)foreach(fx,ufx)
 end
 fc=band(fc+1,16383)
end
function _draw()
 camera(rnd(shk)-shk*.5,rnd(shk)-shk*.5)shk*=.3
 if ph<20 then
  if ph==0 then dsp()end
  if ph==10 then dtt()end
  if ph==11 then dgo()end
  if ph==12 then ded()end
  if ph==13 then dms()camera(0,10)pal()foreach(fx,dfx)camera()end
  if ph==14 then cls(0)end
 else
  if ph<30 then
   dst(sp2)
   cst(4)foreach(bg,dbg)
   if ph==21 then cst(2)else cst(3)end
   foreach(fg,dfg)
  elseif ph<40 then
   cst(1)mdy=.2 dmp(1)dmo(6400)
   foreach(bg,dbg)
   cst(2)foreach(fg,dfg)
  else
   cst(1)mdy=3 dmp(ph-40)dmo(6912)
   cst(2)foreach(fg,dfg)
  end
  pal()foreach(en,den)
  dps()foreach(pb,dpb)
  pal(8,8+fc%2)foreach(eb,deb)
  pal()foreach(fx,dfx)dsc()
 end
end
function esx(i)local a,d,u,v=0,0,0,0 for j=0,32 do
 local h,l=hl(peek(i.p))i.p+=1
 if h==0 then if l==0 then i.t=0 return elseif l<8 then i.m=i.p i.c=flr(l*l*.25)+l+1 elseif l==8 then i.c-=1 if i.c>0 then i.p=i.m end end
 elseif h==1 then i.a=l*.5 elseif h==2 then i.d=l*.0625 elseif h==3 then i.r=l elseif h==4 then i.n=l i.i=0 i.q=ld(960+i.r)
 elseif h<8 then if h==6 then l*=3 elseif h==7 then l=(i.h%l)*3 end i.w+=1 if i.w<l then i.p-=1 i.d=(i.d+i.b)%1 i.x+=cos(i.d)*i.a i.y+=sin(i.d)*i.a return end i.w=0 i.h=flr(hsh(i.h)*256)
 elseif h<10 then d=atan2(msx-i.x,msy-i.y) if h==9 then d+=.5 end v=(1+i.d-d)%1 u=(l+1)*.03125 if abs(v)<u or abs(v)>1-u then i.d=d elseif v<.5 then i.d-=sgn(v)*u else i.d+=sgn(v)*u end
 elseif h==10 then i.a+=l*.1 elseif h==11 then i.f=l elseif h==12 then i.b=(l-8)*.015625+1 elseif h==13 then i.a-=l*.1 elseif h==14 then i.p=esi[ld(512+i.t)]+l
 elseif h==15 then
  if l==0 then i.y=8808-mp
  elseif l==1 then i.y=40
  end
 end
end end
function igs(m)mi,gsp,gsa,gh=m,0,0,m co%=100 end
function gsx()for i=1,64 do gsc=spk(gsp)gsp+=1
 if gsc<16 then gsn=spk(gsp)gsp+=1
  if gsc==0 then gsp=gsi[mi]
  elseif gsc==1 then gsa=gsn
  elseif gsc==2 then gsw+=1 if gsw<=gsn then gsp-=2 return end gsw=0
  elseif gsc==3 then gsp+=gsn
  elseif gsc==4 then afx(gsa,gsn,5,30+band(gsa,15)*54)
  elseif gsc==5 then igs(gsn)return
  elseif gsc==6 then if gsn==0 then lv=1 end if gsn==1 then lv=max(lv-1,1)end if gsn==2 then lv=min(lv+1,3)end
  elseif gsc==7 then afg(0,-384,gsn,0)afg(0,-256,gsn+1,0)afg(0,-128,gsn+2,0)
  elseif gsc==8 then sp2=gsn
  elseif gsc==9 then ph,fc=gsn,0
  elseif gsc==10 then if gsn<=dco then for j=1,2048 do if spk(gsp)==0 and spk(gsp+1)==0 then gsp+=2 return else gsp+=1 end end end
  elseif gsc==11 then local x,y,m=64,-32,2 if gsn==7 then y=40 end if lv>1 or gsn==12 then m=4 end local b=aen(x,y,gsn) bs=b if gsn>7 and gsn<13 then ami(50+gsn,m) end
  elseif gsc==12 then if #en>0 then gsp-=2 end
  elseif gsc==13 then if gsn==255 then music(-1,1500,7)mus=255 else if mus~=gsn then music(gsn,0,7)mus=gsn end end
  elseif gsc==14 then mp,hss,dp=gsn*128,16,0
  elseif gsc==15 then
   if gsn==0 then wcl(lv)end
   if gsn==1 then msy=144 end
   if gsn==2 then se(41,1)wip()end
   if gsn==10 then co+=gsa end
  end
 else gsc,gsn=hl(gsc)
  if gsc<9 then local x,y gsc-=1 if band(gsc,1)==1 and lv<2 then return end if gsc<4 then if gsn==0 then x=ghs(112)+8 else x=gsn*10-16 end if gsc<2 then y=-16 else y=144 end else if gsn==0 then y=ghs(112)+8 else y=gsn*10-17 end if gsc<6 then x=-16 else x=144 end end aen(x,y,gsa)
  elseif gsc==9 then afx(0,0,19+gsn,gsa*3)
  elseif gsc==10 then gsv[gsn]=gsa
  elseif gsc==11 then gsv[gsn],gsm[gsn]=gsa,gsp
  elseif gsc==12 then gsv[gsn]-=1 if gsv[gsn]>0 then gsp=gsm[gsn]end
  elseif gsc==13 then se(gsn,5)
  else
   local w=gsn*3 gsw+=1
   if gsc==14 then w*=10 end
   if gsw<=w then gsp-=1 return end
   gsw=0
  end
 end
end end
-->8
--spr&map

function wpn(w)w1,w2,w3=w,w1,w2 if w1==5 and w2~=5 then apb(16,0,8,0)apb(-16,0,8,.5)end end
function apb(x,y,t,d)local i={x=msx+x,y=msy+y,t=t,d=d,a=1,c=0}if t==7 then i.a=2 end if t==8 then i.a=4 end add(pb,i)end
function upb(i)if i.t<8 then if i.y<-16 or i.y>144 or i.x<-16 or i.x>144 then i.t=10 else i.x+=cos(i.d)*ld(943+i.t)i.y+=sin(i.d)*ld(943+i.t)if pbh(i.x,i.y,i.a)then if i.t<7 then i.t=10 end se(40,0)afx(i.x,i.y,1,.25)end end elseif i.t==8 and w1==5 then i.d=(i.d+.1)%1 i.x=msx+cos(i.d)*16+1 i.y=msy+sin(i.d)*16 if pbh(i.x,i.y,i.a)then se(40,0)afx(i.x,i.y,1,.25)end else del(pb,i)end end
function dpb(i)if i.t==1 then spr(2,i.x-4,i.y-8,1,2)elseif i.t==2 then spr(4,i.x-4,i.y-8,1,2)elseif i.t==3 then spr(4,i.x-4,i.y-8,1,2,true)elseif i.t>3 and i.t<7 then spr(5,i.x-4,i.y-4)elseif i.t==7 then spr(3,i.x-4,i.y-8,1,2)elseif i.t==8 then spr(5,i.x-4+cos(i.d+.25)*4,i.y-4+sin(i.d+.25)*4)spr(6,i.x-4,i.y-4)else end end
function pbh(x,y,a)for i in all(en)do if i.s>0 and i.t>7 and abs(i.x-x)<ld(640+i.t)and abs(i.y-y)<ld(704+i.t)then i.s-=a return true end end return false end
function aeb(x,y,t,xa,ya)local a=.8+lv*.2 local i={x=x,y=y,t=t,xa=xa*a,ya=ya*a}add(eb,i)end
function ueb(i)i.x+=i.xa i.y+=i.ya local x,y,z=abs(i.x-msx),abs(i.y-msy),i.t+1 if sh>0 and x*x+y*y<z*z then se(47,5)afx(0,0,4,0)sh-=i.t del(eb,i)return end if i.x>132 or i.x<-4 or i.y>132 or i.y<-4 then del(eb,i)end end
function deb(i)spr(24-i.t,i.x-4,i.y-4)end
function afx(x,y,t,d)local i={x=x,y=y,t=t,c=0,d=d}add(fx,i)end
function ufx(i)local t=i.t
 if t==1 then i.x+=cos(i.d)*1 i.y+=sin(i.d)*1 i.c+=1 if i.c>6 then i.t=0 end
 elseif t==2 then i.x+=cos(i.d)*4 i.y+=sin(i.d)*4+i.c*.5-6 i.c+=1 if i.c>16 then i.t=0 end
 elseif t==3 then i.c+=1 if i.c>2 then i.t=0 end
 elseif t==4 then i.c+=1 if i.c>4 then i.t=0 end
 elseif t==5 then i.c+=1 if i.c>i.d then i.t=0 end
 elseif t==6 then i.x+=cos(i.d)*4 i.y+=sin(i.d)*4+i.c*.5-6 i.c+=1 if i.c>16 then i.t=0 end
 elseif t==7 then i.c+=1 if i.c>16 then shk=20 i.c=0 i.d=7 i.t=3 se(42,30)end
 elseif t==8 then i.c+=1 if i.c%2==0 then afx(i.x+rnd(64)-32,i.y+rnd(32)-24,2,.75)se(41,1)end if i.c==30 then afx(i.x,i.y,7,.75)end if i.c>43 then i.t=0 end elseif t>19 and t<27 then i.c+=1 if i.c>i.d then i.t=0 end else del(fx,i)end
end
function dfx(i)local t=i.t
 if t==1 then fpt(4)color(7+(fc%2)*5)circfill(i.x,i.y,6-i.c/2)fillp(0)
 elseif t==2 then fpt(4)color(0+(i.c%2)*8)circfill(i.x,i.y,13-i.c/2)fillp(0)color(7+((i.c+1)%4))circfill(i.x,i.y,7-i.c/3)
 elseif t==3 then cls(i.d)
 elseif t==4 then circfill(msx,msy,6,12*(i.c%2))
 elseif t==5 then local c,l,j local y=57 c,l=hl(i.x)prc(tdl[c],y,ld(951+c))y+=8 for j=1,l do prc(tdl[i.y+j-1],y,ld(951+c))y+=8 end
 elseif t==6 then fpt(4)color(0+(i.c%2)*8)circfill(i.x,i.y,26-i.c)fillp(0)color(7+((i.c+1)%4))circfill(i.x,i.y,14-i.c/1.5)
 elseif t==7 then fpt(4)color(0+(i.c%2)*10)circfill(i.x,i.y,13+i.c)fillp(0)color(7+((i.c+1)%4))circfill(i.x,i.y,16+i.c*2)
 elseif t==20 or t==21 then fpt(17+i.c%2)drw(i.t-8,0,40)drw(20+mi,82,43)drw(20+lv,77,48)
 elseif t>21 and t<27 then fpt(17+i.c%2)drw(i.t-8,0,40)
 else end
end
function ehi(i)if i.s>0 and abs(i.x-msx)<ld(640+i.t)and abs(i.y-msy)<ld(704+i.t)then local a=min(sh,i.s)se(47,5)afx(0,0,4,0)i.s-=a sh-=a end end
function eou(i)local sx,sy=ld(640+i.t),ld(704+i.t)if i.x<-sx-8 or i.x>136+sx or i.y<-sy-8 or i.y>136+sy then return true end return false end
function wip()if ph~=24 then foreach(en,des) end eb={}end
function des(i)if i.t<7 or i.t>13 then afx(i.x,i.y,2,.75)i.t=0 i.q=0 end end
function ami(t,n)local e for i=1,n do e=wir(i)e=aen(e.x,e.y,t)e.j=i end end
function wir(i)local p={}local r,a,d d=848+i*4+bs.t*16-132 r=ld(d+2)a=ld(d+3)*.0078125 p.u=bs.x+ld(d)-64 p.v=bs.y+ld(d+1)-64 p.x=p.u+cos(a)*r p.y=p.v+sin(a)*r return p end
function aen(x,y,t)local i={x=x,y=y,t=t,a=4,b=0,c=0,d=.75,f=0,m=0,w=0,i=0,q=0,r=0}i.h=ghs(256)i.p=esi[ld(512+t)]i.s=ld(576+t)add(en,i)return i end
function uen(i)local t=i.t
 if t==0 then del(en,i)
 elseif t<7 then i.y+=1 if abs(i.x-msx)<8 and abs(i.y-msy)<8 then if t==6 then se(43,5)i.t=0 sh=min(sh+10,99)else se(44,5)wpn(t)i.t=0 end end if i.y>136 then i.t=0 end
 elseif t<14 then
  if i.s<-99 then i.s-=1 if i.s<-145 then i.t=0 end
  elseif i.s<1 then i.s=-100 i.q=0 sca(t)se(45,3)wip()afx(i.x,i.y,8,.75)shk=10
  else ehi(i)esx(i) end
 elseif t<20 then if i.s<1 then i.t-=13 i.a=-.5 se(41,2)afx(i.x,i.y,2,.75)sca(t)elseif i.y<-16 then i.t=0 else if i.c==0 then i.a=2 end i.a-=.03 i.y+=i.a i.c+=1 end
 elseif t<22 then ehi(i)if i.s<1 then if t==20 then co+=20 else co+=30 end sca(t)i.t,i.q,shk=0,0,5 se(45,4)afx(i.x,i.y,6,.75)if lv>2 then i.n,i.i,i.q,i.r=14,0,1,0 end elseif eou(i)then i.t=0 i.q=0 else esx(i)end
 elseif t<52 then ehi(i)if i.s<1 then sca(t)i.t,i.q=0,0 se(41,2)afx(i.x,i.y,2,.75)if lv>2 then i.n,i.i,i.q,i.r=1,0,1,0 end elseif eou(i)then i.t,i.q=0,0 else esx(i)end
 elseif t==52 then esx(i)
 elseif t<64 then
  ehi(i)
  if i.s<1 then
   sca(t)i.t,i.q=0,0 shk=2 se(45,4)afx(i.x,i.y,6,.75)if lv>2 then i.n,i.i,i.q,i.r=14,0,1,0 end
  elseif t<58 and eou(i)then i.t,i.q=0,0
  else esx(i)
   if t>57 then
    local p=wir(i.j)
    if t==62 then i.x,i.y=p.x,p.y else i.x,i.y=i.x*.8+p.x*.2,i.y*.8+p.y*.2 end
    if bs.s<1 then i.t,i.q=0,0 afx(i.x,i.y,2,.75)end
   end
  end
 else del(en,i)return end
 t=i.r
 if i.q>0 and i.i%ld(1008+t)==0 then
  local co,si local b=i.n local n,s,e,c,a,v=ld(384+b),ld(400+b),ld(416+b),ld(432+b),ld(976+t),ld(992+t)
  if i.x>64 then v=128-v end
  if a==127 then a=atan2(msx-i.x,msy-i.y)*128 else a+=32 end i.q-=1 v-=64 if t<14 then a+=i.q*v else a+=rnd(v*2)-v end
  for j=1,n do
   local f=(a+c*(j-1)-e)/128
   si=s*.7+1.3 co=si*cos(f)si*=sin(f)
   if i.t>55 and i.t<60 then aeb(i.x-7,i.y+8,s,co,si)aeb(i.x+7,i.y+8,s,co,si)else aeb(i.x,i.y,s,co,si)end
   if b==15 then s+=1 end
  end
 end i.i+=1
end
function den(i) local t,s=i.t,ld(448+i.t)
 if s==2 then sps(2+flr(fc*.5)%4,i.x,i.y)
 elseif t>0 and t<7 then spr(6+i.t,i.x-4,i.y-4)
 elseif t>6 and t<14 then cst(5)sps(s,i.x,i.y)pal()
 elseif t>13 and t<20 then sps(s,i.x,i.y)spr(i.t-7,i.x-4,i.y-2)
 elseif t>19 then if t>57 and fc%2==0 then local p=wir(i.j)line(p.u,p.v,i.x,i.y,2)end if s==24 then s+=i.q%4 end sps(s+i.f,i.x,i.y)
 else end
end
function ups()
 if sh<1 then if sh>-999 then fc=0 music(-1)si=0 se(45,30)sh=-1000 afx(msx,msy,2,.75)afx(0,0,26,110)msy=160 end return end
 local k=band(btn(),15)local t=ld(832+k)*.125 local w
 if k>0 then
  msa=mid(1,msa+.5,3)
  if t<1 then
   msx,msy=mid(6,msx+cos(t)*msa,120),mid(6,msy+sin(t)*msa,121)
  end
 else msa,msx,msy=0,flr(msx),flr(msy)end
 msc-=1
 if msc<1 and btn(5)then if w1==0 or w1==5 then apb(-3,-4,1,.25)apb(5,-4,1,.25)msc=5
  elseif w1==1 then apb(-3,-4,1,.25) apb(5,-4,1,.25) msc=3 elseif w1==2 then apb(-3,-4,7,.25)apb(5,-4,7,.25)msc=20
  elseif w1==3 then apb(-3,-4,2,.3) apb(6,-4,3,.2) msc=3 elseif w1==4 then apb(1,-4,4,.25)apb(6,3,5,.875)apb(-3,3,6,.625)msc=3 end
 end
 if w1>0 and btnp(4)then w,w1,w2,w3=w1,w2,w3,0 afx(0,0,3,7) se(45,10) wip() if w1==5 and w~=5 then apb(16,0,8,0) apb(-16,0,8,.5)end end
end
function dps()if sh>0 then spr(0,msx-7,msy-7,2,2)end end
function sps(id,x,y)local p,n=sdi[id],#sdl[id]/6 local w,h,s,ox,oy
 for i=1,n do h=peek(p)s=band(h,63)w=1+shr(band(h,128),7)h=1+shr(band(h,64),6)ox=peek(p+1)oy=peek(p+2)p+=3 spr(s,x+band(ox,127)-64-w*4,y+band(oy,127)-64-h*4,w,h,band(ox,128)>0,band(oy,128)>0)end
end
function gcl()if rnd(10)<2 then afg(rnd(160)-16,-60,1,rnd(100)) end if rnd(10)<3 then abg(rnd(160)-16,-60,1,rnd(100))end end
function gbs()local i mp=(mp+1)%30720 if mp%16==0 then i=sbs() afg(i.x1-64,-64,2,i.c1) afg(i.x2+64,-64,2,i.c2)end if mp%32==0 then mp+=1 i=sbs() mp-=1 abg(i.x1-64,-64,2,i.c1) abg(i.x2+64,-64,2,i.c2) end end
function sbs()local i={x1,x2,c1,c2} local h=hsh(mp/4000) i.x1=flr(h*8)*16 if i.x1>64 then i.x1=64 end h=hsh(h) i.c1=flr(h*16)h=hsh(h)
 if h>.5 then i.x2=64-i.x1 i.c2=i.c1 if i.c2>11 then i.c2=((i.c2+2)%4)+12 end
 else h=hsh(h)i.x2=flr(h*8)*16 if i.x2>64 then i.x2=0 end h=hsh(h) i.c2=flr(h*16) h=hsh(h) if h>.5 then if i.x1<64 then i.x2=i.x1-64 end if i.x2>0 then i.x1=i.x2+64 end end
 end return i
end
function afg(x,y,t,c)local i={x=x,y=y,t=t,c=c}add(fg,i)end
function abg(x,y,t,c)local i={x=x,y=y,t=t,c=c}add(bg,i)end
function ufg(i)if i.t==1 then i.y+=14 if i.y>200 then i.t=0 end elseif i.t==2 then i.y+=3 if i.y>127 then i.t=0 end elseif i.t>5 and i.t<12 then i.y+=sp2 if i.y>127 then i.t=0 end else del(fg,i)end end
function ubg(i)if i.t==1 then i.y+=10 if i.y>200 then i.t=0 end elseif i.t==2 then i.y+=2 if i.y>127 then i.t=0 end else del(bg,i)end end
function dfg(i)local h,x,y,r
 if i.t==1 then h=hsh(i.c)r=20+h*10 color(6)fpt(4)circfill(i.x,i.y,r)fillp(0)
  if r>20 then r*=.7 circfill(i.x,i.y,r)circfill(i.x+cos(h)*r,i.y+sin(h)*r,10+hsh(h)*5)h=hsh(h)circfill(i.x+cos(h)*r,i.y+sin(h)*r,10+hsh(h)*5)end
 elseif i.t==2 then x=(i.c%4)*8+96 y=flr(i.c*.25)*8 map(x,y,i.x,i.y,8,8)
 elseif i.t>5 and i.t<12 then drw(i.t,i.x,i.y)
 else end
end
function dbg(i)if i.t==1 then h=hsh(i.c)r=20+h*10 color(6)fpt(4)circfill(i.x,i.y,r)fillp(0)elseif i.t==2 then x=(i.c%4)*8+96 y=flr(i.c*.25)*8 map(x,y,i.x,i.y,8,8)end end
function dst(s)cls(0)local y,h mp2=(mp2+s)%1024 for i=0,127 do h=hsh((mp2+1024-i)%1024)color(1+flr(h*200%2)*5)pset(h*128,i)end end
function dmp(s)
 s=mid(0,s,8)if hss>0 then s=8 hss-=1 end sv+=s s=flr(sv) sv-=s
 mp=(16384-s+mp)%16384 dp=(144-s+dp)%144
 local l,d=flr(mp*.125),flr(dp*.125)
 if l~=ll then
  for i=0,17 do
   local a=lbf+i
   poke(a+36,peek(a+18))
   poke(a+18,peek(a))
   poke(a,flr(fbm(i+111,l)*14.5)+3)
  end
  local f,h=fget(flr(l*.125)),band(flr(l*.25),1)*4
  for i=0,15 do
   local t=h+flr(i*.25)
   if band(shr(f,t),1)==0 then
    local b=lbf+i t=gett(b,8)
   	if t==0 then t=gett(b,7)end
   	if t==0 then t=gett(b,6)end
   	if t==0 then t=93 end
   	if t>252 and hsh(i*l+51)>.3 then
   	 t=peek(6192+flr(hsh(i*l+l)*16))
    end
   else
    if peek(lbf+i+18)>8 then t=84 else t=94 end
    poke(lbf+i+19,8)
   end
   mset(i,d,t)
  end
 end
 ll=l l=dp%8
 map(0,d,0,-l,16,18-d)
 map(0,0,0,(18-d)*8-l,16,d)
 d=(d+1)%18
end
function gett(x,y)local t=0
 if peek(x+19)<=y then return 0 end
 if peek(x+18)>y then t+=8 end
 if peek(x+37)>y then t+=4 end
 if peek(x+20)>y then t+=2 end
 if peek(x+1)>y then t+=1 end
 return peek(6048+t+y*16)
end
function dmo(b)
 for j=0,4 do
  local f=band(flr(shr(mp,6))+255+j,255)
  for i=0,1 do
   local a=f*4+i*2
   local o=peek(a+b)
   if o<64 then
    local x,y=hl(peek(a+b+1))
    a=6208+o*3
    local u,v=peek(a),peek(a+1) 
    local w,h=hl(peek(a+2))
    x=x*8-16
    y=y*8-96+j*64-band(mp,63)
    map(u,v,x,y,w+1,h+1)
   end
  end
 end
end
function dms()
 pal(5,2)pal(6,14)pal(11,3+(fc%2)*8)
 map(80,0,0,0,16,16)rectfill(24,76,24,88,11)
 for i=0,10 do pal(6,1+flr(((fc+i)%7)/6)*11)local y=84+i*4 spr(101,48,y)spr(101,72,y)end
 msy-=(msy-88)*.02 pst(21)sps(37,65,76)sps(1,65,msy+2)
 pst(17)sps(37,64,74)sps(1,64,msy)
end
-->8
--utils&ui

function pre()
 local b=""for i=1,#td do local s=sub(td,i,i)if s=="|"then add(tdl,b)b=""else b=b..s end end
 for s in all(esl)do add(esi,udp)dec(s)end for s in all(sdl)do add(sdi,udp)dec(s)end lbf=udp udp+=54
end
function ttl()
 fg,bg,fx,pb,en,eb={},{},{},{},{},{}
 nrc,  mp,  hss,dp,fc,ph,msx,mi,     sh,     hs1,    hs2,    hs3=
 false,3616,13, 0, 0, 10,63, dget(2),dget(3),dget(4),dget(5),dget(6)
end
function utt()
 if btnp(0)then se(46,0)sh-=10 end
 if btnp(1)then se(46,0)sh+=10 end
 sh=mid(9,sh,99)scm=10-flr(sh*.1)
 if btnp(2)then se(46,0)mi+=1 end
 if btnp(3)then se(46,0)mi-=1 end
 mi=mid(1,mi,4)
 if btnp(5)then
  sp2,sc1,sc2,sc3,co,dco,lv,ph,fc,gh,w1,w2,w3=
  3,  scm,0,  0,  0, 0,  1, 20,0, mi,0, 0, 0
  if mi==1 then music(0,0,7)mus=1 else sfx(44,0)mus=255 end
  dset(2,mi)dset(3,sh)igs(mi)bs.s=0
  cll={0,0,0,0,0,0,0,0}clc=mi*2-1
 end
end
function dtt()
 cst(1)mdy=.2 dmp(.5)dmo(6400) if hss>0 then rectfill(0,0,127,127,1)end
 pal()drw(5,0,0)
 color(0)drw(3,17,25)
 if(flr(rnd(16))<1)then color(8)drw(4,16,25)color(12)drw(4,18,25)color(6)drw(4,17,25)
 else color(7)drw(4,17,25)end
 prc("hiscore "..ssc(hs3,hs2,hs1),74,12)prc("        .  .  .",75,12)
 prc("mission \x83    \x94  ",82,7)prc("shield  \x8b    \x91  ",90,7)
 prb(mi,78,82,7)prc("        "..sh,90,7)prc("score multiplier x"..scm,98,10)
 prc("\x97start ",106,7)prc("(c)2019 catzpaw",115,14)
end
function dcl(y)local b=" "
 for i=1,8 do local a=cll[i]+1 b=b..sub("-123x",a,a) if i%2==0 then b=b.." "end end
 prc(b,y,7)prc("score "..ssc(sc3,sc2,sc1),y+12,12) if nrc then prc("- new record -",y+20,8)end
 prc("       .  .  . ",y+13,12)prc("\x97ok ",115,7)
end
function csc()
 local r=false if hs3<sc3 then r=true
 elseif hs3==sc3 and hs2<sc2 then r=true
 elseif hs3==sc3 and hs2==sc2 and hs1<sc1 then r=true end
 if r then hs1,hs2,hs3=sc1,sc2,sc3 dset(4,hs1)dset(5,hs2)dset(6,hs3)end
 return r
end
function ugo()if fc==1 then nrc=csc()end if fc>10 and btnp(5)then music(-1,1500,7)mus=255 ttl()end end
function dgo()pal()dst(-1)rectfill(0,41,127,43,9)prc("g a m e  o v e r",40,7)dcl(70)end
function ded()pal()dst(0)drw(6,0,0)color(9)drw(3,17,25)color(0)drw(4,17,25)dcl(56)prc("thank you for playing!",106,10)prc("(c)2019 catzpaw",97,14)end
function sca(p)local sc=ld(768+p)*50 for i=1,scm do sc1+=sc if(sc1>9999)then sc2+=flr(sc1/10000)sc1%=10000 end if(sc2>9999)then sc3+=flr(sc2/10000)sc2%=10000 end end end
function ssc(s3,s2,s1)local ss3,ss2,ss1="0000"..s3,"0000"..s2,"0000"..s1 return sub(ss3,#ss3-3,#ss3)..sub(ss2,#ss2-3,#ss2)..sub(ss1,#ss1-3,#ss1)end
function dsc()if dco~=co then dco+=sgn(co-dco)end scs=ssc(sc3,sc2,sc1)sco=flr(dco).."%" ssh=""..max(sh,0) spr(13,1,1)prb(scs,10,3,7)prb(".  .  .",20,4,7)spr(14,59,1)prb(sco,68,3,7)spr(15,85,1)prb(ssh,94,3,7)local w=w1 if w>0 then spr(6+w,103,1)end pal(14,2)w=w2 if w>0 then spr(6+w,111,1)end w=w3 if w>0 then spr(6+w,119,1)end pal(14,14)end
function usp()if fc>70 then ttl()end end
function dsp()cls(0)if fc>10 and fc<60 then cls(14)drw(1,49,40)drw(2,32,75)end end
function dec(p)for i=1,#p,2 do poke(udp,h2i(p,i))udp+=1 end end
function h2i(x,y)return tonum("0x"..sub(x,y,y+1))end
function spk(p)return h2i(gsl[mi],p*2+1)end
function ld(p)return peek(16064+shr(band(p,16320),6)*68+band(p,63))end
function se(x,y)if si==0 or x==47 then sfx(x,3)si=y end end
function wcl(l)cll[clc]=l clc+=1 end
function fpt(p)fillp(pt[p])end
function cst(p)p=p*64+mi*16-80 for i=0,15 do pal(i,ld(p+i))end pal(8,ld(352+fc%32))end
function pst(p)p*=16 for i=0,15 do pal(i,ld(p+i))end end
function sb(p)local b=peek(p)if b>127 then b=-band(b,127)end return b end
function hl(p)return shr(band(p,240),4),band(p,15)end
function hsh(p)return band(sin(p*337.313)*341.131,0x.ffff)end
function vns(x,y)local a,b=flr(x),flr(y)x-=a y-=b a+=b*2 x*=x*(3-2*x)y*=y*(3-2*y)return (hsh(a)*(1-x)+hsh(a+1)*x)*(1-y)+(hsh(a+2)*(1-x)+hsh(a+3)*x)*y end
function fbm(x,y)return max(vns(x*.07,y*.08)*.4+vns(x*.14,y*.14)*.4+cos(y*.001)*mdy,0)end
function ghs(p)gh=hsh(gh)return flr(gh*p)end
function prb(s,x,y,c)color(0)print(s,x-1,y)print(s,x+1,y)print(s,x,y-1)print(s,x,y+1)print(s,x,y,c)end
function prc(s,y,c)prb(s,64-#s*2,y,c)end
function drw(s,x,y)local ox,oy,lx,ly,c,b,p=x,y,x,y,0,0,peek2(0xffe+s*2)local h,l,g,w
 for i=1,999 do h,l=hl(peek(p))p+=1 local x,y=lx,ly
  if h==0 then if l==0 then return elseif l==1 then lx=ox elseif l==2 then ly=oy elseif l==3 then lx,ly=ox,oy
   elseif l==4 then g=peek(p)p+=1 for i=0,g do w=peek(p)p+=1 if band(w,16)>0 then pset(x,y)end if band(w,32)>0 then pset(x,y+1)end if band(w,64)>0 then pset(x,y+2)end if band(w,128)>0 then pset(x,y+3)end x+=1 if band(w,1)>0 then pset(x,y)end if band(w,2)>0 then pset(x,y+1)end if band(w,4)>0 then pset(x,y+2)end if band(w,8)>0 then pset(x,y+3)end x+=1 end ly+=4 end
  elseif h==8 then circfill(lx,ly,l*2)elseif h==9 then rectfill(lx,ly,lx+peek(p),ly+l)p+=1 ly+=l+1
  elseif h==4 then for j=0,l do g,w=hl(peek(p))p+=1 x+=g rectfill(x,y,x+w,y)x+=w+1 end ly+=1
  elseif h==5 then for j=0,l do g,w=hl(peek(p))p+=1 x+=g rectfill(x,y,x+w,y+1)x+=w+1 end ly+=2
  elseif h==6 then g,w=peek(p),peek(p+1)p+=2 for j=0,l do x=(g*(l-j)+w*j)/l rectfill(lx,y,x,y) y+=1 end ly+=l+1
  elseif h==7 then g=peek(p)p+=1 for j=0,l do x=sin(j/(l*2))*g-2.5 rectfill(lx-x,y,lx+x,y)y+=1 end
  elseif h==10 then for j=0,l do x,y=hl(peek(p))g,w=hl(peek(p+1))p+=2 rectfill(x+lx,y+ly,g+lx,w+ly)end
  elseif h==11 then for j=0,l do x,y=hl(peek(p))p+=1 pset(x+lx,y+ly)end
  elseif h==12 then lx+=l elseif h==13 then lx+=(l-8)*8 elseif h==14 then ly+=l elseif h==15 then ly+=(l-8)*8
  elseif h==1 then c=l color(c+b*16)elseif h==2 then b=l color(c+b*16)elseif h==3 then fpt(l)
  else return end
 end
end
-->8
--data

gsl={
"091708010d010e0f01110409e2011491e109160121040ae301ffb101ffa1010e15010f1be40102b2011e250108b3012f1df2c3e2011e2b0108b3012e13f2c3e2c2e20108b301212d1bf2c3e20108b301212315f2c3e20102b20106b3012110f320f4c30106b3012110f120f110f120f1c3c2e4010ab3011c121ef4121e011628f4c3011493e10104b30116222ef4c30114180106b30116121e242ce1c3e20a28010e1501111be40108b3012e"
.."12012f1ef6012e12012f1ef3011e242cf3c3e30136252b0106b3011613f228f3c30106b301161df228f3c3e20107b301203cf44ef434f442f4c3e30119b3011c10f120f1c3e1011493e3011e222ee1011418e10104b3011e121ee1242ce1c30a2801210413e301110414e301210415e106020114920278c100000111040be1011495e20121040c0917e3091508040709e20e0a091ee30121040de30121040ee30111040fe301210410e301110411e10601011492"
.."e201210412011318f40f0001ffb101ffa101101501121be40103b3012f1e1d1cf32e2d2cf3c3e30103b3012e141312f3242322f3c3e40102b3011a131df8252bf81719f8c3e60108b3011e1416f31a1cf32426f32a2cf3c3e40104b3012030f640f6c30114930278011518011eb3013010f120f110f120f1c30a64010f1501101be40119b3011c10f120f1c3e2010ab30116131df4232df4c3e20137242c011e"
.."b3013010f120f1013010f120f1c3010ab3011c10f120f10116131df2011c10f120f10116252bf2c3e401149302780121141cf9011518010cb30121141c013020f320f320f3c30a6401210413e301110414e301210415e106020114920278c1000001110416e1011495e20121041708040706e20915e308010917e1013104180dffe20d0d011494e10b080c000dff01010f0a01210419e1011496e20111041ae30f0005020001"
,"091708010d010e50e2011491e10916e3011318f4060101ffb101ffa1011115010e1be40103b3011e141ce128e1c3e20102b30121131de1232de1011a18e128e1c3e40102b20104b3012110f120f1012c5df3c30104b3012110f120f4c30104b3012110f120f1012d7df3c30104b3012110f120f4c3c2e2010cb3011610f320f3c3e3011493e10104b30121222ef4c30114180106b30121121e242ce1c3e20a28010e1501111be4"
.."0102b20104b3011c10f120f1012c5df3c30104b3011c10f120f4c30104b3011c10f120f1012d7df3c30104b3011c10f120f4c3c2e4013815281bea0102b2011e14232d1c0106b3012e18f2012f18f2c3c2e30106b2012230f140f10103b3011c10f120f1c3c2e3011493e3011e222ee1011418e10103b3011e121ee2242ce2c30a2801210413e301110414e301210415e106020114920278c100000111040be1011495e20121040c0917e3"
.."091508040709e20e28091ee30121041be30111041ce301110411e10601011492e20121041d011318f40f0001ffb101ffa101101501121be40102b20104b3012812f401292cf4c30104b301291ef4012824f4c3c2e4010ab3011a15220106b2011c10f120f1c2c3e40110b3012118f210f120f1c3e4010cb301281401292c012d7df28df27df28df2c3e40114930278011518010cb301291cf3012814f301292cf3012824f3c30a6401111501121be4010ab3"
.."011e10f420f4012030f440f4c3e40104b20103b3012030f140f140f1c3e2c2e2010ab3011a1b2e0106b2011c10f120f1c2c3e4010cb3011c1020012d7df28df2011c1020012d7df28df2c3e40114930278011518010cb30117343cf4434df4424ef4c30a6401210413e301110414e301210415e106020114920278c1000001110416e1011495e20121042508040706e20915e308010917e10141041e0dffe20d0d011494e10b090c000dff01010f0a01210419e1"
.."011496e20111041fe30f0005030001"
,"091708010d010e3ce2011491e10916e3011318f4060101ffb101ffa1010f1401121ce40102b2011a1d230106b3012e15f2c3e3011a132d0106b3012f1bf2c3e3c2e20103b20123151b0106b301161719f3232df3c3c2e40103b30123131517191b1de2012720e2c30104b30123131517191b1df7c3e6011493e10123232527292b2de1011418e10123131517191b1de90a28010f1501111be40107b301211425f2c30107b30121"
.."1627f2c30107b301211a29f2c30107b301211c2bf2c3e5013915281bea0106b2011a100108b3011d10f220f2c3c2e50106b20120333df240f20102b3012118f8c3c2e4011493e3011418010ab30120323ef6444cf6c30a2801210413e301110414e301210415e106020114920278c100000111040be1011495e20121040c0917e3091508040709e20e51091ee301210420e301110421e301210422e301220423e501110411e10601011492e20121041d011318f40f0001ff"
.."b101ffa101101501121be40103b3012718e1141ce1444ce1c3e40114b3011610011740f4c3e40102b20126737577797b7d010ab3012e1325f3012f1d2bf3c3c2e40102b20125535557595b5d0105b30116131df60117434df6c3c2e401149302780115180112b3011d10f220f2c3e20a64010e14010f1ce40104b2012718480104b3011f1523f81b2df8c3c2e40106b2011a100108b3011d10f220f2c3c2e50102b20123"
.."131517191b1df30105b3012a54f2c3e20123131517191b1df30105b3012b74f2c3e2c2e50107b301211c2b013010f2c30107b301211a29013010f2c30107b301211627013010f2c30107b301211425013010f2c3e501149302780115180108b2011f10f2200104b3013010f2c3c2e20a6401210413e301110414e301210415e106020114920278c1000001110416e1011495e20121042508040706e20915e308010917e1015104260dffe20d0d011494e10b0a"
.."0c000dff01010f0a01210427e1011496e201110428e30f0005040001"
,"091708010d010e28e2011491e10916e3011318f4060101ffb101ffa1010e1501101be40104b3011b16281afa011b14281cfac3e40104b30118526456685a0119728476887ae2c3e40108b2011f10f2200106b3011d151bf2c3e1c2e30102b20127537367870104b30121161afa262afac3c2e5011493e10114180108b3011b10f6c3e50a28010f1501111be4010eb3012110f620011730f6c3e5013515281bea0102b201275373"
.."67870104b3011b161afc262afcc3c2e30102b20104b3f701231317191dc30107b30121151bf2252bf2c3e3c2e2011493e30114180110b3012c5d012d7df2012c6d012d8df2c3e40a2801210413e301110414e301210415e106020114920278c100000111040be1011495e20121040c0917e3091508040709e20e64091ee301120429e50122042be50111042de301110411e30601011492e20121041d011318f40f0001ffb101ffa1010e1501101be40108b3013110e120e1"
.."c3e50103b20123121e0124343c0104b30118546601197486fcc3c2e30102b201243739e10105b301281301292df3c3e20105b301291d012823f3c3e2c2e30103b2012433383de10105b3012a53f2012b75f2012a67f2c3e2c2e301149302780115180124353b0104b3011a131df828f8c3e50a64010e1501121be40102b2012554585c012674787c0104b30120333d012128f6012118f6c3e2c2e20108b2013110f3200104b30130"
.."10f2c3c2e40103b2012554585c012674787ce10105b3012a53f2012b75f2012a67f2c3e2c2e30103b2012554585c012674787ce10103b3011b10f3012110f320f3c3e2c2e301149302780115180124353b0104b3011b131df828f8c3e50a6401210413e301110414e301210415e106020114920278c1000001110416e1011495e20121041708040706e20915e308010917e10161042e0dffe20d0d011494e10b0b0c000dff01010f0a01210419e10a68011496e201120442"
.."e50f00090ee1090be100000f00e40111042fe30114950d0e01110430e30121040ce10917e3091508040709e20e56092ce301210431e301110432e3011318f4010e13010f1df801101501111bf4011318f4e501710433f50b0cf5011494e1092af20929f209280c00010718e301210434e30929f2092af2092c01110435e308040706092af10929f101210415e20dff0915e308010917e10d27011494e10b0d0c000918013418e201810436e301210437e301810438e301130439e70183043ce70121043fe401810440e20dff"
.."09170f0201600f0ae401210441e50d0f01149601120442e50121040ae30802f30803f30804f30805e3090ee10f01090de601120444e501130446e701210449e30112044ae50121044ce6090ee1090ce10001"
}

sdl={
"c04040"
,"334444333c4433443c333c3c224040"
,"334245333b4233453e333e3b224040"
,"334045333b4033454033403b224040"
,"334542333e4533423b333b3e224040"
,"363bc23645c22e40423e40bc"
,"2e403f25453e25bb3e3e4044"
,"3540453444bd343cbd3f4040"
,"2f4043344541343b413f403d"
,"2b39be2bc7be2e403f3f4043"
,"2240423c45433cbb4329c43d293c3d3e40bb"
,"2240433c46433cba4329c43d293c3d3e40bb"
,"2240443c48433cb84329c43d293c3d3e40bb"
,"26473c26474426393c263944224040"
,"25473b2547c525b93b253945224040"
,"24c547243b4724453924bb39224040"
,"234447233c47234439233c39224040"
,"3445c4343bc434453c343b3c224040"
,"24444324bc432d45bd2d3bbd3e4040"
,"2b3c442b3cbc2bc4442bc4bc2e40c0"
,"2f404024474124b9412bc7bc2b39bc2d4039"
,"29c4c2293cc23e404b3f4044abcd3cab333c3d403c"
,"3540472e393d2e473dbbcdbfbb33bf3e40573f40503f404aabcf3aab313a2d40373d403f"
,"324545323b4532453b323b3b224040"
,"324346323a4332463d323d3a224040"
,"324047323940324740324039224040"
,"324643323d4632433a323a3d224040"
,"3e40ab2d52352dae35abda38ab26382a52472a2e472a5a3d2a263d3f40313a4436393c363bc8b33b38b329c4bd293cbd29c435293c3522403d2e483e2e383e364b38363538e7523fe72e3fe04043"
,"b740ceb0494db0b74d2644cd2a5b3eabddbb2a253eab23bb2a52452a2e45263ccd264ccc2634cc29c4c3293cc32a40352240c32e4844364cc62e38443634c63644c7363cc7e7503de7303de0403b"
,"29373129c9312a47b72a39b73e40a83e485335484f3e385335b84febd336eb2d362e47c82a4a442e39c82a36443f4033b74044293cc629c4c6224046ebd4c5eb2cc53540303849bd3737bde0403e"
,"e75a35abe03be7a635b75942ab1f3bb7a742e052c5e02ec56e52482a553b2a4e3c6e2e482a2b3b3540442a323cab4fb7abb1b729c7c52939c5abde34ab22342e483e2e383e223a3d22c63de04038"
,"6d51cd6d2fcd6d2f336d5133e740b6e7404a9c4f409e3140ab2b46abd546abd5bae040402e44b42a4a482a36482a4ab82a36b82e3cb4ab2bba29c5c5293bc529c53b293b3b2240402e444c2e3c4c"
,"e740b6e7404a29cec8e040402a4a482a36482a4ab82a36b829b7392e4a402e37c02e444c29c5c5293bc529c53b293b3b2240402948c829b6462ebcb42e3c4c294aba2e44b429b4c529cf3e29313c"
,"35b946354746ab383fabc83f6e404134403a"
,"9c40c122403ebb46bbbbbabb6f47436f3943"
,"e0404029c5c5293bc529c53b293b3b224040"
,"410c90411c98406498407490410ca0411ca84074a0410cb0411cb84064b84074b0410cc04064c84074c0410cd0411cd84064d84074d0410ce0411ce84074e0"
,"31444431bc443144bc31bcbc2e4040"
,"29c5c4293bc42c443c2cbc3c3e403f"
}

td="[tepeyollotl cdc]|[jaguar3]|[tlecuezalotl]|[tlapetlanillotl]|[teoatl]|[tonaltzintli]|[tlalloliniliztli]|[tlaltecuhtli]|"
.."jaguar3, cleared to engage.|roger.|head on to the next target.|roger, jaguar3 descent.|forests and...huge facilities.|they look like factories.|is anyone there?|negative. it's unmanned.|jaguar3, enemies in sight.|engaging.|lost target.|beware of reinforcements.|copy.|jaguar3, the target detected.|roger, jaguar3 go up.|"
.."who are you?|target destroyed.|great. let's go the next.|the sunset...wow.|oh...i can't see from here.|jaguar3 engage.|did you come from the space?|ok. we came half.|"
.."where's the night view of rio?|the mankind cities have gone.|a flock of bats on the radar.|animals are often seen,|but no human.|roger, jaguar3 ascent.|are you human?|bagged one.|awsome. next is the last one.|"
.."jaguar3, airtight is losing.|what's up?|i tried to ventilate.|nice air. sweet!|come on...|welcome back, human.|jaguar3, mission update.|enemy's base detected.|attack on the enemy base.|good luck.|"
.."look at our achievements.|the target ran away.|jaguar3, chase it.|i carried out your order.|save the nature of the earth.|yes, it is.|it's our mistake that|didn't include humanity|in the definition of nature.|"
.."i was a little lonely because|there was no one to report|the results for 364 years.|you did it...excellent.|thank you.|my pleasure.|jaguar3, mission is over.|return to the carrier.|"
.."welcome back...|is what i'd like to say...|but you have to wait to|raise a toast till your|medical checkup is over.|huh? why?|you breathed the air of|the earth...you ventilated.|aieee! i screwed up...|"

esl={
"6510654216078162086f6f00"
,"1301654f6808156f6f00"
,"188001654468086f6f00"
,"16b004a161084a07a161086f00"
,"12240268420807a1610800"
,"1477426f426f6f00"
,"1707d161081104419f650807d2620800"
,"1707d161081104479f650807d2620800"
,"1606d1610810304252024664081220681034436812286810304252024664081228681034436812206810e6"
,"1507d161081064324f6a6a6a2c166610682412663f45666610e6"
,"1606d1610810206a324218c75858c8106a34436a324218c75858c8106a3e456a324218c75858c8106a3e436a324218c75858c8106a3749e7"
,"1605d16108102c04136210354d5d344c5d082430041362104852495808e6"
,"1007f052f052f052f05208100235496834426808023e4f6808eb"
,"162c06d1610810043a4b643b4b6408023c4a68304e3d4a6f304e0868043d4564304c533c4564304c530868033e4f683f4f680868e6"
,"106fb161b26633426fb161b06fe1"
,"201a66c9065908c86f00"
,"281a66c7065908c86f00"
,"2c1868cc59c865c459c86f00"
,"2c1868c459c865cc59c86f00"
,"b30652d10811b261b161b0076f0800"
,"200752d208b161b261b3116f106f2c07a252086f6f00"
,"280752d208b161b261b3116f106f2c07a252086f6f00"
,"24b30655d3082c11b261b161b0076f0800"
,"24b36f6f00"
,"05168f642144139f64086f6f00"
,"162c633341ca05a25208c605d2520841c605a25208ca05d25208e400"
,"162c633341c605a25208ca05d2520841ca05a25208c605d25208e400"
,"1520c752c86332426f6f00"
,"1528c952c86332426f6f00"
,"246410654416078162086f6f00"
,"206310654416078162086f6f00"
,"286310654416078162086f6f00"
,"156511024761426a08156f6f00"
,"18806433416f6f00"
,"1365324a6f6f6f00"
,"6410046437426408146f6f00"
,"6410016437446c446c3f416708146f6f00"
,"641001103245686868374a686808146f6f00"
,"61110466b161b26633426fb161b06f08146f6f00"
,"661002643c416f3442683d416f34426808146f6f00"
,"106f6637426fe2"
,"106f6637446f446f6f663f4167e2"
,"106f6f3245686868374a6868e2"
,"106f6f013c416f3442683d416f3442680802354b6808e3"
,"f0102407a261086f6f00"
,"f1106fe2"
,"1a6f6f00"
,"1467761068354a6f32426f6f9f146f6f00"
}
