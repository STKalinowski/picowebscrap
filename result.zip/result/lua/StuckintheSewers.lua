--stuck in the sewers
--by julio maass and bonevolt

cartdata("stuck_in_the_sewers")

poke(0x5f5c, 255)

function _init()
 heartcolor=0
 endingmessage=0
 charmax=dget(20)
 showtimer=dget(30)
 changechar=false
 char=0
 textcolor=0
 pipelist={}
 mousebestclock=dget(0)
 mousebestminute=dget(1)
 mousebeststeps=dget(2)
 mousebestclock100=dget(3)
 mousebestminute100=dget(4)
 mousebeststeps100=dget(5)
 
 girlbestclock=dget(6)
 girlbestminute=dget(7)
 girlbeststeps=dget(8)
 girlbestclock100=dget(9)
 girlbestminute100=dget(10)
 girlbeststeps100=dget(11)
 
 icebestclock=dget(12)
 icebestminute=dget(13)
 icebeststeps=dget(14)
 icebestclock100=dget(15)
 icebestminute100=dget(16)
 icebeststeps100=dget(17)

 if charmax>0 then
  mset(6,0,25)
  mset(9,0,25)
  mset(6,1,25)
  mset(9,1,25)
  mset(6,2,21)
  mset(9,2,21)
 end
	
	savesteps=0
	saveminutes=0
	saveclock=0
	savetrigger=false
	steps=0
 startclock=false
 dt=0
 clock=0
	minutes=0
 level=0//16
 playerx=8
 playery=24
 sprite=1
 fliped=true 
 freezefeet=false
 coins=0
 levelx=0
 levely=0
 tim=0
 dx1=0
 dy1=0
 music(1)
 scr_frame=0
end

function _update()
 if btnp(⬆️) and (playerx==48 or playerx==72) and playery==24 then 
  changechar=true
 end
 if playerx==144 and playery==312 and savetrigger==false then
  savetrigger=true
 	savesteps=steps
 	saveminutes=minutes
 	saveclock=clock
 	
 	if char==0 then
	  if mousebeststeps == 0 
	   or savesteps<mousebeststeps then 
	    mousebeststeps=savesteps 
	  end
	  if (mousebeststeps100 == 0 
	   or savesteps<mousebeststeps100) 
	   and coins==100 
	  then mousebeststeps100=savesteps 
	  end
	  if (mousebestclock == 0 
	   and mousebestminute == 0)
	   or (saveminutes < mousebestminute)
	   or (saveminutes == mousebestminute
	   and saveclock < mousebestclock)
	  then mousebestclock=saveclock
	   mousebestminute=saveminutes
	  end
	  if ((mousebestclock100 == 0 
	   and mousebestminute100 == 0)
	   or (saveminutes < mousebestminute100)
	   or (saveminutes == mousebestminute100
	   and saveclock < mousebestclock100))
	   and coins==100
	  then mousebestclock100=saveclock
	   mousebestminute100=saveminutes
	  end
  end
  
	dset(0,mousebestclock)
	dset(1,mousebestminute)
	dset(2,mousebeststeps)
	dset(3,mousebestclock100)
	dset(4,mousebestminute100)
	dset(5,mousebeststeps100)

 	if char==1 then
	  if girlbeststeps == 0 
	   or savesteps<girlbeststeps then 
	    girlbeststeps=savesteps 
	  end
	  if (girlbeststeps100 == 0 
	   or savesteps<girlbeststeps100) 
	   and coins==100 
	  then girlbeststeps100=savesteps 
	  end
	  if (girlbestclock == 0 
	   and girlbestminute == 0)
	   or (saveminutes < girlbestminute)
	   or (saveminutes == girlbestminute
	   and saveclock < girlbestclock)
	  then girlbestclock=saveclock
	   girlbestminute=saveminutes
	  end
	  if ((girlbestclock100 == 0 
	   and girlbestminute100 == 0)
	   or (saveminutes < girlbestminute100)
	   or (saveminutes == girlbestminute100
	   and saveclock < girlbestclock100))
	   and coins==100
	  then girlbestclock100=saveclock
	   girlbestminute100=saveminutes
	  end
  end
  
	dset(6,girlbestclock)
	dset(7,girlbestminute)
	dset(8,girlbeststeps)
	dset(9,girlbestclock100)
	dset(10,girlbestminute100)
	dset(11,girlbeststeps100)

 	if char==2 then
	  if icebeststeps == 0 
	   or savesteps<icebeststeps then 
	    icebeststeps=savesteps 
	  end
	  if (icebeststeps100 == 0 
	   or savesteps<icebeststeps100) 
	   and coins==100 
	  then icebeststeps100=savesteps 
	  end
	  if (icebestclock == 0 
	   and icebestminute == 0)
	   or (saveminutes < icebestminute)
	   or (saveminutes == icebestminute
	   and saveclock < icebestclock)
	  then icebestclock=saveclock
	   icebestminute=saveminutes
	  end
	  if ((icebestclock100 == 0 
	   and icebestminute100 == 0)
	   or (saveminutes < icebestminute100)
	   or (saveminutes == icebestminute100
	   and saveclock < icebestclock100))
	   and coins==100
	  then icebestclock100=saveclock
	   icebestminute100=saveminutes
	  end
  end
  
	dset(12,icebestclock)
	dset(13,icebestminute)
	dset(14,icebeststeps)
	dset(15,icebestclock100)
	dset(16,icebestminute100)
	dset(17,icebeststeps100)


 end
 if level>0 then
		if btn(0) or btn(1) or btn(2) or btn(3) then
			startclock=true
		end
	 if steps>9999 then steps=9999 end
 	if	startclock==true then
   dt+=1
   if dt%3==0 then clock+=1 end
 		if clock==600 then
 		 minutes+=1
    clock=0
 		end
  end
 end
 tim+=1
 if btnp(⬆️) and not fget(mget(playerx/8,playery/8-1),0) and not fget(mget(playerx/8,playery/8-1),7) then playery-=8 sprite=2 dy1=-1 sfx(1) steps+=1 end
 if btnp(⬇️) and not fget(mget(playerx/8,playery/8+1),0) and not fget(mget(playerx/8,playery/8+1),7) then playery+=8 sprite=1 dy1= 1 sfx(1) steps+=1 end
 if btnp(⬅️) and not fget(mget(playerx/8-1,playery/8),0) and not fget(mget(playerx/8-1,playery/8),6) then playerx-=8 sprite=1 dx1=-1 sfx(1) steps+=1 fliped=false end
 if btnp(➡️) and not fget(mget(playerx/8+1,playery/8),0) and not fget(mget(playerx/8+1,playery/8),6) then playerx+=8 sprite=1 dx1= 1 sfx(1) steps+=1 fliped=true end
 --if btnp(❎) then nextlevel(1) end
 
 if level == 0 then steps = 0 end
 
 function fade()
	 for i=0,20 do
	  for n=0,7 do
	  circ(old_playerx%128+4,old_playery%128+4,160-i*8+n,0)
	  circ(old_playerx%128+4,old_playery%128+3,160-i*8+n,0)
	  end
	  flip()
	 end
	 scr_frame=1
 end
 
 function nextlevel(n)
	 level+=n
  if level==17 then music(18) end
	 levelx=level%8
	 levely=flr(level/8)
	 sfx(3)
	 for i=0,15 do
	  for j=0,15 do
	   if fget(mget(i+levelx*16,j+levely*16),1) then
	    rplayerx=i*8
	    rplayery=j*8
	    freezefeet=true
	   end
	  end
	 end
	 fade()
 end

 function prevlevel()
	 level-=1
	 levelx=level%8
	 levely=flr(level/8)
	 sfx(2)
  for i=0,15 do
   for j=0,15 do
    lookbluespot=mget(i+levelx*16,j+levely*16)
    if lookbluespot==51 then
     rplayerx=i*8
     rplayery=j*8
     freezefeet=true
    end
   end
  end
	 for i=0,20 do
	  for n=0,7 do
	  circ(old_playerx%128+4,old_playery%128+4,160-i*8+n,0)
	  circ(old_playerx%128+4,old_playery%128+3,160-i*8+n,0)
	  end
	  flip()
	 end
	 scr_frame=1
 end

 rplayerx=playerx%128
 rplayery=playery%128

-- if level==0 then
--  if playerx==112 and playery==24 then nextlevel() end
-- end
 
-- if mget(playerx/8,playery/8)==33 then nextlevel() end
 if mget(playerx/8,playery/8)>=44
 and mget(playerx/8,playery/8)<=47
 and mget(old_playerx/8,old_playery/8)==51 then
--cano rosa
	 if char==1 and level==0 then
			level=17
			prevlevel(1)
	 elseif char==1 and level==16 then
			level=1
			prevlevel(1)
		else
	  nextlevel(1)
	 end 
 end

 old_playerx=playerx
 old_playery=playery
 
 tilescan=mget(playerx/8,playery/8)
 greenpipe=fget(mget(playerx/8,playery/8),2)
 redpipe=fget(mget(playerx/8,playery/8),3)
 yellowpipe=fget(mget(playerx/8,playery/8),4)
 bluepipe=fget(mget(playerx/8,playery/8),5)
 
 if tilescan==35 then
  mset(playerx/8,playery/8,19)
  coins+=1
  sfx(0)
 end 
 
 --cano preto
 if tilescan==58 or tilescan==59 or tilescan==60 or tilescan==61 and freezefeet==false then
  if char==1 and level==1 then
   level=16
   nextlevel(1)
  elseif char==1 and level == 17 then
  	level=0
   nextlevel(1)
  else
   prevlevel(1)
  end
  if char==2 then
   unpaint()
  end
 end

 --cano verde
 if greenpipe==true and freezefeet==false then
  if char==2 then
   paintblack()
  end
  if tilescan==6 or tilescan==7 then
   rplayerx=120-rplayerx
  end
  if tilescan==4 or tilescan==5 then
   rplayery=120-rplayery
  end
 end

 --cano vermelho
 if redpipe==true and freezefeet==false then
  if char==2 then
   paintblack()
  end
  if tilescan==20 or tilescan==21 then
   rplayerx=120-rplayerx
  end
  if tilescan==22 or tilescan==23 then
   rplayery=120-rplayery
  end
 end

 --cano amarelo
 if yellowpipe==true and freezefeet==false then
  if char==2 then
   paintblack()
  end
  rplayerx=120-rplayerx
  rplayery=120-rplayery
 end

 --cano azul
 if bluepipe==true and freezefeet==false then
  if char==2 then
   paintblack()
  end
  rplayerytemp=rplayerx
  rplayerx=120-rplayery
  rplayery=rplayerytemp
 end
 
 playerx=rplayerx+levelx*128
 playery=rplayery+levely*128
 tilescan=mget(playerx/8,playery/8)

 --cano cuspir
 if freezefeet==false then
	 if tilescan==4 or
	    tilescan==20 or
	    tilescan==36 or
	    tilescan==52 or 
	    tilescan==44 or 
	    tilescan==58 then 
	    rplayery-=8 sprite=2 sfx(2) dx=0 dy=-1 end 
	 if tilescan==5 or
	    tilescan==21 or
	    tilescan==37 or
	    tilescan==53 or 
	    tilescan==45 or 
	    tilescan==59 then 
	    rplayery+=8 sprite=1 sfx(2) dx=0 dy=1  end 
	 if tilescan==6 or
	    tilescan==22 or
	    tilescan==38 or
	    tilescan==54 or 
	    tilescan==46 or 
	    tilescan==60 then 
	    rplayerx-=8 sprite=1 sfx(2) fliped=false dx=-1 dy=0  end 
	 if tilescan==7 or
	    tilescan==23 or
	    tilescan==39 or
	    tilescan==55 or 
	    tilescan==47 or 
	    tilescan==61 then 
	    rplayerx+=8 sprite=1 sfx(2) fliped=true dx=1 dy=0  end 
 end

--[[ if level==1 then
  if rplayerx==96 and rplayery==8 then nextlevel() end
  if rplayerx==8 then rplayerx=104 end 
  if rplayerx==112 then rplayerx=16 end 
  if rplayery==8 then rplayery=104 end 
  if rplayery==112 then rplayery=16 end 
 end
 
 if level==2 then 
  if playerx==8+level*128 then
   playerx=16+level*128
   if playery==24 then playery=96
   elseif playery==48 then playery=72
   elseif playery==72 then playery=48
   elseif playery==96 then playery=24 end
  end 
  if playerx==112+level*128 then
   playerx=104+level*128
   if playery==24 then playery=96
   elseif playery==48 then playery=72
   elseif playery==72 then playery=48
   elseif playery==96 then playery=24 end
  end
  if playery==8 then
   playery=16
   if playery==24 then playery=96
   elseif playery==48 then playery=72
   elseif playery==72 then playery=48
   elseif playery==96 then playery=24 end
  end
 end]]

 playerx=rplayerx+levelx*128
 playery=rplayery+levely*128
 freezefeet=false
end

function _draw()

 scr_frame=min(scr_frame+1,8)
 for i=0,15 do
  pal(i,sget(48+i,40-scr_frame))
 end
 
 for walk_pipe=0,15,1.5 do
  cls()
	 camera(levelx*128,levely*128) 
	 map(0,0,0,0,128,64)
	 for i=0,128 do
	  for j=0,128 do
	   if mget(i,j)==35 then
	    spr(64+tim\3%6,i*8,j*8)
	   end
	  end
	 end
	 
 	if level==25 then
	 	if char==1 then
	 	 mset(24,54,89)
	 	 mset(25,54,89)
	 	 mset(24,55,89)
	 	 mset(25,55,89)
			 pal({0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}) 
			 for i=-1,1 do
			  for j=-1,1 do
			   if abs(i+j)==1 then
		     sspr(0,40,12,12,24*8+4+i,55*8-4+j)
			   end
			  end
			 end
			 pal()
	 	 sspr(0,40,12,12,24*8+4,55*8-4)
	 	end
	 end
 	if level==25 then
	 	if char==2 then
	 	 mset(23,59,89)
	 	 mset(23,60,89)
	 	 mset(22,54,127)
	 	 mset(22,55,127)
			 pal({0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}) 
			 for i=-1,1 do
			  for j=-1,1 do
			   if abs(i+j)==1 then
		     sspr(0,40,12,12,23*8-4+i,55*8-5+j,12,12,true)
			   end
			  end
			 end
			 pal()
	 	 sspr(0,40,12,12,23*8-4,55*8-5,12,12,true)
    heartcolor+=1
				if heartcolor\2%2==0 then
 				print("♥",23*8+6,55*8-9,8)
				end
				if heartcolor\2%2==1 then
 				print("♥",23*8+6,55*8-9,14)
    end
    rectfill(23*8-4,59*8+2,23*8,59*8+15,15)    
	 	end
	 end
	 
	 --spr(sprite,playerx,playery,1,1,fliped)
	 if walk_pipe<8 then
	  if walk_pipe>0 then
		  if dy1==-1 then
		   clip(0,old_playery+8-levely*128,9999,16)
		  elseif dy1==1 then
		   clip(0,old_playery-16-levely*128,9999,16)
		  elseif dx1==-1 then
		   clip(old_playerx+8-levelx*128,0,16,9999)
		  elseif dx1==1 then
		   clip(old_playerx-16-levelx*128,0,16,9999)
		  end
	  end
	  local s
	  local f
	  if dy1==1 then
	   s=1
	  elseif dy1==-1 then
	   s=2
	  else
	   s=sprite
	  end
	  if dx1==1 then
	   f=true
	  elseif dx1==-1 then
	   f=false
	  else
	   f=fliped
	  end
  	draw_char(old_playerx,old_playery,walk_pipe*dx1-dx1*8,walk_pipe*dy1-dy1*8,s,f)
 	else
	  if dy==-1 then
	   clip(0,playery-8-levely*128,9999,16)
	  elseif dy==1 then
	   clip(0,playery-levely*128,9999,16)
	  elseif dx==-1 then
	   clip(playerx-8-levelx*128,0,16,9999)
	  elseif dx==1 then
	   clip(playerx-levelx*128,0,16,9999)
	  end
	  if changechar==true then 
    char+=1
    if char>charmax then char=0 end
    changechar=false
   end
 	 draw_char(playerx,playery,walk_pipe*dx-dx*16,walk_pipe*dy-dy*16,sprite,fliped)
 	end
 	clip()
  
  if level < 16 then 
		 rectfill(levelx*128,levely*128,levelx*128+35,levely*128+7,0)
		 rectfill(levelx*128+88,levely*128,levelx*128+128,levely*128+7,0)
   if char == 1 and level > 0 then
 		 print("level "..-1*(level-17),levelx*128+1,levely*128+1,7)
		 else
 		 print("level "..level,levelx*128+1,levely*128+1,7)
   end
		 print("coins "..coins,levelx*128+90,levely*128+1,7)
			if showtimer==1 then
				if minutes<100 then
				 rectfill(levelx*128,levely*128+120,levelx*128+48,levely*128+7+120,0)
				else
				 rectfill(levelx*128,levely*128+120,levelx*128+52,levely*128+7+120,0)
				end
			 rectfill(levelx*128+86,levely*128+120,levelx*128+35+100,levely*128+7+120,0)
			 print("time "..(minutes\10)..(minutes%10)..":"..(clock\100%6)..(clock\10%10).."."..(10*clock\10)%10,levelx*128+1,levely*128+1+120,7)
			 print("steps "..steps,levelx*128+88,levely*128+1+120,7)
   end
  elseif level == 16 then 
		 rectfill(levelx*128+5,levely*128+60,levelx*128+35+15,levely*128+7+60,0)
		 rectfill(levelx*128+88-30,levely*128+60,levelx*128+128-30,levely*128+7+60,0)
		 if char == 1 then
		  print("  level 1 ",levelx*128+1+5,levely*128+1+60,7)
		 else
		  print("last level",levelx*128+1+5,levely*128+1+60,7)
		 end
		 print("coins "..coins,levelx*128+90-30,levely*128+1+60,7)
			if showtimer==1 then
		  print("time "..(minutes\10)..(minutes%10)..":"..(clock\100%6)..(clock\10%10).."."..(10*clock\10)%10,levelx*128+1,levely*128+1,7)
		  print("steps "..steps,levelx*128+88,levely*128+1,7)
			end
  else
		 rectfill(levelx*128,levely*128,levelx*128+29,levely*128+7,0)
		 rectfill(levelx*128+88,levely*128,levelx*128+128,levely*128+7,0)
		 print(" beach",levelx*128+1,levely*128+1,7)
		 print("coins "..coins,levelx*128+90,levely*128+1,7)
			if showtimer==1 then
				if minutes<100 then
				 rectfill(levelx*128,levely*128+120,levelx*128+48,levely*128+7+120,0)
				else
				 rectfill(levelx*128,levely*128+120,levelx*128+52,levely*128+7+120,0)
				end
			 rectfill(levelx*128+86,levely*128+120,levelx*128+35+100,levely*128+7+120,0)
			 print("time "..(saveminutes\10)..(saveminutes%10)..":"..(saveclock\100%6)..(saveclock\10%10).."."..(10*saveclock\10)%10,levelx*128+1,levely*128+1+120,7)
			 print("steps "..savesteps,levelx*128+88,levely*128+1+120,7)
			end
  end 
	 --print(level,50+level*128,80,7)
	 --print(rplayerx,50+level*128,90,7)
	 --print(rplayery,50+level*128,100,7)
	 --print(tilescan,50+level*128,110,7)
	 if mget(playerx/8,playery/8)==33 then spr(33,playerx,playery) end
	 camera()
	 if tilescan%16>3
	 and tilescan%16<8
	 or tilescan>=44
	 and tilescan<=47
	 or tilescan>=58
	 and tilescan<=62 then
   flip()
  else
   break
  end
 end
 dx1=0
 dy1=0
 camera()
 
 scr_frame=min(scr_frame+1,8)
 for i=0,15 do
  pal(i,sget(48+i,40-scr_frame))
 end
 
 if level==17
 and playerx>210 then
  nextlevel(8)
  playerx=144
 end
 
 if level==25
 and playerx>180 then
  dset(30,1)
  for i=0,30 do
		 for i=0,15 do
		  pal(i,sget(48+i,40-scr_frame),1)
		 end
	  flip()
	  scr_frame=max(scr_frame-.2,1)
	 end
	 
  for i=0,20 do
   flip()
  end
  
	 pal()
	 
	 if char==0 and charmax==0 and coins<100 then
   endingmessage=1
  end
	 if char==0 and charmax==0 and coins==100 then
   charmax=1
   endingmessage=2
  end
	 if char==1 and charmax==1 and coins<100 then
   endingmessage=3
  end
	 if char==1 and charmax==1 and coins==100 then
   charmax=2
   endingmessage=4
  end

  dset(20,charmax)
  		
  --photo
  for i=1,10,.5 do
   cls(({7,7,7,6,6,13,13,5,5,1})[i\1])
   flip()
  end
		
		for i=96*64,104*64,64 do
 		memset(i,0,16)
		end
		
		for i=104*64,128*64,64 do
 		memset(i+12,0,20)
		end
		
		n=0
		endingtimer=0
	 while true do
 		endingtimer+=1
	  n=min(50,n+1)
		 a=a and a*.9 or .25
		 if (a<.005) a=0
		 
		 xoff=8
		 yoff=yoff and (yoff*.9+.5) or 20
		 yoff=max(yoff,5.25)
		 
		 cls()
		 if endingtimer<100 then
			 ?"  thanks for playing\n\na game by julio maass\n    and bonevolt\n\n    total coins: ",20,90,({1,5,13,6,7})[n\5-5]
			 if n>=30 then
			  ?coins,88,120,({1,5,13,6})[n\5-5] or coins<100 and 7 or 8+tim%8
			 end
   elseif endingtimer<105 then print("  thanks for playing\n\na game by julio maass\n    and bonevolt\n\n    total coins: "..coins,20,90,7)
   elseif endingtimer<110 then print("  thanks for playing\n\na game by julio maass\n    and bonevolt\n\n    total coins: "..coins,20,90,6)
   elseif endingtimer<115 then print("  thanks for playing\n\na game by julio maass\n    and bonevolt\n\n    total coins: "..coins,20,90,13)
   elseif endingtimer<120 then print("  thanks for playing\n\na game by julio maass\n    and bonevolt\n\n    total coins: "..coins,20,90,5)
   elseif endingtimer<125 then print("  thanks for playing\n\na game by julio maass\n    and bonevolt\n\n    total coins: "..coins,20,90,1)
			else
			 if endingtimer<155 then textcolor=7 end
			 if endingtimer<150 then textcolor=6 end
			 if endingtimer<145 then textcolor=13 end
			 if endingtimer<140 then textcolor=5 end
			 if endingtimer<135 then textcolor=1 end
			 if endingtimer<130 then textcolor=0 end
				
	   if char==0 then
				 if endingmessage==1 then
				  print("   collect all coins to",12,84,textcolor)
				  print("   unlock mademouselle",14,92,textcolor)
     end
				 if endingmessage==2 then
				  print("mademouselle unlocked!",22,92)
     end
				 if coins==100 then
				 print("you got all coins!",28,84,textcolor)
					 print("  steps: "..savesteps..
					       "\ntime: "..(saveminutes\10)..(saveminutes%10)..":"..(saveclock\100%6)..(saveclock\10%10).."."..((10*saveclock\10)%10)
					       ,2,108,textcolor)
					 print("best: "..mousebeststeps100..
					       "\nbest: "..(mousebestminute100\10)..(mousebestminute100%10)..":"..(mousebestclock100\100%6)..(mousebestclock100\10%10).."."..((10*mousebestclock100\10)%10)
					       ,66,108,textcolor)
     else
					 print("  steps: "..savesteps..
					       "\ntime:  "..(saveminutes\10)..(saveminutes%10)..":"..(saveclock\100%6)..(saveclock\10%10).."."..((10*saveclock\10)%10)
					       ,2,108,textcolor)
					 print("best: "..mousebeststeps..
					       "\nbest: "..(mousebestminute\10)..(mousebestminute%10)..":"..(mousebestclock\100%6)..(mousebestclock\10%10).."."..((10*mousebestclock\10)%10)
					       ,66,108,textcolor)
     end
     
		   if endingtimer>155 then
			   if coins<100 then 
			    if savesteps==mousebeststeps then
				    ?mousebeststeps,90,108,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
			    if saveclock==mousebestclock and saveminutes==mousebestminute  then
				    ?(mousebestminute\10)..(mousebestminute%10)..":"..(mousebestclock\100%6)..(mousebestclock\10%10).."."..((10*mousebestclock\10)%10),90,114,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
			   end
			   if coins==100 then
			    if savesteps==mousebeststeps100 then
				    ?mousebeststeps100,90,108,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
			    if saveclock==mousebestclock100 and saveminutes==mousebestminute100  then
				    ?(mousebestminute100\10)..(mousebestminute100%10)..":"..(mousebestclock100\100%6)..(mousebestclock100\10%10).."."..((10*mousebestclock100\10)%10),90,114,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
						end
					end
	   end
	   
	   if char==1 then
				 if endingmessage==3 then
				  print("   collect all coins to",12,84,textcolor)
				  print("   unlock mousefredini",14,92,textcolor)
     end
				 if endingmessage==4 then
				  print("mousefredini unlocked!",22,92)
     end
				 if coins==100 then
				 print("you got all coins!",28,84,textcolor)
					 print("  steps: "..savesteps..
					       "\ntime: "..(saveminutes\10)..(saveminutes%10)..":"..(saveclock\100%6)..(saveclock\10%10).."."..((10*saveclock\10)%10)
					       ,2,108,textcolor)
					 print("best: "..girlbeststeps100..
					       "\nbest: "..(girlbestminute100\10)..(girlbestminute100%10)..":"..(girlbestclock100\100%6)..(girlbestclock100\10%10).."."..((10*girlbestclock100\10)%10)
					       ,66,108,textcolor)
     else
					 print("  steps: "..savesteps..
					       "\ntime:  "..(saveminutes\10)..(saveminutes%10)..":"..(saveclock\100%6)..(saveclock\10%10).."."..((10*saveclock\10)%10)
					       ,2,108,textcolor)
					 print("best: "..girlbeststeps..
					       "\nbest: "..(girlbestminute\10)..(girlbestminute%10)..":"..(girlbestclock\100%6)..(girlbestclock\10%10).."."..((10*girlbestclock\10)%10)
					       ,66,108,textcolor)
     end
		   if endingtimer>155 then
			   if coins<100 then 
			    if savesteps==girlbeststeps then
				    ?girlbeststeps,90,108,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
			    if saveclock==girlbestclock and saveminutes==girlbestminute  then
				    ?(girlbestminute\10)..(girlbestminute%10)..":"..(girlbestclock\100%6)..(girlbestclock\10%10).."."..((10*girlbestclock\10)%10),90,114,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
			   end
			   if coins==100 then
			    if savesteps==girlbeststeps100 then
				    ?girlbeststeps100,90,108,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
			    if saveclock==girlbestclock100 and saveminutes==girlbestminute100  then
				    ?(girlbestminute100\10)..(girlbestminute100%10)..":"..(girlbestclock100\100%6)..(girlbestclock100\10%10).."."..((10*girlbestclock100\10)%10),90,114,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
						end
					end
	   end

	   if char==2 then
				 if coins==100 then
				 print("you got all coins!",28,84,textcolor)
					 print("  steps: "..savesteps..
					       "\ntime: "..(saveminutes\10)..(saveminutes%10)..":"..(saveclock\100%6)..(saveclock\10%10).."."..((10*saveclock\10)%10)
					       ,2,108,textcolor)
					 print("best: "..icebeststeps100..
					       "\nbest: "..(icebestminute100\10)..(icebestminute100%10)..":"..(icebestclock100\100%6)..(icebestclock100\10%10).."."..((10*icebestclock100\10)%10)
					       ,66,108,textcolor)
     else
					 print("  steps: "..savesteps..
					       "\ntime:  "..(saveminutes\10)..(saveminutes%10)..":"..(saveclock\100%6)..(saveclock\10%10).."."..((10*saveclock\10)%10)
					       ,2,108,textcolor)
					 print("best: "..icebeststeps..
					       "\nbest: "..(icebestminute\10)..(icebestminute%10)..":"..(icebestclock\100%6)..(icebestclock\10%10).."."..((10*icebestclock\10)%10)
					       ,66,108,textcolor)
     end
		   if endingtimer>155 then
			   if coins<100 then 
			    if savesteps==icebeststeps then
				    ?icebeststeps,90,108,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
			    if saveclock==icebestclock and saveminutes==icebestminute  then
				    ?(icebestminute\10)..(icebestminute%10)..":"..(icebestclock\100%6)..(icebestclock\10%10).."."..((10*icebestclock\10)%10),90,114,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
			   end
			   if coins==100 then
			    if savesteps==icebeststeps100 then
				    ?icebeststeps100,90,108,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
			    if saveclock==icebestclock100 and saveminutes==icebestminute100  then
				    ?(icebestminute100\10)..(icebestminute100%10)..":"..(icebestclock100\100%6)..(icebestclock100\10%10).."."..((10*icebestclock100\10)%10),90,114,({1,5,13,6})[n\5-5] and 7 or 8+tim%8
						 end
						end
					end
	   end

	   --reset de fim de jogo
    if endingtimer == 300 then
     scr_frame=8
				end
    if endingtimer > 300 then
				 scr_frame=min(scr_frame-0.25,8)
				 for i=0,15 do
				  pal(i,sget(48+i,40-scr_frame))
				 end
    end
    if endingtimer == 330 then
     run()
				end

	   
		 end
		 tim+=1
		 for y=0,127 do
		  local a=a+.75
		  tline(0,y,127,y,
		  5+y/8*cos(a)-yoff*8*cos(a)/8-xoff*8*sin(a)/8,
		  59+y/8*sin(a)-yoff*8*sin(a)/8-xoff*8*-cos(a)/8,
		  sin(a)/8,-cos(a)/8
		  ,2
		  )
		 end

		 flip()
		 if btn(4) or btn(5) then cls() end
		end
 end
end

function draw_char(x,y,ox,oy,s,f)
 pal({0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}) 
 for i=-1,1 do
  for j=-1,1 do
   if abs(i+j)==1 then
    if char == 0 then
     sspr(-16+s*16,40,12,12,x-2+i+ox,y-2+j+oy,12,12,f)
    end
   end
  end
 end
 pal()
 if char == 0 then
  sspr(-16+s*16,40,12,12,x-2+ox,y-2+oy,12,12,f)
 end
 palt(15,true)
 palt(0,false)
 if char == 1 then
  sspr(106,34,12,13,x-2+ox,y-3+oy,12,13,f)
 end
 if char == 2 then
  sspr(116,0,12,14,x-2+ox,y-4+oy,12,14,f)
 end
 palt(15,false)
 palt(0,true)
end
-->8
function paintblack()
 pipe={ //salvando pra depois dar respawn
	t=mget(playerx/8,playery/8),
 x=playerx/8,
 y=playery/8,
 }
 add(pipelist,pipe)
 local nextpiece = 1
 if level > 0 then
		if mget (playerx/8,playery/8)<64 then
		 if mget (playerx/8,playery/8)%16==4 then
		  mset(playerx/8,playery/8,58)
				while mget (playerx/8,playery/8+nextpiece)%16==9 do
     if (playery/8)\16 == (playery/8+nextpiece)\16 then
		    mset(playerx/8,playery/8+nextpiece,63)
					end
			  nextpiece += 1
				end
		 end
		 if mget (playerx/8,playery/8)%16==5 then
		  mset(playerx/8,playery/8,59)
				while mget (playerx/8,playery/8-nextpiece)%16==9 do
     if (playery/8)\16 == (playery/8-nextpiece)\16 then
			   mset(playerx/8,playery/8-nextpiece,63)
					end
			  nextpiece += 1
				end
		 end
		 if mget (playerx/8,playery/8)%16==6 then
		  mset(playerx/8,playery/8,60)
				while mget (playerx/8+nextpiece,playery/8)%16==8 do
     if (playerx/8)\16 == (playerx/8+nextpiece)\16 then
			   mset(playerx/8+nextpiece,playery/8,62)
		   end
			  nextpiece += 1
				end
		 end
		 if mget (playerx/8,playery/8)%16==7 then
		  mset(playerx/8,playery/8,61)
				while mget (playerx/8-nextpiece,playery/8)%16==8 do
     if (playerx/8)\16 == (playerx/8-nextpiece)\16 then
			   mset(playerx/8-nextpiece,playery/8,62)
				 end
			  nextpiece += 1
				end
		 end
		end
	end
end

function unpaint()
 for pipe in all(pipelist) do
	 local nextpiece=1
		mset(pipe.x,pipe.y,pipe.t)
  if pipe.t%16==4 then
			while mget (pipe.x,pipe.y+nextpiece)==63 do
    if (pipe.y)\16 == (pipe.y+nextpiece)\16 then
 	   mset(pipe.x,pipe.y+nextpiece,pipe.t+5)
			 end
			 nextpiece += 1
			end
  end
  if pipe.t%16==5 then
			while mget (pipe.x,pipe.y-nextpiece)==63 do
    if (pipe.y)\16 == (pipe.y-nextpiece)\16 then
 	   mset(pipe.x,pipe.y-nextpiece,pipe.t+4)
			 end
			 nextpiece += 1
			end
		end
  if pipe.t%16==6 then
			while mget (pipe.x+nextpiece,pipe.y)==62 do
    if (pipe.x)\16 == (pipe.x+nextpiece)\16 then
 	   mset(pipe.x+nextpiece,pipe.y,pipe.t+2)
			 end
			 nextpiece += 1
			end
  end
  if pipe.t%16==7 then
			while mget (pipe.x-nextpiece,pipe.y)==62 do
    if (pipe.x)\16 == (pipe.x-nextpiece)\16 then
 	   mset(pipe.x-nextpiece,pipe.y,pipe.t+1)
			 end
			 nextpiece += 1
			end
  end
		del(pipelist,pipe)
 end
end