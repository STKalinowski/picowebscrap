--talos descent
--@matthughson

--thanks to ultrabrite for the
--improve line drawing.

--[[ 

--todo--

-must-

-nice-

up thrust (not sure)
music (tried... haven't landed)
intro (would be nice)
player speed streak
branching center line
fade transition

]]


printh("==new run==")

--name of save game
cartdata("mbh_talos")

----------------------------

--convert ypos to meters
function ytom(y)
	return y*0.3
end

--convert meters to ypos
function mtoy(m)
	return m/0.3
end

----------------------------

--clamp a number to a range.
--same as mid
function clamp(n,low,high)
	return max(min(n,high),low)
end

----------------------------

--make 2d vector
function mkvec(x,y)
	local v=
	{
		x=x,
		y=y,
		
  --get the length of the vector
		getlength=function(self)
			return sqrt(self.x^2+self.y^2)
		end,
		
  --get the normal of the vector
		getnorm=function(self)
			local l = self:getlength()
			return mkvec(self.x / l, self.y / l);
		end,
	}
	return v
end

----------------------------

--make a line
function mkline(x1,y1,x2,y2)
	local l=
	{
  --start of the line.
		a=mkvec(x1,y1),
  --end of the line.
		b=mkvec(x2,y2),
	
		draw=function(l,col)

   --thanks ultrabrite
   local a,b=l.a,l.b
   local ly = b.y-a.y
   local x,dx = a.x, (b.x-a.x)/ly
   local bx,bdx = 1, 1/ly
   for y=a.y,b.y do
    rectfill(x-bx,y, x+bx,y, col)
    x+=dx
    bx-=bdx
   end
		end,
		
  --helper to draw closest point
  --on a line to an object
		drawnear=function(l,o,col)
			local lp=closestpointalongline(
				l.a,l.b,mkvec(o.x,o.y))
			circ(lp.x,lp.y,2,col)			
		end,
		
  --finds the closest point on a
  --line to an object.
		closest=function(l,o)
			return closestpointalongline(
				l.a,l.b,mkvec(o.x,o.y))
		end,
	}
	
	return l
end

----------------------------

--make a random doodad.
--the stuff that is in the dirt
--allow the sides, like skulls.
function mkdoodad(_x,_y)

	local _fx=(flr(rnd(2))==0)
	local _fy=(flr(rnd(2))==0)
	local _sp=flr(rnd(4))+4
	add(doodads,{x=_x,y=_y,sp=_sp,
		fx=_fx,fy=_fy})

end

----------------------------

--make a pixel particle.
function mkparticle(_x,_y,
	_tmin,_tmax,_col)

	local o=
	{
  --position
		x=_x,
		y=_y,
		
  --velocity
		dx=(rnd(2)-4)*0.1,
		dy=(rnd(3)-1)*0.1,
		
  --gravity
		g=0,
		
  --lifetime
		t=rnd(_tmax-_tmin)+_tmin,
		
  --color
		col=_col,
	}
	
 --update
	function o:u()
		local o=self
		o.t-=1
		o.dy+=o.g
		o.x+=o.dx
		o.y+=o.dy
		
		if o.t<=0 then
			del(parts,o)
		end
	end
	
 --draw
	function o:d()
		pset(self.x,self.y,self.col)
	end
	
	add(parts,o)
	
	return o
end

----------------------------

--make an air jet particle.
function mkjetpart(d)
	local pr=mkparticle(
		p.x-d,p.y-1,10,20,6)
	pr.dy+=p.dy*speedmod
	pr.dx*=d
end

----------------------------

--make a streak; a line particle
function mkstreak(_x,_y,
	_dx,_dy,_col,_maxhist,_g,_dec)

	local o=
	{
  --position
		x=_x,
		y=_y,
  --velocity
		dx=_dx,
		dy=_dy,
  --deceleration
		decel=_dec,
  --gravity
		g=_g,
  --history of positions
		hist={},
  --max length of history to record
		maxhist=_maxhist,
  --color
		col=_col,
  --has it slowed to a stop
		stopped=false,
  --how long should it live
		lifetime=-1,
	}
	
	add(o.hist,mkvec(o.x,o.y))
	
	--update
	function o:u()
	
  --once stopped, do nothing.
		if self.stopped then
			return
		end
		
  --died of old age?
		if self.lifetime!=-1 then
			self.lifetime-=1
			if self.lifetime<=0 then
				del(streaks,self)
				return
			end
		end

  --fall
		self.dy+=self.g

  --slow down
		self.dx*=self.decel
		self.dy*=self.decel
	
  --detect slow enough to stop.
		if abs(self.dx)<=0.2 and
			abs(self.dy)<=0.2 and
			self.decel!=1 then
			self.stopped=true
			return
		end
		
  --move
		self.x+=self.dx
		self.y+=self.dy
		
  --save history of position
		add(self.hist,mkvec(self.x,self.y))
	
		if #self.hist>self.maxhist then
			del(self.hist,self.hist[1])
		end
		
		--clean up when off bottom.
  --todo: detect offscreen in 
  --general.
		if self.hist[1].y>camy+128 then
			del(streaks,self)
			return
		end
	end
	
 --draw
	function o:d()
	
  --draw a line between each 
  --position in history, creating
  --a kind of curve.
		if #self.hist>1 then
			for i=1,#self.hist-1 do
				local p1=self.hist[i]
				local p2=self.hist[i+1]
				line(p1.x,p1.y,p2.x,p2.y,self.col)
--				pset(p1.x,p1.y,self.col)			
			end
		end
	end
	
	add(streaks,o)
	
	return o

end

----------------------------

--find the point on a line 
--closest to an object.
function closestpointalongline(
	linefrom,lineto,c)
	local u,len=tounitvec(
		linefrom, lineto)
	local v = mkvec(
		c.x-linefrom.x,
		c.y-linefrom.y)
	local w = dotproduct(u, v)
	if w<-len then w=-len
	elseif w>1 then w=1 end
	local r = 
		mkvec((u.x * w),(u.y * w))
	r.x+=linefrom.x;
	r.y+=linefrom.y;
	return r
end

----------------------------

--normalize a vector.
function tounitvec(c1, c2)
	local cx = (c1.x - c2.x)
	local cy = (c1.y - c2.y)
	local c = mkvec(cx,cy)
	local l = c:getlength()
	return mkvec(c.x / l, c.y / l),l
end

----------------------------

--dot product of 2 vectors
function dotproduct(v1, v2)
	return v1.x*v2.x+v1.y*v2.y
end

----------------------------

--save the highscore to disc.
--call at end of run.
function updatehiscore()

	local oldscore=dget(0)
	if oldscore<score then
		dset(0,score)
		hiscore=score
		gothiscore=true
		sfx(8)
	end

end

----------------------------

--on the death of the player.
function ondeath()

 --create a bunch of streaks to 
 --represent to parts of the 
 --player exploding.

 --how long to make the streaks.
	local h=2

	--legs
	mkstreak(p.x,p.y,
		-p.dx,-p.dy,9,h,0.1,1)
	mkstreak(p.x,p.y,
		-p.dx,-p.dy-2,9,h,0.2,1)
	mkstreak(p.x,p.y,
		p.dx,-p.dy,9,h,0.2,1)
	mkstreak(p.x,p.y,
		p.dx,-p.dy-2,9,h,0.1,1)
	
	--head
	mkstreak(p.x,p.y,
		-p.dx+1,-p.dy,12,h,0.2,1)
	mkstreak(p.x,p.y,
		p.dx+1,-p.dy,12,h,0.1,1)
	
	--arms
	mkstreak(p.x,p.y,
		-p.dx,-p.dy-1,7,h,0.1,1)
	mkstreak(p.x,p.y,
		-p.dx+2,-p.dy-1,7,h,0.2,1)
	mkstreak(p.x,p.y,
		p.dx,-p.dy-1,7,h,0.2,1)
	mkstreak(p.x,p.y,
		p.dx+2,-p.dy-1,7,h,0.1,1)
		
	--flying blood
	mkstreak(p.x,p.y,
		-p.dx,-p.dy,8,h,0.05,1)
	mkstreak(p.x,p.y,
		-p.dx+1,-p.dy,8,h,0.05,1)
	mkstreak(p.x,p.y,
		p.dx,-p.dy*2,8,h*4,0.1,1)
	mkstreak(p.x,p.y,
		p.dx+1,-p.dy,8,h*2,0.05,1)
	
	--blood
	mkstreak(p.x,p.y,p.dx,p.dy,8,
		100,0,0.95)
	mkstreak(p.x,p.y,p.dx*0.1,p.dy,8,
		100,0,0.9)
	mkstreak(p.x,p.y,p.dx,p.dy-1,8,
		100,0,0.9)
	
 --player has died so update the 
 --highscore.
	updatehiscore()

 --reset the time since died.
	tsincedead=0
	
 --sound.
	sfx(2)
	sfx(3)
	music(9)

 --gameover state.
	state=2
end

----------------------------

--print string with outline.
function printo(str,startx,
															 starty,col,
															 col_bg)
	print(str,startx+1,starty,col_bg)
	print(str,startx-1,starty,col_bg)
	print(str,startx,starty+1,col_bg)
	print(str,startx,starty-1,col_bg)
	print(str,startx+1,starty-1,col_bg)
	print(str,startx-1,starty-1,col_bg)
	print(str,startx-1,starty+1,col_bg)
	print(str,startx+1,starty+1,col_bg)
	print(str,startx,starty,col)
end

--print string centered with 
--outline.
function printc(
	str,x,y,
	col,col_bg,
	special_chars)

	local len=(#str*4)+(special_chars*3)
	local startx=x-(len/2)
	local starty=y-2
	printo(str,startx,starty,col,col_bg)
end

--print string with sin wave 
--bobbing with outline.
function printsin(str,x,y,
	col,col_bg,special_chars)
	
	local len=(#str*4)+(special_chars*3)
	local startx=x-(len/2)
	local starty=y-2

	local fx=startx
	for i=1,#str do
		local s=sub(str,i,i)
		printo(s,fx,
			starty+(sin((fx+t)*0.015)*2),
			col,col_bg,0)
		fx+=4
		if s=="❎" then
			fx+=3
		end
	end

end

--print string with cosine wave 
--bobbing with outline.
--good when paired with sin.
function printcos(str,x,y,
	col,col_bg,special_chars)
	
	local len=(#str*4)+(special_chars*3)
	local startx=x-(len/2)
	local starty=y-2

	local fx=startx
	for i=1,#str do
		local s=sub(str,i,i)
		printo(s,fx,
			starty+(cos((fx+t)*0.015)*2),
			col,col_bg,0)
		fx+=4
		if s=="❎" then
			fx+=3
		end
	end

end

----------------------------
	
function _init()
	
	music(11)
	reset()

end

----------------------------

function reset()

 --camera position
	camx=0
	camy=0

 --offset from player.
	camoffset=32			

 --last position the path was 
 --generated at. if screen goes
 --past this, a new path node 
 --will be needed.
	lasty=128
 --how much space between each
 --point in the path.
	yinc=32
 --max distance of walls from 
 --center of path.
	xwide=32
 --max distance of walls from 
 --center of path.
	xwide_min=8
 --current speed modification.
 --increases as player progresses
 --to increase challenge.
	speedmod=1

 --the player.
	p=
	{
  --position
		x=64,
		y=-10,--start offscreen.
  --velocity
		dx=0,
		dy=1,
  --sprite
		sp=3,
  --flip
		flipx=false,
	}

 --start with a path down the 
 --center with super wide space.
 --create look of cave opening.
	path=
	{
		{64,60,64,64},
		{64,64,56,48},
		{64,96,48,32},
		{64,128,xwide,xwide},
	}	

 --the speed modifier when player
 --as the player passed thresholds.
 --{speedmod, ypos in meters}
	speeds=
	{
		{1,200},
		{1.5,500},
		{2,1000},
	}
	
 --clear object lists.
	doodads={}
	parts={}
	streaks={}
	
 --main menu.
	state=0
	
 --reset score.
	score=0

 --load hiscore.
	hiscore=dget(0)
	gothiscore=false

end

----------------------------

--ticks since game started.
t=0

function _update60()

	printh("---")

	t+=1

	--update particles.
	for k,v in pairs(parts) do
		v:u()
	end
	
 --update streaks.
	for k,v in pairs(streaks) do
		v:u()
	end
	
 --main menu.
	if state==0 then
		
  --start game.
		if btnp(5) or btnp(4) then
			state=1
			music(-1, 3000)
			sfx(12)
		end
	
		return
	
 --game over.
	elseif state==2 then

		tsincedead+=1

  --restart game.
		if btnp(5) or btnp(4)	then
			sfx(12)
			reset()
			state=1
			music(-1, 3000)
		end
	
		return
		
	end
	
 --check if player has passed
 --a speed threshold and speed
 --should be increased.
	for k,v in pairs(speeds) do
		if ytom(p.y)<v[2] then
			if speedmod!=v[1] then
				speedmod=v[1]
				sfx(11)
    --hack for heartbeat.
				if speedmod<=1.5 then
					music(3)
				elseif speedmod<=2 then
					music(4)
				end
			end
			break
		end
	end

 --mod the players speed.
	local pspd=0.05*speedmod
	local postmove=nil
	if btn(0) then
		p.dx-=pspd
		p.dx=max(p.dx,-1)
		p.flipx=true
		sfx(0)
		postmove=function()
			mkjetpart(-1)
			end
	end
	
	if btn(1) then
		p.dx+=pspd
		p.dx=min(p.dx,1)
		p.flipx=false
		sfx(0)
		postmove=function()mkjetpart(1)end
	end

	p.x+=p.dx
	p.y+=p.dy*speedmod
	if(postmove!=nil)postmove()
	camy=max(p.y-camoffset,0)
	

	--the streak
	if speedmod>1 then
		local c={12,9,7,4}	
		for i=-1,1 do
			local s=mkstreak(p.x+i,p.y,
				-p.dx,-p.dy,c[flr(rnd(#c))+1],5,0,1)
			s.lifetime=rnd(5*speedmod)
		end
	end
	
	score=flr(ytom(p.y-camoffset))
	
	--is it time for a new point
	--on the path?
	if camy+128>lasty and #path>0 then
		--start with the previous x
		local newx=path[#path][1]
		--deviate from that pos
		newx+=rnd(32)-16
		--avoid getting to close to
		--the edges
		newx=clamp(newx,xwide,127-xwide)
		--move downward
		lasty+=yinc
		add(path,
			{newx,lasty,
				rnd(xwide-xwide_min)+xwide_min,
				rnd(xwide-xwide_min)+xwide_min})
		
  --place a doodad.
		if #path>1 then
			local i=#path
			local p1=path[i]
			local p2=path[i-1]
			
			--left
			local l=mkline(
				p1[1]-p1[3],p1[2],
				p2[1]-p2[3],p2[2])
			local sml=l.a.x
			if(l.a.x>l.b.x)sml=l.b.x
			local _x=rnd(sml-8)
			local _y=rnd(l.a.y-l.b.y)+l.b.y
			mkdoodad(_x,_y)
			
			--right
			local l=mkline(
				p1[1]+p1[4],p1[2],
				p2[1]+p2[4],p2[2])
			local lrg=l.a.x
			if(l.a.x<l.b.x)lrg=l.b.x
			local _x=rnd(128-lrg)+lrg
			local _y=rnd(l.a.y-l.b.y)+l.b.y
			mkdoodad(_x,_y)
		end
	end
	
 --clean up paths offscreen.
	for k,v in pairs(path) do
		if v[2]<camy-yinc then
			del(path,v)
		end
	end
	
 --clean up doodads offscreen.
	for k,v in pairs(doodads) do
		if v.y<camy-8 then
			del(doodads,v)
		end
	end
	
 --check for player hitting wall.
	for i=1,#path-1 do
	
		p1=path[i]
		p2=path[i+1]
		
		--left
		local l=mkline(
			p1[1]-p1[3],p1[2],
			p2[1]-p2[3],p2[2])
		local c=l:closest(p)
		local d=mkvec(p.x-c.x,p.y-c.y)
		local len=d:getlength()
		
  --blue reflection when close
  --to wall.
		if len<8 then
				local s=mkstreak(c.x,c.y,
					0,0,12,2,0,1)
 				s.lifetime=5
		end
  --white reflection when really
  --close to wall.
		if len<6 then
				local s=mkstreak(c.x,c.y,
					0,0,7,2,0,1)
 				s.lifetime=5
		end
		
  --dead if within 2 pixels of 
  --wall.
		if len<2 then
			ondeath()
		end
		
		--right		
		local l=mkline(
			p1[1]+p1[4],p1[2],
			p2[1]+p2[4],p2[2])
		local c=l:closest(p)
		local d=mkvec(p.x-c.x,p.y-c.y)
		local len=d:getlength()
				if len<8 then
				local s=mkstreak(c.x,c.y,
					0,0,12,2,0,1)
 				s.lifetime=5
		end
		if len<6 then
				local s=mkstreak(c.x,c.y,
					0,0,7,2,0,1)
 				s.lifetime=5
		end
		if len<2 then
			ondeath()
		end		
	end
	
end

-------------------------

function _draw()

	cls(0)

 --sky at the start of game.
	local c1=12
	local c2=1
	camera(camx,camy*0.5)
	rectfill(0,0,128,28,c1)
	rectfill(0,29,128,56,c2)
	for i=28,36,2 do
		line(0,i,128,i,c1)
	end
	for i=56,64,2 do
		line(0,i,128,i,c2)
	end
	
 --calculate camera shake.
	local shk=mkvec(0,0)
	if state==2 and tsincedead<10 then
		if t%2==0 then
			shk.x=rnd(4)-2
			shk.y=rnd(4)-2
		end
	end

	camera(camx+shk.x,camy+shk.y)
	
 --draw speed up thresholds.
	for i=1,#speeds-1 do
		local v=speeds[i]
		local v=mkvec(64,mtoy(v[2]))
		
		if v.y>camy and v.y<camy+128 then
 		--todo! too expensive
		 printcos("▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒",v.x,v.y,1,1,0)
		 printsin("▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒",v.x,v.y,1,0,0)
		end
	end
	
 --thanks ultrabrite
 for i=1,#path-1 do

  p1=path[i]
  p2=path[i+1]

  --center line.
  local l=mkline(
    p1[1],p1[2],
    p2[1],p2[2])

  --avoid paralax  
  if l.a.y>mtoy(50)then
    l:draw(1)
  elseif l.a.y<=mtoy(50) and
    l.b.y>=mtoy(50) then
    local l=mkline(        
      p1[1]-p1[3],p1[2],
      p2[1],p2[2])
    l:draw(1)
    local l=mkline(
      p1[1]+p1[4],p1[2],
      p2[1],p2[2])
    l:draw(1)
  end

  --left
  local l=mkline(
    p1[1]-p1[3],p1[2],
    p2[1]-p2[3],p2[2])
    
  local x,dx = l.a.x, (l.b.x-l.a.x)/(l.b.y-l.a.y)
  for y=l.a.y,l.b.y do
    rectfill(x,y, 0,y, 1)
    x+=dx
  end
  l:draw(13)

  --right    
  local l=mkline(
    p1[1]+p1[4],p1[2],
    p2[1]+p2[4],p2[2])
  
  local x,dx = l.a.x, (l.b.x-l.a.x)/(l.b.y-l.a.y)
  for y=l.a.y,l.b.y do
    rectfill(x,y, 127,y, 1)
    x+=dx
  end
  l:draw(13)
  
 end
	
	for k,v in pairs(doodads) do
		spr(v.sp,v.x,v.y,1,1,v.fx,v.fy)
	end

	for k,v in pairs(parts) do
		v:d()
	end
	
	for k,v in pairs(streaks) do
		v:d()
	end
	
 --draw the player
	if state!=2 then
		spr(p.sp,p.x-4,p.y-4,1,1,p.flipx,false)
	end

 --hud

	camera(0,0)
	
	printo("score:"..score.."m",2,2,7,0)

	local str="best:"..hiscore.."m"
	local len=#str*4
	local startx=128-len-1
	printo(str,startx,2,7,0)

	--print(stat(1),0,16)
	--print(stat(0),0,24)
	
	if state==0 then
	
		map(0,0,28,32,9,4)
	
		printcos("press ❎ to start",64,80,1,1,1)
		printsin("press ❎ to start",64,80,7,0,1)
		
		printo("@matthughson",2,121,7,0)
		printo("@gruber_music",75,121,7,0)
	elseif state==2 then
		printcos("press ❎ to play again",64,80,1,1,1)
		printsin("press ❎ to play again",64,80,7,0,1)
		printc("game over",64,32,7,0,0)
		
		--hiscore
		local col=7
		if gothiscore then
			col=(t*0.25)%2+9
		end
		str=score.."m"
		if gothiscore then
			printcos(str,64,48,7,7,0)
			printsin(str,64,48,col,0,0)
		else
			printc(str,64,40,col,0,0)
		end
	end

end
if(_update60)_update=function()_update60()_update_buttons()_update60()end