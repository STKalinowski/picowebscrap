-- blue marble
--   by jakub wasilewski

-- feel free to play with the
-- variables below to get
-- various results - dig
-- deeper into the
-- implementation to make
-- bigger changes.
-- you can also play with the
-- textures/lighting tables 
-- in the sprite memory.

-- center for 3d projection
center_x,center_y=64,47
-- toggles for features
moon_on=true
clouds_on=true
stars_on=true
quote_on=true
-- earth properties
earth_size=30
-- moon properties
moon_size=9
moon_orbit=54
-- cloud properties
cloud_count=30
cloud_stacks=8

------------------------------
-- utilities
------------------------------

-- rounds the number to the
-- nearest integer
function round(x)
 return flr(x+0.5)
end

-- linear interpolation from
-- a to b. t=0->a, t=1->b
function lerp(a,b,t)
 return a+(b-a)*t
end

-- random real number
-- between lo and hi
function rndf(lo,hi)
 return lo+rnd()*(hi-lo)
end

-- prints some text with
-- a chosen alignment,
-- 0.5 - centre, 1 - right align
function printa(t,x,y,c,align)
 x-=align*4*#t
 print(t,x,y,c) 
end

------------------------------
-- class & entity system
------------------------------

-- object is the master "class"
-- it has one method - extend(),
-- which can be used to make
-- new classes.
-- each class also inherits that
-- method, making hierarchies
-- possible.
--
-- new instances are made by
-- calling my_class:new({...}),
-- and the object passed to
-- new contains all properties
-- for the instance.
--
-- class objects can define a
-- create() method that gets
-- called whenever this happens.
--
object={}
 function object:extend(kob)
  -- remember the hierarchy
  kob=kob or {}
  kob.extends=self
  -- add the constructor method
  kob.new=function(self,ob)
   -- set up inheritance
   ob=setmetatable(ob or {},{__index=kob})
   -- call all create() methods
   -- in inheritance order
   local ko,create_fn=kob
   while ko do
    if ko.create and ko.create~=create_fn then
     create_fn=ko.create
     create_fn(ob)
    end
    ko=ko.extends
   end
   -- object ready
   return ob
 	end
 	-- set up inheritance between
 	-- the class objects themselves
 	return setmetatable(kob,{__index=self})
 end

-- returns a function that will
-- update all entities
-- passed in the parameter
function update_system(entities)
 return function()
  for e in all(entities) do
   e:update()
  end
 end
end

-- returns a function that will
-- render all entities
-- passed in the parameter
function render_system(entities)
 return function()
  -- depth-sort for correct
  -- drawing order
  local ordered={}
  for e in all(entities) do
   local z=flr(e.z) or -10
   local tab=ordered[z] or {}
   add(tab,e)
   ordered[z]=tab 
  end
  -- draw in z-order
  for z=-80,80 do
   if ordered[z] then
    for e in all(ordered[z]) do
     e:render()
    end
   end
  end
 end
end

------------------------------
-- 3d projection
------------------------------

-- sets the projection up,
-- tilted about x axis by
-- the angle provided
function init_projection(tilt)
 pryy,pryz,przy,przz=
  cos(tilt),sin(tilt),
  -sin(tilt),cos(tilt) 
end

-- projects a point (x,y,z) 
-- using an ortographic projection
-- also provides z, for depth
-- sorting purposes.
function project(x,y,z)
 local py,pz=
  pryy*y+przy*z,
  pryz*y+przz*z
 return center_x+x,center_y+py,pz
end

------------------------------
-- computing lighting luts
------------------------------

-- number of lighting levels
-- possible
lut_levels=8
-- the index of the "neutral"
-- lighting level - the one
-- that means "no change"
neutral=5

------------------------------

-- grabs the lighting look-up
-- tables from the sprite memory
-- see sprite memory at (40,64)
function init_blend_luts()
 -- palette table coords
 local blx,bly=40,64
 -- base addresses
 local addr
 local even_base,odd_base=
  0x4300,
  0x4300+lut_levels*0x100

 -- lookup tables for even lines
 for even_lut=0,lut_levels-1 do
  addr=even_base+0x100*even_lut
  for byte=0,255 do
   local c1,c2=
    band(byte,0xf),
    flr(shr(byte,4))
   local l1=sget(blx+even_lut*2,bly+c1)
   local l2=sget(blx+even_lut*2+1,bly+c2)
   poke(addr+byte,l1+l2*16)
  end
 end
 
 -- lookup tables for odd lines
 -- different, to achieve
 -- a cross-hatch pattern in
 -- some light levels
 for odd_lut=0,lut_levels-1 do
  addr=odd_base+0x100*odd_lut
  for byte=0,255 do
   local c1,c2=
    band(byte,0xf),
    flr(shr(byte,4))
   local l1=sget(blx+odd_lut*2+1,bly+c1)
   local l2=sget(blx+odd_lut*2,bly+c2)
   poke(addr+byte,l1+l2*16)
  end
 end
end

------------------------------
-- light blending function
------------------------------

-- returns a function that
-- applies the lighting
-- level "l" to a single
-- horizontal line segment.
function fl_blend(l)
 local lutaddr=0x4300+shl(l,8)
	return function(x1,x2,y)
	 -- this function operates
	 -- on screen memory directly
	 local laddr=lutaddr
	 local yaddr=0x6000+shl(y,6)
	 local saddr,eaddr=
	  yaddr+band(shr(x1+1,1),0xffff),
	  yaddr+band(shr(x2-1,1),0xffff)
	 -- odd pixel on left?
	 if band(x1,1.99995)>=1 then
	  local a=saddr-1
	  local v=peek(a)
	  poke(a,
	   band(v,0xf) +
	   band(peek(bor(laddr,v)),0xf0)
	  )
	 end
	 -- full bytes fast loop
	 for addr=saddr,eaddr do
	  poke(addr,
	   peek(
	    bor(laddr,peek(addr))
	   )
	  )
	 end
	 -- odd pixel on right?
	 if band(x2,1.99995)<1 then
	  local a=eaddr+1
	  local v=peek(a)
	  poke(a,
	   band(peek(bor(laddr,v)),0xf) +
	   band(v,0xf0)
	  )
	 end
	end
end

-------------------------------
-- palette effects
-------------------------------

-- creates palettes from
-- tables in sprite memory
-- (at (0,64))
function init_palettes(n)
 -- we keep palettes as
 -- blocks of memory ready
 -- to copy directly into
 -- pico-8 video state
 local addr=0x5800
 for plt=0,n-1 do
  for c=0,15 do
   poke(addr,sget(plt,64+c))
   addr+=1
  end
 end
end

-- sets palette number "no"
function set_palette(no)
 -- modify the pico-8 video
 -- state directly, fast
 memcpy(0x5f00,
  0x5800+shl(flr(no),4),
  16)
end

------------------------------
-- precomputing & drawing
-- the lighting
------------------------------

-- this object will be
-- responsible for applying
-- lighting to a planet
lighting=object:extend()
 function lighting:create()
  -- size to fit the planet
  local p=self.target
  local radius=p.size+1
  -- precalculate for later
  self:prepare(radius)
  self.slices=self:scan(radius)
 end

 -- draws the lighting on screen
 -- using normal drawing operations
 -- with each color corresponding
 -- to a light level 
 function lighting:prepare(radius)
  cls()
	 for c in all(self.def) do
	  circfill(
	   64+c[1]*radius,64+c[2]*radius,
	   c[3]*radius,
	   c[4]+1
	  )
	 end
 end
 
 -- remakes the light's circles
 -- into a set of horizontal
 -- light segments suitable
 -- for use with fl_blend
 function lighting:scan(radius)
	 radius+=2
	 -- to support dimming the moon
	 -- when it's in earth's shadow,
	 -- we have several precomputed
	 -- tables for each "dimming"
	 -- level
	 local dlv=
	  self.target.dim_levels
	 local slices={}
	 for i=0,dlv do
	  slices[i]={}
	 end
	 -- scan the screen looking
	 -- for horizontal stretches
	 -- of similar lighting
	 for y=64-radius,64+radius do
	  local lutb=y%2==0
	   and 0 or lut_levels      
	  local prvc,sx=0  
	  for x=64-radius,64+radius+1 do
	   local c=pget(x,y)
	   if c~=prvc then
	    if prvc~=0 then
	     -- new light segment
	     -- store in all the
	     -- "dimming" level
	     -- tables
		    for i=0,dlv do
		     local lutn=max(prvc-1-i,0)
		     -- each slice gets a
		     -- pre-prepared function
		     -- to light it
		     add(slices[i],{
		      sx=sx-64,ex=x-64-1,y=y-64,
		      fl=fl_blend(lutb+lutn)
		     })
		    end
	    end
	    sx,prvc=x,c
	   end
	  end
	 end
	 return slices
 end
 
 -- applies the lighting, with
 -- additional dimming, and at
 -- the right coordinates
 function lighting:apply(dimming,dx,dy)
  local ss=self.slices[dimming]
  local n=#ss
  for i=1,n do
   local s=ss[i]
   s.fl(s.sx+dx,s.ex+dx,s.y+dy)
  end
 end

------------------------------
-- starfield
------------------------------

-- a simple 3d-like starfield
-- faked, but good enough
starfield=object:extend({
 z=-64
})
 -- pre-seeds the right
 -- number of stars
 function starfield:create()
  self.stars={}
  for i=1,self.n do
   self.stars[i]=self:new_star(true)
  end
 end
 
 -- makes a new star, starting
 -- from a chosen vanishing
 -- point
 function starfield:new_star(pre_moved)
  local a=rnd()
  local d=pre_moved and 23+rnd(100) or 16
  local v=rnd(0.2)+0.2
  if pre_moved then
   v*=d/23
  end
  return {
   x=self.cx+sin(a)*d,
   y=self.cy+cos(a)*d,
   vx=sin(a)*v,
   vy=cos(a)*v,
  }
 end
 
 -- move the stars
 function starfield:update()  
  local s=self.stars
  for i=1,#s do
   local st=s[i]
   st.x+=st.vx
   st.y+=st.vy
   -- increasing speed over time
   --  mimics perspective
   st.vx*=1.03
   st.vy*=1.03
   -- stars die off-screen
   if st.x<0 or st.y<0
    or st.x>128 or st.y>128 then
     s[i]=self:new_star()
   end
  end
 end
 
 -- draws the individual stars
 function starfield:render()
  local s=self.stars
  for i=1,#s do
   local st=s[i]
   pset(st.x,st.y,1)
  end
 end

------------------------------
-- helpers for 3d planet
-- precalc
------------------------------

-- does all the actual 3d
-- calculations for planets
-- fills up a "coords" table
-- that will be used to
-- get texturing info later
function prep_planet(p)
 local s=p.size
 local coords={}
 -- go through all latitudes
 for lat=-0.25,0.25,0.003 do
  -- the horizontal scale of 
  -- this "slice" of the
  -- earth sphere
  local scl=cos(lat)
  local sscl=s*scl
  -- texture coords
  local tox,toy,tw,th=
   p.tex_origin.x,
   p.tex_origin.y,
   p.tex_size.w,
   p.tex_size.h
  local tcy=toy+th/2
  -- go through all longitudes
  for long=-0.5,0.5,0.003/scl do
   -- 3d coordinates of this
   -- lat/long on the sphere
   local x,z,y=
    sscl*cos(long),
    sscl*sin(long),
    s*sin(lat)
   -- same coords, after 3d
   -- projection
   local fx,fy,fz=
    project(x,y,z)
   fx,fy=round(fx),round(fy)
   -- texture u/v coords
   -- for this point
   local tx,ty=
    flr(tox+long*tw%tw),
    flr(tcy-lat*2*th)
   -- visible?
   --  ("back-face culling")
   if fz>0 then
    if not coords[fy] then
     coords[fy]={}
    end
    -- store for scan_slices
    coords[fy][fx]={x=tx,y=ty}
    -- visualize precalc
    local tc=sget(tx,ty)    
    pset(fx,fy,tc)
   end
  end
 end
 return coords
end

-- takes the 3d data generated
-- by prep_planet and divides
-- the whole sphere into
-- horizontal line segments
-- that can be textured
-- with one sspr() call.
-- this is the whole trick
-- that makes this fast enough.
function scan_slices(p,coords)
 local s=p.size
 local slices={}
 for y,cc in pairs(coords) do
  local sty,sx,stx,ptx=
   nil,nil,nil
  for x=center_x-s-2,center_x+s+2 do
   local ty=cc[x] and cc[x].y
   if ty~=sty then
    if sty then
     local ssx,ssw=sx,x-sx
     if abs(ptx+128-stx)<abs(ptx-stx) then
      ptx+=128
     end
     if ptx<stx then
      ssx,ssw=ssx+ssw,-ssw
      ptx,stx=stx,ptx
     end
     add(slices,{
      sx=ssx-center_x,sw=ssw,sy=y-center_y,
      tx=stx,ty=sty,
      tw=ptx-stx+1
     })
    end
    sx,stx,sty=
     x,cc[x] and cc[x].x,ty
   end
   ptx=cc[x] and cc[x].x
  end
 end
 return slices
end

------------------------------
-- planet objects
------------------------------

-- the main object - a planet
-- is a sphere that can texture
-- itself and uses light/cloud
-- object to render aftereffects
planet=object:extend({
 x=0,y=0,z=0,dim=0,
 dim_levels=0,
 light_def={
	 {0,0,1.07,2},	 
	 {-0.05,-0.05,0.9,3},
	 {-0.1,-0.1,0.8,4},	 
	 {-0.15,-0.15,0.7,5},
	 {-0.2,-0.2,0.6,6},
	 {-0.3,-0.3,0.4,7},
	}
})
 function planet:create()
  -- create the texturing data
  local crds=prep_planet(self,tlt)
  local slcs=scan_slices(self,crds)
  self.s=slcs
  -- texture mask (depends
  -- on texture width)
  self.tmsk=self.tex_size.w-0x0.0001 
  -- initialize lighting
  self.light=lighting:new({
   target=self,
   def=self.light_def
  })
  -- initialize clouds
  -- clouds rotate at different
  -- speed to separate the
  -- layers visually
  if self.cloud_count then
   self.clouds=clouds:new({
    target=self,
    count=self.cloud_count,
    speed=-128*
     self.rot/self.tex_size.w
   })
  end
 end
 
 function planet:update()
  -- rotate self
  self.off+=self.rot
  self.off%=self.tex_size.w
  -- ...and the clouds
  if self.clouds then
   self.clouds:move()
  end
 end
 
 function planet:render()
  -- find our 2d center
  -- based on 3d coordinates
  local x,y=project(self.x,self.y,self.z)
  x,y=round(x),round(y)
  camera(-x,-y)  
  -- render all the textured
  -- slices
  local slices=self.s
  for si=1,#slices do
   self:render_slice(slices[si])
  end
  -- add the clouds
  if self.clouds then
   self.clouds:overlay()
  end
  camera()
  -- light everything
  self.light:apply(self.dim,x,y)
 end
 
 function planet:render_slice(s)
  -- find the current texture
  -- coordinates for this slice
  -- they change to give
  -- illusion of rotating
  -- the planet is static,
  -- but the texture moves
  -- over its surface instead.
  local tsx=band(s.tx+self.off,self.tmsk)
  local tex=band(tsx+s.tw,self.tmsk)
  -- texture wrapping
  if tex<tsx then
   -- this slice is an unhappy
   -- case that needs 2 sspr()
   -- calls.
   local tw1,tw2=
    self.tex_size.w-tsx,
    tex+1
   local sw1=round(s.sw*tw1/(tw1+tw2))
   local sw2=s.sw-sw1
   local sx1,sx2=s.sx,s.sx+sw1
   sspr(tsx,s.ty,tw1,1,
    sx1,s.sy,sw1,1)
   sspr(0,s.ty,tw2,1,
    sx2,s.sy,sw2,1)
  else
   -- happy case - the whole
   -- slice fits into a single
   -- texture repetition
   sspr(tsx,s.ty,tex-tsx+1,1,
    s.sx,s.sy,s.sw,1)
  end
 end

------------------------------
-- moons
------------------------------

-- moons are like planets,
-- but they move around
-- and cast a shadow
moon=planet:extend({
 dim_levels=5,
 angle=0,
 light_def={
	 {0,0,1,2},	 
	 {-0.05,-0.05,0.9,3},
	 {-0.1,-0.1,0.8,4},	 
	 {-0.15,-0.15,0.7,5},
	 {-0.2,-0.2,0.6,6},
	 {-0.3,-0.3,0.4,7},
	},
 shadow_def={
  {0,0,1,1}
 }
})
 function moon:create()
  -- initialize the shadow
  -- in addition to the
  -- standard planet stuff
  self.shadow=lighting:new({
   target=self,
   def=self.shadow_def
  })
 end
 function moon:update()
  self.angle+=self.orbit_speed
  self.angle%=1
  -- orbit around planet
  self.x,self.y,self.z=
   self:orbit(self.angle)  
  -- rotate towards planet
  self.off=
   self.tex_size.w*((-self.angle)%1)
  -- simulate earth's shadow
  -- on the moon
  local shadow=
   mid(0,1,1-abs(self.angle-0.45)/0.2)
  self.dim=
   round(mid(0,self.dim_levels,shadow*8))
 end
 function moon:orbit(a)
  -- can be tweaked for a
  -- different orbit
  return 
   -sin(a)*moon_orbit,
   -sin(a)*5-2,
   cos(a)*moon_orbit
 end
 function moon:render()
  -- shadow the earth
  -- (solar eclipse daily!)
  local x,y,z=
   project(self.x,self.y,self.z)
  -- these shadow coordinates
  -- are just a "looks right"
  -- eyeballed approximation
  -- when in doubt, fake it.
  local shx,shy=
   round(x+3-self.x*0.25),
   round(y)
  -- only cast shadow if we're
  -- in front of earth, duh.
  if z>0 then
   self.shadow:apply(0,shx,shy)
  end
  -- render the orb itself
  planet.render(self)
 end

------------------------------
-- cloud objects
------------------------------

clouds=object:extend({
 slices=cloud_stacks,
 min_lat=-0.1,max_lat=0.22
})
 function clouds:create()
  self:precalc()
  self:spawn()
 end
 
 -- precalculates coordinates
 -- above earth so that moving
 -- clouds later takes a minimum
 -- amount of work.
 -- clouds come in "stacks" -
 -- sets of clouds at the same
 -- latitude.
 -- for each latitude, we precalc
 -- 256 positions around the planet.
 function clouds:precalc()  
  self.size=self.target.size
  self.cs={}
  local minl,maxl,slices,size=
   self.min_lat,self.max_lat,
   self.slices,self.size
  local lat_stp=
   (maxl-minl)/(slices-0.99)
  for lat=minl,maxl,lat_stp do
   local latcs={}
   local scl=cos(lat)
   local sscl=size*scl
   for lng=0,255 do
    local flng=-0.5+lng/256
    local x,z,y=
     sscl*cos(flng),
     sscl*sin(flng),
     size*sin(lat)
	   x,y,z=project(x,y,z)
	   if z>-1 then
     latcs[lng]={x=x-center_x-3,y=y-center_y-3}
	   end
   end
   add(self.cs,latcs)
  end
 end
 
 -- this creates the actual
 -- clouds randomly.
 -- each cloud is made of
 -- several "puffs" - individual
 -- sprites arranged horizontally
 -- for the appearance of a cloud.
 function clouds:spawn()
  local slices=self.slices
  local per_lat=self.count/slices
  local per_inc_prob=
   per_lat%1
  per_lat=flr(per_lat)
  self.puffs={}
  for slc=1,slices do
   local slpuffs={}
   local lcnt=per_lat
   if rnd()<per_inc_prob then
    lcnt+=1
   end
   for i=1,lcnt do
    local lng,sprd,shft,av=
    rnd(256),
    rndf(2.56,3.84),
    rndf(-1,1),
    rndf(0.9,1.11)*self.speed
	   for p=1,3+rnd(3) do
	    add(slpuffs,{
	     lng=flr(lng-p*sprd),
	     v=av,
					 shft=shft,
	     sp=flr(250+rnd(6))
	    })
	   end
	  end
	  add(self.puffs,slpuffs)
  end
 end
 
 -- move clouds around - just
 -- change longitude of each.
 function clouds:move()
  for sl=1,self.slices do
   local puffs=self.puffs[sl]
   for si=1,#puffs do
    local p=puffs[si]
    p.lng+=p.v
   end
  end  
 end
 
 -- draws the clouds on top
 -- of the earth
 function clouds:overlay()
  -- sprites with transparency
  palt(3,true)
  -- each longitude "stack"
  -- gets own iteration
  -- for speed
  for sl=1,self.slices do
   local coords,puffs=
    self.cs[sl],self.puffs[sl]
   for pfi=1,#puffs do
    local p=puffs[pfi]
    -- use the precalculated
    -- coordinates
    local c=coords[band(p.lng,0xff)]
    -- no coordinates? means this
    -- is behind the planet
    if c then
     -- draw the sprite
     spr(p.sp,c.x,c.y+p.shft)
    end
   end
  end
  -- restore draw state
  palt(3,false)
 end

------------------------------
-- quotes
------------------------------

quote_texts={
 {"nature does not hurry, yet",
  "everything gets accomplished.",
  "-- lao tzu"},
 {"mostly harmless.",
  "-- d. adams     "},
 {"why should i care about future",
  "generations? what have they",
  "ever done for me?",
  "-- g. marx"},
 {"stop worrying about the world",
  "ending today. it's already",
  "tomorrow in australia.",
  "-- c. schulz"},
 {"there are no passengers",
  "on spaceship earth.",
  "we're all crew.",
  "-- m. mcluhan  "},
 {"the earth is the cradle of",
  "humanity, but mankind cannot",
  "stay forever in a cradle.",
  "-- k. tsiolkovsky"},
 {"we are here on earth to fart",
  "around; don't let anybody",
  "tell you different.",
  "-- kurt vonnegut"},
 {"nothing exists except atoms",
  "and empty space; everything",
  "else is opinion.",
  "-- democritus"},
 {"the universe is under",
  "no obligation to",
  "make sense to you.",
  "-- n. degrasse tyson"},
 {"the most dangerous worldview",
  "is that of those who have",
  "not viewed the world.",
  "-- a. von humboldt"},
 {"earth provides enough",
  "to satisfy every man's need,",
  "but not every man's greed.",
  "-- m. gandhi"},
 {"it's a fixer-upper of a planet",
  "but we could make it work.",
  "-- e. musk"},
 {"we don't inherit",
  "the planet from our ancestors,",
  "we borrow it from our children.",
  "-- d. brower"},
 {"what use is a house if you",
  "haven't got a tolerable planet",
  "to put it on?",
  "-- h.d. thoreau"},
 {"i put up my thumb and",
  "blotted out the planet earth.",
  "-- n. armstrong"},
 {"how inappropriate to call",
  "this planet earth, when it",
  "is quite clearly ocean.",
  "-- a.c. clarke"}
}
quote=object:extend({
 z=20,
 state=0,delay=60,
})
 function quote:create()
  -- start with first quote
  self.n,self.state=0,0
  self:switch()
 end
 
 function quote:next()
  self.state=-16
 end
 
	function quote:switch()
	 -- grab next quote from table
  self.n%=#quote_texts
  self.n+=1
	 self.q=quote_texts[self.n]
	 -- space properly depending
	 -- on size
	 local height=#self.q*7
	 self.y=100-height*0.5
	end
	
	function quote:update()
	 if btnp(4) or btnp(5) then
	  self:next()
	 end
	 -- synchronizing the dim
	 -- effect with quote
	 -- changes
	 if self.delay==0 then
		 self.state+=1
		 if self.state==0 then
		  self:switch()
		 end
		else
		 self.delay-=1
		end
	end
	
	function quote:render()
	 local plt=mid(0,7,
	  16-abs(self.state))
	 set_palette(plt)
	 
	 local q,n=self.q,#self.q
	 for i=1,n do
	  local text=q[i]
	  if i==n then
	   printa(text,
	    125,self.y+i*7+2,
	    5,1)
	  else
	   printa(text,
	    64,self.y+i*7,
	    13,0.5)
	  end
	 end
	 
	 set_palette(0)
	end
	
------------------------------
-- main loop
------------------------------

fps=60
function _init()
 cls()
  
 init_palettes(8)
 init_blend_luts()
 init_projection(0.05)
 
 -- adapt to chosen fps
 local multiplier=
  60/fps
  
 -- make earth
 local gaia=planet:new({
  size=earth_size,
  off=0,rot=-1*multiplier,
  tex_origin={x=0,y=0},
  tex_size={w=128,h=64},
  cloud_count=clouds_on and cloud_count,
 })  
 -- ...and its moon
 local luna=moon:new({
  size=moon_size,
  x=-10,y=0,z=10,
  orbit_speed=0x0.01*multiplier,
  tex_origin={x=0,y=96},
  tex_size={w=32,h=16},
 })
 -- a starfield...
 local stars=starfield:new({
  cx=32,cy=40,n=50
 })
 -- and the quotes
 local funny_quote=quote:new()
 
 -- add whatever is on
 -- to the entity list
 entities={gaia}
 if (moon_on) add(entities,luna)
 if (stars_on) add(entities,stars)
 if (quote_on) add(entities,funny_quote)

 -- create the update/render
 -- loops with these entities
 update_entities=
  update_system(entities)
 render_entities=
  render_system(entities)
 
 -- use the right _update
 -- variant for the fps
 if fps==30 then
  _update=update_entities
 else
  _update60=update_entities
 end
end

function _draw()
 cls()
 set_palette(0)
 render_entities()
end
