-- superpicodehot
-- by picoter8
-- todo:
-- - game over screen
-- - game finished screen
-- - player:
-- - - pressing down increases gravity?
-- - gimmicks?
-- - - bouncers
-- - - spikes
-- - - moving platforms
-- - - swamp water?
-- - enemies:
-- - - runners
-- - - bouncers
-- - - bomber 
-- - - hover with orbiting shields
-- - level themes:
-- - - desert?
-- - - jungle?
-- - - cave?
-- - - tech research facility/factory?
-- - boss1:
-- - - killing boss, kills all bullets too
-- - - not-killing explosion should be less impactful

one_frame=1/60

g_time_scale=1
g_gameover=false
g_gameover_t=0

g_boss_killed=false
g_boss_killed_t=0

ss_max_enemies_killed=0

cartdata("supercontrahot")

function load_game()
 ss_max_enemies_killed=dget(0)
end

--
function save_game()
 dset(0,ss_max_enemies_killed)
end

--
function reset_game()
 ss_max_enemies_killed=0
 save_game()
 run()
end


function sfx_set_speed(sfx,speed)
 poke(0x3200+68*sfx+65,speed)
end

align_c,align_r=1,2

function printb(text,x,y,c,bc,a)
 local ox=(a==align_c) and #text*2 or
          (a==align_r) and #text*4 or
          0
 local tx=x-ox
  
 for i=tx-1,tx+1 do
  for j=y-1,y+1 do
   print(text,i,j,bc)
  end
 end
 
 print(text,tx,y,c)
end

function mag(x,y)
  local d=max(abs(x),abs(y))
  local n=min(abs(x),abs(y))/d
  return sqrt(n*n+1)*d
end

function normalize(x,y)
  local m=mag(x,y)
  return x/m,y/m,m
end

function polar_to_xy(r,a)
 return r*cos(a),r*sin(a)
end

function dot(x1,y1,x2,y2)
 return x1*x2+y1*y2
end

function reflect(x,y,nx,ny,restitution,friction)
 local d=dot(x,y,nx,ny)
 
 if d>0 then
  return x,y
 end

 local vnx,vny=-d*nx,-d*ny
 local tx,ty=x+vnx,y+vny
 
 local rx,ry=restitution*vnx+friction*tx,restitution*vny+friction*ty
 return rx,ry
end

function mxy(x,y)
 local xx,yy=x%(128*8),flr(x/(128*8))*128+y
 
 return flr(xx/8),flr(yy/8)
end

function si_to_xy(si)
 return si%16*8,flr(si/16)*8
end

function mappixel(x,y)
 if(y<0)return 0
 
 local si=mget(mxy(x,y))
 
 if(not fget(si,0))return 0
 
 local sx,sy=si_to_xy(si)
 
 return sget(sx+x%8,sy+y%8)
end

function raycast(x,y,nx,ny,t)
 local a=atan2(nx,ny)

 local tr=0
 
 while tr<t do
  local px,py=polar_to_xy(tr,a)
  if mappixel(x+px,y+py)==0 then
   tr+=.5
  else
   tr-=.5
   return true,tr
  end
 end

 return false,tr
end

function time_to_text(time)
 local hours,mins,secs,fsecs=flr(time/3600),flr(time/60%60),flr(time%60),flr((time%60)*10)%10
 if(hours<0 or hours>9)return "8:59:59"
 local txt=hours>0 and hours..":" or ""
 txt=txt..((mins>=10 or hours==0) and mins or "0"..mins)
 txt=txt..(secs<10 and ":0"..secs or ":"..secs).."."..fsecs
 return txt
end

function spr_i_to_xy(i)
 return i%16*8,flr(i/16)*8
end

enemy_colors={5}
flashing_colors={5,6,6,6,6,6,6}
punching_colors={0,0,5,5,6,6,6,6}
punching_colors_lines={0,5,5,6,6,6,6}

pdamage_colors={0,0,0,5,5,5,6,6,6,6}

function make_player()

 return
 {
  reset=function(p)
   p.t=0
   p.x=0
   p.y=64
   p.vx=.4
   p.vy=0
   p.snx=1
   p.sny=0
   p.flip=false
   p.onground=false
   p.offground_t=0
   p.cnx=0
   p.cny=0
   p.cm=0
   p.punching_t=0
   p.allow_punch=false
   p.allow_in_air_jump=false
   p.enemies_killed=0
   p.knockback_t=0
   p.shake_ground_t=0
   p.player_hits=0
   p.power=3
   p.powered_t=0
   p.palette_unlocked_t=0
   p.weak_x=0
   p.weak_y=0   
  end,
  
  damage=function(p)
   -- player got hit!
   sfx(2)
   p.player_hits+=1
   p.knockback_t=1
   p.vx=-16
   
   p.power-=1
   
   if p.power<=0 then
    save_game()
    g_gameover=true
    g_gameover_t=2
   end
   
   local x,y=p.x+1,p.y+1
  
   for i=1,16 do
    local vx,vy=.1-rnd(.2),-.2-rnd(.4)
    make_circle(layer_player_fx,.8+rnd(.4),x+2-rnd(4),y+2-rnd(4),vx,vy,12,0,pdamage_colors)
   end 
  
   for j=1,3 do
    for i=1,12 do
     local vx,vy=polar_to_xy(.5+rnd(.5),i/12+rnd(.05))
     make_line(layer_player_fx,1+rnd(.3),x,y,4*vx,4*vy,6,pdamage_colors)
    end 
   end
   
  end,
  
  collision_checks=function(p)
   
   if p.x<0 then
    p.x=0
   elseif p.x>8*(128*4-1) then
    p.x=8*(128*4-1)
   end
   
   --[[]]
   local sx,sy=2,3
   local ttl,ttr=mappixel(p.x-sx,p.y-sy)!=0,mappixel(p.x+sx,p.y-sy)!=0
   local tl,tr,bl,br=mappixel(p.x-sx,p.y)!=0,mappixel(p.x+sx,p.y)!=0,mappixel(p.x-sx,p.y+sy)!=0,mappixel(p.x+sx,p.y+sy)!=0
   
   if tl and tr and bl and br then
    p.y=flr(p.y-2)
   elseif ttl and tl and bl then
    p.x=flr(p.x+1)
   elseif ttr and tr and br then
    p.x=flr(p.x-1)
   elseif tl and bl then
    p.y=flr(p.y-2)
   elseif tr and br then
    p.y=flr(p.y-2)
   elseif bl or br then
    p.y=flr(p.y-1)
   elseif tl or tr then
    p.y=flr(p.y+1)
   end
   --]]
  end,
  
  --[[
  jump=function(p)
   p.punching_t=.2
   p.queue_jump=true
  end,
  --]]
  
  update=function(p)
   p.t+=one_frame
   
   p.knockback_t=max(0,p.knockback_t-one_frame)
   p.punching_t=max(0,p.punching_t-one_frame)
   p.shake_ground_t=max(0,p.shake_ground_t-one_frame)
   p.powered_t=max(0,p.powered_t-one_frame)
   p.palette_unlocked_t=max(0,p.palette_unlocked_t-one_frame)

   if(g_gameover)return
   
   --[[ queued jump
   if p.queue_jump then
    p.queue_jump=false
    p.allow_punch=true
    p.allow_in_air_jump=true
    p.vy=-2
    p.vx=0
   end
   --]]
   
   -- controls
   local cx,cy=0,0
   
   if(btn(0))cx-=1 p.flip=true
   if(btn(1))cx+=1 p.flip=false
   if(btn(2))cy-=1
   if(btn(3))cy+=1

   -- check if on ground
   p.onground=mappixel(p.x-2,p.y+4)!=0 or mappixel(p.x+2,p.y+4)!=0
              
   if p.onground then
    p.allow_punch=true
    
    --[[
    if p.offground_t>.1 and p.vy>1.2 then
     sfx(4)
     p.shake_ground_t=.1
    end
   --]]
   
    p.offground_t=0
   
   else
    p.offground_t+=one_frame
   end

   if cx!=0 or cy!=0 then
    p.snx,p.sny=normalize(p.snx+.1*cx,p.sny+.1*cy)
   end

   -- punching
   if p.punching_t<=0 and punch_b.time_since_press<.1 and p.knockback_t<=.6 then
    punch_b.consume(punch_b)
    
    -- punching direction
     
    sfx(0)
    p.punching_t=.05
    p.allow_punch=false
    
    make_pb(2,p.x+3*p.snx,p.y+3*p.sny,2.5*p.snx,2.5*p.sny)
   
    --[[
    if p.power>=1 then
     local sa=atan2(p.snx,p.sny)
     
     local bnx,bny=polar_to_xy(1,sa+.05)
     make_pb(2,p.x+3*bnx,p.y+3*bny,2.5*bnx,2.5*bny)
    end
    --]]
   end
   
   -- jumping!
   if p.offground_t<.1 or p.allow_in_air_jump then
    if jump_b.time_since_press<.2 then
     sfx(3)
     jump_b.consume(jump_b)
     p.allow_in_air_jump=false
     p.vy=-2.5
    end
   end
   
   --[[ jump particles
   if p.vy<0 and jump_b.time_since_press%.1>.05 then
    local vx,vy=(.4-rnd(.2))*-p.vx,.1+rnd(.3)
    local x,y=p.x+6*vx+1.5-rnd(2),p.y+4-rnd(4)
    make_circle(layer_player_fx,.3+rnd(.15),x,y,vx,vy,1.5,0,punching_colors)   
   end
   --]]
   
   if p.vy<2 then
    p.vy+=.065*one_frame*60
   else
    p.vy=2
   end

   if p.onground then
    p.vx+=.1*cx*one_frame*60
   else
    p.vx+=.01*cx*one_frame*60
   end
   
   local max_x=.6
   
   if p.vx>max_x then
    p.vx-=.5*(p.vx-max_x)*one_frame*60
   elseif p.vx<-max_x then
    p.vx-=.5*(p.vx+max_x)*one_frame*60
   end   
   
   --[[]]
   if p.onground then
    p.vx+=(p.vx>0 and -.02 or .02)*one_frame*60
    if(abs(p.vx)<.01)p.vx=0
   end
   --]]
   
   
   --[[ punching dash and particles
   if p.punching_t>.3 then
    if p.sny<0 then
     p.vy=-2
    elseif p.sny>0 then
     p.vy=3
    elseif p.snx<0 then
     p.vx,p.vy=-3,0
    elseif p.snx>0 then
     p.vx,p.vy=3,0
    end

    for i=1,4 do
     local vx,vy=-p.vx*(.1+rnd(.3))+.1-rnd(.2),-p.vy*(.1+rnd(.3))+.1-rnd(.2)
     local x,y=p.x+5*p.vx+3-rnd(6),p.y+5*p.vy+3-rnd(6)
     make_circle(layer_player_fx,.4+rnd(.2),x,y,vx,vy,4,0,punching_colors)
    end   
   end
   --]]

   local dx,dy=p.vx*one_frame*60,p.vy*one_frame*60
   
   --[[ collision checks]]
   while abs(dx)>0 or abs(dy)>0 do
    local ddx=dx>=1 and 1 or dx<=-1 and -1 or dx
    p.x+=ddx
    p.collision_checks(p)
    dx-=ddx
  
    local ddy=dy>=.5 and .5 or dy<=-.5 and -.5 or dy
    p.y+=ddy
    p.collision_checks(p)
    dy-=ddy  
   end
--]]
    
   p.weak_x,p.weak_y=p.x,p.y+(p.t%.2>.1 and -2 or -1)


   --[[ trail updates
   p.trail_timer-=1/stat(8)
   
   if p.trail_timer<=0 then
    p.trail_timer=.2
    for i=2,#p.trail_x do
     p.trail_x[i-1]=p.trail_x[i]
     p.trail_y[i-1]=p.trail_y[i]
    end 
    
    p.trail_x[#p.trail_x]=p.x
    p.trail_y[#p.trail_y]=p.y
   end
   --]]
  end,
  
  draw=function(p)
   if(g_gameover)return
   
   if(p.knockback_t>0 and t()%.1>.05)return
   
   --[[
   for i=1,#p.trail_x do
    circ(p.trail_x[i],p.trail_y[i],i/2,i<=4 and 6 or 5)
   end    
--]]

   spr(p.t%.2>.1 and 68 or 69,p.x-3+(p.flip and -1 or 0),p.y-4,1,1,p.flip)
   pset(p.weak_x,p.weak_y,t()%.2>.1 and 0 or 6)
   
   local gx,gy=p.x+(p.flip and 1 or 0)+flr(4.9*p.snx),p.y+flr(5*p.sny)
   
   rect(gx-1,gy-1,gx+1,gy+1,0)
   pset(gx,gy,7)
   
   --pset(p.x,p.y,8)
   
   local s=7+180*(g_time_scale-.1)/.9
   local cc=t()%.1>.05 and 0 or 6
   circ(p.x,p.y,s,cc)
   
  end,
 }
end

function explosion(e,m,ox,oy)
 ox=ox or 0
 oy=oy or 0
 
 for i=1,16*m do
  local vx,vy=.1-rnd(.2),-.2-rnd(.4)
  local x,y=e.x+ox+2-rnd(4),e.y+oy+2-rnd(4)
  make_circle(layer_player_fx,.6*m+rnd(.2*m),x,y,vx,vy,4*m,0,punching_colors)
  
  local vx,vy=polar_to_xy(.5+rnd(.5),i/(16*m)+rnd(.1))
  make_line(layer_player_fx,.1*m+rnd(.2*m),x,y,4*vx,4*vy,3*m,punching_colors_lines)
 end
end

--[[]]
function make_pb(t,x,y,vx,vy)
 local l=entities[layer_pbs]
 
 local e=
 {
  t=t,
  x=x,
  y=y,
  vx=vx,
  vy=vy,
  l=l,
  lt=t,
  
  check_hits=function(e,l)
   for k,v in pairs(l) do
    local s=v.boss and 32 or 8
    local oc=v.boss and -16 or 0
    if e.x<=v.x+oc+s and
       e.x>=v.x+oc and
       e.y<=v.y+oc+s and
       e.y>=v.y+oc then     
     local damaged=v.damage(v)
     if damaged then
      del(e.l,e)
      
      explosion(v,v.boss and 3 or .6,4,4)
     end
    end
   end
  end,
  
  update=function(e)
   e.t-=one_frame
   if e.t<=0 then
    del(e.l,e)
   else
    e.x+=e.vx*one_frame*60
    e.y+=e.vy*one_frame*60
    
    if e.t<e.lt-.01 then
     local vx,vy=-e.vx*(.1+rnd(.3))+.1-rnd(.2),-e.vy*(.1+rnd(.3))+.1-rnd(.2)
     local x,y=e.x+2*e.vx+1-rnd(2),e.y+2*e.vy+1-rnd(2)
     make_circle(layer_player_fx,.1+rnd(.05),x,y,vx,vy,2,0,punching_colors)
     e.lt=e.t
    end
    
    -- check enemy hits
    e.check_hits(e,entities[layer_enemies])
    e.check_hits(e,entities[layer_enemy_minions])
    
    -- collision
    if mappixel(e.x,e.y)!=0 then
     del(e.l,e)
     
     local mx,my=mxy(e.x,e.y)
     local si=mget(mx,my)
     if fget(si,2) then
      
      if fget(si,3) then
       p.power+=1
       p.powered_t=2
      end
      
      mset(mx,my,0)
      sfx(1)
      explosion(e,.6,4,4)
     else
      explosion(e,.4)
     end
    end
   end
  end,
 
  draw=function(e)
   --circ(e.x,e.y,2,time()%.2>.1 and 10 or 8)
  end,
 }
 
 --explosion(e,.3)
 make_circle(layer_player_fx,.6+rnd(.2),e.x+2*e.vx,e.y+2*e.vy,0,0,4,0,flashing_colors)
  

 add(l,e)
 
 return e
end
--]]

function make_camera(p)
 return
 {
   p=p,
   x=0,
   y=0,
   spawned_x=-1,
   enemy_count=0,
   
   check_spawn_enemies=function(e)
    if(e.spawned_x>=e.x+128)return

    local sx,sy=e.spawned_x,0
    
    for i=sx,sx+127,8 do
     for j=sy,sy+127,8 do
      local mx,my=mxy(i,j)
      local si=mget(mx,my)
      if fget(si,7) then
       make_enemy(layer_enemies,si,i,j)
       
       mset(mx,my,0)
       e.enemy_count+=1
      end
     end
    end
   
    e.spawned_x=e.x+128
    
   end,
--[[   
   check_clear_level=function(c)
    if c.enemy_count==c.p.enemies_killed then
     for i=c.tx,c.tx+127,8 do
      for j=c.ty,c.ty+127,8 do
       local mx,my=mxy(i,j)
       local si=mget(mx,my)
       if fget(si,7) then
        mset(mx,my,0)
       end
      end
     end
    end
   end,
--]]   

   update=function(c)
    
    local lb=c.p.x-48
    local rb=c.p.x+80
    
    if lb<c.x then
     c.x=lb<0 and 0 or lb
    elseif rb>c.x+128 then
     c.x=rb>8*4*128-1 and 8*4*128-128 or rb-128
    end
    
    c.check_spawn_enemies(c)

   end,
 }
end

function make_ui(cam,p)
 return
 {
  cam=cam,
  p=p,
  game_started=false,
  game_time=0,
  
  update=function(e)
   if btn()!=0 then
    e.game_started=true
   end
   
   if g_gameover then
    g_gameover_t=max(0,g_gameover_t-one_frame)
    
    if g_gameover_t<=0 then
     if btnp(4) or btnp(5) then
      run()
     end
    end
   end
   
   if g_boss_killed then
    g_boss_killed_t=max(0,g_boss_killed_t-one_frame)
    
    if g_boss_killed_t<=0 then
     --g_boss_killed=false
     
     --todo: go to next chapter
     --current_level=max(0,current_level+1)
     --level_kill_all()
     --level_reset()
    end
   end
   
   if e.game_started and not g_gameover and not g_boss_killed then
    e.game_time+=one_frame
   end
  end,
 
  draw_title=function(e,cw,blinkc)
    --fillp(0xf0f0)
    for y=12,23,2 do
     local x=flr(y/2)*3
     line(min(64,x-4+cw),y,max(64,127-x+4-cw),y,6)
     rect(min(64,x-5+cw),y-1,max(64,127-x+5-cw),y+1,0)
    end
    --rectfill(0,17,127,19,6)
    --fillp()
    printb("super contra hot",64,15,0,blinkc,align_c) 
    printb("@picoter8 2019",64,122,0,blinkc,align_c) 
  end,
  
  draw=function(e)
   camera()
   -- hud
   printb("\137:"..p.power,0,1,0,6)
   printb("\130:"..p.enemies_killed,124,1,0,6,align_r)
   printb("-"..time_to_text(e.game_time).."-",64,1,0,6,align_c)
   
   local blinkc=t()%.2>.1 and 6 or 5
   
   -- extra-life message
   if p.powered_t>0 and p.powered_t%.2>.1 then
    printb("-extra-life-",64,15,0,6,align_c) 
   end
   
   -- palette unlocked message
   if p.palette_unlocked_t>0 and p.palette_unlocked_t%.2>.1 then
    printb("-new-palette_unlocked-",64,21,0,6,align_c) 
   end
   
   if e.game_time<.5 then
    local cw=2*2*e.game_time*e.game_time*64
    clip(cw,0,ceil(128-2*cw),128)
    e.draw_title(e,cw,blinkc)
    printb("- chapter 1 -",64,30,0,blinkc,align_c) 
    clip()
   elseif g_gameover then
    local dy=4*sin(t()*.5)
    printb("-game-over-",64,64.5+dy,0,6,align_c)
    
    if g_gameover_t<=1 then
     printb("press \142 or \151",61,76,0,blinkc,align_c)
     printb("to try again",64,82,0,blinkc,align_c)
    end
   elseif g_boss_killed then
    local cw=0
    e.draw_title(e,cw,blinkc)
    clip()
    local dy=4*sin(t()*.5)
    printb("- chapter 1 complete -",64,54.5+dy,0,blinkc,align_c)
    printb("thanks for playing",64,64.5+dy,0,blinkc,align_c)
   end
  end,
 }
end


--[[]]
function make_eb(t,x,y,vx,vy,s)
 local l=entities[layer_ebs]
 
 local e=
 {
  t=t,
  x=x,
  y=y,
  vx=vx,
  vy=vy,
  s=s,
  l=l,
  lt=t,
  
  update=function(e)
   e.t-=one_frame
   if e.t<=0 then
    del(e.l,e)
    explosion(e,.4)
   else
    e.x+=e.vx*one_frame*60
    e.y+=e.vy*one_frame*60
    
    -- check player damage
    if p.knockback_t<=0 and not g_gameover then
     local px,py=p.weak_x,p.weak_y
     
     if px<=e.x+1.5 and
        px>=e.x-1.5 and
        py<=e.y+1.5 and
        py>=e.y-1.5 then
      p.damage(p)
      del(e.l,e)
     end
    end
    
    -- collision
    if mappixel(e.x,e.y)!=0 then
     del(e.l,e)
     explosion(e,.4)
    end
   end
  end,
 
  draw=function(e)
   circfill(e.x,e.y,s+1,time()%.2>.1 and 0 or 6)
   circfill(e.x,e.y,s,time()%.2>.1 and 6 or 0)
  end,
 }
 
 add(l,e)
 
 return e
end
--]]

function e_ground_runner(e)
 if mappixel(e.x+3,e.y+4)!=0 then
  e.vy=0 e.y=flr(e.y-2)
 elseif mappixel(e.x+3,e.y+5)!=0 then
  e.vy=0 e.y=flr(e.y-1)
 elseif e.vy<0 and mappixel(e.x+3,e.y+1)!=0 then
  e.vy=0 e.y=flr(e.y)
 elseif e.vy<0 and mappixel(e.x+3,e.y+0)!=0 then
  e.vy=0 e.y=flr(e.y+1)
 end
 
 if((e.x<p.x-64 or e.x<=0 or mappixel(e.x,e.y-2)!=0) and e.vx<0)e.vx=-e.vx
 if((e.x>p.x+64 or mappixel(e.x+7,e.y-2)!=0) and e.vx>0)e.vx=-e.vx
end

function e_bouncer(e,vy)
 if e.vy>0 then
  if(mappixel(e.x,e.y+6)!=0)e.vy=vy e.vx=rnd()>.5 and -e.vx or e.vx
 else
  if(mappixel(e.x,e.y)!=0)e.vy=vy e.vx=rnd()>.5 and -e.vx or e.vx
 end
end

function e_draw_anim1(e)
 spr(e.si,e.x,e.y,1,1,e.vx and e.vx>0)
end
--[[
function e_draw_anim2(e)
 e.anim_i=flr(e.si+8*e.t%2)
 spr(e.anim_i,e.x,e.y,1,1,e.vx and e.vx>0)
end
--]]
function e_draw_anim3(e)
 e.anim_i=flr(e.si+8*e.t%3)
 spr(e.anim_i,e.x,e.y,1,1,e.vx and e.vx>0)
end

function e_draw_anim3_nomirror(e)
 e.anim_i=flr(e.si+8*e.t%3)
 spr(e.anim_i,e.x,e.y)
end

function make_spread_turret(count,speed,lifetime)
 return
 {
  init=function(e)
   --e.a=e.x%128/128
   e.nt=e.t+3--+e.a
  end,
  
  update=function(e)
   if e.t>=e.nt then
    e.nt=e.t+3--+e.a
    
    for i=1,count do
     local nx,ny=polar_to_xy(speed,i/count)
     make_eb(lifetime,e.x+4,e.y+4,nx,ny,1)
    end
   end
  end,
  
  draw=e_draw_anim3,
 }
end

function make_ground_runner()
 return
 {
  init=function(e)
   e.vx=-.2-rnd(.2)
   e.vy=0
  end,
  
  update=function(e)
   if p.vy<2 then
    e.vy+=.065*one_frame*60
   else
    e.vy=2
   end
   
   e.x+=e.vx*one_frame*60
   e.y+=e.vy*one_frame*60
   
   e_ground_runner(e)
  end,
  
  draw=e_draw_anim3,
 }
end

enemy_types=
{
 [74]=make_spread_turret(6,.4,5),
 
 [77]=make_ground_runner(), -- bean roller
 
 [90]= -- target player turret
 {
  init=function(e)
   e.nt=e.t+3+rnd(3)+e.x%128/128
   e.nx,e.ny,e.m=normalize(p.x-e.x-4,p.y-e.y-4)
  end,
  
  update=function(e)
   e.nx,e.ny,e.m=normalize(p.x-e.x-4,p.y-e.y-4)
   
   if e.t>=e.nt then
    e.nt=e.t+3+rnd(3)+e.x%128/128
    
    local speed=.4
    make_eb(5,e.x+4,e.y+4,speed*e.nx,speed*e.ny,1)
   end
  end,
  
  draw=function(e)
   e_draw_anim1(e)
   circfill(e.x+3.5+1.5*e.nx,e.y+3.5+1.5*e.ny,1,7)
  end
 },
 
 [93]= -- runner bouncer
 {
  init=function(e)
   e.a=.0075+rnd(.01)
   e.vx=-.1-rnd(.1)
   e.vy=0
  end,
  
  update=function(e)
   e.vy+=e.a*one_frame*60
   
   e.x+=e.vx*one_frame*60
   e.y+=e.vy*one_frame*60

   e_ground_runner(e) 
    
   if rnd()>.95 then
    e_bouncer(e,-.75)
   end
  end,
  
  draw=e_draw_anim3,
 },
 
 
--[[ player seeker ]]
 [106]=
 {
  init=function(e)
   e.a=.0075+rnd(.01)
   e.maxv=.4+rnd(.5)
   
   e.vx,e.vy=0,0
  end,
  
  update=function(e)
   local nx,ny=normalize(p.x-e.x,p.y-e.y)
   
   e.vx+=nx*e.a*one_frame*60
   e.vy+=ny*e.a*one_frame*60
   
   local nx,ny,m=normalize(e.vx,e.vy)
   
   if m>e.maxv then
    e.vx=e.maxv*nx
    e.vy=e.maxv*ny
   end
   
   e.x+=e.vx*one_frame*60
   e.y+=e.vy*one_frame*60
  end,
  
  draw=e_draw_anim3,
 },
--]] 
 
 [122]= -- bouncer
 {
  init=function(e)
   e.a=.0075+rnd(.01)
   e.vx=.2-rnd(.4)
   e.vy=0
  end,
  
  update=function(e)
   e.vy+=e.a*one_frame*60
   
   e.x+=e.vx*one_frame*60
   e.y+=e.vy*one_frame*60

   e_bouncer(e,-e.vy)
  end,
  
  draw=e_draw_anim3_nomirror,
 },
 
 [125]= -- vertical sinwave flyer
 {
  init=function(e)
   e.by=e.y
   e.vx=0
   e.vy=0
  end,
  
  update=function(e)
   e.y=e.by+8*sin(e.t/3)
  end,
  
  draw=e_draw_anim3,
 },
 
 --[[
 [93]=
 {
  init=function(e)
   e.nx,e.ny,e.r=normalize(cam.spawned_x+64-e.x-4,cam.spawned_y+64-e.y-4)
   e.a=atan2(e.nx,e.ny)
   e.update(e)
  end,
  
  update=function(e)
   e.a+=.001*one_frame*60
   local x,y=polar_to_xy(e.r*sin(4*e.a),e.a)
   e.x,e.y=cam.spawned_x+64+x-4,cam.spawned_y+64+y-4
  end
 },
 --]]
 
 [70]= -- boss 1
 {
  
  init=function(e)
   e.boss=true
   e.health=5
   
   local level=(6-e.health)/5
   e.speed=.2/level
   
   e.minions={}
  
   --shooting
   e.nt=e.t+1
   
   --base movement
   e.bx,e.by=e.x,e.y
   e.vx,e.vy=0,0
   
   --minions
   e.et.spawn_minions(e)
  end,
  
  spawn_minions=function(e)
   local level=6-e.health
   local si=24
   for j=1,3 do
    for i=1,si do
     --local r,a=20+4*j+8*sin(level*i/si),i/si
     local r,a=20+8*j,i/si
     local x,y=polar_to_xy(r,a)
     local ec=make_enemy(layer_enemy_minions,101,e.x+x,e.y+y,e)
     ec.r,ec.a=r,a
     
     add(e.minions,ec)
    end
   end
  end,
  
  update=function(e)
   -- movement
   e.x=e.bx+40*sin(e.t/9)
   e.y=e.by+16*sin(e.t/3)
  
   -- shooting
   if e.t>=e.nt then
    
    e.nt=e.t+.5+1.5*e.health/5+rnd()
    
    local speed=.4
    for i=1,12 do
     local nx,ny=polar_to_xy(speed,i/12)
     make_eb(5,e.x,e.y,nx,ny,1)
    end
   end

  end,
  
  draw=function(e)
   local sprx,spry=spr_i_to_xy(e.t%e.speed>(e.speed*.5) and 70 or 72)
   local c,s=cos(1.5*e.t/e.speed),sin(1.5*e.t/e.speed)
   sspr(sprx,spry,16,16,e.x-14-1.5*c,e.y-16-1.5*s,32+3*c,32+3*s)
  
   
   --spr(70,e.x-6,e.y-8,2,2)
   --circfill(e.x+4,e.y+4,8,0)
   --circ(e.x+4,e.y+4,6,7)
   
   --pset(e.x,e.y,8)
   --print(""..e.health,e.x,e.y,8)
   
  end,
 },
 
 [101]= -- minions
 {
  update=function(e)
   
   local offr=e.ep.blink_t and (1-e.ep.blink_t/3) or 1
   
   local level=6-e.ep.health
   
   local x,y=polar_to_xy(offr*e.r+offr*12*sin(e.a+level*e.ep.t*.1),e.a+level*e.ep.t*.02)
   e.x,e.y=e.ep.x+x,e.ep.y+y
  end,
  
  draw=function(e)
   spr(100,e.x,e.y,1,1,e.t%e.ep.speed>(e.ep.speed*.5))
   --circfill(e.x+4,e.y+4,3,0)
   --circ(e.x+4,e.y+4,2,7)  
  end,
 },
}

--[[
function explode_enemy(ex,ey)
 for i=1,16 do
  local vx,vy=.1-rnd(.2),-.2-rnd(.4)
  local x,y=ex+2+rnd(4),ey+2+rnd(4)
  make_circle(layer_player_fx,.8+rnd(.2),x,y,vx,vy,4,0,punching_colors)
 end 

 for j=1,2 do
  for i=1,12 do
   local x,y=ex+4,ey+4
   local vx,vy=polar_to_xy(.5+rnd(.5),i/12+rnd(.05))
   make_line(layer_player_fx,.5+rnd(.3),x,y,4*vx,4*vy,4,punching_colors_lines)
  end 
 end    
end
--]]

function make_enemy(el,si,x,y,ep)
 
 local mx,my=mxy(x,y)
 local mi=my*128+mx
 
 local l=entities[el]
 
 if(ep==nil and l[mi])return
 
 local e=
 {
  l=l,
  et=enemy_types[si],
  mi=mi,
  anim_i=mi,
  si=si,
  t=x/64+y/32,
  lt=x/64+y/32,
  x=x,
  y=y,
  ep=ep,
  
  damage=function(e)
   if e.blink_t and e.blink_t>0 then
    return false
   end
   
   local killed=true
   
   if e.health and e.health>0 then
    e.health-=1
    
    e.blink_t=3
    
    --[[]]
    if e.minions then
     for k,v in pairs(e.minions) do
      v.damage(v)
     end
    end
    --]]
     
    if e.health>0 then
     killed=false
    
     if e.minions then
      e.et.spawn_minions(e)
     end
    end
   end
   
   if killed then
    if e.ep then
     del(e.l,e)
    else
     p.enemies_killed+=1
     
     if ss_max_enemies_killed<p.enemies_killed then
      ss_max_enemies_killed=p.enemies_killed
      if(ss_max_enemies_killed%100==0)p.palette_unlocked_t=2
     end
     
     e.l[e.mi]=nil
    
     if e.boss then
      save_game()
      
      g_boss_killed=true
      g_boss_killed_t=5
     end
    
    end
   end 
    
   sfx(1)
   return true
  end,
  
  update=function(e)
   --if(g_hit_enemy)return

   if e.x<p.x-256 or e.x>p.x+256 then
    return
   end

   if e.blink_t and e.blink_t>0 then
    e.blink_t=max(0,e.blink_t-one_frame)
   end

   e.t+=one_frame
   
   if(e.et and e.et.update)e.et.update(e)
   
   --[[
   if e.t>e.lt+.1 then
    local vx,vy=.1-rnd(.2),-.2-rnd(.4)
    local xx,yy=e.x+4+cos(e.t),e.y+2+sin(e.t)
    make_circle(layer_player_fx,.2+rnd(.2),xx,yy,vx,vy,2.2,0,enemy_colors)
    e.lt=e.t
   end
   --]]
   
   local damages_player=not fget(e.si,6)
   
   -- player not knocked back
   if p.knockback_t<=0 and damages_player and not g_gameover then
    
    local px,py=p.weak_x,p.weak_y
    if px<=e.x+6 and
       px>=e.x+1 and
       py<=e.y+6 and
       py>=e.y+1 then
     p.damage(p)
    end
     
    --[[
    local px,py,px2,py2=0,p.y-2,0,p.y+2
    if p.flip then
     px,px2=p.x-2,p.x+2
    else
     px,px2=p.x,p.x+4
    end
    
    if px<=e.x+6 and
       px2>=e.x+1 and
       py<=e.y+6 and
       py2>=e.y+1 then
     
     p.damage(p)
    end
    --]]
   end
  end,
 
  draw=function(e)

   if e.blink_t and e.blink_t>0 then
    if(e.blink_t%.2>.1)return
   end
  
   if e.et and e.et.draw then
    e.et.draw(e)
   else
    e_draw_anim3(e)
   end
   
   --[[ debug hitboxes
   local s=e.boss and 32 or 8
   local oc=e.boss and -16 or 0
   rect(e.x+oc,e.y+oc,e.x+oc+s,e.y+oc+s,8)
   --]]
  end,
 }
 
 if(e.et and e.et.init)e.et.init(e)
 
 --[[ spawn particles
 local xx,yy=e.x+4,e.y+4
 
 for i=1,8 do
  local vx,vy=polar_to_xy(.75,i/8+x/640+y/320)
  make_circle(layer_player_fx,.3,xx,yy,vx,vy,6,0,enemy_colors) 
 end
 --]]
 
 if ep==nil then
  l[mi]=e
 else
  -- enemies with parents get added to a flat list
  add(l,e)
 end
 
 return e
end

function make_circle(el,t,x,y,vx,vy,s1,s2,colors,outlined)
 local l=entities[el]
 
 local e=
 {
  tt=t,
  t=t,
  x=x,
  y=y,
  vx=vx,
  vy=vy,
  s1=s1,
  s2=s2,
  sc=s1,
  l=l,
  colors=colors,
  outlined=outlined,
  
  update=function(e)
   --if(g_hit_enemy)return
  
   e.t-=one_frame
   if e.t<=0 then
    del(e.l,e)
   else
    e.sc+=one_frame*(e.s2-e.s1)/e.tt
    e.x+=e.vx*one_frame*60
    e.y+=e.vy*one_frame*60
   end
  end,
 
  draw=function(e)
   local ci=flr(1+#e.colors*(1-e.t/e.tt))
   local c=outlined and circ or circfill
   c(e.x,e.y,e.sc,e.colors[ci])
  end,
 }
 
 add(l,e)
 
 return e
end

function make_line(el,t,x,y,vx,vy,s,colors)
 local l=entities[el]
 
 local e=
 {
  tt=t,
  t=t,
  x=x,
  y=y,
  vx=vx,
  vy=vy,
  s=s,
  l=l,
  colors=colors,
  
  update=function(e)
   --if(g_hit_enemy)return
  
   e.t-=one_frame
   if e.t<=0 then
    del(e.l,e)
   else
    e.x+=e.vx*one_frame*60
    e.y+=e.vy*one_frame*60
   end
  end,
 
  draw=function(e)
   local ci=flr(1+#e.colors*(1-e.t/e.tt))
   local ci2=min(#e.colors,flr(2+#e.colors*(1-e.t/e.tt)))
   line(e.x,e.y,e.x+2*e.s*e.vx,e.y+2*e.s*e.vy,e.colors[ci2])
   line(e.x,e.y,e.x+e.s*e.vx,e.y+e.s*e.vy,e.colors[ci])
  end,
 }
 
 add(l,e)
 
 return e
end

function make_button(bi)
 return 
 {
  time_since_press=100,
  last_time_held=0,
  time_held=0,
  time_released=0,
  button_index=bi,

  update=function(b)
   b.time_since_press+=one_frame

   if btn(b.button_index) then
    if b.time_held==0 then
     b.time_since_press=0
    end
  
    b.time_held+=one_frame
   else
    if(b.time_held!=0)b.time_released=0
    b.last_time_held=b.time_held
    b.time_held=0
    b.time_released+=one_frame
   end
  end,

  consume=function(b)
   b.time_since_press=100
  end,
 }
end

layer_buttons,layer_player_fx,layer_player,layer_pbs,layer_enemies,layer_enemy_minions,layer_ebs,layer_camera,layer_ui=1,2,3,4,5,6,7,8,9

entities={}

entities[layer_buttons]={}
entities[layer_player_fx]={}
entities[layer_player]={}
entities[layer_pbs]={}
entities[layer_enemies]={}
entities[layer_enemy_minions]={}
entities[layer_ebs]={}
entities[layer_camera]={}
entities[layer_ui]={}

--g_hit_enemy=nil
--g_hit_enemy_t=0

g_pal_sel=false


pal_sels=
{
 {name="default",     indices={0x00,0x05,0x06,0x07}},
 {name="greens",      indices={0x03,0x8b,0x0b,0x8a}},
 {name="mocha",       indices={0x80,0x84,0x04,0x8f}},
 {name="dusty",       indices={0x85,0x05,0x86,0x06}},
 {name="demonic",     indices={0x00,0x02,0x88,0x08}},
 {name="hellfire",    indices={0x88,0x08,0x89,0x09}},
 {name="grapefruit",  indices={0x89,0x09,0x8f,0x0f}},
 {name="blues",       indices={0x81,0x01,0x8c,0x0c}},
 {name="negative",    indices={0x06,0x86,0x05,0x85}},
 {name="acid",        indices={0x01,0x8b,0x08,0x87}},
 {name="chocolate",   indices={0x04,0x84,0x80,0x00}},
}

pal_sel_max=1
pal_sel_index=1


function pal_sel_menu()
 g_pal_sel=true
 pal_sel_max=min(flr(1+ss_max_enemies_killed/100),#pal_sels)
end

function pal_sel_update()
 if(btnp(2))pal_sel_index=max(1,pal_sel_index-1)
 if(btnp(3))pal_sel_index=min(pal_sel_max,pal_sel_index+1)
 
 if btnp(4) or btnp(5) then
  g_pal_sel=false
 end
end

function pal_sel_set()
 pal()
 
 local cp=pal_sels[pal_sel_index].indices
 pal(14,cp[1],1)
 pal(0,cp[1],1)
 pal(5,cp[2],1)
 pal(6,cp[3],1)
 pal(7,cp[4],1)
end

function pal_sel_draw()
 pal_sel_set()
 
 local x,y=32,32
 
 local rx1,ry1,rx2,ry2=x-4,y-6,x+66,y+pal_sel_max*7+10
 
 rect(rx1-1,ry1-1,rx2+1,ry2+1,6)
 rect(rx1+1,ry1+1,rx2-1,ry2-1,6)
 rect(rx1,ry1,rx2,ry2,0)
 
 printb("- palettes -",x+8,y-1,0,6)
 
 
 
 for i=1,pal_sel_max do
  local p=pal_sels[i]
  local name=(i==pal_sel_index) and ">"..p.name or " "..p.name
  --print(name,x,y+i*7-1,5)
  printb(name,x+8,y+i*7+1,0,6)
 end
end

function _init()
 menuitem(1,"palette",pal_sel_menu)
 menuitem(2,"reset progress!?",reset_game)
 
 music(0)
 
 punch_b=make_button(5)
 add(entities[layer_buttons],punch_b)
 jump_b=make_button(4)
 add(entities[layer_buttons],jump_b)
 
 p=make_player()
 p.reset(p)
 add(entities[layer_player],p)
 
 cam=make_camera(p)
 add(entities[layer_camera],cam)
 
 ui=make_ui(cam,p)
 add(entities[layer_ui],ui)

 background={}
 background2={}
 
 -- background
 for i=1,100 do
  add(background,{x=rnd(128),y=rnd(128),vx=1+rnd(3)}) 
 end
 
 for i=1,20 do
  add(background2,{x=rnd(128),y=rnd(128),vx=.1+rnd(.9)}) 
 end

 load_game()
end

current_level=0

function level_kill_all()
 entities[layer_enemies]={}
 entities[layer_enemy_minions]={}
 entities[layer_ebs]={}
end

function level_reset()
 
 p.reset(p)
 
 if current_level==0 then
  reload(0,0,0x6000,"superpicodehot.p8.lua")
 elseif current_level==1 then
  reload(0,0,0x6000,"spdh-2.p8.lua")
 elseif current_level==2 then
  reload(0,0,0x6000,"spdh-3.p8.lua")
 else
  reload(0,0,0x6000,"spdh-4.p8.lua")
 end
end

function background_draw()
 if current_level==0 then
  for k,v in pairs(background) do
   line(v.x,v.y,v.x+v.vx*5,v.y,6)
  end
  
  fillp(0b1010010110100101.1)
  for k,v in pairs(background2) do
   circfill(v.x,v.y,v.vx*18,6)
  end
  fillp()
 elseif current_level==1 then
  for k,v in pairs(background) do
   line(v.y,128-v.x,v.y,128-v.x+v.vx*3,6)
  end
 else
  fillp(0b1010010110100101.1)
  for k,v in pairs(background) do
   rectfill(v.x,v.y,v.x+v.vx*10,v.y+v.vx*4,6)
  end
  fillp()
  
  for k,v in pairs(background2) do
   rectfill(v.x,v.y,v.x+v.vx*18,v.y+v.vx*8,6)
  end
 end
end

function _update60()
 if g_pal_sel then
  pal_sel_update()
  return
 end
 
 if g_gameover then
  g_time_scale=1
 else
  if btn(0) or btn(1) or btn(2) or btn(3) then
   if(g_time_scale<1)g_time_scale=min(1,g_time_scale+.05)
  else
   if(g_time_scale>.1)g_time_scale=max(.1,g_time_scale-.1)
  end
 end
 
 one_frame=g_time_scale/stat(8)
 
 --[[
 if g_time_scale<=.1 then
  for sfx=10,14 do
   sfx_set_speed(sfx,28)
  end
 else
  for sfx=10,14 do
   sfx_set_speed(sfx,14)
  end
 end
 --]]
 
 --[[
 if g_hit_enemy then
  g_hit_enemy_t-=one_frame
  if(g_hit_enemy_t<=0)g_hit_enemy=nil
 end
 --]]
 
 for k,v in pairs(background) do
  v.x-=(v.vx+rnd())*one_frame*60
  if v.x<-v.vx*10 then
   v.x,v.y=128,rnd(128)
  end
 end

 for k,v in pairs(background2) do
  v.x-=(v.vx+rnd())*one_frame*60
  if v.x<-v.vx*18 then
   v.x,v.y=128+v.vx*18,rnd(128)
  end
 end

 for i=1,#entities do 
  for k,v in pairs(entities[i]) do
   if(v.update)v.update(v)
  end
 end
 
 --[[debug teleport
 if btnp(0,1) then
  p.x-=128
  level_kill_all()
 elseif btnp(1,1) then
  p.x+=128
  level_kill_all()
 end
 
 if btnp(2,1) then
  current_level=max(0,current_level-1)
  level_kill_all()
  level_reset()
 elseif btnp(3,1) then
  current_level=min(3,current_level+1)
  level_kill_all()
  level_reset()
 end 
 --]]
end

function _draw()
 cls(7)

 pal_sel_set()
  
 camera()
 
 background_draw()
 
 local camx,camy=cam.x,cam.y
 if(p.knockback_t>.8 or p.shake_ground_t>0)camx+=1-rnd(2) camy+=1-rnd(2)

 camera(camx,camy)
 --[[
 pal(7,5)pal(4,1)
 pal(11,5)pal(3,1)
 map(0,0,1,1,128,64,0x01)
--]]
 --pal()
 
 --pal(5,7)
 --map cel_x cel_y sx sy cel_w cel_h [layer]
 map(0,0,0,0,128,16,0x03)
 map(0,16,128*8,0,128,16,0x03)
 map(0,32,128*16,0,128,16,0x03)
 map(0,48,128*24,0,128,16,0x03)
 --pal(5,5)

 --camera()
 --if(p.enemies_killed<cam.enemy_count)rect(0,0,63,63,8)
 --camera(camx,camy)


 for i=1,#entities do 
  for k,v in pairs(entities[i]) do
   if(v.draw)v.draw(v)
  end
 end
 
 camera()
 
 if g_pal_sel then
  pal_sel_draw()
 end 
 
 --[[
 y=122
 color(0)
 --print("ek/ec:"..p.enemies_killed.."/"..cam.enemy_count,0,0,7)
 --print("mem:"..stat(0),0,0,0)
 --printb("cpu:"..stat(1),1,y,0,6)
 --print("d:"..p.snx..","..p.sny,0,0,7)
 --print("c:"..cam.tx..","..cam.ty,0,0,7)
 --print("v:"..p.vx..","..p.vy,0,6,0)
 printb("p:"..p.x..","..p.y,1,y,0,6)
 
 --local sx,sy=cam.spawned_x%(8*128),flr(cam.spawned_x/(8*128))*128 
 --print("sc:"..sx..","..sy,0,12,0)
 --]]
end
