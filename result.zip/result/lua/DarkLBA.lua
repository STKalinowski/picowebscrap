-- darklba
-- fred yael
--------------------------------------------------------------
kids_count = 20
opt_difficulty = 2
opt_cursor = 1
--
activity = 0 -- 0:bumper, 1:menu, 2:game
gstate = 0 -- 0:init, 1:play, 2:gameover, 3:gamewin
exitfx = 0
--
camx = 7.5
camy = 7.5
opt_camera = 1 -- 1:edges scroll, 2:player centered, 0:fix
entitylist = {}
-- map 
starty = 24
sizey = 84
offsetx = 56
offsety = starty + sizey/2 + 4
bottom = starty+sizey-1
scrollx = 0
scrolly = 0
scrolldx = 0.0
scrolldy = 0.0
-- system
frame = 0
firedown = 0
dirangle = { 0.5, 0.75, 0.625, 0.0, 0, 0.875, 0, 0.25, 0.375, 0,  0, 0.125, 0, 0, 0 }
btntoangle_relative = { 0.25, 0.75, 0, 0.5, 0.375, 0.625, 0, 0.0, 0.125, 0.875, 0, 0, 0, 0, 0, 0 }
btntoangle_screen = { 0.125, 0.625, 0, 0.375, 0.25, 0.5, 0, 0.875, 0.0, 0.75, 0, 0, 0, 0, 0, 0 }
btntoangle = btntoangle_relative

function _init()
	initdrops()
	--music(0)
end

function initgame()	
	entitylist = {}
	deleteentitylist = {}
	liftlist = {}
	w_emap = {}		-- y0{ x0{ {entity}, {entity}, {entity}, ... }, x1{...} }, y1{...}
	w_dmap = {}		-- y0{ x0{ player direction, player direction, ... }, x1{...} }, y1{...}	
	kids_saved = 0
	kids_found = 0
	kids_dead = 0
	bcount = 0
	zombies_dead = 0
	zombies_count = 0
	player = player_create()
	if opt_difficulty > 1 then
		zombies_count = opt_difficulty * 5
		for n = 1, zombies_count do
			local zombie = zombie_create()
			mx, my = getgroundpos( irnd( 64 ) + 0.5, irnd( 32 ) + 0.5 )
			entity_moveto( zombie, mx, my )
			add( entitylist, zombie )
		end
	end
	if gstate==0 then -- default map
		mx,	my = getgroundpos( 3.5, 3.5 )
		entity_moveto(player, mx, my)
		kids_count =  5 + (5-opt_difficulty) * 5
		local x, y
		for y = 0, 31 do
			for x = 0, 63 do
				local t = w_tget( x, y )
				if t == 66 then
					local z = w_zget( x, y )
					add( liftlist, {	x = x, y = y, down = band(z, 15), up = band(z, 240) / 16 } )
				end
			end
		end
	else
		entity_moveto(player, exitx, exity) 		
	end
	gstate = 1
	camx = player.x
	camy = player.y
end

function player_create()
	local this = new_entity( 1, 192, nil, nil )
	this.speed = 3.0 / 30.0
	this.maxlifepoints = 10
	this.lifepoints = 10
	return this
end
function getgroundpos( mx, my )
	local t = w_tget( mx, my )
	while t != 68 and t != 70 do
		mx = irnd( 64 ) + 0.5
		my = irnd( 32 ) + 0.5
		t = w_tget( mx, my )
	end
	return  mx, my
end
function getmappos( mx, my, t )
	while (w_tget( mx, my ) != t ) do
		mx = irnd( 64 ) + 0.5
		my = irnd( 32 ) + 0.5
	end
	return  mx, my
end
-- sprite
function sprite_draw(this, dx, dy, wz)
	if (this.z > wz)	spr(this.shadow, dx - 4, dy - 5)
	spr( this.sprite, dx - 4, dy - 8 - (flr(this.z)-wz))
end

function sprite_character_draw(this, dx, dy, wz)
	if (this.z > wz)	spr(this.shadow, dx - 4, dy - 5)	-- shadow
	local si = this.sprite
	if this.kind == 2 then -- zombie
		local t = w_tget( this.x, this.y )
		if t == 64 and this.ismoving == 1 then
			si += -16 + 2
		end
	end
	if this.ismoving>0 then
		si += 16
		if (this.back) si += 16 
	end
	if (band( frame + this.oframe, 8 ) == 8) 	si += 1
	spr(si, dx - 4, dy - 8 - (flr(this.z)-wz), 1, 1, this.flip)	
end

function irnd(v)
	return flr(rnd(v))
end

function deltaangle( a0, a1 )
	a0 %= 1.0
	a1 %= 1.0
	local d = a1 - a0
   	if d <= -0.5 then
	    d += 1.0
    elseif d >= 0.5 then
    	d -= 1.0
	end
	return d
end

-- entity
function new_entity( p_kind, p_sprite, p_move, p_ontrigger )
	local this = {
		kind = p_kind,		-- 1:player 2:zombie 3:ball 4:kid 5:dead_kid
		sprite = p_sprite,
		shadow = 255,
		speed = 0.0,
		autoclimb = 2.0,
		swimable = 0,
		move = p_move,
		ontrigger = p_ontrigger,
		draw = sprite_character_draw,
		efollow = player,
		distancetrigger = 1.0,
		holdkid = nil,
		waitframe = 0,
		oframe = irnd( 10 ),
		ismoving = 0,
		angle = 0.0,
		x = 0,
		y = 0,
		z = 0,
		sx = -999,
		sy = -999
	}
	return this
end

function entity_wait_screen( this )
	if (this.sx != -999 and this.sy != -999)	this:ontrigger()
end

function maskframe( m )
	if (band( frame, m ) == m)	return true
	return false
end

function entity_wait_frame( this )
	entity_falling( this )
	if (frame >= this.waitframe)this:ontrigger()
	if this.holdkid then
		if maskframe( 31 ) then
			sfx(1) --kid scream
			addparticle( 3, this.holdkid.sx, this.holdkid.sy - 4 )	
		end
	end
end

function entity_wait_contact( this )
	if not entity_falling( this ) then
		local dx = this.x - this.efollow.x
		local dy = this.y - this.efollow.y
		local d = sqrt( dx*dx + dy*dy )
		if (d < this.distancetrigger) 	this:ontrigger()
	end
end

function entity_restore_move( this )
	this.move = this.memomove
end

function entity_teleport(this)
	this.z += 0.5
	exitfx = 1
	if this.z > 80 then
		bcount -= 1
		if (bcount==0)	sfx(-2,3) --beam off
		add( deleteentitylist, this )
		remove_map_entity( this )
	end
end

function entity_falling( this )
	local cx = flr(this.x)
	local cy = flr(this.y)
	local wz = w_zget(cx, cy)
	if this.z > wz then
		this.z -= 2.0
		if (this.z <= wz)	this.z = wz
		return true
	else
		this.z = wz	-- can't be inside so on top
		return false
	end
end

function entity_move(this, ang )
	ang %= 1.0
	this.angle = ang
	local dx = this.speed * sin( ang )
	local dy = this.speed * cos( ang )
	nx = flr(this.x + dx)
	ny = flr(this.y + dy)
	if nx < 0 or nx > 63 then
		dx = 0
		nx = flr(this.x)
	end
	if ny < 0 or ny > 31 then
		dy = 0
		ny = flr(this.y)
	end
	local cx = flr(this.x)
	local cy = flr(this.y)
	if dx != 0 or dy != 0 then
		local cz = flr(this.z)
		local ac = this.autoclimb
		local swim = this.swimable
		-- if this.climbable == 1 then
			-- if this.isclimbing == 0
			-- if w_zget(nx, ny) - cz > ac then
				-- this.isclimbing = 1
				-- dx = 0
				-- dy = 0
		-- if this.isclimbing == 1
			-- this.z += 0.01 ?
			-- cz = flr(this.z)
			-- if w_zget(nx, ny) <= cz
				-- this.isclimbing = 0
		-- 
		testedtile = w_tget(nx, ny)
		if (swim == 0 and testedtile == 64) or w_zget(nx, ny) - cz > ac then
			if ((swim == 0 and w_tget(nx, cy) == 64) or w_zget(nx, cy) - cz > ac)	dx = 0
			if ((swim == 0 and w_tget(cx, ny) == 64) or w_zget(cx, ny) - cz > ac)	dy = 0
		end
	end
	entity_setdirectionangle( this, ang )
	if dx != 0.0 or dy != 0.0 then
		this.ismoving = 1
		entity_moveto(this, this.x + dx, this.y + dy)
	else
		this.ismoving = 0
	end
end
function entity_moveto(this, x, y)
	local nxi = flr( x )
	local nyi = flr( y )
	local xmap = w_emap[nyi]
	if xmap == nil then
		xmap = { }
		w_emap[nyi] = xmap
	end
	remove_map_entity( this )
	if (xmap[nxi] == nil)	xmap[nxi] = { }
	-- need table insert  for sort
	add( xmap[nxi], this )
	this.x = x
	this.y = y
end
function entity_setdirectionangle( this, angle )
	this.flip = (angle >= 0.375) and (angle < 0.875)
	this.back = (angle >= 0.25) and (angle < 0.75)
end
-- kids
function kid_create(trfunc)
	local this = new_entity( 4, 198, entity_wait_contact, kid_touched )
	this.speed = rnd( 0.02 ) + (0.008 * (6-opt_difficulty))
	this.isheld = false
	return this
end
function kid_touched(this)
	this.move = kid_follow
	drawinfo()
end
function kid_follow(this)
	local trgt = this.efollow
	local ang = 0.0
	local dx = this.x - trgt.x
	local dy = this.y - trgt.y
	local d = sqrt( dx*dx + dy*dy )	
	local dir = w_dget( this.x, this.y )
	if dir != nil then
		ang = this.angle + deltaangle( this.angle, dirangle[dir] ) * 0.08
		-- ang = dirangle[dir]
	else
		ang = atan2( trgt.y - this.y, trgt.x - this.x  )
	end
	if entity_falling(this)==false and d>this.distancetrigger then
		this.ismoving = 1
		entity_move( this, ang )
		if w_tget(this.x,this.y)==106 and this.isheld==false then	-- exit
			sfx(8,3) --beam on
			bcount += 1
			sfx(9)--jingle ? kid safe
			kids_saved += 1
			this.move = entity_teleport
			this.shadow = 0
			this.x = flr(this.x) + 0.5
			this.y = flr(this.y) + 0.5
			drawinfo()
		end		
	else
		this.ismoving = 0
	end
end
--------------------------------------------------------------
-- zombies
function zombie_create()
	local this = new_entity(2,194,entity_wait_screen,zombie_start)
	this.speed = rnd(0.03) + (opt_difficulty*0.01) - 0.02
	this.autoclimb = 4.0
	this.swimable = 1
	this.killable = false
	this.z = 200 + rnd(50)
	return this
end

function zombie_start(this)
	this.move = zombie_follow
	this.distancetrigger = 0.5
end

function zombie_gen()
	local zombie = zombie_create()
	entity_moveto(zombie,player.x+irnd(12)-6,player.y+irnd(12)-6)
	add(entitylist,zombie)
end

function zombie_follow( this )
	local trgt = this.efollow
	local ang = 0.0
	local dir = w_dget( this.x, this.y )
	local dx = this.x - trgt.x
	local dy = this.y - trgt.y
	local d = sqrt( dx*dx + dy*dy )
	if dir != nil then -- and d >= 2.0 then
		ang = this.angle + deltaangle( this.angle, dirangle[dir] ) * 0.1
		-- ang = dirangle[dir]
	else
		ang = atan2( trgt.y - this.y, trgt.x - this.x  )
	end
	if entity_falling( this ) == false then
		this.killable = true
		if d > this.distancetrigger or gstate > 1 then
			this.ismoving = 1
			entity_move( this, ang )
			zombie_check_cell( this, flr(this.x), flr(this.y) )	-- and around ?
		else
			this.ismoving = 0	-- eating		
			sfx(3) --zombie hit/bite player
			this.move = entity_wait_frame
			this.ontrigger = zombie_start
			this.waitframe = frame + 60
			if player.waitframe == 0 then
				player.lifepoints -= 1
				player.waitframe = 50
				if player.lifepoints <= 0 then
					player.lifepoints = 0
					gstate = 2				-- game over
					player.sprite = 241
					player.draw = sprite_draw
					--sfx player die / game over
				end
				addparticle( 4, player.sx, player.sy - 4 )	
				drawplayerlives()
			end
		end
	else
		this.ismoving = 0	-- falling
	end
end

function zombie_check_cell( this, cx, cy )	
	local el = w_eget(cx, cy)
	if el != nil then
		for e in all(el) do
			if e.kind == 4 and e.isheld == false and e.shadow == 255 then  -- free kid ?
				local dx = this.x - e.x
				local dy = this.y - e.y
				local d = sqrt( dx*dx + dy*dy )
				if d < 0.5 then
					sfx(3)--zombie attack / catch kid
					this.move = entity_wait_frame
					this.holdkid = e
					this.ontrigger = zombie_eat
					this.waitframe = frame + 30 * 7
					e.memomove = kid_follow
					e.move = entity_wait_frame
					e.waitframe = frame + 30 * 7
					e.trigger = entity_restore_move
					e.isheld = true
					return true
				end
			end
		end
	end
	return false
end

function zombie_eat(this)
	local kid = this.holdkid
	addparticle( 2, kid.sx, kid.sy - 4 )	
	kid.sprite = 246
	kid.draw = sprite_draw
	sfx(10) --kid scream to death
	kid.kind = 5 -- dead kid
	this.move = zombie_start
	this.holdkid = nil
	kids_dead += 1
	add( deleteentitylist, kid )
	drawinfo()
end

function zombie_death( this )	
	sfx(4)--zombie dying
	if this.holdkid != nil then
		local kid = this.holdkid
		kid.isheld = false
		kid:ontrigger() -- stop wait_frame
	end
	zombies_dead += 1
	addparticle( 2, this.sx, this.sy - 4 )	
	drawinfo()
	remove_map_entity( this )
	del( entitylist, this )
end

--------------------------------------------------------------
-- balls
function ball_create( beta )
	local this = new_entity( 3, 207, ball_move, nil )
	this.draw = sprite_draw
	this.z = player.z + 2
	this.speed = 0.2 
	this.angle = beta
	return this
end
function ball_move(this)
	local dx = this.speed * sin( this.angle )
	local dy = this.speed * cos( this.angle )
	local cx = flr(this.x)
	local cy = flr(this.y)
	nx = flr(this.x + dx)
	ny = flr(this.y + dy)
	local cz = flr(this.z)
	local flagremove = 0
	if w_zget(nx, ny)-cz>0 or cx<0 or cy<0 or cx>63 or cy>31 then
		flagremove = 2
	else
		entity_moveto(this, this.x + dx, this.y + dy)
		local el = w_eget(this.x, this.y)
		if el != nil then
			for e in all(el) do
				if e.kind==2 and e.killable==true then -- zombie
					zombie_death( e )
					flagremove += 1
					break
				end
			end
		end		
	end
	if flagremove > 0 then
		add( deleteentitylist, this )
		remove_map_entity( this )
		addparticle( 1, this.sx, this.sy-2 )
	end
	return true
end
--------------------------------------------------------------
-- world 
function w_eget(x, y)
	local ix = flr(x)
	local iy = flr(y)
	if (ix>63 or iy>31)	return nil
	local xmap = w_emap[iy]
	if (xmap != nil)return xmap[ix]
	return nil
end
function w_dget(x, y)
	local ix = flr(x)
	local iy = flr(y)
	if (iy>31)	return nil
	local xdmap = w_dmap[iy]
	if (xdmap != nil)	return xdmap[ix]
	return nil
end
function w_tget(x, y)
	local ix = flr(x) * 2
	local iy = flr(y)
	if (iy>31) return 64
	if (ix>127) return 64
	local t = mget(ix, iy)
	if (t==0)  return 64
	return t
end
function w_tset(x, y, t)
	mset(flr(x) * 2, flr(y), t)
end
function w_zget(x, y)
	local ix = flr(x) * 2
	local iy = flr(y)
	if (iy>31)	return 0
	return mget(ix + 1, iy)
end
function w_zset(x, y, z)
	if(z>255)	z = 255
	if(z<0)	z = 0
	mset(flr(x) * 2 + 1, flr(y), z)
end
function w_zsett(x, y, z)
	if(z>255)	z = 255
	if(z<0)	z = 0
	local ix = flr(x) * 2 + 1
	local iy = flr(y)
	if (mget(ix, iy) == 0) mset(ix, iy, z)
end
function remove_map_entity( this )
	local cx = flr(this.x)
	local cy = flr(this.y)
	if w_emap[cy] != nil then
		if w_emap[cy][cx] != nil then
			del( w_emap[cy][cx], this )
		end
	end
end
function dolifts()
	for lift in all(liftlist) do
		local dz = lift.up - lift.down
		w_zset( lift.x, lift.y, flr( lift.down + ((dz+1.0) / 2.0) + sin( frame/100.0 ) * (dz+0.9) / 2.0))
	end
end

function initmenu()
	activity = 1
	menu_difficulty = { "no zombie", "easy", "medium", "hard" }
	menu_camera = { "edge scroll", "centered"  }
	menu_cursor = { "relative", "screen" }
	menu = { "start", "random map", "difficulty : ", "cursor : ", "camera : " }
	mline = 1
end
--------------------------------------------------------------
-- game
function resetgame()
	entitylist = {}
	menu[1] = "start"
	gstate = 0
end

function _update()
	if activity == 0 then -- bumper
		if btnp(4) then   
			sfx(5)
			droplist = {}
			initmenu()
			music(-1, 5000)			
-- to remove when default map (hand designed) is playable
rndmap()
resetgame()
gstate = -1
		end		
		return		
	elseif activity == 1 then -- menu
		ml = mline
		if (btnp(2)) mline -= 1
		if (btnp(3)) mline += 1 	
		if (mline==0) mline = 5
		if (mline>5) mline = 1
		if (ml!=mline)	sfx(6)
		if btnp(4) then
			sfx(5)
			if mline == 1 then
				if (gstate <= 0)	initgame()
				firedown = 1
				frame = 0
				activity = 2
			elseif mline == 2 then
				rndmap()
				resetgame()
				gstate = -1
			elseif mline == 3 then
				opt_difficulty += 1 -- inc
				if (opt_difficulty<1)	opt_difficulty = 4
				if (opt_difficulty>4)	opt_difficulty = 1
				rndmap()
				resetgame()
				gstate = -1
			elseif mline == 4 then
				opt_cursor += 1
				if opt_cursor>2 then
					opt_cursor = 1
					btntoangle = btntoangle_relative
				else
					btntoangle = btntoangle_screen
				end
			elseif mline == 5 then
				opt_camera += 1
				if (opt_camera>2) opt_camera = 1
			end
		end			
		return
	end
	-- else activity == 2  -- game
	dolifts()
	
	if opt_difficulty > 1 then
		local rz = shr( 2048, opt_difficulty )-1
		if (maskframe( rz )) zombie_gen()
	end

	-- player input and life
	if btnp(5) then
		sfx(6)
		sfx(-2,3)
		menu[1] = "continue"
		activity = 1
		return
	end
	if gstate == 1 then
		local ang = 0.0
		local btndir = 0
		if (btn(0)) btndir += 1	-- left
		if (btn(1)) btndir += 2 -- right
		if (btn(2)) btndir += 4	-- up
		if (btn(3)) btndir += 8 -- down
		if entity_falling( player ) == false and player.waitframe == 0 then
			if btndir > 0 then
				player.ismoving = 1
				local oxi = flr( player.x )
				local oyi = flr( player.y )
				entity_move(player, btntoangle[btndir] )
				local nxi = flr( player.x )
				local nyi = flr( player.y )
				if oxi != nxi or oyi != nyi then
					local xdmap = w_dmap[oyi]
					if xdmap == nil then
						xdmap = { }
						w_dmap[oyi] = xdmap
					end
					local d = 0
					if nxi != oxi then
						if nxi > oxi then
							d = bor( d, 2 )
						else
							d = bor( d, 8 )
						end
					end
					if nyi != oyi then
						if nyi > oyi then
							d = bor( d, 4 )
						else
							d = bor( d, 1 )
						end
					end
					xdmap[oxi] = d -- update cell with player direction
				end
				if testedtile==78 then -- cage
					w_tset(nx, ny, 70)
					w_zset(nx, ny, w_zget(nx,ny)-8)
					local kid = kid_create()
					entity_moveto( kid, nx+0.5, ny+0.5 )
					kids_found += 1
					add( entitylist, kid )
					sfx(7) --jingle free kid	
				end
				if w_tget( nxi, nyi )==106 and kids_saved>=kids_count-kids_dead then  -- exit
					player.x = flr(player.x) + 0.5
					player.y = flr(player.y) + 0.5
					player.shadow = 0
					gstate = 3			-- game win
					sfx(8,3) --beam on
					bcount += 1
					--sfx jingle victory
				end
			else
				player.ismoving = 0
			end		
			if firedown == 0 then
				if btn(4) then	-- throw ball
					firedown = 1
					local ball = ball_create( player.angle )
					entity_moveto( ball, player.x, player.y )
					add( entitylist, ball )					
					sfx(0)	--launch ball
				end	
			else
				if (not btn(4))	firedown = 0
			end	
			
		else
			if player.waitframe > 0 then
				player.waitframe -= 1	-- player stuck
				if player.waitframe == 0 then
					camera()
				else
					camera( band(frame,1), 0 )
				end
			end
			player.ismoving = 0
		end
	elseif gstate == 3 then -- win
		entity_teleport(player)
	end
	-- entities life
	for e in all(entitylist) do
		e:move()
	end
	if #deleteentitylist > 0 then
		for e in all(deleteentitylist) do
			del( entitylist, e )
		end
		deleteentitylist = {}
	end
 -- camera	
	if opt_camera == 2 then
		camx = player.x
		camy = player.y
	elseif opt_camera == 1 then
		if player.sx < 24 then
			scrolldx = -1.0
			scrollx = 24
		elseif player.sx > 128-24 then
			scrolldx = 1.0
			scrollx = 24
		elseif player.sy < starty+16 then
			scrolldy = -1.0
			scrolly = 40
		elseif player.sy > bottom-16 then
			scrolldy = 1.0
			scrolly = 40
		end
	end
	if scrollx > 0 then
		scrollx -= 1
		camx += 0.1 * scrolldx
		camy -= 0.1 * scrolldx
	end
	if scrolly > 0 then
		scrolly -= 1
		camx += 0.1 * scrolldy
		camy += 0.1 * scrolldy
	end
	-- need a screen coor scrolling offset for particles
	updateparticles()
end
--------------------------------------------------------------
function _draw()
	if activity == 0 then -- bumper
		if frame==0 then
			cls()
			map( 113, 32, 4, 1, 16, 3 )
			y = starty + 8
			cursor( 0, starty + 6)
			print("controls", 49, y, 15 )
			y += 10
			print("move twinsen: cursor", 24, y, 7)
			y += 6
			print("throw magic ball: action [c]", 8, y, 7)	
			y += 6
			print("menu: button 2 [x]", 32, y, 7)	
			y += 12
			print("mission", 50, y, 15)
			y += 10
			print("bring all kids safe to exit", 10, y, 7)
			y += 12
			print("press action to start", 24, y, 10)
			y += 12
			print( "by fred and yael", 33, y, 6 )
			y += 8
			print( "thanks to yellowafterlife", 13, y, 6 )
			y += 8
			print( "www.2dark.fr", 40, y, 2 )
		end		
		dodrops()
	elseif activity == 1 then -- menu
		cls()
		map( 113, 32, 4, 1, 16, 3 )
		-- sy = 18 -- picolcd
		sy = 26
		y = mline*8+sy-2
		rectfill( 10, y, 118, y+8, 4 )
		for l=1,5 do
			str = menu[l]
			if (l == 3) str = str..menu_difficulty[opt_difficulty]
			if (l == 4) str = str..menu_cursor[opt_cursor]
			if (l == 5) str = str..menu_camera[opt_camera]
			print( str, 64-#str*2, l*8+sy, 7 )
		end
		
		--draw2dmappicolcd()
		draw2dmap(85)
		
	else  -- game
		if frame==0 then
			cls()
			map( 113, 32, 4, 1, 16, 3 )
			drawplayerlives()
			drawinfo()
		end
		world_draw() 

		if gstate == 1 then
			if kids_saved >= kids_count - kids_dead then
				print("goto exit",44,starty+2,15)
			end
		elseif gstate == 2 then
			printcenter("game over",0)		
		elseif gstate == 3 then
			player.ismoving = 0 -- anim victory ?
			local t = kids_count - kids_saved
			if t <= 0 then
				printcenter("! congratulations !",-1)
				printcenter("! you are a hero !",1)
			elseif t < kids_count/2 then
				printcenter("! mission success !",-1)
				printcenter("but you can do better",1)
			elseif t < 1 then
				printcenter("? mission success ?",-1)
				printcenter("can you handle that job ?",1)
			else
				printcenter("! you are fired !",-1)
				printcenter("the goal is to save them all...",1)
			end
		end
		--local yfps = starty+sizey-6
		--rectfill( 112,yfps, 127, 118, 0 )
		--print( stat(1), 112,yfps, 15)
	end
	frame += 1 
end

function printcenter( str, oy )
	local x = 64-#str*2
	local y = 34 + oy * 4
	print( str, x+1,y,1 )
	print( str, x-1,y,1 )
	print( str, x,y+1,1 )
	print( str, x,y-1,1 )
	print( str, x,y,7 )
end
function drawplayerlives()
	local x = 12
	local y = starty + sizey + 3
	local mlp = player.maxlifepoints
	local lp = player.lifepoints
	for n = 1, mlp do
		if n <= lp then
			spr( 252, x, y )
		else
			rectfill( x, y, x+7, y+7, 0 )
			spr( 253, x, y )
		end
		spr( 254, x + 8, y )
		x += 10
	end
end

function subs( s )
	return sub( s, #s-1)
end

function drawinfo()
	rectfill( 0, 123, 127, 127, 0 )
	local x
	if (opt_difficulty>1) then
		x = 70
		spr( 246, x, 121 )
		print( subs("0"..kids_dead), x + 9, 123, 15 )
		x = 95
		spr( 242, x, 121 )
		print( subs("0"..zombies_dead), x + 9, 123, 15 )
		x = 10
	else
		x = 35
	end
	spr( 247, x, 121 )
	print( subs("0"..kids_saved), x + 8, 123, 15 )
	x += 25
	spr( 198, x, 122 )
	print( subs("0"..kids_found).."/"..subs("0"..kids_count ), x + 8, 123, 15 )
end

function world_draw()  
	clip( 0, starty, 128, sizey )
	local sx = -11
	local sy = -2
	local xy, x
	for xy = 0, 12 do
		for mx = 0, 9 do
			draw_tile(mx+sx+xy, sy+xy-mx)
		end
		for mx = 0, 8 do
			draw_tile(mx+sx+xy+1, sy+xy-mx)
		end
	end
	-- need more loops 
	-- with test if z enter screen for high cells
	drawparticles()
	clip( 0, 0, 128, 128 ) 
end

function draw_tile(x,y,xy)
	local wx = flr(camx) + x
	local wy = flr(camy) + y
	local t = w_tget(wx, wy)
	if (t == 64) t += 16 * (band(frame,24)/8)
	local ox = (camx + (x - wx))
	local oy = (camy + (y - wy))
	local z = w_zget(wx, wy)
	x -= ox
	y -= oy
	--if (earthquake) zt = z + 1 - irnd( 3 )	
	local dx = flr(offsetx + (x - y) * 8)
	local dy = flr(offsety + (x + y) * 4 - z)
	zt = 1
	-- todo: store precomputed sprite height
	zm = w_zget(wx+1,wy)
	zy = w_zget(wx,wy+1)
	if (zy<zm)	zm = zy		
	if (z>zm)   zt = flr(1 + (z-zm+7) / 8)
	spr(t, dx, dy, 2, zt)
	if t==106 and exitfx == 1 then	-- exit
		drawbeam( dx, dy )
		exitfx = 0
	end
	-- draw entities
	local el = w_eget(wx, wy)
	if el != nil then
		-- need sort y in a cell
		for e in all(el) do
			local ex = e.x - flr(e.x)
			local ey = e.y - flr(e.y)
			e.sx = dx + flr(8 + (ex - ey) * 8.0)
			e.sy = dy + 1 + flr((ex + ey) * 4.0)
			e:draw(e.sx, e.sy, z )			
		end
	end	
-- draw player tiles path
--	local d = w_dget(wx, wy )
--	if d != nil then
--		print( d, dx + 6, dy )
--	end		
end

function drawbeam( dx, dy )
	rectfill( dx+2, starty, dx + 12, dy + 4, 12 )
	local xx = dx
	local yy = dy - band(frame,7)*2
	for y = yy,yy-48,-16 do
		spr( 176, xx, y, 2, 1 )
	end
	if maskframe(1) then
		rectfill( dx+6, starty, dx + 8, dy + 4, 7 )		
	end
end
--------------------------------------------------------------
function draw2dmap(oy)
	ox = 32
	-- rectfill( ox-8, oy-4, ox+64+8, oy+32+12, 1 )
	local x, y, t, c
	for y = 0,31 do
		for x = 0,63 do
			t = w_tget( x, y ) 
			c = 0
			if (t==64) c = 1	-- water
			if (t==66) c = 11	-- lift
			if (t==68) c = 4	-- sand/earth
			if (t==70 or t==102) c = 3	-- grass, flowers
			if (t==72) c = 6	-- stone
			if (t==74) c = 10	-- bridge
			if (t==78) c =14	-- cage
			if (t==106) c = 7 + band(frame,1)	-- exit
			if (c>0) pset(x+ox,y+oy,c)
		end
	end	
	if gstate > 0 then
		if maskframe(8) then
			for e in all(entitylist) do
				k = e.kind
				c = 0
				-- if (k==2)	c = 11
				if (k==4)	c = 14	-- kid
				if (c>0) pset( ox+e.x, oy+e.y, c )	
			end
		end
		if (maskframe(4))	pset(ox+player.x,oy+player.y, 7)
	end
	x = 42
	spr( 247, x, oy+33 )
	print( subs("0"..kids_count), x + 9, oy+35, 15 )
	x = 72
	spr( 243, x, oy+33 )
	local str = subs("0"..zombies_count)
	if (opt_difficulty>1) str = str.."+"
	print( str, x + 9, oy+35, 15 )
end
function draw2dmappicolcd()
	oy = 64
	ox = 32
	local x, y, t, c
	for y = 0,31 do
		for x = 0,63 do
			t = w_tget( x, y ) 
			c = 0
			if (t==64) c = 1	-- water
			if (t==66) c = 11	-- lift
			if (t==68) c = 4	-- sand/earth
			if (t==70 or t==102) c = 3	-- grass, flowers
			if (t==72) c = 6	-- stone
			if (t==74) c = 10	-- bridge
			if (t==78) c =14	-- cage
			if (t==106) c = 7 + band(frame,1)	-- exit
			if (c>0) rectfill(x*2,y*2+oy,x*2+1,y*2+oy+1,c)
		end
	end	
	if gstate > 0 then
		if maskframe(8) then
			for e in all(entitylist) do
				k = e.kind
				c = 0
				-- if (k==2)	c = 11
				if (k==4)	c = 14	-- kid
				if (c>0) rectfill(e.x*2,e.y*2+oy,e.x*2+1,e.y*2+oy+1,c)
			end
		end
		if (maskframe(4))	rectfill(player.x*2,player.y*2+oy,player.x*2+1,player.y*2+oy+1,7)
	end
	x = 42
	oy = 121
	spr( 247, x, oy-2 )
	print( subs("0"..kids_count), x + 9, oy, 15 )
	x = 72
	spr( 243, x, oy-2 )
	local str = subs("0"..zombies_count)
	if (opt_difficulty>1) str = str.."+"
	print( str, x + 9, oy, 15 )
end

function grnd()
	if irnd(2) == 1then
		return 128 + irnd(100)
	end
	return 128
end
function frnd( delta )
	return  delta*4 - irnd(delta*8)
end
function trnd( t0, t1, r )
	if (flr(rnd(r))==0)	return t1
	return t0
end

function scrmapfromheight()
	local mg = 150
	local zt
	local t
	for my = 0,31 do
		for mx = 0,63 do
			mz = w_zget( mx, my )
			if mz <= mg	then
				mz = 0
				t = 64
			else
				mz = flr(((mz-mg)*15)/(255-mg))
				mz += 1
			end
			if mz >= 1 and mz < 5 then 
				mz = 4
				t = 68
			end
			if mz >= 5 and mz < 12 then
				mz = 6 + flr((mz-4)/2)*2
				t = trnd( 70, 102, 5 )
			end
			if mz >= 12 then
				mz = 14 + flr(mz-12)*4
				t = 72
			end
			mz -= 2
			w_tset( mx, my, t )
			w_zset( mx,my, mz )
			poke( 0x6000 + mx + my * 64, t )
--poke( 0x6000 + mx + my * 64 + 33 * 64, t)
		end
	end
end

function rndmap()
	local mx, my, mz
	for my = 0,31 do
		for mx = 0,63 do
			w_tset( mx, my, 64 )
			w_zset( mx, my, 0 )
		end
	end
	for my = 7,23,8 do
		for mx = 7,55,8 do
			w_zset( mx, my, grnd() )
		end
	end
	fractal( 0,0, 31,31 )
	fractal( 31,0, 63,31 )	
	scrmapfromheight()
	-- clear one pixel islands
	for my = 0,31 do
		for mx = 0,63 do
			if w_tget(mx, my) != 64 then
				local n = 0
				if (w_tget(mx+1, my) == 64)	n += 1
				if (w_tget(mx-1, my) == 64)	n += 1
				if (w_tget(mx, my+1) == 64)	n += 1
				if (w_tget(mx, my-1) == 64)	n += 1
				if n == 4 then
					w_tset( mx, my, 64 )
					w_zset( mx, my, 0 )				
					poke( 0x6000 + mx + my * 64, 64 )
--poke( 0x6000 + mx + my * 64 + 33 * 64, 64)
				end
			end
		end
	end
	-- kids
	kidlist = {}
	kids_count =  5 + (5-opt_difficulty) * 5
	for n = 1, kids_count do	
		mx, my = getgroundpos( irnd( 64 ) + 0.5, irnd( 32 ) + 0.5)
		add( kidlist, { flr(mx), flr(my) } )
		w_tset( mx, my, 78 ) -- cage
		w_zset( mx, my, w_zget(mx,my)+8 )
	end	
	-- exit pod
	exitx, exity = getmappos( irnd( 64 ) + 0.5, irnd( 32 ) + 0.5, 70 )
	exitx = flr( exitx )
	exity = flr( exity )
	w_tset( exitx, exity, 106 )	-- exit
	scrfill( exitx, exity, 240 )
	local k = {}
	local idx = 248
	for k in all(kidlist) do
		if peek( 0x6000 + k[1] + k[2] * 64 ) < 240 then
			local bx = k[1]
			local by = k[2]
			while peek(0x6000 + bx + by * 64) != 240 do
--poke(0x6000 + bx+frame + by * 64 + 33*64, 121)
				scrfill( bx, by, 251 )
				msd = 128
				scrfillscan( bx, by, 1, 248 )
				if msd != 128 then
					local dx = dirx[msdir]
					local dy = diry[msdir]
					local sx = msx
					local sy = msy
--poke(0x6000 + sx + sy * 64 + 33*64, frame)
					while peek(0x6000 + sx + sy * 64) == 64 do
						poke(0x6000 + sx + sy * 64, 248)
--poke(0x6000 + sx + sy * 64 + 33*64, 170)
						w_tset( sx, sy, 74 )	-- bridge
						w_zset( sx, sy, 3 )
						sx += dx
						sy += dy
					end
					if peek(0x6000 + sx + sy * 64) != 240 then
						bx = sx
						by = sy
					else
						scrfill( bx, by, 240 )					
					end		
				else
					-- potentialy invalid map: regenerate ?
					break
				end
			end
		end
	end
	-- todo: store sprite height delta to opt display
	initgame()	
end

function scrfill( x, y, c )
	if (x < 0 or y < 0 or x > 63 or y > 31) return
	local ptr = 0x6000 + x + y * 64
	local t = peek( ptr )
	if (t==64 or t==c or t==240) return
	poke( ptr, c )
	scrfill(x+1,y,c)
	scrfill(x-1,y,c)
	scrfill(x,y+1,c)
	scrfill(x,y-1,c)
end
dirx = { 0, 1, -1, 0, 0 }
diry = { 0, 0, 0, 1, -1 }
function scrfillscan( x, y, dir, c )
	if (x < 0 or y < 0 or x > 63 or y > 31) return
--poke(0x6000 + x + y * 64 + 33 * 64, c + c * 16 ) -- 12) -- +frame)
	local ptr = 0x6000 + x + y * 64
	local t = peek( ptr )
	if (t>=240 and t<251) return
	if t==64 then
		local d = 0
		local dx = dirx[dir]
		local dy = diry[dir]
		local sx = x -- + dx
		local sy = y -- + dy
		while peek(0x6000 + sx + sy * 64) == 64 do
--poke(0x6000 + sx + sy * 64 + 33 * 64, 8+8*16) --+frame)
			sx += dx
			sy += dy
			d += 1
			if (sx < 0 or sy < 0 or sx > 63 or sy > 31) return
		end
		t = peek(0x6000 + sx + sy * 64)
		if (t==c or t==251) return
		if d < msd then
			msx = x
			msy = y
			msd = d
			msdir = dir
			msi = t
		end
		return
	end
	poke( ptr, c )
	scrfillscan(x+1,y, 2, c)
	scrfillscan(x-1,y, 3, c)
	scrfillscan(x,y+1, 4, c)
	scrfillscan(x,y-1, 5, c)
end

function fractal( x0, y0, x1, y1)
	local dt = x1-x0
	if dt > 1 then
		local hx = flr((x0+x1)/2)
		local hy = flr((y0+y1)/2)	
		w_zsett(hx, y0, (w_zget( x0, y0 ) + w_zget( x1, y0 ))/2 + frnd( dt ))
		w_zsett(hx, y1, (w_zget( x0, y1 ) + w_zget( x1, y1 ))/2 + frnd( dt ))
		w_zsett(x0, hy, (w_zget( x0, y0 ) + w_zget( x0, y1 ))/2 + frnd( dt ))
		w_zsett(x1, hy, (w_zget( x1, y0 ) + w_zget( x1, y1 ))/2 + frnd( dt )) 
		w_zsett(hx, hy, (w_zget( hx, y0 ) + w_zget( x0, hy ) + w_zget( hx, y1 ) + w_zget( x1, hy))/4 + frnd( dt ) )
		fractal( x0, y0, hx, hy )
		fractal( hx, y0, x1, hy )
		fractal( x0, hy, hx, y1 )
		fractal( hx, hy, x1, y1 )
	end
end
--------------------------------------------------------------
-- particles
particleslist = { }
function createparticle( t, x, y, c )
	local part = { }
	part[0] = 1 -- blood
	part[1] = x
	part[2] = y
	part[6] = c			-- color
	part[7] = 0.0		-- gravity
	add( particleslist, part )
	return part
end		
function addparticle( t, x, y )	
	local c, c2
	if t == 1 then		-- ball impact
		for p = 0,3 do
			local part = createparticle( t, x, y, 7 )
			part[3] = -0.3 + rnd( 0.6 ) -- speedx
			part[4] = -0.3 + rnd( 0.6 ) -- speedy
			part[5] = frame + 10 + p
		end
	elseif t >= 2 then -- and t < 10	then					-- blood zombie, kid, twinsen
		c = 8
		c2 = 11
		if (t == 3) c2 = 14
		if (t == 4) c2 = 12
		for p = 0,24 do
			if (p > 19)	c = c2
			local part = createparticle( t, x, y, c )
			part[3] = -0.3 + rnd( 0.6 ) -- speedx
			part[4] = -0.35 - rnd( 1.0 ) -- speedy
			part[5] = frame + 10 + p/2
			part[7] = 0.1			-- gravity			
		end
	end	
end		
function updateparticles()
	for part in all( particleslist ) do
		part[1] += part[3]
		part[2] += part[4]
		part[4]	+= part[7]
		if part[5] < frame or part[2] > bottom then
			del( particleslist, part )
		end
	end
end
function drawparticles()
	for part in all( particleslist ) do
		pset( part[1], part[2], part[6] )
	end
end
--------------------------------------------------------------
-- title fx
droplist = {}
dropbottom = 1
maxdrops = 30
dropframe = 150
function newdrop()
	return { x = -1.0, y = 999, len = 3.0, dir = 0 }
end
function initdrops()
	droplist = {}
	add( droplist, newdrop() )
	dropframe = frame + 150
end
function dodrops()
	if #droplist < maxdrops then
		if dropframe <= frame then
			dropframe = frame + 150
			add( droplist, newdrop() )
		end
	end
	for d in all(droplist) do
		dodrop(d)
	end
end
function dodrop(this)
	if this.y >= 128 then	
		if (this.y != 999 and dropbottom == 1)	pset( this.x, 127, 8 )
		this.x = irnd( 127 )
		while( pget( this.x, 15 ) != 8 ) do	-- mmm...
			this.x = irnd( 127 )
		end 
		this.y = 17
		this.len = 0
		if (irnd(3)==0)	this.len = this.y + rnd( 11 )
		this.dir = 0
		this.changedir = false
	end
	local nx = this.x
	local ny = this.y + 1
	if ny > 28 then
		local px = pget( nx, ny )
		if px != 0 then
			if px == 8 then
				ny -= 1
				if nx+this.dir < 128 and nx+this.dir > 0 and pget( nx+this.dir, ny ) == 0 then
					nx += this.dir
				else
					if this.changedir == false then
						this.changedir = true
						this.dir = -this.dir
						if nx+this.dir < 128 and nx+this.dir > 0 and pget( nx+this.dir, ny ) == 0 then
							nx += this.dir
						else
							this.y = 999
						end
					else
						this.y = 999
					end
				end
			else
				this.y = 999
			end
		else -- falling
			if this.changedir == true or this.dir == 0 then
				this.dir = 1 - (irnd( 2 )*2)
				this.changedir = false
			end
		end
	end
	if (this.y == 999)	return
	
	if this.y < this.len then
		c = 8
	else
		c = 0
	end
	pset( this.x, this.y, c )
	pset( nx, ny, 8 )			
	this.x = nx
	this.y = ny
end
	