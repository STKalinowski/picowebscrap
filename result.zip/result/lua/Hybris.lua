-- hybrys
-- benjamin soule
-- ludum dare 34

bid=0
di4={1,0,0,1,-1,0,0,-1}
--weak=true

function _init()
 cls()
 t=0
 tt=0
 complete={false,alse,false,false}
 dif=0--rand(4)
 lives=2
 --init_game()
 init_menu()
end

function init_menu()
 
 music(63,2000,1)
 
 mstep=0
 mtt=nil
 
 loop=function() 
 
  if mstep==0 then
   if btnp(4) then
    if t<240 then
     t=240
    else
     sfx(1)
     mstep+=1
     tt=0
    end
   end
  elseif mstep==1 then
   if tt==16 then    
				init_select()   
   end
  else
   
  end
 
 end
 
 
 draw=function()
  cls() 
  draw_title()  
  rectfill(0,48,128,128,2)
  py=56
  for txt in all(text) do  
   d=t/4-(py-48)
   if d > 0 then
    co=sget(min(d,7),13)
    print(txt,(128-#txt*4)/2,py,co)
   end
   py+=8 
  end  
  
  if t>200 then
   music(-1,2000)
  end 
  if t>240 then
   blink=t%16<12
   if mstep==1 then blink=t%4<2 end
   if blink then
    print("press [z] to start !",24,118,7)
   end
  end  
 end
 
end

function launch_game()
 bid=sel
 init_game()
end

function init_select()
 sel=0
 dec={-1,1,2,-2}
 --complete={true,true,true,true}
 -- loop
 loop=function()   
  for i=0,3 do
   if btnp(i) then 
    sel=(sel+dec[1+i])%4
    sfx(48)
   end
  end 
  if btnp(4) then
   if comp then
    sfx(47)
   else
    launch_game()
   end
  end
     
 end
 
 -- draw
 draw=function()
  cls() 
  draw_title()
  
  
  land=lands[1+sel]
  comp=complete[1+sel]
  if comp  then
   land="clean !"
  end
  print(land,2+(128-#land*4)/2,120,7)
      
  sz=32
  for i=0,3 do
   x=32+(i%2)*36
   y=48+flr(i/2)*36
   
   if i==sel then
    co=sget(t%8,10)
    if comp then co=8 end
    rect(x-1,y-1,x+32,y+32,co)
   end
   if complete[i+1] then
    for i=0,15 do 
     pal(i,sget(32+i,22)) 
    end
   end
   sspr(i*32,96,32,32,x,y)
   pal()
   --rectfill(x,y,x+sz,y+sz,1)
  end

 end  
end

lands={
 "lungs maze",
 "isthmus of thyroid",
 "muscular hills",
 "bone marrow wasteland", 
}

function draw_title()
 clip(0,0,128,36)
 am=8+cos((8+t%32)/32)*2
 for i=0,3 do
  r=32-i*am
  co=sget(5-i,9)
  circfill(64,36,r,co)
 end
 clip()
 sspr(0,64,64,32,32,8) 
end


function init_game()
 cells={}
 ents={}
 pxls={}
 burns={}
 opts={}
 sparks_count=0
 buds=0
 gmo=nil
 
 playlist={9,13,4,8}
 
 music(playlist[1+bid],0,3)
 
 -- init boss
 lc=sget(48,16+bid)
 dc=sget(49,16+bid)
 sfc=sget(55,16+bid)
 
 make_cell(64,24,true)
 for i=1,dif do  
  for i=0,100 do
   p={x=rnd(128),y=rnd(48+dif*8)}
   if check_cell_pos(p) then
    break
   end
  end
  make_cell(p.x,p.y)
 end
 
 growth=0 
 spark_max=3
 frags=0
 
 -- hero
 hero=mke(48,64,120)
 hero.upd=upd_hero
 hero.shots=0
 hero.shot_max=2--+8
 hero.blast=0
 hero.burn=0
 hero.life=3
 hero.dre=function(e)
  mx=2
  if e.thrust then mx+=1 end
  spr(29+t%mx,e.x-4,e.y+4)
 end  
 
 pitch=0
 --
 cls()
 
 
 for i=0,3 do 
  e=gen_spark() 
  for i=0,32 do
  -- upd_spark(e)
  end
 end
 save_scr()
 loop=play
 draw=draw_game
 
 --success()

end

function load_scr() 
 --memcpy(0x6000,0x1000,0x1fff)
 memcpy(0x6000,0x1000,0x1000)
 memcpy(0x7000,0x4300,0x0fff)
end

function save_scr()
 memcpy(0x1000,0x6000,0x1000)
 memcpy(0x4300,0x7000,0x0fff)
 
end


function upd_hero(h)
 
 h.thrust=false
 if btn(0) then 
  hmove(-1,0) 
  pitch-=1 
 elseif 
  btn(1) then 
  hmove(1,0)  
  pitch+=1 
 else
  if pitch>0 then pitch-=1 end
  if pitch<0 then pitch+=1 end
 end
 
 if btn(2) then 
  hmove(0,-1) 
  h.thrust=true
 elseif btn(3) then 
  hmove(0,1) 
 end
 if btnp(4) then 
  if h.shots < h.shot_max and loop==play then
   s=shoot(h,0.25,5)
   h.shots+=1
   sfx(32)
  end
 end 
 if btnp(5) then
  gameover()
 end 
 
 pitch=mid(-4,pitch,4)
 hero.fr=66+pitch/2

end

function hmove(dx,dy)
 spd=1.5
 hero.x+=dx*spd
 hero.y+=dy*spd
 
 r=6
 hero.x=mid(r,hero.x,128-r)
 r=4
 hero.y=mid(96,hero.y,128-r)
end

function shoot(from,an,spd)
 s=mke(32,from.x,from.y)
 s.shot=true
 s.bad=from.bad
 if s.bad then
  
  s.fr=57
  s.bfr=3   
  s.playing=true
  s.hit_hero=gameover
 end
 s.boundary=true
 impulse(s,an,spd) 
 return s
end

function impulse(e,an,spd)
 e.vx+=cos(an)*spd
 e.vy+=sin(an)*spd
end




function make_cell(x,y,mother)
 ce=mke(40+bid*2,x,y)
 ce.life=4
 ce.bad=true
 ce.hurt=0
 ce.ray=3
 ce.mother=mother
 if mother then
  ce.ray+=2
  ce.life=20
  ce.fr+=1  
  ce.upd=function(e)   
   circfill(x,y,2,lc)
   --spr(17,x-4,y-4)
   e.upd=nil   
  end
 end
 add(cells,ce) 
 if weak then ce.life=1 end
 
 ce.dre=function(ce)
  if ce.hurt>0 then
   ce.hurt-=1
  end
  r=ce.ray+ce.hurt
  lt=t+(ce.x+ce.y)/4
  r+=flr(cos((lt%80)/80)*1.5)+1
  ce.rr=r
  circ(ce.x,ce.y,r,7)
  clip(ce.x-r,ce.y-r,r,r)
  circ(ce.x,ce.y,r-2,7)
  --circfill(ce.x-r*0.4,ce.y-r*0.4,r*0.4,7)
  clip()
 end
 
 ce.hit=function(ce)
  sfx(33)
  ce.life-=1
  ce.hurt=3
  if ce.life<= 0 then
   destroy_cell(ce)
  end
 end 
end

function scan_parts()
 local a={}
 sz=4
 
 seek=function(x,y)
  for dx=0,sz-1 do
   for dy=0,sz-1 do
    px=x*sz+dx
    py=y*sz+dy
   
    if pget(px,py)==lc then     
     e=mke(0,px,py)
     add(a,e)
     return 
    end    
   end
  end

 end
 
 for x=0,128/sz-1 do 
  for y=0,128/sz-1 do
    seek(x,y)
  end
 end
 
 return a
end


function destroy_cell(ce)
 blast(ce.x,ce.y,8)
 sfx(37)    
 del(cells,ce)
 kill(ce)
 frags+=1
 
 lims={1+flr(dif/2),3+dif,6+dif*2}
 
 for l in all(lims) do
  if frags==l then
   spawn_bonus(rand(4),ce.x,ce.y)
  end
 end

 
 -- spawn
 if bid==0 then
  e=make_mon(12,ce.x,ce.y)
  e.bfr=4
  e.bad=true
  e.playing=true
  e.upd=function(e)
   dx=hero.x-e.x
   dy=hero.y-e.y
   c=0.05
   e.x+=dx*c
   e.y+=dy*c
  end  
  local f=e.hit
  e.hit=function(e)
   e.vx+=rnd(5)-2.5
   e.vy-=4+rand(1)
   e.frict=0.96 
   f(e)
  end
  
      
 elseif bid==1 then
 
  mx=6+dif*4
  if ce.mother then mx+=6 end
  for i=1,mx do
   an=i/mx
   shoot(ce,an,0.5)

  end
 
  
 end
 

 
end

function make_mon(fr,x,y)
 e=mke(fr,x,y)
 e.life=3
 e.bad=true
 e.hit_hero=gameover
 e.hit=function(e)

  e.life-=1
  e.ray=3
  e.flh=3
  if e.life==0 then
   blast(e.x,e.y,4)
   kill(e)
   shk(e.x,e.y,4,24,6,1)
   sfx(46,3)
  else
   sfx(45,3)
  end
  
 end 
 return e
end

function shk(x,y,br,er,et,grad)
 e=mke(0,x,y) 
 e.dre=function(e)
  c=min(e.t/et,1)
  r=br+(er-br)*c
  circ(e.x,e.y,r,sget(e.t,8+grad))
  if c==1 then
   kill(e)
  end
 end 
end

function spawn_bonus(bt,x,y)
 e=mke(49+bt,x,y)
 e.vy=1
 e.ray=6
 e.boundary=true
 e.hit_hero=function(e)
  sfx(39)
  grab_bonus(bt)
  kill(e)
 end
 
end

function mke(fr,x,y)
 e={
  fr=fr,x=x,y=y,ray=2,flip=false,
  vx=0,vy=0,frict=1,t=0
 }
 add(ents,e)
 return e
end



function rand(n) 
 return flr(rnd(n))
end


function scan_blu()
 px=cur.x
 py=cur.y
 for kdi=0,3 do
  px=cur.x+di4[kdi*2+1]
  py=cur.y+di4[kdi*2+2]
  p=pget(px,py)  
  if p==1 then
   pset(px,py,0)   
  elseif p==0 then   
   sum=0
   for ddi=0,3 do
    ppx=px+di4[ddi*2+1]
    ppy=py+di4[ddi*2+2]
    pp=pget(ppx,ppy)
    if pp>1 then
     sum+=1
    end
   end
   if sum<=1 then
    pset(px,py,1)
   end     
  end   
 end
end


function branch()
 local a={}
 px=cur.x
 py=cur.y
 for mdi in get_shf() do
  kdi=(cur.di+mdi)%4
  px=cur.x+di4[kdi*2+1]
  py=cur.y+di4[kdi*2+2]
  p=pget(px,py)  
  if is_in(px,py,4) and p==0 then   
   sum=0
   for ddi=0,3 do
    ppx=px+di4[ddi*2+1]
    ppy=py+di4[ddi*2+2]
    pp=pget(ppx,ppy)
    if pp>0 then
     sum+=1
    end
   end
   if sum<=1 then
    cur.x=px
    cur.y=py
    cur.di=kdi
    return true
   end     
  end   
 end
 return false
 
end

function make_liner(x,y,an)
 e=mke(0,x,y)
 e.ox=x
 e.oy=y
 e.halo=true
 e.an=an
 e.spd=1
 e.upd=function(e)    
  if e.t<20+dif*8 then
   dx=hero.x-e.x
   dy=hero.y-e.y   
   ta=atan2(dx,dy)
   da=ta-e.an
   if da>0.5 then da-=1 end
   if da<-0.5 then da+=1 end
   e.an+=da*0.2 
  end    
  e.spd+=0.05
  e.vx=cos(e.an)*e.spd
  e.vy=sin(e.an)*e.spd
  e.boundary=true    
 end
 e.dre=function(e)
  add_pix(e.x,e.y,0,14,e.ox,e.oy)
  e.ox=e.x
  e.oy=e.y
 end
end


function upd_green_bud(e)
 e.fr=3+e.t/32
 if e.t>96 then
  e.fr=6
  dt=e.t%freq
  if dt<10 then
   e.fr+=1
  end
  if dt==0 then
   s=shoot(e,gha(e,0.2),1)
   s.fr=35
   s.bfr=3   
   s.hit=function(s)
   kill(s)
   local e=mke(17,s.x,s.y)
    e.timer=8
   end
  end
 end
end

function gha(e,arc)
 dx=hero.x-e.x
 dy=hero.y-e.y
 return atan2(dx,dy)+rnd(arc)-arc/2
end

function upd_pink_bud(e)
 e.fr=69+e.t/32
 if e.t>150 then
  sfx(30)
  for i=0,1 do
   shk(e.x,e.y,4,8+i*8,8-i*2,7)
  end
  num=3+dif*3
  for i=1,num do
   s=shoot(e,gha(e,0.1),0.5)
   s.frict=1+(i/num)*0.1
  end  
  kill(e)
 end
end

function make_bud()
 freq=100-dif*20
 local e=make_mon(3,cur.x,cur.y)
 e.ray=5
 e.upd=upd_green_bud
 if bid==3 then
  e.upd=upd_pink_bud
 end
 if cur.di>=2 then
  e.flip=true
 end
 buds+=1
 e.on_death=function() 
  buds-=1
 end
end


function paint_cur()
 pset(cur.x,cur.y,lc)

 if cur.t>40 and rand(40)==0 then
  
  if (bid==0 or bid==3) and buds<3+dif then
   make_bud()
  end
  
  if bid==1 and rand(4)<dif+1 then
   spawn_bee(cur)
  end
  
  if bid==2  and rand(2)==0 then
   make_liner(cur.x,cur.y,-cur.di*0.25)
  end
  
  recycle(cur)
 end
 
end

function gameover()
 if gmo then return end
 gmo=true
 music(-1)
 sfx(41)
 local gmt=t+6
 loop=function()
  if gmt==t then
   gameover2()
  end
 end
 --draw=nil
 
end

function gameover2()

 explode_level()
 kill(hero)
 -- explo
 num=64
 for i=0,num do
  e=mke(26,hero.x,hero.y)
  e.playing=true
  e.boundary=true
  e.bfr=3
  impulse(e,rnd(1),rnd(8))
  
  e=mke(0,hero.x,hero.y)
  e.boundary=true
  e.dre=function(e)
   pset(e.x,e.y,sget(t%8,10))
  end
  impulse(e,rnd(1),4)
  e.frict=0.95+rnd(0.05)  
 end
 
 
 -- loop
 loop=function()
  foreach(ents,upe)
 end
 
 -- draw
 draw=function()
  cls()

  foreach(ents,dre)
  
  c=min(tt/20,1)
  c=1-sqrt(c)
  if c>0 then
   circfill(hero.x,hero.y,c*24,7)
  end
  
  if tt>40 then
   if lives>0 then
    lives-=1
    reload()
    init_select()
   else
    label("game over")  
    if tt>80 or btnp(4) then
     run()
    end 
   end  
  end
  
  
  
 end
 
 
end

function label(str)
 rectfill(0,60,128,68,0)
 print(str,(128-#str*4)/2,62,7) 
end



function spawn_bee(e)
 sfx(40)
 b=mke(19,e.x,e.y)
 b.bfr=6
 b.playing=true
 b.vy=-1.5
 b.vx=rnd(1)-0.5
 b.boundary=true
 b.bad=true
 b.shot=true 
 b.hit_hero=gameover
 b.upd=function(e)
  e.vy+=0.1  
 end
 b.hit=function(e)
  sfx(34)
  e.vy=-1.5
  e.flh=4
 end
 b.dre=function(e)
  circfill(e.x,e.y,6-e.t,7)
  if e.t>4 then e.dre=nil end
  apal(9)
  spr(e.fr,e.x-4,e.y-4)
  pal()
 end
 
 
end

function follow()

 for mdi in get_shf() do
  p=ck(mdi)
  if p==lc then
   ck(mdi,true)
   return true
  end  
 end
 return false
    
end


shf={ 0,1,2, 0,2,1,
      1,0,2, 1,2,0,
      2,0,1, 2,1,0 }

function get_shf()
 local a={}
	bi=1+rand(6)*3
 for i=0,2 do
  add(a,shf[bi+i]-1)
 end
 return all(a)
end

function ck(mdi,apply,mdi2)
 local x=cur.x
 local y=cur.y
 local di=cur.di 
 
 for ddi in all({mdi,mdi2}) do
  if ddi then
   di=(di+ddi)%4
   x+=di4[1+di*2]
   y+=di4[2+di*2]
  end
 end
 
 if x<0 or y<0 or x>=128 or y>=128 then
  return -1;
 end
 if apply then
  cur.x=x
  cur.y=y
  cur.di=di
 else
  cur.nx=x
  cur.ny=y
 end
 return pget(x,y)
end

function dre(e)
 if draw_shots!=e.shot then
  return
 end
 fr=e.fr
 x=e.x-4
 y=e.y-4
 if e.playing then
  if t%2==0 then e.fr+=1 end
  if fget(e.fr,0) then
   kill(e)
  end
  if fget(e.fr,1) then
   if e.fr_trig then
    e.fr_trig(e)
    e.fr_trig=nil
   end
  end
  if fget(e.fr,2) then
   e.fr-=e.bfr
  end       
 end
 
 if e.hurt then
  x+=rand(e.hurt*2)-e.hurt
  y+=rand(e.hurt*2)-e.hurt
 end
 
 if e.flh then
  e.flh-=1
  if e.flh<=0 then
   e.flh=nil
  end
  apal(7)
 end 
 if fr>0 then spr(fr,x,y,1,1,e.flip) end
 pal()

 if e.dre then e.dre(e) end
 
end

function apal(n)
 for i=0,15 do pal(i,n) end
end

function gen_spark() 
 e=mke(0,0,0)
 e.bad=true
 e.spark=true
 recycle(e)
 e.upd=upd_spark
 sparks_count+=1
 return e
end



function upd_spark(e)

 cur=e
 p=pget(cur.x,cur.y) 
 
 function show()
  add_pix(e.x,e.y,50,16+bid)
 end
 
 if p<=1 then
  paint_cur()
 end
  
 -- bew cell
 --fast = #cells==1 and tt<300
 --chance=40+
 chance=10+flr(tt/20)
     
 if rand(chance)==0 and check_cell_pos(cur) then
  make_cell(cur.x,cur.y)
  recycle(cur) 
 end
 
 -- branch
 if rand(max(0,100-e.t*2))==0 and branch() then
  show()
  return   
 end
   
 -- follow  
 if follow() then
  show() 
  return 
 end
   
 if branch() then
  show() 
  return
 end
  
 -- die
 pset(cur.x,cur.y,dc)
 recycle(cur) 
  
end

function check_cell_pos(p)
 for ce in all(cells) do
  if dst(ce,p) < 20 then
			return false
  end
 end
 return is_in(p.x,p.y,8)
end

function recycle(e)
 ce=cells[rand(#cells)+1]
 if not ce or spark_max < sparks_count then
  sparks_count-=1
  kill(e) 
  return 
 end 
 
 e.di=rand(4)
 e.x=ce.x
 e.y=ce.y
 e.t=0
end

function kill(e)
 if e.shot and not e.bad then
  hero.shots-=1
 end
 if e.on_death then
  e.on_death()
 end
 del(ents,e)
end

function upe(e)
 e.t+=1
 if e.upd then e.upd(e) end

 e.vx*=e.frict
 e.vy*=e.frict
 e.x+=e.vx
 e.y+=e.vy
 
 if e.boundary then
  if not is_in(e.x,e.y,-4) then
   kill(e)
  end
 end 
 
 -- cell shoot
 freq=160
 if bid==1 then freq=100 end
 if e.rr and e.t%freq==0 then
  s=shoot(e,gha(e,0.2),1)
 end
 
 -- hit hero
 if e.hit_hero then 
  
  if dst(e,hero)<2+e.ray then
   e.hit_hero(e)
   kill(e)
   return
  end  
 end
 
 if e.shot then
  if e.bad then
   -- todo
  else   
   check_shot_col(e)
  end 
 end
 
 if e.timer then
  e.timer-=1
  if e.timer<=0 then
   kill(e)
  end
 end
 
end

function grab_bonus(bt)

 if bt==0 then
  hero.shot_max+=1
 elseif bt==1 then
  hero.blast+=4
 elseif bt==3 then
  hero.burn+=1 
 end
 
 if bt==2 then
  lives+=1
 else
  add(opts,bt)
 end 
end

function dst(a,b)
 dx=a.x-b.x
 dy=a.y-b.y
 return sqrt(dx*dx+dy*dy)
end

function check_shot_col(e)

 shot=e
 for a in all(ents) do
  if a.hit then
   if dst(a,e)<2+a.ray then
    a.hit(a)
    kill(e)
    return
   end
  end
 end

 
 -- path_col
 r=1
 for dx=0,r*2 do
  for dy=0,r*2 do
   x=e.x+dx-r
   y=e.y+dy-r
   if is_in(x,y) and pget(x,y)>1 then
    kill(e)
    blast(e.x,e.y,4,0)
    sfx(38)
    circfill(e.x,e.y,4,0)
    return
    
   end
  end   
 end
 
end

function blast(x,y,r)
 r+=hero.blast
 circfill(x,y,r,0)
 
 -- sparks
 for s in all(ents) do
  if s.spark then
   dx=s.x-x
   dy=s.y-y
   if sqrt(dx*dx+dy*dy)<r+2 then
    sparks_count-=1
    kill(s)
   end 
  end
 end
  
 -- burn
 rr=r+1
 for i=0,31 do
  an=i/32
  px=flr(x+cos(an)*rr+0.5)
  py=flr(y+sin(an)*rr+0.5)
  burn(px,py,3+hero.burn*6)
 end

 -- fx
 e=mke(0,x,y)
 local an=rnd(1)
 e.dre=function(e)
  rr=r+sqrt(e.t)-2
  circfill(x,y,rr,sget(e.t-1,9))
  
  cc=e.t/8
  cc=sqrt(cc)
  dx=cos(an)*(1-cc)*rr
  dy=sin(an)*(1-cc)*rr
  
  circfill(x+dx,y+dy,cc*rr,0)
  
  if e.t==8 then
   kill(e)
  end  
 end 
end

function burn(x,y,bt)
 pix=pget(x,y)
 if pix!=lc and pix!=dc then
  return
 end
 pset(x,y,0)
 add_pix(x,y,0,12)
 
 if bt>0 then
  e=mke(0,x,y)
 	e.upd=function(e)	
	  if e.t>1 then
	   for di=0,3 do
	    nx=e.x+di4[1+di*2]
	    ny=e.y+di4[2+di*2]
	    burn(nx,ny,bt-1)	   
	   end
	   kill(e)
	  end		 
 	end
	end
	
	
	 
end

 
function is_in(x,y,r)
 if not r then r=0 end
 return x>=r and y>=r and x<128-r and y<128-r
end

function play()

 load_scr()
 foreach(ents,upe)
  
 -- spark max
 spark_max=1
 for ce in all(cells) do
  spark_max+=1
 end 
 --gml=200
 --bonus=-flr(sin(min(t/10,gml)/(gml*2))*10)
 bonus=(12+dif*2)*max(0,1-t/4000)
 spark_max+=flr(bonus)
 if spark_max > sparks_count then
  gen_spark()
 end 
 
 -- check end
 if #cells==0 then
  explode_level()
  next_level()
 end

end

function explode_level() 
 ents={hero}
 tt=0 
 a=scan_parts() 
 cls()  
 for p in all(a) do
  d=dst(hero,p)
  p.fr=74+bid
  impulse(p,0.5+gha(p,0),0.5+rnd(4))
 end
end

function next_level()
 music(17,nil,3)
 
 
 -- loop
 loop=function()
  load_scr()
  foreach(ents,upe)
  
  label("well done!")
  
  if tt==40 then
   sfx(49)
   hero.upd=function()
    hero.vy+=0.1
    hero.fr=66
   end
  end
  if hero.y>140 then  
  
   if dif==3 then
    success()
   else
    complete[bid+1]=true
    dif+=1
    reload()      
    init_select()
   end
  end
 end
 
end

function success()
 music(8)
 ents={hero}
 hero.x=64
 hero.y=96
 hero.upd=upd_hero
 hero.vy=0
 tt=0
 cls()
 reload()
 -- stars
 for i=0,127 do
  s=mke(0,0,0)
  s.c=i/128
  s.bx=rnd(128)
  s.by=rnd(128)
  s.upd=function(s)   
   s.x=s.bx
   s.y=(s.by+t*8*s.c)%128  
  end  
  s.dre=function(s)
   c=min(tt/10,1)*s.c
   col=sget(c*5,11)
   pset(s.x,s.y,col)
  end  
 end
 
 loop=function()
  load_scr()
  foreach(ents,upe)

 end
 
 draw=function()
  cls()
  foreach(ents,dre)
  
  for i=0,15 do
   kt=t+i*6
   x=18+i*6
   y=24+cos((kt%64)/64)*8
   sspr(64+(i%6)*5,64+flr(i/6)*6,5,6,x,y)
  end
  print(ending_text,128-tt,120)
  
 end
 
end

function draw_game()
 save_scr()
 
 -- pix
 for p in all(pxls) do  
  co=sget(p.cx,p.cy)  
  p.cx+=1	
  if co==0 then
   del(pxls,p)
  elseif p.ex then
   if dst(p,hero) < 3 then
    gameover()
   end
   line(p.x,p.y,p.ex,p.ey,co)
  else
   pset(p.x,p.y,co)
  end
 end 

 -- halo
 show_halo()
 
 -- ents
 
 foreach(ents,dre)
  
 -- ents
 draw_shots=true
 foreach(ents,dre) 
 draw_shots=nil
 -- decor
 map(16*bid,0,0,0,16,16)
 
 -- inter
 x=3
 for n in all(opts) do
  spr(53+n,x,120)
  x+=7
 end
 
 x=118
 for n=1,lives do
  spr(60,x,120)
  x-=5
 end
 --trace spark_max
 --rectfill(0,0,20,6,0)
 --print(spark_max.."/"..sparks_count,0,0,7)
end

function _update()
 t=t+1
 tt=tt+1
 if loop then loop() end
  
end



function add_pix(x,y,cx,cy,ex,ey)
 p={x=x,y=y,cx=cx,cy=cy,ex=ex,ey=ey}
 add(pxls,p)
 return p
end



function _draw()
 
 if draw then draw() end

 
 -- log
 y=0
 for msg in all(log_msg) do  
  print(msg,0,y,7)
  y+=8
 end
end

log_msg={}
function log(str)
 add(log_msg,str)
 if #log_msg > 14 then
  del(log_msg,log_msg[1])
 end
end

function show_halo()
 for e in all(ents) do
  --if e.spark then
  --if true then
  if e.halo then
  
   for dx=0,6 do for dy=0,6 do
    x=e.x+dx-3
    y=e.y+dy-3
    --co=sget( 32+pget(x,y),17+bid)
    co=sget( 32+pget(x,y),16)
    if sget(dx+16,dy+8)==7 then
     pset(x,y,co)
    end
   end end
  end
 end
end


text={
 "message to all leucoytes",
 "the spread of infection",
 "is out of control",
 "the brain republica is gone",
 "and no lymph nodes are left.",
 "we can do nothing but struggle",
 "until the very end",
}
 
ending_text="you finally get rid of the infections. the body forces are exhausted and you still have no answers from the spine and the brain. but it seems that few neural cells from the stomach are still able to duplicate and may take command from now on. thanks leucocyte, you're awesome !"