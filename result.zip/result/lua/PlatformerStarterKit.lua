-------------------------------
-- helper functions
-------------------------------

-- creates a deep copy of a
-- table and all its properties
function deep_copy(obj)
 if (type(obj)~="table") return obj
 local cpy={}
 setmetatable(cpy,getmetatable(obj))
 for k,v in pairs(obj) do
  cpy[k]=deep_copy(v)
 end
 return cpy
end

-- adds an element to an index,
-- creating a new table in the
-- index if needed
function index_add(idx,prop,elem)
 if (not idx[prop]) idx[prop]={}
 add(idx[prop],elem)
end

-- calls a method on an object,
-- if it exists
function event(e,evt,p1,p2)
 local fn=e[evt]
 if fn then
  return fn(e,p1,p2)
 end
end

-- returns an entity's property 
-- depending on entity state
-- e.g. hitbox can be specified
-- as {hitbox=box(...)}
-- or {hitbox={
--  walking=box(...),
--  crouching=box(...)
-- }
function state_dependent(e,prop)
 local p=e[prop]
 if (not p) return nil
 if type(p)=="table" and p[e.state] then
  p=p[e.state]
 end
 if type(p)=="table" and p[1] then
  p=p[1]
 end
 return p
end

-- round to nearest whole number
function round(x)
 return flr(x+0.5)
end

-------------------------------
-- objects and classes
-------------------------------

-- "object" is the base class
-- for all other classes
-- new classes are declared
-- by using object:extend({...})
object={}
 function object:extend(kob)
  kob=kob or {}
  kob.extends=self
  return setmetatable(kob,{
   __index=self,
   __call=function(self,ob)
	   ob=setmetatable(ob or {},{__index=kob})
	   local ko,init_fn=kob
	   while ko do
	    if ko.init and ko.init~=init_fn then
	     init_fn=ko.init
	     init_fn(ob)
	    end
	    ko=ko.extends
	   end
	   return ob
  	end
  })
 end

-------------------------------
-- vectors
-------------------------------

vector={}
vector.__index=vector
 -- operators: +, -, *, /
 function vector:__add(b)
  return v(self.x+b.x,self.y+b.y)
 end
 function vector:__sub(b)
  return v(self.x-b.x,self.y-b.y)
 end
 function vector:__mul(m)
  return v(self.x*m,self.y*m)
 end
 function vector:__div(d)
  return v(self.x/d,self.y/d)
 end
 function vector:__unm()
  return v(-self.x,-self.y)
 end
 -- dot product
 function vector:dot(v2)
  return self.x*v2.x+self.y*v2.y
 end
 -- normalization
 function vector:norm()
  return self/sqrt(#self)
 end
 -- length
 function vector:len()
  return sqrt(#self)
 end
 -- the # operator returns
 -- length squared since
 -- that's easier to calculate
 function vector:__len()
  return self.x^2+self.y^2
 end
 -- printable string
 function vector:str()
  return self.x..","..self.y
 end

-- creates a new vector with
-- the x,y coords specified
function v(x,y)
 return setmetatable({
  x=x,y=y
 },vector)
end

-------------------------------
-- collision boxes
-------------------------------

-- collision boxes are just
-- axis-aligned rectangles
cbox=object:extend()
 -- moves the box by the
 -- vector v and returns
 -- the result
 function cbox:translate(v)
  return cbox({
   xl=self.xl+v.x,
   yt=self.yt+v.y,
   xr=self.xr+v.x,
   yb=self.yb+v.y
  })
 end

 -- checks if two boxes
 -- overlap
 function cbox:overlaps(b)
  return
   self.xr>b.xl and
   b.xr>self.xl and
   self.yb>b.yt and
   b.yb>self.yt
 end

 -- calculates a vector that
 -- neatly separates this box
 -- from another. optionally
 -- takes a table of allowed
 -- directions
 function cbox:sepv(b,allowed)
  local candidates={
   v(b.xl-self.xr,0),
   v(b.xr-self.xl,0),
   v(0,b.yt-self.yb),
   v(0,b.yb-self.yt)
  }
  if type(allowed)~="table" then
   allowed={true,true,true,true}
  end
  local ml,mv=32767
  for d,v in pairs(candidates) do
   if allowed[d] and #v<ml then
    ml,mv=#v,v
   end
  end
  return mv
 end
 
 -- printable representation
 function cbox:str()
  return self.xl..","..self.yt..":"..self.xr..","..self.yb
 end

-- makes a new box
function box(xl,yt,xr,yb) 
 return cbox({
  xl=min(xl,xr),xr=max(xl,xr),
  yt=min(yt,yb),yb=max(yt,yb)
 })
end
-- makes a box from two corners
function vbox(v1,v2)
 return box(v1.x,v1.y,v2.x,v2.y)
end

-------------------------------
-- entities
-------------------------------

-- every entity has some
-- basic properties
-- entities have an embedded
-- state that control how
-- they display and how they
-- update each frame
-- if entity is in state "xx",
-- its method "xx" will be called
-- each frame
entity=object:extend({
 state="idle",t=0,
 dynamic=true,
 spawns={}
})
 -- common initialization
 -- for all entity types
 function entity:init()
  if self.sprite then
   self.sprite=deep_copy(self.sprite)
   if not self.render then
    self.render=spr_render
   end
  end
 end
 -- called to transition to
 -- a new state - has no effect
 -- if the entity was in that
 -- state already
 function entity:become(state)
  if state~=self.state then
   self.state,self.t=state,0
  end
 end
 -- checks if entity has 'tag'
 -- on its list of tags
 function entity:is_a(tag)
  if (not self.tags) return false
  for i=1,#self.tags do
   if (self.tags[i]==tag) return true
  end
  return false
 end
 -- called when declaring an
 -- entity class to make it
 -- spawn whenever a tile
 -- with a given number is
 -- encountered on the level map
 function entity:spawns_from(...)
  for tile in all({...}) do
   entity.spawns[tile]=self
  end
 end

-- static entities never move
-- like the level's walls -
-- this lets us optimize a bit,
-- especially for collision
-- detection.
static=entity:extend({
 dynamic=false
})

-------------------------------
-- rendering from the "sprite"
-- property
-------------------------------

function spr_render(e)
 local s,p=e.sprite,e.pos
 -- helper function for
 -- retrieving sprite data
 -- taking entity state into
 -- account, or a default value
 function s_get(prop,dflt)
  local st=s[e.state]
  if (st~=nil and st[prop]~=nil) return st[prop]
  if (s[prop]~=nil) return s[prop]
  return dflt
 end
 -- sprite position
 local sp=p+s_get("offset",v(0,0))
 -- width and height
 local w,h=
  s.width or 1,s.height or 1
 -- orientation
 local flip_x=false
 local frames=s[e.state] or s.idle
 if s.turns then
  if e.facing=="up" then
   frames=frames.u
  elseif e.facing=="down" then
   frames=frames.d
  else
   frames=frames.r
  end
  flip_x=(e.facing=="left")
 end
 if s_get("flips") then
  flip_x=e.flipped
 end
 -- animation
 local delay=frames.delay or 1
 if (type(frames)~="table") frames={frames}
 local frm_index=flr(e.t/delay) % #frames + 1
 local frm=frames[frm_index]
 -- actual drawing
 spr(frm,round(sp.x),round(sp.y),w,h,flip_x)
 -- the current animation frame
 -- is returned, useful for
 -- custom :render() methods
 return frm_index
end

-------------------------------
-- entity registry
-------------------------------

-- entities are indexed for
-- easy access.
-- "entities" is a table with
-- all active entities.
-- "entities_with.<property>"
-- holds all entities that
-- have that property (used by
-- various systems to find
-- entities that move, collide,
-- etc.)
-- "entities_tagged.<tag>"
-- holds all entities with a
-- given tag, and is used for
-- collisions, among other
-- things.

-- resets the entity registry
function entity_reset()
 entities,entities_with,
  entities_tagged={},{},{}
end

-- registers a new entity,
-- making it appear in all
-- indices and update each
-- frame
function e_add(e)
 add(entities,e)
 for p in all(indexed_properties) do
  if (e[p]) index_add(entities_with,p,e)
 end
 if e.tags then
  for t in all(e.tags) do
   index_add(entities_tagged,t,e)
  end
  c_update_bucket(e)
 end
 return e
end

-- removes an entity,
-- effectively making it
-- disappear
function e_remove(e)
 del(entities,e)
 for p in all(indexed_properties) do
  if (e[p]) del(entities_with[p],e)
 end
 if e.tags then
  for t in all(e.tags) do
   del(entities_with[t],e)
   if e.bkt then
    del(c_bucket(t,e.bkt.x,e.bkt.y),e)
   end
  end
 end
 e.bkt=nil
end

-- a list of properties that
-- need an "entities_with"
-- index
indexed_properties={
 "dynamic",
  -- entites that should update
  -- each frame
 "render","render_hud",
  -- entities that render
  -- themselves or a hud
 "vel",
  -- entities that move
  -- (have a velocity)
 "collides_with", 
  -- entities that actively
  -- check for collisions
 "feetbox"
  -- entities that can be
  -- supported by a floor
}

-------------------------------
-- system:
--  entity updating
-------------------------------

-- updates all entities
-- according to their state
function e_update_all()
 for ent in all(entities_with.dynamic) do
  -- call the method with the
  -- name corresponding to
  -- this entity's current
  -- state
  local state=ent.state
  if ent[state] then
   ent[state](ent,ent.t)
  end
  if ent.done then
   -- removed
   e_remove(ent)
  elseif state~=ent.state then
   -- changed state, restart
   -- the "t" counter that
   -- tracks how much time
   -- an entity has spent
   -- in its current state
   ent.t=0
  else
   ent.t+=1
  end  
 end
end

-- schedules a function to be
-- called between udpates -
-- needed for e.g. level
-- changes that reset the
-- entity indexes
function schedule(fn)
 scheduled=fn
end

-------------------------------
-- system:
--  rendering the world
-------------------------------

function r_render_all(prop)
 -- collect all drawables
 -- and sort them into buckets
 -- separated by draw_order
 local drawables={}
 for ent in all(entities_with[prop]) do
  local order=ent.draw_order or 0
  if not drawables[order] then
   drawables[order]={}
  end
  add(drawables[order],ent)  
 end
 -- render the drawable
 -- entities in the right
 -- order (z-indexing)
 for o=0,15 do  
  for ent in all(drawables[o]) do
   r_reset(prop)
   ent[prop](ent,ent.pos)
  end
 end
end

-- helper function that resets
-- pico-8 draw state before
-- each entity
function r_reset(prop)
 pal()
 palt(0,false)
 palt(3,true)
 if (prop~="render_hud" and g_cam) g_cam:apply()
end

-------------------------------
-- system:
--  movement
-------------------------------

function do_movement()
 for ent in all(entities_with.vel) do
  -- entities that have velocity
  -- move by that much each frame
  local ev=ent.vel
  ent.pos+=ev
  -- orientation:
  -- flipped tracks left/right
  -- 'true' is facing left
  if ev.x~=0 then
   ent.flipped=ev.x<0
  end
  -- facing:
  -- 4-direction facing, has
  -- a string value "right"/
  -- "left"/"up"/"down"
  if ev.x~=0 and abs(ev.x)>abs(ev.y) then
   ent.facing=
    ev.x>0 and "right" or "left"
  elseif ev.y~=0 then
   ent.facing=
    ev.y>0 and "down" or "up"
  end
  -- gravity affects velocity
  -- for all entities
  -- define a "weight" property
  if (ent.weight) then
   local w=state_dependent(ent,"weight")
   ent.vel+=v(0,w)
  end
 end
end

-------------------------------
-- system:
--  collision detection
-------------------------------

-- for efficiency, objects
-- requiring collisions are
-- sorted into 16x16 buckets
-- based on their position

-- find bucket coordinates
-- for entity "e"
function c_bkt_coords(e)
 local p=e.pos
 return flr(shr(p.x,4)),flr(shr(p.y,4))
end

-- get the bucket of entities
-- with tag "t" at coords x,y
function c_bucket(t,x,y)
 local key=t..":"..x..","..y
 if not c_buckets[key] then
  c_buckets[key]={}
 end
 return c_buckets[key]
end

-- updates bucket positions
-- for dynamic entities
function c_update_buckets()
 for e in all(entities_with.dynamic) do
  c_update_bucket(e)
 end
end

-- actual bucket update for
-- entity "e". takes care to
-- only update when needed,
-- as switching buckets is
-- costly.
function c_update_bucket(e)
 if (not e.pos or not e.tags) return 
 local bx,by=c_bkt_coords(e)
 if not e.bkt or e.bkt.x~=bx or e.bkt.y~=by then
  if e.bkt then
   for t in all(e.tags) do
    local old=c_bucket(t,e.bkt.x,e.bkt.y)
    del(old,e)
   end
  end
  e.bkt=v(bx,by)  
  for t in all(e.tags) do
   add(c_bucket(t,bx,by),e) 
  end
 end
end

-- iterator that goes over
-- all entities with tag "tag"
-- that can potentially collide
-- with "e" - uses the bucket
-- structure described earlier.
function c_potentials(e,tag)
 local cx,cy=c_bkt_coords(e)
 local bx,by=cx-2,cy-1
 local bkt,nbkt,bi={},0,1
 return function()
  -- ran out of current bucket,
  -- find next non-empty one
  while bi>nbkt do
   bx+=1
   if (bx>cx+1) bx,by=cx-1,by+1
   if (by>cy+1) return nil
   bkt=c_bucket(tag,bx,by)
   nbkt,bi=#bkt,1
  end
  -- return next entity in
  -- current bucket and
  -- increment index
  local e=bkt[bi]
  bi+=1
  return e
 end 
end

-- resets the collision system,
-- making all collision buckets
-- empty again
function collision_reset()
 c_buckets={}
end

-- collision detection main
-- function - detects all
-- requested collisions
function do_collisions()
 -- make sure our bucket
 -- structure is up to date
 c_update_buckets()
 -- iterate over all entities
 -- looking for collisions
 for e in all(entities_with.collides_with) do
  -- ...and all tags they're
  -- interested in
  for tag in all(e.collides_with) do
   -- choose the more efficient
   -- path depending on how
   -- many potential collisions
   -- there are
   local nothers=
    #entities_tagged[tag]  
   if nothers>4 then
    -- for a large number of
    -- possible colliders,
    -- we iterate over our
    -- bucket structure, since
    -- it's more efficient
    for o in c_potentials(e,tag) do
     if o~=e then
      -- get the colliders for
      -- each object
      local ec,oc=
       c_collider(e),c_collider(o)
      -- if both have one,
      -- check for collision
      -- between them
      if ec and oc then
       c_one_collision(ec,oc)
      end
     end
    end
   else
    -- for small numbers, we
    -- just iterate the
    -- entities directly
    for oi=1,nothers do
     local o=entities_tagged[tag][oi]
     -- quick check to rule out
     -- collisions quickly
     local dx,dy=
      abs(e.pos.x-o.pos.x),
      abs(e.pos.y-o.pos.y)
     if dx<=20 and dy<=20 then
      -- quick check passed,
      -- do proper collisions
      -- using hitboxes
      local ec,oc=
       c_collider(e),c_collider(o)
      if ec and oc then
       c_one_collision(ec,oc)
      end
     end
    end
   end     
  end 
 end
end

-- manually check for collision
-- between "box" and object with
-- one of the given "tags"
function c_check(box,tags)
 local fake_e={pos=v(box.xl,box.yt)} 
 for tag in all(tags) do
  for o in c_potentials(fake_e,tag) do
   local oc=c_collider(o)
   if oc and box:overlaps(oc.b) then
    return oc.e
   end
  end
 end
 return nil
end

-- checks for one collision
-- and calls the reaction
-- callbacks on each object
function c_one_collision(ec,oc)
 if ec.b:overlaps(oc.b) then
  c_reaction(ec,oc)
  c_reaction(oc,ec)
 end
end

-- calls the :collide() method
-- on a colliding object, if
-- one exists. if the return
-- value is c_push_out or
-- c_move_out, it acts on
-- that - separating the
-- colliding entities by moving
-- one of them.
function c_reaction(ec,oc)
 local reaction,param=
  event(ec.e,"collide",oc.e)
 if type(reaction)=="function" then
  reaction(ec,oc,param)
 end
end

-- returns the collider for
-- a given entity.
function c_collider(ent)
 -- colliders are cached
 -- for efficiency, but they
 -- are only valid for one
 -- frame
 if ent.collider then 
  if ent.coll_ts==g_time or not ent.dynamic then
   return ent.collider
  end
 end
 -- nothing cached, create
 -- new collider
 local hb=state_dependent(ent,"hitbox")
 if (not hb) return nil
 local coll={
  b=hb:translate(ent.pos),
  e=ent
 }
 -- cache it and return
 ent.collider,ent.coll_ts=
  coll,g_time
 return coll
end

-- reaction function, used by
-- returning it from :collide().
-- cause the other object to
-- be pushed out so it no
-- longer collides.
function c_push_out(oc,ec,allowed_dirs)
 local sepv=ec.b:sepv(oc.b,allowed_dirs)
 ec.e.pos+=sepv
 if ec.e.vel then
  local vdot=ec.e.vel:dot(sepv)
  if vdot<0 then
   if (sepv.y~=0) ec.e.vel.y=0
   if (sepv.x~=0) ec.e.vel.x=0
  end
 end
 ec.b=ec.b:translate(sepv)
end
-- inverse of c_push_out - moves
-- the object with the :collide()
-- method out of the other object.
function c_move_out(oc,ec,allowed)
 return c_push_out(ec,oc,allowed)
end

-------------------------------
-- system:
--  support
--  basically objects being
--  supported by floors
-------------------------------

function do_supports()
 -- entities that want support
 -- have a special collision box
 -- called the "feetbox"
 for e in all(entities_with.feetbox) do  
  local fb=e.feetbox
  if fb then
   -- look for support
   fb=fb:translate(e.pos)
   local support=c_check(fb,{"walls"})
   -- if found, store it for
   -- later - entity update
   -- functions can use the
   -- information
   e.supported_by=support
   -- objects supported by
   -- something move with
   -- whatever supports them
   -- (e.g. standing on 
   -- moving platforms)
   if support and support.vel then
    e.pos+=support.vel
   end
  end
 end
end

-------------------------------
-- entity:
--  parallax background
-------------------------------

bg=entity:extend({
 -- draws early so
 -- that everything covers it
 draw_order=0
})
 function bg:render()
  -- applies the camera
  -- with a small multiplier
  -- so the background moves
  -- less than the foreground
  g_cam:apply(0.2)
  map(109,0,-2,0,19,20)
  map(109,0,150,0,19,20)
 end

-------------------------------
-- entity:
--  level map
-------------------------------

-- the level entity only draws
-- the level using map().
-- collisions are taken care of
-- by individual solid/support
-- entities created on level
-- initialization.
level=entity:extend({
 draw_order=1
})
 function level:init()
  local b,s=
   self.base,self.size
  for x=0,s.x-1 do
   for y=0,s.y-1 do
    -- get tile number
    local blk=mget(b.x+x,b.y+y)    
    -- does this tile spawn
    -- an entity?
    local eclass=entity.spawns[blk]
    if eclass then
     -- yes, it spawns one
     -- let's do it!
     local e=eclass({
      pos=v(x,y)*8,
      tile=blk
     })
     -- register the entity
     e_add(e)
     -- replace the tile
     -- with empty space
     -- in the map
     mset(b.x+x,b.y+y,0)
     blk=0
    end
    -- check what type of tile
    -- this is
    local btype=block_type(blk)
    if btype then
     -- it's not empty,
     -- so it gets an entity
     local b=btype({
      pos=v(x,y)*8,
      map_pos=b+v(x,y),
      typ=bt
     })
     -- register only if needed
     -- (walls completely
     -- surrouned by other
     -- walls aren't)
     if (b.needed) e_add(b)
    end
   end
  end
 end
 -- renders the level
 function level:render()
  palt(3,false)
  map(self.base.x,self.base.y,
   0,0,self.size.x,self.size.y)
 end

-- solid blocks push everything
-- out
solid=static:extend({
 tags={"walls"},
 hitbox=box(0,0,8,8)
})
-- supports are blocks you can
-- stand on, but they don't
-- push you out if you jump
-- from below them
support=solid:extend({
 tags={"walls","bridge"},
 hitbox=box(0,0,8,1)
})
 function solid:init()
  -- magic for collision detection
  -- basically, each block
  -- will only push the player
  -- out in the direction of
  -- empty space
  local dirs={v(-1,0),v(1,0),v(0,-1),v(0,1)}
  local allowed={}
  local needed=false
  for i=1,4 do
   local np=self.map_pos+dirs[i]
   allowed[i]=
    block_type(mget(np.x,np.y))
     ~=solid
   needed=needed or allowed[i]
  end
  self.allowed=allowed
  self.needed=needed
 end
 
 -- solids push the player
 -- out
 function solid:collide(e)
  return c_push_out,self.allowed
 end
 
 -- supports only push the
 -- player out conditionally
 function support:collide(e)
  if (not e.vel) return
  local dy,vy=e.pos.y-self.pos.y,e.vel.y
  if vy>0 and dy<=vy+1 then
   return c_push_out,{false,false,true,false}   
  end
 end

-- block types depend on the
-- sprite flags set in the
-- sprite editor. flag 0 set
-- means a solid block, flag 1 -
-- a support, bridge-type block
function block_type(blk)
 if (fget(blk,0)) return solid
 if (fget(blk,1)) return support
 return nil
end

-------------------------------
-- entity:
--  spikes
-------------------------------

spikes=entity:extend({
 -- different hitboxes for
 -- each tile - different spike
 -- orientations
 hitboxes={
  [80]=box(1,1,7,7),
  [178]=box(1,4,7,8),
  [179]=box(1,0,7,4),
  [163]=box(0,1,4,7),
  [147]=box(4,1,8,7)
 },
 -- spikes kill the player,
 -- so they want collisions
 collides_with={"guy"}
})
spikes:spawns_from(
 178,179,163,147,80
)
 -- choose the right hitbox
 -- on initialization
 function spikes:init()
  self.hitbox=spikes.hitboxes[self.tile]
  self.sprite={idle={self.tile}}
 end
 -- kill on collision
 function spikes:collide(o)
  o:kill()
 end
 -- rendering (just the default
 -- one)
 function spikes:render()
  spr_render(self)
 end

-------------------------------
-- entity: launcher
-------------------------------

-- launchers are trampolines
-- you can jump on
launcher=entity:extend({
 -- launch on collision,
 -- so need to know about them
 collides_with={"guy"},
 hitbox=box(0,5,8,8),
 -- have two states with
 -- different sprites
 sprite={
  idle={136},extended={137}
 }
})
launcher:spawns_from(136)
	-- on collision, we check
	-- if we were actually jumped
	-- on or just walked into
 function launcher:collide(o)
  if self.state=="idle" and
   not o.supported_by then
    -- detected player jumping
    -- on this, change state
    -- and launch player up
    self:become("extended")
    o:become("fly")
    o.vel=v(o.vel.x,-4.4)   
  end
 end
 function launcher:extended(t)
  -- when extended, we just
  -- return to normal after
  -- 15 frames
  if (t>=15) self:become("idle")
 end
 
-------------------------------
-- entity: ladder
-------------------------------
 
-- the ladder entity actually
-- takes care of all ladder-like
-- objects - ropes, vines, etc.
ladder=entity:extend({
 tags={"ladder"},
 hitbox=box(2,-1,6,8)
})
-- that's why it spawns from
-- all those tiles
ladder:spawns_from(
 65,97,113,114,115,
 81,66,82,98
)
 -- the entity only handles
 -- rendering - climbing
 -- happens in player code
 function ladder:render(p)
  palt(3,false)
  spr(self.tile,p.x,p.y)
 end

-------------------------------
-- entity: coin
-------------------------------
   
coin=entity:extend({
 -- coins have an animated
 -- sprite with 4 frames
 sprite={
  idle={184,185,186,187,delay=4}
 },
 -- they disappear on collision
 collides_with={"guy"},
 hitbox=box(0,0,8,8)
})
coin:spawns_from(184)
 -- randomize self.t to
 -- make coins start their
 -- animations from different
 -- spots
 function coin:init()
  self.t+=rnd()*6
 end
 -- on collision, disappear
 -- point-counting would happen
 -- here, if we had it
 function coin:collide(o)
  self.done=true
 end

-------------------------------
-- entity: moving platform
-------------------------------

-- moving platforms come
-- in two sizes
platform=entity:extend({
 -- they start out moving
 state="moving",
 -- they are tagged as walls,
 -- since they behave exactly
 -- the same - other than moving
 tags={"walls"},
 sprite={idle={162}},
 -- they collide with other walls
 -- and turn around when they do
 collides_with={"walls"},
 hitbox=box(0,0,8,8)
})
-- wide platforms just override
-- the looks and the hitbox
wide_platform=platform:extend({
 sprite={
  idle={176},
  width=2
 },
 hitbox=box(0,0,16,8)
})
platform:spawns_from(162)
wide_platform:spawns_from(176)
 -- platforms start out
 -- moving to the right
 function platform:init()
  self.vel=v(1,0)
 end
 -- platforms have two
 -- states: moving and waiting
 -- after they hit something
 function platform:moving()
 end
 function platform:waiting(t)
  if t>=40 then
   -- 40 frames after colliding
   -- we start moving again
   -- in the opposite direction
   self.vel=self.next_vel
   self:become("moving")
  end
 end
 function platform:collide(o)
  if o:is_a("walls") then
   -- collision with other
   -- wall/platform - wait,
   -- then turn around
   if (#self.vel>0) then
    self.next_vel=-self.vel
   end
   self.vel=v(0,0)
   self:become("waiting")
   -- also, move out to avoid
   -- penetrating the other
   -- object
   return c_move_out
  end
  -- when colliding with player,
  -- we act like a normal wall
  if (o:is_a("guy")) return c_push_out
 end

-------------------------------
-- entity: water
-------------------------------

water=entity:extend({
 -- water kills, so collisions
 -- are needed
 hitbox=box(0,0,8,8),
 collides_with={"guy"},
 -- colors for surface animation
 colors={5,12,12,6,6,7}
})
water:spawns_from(96)
 function water:init()
  -- initialize sine wave
  -- offsets for surface
  -- animation
  self.offsets={}
  for x=0,7 do
   self.offsets[x]=rnd()
  end
 end
 -- kill player on contact
 function water:collide(o)
  if o:is_a("guy") then
   o:kill()
  end
 end
 -- rendering
 function water:render(p)
  -- first, the tile
  spr(96,p.x,p.y)
  -- then, the 8 pixels
  -- on the surface will
  -- flash according to
  -- sine waves for a "wavy"
  -- appearance
  for x=0,7 do
   local sv=sin(self.t/40+self.offsets[x])*3+4
   local c=self.colors[flr(sv)]
   pset(p.x+x,p.y,c)
  end
 end

-------------------------------
-- entity: bat
-------------------------------
 
bat=entity:extend({
 -- it's an enemy
 tags={"enemy"},
 -- starts out in the 'fly' state
 state="fly",
 -- moves, starts with 0 velocity
 vel=v(0,0),
 -- same animation for
 -- both states
 sprite={
  fly={32,33,34,33,delay=4},
  back={32,33,34,33,delay=4}
 },
 -- draw order 5 to render
 -- in front of walls
 draw_order=5,
 -- collides with walls (so
 -- it doesn't go through them)
 -- and the player (to kill)
 collides_with={"guy","walls"},
 hitbox=box(2,2,6,6),
})
bat:spawns_from(32)
 function bat:init()
  -- bats remember their origin
  -- so they can return there
  -- in the "back" state
  self.origin=self.pos
 end
 function bat:fly(t)
  -- bats fly by randomly
  -- changing their velocity
  self.vel=v(rnd()-0.5,rnd()-0.5)
  self.vel*=1.75
  -- after a while spent flying,
  -- they go back to their
  -- origin
  if (t>120) self:become("back")
 end
 function bat:back(t)
  -- going back to origin
  -- is done by calculating
  -- a vector to there and
  -- normalizing it to limit
  -- speed
  self.vel=(self.origin-self.pos)  
  if #self.vel>0.25 then   
   -- we're not there yet
   self.vel=self.vel:norm()*0.5
  else
   -- we're there, start
   -- flying away again
   self:become("fly")
  end
 end  
 -- different behaviour
 -- depending on what we
 -- collide with
 function bat:collide(o)
  if o:is_a("guy") then
   o:kill()
  else
   return c_move_out
  end
 end

-------------------------------
-- entity: bird
-------------------------------

-- birds go back and forth
-- without regard to gravity
bird=entity:extend({
 state="fly",
 -- animation, flips set to true
 -- since the bird is either
 -- going right or left
 sprite={
  fly={35,36,37,37,36,35,delay=6},
  flips=true
 },
 draw_order=5,
 -- start out going to
 -- the right
 vel=v(0.5,0),
 -- collisions
 collides_with={"guy","walls"},
 hitbox=box(2,2,6,6)
})
bird:spawns_from(52)
 -- turn around on collision,
 -- kill player on contact
 function bird:collide(o)
  if o:is_a("walls") then
   self.vel=-self.vel
  end
  if o:is_a("guy") then
   o:kill()
  end
 end

-------------------------------
-- entity: enemy spearman
-------------------------------

spearman=entity:extend({
 -- starts out going right
 state="walking",
 vel=v(0.5,0),
 -- affected by gravity
 weight=0.2,
 -- has a few animated states
 sprite={
  aggro={195},
  walking={195,196,195,197,delay=6},
  charge={195,196,195,197,delay=3},
  fly={193},
  offset=v(-4,-13),
  height=2,
  flips=true
 },
 -- holds a spear, its position
 -- depends on animation frame
 -- while walking - these
 -- are the offsets
 spear_pos={
  v(-2,-7),v(-1,-7),
  v(-2,-7),v(-2,-8)
 },
 -- draws in front of most
 -- things
 draw_order=10,
 -- has both hitbox and feetbox
 -- since it stands on floors
 collides_with={"walls","guy"},
 hitbox=box(-2,-10,2,-1),
 feetbox=box(-4,-1,4,-0.999),
 -- has an additional box it
 -- uses to check terrain in
 -- front of itself - to turn
 -- around before it falls
 floorbox=box(-2,0,2,1)
})
spearman:spawns_from(19)
 -- default "patrol" state
 function spearman:walking()
  -- feel for ground, turn
  -- around if it'd fall
  local feel=self:feel_around()
  if (feel) self:turn()
  -- look for player and
  -- become aggressive if
  -- you see him/her
  if self:check_aggro() then
   self:become("aggro")
  end
 end
 
 -- when aggro, the spearman
 -- just stands in place
 -- readying a charge
 function spearman:aggro(t)
  self.vel=v(0,0)
  -- charge after 20 frames
  if (t>=20) self:become("charge")
 end
 
 -- charging is like walking,
 -- but faster
 function spearman:charge()
  self.vel=v(self.flipped and -1 or 1,0)
  -- we only turn around if we
  -- see a wall, but not if we're
  -- going to fall - letting the
  -- player goad spearmen into
  -- falling from their platform
  local feel=self:feel_around()
  if feel=="wall" then
   self:turn()
  end
  -- since we can actually
  -- fall, we should handle
  -- that
  self:do_falls()
 end
 
 -- fly state - when falling
 -- from a platform after
 -- a charge
 function spearman:fly()
  -- did we land?
  if self.supported_by then
   self:become("walking")
  end
  -- did we fall off-screen?
  self.done=self.pos.y>g_level.size.y*8
 end
 
 -- turning
 function spearman:turn()
  self:become("walking")
  self.vel=self.flipped
   and v(0.5,0) or v(-0.5,0)
 end
 
 -- feeling around, returns
 -- "wall" if a wall is in front,
 -- "fall" if we ran out of
 -- platform to walk on,
 -- or nil if none of that
 -- happened
 function spearman:feel_around()
  local felt=nil
  if self.prev and #(self.prev-self.pos)==0 then
   felt="wall"
  elseif not self:check_ground() then
   felt="fall"
  end
  self.prev=self.pos
  return felt
 end
 
 -- check for player - we become
 -- aggressive when the player
 -- is on roughly the same
 -- level as us and close by
 function spearman:check_aggro()
  local dy=g_guy.pos.y-self.pos.y
  if (abs(dy)>2) return false
  local dx=g_guy.pos.x-self.pos.x
  return abs(dx)<64 and (sgn(dx)==sgn(self.vel.x))
 end
 
 -- check if there is ground
 -- in front of us - uses
 -- the floorbox to query
 -- the collision system
 function spearman:check_ground()
  if not self.supported_by then
   return true
  end
  local projected_move=
   self.pos+v(self.vel.x*8,0)
  local box=self.floorbox:translate(projected_move)  
  return c_check(box,{"walls"})~=nil
 end
 
 -- fall if not supported
 -- by a floor
 function spearman:do_falls()
  if not self.supported_by then
   self:become("fly")
  end
 end
 
 -- kill player on collision
 function spearman:collide(o)
  if o:is_a("guy") then
   o:kill()  
  end
 end
 
 -- custom rendering - draws
 -- the standard animated
 -- sprite first, then draws
 -- a spear on top (depending
 -- on the animation)
 function spearman:render(p)
  -- draw person
  local frame=spr_render(self)
  -- draw the spear
  local sp=self.spear_pos[frame]
  if self.flipped then
   sp=v(-sp.x-7,sp.y)
  end
  sp+=self.pos
  spr(63,sp.x,sp.y,1,1,self.flipped)
  -- if we're aggroed, draw
  -- an exclamation point to
  -- alert the player
  if self.state=="aggro" then
   print("!",self.pos.x-1,self.pos.y-18,8)
  end
 end  

-------------------------------
-- encja:
--  chlopek
-------------------------------

-- the main player entity
guy=entity:extend({
 tags={"guy"},
 -- starts falling down
 state="fly",
 -- moves
 vel=v(0,0),
 -- affected by gravity,
 -- except when climbing
 weight={0.2,climb=0},
 -- various animations
 sprite={
  walk={205,206,205,207,delay=5},
  idle={205},
  crouch={202,offset=v(-4,-10)}, 
  fly={204},
  dead={207},
  climb={200,201,delay=6,flips=false},
  offset=v(-4,-13),
  height=2,
  flips=true
 },
 draw_order=10,
 -- collides with stuff
 collides_with={"walls","ladder"},
 -- hitbox is smaller when
 -- crouching
 hitbox={
  box(-2,-10,2,-1),
  crouch=box(-2,-6,2,-1)
 },
 -- has a feetbox to be able
 -- to stand on floors
 feetbox=box(-2,-1,2,-0.999)
})
guy:spawns_from(205)
 -- stores itself in a global
 -- when created - accessing
 -- the player entity easily
 -- from other code
 -- is very convenient
 function guy:init()
  g_guy=self
 end
 -- flying
 function guy:fly(t)
  -- altitude control for jumping
  -- the longer you hold the
  -- jump button, the higher
  -- the jump
  if btn(4) and not btn(3) and t<10 and not self.dropping then
   self.vel.y=-1.75
  end
  -- air control - you can
  -- move left/right when
  -- airborne, but more sluggishly
  -- than on the ground
  if (btn(0)) self.vel-=v(0.3,0)
  if (btn(1)) self.vel+=v(0.3,0)
  -- air resistance - limits
  -- both downward speed and
  -- the horizontal speed
  -- and jump length
  self.vel.x*=(1/1.3)
  -- different animation
  -- frames for jumping up/
  -- falling
  self.sprite.fly[1]=
   self.vel.y>0 and 203 or 204
  -- did we land?
  if self.supported_by and self.vel.y>0 then
   self.vel=v(0,0)
   self:become("idle")
  end
  -- did we hit a ladder?
  if self.on_ladder and self.vel.y>=0 then
   self:become("climb")
  end
  -- did we fall off-screen?
  if self.pos.y>g_level.size.y*8 then
   self:kill()
  end
 end
 -- from the idle state, we
 -- can start walking or jump
 function guy:idle()
  self:do_walking()
  self:do_verticals()
  self:do_ladders()
 end   
 -- from the walking state, we
 -- can continue walking, stop,
 -- or jump
 function guy:walk(t)
  self:do_walking()
  self:do_verticals()
  self:do_ladders()
 end
 -- when crouching, we can't walk
 function guy:crouch()
  if (not btn(3)) self:become("idle")
  -- slide if our velocity
  -- was non-zero when we crouched
  self.vel.x*=0.8
  -- if we're on a bridge-type
  -- tile, down+jump will drop
  -- us one level down
  if btnp(4) and self.supported_by:is_a("bridge") then
   self.pos+=v(0,2)
   self:become("fly")
   return
  end
  self:do_verticals()
 end
 -- "dead" state - dead players
 -- aren't removed to keep
 -- other code working properly
 function guy:dead()
  -- restart the level on
  -- button press
  if btnp(4) or btnp(5) then
   schedule(restart_level)
  end
  -- stop falling at some point
  -- to prevent the y-position
  -- from overflowing
  if self.pos.y>g_level.size.y*8+50 then
   self.vel=v(0,0)
   self.weight=0
  end
 end
 -- when climbing, you can move
 -- in all directions unaffected
 -- by gravity
 function guy:climb()
  -- you can jump from
  -- ladders
  if btnp(4) then
   self.vel.y=-1.75
   self.on_ladder=false
   self:become("fly")
   return
  end
  -- when you move away from
  -- the ladder, you start
  -- falling
  if not self.on_ladder then
   self:become("fly")
   return
  end
  -- 4-direction movement
  self.vel=v(0,0)
  if (btn(0)) self.vel-=v(0.6,0)
  if (btn(1)) self.vel+=v(0.6,0)
  if (btn(2)) self.vel-=v(0,0.6)
  if (btn(3)) self.vel+=v(0,0.6)
  -- only animate while
  -- moving (dirty trick,
  -- sorry)
  if #self.vel==0 then
   self.t-=1
  end
  -- reset the 'on_ladder'
  -- flag - it will be set
  -- back to true during
  -- collision detection if
  -- we're still on one
  self.on_ladder=false
 end
 
 -- collisions
 function guy:collide(o)
  -- colliding with ladders
  -- just sets a flag
  if o:is_a("ladder") then
   self.on_ladder=true
  end
 end
   
 -- getting killed turns
 -- off collisions and
 -- makes us dead
 function guy:kill()
  self.vel=v(0,-1)
  self.hitbox=false
  self.feetbox=false
  self:become("dead")
 end
 -- common multiple-state stuff
 function guy:do_walking()
  -- determine walking speed
  -- based on input
  self.vel=v(0,0)
  if (btn(1)) self.vel=v(1,0)
  if (btn(0)) self.vel=v(-1,0)
  -- change state based
  -- on whether we're moving
  if self.vel.x~=0 then
   self:become("walk")
  else
   self:become("idle")
  end
 end
 
 function guy:do_verticals()
  -- did we fall down?
  if not self.supported_by then
   self:become("fly")
   return
  end
  -- are we jumping?
  if (btn(4)) then
   self:become("fly")
   self.vel.y=-1.75
  end
  -- are we crouching?
  if (btn(3)) then
   self:become("crouch")
  end  
 end
 
 function guy:do_ladders()
  -- should we start climbing?
  if self.on_ladder and (btn(2) or btn(3)) then
   self:become("climb")
  end
 end
 
 -- hud rendering
 function guy:render_hud()
  function p(s,x,y,c)
   print(s,x-#s*2,y+1,0)
   print(s,x-#s*2+1,y,0)
   print(s,x-#s*2,y,c)
  end
  if self.state=="dead" then
   p("press 🅾️ to restart",
    64,100,10)
   p("- you died -",
    64,94,14)
  end
 end

-------------------------------
-- camera
-------------------------------

cam=object:extend({
 -- hold the player
 -- in a window of this size
 window_size=v(20,20),
 p=v(0,0)
})
 function cam:init()
  local ws=self.window_size
  self.window=vbox(
   -ws*0.5-v(64,64),
    ws*0.5-v(64,64)
  )
  self.limits=vbox(
   v(0,0),
   self.level.size*8-v(128,128)
  )
 end
 function cam:update()
  local gp,w,l=self.guy.pos,
   self.window,self.limits
  -- player tracking
  self.p.x=mid(self.p.x,
   gp.x+w.xl,gp.x+w.xr)
  self.p.y=mid(self.p.y,
   gp.y+w.yt,gp.y+w.yb)
  -- limit to map size
  self.p.x=mid(self.p.x,l.xl,l.xr)
  self.p.y=mid(self.p.y,l.yt,l.yb)
 end
 -- apply the camera
 -- transformation
 function cam:apply(magnitude)
  if (not magnitude) magnitude=1
  self:update()
  local d=self.p*magnitude
  camera(d.x,d.y)
 end

-------------------------------
-- initialization
-------------------------------

function _init()
 level_settings={
  base=v(0,0),
  size=v(47,27)
 }
 restart_level()
end

function restart_level()
 -- reload map
 reload(0x2000,0x2000,0x1000)
 -- reset systems
 entity_reset()
 collision_reset()
 -- create entities
 e_add(bg())
 g_level=e_add(level(
  level_settings
 ))
 -- and the camera
 g_cam=cam({
  guy=g_guy,
  level=g_level
 })
end

-------------------------------
-- main loop, just
-- calls the other systems
-------------------------------

g_time=0
function _update60()
 if scheduled then
  scheduled()
  scheduled=nil
 end
 e_update_all()
 do_movement()
 do_collisions()
 do_supports()
 g_time+=1
end

function _draw()
 cls()
 r_render_all("render")
 camera()
 r_render_all("render_hud")
end
