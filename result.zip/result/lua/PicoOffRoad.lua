-- pico off road
-- by assembler bot (2021)
function lz77_decomp(x0,y0,w,h,src,vset)
	local i,d=1,{}
	while i<=#src do
		local c=ord(src,i)
		if c<48 then
			add(d,c-32)
		else
			local ofs,run=w,c-46
			if c>=94 then
				run-=29
			end
			if run>=103 then
				run-=101
			else
				i+=1
				ofs=ord(src,i)-31
				if ofs>=63 then
					ofs-=29
				end
			end
			local pos=#d-ofs
			for j=1,run do
				add(d,d[pos+j])
			end
		end
		i+=1
	end
	for i=0,w*h-1 do
		vset(i%w+x0,i\w+y0,d[i+1])
	end
end



hpi=1.57075
pi=3.1415
pi2=6.283

cos1 = cos function cos(angle) return cos1(angle/(pi2)) end
sin1 = sin function sin(angle) return -sin1(angle/(pi2)) end
atan21 = atan2 function atan2(x,y) return atan21(x,-y)*pi2 end

function isometry(x,y,z)
	return x+511-z/2, z/2-y
end

function clamp(a,min_value,max_value)
	return min(max(a,min_value), max_value)
end

function rotate(x,y,angle)
	local c=cos(angle)
	local s=sin(angle)
	return x*c-y*s,x*s+y*c
end

function rotatesincos(x,y,s,c)
	return x*c-y*s,x*s+y*c
end

function cross(x1,y1,z1,x2,y2,z2)
	return y1*z2-z1*y2, z1*x2-x1*z2, x1*y2-y1*x2
end

function dot(x1,y1,z1,x2,y2,z2)
	return x1*x2+y1*y2+z1*z2
end

function normalize(x,y,z)
	local d=1/sqrt(x*x+y*y+z*z)
	return x*d,y*d,z*d
end

function normalize2d(x,y)
	local d=1/sqrt(x*x+y*y)
	return x*d,y*d
end

function lerp(a,b,t)
	return a+(b-a)*t
end


function project_vertices(vertices_in, vertices_out, offset_x,offset_y)
	for i=1,#vertices_in do
		vertices_out[i]={x=flr(vertices_in[i].x+0.5*vertices_in[i].z)+offset_x,y=flr(vertices_in[i].y-0.5*vertices_in[i].z)+offset_y}
	end
end

function sort_triangles(vertices,triangles)
	local triangles_count=#triangles/4
	for i=0,triangles_count-2 do
		local z1=(vertices[triangles[1+i*4]].z+vertices[triangles[2+i*4]].z+vertices[triangles[3+i*4]].z)/3
		local best_i=i
		local best_z=z1
		for j=i+1,triangles_count-1 do
			local z2=(vertices[triangles[1+j*4]].z+vertices[triangles[2+j*4]].z+vertices[triangles[3+j*4]].z)/3
			if z2>best_z then
				best_i=j
				best_z=z2
			end
		end
		if best_i~=i then
			for j=0,3 do
				triangles[1+i*4+j],triangles[1+best_i*4+j]=triangles[1+best_i*4+j],triangles[1+i*4+j]
			end
		end
	end
end

function cull_triangles(vertices,triangles,dir_x,dir_y,dir_z)
	local out={}
	local triangles_count=#triangles/4
	for i=0,triangles_count-1 do
		local nx,ny,nz = calc_triangle_normal(vertices,triangles,i)
		if dot(nx,ny,nz,dir_x,dir_y,dir_z) < 0 then
			for j=1,4 do
				add(out,triangles[j+i*4])
			end
		end
	end
	return out
end

function calc_triangle_normal(vertices,triangles,idx)
	local i1=triangles[1+idx*4]
	local i2=triangles[2+idx*4]
	local i3=triangles[3+idx*4]
	return cross(vertices[i3].x-vertices[i1].x,vertices[i3].y-vertices[i1].y,vertices[i3].z-vertices[i1].z,vertices[i2].x-vertices[i1].x,vertices[i2].y-vertices[i1].y,vertices[i2].z-vertices[i1].z)
end

function draw_triangles(vertices2d,triangles)
	local triangles_count=#triangles/4
	for i=0,triangles_count-1 do
		draw_triangle(vertices2d[triangles[1+i*4]],vertices2d[triangles[2+i*4]],vertices2d[triangles[3+i*4]],triangles[4+i*4]-1)
	end
end

function draw_triangle(v1,v2,v3,colour)
	local x1,y1,x2,y2,x3,y3=v1.x,v1.y,v2.x,v2.y,v3.x,v3.y
	if x1==x2 and y1==y2 then
		pset(x1,y1,color)
		return
	end

	if y2<y1 then
		x1,y1,x2,y2=x2,y2,x1,y1
	end
	if y3<y2 then
		x2,y2,x3,y3=x3,y3,x2,y2
	end
	if y2<y1 then
		x1,y1,x2,y2=x2,y2,x1,y1
	end
	
	local y=y1
	local dxl=(x2-x1)/(y2-y1)
	local dxr=(x3-x1)/(y3-y1)
	local xl,xr=x1,x1
	
	while y<y2 do
		rectfill(xl,y,xr,y,colour)
		xl+=dxl
		xr+=dxr
		y+=1
	end
	
	xl=x2
	dxl=(x3-x2)/(y3-y2)
	while y<=y3 do
		rectfill(xl,y,xr,y,colour)
		xl+=dxl
		xr+=dxr
		y+=1
	end
end



transparent_patterns={
	0b1111111111111111.1,
	0b0101111101011111.1,
	0b0101111001011110.1,
	0b0101101001011010.1,
	0b0101100001011000.1,
	0b0101000001010000.1,
	0b0100000001000000.1,
	0b0000000000000000.1
}

function set_transparent_pattern(alpha)
	fillp(transparent_patterns[ceil(clamp(alpha*(#transparent_patterns-1),0,#transparent_patterns-1))+1])
end

function draw_sprite4(sx,sy,sw,sh,dx,dy)
	for ry=0,sh-1 do
		for rx=0,sw-1 do
			local c=sget(rx+sx,ry+sy)
			if c~=0 then
				rectfill(dx+rx*4,dy+ry*4,dx+rx*4+3,dy+ry*4+3,c)
			end
		end
	end
end

function printo(text,x,y,c)
	local d={0,0,-1,1,0,0}
	for j=1,4 do
		print(text, x+d[j+2], y+d[j], 0)
	end
	print(text, x, y, c)
end

function time_str(t)
	return tostr(num_to_str2(t\60)..":"..num_to_str21(t%60))
end

function num_to_str2(n)
	return tostr(n\10)..flr(n%10)
end

function num_to_str21(n)
	local tenths=flr((n%10)*10)
	return tostr(n\10)..tenths\10 .."."..tenths%10
end

function lap_to_str(lap)
	if lap==-1 then
		return ""
	end
	return "l"..(lap+1)
end

function draw_progress(x1,y1,x2,v,c1,c2)
	local y2=y1+3
	line(x1+1,y1,x2-1,y1,0)
	line(x1+1,y2,x2-1,y2,0)
	line(x1,y1+1,x1,y2-1,0)
	line(x2,y1+1,x2,y2-1,0)
	
	x1+=1
	x2-=1
	local x=flr(x2-(x2-x1)*v)
	if x>=x2 then return end
	
	line(x,y1+1,x2,y1+1,c1)
	line(x,y1+2,x2,y1+2,c2)
end




racing_map1=[[ロ^:リモム^<えzお;ええお:えおお9えかお.ワヲえrっっツ^ テトc!んんえbお'ツお#う#ツえmお&う ツツえbく&▥ お#う"え*メそ"c#の(や^ え*お そ う"ををソコクゆ^#クケコク^ c#a(え&お"え!ツす%ををツえ_わえ0せ う え_わえ)ナナえ%う!え^わわやえ(ニニえ$う"え@う え)★!え"g"え^やえ$⧗'え"b#リモみ#も メh"c#a(う え#お"え8f5えzろえ%お!ツナナツゃえgやろろえ)ニニツゃお(え)ク^"ゆ^)p やお も%え ツう ツツえ2れえ4やえ*う!こ t ゅゅえ,お"え0や▒&ロう%え ゅゅやえ+クお"え;ロう$ツう!え-お"え-`!▒'ロう$ツう!え.お!え-▥'え"^%え3⬅️,k0お%ツう えvロツ^ えmお&えのお$ンナ^ ンえnか#ッニ^ ッえ@メ○(お)ツ^ ロえ-るるて$ホフ^$ヘケコふ!a$りりえ:るる웃%オウ^$エえ)りりクも#え3う'え3う え9う'ケコえ'ぬ&う"え#う え1☉&え2う"え+ツえ*う&え2う#え#お!え!ょょえ?も$う$え*ょょツソコも"アアさ'も メモホフ^$ヘえ%め サササえ$お う"え$アアu%d7え シシシえ(う!え#う え_`!も%ロう"え"う!えl^#リモムムう!え@サササ✽)え'ふ*え7シシシえ3お"え?^#も'えむお"えしサ^!✽*えhシ^!え6お=らら⬇️"░+え(イイムメた!さ.⬆️#ククお$え4イイククケコ웃%クよg&f'お#も+え%う!え$や`!え e"お/え2う"え$➡️"え _0お!え+ムえ"う#…)え3お!え2う(や`"よe$お/え,ムえ!✽/よに'🅾️-え0█:]]
waypoints_racing_map1=15
starts_racing_map1=split('3763,3954,3760,3951,3959,3768,3962,3771')
racing_map2=[[ム^◝も⧗ホフ^"ヘも!メモも@んク^*オウ^"エs!ケコy+クっっえ0お+え5や^ っっクえ/クお)ケコえ4う#やえ1お)え9う え3お(え8う!え4お'え6クう#え4ひ&メモホフ^"ヘk#😐'っそ#え.ヤサササひ1●-う!☉ ヤお-ユシシシクををお_☉ ユへ1ををククえ^き ふ1う!ククわわ○5え<う+えkう,えlう+え5ヤサササめ6う(え5ユシシシえ7む め!え8ムめ:む め!えs▥$えセサササヤえvシシシユも+ヨ^"ヤヤほ `%ヤヤr!え2め/え#ヨヨス^'ぬ#えaお%ええゃ^"⧗*d'え!ゆ^ やややえ^メえ/い!う!お#モえ/ク^#え&ラリけ(い"え#ろろえ$メけ+キ^#ムクるるクケスススセソb りりえ-ろろけ スコクククケb!`#れれクオウ^#エえ'ややりりスえ,う"えbりりややえ)う%え(け#え1ススう!え)う&え#`"え8う"え$スえ"う%え_りりスえ,ろろひ!a"え8ム^ メヨヨう ⬅️"え#c-モ⬇️!♥"g%マカ^"マヘえ$い#え>e'ク^"ふ#★!え:ヨえ/ゅ^"え4😐/え<ユユシ^#ユユえaク^"m-n(く0メモa#も ょえ サササヤも&ゆ^#え1や^"も ケコa#▥ ょお シシシユえ^アお#やえ)お"クク😐'え9お#▥#え%お#え_やお%え*お"え'は$え2お#▥#え'お!え&ヤササふ ササヤえ2お$え,お え&ユシシふ シシユえ3やひ"メモa#_1は$z1え&b9えコへ6の(らや^#ま5イイお4む"ややらお$え4イイ✽"b&よl+▥ お$え3う)や`!え e"え'お$え2う)す#え p)え!お#え1う/え2お"え2☉*`"よe$へ+ららクえ1░-て よぬ&🅾️1qf]]
waypoints_racing_map2=15
starts_racing_map2=split('3764,3955,3761,3952,3960,3769,3963,3772')
racing_map3=[[ヨ^^ム^7えzお_え∧お@モえ❎お2…"メえiゆんんス^$コゆ^ ケj%ク^$やっっや^ お5スお!∧ え5う$え7お!う"え3う$え.お%∧ お%え1う%クえ6▤ ゆんち"モも!メふ$j"ムムう$え0お$スお ゆゆち$d(え$クえ>う!スえ6ムい#クえ0お"ルタ^ ゆゆえ7▤ `"え4レチ^ スススえ>お1き!ススゆゆゆスをを…&メえ*う&お w は#や^!わえ$い う ス^ コせ ゆゆケh!j ❎(け$w s あ"う え%❎ う#えgわわクえ&う!ゆゆえaう%やえ&う い!えfう え&う スお#えcう!え#ムヨう"…$えcけ!え$^(モに"メj)ムこ&w#s$え'お*ち/ムムゃ^$l$え.c=え%お)ろえdク^'え(お!え2クれれ◆(h1❎ ややお!え3お>え"お!え4お=え#お え5お<え!❎1え'クれn-は!➡️7え.웃)えzお&も"メモえkゅ^$∧<え*お)え%お)フフヘメモな2ゆ^"るるな-の#メモホフ^!ウウエケコw#りりv!え+るるゆゆˇ(き'ケコオウ^#え%う!え-う!えaう"え,う7え)も"う#え+う"え4ククえ*う$え*う;え*う%え)う#お7え#フフヘ➡️ う%え)h.す&🐱#ホフ^!x2お<xhえ⬇️ょょえpクアアも#お%え4サ^ ヤみ2お,え4シ^ ユみ3お+え4ま4み"お*えmクアほ1え_ヤサ^ ほ3え_ユシ^ え=や^#⬇️2ほ6えgお4ヨヨモほ ららえ>イイみ/メヨヨススコ▤!お$え7イイさ#ち"よi$ケス^ え"お$え6う&や`!え e"え(お#え5う&こ#え て"え)お"え4う,え3お クえ3う(や`"よe$え#み&お え1う(し$よと$え ヨヨモ➡️1q`メヨヨ]]
waypoints_racing_map3=15
starts_racing_map3=split('3763,3954,3760,3951,3959,3768,3962,3771')



tiles_w=64
tiles_h=64

function tiles_init(compressed_map,waypoints_count,start_indexes)
	tiles_type={}
	tiles_height={}
	tiles_waypoints={}
	
	waypoints={}
	for i=1,waypoints_count do
		add(waypoints,{})
	end

	dec={}
	local i=1
	while i<=#compressed_map do
		local c=ord(compressed_map,i)
		if c>=189 then
			add(dec,c)
			i+=1
		else
			local ofs=c-93
			c=ord(compressed_map,i+1)
			local l=c-32+3
			if l>=65 then
				l-=29
			end
			
			local start=#dec-ofs;
			for j=1,l do
				add(dec,dec[start+j])
			end
			i+=2
		end
	end
	
	local tile,height
	for i=1,#dec do
		local v,waypoint=dec[i],-1
		if v==189 then 
			tile=11
		elseif v==190 then
			tile=12
		elseif v<=205 then
			tile=11
			local tx,tz=tile_index_to_position(#tiles_type-1)
			waypoint=v-191
			add(waypoints[waypoint+1],tx)
			add(waypoints[waypoint+1],tz)
		elseif v<=230 then
			tile = (v-206)%5 + 1
			height = (v-206)\5*8
		else
			tile = (v-231)%5 + 1 + 5
			height = (v-231)\5*8
		end
		
		add(tiles_waypoints,waypoint)
		add(tiles_type,tile)
		add(tiles_height,height)
	end

	build_collision_solutions()
		
	tile_height_func={
		tile_flat,
		tile_ascend_px,
		tile_ascend_mx,
		tile_ascend_pz,
		tile_ascend_mz,
		tile_flat,
		tile_ascend_px,
		tile_ascend_mx,
		tile_ascend_pz,
		tile_ascend_mz,
		tile_flat,
		tile_flat_rough,
	}
	
	start_positions={}
	for i=1,#start_indexes do
		local x,z=tile_index_to_position(start_indexes[i])
		add(start_positions,x)
		add(start_positions,z)
	end
end

function build_collision_solutions()
	tile_cs={}
	for z=0,tiles_h-1 do
		for x=0,tiles_w-1 do
			local sx,sz=collision_solution(x,z,"11111111112202121120001011210111")
			add(tile_cs,sx)
			add(tile_cs,sz)
		end
	end
	
	local filtered_solution={}
	for z=0,tiles_h-1 do
		for x=0,tiles_w-1 do
			local sx,sz=collision_solution_filter(x,z)
			add(filtered_solution,sx)
			add(filtered_solution,sz)
		end
	end
	
	tile_cs=filtered_solution
end

function collision_solution(x,z,cmbn)
	local t=tiles_type[x+z*tiles_w+1]
	if not tile_is_obstacle(t) then
		return 0,0
	end
	
	local mx=tile_is_obstacle_number(get_tile_type(x-1,z))
	local px=tile_is_obstacle_number(get_tile_type(x+1,z))
	local mz=tile_is_obstacle_number(get_tile_type(x,z-1))
	local pz=tile_is_obstacle_number(get_tile_type(x,z+1))
	
	local index=1+mx+px*2+mz*4+pz*8
	return ord(cmbn,(index-1)*2+1)-49,ord(cmbn,(index-1)*2+2)-49
end

function collision_solution_filter(x,z)
	local t=tiles_type[x+z*tiles_w+1]
	if not tile_is_obstacle(t) then
		return 0,0
	end
	
	local sx,sz=get_collision_solution(x,z)
	if sx~=0 or sz~=0 then
		return sx,sz
	end
	
	local dx,dz
	dx,dz=get_collision_solution(x-1,z)
	sx+=dx sz+=dz
	dx,dz=get_collision_solution(x+1,z)
	sx+=dx sz+=dz
	dx,dz=get_collision_solution(x,z-1)
	sx+=dx sz+=dz
	dx,dz=get_collision_solution(x,z+1)
	sx+=dx sz+=dz
	
	if sx==0 and sz==0 then
		return 0,0
	end
	
	return normalize2d(sx,sz)
end

function get_tile_type(tx,tz)
	return tiles_type[tilec_rot(tx,tiles_w)+tilec_rot(tz,tiles_h)*tiles_w+1]
end

function get_collision_solution(tx,tz)
	local index=(tilec_rot(tx,tiles_w)+tilec_rot(tz,tiles_h)*tiles_w)*2+1
	return tile_cs[index],tile_cs[index+1]
end

function sample_collision_solution(x,z)
	local index=(tilec_rot(flr(x/8),tiles_w)+flr(z/8)*tiles_w)*2+1
	local sx,sz=tile_cs[index],tile_cs[index+1]
	if sx==nil or sz==nil then
		return 0,0
	end
	return sx,sz
end

function sample_tile_map(x,z)
	local tx=tilec_rot(flr(x/8),tiles_w)
	local tz=clamp(flr(z/8),0,tiles_h-1)
	local index=tx+tz*tiles_w+1
	return tiles_type[index],tile_height_func[tiles_type[index]](x%8,z%8)+tiles_height[index],tiles_waypoints[index]
end

function tilec_rot(x,w)
	if x<0  then x+=w end
	if x>=w then x-=w end
	return x
end

function tile_flat(x,z)
	return 0
end
function tile_flat_rough(x,z)
	return ((x>>1)^(z>>1))&1
end
function tile_ascend_px(x,z)
	return x
end
function tile_ascend_mx(x,z)
	return 7-x
end
function tile_ascend_pz(x,z)
	return z
end
function tile_ascend_mz(x,z)
	return 7-z
end

function tile_is_obstacle(t)
	return t>=6 and t<=10
end

function tile_is_obstacle_number(t)
	if tile_is_obstacle(t) then return 1 else return 0 end
end

function tile_is_dirt(t)
	return t==11
end

function height_is_water(y)
	return y<2
end

function tile_index_to_position(index)
	local x=index%tiles_w
	local z=index\tiles_w
	if x>=z\2 then
		x-=tiles_w
	end
	return x*8+4,z*8+4
end








sprite_map_w=64
sprite_map_h=32
sprite_map_x=0
sprite_map_y=0
second_sprite_map_x=64
second_sprite_map_y=0

function sprite_map_init(tx,ty)
	sprite_map_x=tx
	sprite_map_y=ty
	for y=0,sprite_map_h-1 do
		for x=0,sprite_map_w-1 do
			local sprite=mget(tx+x,ty+y)
			if sprite>=64 and fget(sprite,1) then
				mset(tx+x,ty+y,sprite-64)
				mset(second_sprite_map_x+x,second_sprite_map_y+y,sprite)
			else
				mset(second_sprite_map_x+x,second_sprite_map_y+y,0)
			end
		end
	end
end

function sprite_map_draw(ofs_x,ofs_y)
	map(sprite_map_x,sprite_map_y,ofs_x,ofs_y,64,32)
end

function second_sprite_map_draw(ofs_x,ofs_y)
	map(second_sprite_map_x,second_sprite_map_y,ofs_x,ofs_y,64,32)
end




function shadows_init(shading)
	local shadow_color=split(shading)
	for i=0,255 do
		poke(0x4300|i,shadow_color[(i&0xf)+1]|(shadow_color[((i>>4)&0xf)+1]<<4))
	end
end

function draw_shade(x1,y1,x2,y2,x3,y3,x4,y4)
	y1=flr(y1)
	y2=flr(y2)
	y3=flr(y3)
	y4=flr(y4)
	
	shade_edge(x1,y1,x2,y2)
	shade_edge(x2,y2,x3,y3)
	shade_edge(x3,y3,x4,y4)
	shade_edge(x4,y4,x1,y1)
	
	local min_y=clamp(min(y1,min(y2,min(y3,y4))),0,127)
	local max_y=clamp(max(y1,max(y2,max(y3,y4))),0,127)
	
	for y=min_y,max_y do
		local xl=peek(0x4400+y)\2
		local xr=peek(0x4480+y)\2
		local scanline=0x6000+y*64
		for x=xl,xr do
			poke(scanline+x,peek(0x4300|peek(scanline+x)))
		end
	end
end

function shade_edge(x1,y1,x2,y2)
	if y1<y2 then
		local dx=(x2-x1)/(y2-y1)
		while y1<=y2 do
			if y1>=0 and y1<=127 then
				poke(0x4400|y1,clamp(x1,0,127))
			end
			x1+=dx
			y1+=1
		end
	elseif y1>y2 then
		local dx=(x1-x2)/(y1-y2)
		while y2<=y1 do
			if y2>=0 and y2<=127 then
				poke(0x4480|y2,clamp(x2,0,127))
			end
			x2+=dx
			y2+=1
		end
	elseif y1>=0 and y1<=127 then
		x1=clamp(x1,0,127)
		x2=clamp(x2,0,127)
		if x1<x2 then
			poke(0x4400|y1,x1)
			poke(0x4480|y1,x2)
		else
			poke(0x4400|y1,x2)
			poke(0x4480|y1,x1)
		end
	end
end


car_min,car_vscale=-2.1209,0.0215
car_verticesc=[[^}○^●xe☉xp◆○g◆xe∧x^く○^▥x:∧x/◆○7◆x:☉xk🐱x^}xp◆xkうx^くx4うx/◆x4🐱xンqへ◝…も(vも$●ほンq웃◝…⬇️(v⬇️$✽☉w★⬇️znふzn웃w★もやq⬇️や★もや★⬇️やqもや?ひ⌂_ぬ⌂_🅾️や?⌂◝q⬇️◝qもる}웃ン}웃ン}へる}へ ✽🅾️ x🅾️ xね ✽ねwq⬇️wqも♪?⌂♪?ひ(★⬇️(★も ✽➡️ |➡️ |と ✽と ★🅾️ ★ね^}ら^●んp◆らe☉んg◆ん^くらe∧ん^▥ん/◆ら:∧ん7◆ん:☉んk🐱ん^}んp◆んkうん^くん4うん/◆ん4🐱んコ}らコ●んフ◆らチ☉んト◆んコくらチ∧んコ▥んれ◆らウ∧んア◆んウ☉んヌ🐱んコ}んフ◆んヌうんコくんっうんれ◆んっ🐱んコ}○コ●xチ☉xフ◆○ト◆xチ∧xコく○コ▥xウ∧xれ◆○ア◆xウ☉xヌ🐱xコ}xフ◆xヌうxコくxっうxれ◆xっ🐱xゆeへゆ^へゆe☉ゆ^☉りiにわdにりi◆わd◆チv☉シ{◆チvにチvへシ{にチv◆テ★もテ★⬇️^★⬇️^★もスrへスrにエsへエrにシq◆シq☉ウr☉イq◆]]
car_trianglesc=[[o6p+dra+8fe+4`f+:m6+>p=+bqc+=rb+>qo+a`@+a@d+@8e+o:6+dqr+84f+:lm+>op+brq+=pr+>cq+ ,- #,  #/. &/# &10 )1& )32  3) !," ,$" $/% /'% '1( 1*( *3+ 3!+ =c> `rp @qd hji wux {♥} }♥웃 }⌂█ █⌂⬅️ █😐⬇️ ⬇️😐♪ ⬇️🅾️{ {🅾️☉ ~☉| ○♥~ ○⌂웃 🐱⌂▒ 🐱😐⬅️ ✽😐░ ✽🅾️♪ |🅾️● ◆い➡️ ➡️いえ ➡️お⬆️ ⬆️おか ⬆️き❎ ❎きく ❎け◆ ◆けう ★う… ⧗い★ ⧗おえ ∧おˇ ∧きか ▥き▤ あく▥ …けあ こにぬ すにこ すのね たのす たひは てひた てへふ こへて さにし にせし せのそ のちそ ちひつ つふと ふなと へさな #., &0/ )21  -3 !-, ,.$ $./ /0' '01 12* *23 3-! =bc `ar @oq hgj wvu {☉♥ }웃⌂ █⬅️😐 ⬇️♪🅾️ ~♥☉ ○웃♥ ○▒⌂ 🐱⬅️⌂ 🐱░😐 ✽♪😐 ✽●🅾️ |☉🅾️ ◆うい ➡️えお ⬆️かき ❎くけ ★いう ⧗えい ⧗ˇお ∧かお ∧▤き ▥くき あけく …うけ すねに たはの てふひ こぬへ さぬに にねせ せねの のはち ちはひ つひふ ふへな へぬさ 7mn';l:'ゆウむ'ゆまも'もゃゅ'ゅるり'ウろよ'76m';kl'ゆイウ'ゆむま'もまゃ'ゅゃる'ウイろ'をe9#っ6t#e59#^p?#んo<#`g@#わ`^#o_<#8i4#8gh#;:s#67t#7zt#;yk#vlk#xzn#wlv#uzx#4j`#5fわ#@を_#s:ん#?pっ#6っp#ん:o#ef5#^`p#`jg#わf`#o@_#8hi#8@g#7nz#;sy#yuk#uvk#mwn#wxn#wml#uyz#4ij#@eを#$'*&🐱▒○&∧ˇ⧗&せちと&ゆめや&もアめ&むエみ&ゆオイ&まょゃ&ゅれア&イらろ&!"$&$%'&'(*&*+!&!$*&○~|&|●○&●✽○&✽░○&░🐱○&⧗★▥&★…▥&…あ▥&▥▤⧗&▤∧⧗&さしせ&せそち&ちつと&となさ&させと&ゆもめ&もゅア&むウエ&ゆやオ&まほょ&ゅりれ&イオら&]]

function car_mesh_init()
	car_vertices={}
	for i=1,#car_verticesc,3 do
		add(car_vertices,{x=car_min+car_vscale*decode_v(car_verticesc,i),y=car_min+car_vscale*decode_v(car_verticesc,i+1),z=car_min+car_vscale*decode_v(car_verticesc,i+2)})
	end
	
	car_triangles={}
	for i=1,#car_trianglesc do
		add(car_triangles,decode_v(car_trianglesc,i)+1)
	end
end

function decode_v(arr,i)
	local v=ord(arr,i)-32
	if v>=62 then
		v-=29
	end
	return v
end


presorted_count=16

function car_rendering_init()
	transformed_vertices={}
	projected_vertices={}
	sorted_triangles={}

	for i=0,presorted_count-1 do
		local yaw=(i+0.5)*pi2/presorted_count
		car_transform(car_vertices, transformed_vertices, yaw,0,0,1)

		local triangles=cull_triangles(transformed_vertices,car_triangles,-0.5,0.5,1)
		sort_triangles(transformed_vertices,triangles)
		add(sorted_triangles,triangles)
	end
end

function car_draw(pos_x,pos_y,yaw,pitch,roll,scale)
	car_transform(car_vertices, transformed_vertices, yaw,pitch,roll,scale)
	project_vertices(transformed_vertices,projected_vertices,pos_x,pos_y)

	local yaw_index=flr((yaw+0.3*abs(pitch)+abs(roll)*0.2)/pi2*presorted_count)%presorted_count+1
	draw_triangles(projected_vertices,sorted_triangles[yaw_index])
end

function transformation(vec,yaw_sin,yaw_cos,pitch_sin,pitch_cos,roll_sin,roll_cos,scale)
	local x,y,z=vec.x,vec.y,vec.z
	if roll_sin ~= 0 then
		z,y=rotatesincos(z,y,roll_sin,roll_cos)
	end
	if pitch_sin ~= 0 then
		x,y=rotatesincos(x,y,pitch_sin,pitch_cos)
	end
	x,z=rotatesincos(x,z,yaw_sin,yaw_cos)
	return {x=x*scale,y=y*scale,z=z*scale}
end

function car_transform(vertices_in, vertices_out, yaw, pitch, roll, scale)
	local yaw_sin=sin(yaw)
	local yaw_cos=cos(yaw)
	local pitch_sin=sin(pitch)
	local pitch_cos=cos(pitch)
	local roll_sin=sin(roll)
	local roll_cos=cos(roll)

	for i=1,#vertices_in do
		vertices_out[i]=transformation(vertices_in[i],yaw_sin,yaw_cos,pitch_sin,pitch_cos,roll_sin,roll_cos,scale)
	end
end



car_max_speed_forward=4
car_nitro_speed_increase=2
car_max_speed_reverse=-1
car_turn_speed=0.1
car_inertia=0.95
car_gravity=-0.2
car_half_width=4
car_half_length=8
car_terrain_slip=0.85
car_dirt_slip=0.96
car_scale=5
car_colors_default={
	{8,2, "red hurricane"},
	{11,3,"green devil"},
	{12,1,"blue lightning"},
	{10,9,"yellow thunder"},
	{6,13,"silver blaze"}
}

default_throttle=1
difficulty_levels={
	{n="easy",t=0.8},
	{n="medium",t=0.9},
	{n="hard",t=1},
	{n="extreme",t=1.1},
}

player_color=1
waypoint_order=1
cars_count=4
laps_count=4
start_time=0
difficulty=1

function cars_init()
	particles={}
	frame=0

	local start_ofs=1
	if waypoint_order<0 then
		start_ofs=9
	end

	car_sorting=split("1,2,3,4")

	car_colors={}
	add(car_colors,car_colors_default[player_color])
	for i=2,4 do
		if i==player_color then
			add(car_colors,car_colors_default[1])
		else
			add(car_colors,car_colors_default[i])
		end
	end

	cars={}
	for i=1,cars_count do
		local cx=start_positions[start_ofs+  (i-1)*2]
		local cz=start_positions[start_ofs+1+(i-1)*2]
		local t,cy=sample_tile_map(cx,cz)
		add(cars,{x=cx,y=cy,z=cz,yaw=hpi+hpi*waypoint_order,speed=0,speed_y=0,throttle=0,nitro=0,breaking=0,in_air=false,slip=0,slip_x=0,slip_z=0,colour=i,last_waypoint=0,next_waypoint=0,next_x=0,next_z=0,nitro_remains=100,nitro_max=100,lap=-1,is_ai=i>1})
		car_simulate(cars[#cars])
	end
	
	start_time=time()+3.5
end

function cars_update()
	if time()<start_time then return end

	frame+=1
	particles_update()

	car_player(cars[1])
	car_simulate(cars[1])
	
	for i=2,cars_count do
		car_ai(cars[i])
		car_simulate(cars[i])
	end
end

function car_input(car,left,right,throttle,rev,nitro)
	if car.in_air then
		car.throttle=0
		return
	end

	if left then
		car.yaw+=car_turn_speed
		if car.yaw>=pi2 then
			car.yaw-=pi2
		end
	end
	
	if right then
		car.yaw-=car_turn_speed
		if car.yaw<0 then
			car.yaw+=pi2
		end
	end

	if nitro and car.nitro_remains>0 then
		car.nitro=car_nitro_speed_increase
		car.nitro_remains-=1
	else
		car.nitro=0
	end
	
	if throttle then
		car.throttle=default_throttle
	elseif rev then
		car.throttle=-default_throttle
	else
		car.throttle=0
	end
end

function car_next_waypoint(car)
	if car.last_waypoint==car.next_waypoint then
		local nw=(car.next_waypoint + #waypoints + waypoint_order)%#waypoints
		local wps=waypoints[nw+1]
		local index=flr(rnd(#wps\2))*2+1
		car.next_waypoint=nw
		car.next_x=wps[index]
		car.next_z=wps[index+1]
	end
end

function car_player(car)
	car_input(cars[1],btn(0),btn(1),btn(2) or btn(5),btn(3),btn(4))
	car_update_lap(car,car.last_waypoint,car.next_waypoint)
	car_next_waypoint(car)
end

function car_ai(car)
	car_update_lap(car,car.last_waypoint,car.next_waypoint)
	car_next_waypoint(car)

	local dir_x=car.next_x-car.x
	local dir_z=car.next_z-car.z
	local dst_yaw = atan2(-dir_x,dir_z)
	car.dst_yaw=dst_yaw
	
	car.dst_distance=dir_x*dir_x+dir_z*dir_z

	local delta_yaw=dst_yaw-car.yaw
	if delta_yaw> pi then delta_yaw-=pi2 end
	if delta_yaw<-pi then delta_yaw+=pi2 end
	
	car_input(car,delta_yaw>0.1,delta_yaw<-0.1,abs(delta_yaw)<0.5,false,car.dst_distance>6400)

	local next_wps=waypoints[car.next_waypoint+1]
	local index=flr(rnd(#next_wps\2))*2+1
	local ndir_x=next_wps[index]-car.x
	local ndir_z=next_wps[index+1]-car.z
	
	if (ndir_x*ndir_x+ndir_z*ndir_z)<car.dst_distance then
		car.next_x=next_wps[index]
		car.next_z=next_wps[index+1]
	end
end

function car_update_lap(car,last_waypoint,next_waypoint)
	if next_waypoint==0 and last_waypoint==next_waypoint then
		car.lap+=1
		if car.lap>=laps_count then
			sfx(56)
			set_finish_time()
			set_state(3)
		end
	end
end

function set_finish_time()
	if cars[1].finish_time==nil then
		for i=1,cars_count do
			local car=cars[i]
			local ft=t()-start_time
			if car.lap>=laps_count then
				car.finish_time=ft
			else
				local dir_x=car.next_x-car.x
				local dir_z=car.next_z-car.z
				local t_dist=sqrt(dir_x*dir_x+dir_z*dir_z)*0.1
				car.finish_time=ft+t_dist+(laps_count-car.lap-1)*#waypoints*5
				while car.next_waypoint~=0 do
					car.next_waypoint=(car.next_waypoint + #waypoints + waypoint_order)%#waypoints
					car.finish_time+=5
				end
			end
		end
	end
end

function car_simulate(car)
	local was_air=car.in_air
	local prc=0
	local prs=146

	local inertia = car_inertia
	if car.in_air then inertia = 1 end
	local max_speed = car_max_speed_forward
	if car.is_ai then max_speed *= difficulty_levels[difficulty].t end
	car.speed = clamp(car.speed*inertia + car.throttle + car.nitro, car_max_speed_reverse, max_speed + car.nitro)

	local speed=car.speed
	if not car.in_air then
		speed*=(1-abs(car.pitch)*0.4)
		
		if height_is_water(car.y) then
			speed = min(speed,2)
			prs=150
			prc=2
		end
	end
	
	local dir_x=-cos(car.yaw)
	local dir_z= sin(car.yaw)
	local right_x=-dir_z
	local right_z= dir_x

	local move_x = lerp(dir_x,car.slip_x,car.slip)
	local move_z = lerp(dir_z,car.slip_z,car.slip)
	move_x,move_z = normalize2d(move_x,move_z)

	car.slip_x = move_x
	car.slip_z = move_z

	local new_x = car.x + move_x * speed
	local new_z = car.z + move_z * speed

	local fwd_x=dir_x*car_half_length
	local fwd_z=dir_z*car_half_length

	local f_x=new_x+fwd_x
	local f_z=new_z+fwd_z
	local b_x=new_x-fwd_x
	local b_z=new_z-fwd_z

	if speed>=0 then
		local f_t,f_h=sample_tile_map(f_x,f_z)
		if tile_is_obstacle(f_t) then
			local sol_x,sol_z=sample_collision_solution(f_x,f_z)
						
			if sol_x~=0 or sol_z~=0 then
				local tf_x=flr(f_x/8)
				local tf_z=flr(f_z/8)
				while tf_x==flr(f_x/8) and tf_z==flr(f_z/8) do
					f_x+=sol_x
					f_z+=sol_z
				end
			else
				car.screen_x,car.screen_y=isometry(car.x,car.y,car.z)
				car.in_air=false
				return
			end
			
			dir_x,dir_z=normalize2d(f_x-b_x,f_z-b_z)
			
			right_x=-dir_z
			right_z= dir_x
			
			fwd_x=dir_x*car_half_length
			fwd_z=dir_z*car_half_length
			
			car.yaw = atan2(-dir_x,dir_z)
			
			new_x = f_x-fwd_x
			new_z = f_z-fwd_z

			b_x=new_x-fwd_x
			b_z=new_z-fwd_z
			
			if not car.in_air then
				car.speed  = min(car.speed,1.8)
				car.speed_y = max(car.speed_y,0)
			end
		end
	else
		local b_t,b_h=sample_tile_map(b_x,b_z)
		if tile_is_obstacle(b_t) then
			return
		end
	end

	car.x=new_x
	car.z=new_z

	right_x*=car_half_width
	right_z*=car_half_width

	local fr_x=f_x+right_x
	local fr_z=f_z+right_z
	local fl_x=f_x-right_x
	local fl_z=f_z-right_z
	local br_x=b_x+right_x
	local br_z=b_z+right_z
	local bl_x=b_x-right_x
	local bl_z=b_z-right_z

	local fr_t,fr_y,fr_w = sample_tile_map(fr_x,fr_z)
	local fl_t,fl_y,fl_w = sample_tile_map(fl_x,fl_z)
	local br_t,br_y,br_w = sample_tile_map(br_x,br_z)
	local bl_t,bl_y,bl_w = sample_tile_map(bl_x,bl_z)
	
	local f_y = (fr_y+fl_y)*0.5
	local b_y = (br_y+bl_y)*0.5
	local r_y = (fr_y+br_y)*0.5
	local l_y = (fl_y+bl_y)*0.5

	car.sfr_x,car.sfr_y=isometry(fr_x,fr_y,fr_z)
	car.sfl_x,car.sfl_y=isometry(fl_x,fl_y,fl_z)
	car.sbr_x,car.sbr_y=isometry(br_x,br_y,br_z)
	car.sbl_x,car.sbl_y=isometry(bl_x,bl_y,bl_z)

	car.speed_y = clamp(car.speed_y+car_gravity,-4,4)
	local phys_y=car.y+car.speed_y
	local new_tile_type = fr_t
	local new_y = (f_y+b_y)*0.5
	
	if phys_y>new_y then
		car.in_air=true
		car.y=phys_y
		car.roll*=0.95
		car.pitch=max(car.pitch-0.03,-0.4)
		car.slip=0
	else
		if tile_is_dirt(new_tile_type) then
			car.slip=car_dirt_slip
		else
			car.slip=car_terrain_slip
		end
		
		car.in_air=false
		car.speed_y=new_y-car.y
		car.y=new_y
		car.tile_type=new_tile_type
	
		car.pitch=clamp((f_y-b_y)/car_half_length*0.5,-0.5,0.5)
		car.roll=clamp((l_y-r_y)/car_half_width*0.5,-0.5,0.5)
	end

	car.screen_x,car.screen_y=isometry(car.x,car.y,car.z)

	if was_air and not car.in_air then
		prc+=4
	end
	
	if not car.in_air and abs(car.speed)>0.8 and (car.slip>0.9 or car.speed>car_max_speed_forward) then
		prc+=1
	end
	
	for i=1,prc do
		add(particles,{s=prs,x=flr(car.screen_x-11+rnd(10)),y=flr(car.screen_y-11+rnd(10))})
	end
	
	if fr_w~=-1 then car.last_waypoint=fr_w end
	if fl_w~=-1 then car.last_waypoint=fl_w end
	if br_w~=-1 then car.last_waypoint=br_w end
	if bl_w~=-1 then car.last_waypoint=bl_w end
end

function particles_update()
	if frame%4==0 then
		for i=1,#particles do
			local p=particles[i]
			if p==nil then break end
			if p.s==149 or p.s==153 then
				deli(particles,i)
			else
				p.s+=1
			end
		end
	end
end

function cars_draw(ofs_x,ofs_y)
	for i=1,cars_count do
		local car=cars[i]
		local x=car.screen_x-ofs_x
		local y=car.screen_y-ofs_y
		if x>-8 and x<136 and y>-8 and y<136 then
			draw_shade(
				car.sfr_x-ofs_x,car.sfr_y-ofs_y,
				car.sfl_x-ofs_x,car.sfl_y-ofs_y,
				car.sbl_x-ofs_x,car.sbl_y-ofs_y,
				car.sbr_x-ofs_x,car.sbr_y-ofs_y
			)
		end
	end

	palt()
	for i=1,#particles do
		local p=particles[i]
		spr(p.s,p.x-ofs_x,p.y-ofs_y)
	end

	for i=1,cars_count-1 do
		if cars[car_sorting[i]].screen_y > cars[car_sorting[i+1]].screen_y then
			car_sorting[i],car_sorting[i+1]=car_sorting[i+1],car_sorting[i]
		end
	end

	for i=1,cars_count do
		local car=cars[car_sorting[i]]
		local colors=car_colors[car.colour]
		pal(11,colors[1])
		pal(3,colors[2])
		
		local x=car.screen_x-ofs_x
		local y=car.screen_y-ofs_y
		if x>-8 and x<136 and y>-8 and y<136 then
			car_draw(x,y,car.yaw,car.pitch,car.roll,car_scale)
		end
	end
	
	pal(11,11)
	pal(3,3)
end




map_ofs_x=0
map_ofs_y=0

track=1

car_controls=1

tracks={
	{u=0x2000,d=0x2800,rm=racing_map1,wp=waypoints_racing_map1,st=starts_racing_map1},
	{u=0x1800,d=0x1840,rm=racing_map2,wp=waypoints_racing_map2,st=starts_racing_map2},
	{u=0x2040,d=0x2840,rm=racing_map3,wp=waypoints_racing_map3,st=starts_racing_map3}
}

function game_init()
 --music(-1)
 local t=tracks[track]
 pal(5,132,1)
 pal(15,143,1)
 
 for i=0,1920,128 do
	reload(0x2000+i,t.u+i,64)
	reload(0x2800+i,t.d+i,64)
 end
 
 shadows_init("0,0,2,3,5,1,6,7,8,4,4,11,1,13,14,4")
 tiles_init(t.rm,t.wp,t.st)
 sprite_map_init(0,0)
 car_rendering_init()
 cars_init()
end

function game_update()
 cars_update()

 if car_controls==1 then
  local new_ofs_x=cars[1].screen_x-64
  local new_ofs_y=cars[1].screen_y-64
  map_ofs_x=max(0,min(384,new_ofs_x))
  map_ofs_y=max(0,min(128,new_ofs_y))
 else
  debug_screen_controls()
 end
end

function game_draw()
 palt(0,false)
 sprite_map_draw(-map_ofs_x,-map_ofs_y)
 cars_draw(map_ofs_x,map_ofs_y)
 palt(0,true)
 second_sprite_map_draw(-map_ofs_x,-map_ofs_y)

 if btn(❎) and car_controls==0 then
 	tiles_draw(map_ofs_x,map_ofs_y,not btn(🅾️))
 end

	game_ui_draw()
end



prevcountdown=-1
function game_ui_draw()
	local t=time()-start_time

	if t>=0 then
		printo(time_str(t),64-12,2,7)

		for j=0,cars_count-1 do
			local ls=lap_to_str(cars[j+1].lap)
			if j==0 then
				ls=ls.."/"..laps_count
			end
			printo(ls,2,2+j*6,car_colors[cars[j+1].colour][1])
		end
		
		for j=0,cars_count-1 do
			draw_progress(128-32,2+j*3,126,cars[j+1].nitro_remains/cars[j+1].nitro_max,car_colors[cars[j+1].colour][1],car_colors[cars[j+1].colour][2])
		end
	end

	if t<1 then
		t=-t+1
		set_transparent_pattern(t-flr(t))
		local sx=3
		if time()>=start_time then
			sx=9
		end
		local countdown=3-flr(t)
		draw_sprite4(countdown*3,64-6,sx,6, 64-(sx*4)/2,64-24/2)
		fillp()
		
		if countdown>prevcountdown then
			if countdown==3 then
				sfx(55)
			else
				sfx(54)
			end
		end
		prevcountdown=countdown
	end
end




title_image=[[ ね うこ'''ねね=ね6ひ◝セ1ら&ねふゃ'3わ5れ2)109(◝る3ふ5の&1み2#3(6オ◝や5ひま6.5シ5,◝も=*◝◝◝れ&は2#3(の&◝っ1わ2"6)72ためたあ3ョ2$e2@_7q:svて9め(6 7や>2@_8q9srめ<✽'り>2^_ン5ゃ5り3カ722"^/bs█め7-るbmes6 7しb0も∧め3ョ?❎`08いヲ''オ:^=ナ🅾️め4ャ5り6や2 h^^✽6○2y9ラ6/や?あ@ホi^@め3ュ6$6ケ8/:ラ5`2ネ🐱めレ`░1へ4 イ')2 1リ5'824z^/9s?q@░4$2め@すふ*ほ4'へ136す@/9`2x*ほ=░1ュ3░4#ほ*ほ2'6▤aリ;め;/`sc02りb^へ*1ル1◜6'ふ23も</:`7h?░m^4そ1め4リ3'42=め</:`7h?░2ヨ4ˇ4'2ツ1そ3ツ3'ま3ュ'7ヌ8ノみ=/:`7h?░5🐱'e^:や5り░めd░4あ=^9め1つ*1◜2#5エ101/;@;/:`9hb░4▤7イ=そ3レ6 ;0:た=/:`9ua░:❎?0は]]
car_image=[[ ね ねこ◝◝◝◝◝◝◝モ+r さみ#d!4"6?'かむ##!b 1め++9<+いやgみ'ふ<シ1や∧ゆgむ2め1つ>セ+%%⬆️や1めdむ3め#る∧やhむ2めは@チ+★や+hめ3サ#+れ!は🅾️やiめ1 2す_めふ%'⌂ゆ+#fめ2ゆ1セ#ん3や%♥や++iむ3め1し`トの ⌂やqめ#ん!の웃や+#oめ!cめ181ふ░や+lめ3セ#+ウ~や1🅾️a"#^!36v ▒へ_ん'+''4ほ_ケc3fやiて:█1の''6をd `:ゃ4け;◝5"7✽4+3む7ケ{ っ'%u ''へ7コラ!y %へ█ を%''!%eラ%!%%+'5 ふxみ:ミん$$は!a ふ+1_4!ひ>★み2>$4ね<め6ゆん''ゅ!ふ&'4 1ヌ%9➡️^ゆ=オ1ノ3▒ゅ1🅾️1ルウ2ˇ2!!は:めり>ア5め6やわ%''!%ろ%3#ひ%+'3 #の1っ2め3◆mや6め1やゅ$$4め2て@るひ#$5 2+4む5★bや5ケ>fを''1お?ま2ゅ2ウひ+'5 1ニ:め1ソを6れ9gゅ$$ひ6て6ひ7レは$5 2ク;めのhや>ヒを''ひ:む:!#16'5 1b+ゆ3⧗^ふ4め2ヲ!%%2ˇ3ヒを$1ほd◝#2サ:て2め$1 3➡️よ1セ;"3み%$4や1ハわx 2め%3め5ゆ3に2ふ4#<!!1や1む1!1r1んれ1ツ#!g!3ヲ7む1◆1ま1⧗%2るま7$<り+3d1◝ア9い`*3ャ2な3,2!5ウ35の8つ3ふ#7#の5j&2tは&&を#h!6ツひ:め2シ$%!=め:れ+3ホま!''^めのkやほ:め'1☉1➡️1オ1ゃ7つ? 4リ&!$4ッ_むひ1○g ま%2⬇️2に1みの2り1う$$!2め6#の+9 4リ%1a$のaむ2や4う#%2そ4な6$121ソ1テ2ニ6れ1lの$4め2ゅ;に+2ら5g6リ2むょ 7g5#5%1ケ819😐%&!!1◆$2れ2ア3ヤ;ぬや1ル1やケ1ヘ3う:や5#:め1ひ'の$1%6/h!%&2iコ9ヤ7る7,9<2ゆ'1…6ユり9⧗%!%1め$%タ4き_⬆️2ケ%&1ま$1"$''ひ5ろ5ね@⧗%&&$&&!チf0は1ソ1や!2み3ア^ほ;や&!$2リム9ネひ'!%$'4や3めウ%の1やbナeやbネ%$&1ふ$$2や&%3ょc❎ま$&$%%fめわcヌ3と!'1む5,ゅ7や2 ラ6や$%1ま1む'3⬆️ag<⬆️2cトeネの$$&!&1➡️$へp⬆️gめ_やfノ1ふ$$2るひiˇrめ@やhネ2や2"2めl∧r?oめ8ネ1ほ▥め<ゆoノ3む∧めあノね:◝◝◝◝◝◝◝◝ヨ]]

title_items={
	{l=function() player_color=player_color%#car_colors_default+1 end,r=function() player_color=(player_color+#car_colors_default-2)%#car_colors_default+1 end,un=function() pal(11,car_colors_default[player_color][1],1) pal(3,car_colors_default[player_color][2],1) return "car color" end},
	{l=function() difficulty=(difficulty+#difficulty_levels-2)%#difficulty_levels+1 end,r=function() difficulty=difficulty%#difficulty_levels+1 end,un=function() return difficulty_levels[difficulty].n end},
	{n="tournament",e=function() tour=split("0,0,0,0") track=1 waypoint_order=1 laps_count=4 cars_count=4 set_state(2) end},
	{n="single race",e=function() tour=nil menu_tracks() end}
}
title_sel=1

track_items={
	{n="track 1",e=function() track=1 menu_setup() end},
	{n="track 2",e=function() track=2 menu_setup() end},
	{n="track 3",e=function() track=3 menu_setup() end}
}
track_sel=1

setup_items={
	{l=function() laps_count=max(laps_count-1,1) end,r=function() laps_count=min(laps_count+1,20) end,un=function() return "laps "..laps_count end},
	{l=function() waypoint_order*=-1 end,r=function() waypoint_order*=-1 end,un=function() if waypoint_order==1 then return "reverse off" else return "reverse on" end end},
	{l=function() cars_count=max(cars_count-1,1) end,r=function() cars_count=min(cars_count+1,4) end,un=function() return "opponents "..(cars_count-1) end},
	{n="start!",e=function() set_state(2) end}
}
setup_sel=1

menu=nil
menu_get_sel=nil
menu_set_sel=nil
menu_enter=nil
menu_back=nil

function title_init()
	pal(split("0,8,2,13,5,6,7,9,132,4,8,129,1,140,12"),1)
	
	car_rendering_init()
	shadows_init("0,0,2,3,5,1,6,7,8,4,4,11,0,12,13,14")
	
	lz77_decomp(0,0,128,32,title_image,sset)
	lz77_decomp(0,32,128,64,car_image,sset)
	
	for y=0,4+8 do
		for x=0,15 do
			poke(0x2000 + x+y*128,x+y*16)
		end
	end
	
	menu_title()
	music(0)
end

function title_update()
	menu_update()
end

function title_draw()
	local center_x,center_y=64,45
	for i=0,127 do
		local f=(((i>>4)+time()*2)*4) & 7
		local c
		if f>3 then
			c=15-(f&3)
		else
			c=12+(f&3)
		end
		
		line(center_x,center_y,i,127,c)
		line(center_x,center_y,127-i,0,c)
		line(center_x,center_y,0,i,c)
		line(center_x,center_y,127,127-i,c)
	end
	
	map(0,0,0,4-4*abs(sin(time()*5)),16,4)
	map(0,4,0,32,16,8)
	
	if time()>2.5 then
		menu_draw(title_items,title_sel)
	else
		printo("by assembler bot (2021)",18,120,7)
	end
end


function menu_title()
	menu_init(title_items,function() return title_sel end, function(val) title_sel=val end, function() end)
end

function menu_tracks()
	menu_init(track_items,function() return track_sel end, function(val) track_sel=val end, function() menu_title() end)
end

function menu_setup()
	menu_init(setup_items,function() return setup_sel end, function(val) setup_sel=val end, function() menu_tracks() end)
end

function menu_init(items,get,set,back)
	menu=items
	menu_get_sel=get
	menu_set_sel=set
	menu_back=back
end

function menu_update()
	if btnp(0) then
		local left=menu[menu_get_sel()].l
		if left~=nil then sfx(50) left() end
	end
	
	if btnp(1) then
		local right=menu[menu_get_sel()].r
		if right~=nil then sfx(50) right() end
	end

	if btnp(2) then
		sfx(50)
		menu_set_sel(max(menu_get_sel()-1,1))
	end

	if btnp(3) then
		sfx(50)
		menu_set_sel(min(menu_get_sel()+1,#menu))
	end

	if btnp(4) then
		local enter=menu[menu_get_sel()].e
		if enter~=nil then sfx(51) enter() end
	end

	if btnp(5) then
		sfx(52)
		menu_back()
	end

	if game_state~=1 then return end
	for i=1,#menu do
		if menu[i].un~=nil then
			menu[i].n=menu[i].un()
		end
	end
end

function menu_draw()
	draw_shade(32,92,32,126,94,126,94,92)
	rect(32,92,96,126,0)

	for i=1,#menu do
		local x=(96+34-#menu[i].n*4)\2
		local y=(126+92-#menu*7)\2+(i-1)*8
		local nx=(96+34-#car_colors_default[player_color][3]*4)\2
		
		printo(car_colors_default[player_color][3],nx,85,11)
		
		if menu_get_sel()==i and menu[i].l~=nil then
			print("⬅️", 34, y, 2)
			print("➡️", 88, y, 2)
		end
		
		printo(menu[i].n, x, y, 7-5*is(menu_get_sel(),i))
	end
end

function is(x,y)
	if x==y then return 1 end
	return 0
end


posn={"1ST","2ND","3RD","4TH"}

function results_init()
	res_sorting={1,2,3,4}
	res_t=t()
	res_d=120
	res_tour=false
	res_frame=0
end

function results_update()
	if btnp(5) and res_d < 4 then
		sfx(51)
		if tour==nil then
			set_state(1)
			return
		end
		if res_tour then
			track=track%#tracks+1
			if track == 1 then
				waypoint_order*=-1
				if waypoint_order==1 then
					if final_position == 4 then
						set_state(1)
					else
						set_state(4)
					end
					return
				end
			end
			set_state(2)
			return
		end
		res_tour=true
		res_d=120
		res_frame=0
		for i=1,cars_count do
			tour[res_sorting[i]]+=cars_count-i+1
		end
	end
end

function results_draw()
	for y=-1,15 do
		for x=-1,15 do
			local ofs=(time()*16)%8
			rectfill(x*8+ofs,y*8+ofs,x*8+7+ofs,y*8+7+ofs,((x^^y)&1))
		end
	end
	
	local base_y=37-res_d
	res_d/=1.2

	rect(2,base_y,126,base_y+54,0)
	rectfill(3,base_y+1,125,base_y+53,5)

	local title="race results"
	if res_tour then
		title="tournament"
	end
	printo(title, 64-(12/2)*4,base_y+3,7)
	line(4,base_y+10,123,base_y+10,7)

	printo("pos",5,base_y+13,7)
	printo("car",22,base_y+13,7)
	if not res_tour then
		printo("time",83,base_y+13,7)
	end
	if tour~=nil then
		printo("pts",113,base_y+13,7)
	end
	
	for i=1,cars_count do
		local y=base_y+23+i*8-8

		local j=res_sorting[i]
		if j==1 then
			rectfill(3,y-2,125,y+6,13)
			final_position=i
		end

		local ni=min(i+1,cars_count)
		local nj=res_sorting[ni]
		if (res_tour and tour[j]<tour[nj]) or (not res_tour and cars[j].finish_time > cars[nj].finish_time) then
			res_sorting[i],res_sorting[ni]=res_sorting[ni],res_sorting[i]
		end
		
		local c=car_colors[j][1]
		printo(posn[i],5,y,c)
		printo(car_colors[j][3],22,y,c)
		if not res_tour then
			printo(time_str(cars[j].finish_time),83,y,c)
		end
		if tour~=nil then
			if res_tour then
				printo(tour[j],117,y,c)
			else
				printo(cars_count-i+1,117,y,c)
			end
		end
	end
	
	printo("❎ continue",44,120,7)
	res_frame+=1
end



trophy_image=[[ ね ◝リ**❎w*1 ミ<ゃ2웃8♪6-n'_{:|ハ<う7スゆ/4!/4'ほ)6!6 み<⬇️4レ8'5♥6"5▥7ル8➡️<s<ク7∧?ソeテ8q;ハへ7ユ6♪hソ3テ5ユ9|も?♪7テ9す9ソま:{や6ャ9ソfテほ<yよ>◆6ノ=♥6テ@v6%=♪9テbソ3テ^⬅️を6ケ5テaソセ9ソfテソ=ソeテス:テbソ3テろ2ノり=テ9 9ソる;⬆️む9ソfテよ7⬇️る6チ7♥7テ5♥6テゃ:ツ9⬅️fソ3テ>る=ヒ>チ7テaソり@❎へ9ソfテや;█ら=ソeテ`タ>ツ2x9テbソ3テb~@マ=テ9 9ソむ=⬅️<ミ;ソfテよ:⬅️;ム8チ7♥7テ5♥6テcタ>♪_ツ^チe⬅️;テ4タ8チ9웃<チf⬅️5ヨ3ラ2z2🐱6セ`ソ6チ8sd♪3y4ス=☉2ツ7ソふe⬅️8テ2ソ3☉6"3/9🅾️8チg⬅️6ヲ4◜2チ6●9ト3⌂6テ5ロc⬅️9🅾️3▒9チ5タ3~1ツ5♪k⌂:ト3▒2░@チ2ソ3#m⬅️;♪4ツ3⬆️み4ス8タk⬅️9ト3チ<☉5タ3…2ヒn⌂7ト3⌂6♪4ツ2ウ5スふq⬅️6ナ3ス2テ8ト6♪2タu웃7ナ5ト2'8タ5チy⬅️7♪2ネ:タ▒ソ=テ6ツ4⬅️○ソ:♪1テ3フ☉ソ7ト3⬅️4ソ2♪⬇️セb♪웃⬅️4テ2ナ8⌂☉⬅️7テ⧗⬅️6ト6♪😐⌂3ト7タ◆⬅️5テˇ⬅️2ト1テˇ⌂◝◝◝◝◝◝◝◝◝◝◝◝◝◝>⬅️ひ∧ツ◝◝は2タッ4タˇツ◝◝7タ⧗ツ◝◝2ソ2!4ツ♪テ1✽8⬅️🅾️テねチねチrス5ソ6ト✽ナ2░^♪ねチねチさチ7シ:セ5ツ○…2🐱f♪ねチねチあチ%v ◝◝ソ/l *テ*k )◝◝◝◝◝◝ネ*)l ツs#◝◝コ#x ◝クね^セ]]

function trophy_init()
	pal()
	pal(3,128,1)
	pal(15,7)
	
	if final_position==2 then
		pal(9,5)
		pal(10,6)
	elseif final_position==3 then
		pal(9,132,1)
		pal(10,4)
		pal(15,137,1)
	end

	lz77_decomp(0,0,80,112,trophy_image,sset)
	music(-1)
	sfx(57)
	
	dots={}
	for i=1,64 do
		add(dots,{x=rnd(128),y=rnd(128)-128})
	end
end

function trophy_update()
	if btnp(5) then
		sfx(51)
		set_state(1)
	end
end

function trophy_draw()
	for y=-1,15 do
		for x=-1,15 do
			local ofs=(time()*16)%8
			rectfill(x*8+ofs,y*8+ofs,x*8+7+ofs,y*8+7+ofs,((x^^y)&1))
		end
	end
	
	spr(0,24,2,10,14)

	print(posn[final_position],58,100,1)

	for i=1,64 do
		local dx=flr(rnd(5))-2
		local dy=flr(rnd(5))-2
		line(dots[i].x-dx,dots[i].y-dy,dots[i].x+dx,dots[i].y+dy,i%16)

		dots[i].y+=1
		if dots[i].y>=128 then
			dots[i].y = 0
		end
	end

	printo("❎ continue",44,120,7)
end



game_states={
	{init=title_init,update=title_update,draw=title_draw},
	{init=game_init,update=game_update,draw=game_draw},
	{init=results_init,update=results_update,draw=results_draw},
	{init=trophy_init,update=trophy_update,draw=trophy_draw}
}

game_state=1
next_state=0
trans=1
trans_dir=-0.066

function game_states_init()
	--set_state(1)
	title_init()
	title_update()
end

function game_states_update()
	if trans>0 then
		trans=max(trans+trans_dir,0)
		if trans>1 then
			trans=1
			trans_dir*=-1
			
			reload(0,0,0x2fff)
			pal()
			game_state=next_state
			game_states[game_state].init()
			game_states[game_state].update()
		end
	else
		game_states[game_state].update()
	end
end

function game_states_draw()
	game_states[game_state].draw()
	if trans>0 then
		set_transparent_pattern(trans)
		rectfill(0,0,127,127,0)
		fillp()
	end
end

function set_state(state)
	next_state=state
	trans_dir=0.066
	trans=0.01
end




--#include debug.lua

function _init()
 --poke(0x5f2e,1) --keep palette after program ends
 car_mesh_init()
 game_states_init()
end

function _update()
	game_states_update()
end

function _draw()
	game_states_draw()
end
