local dirs={1,0,0,1,-1,0,0,-1}
local decs={0,0,0,1,1,1,1,0}


base_chain=12--0

fill=0
filb=false
filr=false
mt=32

test={
 --"tim",
 --"tim",
}



function _init()
 t=0
 ents={} 
 logs={} 
 init_menu()
 --init_game()  
end


function init_milestones()
 milestones={
  { lim=3,  score=100  },
  { lim=5,  score=250  },
  { lim=10, score=500  },
  { lim=15, score=1000 },
 }  
end

function init_menu()
 t=0
 ents={}
 sfx(13) 
 
 -- milestones
 init_milestones()
 
 
 --
 
 local ready=nil
 
 upd=function()
 
  --fade
  fd=nil
  local n=t/3-8
  if not ready and n<=0 then 
   fd=n 
  end  
  
  if not ready then
   if btnp(4) or btnp(5) then
    ready=0
    sfx(14)
    
   end
  else
   ready+=1
   fd=max(ready/4-4,0)
 	 if ready==32 then
 	  init_game()
 	 end
  end 
  
  foreach(ents,upe)
  
  --
  -- sfx
  if t==24 then
   music(10)
  end  
 
  
  
 end
 
 mdr=function()
  cls()
  camera()
  rectfill(0,0,127,127,2)

  -- title
  local c=min(t/24,1)^2
  map(0,18,0,c*16-4,16,4)
  spr(224,0,c*16,16,2)  

  -- ents
  dp=1
  foreach(ents,dre)

  -- press start
  if t>24 then
   local y=116
   if ready and ready-8>0 then
    y+=ready-8
   end
   rectfill(0,y+1,127,y+7,1)
   local s="press ❎ to start"
   local disp=t%16<8
   if ready then disp=t%2==0 end
   if disp then
    print(s,63-#s*2,y+2,15)
   end
  end  
    
  --panels
  local mt=t-24
  if mt>0 then
	  local k=flr(mt/96)%5
	  if k==4 then k=3 end	  
	  disp_panel(k,mt%(5*96)-k*96)
  end
   
    
 end
 
 
 utm=1
 ff=function()
 
  local fr=16+rand(6) 
  local e=mke(fr,rand(128),48+rand(80))  
  local an=atan2(e.x-64,e.y-46)
  local dx=cos(an)*64
  local dy=sin(an)*64 
  
  e.x+=dx
  e.y+=dy  
  move(e,-dx,-dy,32,function() kl(e) end )
  e.twcv=uturn
  if not ready then 
   wt(2,ff)
  end
  e.bcl=rand(4)
 
  
 end 
 ff()
 
 
end


function disp_panel(pn,pt)

 px,py,pw,ph,cy=0,0,0,0,0
 
 function bp(x,y,ww,hh)
  rectfill(x,y,x+ww-1,y+hh-1,1)
  rect(x+1,y+1,x+ww-2,y+hh-2,7)
 end
 
 function pan(t,ww,hh) 
  px=(128-ww)/2  
  py=(158-hh)/2
  pw=ww
  ph=hh
  cy=py+12
  bp(px,py,ww,hh)
  local tbx=px+ww/2-#t*2
  bp(tbx-5,py-4,#t*4+9,11)
  print(t,tbx,py-1,7)
 end
 
 function pr(s)
  print(s,px+8,cy,7)
  cy+=7
 end
 
 
 function prg(n,lvl,score)  
  print("lvl",px+8,cy,7)
  print(lvl,px+22,cy,9)
  print(n,px+34,cy,7)
  print("+"..score,px+80,cy,11)  
  cy+=7
 end
 

 if pn==3 then
  pan("trophies",120,72)
  clip(px,py+8,pw,ph-10)  
  cy+=12-pt
  for i=0,14 do
  
   local n=tnames[i+1]
   local d=tdesc[i+1]
   print(n,px+pw/2-#n*2,cy,7)
   cy+=7
   print(d,px+pw/2-#d*2,cy,13)
   cy+=8
  end
  clip() 
 end
 
 
 if pn==2 then
  pan("grades",96,40)
  prg("scholar",6,1)
  prg("veteran",9,2)
  prg("legend",12,3)
 end
 
 
 if pn==0 then
	 pan("control",96,54)
	 pr("⬅️ .....move left")
	 pr("➡️ .....move right")
	 pr("⬇️ .....drop piece")
	 pr("⬆️,❎ ..turn piece")
	 pr("hold🅾️..see trophies")  
 end
 
 
 

 if pn==1 then
	 pan("bonus",48,50)	
	 for m in all(milestones) do
	  local s=m.lim..""
	  if #s==1 then s="0"..s end
	  print(s,46,cy,15)  
	  spr(11,54,cy)  
	  print("+"..m.score,64,cy,15)
	  cy+=8
	 end
 end
 

end


function white()
 fd=6 
 local f=function(e)
  fd-=.5
  if fd<=0 then
   fd=nil
   kl(e)
  end
 end
 loop(f)
end


function init_game()
 t=0
 white()
 grid={}
 balls={}
 events={}
 score=0
 mby=99
 cmx=0
 cmy=0
 lvl=1
 hc=0
 xp=0
 xmax=8
 ymax=15
 pcx=4
 tnum=0
 bgc=1
 chain_count=0 
 for y=0,ymax-1 do for x=0,xmax-1 do
  local c={x=x,y=y} 
  add(grid,c)
 end end

 --nei
 for c in all(grid) do
  c.nei={}
  for i=0,3 do
   local nx=c.x+dirs[1+i*2]
   local ny=c.y+dirs[2+i*2]
   local n=gsq(nx,ny)
   if n then add(c.nei,n) end
  end  
 end
 --
 init_milestones()

 -- malus
 malus={} 
 function ad(k,str,desc)
  for i=1,k do
	  local m={
	   id=#malus,
	  	name=str,
	  	desc=desc,
	  	act=false,
	  }
	  add(malus,m)
  end
 end
 ad(2,"col","extra color")
 ad(2,"shp","extra shape")
 ad(2,"chn","+4 chain limit")
 ad(2,"par","+1 parasite")
 ad(3,"siz","+50% piece size")
 ad(2,"bub","+10% bubble")
 ad(2,"foa","+25% foam")
 ad(2,"tim","-50% play time")

 -- trophies
 trophies={}
 for n in all(tnames) do
  add(trophies,{name=n,act=false})
 end
 
 -- test malus
 for t in all(test) do
  act_malus(t)
 end
 
 -- add 2 random dif
 for i=0,1 do
  --add_random_malus()  
 end


 --[[ fill balls
 for i=0,fill-1 do
  local x=rand(xmax)
  local y=rand(ymax)
  if isf(x,y) then
   local b=mkb(rand(get_max_shapes()),rand(get_max_colors()),x,y)
   if filr then b.bcl=0 end
   if filb then
    b.sh=8
    b.fr=16+b.sh
   end
  end
 end
 --]]
 
 --
 first_fill()
 
 --
 music(1,1000,3)
 gen_next() 
 gen_duty()
 ifall() 
 upd=upd_game
 mdr=dr_game
 
end


function first_fill()
 for y=0,2 do
  for x=0,xmax-1 do
			local b=mkb(rand(get_max_shapes()),rand(get_max_colors()),x,ymax-1-y)
      
  end
 end
  
 for i=0,300 do
  build_groups()
  local le=0
  local brk=true
  for g in all(groups) do    
   if #g>3 then
    brk=false
    for b in all(g) do
     b.bcl=rand(4)
     b.sh=rand(4)
     b.fr=b.sh+16
    end
   end    
  end
  if brk then
   break 
  end
 end

end


function gen_duty()
 duty={}
 for i=0,2 do
  add(duty,gpl())
 end
 
 for i=0,2 do
  for k=i+1,2 do
   local a=duty[i+1]
   local b=duty[k+1]
   

   if a.cl==b.cl or a.sh==b.sh then
   
    gen_duty()
    return
   end
  end
 end
 
 
end


function add_random_malus()
 local m=malus[rand(#malus)+1]
 if not m.act then
  m.act=true
 else
  add_random_malus()
 end 
end


function get_max_colors()
 return 4+gm("col")
end
function get_max_shapes()

 return 4+gm("shp")
end


function gpl()
 local pl={
 	sh=rand(get_max_shapes()),
 	cl=rand(get_max_colors()),
 }
 return pl
end

function gen_next()
 nxp={} 
 
 pmax=2
 for i=1,gm("siz") do
  pmax=min(pmax+rand(2),4)
 end 
 

 
 for k=0,pmax-1 do
  local m=gpl()
  for i=0,gm("bub")-1 do
   if rand(10)==0 then
    m.sh=8
   end
  end 
  add(nxp,m)
 end
end


function play_event(str)

 nxt=fall
 
 local a={}
 for i=0,xmax-1 do 
  if not gsq(i,2).ball then
   add(a,i) 
  end
 end
 ------------
 --parasite--
 ------------
 if str=="parasite" then  
  
  for i=1,gm("par") do
   if #a==0 then
    if nxt then
     nxt()
    end
    break
   end  
		 local x=a[rand(#a)+1]
		 del(a,x)
	  
	  local b=mkb(nil,nil,x,0)
	  b.y-=16
	  move(b,0,16,8,nxt)
	  nxt=fall
	  fast=true
  end
 end
 
 --------
 --foam--
 --------
 if str=="foam" then 
  for x in all(a) do
   if not gsq(x,ymax-1).ball then
    del(a,x)
   end
  end
  if #a==0 then
   nxt()
   return
  end
		local x=a[rand(#a)+1]
		del(a,x)
		for y=0,ymax-1 do		
		 local b=gsq(x,y).ball
		 if b then
		  place(b,x,y-1,8)
		 end		
		end		
		local b=mkb(8,0,x,ymax-1)		
		b.y+=8
		b.clp=true
		local f=function()
		 nxt()
		end
		move(b,0,-8,8,f)		
 end
 
 if str=="milestone" then
  sfx(19,nil,0,12)
  music(-1,400)
  local ms=milestones[1]
  del(milestones,ms)
  local str=" trophies bonus :"
  
  local e=mke()
  e.upd=function()
  
  end
  
  e.dr=function()
   
   local ⧗=e.⧗-64
   if ⧗==0 then
    sfx(19,nil,16)
    score+=ms.score
   end
   
   local ec=max(8-e.⧗/2,4)
   clip(40,0,xmax*8-2,128)
   local y=4-e.⧗/16-max(0,⧗)
   for i=0,#str-1 do
    local cl=sget((i+t)%4,4)
    local x=36+i*4
    local x=70+i*ec-(#str*(ec/2))
    print(sub(str,i,i),x,y,cl)
   end
   

   
   
   if ⧗>0 then
    
    local s="+"..ms.score
    local y=8-⧗/2
    local cl=9+t%2
    print(s,71-#s*2,y,cl)
   else
   
	   local l=ms.lim
	   local r=l>10 and 2 or 3
	   local tec=max(6-e.⧗/4,0)
	   for i=0,l-1 do
	    local x=71+i*r*2-l*r 
	    local dy=sin((t/2+i*3)/8)*tec  
	    spr(9,x,y+8.5+dy)
	   end   
   end
   clip()
   if ⧗>32 then
    kl(e)
    nxt()
    music(1,600)
   end

   
    
  end  

 end
 
end

function game_over()
 music(0)

 bgc=2
 gmo=mke()

 local x=0
 local f=function()  
  for y=0,ymax-1 do
   local b=gsq(x,y).ball
   if b then
    kl(b)
    del(balls,b)
    b.cell.ball=nil
    local e=mke(54,b.x,b.y)
    break
   end
  end   
  x=(x+1)%xmax
 end
 local lv=false
 
 gmo.upd = function()
  for i=0,1 do f() end
  if not lv and btnp(4) then
   lv=true
   fd=0
  end  
  if lv then
   fd-=1
   if fd<-4 then
    kl(gmo)
    init_menu()
   end
  end
  
 end
 
 gmo.dr=function()
  if gmo.⧗>40 then
   bgc=1
   local ⧗=gmo.⧗-40
   local s="press ❎ to restart -- "
   local ss=s..s
   local x=40-(t%(#s*4+4))
   local y=50--min(⧗*4,50)
   local open=max(64-⧗*4,4)
   clip(40,0,xmax*8,127)
   rectfill(0,y+2-open,128,y+2+open,2)
   if ⧗>12 then
    print(ss,x,y,7 )
   end
   clip()
  end
 end


end

function refresh_mby()
 mby=ymax
 for b in all(balls) do
  if not b.pc then
   mby=min(b.cell.y,mby)
  end
 end
end


function new_piece()
 
 -- check end
 refresh_mby() 
 if mby<2 then
  game_over()
  return
 end 
 
 
 -- new turn
 if nwt then
	 if gm("par")>0 then
	  add(events,"parasite")
	 end
	 if rand(100)<gm("foa")*25 then
	  add(events,"foam")
	 end 	  
	 local ms=milestones[1]
	 if ms and tnum>=ms.lim then
	  add(events,"milestone")
	 end
	 
	 nwt=false	 
	 if #duty==0 then
	  gen_duty()
	 end
	 
 end
 
 -- play events
 if #events>0 then
  local ev=events[1]
  play_event(ev)
  del(events,ev)
  return
 end 
 

 refresh_mby()

 pcs={}
 trn=0
 pcx=4 
 
 local i=0
 for n in all(nxp) do
  local x,y=gbp(i,trn)
  local b=mkb(n.sh,n.cl,x,y)  
  b.pc=true  
  b.y-=16
  --move(b,0,16,8)  
  place(b,x,y,8)
  add(pcs,b)
  i+=1
 end 
 
 gen_next()
 playing=loop(play) 

 
 
end



function progress()
 xp+=1
 if xp>=gmxp() then
  level_up()  
 end
end

function level_up()
 
 xp=0  
 list={}
 for m in all(malus) do
  if not m.act then
   add(list,m)
  end
 end
 
 if #list==0 then
  return 
 end
 
 music(-1,200)
 sfx(20)
 
 local fi=rand(#list)
 local tm=128
 local n=0
 local lim=-32
 chm=nil
 
 local f=function(e)
  n+=1 
  
  if chm then
   if n==32 then
    up=nil
    chm=nil
    lvl+=1
 	  kl(e)
 	  music(3,2000)
   end   
   return 
  end
  
  
  local m=list[1+fi%#list]
  him=m.id
   
  if n>lim then
   n=0   
	  if lim==10 then
	   
	   m.act=true
	   chm=m
	   him=nil	   
	   sfx(7)

	  else  
	   fi+=1	   
	   lim+=1	   
	   sfx(1,nil,5,1)
   end
  end
 end
 up=loop(f)
 up.dr=function()
 
 

  
  if chm then
   local s=chm.desc
   cl=sget(n/4,1)
   print(s,gmid()-#s*2,10-n/4,cl)
  else
	  local str="level up!!"  
	  local ec=max(8-up.⧗/4,1)   
	  for i=1,#str do
	   local x=gmid()+i*4-#str*2.5
	   local y=8.5+sin(t/16+i/5)*ec
	   local cl=8+(t+i)%8
	   print( sub(str,i-1,i-1),x,y,cl)
	  end  
  end 
  
 end
end

function gmid(s)
 return 72
end

function gm(str)
 local n=0
 for m in all(malus) do
  if m.name==str and m.act then
   n+=1
  end
 end
 return n
end




function gmxp()
 return 20+(lvl-1)*10
end

function pcpos()

 -- correct_pos
 for i=0,#pcs do
  local x,y=gbp(i,trn)
  local p=pcs[i+1]
  if p and x<0 then
   pcx+=1
  end
  if p and x>=xmax then
   pcx-=1
  end  
 end	

 for i=0,#pcs do
  local x,y=gbp(i,trn)
  local p=pcs[i+1]
  if p then
   place(p,x,y,3)
  end
 end	
 
 
end


function play(lp)

	function turn(n)
	 trn=(trn+n)%4
  pcpos()
	 sfx(1,nil,3,2) 
	end


 function pmov(n)	 
  pcx+=n
  pcpos()
  sfx(1,nil,1,2)
 end

 local ⧗=get_⧗()-lp.⧗

 tdg=nil
 if ⧗<80 then
  tdg=true
  if ⧗%16==0 then 
   sfx(1,nil,6,1)   
  end
 end

 if btnp(0) then pmov(-1) end
 if btnp(1) then pmov(1) end
 if btnp(2) or btnp(4) then turn(-1) end
 if btnp(3) or ⧗<=0 then
  playing=nil
  kl(lp)
  fast=true
  nwt=true
  tdg=nil
  for p in all(pcs) do
   p.pc=false
   p.y+=2
  end
  chain_count=0  
  ifall()  
 end
 
 -- hc
 local n=-1/8
 if btn(5) then n*=-1 end
 hc=mid(0,hc+n,1)
 
  
 

end




function gbp(i,trn)
 i=(i+trn)%4
 return pcx+decs[i*2+1],decs[i*2+2]  
end


function build_groups()
 for b in all(balls) do
  b.gid=nil
 end 
 gid=0 
 groups={}
 for b in all(balls) do 
  if not b.gid then
	  b.gid=gid
	  local g={}
	  add(groups,g)
			function seek(a)
			 add(g,a)
			 for b in all(gnei(a)) do
			  if b.gid != a.gid and cnx(a,b) then
			   b.gid=gid
			   seek(b)
			  end  
			 end
			end  
	  seek(b)
	  gid+=1
  end
 end 
end



function chk_groups()

	build_groups()
 

 for gr in all(groups) do
  --[[
  local l=false
  local r=false
  for b in all(gr) do
   l=l or b.cell.x==0
   r=r or b.cell.x==xmax-1
  end   
  --]]
 
  if #gr>base_chain+gm("chn")*4 then 
   sfx(3)
   xgr=gr
   for b in all(xgr) do
    b.wxpl=true
   end   
   wt(mt/2,explode_bubs)
   return
  end
 end 
 ifall()
end

function fx_exp(x,y)

 local e=mke()
 local r=3
 e.upd=function(e)
  local c=e.⧗/8
  r=2+4*sqrt(c)
  if c>=1 then
   kl(e)
  end
 end
 
 e.dr=function()
  circfill(x,y,r,7)
 end
 

end


function explode_bubs()
 
 local w=2
 
 for a in all(xgr) do
  for n in all(gnei(a)) do
   if n.sh==8 then
    kl(n)
    n.cell.ball=nil
    w=16    
    mke(52,n.x,n.y) 
       
   end
  end
 end
 if w>2 then
  sfx(8)
 end
 
 wt(w,analyze)
 
end

function brd(e,x,y,cl)
 apal(cl)
 e.dr(e,x-1,y)
 e.dr(e,x+1,y)
 e.dr(e,x,y+1)
 e.dr(e,x,y-1)
 pal() 
end


function analyze()
 local shapes={}
 local colors={}
 local sides={}
 for b in all(xgr) do
  uadd(shapes,b.sh)
  uadd(colors,b.bcl)
  if b.cell.x==0 then 
   uadd(sides,0)
  end
  if b.cell.x==xmax-1 then 
   uadd(sides,1)
  end
 end

 prk=0
 mult=1
 if #shapes==get_max_shapes() then
  brag("max shapes",1)
 end
 
 if #colors==get_max_colors() then
  brag("max colors",1)
 end
 
 if #sides==2 then
  brag("junction",3)
 end
 
 if #shapes==1 then
  brag("monoshape",3)
 end
 
 if #colors==1 then
  brag("monocolor",3)
 end
 
 if chain_count>0 then
  brag("chain",chain_count)
 end
 
 if #xgr==#balls then
  brag("all clear",lvl)
 end
 
 if #xgr>=30 then
  brag("huge",5)
 elseif #xgr>=20 then
  brag("big",2)
 end
 
 refresh_mby()
 if mby<2 then
  brag("last stand",3)
 end
 
 if lvl>=12 then
  brag("legend",3)
 elseif lvl>=9 then
  brag("veteran",2)
 elseif lvl>=6 then
  brag("scholar",1)
 end
 
 
 -- check duty
 local dsum=0
 for pl in all(duty) do
  for b in all(xgr) do 
	  if b.sh==pl.sh and b.bcl==pl.cl then
	   dsum+=1
	   break
	  end
	 end
	end
	
	
	if dsum==#duty then
	 brag("full duty",dsum+lvl)
	 take_duty=true
	elseif dsum>0 then
	 brag("duty",dsum)
	end

 chain_count+=1
 xpl={xgr[1]}
 wt(mt*prk,explode)
 
end

function brag(str,inc)
 

 
 -- trophies 
 for tr in all(trophies) do  
  if not tr.act and tr.name==str then
   tr.act=true
   tnum+=1
  end
 end 
 
 -- apply
 mult+=inc
 str=str.." +"..inc
 
 utm=2
 local f=function()
  sfx(5)
	 local e=mke(0,72-#str*2,-10) 
	 
	 move(e,0,8,mt,function() kl(e) end)
	 
	 e.twcv=uturn
	 
	 e.dr=function(e,x,y)  
	  print(str,x,y,8+t%8)
	 end
 end
 wt(mt*prk,f)
 
 prk+=1
 
 
end

function uturn(c)

 return min(-sin(c/2)*utm,1)
end 



function uadd(a,n)
 for k in all(a) do
  if k==n then
   return
  end
 end
 add(a,n)
end


function explode()
 
 local nxpl={}
 for a in all(xpl) do
  for b in all(gnei(a)) do
   if cnx(a,b) and not b.xpl then
    add(nxpl,b)
    b.xpl=true
   end
  end
    
  kl(a)
  del(balls,a)
  a.cell.ball=nil  
  add_score(mult,a.x+1+rand(5),a.y+3,sget(a.bcl))
 	progress()
 	
 	for i=0,1 do
 	 local x=a.x+rand(7)
 	 local y=a.y+rand(7)
 	 local p=mke(58,x,y)
 	 p.bcl=a.bcl
 	 p.we=-rnd()/5
 	 p.vx=(rnd(3)-1)/5
 	 p.frict=.95
 	end
 	
 	 
 end 

 xpl=nxpl 
 if #xpl>0 then 
  sfx(4)
  cmx=rand(8)-4
  cmy=rand(8)-4
  wt(3,explode)
 else
  xgr=nil
  if take_duty then
   duty={}
   take_duty=nil
  end
  
  chk_groups()
 end

end


function add_score(n,x,y,cl)
 score+=n
 local e=mke(0,x,y)
 local r=6
 e.upd=function()
  r*=.9
 end
 e.dr=function(e,x,y)
  circfill(x,y+2,r,7)
  print("+"..n,x-4,y,cl)  
 end
 e.brd=7
 e.dp=2
 move(e,0,-4-rand(4),12,function() kl(e) end)
 
 

end

function gnei(a)
 local res={}
 for c in all(a.cell.nei) do
  if c.ball then
   add(res,c.ball)
  end
 end
 return res
end

function ifall()
 flc=0
 fall()
end

function fall()
 
 local fall_spd=fast and 2 or 4
 local count=0
 for i=0,#grid-1 do
  local c=grid[#grid-i]
  local b=c.ball
  if b then
   local bot=gsq(c.x,c.y+1)
   if bot and isf(bot.x,bot.y) then
    bmov(b,0,1,fall_spd)
    b.pc=nil
    count+=1
   end  
  end
 end
 
 if ocn and ocn!=count then
  sfx(1,nil,0,1)
  if fast then sfx(2) end
 end
 
 
 if count>0 then
  ocn=count
  wt(fall_spd,fall) 
  flc+=1 
 else
  if fast then
   cmy=4
   fast=false
   --wt(2,progress)
  end  
  ocn=nil
  if flc>0 then
   chk_groups()  
  else
   wt(8,new_piece)
  end
 end 
 
 
 
end

function bmov(b,dx,dy,k)
 local nsq=gsq(b.cell.x+dx,b.cell.y+dy)
 b.cell.ball=nil
 b.cell=nsq
 nsq.ball=b
 local x,y=gcp(nsq)
 moveto(b,x,y,k)
end

function gcp(c)
 return (c.x+5)*8,c.y*8
end

function isf(x,y)
 local c=gsq(x,y)
 return c and not c.ball
end


function leave_cell(e)
 if e.cell then
	 if e.cell.ball==e then
	  e.cell.ball=nil
	 end
	 e.cell=nil
 end
end

function place(e,px,py,n)
 leave_cell(e)
 local tx,ty=(px+5)*8,py*8
 local c=gsq(px,py)
 
 if e.pc then
  ty-=2
 end
 
 c.ball=e
 e.cell=c
 
 if n then
  moveto(e,tx,ty,n)
 else
  e.x=tx
  e.y=ty
 end
 
end

function mkb(sh,cl,x,y)
  
 local sh=sh or rand(get_max_shapes())
 local cl=cl or rand(get_max_colors())
 
 local e=mke(16+sh)
 place(e,x,y)
 e.sh=sh
 e.bcl=cl
 e.rsa=rnd()
 e.rsb=rnd()
 add(balls,e)
 return e
end


function gsq(x,y)
 if x<0 or y<0 or x>=xmax or y>=ymax then
  return nil
 end
 return grid[1+y*xmax+x]
end






function rand(n)
 return flr(rnd(n))
end



function upd_game()
 
  
 if up then
  upe(up)
  return
 end
 if frz then
  frz-=1
  frz=frz>0 and frz or nil
 end 
 foreach(ents,upe)
 
 
 
end




function _update()
 t=t+1
 upd()
 --[[dev
 if btn(5,1) then
	 for i=1,10 do upd() end
	elseif btn(4,1) then
	 if t%10==0 then upd() end
	else
	 upd()
 end
 -]]

end




function upe(e)
 e.⧗+=1
 if e.upd then e.upd(e) end
 
 -- phys
 e.vy+=e.we
 e.x+=e.vx
 e.y+=e.vy
 e.vx*=e.frict
 e.vy*=e.frict
 
 -- anims
 if fget(e.fr,3) and e.⧗%4==0 then
  e.fr+=1
  if fget(e.fr,0) then
   kl(e)
   return
  end
 end

 --  tweens
 if e.twc then
  local c=min(e.twc+1/e.tws,1)
  cc=e.twcv and e.twcv(c) or c
  e.x=e.sx+(e.ex-e.sx)*cc
  e.y=e.sy+(e.ey-e.sy)*cc
  if e.jmp then   
   e.y+=sin(c/2)*e.jmp
  end  
  e.twc=c  
  if c==1 then
   e.twc=nil
   e.jmp=nil
   e.twcv=nil
   local f=e.twf
   if f then
    e.twf=nil
    f()
   end
  end
 end
 
 -- life
 if e.life then
  e.life-=1
  if e.life<16 and e.blk then
   e.vis=t%2==0
  end  
  if e.life<=0 then
   kl(e)
   if e.nxt then
    local f=e.nxt
    e.nxt=nil
    f()
   end
  end
 end 
  
end

function kl(e)
 del(ents,e)
 
end



function mke(fr,x,y)
 
 local e={
  x=x or 0,
  y=y or 0,
  fr=fr or 0,
  ⧗=0,dp=1,
  vx=0,vy=0,we=0,frict=1,
 }
 add(ents,e)
 return e
end


function dre(e)
 if dp != e.dp then
  return
 end
 local fr=e.fr
 local x=e.x
 local y=e.y
 
 
 -- pal
 if e.bcl then
  pal(8,sget(e.bcl,0))
 end
 if e.wxpl and (t%4<2 or e.xpl) then
  apal(7)
 end
 
 -- brd
 if e.brd then
  brd(e,x,y,e.brd)
 end
 
 -- clp
 if e.clp then
  clp=true
  clip(40,0,40+xmax*8,ymax*8+4)
 end
 
 -- draw
 local dr=e.dr
 if not dr and e.fr>0 then
  dr=function(e,x,y)
   spr(e.fr,e.x,e.y)
  end
 end 
 if dr then dr(e,x,y) end
 
 -- reset pal
 if clp then clip() end
 rpal()
 
end

function rpal()
 for i=0,15 do pal(i,i,0) end
end

function apal(n)
 for i=0,15 do pal(i,n) end
end



function _draw()

 mdr()

 --
 if fd then
	 for i=0,15 do
	  pal(i,sget(48+i,mid(0,5+fd,10)),1)
	 end 
 end

 -- log
 cursor(0,0,7)
 for l in all(logs) do
 color(8+t%8)
  print(l)
 end 
 
end

function dr_game()
 
 
 rectfill(0,-8,127,127,bgc)

 --[[
 if not scx then
  scx=0
  scy=0
 end
 scx-=.2
 scy-=.1 
 if scx<-128 then
  scx+=128
 end
 if scy<-128 then
  scy+=128
 end
 map(32,0,scx,scy,32,32)
 --]]

 if abs(cmy)>1 then
  cmy*=-.75
 else
  cmy=0
 end
 if abs(cmx)>1 then
  cmx*=-.85
 else
  cmx=0
 end
 
 hdx=(.5-cos(hc/2)/2)*56
 
 camera(cmx+hdx,cmy-4) 
 map(0,0,-8,-8) 
 draw_inter()
 draw_limit()
 --draw_back_balls()
 
 draw_links()

 
 dp=1 
 foreach(ents,dre)
 dp=2
 foreach(ents,dre) 
end


function draw_back_balls()
 
 for b in all(balls) do
  apal(( b.wxpl and t%4<2) and 13 or 1)
  sspr(0+b.sh*11,32,11,11,b.x-2,b.y-2) 
 end
 pal()
end

function draw_limit()
 if not playing or hc>0 then
  return
 end
 local cl=13
 if mby<5 then
  cl=9
 end 
 if mby==2 then
  cl=8+t%3
 end 
 
 line(40,14,40+xmax*8-2,14,cl)
 --[[ -- dots
 local la=4
 local lb=3
 local x=t%(la+lb)
 clip(40,14,xmax*8-1,12)
 while x<xmax*8+8 do
  line(32+x,14,32+x+la,14,cl)
  x+=la+lb
 end
 clip()
 --]]
 
 --[[
 for b in all(pcs) do
  local x=b.cell.x
  for y=2,ymax-1 do
   local sq=gsq(x,y)
   if sq.ball then
    break
   end
   local x=40+x*8+3
   local y=y*8+(t%8)-1
   rectfill(x,y,x+1,y+1,13)   
  end  
 end
 --]]
 
 if t%2==0 or true then
	 for x=0,xmax-1 do 
	  local s=0
	  local by=1
	  for y=2,ymax-1 do
	   if gsq(x,y).ball then
	    break
	   end
	   by=y
	  end 
	  for y=0,1 do
	   local b=gsq(x,1-y).ball
	   if b then
	    pal(8,sget(b.bcl,0))
	    spr(38+b.sh,(b.cell.x+5)*8,by*8)
	    by-=1
	   end 
	   pal()   
	  end 
	 end
 end 
 
end


function draw_inter()
 
 function bg(x,y,ww,hh)
	 rectfill(x,y,x+ww-1,y+hh-1,1)
  rectfill(x+1,y+1,x+ww-1,y+hh-1,5) --13
 end
 
 function pr(s,x,y,style)
  if x==-1 then
   x=17-#s*2  
  end   
  if style then
   print(s,x,y,style)
  else  
		 print(s,x+1,y+1,1)
		 print(s,x,y,7)
		end
 end
 
 function bar(r,y,cla,clb)
	 rectfill(7,y,26,y+2,cla) 
	 rectfill(7,y,7+19*r,y+2,clb)  
 end
 
 -- score
 bg(2,-2,30,9)
 local s=score..""
 while #s<5 do
  s="0"..s
 end
 pr(s,17-#s*2,0)

 -- level
 bg(2,10,30,14) 
 pr("lvl."..lvl,-1,12) 
 local r=xp/gmxp() 
 local cl=9
 if up then
  r=1
  cl=9+t%2
 end 
 bar(r,19,4,cl)
 
 -- next
 bg(2,27,30,30)
 pr("next",-1,29) 
 for k=0,1 do 
  local i=0 
  if k==0 then
   apal(1)
  end
  local dx=#nxp>2 and 10 or 14
  for b in all(nxp) do
	  local x,y=gbp(i,0)
	  if k==1 then	   
	   pal(8,sget(b.cl,0))
	  end
	  spr(16+b.sh,(x-pcx)*8+dx-k,y*8+39-k)
	  i+=1
	 end 
	 pal() 
 end
 
 -- duty
 bg(2,60,30,43)
 pr("duty",-1,62)
 local y=71
 for pl in all(duty) do  
  local ok=false
  if xgr then
   for b in all(xgr) do
    if b.sh==pl.sh and b.bcl==pl.cl then
     ok=true
     break
    end
   end
  end  
  if ok and t%2==0 then apal(7)  end
  spr(8,8,y)
  pal()  
  drb(pl.sh,pl.cl,13+4,y)
  y+=10
 end
 pal()
 
 -- time
 bg(2,106,30,14)
 pr("time",-1,108)
 r=1
 if playing then
  r=1-playing.⧗/get_⧗()  
 end 
 local bl=tdg and t%2==0
 local cla=bl and 8 or 13
 local clb=bl and 7 or 6 
 bar(r,115,cla,clb)
 
 
 -- malus
 local by=1
 bg(111,by-2,15,121)
 for i=0,16 do
  local m=malus[i+1]
  local style= 13
  if m.act then
   style=nil
  end
  if m.id==him then
   style=9+t%2
  end  
  pr(m.name,113,by+i*7,style)  
 end
 
 -- trophies
 bg(129,by-2,53,121)
 --[[ 
 for i=0,1 do
  local x=131+i*38
  apal(1)
	 spr(25,x+1,by+1,1.5,1)
	 pal()
	 spr(25,x,by,1.5,1)
 end 
 --]]
 pr("trophies",140,by+1)
 local i=0
 for tr in all(trophies) do
  local style=13
  if tr.act then style=nil end
  local y=12+by+i*7
  for i=tr.act and 0 or 1,1 do
   if i==0 then apal(1) else pal() end
   spr(tr.act and 11 or 10,131+1-i,y+1-i)
  end
  pr(tr.name,132+6,y,style)
  i+=1
 end

end




function get_⧗()
 return flr(512/(2^gm("tim")))
end

function drb(sh,cl,x,y)
 for k=0,1 do  
  if k==0 then apal(1) end
  if k==1 then
   pal()	   
   pal(8,sget(cl,0))
  end
  spr(16+sh,x+1-k,y+1-k)
 end
 pal() 
end




function draw_links()
 
 for a in all(balls) do
  for i=0,2 do
   local nx = a.cell.x+dirs[i*2+1]
   local ny = a.cell.y+dirs[i*2+2]
   local bc = gsq(nx,ny)   
   local ok=i<2 and bc and bc.ball and cnx(a,bc.ball)
   local ax,ay=gcn(a)
   local bx,by=0,0
   if ok then  	 
  	 bx,by=gcn(bc.ball)
   end   
   
   -- side link
   for k=0,1 do    
	   if a.sh!=8 and a.cell.x==k*(xmax-1) and i==2 then
	    ok=true
	    bx=(5+k*(xmax+1))*8-2-k*6
	    by=a.cell.y*8+3
	   end
   end   
  	if ok then  
  	 local cl=13	 
  	 if a.wxpl then
  	  cl=t%4<2 and 7 or 6
  	 end 
	   for dx=-1,1 do for dy=-1,1 do
	    line(ax+dx,ay+dy,bx+dx,by+dy,cl)
	   end end
	   --line(ax,ay,bx,by,13)
  	 --line(ax,ay,bx,by,6)
  	end  
  end
 end 
end

function gcn(a) 
 local an=a.rsa+t/ (16+a.rsb*8)
 local x=a.x+3.5+cos(an)*1.5
 local y=a.y+3.5+sin(an)*1.5
 return x,y
end


function cnx(a,b)
 if a.sh==8 or b.sh==8 then
  return false
 end
 return a.bcl==b.bcl or a.sh==b.sh
end

tdesc={
 "get all shapes in a combo",
 "get all colors in a combo",
 "join left and right walls",
 "combo with only one color",
 "combo with only one shape",
 
 "multiple combo in one turn",
 "clear the board", 
 "make a combo of 20+ stones",
 "make a combo of 30+ stones",
 "combo when limit is crossed",
 
 "cobo with 1+ duty stone",
 "combo with all duty stones",
 "combo with lvl 6 or above",
 "combo with lvl 9 or above",
 "combo with lvl 10 or above",
}


tnames={
 "max shapes",
 "max colors",
 "junction",
 "monoshape",
 "monocolor",
 
 "chain",
 "all clear", 
 "big",
 "huge",
 "last stand",
 
 "duty",
 "full duty",
 "scholar",
 "veteran",
 "legend",
}


-->8
-- libs

function log(n)
 add(logs,n)
 if #logs>20 then
  del(logs,logs[1])
 end
end

function loop(f,t,nxt)
 local e=mke(0)
 e.upd=f
 e.life=t
 e.nxt=nxt
 return e
end

function wt(t,f,a,b,c)
 local e=mke()
 e.life=t
 e.nxt=function() f(a,b,c) end
end


-- tweening
function move(e,dx,dy,n,f)
 moveto(e,e.x+dx,e.y+dy,n,f)
end

function moveto(e,tx,ty,n,f)
 e.sx=e.x
 e.sy=e.y
 e.ex=tx
 e.ey=ty
 e.twc=0
 e.tws=n
 e.twf=f 
 if n<0 then
  local dx=hmod(e.ex-e.sx)
  local dy=e.ey-e.sy
  local dd=sqrt(dx^2+dy^2)
  e.tws=-dd/n
 end

end
-->8
-- deprecated

function draw_links_dep()
 
 local lcl=t%2==0 and 13 or 6
 local lcl=8+t%8
 local lcl=13
 
 function lnk(a,dx,dy)
  local b=gsq(a.x+dx,a.y+dy)

  if b and b.ball and cnx(a.ball,b.ball)  then   
 
   for dx=-1,1 do for dy=-1,1 do
    local ax=a.ball.x+3+dx
    local ay=a.ball.y+3+dy
    local bx=b.ball.x+3+dx
    local by=b.ball.y+3+dy   
    line(ax,ay,bx,by,lcl)
   end end

  end
 
 end
 
 for c in all(grid) do
  if c.ball then
   lnk(c,1,0)
   lnk(c,0,1)  
  end
 end
 

end
-->8
-- dev

function act_malus(str)
 for m in all(malus) do
  if not m.act and m.name==str then
   m.act=true
   break
  end
 end
end