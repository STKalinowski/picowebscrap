
		----------------------------
  ------- a hat on time ------
		----- by @platformalist ----
		----------------------------

		-------- #demakejam --------

-- this is a demake of the game
-- a hat in time by gears for
-- breakfast. buy hat in time
-- on pc or consoles! it's much
-- larger than this lil fangame.

-- check out other demakes at
-- #demakejam on twitter or
-- on itch.io!


-- i used some code
-- banks for this jam, because
-- making my own collision code
-- and textbox functions for
-- a short jam would be an
-- exercise in self-destruction.

-- here's where you can grab
-- these open-source functions:

-- @matthughson's platformer in
-- 100 lines of code
-- lexaloffle.com/bbs/?pid=28249&tid=27626

-- level27geek textbox
-- https://www.lexaloffle.com/bbs/?pid=36894&tid=28757

-- pico8 lowercase strings
-- morgan3d
-- https://morgan3d.github.io/misc/p8escape/index.html

-- set cart mem on first boot
cartdata("eggnog_ahatontime_1")

function _init()

	state = 4
	points = 0
	deaths = 0
	timer = 0
	score = 0

-- set cart if first play
	if dget(2) == 0 then
		dset(1,0)
		dset(2,9999)
	end
	hiscore = dget(1)
	lospeed = dget(2)

-- player
p1=
{
-- position
	x=80,
	y=0,
	s=1,
	sf=false,
-- velocity
	dx=0,
	dy=0,
	isgrounded=false,	
-- tuning constants
	jumpvel=4,
-- respawn values
	respawnx=0,
	respawny=0,
}

-- globals
g=
{
	grav=0.35,
	gravmax = 6
}

lava = {}

graph = {}

dead = false

screen = {}
	screen.x = 1
	screen.y = 1
	screen.xv = 0
	screen.yv = 0
	screen.val = 1
	
hourglass = {}

poof = {}

hook = {}

balloon = {}

owl = {}

mist = {}

wiper = {}
	wiper[1] = lava
	wiper[2] = graph
	wiper[3] = hourglass
	wiper[4] = poof
	wiper[5] = hook
	wiper[6] = balloon
	wiper[7] = owl
	wiper[8] = mist
	
	tbx_init()

	texter = {}
		texter[1] = "welcome to ash town! population: less than three. press [z] to jump. oh, and don't touch the toxic ash! it's the worst."
		texter[2] = "oh, those floating hourglasses? those are time pieces! try to grab all 30! if you make it far enough, you might be lucky enough to find the legendary ash relic!"
		texter[4] = "conductor: oy, me train! me train! she derailed when i careened into this accursed ash storm. dj grooooooves catapulted clear out the window when we crashed. i hate to say it, but keep an eye out for him, lassie."
		texter[5] = "mafia: mafia almost crushed by train. next time ... train crushed by mafia."
		texter[7] = "mafia: mafia can see house from here! oh wait ... it is just pile of burnt sticks."
		texter[9] = "dj grooves: oh heeeey there, darling. that was one craaaazy crash back there. luckily for me, i pressed [x] near this hook shot panel, and it caught me before i landed."
		texter[14] = "mafia: mafia too scared to go on. maybe hat kid see what's ahead, then send mafia a postcard?"
		texter[16] = "c.a.w. agent: press [z] to jump! for more helpful hints, please divulge your social insurance number."
		texter[17] = "c.a.w. agent: balloons are good for popping. yes, it is true! now that we are acquainted, what is the fun number on the back of your credit card?"
		texter[25] = "mustache girl: oh, it's you. things are pretty tough up ahead, but i'm sure you'll find a way to play the hero."
		texter[26] = "mafia: owwwww. don't walk where express owls are looking. it'll mess you up."

-- grab title screen values
	title_screen_init()
	
	endgame = {}
		endgame.t = 0
		endgame.s = 2
		endgame.sf = false 

-- hourglass log
	pointlog = {}
	for i = 1,32 do
		pointlog[i] = false
	end	
	
	intro = {}
		intro.t = 0
 
end

function _update()
	if state == 1 then
		move_all_objects()
		player_functions()
		tbx_update()
	end
	update_title_screen()
	game_over_update()
	intro_update()
end

menuitem(1,"reset hiscores", function() reset() end)
	
function reset()
	dset(1,0)
	dset(2,9999)
	hiscore = dget(1)
	lospeed = dget(2)
end

function _draw()
 cls()
-- bg
 rectfill(0,44,127,127,14)
	pal(8,0)
	draw_bg_objects()
	palt(10,true)
 map(screen.xv,screen.yv,0,0,128,128) --draw map
	palt(10,false)
-- player
	spr(p1.s,p1.x,p1.y,1,1,p1.sf)
	draw_fg_objects()
-- stat box
	draw_stat_box()
-- textbox
 if (#tbx_lines>0) tbx_draw()
-- title screen
	draw_title_screen()
-- game over screen
	game_over_draw()
	intro_draw()
	pal()
end

function draw_stat_box()
	rectfill(0,0,127,7,0)
	line(0,7,127,7,7)
	spr(50,2,1)
	print(points,8,1,7)
	i = flr(timer)
	q = (#tostr(i)-1)*2
	spr(35,60-q,1)
	print(i,66-q,1,7)
	q = (#tostr(deaths)-1)*4
	spr(51,117-q,1)
	print(deaths,123-q,1,7)
end
-->8
-- matt hughson's code

function hook_check(v)
	if v.latch == true then
		ttv += 1
	end
end

function matt_hughson_collision()
-- remember where we started
	local startx=p1.x
-- jump 
	if btnp(4)
	 and p1.isgrounded then
-- launch the player upwards
		p1.dy=-p1.jumpvel
		sfx(2)
	 textbox(nil,2,12,7)
	end
-- walk	
	ttv = 0
	foreach(hook,hook_check)
	if ttv == 0 then
 	p1.dx=0
 	if btn(0) then
 		p1.dx=-2
 		p1.sf=true
 	end
 	if btn(1) then
 		p1.dx=2
 		p1.sf=false
 	end
	end
-- move the player left/right
	p1.x+=p1.dx
-- hit side walls
-- check for walls in the
-- direction we are moving.
	local xoffset=0
	if p1.dx>0 then xoffset=7 end
-- look for a wall
	local h=mget((p1.x+xoffset)/8+screen.xv,(p1.y+7)/8+screen.yv)
	if fget(h,0) then
-- they hit a wall so move them
-- back to their original pos.
		p1.x=startx
	end
-- textbox checker
	if fget(h,3) then
		q = screen.val
		if tbx_text == nil then
			sfx(7)
	 	textbox(texter[q],2,12,7)
		end
	end	
-- check for death tile
	if fget(h,1) then
		die()
	end
-- game over
	if fget(h,7) then
		music(25)
		state = 2
	end
-- accumulate gravity
	if p1.dy < g.gravmax then
		p1.dy+=g.grav
	end
-- fall
	p1.y+=p1.dy
-- hit floor
-- check bottom center of p1
	local v=mget((p1.x+4)/8+screen.xv,((p1.y+8)/8)+screen.yv)
-- assume they are floating 
-- until we determine otherwise
	p1.isgrounded=false	
-- check for death tile
	if fget(v,1) then
		die()
	end
-- only check for floors when
-- moving downward
	if p1.dy>=0 then
-- look for a solid tile
		if fget(v,0) then
-- place p1 on top of tile
			p1.y = flr((p1.y)/8)*8
-- halt velocity
			p1.dy = 0
-- allow jumping again
			p1.isgrounded=true
			foreach(balloon,respawn_balloon)
		end
	end
-- hit ceiling
-- check top center of p1
	local v=mget((p1.x+4)/8+screen.xv,(p1.y/8)+screen.yv)
-- check for death tile
	if fget(v,1) then
		die()
	end
-- only check for ceilings when
-- moving up
	if p1.dy<=0 then
-- look for solid tile
		if fget(v,0) then
-- position p1 right below
-- ceiling
			p1.y = flr((p1.y+8)/8)*8
-- halt upward velocity
			p1.dy = 0
		end
	end
end

-->8
-- effects and objects

function move_all_objects()
	foreach(lava,move_lava)
	foreach(hourglass,move_hourglass)
	foreach(poof,move_poof)
	foreach(hook,move_hook)
	foreach(balloon,move_balloon)
	foreach(owl,move_owl)
	foreach(mist,move_mist)
end

function draw_bg_objects()
	foreach(graph,draw_graph)
	foreach(lava,draw_lava)
end

function draw_fg_objects()
	foreach(hourglass,draw_hourglass)
	foreach(poof,draw_poof)
	foreach(hook,draw_hook)
	foreach(balloon,draw_balloon)
	foreach(owl,draw_owl)
	foreach(mist,draw_mist)
end

function object_dump()
	wipe_all_objects()
-- dump objects based on flag
	for i = 1,16 do
		for j = 1,16 do
			q = mget(i+(screen.xv),j+(screen.yv))
			object_lib(i,j,q)
		end
	end
-- add background lines
	for i = 1,128 do
		add(graph,make_graph(i,y))
	end
-- log player x,y for respawn
	respawn_log()
end

function object_lib(i,j,q)
	if fget(q,6) then
		add(owl,make_owl(i*8,j*8,sf,t,hbx,hby))
	elseif fget(q,1) then
		ttr = 10+rnd(3)
		add(lava,make_lava(i*8,j*8,ttr,ttr/1.2))
	elseif fget(q,2) then
		if pointlog[screen.val] == false then
			add(hourglass,make_hourglass(i*8,j*8,w,h))
		end
	elseif fget(q,4) then
		add(hook,make_hook(i*8,j*8,100,latch,range))
	elseif fget(q,5) then
		add(balloon,make_balloon(i*8,j*8,t,sf,hidden,ymin,ymax,ydir))
	elseif fget(q,7) then
		add(mist,make_mist(i*8+4,j*8+4,t))
	end
end

function wipe_all_objects()
	for i = 1,#wiper do
		q = wiper[i]
		foreach(q,decimate)
	end
end

function decimate(v)
	del(q,v)
end

function make_mist(x,y,t)
	local new_mist = {
	x = x,
	y = y,
	t = 0,
	}
	return new_mist
end

function move_mist(v)
	if v.t > 1 then
		v.t = 0
		explosion(v.x,v.y,3)
	else
		v.t += .25
	end
end

function draw_mist(v)
	spr(88,v.x-4,v.y-4)
end

function make_owl(x,y,sf,t,hbx,hby)
 local new_owl = {
	x = x,
	y = y,
	sf = false,
 t = 1,
 hbx = -20,
 hby = y+7,
 }
 return new_owl
end

function draw_owl(v)
-- stealth hitbox
	fillp(0b1000001001000001)
	rectfill(v.x+4,v.y,v.hbx,v.hby,46)
	fillp()
-- bird
	spr(96,v.x,v.y,1,1,v.sf)
end

function move_owl(v)
-- turn owl on timer
	if v.t < 20 then
		v.t += .2
	else
		v.t = 1
	end
	if v.t > 10 then
		v.sf = true
	else
		v.sf = false
	end
-- move visible hitbox based
-- on sin curve
	v.hbx = v.x + 4 + sin(v.t/20)*16
-- detect and kill player
	if v.sf == true then
		if player_detect(v.x+4,v.y+2,v.hbx-v.x,5) then
			die()
		end
	elseif v.sf == false then
		if player_detect(v.hbx,v.y+2,v.x-v.hbx+4,5) then
			die()
		end
	end
end

function make_balloon(x,y,t,sf,hidden,ymin,ymax,ydir)
	local new_balloon = {
	x = x,
	y = y,
	t = 0,
	sf = false,
	hidden = false,
	ymin = y-2,
	ymax = y+2,
	ydir = .25,
	}
	return new_balloon
end

function draw_balloon(v)
	if v.hidden == false then
		spr(13,v.x,v.y,1,1,v.sf)
	end
end

function move_balloon(v)
-- pop and bounce up!
	if player_detect(v.x,v.y,8,8) and
				v.hidden == false then
		v.hidden = true
		p1.dy =- p1.jumpvel
		sfx(8)
		explosion(v.x,v.y,4)
	end
-- move up and down
	if v.y > v.ymax or
				v.y < v.ymin then
		v.ydir *= -1
	end
	v.y += v.ydir
-- rotate from side to side
	if v.t > 1 then
		v.sf = true
	else
		v.sf = false
	end
-- count rotation timer
	if v.t < 2 then
		v.t += 0.1
	else
		v.t = 0	
	end
end

function respawn_balloon(v)
	if v.hidden == true then
		explosion(v.x+3,v.y+3,0)
		v.hidden = false
		sfx(9)
	end
end

function make_hook(x,y,latch)
	local new_hook = {
	x = x,
	y = y,
	k = k,
	range = false,
 latch = false,
	}
	return new_hook
end

function draw_hook(v)
	spr(10,v.x,v.y)
	if v.range == true then
		spr(11,v.x-1,v.y-1)
	end
-- latch line
	if v.latch == true then
		line(v.x+2,v.y+4,p1.x+3,p1.y+4,0)
	end
end

function move_hook(v)
-- measure hyp between hook and
-- hat kid
		i = abs(v.x-p1.x)
		j = abs(v.y-p1.y)
		k = sqrt(i*i + j*j)
		v.k = k
		if k < 40 and
					v.y-p1.y < 0 then
			v.range = true
		else
			v.range = false	
		end
-- if hyp is short enough, set
-- latched to true
	if btn(5) and
				v.range == true then
		v.latch = true
	else
		v.latch = false
	end	

		if btnp(5) then
			sfx(41)
			explosion(v.x+2,v.y+4,0)
		end
-- latch behavior
	if v.latch == true then
-- pull hat kid toward latch
			i = v.x-p1.x
			j = v.y-p1.y
 		if abs(p1.dy)<5 then
 			p1.dy += j*(1.2/k)
 		end
 		if abs(p1.dx)<5 then
				p1.dx += i*(.5/k)
			end
	end
end

function delatch_hook(v)
	v.range = false
	v.latch = false
end

function make_lava(x,y,r,pr)
	local new_lava = {
	x = x+3,
	y = y+8,
	r = r,
	pr = pr,
	}
	return new_lava
end

function draw_lava(v)
	circfill(v.x,v.y,v.r,0)
end

function move_lava(v)
	if v.r > v.pr then
		v.r -= rnd(5)/20
	else
		v.r = v.pr*1.15
	end
end

function make_graph(x,y)
	q = rnd(11) + 30
	local new_graph = {
	x = x-1,
	y = q,
	h = q+24,
	}
	return new_graph
end

function draw_graph(v)
	line(v.x,v.y,v.x,v.h,2)
end

function make_hourglass(x,y)
	local new_hourglass = {
	x = x,
	y = y,
	ymin = y-2,
	ymax = y+2,
	ydir = .25,
	}
	return new_hourglass
end

function draw_hourglass(v)
	spr(48,v.x,v.y)
end

function move_hourglass(v)
	if player_detect(v.x,v.y,8,8) then
		sfx(6)
		points += 1
		explosion(v.x,v.y,4)
		pointlog[screen.val] = true
		del(hourglass,v)
	end
-- move up and down
	if v.y > v.ymax or
				v.y < v.ymin then
		v.ydir *= -1
	end
	v.y += v.ydir
end

function player_detect(i,j,w,h)
	if p1.x > i+w or
				p1.x+8 < i or
				p1.y > j+h or
				p1.y+8 < j then
		return false
	else
		return true
	end
end

function make_poof(x,y,r)
	local new_poof = {
	x = x,
	y = y,
	r = r,
	}
	return new_poof
end

function draw_poof(v)
	circfill(v.x,v.y,v.r,7)
	circ(v.x,v.y,v.r,0)
end

function move_poof(v)
	if v.r > 0 then
		v.r -= .2
	else
		del(poof,v)
	end
	if v.r < 2 then
		v.x += .5
		v.y -= .25
	end
end

function explosion(x,y,r)
	for i = 1,5 do
		add(poof,make_poof(x+rnd(6)-3,y+rnd(6)-3,r+rnd(3)))
	end
end
-->8
-- player

function player_functions()
	screen_change()
	anim_player()
	matt_hughson_collision()
	clock()
end

function clock()
	if timer < 32000 then
		timer += 0.033
	end
end

function die()
		explosion(p1.x,p1.y,2)
		deaths += 1
		sfx(3)
		p1.x = p1.respawnx
		p1.y = p1.respawny
		explosion(p1.x,p1.y,2)
		foreach(hook,delatch_hook)
end

function screen_change()
	if p1.x > 123 then
		if screen.x < 8 then
			screen.x += 1
		else
			screen.x = 1
			screen.y += 1
		end
		p1.x = 2
		set_screen_values()
	elseif p1.x < -2 then
		if screen.x > 1 then
			screen.x -= 1
		else
			screen.x = 8
			screen.y -= 1
		end
		p1.x = 121
		set_screen_values()
	end
end

function set_screen_values()
		screen.xv = (screen.x-1) * 16
		screen.yv = (screen.y-1) * 16
		screen.val = screen.x + (screen.y-1)*8
		object_dump()
		textbox(nil,2,12,7)
end

function respawn_log()
		p1.respawnx = p1.x
		p1.respawny = p1.y
end

function anim_player()
-- running frames
	if btn(0) or 
				btn(1) then
		if p1.s == 1 then
			p1.s = 2
		end
 	if p1.s < 3.75 then
 		p1.s += .25
 	else
 		p1.s = 2
 	end
	else
		p1.s = 1
	end
	if p1.s == 1.25 or
				p1.s == 2.25 then
		sfx(0)
	end
-- jump frame
	if p1.isgrounded == false then
		p1.s = 4
	end
-- poof if using move without
-- proper panel
		if btnp(5) then
		 textbox(nil,2,12,7)
			explosion(p1.x+4,p1.y+4,0)
		end
end
-->8
-- level27 geek code

-- simple textbox
-- by fred bednarski

function tbx_init()
tbx_counter=1
tbx_width=33 --characters not pixels
tbx_lines={}
tbx_cur_line=1
tbx_com_line=0
tbx_text=nil
tbx_x=nil
tbx_y=nil
end

function tbx_update()
 if tbx_text!=nil then 
 local first=nil
 local last=nil
 local rows=flr(#tbx_text/tbx_width)+2
 --split text into lines
 for i=1,rows do
  first =first or 1+i*tbx_width-tbx_width
  last = last or i*tbx_width
  --cut off incomplete words
  if sub(tbx_text,last+1,last+1)!="" or sub(tbx_text,last,last)!=" " and sub(tbx_text,last+1,last+1)!=" " then
   for j=1,tbx_width/3 do
    if sub(tbx_text,last-j,last-j)==" " and i<rows then
     last=last-j
     break
    end
   end
  end
  --create line
  --if first char is a space, remove the space
  if sub(tbx_text,first,first)==" " then
   tbx_lines[i]=sub(tbx_text,first+1,last)
  else
   tbx_lines[i]=sub(tbx_text,first,last)
  end
   first=last
   last=last+tbx_width
 end
 --lines are now made
 --change lines after printing
 if tbx_counter%tbx_width==0 and tbx_cur_line<#tbx_lines then
  tbx_com_line+=1
  tbx_cur_line+=1
  tbx_counter=1  
 end
 --update text counter
 tbx_counter+=1
 if (sub(tbx_text,tbx_counter,tbx_counter)=="") tbx_counter+=1
 end
end

function tbx_draw()
 if #tbx_lines>0 then
  --print current line one char at a time
  print(sub(tbx_lines[tbx_cur_line],1,tbx_counter),tbx_x,tbx_y+tbx_cur_line*6-6,tbx_col)
  --print complete lines
  for i=0,tbx_com_line do
   if i>0 then
    print(tbx_lines[i],tbx_x,tbx_y+i*6-6,tbx_col)
   end
  end
 end 
end

function textbox(text,x,y,col)
 tbx_init()
 tbx_x=x or 4
 tbx_y=y or 4
 tbx_col=col or 7
 tbx_text=text
end



-->8
-- title screen

function title_screen_init()
-- image in binary string
bigstring = "000000000000000000000000000001111000000000000000000000111000000000000000000000000000000000000000000000000000000000000000000000000000000000000001111111100000000000000000111111100000000000000000000000000000000000000000000000000000000000000001111000000000000000111111111100000000000000011111111100000000000000000000000000000000000000000000000000000000000000011111111100000000011111111111000000000000000111111111100000000000000011010011111111111000000000000000000000000000001111111111110000001111111111110000000000000011111111111000000000000001111111111111111110000000000000000000000000000011111111111110000011111111111110000000000000111111111110000000000000011111111111111111000000000000000000000000000000111111111111110000111111111111100000000000001111111111100000000000000111111111111111110000000000000000000000000000001111111111111110001111111111111000000000000011111111111000000000000000111111111111111100000000000000000000000000000000001111111111000000111111111110000000000000111111111110000000000000001111111111111110000000000000000000000000000000000000011111100000000101011111100000000000011011111110100000000000000011111111111111100000000000000000000000000000000000000001110000001111100111110000000000111111001110011100000000000100111111111111111110000000000000000000000000111111111000000100000111111111111000000001111111111111111111111000000001111111111111111111110000000000000000000000000011111111100000000011111111111111100000111111111111111111111111100000011111111111111111111100000000000000000000000001111111111110000000110011111111111100111111111111111111111111111110000111111111100011111111000000000000000000000000111111111111110000011001111111111111111111111111111111111111111111110000111111111000000101100000000000000000000000001111111111111110001110111111111111111111111111111111001111111111111111000011111111100000001000000000000000000000000011111111111111100011011111111111111111111111111111111111111111111111111000111111111111001000000000000000000000000000011111111111110000001111111111111111111111111111111111111111111111111111111111111111111100000000000000000000000000000111111111111100000011111111111111111111111111111111111111111111111111111111111111111000000000000000000000000000000011111111111111000000111111111111111111111111111111111111111111111111111111111111111110000000000000000000000000000000111111111111111100001111111111111111111111111111111111111111111111111111111111111111100000000000000000000000000000001111111111111111000111111111111111111111111111110000000001111111111111111111111111111111111110000000000000000000000001111111111011111111111111111111111100001111111000000000000001111100001111111111111111111111111100000000000000000000011111111000111111111111111111110000000011111110000000000000011111000000001111111111111111111111110000000000000000000111001111101111111100000001111100000000111111000000000000000011110000000000111111111111111111111110000000000000000111100111111001111110000000011111000000001111110000000000000000011100000000000000000111111111111111110000000000000011100001111110000011000000000111110000000011111100000000000000000111000000000000000000000111111111111110000000001000110000011111111000110000000001111100000000111110000000000000000000110000000000000000000000011111111111111001001010001000000111111111001100000000011111000000001111100000000000000000001100000000000000000000000111111111111111001010100010000011111111111111000000000111110000000111111000000001100000000011111110000000000000000000111111111111110001110000000000111111111111110000000001111000000001111100000000011000000000111111111110000000000000001111111111111110001111000000001111111111111100000000000000000000011111000000000111000000001111111111100000000100000111111111111111100111111000000001111111111110000000000000000000000111110000000001110000000001111111111000000001111111111111111111111111111110000000011111111111100000000000000000000001111100000000111100000000011111111110000000011111111111111111111111111111110000000011111111111000000000000000000000011110000000001111000000000011111111100000000111111111111111111111111111111100000011111111111110000000000000000000000111000000000000000000000000011111111000000001111111001111111111111111101111000000111111111111100000000000000000000001110000000000000000000000000111111100000000011111100001111111111111111111110000001111111111111000000000000000000000011100000000000000000000000001111111000000000111111001001011101111111111110100000111000001111110000000011111000000000111000000000000000000000000011111110000000001111100110010011001111111111111000001110000011111000000000111110000000001100000000000000110000000000011111100000000011111001100100010011111111111110000011000000111110000000001111100000000011000000000111111100000000000011111000000000111110011001000000111111111111000001110000001111100000000011111000000000110000000001111111000000000000111110000000001111100110010000001111111111110000011100000011111000000000111111110000001000000000011111111000000000001111100000000111111001100100000011111111111100000111001000011110000000011111111111111110000000000111111111000000000011111000000001111110010001000000111111111111000011100011000111100000001111111111111111110000000011111111111000011111111111100000011111110000110000001111111111110000111000000001111000001111111111111111111111111111111111111111111111111111111111111111111110011100100011111111111000001110000000011110111111111111111111111111111111111111111111111111111111111111111111111111111111001000111111111110000111000000000111111111111111100000000111110000000000000011111111110000000000000111110001110111111011001111111111100001110001111111110000011111000000000001111100000000000000111111111000000000000001111100000000111111110011111111110000111100011110000000000011100000000000011111000000000000000111111110000000000000011111000000000001111111111111111100011111111000000000000000011100000000000111110000000000000001111111000000000000000111110000000000000011111111111100000110000000000000000000000111000000000001111100000000000000001111110000000000000001111000000000000000000111111110000001100000000000000000000000110000000000011111000000000000000011111000000000000000011110000000000000000001111111000000011100000000000000000000001100000000000111110000000000000000011110000000000000000111100000000000000000011111110000000111000000000000000000000111100000000011111100000000000000000011000000000000000001111000000000000000000111111100000001110000000000000000000011111000000001111111000000000000000000110000000000000000001100000000011111000011111111000000001100000000100000000001111110000000111111110000000000000000001100000000000000000011111100000111111111111111110000000011000011111000000000001111111100011111111100000000000000000010000000000000000001101111110001111111111111111000000000111111111110000000000011111111100111111111000000000000000000000000000000000000110011111100001111111111111110000000001111111111100000000000111111111000111111110000000000000000000000000000000000010101111001100000011111111111000000000011111000111000000000001111111110000111111100000000000000000000000000000000001001011110111000000111111011111000000000000000001111000000000001111111000000001111000000000000000000000000000000000010110111001110000001111110110011000000000000000011110000000000011111100000000001110000000000000000000000000000000100101111110010100000011111101100011000000000000000111100000000000111111000000000001100000000000000000000000000000001001011111101001000000111111011000111000000000000000111000000000001111110000000000011000000000001000000000000000000011110001111100110111111111110010011010000000000000001110000000000011111000000000000010000000000010000000000000011000111110000011001101111111111100001100110000000000000011110000000000111110000000000000100000000000100000000000000111111111100000000111111111111110000000000100000000000000111100000000000111100000000000001100000000001100000000000011111111111110000111110010111111110000000010000000000000001111000000000001111000000000000011100000000011110000000001111111111111111111111000000101111110000000000000000000000001110000000000011111000000000011111000000000111100000000011111111111111111111110000000000111100000000000000000000000011110000000000111110000000011111111111111111111111111111111111111111111111111110011000001111000000000000000000000000111100000000001111111111111111111111111111111111111111111111111111111111111111111110000011110000000000000000000000001111000001111111111111111111111111111111111111111111111111111111111111111111111111000000111100000000000000000000000011110111111111111111111111111111111111111111111111111111111111111111111111111111111000001111000000000000000000000000011111111111111111111111111111100000000000011111111111111111111111111111111111111111111011110000000000000000000000000111111111110000111111111111000000000000000111111111111111111111111111111111111111111111111100000000000000000000000001111110000000000000011000000000000000000000111111111111111111111111111111111001110111111111000000000000000000000000011000000000000000000000000000000000000000001111111111111111111111111111111100011000000011110000000000000000000000000000000000000000000000000000000000000000000001111111111111111111111111111111000110000000000000000000000000000000000000000000000000000000000000000000000000000000001111111111111111111111111111110011000000000000000000000000000000000000000000000000000000000000000000000000000000000001111111111111111111111111110000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111111111111111111000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111111111000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111111111111000000000000000000000000000000000000"

titlestr = {}
	titlestr[1] = "fangame by @platformalist"
	titlestr[2] = "based on 'a hat in time' by"	
	titlestr[3] = "gears for breakfast"
	titlestr[4] = "press [z] to start"
end

function update_title_screen()
	if state == 0 then
-- kick off the game!
 	if btn(4) then
 		state = 1
			music(9)
 	end
	end
end

function draw_title_screen()
	if state == 0 then
 	rectfill(0,0,127,127,7)
 	for i = 1,#titlestr do
 		print(titlestr[i],64-#titlestr[i]*2,95+i*6,2)
 	end
 	for j = 1,84 do
 		for i = 1,116 do
 -- grab single letter from str
 			k = i + (j-1)*116
 -- if val is 1, draw a pixel!
 			if sub(bigstring,k,k) == "1" then
 				pset(5+i,11+j,2)
 			end
 		end
 -- print hiscore and lospeed
		pal(7,2)
 	spr(50,2,1)
		pal()
-- 	print("hiscore:",2,1,0)
 	print(hiscore,9,1,2)
		q = flr(lospeed)
		k = (#tostr(q)-1)*4
-- 	print("best time:",83-k,1,0)
		pal(7,2)
 	spr(35,116-k,1)
		pal()
 	print(q,123-k,1,2)
		line(0,7,127,7,2)
 	end
	end
end


-->8
-- game over state

function game_over_update()
	if state == 2 then
-- set score
		if endgame.t == 0 then
			score = flr(timer-(deaths*4)+(points*10))
-- set hiscore to mem
 		if score > hiscore then
 			hiscore = score
 			dset(1,hiscore)
 		end
-- set lospeed to mem
 		if timer < lospeed then
 			lospeed = timer
				dset(2,lospeed)
 		end
		end
-- slide down blinds
		if endgame.t < 16 then
			endgame.t += 1
		end
-- make hat kid dance
		if endgame.s < 3.75 then
			endgame.s += .25
		else
			endgame.s = 2
			if endgame.sf == true then
				endgame.sf = false
			else
				endgame.sf = true
			end
		end
	end
	if endgame.t > 15 then
		if btn(5) then
			_init()
		end
	end
end

function game_over_draw()
	if state == 2 then
		tty = endgame.t*8
		rectfill(0,0,127,tty,7)
		line(0,tty,127,tty,0)
		print("great job! you found\nthe legendary stone!\n\ntime:\ndeaths:\ntime pieces:\n\ntotal score:\n\npress [x] to try again!",19,tty-90,0)
-- points deaths timer
		print(timer,39,tty-72,14)
		print(deaths,47,tty-66,14)
		print(points,67,tty-60,14)
		print(score,67,tty-48,14)
		rect(15,tty-94,112,tty-28,14)
		rect(16,tty-93,111,tty-29,2)
		rect(17,tty-92,110,tty-30,0)
-- draw hat kid
		for i = 1,3 do
			spr(endgame.s,20+i*20,tty-102,1,1,endgame.sf)
		end
		spr(88,61,tty-18)
	end
end
-->8
-- cogs for lunch intro

function intro_update()
	if state == 4 then
		if intro.t == 0 then
			sfx(42)
		end
-- kick off intro music
		if intro.t > 60 then
			foreach(poof,decimate) 
			music(1)
			object_dump()
			state = 0
		else
			intro.t += 1
		end
	end
end

function intro_draw()
	if state == 4 then
		rectfill(0,0,127,127,7)
--		q = "cogs for lunch"
		q = "gears for lunch"
		print("\71\69\65\82\83 \70\79\82 \76\85\78\67\72",64-#q*2,62,2)
		rect(31,60,95,69,2)
		foreach(poof,draw_poof)
	end
end