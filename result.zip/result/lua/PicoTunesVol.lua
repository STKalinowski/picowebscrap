--pico-8 tunes #2    @grubermusic
--      @krajzeg   @castpixel
object={}
function object:extend(kob)if type(kob)=="string" then
kob=ob(kob)end
kob=kob or {}
kob.extends,kob.meta=
self,{__index=kob}
return setmetatable(kob,{__index=self,__call=function(self,ob)ob=setmetatable(ob or {},kob.meta)
if (kob.init)kob.init(ob)
return ob
end
})end
vector={}
vector.__index=vector
function vector:__add(b)
return v(self.x+b.x,self.y+b.y,self.z+b.z)end
function vector:__sub(b)
return v(self.x-b.x,self.y-b.y,self.z+b.z)end
function vector:__mul(m)
return v(self.x*m,self.y*m,self.z*m)end
function vector:__div(d)
return v(self.x/d,self.y/d)end
function vector:__unm()
return v(-self.x,-self.y)end
function vector:dot(v2)
return self.x*v2.x+self.y*v2.y
end
function vector:norm()
return self/sqrt(#self)end
function vector:rotr()
return v(-self.y,self.x)end
function vector:len()
return sqrt(#self)end
function vector:__len()
return self.x^2+self.y^2
end
function vector:str()
return self.x..","..self.y
end
function v(x,y,z)
return setmetatable({x=x,y=y,z=z or 0,},vector)end
function mav(magnitude,angle)
return v(cos(angle),sin(angle))*magnitude
end
function call(fn,a)
return fn
and fn(a[1],a[2],a[3],a[4],a[5])or a
end
function set(o,props)for k,v in pairs(props or {})do
o[k]=v
end
return o
end
function ob(str,props)local result,s,n,inpar=
{},1,1,0
each_char(str,function(c,i)local sc,nxt=sub(str,s,s),i+1
if c=="(" then
inpar+=1
elseif c==")" then
inpar-=1
elseif inpar==0 then
if c=="=" then
n,s=sub(str,s,i-1),nxt
elseif c=="," and s<i then
result[n]=sc=='"'and sub(str,s+1,i-2)or sub(str,s+1,s+1)=="("and call(obfn[sc],ob(sub(str,s+2,i-2)..","))or sc!="f"and band(sub(str,s,i-1)+0,0xffff.fffe)s=nxt
if (type(n)=="number")n+=1
elseif sc!='"'and c==" " or c=="\n" then
s=nxt
end
end
end)
return set(result,props)end
function each_char(str,fn)local rs={}
for i=1,#str do
add(rs,fn(sub(str,i,i),i))end
return rs
end
obfn={v=v}
function init_palettes(n)local a=0x5000
for p=0,n do
for c=0,15 do
local v=sget(p,c)
if (c==sget(p,16))v+=0x80
poke(a,v)
a+=1
end
end
end
function set_palette(no)memcpy(0x5f00,0x5000+shl(flr(no),4),16)end
function bg(clr)rectfill(0,0,128,72,clr)end
function rndf(l,h)
return l+rnd(h-l)end
function rndpick(seq)
return seq[flr(rnd(#seq)+1)]
end
function lerp(a,b,t)
return a+(b-a)*t
end
function round(n)
return flr(n+0.5)end
psh=ob([[
o(x=-1,y=-1,c=0),
o(x=0,y=-1,c=0),
o(x=1,y=-1,c=0),
o(x=-1,y=0,c=0),
o(x=1,y=0,c=0),
o(x=-1,y=1,c=0),
o(x=0,y=1,c=0),
o(x=1,y=1,c=0),
o(x=0,y=0,c=1),
]])function printsh(t,x,y,c,a)
if (a)x-=a*4*#t
for d in all(psh)do
print(t,x+d.x,y+d.y,c*d.c)end
end
function each(seq,fn)local mapped={}
for i,e in pairs(seq)do
mapped[i]=fn(e,i)end
return mapped
end
function rng(a,b)
if (not b)a,b=1,a
local r={}
for i=a,b do
add(r,i)end
return r
end
function screengrab(yt,yb)memcpy(0x1800,0x6000+0x40*(yt+cam.y),(yb-yt+1)*0x40)end
function ngon(pts,c)local xls,xrs,npts={},{},#pts
for i=1,npts do
ngon_edge(pts[i],pts[i%npts+1],xls,xrs
)end
for y,xl in pairs(xls)do
rectfill(xl,y,xrs[y],y,c)end
end
function ngon_edge(a,b,xls,xrs)local ax,ay=a.x,round(a.y)local bx,by=b.x,round(b.y)
if (ay==by)return
local x,dx,stp=
ax,(bx-ax)/abs(by-ay),1
if by<ay then
xrs,stp=xls,-1
end
for y=ay,by,stp do
xrs[y]=x
x+=dx
end
end
function init_noise()srand(123)for addr=0x4300,0x4aff do
poke(addr,rnd(256))end
end
function noise(x,y)local ix,iy=band(x,0x3f),band(y,0x1f)local a=0x4300+shl(iy,6)+ix
local fx,fy=band(x,0x0.ffff),band(y,0x0.ffff)local ifx=1-fx
return (1-fy)*(peek(a)*ifx+peek(a+1)*fx)+
fy*(peek(a+64)*ifx+peek(a+65)*fx)end
function moving_noise(h,nx,nxm,nym,y_persp,fade,colors
)
nx-=nxm*256
local bps,lut={},{}
local first=0
for c in all(colors)do
for i=first,c[2]do
lut[i]=c[1]
end
first=c[2]
end
for y=1,h do
bps[y]={{x=127,c=12}}
end
local mnoise={}
function mnoise:move(d)
nx+=nxm*d
local dp,dpstep=d,d*y_persp
for y=1,h do
local ny,ln=y*nym,bps[y]
for _,b in pairs(ln)do
b.x+=dp
end
if ln[2]and ln[2].x>127 then
del(ln,ln[1])end
local nc=lut[flr(mid(noise(nx,ny)+fade*y,0,255))]
if nc~=ln[#ln].c then
add(ln,{x=0,c=nc})end
dp+=dpstep
end
end
function mnoise:render(base_y,rf)for y=1,h do
local sy,ln=base_y+y-1,bps[y]
for i=1,#ln do
local f,t=ln[i],ln[i+1]
if (f.c)rf(f.x,sy,t and t.x or 0,sy,f.c)
end
end
end
for i=1,256 do
mnoise:move(1)end
return mnoise
end
function waterfall_scene()local brefl=bumprefl()local w1,w2=
waterfall(36,12,17,56,3,brefl),waterfall(88,8,25,56,2,brefl)
return function(t)bg(12)w1.body(t)w2.body(t)map(0,0,0,0,16,8)set_palette(7)brefl:update()brefl:draw(t)set_palette()w1.foam(t)w2.foam(t)screengrab(28,59)end
end
bumprefl=object:extend()function bumprefl:init()self.b,self.v={},{}
for i=-65,832 do
self.b[i]=0
self.v[i]=0
end
end
function bumprefl:update()local i=0
local ba,va=self.b,self.v
for i=0,767 do
local b,v=ba[i],va[i]
v=(ba[i-64]+ba[i-1]+ba[i+1]-b*3)*0.018+
(ba[i+64]-b)*0.016+
v-b*0.02
b+=v
v*=0.955
ba[i],va[i]=b,v
end
end
function bumprefl:draw(t)local i=0
for y=60,71 do
local shy=296.09-y*2.8181
for x=0,127,2 do
local b=flr(self.b[i])if abs(b)>15 then
rectfill(x,y,x+1,y,b>0 and 7 or 0)else
sspr(x+b,shy,2,1,x,y)end
i+=1
end
end
end
function waterfall(c,w,top,bottom,flow,brefl)local xl,xr=c-w,c+w-1
local flows,foam={},{}
local gravity,foam_c,foam_p=
v(0,0.08),ob([[6,7,7,7,]]),
ob([[-23130.5,23130.5,0.5,0.5,]])
local rects={bottom,12,top+1,7,top,5}
return {
body=function(t)
t/=8
for i=1,5,2 do
rectfill(xl,top,xr,rects[i],rects[i+1])
end
for m=1.1,2.1 do
rectfill(c+sin(t*m)*w,top+1,
c+sin(t*m+0.05)*w,bottom,
13)
end
for i=1,flow do
add(flows,{
x=rndf(xl,xr),
y=top+1,v=rndf(1,3),
c=rndf(6,8)
})
end
for f in all(flows)do
local x,y,vel=f.x,f.y,f.v
f.y+=vel
rectfill(x,y,x,f.y+vel,f.c)
if y>bottom then
del(flows,f)
add(foam,{
p=v(x,y),
v=mav(vel*rndf(0.1,0.2),rndf(0.15,0.35)),
l=vel*2.5
})
brefl.v[flr(x*0.5)]+=vel*5
end
end
end,
foam=function(t)
for f in all(foam)do
local i=flr(f.l/3)+1
local size=5.5-abs(f.l-4)
fillp(foam_p[i])
circfill(f.p.x,f.p.y,size,foam_c[i])
circfill(f.p.x+2,f.p.y+2,size,6)
f.p+=f.v
f.v+=gravity
f.v*=0.985
f.l-=0.4
if (f.l<=0)del(foam,f)
end
fillp()
end
}
end
function clockwork_scene()
local beat,trans=48,20
local panel_pos=ob([[
v(5,32),
v(39,20),
v(72,21),
v(103,28),
]])local gear_draws=ob([[
o(v=v(2,2),c=0),
o(v=v(0,-1),c=13),
o(v=v(0,0),c=5),
]])local fggears=each(ob([[
o(v(25,7),10,7,0.4,1),
o(v(53,32),20,10,0.2),
o(v(61,75),16,8,0.28,1),
o(v(14,46),15,8,0.25,1),
o(v(90,19),12,8,0.4,1),
o(v(114,44),15,8,0.25),
]]),function(d)return call(gear,d)end)local bggears=each(ob([[
o(v(13,15),15,6,0.24,1),
o(v(71,6),8,6,0.25,1),
o(v(82,66),25,18,0.15),
o(v(33,66),18,14,0.2,1),
o(v(120,10),12,10,0.2,1),
]]),function(d)return call(gear,d)end)local panels=each(panel_pos,panel)local bt,phase=0
return function(t)local on_beat=t-bt>trans and stat(20)%8==0
if (on_beat)bt=t
phase=(t-bt)/trans
if (phase>1)phase=0
bg(0)for g in all(bggears)do
local c,s=g(phase,v(0,0),1)circfill(c.x,c.y,s*0.8,0)circfill(c.x,c.y,2,1)end
for g in all(fggears)do
for d in all(gear_draws)do
g(phase,d.v,d.c)end
end
for p in all(panels)do
p(on_beat)end
end
end
panel_words=ob([[
o(2,4,14,6),
o(0,1,2,3),
o(9,6,6,10),
o(11,12,13,7),
o(2,6,14,15),
o(1,5,6,7),
]])function slat_coords(w,i)local sprn=panel_words[w][i]
return v(72+sprn%4*6,flr(sprn/4)*8)end
function panel(bpos,d)local move_dir=ob([[-1,-1,-1,1,1,1,]])
local slats=ob([[0,0,0,0,]])
local word,order,moving,turning=0,5,0
local s1,s2
local pos,vdown=bpos,v(0,1)
return function(beat)
if beat and not turning or not s1 then
moving=8
order+=1
if order==6 then
order=0
word=word%#panel_words+1
s1,s2,slats=
slat_coords(word,d),
slat_coords(word%#panel_words+1,d),
ob([[0,0,0,0,]])
elseif order<5 then
repeat
turning=flr(rndf(1,5))
until slats[turning]==0
end
end
if turning then
slats[turning]+=0.0625
if slats[turning]==1 then
turning=nil
end
end
if moving>0 then
pos.y+=0.5*move_dir[(order+shl(1,d))%6+1]
moving-=1
end
map(32,0,pos.x-8,pos.y-11,4,5)
for y=0,3 do
slat(pos+vdown*y*6,
s1+vdown*y*2,s2+vdown*y*2,
slats[y+1])
end
end
end
function slat(p,s1,s2,turn)
local x,y,h=p.x,p.y,abs(cos(turn/2))*6
local half_h=h/2
local yb=y-half_h
set_palette(5-abs(0.5-turn)*10)
rectfill(x,yb,x+19,y+half_h-1,0)
local s=turn>0.5 and s2 or s1
sspr(s.x,s.y,6,2,x+1,yb,18,h)
set_palette(8)
sspr(s.x,s.y,6,1,x+1,yb,18,1)
set_palette()
end
function gear(c,size,count,height,cw)
local pitch,width=1/count,0.5/count
if (cw)pitch*=-1
local spokes=each(rng(count),function(i)
local b=i*pitch
return rotgon({
{0.95,b-width*0.2},
{0.95,b+width*1.2},
{1+height,b+width*0.8},
{1+height,b+width*0.2}
})
end)
return function(seq,d,clr)
local ctr=c+d
for s in all(spokes)do
s:update(ctr,size,seq*pitch):draw(ngon,clr)
end
circfill(ctr.x,ctr.y,size,clr)
return c,size
end
end
function rotgon(pts)
local rpts=each(pts,function()return v(0,0)end)
return {
update=function(self,c,s,a,sx)
sx=sx or 1
for i,p in pairs(pts)do
local a,as,rp=
p[2]+a,p[1]*s,
rpts[i]
rp.x,rp.y=
c.x+cos(a)*as*sx,
c.y+sin(a)*as
end
return self
end,
draw=function(self,fn,clr)
fn(rpts,clr)
return self
end,
pts=rpts,
opts=pts
}
end
function extrude_and_outline(pts,depth,clr,outline)
local npts,dv=#pts,v(depth,0)
for i,p in pairs(pts)do
local n=pts[i%npts+1]
if p.y<n.y then
ngon({p,p+dv,n+dv,n},clr)
line(p.x+outline,p.y,n.x+outline,n.y,0)
end
end
end
function gate_scene()
local glow=circs(ob([[
o(x=0,y=0,r=13,clr=2),
o(x=-1,y=0,r=11,clr=4),
o(x=-2,y=0,r=10,clr=9),
o(x=-3,y=0,r=9,clr=10),
o(x=-4,y=0,r=7,clr=7),
]]),2)local segs=ob([[
o(s=0,as=0.01,ae=0.115),
o(s=0,as=0.1975,ae=0.265),
o(s=0,as=0.285,ae=0.365),
o(s=0,as=0.4475,ae=0.5525),
o(s=0,as=0.6975,ae=0.8025),
o(s=0,as=0.8225,ae=0.865),
o(s=0,as=0.885,ae=0.99,h=3),
o(s=0.05,as=0.135,ae=0.1775,h=2),
o(s=0.05,as=0.385,ae=0.4275,h=2),
o(s=0.05,as=0.5725,ae=0.615,h=3),
o(s=0.05,as=0.635,ae=0.6775,h=3),
]])for s in all(segs)do
local inner,outer=23*(1-s.s),30*(1+s.s)s.rg=rotgon({{inner,s.as},{inner,s.ae},{outer,s.ae},{outer,s.as}
})s.c=v(58-(s.h or 0),36)end
local stars=starfield(ob([[
origin=v(128,36),
spread=36,n=100,
left=0,right=128,
spd=1,spdf=1,flip=-1,
colors=o(1),
]]))local tunnel=starfield(ob([[
origin=v(74,36),
spread=6,n=200,
left=74,right=128,
spd=3,spdf=-2,flip=1,
colors=o(7,7,10,9,4,2,1),
]]))local tunnel_rects=ob([[
o(y1=32,y2=40,c=1),
o(y1=33,y2=39,c=4),
o(y1=34,y2=38,c=9),
o(y1=35,y2=37,c=10),
]])local ships,ship_p={},0.1
local anim,g1a,g2a=0,0,0.5
return function(t,cam)anim=lerp(anim,0,0.1)local pull=min(-anim*7,0)local rot_speed=1-anim
g1a-=rot_speed/240
g2a+=rot_speed/360
stars:draw()function draw_gates(front_parts)draw_gate(segs,0.8,v(20+pull,0),g1a,5,13,1,front_parts)draw_gate(segs,1,v(-pull,0),g2a,13,6,1,front_parts)end
draw_gates(false)glow(v(64,36),1+anim*0.75)for r in all(tunnel_rects)do
rectfill(tunnel.left,r.y1,128,r.y2,r.c)end
tunnel:draw()for s in all(ships)do
if s:update(ships)then
anim=2
g1a+=0.05
g2a-=0.05
end
s:render()end
set_palette()draw_gates(true)if rnd()<ship_p then
local bv=rndf(0.25,0.4)add(ships,ship({p=v(-16,rndf(28,44)),base_v=bv,v=v(bv,0),m=rndpick(ship.models)}))ship_p=-0.015
else
ship_p+=0.0005
end
end
end
ship=object:extend(ob([[
models=o(
o(sx=0,sy=40,sw=8),
o(sx=0,sy=32,sw=16),
o(sx=8,sy=40,sw=8),
o(sx=0,sy=48,sw=16),
),
]]))function ship:update(ships)local d=64-self.p.x
if d<50 then
self.v.x+=0.25/d*d
end
self.p+=self.v
if self.p.x>=128 then
del(ships,self)end
if d<22 and not self.boom then
self.boom=true
return true
end
end
function ship:render()local m,v_factor=self.m,self.v.x^2
local w=(1+v_factor*0.125)*m.sw
local plt=16+v_factor*0.3
for n=4,0,-1 do
set_palette(mid(plt-n*3,16,21))palt(0,true)sspr(m.sx,m.sy,m.sw,8,self.p.x-(self.v.x-self.base_v)*n,self.p.y,w,8)end
end
function draw_gate(segs,size,d,a,fg,hl,bg,front)for s in all(segs)do
s.front=(s.rg.opts[1][2]+a+0.75)%1>0.5
if s.front==front then
s.rg:update(s.c+d-v(1,1),size,a,0.5)extrude_and_outline(s.rg.pts,5+(s.h or 0),bg,2)end
end
for s in all(segs)do
if s.front==front then
s.rg:draw(ngon,hl):update(s.c+d,size,a,0.5):draw(ngon,fg)end
end
end
function circs(cs,r,cr)
return function(ctr,scl)for c in all(cs)do
circfill(ctr.x+c.x*scl+(cr or 2)*rnd(),ctr.y+c.y*scl+(cr or 2)*rnd(),c.r*scl+rnd(r),c.clr
)end
end
end
starfield=object:extend()function starfield:init()self.stars=each(rng(self.n),function()local s=self:new()s.x=rndf(self.left,self.right)
return s
end)end
function starfield:new()local ny=rndf(-0.99,0.99)local y=self.origin.y+ny*self.spread
local vx=self.spd+ny^2*self.spdf
local c=self.colors[flr(1+abs(ny)*(#self.colors))]
return {x=self.origin.x,y=y,vx=vx*self.flip,c=c
}
end
function starfield:draw()for i,s in pairs(self.stars)do
local x=s.x
rectfill(x,s.y,x-s.vx+self.flip,s.y,s.c)
s.x+=s.vx
if x<self.left or x>self.right then
self.stars[i]=self:new()end
end
end
function autumn_scene(wind_s)local tree=branch(19,0,4)local wind=0
local gust,delay=wind_s,120
local sky=moving_noise(58,1,0.05,1,-0.01,2,ob([[o(7,100),o(6,150),o(12,256),o(13,256),]])
)
local ground=moving_noise(
27,18.80,0.02,0.04,0,0,
ob([[o(f,135),o(6,145),o(10,170),o(9,180),o(10,190),o(9,210),o(4,256),]])
)
return function(t)
sky:render(0,rectfill)
ground:render(46,rectfill)
tree(v(27,66),0.25,wind,t/120)
set_palette(9)
spr(112,19,62,2,1)
wind=lerp(wind,gust,0.01)
delay-=1
if delay<=0 then
gust,delay=
max(wind_s-gust+rndf(0.0,0.2)*wind_s,wind_s*0.1),
rndf(60,240)
end
sky:move(wind*30)
end
end
depth_base_w,depth_tip_a=
0.03,0.004
function branch(m,a,depth)
local children
if depth>0 then
function fork(length,turn,depth)
return branch(length*0.8*rndf(0.9,1.1),turn*rndf(0.6,1.5),depth-1)
end
children={fork(m,-0.1,depth),fork(m,0.1,depth)}
else
children={clump()}
end
local base_w=0.15+depth_base_w*depth
local tip_a=0.01+depth_tip_a*depth
function shape(wl,wr,as)
return rotgon({
{base_w*wl,-0.25},{base_w*wr,0.25},
{1,tip_a*as},{1,-tip_a*as}
})
end
local back,front=
shape(1,1,1),shape(0.15,0.65,0.5)
local right,off,twist=v(1,0),rndf(-0.1,0.1),0
return function(base,ang,wind,t)
ang+=a
local wind_s=wind/(depth+1)
wind_s*=right:dot(mav(1,ang-0.25))
wind_s=mid(wind_s,-0.05,0.05)
twist+=wind_s*0.07
twist*=0.95+sin(t+off)*0.01
ang-=twist
back:update(base,m,ang):draw(ngon,0)
front:update(base,m,ang):draw(ngon,2)
local tip=base+mav(m,ang)
for child in all(children)do
child(tip,ang,wind,t*(1+off))
end
end
end
local leaf_s=ob([[13,14,15,29,30,31,]])
function clump()
local leaves=each(rng(10),function()
return {
p=mav(rndf(0,8),rnd())-v(4,4),
s=rndpick(leaf_s)
}
end)
return function(base,_,wind)
local windf=min(wind*5+0.5,2)
for _,l in pairs(leaves)do
local lx,ly=
base.x+l.p.x+rnd(windf),
base.y+l.p.y+rnd(windf)
spr(l.s,lx,ly)
if l.v then
l.p+=l.v
l.v.x+=wind*rndf(-0.2,2)
l.v.y+=rndf(0,0.04)
l.v*=0.95
if lx>128 or ly>72 then
del(leaves,l)
end
end
end
if rnd(20)<wind then
add(leaves,{
p=mav(4,rnd()),
v=v(0,0),
s=rndpick(leaf_s)
})
end
end
end
function flame_scene()
local sprs=ob([[
moon=o(82,104,3,2,2),
bonfire1=o(66,33,43,2,1),
bonfire2=o(66,41,44,2,1),
aragorn=o(68,65,26,4,4),
]])local light=ob([[
o(1,54,-23131),
o(1,50),
o(18,42,-23131),
o(2,34),
o(36,27,-23131),
o(4,20),
o(9,11)
]])light[0]={0,54}
for i=1,#light do
local l=light[i]
l.extent,l.clr={},{}
local radius=l[2]
for a=0,0.24,0.008 do
local x,y=
cos(a)*radius,flr(-sin(a)*0.3*radius)l.extent[y],l.clr[y]=
x,noise(y*0.7,2)<128 and i-1 or i
end
end
local lighting=flamelight(45,53,light)local flames=each(ob([[
o(45,47,5,0.8),
o(43,46,3,0.4),
o(47,48,4,0.6),
]]),function(fd)
return call(flame,fd)end)
return function(t)
t*=0.1
local wind=noise(t,3)/1024
for i=1,20 do
pset(noise(i,10)/2,noise(i,8)/8,1)end
call(spr,sprs.moon)lighting(t)set_palette(5)sspr(32,32,32,32,63,51,64+wind*64,11,false,true)set_palette(10+noise(t*5,3)/80)call(spr,sprs.aragorn)set_palette()call(spr,sprs.bonfire1)call(spr,sprs.bonfire2)for f in all(flames)do
f(t,wind)end
set_palette()end
end
function flame(cx,cy,gen,sz)local sparks={}
return function(t,wind)local m=1+noise(t,4)/512
for i=1,gen*m do
add(sparks,{x=cx-4+noise(t*3,4)/32+rndf(-sz,sz),y=cy,vx=rndf(-sz,sz),vy=-0.5,age=0,swing=rndf(0.04,0.07)})end
set_palette(15)for i,s in pairs(sparks)do
s.age+=0.015
s.x+=s.vx+wind
s.y+=s.vy
s.vx-=(s.x-cx)*s.swing*s.age
local x,y=s.x,s.y
if rnd()>s.age then
pset(x,y,pget(x,y))pset(x,y+1,pget(x,y+1))end
if s.age>1 then
sparks[i]=nil
end
end
end
end
function flamelight(cx,cy,light)
return function(t)local by=cy
for l in all(light)do
local flicker=1+noise(t,l[2])*0.001
for y=-18,18 do
local yi=abs(y)local ext,clr=l.extent[yi],l.clr[yi]
if ext then
fillp(light[clr][3])
ext*=flicker
ext+=rndf(-2,2)
rectfill(cx-ext,by+y,cx+ext,by+y,light[clr][1])end
end
by-=1
end
end
end
function eyes_scene()local left_wall=brickwall(56,-40,-1,8)local right_wall=brickwall(64,168,1,4)local mons=monsters(10,69,37)
return function(t)bg(0)mons(t)stairs(left_wall(t),right_wall(t))end
end
function raycast(screen_x,origin,radius)local ray=v((screen_x-64)*0.0234,-1):norm()local dot=ray:dot(-origin)local s=radius^2+dot^2-#origin
if (s<0.0)return nil
s=sqrt(s)if dot<s and dot+s>=0 then
s=-s
end
return origin+ray*(dot-s)end
function monsters(n,cx,cy)local mons=each(rng(n),function()
return {mx=rndf(1,3),my=rndf(1,3),ox=rnd(),oy=rnd(),s=rndf(2,6),e=0,espr=rndpick(ob([[106,107,122,123,]]))
}
end)
return function(t)
t*=0.001
for m in all(mons)do
local x,y=
cos(m.mx*t+m.ox)*12,
sin(m.my*t+m.oy)*10
if m.e==0 then
if (rnd()<0.003)m.e=11
else
set_palette(abs(m.e-6))
spr(m.espr,cx+x,cy+y)
m.e-=0.125
end
end
set_palette()
end
end
function stairs(lst,rst,i)
while lst[i]do
if rst[i-2]then
local l,r=lst[i],rst[i-2]
ngon({l,r,r+v(0,5),l+v(0,5)},0)
line(l.x,l.y,r.x,r.y,1)
end
i-=1
end
end
function brickwall(sx,ex,dx,r)
local eye=v(-6,4)
local intersection={}
for x=sx,ex,dx do
local ip=raycast(x,eye,r)
if ip then
ip.a=atan2(ip.x,ip.y)
intersection[x]=ip
end
end
return function(t)
local steps,pstep,fstep={}
local tf=t*0.5%32
for screen_x=sx,ex,dx do
local ip=intersection[screen_x]
if ip then
local angle=ip.a
local tex_x=-angle*1200+tf
local z=eye.y-ip.y
if z<7.14 then
local step=flr(tex_x/16+42)
local h=72/z
local screen_y=24-h+z*1.5+abs(sin(tf/32))*2
local screen_h=h*2+(step-tf/16)*2
if screen_x>=0 and screen_x<=127 then
texcol(64,32,tex_x,7+(step-tf/16)*0.25,
screen_x,screen_y,screen_h,
z*0.7)
end
if step~=pstep then
steps[step]=v(screen_x,flr(screen_y+screen_h))
pstep,fstep=step,fstep or step
end
end
end
end
set_palette()
return steps,fstep
end
end
function texcol(tox,toy,tx,trep,
sx,sy,sh,plt)
local tsx,tsy=tox+band(tx,0xf),toy
local sreph=sh/trep
for rep=1,trep do
if sy+sreph>0 and sy<128 then
set_palette(plt+rnd(0.2))
sspr(tsx,tsy,1,8,
sx,sy,1,sreph+1)
tsy=toy+rep%2*8
end
sy+=sreph
end
local f=trep%1
if f>0 then
sspr(tsx,tsy,1,8*f+1,
sx,sy,1,sreph*f+1)
end
end
function icarus_scene()
local sun=circs(ob[[
o(x=0,y=0,r=9,clr=9),
o(x=0,y=0,r=8,clr=10),
o(x=0,y=0,r=6,clr=7),
]],0,0)local icarus=make_icarus()local clouds=moving_noise(40,10,0.05,1,0,0.3,ob[[
o(7,10),o(6,20),o(false,256),o(13,256),
]])local sink,map_x=0,0
return function(t)bg(12)for d=0,256,256 do
map(0,8,d-map_x,36+sink/5,32,5)end
sun(v(110,12+sink/5),1)clouds:render(3,inv_rectfill)draw_terrain(t*0.0293,150-sink*0.85,40,9.5,1.1,7.4)sink=icarus(t)draw_terrain(t*0.039125,150-sink,10,9,2.2,5.5)map_x=(map_x+0.1)%256
clouds:move(4)end
end
function inv_rectfill(x1,y1,x2,...)rectfill(127-x1,y1,127-x2,...)end
function make_icarus()local y_pos,fall_v,wings=0,0.02,1
local frm=ob([[128,130,130,130,132,132,132,132,132,130,134,160,162,164,164,164,164,164,162,162,160,160,]])
local gravity=ob([[1,2,2,2,3,3,3,3,3,2,1,-1,-4,-12,-8,-4,-3,-3,-2,-2,-1,0,]])
return function(t)
if wings==1 and rnd()<y_pos*0.06 then
wings=2
end
local ind=flr(max(wings,1))
spr(frm[ind],30,10+y_pos*10,2,2)
y_pos+=fall_v
fall_v+=gravity[ind]*0.001
if wings~=1 then
wings=wings%#frm+0.5
else
fall_v=min(fall_v,0.01)
end
fall_v=max(fall_v,-0.04)
return y_pos*8
end
end
function draw_terrain(t,horiz,x_base,z_base,slp,zs)
memset(0x1800,72,0x90)
set_palette(22)
local prev_h=0
local z,zstep=zs,0.18
x_base+=t
while z<8 do
local xstep,nz=z*0.0094,z
local sx,addr=-4,0x1800
local base_y,h_mul=horiz-z*z_base,8/z
for x=x_base-z*0.3-xstep*2,x_base+z*0.3,xstep do
local h=noise(x,nz)*0.08+sin(x)
local slope=mid(3+(h-prev_h)*slp,0,6)
local yproj=base_y-h*h_mul
local limit=peek(addr)
if yproj<limit then
rectfill(sx,yproj,sx+1,limit,slope)
poke(addr,yproj)
end
prev_h=h
sx+=2
addr+=1
end
z+=zstep
zstep+=0.015
end
local addr=0x1800
for sx=-4,127,2 do
rectfill(sx,peek(addr),sx+1,peek(addr),1)
addr+=1
end
set_palette()
end
ohpts=ob([[
v(0,5,0),
v(5,0,0),v(0,0,5),v(-5,0,0),v(0,0,-5),
v(0,-5,0),
]])ohfcs=ob([[
o(1,2,3,n=v(0.57,-0.57,0.57)),
o(1,3,4,n=v(-0.57,-0.57,0.57)),
o(1,4,5,n=v(-0.57,-0.57,-0.57)),
o(1,5,2,n=v(0.57,-0.57,-0.57)),
o(6,3,2,n=v(0.57,0.57,0.57)),
o(6,4,3,n=v(-0.57,0.57,0.57)),
o(6,5,4,n=v(-0.57,0.57,-0.57)),
o(6,2,5,n=v(0.57,0.57,-0.57)),
]])lpts=ob([[
v(0,0,0),
v(0,0,30),
]])lfcs=ob([[
o(1,2,n=v(0,0,-1)),
]])function asteroid_scene()local r3d=threed()local objects={}
local ship=smallship()
return function(t)
t*=0.001
if rnd()<0.6 then
local p=mav(210,rnd())add(objects,{pos=v(p.x*2,p.y*0.6,400),spd=rndf(6,10),model=new_model(ohpts,ohfcs,rndf(1,5)),rotates=true
})add(objects,{pos=v(-p.x*1.3,-p.y*0.4,400),spd=rndf(10,40),model=new_model(lpts,lfcs,rndf(0.2,2)),})end
bg(0)for k,ob in pairs(objects)do
local pos=ob.pos
pos.z-=ob.spd
if pos.z<3 then
del(objects,ob)else
if ob.rotates then
for _,pt in pairs(ob.model.points)do
rotate_vec(pt)end
end
for _,face in pairs(ob.model.faces)do
if (ob.rotates)rotate_vec(face.n)
local px,py=r3d.draw(face,pos)if abs(px)>74 or abs(py)>46 then
del(objects,ob)end
end
end
end
set_palette(22)r3d.render()set_palette()ship()end
end
function new_model(pts,fcs,scl)local points=each(pts,function(p)
return p*(rndf(1,1.3)*scl)end)local faces=each(fcs,function(f)
local face=each(f,function(i)return points[i]end)face.n=f.n*1
return face
end)
return {points=points,faces=faces
}
end
function rotate_vec(pt)local x,y,z=pt.x,pt.y,pt.z
pt.x,pt.y,pt.z=
0.9987*x-0.0493*y+0.0012*z,0.0493*x+0.9975*y-0.0493*z,0.0012*x+0.0493*y+0.9987*z
end
function threed()local faces={}
return {draw=function(face,off)local face_z=0
local projx,projy
local p={}
for i,pt in pairs(face)do
if i~="n" then
local x,y,z=pt.x+off.x,pt.y+off.y,(pt.z+off.z+1)
face_z+=z
local pz=z*0.04
projx,projy=x/pz,y/pz
p[i]={x=64+projx,y=36+projy}
else
if (pt.z>0)return 0,0
p.l=abs(pt.z)*5
end
end
p.l=max(0,p.l-face_z*0.003)if p[3]then
local x1,y1,x2,y2=
p[2].x-p[1].x,p[2].y-p[1].y,p[3].x-p[2].x,p[3].y-p[2].y
if (x1*y2-x2*y1<0)return 0,0
else
face_z=1500
end
face_z=flr(shr(face_z,3))
if (not faces[face_z])faces[face_z]={}
add(faces[face_z],p)
return projx,projy
end,render=function()for z=200,0,-1 do
for _,f in pairs(faces[z]or {})do
if f[3]then
ngon(f,f.l)else
line(f[1].x,f[1].y,f[2].x,f[2].y,0)end
end
end
faces={}
end
}
end
ssfrms=ob([[76,78,108,110,166,]])
function smallship()
local engine=circs(ob([[
o(x=0,y=3,r=4,clr=2),
o(x=0,y=2,r=2.5,clr=8),
o(x=0,y=1,r=2,clr=9),
o(x=0,y=0,r=1.5,clr=10),
]]),1)local pos,tilt=v(56,40),0
local tpos,ttilt=pos,tilt
local prob=0
return function(t)if rnd()<prob then
tpos=v(rndf(26,86),rndf(16,61))repeat
ttilt=rndf(-4.45,4.45)until round(ttilt)~=round(tilt)prob=0
else
prob+=0.001
end
tilt=lerp(tilt,ttilt,0.05)pos=lerp(pos,tpos,0.03)local frm=abs(round(tilt))spr(ssfrms[flr(frm+1)],pos.x,pos.y,2,2,tilt<0)engine(pos+v(6,8),1)end
end
function ski_scene()local slp=72/128
local skiv=v(4,4*slp)local front=hill(slp,36,4,7,0.5)local back=hill(slp,24,2,6,0.25)local b2=hill(slp,16,1,5,0.06)local snows=snow(4,slp)local bgpines=pines(v(2,2*slp),141,1,2,-9,20,0.14)local midpines=pines(skiv,142,2,3,-15,-5,0.08)local fgpines=pines(v(6,6*slp),142,2,3,24,60,0.12)local trails={}
for o in all({v(2,6),v(0,8)})do
add(trails,trail({6,6,6,7,7},16,skiv,o
))end
local sy=37
return function(t)bg(12)b2()local hy,piney=back()bgpines(piney)local py=sy
hy,piney=front()sy=lerp(sy,hy+16,0.3)local dy=sy-py
midpines(piney)snows()for t in all(trails)do
t(v(35,sy))end
spr(136,35,sy,3,2)spr(139,38,sy-dy/0.5,2,2)fgpines(piney)end
end
function hill(slp,cy,spd,c,hld)local y,iy={},cy-64*slp
local refy=cy+64*slp
for x=0,135 do
y[x]=iy+slp*x
end
local cslp,spring=slp
return function()for x=0,127 do
rectfill(x,y[x],x,71,c)y[x]=y[x+spd]-slp*spd
end
local rndd=
rndf(-0.01,0.01)+
(slp-cslp)*0.02*hld+
(refy-y[127])*0.001*hld
for x=128,128+spd do
y[x]=y[x-1]+cslp
cslp+=rndd/hld
end
return y[35],y[128]
end
end
function snow(spd,slp)local s={}
for x=0,127,2 do
add(s,{p=v(x,rnd(x*slp)),v=v(-spd+rndf(-0.2,0.2),-slp+rndf(-0.2,0.2))})end
return function()for _,s in pairs(s)do
if (s.pp)line(s.p.x,s.p.y,s.pp.x,s.pp.y,7)
s.pp=s.p+s.v*0.5
s.p+=s.v
s.v.x+=rndf(-0.01,0.01)
if s.p.y<0 then
s.p,s.pp=v(128+rnd(spd),rndf(0,84))s.v=v(-spd+rndf(-0.2,0.2),-slp*spd+rndf(-0.2,0.2))end
end
end
end
function pines(vel,sp,sw,sh,h,l,prob)local ps={}
return function(y)if rnd()<prob then
add(ps,{p=v(128,y+rndf(h,l)),v=vel+v(0,0)})end
for p in all(ps)do
spr(sp,p.p.x,p.p.y,sw,sh)
p.p-=p.v
if p.p.x<-5 then
del(ps,p)end
end
end
end
function trail(cs,l,d,o)local ps={}
return function(p)add(ps,{p=p,c=cs[flr(rnd(#cs)+1)]})if #ps>l then
del(ps,ps[1])end
for i=1,#ps-1 do
local a,b=ps[i].p+o,ps[i+1].p+o
line(a.x,a.y,b.x,b.y,ps[i].c)
ps[i].p-=d
end
end
end
function robot_scene()local bones=ob[[
o(p=-1,a=0.25,l=0),
o(p=1,a=0,l=13),
o(p=2,a=0.25,l=5),
o(p=2,a=-0.25,l=5),
o(p=3,a=0,l=7),
o(p=4,a=0,l=7),
o(p=1,a=0.35,l=4),
o(p=1,a=-0.35,l=4),
o(p=7,a=0.15,l=8),
o(p=8,a=-0.15,l=8),
o(p=5,a=0,l=6),
o(p=6,a=0,l=6),
o(p=2,a=0,l=5),
o(p=9,a=0,l=8),
o(p=10,a=0,l=8),
]]
local poses=ob[[
o(0),
o(0,0.1,0,0,
0.06,0.06,0.05,0.05,
-0.05,0.2,-0.125,0.125),
o(0,0,0,0,
0.25,-0.25,0,0,
0,0,0.2,-0.2,),
o(0,-0.1,0,0,
-0.06,-0.06,-0.05,-0.05,
0.05,-0.2,0.125,-0.125),
o(0),
o(0,0,0,0,
-0.25,0.25,0.05,-0.05,
-0.05,0.05,-0.25,0.25),
o(0,0,0,0,
0,0,0,0,
-0.2,0.2,-0.2,0.2,
0,0.1,-0.1,),
o(0,0,0,0,
0,0,0,0,
-0.2,0.2,0.2,-0.2,
0,0.1,-0.1,),
o(0),
o(0,-0.1,0,0,
-0.06,-0.06,-0.05,-0.05,
-0.2,0.05,0.125,-0.125),
o(0,0,0,0,
0.25,-0.25,0,0,
0,0,0.2,-0.2,),
o(0,0.1,0,0,
0.06,0.06,0.05,0.05,
0.2,-0.05,-0.125,0.125),
o(0),
o(0,0,0,0,
0.1,-0.1,-0.1,0.1,
-0.15,0.15,-0.2,0.2),
o(0,0,0,0,
-0.25,0.25,-0.1,0.1,
-0.15,0.15,0,0),
o(0,0,0,0,
0.3,-0.3,0,0,
-0.25,0.25,0.3,-0.3),
]]
local sprs=ob[[
o(b=13),
o(b=13,s=169,dy=12),
o(b=12,s=170),
o(b=11,s=168),
o(b=14,s=184),
o(b=15,s=184),
]]
local rbts=ob[[
o(d=v(-32,7),plt=2,f=185),
o(d=v(32,7),plt=2,f=185),
o(d=v(0,0),plt=0,f=185),
]]
local shadowed=ob[[5,6,14,15,]]
local current=ob[[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]]
local spds=set({},current)
local pi=1
local psw=1
return function(t,cam)
draw_dancefloor(pi%2+1)
local sw=stat(20)%8
if sw==0 and psw~=0 then
pi=pi%#poses+1
end
psw=sw
local k=0.02
for i=1,#current do
spds[i]+=((poses[pi][i]or 0)-current[i])*k
current[i]+=spds[i]
spds[i]*=0.88
end
local pts=bones_to_points(v(64,36),bones,current)
feet_plant(pts,62)
local sl,sr=127,0
for i in all(shadowed)do
local px=pts[i].p.x
if (px<sl)sl=px
if (px>sr)sr=px
end
for r in all(rbts)do
local c=r.d+cam
camera(c.x,c.y)
set_palette(r.plt)
rectfill(sl,60,sr,66,0)
spr(190,sl-8,59)
spr(191,sr,59)
ngon({pts[3].p,pts[4].p,pts[8].p,pts[7].p},5)
ngon({pts[1].p,pts[3].p,pts[4].p},13)
draw_bones(bones,pts)
for s in all(sprs)do
local ap=pts[s.b].p
spr(s.s or r.f,ap.x-4,ap.y-(s.dy or 4))
end
end
end
end
function bones_to_points(ctr,bs,pose)
local pts={}
for i=1,#bs do
local b=bs[i]
local parent=pts[b.p]or {p=ctr,a=0}
local ba=parent.a+b.a+pose[i]
pts[i]={
p=parent.p+mav(b.l,ba),
a=ba
}
end
return pts
end
bloffs=ob[[
o(d=v(1,0),c=5),
o(d=v(0,1),c=5),
o(d=v(-1,0),c=13),
o(d=v(0,-1),c=6),
o(d=v(0,0),c=13),
]]
function draw_bones(bs,pts)for i=3,#bs do
local f,t=pts[bs[i].p].p,pts[i].p
for o in all(bloffs)do
line(f.x+o.d.x,f.y+o.d.y,t.x+o.d.x,t.y+o.d.y,o.c)end
end
end
function feet_plant(pts,y)local cy=max(pts[14].p.y,pts[15].p.y)local d=v(0,y-cy)for p in all(pts)do
p.p+=d
end
end
function draw_dancefloor(c)for z=2,0,-0.25 do
for x=-200,216,16 do
floorline(x,36,z,x,36,z-0.2,c)floorline(x,36,z,x+14,36,z,c)c=c%2+1
end
end
end
function floorline(x1,y1,z1,x2,y2,z2,c)local xs1=64+x1/(z1+1)local ys1=30+y1/(z1+1)local xs2=64+x2/(z2+1)local ys2=30+y2/(z2+1)line(xs1,ys1-1,xs2,ys2-1,0)line(xs1,ys1,xs2,ys2,c)line(xs1,ys1+1,xs2,ys2+1,c)pset(xs1-1,ys1,0)end
function title_scene()local n1=moving_noise(58,1,0.05,0.1,-0.01,1,ob([[o(2,50),o(2,100),o(1,150),o(f,256),o(13,256),]])
)
local n2=moving_noise(
58,6,0.05,0.1,-0.01,1,
ob([[o(2,50),o(2,100),o(1,150),o(f,256),o(13,256),]])
)
local n3=moving_noise(
36,11,0.05,0.2,-0.012,1,
ob([[o(5,170),o(f,256),o(5,256),]])
)
local n4=moving_noise(
36,16,0.05,0.2,-0.012,1,
ob([[o(5,170),o(f,256),o(5,256),]])
)
local texts=ob[[
o("music:",32,25,9,0),
o("@gruber_music",96,31,15,1),
o("cover art:",32,39,9,0),
o("@castpixel",96,45,15,1),
o("odds and ends:",32,53,9,0),
o("@krajzeg",96,59,15,1),
o("⬅️ ➡️               ",64,91,13,0.5),
o("  /   switch songs",64,91,5,0.5),
]]
local logo=ob[[
o(3,44,-13,1,3),
o(4,76,-13,1,3),
o(45,52,-13,3,2),
o(171,52,3,3,2),
]]
return function(t)n1:move(1)n2:move(2)n3:move(1)n4:move(1)n1:render(0,inv_rectfill)n2:render(0,dinv_rectfill)set_palette(14)n3:render(0,lrect)n4:render(0,ilrect)set_palette(6)clip()for l in all(logo)do
call(spr,l)end
set_palette()for t in all(texts)do
call(printsh,t)end
end
end
function dinv_rectfill(x1,y1,x2,y2,c)rectfill(127-x1,75-y1,127-x2,75-y2,c)end
function lrect(x2,y1,x1)local d=band(x1,1)local addr=0x6400+shl(y1,6)+band(shr(x1,1),0xffff)local len=band(shr(x2-x1,1),0xffff)+2
memcpy(0x1800,addr,len)sspr(d,96,x2-x1+1,1,x1,y1)end
function ilrect(x2,y1,x1)y1=75-y1
local d=band(x1,1)local addr=0x6400+shl(y1,6)+band(shr(x1,1),0xffff)local len=band(shr(x2-x1,1),0xffff)+2
memcpy(0x1800,addr,len)sspr(d,96,x2-x1+1,1,x1,y1)end
selector=object:extend({pos=1,tgt=1
})function selector:update()self.pos=lerp(self.pos,self.tgt,0.2)if abs(self.tgt-self.pos)<0.005 then
self.pos=self.tgt
end
for btn=0,1 do
if (btnp(btn))self:switch_to(self.tgt+btn*2-1)
end
end
function selector:switch_to(p)p=(p-1)%#screens+1
self.tgt=p
music(screens[p].pat)end
function selector:render()local pos=self.pos
local pi,pf=flr(pos),pos-flr(pos)local left,right=
screens[pi],screens[pi%#screens+1]
local off=flr(-pf*256)local pane_cam=v(-cam.x-off,-cam.y)camera(pane_cam.x,pane_cam.y)clip(off,cam.y,128,72)if off>-128 then
left.fn(t,pane_cam)end
pane_cam.x-=256
camera(pane_cam.x,pane_cam.y)clip(off+256,cam.y,128,72)if off<=-128 then
right.fn(t,pane_cam)end
clip()camera()if pf~=0 then
scene_label(128,pf*128,167-pf*60,right.name)end
scene_label(0,pf*128,107+pf*60,left.name)end
function scene_label(x,dx,dy,name)
if (not name)return
rectfill(16+x-dx,108,111+x-dx,110,1)printsh(name,64,dy,6,0.5)end
function empty_scene(c)
return function(t)bg(c)end
end
cam=v(0,16)function _init()init_palettes(32)init_noise()local scenes=ob([[
o(name=f,pat=63),
o(name="1. into the belt",pat=6),
o(name="2. need for speed",pat=56),
o(name="3. like clockwork",pat=21),
o(name="4. morning shower",pat=0),
o(name="5. robot dance",pat=31),
o(name="6. eyes in the dark",pat=43),
o(name="7. flight of icarus",pat=49),
o(name="8. fickle flame",pat=40),
o(name="9. autumn wind",pat=39),
o(name="10. dimensional gate",pat=13),
]])local fns={title_scene(),asteroid_scene(),ski_scene(),clockwork_scene(),waterfall_scene(),robot_scene(),eyes_scene(),icarus_scene(),flame_scene(),autumn_scene(0.4),gate_scene(),}
screens=each(scenes,function(s,i)s.fn = fns[i]
return s
end)sel=selector()sel:switch_to(1)end
t=0
function _update60()
t+=1
sel:update()end
function _draw()cls()rectfill(0,cam.y-2,127,cam.y-2,1)rectfill(0,cam.y+73,127,cam.y+73,1)sel:render()camera()clip()end