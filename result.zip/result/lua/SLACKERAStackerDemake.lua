-- slacker v1.2
-- by paul nicholas

-- global vars
scene=0
mt = {}
player = {}
screenwidth = 127
screenheight = 127
anim = {}
anim.playing = false
anim.current_anim = 0 --none
fonts = {}
prize = {}
prizeselect = {}


-- game loop -------------------
function _init()
 fonts_init()
 create_matrix()
 prizes_init()

 if scene==0 then
  title_init()
 elseif scene==1 then
  game_init()
 elseif scene==2 then
  prizeselect_init()
 end
end

function _update60()
	if scene==0 then
  -- title/attract
  title_update()
  anim_update()
 elseif (scene == 1) then
  -- game
  if (not anim.playing) then
	 	game_update()
	 else
	  anim_update()
	 end
 elseif (scene == 2) then
  -- prize select
  if (not anim.playing) then
   prizeselect_update()
  else
   anim_update()
  end
	end
end

-- fix for bug in v0.1.8 html
function _update()
 _update60()
 _update_buttons()
 _update60()
end


function _draw()
 if scene==0 then
  title_draw()
 elseif scene==1 then
  game_draw()
 elseif scene==2 then
  prizeselect_draw()
 end
end

-- init functions ---------------------------
function title_init()
	play_anim_attract()
end

function game_init()
	clear_matrix()

	player.lpos  = 4 --"1-indexed"
	player.lives = 3
	player.level = 1
	player.dir = -1 -- +ve=right
	player.speedcounter = 0
	player.lostlifepos = {0,0,0}
end

function prizeselect_init()
 clear_matrix()

 prizeselect.dir = 1
 prizeselect.lpos = 3
 prizeselect.dist = 3
 prizeselect.speedcounter = 1
 prizeselect.frame = 1
 prizeselect.pause = true
 prizeselect.selected = 0
 prizeselect.prizenum = 0

 find_next_prize()
 update_prizeselector(true)
end

function find_next_prize()
 -- loop until we find an available prize
 prize_found=false
 infinity_check=0
 while (not prize_found and infinity_check<2) do
  prizeselect.prizenum+=1
  if (prizeselect.prizenum>4) then
   prizeselect.prizenum=1
   infinity_check+=1
  end

  if (prize[prizeselect.prizenum].visible) then
   prize_found=true
  end
 end

 if (prize_found) then
  if (prizeselect.prizenum==1) then
   prizeselect.lpos=3
   prizeselect.dir = 1
  elseif (prizeselect.prizenum==2) then
   prizeselect.lpos=7
   prizeselect.dir = -1
  elseif (prizeselect.prizenum==3) then
   prizeselect.lpos=3
   prizeselect.dir = 1
  elseif (prizeselect.prizenum==4) then
   prizeselect.lpos=7
   prizeselect.dir = -1
  end
 else
  prizeselect.prizenum=0
 end
end

function create_matrix()
 for r=1,15 do
  mt[r] = {}  -- create a new row
  for c=1,11 do
   mt[r][c] = 0
  end
 end
end

function clear_matrix()
 for r=1,15 do
  for c=1,11 do
   mt[r][c] = 0
  end
 end
end

function win_matrix()
 mt[1] ={0,0,0,0,0,0,0,0,0,0,0}
 mt[2] ={0,0,0,1,0,0,0,1,0,0,0}
 mt[3] ={0,0,0,1,0,1,0,1,0,0,0}
 mt[4] ={0,0,0,1,1,0,1,1,0,0,0}
 mt[5] ={0,0,0,1,0,0,0,1,0,0,0}
 mt[6] ={0,0,0,0,0,0,0,0,0,0,0}
 mt[7] ={0,0,0,0,0,1,0,0,0,0,0}
 mt[8] ={0,0,0,0,0,1,0,0,0,0,0}
 mt[9] ={0,0,0,0,0,1,0,0,0,0,0}
 mt[10]={0,0,0,0,0,1,0,0,0,0,0}
 mt[11]={0,0,0,0,0,0,0,0,0,0,0}
 mt[12]={0,0,0,1,0,1,1,0,0,0,0}
 mt[13]={0,0,0,1,1,0,0,1,0,0,0}
 mt[14]={0,0,0,1,0,0,0,1,0,0,0}
 mt[15]={0,0,0,1,0,0,0,1,0,0,0}
end

-- update functions -------------------------
function title_update()
	if (btnp(4) or btnp(5)) then
		-- start game
		stop_anim()
	 game_init()
  scene=1

  --prizeselect_init()
  --scene=2 --debug!!!!
	end
end

function game_update()
  btnpressed = player_control()
  if (not btnpressed) then
   update_player()
   player_draw()
  end
end

function prizeselect_update()
 -- only update until a selection is made
 if (prizeselect.selected == 0) then
  if (btnp(4) or btnp(5)) then
   -- select prize
   prizeselect.selected = prizeselect.prizenum
   -- animate dropping prize
   sfx(4,3)
   play_anim_prizedrop()
  else
   if (((not prizeselect.pause) and prizeselect.speedcounter<5)
    or ((prizeselect.pause) and prizeselect.speedcounter<30)) then
    prizeselect.speedcounter+=1
    return
   else
    prizeselect.speedcounter=1
    prizeselect.pause = false
   end
   update_prizeselector(false)
  end
 end
end

-- animations ------------------
--[[
 0 = none
 1 = title/attract
 2 = lost life
 3 = game over
 4 = win (all prizes gone)
 5 = level up (pause)
 6 = crumble
 7 = prize line (win)
 8 = prize drop
 --]]
function anim_update()
	if (anim.current_anim == 1) then
		--=============--
		-- attract mode
		--=============--
  if (anim.delay<5) then
   anim.delay+=1
   return
  else
   anim.delay=1
  end

	 clear_matrix()

	 rpos=anim.frame

  for chr=1,#fonts.title do
   l=sub(fonts.title,chr,chr)
   draw_letter(l,rpos,5)
   rpos+=6
  end

		anim.frame-=1
		if (anim.frame<-(#fonts.title*6)) then
		 anim.frame=16
		end



	elseif (anim.current_anim == 2) then
	 --=============--
	 -- lost life
	 --=============--
	 if (anim.seq==1) then
	  -- oh-shit moment! ------
	  if (anim.delay<20) then
	   anim.delay+=1
	   return
	  end
	  -- change to fall
 		 anim.seq+=1
 		 anim.frame=0
	 elseif (anim.seq==2) then
	  -- falling block(s) -----
	  if (anim.delay<5) then
	   anim.delay+=1
	   return
	  else
	   anim.delay=1
	  end

	  all_landed=true
	 	for b in all(anim.falling) do
 		 if (not b.landed) then
 	   -- move block(s) sprite down
 		  mt[15-b.row][b.col]=0
 		  mt[15-(b.row-1)][b.col]=1
 		  -- move ref down
 		  b.row-=1
 		  all_landed=false
 		  -- check for floor
 		  if ((b.row>=1 and mt[15-(b.row-1)][b.col]==1)
 		   or (b.row==0)) then
 		 	 -- block hit floor
 		 	 b.landed=true
 		  end
 		 end
 		end
 		if (all_landed) then
 		 -- change to flash
 		 anim.seq+=1
 		 anim.frame=0
 		end
	 elseif (anim.seq==3) then
	 	-- flash block(s) -------
	 	if (anim.delay<12) then
	 	 -- skip this cycle
	   anim.delay+=1
	   return
	  end

	  -- toggle display state
	  anim.flash_on=not anim.flash_on
	  anim.delay=1
	  for b in all(anim.falling) do
	   numval =(anim.flash_on and 1 or 0)
	   mt[15-b.row][b.col]=numval
	  end

	  anim.flash_count+=1
	  if (anim.flash_count > 7) then
	   -- done
    level_up()
	  end
	 else
	  -- anim complete
	 end
	 -- move anim on a frame
  anim.frame+=1

 elseif (anim.current_anim == 3) then
	 --=============--
	 -- game over
	 --=============--
	 if (anim.seq==1) then
	  -- oh-shit moment! ------
	  if (anim.delay<40) then
	   anim.delay+=1
	   return
	  end
	  -- change to fall
 		 anim.seq+=1
 		 anim.frame=0
 	elseif (anim.seq==2) then
	 	-- flash block(s) -------
	 	if (anim.delay<12) then
	 	 -- skip this cycle
	   anim.delay+=1
	   return
	  end

	  -- toggle display state
	  anim.flash_on=not anim.flash_on
	  anim.delay=1
	  for b in all(anim.falling) do
	   numval =(anim.flash_on and 1 or 0)
	   mt[15-(b.row-1)][b.col]=numval
	  end

	  anim.flash_count+=1
	  if (anim.flash_count > 7) then
	   -- anim complete

	   -- todo: play "fall" clear matrix
	   game_over()
	  end
	 end
	 -- move anim on a frame
  anim.frame+=1


 elseif (anim.current_anim == 4) then
  --=============--
  -- game win
  --=============--
  if (anim.delay<5) then
   anim.delay+=1
   return
  else
   anim.delay=1
  end

  clear_matrix()

  rpos=anim.frame

  for chr=1,#fonts.win do
   l=sub(fonts.win,chr,chr)
   draw_letter(l,rpos,5)
   rpos+=6
  end

  anim.frame-=1
  if (anim.frame<-(#fonts.win*6)) then
   anim.frame=16
  end

 elseif (anim.current_anim == 5) then
  --=============--
  -- level up (delay)
  --=============--
  if (anim.delay<40) then
   -- skip this cycle
   anim.delay+=1
   return
  end
  level_up()

 elseif (anim.current_anim == 6) then
  --=============--
  -- crumble anim
  --=============--
   -- have we selected a block yet?
  if (anim.falling.col == 0) then
   -- have we analysed row yet?
   if (#anim.rowdata==0) then
    -- > go through curr row
    msg=""
    for b in all(mt[anim.row]) do
     msg=msg..b..","
    end

    for c=1,11 do
     if (mt[anim.row][c]==1) then
      -- > note col pos of all 1's
      add(anim.rowdata,c)
     end
    end

    if (#anim.rowdata==0) then
     -- no more blocks,
     -- go to title
     title_init()
     scene=0
     return
    end
   end

   -- > use rnd to select from array
   anim.falling.rndidx=flr(rnd(#anim.rowdata))+1
   anim.falling.col=anim.rowdata[anim.falling.rndidx]
   anim.falling.row=anim.row
   anim.falling.landed=false
  end

  -- > animate the block offscreen
  --
  if (not anim.falling.landed) then
   -- move block(s) sprite down
   mt[anim.falling.row][anim.falling.col]=0
   if (anim.falling.row+1<=15) then
    mt[anim.falling.row+1][anim.falling.col]=1
   end
   -- move ref down
   anim.falling.row+=1
   -- check for floor
   if (anim.falling.row>15) then
    -- hit floor, move up row
    anim.falling.landed=true
    anim.falling.col=0
    anim.falling.row=0

    anim.rowdata[anim.falling.rndidx]=-1
    del(anim.rowdata,-1)
    --
    if (#anim.rowdata==0) then
     anim.row-=1
     if (anim.row<1) then
      -- go to title
      scene=0
      title_init()
     end
    else
     -- pick new block
     anim.falling.rndidx=flr(rnd(#anim.rowdata))+1
     anim.falling.col=anim.rowdata[anim.falling.rndidx]
     anim.falling.row=anim.row
     anim.falling.landed=false
    end
   end
  end

 elseif (anim.current_anim == 7) then
  --=============--
  -- prize (line)
  --=============--
  if (anim.delay<30) then
   -- skip this cycle
   anim.delay+=1
   return
  else
   anim.delay=1
  end

  -- alternate flashing
  anim.flashing = not anim.flashing
  -- winner?
  if (anim.major) then
   clear_matrix()
   if (not anim.flashing) then
    win_matrix()
   end
  end
  -- draw line?
  for c=1,11 do
   if (anim.flashing
   and anim.frame>0) then
    mt[15-(player.level-1)][c]=1
   else
    mt[15-(player.level-1)][c]=0
   end
  end

  anim.frame+=1
  if (anim.frame>7) then
   -- restore pos
   player_draw()
   level_up()
  end
 elseif (anim.current_anim == 8) then
  --=============--
  -- prize drop
  --=============--
  -- prize is falling
  prize[prizeselect.prizenum].y+=2
  if (prize[prizeselect.prizenum].y > 130
   and prize[prizeselect.prizenum].y < 150) then
   -- prize hit floor
   prize[prizeselect.prizenum].visible = false
   -- screen shake
   shake_camera()

   -- todo: show prize message?

  elseif (prize[prizeselect.prizenum].y > 150) then
   -- stop shake
   reset_camera()
   -- any prizes left?
   prizeselect.prizenum=0
   find_next_prize()
   if (prizeselect.prizenum>0) then
    -- go to title/attract screen
    prizeselect.prizenum=0
    stop_anim()
    title_init()
    scene=0
   else
    -- go to game over (all prizes gone!)
    play_anim_win()
   end
  end
 end
end


function update_player()
	-- auto-move player
 move=false

	player.speedcounter += 1
	if player.level <= 3
		and player.speedcounter > 7 then
	  move = true
 elseif player.level > 3
 	and player.level <= 6
 	and player.speedcounter > 6 then
   if (player.lives > 2) then
 		 player.lives = 2
 		end
 		move = true
 elseif player.level > 6
 	and player.level <= 9
 	and player.speedcounter > 5 then
 		move = true
 elseif player.level > 9
 	and player.level <= 12
 	and player.speedcounter > 4 then
 		if (player.lives > 1) then
 		 player.lives = 1
 		end
 		move = true
 elseif player.level > 12
 	and player.level <= 15
 	and player.speedcounter > 3 then
 		move = true
 end

 if move then
		player.lpos += player.dir

  -- >>>> right
  if (player.dir == 1) then--6,9
   if (player.lpos+player.lives-1 == 6) then
    sfx(11,0)
   elseif (player.lpos+player.lives-1 == 8) then
    sfx(12,0)
   elseif (player.lpos+player.lives-1 == 10) then
    sfx(13,2)
   end
  -- <<<< left
  else  --6,3
   if (player.lpos == 6) then
    sfx(11,1)
   elseif (player.lpos == 4) then
    sfx(12,1)
   elseif (player.lpos == 2) then
    sfx(14,3)
   end
  end

		-- left edge check
		if (player.lives == 3) then
		 if (player.lpos < 1) then
				player.lpos = 1+1
				player.dir = 1
    --sfx(13,2)
			end
		elseif (player.lives == 2) then
			if (player.lpos < 2) then
				player.lpos = 2+1
				player.dir = 1
    --sfx(13,2)
			end
		else
			if (player.lpos < 3) then
				player.lpos = 3+1
				player.dir = 1
    --sfx(13,2)
			end
		end
		-- right edge check
		if (player.lives == 3) then
			if (player.lpos > 9) then
				player.lpos = 9-1
				player.dir = -1
    --sfx(14,3)
			end
		elseif (player.lives == 2) then
			if (player.lpos+player.lives-1 > 10) then
				player.lpos = 10-1
				player.dir = -1
    --sfx(14,3)
			end
		else
			if (player.lpos+player.lives-1 > 9) then
				player.lpos = 9-1
				player.dir = -1
    --sfx(14,3)
			end
		end
		player.speedcounter = 0
	else
	 -- do nothing
	 -- (skip move this frame)
	end
--	]]--
end


function level_up()
 stop_anim()
 player.lostlifepos = {0,0,0}
 player.level += 1
 if (player.level > 15) then
  -- winner!!
  player.level = 15
  game_win()
 else
  -- randomise pos/dir
  player.lpos = flr(rnd(11))
  player.dir = flr(rnd(2))
  if (player.dir>1) then
   player.dir = 1
  else
   player.dir = -1
  end
  update_player() --fix layer pos
  player_draw()
 end
end

function game_win()
 -- move to "select prize" scene...
 stop_anim()
 prizeselect_init()
 scene=2
end

function game_over()
 --stop_anim()
	play_anim_crumble()
end

function update_prizeselector(init)
 -- animate selector
 if (not init) then
  prizeselect.lpos += prizeselect.dir
 end

 -- left edge check
 if (prizeselect.dir < 0 and prizeselect.lpos < 3) then
  prizeselect.lpos = 3
  prizeselect.dir = 1
  prizeselect.frame+=1
  prizeselect.pause = true
 end
 -- right edge check
 if (prizeselect.dir > 0 and prizeselect.lpos > 7) then
  prizeselect.lpos = 7
  prizeselect.dir = -1
  prizeselect.frame+=1
  prizeselect.pause = true
 end
 -- move-distance-checks
 if (prizeselect.prizenum==1 or prizeselect.prizenum==3) then
  if (prizeselect.lpos > 1+prizeselect.dist) then
   prizeselect.dir = -1
  end
 else
  if (prizeselect.lpos < 9-prizeselect.dist) then
   prizeselect.dir = 1
  end
 end

 if (prizeselect.frame>=4 and (not prizeselect.pause)) then
  prizeselect.frame=1
  -- move to next available prize
  find_next_prize()
  prizeselect.pause=true
  update_prizeselector(true)
  return
 end

 -- "draw" position
 clear_matrix()
 if (prizeselect.prizenum==1) then
  draw_letter("<",2,prizeselect.lpos)
 elseif (prizeselect.prizenum==2) then
  draw_letter(">",2,prizeselect.lpos)
 elseif (prizeselect.prizenum==3) then
  draw_letter("<",9,prizeselect.lpos)
 elseif (prizeselect.prizenum==4) then
  draw_letter(">",9,prizeselect.lpos)
 end
end

-- draw functions -------------------------
function title_draw()
 cls()
 draw_matrix()
 draw_map()
 draw_prizes()
 --draw_debug()
end

function game_draw()
 cls()
 --rectfill(35,10,90,120,1)
 draw_matrix()
 draw_map()
 draw_prizes()
 --draw_debug()
end

function prizeselect_draw()
 cls()
 draw_matrix()
 draw_map()
 draw_prizes()
 --draw_debug()
end

function player_draw()
 -- set players current pos in matrix
 for c=1,11 do
  mt[15-player.level+1][c]=0
 end

 for p=0,player.lives-1 do
  if (player.lpos+p >= 3)
   and (player.lpos+p <= 9) then
   mt[15-player.level+1][player.lpos+p]=1
  end
 end
end

function draw_map()
 palt(0, true)
 palt(4, false)
 map(0,0,0,0,16,16)
end

function draw_matrix()
--	spr(18,39,11)  -- top-left
--	spr(18,81,11)  -- top-right
--	spr(18,39,109) -- bottom-left
--	spr(18,81,109) -- bottom-right
	y=11
	for r=1,15 do
		x=39
		for c=3,9 do --draw less!
			if (mt[r][c] == 1) then
				spr(18,x,y)
			end
			x+=7
		end
		y+=7
	end
end

-- draw sprites
function draw_prizes()
 palt(0, false)
 palt(4, true)

 -- prize holders
 if (prizeselect.prizenum==1 and prizeselect.pause) then
  spr(30,12,27)
 else
  spr(29,12,27)
 end
 if (prizeselect.prizenum==2 and prizeselect.pause) then
  spr(30,108,27)
 else
  spr(29,108,27)
 end
 if (prizeselect.prizenum==3 and prizeselect.pause) then
  spr(30,12,75)
 else
  spr(29,12,75)
 end
 if (prizeselect.prizenum==4 and prizeselect.pause) then
  spr(30,108,75)
 else
  spr(29,108,75)
 end

 -- prizes
 if (prize[3].visible) then
  spr(144,prize[3].x,prize[3].y)
  spr(145,prize[3].x+8,prize[3].y)
  spr(146,prize[3].x+16,prize[3].y)
  spr(147,prize[3].x+24,prize[3].y)

  spr(160,prize[3].x,prize[3].y+8)
  spr(161,prize[3].x+8,prize[3].y+8)
  spr(162,prize[3].x+16,prize[3].y+8)
  spr(163,prize[3].x+24,prize[3].y+8)

  spr(176,prize[3].x,prize[3].y+16)
  spr(177,prize[3].x+8,prize[3].y+16)
  spr(178,prize[3].x+16,prize[3].y+16)
  spr(179,prize[3].x+24,prize[3].y+16)
 end
 if (prize[4].visible) then
  spr(156,prize[4].x,prize[4].y)
  spr(157,prize[4].x+8,prize[4].y)
  spr(158,prize[4].x+16,prize[4].y)
  spr(159,prize[4].x+24,prize[4].y)

  spr(172,prize[4].x,prize[4].y+8)
  spr(173,prize[4].x+8,prize[4].y+8)
  spr(174,prize[4].x+16,prize[4].y+8)
  spr(175,prize[4].x+24,prize[4].y+8)

  spr(188,prize[4].x,prize[4].y+16)
  spr(189,prize[4].x+8,prize[4].y+16)
  spr(190,prize[4].x+16,prize[4].y+16)
  spr(191,prize[4].x+24,prize[4].y+16)
 end
 if (prize[1].visible) then
  spr(48,prize[1].x,prize[1].y)
  spr(49,prize[1].x+8,prize[1].y)
  spr(50,prize[1].x+16,prize[1].y)
  spr(51,prize[1].x+24,prize[1].y)

  spr(64,prize[1].x,prize[1].y+8)
  spr(65,prize[1].x+8,prize[1].y+8)
  spr(66,prize[1].x+16,prize[1].y+8)
  spr(67,prize[1].x+24,prize[1].y+8)

  spr(80,prize[1].x,prize[1].y+16)
  spr(81,prize[1].x+8,prize[1].y+16)
  spr(82,prize[1].x+16,prize[1].y+16)
  spr(83,prize[1].x+24,prize[1].y+16)
 end
 if (prize[2].visible) then
  spr(60,prize[2].x,prize[2].y)
  spr(61,prize[2].x+8,prize[2].y)
  spr(62,prize[2].x+16,prize[2].y)
  spr(63,prize[2].x+24,prize[2].y)

  spr(76,prize[2].x,prize[2].y+8)
  spr(77,prize[2].x+8,prize[2].y+8)
  spr(78,prize[2].x+16,prize[2].y+8)
  spr(79,prize[2].x+24,prize[2].y+8)

  spr(92,prize[2].x,prize[2].y+16)
  spr(93,prize[2].x+8,prize[2].y+16)
  spr(94,prize[2].x+16,prize[2].y+16)
  spr(95,prize[2].x+24,prize[2].y+16)
 end
end



function draw_letter(letter, row, col) -- top-left coordinates
  for r=1,5 do
   for c=1,5 do
    if (row+(r-1)>0)
    and (row+(r-1)<16) then
     mt[row+(r-1)][col+(c-1)]=fonts[letter][r][c]
    else
     -- off screen
    end
   end
  end
end

function shake_camera()
 sx=flr(rnd(8))-4
 sy=flr(rnd(8))-4
 camera(sx,sy)
end

function reset_camera()
 camera(0,0)
end

-- animations ------------------
--[[
 0 = none
 1 = title/attract
 2 = lost life
 3 = game over
 4 = -win (not used)
 5 = level up (pause)
 6 = crumble
 7 = prize line (win?)
 8 = prize drop
 --]]

function play_anim_attract()
 -- "press to start"
 anim.playing = true
 anim.current_anim = 1
 anim.delay=1
 anim.frame=16
 clear_matrix()
end

function play_anim_levelup()
 anim.playing = true
 anim.current_anim = 5
 anim.frame=1 --used for timing
 anim.delay=1 --anim speed
end

function play_anim_lostlife()
 -- animate lost block(s) falling
 anim.playing = true
 anim.current_anim = 2
 anim.falling={}
 anim.seq=1 --1=pause,2=fall,3=flash
 anim.frame=1 --used for timing
 anim.delay=1 --anim speed
 anim.flash_on=true
 anim.flash_count=1
 sfx(-1,0)
 sfx(-1,1)
 sfx(01,2)

 count=1
 for l in all(player.lostlifepos) do
   if (l>0) then
  	 anim.falling[count]={}
  	 anim.falling[count].col=l
 	  anim.falling[count].row=player.level
 	  count += 1
 	 end
 end
end

function play_anim_win()
 -- "win"
 anim.playing = true
 anim.current_anim = 4
 anim.delay=1
 anim.frame=16
 clear_matrix()
end

function play_anim_gameover()
 -- animate lost block(s) falling
 anim.playing = true
 anim.current_anim = 3
 anim.falling={}
 anim.seq=1 --1=pause,2=flash
 anim.frame=1 --used for timing
 anim.delay=1 --anim speed
 anim.flash_on=true
 anim.flash_count=1
 sfx(-1,0)
 sfx(-1,1)
 sfx(01,2)

 count=1
 for l in all(player.lostlifepos) do
   if (l>0) then
  	 anim.falling[count]={}
  	 anim.falling[count].col=l
 	  anim.falling[count].row=player.level
 	  count += 1
 	 end
 end
end

function play_anim_crumble()
	-- animate block(s) falling randomly
 anim.playing = true
 anim.current_anim = 6
 anim.row=15
 anim.falling={}
 anim.falling.landed=true
 anim.falling.col=0
 anim.falling.row=0
 anim.rowdata={}
 anim.frame=1 --used for timing
 anim.delay=1 --anim speed
 sfx(02,0)
end

function play_anim_prize(major)
 anim.playing = true
 anim.current_anim = 7
 anim.frame=1 --used for timing
 anim.delay=1 --anim speed
 anim.major = major
 anim.flashing = false
end

function play_anim_prizedrop()
 anim.playing = true
 anim.current_anim = 8
 anim.delay=1 --anim speed
end


function stop_anim()
 anim.playing = false
 anim.current_anim = 0 --none
end


-- handle button inputs ---------------------
function player_control()
	if (btnp(4)) or (btnp(5)) then
	 res = check_drop()
	 if (res == 0) then
			-- perfect
   sfx(-1,0)
   sfx(-1,1)
   sfx(00,2)
   if (player.level == 11) then
    play_anim_prize(false)
   elseif (player.level == 15) then
    play_anim_prize(true)
    sfx(03,3)
   else
    play_anim_levelup() --add delay
   end
	 elseif (res<0) then
	  player.lives += res
	  if (player.lives>0) then
	   -- life lost
	 	 play_anim_lostlife()
   else
    -- game over
    play_anim_gameover()
		 end
		end

  -- button pressed
  return true
 else
  -- nothing pressed
  return false
	end
end

-- collision check
-- (returns lives lost)
function check_drop()
 lostlives=0
 if (player.level==1) then
 	-- give pass at level 1
 else
  for p=0,player.lives-1 do
	   if (mt[15-player.level+2][player.lpos+p]==0) then
			  player.lostlifepos[p+1]=player.lpos+p
			  lostlives -= 1
			 end
 	end
 end
 return lostlives
end

--[[
-- debug code
function draw_debug()
 print("mem:"..stat(0),18,2,8)
 print("cpu:"..stat(1),18,8,8)

 msg=""
 for v in all(mt[15-player.level]) do
 	 msg=msg..v..","
 end
 print("row:"..msg,18,14,8)
 print("level:"..player.level,18,20,8)
end
]]--

function prizes_init()
 -- init prize states

 -- psp
 prize[1] = {}
 prize[1].name = "sony psp"
 prize[1].visible = true
 prize[1].x = 0
 prize[1].y = 32

 prize[2] = {} -- ipod
 prize[2].name = "ipod classic"
 prize[2].visible = true
 prize[2].x = 96
 prize[2].y = 32

 prize[3] = {} -- pi
 prize[3].name = "raspberry pi"
 prize[3].visible = true
 prize[3].x = 0
 prize[3].y = 80

 prize[4] = {} -- wii
 prize[4].name = "nintendo wii"
 prize[4].visible = true
 prize[4].x = 96
 prize[4].y = 80

end

function fonts_init()
 fonts.title = "slacker - press to start"
 fonts.win   = "no more prizes - game over"

 fonts[" "]={{0,0,0},
             {0,0,0},
             {0,0,0},
             {0,0,0},
             {0,0,0}}

 fonts["-"]={{0,0,0},
             {0,1,0},
             {1,1,1},
             {0,1,0},
             {0,0,0}}

 fonts["<"]={{0,0,1},
             {0,1,0},
             {1,0,0},
             {0,1,0},
             {0,0,1}}

 fonts[">"]={{1,0,0},
             {0,1,0},
             {0,0,1},
             {0,1,0},
             {1,0,0}}

 fonts.a ={{1,1,1},
           {1,0,1},
           {1,1,1},
           {1,0,1},
           {1,0,1}}

 fonts.b ={{1,1,1},
           {1,0,1},
           {1,1,0},
           {1,0,1},
           {1,1,1}}

 fonts.c ={{0,1,1},
           {1,0,0},
           {1,0,0},
           {1,0,0},
           {0,1,1}}

 fonts.d ={{1,1,0},
           {1,0,1},
           {1,0,1},
           {1,0,1},
           {1,1,1}}

 fonts.e ={{1,1,1},
           {1,0,0},
           {1,1,0},
           {1,0,0},
           {1,1,1}}

 fonts.f ={{1,1,1},
           {1,0,0},
           {1,1,0},
           {1,0,0},
           {1,0,0}}

 fonts.g ={{0,1,1},
           {1,0,0},
           {1,0,0},
           {1,0,1},
           {1,1,1}}

 fonts.h ={{1,0,1},
           {1,0,1},
           {1,1,1},
           {1,0,1},
           {1,0,1}}

 fonts.i ={{1,1,1},
           {0,1,0},
           {0,1,0},
           {0,1,0},
           {1,1,1}}

 fonts.j ={{1,1,1},
           {0,1,0},
           {0,1,0},
           {0,1,0},
           {1,1,0}}

 fonts.k ={{1,0,1},
           {1,0,1},
           {1,1,0},
           {1,0,1},
           {1,0,1}}

 fonts.l ={{1,0,0},
           {1,0,0},
           {1,0,0},
           {1,0,0},
           {1,1,1}}

 fonts.m ={{1,1,1},
           {1,1,1},
           {1,0,1},
           {1,0,1},
           {1,0,1}}

 fonts.n ={{1,1,0},
           {1,0,1},
           {1,0,1},
           {1,0,1},
           {1,0,1}}

 fonts.o ={{0,1,1},
           {1,0,1},
           {1,0,1},
           {1,0,1},
           {1,1,0}}

 fonts.p ={{1,1,1},
           {1,0,1},
           {1,1,1},
           {1,0,0},
           {1,0,0}}

 fonts.q ={{0,1,0},
           {1,0,1},
           {1,0,1},
           {1,1,0},
           {0,1,1}}

 fonts.r ={{1,1,1},
           {1,0,1},
           {1,1,0},
           {1,0,1},
           {1,0,1}}

 fonts.s ={{0,1,1},
           {1,0,0},
           {1,1,1},
           {0,0,1},
           {1,1,0}}

 fonts.t ={{1,1,1},
           {0,1,0},
           {0,1,0},
           {0,1,0},
           {0,1,0}}

 fonts.u ={{1,0,1},
           {1,0,1},
           {1,0,1},
           {1,0,1},
           {0,1,1}}

 fonts.v ={{1,0,1},
           {1,0,1},
           {1,0,1},
           {1,0,1},
           {0,1,0}}

 fonts.w ={{1,0,1},
           {1,0,1},
           {1,0,1},
           {1,1,1},
           {1,1,1}}

 fonts.x ={{1,0,1},
           {1,0,1},
           {0,1,0},
           {1,0,1},
           {1,0,1}}

 fonts.y ={{1,0,1},
           {1,0,1},
           {1,1,1},
           {0,0,1},
           {1,1,1}}

 fonts.z ={{1,1,1},
           {0,0,1},
           {0,1,0},
           {1,0,0},
           {1,1,1}}
end


-- see how looks on non-60fps
--u60=_update60 _update60=nil function _update() u60() _update_buttons() u60() end

--slow-mo
--u60=_update60 _update60=nil function _update() u60() _update_buttons() end
if(_update60)_update=function()_update60()_update_buttons()_update60()end