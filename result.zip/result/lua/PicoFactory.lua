-- pico-factory
-- a ld37 game by caranha
-- version count = 5
-------------------------
-- v1.3.1 -- fixed double click bug, added bignum, buffed sandwich
-- v1.3 -- added overwrite
        -- fruits now explode on rejected machines
        -- rebalanced costs
        -- output cost now exponential
        -- new objects: chicken, sandwich maker
-- v1.2 -- changed how input works
-- v1.1 -- added oven and assembler
-- v1.01 -- initial version
-------------------------
-- todo:
-- 1. music
-- 2. rewrite graph as a log graph
-- 3. tile variation and improvement
-- 4. new game modes
-- 5. more tiles and more rebalancing

dx={-1,1,0,0}
dy={0,0,-1,1}
ptclist={}
version = "v1.3.1"

----------------------------
-- bignum
b_string = function(high,low)
	if (high == 0) return low
	local z = (low > 999 and "") or (low > 99 and "0") or (low > 9 and "00") or "000"
 return high..z..low	
end

b_add = function (ah,al,bh,bl)
	local low = al + bl
	local high = ah + bh
	if low > 9999 then
	 low -= 10000
		high += 1
	end
	high = min(high, 10000)
	return high,low
end	

-- minimizes to zero
b_sub = function (ah,al,bh,bl)
	local low = al - bl
	local high = ah - bh
	if low < 0 then
		low += 10000
		high -= 1
	end

	if (high < 0 or low < 0) return 0,0
	return high,low
end

b_gt = function (ah,al,bh,bl)
	return (bh < ah or (bh == ah and bl <= al))
end

b_shift = function (ah,al)
	local high = min(ah*10 + flr(al/1000), 10000)
	local low = ((high == 10000 and 0) or (al%1000)*10)
	return high, low
end

b_div = function (ah,al,bh,bl)
	local base = 1
	local res = 0
	local high = ah
	local low = al
	while base >= 0.001 do
		count = 0
		while b_gt(high,low,bh,bl) do
			count += 1
			high,low = b_sub(high,low,bh,bl)
		end
		high,low = b_shift(high,low)
		res += count * base
		base /= 10
	end
	return res
end


--------------------------
function new_window(x0,y0,x1,y1,c1,c2,c3,mage)
	local w = {
		open = false,
		age = 0,
		mage = mage,
		x0 = x0,
		y0 = y0,
		x1 = x1,
		y1 = y1,
		c1 = c1,
		c2 = c2,
		c3 = c3
	}
	return w
end

function w_draw(w)
	if (w.age == 0 and not w.open) return
	local ymid = ((w.y1-w.y0)/2)*((w.age%w.mage)/w.mage)
	local ytop = w.y0 + ymid 
	local ybot = w.y1 - ymid
	rect(w.x0+1,ytop+1,w.x1+1,ybot+1,w.c3)
	rectfill(w.x0,ytop,w.x1,ybot,w.c1)
	rect(w.x0,ytop,w.x1,ybot,w.c2)
end

function w_updt(w)
	local sig = -1*sgn(w.age)
	if (w.age != 0) then
		w.age += sig
		if (w.age == 0) w.open = (sig == -1)
	end
end

function w_toggle(w)
	if (w.age != 0) return
	if (w.open) then
		w.age = -1*w.mage
	else
		w.age = w.mage
	end	
end
--------------------------


function _init()
	winlist = {
		new_window(15,25,111,53,3,3,1,1), -- menu window 2
		new_window(9,78,117,102,3,3,1,1), -- menu window 1
		new_window(4,20,124,107,0,3,1,30), -- end window
		new_window(35,35,94,94,0,3,1,5), -- item menu window
	}

	menu_items = {
									{s=42,c={0,0},x=0,y=0,f=destroy,m="destroy a tile! "},
  							{s=41,c={0,100},x=0,y=1,f=addoutput,m="sells products "},
		 						{s=1,c={0,2},x=1,y=0,f=addbelt,m="conveyor belt ⬅️ "},
		 						{s=5,c={0,2},x=1,y=1,f=addbelt,m="conveyor belt ➡️ "},
		 						{s=17,c={0,2},x=1,y=2,f=addbelt,m="conveyor belt ⬆️ "},
		 						{s=21,c={0,2},x=1,y=3,f=addbelt,m="conveyor belt ⬇️ "},
		 						{s=57,c={0,6},x=1,y=4,f=addsplit,m="splits the input 3-way "},
		 						{s=9,c={0,10},x=2,y=0,f=addtree,m="tree: 1 apple/3s "},
		 						{s=25,c={0,150},x=3,y=0,f=addprocessor,m="mixer: 4 apples = juice "},
		 						{s=64,c={0,100},x=2,y=1,f=addoven,m="bakery: 3 bread/2 s "},
		 						{s=80,c={0,500},x=3,y=1,f=addass,m="bread + juice = $$$ "},
		 						{s=68,c={0,50},x=4,y=0,f=addchicken,m="a bit random "},
		 						{s=84,c={0,2500},x=4,y=1,f=addtoaster,m="egg + bread = $$$$$ "},
		 						{s=44,c={0,0},x=0,y=2,f=nil,m="not available"},
		 						{s=44,c={0,0},x=0,y=3,f=nil,m="not available"},
		 						{s=44,c={0,0},x=0,y=4,f=nil,m="not available"},
		 						{s=44,c={0,0},x=2,y=2,f=nil,m="not available"},		 								 								 						
		 						{s=44,c={0,0},x=2,y=3,f=nil,m="not available"},
		 						{s=44,c={0,0},x=2,y=4,f=nil,m="not available"},
		 						{s=44,c={0,0},x=3,y=2,f=nil,m="not available"},
		 						{s=44,c={0,0},x=3,y=3,f=nil,m="not available"},
		 						{s=44,c={0,0},x=3,y=4,f=nil,m="not available"},
		 						{s=44,c={0,0},x=4,y=2,f=nil,m="not available"},
		 						{s=44,c={0,0},x=4,y=3,f=nil,m="not available"},
		 						{s=44,c={0,0},x=4,y=4,f=nil,m="not available"},
		 					}

	
	cartdata("caranha_ld37")
	screenshake = 0
	beltc = 0
	money = {high = 0, low = 0}

	hs_high = dget(1)
	hs_low = dget(0)

	if dget(3) < 5 then
		hs_high = 0
		hs_low = 1000
		dset(0,1000)
		dset(1,0)
		dset(3,5) 
	end

	_update = update_menu
	_draw = draw_menu
	menustart()
end

function menustart()
	fruit = {}
	w_toggle(winlist[1])
	w_toggle(winlist[2])
	mcounter = 0
	_update = update_menu
	_draw = draw_menu

	cleanroom()
	addtree(5,8)
	addbelt(6,8,2)
	addbelt(7,8,2)
	addbelt(8,8,2)
	addbelt(9,8,2)
	addbelt(10,8,2)
	addbelt(11,8,2)
	addoutput(12,8)
end

function gamestart()
	mhelp = "'x' to select a tool, 'z' to use it"
	money = {high = 0, low = 100}
	mhist = {}
	mmax_high, mmax_low = 0,0
	fruit = {}
	timeleft = 7200
 
	curx,cury = 8,7
	menux,menuy = 0,0
	place_mode = true
	select = 1
	menuselect = 1
	overwrite = false
	
	menu_items[2].c={0,100}
end

function scorestart()
	w_toggle(winlist[3])
	scorecounter = 0
end


-------- particle system -----
function newptc(x,y,c,s,dx,dy,ddx,ddy,ma)
	local p = {}
	p.x = x
	p.y = y
	p.dx = dx or 0
	p.dy = dy or 0
	p.ddx = ddx or 0
	p.ddy = ddy or 0
	p.s = s or 1
	p.c = c or 3
	p.a = ma or 5
	return p
end

function drawptc(p)
	circfill(p.x,p.y,p.s,p.c)	
end

function updateptc()
	for p in all(ptclist) do
		p.a -= 1
		p.x += p.dx
		p.y += p.dy
		p.dx += p.ddx
		p.dy += p.ddy
		if (p.a < 0) del(ptclist,p)
	end
end

-------- game functions ------
function sshake()
	camera()
	if screenshake > 0 then
		camera(rnd(screenshake)-screenshake/2,
									rnd(screenshake)-screenshake/2)
	 screenshake -= 1
	end
end

function cleanroom()
	tiles = {}
	for i=1,16 do
		tiles[i] = {}
		for j=1,13 do
			tiles[i][j] = {t=nil,s=32,age=0}
			if (i == 1 or i == 16) tiles[i][j] = {t="w",s=38,age=0}
			if (j == 1 or j == 13) tiles[i][j] = {t="w",s=37,age=0}
		end
	end
	tiles[1][1].s = 33
	tiles[1][13].s = 35
	tiles[16][1].s = 34
	tiles[16][13].s = 36  
end


------------------------------
-- input functions
function updatecursor()
	for i=1,4 do
		if btnp(i-1) then
			if (place_mode) then
				curx = mid(2,curx+dx[i],15)
				cury = mid(2,cury+dy[i],12)
			else
				menux = mid(0,menux+dx[i],4)
				menuy = mid(0,menuy+dy[i],4)
				for s,i in pairs(menu_items) do
					if i.x == menux and i.y == menuy then
						menuselect = s
						break
					end
				end	
			end
		end
	end

	if btnp(5) and winlist[4].age == 0 then 
		overwrite = false
		place_mode = not place_mode
		w_toggle(winlist[4])
		sfx(1)
	end

	if btnp(4) and winlist[4].age == 0 then
		if (place_mode) then
			sm = menu_items[select]
			if b_gt(sm.c[1],sm.c[2],money.high, money.low) then
				sfx(2)
				return
			end

			if (select == 1) then
				sm.f(curx,cury)
			else
				if (tiles[curx][cury].t) then
					if (overwrite) then
						destroy(curx,cury)
					else
						overwrite = true
						screenshake = 7
						sfx(2)
						return
					end
				end
				money.high,money.low = b_sub(money.high,money.low,sm.c[1],sm.c[2])
				sm.f(curx,cury,select-2)
				sfx(3)
			end
		else
			if not menu_items[menuselect].f then
				screenshake = 7
				sfx(2)
 		else
				select = menuselect
				place_mode = not place_mode
				w_toggle(winlist[4])
				sfx(1)
				overwrite = false
			end
		end
	end	
end


-----------------------------
-- tile functions
function destroy(x,y)
	tiles[x][y] = {
	t=nil,
	age=0,
	s=32
	}
	screenshake = 5
	sfx(0)
	for i=1,10 do
		add(ptclist,
			newptc(x*8-4,y*8+5,5+rnd(2),rnd(2)+0.2,cos(0.13+i/4)/2*rnd(2),sin(0.13+i/4)/2*rnd(2),0,0,10))
	end

	if (t == "output") menu_items[2].c[2] = menu_items[2].c[2]/2
end

beltd = {1,5,17,21}
function addbelt(x,y,d)
	tiles[x][y] = {
		t = "b",
		s = beltd[d],
		d = d,
		age = 0
	}
end

function addsplit(x,y)
	tiles[x][y] = {
		t = "split",
		s = 60,
		age = 0,
		inv = {},
		d = 4,
		get = function(self,f)
									add(self.inv,f.s)
								end
	}
end

function addtree(x,y)
	tiles[x][y] = {
		t="tree",
		s=9,
		state=0,
		age=30
	}
end

function addchicken(x,y)
	tiles[x][y] = {
		t="chicken",
		s=68,
		state=-1,
		age=flr(rnd(20)+60)
	}
end

function addoven(x,y)
	tiles[x][y] = {
		t="oven",
		s=64,
		state=0,
		age=5
	}
end

function addass(x,y)
	tiles[x][y] = {
		t="assembler",
		s=80,
		state=0,
		juice=0,
		bread=0,
		age=0,
		get = function(self,f)
									if f.s==50 and self.juice == 0 then
										self.juice = 1
									else 
										if f.s == 51 and self.bread == 0 then
											self.bread = 1
										else
											fruitsplash(f)
										end
									end
								end
	}
end

function addtoaster(x,y)
	tiles[x][y] = {
		t="toaster",
		s=84,
		state=0,
		egg=false,
		bread=false,
		age=0,
		get = function(self,f)
									if f.s==51 and not self.bread then
										self.bread = true
									else 
										if f.s == 53 and not self.egg then
											self.egg = true
										else
											fruitsplash(f)
										end
									end
								end
	}
end

function addprocessor(x,y)
	tiles[x][y] = {
		t="processor",
		s=25,
		state=0,
		fruit=0,
		age=0,
		get = function(self,f)
									if (f.s == 49 and self.fruit < 4) then
										self.fruit += 1
									else
										fruitsplash(f)
									end
								end
	}
end



fruitsell = {{0,1},
													{0,40},
													{0,1},
													{0,300},
													{0,1},
													{0,2000}}
function addoutput(x,y)
	tiles[x][y] = {
		t="output",
		s=41,
		age=0,
		get= function(self,f)
								local fs = fruitsell[f.s-48]
								money.high,money.low = b_add(money.high,money.low,fs[1],fs[2])
								for i=1,min(fs[2],200) do
									add(ptclist,
									newptc(x*8-5+rnd(3),y*8+4+rnd(3),9,1,cos(rnd())/1.5,-2.5+rnd(1),0,0.2,7+rnd(2)))
								end
								sfx(4)
							end
	}
	menu_items[2].c[2] = min(menu_items[2].c[2]*2,6400)
end

function addfruit(x,y,s)
	local f = {
		x = x,
		y = y,
		ox = flr(rnd(3))-1,
		oy = flr(rnd(3))-1,
		dx = 0,
		dy = 0,
		age = 0,
		s = s,
	}
	add(fruit,f)
end

--------------------------------
-- update functions

function fruitsplash(f)
	for i=1,4 do
		add(ptclist,newptc(f.x*8+f.ox-4,f.y*8+f.oy+5,8,0.5,cos(0.13+i/4)/2,sin(0.13+i/4)/2))
	end
end

function u_fruit(f)
	if f.age == 0 then
		f.x += f.dx
		f.y += f.dy
		t = tiles[f.x][f.y]
		if fget(mget(f.x,f.y),0) then
			f.age = 8
			f.dx = dx[t.d]
			f.dy = dy[t.d]
		else
			if (t.get) then 
				t:get(f)
			else	
				fruitsplash(f)
			end
		end
	end
	f.age -= 0.5
end

function u_tile(i,j)
	t = tiles[i][j]
	t.age -= 1

	if t.t == "b" then
		t.s = beltd[t.d] + beltc/2
	end

	if t.t == "split" then
		if #(t.inv) > 0 then
			addfruit(i+dx[t.d],j+dy[t.d],t.inv[1])
			del(t.inv,t.inv[1])
			t.d = t.d/2
			if (t.d < 1) t.d = 4
			t.s = 57 + min(t.d,3)
		end
	end

	if t.t == "tree" then
		if t.age < 0 then 
			t.state = (t.state + 1) %3
			t.age = 30
			if (t.state == 0) addfruit(i+1,j,49)
		end
		t.s = 9+t.state
	end

	if t.t == "chicken" then
		if t.age < 0 then
			addfruit(i+t.state,j,53)
			t.age = flr(rnd(20)+60)
			t.state = -1*t.state
		end
		local jmp = rnd(t.age) < 3 and 1 or 0
		t.s = 68 + jmp - (2*min(0,t.state))
	end

	if t.t == "oven" then
		if t.age < 0 then
			t.state = (t.state+1)%4
			t.age = 6
			if (t.state == 0) addfruit(i,j-1,51)
		end
		t.s = 64+t.state 
	end

	if t.t == "processor" then
		t.s = 25+t.fruit
		if (t.fruit == 4 and t.age < 0) then
			t.age = 30
			sfx(5)
		end
		if (t.age > 0) then
			t.s += t.age%2
		end
		if (t.age == 0) then
			t.fruit = 0
			addfruit(i+1,j+0,50)	
		end
	end
	
	if t.t == "assembler" then
		t.s = 80 + t.juice + t.bread
		if (t.juice + t.bread == 2 and t.age < 0) then
		 t.age = 90
		 sfx(8)
		end
		if (t.age > 0) then
			t.s += (t.age%8)/4
		end
		if (t.age == 0) then
			t.juice = 0
			t.bread = 0
			addfruit(i-1,j+0,52)
		end
	end	
	
	if t.t == "toaster" then
		t.s = 84 + (t.egg and 2 or 0) + (t.bread and 1 or 0)
		if (t.egg and t.bread and t.age < 0) then
		 t.age = 45
		 sfx(9)
		end
		if (t.age > 0) then
			t.s += (t.age%8)/4
		end
		if (t.age == 0) then
			t.bread = false
			t.egg = false
			addfruit(i-1,j+0,54)
			addfruit(i+1,j+0,54)
		end
	end
end

function update_game()

	if (scount == 0 and rnd() < 0.3) mhelp = messages[flr(rnd(#messages))+1]

	if (timeleft%60==0 and timeleft>=0) then 
		add(mhist,{money.high,money.low})
		if b_gt(money.high, money.low, mmax_high, mmax_low) then
			mmax_high, mmax_low = money.high, money.low
		end
	end	
	timeleft -= 1
	if (timeleft < 0) then 
		winlist[4].open = false
		scorestart()
		_update = update_end
		_draw = draw_end
		return
	end


	for i=1,16 do
		for j=1,13 do
			u_tile(i,j)
			mset(i,j,tiles[i][j].s)
		end
	end
	beltc = (beltc+1)%8
	
	for f in all(fruit) do
		u_fruit(f)
		if (f.age < 0) del(fruit,f)
	end
	updatecursor()
	updateptc()
	foreach(winlist,w_updt)
end

function update_menu()
	mcounter += 1
	foreach(winlist,w_updt)
	
	for i=1,16 do
		for j=1,13 do
			u_tile(i,j)
			mset(i,j,tiles[i][j].s)
		end
	end
	beltc = (beltc+1)%8
	
	for f in all(fruit) do
		u_fruit(f)
		if (f.age < 0) del(fruit,f)
	end
	updateptc()
	
	if btn() > 0 and mcounter > 10 then
		sfx(7)
		mcounter = -60
	end
	
	if mcounter == -1 then
		w_toggle(winlist[1])
		w_toggle(winlist[2])
		gamestart()
		_update = update_game
		_draw = draw_game
	end
end

function update_end()
	scorecounter += 1
	foreach(winlist,w_updt)
	
	if scorecounter > 30 and scorecounter < 30+#mhist then
		sfx(4)
	end
	if scorecounter == 33+#mhist and b_gt(money.high,money.low,hs_high,hs_low) then
		sfx(6)
	end
	
	if scorecounter > 60 and btn() > 0 then
		if b_gt(money.high,money.low,hs_high,hs_low) then
	 	dset(0,money.low)
	 	dset(1,money.high)
	 	hs_low = money.low
	 	hs_high = money.high
	 end
	 winlist[3].open = false
		menustart()
	end
end

---------------------------
-- draw functions


scount = 0
function draw_bottom()
	scount = (scount + 1) % (128 + #mhelp*4)

	local menushow = (place_mode and select or menuselect)
	local mitem = menu_items[menushow]
	local ttext = mitem.m.."(c:"..b_string(mitem.c[1],mitem.c[2])..")"

	print(ttext,64-#ttext*2,2,7)
	print(mhelp,128 - scount,115,7)		
	print("$$ = "..b_string(money.high,money.low),2,121,10)

	local tc = 10
	if (timeleft < 900) tc -= 2*(flr((timeleft%10)/5))

	print("time: "..max(0,flr(timeleft/1800))..":",85,121,tc)
	if (timeleft > 0) then
		print(flr((timeleft/300)%6),117,121,tc)
		print(flr((timeleft/30)%10),121,121,tc)
	else
		print("00",116,121,tc)
	end
end

function drawscore()
	foreach(winlist,w_draw)

	if b_gt(hs_high,hs_low,mmax_high,mmax_low) then
		mmax_high, mmax_low = hs_high, hs_low
	end

	local scorey = function(h,l) return 90-((b_div(h,l,mmax_high,mmax_low))*53) end	

	if (scorecounter > 30) then
		local smsg = "final score "..b_string(money.high,money.low)
		print(smsg,64-#smsg*2,26,3)
		line(14,scorey(hs_high,hs_low),114,scorey(hs_high,hs_low),12)
		line(14,scorey(0,0),114,scorey(0,0),7)
		line(14,scorey(0,0),14,scorey(mmax_high,mmax_low),7)
		
		local gstep = 100/(#mhist-1)
		for i=1,(min(#mhist,scorecounter-30)-1) do
			line(14+(i-1)*gstep,scorey(mhist[i][1],mhist[i][2]),14+(i)*gstep,scorey(mhist[i+1][1],mhist[i+1][2]),10)
		end
		if (scorecounter > 32+#mhist) then
			if b_gt(money.high, money.low, hs_high,hs_low) then
				print ("♪ new highscore ♪",30,94+sin(scorecounter/60),3+sin(scorecounter/60)*8)
			else
				print ("try to beat the highscore!",14,95,3)
			end
		end
	end
	
end

function draw_board()
	cls()
	sshake()
	map(1,1,0,10,16,13)
	for f in all(fruit) do
		spr(f.s,f.x*8+f.ox+f.dx*(8-f.age)-8,
		        f.y*8+f.oy+f.dy*(8-f.age)+2)
	end 
	foreach(ptclist,drawptc)
end

function draw_game()
	draw_board() -- game board
	draw_bottom() -- timer

	spr(48,curx*8-8,cury*8+2)

	-- draw input
	foreach(winlist,w_draw)

	if (not place_mode) then
		if (winlist[4].open and	winlist[4].age==0) then
		 rect(menux*11+38,menuy*11+38,menux*11+47,menuy*11+47,7)
		 for i in all(menu_items) do
		 	spr(i.s,i.x*11+39,i.y*11+39)
		 end
		end
	end
end

function draw_menu()
	draw_board()

	print(version,127-#version*4,2)
	foreach(winlist,w_draw)

	spr(100,20,27,12,2)
	print("a ld37 game by @caranha",19,46,1)
	print("a ld37 game by @caranha",18,45,6)
	print("build your factory in 4:00",12,81,1)
	print("earn more than $"..b_string(hs_high,hs_low),12,89,1)
	print("press any key to start",12,97,1)
	print("build your factory in 4:00",11,80,6)
	print("earn more than $"..b_string(hs_high,hs_low),11,88,6)
	print("press any key to start",11,96,6)
	
	if (mcounter < -42)	print("ready!",52,120)
	if (mcounter > -32 and mcounter < -18) print("set!",56,120)
	if (mcounter > -10 and mcounter < 0) print("go!",58,120)	
end

function draw_end()
	draw_board()
	drawscore()
end

messages = {
	"this game was made in 48 hours for ludum dare 37!",
	"inspired by 'idle factory'.",
	"i ♥ pico-8",
	"can you beat $10.000?",
	"nerf bread!",
	"go play pico fox!",
	"got a highscore? send me a screenshot on twitter!",
	"publish or perish.",
	"feel free to send me ideas to improve the game.",
 "making music is hard...",
 "for a list of cool pico games: http://clowerweb.com/games/pico/",
 "balancing is hard...",
 "you can overwrite tiles by pressing the 'use' button twice."
}