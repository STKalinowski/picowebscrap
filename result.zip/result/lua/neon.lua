--neon
--by luca harris

--palette
for i=1,7 do
 pal(i,({
  8,11,10,140,14,12,7,
 })[i],1)
end

--list of points
local ps=nil

--interporlate between items
--in a table.
--t - a table
--i - index into t
function smooth(t,i)
 local n=#t
 local i0=flr(i)
 local t0=t[min(n,i0)]
 local a,b
 if type(t0)=="table" then
  a=t0[1]
  b=t0[2]
 else
	 a=t0
	 b=i<n and t[i0+1] or t0
	 if type(b)=="table" then
	  b=b[1]
	 end
	end
	
	local k=i-i0
	return a*(1-k)+b*k
end

--alternating scanline cls
function scan_clear()
 local f=frame%2
 
 for j=0,127 do
  local i=0x6000+j*64
  if j%2==f then
   memset(i,0,64)
  end
 end
end

--music stuff
beat_table={
 1,1,1,2,
 2,2,3,3,
 3,3,4,4,
 4,5,5,6,
}

beat_int_table={
 4,1,{0.5,0},4,
 1,{0.5,0},4,2,
 1,{0,2},2,6,
 {2,1},5.2,{2,0},{4.7,0},
}

--state
local ch1l=-1
local ch1h=0
local ptn0=-1
local rotation=0
frame=0
clear_mode=0

--init!
function _init()
 music(0)
end

--pattern handlers
--ptn 0
function ptn_0(p)
 p.spy=0
 p.spx=0
 p.spw=17
 p.sph=8
 p.spd=5
 p.speed=7
 p.int=(ch1h%4)*(ch1h/32)*1.2
 p.scale=6+ch1h/8
end

--ptn 1-2
function ptn_1(p)
 p.spy=16
 p.spx=0
 p.spw=42
 p.sph=15
	
 if ptn==1 then
  local k=ch1h%4
  p.int=-0.5-k*0.9
  p.scale=8.5+k*1.5
 else
	 local k=smooth(beat_int_table,1+ch1h%16)
  p.int=k*0.8
  p.scale=3+beat_table[1+ch1%16]*2.5
 end
end

--ptn 3-4
function ptn_3(p)
 p.spy=0
 p.spx=48
 p.spw=26
 p.sph=8
 p.spd=5
 
 local bop=ch1c and ({
  1,0,0,1,
  0,0,1,0,
  0,0,1,1,
  0,1,0,1,
 })[1+ch1%16]==1
 if(bop)ptn3t=1
	
	if ptn==3 then
	 p.speed=bop and 100 or 11
	 p.scale=9+ptn3t*2
  p.int=ptn3t*4+0.2
	else
	 p.speed=3+ptn3t*25+ch1h*0.45
	 p.int=ch1h/7+ptn3t*2.5
	 p.scale=8+ptn3t*2
	end
 
 ptn3t*=0.74
end

--ptn 5-8
function ptn_5(p)
 p.spy=16
 p.spx=48
 p.spw=48
 p.sph=16
 local k=(4-ch1h%4)
 
 if ptn<7 then
  p.speed=ch1c and ch1==0 and 100 or 6+k*1
 end
	
	if ptn==5 then
	 p.int=-k
	 p.scale=12+k*1
	elseif ptn==6 then
	 p.int=-2-k
	 p.scale=18-k*2
	 p.speed=10
	elseif ptn==7 then
	 local k2=ch1h%8<4 and k or 4-k
	 p.int=1+k2*0.8
	 p.scale=4+k2*3
	else
	 p.int=5-k*1.12+ch1h*0.04
	 p.scale=10+k*0.7+ch1h*0.2
	 p.speed=7+ch1h*0.7
	end
end

--ptn 9-10
function ptn_9(p)
	p.spy=0
	p.spx=80
	p.spw=33
	p.sph=16
	
	local k=smooth(beat_int_table,1+ch1h%16)
	p.speed=10
	if ptn==9 then
	 p.int=0.2+k*0.7
	 p.scale=4+beat_table[1+ch1%16]*2.3
	else
	 p.scale=11
	 p.int=0.2+k*0.8
	 p.speed=7+k*4.2
	end
end

--ptn 11-12
function ptn_11(p)
 local which=(beat_table[1+ch1%16]-1)%4
 
 ptn13_last=ptn13_last or -1
 local bop=which!=ptn13_last
 if(bop)nptn=true
 
 local d=({
  {16,0,42,15,3},
  {0,48,26,8,5},
  {16,48,48,16,3},
  {0,80,33,16,3},
 })[1+which]
 
 p.spy=d[1]
 p.spx=d[2]
 p.spw=d[3]
 p.sph=d[4]
 p.spd=d[5]
 
 local k=smooth(beat_int_table,1+ch1h%16)
 if ptn==11 then
  local k2=0.1+k*1.5
  p.int=-k2
	 p.speed=8
	 p.scale=13+k2/2
 else
  local kc=(ch1h/32)^2
  local k2=0.1+kc*1.2+(4-ch1h%4)*(1+kc*0.7)
  p.int=k2
	 p.speed=8+kc*24
	 p.scale=10+kc*10
	end
end

--ptn 13-16
function ptn_13(p)
 p.spy=0
 p.spx=0
 p.spw=17
 p.sph=8
 p.spd=6
 p.speed=9
 
 local k=(4-ch1h%4)
 local k2=(2-ch1h%2)
 local prog=(ptn-13)*32+ch1h
 local progt=prog/128
 p.speed=1.2+progt*8.5
 p.scale=3+progt*10
 p.int=1-progt*1.2+k*(progt*progt)
 if ptn==16 then
  p.int+=k2*ch1h*0.02
 end
end

--draw!
function _draw()
	--get music state
	ptn=stat(24)
	nptn=ptn0!=ptn
	ptn0=ptn
	ch1=stat(20)
	ch1c=ch1!=ch1l
	if ch1c then
	 ch1h=ch1
	 ch1l=ch1
	else
	 ch1h+=0.25
	end
	
	--swap clear mode everytime
	--we reach the last pattern
	if nptn and ptn==13 then
	 clear_mode=(clear_mode+1)%2
	end
	
	if clear_mode==0 then
	 cls()
	else
	 scan_clear()
	end
	
	--graphics parameters
	local p={
	 spx=0,
		spy=0,
		spw=16,
	 sph=16,
		spd=3,
		int=0,
		scale=14,
		speed=6,
	}
	
	--pattern handlers
	if ptn==0 then
	 ptn_0(p)
	elseif ptn<=2 then
	 ptn_1(p)
	elseif ptn<=4 then
	 ptn_3(p)
	elseif ptn<=8 then
	 ptn_5(p)
	elseif ptn<=10 then
	 ptn_9(p)
 elseif ptn<=12 then
	 ptn_11(p)
	else
	 ptn_13(p)
	end
	
	--get locals from params
	local spx=p.spx
	local spy=p.spy
	local spw=p.spw
	local sph=p.sph
	local spd=p.spd
	local int=p.int
	local scale=p.scale
	local speed=p.speed
	
	--main
	--load points
	if nptn then
	 ps={}
		for y=0,sph-1 do
		for x=0,spw-1 do
		 local c=sget(spx+x,spy+y)
		 if c>0 then
		  add(ps,{x=x,y=y,c=c})
		 end
		end
		end
	end
	
	--normalize params
	int=int/100
	rotation+=speed/900
	
	--precalc constants
	local js={}
	for i=0,2 do
	 js[i]=0.27+int*i
	end
	local is={[0]=4,2,1}
	local yc=sph/2
	local ky=scale/sph
	local kx=0.5/spw
	
	--draw points
	for pi=1,#ps do
	 local p=ps[pi]
	 local x=p.x
	 local y=p.y
	 local c=p.c
	 local q=0.07+(-x*kx+rotation)%0.5
	 if q<0.42 then
		 local sq=sin(q)
		 for a=0,spd-1 do
		 	local x2=cos(q+a/(spd/kx))*scale
			 for b=0,spd-1 do
			  local y2=(y+b/spd-yc)*ky
					for i=0,2 do
					 local k=.5+sq*js[i]
				  local u=64+x2/k
				  local v=64+y2/k
				  pset(u,v,bor(is[i],pget(u,v)))
					end
				end
			end
		end
	end
	
 frame+=1
 
 --debug
	--?stat(1),0,0,7
end