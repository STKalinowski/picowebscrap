-- orbys :: tdf2016 post-compo
-- by pod (castpixel & zep)

--[[

 gfx:  castpixel (tw:@castpixel)
 code: zep (tw:@lexaloffle)
 sfx:  castpixel & zep
 
 ★ warning ★
 
 this code was frantically
 hacked together shortly before
 the tokyo demo fest compo, so
 is very not readable. ★
 
]]

srand(0)

-- mpat:
-- 12 marine 16 disco 20 cards
-- 26.5 plasma  31 outro
mpat=0
pat2=0 

debug_info = false

t=mpat*129
t-=130 -- added 1 pat at start

----------

gt = t

datpos={
0,492,1502,1706,5573,7034,8229,9162,9930,10191
};

dath={64,69,48,128,48,48,48,48,20,48}


--reload(0,0,0x3000,"g_all.p8")
--cstore(0,0,0x3000)

disco={}

function load_gfx(index,y)
 ppx = 0
 ppy = y
 
 decomp(datpos[index],
  dath[index]*128,pc)
 
end



ppx=0 ppy=0
function decomp(src, plen, putcol)
 px=0
 src-=1 
 local bit=256
 local b=0
 function getval(bits)
  val=0
  for i=0,bits-1 do
   --get next bit from stream
   if (bit==256) then
    bit=1
    src+=1
    byte=peek(src)
   end
   if band(byte,bit)>0 then
    val+=shl(1,i)
   end
   bit*=2
  end
  return val
 end
 
 
 -- header
 local col_bits=getval(4)
 local bitstart=getval(3)
 local bitjump=getval(3)
 getval(1) -- ignore options 
 local ncols=getval(col_bits)+1
 local clist={}
 for i=0,ncols-1 do
  clist[i]=getval(col_bits)
 end
 
 local cbits=getval(3)
 local maxval=getval(cbits)
 
 local pos=0
 while (pos < plen) do

  -- span length
  local bl = bitstart
  while getval(1)==0 do
   bl += bitjump end
  len=getval(bl)+1
  
  -- colour
  
  local index=1
  v=getval(cbits)
  while(v > maxval) do
   index += maxval+1
   v=getval(cbits)
  end
  index += v
  
  col = clist[index]
  
  -- move to front
  for i=index,1,-1 do
   clist[i]=clist[i-1]
  end
  clist[0]=col
   
  -- draw the span
  for i=1,len do
   putcol(col)
   pos+=1
  end

 end
 
end

-- put colour (for decompressor)
function pc(col)

 if (ppy < 0) then
  -- draw to screen (marine)
  pset(ppx,ppy+128,col)
 else
  -- draw to spritesheet
  sset(ppx,ppy,col)
 end
 ppx += 1
 if (ppx==128) ppx=0 ppy+=1 
end


----------

orb={}

local ca = 0
local cat = 0

function rot(x,y,a)
 local x0=x
 x = cos(a)*x - sin(a)*y
 y = cos(a)*y + sin(a)*x0
 return x,y
end

-- draw wireframe pod logo
-- at angle, width and colour
function draw_pod(x,y,a,w,col)

 l =
 {
  -- p out
  [0]=0,0,4,0,
  4,0,4,4,
  4,4,1,4,
  1,4,1,5,
  1,5,0,5,
  0,5,0,0,
  
  -- half o
  5,0,9,0,
  5,0,5,4,
  6,1,8,1,
  6,1,6,3,
  
  -- p in
  1,1,3,1,
  3,1,3,3,
  3,3,1,3,
  1,3,1,1,
  
 }
 
 nl=14
 
 for i= 0, 4*nl-1,2 do
  l[i] -= 7
  l[i+1] -= 2
 end
 
 -- pod
 
 -- draw all lines
 
 for i= 0, 4*nl-1,4 do
 
  sx0=l[i+0] * w
  sy0=l[i+1] * w
  sx1=l[i+2] * w
  sy1=l[i+3] * w
  
  --rotate
  
  sx0,sy0 = rot(sx0,sy0,a)
  sx1,sy1 = rot(sx1,sy1,a)
  
  line(x+sx0,y+sy0,x+sx1,y+sy1,
       col)
  
  sx0=-l[i+0] * w
  sy0=-l[i+1] * w
  sx1=-l[i+2] * w
  sy1=-l[i+3] * w
  
  
  sx0,sy0 = rot(sx0,sy0,a)
  sx1,sy1 = rot(sx1,sy1,a)
  
  line(x+sx0,y+sy0,x+sx1,y+sy1,
       col)
       
 end
 
end


function sqr(x) return x*x end

function draw_pod_intro()

 local ttt=t
 local t=ttt+130
 ext = 0.05-(t*0.05)/(30*4.2) 
 ext = max(0,ext)
 
 w = max(4,104-t*1)
 
 if (ext == 0 and false) then
 
  -- stay for a second
  t0 = t-100
  t0 = max(0, t0-15)
  --t0 = 0
  
  w = 4+sqr(t0*0.2)
  w = 4
  
  y = 64-4*w 
  --y -= sqr(t0*0.2)*1.5
  x = 64-8*w 
  
  sspr(0,0,16,8,x,y, 16*w, 8*w)

 else
 
  local start=13
  if (ext == 0) start = 7
 
  for i=start,7,-0.5 do 
   a = -t*0.0051+i*ext
   --a = max(-0.5,a) 
   if (a < -0.5) then
    --w += (a+0.5)*-3
    --w = min(w,8)
    a=(a+0.5)*4-0.5
   end
   a = max(-1,a) 
   c = i
   if (c == 7 and t > 143) then
    local t0 = t-143
    t0 = flr(t0 / 2)
    local a = {[0]=7,6,12,13,5,1,0} 
    c=a[mid(0,t0,6)]
   end
   
   if (c > 0) then
    draw_pod(64,64,a,w,c)
   end
  end
 end
 
 
 t0 = 240
 if (t >= t0 and t < t0+30*7) then
  
  t0=t-t0
  t0 = min(t0, 72)
  y = 2

  sspr(0,8,128,t0,
   12,y)
  for x=0,104 do
   line(x+12,y+t0,x+12,127,
    sget(x,8+t0))
  end
 end
end







-- get sx, sy, sz
function calc_orb(o)
local x,y,z
 
 x = o.x
 y = o.y
 z = o.z
 
 -- distortion
 
-- x *= 2 y *= 2 z *= 2

 q = 0.5

 if(t>500 and t<800) then
  local amp = -sin((t-500)/300)
  x += cos((t-500)*0.04+y*0.2)
    *q*amp
 end
 
 if(t>900 and t<1000) then
  local amp = -sin((t-900)/100)
  amp*=2
  z += cos((t-900)*0.04+y*0.2)
    *q*amp
 end
 
 -- big distotion when colourful
 if(t>1000 and t<1300) then
  local amp = -sin((t-1000)/300)
  amp*=1
  x += cos((t-1100)*0.04+y*0.2)
    *q*amp*2
  y += cos((t-1100)*0.023+z*0.3)
    *q*amp
   
  z += cos((t-1100)*0.011+x*0.3)
    *q*amp
 end
 
 
 --y += cos(0.3+t*0.04+z*0.2+x*0.2)*q
 --z += cos(0.7+t*0.03+z*0.25+y*0.23)*q
 
 -- camera: rotate xz
 -- and move camera back
 --cat = 0 ca = 0
 
 x,y = rot(x,y,cat)
 x,z = rot(x,z,ca)
 
 
 -- distance from center
 z += 7
 
 
 -- come in from left
 -- was 430 in compo version
 if (t < 370) x-= (370-t)*0.1
 
 o.sort_z = z
 if (o.col > 16) o.sort_z=0
 
 
 -- move to grid
 
 if (t > 1300) then
  local t0 = t-1300
  t0 -= o.index*1
  t0 = (t0/60)
  t0 = mid(0,t0,1)
  
  t1 = 1-t0
  
  local xx=o.index%10
  local yy=flr(o.index/10)
  x = x*t1 + ((xx-4.5)*0.52) *t0
  y = y*t1 + ((yy-4.5)*0.52) *t0
  z = z*t1 + 4*t0
  
  -- non-linear movement
  y -= sin(t1) * 2
  x += sin(t1) * cos(o.index*0.03)*1
  
  if (t0 > 0.5) o.col=0+16
  
 end
 
 -- * 96 for narrower fov
 
 o.sx = 64 + x * 96 / z
 o.sy = 64 + y * 96 / z
 o.sz = z
 
 o.sy2= 64+(5.5-y*0.9) * 96 / z
 o.above = y < 2.5
 
 
end

function draw_orb(o)

 local sx
 local sy
 
 sx = o.sx
 sy = o.sy
 sz = o.sz
 
 --if (not o.above) return
 
--[[
 rectfill(
  sx-5/z,sy-5/z,
  sx+5/z, sy+5/z, o.col)
]]
 z = o.sz
 w=16/z
 
 if (opass==0) then
  
  --[[
  rectfill(sx-w + cos((t+o.index)*0.21)*1.5
  ,200-sy,
  sx+3 + cos((t+o.index)*0.17)*1.5,
  200-sy+w, 
  0)]]
  
  --reflection / shadow
  --if (o.above) then
   --circ(sx,sy,5,14)
  circfill(o.sx,o.sy2,w*1.5,0)
  
  return
 end
  
 
 if (o.col==0) then
  pal(2,0)
  if (opass==1) then
   spr(240,sx-4,sy-4)
  end
  
  
  
  -- shadow
  if (opass==2) then
   for i=1,15 do
    pal(i,0)
   end
   sspr(0,120,8,8,sx-4,
   (104+(104-sy)/2)-4,8,4)
  end
  
  pal()
  
  return
 end
 
--[[
 if (w < 1.5) then
  rectfill(sx,sy,sx+1,sy+1,col)
 elseif (w < 2) then
  rectfill(sx-1,sy-1,sx+1,sy+1,col)

 else
]]

 if(o.col > 16 and false) then
  -- white square
  
  local x = o.sx
  local y = o.sy
   x = flr(x/12.8-0.1)
   y = flr(y/12.8-0.5)
   rectfill(x*12.8,y*12.8,
    x*12.8+12.8,y*12.8+12.8,
    7)
  return
 end

 -- blur
 if (o.col < 16) then
 circfill(o.lsx, o.lsy, w, o.col)
 
 --circfill(sx-(sx-o.lsx)*0.5, 
 --         sy-(sy-o.lsy)*0.5, 
 --         w, o.col)
 end
 -- edge
 --circ(sx,sy,w+2,o.col)
 
 
 if (o.col >= 16) w += 2
 
 -- body
 circfill(sx, sy, w, o.col)

 -- highlight
 if (o.col < 16) then
 circfill(sx + 4/z, sy -4/z,
  w/4, 7) 
 end
  
 o.lsx=sx
 o.lsy=sy
 
  
-- end
 
-- spr(47,sx-4,sy-4)

end

function move_orb(o)
-- o.z += 0.01
-- o.x += 0.01
--[[
 q=0.02
 if (btn(0)) o.x -= q
 if (btn(1)) o.x += q
 if (btn(2)) o.y -= q
 if (btn(3)) o.y += q
-- if (btn(4)) o.z -= q
 if (btn(5)) o.z += q
]]

 -- move left
 if (t > 700 and t < 800) then
  o.x += 0.02
  o.z += 0.005
 end


 -- move away
 if (t > 800 and t < 900) then

  o.z += 0.015

 end
 
 -- move back 
 if (t > 1000 and t < 1120) then
  o.x -= 0.02
  o.z -= 0.02
  o.y -= 0.005
 end

 -- turn to balls
 if(rnd(20)<1 and t > 930 and 
  o.col < 16) then
  o.col = 7+rnd(6)
 end
 
 if(rnd(7)<1 and t > 1210 and 
  o.col < 16 and o.col != 0) then
  o.col = 16
 end
 
 --if(rnd(60)<1) o.col=0
end


function make_orb(x,y,z)
 o={}
 o.x=x
 o.y=y
 o.z=z
 o.index=#orb
 o.lsx=10000 -- offscreen
 o.lsy=10000 
 o.sort_z = z
 o.col=0
 add(orb,o)
 return o
end

function make_orbs()
 for z=0,4 do
 for y=0,4 do
  for x=0,4 do
  
   o=make_orb(x*0.5 - 1,
              y*0.5 - 1,
              z*0.5 - 1)
   
  end
 end
 end
end

function sort_orbs()

 count=0
 -- sort left to right
 for i=1,#orb-1 do

  if (orb[i].sort_z < 
      orb[i+1].sort_z)
  then
   count += 1
   local tmp=orb[i]
   orb[i]=orb[i+1]
   orb[i+1]=tmp
  end

 end
 
 --sort right to left
 for i=#orb-1, 1,-1 do

  if (orb[i].sort_z < 
      orb[i+1].sort_z)
  then
   count += 1
   local tmp=orb[i]
   orb[i]=orb[i+1]
   orb[i+1]=tmp
  end

 end

 return count
 
end

function _update()

 t=t+1

 gt+=1
  
 if (btn(4)) t+=10 gt+=10

 if (t < 1800) then
  foreach(orb,move_orb)
  ca += 0.01
  cat = cos(t/300)*0.2
 end


end

 skydat={
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, 1,0,0,1,1,0,1,1,1,1,1,1,1,0,1,1,1,5,5,5,13,13,14,13,13,13,14,13,13,14,14,13,14,14,14,14,14,14,15,15,14,15
 }
 
function draw_orb_dance()

 
 camy = min(-32,-200+t*1)
 camy = flr(camy)

-- camy = 0---32

 camera(0,camy)

 
 
 -- sky
 for y=0,64 do
  line(0,y,127,y,
   skydat[min(y+20,#skydat)])
 end
 
 -- stars
 seed=rnd()
 srand(6)
 for i=0,40 do
 local col = 1
  if (t > 178-110) col=5
  if (t > 184-110) col=13
  
  if (t > 188-110) then
  col =
   6 + (t/8+rnd(2))%2
  
   if (i < 10) col=13
   
   
  else
   local adasd = rnd(2)
  end
  pset(rnd(128),32-rnd(128),
  col)
  
 end
 srand(seed)
 
 -- mountains
 
 pal(13,13)
 pal(7,7)
 
 spr(208,0,64-20,16,2)
 rectfill(0,60,127,61,13)
 rectfill(0,62,127,63,0)
 pal()
 
 -- ground
 rectfill(0,64,127,127,1)


 -- water: reflect mountains
 
 local z=64 ---camy
 local h=mid(0,127-z,16)
 local dcol =
 {
  [0]=1,0,0,0,
  0,0,0,0,
  0,0,0,0,
  0,0,0,0
 }
 
 rectfill(0,64,127,67,0)
 line(0,68,110,68,0)
 line(123,68,127,68,0)
 for y=5,h-2 do
 
  xo = 0
--  xo += (y-t/4)%2.5
  xo += cos((y+t*0.1)*0.7)*1.5
  
  local gy
  gy = 96+8+((h-1)-y)
  
  if (64+y-camy < 128) then
  for x=0,127,1 do
   val=sget(x+xo, 
    gy + cos(x*0.2)*0.5)
   pset(x,64+y, dcol[val])
  end
  end
  
 end
 
 -- orbs
 
 camera()
 foreach(orb, calc_orb)
 
 local pass=0
 local num = 1
 while (num > 0 and pass<2) do
  num = sort_orbs()
  pass += 1
 end


 -- reflecton 
 opass=0
 foreach(orb, draw_orb)

 opass=1
 foreach(orb, draw_orb)
 
 
 -- whitewash chaser
 
 if (t > 1360) then
  local y=(t-1360)*1.1
  rectfill(0,0,127,y,
   0)
   
  line(0,y+2,127,y+2,0)
  
 end
 
end

function _init()
 load_gfx(3, 64+32+8)
 load_gfx(2, 24) -- orby logo

 -- clear first three rows
 memset(0,0,64*25)
 memset(64*93,0,64*4)
 
 for y=23,95 do
  for x=127,0,-1 do
   sset(x,y,sget(x-1,y))
  end
 end
 
 --black mask

 for y=23,98 do
  for x=0,127 do
   local cl,cr,cu
   cl=sget(x-1,y)
   cr=sget(x+1,y)
   cu=sget(x,y-1)
   
   local c=0
   if (cl!=0 and cl!=12) c+=1
   if (cr!=0 and cr!=12) c+=1
   if (cu!=0 and cu!=12) c+=1
   
   if (c>0) then
    if(sget(x,y)==0) then
     sset(x,y,12)
    end
   end
   
  end
 end

 make_orbs()
 
 msp={}
 for i=0,4095 do
  msp[i]={-50,-50,0,0,0,0}
 end
 mspi=1

 -- play music after init
 -- to avoid accidental desync

music(mpat)

end


function draw_orby_logo()

 t0 = t- 95 --180
 
-- if (t0 < 0) return
 
 if (t0 > 280) return

 local yo = 0
 local exitt = 220 -- 160
 
 if (t0 > exitt) then
   yo-=(t0-exitt)*3
 end
 
 if (yo < -69) return
  
 
  y1=0+t0
  y1=mid(-1,y1,68)
 
  for i=1,15 do pal(i,0) end
  
  h=y1+1
  
  --[[
  sspr(0,32,112,69,12+1,yo+3,112,h)
  sspr(0,32,112,69,12-1,yo+3,112,h)
  sspr(0,32,112,69,12,yo+4,112,h)
 ]]
 
 pal()

 
--[[
 for y=0,y1 do
  local mag=(30+y-t0)
  mag=mid(0,mag/15,1)
  
  local xo=cos(t0*0.1+y*0.17)*mag*10
  local yo2=cos(t0*0.24+y*0.1)*mag*20
  
  if (mag < 1) then
  sspr(0,32+y,112,1,
  12+xo,2+y+yo2+yo,112,1)
  end
  
 end
]]

pal(12,0) -- black mask

local h=t0-30
h=mid(0,h,70)
if (h > 0) then
 sspr(0,24+70-h,112,h,
   12,72-h+yo,112,h)
 if (h < 70) then
  
  for x=0,112 do
   local col=sget(x,24+69-h)
   if (col != 0) then
   --line(12+x,2+h,12+x,72,col)
   line(12+x,2,12+x,71-h,col)
   end
  end

 end
end


pal()
-- sspr(0,32,112,69,12,2,112,69)
end



loaded=false
function draw_marine()

 if (not loaded) then
  reload()
  for i=0,15 do pal(i,0,1) end
  load_gfx(4,-128)
  memcpy(0x0,0x6000,0x2000)
  
  loaded=true
  cls() pal()
 end
 
 
  if (t >= 1600) then
   -- faster
   -- need to give alien
   -- probe thing cpu
   local t0=t-1778
   t0=mid(0,t0,64)
   for y=0,63-t0 do
    memcpy(0x6000+y*64,
           0x0000+y*64,
           64)
    memcpy(0x6000+(127-y)*64,
           0x0000+(127-y)*64,
           64)       
   end
   
  else

  for y=0,7 do
   for x=0,7 do
    t0 = t-1500
    
    t0-=(x*2+y)
    t0-=((x+13)*(y+103)*12)%15
    
    local a=t0 / 16
    a = min(a,1.25)
    
    w=abs(sin(a))*16
    if (t0 < 0) w=0
    
    w *= a/1.25
    h = 16 * a/1.25
    --w = min(16, t0*1)
   
    if (w > 0) then
    
     if (a > 0.5 and a < 1) then
      local col = 7
      local q = abs(a-0.6)*4
      if (q > 0.1) col=6
      if (q > 0.2) col=13
      if (q > 0.4) col=5
      if (q > 0.7) col=1
      
      f = rectfill
      if (col==7) f=rectfill
       
      f(
       x*16+8-w/2,
       y*16+8-h/2,
       x*16+8+w/2,
       y*16+8+h/2,
       col)
     
     else
     
      sspr(x*16,y*16,16, 16,
       x*16 + 8-w/2,
       y*16 + 8-h/2,
       w,h)
     end
    end
    
   end
  end
  end
  
  local s={
   "",
   "c█   xe ",
   "castpixel",
   "castpixel",
   " a  🐱x",
   "  zep ",
   "  zep ",
   ""
  }
  local start_t=1540
  local slen=30
  if (t >= start_t 
   -- and t <= start_t+slen*6.1
  ) 
  then
   local i=(t-start_t)/slen
   
   local t0=(i%1)
   i = flr(i)
   --if (i==1 or i==5) t0=1
   i=mid(1,i,#s)
   
   x0 = 120-(t-start_t)/2
   if (true) then
    print(s[i],x0,1,7)
    for j=0,(0.5-t0)*140 do
     local x=i*18+rnd(18*4)
     x=x0-2+rnd(18*4)
     local y=rnd(6)
     
     --circfill(x,y,1,pget(x,y))
     local col=pget(x,y)
     line(x-4,y,x+4,y,col==0 and 0 or 13+rnd(3))
     line(x-2,y,x+2,y,col)
    
    end
   end
  end
  
  cmap=
  {
   [0]={0,0,0,0},
   {1,0,0,0},
   {2,2,1,1},
   {3,3,1,2},

   {4,1,1,1},
   {5,2,1,0},
   {6,13,5,5},
   {7,6,13,6},

   {8,13,2,2},
   {9,4,2,2},
   {10,9,4,4},
   {11,11,6,3},

   {12,12,13,1},
   {13,13,5,5},
   {14,8,13,2},
   {15,15,14,13}
   
  }
  
  -- pixel circle
  t0=t-1640
  if (t0 > 0 ) then
  
   -- make sure completes before
   -- fadeout -- no cpu
   cx = -48+(t0)*1.8
   cy = 80+(t0)*0.2
  
   if (cx < 128+32) then
--   if (t < 1790) then
   for y=0,127,2 do
   for x=0,127,2 do
   
    local i=1
    local dx = cx-x
    local dy = cy-y
    
    local d = dx*dx+dy*dy
    
    
    if (d > 32*32) then
     i=1
    elseif (d < 16*16) then
     i=4
    elseif (d < 24*24) then
     i=3
    else
     i =2
    end
    
    if (i > 1) then
    rectfill(x,y,x+1,y+1,
     cmap[pget(x+(t0%2),y)][i])
    end
    
   end
   end
   end
  
   circfill(cx,cy,5,12)
   circfill(cx,cy,4,7)
   
   for i=0,1,0.33 do
   
   circfill(cx+cos(i+t*0.02)*4,
        cy+sin(i+t*0.02)*4,2,7)
   
   end
  
  end
  

  -- fade out
  
  
  -- 1790
  if (t > 1780) then
   t0=t-1780
   t0=min(t0,64)
   
   -- don't need -- just don't
   -- draw whole marine above
   --rectfill(0,64-t0,127,64+t0,0)
   
   -- sparkles
   
   -- make some sparkles
   t0+=2
   		
   local start_y = 64+t0
   if (flr(t)%2 == 0) start_y=63-t0
   
   for j=t%2,127,2 do
   
    local sp=msp[mspi] 
    mspi=(mspi+1)%1800
    
    sp[1]=j 
    sp[2]=start_y
    
    -- colour and size
    sp[5]=sget(j+1,sp[2])
    --sp[5]=cmap[sp[5]][3]
    sp[6]=1.2 +rnd(1)
    
    -- velocity
    sp[3]= cos(j*0.01+t0*0.05)*2
    
    sp[4] = 0--sgn(64-sp[2])*0
    
   end
   
   -- draw sparkles
   for j=0,1800-1 do
    local sp=msp[j]
    --pset(sp[1],sp[2],8)--sp[5])
    
    if (sp[6] >= 0) then
    rectfill(
     sp[1],sp[2],
     sp[1]+sp[6],sp[2]+sp[6],
     sp[5])
    end
    
    sp[1]+=sp[3]
    sp[2]+=sp[4]
    sp[6]-=0.1
    
   end
   
  end
  
end
  
  
function disco_module()

local t=0
local dd=0

-- disco init
local function _init()
 pal()
 pl={}
 pl.x = 12 pl.y = 20
 pl.z = 12
 pl.d = 0.25
 pl.dz = 0
 pl.jetpack=true
 
 
 -- load font
 reload()
 load_gfx(9,32)
 
 
 -- clear start of spritesheet
 
 
 memset(0x0,0,0x800)
 
 for y=0,32 do
 for x=0,32 do
  if (x==0 or x==31 or 
      y==0 or y==31) then
   mset(x,y,15)
  else
   mset(x,y,0)
  end
 end
 end
 
end

function mc(x,y)
 return mget(x,y)
end

function mz(x,y)
 local col=mget(x,y)
 return 16-col*0.2
end


-- disco update
local function _update()

  t+= 1
 
  for i=0, 40 do
   x=rnd(28)+2
   y=rnd(28)+2

   col = 0
   local p=10
   if (t > 200) then
    p = 4
    --col=sget(x,y)
    --if (col==0) col=12
    if (rnd(10) < 1) then
     col=8+rnd(7)
    end
    
   end
   
   if (rnd(p) < 1) then
    col=12+rnd(3)
   end
   
   sset(x,y,col)
   
   if (t < 200) then
   if col != 0 then
    sset(x+1,y,7)
   end
   end
   
  end

 
 pl.x = 16 + cos(-t*0.005)*4
 pl.y = 16 + sin(-t*0.005)*4
 pl.d = (-t*0.005)+0.5
 

 -- z means player feet
 if (pl.z >= mz(pl.x,pl.y) and pl.dz >=0) then
  pl.z = mz(pl.x,pl.y)
  pl.dz = 0
 else
  pl.dz=pl.dz+0.005 -- weak gravity
  pl.z =pl.z + pl.dz
 end

 if (t > 300 and t < 330) then
   pl.dz=-0.02
 end
 
 -- jump out at end
 if (t > 570+pat2) pl.dz -= 0.015
 
end


function draw_3dsp(x,y,r,a,c)
	    
	--circfill(x,y,1,c)
	
 line(x+cos(a)*r,y+sin(a)*r,
      x-cos(a)*r,y-sin(a)*r,
      c)

--[[
 a+=0.25
 r*=3
 
 line(x+cos(a)*r,y+sin(a)*r,
      x-cos(a)*r,y-sin(a)*r,
      c)
      
 pset(x,y,7) -- always white
]]
end

    
function draw_3d_sparkles(h)

 local a0 = pl.d
 
 srand(0)
 local start_t=350 -- 350
 local len = mid(-1,(t-start_t)/3,40)
 
 if (t >= 580) then
  
   len -= (t-580)
 end
  
 --local len = 15 + sin(t/200)*10
 
 for j=1,200,50 do
	 for i=j,j+len,1 do
	 
	  local a=rnd(1)+a0
	  local r=rnd(4)
	  local y=rnd(1)-0.5
	  
	  local q=i/200
	  
	  -- stop moving at 450
	  q += min(t,450)/400
	  
	  a = a0+q*2
	  r = 2+cos(q*3)*1.5
	  y = cos(q*5)*0.5
	  
	  local x=cos(a)*r
	  local z=2+sin(a)*r
	  
	  if (z > 0.1) then
	    
	    local sx=64+x*64/z
			  local sy=h+ y*64/z
			  local sr= 5/z
	    local c=7
	    --if (z > 2)c=13
	    if (z > 3)c=13
	    
	    --if (c==7 and 
	    --if (c==7) c=8+z
	    
	    draw_3dsp(sx,sy,sr,
	      q*4, c)
	    
			  --circ(sx,sy,sr,c)
	  end
	 
	 end
 end

end

function draw_3d(horizon)
 dd = 1-dd
 local celz0
 local col
 -- calculate view plane (line)

 local v={}
 v.x0 = cos(pl.d+0.1) 
 v.y0 = sin(pl.d+0.1)
 v.x1 = cos(pl.d-0.1)
 v.y1 = sin(pl.d-0.1)


 for sx=0,127,2 do

  sy=127

  -- camera based on player pos
  x=pl.x
  y=pl.y
  z=pl.z-1 -- 1 unit high

  ix=flr(x)
  iy=flr(y)
  tdist=0
  col=mget(ix,iy)
  celz=16-col*0.2
  
  -- calc cast vector
  local t=sx/127
  vx = v.x0 * (1-t) + v.x1 * t
  vy = v.y0 * (1-t) + v.y1 * t
  dir_x = sgn(vx)
  dir_y = sgn(vy)

  skip_x = 1/abs(vx)
  skip_y = 1/abs(vy)

  if (sgn(vx) > 0) then
   dist_x = 1-(x%1) else
   dist_x =   (x%1) end
  if (sgn(vy) > 0) then
   dist_y = 1-(y%1) else
   dist_y =   (y%1) end

  dist_x = dist_x * skip_x
  dist_y = dist_y * skip_y

  -- start skipping
  skip=true
  skips=0

  while (skip) do
   local gcol = sget(ix,iy+8)
   skips += 1
   if (dist_x < dist_y) then
    ix=ix+dir_x
    last_dir = 0
    dist_y = dist_y - dist_x
    tdist = tdist + dist_x
    dist_x = skip_x
   else
    iy=iy+dir_y
    last_dir = 1
    dist_x = dist_x - dist_y
    tdist = tdist + dist_y
    dist_y = skip_y
   end
   
   
   -- prev cel properties
   col0=col
   celz0=celz
   -- new cel properties
   col=mget(ix,iy)
   celz=16--16-col*0.2


--   print(ix.." "..iy.." "..col)
    
   if (col==15) then skip=false end

   if (tdist > 20) skip=false
   --discard close hits
   if (tdist > 0.1) then
   -- screen space

   local sy1 = celz0-z
   
   
   sy1 = (sy1 * 64)/tdist
   sy1 += horizon 
   
   -- wall: only if far
   --[[
   if (gcol == 13 and 
       tdist > 5) then
     gcol=7 sy1 = 64
   end
   ]]
   
   -- draw ground to new point
   if (sy1 < sy) then
    --line(sx,sy1-1,sx,sy,col0)
 
    --dd = 1-dd
    if (gcol != 0 or true)
    then
    line(sx+dd,sy1-1,sx+dd,sy,gcol)
    
    --[[
    if (gcol != 0) then
     if (gcol==7) 
     then
      gcol=13
     else
      gcol=1
     end
    end
    ]]
    
    line(sx+dd,127-(sy1-1),sx+dd,    
    127-sy,gcol)
    
    end
    
    sy=sy1
   end

   
  end   
  end -- skipping
  
  -- remaining floor: black
  if (sy >  64) then
   line(sx+dd,127-sy,sx+dd,sy,0)
  end
 end -- sx

end


 
-- disco draw

local function _draw()

 local h=68
 h+=mid(0,(t-300)/2,12)
 
 if (t > 300) then
  for i=1,min(15,(t-200)/10) do 
   pal(i,i/6) end
 end

  draw_3d(h)

 pal()
 
 rectfill(0,63-7,127,63+7,0)
 
 local r=rnd() -- backup
 draw_3d_sparkles(68)
 srand(r)
end

 return _init, _update, _draw

end



function draw_card(which,tt0)

local t0 =t - tt0


if (t0 > 200) then return end

--rectfill(0,0,20,20,rnd(16))

if (which == 2 and t0 > 120) then
 for i=0,100 do
  poke(rnd(0x4000),rnd(256))
 end
end

q= mid(0,64-t0*1.6,64)
q= q*q/64
q= q*q/64
q= mid(0,q-2, 64)

x2=64
if (t0 < 40) then
 spr(0, 0-q ,16
 + sin(q*0.007)*5
 , 8,6)
 spr(8, 0-q ,16+48
 + sin(q*0.007)*5
 , 8,6)
else

 -- spin
 a = (t0-40)/20
 a = min(a,0.5)
 w = cos(a)*32
 h = 96
 
 src=0
 if (w<0) src=64
 
 x0=0
 
if (t0 > 160) then
x0 -= (t0-160)*4
end
 
 if (which == 2) then
  x0=0
 end
 
 palt(0,false)
 sspr(0,src,64,48,
  x0+32-abs(w),16,abs(w)*2,h/2)
 sspr(64,src,64,48,
  x0+32-abs(w),16+h/2,abs(w)*2,h/2) 

 x2 += sqr(t0-40)
 
end


-- card on right

spr(0, x2+q,16    - sin(q*0.007)*5 , 8,6)
spr(8, x2+q,16+48 - sin(q*0.007)*5 , 8,6)

color(7)


if (t0 > 90) then
 if which==2 then
  pr("attack +3",-x0*3+75,50,13)
 else
  pr("tech +2",-x0*3+75,50,13)
 
 end
end

if (t0 > 100) then
 if which==0 then

  pr("wormhole",-x0*3+75,70,7)
 
 elseif which == 1 then
  pr("plasma",-x0*3+75,70,6)
 else
  pr("glitchy",-x0*3+75,70,6)
  pr("sword",-x0*3+75,80,6)
 
 end
end



end



function worm_module()

cx=0
cy=0
cdx=0
cdy=0

local t = 0
ri={}
glib=0

function draw_poly(p, num, col)

p[0]={}
p[0].x = p[num].x
p[0].y = p[num].y

if (col >= 16) then
for i=1,num do
 
 line(p[i-1].x,p[i-1].y,
      p[i].x,p[i].y, col)
  end
 
return
end


top = 0 bot = 0
for i=1,num do
 if (p[i].y < p[top].y)
 then top=i end
 if (p[i].y > p[bot].y)
 then bot=i end
end

local l = (top + num-1) % num;
local r = top;

local xl = p[r].x
local xr = p[r].x


dxl =  p[l].x-p[l+1].x
dxl /= p[l].y-p[l+1].y

dxr = p[r+1].x-p[r].x
dxr /= p[r+1].y - p[r].y

py = p[top].y + 0.5
--py = p[top].y --anti-hole hack

while (true) do

 next_stop = p[l].y
 
 if (p[r+1].y < p[l].y) then
  next_stop = p[r+1].y
 end
  
 for blah=py,next_stop do

  line(xl, py, xr, py, col)
  
  
  xl += dxl
  xr += dxr
  py += 1

 end
 
 -- find next
 if (p[l].y < p[r+1].y) then
 
  if (l == bot) then
   return
  end
  l=(l+num-1)%num
  xl=p[l+1].x
  dxl = p[l].x-p[l+1].x
  dxl/= p[l].y-p[l+1].y
  xl += dxl * (py-p[l+1].y)
 else
  r=(r+num+1)%num
  if (r == bot) then
   return
  end
  
  xr=p[r].x
  dxr = p[r+1].x-p[r].x
  dxr/= p[r+1].y-p[r].y
  xr += dxr * (py-p[r].y)
 end
 
 
end


end

p0 = {{},{},{},{}}

local function _update()
 t += 1
 
 for i=#ri,1,-1 do
  ri[i].z -= 0.12
  ri[i].a -= cos(t*0.001)*0.01
  
 end
 
 
 while (ri[1].z < 0.5) do
  
   local tmp = ri[1]
   
   -- move everything up
   for j=1,#ri-1 do
    ri[j]=ri[j+1]
   end
   
   -- add new ring
   glib+=1
   
   ri[#ri] = tmp
   
   local r = ri[#ri]
   
   r.z = ri[#ri-1].z+1
   r.a = ri[#ri-1].a-- -1/32
   
   r.x = cos(glib*0.04)*0.5
   r.y = cos(glib*0.03)*0.3

--   r.x=0 r.y=0
   
   -- twist
   r.a -= 0.02 * cos(glib*0.05)
   
   for j=0,15 do
    r.col[j] = 1
    if (rnd(4) < 1) then
     r.col[j]=7
    end
    if (glib%10)==0 then
     r.col[j]=14
    end    

   end
   
   if (t > 440) then
    for j=0,15 do
     r.col[j]=0
    end    
   end

if (t < 160)  then
for j=0,15 do
r.col[j]+=16   
end end
   
 end
 
 local q =0.003
 if (cx < ri[1].x - 0.1) cdx+=q
 if (cx > ri[1].x + 0.1) cdx-=q
 cx += cdx
 cdx *= 0.95
 
 local t=ri[#ri].z-0.5

--t=1
--cx=ri[1].x*(t)+ri[2].x*(1-t)
 
  
end

z = 0

local function _draw()

-- cls()
 
 dz = 0.5
 ao=0
  
  

 for i=#ri-1,1,-1 do
 
 -- draw ring
 
  q=1/32
  
  local coli=0
  
  for a=0,1-q,q*2 do

   local a0 = ri[i].a + a
   local a1 = ri[i+1].a + a
   
   local z0 = ri[i].z
   local z1 = 
    z0*0.75+ri[i+1].z*0.25
   --local z1 = ri[i+1].z
  
   p0[1].x = cos(a0) + ri[i].x
   p0[1].y = sin(a0) + ri[i].y
   p0[2].x = cos(a0+q)+ri[i].x
   p0[2].y = sin(a0+q)+ri[i].y
   p0[3].x = cos(a1+q)+ri[i+1].x
   p0[3].y = sin(a1+q)+ri[i+1].y
   p0[4].x = cos(a1)  +ri[i+1].x
   p0[4].y = sin(a1)  +ri[i+1].y
   
   -- transform into screen space
   for v=1,2 do
    p0[v].x = (p0[v].x-cx)*64/z0+64 
    p0[v].y = (p0[v].y-cy)*64/z0+64
   end
   for v=3,4 do
    p0[v].x = (p0[v].x-cx)*64/z1+64 
    p0[v].y = (p0[v].y-cy)*64/z1+64
   end
   
   if (i > 6) then
   draw_poly(p0,4,bor(16,ri[i].col[coli]))
   else
   draw_poly(p0,4,ri[i].col[coli])
   end

   coli+=1
   
  end
 
 
 end 

-- print(stat(1),0,0,7)

end

local function _init()

 x={}
 y={}
 
 for i=1,10 do
  ri[i]={}
  ri[i].a = 0
  ri[i].x = 0
  ri[i].y = 0
  ri[i].z = i 
  ri[i].col={}
  for j=0,15 do
   ri[i].col[j] = 0
  end
 end


end


return _init, _update, _draw

end


ppa = 64.7
ppb = 64
ppc = 0

function draw_plasma(w)

 
-- draw balls to draw onto
  
 bcol={0xff,0x99,0x33,0x11,0xee}
 
 q=1 w1=3
 if (w < 2) q = w
 if (w > w1) q = 1-(w-w1)
 q = mid(0,q,1)
 
 hh=flr(4+q*31)*64
 

 local p=0
 
 
 if (flipper==nil) flipper=0
 flipper = 1-flipper
 if (q > 0) then
  for i=0x6000+flipper,0x7fff,2 do
   poke(i, band(p,0x33)+0xcc)
   
  p=p+cos(i/ppa )
  p=p+cos(i/ppb)*ppc 

  end
 else
  cls()
  --rectfill(0,0,127,127,3)
 end
 
 ppa=ppa+0x0.0072
 ppb=ppb-0x0.002
 ppc+=0.03
  
 -----
 --if (true) return
 
 
 -- black circles for transition
 
 -- w -1.5 .. ~4
 
 local q=w
 q=1 w1=3
 if (w < 2) q = w
 if (w > w1) q = 1-(w-w1)
 --q = mid(0,1-q,1)
 q = 1-q
 
 -- radial transition
 for y=-1,16 do
 for x=-3,16 do
  xx=x*8
  yy=y*8
  d=sqrt((x-7.5)^2+(y-7.5)^2)
  r=q*15 - 11 + d
  r = mid(0,r,8)
  if (r == 8) then
  
   rectfill(xx-1,yy-1,xx+8,yy+8,0)
  elseif (r > 0) then
   xx += (y%2)*4
   
   --xx += cos(y*0.1+t*0.1)*2
   
   circfill(xx+3,yy+3,r,0)
   --rectfill(xx+3-r,yy+3-r,
   --         xx+3+r, yy+3+r, 0)
  end
  
 end
 end
 
end


-- w 0..1
function draw_plasma2(w)

-- if (w < 0.01) return

 q=0
 w *= 400
 
 
 --pink
 circfill(64,64,w,max(0,0xcc-q))

 -- orange
 --circfill(64,64,w*0.5,max(0,0x77-q))

 
 w2 = max(w-10,0) 
 
 for i=1,10 do
 
  x = cos(i*0.1)+cos(i*i*0.1)
  x += cos((t+i*33)*0.003)
  
  x = 64 + x*w2/5
  
  y = sin(i*0.21)+sin(i*i*0.15)
  y += sin((t+i*55)*0.004)
  
  y = 64 + y*w2/5
  
  circfill(x,y,5+min(w2/6,30),0x77)

 end
 
  -- black
 if (w > 300) then
  circfill(64,64,max(w-300),0)
 end


 ppa=ppa+0x0.0010
 ppb=ppb-0x0.0008
 

 local p=0
 
 local z = 0
 z = 8+flr((t/40))%5
 z = z + z*16
 
 --for i=0x6000,0x6000+(flr(t)%3)
 --do
 -- p=p+
 --  (cos(i/ppa)+cos(i/ppb)*ppc)
 --  *(flr(t)%3)
 --end
 
 if (false) then
  for i=0x6000,0x7fff-2,2 do
   if (peek(i) != 0) then
   
    local val=band(p, 0x33) +
      peek(i)
      
      poke(i, val)
      poke(i+1, val)
      --poke(i+2, val)
   end  
  p=p+cos(i/ppa)*3
  end
 
 end
 --print(stat(1),2,2,rnd(16))

-- pal(12,0,1)


end


function draw_outro()
 cls()

 t0=t-(3900+pat2)

 for y=32,95 do   

  q = 60-t0
  q /= 60
  q = mid(0,q,1)
  q = q*q
  
  sspr(0,y,128,1,
  cos(t*0.03+y*0.04)*180*q,
  
  y,128,1)
 end

str =

[[
greetings tokyo demo fest
and pico-8 peeps!

we hope you enjoyed the
post-compo version of our
first pod production.

with castpixel on pixels +
sfx, and zep on code + sfx
 ** 
this was first released at
tdf 2016, but was
missing a few details like
spriteball shadows..
or are they reflections? 
who knows.
                  
see you next time <3 <3
   -pod                         
\(^ _ ^)/ weeeee
]]


 for i=1,#str do
  local cc=sub(str,i,i)
  print(cc, 
  180-t0*1.5 + i*4, 
  110 + cos(i*0.05+t0*0.02)*3, 
   8+(i%8))
 end

end


function _draw()
 
 -- 167
 if (t<50) then
  cls()
  draw_pod_intro()
 elseif (t<1500) then
  cls()
  draw_orb_dance()
  
  draw_orby_logo()
 elseif (t < 1930) then --1900
  cls()
  draw_marine()
  
 elseif (t < 2600+pat2) then
 
  if (disco.init == nil) then
  
   -- remove marine sparkles
   -- (stay inside 512k pre-0.1.6)
   msp=nil
  
   disco.init, disco.update,
   disco.draw = disco_module()
   
   disco.init()
   
  end
  
  disco.update()
  disco.draw()
  
 local t0=t-2065
 
 
 elseif (t < 3170+pat2) then
  cls()
  
  if (card_inited == nil) then
   card_inited = true
   reload()
   load_gfx(5,0)
   load_gfx(6,64)
   worm ={}
   worm.init , worm.update ,
   worm.draw = worm_module()
   worm.init()
  end
  
  cls()
  if (t > 2640+pat2 and worm) then
   worm.update()
   worm.draw()
  end
  
  -- sleen tech
  draw_card(0,2600+pat2)
  
 elseif (t < 3660+pat2) then
 --cls() -- ()(
 
 --[[
  if (t < 3200+pat2 and worm) then
   --()(
   worm.update()
   worm.draw()
  else
 ]]
   local q=t-(3330+pat2)
   
   draw_plasma(q / 80)
 -- end
  
  if (card_inited1 == nil) then
   card_inited1 = true
   reload()
   load_gfx(5,0)
   load_gfx(7,64)
   
  end
  
  -- gromlin tech
  draw_card(1,3170+pat2)
 
 elseif (t < 3900+pat2) then
 
 cls()
  
  if (card_inited2 == nil) then
   card_inited2 = true
   reload()
   load_gfx(5,0)
   load_gfx(8,64)
   
  end
  
  -- glitch sword
  draw_card(2,3660+pat2)
  
 
 else
  if (inited_outro==nil) then
   memset(0,0,0x4300)
   reload()
   pal()
   
   load_gfx(1,32)
   music(40)
   inited_outro=true
  end
  draw_outro()
 end
 

 if (t > 5120+pat2) then
  stop()
 end


 -- debug info
 if (debug_info) then
 rectfill(0,0,32,6,0)
  color(7)
  print(stat(1),0,0)
  print(stat(0),0,8)
  print(t,0,16)
  if (stat(1) >= 1) then
   rectfill(60,1,126,3,8+rnd(2))
  end
 end
 
 --pr(tostr(stat(1)),2,2,rnd(16))


end



-->8
-- 5x6 font by zep
--
-- see snippets:
-- lexaloffle.com/bbs/?pid=font_5x6

-- alphabet. pairs that end
-- in a space can be expressed
-- as a single char when passed
-- to pr()


skinny="i"
wide="mntvwxz"

alph="  ! \" # $ % & ' ( ) * + , - . / "..
"0 1 2 3 4 5 6 7 8 9 : ; < = > ? "..
"@ a b c d e f g h i j k l m n o p q r s t u v w x y z "

function font_init()

 -- trimmed unused characters
 -- many still in original font
 s =[[  0000.0000! 739c.e038" 5280.0000# 02be.afa8$ 23e8.e2f8% 0674.45cc& 6414.c934' 2100.0000( 3318.c618) 618c.6330* 012a.ea90+ 0238.8000, 0000.0330- 0000.e000. 0000.0030/ 3198.cc600 f4a5.2f001 e108.4f002 f0bd.0f003 f0bc.2f004 94bc.21005 f43c.2f006 f43d.2f007 f084.21008 f4bd.2f009 f4bc.2100: 0300.0600; 0300.0660< 0199.8618= 001c.0700> 030c.3330? f0c6.e030@ 746f.783ca f4bd.2900b e4b9.2e00c f421.0f00d e4a5.2f00e f439.0f00f f439.0800g f42d.2f00h 94bd.2900i e210.8e00j f108.4e00k 9531.4900l 8421.0f00m 8eeb.1880n 8e6b.3880o 64a5.2600p f4bd.0800q 64a5.6700r f4bd.4900s f43c.2f00t f908.4200u 94a5.2600v 8c62.a200w 8c6b.b880x 8a88.a880y 94bc.2f00z f888.8f80]]

 -- build fcmap
 fcmap={}
 for i=0,#s/11 do
  local p=1+i*11
  fcmap[sub(s,p,p+1)]=
   tonum("0x"..sub(s,p+2,p+10))
 end
end

function pr(str,sx,sy,col)
 local sx0=sx
 local p=1
 while (p <= #str) do
  local c=sub(str,p,p)
  local v 
  
  if (c=="\n") then
   sy += 9 sx=sx0 
  else
	  -- match single first
	  v = fcmap[c.." "] 
	  if not v then 
	   --look for double char (`a)
	   v= fcmap[sub(str,p,p+1)]
	   p+=1
	  end

   local sy1=sy
   if (band(v,0x0.0002)>0)sy1+=2
   
   
   for y=sy1,sy1+5 do
	   for x=sx,sx+4 do
	    if (band(v,0x8000)<0) then
	     pset(x,y,col)
	     
	    end
	    v=rotl(v,1)
	   end
	  end
	  
	  sx+=5
	  for i=1,#skinny do
	   if (v==sub(skinny,i,i)) sx-=1
	  end
	  for i=1,#wide do
	  
	   if (c==sub(wide,i,i)) sx+=1
	  end
	  
  end
  p += 1
 end

end
font_init()
