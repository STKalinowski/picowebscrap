-- get out of this dungeon
-- insanus + god

debug=false
time_count=false

function _init()
 t_delay=0
 t_reverse=false
 flicker=0
 lightning=0
 _update = menu_update
 _draw = menu_draw
 init_zombies()
 init_slimes()
 music(46,100,-1)
end

function thunder()
 lightning += 1
 if(lightning > 100) and
 (lightning < 105) or
 (lightning > 108) and
 (lightning < 115) then
  pal(0,0,1) pal(1,7,1) pal(2,7,1)
  pal(3,0,1) pal(4,7,1) pal(5,7,1)
  pal(7,7,1) pal(8,7,1) pal(9,7,1)
  pal(10,7,1) pal(11,7,1) pal(12,7,1)
  pal(13,7,1) pal(14,7,1) pal(15,7,1)
  if(lightning == 101) sfx(48,-1)
 end
 if(lightning > 400) lightning = 0
end

function menu_update() 
 if(btn(4) and btn(5))
 and(t_delay==40) then
  t_reverse=true
  music(-1,300)
  music(0,300,0)
  sfx(61)
 end
 if(t_delay==0)
 and(t_reverse==true) then
  t_delay=0
 	t_reverse=false
 	_update = game_update
 	_draw = game_draw
 end
end

function menu_draw()
 cls() 
 color_transition()
 map(112,48,0,0,16,16)
 
 snow_part(1,rnd(128),rnd(28)-28)
 lava_sparks(rnd(1)-0.8,rnd(16)+36,120)
 lava_sparks(rnd(1)-0.8,rnd(16)+80,120)
 
 flicker += 1 
 if(flicker <= 16) then
  print("press 🅾️ + ❎ to start",21,110,7)
  print("🅾️",45,110,12)
  print("❎",65,110,8)
 end
 if(flicker >= 32) flicker = 0
 
 print("v1.1",4,85,(flicker/4)+8)

 thunder()
end

p={
 --start position
 x=444,y=352,
 --first checkpoint
 cpx=51,cpy=43,
 --last checkpoint
 last_cpx=51,last_cpy=43,
 
 door=false,alive=true,
 speed=0,grav=3,armor=0,
 deathcount=0,death=0,
 jumps=0,jumpsmax=1,
 shake=0,heat=0,
 punch=false,punch_delay=0,
 dash=false,

 score=0,spider=0,key=0,
 gem1=0,gem2=0,gem3=0,
 gem4=0,gem5=0,gem6=0,
	msg_delay=0,msg_type=0,
	
 dirx=false, move=false,
 pcol=true, --allow collisions
 walk={
  first_i=2, start_i=2,
  size=4, speed=1/3,
 },
 punch_anim={
  first_i=4, start_i=4,
  size=3, speed=1/3,
 },
 cpfire={
  first_i=9, start_i=9,
  size=2, speed=1/3,
 },
 fire1={
  first_i=45, start_i=45,
  size=2, speed=1/3,
 },
 fire2={
  first_i=46, start_i=45,
  size=2, speed=1/3,
 }
}
--arrow
arw={ 
 speed=2, delay=60
}
--timer
t={
 ms=0, s=0, m=0
}

function timer()
 if(t.ms <= 60) t.ms+=2
 if(t.ms >= 60) then
  t.ms=0
  t.s+=1
 end
 if(t.s >= 60) then
  t.m+=1
  t.s=0
 end
end

--btn(4)=jump
--btn(5)=action
function controls() 
 local lx=flr((p.x+2)/8)*8
 //local lx=flr(p.x)
 if(p.alive) then
 	--ice inertia
  if(ice) then
   if(btn(0))
   and(p.speed<2) then
   	p.speed+=0.2
   	p.x-=flr(p.speed)
   	p.dirx=true
   elseif(p.dirx==true)
   and(p.speed>0) then
    p.x-=p.speed
    p.speed-=0.2
   end
   if(btn(1))
   and(p.speed<2) then
   	p.speed+=0.2
   	p.x+=flr(p.speed)
   	p.dirx=false
   elseif(p.dirx==false)
   and(p.speed>0) then
    p.x+=p.speed
    p.speed-=0.2
   end
  else --default speed
   if(btn(0)) then
   	p.speed=2
   	p.x-=p.speed
   	p.dirx=true
   end
   if(btn(1)) then 
   	p.speed=2
   	p.x+=p.speed
   	p.dirx=false
   end
   if(p.move) then
    p.speed=2
   else 
    p.speed=0
   end
  end
 
  if((btn(0) or btn(1))==true) then
   p.move=true
  else
   p.move=false
  end 
 end
 if(collision(0))
 or(collision(1))then
  p.x=lx
  p.move=false
 end
end

function gravity() --and jump
 local ly=flr((p.y+2)/8)*8 --last y
 p.y+=p.grav
 if(collision(0))
 or(collision(2))
 or(collision(3)) then
  p.jumps=p.jumpsmax
 else
  if(p.armor==0) p.jumps=p.jumpsmax-1
 end
 if(p.alive==true) then
  --jump
  if(btnp(4)) 
  and(p.grav==3)
  and(collision(0)) then
    p.jumps-=1
   	p.grav=-7
  		sfx(49)
  end
  --multijumps
  if(btnp(4)) 
  and(collision(0)==false) 
  and(p.jumps>0) then
    p.jumps-=1
   	p.grav=-7
  		sfx(49)
  end
 end
 if(p.grav<3) p.grav+=1
 if(collision(2)) then--ice
  p.y=ly
  ground=false
  ice=true
  lava=false
 elseif(collision(3)) then--lava
  p.y=ly
  ground=false
  ice=false
  lava=true
 elseif(collision(0)) then--ground
  p.y=ly
  ground=true
  ice=false
  lava=false
 elseif(collision(1)) then--wall
  p.y=ly
 else
  ground=false
  ice=false
  lava=false
 end
 --ignore hud position
 if(cely-(16*ry)==14) p.y+=16
 if(cely-(16*ry)==15) p.y-=16
end

-- 0=ground
-- 1=walls
-- 2=ice
-- 3=lava
function collision(flag)
 col=false
 if(p.pcol) then
  colx1 = (p.x)/8
  coly1 = (p.y)/8
  colx2 = (p.x+7)/8
  coly2 = (p.y+7)/8
 	a = fget(mget(colx1,coly1),flag)
 	b = fget(mget(colx1,coly2),flag)
 	c = fget(mget(colx2,coly2),flag)
 	d = fget(mget(colx2,coly1),flag)
  col = a or b or c or d
 end
 return col
end

function checkpoint()
  if(mget(celx,cely)==8) then
  sfx(55)
  p.msg_delay=20
  p.msg_type=3
  p.cpx=celx
  p.cpy=cely
  mset(p.last_cpx,p.last_cpy,8)
  cpfire=false
  p.last_cpx=p.cpx
  p.last_cpy=p.cpy
  --hide spite to show animation
  mset(celx,cely,0)
  cpfire=true
 end
end

function punching()
 if(p.punch_delay > 0) p.punch_delay-=1
 if(p.alive) then
  if(btn(5))
  and(p.punch==false)
  and(p.punch_delay == 0) then
   p.punch_delay = 18
   sfx(50)
  end
  if(p.punch_delay >= 10) then
   p.punch = true
  else
   p.punch = false
   p.punch_anim.first_i = 4
  end
  if(p.punch) 
  and(p.punch_delay >= 14)then
   if(btn(0)) then
    p.x -= 2
   end
   if(btn(1)) then
    p.x += 2
   end
  end
 end
end

function ladder()
 if(p.alive) then
  if(mget(celx,cely)==21) then
   p.grav = 0
   if(btn(2)) p.grav =- 2
   if(btn(3)) p.grav = 2
  end
 end
end

function ice_cube()
 --ice cube x+1
 if(mget(celx+1,cely)==12) then
  if(btnp(5)) then
   sfx(62)
   make_explosion(p.x+12,p.y+4,5)
   mset(celx+1,cely,0)
  end
 end
 if(mget(celx+1,cely)==11) then
  if(btnp(5)) then
   sfx(62)
   make_explosion(p.x+12,p.y+4,5)
   mset(celx+1,cely,12)
  end
 end
 --ice cube x-1
 if(mget(celx-1,cely)==12) then
  if(btnp(5)) then
   sfx(62)
   make_explosion(p.x-4,p.y+4,5)
   mset(celx-1,cely,0)
  end
 end
 if(mget(celx-1,cely)==11) then
  if(btnp(5)) then
   sfx(62)
   make_explosion(p.x-4,p.y+4,5)
   mset(celx-1,cely,12)
  end
 end
end

function item()
 --coins
 if(mget(celx,cely)==33) then
  p.score+=1
  mset(celx,cely,0)
  sfx(51)
  p.msg_delay=10
  p.msg_type=1
	end
	--chest
	if(mget(celx,cely)==22)
	 and (btn(5)) then
  p.score+=25
  mset(celx,cely,23)
  sfx(52)
  p.msg_delay=10
  p.msg_type=2
	end
		--armor
	if(mget(celx,cely)==39) then
  p.armor=1
  p.jumpsmax=2
  mset(celx,cely,0)
  sfx(54)
  p.msg_delay=90
  p.msg_type=9
	end
	if(mget(celx,cely)==40) then
  p.armor=2
  p.jumpsmax=2
  p.heat=80
  mset(celx,cely,0)
  sfx(54)
  p.msg_delay=90
  p.msg_type=10
	end
	--gems
	if(mget(celx,cely)==52) then
  p.gem1=1 p.score+=50
  mset(celx,cely,0)
  sfx(53)
  p.msg_delay=20
  p.msg_type=4.1
	end
	if(mget(celx,cely)==53) then
  p.gem2=1 p.score+=50
  mset(celx,cely,0)
  sfx(53)
  p.msg_delay=20
  p.msg_type=4.2
	end
	if(mget(celx,cely)==54) then
  p.gem3=1 p.score+=50
  mset(celx,cely,0)
  sfx(53)
  p.msg_delay=20
  p.msg_type=4.3
	end
	if(mget(celx,cely)==55) then
  p.gem4=1 p.score+=50
  mset(celx,cely,0)
  sfx(53)
  p.msg_delay=20
  p.msg_type=4.4
	end
	if(mget(celx,cely)==56) then
  p.gem5=1 p.score+=50
  mset(celx,cely,0)
  sfx(53)
  p.msg_delay=20
  p.msg_type=4.5
	end
	if(mget(celx,cely)==57) then
  p.gem6=1 p.score+=50
  mset(celx,cely,0)
  sfx(53)
  p.msg_delay=20
  p.msg_type=4.6
	end
end

function keys()
 --key
 if(mget(celx,cely)==24) then
  sfx(56) 
  p.key+=1
  mset(celx,cely,0)
  p.msg_delay=20
  p.msg_type=5
 end
 --door x+1
 if(mget(celx+1,cely)==25) then
  if(p.key>0) and(btn(5)) then
   sfx(61)
   p.key-=1
   mset(celx+1,cely,26)
  end
 end
 --door x-1
 if(mget(celx-1,cely)==25) then
  if(p.key>0) and(btn(5)) then
   sfx(61)
   p.key-=1
   mset(celx-1,cely,26)
  end
 end 
end

function traps()
 if(p.alive) then
  --spikes = 1
  if(mget(celx,cely)==42) then
   p.death=1
   sfx(57)
  end
 --ice sprike = 2
  if(mget(celx,cely)==43) then
   p.death=2
   sfx(57)
  end
	--lava = 3
  if(lava) and(p.heat<=0) then
 	 p.death=3
 	 sfx(59)
 	end
 	if(p.armor==2) and(p.alive) then
   if(lava) then
    if(p.heat>0) p.heat-=2 
   else
    if(p.heat<80) p.heat+=0.5
 	 end
  end
 end
	--arrow = 4
	arw.speed+=2
 arw.delay-=1
 if(arw.delay==0) then
  arw.delay=60
  arw.speed=0
 end	
end

function monsters()
 --spider web
 if(mget(celx,cely)==38) then
  p.grav=1
		if(btn(0)) then
  	p.x+=1
  end
  if(btn(1)) then 
  	p.x-=1
  end
 end
	--spider
 if(mget(celx,cely)==15) then
  sfx(63)
  p.spider+=1
  mset(celx,cely,0)
	end
end

function death()
	--death	
	if(p.death!=0)
	and(p.alive==true) then
	 p.deathcount+=1
	 p.shake=10
	 if(p.death!=2) p.grav=-5
	 p.alive=false
	end
	if(p.death!=0)
 and(p.alive==false)
	and(btn(5)) then
	 if(p.armor==2) p.heat=80
  p.x=p.cpx*8
  p.y=p.cpy*8
  p.death=0
  p.alive=true
	end
end

function theend()
 if(p.gem1)==1 and(p.gem2)==1 
 and(p.gem3)==1 and(p.gem4)==1 
 and(p.gem5)==1 and(p.gem6)==1 then
  door=true
 end
 if(door) then
  if(mget(celx,cely)==94)
  or(mget(celx,cely)==95) then
   if(btn(5)) then
    t_reverse=true	 
	   music(-1,300)
    music(47,300,0)
    sfx(61)
   end
 	end
	 if(t_reverse==true) 
	 and(t_delay==0) then	 
	  t_delay=0
  	t_reverse=false
  	_update = end_update
   _draw = end_draw
	 end
 end
end

function gameover()
 if(p.deathcount >= 100) then
 	 t_delay=0
  	t_reverse=false
  	music(-1,300)
   music(47,300,0)
   _update = gameover_update
   _draw = gameover_draw
 end
end

function anim(a)
 a.first_i += a.speed
 if (a.first_i >= a.start_i + a.size) then
  a.first_i = a.start_i
 end
 return flr(a.first_i)
end

function color_transition()
 if(t_delay<40) t_delay+=2
 if(t_reverse==true) t_delay-=4
 --color transition
 if(t_delay<5) then
  pal()
  pal(1,0) pal(2,0) pal(3,0) 
  pal(4,0) pal(5,0) pal(7,0)
  pal(6,0) pal(8,0) pal(9,0)
  pal(10,0) pal(11,0) pal(12,0)
  pal(13,1) pal(14,0) pal(15,0)
 elseif(t_delay<10) then
  pal()
  pal(1,1) pal(2,1) pal(3,1)
  pal(4,1) pal(5,1) pal(7,1)
  pal(6,1) pal(8,1) pal(9,1) 
  pal(10,1) pal(11,1)
  pal(12,1) pal(13,1)
  pal(14,1) pal(15,1)
 elseif(t_delay<15) then
  pal()
  pal(3,13) pal(4,1) pal(5,1) 
  pal(7,1) pal(6,5) pal(8,1) 
  pal(9,1) pal(10,1) pal(12,1) 
  pal(11,13) pal(14,2) pal(15,14)
 elseif(t_delay<20) then
  pal()
  pal(3,3) pal(7,12) pal(8,1) 
  pal(9,12) pal(10,12) 
  pal(11,11) pal(12,12) pal(13,13)
  pal(14,13) pal(15,13)
 elseif(t_delay<25) then
  pal() 
  pal(7,8) pal(8,2) 
  pal(9,8) pal(10,8) 
 elseif(t_delay<30) then
  pal() pal(7,9) pal(10,9) 
 elseif(t_delay<35) then
  pal() pal(7,9)
 else
  pal()
 end
end

--snowflakes
snowflakes={}

function snow_part(nb,nx,ny)
 while (nb>0) do
  snow={}
  snow.x=nx
  snow.y=ny
  snow.dirx=rnd(1)-0.5
  snow.diry=rnd(1)+0.5
  snow.col=7
  snow.f=0
  snow.maxf=rnd(56)+56 --max frames
  add(snowflakes,snow)
  nb-=1
 end
 for snow in all(snowflakes) do
  snow.x+=snow.dirx
  snow.y+=snow.diry
  snow.f+=1
  if(snow.f>56) snow.col=12
  pset(snow.x,snow.y,snow.col)
  if (snow.f>snow.maxf) then
   del(snowflakes,snow)
  end
 end
end

--sparks
sparks={}

function lava_sparks(nb,nx,ny)
 while (nb>0) do
  lav={}
  lav.x=nx
  lav.y=ny
  lav.dirx=(rnd(1)-0.5)/3
  lav.diry=(rnd(1)-1)/3
  lav.col=9
  lav.f=0
  lav.maxf=rnd(16)+16 --max frames
  add(sparks,lav)
  nb-=1
 end
 for lav in all(sparks) do
  lav.x+=lav.dirx
  lav.y+=lav.diry
  lav.f+=1
  if(lav.f>rnd(12)+6) lav.col=8
  if(lav.f>rnd(16)+8) lav.col=2
  pset(lav.x,lav.y,lav.col)
  if (lav.f>lav.maxf) then
   del(sparks,lav)
  end
 end
end

--dust
dust={}
dash_dust=0

function dust_part(nb,nx,ny)
 while (nb>0) do
  d={}
  d.x=nx
  d.y=ny
  if(p.dirx) then
   d.dirx=rnd(1)
  else 
   d.dirx=-(rnd(1))
  end
  d.diry=(rnd(1)-0.5)
  d.col=(flicker/4)+8
  d.f=0
  d.maxf=rnd(12)+12 --max frames
  add(dust,d)
  nb-=1
 end
 for d in all(dust) do
  d.x+=d.dirx
  d.y+=d.diry
  d.f+=1
  if(d.f>rnd(6)+18) d.col=2
  if(d.f>rnd(12)+12) d.col=9
  pset(d.x,d.y,d.col)
  if (d.f>d.maxf) then
   del(dust,d)
  end
 end
end

zombies={
 walk={
  first_i=13, start_i=13,
  size=2, speed=1/30,
 }
}

function init_zombies()
 make_zombie(42*8,44*8)
 
 make_zombie(28*8,2*8)
 
 make_zombie(42*8,12*8)
 make_zombie(83*8,44*8)
 make_zombie(82*8,12*8)
end

function make_zombie(zx,zy)
 local zombie={}
 zombie.x=zx
 zombie.y=zy
 zombie.dirx=true
 zombie.move=0
 zombie.spd=0.5
 add(zombies,zombie)
 return zombie
end

function zombie_move()
 for z in all(zombies) do
  --zombie move
 	if(z.dirx == true) then
 	 z.x += z.spd  
 	else
 	 z.x -= z.spd  
 	end
  --zombie collisions
  if(z.dirx) then
   if(mget(flr((z.x)/8)+1,flr(z.y/8)+1)==0)
   or(mget(flr((z.x)/8)+1,flr(z.y/8))!=0) then
    z.dirx = false
   end
  else
   if(mget(flr((z.x)/8),flr(z.y/8)+1)==0) 
   or(mget(flr((z.x)/8),flr(z.y/8))!=0) then
    z.dirx = true
   end
  end 
 end 
end

slimes={}

function init_slimes()
 make_slime(8*8,54*8)
 make_slime(27*8,60*8)
 make_slime(85*8,60*8)
 make_slime(122*8,44*8)
end

function make_slime(zx,zy)
 local slime={}
 slime.x=zx
 slime.y=zy
 slime.dirx=true
 slime.move=0
 slime.spd=0.5
 add(slimes,slime)
 return slime
end

function slime_move()
 for s in all(slimes) do
  --slime move
 	if(s.dirx == true) then
 	 s.x += s.spd  
 	else
 	 s.x -= s.spd  
 	end
  --slime collisions
  if(s.dirx) then
   if(mget(flr((s.x)/8)+1,flr(s.y/8)+1)==0)
   or(mget(flr((s.x)/8)+1,flr(s.y/8))!=0) then
    s.dirx = false
   end
  else
   if(mget(flr((s.x)/8),flr(s.y/8)+1)==0) 
   or(mget(flr((s.x)/8),flr(s.y/8))!=0) then
    s.dirx = true
   end
  end 
 end
end

explosions={}

function make_explosion(x,y,nb)
 while (nb>0) do
  ex={}
  ex.x=x+(rnd(2)-1)*5
  ex.y=y+(rnd(2)-1)*5
  ex.r=2+rnd(6) --rayon
  ex.c=7 --couleur
  add(explosions,ex)
  nb-=1
 end
end

function game_update()
 timer()
 controls()
 gravity()
 collision()
 punching()
 item()
 keys()
 checkpoint()
 ladder()
 ice_cube()
 traps()
 monsters()
 zombie_move()
 slime_move()
 death()
 theend()
 gameover()
end

function game_draw() 
 cls() 
 color_transition()

 --room position
 rx=flr((p.x+4)/128) --room x
 ry=flr((p.y+4)/128) --room y
 --current room draw position
 dx=(rx*128) --draw x
 dy=(ry*128) --draw y
 --cell position
 if(p.dirx==true) then
  celx = flr((p.x+3)/8)
 else
  celx = flr((p.x+4)/8)
 end
 cely = flr((p.y+3)/8)
 --room cell position
 rmx = (celx-(16*rx))
 rmy = (cely-(16*ry))
 --rect cell position
 rcx = rmx*8+dx
 rcy = rmy*8+dy
 
 --camera
 if(p.shake>1) then
  camera(rx*128+flr(rnd(4)-2),ry*128+flr(rnd(4)-2))
	 p.shake-=1
 else
  camera(rx*128,ry*128)
 end

 map(0,0,0,0,128,64)

 for z in all(zombies) do
  --draw zombie
  if(z.dirx) then
   spr(anim(zombies.walk),z.x,z.y,1,1,true)
  else
   spr(anim(zombies.walk),z.x,z.y,1,1,false)
  end
  --zombie hit player
  if(celx == flr((z.x+3)/8))
  and(cely == flr((z.y+3)/8)) then
   if(p.alive) sfx(58)
   p.death=5
  end
  --player hit zombie
  if(btn(5)) then
   if(p.dirx == true) then
    if(celx == flr((z.x+3)/8))
    and(cely == flr((z.y+3)/8))
    or(celx == flr((z.x+3)/8)+1)
    and(cely == flr((z.y+3)/8)) then
     p.score+=10
     sfx(57)
     p.msg_delay=10
     p.msg_type=6
     make_explosion(z.x+4,z.y+4,5)
     del(zombies,z)
    end
   else
    if(celx == flr((z.x+3)/8))
    and(cely == flr((z.y+3)/8))
    or(celx == flr((z.x+3)/8)-1)
    and(cely == flr((z.y+3)/8)) then
     p.score+=10
     sfx(57)
     p.msg_delay=10
     p.msg_type=6
     make_explosion(z.x+4,z.y+4,5)
     del(zombies,z)
    end
   end
  end
 end
 
 for s in all(slimes) do
  --draw slime
  if(s.dirx) then
   spr(31,s.x,s.y,1,1,false)
  else
   spr(31,s.x,s.y,1,1,true)
  end
  --slime hit player
  if(celx == flr((s.x+3)/8))
  and(cely == flr((s.y+3)/8)) then
   if(p.alive) sfx(58)
   p.death=6
  end
  --player hit slime
  if(btn(5)) then
   if(p.dirx == true) then
    if(celx == flr((s.x+3)/8))
    and(cely == flr((s.y+3)/8))
    or(celx == flr((s.x+3)/8)+1)
    and(cely == flr((s.y+3)/8)) then
     p.score+=10
     sfx(57)
     p.msg_delay=10
     p.msg_type=6
     make_explosion(s.x+4,s.y+4,5) 
     del(slimes,s)
    end
   else
    if(celx == flr((s.x+3)/8))
    and(cely == flr((s.y+3)/8))
    or(celx == flr((s.x+3)/8)-1)
    and(cely == flr((s.y+3)/8)) then
     p.score+=10
     sfx(57)
     p.msg_delay=10
     p.msg_type=6
     make_explosion(s.x+4,s.y+4,5)
     del(slimes,s)
    end
   end
  end
 end
 
 --smooth camera
 --camera(p.x-64<0 and 0 or p.x-64,p.y-64) 

 --timer
 if(time_count) then
  print(":",112+dx,4+dy,7)
  print(":",100+dx,4+dy,7)
  if(t.ms<10) then
   print(flr(t.ms),120+dx,4+dy,7)
   print("0",116+dx,4+dy,7)
  else
   print(flr(t.ms),116+dx,4+dy,7)
  end
  if(t.s<10) then
   print(t.s,108+dx,4+dy,7)
   print("0",104+dx,4+dy,7)
  else
   print(t.s,104+dx,4+dy,7)
  end
  if(t.m<10) then
   print(t.m,96+dx,4+dy,7)
   print("0",92+dx,4+dy,7)
  else
   print(t.m,92+dx,4+dy,7)
  end
 end

 --final door
 if(door) then
  --landscape
  rectfill(444,339,451,359,8)
  rectfill(447,338,448,359,8)
  rectfill(442,341,453,359,8)
  circfill(447,351,4,9)
  circfill(448,351,4,9)
  circfill(447,351,3,10)
  circfill(448,351,3,10)
  rectfill(442,352,453,359,1)
  line(444,353,451,353,12)
  line(446,355,449,355,12)
  --door left
  line(438,342,438,359,4)
  pset(438,341,9)
  line(436,340,436,359,4)
  pset(436,339,9)
  line(434,338,434,359,4)
  pset(434,337,9)
  rectfill(433,345,438,346,4)
  rectfill(433,353,438,354,4)
  pset(434,347,2) 
  pset(434,355,2)
  pset(436,347,2) 
  pset(436,355,2)
  pset(438,347,2) 
  pset(438,355,2)
  --door right
  line(457,342,457,359,4)
  pset(457,341,9)
  line(459,340,459,359,4)
  pset(459,339,9)
  line(461,338,461,359,4)
  pset(461,337,9)
  rectfill(457,345,462,346,4)
  rectfill(457,353,462,354,4)
  pset(457,347,2) 
  pset(457,355,2)
  pset(459,347,2) 
  pset(459,355,2)
  pset(461,347,2) 
  pset(461,355,2)
 end

 --check point fire
 if(cpfire) then
  spr(anim(p.cpfire),p.last_cpx*8,p.last_cpy*8)
 end 
 
 --check for fire sprite
 for fx=0,15 do
  for fy=0,13 do
   if(mget(flr(fx*8+dx)/8,(flr(fy*8+dy)/8))==45) then
    spr(anim(p.fire1),fx*8+dx,fy*8+dy)
   end
   if(mget(flr(fx*8+dx)/8,(flr(fy*8+dy)/8))==46) then
    spr(anim(p.fire2),fx*8+dx,fy*8+dy)
   end
  end
 end 
 
 --arrow dispenser left
 for alx=0,15 do
  for aly=0,13 do
   if(arw.delay>=0) then
    arw.lx=((alx+1)+flr(arw.speed/8))+(16*rx)
    arw.ly=aly+(16*ry)   	
  	 if(mget(flr(alx*8+dx)/8,(flr(aly*8+dy)/8))==111) then
     spr(126,(alx+1)*8+dx+arw.speed,aly*8+dy)      
     if(arw.lx==celx) and(arw.ly==cely) and(p.alive) then
    	 p.death=4
    	 sfx(60)
    	end
    end
   end
  end
 end

 --arrow dispenser right
 for arx=0,15 do
  for ary=0,13 do
   if(arw.delay>=0) then
    arw.rx=((arx-1)-flr(arw.speed/8))+(16*rx)
    arw.ry=ary+(16*ry)
    if(mget(flr(arx*8+dx)/8,(flr(ary*8+dy)/8))==110) then
     spr(126,(arx-1)*8+dx-arw.speed,ary*8+dy,1,1,true,false)
    	if(arw.rx==celx) and(arw.ry==cely) and(p.alive) then
    	 p.death=4
    	 sfx(60)
    	end
    end
   end
  end
 end
 
 --player dash
 if(p.punch) and(p.alive) then
  if(btn(0)) or(btn(1)) then
   dash_dust=3
  end
 else
  dash_dust=0
 end
 dust_part(dash_dust,p.x+rnd(8),p.y+rnd(8))

 if(p.punch) and(p.alive) then
  if(btn(0)) or(btn(1)) then
   p.dash=true
   pal(4,(flicker/4)+8)
   pal(2,(flicker/4)+8)
   pal(2,(flicker/4)+8)
   pal(9,(flicker/4)+8)
   pal(10,(flicker/4)+8)
   pal(12,(flicker/4)+8)
   pal(13,(flicker/4)+8)
  end
 end
 
 --player
 pal(1,0)
 if(p.alive) then
  if(p.armor==1) pal(4,12) pal(2,13) pal(9,13)
  if(p.armor==2) pal(4,10) pal(2,9) pal(9,8)
  --punch
  if(p.punch) then
   if(p.punch) then
    spr(anim(p.punch_anim),p.x,p.y,1,1,p.dirx)
   else
    spr(1,p.x,p.y,1,1,p.dirx) 
   end
  --walk
  elseif(ground) or(ice) or(lava) then
   if(p.move == true) then
    spr(anim(p.walk),p.x,p.y,1,1,p.dirx)
   else
    spr(1,p.x,p.y,1,1,p.dirx) 
   end
  --fall or jump
  else
   spr(7,p.x,p.y,1,1,p.dirx)
  end
  pal()
 else
  --player death
  if(p.grav<0) then
   spr(41,p.x,p.y,1,1,p.dirx,false)
  else
   spr(41,p.x,p.y+3,1,1,p.dirx,true)
  end
 end
 pal()
 
 for e in all(explosions) do
  circfill(e.x,e.y,e.r,e.c)
  e.r-=1
  if (e.r<=0) del(explosions,e)
 end
 
 --lava heat
 if(p.armor==2) and(p.alive) then
  if(p.heat<80) and(p.heat>0) then
   local colour=8+flr(p.heat/20)
   rectfill(p.x-1,p.y-6,p.x+flr(p.heat/10)+1,p.y-3,0)
   rectfill(p.x,p.y-5,p.x+flr(p.heat/10),p.y-4,colour)
  end
 end
 
 --item messages
 if(p.msg_delay>0) then
  p.msg_delay-=1
 end
  --msg print
 if(p.msg_delay>0) then
  if(p.msg_type==1) then --coin
	  rectfill(p.x-1,p.y-9,p.x+7,p.y-3,0)
	  print("+1",p.x,p.y-8,7)
  end
  if(p.msg_type==2) then --chest
  	rectfill(p.x-3,p.y-9,p.x+9,p.y-3,0)
   print("+25",p.x-2,p.y-8,7)
  end
  if(p.msg_type==3) then
   rectfill(p.x-17,p.y-9,p.x+23,p.y-3,0)
   print("checkpoint",p.x-16,p.y-8,12)
  end
  if(p.msg_type==4.1) then
   rectfill(p.x-5,p.y-9,p.x+11,p.y-3,0)
   print("ruby",p.x-4,p.y-8,8)
  end
  if(p.msg_type==4.2) then
   rectfill(p.x-9,p.y-9,p.x+11,p.y-3,0)
   print("quartz",p.x-8,p.y-8,14)
  end
  if(p.msg_type==4.3) then
   rectfill(p.x-11,p.y-9,p.x+17,p.y-3,0)
   print("diamond",p.x-10,p.y-8,12)
  end
  if(p.msg_type==4.4) then
   rectfill(p.x-5,p.y-9,p.x+15,p.y-3,0)
   print("pearl",p.x-4,p.y-8,6)
  end
  if(p.msg_type==4.5) then
   rectfill(p.x-5,p.y-9,p.x+15,p.y-3,0)
   print("amber",p.x-4,p.y-8,9)
  end
  if(p.msg_type==4.6) then
   rectfill(p.x-10,p.y-9,p.x+18,p.y-3,0)
   print("emerald",p.x-9,p.y-8,11)
  end
  if(p.msg_type==5) then --key
   rectfill(p.x-3,p.y-9,p.x+9,p.y-3,0)
   print("key",p.x-2,p.y-8,9)
  end
  if(p.msg_type==6) then --zombie
   rectfill(p.x-3,p.y-9,p.x+9,p.y-3,0)
   print("+10",p.x-2,p.y-8,7)
  end
  if(p.msg_type==9) then --ice armor
   snow_part(2,rnd(128)+dx,dy)
   rectfill(45+dx,48+dy,83+dx,56+dy,7)
   rectfill(44+dx,47+dy,82+dx,55+dy,12)
   print("ice armor",46+dx,49+dy,0)
   rectfill(25+dx,60+dy,101+dx,66+dy,0)
   print("you can double jump",26+dx,61+dy,7)
  end
  if(p.msg_type==10) then --lava armor
   lava_sparks(2,(rnd(36))+44+dx,dy+46)
   rectfill(43+dx,48+dy,85+dx,56+dy,8)
   rectfill(42+dx,47+dy,84+dx,55+dy,9)
   print("lava armor",44+dx,49+dy,0)
   rectfill(23+dx,60+dy,103+dx,66+dy,0)
   print("you can walk on lava",24+dx,61+dy,7)
  end
	end
 if(p.msg_delay==0) then
  p.msg_type=0
 end

 --deaths
 if(p.death>0) then
  if(p.death==1) then
   rectfill(29+dx,40+dy,97+dx,46+dy,0)
   print("spiky things hurt",30+dx,41+dy,7)
  end
  if(p.death==2) then
   rectfill(13+dx,40+dy,113+dx,46+dy,0)
   print("your body is already cold",14+dx,41+dy,12)
  end
  if(p.death==3) then
   rectfill(13+dx,40+dy,113+dx,46+dy,0)
   print("don't try to swim in lava",14+dx,41+dy,9)
  end
  if(p.death==4) then
   rectfill(7+dx,40+dy,119+dx,46+dy,0)
   print("something passed through you",8+dx,41+dy,9)
  end
  if(p.death==5) then
   rectfill(21+dx,40+dy,105+dx,46+dy,0)
   print("zombie eat your brain",22+dx,41+dy,11)
  end
  if(p.death==6) then
   rectfill(24+dx,40+dy,102+dx,46+dy,0)
   print("lava slimes are hot",25+dx,41+dy,9)
  end
  rectfill(29+dx,56+dy,97+dx,63+dy,0)
  print(100-p.deathcount,36+dx,58+dy,(flicker/4)+8)
  print("lives left",48+dx,58+dy,7)
  rectfill(29+dx,72+dy,97+dx,79+dy,0)
  print("press ❎ to retry",30+dx,74+dy,8)
 end
 
 --skulls
 if(p.alive) then
 if(celx==71) and(cely==44) then
  print("there must be a way \n  to jump higher",28+dx,32+dy,7)
 end
 if(celx==46) and(cely==26) then
  print("where is this \n goddam key!",42+dx,82+dy,7)
 end
 if(celx==33) and(cely==12) then
  print("monsters deserves \na good punch in the face",4+dx,62+dy,7)
 end
 if(celx==62) and(cely==28) then
  print("guess where i took an arrow",10+dx,60+dy,7)
 end
 if(celx==122) and(cely==35) then
  print("you probably wonder how \n   i ended up there",20+dx,56+dy,7)
 end
 if(celx==81) and(cely==12) then
  print("   dash to go \nfaster and further",32+dx,56+dy,7)
 end
 if(celx==65) and(cely==28) then
  print("i like to keep my spiders\n      in my pockets",16+dx,88+dy,7)
 end
 if(celx==92) and(cely==60) then
  print("welcome to the pit",32+dx,56+dy,7)
 end
 end
 
 --snowflakes
 if(rx==5 and ry==2) or
 (rx==6 and ry==2) or
 (rx==4 and ry==1) or
 (rx==5 and ry==1) or
 (rx==6 and ry==1) or
 (rx==7 and ry==1) or
 (rx==7 and ry==2) or
 (rx==4 and ry==0) or
 (rx==5 and ry==0) or
 (rx==6 and ry==0) or
 (rx==7 and ry==0) or
 (rx==0 and ry==0) then
  snow_part(1,rnd(128)+dx,rnd(56)+dy)
 end
 
 --sparks
 if(rx==1 and ry==2) then
  lava_sparks(rnd(1)-0.8,rnd(16)+0+dx,104+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+24+dx,104+dy)
 end
 if(rx==1 and ry==1) then
  lava_sparks(rnd(1)-0.8,rnd(16)+8+dx,104+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+32+dx,104+dy)
 end
 if(rx==0 and ry==1) then
  lava_sparks(rnd(1)-0.8,rnd(16)+68+dx,56+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+16+dx,104+dy)
 end
 if(rx==0 and ry==2) then
  lava_sparks(rnd(1)-0.8,rnd(16)+104+dx,104+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+32+dx,104+dy)
 end
 if(rx==0 and ry==3) then
  lava_sparks(rnd(1)-0.8,rnd(16)+48+dx,56+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+80+dx,56+dy)
 end
 if(rx==1 and ry==3) then
  lava_sparks(rnd(1)-0.8,rnd(16)+40+dx,104+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+88+dx,104+dy)
 end
 if(rx==2 and ry==3) then
  lava_sparks(rnd(1)-0.8,rnd(16)+24+dx,104+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+64+dx,104+dy)
 end
 if(rx==4 and ry==3) then
  lava_sparks(rnd(1)-0.8,rnd(16)+40+dx,104+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+88+dx,104+dy)
 end
 if(rx==5 and ry==3) then
  lava_sparks(rnd(1)-0.8,rnd(16)+8+dx,104+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+48+dx,104+dy)
 end
 if(rx==7 and ry==2) then
  lava_sparks(rnd(1)-0.8,rnd(16)+48+dx,104+dy)
  lava_sparks(rnd(1)-0.8,rnd(16)+80+dx,104+dy)
 end
 
 --hud 
 rectfill(0+dx,112+dy,127+dx,127+dy,0)
 --score
 if(p.score<10) then
  print(p.score,112+dx,117+dy,7)
  print("000",100+dx,117+dy,1)
 elseif(p.score>99) then
  print(p.score,104+dx,117+dy,7)
  print("0",100+dx,117+dy,1)
 else
  print(p.score,108+dx,117+dy,7)
  print("00",100+dx,117+dy,1)
 end
 spr(51,115+dx,115+dy)
 --deathcount
 if(p.deathcount<10) then
  print(p.deathcount,8+dx,117+dy,8)
  print("0",4+dx,117+dy,1)
 else
  print(p.deathcount,4+dx,117+dy,8)
 end
 spr(41,12+dx,114+dy)
 --keys
 if(p.key>0) then
 print(p.key,84+dx,117+dy,7)
 else
 print(p.key,84+dx,117+dy,1)
 end
 spr(24,88+dx,115+dy)
 --gem1
 if(p.gem1==0) then
  pal(7,1) pal(8,1) pal(2,1)
 end
 spr(52,28+dx,116+dy) pal()
 --gem2
 if(p.gem2==0) then
  pal(7,1) pal(14,1) pal(15,1)
 end
 spr(53,36+dx,116+dy) pal()
 --gem3
 if(p.gem3==0) then
  pal(7,1) pal(12,1)
 end
 spr(54,44+dx,116+dy) pal()
 --gem4
 if(p.gem4==0) then
  pal(7,1) pal(6,1) pal(13,1)
 end
 spr(55,52+dx,116+dy) pal()
 --gem5
 if(p.gem5==0) then
  pal(7,1) pal(8,1) pal(9,1)
 end
 spr(56,60+dx,116+dy) pal()
 --gem6
 if(p.gem6==0) then
  pal(7,1) pal(3,1) pal(11,1)
 end
 spr(57,68+dx,116+dy) pal()
 --action
 if(mget(celx,cely)==22) or
  (mget(celx+1,cely)==25)
  and (p.key>0) or
  (mget(celx-1,cely)==25)
  and (p.key>0) then
  print("open",14+dx,4+dy,7)
  print("❎",4+dx,4+dy,8)
 end
 
 if(door) then
  if(mget(celx,cely)==94)
  or(mget(celx,cely)==95) then
	  print("got out",14+dx,4+dy,7)
   print("❎",4+dx,4+dy,8)
 	end
 end
 
 
 flicker += 1
 if(flicker >= 32) flicker = 0
 
 --[[
 if(debug) then
  --room position
  print(rx,108+dx,4+dy,10)
  print(ry,120+dx,4+dy,10)
  --player cell
  print(celx,4+dx,4+dy,8)
  print(cely,16+dx,4+dy,8)
  --player room cell
  rect(rcx,rcy,rcx+8,rcy+8,8)
  print(rmx,108+dx,12+dy,8)
  print(rmy,120+dx,12+dy,8)
  --player position
  print(p.x,32+dx,4+dy,11)
  print(p.y,64+dx,4+dy,11)
  --col 
  if(ground) then
   print("ground",4+dx,12+dy,12)
  end
  if(ice) then
   print("ice",32+dx,12+dy,12)
  end
  if(lava) then
   print("lava",64+dx,12+dy,12)
  end
  --jump
  if(btn(4)) print('jump',28+dx,12+dy,10)
 	--grav
 	print(p.grav,4+dx,20+dy,9)
	 --sprite
		print(mget(celx,cely),16+dx,20+dy,12)
	 --armor
	 print(p.armor,4+dx,28+dy,11)
	 --jumps
	 print(p.jumps,16+dx,28+dy,10)
	 --checkpoint
	 print(p.cpx,4+dx,36+dy,9)
	 print(p.cpy,16+dx,36+dy,9)
	 --cpu
	 print(flr(stat(0)),4+dx,108+dy,11)
	end
	]]

 thunder()

end

function end_update() 
 if(btnp(5)) then
  t_reverse=true
 end
 if(t_delay==0)
 and(t_reverse==true) then
  t_delay=0
 	t_reverse=false
 	_draw = credit_draw
 	_update = credit_update
 end
end

function end_draw()
 cls()
 color_transition()  
 camera()
 map(96,48,0,0,16,16)
 print("you found the way out",22,14,12)
 
 lava_sparks(rnd(1)-0.8,rnd(16)+16,120)
 lava_sparks(rnd(1)-0.8,rnd(16)+40,120)

 flicker += 1
 --timer
 if(t.ms<10) then
  print(flr(t.ms),76,29,(flicker/4)+8)
  print("0",72,29,(flicker/4)+8)
 else
  print(flr(t.ms),72,29,(flicker/4)+8)
 end
 print(":",68,29,(flicker/4)+8)
 if(t.s<10) then
  print(t.s,64,29,(flicker/4)+8)
  print("0",60,29,(flicker/4)+8)
 else
  print(t.s,60,29,(flicker/4)+8)
 end
 print(":",56,28,(flicker/4)+8)
 if(t.m<10) then
  print(t.m,52,29,(flicker/4)+8)
  print("0",48,29,(flicker/4)+8)
 else
  print(t.m,48,29,(flicker/4)+8)
 end
 if(flicker >= 32) flicker = 0
 
 --score
 print(p.score,44,50,7)
 death_bonus=0
 spider_bonus=0
 print(p.deathcount,44,66,8)
 if(p.deathcount==0) then
  print("+250",76,66,11)
  death_bonus=250
 else
  print("-"..p.deathcount*10,76,66,8)
 end
 spr(41,32,63)
 print(p.spider.."/16",44,82,12)
 if(p.spider==16) then
  print("+250",76,82,11)
  spider_bonus=250
 else
  print("+"..p.spider*10,76,82,12)
 end
 final_score=p.score-(p.deathcount*10)+(p.spider*10)+death_bonus+spider_bonus
 print("total score: "..final_score,30,98,9)
 print("press ❎",85,118,7)
 print("❎",109,118,8)
end

function credit_update()

end

function credit_draw()
 cls()
 color_transition() 
 spr(64,8,0,14,4)
 rectfill(8,0,16,8,0)
 --jaycobs
 circ(49,54,4,8)
 circ(75,54,4,8)
 rect(49,50,75,58,8)
 rectfill(49,51,75,57,0)
 print("design + code",36,42,9)
 print("insanus",49,52,7)
 print("@lupusinsanus | jaycobs.fr",12,62,12)
 --bogdan
 circ(32,94,4,8)
 circ(94,94,4,8)
 rect(32,90,94,98,8)
 rectfill(32,91,94,97,0)
 print("music + sfx",42,82,9)
 print("bogdan raczynski",32,92,7)
 print("@bogdanraczynski",32,102,12)
 
 flicker += 1
 print("thanks for playing",28,120,(flicker/4)+8)
 if(flicker >= 32) flicker = 0

 snow_part(1,rnd(128),rnd(56))

 if(btnp(5)) then
  t_reverse=true
 end
 if(t_delay==0)
 and(t_reverse==true) then
  t_delay=0
 	t_reverse=false
 	run()
 end

end


function gameover_update()

end
   
function gameover_draw()
 poke(0x5f2c,3)
 cls()
 color_transition()
 camera()
 lava_sparks(1,rnd(64),rnd(12)+52)

 print("game\nover",24,24,8)
 --spr(41,28,16)

 if(btnp(5))	run()
end