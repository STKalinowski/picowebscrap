--slime bubble bro
--by guerragames

--
one_frame=1/60
epsilon=.001

t=0

max_air_time=6000

game_finished_once=0
game_finished_last=0
game_finished=false

--
cartdata("slimebubblebro")

map_x=dget(0)
map_y=dget(1)
game_time=dget(2)
player_score=dget(3)
player_deaths=dget(4)
game_finished_once=dget(5)
game_finished_last=dget(6)

--
function save_game()
 dset(0,map_x)
 dset(1,map_y)
 dset(2,game_time)
 dset(3,player_score)
 dset(4,player_deaths)
 dset(5,game_finished_once)
 dset(6,game_finished_last)
end

--
function reset_game()
 game_finished_once=0
 reset_score()
end

--
function reset_score()
 map_x,map_y,game_time,player_score,player_deaths,game_finished_last=0,0,0,0,0,0,0
 save_game()
 run()
end

--
function next_i(l,i)
 i+=1
 if(i>#l)i=1
 return i
end

--
function nl(s)
 local a={}
 local ns=""
 
 while #s>0 do
  local d=sub(s,1,1)
  if d=="," then
   add(a,ns+0)
   ns=""
  else
   ns=ns..d
  end
  
  s=sub(s,2)
 end
 
 return a
end

--
function create_button(btn_num)
 return 
 {
  time_since_press=100,
  time_held=0,
  button_number=btn_num,

  button_init=function(b)
   b.time_since_press=100
   b.time_held=0
  end,

  button_update=function(b)
   b.time_since_press+=one_frame

   if btn(b.button_number) then
    if b.time_held==0 then
     b.time_since_press=0
    end
  
    b.time_held+=one_frame
   else
    b.time_held=0
   end
  end,

  button_consume=function(b)
   b.time_since_press=100
  end,
 }
end

jump_button=create_button(5)
shoot_button=create_button(4)

--
function mag(x,y)
  local d=max(abs(x),abs(y))
  local n=min(abs(x),abs(y))/d
  return sqrt(n*n+1)*d
end

--
function normalize(x,y)
  local m=mag(x,y)
  return x/m,y/m,m
end

--
align_c=0
align_l=1
align_r=2

function print_outline(t,x,y,c,bc,a)
  local ox=#t*2 
  if a==align_l then
   ox=0
  elseif a==align_r then
   ox=#t*4
  end
  local tx=x-ox
  color(bc)
  print(t,tx-1,y)print(t,tx-1,y-1)print(t,tx,y-1)print(t,tx+1,y-1)
  print(t,tx+1,y)print(t,tx+1,y+1)print(t,tx,y+1)print(t,tx-1,y+1)
  print(t,tx,y,c)
end

--
function time_to_text(time)
 local mins=flr(time/60)
 local secs=flr(time%60)
 
  if mins >= 100 then
   return "99:59"
  elseif mins > 0 then
   if secs < 10 then
    return mins..":0"..secs
   else
    return mins..":"..secs
   end
  else
   return ""..secs
  end
end

--
cam_shake_x=0
cam_shake_y=0
cam_shake_damp=0
screen_flash_timer=0
screen_flash_color=7

--
function screenflash(duration,color)
 screen_flash_timer=duration
 screen_flash_color=color
end

--
function screenshake(max_radius,damp)
 local a=rnd()
 cam_shake_x=max_radius*cos(a)
 cam_shake_y=max_radius*sin(a)
 cam_shake_damp=damp
end

--
function update_screeneffects()
 cam_shake_x*=cam_shake_damp+rnd(.1)
 cam_shake_y*=cam_shake_damp+rnd(.1)
 
 if abs(cam_shake_x)<1 and abs(cam_shake_y)<1 then
  cam_shake_x=0
  cam_shake_y=0
 end
 
 camera(cam_shake_x,cam_shake_y)
 
 if screen_flash_timer>0 then
  screen_flash_timer-=one_frame
 end
end

--
function round(x) return flr(x+.5) end
 
function map_coords(x,y)
 return map_x+flr(round(x)/8)%16,map_y+flr(round(y)/8)%16
end

function s_floor(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx,my-1)
 return fget(val,0) and not fget(val2,2)
end

function s_ceil(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx,my+1)
 return fget(val,2) and not fget(val2,0)
end

function s_lwall(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx+1,my)
 return fget(val,3) and not fget(val2,1)
end

function s_rwall(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx-1,my)
 return fget(val,1) and not fget(val2,3)
end

--
function collision_checks(x,y,vx,vy,ws,we,hs,he)
 local new_x,new_y=x,y
 
 local on_floor,on_ceiling,on_lwall,on_rwall=false,false,false,false
 
 local nvx,nvy,vel_mag=normalize(vx,vy)
 
 local keep_looking=true
 
 while keep_looking do
  local temp_x,temp_y=new_x,new_y
  
  if vel_mag>epsilon then
   local i_vx=(vel_mag>=1) and nvx or (vel_mag*nvx) 
   local i_vy=(vel_mag>=1) and nvy or (vel_mag*nvy)
        
    if not on_floor and not on_ceiling then
     if i_vy>0 then
      if s_floor(new_x+ws+1,new_y+he+1) and not s_floor(new_x+ws+1,new_y+he-1) or 
         s_floor(new_x+we-1,new_y+he+1) and not s_floor(new_x+we-1,new_y+he-1) then
       on_floor=true
       temp_y=round(temp_y)
       nvy=0
       i_vy=0
      end
     else
      if s_ceil(new_x+ws+1,new_y+hs-1) and not s_ceil(new_x+ws+1,new_y+hs+1) or
         s_ceil(new_x+we-1,new_y+hs-1) and not s_ceil(new_x+we-1,new_y+hs+1) then
       on_ceiling=true
       temp_y=round(temp_y)
       nvy=0
       i_vy=0
      end
     end
    end
    
    if not on_rwall and not on_lwall then
     if i_vx > 0 then
      if s_rwall(new_x+we+1,new_y+hs+1) and not s_rwall(new_x+we-1,new_y+hs+1) or
         s_rwall(new_x+we+1,new_y+he-1) and not s_rwall(new_x+we-1,new_y+he-1) then
       on_rwall=true
       temp_x=round(temp_x)
       nvx=0
       i_vx=0
      end
     else
      if s_lwall(new_x+ws-1,new_y+hs+1) and not s_lwall(new_x+ws+1,new_y+hs+1) or
         s_lwall(new_x+ws-1,new_y+he-1) and not s_lwall(new_x+ws+1,new_y+he-1) then
       on_lwall=true
       temp_x=round(temp_x)
       nvx=0
       i_vx=0
      end
     end
    end
    
    --[[]]
    if abs(i_vy)>epsilon and abs(i_vx)>epsilon and not on_floor and not on_ceiling and not on_lwall and not on_rwall then
    if not on_floor and not on_ceiling then
     if i_vy > 0 then
      if s_floor(new_x+ws-1,new_y+he+1) and not s_floor(new_x+ws+1,new_y+he-1) or 
         s_floor(new_x+we+1,new_y+he+1) and not s_floor(new_x+we-1,new_y+he-1) then
       on_floor=true
       temp_y=round(temp_y)
       nvy=0
       i_vy=0
      end
     else
      if s_ceil(new_x+ws-1,new_y+hs-1) and not s_ceil(new_x+ws+1,new_y+hs+1) or
         s_ceil(new_x+we+1,new_y+hs-1) and not s_ceil(new_x+we-1,new_y+hs+1) then
       on_ceiling=true
       temp_y=round(temp_y)
       nvy=0
       i_vy=0
      end
     end
    end
    
    if not on_floor and not on_ceiling and not on_rwall and not on_lwall then
     if i_vx > 0 then
      if s_rwall(new_x+we+1,new_y+hs-1) and not s_rwall(new_x+we-1,new_y+hs+1) or
         s_rwall(new_x+we+1,new_y+he+1) and not s_rwall(new_x+we-1,new_y+he-1) then
       on_rwall=true
       temp_x=round(temp_x)
       nvx=0
       i_vx=0
      end
     else
      if s_lwall(new_x+ws-1,new_y+hs-1) and not s_lwall(new_x+ws+1,new_y+hs+1) or
         s_lwall(new_x+ws-1,new_y+he+1) and not s_lwall(new_x+ws+1,new_y+he-1) then
       on_lwall=true
       temp_x=round(temp_x)
       nvx=0
       i_vx=0
      end
     end
    end
    end
    --]]
    
    if not on_floor and not on_ceiling then
     temp_y+=i_vy
    end
  
    if not on_rwall and not on_lwall then
     temp_x+=i_vx
    end    
  
    vel_mag-=1
  else
   keep_looking=false
  end

  new_x,new_y=temp_x,temp_y
  
  if on_floor or on_ceiling then
   new_y=round(new_y)
  end
 
  if on_rwall or on_lwall then
   new_x=round(new_x)
  end
 end
 
 return {x=new_x,y=new_y,floor=on_floor,lwall=on_lwall,rwall=on_rwall,ceil=on_ceiling}
end

--
function boss_collision_checks(e)
 local new_x,new_y=e.x+e.vx,e.y+e.vy
 local on_floor,on_lwall,on_rwall,on_ceiling=false,false,false,false
 
 if new_x-e.size<0 then
  new_x=e.size
  on_lwall=true
 elseif new_x+e.size>127 then
  new_x=127-e.size
  on_rwall=true
 end
 
 if new_y-e.size<0 then
  new_y=e.size
  on_ceiling=true
 elseif new_y+e.size>127 then
  new_y=127-e.size
  on_floor=true
 end
 return {x=new_x,y=new_y,floor=on_floor,lwall=on_lwall,rwall=on_rwall,ceil=on_ceiling}
end

--
function check_edge_warps(x,y)
  if x+6<1 then
   x=122
  elseif x+2>126 then
   x=-2
  elseif y+6<1 then
   y=122
  elseif y+2>126 then
   y=-2
  end
  
  return x,y
end

--
sbs={}
sbs_next=1

for i=1,22 do
 local sb={}
 sb.timer=0
 add(sbs,sb)
end

--
function sbs_launch(x,y,score,timer)
 local sb=sbs[sbs_next]
 
 sb.x,sb.y=x,y
 sb.score_text=(score>0) and "+"..score or ""..score
 sb.bcolor=(score>0) and 10 or 8
 sb.timer=timer
 
 sbs_next=next_i(sbs,sbs_next)
end

--
function sbs_update()
 for i=1,#sbs do
  local sb=sbs[i]
  
  if sb.timer>0 then
   sb.timer-=one_frame
   sb.y-=.5
  end
 end
end

--
function sbs_draw()
 for i=1,#sbs do
  local sb=sbs[i]
  if sb.timer>0 then
   local blink=(sb.timer%.2)>.1
   print_outline(sb.score_text,sb.x,sb.y,blink and 7 or sb.bcolor,1)
  end
 end
end

--
exps={}
exps_next=1

exps_colors=nl("3,3,11,11,3,11,11,7,10")

exps_level_small={intensity=2,time=.2}
exps_level_medium={intensity=2,time=.4}
exps_level_hard={intensity=4,time=.8}

for i=0,40 do
 local ex={}
 
 ex.t=0
 ex.particles={}
 
 for j=0,30 do
  local p={}
  add(ex.particles,p)
 end
 
 add(exps,ex)
end

--
function exps_spawn(px,py,level)
 local ex=exps[exps_next]
 
 for k,p in pairs(ex.particles) do
  local an=rnd()
  local b=rnd(.15)
  local ra=level.intensity+rnd(.2)

  p.x,p.y,p.vx,p.vy=px,py,ra*cos(an)*sin(b),ra*sin(an)*sin(b)
  
  p.max_t=level.time+rnd(level.time)
  p.t=p.max_t
 end
 
 ex.active=true
 ex.t=2*level.time
 ex.level=level
 
 exps_next=next_i(exps,exps_next)
end

--
function exps_update()
 for k,ex in pairs(exps) do
  if ex.active then
   if ex.t>0 then
    ex.t-=one_frame
    
    for k,p in pairs(ex.particles) do
     p.vx*=.9
     p.vy*=.9
     p.vy+=.05
     p.x+=p.vx
     p.y+=p.vy
     p.t-=one_frame
    end

   else
    ex.active=false
   end
  end
 end
end

--
function exps_draw()
 pink_color_check()
 for k,ex in pairs(exps) do
  if ex.active then
   for k,p in pairs(ex.particles) do
    local s=p.t/p.max_t
    local c=exps_colors[1+flr((#exps_colors-1)*s)]
    circfill(p.x,p.y,ex.level.intensity*s,c)
   end
  end
 end
 pal()
end

--
bullets={}
bullets_next=1

for i=1,100 do
 local b={}
 b.p={}
 b.vx,b.vy=0,0
 b.t=0
 b.s=4
 for j=1,4 do
  b.p[j]={}
 end
 add(bullets,b)
end

--
function bullets_spawn(x,y,vx,vy,s,t)
 local b=bullets[bullets_next]
 
 b.active=true
 b.vx,b.vy=vx,vy
 b.t=t
 b.s=s
 
 b.p[1].x,b.p[1].y=x,y
 
 for j=#b.p,2,-1 do
  b.p[j].x,b.p[j].y=b.p[1].x,b.p[1].y
 end

 bullets_next=next_i(bullets,bullets_next)
end

--
function bullets_collision_checks()
 for k,b in pairs(bullets) do
  if b.active then
   local x,y=b.p[1].x,b.p[1].y
   if b.vy>1 and s_floor(x+b.vx,y+b.vy) then
    b.active=false
   elseif b.vx<-epsilon and s_lwall(x+b.vx,y+b.vy) then
    b.active=false
   elseif b.vx>epsilon and s_rwall(x+b.vx,y+b.vy) then
    b.active=false
   end
   
   if not b.active then
    exps_spawn(x,y,exps_level_small)
   end
  end
 end
end

--
function bullets_check_edge_warps(b)
 if b.x<0 then
  b.x=127
 elseif b.x>127 then
  b.x=0
 elseif b.y<0 then
  b.y=127
 elseif b.y>127 then
  b.y=0
 end
end

--
function bullets_update()
 bullets_collision_checks()

 for k,b in pairs(bullets) do
  if b.active then
   b.t-=one_frame
   
   if b.t<=0 then
    b.active=false
   else
    
    bullets_check_edge_warps(b.p[1])
    
    b.p[1].x+=b.vx
    b.p[1].y+=b.vy
    
    b.vy+=.2
    if b.vy>4 then
     b.vy=4
    end
    
    for j=#b.p,2,-1 do
     b.p[j].x,b.p[j].y=b.p[j-1].x,b.p[j-1].y
    end
   end
  end
 end
end

--
function bullets_draw()
 pink_color_check()
 for k,b in pairs(bullets) do
  if b.active then
   local size_scale=1
   if b.t<.1 then
    size_scale=b.t/.1
   end
  
   for j=#b.p,1,-1 do
    circfill(b.p[j].x,b.p[j].y,1+b.s*size_scale*(1-j/#b.p),3)
   end
   for j=#b.p,1,-1 do
    circfill(b.p[j].x,b.p[j].y,1+b.s*size_scale*(1-j/#b.p)-1,11)
   end
  end
 end
 pal()
end

--
player={}

player_idle_anim=nl("57,57,57,57,57,58,58,58,58,58")
player_run_anim=nl("8,8,8,8,9,9,9,9")
player_start_anim={58}
player_launch_anim={58}
player_arc_anim={43}
player_wall_anim={43}

player_anim=player_start_anim

player_spawn_x=7*8
player_spawn_y=14*8

--
player_init=function()
 player_anim_index=1
 player_anim_flip=false
 player_anim_loops=true
 player_max_vx=1
 player_gravity=.5
 player_max_vy=3
 player_air_time=max_air_time
 player_exploding=0
 
 player_score_mul=0
 
 player_reset()
end

--
function player_is_in_launch_anim()
 return player_anim==player_launch_anim
end

--
function player_set_anim(anim,loops,flips)
 if player_anim!=anim then
  player_anim=anim
  player_anim_index=1
 end
 
 player_anim_loops=loops
 player_anim_flip=flips
end

--
function player_loco_anim(cr)
 if cr.lwall or cr.rwall then
  if abs(player_vx)>.1 and player_anim!=player_wall_anim then
   player_set_anim(player_wall_anim,true,player_anim_flip)
   return
  end
 end
 
 player_set_anim(abs(player_vx)>.1 and player_run_anim or player_idle_anim,true,player_anim_flip)
end

--
function player_anim_advance(cr)
 player_anim_index+=1
 
 if player_anim_index>#player_anim then
  player_anim_index=1
  
  if player_is_in_launch_anim() then
   player_vy=-4.5
   player_gravity=.5
  end
  
  if (not player_anim_loops) player_loco_anim(cr)
 end
end

--
function player_update()
 
 player_touching_death=false
 
 if player_respawning>0 then
  player_respawning-=one_frame
 end
 
 if player_died then
  if player_exploding>0 then
   player_exploding-=one_frame
   
   if player_exploding<0 then
    player_exploding=0
    exps_spawn(player_x,player_y+2,exps_level_hard)
    exps_spawn(player_x+4,player_y+6,exps_level_hard)
    exps_spawn(player_x+8,player_y+2,exps_level_hard)
    player_respawn()
   end
  end

  return
 end
 
 if level_transition>0 and level_transition<1 then
  local speed=4*sin(-.25*(1-level_transition))
  local nvx,nvy,mag=normalize(player_spawn_x-player_x,player_spawn_y-player_y)

  if mag<speed then
   player_x,player_y=player_spawn_x,player_spawn_y
  else
   player_x+=speed*nvx
   player_y+=speed*nvy
  end
  
  return
 end

 player_x,player_y=check_edge_warps(player_x,player_y)
 
 local collision_result=collision_checks(player_x,player_y,player_vx,player_vy,1,6,3,7)
 player_x=collision_result.x
 player_y=collision_result.y
 
 player_anim_advance(collision_result)
 
  player_air_time+=one_frame
  if player_air_time>max_air_time then
   player_air_time=max_air_time
  end

  if not collision_result.floor then
   player_vy+=player_gravity
  
   if player_vy>player_max_vy then
    player_vy=player_max_vy
   end
   
   if (abs(player_vy)>.1)player_set_anim(player_arc_anim,true,player_anim_flip)
  end

  if collision_result.floor then
   if player_air_time>.1 then
    exps_spawn(player_x+4,player_y+8,exps_level_small)
   end
   player_air_time=0
   player_loco_anim(collision_result)
  end
  
  if btn(0) then
   player_vx=-player_max_vx
   player_anim_flip=true
   
   if collision_result.floor and not player_is_in_launch_anim() then
    player_set_anim(player_run_anim,true,player_anim_flip)
   end
  elseif btn(1) then
   player_vx=player_max_vx
   player_anim_flip=false
   if collision_result.floor and not player_is_in_launch_anim() then
    player_set_anim(player_run_anim,true,player_anim_flip)
   end
  else
   if player_air_time>.1 then
    player_vx*=.9
   else
    player_vx*=.5

    if player_vx<.1 then
     if collision_result.floor and not player_is_in_launch_anim() then
      player_set_anim(player_idle_anim,true,player_anim_flip)
     end
    end
    
    if abs(player_vx)<epsilon then
     player_vx=0
    end
   end
  end

  
  if player_air_time<.1 then  
   if jump_button.time_since_press<.2 then
     sfx(1)
     player_vx,player_vy=0,0
     player_gravity=0
     
     jump_button:button_consume()
     player_air_time=max_air_time
     player_set_anim(player_launch_anim,false,player_anim_flip)
   end
  end

  -- shooting bullets
  if shoot_button.time_since_press<.2 then
   shoot_button:button_consume()
   local ox=player_anim_flip and 0 or 8
   local a=.025
   
   local bvx=(player_anim_flip and -3 or 3)*cos(a)
   local bvy=3*sin(a)
   
   sfx(0)
   bullets_spawn(player_x+ox,player_y+2,bvx,bvy,2,.25)
  end
end

--
function player_killed()
 player_touching_death=true
 
 if player_respawning<=0 and not player_died then
  player_deaths+=1
  
  local score_penalty=player_deaths
  sbs_launch(player_x+4,player_y,-10*score_penalty,1)
  player_score-=score_penalty
  
  player_died=true
  player_exploding=.3
  screenshake(6,.7)
  screenflash(.05,8)
  sfx(3)
 end
end

--
function player_reset()
 player_x,player_y=player_spawn_x,player_spawn_y
 player_vx,player_vy=0,0
 player_gravity=.5
 player_died=false
 player_exploding=0
 player_respawning=1
end

--
function player_respawn()
 player_reset()
 player_respawning=2
end

--
function player_sspr(spr_index,size,ysize)
 sspr(spr_index%16*8,flr(spr_index/16)*8,8,8,player_x-size,player_y-ysize,8+size*2,8+size*2,player_anim_flip)
end

-- 
function pink_color_check()
 if game_finished_once==1 then
  pal(3,8)pal(11,14)
 end
end

--
function player_draw()
 pink_color_check()
 
 local spr_index=player_anim[player_anim_index]
 
 if level_transition>0 and level_transition<1 then
  local size=24
  
  if level_show_previous then
   size=24*sin(-.5*(1-level_transition))
  else
   size=42*sin(-.25-.25*(1-level_transition))
  end
 
  spr_index=57
  player_sspr(spr_index,size,2*size+1)
 elseif player_respawning>1.7 then
  local size=16*sin(-.5*(2-player_respawning)/.3)
  
  spr_index=57
  player_sspr(spr_index,size,2*size+1)
 elseif player_respawning>0 then
  local blink=player_respawning%.1>.05
  if blink then
   spr(spr_index,player_x,player_y,1,1,player_anim_flip)
  end
 elseif player_died then
  if player_exploding>0 then
   spr_index=59
   local size=16*sin(-.5*(.3-player_exploding)/.3)
   
   player_sspr(spr_index,size,size)
  end
 else
  spr(spr_index,player_x,player_y,1,1,player_anim_flip)
 end
 
 pal()
end

--
expq={}
expq_delay=0

function expq_push(e)
 if e.active and e.exploding<=0 then
  e.slimed_index=enemy_max_slime_level
  e.exploding=enemy_explosion_time
  add(expq,e)
 end
end

function expq_pop()
 local e=expq[1]
 if e then
  expq_delay=.2
  del(expq,e)
 else
  player_score_mul=0
 end
 return e
end

function expq_update()
 expq_delay-=one_frame
 
 if expq_delay<=0 then
  local e=expq_pop()
  if e then
   if e.isboss then
    player_score+=e.type.scorevalue
    sbs_launch(e.x,e.y,10*e.type.scorevalue,2)
    for i=0,8 do
     exps_spawn(e.x+e.size-rnd(2*e.size),e.y+e.size-rnd(2*e.size),exps_level_hard)
    end
    screenshake(6,.7)
    screenflash(.1,7)
   else
    player_score_mul+=1
    player_score+=player_score_mul
    sbs_launch(e.x+4,e.y,10*player_score_mul,.5+.1*player_score_mul)
    exps_spawn(e.x+4,e.y+4,exps_level_hard)
    screenshake(6,.7)
    screenflash(.025,7)
   end
   
   sfx(2)
  end
 end
end

--
function enemy_ledge_behavior_turn(e)
 if e.x+4>e.last_ledge_x then
  e.vx=e.max_vx
  e.anim_flip=false
 else
  e.vx=-e.max_vx
  e.anim_flip=true
 end
end

--
function enemy_shooter_init(e,wait,rndwait)
 e.shoot_bullet_time=wait+rnd(rndwait)
 e.bullet_timer=0
end

--
function enemy_shooter_spread(e,speed,count,angle)
 if e.bullet_timer<e.shoot_bullet_time then
  e.bullet_timer+=one_frame
   
  if e.bullet_timer>=e.shoot_bullet_time then
   e.bullet_timer=0
    
   if e.x+4>player_x+4 then
    angle+=.5
   end
   
   ebs_shoot_spread(e.x+2,e.y+2,speed,count,angle)
  end
 end
end

--
function enemy_shooter_aimed(e)
 if e.bullet_timer<e.shoot_bullet_time then
  e.bullet_timer+=one_frame
   
  if e.bullet_timer>=e.shoot_bullet_time then
   e.bullet_timer=0
   ebs_shoot_aimed(e.x+4,e.y+4,1,1,0)
  end
 end
end

--
function enemy_shooter_draw(e)
 if e.bullet_timer>=e.shoot_bullet_time-.2 then
  local o=(e.vx>0) and -1 or 0
  circfill(e.x+4+o,e.y+4,6,8)
  circ(e.x+4+o,e.y+4,6,10) 
 end
  
 enemy_default_draw(e)
end

--
function enemy_spawner_init(e,time,spawn_type,max_minions)
 e.spawn_enemy_time=time
 e.spawn_timer=0
 e.spawn_type=spawn_type
 e.max_minions=max_minions
end 

--
function enemy_spawner_update(e)
 if e.spawn_timer<e.spawn_enemy_time then
  e.spawn_timer+=one_frame
   
  if e.spawn_timer>=e.spawn_enemy_time then
   e.spawn_timer=0
   
   if enemies_active_count-1<e.max_minions then
    enemy_spawn(e.spawn_type,e.x,e.y)
   end
  end
 end
end 

--
enemy_types={}

enemy_types[1]=
{
 idle_anim=nl("1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,"),
 vel_x=.1,
 
 init=function(e)
  enemy_shooter_init(e,2,1)
 end,
 
 update=function(e)
  enemy_shooter_aimed(e)
 end,
 
 ledge_behavior=enemy_ledge_behavior_turn,
 draw=enemy_shooter_draw,
}

enemy_types[5]=
{
 idle_anim=nl("6,6,6,6,6,5,5,5,5,5"),
 vel_x=.1,
 
 init=function(e)
  enemy_shooter_init(e,2,1)
 end,
 
 update=function(e)
   enemy_shooter_spread(e,1,8,0)
 end,
 
 ledge_behavior=enemy_ledge_behavior_turn,
 draw=enemy_shooter_draw,
}

enemy_types[10]=
{
 idle_anim=nl("11,11,11,11,11,10,10,10,10,10"),
 vel_x=.2,
 
 init=function(e)
  enemy_shooter_init(e,2,1)
 end,
 
 update=function(e)
   enemy_shooter_spread(e,1,1,0)
 end,
 
 ledge_behavior=enemy_ledge_behavior_turn,
 draw=enemy_shooter_draw,
}

enemy_types[13]=
{
 idle_anim=nl("13,13,13,13,13,14,14,14,14,14"),
 vel_x=.1,
 
 alert_anim=nl("13,13,13,15,15,15,15,15,15,15"),

 ledge_behavior=enemy_ledge_behavior_turn,
 
 init=function(e)
  e.keep_alert=0
 end,
 
 update=function(e)
  e.keep_alert-=one_frame
  if e.keep_alert<0 then
   e.keep_alert=0
  end

  if e.keep_alert<=0 then
   if e.y+2>player_y+8 or e.y+6<player_y then
    e.max_vx=.1
    e.vx=e.anim_flip and -.1 or .1
    e.anim=e.type.idle_anim
   else
    e.max_vx=1
    e.vx=e.anim_flip and -1 or 1
    e.anim=e.type.alert_anim
    e.keep_alert=1
   end
  end
 end,
}

enemy_types[21]=
{
 idle_anim=nl("21,21,21,21,21,22,22,22,22,22"),
 vel_x=0,
 
 update=function(e)
  if e.slimed_index<=0 then
   if rnd()>.95 then
    if s_floor(e.x+4,e.y+9) then
     if abs(e.vy)<epsilon then
      e.vy=-4.2
      e.anim_flip=player_x<e.x
      e.vx=e.anim_flip and -.6 or .6
     end
    end
   else
    if s_floor(e.x+4,e.y+9) then
     e.vx=0
    end
   end
  end
 end,
 
 ledge_behavior=function(e)end,
}


enemy_types[27]=
{
 idle_anim=nl("28,28,28,28,28,27,27,27,27,27"),
 vel_x=.1,
 
 init=function(e)
  e.gravity=0
  enemy_shooter_init(e,2,1)
 end,
 
 ledge_behavior=function(e)end,
 
 update=function(e)
  enemy_shooter_aimed(e)
  
  if e.slimed_index<1 then
   if rnd()>.99 then
    e.vx,e.vy=e.vy,e.vx 
   end
  end
 end,
 
 draw=enemy_shooter_draw,
}

enemy_types[32]=
{
 idle_anim=nl("32,32,32,32,32,33,33,33,33,33"),
 vel_x=.5,
 
 ledge_behavior=function()end,
}

enemy_types[35]=
{
 idle_anim=nl("36,36,36,36,36,35,35,35,35,35"),
 vel_x=.2,
 
 init=function(e)
  e.max_vy=.25
  e.vy=e.max_vy
  e.timer=0
  e.gravity=0
 end,
 
 ledge_behavior=function(e)end,
 
 update=function(e)
  e.timer-=one_frame
  
  if e.timer<=0 then
   e.timer=.5+rnd(.5)
   
   local nvx,nvy,mag=normalize(player_x-e.x,player_y-e.y)

   e.vx=nvx*e.max_vy
   e.vy=nvy*e.max_vy
  end
 end,
}

enemy_types[37]=
{
 idle_anim=nl("38,38,38,38,38,37,37,37,37,37"),
 vel_x=.5,
 
 init=function(e)
  e.max_vy=.5
  e.vy=e.max_vy
  e.gravity=0
 end,
 
 ledge_behavior=function(e)end,
 
 update=function(e)
  if e.slimed_index<1 then
   if e.collision_result.floor then
    e.vy=-e.max_vy
   elseif e.collision_result.ceil then
    e.vy=e.max_vy
   elseif abs(e.vy)<.01 then
    e.vy=e.max_vy
   end
  end
 end,
}

enemy_types[41]=
{
 idle_anim=nl("41,41,41,41,41,42,42,42,42,42,"),
 vel_x=.3,
 
 init=function(e)
  e.jump_cooldown=0
 end,
 
 update=function(e)
  
  e.jump_cooldown-=one_frame
  
  if e.jump_cooldown<=0 then
   if e.slimed_index<=0 then
    if rnd()>.99 then
     if s_floor(e.x+4,e.y-1) then
      e.vy=-4.2
      e.jump_cooldown=1
     end
    end
   end
  end
 end,
 
 ledge_behavior=function(e)
  if e.slimed_index<=0 then
   if rnd()>.9 then 
    if e.jump_cooldown<=0 then
     e.vy=-4.2
     e.jump_cooldown=1
    end
   end
  end
 end,
}

enemy_types[48]=
{
 idle_anim=nl("49,49,49,49,49,48,48,48,48,48"),
 vel_x=.5,
 
 ledge_behavior=enemy_ledge_behavior_turn,
}

--
function make_boss(ia,sa,ss,ms,bc,bw,sv)
 return {
 idle_anim=ia,
 slimed_anim=sa,
 spr_s=ss,
 vel_x=.2,
 max_s=ms,
 bcount=bc,
 bwait=bw,
 scorevalue=sv,
 
 init=function(e)
  e.gravity=0
  e.isboss=true
  e.angle=0
  e.size=8
  e.damt=0
  enemy_spawner_init(e,5,48,10)
  enemy_shooter_init(e,e.type.bwait,0)
 end,
 
 ledge_behavior=function()end,
 
 take_damage=function(e,dam)
  e.damt=.05
  e.size+=dam
  if e.size>e.type.max_s then
   e.size=e.type.max_s
   
   for k,ae in pairs(enemies) do
    enemy_explode(ae)
   end
  end
 end,
 
 update=function(e)
  e.angle+=.01

  enemy_shooter_spread(e,.5,e.type.bcount,e.angle)
  enemy_spawner_update(e)
  
  e.damt=max(0,e.damt-one_frame)
  
  if e.collision_result.ceil then
   e.vy=e.type.vel_x
  elseif e.collision_result.floor then
   e.vy=-e.type.vel_x
  end
 
  if rnd()>.99 then
   e.vx,e.vy=e.vy,e.vx 
  end
 end,
 
 draw=function(e)
  if e.damt>0 then
   pal(7,8)
   pal(6,8)
  end
  
  local shake=3*(max(.5,e.size/e.type.max_s)-.5)/.5
  
  local sprite=e.anim[e.anim_index]
  sspr(sprite%16*8,flr(sprite/16)*8,e.type.spr_s,e.type.spr_s,e.x-e.size+1+rnd(shake),e.y-e.size+1+rnd(shake),e.size*2,e.size*2,e.anim_flip)
  pal()
 end,
}
end

enemy_types[54]=make_boss(nl("54,54,54,54,54,54,54,54,55,55,55,55,55,55,55,55"),{54},7,16,4,1.5,20)
enemy_types[52]=make_boss(nl("52,52,52,52,52,52,52,52,53,53,53,53,53,53,53,53"),{52},7,24,6,1,40)
enemy_types[25]=make_boss(nl("25,25,25,25,25,25,25,25,26,26,26,26,26,26,26,26"),{25},7,32,8,.8,80)
enemy_types[23]=make_boss(nl("23,23,23,23,23,23,23,23,46,46,46,46,46,46,46,46"),{54},16,42,8,.5,200)

--
function enemy_default_draw(e) 
 spr(e.anim[e.anim_index],e.x,e.y,1,1,e.anim_flip)
end

--

enemy_max_slime_level=6
enemy_explosion_time=.2
enemies={}

for i=0,40 do
 add(enemies,{})
end

--
function enemies_init()
 enemies_next=1
 enemies_active_count=0
 
 enemies_boss=nil
 
 for k,e in pairs(enemies) do
  e.active=false
  e.x,e.y=0,0
  e.type_i=48
  e.type=enemy_types[e.type_i]
  e.anim_index=1
  e.anim=e.type.idle_anim
  e.max_vx=e.type.vel_x
  e.vx,e.vy=e.max_vx,0  
  e.anim_flip=false
  e.slimed_index=0
  e.last_slimed=0
  e.invulnerable=0
  e.exploding=0
  e.isboss=false
 end
end

--
function enemy_spawn(spr,x,y)
 if enemies_active_count>=#enemies then
  return
 end
 
 enemies_active_count+=1
 
 local e=enemies[enemies_next]
 while e.active do
  enemies_next=next_i(enemies,enemies_next)
  e=enemies[enemies_next]
 end

 e.active=true
 e.type_i=spr
 e.type=enemy_types[e.type_i]
   
 e.anim=e.type.idle_anim
 e.slimed_index=0
 
 e.x,e.y=x,y
 
 e.max_vx=e.type.vel_x
 e.max_vy=nil
 e.vx=(e.x<64) and -e.max_vx or e.max_vx  
 e.vy=0
 
 e.last_ledge_x,e.last_ledge_y=0,0
 
 e.anim_flip=(e.vx<0)

 e.gravity=nil
 
 if(e.type.init)e.type.init(e)
 
 if(e.isboss)enemies_boss=e
end

--

function slimed_enemy_check_freeze(eb)
 if eb.slimed_index>1 then
  local ebx,eby=eb.x,eb.y
  for k,e in pairs(enemies) do
   if e.active and e!=eb then
    if not e.isboss then
     local ex,ey=e.x,e.y
   
     local mags=mag(ex-ebx,ey-eby)
   
     local bubble_size=eb.slimed_index*4
     if mags<bubble_size then
      if e.slimed_index<=0 then
       e.slimed_index=1
      end
     end
    end
   end
  end
 end 
end

--
function enemy_check_collateral(eb)
 local ebx,eby=eb.x+4,eb.y+4
 local bubble_size=eb.slimed_index*4
 
 for k,e in pairs(enemies) do
  if e.active and e!=eb then
   if e.isboss then
     local mags=mag(e.x-ebx,e.y-eby)
     if mags<bubble_size+e.size then
      e.type.take_damage(e,1.5)
     end
   else
    if e.slimed_index>=1 then
     enemy_explode(e)
    else
     local ex,ey=e.x+4,e.y+4
     local mags=mag(ex-ebx,ey-eby)
    
     if mags<bubble_size then
      enemy_explode(e)
     end
    end
   end
  end
 end 
end

--
function slimed_enemy_check_player_collision(e)
 local px,py=player_x,player_y
 local ex,ey=e.x,e.y
   
 local nvx,nvy,mag=normalize(ex-px,ey-py)
   
 local bubble_size=4+e.slimed_index*4
 if mag<bubble_size then
  e.vx=nvx*(bubble_size-mag)*.2
 end 
end

--
function enemy_movement(e)
 e.x,e.y=check_edge_warps(e.x,e.y)
 
 if e.isboss then
  e.collision_result=boss_collision_checks(e)
 else
  e.collision_result=collision_checks(e.x,e.y,e.vx,e.vy,0,7,0,7)
 end
 
 e.y=e.collision_result.y
 
 e.x=e.collision_result.x
 if e.collision_result.rwall then
  e.vx=-e.max_vx
  e.anim_flip=true
 elseif e.collision_result.lwall then
  e.vx=e.max_vx
  e.anim_flip=false
 end
 
 if e.collision_result.rwall or e.collision_result.lwall or
    e.collision_result.floor or e.collision_result.ceil then
  e.last_collision_x=e.collision_result.x
  e.last_collision_y=e.collision_result.y
 end
 
 if e.type.ledge_behavior then
  if s_floor(e.x+4,e.y+9) then
   if e.vx>0 and not s_floor(e.x+7,e.y+9) then
    e.last_ledge_x,e.last_ledge_y=e.x+7,e.y+9
    e.type.ledge_behavior(e)
   elseif e.vx<0 and not s_floor(e.x-1,e.y+9) then
    e.last_ledge_x,e.last_ledge_y=e.x-1,e.y+9
    e.type.ledge_behavior(e)
   end
  end
 end
end

--
function enemy_check_player(e)
 if e.isboss then
  local mags=mag(e.x-player_x-4,e.y-player_y-4)
  if mags<e.size+4 then
   player_killed()
  end  
 else
  if player_x+6<e.x or
     player_x>e.x+8 or
     player_y+6<e.y or
     player_y>e.y+8 then
  else
   player_killed()
  end
 end
end

--
function enemy_explode(e)
 expq_push(e)
end

--
function enemy_player_bullet_collision(b,e)
 local bp=b.p[1]
 
 if e.isboss then
  local mags=mag(e.x-bp.x,e.y-bp.y)
  if mags>e.size+3 then
   return false
  end
 else
  if bp.x+1<e.x or
     bp.x-1>e.x+8 or
     bp.y+1<e.y or
     bp.y-1>e.y+8 then
   return false
  end
 end
 
 return true
end

--

function enemy_update_nonexploding(e)
 -- slimed movement
 if e.slimed_index>=1 then
  e.x+=e.vx
  e.y+=e.vy
   
  if abs(e.vx)>0 then
   e.vx*=.8
  end

  if e.vx>0 then
   if s_rwall(e.x+8+e.vx,e.y+4) then
    e.vx=0
   end
  elseif e.vx<0 then
   if s_lwall(e.x+e.vx,e.y+4) then
    e.vx=0
   end
  end
 end

 -- gravity
 if e.collision_result and not e.collision_result.floor then
  local g=e.gravity or .5
  local max_vy=e.max_vy or 4
      
  if e.slimed_index>=1 then
   max_vy=.5
   g=.5
  end
      
  e.vy+=g
      
  if e.vy>max_vy then
   e.vy=max_vy
  end
 else
  local has_gravity=(e.slimed_index>=1 or not e.gravity or e.gravity>0)
  if has_gravity and e.vy>0 then
   e.vy=0
   e.y=flr(e.y)
  end
 end

 -- advance animation
 e.anim_index=next_i(e.anim,e.anim_index)
   
 if e.invulnerable>0 then
  e.invulnerable-=one_frame
 end
   
 -- slimed cooldown
 if e.slimed_index>=1 then
  e.last_slimed-=one_frame
  if e.last_slimed<=0 then
   e.slimed_index-=1
   e.last_slimed=2
     
   if e.slimed_index<=0 then
    e.vx=e.anim_flip and -e.max_vx or e.max_vx
   end
  end
    
  if e.slimed_index>0 then
   slimed_enemy_check_player_collision(e)
     
   slimed_enemy_check_freeze(e)
  end
 end

end

--
function enemies_update()
 expq_update()
 
 local enemies_exploding=(#expq>0)
 
 for k,e in pairs(enemies) do
  if e.active then
   if not enemies_exploding then
    enemy_update_nonexploding(e)
   end
   
   if not enemies_exploding and e.exploding>0 then
    e.exploding-=one_frame
    if e.exploding<=0 then
     
     enemy_check_collateral(e)
     
     enemies_active_count-=1
     e.active=false
     
     if enemies_active_count<=0 then
      level_goto_next()
     end
    end
   end
   
   if e.exploding<=0 then
    for k2,b in pairs(bullets) do
     if b.active then
      if enemy_player_bullet_collision(b,e) then
       b.active=false
       
       if(e.type.take_damage)e.type.take_damage(e,.1)
      
       if e.invulnerable<=0 then
        e.invulnerable=.2
      
        if not e.isboss then
         e.slimed_index+=1
         e.vx,e.vy=0,0
         e.last_slimed=(e.slimed_index>=enemy_max_slime_level-1) and 6 or 2
        end
        
        if not enemies_exploding and e.slimed_index>=enemy_max_slime_level then
         enemy_explode(e)
        else
         exps_spawn(b.p[1].x,b.p[1].y,exps_level_medium)
         screenshake(2,.7)
        end
       else
        exps_spawn(b.p[1].x,b.p[1].y,exps_level_small)
       end
      end
     end
    end
   end
  end
 end
 
 if not enemies_exploding then
  for k,e in pairs(enemies) do
   if e.active then
    enemy_movement(e)
   
    if e.slimed_index<1 then
     if(e.type.update)e.type.update(e)
     enemy_check_player(e)
    end
   end
  end
 end
end

--
function enemy_draw_bubble(e,sx,sy)
 pink_color_check()
 circfill(e.x+4+sx-e.slimed_index*2,e.y+sy+8-e.slimed_index*2.5,e.slimed_index/1.5,7)
 circ(e.x+sx+3+1,e.y+sy+4,e.slimed_index*4-1,7)
 if e.slimed_index>=3 then
  circ(e.x+sx+3,e.y+sy+4,e.slimed_index*4-1,7)
  circ(e.x+sx+3+2,e.y+sy+4,e.slimed_index*4-1,7)
 end
 circ(e.x+sx+4,e.y+sy+4,e.slimed_index*4,11)
 pal()
end

--
function enemies_draw() 
 for k,e in pairs(enemies) do
  if e.active and e.exploding<=0 then
   if e.slimed_index<enemy_max_slime_level-1 then   
    if e.slimed_index<=0 then
     if e.type.draw then
      e.type.draw(e) 
     else
      enemy_default_draw(e)
     end
    end
   end
  end
 end

 for k,e in pairs(enemies) do
  if e.active and e.exploding<=0 then
   if e.slimed_index<enemy_max_slime_level-1 then   
    if e.slimed_index>0 then
     spr(e.type.slimed_anim or e.type.idle_anim[1],e.x,e.y)
      
     local blink=(e.slimed_index!=1 or e.last_slimed>1 or e.last_slimed%.1>.05)
      
     if blink then
      enemy_draw_bubble(e,0,0)
     end
    end
   end
  end
 end

 for k,e in pairs(enemies) do
  if e.active then
   if e.slimed_index>=enemy_max_slime_level-1 or e.exploding>0 then   
     local shakex,shakey=1-rnd(2),1-rnd(2)
     spr(e.type.slimed_anim or e.type.idle_anim[1],e.x+shakex,e.y+shakey)
     enemy_draw_bubble(e,shakex,shakey)
   end
  end
 end
end

--
ebs={}
ebs_next=1
ebs_blink=0
ebs_blink_on=true

for i=1,100 do
 add(ebs,{})
end

function ebs_reset()
 for k,eb in pairs(ebs)do
  eb.active=false
 end
end

function ebs_make_bullets(x,y,speed,count,inc_a,start_a)
 sfx(4)
 local ia=start_a
 for i=1,count do
  local eb=ebs[ebs_next]
  eb.x,eb.y=x,y
  eb.velx,eb.vely=speed*cos(ia),speed*sin(ia)
  eb.active=true
  ebs_next=next_i(ebs,ebs_next)
  
  ia-=inc_a
 end 
end

--
function ebs_check_player(eb)
 if player_x+6<eb.x+1 or
    player_x>eb.x+3 or
    player_y+6<eb.y+1 or
    player_y>eb.y+3 then
 else
  eb.active=false
  player_killed()
 end
end

--
function ebs_update()
 if ebs_blink<=0 then
  ebs_blink=.05
  ebs_blink_on=not ebs_blink_on
 else
  ebs_blink-=one_frame
 end

 for k,eb in pairs(ebs)do
  if eb.active then
   if eb.y<-8 or eb.x<-8 or eb.y>142 or eb.x>142 then
    eb.active=false
   else
	   eb.y+=eb.vely
    eb.x+=eb.velx

    ebs_check_player(eb)
    
    for k,e in pairs(enemies) do
     if e.active and e.slimed_index>=1 then
      local ex,ey=e.x+4,e.y+4
   
      local mags=mag(ex-eb.x,ey-eb.y)
      
      local bubble_size=e.slimed_index*4+1
      if mags<bubble_size then
       eb.active=false
       exps_spawn(eb.x,eb.y,exps_level_small)
      end
     end
    end
   end
  end
 end
end

--
function ebs_draw()
 pal()

 if ebs_blink_on then
  pal(8,9)
  pal(10,8)
 end
  
 for k,eb in pairs(ebs)do
  if eb.active then
   spr(3,eb.x,eb.y)
  end
 end
 
 pal()
end

function ebs_shoot_aimed(x,y,speed,count,angle)
 local to_player_x,to_player_y=player_x-x,player_y-y
 local nx,ny,mag=normalize(to_player_x,to_player_y)
 local a=atan2(nx,ny)
 ebs_make_bullets(x,y,speed,count,angle/count,a)
end

function ebs_shoot_spread(x,y,speed,count,angle)
 ebs_make_bullets(x,y,speed,count,1/count,angle)
end

--
level_transition=0
level_show_previous=false
level_show_title=0
level_number=0
next_map_x=map_x
next_map_y=map_y

--
function level_goto(mx,my)
 level_number=flr(mx/16)+flr(my/16)*8
 
 if level_number<0 then
  level_number=0
 elseif level_number>31 then
  level_number=31
 end

 level_transition=.99
 level_show_previous=false
 next_map_x=level_number%8*16
 next_map_y=flr(level_number/8)*16
end

--
function level_goto_next()
 if level_number<32 then
  level_transition=2
  level_show_previous=true
  level_number+=1
  next_map_x=level_number%8*16
  next_map_y=flr(level_number/8)*16
  
  if level_number>=32 then
   player_spawn_x=6*8
   player_spawn_y=8*8
  end  
 end
end

--
function level_init()
 for i=map_x,map_x+15 do
  for j=map_y,map_y+15 do
   local tile_spr=mget(i,j)
   if fget(tile_spr,7) then
    enemy_spawn(tile_spr,(i-map_x)*8,(j-map_y)*8)
   end
  end
 end
end

--
function level_update()
 if level_transition>0 then
  level_transition-=one_frame
  
  if level_transition<1 and level_transition+one_frame>1 then
   sfx(5)
  end
  
  if level_transition<=0 then
   level_transition=0
   map_x=next_map_x
   map_y=next_map_y
   
   save_game()
   game_view.start()
   
   if level_number>=32 then
    game_finished=true
    game_finished_last=1
    game_finished_once=1
    level_number=0
    map_x,map_y=0,0
    save_game()
   end

   level_show_title=2
  end
 end
 
 if level_show_title>0 then
  level_show_title-=one_frame
 end
end

--
function level_draw()
 if level_transition>0 then
  local offsety=-128*sin(.25-level_transition/4)
  map(next_map_x,next_map_y,0,offsety-128,16,16,0x10)
  if(level_show_previous)map(map_x,map_y,0,offsety,16,16,0x10)
 end
end

--
function level_title_draw()
 if level_show_title>0 then
  local a,b=map_y/16+1,map_x/16+1
  if(b==8)b="boss"
  print_outline("floor "..a.."-"..b,64,64,7,1)
 end
end

--
function ge_sspr(spx,spy,x,y,s,f)
 sspr(spx,spy,8,8,x-s,y-s,s*2,s*2,f)
end

--
function game_end_draw()
 for i=0,999 do
  pset(rnd(128),rnd(128),rnd(3))
 end
 
 if t%(14*one_frame*2)<one_frame then
  player_anim_flip=not player_anim_flip
  exps_spawn(rnd(128),rnd(128),exps_level_hard)
 end
 
 local spr_index=57
 local spr_index2=44
 
 local spr1x,spr1y=spr_index%16*8,flr(spr_index/16)*8
 local spr2x,spr2y=spr_index2%16*8,flr(spr_index2/16)*8
 
 local tover2=t*.5

 for a=0,1,.03 do
  local r=90*(a)
  local x,y=64+r*cos(a*tover2),64+r*sin(a*tover2)
  local size=r*.2
  if a%.06>=.03 then
   ge_sspr(spr1x,spr1y,x,y,size,player_anim_flip)
  else
   ge_sspr(spr2x,spr2y,x,y,size,not player_anim_flip)
  end
 end
 
 ge_sspr(spr1x,spr1y,48,56,16,player_anim_flip)
 ge_sspr(spr2x,spr2y,80,56,16,not player_anim_flip)
 
 print_outline("congratulations!",64,74,7,1)
 print_outline("you rescued slimette!",64,84,7,1)
end

--
music(0)

--
function _init()
 menuitem(1,"reset progress!?",reset_game)

 if game_finished_last==1 then
  reset_score()
 end

 t=0
 
 jump_button:button_init()
 shoot_button:button_init()

 player_init()
 enemies_init()
 ebs_reset()
end

--
fe_view={}

local title="06ee010e010001e002ee010e010003ee010e010002ee010004ee010e01e002ee050024ee01300133010302ee0130013301e002ee0130013301e0010e013301e003ee0130010301ee010e053301e022ee010e01b3017701370100010e01730177010301ee010e01730177010301300177010302ee010e0173013701e0013003bb017b0177010322ee013002bb017b0133010001b301bb013701e0013001bb017b0103013001bb013701e001ee013001bb0137010001b305bb013701e020ee010e01b303bb0177013302bb013701e0013002bb013701b301bb013701e001ee013001bb017b010301b305bb013701e020ee013005bb013702bb013b0100013002bb013701b302bb0103010001b301bb017b013302bb023302bb010321ee013001bb013b013302bb013702bb013b0100013002bb013b01b302bb013b013303bb013301bb013b0200023301e020ee010e013001bb0103010001b301bb013b02bb013b0100013002bb013b01b307bb013301bb013b040021ee010e013001bb013b0100013001bb013b02bb013b020001b301bb013b01b307bb013301bb013b01e0020022ee010e013002bb013301000133010301b301bb013b020001b301bb013b01b307bb013301bb013b01e024ee010e010001b302bb0103020001b301bb010301ee0100013001bb013b01b301bb013b02bb013b02bb013301bb013b01e024ee010e0100013002bb013b01e0010001b301bb010301ee0100013001bb013b01b301bb013b01b301bb013302bb013301bb013b020024ee020001b302bb0103010001b301bb010301ee010e013001bb013b01b301bb013b01b301bb013302bb013302bb023301e023ee010e0100013002bb0137010001b301bb010301ee010e013001bb013b01b301bb013b01b301bb013302bb013302bb017b0177010324ee020001b301bb017b010301b301bb010301ee010e013001bb013b01b301bb013b0130013b013002bb013304bb013701e022ee0300013001bb017b010301b301bb010301ee010e013001bb013b01b301bb013b01000103013002bb013304bb010318ee010e020007ee010e013301030100013002bb013701b3013b01e0010e0100013001bb013b01b301bb013b0200013002bb013302bb023301e017ee0100013001bb013b010006ee0130017b0137020001b301bb013701b3013b01e001300103013001bb013b01b301bb013b01e0010e013002bb013301bb013b020017ee010001b303bb013b01e005ee013001bb017b0103010001b301bb013b01b3013b010001730137013001bb013b01b301bb013b01e0010e013002bb013301bb013b010017ee010e01b301bb017b017701b701bb010304ee010e013001bb017b0103010001b301bb013b01b3013b013001bb017b013301bb013b01b301bb013b01e0010e013002bb013301bb013b01e017ee010002bb027701b701bb013b01e003ee010e013002bb0103010001b301bb013b01b3013b013001bb017b013301bb013b01b301bb013b01e0010e013002bb013301bb013b01e016ee010e01b301bb017b01b703bb013b01e003ee010e013002bb013b010001b301bb013b01b3013b01b302bb013301bb013b01b301bb013b01e0010e013002bb013301bb013b01e001ee020013ee013001b301bb01b704bb013b01e003ee010e013003bb013302bb010301b3013b03bb013301bb013b01b301bb013b01e0010e013002bb013301bb013b0200023301e012ee013007bb013b01e003ee010e010001b305bb010301b303bb0133013001bb013b01b301bb013b01e0010e013002bb013302bb0233017b0177010311ee010e013307bb013b01e003ee010e010001b304bb013b010001b302bb01330100013001bb013b01b301bb013b01e0010e013002bb010301b305bb013701e010ee013001b307bb013b01e004ee0100013004bb01e3010001b301bb013b0100010e013001bb013b01b301bb013b01e0010e013002bb010301b305bb013701e010ee013008bb013301e004ee0200013302bb013b01e0010001b301bb010301ee010e010001b30103013001bb010301ee010e010001b3013b0100013005bb010310ee010e013307bb0133010305ee010e02000233010301e001000130013301e001ee010e0100013002000133010001e0010e0100013001030200053301e010ee010e013306bb023301e006ee02000130010301000103013001030130010301ee013001030100010302000133010301ee010001300103010e01300103010001300133010011ee010e013304bb0333010308ee010001b301370130013701b3013701b30137010001b30137013001370100013001bb013701e0010e01b30137010001b30137010001b3017b010311ee010e013301b301bb013b0333010301e008ee013001bb017b0133013b01b3013b01bb017b013301bb017b0133013b010001b301bb017b0103013001bb017b013301bb017b013302bb013701e00cee010e010001e002ee013004330103010001e009ee0130013b01b3023b01b3023b01b3023b01b3023b010001b3023301e00130013b01b3023b01b3023b01b3013b01e00bee010e01300133010302ee010e0333010001e00aee010e0130013b01b3023b01b3023b01b3023b01b3023b010001b301330100010e0130013b01b3023b01b3023b01b3013b01e00bee013001b301bb013b01e002ee03000cee010e013002bb0133013b01b3013b02bb013302bb0133013b010001b301bb0103010e013002bb013302bb0133013b01b3013b01e00aee010e01b301bb017701bb010311ee010e0130013b01b3023b01b3023b01b3023b01b3023b010001b301330100010e0130013b01b3023b01b3023b01b3013b01e00aee013001bb027701bb013b01e010ee010e0130013b01b3023b01b3023b01b3023b01b3023b013301b3023301000130013b01b3023b01b3023b01b3013b01e00aee013001bb017702bb013b01e010ee010e013002bb013302bb013302bb013302bb013302bb01b302bb0103013002bb0133013b01b3013b02bb013b01e009ee010e01b3017b03bb013b01e010ee010e010001b3013b010001b3013b010001b3013b010001b3013b010001b3013b013001bb013b020001b3013b0130013b01b3010301b301bb01030aee010e01b304bb013b01e010ee010e010001300103010001300103010001300103010001300103010001300103010001330103010e01000130010301000103013001000130013301e00aee013005bb013301e011ee020001e0020001e0020001e0020001e0050001e001ee09000bee013004bb013b010312ee010e01e001ee010e01e001ee010e01e001ee010e01e001ee010e01e001ee010001e002ee010e01e001ee01e0010e01ee010e01000cee013003bb013b013301e038ee010e01b302bb013b0133010339ee010e01b302bb0133010301e02bee030001e00aee010e01b301bb0133010301e02bee010e013302bb010b020008ee010e0133013b013301e02cee0130013305bb010007ee010e023301032cee010e023306bb020001e005ee0130010301e02cee010e013301b308bb010b010004ee010e01e02dee013001330bbb01e032ee013001b30bbb010b01e030ee010e013301b30cbb010b01002fee010e01330fbb01e02eee013001b30fbb010b2dee010e013311bb01e02cee013012bb010b2bee010e01b313bb01e02aee01300dbb013b013305bb010b29ee010001b30dbb0133017701b705bb01e027ee010e013307bb013301b304bb013b0173027705bb01e027ee013001b306bb0133017301b704bb013b0173027705bb010b26ee010e013307bb0133027704bb013b037701b704bb010b26ee010e01b306bb013b0173027701b703bb0133037701b704bb010b26ee013001b306bb013b0173027701b703bb0133037701b705bb01e024ee010e013307bb013b0173037702bb013b0173047705bb01e00cee010e010003ee010e04000eee010e013307bb013b047702bb013b0173047705bb01e00bee010e01b001bb010002ee0130013303bb01000dee013001b307bb0133047701b701bb013b0173047705bb01e00aee010e01b003bb01e0010e013301b304bb01000cee013001b307bb0133047701b701bb013b0173047705bb010b09ee010e01b004bb01e00130013302bb027701b701bb01000aee010e013308bb0133047701b701bb013b0173047705bb010b09ee01b002bb017b017701bb010b0130013302bb047701bb010009ee0130013308bb0133047701b701bb013b0173037701b705bb010b08ee010e02bb017b027701b7010b0130013304bb027701b701bb01e008ee0130013308bb0133047701b701bb013b0173037701b705bb010b08ee01b001bb017b017701b702bb01030130013301b305bb017701bb010b04ee020001ee010e023308bb0133047701b702bb0133037701b705bb010307ee010e02bb017701b703bb01030130013301b305bb017b01b701bb01e002ee010e02bb01e0010e023308bb013b047701b702bb0133037706bb010307ee01b001bb017b01b703bb013b0103010e023306bb017b01b7010b02ee013001bb01b7010b010e023308bb013b0173037701b702bb013b037706bb010301ee010e010003ee010e02bb01b704bb013b0103010e033306bb017b01bb01e001ee013001bb017b010b010e023308bb013b0133037703bb013b0173017701b706bb010301ee01b001bb01e002ee01b001bb017b05bb013301e001ee0100033301b305bb01b7010b01ee010e01b3017b010b010e023309bb0133037703bb013b0133017701b305bb013b0103010e017b01b7010301ee010e02bb01b704bb013b013301e002ee0100043304bb017b01bb01e001ee013002bb0100023309bb013b0173027704bb023306bb013b01e0010e01b701bb010301ee01b007bb0133010304ee0100043305bb010b01ee010e01b301bb010002330abb0133017701b70cbb013301e001b002bb0103010e07bb013b013301e005ee0100043304bb010b02ee013001bb010002330abb013b013301b30cbb013301e001b001bb013b01e001b006bb013b0133010307ee0100033301b304bb01e001ee010e01b30100023318bb013b013301e001b001bb0103010e07bb023301e008ee0100033301b303bb01e001ee010e01b3010b023301b317bb013b0103010e01bb013b01e0010e06bb023301000aee0100033303bb010b02ee0130010b0130013301b317bb01330103010e01bb010301ee01b005bb013b013301030cee0100033302bb010b02ee0130010b0130023317bb01330103010e013b01e0010e05bb013b023301e00dee0100023301b302bb01e001ee0130010b0130023316bb013b013301e001b0010301ee01b004bb033301000fee0100023301b301bb01e001ee010e010b0130023301b315bb0133010301ee01b001e0010e04bb0333010011ee0130023301bb010b01ee010e010b010e033314bb013b0133010301ee013001e001b003bb0333010012ee010e0130013301b301bb01e0010e0103010e033301b313bb023301e0010e010b01ee01b002bb0333010014ee010e023301bb01e001ee01b00100043312bb013b0133010301ee010e0103010e02bb013b0233010010ee020004ee0130013301bb01e001ee01b001e00130033301b310bb013b0233010302ee01e001b002bb0233010310ee010e02bb010003ee010e013301b3010b01ee013001e0013004330fbb013b033301e003ee01b001bb0233010301e010ee01b0017b017701bb010003ee01300133010b01ee010e01ee013005330dbb0433010303ee010e01bb013b0133010301e011ee01b002bb017701bb01e002ee010e013301b301e002ee010e063301b309bb063301e003ee01b001bb0133010301e012ee013004bb010b01e002ee013001b301e003ee0130083305bb013b0633010303ee010e01bb013b013301e001ee010e010010ee010e023301b302bb010b02ee010e0133010b03ee0130143301e003ee010e01bb0133010001ee010001b001bb010010ee02000130013301b301bb010002ee0130010b03ee010e01301233010304ee01b0013b010301ee010e01bb017b017701bb01e011ee010e0100013001b301bb01e001ee010e010304ee010e1133010301e003ee010e01bb010001e0010e01b003bb01b7010b13ee010e013001b3010b01e001ee013001e004ee0130103301e004ee01b0010b01ee010e01b005bb010314ee010e013001b3010b01ee010e05ee010e01300e33010005ee010e01e0010e01b005bb013b010315ee010e013001b301e007ee010e01300c33010008ee01b002bb0433010301e016ee010e0130010b08ee010e01300a33010008ee010e01bb0233040001e018ee010e01b301e008ee010e01300733020009ee01b0013302001eee0100010b09ee010e07000aee010e0133010021ee01b001e01aee0130010322ee010e010b1aee010e01e023ee01e0feeefeeefeeefeeefeeefeee39ee0100"

function hex_to_num(str)
	return ("0x"..str)+0
end

function load_rle()
	local index=0
	for i=1,#title,4 do
		local count=hex_to_num(sub(title,i,i+1))
		local col=hex_to_num(sub(title,i+2,i+3))
		for j=1,count do
   poke(index,col)
		 index+=1
		end
	end
end

function clear_sprsheet()
	reload(0x0,0x0,0x2000)
end

--
fe_view.start=function()
 _init()
 load_rle()
end

--
fe_view.update=function()
 
 if front_end_fade_in>0 then
  front_end_fade_in-=one_frame
 else
  front_end_fade_in=0
  
  if btn(4) then
   current_view=game_view
   current_view.start()
   level_goto(map_x,map_y)
   player_x,player_y=64,74
  end
 end
end

--
fe_view.draw=function()
 cls()

 local fade=max(0,front_end_fade_in-1)
 local ft=-fade/.5
 local scale=ft*ft
 
 for a=0,1,1/5 do
  local s,c=sin(a-t/8),cos(a-t/8)
  for r=4,100*(1-2*fade),2 do
   local q=r/25-t
   local x,y,size=64+r*c+r/4*cos(q),64+r*s+r/4*sin(q),1+r/12
   circ(x+1,y+1,size,10)circfill(x,y,size,1)circ(x,y,size,5)
  end
 end
 
 palt(14,true)palt(0,false)
 pink_color_check()
 spr(0,0,-128*scale+3+3*sin(t/one_frame/21),16,16)
 pal()
 palt()
 
 if front_end_fade_in<.5 then
  if (t%.4<.3)print_outline("press \142 to start!",64,92,7,1)
 end

 print_outline("guerragames 2017",64,120,7,2)
end

front_end_fade_in=1.5


--
game_view={}

--
game_view.start=function()
 clear_sprsheet()
 
 jump_button:button_init()
 shoot_button:button_init()

 player_reset()
 enemies_init()
 ebs_reset()
 level_init() 
end

--
game_view.update=function()
 if(not game_finished)game_time+=one_frame
 
 player_update()
 bullets_update()
 
 if level_transition<=0 then
  enemies_update()
 end
 
 ebs_update()
 exps_update()
 sbs_update()
 level_update()
end

--
function score_draw()
 print_outline("scr:"..player_score..(player_score==0 and "" or "0"),2,2,7,2,align_l)
 print_outline("deaths:"..player_deaths,127,2,7,2,align_r)
 print_outline("-"..time_to_text(game_time).."-",64,2,7,2)
end

--
game_view.draw=function()
 if game_finished then
  exps_draw()
  game_end_draw()
  score_draw()
  return
 end 

 cls()
 
 if level_transition>0 and level_transition<1 then
  level_draw()
  player_draw()
  score_draw()
  if(level_transition>.3 and level_transition%.3<.2)print_outline("game saved!",64,64,7,8)
  return
 end

 if screen_flash_timer>0 then
  cls(screen_flash_color)
  return
 end
  
  map(map_x,map_y,0,0,16,16,0x10)
 
  score_draw()
 
  enemies_draw()
  player_draw()
  bullets_draw()
  exps_draw()
  ebs_draw()
  sbs_draw()
  
  level_title_draw()
end

--
current_view=fe_view
current_view.start()

--
function _update60()
 t+=one_frame
 
 update_screeneffects()
 jump_button:button_update()
 shoot_button:button_update()
 current_view.update()
end

--
function _draw()
 current_view.draw()
end
if(_update60)_update=function()_update60()_update_buttons()_update60()end