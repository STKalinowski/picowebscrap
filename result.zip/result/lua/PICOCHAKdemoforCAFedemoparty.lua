-- picochak
-- by megus and stardust

function rnd_arr(arr)
	return arr[flr(rnd(#arr)) + 1]
end

function rndp(r, a)
	return rnd(r) + a
end

function s3d(a, r, scale, yscale)
	local x, z = scos(a, r), ssin(a, r) + 200
	return 64 + scale * x / z, 60 + scale * ((x * yscale + 60) / z - 0.3), z
end

function draw_gradient(y, cols)
	local ptn = 1
	while y < 128 do
		rectfill(0, y, 127, y + 3, cols + dither[ptn])
		y += 4
		ptn = min(ptn + 1, 17)
	end
end

function set_palette(palette)
	for i = 1, #palette do pal(i, palette[i], 1) end
	stars_palette()
end

function chak_palette()
	set_palette({128, 133, 132, 4, 9, 10, 135, 7, 7, 7, 11, 12})
end

function stars_palette()
	pal(13, 1, 1)
	pal(14, 6, 1)
	pal(15, 7, 1)
end

function ssin(t, scale, tscale)
	return sin(t / (tscale or 1)) * scale
end

function scos(t, scale, tscale)
	return cos(t / (tscale or 1)) * scale
end

function sease_elastic(t, scale, tscale, p)
	p, scale = p or 0.3, scale or 1
	t /= tscale or 1
	return scale * (2 ^ (-10 * t)) * -sin((t - p / 4) / p) + scale
end

function sease_cubic(t, scale, tscale)
	scale = scale or 1
	t /= tscale or 1
	if (t < 0.5) return scale * (t * 2) ^ 3 / 2
	return scale - scale * ((1 - t) * 2) ^ 3 / 2
end

function dease_cubic(t, scale, tscale)
	return sease_cubic(t, scale, tscale) - sease_cubic(t - 1, scale, tscale)
end

function dease_elastic(t, scale, tscale)
	return sease_elastic(t, scale, tscale) - sease_elastic(t - 1, scale, tscale)
end

function out_of_screen(o)
	return band(o[1], 0xff80) ~= 0 or band(o[2], 0xff80) ~= 0
end

function px9_decomp(x0,y0,src)
	local function vlist_val(l, val)
		for i=1,#l do
			if l[i]==val then
				for j=i,2,-1 do
					l[j]=l[j-1]
				end
				l[1] = val
				return i
			end
		end
	end

	local cache,cache_bits=0,0
	function getval(bits)
		if cache_bits<16 then
			cache+=lshr(peek2(src),16-cache_bits)
			cache_bits+=16
			src+=2
		end
		local val=lshr(shl(cache,32-bits),16-bits)
		cache=lshr(cache,bits)
		cache_bits-=bits
		return val
	end

	function gn1()
		local bits,tot=1,1

		while 1 do
			local mx,vv=2^bits-1,getval(bits)
			tot+=vv
			bits+=1
			if (vv<mx) return tot
		end
	end

	local w,h,b,el,pr,x,y,splen,mode = gn1(),gn1(),gn1(),{},{},0,0,0

	for i=1,gn1() do
		add(el,getval(b))
	end
	for y=y0,y0+h-1 do
		for x=x0,x0+w-1 do

			splen-=1

			if splen<1 then
				splen,mode=gn1(),not mode
			end

			local a= y>y0 and sget(x,y-1) or 0

			local l=pr[a]
			if not l then
				l={}
				for e in all(el) do
					add(l,e)
				end
				pr[a]=l
			end

			local idx=mode and 1 or gn1()+1
			local v=l[idx]

			vlist_val(l, v)
			vlist_val(el, v)

			sset(x,y,v)

			x+=1
			y+=flr(x/w)
			x%=w
		end
	end
end

sr_stars, sr_mode, sr_dx, sr_dy, sr_new = {}, 0, 0, 0, {
	function(old_star)
		return old_star == nil and {rnd(128), rnd(128), rnd(5) - 2} or old_star
	end,

	function()
		return {0, 0, rnd(3), rnd(2) - 1, rnd(2) - 1, rndp(50, 50), rndp(3, 1)}
	end,

	function(old_star)
		return old_star == nil and {rnd(128), rnd(128), rnd(3), rndp(3, 1)} or {old_star[1], old_star[2], old_star[3], rndp(3, 1)}
	end,
}

function stars_set_mode(new_mode, new_dx, new_dy)
	sr_dx, sr_dy = new_dx or 1, new_dy or 0

	if sr_mode ~= new_mode then
		sr_mode = new_mode
		for i = 1, 50 do sr_stars[i] = sr_new[sr_mode](sr_stars[i]) end
	end
end

function stars_update()
	for i = 1, 50 do
		if (out_of_screen(sr_stars[i])) sr_stars[i] = sr_new[sr_mode]()

		local s = sr_stars[i]
		local s4, s6 = s[4], s[6]

		if sr_mode == 1 then
			s[3] += 0.03
			if (s[3] > 2.5) s[1] = 130
		elseif sr_mode == 2 then
			s[1] = 64 + s4 / s6 * 2500
			s[2] = 64 + s[5] / s6 * 2500
			s[6] -= s[7] * sr_dx
		else
			s[1] += s4 * sr_dx
			s[2] += s4 * sr_dy
		end
	end
end

function stars_draw()
	for s in all(sr_stars) do
		pset(s[1], s[2], 0x100f - abs(flr(s[3])))
	end
end

function init_galaxy()
local galaxy, colors, blows, scale = {}, {1, 6, 7, 10, 15}, {}, 120

for c = 1, 5 do
	for d = 1, 100 do
		add(galaxy, {d + rnd(), rndp(0.1, c / 5 + d / 100), rnd_arr(colors)})
	end
end

function galaxy_set_scale(nscale)
	scale = nscale
end

function galaxy_delete_star()
	del(galaxy, rnd_arr(galaxy))
end

function galaxy_blow_star()
	local star = del(galaxy, rnd_arr(galaxy))
	local x, y = s3d(star[2], star[1], scale, 0.33)
	add(blows, {x, y, 1})
end

function galaxy_update()
	for s in all(galaxy) do
		s[2] -= 0.001
	end
	for b in all(blows) do
		b[3] += 0.3
		if (b[3] > 10) del(blows, b)
	end
end

function galaxy_draw()
	for s in all(galaxy) do
		local x, y = s3d(s[2], s[1], scale, 0.33)
		pset(x, y, s[3])
	end

	for b in all(blows) do
		circfill(b[1], b[2], b[3], 0x107 + dither[flr(b[3] * 1.5)])
	end
end
end
function init_blows()
local blows = {}

function draw_blow(x, y, r)
	for col = 0x1008, 0x1005, -1 do
		circfill(x, y, r, col)
		r *= 0.75
	end
end

function blows_add(x, y)
	add(blows, {x, y, rnd(3)})
end

function blows_update()
	for blow in all(blows) do
		blow[3] += 0.3
		if (blow[3] > 16) del(blows, blow)
	end
end

function blows_draw()
	for blow in all(blows) do draw_blow(blow[1], blow[2], blow[3]) end
end
end
function spr_from_letter(letter)
	for c = 1, 40 do
		if letter == sub(texts, c, c) then
			c -= 1
			return 8 + c % 8 + flr(c / 8) * 16
		end
	end
end

function spr_letter(x, y, sprn, col)
	pal(7, 0)
	for c = -1, 1 do
		for d = -1, 1 do
			spr(sprn, x + c, y + d)
		end
	end
	pal(7, col)
	spr(sprn, x, y)
	pal(7, 7)
end

function pico_print(x, y, str)
	camera(0, -16)
	for c = -1, 1 do
		for d = -1, 1 do
			print(str, x + c, y + d, 0)
		end
	end
	print(str, x, y, 15)
	camera()
end

function spr_print(x, y, str, col)
	for c = 1, #str do
		spr_letter(x + c * 8 - 8, y, spr_from_letter(sub(str, c, c)), col or 7)
	end
end

function tnum(off)
	return tonum(sub(texts, t_idx + off, t_idx + off + 2))
end

function pico_text_show(sync)
	pt_idx1 = t_idx + 7
	pt_sx, pt_sy, pt_idx2, pt_show = tnum(1), tnum(4), pt_idx1, true

	if sync ~= false then
		wait_sync()
		pico_text_hide()
	end
end

function pico_text_hide()
	pt_show = false
end

function spr_text_show(col)
	st_sx, st_sy, st_col, st_letters, st_pletters, st_state = tnum(1), tnum(4), col or 14, {}, {}, 1

	for c = t_idx + 7, t_idx + 27 do
		local l = sub(texts, c, c)
		if l == "|" then
			t_idx = c
			break
		end
		add(st_letters, spr_from_letter(l))
		add(st_pletters, 0.08 - 0.01 * (c - t_idx))
	end
	st_len = #st_letters
end

function spr_text_hide()
	for c = 1, st_len do
		st_pletters[c], st_state = 0.01 - 0.01 * c, 2
	end
end

function tex_triangle(x1, y1, x2, y2, x3, y3, light, tx1, ty1, tx2, ty2, tx3, ty3)
	if (y1 > y2) y1, y2, x1, x2, ty1, ty2, tx1, tx2 = y2, y1, x2, x1, ty2, ty1, tx2, tx1
	if (y1 > y3) y1, y3, x1, x3, ty1, ty3, tx1, tx3 = y3, y1, x3, x1, ty3, ty1, tx3, tx1
	if (y2 > y3) y2, y3, x2, x3, ty2, ty3, tx2, tx3 = y3, y2, x3, x2, ty3, ty2, tx3, tx2

	local dy13, ttx1, ttx2, tty1, tty2, lx1, lx2 = y3 - y1, tx1, tx1, ty1, ty1, x1, x1
	local dx1, dtx1, dty1, dx2, dtx2, dty2, dy23 = (x3 - x1) / dy13, (tx3 - tx1) / dy13, (ty3 - ty1) / dy13

	local function tex_line(x1, x2, y, tx1, ty1, tx2, ty2)
		local dtx, dty = (tx2 - tx1) / (x2 - x1), (ty2 - ty1) / (x2 - x1)
		for x = x1, x2 do
			pset(x, y, colormap[flr(sget(tx1, ty1) * light)])
			tx1 += dtx
			ty1 += dty
		end
	end

	local function fill(y1, y2)
		for y = y1, min(y2, 127) do
			if lx1 > lx2 then
				tex_line(lx2, lx1, y, ttx2, tty2, ttx1, tty1)
			else
				tex_line(lx1, lx2, y, ttx1, tty1, ttx2, tty2)
			end

			lx1 += dx1
			lx2 += dx2
			ttx1 += dtx1
			tty1 += dty1
			ttx2 += dtx2
			tty2 += dty2
		end
	end

	if y2 > y1 then
		local dy12 = y2 - y1
		dx2, dtx2, dty2 = (x2 - x1) / dy12, (tx2 - tx1) / dy12, (ty2 - ty1) / dy12
		fill(y1, y2)
	end
	dy23, lx1, lx2, ttx1, tty1, ttx2, tty2 = y3 - y2, x1 + (y2 - y1) * dx1, x2, tx1 + (y2 - y1) * dtx1, ty1 + (y2 - y1) * dty1, tx2, ty2
	dx2, dtx2, dty2 = (x3 - x2) / dy23, (tx3 - tx2) / dy23, (ty3 - ty2) / dy23
	fill(y2, y3)
end


function triangle(x1, y1, x2, y2, x3, y3, col)
	if (min(x1, min(x2, x3)) > 127 or max(x1, max(x2, x3)) < 0 or min(y1, min(y2, y3)) > 127 or max(y1, max(y2, y3)) < 0) return

	if (y1 > y2) y1, y2, x1, x2 = y2, y1, x2, x1
	if (y1 > y3) y1, y3, x1, x3 = y3, y1, x3, x1
	if (y2 > y3) y2, y3, x2, x3 = y3, y2, x3, x2

	local dx1, tx1, tx2, dx2 = (x3 - x1) / (y3 - y1), x1, x1

	local function fill(y1, y2)
		for y = y1, min(y2, 127) do
			rectfill(tx1, y, tx2, y, col)
			tx1 += dx1
			tx2 += dx2
		end
	end

	if y2 > y1 then
		dx2 = (x2 - x1) / (y2 - y1)
		fill(y1, y2)
	end
	tx1, tx2, dx2 = x1 + (y2 - y1) * dx1, x2, (x3 - x2) / (y3 - y2)
	fill(y2, y3)
end

function tmatrix(angles, scale, offsets)
	local c1, c2, c3, s1, s2, s3 = cos(angles[1]), cos(angles[2]), cos(angles[3]), sin(angles[1]), sin(angles[2]), sin(angles[3])
	return mmult({2,0,0,0,0,2,0,0,0,0,-1,1,0,0,0.02,0},
		mmult({scale,0,0,offsets[1],0,scale,0,offsets[2],0,0,scale,offsets[3],0,0,0,1},
			{c2,s2*s3,c3*s2,0,s1*s2,c1*c3-c2*s1*s3,-c1*s3-c2*c3*s1,0,-c1*s2,c3*s1+c1*c2*s3,c1*c2*c3-s1*s3,0,0,0,0,1}))
end

function is_cw(p1, p2, p3)
	return (p2[1]-p1[1])*(p3[2]-p1[2])-(p2[2]-p1[2])*(p3[1]-p1[1])>0
end

function normal(p1, p2, p3)
	local ux, uy, uz, vx, vy, vz = p2[1]-p1[1], p2[2]-p1[2], p2[3]-p1[3], p3[1]-p1[1], p3[2]-p1[2], p3[3]-p1[3]
	local x, y, z = (uy * vz - uz * vy) / 256, (uz * vx - ux * vz) / 256, (ux * vy - uy * vx) / 256
	local len = sqrt(x*x+y*y+z*z)
	return {x/len,y/len,z/len}
end

function vmmult(v, m)
	local v1, v2, v3 = v[1], v[2], v[3]
	return {m[1]*v1+m[2]*v2+m[3]*v3+m[4],m[5]*v1+m[6]*v2+m[7]*v3+m[8],m[9]*v1+m[10]*v2+m[11]*v3+m[12],m[13]*v1+m[14]*v2+m[15]*v3+m[16]}
end

function mmult(m1, m2)
	local r = {}
	for c = 0, 3 do
		for d = 0, 3 do
			local t = 0
			for e = 0, 3 do
				t += m1[c*4+e+1]*m2[e*4+d+1]
			end
			add(r, t)
		end
	end
	return r
end

function radix_sort(arr, mask, idx1, idx2)
	local c, rb = idx1, idx2 + 1
	while c < rb do
		if band(arr[c][1], mask) ~= 0 then
			repeat
				rb -= 1
				if (rb == c) break
			until band(arr[rb][1], mask) == 0
			arr[c], arr[rb] = arr[rb], arr[c]
		end
		c += 1
	end
	if mask ~= 1 then
		mask /= 2
		if (rb - 1 > idx1) radix_sort(arr, mask, idx1, rb - 1)
		if (rb < idx2) radix_sort(arr, mask, rb, idx2)
	end
end

function get_v2d(vertices, matrix)
	local v2d = {}
	for v in all(vertices) do
		local pv = vmmult(v, matrix)
		add(v2d, {64 + pv[1] / pv[4], 64 - pv[2] / pv[4], pv[3]})
	end
	return v2d
end

function m3d_tex(vertices, tris, angles, scale, offsets)
	local v2d = get_v2d(vertices, tmatrix(angles, scale, offsets))

	for tri in all(tris) do
		local p1, p2, p3 = v2d[tri[1]], v2d[tri[2]], v2d[tri[3]]
		if is_cw(p1, p2, p3) then
			tex_triangle(p1[1], p1[2], p2[1], p2[2], p3[1], p3[2], -ssin(abs(normal(p1, p2, p3)[3]), 8, 4), tri[4], tri[5], tri[6], tri[7], tri[8], tri[9])
		end
	end
end

function m3d_shaded(vertices, tris, angles, scale, offsets)
	local sorted, v2d = {}, get_v2d(vertices, tmatrix(angles, scale, offsets))

	for tri in all(tris) do
		local p1, p2, p3 = v2d[tri[1]], v2d[tri[2]], v2d[tri[3]]
		if is_cw(p1, p2, p3) then
			local pv3 = normal(p1, p2, p3)[3]
			local light = min(1, abs(tri[5] < 2 and (pv3 * tri[5]) or (pv3 * pv3)))
			add(sorted, {p1[3] + p2[3] + p3[3], p1, p2, p3, tri[4] + (light < 0.2 and (0x10 + dither[9 - flr(light * 40)]) or (0x80 + dither[ceil(light * 20 - 3)]))})
		end
	end

	radix_sort(sorted, 0x400, 1, #sorted)

	for tri in all(sorted) do
		local p1, p2, p3 = tri[2], tri[3], tri[4]
		triangle(p1[1], p1[2], p2[1], p2[2], p3[1], p3[2], tri[5])
	end
end

function model_tris(r, s)
	local tris, lastidx = {}, (r - 2) * s + 2

    for c = 2, lastidx, s do
		for d = 0, s - 1 do
			local pc, nd = c - s, (d + 1) % s

			if c == 2 then
				add(tris, {1, d + 2, nd + 2, 3, 0})
			elseif c == lastidx then
				add(tris, {pc + d, c, pc + nd, 5, 2})
			else
				add(tris, {pc + d, c + d, pc + nd, 5, 2})
				add(tris, {pc + nd, c + d, c + nd, 5, 2})
			end
		end
	end
	return tris
end

function load_models()
	local addr = 9289
	for n in all({52, 44, 162, 225, 86}) do
		local vertices = {}
		for c = 1, n do
			local vertex = {}
			for d = 1, 3 do
				local v = peek(addr)
				if (v > 127) v = bor(v, 0xff00)
				add(vertex, v / 64)
				addr += 1
			end
			add(vertices, vertex)
		end
		add(m_vertices, vertices)
	end

	local tris = {{3, 51, 4, 5, 2}, {4, 51, 52, 5, 2}}
	for c = 3, 49, 2 do
		local c1, c2 = c + 1, c + 2
		add(tris, {1, c, c2, 5, 2})
		add(tris, {2, c + 3, c1, 5, 2})
		add(tris, {c2, c, c1, 7, 2})
		add(tris, {c2, c1, c + 3, 7, 2})
	end
	add(m_tris, tris)

	tris = model_tris(9, 6)
	for c = 9, 80, 4 do
		tris[c][4], tris[c][5], tris[c + 1][4], tris[c + 1][5] = 4, 0, 3, 0
	end
	add(m_tris, tris)

	add(m_tris, model_tris(12, 16))

	tris = {}
	for c = 1, 211, 15 do
		for d = 0, 14 do
			local nc, nd, col, diff = (c + 15) % 225, (d + 1) % 15, 4, 2
			if (d > 6) col, diff = 5, 0.5
			add(tris, {c + d, nc + d, c + nd, col, diff})
			add(tris, {c + nd, nc + d, nc + nd, col, diff})
		end
	end
	add(m_tris, tris)

	tris = model_tris(8, 14)
	local y, idx = {63, 60, 56, 50, 16, 8, 3, 0}, 1

	for c = 1, 7 do
		for d = 0, 13 do
			local tx1, ty1 = d * 4.5, y[c]
			local tx2, ty2 = tx1 + 4.5, y[c + 1]
			local tx3, ty3 = tx2, ty2

			local function upd_tri()
				local tri = tris[idx]
				tris[idx] = {tri[1], tri[2], tri[3], tx1, ty1, tx2, ty2, tx3, ty3}
				idx += 1
			end

			if c == 1 then
				tx1, tx2 = 32, tx1
			elseif c == 7 then
				tx2, ty3 = 32, ty1
			else
				ty3, tx2 = ty1, tx1
				upd_tri()
				ty3, tx1, tx2 = ty2, tx3, tx1
			end
			upd_tri()
		end
	end
	add(m_tris, tris)
end


function fx_sky_transition()
local y = (sky_dir == -1) and 128 or -64

stars_palette()
stars_set_mode(3, 0, sky_dir)

return function()
	wait_frames(60)
	sky_dir *= -1
end,

function()
	stars_update()
	y += sky_dir * 3.2
end,

function()
	stars_draw()
	draw_gradient(y, 0xc0)
end
end
function fx_intro()
local plogo = 0

px9_decomp(0, 64, 0x2000)
stars_palette()
init_galaxy()

return function()
	pico_text_show()

	spr_text_show()
	while loop_frames(90) do
		plogo = sease_elastic(frame, 96, 90)
	end

	wait_frames(60)

	spr_text_hide()
	while loop_frames(165) do
		plogo = scos(min(frame, 45), 96, 180)
		galaxy_set_scale(120 + frame * 3)
		galaxy_delete_star()
		galaxy_delete_star()
		stars_set_mode(2, min(frame / 125, 2))
	end
end,

function()
	stars_update()
	galaxy_update()
end,

function()
	stars_draw()
	galaxy_draw()
	spr(128, 14, 128 - plogo, 13, 8)
end
end
function fx_foodstars()
set_palette({0x80, 0x85, 0x84, 4, 9, 10, 0x87, 7, 3, 0x8c, 0x84, 0x88})
px9_decomp(0, 64, 8903)

local angles, model, pcoords, scale, phalo, camerax, pfade, sprs, planets =
	{0.23, 0, 0}, 1, {}, 0, 0, 0, 0, {{48, 88}, {72, 88}, {0, 64}, {24, 64}, {48, 64}, {72, 64}, {0, 88}, {24, 88}}

local function draw_planet(p)
	pal(7, 8)
	pal(1, 9 + p[5])
	local p4 = p[4]
	sspr(sprs[p[6]][1], sprs[p[6]][2], 24, 24, p[2] - p4, p[3] - p4, p4 * 2, p4 * 2)
	pal(7, 7)
	pal(1, 1)
end

local function draw_orbit(phase)
	for c = 1, #planets do
		local oldx, oldy
		for d = 0, 15 do
			local x, y = s3d((d + phase) / 30, planets[c][1], scale, 0)
			if (oldx ~= nil) line(oldx, oldy, x, y, 0x1109.a5a5)
			oldx, oldy = x, y
		end
	end
end

return function()
	for c = 1, 3 do
		model, pfade = c, 0
		stars_set_mode(2, 2)
		wait_frames(15)

		planets = {}
		for c = 65, 125, 20 do
			add(planets, {c, rnd(), flr(rnd(4)), rndp(5, 5), rndp(0.005, 0.002)})
		end

		while loop_frames(90) do
			stars_set_mode(2, dease_elastic(frame, 12, 90))
			scale = sease_elastic(frame, 100, 90)
		end

		stars_set_mode(1)
		spr_text_show()
		pico_text_show()
		spr_text_hide()

		pfade = 1
		while loop_frames(30) do
			stars_set_mode(2, 2)
			scale, camerax = 600 - scos(frame, 500, 120), frame * frame / 4
		end

		pfade, camerax, scale = 2, 0, 0
		wait_frames(15)
	end
end,

function()
	stars_update()

	phalo += 0.01
	angles[1] += 0.005
	angles[2] += 0.003
	angles[3] += 0.001

	for planet in all(planets) do
		planet[2] -= planet[5]
	end
end,

function()
	stars_draw()

	if scale ~= 0 then
		camera(camerax, 0)

		for c = 1, #planets do
			local planet = planets[c]
			local x, y, z = s3d(planet[2], planet[1], scale, 0)
			pcoords[c] = {z, x, y, planet[4] * scale / z, planet[3], band(planet[2] * 8 + 1, 0x7) + 1}
		end

		draw_orbit(15)

		for planet in all(pcoords) do
			if (planet[1] >= 200) draw_planet(planet)
		end

		circfill(64, 64, scale * (0.325 + ssin(phalo, 0.025)), 0x1107.7fdf)
		circfill(64, 64, scale * (0.25 + ssin(phalo, 0.05, 0.83)), 0x1107.5f5f)

		m3d_shaded(m_vertices[model], m_tris[model], angles, scale, {0, 0, 400})

		draw_orbit(0)

		for planet in all(pcoords) do
			if (planet[1] < 200) draw_planet(planet)
		end

		camera()
	end

	if pfade == 1 and frame > 10 then
		circfill(104 - frame * 4, 64, frame * 9 - 90, 0x110f)
	elseif pfade == 2 then
		rectfill(0, 0, 128, 128, 0x10f + dither[frame + 1])
	end
end
end
function fx_donuts()
local donuty, donutx, show_mega, offy, angles, tunnel, tunnel_active, move_donuts, px, py, dscale =
	128, 0, false, 210, {0, 0, 0}, {}, false, false, 0, 0, 47

set_palette({128, 133, 132, 4, 9, 10, 7, 7, 9, 10, 11, 0})

local function show_tunnel()
	tunnel_active = true
	for c = 1, 8 do
		add(tunnel, {10, rnd(14)})
		wait_frames(10)
	end
	wait_sync()
	tunnel_active = false
end

return function()
	pico_text_show(false)
	wait_frames(60)
	show_tunnel()
	stars_set_mode(1)
	pico_text_hide()
	wait_frames(30)

	while loop_frames(64) do
		donuty -= 2
	end

	move_donuts, show_mega = true, true
	wait_frames(120)
	while loop_frames(210) do
		offy -= 1
	end
	wait_sync()
	move_donuts = false
	while loop_frames(64) do
		donuty += 3
	end

	spr_text_show()
	pico_text_show()
	pico_text_show()
	spr_text_hide()
	stars_set_mode(2, 2)
	wait_frames(30)
	show_tunnel()

	while loop_frames(15) do
		dscale += 10
	end
end,

function()
	stars_update()
	angles[1] += 0.005
	angles[2] += 0.007
	angles[3] += 0.002
	if move_donuts then
		donutx, donuty = ssin(px, 32) - 32, ssin(py, 32) - 32
		px += 0.005
		py += 0.007
	end

	for r in all(tunnel) do
		r[1] *= 1.12
		if r[1] > 80 and tunnel_active then
			r[1], r[2] = rndp(4, 8), rnd(14)
		end
	end
end,

function()
	stars_draw()

	for r in all(tunnel) do
		circ(64, 64, r[1], flr(r[2]) + 0x1001)
	end

	local y, f = donuty, 0

	while y < 128 do
		local x = donutx + f
		while x < 128 do
			spr(171, x, y, 2, 2)
			x += 32
		end
		y += 16
		f = bxor(f, 16)
	end

	if (show_mega) m3d_shaded(m_vertices[4], m_tris[4], angles, dscale, {0, offy, 200})
end
end
function fx_donut_attack()
local bg, bgc, lasers, donuts = 0, 0, {}, {}

stars_palette()
init_galaxy()

local function random_line(t)
	local a1, a2 = rnd(), rnd()
	add(t, {ssin(a1, 120) + 64, scos(a1, 120) + 64, ssin(a2, 120) + 64, scos(a2, 120) + 64, 20})
end

return function()
	while loop_sync() do
		if (rnd() < 0.4) random_line(lasers)
		if (rnd() < 0.7) random_line(donuts)
		if (rnd() < 0.1) galaxy_blow_star()
	end

	bgc = 1000
	pico_text_show()
end,

function()
	stars_update()
	galaxy_update()

	if (bgc <= 0) bgc = rnd(20) + 10
	bg = bgc < 10 and (flr(bgc % 2) * 2) or 0
	bgc -= 0.4

	for l in all(lasers) do
		l[5] -= 1
		if (l[5] == 0) del(lasers, l)
	end

	for d in all(donuts) do
		d[1] += (d[3] - d[1]) * 0.05
		d[2] += (d[4] - d[2]) * 0.05
		if (abs(d[3] - d[1]) < 1 and abs(d[4] - d[2]) < 1) del(donuts, d)
	end
end,

function()
	cls(bg)
	stars_draw()
	galaxy_draw()

	for l in all(lasers) do
		local x1, y1, x2, y2 = l[1] + rnd(2), l[2] + rnd(2), l[3] + rnd(2), l[4] + rnd(2)
		line(x1 + 3, y1, x2 + 3, y2, 0x1102)
		line(x1, y1, x2, y2, 0x1107 + rnd())
		line(x1 + 1, y1, x2 + 1, y2, 0x110a + rnd())
	end

	pal(12, 0)
	for donut in all(donuts) do
		spr(171, donut[1], donut[2], 2, 2)
	end
end,

-1
end
function fx_preparations(sprnum, dpx, dpy, final)
local ppx, ppy, starty, particles, sm, pgrad, grady, bugx, bstate = 0, 0, 56, {}, 0, 128, 128, 0, 0

for c = 1, 24 do
	particles[c] = {0, 0, 0, rndp(60, 30), 0, 0, rnd(), rnd()}
end

local function new_particle(c, p4, p7, p8)
	local p = particles[c]
	particles[c] = {p[1], p[2], 0, p4, p[1], p[2], p7, p8}
end

local function move_particles()
	for c = 1, #particles do
		local p = particles[c]
		local p3, p4, p5, p6 = p[3], p[4], p[5], p[6]
		local ease = sease_cubic(p3, 1, p4)
		p[1] = p5 + ease * (p[7] - p5)
		p[2] = p6 + ease * (p[8] - p6)
		p[3] += 1
		if p3 >= p4 then
			new_particle(c, rndp(30, 30), rnd(), rnd())
		end
	end
end

return function()
	while loop_frames(240) do
		move_particles()
	end

	for c = 1, #particles do
		new_particle(c, 60, c / #particles, 0.9)
	end
	dpy, bstate = (ppx + dpx * 60 - ppy) / 60, 1

	while loop_frames(60) do
		bugx = 128 - sease_elastic(frame, 64, 60)
		move_particles()
	end

	bstate, dpx, dpy = 2, 0.01, 0.01
	wait_sync()

	bstate = 3
	if final == true then
		ppx, ppy = band(ppx, 0x0.ffff), band(ppy, 0x0.ffff)
		dpx, dpy = -ppx / 120, -ppy / 120
		for c = 1, #particles do
			new_particle(c, 120, rndp(0.14, 0.68), rndp(0.7, 0.3))
		end

		while loop_frames(120) do
			bugx = 64 - sease_cubic(frame, 128, 60)
			move_particles()
		end

		while loop_frames(90) do
			starty, dpx, dpy = 56 + frame / 1.1, 0, 0
			grady += 2
		end
	else
		while loop_frames(90) do
			bugx, starty = 64 - sease_cubic(frame, 128, 60), 56 - sease_cubic(frame, 140, 90)
		end
	end
end,

function()
	ppx += dpx
	ppy += dpy
	pgrad += 0.005
	grady = max(80, grady - 1)
end,

function()
	local cnt = (bstate == 2) and min(flr(frame / 1.3), 24) or 24

	local function draw_bugulma()
		palt(12, true)
		palt(0, false)
		spr(128, bugx - 29, 32, 9, 8)
		if bstate ~= 1 then
			spr_print(bugx - (cnt < 10 and 4 or 8), 72, "" .. cnt)
			rectfill(bugx - 16, 83, bugx - 16 + min(cnt * 1.33, 31), 86, 0x1008)
		end
		palt()
	end

	draw_gradient(grady + ssin(pgrad, 10), 0xfc)

	if (bstate % 2 == 1) draw_bugulma()
	pal(12, 0)
	for c = 1, #particles do
		local p = particles[c]
		local x, y = 56 + scos(p[1] + ssin(ppx, 0.128), p[2] * 64), starty + ssin(p[1] + ssin(ppy, 0.125), p[2] * 64)
		if bstate == 2 and c <= cnt then
			line(64, 64, x + 8, y + 8, 0x1105.5a5a)
		end
		spr(sprnum, x, y, 2, 2)
	end
	pal()

	if (bstate == 2) draw_bugulma()
end,

12
end

function fx_twister()
local pa, px, ptx, aspd, alspd, pattern, colors, ystart, y1end, y2end, w1, w2, amp, condense =
{0, 0.4}, {0.1, 0.5}, 0, {0.015, 0.007}, {-0.001, 0.003}, 0x1000.5a5a, {0x45, 0x55, 0x56, 0x66, 0x67, 0x78, 0x88}, 0, 0, 0, 8, 8, 32, 0.001

chak_palette()

local function draw_twister(y, tt, tpx, w)
	local adder, sides = scos(tpx, amp) + 64, #colors
	for c = 1, sides do
		local x1, x2 = sin(tt) * w + adder, ssin(tt + (1 / sides), w) + adder
		if (x2 > x1) rectfill(x1, y, x2, y, colors[c] + pattern)
		tt += 1 / sides
	end
end

return function()
	while loop_frames(65) do
		amp, y1end, w1 = 5, frame * 2, 0.5
	end

	while loop_frames(240) do
		w1, amp, alspd[1] = 0.5 + min(frame / 12, 10), 5 + min(frame / 10, 30), -abs(ssin(frame, 0.005, 240))
	end

	while loop_frames(65) do
		y2end, w2 = frame * 2, 0.5
	end

	while loop_frames(240) do
		w2, alspd[2] = 0.5 + min(frame / 12, 10), -abs(ssin(frame, 0.005, 240))
	end

	while loop_sync() do
		alspd, condense = {-abs(ssin(frame, 0.007, 250)), -abs(ssin(frame, 0.006, 223))}, 0.006 - scos(frame, 0.005, 200)
	end

	while loop_frames(120) do
		w1 = 10 - min(frame / 12, 9.5)
		w2 = w1
	end

	while loop_frames(64) do
		ystart = min(128, frame * 2)
	end
end,

function()
	ptx += 0.01
	for c = 1, 2 do
		px[c] += 0.01
		pa[c] += aspd[c]
	end
end,

function()
	pattern = bxor(pattern, 0x0.ffff)
	local tpa, tpx = {pa[1], pa[2]}, {px[1], px[2]}
	for y = ystart, 127 do
		if band(tpx[1], 0x0.ffff) > 0.5 then
			if (y < y1end) draw_twister(y, tpa[1], tpx[1], w1)
			if (y < y2end) draw_twister(y, tpa[2], tpx[2], w2)
		else
			if (y < y2end) draw_twister(y, tpa[2], tpx[2], w2)
			if (y < y1end) draw_twister(y, tpa[1], tpx[1], w1)
		end

		for c = 1, 2 do
			tpx[c] -= condense
			tpa[c] += alspd[c]
		end
	end
end,
12
end

function fx_kaleidoscope()
local zph, zzoom, zpx, zpy = 0, 1, 0, 0
px9_decomp(0, 0, 11008)

return function()
	for c = 1, 8 do
		spr_text_show(15)
		wait_frames(55)
	end
	spr_text_hide()
	wait_sync()
end,

function()
	zph += 0.002
	zpx += 0.003
	zpy += 0.004
	zzoom += 0.002
end,

function()
	local s, f = 0.8 + ssin(zzoom, 0.4), frame % 2
	local zdx, zdy, zsx, zsy = scos(zph, s), ssin(zph, s), ssin(zpx, 20), ssin(zpy, 20)

	for y = 0, 63 do
		local ztx, zty = zsx + (y + f) * (zdy + zdx), zsy + y * (zdx - zdy)

		for x = y + f, 63, 2 do
			local xm, ym = 127 - x, 127 - y
			pset(x, y, sget(ztx % 64, zty % 64))
			pset(xm, y)
			pset(x, ym)
			pset(xm, ym)
			pset(y, x)
			pset(ym, x)
			pset(y, xm)
			pset(ym, xm)
			ztx += zdx * 2
			zty -= zdy * 2
		end
	end
end,

-1
end
function fx_picochak()
local angles, offsets, rotate = {0, 0, 0}, {0, -300, 300}, false
chak_palette()

return function()
	while loop_frames(180) do
		local ease = sease_cubic(frame, 1, 180)
		stars_set_mode(3, 0, 1 - ease)
		offsets[2] = ease * 300 - 300
	end

	stars_set_mode(1)
	pico_text_show(false)

	rotate = true
	wait_sync()

	pico_text_hide()
	while loop_frames(104) do
		local ease = sease_cubic(frame, 1, -104)
		stars_set_mode(3, ease)
		offsets[1] = ease * 150
	end
end,

function()
	stars_update()
	if rotate then
		angles[1] += 0.006
		angles[2] += 0.003
		angles[3] += 0.002
	end
end,

function()
	stars_draw()
	m3d_tex(m_vertices[5], m_tris[5], angles, 150, offsets)
end
end
function fx_bullet_hell()
local bullets, sprs, ptn, donuts, heroes, sprn = {}, {141, 139, 108}, 17, {}, {}

set_palette({1, 2, 3, 4, 9, 10, 135, 7, 9, 10, 8, 0})
stars_set_mode(3, -1)
init_blows()

local function donut_xy(a)
	return 190 - scos(a, 100), 72 + ssin(a, 100)
end

return function()
	wait_frames(17)
	for c = 1, 3 do
		sprn = c
		init_blows()
		for d = 0, 1, 0.025 do
			add(donuts, d)
		end

		for d = 0, 127, 16 do
			add(heroes, {0, d})
		end

		while loop_frames(255) do
			if rnd() < 0.4 + c * 0.1 then
				local x, y = donut_xy(rnd_arr(donuts))
				if c == 1 then
					for d = -1, 1 do
						for e = 0, 3, 3 do add(bullets, {x, y, 1, 10, 2, d, e}) end
					end
				else
					for a = -0.125, 0.125, 0.05 do
						for d = 0, c do add(bullets, {x, y, c - 1, 11, scos(a, 2), ssin(a, 2), d * 5}) end
					end
				end
			end
			local h = rnd_arr(heroes)
			add(bullets, {h[1], h[2] + 8, 2, 6, -3, 0, 0})

			if rnd() < 0.02 and #heroes ~= 1 then
				local h = rnd_arr(heroes)
				blows_add(h[1] + 8, h[2] + 8)
				del(heroes, h)
			end

			if rnd() < 0.1 and #donuts ~= 1 then
				local d = rnd_arr(donuts)
				local x, y = donut_xy(d)
				blows_add(x + 8, y)
				del(donuts, d)
			end

			if (frame == 239) ptn = 17
		end
		donuts, heroes, bullets = {}, {}, {}
	end
	init_blows()
	wait_frames(60)
end,

function()
	stars_update()
	blows_update()

	for b in all(bullets) do
		if b[7] == 0 then
			b[1] -= b[5]
			b[2] += b[6]
			if (out_of_screen(b)) del(bullets, b)
		else
			b[7] -= 1
		end
	end

	for c = 1, #donuts do
		donuts[c] += 0.003
	end

	for h in all(heroes) do
		h[1] += 0.1
	end

	ptn = max(-17, ptn - 1)
end,

function()
	stars_draw()

	for b in all(bullets) do
		if b[7] == 0 then
			circfill(b[1], b[2], b[3] + 1, 14)
			circfill(b[1], b[2], b[3], b[4])
		end
	end

	for d in all(donuts) do
		local x, y = donut_xy(d)
		spr(171, x, y - 8, 2, 2)
	end

	for h in all(heroes) do
		spr(sprs[sprn], h[1], h[2], 2, 2)
	end

	blows_draw()
	rectfill(0, 0, 127, 127, 0x10f + dither[max(1, abs(ptn))])
end
end
function fx_final_strike()
local offx, hero, shake, pa1, pa2, rblow, dblow, rayx1, rayx2 = 0, 1, false, 0, 0, 0, 0, -1000, -1000

chak_palette()
init_blows()

local function model_move(frames, x, distance, stars_scale, ease, dease)
	while loop_frames(frames) do
		offx = ease(frame, distance, frames) + x
		stars_set_mode(3, dease(frame, stars_scale, 54))
	end
	stars_set_mode(1)
end

local function hero_phrase(h, x11, x12, x21, x22, ss)
	spr_text_show()
	pico_text_show(false)
	hero = h
	model_move(54, x11, x12, 3 * ss, sease_elastic, dease_elastic)

	wait_frames(55)

	spr_text_hide()
	pico_text_hide()
	model_move(27, x21, x22, -12 * ss, sease_cubic, dease_cubic)
end

local function rnd_blow()
	local r, a = rndp(15, 15), rnd()
	blows_add(64 + ssin(a, r), 64 + scos(a, r))
end

return function()
	for c = 1, 3 do
		hero_phrase(1, -150, 150, 0, -225, 1)
		hero_phrase(2, 150, -150, 0, 225, -1)
	end

	shake, hero = true, 1
	model_move(60, -150, 150, 3, sease_elastic, dease_elastic)
	dblow = 0.5
	wait_frames(120)
	dblow, rayx1, rayx2 = 0, 64, 128
	wait_frames(60)

	model_move(30, 0, -200, -12, sease_cubic, dease_cubic)
	hero, rayx1, rblow = 2, -1000, 0
	model_move(60, 150, -150, -3, sease_elastic, dease_elastic)
	wait_frames(30)
	rayx1, rayx2 = -1000, -1000

	for c = 1, 90 do
		for d = 1, 4 do
			rnd_blow()
		end
		wait_frames(1)
	end

	hero = 0
	for c = 1, 20 do
		rnd_blow()
		wait_frames(2)
	end
	shake = false

	pico_text_show()
end,

function()
	pa1 += 0.005
	pa2 += 0.003
	rblow += dblow

	stars_update()
	blows_update()
end,

function()
	if (shake) camera(rndp(4, -2), rndp(4, -2))
	stars_draw()

	rectfill(rayx1 + offx, 40, rayx2, 88, 8)
	if (rblow ~= 0) draw_blow(64 + offx, 64, rblow)

	local angles, offsets = {ssin(pa1, 0.1) + 0.05, scos(pa2, 0.1), 0}, {offx, 0, 200}
	if hero == 1 then
		m3d_tex(m_vertices[5], m_tris[5], angles, 110, offsets)
	elseif hero == 2 then
		m3d_shaded(m_vertices[4], m_tris[4], angles, 44, offsets)
	end

	blows_draw()
end
end
function fx_dancing_chak()
local angle, balls, rings, y1, y2, hl, p, t1, t2 = 0, {}, -4, 96, 80, 0, -1, {32, 64, 80, 96, 250}, {96, 127, 16, 32, 64}
stars_palette()

return function()
	while loop_frames(1268) do
		if frame % 32 == 0 then
			for c = 1, 8 do
				add(balls, {rnd(128), rnd(128), rndp(10, 8), flr(rndp(8, 0x107)), 0.75})
			end
			rings = min(5, rings + 1)
		end

		if rings == 5 then
			if frame % 128 == 0 then
				p = (p + 1) % 4
				hl = p == 3 and 2 or 0
				if (p == 3 or p == 0) y1, y2 = y2, y1
			end

			local t = (p == 3) and t2[hl + 1] or t1[hl + 1]
			if (frame % 128 >= t) hl = (hl + 1) % 5
		end
	end
end,

function()
	stars_update()
	angle += 0.005

	for b in all(balls) do
		b[5] += 0.25
		if (b[5] == 17) del(balls, b)
	end
end,

function()
	stars_draw()
	pal(12, 12)
	for b in all(balls) do
		circfill(b[1], b[2], b[3], b[4] + dither[flr(b[5])])
	end

	pal(12, 0)
	local jumpy = abs(ssin(frame, 8, 64))
	for i = 0, 0.9, 0.1 do
		for j = 1, rings do
			local a = angle + i + ssin(j, ssin(frame, 0.03, 64), 4)
			spr(173, 56 + ssin(a, j * 10), 60 + scos(a, j * 10) - jumpy, 2, 2)
		end
	end

	local function kprint(x, y, text, n)
		spr_print(x, y - jumpy, text, hl == n and 11)
	end

	if rings == 5 then
		kprint(12, y1, "dance!", 0)
		kprint(68, y1, "dance!", 1)
		kprint(28, y2, "pico", 2)
		kprint(44, y2, "co", 3)
		kprint(60, y2, "chak!", 4)
	end

end
end

function fx_epilogue()
poke4(0x5f40, 0x2.080f)
music(0x2d)
chak_palette()

local px, py, bumpmap, idx, txty, notdone, text = 0, 0, {}, 1, 115, true,
	{'p i c o c h a k', 'pico-8 demo', 'by megus and stardust', '', 'code', 'megus', '', 'music', 'n1k-o / stardust', '', 'graphics', 'diver / stardust', '', 'presented at', 'cafe 2019', '', 'no donuts were eaten', 'in the making of this demo', '', '', 'thank you for watching!'}

for y = -16, 15 do
	for x = -16, 15 do
		add(bumpmap, 4 * max(0, 24 - flr(sqrt(x * x + y * y))))
	end
end

return function()
	while notdone do yield() end
	music(-1, 8000)
	for c = 1, 96 do
		for d = 1, #bumpmap do
			bumpmap[d] = max(0, bumpmap[d] - 1)
		end
		wait_frames(3)
	end
	stop()
end,

function()
	px += 0.0057
	py += 0.007

	if notdone then
		if txty < -24 then
			txty += 16
			idx += 1
			if (idx > #text) notdone = false
		else
			txty -= 0.5
		end
	end
end,

function()
	local lightx, ly = flr(ssin(px, 22) - 16), flr(scos(py, 22) - 16)
	for y = 1, 63 do
		local lx = lightx
		for x = 1, 63 do
			local xdelta, ydelta = sget(x - 1, y) - sget(x + 1, y), sget(x, y - 1) - sget(x, y + 1)
			local xtemp, ytemp = lx + xdelta * 2, ly + ydelta * 2
			if band(xtemp, 0xffe0) == 0 and band(ytemp, 0xffe0) == 0 then
				rectfill(x * 2, y * 2, x * 2 + 1, y * 2 + 1, colormap[bumpmap[ytemp * 32 + xtemp + 1]])
			end
			lx += 1
		end
		ly += 1
	end

	if notdone then
		local ty, tidx = txty, idx
		while ty < 115 and tidx <= #text do
			local str = text[tidx]
			pico_print(64 - #str * 2, ty, str, 8)

			ty += 16
			tidx += 1
		end
	end
end
end

t_idx,st_len,pt_show,sky_dir,sc_idx,mfx_idx,mfx_l1,mfx_l2,colormap,m_vertices,m_tris,texts,dither,scenario,mfx_scenario=
41, 0, false, -1, 1, 1, 0x4300, 0x4300, {}, {}, {},
"abcdefghijklmnopqrstuvwxyz0123456789/-! |0  48 a long time ago in tatar galaxy\nfar-far away, there lived\npeaceful sentient food folks.\n\nlet's meet some of them!|-8 24 attack of donuts|-8 36 qistibi|0  88 system is inhabited by sentient\nmashed potato stuffed flatbreads\ntatar spirit is strong with them|-8 36 ochpochmak|0  88 triangular pies filled with\nminced beef, potatoes and onion\nlive and prosper in this system|-8 36 peremech|0  88 nice and round pies with beef\nand onion filling happily live\nhere in peace and harmony|18 44 meanwhile, somewhere in\n  junk food galaxy...|-8 36 mega donut|0  88 let's conquer those weaklings\nfrom tatar food galaxy!|0  88 we, donuts, are superior food!\nwe will reign over the universe!|0  52 donuts conquered tatar galaxy...\n\nbut the war is not lost yet.\nbrave tatar warriors started\npreparing to strike back!|18 68 lexaloffle|64 91 ate bit|17 86 razor1911|27 41 jumalauta|23 57 excess team|3  45 gemba|37 84 triad|50 75 demarche|1  25 hprg|40 43 the sands|10 86 fairlight|59 99 scoopex|8  24 censor design|20 69 serzhsoft|41 98 prosonix|29 25 outsiders|-4 34 genesis project|70 51 joker|7  56 sibcrew|37 89 q-bone|13 46 offence|18 33 goblinish|25 99 gdc|60 -8 all party people|0  80 here comes the picochak!\nthe epic tatar galaxy warrior.\nwith his supreme powers\ntatar food galaxy still has\nthe chance to survive!|-8 36 picochak|0  88 die, you piece of junk!|40 36 mega donut|0  88 no you!|-8 36 picochak|0  88 we are healthier food than you!|40 36 mega donut|0  88 but i'm more delicious!|-8 36 picochak|0  88 prepare to die, bastard!|40 36 mega donut|0  88 ? ? ?|0  44 so, picochak won this battle\nand the galaxy is free again!\n\nit's time to celebrate!|",
{0x1000.0000,0x1000.8000,0x1000.8020,0x1000.a020,0x1000.a0a0,0x1000.a4a0,0x1000.a4a1,0x1000.a5a1,0x1000.a5a5,0x1000.e5a5,0x1000.e5b5,0x1000.f5b5,0x1000.f5f5,0x1000.fdf5,0x1000.fdf7,0x1000.fff7,0x1000.ffff,0x1000.ffff},
{
fx_intro, 1,
fx_foodstars, 4, 6, 8,
fx_donuts, 9, 13, 15, 17, 19,
fx_donut_attack, 25, 27,
fx_sky_transition,
function() return fx_preparations(104, 0, 0) end, 29,
fx_kaleidoscope, 31,
function() return fx_preparations(106, 0.009, 0.0086) end, 33,
fx_kaleidoscope, 35,
function() return fx_preparations(108, 0.001, -0.01) end, 37,
fx_kaleidoscope, 39,
function() return fx_preparations(110, 0.01, 0.01, true) end, 41,
fx_twister, 46,
fx_sky_transition,
fx_picochak, 49,
fx_bullet_hell,
fx_final_strike, 71,
fx_dancing_chak,
fx_epilogue
},
{
-- 0x0F0D.0R0H
0, 0x0.04,
8, 0x090C.8,
9, 0,
13, 0x0404,
15, 0x0d0e.8,
16, 0,
23, 0x0404,
24, 0x131c.8,
27, 0x0.01,
31, 0x0.09,
39, 0x2.09,
47, 0x0.8,
48, 0x1d28.8,
49, 0x0.08,
72, 0x292c.8,
73, 0x2.080a,
78, 0x2d2e.8,
32767
}


function loop_int(r)
	yield()
	frame += 1
	if (not r) frame = 0
	return r
end

function loop_frames(frames)
	return loop_int(frame <= frames)
end

function wait_frames(frames)
	while loop_frames(frames) do end
end

function loop_sync()
	local r = mfx_time < scenario[sc_idx]
	if (not r) sc_idx += 1
	return loop_int(r)
end

function wait_sync()
	while loop_sync() do end
end

function next_fx()
	pal()
	camera()
	reload(0, 0, 8192)
	fx_coupdate, fx_update, fx_draw, fx_bg = scenario[sc_idx]()
	fx_coupdate, frame = cocreate(fx_coupdate), -1
	sc_idx += 1
end

function toggle_loop(a)
	poke(a, bxor(peek(a), 0x80))
end

function sfx_copy(src, dest, count, size)
	for c = 1, count do
		memcpy(dest, src, size)
		src += 64
		dest += size
	end
end

function _init()
	poke(0x5f34, 1)

	for c = 2, 9 do
		for d = 1, 16 do
			add(colormap, c + c * 16 + 16 + dither[d])
		end
	end

	load_models()
	stars_set_mode(1)
	music()

	next_fx()
end

function _update60()
	mfx_time = stat(25) + stat(26) / 4096

  if mfx_time >= mfx_scenario[mfx_idx] then
		local cmd = mfx_scenario[mfx_idx + 1]
    mfx_idx += 2
		if band(cmd, 0x0.8) == 0 then
			poke4(0x5f40, cmd)
		elseif cmd == 0x0.8 then
			sfx_copy(2592, 0x3420, 8, 32)
			sfx_copy(6180, 0x3520, 32, 28)
		else
			toggle_loop(mfx_l1)
			toggle_loop(mfx_l2)
			mfx_l1, mfx_l2 = 0x3100 + band(cmd, 0x3f00) / 64, 0x3101 + band(cmd, 0x3f) * 4
			toggle_loop(mfx_l1)
			toggle_loop(mfx_l2)
		end
  end

	if (not coresume(fx_coupdate)) next_fx()
	fx_update()

	if pt_show then
		if (sub(texts, pt_idx2, pt_idx2) ~= "|") pt_idx2 += 1 else t_idx = pt_idx2
	end

	if st_len ~= 0 then
		local count = 0
		for c = 1, st_len do
			if st_pletters[c] >= 1 then
				count += 1
			else
				st_pletters[c] += (st_state == 1 and 0.02 or 0.05)
			end
		end
		if (count == st_len and st_state == 2) st_len = 0
	end
end

function _draw()
	if (fx_bg ~= -1) cls(fx_bg or 0)
	fx_draw()
	camera()

	if (pt_show) pico_print(pt_sx, pt_sy, sub(texts, pt_idx1, pt_idx2 - 1))

	for c = 1, st_len do
		if st_letters[c] ~= 79 then
			local pl, y = st_pletters[c]
			if st_state == 1 then
				y = pl < 0 and 0 or sease_elastic(pl, st_sy, 1, 0.5)
			else
				y = pl < 0 and st_sy or scos(pl, st_sy, 4)
			end
			spr_letter(st_sx + c * 8, 128 - y, st_letters[c], st_col)
		end
	end
end

----------------