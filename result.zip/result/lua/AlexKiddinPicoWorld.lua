function a() b=1 c=1 d=0 e=f g=h i=0 j=3 k=0 for l=1,7 do m[l]=0 end n() for o=1,16 do for p=1,16 do mset(o-1,p-1,q[o][p]) end end r(b,c) end s,t=0 u=8 v=28 w=58 x=70 y=7 z=54 ba=11 bb=31 bc=17 bd=63 be=66 bf=96 bg=75 bh=0 bi=6 bj=7 bk=23 bl=31 bm=27 bn=33 bo=0 bp=1 bq=2 br=3 bs=4 bt=5 bu=7 bv=nil bw=0 bx={} by=false bz=0 ca=0 cb=0 cc=0 cd=0 ce={6,6,14,13} cf=1 cg=1 ch=nil ci=nil cj=0 ck=0 cl=0 cm=nil cn=nil co=""cp=0 cq=0 q={} function _init() poke(0x5f2c,3) for o=1,16 do add(q,{}) for p=1,16 do add(q[o],mget(o-1,p-1)) end end cr=false cs=false ct=0 cu={} cu.cv=0 cu.cw=1 cu.cx=3 cu.cy=4 cu.cz=5 cu.da=6 cu.db=7 cu.dc=8 cu.dd=9 cu.de=10 cu.df=11 dg={} dg.dh=0 dg.di=1 dg.dj=2 dg.dk=3 dg.dl=4 dg.dm=5 m={} dn=0 dp=48 dq=1 dr=0 ds={} dt=du(1,0,0) a() bx={"   alex in\n  pico world\n\ndomarius games\n\ncode/art/music:\n clint hobson","🅾️(z) - punch\n❎(x) - items\n⬆️(up) - jump"} end function _update() if bv==nil
and#bx>0 then local dv=bx[1] dw(dv) del(bx,dv) end if bv~=nil then
if bw>0 then
bw-=1 elseif btnp(4) or btnp(5) then bv=nil end return end e() end function f() if btnp(5) then
ch=e e=dx g=dy end dz(dt) ea(ds) ea(eb) ea(ec) ea(ed) if d>0 then
ee() end for ef in all(ec) do local eg=ef.o local eh=ef.p+4 if not ef.ei then
eg+=4 else eg+=3 end if ej(eg,eh) then
ef.ek-=1 end end if el==dg.dj
and ca>63 then em() end if el==dg.dl then
if dt.o<bz then
dt.o=bz end if bz>63
and c<#en then em() end end if el==dg.dm then
local eo=flr(dt.o/64) local ep=flr(dt.p/64) if eo~=0
or ep~=0 then c+=eo c+=(ep*16) eq() dt.o-=eo*64 dt.p-=ep*64 cb=dt.o cc=dt.p if ep~=0 then
dt.o-=dt.er*2 end if ep<0 then
dt.p-=8 end end end if dt.cu==cu.da
and#es>0 then et=true en=es es={} eu(dg.dl) dt.p=0 dt.o=8 bz=0 ca=0 c=1 ev=bj ew() end end function ex() dz(dt) if dt.o>55 then
dt.o=55 end ea(ec) if dt.ey then
by=true end for l=1,#ez do local fa=ez[l] if by and fa.fb then
if fc(dt,fa) then
if k<fa.fd then
dw("you are short\nof money,\naren't you?") by=false else if not fe(fa.ff) then
fg(fa.ff) k-=fa.fd fa.fb=false dw("thank you.") end by=false end end end end return end function dx() if btnp(5) then
e=ch g=h end if btnp(1) then
dq+=1 end if btnp(0) then
dq-=1 end if dq>#m then
dq=1 end if dq<1 then
dq=#m end if btnp(4) and dr==0
and m[dq]~=0 then dr=dq sfx(27,3) sfx(26,2) end return end function dy() camera(0,0) rectfill(0,0,64,64,0) if cs then
spr(59,dn+(dq*8),dp-8-1) end for l=1,#m do spr(m[l],dn+(l*8),dp) end if btnp(4) then
local l=m[dq] end if dr>0 and cs then
rectfill(dn+(dr*8),dp,dn+(dr*8)+8,dp+8,0) end spr(bg,8,5) print("x "..j,21,8,7) spr(y,8,16) print("x "..k,21,17,7) print("score: "..i,8,26,7) return end function fh() bz=0 ca=0 camera(0,0) rectfill(0,0,64,64,fi) circfill(31,32,33,5) rectfill(0,32,64,56,5) rectfill(0,44,8,56,12) rectfill(8,22,54,40,12) map(0,7,0,56,8,1) spr(y,0,0) print(k,10,2,0) for l=1,#ez do local fa=ez[l] if fa.fb then
spr(fa.ff,fa.o,fa.p) print(fa.fd,fa.o-2,fa.p-8,0) end end spr(60,48,48) fj(dt) return end function h() if el==dg.dj then
if dt.p-32>ca then
ca=dt.p-32 end if c==#en and ca>63 then
ca=63 end end if el==dg.dl then
if dt.dc or dt.df then
bz=dt.o-8 else if dt.o-32>bz then
bz=dt.o-32 end end if c==#en and bz>63 then
bz=63 end end if el==dg.dm then
bz=0 ca=0 end if fk then
bz=0 end camera(bz,ca) rectfill(bz,ca,bz+128,ca+128,fi) for l=1,#fl do circfill(fl[l][2],56,fl[l][1],3) end for l=1,#fm do circfill(fm[l][2]+64,56,fm[l][1],3) end if et then
if ct==0 then
cf+=cg if cf==#ce then cg=-1 end
if cf==1 then cg=1 end
end pal(6,ce[cf]) map(0,0,0,0,16,16,0) pal() else map(0,0,0,0,16,16,0) end foreach(ec,fj) foreach(ed,fj) foreach(eb,fj) foreach(ds,fj) if dt.fn>0
and cr then fj(dt,1) else fj(dt) end if dt.de then
line(dt.o+3,dt.p-1,dt.o+4,dt.p-1,1) if cs then
line(dt.o,dt.p-2,dt.o+7,dt.p-2,1) else line(dt.o+3,dt.p-2,dt.o+4,dt.p-2,1) end end map(0,0,0,0,16,16,64) end function _draw() cr=not cr ct+=1 if ct>4 then
cs=not cs ct=0 end g() if bv~=nil then
local fo=bz+1 local fp=ca+8 rectfill(fo,fp,fo+60,fp+((#bv/14)+1)*8,1) print(bv,fo+2,fp+2,7) end end function fq(o,p) circfill(o-7,p,3,7) circfill(o+3,p,3,7) circfill(o-2,p+2,2,7) circfill(o-1,p-2,3,7) end function fj(fr,fs) if fs==nil then
fs=0 end if fr.fb==false then
return end if fr.ft>0 and cr then
fu(8) end if fr.spr<0 then
spr(abs(fr.spr),fr.o+fs,fr.p,fr.fv,fr.fw,fr.ei==false) else spr(fr.spr,fr.o+fs,fr.p,fr.fv,fr.fw,fr.ei) end pal() end function eu(fx) s=64 t=64 el=fx if el==dg.dl then
fy=8 fz=0 s=128 end if el==dg.dj then
fy=0 fz=8 t=128 end end function em() for p=0,7 do for o=0,7 do ga(o,p,mget(o+fy,p+fz)) end end local gb=fy*8 local gc=fz*8 bz-=gb ca-=gc dt.o-=gb dt.p-=gc cb-=gb cc-=gc gd(gb,gc,ec) gd(gb,gc,ed) gd(gb,gc,eb) gd(gb,gc,ds) c+=1 if ge then
fl={} for l in all(fm) do add(fl,l) end fm={} for l=0,2 do add(fm,{rnd(10)+5,l*21}) end end if c>#en then
return end gf(c,fy,fz) end function gd(gb,gc,gg) for fr in all(gg) do fr.o-=gb fr.p-=gc end end function gh(gi,gg) for fr in all(gg) do if fr.ff==gi then
del(gg,fr) end end end function gf(gj,gk,gl) local fx=0 if el==dg.dm then
fx=gj gm=fx else fx=en[gj] end if gn~=nil then
for o=0,7 do for p=0,7 do ga(o+gk,p+gl,gn[o][p]) end end return end local go=gp[gm] local gq=flr(fx%16) gr=flr(fx/16) gq*=8 gr*=8 for o=0,7 do for p=0,7 do local gi=mget(o+gq,p+gr) if gi==bg and gs[c]==true then
gi=0 end if el==dg.dm then
if(gi==7 or gi==4)
and go>0 then gi=0 go-=1 end end ga(o+gk,p+gl,gi) end end end function r(l,fx) n() dt.ft=0 dt.gt=true dt.o=8 dt.p=48 en={} es={} eu(dg.dl) ev=bh fi=12 gu=0 et=false ge=false gv=true ci=nil fk=false bz=0 ca=0 b=l c=fx local gw={bb,w,bg} local gx={200,100,500} gp={} for l=1,128 do add(gp,0) end gm=1 gs={} bx={"level "..l} if l==1 then
eu(dg.dj) en={0,16,32,48,64,47} es={1,2,3,4} ca=-32 dt.p=8 end if l==2 then
en={112,113,114,46,113,113,46,114,113,114,114,46,115,116} ge=true end if l==3 then
dt.p=8 et=true ev=bj en={96,97,98,99,100} end if l==4 then
en={49,50,51,52,53} end if l==5 then
en={11,12,11,12,11,12,11,12,8,7,8,9,8,63,7,9,8,63,8,7,11,9,11,47,15} es={54,55,56,57} gy(dt) ev=bl dt.p=0 end if l==6 then
gw[1]=bd en={33,34,35,36,35,37,35,38,39} end if l==7 then
fi=2 en={40,41,42,41,43,42,44,45} end if l==8 then
fi=5 en={58,59,60,59,61,60,59,61,60,59,61,62} end if l==9 then
en={47,7,8,7,8,9,8,63,7,9,8,63,8,7,9,7,8,9,47,10} es={80,81,82,83} dt.df=true dt.gz=ha dt.cu=cu.df dt.hb=nil ev=bk end if l==10 then
gw[1]=bd en={112,23,24,25,24,25,23,26} end if l==11 then
ev=bn eu(dg.dm) c=102 fi=5 gv=false dt.gt=false end if l==12 then
gw[1]=bg gx[1]=500 en={58,65,66,67,68} ge=true end if l==13 then
gy(dt) ev=bl en={17,18,19,20,18,20,19,18,21} end if l==14 then
en={84,85} dt.o=0 end if l==15 then
en={112,27,29,28,30,27,27,29,28,27,27,30,28,31} ge=true end if l==16 then
c=90 ev=bn eu(dg.dm) fi=5 gv=false end if l==17 then
bx={} e=hc g=hd he="the heroic\naction taken\nby alex kidd\nresulted in\nthe downfall\nof janken the\ngreat and a\nreturn of\npeace and\ntranquility to\n\"radaxian.\" in\na dazzling\ncoronation,\n\"igul,\" his\nelder brother,\nbecame the\nking of\n\"radaxian.\"\nthe citizens\nwho were\nturned into\nstone reverted\nback to human\nbeings through\nthe power of\nthe \"crown.\"\nalex was\noverjoyed that\nhe was able to\nuse his\nmartial art\nskills for the\ngood of the\ncitizens.\nsome doubt\nstill lingers\nin his mind as\nto whether or\nnot all of the\nsinister enemy\nforces were\nactually\ndestroyed.\nadded to this\nfear, is the\nuneasiness he\nfeels because\nof the fact\nthat the\nwhereabouts of\nhis father,\nking sander,\nis still\nunknown."hf=64 for l=3,14 do hg(l,32) end music(1) return end if l==18 then
bx={} dt.p=8 et=true ev=bj en={5,6} end if l==19 then
bx={} en={69,101,117} b=3 end fl={} fm={} ew() ez=hh(gw,gx) end function eq() ds={} ec={} ed={} eb={} cb=dt.o cc=dt.p gf(c,0,0) if el~=dg.dm then
c+=1 gf(c,fy,fz) end end function ew() eq() music(ev) end function gy(fr) fr.hb=nil fr.de=true fr.gz=hi fr.hj=0.1 fr.hk=1 fr.hl=0.5 music(bl) end function hm(gi,o,p,gg) local fr={} fr.hn=false if gg~=nil then
add(gg,fr) end fr.ho=0 fr.ff=gi fr.o=o fr.p=p fr.hp=4 fr.fv=1 fr.fw=1 fr.hq=8 fr.hr=8 fr.hs=0 fr.ht=0 fr.hu=7 fr.hv=7 fr.er=0 fr.hw=0 fr.cu=cu.cv fr.hl=1 fr.hx=1 fr.spr=gi fr.hy={} fr.ei=false hz(fr,cu.cv,{fr.ff}) hz(fr,cu.cx,{22,23}) fr.fb=true fr.ia=0.1 fr.ib=1 fr.ek=1 fr.ic=1 fr.ft=0 hz(fr,cu.cx,{22,23}) fr.fk=false fr.id=true fr.hj=0.6 fr.ey=false fr.hk=5 fr.ie=false fr.ig=false fr.gt=false if b==1 then
fr.gt=true end fr.ih=false fr.ii=false fr.ij=-1 fr.i=0 if gi==v then
fr.id=false fr.hj=0 hz(fr,cu.cv,{28,44}) fr.ik=2*30 fr.ib=0 fr.gz=function() if fr.ik>0 then
fr.ik-=1 return end fr.ib=1 if d<=0 then
il(fr,dt) end end end if gi==110
or gi==126 then fr.i=8 fr.gt=true fr.ek=3 fr.fk=true fr.hl=2 fr.gz=function() if dt.o>fr.o-30 then
im() fk=true em() bz=0 io(gi,fr) end end end if gi==20
or gi==55 or gi==68 or gi==87 or gi==103 or gi==102 or gi==76 then io(gi,fr) end if gi==41 then
fr.hj=0 fr.ig=true fr.i=6 fr.ho=z hz(fr,cu.cv,{41,-41}) fr.ek=3 fr.hl=0.5 fr.hw=fr.hl fr.ip=0 fr.gz=function() if fr.ip>0 then
fr.ip-=1 fr.spr=fr.ff if fr.ip==0 then
sfx(47,2) for l=0,3 do iq(fr) end fr.hw=-fr.hl end return end ir(fr) if fr.ii then
if fr.hw<0 then
fr.ip=1*30 fr.hw=0 end end end end if gi==42
or gi==92 then fr.id=false fr.hj=0 fr.i=4 fr.ho=z fr.er=0.25 fr.is=0 fr.it=3*30 fr.iu=0.025 fr.iv=8 fr.iw=0 fr.ix=fr.p fr.gz=function() iy(fr) iz(fr) ir(fr) end end if gi==79 then
fr.i=42 fr.ho=z fr.ek=3 fr.hj=0 fr.ja=5 fr.jb={} fr.gz=function() ir(fr) if fr.ek<=0 then
for ef in all(fr.jb) do ef.ek=0 end end if fr.ja>0 then
local ef=jc(47,fr.o-2-(fr.ja*4),fr.p+4,ds) fr.jb[fr.ja]=ef fr.ja-=1 ef.iu=0.007 ef.iv=fr.ja*3 ef.iw=0-fr.ja*0.07 ef.ix=ef.p ef.gz=function() iz(ef) ir(ef) end end end end if gi==81 then
fr.i=2 hz(fr,cu.cv,{81}) hz(fr,cu.cz,{82}) fr.ei=true fr.jd=30*1 fr.je=0 fr.hj=0.1 fr.gz=function() if fr.cu==cu.cx then
return end if fr.ey then
fr.je+=1 if fr.je>=fr.jd then
fr.hw-=2 fr.je=0 fr.cu=cu.cz fr.ey=false end end if fr.ey and fr.cu~=cu.cv then
fr.cu=cu.cv end ir(fr) end end if gi==109 then
fr.hj=0.01 end if gi==108 then
fr.i=4 hz(fr,cu.cv,{gi,-gi}) fr.jf=0 fr.jg=30*3 fr.ia=0.2 fr.gz=function() if fr.o<bz or fr.o>bz+56 then
return end jh(fr,dt,100) if fr.jf>30*2 then
fr.spr=fr.ff end ir(fr) end end if gi==66
or gi==64 or gi==65 or gi==bf then ci=fr fr.hj=0 fr.i=20 fr.fk=true fr.ek=3 fr.gz=function() if dt.o>fr.o-20
and e==f then fk=true im() gh(v,ds) e=ji dt.cu=cu.cw dt.ei=true dt.gz=nil dt.hw=0 dt.ft=0 if gv then
em() bz=0 end end end if gi==bf then
fr.i=100 fr.fw=2 end end if gi==14 then
jj(fr,{"oh, alex, i'm \nterribly sorry \nbut i was just \nrobbed of the \nmoonlight \nstone.","the \"crown\" is \nwith your \nprincess and \njanken the \ngreat has \ntaken her.",}) end if gi==84 then
jj(fr,{"thank you,\nalex. janken\nhad trapped me\nin here.","your mother is\nsafe as well,\nshe is in good\nhands.","sadly, i do\nnot know where\nyour father\nis."}) end if gi==29 then
if(b==6) then
jj(fr,{"prince alex of \n\"radaxian,\" \nyou are \nlooking very \nwell indeed! \nwe hear that \nyour elder \nbrother is ","imprisoned in \nthe \"radaxian\" \ncastle and you \nare the only \nperson who can \ncome to his \nrescue.",}) else jj(fr,{"welcome, alex. \nyou are a \nprince from \nthe country of \nradaxian, who \nwas kidnapped \nby evil men \nwhen you were ","but a small \nboy. your \nnative land is \nnow being \ngrossly \nmisgoverned by \nthe tyrant, ","\"janken the \ngreat.\" your \nmission is to \nsave the \npopulace from \nhim."}) end end if gi==60 then
jj(fr,{"thank you, \nalex. the \nmoon-light \nstone is in \nthe nibana \nkingdom,","so you must \nreach there \nbefore janken \nthe great \ndoes.",}) end return fr end function io(gi,fr) fr.i=2 fr.ie=true if gi==103
or gi==102 then hz(fr,cu.cv,{gi,-gi}) else if gi~=76 then
hz(fr,cu.cv,{gi,gi+1}) else fr.hj=0.25 end end if gi==20
or gi==55 or gi==87 then fr.hj=0 end fr.er=-0.5 if gi==55 then
fr.ho=z end fr.gz=function() if gi~=102 then
ir(fr) end if gi==68
or gi==102 or gi==110 or gi==126 then local jk=jl(fr.o+fr.er+4,fr.p+8) if not fget(jk.gi,bo) then
fr.er*=-1 end end if gi==76
and fr.ey then fr.hw=-1.5 end end end function jj(fr,dw) fr.jm=false fr.ib=0 fr.jn=dw fr.gz=function() if(dt.o>fr.o-20
and dt.o<fr.o+8 and fr.jm==false) then fr.jm=true bx=fr.jn end end end function ea(gg) for l=#gg,1,-1 do local fr=gg[l] dz(fr) if fr==nil or fr.hn then
del(gg,fr) end end end function dz(fr) if fr.cj~=nil then
fr.cj-=1 end if fr.ek<=0
or(fr.cj~=nil and fr.cj<=0) then fr.hn=true i+=fr.i local jo=fr.hy[cu.cx] if jo[1]~=0 then
local jp=jc(22,fr.o,fr.p,eb) hz(jp,cu.cv,jo) jp.cj=30*(#jo*0.5) jp.ia=0.065 end if fr.fk and fr.ff~=bf then
ga(6,4,ba) if b==6 then
ga(6,6,29) end end end local hy=fr.hy[fr.cu] fr.hx+=fr.ia if flr(fr.hx)>#hy then
fr.hx=1 if fr.cu==cu.cy then
fr.cu=cu.cv end end fr.spr=fr.hy[fr.cu][flr(fr.hx)] if not fr.fb then
return end if fr.gz~=nil then
fr.gz(fr) end if fr.cu~=cu.db then
fr.hw+=fr.hj end if fr.id then
id(fr) end fr.o+=fr.er fr.p+=fr.hw if jq(fr)==false then
fr.hn=true end if fr.ft>0 then
fr.ft-=1 end if fr.er!=0 and fr~=dt then
fr.ei=fr.er<0 end end function id(fr) fr.ih,fr.ii=false fr.ij=-1 local jr=fr.o+fr.er if jr<0
or jr+7>s or(fk and jr>56) then fr.ih=true end if fr==dt
and el==dg.dm then fr.ih=false end if js(fr) then
local er=fr.er fr.er=0 if js(fr) then
fr.ii=true end fr.er=er local hw=fr.hw fr.hw=0 if js(fr) then
fr.ih=true end fr.hw=hw if not fr.ih
and not fr.ii then fr.ii=true end end if(not fr.ey or btn(3))
and fr.ij~=-1 and fr==dt then fr.o=fr.ij fr.ey=false fr.er=0 return end if fr.ih then
if fr.ie then
fr.er*=-1 else fr.er=0 end end if fr.ii then
if fr.ig then
fr.hw*=-1 else local jt=sgn(fr.hw) fr.hw=0 while(not js(fr)) do fr.p+=jt end fr.p-=jt fr.ey=jt>0 end else fr.ey=false end end function iq(fr) local ef=jc(57,fr.o,fr.p,ed,rnd(2)-1,(rnd(1)*-1)-0.5) end function hz(ju,cu,jv) ju.hy[cu]=jv end function du(gi,o,p) local fr=hm(gi,o,p) fr.gz=jw fr.ek=6 fr.jx=0 fr.jy=false fr.jz=nil fr.ka=nil fr.kb=false hz(fr,cu.cv,{1}) hz(fr,cu.cw,{2,18}) hz(fr,cu.cy,{3,3,1,1}) hz(fr,cu.cz,{19}) hz(fr,cu.da,{12,13}) hz(fr,cu.db,{83,-83}) hz(fr,cu.dc,{bb}) hz(fr,cu.dd,{15}) hz(fr,cu.df,{bc}) fr.fn=0 fr.kc=false fr.hb=nil return fr end function n() dt.dc=false dt.de=false dt.df=false dt.kd=false dt.fb=true dt.cu=cu.cv dt.hj=0.6 dt.hk=5 dt.hl=1 dt.gz=jw dt.ft=2*30 dt.er=0 dt.hw=0 music(ev) end function jw(fr) if fr.fn>0 then
fr.fn-=1 if fr.cu==cu.da then
fr.hw=0 fr.er=0 end return end if m[dr]==w then
fr.kd=true m[dr]=0 dr=0 end local gi=ke(fr) if gi==ba then return end
if(fr.cu~=cu.db
and fr.ij~=-1) then fr.cu=cu.db fr.er=0 fr.hw=0 fr.hj=0.6 gu=0 end local jk=jl(fr.o+3,fr.p+8) local kf=jk.gi if fr.cu==cu.db then
if btn(2) then
fr.kb=true fr.p-=1 end if btn(3) then
fr.p+=1 end if fr.ij==-1 then
fr.cu=cu.cv fr.ey=true fr.p=flr(fr.p/8) fr.p*=8 end else kg(fr) if fr.cu==cu.da then
kh(fr) if btn(3)
and kf==95 then r(18,1) return end if fr.p<0 then
r(19,1) return end else if fr.jx<=0 then
ki(fr) end if btn(3)
and fr.ey and fget(kf,bt) then fr.p+=8 fr.o=jk.kj*8 end end end if(fr.cu~=cu.da and
fget(gi,bs)) then fr.cu=cu.da fr.hj=-0.2 sfx(24,3) sfx(25,2) gu=z end if(fr.cu==cu.da and
gi==39) then fr.hw+=1 end if fr.ey then
if el~=dg.dm then
cb=fr.o cc=fr.p end if kf~=cd then
if kf==27 then
hm(v,jk.kj*8,jk.kk*8,ds) end end cd=kf end if btnp(2) and e~=ex
and(gi==61 or gi==62) then e=ex g=fh sfx(-1,3) fr.hw=0 fr.o=8 dw("welcome.\nplease buy the\nthings that\nyou like.") end if(e==ex
and btnp(2) and dt.o<8) then e=f g=h fr.hw=0 sfx(-1,3) if fe(bb) then
fr.dc=true kl(bb) fr.cu=cu.dc fr.ei=false fr.gz=ha music(bk) end if fe(bd) then
gy(dt) kl(bd) end end for ef in all(ed) do if(fc(fr,ef)
and fr.ft==0) then km(fr) break end end local kn=ko(fr) if(kn~=nil
and fr.ft==0) then km(fr) end end function ee() d-=1 if d<=0 then
j-=1 if j<=0 then
kp() return end n() gh(v,ds) if dt.cu~=cu.da
or el~=dg.dm then dt.o=cb dt.p=cc end if b==13 then
gy(dt) end end end function km(fr) d=3*30 fr.er=0 fr.hw=0 fr.fb=false local kq=jc(9,fr.o,fr.p,ed,0,-0.5) hz(kq,cu.cv,{9,10}) kq.cj=30*2.75 if fr.jz~=nil then fr.jz.fb=false end
music(bi) end function ke(fr) local jk=jl(fr.o+4,fr.p+4) local gi=jk.gi local kj=jk.kj local kk=jk.kk if gi==y then
ga(kj,kk,gu) k+=20 sfx(17,3) gp[gm]+=1 end if gi==w then
fg(w) kr(kj,kk) end if gi==bg then
j+=1 kr(kj,kk) gs[c]=true end if gi==ba then
b+=1 r(b,1) end if fget(gi,bq)
and fr.ft==0 then if(fr.dc or fr.de or fr.df) then
im() else km(fr) end end return gi end function kr(o,p) ga(o,p,gu) sfx(27,3) sfx(26,2) end function ha(fr) if btn(0)==false and btn(1)==false then
fr.er=1 end if btn(0) then fr.er=0.5 end
if btn(1) then fr.er=2 end
local jk=jl(fr.o+fr.er+8,fr.p+5) local gi=jk.gi if fget(gi,bp) then
ks(jk.kj,jk.kk) end if(fget(gi,bp)==false
and fget(gi,bo)) then im() end if gi==39 and fr.df then
fr.hw=-1 fr.ey=true end if btn(2) and fr.ey
and fr.kb==false then fr.kb=true sfx(0,3) fr.hw=-fr.hk end if btn(2)==false and fr.ey then
fr.kb=false end if fr.ey==false
and fr.kc and fr.kb==false then fr.hw=-2 fr.kc=false end if fr.dc then
if fr.ey==false then
fr.cu=cu.dd end if fr.ey then
fr.cu=cu.dc fr.kc=true end end ke(fr) local kn=ko(fr) if kn~=nil then
if fr.df then
im() else ib(kn) end end if fr.df then
kt(fr) end end function hi(fr) local jk=jl(fr.o+4,fr.p+fr.hw) local gi=jk.gi if fget(gi,bo) then
im() end if fr.p>0 then
fr.ey=true end ki(fr) fr.spr=bd kt(fr) local gi=ke(fr) if gi==39 then
im() end if ko(fr)~=nil then
im() end end function ko(fr) for kn in all(ds) do if(kn.ib>0
and fc(fr,kn)) then return kn end end return nil end function kt(fr) local ef=fr.hb if btnp(4) and ef==nil then
sfx(15,3) local er=4 if dt.ei then
er=-4 end ef=jc(47,fr.o,fr.p,ec,er,0) hz(ef,cu.cx,{80}) ef.cj=10 ef.ek=1 fr.hb=ef end if ef~=nil
and ef.hn then fr.hb=nil end end function im() if
dt.dc==false and dt.df==false and dt.de==false then return end n() dt.hw=-4 ku(dt.o,dt.p) dt.ey=false dt.kb=true cb=dt.o cc=dt.p end function ku(o,p) local jp=jc(80,o,p,eb) jp.cj=30*0.5 jp.hj=0 end function fg(gi) if gi==bg then
j+=1 return end for l=1,#m do if m[l]==0 then
m[l]=gi return end end end function fe(gi) for l=1,#m do if m[l]==gi then
return true end end return false end function kl(gi) for l=1,#m do if m[l]==gi then
m[l]=0 end end return end function hh(kv,kw) local kx={} for l=1,#kv do local ky=hm(kv[l],-4+(l*16),32,ds) ky.fd=kw[l] add(kx,ky) del(ds,ky) end return kx end function fu(kz) for l=0,15 do pal(l,kz) end end function ki(fr) fr.cu=cu.cv if btn(0) then
fr.er-=fr.hl fr.cu=cu.cw fr.ei=true end if btn(1) then
fr.er+=fr.hl fr.cu=cu.cw fr.ei=false end if btn(2) and fr.ey and fr.kb==false then
fr.kb=true if fr.de==false then
sfx(0,3) end fr.hw=-fr.hk fr.ey=false end if btn(2)==false and fr.ey then
fr.kb=false end if fr.ey==false then
fr.cu=cu.cz end fr.er/=1.5 if abs(fr.er<0.25)
and not btn(0) and not btn(1) then fr.er=0 end end function kh(fr) cb=fr.o cc=fr.p if fr.hw>4 then fr.hw=4 end
if btn(0) and fr.er>-fr.hp then
fr.er-=fr.hl fr.ei=true end if btn(1) and fr.er<fr.hp then
fr.er+=fr.hl fr.ei=false end if btn(2) and fr.hw>-fr.hp then
fr.hw-=fr.hl end if btn(3) and fr.hw<fr.hp then
fr.hw+=fr.hl end fr.er/=2 fr.hw/=2 end function js(fr) local la=fr.o+fr.er local lb=fr.p+fr.hw local lc=la+7 local ld=lb+7 la/=8 lb/=8 lc/=8 ld/=8 return le(la,lb,fr) or le(la,ld) or le(lc,ld) or le(lc,lb,fr) or(el==dg.dl and fr.p+fr.hw>=56) end function le(lf,lg,fr) if fget(lh(lf,lg),bt)
and fr~=nil then fr.ij=flr(lf)*8 end return fget(lh(lf,lg),bo) end function fc(li,lj) if
li.o+li.hu<lj.o+lj.hs or lj.o+lj.hu<li.o+li.hs or li.p+li.hv<lj.p+lj.ht or lj.p+lj.hv<li.p+li.ht then return false else return true end end function ib(fr) if fr.ft>0 then
return end fr.ek-=1 fr.ft=fr.ic*30 sfx(21,3) if fr.ff==110
or fr.ff==126 then fr.er*=(4-fr.ek)*0.75 end end function iy(fr) fr.is+=1 if fr.is>fr.it then
fr.er*=-1 fr.hw*=-1 fr.is=0 end end function iz(fr) fr.p=fr.iv*sin(fr.iw) fr.p+=fr.ix fr.iw+=fr.iu end function jh(fr,gi,lk) fr.jf+=1 if fr.jf>=fr.jg then
fr.jf=0 local ef=jc(lk,fr.o,fr.p,ed) il(ef,gi) end end function jc(gi,o,p,gg,er,hw,ll) local fr=hm(gi,o,p,gg) hz(fr,cu.cx,{0}) fr.id=false if er~=nil then
fr.er=er fr.hw=hw end fr.hq=4 fr.hr=4 fr.hj=0 if ll~=nil then fr.hj=ll end
fr.hs=2 fr.ht=2 fr.hu=5 fr.hv=5 return fr end function jq(fr) if fr.o<0
or fr.o+7>s or(fr.p<ca+-7 and el==dg.dj) or fr.p+7>t then return false end return true end function kg(fr) if btn(4)
and fr.jx==0 and fr.jy==false then fr.jx=10 fr.jy=true sfx(1,3) fr.hx=1 if fr.cu~=cu.da then
fr.cu=cu.cy end local ef=jc(x,fr.o,fr.p,ec) fr.jz=ef ef.cj=30*0.15 ef.ek=1000 ef.hl=0 ef.ei=fr.ei if fr.kd then
sfx(28,2) local lm=jc(43,fr.o,fr.p,ec) fr.ka=lm lm.ib=10 lm.ln=1000 lm.ek=1000 lm.ei=fr.ei if fr.ei==false then
lm.er=4 else lm.er=-4 end end end if not btn(4) then
fr.jy=false end if fr.jx>0 then
fr.jx-=1 if fr.ey then
fr.er/=1.5 end end if fr.jz~=nil then
local ef=fr.jz ef.o=fr.o+fr.er ef.p=fr.p+fr.hw if fr.ei then
ef.o-=7 else ef.o+=7 end end end function jl(lo,lp) local lq={} lq.kj=flr(lo/8) lq.kk=flr(lp/8) lq.gi=mget(lq.kj,lq.kk) return lq end function ej(o,p) if o>bz+64 then
return end local jk=jl(o,p) local gi=jk.gi if fget(gi,bp) then
ks(jk.kj,jk.kk) return true end return false end function ks(kj,kk) local gi=mget(kj,kk) ga(kj,kk,gu) local lo=(kj*8) lp=(kk*8) jc(8,lo,lp,eb,-1,-5,0.5) jc(8,lo+4,lp,eb,1,-5,0.5) jc(8,lo,lp+4,eb,-1,-3,0.5) jc(8,lo+4,lp+4,eb,1,-3,0.5) sfx(16,3) if gi==4 then
ga(kj,kk,y) end if gi==6 then
if(dt.kd or
fe(w)) then local ll=hm(v,kj*8,kk*8,ds) else ga(kj,kk,w) end end if gi==16
and not dt.de then dt.fn=2*30 dt.er=0 end end function dw(dv) bw=30 bv=dv end function ga(o,p,gi) if fget(gi,bu) then
local fr=hm(gi,o*8,p*8,ds) gi=fr.ho end local lr=8 local lt=8 if el==dg.dl then
lr=16 end if el==dg.dj then
lt=16 end if o>=0 and o<lr and p>=0 and p<lt then
mset(o,p,gi) end end function lh(o,p) o=flr(o) p=flr(p) if(el==dg.dm
and(o<0 or o>7 or p<0 or p>7)) then return 0 end return mget(o,p) end function ir(fr) if fr.cu==cu.cx then
return end for ef in all(ec) do if fc(fr,ef) then
ef.ek-=1 ib(fr) end end end function il(fr,gi) local lf=gi.o-fr.o local lg=gi.p-fr.p local lu=sqrt(lf*lf+lg*lg) fr.er=(lf/lu)*fr.hl fr.hw=(lg/lu)*fr.hl end function hg(sfx,hl) poke(0x3200+68*sfx+65,hl) end function ji() if dt.o>8 then
dt.er=-1 dz(dt) ea(eb) end if dt.o<=10 then
lv() end end function lv() eb={} ec={} ed={} dt.ft=0 cq=0 cp=0 co=""dt.o=8 dt.p=48 dt.ei=false cm=hm(x,15,47,eb) cn=hm(x,42,48,eb) cm.spr=x cn.spr=x cm.fb=false cn.fb=false cn.ei=true dt.spr=1 bx={"i'm\n\"stone head\",\nthe third\nhenchman of\nthe king.","i'll let you\npass by here\nif you win 3\n\"janken\"\nmatches.","you must\nchoose either\nthe \"paper\",\n\"scissors\" or\n\"stone\" before\nthe music\nstops.",} if ci.ff==64 then
bx[1]="i'm \"scissor\nhead\", the\nsecond\nhenchman of\nthe king."end if ci.ff==65 then
bx[1]="i'm \"paper\nhead\", the\nfirst\nhenchman of\nthe king."end if ci.ff==bf then
bx[1]="it's lucky\nyou've come\nthis far,\nhowever, i'll\nput and end\nto that."
bx[2]="let's \"janken\"\nfor 3 matches,\nand if you\nlose, i'll\nturn you into\nstone."
cn.o-=2 cn.p-=2 end e=lw g=lx music(-1) end function lx() h() fq(16,16) fq(48,16) spr(x+ck,12,12) spr(x+cl,42,12,1,1,true) print(co,8,24,0) end function lw() if#bx==0 and bv==nil then
e=ly cj=0 music(bm) end end function ly() cj+=1 if(cj%60==0
and cj<8*30) then local lz=cl while(cl==lz) do cl=flr(rnd(3)) end end if btnp(2) then
ck+=1 if ck>2 then
ck=0 end end if btnp(3) then
ck-=1 if ck<0 then
ck=2 end end if cj%25==0 then
dt.ei=not dt.ei ci.ei=not ci.ei end if cj>10*30 then
cj=0 dt.ei=false dt.spr=3 ci.ei=false e=ma end end function ma() cj+=1 local mb=cj%30 if mb==0 or mb==15 then
cm.fb=not cm.fb cn.fb=not cn.fb end if mb==15 then
sfx(1,3) if cj>=2*30 then
cm.spr=x+ck cn.spr=x+cl e=mc end end end function mc() local md=false if((ck==0
and cl==2) or(ck==1 and cl==0) or(ck==2 and cl==1)) then md=true end if ck==cl then
dw("it's a draw.\nyou sure\nlucked out.") else if md then
dw("darn it. i\nlose.") cp+=1 co=co.."o"else dw("i win. you got\nit.") cq+=1 co=co.."x"end end if cq>=2 then
e=me cj=0 return end if cp>=2 then
e=mf return end e=mg cj=0 end function mg() if#bx==0 and bv==nil then
cm.fb=false cn.fb=false cm.spr=x cn.spr=x dt.spr=1 e=ly cj=0 music(bm) end end function me() if cj==0 then
dw("you'd better\naccept the\ninevitable!") cm.fb=false cn.fb=false end if cj==1 then
km(dt) end cj+=1 f() if cj>=4*30 then
e=ji dt.ft=2*30 dt.fb=true end end function mf() e=f eb={} dt.cu=cu.cv dt.gz=jw g=h local mh="well it looks\nlike that's\nthe way it's\nmeant to be.\nok. take this!"if b==11
or b==12 or b==15 then if b==11 then
ga(1,7,77) end ev=bn music(bn) dw(mh) ci.er=0.5 ci.hw=0.5 ci.ie=true ci.ig=true ci.hj=0 ci.iu=0.025 ci.iv=8 ci.iw=0 ci.ix=40 ci.gz=function() ir(ci) if b==15 then
iz(ci) end end return end if ci.ff==bf then
dw(mh) e=mi ci.gz=ir mset(0,5,97) mset(0,6,97) music(bn) cb=10 dt.o=10 return end ci.ek=0 end function mi() f() cj+=1 if cj>30*3 then
cj=0 local ef=jc(100,ci.o-2,ci.p,ed,-0.5,0) ef.iu=0.025 ef.iv=8 ef.iw=0 ef.ix=40 ef.gz=function() iz(ef) end end if ci.ek<=0 then
e=f for l=1,5 do mset(1,l,113) end end end function kp() e=mj g=mk camera(0,0) rectfill(0,0,64,64,0) print("game over",14,16,7) print("score: "..i,8,32,7) music(39) bw=90 end function mk() end function hc() hf-=0.25 if hf<-330 then
kp() bw=300 end end function hd() camera(0,0) rectfill(0,0,64,64,0) print(he,2,hf,7) end function mj() if bw>0 then
bw-=1 elseif btnp(4) or btnp(5) then a() end end