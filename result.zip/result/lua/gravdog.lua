-- made for ccawjam by dogs++
-- ccaw!
function _init()
 cartdata("dogsplusplus_ccaw")
 _debug_buf = {}
 world = {}
 world.state = "title"
 _init_title()
end

function _begin()
 _kill = 0
 pal()

 world.planet_vault = {}
 world.planets = {}
 world.stars = {}
 world.spikes = {}
 world.player = nil
 world.hand = nil
 world.goal = nil
 world.winship = nil
 world.particles = {}
 world.powerups = {}
 world.jetpacks = 3
 world.lives = 3
 world.arrow = nil
 world.state = "game"
 world.freezeend = -1
 world.score = 0
 
 menuitem(1, "restart level", _menu_reset)
 menuitem(2, "new level", _menu_new_level)
 -- menuitem(3, "win", _win)
 -- menuitem(4, "lose", _lose)

 _new_level() 
end

function _debug(s)
 add(_debug_buf, s)
end

function _win()
 world.score += 100
 world.state = "win"
 music(26)
end

function _lose()
 world.lives -= 1
 world.state = "lose"
end

function _menu_new_level()
 if (world.lives > 1) then
  world.lives -= 1
  _new_level()
 end
end

function _new_level()
 _gen_planets()
 _init_powerups()
 _reset()
 local mus = flr(rnd(3))
 if mus == 0 then
  music(10)
 elseif mus == 1 then
  music(16)
 else
  music(22)
 end
end

function _hitfreeze(seconds)
 if (time() - world.freezeend < 0.75) return
 world.freezeend = time() + seconds
 world.laststate = world.state
 world.state = "freeze"
end

function _menu_reset()
 if (world.lives > 0) then
  _reset()
 end
end

function _reset()
 _init_planets()
 _init_bgstars()
 _init_hand()
 _init_spikes()
 _init_goal()
 _init_winship()
 _init_particles()
 _init_player()
 _init_arrow()
 world.state = "game"
 if world.lives <= 0 then
  world.state = "lose"
 end
end
-->8
-- math/particles
-- 1

function _v(x, y)
 return {x=x, y=y}
end

function v_p2v(x1,y1,x2,y2)
 local v = {}
 v.x = x2-x1
 v.y = y2-y1
 return v
end

function v_mag(v)
 -- hacks to avoid overflows
 local nx = v.x * 0x0.01
 local ny = v.y * 0x0.01
 return sqrt(nx * nx + ny * ny) * 0x100
end

function v_norm(v)
 return {x=v.x/v_mag(v), y=v.y/v_mag(v)}
end

function v_add(v, u)
 return {x=v.x+u.x, y=v.y+u.y}
end

function v_mult(v, s)
 return {x=v.x*s, y=v.y*s}
end

function v_dot(v, u)
 return v.x*u.x + v.y*u.y
end

function _init_particles()
 world.particles = {}
end

function _update_particles()
 for p in all(world.particles) do
  if p.life <= 0 then
   del(world.particles, p) 
  else
   p.x += p.vx
   p.y += p.vy
   p.vx *= p.f
   p.vy *= p.f
   p.life -= 1
  end
 end
end

function _draw_particles()
 for p in all(world.particles) do
  if p.h == true then
   circ(p.x, p.y, p.r, p.c)
  else
   circfill(p.x, p.y, p.r, p.c)
  end
 end
end

function make_particle(x, y, vx, vy, r, c, life, friction, hollow)
 local p = {}
 p.x = x
 p.y = y
 p.vx = vx
 p.vy = vy
 p.r = r
 p.c = c
 p.life = life
 p.f = friction
 p.h = hollow or false
 add(world.particles, p)
 return p
end

function make_r_particle(x, y, mag, r, c, life, friction, hollow)
 local h = hollow or false
 local angle = rnd(360)
 local p = make_particle(x, y, 0, 0, r, c, life, friction, h)
 p.vx = mag * cos(angle/360)
 p.vy = mag * sin(angle/360)
 return p
end

function _draw_jetpacks()
 for i=0,world.jetpacks-1 do
  spr(52, 2 + 11 * i, 2)
 end
end

function _draw_lives()
 for i=0,world.lives-1 do
  spr(36,118-11*i, 2)
 end
end

function make_powerup(x, y, type)
 local pu = {}
 pu.x = x
 pu.y = y
 pu.type = type
 pu.col = make_planet(pu.x, pu.y, 1)
 return pu 
end

function _init_powerups()
 world.powerups = {}
 local dice = rnd(100)
 if dice < 10 then
  local pu = make_powerup(0, 0, "life")
  repeat
   pu.col.x = 20 + rnd(88)
   pu.col.y = 20 + rnd(88)
  until no_planet_collisions_boost(pu.col, world.planet_vault, 16)
  pu.x = pu.col.x
  pu.y = pu.col.y
  add(world.powerups, pu)
 end

 if dice < 30 then
  local pu = make_powerup(0, 0, "jetpack")
  repeat
   pu.col.x = 20 + rnd(88)
   pu.col.y = 20 + rnd(88)
  until no_planet_collisions_boost(pu.col, world.planet_vault, 16)
  pu.x = pu.col.x
  pu.y = pu.col.y
  add(world.powerups, pu)
 end
end

function _update_powerups(pul)
 for pu in all(pul) do
  if rnd(100) < 2 then
   make_r_particle(pu.x, pu.y, 0.5+rnd(0.5), 0.90+rnd(0.5), 10, 18+rnd(8), 0.99)
  end

  if (c_cvc(world.player.col, pu.col)) then
   make_r_particle(pu.x, pu.y, 0.1, 6, 10, 18+rnd(8), 0.99, true)
   for i=1,3 do
    make_r_particle(pu.x, pu.y, 0.5+rnd(0.5), 0.90+rnd(0.5), 10, 18+rnd(8), 0.99)
   end

   if (pu.type == "jetpack") then 
    world.jetpacks += 1
    world.score += 2
   end
   if (pu.type == "life") then
    world.lives += 1
    world.score += 3
   end
   del(world.powerups, pu)
   sfx(3)
   _hitfreeze(0.4)
  end

  for pl in all (world.planets) do
   if (c_cvc(pu.col, pl)) then
    make_r_particle(pu.x, pu.y, 0.1, 6, 6, 18+rnd(8), 0.99, true)
    for i=1,3 do
     make_r_particle(pu.x, pu.y, 0.5+rnd(0.5), 0.90+rnd(0.5), 6, 18+rnd(8), 0.99)
    end
    sfx(4)
    del(world.powerups, pu)
   end
  end

 end
end

function _draw_powerups(pul)
 for pu in all(pul) do
  if pu.type == "life" then
   spr(54, pu.x-2, pu.y-2 + sin(time()/1.5))
  elseif pu.type == "jetpack" then
   spr(53, pu.x-2, pu.y-2 + sin(time()/1.5))
  end
 end
end

function _draw_score()
 local paddingn = 6-#tostr(world.score)
 local padding = ""
 for i=1,paddingn do padding = padding.."0" end
 print(padding..world.score.."00", 6*8, 0, 7)
end

function _init_arrow()
 local a = {}
 a.x = 16
 a.y = 16
 a.s = 8
 world.arrow = a
end

function _draw_arrow(a)
 local fx = false
 local fy = false

 if (
  world.player.x >= 0 and world.player.x < 128 and
  world.player.y >= 0 and world.player.y < 128
  ) then return end

 a.x = mid(0, world.player.x, 128-8)
 a.y = mid(0, world.player.y, 128-8)

 if world.player.x >= 0 and world.player.x < 128 then
  a.s = 8
  if world.player.y > 0 then
   fy = true
  end
 elseif world.player.y >= 0 and world.player.y < 128 then
  a.s = 24
  if world.player.x > 0 then
   fx = true
  end
 elseif world.player.x > 0 then
  a.s = 40
  if world.player.y > 0 then
   fy = true
  end
 else -- x < 0
  a.s = 40
  fx = true
  if world.player.y > 0 then
   fy = true
  end
 end

 spr(a.s+12*time()%2, a.x, a.y, 1, 1, fx, fy)
end

-->8
-- collision
-- 2

function c_cvc(c1, c2)
 -- if two circles have the exact same coords, they're _probably_ the same :)
 if (c1.x == c2.x and c1.y == c2.y) return false
 local v = v_p2v(c1.x,c1.y,c2.x,c2.y)
 return v_mag(v) < c1.r + c2.r
end

function c_colvel(s, d, v)
 local vs = _v(s.x,s.y)
 local vd = _v(d.x,d.y)
 local point = v_mult(v_add(v_mult(vs, s.r), v_mult(vd, d.r)), 1/(s.r+d.r))
 local dir = v_norm(v_p2v(s.x, s.y, point.x, point.y))
 return v_add(v, v_mult(dir, -2*v_dot(v, dir)))
 -- v - 2(v*dir)dir
end

-->8
-- planet/bgstar functions
-- 3

function _gen_planets()
 world.planet_vault = {}
 place_planet(make_planet(0, 0, 28 - 4 + rnd(8)), world.planet_vault)
 place_planet(make_planet(0, 0, 18 - 3 + rnd(6)), world.planet_vault)
 if rnd(100) < 45 then
  place_planet(make_planet(0, 0, 12 - 2  + rnd(4)), world.planet_vault)
 end
 place_planet(make_planet(0, 0, 8 - 2  + rnd(4), true), world.planet_vault)
end

function _init_planets()
 world.planets = {}
 for pl in all(world.planet_vault) do
  local pcp = make_planet(pl.x, pl.y, pl.r, pl.death)
  pcp.c = pl.c
  pcp.c2 = pl.c2
  pcp.fill = pl.fill
  add(world.planets, pcp)
 end
end

function _draw_planets()
 for p in all(world.planets) do
  local lx = p.x
  local ly = p.y

  if (p.death == true) then 
   lx += -1 + rnd(2)
   ly += -1 + rnd(2)
   fillp()
   circfill(lx,ly,p.r,0)
   circ(lx, ly, p.r*1.5, 6)
   fillp(0b0101101001011010)
   circ(lx, ly, -time()*14 % p.r*2, 7)
   fillp()
  else
   fillp()
   circfill(lx,ly,p.r,p.c)
   fillp(p.fill)
   circfill(lx,ly,p.r,p.c2)
  end
 end
end

function make_planet(x, y, r, d)
 local c = 1 + rnd(15)
 local c2 = 1+rnd(15)
 local fill = flr(rnd(32768)) + 0b0.1
 local d = d or false
 local p = {}
 p.x = x
 p.y = y
 p.r = r
 p.c = c
 p.c2 = c2
 p.fill = fill
 p.death = d
 return p
end

function get_planet_force_upon(p, o)
 local g = sqrt(p.r)*0.6 * 0.18
 local dir = v_norm(v_p2v(o.x,o.y,p.x,p.y))
 local mag = g*o.m/((v_mag(v_p2v(o.x,o.y,p.x,p.y))-p.r)*0.8)
 return v_mult(dir, mag)
end

function place_planet(p, list)
 if (p.death == true) return place_planet_death(p, list)
 repeat
  p.x = rnd(128)
  p.y = rnd(128)
 until no_planet_collisions_boost(p, list, 8)
 add(list, p)
end

function place_planet_death(p, list)
 repeat
  p.x = 20 + rnd(88)
  p.y = 20 + rnd(88)
 until no_planet_collisions_boost(p, list, 16)
 add(list, p)
end

function no_planet_collisions(c, list)
 local flag = true
  for pl in all(list) do
   if c_cvc(c, pl) then
    flag = false
    break
   end
  end
 return flag
end

function no_planet_collisions_boost(c, list, boost)
 local flag = true
  for pl in all(list) do
   if c_cvc(c, make_planet(pl.x, pl.y, pl.r+boost)) then
    flag = false
    break
   end
  end
 return flag
end

function place_on_planet(pl, o)
 local angle = rnd(360)
 o.x = pl.x + cos(angle/360) * ( o.col.r + pl.r + 1)
 o.y = pl.y + sin(angle/360) * ( o.col.r + pl.r + 1)
 return o
end

function get_closest_planet(v)
 local mind = 32000
 local ret = nil
 for pl in all(world.planets) do
  if v_mag(v_p2v(v.x, v.y, pl.x, pl.y)) < mind then
   mind = v_mag(v_p2v(v.x, v.y, pl.x, pl.y))
   ret = pl
  end
 end
 return ret
end

function _init_bgstars()
 world.stars = {}
 for i=1,12 do
  add(world.stars, {x=rnd(128), y=rnd(128)})
 end
end

function _draw_bgstars(stars)
 for s in all(stars) do
  color(7)
  pset(s.x, s.y)
 end
end

-->8
-- player functions
-- 4

function _init_player()
 world.player = make_player()
 -- place on first planet
 local p1 = world.planets[1]
 local angle = rnd(360)
 world.player.x = p1.x + cos(angle/360) *( world.player.col.r + p1.r + 1)
 world.player.y = p1.y + sin(angle/360) *( world.player.col.r + p1.r + 1)
end

function get_player_input(p)
 p.inp.dx = 0
 p.inp.dy = 0

 if (btn(⬅️)) p.inp.dx -= 1
 if (btn(➡️)) p.inp.dx += 1
 if (btn(⬆️)) p.inp.dy -= 1
 if (btn(⬇️)) p.inp.dy += 1

 if (btn(❎)) then 
  p.inp.bx = 1 
  if p.inp.bx_lastf == 0 then 
   p.inp.bxp = 1
  else
   p.inp.bxp = 0
  end
  p.inp.bx_lastf = 1
 else 
  p.inp.bx = 0
  p.inp.bxp = 0
  p.inp.bx_lastf = 0
 end

 if (btn(🅾️)) then 
  p.inp.bo = 1 
  if p.inp.bo_lastf == 0 then 
   p.inp.bop = 1
  else
   p.inp.bop = 0
  end
  p.inp.bo_lastf = 1
 else 
  p.inp.bo = 0
  p.inp.bop = 0
  p.inp.bo_lastf = 0
 end
 
 if (p.inp.dx * p.inp.dy != 0) then
  p.inp.dx *= 0.707
  p.inp.dy *= 0.707
 end
end

function _update_player(p)
 -- hack to stop updating invisible player after loss
 if world.state == "lose" and p.s == 0 then return end
 local f = _v(0,0)

 for pl in all(world.planets) do
  f = v_add(f, get_planet_force_upon(pl, p))
 end

 local friction = 0.7
 local jump = 2

 p.vx += f.x
 p.vy += f.y
 local oldx = p.x
 local oldy = p.y 
 p.x += p.vx
 p.y += p.vy
 p.col.x = p.x
 p.col.y = p.y

 -- collisions - spikes
 for os in all(world.spikes) do
  if (c_cvc(p.col, os.col)) then
   local angle = rnd(360)
   local mag = 1.5
   p.vx = cos(angle/360) * mag
   p.vy = sin(angle/360) * mag
   for i=1,2 do
    make_r_particle(os.x, os.y, 1, 0.5, 7, 12+rnd(4), 0.95)
   end
   sfx(2)
  end
 end

 -- collisions - planets
 for pl in all(world.planets) do
  if (c_cvc(pl, p.col)) then
   local newvel = c_colvel(pl, p.col, _v(p.vx, p.vy))
   local dir = v_norm(v_p2v(pl.x, pl.y, p.x, p.y))
   local edge = v_mult(dir, pl.r + p.col.r)
   p.x = pl.x + edge.x
   p.y = pl.y + edge.y
   if v_mag(_v(p.vx, p.vy)) > 0.02 then
    sfx(2)
    make_r_particle(p.x, p.y, 1, 0.5, 7, 12+rnd(4), 0.95)
    make_r_particle(p.x, p.y, 1, 0.5, 7, 12+rnd(4), 0.95)
    if p.death != true then
     world.score += flr(v_mag(_v(p.vx, p.vy)))
    end
   end
   p.vx = newvel.x * friction
   p.vy = newvel.y * friction


   if (p.inp.bop == 1 and world.jetpacks > 0 and world.state != "lose") then
    -- jump
    p.vx += v_mult(dir, jump).x
    p.vy += v_mult(dir, jump).y
    world.jetpacks -= 1
    for i=1,5 do
     make_r_particle(p.x, p.y, 1.4, 1, 7, 10, 0.94)
    end
    make_r_particle(p.x, p.y, 0, 6, 7, 2, 0, true)
    sfx(8)
    _hitfreeze(0.07)
   end

   if (pl.death == true) then 
    p.s = 0
    for i=1,4 do
     make_r_particle(p.x, p.y, 1, 1, 6, 15, 0.7)
    end
    make_r_particle(p.x, p.y, 0, 6, 7, 2, 0, true)
    sfx(9)
    _lose() 
    _hitfreeze(0.5)
   end

   break
  end
 end

 -- win
 if c_cvc(p.col, world.goal.col) and world.state == "game" then
  make_r_particle(p.x, p.y, 2, 6, 7, 2, 0.2, true)
  sfx(3)
  _win()
  _hitfreeze(0.5)
 end
end

function _draw_player(p)
 if world.state == "game" then
  local mag = v_mag(_v(p.vx, p.vy))
  if mag > 0.10 then
   p.s = 36 + ((10+2*mag)*time()%4)
   make_r_particle(p.x, p.y, 2, 1, 7, 12, 0.4)
   sfx(2)
   world.score += 1
  else
   p.s = 36
  end
 end

 spr(p.s, p.x-3, p.y-3)
 -- circ(p.x, p.y, p.col.r)
end

function make_player()
 local p = {}
 p.x = 0
 p.y = 0
 p.vx = 0
 p.vy = 0
 p.s = 36
 p.m = 1.5
 p.col = make_planet(p.x,p.y,3) -- collision circle
 p.inp = {}
 p.inp.dx = 0
 p.inp.dy = 0
 p.inp.bx  = 0
 p.inp.bo  = 0
 p.inp.v  = _v(0, 0)
 return p
end

-->8
-- hand/spike functions
-- 5
function _init_hand()
 local hand = {}
 hand.x = 64
 hand.y = 64
 hand.vx = 0
 hand.vy = 0
 hand.spr = 16
 hand.grab = false
 hand.grab_last = false
 hand.planet = nil
 hand.ringcol = 7
 world.hand = hand
end

function _update_hand(h)
 local oldvx = h.vx
 local oldvy = h.vy
 h.vx += world.player.inp.dx * 0.5
 h.vy += world.player.inp.dy * 0.5

 if (abs(h.vx) > 2) h.vx = oldvx
 if (abs(h.vy) > 2) h.vy = oldvy

 h.x += h.vx
 h.y += h.vy

 h.x = mid(0, h.x, 128)
 h.y = mid(0, h.y, 128)

 if world.player.inp.dx == 0
 and world.player.inp.dy == 0 then
  h.vx *= 0.7
  h.vy *= 0.7
 end

 if (world.player.inp.bx == 1) then
  h.spr = 18
  if h.grab_last == false then
   sfx(0)
   grab_attempt(h)
  end
  h.grab_last = true
 else
  h.spr = 16
  h.grab_last = false
  h.planet = nil;
 end

 if h.planet != nil then
  local oldx = h.planet.x
  local oldy = h.planet.y
  h.planet.x += h.vx
  h.planet.y += h.vy

  if not no_planet_collisions_boost(h.planet, world.planets, 8) then
   h.ringcol = 8
   h.planet.x = oldx
   h.planet.y = oldy
  else
   h.ringcol = 7
  end

  h.planet.x = mid(0-h.planet.r/2, h.planet.x, 128+h.planet.r/2)
  h.planet.y = mid(0-h.planet.r/2, h.planet.y, 128+h.planet.r/2)
 end
end

function _draw_hand(h)
 spr(h.spr, h.x-7, h.y-7, 2, 2)

 if h.planet != nil then
  fillp(0b0101101001011010.1)
  circ(h.planet.x, h.planet.y, v_mag(v_p2v(h.planet.x, h.planet.y, h.x, h.y)), h.ringcol)
  fillp(0)
 else
  fillp(0)
 end
end

function grab_attempt(h)
 h.planet = get_closest_planet(_v(h.x, h.y))
end

function _init_spikes()
 world.spikes = {}
 add(world.spikes, place_on_planet(world.planets[1], make_spike(0, 0)))
 add(world.spikes, place_on_planet(world.planets[2], make_spike(0, 0)))
 _debug(#world.planets)
 add(world.spikes, place_on_planet(world.planets[#world.planets-1], make_spike(0, 0)))
end

function _update_spikes(spikes)
 for s in all(spikes) do
  local f = _v(0,0)

  for pl in all(world.planets) do
   f = v_add(f, get_planet_force_upon(pl, s))
  end

  local friction = 0.7

  s.vx += f.x
  s.vy += f.y
  s.x += s.vx
  s.y += s.vy
  s.col.x = s.x
  s.col.y = s.y

  -- collsions - other spikes
  for os in all(world.spikes) do
   if (c_cvc(s.col, os.col)) then
    local angle = rnd(360)
    local mag = 2
    s.vx = cos(angle/360) * mag
    s.vy = sin(angle/360) * mag
    for i=1,2 do
     make_r_particle(s.x, s.y, 1 + rnd(1), 0.5, 7, 12+rnd(5), 0.98)
     sfx(4)
    end
   end
  end

  -- collisions - planets
  for pl in all(world.planets) do
   if (c_cvc(pl, s.col)) then
    local newvel = c_colvel(pl, s.col, _v(s.vx, s.vy))
    local dir = v_norm(v_p2v(pl.x, pl.y, s.x, s.y))
    local edge = v_mult(dir, pl.r + s.col.r)
    s.x = pl.x + edge.x
    s.y = pl.y + edge.y
    s.vx = newvel.x * friction
    s.vy = newvel.y * friction

    if (pl.death == true) then -- black hole
     for i=1,4 do
      make_r_particle(s.x, s.y, 0.5, 1, 6, 15, 0.7)
      sfx(9)
     end
     world.score += 2
     del(world.spikes, s)
    end

    break
   end
  end

 end
end

function _draw_spikes(spikes)
 for s in all(spikes) do
  local fy = time()*4 % 1 < 0.5
  spr(s.spr, s.x-3, s.y-3, 1, 1, false, fy)
 end
end

function make_spike(x, y)
 local s = {}
 s.x = x
 s.y = y
 s.vx = 0
 s.vy = 0
 s.spr = 20
 s.col = make_planet(s.x, s.y, 3)
 s.m = 1
 return s
end

-->8
-- 6
-- goal functions
function _init_goal()
 local g = {}
 g.x = 128
 g.y = 128
 g.vx = 0
 g.vy = 0
 g.m = 1
 g.spr = 4
 g.col = make_planet(g.x, g.y, 2)

 -- place around planet 4 (black hole)
 place_on_planet(world.planets[#world.planets], g)
 world.goal = g
end

function _update_goal(g)
 local f = _v(0,0)

 for pl in all(world.planets) do
  f = v_add(f, get_planet_force_upon(pl, g))
 end

 local friction = 0.9

 g.vx += f.x
 g.vy += f.y
 g.x += g.vx
 g.y += g.vy
 g.col.x = g.x
 g.col.y = g.y

 -- collisions
 for pl in all(world.planets) do -- planets
  local bigpl = make_planet(pl.x, pl.y, pl.r+10)
  if (c_cvc(bigpl, g.col)) then
   local newvel = c_colvel(bigpl, g.col, _v(g.vx, g.vy))
   local dir = v_norm(v_p2v(bigpl.x, bigpl.y, g.x, g.y))
   local edge = v_mult(dir, bigpl.r + g.col.r)
   g.x = bigpl.x + edge.x
   g.y = bigpl.y + edge.y
   g.vx *= friction
   g.vy *= friction
   if rnd(6) < 1 then
    make_particle(g.x+rnd(1.5), g.y+6, -0.2+rnd(0.4), 1, 0.5, 6, 16+rnd(10), 0.97)
   end
  end
 end

 for sp in all(world.spikes) do -- spikes
  if c_cvc(sp.col, g.col) then
   g.spr = 0
   make_r_particle(g.x, g.y, 0.1, 6, 7, 3, 1, true)
   for i=1,4 do
    make_r_particle(g.x, g.y, 1+rnd(1.5), 1, 7, 18+rnd(20), 0.97)
   end
   for i=1,8 do
    make_r_particle(g.x, g.y, 1.5+rnd(1.5), 0.5, 7, 20+rnd(20), 0.99)
   end
   sfx(1)
   _lose()
   _hitfreeze(0.5)
  end
 end
end

function _draw_goal(g)
 spr(g.spr, g.x-3, g.y-4)
end

function _init_winship()
 world.winship = make_winship()
end

function make_winship()
 local ws = {}
 ws.x = 48
 ws.y = 128
 ws.vx = 0
 ws.vy = -1
 ws.spr = 12
 return ws
end

function _update_winscreen(ws)
 if ws.y < -72 then
  _new_level()
 end
 
 ws.y += ws.vy
 ws.vy -= 0.02

 if rnd(30) < 20 then
  make_particle(ws.x+8, ws.y+34, -1+rnd(2), 1+rnd(2), 1+rnd(3), 9+flr(rnd(2)), 15+rnd(15), 0.9)
  sfx(5)
 end

 if rnd(30) < 20 then
  make_particle(ws.x+22, ws.y+34, -1+rnd(2), 1+rnd(2), 1+rnd(3), 9+flr(rnd(2)), 15+rnd(15), 0.9)
  sfx(5)
 end
end

function _draw_winscreen()
 local ws = world.winship
 spr(ws.spr, ws.x -1 + rnd(2), ws.y, 4, 4)
end

function _update_losescreen()
 if world.lives <= 0 then
  if world.player.inp.bxp == 1 then
   local hiscore = dget(0)
   if world.score > hiscore then
    dset(0, world.score)
   end
   run()
  end
 elseif world.player.inp.bxp == 1 then
  _reset()
 end
end

function _draw_losescreen()
 if world.lives > 0 then
  print("press ❎ to retry.")
 else
  if world.score > dget(0) then
   local c = 7
   if (sin(time()) > 0) c = 10
   color(c)
   print("high score! press ❎.")
  else
   print("press ❎.")
  end
 end
end

function _init_title()
 world.menustack = {}
 world.menuchoice = 0
 world.menuchoicen = 2
 world.highscore = dget(0)
 add(world.menustack, "main")
 _init_bgstars()
 world.planets = {}
 add(world.planets, make_planet(64, 200, 100))
 music(4)
end

function _update_title()
 if (btnp(3)) then 
  world.menuchoice = (world.menuchoice + 1) % world.menuchoicen
  sfx(6)
 end
 if (btnp(2)) then 
  world.menuchoice = (world.menuchoice - 1) % world.menuchoicen
  sfx(6)
 end
 local menu = world.menustack[#world.menustack]

 if menu == "main" then
  if (btnp(4)) then
   if (world.menuchoice == 0) then
    sfx(7)
    _begin()
   elseif (world.menuchoice == 1) then
    add(world.menustack, "tutorial")
    sfx(7)
   end 
  end
 end

 if menu == "tutorial" then
  if (btnp(5)) then
   del(world.menustack, world.menustack[#world.menustack])
  end
 end
end

function _draw_title()
 local menu = world.menustack[#world.menustack]
 
 _draw_bgstars(world.stars)
 if menu == "main" then
  -- main menu
  _draw_planets(world.planets)
  pal(5, world.planets[1].c)
  pal(6, world.planets[1].c2)

  local paddingn = 6-#tostr(dget(0))
  local padding = ""
  for i=1,paddingn do padding = padding.."0" end

  print("high score: "..padding..dget(0).."00", 22, 0)

  print("play", 56, 64)
  print("tutorial", 48, 72)
  print("★", 38, 64 + world.menuchoice*8)

  spr(64, 22+3*cos(time()/2), 20+4*sin(time()/5), 10, 4)
 elseif menu == "tutorial" then
  pal()
  local yoff = 2*sin(time()/4)+4
  local xoff = 2

  print("get dog (  )...", 34+xoff, 8+yoff)
  spr(36, 70+xoff, 6+yoff) 
  print("...to the doghouse! (  )", 16+xoff, 16+yoff)
  spr(04, 100+xoff, 14+yoff)
  
  print("dog can't move much...", 20+xoff, 26+yoff) 
  print("...but you can move planets!", 0+xoff, 34+yoff)
  
  print("grab and drag planets with ❎", 2+xoff, 44+yoff)
  print("do a jetpack blast with 🅾️", 6+xoff, 52+yoff)
  
  print("don't let spikes (  )...", 14+xoff, 62+yoff)
  spr(20, 86+xoff, 60+yoff)
  print("...hit the doghouse!", 16+xoff, 70+yoff)

  print("grab powerups!", 28+xoff, 80+yoff)
  print("extra life:", 32+xoff, 88+yoff)
  print("extra jetpack blast:", 16+xoff, 96+yoff)
  spr(54, 80+xoff, 88+yoff)
  spr(53, 100+xoff, 96+yoff)

  print("press ❎", 40+xoff, 106+yoff)

 end
end

-->8
-- tick
-- 7
function _update()
 if world.state != "title" then
  get_player_input(world.player)
 end
 if world.state == "game" then
  _update_hand(world.hand)
  _update_spikes(world.spikes)
  _update_player(world.player)
  _update_powerups(world.powerups)
  _update_particles(world.particles)
  _update_goal(world.goal)
 elseif world.state == "win" then
  _update_winscreen(world.winship)
  _update_particles(world.particles)
 elseif world.state == "lose" then
  _update_spikes(world.spikes)
  _update_player(world.player)
  _update_particles(world.particles)
  _update_losescreen()
 elseif world.state == "freeze" then
  -- freeze!
  if time() >= world.freezeend then
   world.state = world.laststate
  end
 elseif world.state == "title" then
  _update_title()
 else
  _debug("idk what state this is :/")
 end
end

function _draw()
 cls()
 if world.state == "game" or world.state == "freeze" then
  _draw_bgstars(world.stars)
  _draw_planets()
  _draw_spikes(world.spikes)
  _draw_player(world.player)
  _draw_hand(world.hand)
  _draw_goal(world.goal)
  _draw_particles(world.particles)
  _draw_powerups(world.powerups)
  _draw_jetpacks()
  _draw_lives()
  _draw_score()
  _draw_arrow(world.arrow)
 elseif world.state == "win" then
  _draw_bgstars(world.stars)
  _draw_spikes(world.spikes)
  _draw_planets()
  _draw_particles(world.particles)
  _draw_powerups(world.powerups)
  _draw_jetpacks()
  _draw_lives()
  _draw_score() 
  _draw_winscreen()
 elseif world.state == "lose" then
  _draw_bgstars(world.stars)
  _draw_planets()
  _draw_spikes(world.spikes)
  _draw_player(world.player)
  _draw_goal(world.goal)
  _draw_particles(world.particles)
  _draw_losescreen()
 elseif world.state == "title" then
  _draw_title()
 end

 _draw_debug()
 _debug_buf = {}
 if (_kill == true) stop()
end

function _draw_debug()
	color(7)
 -- _debug(stat(7)) -- fps
 -- vector field
 -- local dum = {m=1}
 -- for i=0,128,8 do
 --  for j=0,128,8  do
 --   local f = _v(0, 0)
 --   dum.x = i
 --   dum.y = j
 --   for pl in all(world.planets) do
 --    f = v_add(f, get_planet_force_upon(pl, dum))
 --   end
 --   color(7)
 --   line(i, j, i+f.x*10, j+f.y*10)
 --   pset(i+f.x*10, j+f.y*10, 8)
 --  end
 -- end
 if (#_debug_buf > 0) print("", 0, 0)
 for s in all(_debug_buf) do
  print(s)
 end
end