--egypt
--made with ♥ for gbjam7

cartdata"egypt"
asc=[[ !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~]]
bsprs={
 egypt="64203f40000000000014000001400000003f400000000000005ffc3ff00000000001ff00000ff00000003ff000000000007fffddf774000000000df7c0001d74000000f7741dd0000177fffffdffd4000000003f7fc0001dfc000000ffd4ff7c003fdf7f55f07fd007fd0000f7ff50003ffc01f0007fd7df7f003d55fd5f501fc1ffffc007dfff740077f407f5007fd7fdf7c0fdffd5fd401f5ff5ffc00f7f5d7d005ff40f5f001f7df7ffc0fddf1d75001f7df5fd401dfd077d0017d00f7f001dfd57fdd075f43f40001d7fd555001ff507dd00f740077f001ffd017df00550fd4000075d50000035d001d400fd4015fd0017f4007ff00003f500001fd5000000fdd001f0007dd0f7f4001ff00077d0000ff7c0003df4000000fd5000500077fffdf4003fd000df40000fd7c0003dd0000000ff4000000037ff7d74003fcf03f5400005d7f0003ff00ff0007f400000003d7ff7d000774fdf7c000001fff00077d7ff7c007f4015fc000f7d57d0007743ffdd000000fff400ff5ff7f4007d40ffff0005545fd0007f41ff500000007d7400ff7ff5d0007d03ff7f000000ffc0003f40540000000077d400fd7fff50007d077f7f000001df40007f40000000000077f000755fd500007d47fdf7000001ff40005f40000000000055d00017d50000007f41f45f000003df4000774000000000007d50003d740000007f40401d0000015d0000f74000000000007fd0001ff40000007fc0007d000007dd0000774000000000007df0001ff40000007df0007d00000fd40000550000000000007fd0001ff00000001ff001fd00001df400007f4000000000007d50001ff0017ff01f7c03fd00003ff40000ffc000000000007dd0001ff757fffc17ff5ffc000077d00000fdd0000000000017f00075fffdfff4055f7ff400015fd000007fd000000000001f70007d7f5dfff403d5f7f40003df4000007ff00000000000ff7400775fffffd001f5dfd0001f5d0000007ff40000000000fff4001ff7f55540007dffd0017f740000003ff400000000007fd40007fd4000000015fd417ff7500000001fd000000000001fd000015000000000015401d5550000000005400000000000054000",
 man1="2b3c00000000000011400000000000000000015400000000000000000005c00000000000000000013d540000000000000000007500000000000000000001100000000000000000010d140500000000000000010d4010000000000000000414410000000000000000040511410000000000000014104f450000000000007451547745000000000007414145d5040000000000100f0d1155040000000001d3745c507504000000003c0fc353d0d51000000003541d0f4c43c70000000017117014d0475400000007cd41c1d3410f45000000f5050f434fc40f1400017f5414141f47440140007df54000415f4151f4000d3500000405554110400015c000000015500110100010000000015550005010070000000000511000c04074000000001540110141010000000000575544051d0000000000015554040d34100000000054757d001050400000003ff405f501014100000007fd545fd0004500000001fdf4417d000114fd00001ff55001f5000041540005fd540005d000500300003f54000017d000003f0001fc0000001fd04000340003d00000005741000550000d500000003d04001f500013c00000017500000000004f400000007d00000000013d000000007c00000000057400000003d000000000155000000007d00000000051400000000f400000000045000000001d500000000314000000007dd00000000d50000000007540000000000000000001f500000000500000000003d50000050550000000000754000051d400400000001d500000000050000000007540000000000000000001d50000000000000000000750000000000000000000000000000000000000000050000000000000000000015000000000000000000505400000000000000000551d01",
 man2="42481015d00000101000001000000000000005045500000505000005000000000000000005500000000000000000000000000000001c00000000000000000000000000001015d00000101000001000000000000005045500000505000005000000000000000005500000000000000000000000000000001c00000000000000000000000000001015d00000101000001000000000000005045500000505000005000000000000000005500000000000000000000000000000001c00000000000000000000000000001015d00000101000001000001000000005045500000505000005000005000000000005500000000000000000000000000000001c00000000000000000000000000001015d00000101000001000001000000005045500000505000005000005000000000005500000000000000000000000000000001c00000000000000000000000000001015d00000101000001000001000000005045500000505000005000005000000000005500000000000000000000000000000001c00000000000000000000000000001015d00000101000001000001000100005045500000505000005000005000500000005500000000000000000000000000000001c00000000000000000000000000001015d00000101000001000001000100005045500000505000005000005000500000005500000000000000000000000000000001c00000000000000000000000000001015d00000101000001000001000100015045500000505000005000005000500050005500000000000000000000000000000001c00000000000000000000000000001015d00000101000001000001000100015045500000505000005000005000500050005500000000000000000000000000000001c00000000000000000000000000001015d00000101000140000001000100015045500000505000140000005000500050005500000000000050001400000000000001c00000000000140001500000000001015d00000101005455001c0100010000504550000050501d1f5d55c050005000000055000000000141c5547000000000000001c00000000041154550000000000001015d0000010115115700150100000000504550000050515045f40040500000000000550000000014055c001c00000000000001c00000000140500101d00000000001015d00000101054000f00000000000005045500000505140157f00000000000000005500000000000157f00000000000000001c000000000001d1140000000000001015d000001010005405400000000000050455000005050005000500000000000000055000000000014003d0000000000000001c00000000005400000000000000001015d00000101005400000000000000005045500000505005c00000000000000000005500000000015000000000000000000001c00000000040000000000000000001015d00000000054000000000000000005045500000000000000000000000000000005500000000000000000000000000000001c00000000000000000000000000001015d00000000000000000000000000005045500000000000000000000000000000005500000000000000000000000000000001c0000000000000000000000000000",
 man3="584057c00057c0000000000000000000000003d50403d50417c00017c0000000000000000000000003d40003d4001540001540000000000000000000000001540101540154d00054d0000000000000000000000007150007150055f00055f000000000000000000000000f55040f55041f50001f50000000000000000000000005f40005f4001750001750000000000000000000000005f40105f4015550005550000000000000000000000005550005550057c00057c0000000000000000000000003d50403d50417c00017c0000000000000000000000003d40003d4001540001540000000000000000000000001540101540154d00054d0000000000000000000000007150007150055f00055f000000000000000000000000f55040f55041f50001f50000000000000000000000005f40005f4001750001750000000000000000000000005f40105f4015550005550000000000000000000000005550005550057c00057c0000000000000000000000003d50403d50417c00017c0000000000000000000000003d40003d4001540001540000000000000000000000001540101540154d00054d0000000000000000000000007150007150055f00055f000000000000000000000000f55040f55041f50001f50000000000000000000000005f40005f4001750001750000000000000000000000005f40105f4015550005550000000000000000000000005550005550057c00057c000000000000c100000000003d50403d50417c00017c0000000000074ff4000000003d40003d4001540001540000000000010077000000001540101540154d00054d00000000000f5411000000007150007150055f00055f000000000011554500000000f55040f55041f50001f50000000001d5145c000000005f40005f4001750001750000000003051474000000005f40105f4015550005550000000001051050000000005550005550057c00057c0000000001511400000000003d50403d50417c00017c00000000017144c0000000003d40003d400154000154000000000d4415c0000000001540101540154d00054d000000000d1d5740000000007150007150055f00055f000000000d04555000000000f55040f55041f50001f50000000014000740000000005f40005f40017500017500000000140c51c0000000005f40105f40155500055500000000540d10c0000000005550005550057c00057c00000000001d5dd0000000003d50403d50417c00017c0000000000144550000000003d40003d4001540001540000000000150070000000001540101540154d00054d0000000000050170000000007150007150055f00055f000000000015015000000000f55040f55041f50001f50000000000310154000000005f40005f4001750001750000000000330154000000005f40105f40155500055500000000007100cc000000005550005550057c00057c05500550015005cc055005503d50403d50417c00017c7d757d75d5507f515d757d753d40003d4001540001545555555555505501555555551540101540154d00054d55555555554155015555555d7150007150055f00055f555555555500550155555555f55040f55041f50001f55555555555005500555555555f40005f4001750001755555555554005500155555555f40105f40155500055555555555d00155c01555555d5550005550057c00057c5555555540005500005555553d50403d50417c00017c5555555500001500005555553d40003d4001540001545445544d000051400045544d1540101540154d00054d4154414400000000000441547150007150055f00055f405040404000550000404050f55040f55041f50001f50410000000005540000104105f40005f4001750001755000500000005140001050005f40105f40155d00055d10001000000000000000100075500075500",
 man_stand="1020000140000003c000000fd400000040000011c40000040400000111400174f1500d307450071074500510551000145110070cd1000f0c01301c105134340050143d0554141d1d453c003d0f50003d0f00003d0f0000351d000034050000541c0000543c00003454000074d4000071d4000050540001d074000000400001501400",
 rock1="0b2500001000000000010000450001400144500177410474005c1c414011401140141f007c74405100440f0134400005f0041ff5011ffd057c4455005010400507447f00345c500175c0400405507c05f14011c001510401741c015010000000000c000010100000",
 rock2="071104005001453d500350454f407d440000500340010d35100000d001400400",
 rock3="0a4600001000050000000000000010000500000000000000100005000000000010001500050000000000100015000500000000001000150005000000000010001500050000000000100015000500000000001000150005000000000010001500050000000000100015000500000000001000150005000000000010001500050000000000100015000500000000000000100005000000000000001000050000000000000010000500000000000000100005",
 jewel="2020000002aaaa80000000002a8002a800000002a03ff00a0000000a03fffc00a00000283ff00000280000a0fc0000000a000283c00000002280020f000000003080083c000000aafeaa28f000000000302820f008000000200823f0000200002008a3c000000000200a83c00000000020028fc0008000000002830002c0000200028300000000000002802000000000000280200000000003c2a3200800000003ca23e00000000003c820f0000000000f08aafeaa0008080f280830000000003c20022000000000fc8002a00000000ff28000a00000003fca0000280008003c2800002200000000a0000000a000000a000000002aa000a800000002aaaaaaaa8000",
 goddess="3737000000000015515500000000000000000000055ddf554000000000000000000055fff5554000000000000000000555557df5400000000000000000755f5fd57d400000000000000003555755577d00000000000000001f55fd7d57fc00000000000000007d5557557f540000000000000007df57d7dd75500000000000000015ff757f55d5c00000000000000055d55557555f4000000000000001f5555d5555fd000000000000001f555dfdd7d5fc000000000000007dd5f7f7d5d77000000000000001df77dff77dd54000000000000007fddf7fdf7dff40000000000000155f7fffdf77f700000000000000f57fffff7fddfc00000000000003d5ffffffff7df0000000000000055700ffc03dd5c00000000000005f7ffcfcfffdf50000000000000175d15ffd51f7d400000000000005f7f03cf03fffd000000000000017dffff3fffffdc000000000000057dfffcffffff7000000000000015ffffcffffff7c0000000000000753fff3cfffc7f00000000000001f4ffff0ffff05c00000000000007d0ffffffff00500000000000001d53ff3fcffc11c00000000000001d03ff00ffc04300000000000000745fffffff044400000000000003d44ffffff051500000000000000d040fffff01454000000000000035110ffff3d11500000000000000740003fc3f045400000000000005f10c0003fc105000000000000005443f000ffc0440000000000000155fff00fffc01000000000000017fffffffffffffaaa00000000ffffffffffffffffeafea000003ffffffffffffffffeaaffa00003ffffffffffffffffeaaeabe0003ffffffffffffffffaabeaaaa000ffffffc0ffffff03aabebbfa800ffffffff03fffc0faabebaafa00fffffffffc3ffc3eaffefaaaaa0fffffffffffffeaabffafaaebe83ffffcffffffeafebfeaeaababe8ffffc3ffffeafbabfebebabfeaabffff3fffaafebabfabebeaffaaaffffcffabfeafafeafabeabfea8bffff3abfaafebfaaeabeaaaea02babaebfaaaaaaaaaa2aaaaaaa00082820aaaa88a22a2088aaa2a8000",
 gbjam="1014555555556aaaaaa96ffffff96ffffff96d555d796f7777796f757f796d777f796ffffff96fffffe96aaaaaa96aaaaaa96a6aaa59695aaa596a6aaaa96aaaa5a96aaaa5a96aaaaaa96aaaaaa455555550",
}
jewel={x=0,y=0,z=0,dx=0,dy=0,dz=0,tz=0,}
function move_jewel(float)
 jewel.x+=jewel.dx
 jewel.y+=jewel.dy
 if (jewel.tz==0) sfx(61,3)
 jewel.tz+=1
 if (not float) jewel.z=-sin(jewel.tz/16)*4
 if jewel.tz>=8 then
  jewel.dx,jewel.dy,jewel.dz,jewel.tz=0,0,0,0
  if (not float) jewel.z=0
  return true
 end
 return false
end
function draw_jewel(mx,my,hs)
 pal(1,c(0))
 if (not hs) spr(16,(jewel.x+mx)*8,(jewel.y+my)*8)
 spr(15,(jewel.x+mx)*8,(jewel.y+my)*8-jewel.z-1)
end
function init_starfield()
 sf1,sf2,sfy1,sfy2={},{},0,0
 for i=1,200 do
  add(sf1,{
   x=flr(rnd(128)),
   y=flr(rnd(256)),
  })
  add(sf2,{
   x=flr(rnd(128)),
   y=flr(rnd(256)),
  })
 end
end
function upd_starfield()
 sfy1,sfy2=(sfy1-.5)%256,(sfy2-1)%256
end
function draw_starfield()
 for star in all(sf1) do
  pset(star.x,(star.y+sfy1)%256-128,4)
 end
 for star in all(sf2) do
  pset(star.x,(star.y+sfy2)%256-128,7)
 end
end
fade_spd=.04
local st={}
-->8
--functions

function init_egypt()
 pwi={22,124,180,32,134,120,136,18,88,124,128,68,140,248,138,68}
 pws={178,23,33,179,141,83,133,168,166,242,141,217,25,237,216,59}
 pwo={184,80,8,136,176,24,200,16,216,16,240,40,24,216,232,176}
end
function save_egypt(save_to_cart)
 local difficulty,floor,rooms,magic,h=st.map.difficulty,st.map.floor,st.map.rooms,st.game.magic,true
 local n,r={0,bor(rooms,shl(difficulty,6)),shl(floor,3)},{}
 for u=1,3 do
  add(r,magic[u])
 end
 if difficulty==1 then
  r={0,0,0}
 else
  local s=0
  for u=1,3 do
   if (r[u]>3) h=false
   s+=r[u]
  end
  if (s>8) h=false
 end
 if h then
  n[1]=r[1]*64+r[2]*16+r[3]*4
  local a=0
  for u=1,3 do
   a+=flr(n[u]/16)+n[u]%16
  end
  a%=16
  n={bxor(n[1]+band(a,1),pwi[a+1]),bxor(n[2],pws[a+1]),bxor(n[3]+flr(shr(a,1)),pwo[a+1])}
  if save_to_cart then
   for u=1,3 do
    poke(0x5dff+u,n[u])
   end
  end
 end
 return h and hex(n[1],2)..hex(n[2],2)..hex(n[3],2) or "invalid"
end
function load_egypt(password)
 local h=true
 if (#password!=6) h=false
 local game
 if h then
  local n={}
  for u=1,6,2 do
   add(n,dec(sub(password,u,u+1)))
  end
  local a=n[3]%8*2+band(n[1],1)
  n={bxor(band(n[1],254),pwi[a+1]),bxor(n[2],pws[a+1]),bxor(band(n[3],248),pwo[a+1])}
  local aa=0
  for u=1,3 do
   aa+=flr(n[u]/16)+n[u]%16
  end
  aa%=16
  game,h={
   difficulty=flr(shr(n[2],6)),
   floor=shr(n[3],3),
   rooms=n[2]%64,
   magic={flr(shr(n[1],6))%4,flr(shr(n[1],4))%4,flr(shr(n[1],2))%4},
  },a==aa
  if (game.difficulty>2) h=false
  if (game.floor>18) h=false
  if (game.floor==18 and (game.rooms>0 and game.difficulty!=1 or game.rooms!=2^count_bits(game.rooms)-1)) h=false
  local s=0
  for u=1,3 do
   if (game.magic[u]>3) h=false
   s+=game.magic[u]
  end
  if (s>8) h=false
  if (game.difficulty==1 and s>0) h=false
 end
 return h and game or "invalid"
end
function c(n)
 return peek(0x5f00+n)
end
function dec(s)
 return tonum("0x"..s)
end
function hex(n,l)
 l=l or 1
 local s=sub(tostr(n,true),3,6)
 while sub(s,1,1)=="0" do
  s=sub(s,2,-1)
 end
 while #s<l do
  s="0"..s
 end
 return s
end
function count_bits(n)
 local s=0
 while n>=1 do
  s+=band(n,1)
  n=shr(n,1)
 end
 return s
end
function init_btns()
 oldbtns,btns=0,0
end
function upd_btns()
 oldbtns,btns=btns,btn()
end
function btnf(b)
 return band(btns,shl(1,b))>0 and band(oldbtns,shl(1,b))==0
end
function print_center(s,x,y,c,d)
 local w=1
 for i=1,#s do
  w+=(sub(s,i,i)>="█" and 8 or 4)
 end
 print_outline(s,x-flr(w/2)+64,y,c,d)
end
function print_outline(s,x,y,c,d)
 for a=x-1,x+1 do
  for b=y-1,y+1 do
   print(s,a,b,d)
  end
 end
 print(s,x,y,c)
end
function fadepal(fd)
 local dpal=fd<0 and "55dded77eaf666f7" or "001121d64493d1de"
 for j=0,15 do
  local col=j
  for k=1,(flr(mid(0,abs(fd),1)*100)+(j*1.46))/22 do
   col=dec(sub(dpal,col+1,col+1))
  end
  pal(c(j),col)
 end
end
function save_pal()
 tmpl={}
 for i=0,15 do
  tmpl[i]=c(i)
 end
end
function reload_pal()
 for i=0,15 do
  pal(i,tmpl[i])
 end
end
function apply_filter()
 for i=0,15 do
  pal(i,dec(sub("004044ff44fcc4ff",i+1,i+1)),1)
 end
end
function fade_b2n()
 while fade>0 do
  _draw()
  flip()
  fade-=fade_spd
 end
 fade=0
end
function fade_n2b()
 while fade<1 do
  _draw()
  flip()
  fade+=fade_spd
 end
 fade=1
end
function fade_w2n()
 while fade<0 do
  _draw()
  flip()
  fade+=fade_spd
 end
 fade=0
end
function fade_n2w()
 while fade>-2 do
  _draw()
  flip()
  fade-=fade_spd
 end
 fade=-2
end
function box(x,y,w,h)
 rectfill(x,y,x+w-1,y+h-1,0)
 for i=0,w+5,w+5 do
  rectfill(x+i-5,y,x+i-1,y+h-1,0)
  for j=2,ceil(h/4+1) do
   spr(22,x+i-4,y+j*4-8)
  end
 end
 for i=0,h+5,h+5 do
  rectfill(x,y+i-5,x+w-1,y+i-1,0)
  for j=2,ceil(w/4+1) do
   spr(23,x+j*4-8,y+i-4)
  end
 end
 for i=0,w+5,w+5 do
  for j=0,h+5,h+5 do
   rectfill(x+i-6,y+j-6,x+i,y+j,0)
   spr(21,x+i-5,y+j-5)
  end
 end
end
function init_print_ti()
 ord={}
 for i=1,#asc do
  ord[sub(asc,i,i)]=i*8-7
 end
end
function print_ti(s,x,y,c)
 local cx,cy,ti=0,0,[[100000001000001d3000601850afabea509afeb230004c994005554110000018200001d12000022e50a27c8a300011c420000026300010841000000130000c9830003a2e300027e130004ea9300046aa3000708f300076b230003eb730004e9830007ebf300076be1000000a2000002a300011513000294a30004544300042a8512ade2e30003e8f30007eaa30003a3130007e2e30007eb130007e9030003a3730007c9f300047f130000c3f30007c9b30007c2130007d9f30007e0f30007e3f30007e8830007a7f30007e8b300026b2300043f030007c3f3000707c30007cdf30006c9b300060f830004eb9200003f1300060832000023f3000220830000421200002083000192f30007d26300019293000193f30001965200001f4300026be30007d07100000173000083630007c452000021f50f4190730003d073000192630003d443000114f30003c88200001ab200003c930003c2f3000306c50e0982e300024c93000344c4004ada9300013711000001f3000476440022088]]
 for i=1,#s do
  local chr=sub(s,i,i)
  if chr=="\n" then
   cx=0 cy+=6
  else
   local j=ord[chr]
   local w,b=tonum(sub(ti,j,j)),tonum("0x"..sub(ti,j+1,j+3).."."..sub(ti,j+4,j+7))
   for k=w-1,0,-1 do
    for l=4,0,-1 do
     if (band(b,0x.0001)>0) pset(x+cx+k,y+cy+l,c)
     b/=2
    end
   end
   cx+=w+1
  end
 end
end
function bspr(s,x,y,p)
 local pl,w,h,sc,num={[0]=0,4,12,15},dec(sub(s,1,2)),dec(sub(s,3,4)),5,0
 for j=0,h-1 do
  for i=0,w-1 do
   num*=4
   if (sc%1==0) num=shr(dec(sub(s,sc,sc)),2)
   local cl=pl[band(num,0b11)]
   if (cl>0) pset(x+i,y+j,cl)
   sc+=.5
  end
 end
end
local curr_st
function sw_st(st,...)
 local prev=curr_st
 curr_st=st
 curr_st:enter(prev,...)
end
-->8
--init/update/draw

function _init()
 init_btns()
 init_print_ti()
 init_egypt()
 fade=1
 sw_st(st.opening)
end

function _update()
 upd_btns()
 curr_st:update()
end

function _draw()
 pal() fadepal(fade)
 curr_st:draw()
 apply_filter()
end
-->8
--game state

st.game={}

function st.game:enter(prev,lvl)
 self.level=lvl
 for i=0,7 do
  for j=0,7 do
   mset(i,j,sget(self.level%16*8+i,flr(self.level/16)*8+64+j))
  end
 end
 for i=0,7 do
  for j=0,7 do
   if (fget(self:tget(i,j),3)) jewel.x,jewel.y=i,j self:tset(i,j,0)
  end
 end
 self:init_flood_board()
 self:upd_mtbl()
 jewel.z,jewel.dx,jewel.dy,jewel.dz,self.pt,self.magic_tmr,self.float_steps,self.slide_i,self.match_i,self.step,self.rot, self.using_magic,self.floating=0,0,0,0,0,0,0,0,0,0,0,false,false
 fade_b2n()
 if (prev!=self) music(flr(self.level/6)%2==0 and 0 or 9)
 menuitem(1,"restart level",function()
  while not move_jewel() do end
  sfx(61,-2)
  sw_st(st.game,st.game.level)
 end)
 menuitem(2,"give up",function()
  while jewel.tz>0 do
   move_jewel(self.floating)
   _draw()
   flip()
  end
  sw_st(st.gamelose,true)
 end)
end

function st.game:init_flood_board()
 self.brd={}
 for i=0,7 do
  self.brd[i]={}
  for j=0,7 do
   self.brd[i][j]=0
  end
 end
end

function st.game:update()
 if self.slide_i<=0 then
  if self.match_i<=0 then
   if self.using_magic then
    if jewel.dx==0 and jewel.dy==0 then
     if btnp(➡️) or btnp(⬅️) then
      jewel.dx=btnp(➡️) and .125 or -.125
     elseif btnf(❎) then
      local item=self.mtbl[jewel.x+1]
      if (item>0) self.magic[item]-=1
      self:upd_mtbl()
      if item==1 then
       local used=false
       self:init_flood_board()
       for i=0,7 do
        for j=0,7 do
         if (fget(self:tget(i,j),2)) self.brd[i][j]=self:tget(i,j) used=true
        end
       end
       if (used) self.match_i=29 sfx(63,3)
      elseif item==2 then
       self.floating=true
       self.float_steps=5
      elseif item==3 then
       local used=false
       self:init_flood_board()
       for i=self.jx-1,self.jx+1 do
        for j=self.jy-1,self.jy+1 do
         if i==mid(0,i,7) and j==mid(0,j,7) then
          if (fget(self:tget(i,j),2)) self.brd[i][j]=self:tget(i,j) used=true
         end
        end
       end
       if (used) self.match_i=29 sfx(63,3)
      end
      self.using_magic=false
      jewel.x,jewel.y=self.jx,self.jy
      if item==2 then
       while jewel.z<4 do
        jewel.z+=1
        _draw()
        flip()
       end
      end
     elseif btnf(🅾️) then
      self.using_magic=false
      jewel.x,jewel.y=self.jx,self.jy
     end
     local fx=jewel.x+jewel.dx*8
     if (fx!=mid(0,fx,7)) jewel.dx=0
    else
     move_jewel()
    end
   else
    if jewel.dx==0 and jewel.dy==0 then
     if btnp(➡️) or btnp(⬅️) then
      jewel.dx=btnp(➡️) and .125 or -.125
     elseif btnp(⬇️) or btnp(⬆️) then
      jewel.dy=btnp(⬇️) and .125 or -.125
     elseif btnf(🅾️) then
      self.jx,self.jy,jewel.x,jewel.y=jewel.x,jewel.y,0,0
      self.using_magic=true
     end
     local fx,fy=jewel.x+jewel.dx*8,jewel.y+jewel.dy*8
     if (fx!=mid(0,fx,7) or fy!=mid(0,fy,7) or (not self.floating and fget(self:tget(fx,fy),2))) jewel.dx,jewel.dy=0,0
    else
     if move_jewel(self.floating) then
      self.step=min(self.step+1,999)
      if self.float_steps>0 then
       self.float_steps-=1
       if self.float_steps==0 then
        self.floating=false
        while jewel.z>0 do
         jewel.z-=1
         _draw()
         flip()
        end
       end
      else
       self.pt=self:tget(jewel.x,jewel.y)
       if (fget(self.pt,1)) self.slide_i=8 sfx(62,3)
      end
     end
    end
   end
  else
   self.match_i-=1
   for i=0,7 do
    for j=0,7 do
     local tl=self.brd[i][j]
     if (tl>0) self:tset(i,j,({0,tl,0,tl,0,tl,0,tl,0,tl,0,tl,0,tl,0,tl,17,18,19,20,17,18,19,20,17,18,19,20,0,})[29-self.match_i])
    end
   end
   if self.match_i==0 then
    local won,lost=true,false
    local count={0,0,0,0,0,0,0,0,0}
    for i=0,7 do
     for j=0,7 do
      if (fget(self:tget(i,j),0)) count[self:tget(i,j)]+=1 won=false
     end
    end
    for i=1,9 do
     if (count[i]==1) lost=true
    end
    if won then
     if st.map.floor==18 and st.map.lvl==5 then
      music(-1,1000)
      fade_n2w()
      sw_st(st.cutscene,3)
     else
      sw_st(st.gamewin)
     end
    end
    if (lost) sw_st(st.gamelose)
   end
  end
 else
  self.slide_i-=1.5
  if self.slide_i<=0 then
   self.rot=min(self.rot+1,999)
   local md=self.pt-10
   if md<2 then
    local mm=md*2-1
    for i=0,7*mm,mm do
     self:tset(jewel.x+i,jewel.y,self:tget(jewel.x+i+mm,jewel.y))
    end
    self:tset(jewel.x-mm,jewel.y,self.pt)
   else
    local mm=(md-2)*2-1
    for i=0,7*mm,mm do
     self:tset(jewel.x,jewel.y+i,self:tget(jewel.x,jewel.y+i+mm))
    end
    self:tset(jewel.x,jewel.y-mm,self.pt)
   end
   local b={}
   for i=0,7 do
    b[i]={}
    for j=0,7 do
     b[i][j]=false
    end
   end
   self:init_flood_board()
   for i=0,7 do
    for j=0,7 do
     local target=self:tget(i,j)
     if fget(target,0) then
      b[i][j]=true
      local q={{i,j}}
      local group={q[1]}
      while #q>0 do
       local n=q[1]
       del(q,q[1])
       for k=1,4 do
        local nn=({
         {n[1]-1,n[2]},
         {n[1]+1,n[2]},
         {n[1],n[2]-1},
         {n[1],n[2]+1},
        })[k]
        if nn[1]==mid(0,nn[1],7) and nn[2]==mid(0,nn[2],7) and not b[nn[1]][nn[2]] and self:tget(nn[1],nn[2])==target then
         b[nn[1]][nn[2]]=true
         add(group,nn)
         add(q,nn)
        end
       end
      end
      if #group>1 then
       for tl in all(group) do
        self.brd[tl[1]][tl[2]]=self:tget(tl[1],tl[2])
       end
       self.match_i=29
       sfx(63,3)
      end
     end
    end
   end
  end
 end
 if (curr_st!=self) menuitem(1) menuitem(2)
end

function st.game:tget(x,y)
 return mget(x%8,y%8)
end

function st.game:tset(x,y,t)
 return mset(x%8,y%8,t)
end

function st.game:upd_mtbl()
 self.mtbl={0,0,0,0,0,0,0,0}
 local count=0
 for i=#self.magic,1,-1 do
  for j=1,self.magic[i] do
   self.mtbl[count+1]=i
   count+=1
  end
 end
end

function st.game:draw()
 self:draw_game()
 if self.using_magic then
  draw_jewel(1,12)
 else
  draw_jewel(1,2)
 end
end

function st.game:draw_game(map_dark)
 save_pal()
 cls(c(4))
 box(8,16,64,64)
 if (map_dark) pal(15,c(4))
 map(0,0,8,16,8,8)
 if self.slide_i>0 then
  local md=self.pt-10
  if md<2 then
   clip(8,16+jewel.y*8,64,8)
  else
   clip(8+jewel.x*8,16,8,64)
  end
  rectfill(8,16,72,80,0)
  for i=-1,1 do
   if md<2 then
    map(
     0,jewel.y,
     8+i*64+(md*2-1)*(self.slide_i-8),
     16+jewel.y*8,
     8,1
    )
   else
    map(
     jewel.x,0,
     8+jewel.x*8,
     16+i*64+((md-2)*2-1)*(self.slide_i-8),
     1,8
    )
   end
  end
  clip()
 end
 reload_pal()
 box(96,16,24,72)
 local count={0,0,0,0,0,0,0,0,0}
 for i=0,7 do
  for j=0,7 do
   if self.match_i>0 and fget(self.brd[i][j],0) then
    count[self.brd[i][j]]+=1
   elseif fget(self:tget(i,j),0) then
    count[self:tget(i,j)]+=1
   end
  end
 end
 local j=0
 for i=1,9 do
  if count[i]>0 then
   spr(i,100,j*8+16)
   print(count[i],112,j*8+18,15)
   j+=1
  end
 end
 box(8,104,64,8)
 for i=1,#self.mtbl do
  if (self.mtbl[i]>0) spr(120+self.mtbl[i],8*i,104)
 end
 if (st.map.floor==18 and curr_st==self) print("password: "..save_egypt(),8,106,15)
 box(88,104,32,16)
 print("step "..tostr(self.step),88,106,15)
 print("rot  "..tostr(self.rot),88,112,15)
end

--win level state

st.gamewin={door_spd=.02}

function st.gamewin:enter(prev,px,py)
 self.door_i=0
 self.music_done,self.at_door,self.door_opened,self.in_door,self.fading_out=false,false,false,false,false
 local cb1=count_bits(st.map.rooms)
 st.map.rooms=bor(st.map.rooms,shl(1,st.map.lvl))
 local cb2=count_bits(st.map.rooms)
 if st.map.difficulty==0 and cb1==3 and cb2==4 then
  music(-1)
  local mgc={}
  local s=0
  for i=1,3 do
   s+=st.game.magic[i]
  end
  if s<8 then
   local count=0
   for i=3,1,-1 do
    count+=st.game.magic[i]
    if (st.game.magic[i]<3) add(mgc,{i,count})
   end
  end
  local mgx,mgy,mgtx,mgty,mgfc,mgi=100,-8,72,104,0,nil
  if (#mgc>0) mgi=mgc[flr(rnd(#mgc))+1] mgtx=mgi[2]*8+8
  while mgy!=mid(mgty-1,mgy,mgty+1) do
   mgx+=(mgtx-mgx)/16
   mgy+=(mgty-mgy)/16
   _draw()
   spr(17+mgfc,mgx,mgy)
   flip()
   mgfc=(mgfc+1)%4
  end
  if (mgi) st.game.magic[mgi[1]]+=1 st.game:upd_mtbl()
  sfx(57,3)
  while stat(19)!=-1 do
   _draw()
   flip()
  end
 end
 save_egypt(true)
 music(15)
end

function st.gamewin:update()
 if self.music_done then
  if self.at_door then
   if self.door_opened then
    if self.in_door then
     if self.fading_out then
      if stat(19)==-1 then
       fade+=fade_spd
       if fade>=1 then
        if st.map.floor==18 then
         st.map.lvl+=1
         sw_st(st.game,108+st.map.lvl)
        else
         sw_st(st.map,st.map.floor)
        end
       end
      end
     else
      self.door_i=mid(0,self.door_i-self.door_spd,1)
      if (self.door_i<=0) sfx(59,3) self.fading_out=true
     end
    else
     jewel.dx,jewel.dy=jewel.x<3.5 and .0625 or -.0625,-.125
     if (move_jewel()) self.in_door=true sfx(60,3)
    end
   else
    self.door_i=mid(0,self.door_i+self.door_spd,1)
    if (self.door_i>=1) self.door_opened=true sfx(60,-2)
   end
  else
   self.jewel_should_move=true
   if jewel.x==3 or jewel.x==4 then
    if jewel.y>0 then
     jewel.dx,jewel.dy=0,-.125
    else
     self.at_door=true
     sfx(60,3)
    end
   else
    jewel.dx,jewel.dy=jewel.x<3 and .125 or -.125,0
   end
   if (move_jewel() and jewel.x==mid(3,jewel.x,4) and jewel.y==0) self.at_door=true sfx(60,3)
  end
 else
  if (stat(24)==-1) self.music_done=true
 end
end

function st.gamewin:draw()
 st.game:draw_game(true)
 pal(1,c(0))
 rectfill(32,7,47,14,0)
 if (self.in_door) draw_jewel(1,2,true)
 spr(flr(self.door_i*3+.5)*2+24,32,7,2,1)
 if (not self.in_door) draw_jewel(1,2)
end

--lose level state

st.gamelose={}

function st.gamelose:enter(prev,kick)
 self.kick_to_map,self.music_done=kick,false
 music(16)
end

function st.gamelose:update()
 if self.music_done then
  fade+=fade_spd
  if fade>=1 then
   if self.kick_to_map then
    sw_st(st.map,st.map.floor)
   else
    sw_st(st.game,st.game.level)
   end
  end
 else
  if (stat(24)==-1) self.music_done=true
 end
end

function st.gamelose:draw()
 st.game:draw_game(true)
 draw_jewel(1,2)
end
-->8
--map state

st.map={flash_spd=.02}

function st.map:enter(prev)
 if (prev==st.fall) self.floor+=1 self.rooms=0
 self.bg=flr(self.floor/6)
 self.order,self.mx,self.my,self.cam_x,self.flashing,self.flash_i=({{0,5,1,4,2,3},{5,0,4,1,3,2},{0,5,1,4,2,3},{0}})[self.bg+1],self.bg*17+8,0,({4,0,4,4})[self.bg+1],self.floor==18 or count_bits(self.rooms)>=3,0
 reload(0x2000,0x2000,0x1000)
 if prev==st.fall or prev==st.combine or prev==st.title then
  jewel.x,jewel.y=8,self.bg+8
 else
  jewel.x,jewel.y=self.jx,self.jy
 end
 if prev==st.fall or prev==st.combine then
  jewel.z,self.fallen,self.impacted=128,false,false
 else
  jewel.z,self.fallen,self.impacted=0,true,true
 end
 local count=1
 local lvl
 for j=0,15 do
  for i=0,16 do
   if fget(self:tget(i,j),3) then
    lvl=self.order[count]
    if (band(self.rooms,shl(1,lvl))>0) self:tset(i,j,125)
    count+=1
   end
  end
 end
 jewel.dz,self.faded_in,self.lvl=0,false,0
 save_egypt(true)
 if (self.floor<18) music(17)
end

function st.map:update()
 if self.faded_in then
  self.flash_i+=self.flash_spd
  if self.fallen then
   if self.impacted then
    if jewel.dx==0 and jewel.dy==0 then
     if btnp(➡️) or btnp(⬅️) then
      jewel.dx=btnp(➡️) and .125 or -.125
     elseif btnp(⬇️) or btnp(⬆️) then
      jewel.dy=btnp(⬇️) and .125 or -.125
     elseif btnf(❎) then
      if fget(self:tget(jewel.x,jewel.y),3) then
       local i,j,count=0,0,1
       while i!=jewel.x or j!=jewel.y do
        if (fget(self:tget(i,j),3)) count+=1
        i+=1
        if i>=17 then
         i=0 j+=1
         if (j>=16) break
        end
       end
       self.lvl=self.order[count]
       music(-1,1000)
       fade_n2b()
       self.jx,self.jy=jewel.x,jewel.y
       sw_st(st.game,self.floor*6+self.lvl)
      elseif self.flashing and fget(self:tget(jewel.x,jewel.y),5) then
       music(-1,1000)
       if self.floor==18 then
        if self.difficulty==1 then
         self.lvl=0
         fade_n2b()
         sw_st(st.game,108)
        else
         fade_n2w()
         sw_st(st.cutscene,3)
        end
       else
        fade_n2b()
        sw_st(st.fall)
       end
      end
     end
     local fx,fy=jewel.x+jewel.dx*8,jewel.y+jewel.dy*8
     local fx2=fx-self.cam_x/8
     if (fx2!=mid(0,fx2,15) or fy!=mid(0,fy,15) or fget(self:tget(fx,fy),2)) jewel.dx,jewel.dy=0,0
    else
     move_jewel()
    end
   else
    if (move_jewel()) self.impacted=true
   end
  else
   jewel.dz+=.3
   jewel.z-=jewel.dz
   if (jewel.z<0) jewel.z,self.fallen=0,true
  end
 else
  fade-=fade_spd
  if (fade<=0) fade,self.faded_in=0,true
 end
end

function st.map:tget(x,y)
 return mget(self.mx+x,self.my+y)
end

function st.map:tset(x,y,t)
 return mset(self.mx+x,self.my+y,t)
end

function st.map:draw()
 cls(c(0))
 camera(self.cam_x,0)
 save_pal()
 pal(1,c(0))
 map(self.mx,self.my,0,0,17,16)
 if (self.flashing) fadepal(cos(self.flash_i)) map(self.mx,self.my,0,0,17,16,0x10)
 reload_pal()
 draw_jewel(0,0)
 camera()
 if (btn(6)) print_outline("password: "..save_egypt(),32,120,15,4)
end

--falling animation state

st.fall={}

function st.fall:enter()
 self.cam_y,jewel.x,jewel.y,self.faded_in,self.jewel_fell,self.faded_out=0,7.5,-4,false,false,false
 sfx(58)
end

function st.fall:update()
 if self.faded_out then
  sw_st(st.map)
 else
  self.cam_y-=6
  jewel.y+=.25
  if (jewel.y>=17) self.jewel_fell=true
  if self.jewel_fell then
   fade+=fade_spd
   if (fade>=1) self.faded_out=true
  else
   if not self.faded_in then
    fade-=fade_spd
    if (fade<=0) fade,self.faded_in=0,true
   end
  end
 end
end

function st.fall:draw()
 cls(c(0))
 for i=0,4 do
  local y,j=self.cam_y,0
  while y<128 do
   if y>=-56 then
    local x=10+i*30-(j%3*12)
    for k=0,2 do
     rectfill(x,y+k*14,x,y+k*14+13,c(({15,15,12})[k+1]))
    end
   end
   j=(j+1)%8 y+=28
  end
 end
 draw_jewel(0,0,true)
end
-->8
--cutscene state

st.cutscene={
 text_spd=.85,
 text_wait=100,
 scenes={
  {
   pics={
    {bsprs.rock1,13,26},
    {bsprs.rock2,96,37},
    {bsprs.man1,38,12},
   },
   text={
[[On that day, I found myself
venturing solo into an
unexplored temple.]],
[[Before I knew it, I had
wandered far into its depths.]],
[[When suddenly...]],
   },
  },
  {
   pics={
    {bsprs.rock3,114,0},
    {bsprs.man2,6,0},
    {bsprs.jewel,76,28},
   },
   text={
[[An enormous jewel enveloped
by a beautiful light revealed
itself before me.]],
[["I am the goddess of this temple,
who protected this land long
ago."]],
[["For thousands of years, I have
awaited an adventurer like you."]],
[["Unfortunately, you have
already been trapped within this
cursed temple."]],
[["I too have been stuck here for
eons, sealed within by the
machinations of evil."]],
[["Scattered throughout here are
a number of seals, which have
caused my power to dwindle."]],
[["The jewel you see before you is
what remains of me, created
with what power I have left."]],
[["It has the power to dispel the
seals throughout the temple."]],
[["However, I no longer possess
the power necessary to control
it."]],
[["Please, take control of this
jewel, and liberate me from this
temple."]],
   },
  },
  {
   pics={
    {bsprs.goddess,36,17},
   },
   text={
[["You have done well to come so
far."]],
[["Thanks to your efforts, all of
the seals within this temple have
been dispelled."]],
[["My power has been restored,
and I am able to protect this
beautiful land as I did long ago."]],
[["You have shown yourself to
possess both courage and
wisdom."]],
[["As a sign of gratitude, I would
like to grant you any wish you
may have."]],
   },
  },
  {
   pics={
    {bsprs.man3,22,8},
   },
   text={
[[However, I had nothing that I
wished for.]],
[[For as an adventurer, I had
already obtained the fulfillment
I needed by clearing this temple.]],
[[With the curse dispelled, I
stepped out of the temple...]],
[[...and once again gazed upon the
sunrise over the lands of the
goddess.]],
   },
  },
 },
}

function st.cutscene:enter(prev,scn)
 self.scene_i,self.text,self.text_i=scn,1,15*-self.text_spd
 self.scene=self.scenes[self.scene_i]
 if self.scene_i==3 then
  poke(0x5e00,0x00)
  poke(0x5e01,0x00)
  poke(0x5e02,0x00)
  fade_w2n()
 else
  fade_b2n()
 end
 if (prev!=self) music(self.scene_i<3 and 17 or 19)
end

function st.cutscene:update()
 self.text_i+=self.text_spd
 if (self.scene_i<3 and btnp(❎) and self.text_i<#self.scene.text[self.text]) self.text_i=#self.scene.text[self.text]+self.text_wait*.9*self.text_spd
 if self.text_i>#self.scene.text[self.text]+self.text_wait*self.text_spd then
  self.text_i=0
  self.text+=1
  if self.text>#self.scene.text then
   fade_n2b()
   if self.scene_i==2 then
    music(-1,1000)
    sw_st(st.combine)
   elseif self.scene_i==4 then
    sw_st(st.ending)
   else
    sw_st(st.cutscene,self.scene_i+1)
   end
  end
 end
end

function st.cutscene:draw()
 cls(c(0))
 for pic in all(self.scene.pics) do
  bspr(pic[1],pic[2],pic[3],pic[4])
 end
 box(7,92,114,21)
 if (self.text<=#self.scene.text and self.text_i>=1) print_ti(sub(self.scene.text[self.text],1,self.text_i),8,94,7)
end

--man/jewel combining state

st.combine={
 start_offset=80,
 offset_spd=1.1,
 wait=60,
 flash_spd=.075,
}

function st.combine:enter()
 self.offset,self.flashing,self.flashed,self.wait_tmr=self.start_offset,false,false,self.wait
end

function st.combine:update()
 if self.flashed then
  fade=min(0,fade+self.flash_spd)
  self.wait_tmr-=1
  if (self.wait_tmr<=0) fade_n2b() sw_st(st.map)
 else
  if self.flashing then
   fade-=self.flash_spd
   if (fade<=-1) self.flashed=true
  else
   if self.offset>0 then
    fade=max(0,fade-fade_spd)
    self.offset=max(0,self.offset-self.offset_spd)
    if (self.offset==0) sfx(57) self.flashing=true
   end
  end
 end
end

function st.combine:draw()
 cls(c(0))
 if (not self.flashed) bspr(bsprs.man_stand,64-8-self.offset,48,"04cf")
 bspr(bsprs.jewel,64-16+self.offset,48,"04cf")
end

--ending state

st.ending={scroll_up_wait=120,end_wait=150}

function st.ending:enter()
 self.cam_y,self.scroll_timer,self.end_timer=0,self.scroll_up_wait,self.end_wait
 fade_b2n()
end

function st.ending:update()
 if self.scroll_timer>0 then
  self.scroll_timer-=1
 else
  self.cam_y=max(-128,self.cam_y-1)
  if self.cam_y<=-128 then
   self.end_timer-=1
   if self.end_timer<=0 then
    fade_n2b()
    sw_st(st.credits)
   end
  end
 end
end

function st.ending:draw()
 cls(c(12))
 camera(0,self.cam_y)
 pal(1,c(0))
 map(93,0,0,0,16,16)
 spr(118,52,-68,3,1)
end
-->8
--title screen state

st.title={pw_iv_time=30}

function st.title:enter()
 init_starfield()
 self.cam_y,jewel.x,jewel.y,self.faded_in,self.menu,self.newgame,self.password,self.fading_out=-128,0,0,false,false,false,false,false
 music(0)
end

function st.title:update()
 upd_starfield()
 self.cam_y=min(0,self.cam_y+1)
 if self.faded_in then
  if self.cam_y>=0 then
   if self.menu then
    if jewel.dx==0 and jewel.dy==0 then
     if (btnp(⬇️) or btnp(⬆️)) jewel.dy=btnp(⬇️) and .125 or -.125
     local fy=jewel.y+jewel.dy*8
     if (fy!=mid(0,fy,2)) jewel.dy=0
     if btnf(❎) then
      if jewel.y==0 then
       local game=load_egypt(hex(peek(0x5e00),2)..hex(peek(0x5e01),2)..hex(peek(0x5e02),2))
       if game=="invalid" then
        sfx(56)
       else
        st.map.difficulty,st.map.floor,st.map.rooms,st.game.magic=game.difficulty,game.floor,game.rooms,game.magic
        self:load()
       end
      elseif jewel.y==1 then
       jewel.y,self.menu,self.newgame=0,false,true
      elseif jewel.y==2 then
       jewel.x,jewel.y,self.menu,self.password,self.pw,self.pw_curx,self.pw_cury,self.pw_iv_tmr=0,0,false,true,"",0,0,0
      end
     end
    else
     move_jewel()
    end
   elseif self.newgame then
    if jewel.dx==0 and jewel.dy==0 then
     if (btnp(⬇️) or btnp(⬆️)) jewel.dy=btnp(⬇️) and .125 or -.125
     local fy=jewel.y+jewel.dy*8
     if (fy!=mid(0,fy,2)) jewel.dy=0
     if btnf(❎) then
      st.map.difficulty,st.map.floor,st.map.rooms,st.game.magic=-jewel.y%3,0,0,jewel.y==2 and {0,0,0} or {2,2,2}
      save_egypt(true)
      self:load()
     elseif btnf(🅾️) then
      self.newgame,self.menu=false,true
     end
    else
     move_jewel()
    end
   elseif self.password then
    self.pw_iv_tmr=max(0,self.pw_iv_tmr-1)
    if btnp(➡️) or btnp(⬅️) then
     self.pw_curx=mid(0,3,self.pw_curx+(btnp(➡️) and 1 or -1)*(self.pw_cury==4 and 2 or 1))
    elseif btnp(⬇️) or btnp(⬆️) then
     self.pw_cury=mid(0,4,self.pw_cury+(btnp(⬇️) and 1 or -1))
    end
    if (self.pw_cury==4) self.pw_curx=2*flr(self.pw_curx/2)
    if jewel.dx==0 and jewel.dy==0 then
     if btnf(❎) then
      if self.pw_cury<=3 then
       self.pw=sub(self.pw..hex(self.pw_cury*4+self.pw_curx),1,6)
       if (#self.pw<6) jewel.dx=.125
      else
       if self.pw_curx==0 then
        if (#self.pw<6) jewel.dx=-.125
        self.pw=sub(self.pw,1,-2)
       else
        local game=load_egypt(self.pw)
        if game=="invalid" then
         sfx(56)
         self.pw_iv_tmr=self.pw_iv_time
        else
         st.map.difficulty,st.map.floor,st.map.rooms,st.game.magic=game.difficulty,game.floor,game.rooms,game.magic
         save_egypt(true)
         self:load()
        end
       end
      end
     elseif btnf(🅾️) then
      self.password=false
      self.menu=true
      jewel.x,jewel.y=0,0
     end
    else
     move_jewel()
    end
   else
    if (btnf(❎)) self.menu=true
   end
  end
 else
  fade-=fade_spd
  if (fade<=0) fade=0 self.faded_in=true
 end
end

function st.title:load()
 music(-1,1000)
 fade_n2b()
 if st.map.floor==0 and st.map.rooms==0 then
  sw_st(st.cutscene,1)
 elseif st.map.floor==18 and count_bits(st.map.rooms)>0 then
  st.map.lvl=count_bits(st.map.rooms)
  sw_st(st.game,108+st.map.lvl)
 else
  sw_st(st.map)
 end
end

function st.title:draw()
 cls(c(0))
 camera(0,self.cam_y)
 draw_starfield()
 bspr(bsprs.egypt,16,16)
 pal(1,c(0))
 map(76,0,0,0,16,16)
 if self.menu then
  box(40,56,48,24)
  print("continue",53,58,7)
  print("new game",53,66,7)
  print("password",53,74,7)
  draw_jewel(5.5,7)
 elseif self.newgame then
  box(40,56,48,24)
  print("easy",53,58,7)
  print("normal",53,66,7)
  print("hard",53,74,7)
  draw_jewel(5.5,7)
 elseif self.password then
  box(38,56,52,60)
  for i=1,#self.pw do
   print(sub(self.pw,i,i),42+(i-1)*8,68,7)
  end
  if (self.pw_iv_tmr>0) print("bad password!",39,74,15)
  rectfill(self.pw_curx*8+48,self.pw_cury*6+79,self.pw_curx*8+54+(self.pw_cury==4 and 8 or 0),self.pw_cury*6+85,4)
  print([[
0 1 2 3
4 5 6 7
8 9 a b
c d e f]],50,80,15)
  print("⬅️",52,104,15)
  print("end",66,104,15)
  draw_jewel(4.875,7.25)
 else
  print_outline("press ❎ to begin",30,55,time()%1<.5 and 12 or 4,0)
 end
end
-->8
--opening screen state

st.opening={}

function st.opening:enter()
 self.wait=90
 menuitem(1,"view ending",function()
  menuitem(1)
  fade_n2w()
  st.map.difficulty=1
  sw_st(st.cutscene,3)
 end)
 fade_b2n()
end

function st.opening:update()
 self.wait-=1
 if self.wait==80 then
  sfx(57)
 elseif self.wait<=0 then
  menuitem(1)
  fade_n2b()
  sw_st(st.title)
 end
end

function st.opening:draw()
 cls(c(0))
 print("made with ♥ for",32,44,7)
 print("gbjam",52,75,7)
 print("7",72,75,12)
 bspr(bsprs.gbjam,56,52)
end

--credits state

st.credits={
 text_spd=2.5,
 text_wait=130,
 text={
  {"programmer","josiah winslow","winslowjosiah.itch.io"},
  {"translator","tsukinara","reddit.com/u/tsukinara"},
  {"sound designer","tesselode","tesselode.itch.io"},
  {"composer","senatormyth","twitter.com/senatormyth"},
  {"graphics director","jusiv","jusiv.itch.io"},
  {"general feedback","marbles-box","lexaloffle.com/bbs/?uid=27098"},
  {"special thanks","retroshark","retroshark.itch.io"},
  {"special thanks","7soul","7soul.itch.io"},
  {"made for gbjam7","play the other games at","itch.io/jam/gbjam-7/entries"},
 },
}

function st.credits:enter()
 init_starfield()
 self.text_x,self.text_i,self.text_waited,self.faded_in=128,1,self.text_wait,false
 if (st.map.difficulty!=1) add(self.text,{"now beat the sphinx's puzzles","by playing on hard mode","good luck!",})
 music(19)
end

function st.credits:update()
 upd_starfield()
 if self.faded_in then
  if self.text_x<=-128 then
   self.text_x=128
   self.text_i+=1
  elseif self.text_x<0 then
   self.text_x-=self.text_spd
  elseif self.text_x==0 then
   if (self.text_i<#self.text) self.text_waited-=1
   if (self.text_waited<=0) self.text_x-=self.text_spd
  else
   self.text_x-=self.text_spd
   if (self.text_x<=0) self.text_x,self.text_waited=0,self.text_wait
  end
 else
  fade-=fade_spd
  if (fade<=0) fade,self.faded_in=0,true
 end
end

function st.credits:draw()
 cls(c(0))
 camera()
 draw_starfield()
 spr(self.text_i%10,flr(self.text_x+60),47)
 for i=1,3 do
  print_center(self.text[self.text_i][i],self.text_x,i*8+49,i*6-6,6-2*i)
 end
end