-- kittenm4stersoft defrag
-- by kittenm4ster

-- global constants
debug = false
noseekdelay = false
fps = 30
numblocks = 768
max_seek_frames = 15
gridw = 40
cell_w = 2
cell_h = 4
gridw_px = (gridw * (cell_w + 1)) - 1
gridx_px = 64 - (gridw_px / 2)
gridy_px = 4
window_center_x = 63
sfx_len = 68
guitar_solo_addr = 0x3200 + (sfx_len * 14)
guitar_solo_len = (sfx_len * 14)

cell_state_color = {}
cell_state_color[0] = 13 -- no data
cell_state_color[1] =  6 -- data
cell_state_color[2] = 11 -- read
cell_state_color[3] =  8 -- write

shadow_palette_map = {}
shadow_palette_map[0] = 0
shadow_palette_map[1] = 0
shadow_palette_map[6] = 1
shadow_palette_map[13] = 1
shadow_palette_map[9] = 1

function _init()
  set_screensaver_mode(false)
  set_music_mode(false)
  init()
end


function init()
  if debug then
    printh('\n--init--')
    local seed = rnd_int(-32767, 32767)
    printh('seed: ' .. seed)
    srand(seed)
  end

  -- disk
  disk = {
    blocks = {},
    head = 1
  }

  -- file system
  fat = {
    files = {},
    numusedblocks = 0
  }

  -- cluster cache
  block_map = {}

  -- gui
  grid = {}
  gridprog = 0
  blocksdefragged = 0
  elapsed = {
    h = 0,
    m = 0,
    s = 0
  }

  init_blocks()
  init_grid()

  local fragamt = biased_rnd(5, 50, 2)
  quickmode = true
  create_fragmented_disk(fragamt)
  quickmode = false

  if debug then
    -- verify all initial files
    for i, file in pairs(fat.files) do
      verify_file(file)
    end
  end

  -- windowstate:
  -- 0 closed
  -- 1 opening - small
  -- 2 opening - medium
  -- 3 fully open
  windowstate = 0

  runner = cocreate(run_coroutine)

  stage = 'analyzing'
  progress = 0
end

function _update()
  fast_sax_hack()
  guitar_solo_swap()
  pan_flute_reverb()

  if costatus(runner) == 'dead' and screensaver then
    init()
  end

  if costatus(runner) ~= 'dead' then
    assert(coresume(runner))
  end

  if stage == 'defragmenting' or stage == 'done' then
    progress = flr((blocksdefragged / fat.numusedblocks) * 100)

    if stage ~= 'done' then
      progress = min(progress, 99)
    end
  end

  if stage == 'defragmenting' then
    update_elapsed_time()
  end
end

function update_elapsed_time()
  local sec = stat(95)

  if sec ~= elapsed.prevsec then
    if elapsed.prevsec then
      increment_elapsed_time(elapsed)
    end

    elapsed.prevsec = sec
  end
end

function increment_elapsed_time(e)
  e.s += 1
  if e.s == 60 then
    e.s = 0
    e.m += 1
  end

  if e.m == 60 then
    e.m = 0
    e.h += 1
  end
end

function prompt()
  repeat
    yield()
  until btnp(4) or screensaver
end

function run_coroutine()
  stage = 'analyzing'
  analyze()
  progress = 0

  if analysis.blocksfree == 0 then
    if not screensaver then
      stage = 'no space'
      open_window()
      prompt()
      quit_if_not_screensaver()
    end

    return
  end

  if not screensaver then
    stage = 'ready'
    open_window()
    prompt()
    close_window()
  end

  while true do
    if debug then
      printh('run: defragmenting')
    end

    stage = 'defragmenting'
    progress = 0
    defrag_and_compact()

    if any_files_are_fragmented() then
      -- enable slower "last resort" defrag strategy
      if debug then
        printh("run: enabling last resort defag strategy and restarting")
      end
      allow_last_resort_defrag = true
    else
      break
    end
  end

  stage = 'done'

  if debug then
    printh(
      'elapsed time: ' ..
      lpad2(elapsed.h) .. ':' .. lpad2(elapsed.m) .. ':' .. lpad2(elapsed.s)
    )
  end

  if debug then
    progress = flr((blocksdefragged / fat.numusedblocks) * 100)
    assert(progress == 100, 'progress not at 100!')
  end

  if screensaver then
    sleep(fps * 6)
  else
    open_window()
    prompt()
    close_window()
    quit_if_not_screensaver()
  end
end

-- screensaver mode could have been activated during a prompt, so we
-- need to check again before calling stop()
function quit_if_not_screensaver()
  if not screensaver then
    stop()
  end
end

function analyze()
  analysis = {
    numfragmented = 0,
    numfragments = 0
  }
  block_map = {}
  progress = 0

  for i, file in pairs(fat.files) do
    quickmode = true
    local blocks = find_blocks(file)
    quickmode = false

    for _, block in pairs(blocks) do
      block_map[block.addr] = block
    end

    local fragcount = count_fragments(file)
    analysis.numfragments += count_fragments(file)
    if fragcount > 0 then
      file.isfragmented = true
      analysis.numfragmented += 1
    end

    progress = flr((i / #fat.files) * 100)
    yield()
  end

  analysis.numfragments = get_total_fragments()
  analysis.fragpercent = fmt_percent(analysis.numfragments / fat.numusedblocks)
  analysis.blocksfree = numblocks - fat.numusedblocks

  if debug then
    printh('actual file count: ' .. #fat.files)
    for k, v in pairs(analysis) do
      printh(k .. ': ' .. v)
    end

    local diskusage = flr((fat.numusedblocks / numblocks) * 100)
    printh('usage: ' .. diskusage .. '%')
  end
end

function ciel(n)
  return -flr(-n)
end

function fmt_percent(n)
  return ciel(n * 100)
end

function get_total_fragments()
  local count = 0

  for _, file in pairs(fat.files) do
    count += count_fragments(file)
  end

  return count
end

function verify_file(file)
  if not debug then
    return
  end

  quickmode = true
  local blocks = find_blocks(file)
  local id = '[file ' .. file.i .. '] '
  quickmode = false

  assert(file.addr >= 1 and file.addr <= numblocks, id .. 'addr out of bounds')

  assert(
    (#blocks == file.len),
    id .. 'len ' .. file.len .. ' but found ' .. #blocks .. ' blocks')

  for i = 1, #blocks do
    local block = blocks[i]
    local cached = block_map[block.addr]

    if #block_map > 0 then
      assert(cached, id .. 'no cached version of block ' .. i)
      assert(cached.file == file, id .. 'wrong file pointer')

      for k, v in pairs(cached) do
        assert(block[k] == v, id .. 'cache mismatch on ' .. k)
      end
    end
  end

  assert(blocks[#blocks].nxt == -1, id .. 'last block not terminated')
end

function _draw()
  cls(1)
  draw_grid()
  draw_status_area()

  if stage == 'ready' then
    draw_start_prompt()
  elseif stage == 'done' then
    draw_end_prompt()
  elseif stage == 'no space' then
    draw_no_space_prompt()
  end
end

function draw_status_area()
  color(7)

  print('status:', gridx_px, 107)
  rprint(stage, gridx_px + gridw_px - 1, 107)

  print('progress:', gridx_px, 113)
  rprint(progress .. '%', gridx_px + gridw_px - 1, 113)

  draw_progress_bar(gridx_px, 119, gridw_px, 5, progress)
end

function plural_s(n)
  return (n == 1 and '' or 's')
end

function space(n)
  local s = ''
  for i = 1, n do
    s = s .. ' '
  end
  return s
end

function draw_start_prompt()
  local lines

  local pad1 = (#tostr(analysis.numfragmented) == 1 and ' ' or '')

  local n = 4 - #tostr(analysis.numfragments)
  local pad2 = space(n)

  local n = #tostr(analysis.blocksfree)
  n = max(2, n)
  local pad3 = space(n)

  lines = {
    pad1 .. analysis.numfragmented .. '/' .. #fat.files .. ' files fragmented',
    pad2 .. analysis.numfragments .. ' total fragments',
    analysis.blocksfree .. ' block' .. plural_s(analysis.blocksfree) ..
      ' free' .. pad3,
    '',
    'disk is ' .. analysis.fragpercent .. '% fragmented',
    '',
    'press 🅾️ to optimize'
  }

  draw_window(lines)
end

function draw_end_prompt()
  local lines

  lines = {
    'optimization complete',
    '',
    'elapsed time:',
    lpad2(elapsed.h) .. ':' .. lpad2(elapsed.m) .. ':' .. lpad2(elapsed.s),
    '',
    'press 🅾️ to exit'
  }

  draw_window(lines)
end

function draw_no_space_prompt()
  local lines

  lines = {
    '0 blocks free',
    'cannot defragment disk',
    '',
    'press 🅾️ to exit'
  }

  draw_window(lines)
end

function draw_shadow(x1, y1, x2, y2)
  for y = y1, y2 do
    for x = x1, x2 do
      local c = pget(x, y)

      c = shadow_palette_map[c]
      pset(x, y, c)
    end
  end
end

function draw_window(lines)
  local borderw = 1
  local paddingw = 2
  local shadowoffset = 4
  local w = 96
  local h = (#lines * 6) + paddingw

  if windowstate == 0 then
    return
  elseif windowstate < 3 then
    w /= (4 - windowstate)
    h /= (4 - windowstate)
  end

  local x1 = window_center_x - flr(w / 2)
  local y1 = window_center_x - (h / 2) - shadowoffset
  local x2 = window_center_x + flr(w / 2)
  local y2 = window_center_x + (h / 2) - shadowoffset

  -- right
  draw_shadow(
    x2 + borderw + 1,
    y1 - borderw + shadowoffset,
    x2 + borderw + shadowoffset,
    y2 + borderw + shadowoffset)

  -- bottom
  draw_shadow(
    x1 - borderw + shadowoffset,
    y2 + borderw + 1,
    x2 + borderw,
    y2 + borderw + shadowoffset)

  rectfill(x1 - borderw, y1 - borderw, x2 + borderw, y2 + borderw, 7)
  rectfill(x1, y1, x2, y2, 12)

  if windowstate == 3 then
    -- draw the lines of text
    color(7)
    for i, line in pairs(lines) do
      cprint(line, window_center_x, y1 + paddingw + ((i - 1) * 6))
    end
  end
end

function determine_grid_progress(gridprog)
  local i = gridprog + 1

  while i <= numblocks do
    local block = block_map[i]

    if block and block.file.isdefragged then
      gridprog = i
      i += 1
    else
      break
    end
  end

  return gridprog
end

function rprint(s, x, y)
  print(s, x - (#s * 4) + 2, y)
end

function draw_grid()
  local x, y = gridx_px, gridy_px

  for i, cell in pairs(grid) do
    local state = cell.state
    local c = cell_state_color[state]

    local x1 = x
    local y1 = y
    local x2 = x + cell_w - 1
    local y2 = y + cell_h - 1

    -- highlight the current file
    if state == 1 then
      local block = block_map[i]

      if block and block.file == currentfile then
        if block.fbi == 1 then
          c = 12
        else
          c = 7
        end
      end
    end

    if i <= gridprog then
      c = 9
    end

    -- draw the cell with a color based on state
    rectfill(x1, y1, x2, y2, c)

    x += cell_w + 1
    if i % gridw == 0 then
      x = gridx_px
      y += cell_h + 1
    end
  end
  fillp()
end

function init_blocks()
  for i = 1, numblocks do
    add(disk.blocks, 0)
  end
end

function init_grid()
  for i = 1, numblocks do
    local cell = {
      state = 0
    }

    add(grid, cell)
  end
end

function should_fragment(fragamt)
  if rnd_int(1, 100) > 100 - fragamt then
    return true
  end

  return false
end

function biased_rnd(min, max, p)
  return min + ((max - min) * (rnd() ^ p))
end

function add_file(addr)
  local filebuilder = {
    file = {
      addr = addr,
      len = 1,
      i = #fat.files + 1,
    },
    prevaddr = addr
  }

  add(fat.files, filebuilder.file)
  write(filebuilder.file.addr, -1)

  return filebuilder
end

-- @param fragamt number from 0-100 which indicates how likely files will get
-- fragmented as they are added to the disk
function create_fragmented_disk(fragamt)
  local start = 1
  local numfiles = rnd_int(10, 99)
  local maxusage = .90

  if debug then
    printh('fragamt: ' .. fragamt)
    printh('numfiles: ' .. numfiles)
  end

  for i = 1, numfiles do
    if i > 1 then
      if i > numfiles / 4 and should_fragment(fragamt) then
        start = find_next_free_addr_nocache(rnd_int(1, numblocks))
      else
        start = find_next_free_addr_nocache(start + 1)
      end
    end

    -- if there are no more free blocks
    if not start then
      return
    end

    local filebuilder
    if (fat.numusedblocks + 1) / numblocks <= maxusage then
      -- create a file
      filebuilder = add_file(start)
    else
      if debug then
        printh('stopping files early to limit disk usage')
      end
      return
    end

    -- add some additional blocks to the file
    local len = rnd_int(1, 20)
    if rnd_int(1, 100) == 1 then
      len *= 2
    end
    local addr = start
    for j = 1, len do
      -- choose the next block address
      if should_fragment(fragamt) then
        addr = find_next_free_addr_nocache(rnd_int(1, numblocks))
      else
        addr = find_next_free_addr_nocache(addr + 1)
      end

      -- if there are no more free blocks
      if not addr then
        return
      end

      if (fat.numusedblocks + 1) / numblocks <= maxusage then
        -- add another block to this file
        append_block(filebuilder, addr)
      else
        if debug then
          printh('stopping files early to limit disk usage')
        end

        -- stop adding files
        return
      end
    end
  end
end

function append_block(filebuilder, addr)
  disk.blocks[filebuilder.prevaddr] = addr
  write(addr)

  filebuilder.file.len += 1
  filebuilder.prevaddr = addr
end

function is_free(addr)
  return (addr >= 1 and addr <= numblocks and block_map[addr] == nil)
end

function try_to_fill_gap(gap)
  local success = false
  local movedany = false
  local nextaddr

  -- find the best file to to move into this gap
  local best = {file = nil, slack = 32767}
  for _, file in pairs(fat.files) do
    if file.len <= gap.len then
      local slack = abs(file.len - gap.len)

      if file.addr > gap.addr and abs(file.len - gap.len) < best.slack then
        best.file = file
        best.slack = slack

        -- if this file is a perfect fit
        if file.len == gap.len then
          -- don't look at any more files
          break
        end
      end
    end
  end

  if best.file then
    -- move the file into this gap
    move_file(best.file, gap.addr)

    movedany = true
    success = true
    nextaddr = gap.addr + best.file.len
  else
    -- find what the next file is
    local block = block_map[gap.addr + gap.len]

    verify_file(block.file)

    if is_fragmented(block.file) then
      nextaddr = gap.addr + gap.len
    else
      -- move the next file backwards to this gap
      move_file(block.file, gap.addr)

      movedany = true
      success = true
      nextaddr = gap.addr + block.file.len
    end
  end

  return success, nextaddr
end

function draw_progress_bar(x, y, w, h, progress)
  local x1, y1 = x, y
  local x2, y2 = x + w - 1, y + h - 1
  local barx2 = x + ((w * progress) / 100) - 1
  barx2 = max(x, barx2)

  fillp(0b0101101001011010.1)
  rectfill(x1, y1, x2, y2, 13)
  fillp()

  if progress > 0 then
    rectfill(x1, y1, barx2, y2, 10)
  end
end

function clear_path(addr, len)
  local illegaldests = {}
  for i = addr, addr + len - 1 do
    add(illegaldests, i)
  end

  for i = 1, len do
    if not is_free(addr) then
      local dest = find_contiguous_space(1, 1, illegaldests)
      if dest then
        move(addr, dest)
      else
        assert(false, 'clear_path: no free space left!')
      end
    end

    addr += 1
  end
end

function any_files_are_fragmented()
  for _, file in pairs(fat.files) do
    if is_fragmented(file) then
      return true
    end
  end
end

function defrag_and_compact()
  local addr = 1
  gridprog = 0

  while addr <= numblocks and gridprog < fat.numusedblocks do
    local block = block_map[addr]
    local movedany = false
    local nextaddr

    currentfile = nil

    if block then
      movedany = defrag_file(block.file)

      if not movedany then
        -- find the next block that is not part of this file
        nextaddr = addr
        local b = block_map[nextaddr]
        while b and b.file == block.file and nextaddr < numblocks do
          nextaddr += 1
          b = block_map[nextaddr]
        end

        -- if we didn't actually get out of the file before exiting the loop
        -- above
        if b and b.file == block.file then
          nextaddr = nil
        end
      end
    else
      local gap = find_next_gap(addr)

      if gap then
        movedany, nextaddr = try_to_fill_gap(gap)
      end
    end

    gridprog = determine_grid_progress(gridprog)

    if movedany then
      addr = gridprog + 1
    elseif nextaddr and nextaddr > addr then
      addr = nextaddr
    else
      addr += 1
    end

    addr = max(gridprog + 1, addr)
  end
end

function defrag_file(file)
  local success = false
  local movedany = false
  local i = file.i

  verify_file(file)

  local lastcontigblock = is_fragmented(file)

  -- if the file is fragmented
  if lastcontigblock then
    local freedest = find_contig_space_for_file(file)

    if freedest then
      move_file(file, freedest, true)
      success = true
      movedany = true
    elseif can_clear_path(file, lastcontigblock) then
      local start = lastcontigblock.addr + 1

      clear_path(start, file.len - lastcontigblock.fbi)
      verify_file(file)
      move_file(file, file.addr)
      success = true
      movedany = true
    else
      local dest = find_contiguous_space(file.len, gridprog)

      if dest then
        move_file(file, dest)
        success = true
      elseif allow_last_resort_defrag then
        if last_resort_defrag(file, lastcontigblock) then
          movedany = true
        end
      end
    end
  else
    if not file.isdefragged then
      blocksdefragged += file.len
    end
    success = true
  end

  if success then
    file.isdefragged = true
    file.isfragmented = false

    assert(
      is_fragmented(file) == false,
      'file ' .. i .. ' is still fragmented!')
  end

  verify_file(file)

  return movedany
end

function file_is_mostly_contiguous(file, lastcontigblock)
  return (lastcontigblock.fbi > file.len / 2)
end

-- this search is non-exhaustive, intended for efficiency/economy of movement,
-- e.g. it will only return true if the contiguous part of the file at the
-- begining is >= half of the file's length; it's assumed that in the opposite
-- case it's better to move the file somewhere else.
function can_clear_path(file, lastcontigblock)
  if (file.addr + file.len - 1 > numblocks or
      not file_is_mostly_contiguous(file, lastcontigblock)) then
    return false
  end

  local start = lastcontigblock.addr + 1
  local len = file.len - lastcontigblock.fbi

  -- if there are not enough free blocks to clear the whole path at once
  if analysis.blocksfree < len then
    return false
  end

  -- check that all blocks in the path are one of the following:
  --   * unoccupied
  --   * part of a file which is fragmented
  --   * part of the current file
  for addr = start, start + len - 1 do
    local block = block_map[addr]
    local okay = false

    if block == nil or is_fragmented(block.file) or block.file == file then
      okay = true
    end

    if not okay then
      return false
    end
  end

  -- no blocks failed above
  return true
end

-- find the best (closest) gap, either before or after the given address
function find_closest_gap(addr)
  local prevgap = find_prev_gap(addr + 1, true)
  local nextgap = find_next_gap(addr + 1, true)

  -- if one is null, return the non-null gap
  if not prevgap then
    return nextgap
  elseif not nextgap then
    return prevgap
  end

  -- return the closer gap
  prevdist = addr - (prevgap.addr + prevgap.len - 1)
  nextdist = nextgap.addr - addr
  if prevdist <= nextdist then
    return prevgap
  else
    return nextgap
  end
end

-- move (not actually "make" ex nihilo) the nearest gap to the specified
-- address, attempting to make a gap of the desired length, but only
-- guaranteeing a gap length of at least 1
function make_gap(addr, desiredlen)
  local gap = find_closest_gap(addr)
  local delta = gap.len
  assert(gap, 'no gap found')

  if gap.addr < addr then
    -- shift everything to the left
    for src = gap.addr + gap.len, addr - 1 do
      move(src, src - delta)
    end
  else
    -- shift blocks forward so that the gap is brought backwards to where we
    -- need it

    -- don't open a bigger gap on the right than necessary (we only care about
    -- limiting this when moving to the right, since the ultimate goal is to
    -- compact everything to the left)
    if delta > desiredlen then
      delta = desiredlen
    end

    for src = gap.addr - 1, addr, -1 do
      move(src, src + delta)
    end
  end
end

-- defrag a file in a slow way (thus it should be used only as a last resort)
-- by moving gaps over to where we need them to be. this method only requires
-- one free block, but will work faster with more free blocks.
-- returns true if any blocks were moved
function last_resort_defrag(file, lastcontigblock)
  assert(is_fragmented(file), 'hey; file ' .. file.i .. ' is not fragmented')
  assert(analysis.blocksfree > 0)

  local newstart = file.addr

  -- determine where the start block of the file should be
  if not file_is_mostly_contiguous(file, lastcontigblock) then
    local earliest = find_earliest_block(file)

    -- if the file's earliest block is not the file's start block
    if earliest.addr ~= file.addr then
      newstart = earliest.addr
    end
  else
    if debug then
      printh('in last_resort_defrag, decided not to move start of mostly-contig file')
    end
  end

  -- adjust the starting address backward if there are free blocks
  while is_free(newstart - 1) do
    newstart -= 1
  end

  -- make sure we don't try to move the file outside the bounds of the disk
  newstart = min(numblocks - file.len - 1, newstart)

  return move_file_with_bulldoze(file, newstart)
end

function move_file_with_bulldoze(file, dest)
  local movedany = false
  local fbi = 1
  currentfile = file

  repeat
    local start = dest + fbi - 1
    local finish = dest + file.len - 1

    local illegaldests = {}
    for i = start, finish do
      add(illegaldests, i)
    end

    -- addr is the spot we are trying to clear, and is the destination for the
    -- next block in the file
    for addr = start, finish do
      local block = block_map[addr]
      local alreadycorrect = (block and block.file == file and block.fbi == fbi)

      -- if there is a block here, and it's not already the correct one
      if block and not alreadycorrect then
        -- if this block is part of a fragmented file
        if is_fragmented(block.file) then
          local dst

          -- if the block is part of this file
          if block.file == file then
            local properdst = dest + block.fbi - 1
            -- if the block's proper spot is free
            if is_free(properdst) then
              dst = properdst
            end
          end

          if not dst then
            dst = find_free_block_backwards({addr})
          end

          move(block.addr, dst)
          movedany = true
        else
          -- try to find a free space to move the file out of the way
          local dst = find_contiguous_space(block.file.len, 1, illegaldests)
          if dst then
            move_file(block.file, dst)
            currentfile = file -- recover the current file highlight
            movedany = true
          else
            local spaceneeded = file.addr + file.len - addr
            local oldfileaddr = file.addr
            make_gap(addr, spaceneeded)
            movedany = true

            -- if make_gap() caused the file to move
            local delta = file.addr - oldfileaddr
            if delta ~= 0 then
              dest += delta
              -- exit the for loop so we can reorient to the file's new
              -- position
              return
            end
          end
        end
      end

      -- move the block into the correct position
      local src = get_file_block(file, fbi).addr
      if move(src, addr) then
        movedany = true
      end

      fbi += 1
    end
  until fbi > file.len

  return movedany
end

function find_free_block_backwards(illegaldests)
  for addr = numblocks, 1, -1 do
    local legal = true
    if illegaldests then
      if value_in_table(addr, illegaldests) then
        legal = false
      end
    end

    if legal and is_free(addr) then
      return addr
    end
  end
end

function move(src, dest)
  if src == dest then
    return false
  end

  -- move the block info cache before write() so that the nxt address gets
  -- updated by write()
  block_map[dest] = shallow_copy(block_map[src])
  block_map[dest].addr = dest

  write(dest, read(src))
  delete(src)

  local block = block_map[dest]
  if block.prev == -1 then
    -- update the file address
    block.file.addr = dest
  end
  if block.prev ~= -1 then
    -- update the previous block's "nxt" link to this block
    local prevblock = block_map[block.prev]
    write(prevblock.addr, block.addr)
  end
  if block.nxt ~= -1 then
    -- update the next block's "prev" link to this block
    local nextblock = block_map[block.nxt]
    nextblock.prev = block.addr
  end

  return true
end

function move_file(file, dest, clearpath)
  verify_file(file)

  local block = block_map[file.addr]
  currentfile = file

  for i = 1, file.len do
    local src = block.addr

    if src ~= dest then
      if clearpath and not is_free(dest) then
        -- move this block out of the way
        local dest2 = find_contiguous_space(1, 1)--, illegaldests)
        move(dest, dest2)
      end

      move(src, dest)
    end

    -- moving a file via this method will always defrag it, so record that
    -- progress
    if not file.isdefragged then
      blocksdefragged += 1
    end

    if i == 1 then
      -- update the address of the file's first block since it has now changed
      file.addr = dest
    end

    dest += 1
    if i < file.len then
      block = block_map[block.nxt]
    end
  end

  assert(not is_fragmented(file), 'move_file() did not defragment file!')
  file.isfragmented = false
  file.isdefragged = true

  verify_file(file)
end

function find_next_free_addr_nocache(start)
  local i = start
  local checkedcount = 0

  i = max(1, start)
  i = min(start, numblocks)

  while checkedcount < numblocks do
    if disk.blocks[i] == 0 then
      return i
    end

    i += 1
    checkedcount += 1

    if i > numblocks then
      i = 1
    end
  end

  assert(false, 'no more free blocks!')
end

function find_next_gap(addr, includelast)
  local start = nil

  -- go backwards to find the first unoccupied block, in case we are already
  -- inside a gap
  while is_free(addr - 1) and addr > 1 do
    addr -= 1
  end

  for i = addr, numblocks do
    if is_free(i) then
      if not start then
        start = i
      end
    elseif start then
      return {
        addr = start,
        len = i - start
      }
    end
  end

  if includelast and start then
    return {
      addr = start,
      len = numblocks - start + 1
    }
  end
end

function find_prev_gap(addr, includelast)
  local finish = nil

  -- go forward to find the last block in the gap where we are, in case we are
  -- already inside a gap
  while is_free(addr + 1) and addr < numblocks do
    addr += 1
  end

  for i = addr, 1, -1 do
    if is_free(i) then
      if not finish then
        finish = i
      end
    elseif finish then
      return {
        addr = i + 1,
        len = finish - i
      }
    end
  end

  if includelast and finish then
    return {
      addr = 1,
      len = finish
    }
  end
end

function sleep(frames)
  for i = 1, frames do
    yield()
  end
end

function find_earliest_block(file)
  local earliestblock = block_map[file.addr]
  local addr = file.addr
  repeat
    local block = block_map[addr]
    local nxt = block.nxt

    if block.addr < earliestblock.addr then
      earliestblock = block
    end

    addr = nxt
  until addr == -1

  return earliestblock
end

-- find contiguous free space for the file at or before its current earliest
-- block's address, allowing for overlapping some of the same blocks that are
-- currently used by this file, since we can move them out of the way
function find_contig_space_for_file(file)
  local earliestblock = find_earliest_block(file)

  for start = 1, earliestblock.addr do
    local finish = start + file.len - 1

    if finish <= numblocks then
      local okay = true

      for addr = start, finish do
        local infile = false
        local block = block_map[addr]
        if block and block.file == file then
          infile = true
        end

        if not (is_free(addr) or infile) then
          okay = false
          break
        end
      end

      if okay then
        return start
      end
    end
  end
end

function find_contiguous_space(len, start, illegaldests)
  local start = start or 1
  start = max(1, start)

  if len == 1 then
    for addr = start, numblocks do
      local legal = true
      if illegaldests then
        if value_in_table(addr, illegaldests) then
          legal = false
        end
      end

      if legal and is_free(addr) then
        return addr
      end
    end

    return
  end

  local addr = start
  while addr <= numblocks do
    local legal = true
    if illegaldests then
      if value_in_table(addr, illegaldests) then
        legal = false
      end
    end

    if is_free(addr) and legal then
      local left = addr - (len - 1)

      if left >= 1 then
        local vacant = true

        -- search backwards for contiguous free blocks
        for j = addr - 1, left, -1 do
          if not is_free(j) then
            vacant = false
            addr = j + 1
            break
          end
        end

        if vacant then
          return left
        end
      end
    end

    addr += (len - 1)
  end
end

function seek(addr)
  local dist = abs(addr - disk.head)

  if dist > 1 then
    local frames = (dist * max_seek_frames) / numblocks

    -- add some randomness
    frames += rnd_int(-1, 1)

    if not noseekdelay then
      sleep(frames)
    end
  end

  disk.head = addr
end

function read(addr)
  if not quickmode then
    seek(addr)
    grid[addr].state = 2
    sleep(rnd_sleep_rw())
    grid[addr].state = 1
  end

  return disk.blocks[addr]
end

function delete(addr)
  grid[addr].state = 0
  disk.blocks[addr] = 0

  -- update numusedblocks
  fat.numusedblocks -= 1

  -- keep the cached block map up to date
  block_map[addr] = nil
end

function rnd_sleep_rw()
  if rnd_int(1, 250) == 1 then
    return 2
  else
    return 1
  end
end

function write(addr, nxt)
  if quickmode then
    grid[addr].state = 1
  else
    seek(addr)
    grid[addr].state = 3
    sleep(rnd_sleep_rw())
    grid[addr].state = 1
  end

  local value = nxt or -1

  -- update numusedblocks
  if disk.blocks[addr] == 0 then
    fat.numusedblocks += 1
  end

  -- write the value to disk
  disk.blocks[addr] = value

  if block_map[addr] then
    -- keep the cached map up to date
    block_map[addr].nxt = value
  end
end

function find_blocks(file)
  local addr = file.addr
  local blocks = {}
  local prev
  local i = 1

  repeat
    local nxt = read(addr)
    local block = {
      file = file,
      fbi = i, -- file block index
      addr = addr,
      prev = prev or -1,
      nxt = nxt
    }

    add(blocks, block)

    prev = addr
    addr = nxt
    assert(i <= file.len, 'blocks exceed reported file len')
    i += 1
  until addr == -1

  return blocks
end

function get_file_block(file, fbi)
  local addr = file.addr

  repeat
    local block = block_map[addr]
    local nxt = block.nxt

    if block.fbi == fbi then
      return block
    end

    addr = nxt
  until addr == -1
end

function count_fragments(file)
  local addr = file.addr
  local count = 0

  repeat
    local block = block_map[addr]
    local nxt = block.nxt

    if nxt ~= addr + 1 and nxt ~= -1 then
      count += 1
    end

    addr = nxt
  until addr == -1

  return count
end

function is_fragmented(file)
  local addr = file.addr

  repeat
    local block = block_map[addr]
    local nxt = block.nxt

    assert(
      nxt > 0 or nxt == -1,
      'block at ' .. block.addr .. ' has bad nxt pointer: ' .. tostr(nxt))

    if nxt ~= addr + 1 and nxt ~= -1 then
      -- return the last contiguous block
      return block
    end

    addr = nxt
  until addr == -1

  return false
end

function open_window()
  sfx(3, 2, 24, 3)
  for ws = 1, 3 do
    windowstate = ws
    sleep(1)
  end
end

function close_window()
  windowstate = 0
  sleep(1)
end

function set_screensaver_mode(on)
  screensaver = on

  if on then
    menuitem(2, 'stop screensaver',
    function() set_screensaver_mode(false) end)
  else
    menuitem(2, 'screensaver mode',
    function() set_screensaver_mode(true) end)
  end
end

function set_music_mode(on)
  if on then
    set_reverb(3, true) -- enable reverb on 4th (lead) channel
    music(0)
    menuitem(1, 'stop music',
    function() set_music_mode(false) end)
  else
    set_reverb(2, false)
    set_reverb(3, false)
    music(-1)
    menuitem(1, 'relaxing music',
    function() set_music_mode(true) end)
  end
end

function rnd_int(min, max)
  return flr(rnd((max + 1) - min)) + min
end

function shallow_copy(t)
  local t2 = {}
  for k, v in pairs(t) do
    t2[k] = v
  end
  return t2
end

function value_in_table(v, t)
  for k, v2 in pairs(t) do
    if v2 == v then
      return true
    end
  end

  return false
end

-- center print
function cprint(s, x, y)
  local w = text_width(s)
  print(s, x - flr(w / 2), y)
end

function text_width(s)
  local w = 0

  for i = 1, #s do
    local c = sub(s, i, i)

    -- if this is a glyph
    if c == '🅾️' or c == '❎' then
      w += 8
    else
      w += 4
    end
  end

  return max(0, w - 1)
end

-- left-pads a number with zeros until it is two digits long
function lpad2(n)
  local s = tostr(n)

  if #s == 1 then
    s = '0' .. s
  end

  return s
end

function fast_sax_hack()
  -- if this is the pattern before the fast-sax pattern
  if stat(24) == 24 then
    playedsax = false
  end

  if not playedsax then
    -- sfx 59, note number 16
    if stat(19) == 59 and stat(23) == 16 then
      sfx(62, 3)
      playedsax = true
    end
  end
end

function guitar_solo_swap()
  -- * guitar solo is played in patterns 28-35
  -- * we swap it in (to sfx 14-27) during pattern 27
  -- * we swap it out during pattern 36

  local pattern = stat(24)

  if guitarisloaded then
    -- if no music is playing, or the music is outside the part where we need
    -- to have the guitar solo loaded
    if stat(19) == -1 or pattern < 27 or pattern >= 36 then
      -- restore the original sfx 14-27 from user data area
      memcpy(guitar_solo_addr, 0x4300, guitar_solo_len)
      guitarisloaded = false
    end
  else
    if pattern == 27 then
      -- save a copy of the original sfx 14-27 to user data area
      memcpy(0x4300, guitar_solo_addr, guitar_solo_len)

      -- copy the guitar solo (stored in gfx) to sfx 14-27
      memcpy(guitar_solo_addr, 0, guitar_solo_len)

      guitarisloaded = true
    end
  end
end

function set_reverb(ch, on)
  assert(ch >= 0 and ch <= 3)
  local r = peek(0x5f41)
  if on then
    r = bor(r, 2 ^ ch)
  else
    r = band(r, bnot(2 ^ ch))
  end
  poke(0x5f41, r)
end

function pan_flute_reverb()
  local sfx = stat(17)
  local note = stat(23)

  -- enable reverb for the 2nd channel only during the part where the one pan
  -- flute hit is
  if sfx == 43 and (note == 14 or note == 15) then
    set_reverb(1, true)
  else
    set_reverb(1, false)
  end
end
