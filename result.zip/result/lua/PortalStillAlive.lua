-- portal - still alive
-- by paul nicholas


function _init()

	-- timecode, lyric, speed (2=norm,1=fast), gfx_index
	lyrics = {
		{ 2.75,    "this was a triumph."},
		{ 14.099,  "i'm making a note here:"},
		{ 20.798,  "huge success."},
		{ 29.197,  "it's hard to overstate my satisfaction.", 3 },
		{ 50.7,    "aperture science.", 2, 1 },
		{ 61.994,  "we do what we must because we can."},
		{ 77.493,  "for the good of all of us", 3 },
		{ 87.392,  "except the ones who are dead.", 1, 2 },

		{ 94.2, nil }, -- page break

		{ 94.291,  "but there's no sense crying over every mistake.", 2, 1 },
		{ 106.09,  "you just keep on trying till you run out of cake."},
		{ 118.089, "and the science gets done and you make a neat gun.", 2, 3 },
		{ 129.788, "for the people who are still alive.", 2, 1 },
		
		{ 140.0, nil }, -- page break
		
		{ 157.586, "i'm not even angry."},
		{ 170.084, "i'm being so sincere right now.", 3},
		{ 184.783, "even though you broke my heart and killed me.", 3, 4 },
		{ 205.281, "and tore me to pieces.", 2, 5 },
		{ 217.18,  "and threw every piece into a fire.", 3, 6},
		{ 232.579, "as they burned it hurt because"},
		{ 242.578, "i was so happy for you!", 2, 7},

		{ 249.0, nil }, -- page break

		{ 249.477, "now these points of data make a beautiful line."},
		{ 261.176, "and we're out of beta, we're releasing on time."},
		{ 273.175, "so i'm glad i got burned.", 2, 6},
		{ 279.074, "think of all the things we learned", 1, 3 },
		{ 285.274, "for the people who are still alive.", 2, 1},

		{ 311.0, nil }, -- page break
		
		{ 313.471, "go ahead and leave me."},
		{ 324.67,  "i think i prefer to stay inside.", 3 },
		{ 340.269, "maybe you'll find someone else to help you.", 3 },
		{ 361.367, "maybe black mesa...", 2, 8 },
		{ 372.566, "that was a joke. haha. fat chance."},
		{ 388.264, "anyway, this cake is great.", 3, 9 },
		{ 398.064, "it's so delicious and moist."},

		{ 404.8, nil }, -- page break
		
		{ 404.863, "look at me still talking when there's science to do.", 2, 2 },
		{ 416.762, "when i look out there it makes me glad i'm not you.", 2, 1 },
		{ 428.661, "i've experiments to run there is research to be done", 2, 3 },
		{ 440.56,  "on the people who are still alive", 2, 5 },

		{ 452.0, nil }, -- page break
		
		{ 452.559, "and believe me i am still alive.", 2, 1 },
		{ 463.658, "i'm doing science and i'm still alive."},
		{ 475.756, "i feel fantastic and i'm still alive."},
		{ 487.855, "while you're dying i'll be still alive."},
		{ 499.454, "and when you're dead i will be still alive."},
		{ 511.253, "still alive"},
		{ 517.453, "still alive"}
	}


	ui=	[[
.---------------..-------------.
|               ||             |
|               ||             |
|               ||             |
|               ||             |
|               ||             |
|               ||             |
|               ||             |
|               ||             |
|               ||             |
|               |`-------------'
|               |
|               |
|               |
|               |
|               |
|               |
|               |
|               |
|               |
`---------------'
	]]

credits = {
--|#############| 
	">pico-8 pals<",
	" ",
	"burning out",
	" ",
	"gregos el",
	" ",
	"trasevol dog",
	" ",
	"macario",
	" ",
	"kometbomb",
	" ",
	"gruber",
	" ",
	"jakub",
	" ",
	"mboffin",
	" ",
	"pi0cket",
	" ",
	"ultrabrite",
	" ",
	"enargy",
	" ",
	"gabriel c.",
	" ",
	"monsters go",
	" ",
	"ilkke",
	" ",
	"jose guerra",
	" ",
	"impbox",
	" ",
	"andy reist",
	" ",
	"sean s.",
	" ",
	"papaquark",
	" ",
	"matt hughson",
	" ",
	"josefnpat",
	" ",
	"rez",
	" ",
	"pixelartm",
	" ",
	"s0phieh",
	" ",
	"2d array",
	" ",
	"egor",
	" ",
	"nusan fx",
	" ",
	"electric g.",
	" ",
	"codekitchen",
	" ",
	"morningtoast",
	" ",
	"viza",
	" ",
	"kittenm4ster",
	" ",
	"blokatt",
	" ",
	"(and anyone",
	"i forgot!)",
	" ",
	" ",
	" ", 
	" ",
	" ",
	"and of course",
	"the one who",
	"made all this",
	"possible...",
	" ",
	"    zep",
  " ",
	" ", 
	" thank you",
	"for watching!",
}

gfx_list = {
	{ x=0,  y=0 }, -- aperture science
	{ x=24, y=0 }, -- radiation
	{ x=48, y=0 }, -- atom
	{ x=72, y=0 }, -- heart
	{ x=96, y=0 }, -- bang
	{ x=0,  y=24 },-- fire
	{ x=24, y=24 },-- check
	{ x=48, y=24 },-- black mesa
	{ x=72, y=24 } -- cake
}


	-- init time
	t = 0 --0
	cursor_delay = 0
	cursor_on = 0


	-- play song
 	music(0)

	-- init main/lyrics console
	main_console = new_console(
		15, -- char_width (15)
		22, -- char_height (19)
		5,  -- x_pos
		5,  -- y_pos
		9,  -- text color
		2   -- page mode (1=scroll, 2=clear)
	)
	lyric_pos = 1

  -- credits console
	mini_console = new_console(
		13, -- char_width (15)
		11, -- char_height (19)
		73,  -- x_pos
		5,  -- y_pos
		9,  -- text color
		1   -- page mode (1=scroll, 2=clear)
	)
	for i=1,10 do
		add(mini_console.line_hist, "")
	end

	curr_gfx = nil
end

function _update()
	-- update timeline
	t += 0.1
	-- update flashing cursor
	cursor_delay += 1
	if cursor_delay > 4 then
		cursor_on = -1 - cursor_on
		cursor_delay = 0
	end

	update_console(main_console)
	update_console(mini_console)

	if lyric_pos <= #lyrics then
		-- check to see if it's time for next line
		if t >= lyrics[1][1] then
			-- display lyric
			write_text(main_console, lyrics[1][2], lyrics[1][3])
			-- check for gfx change
			if lyrics[1][4] then
				curr_gfx = lyrics[1][4]
			end
			-- remove it from "queue"
			del(lyrics, lyrics[1])
		end
	else
		-- stop timeline (to ensure it won't wrap around and start again!)
		t = 600
	end

	-- update credits
	if time()%2 == 0 
	 and #credits > 0 then
		write_text(mini_console, credits[1])
		-- remove it from "queue"
		del(credits, credits[1])
	end
end


function _draw()
	cls()
	-- draw ui
	print(ui,0,0,9)

	-- draw consoles
	draw_console(main_console)
	draw_console(mini_console)

	-- draw graphics
	if curr_gfx then
		draw_gfx(gfx_list[curr_gfx])
	end
end

-- internal code

function new_console(char_width, char_height, x_pos, y_pos, col, page_mode)
	-- create a new console "object"
	local console = {}
	console.char_width = char_width
	console.char_height = char_height
	console.x = x_pos
	console.y = y_pos
	console.col = col or 9
	console.page_mode = page_mode or 1
	console.line_hist = {  }
	console.curr_lines = {}
	console.curr_line_pos = 1
	console.curr_line_speed = 2
	console.curr_line_delaycount = 0
	console.curr_line_wip = ""

	return console
end

function update_console(console)
	-- add chars of current spoken message to hist
	if #console.curr_lines > 0 then
		local curchari = #console.curr_line_wip + 1
		-- end of line?
		if curchari > #console.curr_lines[console.curr_line_pos] then
			-- add finished line
			add(console.line_hist, console.curr_lines[1])
			-- remove already-spoken line so we can go to next
			del(console.curr_lines, console.curr_lines[1])

			console.curr_line_wip = ""
			-- abort this cycle
			return
		end

		-- check to see if we reached the end of display (page)
		if #console.line_hist > console.char_height-1 then
			page_console(console)
			return
		end

		console.curr_line_delaycount += 1
		-- is it time to add next char?
		if console.curr_line_delaycount >= console.curr_line_speed then
			-- update current wip line
			console.curr_line_wip = sub(console.curr_lines[console.curr_line_pos], 1, curchari)	
			-- reset speed counter
			console.curr_line_delaycount = 0
		end
	end
end

function draw_console(console)
	-- print history
	for l = 0, #console.line_hist-1 do
		print(
			smallcaps(console.line_hist[l+1]),
			console.x,
			console.y + l*5,
			console.col)
	end
	-- print current line (being written)
	local cursor = 
		(cursor_on == 0 
			and #console.curr_line_wip < console.char_width
			and #console.line_hist < console.char_height) 
				and "_" or ""
			
	print(
			smallcaps(console.curr_line_wip..cursor),
			console.x,
			console.y + #console.line_hist*5,
			console.col)
end


-- draw graphic/icon
function draw_gfx(gfx)
	local xoff = 75
	local yoff = 68

	-- base sprite
	sspr(gfx.x, gfx.y, 24, 24, xoff, yoff, 48, 48)
	-- scanlines effect
	for y = 0,50,2 do
		line(xoff-2, yoff+y, xoff+48, yoff+y, 0)
	end
end



function page_console(console)
	if console.page_mode == 1 then
		-- scroll (prune) lines
		del(console.line_hist, console.line_hist[1])
	elseif console.page_mode == 2 then
		-- clear page
		console.line_hist = { }
	end
end

function write_text(console, message, speed)

	local lines={}
	local currline=""
	local curword=""
	local curchar=""
	local upt = function()
		--if #curword+#currline>29 then
		if #curword + #currline > console.char_width then
			add(lines,currline)
			currline=""
		end
		currline=currline..curword
		curword=""
	end

	-- first, check for page-break
	if message == nil then
		page_console(console)
		return
	end

	-- ok, something to write
	for i=1,#message do
		curchar=sub(message,i,i)
		curword=curword..curchar
		if curchar==" " then
			upt()
		--elseif #curword>28 then
		elseif #curword > console.char_width-1 then
			curword=curword.."-"
			upt()
		end
	end
	upt()
	if currline~="" then
		add(lines,currline)
	end

	-- set current "spoken line"
	console.curr_lines = lines
	console.curr_line_speed = speed or 2
end



-- -----------------------------------------------------------------
-- libraries and helper code
-- -----------------------------------------------------------------

function smallcaps(s)
	local d=""
	local l,c,t=false,false
	for i=1,#s do
		local a=sub(s,i,i)
		if a=="^" then
			if c then d=d..a end
				c=not c
			elseif a=="~" then
				if t then d=d..a end
				t,l=not t,not l
			else 
				if c==l and a>="a" and a<="z" then
				for j=1,26 do
					if a==sub("abcdefghijklmnopqrstuvwxyz",j,j) then
						a=sub("\65\66\67\68\69\70\71\72\73\74\75\76\77\78\79\80\81\82\83\84\85\86\87\88\89\90\91\92",j,j)
					break
					end
				end
			end
			d=d..a
			c,t=false,false
		end
	end
	return d
end
