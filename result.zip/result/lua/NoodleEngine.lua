-- noodle engine example cart
--  by jakub wasilewski

-- the engine core is minified,
-- but the picture examples
-- are plaintext (scroll to
-- bottom), so feel free to
-- play with them!

-- the docs for making your
-- own pictures are here:

-- http://wasyl.eu/noodleengine

-------------------------------
-- minified engine core
-------------------------------

function ec(x)
return flr(x+0.5)end
function ceil(x)
return -flr(-x)end
function lerp(a,b,t)
return a*(1-t)+b*t
end
function rndf(lo,hi)
return lo+rnd(hi-lo)end
function rndsgn()
return rnd()<0.5 and 1 or -1
end
function bw(ge,fn,...)local gt={}
for i=1,#ge do
gt[i]=fn(ge[i],...)end
return gt
end
function f_(jc)dk={}
for k,v in pairs(jc)do
dk[k]=v
end
return dk
end
function fj(fn,im)
return fn(im[1],im[2],im[3],im[4],im[5],im[6])end
function fa(ge)local a=1
for i=1,#ge do
local e=abs(ge[i])
if (e>a)a=e
end
return a
end
function bj(s,x,y,c,a)s=s..""
x-=#s*4*a
print(s,x,y,c)end
local dw8_colors={[0]={0.000,0.000,0.000},{0.114,0.169,0.325},{0.494,0.145,0.325},{0.000,0.529,0.318},{0.671,0.322,0.212},{0.373,0.341,0.310},{0.761,0.765,0.780},{1.000,0.945,0.910},{1.000,0.000,0.302},{1.000,0.639,0.000},{1.000,0.925,0.153},{0.000,0.894,0.212},{0.161,0.678,1.000},{0.514,0.463,0.612},{1.000,0.467,0.659},{1.000,0.800,0.667},}
function bx2gs(h,s,l)h,s,l=h%1,mid(s,0,1),mid(l,0,1)local ja=s*(1-abs(2*l-1))local fq,eu=
l+ja/2,l-ja/2
local r,g,b
if h<1/6 then
r,b,g=fq,eu,eu+ja*h*6
elseif h<2/6 then
g,b,r=fq,eu,fq-ja*(h-1/6)*6
elseif h<3/6 then
g,r,b=fq,eu,eu+ja*(h-2/6)*6
elseif h<4/6 then
b,r,g=fq,eu,fq-ja*(h-3/6)*6
elseif h<5/6 then
b,g,r=fq,eu,eu+ja*(h-4/6)*6
else
r,g,b=fq,eu,fq-ja*(h-5/6)*6
end
return r,g,b
end
function jx(r,g,b)de,ek=nil,1000
for i=0,15 do
local c=dw8_colors[i]
local cr,cg,cb=c[1],c[2],c[3]
local dr,dg,db=
(cr-r)^2,(cg-g)^2,(cb-b)^2
local bo=dr*2+dg*4+db
if bo<ek then
de,ek=i,bo
end
end
return de
end
function hx(h,s,l)
return jx(bx2gs(h,s,l))end
function fz()for b=1/16,15/16,1/8 do
for r=1/32,31/32,1/16 do
for g=1/32,31/32,1/16 do
local x=(b*8-0.5)*16+(r*16-0.5)local y=(g*16-0.5)+32
local c=jx(r,g,b)sset(x,y,c)end
end
end
jz()end
ez={}
ez.__index=ez
function ba(ip)ip.ga=fa(ip)
return setmetatable(ip,ez)end
function ez.fi()
return ba({1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1})end
function ez:gh(p)local m=self
local x,y,z,w=p[1],p[2],p[3]
local eh=fa(p)local fg=8000/self.ga/eh
local tx=fg*m[1]*x+fg*m[2]*y+fg*m[3]*z+fg*m[4]
local ty=fg*m[5]*x+fg*m[6]*y+fg*m[7]*z+fg*m[8]
local tz=fg*m[9]*x+fg*m[10]*y+fg*m[11]*z+fg*m[12]
return v(tx/fg,ty/fg,tz/fg)end
function ez:dv()local s="["for i=1,16 do
s=s..self[i]
s=s..(i==16 and "]" or ",")
if (i%4==0)s=s.."\n"
end
return s
end
function ez.bh(x,y,z)if type(x)=="table" then
x,y,z=x[1],x[2],x[3]
end
return ba({1,0,0,x,0,1,0,y,0,0,1,z,0,0,0,1})end
function ez.fb(ik,da)local sn,cn=sin(da),cos(da)local ic=1-cn
local ax,ay,az=ik[1],ik[2],ik[3]
return ba({cn+8000*ax*ax*ic/8000,ax*ay*ic-az*sn,ax*az*ic+ay*sn,0,ay*ax*ic+az*sn,cn+ay*ay*ic,ay*az*ic-ax*sn,0,az*ax*ic-ay*sn,az*ay*ic+ax*sn,cn+az*az*ic,0,0,0,0,1
})end
function ez.fk(sx,sy,sz)
if (not sy)sy=sx
if (not sz)sz=sy
return ba({sx,0,0,0,0,sy,0,0,0,0,sz,0,0,0,0,1})end
function ez:d_()local eo={}
for i=0,3 do
for j=0,3 do
eo[j*4+i+1]=by(i,j,self)end
end
local d=0
for k=0,3 do
d+=self[k+1]*eo[k*4+1]
end
if (d==0)return nil
local id=1/d
for i=1,16 do
eo[i]*=id
end
return ba(eo)end
function by(i,j,m)local o=2+(j-i)
i+=4+o
j+=4-o
local e=function(dx,dy)local gw=((j+dy)%4)*4 + (i+dx)%4 + 1
return m[gw]
end
local eo=
e( 1,-1)*e( 0,0)*e(-1,1)+
e( 1,1)*e( 0,-1)*e(-1,0)+
e(-1,-1)*e( 1,0)*e( 0,1)-
e(-1,-1)*e( 0,0)*e( 1,1)-
e(-1,1)*e( 0,-1)*e( 1,0)-
e( 1,-1)*e(-1,0)*e( 0,1)
return (o%2==1)and eo or -eo
end
function ez.__mul(a,b)local r={}
local fg=8000/a.ga/b.ga
for y=0,3 do
for x=0,3 do
local c=0
for n=0,3 do
c+=fg*a[y*4+n+1]*b[n*4+x+1]
end
add(r,c/fg)end
end
return ba(r)end
en={}
en.__index=en
function v(x,y,z)
return setmetatable({x,y,z},en)end
function en:__len()
return self[1]^2+self[2]^2+self[3]^2
end
function en:__unm()
return v(-self[1],-self[2],-self[3])end
function en:__add(o)
return v(self[1]+o[1],self[2]+o[2],self[3]+o[3]
)end
function en:__sub(o)
return v(self[1]-o[1],self[2]-o[2],self[3]-o[3]
)end
function en:__mul(a)
return v(self[1]*a,self[2]*a,self[3]*a
)end
function en:hw(o)
return self[1]*o[1]+self[2]*o[2]+self[3]*o[3]
end
function en:e_(g_)local x,y,z=
self[2]*g_[3]-self[3]*g_[2],self[3]*g_[1]-self[1]*g_[3],self[1]*g_[2]-self[2]*g_[1]
return v(x,y,z)end
function en:hs(ga)ga=ga or 1
local m=self:ie()/ga
return v(self[1]/m,self[2]/m,self[3]/m)end
function en:ie()
return sqrt(#self)end
function en:dc()local x,y,z=self[1],self[2],self[3]
local zf=max(1+z*0.0125,0.5)local px,py=64+x/zf,64+y/zf
return v(px,py,z)end
function en:gh(m)
return m:gh(self)end
function en:dv()
return "["..self[1]..","..
self[2]..","..
self[3].."]"end
en.ha=v(0,0,0)function gb(c)
return function(x1,x2,y)rectfill(x1,y,x2,y,c)end
end
function gc(ch,gl)local gv,c_,ce,js,ib=
#ch,{},{},{},{}
local ct,gr=128,-1
for i=1,gv do
local gk=i%gv+1
ct,gr=cz(ch[i],ch[gk],c_,ce,js,ib,ct,gr
)end
for y=ct,gr do
gl(ceil(c_[y]),flr(ce[y]),y,js[y],ib[y])end
end
function hl(c1,c2,y1,y2,iy1,iy2)if abs(y2-y1)>0.001 then
return c1+(c2-c1)*(iy1-y1)/(y2-y1)else
return (c1+c2)*0.5
end
end
function cz(iw,to,c_,ce,js,ib,ct,gr
)if iw[2]>to[2]then
iw,to=to,iw
end
local x1,y1,x2,y2=
iw[1],iw[2],to[1],to[2]
local iy1,iy2=
max(ceil(y1),0),min(flr(y2),128)if iy1>=y2 then
return ct,gr
end
local ix1=
hl(x1,x2,y1,y2,iy1,iy2)local zr1,zr2=
100/(iw[3]+100),100/(to[3]+100)local fm1=
hl(zr1,zr2,y1,y2,iy1,iy2)local ck=y1>y2 and -1 or 1
local ij=(x2-x1)/abs(y2-y1)local jt=(zr2-zr1)/abs(y2-y1)local x,zr=ix1,fm1
for y=iy1,iy2,ck do
if not c_[y]or x<c_[y]then
c_[y]=x
js[y]=zr
end
if not ce[y]or x>ce[y]then
ce[y]=x
ib[y]=zr
end
x+=ij
zr+=jt
end
return max(min(ct,min(iy1,iy2)),0),min(max(gr,max(iy1,iy2)),127)end
function dt(j_,fogc,cr,cg,cb)
return lerp(cr,fogc[1],j_),lerp(cg,fogc[2],j_),lerp(cb,fogc[3],j_)end
function b_3d(ch,clr,gj)local p1,p2,p3=ch[1],ch[2],ch[3]
local ht=(p2-p1):hs():e_(p3-p2):hs()local light=abs(ht:hw(fd))local p2d=bw(ch,en.dc)if backface_cull and ht[3]<0 then
return
else
end
local fog=mid((p1[3]-cc)/ef,0,1)
if (h_==jm and fog==1)return
light=1.4*light+0.2
if (h_==0)light*=(1-fog)
local r,g,b=bx2gs(clr.h,clr.s,clr.l*light
)if h_~=0 then
r,g,b=dt(fog,bp,r,g,b)end
er,eg,eb=0,0,0
gc(p2d,iq(r,g,b,gj,fog))end
ir={}
function cf()local hk,cu=
v(1,0,0),v(0,1,0)local fp=v(0,0,-31.5)for bn=-0.25,0.25,0.005 do
for bv=-0.25,0.25,0.005 do
local y=sin(bn)local scl=cos(bn)local x,z=sin(bv)*scl,-cos(bv)*scl
local px,py=
ec(y*31.5),ec(x*31.5)
if (not ir[py])ir[py]={}
ir[py][px]=v(x,y,z)end
end
end
function sphere3d(jy,r,clr,gj)local c2d,hr=jy:dc(),jy[3]
local rp=(jy+v(r,0,0)):dc()local r2d=(rp-c2d):ie()local cx,cy=
ec(c2d[1]),ec(c2d[2])local bs=ceil(r2d)local ei=32/r2d
local fog=mid((jy[3]-cc)/ef,0,1)local ff=flr(7*(1-fog)+0.5)er,eg,eb=0,0,0
for dy=-bs,bs do
local bz=ir[ec(dy*ei)]
if bz then
for dx=-bs,bs do
local st=bz[ec(dx*ei)]
if st then
local light=0.2-1.4*fd:hw(st)
if (h_==0)light*=(1-fog)
local cr,cg,cb=
bx2gs(clr.h,clr.s,clr.l*light)if h_~=0 then
cr,cg,cb=
dt(fog,bp,cr,cg,cb)end
local dr,dg,db=
mid(cr+er,0,1),mid(cg+eg,0,1),mid(cb+eb,0,1)c,er,eg,eb=
fe(dr,dg,db)
er-=shr(er,1)
eg-=shr(eg,1)
eb-=shr(eb,1)
local z=hr+st[3]
local zr=100/(z+100)il(cx+dx,cy+dy,zr,c,gj,ff)end
end
end
end
end
function ca()memset(0x1c00,31,0x4000)end
function fw(i)local v=peek(0x1c00+i)
return band(0x7,shr(v,5)),band(0x1f,v)end
function gn(i,ea,gj)poke(0x1c00+i,shl(ea,5)+band(gj,0x1f))end
jd={{dx=1,dy=0,di=1,v=6,lm=0},{dx=-1,dy=0,di=-1,v=6,lm=0},{dx=0,dy=1,di=128,v=6,lm=0},{dx=0,dy=-1,di=-128,v=6,lm=0},{dx=1,dy=1,di=129,v=3,lm=0.3},{dx=-1,dy=1,di=127,v=3,lm=0.3},{dx=1,dy=-1,di=-127,v=3,lm=0.3},{dx=2,dy=0,di=2,v=3,lm=0.3},{dx=0,dy=2,di=256,v=3,lm=0.3},{dx=2,dy=1,di=130,v=3,lm=0.3},{dx=1,dy=2,di=257,v=3,lm=0.3},{dx=-1,dy=2,di=255,v=3,lm=0.3},{dx=2,dy=-1,di=-126,v=3,lm=0.3}
}
function hz(x,y,i,ff)local zh=ey[i]
local sh,fh=fw(i)for sd=1,13 do
local d=jd[sd]
local lm=d.lm
local io=i+d.di
local zo=ey[io]
local so,fx=fw(io)local gq
if (not zo)goto jh
gq=zo/zh
if gq<0.96 and gq>=lm and fh~=fx then
local v=min(d.v,ff)if so<v then
local xo,yo=x+d.dx,y+d.dy
gn(io,v,fx)pset(xo,yo,sget(7-v+so,pget(xo,yo)))end
end
::jh::
local zo=ey[i-d.di]
if (not zo)goto bm
local so,fx=fw(i-d.di)gq=zh/zo
if gq<0.96 and gq>=lm and fh~=fx then
local v=min(d.v,ff)if sh<v then
gn(i,v,fh)pset(x,y,sget(7-v+sh,pget(x,y)))sh=v
end
end
::bm::
end
end
function il(x,y,zr,c,gj,ff)local i=shl(y,7)+x
if (ey[i]or 32000)>=zr then
return
end
ey[i]=zr
gn(i,0,gj)pset(x,y,c)if ff>0 then
hz(x,y,i,ff)end
end
function fe(r,g,b)local ri,gi,bi=
r*15.999,g*15.999,flr(b*7.999)local c=sget(shl(bi,4)+ri,32+gi
)local dq=dw8_colors[c]
local ar,ag,ab=dq[1],dq[2],dq[3]
return c,r-ar,g-ag,b-ab
end
er,eg,eb=0,0,0
function iq(cr,cg,cb,gj,fog)local ff=flr(7*(1-fog)+0.5)
return function(x1,x2,y,zr1,zr2)local ix1,ix2=
max(x1,0),min(x2,127)
if (ix1>ix2)return
local fm1=
hl(zr1,zr2,x1,x2,ix1,ix2)local jt=(zr2-zr1)/(x2-x1)local zr=fm1
local c
for x=ix1,ix2 do
local dr,dg,db=
mid(cr+er,0,1),mid(cg+eg,0,1),mid(cb+eb,0,1)c,er,eg,eb=
fe(dr,dg,db)er=shr(er,1)eg=shr(eg,1)eb=shr(eb,1)il(x,y,zr,c,gj,ff)
zr+=jt
end
end
end
eq={}
function picture(gm,jl)add(eq,{gm=gm,bg=jl.bg,is=function()local origin=jl.origin and
fj(v,jl.origin)or
v(0,0,70)local clr=jl.clr and
{h=jl.clr[1],s=jl.clr[2],l=jl.clr[3]}or
{h=0.15,s=1,l=0.56}
du={{fn=jl.shape,c=origin,clr=clr,m=ez.fb(v(1,0,0),-0.25),gd=0,jb=ez.fi()}}
fd=(jl.light
and fj(v,jl.light)or v(0.5,0.5,1)):hs()local fog=jl.fog or {120,200}
cc=fog[1]
ef=fog[2]-fog[1]
h_=jl.fogc or 0
jm=jl.bg or 0
bp=dw8_colors[h_]
if jl.backface_cull~=nil then
backface_cull=jl.backface_cull
else
backface_cull=true
end
end
})end
ia=1
gj=0
function cm(ja)
ia+=ja
ia=
(ia-1)%#eq+1
hh=eq[ia]
cls(hh.bg)flip()ev()gp,hc=0,0
hh.is()end
function ev()ey={}
for i=0,16383 do
ey[i]=0.01
end
ca()local bg=hh.bg or 0
local fv=bg*17
memset(0x5c00,fv,0x200)end
function ew()local gx=du[1]
if (not gx)return false
del(du,gx)it=gx
if gx.cs then
local p=gx.cs
gx.fn(gx.gd,p[1],p[2],p[3],p[4],p[5]
)else
gx.fn(gx.gd)end
return gx
end
function jf(i_)
return {m=i_.m,c=i_.c,clr=i_.clr,ch=i_.ch,cp=i_.cp,fn=i_.fn,gd=i_.gd,jb=i_.jb
}
end
function fu(i_,...)local gx=jf(i_)local ed
for he in all({...})do
if type(he)=="table" then
for k,v in pairs(he)do
fy[k](gx,v)end
else
if (not ed)ed={}
add(ed,he)end
end
return gx,ed
end
function move(...)it=fu(it,...)end
function lock()local gx=fu(it,{rx=0.25})it.jb=gx.m
end
function reset()it.m=it.jb
it=fu(it,{rx=-0.25})end
function shape(jn,...)local gx,ed=fu(it,...)
gx.gd+=1
gx.fn=jn
gx.ch=gx.cp or gx.ch
gx.cs=ed
local c=gx.c
if abs(c[1])<1000 and abs(c[2]<1000)and c[3]>0 then
add(du,gx)end
end
function strip(w,...)local gx=fu(it,...)local fs=v(w,0,0):gh(gx.m)local l,r=gx.c-fs,gx.c+fs
local hf=it.ch
it.cp={l,r}
if (not hf)or #hf~=2 then
return
end
local d_=ih(gx,l,hf[1])local em=d_
and {hf[1],hf[2],r,l}
or {hf[2],hf[1],l,r}
b_3d(em,it.clr,gj)
gj+=1
end
el={v(-1,-1,-1),v(1,-1,-1),v(1,1,-1),v(-1,1,-1),v(-1,-1,1),v(1,-1,1),v(1,1,1),v(-1,1,1),}
jo={{1,2,3,4},{8,7,6,5},{1,4,8,5},{2,6,7,3},{1,5,6,2},{4,3,7,8}
}
function cube(ju,...)local gx=fu(it,...)local ep=bw(el,en.gh,gx.m)for i=1,8 do
ep[i]=gx.c+ep[i]*ju
end
for fc=1,6 do
local f=jo[fc]
b_3d({ep[f[1]],ep[f[2]],ep[f[3]],ep[f[4]]},it.clr,gj
)end
gj+=1
end
function tube(cw,w,...)local gx=fu(it,...)local fs=v(w,0,0)local jv=cl(cw)local ch={}
for i=1,cw do
ch[i]=gx.c+fs:gh(gx.m)fs=fs:gh(jv)end
it.cp=ch
local hf=it.ch
if (not hf)or #hf~=cw then
return
end
local d_=ih(gx,ch[1],hf[1])for i=1,cw do
local n1,n2=i,i%cw+1
if (d_)n1,n2=n2,n1
b_3d({ch[n2],ch[n1],hf[n1],hf[n2]},it.clr,gj
)
gj+=1
end
end
function cap()
if (not it.ch)return
b_3d(it.ch,it.clr,gj
)
gj+=1
end
function sphere(dp,...)local gx=fu(it,...)local r=v(dp,0,0):gh(gx.m)sphere3d(gx.c,r:ie(),gx.clr,gj)
gj+=1
end
function disc(dp,...)local gx=fu(it,...)local fs=v(dp,0,0)local l1,l2=
fs:gh(gx.m):ie(),v(0,dp,0):gh(gx.m):ie()local cw=max(flr(max(l1,l2)/2),3)local jv=cl(cw)local ch={}
for i=1,cw do
ch[i]=gx.c+fs:gh(gx.m)fs=fs:gh(jv)end
b_3d(ch,it.clr,gj)
gj+=1
end
function ih(i_,pt,hf)local fwd=v(0,0,1):gh(i_.m)
return fwd:hw(pt-hf)<0
end
jr={}
function cl(br)if not jr[br]then
jr[br]=ez.fb(v(0,0,1),1/br
)end
return jr[br]
end
function bu(jp)
return function(i_,d)local cj=(jp*d):gh(i_.m)
i_.c+=cj
end
end
function hy(jp)
return function(i_,d)local ii=(jp*d):gh(i_.jb)
i_.c+=ii
end
end
function bt(ik)
return function(i_,a)local iz=ik:gh(i_.m):hs()i_.m=ez.fb(iz,a)*i_.m
end
end
function iu(ik)
return function(i_,a)local bk=ik:gh(i_.jb):hs()i_.m=
ez.fb(bk,a)*
i_.m
end
end
function ee(x,y,z)
return function(i_,s)i_.m=i_.m *
ez.fk(x and s or 1,y and s or 1,z and s or 1
)end
end
fy={fwd=bu(v(0,0,1)),bck=bu(v(0,0,-1)),lft=bu(v(-1,0,0)),rgt=bu(v(1,0,0)),up=bu(v(0,-1,0)),dn=bu(v(0,1,0)),fwdg=hy(v(0,0,1)),bckg=hy(v(0,0,-1)),lftg=hy(v(-1,0,0)),rgtg=hy(v(1,0,0)),upg=hy(v(0,-1,0)),dng=hy(v(0,1,0)),rx=bt(v(1,0,0)),ry=bt(v(0,1,0)),rz=bt(v(0,0,1)),rxg=iu(v(1,0,0)),ryg=iu(v(0,1,0)),rzg=iu(v(0,0,1)),scl=ee(true,true,true),sx=ee(true,false,false),sy=ee(false,true,false),sz=ee(false,false,true)}
function fy.t(i_,v)i_.gd=v
end
function fy.hue(i_,dh)i_.clr=f_(i_.clr)i_.clr.h=(i_.clr.h+dh)%1
end
function fy.sat(i_,ds)i_.clr=f_(i_.clr)
i_.clr.s+=ds
end
function fy.lgt(i_,dl)i_.clr=f_(i_.clr)
i_.clr.l+=dl
end
function fy.clr(i_,c)i_.clr={h=c[1],s=c[2],l=c[3]}
end
function _init()cf()ka=true
cm(0)end
function _update60()
if (btnp(0))cm(-1)
if (btnp(1)or btnp(4))cm(1)
if (btnp(3))ka=not ka
if (btnp(5))cm(0)
end
function _draw()memcpy(0x7e00,0x5c00,0x200)local bq,hb=
1,0
while bq>=1 do
if (not ew())break
hb+=1
bq=(0.95-stat(1))*hb/stat(1)end
gp+=hb
hc+=1
memcpy(0x5c00,0x7e00,0x200)if ka then
rectfill(0,120,127,120,0)rectfill(0,121,127,127,1)print(hh.gm,1,122,6)bj("🅾️=next ❎=redo  ",127,122,5,1)end
end

-------------------------------
-------------------------------
-- pics go here!
-------------------------------
-------------------------------

-- starter template
--[[
 function mypic()
  sphere(16)
 end
 picture("my pic",{
  shape=mypic
 })
--]]

------------------------------
-- spiral example
------------------------------

function spiral()
 -- 6 units forward,
 -- rotate slightly to left
 -- scale z axis down to make
 -- following shapes shorter
 move(
  {fwd=6},{ry=0.01},{sz=0.997})
 -- draw a tube segment
 tube(4,5)
 -- recurse to make the spiral
 -- continue!
 shape(spiral)
end

picture("spiral",{
 shape=spiral,
 origin={90,0,70}
})

------------------------------
-- tunnel example
------------------------------

function tunnel(t)
 -- a tunnel is just a fancy
 -- spiral
 move({fwd=6},{ry=0.01},
  {fwdg=0.25+0.001*t},
  {rgtg=t*0.0003})
 -- ..that shoots a whisker
 -- from each point
 shape(whisker,
  rndf(5,25),rndsgn(),{t=0},
  {ry=0.25},{rx=-0.1})
 -- and continues on and on
 shape(tunnel)
end
function whisker(t,ln,r)
 -- whiskers slowly twist
 -- in the direction given
 -- by r
 move({fwd=4},{ry=r*0.02})
 tube(5,2)
 if (t<ln) shape(whisker,ln,r)
end
picture("tunnel",{
 shape=tunnel,
 origin={90,0,40},fog={50,700},
 clr={0.1,0.5,0.6}})

------------------------------
-- spirograph example
------------------------------

arm_count=11
arm_thickness=10
function spiro()
 move({rz=0.03})
 lock()
 shape(arms)
end
function arms()
 for i=1,arm_count do
  shape(arm,
   {rzg=i/arm_count},{rz=0.1},
   {hue=i/arm_count}
  )
 end
end
function arm(t)
 local tf=1/(1+t/100)
 move({fwd=1.3},{rzg=0.002/tf},
  {fwdg=0.19},{hue=0.001})
 tube(6,arm_thickness*tf)
 if (tf>0.1) shape(arm)
end

picture("spiro",{
 shape=spiro,
 clr={0.3,1,0.56},
 origin={-15,0,70}
})


-------------------------------
-- mandala example
-------------------------------

-- 5-way star symmetry for now
-- but other settings are
-- interesting as well!
symmetry=5
function mandala()
 for i=1,symmetry do
  -- main strand
  shape(strand,{ry=i/symmetry})
  -- flipped strand
  shape(strand,{sy=-1},{ry=i/symmetry})
  -- supplementary strand in a
  -- slightly different direction
  shape(strand,{fwd=5},{ry=i/symmetry},{rx=-0.15},{scl=0.9})
 end
end

function strand(t)
 -- make a twisting tube
 move({fwd=3},{ry=0.01},{hue=-0.003},{fwdg=0.4})
 tube(4,5)
 -- every 25 ticks, we end
 -- the strand and spawn
 -- new, smaller strands
 if t%25==0 then
  -- at t=150, we're done
  if (t==150) return
  shape(strand,{scl=0.9},{ry=0.1})
  if (t>=100) return
  -- if t<100, we spawn two
  -- additional strands
  -- to the sides
  shape(strand,{scl=0.7},{ry=0.35},{lgt=-0.1})
  shape(strand,{scl=0.7},{ry=-0.15},{lgt=-0.1})
 else
  -- no spawning, just
  -- continue this strand
  shape(strand)
 end
end

picture("mandala",{
 shape=mandala,
 clr={1,0.4,0.6}
})

-------------------------------
-- flower example
-------------------------------

function flower()
 -- spawn petals and stem
 shape(petals,
  {rzg=0.12,rx=0.07,hue=0.04})
 shape(stem,
  {hue=0.33},{rzg=0.1},{rz=0.12})
end

function petals()
 -- 8 petals with rotational
 -- symmetry
 local count=8
 for i=0,count-1 do
  -- bottom petal
  shape(petal,{hue=0.12},{lgt=0},
   {ry=i/count},{rx=-0.05})
  -- middle petal (smaller, darker)
  shape(petal,{hue=0.06},{lgt=-0.08},
   {ry=(i+0.5)/count},{rx=-0.12},{scl=0.85})
  -- chalice petal (even smaller and darker)
  shape(petal,{hue=0},{lgt=0.2},
   {ry=i/count},{rx=-0.225},{rz=-0.1},{scl=0.75})
 end
end

function petal(t)
 -- size factor based on time
 local f=max(1-t*0.006,0)
 -- draw the petal
 move({fwd=0.6},{rz=0.006},
  {rx=0.002},{lgt=0.004})
 -- width decreases with time
 tube(4,30*f)
 -- terminate after a while
 if (t<160) shape(petal)
end

function stem(t)
 -- just a mostly straight tube
 move(
  {bck=2},{rzg=-0.001},
  {rz=0.002}
 )
 tube(4,4)
 if (t<100) shape(stem)
end

picture("flower",{
 shape=flower,
 origin={-10,-20,60},
 clr={0,1,0.3},
 light={-0.3,0.7,1},
})

------------------------------
-- pipe screensaver
------------------------------

function pipes()
 -- spawn a grid of randomly
 -- oriented pipes
 for x=-2,2,2 do
  for y=-2,2,2 do
   for z=-2,2,2 do
   shape(pipe,
    {dn=z*20,fwd=y*20,rgt=x*20},
    rnd()<0.8 and rndturn())
   shape(pipe,
    {dn=z*20,fwd=y*20,rgt=x*20},
    rnd()<0.8 and rndturn())
   end
  end
 end
end
function pipe(t)
 -- draw segment
 tube(4,2.5)
 move({fwd=3})
 -- turn sometimes
 if rnd()<t*0.005 then
  -- turn in a random dir
  move(rndturn())
  sphere(3)
  shape(pipe,{t=0})
  return
 end
 -- randomly end
 if (rnd()<t*0.0005) return
 -- continue the pipe
 shape(pipe)
end
-- returns a random turn
-- transformation
turns={
 {rx=0.25},{rx=-0.25},
 {ry=0.25},{ry=-0.25}
}
function rndturn()
 local turn=flr(rnd(4)+1)
 return turns[turn]
end

picture("pipes",{
 shape=pipes,
 clr={0,0,0.8},
 origin={0,0,100},
 fog={70,120},
 bg=13,fogc=13,
})

------------------------------
-- weaves
------------------------------

brkx,brky=0.25,0.05
function weaves()
 shape(weave)
 shape(weave,{dn=20},{lgt=-0.5})
end
function weave()
 for ya=0,0.99,0.25 do
  for xa=0,0.99,0.2 do
   shape(wire,{ry=ya},{rx=xa})
  end
 end
end
function wire(t)
 move({fwd=4},{ry=0.01},{rx=0.01})
 tube(4,5)
 if (t==90) return
 if t%25==0 then
  shape(wire,{sx=0.8},{sy=0.8},{sz=1.2},{lft=30},{rx=-brkx},{ry=-brky})
  shape(wire,{sx=0.8},{sy=0.8},{sz=1.2},{rgt=30},{rx=brkx},{ry=brky})
 else
  shape(wire,{scl=0.98},{hue=0.003})
 end
end

picture("weave",{
 shape=weaves,
 origin={0,0,70},
 clr={0.95,1,0.9},
 fog={50,110},
 bg=7,fogc=7,
})

-------------------------------
-- kudzu example
-------------------------------

tentacle_count=60
function tentacles()
 for i=1,tentacle_count do
  local angle=i/tentacle_count
  local turn=rnd()<0.5 and 1 or -1
  shape(tentacle,turn,0,
   {rx=rnd()},{ry=rnd()},
   {hue=rndf(-0.1,0.1)},
   {lgt=rndf(-0.2,0.2)})
 end
end

function tentacle(t,turn,p)
 local dist=1/(1+t/60)
 move(
  {fwd=dist*2},
  {ry=turn*0.016},
  {rz=-turn*0.004}
 )
 tube(5,8*dist*dist)
 if (rnd()<p) turn,p=-turn,0
 if (rnd()<p/2) then
  sphere(dist*12,{
   dn=dist*8,
   clr={rndf(0.0,0.2),1,0.7}
	 })
 end 
 if t<150 then
  shape(tentacle,turn,p+0.005)
 else
  sphere(dist*12,{
   dn=dist*8,
   clr={rndf(0.0,0.2),1,0.7}
  })
 end
end

picture("kudzu",{
 shape=tentacles,
 clr={0.35,1,0.56},
 fog={60,90}
})

-------------------------------
-- tree example
-------------------------------

-- how long before tree
-- branches out
branch_len=40

function tree()
 -- initialize the first
 -- branch
 shape(branch,branch_len,0,0)
end
function branch(t,bl,ln,lv)
 -- make the branch
 move({
  fwd=3,upg=0.05,
  sx=0.986,sy=0.986,
  rz=0.003,rx=0.0005,
 })
 tube(6,60)
 -- should we branch out?
 if rnd()<(ln-bl)*0.01 then
  -- how many branches?
  local lvoff=3-lv*0.5
  local count=flr(rnd(2)+lvoff)
  -- make the individual
  -- branches, rotating
  -- each to spread them out
  for i=1,count do
   local rsgn=rnd()>0.5
    and -1 or 1
   shape(branch,bl*0.75,0,lv+1,
    {rz=i/count},
    {rx=rndf(0.07,0.2)*rsgn}
   )
  end
  -- should this root branch
  -- continue or end?
  if rnd()<0.8-lv*0.1 then
   shape(branch,bl*0.75,0,lv+0.4)
  end
 elseif lv<4 then
  -- no branching out, continue
  shape(branch,bl,ln+1,lv)
 else
  -- end of branch - make a
  -- clump of leaves!
  shape(clump)
 end
end
function clump()
 -- reset rotation/scale
 -- set color to green
 reset()
 move({clr={0.3,1,0.4}})
 -- simulate leaves
 -- with lots of spheres
 for i=1,60 do
  sphere(10,
   {rx=rnd(),ry=rnd()},
   {fwd=rnd(30)})
 end
end

picture("tree",{
 shape=tree,
 origin={0,300,300},
 fog={300,450},--{50,350}
 clr={0.1,0.7,0.6},
})

------------------------------
-- mushroom patch
------------------------------

shrooms=10
stalk_len,stalk_w,cap_w=30,6,48
function shroompatch()
 move({rx=-0.05},{scl=1.1})
 for i=1,shrooms do
  local sclw=rndf(0.8,1)
  local shapef=rndf(0.8,1.6)
  local twist=rndf(-0.07,0.07)
  twist=rndsgn()*twist*twist
	 shape(shroom,shapef,twist,
	  {lft=rndf(-70,70)},
	  {up=rndf(-90,50)},
	  {scl=rndf(0.4,1)},
	  {rx=rndf(-0.05,0.0)},
	  {ry=rndf(-0.02,0.02)},
	  {hue=rndf(-0.1,0.1)}
	 )
	end
	for i=1,320 do
	 shape(grassblade,rndf(4,13),
	  {rz=rnd()},{lft=rndf(0,70)},
	  {ry=rndf(-0.1,0.1)},
	  {rz=rnd()},
	  {clr={0.4,1,rndf(0.3,0.4)}})
	end
end
function shroom(t,shapef,twist)
	local tt=t/stalk_len
	local sf=1.1-tt*0.23
	move({fwd=2*shapef,sx=sf,sy=sf})
	move({ry=twist})
	tube(10,stalk_w)
	if t<stalk_len then
	 shape(shroom,shapef,twist)
	else
	 local sf=cap_w/stalk_w
	 shape(shroomcap,
	 	{sx=sf},{sy=sf},
	 	{rx=rndf(-0.02,0.02)},
	 	{ry=rndf(-0.02,0.02)},
	 	{lgt=-0.5},{sat=0.3},
	 	{t=0})
	end
end
function shroomcap(t)
 local tf=t/50
 local sf=1-tf*tf*0.06
 tube(16,stalk_w)
 move({fwd=0.5,sx=sf,sy=sf})
 if t<50 then
  shape(shroomcap)
 else
  cap()
 end
end
function grassblade(t,l)
 move({fwd=4,sx=0.96,rz=0.02})
 strip(2)
 if t<l then
  shape(grassblade,l)
 end
end
picture("shrooms",{
 shape=shroompatch,
 origin={0,40,90},
 clr={0.1,0.6,0.8},
 backface_cull=false,
 fog={60,150},
})
if(_update60)_update=function()_update60()_update_buttons()_update60()end