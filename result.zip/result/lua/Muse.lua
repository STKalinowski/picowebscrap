--a musical toy for slapping
--notes together haphazardly
--it also demos how to write
--patterns programatically.

--by jakub wasilewski
--license: cc-by-nc-sa

-----------------------------
-- writing notes to memory
-----------------------------
note={c=0,c_=1,d=2,d_=3,e=4,
 f=5,f_=6,g=7,g_=8,a=9,a_=10,
 b=11}
function poke_note(snd,pos,note,octave,ins,vol,eff)
 local fb=octave*12+note -- 0..5 note
  +(ins%4)*64            -- 6..7 ins
 local sb=flr(ins/4)     -- 8..8 ins+
  +vol*2                 -- 9..11 volume
  +eff*16                -- 12..14 effect 
 local addr = 0x3200 
  +snd*68+pos*2
 poke(addr,fb)
 poke(addr+1,sb)
end

-----------------------------
-- config - scale and sounds
-----------------------------
-- major pentatonic scale
scale={
 {note.d,1},
 {note.e,1},
 {note.g,1},
 {note.a,1},
 {note.c,2},
 {note.d,2},
 {note.e,2},
 {note.g,2},
 {note.a,2},
 {note.c,3},
 {note.d,3},
 {note.e,3},
 {note.g,3},
 {note.a,3},
 {note.c,4},
}
--"instruments" that you can use
sounds={
 {oct=0,ins=7,vol=5,eff=0},
 {oct=0,ins=1,vol=5,eff=5},
 {oct=0,ins=0,vol=7,eff=3},
 {oct=0,ins=6,vol=3,eff=5},
 {oct=0,ins=1,vol=5,eff=4},
 {oct=1,ins=5,vol=5,eff=5}
}

------------------------------
-- note map
------------------------------
--base # of "note" sprites
base_sprite=2

--adds note to map if it wasn't
--there, else removes it
function toggle_map(snd,x,y)
 local prev=mget(x,y)
 local sprite=snd+base_sprite-1
 if prev==sprite then
  mset(x,y,0)
 else
  mset(x,y,sprite)
 end
end

--updates the actual sfx with
--data from our map (at the
--column given)
function update_notes(x)
 local note_cnt=0
 for y=0,14 do
  local n=mget(x,y)
  if n>0 and note_cnt<4 then
   local snd=n-base_sprite+1
   add_note(note_cnt,snd,x,y)
   note_cnt+=1
  end
 end
 
 for p=note_cnt,3 do
  del_note(p,x)
 end
end

-- updates all notes based on
-- data in the map
function update_all_notes()
 for x=0,15 do
  update_notes(x)
 end
end

-- removes a note from sfx
-- corresponding to column x
function del_note(pat,x)
 poke_note(pat,x*2,0,0,0,0,0)
end

-- adds a note to sfx
-- corresponding to coords x,y
-- using the given sound
function add_note(pat,snd,x,y)
 local s=sounds[snd]
 local note=scale[15-y][1]
 local octave=scale[15-y][2]+s.oct
 local pos=x*2
 
 poke_note(pat,pos,note,octave,
  s.ins,s.vol,s.eff)
end

-- color map for flashing notes
flash_map = {
 {7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7},
 {6,6,6,6,7,6,7,7,7,7,7,7,7,7,7,7},
 {5,13,8,11,9,6,7,7,14,10,7,11,12,12,15,7},
 {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
}
function draw_notes()
 local gx = guide and guide.x
  or -100
 
 for x=0,15 do
  --draw note shadows
  for clr=1,15 do
   pal(clr,0,0)
  end
  map(x,0,x*8+2,2,1,16)
  pal()
  
  --flash notes when they play
  local d=flr((gx-x*8)/2)+1
  if d>=1 and d<4 then
   local f=flash_map[d]
   for clr=0,15 do
    pal(clr,f[clr+1],0)
   end
  end
  
  --draw notes in this column
  map(x,0,x*8,0,1,16)
 end
 pal()
end

------------------------------
-- utils
------------------------------

function printc(t,x,y,c)
 x-=#t*2
 print(t,x,y,c)
end

------------------------------
-- input
------------------------------
prev_input=0
delay=0
hold=0
function parse_input()
 local inp={
  x=0,y=0,
  b1=false,b2=false,
  held_b2=false
 }
 if delay==0 then
  if (btn(0)) inp.x-=1
  if (btn(1)) inp.x+=1
  if (btn(2)) inp.y-=1
  if (btn(3)) inp.y+=1
  if (btn()) delay=2  
 elseif delay>0 then
  delay-=1
 end
 if prev_input<16 then
  inp.b1=btn(4)
  inp.b2=btn(5)
 end
 if btn(5) then
  hold+=1
  if (hold==10) then
   inp.held_b2=true
  end
 else
  hold=0
 end
 
 prev_input=btn()
 return inp
end

------------------------------
-- guide
------------------------------
guide_advance=1.002
function update_guide()
 if (not guide) return
 guide.x+=guide_advance
 guide.x%=128
end

function draw_guide()
 if (not guide) return
 local sx=guide.x
 rectfill(sx,0,sx,127,12)
 rectfill(sx-2,0,sx-2,127,13)
 rectfill(sx-4,0,sx-4,127,5)
end

function draw_grid()
 for n=0,128,16 do
  rectfill(n,0,n,127,0)
  rectfill(0,n,127,n,0)
 end
end

------------------------------
-- status bar
------------------------------
function draw_status()
 rectfill(0,121,127,127,5)
 rectfill(0,120,127,120,0)
 print("hold x for",
  78,122,6)
 spr(15,120,122)
 
 for i=0,#sounds-1 do
  local s=base_sprite+i
  if (ptr.snd==i+1) then
   rectfill(i*8,126,i*8+7,127,7)
   rectfill(i*8,124,i*8+7,125,6)
  end
  spr(s,i*8,120) 
 end 
end

------------------------------
-- title screen
------------------------------

menu_options={
 "clear song",
 "demo song",
 "load from cart",
 "save to cart",
 nil,
 "play!"
}
function draw_title()
 rectfill(0,16,127,48,0)
 rectfill(0,14,127,14,0)
 rectfill(0,50,127,50,0)
 sspr(0,8,13*8,3*8,
  18,20)
 print("jw",119,41,1)
  
 for n,t in pairs(menu_options) do
  if t then
   if menu_sel==n then
    rectfill(24,54+n*7,127-24,60+n*7,7)
    printc(t,64,55+n*7,0)
   else
    printc(t,64,56+n*7,0)   
    printc(t,65,55+n*7,0)   
    printc(t,64,55+n*7,15)   
   end
  end
 end
end

function update_title()
 local i=parse_input()
 
 -- move menu
 menu_sel+=i.y 
 while not menu_options[menu_sel] do
  menu_sel+=i.y
  if (menu_sel<1) menu_sel=#menu_options
  if (menu_sel>#menu_options) menu_sel=1
 end
 
 -- apply options
 if (i.b1) then
  apply_option(menu_options[menu_sel])
 end
 -- quick exit
 if (i.b2) apply_option("play!")
end

-- applies a menu option when
-- it's activated
function apply_option(op)
 if op=="play!" then
  --yessir!
  _play()
 elseif op=="clear song" then
  --clear map
  for x=0,15 do
   for y=0,15 do
    mset(x,y,0)
   end
  end
  update_all_notes()
 elseif op=="demo song" then
  for x=0,15 do
   for y=0,15 do
    mset(x,y,mget(x+16,y))
   end
  end
  update_all_notes()
 elseif op=="save to cart" then
  --save map data and patterns
  --the patterns are only so
  --you can copy them to other
  --carts and work on your music
  --more, muse only uses the map
  cstore(0x2000,0x2000,0x800)
  cstore(0x3200,0x3200,68*4)
 elseif op=="load from cart" then
  --load map data,update notes
  reload(0x2000,0x800)
  update_all_notes()
 end
end

------------------------------
-- playing
------------------------------

function update_playing()
 local i=parse_input() 
 ptr.x=mid(ptr.x+i.x,0,15)
 ptr.y=mid(ptr.y+i.y,0,14)
 if i.b1 then
  toggle_map(ptr.snd,ptr.x,ptr.y)
  update_notes(ptr.x)
 end
 if i.b2 then
  ptr.snd+=1
  if (ptr.snd>#sounds) ptr.snd=1  
 end
 if (i.held_b2) _pause()
 
 --update music visualization
 update_guide()
end

------------------------------
-- lifecycle methods
------------------------------

function _init()
 -- initialize our globals
 ptr={x=0,y=7,snd=1} 
 -- use the saved note map
 update_all_notes()
 -- start paused
 _pause()
end

-- pair of function for app
-- state control
function _play()
 music(0)
 guide={x=0}
 title=false
end
function _pause()
 music(-1)
 guide=nil
 title=true
 menu_sel=#menu_options
end

function _update()
 if title then
  update_title()
 else
  update_playing()
 end 
end

function _draw()
 rectfill(0,0,128,128,1)
 draw_guide()
 draw_grid()
 draw_notes() 
 draw_status()
 
 if title then
  draw_title() 
 else
  spr(1,ptr.x*8,ptr.y*8)
 end
end
