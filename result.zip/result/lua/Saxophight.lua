--saxophight!    help max the sax
--perform the solo of his career!

--game screen
screen=0 --0:title,1:play,2:lose

--title screen
title_direction=0
title_max_x=52
title_sprite=8
top_score_blues=0
top_score_bebop=0
title_transition=false
title_counter=0
show_instructions=false

--gameover screen
gameover_transition=true
gameover_counter=0
set_gameover=false

--player
p = {}
p.max_dx = 2
p.x_col_l_bound = {6,0} --lower bound for h collision
p.x_col_u_bound = {15,9} --upper bound for h collision
p.player = true
p.sax = 0

spawn = {}
spawn.x = {72,231}
spawn.y = {48,119}
blues_beat = 12 --frames per beat (75 bpm)
bebop_beat = 9 --frames per beat (150 bpm)
g = .15 --gravity acceleration (pixels/frame^2)
max_dy = 7 --terminal vel, prevents going through 8x8 tile
camera_delay = 4

--music stuff
blues_chords = {1,1,1,1,4,4,1,1,5,4,1,5,1,1,1,1,4,4,1,1,5,4,1,1}
blues_bass_pos = {1,1,1,2,1,1,1,0,1,2,1,2,1,0,1,2,0,0,0,2,0,2,0,2,0,0,0,2,0,2,0,1,2,2,2,1,0,0,0,2,0,0,0,1,2,1,2,1,0,1,0,2,0,2,0,2,0,1,0,1,0,2,0,1,2,1,2,1,2,1,2,1,2,0,2,1,2,1,2,0,1,2,1,0,2,0,2,1,2,1,2,1,2,1,2,1}
bebop_chords = {1,2,1,5,4,4,1,5,2,5,1,2,1,2,1,5,4,4,1,5,2,5,1,1}
bebop_bass_pos = {1,2,1,0,2,0,2,1,2,0,1,2,1,0,1,0,2,0,1,2,0,2,1,0,1,0,2,0,1,0,2,1,0,1,2,1,2,1,0,2,0,1,2,1,0,1,0,2,1,2,1,0,1,2,1,0,1,2,0,2,0,1,0,1,2,0,1,2,0,2,1,0,1,0,1,2,0,2,1,2,0,1,2,1,2,1,0,2,1,2,1,0,2,1,2,1}

--unlockables
sax_colors = {true,false,false,false,false}
msg_thresholds = {50,100,200,300,450,600,800,1000,1250,1500,1800,2100}

--messages
bass_msgs = {
 "keep it up, max!",
 "feel the groove",
 "woo!",
 "that's it!",
 "keep that flow, max!",
 "swing it!",
 "blow that horn"
}
drum_msgs = {
 "hot licks, max!",
 "feel the rhythm",
 "keep it movin'",
 "you're killin' it!",
 "solid",
 "break it down",
 "right on!"
}
bar_msgs = {
 "groovin'",
 "dig it!",
 "drink's on me, max!",
 "oh yeah",
 "that's what i'm talkin' about",
 "mhmm",
 "sounds good, max",
 "get down!",
 "jammin'",
 "don't stop!"
}
drink_msgs = {
 "that cat can blow!",
 "yeah!",
 "swingin'",
 "i'm feelin' it",
 "whoa!",
 "he can really wail",
 "swanky!"
}
hat_msgs = {
 "hat's off to you",
 "nice!",
 "toe tappin'!",
 "how's he still going?",
 "ornithological!",
 "he's got some chops",
 "wild"
}
bass_hit_msgs = {
 "oof...",
 "ouch!",
 "stay in key, max!",
 "watch those accidentals!",
 "keep at it!",
 "1 2 3 4"
}
drum_hit_msgs = {
 "get back in the swing",
 "hmm...",
 "relax, max!",
 "err...",
 "bounce back, max!",
 "stay focused"
}
gameover_msgs = {
 "let's take it from the top!",
 "take five",
 "don't blow your top",
 "back to the head",
 "we'll be here all week",
 "don't split just yet!",
 "how 'bout another round?",
 "tune up that sax",
 "take a deep breath"
}

function _init()
 --read high score data, set unlocks
 cartdata("saxophight")
 top_score_blues = dget(0)
 top_score_bebop = dget(1)
 if top_score_blues >= 500 then
 	sax_colors[2] = true
 end
 if top_score_blues >= 1000 then
  sax_colors[4] = true
 end
 if top_score_bebop >= 500 then
  sax_colors[3] = true
 end
 if top_score_bebop >= 1000 then
  sax_colors[5] = true
 end
 
 music(7)
end

--reset the game for another round
--game_mode=0:blues
--game_mode=1:bebop
function reset(game_mode)
 --reset a lot of state
 notes = {}
 shatter = {}
 tpt_spawns = {}
 trumpets = {}
 accidentals = {}
 counter = 0
 camera_follow = {}
 note_counter = 1
 chord_counter = 1
 triplet_flag = false
 arm_in = true
 head_nod = false
 play_snare = false
 play_hihat = false
 snare_counter = 0
 kick_counter = 0
 hihat_counter = 0
 new_unlock = false
 msgs = {}
 for i=1,5 do
  msgs[i] = {}
  msgs[i].text = ""
  msgs[i].counter = 0
 end
 gameover_msg_set = false
 
 --hud
 game_points = 0
 health = 40
 breath = 40
 
 --player initialization
 p.x = 120
 p.y = 112
 p.dx = 0
 p.dy = 0
 p.ddx = 0
 p.dir = 1
 p.state = 0 --0:stand,1:run,2:jump
 p.frame = 0 --animation frame
 p.sprite = 0 --animation offset
 p.jump_reset = false --flag for jump key release
 p.x_col = {0,9} --horizontal collision box
 p.y_col = {0,30} --vertical collision box
 
 for i=1,camera_delay do
  c={}
  c.x = p.x-60
  c.y = p.y-96
  camera_follow[i] = c
 end
 
 --blues- vs bebop-specific
 if (game_mode == 0) then
  beat = blues_beat
  prev_note = 12
  music(0,0)
 else
  beat = bebop_beat
  prev_note = 22
  music(3,0)
 end
end

function h_physics(obj)
 --friction
 if (on_ground(obj)) then
 	if (obj.ddx == 0)	obj.dx *= .9
	end
	
	--update
	obj.dx += obj.ddx
	obj.dx = mid(-obj.max_dx,obj.dx,obj.max_dx)
	obj.x += obj.dx
end

function v_physics(obj)
	--check for not on ground
	if (not on_ground(obj)) then
		obj.state = 2
		obj.jump_reset = false
		obj.dy = mid(-max_dy, obj.dy+g, max_dy)
	else
		--player case: start jump
		if (obj.player and obj.start_jump) then
		 obj.dy = -2
		 obj.state = 2
		 obj.start_jump = false
		end
	end	
	obj.y += obj.dy
end

function v_collision(obj)
 --iteration 1 ceiling, 2 floor
 for i=2,1,-1 do
		in_collision = false
		for j=obj.x_col[1],obj.x_col[2] do
		 v_edge = obj.y+7-obj.y_col[i]
  	if (is_solid(obj.x+j, v_edge)) in_collision=true break
 	end
 	if (in_collision) then
	  obj.dy = 0
   obj.y = flr(v_edge/8)*8+9*i-17+obj.y_col[i]
   return true
	 end
	end
	return false
end

function h_collision(obj)
 --iteration 1 left, 2 right
 for i=1,2 do
		in_collision = false
		for j=obj.y_col[1],obj.y_col[2] do
		 h_edge = obj.x+obj.x_col[i]
  	if (is_solid(h_edge, obj.y+7-j)) in_collision=true break
 	end
 	if (in_collision) then
	  obj.dx = 0
   obj.x = flr(h_edge/8)*8-9*i+17-obj.x_col[i]
   return true
	 end
	end
	return false
end

function check_object_collisions()
 --projectile collision
 for tpt in all(trumpets) do
  for note in all(notes) do
   if (obj_collision(tpt, note)) then
    if (tpt.sprite < 136) then
     game_points += 10
     check_msg_thresholds(10)
	    tpt.sprite += 8
     tpt.frame = 0
	    tpt.dx = 0
	    tpt.dy = -1
 	   play_hihat = true
    end
  	 destroy_note(note)
   end
  end
 end
 
 --collision with player
 for tpt in all(trumpets) do
  if (obj_collision(tpt,p)) then
   if (tpt.sprite<136) then
    hit_player()
    tpt.sprite += 8
    tpt.frame = 0
    push = tpt.dx
    tpt.dx = p.dx
    p.dx += push/2
    tpt.dy = -1
   end
  end
 end
 for accidental in all(accidentals) do
  if (obj_collision(accidental,p)) then
   hit_player()
   p.dx += accidental.dir*accidental.dx/2
   shatter_effect = {}
   shatter_effect.x = accidental.x+avg(accidental.x_col[1],accidental.x_col[2]-4)
   shatter_effect.y = accidental.y+avg(accidental.y_col[1],accidental.y_col[2]-4)
   shatter_effect.sprite=188
   add(shatter, shatter_effect)
   del(accidentals, accidental)
   if rnd(1) < .5 then
    if rnd(1) < .5 then
     msgs[1].text = rnd_msg(bass_hit_msgs)
     msgs[1].counter = 240
     msgs[2].counter = 0
    else
     msgs[2].text = rnd_msg(drum_hit_msgs)
     msgs[2].counter = 240
     msgs[1].counter = 0
    end
   end
  end
 end
end

function hit_player()
 play_snare = true
 health -= 2.5
 if (health<0) then
 	health=0
 	set_gameover = true
 	
 end
end

function obj_collision(obj1, obj2)
	y1 = obj1.y
	y2 = obj2.y
	if (obj1==p) y1+=7
	if (obj2==p) y2+=7
	c1 = obj1.x+obj1.x_col[1]
	c2 = obj1.x+obj1.x_col[2]
	c3 = obj2.x+obj2.x_col[1]
	c4 = obj2.x+obj2.x_col[2]
	c5 = y1-obj1.y_col[1]
	c6 = y1-obj1.y_col[2]
	c7 = y2-obj2.y_col[1]
	c8 = y2-obj2.y_col[2]
 return (c1<c4 and c2>c3 and c7>c6 and c8<c5)
end

function on_ground(obj)
 for i=obj.x_col[1],obj.x_col[2] do
 	if (is_solid(obj.x+i, obj.y-obj.y_col[1]+8)) return true
 end
 return false
end

function against_wall(obj,dir)
	for j=obj.y_col[1],obj.y_col[2] do
		if (is_solid(obj.x+obj.x_col[.5*dir+1.5]+dir,obj.y+7-j)) return true
	end
	return false
end

function is_solid(x,y)
 return fget(mget(x/8, y/8)) == 1
end

function turn(dir)
 if (p.dir == -dir) p.x += dir*8
 p.dir = dir
 i = .5*dir+1.5
 p.x_col = {p.x_col_l_bound[i],p.x_col_u_bound[i]}
end

function run_p(dir)
 turn(dir)
	p.ddx = p.dir*.2
	if (p.state==0) p.state=1 p.frame=0
end

function air_drift(dir)
	turn(dir)
	p.ddx = p.dir*.1
end

function blow()
 if (breath <= 0) breath=0 return
 breath -= 0.25
 if (breath<0) breath=0
 
 if (counter == 0) blow_note(0) prev_note=-1
 
 if (counter == flr(1/3*beat)) then
  if (rnd(1) > .8) then
   blow_note(1)
   triplet_flag = true
  else
   triplet_flag = false
  end
 end
 
 if (counter == flr(2/3*beat) and (triplet_flag or rnd(1) > .5)) then
  blow_note(2)
  triplet_flag = false
 end
end

--length:
 --0 for full
 --1 for middle triplet
 --2 for eighth
function blow_note(length)
 --determine note
 if (prev_note==-1) then
  if (length==1 or length==2) then
   note_sfx = select_note(1)
  else
   note_sfx = select_note(3)
  end
 else
  if length==0 then
   note_sfx = select_note(4)
  elseif length==1 then
   note_sfx = select_note(2)
  else
   if triplet_flag then
    note_sfx = select_note(2)
   else
    note_sfx = select_note(5)
   end
  end
 end

 --save note
 prev_note = note_sfx
 
 --play note
 if (length==2) length=1
	sfx(note_sfx,3,length)
	
	--set visual orientation
	orientation=0
	if beat == blues_beat then
		if (note_sfx > 11) orientation=1
	else
	 if (note_sfx > 30) orientation=1
	end

 --phyiscal note
 if (btn(2)) then
	 create_note(.75,-3.5,orientation)
	else
	 if (btn(3)) then
	  if on_ground(p) then
		  create_note(2.25,-2,orientation)
		 else
		 create_note(2.25,0,orientation)
		 end
	 else
	  create_note(1.25,-2.85,orientation)
	 end
	end
end

--option 1: random
--option 2: prev_note
--option 3: chord
--option 4: chord+prev_note
--option 5: chord(light)+prev_note
function select_note(option)
 if beat == blues_beat then
  dist_size = 13
  sfx_offset = 5
 else
  dist_size = 17
  sfx_offset = 21
 end
 
 if (option==1) return flr(rnd(dist_size)) + sfx_offset + 1

	last_note = prev_note-sfx_offset
	 
 pdist={}
 for i=1,dist_size do
  pdist[i]=0.0
 end

 if (option==2 or option==4 or option==5) then
	 --add prev_note chance
	 pdist[last_note] += 1
	 if (last_note+1<=dist_size) pdist[last_note+1] += 1
	 if (last_note+2<=dist_size) pdist[last_note+2] += 0.5
	 if (last_note+3<=dist_size) pdist[last_note+3] += 0.25
	 if (last_note-1>0) pdist[last_note-1] += 1
	 if (last_note-2>0) pdist[last_note-2] += 0.5
	 if (last_note-3>0) pdist[last_note-3] += 0.25	
	 
	 if (last_note+5<=dist_size) then
	  for i=last_note+5,dist_size do
	   pdist[i] -= 0.5
	  end
	 end
	 if (last_note-5>1) then
	  for i=last_note-5,1 do
	   pdist[i] -= 0.5
	  end
	 end
 end

 if (option==3 or option==4) then
  if beat == blues_beat then
	  pdist = add_chord(pdist,blues_chords[chord_counter],1.0)
	 else
	  pdist = add_chord(pdist,bebop_chords[chord_counter],1.0)
	 end
 end

 if (option==5) then
  if beat == blues_beat then
	  pdist = add_chord(pdist,blues_chords[chord_counter],0.5)
	 else
	  pdist = add_chord(pdist,bebop_chords[chord_counter],0.5)
	 end
 end

 pdist_sum = 0
 for i=1,dist_size do
  if (pdist[i] < 0) pdist[i]=0
  pdist_sum += pdist[i]
 end
 for i=1,dist_size do
  pdist[i] /= pdist_sum
 end

 --select from distribution
 randnote = rnd(1)
 sum = 0
 for i=1,dist_size do
  sum += pdist[i]
  if (sum >= randnote) then
   return i+sfx_offset
  end
 end
 
 return 1+sfx_offset
end

function add_chord(dist,chord,value)
 if beat == blues_beat then
  --blues chords
  if chord==1 then
   dist[1] += value
   dist[2] += value
   dist[5] += value
   dist[7] += value
   dist[8] += value
   dist[11] += value
   dist[13] += value
  elseif chord==4 then
   dist[1] += value
   dist[3] += value
   dist[7] += value
   dist[9] += value
   dist[13] += value 
  elseif chord==5 then
   dist[5] += value
   dist[6] += value
   dist[11] += value
   dist[12] += value
  end
 else
  --bebop chords
  if chord==1 then
   dist[1] += value
   dist[3] += value
   dist[5] += value
   dist[8] += value
   dist[9] += value
   dist[11] += value
   dist[13] += value
   dist[16] += value
  elseif chord==2 then
   dist[2] += value
   dist[4] += value
   dist[7] += value
   dist[10] += value 
   dist[12] += value
   dist[15] += value
  elseif chord==4 then
   dist[1] += value
   dist[4] += value
   dist[7] += value
   dist[9] += value
   dist[12] += value 
   dist[15] += value
   dist[17] += value
  elseif chord==5 then
   dist[2] += value
   dist[5] += value
   dist[8] += value
   dist[10] += value
   dist[13] += value
   dist[16] += value
  end
 end
 return dist
end

function move_note(note)
	h_physics(note)
	if(h_collision(note) and screen==1) destroy_note(note)
	v_physics(note)
	if(v_collision(note) and screen==1) destroy_note(note)
end

function move_trumpet(tpt)
 h_physics(tpt)
 h_collision(tpt)
 v_physics(tpt)
 if (v_collision(tpt) and tpt.sprite < 136 and on_ground(tpt)) then
  tpt.sprite += 8
  tpt.frame = 0
 end
end

function move_accidental(accidental)
 if accidental.dx~=0 then
  accidental.x += accidental.dir*accidental.dx
  accidental.y = accidental.base_y + accidental.amp*sin(accidental.x*accidental.scale)
 end 
 
 if accidental.x>304 or accidental.x<0 then
  del(accidentals, accidental)
 end
end

function standard_physics(obj)
 h_physics(obj)
 h_collision(obj)
 v_physics(obj)
 v_collision(obj)
end

function destroy_note(note)
 shatter_effect = {}
 shatter_effect.x = note.x+avg(note.x_col[1],note.x_col[2]-4)
 shatter_effect.y = note.y+avg(note.y_col[1],note.y_col[2]-4)
 shatter_effect.sprite=188
 add(shatter, shatter_effect)
 del(notes, note)
end

function avg(a,b)
 return (a+b)/2
end

--orientation=0 for low notes
--orientation=1 for high notes
function create_note(dx,dy,orientation)
 n = flr(rnd(6))
 x_col = {0,3}
 y_col = {0,7}
 if (n == 1 or n == 4) x_col[2] = 7
 if (n == 2) x_col[2] = 5
 if (n == 5) x_col[2] = 4
 x = p.x
 if (p.dir == 1) x+=12
 y = p.y-16

 if (orientation == 1) n+=6
 
 note = create_object(176+n,x,y,p.dir*dx,dy,x_col,y_col)
 add(notes,note)
end

function spawn_enemies()
 if (#tpt_spawns+#trumpets <= max(sqrt(min(game_points,500)/3),3) and rnd(1) > .75) then
  tpt_spawn = create_trumpet_spawn()
  add(tpt_spawns, tpt_spawn)
 end
 if beat == bebop_beat then
  if #accidentals < 1 and rnd(1) > .95 then
   create_accidental()
  end
 end 
end

function generate_spawn_point()
 point = {}
 point.x = generate_spawn_coord(spawn.x)
 point.y = generate_spawn_coord(spawn.y)
 return point
end

function generate_spawn_coord(bounds)
 return rnd(bounds[2]-bounds[1])+bounds[1]
end

function create_trumpet_spawn()
 point = generate_spawn_point()
 while (close_to_player(point)) do
  point = generate_spawn_point()
 end
 dx = rnd(1.5)+1
 if (point.x > p.x) dx*=-1
 --if (rnd(1) < .5) dx*=-1
 dy = rnd(3)-3
 return create_object(144,point.x,point.y,dx,dy,{1,6},{1,6})
end

function create_trumpet(tpt_spawn)
 n = flr(rnd(8))
 del(tpt_spawns, tpt_spawn)
 return create_object(128+n,tpt_spawn.x,tpt_spawn.y,tpt_spawn.dx,tpt_spawn.dy,{1,6},{1,6})
end

function close_to_player(spawn)
 dx = p.x+7.5-spawn.x
 dy = p.y-7.5-spawn.y
 dst = sqrt(dx*dx+dy*dy)
 return dst < 32
end

function create_accidental()
 spr_offset = flr(rnd(3))
 x_col = {0,4}
 y_col = {0,7}
 if spr_offset==0 then
  x_col[2] = 5
 end
 --y:112-128
 spr_y = 112 + flr(rnd(17))
 spr_dx = 1 + rnd(.4)
 accidental = create_object(160+spr_offset,0,spr_y,spr_dx,0,x_col,y_col)
 if rnd(1) > 0.5 then
  accidental.x = 304
  accidental.dir = -1
 end
 accidental.base_y = accidental.y
 accidental.scale = rnd(.01) + 0.005
 accidental.amp = flr(rnd(5)) + 6
 add(accidentals, accidental)
end

function create_object(sprite,x,y,dx,dy,x_col,y_col)
 object = {}
	object.sprite=sprite
	object.x=x
	object.y=y
	object.dx=dx
	object.dy=dy
	object.x_col=x_col
	object.y_col=y_col
	
	--default values for simple objects
	object.ddx=0
	object.max_dx=7
	object.player=false
	object.dir=1
	object.frame=0
	
	return object
end

function update_animations()
 p.frame += 1
 p.frame %= 32
 
 if (p.state == 2 and on_ground(p)) p.state=0
 if (p.state == 0) p.sprite=0
 if (p.state == 1) then
  if (p.frame < 32) p.sprite=0
  if (p.frame < 24) p.sprite=4
  if (p.frame < 16) p.sprite=0
  if (p.frame < 8) p.sprite=2 
  if (against_wall(p,p.dir)) p.sprite=0 p.state=0
 end
 if (p.state == 2) p.sprite=6
 
 foreach(trumpets,update_tpt_animation)
end

function update_tpt_animation(tpt)
 --fallen trumpet
 if tpt.sprite >= 136 then
 	tpt.frame += 1
 	if tpt.frame > 120 then
 	 del(trumpets, tpt)
 	 game_points+=1
 	 check_msg_thresholds(1)
 	end
  return
 end
  
 --active trumpet
 tpt.frame = (tpt.frame+1)%20
 tpt.sprite = 128+flr(tpt.frame/2.5)
end

function update_effects()
 foreach(shatter,update_shatter)
 foreach(tpt_spawns,update_tpt_spawn)
end

function update_shatter(s)
 s.sprite += 1
 if (s.sprite > 191) del(shatter,s)
end

function update_tpt_spawn(tpt_spawn)
 tpt_spawn.frame += 1
 if (tpt_spawn.frame > 15) then
  tpt = create_trumpet(tpt_spawn)
  add(trumpets, tpt)
  del(tpt_spawns, tpt_spawn)
 else
  tpt_spawn.sprite = 144+tpt_spawn.frame
 end
end

function update_music()
	counter += 1
	if (counter >= beat) then
		note_counter += 1
		if (note_counter > 4) then
			chord_counter += 1
			if beat == blues_beat then
				if (chord_counter == 9) music(1,0)
				if (chord_counter == 17) music(2,0)
				if (chord_counter > #blues_chords) then
			  chord_counter = 1
			  music(0,0)
			 end
			else
			 if (chord_counter == 9) music(4,0)
			 if (chord_counter == 17) music(5,0)
			 if (chord_counter > #bebop_chords) then
			  chord_counter = 1
			  music(3,0)
			 end
			end
			note_counter = 1
		end
		counter = 0
	end
end

function update_drums()
 if counter == 0 and breath<14 then
  sfx(20,1)
  kick_counter = 4
 end
 if counter == 0 or counter == flr(2/3*beat) then
  if play_snare then
   sfx(19,2)
   snare_counter = 4
   play_snare = false
  elseif play_hihat then
   sfx(21,2)
   hihat_counter = 4
   play_hihat = false
  end
 end
end

function freeze_objects()
 for tpt in all(trumpets) do
  if (tpt.sprite < 136) then
	  tpt.sprite += 8
   tpt.frame = 0
  end
  tpt.dx = 0
	 tpt.dy = 0
	 tpt.ddx = 0
 end
 for note in all(notes) do
	  note.dx = 0
	  note.dy = 0
	  note.ddx = 0
 end
 for accidental in all(accidentals) do
  accidental.dx = 0
  accidental.dy = 0
  accidental.ddx = 0
 end
end

function update_msgs()
 for i=1,5 do
  msgs[i].counter = max(msgs[i].counter - 1, 0)
 end
end

function check_msg_thresholds(change)
 for i=1,#msg_thresholds do
  if game_points>=msg_thresholds[i] and game_points-change<msg_thresholds[i] then
   create_msgs()
   return
  end
 end
end

function create_msgs()
 msg_chance = .333
 if game_points>=500 then
  msg_chance = .5
 elseif game_points>=1000 then
  msg_chance = .667
 end
 
 --musicians
 if rnd(1) < msg_chance then
  if rnd(1) < .5 then
	  msgs[1].text = rnd_msg(bass_msgs)
 	 msgs[1].counter = 240
 	 msgs[2].counter = 0
 	else
 	 msgs[2].text = rnd_msg(drum_msgs)
 	 msgs[2].counter = 240
 	 msgs[1].counter = 0
 	end
 end
 
 --bartender
 if rnd(1) < msg_chance then
  msgs[3].text = rnd_msg(bar_msgs)
  msgs[3].counter = 240
 end
 
 --listeners
 if rnd(1) < msg_chance then
  if rnd(1) < .5 then
	  msgs[4].text = rnd_msg(drink_msgs)
 	 msgs[4].counter = 240
 	 msgs[5].counter = 0
 	else
 	 msgs[5].text = rnd_msg(hat_msgs)
 	 msgs[5].counter = 240
 	 msgs[4].counter = 0
 	end
 end
end

function rnd_msg(msg_list)
 return msg_list[flr(rnd(#msg_list))+1]
end

function _update()
 if screen == 0 then
  if not title_transition then	 
  title_counter = (title_counter+1)%120 
	  if not show_instructions then
	  
	   if btnp(1) then
	    title_direction = 1
     title_max_x = 60
     title_sprite = 0
    end
   
    if btnp(0) then
     title_max_x = 52
     title_direction = 0
     title_sprite = 8
    end
   
    if btnp(2) then
     p.sax = (p.sax + 1) % 5
     while not sax_colors[p.sax+1] do
      p.sax = (p.sax + 1) % 5
     end
    elseif btnp(3) then
     p.sax = (p.sax - 1) % 5
     while not sax_colors[p.sax+1] do
      p.sax = (p.sax - 1) % 5
     end
    end
   
    if btnp(4) then
     music(-1)
     title_transition = true
     sfx(19,3)
    elseif btnp(5) then
     show_instructions = true
     instruction_page = 1
    end
   else
    if btnp(4) or btnp(5) then
     instruction_page += 1
     if instruction_page > 2 then
      show_instructions = false
     end
    end
   end
  else
   --walk off screen
   if (title_max_x <= 28 and (title_max_x-4)%12 == 0) or (title_max_x >=96 and (title_max_x+3)%9 == 0) then
    sfx(21,1)
   end
   title_max_x += title_direction*2-1
   
   --title_max_x += 1
   if title_max_x <= -68 or title_max_x >= 168 then
    screen = 1
    reset(title_direction)
    if title_direction == 0 then
     title_max_x = 52
     title_sprite = 8
    else
     title_max_x = 60
     title_sprite = 0
    end
    title_transition = false
    title_counter = 0
   else
   --set sprite
    if title_direction == 0 then
     if title_max_x > 40 or (title_max_x <= 4 and title_max_x > -8) then
      title_sprite = 10
     elseif (title_max_x <= 28 and title_max_x > 16) or title_max_x <= -20 then
      title_sprite = 12
     else
      title_sprite = 8
     end
    else
     if title_max_x < 69 or (title_max_x >= 96 and title_max_x < 105) or title_max_x >= 132 then
      title_sprite = 2
     elseif (title_max_x >= 78 and title_max_x < 87) or (title_max_x >= 114 and title_max_x < 123) then
      title_sprite = 4
     else
      title_sprite = 0
     end
    end
   end
  end
 end

 if screen == 1 then  
  --update the state of the world
  foreach(notes, move_note)
  foreach(trumpets, move_trumpet)
  foreach(accidentals, move_accidental)
    
  --player actions
	 --horizontal movement
	 p_on_ground = on_ground(p)
	 if (p_on_ground) then
	 	if (btn(0) and not against_wall(p,-1)) run_p(-1)
	 	if (btn(1) and not against_wall(p,1)) run_p(1)
	 	if (not btn(0) and not btn(1)) then
	 		p.ddx=0
	 	 p.state=0
	 	 p.frame=0
	 	end
	 else
	  if (btn(0)) air_drift(-1)
	 	if (btn(1)) air_drift(1)
	 	if (not btn(0) and not btn(1)) p.ddx=0
	 end
	
 	--jump
 	if (on_ground(p)) then
	  if (p.jump_reset) then
		 	if (btn(4) and p.jump_reset) then
			 	p.start_jump=true
			 	p.jump_reset = false
			 end
		 else
			 if (not btn(4)) p.jump_reset = true
		 end
	 end
	
	 --blow
	 if (btn(5)) then
	 	blow()
	 else
	 	breath = min(breath+1,40)	 	
	 end

  --update player position
	 standard_physics(p)
	
	 check_object_collisions()
  update_effects()
	
	 --create new enemies
	 spawn_enemies()
	
	 --final state updates
	 update_drums()
	 update_animations()
	 update_music()
	 update_msgs()
	 
	 --gameover check
	 if set_gameover then
	  music(-1,0)
	  music(6)
   screen=2
   freeze_objects()
   set_gameover = false
	 end
 end
 
 if screen == 2 then
  if gameover_transition then
   foreach(notes, move_note)
   foreach(trumpets, move_trumpet)
   gameover_counter += 1
   if gameover_counter > 244 then
    gameover_transition = false
   end
  else
   --wait for input
   if btnp(4) or btnp(5) then
    if beat == blues_beat then
     if game_points > top_score_blues then
      top_score_blues = game_points
      dset(0,top_score_blues)
     end
    else
     if game_points > top_score_bebop then
      top_score_bebop = game_points
      dset(1,top_score_bebop)
     end
    end
    screen = 0
    gameover_counter = 0
    gameover_transition = true
    music(7)
   end
  end
 end
end

function update_camera()
 newc = {}
 --center camera at the middle of the hitbox
	newc.x = p.x-64-4*p.dir+8
	newc.y = p.y-96
	
	camera_follow[camera_delay+1] = newc
	for i=1,camera_delay do
		camera_follow[i] = camera_follow[i+1]
	end
	
	camera(camera_follow[1].x,camera_follow[1].y)
end

function update_background()
 --sign flicker
 if mget(5,7) == 77 then
  if rnd(1) < 0.05 then
   mset(5,7,109)
   mset(6,7,110)
   mset(7,7,111)
   mset(5,8,125)
   mset(6,8,126)
   mset(7,8,127)
  end
 else
  if rnd(1) < 0.1 then
   mset(5,7,77)
   mset(6,7,78)
   mset(7,7,79)
   mset(5,8,93)
   mset(6,8,94)
   mset(7,8,95)
  end
 end
 
 --background characters
 if chord_counter%2 == 0 then
  if (note_counter == 3 and not arm_in) arm_in = true
 else
  if (note_counter == 3 and arm_in) arm_in = false
 end
 
 if chord_counter%2 == 0 then
  if (not head_nod) head_nod = true
 else
  if (head_nod) head_nod = false 
 end
end

function draw_background_chars()
 --bass player
 spr(192,88,80)
 bass_frame=(chord_counter-1)*4+note_counter
 bass_sprite=193
 if beat == blues_beat then
  if blues_bass_pos[bass_frame] == 0 then
   bass_sprite=194
  end
  if blues_bass_pos[bass_frame] == 2 then
   bass_sprite=241
  end
 else
  if bebop_bass_pos[bass_frame] == 0 then
   bass_sprite=194
  end
  if bebop_bass_pos[bass_frame] == 2 then
   bass_sprite=241
  end
 end
 spr(bass_sprite,96,80)
 if bass_frame%2 == 1 then
	 spr(208,88,88)
	else
	 spr(240,88,88)
	end
	spr(209,96,88)
	spr(224,88,96)
	spr(225,96,96)
	
	--drummer
	spr(200,116,80)
	if snare_counter > 0 then
	 spr(248,116,88)
	 snare_counter -= 1
	else
	 spr(216,116,88)
	end
	if kick_counter > 0 then
	 spr(245,108,96,2,1)
	 kick_counter -= 1
	else
	 spr(231,108,96,2,1)
	end
	if hihat_counter > 0 then
	 spr(201,108,80)
	 spr(247,108,88)
	 hihat_counter -= 1
	else
	 spr(199,108,80)
	 spr(215,108,88)
	end

	--hat tipper
	if head_nod then
		spr(195,192,80,2,2)
	else
	 spr(210,192,80)
	 spr(244,200,80)
	 spr(242,192,88,2,1)
	end
	
	--drink nurser
 if arm_in then
  spr(197,184,80,1,2)
 else
  spr(198,184,80,1,2)
 end

 --bartender
 tender_left_x = 144
 tender_right_x = 152
 tender_flipped = false
 if p.x>=148 then
		tender_flipped = true
		tender_left_x = 152
		tender_right_x = 144
 end
 spr(217,144,80,2,1,tender_flipped)
 spr(233,tender_left_x,88,1,1,tender_flipped)
 if note_counter%2==0 then
  spr(234,tender_right_x,88,1,1,tender_flipped)
 elseif note_counter==1 then
  spr(235,tender_right_x,88,1,1,tender_flipped)
 else
  spr(251,tender_right_x,88,1,1,tender_flipped)
 end
 spr(249,144,96,2,1)
 spr(203,136,88,1,2)
 spr(203,160,88,1,2,true)
 
 --legs
	if bass_frame%2==1 then
 	spr(226,192,96)
 	spr(230,184,96,1,1)
 else
  spr(227,192,96)
  spr(229,184,96,1,1)
 end
	spr(228,200,96)
 
end

function draw_notes()
 foreach(notes, draw_spr)
end

function draw_effects()
 foreach(shatter, draw_spr)
 foreach(tpt_spawns, draw_spr)
end

function draw_enemies()
 foreach(trumpets, draw_spr)
 foreach(accidentals, draw_spr)
end

function draw_spr(s)
 spr(s.sprite, s.x, s.y)
end

function draw_hud()
 camera()
 color(6)
 rect(2,2,44,8)
 rect(83,2,125,8)
 
 --meters
 
 color(2)
 rect(3,3,3+health,7)
 if (health >= 1) then
  color(8)
  rectfill(3,3,3+health-1,6)
 end
 
 color(1)
 rect(124-breath,3,124,7)
 if (breath >= 1) then
 	color(12)
 	rectfill(124-breath+1,3,124,6)
 end

 --score 
 print_centered_n(game_points,65,4,3)
 print_centered_n(game_points,64,3,11)
 
end

function print_centered(text,tx,ty,tcol,numspecial)
 if tcol == nil then
 	tcol = 6
 end
 if numspecial == nil then
  numspecial = 0
 end
 print(text, tx-#text*2-numspecial*3/2, ty, tcol)
end

--print centered for numbers
function print_centered_n(number,tx,ty,tcol)
 temp_number = number
 ndigits = 1
 while (temp_number > 9) do
  temp_number = flr(temp_number/10)
  ndigits += 1
 end
 print(number, tx-ndigits*2, ty, tcol)
end

function set_sax_color()
 if p.sax == 1 then
		pal(9,13)
		pal(10,7)
	elseif p.sax == 2 then
	 pal(9,4)
	 pal(10,9)
	elseif p.sax == 3 then
	 pal(9,2)
	 pal(10,0)
	elseif p.sax == 4 then
	 pal(10,7)
	 pal(9,15)
	end
end

function reset_sax_color()
 pal(9,9)
 pal(10,10)
end

function instruction(page)
 rectfill(11,11,119,119,0)
 rectfill(10,10,118,118,1)
 rect(12,12,116,116,6)
 if page == 1 then
  palt(11,true)
  palt(0,false)
  spr(0,18,18,2,2)
  palt(11,false)
  palt(0,true)
  print("guide max the sax",42,20,6)
  print("through his solo",42,28,6)
  
  spr(137,18,42)
  spr(134,26,42)
  print("avoid trumpets",42,44,6)
  
  spr(180,18,58)
  spr(187,26,58)
  print("protect max by",42,60,6)
  print("playing notes",42,68,6)
  
  spr(160,18,84)
  spr(161,26,84)
  print("beware of extra",42,86,6)
  print("bebop accidentals",42,94,6)
  
  print("1/2",100,106,6)
 else
  print("title screen",18,18,6)
  print("⬅️➡️",22,26,6)
  print("select genre",42,26,6)
  print("⬆️⬇️",22,34,6)
  print("select saxophone",42,34,6)
  print("playing a solo",18,50,6)
  print("⬅️➡️",22,58,6)
  print("move",42,58,6)
  print("🅾️/z",22,66,6)
  print("jump",42,66,6)
  print("❎/x",22,74,6)
  print("blow",42,74,6)
  print("⬆️⬇️",22,82,6)
  print("angle notes",42,82,6)
  print("2/2",100,106,6)
  
  palt(11,true)
  palt(0,true)
  spr(192,18,90,2,3)
  spr(199,34,90,2,3)
  palt(0,true)
  palt(11,false)
 end
end

function draw_comments()
 for i=1,5 do
  if msgs[i].counter > 0 then
   msg_y = 72
   if i==1 then
    msg_x = 93
    msg_color = 8
   elseif i==2 then
    msg_x = 116
    msg_color = 9
   elseif i==3 then
    msg_x = 153
    msg_color = 6
    for i=1,5 do
     if i~=3 and msgs[i].counter > 0 then
      msg_y = 64
     end
    end
   elseif i==4 then
    msg_x = 188
    msg_color = 14
   else
    msg_x = 199
    msg_color = 15
   end
   print_centered(msgs[i].text, msg_x, msg_y, msg_color)
  end
 end
end

function _draw()

 cls()

 if screen == 0 then
  --render title screen text
  print_centered("saxophight",65,2,4)
  print_centered("saxophight",64,1,10)
  print_centered("help max the sax make his",64,8)
  print_centered("way in the cutthroat world of",64,14)
  print_centered("underground jazz",64,20)
  
  blues_color1 = 5
  blues_color2 = 6
  bebop_color1 = 5
  bebop_color2 = 6
  
  if title_direction == 0 then
   blues_color1 = 1
   blues_color2 = 12
  else
   bebop_color1 = 2
   bebop_color2 = 8
  end
  
  print_centered("blues",33,39,blues_color1)
  print_centered("blues",32,38,blues_color2)
  print_centered_n(top_score_blues,33,46,blues_color1)
  print_centered_n(top_score_blues,32,45,blues_color2)
  
  print_centered("bebop",97,39,bebop_color1)  
  print_centered("bebop",96,38,bebop_color2)
  print_centered_n(top_score_bebop,97,46,bebop_color1)
  print_centered_n(top_score_bebop,96,45,bebop_color2)
		
		--render title screen scene
		for i=0,16 do
			spr(64,i*8,88,1,2)
			spr(97,i*8,104)
		end
		
		--render saxophone selection
		sax_msg = "saxophone: "
		if p.sax == 1 then
		 sax_msg = sax_msg.."silver"
		elseif p.sax == 2 then
		 sax_msg = sax_msg.."bronze"
		elseif p.sax == 3 then
		 sax_msg = sax_msg.."black lacquer"
		elseif p.sax == 4 then
		 sax_msg = sax_msg.."grafton"
		else
		 sax_msg = sax_msg.."classic"
		end
			
		print_centered(sax_msg,63,112,6)

		--render instructions
		if not title_transition then
		 if title_counter >= 30 and title_counter < 60 then
		  print_centered("press 🅾️/z to start",63,120,6,1)
		 elseif title_counter >= 90 then
		 	print_centered("press ❎/x for instructions",63,120,6,1)
		 end
		end
		
		--render title screen max
		palt(0,false)
		palt(11,true)
		set_sax_color()
		if title_direction == 0 then
		 spr(title_sprite,title_max_x,72,2,4)
		else
		 spr(title_sprite,title_max_x,72,2,4)
		end
		pal(9,9)
		pal(10,10)
		palt(0,true)
		
		--render ready text
		if title_max_x <= -20 and title_max_x > -32 then
		print_centered("one           ",64,64,6)
		elseif title_max_x <= -32 and title_max_x > -44 then
		 print_centered("one more      ",64,64,6)
		elseif title_max_x <= -44 and title_max_x > -56 then
		 print_centered("one more time ",64,64,6) 
		elseif title_max_x <= -56 then
 		print_centered("one more time!",64,64,6)
		end
		if title_max_x >= 132 and title_max_x < 141 then
		print_centered("one           ",64,64,6)
		elseif title_max_x >= 141 and title_max_x < 150 then
		 print_centered("one more      ",64,64,6)
		elseif title_max_x >= 150 and title_max_x < 159 then
		 print_centered("one more once ",64,64,6)
		elseif title_max_x >= 159 then
		 print_centered("one more once!",64,64,6)
		end

  --render instruction page
		if show_instructions then
   instruction(instruction_page)
  end
 elseif screen == 1 then
  --render background
  update_camera()
  update_background()
	 map(0,0,0,0,48,32)
  
  --render background characters
  palt(0,false)
  palt(11,true)
  draw_background_chars()
  draw_comments()
	 
	 --render max the sax
	 sprite = p.sprite
	 set_sax_color()
	 if (p.dir == -1) sprite+=8
	 for shift=0,48,16 do
	 	spr(48-shift+sprite, p.x, p.y-shift/2)
	 	spr(49-shift+sprite, p.x+8, p.y-shift/2)
	 end
	 reset_sax_color()
	 
	 palt(0,true)
	 
	 --render the brass enemies
	 draw_enemies()
	 
	 --render music notes
	 draw_notes()
	 
	 --render effects
	 draw_effects()
  
  --render hud
  draw_hud()
 elseif screen == 2 then
  if gameover_counter < 154 then
   --render (mostly) frozen scene
   update_camera()
	  map(0,0,0,0,48,32)

   palt(0,false)
   palt(11,true)
   draw_background_chars()
	  sprite = p.sprite
	  if (p.dir == -1) sprite+=8
	  for shift=0,48,16 do
	  	spr(48-shift+sprite, p.x, p.y-shift/2)
	  	spr(49-shift+sprite, p.x+8, p.y-shift/2)
	  end
 	 palt(0,true)
	  draw_enemies()
	  draw_notes()
   draw_hud()
  
   --render transition effects
   if gameover_counter > 90 then
    rectfill(0,0,128,(gameover_counter-90)*2,0)
   end
  else
   --render phrase and final score
   print_centered("final score",64,48,5)
   print_centered("final score",63,47,6)
   if gameover_counter > 184 then
    print_centered_n(game_points,64,56,3)
    print_centered_n(game_points,63,55,11)
   end
   if gameover_counter > 214 then
    if beat == blues_beat then
     if game_points > top_score_blues then
      print_centered("top performance!",64,64,4)
      print_centered("top performance!",63,63,10)
     end
     if not sax_colors[2] then
      if game_points >= 500 then
       sax_colors[2] = true
       new_unlock = true
      end
     end
     if not sax_colors[4] then
      if game_points >= 1000 then
       sax_colors[4] = true
       new_unlock = true
      end
     end
    else
     if game_points > top_score_bebop then
      print_centered("top performance!",64,64,4)
      print_centered("top performance!",63,63,10)
     end
     if not sax_colors[3] then
      if game_points >= 500 then
       sax_colors[3] = true
       new_unlock = true
      end
     end
     if not sax_colors[5] then
      if game_points >= 1000 then
       sax_colors[5] = true
       new_unlock = true
      end
     end
    end
    if new_unlock then
     print_centered("new sax unlocked!",64,72,4)
     print_centered("new sax unlocked!",63,71,10)
    end
   end
   if gameover_counter > 244 then
    if beat == blues_beat then
     replay_text_color1 = 1
     replay_text_color2 = 12
    else
     replay_text_color1 = 2
     replay_text_color2 = 8
    end
    if not gameover_msg_set then
	    gameover_msg = rnd_msg(gameover_msgs)
	    gameover_msg_set = true
	   end
    print_centered(gameover_msg,64,80,replay_text_color1)
    print_centered(gameover_msg,63,79,replay_text_color2)
   end
  end
 end
end