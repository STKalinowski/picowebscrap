-- netty
-- andrew minnich
cartdata("tesselode_netty")



-- state management
state = {}

function gotostate(s, ...)
 menuitem(4)
 state.current = s
 state.current:enter(...)
end



-- camera shakes
shake = {}
shake.launch = {
 {-1, -1},
 {-1, -1},
 {-1, -1},
 {1, 1},
 {1, 1},
 {1, 1},
 {1, -1},
 {1, -1},
 {1, -1},
 {-1, 1},
 {-1, 1},
 {-1, 1},
 {0, 0},
}


-- grid palettes
gridpalette = {
 {1, 0, 0, 6, 12, 'netty'},
 {0, 1, 1, 5, 1, 'nite',},
 {3, 11, 11, 11, 3, 'circuit',},
 {5, 0, 0, 0, 0, 'lumines',},
 {0, 0, 8, 8, 8, 'evil',},
 {13, 1, 1, 6, 1, 'murky',},
 {4, 9, 15, 4, 9, 'waffle',},
 {9, 0, 0, 10, 9, 'bee',},
 {8, 2, 2, 6, 14, 'punch',},
 {14, 14, 12, 6, 12, 'cute',},
 {7, 6, 6, 7, 7, 'sterile',},
 {0, 1, 0, 0, 7, 'depths',},
}


-- extra functions
function printc(s, x, y, c, glyphs)
 glyphs = glyphs or 0
 s = s .. ''
 x -= #s * 2 + glyphs * 2
 print(s, x, y, c)
end

function shakecamera(sequence)
 cam.sequence = sequence
 cam.frame = 1
end

function sign(x)
 if x < 0 then
  return -1
 elseif x > 0 then
  return 1
 else
  return 0
 end
end

function clamp(x, a, b)
 if x < a then
  return a
 elseif x > b then
  return b
 else
  return x
 end
end

function lerp(a, b, f)
 return a + (b-a) * f
end

function lerpl(a, b, f, m)
 local d = (b-a) * f
 d = clamp(d, -m, m)
 return a + d
end

function round(x)
 if x % 1 > .5 then
  return flr(x) + 1
 else
  return flr(x)
 end
end

function ceil(x)
 if x == flr(x) then
  return x
 else
  return flr(x) + 1
 end
end

function drawborder()
 pal(6, gridpalette[currentpalette][4])
 pal(12, gridpalette[currentpalette][5])
 map(0, 0, 0, 0, 16, 16)
 pal()
end


-- globals
gametype = 1
player = nil
dots = nil
blackholes = nil
effects = nil
score = nil
gravitytimer = nil
freezeframes = 0
uptime = 0

-- options
launchstyle = nil
movestyle = nil
firstrun = dget(2)
currentpalette = nil
if firstrun == 0 then
 dset(2, 1) -- first run
 dset(3, 1) -- launch style
 dset(4, 0) -- move style
 dset(5, 1) -- color palette
end

function setlaunchstyle(s)
 launchstyle = s
 dset(3, s)
 if s == 0 then
  menuitem(1, 'launch: normal', function()
   setlaunchstyle(1)
  end)
 end
 if s == 1 then
  menuitem(1, 'launch: inverted', function()
   setlaunchstyle(0)
  end)
 end
end

function setmovestyle(s)
 movestyle = s
 dset(4, s)
 if s == 0 then
  menuitem(2, 'move: normal', function()
   setmovestyle(1)
  end)
 end
 if s == 1 then
  menuitem(2, 'move: inverted', function()
   setmovestyle(0)
  end)
 end
end

function setcolorpalette(c)
 if c < 1 then c = 1 end
 if c > #gridpalette then c = 1 end
 currentpalette = c
 dset(5, c)
 menuitem(3, 'color: ' .. gridpalette[currentpalette][6], function()
  setcolorpalette(currentpalette + 1)
 end)
end

setlaunchstyle(dget(3))
setmovestyle(dget(4))
setcolorpalette(dget(5))



class = {}

function class.player()
 local player = {
  -- tweak me
  r = 4,
  accel = .02,
  friction = 1.015,
 	maxspeed = 2.5,
 	slomospeed = .2,
 	chargespeed = 1/60,
 	launchspeed = 3,
 	traillength = 16,

  -- don't tweak me
  buttoncurrent = false,
  buttonprevious = false,
 	x = 64,
 	y = 64,
 	vx = 0,
 	vy = 0,
 	canlaunch = true,
 	launching = false,
 	charge = 0,
 	launchdir = 0,
 	suctiontimer = 0,
 	sizetimer = 0,
 	speedtimer = 0,
 }
 player.displayr = player.r

 -- init trail
 player.trail = {}
 local i
 for i = 1, player.traillength do
  player.trail[i] = {x = player.x, y = player.y}
 end
 
 local inputx
 local inputy

 function player:update()
  -- input
  inputx = 0
  inputy = 0
  if (btn(0)) inputx -= 1
  if (btn(1)) inputx += 1
  if (btn(2)) inputy -= 1
  if (btn(3)) inputy += 1
  local l = sqrt(inputx*inputx + inputy*inputy)
  if l > 1 then
   inputx /= l
   inputy /= l
  end
  self.buttonprevious = self.buttoncurrent
  self.buttoncurrent = btn(4)
  local buttonpressed = self.buttoncurrent and not self.buttonprevious

  local speed = sqrt(self.vx*self.vx + self.vy*self.vy)

  -- acceleration
  local d = movestyle == 1 and -1 or 1
  self.vx += inputx * self.accel * speed / self.maxspeed * d
  self.vy += inputy * self.accel * speed / self.maxspeed * d

  -- friction
  self.vx /= self.friction
  self.vy /= self.friction
  
  -- gravity
  if gravitytimer > 0 then
   self.vy += .02
  end
  
  -- black hole gravity
  for b in all(blackholes) do
	  local d = atan2(b.x - self.x, b.y - self.y)
	  self.vx += .004 * cos(d)
	  self.vy += .004 * sin(d)
	 end

  -- bounce of screen edges
  local burstbounceparticles = function(angle)   
   for i = 1, 3 do
    local p = class.particle(self.x, self.y)
    p.angle = angle - .25 + rnd(.5)
    add(effects, p)
   end
   sfx(10)
  end
  if self.x < self.r then
   self.x = self.r
   self.vx *= -1
   burstbounceparticles(0)
  end
  if self.x > 128 - self.r then
   self.x = 128 - self.r
   self.vx *= -1
   burstbounceparticles(.5)
  end
  if self.y < self.r + 16 then
   self.y = self.r + 16
   self.vy *= -1
   burstbounceparticles(.75)
  end
  if self.y > 128 - self.r then
   self.y = 128 - self.r
   self.vy *= -1
   burstbounceparticles(.25)
  end

  -- limit speed
  if speed > self.maxspeed then
   self.vx /= (speed / self.maxspeed)
   self.vy /= (speed / self.maxspeed)
  end

  -- launching --
  
  -- start charge
  if not self.launching and buttonpressed then
   if self.canlaunch then
	   self.launching = true
	   self.charge = 0
	   if btn(0) or btn(1) or btn(2) or btn(3) then
	    self.launchdir = atan2(inputx, inputy)
	    if launchstyle == 1 then
	     self.launchdir += .5
	    end
	   else
	    self.launchdir = atan2(self.vx, self.vy)
	   end
	   sfx(8, 2)
	  else
	   sfx(35)
	  end
  end
  
  -- charge up
  if self.launching then
   self.charge += self.chargespeed
   if btnp(0) or btnp(1) or btnp(2) or btnp(3) then
    self.launchdir = atan2(inputx, inputy)
    if launchstyle == 1 then
     self.launchdir += .5
    end
   end
  end
  
  -- launch
  if self.launching and (not btn(4) or self.charge >= 1) then
   state.gameplay:onlaunch()
   self.launching = false
   local angle = self.launchdir
   self.vx = self.launchspeed * cos(angle) * self.charge
   self.vy = self.launchspeed * sin(angle) * self.charge
   score.multiplier = 1
   
   -- effects
   for i = 1, 5 do
    local p = class.particle(self.x, self.y, 12)
    p.angle = angle + .5 - .15 + rnd(.3)
    add(effects, p)
   end
   shakecamera(shake.launch)
   freezeframes = 2
   sfx(9, 2)
  end

  -- powerup states
  if self.suctiontimer > 0 then
   self.suctiontimer -= 1/60
  end
  if self.sizetimer > 0 then
   self.r = 8
   self.sizetimer -= 1/60
  else
   self.r = 4
  end
  if self.speedtimer > 0 then
   self.speedtimer -= 1/60
  end

  -- apply movement
 	local speedfactor
 	if self.launching then
 	 speedfactor = self.slomospeed
 	else
 	 speedfactor = 1
 	end
 	if self.speedtimer > 0 then
 	 speedfactor *= 1.5
 	end
  self.x += self.vx * speedfactor
  self.y += self.vy * speedfactor

  -- trail
  self.trail[1].x = player.x
  self.trail[1].y = player.y
  for i = 2, #self.trail do
   local t1 = self.trail[i]
   local t2 = self.trail[i - 1]
   t1.x = (t1.x + t2.x) / 2
   t1.y = (t1.y + t2.y) / 2
  end
  
  -- cosmetic
  self.displayr = self.displayr + (self.r - self.displayr) * .1
  
  -- burst some particles
  if not self.firstframe then
		 for i = 1, 10 do
			 add(effects, class.particle(self.x, self.y, 7))
			end
			self.firstframe = true
		end
 end

 function player:draw()
  -- draw launching hud
  local x, y = flr(self.x), flr(self.y)
  if self.launching then
   circfill(self.x, self.y, self.displayr * 4, 12)
   circfill(self.x, self.y, self.displayr + self.displayr*3*self.charge, 14)
   local bx = cos(self.launchdir) * self.displayr * 4
   local by = sin(self.launchdir) * self.displayr * 4
   if launchstyle == 1 then
    bx = -bx
    by = -by
   end
   line(self.x, self.y, self.x + bx, self.y + by, 9)
  end

  -- draw trail
  for i = 1, #self.trail do
   local t = self.trail[i]
   local r = self.displayr - self.displayr * (i / #self.trail)
   local c
   if self.speedtimer > 0 then
    c = 9
   else
    c = 7
   end
   circfill(t.x, t.y, r, c)
  end
  
  if self.suctiontimer > 0 then
   circfill(x, y, self.displayr, 11)
   circ(x, y, self.displayr, 10)
  else
   circfill(x + 1, y + 1, self.displayr, 5)
   circfill(x, y, self.displayr, 7)
	  circ(x, y, self.displayr, 6)
	 end
 end

 return player
end



function class.dot(special)
 local dot = {
  r = 4,

  x = 4 + flr(rnd(120)),
  y = 20 + flr(rnd(104)),
  vx = 0,
  vy = 0,
  special = special,
  displayr = 1,
 }

 function dot:update()
  -- suction
  if player.suctiontimer > 0 then
	  local d = atan2(player.x - self.x, player.y - self.y)
	  self.vx += .004 * cos(d)
	  self.vy += .004 * sin(d)
	 end
  
  -- gravity
  if gravitytimer > 0 then
   self.vy += .02
  end
  
  -- black hole gravity
  for b in all(blackholes) do
	  local d = atan2(b.x - self.x, b.y - self.y)
	  self.vx += .004 * cos(d)
	  self.vy += .004 * sin(d)
	 end
  
  -- bounce off walls
  if self.x < self.r then
   self.x = self.r
   self.vx *= -1
   sfx(24)
  end
  if self.x > 128 - self.r then
   self.x = 128 - self.r
   self.vx *= -1
   sfx(24)
  end
  if self.y < self.r + 16 then
   self.y = self.r + 16
   self.vy *= -1
   sfx(24)
  end
  if self.y > 128 - self.r then
   self.y = 128 - self.r
   self.vy *= -1
   sfx(24)
  end
  
  -- apply movement
  self.x += self.vx
  self.y += self.vy
  
  -- enter animation
  if self.displayr < self.r then
   self.displayr += 1/3
  end
 end

 function dot:draw()
  if self.special then
   local x1, y1 = self.x, self.y
	  for i = 0, 1, 1/16 do
		  local r = self.displayr + 2 * sin(uptime / 30 + i * 4)
		  local x2 = self.x + r * cos(i)
		  local y2 = self.y + r * sin(i)
		  line(x1, y1, x2, y2, 11)
		 end
		end
 
  if self.displayr < self.r then
   if self.special then
    circfill(self.x, self.y, self.displayr, 11)
   else
    circfill(self.x, self.y, self.displayr, 10)
   end
  else
	  local s
	  if self.special then
	   s = 2
	  else
	   s = 1
	  end
	  spr(s + 2, self.x - 3, self.y - 3)
	  spr(s, self.x - 4, self.y - 4)
	 end
 end

 return dot
end


function class.blackhole()
 local blackhole = {
  x = 8 + flr(rnd(112)),
  y = 24 + flr(rnd(96)),
	 r = 8,
	 life = 5,
	 displayr = 0,
	}
	sfx(20, 1)
	
	function blackhole:update()
	 self.life -= 1/60
	 if self.life <= 20/60 then
	  self.r = 0
	 end
	 self.displayr = self.displayr + (self.r - self.displayr) * .1
	 if self.life <= 0 then
	  sfx(22, 1)
	 end
	end

	function blackhole:draw()
	 local x1, y1 = self.x, self.y
	 for i = 0, 1, .05 do
	  local r = self.displayr + 2 + 2 * sin(uptime / 30 + i * 3)
	  local x2 = self.x + r * cos(i)
	  local y2 = self.y + r * sin(i)
	  line(x1, y1, x2, y2, 8)
	 end
	 circfill(self.x, self.y, self.displayr, 0)
	 circ(self.x, self.y, self.displayr, 8)
	end
	
	return blackhole
end



function class.particle(x, y, col)
 local particle = {
  x = x,
  y = y,
  angle = rnd(1),
  speed = 3,
  friction = 1.1,
  col = col or 7,
  life = .25 + rnd(.25),
 }

 function particle:update()
  self.speed /= self.friction
  self.x += self.speed * cos(self.angle)
  self.y += self.speed * sin(self.angle)
  self.life -= 1/60
 end

 function particle:draw()
  rect(self.x, self.y, self.x + 1, self.y + 1, self.col)
 end

 return particle
end


function class.scorepopup(x, y, score, col)
 local scorepopup = {
  x = x,
  y = y,
  score = score,
  col = col or 10,
  speed = 2,
  friction = 1.1,
  life = .5,
 }
 
 function scorepopup:update()
  self.speed /= self.friction
  self.y -= self.speed
  self.life -= 1/60
 end
 
 function scorepopup:draw()
  local s = self.score .. '00'
	 printc(s, self.x + 1, self.y + 1, 5)
  printc(s, self.x, self.y, self.col)
 end
 
 return scorepopup
end


function class.poweruptext(s)
 local text = {
  s = s,
  
  y = 16,
  life = 1.5,
  id = 'text',
 }
 
 function text:update()
  self.y /= 1.1
  self.life -= 1/60
 end
 
 function text:draw()
  printc(self.s, 65, 65 + self.y, 5)
  printc(self.s, 64, 64 + self.y, 11)
 end
 
 return text
end



function class.gridpoint(x, y)
 local point = {
  anchorx = x,
  anchory = y,
  x = x,
  y = y,
  vx = 0,
  vy = 0,
 }
 
 function point:update()
  if self.anchorx == 0 or self.anchorx == 128 or self.anchory == 16 or self.anchory == 128 then
   return
  end
  
  for b in all(blackholes) do
	  local r = sqrt((b.x - self.x)^2 + (b.y - self.y)^2)
	  if r < 1 then r = 1 end
   self.x = lerp(self.x, b.x, 1/r)
   self.y = lerp(self.y, b.y, 1/r)
  end
  
  local r = sqrt((player.x - self.x)^2 + (player.y - self.y)^2)
  if r < 1 then r = 1 end
  local f = (player.r^3)/320
  self.x = lerp(self.x, player.x, f/r)
  self.y = lerp(self.y, player.y, f/r)
  
  if gravitytimer > 0 then
   self.y = lerp(self.y, 128, .02)
  end
  
  self.x = lerp(self.x, self.anchorx, .1)
  self.y = lerp(self.y, self.anchory, .1)
 end

 return point
end



-- hud --

hud = {
 timeyoffset = 0,
 displayscore = 0,
 cutedots = {0, 0, 0, 0, 0, 0, 0, 0},
}

function hud:tickdown(playsound)
 self.timeyoffset = 4
 if playsound then sfx(29) end
end

function hud:update()
 local s = 0
 
 if state.current == state.gameplay or state.current == state.results then
  s = score.score
 end

 -- timer animation
 self.timeyoffset = lerp(self.timeyoffset, 0, .2)
	 
 -- rolling score counter
 if state.current == state.gameplay or state.current == state.results then
	 self.displayscore = lerp(self.displayscore, s, .25)
	 if self.displayscore % 1 > .99 then
	  self.displayscore = flr(self.displayscore) + 1
	 end
	else
	 self.displayscore = 0
	end

 if gametype == 3 then
  -- update zen mode visualizer
	 local wiggle = 1000 * sin(uptime/240) * (s - self.displayscore) / 100
	 self.cutedots[1] = lerpl(self.cutedots[1], wiggle, .1, 1.5)
	 for i = 8, 2, -1 do
	  self.cutedots[i] = lerp(self.cutedots[i], self.cutedots[i-1], .1)
	 end
	end
end

function hud:draw()
 local scoredisplayy = 0
 local timeleft = 60
 local movesleft = 15

 if state.current == state.gameplay or state.current == state.results then
  timeleft = score.timeleft
  movesleft = score.movesleft
 
  scoredisplayy = 400 * (score.score - self.displayscore) / 200
	 if scoredisplayy > 2 then scoredisplayy = 2 end
	 scoredisplayy = round(scoredisplayy)
	end

 if gametype == 3 then
  -- draw zen mode visualizer
	 for i = 1, 8 do
	  local x = 36 + 8 * (i - 1)
	  local wiggle = self.cutedots[i]
	  wiggle = clamp(wiggle, -4 ,4)
	  local y = round(8 + wiggle)
	  local c = 5
	  if abs(wiggle) > 1 then
	   c = gridpalette[currentpalette][4]
	  end
	  if abs(wiggle) > 3 then
	   c = gridpalette[currentpalette][5]
	  end
	  circfill(x, y, 2, c)
	 end
	 return false
	end
	
	-- score counter
 local s
 if self.displayscore == 0 then
  s = 0
 else
  local whole = flr(self.displayscore)
  local decimal = self.displayscore % 1
  if whole == 0 then whole = '' end
  if decimal == 0 then
   s = whole .. '00'
  else
   decimal = decimal .. ''
	  s = whole .. sub(decimal, 3, 4)
	 end
 end
 
 print('score', 2, 2, 5)
 print('score', 1, 1, 12)
 print(s, 26, 2 + scoredisplayy, 5)
 print(s, 25, 1 + scoredisplayy, 7)
 
 -- high score
 local s = dget(gametype-1)
 if s ~= 0 then
  s = s .. '00'
 end
 print('high', 2, 10, 5)
 print('high', 1, 9, 10)
 print(s, 26, 10, 5)
 print(s, 25, 9, 7)
 
 -- time/moves left
 if gametype == 1 or movesleft == 0 then
	 print('time', 113, 2, 5)
	 print('time', 112, 1, 7)
	 local t = ceil(timeleft)
	 t = t .. ''
	 printc(t, 121, 10 + self.timeyoffset, 5)
	 local c = 7
	 if timeleft <= 10 then
	  c = 8
	 end
	 printc(t, 120, 9 + self.timeyoffset, c)
	else
	 print('left', 113, 2, 5)
	 print('left', 112, 1, 7)
	 local t = movesleft
	 t = t .. ''
	 printc(t, 121, 10 + self.timeyoffset, 5)
	 local c = 7
	 if movesleft <= 5 then
	  c = 8
	 end
	 printc(t, 120, 9 + self.timeyoffset, c)
	end
end
  


-- gameplay state --

state.gameplay = {}

function state.gameplay:enter(gametype)
	player = class.player()
	dots = {}
	blackholes = {}
	effects = {}
	score = {
	 score = 0,
	 multiplier = 1,
	 dotscollected = 0,
	 timeleft = 60,
	 movesleft = 15,
	}
	cam = {
	 sequence = {{0, 0}},
	 frame = 1,
	}
	gravitytimer = 0
	
	self.powerups = {}
	
	-- cosmetic
	self.grid = {}
	for x = 0, 128, 16 do
	 self.grid[x] = {}
	 for y = 16, 128, 16 do
	  self.grid[x][y] = class.gridpoint(x, y)
	 end
	end
	 
	self.secondtimer = 1
	
	for i = 1, 5 do
		add(dots, class.dot())
	end
	
	menuitem(4, 'retry', function()
	 gotostate(state.transition, state.intro, true)
	end)
end

function state.gameplay:powerup()
 -- shuffle powerups
 if #self.powerups == 0 then
	 if gametype == 1 then
		 self.powerups = {1, 2, 3, 4, 5, 6}
		end
		if gametype == 2 then
		 self.powerups = {2, 3, 4, 5, 6}
		end
  if gametype == 3 then
   self.powerups = {2, 3, 4, 5}
  end 
	 for _ = 1, 10 do
		 for i = 1, #self.powerups - 1 do
	   local j = i + 1
	   if rnd(2) < 1 then
	    local a, b = self.powerups[i], self.powerups[j]
	    self.powerups[i] = b
	    self.powerups[j] = a
	   end
	  end
	 end
 end
 		
 local c = self.powerups[1]
 assert(c)
 del(self.powerups, self.powerups[1])

 -- delete previous powerup text
 for e in all(effects) do
  if e.id == 'text' then
   del(effects, e)
  end
 end

 if c == 1 then
  add(dots, class.dot())
  add(effects, class.poweruptext('extra gem!'))
  sfx(19, 3)
 end
 if c == 2 then
  add(blackholes, class.blackhole())
  add(effects, class.poweruptext('black hole!'))
 end
 if c == 3 then
  player.sizetimer = 5
  add(effects, class.poweruptext('size up!'))
  sfx(25, 3)
 end
 if c == 4 then
  gravitytimer = 5
  sfx(23, 3)
  add(effects, class.poweruptext('gravity!'))
 end
 if c == 5 then
  player.speedtimer = 5
  add(effects, class.poweruptext('speed up!'))
  sfx(21, 3)
 end
 if c == 6 then
  if gametype == 1 then
	  score.timeleft += 5
	  add(effects, class.poweruptext('extra time!'))
	 else
	  score.movesleft += 3
	  add(effects, class.poweruptext('extra launches!'))
	 end  
  sfx(33, 3)
 end
end

function state.gameplay:onlaunch()
 if gametype == 2 then
  score.movesleft -= 1
  if score.movesleft == 5 then
   sfx(40, 1)
  end
  if score.movesleft == 3 then
   sfx(41, 1)
  end
  if score.movesleft == 1 then
   sfx(42, 1)
  end
  hud:tickdown()
 end
end

function state.gameplay:update()
 if freezeframes > 0 then
  freezeframes -= 1
  return
 end

 if gametype == 1 then
	 score.timeleft -= 1/60
	 if score.timeleft <= 0 then
	  gotostate(state.results)
	 end
	end
	if gametype == 2 then
	 player.canlaunch = score.movesleft > 0
	 if score.movesleft == 0 then
	  score.timeleft -= 1/60
	  if score.timeleft <= 0 then
		  gotostate(state.results)
		 end
		else
			score.timeleft = 10
		end
	end
 
 if gravitytimer > 0 then
  gravitytimer -= 1/60
 end

 -- update player
 player:update()

 -- update dots
 for d in all(dots) do
  d:update()	

  -- dot collection
  local distance = sqrt((d.x - player.x)^2 + (d.y - player.y)^2)
  if distance < player.r + d.r then
   del(dots, d)
   local dotscore = score.multiplier
   local col
   if d.special then
    col = 11
    dotscore *= 5
    self:powerup()
   else
    col = 10
   end
   score.dotscollected += 1
   score.multiplier += 1
   score.score += dotscore
   add(dots, class.dot(score.dotscollected % 5 == 0))
   for i = 1, 5 do
    add(effects, class.particle(d.x, d.y, col))
   end
   add(effects, class.scorepopup(d.x, d.y, dotscore, col))
   local s
   if score.multiplier > 8 then
    s = 7
   else
	   s = score.multiplier - 2
	  end
	  if d.special then
	   s += 11
	  end
	  sfx(s, 0)
  end
 end
 
 -- update blackholes
 for b in all(blackholes) do
  b:update()
  if b.life <= 0 then
   del(blackholes, b)
  end
 end

 -- update particles
 for e in all(effects) do
  e:update()
  if e.life <= 0 then
   del(effects, e)
  end
 end
 
 -- update grid
 for x = 0, 128, 16 do
	 for y = 16, 128, 16 do
	  self.grid[x][y]:update()
	 end
	end
 
 -- update camera
 cam.frame += 1
 if cam.frame > #cam.sequence then
  cam.frame = #cam.sequence
 end
 
 -- update hud animations
 if gametype == 1 or score.movesleft == 0 then
	 self.secondtimer -= 1/60
	 if self.secondtimer <= 0 then
	  self.secondtimer += 1
	  if score.timeleft < 10 then
	   hud:tickdown(true)
	  end
	 end
	else
	 self.secondtimer = 1
	end
end

function state.gameplay:draw()
 cls()
 
 camera(cam.sequence[cam.frame][1], cam.sequence[cam.frame][2])
 
 -- draw grid
 clip(2, 18, 126, 108)
 rectfill(0, 0, 128, 128, gridpalette[currentpalette][1])
	for x = 0, 128, 16 do
	 for y = 16, 112, 16 do
	  local a = self.grid[x][y]
	  local b = self.grid[x][y+16]
	  line(a.x, a.y, b.x, b.y, gridpalette[currentpalette][2])
	 end
	end
	for x = 0, 112, 16 do
	 for y = 16, 128, 16 do
	  local a = self.grid[x][y]
	  local b = self.grid[x+16][y]
	  line(a.x, a.y, b.x, b.y, gridpalette[currentpalette][3])
	 end
	end
	clip()
 
 drawborder()
 	
	-- draw entities
 for b in all(blackholes) do
  b:draw()
 end
 player:draw()
 for d in all(dots) do
  d:draw()
 end
 for e in all(effects) do
  e:draw()
 end
 
 camera()
end



-- results screen
state.results = {}

function state.results:enter()
 sfx(-1, 0)
 sfx(-1, 1)
 sfx(-1, 2)
 sfx(-1, 3)
 sfx(31)

 self.newhighscore = false
 if score.score > dget(gametype-1) then
  self.newhighscore = true
  dset(gametype-1, score.score)
 end
 
 self.statetimer = 4
 self.displayscore = 0
end

function state.results:update()
 if self.statetimer > 0 then
	 self.statetimer -= 1/60
	 if self.statetimer <= 0 then
	  if self.newhighscore then
	   sfx(32)
	  end
	 end
	end

 if self.statetimer <= 2 then
  if self.displayscore < score.score then
   if stat(16) ~= 34 then
	   sfx(34, 0)
	  end
	  self.displayscore += score.score/100
	  if self.displayscore > score.score then
	   self.displayscore = score.score
	  end
	 else
	  if stat(16) == 34 then
	   sfx(26, 0)
	  end
	 end
	end

 if self.statetimer <= 0 then
	 if btnp(4) then
 	 gotostate(state.transition, state.intro, true)
	 end
	 if btnp(5) then
	  gotostate(state.transition, state.title, true)
  end
 end
end

function state.results:draw()
 state.gameplay:draw()

 rectfill(8, 32, 120, 96, 0)
 
 local c = 12
 if gametype == 2 then
  c = 14
 end
 
 if self.statetimer <= 2 then
	 printc('final score', 65, 41, 5)
	 printc('final score', 64, 40, c)
	 local s = flr(self.displayscore)
	 if s > 0 then
	  s = s .. '00'
	 end
	 printc(s, 65, 49, 5)
	 printc(s, 64, 48, 7)
	else
	 if gametype == 1 then
	 	printc('time up!', 65, 65, 5)
		 printc('time up!', 64, 64, 7)
		elseif gametype == 2 then
		 printc('out of moves!', 65, 65, 5)
		 printc('out of moves!', 64, 64, 7)
		end
	end
	
	if self.statetimer <= 0 then
	 if self.newhighscore then
	  printc('new high score!', 65, 65, 5)
	  printc('new high score!', 64, 64, 10)
	 end
	 printc('🅾️ retry    ❎ menu', 65, 81, 5, 1)
	 printc('🅾️ retry    ❎ menu', 64, 80, c, 1)
	end
end



-- intro sequence
state.intro = {}

function state.intro:enter()
 self.rings = {}
 for i = 1, 8 do
  self.rings[i] = {
   startr = 16*i,
   extrar = rnd(128),
   targetr = i/4,
  }
  self.rings[i].r = self.rings[i].startr
 end
 
 self.timer = 2
 
 if gametype == 3 then
  sfx(28)
  sfx(37)
 else
	 sfx(27)
	 sfx(28)
	end
end

function state.intro:update()
 for i = 1, #self.rings do
  local r = self.rings[i]
  r.r -= r.startr/120
  r.extrar = lerp(r.extrar, 0, .05)
 end
 
 self.timer -= 1/60
 if self.timer <= 0 then
  sfx(-1, 0)
  sfx(-1, 1)
  sfx(-1, 2)
  sfx(-1, 3)
  if gametype == 3 then
   sfx(38)
   sfx(39)
  else
	  sfx(9)
	 end
  gotostate(state.gameplay)
 end
end

function state.intro:draw()
 cls()
 
 clip(2, 18, 126, 108)
 
 -- draw rings
 for i = 1, #self.rings do
  local r = self.rings[i]
  local c = i % 2 == 0 and 12 or 3
  if gametype ~= 3 then
   c = i + 4
  end
  circ(64, 64, r.r + r.extrar + r.targetr, c)
 end
 
 clip()
end



state.transition = {}

function state.transition:enter(s, crop)
 self.r = 1
 self.s = s
 self.crop = crop
 sfx(30)
end

function state.transition:update()
 self.r *= 1.15
 if self.r > 10000 then
  gotostate(self.s)
 end
end

function state.transition:draw()
 --rectfill(0, 0, self.x, 128, 0)
 if self.crop then
  clip(0, 16, 128, 112)
 end
 circfill(64, 64, self.r, 0)
 circfill(64, 64, self.r/2, gridpalette[currentpalette][1])
 circfill(64, 64, self.r/4, 0)
 clip()
end


-- title screen
state.title = {}

function state.title:enter()
 music(0)
 poke(0x5f42, 2)
end

function state.title:update()
 if btnp(5) then
  gametype += 1
  if gametype > 3 then
   gametype = 1
  end
  sfx(36)
 end
 if btnp(4) then
  music(-1)
  poke(0x5f42, 0)
  gotostate(state.transition, state.intro, true)
 end
end

function state.title:draw()
 cls()
 
 clip(2, 18, 126, 108)
 
 rectfill(0, 0, 128, 128, gridpalette[currentpalette][1])

 -- draw grid
 for x = 0, 128, 16 do
  line(x, 16, x, 128, gridpalette[currentpalette][2])
 end
 for y = 16, 128, 16 do
  line(0, y, 128, y, gridpalette[currentpalette][3])
 end
 
 clip()
 
 drawborder()

 -- draw title
 for i = 0, 4 do
  local s = 6 + i * 2
  local x = 128/2 - (15*5)/2 + 15*i
  local y = 32 + 3.99 * sin(uptime/60 - 1/15*i)
  spr(s, x, y, 2, 2)
 end
 
 printc('strategic kinetic', 65, 53, 5)
 printc('strategic kinetic', 64, 52, 7)
 printc('action videogame', 65, 61, 5)
 printc('action videogame', 64, 60, 7)
 
 -- instructions
 camera(0, 1.99 * sin(uptime / 120) + 4)
 
 local c = 12
 if gametype == 2 then c = 14 end
 if gametype == 3 then c = 9 end
 
 printc('hold ⬆️⬇️⬅️➡️ to aim', 65, 81, 5, 4)
 printc('hold ⬆️⬇️⬅️➡️ to aim', 64, 80, 6, 4)
 
 printc('hold 🅾️ to charge', 65, 89, 5, 1)
 printc('hold 🅾️ to charge', 64, 88, 6, 1)
 
 printc('release 🅾️ to launch!', 65, 97, 5, 1)
 printc('release 🅾️ to launch!', 64, 96, 6, 1)
 
 local s
 if gametype == 1 then
  s = '❎ reflexive    🅾️ start'
 elseif gametype == 2 then
  s = '❎ cerebral     🅾️ start'
 elseif gametype == 3 then	
  s = '❎ sensory      🅾️ start'
 end
 printc(s, 65, 113, 5, 1)
 printc(s, 64, 112, c, 1)
 
 camera()
end



-- main loop --
function _init()
	gotostate(state.transition, state.title)
end

function _update60()
 uptime += 1
 state.current:update()
 hud:update()
end

function _draw()
 state.current:draw()
 if state.current ~= state.transition then
	 hud:draw()
	end
end
if(_update60)_update=function()_update60()_update_buttons()_update60()end