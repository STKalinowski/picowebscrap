-- tetraminis deffect
-- by tromagon

--boot
state_update=nil
state_draw=nil

skip_menu=false

function _init()
	if (skip_menu)	init_game() return
	init_main()
end

function _update()
	state_update()
end

function _draw()
	cls()
	state_draw()
end

--main menu
title="tetraminis deffect"
descr="pick stage then press ❎"

function init_main()
	state_update=update_main
	state_draw=draw_main
end

sel_w=15
sel_h=10
selections={}
sel_index=0
sel={x=1,y=1}

instr_a="⬆️/up		 : hard drop"
instr_b="⬇️/down : drop"
instr_c="🅾️/z			 : zone"
instr_d="❎/x			 : rotate"

function draw_main()
draw_bgnd_10()
	map(0,0,64-7*8,10,14,3)
	
	local instr_x=64-#instr_c*2
	local instr_y=128-30
	local gap=6
	print(instr_d,instr_x,instr_y,13)
	print(instr_b,instr_x,instr_y+gap,13)
	print(instr_a,instr_x,instr_y+2*gap,13)
	print(instr_c,instr_x,instr_y+3*gap,13)

	print(descr,64-#descr*2,38,6)
	local offset=64-5*sel_w/2
	local selector_y=50
	for i=1,#levels do
		local x=offset+flr((i-1)%5)*sel_w
		local y=selector_y+flr((i-1)/5)*sel_h
		rect(x,y,x+sel_w,y+sel_h,7)
		add(selections,{x=x,y=y})
		local str=i..""
		if sel_index+1==i then
			print(str,x+5,y+3,11)
		else
			print(str,x+5,y+3,7)
		end
	end
	local s=selections[sel_index+1]
	rect(s.x,s.y,s.x+sel_w,s.y+sel_h,11)
end

function update_main()

	--sel_index=(sel.y-1)*5+sel.x
	if btnp(5) then
		state_update=update_blink
		sfx(32)
	end
	--left
	if btnp(0) then
		sfx(62)
		if sel_index%5>0 then sel_index-=1 end
	end
	if btnp(1) then
	sfx(62)
		if sel_index%5+1<5 and sel_index+1<#levels then sel_index+=1 end
	end
	if btnp(2) then
	sfx(62)
		if sel_index-5>=0 then sel_index-=5 end
	end
	
	if btnp(3) then
	sfx(62)
		if sel_index+5<#levels then sel_index+=5 end
	end

end

select_time=2
blink_time=0.1
blink=false

function update_blink()
	select_time-=1/30
	
	blink_time-=1/30
	if blink_time<=0 then
		blink_time=0.1
		if blink then blink=false else blink=true end
	end
	
	if (blink) descr=""
	if not blink then descr="pick stage then press ❎" end
	
	if (select_time<=0)	then
		select_time=2
		blink_time=0.1
		init_game()
	end
end

function init_game_over()
	state_update=update_game_over
	state_draw=draw_game_over
	gameover_time=gameover_wait
	sfx(33)
end

gameover_title="game over"
gameover_wait=2
gameover_time=gameover_wait

function draw_game_over()
	print(gameover_title,64-#gameover_title*2,64-4,7)
end

function update_game_over()
	gameover_time-=1/30
	if (gameover_time<=0) init_main()
end

end_game_wait=5
end_game_time=end_game_wait
end_game_title="you're insane!!"
end_game_descr="◆◆◆◆◆◆◆◆◆◆"

function init_end_game()
	state_update=update_end_game
	state_draw=draw_end_game
	end_game_time=end_game_wait
end

function draw_end_game()
	print(end_game_title,64-#end_game_title*2,64-4,7)
	print(end_game_descr,64-#end_game_descr*4,64+4,6)
	local score="score "..score
	print(score,64-#score*2,64+15,7)
end

function update_end_game()
	end_game_time-=1/30
	if (end_game_time<=0) init_main()
end
-->8
--data
--controls
hard_drop_input=2
rotate_input=5
left_input=0
right_input=1
drop_input=3
zone_input=4

--profile
game_state_update=nil
draw_bgnd=nil
next_fall=0
fast_fall=0.05
current_fall_interval=0

curr_tetr={
	data=nil,
	pos={x=0,y=0},
	rot_index=1,
	index=1
}

next_tetr=1
drop_row=0

current_wait=0
line_index=0
current_zone=0
current_zone_lines=0
zone_label="zone"
is_zone=false
current_zone_time=0

c_time=0
score=0
mul_bgnd=1
notif=""
notif_time=0

--config
csize=5
outline=1
grid_w=10
grid_h=20
grid={}
grid_area={
	x=64-grid_w/2*csize,
	y=64-grid_h/2*csize,
	w=grid_w*csize,
	h=grid_h*csize
}

wait_cooldown=0.3

--zone_incr=0.25
--zone_req_line=2
zone_incr=0.25
zone_req_line=4
total_zone_time=20
cumul_lines=0

zone_img=16
drop_img=32
zone_cell=64
zone_tetr=48

otetr={
	w=2,
	h=2,
	dflt=1,
	offsety=0,
	rotation={
 	{
 		{1,1},
 		{1,1}
 	},
 	{
 		{1,1},
 		{1,1}
 	},
 	{
 		{1,1},
 		{1,1}
 	},
 	{
 		{1,1},
 		{1,1}
 	}
 }
}

itetr={
	w=4,
	h=4,
	dflt=1,
	offsety=0.5,
	rotation={
 	{
 		{0,0,0,0},
 		{1,1,1,1},
 		{0,0,0,0},
 		{0,0,0,0}
 	},
 	{
 		{0,0,1,0},
 		{0,0,1,0},
 		{0,0,1,0},
 		{0,0,1,0}
 	},
 	{
 		{0,0,0,0},
 		{0,0,0,0},
 		{1,1,1,1},
 		{0,0,0,0}
 	},
 	{
 		{0,1,0,0},
 		{0,1,0,0},
 		{0,1,0,0},
 		{0,1,0,0}
 	}
 }
}

ttetr={
	w=3,
	h=3,
	dflt=3,
	offsety=0,
	rotation={
 	{
 		{0,1,0},
 		{1,1,1},
 		{0,0,0}
 	},
 	{
 		{0,1,0},
 		{0,1,1},
 		{0,1,0}
 	},
 	{
 		{0,0,0},
 		{1,1,1},
 		{0,1,0}
 	},
 	{
 		{0,1,0},
 		{1,1,0},
 		{0,1,0}
 	}
 }
}

stetr={
	w=3,
	h=3,
	dflt=1,
	offsety=1,
	rotation={
 	{
 		{0,1,1},
 		{1,1,0},
 		{0,0,0}
 	},
 	{
 		{0,1,0},
 		{0,1,1},
 		{0,0,1}
 	},
 	{
 		{0,0,0},
 		{0,1,1},
 		{1,1,0}
 	},
 	{
 		{1,0,0},
 		{1,1,0},
 		{0,1,0}
 	}
 }
}

ztetr={
	w=3,
	h=3,
	dflt=1,
	offsety=1,
	rotation={
 	{
 		{1,1,0},
 		{0,1,1},
 		{0,0,0}
 	},
 	{
 		{0,0,1},
 		{0,1,1},
 		{0,1,0}
 	},
 	{
 		{0,0,0},
 		{1,1,0},
 		{0,1,1}
 	},
 	{
 		{0,1,0},
 		{1,1,0},
 		{1,0,0}
 	}
 }
}

jtetr={
	w=3,
	h=3,
	dflt=3,
	offsety=0,
	rotation={
 	{
 		{1,0,0},
 		{1,1,1},
 		{0,0,0}
 	},
 	{
 		{0,1,1},
 		{0,1,0},
 		{0,1,0}
 	},
 	{
 		{0,0,0},
 		{1,1,1},
 		{0,0,1}
 	},
 	{
 		{0,1,0},
 		{0,1,0},
 		{1,1,0}
 	}
 }
}

ltetr={
	w=3,
	h=3,
	dflt=3,
	offsety=0,
	rotation={
 	{
 		{0,0,1},
 		{1,1,1},
 		{0,0,0}
 	},
 	{
 		{0,1,0},
 		{0,1,0},
 		{0,1,1}
 	},
 	{
 		{0,0,0},
 		{1,1,1},
 		{1,0,0}
 	},
 	{
 		{1,1,0},
 		{0,1,0},
 		{0,1,0}
 	}
 }
}

tetr={
		ttetr,jtetr,ztetr,otetr,
		stetr,ltetr,itetr}
tetr_count=#tetr
-->8
--update game
function init_game()
	state_update=update_game
	state_draw=draw_game
	level_index=sel_index+1
	zone_label="zone"
	current_zone=0
	current_zone_lines=0
	reset_game()
	music(0)
end

function update_game()
	c_time+=1/30
	game_state_update()
	update_particles()
	update_motif()
end

function fall_update()
	local c=curr_tetr
	local new_pos={x=c.pos.x,y=c.pos.y}
	
	if btnp(zone_input) then
		if current_zone>0 and not is_zone then
			sfx(59)
			is_zone=true
			zone_label="zone"
			pop_notif("zone",1)
			current_zone_time=current_zone*total_zone_time	
		end
	end
	--left
	if btnp(left_input) then
		new_pos.x-=1
	end
	--right
	if btnp(right_input) then
		new_pos.x+=1
	end
	if new_pos.x~=c.pos.x then
		if validate_move(c,new_pos,c.rot_index) then
			commit_pos(c,new_pos)
			sfx(61)
		end
	end
	
	calculate_drop()

	--up rotate
	if btnp(rotate_input) then
	 local new_rot=c.rot_index
		new_rot+=1
		if new_rot>4 then 
			new_rot=1 
		end
		if validate_move(c,new_pos,new_rot) then
			c.rot_index=new_rot
			calculate_drop()
			sfx(62)
		end
	end
	
	--down
	if btn(drop_input) then
		current_fall_interval=fast_fall
		next_fall=0
	else
		current_fall_interval=speeds[start_spds[level_index]]
	end
	
	next_fall-=1/30
	if next_fall<0 then
		next_fall=current_fall_interval
		new_pos.x=c.pos.x
		new_pos.y+=1
		if not validate_move(c,new_pos,c.rot_index) then
			sfx(60)
			land(c)
		else
			commit_pos(c,new_pos)
		end
	end
	
	if btnp(hard_drop_input) then
		sfx(63)
		drop(c)
		land(c)
	end
	
	mul_bgnd-=1/30
	if (mul_bgnd<1) mul_bgnd=1
	
	if is_zone then
		current_zone_time-=1/30
		current_zone=current_zone_time/total_zone_time
		if current_zone_time<=0 then
			end_zone()
		end
	end
end

function change_bgnd()
	bgnd_index+=1
	if bgnd_index>bgnd_count then
		bgnd_index=1
	end
end

function end_zone()
	sfx(58)
	local offset=0
	local row=0
	local is_cleared=false
	for j=1,grid_h do
		row=grid_h-j+1
		is_cleared=(grid[row][1]==zone_img)
		if (is_cleared) then
			offset+=1 
			explode(
 		64,
 		grid_area.y+row*csize-csize/2,
 		4,6,1,1,10,3,6)
		end
		if offset>0 then
 		for i=1,grid_w do
 			if (is_cleared) then
 				grid[row][i]=0
 			else
 				grid[row+offset][i]=grid[row][i]
 				grid[row][i]=0
 			end
 		end
		end
	end
	if cumul_lines>4 then
		local score_index=cumul_lines
 	if (score_index>#scores) score_index=#scores
 	score+=scores[score_index]
 	pop_notif(scores[score_index].." bonus points",2)
	end
	mul_bgnd=4
	is_zone=false
	current_zone_time=0
	current_zone=0
	cumul_lines=0
end

function wait_update()
	current_wait-=1/30
	if current_wait<=0 then
		current_wait=wait_cooldown
		local c=spawn_tetr()
		if validate_move(c,c.pos,c.rot_index) then
			game_state_update=fall_update
		else
			game_state_update=game_over_update
		end
	end
end

function game_over_update()
	if is_zone then
		end_zone()
		game_state_update=fall_update
	else
		music(-1,100)
		init_game_over()
	end
end

function reset_game()
	curr_lvl.data=levels[level_index]
	curr_lvl.spd=start_spds[level_index]
	curr_lvl.lines=0
	current_wait=wait_cooldown
 current_fall_interval=speeds[start_spds[level_index]]
 next_fall=current_fall_interval
	clear_board()
	next_tetr=flr(rnd(tetr_count))+1
	spawn_tetr()
	game_state_update=fall_update
	bgnd_index=flr(rnd(bgnd_count))
	--zone_label="zone"
	pop_notif("stage "..level_index,2)
end

function clear_board()
	for j=1,grid_h do
			grid[j]={}
		for i=1,grid_w do
			grid[j][i]=0
		end
	end
end

function spawn_tetr()
	local c=curr_tetr
	c.data=tetr[next_tetr]
	c.index=next_tetr
	next_tetr=flr(rnd(tetr_count))+1
	c.rot_index=c.data.dflt
	c.pos.x=grid_w/2-1
	c.pos.y=0
	return c
end

function commit_pos(c,new_pos)
	c.pos.x=new_pos.x
	c.pos.y=new_pos.y
end

function drop(c)
	c.pos.y=drop_row
end

function land(c)
	if c.data==null then return end
	explode(
	grid_area.x+(c.pos.x+c.data.w/2)*csize,
	grid_area.y+(c.pos.y+c.data.h/2)*csize,
	2,4,2,2,10,2,col[curr_lvl.data.img[c.index]])
	local rot=c.data.rotation[c.rot_index]
	for j=1,c.data.h do
 	for i=1,c.data.w do
 		if rot[j][i]!=0 then
 			grid[c.pos.y+j][c.pos.x+i]=curr_lvl.data.img[c.index]
 		end
 	end
 end
 check_lines()
 curr_tetr.data=nil
 game_state_update=wait_update
end

function validate_move(c,new_pos,new_rot)
	local rot=c.data.rotation[new_rot]
	for j=1,c.data.h do
 	for i=1,c.data.w do
 		if rot[j][i]!=0 then
 			if new_pos.y+j>grid_h then return false end 
 			if	grid[new_pos.y+j][new_pos.x+i]!=0 then return false end
 		end
 	end
 end
 return true
end

function check_lines()
	local is_line=true
	local lines={}
	local num_lines=0
	for j=1,grid_h do
		is_line=true
 	for i=1,grid_w do
 		local img=grid[j][i]
 		if img==0 or img==zone_img then
 			is_line=false
 			break
 		end
 	end
 	if is_line then
 		add(lines,j)
 		num_lines+=1
 	end
 end
 for l=1,num_lines do
 	local row=lines[l]
 	for i=1,grid_w do
 		grid[row][i]=0
 	end
 end
 if (num_lines==0) return
 curr_lvl.lines+=num_lines
 if (curr_lvl.spd_index<=#spd_changes[level_index]) then
		for i=curr_lvl.spd_index,#spd_changes[level_index] do
			local req_l=req_lines[level_index][i]
 		if curr_lvl.lines>=req_l then
 			curr_lvl.spd=spd_changes[level_index][curr_lvl.spd_index]
 			curr_lvl.spd_index+=1
 			pop_notif("speed up",1)
 		end
		end	
	end
	mul_bgnd=num_lines+1
	sfx(57)
	if (is_zone) then 
		build_zone(num_lines,lines)
	else
		local s={
			r=4,velx=8,vely=2,
			mass=1,count=10,life=3,
			col=7
		}
	
		for i=1,num_lines do
			explode(
 	64,
 	grid_area.y+lines[i]*csize-csize/2,
 	s.r,s.velx,s.vely,s.mass,s.count,s.life,s.col)
		end
		
		collapse(num_lines,lines)
		check_end_level()
	end
	local score_index=num_lines
	if (score_index>#scores) score_index=#scores
	score+=scores[num_lines]
end

function check_end_level()
	if curr_lvl.lines>=req_tot[level_index] then
		play_next_lvl()
	end
end

function play_next_lvl()
	level_index+=1
	if (level_index>#levels) then 
		init_end_game()
	else
		reset_game()
	end
end

function collapse(l,lines)
	local start_row=lines[1]-1
 for j=1,start_row do
 	local src=start_row-j+1
 	local dest=src+l
		for i=1,grid_w do
			local oldval=grid[dest][i]
			local newval=grid[src][i]
			grid[dest][i]=grid[src][i]
		end
	end
	if (is_zone==false) then
		current_zone_lines+=l
		while current_zone_lines>=zone_req_line do
			current_zone_lines-=l
			current_zone+=zone_incr
			current_zone_lines=0
		end
		if (current_zone<1) then
			zone_label="zone"
		else 
			zone_label="max"
			current_zone=1
		end
	end 
end

function find_val(val,array)
	local l=#array
	for i=1,l do
		if (array[i]==val) return true
	end
	return false
end

function build_zone(l,lines)
	cumul_lines+=l
	pop_notif(cumul_lines.."lines",1)
	local offset=0
	local start_row=lines[l]+1
	for j=lines[1],grid_h do
		if (find_val(j,lines)) then
			offset+=1
		else
			for i=1,grid_w do
				grid[j-offset][i]=grid[j][i]
			end
		end
	end
	for j=1,cumul_lines do
		for i=1,grid_w do
			grid[grid_h-j+1][i]=zone_img
		end
	end
end

function calculate_drop()
	local c=curr_tetr
	local rot=c.data.rotation[c.rot_index]
	local row=grid_h
	local valid=true
	drop_row=grid_h
	for h=c.pos.y,grid_h do
		local row=h
		valid=validate_drop(c,row)
		if valid then
			drop_row=row
		else
			break
		end
	end
end

function validate_drop(c,row)
	local rot=c.data.rotation[c.rot_index]
	for j=1,c.data.h do
 	for i=1,c.data.w do
 		if rot[j][i]!=0 then
 			if row+j>grid_h then return false end 
 			if	grid[row+j][c.pos.x+i]!=0 then return false end
 		end
 	end
 end
 return true
end

function update_motif()
	notif_time-=1/30
	if (notif_time<=0) notif=""
end

function pop_notif(text,d)
	notif_time=d
	notif=text
end
-->8
--draw game

bgnd_index=1

c=cos
s=sin

function draw_game()
local g=grid_area
	if (not is_zone) then
		bgnd_anims[curr_lvl.data.bgnd_index]()
		rectfill(g.x,g.y,g.x+g.w,g.y+g.h,0)
	else
		rectfill(0,0,128,128,7)
		rectfill(g.x,g.y,g.x+g.w,g.y+g.h,7)
	end
--	draw_zone()
	rect(g.x-outline,g.y-outline,
	g.x+g.w+outline-1,g.y+g.h+outline-1,curr_lvl.data.theme_col)
	rect(g.x-outline-1,g.y-outline-1,
	g.x+g.w+outline,g.y+g.h+outline,5)
	if (curr_tetr.data~=nil) draw_drop()
	if (is_zone) then 
		palt(0,false)
		palt(15,true)
		
	end
	draw_zone()
	if (curr_tetr.data~=nil) draw_tetr()
	for j=1,grid_h do
 	for i=1,grid_w do
 		local img=grid[j][i]
 		if img!=0 then
 			if (is_zone and img~=zone_img) img=zone_cell
	 		spr(img,
	 		g.x+(i-1)*csize,
	 		g.y+(j-1)*csize)
	 	end
 	end
 end
 palt(0,true)
 palt(15,false)
 draw_particles()
 draw_next()
 draw_stat()
 draw_time_panel()
 draw_score()
 draw_notif()
end

function draw_tetr(g)
	local c=curr_tetr
	local g=grid_area
	for j=1,c.data.h do
		for i=1,c.data.w do
			local rot=c.data.rotation[c.rot_index]
			if (rot[j][i]==1) then
				local img=curr_lvl.data.img[c.index]
				if (is_zone) img=zone_tetr
				spr(img,
				g.x+(c.pos.x+i-1)*csize,
				g.y+(c.pos.y+j-1)*csize)	
			end
		end
	end
end

zone_pos={x=32-10,y=100}
zone_max_r=11

function draw_zone()
	circfill(zone_pos.x,zone_pos.y,zone_max_r+1,5)
	circfill(zone_pos.x,zone_pos.y,zone_max_r,0)
	if (current_zone>0) circfill(zone_pos.x,zone_pos.y,current_zone*zone_max_r,curr_lvl.data.theme_col)
	circ(zone_pos.x,zone_pos.y,zone_max_r,7)
	local col=7
	if (current_zone>=1) col=rnd(8)
	print(zone_label,zone_pos.x-#zone_label*2+2,zone_pos.y-1,0)
	print(zone_label,zone_pos.x-#zone_label*2+1,zone_pos.y-2,col)
end

function draw_drop()
	local c=curr_tetr
	local g=grid_area
	for j=1,c.data.h do
		for i=1,c.data.w do
			local rot=c.data.rotation[c.rot_index]
			if (rot[j][i]==1) then
				spr(drop_img,
				g.x+(c.pos.x+i-1)*csize,
				g.y+(drop_row+j-1)*csize)	
			end
		end
	end
end

next_win={x=128-37,y=14,w=csize*6-1,h=csize*4}

function draw_next()
	local n=next_win
	rectfill(n.x,n.y,
	n.x+n.w,n.y+n.h,0)
	rect(n.x-outline,n.y-outline,
	n.x+n.w+outline-1,n.y+n.h+outline-1,curr_lvl.data.theme_col)
	rect(n.x-outline-1,n.y-outline-1,
	n.x+n.w+outline,n.y+n.h+outline,5)
	local nxt=tetr[next_tetr]
	for j=1,nxt.h do
		for i=1,nxt.w do
			local rot=nxt.rotation[nxt.dflt]
			if (rot[j][i]==1) then
				spr(curr_lvl.data.img[next_tetr],
				n.x+n.w/2-nxt.w/2*csize+(i-1)*csize,
				n.y+n.h/2-(nxt.h/2-nxt.offsety)*csize+(j-1)*csize)	
			end
		end
	end
end

time_win={x=128-36,y=128-30,w=27,h=15}

function draw_time_panel()
	local n=time_win
	rectfill(n.x,n.y,
	n.x+n.w,n.y+n.h,0)
	rect(n.x-outline,n.y-outline,
	n.x+n.w+outline-1,n.y+n.h+outline-1,curr_lvl.data.theme_col)
	rect(n.x-outline-1,n.y-outline-1,
	n.x+n.w+outline,n.y+n.h+outline,5)
	local offset=2
	print("time: ",n.x+2,n.y+offset,7)
	offset+=6
	draw_time(offset)
end

stat_win={x=10,y=14,w=27,h=45}

function draw_stat()
	local n=stat_win
	rectfill(n.x,n.y,
	n.x+n.w,n.y+n.h,0)
	rect(n.x-outline,n.y-outline,
	n.x+n.w+outline-1,n.y+n.h+outline-1,curr_lvl.data.theme_col)
	rect(n.x-outline-1,n.y-outline-1,
	n.x+n.w+outline,n.y+n.h+outline,5)
	local offset=2
	print("stage: ",n.x+2,n.y+offset,7)
	offset+=6
	print(level_index.."/"..#levels,n.x+2,n.y+offset,6)
	offset+=8
	print("lines: ",n.x+2,n.y+offset,7)
	offset+=6
	print(curr_lvl.lines.."/"..req_tot[level_index],n.x+2,n.y+offset,6)
	offset+=8
	print("speed: ",n.x+2,n.y+offset,7)
	offset+=6
	print(curr_lvl.spd,n.x+2,n.y+offset,6)
end

function draw_time(offset)
 local n=time_win
	minstr=""
	local sec=flr(c_time)
	local minstr=flr(sec/60)
	if (minstr<10) then
		minstr="0"..minstr
	end
	sec=sec-minstr*60
	if (sec<10) then
		sec="0"..sec
	end
	local tmrstr=minstr .. ":" .. sec
	print(tmrstr,n.x+2,n.y+offset,6)
end

score_win={x=38,y=128-10,w=52,h=9}

function draw_score()
	local n=score_win
	rectfill(n.x,n.y,
	n.x+n.w,n.y+n.h,0)
	rect(n.x-outline,n.y-outline,
	n.x+n.w+outline-1,n.y+n.h+outline-1,curr_lvl.data.theme_col)
	rect(n.x-outline-1,n.y-outline-1,
	n.x+n.w+outline,n.y+n.h+outline,5)
	local score_str=score
	local digit=0
	while digit<5 do
		digit+=1
		local chk=1
		for i=1,digit do
			chk=chk*10
		end
		if (score<chk) score_str="0"..score_str
	end
	print("score: "..score_str,n.x+2,n.y+2,7)
end


function draw_notif()
	local shdw=0
	local txt=7
	if (is_zone) then
		shdw=7
		txt=0
	end
	
	print(notif,64-#notif*2+1,64-3+1,shdw)
	print(notif,64-#notif*2,64-3,txt)
end

function draw_bgnd_01()
	for r=4,64,4 do
 	for i=0,7/4,1/4 do
 		q=(time()*(1+r/32)/4)%1
 		v0=mid(0,(q-i)*4,1)
 		v1=mid(0,(q-i)*4+2,1)
 		a=i-1/4
 		x=64+cos(a)*r*0.71
 		y=64+sin(a)*r*0.71
 		r+=0.001 u=cos(a) v=sin(a)
 		--if(v1>v0)line(x+u*v0*r,y+v*v0*r,x+u*v1*r,y+v*v1*r,5)
 		if(v1>v0)circ(x+u*v0*r,y+v*v0*r,100,curr_lvl.data.theme_col)
 	end 
 end
end

bgnd_02={
	p={1,2,12,13}
}

function draw_bgnd_02()
 local t=time()
 local p=bgnd_02.p
 for i=0,1,.01 do 
  x=64+(32+sin(t)*7*sin(8*i+t/2))*cos(i)
  y=64+(64+sin(t)*7*sin(8*i+t/2))*sin(i)
  r=sin(t/4)*10*mul_bgnd*2*(sin(t/2+i*2))
  circfill(x,y,r+1,p[flr(4+sin(i)*cos(i)*3-.5)])
 end 
end

t=0
function draw_bgnd_03()
	camera(-8,-8)
	t+=.002
	for k=0,112,16 do
		for j=0,112,16 do
		a=0
		x=k
		y=j
		s=k%32>=16 and 0 or .25
		c=j%32>=16 and 2*s or .25
			for i=-8,8 do
				a+=i/32*(2*min(.5,.6*sin(t))-1)
				n=x+2*cos(a+s+c)m=y+2*sin(a+s+c)line(n,m,x,y,7)
				x=n
				y=m
			end
		end
	end
	camera(0,0)
end

bgnd_04={
	t=0,
	x=64,
	y=-5
}

function draw_bgnd_04()
local t=bgnd_04.t
local x=bgnd_04.x
local y=bgnd_04.y
t+=.015
for i=1,140,10 do
s=sin(t)*5*mul_bgnd
c=cos(t+i*0.01)*20*mul_bgnd
l=x+c
m=y+s+i
n=x-c
o=y-s+i
line(l,m,n,o,5)
line(l,m,l*0.5+n*0.5,m*0.5+o*0.5,4)
circfill(l,m,s*0.4+20+mul_bgnd*1,5)
circfill(n,o,-s*0.4+20+mul_bgnd*1,11)
end
bgnd_04.t=t
end

bgnd_05={
	q=0
}

function bgnd_05_helper(u,v,a,l)
	local q=bgnd_05.q
	local b=bgnd_05_helper
if(l<3)circfill(u,v,mul_bgnd,12+q%3)return
local x,y=u+cos(a)*l,v+sin(a)*l
line(u,v,x,y,13+q%3)q+=1
for i=0,1,0.34 do b(x,y,a+i+0.25+time()/16,l*0.6)
end 
end

function draw_bgnd_05()
local b=bgnd_05_helper
for i=0,1,.34 do
b(64,64,i+time()/16,40+mul_bgnd*2,7)end
end

bgnd_06={
	m=64,
	c=cos,
	s=sin,
	t=0
}

function draw_bgnd_06()
 local m=bgnd_06.m
 local c=bgnd_06.c
 local s=bgnd_06.s
 local t=bgnd_06.t
 t+=.002*mul_bgnd
 n,r=32,64-s(t)*32+10
 q=24
 for i=1,n do
  d=i/n+t
  e=(i+1)/n+t
  for j=1,n do
   f=j/n
   g=(j)/n
   o,p=max(d,e),min(d,e)
   line(
   m+c(o)*r*c(f+t),
   m+s(o)*r*s(f-t),
   m+c(p)*r*c(g+t),
   m+s(p)*r*s(g-t),i%4+12)
  end
 end
 bgnd_06.t=t
end

bgnd_07={
	p=0,
	t={7,7,10,9,8,4,2,1},
	o=0
}

function draw_bgnd_07()
	local p=bgnd_07.p
	local t=bgnd_07.t
	local o=bgnd_07.o
	for j=1,16 do
  for i=1,16 do
  a=(i+p+j/2)/16r=48z=r*cos(a)e=i*8-64
  x=64+(e*cos(o)-z*sin(o))z=64+(e*sin(o)+z*cos(o))z=z/128x=32*z+x/(1+z)y=32*z+j*8/(1+z)s=4-3*z
  circfill(x-s/2,y-s/2,s+10,t[flr(2+z*6)])
  end
 end
 bgnd_07.p+=.10*mul_bgnd
 bgnd_07.o-=.001
end

bgnd_08={
	s=128,
	x=1,
	d=1,
	col={8,9,10,2}
}

function draw_bgnd_08()
	local s=bgnd_08.s
	local x=bgnd_08.x
	local d=bgnd_08.d
 x+=d
 z=ceil(sin(x/s)*20*mul_bgnd)
 if(x>s/2)d*=-1
 for j=1,15 do
 --fillp(0b1111000011110000.1+j)
 circfill(s/2,s/2,50+z-j*4+20,bgnd_08.col[j%#bgnd_08.col+1])
 end
 bgnd_08.x=x
end

t=0
function draw_bgnd_09()
t+=.1
for y=-64,64,3 do
d=y%6/3*3
for x=-75+d,64+d,6 do
a=atan2(x,y)
r=sqrt(x*x+y*y)/64
c=mul_bgnd*r*cos(r/2+a*2-t/5)+2*sin(t/16)
--rectfill(x+64,y+64,x+68,y+65,7+c%7)
circfill(x+64,y+64,1+mul_bgnd*2,7+c%7)
end
end
end

function draw_bgnd_10()
	u=7*time()q=1p=1
for i=0,49 do
z=i
k=min(1,i/4)x=64*cos((64+q))y=64+32*sin((77+q))
for j=0,1,1/60 do
r=(3*z+20)*(.8+.2*cos(j*p-u/23))
pset(x+r*cos(j),y+r*sin(j),"0x"..sub("1249fa7",k,k+1))
end
end
end

--fillp(23130)
function draw_bgnd_11()
local z=cos
g=time()/9w="1224499aaff777"for i=0,1,.004 do
l=32+2*z(i*3+z(g))x=l*z(i)y=l*sin(i)for k=0,3 do
o=k/4+z(i-g)*z(g)/2-g+i/2p=sin(o)+2s=z(o)+2
if(s>p)for n=0,3 do line(64+x*s+n%2,64+y*s+n/2,64+x*p+n%2,64+y*p+n/2,'0x'..sub(w,1,(s-p)*11))end
end end
end

bgnd_12={
	l={}
}

function bgnd_12_helper()
	local l=bgnd_12.l
	add(l,{x=64,y=64,a=rnd(),r=2+rnd(4)})
end


function draw_bgnd_12()
	local a=bgnd_12_helper
	local l=bgnd_12.l
	a()a()a()a()a()a()
	for k,p in pairs(l)do
		p.a+=rnd(.1)-.05
		p.r*=.88+((mul_bgnd-1)/100*4)+rnd(.1)
		p.x+=p.r*cos(p.a)p.y+=p.r*sin(p.a)
		circfill(p.x,p.y,p.r)
		if(p.r<.1)del(l,p)
		end
		bgnd_12.l=l
end

bgnd_13={
	t=0,
	k=0
}

function draw_bgnd_13()
	local t=bgnd_13.t
	local k=bgnd_13.k
	for a=0,1,.5 do
for b=0,1.1,.1 do
for c=0,1.1,.05 do
 i=cos(c+b+a)*40
 j=sin(c+t+b)*32
 circfill(i+64+(sin(k+c*a)*i/2),
 j+64+(cos(k+c*a)*20),
 c+b+a,28+b*3)
end 
end
bgnd_13.k+=.004
end
bgnd_13.t+=.001+(mul_bgnd-1)/100
end

function draw_bgnd_14()
	t+=.02+(mul_bgnd-1)/100
 h=1
 for x=-64,64,4 do
 for y=-64,64,4 do
 a=atan2(x,y)
 r=sqrt(x*x+y*y)/64
 s,c=2*sin(t+a+r*t),2*cos(t+a+r*t)
 n,m=64+x+s,64+y+c
 --rectfill(n-h,m-h,n+h,m+h,10)
 circfill(n-h,m-h,1,12)
 end
 end
end

--fillp(23130)
bgnd_15={
	z=0,
	c={1,2,4,9,15,10,7,7}
}

function draw_bgnd_15()
	local z=bgnd_15.z
	local c=bgnd_15.c
	for y=0,127 do
q=y/128
r,w=q*sin(z)/20+z,sin(z+q)+32
for f=0,.75,.25 do
a,b=cos(f+r),cos(f+r+.25)
j=abs(a-b)*5
g,h=c[flr(j+1)],c[flr(j+1.5)]
if(a<b)rect(a*w+64,y,b*w+64,y,g+h*16)
end
end
bgnd_15.z+=0.004
end

bgnd_16={
	s=64,
	t=0
}

function draw_bgnd_16()
local t=bgnd_16.t
local s=bgnd_16.s
bgnd_16.t+=.0001
x=s y=s
for i=1,300 do
j=i*t
u=x
v=y
x=x+j*sin(j)y=y+j*cos(j)
--line(u,v,x,y,rnd(2)+8)
circfill(x,y,15,rnd(3)+9)
end
end

bgnd_17={
	x=64,y=64,r=1,a=0,t=0
}

function draw_bgnd_17()
	local x=bgnd_17.x
	local y=bgnd_17.y
	local r=bgnd_17.r
	local a=bgnd_17.a
	local t=bgnd_17.t 
for i=0,150 do
printh(r)
 circfill(x,y,r/2,6+i%3)
 x+=cos(a)*r y+=sin(a)*r
 r+=1/16 a+=t/5
end
bgnd_17.x=x
bgnd_17.y=y
bgnd_17.r=r
bgnd_17.a=a
bgnd_17.t+=0.001
end

function draw_bgnd_18()
	for i=-70,-60 do
 circ(64,
 64,
 (i+130+(mul_bgnd-1)*10),
 (i+t*100)%2+9)end
 t-=.01
end

bgnd_anims={
	draw_bgnd_01,
	draw_bgnd_02,
	draw_bgnd_03,
	draw_bgnd_04,
	draw_bgnd_05,
	draw_bgnd_06,
	draw_bgnd_07,
	draw_bgnd_08,
	draw_bgnd_09,
	draw_bgnd_10,
	draw_bgnd_11,
	draw_bgnd_12,
	draw_bgnd_13,
	draw_bgnd_14,
	draw_bgnd_15,
	draw_bgnd_16,	
 draw_bgnd_17,
 draw_bgnd_18
}

bgnd_count=#bgnd_anims
-->8
--levels
level_index=1

curr_lvl={
	data=nil,
	spd_index=1,
	lines=0
}

speeds={
1.2,
1,
0.95,
0.85,
0.8,
0.75,
0.7,
0.65,
0.6,
0.55,
0.5,
0.45,
0.3,
0.2,
0.15,
0.1,
0.05
}

col={
	8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0,
	0,8,9,3,12,6,14,2,4,13,15,11,0,0,0,0
}

spiral={
	bgnd_index=1,
	img={85,89,90,85,89,90,85},
	theme_col=1
}

blue_wave={
	bgnd_index=2,
	img={119,116,117,119,116,117,116},
	theme_col=13
}

radioactive={
	bgnd_index=4,
	img={131,139,136,131,139,136,130},
	theme_col=3
}

crystal={
	bgnd_index=5,
	img={36,37,41,36,37,41,36},
	theme_col=12
}

the_eye={
	bgnd_index=6,
	img={166,169,164,166,169,164,170},
	theme_col=14
}

fire={
	bgnd_index=7,
	img={97,98,104,97,98,104,103},
	theme_col=8
}

sauron={
	bgnd_index=8,
	img={113,114,119,113,114,119,113},
	theme_col=2
}

raimbow={
	bgnd_index=9,
	img={11,4,2,1,9,5,1},
	theme_col=7
}

snow={
	bgnd_index=12,
	img={133,133,133,133,133,133,133},
	theme_col=7
}

planetarium={
	bgnd_index=13,
	img={4,6,7,4,6,7,4},
	theme_col=14
}

goodnight={
	bgnd_index=14,
	img={180,186,181,180,186,181,182},
	theme_col=1
}

levels={
planetarium,
blue_wave,
crystal,
radioactive,
the_eye,
sauron,
goodnight,
snow,
spiral,
fire,
raimbow}

start_spds={
1,
2,
3,
4,
5,
6,
7,
12,
13,
14,
15
}

spd_changes={
	{2},
	{3},
	{4,5},
	{5,6},
	{7,8},
	{8,9},
	{10,12},
	{11,12},
	{12,13},
	{14,15},
	{16,17}
}

req_lines={
	{5},
	{8},
	{10,12},
	{10,15},
	{12,15},
	{15,20},
	{15,20},
	{15,20},
	{15,20},
	{15,20},
	{20,30,40}
}

req_tot={
	10,
	12,
	15,
	18,
	20,
	22,
	25,
	25,
	25,
	30,
	40
}

scores={
4,
10,
30,
120,
200,
225,
250,
275,
500,
1000,
1100,
1200,
1300,
1400,
1500,
2000}
-->8
--particles
sparks={}

for i=1,200 do
	add(sparks, {
	x=0,y=0,velx=0,vely=0,
	r=0,alive=false,mass=0,lifetime=0,
	col=0,life=0,start_r=0
	})
end

function explode(x,y,r,velx,vely,mass,count,lifetime,col)
	local selected=0
	for i=1,#sparks do
		if not sparks[i].alive then
			sparks[i].x=x
			sparks[i].y=y
			local direct=-1
			if (flr(rnd(10))+1>5) direct=1
			sparks[i].velx=direct*rnd(velx)
			sparks[i].vely=-1+rnd(vely)
			sparks[i].mass=0.5+rnd(mass)
			sparks[i].start_r=0.5+rnd(r)
			sparks[i].alive=true
			sparks[i].lifetime=lifetime
			sparks[i].life=lifetime
			sparks[i].col=col
			selected+=1
			if selected==count then break end			
		end
	end
end

function update_particles()
	for i=1,#sparks do
		local s=sparks[i] 
		if s.alive then
			sparks[i].life-=1/30
			if (sparks[i].life<=0) sparks[i].alive=false
			local p=sparks[i].life/sparks[i].lifetime
			sparks[i].r=p*sparks[i].start_r
			sparks[i].x+=s.velx/ s.mass
			sparks[i].y+=s.vely / s.mass
		end
	end
end

function draw_particles()
	for i=1,#sparks do
		if sparks[i].alive then
			circfill(
				sparks[i].x,
				sparks[i].y,
				sparks[i].r,
				sparks[i].col
			)
		end
	end
end