--matchy matchy
--by ilkke

-- alt inputs (never both)
mouse=false
touch=false

-- misc level stuff
level=0
levelsize=30
totallevels=35 -- sel.w * sel.h

-- holders for level data
levels={} -- 0 locked, 1 unlocked, 2 beat, 3 aced
levels[1]=1 -- unlock first level
--scores={} -- score per level

-- load data if present
cartdata("ilkke_matchy")
local d=dget(0)
if d!=0 then
 printh ("loading savegame")
 local n
 for n=0,totallevels-1 do
  levels[n+1]=dget(n)
 end
else
-- if not fill with zeroes
 printh ("nothing to load")
 local n
 for n=1,totallevels-1 do
  levels[n+1]=0
 end

end

function savegame()
 printh ("saving game")
 local n
 for n=0,totallevels-1 do
  dset(n,levels[n+1])
 end
end


--
-- statemachine
--

menustate=0
gamestate=1
selectstate=2
modestate=3
endstate=4

state=menustate

function setstate(s)
 state=s
 _init()
end

function _init()
 if (state==menustate) then 
  menuinit()
 elseif (state==gamestate) then
  gameinit()
 elseif (state==modestate) then
  modeinit()
 elseif (state==selectstate) then
  selectinit()
 elseif (state==endstate) then
  endinit()
 end
end

function _update()
 if (state==menustate) then
  menuupdate()
 elseif (state==gamestate) then
  gameupdate()
 elseif (state==modestate) then
  modeupdate()
 elseif (state==selectstate) then
  selectupdate()
 elseif (state==endstate) then
  endupdate()
 end
end

function _draw()
 if (state==menustate) then
  menudraw()
 elseif (state==gamestate) then
  gamedraw()
 elseif (state==modestate) then
  modedraw()
 elseif (state==selectstate) then
  selectdraw()
 elseif (state==endstate) then
  enddraw()
 end
-- print(stat(0),0,0,7)
end

--
-- menu state
--

function menuinit()
 if (not playing) then
  music(2)
  playing=true
 end
	initheart()
 heart.col=1
 heart.angle=0
 heart.on=true
end

function menuupdate()
 heart.zum=300+abs(sin(heart.angle))*300
 heart.angle+=0.015
 if btnp(4) then
  sfx(7)
  setstate(modestate)
 end
end

function menudraw()
 cls()
 drawheart()
	drawlogo(6,42)
	drawpressplay()
	drawcopyright()
end

function	drawcopyright()
 local t="(c)2016 by ilkke"
 print (t,64-#t*2,120,12)
end
function drawpressplay()
 palt(11,true)
 palt(0,false)
 if (heart.zum<500) then
  spr(96,32,88,8,1)
 end
 palt()
end

function drawlogo(x,y)
 for s=0,13 do
  local wob=sin(2*heart.angle+s/15)*2
	 drawsegment(64+s,x+s*8,y+wob)
	end
end

function drawsegment(s,x,y)
 -- shadow
 stencil(0)
 local sd=5
 spr(s,x+sd,y+sd,1,2)
 spr(s,x+5+sd,y+17+sd,1,2)
 --matchy yellow
	pal()
 spr(s,x,y,1,2)
 --matchy red
	pal(4,2) pal(9,8) pal(10,14)
 spr(s,x+5,y+17.5,1,2)
	pal()

-- spr(s,x,y,1,2)
end

function drawlogo2(x,y)
 -- shadow
 stencil(0)
 local sd=3
 spr(64,x+sd,y+sd,14,2)
 spr(64,x+5+sd,y+17+sd,14,2)

 -- outline
 stencil(0)
 for ix=-1,1,2 do
  for iy=-1,1,2 do
--		 spr(64,x+ix,y+iy,14,2)
--		 spr(64,x+5+ix,y+17+iy,14,2)
		end
 end
 --matchy yellow
	pal()
 spr(64,x,y,14,2)
 --matchy red
	pal(4,2) pal(9,8) pal(10,14)
 spr(64,x+5,y+17,14,2)
	
	pal()
end

function stencil(c)
 for oc=0,15 do
  pal(oc,c)
 end
end

--
-- mode state
--

function modeinit()
 ly=42
 initmodes()
end

function modeupdate()
 if (ly>28) ly-=(ly-28)/3
 heart.zum=300+abs(sin(heart.angle))*300
 heart.angle+=0.015
 modecontrols()
end

function modedraw()
 cls()
 drawheart()
 drawmodes()
	drawlogo(6,ly)
	drawmodeinfo()
end

function modecontrols()

 local y=modes.selected
 
 if btnp(2) then 
  sfx(8)
  y-=1
 end
 if btnp(3) then
  sfx(8)
  y+=1
 end
 
 y=max(1,y)
 y=min(2,y)
 
 modes.selected=y

 if btnp(4) then
  if modes.selected==1 then
   sfx(6)
   setstate(selectstate)
  end
  if (modes.selected==2) then
   sfx(6)
   setstate(gamestate)
  end
 end
end

function initmodes()
 if modes==nil then
  modes={}
  modes[1]={"puzzle","can you clear all the pieces?"}
--  modes[1]={"puzzle","solve levels at your own pace"}
  modes[2]={"time attack","endless mode that gets faster"}
  modes.selected=1
 end
end

function drawmodeinfo()
 local t=modes[modes.selected][2]
 print (t,64-#t*2,120,12)
end

function drawmodes()
 drawoption(1)
 drawoption(2)
end

function drawoption(n)
 -- colors
 local c1 local c2
 if n==modes.selected then
  c1=9 c2=4
 else
  c1=8 c2=2 
 end
 -- pad and size
 local padh=20
 local padv=4
 local h=16
 local top=(padv+h)*(n-1)+72
 -- draw box
 transfill (padh,top,128-padh,top+h,c1,c2)
 -- title
 local t=modes[n][1]
 print(t,64-#t*2+1,top+h/2-2,1)

 print(t,64-#t*2,top+h/2-1,1)
 print(t,64-#t*2+1,top+h/2-1,0)
 print(t,64-#t*2,top+h/2-2,7)
end

function transfill(x1,y1,x2,y2,c1,c2)
 -- transparency
 local c
 for x=x1,x2 do
  for y=y1,y2 do
   c=pget(x,y)
   if (c==0) pset(x,y,c2)
   if (c==1) pset(x,y,c1)
  end
 end
 -- rounded corners
 pset(x1,y1,0)
 pset(x2,y1,0)
 pset(x1,y2,0)
 pset(x2,y2,0)
end

--
-- selector state
--

function selectinit()
 sel={}
 --
 sel.w=7 -- columns
 sel.h=5 -- rows
 sel.offset=0 -- start row
 --position
 sel.offx=8
 sel.offy=25
 
 initcursor()
 
 heart.col=2
end

function selectupdate()
 heart.zum=300+abs(sin(heart.angle))*300
 heart.angle+=0.015

 updatecursor()
 selectbuttons()
end

function selectdraw()
 cls()
 drawheart()
 drawlevelgrid()
 drawcursor()
end

function drawlevelgrid()
 palt(0,false)
 local lev=sel.w*sel.offset+1
 local s
 --
 for h=0,sel.h-1 do
  for w=0,sel.w-1 do
   if levels[lev] then
    s=levels[lev]
   else
    s=0
   end
   drawcell(lev,w*16+sel.offx,h*16+sel.offy,s)
   lev+=1
  end
 end
 palt(0,true)
end

function drawcell(n,x,y,s)
 palt(11,true)
 local sp=s+39
 --
 spr(sp,x,y,1,2)
 spr(sp,x+7,y,1,2,true,false)
 
 local c
 if (s==0) c=2
 if (s==1) c=4
 if (s==2) c=4
 if (s==3) c=2
 --
 if (s==0) then
  spr(11,x+4,y+2)
 else
  local tx=padscore(""..n,2)
  print(tx,x+4,y+4,c)
 end
 palt(11,false)
end

function selectbuttons()
 if btnp(5) then
  sfx(7)
  setstate(menustate)
 end
 if btnp(4) or (mouse and mouseclick()) then
  level=levelundercursor()
  if levels[level+1]!=nil then
   if (levels[level+1]>0) then
    sfx(6)
    setstate(gamestate)
   else
    sfx(9)
   end
  end
 end
 if (touch) testtouch()
end

function levelundercursor()
 local l
  l=(crsr.y-1)*sel.w+crsr.x
 return l
end
--
-- game state
--

function gameinit()
 music(-1)
 playing=false
 cls()
 bgc=0
 rainbow_on=false
 initcursor()
 initscore()
 initmessage()
 initheart()

 pmenu={}

 -- puzzle mode
 if modes.selected==1 then
  srand(level)
  nextlevel()
 -- endless mode
 elseif modes.selected==2 then
  initpieces2()
  inittimer()
  heart_out(0,heartoff)
 end
end

function gameupdate()
 if not pause then
  updatecursor()
  gamebuttons()
  if (modes.selected==2) then
   updatetimer()
   if movesleft()==0 then 
    pause=true
    levelcomplete()
   end
  end
 end
  bitsupdate()
  updateanimations()
  updateheart()
  updatemessage()
end

function gamedraw()
 cls()
 drawbg()
 drawpieces()
 drawanimations()
-- if (not touch) drawcursor()
 bitsdraw()
 drawcursor()
 drawinfo()
 if (mouse) drawmouse()
 if (rainbow_on) cls(bgc)
 drawheart()
 drawmessage()
 if (modes.selected==2) drawtimer()
 if (pmenu.on) drawpausemenu()
end

-- board

function drawbg()
 -- draw chequered pattern
 for y=0,6 do
  for x=0,7 do
   if (x%2 != y%2) then
    col=1
   else
    col=2
   end
   rectfill(x*16,y*16,(x+1)*16,(y+1)*16,col)
  end
 end
 -- draw board edge
 local data={}
 data[1]={0,16,16,16,16,16,16,16,16}
 data[2]={1,16,15,16,16,16,16,16,16}
 data[3]={2,16,15,16,15,16,15,16,17}
 data[4]={3,16,14,16,15,16,15,16,17}
 for i=1,4 do
  y=127-16+i
  x=0 c=0
  for j=1,9 do
   line(x,y,x+data[i][j],y,c)
   x+=data[i][j]
   if c==0 then
    c=1
   else
    c=0
   end
  end
 end
end

-- timer

function inittimer()
 timer={}
 timer.t=128
 timer.speed=0
 timer.inc=0.05 -- add
 timer.relief=0.75 -- mult
end

function updatetimer()
 timer.t-=timer.speed
 if timer.t<1 then
  timer.t=128
	 spawnrandompiece()
 end
end

function drawtimer()
 rectfill(0,126,timer.t,127,2)
end

function faster()
 timer.speed+=timer.inc
end

function slower()
 printh("slower")
 timer.speed*=timer.relief
end

-- pieces

-- spawn random piece
function spawnrandompiece()
 sfx(7)
 local fails=0

 local x
 local y
 x=flr(rnd(8))+1
 y=flr(rnd(7))+1 
 
 while (pieces[x][y]!=0) do
  x=flr(rnd(8))+1
  y=flr(rnd(7))+1 
  fails+=1
  if (fails>100) return
 end
  
 pieces[x][y]=flr(rnd(7))+1
 local bit={}

 bit.c=10
 bit.no=8
 bit.t=10
 bit.x=x*16-8
 bit.y=y*16-8
 bit.i=0.5
 bitsinit(bit)
end

-- spawn solvable map
function initpieces()
 printh("------------------")
 rounds=levelsize
 pieces={}
	matched={}
	
 -- fill with 0
 for i=1,8 do
  pieces[i]={}
  for j=1,7 do
   pieces[i][j]=0
  end
 end
 
 fails=0
 -- pick random spots and test for neighbours
 while rounds>0 do
  local rx=flr(rnd(6)+2)
  local ry=flr(rnd(5)+2)

  local vacant=0
  local freedir={false,false,false,false}

  if ry>2 then
   if (pieces[rx][ry-1]==0) then 
    vacant+=1
    freedir[1]=true
   end
  end
  if ry<7 then
   if (pieces[rx][ry+1]==0) then 
    vacant+=1
    freedir[2]=true
   end
  end
  if rx>2 then
   if (pieces[rx-1][ry]==0) then
    vacant+=1
    freedir[3]=true
   end
  end
  if rx<8 then
   if (pieces[rx+1][ry]==0) then 
    vacant+=1
    freedir[4]=true
   end
  end

  if vacant>1 and (pieces[rx][ry]==0) then
   spawnpair(rx,ry,freedir)
   rounds-=1
  else
   fails+=1
   if fails>1000 then 
    printh("pairs unspawned:"..rounds)
--    printh("fails:"..fails)
    break 
   end
  end

 end
end

function spawnpair(x,y,free)
-- printh("spawning a pair at "..x.."/"..y)
 -- clear directions
 local u=1 local d=1
 local l=1 local r=1
 -- scan
 while y-u>0 and pieces[x][y-u]==0 do
  u+=1
 end
 while y+d<8 and pieces[x][y+d]==0 do
  d+=1
 end
 while x-l>0 and pieces[x-l][y]==0 do
  l+=1
 end
 while x+r<9 and pieces[x+r][y]==0 do
  r+=1
 end
 
 --remove unavailable dirs

 d1=flr(rnd(4))+1
 while not free[d1] do
  d1=flr(rnd(4))+1
 end
 free[d1]=false
 d2=flr(rnd(4))+1
 while not free[d2] do
  d2=flr(rnd(4))+1
 end
 
 -- random animal
 local pc=flr(rnd(7))+1
 --spawn a pair
 local dirs={u,d,l,r}
 spawnindir(pc,x,y,d1,dirs[d1]-1)
 spawnindir(pc,x,y,d2,dirs[d2]-1)

end

-- returns length of a table
function len(a)
 local l=0
  local i
  for i in all(a) do
   l+=1
  end
 return l
end

-- spawn an animal in direction
function spawnindir(pc,x,y,d,dist)
-- printh("-spawning a "..name(pc).." dir:"..d.." dist "..dist)
 if (d==1) pieces[x][y-dist]=pc
 if (d==2) pieces[x][y+dist]=pc
 if (d==3) pieces[x-dist][y]=pc
 if (d==4) pieces[x+dist][y]=pc
end

-- spawn level pieces at random
function initpieces2()
 local chance=0.75
 pieces={}
 -- placeholder board gen
 for x=1,8 do
  pieces[x]={}
  for y=1,7 do
   if rnd(1)<chance then
    pieces[x][y]=flr(rnd(7))+1
   else
    pieces[x][y]=0
   end
  end
 end 
 --

 matched={}
end

function drawpieces()
 palt(0,false)
 for y=0,6 do
  for x=0,7 do
   if pieces[x+1][y+1]>0 then
    drawpiece(pieces[x+1][y+1],x*16,y*16)
   end
  end
 end
end

function drawpiece(p,x,y)
 local r=rnd(1.003)

 if (x/16%2 != y/16%2) p+=32
 spr(p-1,x,y+r,1,2)
 spr(p-1,x+8,y+r,1,2,true,false)
end

-- cursor

function initcursor()
 crsr={}
 crsr.zum=0
 
 if (state==gamestate) then
  crsr.s=9
  --offsets
  crsr.x=4
  crsr.y=4
  crsr.offx=8
  crsr.offy=8
  --bounds
  crsr.bl=0
  crsr.br=7
  crsr.bu=0
  crsr.bd=6
 elseif (state==selectstate) then
  crsr.s=43
  --offsets
  crsr.x=0
  crsr.y=1
  crsr.offx=0
  crsr.offy=0
  --bounds
  crsr.bl=0
  crsr.br=6
  crsr.bu=1
  crsr.bd=5
 end
 --
 if (mouse or touch) mouseinit()
 if (touch) inittouch()
end

function updatecursor()
 movecursor()
 if crsr.zum>0 then
  crsr.zum-=0.75
 else 
  crsr.zum=0
 end
end

function movecursor()
 -- mouse
 if (mouse) then
  if mousey()<112 then
   crsr.x=flr(mousex()/16)
   crsr.y=flr(mousey()/16)
  end
 end
 -- keys
 if btnp(0) then
  sfx(8)
  crsr.x-=1
  crsr.x=max(crsr.bl,crsr.x)
  bumpcursor()
 elseif btnp(1) then
  sfx(8)
  crsr.x+=1
  crsr.x=min(crsr.br,crsr.x)
  bumpcursor()
 elseif btnp(2) then
  sfx(8)
  crsr.y-=1
  crsr.y=max(crsr.bu,crsr.y)
  bumpcursor()
 elseif btnp(3) then
  sfx(8)
  crsr.y+=1
  crsr.y=min(crsr.bd,crsr.y)
  bumpcursor()
 end
end

function bumpcursor()
 crsr.zum=2
end

function drawcursor()
 palt(0,false)
 palt(11,true)

 local dx=crsr.x*16-crsr.offx
 local dy=crsr.y*16-crsr.offy
 local z=crsr.zum
 local s1=crsr.s
 local s2=crsr.s+16

 spr(s1,dx+5-z,dy+6-z)
 spr(s1,dx+19+z,dy+6-z,1,1,true,false)

 spr(s2,dx+5-z,dy+19+z)
 spr(s2,dx+19+z,dy+19+z,1,1,true,false)
 
 palt(11,false)
end

function gamebuttons()

 if btnp(5) then
  sfx(7)
  pausegame(true)
 end
 
 if btnp(4) or (mouse and mouseclick()) then
  testmatch(crsr.x,crsr.y)
 end
 
 if (touch) testtouch()
 
end

-- matching

function testmatch(x,y)
 local matched=false
 local couples=0
 if pieces[x+1][y+1]==0 then
  --scan
  local pcs=scan(x,y)
  --count
  local count={}
  for i=1,7 do
   count[i]=0
   for j=1,4 do
    if pcs[j][1]==i then
     count[i]+=1
    end
   end
  end
  --read the count
  for i=1,7 do
   local c=count[i]
   if c>1 then
    --a match!
    matched=true
    if (modes.selected==2) faster()
    for j=1,4 do
     if pcs[j][1]==i then
      --piece is in a match
						matchpiece(pcs[j][2]-1,pcs[j][3]-1,x,y)
     end
    end
    --score
    if (c==4) then
     sfx(12)
     score+=score_4some
     showmessage("love rectangle!",40)
    elseif (c==3) then
     sfx(11)
     score+=score_3some
     showmessage("love triangle!",40)
    elseif (c==2) then
    couples+=1
    end
   end
  end
  --more score
  if (couples==2) then
   sfx(12)
   score+=score_4some
   showmessage("double date!",40)
  elseif (couples==1) then
   sfx(10)
   score+=score_pair
  end
 else
  --todo lose life
 end
 if (matched) queueheart()
 if not matched then
  sfx(9)
  if (modes.selected==2) spawnrandompiece()
 end
end

-- add a heart at intersection
function queueheart()
 local h={}
 h.x=crsr.x
 h.y=crsr.y
 h.tx=h.x
 h.ty=h.y
 h.s=8
 h.timer=10
 add(matched,h)
end

function matchpiece(x,y,tx,ty)
 local p={}
 p.x=x
 p.y=y
 p.tx=tx
 p.ty=ty
 p.s=pieces[x+1][y+1]
 add(matched,p)
 killpiece(x,y)
end

function killpiece(x,y)
 pieces[x+1][y+1]=0
end

-- scanning

function scan(x,y)
 x+=1
 y+=1
 local pcs={}
 pcs[1]=scanup(x,y)
 pcs[2]=scanright(x,y)
 pcs[3]=scandown(x,y)
 pcs[4]=scanleft(x,y)
 return pcs
-- return " ⬆️"..pcs[1].." ⬇️"..pcs[3].." ➡️"..pcs[2].." ⬅️"..pcs[4]
end

function scanup(x,y)
 local dy=y-1
 while dy>0 do
  if pieces[x][dy]>0 then
   return {pieces[x][dy],x,dy}
  end
  dy-=1
 end
 return {0,0,0}
end

function scandown(x,y)
 local dy=y+1
 while dy<8 do
  if pieces[x][dy]>0 then
   return {pieces[x][dy],x,dy}
  end
  dy+=1
 end
 return {0,0,0}
end

function scanright(x,y)
 local dx=x+1
 while dx<9 do
  if pieces[dx][y]>0 then
   return {pieces[dx][y],dx,y}
  end
  dx+=1
 end
 return {0,0,0}
end

function scanleft(x,y)
 local dx=x-1
 while dx>0 do
  if pieces[dx][y]>0 then
   return {pieces[dx][y],dx,y}
  end
  dx-=1
 end
 return {0,0,0}
end

-- flow

function isboardclear()
-- local clear=true
 for i=1,8 do
  for j=1,7 do
   if pieces[i][j]>0 then
			 return false
   end
  end
 end
 return true
end

function countpieces()
 local c=0
 for i=1,8 do
  for j=1,7 do
   if pieces[i][j]>0 then
			 c+=1
   end
  end
 end
 return c
end

function gameover()
 setstate(endstate)
end

function endinit()
 cls(0)
 sfx(14)
 heart_out(8,heartoff())
 heart.zumstep=0.9
 heart.broken=false
end

function endupdate()
 if heart.broken==false then
  if (heart.zum>150) then
   updateheart()
  else
   heart.broken=true
   heartoff()
   
   local bit={}
   bit.c=2
   bit.no=32
   bitsinit(bit)
  end
 else
  bitsupdate()
  -- any key to go back
  if (btnp(4)) backtomenu()
  if (btnp(5)) backtomenu()
 end
end

function enddraw()
 cls()
 if heart.broken then
  bitsdraw()
  spr(104,47,46,4,4)
  palt(11,true)
  palt(0,false)
  spr(112,37,78,7,1)
  palt(11,false)
  drawscore(46,90)
 else
  drawheart()
 end
end

function backtomenu()
 bitsclear()
 setstate(menustate)
end

function bitsclear()
 bits={}
end

function bitsinit(bit)
printh("bits init")
 bits={}
 bits.no=bit.no
 if bit.x!=nil then
  bits.x=bit.x
  bits.y=bit.y
 else
  bits.x=63
  bits.y=63
 end
 local b
 for b=1,bits.no do
  addbit(bit.c,bit.t,bit.i)
 end
end

function bitsupdate()
 for b in all(bits) do
  b.x+=b.xs
  b.y+=b.ys
  b.xs*=b.inert
  b.ys*=b.inert
  if (b.t !=0) then
   b.t-=1
   b.s-=0.5
  end
  if b.t==1 then
--  if b.xs<0.01 and b.ys<0.01 then
   del(bits,b)
  end
 end
end

function bitsdraw()
 for b in all(bits) do
--  pset(b.x,b.y,8)
  rect(b.x,b.y,b.x+b.s-1,b.y+b.s-1,b.c)
 end
end

function addbit(c,t,i)
 local b={}

 b.x=bits.x
 b.y=bits.y
 b.xs=rnd(16)-8
 b.ys=rnd(16)-8
 b.s=rnd(1)+1
 b.c=c
 
 if i!=nil then
  b.inert=i
 else
  b.inert=0.8
 end
 if t!=nil then
  b.t=t
 else
  b.t=0
 end
 add(bits,b)
 return b

end

function levelcomplete()
 printh("---levelcomplete()")
 
 -- puzzle
 if modes.selected==1 then

  if isboardclear() then
   sfx(15)
   showmessage("level clear!",60)
   if (levels[level]<3) levels[level]=3 -- ace
   unlocklevel(level+1)
   savegame()
   heart_in(8,rainbow)
  else
   showmessage("no moves left!",60)
   if (levels[level]<2) levels[level]=2 -- complete
   unlocklevel(level+1)
   savegame()
   heart_in(0,nextlevel)
  end

--  rainbow(1)

    
 -- endless
 elseif modes.selected==2 then
  local c=countpieces()
  printh ("pieces left: "..c)
  -- board mostly clear
  if c < 12 then
   pause=true
   sfx(15)
   showmessage("level up!",60)
   heart_in(0,levelup)
      
  -- board mostly full
  elseif c > 50 then
   showmessage("game over!",60)
   heart_in(0,gameover)
   
  -- in between
  else 
   local n
   for n=1,8 do
    spawnrandompiece()
   end
   sfx(13)   
   showmessage("raining cats and dogs!",20)
   pause=false
  end
 end

end

function unlocklevel(l)
 if (levels[l]==0) levels[l]=1
end

function levelup()
 initpieces2()
 slower()
 score+=score_levelup
 heart_out(0,heartoff)
 level+=1
end

function nextlevel()

 level+=1
 if level>totallevels then
	initheart()
 heart.col=1
 heart.angle=0
 heart.on=true
  setstate(selectstate)
  return
 end
 
 -- unlock
 if (levels[level]==0 or levels[level]==nil) levels[level]=1

 printh(" -- level "..level.." --")

 srand(level)
 initpieces()
 heart_out(0,heartoff)
end

-- animated pieces/hearts

function updateanimations()
 local p
 for p in all(matched) do
  local dh=p.tx-p.x
  local dv=p.ty-p.y
  p.x+=dh/2
  p.y+=dv/2
  if (p.s==8) then
   p.timer-=1
   if (p.timer<1) del(matched,p)
  elseif (abs(dh)<0.05 and abs(dv)<0.05) then
   del(matched,p)
   if #matched==1 and pause==false then
    if (movesleft()==0) levelcomplete()
   end
  end 
 end
end

function drawanimations()
 local p
 palt(1,true)
 palt(2,true)
 for p in all(matched) do
  if(p.s==8)then
   palt(1,false)
   palt(2,false)
   palt(11,true)
   spr(7,p.x*16,p.y*16,2,2)
  else
   drawpiece(p.s,p.x*16,p.y*16)
  end
 end
 palt(1,false)
 palt(2,false)
 palt(11,false)
end

-- hud

function initscore()
 score=0
 score_pair=10
 score_3some=20
 score_2pairs=30
 score_4some=40
 score_levelup=100
end

function drawinfo()
 drawlevelnumber()
 drawscore(89,118)
end

function drawlevelnumber()
 local x=0
 local y=118
 --
 local text="level:"..padscore(""..level,3)
 -- separate zeroes
 local zero=""
 local i 
 local j=3
 if (level<1000) j=2
 if (level<100) j=1
 if (level<10) j=0
 --
 for i=1,#text-j do
  local ch=sub(text,i,i)
  if ch=="0" then
   zero=zero.."0"
  else
   zero=zero.." "  
  end
 end
 -- score
 print(text,x,y+1,4)
 print(text,x,y,10)
 --zeroes
 print(zero,x,y+1,1)
 print(zero,x,y,4)
end

function drawscore(x,y)
-- local x=89
-- local y=118
 local scoretext="score:"..padscore(""..score,4)
 -- separate zeroes
 local scorezero=""
 local i 
 local j=3
 if (score<1000) j=2
 if (score<100) j=1
 if (score<10) j=0
 --
 for i=1,#scoretext-j do
  local ch=sub(scoretext,i,i)
  if ch=="0" then
   scorezero=scorezero.."0"
  else
   scorezero=scorezero.." "  
  end
 end
 -- score
 print(scoretext,x,y+1,4)
 print(scoretext,x,y,10)
 --zeroes
 print(scorezero,x,y+1,1)
 print(scorezero,x,y,4) 
end

function padscore(string,length)
  if (#string==length) return string
  return "0"..padscore(string, length-1)
end

-- test moves left

function movesleft()
 local moves=0
 local x local y
 for x=1,8 do
  for y=1,7 do
   if pieces[x][y]==0 then
    if canmove(x,y) then
     moves+=1
    end
   end
  end
 end
 return moves
end

function canmove(x,y)
--printh("canmove("..x..","..y..")")
  local can=false
  --scan
  x-=1
  y-=1
  local pcs=scan(x,y)
  --count
  local count={}
  local i local j
  for i=1,7 do
   count[i]=0
   for j=1,4 do
    if pcs[j][1]==i then
     count[i]+=1
    end
   end
  end
  --read the count
  for i=1,7 do
   local c=count[i]
   if c>1 then
				can=true
   end
  end

 return can
end

-- messages

function initmessage()
 message={}
 message.on=false
end

function showmessage(txt,timer)
 message.on=true
 message.txt="\135  "..txt.." \135  "
 message.timer=timer
end

function updatemessage()
 if message.on then
  message.timer-=1
  if message.timer<1 then
   message.on=false
  end
 end
end

function drawmessage()
 if message.on then
  rectfill(0,116,128,128,0)
  printcolor(message.txt,64-(#message.txt*2),118)
 end
end

function printcolor(txt,x,y)
 for i=1,#txt do
  local c=randcol()
  print(sub(txt,i,i+1),i*4+x,y-1+rnd(2),c)
 end
end

function pausegame(p)
 pause=p
 if p then
  pmenu.on=p
  pmenu.h=0
  pmenu.hs=4
 end
end

function drawpausemenu()
 if pmenu.h>0 then
  rectfill(0,63-pmenu.h,128,63+pmenu.h,0)
 end

 if (pmenu.h==20) then
  pmenu.hs=0

  local t="🅾️ to quit "
  print (t,64-#t*2,57,7)
  t="❎ resume game "
  print (t,64-#t*2,65,7)
  if btnp(4) then
   pausegame(false)
   backtomenu()
  end
  if btnp(5) then
   pausegame(false)
   pmenu.hs=-4
  end
 end

 pmenu.h+=pmenu.hs

 if (pmenu.h==0) then
  pmenu.hs=0
 end 


end

--
-- helpers
--

-- wait on keypress
function wait()
 drawbg()
 drawpieces()

 while (btn(4)) do end
-- printh(".")
 while (not btn(4)) do end
-- printh("..")
end

function name(n)
 local names={"dog","cat","pig","fish","chick","fox","frog"}
 return names[n]
end

-- mouse

function mouseinit()
 poke(0x5f2d,1)
end

function mousex()
 return stat(32)
end

function mousey()
 return stat(33)
end

function mouseclick()
 return stat(34)==1
end

function drawmouse()
 palt(11,true)
 spr(26,mousex(),mousey())
 palt(11,false)
end

-- touch

function inittouch()
 oldmousex=mousex()
 oldmousey=mousey()
end

function testtouch()
 if not (mousex()==oldmousex and mousey()==oldmousey) then
  if mousey()<112 and mousex()<127 then
   crsr.x=flr(mousex()/16)
   crsr.y=flr(mousey()/16)
  end
  testmatch(crsr.x,crsr.y)
  oldmousex=mousex()
  oldmousey=mousey()
 end
end

-- heart wipes

function initheart()
 heart={}
 heart.on=false
 heart.zummax=1300
 heart.zummin=10
 heart.zum=heart.zummin+1
end

function updateheart()
 if heart.on then
  if heart.zum>heart.zummin 
  and heart.zum<heart.zummax 
  then
   heart.zum*=heart.zumstep
  else
   heart.zumstep=0
   if heart.callback!=nil then
    heart.callback()
   end
  end
 end
end

function drawheart()
 if heart.on then
  palt(11,true)
  palt(0,false)
  pal(0,heart.col)
  zspr(12,4,4,64,64,heart.zum/200)
  palt(11,false)
  pal(0,0)
  palt(0,true)
 end
end

function heart_in(col,f)
print("---heart_in")
 pause=true
 heart.on=true
 heart.zum=25
 heart.zumstep=1.3
 if (col!=nil) heart.col=col
 heart.callback=f
end

function heartoff()
 heart.on=false
 pause=false
 heart.zum=heart.zummin+1
end

function heart_out(col,f)
print("---heart_out")
 pause=true
 heart.on=true
 heart.zum=heart.zummax-1
 heart.zumstep=0.7
 if (col!=nil) heart.col=col
 heart.callback=f
end

-- zoom sprite, centered
function zspr(n,w,h,dx,dy,dz)
 sx = 8 * (n % 16)
 sy = 8 * flr(n / 16)
 sw = 8 * w
 sh = 8 * h
 dw = sw * dz
 dh = sh * dz
 sspr(sx,sy,sw,sh, dx-dw/2,dy-dh/2,dw,dh)
end

-- random color (second half)
function randcol()
 return rnd(7)+8
end

function rainbow()
 rainbow_on=true
 bgc=8
 heart_in(14,rainbow2)
end

function rainbow2()
 bgc=14
 heart_in(0,rainbow_end)
end

function rainbow_end()
 rainbow_on=false
 nextlevel()
end

--todo

-- fix mouse button held

--?ingame music
--?levelup pts 4 fewer pcs left)
--?tutorial
--?premade puzzle levels (can gen then pick)
--?kill piece/lives
--? sine slowdown
