-- cave berries
-- by ryosuke mihara

-- constants
t_max=1024
g=0.098
max_berries=60
-- types
obj_berry=0
act_bot=1
-- global vars
t=0
acts={}
cam={}
cam.x=580
cam.y=-104
pc=nil
spks={}
objs={}
num_berries=0
hud=false
beats=0
karaoke=true
gameover=false
phase=0
win=false
win_t=0
blts={}

-- deployment
function _init()
	music(0,0,14)

	pc=create_actor()
	pc.x=620
	pc.y=-64
	add(acts,pc)
	deploy_berries()
	deploy_bots()
end

--------------------
-- deployment
--------------------

-- create actors
function create_actor()
	local c={}
	c.x=0
	c.y=0
	c.dx=0
	c.dy=0
	c.w=8
	c.h=8
	c.ani_sl=1
	c.ani_sr=6
	c.ani_wl=2
	c.ani_wr=7
	c.ani_wlen=4
	c.ani_eye=11
	c.left=false
	c.vdir=0
	c.g=false
	c.fire=false
	c.wet=false
	c.surface=false
	c.phase=0
	c.type=-1
	return c
end

function add_actor(x,y)
	local c=create_actor()
	c.x=x
	c.y=y
	add(acts,c)
end

function create_obj()
	local o={}
	o.x=0
	o.y=0
	o.dx=0
	o.dy=0
	o.w=8
	o.h=8
	o.s=64
	o.g=true
	o.wet=false
	o.target = nil
	o.type=-1
	return o
end

function deploy_bots()
	local bot=nil
	for y=64,96+4*8,1 do
		for x=0,8*16,1 do
			if sget(x,y)==5 then
				sset(x,y,0)
				bot=create_actor()
				bot.x=x*8
				bot.y=(y-96)*8
				bot.s=16
				bot.type=act_bot
				bot.phase=flr(rnd(360))
				add(acts,bot)
			end
		end
	end
end

function deploy_berries()
	local bry=nil
	for y=64,96+4*8,1 do
		for x=0,8*16,1 do
			if sget(x,y)==8 then
			 sset(x,y,11)
				bry=create_obj()
				bry.x=x*8
				bry.y=(y-96)*8
				bry.type=obj_berry
				add(objs,bry)
			end
		end
	end
end

--------------------
-- drawings
--------------------

function draw_bullet(blt)
	local x0=blt.x-cam.x
	local y0=blt.y-cam.y
	local x1=x0+blt.dx
	local y1=y0+blt.dy
	line(x0,y0,x1,y1,8+t%2)
end

function draw_win_bg()
	--rectfill(0,0,127,127,13)
	
	local cx=pc.x+pc.w/2-cam.x
	local cy=pc.y+pc.h/2-cam.y
	
	circfill(cx,cy,win_t,14)
	
	if t%4==0 then
		win_t+=1
		if win_t>127 then
			win_t=127
		end
	end
end

function draw_restart()
	rectfill(0,121,127,127,0)
	color(7)
	print("press button to restart",18,122)
end

function draw_karaoke()
	if beats>=16 and beats<80 then
		local lb=(beats-16)%16
		local x=32
		local y=8+beats%4-2
		
		-- base lyric
		color(7)
		if lb<8 then
			x=28
			print("collect the berries",x,y)
			
			color(8)
			if lb==0 then
				print("collect")
			end
			if lb==1 then
				print("        the")
			end
			if lb>1 then
				print("            berries")
			end
		else
			x=46
			print("in the cave",x,y)
			
			color(8)
			if lb==8 then
				print("in")
			end
			if lb==9 then
				print("   the")
			end
			if lb>9 then
				print("       cave")
			end
		end
	end
end

function draw_bot(ac)
	local x=ac.x-cam.x
	local y=ac.y-cam.y
	if x+ac.w/2 < 0  then return end
	if x+ac.w/2 >127 then return end
	if y+ac.h/2 < 0  then return end
	if y+ac.h/2 >127 then return end
	spr(ac.s,x,y)
	bot_ai(ac)
end

function draw_actor(ac)
	if ac~=pc then
		draw_bot(ac)
		return
	end
	
	if ac==pc and gameover then
		spr(12,ac.x-cam.x,ac.y-cam.y)
		return
	end
	if ac==pc and win then
		spr(13,ac.x-cam.x,ac.y-cam.y)
		return
	end

	local walking=false
	local s=ac.ani_sl
	if not ac.left then s=ac.ani_sr end
	local idx=flr(t/4)%ac.ani_wlen
	local w0=ac.ani_wl
	if not ac.left then w0=ac.ani_wr end
	
	if ac.g and (btn(0) or btn(1)) then
		s=w0+idx
		walking=true
		if t%7==0 then sfx(0) end
	end
	
	if not ac.g then
		s=w0
		idx=0
	end
	
	spr(s,ac.x-cam.x,ac.y-cam.y)
	
	-- draw_eye
	if ac==pc then
		local eye_x=ac.x-cam.x
		local eye_y=ac.y-cam.y
		if not ac.left then eye_x+=1 end
		eye_y+=ac.vdir
	
		if (walking or not ac.g) and idx==0 then
			if ac.left then
				eye_x-=1
			else
				eye_x+=1
			end
		end
		if walking and idx==1 then
			eye_y+=1
		end
	
	spr(ac.ani_eye,eye_x,eye_y)
	end
end

function draw_map()
	local cx=flr(cam.x/8)
	local cy=flr(cam.y/8)
	local spx=cx
	local spy=96+cy
	
	local scr_x=cam.x-cx*8
	local scr_y=cam.y-cy*8
	
	local wall=0
	local px
	local py
	local tlx
	local tly
	
	for y=0,16,1 do
		for x=0,16,1 do
			px=spx+x
			py=spy+y
			spix=sget(px,py)
			tlx=x*8-scr_x
			tly=y*8-scr_y
			
			--rock
			if spix==6 or py>127 or px<0 or px>127 then
				spr(68+(px+py)%3,tlx,tly)
				
				local luck=false
				if (px+py)%3==0 then luck=true end
				
				if px>=0 and px<128 and py<128 then
				--top-left
				if sget(px-1,py-1)~=6 and luck then
					pset(tlx,tly,1)		
				end
				--top-right
				if sget(px+1,py-1)~=6 and luck then
					pset(tlx+7,tly,1)
				end
				--bottom-left
				if sget(px-1,py+1)~=6 and luck then
					pset(tlx,tly+7,1)
				end
				--bottom-right
				if sget(px+1,py+1)~=6 and luck then
					pset(tlx+7,tly+7,1)
				end
				end
				
			end
			--water surface
			if spix==12 then
				spr(65+((t/16)+px)%3,tlx,tly)
			end
			--magma
			if spix==2 then
				spr(71+((t/16)+px)%4,tlx,tly)
			end
			--soil
			if spix==11 then
				
				rectfill(tlx,tly,tlx+8,tly+8,3)
				
				--top
				if sget(px,py-1)~=11 then
					line(tlx+1,tly,tlx+8,tly,12)
				end
				--bottom
				if sget(px,py+1)~=11 then
					line(tlx+1,tly+8,tlx+8,tly+8,12)
				end
				--left
				if sget(px-1,py)~=11 then
					line(tlx+1,tly,tlx,tly+8,12)
				end
				--right
				if sget(px+1,py)~=11 then
					line(tlx+9,tly,tlx+8,tly+8,12)
				end
			
				--spr(64,x*8-scr_x,y*8-scr_y)
			end
		end
	end
end

function draw_obj(o)
	if o.target~=nil then
		local adjx=0
		local adjy=0
		if win then
			adjx=(o.x+flr(t/12))%3-1
			adjy=(o.y+flr((t+1)/12))%3-1
		end
		spr(o.s,o.x+adjx,o.y+adjy)
		return
	end
	local x=o.x-cam.x
	local y=o.y-cam.y
	if x>-8 and x<136 and y>-8 and y<136 then
		spr(o.s,x,y)
 end
end

function draw_spark(spk)
	pset(spk.x,spk.y,8+rnd(3))
end

function add_spark(x,y,dx,dy)
	local th=(rnd(180)-90)/360
	local sdx=dx/abs(dx)*-1
	local sdy=dy/abs(dy)*-1
	sdx+=cos(th)*rnd(0.75)
	sdy+=sin(th)*rnd(0.75)
	local spk={}
	spk.x=x
	spk.y=y
	spk.dx=sdx
	spk.dy=sdy
	spk.age=0
	add(spks,spk)
end

function add_sparks(x,y,dx,dy)
	for num_spk=3,0,-1 do
		add_spark(x,y,dx,dy)
	end
end

function col_bots(x,y)
	for bot in all(acts) do
		if bot~=pc then
			local ok=true
			if x<bot.x then ok=false end
			if x>bot.x+bot.w then ok=false end
			if y<bot.y then ok=false end
			if y>bot.y+bot.h then ok=false end
			return ok
		end
	end
	return false
end

function draw_beam()
	if pc.fire and not win and not gameover then
		--local vals
		local bi
		local bdx
		local bdy
		local bx
		local by
		local num_eyes=1
		local sx
		local sy
		local break_done=false
		
		--init local vals
		if pc.vdir~=0 then num_eyes=2 end
		bdx=4
		if pc.left then bdx*=-1 end
		bdy=pc.vdir*4
		if pc.vdir~=0 then bdx=0 end
		
		for i=1,num_eyes,1 do
			if i==1 then
				if pc.left then
					bx=pc.x-cam.x+4
					by=pc.y-cam.y+1
				else
					bx=pc.x-cam.x+3
					by=pc.y-cam.y+1
				end
				by+=pc.vdir
			else
				if pc.left then
					bx=pc.x-cam.x+2
					by=pc.y-cam.y+1
				else
					bx=pc.x-cam.x+5
					by=pc.y-cam.y+1
				end
				by+=pc.vdir
			end
			if not pc.g and pc.vdir~=0 then
				if pc.left then bx-=1 end
				if not pc.left then bx+=1 end
			end
			local spix		
			--current pos
			local cbx=bx
			local cby=by
			--prev pos
			local pbx=bx
			local pby=by
			--
			for bi=0,48,1 do
				cbx=pbx+bdx
				cby=pby+bdy
				sx=flr((cbx+cam.x)/8)
				sy=flr((cby+cam.y)/8)+96
				spix=sget(sx,sy)
				if solid(spix) then
			 	add_sparks(cbx,cby,bdx,bdy)
			 	if t%4==0 and not break_done then
			 		if destructive(spix) then
			  		sset(sx,sy,0)
			  		sfx(1)
			  		break_done=true
			  	end
			 	end
					if t%2==0 and not destructive(spix) then
						sfx(2)
					end
					break
				end
				
				if col_bots(cbx+cam.x,cby+cam.y) then
					add_sparks(cbx,cby,bdx,bdy)
					if t%2==0 then
						sfx(2)
					end
					break
				end
				
				line(pbx,pby,cbx,cby,8+rnd(3))
				pbx=cbx
				pby=cby
				
				if cbx<0 or cbx>127 or cby<0 or cby>127 then
					break
				end
			end
		end
	end
end

--------------------
-- ai
--------------------

function create_bullet()
	local blt={}
	blt.x=0
	blt.y=0
	blt.dx=0
	blt.dy=0
	blt.age=0
	return blt
end

function bot_ai(bot)
	if bot~=pc then
		local ph=bot.phase
		if ph>180 then ph=360-ph end
		local angle=ph/360
		local cx=bot.x-cam.x+bot.w/2
		local cy=bot.y-cam.y+bot.h/2
		local r=2
		local ex=cx+cos(angle)*r
		local ey=cy+sin(angle)*r
		
		local eureka=false
		for i=2,48,2 do
			local er=4
			local vx=ex+cos(angle)*i+cam.x
			local vy=ey+sin(angle)*i+cam.y
		--	circ(vx-cam.x,vy-cam.y,er,7)
			local spix=sget(flr(vx/8),flr(vy/8)+96)
			if solid(spix) then break end

			if abs(pc.x+pc.w/2-vx)<er and abs(pc.y+pc.h/2-vy)<er then
				eureka=true
				break	
			end
		end
		
		if eureka then
			pset(ex,ey,8)
		else
			pset(ex,ey,11)
			bot.phase=(bot.phase+1)%360
		end
		
		
		if eureka then
		
			if t%8==0 then
				local blt=create_bullet()
				blt.x=ex+cam.x
				blt.y=ey+cam.y
				blt.dx=2*cos(angle)
				blt.dy=2*sin(angle)
				add(blts,blt)
			end
		end
	end
end

--------------------
-- physics
--------------------
function hit(ac)
	music(-1)
 gameover=true
 sfx(12)
 ac.dy=-1.5
end

function update_bullet(blt)
	blt.x+=blt.dx
	blt.y+=blt.dy
	blt.age+=1
	local sx=flr(blt.x/8)
	local sy=flr(blt.y/8)+96
	local spix=sget(sx,sy)
	if spix==6 or blt.age>80 then
		del(blts,blt)
	else
		local xok=false
		local yok=false
		if blt.x>=pc.x and blt.x<pc.x+pc.w then xok=true end
		if blt.y>=pc.y and blt.y<pc.y+pc.h then yok=true end
		if not gameover and xok and yok then
			del(blts,blt)
			hit(pc)
		end
	end
end

function solid(spix)
	if spix==11 or spix==6 then
		return true
	else
		return false
	end
end

function destructive(spix)
	if spix==11 then
		return true
	end
	return false
end

function water(spix)
	if spix==12 or spix==1 then
		return true
	end
	return false
end

function water_surface(spix)
	if spix==12 then
		return true
	end
	return false
end

function magma(spix)
	if spix==2 then
		return true
	end
	return false
end

function update_actor(ac)
	if ac==pc and win then
		return
	end
	if ac==pc and gameover then
		if phase>0 then
			return
		end
	
		ac.dy+=g
		ac.x+=ac.dx
		ac.y+=ac.dy
		
		if phase==0 and ac.y-cam.y>127 then
			phase=1
		end
		return
	end

	local sx=0
	local sy=0
	local spix=0
	
	-- center
	sx=flr((ac.x+ac.w/2)/8)
	sy=flr((ac.y+ac.h/2)/8)
	spix=sget(sx,sy+96)
	if not ac.g then
		-- water
		if water(spix) then
			if not ac.wet then
				ac.dy=0
				ac.wet=true
			end
			ac.dy+=g/3
		else
			ac.dy+=g
			ac.wet=false
		end
		ac.surface=water_surface(spix)
	end
	ac.x+=ac.dx
 ac.y+=ac.dy
 
 -- col magma
 if magma(spix) and ac==pc then
		hit(ac)
 	return
 end
	
	-- col bottom
	for ty=0,2,1 do
		sx=flr((ac.x+ac.w/2)/8)
		sy=flr((ac.y+ac.h+ty)/8)
		spix=sget(sx,sy+96)
		if not ac.g and solid(spix) then
			ac.g=true
			ac.dy=0
			ac.y=(sy-1)*8
			break
		end
		if ac.g and not solid(spix) then
			ac.g=false
			break
		end
	end
	
	-- col head
	if not ac.g and ac.dy<0 then
		for ty=0,2,1 do
			sx=flr((ac.x+ac.w/2)/8)
			sy=flr((ac.y-ty)/8)
			spix=sget(sx,sy+96)
			if solid(spix) then
				ac.dy=0
				ac.y=(sy+1)*8
				break
			end
		end
	end
	
	-- col left
	sx=flr(ac.x/8)
	sy=flr((ac.y+ac.h/2)/8)
	spix=sget(sx,sy+96)
	if solid(spix) then
		ac.dx=0
		ac.x=(sx+1)*8
	end
	
	-- col right
	sx=flr((ac.x+ac.w)/8)
	spix=sget(sx,sy+96)
	if solid(spix) then
		ac.dx=0
		ac.x=(sx-1)*8
	end
end

function update_spark(spk)
	spk.dy+=g
	spk.x+=spk.dx
	spk.y+=spk.dy
	spk.age+=1
	if spk.age>8 then
		del(spks,spk)
	end
end

function update_obj(o)
	o.x+=o.dx
	o.y+=o.dy
	
	if o.target~=nil then
		local tdx=abs(o.target.x-o.x)
		local tdy=abs(o.target.y-o.y)
		if tdx<8 and tdy<8 then
			o.x=o.target.x
			o.y=o.target.y
			o.dx=0
			o.dy=0
		end
		return
	end
	
	local sx=0
	local sy=0
	local spix=0
	sx=flr((o.x+o.w/2)/8)
	sy=flr((o.y+o.h/2)/8)
	spix=sget(sx,sy+96)
	
	
	if not o.g then
	 -- water
	 if water(spix) then
			if not o.wet then
				o.dy=0
				o.wet=true
			end
			o.dy+=g/3
		else
			o.dy+=g
			o.wet=false
		end
	end
	
	-- col center
	if not solid(spix) and o.g then
		o.g=true
	end
		
	-- col bottom
	for ty=0,2,1 do
		sx=flr((o.x+o.w/2)/8)
		sy=flr((o.y+o.h+ty)/8)
		spix=sget(sx,sy+96)
		if not o.g and solid(spix) then
			o.g=true
			o.dy=0
			o.y=(sy-1)*8
			break
		end
		if o.g and not solid(spix) then
			o.g=false
			break
		end
	end
	
	-- catch
	if o.type==obj_berry and not gameover then
		local ocx=o.x+o.w/2
		local ocy=o.y+o.h/2
		local xok=false
		if ocx>=pc.x and ocx<=pc.x+pc.w then
			xok=true
		end
		local yok=false
		if ocy>=pc.y and ocy<=pc.y+pc.h then
			yok=true
		end
		if xok and yok then
			catch_berry(o)
		end
	end
end

function catch_berry(o)
	o.target={}
	
	local tx=0
	local ty=0
	if num_berries<16 then
		tx=num_berries*8
		ty=0
	end
	if num_berries>=16 and num_berries<30 then
		tx=15*8
		ty=(num_berries-15)*8
	end
	if num_berries>=30 and num_berries<46 then
		tx=(15-(num_berries-30))*8
		ty=15*8
	end
	if num_berries>45 then
		tx=0
		ty=(14-(num_berries-46))*8
	end
	ty-=1
	o.target.x=tx
	o.target.y=ty
	num_berries+=1
	
	o.x-=cam.x
	o.y-=cam.y
	
	o.dx=(o.target.x-o.x)/10
	o.dy=(o.target.y-o.y)/10
	
	sfx(7)
	
	if not win and num_berries>=max_berries then
		win=true
		music(7)
	end
end

--------------------
-- inputs
--------------------

function ctrl()
	if gameover or win then
		if phase>0 and btn()~=0 then
			run()
		end
		if win_t>32 and btn()~=0 then
			run()
		end
		return
	end

	local dx=0
	local vdir=0
	if btn(0) then 
		dx=-0.75
		pc.left=true
 end
	if btn(1) then 
		dx=0.75
		pc.left=false
 end
 if btn(2) then
 	vdir=-1
 end
 if btn(3) then
 	vdir=1
 end
 if btn(5) and pc.g then
 	pc.dy=-2.5
 	pc.g=false
 else
 	if btn(5) and pc.wet then
 		if pc.surface then
 			pc.dy=-2.5/1.6
 		else
 			pc.dy=-2.5/3
 		end
 		if pc.g then pc.y-=1 end
 		pc.g=false
 	end
 end
	pc.dx=dx
	pc.vdir=vdir
	
	
	--
	pc.fire=btn(4)
end

--------------------
-- camera
--------------------

function update_camera()
	if gameover then
		return
	end
	
	local clen=48

	if pc.x>cam.x+128-clen then
		cam.x+=pc.x-(cam.x+128-clen)
	end
	if pc.x<cam.x+clen then
		cam.x-=(cam.x+clen-pc.x)
	end
	if pc.y>cam.y+128-clen then
		cam.y+=pc.y-(cam.y+128-clen)
	end
	if pc.y<cam.y+clen then
		cam.y-=(cam.y+clen-pc.y)
	end
end

-- loop
function _update()
	t=(t+1)%t_max
	ctrl()
	update_camera()
	foreach(acts,update_actor)
	foreach(spks,update_spark)
	foreach(objs,update_obj)
	foreach(blts,update_bullet)
	
	-- beats
	if t%12==0 then
		beats+=1
		if beats>=112 then
			beats=16
		end
	end
	
	-- music
	if not win and pc.y>0 then
		music(-1,1000)
		karaoke=false
	end
end

function _draw()
	rectfill(0,0,127,127,0)
	if win then
		if win_t>32 then
			draw_restart()
		end
		draw_win_bg()
	end
	if win_t<16 then
		draw_map()
	end
	foreach(spks,draw_spark)
	foreach(objs,draw_obj)
	foreach(acts,draw_actor)
	foreach(blts,draw_bullet)
	draw_beam()
	if not win and karaoke then
		draw_karaoke()
	end
	if phase>0 then
		draw_restart()
	end
	--
	if hud then
	color(7)
	cursor(0,0)
	print("cam: "..cam.x..","..cam.y)
	print("pc : "..pc.x..","..pc.y)
	if pc.left then
	print("left")
	else
	print("right")
	end
	if pc.wet then
		color(12)
		print("wet")
	end
	if count(objs)>0 then
		print(count(objs))
	end
	end
	
	--
	--cursor(0,0)
	--color(12)
	--print(beats)
	
end

