-- starjump 1.0
-- by luca harris


function lerp(a, b, t)
	return a + (b - a) * t
end

function square_circle_intersect(square_pos, half_square_width, circle_pos, circle_radius)
	local diff = square_pos - circle_pos
	local dist = diff:len()

	if (dist < circle_radius + half_square_width) return true

	local pos = circle_pos + diff * (circle_radius / dist)
	return abs(pos.x - square_pos.x) <= half_square_width and 
		   abs(pos.y - square_pos.y) <= half_square_width 
end

function default(a, b)
	if (a == nil) return b
	return a
end

-- triwave(0) = 0
-- triwave(0.25) = 1
-- triwave(0.50) = 0
-- triwave(0.75) = -1
function triwave(t)
	t = (t + 0.75) % 1
	return abs(t * 4 - 2) - 1
end

function rnd_range(a, b)
	return a + rnd(b - a)
end

function rnd_signed(a)
	return rnd(a * 2) - a
end

function rnd_sign()
	return sgn(rnd() - 0.5)
end

function int_cos(t)
	return 0.5 - cos(t / 2) / 2
end

function int_linear(t)
	return t
end

function bit(n, i)
	return (n & (1 << i)) >> i
end

function menuitem_cursor(b)
	return bit(b, 1) - bit(b, 0)
end

-- function int_smoothstep(t)
-- 	return 3 * t^2 + 2 * t^3
-- end

function option_get_points(options, i)
	local ps = {}
	for i=i,#options-1,2 do
		add(ps, vec(options[i], options[i + 1]))
	end
	return ps
end

-- loops: if the points form a loop or a straight line
-- wrap_mode:
--  0: continuous loop (default)
--  1: discontinous wrap
--  2: discontinuous no wrap
-- int: interporlation function (between points) defaults to linear
-- returns (t, position, delta_position)
function move_along_points(ps, t, dist, wrap_mode, int)
	int = int or int_linear

	local i = flr(t)
	local p1, p2 =
		ps[1 + i % #ps],
		ps[1 + (i + 1) % #ps]

	local pos1 = p1:lerp(p2, int(t % 1))
	t += dist / p1:dist(p2)

	i = flr(t)
	p1 = ps[1 + i % #ps]
	p2 = ps[1 + (i + 1) % #ps]
	
	local pos2 = p1:lerp(p2, int(t % 1))
	local delta_pos = pos2 - pos1

	if wrap_mode == 1 then
		local t0 = t
		t = t % (#ps - 1)

		-- on teleport don't use delta
		if t < t0 then
			delta_pos = vec()
		end
	elseif wrap_mode == 2 then
		local tmax = #ps -1
		if t >= tmax then
			t = tmax
			delta_pos = vec()
		end
	end

	return t, pos2, delta_pos
end




function vec(x, y)
	return setmetatable({
		x = x or 0,
		y = y or 0
	}, vec_mt)
end

function polar(a, d)
	d = d or 1
	return vec(cos(a) * d, sin(a) * d)
end

vec_mt = {
	-- __unm = function (v)
	-- 	return vec(-v.x, -v.y)
	-- end,
	__add = function(v1, v2)
		return vec(v1.x + v2.x, v1.y + v2.y)
	end,
	__sub = function(v1, v2)
		return vec(v1.x - v2.x, v1.y - v2.y)
	end,
	-- order must be vector * number
	__mul = function(v, k)
		return vec(v.x * k, v.y * k)
	end,
	-- order must be vector / number
	__div = function(v, k)
		return vec(v.x / k, v.y / k)
	end,
	-- __tostring = function(v)
	-- 	return v.x..","..v.y
	-- end,
	__index = {
		-- get vector length
		len = function (self)
			-- adapted from https://pico-8.fandom.com/wiki/Known_Bugs
			-- sacrifice some precision to prevent overflow
			local x, y = self.x/32, self.y/32
			local k = x*x + y*y

			return k<0 and 32767 or sqrt(k) * 32
		end,
		-- dist to vector
		dist = function (self, v)
			return (self - v):len()
		end,
		-- get norm/unit vector
		norm = function (self)
			local len = self:len()
			if (len < 0.001) len = 1
			return self / len
		end,
		lerp = function (self, v, t)
			return vec(
				lerp(self.x, v.x, t),
				lerp(self.y, v.y, t)
			)
		end,
		toward = function (self, v, max_delta)
			return self:toward_smooth(v, max_delta, 0)
		end,
		toward_smooth = function (self, v, max_delta, smooth_factor)
			local delta = v - self
			local delta_len = delta:len()
			local dist = max(max_delta, delta_len * smooth_factor)
			if dist >= delta_len then
				return v * 1
			else
				return self + delta * (dist / delta_len)
			end
		end,
		-- -- dot product
		-- dot = function (self, v)
		-- 	return self.x * v.x + self.y * v.y
		-- end,
		-- -- project self onto v
		-- proj = function (self, v)
		-- 	return v * (self:dot(v) / v:dot(v))
		-- end,
		-- get floored value
		flr = function (self)
			return vec(flr(self.x), flr(self.y))
		end,
	}
}




function particle_set()
	return setmetatable({
		ps = {},
	}, particle_set_mt)
end

particle_set_mt = {
	__index = {
		add = function(self, p)
			p.f = 0
			add(self.ps, p)
		end,
		update = function(self)
			for p in all(self.ps) do
				if p.age then
					p.t = p.f / p.age
				end

				if p.update then
					p:update()
				end

				p.f += 1
			end
		end,
		draw = function(self)
			for p in all(self.ps) do
				if p.draw then
					p:draw()
				end
				if p.die or (p.age and p.f > p.age) then
					del(self.ps, p)
				end
			end
		end,
	}
}




-- cam_scale = 1
-- cam_center = vec()
-- cam_center0 = vec()
-- cam_size

function set_camera()
	local function dir_to_delta(dir)
		-- if (zone[dir .. "_secret"]) return 0.4
		return zone[dir] and -0.1 or 0.75
	end

	local x1, y1, x2, y2 =
		zone.vx1 - dir_to_delta("left"),
		zone.vy1 - dir_to_delta("up"),
		zone.vx2 + dir_to_delta("right"),
		zone.vy2 + dir_to_delta("down")

	local zone_width, zone_height =
		x2 - x1 + 1,
		y2 - y1 + 1

	-- put zone doors on edge of screen (if possible)
	if zone_width < zone_height then
		if zone.right and not zone.left then
			x1 -= zone_height - zone_width
			zone_width = zone_height
		elseif zone.left and not zone.right then
			x2 += zone_height - zone_width
			zone_width = zone_height
		end
	elseif zone_height < zone_width then
		if zone.down and not zone.up then
			y1 -= zone_width - zone_height
			zone_height = zone_width
		elseif zone.up and not zone.down then
			y2 += zone_width - zone_height
			zone_height = zone_width
		end
	end

	cam_size = max(zone_width, zone_height)
	cam_scale = 128 / cam_size
	cam_center = vec(x1 + zone_width/2, y1 + zone_height/2)
	cam_center0 = cam_center
end

-- transform world point to screen space
function cam_tf(v)
	return vec(
		64 + (v.x - cam_center.x) * cam_scale,
		64 + (v.y - cam_center.y) * cam_scale
	)
end

function in_view(pos, width)
	pos = cam_tf(pos)
	width *= cam_scale

	return abs(pos.x - 64) <= 64 + width and abs(pos.y - 64) <= 64 + width
end




-- getf: (x: number, y: number) => number
-- return [vec, vec][]
function edges_get(getf, x1, y1, x2, y2)
	function get(x, y)
		if x>=x1 and x<=x2 and y>=y1 and y<=y2 then
			return getf(x, y)
		end
		return 0
	end

	local edges={}
	for y=y1,y2 do
		for x=x1,x2 do
			local n = get(x, y)
			if n != 0 then
				local n1,n2,n3,n4 = 
					get(x - 1, y, n),
					get(x + 1, y, n),
					get(x, y - 1, n),
					get(x, y + 1, n)
				if (n != n1) add(edges, { vec(x,     y    ), vec(x,     y + 1), n = n, m = n1 })
				if (n != n2) add(edges, { vec(x + 1, y    ), vec(x + 1, y + 1), n = n, m = n2 })
				if (n != n3) add(edges, { vec(x,     y    ), vec(x + 1, y    ), n = n, m = n3 })
				if (n != n4) add(edges, { vec(x,     y + 1), vec(x + 1, y + 1), n = n, m = n4 })
			end
		end
	end

	return edges
end




-- player state (commented out means intialised elsewhere, just here for reference)
-- p_pos=vec()
p_pos_smooth=vec()
p_posz=0
p_velz=0
p_dj=0
-- p_dj_count=0
p_w=0.49 -- floor width
p_ew=0.3 -- wall width
-- p_mode = 0 -- 0=start 1=playing 2=end
-- p_alive=false
p_spawned = false
p_locked = false
-- p_captured = false
-- p_capture_object = nil
p_capture_vel = vec()
-- p_capture_gravity = 0
-- p_force_vel = vec()
-- p_hidden = false
p_death_t = 999
p_kt=-1
p_particles = particle_set()
p_press_jump = false
-- p_end_animation_t = 0
-- p_safe_zone = nil

function p_reset()
	p_dj_count = 0
	p_alive = false
	p_safe_zone = nil
	p_captured = false
	p_capture_object = nil
	p_hidden = false
	p_end_animation_t = 0
end

p_reset()

function p_init()
	p_reset()
	p_pos = vec(17, 1)
	p_mode = 0
	zone_flip = false
	return "start"
end

function p_tiles()
	return zone_tiles(p_pos.x, p_pos.y, p_w)
end

function p_pos_world()
	return p_pos - vec(0, p_posz)
end

-- function p_pos_screen()
-- 	return cam_tf(p_pos_world())
-- end

function p_on_floor()
	return p_posz <= 0
end

function p_over_ground()
	for p in all(zone_platforms) do
		if p.contains(p_pos, p_w) then
			return true
		end
	end
	return p_tiles() & 1 == 1
end

function p_in_wall()
	return zone_tiles(p_pos.x, p_pos.y, p_ew) >= 2
end

-- adds wobble to points in world space
-- amount: amount of wobble (1 = default)
-- v: world space position to modify
-- v_center: used to compare to player pos, defaults to v
-- seed: used for wobble offset, defaults to 0
function add_wobble(amount, v, v_center, seed)
	local d = (v_center or v):dist(p_pos_smooth)
	local k = (amount * g_wobble_amount) / max(1.7, 5 - d * 0.29)
	local t = v.x / 7 + v.y / 7 + t() / 2.5 + (seed or 0)

	return vec(
		v.x + cos(t * 1.35) * sin(t * 2.7) * k,
		v.y + cos(t * 2.35 + 0.3) * sin(t * 1.7 + 0.4) * k
	)

	-- local x = v.x
	-- local y = v.y
	-- if not v.outx then
	-- 	x += cos(t * 1.35) * sin(t * 2.7) / k
	-- end
	-- if not v.outy then
	-- 	y += cos(t * 2.35 + 0.3) * sin(t * 1.7 + 0.4) / k
	-- end
	-- return vec(x, y)
end

function p_add_jump_particle(da, n)
	n = n or 4
	local pos = p_pos_world()
	for i=1,n do
		p_particles:add({
			age = 6,
			draw = function(self)
				local a = da + i / n
				local d = polar(a, cam_scale)
				local k = 0.3 + self.f * 0.08
				local l = (1 - self.t) * 0.1
				local spos = cam_tf(pos):flr()
				local v1 = spos + d * (k - l)
				local v2 = spos + d * (k + l)
				thline(
					v1.x, v1.y,
					v2.x, v2.y,
					0, 1
				)
			end
		})
	end
end

function p_jump(speed, options)
	options = options or {}

	sfx(options.sfx or 8)

	if options.particles != false then
		p_add_jump_particle(0.125)
	end
	
	p_kt = 0
	p_dj = p_dj_count
	p_velz = speed

	if options.apply_vel then
		p_posz = (options.z or 0) + speed * 0.5
	end
end

function p_uncapture()
	p_captured = false
	p_add_jump_particle(0, 6)
	p_jump(0.448, {apply_vel = true, particles = false})
end

function p_kill()
	p_alive = false
	p_captured = false
	p_capture_object = nil
	-- p_force_vel = nil
	p_death_t = 0
	g_deaths += 1

	sfx(11)
end

function p_circle_intersect(pos, radius)
	return square_circle_intersect(p_pos, p_ew, pos, radius)
end




function bubble(options)
	local pos,flipper = vec(options[1], options[2]),options[3]
	local active = true

	return {
		pre_update = function()
			if active then
				if bubble_check_hit(pos) then
					add_enemy_pop_particles(pos, flipper and 1 or 3)
					active = false

					if flipper then
						zone_toggle_flip()
					end
				end
			end
			if p_spawned then
				active = true
			end
		end,
		draw = function()
			if active or not p_alive then
				if apply_enemy_respawn_fade(active) then
					bubble_draw(pos, pos.x + pos.y, zone_t, 1, flipper and 2 or 3)
				end
			end

			fillp()
		end
	}
end

function bubble_flip(options)
	options[3] = true
	return bubble(options)
end

function bubble_blower(options)
	local angle,int,delay,speed,rate,pre,bs,pos_f,ps,aim_on_player,t,pos = options[1],options.int,(options.delay or 0),(options.speed or 0.12),(options.rate or 30),(options.pre or 0),{}
	if type(angle) == "function" then
		pos_f = angle
		t = 0
		pos, angle = pos_f(zone_t)
	else
		ps = option_get_points(options, 2)
		t, pos = move_along_points(ps, options.t or 0, 0, 0, int)
		aim_on_player = angle < 0

		local dir = vec(cos(angle), sin(angle))
		for i=1,pre do
			add(bs, {
				t = zone_t - i * rate,
				pos = pos + dir * (0.6 + ((i -1) * rate + (delay == 0 and 30 or delay)) * speed),
				dir = dir,
			})
		end
	end

	return {
		pre_update = function()
			if pos_f then
				t = zone_t
				pos, angle = pos_f(t)
			else
				t, pos = move_along_points(ps, t, speed, 0, int)
			end

			if aim_on_player then
				angle = atan2(p_pos.x - pos.x, p_pos.y - pos.y)
			end

			if (delay - 2 + zone_t) % rate < 1 then
				local dir = vec(cos(angle), sin(angle))
				add(bs, {
					t = zone_t,
					pos = pos + dir * 0.6,
					dir = dir,
				})
			end

			for b in all(bs) do
				b.pos += b.dir * 0.15

				local del_b
				if bubble_check_hit(b.pos) then
					del_b = true
				elseif not in_view(b.pos, -0.6) then
					del_b = true
				end

				if del_b then
					del(bs, b)
					add_enemy_pop_particles(b.pos)
				end
			end
		end,
		draw = function()
			local seed = pos.x + pos.y

			-- shooter
			local ps = {}
			local draw_angle = angle
			if not pos_f then
				draw_angle += triwave(time() * 0.7) * 0.04 * g_wobble_amount
			end
			for i=0,2 do
				local a = draw_angle + i/3
				add(ps, cam_tf(pos + vec(cos(a), sin(a)) * (0.25 + min(i, 1) * 0.4)))
			end
			draw_enemy_ring(ps, 1, 0.32, 3)

			-- bubbles
			for b in all(bs) do
				local base_scale = m

				bubble_draw(b.pos, seed, b.t, min(1, (zone_t - b.t) / 6))
			end
		end,
	}
end

function bubble_check_hit(pos)
	if p_alive and not p_capture_object and p_on_floor() and p_circle_intersect(pos, 1) then
		if p_captured then
			p_uncapture()
		else
			p_jump(0.47, {apply_vel = true, sfx = 12, particles = false})
		end
		return true
	end
end

function bubble_draw(pos, seed, t, base_scale, c)
	-- generate points on circle
	local pdist = pos:dist(p_pos)
	local dist_scale = min(0.3, 0.16 + pdist / 100) * g_wobble_amount
	local ps = {}
	for i=0,10 do
		local a = i/11
		local a2 = a + t / 300 + seed / 50
		local r = (1 + sin(a2 + time()) * sin(a2 * 7 + time()) * dist_scale) * base_scale
		add(ps, cam_tf(pos + vec(cos(a), sin(a)) * r))
	end

	draw_enemy_ring(ps, 1, 0.4, c or 3)
end


function cannon(options)
	local angle,speed,int,ps = options[1],(options.speed or 0.13),options.int,option_get_points(options, 2)
	local t, pos = move_along_points(ps, options.t or 0, 0, 0, int)
	local capture_t,fire_t,captured= -9999,-9999

	return {
		pre_update = function(self)
			t, pos = move_along_points(ps, t, speed, 0, int)

			if captured then
				-- in the barrell
				-- short delay before you're allowed to shoot. what is this, melee?
				if zone_t >= capture_t + 2 and p_press_jump then
					-- shoot!
					p_press_jump = false
					captured = false
					p_capture_object = nil
					fire_t = zone_t
					p_hidden = false
					sfx(15)

					-- move to front of barrel
					p_pos = pos + vec(cos(angle), sin(angle)) * 1.95
					p_posz = 0

					-- blast particles
					add_enemy_blast_particles(p_pos - vec(0, 0.35), angle)

					-- set velocity
					p_capture_vel = vec(cos(angle), sin(angle)) * 0.42
				end
			elseif not p_capture_object then
				-- unlock player onframe after firing
				if fire_t == zone_t - 1 then
					p_locked = false
				end

				-- capture player when the land in radius
				if p_alive and (p_captured or p_on_floor()) and p_circle_intersect(pos, 1.1) then
					captured = true
					capture_t = zone_t
					p_captured = true
					p_capture_object = self
					p_capture_vel = vec()
					p_locked = true
					p_hidden = true
					sfx(13)
				end
			end
		end,
		draw = function()
			-- local ppp = cam_tf(pos)
			-- line(ppp.x - 64, ppp.y, ppp.x + 64, ppp.y, 3)

			local seed = pos.x + pos.y

			-- get x/y distortion!
			local tc = zone_t - capture_t
			local tf = zone_t - fire_t
			local base_rx = 1
			local base_ry = 1
			if captured then
				-- uniform scaling, shrinking gives sense of impact
				local k = cos(tc * 0.1 + 0.32) * (0.2 / (1 + tc * 0.33))
				base_rx += k
				base_ry += k
			else
				-- varied scaling
				-- alternates directions between axes to give sense of a blast
				-- larger in direction perpendicular to shoot directon
				base_rx += (cos(tf * 0.05 - 0.12) ^ 2) * ((0.8 + cos(angle/2)^2 * 0.4) / (1 + tf * 0.2))
				base_ry += (cos(tf * 0.05 - 0.37) ^ 2) * ((0.8 + sin(angle/2)^2 * 0.4) / (1 + tf * 0.2))
			end

			-- get points on outline
			local ps = {}
			local wr = 0.14 * g_wobble_amount
			for i=0,14 do
				local r = 1
				local a
				if i <= 1 then
					a = 0.9 + i * 0.08
					r = 1.6
				else
					a = (i - 2) * (0.88 / 12)
				end
				local a2 = a + seed / 50
				a += angle + 0.06
				r += sin(a2 + time()) * sin(a2 * 7 + time()) * wr
				
				add(ps, cam_tf(pos + vec(cos(a) * base_rx, sin(a) * base_ry) * r))
			end

			-- draw body

			draw_enemy_ring(ps, 1.2, 0.4, 4)
			
			-- draw impact lines
			if tc <= 8 then
				local t2 = tc / 9
				local r = 1.4 + t2 * 0.7
				for i=0,7 do
					local a = angle + 0.13 + i * (0.74 / 7)
					local dir = vec(cos(a), sin(a))
					local w = (1 - t2) * 0.1
					local p1 = cam_tf(pos + dir * (r - w))
					local p2 = cam_tf(pos + dir * (r + w))
	
					thline(p1.x, p1.y, p2.x, p2.y, 0, 4)
				end
			end
		end,
	}
end

function draw_enemy_ring(ps, w0, w1, c)
	-- setup simple lerp
	w1 -= w0

	-- draw two thick lines
	-- 0=background outline
	-- 1=foreground
	for j=0,1 do
		local w = w0 + j * w1
		for i=0,#ps-1 do
			local p1 = ps[1 + i]
			local p2 = ps[1 + (i + 1) % #ps]

			wline(p1.x, p1.y, p2.x, p2.y, w, c * j)
		end
	end
end

function add_enemy_pop_particles(pos, col)
	col = col or 3
	local n = 7
	for i=1,n do
		enemy_particles:add({
			age = 8,
			draw = function(self)
				local a = i / n + (pos.x + pos.y)/99
				local dir = vec(cos(a), sin(a))
				local d = 0.8 + self.f * 0.09
				local w = (1 - self.t) * 0.1 * cam_scale
				local p = cam_tf(pos + dir * d)
				if (self.f > 6) fillp(▒)
				rectfill(
					p.x - w - 1,
					p.y - w - 1,
					p.x + w + 1,
					p.y + w + 1,
					0
				)
				rectfill(
					p.x - w,
					p.y - w,
					p.x + w,
					p.y + w,
					col
				)
				fillp()
			end
		})
	end
end

function add_enemy_blast_particles(pos, angle)
	local n = 8
	for i=1,n do
		local a = angle + rnd_range(0.08, 0.22) * rnd_sign()
		local dir = vec(cos(a), sin(a))
		local radius = rnd_range(0.2, 0.7)
		local speed = rnd_range(0.08, 0.14)

		enemy_particles:add({
			age = rnd_range(10, 12),
			draw = function(self)
				local p = cam_tf(pos + dir * (0.8 + self.f * speed))

				fillp(self.t < 0.15 and 0 or (self.t < 0.9 and ▒ or ░))

				circfill(p.x, p.y, (1 - self.t) * radius * cam_scale, 4)
				
				fillp()
			end
		})
	end
end

function apply_enemy_respawn_fade(enemy_alive)
	if not enemy_alive and not p_alive then
		if p_death_t >= 4 then
			fillp(p_death_t <= 5 and ░ or ▒)
			return true
		end
	elseif enemy_alive then
		return true
	end
end

enemy_particles = particle_set()




function simple_platform(options)
	local w,h,speed,t,loop,auto_scroller,int,ps = options[1],options[2],options[3],(options.t or 0),default(options.loop, true),default(options.auto_scroller, false),options.int,option_get_points(options, 4)
	local going,pos = not auto_scroller,ps[1]
	local seed = rnd()

	-- update function
	local function update(self, contains_p)
		if auto_scroller then
			if p_spawned then
				going = false
				pos = ps[1]
				t = 0
			elseif contains_p and p_on_floor() then
				going = true 
			end
		end

		if going then
			local delta
			t, pos, delta = move_along_points(ps, t, speed, loop and 0 or (auto_scroller and 2 or 1), int)
			return delta
		end

		return vec()
	end

	-- init
	update(nil, false)

	-- return object
	return {
		contains = function (p, size)
			return
				p.x + size >= pos.x - w/2 and
				p.y + size >= pos.y - h/2 and
				p.x - size <= pos.x + w/2 and
				p.y - size <= pos.y + h/2
		end,
		update = update,
		draw = function ()
			-- path lines
			if auto_scroller then
				fillp(▒)
				local prev

				for i=1,#ps do
					local pos = cam_tf(add_wobble(0.75, ps[i]))

					if prev then
						line(prev.x, prev.y, pos.x, pos.y, 1)
					end
					prev = pos
				end

				fillp()
			end

			-- respawn fade out
			if (auto_scroller and not p_alive and going) fillp(p_death_t < 4 and ▒ or ░)

			-- draw dots
			local nx = flr(w) - 1
			local ny = flr(h) - 1
			for x=0,nx do
			for y=0,ny do
				local p = cam_tf(vec(
					pos.x + x - nx/2,
					pos.y + y - ny/2
				))
				pset(p.x, p.y, 1)
			end
			end

			-- draw outline
			for i=0,4 do
				local a1 = i/4 + 0.125
				local a2 = a1 + 0.25
				local p1 = vec(cos(a1) * 0.7071 * w, sin(a1) * 0.7071 * h)
				local p2 = vec(cos(a2) * 0.7071 * w, sin(a2) * 0.7071 * h)
				local n = ceil(i%2 == 0 and w or h)
				local prev
				for j=0,n do
					local p = p1:lerp(p2, j/n)
					p = cam_tf(pos + add_wobble(0.95, p, pos, seed))
					if prev then
						wline(prev.x, prev.y, p.x, p.y, 0.34, 1)
					end
					prev = p
				end
			end

			fillp()
		end,
	}
end




zones = {
	test = {
		0, 0,
		1, 1,
	},
	start = {
		16, 0,
		20, 1,
		pad_up = 2,
		right = "jump",
		draw = function()
			sspr(
				0, 8, 32, 8,
				64, 4, 64, 16
			)
		end,
	},
	jump = {
		21, 0,
		28, 3, 
		right = "j_turn",
	},
	j_turn = {
		28, 0,
		37, 7,
		pad_right = 1,
		right = "buppy",
		down = "sparse",
	},
	buppy = {
		15, 50,
		17, 54,
		draw = function()
			spr(33, 116, 4)
		end
	},
	sparse = {
		0, 52,
		14, 63,
		right = "castle",
	},
	castle = {
		0, 0,
		14, 14,
	},
	shared_corner = {
		16, 50,
		29, 63,
		up = "castle",
		left = "platform_intro",
		down = "platform_3",
		right = "bubble_a1",
	},
	platform_intro = {
		15, 8,
		28, 9,
		left = "platform_1",
		platforms = {
			simple_platform, {
				2, 2, 0.1,
				25, 9,
				19, 9,
				t = 0.9
			}
		},
	},
	platform_1 = {
		0, 15,
		11, 24,
		left = "platform_2",
		platforms = {
			simple_platform, {
				2, 2, 0.1,
				4, 16,
				8, 16,
				t = 1.2
			},
			simple_platform, {
				2, 2, 0.1,
				4, 20,
				8, 20,
				t = 0.6
			},
			simple_platform, {
				2, 2, 0.1,
				4, 24,
				8, 24,
			},
		},
	},
	platform_2 = {
		27, 8,
		44, 17,
		left = "platform_3",
		platforms = {},
		enter = function()
			for x=0,2 do
				local x2 = 32 + x * 4
				for y=0,3 do
					add(zone_platforms, simple_platform{
						loop = false,
						2, 2, 0.15,
						x2, 2.5,
						x2, 23.5,
						t=(y/4 - x/12) % 1
					})
				end
			end
		end,
	},
	platform_3 = {
		0, 25,
		12, 38,
		pad_left = 3,
		platforms = {
			simple_platform, {
				2, 2, 0.12,
				-2, 28,
				4, 28,
				t = 0.8
			},
			simple_platform, {
				2, 2, 0.12,
				10, 29,
				10, 32,
				t = 0.7
			},
		},
		enter = function()
			for i=1,6 do
				add(zone_platforms, simple_platform{
					2, 2, 0.1,
					7, 32,
					-2, 32,
					-2, 38,
					7, 38,
					t = ({ 0.00000, 0.55556, 1.16667, 2.00000, 2.55556, 3.16667 })[i],
				})
			end
		end,
	},
	bubble_a1 = {
		96, 0,
		109, 7,
		right = "bubble_a2",
		enemies = {
			bubble, {
				100, 7
			},
			bubble, {
				103, 7
			},
			bubble, {
				103, 4
			},
			bubble, {
				103, 1
			},
			bubble, {
				106, 1
			},
		}
	},
	bubble_a2 = {
		54, 51,
		68, 63,
		up = "bubble_a3",
		enemies = {
			bubble, {
				57, 55
			},
			bubble, {
				61, 55
			},
			bubble, {
				61, 59
			},
			bubble, {
				62, 63
			},
			bubble, {
				65.5, 59
			},
			bubble, {
				68, 55
			},
		}
	},
	bubble_a3 = {
		119, 51,
		127, 63,
		up = "bubble_a4",
		pad_right = 2.5,
		enemies = {
			bubble, {
				123.3, 62
			},
			bubble, {
				125.4, 62
			},
			bubble, {
				127.6, 62
			},
			bubble, {
				129.8, 62
			},
			bubble, {
				129.8, 59.9
			},
			bubble, {
				129.8, 57.8
			},
			bubble, {
				129.8, 55.7
			},
		},
		platforms = {
			simple_platform, {
				auto_scroller = true,
				loop = false,
				2, 2, 0.125,
				129.8, 53.3,
				125, 53.3,
				125, 56.5,
				120, 56.5,
			},
		}
	},
	bubble_a4 = {
		69, 57,
		75, 63,
		right = "bubble_0",
		pad_left = 3,
		pad_up = 3,
		enemies = {
			bubble, {
				67.5, 59
			},
			bubble, {
				67.5, 55.5
			},
			bubble, {
				71, 55.5
			},
		}
	},
	bubble_0 = {
		15, 8,
		28, 9,
		right = "bubble_1",
		enemies = {
			bubble_blower, {
				0.25,
				20.3, 14,
			},
			bubble_blower, {
				0.75,
				23.7, 4,
			},
		},
	},
	bubble_1 = {
		27, 8,
		44, 17,
		right = "bubble_2",
		enemies = {
			bubble_blower, {
				0.25,
				31, 20,
			},
			bubble_blower, {
				0.25,
				34.33, 20,
				delay=21,
			},
			bubble_blower, {
				0.25,
				37.66, 20,
				delay=12,
			},
			bubble_blower, {
				0.25,
				41, 20,
				delay=3,
			},
		},
	},
	bubble_2 = {
		0, 39,
		12, 51,
		up = "bubble_3",
		pad_down = 0.5,
		pad_right = 0.5,
		enemies = {
			bubble_blower, {
				0.75,
				4, 49,
				delay=20,
			},
			bubble_blower, {
				0.75,
				6, 49,
				delay=10,
			},
			bubble_blower, {
				0.75,
				8, 49,
			},
			bubble_blower, {
				0,
				9, 47,
				delay=10,
			},
			bubble_blower, {
				0,
				9, 45,
			},
			bubble_blower, {
				0,
				9, 43,
				delay=20,
			},
		},
	},
	bubble_3 = {  
		13, 12,
		14, 28,
		up = "bubble_frogger",
		pad_right = -8,
		enemies = {
			bubble_blower, {
				0.25,
				5.5, 28.1,
			},
			bubble_blower, {
				0.25,
				8.5, 28.1,
			},
			bubble_blower, {
				0.25,
				11.5, 28.1,
			},
		},
	},
	bubble_frogger = {
		13, 27,
		14, 45,
		up = "bubble_4",
		enemies = {
			bubble_blower, {
				0.5,
				22.5, 41.5,
				pre = 4,
				delay = 20,
			},
			bubble_blower, {
				0.5,
				22.5, 35,
				pre = 4,
				delay = 5,
			},
		},
		platforms = {
			simple_platform, {
				6, 1.5, 0.21,
				1, 31.5,
				26.5, 31.5,
				loop = false,
			},
		},
		enter = function()
			for i=0,2 do
				add(zone_platforms, simple_platform{
					3, 1.5, 0.13,
					2, 38.25,
					25.5, 38.25,
					t = 0.2 + i / 3,
					loop = false,
				})
			end
		end,
	},
	bubble_4 = {
		15, 10,
		21, 26,
		up = "bubble_rest",
		pad_left = -2,
		platforms = {
			simple_platform, {
				auto_scroller = true,
				loop = false,
				2, 2, 0.11,
				21, 23,
				13, 23,
				13, 14,
				21, 14,
			},
		},
		enemies = {
			bubble_blower, {
				0,
				12, 17.5,
			},
			bubble_blower, {
				0.5,
				27, 19.5,
			},
		}
	},
	bubble_rest = {
		38, 0,
		43, 5,
		pad_up = 2,
		pad_right = 2,
		left = "bubble_5",
	},
	bubble_5 = {
		45, 11,
		59, 12,
		left = "bubble_6",
		enemies = {
			bubble_blower, {
				0.25,
				48.5, 18,
				56.5, 18,
				rate = 18,
				speed = 0.16,
				t = 0.93,
			},
		},
	},
	bubble_6 = {
		38, 48,
		53, 63,
		up = "bubble_exit",
		enemies = {
			bubble_blower, {
				0.25,
				48.5, 18,
				56.5, 18,
				rate = 18,
				speed = 0.16,
				t = 0.93,
			},
		},
		enter = function()
			for i=1,3 do
				add(zone_enemies, bubble_blower{
					function(t)
						local r = 7.2
						local a = i/3 - t / 480 + 0.25
						return vec(46 + cos(a) * r, 56 + sin(a) * r), a+0.56
					end,
					rate = 21,
					delay = i * -7,
				})
			end
		end,
	},
	bubble_exit = {
		87, 57,
		90, 63,
		up = "cannon_0a",
	},
	cannon_0a = {
		0, 0,
		1, 1,
		up = "cannon_0",
		pad_up = 14,
		enemies = {
			cannon, {
				0.25,
				1, -1.5
			},
		}
	},
	cannon_0 = {
		0, 0,
		1, 1,
		left = "cannon_1",
		pad_down = 7,
		pad_right = 13,
		enemies = {
			cannon, {
				0.875,
				7.5, 1
			},
			cannon, {
				0.75,
				3.5, -3.5
			},
			cannon, {
				0,
				3.5, 5.5
			},
			cannon, {
				0.5,
				12.5, -3.5
			},
			cannon, {
				0.25,
				12.5, 5.5
			},
		}
	},
	cannon_1 = {
		44, 0,
		57, 5,
		pad_up = 3,
		left = "cannon_2a",
		enemies = {
			cannon, {
				0.25,
				54.5, 5
			},
			cannon, {
				0.75,
				51, -3
			},
			cannon, {
				0.5,
				47.5, 5
			},
		},
	},
	cannon_2a = {
		26, 11,
		45, 12,
		left = "cannon_2",
		enemies = {
			cannon, {
				0.5,
				43.5, 12
			},
			bubble_blower, {
				0.75,
				33.5, 3.5,
				pre = 2,
			},
			bubble_blower, {
				0.25,
				38, 20.5,
				delay = 10,
				pre = 3,
			},
		},
	},
	cannon_2 = {
		91, 62,
		107, 63,
		left = "cannon_3",
		pad_down = 6,
		enemies = {
			cannon, {
				0.5,
				105.5, 63
			},
			bubble, {
				98, 63
			},
			bubble, {
				98, 66.75
			},
			cannon, {
				0.125,
				98, 70.5
			},
		}
	},
	cannon_3 = {
		110, 0,
		127, 8,
		down = "cannon_4",
		pad_left = -0.2,
		enemies = {
			cannon, {
				0.5,
				125.5, 1,
			},
			cannon, {
				0,
				112, -6,
			},
			bubble, {
				116.5, 1
			},
			bubble, {
				119, -2.5
			},
			bubble, {
				119, 1
			},
			bubble, {
				112, -2.5
			},
		},
		platforms = {
			simple_platform, {
				auto_scroller = true,
				loop = false,
				2, 2, 0.12,
				112, 1,
				112, 5,
				119, 5,
			}
		},
	},
	cannon_4 = {
		117, 33,
		127, 50,
		down = "pre_flip",
		enemies = {
			cannon, {
				0,
				118, 41,
				118, 36.5,
				t = 0.6,
				int = int_cos,
			},
			cannon, {
				0.5,
				127, 39.75,
				127, 44.25,
				int = int_cos,
				t = 0.6,
			},
			cannon, {
				0,
				118, 47.5,
				118, 43,
				t = 0.6,
				int = int_cos,
			},
		},
	},
	pre_flip = {
		67, 0,
		72, 5,
		right = "flip1",
		pad_left = 2,
		enemies = {
			cannon, {
				0.75,
				65.5, 2,
			},
			bubble, {
				68.5, 7.5
			}
		},
	},
	flip1 = {
		58, 0,
		66, 5,
		right = "flip1x",
		enemies = {
			bubble_flip, { 60, 5.8 },
			bubble_flip, { 65, 0.2 },
		}
	},
	flip1x = {
		83, 14,
		92, 18,
		right = "flip2",
		down = "flip1y",
		pad_down = 2,
		enemies = {
			bubble_flip, { 88, 15 },
		},
	},
	flip1y = {
		83, 16,
		92, 16,
		enemies = {
			bubble, { 88, 17.5 },
		},
	},
	flip2 = {
		82, 0,
		95, 9,
		right = "flip3a",
		enemies = {
			bubble_flip, { 85.5, 4 },
			bubble_flip, { 84.5, 10 },
			bubble_flip, { 90.5, 5 },
			cannon, { 0.727, 94.5, 0.5 },
		}
	},
	flip3a = {
		109, 54,
		118, 63,
		down = "flip3b",
		up = "flip3d",
		right = "flip4",
	},
	flip3b = {
		122, 20,
		127, 29,
		pad_down = 2.2,
		enemies = {
			bubble_flip, { 120.3, 27 },
			bubble_flip, { 129.7, 27 },
			bubble_flip, { 125, 31.7 },
		}
	},
	flip3d = {
		119, 9,
		127, 19,
		enemies = {
			bubble_flip, { 127.5, 10 },
		}
	},
	flip4 = {
		68, 11,
		81, 18,
		right = "flip5",
		enter = function(self)
			for x=72,78,3 do
				for y=12,18,3 do
					add(zone_enemies, bubble_flip{ x, y })
				end
			end
		end,
	},
	flip5 = {
		89, 31,
		102, 32,
		right = "flip6",
		enemies = {
			bubble_flip, { 96, 37.5 },
			bubble_flip, { 96, 26.5 },
			cannon, { 0.75, 92.5, 32 },
			cannon, { 0.25, 99.5, 35 },
			cannon, { 0.5, 99.5, 29.25 },
		},
		platforms = {
			simple_platform, {
				auto_scroller = true,
				loop = false,
				1, 1, 0.12,
				99.5, 37.5,
				96, 37.5,
			}
		}
	},
	flip6 = {
		73, 27,
		88, 38,
		right = "ending",
		pad_up = 1,
		door_right = 38,
		enemies = {
			bubble, { 78, 34.5 },
			cannon, { 0.25, 75.5, 38 },
			cannon, { 0, 80.5, 38 },
			bubble_blower, { 0.75, 85.5, 31 },
			bubble, { 83, 26.5 },
			bubble_flip, { 78, 26.5 },
		},
		platforms = {
			simple_platform, {
				auto_scroller = true,
				loop = false,
				2, 2, 0.12,
				78, 31,
				83, 31,
			}
		}
	},
	ending = {
		3, 0,
		3, 1,
		pad_right = 10,
		enter = function(self)
			-- game complted when we enter this screen while being shot by a cannon :)
			if p_captured then
				p_mode = 2
			end

			srand(1500)
			self.ps = {}
			for i=0,26 do
				add(self.ps, {
					x = rnd(),
					y = rnd(),
					s = rnd(),
					d = rnd_sign(),
				})
			end
		end,
		draw = function(self)
			local x0 = max(cam_center0.x + 0.5, p_pos.x - cam_size/2)
			local y0 = cam_center0.y - cam_size/2
			local w = cam_size + 2

			for point in all(self.ps) do
				local p = cam_tf(vec(
					x0 - 1 + (point.x * w - x0) % w,
					y0 - 1 + point.y * w
				))

				local p0
				for i=0,10 do
					local p1 = p + polar(i * 0.1 + zone_t * 0.01 * point.d + point.s, (1.2 + i%2 * 2.5) * (1 + point.s))
					if p0 then
						line(p0.x, p0.y, p1.x, p1.y, 1)
					end
					p0 = p1
				end
			end
		end,
	},
}




zone_dirs = {
	"left", "right", "up", "down",
}
zone_dirs_info = {
	left = {true, -1},
	right = {true, 1},
	up = {false, -1},
	down = {false, 1},
}
zone_inverse_dirs = {
	up = "down",
	down = "up",
	left = "right",
	right = "left" 
}
-- zone_flip = false

-- initiliase zone definitions
for name, zone in pairs(zones) do
	-- simplify extra meta
	zone.name = name
	zone.x1 = zone[1]
	zone.y1 = zone[2]
	zone.x2 = zone[3]
	zone.y2 = zone[4]
	zone.vx1 = zone.x1 - (zone.pad_left or 0)
	zone.vy1 = zone.y1 - (zone.pad_up or 0)
	zone.vx2 = zone.x2 + (zone.pad_right or 0)
	zone.vy2 = zone.y2 + (zone.pad_down or 0)
	zone.flip = zone.flip == true -- nil to false

	-- generate zone id from name
	local id = 0
	for i=1,#name do
		id += ord(name, i)
	end
	zone.id = id

	-- -- DEV_ONLY: ensure no duplicate ids generated (fix by changing zone name)
	-- zone_ids = zone_ids or {}
	-- assert(not zone_ids[id], "duplicate zone id")
	-- zone_ids[id] = zone
	
	-- add inverse references
	for name2, zone2 in pairs(zones) do
		for dir in all(zone_dirs) do
			if zone[dir] == name2 then
				zone2[zone_inverse_dirs[dir]] = name
			end
		end
	end
end

-- zone state
function load_zone(name, dir, move_player)
	-- handle position transformation between zones
	local prev_zone = zone
	zone = zones[name]
	zone_t = 0
	zone_is_end = zone.name == "ending"

	-- update to match flip state
	zone_edges = nil
	zone_set_flip(zone_flip)

	-- if moving between zones, need to teleport player into new zone
	if move_player != false and prev_zone and dir then
		-- use the direction to get the entry/exit positions for each zone
		local inv_dir = zone_inverse_dirs[dir]

		local prev_entry = zone_door_pos(prev_zone, dir)
		local entry = zone_door_pos(zone, inv_dir)

		-- teleport!
		p_pos = (p_pos - prev_entry) + entry
		
		if zone != prev_zone then
			p_pos_smooth = p_pos
		end

		-- snap to edge of zone
		local dirx = zone_dirs_info[inv_dir][1]
		if dirx then
			p_pos.x = entry.x
		else
			p_pos.y = entry.y
		end

		-- if we would teleport into a wall, use door entrance instead. you're welcome :)
		if p_in_wall() then
			if dirx then
				p_pos.y = entry.y
			else
				p_pos.x = entry.x
			end
		end
	else
		-- loading zone directly
		p_pos_smooth = p_pos
	end

	-- save progress
	if p_over_ground() then
		dset(0, p_pos.x)
		dset(1, p_pos.y)
		dset(2, zone.id)
		dset(3, g_timer)
		dset(4, g_deaths)
		dset(7, zone_flip and 1 or 0)
	end

	-- if portal-ing across screen then we don't need to reload stuff!
	if zone == prev_posz then
		return
	end

	-- load the edges (used for rendering)
	zone_edges = edges_get(mget, zone.x1, zone.y1, zone.x2, zone.y2)

	local function check_vec(v)
		-- if (zone.left and v.x <= zone.x1) or (zone.right and v.x > zone.x2) then
		-- 	v.outx = true
		-- end
		-- if (zone.up and v.y <= zone.y1) or (zone.down and v.y > zone.y2) then
		-- 	v.outy = true
		-- end
		return (zone.left and v.x <= zone.vx1) or (zone.right and v.x > zone.vx2) or
		(zone.up and v.y <= zone.vy1) or (zone.down and v.y > zone.vy2)
	end

	for e in all(zone_edges) do
		if check_vec(e[1]) and check_vec(e[2]) then
			del(zone_edges, e)
		end
	end

	-- load the platforms
	zone_platforms = {}
	if zone.platforms then
		for i=2,#zone.platforms,2 do
			add(zone_platforms, zone.platforms[i - 1](zone.platforms[i]))
		end
	end
	
	-- load the enemies
	zone_enemies = {}
	if zone.enemies then
		for i=2,#zone.enemies,2 do
			add(zone_enemies, zone.enemies[i - 1](zone.enemies[i]))
		end
	end

	-- custom zone entry function
	if (zone.enter) zone:enter()

	-- setup camera
	set_camera()
end

function zone_tile(x, y)
	if x < zone.x1 or y < zone.y1 or flr(x) > zone.x2 or flr(y) > zone.y2 then
		return 0
	end
	return mget(x, y)
end

function zone_tiles(x, y, width)
	return zone_tile(x - width, y - width)
		 | zone_tile(x + width, y - width)
		 | zone_tile(x - width, y + width)
		 | zone_tile(x + width, y + width)
end

function zone_tiles_wall(x, y, width)
	return zone_tiles(x, y, width) & 2 == 2
end

function zone_door_pos(zone, dir)
	local info = zone_dirs_info[dir]
	local s = info[2]
	local ds = 0.5 + s * 0.4
	local explict = zone["door_"..dir]

	if info[1] then
		local x = s==1 and zone.vx2 or zone.vx1
		
		if (explict) return vec(x + ds, explict)

		local miny,maxy
		for y = zone.y1, zone.y2 do
			if mget(x, y) != 0 then
				miny = miny or y
				maxy = y
			end
		end
		return vec(
			x + ds,
			(miny and (miny + maxy) or (zone.vy1 + zone.vy2)) / 2 + 0.5
		)
	else
		local y = s==1 and zone.vy2 or zone.vy1

		if (explict) return vec(explict, y + ds)

		local minx,maxx
		for x = zone.x1, zone.x2 do
			if mget(x, y) != 0 then
				minx = minx or x
				maxx = x
			end
		end
		return vec(
			(minx and (minx + maxx) or (zone.vx1 + zone.vx2)) / 2 + 0.5,
			y + ds
		)
	end
end

function load_zone_and_player(name, dir)
	load_zone(name, dir, false)
	p_pos = zone_door_pos(zone, zone_inverse_dirs[dir])
	p_pos_smooth = p_pos * 1
end

function zone_toggle_flip_data()
	zone.flip = not zone.flip

	-- flip edge colors
	for e in all(zone_edges) do
		if e.m == 0 then
			e.n = 2 - (e.n - 1)
		end
	end

	-- flip map data
	for x=zone.x1,zone.x2 do
		for y=zone.y1,zone.y2 do
			local n = mget(x, y)
			if (n != 0) mset(x, y, 2 - (n - 1))
		end
	end
end

function zone_toggle_flip()
	zone_flip = not zone_flip
	zone_toggle_flip_data()
end

function zone_set_flip(flip)
	zone_flip = flip
	if zone.flip != flip then
		zone_toggle_flip_data()
	end
end




function thline(x1, y1, x2, y2, c1, c2)
	for y=-1,1 do
	for x=-1,1 do
		line(
			x1 - x,
			y1 - y,
			x2 - x,
			y2 - y,
			c1
		)
	end
	end

	line(x1, y1, x2, y2, c2)
end

function wline(x1, y1, x2, y2, w, c)
	local dx, dy =
		x2 - x1,
		y2 - y1
	local len=sqrt(dx * dx + dy * dy) * 0.82

	for i=0,len do
		local t = i / len
		local x, y =
			x1 + dx * t,
			y1 + dy * t
		
		rectfill(
			x - w,
			y - w,
			x + w,
			y + w,
			c
		)
	end
end

function thprint(s, x, y, c1, c2)
	for dx=-1,1 do
		for dy=-1,1 do
			?s, x + dx, y + dy, c1
		end
	end
	?s, x, y, c2
end




-- localized input
-- button_1_prev = false
-- button_2_prev = false

-- global game settings/state
g_timer = 0
g_deaths = 0
g_speedrun = false
g_wobble_amount_i = 6
g_wobble_amount = 1

function g_set_speedrun(enabled)
	g_speedrun = enabled
	dset(5, enabled and 1 or 0)
	menuitem(3, (enabled and "hide" or "show").." timer", function() g_set_speedrun(not g_speedrun) end)
end

function g_set_wobble(wobble_i)
	g_wobble_amount_i = mid(0, 6, wobble_i)
	g_wobble_amount = g_wobble_amount_i / 6
	dset(6, g_wobble_amount_i)
	local s = "wobble <"
	for i=0,6 do
		s ..= (i == g_wobble_amount_i and "◆" or ".")
	end
	menuitem(2, s .. ">", function(b)
		if b != 0 then
			g_set_wobble(g_wobble_amount_i + menuitem_cursor(b))
		end
	end)
end

function g_set_screen_skip_index(i)
	i = i % 4
	local dir = zone_dirs[1 + i]
	menuitem(4, "skip < " .. dir .. " >", function(b)
		if b == 112 then
			local next = zone[dir]
			if next then
				load_zone_and_player(next, dir)
			end
		else
			g_set_screen_skip_index(i + menuitem_cursor(b))
		end
	end)
end
g_set_screen_skip_index(0)

menuitem(5, "reset progress", function()
	g_timer = 0
	g_deaths = 0
	load_zone(p_init(), nil, false)
end)

function _update()
	-- need to set pal every frame in case of resume()
	pal({
		[0]=134,
		[1]=7,
		[2]=133,
		[3]=15,
		[4]=143,
		[8]=5
	}, 1)

	-- read inputs
	local ix, iy = 0, 0
	if (btn(0) or btn(0, 1)) ix -= 1
	if (btn(1) or btn(1, 1)) ix += 1
	if (btn(2) or btn(2, 1)) iy -= 1
	if (btn(3) or btn(3, 1)) iy += 1
	local iv = vec(ix, iy):norm()

	local button_1, button_2 = btn(4) or btn(4, 1), btn(5) or btn(5, 1)
	local any_button = button_1 or button_2

	-- intro :)
	if p_mode == 0 then
		if any_button then
			p_mode = 1
		else
			return
		end
	end

	-- -- DEV_ONLY: move player automatically during frame-step mode (change to whatever direction you like)
	-- if (stat(110)) iv = vec(-1, 0)

	-- -- DEV_ONLY: quick screen navigation
	-- if btn(4, 1) then
	-- 	for i=0,3 do
	-- 		local dir = zone_dirs[1 + i]
	-- 		if (btnp(i) and zone[dir]) load_zone_and_player(zone[dir], dir) break
	-- 	end
	-- end

	-- -- DEV_ONLY: flip
	-- if btnp(5, 1) then
	-- 	zone_toggle_flip()
	-- end

	-- during death + transition out of death
	p_spawned = false

	if not p_alive then
		p_death_t += 1

		if p_death_t >= 11 then
			-- respawn
			p_alive = true

			-- put player back at last safe location
			-- if was in a previus zone, load back into that zone
			if p_safe_zone then
				if p_safe_zone == zone then
					zone_set_flip(p_safe_flip)
				else
					zone_flip = p_safe_flip
					load_zone(p_safe_zone.name)
					p_pos_smooth = p_safe_pos * 1
				end
				p_pos = p_safe_pos * 1
			end
			
			-- respawn effects
			p_add_jump_particle(0, 4)
			sfx(10)

			-- update state
			button_1_prev = false
			button_2_prev = false
			p_spawned = true

			-- if respawning from end need to reset camera
			if p_mode == 2 then
				p_mode = 1
				cam_center = cam_center0
				p_dj_count = 2 -- luca's gift :3
			end
		end
	end

	-- read player inputs + handle vertical movement
	local p_vel = vec()
	local prev_posz = p_posz

	p_press_jump = (not button_1_prev and button_1) or (not button_2_prev and button_2)
	button_1_prev = button_1
	button_2_prev = button_2

	-- if p_alive and not p_captured and not p_force_vel then
	if p_alive and not p_captured then
		-- jump or double jump
		if p_press_jump and (p_on_floor() or p_dj > 0) then
			if p_on_floor() then
				-- ground jump
				p_jump(0.45)
			else
				-- double jump
				sfx(8)
				p_add_jump_particle(0)

				if p_velz < 0 then
					p_velz = 0.35
				else
					p_velz += 0.35
				end
				p_dj -= 1
			end
		end

		-- vertical movement (move + gravity)
		p_posz += p_velz
		p_velz -= (p_velz < 0 or any_button) and 0.06 or 0.16

		-- base movement velocity
		p_vel = iv * 0.23
	end

-- 	if p_force_vel then
-- 		-- p_vel = p_force_vel + (iv - iv:proj(p_force_vel)) * 0.23
-- 		p_posz += p_velz
-- 		p_velz -= p_capture_gravity
-- 
-- 		if p_posz >= 0 then
-- 			p_vel = p_force_vel + iv * 0.08
-- 		end
-- 	end

	-- pre-update enemies
	for e in all(zone_enemies) do
		if e.pre_update then
			e:pre_update()
		end
	end

	-- update platforms
	for p in all(zone_platforms) do
		local didContain = p.contains(p_pos, p_w)
		local delta = p:update(didContain)
		if p_alive and not p_captured and didContain and p_on_floor() and p.contains(p_pos, p_w) then
			p_vel += delta
		end
	end

	-- last capture check
	if p_captured then
		p_vel = vec()
	end

	-- captured!!!
	if p_alive and p_captured then
		-- add capture velocity (even after jumping out, feels better...)
		p_vel += p_capture_vel

		-- jump out
		if not p_locked and p_press_jump then
			p_uncapture()
		elseif not in_view(p_pos, 0.5) then
			-- die from being offscreen :(
			p_kill()
		end
	end

	-- handle landing
	if p_alive and not p_captured then
		-- landing
		if p_posz <= 0 then
			p_velz = 0
			p_posz = 0
			-- p_force_vel = nil

			if p_over_ground() then
				p_kt = -1

				if prev_posz > 0 then
					sfx(9)
					p_add_jump_particle(0, 2)	
				end
			end
		end
	end

	-- apply horizontal movement delta
	if p_alive then
		-- local wall_tile = p_force_vel and 3 or 2
		local wall_tile = 2

		-- player width (in direction we're moving) larger if captured
		local _pw = p_captured and 0.6 or p_ew

		-- move in four steps, checking if we move into any walls
		local dv = p_vel / 4
		for i=0,3 do
			-- first move in x-axis
			p_pos.x += dv.x

			local top = p_pos.y - p_ew
			local bottom = p_pos.y + p_ew
			local left = p_pos.x - _pw
			local right = p_pos.x + _pw
			local rem = p_pos.y % 1

			if dv.x != 0 then
				local x = dv.x < 0 and left or right

				local wall_top = zone_tile(x, top) == wall_tile
				local wall_bottom = zone_tile(x, bottom) == wall_tile

				-- assist moving past edges (up or below)
				if dv.y == 0 and not wall_top and wall_bottom and rem > 0.5  then
					p_pos.y -= bottom % 1 + 0.01
				elseif dv.y == 0 and wall_top and not wall_bottom and rem < 0.5  then
					p_pos.y += 1 - (top % 1) + 0.01
				elseif wall_top or wall_bottom then
					-- bump against wall
					if dv.x < 0 then
						p_pos.x += 1 - (left % 1) + 0.01
					else
						p_pos.x -= right % 1 + 0.01
					end

					if p_captured then
						p_uncapture()
						dv.x = 0
					end
				end
			end

			-- now move in y-axis
			p_pos.y += dv.y

			top = p_pos.y - _pw
			bottom = p_pos.y + _pw
			left = p_pos.x - p_ew
			right = p_pos.x + p_ew
			rem = p_pos.x % 1

			if dv.y != 0 then
				local y = dv.y < 0 and top or bottom

				local wall_left = zone_tile(left, y) == wall_tile
				local wall_right = zone_tile(right, y) == wall_tile

				-- assist moving past edges (to the left or right)
				if dv.x == 0 and not wall_left and wall_right and rem > 0.5  then
					p_pos.x -= right % 1 + 0.01
				elseif dv.x == 0 and wall_left and not wall_right and rem < 0.5  then
					p_pos.x += 1 - (left % 1) + 0.01
				elseif wall_left or wall_right then
					-- bump against wall
					if dv.y < 0 then
						p_pos.y += 1 - (top % 1) + 0.01
					else
						p_pos.y -= bottom % 1 + 0.01
					end

					if p_captured then
						p_uncapture()
						dv.y = 0
					end
				end
			end

			-- check tiles
			if p_on_floor() then
				if p_over_ground() then
					-- we only want to save safe positions
					if (prev_posz > 0 and p_tiles() & 1 == 1) or zone_tile(p_pos.x, p_pos.y) == 1 then
						p_safe_pos = p_pos * 1
						p_safe_zone = zone
						p_safe_flip = zone.flip
					end
				elseif not p_captured then
					-- currently over the void
					if p_kt < 0 then
						-- init kyote time
						p_kt = 6
					else
						-- decrement kyote time
						p_kt -= 1
						if p_kt <= 0 then
							-- end of kyote time, we fell!
							p_kill()
						end
					end
				end
			end

			-- may have been killed during this step
			if not p_alive then
				break
			end
		end

		-- check zone transition
		if zone.down and flr(p_pos.y) > zone.vy2 then
			load_zone(zone.down, "down")
		elseif zone.up and p_pos.y < zone.vy1 then
			load_zone(zone.up, "up")
		elseif zone.right and flr(p_pos.x) > zone.vx2 then
			load_zone(zone.right, "right")
		elseif zone.left and p_pos.x < zone.vx1 then
			load_zone(zone.left, "left")
		end
	end

	-- smooth player pos
	p_pos_smooth = p_pos_smooth:toward(p_pos, 0.6)
	
	-- update player particles
	p_particles:update()

	-- post update enemies
	for e in all(zone_enemies) do
		if e.update then
			e:update()
		end
	end

	-- update enemy particles
	enemy_particles:update()

	-- zone tick
	zone_t += 1

	if p_mode == 2 and zone_is_end then
		-- beat game mode
		-- center camera on player (after have passed end)
		if p_pos.x > cam_center0.x then
			cam_center = vec(p_pos.x, cam_center0.y)
		end

		if p_pos.x > 10 then
			local t = flr((p_pos.x - 12) / 13)
			if t > p_end_animation_t and t <= 3 then
				sfx(17 + t)
				p_end_animation_t = t
			end
		else
			p_end_animation_t = 0
		end
	elseif p_mode != 0 then
		-- main game mode
		-- game info update
		g_timer += 0x.01 -- use decimal bits to increase time until overflow (normally would be 18mins, 2 decimals increases to about half a year)
	end
end

function _draw()
	cls()
	
	-- draw level
	for y=zone.y1, zone.y2 do
	for x=zone.x1, zone.x2 do
		local tile = mget(x, y)
		if tile != 0 then
			local v = cam_tf(vec(x + .5, y + .5))
			pset(v.x, v.y, tile)
		end
	end
	end
	
	for tile_n = 1,2 do
		-- draw platforms between floor and osbtacles
		if tile_n == 2 then
			for p in all(zone_platforms) do
				p:draw()
			end
		end

		-- draw level tiles
		for e in all(zone_edges) do
			if e.n == tile_n then
				local v1 = add_wobble(1, e[1])
				local v2 = add_wobble(1, e[2])
				v1 = cam_tf(v1)
				v2 = cam_tf(v2)

				wline(v1.x, v1.y, v2.x, v2.y, 0.35, e.n)
			end
		end
	end

	-- custom zone draw
	if zone.draw then
		zone:draw()
	end

	-- draw enemies
	for e in all(zone_enemies) do
		e:draw()
	end

	-- enemy particles
	enemy_particles:draw()
	
	-- draw player
	local pworld = p_pos_world()
	local ps0 = cam_tf(p_pos)
	local ps1 = cam_tf(pworld)
	
	-- player shadow
	if p_posz > 0 then
		fillp(▒)

		circfill(ps0.x, ps0.y, mid(2, 3, 1.4 + p_posz * 0.7), 8)

		fillp()
	end
	
	-- player particles
	p_particles:draw()

	-- player body
	-- don't draw for a few frames at end of death animation
	if not p_hidden and (p_alive or p_death_t < 7) then
		-- -- capture outline
		-- if p_captured then
		-- 	local r = 0.7 * cam_scale
		-- 	-- fillp(▒)
		-- 	for j=0,1 do
		-- 	for i=0,16 do
		-- 		local a = i/17
		-- 		local a2 = a
		-- 		local r2 = r * (1 + sin(a2 + time()) * sin(a2 * 7 + time()) * 0.1)
		-- 		local x2,y2 = flr(ps1.x + cos(a) * r2), flr(ps1.y + sin(a) * r2)
		-- 		pset(x2, y2, 1)
		-- 	end
		-- 	end
		-- 	fillp()
		-- end

		-- fade out over death
		if not p_alive and p_death_t >= 3 then
			fillp(▒)
		end

		-- generate a ring of points
		local p_scale = p_alive and 1 or max(0, 1 - (p_death_t + 1) / 6)
		local p_sin_scale = 0.08 + (1 - p_scale) * 0.1
		local p_sin_rate = 0.4
		local p_sin_count = 5
		if p_captured then
			p_sin_scale *= 3.7
			p_sin_rate = 2.5
			p_sin_count = 4

			-- reverse spin direction if going left/down
			local p_angle = atan2(p_capture_vel.x, p_capture_vel.y)
			if p_angle > 0.125 and p_angle < 0.625 then
				p_sin_rate = -p_sin_rate
			end
		end
		
		local ps = {}
		for i=0,15 do
			i = i%15
			local a = i/15
			add(ps, 
				cam_tf(pworld + vec(cos(a), sin(a)) * (0.21 - 1/cam_scale + sin(a * p_sin_count + t() * p_sin_rate) * p_sin_scale) * p_scale)
			)
		end
		
		-- draw ring as three thick lintes
		-- 0=bg border
		-- 1=outer fg
		-- 2=inner bg
		for j=0,2 do
			-- line width, shrink as die
			local width = (2 - j) * lerp(0.2, 1, p_scale)

			-- don't draw inside while small!
			if j==2 and p_scale < 0.4 then
				break
			end

			-- draw wide lines between each point
			for i=1,15 do
				local p1 = ps[i]
				local p2 = ps[i + 1]
				wline(p1.x, p1.y, p2.x, p2.y, width, j % 2)
			end
		end

		fillp()
	end

	-- speedrun/results ui
	local end_anim_t = p_mode != 2 and 0 or p_end_animation_t
	if g_speedrun or end_anim_t >= 1 then
		local seconds = g_timer * 8.533333 -- 256 / 30
		local mins = flr(seconds / 60)
		seconds = seconds % 60
		local rem_seconds = flr((seconds % 1) * 100)
		if rem_seconds < 10 then
			rem_seconds = "0" .. rem_seconds
		end
		seconds = flr(seconds)
		if seconds < 10 then
			seconds = "0" .. seconds
		end

		thprint(mins .. ":" .. seconds .. "." .. rem_seconds, 2, 2, 0, 1)
	end
	if end_anim_t >= 2 then
		local s = tostr(g_deaths)
		thprint(s .. "♥", 119 - #s * 4, 2, 0, 1)
	end
	if end_anim_t >= 3 then
		thprint("thanks for playing!", 24, 121, 0, 1)
	end

	-- -- DEV_ONLY: debug ui
	-- ?cam_scale,2,8,15
end

-- start!
do
	-- load saved data
	local zone_name
	if cartdata("lucaharris_starjump") then
		-- have save data
		p_pos = vec(dget(0), dget(1))
		local id = dget(2)
		g_timer = dget(3)
		g_deaths = dget(4)
		g_speedrun = dget(5) > 0
		g_wobble_amount_i = dget(6)
		zone_flip = dget(7) > 0
		p_mode = 1

		for name,zone in pairs(zones) do
			if zone.id == id then
				zone_name = name
				break
			end
		end
	end

	g_set_speedrun(g_speedrun)
	g_set_wobble(g_wobble_amount_i)

	-- failed to find save data, load from start!
	if not zone_name then
		zone_name = p_init()
	end

	-- -- DEV_ONLY: load directly to test area
	-- p_mode = 1  p_alive = true  zone_flip = true  load_zone_and_player("flip5", "right")

	-- load into chosen zone
	load_zone(zone_name, nil, false)
end



