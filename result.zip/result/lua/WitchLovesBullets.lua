--by matthieu le gallic
--♪ dustin van wyk

--
--player entity
--
player=
 {
 hitbox={x=5,y=6,w=6,h=8},
 
 init=function(this)
  this.x=-48
  this.y=56
  this.life=lifemax
  this.pow=0
  this.powtimer=0
  this.rapidtime=5
  this.rbubl=0
  this.rapid=0
  this.movespd=2
  this.anim=0
  this.move=false
  this.hurt=0
  bosslife=-1
  
  --reload map (restore enemies)
  --useful for respawns
  reload(0x1000,0x1000,0x1fff)
  
  --music
  music(16*(lvl%2))
 end,
 
 hit=function(this)
 
  if this.hurt==0 then
	  this.life-=1
	  this.hurt=60
	  sfx(13)
	  
	  --death
	  if this.life==0 then
	   this.move=false
	   lives-=1
	   deaths+=1
	   
	   --fade out music
	   if lives==0 then
	    music(-1,1000)
	   end
	   
	   --prepare game over screen
	   choice=0
	  end
	  
  end
 end,
 
 update=function(this)
 
  --animation
  this.anim=(this.anim+0.25)%8
  
  --rapid fire timers
  this.rapid=tick(this.rapid)
  this.rbubl=tick(this.rbubl)
  
  --powerup timer
  this.powtimer=tick(this.powtimer)
  this.pow*=min(1,this.powtimer)
  
  --shield timer
  this.hurt=tick(this.hurt)
  
  --respawn
  if this.life==0 and this.hurt==0 then
  
   this.x=16
	  this.y=56
	  
	  while collmap(player) do
	   this.y=flr(rnd(122))-6
	  end
  
	  --respawn
	  if lives!=0 then
	   this.move=true
	   this.life=lifemax
	   this.hurt=60
	  else
	  
	   --stop camera
	   camspd=0
	   
	   this.hurt=1
	   
	   --update game over screen
	   
	   if btnp(2) or btnp(3) then
	    choice=1-choice
	   end
	   
	   if btnp(4) or btnp(5) then
	    
	   	--restart level
	    enemies={}
		   bullets={}
		   lvlx=0
		   camx=0
		   sublvl=0
		   lives=livesmax
		   score=0
		   		   
	    if choice==1 then
	     --exit to main menu
	     sfx(13)
		    lvl=0
		    screen=0
		   else
		    sfx(12)
		    player:init()
		   end
		   
	   end
	  end
   
  end
  
  --movement
  if this.move then
  
	 	if btn(0) then
	 	 this.x-=this.movespd
	 	 while collmap(this) do
	 	  this.x+=1
	 	 end
	 	end
	 	
	 	if btn(1) then
	 	 this.x+=this.movespd
	 	 while collmap(this) do
	 	  this.x-=1
	 	 end
	 	end
	 	
	 	if btn(2) then
	 	 this.y-=this.movespd
	 	 while collmap(this) do
	 	  this.y+=1
	 	 end
	 	end
	 	
	 	if btn(3) then
	 	 this.y+=this.movespd
	 	 while collmap(this) do
	 	  this.y-=1
	 	 end
	 	end
	 	
	 	this.x=clamp(this.x,-this.hitbox.x,128-this.hitbox.w-this.hitbox.x)
	 	this.y=clamp(this.y,-this.hitbox.y,128-this.hitbox.h-this.hitbox.y)
	 	
	  --shoot
	  if btn(4) and not btn(5)
	  and this.rapid==0 then
	   addbullet(this.x+10,this.y+4,6,0,0)
	   if this.pow>1 then
		   addbullet(this.x+10,this.y+2,6,-2,0,0)
		   addbullet(this.x+10,this.y+6,6,2,0,0)
	   end
	   this.rapid=this.rapidtime
	   addpart(this.x+14,this.y+5,0,0,34,1)
   end
	 	
	 	--bubble
	 	if btn(5) and this.rbubl==0 then
	 	 addbullet(this.x+12,this.y+10,1,0,2)
	 	 this.rbubl=this.rapidtime*2
	 	end
 	
 	end
 	
 	--global variables
 	xp=this.x+this.hitbox.x
	 yp=this.y+this.hitbox.y
 	
 end,
 
 draw=function(this)
 
  if this.life>0 then
   
   local arm=0
	  
	  if this.hurt>0 and this.anim%2<1 then
	   sprcol(7)
	  end
	  
	  if this.move and btn(4)
	  and not btn(5) then
	   arm=1
	  end
	  
	  drawwitch(this.x,this.y,1,this.anim,arm)
	  
	  pal()
  else
  
   --fall after dying
   spr(1,this.x-(60-this.hurt),this.y+(20-this.hurt/3)^2,2,2)
   
  end
  
 end
 }
 
--
--bullet entity
--
bullet={
 
 init=function(this)
  this.hitbox={x=1,y=1,w=5,h=5}
  if this.bultype==1 then
   this.hitbox={x=2,y=2,w=3,h=3}
  end
 end,
 
 update=function(this)
  this.x+=this.hspd
  this.y+=this.vspd
  
  --bubble float
  if this.bultype==2 then
   if this.y<water-8 then
    this.vspd+=0.2
   else
    this.vspd=max(-1.5,this.vspd-4)
   end
  end
  
  --collision with walls
  if collmap(this) or this.x<-4 or this.x>124 or this.y<-4 or this.y>124 then
   del(bullets,this)
  end
  
  --collision with player
  if this.bultype==1 and collcheck(this.x+2,this.y+2,3,3,xp,yp,wp,hp) then
   player:hit()
  end
  
 end,
 
 draw=function(this)
  local sprite={32+player.pow%2,38,5+player.anim%2}
  
  spr(sprite[this.bultype+1],this.x,this.y)
 end
 }

--
--particle entity
--
part={
 
 --anim is offset by 1 frame
 --because it starts before the
 --object is drawn
 
 update=function(this)
  this.hspd*=this.fric
  this.vspd*=this.fric
  this.x+=this.hspd
  this.y+=this.vspd
  this.anim+=this.animspd
  if this.anim>=this.animmax+this.animspd then
   del(parts,this)
  end
 end,
 
 draw=function(this)
  spr(this.sprite+this.anim-this.animspd,this.x,this.y)
 end
 
 }

--add a bullet
function addbullet(_x,_y,_hspd,_vspd,_bultype)
 local t={
 x=_x,
 y=_y,
 hspd=_hspd,
 vspd=_vspd,
 bultype=_bultype}
 add(bullets,t)
 bullet.init(t)
 return t
end

--add a particle
function addpart(_x,_y,_hspd,_vspd,_spr,_animspd)
 local t={
 x=_x,
 y=_y,
 hspd=_hspd,
 vspd=_vspd,
 sprite=_spr,
 anim=0,
 animspd=_animspd,
 animmax=2,
 fric=1
 }
 add(parts,t)
 return t
end

--move bullet towards point
function movetowards(t,x2,y2,spd)
 t.hspd=spd*trigcos(t.x,t.y,x2,y2)
 t.vspd=spd*trigsin(t.x,t.y,x2,y2)
end

--add an enemy
function addenemy(_x,_y,_type)
 local t={
 x=_x,
 y=_y,
 typ=_type
 }
 add(enemies,t)
 _type.init(t)
 return t
end

--check for collision
function collcheck(x1,y1,w1,h1,x2,y2,w2,h2)
 return x1+w1>x2 and y1+h1>y2 and x2+w2>x1 and y2+h2>y1
end

--collision with map
function collmap(this,...)
 
 local i,x,y,w,h,m,hit,arg
 arg={...}
 if #arg==0 then
  hit=this.hitbox
 else
  hit=arg[1]
 end
 
 x=(this.x+hit.x+camx)/8
 y=(this.y+hit.y+128*lvl)/8
 w=(hit.w)/8
 h=(hit.h)/8
 
 for i=0,8 do
  if i==4 then i+=1 end
  m=mget(x+w*(i%3)/2,y+h*flr(i/3)/2)
  if fget(m,0) and not fget(m,1) then
   return true
  end

 end
end

--change sprite color
function sprcol(c)
 for i=0,15 do
  pal(i,c)
 end
end

--distance
function dist(x1,y1,x2,y2)
	return sqrt((x2-x1)^2+(y2-y1)^2)
end

function trigcos(x1,y1,x2,y2)
 return (x2-x1)/dist(x1,y1,x2,y2)
end

function trigsin(x1,y1,x2,y2)
 return (y2-y1)/dist(x1,y1,x2,y2)
end

function clamp(x,a,b)
 return min(max(x,a),b)
end

function tick(t)
 return max(0,t-1)
end

--print centered text
function printcnt(str,x,y,col)
 print(str,x-#str*2,y-3,col)
end

--change transparent color
function transcol(c)
 palt(0,false)
 palt(c,true)
end

--draw moon
function drawmoon(x,y)
 spr(16,x,y)
 spr(16,x+8,y,1,1,true,false)
 spr(16,x,y+8,1,1,false,true)
 spr(16,x+8,y+8,1,1,true,true)
end

--draw witch (player,final boss)
function drawwitch(x,y,xscale
                  ,anim,arm)
 
 local i=2*flr(anim%2)
 local y2=y+cos(anim/8)+0.5
 local hflip=xscale==-1

 spr(1+i,x,y2,2,1,hflip,false)
 spr(17+i,x+4-4*xscale,y2+8,1,1,hflip,false)
	  
	spr(18+2*arm,x+4+4*xscale,y2+8,1,1,hflip,false)
end

--begin boss battle
function beginbattle(this)
 this.life=this.lifemax
 this.atk=0
 this.t=this.tmax
 bosslife=this.life
 bosslifemax=this.lifemax
end

function cheat()
 lvlx=3*127
 camx=8*(127-16)
 sublvl=4
end

--function cheat2()
-- enemies[1].life=1
--end
-->8
--enemies

--enemy entity
enemy={
 
 die=function(this)
 
  local i,obj 
  
  for i=0,7 do
   obj=addpart(this.x,this.y,4*cos(i/8),4*sin(i/8),36,0.25)
   obj.fric=0.75
  end
  
  if camspd>0 then
   score+=flr(this.typ.pts*multiplier/10)
   scoretimer=45
   multiplier=min(50,multiplier+2)
  end
  
  del(enemies,this)
  
  sfx(10)
  
 end,
 
 update=function(this)
 
  --enemy-specific code
  this.typ.update(this)
  
  if this.anim!=-1 then
   this.anim=(this.anim+1)%this.animmax
  end
  
  local x1,y1,w1,h1
  
  x1=this.x+this.typ.hitbox.x
  y1=this.y+this.typ.hitbox.y
  w1=this.typ.hitbox.w
  h1=this.typ.hitbox.h
  
  if this.life>=0 then
  
   --collision checking
   for obj in all(bullets) do
  
    if obj.bultype!=1 then
    
     local x2,y2,h2,w2
     x2=obj.x+obj.hitbox.x
     y2=obj.y+obj.hitbox.y
     w2=obj.hitbox.w
     h2=obj.hitbox.h
    
     if collcheck(x1,y1,w1,h1,x2,y2,w2,h2) then
      
      if player.life>0 then
	      if player.pow==1 or obj.bultype==2
	      then
	       this.life-=2
	      else
	       this.life-=1
	      end
      end
     
      if this.life<=0 then
       if this.typ.die!=-1 then
        this.typ.die(this)
       else
        enemy.die(this)
       end
       
      else
       addpart(obj.x,obj.y,0,0,34-obj.bultype*6.5,0.25)
       this.flash=4
       sfx(11)
      end
      
      del(bullets,obj)
     
     end--end if(collcheck)
    
    end
    
   end
  end--end of bullet  collision check
  
  --collision with player
  if collcheck(x1,y1,h1,w1,xp,yp,wp,hp) then
   player:hit()
  end
 
 end,
 
 draw=function(this)
 
  if this.flash>0 then
   sprcol(7)
   this.flash-=1
  end
  
  this.typ.draw(this)
  pal()
 end 
 }

--bat
bat={
 hitbox={x=2,y=2,w=4,h=4},
 
 die=-1,
 
 pts=5,

 init=function(this)
  this.flash=-1
  this.life=1
  this.y0=this.y
  this.anim=(this.x/2)%32
  this.animmax=32
 end,
 
 update=function(this)
  this.y=this.y0+3*(cos(this.anim/32))
  this.x-=camspd
  if(this.x<-8) then
   del(enemies,this)
  end
 end,
 
 draw=function(this)
  spr(48+(this.anim/4)%2,this.x,this.y)
 end
 }

--frog
frog={
 hitbox={x=1,y=1,w=6,h=6},
 
 die=-1,
 
 pts=10,
 
 init=function(this)
  this.flash=0
  this.life=2
  this.anim=-1
  this.y0=this.y
  this.t=flr(rnd(90))
  
  --floor detection
  local i
  i=this.y/8
  while fget(mget((this.x+camx)/8,i+16*lvl),0)==false do
   i+=1
  end
  
  this.y0=i*8-8
  
 end,
 
 update=function(this)
  local shoot=false
  
  this.x-=camspd
  this.t=(this.t-1)%90
  if this.t>30 then
   this.y=this.y0+64*sin((this.t-30)/120)
  else
   this.y=this.y0
  end
  
  --collision with ceiling
  if this.t>60 and collmap(this,frog.hitbox) then
   this.t=60-(this.t-60)
   shoot=true
  end
  
  --shoot
  if this.t==60 or shoot then
   movetowards(addbullet(this.x-4,this.y,0,0,1),player.x+4,player.y+4,2)
   shoot=false
  end
  
  if this.x<-8 then
   del(enemies,this)
  end
  
 end,
 
 draw=function(this)
  local img=0
  if(this.t>30) then img=1 end
  
  transcol(1)
  
  spr(50+img,this.x,this.y)
  pal()
 end
 }

caul={
 hitbox={x=0,y=0,w=8,h=8},
 
 die=-1,
 
 pts=10,
 
 init=function(this)
  this.anim=0
  this.animmax=8
  this.life=5
  this.flash=0
  this.t=0
  
  --floor detection
  local i=this.y/8
  while fget(mget((this.x+camx)/8,i+16*lvl),0)==false do
   i+=1
  end
  
  this.y=i*8-8
  
 end,
 
 update=function(this)
  this.t=(this.t-1)%20
  this.x-=camspd
  
  --shoot
  if this.t==0 then
   local t,rdir
   t=addenemy(this.x,this.y-4,fire)
   rdir=0.125+rnd(0.25)
   t.hspd=-camspd+2*cos(rdir)
   t.vspd=2*sin(rdir)
  end
 end,
 
 draw=function(this)
 
  if this.anim>=4 then
   pal(8,1)
   pal(9,8)
   pal(10,9)
  end
  
  spr(52,this.x,this.y)
 end
 }

fire={
 hitbox={x=1,y=1,w=6,h=6},
 
 init=function(this)
  this.flash=-1
  this.life=-1
  this.anim=0
  this.animmax=8
 end,
 
 update=function(this)
  this.x+=this.hspd
  this.y+=this.vspd
  
  if collmap(this,fire.hitbox) or not collcheck(this.x,this.y,8,8,0,0,128,128) then
   del(enemies,this)
  end
 end,
 
 draw=function(this)
  spr(53+this.anim/4,this.x,this.y)
 end
 }

ghost={
 hitbox={x=1,y=1,w=5,h=6},
 
 die=-1,
 
 pts=5,
 
 init=function(this)
  this.life=1
  this.flash=-1
  this.anim=-1
  this.hspd=-camspd
  this.vspd=2*sgn(64-this.y)
 end,
 
 update=function(this)
  this.x+=this.hspd
  this.y+=this.vspd
  
  if this.vspd<0 and this.y<player.y+4
   or this.vspd>0 and this.y>player.y+4 then
   this.vspd=0
   this.hspd=-3*max(1,camspd)
  end
  
  if this.x<-8 then
   del(enemies,this)
  end
  
 end,
 
 draw=function(this)
  spr(55,this.x,this.y)
 end
 }

squid={
 hitbox={x=1,y=1,w=6,h=6},
 
 die=-1,
 
 pts=10,
 
 init=function(this)
  this.flash=0
  this.life=2
  this.anim=0
  this.animmax=32
  this.hspd=-camspd
  this.y+=64
  this.shot=false
 end,
 
 update=function(this)
  this.x-=camspd
  this.y-=(32-this.anim)/16
  
  if this.x<-8 or this.y<-8 then
   del(enemies,this)
  end
  
  if this.y<48 and not this.shot then
   movetowards(addbullet(this.x,this.y,0,0,1),player.x+4,player.y+4,2)
   this.shot=true
  end
 end,
 
 draw=function(this)
  spr(57-flr(this.anim/24),this.x,this.y)
 end
 }

fish=
 {
 hitbox={x=0,y=2,w=8,h=5},
 
 die=-1,
 
 pts=5,
 
 init=function(this)
  this.flash=-1
  this.life=1
  this.anim=-1
  this.vspd=0
  this.y0=this.y
  this.y=this.y0+rnd(water-12-this.y0)
  this.vspd=sqrt(this.y-this.y0)*0.6
 end,
 
 update=function(this)
  this.vspd+=0.2
  this.x-=2+camspd
  this.y+=this.vspd
  
  if this.y>=water-12 and this.vspd>0 then
   this.y-=this.vspd
   this.vspd=-this.vspd
  end
 end,
 
 draw=function(this)
  transcol(1)
  spr(58.5+0.5*sgn(this.vspd),this.x,this.y)
  pal()
 end
 }

urchin={
 hitbox={x=1,y=1,w=6,h=6},
 
 init=function(this)
  this.life=-1
  this.flash=-1
  this.anim=-1
 end,
 
 update=function(this)
  this.x-=camspd
  this.y=water-6
  if this.x<-8 then
   del(enemies,this)
  end
 end,
 
 draw=function(this)
  spr(60,this.x,this.y)
 end
 }

ship={
 hitbox={x=1,y=1,w=6,h=6},
 
 die=-1,
 
 pts=30,
 
 init=function(this)
  this.life=12
  this.flash=0
  this.anim=-1
 end,
 
 update=function(this)
  this.x-=camspd-0.5
  this.y=water-12
  if this.x<-8 then
   del(enemies,this)
  end
  
  if lvlx%4==0 then
   movetowards(addbullet(this.x,this.y,0,0,1),player.x+4,player.y+4,2)
  end
 end,
 
 draw=function(this)
  spr(61,this.x,this.y+0.5+sin(lvlx/4))
 end
 }

torpedo={

 hitbox={x=0,y=1,w=7,h=5},
 
 die=-1,

 init=function(this)
  this.anim=-1
  this.life=2
  this.flash=0
  this.hspd=0
  this.vspd=0
 end,
 
 update=function(this)
  this.hspd-=0.1
  this.vspd-=0.2*this.hspd*sgn(player.y-this.y+4)
  this.vspd=clamp(this.vspd,0.2*this.hspd,-0.2*this.hspd)
  this.x+=this.hspd
  this.y+=this.vspd
  if this.x<-8 then
   del(enemies,this)
  end
 end,
 
 draw=function(this)
  transcol(1)
  spr(62,this.x,this.y)
  pal()
 end
 }

spike={
 hitbox={x=1,y=1,w=5,h=5},
 
 init=function(this)
  this.life=-1
  this.flash=-1
  this.anim=-1
  this.vspd=-1
  if this.y<64 then
   this.vspd=1
  end
 end,
 
 update=function(this)
  this.x-=camspd
  this.y+=this.vspd
  if collmap(this,spike.hitbox)
  or this.y<0 or this.y>water-8
  or this.y>120 then
   this.y-=this.vspd
   this.vspd=-this.vspd
  end
 end,
 
 draw=function(this)
  spr(63,this.x,this.y)
 end
 }

lavaball={
 hitbox={x=2,y=2,w=13,h=13},
 
 init=function(this)
  this.life=-1
  this.anim=0
  this.animmax=30
  this.flash=-1
  this.height=water-8-this.y
  this.y=water+4+rnd(8)
  this.vspd=-0.5
 end,
 
 update=function(this)
  this.x-=camspd
  this.y+=this.vspd
  
  if this.vspd!=0 and this.y<=water-8 then
   this.vspd=0
   this.anim=0
  end
  
  if this.y<=water-8 then
   this.y=water-8+this.height*sin(this.anim*0.25/30)
   
   --explode
   if this.anim>=29 then
    local i,s,c,t
    for i=0,7 do
     s=sin(0.125*i)
     c=cos(0.125*i)
     t=addenemy(this.x+4+4*c,this.y+4+4*s,fire)
     t.hspd=2*c-camspd
     t.vspd=2*s
    end
    
    del(enemies,this)
    
    sfx(10)
   end
   
  end
  
 end,
 
 draw=function(this)
  pal(6,9)
  pal(5,8)
  drawmoon(this.x,this.y)
  pal()
 end
 }

witch={
 hitbox={x=2,y=0,w=3,h=7},
 
 die=-1,
 
 pts=30,
 
 init=function(this)
  this.life=5
  this.anim=0
  this.animmax=32
  this.flash=-1
  this.vspd=1-2*flr(rnd(2))
  this.y0=this.y
 end,
 
 update=function(this)
  this.x-=camspd/2
  this.y+=this.vspd
  
  --bullets
  if this.anim>24 and this.anim%2==0 then
   movetowards(addbullet(this.x-4,this.y,0,0,1),player.x+4,player.y+4,3)
  end
  
  --revert vertical speed
  if this.y<0 or this.y>120 or abs(this.y-this.y0)>16 then
   this.y-=this.vspd
   this.vspd=-this.vspd
  end
  
  --outside the screen
  if this.x<-8 then
   del(enemies,this)
  end
  
 end,
 
 draw=function(this)
  spr(43,this.x,this.y)
 end
 }

dragon={
 hitbox={x=1,y=1,w=5,h=5},
 
 die=-1,
 
 pts=5,
 
 init=function(this)
  this.balls=false
  this.btype=0
  this.y0=this.y
  this.anim=-1
  this.flash=0
  this.life=2
  this.offset=rnd(1)
 end,
 
 update=function(this)
  
  --create balls
  if not this.balls and this.btype==0 then
   local i,t
   
   --head is invincible
   this.life=-1
   
   --add balls
   for i=0,11 do
    t=addenemy(this.x+6+4*i,this.y,dragon)
    t.btype=1
    t.offset=this.offset
   end
   
   this.balls=true
   
  end
  
  this.x-=1+max(1,camspd)
  this.y=this.y0+16*sin(this.x/100+this.offset)
 end,
 
 draw=function(this)
  transcol(1)
  spr(44+this.btype,this.x,this.y)
  pal()
 end
 }

bubble={
	hitbox={x=2,y=2,w=12,h=12},
	
	die=-1,
	
	pts=30,
	
	init=function(this)
	 this.life=10
	 this.anim=flr(rnd(120))
	 this.animmax=120
	 this.y0=this.y
	 this.flash=0
	 this.angle=0
 end,
	
	update=function(this)
	 --move left
	 this.x-=camspd/2
	
	 --float
	 this.y=this.y0+16*sin(this.anim/60)
	 
	 --rotation
	 this.angle=this.anim/30
	 
	 --outside the screen
  if this.x<-16 then
   del(enemies,this)
  end
	 
	 --bullets
	 if this.anim%40==10 then
	  local i,a,c,s
	  for i=0,3 do
	   a=i/4+this.angle
	   c=cos(a)
	   s=sin(a)
	   addbullet(this.x+4+4*c,
	             this.y+4+4*s,
	             1.5*c-camspd,
	             1.5*s,
	             1)
	  end
	 end
	
	end,
	
	draw=function(this)
	 local i
	 
	 for i=0,3 do
	  spr(5+flr(this.anim/4)%2,
	  this.x+4+4*cos(i/4+this.angle),
	  this.y+4+4*sin(i/4+this.angle))
	 end
	 
	end
	
	}
-->8
--bosses
boss={

 die=function(this)
  this.flash+=this.t%2
  
  --explosions
  if this.t%5==0 then
   sfx(10)
   addpart(this.x-4+rnd(16),this.y-4+rnd(16),0,0,36,0.375)
  end
  
  --start level outro
  if this.t<-60 then
   --boss disappears
   del(enemies,this)
   
   --score
   score+=2000
   
   --begin outro
   lvlcomp=true
   
   --remove hud life bar
   bosslife=-1
   bosslifemax=-1
  end
 end,

 update=function(this)
  
  --timer
  this.t-=1
  
  --hud life bar
  bosslife=this.life
  
  --boss intro
  if this.life>-2 then
  
   --move into the screen
   if this.t<0 then
   
    if this._spr==11 then
     --frog boss moves upwards
     this.y-=0.5
     if this.y==80 then
      beginbattle(this)
     end
     
    else
     --other bosses move left
		   this.x-=1
		   if this.x==104 then
		    beginbattle(this)
		   end
	   end
	   
	  else
		  
		  --change attacks
		  if this.t==0 then
		   this.atk=(this.atk+1)%this.atkmax
		   this.t=this.tmax
		  end
		  
		  --main attack code
		  this.atkf[this.atk+1](this)
		  
		  --defeated
		  if this.life<=0 and this.t>0 then
		   this.t=-1
		   this.life=-2
		   --fade out music
		   music(-1,1000)
		   
		   --player is invincible
		   player.hurt=120
		  end
	   
   end
   
  else
   --defeat animation
   boss.die(this)
  end
  
 end,
 
 draw=function(this)
  
  --final boss has its
  --own draw code 
  if lvl<3 then
 
	  spr(this._spr,this.x,this.y,2,2)
	  pal()
	  
  end
	 
	 --level outro
  if this.life<-1 then
   local dx=max(0,80+this.t*3)
   printcnt("stage "..lvl+1,64+dx,60,7)
   printcnt("clear",64+dx,68,7)
  end
  
 end
 }

bghost={
 hitbox={x=1,y=1,w=14,h=14},
 
 die=function(this)
  boss.die(this)
 end,
 
 init=function(this)
  this.x=160
  this.y=56
  this.life=-1
  this.lifemax=100
  this.flash=0
  this.atk=-1
  this.atkmax=2
  this.t=-1
  this.tmax=120
  this.anim=-1
  this._spr=7
  
  this.atkf={}
  
  this.atkf[1]=function(this)
	  --attack 1
	  this.y=56+40*sin(this.t/60)
	  if this.t%20==10 then
	   addbullet(this.x-4,this.y+4,-4,0,1)
	  end
  end
  
  this.atkf[2]=function(this)
	  --attack 2
	  if this.t%40==35 then
	   local i,y0
	   y0=2*flr(rnd(2))-1
	   
	   --spawn ghosts
	   for i=0,4 do
	    addenemy(32+22*(this.t-20)/40,60+y0*(68+i*12),ghost)
	   end
	  end
	  
	  --bullets
	  if this.t%45==40 then
	   movetowards(addbullet(this.x-4,this.y+4,0,0,1),player.x+4,player.y+4,1)
	  end
  end
  
 end,
 
 update=function(this)
  boss.update(this)
 end,
 
 draw=function(this)
  boss.draw(this)
 end
 }

bship={
 
 hitbox={x=1,y=1,w=14,h=14},
 
 die=function(this)
  boss.die(this)
 end,
 
 init=function(this)
  this.x=160
  this.y=48
  this.life=-1
  this.lifemax=175
  this.flash=0
  this.atk=-1
  this.atkmax=1
  this.t=-1
  this.tmax=200
  this.anim=-1
  this._spr=9
  
  this.atkf={}
  
  this.atkf[1]=function(this)
   water=64+48*sin(this.t/200)
   this.y=water-20+0.5+2*sin(this.t/40)
   
   local i
   
   --each attack happens 5 times
   for i=-2,2 do
    
    --bullets
	   if this.t==1+(199+i*20)%200 then
	    addbullet(this.x,this.y+8,-3,0,1)
	    addbullet(this.x,this.y+6,-3,-1.5,1)
	    addbullet(this.x,this.y+4,-3,-3,1)
	   end
	   
	   --torpedoes
	   if this.t==100+i*20 then
	    addenemy(this.x+4,this.y+16,torpedo)
	   end
   end
   
   --spawn squids
   if this.t==150 then
    for i=0,2 do
     addenemy(32+24*i,128+flr(rnd(32)),squid)
    end
   end
   
  end
 
 end,
 
 update=function(this)
  
  if this.t<0 and this.life>-2 then
   water=min(64,water+0.5)
   this.y=water-20
  end
  
  boss.update(this)
 end,
 
 draw=function(this)
  boss.draw(this)
 end
 }

bfrog={
 
 hitbox={x=0,y=3,w=31,h=28},
 
 die=function(this)
  boss.die(this)
 end,
 
 init=function(this)  
  this.x=48
  this.y=128
  this.life=-1
  this.lifemax=150
  this.flash=0
  this.atk=-1
  this.atkmax=2
  this.t=-1
  this.tmax=180
  this.anim=-1
  this._spr=11
  
  this.atkf={}
  
  this.atkf[1]=function(this)
   --move left and right
   this.x=48+44*sin(this.t/90)
   this.y=80
   
   --bullets
   if this.t%15==7 then
    addbullet(this.x+8,this.y,-1,-2,1)
    addbullet(this.x+16,this.y,1,-2,1)
   end
  end
  
  this.atkf[2]=function(this)
   --move down then up
   this.x=48
   this.y+=0.5*sgn(this.t-90)
   
   if this.t==130 then
    local i
    
    --spawn 3 lava balls
    for i=-0.5,1.5 do
     addenemy(56+i*24,16+rnd(32),lavaball)
    end
    
   end
  end
  
 end,
 
 update=function(this)
  if water<96 then
   water+=0.5
  end
  
  boss.update(this)
 end,
 
 draw=function(this)
  palt(0,false)
  palt(1,true)
  spr(11,this.x,this.y,2,2)
  spr(11,this.x+16,this.y,2,2,true,false)
  boss.draw(this)
 end
 }
 
bwitch={
 
 hitbox={x=-4,y=-4,w=23,h=23},
 
 die=function(this)
  --save position for ending
  lvlcompx=this.x
  lvlcompy=this.y
  boss.die(this)
 end,
 
 init=function(this)
  this.x=160
  this.y=56
  this.anim=0
  this.animmax=32
  this.life=-1
  this.lifemax=200
  this.flash=0
  this._spr=0
  this.atk=-1
  this.atkmax=3
  this.t=-1
  this.tmax=240
  
  this.atkf={}
  
  local i
  
  --attack 1
  this.atkf[1]=function(this)
	  this.y=56+48*sin(this.t/80)
	  
	  if this.t%15==5 then
	   
	   for i=0.5,7.5 do
	    addbullet(this.x+4+16*cos(i/8)
	             ,this.y+4+16*sin(i/8)
	             ,-4,0,1)
	   end
	  end
	  
  end
  
  --attack 2
  this.atkf[2]=function(this)
   this.x=56+48*cos(this.t/80)
   
   if this.t%180<60 then
    this.y-=1
   else
    this.y+=1
   end
   
   --spawn dragon
   if this.t%120==60 then
    addenemy(128,16+rnd(88),dragon)
   end
   
  end
  
  --attack 3
  this.atkf[3]=function(this)
   if this.t%11==1 and this.t>60 then
    
    local bhspd,bvspd
    
    for i=0,7 do
     bhspd=cos(this.anim/64+i/8)
     bvspd=sin(this.anim/64+i/8)
     
     addbullet(this.x+4+16*bhspd,this.y+4+16*bvspd,bhspd*0.75,bvspd*0.75,1)
    end
    
   end
  
  end
  
  
 end,
 
 update=function(this)
  boss.update(this)
 end,
 
 draw=function(this)
 
  local i=2*flr(this.anim%2)
  local y2=this.y+flr(cos(this.anim/32)+0.5)
  
  if this.flash<1 then
   pal(1,0)
   pal(2,1)
   pal(15,7)
   pal(8,1)
  end  
  
  drawwitch(this.x,this.y,-1,this.anim/4,0)
  
  transcol(1)
  
  --skulls
  for i=0,7 do
   spr(46,this.x+4+16*cos(this.anim/64+i/8)
         ,this.y+4+16*sin(this.anim/64+i/8))
  end
  
  pal()
  
  boss.draw(this)
 end
 }
-->8
--items

item={

 update=function(this)
  this.x-=camspd
  
  if this.x<-8 then
   del(items,this)
  end
  
  this.anim=(this.anim+0.125)%8
  
  if collcheck(this.x+1,this.y+2,6,4,xp,yp,wp,hp) then
   player.pow=this.pow+1
   player.powtimer=180
   del(items,this)
   
   sfx(12)
  end
 end,
 
 draw=function(this)
  if this.anim%4>3 then
   sprcol(7)
  end
  spr(39+this.pow,this.x,this.y+flr(0.5+sin(this.anim/4)))
  pal()
 end
 
 }
-->8
--_init
function _init()
 
 --maximum hp
 lifemax=5
 
 --init player and metatables
 --player:init()
 bullets={}
 parts={}
 enemies={}
 items={}
 
 --camera
 camx=0
 camspd=0
 
 --level
 lvl=0
 lvlx=0
 sublvl=0
 
 --score
 score=0
 multiplier=1
 scoretimer=0
 
 --level transitions
 lvlcomp=false
 lvlcompx=0
 lvlcompy=0
 
 --water height
 water=136
 
 --number of lives
 lives=3
 livesmax=3
 
 --death count
 deaths=0
 
 --ending info
 endanim=0
 
 --title screen and ending
 screen=0
 
 --menu choice
 choice=1
 
 --copy of player coordinates
 xp=0
 yp=0
 wp=6
 hp=8
 
 --hud boss life bar
 bosslife=-1
 bosslifemax=-1
 
 --enemy type lookup table
 etype={
  id={48,50,52,56,58,60,61,63,
     16,43,44,5},
  typ={bat,frog,caul,squid,fish,
      urchin,ship,spike,
      lavaball,witch,dragon,
      bubble}
 }
 
 
end
-->8
--_update
function _update()

 --title screen
 if screen==0 then
  
  endanim=(endanim+1)%256
  
  if btnp(2) then
   choice=(choice-1)%3
  end
  
  if btnp(3) then
   choice=(choice+1)%3
  end
  
  if btnp(4) or btnp(5) then
   
   if choice==0 then
    livesmax=-1
   elseif choice==1 then
    livesmax=3
   else
    livesmax=1
   end
   
   sfx(12)
   
   screen=1
   
   lives=livesmax
   player:init()
   
   endanim=0
   
  end
 else
 
  --update game
  
  --update player
	 player:update()
	 
	 --score multiplier
	 if scoretimer>0 then
	  scoretimer-=1
	 else
	  multiplier=10
	 end
	 
	 --update bullets
	 foreach(bullets,bullet.update)
	 
	 --update enemies
	 foreach(enemies,enemy.update)
	 
	 --update items
	 foreach(items,item.update)
	
	 --update particles
	 foreach(parts,part.update)
	 
	 --read map for objects
	 local i,j,m,t,mx,my,addy
	 
	 for i=0,15 do
	  mx=min(127,flr(lvlx/3))
	  my=lvl*16+i
	  m=mget(mx,my)
	  addy=8*i
	  
	  --lookup table
	  for j=1,count(etype.id) do
	   if m==etype.id[j] then
	    addenemy(128,addy,etype.typ[j])
	    mset(mx,my,0)
	   end
	  end
	  
	  --add 5 bats
	  if m==49 then
	   for j=0,4 do
	    addenemy(128+j*12,addy,bat)
	   end
	  mset(mx,my,0)
	  end
	  
	  --add ghosts
	  if m==55 then
		  local gdir
		  if i>7 then
		   gdir=1
		  else
		   gdir=-1
		  end
		  
		  for j=0,4 do
		   addenemy(128,60+gdir*(68+j*12),ghost)
		  end
		  
		  mset(mx,my,0)
	  end
	  
	  --add items
	  if m==39 or m==40 then
	   local t={x=128,y=8*i,anim=0}
	   t.pow=m-39
	   add(items,t)
	   mset(mx,my,0)
	  end
	 
	 end--end of enemy placement
	 
	 --move camera to the right
	 lvlx+=min(1,camspd)/8
	 
	 camx+=camspd
	 
	 --level sections
	 if sublvl==0 then
	  camx%=256
	  if lvlx>128 then
	   sublvl=1
	  end
	 end
	 
	 if sublvl==1 and camx>512 then
	  sublvl=2
	 end
	 
	 if sublvl==2 then
	  camx=512+(camx-512)%256
	  if lvlx>280 then
	   sublvl=3
	  end
	 end
	 
	 if sublvl==3 and camx>=896 then
	  sublvl=4
	 end
	 
	 if sublvl==4 then
	  camx=896
	 end
	 
	 --level music fades out
	 if lvlx==372 then
	  music(-1,1000)
	 end
	 
	 --boss music fades in
	 if lvlx==378 then
	  music(34,1000)
	 end
	 
	 --begin boss battle
	 if camspd>0 and lvlx>=381 then
	  local lvlboss={bghost,bship,bfrog,bwitch}
	  --stop camera
	  camspd=0
	  --spawn boss
	  addenemy(0,0,lvlboss[lvl+1])
	 end
	 
	 --water
	 if lvl==1 then
	  --level 2
	  if lvlx<72 then
	   water=112
	  elseif lvlx<=88 then
	   water=clamp(112-lvlx+72,96,112)
	  elseif lvlx<=152 then
	   water=clamp(96-lvlx+120,64,96)
	  elseif lvlx<=242 then
	   water=clamp(64+2*lvlx-420,64,96)
	  elseif lvlx<=300 then
	   water=clamp(96-2*lvlx+504,64,96)
	  elseif lvlx<381 then
	   water=64+32*sin(lvlx/20)
	  end
	 elseif lvl==2 then
	  --level 3
	  if lvlx<180 then 
	   water=112
	  elseif lvlx<=192 then
	   water=clamp(112-3*lvlx+540,80,112)
	  elseif lvlx<=272 then
	   water=clamp(80+2*lvlx-464,80,112)
	  elseif lvlx<=312 then
	   water=clamp(112-2*lvlx+576,80,112)
	  end
	  
	 else
	  --levels 1 and 4 (no water)
	  water=136
	 end
	 
	 --level 4 speed increase
	 if lvl==3 and lvlx==177 then
	  camspd=2
	 end
	 
	 --push player back
	 while collmap(player) do
	  player.x-=1
	 end
	 
	 --player crushed
	 if player.move and player.x<-player.hitbox.x then
	  player.life=1
	  player.hurt=0
	  player:hit()
	 end
	 
	 --lava damage
	 if lvl==2 and yp+hp>=water then
	  player:hit()
	 end
	 
	 --level intro
	 if screen==1 and camspd==0 
	 and lvlx==0 then
	 
	  player.x+=0.1*(24-player.x)
	  if player.x>=16 then
	   camspd=1
	   player.move=true
	   player.x=flr(player.x)
	  end
	  
	 end
	 
	 --level outro
	 if lvlcomp then
	 
	  player.move=false
	  
	  if lvl<3 then
	   --level to level transition
	   
	   if lvlcompx==0 then
	    lvlcompx=player.x
	   end
	   
		  player.x+=max(0.5,0.1*(player.x-lvlcompx))
		  
		  --go to next level
		  if player.x-lvlcompx>128 then
		   
		   enemies={}
		   bullets={}
		   lvlx=0
		   camx=0
		   lvl+=1
		   sublvl=0
		   lvlcomp=false
		   lvlcompx=0
		   lives=livesmax
		   player:init()
		   
		  end
	  
	  end 
	    
	  
	 end --end of level outro
 
 end --end of main game update
   
end
-->8
--_draw
function _draw()
 
 rectfill(0,0,128,128,0)
 
 local i
 
 if lvl==0 then
  --level 1 background
  
  if lvlx<180 then
	  
	  rectfill(0,0,128,27,1)
	  
	  --draw moon
	  drawmoon(104,8)
	  
	  rectfill(0,36,128,128,0)
	  
	  --draw clouds
	  for i=0,8 do
	   spr(70,-(lvlx*2%16)+i*16,28,2,1)
	  end

   rectfill(128-max(0,camx-284),0,128,128,0)
	  
	 else
	  --cavern background
	  
	  for i=0,2 do
	   spr(86,-(lvlx*3%72+16)+i*72,12,2,2)
	   spr(86,-((lvlx*3+36)%72+16)+i*72,100,2,2,false,true)
	   spr(118,-(lvlx*2%68+8)+i*68,36)
	   spr(118,-((lvlx*2+34)%68+8)+i*68,84,1,1,false,true)
	  end
	  
	 end

 elseif  lvl==1 then
  --level 2 background
  local wy=28+(112-water)/3
  
  rectfill(0,0,128,wy,1)
  
  rectfill(0,26,128,64,2)
  line(0,27,128,27,1)
  rectfill(0,40,128,64,8)
  line(0,41,128,41,2)
  
  rectfill(0,wy+8,128,128,0)
  
  drawmoon(104,8)
  
  pal(0,1)
  palt(1,true)
  sprcol(0)
  
  for i=0,16 do
   spr(119,i*8-(lvlx*3)%8,wy)
  end
  
  pal()

 elseif lvl==2 then
  --level 3 background
  local j
  
  --small pillars
  for i=0,3 do
   
	  for j=0,5 do
	   spr(98,-(lvlx*2%48+8)+i*48,
	       40+j*8,1,1)
	  end
	  
	 end
	 
	 --large pillars
	 for i=0,2 do
	  
	  pal(1,0)
	  pal(2,1)
	  
	  for j=0,9 do
	  
	   if j>=water/8-8 then
	    pal()
	   end
	  
	   if j>=water/8-6 then
	    pal(1,2)
	    pal(2,8)
	   end
	   
	   transcol(7)
	   
	   spr(99,-(lvlx*4%72)+i*72,
	       24+j*8,2,1)
	  end
	  
	  pal()
  
  end
 
 else
  --level 4 background
  
  --palette gradients
  local colors={
   {0,1,2,13,12},
   {1,2,5,3,13},
   {1,2,5,3,14},
   {2,5,3,14,15}
  }
  
  local colid=flr(clamp(lvlx-168,1,5))
  
  rectfill(0,0,128,128,colors[1][colid])
  
  --color gradients
  rectfill(0,0,128,9,colors[4][colid])
  rectfill(0,10,128,19,colors[3][colid])
  line(0,11,128,11,colors[4][colid])
  line(0,21,128,21,colors[3][colid])
  
  rectfill(0,117,128,128,colors[2][colid])
  line(0,115,128,115,colors[2][colid])
  
  --clouds
  pal(13,colors[2][colid])
  
  local dx
  
  for j=0,1 do
  
	  for i=0,2 do
	   dx=-(lvlx*3%96+48*j)+i*96

    spr(13,dx,24+64*j,3,2)
   end
   
  end
  
  pal()
  
 end
 
 --frog boss is behind the lava
 if lvl==2 then
  for obj in all(enemies) do
   if obj.typ==bfrog then
    enemy.draw(obj)
   end
  end
 end
 
 --draw water
 if lvl!=0 and water<136 then
  
  --lava in level 3
  if lvl==2 then
   pal(3,8)
   pal(12,9)
   pal(7,10)
  end
  
  for i=0,16 do
   spr(119,-(lvlx*6%8)+8*i,water-8)
   rectfill(0,water,128,128,3)
  end
  
  pal()
 end
 
 local cx=-(camx%8)
 
 --draw map
 map(camx/8,lvl*16,cx,0,17,16,1)
 
 --draw scenery
 map(camx/8,lvl*16,cx,0,17,16,4)
 
 --
 --title screen and main menu
 --
 
 if screen==0 then
 	
 	local menutxt={"casual",
 	               "normal",
 	               "hard"}
  local menuspr={41,47,46}
  local menucol
  local menucred={"flytrap studios",
                  "♪ dustin van wyk"}
 	
 	--print difficulty options
 	for i=1,3 do
 	 if choice==i-1 then
 	  menucol=7
 	 else
 	  menucol=6
 	 end
 	 
 	 printcnt(menutxt[i],64,72+8*i,menucol)
 	 
 	end --end of for loop
 	
 	if choice==2 then
 	 transcol(1)
 	end
 	
		for i=-1,1,2 do
		 spr(menuspr[choice+1],60+20*i,76+8*choice,1,1,i<0,false)
		end
		
		pal()
		
		--title logo
		local dy2=0.5+2*sin(endanim/64+0.125)
		
		--"loves"
		palt(12,true)
		palt(13,true)
		palt(1,true)
		palt(4,true)
		palt(9,true)
		palt(10,true)
		spr(90,40,40+dy2,6,2)
		pal()
		
		--"witch"
		palt(14,true)
		palt(8,true)
		spr(74,40,32+0.5+2*sin(endanim/64),6,2)
		
		--"bullets"
		spr(106,40,48+0.5+2*sin(endanim/64+0.25),6,2)
		pal()
		
		--hearts
		spr(41+(endanim/8)%2,30,60+dy2)
		spr(42-flr(endanim/8)%2,92,28+dy2)
		
		--witch
		sprcol(0)
		drawwitch(192-endanim,8,-1,endanim/4,0)
		pal()
		
		--credits
		printcnt(menucred[1+flr(endanim/64)%2],64,124,7)
		print("1.1",116,122,6)
 	
 	
 end --end of title screen
 
 
 --
 --player, in-game objects, hud
 --
 
 if screen==1 then
 
	 --draw player 
	 player:draw()
	 
	 --draw bullets
	 foreach(bullets,bullet.draw)
	 
	 --draw enemies
	 for obj in all(enemies) do
	  
	  --frog boss isn't drawn now
	  if obj.typ!=bfrog then
	   enemy.draw(obj)
	  end
	  
	 end
	 
	 --draw items
	 foreach(items,item.draw)
	 
	 --draw particles
	 foreach(parts,part.draw)
	 
	 --
	 --draw hud
	 --
	 
	 --level 1 tutorial
	 if lvl==0 and lvlx<21
	 and camspd>0
	 and flr(lvlx/2)%2==0 then
   printcnt("press 🅾️",88,12,7)
   spr(33,84,18)
	  printcnt("press ❎",40,12,7)
   spr(5,36,18)
	 end
	 
	 --hearts
	 for i=0,lifemax-1 do
	  if i>=player.life then
	   pal(8,0)
	  end
	  
	  spr(42,6*i,0)
	 end
	 
	 pal()
	 
	 --draw lives
	 if lives>0 then
	  spr(47,0,7)
	  print(lives,10,9,7)
	  pal()
	 end
	 
	 --score
	 print(score,128-4*#tostr(score),
	          1,7)
	 for i=#tostr(score)+1,6 do
	  print(0,128-4*i,1)
	 end
	 
	 if multiplier>10 then
	  print("x"..multiplier/10,
	        124-4*#tostr(multiplier/10),
	        7,
	        5+3*flr(multiplier/50)+3*scoretimer/45.1)
	 end
	 
	 --boss life bar
	 if bosslife>-1 then
	  rectfill(14,124,14+bosslife/bosslifemax*100,125,12)
	 end
	 
	 --level intro
	 if lvlx<9 then
	  local dy=16*max(lvlx-7,0)^2+(16-player.x)*(1-camspd)
	  printcnt("stage "..lvl+1,64,60-dy,7)
	  printcnt("start",64,68+dy,7)
	 end
	 
	 --level outro
	 if lvlcomp and lvl<3 and player.x-lvlcompx<32 then
	  printcnt("stage "..lvl+1,64,60,7)
	  printcnt("clear",64,68,7)
	 end
	 
	 --game over screen
	 if lives==0 and camspd==0 then
	  printcnt("game over",64,32,7)
	  printcnt("continue",64,88,7-choice)
	  printcnt("give up", 64,96,6+choice)
	  
	  if choice==1 then
	   transcol(1)
	  end
	  
	  for i=-1,1,2 do
	   spr(47-choice,60+20*i,84+8*choice,1,1,i<0,false)
	  end
	  
	  pal()
	  
	 end
	 
 end
 
 --ending
 if lvlcomp and lvl==3 then
  
  endanim+=1
  
  if screen==1 then
   
   --ending part 1
   
   local scale=-1
   
   --start ending music
   if endanim==120 then
    music(44)
   end
   
	  --update first
	  if endanim>120 then
	  
	   --player moves to the right
	   player.x+=2
	   
	   --other witch follows behind
	   if player.x>lvlcompx+8 then
	    lvlcompx+=2
	    scale=1
	   end
	  
	  end
   
   
   --draw afterwards
   
   --friendly witch
   pal(8,14)
	  drawwitch(lvlcompx,lvlcompy,scale,player.anim+2,0)
	  pal()
	  
	  --hearts
	  if endanim>=60 and endanim<90 then
	   spr(41,player.x+4,player.y-endanim/2+26)
	   spr(41,lvlcompx+4,lvlcompy-endanim/2+26)
	  end
	  
	  --transition to part 2
	  rectfill(916-4*endanim,0,129,128,0)
	  
	  --go to part 2
	  if endanim==229 then
	   screen=2
	   endanim=0
	  end
  
  else
   
   --ending part 2
   
   local endtxt={
    "♥congratulations♥",
    "game by matthieu le gallic",
    "♪ composed by dustin van wyk",
    "pico ♪ by matthieu le gallic",
    "score : "..score.."   deaths : "..deaths,
    "♥congratulations♥"
    }
   
   rectfill(0,0,128,128,13)
   
   rectfill(0,109,128,120,14)
   line(0,107,128,107,14)
   rectfill(0,121,128,128,15)
   line(0,119,128,119,15)
   
   --clouds
   pal(13,14)
   
   local j
   
   for i=0,3 do
    --drawing 2 clouds gives the
    --illusion of a bigger cloud
    for j=0,1 do
     spr(13,i*96-endanim%96-24-j*7,0,3,2)
    end
    spr(13,i*64-(endanim/2)%64-24,16,3,2)
    
   end
   
   drawwitch(44,52,1,endanim/4,0)
   pal(8,14)
   drawwitch(68,60,1,endanim/4+1,0)
   
   
   if endanim>32 then
    endanim=32+(endanim-32)%1920
    
    local textoffset=flr((endanim-32)/192)%5
        
    --draw text
	   for i=0,5 do
		
	    if (endanim-32)%192<128 then
	     --text doesn't move
	     printcnt(endtxt[i+1],64+128*(i-textoffset),92,7)
	    else
	     --scrolling text
	     local dx=2*((endanim-32)%192-128)
	     printcnt(endtxt[i+1],64+128*(i-textoffset)-dx,92,7)
	    end
	   
	   end
   end
   
   
   --transition from part 1
   rectfill(-1,0,128-4*endanim,128,0)
  
  end
 
 end
 

end