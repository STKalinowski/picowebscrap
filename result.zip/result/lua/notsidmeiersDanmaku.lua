-- not sid meier's danmaku 0.28
-- martin mauchauffee

-- todo: new boss message: dont
-- be scared, it's only the boss

-- todo: display a werkage
-- of ships after kill

-- todo: add a special sound
-- for red lazer

-- todo: assign sound fx to
-- specific channel

-- ============================
-- math

function nor(x,y)
 l=1/sqrt(x*x+y*y)
 return x*l,y*l end

function rot(x,y,r)
 c,s=cos(r),sin(r)
 return x*c-y*s,x*s+y*c end

function ang(x,y,u,v)
 atan2(v-y,x-u) end

function aim(x,y,u,v)
 r=atan2(u-x,v-y)
 return cos(r),sin(r) end

function dis(x,y,u,v)
 m,n=u-x,v-y
 return m*m+n*n end

-- ============================
-- data

-- x,y= position
-- u,v= direction
-- s= speed
-- t= rotate speed

-- a= active
-- !b= ship/cannon hp
-- !e= initial hp
-- !z= frame live counter
-- !c= bullet shooted
-- !r= base score when shooted

-- d,!e= frame delay,initial

-- g= next index of object
-- l= length of object list

-- !c= bullet count this frame
-- t= repeat x times

-- m= movement function
-- n= shape function
-- p= pattern function

-- i,j= object index
-- b= bullet object
-- q= shape object
-- p= pattern object
-- h= ship/cannon object

-- f= frame tile index
-- o= distance from cannon
-- !z= tile index incr

-- w= aim follow mode
-- xxx: not used for shoot?
-- !r= contiguous shoot mode

-- !d= show vessel colision

-- bullets,shapes,ships,beam,
-- particles,sprite particles,
-- back circle particle,
-- front circle particle,
-- score digits,best score
-- digits,hit combo digits,
-- local damage,boss cannons
bs,qs,hs,be,pp,sp,bp,fp,scos,
best,hitg,lo,bo,slow
={},{},{},{},{},{},{},{},{},{},
{},{},{},-1

-- some table current index and
-- maximum size...,
-- shape speed multiplyer,
-- shape count multiplyer,
-- ship hp multiplyer,
-- hit counter,message,
-- warning message
bs.g,bs.l,qs.g,qs.l,hs.g,hs.l,
be.g,be.l,bed,bee,bef,pp.g,pp.l,
sp.g,sp.l,bp.g,bp.l,fp.g,fp.l,
hitv,lo.g,lo.l,
err,poa,lea
=1,1024,1,16,1,16,1,16,0,2,0,1,8,
1,32,11,32,21,32,0,1,16,"",0,0

function next(t)
 t.g=t.g%t.l+1 end

function none()end

-- ============================
-- conductor helper

function bcount(c)
 local n=max(1,c)
 if(c%2!=n%2)n+=1
 return n end

-- ============================
-- bullet movements

function roundexpl(r,m)
local z,a=lez
return function(i,b)
 --err="z:"..(lez-z)
 local a=lez-z
 if a<m then
  b.u,b.v=rot(b.u,b.v,r)
 elseif a==m then
  b.u*=1.7
  b.v*=1.7
 else
  b.u*=1.01
  b.v*=1.01
 end
end
end

--function roundinf(i,b)
-- b.u*=1.04
 --b.v*=1.04
--end

-- ============================
-- ship movements

function cross(i,h)
 h.x+=h.u*h.s h.y+=h.v*h.s end

function retreat(i,h)
 h.v=mid(-0.1,h.v-0.05,-1)
 cross(i,h,ve) end

function curve(i,h)
 h.x+=h.u*h.s h.y+=h.v*h.s
 h.u,h.v=rot(h.u,h.v,h.t) end

function flee(i,h)
 dx=vex-h.x
 h.u=-dx*0.01 h.v+=0.03
 cross(i,h,ve) end

function target(i,h)
 x=vex
 if(h.u==0)h.u=0.2
 if(h.x>x+6)h.u=-abs(h.u)
 if(h.x<x-6)h.u=abs(h.u)
 cross(i,h) end

-- return vessel position to aim at
function vepos()
 if lpf then -- fixed
  local x,y=vex,vey
  return function()
   return x,y
  end
 elseif lpa then -- late position
  return function()
   local p=lp[(lp.i-3)%4+1]
   return p.x,p.y
  end
 else -- current position
  return function()
   return vex,vey
  end
 end
end

-- ============================
-- shape fire

function arc(
a,--0.5..0=circle,point
s)--spirale
local vepos=vepos()
return function(i,q,j,f)
 h=q.h
 m,n=h.u,h.v
 local x,y=vepos()
 local o=boss and 10 or 5
 if(q.w)m,n=aim(h.x,h.y,x,y)
 r=(((2*j)-1)/q.c-1)*a
 u,v=rot(m,n,r+(q.z*s))
 bx,by=h.x+u*o,h.y+v*o
 return true,bx,by,u*q.s,v*q.s end
end

-- ============================
-- level

function apply(t)
 if(#leh<1)return
 for i in all(leh)do
  if boss then
   h=bo[i]
  else
   h=hs[i]
  end
  if h and h.a then
   if t==5 or t==6 then
    h.t=h.t+0.006*(((t-4)*2)-3)
    h.m=curve
   --slower ship
   elseif t==7 then
    h.s-=0.25
   --stop ship
   elseif t==8 then
    h.s=0
   --faster ship
   elseif t==9 then
    if h.s==0 then
     h.s=0.5
    else
     h.s+=0.25
    end
   --movement ship
   elseif t==45 then
    h.m=retreat
   elseif t==46 then
    h.m=flee
   elseif t==47 then
    h.m=cross
   elseif t==62 then
    h.m=target
   --fire shape
   elseif t>=1 and t<=4 then
    local s=lebn
    if s==arc then
     s=s(leaa,leas)
    end
    fire(h,lec,led,let,s,
    lebm,lebs,lebf,lew)
    lebt=1
   end
   if t==46 or t==47 or t==63 or (t>=1 and t<=9) then
    lem=false
   end
  end
 end
 return true
end

--function findt()
-- for i=1,100 do
--  local x,y=(lea+i)%128,(lea+i)/128
--  if mget(x,y)==78 then
--   return flr(lea+i)
--  end
-- end
--end

function level()
 lea+=0.25
 if flr(lea)==lea then
  x,y=lea%128,lea/128
  t=mget(x,y)
  if t==111 then
   scene,vel,veb=upd,false,false
   anim=win()
   sfx(-2,0)
   for i=1,qs.l do
    qs[i].n=none
    qs[i].t=0
   end
  --boss waiting position
  elseif t==94 then
   if box~=bou
   or boy~=bov then
    lea-=1
   else
    for i=1,qs.l do
     qs[i].t=0
    end
 	 end
  --position and direction
  elseif t==40 then
   bou,bov,lex,ley,leu,lev
   =0,30,0,-18,0,1
  elseif t==41 then
   bou,bov,lex,ley,leu,lev
   =-25,30,-40,-18,0,1
  elseif t==42 then
   bou,bov,lex,ley,leu,lev
   =25,30,40,-18,0,1
  elseif t==43 then
   bou,bov,lex,ley,leu,lev
   =20,44,-70,-18,0.7,0.7
  elseif t==44 then
   bou,bov,lex,ley,leu,lev
   =-20,44,80,-18,-0.7,0.7
  elseif t==56 then
   bou,bov,lex,ley,leu,lev
   =30,34,-82,40,1.0,0
  elseif t==57 then
   bou,bov,lex,ley,leu,lev
   =-30,34,82,40,-1.0,0
  elseif t==58 then
   bou,bov,lex,ley,leu,lev
   =30,24,-82,20,1.0,0
  elseif t==59 then
   bou,bov,lex,ley,leu,lev
   =-30,24,82,20,-1.0,0
  --ship movement
  elseif t==47 then
   if(not apply(t))lesm=cross
  elseif t==46 then
   if(not apply(t))lesm=flee
  elseif t==62 then
   if(not apply(t))lesm=target
  elseif t==45 then
   apply(t)
  --ship rotation
  elseif t==5 then
   if not apply(t) then
    leu,lev=rot(leu,lev,-0.05)
   end
  elseif t==6 then
   if not apply(t) then
    leu,lev=rot(leu,lev,0.05)
   end
  --ship speed
  elseif t==7 then
   if boss then
    bos=0.25
   elseif not apply(t) then
    less=lel==7 and 0.85 or 0.75
   end
  elseif t==8 then
   if boss then
    bos=0.5
   elseif not apply(t) then
    less=lel==8 and 1.5 or 1
   end
  elseif t==9 then
   if boss then
    bos=1.5
   elseif not apply(t) then
    less=lel==9 and 2.5 or 2
   end
  --boss hp
  elseif t==79 then
   bom+=100
   bob+=100
   boi+=2
   boa=true
  --developer markers
  --elseif t==24 then
  -- for ii=1,1000 do
  --  local xx,yy=(lea+ii)%128,(lea+ii)/128
  --  if mget(xx,yy)==25 then
  --   lea=flr(lea+ii)
  --   break
  --  end
  -- end
  elseif t==26 then
   slow=1
  elseif t==27 then
   slow=-1
  --markers
  elseif t==78 then
   if lema==0 then
    lema,lec,led,let
    =lea,0,0,0
   else
    lerk=lea
    lea=lema
   end
  --hp, score, ship frame
  elseif t==131 or t==163 then
   leb,ler,lesf=5,550,t>159 and 163 or 131
  elseif t==147 or t==179 then
   leb,ler,lesf=7,800,t>159 and 163 or 131
  elseif t==130 or t==161 then
   leb,ler,lesf=12,1000,t>159 and 161 or 130
  elseif t==146 or t==177 then
   leb,ler,lesf=18,1500,t>159 and 161 or 130
  elseif t==129 or t==160 then
   leb,ler,lesf=30,3000,t>159 and 160 or 129
  elseif t==145 or t==176 then
   leb,ler,lesf=40,4000,t>159 and 160 or 129
  elseif t==128 or t==162 then
   leb,ler,lesf=70,8000,t>159 and 162 or 128
  elseif t==144 or t==178 then
   leb,ler,lesf=90,10000,t>159 and 162 or 128
  --boss arrive! distance from canon
  elseif t==127 then
   boss,wa,box,boy,bou,bov
   =true,1,0,-50,0,30
  --arc angle
  elseif t==28 then
   leaa=0.5
  elseif t==29 then
   leaa=0.25
  elseif t==30 then
   leaa=0.125
  elseif t==31 then
   leaa=0.0625
  --arc spirale
  elseif t==60 then
   leas-=0.01
  elseif t==61 then
   leas+=0.01
  --bullet movement
  elseif t==34 then
   lebm=none
  elseif t==16 then
   lebm=roundexpl(0.02,110)
  elseif t==17 then
   leas-=0.001
  elseif t==51 then
   lpa=true
  elseif t==90 then
   lpf=true
  --bullet frame, bullet speed
  elseif t==1 then
   lebf,lebs=1,1.5
   apply(t)
  elseif t==2 then
   lebf,lebs=2,3
   apply(t)
  elseif t==3 then
   lebf,lebs=3,4
   apply(t)
  elseif t==4 then
   lebf,lebs=4,2
   apply(t)
  --aim mode
  elseif t==33 then
   lew,lpa,lpf
   =false,false,false
  elseif t==49 then
   lew,lpa,lpf
   =true,false,false
  end
  --arc
  if t>=28 and t<=31 then
   lebn,leas=arc,0
  --cancel selection
  elseif t==0 then
   lem,leh=false,{}
  --multiple selection
  elseif t==63 then
   lem=true
  --select spawned ship
  elseif t>=10 and t<=15 then
   if(not lem)leh={}
   if boss then
    -- todo: put the ship object directly
    add(leh,(t-9))
   else
    -- todo: put the ship object directly
    add(leh,(hs.g+8-t)%hs.l+1)
   end
  --fake spawn ship
  elseif t==32 then
   next(hs)
  --spawn ship
  elseif (t>=128 and t<=131)
  or (t>=144 and t<=147) 
  or (t>=160 and t<=163)
  or (t>=176 and t<=179) then
   spawn(lex,ley,leu,lev,
   lesf,less,lesm,leb,ler)
  --count,delay,repeat x10
  elseif t>=96 and t<=105 then
   local v=(t-96)*10
   if lebt==1 then
    lec=v
   elseif lebt==2 then
    led=v
   elseif lebt==3 then
    let=v
   end
  --count,delay,repeat x1
  elseif t>=112 and t<=121 then
   local v=(t-112)
   if lebt==1 then
    lec=flr(lec/10)*10+v
   elseif lebt==2 then
    led=flr(led/10)*10+v
   elseif lebt==3 then
    let=flr(let/10)*10+v
   end
   lebt=lebt%3+1
  end
  lel=t
 end
end

-- ============================
-- particle functions

function beam(i,p)
 if p.z<3 then
  x,y
  =(i%p.z-4)*0.5,(p.z-3)*0.5
  sprite(p.x+x,p.y+y,20,glitter)
 else p.f=none end end

function lazer(i,p)
 if p.z<3 then
  x,y
  =(i%p.z-4)*0.5,(p.z-3)*0.5
  sprite(p.x+x,p.y+y,20,firin)
 else p.f=none end end

function dart(i,p)
 u,v=-61,124-vep
 x,y=(p.x+u)/2,(p.y+v)/2
 if p.z==0 then
  line(p.x,p.y,x,y,12)
 elseif p.z<3 then
  line(x,y,u,v,12)
  line(p.x,p.y,x,y,1)
  p.x,p.y=x,y
 elseif p.z==3 then
  line(x,y,u,v,12)
  line(p.x,p.y,x,y,1)
 else
  p.f=none
 end
end

function stars(i,p)
 if p.y<280 then
  if i<3 then
   p.x+=9
   p.y+=18
   line(p.x,p.y,p.x+3,p.y+7,5)
   line(p.x+4,p.y+8,p.x+7,
   p.y+15,6)
   line(p.x+8,p.y+16,p.x+11,
   p.y+23,7)
  elseif i<7 then
   p.x+=6
   p.y+=12
   line(p.x,p.y,p.x+1,p.y+3,1)
   line(p.x+2,p.y+4,p.x+3,
   p.y+7,13)
   line(p.x+4,p.y+8,p.x+5,
   p.y+11,12)
  else
   p.x+=2
   p.y+=4
   pset(p.x,p.y+12,5)
  end
 else 
  p.f=none
end
end

function point(c)
 c=max(1,c/100)
 return function(i,p)
  if p.z<c then
   poa+=1
   sprite(p.x,p.y,24,gotoscore)
  else p.f=none end
 end
end

function hit(c)
 return function(i,p)
  if p.z<4 then
   sprite(p.x,p.y,24,gotohit)
  else p.f=none end
 end
end

function explosion(i,p)
 if p.z<20 then
  if p.z<(10+i%3) and (
   p.z%4==1 or p.z%3==1) then
   x,y,r
   =rnd(12)*2-12,rnd(8)*2-8,i%12+8
   front(p.x+x,p.y+y,r,7,bang)
  end
  if p.z<12 and
   (p.z%2==1 or p.z%3==1) then
   x,y
   =rnd(4)*2-4,rnd(4)-2
   sprite(p.x+x,p.y+y,20,flick)
  end
  if p.z>7 and p.z<20 and (
   p.z%4==1 or p.z%5==1
   ) then
   x,y,r
   =rnd(12)*2-12,rnd(8)*3-12,i%4+6
   back(p.x+x,p.y+y,r,1,smoke)
  end
 else p.f=none end end

function gotoscore(i,s)
 u,v=aim(s.x,s.y,58-rnd()*20,6+rnd()*4)
 s.x+=u*min(15,s.z+i)*0.7
 s.y+=v*min(15,s.z+i)*0.6
 pal(8,1)pal(2,12)pal(7,13)
 if s.z==15 then
  s.f,s.y=none,-128
 else
  poa+=1
 end
end

function gotohit(i,s)
 u,v=aim(s.x,s.y,-30,12)
 s.x+=u*s.z*0.3
 s.y+=v*s.z*0.3
 pal(8,4)pal(2,9)pal(7,10)
 if(s.z==30) s.f,s.y=none,-128 end

function glitter(i,s)
 s.x+=0.124*i-2
 s.y+=s.z-2
 if(s.z==9) s.f,s.y=none,-128 end

function firin(i,s)
 glitter(i,s)
 pal(11,12)pal(3,13) end

function flick(i,s)
 glitter(i,s)
 pal(11,9)pal(3,4) end

function smoke(i,p)
 p.y-=0.25
 p.y+=(i-16)*0.01
 p.r+=((i%4)+2)*0.03
 if p.z==(i%14)+18 then
  p.f=none p.y=-64 end end

function bang(i,p)
 p.x+=(p.z%3)-1
 if p.z==0 then p.c=0
 elseif p.z==1 then p.c=10
 elseif p.r>17 then p.r-=4 p.c=10
 elseif p.r>5 then p.r-=3 p.c=6
 elseif p.r>3 then p.r-=2 p.c=6
 else p.f=none p.y=-64 end end

--todo: can be transformed
--to an anim
function die(i,p)
 p.y+=0.1
 if p.z<30 then
  x=rnd()*2-1
  --xxx: weird, normally
  --vessel should always be
  --drawn
  spr(32,p.x-8+x,p.y-11,1,2)
  spr(32,p.x+x,p.y-11,1,2,true)
 end
 if(p.z==0)sfx(1,1)sfx(4,0)
 if p.z<16 then
  for i=0.25,1,0.25 do
   x,y=rot(-130,0,
   i+rnd()/80+p.z/400)
   line(p.x,p.y,p.x+x,p.y+y,7)
   for j=-1,1 do
    line(p.x-j/2,p.y+j/2,p.x+x-j,p.y+y+j,7)
    line(p.x+j/2,p.y+j/2,p.x+x+j,p.y+y+j,6)
   end
  end
  x=rnd()*2-1
  circ(p.x+x,p.y,30-p.z,7)
  circ(p.x+x,p.y,31.25-p.z,6)
  circ(p.x+x,p.y,32.5-p.z,7)
 elseif p.z==16 or p.z==18 then
  cls(7)
 elseif p.z==17 then
  cls()
 elseif p.z<30 then
  x,y=rnd()*2-1,rnd()*2-1
  circfill(p.x+x*2,p.y+y*2,45-p.z/2,6)
  circfill(p.x+x,p.y+y,40-p.z/2,7)
 elseif p.z==30 or p.z==33
 or p.z==37 then
  if(p.z==30)sfx(-2,0)sfx(-2,1)
  sfx(5)
  effect(p.x,p.y,explosion)
 elseif p.z==50 then
  sfx(-1)
 elseif p.z==41 then
  p.f=none
 end
end

function palrot(from,to)
local a,l=1,#to
return function(s)
 for i,c in pairs(from) do
  pal(from[i],to[flr(i+a)%l+1])
 end
 a=a%l+s
end
end

-- ============================
-- ennemy function

function shoot(x,y,u,v,f,m)
 b=bs[bs.g] next(bs)
 b.x,b.y,b.u,b.v,b.f,b.z,b.m
 =x,y,u,v,f,0,m end

-- h= ship/cannon object
-- c= bullet count this frame
-- d= frame delay
-- t= repeat x times
-- n= shape function
-- m= movement function
-- s= speed
-- f= frame tile index
-- w= aim follow mode
function fire(h,c,d,t,n,m,s,
f,w)
 h.q=qs.g
 q=qs[qs.g] next(qs)
 q.c,q.d,q.e,q.t,q.n,q.m,q.s,
 q.w,q.z,q.h,q.f
 =bcount(c),0,d,t,n,m,
 s,w,0,h,f end

-- x,y= position
-- u,v= direction
-- f= frame tile index
-- s= speed
-- o= distance from cannon
-- m= movement function
-- b= hp
-- r= base score when destroyed
function spawn(x,y,u,v,f,s,m,
b,r)
 h=hs[hs.g] next(hs)
 h.x,h.y,h.u,h.v,h.f,h.s,
 h.m,h.a,h.b,h.d,h.e,h.c,h.z,
 h.r,h.t
 =x,y,u,v,f,s,m,true,
 flr(b*.7),0,b,0,0,r,0
 return h end

function damage(h,v,qs)
 if boss then
  if bob>0 then
   sco(1234)
   bob-=v
  elseif boa then
   for i=1,100 do
    local x,y=(lea+i)%128,(lea+i)/128
    if mget(x,y)==78 then
     lerk=flr(lea+i)
     break
    end
   end
   slow=-1
   lea=lerk
   lerk,lema,bom,boa,boi
   ,lebt,lec,led,let,lem,leh
   =0,0,0,false,4,1,0,0,0
   ,false,{}
   for i=1,6 do
    local b=bo[i]
    if(b.q>0)qs[b.q].t=0
   end
   sco(32000)
  end
 elseif h.c then
  if h.b>0
  then h.b-=v h.d=6
  else
   kill(h)
   locald(h.x,h.y,h.r/2,h.r/100)
  end
 end
end

function locald(x,y,s,z)
 l=lo[lo.g] next(lo)
 l.x,l.y,l.s,l.z=x,y,s,z end

function kill(h)
 effect(h.x,h.y,explosion)
 effect(h.x,h.y,point(h.r))
 sfx(5)
 h.b,h.m,h.a=0,none,false
 if(qs[h.q])qs[h.q].t=0
 sco(max(99,h.r+h.c*1000))
 if(h.q>0)qs[h.q].t=0
 if vep<uipo-3 then
  effect(h.x,h.y,hit(h.r))
  if hitv<999 then
   hitv+=1
   if hitg[3]<9 then
    hitg[3]+=1
   else
    hitg[3]=0
    if hitg[2]<9 then
     hitg[2]+=1
    else
     hitg[2]=0
     if hitg[1]<9 then
      hitg[1]+=1
     end
    end
   end
  end
  extend(i)
  hitd=50
 end
end

function dead()
 vea,veb,vel=false,false,false
 effect(vex,vey,die,0)
 vex,vey=0,140
 anim=arrive(110)
end

-- ============================
-- emitter

function effect(x,y,f,i)
 p=pp[i or pp.g] next(pp)
 p.x,p.y,p.f,p.z
 =x,y,f,0 end

function sprite(x,y,t,f)
 s=sp[sp.g] next(sp)
 s.x,s.y,s.t,s.a,s.f,s.z,s.d
 =x,y,t,0,f,0,3 end

function back(x,y,r,c,f)
 p=bp[bp.g] next(bp)
 p.x,p.y,p.r,p.c,p.f,p.z
 =x,y,r,c,f,0 end

function front(x,y,r,c,f)
 p=fp[fp.g] next(fp)
 p.x,p.y,p.r,p.c,p.f,p.z
 =x,y,r,c,f,0 end

-- ============================
-- gameplay

function sco(h)
 local i=8
 for j=1,1+hitv do
  while h>0 do
   a=h%10
   if(scos[i]+a>9)h+=10
   scos[i]=(scos[i]+a)%10
   h=flr(h/10) i-=1
  end
 end
end

function power(p)
 if vep<uipo and p>0.125
 and lez%5==0 then
  effect(vex,vey,dart)
 end
 vep=min(uipo,vep+p+hitv/100)
end

function extend(p)
 uipo=min(80,uipo+1) end

function slottoscore(s)
 local a,n,t,v
 =0x5e00+12*s,3*s+1,{}
 for i=1,8 do
  if i%4==1 then
   v=dget(n)
   n-=1
  end
  t[i]=band(v,15)
  v=shr(v,4)
 end
 return t
end

function resetscore()
 for i=1,8 do scos[i]=0 end
end

function reset()
 -- lp=late postion of vessels,
 -- late position active
 -- fix late position
 -- lez=level frame counter
 -- lea=index of tile to read
 --=0,384,false,0,0,132 --1 boss
 --=0,768,false,0,0,164 --2
 -- lex,ley=ship position
 -- leu,lev=ship direction
 -- lesm=ship movement
 -- less=ship speed
 -- lesf=ship frame
 -- leb=base hp
 -- ler=base scare
 -- leh=selected ship for shoot
 -- settings
 -- lem=multi selection enable
 -- lep=consumed, will be reset
 -- lec=bullet count
 -- led=bullet delay
 -- let=bullet repeat
 -- lebn=shape
 -- leaa=arc angle
 -- leas=arc spirale
 -- lebm=bullet movement
 -- lebs=bullet speed
 -- lebz=bullet speed multiplyer
 -- lew=aim
 -- lebf=bullet frame
 -- lebt=bullet number state 
 -- 1=count 2=delay 3=repeat
 -- lel=old tile
 -- box,boy=position
 -- bou,bov=target position
 -- bos=speed
 -- boh=sel canon
 -- bob=real hp
 -- bom=max hp
 -- bod=disp hp
 -- boi=hp heal speed
 -- poa=point anim
 la,vex,vey,veu,vev,vea,veb,vez,
 ved,vel,ves,vep,vew,veg,lp,
 lpa,lpf,lez,boss,lema,lerk,
 boti,lex,ley,leu,lev,lesm,less,
 leb,ler,leh,lec,led,let,lebn,
 leaa,leas,lebm,lebs,lebz,lew,
 lesf,lebf,lebt,lem,lel,uipo,
 hitd,hitv,box,boy,bou,bov,bos,
 boh,bob,bod,bom,boa,boi,poa
 =16,0,140,0,0,false,false,0,
 false,false,3,10,40,false,{},
 false,false,0,false,0,0,
 132,0,-82,0,1,cross,1,
 5,0,{},1,0,1,arc,
 0,0,none,0,1,false,
 0,0,1,false,0,20,
 0,0,0,-50,0,30,0.5,
 1,0,0,0,false,4,0
 lp.i=1
 --debug
 --lea=0
 for i=1,4 do lp[i]={x=0,y=0} end
 -- ui
 for i=1,3 do hitg[i]=0 end
 -- x,y=pos from boss
 -- a=active (needed)
 -- u,v=canon dir
 -- o=?
 -- c=?
 for i=1,6 do
  local b={}
  bo[i]=b
  b.a,b.u,b.v,b.c,b.q,b.z
  =true,0,1,0,0,0
 end
 -- todo: change dir of canon: u,v
 -- todo: setup cannon for boss 2?
 bo[1].x,bo[1].y=-20,boy-5
 bo[2].x,bo[2].y=20,boy-5
 bo[3].x,bo[3].y=-22,boy+10
 bo[4].x,bo[4].y=22,boy+10
 bo[5].x,bo[5].y=0,boy-8
 bo[6].x,bo[6].y=0,boy+14
 wa=0
end

--debug
--function mhere()dset(63,lea)run()end
--function mhind()dset(63,max(0,lea-8))run()end
--function mrese()dset(63,0)run()end

function arrive(wait)
 return cocreate(function()
  veg=true
  while wait>0 do
   wait-=1
   yield()
  end
  vex,vey=0,140
  while vey>101 do
   vey+=max(-5,(100-vey)/3)
   yield()
  end
  while vey<117 do
   vey+=min(3,(118-vey)/4)
   yield()
  end
  vea,wait=true,30
  while wait>0 do
   wait-=1
   yield()
  end
  veg,anim=false,false
 end)
end

function win()
 local t=0
 warmup()
 return cocreate(function()
  veg,vea=true,true
  for t=0,70 do
   y+=0.5
   sfx(8)
   if t%11==0 then
    sfx(5)
    effect(box+t*0.5-25+rnd(10),
    boy+(t*33)%20,explosion)
   end
   if t==50 then
    effect(box,boy+15,die,0)
    rectfill(-64,0,64,128,7)
   end
   if t==65 then
    boss=false
   end
   yield()
  end
  for t=0,20 do
   vev-=1
   vey+=vev
   rectfill(vex-2,vey+4,vex+1,
   128,7-max(t-18,0))
   sspr(64+(t%2)*24,16,24,16,
   vex-8,vey+4,15,12)
   yield()
  end
  for t=0,120 do
   spr(5,-20,70-t*0.25,5,1)
   yield()
  end
  if lea<768 then
   reset()
   anim,scene,lea,boti
   =false,play,768,164
  else
   reset()
   local b=false
   for i=1,8 do
    if scos[i]>best[i] then
     b=true
    end
   end
   if b then
    for i=1,8 do
     best[i]=scos[i]
     dset(i,scos[i])
    end
   end
   anim,scene=ranking(),title
   sfx(-1,0)music(1,10,7)
  end
 end)
end

function present(st)
 local s,c,d,x,y,z,w,m,n,t
 =-st,{},{},70,283,0,1,0,0,0
 return cocreate(function()
  while true do
   if(y>43 and s>-10)y-=(y-43)/8
   camera(rnd(2)-1,rnd(3)-1)
   x+=w/4
   spr(203,x-8,y,5,3)
   spr(252,x,y+24,2,1)
   spr(249,x,y-8,3,1)
   spr(254,x-8,y-16,2,1)
   m=x+14
   n=y+27
   for i=1,10 do
    line(m+i,n,m+i+30,n+60
    ,i%9==1 and 6 or 7)
   end
   if(z==58)w=-w
   z=z%50+9
   spr(96,m+z/2-5,n+z)
   spr(97,m+z/2+2,n+z-8,2,1)
   spr((z%30)>15 and 40 or 43
   ,m-5,n-3,3,2)
   camera(-64,-64)
   if(s>-10)spr(192,-43,y-21,9,1)
   if(s>14)spr(201,-62,30,2,2)
   if(s>15)spr(224,-46,30,2,2)
   if(s>16)spr(226,-31,30,1,2)
   if(s>17)spr(226,-24,30,1,2,true)
   if(s>18)spr(227,-18,30,2,2)
   if(s>19)spr(229,-3,30,1,2)
   if(s>20)spr(229,4,30,1,2,true)
   if(s>21)spr(226,11,30,1,2)
   if(s>22)spr(226,18,30,1,2,true)
   if(s>23)spr(230,24,30,2,2)
   if(s>24)spr(232,39,30,1,2)
   if(s>25)spr(232,46,30,1,2,true)
   if(s>39)rectfill(-45,46,19,51,1)rectfill(23,46,39,51,1)print("\85\78\67\79\77\80\82\69\72\69\78\83\73\66\76\69 \90\69\82\79",-44,46,13)
   if(s>44)rectfill(-45,51,-21,56,1)rectfill(-17,51,11,56,1)print("\66\79\77\66\69\82 \70\73\71\72\84\69\82",-44,51,13)
   if(s<45)s=s+1
   if t==160 then
    anim=ranking()
   elseif btnp(5) then
    if s<45 then
     s,y=45,43
    else
     restart(keyboard)
    end
   end
   t+=1
   yield()
  end
 end)
end

function restart(inp)
 anim,scene,lea,input,rid
 =false,play,0,inp,1
 reset()
 music(-1,200)
 for i=1,pp.l do
  pp[i].f=none
 end
end

function sprtext(str,x,y)
 local num,c=""
 for i=1,#str do
  c=sub(str,i,i)
  if c=="," then
   spr(tonum(num),x,y)
   x+=7
   num=""
  else
   num=num..c
  end
 end
end

function ranking()
 local h,z=-130,0
 score(scos,-12,20)
 return cocreate(function()
  while true do
   z+=1
   camera(-40,h)
   sprtext("33,34,35,49,50,35,51,",0,0)
   print("last",-4,14,13)
   score(scos,-12,20)
   print("best",-4,30,13)
   score(best,-12,36)
   sprtext("28,33,29,30,50,31,46,",0,50)
   print("title screen art",-5,63,13)
   print("radigo",12,70,6)
   print("everything else",-3,83,13)
   print("moechofe",9,90,6)
   print("tests & qa",5,103,13)
   print("david cruau",3,110,6)
   if btnp(5) then
    if h<-8 then
     h=-8
    else
     anim=present(5)
    end
   end
   if z>100 then
    if h<110 then
     h+=z/6
    elseif rankingc<2 then
     anim=present(5)
     rankingc+=1
    else
     restart(demo)
    end
   else
    if(h<-8)h+=(-h+8)/6
   end
   yield()
  end
 end)
end

anim,rankingc=false,0
function play()
 rankingc=-1
 if vea then
  ctr()
 elseif not anim then
  anim=arrive(10)
 end
 upd()
 -- update level,spawn ship
 level() lez+=1
end

titlerotpal=palrot({1,2,14},{1,2,14,15,13,12})

tz=0
function title()
 if(not anim)anim=present(55)
 tz=tz%2+1
 if tz==1 then
  effect(rnd()*-128+20,-20
  ,stars)
 end
 pat(true)
end

function keyboard()
 return btn(0),btn(1),btn(2),
 btn(3),btn(4),btn(5)
end

rep=",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,0,,,,,0,0,0,,,,0,0,0,,,0,0,0,,,,5,05,0,0,,0,0,05,5,5,5,5,5,,5,5,5,45,45,45,45,4,4,4,4,4,4,4,4,4,4,4,4,14,1,1,1,1,5,5,5,,0,0,0,,,,,,,,,1,1,145,145,145,14,14,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,15,15,15,15,15,15,15,5,45,45,45,45,45,045,045,045,045,45,45,45,45,45,45,45,045,045,045,045,04,0,0,0,0,0,0,0,0,0,0,0,0,0,0,04,04,04,04,04,04,04,04,04,04,0,02,02,02,25,25,25,25,25,45,45,45,45,45,45,45,45,45,45,45,4,4,,,,,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,,,5,5,15,15,15,15,1,1,1,1,13,13,13,13,1,1,,,,,0,0,0,,,5,5,15,15,5,5,,1,1,1,,,,5,5,5,,,,,,,,,,0,0,0,,,5,5,5,15,15,145,145,145,145,15,,4,4,4,4,4,4,04,04,04,04,4,4,4,4,,,1,1,1,1,5,5,35,345,345,0345,0345,0345,345,345,1345,13,1,1,1,1,1,1,1,1,1,1,1,12,2,2,02,02,02,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,,,1,1,,,,,,,1,1,1,1,,,5,5,,,0,0,,,5,5,5,15,1,1,,,5,5,5,5,5,5,05,05,05,05,05,05,05,05,05,05,05,05,015,15,15,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,15,5,5,5,5,5,5,15,15,15,15,15,5,05,05,0,0,0,0,0,04,04,04,4,4,4,4,4,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,124,12,25,25,25,2,2,2,,,0,0,05,05,05,5,5,5,5,5,45,45,45,45,45,45,45,45,45,345,34,03,03,03,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,03,03,3,35,5,,,,,5,5,5,5,,,,,,,,,,,5,5,5,5,5,5,5,5,5,5,5,5,45,45,45,45,45,,,,,,,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,15,15,15,15,15,15,5,5,5,5,5,5,15,15,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,35,35,35,5,5,5,5,15,15,5,5,5,5,5,5,5,35,35,35,5,5,5,5,5,5,5,45,45,45,45,45,45,45,45,45,,,,2,2,2,02,02,0,0,0,0,,,,,,,,,,,,,,,,,,0,0,0,,,,0,0,,,,0,0,,,,,1,1,1,1,1,1,15,5,5,5,5,,,,,,,,,,,,,,,,34,34,34,34,34,134,1345,145,145,145,145,145,1,1,1,1,1,1,12,12,2,2,2,2,0,0,0,0,0,0,4,4,4,14,1,1,1,12,12,02,02,0,0,0,0,0,03,03,03,03,03,03,03,03,03,0,0,0,05,5,5,15,15,15,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,05,05,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,15,15,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,,,,4,4,4,14,14,4,4,4,4,4,4,14,4,,,,1,,,,,,,,,,,,,,,,1,1,,,,,,,,0,0,0,0,0,0,,,,,,,1,1,1,,,,,,,,,,,0,0,,,,,,,,,,2,2,02,02,0,0,0,0,0,,,,,,,,,,,03,03,0,0,0,,,,,5,5,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,0,0,0,,5,15,15,15,15,5,5,,,0,0,0,0,,4,4,14,14,14,14,14,14,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,,,,,,,,1,1,1,1,,,,,,,,,,,4,4,4,4,4,4,4,,,,,,,,,,4,4,4,4,4,4,4,,,,,,,,,,,,,,,,,2,2,2,02,02,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,,,3,3,3,3,,,,,,,,,,,,,,,0,0,,,,0,0,,,,0,0,0,0,0,0,0,0,0,05,5,5,5,,,,,,,,15,15,15,5,,,,,,5,5,5,,,,,,,,,,,,,,1,1,15,5,5,5,,,3,3,3,,,,,,3,3,3,35,5,5,5,5,,,,3,3,,5,5,5,15,5,,,,,,1,1,1,1,1,1,,,,,0,04,04,4,4,4,4,4,4,4,4,4,4,04,04,04,4,,,,,,,,,,,0,0,0,0,0,0,,,,,,,1,1,1,1,,,,,,,4,4,04,04,04,04,04,04,0,,,,,,,,,,,,,,,,,,,,,,,1,1,12,12,2,02,0,0,,,5,5,5,5,15,15,345,345,34,34,34,34,34,34,34,3,13,13,13,13,13,1,1,,,,,,,,,,,0,0,0,0,0,0,04,04,04,04,04,04,04,04,4,,,,,,,,,,,,1,1,1,1,1,1,1,1,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,2,2,2,2,,1,1,1,,,,,,,,,,,,,,,,,,,,,,5,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,5,5,,,,,,,5,5,35,35,35,35,35,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,15,15,15,5,5,5,5,5,5,5,5,5,5,5,05,05,05,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,25,25,5,5,5,15,15,15,15,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,05,05,5,5,5,5,5,5,5,5,5,5,15,15,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,05,05,5,45,45,45,45,45,45,045,045,45,45,45,45,045,045,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,145,145,145,45,45,45,45,145,145,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,045,045,45,45,45,45,45,45,45,45,45,45,45,45,045,045,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,5,5,,,,,,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,145,145,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,145,145,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,045,045,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,145,145,145,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,145,145,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,5,5,5,5,5,5,5,5,5,5,05,5,5,5,45,45,45,45,045,045,045,45,45,45,45,45,45,45,45,45,45,45,45,045,045,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,45,5,5,5,5,5,5,5,5,5,05,05,5,5,5,5,5,5,5,5,5,5,5,5,5,15,15,15,15,15,15,15,15,5,5,5,5,5,5,5,05,05,05,5,5,,,,,,,,,,,,,,,,,,,,,,,,,,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,15,15,15,5,5,5,5,15,15,5,5,15,15,15,15,15,15,5,5,5,5,5,45,45,45,45,045,045,045,45,45,45,045,045,045,045,045,45,45,45,45,145,145,145,145,45,45,45,145,145,145,145,145,45,45,45,45,45,045,045,045,045,045,045,5,15,15,15,15,15,5,5,5,15,15,15,5,5,5,5,5,5,15,15,15,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,15,15,15,5,5,15,15,15,15,5,5,45,45,45,45,45,45,045,045,045,045,045,045,045,045,045,045,045,045,045,045,045,045,045,045,045,45,45,145,145,145,145,145,145,45,45,45,45,145,145,145,145,45,45,45,45,45,45,45,045,045,045,045,45,45,045,045,045,045,045,045,045,045,045,045,045,045,045,045,045,045,45,145,145,145,145,145,145,145,145,145,145,145,145,145,145,145,145,145,145,145,45,45,45,45,45,45,45,045,045,045,045,045,045,45,45,45,045,045,045,45,45,045,045,045,1,1,,,,,,|"
function demo()
 b0,b1,b2,b3,b4,b5=false,false,false,false,false,false
 while rid<=#rep do
  local c=sub(rep,rid,rid)
  rid=rid+1
  if c=="|" then
   scene=title
   sfx(-1,0)
   music(1,10,7)
  end
  if(c==",")break
  if(c=="0")b0=true
  if(c=="1")b1=true
  if(c=="2")b2=true
  if(c=="3")b3=true
  if(c=="4")b4=true
  if(c=="5")b5=true
 end
 return b0,b1,b2,b3,b4,b5
end

function ctr()
 --demo recorder
 --if(btn(0))printh("0")
 --if(btn(1))printh("1")
 --if(btn(2))printh("2")
 --if(btn(3))printh("3")
 --if(btn(4))printh("4")
 --if(btn(5))printh("5")
 --printh(",")
 -- move vessel
 local b0,b1,b2,b3,b4,b5=input()
 veu,vev=0,0
 if(b0)veu-=ves
 if(b1)veu+=ves
 if(b2)vev-=ves
 if(b3)vev+=ves
 -- shoot beam/lazer
 if vea and b4 then
  if(not vel and vep>5.75)vel,ves=true,2 sfx(6,0) -- fixme: ves=2 !!!???
  if(vep<0)vel,ves=false,3 sfx(-2,0)
 else
  if(vel)vel,ves=false,3 sfx(-2,0)
 end
 if vea and b5 and not vel then
  if(not veb)veb,ves=true,3 sfx(0,0)
 else
  if veb then
   veb,bed=false,0
   if(not vel)sfx(-2,0) ves=3
  end
 end
 lp[lp.i].x=vex
 lp[lp.i].y=vey
 lp.i=(lp.i%4)+1
 vex=mid(-60,60,vex+veu)
 vey=mid(4,126,vey+vev)
end

function pat(canshoot)
 -- update shape,shoot bullet
 for i=1,qs.l do
  q=qs[i] q.z+=1
  if q.t>0 then
   w=ang(q.h.x,q.h.y,vex,vey)
   if q.d>0 then q.d-=1
   else q.d=q.e
    for j=1,q.c do
     a,x,y,u,v
     =q.n(i,q,j,w)
     if(vea or canshoot)shoot(x,y,u,v,q.f,q.m)
     q.h.c+=1 end
    q.t=(q.t==1)and -1or q.t-1
   end
  end
 end
 -- update particle
 for i=0,pp.l do
  local p=pp[i]
  p.f(i,p) p.z+=1
 end
 -- draw particles
 for i=1,32 do
  local b=bp[i]
  b.f(i,b)
  circfill(b.x,b.y,b.r,b.c)
  b.z+=1
 end
 for i=1,32 do
  local s,f=sp[i],fp[i]
  s.f(i,s)
  spr(s.t+s.a,s.x-3,s.y-3)
  pal()
  if s.d==0 then
   s.d=1
   s.a=(s.a==3)and 0or s.a+1
  else s.d-=1 end
  s.z+=1
  f.f(i,f)
  circfill(f.x,f.y,f.r,f.c)
  f.z+=1
 end
end

function bul()
 -- update,draw bullet
 for i=1,bs.l do
  b=bs[i]
  spr(b.f,b.x-3,b.y-3)
  b.x+=b.u b.y+=b.v
  b.m(i,b)
  local d=dis(b.x-3,b.y-3,vex-4,vey-3)
  if vea and d>0 and not veg then
   --debug
   --if(d<6)dead()
   if(d<5)dead()
   if d<100 then
    ved=true
    power(0.375)
   end
  end
  if b.x<-72 or b.x>72
  or b.y<-16 or b.y>142 then
   b.m,b.y,b.x=none,0,160 end
 end
end

function score(d,x,y)
 poa=max(0,poa-flr(poa/2+1))
 por=false
 for i=1,8 do
  local v=por and rnd(9) or d[i]
  spr(112+v,i*7+x,y)
  por=(v>0 and poa>0) and true or false
 end
end

function upd()
 ved=false
 -- draw score
 score(scos,-8,1)
 -- draw lazerbar
 spr(74,-65,122-uipo)
 spr(75,-65,111,1,2)
 line(-63,115,-63,126-uipo,1)
 line(-59,119,-59,130-uipo,1)
 for i=0,2 do
  if vep>0.125 then
   c=12
   if(vep<5)c=6
   if(vep>uipo-3.25)c=8
   line(-62+i,123+i,-62+i,123+i-vep,c)
  end
 end
 -- draw hit
 if hitd>0 then
  if hitd>48 then
   pal(2,7)pal(14,5)pal(4,5)
  end
  hitd-=1
  for i=1,3 do
   spr(64+hitg[i],-72+i*9,1,1,2)
  end
  spr(76,-36,1,2,2)
  pal()
 end
 if wa>0 and wa<120 then
  if(wa>1 and wa<3)pal(9,7)
  print("here he comes",-56,29,9)
  pal()
  if(wa>20 and wa<23)pal(8,7)pal(2,6)
  if(wa>20)sspr(80,48,40,16,-56,38,96,32)sspr(114,48,6,16,39,38,16,32)
  pal()
  local wa9=wa%9
  if(wa>40 and wa<43 or wa>114)pal(6,7)
  --if(wa>40 and wa<116)print("100% bullets storm",-56,72,6)
  --if(wa>50 and wa<53 or wa>112)pal(6,7)
  --if(wa>50 and wa<114)print("#"..flr(wa/9%9).."."..wa9..wa9..wa9.."\x8132767\x99"..(shl(1,wa)%9).."\x80mk2",-56,79,6)
  --if(wa>60 and wa<63 or wa>110)pal(6,7)
  --if(wa>60 and wa<112)print("he is tough!!!",-56,86,6)
  pal()
  wa+=1
 end
 -- update,draw boss
 if boss then
  -- hp
  d=bob-bod
  if d>4 then
   bod+=boi
  elseif d<-2 then
   bod-=2
  else
   bod=bob
  end
  rectfill(-54,11,54,13,2)
  if bod>0 then
   rectfill(-54,11,bod/bom*116-54,13,8)
  end
  -- compute direction using target
  bd=dis(box,boy,bou,bov)
  if bd<-1 or bd>1 then
   bu,bv=nor(aim(box,boy,bou,bov))
   bu,bv=bu*bos,bv*bos
   box+=bu
   boy+=bv
   for i=1,6 do
    bo[i].x+=bu
    bo[i].y+=bv
   end
  else
   box=bou
   boy=bov
  end
  x,y=box,boy
  spr(boti,x-32,y-16,4,2)
  spr(boti+4,x-32,y+0,4,2)
  spr(boti+8,x-32,y+16,4,2)
  spr(boti,x,y-16,4,2,true)
  spr(boti+4,x,y+0,4,2,true)
  spr(boti+8,x,y+16,4,2,true)
 end
 -- update,draw ship
 for i=1,hs.l do
  h=hs[i]
  if h.a then
   if h.x<-96 or h.x>96
   or h.y>160 or h.y<-32 then
    h.m,h.x,h.a
    =none,-128,false
   else
    h.m(i,h)
    if h.d>3 and lez%2==0 then
     for c=1,16 do pal(c,7) end
    end
    spr(h.f,h.x-8,h.y-7,1,2)
    spr(h.f,h.x,h.y-7,1,2,true)
    pal()
    if h.d>0 then
     h.d-=1
     line(h.x-6,h.y-9,h.x+6,h.y-9,3)
     local b=(h.b/h.e)*12
     if(b>0)line(h.x-6,h.y-9,h.x-6+b,h.y-9,11)
    end
   end
  end
 end
 pat()
 -- update,draw vessel
 if veg and lez%4>1 then
  pal(10,7) pal(9,7)
  pal(4,7) pal(12,7)
  pal(13,7) pal(1,7)
  pal(2,7) pal(5,7)
 end
 spr(32,vex-8,vey-11,1,2)
 spr(32,vex,vey-11,1,2,true)
 pal()
 -- update beam
 if veb then
  if bed==0 then
   bed=bee
   for j=0,1 do
    b=be[be.g]
    be.g=(be.g==be.l)and 1or be.g+1
    b.x=vex-8*j
    b.y=vey-24
   end
  else bed-=1 end
  spr(16+bef,vex-11,vey-16)
  spr(16+(bef+2)%4,vex+3,vey-16,1,1,true)
  bef=(bef+1)%4
 end
 -- draw beam
 s2=false
 for i=1,be.l do
  b=be[i]
  if b.y>-16 then
   spr(36+((i+lez)%2),b.x,b.y,1,2)
   if boss then
    -- collision with boss
    d=dis(box-4,boy-8,b.x,b.y)
    if d>0 and d<700 then
     if(not s2)sfx(2) s2=true
     effect(b.x+8,b.y+16,beam)
     b.y=-128
     damage(bo,1,qs)
    end
   else
    -- collision with ship
    for j=1,hs.l do
     h=hs[j]
     if h.a then
      d=dis(h.x-4,h.y-8,b.x,b.y)
      if d>0 and d<70 then
       if(not s2)sfx(2) s2=true
       effect(b.x+8,b.y+16,beam)
       b.y=-128
       damage(h,1,qs)
      end
     end
    end
   end
   b.y-=9
  end
 end
 -- draw lazer
 if vel then
  x,y,t,i=vex,vey,-16,false
  yy,hh=-99,false
  if boss then
   -- collision with boss
   if boy<vey-22 and box>x-30
   and box<x+31 then
    sfx(2)
    hh,yy=bo,boy-10
    if box>x-6
    and box<x+7 then
     yy=boy+10
    elseif box>x-20
    and box<x+21 then
     yy=boy+4
    end
   end
  else
   -- collision with ship
   for j=1,hs.l do
    h=hs[j]
    if h.a then
     if h.y<y-22 and h.x>x-11
     and h.x<x+12
     and h.y>yy then
      yy,hh=h.y-10,h
     end
    end
   end
  end
  if hh then
   effect(x,yy+16,lazer)
   i,t=j,yy+6
  end
  ld=1.4
  -- fixme: duplicated
  if vep>uipo-3.25 then
   if(la==16)la=25
   ld=1.7
   pal(7,0)pal(12,8)pal(6,2)
  end
  la=max(16,la-1)
  if hh then
   sfx(7)
   damage(hh,ld,qs)
  end
  local lh=(lez%2==0)
  sspr(48,21,16,3,x-la/2,t+16,la,y-t-24,lh,false)
  sspr(48,24,16,8,x-la/2,y-16,la,8,lh,false)
  if(hh)sspr(48,16,16,8,x-la/2,t+8,la,8,lh,false)
  pal()palt()
  vep=max(-1,vep-1)
 else
  power(0.0625)
 end
 bul()
 -- draw vessel colision
 if ved then
  vez=(vez==3)and 0or vez+1
  spr(24+vez,vex-4,vey-3)
 end
 -- apply local damage
 for i=1,lo.l do
  l=lo[i]
  if l.z>0 then
   l.z-=3
   for j=1,hs.l do
    local h=hs[j]
    if h.a
    and dis(l.x,l.y,h.x,h.y)<l.s
    then
     damage(h,2,qs)
    end
   end
  end
 end
end

scene=title
music(1)

cartdata("moechofe_md_1")
--debug
--printh("==========fresh start")
--menuitem(1,"mark here",mhere)
--menuitem(2,"mark behind",mhind)
--menuitem(3,"reset mark",mrese)

function warmup()
 -- bullet warpup
 for i=1,bs.l do
  b={} bs[i]=b
  b.x,b.y,b.u,b.v,b.f,b.z,b.m
  =-28,-28,0,0,0,0,none
 end
 -- shape warmup
 for i=1,qs.l do
  q={} qs[i]=q
  q.c,q.d,q.e,q.t,q.f,q.n,q.m,
  q.s,q.h,q.z,q.w
  =0,0,0,-1,0,none,none,0.0,
  false,0,false
 end
end

function _init()
 warmup()
 -- ship warmup
 for i=1,hs.l do
  h={} hs[i]=h
  h.x,h.y,h.u,h.v,h.f,h.s,
  h.m,h.a,h.b,h.d,h.e,h.c,h.z,
  h.r,h.q,h.t
  =-128,0,0,0,0,0,none,false,
  0,0,0,0,0,0,0,0
 end
 -- local damage warmup
 for i=1,lo.l do
  l={} lo[i]=l
  l.x,l.y,l.s,l.z=0,0,0,0
 end
 -- beam warmup
 for i=1,be.l do
  b={} be[i]=b
  b.x,b.y,b.f=0,-128,0
 end
 -- particle warmup
 for i=0,pp.l do
  p={} pp[i]=p
  p.x,p.y,p.z,p.f
  =0,0,0,none
 end
 -- sprite particle warmup
 for i=1,sp.l do
  s,b,f,l={},{},{},{}
  sp[i],bp[i],fp[i]
  =s,b,f
  s.x,s.y,s.f,s.z,s.f,s.t,s.d,
  s.a,b.x,b.y,b.c,b.r,b.f,b.z,
  f.x,f.y,f.c,f.r,f.f,f.z
  =0,-64,none,0,0,0,0,0,0,-64,
  0,0,none,0,0,-64,0,0,none,0
 end
 -- score
 for i=1,8 do
  scos[i]=0
   best[i]=dget(i)
 end
 --debug
-- if true then
--  reset()
--  scene=play
--  music(-1)
  --lea=768
--  lea=dget(63)
  --boti=164
-- end
end

function _draw()
 camera(-64,0) 
 if slow==1 and vea then
  slow=0
 else
  cls()scene()
  if(anim and costatus(anim))coresume(anim)
  if(slow==0)slow=1
 end
-- print(err,-57,122,8)
 --debug
-- if false and lez then
--  print("m"..flr(stat(0)).." c"..flr(stat(1)*1000)/1000,-57,115,7)
  --print("z"..lez..">"..flr(lea),0,115,9)
--  x,y=lea%128,flr(lea/128)
--  map(x-8,y,-68,17,32,1)
--  print("x,y:"..flr(x)..","..flr(y),0,109,8)
--  print("cdt:"..lec..","..led..","..let,0,121,10)
--  spr(95,-7,14)
--  spr(95,-2,14,1,1,true)
--  spr(95,-7,19,1,1,false,true)
--  spr(95,-2,19,1,1,true,true)
-- end
end
