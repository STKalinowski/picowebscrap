-- stories at the dawn
-- by yellowafterlife
clues=1
clues_time=0
clues_help=210
clues_btn=0
-- if map rect is all passable
function mcheck(x,y,w,h)
 if(x<0 or x+w>128) return false
 if(y<0 or y+h>64) return false
 for r=flr(y),flr(y+h-0.001) do
  for c=flr(x),flr(x+w-0.001) do
   if(fget(mget(c,r),0))then
    return false
   end
  end
 end
 return true
end
-- creates an object
function onew(x,y,w,h,ox,oy,vx,vy)
 return {
  x=x,y=y,w=w or 1,h=h or 1,
  ox=ox or 0,oy=oy or 0,
  vx=vx or 0,vy=vy or 0}
end
-- if can place obj at xy
function ocheck(o,x,y)
 return mcheck((x-o.ox)/8,(y-o.oy)/8,o.w/8,o.h/8)
end
-- if can place obj at rel xy
function ocr(o,dx,dy)
 return ocheck(o,o.x+dx,o.y+dy)
end
-- draws an object
function odraw(o,s,f)
 if(s==nil) s=o.s
 if(f==nil) f=o.f or false
 spr(s,
  o.x-o.vx,
  o.y-o.vy,
  1,1,f)
end
-- creates a new player
function pnew(x,y)
 return {x=x,y=y,w=4,h=6,
 ox=2,oy=0,vx=4,vy=2,
 t=0,s=1,f=false,v=0,g=0,
 kx=0,kj=false}
end
function pstep(p)
 local d,s
 p.t+=1
 -- gravity and jumping:
 if(ocr(p,0,1))then
  p.v+=0.23
  p.g+=1
 else p.g=0 end
 if(p.kj and p.g<4) p.v=-1.9
 -- horizontal movement:
 d=2 s=p.kx
 p.s=1
 if(s~=0)then
  p.f=s>0
  while(d>0)do
   if(ocr(p,s,0))then
    p.x+=s
    p.s=2+flr(p.t/3)%3
    d-=1
   else d=0 end
  end
 end
 -- vertical movement:
 d=abs(p.v) s=sgn(p.v)
 while(d>0)do
  if(ocr(p,0,s))then
   p.y+=s
   p.s=5
   d-=1
  else
   p.v=0
   d=0
  end
 end
 -- trigger switches:
 d=p.x/8 s=p.y/8
 if(mget(d,s)==8)then
  mset(d,s,9)
  while(d<128)do
   s=0
   while(s<16)do
    if(mget(d,s)==12)then
     mset(d,s,13)
     d=128
     break
    else s+=1 end
   end
   d+=1
  end
 end
end
function p1step(p)
 local s=0
 if(edc>0)then
  p.kx=0
  p.kj=false
 else
  -- poll controls:
  if(btn(0)) s-=1
  if(btn(1)) s+=1
  p.kx=s
  p.kj0=p.kj1
  p.kj1=btn(2) or btn(4)
  p.kj=not p.kj0 and p.kj1
  -- timer:
  if(gtf==0)then
   if(s~=0) gtf=1
  else gtf+=1 end
  gts=flr(gtf/30*100)/100
  -- endings:
  if(cam_r>1)then
   if(p.x<68)then
    -- endings trigger based
    -- on max screen explored:
    if(cam_r<3)then
     edc=1
    elseif(cam_r<5)then
     edc=2
     edt=-60
    else
     edc=3
     edt=-60
    end
    p.s=6
    gtt+=gts
   elseif(p.x>=966)then
    edc=4
    gtt+=gts
   end
  end
  -- trigger camera scrolling:
  s=flr(p1.x/128)
  if(s~=cam_x1/128)then
   if(s>cam_r)then
    cam_r=s
    cbp=cb
    if(s>=3) cb=2
    if(s>=5) cb=13
    if(s>=7)then
     cs0=-1
     cb=15
    end
    skyt=24
   end
   cam_x0=cam_x
   cam_x1=s*128
   cam_xt=0
  end
 end
 pstep(p)
end
-- ai:
function p2step(p)
 local b,dw,kx,kj
 -- current block:
 b=mget(p.x/8,p.y/8)
 -- if it's worth waiting:
 dw=cam_r<flr(p.x/128) or cam_w<7
 --
 kx=1 kj=0
 -- don't walk at endings bydef:
 if(edc>0 and edc<4) kx=0
 -- stop at the end:
 if(p.x>970) kx=0
 -- waiting spots:
 if(dw and b==10)then
  if(p.x%8>=4) then
   kx=0 p.f=false
  end
 elseif(dw and b==11)then
  if(p.x%8>=4) then
   kx=0 p.f=true
  end
 end
 -- jumping:
 if(not ocr(p,0,1) and kx>0)then
  if(not ocr(p,4,0))then
   if(ocr(p,4,-8))then
    -- can jump over.
    kj=1
   else
    -- can't jump over.wait
    kx=0
   end
  elseif(ocr(p,2,1) and ocr(p,2,9))then
   -- no safe drop ahead, jump.
   kj=1
  end
 end
 -- ending 3:
 if(edc==3)then
  if(edt<-30)then
   --
  elseif(edt==-30)then
   p.x=130
   p.y=98
  elseif(p.x>70)then
   kx=-1
  end
 end
 --
 p.kx=kx
 p.kj=kj>0
 pstep(p)
end
--
starx=0
stars={}
for i=1,192 do
 add(stars,{
  x=1+rnd(6)+band(i,15)*8,
  y=1+rnd(6)+shr(i,4)*8,
  z=rnd(5)<1})
end
function _drawstars()
 sx=flr(starx)
 for so in all(stars) do
  local sc=so.z and cs1 or cs0
  if(sc>=0) pset((so.x+sx)%128,so.y,sc)
 end
 -- moon:
 --spr(15,112-cam_x/64,8)
end
--
eds={0,0,0,0}
edp={1,2,13,15}
edc=0
edn=0
function _update()
 local d
 if(btn(5))then
  clues_btn=1
 else
  if(clues_btn>0)then
   clues=1-clues
   clues_time=90
  end
  clues_btn=0
 end
 --
 p1step(p1)
 p2step(p2)
 --
 if(edc>0)then
  -- ending-specific code:
  if(edc==4)then
  
  elseif(edc==3)then
   if(edt>=-30) p1.s=6
   if(edt>=30) p2.s=6
  elseif(edc==2)then
   if(edt>=-30) p1.s=6
   if(edt>=45) p2.s=6
   if(edt==0)then
    cam_x0=cam_x
    cam_x1=flr(p2.x/128)*128
    cam_xt=0
   end
  elseif(edt>30)then
   p1.s=6
   p2.s=6
  end
  -- restarting:
  if(edt>165 and edn<4)then
   if(btn(4) or btn(2))then
    edb=1
   else
    if(edb>0)then
     -- reset doors:
     for y=0,15 do
      for x=0,127 do
       d=mget(x,y)
       if(d==9) mset(x,y,8)
       if(d==13) mset(x,y,12)
      end
     end
     -- show all hints:
     if(edn==1)then
      for y=0,15 do
       for x=0,127 do
        if(mget(x,y)==22)then
         mset(x,y,21)
        end
       end
      end
     end
     -- hide taken hints:
     if(edc<4)then
      d=-16+edc*32
      for y=0,15 do
       for x=d,d+31 do
        if(mget(x,y)==21)then
         mset(x,y,22)
        end
       end
      end
     end
     --
     _reset()
    end
    edb=0
   end
  end
 end
end
-- draws the fancy transition:
function _drawfade(c,t)
 if(t<-9)then
  rectfill(0,0,127,127,c)
  return
 end
 pal(3,c)
 for x=0,15 do
  local i=64+max(0,min(9,x-t))
  for y=0,15 do
   spr(i,x*8,y*8)
  end
 end
end
--
function _draw()
 -- map gray color to black:
 pal(5,0)
 -- handle camera scrolling:
 local cxt,cxp,i,x,y,c,b,w,h,t
 if(cam_xt<1)then
  cam_xt=min(cam_xt+0.03,1)
  cam_w=0
 else cam_w+=1 end
 cxt=-sin(cam_xt/4)
 cxp=cam_x
 cam_x=cam_x0*(1-cxt)+cam_x1*cxt
 starx-=(cam_x-cxp)*0.5
 -- draw the sky:
 if(skyt>-9) skyt-=1
 rectfill(0,0,128,128,cbp)
 _drawfade(cb,skyt)
 _drawstars()
 camera(flr(cam_x),0)
 -- draw shines behind the hints:
 if(clues>0)then
  i=flr((gtf%150)/2)
  if(i<12) then
   for sh in all(shine) do
    spr(80+i,sh.x,sh.y)
   end
  end
 else
  -- no clues, hide these.
  for sh in all(shine) do
   spr(16,sh.x,sh.y)
  end
 end
 -- draw map and players:
 mapdraw(0,0,0,0,128,16)
 odraw(p1)
 odraw(p2)
 -- reset:
 camera()
 pal()
 -- ending ui:
 if(edc>0)then
  edt+=1
  starx-=min(max(0,(edt-15)/30),1)*0.11
  _drawfade(7,110-edt)
  if(edt>=120)then
   -- increment:
   if(edt==180)then
    if(eds[edc]<1)then
     eds[edc]=1
     edn+=1
    else edhint=1 end
   end
   -- times:
   if(edt>=135)then
    y=2
    if(gtt>gts)then
     print("total:"..gtt.."s",2,y,5)
     y+=6
    end
    print("time:"..gts.."s",2,y,5)
   end
   -- sections in the middle:
   y=24
   b=y+64-1
   w=24
   h=64
   t=4
   for k=0,3 do
    x=(128-t*3-w*4)/2+(t+w)*k
    if(eds[k+1]>0)then
     c=7
     pal(5,6)
    else
     c=edp[k+1]
     pal(5,0)
    end
    -- map inside:
    clip(x,y,w,h)
    rectfill(x,y,x+w,y+h,c)
    mapdraw(20+k*32-k,5,x-4,y-4,w/8+1,h/8+1)
    clip()
    -- frame:
    rect(x-1,y-1,x+w,y+h,6)
    -- fade-in:
    pal(3,7)
    for fy=0,h/8-1 do
     for fx=0,w/8-1 do
      i=64+max(min(131-edt+fy+k*4+fx,9),0)
      spr(i,x+fx*8,y+fy*8)
     end
    end
   end
   pal()
   -- status:
   if(edt>=150 and clues>0)then
   print(edn.."/4 stories discovered",
    20,y-8,5)
   end
   -- hints:
   if(edt>=195 and edn<4 and clues>0)then
    x=18 y=96 c=5
    spr(92,x-12,y)
    if(edhint>0)then
     print("hint: signs like this show",x,y-1,c)
     print("you where to turn back.",x,y+5,c)
    elseif(edn>=3 and eds[4]<0)then
     print("hint: the story can change",x,y-1,c)
     print("if you will go forward.",x,y+5,c)
    elseif(edc<4)then
     print("hint: the story can change",x,y-1,c)
     print("depending on when you turn",x,y+5,c)
    else
     print("hint: the story can change",x,y-1,c)
     print("if you return back instead",x,y+5,c)
    end
   end
   -- "the end"/"restart":
   if(edt>=210)then
    if(edn>=4)then
     spr(74,48,112,4,1)
    else
     spr(78,56,112,2,1)
    end
   end
  end
 end
 --
 x=2 y=2 c=7
 if(clues_time>0)then
  rectfill(x-1,y-1,x+58-clues*4,y+5,0)
  print("clues "
   ..(clues>0 and "en" or "dis")
   .."abled!",x,y,c)
  clues_help=0
  clues_time-=1
 elseif(clues_help>0)then
  clues_help-=1
  rectfill(x-1,y-1,x+103,y+23,0)
  print("arrows to move.",x,y,c)
  y+=6
  print("up/z/c to jump.",x,y,c)
  y+=6
  print("press x/v to disable clues",x,y,c)
  y+=6
  print("(more challenging!)",x,y,c)
 end
end
gtt=0--total time (seconds)
function _reset()
 --shining objects:
 shine={}
 for y=0,15 do
  for x=0,127 do
   if(mget(x,y)==21)then
    add(shine,{x=x*8,y=y*8})
   end
  end
 end
 --colors:
 cg=0
 cb=1
 cbp=0
 cs0=13
 cs1=7
 skyt=20
 -- ending-related:
 edc=0--current(1..4)
 edt=0--animation ticks
 edb=0--restart button state
 edhint=0--exocomics.com/373
 --^(when people need a very
 -- obvious hint to proceed)
 -- game time:
 gtf=0--in frames
 gts=0--in seconds
 -- players:
 p1=pnew(64,98)
 p2=pnew(492,24)
 -- camera:
 cam_r=flr(p1.x/128)
 cam_x=cam_r*128
 cam_x0=cam_x
 cam_x1=cam_x
 cam_xt=1
 cam_w=0
end
function _init()
 --hide hints on first run:
 for y=0,15 do
  for x=0,127 do
   if(mget(x,y)==21)then
    mset(x,y,22)
   end
  end
 end
 --
 _reset()
end

