-- storming the grandmothership
-- by picoter8

-- todo:
-- - shield left after game finished give points

-- keep the palette in the editor
poke(0x5f2e,1)

cartdata("grandmothership")

cpu,one_frame,g_time_scale=stat(1),1/60,1

g_gameover,
g_gameover_t,
g_boss_cores_killed,
g_boss_cores_killed_t,
g_last_boss_killed,
g_last_boss_killed_t,
g_core_count,
g_killed_core_count
=false,0,0,0,false,2,0,0

g_ms_fudge=64

ui_power_up_dialog,ui_power_up_dialog_t,ui_power_up_selection=false,0,2

align_c,align_r=1,2

function printb(text,x,y,c,bc,a)
 local ox=(a==align_c) and #text*2 or
          (a==align_r) and #text*4 or
          0
 local tx=x-ox
  
 for i=tx-1,tx+1 do
  for j=y-1,y+1 do
   print(text,i,j,bc)
  end
 end
 
 print(text,tx,y,c)
end

function printa(text,x,y,c,a)
 local ox=(a==align_c) and #text*2 or
          (a==align_r) and #text*4 or
          0
 print(text,x-ox,y,c)
end

function angle_fix(a)
 while a>.5 do
  a-=1
 end
 
 while a<-.5 do
  a+=1
 end
 
 return a
end

function normalize(x,y)
  local d=max(abs(x),abs(y))
  local n=min(abs(x),abs(y))/d
  local m=sqrt(n*n+1)*d
  return x/m,y/m,m
end

function polar_to_xy(r,a)
 return r*cos(a),r*sin(a)
end

function mxy(x,y)
 return x\8,y\8
end

function mappixel(x,y)
 if(y<0)return 0
 if(x<0)return 0
 if(y>256)return 0
 if(x>1024)return 0
 
 return fget(mget(x\8,y\8),0) and 1 or 0
end

function time_to_text(time)
 local hours,mins,secs,fsecs=time\3600,time\60%60,time\1%60,time%60*10\1%10
 if(hours<0 or hours>9)return "8:59:59"
 return hours>0 and hours..":" or ""
        ..((mins>=10 or hours==0) and mins or "0"..mins)
        ..(secs<10 and ":0"..secs or ":"..secs).."."..fsecs
end

explosion_colors,
explosion_smoke_colors,
debris_colors=
split"10,9,9,8,8,2,2",
split"7,7,9,9,8,8,2,2",
split"7,7,5,5,11,11,3,3"

function option_shooting(a)
  local nx,ny=polar_to_xy(1,a)
  make_pb(.6,p_x+12*nx,p_y+12*ny,4*nx,4*ny)
end

function make_player()

 return
 {
  init=function(p)
   p_t,p_x,p_y,p_vx,p_vy=0,-256,128,0,0
   
   p_flip,p_onx,p_ony,p_shooting_t,p_knockback_t,p_shake_ground_t,p_score=false,1,0,0,0,0,0

   p_shield,p_option_count,p_power,p_rate,p_max_s=5,1,1,.5,.75
  end,
  
  damage=function(p)
   -- player got hit!
   sfx(2)
   p_shield-=1
   p_knockback_t=1
   
   if p_shield<=0 then
    g_gameover,g_gameover_t=true,2
   end
   
   local x,y=p_x+1,p_y+1
  
   local r,ti=g_gameover and 8 or 2,g_gameover and 1.4 or .8

   for i=1,g_gameover and 32 or 16 do
    make_circle(layer_player_fx,ti+rnd(ti/2),x+r-rnd(2*r),y+r-rnd(2*r),-.2-rnd(.4),-.2-rnd(.4),g_gameover and (12+rnd(6)) or 12,0,explosion_colors)
   end 
  
   for j=1,g_gameover and 6 or 3 do
    for i=1,12 do
     local vx,vy=polar_to_xy(.5+rnd(.5),i/12+rnd(.05))
     make_line(layer_player_fx,ti+rnd(.3),x,y,4*vx,4*vy,6,explosion_colors)
    end 
   end
   
  end,
  
  collision_checks=function(p,ddx,ddy)
   
   if p_x<-320 then
    p_x=-320
   elseif p_x>1056+g_ms_fudge then
    p_x=1056+g_ms_fudge
   end
   
   if p_y<-g_ms_fudge then
    p_y=-g_ms_fudge
   elseif p_y>256+g_ms_fudge then
    p_y=256+g_ms_fudge
   end
   
   if(g_last_boss_killed)return
   if mappixel(p_x,p_y)!=0 then
    if abs(ddx)>0 then
     p_x=flr(p_x)+(ddx>0 and -1 or 1)
    end
    if abs(ddy)>0 then
     p_y=flr(p_y)+(ddy>0 and -1 or 1)
    end
   end
  end,
  
  update=function(p)
   p_t+=one_frame
   
   p_knockback_t=max(0,p_knockback_t-one_frame)
   p_shooting_t=max(0,p_shooting_t-one_frame)
   p_shake_ground_t=max(0,p_shake_ground_t-one_frame)
   
   if(g_gameover)return
      
   -- controls
   local cx,cy,aiming=0,0,false
   
   if(btn(0))cx-=1
   if(btn(1))cx+=1
   if(btn(2))cy-=1
   if(btn(3))cy+=1

   if btn(4) then
     if(btn(0))p_flip=true
     if(btn(1))p_flip=false

     --360 degree option shooting
     aiming=true
     if cx!=0 or cy!=0 then
       p_onx,p_ony=normalize(p_onx+.1*cx,p_ony+.1*cy)
     end
   end
   
   if ui_game_started then
    -- at the beginning of the level, autoscroll forward...
    if p_x<-64 then
     cx+=.2
    end
   end

   --[[ shooting (can't shoot if changing directions) ]]
   if not aiming and not ui_power_up_dialog then
    if p_shooting_t<=0 and punch_b.time_held>0 and p_knockback_t<=.6 then
     punch_b.consume(punch_b)
     
     sfx(0)
     p_shooting_t=p_rate
     
     -- ship shooting
     local snx=p_flip and -1 or 1
     make_pb(.6,p_x+4*snx,p_y+2.5,4*snx,0)

     -- option shooting
     local a=atan2(p_onx,p_ony)
     option_shooting(a)
     if(p_option_count>=2)option_shooting(a-.03125)
     if(p_option_count>=3)option_shooting(a+.03125)
    end
   end
   --]]
   
   --[[ smoke particles (no more smoke if changing directions) ]]
   if not aiming and not ui_power_up_dialog then
    local dam=mid(.15,1-p_shield/5,1)
    local vxsign=p_flip and -1 or 1
    local vx,vy=(.4-rnd(.2))*p_vx-vxsign*(1+dam),.4-rnd()
    local x,y=p_x-vxsign*(8+rnd(2)),p_y+3-rnd(4)
    make_circle(layer_player_fx,.2+rnd(.5)*dam,x,y,vx,vy*dam,1.5+rnd(),0,rnd(dam)>.2 and explosion_smoke_colors or explosion_colors)

    if dam>.25 then
      if(rnd()>.25)make_circle(layer_post_player_fx,rnd(.5)*dam,p_x+vxsign*4,p_y,vx,vy*dam,1.5+rnd(),0,explosion_smoke_colors)
    end
   end
   --]]
   
   p_vx+=.1*cx*one_frame*60
   p_vy+=.1*cy*one_frame*60
   
   local nx,ny,m=normalize(p_vx,p_vy)
   
   if m>p_max_s then
    p_vx,p_vy=p_max_s*nx,p_max_s*ny
   end
   
   p_vx*=.9
   p_vy*=.9
   
   if (abs(p_vx)<.01)p_vx=0
   if (abs(p_vy)<.01)p_vy=0

   local dx,dy=p_vx*one_frame*60,p_vy*one_frame*60
   
   --[[ collision checks]]
   while abs(dx)>0 or abs(dy)>0 do
    local ddx=dx>=1 and 1 or dx<=-1 and -1 or dx
    p_x+=ddx
    p:collision_checks(ddx,0)
    dx-=ddx
  
    local ddy=dy>=.5 and .5 or dy<=-.5 and -.5 or dy
    p_y+=ddy
    p:collision_checks(0,ddy)
    dy-=ddy  
   end
   --]]
  
   if not ui_game_started then
    p_x,p_y=mid(cam_x+8,p_x,cam_x+128-32),mid(cam_y+16,p_y,cam_y+128-16)
   end
  
  end,
  
  draw=function(p)
   if(g_gameover)return
   
   if(p_knockback_t>0 and t()%.1>.05)return

   local sprite=p_vy>.5 and 68 or
                p_vy>.2 and 66 or
                p_vy>-.2 and 64 or
                p_vy>-.5 and 98 or
                100
   
   spr(sprite,p_x-7+(p_flip and -1 or 0),p_y-8,2,2,p_flip)
   
   -- option ball
   circfill(p_x+11*p_onx,p_y+11*p_ony,3,1)
   circfill(p_x+11*p_onx,p_y+11*p_ony,2,9)
   circfill(p_x+12*p_onx,p_y+12*p_ony,1,10)
  end,
 }
end

function explosion(ex,ey,m)
 for i=1,16*m do
  local x,y=ex+2-rnd(4),ey+2-rnd(4)
  local vx,vy=polar_to_xy(.2+rnd(.4),i/(16*m)+rnd(.1))
  make_circle(layer_post_enemy_fx,.6*m+rnd(.2*m),x,y,vx,vy,6*m,0,explosion_smoke_colors)
  make_line(layer_post_enemy_fx,.1*m+rnd(.2*m),x,y,4*vx,4*vy,3*m,explosion_colors)
 end
end

function ms_debris(x,y,time,rtime,size,speed,rspeed)
 -- shoot debris
 for a=0,1,.1 do
  local vx,vy=polar_to_xy(speed+rnd(rspeed),a+rnd(.075))
  make_circle(layer_post_enemy_fx,time+rnd(rtime),x,y,vx,vy,size,0,debris_colors)
 end 
end 

ms_damage_keys=   split"  1,  2,  3,  4,  5,  6,  7,  8,  9, 10,   12, 13, 14, 15, 16, 17, 18, 19, 20,   21, 22, 23, 24, 25, 26, 28, 29,   30, 31, 32, 33, 34, 37, 38,   40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50,   55, 57, 58, 59,   60, 61, 62, 63,   71, 72, 73, 74, 75, 88, 89, 90, 91,103,106,107,  123,130,146,162"
ms_damage_values= split"196,224,225,199,232,233,192,193,194,195,  232,233,205,237,227,212,213,214,215,  248,249,208,196,197,211,248,249,  221,253,228,240,243,201,202,  212,213,234,235,230,231,238,239,244,241,244,  200,216,250,251,  246,247,254,255,  244,227,228, 53, 76,243,244, 53,  0,104, 53,  0,  124,204,220,236"

ms_damage_table={}

for i=1,#ms_damage_keys do
  ms_damage_table[ms_damage_keys[i]]=ms_damage_values[i]
end

function ms_check_damage(si,mx,my)
 local damaged_tile=ms_damage_table[si]
 
 local x,y=8*mx+4,8*my+4
 
 if damaged_tile then
  mset(mx,my,damaged_tile)
  
  ms_debris(x,y,.4,.4,4,.25,.5)
  p_score+=5
  
  sfx(1)
 end

 explosion(x,y,damaged_tile and .6 or .3)
 
end

--[[]]
function make_pb(t,x,y,vx,vy)
 local l=entities[layer_pbs]
 
 local e=
 {
  t=t,
  x=x,
  y=y,
  vx=vx,
  vy=vy,
  l=l,
  lt=t,
  
  damage_enemy=function(e,v)
   v:damage()
   
   local hw,hh=v.cc and 0 or .5*(v.w or 8),v.cc and 0 or .5*(v.h or 8)
   
   local x,y=v.x+hw,v.y+hh
   
   if v.health<=0 then
    explosion(v.x+hw,v.y+hh,v.last_boss and 6 or v.boss and 2.4 or v.core and 1.6 or .8)
   else
    explosion(e.x,e.y,.3)
   end
  end,
  
  check_hits=function(e,l)
   for k,v in pairs(l) do
    if not v.offcam then
     local w,h=v.w or 8,v.h or 8
      
     if v.et and v.et.check_hits then
      if(v.et.check_hits(v,e))return true
      elseif v.cc then
      local hw,hh=w*.5,h*.5
      -- enemy is setup as centered collision (x,y in the middle)
      if e.x<=v.x+hw and
          e.x>=v.x-hw and
          e.y<=v.y+hh and
          e.y>=v.y-hh then
        e:damage_enemy(v)
        return true
      end
      else
      if e.x<=v.x+w and
          e.x>=v.x and
          e.y<=v.y+h and
          e.y>=v.y then     
        e:damage_enemy(v)
        return true
      end
     end
    end
   end
  end,
  
  update=function(e)
   e.t-=one_frame
   
   if e.x<p_x-128 or e.x>p_x+128 or e.y<p_y-128 or e.y>p_y+128 or e.t<=0 then
    del(e.l,e)
   else
    e.x+=e.vx*one_frame*60
    e.y+=e.vy*one_frame*60

    if not g_last_boss_killed then
      -- check enemy hits
      --[[
      local hit=e.check_hits(e,entities[layer_enemies])
      if(not hit)hit=e.check_hits(e,entities[layer_enemy_tentacles])
      if(not hit)hit=e.check_hits(e,entities[layer_enemy_minions])
      --]]
      local hit=e.check_hits(e,entities[layer_enemies]) or
                e.check_hits(e,entities[layer_enemy_tentacles]) or
                e.check_hits(e,entities[layer_enemy_minions])
      
      if not hit then
        -- collision with world
        if mappixel(e.x,e.y)!=0 then
          hit=true
          local mx,my=mxy(e.x,e.y)
          local si=mget(mx,my)
          ms_check_damage(si,mx,my)
        end
      end
      
      if(hit)del(e.l,e)
    end
   end
  end,
 
  draw=function(e)
   if e.t%.05>.025 then
    pal(8,10)
    pal(10,8)
   end

   local lsize=1+p_power/2
   local x,y=e.x,e.y
   line(x,y,x-2*lsize*e.vx,y-2*lsize*e.vy,8)
   line(x,y,x-lsize*e.vx,y-lsize*e.vy,10)
   
   pal(8,8)pal(10,10)
   spr(105,x-2,y-2)
  end,
 }
 
 make_circle(layer_player_fx,.2+rnd(.2),x+2*vx,y+2*vy,0,0,4,0,explosion_colors)
  

 add(l,e)
 
 return e
end
--]]

function make_camera()
 return
 {
   init=function(e)
    cam_x,cam_y=p_x-56,p_y-72
    cam_tx,cam_ty=cam_x,cam_y
    cam_offship_enemy_spawn_t=1
   end,
   
   check_spawn_enemies=function(e)
    for i=p_x,p_x+128,8 do
     for j=0,255,8 do
      local mx,my=mxy(i,j)
      local si=mget(mx,my)
      if fget(si,7) then
        local layer=fget(si,6) and layer_enemy_tentacles or layer_enemies
        make_enemy(layer,si,i,j,nil,false)
        mset(mx,my,0)
      end
     end
    end
    
    if ui_game_started then
     -- if on top or on bottom, spawn some flyers...
     if cpu<.8 then
      if p_x<900 then
        if p_x<-64 or p_y<32 or p_y>224 then
          cam_offship_enemy_spawn_t=max(0,cam_offship_enemy_spawn_t-one_frame)
          
          if cam_offship_enemy_spawn_t<=0 then
            cam_offship_enemy_spawn_t=1+rnd()
            
            make_enemy(layer_enemy_minions,168,cam_x+128,p_y+32-rnd(64),nil,true)
          end
        end
      end
     end
    end
   end,

   update=function(e)
    if ui_game_started then
     cam_tx=p_x+(p_flip and -88 or -40)
     cam_x+=.05*(cam_tx-cam_x)

     if(cam_tx<-115)p_vx=max(.2,p_vx)
     
     cam_ty=p_y-64
     cam_y+=.05*(cam_ty-cam_y)
     
     cam:check_spawn_enemies()
    end
   end,
   
   draw=function(e)
    local camx,camy=cam_x,cam_y

    if not btn(4) and not ui_power_up_dialog then
      if(p_knockback_t>.8 or p_shake_ground_t>0)camx+=1-rnd(2) camy+=1-rnd(2)
    end

    camera(camx,camy)
    clip(0,8,128,112)
    
    if(t()%.1>.05)pal(7,10)
    if not g_last_boss_killed then
      map(0,0,0,0,128,32,0x03)

      local x1,y1,x2,y2=-400,-g_ms_fudge,1056+g_ms_fudge,256+g_ms_fudge
      pat={0b0.1,0b0000001000001000.1,0b0101101001011010.1,0b0111111111011111.1}
      
      for i=1,4 do
        fillp(pat[i])
        rectfill(x1,y1-128,x2+128,y1+(i-1)*16,0)
        rectfill(x1,y2-(i-1)*16,x2+128,y2+128,0)
      end

      fillp()
    end
    reset_pal()

    --print(""..cam_x,cam_x,cam_y+16,7)
   end,
 }
end

function scan_text(text)
  scan={}
  rectfill(0,0,#text*4+1,7,0)
  print(text,0,0,1)
  for y=0,7 do
    scan[y]={}
    for x=0,#text*4+1 do
      scan[y][x]={c=pget(x,y),x=256+rnd(256),y=-128+rnd(384),vx=1-rnd(2),vy=1-rnd(2)}
    end
  end
  return scan
end

title_text=scan_text("grandmothership")

--
function draw_title_text(text,x,y)
 
 for j=0,#text do
  local row=text[j]
  for i=0,#row do
   local p=row[i]
   
   local cs=p.c
   if cs!=0 then
    
    local tx,ty=x+i*2,y+j*3
    
    if ui_game_started then
     tx,ty=x+i*2-256,y+j*3
     p.vx+=-1
    else
     tx,ty=x+i*2,y+j*3
     local nx,ny,m=normalize(tx-p.x,ty-p.y)
     p.vx=mid(-5,p.vx+min(m,.3)*nx,5)
     p.vy=mid(-5,p.vy+min(m,.3)*ny,5)
     p.vx*=.95
     p.vy*=.95
     
     if m<1 then
      p.vx=0 p.vy=0
      p.x=tx p.y=ty
     end
    end
    
    p.x+=p.vx*one_frame*60
    p.y+=p.vy*one_frame*60
    
    rectfill(p.x-1,p.y-1,p.x+3,p.y+4,3)
   end
  end
 end
 
 local colors=split"5,5,5,5,5,5,11,6,7,7,7,6,6,6,11,11,5,5,5,5,5,5,5"
 
 for j=0,#text do
  local row=text[j]
  for i=0,#row do
   local p=row[i]
   
   local cs=p.c
   if cs!=0 then
    for k=0,3 do
     local c=colors[1+flr(j*3+k+40*ui_title_time)%#colors]
     line(p.x,p.y+k,p.x+2,p.y+k,c)
    end
   end
  end
 end
end

function ui_power_up_valid()
  return ui_power_up_selection==1 or
         ui_power_up_selection==2 and p_option_count<3 or
         ui_power_up_selection==3 and p_power<5 or
         ui_power_up_selection==4 and p_rate>.175 or
         ui_power_up_selection==5 and p_max_s<2
end

function ui_power_up_verify()
  while not ui_power_up_valid() do
    ui_power_up_selection+=1
    if(ui_power_up_selection>5)ui_power_up_selection=1
  end
end

function ui_power_up_next()
  repeat
    ui_power_up_selection+=1
    if(ui_power_up_selection>5)ui_power_up_selection=1
  until ui_power_up_valid()
end

function ui_power_up_prev()
  repeat
    ui_power_up_selection-=1
    if(ui_power_up_selection<1)ui_power_up_selection=5
  until ui_power_up_valid()
end

function make_ui()
 return
 {

  init=function(e)
    ui_game_started,ui_game_time,ui_title_time=false,0,0
  end,
  
  update=function(e)
   if not ui_game_started then
    if ui_title_time>1 and btn(4) and btn(5) then
      music(0,1000,3)
      ui_game_started=true
    end
   end
   
   if g_gameover then
    g_gameover_t=max(0,g_gameover_t-one_frame)
    
    if g_gameover_t<=0 then
     if btnp(4) or btnp(5) then
      run()
     end
    end
   end

   if g_last_boss_killed then
    g_last_boss_killed_t=max(0,g_last_boss_killed_t-one_frame)
   end

  --[[ debug temp stuff
  --if btnp(4,1) then
  --  ui_power_up_dialog,ui_power_up_dialog_t=true,.5
  --  ui_power_up_verify()
  --end
  if btnp(5,1) then
    p_shield,p_option_count,p_power,p_rate,p_max_s=31,3,5,.15,2 -- max powers
  end
  --]]

   if ui_power_up_dialog then
    if(btnp(2))ui_power_up_prev()
    if(btnp(3))ui_power_up_next()

    ui_power_up_dialog_t=max(0,ui_power_up_dialog_t-1/stat(8))

    if ui_power_up_dialog_t<=0 and btnp(5) then
      ui_power_up_dialog=false
      if ui_power_up_selection==1 then
        p_shield+=1
      elseif ui_power_up_selection==2 then
        p_option_count+=1
      elseif ui_power_up_selection==3 then
        p_power+=.5
      elseif ui_power_up_selection==4 then
        p_rate-=.05
      elseif ui_power_up_selection==5 then
        p_max_s+=.25
      end
    end
   end
   
   if ui_game_started and not g_gameover and not g_last_boss_killed and not ui_power_up_dialog then
    ui_game_time+=one_frame
   elseif not ui_game_started then
    ui_title_time+=one_frame
    if(ui_title_time>30000)ui_title_time=10
   end
  end,
 
  draw_title=function(e,c,oc)
   if ui_game_time<3 then

    ease=ui_game_started and 1-2*max(0,.5-ui_game_time) or 2*max(0,.5-ui_title_time)
    
    local x=ui_game_started and 128*ease*ease or -128*ease*ease
    printb("storming",64-x,16,7,0,align_c) 
    printb("the",64-x*3,24,7,0,align_c)
    draw_title_text(title_text,4,32)
    
    if ui_title_time>3 then
      printb("z+x to start",64-x,104,ui_title_time%.2>.1 and 7 or 5,0,align_c)
      printb("z:aim",44-x,92,7,0,align_c)
      printb("x:shoot",84-x,92,7,0,align_c)
      printb("@picoter8 2021",64-x,114,7,0,align_c) 
    end
   end
  end,
  
  draw=function(e)
   camera()
   if ui_power_up_dialog then
    d=max(0,ui_power_up_dialog_t^3)
    y=40+d*88
    --fillp(0b0101101001011010.1)
    --rectfill(22,y-4,104,y+44,3)
    --fillp()
    rect(23,y-3,103,y+43,3)
    rect(22,y-4,104,y+44,7)
    printb(">",42,y+1+ui_power_up_selection*7,7,0)
    printb("- choose power-up -",64,y,7,0,align_c)y+=8
    printb("+shield",47,y,7,0)y+=7
    printb("+multiple",47,y,p_option_count<3 and 7 or 5,0)y+=7
    printb("+power",47,y,p_power<5 and 7 or 5,0)y+=7
    printb("+rate",47,y,p_rate>.175 and 7 or 5,0)y+=7
    printb("+speed",47,y,p_max_s<2 and 7 or 5,0)y+=7
   end

   e:draw_title(c,oc)
   
   if not ui_game_started then
    
   elseif g_gameover then
    printb("- game-over -",64,64,7,0,align_c)
    
    if g_gameover_t<=1 then
     printb("press \142 or \151",61,76,7,0,align_c)
     printb("to try again",64,82,7,0,align_c)
    end
   elseif g_last_boss_killed_t<=1 then
    printb("- grandmothership destroyed -",64,32,7,0,align_c)
    printb("thanks for playing",64,44,7,0,align_c)
   end
  end,
 }
end


--[[]]
function make_eb(t,x,y,vx,vy,s)
 if(g_last_boss_killed)return

 local l=entities[layer_ebs]
 
 local e=
 {
  t=t,
  x=x,
  y=y,
  vx=vx,
  vy=vy,
  s=s,
  l=l,
  lt=t,
  
  update=function(e)
   e.t-=one_frame
   if e.t<=0 then
    del(e.l,e)
    explosion(e.x,e.y,.3)
   else
    e.x+=e.vx*one_frame*60
    e.y+=e.vy*one_frame*60

    local x,y=e.x,e.y
    
    -- check player damage
    if p_knockback_t<=0 and not g_gameover and not g_last_boss_killed then
     if p_x-3<=x and
        p_x+3>=x and
        p_y-3<=y and
        p_y+3>=y then
      p:damage()
      del(e.l,e)
     end
    end
    
    -- collision
    if mappixel(x,y)!=0 then
     del(e.l,e)
     explosion(x,y,.3)
    end
   end
  end,
 
  draw=function(e)
   local t=time()%.2>.1
   circfill(e.x,e.y,s+1,t and 12 or 8)
   circfill(e.x,e.y,s,t and 8 or 12)
  end,
 }
 
 add(l,e)
 
 return e
end
--]]

function e_seeker_update(e)
 local nx,ny=normalize(p_x-e.x,p_y-e.y)
 
 e.vx+=nx*e.a*one_frame*60
 e.vy+=ny*e.a*one_frame*60
 
 local nx,ny,m=normalize(e.vx,e.vy)
 
 if m>e.maxv then
  e.vx,e.vy=e.maxv*nx,e.maxv*ny
 end
 
 e.x+=e.vx*one_frame*60
 e.y+=e.vy*one_frame*60
end

function e_trail_particles(e,ox)
 if e.npt<e.t then
  e.npt=e.t+.1
  make_circle(layer_enemy_fx,.2+rnd(.5),e.x+6-rnd(4)+ox,e.y+6-rnd(4),0,0,1+rnd(),0,explosion_colors)
 end
end

function e_draw_anim(e,count)
 e.anim_i=flr(e.si+8*e.t%count)
 spr(e.anim_i,e.x,e.y,1,1,e.vx and e.vx>0)
end

function e_draw_anim1(e)
 spr(e.si,e.x,e.y,1,1,e.vx and e.vx>0)
end

function e_draw_anim3(e)
 e_draw_anim(e,3)
end

function e_draw_anim3_nomirror(e)
 e.anim_i=flr(e.si+8*e.t%3)
 spr(e.anim_i,e.x,e.y)
end

function update_spread_turret(e,x,y,count,speed,lifetime)
  if e.t>=e.nt then
    e.nt=e.t+3
    sfx(4)

    for i=1,count do
      local nx,ny=polar_to_xy(speed,i/count+e.t)
      make_eb(lifetime,x,y,nx,ny,1)
    end
  end
end

function blink_shooting_color(etime)
  pal(8,etime%.1>.05 and 8 or 10)
  --pal(9,etime%.1>.05 and 9 or 8)
  --pal(10,etime%.1>.05 and 10 or 8)
end

function make_spread_turret(count,speed,lifetime,health)
 return
 {
  init=function(e)
   e.health=health
   e.a=e.x%128/128
   e.nt=1.5
  end,
  
  update=function(e) update_spread_turret(e,e.x+4,e.y+4,count,speed,lifetime) end,
  
  draw=function(e)
   if e.t>=e.nt-.5 then
    blink_shooting_color(e.t)
    --pal(8,e.t%.1>.05 and 8 or 10)
   end
   
   e_draw_anim1(e)
   
   pal(8,8)
  end,
 }
end

-- shooting rate time, shooting rate time random, shooting time, wait time
function make_targeting_turret(srt,srtr,st,wt,health)
 return
 {
  init=function(e)
   e.health=health or 4
   e.wt=wt/2
   e.st=0
   e.nt=srt+rnd(srtr)
   e.nx,e.ny,e.m=normalize(p_x-e.x-4,p_y-e.y-4)
  end,
  
  update=function(e)
   e.nx,e.ny,e.m=normalize(p_x-e.x-4,p_y-e.y-4)
   
   if e.wt>0 then
    e.wt=max(0,e.wt-one_frame)
    
    if e.wt<=0 then
     e.st=st
    end
   elseif e.st>0 then
    e.st=max(0,e.st-one_frame)
    if e.st<=0 then
     e.wt=wt
    end
   end
   
   if (st==0 or e.st>0) and e.t>=e.nt then
    e.nt=e.t+srt+rnd(srtr)
    sfx(4)
    
    local speed=.6
    make_eb(5,e.x+3.5+6.5*e.nx,e.y+3.5+6.5*e.ny,speed*e.nx,speed*e.ny,1)
   end
  end,
  
  draw=function(e)
    --local c=e.t%.1>.05 and 8 or 10

    if st>0 then
      if e.wt<=.5 then
        blink_shooting_color(e.t)
        --pal(8,c)
      end
    else
      if e.t>=e.nt-.5 then
        blink_shooting_color(e.t)
        --pal(8,c)
      end
    end

    e_draw_anim1(e)

    local x1,y1=e.x,e.y
    local x2,y2=x1+5.5*e.nx,y1+5.5*e.ny

    for i=3,4 do
     for j=3,4 do
      line(x1+i,y1+j,x2+i,y2+j,8)
     end
    end
    
    pal(8,8)
  end
 }
end

function make_tentacle(ba,size)
 return
 {
  init=function(e)
   e.size,e.ba,e.aa,e.ta,e.offcam_w=size,ba,0,0,56
   e.score=50

   e.parts={}
   for i=1,e.size do
    add(e.parts,{ba=0,ra=0,x=e.x+3,y=e.y+3,active=(i==e.size)})
   end
   
   e.active_part_i=size

   -- shooting
   e.nt=1.5
  end,
  
  check_hits=function(e,b)
   
   for i=e.active_part_i,1,-1 do
    local p=e.parts[i]
    
    if p then
     local bx,by=b.x,b.y

     -- enemy is setup as centered collision (x,y in the middle)
     if bx<=p.x+4 and
        bx>=p.x-4 and
        by<=p.y+4 and
        by>=p.y-4 then
      if i==e.active_part_i then
       e.active_part_i-=1

       e.blink_t=.1
       
       if e.active_part_i<=1 then
        b:damage_enemy(e)
        e:kill()
        explosion(bx,by,.8)
       else
        explosion(bx,by,.6)
       end
      else
       explosion(bx,by,.3)
      end
      
      return true
     end
    end
   end
   
   return false
  end,
  
  update=function(e)

   local ap=e.parts[e.active_part_i]
   if(ap)update_spread_turret(e,ap.x,ap.y,8,.3,5)

   e.nx,e.ny,e.m=normalize(p_x-e.x+4,p_y-e.y+4)
   
   if e.m<128 then
    local a_to_p=atan2(e.nx,e.ny)
    local tta=angle_fix(a_to_p-e.ba)
    if abs(tta)<.375 then
     e.ta=tta
     e.ta*=1-e.m/128
     e.ta=mid(-.15,e.ta,.15)
    end
   end
   
   e.aa+=.1*angle_fix(e.ta-e.aa)
   
   local lx,ly=e.x+4,e.y+4
   local dist=4

   for i=2,e.active_part_i do
    local lpart,part=e.parts[i-1],e.parts[i]

    part.ra=angle_fix(.1*sin(i/10-e.t)*i/(e.size*2))
  
    part.ra=mid(-.05,part.ra,.05)
   
    part.ba=lpart.ba+part.ra
    
    local dx,dy=polar_to_xy(dist,part.ba+e.ba+2*e.aa*i/e.size)
    
    part.x,part.y=lx+dx,ly+dy
    lx,ly=part.x,part.y

    -- check player damage
    if p_knockback_t<=0 and not g_gameover and not g_last_boss_killed then
     if p_x-3<=lx+2 and
        p_x+3>=lx-2 and
        p_y-3<=ly+2 and
        p_y+3>=ly-2 then
      p:damage()
     end
    end    

   end
  end,
  
  draw=function(e)
   if e.blink_t>0 then
    blink_pal()
   end

   if e.t>=e.nt-.5 then
    blink_shooting_color(e.t)
    --pal(8,e.t%.1>.05 and 8 or 10)
   end   

   e_draw_anim1(e)
   
   for i=1,e.active_part_i do
    local part=e.parts[i]
    spr(i==e.active_part_i and 129 or 145,part.x-3,part.y-3)
    --[[
    circfill(part.x,part.y,3,3)
    circfill(part.x,part.y,2,5)
    circfill(part.x,part.y,1,(i==e.active_part_i) and 8 or 6)
    --]]
   end

   reset_pal()
  end
 }
end

function make_enemy_spawner(spawnee,sr)
return 
{
 init=function(e)
  e.health,e.score=16,20
  e.sr=sr+rnd()
  e.nst=e.sr/2
 end,
 
 update=function(e)
  e.nst=max(0,e.nst-one_frame)
  
  if e.nst<=0 then
   e.nst=e.sr
   if cpu<.8 then
    sfx(3)
    make_enemy(layer_enemy_minions,spawnee,e.x-4,e.y,e,true)
   end
  end
 end,
 
 draw=function(e)
  e.anim_i=e.si

  if e.nst<.2 then
   e.anim_i+=2
  elseif e.nst>e.sr-.2 then
   e.anim_i+=1
  end

  spr(e.anim_i,e.x,e.y)
 end,
}
end

function core_draw(e,colors)
  local cc=e.nst>0.5 and 8 or e.t%.1>.05 and 8 or 10

  local x,y=e.x,e.y
  local hw=.5*e.w

  local a,da=0,.25/6

  local nx,ny=normalize(p_x-x,p_y-y)

  local offsets=split"0,0,0,.05,.15"
  for i=1,5 do
    circfill(x+offsets[i]*hw*nx,y+offsets[i]*hw*ny,hw*cos(a),colors[i]) a+=da
  end

  circfill(x+.3*hw*nx,y+.3*hw*ny,max(2,hw*cos(a)),cc) a+=da
--]]
end

function make_mini_core(ox,oy)
 return
 {
  init=function(e)
   g_core_count+=1

   e.x+=ox
   e.y+=oy
   e.health,e.score=10+5*g_core_count,100
   e.minion_health=10
   e.core=true

   -- centered collision
   e.cc=true
   
   -- spawner stuf
   e.sr=4+rnd()
   e.nst=e.sr

  end,
  
  update=function(e)
   e.minion_health=e.health/8

   local size=8+e.health/4
   e.w,e.h=size,size
   e.offcam_w=e.w/2
   
   -- spawner stuff
   e.nst=max(0,e.nst-one_frame)
  
   if e.nst<=0 then
    e.nst=e.sr
    if cpu<.8 then
     sfx(3)
     make_enemy(layer_enemy_minions,154,e.x,e.y,e,true)
    end
   end
  end,
  
  draw=function(e) core_draw(e,split"3,5,11,6,7") end,
 }
end

function boss_shoot_chain(e)
  e.minion_health=5
  local hw=.5*e.w
  for i=0,12 do
    local ni=i/12
    e.minion_initv=.6+.6*abs(ni-.5)
    e.minion_maxv=e.minion_initv
    local x,y=e.x+hw*cos(ni),e.y+hw*sin(ni)
    make_enemy(layer_enemy_minions,154,x,y,e,true)
  end
end

function boss_circles(e)
  e.minion_health,e.minion_initv,e.minion_maxv=20,.6,1
  local hw=.5*e.w
  for i=0,6 do
    local x,y=e.x+hw*cos(i/6),e.y+hw*sin(i/6)
    make_enemy(layer_enemy_minions,154,x,y,e,true)
  end
end

function boss_single_circ(e)
  e.minion_health=60
  make_enemy(layer_enemy_minions,154,e.x,e.y,e,true)
end

function boss_reset_minion(e)
  e.minion_expire,e.minion_health,e.minion_initv,e.minion_maxv=5,nil,nil,nil
end

function make_boss_core()
 return
 {
  init=function(e)
   e.w,e.h=32,32
   e.x,e.y=e.x+8,e.y+8
   e.health,e.score=600,250
   e.boss=true

   -- centered collision
   e.cc=true
   
   -- spawner stuf
   e.sr,e.nst=3,1.5

  end,
  
  update=function(e)
   local size=16+e.health/16
   e.w,e.h=size,size
   e.offcam_w=e.w/2
   
   -- spawner stuff
   e.nst=max(0,e.nst-one_frame)
  
   if e.nst<=0 then
    e.nst=e.sr
    if cpu<.8 then
      boss_reset_minion(e)
      sfx(3)
      local shot_types={boss_single_circ,boss_circles,boss_shoot_chain}
      rnd(shot_types)(e)
    end
   end
  end,
  
  draw=function(e) core_draw(e,split"8,5,11,6,7") end,
 }
end


function make_last_boss()
 return
 {
  init=function(e)  
   e.w,e.h=0,0
   e.x+=8
   e.y+=8
   e.health,e.score=1000,1000
   e.last_boss=true

   -- centered collision
   e.cc=true
   
   -- spawner stuf
   e.sr,e.nst=2,1
  end,
  
  update=function(e)
   if(g_boss_cores_killed<4)return
   g_boss_cores_killed_t=max(0,g_boss_cores_killed_t-one_frame)

   local size=16+(1000-e.health)/12
   if(g_boss_cores_killed_t>0)size=16*(1-g_boss_cores_killed_t)
   e.w,e.h=size,size
   e.offcam_w=e.w/2
   
   -- spawner stuff
   e.sr=.25+1.75*e.health/1000
   e.nst=max(0,e.nst-one_frame)
  
   if e.nst<=0 then
    e.nst=e.sr
    if cpu<.8 then
      boss_reset_minion(e)
      local shot_types={boss_single_circ,boss_circles,boss_shoot_chain}
      rnd(shot_types)(e)
    end
   end
  end,
  
  draw=function(e) 
    if(g_boss_cores_killed<4)return
    core_draw(e,split"4,8,9,10,7") 
  end,
 }
end

enemy_types=
{
 [128]=make_boss_core(),
 [144]=make_last_boss(),

 --[[ mini-core ]]
 [139]=make_mini_core(8,8),
 [140]=make_mini_core(0,8),
 [155]=make_mini_core(8,0),
 [156]=make_mini_core(0,0),
 
 [131]=make_tentacle(.75,14),
 [163]=make_tentacle(.5,14),
 [147]=make_tentacle(0,14),
 [179]=make_tentacle(.25,14),

 [191]=make_targeting_turret(2,2,0,0),
 [175]=make_targeting_turret(2,2,0,0),
 [174]=make_targeting_turret(2,2,0,0),
 
 [79]=make_spread_turret(12,.2,5,8),
 [141]=make_spread_turret(6,.4,5,4),
 
 [142]=make_targeting_turret(.05,.05,.5,2),
 [143]=make_targeting_turret(.05,.05,.5,2),
 [158]=make_targeting_turret(.05,.05,.5,2),
 [159]=make_targeting_turret(.05,.05,.5,2),

 [78]=make_targeting_turret(.1,.1,2,1,16),
 [94]=make_targeting_turret(.1,.1,2,1,16),
 
 --[[slow follower bubble - shot by mini-core]]
 [154]=
 {
  init=function(e)
   e.a=.004
   e.maxv=e.ep.minion_maxv or .4
   e.vx,e.vy=0,0
   local initv=e.ep.minion_initv
   if initv then
    local nx,ny=normalize(p_x-e.x,p_y-e.y)
    e.vx,e.vy=initv*nx,initv*ny
   end
   
   e.health=e.ep.minion_health
   e.w,e.h=e.ep.w,e.ep.h
   
   -- centered collision
   e.cc=true

   e.expire_t=e.ep.minion_expire or 10
  end,
  
  update=function(e)
   local size=4+e.health

   if e.t<.2 then
    size*=e.t/.2
   elseif e.expire_t-e.t<.2 then
    size*=(e.expire_t-e.t)/.2
   end

   e.w,e.h=size,size
   
   e_seeker_update(e)
  end,
  
  draw=function(e)
   local x,y,hw,c=e.x,e.y,.5*e.w,e.t%.1>.05 and 8 or 12
   
   --circ(x,y,hw,c)
   --circ(x-1,y,hw,c)
   oval(x-hw,y-hw,x+hw,y+hw,c)
   oval(x-1-hw,y-hw,x-1+hw,y+hw,c)

  end,
 },
 
 -- big thruster
 [157]=
 {
  init=function(e)
   e.h,e.health=16,40
   e.sr,e.nst=6,6
  end,
  
  update=function(e)
   e.nst=max(0,e.nst-one_frame)
   
   if e.nst<=1 then
    sfx(8)
    p_shake_ground_t=e.nst
    
    -- check player damage
    if p_knockback_t<=0 and not g_gameover and not g_last_boss_killed then
     if p_x-3<=e.x and
        p_x+3>=e.x-256 and
        p_y-3<=e.y+13 and
        p_y+3>=e.y+2 then
      p:damage()
     end
    end    
   end
   
   if e.nst<=0 then
    sfx(8,-2)
    e.nst=e.sr
   end
  end,
  
  draw=function(e)
   local s=sin(e.t*5)
   local x,y=e.x,e.y
   
   if e.nst<1 then
    rectfill(x,y+2,x-256,y+13,8)
    rectfill(x,y+4,x-256,y+11,9)
    rectfill(x,y+7-s,x-256,y+9+s,10)
   else
    circfill(x,y+7,s+4.5,8)
    circfill(x,y+8,s+4.5,8)
    
    if e.nst<2 then
     fillp(e.t%.1>.05 and 0b1111011111111101.1 or 0b1111110111110111.1)
     rectfill(x,y+2,x-256,y+13,10)
     fillp()
    end
   end
   
   circfill(x,y+7,s+3.5,10)
   circfill(x,y+8,s+3.5,10)
   
   spr(e.si,x,y,1,2)
  end,
 },
 
 -- r-type style flyer
 [168]=
 {
  init=function(e)
   e.by=e.y
   e.health=1
   e.sin,e.t,e.npt,e.expire_t=0,0,0,10
  end,
 
  update=function(e)
   e.sin=sin(e.t/2+e.x/128+e.y/256)
   
   local mag_y=min(12,16*e.t)
   
   e.y=e.by+mag_y*e.sin
   e.x-=.5*60*one_frame
   
   e_trail_particles(e,2)
  end,
  
  draw=function(e) 
   e.anim_i=flr(e.si+2.5-2*e.sin)
   spr(e.anim_i,e.x,e.y,1,1,e.vx and e.vx>0)
  end,
 },
 
 -- enemy spawner
 [184]=make_enemy_spawner(168,6),
 [187]=make_enemy_spawner(136,6),
 
--[[ player seeker ]]
 [136]=
 {
  init=function(e)
   e.a,e.maxv=.004,.4
   e.health,e.vx,e.vy=4,0,0
   e.npt,e.expire_t=e.t,10
  end,
  
  update=function(e)
   e_seeker_update(e)
   e_trail_particles(e,0)
  end,
  
  draw=e_draw_anim3,
 },
--]]
}

function make_enemy(el,si,x,y,ep,minion)
 if(g_last_boss_killed) return

 local mx,my=mxy(x,y)
 local mi=my*128+mx
 
 local l=entities[el]
 
 --check if we've already spawned this enemy
 if(not minion and ep==nil and l[mi])return
 
 local e=
 {
  l=l,
  et=enemy_types[si],
  mi=(ep==nil and mi or -1),
  anim_i=mi,
  si=si,
  t=0,
  x=x,
  y=y,
  ep=ep,
  minion=minion,
  
  health=4,
  offcam=false,
  
  blink_t=0,
  
  kill=function(e,no_sound)
    if e.ep or e.minion then
      del(e.l,e)
    else
      if(e.mi>=0)e.l[e.mi]=nil
      p_score+=e.score or 10
    end  

    if e.core then
      sfx(7)
      g_killed_core_count+=1

      -- killed a core, open dialog to chose power-up
      ui_power_up_dialog,ui_power_up_dialog_t=true,1
      ui_power_up_verify()
    elseif e.boss then
      sfx(9)
      g_boss_cores_killed+=1
      if(g_boss_cores_killed>=4)g_boss_cores_killed_t=1
    elseif e.last_boss then
      sfx(9)
      g_last_boss_killed,g_last_boss_killed_t=true,2
      level_kill_all()
    else
     if(not no_sound)sfx(1)
    end

  end,
  
  damage=function(e)
   if e.health>0 then
    e.health-=p_power
    e.blink_t=.1
   end
   
   if e.health<=0 then
    e:kill()
   else
    sfx(6)
   end 

   return true
  end,
  
  update=function(e)
   e.t+=one_frame
   e.blink_t=max(0,e.blink_t-one_frame)

   -- check and kill if out of bounds
   local fudge=2*g_ms_fudge
   if e.x<-256-fudge or 
      p_x>1024+fudge or 
      p_y<-fudge or 
      p_y>256+fudge then
    e:kill(true)
   end
   
   if e.expire_t and e.t>e.expire_t then
    e:kill(true)
   end

   e.offcam=false

   -- don't update out of camera enemies
   if e.t>1 then  -- give just spawned enemies at least a second of play before checking bounds
    local offcam_w=e.offcam_w or 16
    if e.x<cam_x-offcam_w or e.x>cam_x+128+offcam_w or
       e.y<cam_y-offcam_w or e.y>cam_y+128+offcam_w then
      e.offcam=true
      return
    end
   end

   if(e.et and e.et.update)e.et.update(e)

   local damages_player=not fget(e.si,6)
   
   -- player not knocked back
   if p_knockback_t<=0 and damages_player and not g_gameover and not g_last_boss_killed then
    local ex,ey,w,h=e.x,e.y,(e.w or 8)-2,(e.h or 8)-2
    
    if e.cc then
     local hw,hh=w*.5,h*.5
     -- enemy is setup as centered collision (x,y in the middle)
     if p_x-3<=ex+hw and
        p_x+3>=ex-hw and
        p_y-3<=ey+hh and
        p_y+3>=ey-hh then
      p:damage()
     end
    else
     if p_x-3<=ex+w and
        p_x+3>=ex+1 and
        p_y-3<=ey+h and
        p_y+3>=ey+1 then
      p:damage()
     end
    end
   end
  end,
 
  draw=function(e)
   if(e.offcam)return
   
   if e.blink_t>0 then
    blink_pal()
   end
   
   if e.et and e.et.draw then
    e.et.draw(e)
   else
    e_draw_anim3(e)
   end
   
   reset_pal()
  end,
 }
 
 if(e.et and e.et.init)e.et.init(e)
 
 if not minion and ep==nil then
  l[mi]=e
 else
  -- enemies with parents get added to a flat list
  add(l,e)
 end
 
 return e
end

function make_circle(el,t,x,y,vx,vy,s1,s2,colors,outlined)
 local l=entities[el]
 
 local e=
 {
  tt=t,
  t=t,
  x=x,
  y=y,
  vx=vx,
  vy=vy,
  s1=s1,
  s2=s2,
  sc=s1,
  l=l,
  colors=colors,
  outlined=outlined,
  
  update=function(e)
   e.t-=one_frame
   if e.t<=0 then
    del(e.l,e)
   else
    e.sc+=one_frame*(e.s2-e.s1)/e.tt
    e.x+=e.vx*one_frame*60
    e.y+=e.vy*one_frame*60
   end
  end,
 
  draw=function(e)
   local ci=flr(1+#e.colors*(1-e.t/e.tt))
   --local c=outlined and circ or circfill
   --c(e.x,e.y,e.sc,e.colors[ci])
   local o=outlined and oval or ovalfill
   o(e.x-e.sc,e.y-e.sc,e.x+e.sc,e.y+e.sc,e.colors[ci])
  end,
 }
 
 add(l,e)
 
 return e
end

function make_line(el,t,x,y,vx,vy,s,colors)
 local l=entities[el]
 
 local e=
 {
  tt=t,
  t=t,
  x=x,
  y=y,
  vx=vx,
  vy=vy,
  s=s,
  l=l,
  colors=colors,
  
  update=function(e)
   e.t-=one_frame
   if e.t<=0 then
    del(e.l,e)
   else
    e.x+=e.vx*one_frame*60
    e.y+=e.vy*one_frame*60
   end
  end,
 
  draw=function(e)
   local ci=flr(1+#e.colors*(1-e.t/e.tt))
   local ci2=min(#e.colors,flr(2+#e.colors*(1-e.t/e.tt)))
   line(e.x,e.y,e.x+2*e.s*e.vx,e.y+2*e.s*e.vy,e.colors[ci2])
   line(e.x,e.y,e.x+e.s*e.vx,e.y+e.s*e.vy,e.colors[ci])
  end,
 }
 
 add(l,e)
 
 return e
end

function make_button(bi)
 return 
 {
  time_since_press=100,
  last_time_held=0,
  time_held=0,
  time_released=0,
  button_index=bi,

  update=function(b)
   b.time_since_press+=one_frame

   if btn(b.button_index) then
    if b.time_held==0 then
     b.time_since_press=0
    end
  
    b.time_held+=one_frame
   else
    if(b.time_held!=0)b.time_released=0
    b.last_time_held=b.time_held
    b.time_held=0
    b.time_released+=one_frame
   end
  end,

  consume=function(b)
   b.time_since_press=100
  end,
 }
end

layer_buttons,
layer_camera,
layer_player_fx,
layer_player,
layer_post_player_fx,
layer_pbs,
layer_enemy_fx,
layer_enemies,
layer_enemy_tentacles,
layer_enemy_minions,
layer_post_enemy_fx,
layer_ebs,layer_ui
=1,2,3,4,5,6,7,8,9,10,11,12,13

entities={}

entities[layer_buttons],
entities[layer_player_fx],
entities[layer_player],
entities[layer_post_player_fx],
entities[layer_pbs],
entities[layer_enemy_fx],
entities[layer_enemies],
entities[layer_enemy_tentacles],
entities[layer_enemy_minions],
entities[layer_post_enemy_fx],
entities[layer_ebs],
entities[layer_camera],
entities[layer_ui]
={},{},{},{},{},{},{},{},{},{},{},{},{}


function _init()
 music(56,0,3)

 background_high=dget(0)
 background_count=background_high==0 and 200 or 100

 menuitem(1,background_high==0 and "background:high" or "background:low",
  function()
    background_high=background_high==0 and 1 or 0
    background_count=background_high==0 and 200 or 100
    dset(0,background_high)
    menuitem(_,background_high==0 and "background:high" or "background:low")
    return true
  end)
 
 punch_b=make_button(5)
 add(entities[layer_buttons],punch_b)
 
 p=make_player()
 p:init()
 add(entities[layer_player],p)
 
 cam=make_camera()
 cam:init()
 add(entities[layer_camera],cam)
 
 ui=make_ui()
 ui:init()
 add(entities[layer_ui],ui)

 background={}
 
 -- background
 for i=1,200 do
  add(background,{x=rnd(512),y=flr(rnd(512)),vx=0,mvx=.1+rnd(10)}) 
 end
end

--[[]]
function level_kill_all()
 entities[layer_enemies],
 entities[layer_enemy_tentacles],
 entities[layer_enemy_minions],
 entities[layer_ebs]={},{},{},{}
end
--]]

function background_draw()
  local colors=background_high==0 and split"15,3,5,11,6,7" or split"15,3,5"
  local cy=cam_y+128 -- background lines go from [0 to 512]
  
  for i=1,background_count do
    local v=background[i]
    local y=v.y-flr(cy*mid(0,v.mvx/10,1))
    --local c=colors[min(flr(1+.5*v.mvx),#colors)]
    line(v.x,y,v.x+v.vx*5,y,g_last_boss_killed and rnd(16) or colors[min(flr(1+.5*v.mvx),#colors)])
    --print(""..c,v.x,v.y,7)
  end

 --print(""..cam_y,0,16,7) -- -128 -> 256
end

function _update60()
 --[[]]
 if g_gameover then
  g_time_scale=1
 else
  if not btn(4) and not ui_power_up_dialog then
   if(g_time_scale<1)g_time_scale=min(1,g_time_scale+.05)
  else
   local scale=0
   if(g_time_scale>scale)g_time_scale=max(scale,g_time_scale-.1)
  end
 end
 --]]
 
 one_frame=g_time_scale/stat(8)

 local extra_vx=ui_game_started and 0 or 4
 
 --for k,v in pairs(background) do
 for i=1,background_count do
  local v=background[i]
  v.vx=(extra_vx+v.mvx)*one_frame*60
  v.x-=v.vx
  if v.x<-40 then
   v.x,v.y=128+40,flr(rnd(512))
  end
 end

 for i=1,#entities do 
  for k,v in pairs(entities[i]) do
   if(v.update)v:update()
  end
 end

end

--
function blink_pal()
  pal(split"1,6,10,4,9,10,8,7,9,10,9,12,13,14,15")
end

--
function reset_pal()
 pal()
 pal(3,0xf5,1)
 pal(11,0xf6,1)
 pal(15,0xf0,1)
end

--
function _draw()
 cls()

 reset_pal()
 
 camera()
 clip(0,8,128,112)

 background_draw()
 
 for i=1,#entities do 
  for k,v in pairs(entities[i]) do
   if(v.draw)v:draw()
  end
 end
 
 camera()
 clip()
 
 if ui_game_started then
  printa("00000",21,1,3,align_r)
  printa(""..p_score,21,1,7,align_r)
  printa(time_to_text(ui_game_time),128,1,7,align_r)

  if p_shield<=1 and t()%.2>.1 then
    rect(0,7,127,120,8)
    rect(1,8,126,119,8)
  end

  for i=3,126,4 do
    spr((i-3)/4<p_shield and 112 or 113,i,122)
  end
 end

 
 cpu=stat(1)
 
 --[[debug
 y=122
 color(7)
 --printb("p:("..p.x..","..p.y..")",1,y,0,6)y-=6
 --]]
end
