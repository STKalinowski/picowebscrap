--violet
--by lily.kensa

--⬆️⬆️⬇️⬇️⬅️➡️⬅️➡️❎🅾️

function hack()
	--spikes 13 14 29 30
	fset(13,4,false)
	fset(14,4,false)
	fset(29,4,false)
	fset(30,4,false)
end

function apoke(a,b)
	poke(0x5f10+a,128+b-16)
end

function init_color()
	poke(0x5f2e,1)
	apoke(1,27)
	apoke(3,21)
	apoke(14,24)
	apoke(10,22)
	apoke(11,18)
	apoke(4,17)
	apoke(13,19)
	--apoke(9,20)
end

-->8
-- game loop

function _init()
	start=false
	starting=false
	swap=false
	c={}
	crystal={}
	p={}
	particles={}
	s={}
	snow={}
	timer={
		init=0,
		gap=0,
		m=0,
		s=0,
		goal=false,
		gtime=32767,
		waste=0,
		length=0
	}
	title={
		value=0,
		target=0,
		select=0,
		pressed=0,
		hack=1,
		last=1,
		dark=0,
		input={
			u=false,
			d=false,
			r=false,
			l=false,
			o=false,
			x=false,
			time={
				u=0,
				d=0,
				r=0,
				l=0,
				o=0,
				x=0
			}
		},
		cam={
			x=0,
			target={
				x=0
			}
		}
	}
	music()
	init_color()
	init_input()
	spawn=find_spawn()
	init_player()
end

function initx()
	init_player()
	init_map()
	init_camera()
	init_fresh()
	init_text()
	init_skin()
	update_map()
	update_camera()
	init_snow()
end

function _update60()
	if starting then starting=false end
	update_input()
	if start then updatex() elseif title.dark==0 then
		title.input.u=btn(⬆️)
		title.input.d=btn(⬇️)
		title.input.r=btn(➡️)
		title.input.l=btn(⬅️)
		if swap then
			title.input.x=btn(🅾️)
			title.input.o=btn(❎)
		else
			title.input.o=btn(🅾️)
			title.input.x=btn(❎)
		end
		if title.input.u then title.input.time.u+=1 else title.input.time.u=0 end
		if title.input.d then title.input.time.d+=1 else title.input.time.d=0 end
		if title.input.r then title.input.time.r+=1 else title.input.time.r=0 end
		if title.input.l then title.input.time.l+=1 else title.input.time.l=0 end
		if title.input.o then title.input.time.o+=1 else title.input.time.o=0 end
		if title.input.x then title.input.time.x+=1 else title.input.time.x=0 end

		title.last=title.hack
		if     title.input.time.u==1 and title.hack==1  then title.hack=2
		elseif title.input.time.u==1 and title.hack==2  then title.hack=3 
		elseif title.input.time.d==1 and title.hack==3  then title.hack=4 
		elseif title.input.time.d==1 and title.hack==4  then title.hack=5 
		elseif title.input.time.l==1 and title.hack==5  then title.hack=6 
		elseif title.input.time.r==1 and title.hack==6  then title.hack=7 
		elseif title.input.time.l==1 and title.hack==7  then title.hack=8 
		elseif title.input.time.r==1 and title.hack==8  then title.hack=9 
		elseif title.input.time.x==1 and title.hack==9  then title.hack=10 
		elseif title.input.time.o==1 and title.hack==10 then title.hack=11 end
		if (
		title.input.time.u==1 or
		title.input.time.d==1 or
		title.input.time.r==1 or
		title.input.time.l==1 or
		title.input.time.x==1 or
		title.input.time.o==1
		) and title.hack==title.last then
			title.hack=1
		end

		if title.hack==11 then hack() title.dark=1 title.pressed=0 elseif

		--====page.1
		title.cam.target.x==0 then
			if title.input.time.u==1 then title.target-=1 title.pressed=0 title.input.time.o=0 end
			if title.input.time.d==1 then title.target+=1 title.pressed=0 title.input.time.o=0 end
			if title.target<0 then title.target=2 end
			if title.target>2 then title.target=0 end
			if abs(title.target*13-title.select)>0.2 then title.select-=(title.select-title.target*13)/2 end
			if mid(1,title.input.time.o,28)==title.input.time.o then title.pressed+=2 end
			if title.pressed>0 and not title.input.o then title.pressed-=4 end
			if title.pressed==56 and title.target==2 then swap=not swap end
			if (title.pressed==56 and title.target==1) or title.input.r then title.cam.target.x=128 title.pressed=0 end
			if title.pressed==56 and title.target==0 then title.dark=1 end
		elseif
		--====page.2
		title.cam.target.x==128 then
			if mid(1,title.input.time.o,28)==title.input.time.o then title.pressed+=2 end
			if title.pressed>0 and not (mid(1,title.input.time.o,28)==title.input.time.o) then title.pressed-=4 end	
			if title.pressed==56 or title.input.l then title.cam.target.x=0 title.pressed=0 end		
		end
		--====else
		title.cam.x-=(title.cam.x-title.cam.target.x)/6
		title.cam.x=mid(0,title.cam.x,128)
		title.pressed=mid(0,title.pressed,56)
	else
		--==== dark dark dark
		title.dark+=1
		if title.dark==8 then initx() starting=true start=true timer.init=time() end
	end
end

function updatex()
	if fresh<64 then
		update_player()
		update_map()
		update_camera()
	end
	update_particles()
	update_fresh()
	update_text()
	update_skin()
	update_snow()

	timer.s=tonum(timer.s)
	if player.x<128 and player.y<128 then
		if not timer.goal then
			timer.gtime=time()
		end
		timer.goal=true
	else
		if timer.goal then
			timer.waste+=time()-timer.gtime
		end
		timer.goal=false
		timer.gap=time()-timer.init-timer.waste
		timer.m=flr(timer.gap/60)
		timer.s=timer.gap%60
		--timer.value=tostr(tostr(timer.m)..":"..tostr(timer.s))
	end
	if tonum(timer.s)<10 then timer.s="0"..tostr(timer.s) end
	if (#tostr(timer.s))<7 then
		repeat
			timer.s=tostr(timer.s)
			timer.s=timer.s.."0"
		until (#tostr(timer.s))==7
	end
	--timer.s=tonum(timer.s)
	timer.length=#tostr(timer.m)+#tostr(timer.s)+1
end

function _draw()
	palt(0,false)
	palt(9,true)
	color(8)
	cls(0)
	for i = 0,15 do
		pal(i,i)
	end
	if start then drawx() else
		for i = 48,59 do
			pal(sget(i,0),sget(i,title.dark))
		end
		camera(flr(title.cam.x+0.5),0)
		for x=0,15 do
			for y=0,15 do
				spr(16,8*x,8*y)
			end
		end
		rectfill(128,0,256,128,11)
		--====page.1
		map(0,32,0,0,16,16)
		rectfill(0,64,127,127,11)
		print("vIOLET",64-6*2,45,6)
		for i = 0,26,13 do
			rectfill(64-28,79+i,64+28,79+8+i,5)
			rect(    64-28,79+i,64+28,79+8+i,10)
		end
		rectfill(64-28,79+flr(title.select+0.5),64-28+title.pressed,79+8+flr(title.select+0.5),10)
		rect(    64-28,79+flr(title.select+0.5),64+28,79+8+flr(title.select+0.5),15)
		print("sTART", 64-5*2,80+1,15)
		print("tUTORIAL",64-8*2,80+1+13,15)
		if swap then
			print("sWAP ❎/🅾️",64-10*2,80+1+13*2,15)
		else
			print("sWAP 🅾️/❎",64-10*2,80+1+13*2,15)
		end
		--====page.2
		rectfill(128+5,7,255-5,127-20-7,3)
		rect(    128+5,7,255-5,127-20-7,5)

		i=30
		rectfill(128+64-28,79+i,128+64+28,79+8+i,5)
		rectfill(128+64-28,79+i,128+64-28+title.pressed,79+8+i,10)
		rect(    128+64-28,79+i,128+64+28,79+8+i,15)
		if swap then
			str=[[	
◆violet
game by lily.kensa♪

press ⬅️/➡️ to move.
press ❎ to jump,
hold to jump higher.
press 🅾️ to dash,
can dash through spikes!
hold only ⬆️ to slide.
hold ⬇️ to walk slowly.

hope you enjoy my game♥
			]]
		else
			str=[[	
◆violet
game by lily.kensa♪

press ⬅️/➡️ to move.
press 🅾️ to jump,
hold to jump higher.
press ❎ to dash,
can dash through spikes!
hold only ⬆️ to slide.
hold ⬇️ to walk slowly.

hope you enjoy my game♥
			]]
		end
		print("bACK",128+64-4*2+1,80+1+i,15)
		print(str,128+8*2,7+3,10)

	end
	if starting then cls(0) end
end

function drawx()
	--map(0,0,0,0,16,16)
	for x=0,15 do
		for y=0,15 do
			spr(16,cam.x+8*x,cam.y+8*y)
		end
	end
	circ(player.x+4,player.y+4,24-flr(cos(time())*0.9),4)
	--if player.slided<3 then pal(8,8) pal(14,14) else pal(8,12) pal(14,1) end
	draw_background()
	draw_main()
	draw_particles(-1)

	print("vIOLET",64-6*2,                                 70,  15)
	print(timer.s, 64+timer.length*2-#tostr(timer.s)*4,    70+8,7 )
	print(":"    , 64-timer.length*2+#tostr(timer.m)*4,    70+8,7 )     
	print(timer.m, 64-timer.length*2,                      70+8,7 )
	print("mUSHROOM:",           63-18-2-#tostr(catch)*2,70+16,6)
	print(catch,                 63+18-2-#tostr(catch)*2,70+16,6)
	print("/8",                  63+18+2-#tostr(catch)*2,70+16,6)
	print("g0al"  ,              64-4*2, 20,   2)
	print("uNDER tHE vIOLET sKY",64-20*2,20+8, 3)

	if player.slided<3 then pal(7,9) else pal(7,12) end
	draw_skin()
	draw_player()
	for i = 0,15 do
		pal(i,i)
	end
	draw_foreground()
	--if player.slided<3 then pal(14,14) else pal(14,1) end
	draw_particles(1)
	--pal(14,14)
	draw_snow(-1)
	draw_text()
	draw_snow(1)
	draw_fresh()
end


-->8
-- player code

function init_player()
	last_ground_time=time()
	coyote_time=0.08
	player={
		x=spawn.x,
		y=spawn.y,
		dx=0,
		dy=-1,
		sprite=1,
		animator=0,
		width=5,
		height=8,
		gravity=0.1,
		acceleration=0.25,
		jump=2,
		slide=1,
		max_dx=7,
		max_dy=7,
		friction=0.85,
		drag=0.85,
		grounded=false,
		flipped=false,
		running=false,
		jumping=false,
		falling=false,
		slided=0
	}
end

function update_player()

	if player.sliding then sfx(15) end	
	if input.x>0 then
		player.flipped=false
	elseif input.x<0 then
		player.flipped=true
	end

	player.running=input.x!=0

  --move
  player.dy+=player.gravity
  player.dx+=player.acceleration*input.x
  
  --resistance
  player.dy=mid(-player.max_dy,player.dy,player.max_dy)
  player.dx=mid(-player.max_dx,player.dx,player.max_dx)
  
  --slide
  if input.slide.pressed and (abs(loc.x)+abs(loc.y)!=0) and not (player.slided>=5) then
		bubble(player.x+4,player.y+4,4.4,7)
		for i=0,3 do
			player.x+=loc.x
			if hit(player.x+1,player.y,player.width,player.height-1,0) or player.x<7 then
				player.x-=loc.x
			end
			player.y+=loc.y
			if hit(player.x+1,player.y,player.width,player.height-1,0) or player.x<7 then
				player.y-=loc.y
			end
			player.dy*=0.6
			--[[local p={
				x=player.x+4,
				y=player.y+4,
				xv=(rnd(3)-1)/2.4,
				yv=(rnd(3)-1)/2.4,
				r=2+rnd(2),
				c=7,
				z=1
			}
			add(particles,p)]]
		end
		player.slided+=1
		player.grounded=false
		input.jump.locked=true
		--if player.slided==2 then player.dy-=player.gravity player.dy+=loc.y*4 player.dy-=player.gravity end
  elseif player.slided>0 then
		player.slided+=1	
		--player.dy=mid(-2,player.dy,32767)
  end
  if player.slided==3 then player.dy=0 end
  if player.slided==1 then sfx(14) end
  if player.slided>5 and player.slided<7 then player.dy-=player.gravity player.dy+=loc.y*1.1 player.dx+=loc.x end
  if player.grounded and player.slided>7 then player.slided=0 end
  if mid(1,player.slided,7)==player.slided then
		if player.slided%2==0 then
			local c={
				x=player.x,
				y=player.y,
				t=0
			}
			add(circles,c)
		end
  end
  
  --jump
  if input.jump.pressed and player.grounded then
    player.grounded=false
    player.dy=-player.jump
    input.jump.ptime=-leniency
    sfx(1)
	for x_ = player.x+1-2 , player.x+player.width+2, 2 do 
		local p={
				x=x_,
				y=player.y+player.height-0.8,
				z=1,
				c=7,
				xv=(rnd(3)-1)/3,
				yv=(rnd(3)-1.2)/3,
				r=rnd(2)+2
			}
		add(particles,p)
	end
  end

  if (not input.jump.locked) and player.dy<0 and (player.slided>13 or player.slided==0) then
  	player.dy*=0.5
  end
  
  --goto
  player.grounded=((player.x<124) and (player.y<124))
  player.onwall=false
  step=flr(abs(player.dx)+abs(player.dy))+1
  for i = 1,step do
	player.x+=player.dx/step
	if hit(player.x+1,player.y,player.width,player.height-1,0) or player.x<7 or (player.y<0 and player.x>474) then
		player.x-=player.dx/step
		player.dx*=0.4
		--player.running=false
		if input.x!=0 and player.dy>0 and not (time()-input.jump.ptime<1) then
			player.onwall=true
			--player.falling=false
			player.dy*=0.98
		end
	end
  end

  for i = 1,step do
	player.y+=player.dy/step
	player.jump=2
	for w= 1,player.width do
		if mget((player.x+w)/8,(player.y+player.height)/8)==12 then
			player.jump=2.88
			mset((player.x+w)/8,(player.y+player.height)/8,0)
			local t={
				x=flr((player.x+w)/8)*8,
				y=flr((player.y+player.height)/8)*8,
				my=0,
				dy=0,
				die=0,
				ftime=10
			}
			add(tiles,t)
		end
	end
	for t in all(tiles) do
		t.gap=t.y+t.my-player.y-player.height+1
		if ( t.gap>-2 and t.gap<=0.5 ) and t.die==0 then
			for w = -player.width-2,7+2 do
				if abs(t.x+w-player.x)<=1 then
					player.y-=player.dy/step
					player.dy*=0.99
					player.dy=mid(t.dy,player.dy,32767)
					player.grounded=true
					player.onwall=false
					last_ground_time=time()
					player.jump=2.88
					break
				end
			end
		end
		if ( (t.x-player.x<player.width+1) and (t.x-player.x>-8) ) 
		and ( (t.y+t.my-player.y<player.height+1) and (t.y-player.y>-8) ) then
			player.jump=2.88
		end
	end
	if hit(player.x+1,player.y,player.width,player.height-1,0) then
		player.y-=player.dy/step
		if player.dy>0 then
			player.grounded=true
			player.onwall=false
			last_ground_time=time()
		end
		player.dy=0.1
		break
	end
  end

  
  if time()-last_ground_time<coyote_time then
  	player.grounded=true
  end
  if player.grounded then player.onwall=false elseif player.onwall then
	local p={
		x=player.x+player.width/2+input.x*2.5+1,
		y=player.y+player.height/2,
		r=1.01,
		xv=0,
		yv=0,
		c=7,
		z=1
	}
	add(particles,p)
  end

  --resistance
  if player.grounded then
	if player.sliding then
		player.dx*=(player.friction)/(player.friction+0.1)
	elseif input.y<0 then
		player.dx*=player.friction*player.friction
	else
   		player.dx*=player.friction
	end
  else
  	player.dx*=player.drag
  end
  
  --[[player.y+=player.dy
  player.x+=player.dx]]
  
  if player.grounded then
  	player.idle=input.x==0
	if not player.running then
		player.sliding=((input.y>0) and (abs(player.dx)>0.06 and (player.dy>-0.1))) 
	else
		player.sliding=false
	end
  else
  	player.running=false
  	player.idle=false
  	player.falling=player.dy>0
  	player.jumping=player.dy<0
  end
  
  animate()

  if hit(player.x+1,player.y,player.width,player.height-1,4)
  and (player.slided==0 or player.slided>12.9) then
		fresh=256
  end

  if mget((player.x+player.width/2)/8,(player.y+player.height/2)/8)==89 then
	mset((player.x+player.width/2)/8,(player.y+player.height/2)/8,88)
	mset((spawn.x+player.width/2)/8,(spawn.y+player.height/2)/8,89)
	mset(7,7,0)
	spawn.x=player.x
	spawn.y=player.y
	spawn.mapy=mapy
  end
  if getmap(player.x+2,player.y+1,player.width-2,player.height-2,48) then
	setmap(player.x+2,player.y+1,player.width-2,player.height-2,32)
	--player.slided=0
	--layer.dy+=-player.gravity*2+loc.y*2
	local c={
		x=g.m.x,
		y=g.m.y,
		time=120
	}
	add(crystal,c)
	for i = 1,8 do
		local p={
			x=c.x*8+4,
			y=c.y*8+4,
			xv=(rnd(3)-1)/8,
			yv=-(rnd(3))/4,
			r=1+rnd(2),
			c=15,
			z=-1
		}
		add(particles,p)
	end
  end
	if getmap(player.x+2,player.y+1,player.width-2,player.height-2,43) then
		block.value=1
		block.bomb=true
		setmap(player.x+2,player.y+1,player.width-2,player.height-2,59)
		sfx(17)
	end
	if getmap(player.x+2,player.y+1,player.width-2,player.height-2,42) then
		block.value=0
		block.bomb=true
		setmap(player.x+2,player.y+1,player.width-2,player.height-2,58)
		sfx(16)
	end


	if player.y>4*128+8 then fresh=256 end

end

function draw_player()
	spr(player.sprite,player.x,player.y,1,1,player.flipped)
end

function find_spawn()
	for i = 0,15 do
		for j = 0,64 do
			if mget(i,j)==1 then
				mset(i,j,88)
				return {x=i*8,y=j*8,mapy=flr(j/16)*128}
			end
		end
	end
	return {x=59,y=128+59,mapy=flr(0/16)*128}
end

function animate()
	if player.onwall then
		cycle(51,54,0.11)
	elseif player.running then
		if input.y<0 then
			cycle(17,22,0.15)
		else
			cycle(17,22,0.1)
		end
	elseif player.sliding then
		cycle(49,50,0.1)
	elseif player.idle then
		cycle(1,5,0.1)
	elseif player.jumping then
		cycle(33,34,0.1)
	elseif player.falling then
		cycle(35,36,0.1)
	end
end

function cycle(first,last,interval)
	if time()-player.animator>interval then
		player.animator=time()
		if player.sprite==18
		or player.sprite==20
		or player.sprite==22
		then sfx(0) end
		player.sprite+=1
	end
		if player.sprite<first
		or player.sprite>last then
			player.sprite=first
		end
end
-->8
-- input code

function init_button()
	return {locked=false,ptime=0,pressed=false}
end

leniency=0.1

eval={[true]=1,[false]=0}

function init_input()
	input={
		x=0,
		y=0,
		jump=init_button(),
		slide=init_button()
	}
end

function update_input()

	input.x=eval[btn(➡️)]-eval[btn(⬅️)]
	--if input.y<=0 and btn(⬆️) and abs(player.dx)>0 then sfx(15) end
	--if player.sliding then sfx(15) end
	input.y=eval[btn(⬆️)]-eval[btn(⬇️)]
	
	if ((not swap) and btn(🅾️)) or (swap and btn(❎)) then
		if not input.jump.locked then
			input.jump.locked=true
			input.jump.ptime=time()
		end
	else
		input.jump.locked=false
	end
	
	if ((not swap) and btn(❎)) or (swap and btn(🅾️)) then
		if not input.slide.locked then
			input.slide.locked=true
			input.slide.ptime=time()
		end
	else
		input.slide.locked=false
	end
	if player.slided==0 then
		loc={x=0,y=0,shift=1.1}
		if btn(⬆️) then loc.y=-loc.shift end 
		if btn(⬇️) then loc.y=loc.shift end
		if btn(➡️) then loc.x=loc.shift end
		if btn(⬅️) then loc.x=-loc.shift end
		if abs(loc.x)+abs(loc.y)>=2 then
			loc.x*=2/3
			loc.y*=2/3
		end
	end
	
	input.jump.pressed=time()-input.jump.ptime<leniency
	input.slide.pressed=time()-input.slide.ptime<leniency
	
end

function input_recieved(bool)
	bool=false
end
-->8
-- map code

function init_map()
	block={
		value=0,
		bomb=false
	}
	mapy=3*128
	t={}
	tiles={}
	b={}
	bonus={}
	catch=0
end

function update_map()
	if player.y-mapy>128 then mapy+=128 end
	if player.y-mapy<-8 then mapy-=128 end
	for i = player.x/8-15,player.x/8+15 do
		for j = cam.y/8-4,cam.y/8+16+4 do
			observe(flr(i),flr(j))
		end
	end
	if block.bomb then block.bomb=false end
	for b in all(bonus) do
		if abs(b.x-player.x)>80 or b.y-mapy>128 then
			mset(b.x/8,b.y/8,15)
			del(bonus,b)
		end
		if abs(player.x-b.x)<8 and abs(player.y-b.y)<8 and b.die==0 then
			b.die=1
			catch+=1
			for i = 1,14 do
				local p={
					x=b.x+4,
					y=b.y+4,
					xv=(rnd(3)-1)/2,
					yv=(rnd(3)-1)/2,
					r=1+rnd(3),
					c=7,
					z=1
				}
				add(particles,p)
			end
			sfx(18)
		end
		if b.die>0 then b.die+=1 end
		if b.die>20 then del(bonus,b) end
	end
	for t in all(tiles) do
		if t.die==0 then
			if t.ftime<=0 then
				t.my+=t.dy
				t.dy+=player.gravity*0.65
				t.dy*=0.98
			else
				t.ftime-=1
			end
		else
			t.die-=1
			if t.die==0 then
				if abs(player.x-t.x)>player.width or abs(player.y-t.y)>player.height then
					t.die=32767
					mset(t.x/8,t.y/8,12)
					del(tiles,t)
					bomb(t.x+4,t.y+4,7)
				else
					t.die=8
				end
			end
		end
		if (hit(t.x,t.y+t.my,7,6,0) or hit(t.x,t.y+t.my,7,5,7)) and t.die==0 then
			bomb(t.x+4,t.y+t.my+4,7)
			t.die=50
		end
	end
	for c in all(crystal) do
		c.time-=1
		if c.time==115 then player.slided=0 player.dy-=player.gravity end
		if c.time<=0 then
			mset(c.x,c.y,48)
			del(crystal,c)
			for i = 1,8 do
				local p={
					x=c.x*8+4,
					y=c.y*8+4,
					xv=(rnd(3)-1)/8,
					yv=-(rnd(3))/4,
					r=1+rnd(2),
					c=15,
					z=-1
				}
				add(particles,p)
			end
		end
	end
end

function observe(x_,y_)
	m=mget(x_,y_)
	if m==15 then
		mset(x_,y_,0)
		local b={
			x=x_*8,
			y=y_*8,
			die=0
		}
		add(bonus,b)
	end
	if fget(m,6) --[[and (time()*20+y_*8)%8<4]] then
		local p={
			x=x_*8+4,
			y=y_*8+4,
			xv=(rnd(3)-1)/14,
			yv=-0.7,
			r=1+rnd(1.8),
			c=14,
			z=-1
		}
		add(particles,p)
	end
	if m==88 then
		local p={
			x=x_*8+4,
			y=y_*8+4,
			xv=(rnd(3)-1)/14,
			yv=-0.7,
			r=1+rnd(1.8),
			c=14,
			z=-1
		}
		add(particles,p)
	end
	if m==11 and block.value==1 then
		mset(x_,y_,27)
		if block.bomb then bubble(x_*8+4,y_*8+4,7,7) end
	end
	if m==10 and block.value==0 then
		mset(x_,y_,26)
		if block.bomb then bubble(x_*8+4,y_*8+4,7,7) end
	end
	if m==26 and block.value==1 then
		mset(x_,y_,10)
		if block.bomb then bubble(x_*8+4,y_*8+4,7,7) end
	end
	if m==27 and block.value==0 then
		mset(x_,y_,11)
		if block.bomb then bubble(x_*8+4,y_*8+4,7,7) end
	end
	if m==59 and block.value==0 then
		mset(x_,y_,43)
	end
	if m==58 and block.value==1 then
		mset(x_,y_,42)
	end
	if m==43 and block.value==1 then
		mset(x_,y_,59)
	end
	if m==42 and block.value==0 then
		mset(x_,y_,58)
	end
end

function draw_background()
	map(0,0,0,0,cam.x/8+17,cam.y/8+17,0x2)
end

function draw_main()
	map(0,0,0,0,cam.x/8+17,cam.y/8+17,0x4)
end

function draw_foreground()
	map(0,0,0,0,16,16,0x8)
	for b in all(bonus) do
		if b.die==0 then spr(15,b.x,b.y+cos(time())*3-1) else
			print("1000",b.x-4,b.y-b.die/3,7+(((flr(b.die/2))%4)/4+1/4))
		end
	end
	for t in all(tiles) do
		if t.die==0 then spr(12,t.x,t.y+t.my) end
	end
end

function hit(x,y,w,h,m)

  collide=false
  
  for i=x,x+w,w do
    if fget(mget(i/8,y/8),m)
    or fget(mget(i/8,(y+h)/8),m)
    then collide=true end
	if m==0 then
		if fget(mget(i/8,(y+h)/8),7) and (not fget(mget(i/8,(y+h-1.5)/8),7)) and player.dy>0 then
			collide=true
			if fget(mget(i/8,(y+h)/8)) then
				player.y-=0.1
			end
		end
	end
  end
  
  for i=y,y+h,h do
    if fget(mget(x/8,i/8),m)
    or fget(mget((x+w)/8,i/8),m)
    then collide=true end
  end
  
  return collide
  
end

function getmap(x,y,w,h,m)
	m0=mget((x  )/8,(y    )/8)
	m1=mget((x+w)/8,(y    )/8)
	m2=mget((x  )/8,(y+h-1)/8)
	m3=mget((x+w)/8,(y+h-1)/8)
	g0=(m0==m)
	g1=(m1==m)
	g2=(m2==m)
	g3=(m3==m)
	g={
		x=-1,
		y=-1,
		m={
			x=-1,
			y=-1
		}
	}
	if g0 or g2 then g.x=x elseif g1 or g3 then g.x=x+w end
	if g0 or g1 then g.y=y elseif g2 or g3 then g.y=y+h-1 end
	g.m.x=flr(g.x/8)
	g.m.y=flr(g.y/8)
	return (g0 or g1 or g2 or g3)
end

function setmap(x,y,w,h,m)
	if g0 then mset((x  )/8,(y    )/8,m) end
	if g1 then mset((x+w)/8,(y    )/8,m) end
	if g2 then mset((x  )/8,(y+h-1)/8,m) end
	if g3 then mset((x+w)/8,(y+h-1)/8,m) end
end

-->8
-- camera code

function init_camera()
	cam={
		x=0,
		y=0,
		c={
			x=0,
			y=0
		},
		target={
			x=0,
			y=0
		},
		offset={
			x=-61,
			y=-77
		},
		follow={
			x=0.05,
			y=0.05
		}
	}
	set_camera(spawn.x-59,spawn.mapy)
end

function update_camera()
	cam.target.x=player.x+cam.offset.x
	cam.target.y=mapy
	cam.target.y=mid(0,cam.target.y,384)
	cam.target.x=mid(0,cam.target.x,896)
	if (cam.target.y==0) or (cam.target.y==256) then
		if cam.target.x<64 then
			cam.target.x=0
		elseif cam.target.x<128 then
			cam.target.x=128
		end
	end

	cam.c.x+=(cam.target.x-cam.c.x)*cam.follow.x
	cam.c.y+=(cam.target.y-cam.c.y)*cam.follow.y
	cam.c.y=mid(0,cam.c.y,384)
	cam.c.x=mid(0,cam.c.x,896)
	cam.x=flr(cam.c.x+0.5)
	cam.y=flr(cam.c.y+0.5)

	camera(cam.x,cam.y)
end

function set_camera(x,y)
	cam.c.x=x
	cam.c.y=y
end
-->8
--particles code

function bomb(x_,y_,c_)
	for i = 1,12 do
		local p={
			x=x_,
			y=y_,
			xv=(rnd(3)-1)/2.6,
			yv=(rnd(3)-1)/2.6,
			r=2+rnd(3),
			c=c_,
			z=-1
		}
		add(particles,p)
	end
end

function bubble(x_,y_,r_,c_)
	local p={
		x=x_,
		y=y_,
		z=-1,
		c=c_,
		xv=(rnd(3)-1)/7,
		yv=(rnd(3)-1)/7,
		r=r_
	}
	add(particles,p)
end

function update_particles()
	for p in all(particles) do
		p.x+=p.xv
		p.y+=p.yv
		p.r-=0.2
		if p.r<=0 then del(particles,p) end
	end
end

function draw_particles(z_)
	for p in all(particles) do
		if p.z==z_ then
			circfill(p.x,p.y,p.r,p.c)
		end
	end
end

-->8
--fresh code

function init_fresh()
	fresh=128
end

function update_fresh()
	if fresh>-256 then fresh-=8 else fresh=-256 end
	if fresh==128 then
		init_player() 
		set_camera(spawn.x-59,spawn.mapy) 
		update_camera()
		update_map() 
		init_snow()
		update_snow()
	end
end

function draw_fresh()
	for i = 0,15,2 do
		rectfill(0+i*8+cam.x,fresh-128+8+cam.y,8+i*8+cam.x,fresh*3+cam.y,0)
	end
	for i = 1,16,2 do
		rectfill(0+i*8+cam.x,128-(fresh-128+8)*3+cam.y,8+i*8+cam.x,128-fresh*3+cam.y,0)
	end
end

-->8
--text code

function init_text()
	m={}
	messages={}
	text={
		message="",
		show=false,
		y=0
	}
	add_text(19,59,"❎ TO dASH ")
	add_text(32,60,"iGNITE FOR A cHECKPOINT")
	add_text(125,28,"jUMP lEFT AND rIGHT")
	add_text(57,44,"bE cAREFUL")
	add_text(75,27,"➡️+❎ tHROUGH sPIKES  ")
	add_text(119,58,"cRYSTAL TO dASH aGAIN")
	add_text(38,20,"❎ tHROUGH sPIKES ")
end

function add_text(x_,y_,t_)
	local m={
		x=x_,
		y=y_,
		t=t_
	}
	add(messages,m)
end

function update_text()
	if text.y>-1 then text.show=false end
	for m in all(messages) do
		if ( (m.x*8-player.x<player.width) and (m.x*8-player.x>-8) )
		and ( (m.y*8-player.y<player.height) and (m.y*8-player.y>-8) ) then
			text.message=m.t text.show=true text.y-=3 break
		end
	end
	text.y*=0.87
end

function draw_text()
	if text.show then
		rectfill(15+cam.x,128+text.y+cam.y,128-16+cam.x,128+text.y+10+cam.y,5)
		rect(15+cam.x,128+text.y+cam.y,128-16+cam.x,128+text.y+10+cam.y,10)
		print(text.message,64+cam.x-#text.message*2,128+text.y+cam.y+3,3)
	end
end

-->8
--skin code

function init_skin()
	f={}
	follow={}
	c={}
	circles={}
	--[[for i = 1,4,0.5 do
		local c={
			x=player.x+player.width/2,
			y=player.y+player.height/2,
			r=i,
			z=i*2,
		}
		add(circles,c)
	end
	for i = 0,9 do
		local f={
			x=player.x,
			y=player.y,
			t=i
		}
		add(follow,f)
	end]]
end

function update_skin()
	--[[for f in all(follow) do
		f.t+=1
		if f.t==10 then
			del(follow,f)
		end
	end]]
	for c in all(circles) do
		c.t+=1
		if c.t==6 then
			del(circles,c)
		end
	end
end

function draw_skin()
	for c in all(circles) do
		if player.slided>4 and player.slided<8 then
			for i = 1,15 do
				pal(i,5)
			end
			spr(player.sprite,c.x,c.y,1,1,player.flipped--[[,6-flr(c.r*2)]])
		end
	end
end

-->8
--snow code

function init_snow()
	snow={}
	for i = 0,7 do
			local s={
				x=mid(0,spawn.x-59,32767)+rnd(128),
				y=mapy+rnd(128),
				r=rnd(3),
				z=1
			}
			add(snow,s)
			local s={
				x=mid(0,spawn.x-59,32767)+rnd(128),
				y=mapy+rnd(128),
				r=rnd(2)+1,
				z=-1
			}
			add(snow,s)
	end
end

function update_snow()
	for s in all(snow) do
		s.y+=3.5-s.r+rnd(2)
		if s.y>cam.y+128 then
			s.y=cam.y
			s.x=cam.x+rnd(128)
			if player.x<128 and player.y<128 then
				del(snow,s)
			end
		end
		if s.y<cam.y then
			s.y=cam.y+128
		end
		if s.x>cam.x+128 then
			s.x=cam.x
		end
		if s.x<cam.x then
			s.x=cam.x+128
		end
	end
	if timer.waste>2 then
		del(snow,s)
	end
end

function draw_snow(layer)
	for s in all(snow) do
		if s.z==layer then
			circfill(s.x,s.y,s.r,7)
		end
	end
end
