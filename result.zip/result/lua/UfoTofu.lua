--ufo tofu
--by albey amakiir

modes={
  menu=0,
  game=1,
  tutorial=2
}

map_bx=16
map_by=0
max_chain=14
min_chain=3
min_chain_score=4
max_combo=10
max_teleports=3

function _init()
  cartdata("albeyamakiir_ufotofu")

  hs_short=dget(0)
  hs_long=dget(1)

  menu_init()
end

function menu_init()
  mode=modes.menu

  menu_select=0
  music(-1)
end

function game_init(moves)
  mode=modes.game
  setup_vars(moves)
  setup_board(7,4)
  --music(0)
end

function help_init()
  mode=modes.tutorial
end

function setup_vars(moves)
  chain_count=0
  length=0
  chain={}
  lengths={}
  chains={}
  
  combo=0
  last_turn_score=0
  score=0
  got_hs=false
  turns_left=moves
  teleports_left=max_teleports
  
  long_game=moves==50
end

function setup_board(size,tiles)
  b_size=size
  blocktypes=tiles
  offset_x=(5+((10-size)/2))*8
  offset_y=(3+((10-size)/2))*8
  centre=flr((b_size+1)/2)-1
  curs_x=centre
  curs_y=centre
  
  for x=0,size-1 do
    for y=0,size-1 do
      mset(x+map_bx,y+map_by,random_block())
    end
  end
end

function random_block()
  return (flr(rnd(blocktypes))+1)
end

------------------

function move_cursor(x,y)
  local cur_x=x
  local cur_y=y

  if (btnp(0)) then x-=1
  elseif (btnp(1)) then x+=1
 	elseif (btnp(2)) then y-=1
  elseif (btnp(3)) then y+=1
  end
	 
  if (x<0) x=0
	 if (y<0) y=0
  if (x>=b_size) x=b_size-1
	 if (y>=b_size) y=b_size-1
  
  if (length<2 or x!=chain[length-1].x or y!=chain[length-1].y) then
    if (length>=max_chain) then
      x=cur_x
      y=cur_y
	   end
	 end
	 
	 if (length>3 and is_loc_in_chain(x,y)) then
    x=cur_x
    y=cur_y
	 end
	 
	 if (x!=cur_x or y!=cur_y) then
	   sfx(0)
	 end
	 
	 return x,y
end

function add_remove_location(x,y)
  if (length==0 or chain[length].x!=x or chain[length].y!=y) then
    if (length>1 and x==chain[length-1].x and y==chain[length-1].y) then
      remove_location()
    else
      add_location(x,y)
    end
 	end
end

function add_location(x,y)
  local mark=mget(x+map_bx,y+map_by)
  if (fget(mark,0)) then
    local	location={}
    location.x=x
    location.y=y
    location.mark=mark
    length+=1
    chain[length]=location
  end
end

function remove_location()
  length-=1
end

function teleport()
  if (btnp(4)) then
    if (chain[1].x!=centre or chain[1].y!=centre) then
      if (teleports_left>0) then
        length=0
        curs_x=centre
        curs_y=centre
        teleports_left-=1
        sfx(9)
      else
        sfx(10)
      end
    end
  end
end

function is_loc_in_chain(x,y)
  for i=1,length-2	do
    if (chain[i].x==x and chain[i].y==y) then
      return true
    end
  end
  
  return false
end

function is_palindrome()
  if (length>=min_chain) then
    local half=flr(length/2)
    
    for i=1,half do
      if (chain[i].mark!=chain[length+1-i].mark) then
        return false
      end	
    end
    
    return true
  end
  
  return false
end

function take_move()
  if (is_palindrome()) then
    score_move()
  
    erase_from_move()
  
    chain_count+=1
    lengths[chain_count]=length
    chains[chain_count]=chain
    length=0
    chain={}
    
    turns_left-=1
    
    if (turns_left==0) then
      if (long_game) then
        if (score>hs_long) then
          hs_long=score
          dset(1,score)
          got_hs=true
        end
      else
        if (score>hs_short) then
          hs_short=score
          dset(0,score)
          got_hs=true
        end
      end
      
      sfx(8)
    end
  end
end

function score_move()
  score+=length
  last_turn_score=length
  sfx(4)
end

function erase_from_move()
  for i=1,length do
    mset(chain[i].x+map_bx,chain[i].y+map_by,chain[i].mark+blocktypes)
  end
end

function animate_clear()
  local animating=false
  
  for x=0,b_size-1 do
    for y=0,b_size-1 do
      local m=mget(x+map_bx,y+map_by)
      if (m==0) then
        fall_block(x,y)
        animating=true
      elseif (fget(m,1)) then
        mset(x+map_bx,y+map_by,m+blocktypes)
        animating=true
      elseif (not fget(m,0)) then
        mset(x+map_bx,y+map_by,0)
        animating=true
      end
    end
  end
  
  return animating
end

--location is empty
function fall_block(x,y)
  if (y!=0) then
    mset(x+map_bx,y+map_by,mget(x+map_bx,y+map_by-1))
    mset(x+map_bx,y+map_by-1,0)
  else
    mset(x+map_bx,y+map_by,random_block())
  end
end

function change_menu_item()
  if (btnp(2)) then
    menu_select-=1
    if (menu_select<0) menu_select=2
    sfx(1)
  elseif (btnp(3)) then
    menu_select+=1
    if (menu_select>2) menu_select=0
    sfx(1)
  end
end

function select_menu_item(item)
  if (item==0) then
    game_init(20)
    sfx(2)
  elseif (item==1) then
    game_init(50)
    sfx(2)
  elseif (item==2) then
    help_init()
    sfx(3)
  end
end

function _update()
  if (mode==modes.game) then
    if (not animate_clear()) then
      if (turns_left>0) then
        teleport()
        curs_x,curs_y = move_cursor(curs_x,curs_y)
        add_remove_location(curs_x,curs_y)
        take_move()
      else
        if (btnp(4)) menu_init()
      end
    end
  elseif (mode==modes.menu) then
    change_menu_item()
    if (btnp(4)) then
      select_menu_item(menu_select)
    end
  elseif (mode==modes.tutorial) then
    if (btnp(4)) then
      menu_init()
      sfx(3)
      menu_select=2	
    end
  end
end

------------------

function draw_frames()
  map(0,0, 0,0, 16,16)
end

function draw_board()
  rectfill(curs_x*8+offset_x,curs_y*8+offset_y,curs_x*8+6+offset_x,curs_y*8+6+offset_y,5)
  rect(curs_x*8-1+offset_x,curs_y*8-1+offset_y,curs_x*8+7+offset_x,curs_y*8+7+offset_y,7)
  
	 map(0+map_bx,0+map_by, offset_x,offset_y, b_size,b_size)	 
end

function draw_line()
  color(7)
  if (length>1) then
    for i=1,length-1 do
      line(chain[i].x*8+3+offset_x,chain[i].y*8+3+offset_y,chain[i+1].x*8+3+offset_x,chain[i+1].y*8+3+offset_y)
    end
  end
end

function draw_chain()
  if (length>0) then
    for i=1,length do
      spr(chain[i].mark,(i)*8,116)
    end
  end
  if (chain_count>0) then
    for i=1,lengths[chain_count] do
      spr(chains[chain_count][i].mark,(i)*8,108)
    end
  end
end

function draw_chain_list()
  for i=1,chain_count do
    for j=1,lengths[i] do
      local mark=chains[i][j].mark
      if (mark==1) then color(8)
      elseif (mark==2) then color(10)
      elseif (mark==3) then color(11)
      elseif (mark==4) then color(12)
      end
      
      line(j+20,i+36,j+20,i+36)
    end
  end
end

function draw_score()
  color(7)
  print("score: "..score,10,6)
  print("turns: "..turns_left,10,14)
  if (chain_count>0) then
    print(last_turn_score,10,102)
  end
  if (turns_left<=0) then
    print("game over",70,14,10)
    print("press 🅾️ to finish",28,120,7)
  end
  
  local hs=hs_short
  local hs_text="high"
  if (long_game) hs=hs_long
  if (got_hs) then
    hs_text="new"
    color(10)
  else color(12) end
  print(""..hs_text.." score: "..hs,58,6)
end

function draw_teleports()
  local x=curs_x
  local y=curs_y
  
  if (length>0) then
    x=chain[1].x
    y=chain[1].y
  end

  if (x!=centre or y!=centre) then
    color(7)
  else
    color(5)
  end
  print("🅾️warps: "..teleports_left,10,22)
end

function centre_string(str,y)
  local centre=64-flr((#str*4)/2)
  print(str,centre,y)
end

function draw_menu()
  map(0,16, 30,20, 9,3)

  color(10)
  centre_string("by albey amakiir",45)

  color(7)

  local menu_y=64
  centre_string("short game",menu_y)
  centre_string("long game",menu_y+8)
  centre_string("instructions",menu_y+16)
  print(">",30,menu_y+(8*menu_select))
  
  color(12)
  centre_string("high score",menu_y+28)
  centre_string("short: "..hs_short.."  long: "..hs_long,menu_y+36)
  
  print("press 🅾️ to select",28,112,7)
end

function draw_help()
  color(7)

  centre_string("it's a ufo tofu platter!",8)
  centre_string("create mirrored collections of",20)
  centre_string("tofu, like edible palindromes.",28)
  centre_string("like this:",40)
  
  spr(1,52,51)
  spr(2,60,51)
  spr(1,68,51)
  
  centre_string("or this:",64)
  
  spr(3,8,75)
  spr(3,16,75)
  spr(1,24,75)
  spr(2,32,75)
  spr(2,40,75)
  spr(2,48,75)
  spr(4,56,75)
  spr(4,64,75)
  spr(2,72,75)
  spr(2,80,75)
  spr(2,88,75)
  spr(1,96,75)
  spr(3,104,75)
  spr(3,112,75)
  
  centre_string("you can warp to the centre 3",88)
  centre_string("times if you get in trouble.",96)
  print("press 🅾️ to return",28,112)
end

function _draw()
  cls()
  if (mode==modes.game) then
    draw_frames()
    draw_board()
    draw_line()
    draw_chain()
    if (chain_count) draw_chain_list()
    draw_score()
    draw_teleports()
  elseif (mode==modes.menu) then
    draw_menu()
  elseif (mode==modes.tutorial) then
    draw_help()
  end
end