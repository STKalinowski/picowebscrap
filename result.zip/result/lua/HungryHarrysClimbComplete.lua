--hungry harry's climb '17
--by rocco panella


function fill_map(themap,x1,y1,x2,y2,val)
	if x1>x2 then
		local x3=x1
		x1=x2
		x2=x3
	end
	if y1>y2 then
		local y3=y1
		y1=y2
		y2=y3
	end
	for xx=x1,x2 do
		for yy=y1,y2 do
		 themap[xx][yy]=val
		end
	end
	return themap
end

function init_map()
	-- outputs an array of zeros
	-- add features here to have
	--them ignored by kmc
	local mymap = {}
	--make the map
	for xx = 0,63 do
		local column = {}
		for yy = 0,127 do
			column[yy] = 0
		end
		mymap[xx] = column
	end
	--load a template
	
	mymap=load_template(mymap,scheme)
	
	--fix borders
	mymap=fill_map(mymap,0,0,0,127,1)
	mymap=fill_map(mymap,63,0,63,127,1)
	mymap=fill_map(mymap,0,0,63,0,1)
	mymap=fill_map(mymap,0,127,63,127,1)
	
	return mymap
end

function load_template(mymap,id)
	--go to shared memory and load
	--a shape to the map
	--must copy to ram first
	reload(0x1000,0x1000,0x1000)
	local sx = 8*(id%16)
	local sy = 8*flr(id/16)
	local xx=0
	for mx=sx,sx+15 do
		local yy=0
		for my=sy,sy+31 do
			local pix=sget(mx,my)
			mymap=fill_map(mymap,xx*4,yy*4,xx*4+3,yy*4+3,pix)
			yy+=1
		end
		xx+=1
	end
	return mymap		
end


function seed_map(mymap)
	--adds random seeds to the array
	--ff is the fill factor
	--higher ff means denser cave
	local ff = 0.1+rnd(0.4)--0.2 --starting fill factor
	local blist={}
	--add voids, fill them with -1,
	--then set back to zero
	--mymap=fill_map(mymap,10,100,40,120,-1)
	for xx = 1,62 do
		for yy = 1,126 do
		
			--interesting shapes
			if rnd() < ff and mymap[xx][yy] == 0 then
			 mymap[xx][yy] = max(1,mymap[xx][yy])
		 	if (mymap[xx][yy] == 1) add(blist,{xx,yy})
		 elseif mymap[xx][yy]==-1 then
		 	mymap[xx][yy]=0
		 end
		end
	end
	
	return mymap,blist,ff
end

function kmc_map(mymap,blist)
 --this actually grows the map
 --parameters
 chance_move = 0.5 -- chance for a particle to move
 chance_leave = 0.25 -- stickiness, lower is stickier
 for xy = 1,#blist do
 	if xy <= #blist then
 	 xx=blist[xy][1]
 	 yy=blist[xy][2]
 			if rnd() < chance_move then
 				mydir = d1()--flr(rnd()*4)
 				mydir2 = dn1()--1-2*d1()--flr(mydir/2)
 				xnew = xx + mydir*mydir2
 				ynew = yy + (1-mydir)*mydir2
 				--gravity
 				if rnd() < 0.3 then
 					xnew = xx
 					ynew = yy+1
 				end
 				--is new space open?
 				if mymap[xnew][ynew]==0 then
 					--how many neighbors in my space?
 					myneighbors = mymap[xx-1][yy] +	mymap[xx+1][yy] +	mymap[xx][yy-1] +	mymap[xx][yy+1]
 					--how many in new space
 					newneighbors = mymap[xnew-1][ynew] +	mymap[xnew+1][ynew] +	mymap[xnew][ynew-1] +mymap[xnew][ynew+1] - 1
 					net = max(myneighbors-newneighbors,0)
 					--if (net > 0) print(net)
 					chance_stick = pow(chance_leave,net)
 					--additional gamble
 					if rnd() < chance_stick then
 						--move!
 						mymap[xx][yy]=0
 						mymap[xnew][ynew]=1
 						blist[xy]={xnew,ynew}
 						if (newneighbors >= 3) del(blist,blist[xy])
 					elseif myneighbors >= 3 then
 						del(blist,blist[xy])
 					end
 				end
 			end
 		--end
 	end
 end
 return mymap,blist
end

function finalize_map(mymap,ff)
	--use this to smooth things
	--and add objects	
	--first, tap down singles and upward spikes
	for xx = 1,62 do
 	for yy = 1,126 do
 		if mymap[xx][yy] == 1 then
 			--myneighbors = 0
 			myneighbors = mymap[xx-1][yy] +	mymap[xx+1][yy] +	mymap[xx][yy-1] + mymap[xx][yy+1]
				if myneighbors <= 1 then		
					if (rnd() < 0.5) mymap[xx][yy]=0
				end
				--hanging check
				myneighbors = 0
 			myneighbors += mymap[xx-1][yy] +	mymap[xx+1][yy] +	mymap[xx][yy+1]
				if myneighbors == 0 then		
					if (rnd() < 0.5) mymap[xx][yy]=0
				end	
			end
		end
	end
	--opening at top
	--fill with climbables
	mymap=fill_map(mymap,28,0,36,0,3)
	mymap=fill_map(mymap,29,1,35,1,3)
	mymap=fill_map(mymap,30,2,34,2,3)
	
	--create opening for hero
	xtarget = 32
	ytarget = 124
	mymap=fill_map(mymap,xtarget-2,ytarget-1,xtarget+2,ytarget+1,0)
	--make sure map can be completed
 mymap=escape_map(mymap)
	--add bridges
	mymap=bridge_map(mymap)
	--add hangers
	mymap=tites_map(mymap)

 --now we need to add stuff!
 --add some mushrooms
 mymap=bad_map(mymap,6,0,2,true)
 for ee in all(enemies) do
 	w=0
 	if (ee[1]==42) w=3
 	mymap=bad_map(mymap,ee[1],w,ee[2],ee[1]==52)
 end
 --actually place the hero
 mymap[32][124]=5
 return mymap
end



function bad_map(mymap,id,wh,chh,gr)
	--use this to add baddies
	--id is what you want to place
	--wh is where
	--chh is probability
	--gr is if gravity applies
	mchance=(chh+ff)/(16*16) --one per screen-ish
 bchance=.01 --chance it will be a supermush
 for xx=1,62 do
 	for yy=1,126 do
 		if rnd() < mchance then
 			xh=xx
 			yh=yy
 			th=mymap[xh][yh]				
 			--in a block?
 			if th==1 then
 				--force upwards
 				while th != wh do
 					yh+=-1
 					if yh<1 then
 						th=wh
 					else
 						th=mymap[xh][yh]
 					end
 				end
 				if yh > 0 then
 					mymap[xh][yh]=id
 					--if (rnd() < bchance) mymap[xh][yh]=7
 			 end
 		 elseif (not gr) and th==wh then
 		  mymap[xh][yh]=id
 		 elseif gr then
 		 	--mush needs to sit on a floor
 		 	tb=mymap[xh][yh+1]

		 		while tb!=1 do
		 			yh+=1
		 			if yh > 126 then
		 				tb=1
		 			else
		 				tb=mymap[xh][yh+1]
		 			end
 		 	end
 		 	if yh < 127 then
 		 		mymap[xh][yh]=id
 					--if (rnd() < bchance) mymap[xh][yh]=7
 			 end
 			end
 		end
 	end
 end
 return mymap 
end


function escape_map(mymap)
	--used to make sure exit can be reached
	xs=32
	ys=1
	xf=28
	yf=1
	xg=32
	yg=124
	drillcount=0
	xx=xs
	yy=ys
	try=true
	good = false
	count=0
	miny=0
	minx=1
	mydir=1
	rw=false
	lw=false
	
	--while try, attempt to move down
	while try do
		down = mymap[xx][yy+1]
		up   = mymap[xx][yy-1]
		right= mymap[xx+1][yy]
		left = mymap[xx-1][yy]
		
		--have i reached the finish?
		if xx>xg-3 and xx<xg+3 and yy>yg-3 then
			try=false
		--have i reached the bottom but not center?
		elseif yy>yg-3 then
			--drill sideways to the goal
			mymap=fill_map(mymap,xx,yy,xg,yy-1,0)
			try=false
		--can i move down?
		elseif down != 1 then
			yy+=1
			--is this a new depth?
			if yy>miny then
				miny=yy
				minx=xx
				--reset left and right limits
				rw=false
				lw=false
			end
		--have i already tried moving
		--left and right?
		elseif rw and lw then
			yy=miny+1
			xx=minx
			--mymap[xx+1][yy]=0
			mymap[xx][yy]=3
			miny=yy
			drillcount+=1
			if drillcount > 2+6*rnd() then
				--mymap=fill_map(mymap,xx-flr(1+3*rnd()),yy,xx+flr(1+3*rnd()),yy-flr(1+3*rnd()),3)
				mx = 8 - flr(16*rnd())
				if (xx+mx > 62 or xx +mx < 1) mx=-1*mx
				mymap=fill_map(mymap,xx,yy,xx+mx,yy+1,0)
				xx+=mx
				minx=xx
				drillcount=0
			end
			--drill a little more
			if (mymap[xx][yy+1]!=1) mymap[xx][yy+1] = 3
			if (mymap[xx][yy+2]!=1) mymap[xx][yy+2] = 3
		--try moving or r
		elseif mydir==1 then
		 if right == 1 then
		 	rhop=true
		 	while rhop do
		 		upnew=mymap[xx][yy-1]
		 		if upnew == 1 or yy <= 1 then
		 			rhop=false
		 			rw=true
		 			mydir=-1
		 		else
		 			upright=mymap[xx+1][yy-1]
		 			if upright == 1 then
		 				rhop=true
		 				yy=yy-1
		 			else
		 				yy=yy-1
		 				xx=xx+1
		 				rhop=false
		 			end
		 		end
		 	end
		 else
		 	xx+=1
		 end
		--try moving left
		elseif mydir==-1 then
			if left == 1 then
		 	lhop=true
		 	while lhop do
		 		upnew=mymap[xx][yy-1]
		 		if upnew == 1 or yy <= 1 then
		 			lhop=false
		 			lw=true
		 			mydir=1
		 		else
		 			upleft=mymap[xx-1][yy-1]
		 			if upleft == 1 then
		 				lhop=true
		 				yy=yy-1
		 			else
		 				yy=yy-1
		 				xx=xx-1
		 				lhop=false
		 			end
		 		end
		 	end
		 else
		 	xx+=-1
		 end
		end
	end
		
 return mymap
end

function bridge_map(mymap)
	--grow bridges
	chancestart=0.2
	chancecont=0.8
	for xx = 1,60 do
 	for yy = 1,123 do
 		if mymap[xx][yy]==1 then
 			myneighbors = 0
 		 myneighbors += mymap[xx][yy-1] + mymap[xx+1][yy]
 		 bl=0
 		 try=true
 		 build=false
 		 if myneighbors == 0 and mymap[xx-1][yy] == 1 and rnd() < chancestart then
 		 	bx=xx+1
 				by=yy
 		 	while try do
 			 	myneighbors = 0
 			  myneighbors += mymap[bx][by-1] + mymap[bx][by+1]
 		 	 if myneighbors == 0 then
 		 	 	if mymap[bx+1][by] > 0 then
 		 	 		try = false
 		 	 		build = true
 		 	 	else
 		 	 		try = true
 		 	 		bx+=1
 		 	 	end
 		 	 else
 		 	 	try=false
 		 	 	build=false
 		 	 end
 		 	end
 		 end
 		 if build then
 		 	bl = bx-xx 
 		 	if bl > 3 then
 		 		mymap=fill_map(mymap,xx+1,yy,bx,yy,4) 		 	
 		 	end
 		 end
 		end
 	end
 end
	return mymap
end



function tites_map(mymap)
	--grow stalactites, climbable
	chancestart=0.1
	chancecont=0.8
	for xx = 1,62 do
 	for yy = 0,126 do
 		if mymap[xx][yy]>0 then
 	  --hanging check
			 myneighbors = 0
 		 myneighbors += mymap[xx][yy+1]
 		 if myneighbors == 0 then
 		 	--tite loop
 		 	myneighbors += mymap[xx+1][yy] + mymap[xx-1][yy]
 		 	tx=xx
 		 	ty=yy+1
 		 	py=0
 		 	try = true
 		 	while try do
 		 		empty=mymap[tx][ty+py]+mymap[tx-1][ty+py]+mymap[tx+1][ty+py]
 		 		if empty == 0 then
 		 			py += 1
 		 		else
 		 			try = false
 		 		end
 		 	end
 		 	chance=py*chancestart--pow(chancestart,myneighbors)
 		 	while (rnd() < chance and ty<125) do-- and try and ty < 125) do
 		 	 mymap[tx][ty]=3
 		 	 chance += -chancestart
 		 	 ty+=1
			 	end
			 end
			end
		end
	end
	return mymap
end

--convenience functions------

function d1()
	return flr(rnd(2))
end

function dn1()
	return -1+2*d1()
end

function sign(num)
	if (num >= 0) return 1
	if (num < 0) return -1
	--if (num == 0) return 0
end

function pow(root,power)
	--my own exponent function
	--handles noninteger roots
	--only whole number powers
	if power == 0 then
		return 1
	else
		newnum=1
		for ii=1,power do
			newnum = newnum*root
		end
	end
	return newnum
end


function layout_map(mymap)
	--actually paint map to real world
	local key={}
	--key index is map vals
	--key values are tiles
	for ii=1,100 do
		key[ii]=ii
	end
	--key[0]=0
	key[1]=34
	key[2]=34
	key[3]=51
	key[4]=35
	key[5]=3
	key[6]=48
	key[7]=49
	--key[29]=29
	--key[42]=42
	--key[44]=44
	--key[47]=47
	--key[52]=52
	--key[58]=58
 --key[57]=57
 --key[25]=25
 --key[61]=61
 --key[15]=15
	--first half
	for xx = 0,63 do
		for yy = 0,63 do
			mset(xx+64,yy,key[mymap[xx][yy]])
		end
		--second half
		for yy = 64,127 do
			mset(xx,yy-64,key[mymap[xx][yy]])
		end
	end
end


function pretty_tiles()
	--use this for pretty tiling
	local os = theme--90
	for xx = 0,127 do
		for yy = 0,63 do
			val = mget(xx,yy)
			--background
			if val == 0 then
				mset(xx,yy,1*(xx%2)+16*(yy%2)+os)
			elseif val == 35 then
				mset(xx,yy,19+os)
			elseif val == 51 then
				mset(xx,yy,35+os)
			else
				fval = fget(val,1)
				if fval then
					kern={}
					for xp=xx-1,xx+1 do
						for yp=yy-1,yy+1 do
							if xp<0 or xp>127 or yp<0 or yp>63 then
							 kp=true
							else
							 kp=fget(mget(xp,yp),1)
							end
							add(kern,kp)
						end
					end
					--check above
					if kern[4] then
						if (kern[6])	mset(xx,yy,18+os)
						if (not kern[6]) mset(xx,yy,34+os)
					else
						if (kern[6])	mset(xx,yy,2+os)
						if (not kern[6]) mset(xx,yy,3+os)
					end					
				end
			end
		end
	end
end

--end map code! whew!

--start oop for actors

--player is the generic actor class
player={}

function player:new(o)
	--use this for making subclasses
 o=o or {}
 o.x = o.x or 0
 o.y = o.y or 0
 --if o.x > 64*8 then
	--	o.gx = o.x - 64*8
	--	o.gy = o.y - 64*8
	--else
		o.gx = o.x
		o.gy = o.y
	--end
 o.dx = o.dx or 0
 o.dy = o.dy or 0
 o.ground = o.ground or false
 o.climb = o.climb or false
 o.climbw = o.climbw or false
 o.hang = o.hang or false
 o.duck = o.duck or false
 o.stun = o.stun or false
 o.stunt = o.stunt or 0
 o.colt = o.colt or 0
 o.burpt = o.burpt or 0
 o.gravity = o.gravity or 0.1
 o.jump=1.5
 o.speed=1
 o.dead=false
 o.sprite = o.sprite or 1
 o.spritedraw = 1

 o.spritewalk = o.spritewalk or {o.sprite}
 o.spritefall = o.spritefall or {o.sprite,o.sprite} 
 o.spriteclimb = o.spriteclimb or o.sprite
 o.spriteclimbw = o.spriteclimbw or {o.sprite,o.sprite}
	o.spritehang = o.spritehang or {o.sprite,o.sprite} 
 o.spriteduck = o.spriteduck or o.sprite 
 o.spritestun = o.spritestun or o.sprite
 o.spriteburp = o.spriteburp or o.sprite
 o.walkframe = 0
 o.flipframe = false
 o.flipme=false
 o.canjump=false
 o.speedframe = 4
 --wall values
 o.w = {}
 o.w[0] = o.w[0] or false
 o.w[1] = o.w[1] or false
 o.w[2] = o.w[2] or false
 o.w[3] = o.w[3] or false
 o.w0={}
 o.w0[0] = false
 o.w0[1] = false
 o.w0[2] = false
 o.w0[3] = false
 setmetatable(o,self)
 self.__index=self
 return o
end

function player:inst(o)
	--use this to actually create an instance ingame
 o=o or {}
 local a={}
 for k,v in pairs(self) do
 	a[k] = v
 end
 a.x = o.x or self.x
 a.y = o.y or self.y
 a.dx = o.dx or self.dx
 a.dy = o.dy or self.dy
 setmetatable(a,self)
 self.__index=self
 return a
end


function player:update_early()
	--replace with behavior
	--specific to subclass
end

function map_solid(xx,yy)
	--takes pix and returns
	--fvals for the tile
	mx,my = simple_xy(xx,yy)
	local myf={}
	for ii=0,7 do
		myf[ii]=fget(mget(mx,my),ii)
	end
	return myf
end

function map_val(xx,yy)	
	mx,my = simple_xy(xx,yy)
	return mget(mx,my)
end

function simple_xy(xx,yy)
 local mx = flr(xx/8)
	local my = flr(yy/8)
	--loop mx and my if needed
	if mx < 64 and my < 0 then
		mx += 64
		my += 64
	elseif mx >= 64 and my >= 64 then
		mx += -64
		my += -64
	end
	return mx,my
end

function map_destroy(xx,yy,fill)
 mx,my = simple_xy(xx,yy)-- = flr(xx/8)
	if ((my==63 and mx < 64) or mx==0 or mx==127 or mx==63 or mx==64) return
	local newt = fill or theme+1*(mx%2)+16*(my%2)
	--mset(mx,my,0)
	mset(mx,my,newt)
end	

function player:update()
	--subclass stuff runs first
	--self:update_early()
	--move
	--gravity
	if (not (self.climb or self.climbw or self.hang)) self.dy += self.gravity
	
 self.x += self.dx
	self.y += self.dy
	
	if self.stun then
		self.stunt += -1
		if (self.stunt <= 0) self.stun = false
	end
	
	if (self.colt > 0) self.colt += -1
	if (self.burpt > 0) self.burpt += -1
	
	--loop around the world if necessary
	--this is only needed if you have a 'tall'map
	--remove if you want a long map
	if self.x<64*8 and self.y < 0 then
		self.x += 64*8
		self.y += 64*8
	elseif self.x > 64*8 and self.y > 64*8 then
		self.x += -64*8
		self.y += -64*8
	end
	-- end world loop
	
	--reset wall collisions
	--for ii=0,3 do
	--	self.w[ii]=false
	--end
	self.w0={}
	self.w0=self.w--copy(self.w)
 self.w={}
	for kk=0,3 do
		--self.w0[kk]=vv
		self.w[kk]=false
	end
	
	--snap up
	if self.dy >= 0 then
		if map_solid(self.x+2,self.y+8)[1] 
		or map_solid(self.x+5,self.y+8)[1] then
			if self.stun then
				if self.dy < 0.3 then
					self.dy = 0
				else
					self.dy = -self.dy*0.5
				end
				if abs(self.dx) < 0.2 then
					self.dx=0
				else
					self.dx*=0.8
				end
			else
				self.dy = 0
			end
			self.ground = true
			self.y = 8*(flr(self.y/8))
			self.w[3] = true
		-- passthroughs
		elseif map_solid(self.x+2,self.y+8)[3] 
		or map_solid(self.x+5,self.y+8)[3] then -- passthroughs
			if not self.climb then
				if self.stun then
					if self.dy < 0.5 then
						self.dy = 0
					else
						self.dy = -self.dy*0.5
					end
					if abs(self.dx) < 0.2 then
						self.dx=0
					else
						self.dx*=0.8
					end
				else
					self.dy = 0
				end
				self.ground = true
				self.y = 8*(flr(self.y/8))
				self.w[3] = true
			end
			
			--self.ground = false
		end
	end
	
	--snap down
	if self.dy <= 0 then
		if (self.dy < 0) self.ground = false
		if map_solid(self.x+3,self.y-1)[1]
	 or map_solid(self.x+5,self.y-1)[1] then
			if horns and self.sprite==3 and self.dy<0 and not btn(2) then
				map_destroy(self.x+4,self.y-4)
				self.dy=max(-0.8,self.dy)
				sprint("smash",self.x+4,self.y-4,7,10)				
			else
			
				self.dy = 0
				--self.ground = true
				self.y = 8*(flr((self.y+4)/8))
				self.w[2] = true
			end
		end
	end	
	
		--snap right
	if self.dx <= 0 then
		if map_solid(self.x,self.y+1)[1]
	 or map_solid(self.x,self.y+6)[1] then
			if self.stun then
				self.dx*=-0.8
			else
				self.dx = 0
			end
			--self.ground = true
			self.x = 8*(flr((self.x+4)/8))-1
			self.w[0] = true
			--sprint("0!",self.x+4,self.y-4,7,10)
		end
	end
	
	--snap left
	if self.dx >= 0 then
		if map_solid(self.x+7,self.y+1)[1] 
		or map_solid(self.x+7,self.y+6)[1] then
			if self.stun then
				self.dx*=-0.8
			else
				self.dx = 0
			end
			--self.ground = true
			self.x = 8*(flr((self.x)/8))+1
			self.w[1] = true
			--sprint("1!",self.x+4,self.y-4,7,10)
		end
	end
	
	--get my background
	local background = map_solid(self.x+4,self.y+4)
	
	--check climb state
	if self.climb then
		--local cl = map_solid(self.x+4,self.y+4)[2]
		if not background[2] then 
		 self.climb=false
		 self.canjump=true
		end
	end
	
	--check wall climb state
	if self.climbw then
		if (not (self.w[0] or self.w[1])) self.climbw = false
	end
	
	--check	hang
	if self.hang then
		self.canjump=false
		if (not self.w[2]) self.hang = false
	end
	
	--global coords update
	if self.x > 64*8 then
		self.gx = self.x - 64*8
		self.gy = self.y - 64*8
	else
		self.gx = self.x
		self.gy = self.y
	end

	if (self.sprite > 1 and background[7]) self:stunme(180,dn1()*1.2,-1.2)	
	--get ready to draw
	--self:draw_setup()
	
end

function player:stunme(tt,xx,yy)
	--stun the player
	--tt is time
	--vector sets a velocity
	self.stun = true
	self.stunt = tt
	self.colt = 5 -- time until able to be stunned again
	self.dx = xx
	self.dy = yy
	self.climbw=false
	self.climb=false
	self.hang=false
	sfx(16)
end

function player:draw_setup()
	--setup the sprite
	--self.spritedraw=self.sprite
	if (self.dx > 0) self.flipframe = false
	if (self.dx < 0) self.flipframe = true
	if (self.dx!=0) self.flipme=self.flipframe
	if self.ground then
		if self.dx == 0 then
			self.spritedraw = self.sprite
			self.walkframe = 0
		else
			self.walkframe += abs(self.dx)
			local frame = flr(self.walkframe/self.speedframe)%(#self.spritewalk)+1
			self.spritedraw = self.spritewalk[frame]
			if (frame==1 and self.sprite==3) sfx(9)
		end
	else
		self.spritedraw = self.spritefall[2]
		if (self.dy < 0) self.spritedraw = self.spritefall[1]
	end
	if self.duck then
		self.spritedraw=self.spriteduck
	end
	
	if (self.burpt>=burpspeed-15 and self.burpt>0) self.spritedraw=self.spriteburp
	if (self.burpt>=burpspeed-3 and self.burpt>0) self.spritedraw=self.spriteduck
	
	if self.climb then
		self.spritedraw = self.spriteclimb
		--if (self.dx != 0 or self.dy != 0) 
		self.flipframe = (0.5*self.x+self.y)%4 > 1
	end
	if self.climbw then
		self.spritedraw = self.spriteclimbw[1+flr((self.y/2)%2)]
		--if (self.dx != 0 or self.dy != 0) self.flipframe = (self.x+0.5*self.y)%4 > 1
	end
	if self.hang then
		self.spritedraw = self.spritehang[1+flr((self.x/2)%2)]
	end
end

function player:draw_early()
	--replace per player
end

function player:draw(moveme)
	--self:draw_setup()
	--moveme is 0 if entity is in same side as player
	--3 if entity is below player
	--2 if entity is above
	local drawx = self.x
	local drawy = self.y
	if moveme==2 then
	 drawx = self.x - 64*8
	 drawy = self.y - 64*8
	elseif moveme==3 then
	 drawx = self.x + 64*8 
	 drawy = self.y + 64*8
	end
	if self.stun and self.sprite != 47 then
		self.spritedraw = self.spritestun
  if (self.stunt > 30) sprint("★",self.x+(self.stunt%32)/4,self.y-2,10,1)
  if (self.stunt <= 30) sprint("★",self.x+self.stunt%8,self.y-2,7,1)
	end
	--pal(6,7)
	ospr(self.spritedraw,drawx,drawy,1,1,self.flipframe)
	--pal()
end

function ospr(spri,x,y,wx,wy,ff)
	--palt(0,false)
	for cc=1,15 do pal(cc,1) end
	for xx=-1,1 do
		for yy=-1,1 do
			spr(spri,x+xx,y+yy,wx,wy,ff)
		end
	end
	pal()
	palt()
	spr(spri,x,y,wx,wy,ff)
end

--hero class
hero = player:new({sprite=3,
	spritewalk={4,5,6,7},
	spritefall={4,5},
	spriteclimb=8,
	spriteclimbw={9,10},
	spritehang={11,12},
	spriteduck=13,
	spritestun=14,
	spriteburp=2})
	
--walker class
walker = player:new({sprite=29,
	spritewalk={29,30},
	--spritefall={30,30},
	--spriteclimb=29,
	spriteclimbw={27,28},
	spritehang={26,31},
	spritestun=28})

crawler = player:new({sprite=42,
	spritestun=43})

spitter = player:new({sprite=44,
	spritewalk={44,45},
	spriteduck=45,
	spritestun=46})
	
bat = player:new({sprite=58,
	spritefall={58,59},
	spritestun=60})

hopper = player:new({sprite=61,
	spritewalk={61,62},
	spritefall={62,61},
	spritestun=63})
	
glider = player:new({sprite=25,
	spritefall={24,24},
	spritestun=40})
	
dropper = player:new({sprite=57,
	spritefall={41,41},
	spritehang={41,41},
	gravity=-0.2,
	spritestun=41})
	
slimeball = player:new({sprite=15,
	size=0,
	colt=5})


fireball = player:new({sprite=47,
	gravity=0.025,
	stun=true,
	stunt=180,
	colt=5})
	
blast = player:new({sprite=0,
	colt=4,
	size=2,
	gravity=0})

burp = player:new({sprite=1,
	burpt=30,
	gravity=0,
	colt=30})

function hero:update_early()
	--controls for hero
	self.dx = 0
	local burpgo = self.burpt <= max(burpspeed-20,0)
	if (not btn(3)) self.duck=false
	if (self.climb or self.climbw)	self.dy = 0
	if btn(0) and burpgo and not self.w[0] then
	 self.dx = -speed
	 if (self.climb or self.hang) then 
	 	self.dx = -0.5*speed
	 	if (t%7==0) sfx(8)
		end
	end
	if btn(1) and burpgo and not self.w[1] then
	 self.dx = speed
	 if (self.climb or self.hang) then
	 	self.dx = 0.5*speed
	 	if (t%7==0) sfx(8)
	 end
	end
	if btnp(4) then
		if self.ground or self.hang or self.climb or self.climbw or self.canjump then 
			self.dy = -jump
			self.hang = false
			self.canjump=false
			self.climb=false
			self.climbw=false
			sfx(7)
		elseif flight then
			self.dy = -jump
			sprint("toot",self.x+4,self.y+9,6,5)
			hunger += -flightburn
			sfx(17)
		end
	end
	if btn(2) then
		local cl = map_solid(self.x+4,self.y+4)[2]
		if cl then
			self.climb=true
			self.dy = -0.5*speed
			if (t%7==0) sfx(8)
		elseif self.w[2] then
			self.hang = true
			self.dy = 0
		elseif self.w[0] or self.w[1] then
			self.climbw=true
			self.dy = -0.5*speed
			if (t%7==0) sfx(8)
		end
		--if (self.ground and self.dx==0) self.duck=true
	end
	if btn(3) then
		if self.climb then
		 self.dy = 0.5
		 if (t%7==0) sfx(8)
		end
		if self.climbw then
		 self.dy = 0.5
		 if (t%7==0) sfx(8)
		end
		if self.hang then
			self.hang = false
		end
		if (self.ground) self.duck=true
	end
	if btnp(3) and self.ground then
		if map_solid(self.x+4,self.y+9)[1] then
			map_destroy(self.x+4,self.y+9)
			sprint("dig!",self.x+4,self.y-4,7,10)
			sfx(0)
			--routine to "pile" behind
			local xp = self.x-4
			if (self.flipframe) xp = self.x + 12
			local yp = self.y+9
			local done = false
			while not done do
			 ms=map_solid(xp,yp)[1]
			 if ms then
			 	ms2 = map_solid(xp,yp-8)[1]
			 	if (ms and ms2) done=true--yp += -8
			 	if yp < self.y-0 then
			 		done=true
			 	elseif ms and not ms2 then
			 	 done=true
			 	 if (not map_solid(xp,yp-18)[1]) map_destroy(xp,yp-8,theme+18)
			 	end
			 else
			 	yp+=8
			 	if (yp > self.y+24) done=true
			 end	
			end
			
			--end pile routine
		elseif map_solid(self.x+4,self.y+9)[3] then
			self.y+=4
			self.climb=true
		end
	end
	--end
	--burping
	
	if self.burpt <= 0 then
	 if btn(5) then
	 	local i=0
	 	while i < burpnum do
	 		local ddx=burpvel
	 		if (self.flipme) ddx=-burpvel
	 		local bp={x=self.x,
				y=self.y,
				dy=-i*0.25,--i*0.2*rnd()*dn1(),
				dx=ddx*(1-i*0.1)}--*rnd()*dn1()}
				dg=i*0.005
				local mybp = burp:inst(bp)
				mybp.burpt=burplife
				mybp.colt=burplife+3
				mybp.gravity=dg
		 	add(actors,mybp)
	 		self.burpt=burpspeed
	 		i+=1
	 	end
	 	sprint("belch",self.x+4,self.y-4,6,20)
	 	sfx(18)
		end
	end
	--hero specific collisions
	--check for mushrooms
	mc=map_val(self.x+4,self.y+4)
	
	if mc==48 then
		power+=4
		score+=4
--		power+=flr((hunger+10)/hungermax)*((hunger+10)%hungermax)
		hunger+=10
		hunger=min(hungermax,hunger)
		map_destroy(self.x+4,self.y+4)
		sprint(ft[1+flr(rnd(#ft))],self.x+4,self.y-4,7,10)
		sfx(6)
	end
	local gotpowerup=true --flag if needed
	local happystring=''
	if mc==70 then --jumpup
		happystring="jump up!"
	 jump+=0.5
	elseif mc==71 then --speedup	
		happystring="speed up!"
	 speed+=0.25
	elseif mc==72 then --flight
		happystring="flight! it burns!"
	 flight=true
	elseif mc==73 then --horns
		happystring="smash the ceiling!"
	 if (horns) jump += 0.25
	 horns=true
	elseif mc==74 then --explosive
		happystring="burp-splosion!"
	 burpsplode+=1
	 burpvel+=0.25
	elseif mc==75 then --time
		happystring="burp up!"
	 burplife+=30
	 burpvel+=0.5
	elseif mc==76 then --multishot
		happystring="scatter-burp!"
	 burpnum+=2
	elseif mc==77 then --firerate
		happystring="burp rate up!"
	 burpspeed=flr(burpspeed/2)
	elseif mc==78 then --leave ladders
		happystring="sticky burp!"
	 if (laddderburp) burpspeed=flr(2*burpspeed/3)
		ladderburp=true
	elseif mc==79 then --carnivore
		happystring="eat stunned enemies!"
	 burpvel+=0.25
		caneat=true
	else
		gotpowerup=false --flag if needed
	end
	if gotpowerup then
		sprint(happystring,self.x+4,self.y-4,10,60)
		sfx(11)
		map_destroy(self.x+4,self.y+4)		
		powerscore+=1
	end
	--check spikes
	local hurt = map_solid(self.x+4,self.y+4)[4]
	if hurt then
		dire = sign(self.x-8*flr((self.x+4)/8))
 	self:stunme(60,dire*1.2,-1.2)
		map_destroy(self.x+4,self.y+4)
	end
end


function burp:update_early()
 if (self.burpt <=0) self.dead=true
 if self.dead and burpsplode>0 then
 	local bl={x=self.x,
		y=self.y}
		--bl.size=burpsplode
	 local mybl = blast:inst(bl)
	 mybl.size=burpsplode
		add(actors,mybl)
 end
	if (ladderburp) map_destroy(self.x+4,self.y+4,94)
end


function walker:update_early()
	
	--if on the ground--------
	if self.w[3] then
		if self.climbw and self.dy >=0 then
			self.climbw=false
			if (self.w[1]) self.dx=-0.25
			if (self.w[0]) self.dx=0.25
			
		elseif (self.w[1] and not self.w0[1]) or (self.w[0] and not self.w0[0]) then
		 --if map_solid(self.x+7,self.y+4)[1] then
			--if self.w[1] then
				--self.dx = -0.25
			self.climbw=true
			self.dy=-0.25
		elseif self.dx == 0 then
			self.dx = -0.25*dn1()
		end
	--climbing behavior------
	elseif self.climbw then
		if self.w[2] then
			self.hang=true
			self.climbw=false
			self.dy=0
			if (self.w[1]) self.dx=-0.25
			if (self.w[0]) self.dx=0.25
		elseif self.w[3] then
			self.climbw=false
			self.dy=0
			if (self.w[1]) self.dx=-0.25
			if (self.w[0]) self.dx=0.25
		elseif self.dy>0 then
			if self.w[0] then
				if (not map_solid(self.x-1,self.y+9)[1]) self.dy=-0.25
			elseif self.w[1] then
				if (not map_solid(self.x+8,self.y+9)[1]) self.dy=-0.25
			end	
		end
	--hop up-----
	elseif self.dy<0 then
		if self.w[2] and not self.w0[2] then
		 self.hang=true
		 self.dx = -0.25*dn1()
		elseif self.w0[0] and (not self.w[0]) then
			self.y+=-1
			self.dy=-0.5
			self.dx=-0.25
			self.x+=-1
		elseif self.w0[1] and (not self.w[1]) then
			self.y+=-1
			self.dy=-0.5
			self.dx=0.25
			self.x+=1
		end
	--hanging behavior------
	elseif self.hang then
		if self.w[1] or self.w[0] then
			self.hang=false
			self.climbw=true
			self.dx=0
			self.dy=0.25
		end
	--turnaround from a fall
	elseif self.dy>0 and (self.w0[3] and not self.w[3]) then
		self.x+=4*self.dx
		self.dx = -self.dx
		self.y+=1
	--grab a wall and climb down if falling
	elseif self.dy>0 and (self.w[0] or self.w[1]) then
		self.climbw=true
		self.dy=0.25
	end
end

function crawler:update_early()
	local cll = map_solid(self.x+4,self.y+4)[2]--fget(map_val(self.x+4,self.y+4),2)
	if not self.stun	then
		if cll then
			cl2 = fget(map_val(self.x+4,self.y-1),2)
			cl3 = fget(map_val(self.x+4,self.y+8),2)
			self.climb = true
			self.dx=0
			self.x= 8*flr((self.x+4)/8)
			
			--if self.dy < 0 then
			if (self.w[2] or (not cl2)) self.dy=0.2
			--elseif self.dy > 0 then
			if (self.w[3] or (not cl3)) self.dy=-0.2
			if (self.dy==0) self.dy=-0.2
			--end
		else
			--self.stun=true
			--self.stunt = 10
			if (self.w[3]) self:stunme(100,-0.5*dn1(),-1)
		end
	end
end	

function bat:update_early()
	--local ss = map_solid(self.x+4,self.y+4)[1]
	--if not self.stun	then
		--if cll then
	local pt = (self.x>player1.x-5 and self.x<player1.x+5 and self.y<player1.y and self.y > player1.y-60)
	if (rnd() < self.dy and not pt) self.dy=-0.5
	if (self.w[1]) self.dx=-0.15
	if (self.w[0]) self.dx=0.15
	if (self.w[3]) self.dy=-2
	if (self.dx == 0) self.dx = 0.15*dn1()
end	

function hopper:update_early()
	if (self.w[3] and rnd(60)<1) self.dy=-2-rnd(2)
	--if (self.dx == 0) self.dx = 0.15*(-1+2*flr(rnd(2)))
end	

function dropper:update_early()
	
	if self.w[2] then
		self.hang=true
		self.dy=0
		self.y+=-1
		self.dx=0
		self.gravity=0.1
		if rnd(300) <= 1 then
			local sb={x=self.x,
			y=self.y,
			size=0}
			local mysb = slimeball:inst(sb)
		 add(actors,mysb)
		end
	end
end	

function glider:update_early()
	if (self.w[3]) self.dx=0
	if not (self.w[3] or self.w[1] or self.w[0]) then
	 self.dy += -self.gravity
	 if (self.dx==0) self.dx=0.5*dn1()
	end
	if self.w[3] and rnd(60) < 2 then
	 self.dy=-1
	 self.dx=dn1()
	end
	if self.w[0] or self.w[1] then
		self.dy=0
		self.dx=0
		self.climbw=true
		if rnd(60) < 1 then
			if self.w[0] then
				self.x+=1
				self.dx=1
			else
				self.x+=-1
				self.dx=-1
			end
			self.climbw=false
			self.dy=0.3*dn1()*rnd()
		end
	end
	if self.w[2] then
		self.y+=1
		self.dy=0.5
	end
end	


function spitter:update_early()	
	--if on the ground--------
	if self.w[3] then
		if (self.w[1]) self.dx=-0.1
		if (self.w[0]) self.dx=0.1
		if (not map_solid(self.x-1,self.y+8)[1]) self.dx=0.1
		if (not map_solid(self.x+8,self.y+8)[1]) self.dx=-0.1
		if (self.dx == 0) self.dx = 0.1*dn1()
		if flr(rnd(300)) == 1 then
			local fb={x=self.x,
			y=self.y,
			dy=-1,
			dx=sign(self.dx)*1.5}
			local myfb = fireball:inst(fb)
		 add(actors,myfb)
		end
	end
end

function slimeball:update_early()
	if (self.w[1]) self.dx=-0.75
	if (self.w[0]) self.dx=0.75
	if (self.dy >= 0.4) self.dx = 0
	if (self.dx==0 and self.w[3]) self.dx=0.75*dn1()
	if (self.w[1] or self.w[0]) self.size+=1
	if (self.size >= 4) self.dead=true
end


function fireball:update_early()	
	if not self.stun then
	 self.dead=true
	 local bl={x=self.x,
		y=self.y}
		bl.size=4
	 local mybl = blast:inst(bl)
		add(actors,mybl)
	end
end

--function fireball:draw_early()
--end

function blast:update_early()
	local xx = flr(self.x+4)
	local yy = flr(self.y+4)
	if self.colt == 4 then
		sfx(19)
		--blowup
		for ii = -self.size,self.size do
			for jj = -self.size+abs(ii),self.size-abs(ii) do
			 map_destroy(xx+8*ii,yy+8*jj,56)
			 map_destroy(xx+8*jj,yy+8*ii,56)
			end
		end
	end
	if self.colt==1 then 
	 for ii = -self.size,self.size do
			for jj = -self.size+abs(ii),self.size-abs(ii) do
			 map_destroy(xx+8*ii,yy+8*jj)
			 map_destroy(xx+8*jj,yy+8*ii)
			end
		end
	
		self.dead=true	
	end
end

function blast:draw_early()
	if self.colt == 2 then
		--blowup
		for ii =0, self.size do
			sprint("boom",self.x+4+ii*8*dn1(),self.y+4+ii*8*dn1(),10,5)
		end
	end
end

--collision handlers
function collisions_exact(act,hero)
--perform exact collisions
	local myx = hero.x
	local myy = hero.y
	local myid = hero.sprite
	local hb = 3
	if (myid!=3) hb=6
	for k,v in pairs(act) do
		local hisx = v.x
		local hisy = v.y
		local hisid = v.sprite
		if abs(myx-hisx) <= hb 
		and abs(myy-hisy) <= hb 
		and hisid !=3 
		and hisid !=1
		and v.colt <=0 
		and myid != hisid then
			dire = sign(myx-hisx)
 		if myid == 3 and (v.stun and hisid!=47) then
 			if caneat then
 				v.dead=true
 				v.colt=10
 				if not hero.stun then
 					power+=3
						hunger+=5
						hunger=min(hungermax,hunger)
						sprint(ft[1+flr(rnd(#ft))],myx+4,myy-4,7,30)
						sfx(6)
					end
				end
 		else
 			if (myid==3) hero:stunme(60,dire*1.2,-1.2)
				v:stunme(90,-dire*1.2,-1.2)
				if (myid==3) hunger += -5
				if myid==1 then
				 if (burpsplode<1) hero.dead=true
				 v.stunt += 90
				end
			end
		end
	end
end

--make a function to crawl the map
function crawl_map()
	--call this in init
	--this will create entities from sprites
	local entities = {}
	--player is made accessible 
	--separately
	local p1 = nil
	--key needed for entities
	local key = {}
	key[3]=hero
	key[29]=walker
	key[42]=crawler
	key[44]=spitter
	key[47]=fireball
	key[58]=bat
 key[57]=dropper
 key[25]=glider
 key[61]=hopper
 key[15]=slimeball	
	for xx = 0,127 do
		for yy = 0,63 do
			local tile = mget(xx,yy)
			if tile == 3 then
				p1 = hero:inst({x=xx*8,y=yy*8})
				--add(entities,p1)
				--ploc = #entities
				--remove the tile
				mset(xx,yy,0)
			else 
				for kk,vv in pairs(key) do
					if tile == kk then
						--local pe = vv:inst({x=xx*8,y=yy*8})
						add(entities,vv:inst({x=xx*8,y=yy*8}))
						mset(xx,yy,0)
						--fix for crawler
						if (tile==42) mset(xx,yy,51)
					end
				end
			end
		end
	end
	--local vals = {entities,p1}
	return entities,p1
end

function build_game()
	maparray = finalize_map(maparray)
	layout_map(maparray)	
	actors,player1 = crawl_map()
	add(actors,player1)
	burplist={} -- list for attacks
	pretty_tiles()
end

--camera controls
function cam_follow(x,y)
	if x < 64*8 then
		cx = min(max(x-64,0),48*8)
		cy = min(y-64,48*8)
		camera(cx,cy)
		map(0,0,0,0,64,64)
		map(64,0,0,-64*8,64,64)
	elseif x >= 64*8 then
		cx = min(max(x-64,64*8),112*8)
		cy = max(y-64,0)
		camera(cx,cy)
		map(64,0,64*8,0,64,64)
		map(0,0,64*8,64*8,64,64)
	end
end


--global variables

mapdone=false --toggle used to say if map is done building
level=1 -- can be 1 2 3 4 5
theme=16
scheme=132
themes={16,90,86,20}
schemes={{128},
									{132},
									{130,134},
									{136}}
schemecnt={1,1,2,1}
hunger=100 -- if this hits 0 you lose
hungermax=100
hungerloss=60
power=0
powermax=100
ft={"munch","chomp","yum!",
				"burp","bite","owmpf"}
enemies={}
enemylist={{29,1},
										{42,5},
										{44,0.3},
										{58,1},
 									{57,0.5},
 									{25,1},
 									{61,2},
 									{52,1.5}}
speed=1
jump=1.5
burpspeed=30--30
burpsplode=0---0
caneat=false
burpvel=0.5
burpnum=1--1
ladderburp=false
burplife=30
flight=false
flightburn=5
horns=false
laser=false
check_col=0 --o is no, 1 is pacman, 2 is detailed
score=0
timescore=0
powerscore=0
--powerlist
--powerlist={}
--powerlist[70]="jump"

function add_enemy()
	ernd = flr(1+rnd()*#enemylist)
	add(enemies,enemylist[ernd])
end

function _init()
	--mymap mode
	mapmode = true
	theme=themes[1]
	scheme=schemes[1][1]
	add_enemy()
	maparray = init_map()
	maparray,btable,ff = seed_map(maparray)
	t=0
end



function _update60()
	
	--code for updating the game
	if not mapmode then
		--get live actors, those close to hero
		ac={}
		for kk,aa in pairs(actors) do
			if (t==1 or (aa.sprite==1 or aa.sprite==15 or aa.sprite==47 or aa.sprite==0 or (abs(aa.gx - player1.gx)<128 and abs(aa.gy - player1.gy)<128))) add(ac,aa)
		end

		for kk,aa in pairs(ac) do
			if (not aa.stun) aa:update_early()			
			--aa:update()
		end
		--update
		for kk,aa in pairs(ac) do
			aa:update()
	 	aa:draw_early()
	 	if (aa.sprite == 1) collisions_exact(ac,aa)
		 if (aa.dead) del(actors,aa)
		 if (aa.dead) del(actors,ac)
		end
		
		--collision stuff
		--hero and attacks
		
		--all other entities
		--collisions_pac(ac)	
		collisions_exact(ac,player1)
		if (t%60==0) timescore+=1
		--did the player win?
		if player1.x > 64*8 and player1.y < 1 then
		 --fire up the next level!
		 mapmode=true
		 mapdone=false
		 --level+=1
		 camera()
		 oprint("climb "..level.." complete!",36,60,12,7)
		 level+=1
		 hunger = min(hunger+50,100)
			levnum=level
			if (level>4) levnum=1+flr(4*rnd())
			theme=themes[levnum]
			scheme=schemes[levnum][1+flr(schemecnt[levnum]*rnd())]
			add_enemy()
		 sfx(5)
		 hungerloss=flr(hungerloss*0.9)
		 maparray = init_map()
	  maparray,btable = seed_map(maparray)
	  t=0
	 end
	 --lose health
	 if t%hungerloss==0 then
	 	hunger+=-1
	 end
	 --get a power!
	 if power>=powermax then
	  power=0
	  map_destroy(player1.x+4,player1.y-8,70+flr(10*rnd()))
	  sprint("powerup!",player1.x+4,player1.y-10,10,20)
	  sfx(11)
	 end
	 --did i die?
	 if hunger < 0 then
	 	mapmode=true
		 mapdone=false
		 --level+=1
		 camera()
		 oprint("harry starved!",36,50,8,7)
		 oprint("game over!",36,60,8,7)
		 oprint("z to restart",36,70,8,7)
		 sfx(10)
		 level=0
		 maparray = init_map()
	  maparray,btable = seed_map(maparray)
	  t=0
	 end
	end
	
	--code for making the map
	if mapmode then
		if t < 100 and level>0 then
		--kmc the map
	 	for ii=0,9 do
	 		maparray,btable = kmc_map(maparray,btable)
	 	end
	 elseif t>=100 then
	  mapdone=true
	 end
	 if btnp(4) and level == 0 then
	 --reset if necessary
	 	run()
	 end
	 if btnp(4) and mapdone then
	 --set up the game to run
	  mapmode = not mapmode
	  build_game()
	  t=0
	 end
	end
	t+=1
end

function cprint(str,x,y,c)
	ll=#str
	lmid=ll*4/2
	palt(0,false)
	oprint(str,x-lmid,y-2,c,0)
	palt()
end

sl={}--strings to get drawn
function sprint(str,x,y,c,life)
	local o = {}
	o.string=str
	o.x=x
	o.y=y
	o.c=c
	o.life=life
	add(sl,o) 
end

function oprint(str,x,y,c1,c2)
	--outlined text
	--c1 is interior
	--c2 is outline
	for xx=x-1,x+1 do
		for yy=y-1,y+1 do
			print(str,xx,yy,c2)
		end
	end
	print(str,x,y,c1)
end

--tl={}
--tl[2]={}
--tl[3]={}
tl={"what a fall!",
"harry has to get out!",
"but harry is hungry...",
"harry eat mushrooms on the way",
"harry can climb with ⬆️",
"use ❎ to burp at foes!",
"and he can dig with ⬇️",
"please help harry out!"}	
tlc=0

function _draw()
	
	--mapmode art
	--draw all your loading stuff here
	if mapmode then
		--title screen
		if level==1 then
			if t < 15 then
				poke(0x5f2c,3)
				cls(1)
				cprint("palo",32,12,15)
			 cprint("blanco",32,18,15)
			 cprint("games",32,24,15)
				cprint("presents",32,36,12)
				if (t==1) music(5)
			elseif t < 200 then
				poke(0x5f2c,3)
				camera()
				cls()
			 map(0,0,0,0,8,8)
			 cprint("hungry",32,3,12)
			 cprint("harry's",32,9,12)
			 cprint("climb",32,15,12)
			 if (t==16) sfx(15)
--			 cprint("palo blanco games",32,55,12)
  	else
  		poke(0x5f2c,0)
  		cls(1)
  		if (t==201) music(0)
  		map(24,0,0,0,16,16)
  		cprint("z or c to start!",64,120,12)
			end
		elseif level == 5 then
			reload(0x2000,0x2000,0x1000)
 		cls(1)
 		map(8,0,0,0,16,16)
 		color(7)
 		print([[
 								harry escaped!
 							congratulations!
 		]])
 		print("  score: "..score)
 		print("  time: "..timescore)
 		print("  powerups: "..powerscore)
 		print("you can keep playing")
 		print(" loading: "..min(100,t))
 		if (t>99) print("    z or c to start!")
 		color()

		elseif level != 0 then
  	if t%5 == 0 then
  		poke(0x5f2c,0)
  		reload(0x2000,0x2000,0x1000)
  		cls(0)
  		map(40,0,0,0,16,16)
  		print("")
  		color(7)
  		print("    score: "..score.."   time: "..timescore)
  		print("    next level: "..level.."  of 4")
  		print("    loading: "..min(100,t))
  		if (t>99) print("    z or c to start!")
  		color()
			end

		
		end
	--draw the actual gameplay
	--if not in mapmode
	else
		poke(0x5f2c,0)
		cls()
		cam_follow(player1.x,player1.y)
		
		--draw actors
		for aa in all(actors) do
			if (abs(aa.gx-player1.gx)<128 and abs(aa.gy-player1.gy)<128) then
				aa:draw_setup()
				local mm=0
				if (aa.x > 64*8 and player1.x < 64*8) mm=2
				if (aa.x < 64*8 and player1.x > 64*8) mm=3
				aa:draw(mm)
			end
		end
		
		--draw particles
		--particles_update()
		--particles_draw()
		
		--draw flavor text
		for k,v in pairs(sl) do
			cprint(v.string,v.x,v.y,v.c)
			v.life+=-1
			if (v.life <= 0) del(sl,sl[k])
		end
		
		--print(stat(1),cx+8,cy+8,10)
		--print("lvl"..level,cx+8,cy+1,10)
		--draw hunger
		spr(65,cx+71,cy+1)
		oprint(hunger,cx+81,cy+2,8)
		spr(81,cx+98,cy+1)
		oprint(power,cx+108,cy+2,12)
		--end
		line(cx+124,cy,cx+124,cy+127,6)
		spr(80,cx+127-9,cy+1)
		circ(cx+124,-3+cy+flr((player1.y/8)+64*(1-flr((player1.x/8)/64))),2,9)

		--draw flavor text to help out
		if level == 1 then
			if (t%90==0) then
				tlc+=0.5
				tx=tl[tlc]
				if (tx != nil) sprint(tx,player1.x+4,player1.y-4,12,70)
			end
		end 
		--draw helper arrow
	end
end

--u60=_update60 _update60=nil function _update() u60() u60() end