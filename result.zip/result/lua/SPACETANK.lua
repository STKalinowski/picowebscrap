--spacetank 9000
--by ashley pringle
cartdata("spacetank")

debug=false
debug_l={}

function _init()
	state=0
	timer=0
	changestate(state)
	--machinegun
	bullettype={}
	bullettype[1]={}
	bullettype[1].vel=6
	bullettype[1].rof=2
	bullettype[1].dest=true--{destroy/bounce,momentum}
	bullettype[1].num=1
	bullettype[1].acc=0.02
	bullettype[1].snd=3
	bullettype[1].rec=0.02
	bullettype[1].dam=1
	bullettype[1].proj=1
	bullettype[1].heat=5
	--shotgun
	bullettype[2]={}
	bullettype[2].vel=5
	bullettype[2].rof=10
	bullettype[2].dest=true--{destroy/bounce,momentum}
	bullettype[2].num=10
	bullettype[2].acc=0.05
	bullettype[2].snd=16
	bullettype[2].rec=0.1
	bullettype[2].dam=1
	bullettype[2].proj=1
	bullettype[2].heat=30
	--minigun
	bullettype[3]={}
	bullettype[3].vel=8
	bullettype[3].rof=1
	bullettype[3].dest=true--{destroy/bounce,momentum}
	bullettype[3].num=3
	bullettype[3].acc=0.045
	bullettype[3].snd=15
	bullettype[3].rec=0.03
	bullettype[3].dam=1
	bullettype[3].proj=1
	bullettype[3].heat=10
	--cannon
	bullettype[4]={}
	bullettype[4].vel=8
	bullettype[4].rof=8
	bullettype[4].dest=true--{destroy/bounce,momentum}
	bullettype[4].num=1
	bullettype[4].acc=0
	bullettype[4].snd=17
	bullettype[4].rec=0.06
	bullettype[4].dam=3
	bullettype[4].proj=2
	bullettype[4].heat=30
	--bouncy ball
	bullettype[5]={}
	bullettype[5].vel=4
	bullettype[5].rof=16
	bullettype[5].dest=false--{destroy/bounce,momentum}
	bullettype[5].num=1
	bullettype[5].acc=0
	bullettype[5].snd=24
	bullettype[5].rec=0
	bullettype[5].dam=3
	bullettype[5].proj=3
	bullettype[5].heat=60
		--light lazer
	bullettype[6]={}
	bullettype[6].vel=0
	bullettype[6].rof=2
	bullettype[6].dest=true--{destroy/bounce,momentum}
	bullettype[6].num=1
	bullettype[6].acc=0
	bullettype[6].snd=25
	bullettype[6].rec=0
	bullettype[6].dam=0.2
	bullettype[6].proj=4
	bullettype[6].heat=5
	--bouncy ballz tm
--	bullettype[7]={}
--	bullettype[7].vel=9
--	bullettype[7].rof=16
--	bullettype[7].dest=false--{destroy/bounce,momentum}
--	bullettype[7].num=10
--	bullettype[7].acc=0.08
--	bullettype[7].snd=24
--	bullettype[7].rec=0
--	bullettype[7].dam=3
--	bullettype[7].proj=3
--	bullettype[7].heat=60
	
	enums={}
	--actor types
	enums.tank=1
	enums.bullet=2
	enums.enemy=3
	enums.debris=4
	enums.explosion=5
	enums.cloud=6
	enums.crate=7
	--enemy types
	enums.ufo=1
	enums.man=2
	enums.missile=3
	enums.intro=0
	--gun types
	enums.machinegun=1
	enums.shotgun=2
	enums.minigun=3
	enums.cannon=4
	enums.bouncyball=5
	enums.lazer=6
	--projectile types
	
	--game states
	enums.title=1
	enums.options=2
	enums.game=3
	
	hud={}
	hud.bar={}
	hud.bar.x=12
	hud.bar.y=10
	hud.bar.w=100
	hud.bar.h=6
	hud.bar.c=8
	hud.score={}
	hud.score.x=12
	hud.score.y=4
	hud.hp={}
	hud.hp.x=100
	hud.hp.y=4

	hillspacing=50
end

function generatelandscape(gh,hh,gw,hw,hs,first)
	level+=1
	local los,his=0,0
	ground[1]={0,0}
	for a=2,200 do
		local h=0
		h=gh
		if his>0 then
			if his>hw then 
				his=0
				los+=1
			else
				his+=1
				h+=hh
			end
		elseif los>gw then
				los=0
				h+=hh
				his+=1
		else
				los+=1
		end
		ground[a]={a*hs,-flr(rnd(h))}
		if not first then
			if a>1 and a<6 then
				ground[a][2]=ground[195+a][2]
			end
		end
		local w=ground[a][1]-ground[a-1][1]
		local h=ground[a-1][2]-ground[a][2]
		ground[a-1].ratio=h/w
		ground[a-1].d=atan2(w,h)
	end
end

function distance(x1,y1,x2,y2)
	--need to div by 10 bc numbers were getting way to big and overflowing, giving negatives output
	local a=(x2-x1)/10  local b=(y2-y1)/10
	return (a*a+b*b)
end

function getgroundheight(x)
	local gx=flr(x/hillspacing)
	if gx>1 and gx<200 then
		if ground[gx][1]<x and ground[gx+1][1]>x then
			local w=x-ground[gx][1]
			return ground[gx][2]-w*ground[gx].ratio
		elseif ground[gx][1]==x then
			return ground[gx][2]
		end
	end
	return 0
end

function getgrounddir(a)
	for b=1,#ground-1 do
		if ground[b][1]<a.x and ground[b+1][1]>a.x then
			return ground[b].d
		end
	end
end

function makeactor(t,x,y,d,vel)
	local actor={}
	actor.t=t
	actor.x=x
	actor.y=y
	actor.d=d
	actor.vec={cos(d),sin(d)}
	actor.vel=vel
	actor.grav=true
	actor.delta=timer
	actor.accel=0.08
	actor.decel=0.02
	actor.maxvel=5

	add(actors,actor)
	return actor
end

function maketank(x,y,d,vel,bt)
	local tank=makeactor(1,x,y,d,vel)
	tank.bt=bt
	tank.hp=3
	tank.hit=0
	tank.drop=1
	tank.hitsfx=21
	tank.deathsnd=23
	makehitbox(tank,-4,-10,8,10)
	tank.gun={}
	tank.gun.angle=0.25
	tank.gun.len=6
	tank.gun.x=0
	tank.gun.y=0
	tank.gun.vec={0,0}
	tank.gun.delta=0
	tank.gun.heat=0
	
	tank.xoff=-3
	tank.yoff=-7
	return tank
end

function makebullet(x,y,d,vel,bt)
	local bullet=makeactor(2,x,y,d,vel)
	bullet.tail={x,y}
	bullet.bt=bt
	if bullet.bt==enums.bouncyball then
		bullet.bouncy=true
		bullet.decel=0
	elseif bullet.bt==enums.lazer then
		bullet.grav=false
		bullet.decel=0
	end
end

function makeenemy(x,y,d,vel,bt,et,hp,sp)
	local enemy=makeactor(3,x,y,d,vel)
	enemy.et=et
	enemy.hp=hp
	enemy.hitsfx=5
	if et==enums.ufo then
		enemy.grav=false
		enemy.drop=0.4
		makehitbox(enemy,1-8,2-4-4,12,9)
	elseif et==enums.man then
		enemy.deathsnd=18
		enemy.drop=0
		enemy.bouncy=true
		enemy.sp=sp
		makehitbox(enemy,0-4,0-4,8,8)
	elseif et==enums.missile then
		sfx(20)
		enemy.grav=false
		enemy.drop=0.2
		makehitbox(enemy,0-4,0-4,5,8)
		counters.missiles+=1
	end
	counters.enemies+=1
end

function makedebris(x,y)
	local debris=makeactor(4,x,y,rnd(0.5),rnd(4)+3)
	debris.angle=rnd(1)
	debris.w=6
	debris.bounce=0
	debris.bouncy=true
	return debris
end

function makeexplosion(x,y)
	local e=makeactor(5,x,y,0,0)
	sfx(2)
	e.grav=false
	cam.shake=10
	for j=1,10 do
		makecloud(e.x+rnd(20)-10,e.y+rnd(20)-10,10)
	end
end

function makecloud(x,y,r)
	if x>cam[1] and x<cam[1]+128 then
		local e=makeactor(6,x,y,0,0)
		e.r=r
		e.grav=false
	end
end

function makecrate(x,y,w,bt)
	local c=makedebris(x,y)
	c.t=7
	c.w=w
	c.bt=bt
	c.vel=rnd(4)+4
	c.d=rnd(0.15)
	c.decel=0.03
	c.bouncy=true
	makehitbox(c,-w/2-4,-w/2-4,w+6,w+6)
end

function makehitbox(a,x,y,w,h)
	a.hitbox={}
	a.hitbox.x=x
	a.hitbox.y=y
	a.hitbox.w=w
	a.hitbox.h=h
end

function drawactor(t)
	if t.t==enums.tank then
		spr(1,t.x+t.xoff,t.y+t.yoff)
		line(t.x+1,t.y-4+t.yoff+7,t.gun.x,t.gun.y+7,8)
	elseif t.t==enums.bullet then
		--normal bullets
		if bullettype[t.bt].proj==1 then
			line(t.x,t.y,t.tail[1],t.tail[2],7)
		--cannon shell
		elseif bullettype[t.bt].proj==2 then
			circfill(t.x,t.y,4,7)
			circfill(t.tail[1],t.tail[2],3,7)
		--bouncy ball
		elseif bullettype[t.bt].proj==3 then
			circ(t.x,t.y,6+(cos(timer/20))*2,7)
			circ(t.x,t.y,3+(sin(timer/20))*2,7)
		--lazer
		elseif bullettype[t.bt].proj==4 then
			line(player.gun.x,player.gun.y-player.yoff,t.x,t.y,7)
		end
	elseif t.t==enums.enemy then
		if t.et==enums.ufo then
			spr(19+flr(cos(timer/20))*2,t.x-8,t.y-4,2,1)
		elseif t.et==enums.man then
			spr(t.sp+(timer/20)%2,t.x-4,t.y-4)
		elseif t.et==enums.missile then
			spr(50,t.x-4,t.y-4,1,1)
		end
	elseif t.t==enums.debris then
		line(t.x-cos(t.angle)*t.w/2,t.y-sin(t.angle)*t.w/2,t.x+cos(t.angle)*t.w,t.y+sin(t.angle)*t.w,8)
	elseif t.t==enums.explosion then
		circfill(t.x,t.y,5+(timer-t.delta)*10,7)
	elseif t.t==enums.cloud then
		circfill(t.x,t.y,t.r-(timer-t.delta)*1,5)
	elseif t.t==enums.crate then
		drawbox(t.x,t.y,t.w,t.angle)
	end
	if debug then
		if t.hitbox!=nil then
			rect(t.x+t.hitbox.x,t.y+t.hitbox.y,t.x+t.hitbox.x+t.hitbox.w,t.y+t.hitbox.y+t.hitbox.h,12)
			pset(t.x,t.y,10)
		end
	end
end

function drawbox(x,y,w,a)
	for i=0,3 do
		line(x+cos(a+i*0.25)*w/2,y+sin(a+i*0.25)*w/2,x+cos(a+(i+1)*0.25)*w/2,y+sin(a+(i+1)*0.25)*w/2,7)
	end
end

function collision(a,enemy)
	if a.x>enemy.x+enemy.hitbox.x then
	if a.x<enemy.x+enemy.hitbox.x+enemy.hitbox.w then--+a.vec[1]*a.vel
	if a.y>enemy.y+enemy.hitbox.y then---a.vec[2]*a.vel
	if a.y<enemy.y+enemy.hitbox.y+enemy.hitbox.h then
		return true
	end
	end
	end
	end
	return false
end

function controlactor(a)
	if a.t==enums.tank then
		if a.x>198*hillspacing then
			generatelandscape(20-rnd(15),60-rnd(50),3+rnd(6),3+rnd(12),hillspacing,false)
			for actor in all(actors) do 
				local diff=actor.x-198*hillspacing
				actor.x=hillspacing*3+diff
				if actor.x<=0 or actor.x>=hillspacing*200 then
					del(actors,actor)
				end
			end
			mothership.x=0
		end
		if btn(5) or btn(3) then
			a.vel-=a.decel*4
		else
			a.vel+=a.accel
		end
		if btn(1) then
			a.gun.angle=clamp(a.gun.angle-0.016,0,0.5,true)
		elseif btn(0) then 
			a.gun.angle=clamp(a.gun.angle+0.016,0,0.5,true)
		end
		
		a.vel=clamp(a.vel,-a.maxvel,a.maxvel,true)
		
		a.gun.vec[1]=cos(a.gun.angle)
		a.gun.vec[2]=sin(a.gun.angle)
		a.gun.x=a.x+1+a.gun.vec[1]*a.gun.len
		a.gun.y=a.y-4+a.gun.vec[2]*a.gun.len
		
		if a.hit>0 then
			a.hit-=1
		end
	elseif a.t==enums.bullet then
		a.tail={a.x-a.vec[1],a.y-a.vec[2]}
		if a.bt==enums.cannon then
			makecloud(a.x+rnd(10)-5,a.y+rnd(10)-5,3)
		elseif a.bt==enums.lazer then
			if timer-a.delta>=2 then
				del(actors,a)
			end
		end
		for enemy in all(actors) do
			if enemy.t==enums.enemy then
				if collision(a,enemy) then
					damageactor(enemy,bullettype[a.bt].dam)
					if a.bt!=enums.bouncyball then
						del(actors,a)
					end
					makedebris(a.x,a.y)
				elseif a.bt==enums.cannon or a.bt==enums.bouncyball then
					if distance(a.x,a.y,enemy.x,enemy.y)<2 then
						damageactor(enemy,bullettype[a.bt].dam)
						if a.bt!=enums.bouncyball then
							del(actors,a)
						end
					makedebris(a.x,a.y)
					end
				end
				if bullettype[a.bt].proj==4 then
					local ld=atan2(enemy.x-player.gun.x,enemy.y-player.gun.y-player.yoff)
					--todo: fix this so that it doesnt jump from 0 to 1 when you try to check if ld is > gun angle
					if ld>player.gun.angle-0.02 and ld<player.gun.angle+0.02 then
						damageactor(enemy,bullettype[a.bt].dam)
					end
				end
			end
		end
	elseif a.t==enums.enemy then
		if a.et==enums.ufo then
			if a.x<=player.x+50 then
				a.maxvel=8
			else
				a.maxvel=4
			end
			if a.vel<=a.maxvel then
				a.vel+=a.accel
			else
				a.vel-=3
			end
			if counters.missiles<=0 then
				if flr(a.x)==flr(player.x)+30 then
					makeenemy(a.x,a.y,0.9,4,1,3,1)
				end
			end
		elseif a.et==enums.man then
			a.vel=4
			if timer%2==0 then
				makecloud(a.x+1+rnd(4)-2,a.y+4+rnd(4)-2,2)
			end
		elseif a.et==enums.missile then
			--missile stuff
			a.vel=3
			if collision(a,player) then
				player.hit=20
				damageactor(player,1)
				damageactor(a,1)
			end
			if a.y>=getgroundheight(a.x) then
				damageactor(a,1)
			end
		end
	elseif a.t==enums.debris then
			a.angle+=0.1*a.vec[1]
			if timer-a.delta<=1 then
				a.bounce+=1
		end
		if a.bounce==4 then
			for j=1,4 do
				makecloud(a.x+rnd(20)-10,a.y+rnd(20)-10,6)
			end
			sfx(6)
			del(actors,a)
		end
	elseif a.t==enums.explosion then
		if timer-a.delta>=2 then
			for b=1,#actors do
				local t=actors[b]
				if t.t==enums.enemy then
					if distance(a.x,a.y,t.x,t.y)<5 then
						damageactor(t,2)
					end
				end
			end
			del(actors,a)
		end
	elseif a.t==enums.cloud then
		if timer-a.delta>=30 then
			del(actors,a)
		end
	elseif a.t==enums.crate then
		a.angle-=0.01*cos(a.d)*a.vel
		if timer-a.delta<=1 then
			a.bounce+=1
		end
		if collision(player,a) then
			sfx(14)
			counters.gets+=1
			for b=1,4 do
				makedebris(a.x,a.y)
			end
			while a.bt==player.bt do
				a.bt=flr(rnd(#bullettype))+1
			end
			player.bt=a.bt
			player.gun.heat=0
			player.gun.delta=0
			del(actors,a)
		end
	end

	if a.y<getgroundheight(a.x) then
		if a.grav then
			a.y+=gravity*(timer-a.delta)
			if a.t==enums.tank then
				a.yoff=-7
			end
		end
	else
		if a.t==enums.tank then
			a.yoff+=sin(timer/(12))
		end
		if a.t!=enums.cloud then
			if a.t!=enums.explosion then
				a.delta=timer
			end
		end
		if not a.bouncy then
			a.d=getgrounddir(a)
		end
		if a.t==enums.bullet then
			if a.x>cam[1] and a.x<cam[1]+128 then
				sfx(4)
			end
			--make an array of functions for this?
			--each function is indexed from array with the .bt value
			if bullettype[a.bt].dest then
				if bullettype[a.bt].proj==1 then
					makecloud(a.x+rnd(20)-10,a.y+rnd(20)-10,5)
				elseif bullettype[a.bt].proj==2 then
					makeexplosion(a.x,a.y)
				end
				del(actors,a)--delete for bounce!
			end
		end
		a.y=getgroundheight(a.x)+1
	end
	
	a.vec[1]=cos(a.d)
	a.vec[2]=sin(a.d)
	a.x+=a.vec[1]*a.vel
	a.y+=a.vec[2]*a.vel
 
	if a.vel<0 then
		a.vel+=a.decel
	elseif a.vel>0 then
		a.vel-=a.decel
	end
 
 if a.x<cam[1]-128
 or a.x>cam[1]+512
 or a.y>128
 or a.y<-512
 or a.x>=200*hillspacing
 or a.x<=1*hillspacing then
 	if a.t==enums.enemy then
 		counters.enemies-=1
 		if a.et==enums.missile then
 			counters.missiles-=1
 		end
 	end
 	if a.t!=enums.tank then
 		del(actors,a)
 	end
 end
 
 if a.t==enums.tank then
		if a.gun.len<6 then
			a.gun.len+=1
		end
		a.gun.x=a.x+1+a.gun.vec[1]*a.gun.len
		a.gun.y=a.y-4+a.gun.vec[2]*a.gun.len+a.yoff
		if a.gun.delta==0 then
			hud.bar.c=8
			if btn(4) then
				sfx(bullettype[a.bt].snd)
				a.gun.len=2
				a.gun.heat+=bullettype[a.bt].heat
				if bullettype[a.bt].proj==4 then
					--lazer
					makebullet(a.gun.x+a.gun.vec[1]*100,a.gun.y+a.gun.vec[2]*100,a.gun.angle,0,a.bt)
				else
					local bvel=sqrt( (a.gun.vec[1]*bullettype[a.bt].vel+a.vec[1]*a.vel)^2+(a.gun.vec[2]*bullettype[a.bt].vel+a.vec[2]*a.vel)^2 )
					for b=1,bullettype[a.bt].num do
						makebullet(a.gun.x,a.gun.y+7,a.gun.angle+rnd(bullettype[a.bt].acc)-bullettype[a.bt].acc/2,bvel+rnd(1)-1,a.bt)
					end
					if a.gun.angle<0.25 then
						a.gun.angle+=bullettype[a.bt].rec
					end
				end
				a.gun.delta=bullettype[a.bt].rof
			end
		else 
			a.gun.delta-=1
			if a.gun.delta>20 then
				if timer%3==0 then
					makecloud(a.gun.x,a.gun.y+6,4)
					hud.bar.c=7
				end
			end
		end
		if a.gun.heat>0 then
			if a.gun.heat>=100 then
				a.gun.heat=100
				a.gun.delta=100
				sfx(19)
			end
			a.gun.heat-=1
		else
			a.gun.heat=0
		end
		
		--stuff below can prob be elsewhere
		if cam.shake>0 then
			cam.shake-=1
		end
		cam[1]=a.x+8*a.vel+rnd(cam.shake)*2-56
		if a.y<-60 then
			cam[2]=-118+a.y+60
		else
			cam[2]=-118
		end
		if a.vel<1.5 then
			mothership.x+=1.5
			mothership.c=7
			mothership.spr=67
		elseif a.vel<3.5 then
			mothership.x+=a.vel+0.1
			mothership.c=7
			mothership.spr=67
		end
		if mothership.x>a.x then
			if a.hp>0 then
				damageactor(a,3)
			end
		elseif mothership.x<cam[1]-1 then
			mothership.x=cam[1]-1
			mothership.c=0
			mothership.spr=110
		else
			sfx(38)
		end
	end
end

function damageactor(a,d)
	sfx(a.hitsfx)
	pal(8,7)
	a.hp-=d-- or 3
	if a.hp<1 then
		sfx(a.deathsnd)
		pause=2
		if a.et==enums.ufo then
			for b=1,6 do
				makedebris(a.x,a.y)
			end
		elseif a.et==enums.missile then
			counters.missiles=clamp(counters.missiles-1,0,99,true)
		end
		makeexplosion(a.x,a.y)
		if rnd(1)<a.drop+1/(level*2) then
			makecrate(a.x,a.y,12,flr(rnd(#bullettype))+1)
		end
		del(actors,a)
		counters.enemies-=1
	end
end

function spawnentities()
	if counters.enemies<level then
		if spawntimer<10 then
			spawntimer+=1
		else
			spawntimer=0
			if rnd(1)<0.3 then
				--spawn man
				if player.hp>0 then
					makeenemy(cam[1]+130,getgroundheight(cam[1]+130)-rnd(10),0.15,3,6,2,1,33)
				--spawn celebrator
				else
					makeenemy(cam[1]-12,-rnd(128),0.15,3,6,2,1,35)
				end
			elseif rnd(1)<0.3 then
				--spawn ufo
				makeenemy(cam[1]-12,-100+rnd(40),0,5,6,1,3)
			elseif rnd(1)<0.1 then
				if level>4 then
					--spawn truck
				end
			end
		end
	end
end

function _update()
	if state==enums.intro then
		if btnp(4) or timer>=1140 then
			sfx(2)
			changestate(enums.title)
		end
	elseif state==enums.title then
		if btnp(4) then
			makeexplosion(60,60)
			titletimer=20
		elseif btnp(5) then
			changestate(enums.options)
		end
		if titletimer>1 then
			titletimer-=1
		elseif titletimer==1 then
			changestate(enums.game)
		end
	elseif state==enums.options then
		if btnp(4) or btnp(5) then
			changestate(enums.title)
		end
	elseif state==enums.game then
		if pause==0 then
			foreach(actors,controlactor)
			if player.hp<=0 then
				mothership.x-=0.5
			end
			spawnentities()
		else
			pause-=1
		end
		if player.hp<=0 then
			if counters.gets>dget(0) then
				dset(0,counters.gets)
			end
			deathtimer+=1
			if deathtimer>60 then
				if btnp(4) then
					changestate(enums.game)
				end
			end
		end
		if debug then
			debug_u()
		end
	end
	timer+=1
end

function _draw()
	cls()
	camera(cam[1],cam[2])
	if state==enums.intro then
		drawintro(0,120,255,{16,40,50,60},{1,2,2,2})
	elseif state==enums.title then
		spr(128,0,0,4,4)
		spr(132,28,0,4,4)
		spr(136,52,0,4,4)
		spr(140,78,0,4,4)
		spr(192,104,0,4,4)
		spr(196,10,32,4,4)
		spr(136,38,32,4,4)
		spr(200,64,32,4,4)
		spr(204,92,32,4,4)
		print("9000",53,68,8)
		print("start: 🅾️",44,80,8)
		print("instructions: ❎",29,90,8)
		print("hi score: "..dget(0),36,106,8)
		print("by:@ashleypringle",28,122,7)
		foreach(actors,drawactor)
	elseif state==enums.options then
		pal(7,flr(rnd(15))+1)
		print("instructions:",40,10,8)
		spr(19+flr(cos(timer/20))*2,0,22,2,1)
		spr(33+(timer/20)%2,3,32,1,1,true)
		print("the aliens possess powerful\nweapon technology which\nmutates the geneology of\nweapons",20,20,8)
		print("they can't be trusted with\nsuch powerful arms\ndestroy them and salvage\ntheir tech to mutate\nspacetank's weapon so\nit can be used for good",20,50,8)
		drawbox(7,66,12,-timer/100)
		spr(1,2,94+sin(timer/(12)),1,1)
		line(5,98+sin(timer/(12)),10,94+sin(timer/(12)),8)
		print("shoots = 🅾️\ngun angle = ⬅️ or ➡️\nbrake = button ❎ or ⬇️",20,90,8)
	elseif state==enums.game then
		pal(7,flr(rnd(15))+1)
		if player.hit>0 then
			pal(8,flr(rnd(15))+1)
		end
		if timer<30 then
			sspr(8,32,16,16,135,-230,32,32)
		end
		for a=1,#ground-1 do
			line(ground[a][1],ground[a][2],ground[a+1][1],ground[a+1][2],8)
			line(ground[a][1]+8,ground[a][2]+8,ground[a+1][1]+8,ground[a+1][2]+8,7)
		end
		spr(24,300,getgroundheight(300)-23,7,3)
		print(level,312,getgroundheight(300)-5,7)
		if mothership.x>cam[1] then
			rectfill(mothership.x-10,cam[2]+12,mothership.x-1,getgroundheight(mothership.x),mothership.c)
			circfill(mothership.x-5.5,getgroundheight(mothership.x),4.95,mothership.c)
			spr(mothership.spr,mothership.x-12,cam[2],2,2)
		end
		foreach(actors,drawactor)
		if player.gun.heat>0 then
			rectfill(cam[1]+hud.bar.x,cam[2]+hud.bar.y,cam[1]+hud.bar.x+player.gun.heat,cam[2]+hud.bar.y+hud.bar.h,hud.bar.c)
			rect(cam[1]+hud.bar.x,cam[2]+hud.bar.y,cam[1]+hud.bar.x+hud.bar.w,cam[2]+hud.bar.y+hud.bar.h,8)
		end
		print("crates:"..counters.gets,cam[1]+hud.score.x,cam[2]+hud.score.y,8)
		print("hp:"..player.hp,cam[1]+hud.hp.x,cam[2]+hud.hp.y,8)
		if player.hp<=0 then
			print("space tank died",cam[1]+34,cam[2]+50,8)
			print("in the year 9000",cam[1]+32,cam[2]+60,8)
			print("with "..counters.gets.." weapon crates",cam[1]+24,cam[2]+70,8)
			if deathtimer>60 then
				if timer%40<=20 then
					print("restart: button 1",cam[1]+30,cam[2]+80,8)
				end
			end
		end
		pal()
		if debug then
			for a=1,#debug_l do
				print(debug_l[a],cam[1]+0,cam[2]+(a-1)*6,11)
			end
		end
	end
end

function drawintro(x,y,st,td,col)
	local ind=0
	for a=0,2 do
		if timer>st*2^a then ind=a+1 end
	end
	for a=1,#introtext do
		print(introtext[a],x,y+a*7-timer/4,7+((timer+(a-1)*10)/td[ind+1])%col[ind+1])
	end
end

function clamp(v,mi,ma,h)
	if h then
		if v<mi then v=mi
		elseif v>ma then v=ma
		end
	else
		if v<mi then v=ma
		elseif v>ma then v=mi
		end
	end
	return v
end

function changestate(s)
	state=s
	timer=0
	cam={0,0}
	cam.shake=0
	
	actors={}
	introtext={}
	titletimer=0
	music(-1)
	if state==0 then
		music(0)
		add(introtext,"it is the year 9000")
		add(introtext,"")
		add(introtext,"humanity has expanded its empire")
		add(introtext,"to the outer reaches of the")
		add(introtext,"universe")
		add(introtext,"")
		add(introtext,"we have finally reached planet x")
		add(introtext,"fabled home world of the")
		add(introtext,"invaluable 'space ore'")
		add(introtext,"")
		add(introtext,"humanity's mining operations")
		add(introtext,"have been wildly successful")
		add(introtext,"the precious space ore has")
		add(introtext,"brought prosperity and peace")
		add(introtext,"to humanity, but....")
		add(introtext,"")
		add(introtext,"the evil x-onians are disrupting")
		add(introtext,"our mining operations")
		add(introtext,"they destroy our mines and")
		add(introtext,"steal our hard earned ore")
		add(introtext,"")
		add(introtext,"without the valuable space ore")
		add(introtext,"humanity's economy will collapse")
		add(introtext,"and chaos will ensue")
		add(introtext,"")
		add(introtext,"there is only one way")
		add(introtext,"for us to stop them")
		add(introtext,"")
		add(introtext,"you have the technology")
		add(introtext,"you are powerful and good")
		add(introtext,"you are..........")
	elseif state==3 then
		sfx(37)
		pause=0
		spawntimer=0
		level=0
		ground={}
		generatelandscape(10,40,3,3,hillspacing,true)
		counters={}
		counters.enemies=0
		counters.gets=0
		counters.missiles=0
		gravity=0.2
		deathtimer=0
		player=maketank(150,-200,0,0,1)
		mothership={}
		mothership.x=120
		mothership.y=getgroundheight(mothership.x)
		mothership.c=7
		mothership.spr=67
	end
end

function debug_u()
	debug_l[1]=timer
	debug_l[2]="mem="..stat(0)
	debug_l[3]="cpu="..stat(1)
	debug_l[4]="actors:"..#actors
	debug_l[5]="tank x:"..player.x
	debug_l[6]="tank y:"..player.y
	debug_l[7]="tank vel:"..player.vel
	debug_l[8]="gun x:"..player.gun.x
	debug_l[9]="gun y:"..player.gun.y
	debug_l[10]="gun d:"..player.gun.angle
	debug_l[11]="gun vx:"..player.gun.vec[1]
	debug_l[12]="gun vy:"..player.gun.vec[2]	
	debug_l[13]="ratio:"..getgroundheight(player.x)
	debug_l[14]="tank vx:"..player.vec[1]
	debug_l[15]="tank vy:"..player.vec[2]
	debug_l[16]="enemy cnt:"..counters.enemies
	debug_l[17]="missiles cnt:"..counters.missiles
	debug_l[18]="camx:"..cam[1]
	debug_l[19]="camy:"..cam[2]
	debug_l[20]="level:"..level
	debug_l[21]="spawnt:"..spawntimer
end