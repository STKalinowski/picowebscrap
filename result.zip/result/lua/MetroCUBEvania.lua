-- metrocubevania
-- by flytrap studios

function print_centered(str,x,y,col)
 print(str,x-#str*2,y-3,col)
end

function explode(x,y)
 e_max+=1
 e_x[e_max]=x
 e_y[e_max]=y
 e_img[e_max]=0
end

function odd(n)
 return n%2
end

function included(a,b,c)
	return a>=b and a<=c
end

function text(s,t)
 alarm[0]=t
 txt=s
end

function die()
 dead=15
 deaths+=1
 canmove=false
 sfx(1)
end

function room_update()
 local i,j,x1,y1
 alarm[1]=-1
 room_x=flr(px/16)
 room_y=flr(py/16)
 
 bul_max=0
 
 -- play music
 for i=1,4 do
  if room_x==mus_x[i] and room_y==mus_y[i]
  and not mus_played[i] then
   music(i)
   mus_played[i]=true
  end
 end
 
 for i=0,15 do
  for j=0,15 do
   x1=room_x*16+i
   y1=room_y*16+j
   
   if fget(mget(x1,y1),4)
    then
     bul_x[bul_max]=0
     bul_y[bul_max]=0
     bul_sx[bul_max]=x1
     bul_sy[bul_max]=y1
     if mget(x1,y1)==27
     then bul_shs[bul_max]=0
          bul_svs[bul_max]=-1
     elseif mget(x1,y1)==28
     then bul_shs[bul_max]=0
          bul_svs[bul_max]=1
     elseif mget(x1,y1)==29
     then bul_shs[bul_max]=-1
          bul_svs[bul_max]=0
     elseif mget(x1,y1)==30
     then bul_shs[bul_max]=1
          bul_svs[bul_max]=0
     end
     bul_max+=1
   end
   
   if mget(x1,y1)==35 and power[3]
   then
    mset(x1,y1,0)
   end
  end
 end
 
 if bul_max>0 then
  alarm[2]=15
 end
end

function checkpoint()
 local i,j
 for i=0,127 do
  for j=0,63 do
   if mget(i,j)==40 then
    mset(i,j,39)
    break
   end
  end
 end 
 
 mset(px,py,40)
 sx=flr(px)+0.5
 sy=flr(py)+0.5
 sfx(4)
end

function power_get()
 local id
 id=mget(px,py)-55
 power[id]=true
 sfx(2)
 mset(px,py,0)
 power_id=id
 alarm[1]=30
 text(power_txt[id+1],90)
end

function map_init()
 local power_id
 for i=0,127 do
  for j=0,63 do
   if flag(i,j,3) then
    power_id=mget(i,j)-55
    power_x[power_id]=i
    power_y[power_id]=j
    power[power_id]=false
   end
   
   if mget(i,j)==41 then
    medal_max+=1
   end
   
  end
 end
end

function flag(x,y,f)
 val=mget(x,y)
 return fget(val,f)
end

function spr_flag(x,y,w,h,f)
	val=flag(x-w,y-h,f) or
					flag(x-w,y+h,f) or
					flag(x+w,y-h,f) or
					flag(x+w,y+h,f)
	return val
end

function player_move_solid(ydir)
 local i
 i=0
 while not spr_flag(px,py+i+0.1*ydir,0.4,0.4,0)
 do i+=0.1*ydir
 end
 
 if ydir==1 then
  py=flr(py+i-0.5)+0.5
 elseif ydir==-1 then
  py=ceil(py+i-0.5)+0.5
 end
end
-->8
-- init

function _init()
 local i
 alarm={}
 for i=0,3 do
  alarm[i]=-1
 end
 cheat=false
 frame=0
 screen=0
 intro=true
 alarm[3]=-1
 px=38
 py=40
 room_x=2
 room_y=2
 spd=0.25
 grav=0.05
 jspd=-0.5
 vspd=0
 ground=false
 hflip=false
 pimg=0
 sx=38
 sy=40
 dead=-1
 deaths=0
 canmove=false
 power={}
 power_x={}
 power_y={}
 power_txt={"springboards activated",
 											"double jump - 🅾️",
 											"dive - ⬇️",
 											"doors unlocked"}
 power_max=3
 power_id=0
 bul_max=0
 bul_x={}
 bul_y={}
 bul_sx={}
 bul_sy={}
 bul_hs={}
 bul_vs={}
 bul_shs={}
 bul_svs={}
 key_jump=false
 double=true
 coyote=0
 coyotemax=4
 txt=""
 lava=58
 medal=0
 medal_max=0
 boss=false
 boss_x=100
 boss_y=40
 boss_dir=1
 boss_vspd=0
 boss_life=4
 boss_dead=false
 boss_img=-2
 boss_init=false
 boss_timer=-1
 boss_shot=0
 mus_x={3,1,6,6}
 mus_y={1,3,0,1}
 mus_played={false,false,false,false}
 e_x={}
 e_y={}
 e_img={}
 e_max=0
 menu=1
 map_init()
end
-->8
-- update

function _update()

if canmove then
 -- player movement
 
	-- walk left
	if btn(0) and not spr_flag(px-spd,py,0.4,0.4,0)
  then px-=spd hflip=true
	end
	
	-- walk right
	if btn(1) and not spr_flag(px+spd,py,0.4,0.4,0)
	 then px+=spd hflip=false
	end
	
	-- jump
	cond=(ground or coyote>0)
	
	if (btn(4) or btn(5))
 and not key_jump
 and (cond or (double and power[1]))
 and not spr_flag(px,py-1,0.4,0.4,0)
	 then vspd=jspd
	 					if cond then
	       ground=false
	       sfx(0)
	      else
	       double=false
	       sfx(3)
	      end
	      key_jump=true
	end
	
	-- coyote time
	if not ground then
	 coyote=max(coyote-1, 0)
	end
	
	-- don't leave the map
	if px<0.5 or py<0.5 or px>127.5 or py>63.5
	then
	 px=min(max(0.5,px),127.5)
	 py=min(max(0.5,py),63.5)
	end
	
	if key_jump
 and not (btn(4) or btn(5)) then
	 key_jump=false
	end
	
	-- dive
	if power[2] and not ground
 and btn(3)	and vspd>=0
	then
	 vspd=0.5
	 
	 -- stuck in wall bugfix
	 while flag(px-0.4,py,0) do
	 	px+=spd
	 end
	 
	 while flag(px+0.4,py,0) do
	  px-=spd
	 end
	end
	
	-- vertical speed
	py+=vspd

 -- spikes ?
 if spr_flag(px,py,0.4,0.4,1) then
  die()
 end
 
 -- power-up ?
 if flag(px,py,3) then
  power_get()
 end
 
 -- spring ?
 if spr_flag(px,py+1,0.4,0.4,5)
 and power[0] and ground then
  sfx(5)
  vspd=1.5*jspd
  ground=false
 end
 
 -- medal ?
 if spr_flag(px,py,0.4,0.4,7) then
  for dx=-1,1 do
   for dy=-1,1 do
    x2=px+dx
    y2=py+dy
    -- remove medal from map
    if mget(x2,y2)==41 then
			  mset(x2,y2,0)
			  medal+=1
			  sfx(7)
			  text("medal found ("..medal.."/"..medal_max..")",90)
			 end
			end
		end
 end
 
 if mget(px,py)==39 then
  checkpoint()
 end
 
	-- gravity
	vspd=min(0.5,vspd+grav)
	
	-- fall
	if ground and not spr_flag(px,py+1,0.4,0.4,0)
 then
  ground=false
  coyote=coyotemax
	end
	
	-- vertical collision
	if spr_flag(px,py+vspd,0.4,0.5,0)
	 then
	 if power[2] and vspd==0.5
	 and btn(3) and spr_flag(px,py+vspd,0.4,0.5,6)
	 then -- destroy blocks
	  for i=-1,1 do
	   if flag(px+i,py+vspd+0.4,6) 
	   then
 	   mset(px+i,py+vspd+0.4,0)
 	   explode(flr(px+i)+0.5,flr(py+vspd+0.4)+0.5)
 	  end
	  end
	  sfx(8)
	 else
 	 if vspd<0 then
 	  vspd=0 player_move_solid(-1)
 	 else
 	  vspd=0 player_move_solid(1)
 	  ground=true
 	  double=true
 	 end
 	end
	end
	
	-- init boss
	if included(px,96,110.5) and included(py,32,48)
	and not boss
	then
	 local i
	 boss=true
	 for i=0,3 do
	  mset(99+3*i,35,4)
	  mset(111,38+i,1)
	  explode(111.5,38.5+i)
	 end
	 
	 alarm[3]=120
	 boss_img=-1
	 
	end 

end -- canmove

	-- player animation
	if vspd>0 then pimg=2
	elseif vspd==0 then pimg=0
	elseif vspd<0 then pimg=1
	end
	
	-- title screen
	if screen==0
	then
	 if btnp(2) then
	  menu=(menu-1)%3
	  sfx(7)
	 elseif btnp(3) then
	  menu=(menu+1)%3
	  sfx(7)
	 end
	
	 if btnp(4) or btnp(5) then
 	 local i
 	 for i=0,3 do
 	  mset(35+3*i,35,4)
 	 end
 	 sfx(2)
 	 screen=1
 	 alarm[3]=180
 	 if menu==0 then
 	  --easy mode
 	  mset(17,11,17)
 	  mset(33,21,17)
 	  mset(9,21,17)
 	  mset(10,21,23)
 	  mset(107,6,0)
 	  mset(107,8,0)
 	  mset(127,7,0)
 	  mset(124,3,0)
 	  mset(117,3,0)
 	  mset(58,61,5)
 	  mset(55,58,5)
 	  mset(58,55,5)
 	  mset(84,59,0)
 	  mset(92,56,0)
 	  mset(101,28,0)
 	  mset(113,21,0)
 	  mset(89,4,33)
 	  mset(98,51,39)
 	 end
 	 if menu==2 then
 	  --hard mode
 	  mset(54,46,23)
 	  mset(58,35,25)
 	  mset(34,25,23)
 	  mset(35,7,23)
 	  mset(23,23,23)
 	  mset(12,23,23)
 	  mset(8,19,23)
 	  mset(13,11,23)
 	  mset(22,11,23)
 	  mset(5,41,24)
 	  mset(6,41,24)
 	  mset(36,55,23)
 	  mset(37,55,23)
 	  mset(55,57,23)
 	  mset(71,56,23)
 	  mset(67,60,23)
 	  mset(88,55,24)
 	  mset(102,55,23)
 	  mset(109,11,26)
 	  mset(114,26,25)
 	  mset(124,21,25)
 	 end
 	end
	end
 
 if dead>-1 then
  pimg=3+6*(dead%2) -- flashing
  dead-=1 -- timer
  if dead==-1 then
   if not boss_dead then
    px=sx
    py=sy
   end
			vspd=0
			hflip=0
			canmove=true
			if sx!=38 and sy!=40 then
			 player_move_solid(1)
			 ground=true
			else
			 ground=false
			end
			-- reset boss
			if boss and not boss_dead then
			 local i
			 for i=0,3 do
			  mset(111,38+i,0)
			  mset(99+3*i,35,3)
			 end
			 boss=false
			 boss_x=100
			 boss_y=40
			 boss_life=4
			 boss_dir=1
			 boss_vspd=0
			 boss_img=-2
			 boss_init=false
			 boss_shot=0
			 alarm[3]=-1
			end
			
		end
	end
	
	-- bullets
	if bul_max>0 then
	 for i=0,bul_max-1 do
	  if not (bul_x[i]==0 and bul_y[i]==0)
	  then
	   bul_x[i]+=bul_hs[i]*0.5
	   bul_y[i]+=bul_vs[i]*0.5
	  end
	  -- collision with a wall
	  if spr_flag(bul_x[i],bul_y[i],0.4,0.4,0)
	  then
	   explode(bul_x[i]-0.5*bul_hs[i],bul_y[i]-0.5*bul_vs[i])
	   bul_hs[i]=0
	   bul_vs[i]=0
	   bul_x[i]=0
	   bul_y[i]=0
	  end
	  
	  -- collision with player
	  if included(bul_x[i],px-0.8,px+0.8) 
	  and included(bul_y[i],py-0.8,py+0.8)
	  and dead==-1 then
	   explode(bul_x[i]-0.5*bul_hs[i],bul_y[i]-0.5*bul_vs[i])
	   bul_hs[i]=0
	   bul_vs[i]=0
	   bul_x[i]=0
	   bul_y[i]=0
	   die()
	  end
	  
	 end
 	-- shoot bullets
 	if alarm[2]==0 then
 	 local i
 	 for i=0,bul_max-1 do
 	  bul_x[i]=bul_sx[i]+0.5+bul_shs[i]
 	  bul_y[i]=bul_sy[i]+0.5+bul_svs[i]
 	  bul_hs[i]=bul_shs[i]
 	  bul_vs[i]=bul_svs[i]
 	 end
 	 
   alarm[2]=30
   sfx(6)
  end
 end
 
 -- update room	
	if not included(px,room_x*16,room_x*16+16)
	or not included(py,room_y*16,room_y*16+16)
	then
	 room_update()
	end

 
 local i
 
 for i=0,3 do
  alarm[i]=max(-1,alarm[i]-1)
 end
 
 frame=(frame+1)%300
 
 -- lava
 lava=58+4*sin(frame/150)
 if py>=lava and dead==-1 then
  die()
 end
 
 -- intro cutscene
 if intro and alarm[3]==0 then
  intro=false
  canmove=true
 end
 
 if boss_img==-1 and alarm[3]==0 then
  boss_img=0
 end
 
 -- boss ai
 if boss_img>=0 and not boss_dead
 then
  
  if boss_x>110 or boss_x<98
  and boss_y<46 then
   boss_dir=-boss_dir
   boss_x=min(max(98,boss_x),110)
  end
  
  if boss_y<46 then
   boss_vspd=min(0.5,boss_vspd+grav)
   boss_x+=spd*0.5*boss_dir
   if boss_vspd<0 then
    boss_img=1
   else
    boss_img=2
   end
  else
   boss_img=0
   boss_y=46
   if boss_vspd>0 then -- shoot
    local i
    if boss_shot or menu==2 then
     for i=0,2 do
      bul_max+=1
      bul_x[bul_max-1]=boss_x+cos(i/4)
      bul_y[bul_max-1]=boss_y+sin(i/4)
      bul_hs[bul_max-1]=cos(i/4)
      bul_vs[bul_max-1]=sin(i/4)
     end
    end
    
    if not boss_shot or menu==2 then
     for i=0,1 do
      bul_max+=1
      bul_x[bul_max-1]=boss_x+2*i-1
      bul_y[bul_max-1]=boss_y-1
      bul_hs[bul_max-1]=(2*i-1)*sqrt(2)*0.5
      bul_vs[bul_max-1]=-1
     end
    end
    
    boss_shot=not boss_shot
    sfx(6)
    alarm[3]=12+4*boss_life
    boss_vspd=0
    boss_init=true
   end
  end
  
  -- jump
  if alarm[3]==0 and boss_init
  then
   boss_vspd=-0.3-0.125*boss_life
  end
  
  -- player collision
  if included(px,boss_x-1,boss_x+1)
  and included(py,boss_y-1,boss_y+1)  
  and boss_timer==-1
  then
   if vspd==0.5 and btn(3)
   and py<boss_y then
    sfx(1)
    boss_life-=1
    boss_timer=60
    vspd=jspd/2
    mset(99+3*boss_life,35,3)
    if boss_life==0 then
     boss_dead=true
     boss_img=3
     alarm[3]=180
    end
    
   elseif dead==-1 then
    die()
   end
  end 
   
  
  boss_y+=boss_vspd
  boss_timer=max(-1,boss_timer-1)
  
 end
 
 -- ending
 if boss_dead then
  if included(alarm[3],120,180) 
  and frame%5==0 then
   explode(rnd(2)+boss_x-1,rnd(2)+boss_y-1)
   sfx(8)
  end
  
  if alarm[3]==120 then
   canmove=false
   sfx(9)
  end
  
  if alarm[3]==0 then
   music(5)
  end
 end
 
 -- explosions
 if e_max>0 then
  local i,j
  for i=1,e_max do
   e_img[i]+=0.5
   if e_img[i]==4 then
    for j=i+1,e_max do
     e_x[j-1]=e_x[j]
     e_y[j-1]=e_y[j]
     e_img[j-1]=e_img[j]
    end
    e_max-=1
   end
  end
 end
 
 -- cheat
 if cheat then
  local i
  for i=0,3 do
   power[i]=true
  end
  cheat=false
 end
  
end
-->8
-- draw

function _draw()

 local i,j
 
 -- map
 cls()
 camera(room_x*128,room_y*128)
  
  -- moon
  if room_y==0 and room_x<4 then
   spr(44,room_x*128+8,8,2,2)
   palt(0,false)
   palt(15,true)
   spr(46,room_x*128-8+(frame/5),18,2,1)
   pal()
  end
  
  map(0,0,0,0,128,63)
  
  -- title screen
  if screen==0
  or (intro and alarm[3]>150 and odd(frame)==1)
  then
   local x1,y1,i
   x1=room_x*128
   y1=room_x*128
   spr(72,x1+44,y1+16,5,1)
   spr(121,x1+53,y1+47,3,1)
   for i=0,3 do
    local s
    s=sin(frame/15+i*0.25)*2
    spr(88+2*i,x1+37+14*i,y1+28+s,2,2)
   end
   
   print_centered("easy",x1+64,y1+85,7-2*min(menu,1))
   print_centered("normal",x1+64,y1+91,5+2*(menu%2))
   print_centered("hard",x1+64,y1+97,5+2*max(menu-1))
   if frame%150<75 then
    print_centered("flytrap studios",x1+64,y1+124,6)
   else
    print_centered("matthieu le gallic",x1+64,y1+124,6)
   end
   print("1.2",x1+112,y1+122,5)
  end
  
  -- power-up
  for i=0,power_max do
   if not power[i]
   and included(power_x[i],room_x*16,room_x*16+16)
   and included(power_y[i],room_y*16,room_y*16+16)
   then
    local x0,y0
    x0=power_x[i]*8
    y0=power_y[i]*8
     
    circ(x0+4,y0+4,8+2*sin(frame/15),7)
    
   else
    if power_id==i and alarm[1]>-1
     then
     local x0,y0
     x0=power_x[i]*8
     y0=power_y[i]*8
     
     circ(x0+4,y0+4,8+(30-alarm[1])*4,7)
     
     if frame%2==0 then
      spr(55+power_id,power_x[power_id]*8,power_y[power_id]*8)
     end
     
    end
   end
  end
  
  -- boss intro
  if boss_img==-1 then
   if alarm[3]<=30 then
    spr(64,(boss_x-1)*8,(boss_y-1)*8,2,2)
   end
   
   if alarm[3]<=60 then
    local size
    size=8-abs(alarm[3]-30)/3.75
    rectfill(boss_x*8-size,boss_y*8-size,boss_x*8+size,boss_y*8+size,8)
   end
  end
  
  -- boss
  if boss_img>=0 then
   local bflip
   if boss_dir==-1 then
    bflip=true
   else
    bflip=false
   end
   
   if not ((boss_dead or boss_timer>=0)
   and frame%2==0) then
    spr(64+2*boss_img,(boss_x-1)*8,(boss_y-1)*8,2,2,bflip)
   end
   
  end
  
  -- explosions
  if e_max>0 then
   local i
   for i=1,e_max do
    spr(11+flr(e_img[i]),e_x[i]*8-4,e_y[i]*8-4)
   end
  end 
  
  if not intro or canmove then
   -- player
   spr(7+pimg,px*8-4,py*8-4,1,1,hflip)
   -- dive
   if power[2] and vspd==0.5
   and btn(3)  and frame%2==0
   then
    spr(7+pimg,px*8-4,py*8-12,1,1,hflip)
   end
  end
  
  -- intro
  if intro and not canmove
  and screen==1 then
  
   if alarm[3]<=30 then
    spr(7,px*8-4,py*8-4)
   end
   
   if alarm[3]<=60 then
   
    if alarm[3]==60 then
     music(0)
    end
    
	   local size
	   size=4-abs(alarm[3]-30)/7.5
    rectfill(px*8-size,py*8-size,px*8+size,py*8+size,12)
   end
  end
  -- bullets
  if bul_max>0 then
   for i=0,bul_max-1 do
    if not (bul_x[i]==0 and bul_y[i]==0)
    then
     spr(15,bul_x[i]*8-4,bul_y[i]*8-4)
    end
   end
  end
  
  -- lava
  if room_y==3 then
   rectfill(room_x*128,lava*8+8,(room_x+1)*128,511,8)
   for i=-1,15 do
    spr(52,room_x*128+i*8+(frame/(37.5/16))%8,lava*8)
   end
  end
  
  -- particle effect
  if (room_y==0 and room_x>=4)
  or (room_y==3) then
   local x0,y0,x1,y1,k,col
   col=42+room_y/3
   x0=room_x*128
   y0=room_y*128
    for i=0,3 do
     for j=-2,7 do
      x1=x0+8+32*i+16*odd(j)+2*sin(frame/15)*((2*odd(i+j))-1)
      if room_y==0 then
       y1=y0-32+j*32+(frame%60)*(32/30)+16*odd(i+j)
      else
       y1=y0+32+j*32-(frame%60)*(32/30)+16*odd(i+j)
      end
      spr(col,x1,y1)
     end
    end
  end
  
  -- text
  if alarm[0]>-1 then
   for i=-1,1 do
    for j=-1,1 do
     print(txt,i+room_x*128+64-#txt*2,j+(room_y+1)*128-min(6,alarm[0]/4),0)
    end
   end
   
   print(txt,room_x*128+64-#txt*2,(room_y+1)*128-min(6,alarm[0]/4),7)
  end
  
  -- ending
  if boss_dead then
   if included(alarm[3],60,120) then
    local x0,y0,x1,y1,s
    x1=768
    y1=256
    x0=boss_x*8
    y0=boss_y*8
    s=(cos((alarm[3]-60)/120)+1)*128
    rectfill(x0-s,y1,x0+s,y1+128,7)
    rectfill(x1,y0-s,x1+128,y0+s,7)
   end
   
   if alarm[3]<60 then
    rectfill(768,256,896,384,7)
   end
   
   if alarm[3]==-1 then
    local x1,y1,s,i,str
    x1=room_x*128
    y1=room_y*128
    
    palt(0,false)
    for i=0,8 do
     s=sin(frame/15+i*0.25)*2
     spr(112+i,x1+28+8*i,y1+12+s)
    end
    palt(0,true)
    
    if menu==0 then
     str="easy"
    elseif menu==1 then
     str="normal"
    elseif menu==2 then
     str="hard"
    end
    
    print_centered("difficulty",x1+64,y1+40)
    print_centered(str,x1+64,y1+48)
    print_centered("deaths",x1+64,y1+72)
    print_centered(tostr(deaths),x1+64,y1+80)
    print_centered("medals",x1+64,y1+104)
    for i=-2,2 do
     if medal>=i+3 then
      spr(63,x1+64+8*i-4,y1+108)
     else
      palt(0,false)
      spr(62,x1+64+8*i-4,y1+108)
      palt(0,true)
     end
    end
   end
  end 
  
end	
