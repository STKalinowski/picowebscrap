-- winterwood
-- by jusiv

--[[
this was made in parts of 
october and december 2020 for 
the 2020 pico-8 advent calendar

the polytex function used is by
freds72 (@fsouchu on twitter)

all other code and assets were created
by henry "jusiv" stadolnik

to follow my work, check out my
twitter: @jusiv_

(c) 2020 j. henry stadolnik iv

controls
- move: ⬆️⬇️⬅️➡️
- rotate: 🅾️❎

music tracks
--0.  title/ending
--5.  forest
--11. whiteout
--12. safe
]]

poke(0x5f2c,3)

function _init()
 --title
 show_title,title_trans,show_intro,ending = true,-40,false,false
 music"0"
 
 --camera and player
 cam_x,cam_y,cam_angle,cam_d,cax,cay = 915,410,325,0,0,0
 p_x,p_y,p_dx,p_dy,p_s = 960,356,0,0,4 --p_s is hitbox side length
 p_sp,p_sm,p_f = 1,false,0
 p_d,p_cam_d,p_show_d,p_new_d,p_new_d_wait = 0,1,1,1,0
 p_lock,p_stuck,p_rotwait,p_inside,inside_fade = true,false,0,false,0 --whether player is indoors
 respawn_x,respawn_y,respawn_trans,respawn_warp,respawn_time = 280,256,0,10,35
 fade_trans,fade_time = 0,10 --fade transition
 
 --dog
 play_whistle,whistletime,whistletimemax = false,0,30
 dog_start,dog_done,dog_wait,dog_waitmax = false,false,0,90
 dtarget,dtarget_x,dtarget_y,dbarkwait,dbarktime,dbarktimemax = 0,0,0,0,0,30
 dtargets = {104,13, 94,7, 101,18, 101,2, 106,11, 117,13} --pairs
 
 --actors
 smoke_wait,snow_clock,snow_wait,snow_pal = 5,0,2,0
 triggers,walls,planes,props,tprops,parts,trees,smoke = {},{},{},{},{},{},{},{},{}
 buckets,bucket_count = {},96
 
 --trees
 for y=0,55 do
  for x=0,127 do
   if mget(x,y) == 102 then
    add_tree(x+0.5,y+0.5,8,2.5+rnd(1.5))
    mset(x,y,33)
   elseif mget(x,y) == 238 then
    add_tree(x+0.5,y+0.5,6,1.5+rnd(1))
    mset(x,y,33)
   elseif mget(x,y) == 237 then
    add_tree(x+0.5,y+0.5,4,1+rnd(0.4))
    mset(x,y,33)
   end
  end
 end
 
 --house
 local hx1,hy1,hx2,hy2 = 115,39,120,45
 local hxm,hym = (hx1+hx2)/2,(hy1+hy2)/2
 -- left
 add_wall(hx1,hy1,0, hx1,hy2,2, 
           5,62, 6,2)
 -- front
 add_wall(hx1,hy2,0, hx2,hy2,4, 
           0,60, 5,4)
 add_tree(hx1+1.25,hy2+0.5,3,1,true)
 add_tree(hx2-1.25,hy2+0.5,3,1,true)
 -- right
 add_wall(hx2,hy2,0, hx2,hy1,2, 
           5,62, 6,2)
 -- back
 add_wall(hx2,hy1,0, hx1,hy1,2,
           5,60, 5,2)
 add_wall(hx2,hy1,2, hx1,hy1,4, 
           0,60, 5,2) 
 -- roof
 add_roof(hxm,hy1-0.5, hxm,hym,
           hx1-0.5,hy1-0.5, hx1-0.5,hym,
           2,4, 12,58, 3.5,3)
 add_roof(hxm,hym, hxm,hy2+0.5,
           hx1-0.5,hym, hx1-0.5,hy2+0.5, 
           2,4, 12,58, 3.5,3)
 add_roof(hxm,hy2+0.5, hxm,hym,
           hx2+0.5,hy2+0.5, hx2+0.5,hym,
           2,4, 12,58, 3.5,3)
 add_roof(hxm,hym, hxm,hy1-0.5,
           hx2+0.5,hym, hx2+0.5,hy1-0.5,
           2,4, 12,58, 3.5,3) 
 -- decor
 --  bed 
 add_dplane(119,39, 120,39,
            119,40.5, 120,40.5,
            0.375, 14,56.5, 1,1.5)
 add_dwall(119,40.5,0, 119,39,0.375,
            16,60, 1.5,0.375)
 add_dwall(119,39,0, 120,39,0.375,
            14,56, 1,0.375)
 add_dwall(120,39,0, 120,40.5,0.375,
            16,60, 1.5,0.375)
 add_dwall(120,40.5,0, 119,40.5,0.375,
            14,56, 1,0.375)
 --  chair
 add_dplane(115.5,40, 117,40,
            115.5,40.75, 117,40.75,
            0.25, 15,57.25, 1,0.75)
 add_dwall(117,40.125,0, 117,40.75,0.25,
            15,57.375, 0.375,0.25)
 add_dwall(115.5,40.75,0, 115.5,40.125,0.25,
            15,57.375, 0.375,0.25)
 add_dwall(117,40.75,0, 115.5,40.75,0.25,
            15,57.75, 1,0.25) 
 add_dwall(115.5,40.125,0.25, 117,40.125,0.75,
            15,57.25, 1,0.375)
 add_dwall(117,40.125,0.25, 115.5,40.125,0.75,
            15,57.25, 1,0.375)
 --  table
 add_dplane(115,43, 116,43,
            115,44, 116,44,
            0.5, 18,60, 1,1)
 add_dplane(116,43.15, 116.6,43.15,
            116,43.85, 116.6,43.85,
            0.25, 18,60, 1,1)
 --  sink
 add_dplane(120,43, 120,44,
            119.5,43, 119.5,44,
            0.5, 16,60.5, 1,0.5)
 add_dplane(120,44, 120,44.5,
            119.5,44, 119.5,44.5,
            0.5, 10.5,60, 0.5,0.5)
 add_dwall(120,43,0, 120,44.5,0.5,
            16,60, 1.5,0.5)
 add_dwall(119.5,43,0, 120,43,0.5,
            17.5,60, 0.5,0.5)
 add_dwall(119.5,44.5,0, 119.5,43,0.5,
            16,60, 1.5,0.5)
 add_dwall(120,44.5,0, 119.5,44.5,0.5,
            17.5,60, 0.5,0.5)
 --  bookshelf
 add_dplane(117,39, 118,39,
            117,39.5, 118,39.5,
            1, 17,60.5, 1,0.5)
 add_dwall(118,39.5,0, 117,39.5,1,
            20,60, -1,1)
 add_dwall(118,39,0, 118,39.5,1,
            10.5,61, 0.5,1)
 add_dwall(117,39,0, 118,39,1,
            19,60, 1,1)
 add_dwall(117,39.5,0, 117,39,1,
            10.5,61, 0.5,1)
 --  coat rack
 add_tprop(116,44.5, 115,44.5, 0,1,
           15,56, 1,1, 2,true)
 --  photos
 add_dwall(115,39.625,0.875, 115,40,1.375,
           12.625,56, 0.375,0.5)
 add_dwall(118.75,45,1.125, 119.25,45,1.625,
           10.5,60.5, 0.5,0.5)
 add_dwall(120,42.125,1, 120,41.5,1.5,
           12,56, 0.625,0.5)
 --  fireplace base
 add_dplane(115,42.5, 115,41.5,
            115.25,42.5, 115.25,41.5,
            1, 12,58, 1,0.25)
 add_dwall(115.25,41.5,0, 115.25,42.5,1,
            13,56, 1,1)
 add_dwall(115,41.5,0, 115.25,41.5,1,
            10,61, 0.25,1)
 add_dwall(115,42.5,0, 115,41.5,1,
            13,57, 1,1)
 add_dwall(115.25,42.5,0, 115,42.5,1,
            10,61, 0.25,1)
 --  fireplace shaft
 add_dwall(115.25,41.75,1, 115.25,42.25,2,
            10,60, 0.5,1)
 add_dwall(115,41.75,1, 115.25,41.75,2,
            10.25,61, 0.25,1)
 add_dwall(115,42.25,1, 115,41.75,2,
            10,60, 0.5,1)
 add_dwall(115.25,42.25,1, 115,42.25,2,
            10.25,61, 0.25,1)
 --  chimney
 --   left
 add_rooftop(117.25,41.75, 117.25,42.25,
             117.25,41.75, 117.25,42.25,
             4,5, 10,60, 0.5,1, 48)
 --   front
 add_rooftop(117.25,42.25, 117.75,42.25,
             117.25,42.25, 117.75,42.25,
             4,5, 10,60, 0.5,1, 48)
 --   right
 add_rooftop(117.75,41.75, 117.75,42.25,
             117.75,41.75, 117.75,42.25,
             4,5, 10,60, 0.5,1, 48)
 --   back
 add_rooftop(117.25,41.75, 117.75,41.75,
             117.25,41.75, 117.75,41.75,
             4,5, 10,60, 0.5,1, 48)
 --   top
 add_rooftop(117.25,41.75, 117.75,41.75,
             117.25,42.25, 117.75,42.25,
             5,5, 10.5,60, 0.5,0.5, 64)
 -- signs
 add_tprop(9.5,12, 9.5,13, 0,1.5,
           12,56.5, 1,1.375, 4)
 add_tprop(10.5,7.5, 11.5,7.5, 0,1,
           11,60, 1,1, 2)
 add_tprop(16,23, 16,24, 0,1,
           11,60, 1,1, 2)
 add_tprop(23,43, 23,42, 0,1,
           11,60, 1,1, 2)
 add_tprop(45,35, 46,35, 0,1,
           11,60, 1,1, 2)
 add_tprop(71,45.5, 72,45.5, 0,1,
           11,60, 1,1, 2)
 -- trees
 add_tree(110,12.5,4,1.2)
 add_tree(112,11,6,2)
 -- triggers
 add_message(35.5,31.5, 3,3,{12,13,14,15},0)
 add_message(98,22,     3,2,{16,17,18,19,20,21},1)
 add_message(117.5,41.5,  1.5,1.5,{24,25,26,27,28,29,30,31,32,33,34,35},2)
 -- npcs
 add_dog({118,18, 121,23, 119,29, 118,36, 113,39, 113.5,46.5, 117.25,46, 118,42})
 add_jones(117.5,41.5)
 
 --sprites
 spr_broken_ice = {}
 spr_broken_ice[0b0000]=36 --0 neighbors
 spr_broken_ice[0b0100]=21 --1 neighbor
 spr_broken_ice[0b1000]=22
 spr_broken_ice[0b0001]=37
 spr_broken_ice[0b0010]=38
 spr_broken_ice[0b1100]=23 --2 neighbors
 spr_broken_ice[0b0011]=39
 spr_broken_ice[0b0101]=24
 spr_broken_ice[0b0110]=25
 spr_broken_ice[0b1001]=40
 spr_broken_ice[0b1010]=41
 spr_broken_ice[0b1011]=53 --3 neighbors
 spr_broken_ice[0b0111]=54
 spr_broken_ice[0b1110]=55
 spr_broken_ice[0b1101]=56
 spr_broken_ice[0b1111]=57 --4 neighbors

 --text
 lmax,text_change,text_wait,text_delay,text_mute = 14,true,15,0,2
 text_queue,text_lines,text_y,img_y,img_show = {1},{},64,-16,false
 dialogue = {
  --title (1)
  "00press 🅾️ or ❎",
  --intro (2-7)
  "01mr. jones and his dog always rest at the bench by my house.",
  "02whenever she'd wander off, he'd call her back with his trusty whistle.",
  "03but one winter day, i noticed he left his whistle behind.",
  "04a snowstorm was coming, and i couldn't bear the thought",
  "05of him stuck searching for it out in the freezing cold.",
  "06so i decided to bring it to him myself.",
  --area 1: forest (8-11)
  "00mr. jones lives in a cabin by the lake in these woods.",
  "00the trail seems to be marked so i'll be fine.",
  "00...unless the snow's covered parts of it.",
  "00⬆️⬇️⬅️➡️: move/🅾️❎: rotate",
  --area 2: lake (12-15)
  "00alright, i made it to the lake!",
  "07the hill mr. jones lives on is on the other side.",
  "00it looks like i'll have to walk across though...",
  "00but at least it looks mostly frozen?",
  --freezing (16-21)
  "00oh man oh man what am i gonna do now?",
  "00i can't see anything in this storm...",
  "00but i'll freeze to death if i stay out here!",
  "00...",
  "03wait, the dog whistle!",
  "08i should be close, perhaps his dog can hear it from here!",
  -- (wait here w/ sfx)
  --dog (22-23)
  "20*bark!*",
  "00that sounded like her! maybe i can follow her to safety!",
  --ending (24-35)
  "11millie, there you are girl!",
  "10don't scare an old man like that, running off into the storm!",
  "15oh! i'm sorry, i nearly missed you there!",
  "10what brings you all the way out here in this weather?",
  "03i was worried you'd be out there looking for this, mr. jones.",
  "02you dropped it at the bench you stop at by my house.",
  "10oh!!! and here i thought i'd lost it for good under all this snow!",
  "10thank you kindly for trekking out here to bring it back!",
  "10but oh,/you must be freezing now...",
  "10why don't you stay a bit and i'll fix you some hot cocoa as thanks!",
  "09 t h e ~ e n d",
  }
end
-->8
--actors

-- ★ handling special tiles
function break_ice(mx,my)
 --set to 1x1 hole
 mset(mx,my,36) --set to 1x1 pit
 --update neighbors
 if flag(mx,my-1,7) then
  update_broken_ice(mx,my-1)
 end
 if flag(mx,my+1,7) then
  update_broken_ice(mx,my+1)
 end
 if flag(mx-1,my,7) then
  update_broken_ice(mx-1,my)
 end
 if flag(mx+1,my,7) then
  update_broken_ice(mx+1,my)
 end
 update_broken_ice(mx,my)
end

function update_broken_ice(mx,my)
 --bit order: ⬆️⬇️⬅️➡️
 local bits = 0b0000
 if flag(mx,my-1,7) then
  bits = bor(bits,0b1000)
 end
 if flag(mx,my+1,7) then
  bits = bor(bits,0b0100)
 end
 if flag(mx-1,my,7) then
  bits = bor(bits,0b0010)
 end
 if flag(mx+1,my,7) then
  bits = bor(bits,0b0001)
 end
 mset(mx,my,spr_broken_ice[bits])
 rsfx(18)
end

function crack1_ice(mx,my)
 mset(mx,my,18+16*flr(rnd(3)))
 rsfx(11)
end

function crack2_ice(mx,my)
 mset(mx,my,mget(mx,my)+1)
 rsfx(11)
end

-- ★ creating actors
function add_message(mx,my,mw,mh,msg_set,scene)
 local p = {
  x=mx*8,
  y=my*8,
  w=mw*4,
  h=mh*4,
  msg=msg_set,
  scene=scene,
  effect=show_message
 }
 add(triggers,p)
end


function make_prop(x,y,w,h,sp)
 --makes a sprite prop
 local p={
 	sp=sp,
 	sm=false,
 	x=x*8,
 	y=y*8,
 	w=w,
 	h=h,
 	rx=0,
 	ry=0,
 	shad=draw_shadow,
 	draw=draw_sprite,
 }
 return p
end

function add_prop(x,y,w,h,sp)
 --makes and adds a sprite prop
 add(props,make_prop(x,y,w,h,sp))
end

function add_dog(mcoords)
 --makes the dog
 local p=make_prop(mcoords[1],mcoords[2],1,1,68)
 p.draw,p.upd = draw_npc,upd_dog
 p.pathcoords = mcoords --pairs
 p.pathindex,p.f,p.d,p.cam_d,p.door = 1,0,1,1,false
 add(parts,p)
end

function add_jones(x,y)
 --makes mr. jones
 local p=make_prop(x,y,1,1,84)
 p.draw,p.upd,p.f,p.d,p.cam_d = draw_npc,upd_jones,0,1,1
 add(parts,p)
end

function add_tree(x,y,r,h,outonly)
 --makes a sprite prop
 --outonly is optional
 local p={
 	x=x*8,
 	y=y*8,
 	r=r,
 	a=rnd(0.25)-0.125,
 	z=h*8,
 	rx=0,
 	ry=0,
  leaftex={},
  leafverts={},
 	shad=draw_circshadow,
 	draw=draw_tree,
 	outonly=outonly or false
 }
 for i=0,3 do
  add(p.leaftex,11+flr(rnd(9)))
 end
 add(trees,p)
end

function add_tprop(x1,y1,x2,y2,z1,z2,tx,ty,tw,th,radius,inside)
 --makes a 3d plane prop
 local p={
 	x1=x1*8,
 	y1=y1*8,
 	x2=x2*8,
 	y2=y2*8,
 	z1=z1*8,
 	z2=z2*8,
 	tx=tx,
 	ty=ty,
 	tw=tw,
 	th=th,
		rxfar=0,
		ryfar=0,
		rxnear=0,
		rynear=0,
 	r=radius,
 	inside=inside or false,
 	flipped=false,--whether draw direction reversed
 	shad=draw_circshadow2,
 	draw=draw_tprop,
 }
 add(tprops,p)
end


function make_wall(x1,y1,z1,x2,y2,z2,tx,ty,tw,th)
 --makes a vertical plane quad
 local p={
  x1=x1*8,--start 3d coord
  y1=y1*8,
  z1=z1*8,
  x2=x2*8,--end 3d coord
  y2=y2*8,
  z2=z2*8,
  tx=tx,--start texture coord
  ty=ty,
  tw=tw,--texture dimensions
  th=th,
  normal=-atan2(x2-x1,y2-y1),--precompute normal
  verts={},
  flipped=false,--whether draw direction reversed
  shad=draw_none,
  draw=draw_wall,
 }
 return p
end

function add_wall(x1,y1,z1,x2,y2,z2,tx,ty,tw,th)
 add(walls,make_wall(x1,y1,z1,x2,y2,z2,tx,ty,tw,th))
end

function add_dwall(x1,y1,z1,x2,y2,z2,tx,ty,tw,th)
 -- make a decorative indoor wall
 local p = make_wall(x1,y1,z1,x2,y2,z2,tx,ty,tw,th)
 p.iswall,p.draw = true,draw_deco
 add(walls,p)
end

function make_plane(x1,y1,x2,y2,
                   x3,y3,x4,y4,
                   z1,z2,tx,ty,tw,th,
                   roof,sortshift)
 -- plane with optional slope 
 --   1+-----+2 <-z2
 --   /     /:      
 -- 3+-----+4'  <-z1
 local p={
  x1=x1*8,--upper coord 1
  y1=y1*8,
  x2=x2*8,--upper coord 2
  y2=y2*8,
  x3=x3*8,--lower coord 1
  y3=y3*8,
  x4=x4*8,--lower coord 2
  y4=y4*8,
  z1=z1*8,--z range
  z2=z2*8,
  tx=tx,--start texture coord
  ty=ty,
  tw=tw,--texture dimensions
  th=th,
  isroof=roof,
  sortshift=sortshift or 0,
  verts={},
  shad=draw_none,
  draw=draw_roof,
 }
 return p
end

function add_roof(x1,y1,x2,y2,
                   x3,y3,x4,y4,
                   z1,z2,tx,ty,tw,th)
 add(planes,make_plane(x1,y1,x2,y2,
                   x3,y3,x4,y4,
                   z1,z2,tx,ty,tw,th,
                   true,8))
end

function add_rooftop(x1,y1,x2,y2,
                   x3,y3,x4,y4,
                   z1,z2,tx,ty,tw,th,shift)
 add(planes,make_plane(x1,y1,x2,y2,
                   x3,y3,x4,y4,
                   z1,z2,tx,ty,tw,th,
                   true,shift))
end

function add_dplane(x1,y1,x2,y2,
                   x3,y3,x4,y4,
                   z,tx,ty,tw,th)
 -- make a decorative indoor plane
 local p = make_plane(x1,y1,x2,y2,
                   x3,y3,x4,y4,
                   z,z,tx,ty,tw,th,
                   false)
 p.iswall,p.draw = false,draw_deco
 add(planes,p)
end

function add_player()
 local respawn = respawn_trans > 0
 local p = {
  sp=p_sp+p_f,
  sm=p_sm,
  w=1,
  h=1,
  rx=32,
  ry=respawn and 34 or 32,
  -- skip draw if respawning (ternary)
  shad=(respawn or show_title) and 
       draw_none or draw_shadow,
  -- skip draw if underwater (ternary)
  draw=(show_title or (respawn and (p_f >= 4 or respawn_trans <= respawn_warp))) and 
       draw_none or draw_sprite
  }
 add(buckets[32],p)
end

function add_footprint(d)
 --calculate position
 local offset,aa = 1.5,cam_angle/360
 if p_f == 2 then
  offset *= -1
 end
 if p_cam_d%2 == 0 then
  offset /= 2
 end
 local pos_x = cam_x+offset*cos(aa)-0.5*sin(aa)
 local pos_y = cam_y+offset*sin(aa)-0.5*cos(aa)
  
 --only create if on snow
 if pixel_color(pos_x,pos_y) == 7 then
  local p={
   x=pos_x,
   y=pos_y,
   d=d,
   l=1.5,
   c=6,
   t=40,
   rx=0,
   ry=0,
   shad=draw_ray,
   draw=draw_none,
   upd=upd_footprint
  }
  add(parts,p)
  rsfx(8)
 else
  rsfx(15)
 end
end

function add_snow()
 local ir,ia,z = 4+rnd(120),rnd(1),64+rnd(20)
 local p={
  x=p_x+ir*cos(ia),
  y=p_y+ir*sin(ia),
  zm=z,
  z=z,
  zs=0.05+rnd(0.7),--fall speed
  ds=rnd(0.2),--drift speed
  da=rnd(1),--drift direction
  r=rnd(2),
  c=6+rnd(1.3),
  rx=0,
  ry=0,
  shad=draw_none,
  draw=draw_snow,
  upd=upd_snow
 }
 add(parts,p)
end


function add_smoke()
 local z1=40+rnd(10)
 local p={
  x=940,
  y=336,
  zm=z1+rnd(20),
  z=z1,
  zs=0.05+rnd(0.2),--rise speed
  ds=rnd(0.2),--drift speed
  da=rnd(1),--drift direction
  r=rnd(2),
  rx=0,
  ry=0,
  shad=draw_none,
  draw=draw_smoke,
 }
 add(smoke,p)
end

-- ★ update actors
function upd_footprint(p)
 p.t -= 1
 if p.t <= 0 then
  del(parts,p)
 end
end

function upd_snow(p)
 p.z -= p.zs
 p.x += p.ds*cos(p.da)
 p.y += p.ds*sin(p.da)
 p.da += rnd(0.03)
 if p.z < 0 then
  del(parts,p)
 end
end

function upd_smoke(p)
 p.z += p.zs
 p.x += p.ds*cos(p.da)
 p.y += p.ds*sin(p.da)
 p.da += rnd(0.05)
 if p.z > p.zm then
  p.r -= 0.2
  p.zs -= rnd(0.02)
  if p.r <= 0 then
   del(smoke,p)
  end
 else
  p.r += rnd(0.1)
  p.zs += rnd(0.01)
 end
end

function upd_dog(p)
 local pindex,pcoords,moving = p.pathindex*2,p.pathcoords,false
 --bark anim
 if dbarktimemax-dbarktime < 5 then
  p.sp,p.f = 67,0
 elseif dbarktime > 10 then
  p.sp,p.f = 68,0
 --walk or sit
 else
  -- if at end of path, look at player
  if pindex > #pcoords then
   local lx,ly=p_x-p.x,p_y-p.y
   local lookd = atan2(lx,-ly)*4
   if lookd >= 3.5 then
    p.d = 0
   else
    p.d = max(0,flr(lookd+0.5))
   end
  -- otherwise, advance along path
  else
   local x,y,nx,ny,spd = p.x,p.y,8*pcoords[pindex-1],8*pcoords[pindex],2
   if x != nx and y != ny then
    local dx,dy = nx-x,ny-y
    local dst,da = 128*dist(dx/128,dy/128),atan2(dx,dy)
    if dst < spd then
     p.x,p.y = nx,ny
    else
     local pdx,pdy=spd*cos(da),spd*sin(da)
     p.x += pdx
     p.y += pdy
     --update angle
     local newd = atan2(pdx,-pdy)*4
     if newd >= 3.5 then
      p.d = 0
     else
      p.d = max(0,flr(newd+0.5))
     end
     moving = true
    end
    --make door sound when passing through
    if not p.door and flag(p.x\8,p.y\8,2) then
     sfx"25"
     p.door = true
    end
   else
    -- wait for player to approach
    local pdx,pdy = p_x-x,p_y-y
    local pdst = 128*dist(pdx/128,pdy/128)
    if pdst < 24 or (dog_done and p.pathindex < 7 and p_x >= 960 and p_y > 312) then
     -- bark and move if approached
     -- or if player goes around far side of house
     p.pathindex += 1
     bark()
     -- block off backtracking
     if p.pathindex == 4 then
      p_stuck = true
     end
    end
   end
  end
  --update sprite
  p.cam_d = (p.d+cam_d)%4
  if p.cam_d == 1 then
   p.sp = 68
  elseif p.cam_d == 3 then
   p.sp = 72
  else
   p.sp = 76
  end
  p.sm = (p.cam_d == 2)
  if moving then
   p.f = (p.f+0.5)%4
  else
   p.f = 0
  end
 end
 p.sp += p.f
end

function upd_jones(p)
 --[[look at player
 local lx,ly=p_x-p.x,p_y-p.y
 local lookd = atan2(lx,-ly)*4
 if lookd >= 3.5 then
  p.d = 0
 else
  p.d = max(0,flr(lookd+0.5))
 end
 --]]
 --change sprite
 p.cam_d = (p.d+cam_d)%4
 if p.cam_d == 1 then
  p.sp = 84
 elseif p.cam_d == 3 then
  p.sp = 86
 else
  p.sp = 88
 end
 p.sm = (p.cam_d == 2)
 --idle animation
 p.f = (p.f+0.125)%2
 p.sp += p.f
end

function show_message(p)
 text_queue,text_change,p_rotwait = p.msg,true,24
 --freeze
 if p.scene == 1 then
  snow_pal,text_delay,p_stuck,dog_start,play_whistle,text_mute = 4,45,true,true,true,1
  music(11,2000)
 elseif p.scene == 2 then
  ending = true
 end
 del(triggers,p)
end

-- ★ sort actors
-- cax=cos(cam_angle),cay=sin(cam_angle)
function map_to_screen(p)
 local xpos,ypos = p.x-cam_x,p.y-cam_y
 p.rx = xpos*cax+ypos*cay+32
 p.ry = ypos*cax-xpos*cay+32
 --queue for rendering
 if mid(p.rx,-16,80) == p.rx and
    mid(p.ry,0,bucket_count) == p.ry then
  add(buckets[flr(p.ry)+1],p)
 end
end

function smoke_to_screen(p)
 local xpos,ypos = p.x-cam_x,p.y-cam_y
 p.rx = xpos*cax+ypos*cay+32
 p.ry = ypos*cax-xpos*cay+32
 --queue for rendering
 add(buckets[bucket_count],p)
end

function tree_to_screen(p)
 local xpos,ypos,z,r = p.x-cam_x,p.y-cam_y,p.z,p.r
 local brx = xpos*cax+ypos*cay+32
 local bry = ypos*cax-xpos*cay+32
 --cancel early if not drawing
 if mid(brx,-r,64+r) != brx or
    bry < -r or bry-z > 64 then
  return
 end
 --calculate tree positions
 p.rx,p.ry = brx,bry
 local order = {2,3,1,0} --sort order of leaves
 for i=0,3 do
  local id,ang = order[1+(cam_d+i)%4],p.a+i/4
  local xp,yp = xpos+r*cos(ang),ypos-r*sin(ang)
  p.leafverts[id+1] = make_v(
    xp*cax+yp*cay+32,
    yp*cax-xp*cay+32,0,
    p.leaftex[i+1],61)
 end
 --queue for rendering
 add(buckets[mid(1,flr(bry),bucket_count)],p)
end

function tprop_to_screen(p)
 --get camera-based coords
 local x1,y1,x2,y2 = p.x1-cam_x,p.y1-cam_y,p.x2-cam_x,p.y2-cam_y
 --calculate screen coords
 local rx1 = (x1*cax+y1*cay+32)
 local ry1 = (y1*cax-x1*cay+32)
 local rx2 = (x2*cax+y2*cay+32)
 local ry2 = (y2*cax-x2*cay+32)
 --determine draw direction
 if ry1 <= ry2 then
  p.rxfar,p.ryfar,p.rxnear,p.rynear,p.flipped = rx1,ry1,rx2,ry2,false
 else
  p.rxfar,p.ryfar,p.rxnear,p.rynear,p.flipped = rx2,ry2,rx1,ry1,true
 end
 --queue for rendering if on-screen
 if max(ry1,ry2)-p.z1+p.r >= 0 and min(ry1,ry2)-p.z2 < 64 then
  add(buckets[mid(1,bucket_count,flr((ry1+ry2)/2))],p)
 end
end

function wall_to_screen(p)
 --get camera-based coords
 local x1,y1,x2,y2,z1,z2,tx,ty,tw,th = p.x1-cam_x,p.y1-cam_y,p.x2-cam_x,p.y2-cam_y,p.z1,p.z2,p.tx,p.ty,p.tw,p.th
 --calculate screen coords
 local rx1 = x1*cax+y1*cay+32
 local ry1 = y1*cax-x1*cay+32
 local rx2 = x2*cax+y2*cay+32
 local ry2 = y2*cax-x2*cay+32
 --determine depth
 local sorty,endy = ry1,ry2
 if ry1 > ry2 then
  -- y2 is far y
  sorty,endy = ry2,ry1
 end
 --render if on-screen
 if endy > 0 and sorty-z2 < 64 then
  --store rendering verts
  p.verts = {make_v(rx1,ry1,z2,tx,ty),--v1
             make_v(rx2,ry2,z2,tx+tw,ty),--v2
             make_v(rx2,ry2,z1,tx+tw,ty+th),--v4
             make_v(rx1,ry1,z1,tx,ty+th)}--v3
  --queue for rendering
  add(buckets[mid(1,bucket_count,flr(sorty))],p)
 end
end

function plane_to_screen(p)
 --get camera-based coords
 local x1,y1,x2,y2,x3,y3,x4,y4,z1,z2,tx,ty,tw,th = p.x1-cam_x,p.y1-cam_y,p.x2-cam_x,p.y2-cam_y,p.x3-cam_x,p.y3-cam_y,p.x4-cam_x,p.y4-cam_y,p.z1,p.z2,p.tx,p.ty,p.tw,p.th
 --calculate screen coords
 local rx1 = x1*cax+y1*cay+32
 local ry1 = y1*cax-x1*cay+32
 local rx2 = x2*cax+y2*cay+32
 local ry2 = y2*cax-x2*cay+32
 local rx3 = x3*cax+y3*cay+32
 local ry3 = y3*cax-x3*cay+32
 local rx4 = x4*cax+y4*cay+32
 local ry4 = y4*cax-x4*cay+32
 --determine depth
 --based on lowest vertex on screen
 local botneary = ry4
 if ry3 > ry4 then
  botneary = ry3
 end
 --store rendering verts
 p.verts = {make_v(rx1,ry1,z2,tx,ty),--v1
            make_v(rx2,ry2,z2,tx+tw,ty),--v2
            make_v(rx4,ry4,z1,tx+tw,ty+th),--v4 
            make_v(rx3,ry3,z1,tx,ty+th)}--v3
 --queue for rendering
 if p.isroof then
  -- sort by near bottom coord
  -- +8 offset ensures player won't overlap roof
  add(buckets[mid(1,bucket_count,flr(botneary+p.sortshift))],p)
 else
  -- sort by far top coord
  add(buckets[mid(1,bucket_count,flr(min(ry1,ry2,ry3,ry4)))],p)
 end
end


-- ★ drawing actors
function draw_none(p)
end

function draw_shadow(p)
 ovalfill(p.rx-4*p.w,p.ry-3,
          p.rx+4*p.w-1,p.ry,
          6)
end

function draw_circshadow(p)
 circfill(p.rx,p.ry,p.r*0.8,6)
end

function draw_circshadow2(p)
 circfill((p.rxfar+p.rxnear)/2,(p.ryfar+p.rynear)/2,p.r,6)
end

function draw_snow(p)
 if not p_inside then
  circ(p.rx,p.ry-p.z,p.r*(p.z/p.zm),p.c)
 end
end

function draw_smoke(p)
 if not p_inside then
  fillp(0b0101101001011010.1)
  circfill(p.rx,p.ry-p.z,p.r,13)
  fillp()
 end
end

function draw_sprite(p)
 spr(p.sp,
     p.rx-8*p.w+4,
     p.ry-8*p.h,
     p.w,p.h,
     p.sm,false)
end

function draw_npc(p)
 --only draw if player in same
 --space (indoors vs outdoors)
 if flag(p.x\8,p.y\8,1) == p_inside then
  draw_sprite(p)
 end
end

function draw_pixel(p)
 pset(p.rx,p.ry,p.c)
end

function draw_ray(p)
 local aa = -(p.d+cam_angle/360)
 line(p.rx,p.ry,
      p.rx+p.l*cos(aa),
      p.ry+p.l*sin(aa),
      p.c)
end

function draw_tprop(p)
 --if indoors only draw indoors
 if p.inside and (show_title or title_trans > 0 or not p_inside) then
  return
 end
 
 local xf,yf,xn,yn,z1,z2,tx = p.rxfar,p.ryfar,p.rxnear,p.rynear,p.z1+1,p.z2+1,p.tx
 local len = dist(p.x2-p.x1,p.y2-p.y1)
 local texx,texstepx,texstepy = tx,((p.tw)/(len/8))/8,p.th/(z2-z1)
 --draws based on furthest coord
 if p.flipped then
  texx = tx+p.tw-0.125
  texstepx *= -1 --reverse step direction
 end
 -- draw tline plane
 local stepx,stepy= (xn-xf)/len,(yn-yf)/len
 for i=0,len-1 do
  local xx,yy = xf+stepx*i,yf+stepy*i+2
  tline(xx,yy-z2, xx,yy-z1,
        texx+texstepx*i,p.ty,0,texstepy)
 end
end

function draw_wall(p)
 -- back/frontface culling
 local asum = abs(cam_angle/360+p.normal)%1
 local show,fading = min(asum,1-asum) <= 0.25,inside_fade > 0 and not p.isprop
 if p_inside then
  -- invert culling indoors
  show = not show
 end
 -- override regular drawing rule if fading
 if fading then
   -- back walls never fade
   if not (show ~= p_inside) then
    fading = false
   end
   show = true
 end
 -- draw plane
 if show then
  --draw as textured polygon
  polytex(p.verts,fading)
 end
end

function draw_roof(p)
 --don't draw if player indoors
 local fading = inside_fade > 0
 if p_inside and not fading then
  return
 end
 --draw as textured polygon
 polytex(p.verts,fading)
end

function draw_tree(p)
 --skip if outdoors only and inside
 if p.outonly and p_inside then
  return
 end
 
 local x1,y1,z,r = p.rx,p.ry,p.z,p.r
 local texstepx,texstepy = 1/r,3/z
 rect(x1,y1,x1,y1-z,3)
 circfill(x1,y1-2,r/2)
 for i=1,4 do
  local v = p.leafverts[i]
  local x2,y2,tx,ty = v.x,v.y,v.u+1,v.v
  -- draw tline plane
  local stepx,stepy = (x2-x1)/r,(y2-y1)/r
  for j=1,r do
   local xx,yy = x1+stepx*j,y1+stepy*j
   tline(xx,yy-z, xx,yy,
         tx-texstepx*j,ty,0,texstepy)
  end
 end
end

function draw_deco(p)
 --only draw if player indoors
 if not p_inside then
  return
 end
 --draw as textured polygon
 if p.iswall then
  draw_wall(p)
 else
  polytex(p.verts,false)
 end
end
-->8
--main
function dist(dx,dy,dz)
 -- dz is optional
 local z = dz or 0
 return sqrt(dx*dx+dy*dy+z*z)
end


function make_v(x,y,z,u,v)
 return {x=x,y=y,z=z,u=u,v=v}
end


function pixel_color(x,y)
 local pos_sp = mget(x\8,y\8)
 return sget(8*(pos_sp%16)+flr(x)%8,
 												8*(pos_sp\16)+flr(y)%8)
end


function flag(mx,my,f)
 return fget(mget(mx,my),f)
end

function collide(x,y,f,every)
 --handle player hitbox collisions
 local ss = p_s/16
 local f1 = flag(x-ss,y-ss,f)
 local f2 = flag(x+ss,y-ss,f)
 local f3 = flag(x-ss,y+ss,f)
 local f4 = flag(x+ss,y+ss,f)
 if every then
  --if every check detects the flag 
  return f1 and f2 and f3 and f4
 else
  --if any checks detect the flag
  return f1 or f2 or f3 or f4
 end
end

function canmove(x,y)
 local mx,my = x/8,y/8
 -- stop at walls
 if collide(mx,my,0) or (p_stuck and collide(mx,my,3)) then
  return false
 -- prevent crossing from inside
 -- to outside unless on doorway
 elseif not collide(mx,my,2) then
  if p_inside then
   -- walking inside
   -- allow movement if entirely on floor
   return collide(mx,my,1,true)
  else
   -- walking outside
   -- allow movement if not on floor
   return not collide(mx,my,1)
  end
 end
 -- otherwise, allow movement
 return true
end


function startfade(n)
 fade_time = n or fade_time
 fade_trans = fade_time
end


function next_dog(wait)
 dtarget += 1
 local d2 = dtarget*2
 if d2 <= #dtargets then
  dtarget_x = dtargets[d2-1]*8
  dtarget_y = dtargets[d2]*8
  dbarkwait = wait or 5
 else
  dog_done = true
  p_stuck = false
  --prevent backtracking
  fset(224,0,true)
 end
end

function rsfx(n)
 sfx(n+flr(rnd"3"))
end

function bark()
 dbarktime = dbarktimemax
 rsfx(21)
end

function whistle()
 whistletime,play_whistle = whistletimemax,false
 sfx"24"
end


function _update()
 --fade effect
 if fade_trans > 0 then
  if not ending or fade_trans > fade_time/2 then
   fade_trans -= 1
   if ending and fade_trans <= fade_time/2 then
    music(0,3000)
   end
  end
 end
 
 --advance title
 if show_title then
  if title_trans < 10 then
   title_trans += 1
  end
 elseif title_trans > 0 then
  title_trans -= 1
  if title_trans <= 0 then
   text_change = true
   text_queue = {2,3,4,5,6,7}
   show_intro = true
   p_x,p_y,cam_angle = 47,85,270
   music(5,1000)
  end
 end
 
 --display text
 local texttargety,imgtargety = 68,-16
 if not text_change and (not show_title or title_trans > 0) then
  texttargety = 74-6*#text_lines
  imgtargety = texttargety/2
 end
 if text_delay > 0 then
  text_delay -= 1
  if text_delay <= 0 and text_lines[1] == 0 then
   sfx"26"
  end
 else
  text_y += (texttargety-text_y)/2
  img_y += (imgtargety-img_y)/2
 end
 -- show dialogue can advance
 if text_y < texttargety+1 then
  text_wait += 1
  if text_wait > 45 then
   text_wait = 15
  end
 end
 -- advance to next dialogue
 if text_change and text_y > 63 then
  text_change = false
  if #text_queue > 0 then
   local nextline = text_queue[1]
   text_lines = splittext(dialogue[nextline])
   del(text_queue,nextline)
   img_show = #text_lines >= 2 and text_lines[2] > 0
   --fade out at ending
   if ending and #text_queue <= 1 then
    startfade(30)
   --play appropriate talk sound
   elseif text_mute <= 0 then
    if text_lines[1] == 0 then
     sfx"26"
    elseif text_lines[1] == 1 then
     sfx"27"
    end
   else
    text_mute -= 1
   end
  else
   text_lines = {}
   img_show = false
   -- end intro sequence
   if show_intro then
    show_intro,fade_trans,fade_time,p_lock,text_queue,text_change,text_delay,text_mute = false,15,30,false,{8,9,10,11},true,45,1
   end
   -- play whistle
   if play_whistle then
    whistle()
   end
  end
 end

 --actor updates
 for i=#triggers,1,-1 do
  local t = triggers[i]
  local x,y,w,h = t.x,t.y,t.w,t.h
  if mid(p_x,x-w,x+w) == p_x and
     mid(p_y,y-h,y+h) == p_y then
   t:effect()
  end
 end
 for i=#parts,1,-1 do
  parts[i]:upd()
 end
 snow_clock += 1
 while snow_clock > snow_wait do
  if #parts < 500 then
   add_snow()
  end
  snow_clock -= snow_wait
 end
 for i=#smoke,1,-1 do
  upd_smoke(smoke[i])
 end
 smoke_wait -= 1
 if smoke_wait <= 0 then
  add_smoke()
  smoke_wait = rnd(12)
 end
 
 --whistle
 if whistletime > 0 then
  whistletime -= 1
 end
 --dog
 if dbarktime > 0 then
  dbarktime -= 1
 end
 if dog_start and not dog_done and #text_lines <= 0 then
  --initialize dog after delay
  if dog_wait < dog_waitmax then
   dog_wait += 1
   if dog_wait >= dog_waitmax then
    text_queue = {22,23}
    text_change = true
    next_dog(40)
    bark()
   end
  --progress dog
  else
   if mid(p_x,dtarget_x-8,dtarget_x+8) == p_x and
      mid(p_y,dtarget_y-8,dtarget_y+8) == p_y then
    next_dog()
   end  
   dbarkwait -= 1
   if dbarkwait < 0 then
    dbarkwait = 90+flr(rnd(60))
    bark()
   end
  end
 end
 
 --physics
 local dx,dy,da = 0,0,0
 -- detect ice
 local p_acc,fric = 1.25,0.05
 if respawn_trans > 0 then
  fric = 0.25
 end
 if flag(p_x/8,p_y/8,4) then
  -- ice physics (oh boy)
  local vel = dist(p_dx,p_dy)
  p_acc = max(0.01,0.15-vel*0.1)
  if vel > 0 then
   local velscale = max(0,min(0.8,vel-fric))/vel
   p_dx *= velscale
   p_dy *= velscale
  end
 else
  -- no sliding
  p_dx = 0
  p_dy = 0
 end
 
 --input
 -- update rotate delay
 if p_rotwait > 0 then
  p_rotwait -= 1
 end
 -- advance title
 if show_title then
  if title_trans > 0 and (btnp"4" or btnp"5") then
   show_title,text_change,text_wait = false,true,0
   startfade(title_trans*2)
   sfx"28"
   music(-1,500)
  end
 -- ignore regular input and
 -- handle respawn transition
 elseif respawn_trans > 0 then
  respawn_trans -= 1
  if respawn_trans == respawn_warp*2 then
   startfade(respawn_warp*2)
  elseif respawn_trans == respawn_warp then
   if snow_pal > 0 then
    music"5"
   end
   p_x,p_y,p_sp,p_f,snow_wait,snow_pal = respawn_x,respawn_y,4,0,2,0
  end
 -- handle dialogue
 elseif #text_lines > 0 then
  if (btn"4" or btn"5") and p_rotwait <= 0 then
   if text_wait > 12 and (not ending or #text_queue > 1) then
    text_change,text_wait,p_rotwait = true,0,12
   end
  end
 -- handle movement and rotation
 elseif not p_lock then
  -- walk
  if btn"0" then dx -= 1 end
  if btn"1" then dx += 1 end
  if btn"2" then dy += 1 end
  if btn"3" then dy -= 1 end
  -- rotate
  if p_rotwait <= 0 then
   if btn"4" then da += 3 end
   if btn"5" then da -= 3 end
  end
 end
 
 --camera
 -- rotate camera
 cam_angle = (cam_angle+da+360)%360
 -- get camera orientation
 cam_d = cam_angle/90
 if cam_d > 3.5 then
  cam_d = 0
 else
  cam_d = max(0,flr(cam_d+0.5))
 end
 
 --move and animate
 local ca = cam_angle/360
 local step_x = cos(ca)*dx+sin(ca)*dy
 local step_y = cos(ca+.25)*dx+sin(ca+.25)*dy
 local step_l,step_d = dist(step_x,step_y),atan2(step_x,-step_y)
 if step_l > 0 then
  p_dx += p_acc*step_x/step_l
  p_dy += p_acc*step_y/step_l
  --set orientation
  p_d = step_d*4
  if p_d >= 3.5 then
   p_d = 0
  else
   p_d = max(0,flr(p_d+0.5))
  end
  --animate
  p_f = (p_f+0.25)%4
 elseif respawn_trans > respawn_warp then
  p_f = min(4,p_f+0.5)
 else
  p_f = 0
 end 
 -- detect collisions
 if not canmove(p_x+p_dx,p_y) then
  p_dx = 0
 end
 if not canmove(p_x,p_y+p_dy) then
  p_dy = 0
 end
 if not canmove(p_x+p_dx,p_y+p_dy) then
  p_dx,p_dy = 0,0
 end
 
 -- update player postion
 --  bounds should be 48 from each edge
 p_x,p_y = mid(47,1024,p_x+p_dx),mid(0,404,p_y+p_dy)
 -- update whether inside
 if inside_fade > 0 then
  inside_fade -= 1
 end
 local inside = flag(p_x\8,p_y\8,1)
 if p_inside != inside then
  p_inside,inside_fade = inside,4
  --play sound for using door
  sfx"25"
 end
 -- update checkpoint
 if mid(p_x,560,600) == p_x and p_y > 340 then
  respawn_x,respawn_y = 576,356
 end
 -- update snow intensity
 if not show_title and title_trans <= 0 then
  if dog_done then
   -- map 115,12 -> 920,96
   local snowdist = dist((904-p_x)/180,(96-p_y)/180)
   if snowdist > snow_wait then
    snow_wait = min(2,snowdist)
   end
   if snow_pal >= 4 then
     snow_pal = 3
     music(-1,1000)
    elseif snow_pal == 3 and snowdist > 0.4 then
     snow_pal = 2
    elseif snow_pal == 2 and snowdist > 0.6 then
     snow_pal = 1
     music(12,2000)
    elseif snow_pal == 1 and snowdist > 0.8 then
     snow_pal = 0
    end
  else
   -- map 108,22 -> 864,176
   local snowdist = dist((864-p_x)/225,(176-p_y)/225)
   if snowdist < snow_wait then
    snow_wait = max(0.9,snowdist)
    if snow_pal == 0 and snowdist < 0.9 then
     snow_pal = 1
     music(-1,1500)
    elseif snow_pal == 1 and snowdist < 0.7 then
     snow_pal = 2
    elseif snow_pal == 2 and snowdist < 0.4 then
     snow_pal = 3
    end
   end
  end
 end
 -- fall into water
 if respawn_trans <= 0 and flag(p_x/8,p_y/8,7) and pixel_color(p_x,p_y) == 1 then
  respawn_trans,p_f = respawn_time,0
  sfx"14"
 end
 -- get player percieved orientation
 p_cam_d = (p_d+cam_d)%4
 if p_cam_d != p_show_d then
  --update orientation with delay
  --to prevent 1-frame flicker
  if p_cam_d != p_new_d then
   p_new_d,p_new_d_wait = p_cam_d,0
  else
   p_new_d_wait += 1
   if p_new_d_wait > 1 then
    p_show_d = p_new_d
   end
  end
 else
  p_new_d_wait = 0
 end
 -- leave footprints
 if step_l != 0 and p_f%2 == 0 then
  add_footprint(step_d)
 end
 -- set player sprite
 if respawn_trans > respawn_warp then
  p_sp = 0
 elseif p_show_d == 1 then
  p_sp = 4
 elseif p_show_d == 3 then
  p_sp = 8
 else
  p_sp = 12
 end
 p_sm = (p_show_d == 2)
 -- lerp camera
 local camlerp = 2
 if show_title then
  camlerp = 12
 end
 cam_x += (p_x-cam_x)/camlerp
 cam_y += (p_y-cam_y)/camlerp
 
 --break ice
 for x=-1,1,1 do
  for y=-1,1,1 do
   local mx,my = (p_x+x)\8,(p_y+y)\8
   if flag(mx,my,6) then
    break_ice(mx,my)
   end
  end
 end
 --crack2 ice
 for x=-3,3,3 do
  for y=-3,3,3 do
   local mx,my = (p_x+x)\8,(p_y+y)\8
   if flag(mx,my,5) then
    crack2_ice(mx,my)
   end
  end
 end
 --crack1 ice
 for x=-5,5,5 do
  for y=-5,5,5 do
   local mx,my = (p_x+x)\8,(p_y+y)\8
   if mget(mx,my) == 20 then
    crack1_ice(mx,my)
   end
  end
 end
end
-->8
--text
function splittext(text)
 local txt = text
 --num 1 = box style (0 player, 1 jones, 2 dog)
 --num 2 = image (0 none, 1 bench)
 local t,pos = {tonum(sub(txt,1,1)),tonum(sub(txt,2,2))},3
 --current char, last line break,last space pos
 local ccount,splitpos,spacepos = 0,pos,pos
 while pos < #txt do
 	local c = sub(txt,pos,pos)
 	--mark word break
 	if c == " " or c == "-" then
 		spacepos = pos
 	end
 	--break line at /
 	if c == "/" then
 	 add(t,sub(txt,splitpos,pos-1))
 	 pos += 1
 	 splitpos,spacepos,ccount = pos,pos,-1
 	--break line at word break
 	elseif ccount > lmax then
 	 local len = pos-spacepos
 	 add(t,sub(txt,splitpos,spacepos))
 	 splitpos,ccount = spacepos+1,len-1
 	end
 	pos += 1
 	ccount += 1
 end
 add(t,sub(txt,splitpos,pos))
 return t
end
-->8
--drawing
function spal(c1,c2,c3,c4,c5,c8,
              c9,c10,c12,c13,c14,c15)
 pal(1,c1)
 pal(2,c2)
 pal(3,c3)
 pal(4,c4)
 pal(5,c5)
 pal(8,c8)
 pal(9,c9)
 pal(10,c10)
 pal(12,c12)
 pal(13,c13)
 pal(14,c14)
 pal(15,c15)
end

function _draw()
 cls"7"
 
 --snow palette swap
 if snow_pal == 1 then
  spal(5,5,13,13,5,13,
       6,10,6,13,6,6)
 elseif snow_pal == 2 then
  spal(13,13,13,13,13,13,
       6,10,6,13,6,6)
 elseif snow_pal == 3 then
  spal(6,6,6,6,6,6,
       6,7,6,6,6,6)
 elseif snow_pal == 4 then
  spal(6,6,7,6,7,6,
       7,7,7,6,6,6)
 end
 
 local ca = cam_angle/360
 cax,cay = cos(ca),sin(ca)
 local cdx,cdy = -cos(ca+.25)/8,-sin(ca+.25)/8
 --draw map
 for x=0,63 do
  tline(x,0,x,63,
        (cam_x+(x-32)*cax+32*cay)/8,
        (cam_y+(x-32)*cay-32*cax)/8,
        cdx,cdy)
 end
 --sort actors into buckets
 -- initialize buckets
 buckets = {}
 for i=0,bucket_count do
  add(buckets,{})
 end
 -- sort actors
 foreach(walls,wall_to_screen)
 foreach(planes,plane_to_screen)
 foreach(tprops,tprop_to_screen)
 foreach(trees,tree_to_screen)
 foreach(props,map_to_screen)
 foreach(parts,map_to_screen)
 foreach(smoke,smoke_to_screen)
 -- insert player
 add_player()
 
 --draw actor shadows
 if snow_pal < 4 then
  for i=1,#buckets do
   local b=buckets[i]
   for j=1,#b do
    b[j]:shad()
   end
  end
 end
 --draw actors from buckets
 for i=1,#buckets do
  local b=buckets[i]
  for j=1,#b do
   b[j]:draw()
  end
 end
 
 --reset snow palette change
 pal()
 
 --draw whistle
 if whistletime > 0 then
  local wfactor = 2-2*whistletime/whistletimemax
  for i=0,2 do
   local rw = 12*(wfactor-i/2)
   if rw > 0 and rw < 8 then
    circ(31,27,rw,15)
   end
  end
 end
 --draw bark
 if dog_start and not dog_done then
  local angb = atan2(dtarget_x-p_x,dtarget_y-p_y)
  local xb,yb = p_x+48*cos(angb)-cam_x,p_y+48*sin(angb)-cam_y
  local barkx = mid(0,63,xb*cax+yb*cay+32)
  local barky = mid(0,63,yb*cax-xb*cay+32)
  local bfactor = 2-2*dbarktime/dbarktimemax
  for i=0,2 do
   local rb = 8*(bfactor-i/2)
   if rb > 0 and rb < 8 then
    circ(barkx,barky,rb,9)
   end
  end
 end
 
 --draw intro background
 if show_intro then
  cls"7"
 end
 
 --draw title
 if (show_title and title_trans > -5) or title_trans > 0 then
  local titlef = title_trans*0.75-6
  local titley = -titlef*titlef+11.5
  ovalfill(6,titley+1,57,titley+20,6)
  oval(3,titley-2,60,titley+23)
  print("@jusiv_",19,titley-8)
  ovalfill(8,titley+3,55,titley+18,7)
  sspr(62,120,35,8,10,titley+6)
  sspr(92,120,10,8,44,titley+6)
 end
 
 --draw fade transiton
 if fade_trans > 0 then
  local ff = fade_trans/fade_time
  if ff < 0.15 then
   fillp(0b1111000011110000.1)
  elseif ff > 0.85 then
   fillp(0b0000111100001111.1)
  end
  rectfill(0,0,63,63,7)
  fillp()
 end
 
 --draw dialogue
 local tl,c1,c2 = #text_lines > 0,2,8
 if tl then
  local boxid,picid = text_lines[1],text_lines[2]
  if boxid == 1 then
   -- mr. jones
   c1,c2 = 3,11
  elseif boxid == 2 then
   -- dog
   c1,c2 = 5,13
  end
  if img_show then
   local ix1,iy1,ix2,iy2 = 8,img_y-14,56,img_y+15
   ovalfill(ix1-1,iy1-1,ix2+1,iy2+1,10)
   oval(ix1,iy1,ix2,iy2,9)
   ovalfill(ix1+3,iy1+3,ix2-3,iy2-3)
   ovalfill(ix1+5,iy1+5,ix2-5,iy2-5,10)
   ovalfill(ix1+7,iy1+7,ix2-7,iy2-7,7)
   if picid == 1 then
    if ending then
     -- i ran out of digits so
     -- this is a jank work-around
     spr(88,25,img_y-2)
     pset(31,img_y+2,4)
     spr(78,32,img_y-2,1,1,true,false)
     print("♥",30,img_y-6,8)
    else
     spr(93,30,img_y-2,2,1)
     spr(82,30,img_y-4)
     spr(78,22,img_y-2)
     print("♥",25,img_y-6,8)
    end
   elseif picid == 2 then
    if ending then
     -- same as above
     spr(93,25,img_y-3,2,1)
    else
     spr(83,38,img_y-4)
     spr(67,20,img_y-4,1,1,true,false)
     print("(",34,img_y-3,15)
     pset(37,img_y-1)
    end
   elseif picid == 3 then
    spr(109,24,img_y-7,2,2)
   elseif picid == 4 then
    ovalfill(ix1+9,iy1+8,ix2-9,iy2-8,12)
    spr(255,25,img_y-4)
    circ(36,img_y,1,7)
    pset(21,img_y+2)
    pset(40,img_y-2)
    pset(34,img_y+6)
    circ(31,img_y+4,1,6)
    pset(32,img_y-5)
    pset(43,img_y+3)
   elseif picid == 5 then
    if ending then
     -- same thing
     spr(12,24,img_y-3)
     spr(89,34,img_y-3,1,1,true,false)
     print("!",33,img_y-5,6)
    else
     spr(66,26,img_y-3)
     spr(68,34,img_y-3)
    end
   elseif picid == 6 then
    spr(4,29,img_y-4)
   elseif picid == 7 then
    ovalfill(ix1+9,iy1+8,ix2-9,iy2-8,12)
    ovalfill(ix1+14,iy2-16,ix2-9,iy2-12,3)
    print(":\"",34,img_y-3)
    print("':",40,img_y-2)
    print("\"",17,img_y)
    ovalfill(ix1+9,iy2-14,ix2-34,iy2-12,6)
    ovalfill(ix1+24,iy2-15,ix2-9,iy2-10)
    ovalfill(ix1+10,iy2-14,ix2-13,iy2-7,7)
    print("'",44,img_y+4)
    print("'",46,img_y+3)
    sspr(51,120,11,8,22,img_y-5)
   elseif picid == 8 then
    spr(67,29,img_y-4)
   elseif picid == 9 then
    ovalfill(ix1+9,iy1+8,ix2-9,iy2-8,14)
    rectfill(19,img_y,45,img_y+2,4)
    rect(20,img_y+3,44,img_y+3)
    rect(21,img_y+4,43,img_y+4)
    rect(24,img_y+5,40,img_y+5)
    spr(253,24,img_y-4)
    spr(253,33,img_y-5,1,1,true,false)
    print("made by @jusiv_",3,img_y-23,6)
    print("thx for playing!",1,img_y+20)
   end
  end
 end
 rectfill(0,text_y,63,64,c1)
 rect(-1,text_y,64,64,c2)
 local textx = 1
 if text_lines[2] == 9 then
  textx = 2
 end
 if tl then
  for i=3,#text_lines do
   print(text_lines[i],textx,text_y+6*i-16,7)
  end
  if (not ending or #text_queue > 1) and text_y < 58 and text_wait >= 10 then
   sspr(48,124,3,4,60,58+flr(text_wait/15)%2)
  end
 end
end
-->8
--imported

--[[
polytex: textured edge renderer

this function is the work of 
freds72 (@fsouchu on twitter).
it is used here with his
permission.

it is slightly modified to
interpret height (z) values 
correctly in my engine and to
have a fading effect.

forum source:
https://www.lexaloffle.com/bbs/?pid=76387#p
--]]
function polytex(v,fade)
	local p0,nodes=v[#v],{}
	local x0,y0,u0,v0=p0.x,p0.y-p0.z,p0.u,p0.v
	for i=1,#v do
		local p1=v[i]
		local x1,y1,u1,v1=p1.x,p1.y-p1.z,p1.u,p1.v
		local _x1,_y1,_u1,_v1=x1,y1,u1,v1
		if(y0>y1) x0,y0,x1,y1,u0,v0,u1,v1=x1,y1,x0,y0,u1,v1,u0,v0
		local dy=y1-y0
		local dx,du,dv=(x1-x0)/dy,(u1-u0)/dy,(v1-v0)/dy
		if(y0<0) x0-=y0*dx u0-=y0*du v0-=y0*dv y0=0
		local cy0=ceil(y0)
		-- sub-pix shift
		local sy,toggle = cy0-y0,true --whether to draw a given line
		x0+=sy*dx
		u0+=sy*du
		v0+=sy*dv
			
		for y=cy0,min(ceil(y1)-1,63) do
			--skip every other line if fading
			if fade then
 			toggle = not toggle
			end
			
			local x=nodes[y]
			if x and toggle then
				-- backup current edge values
				local a,au,av,b,bu,bv=x[1],x[2],x[3],x0,u0,v0
				if(a>b) a,au,av,b,bu,bv=b,bu,bv,a,au,av
				
				local x0,x1=ceil(a),min(ceil(b)-1,63)
				if x0<=x1 then
					local dab=b-a
					local dau,dav=(bu-au)/dab,(bv-av)/dab
					-- sub-pix shift
					local sa=x0-a
					au+=sa*dau
					av+=sa*dav
					tline(x0,y,x1,y,au,av,dau,dav)
			 end
			else
				nodes[y]={x0,u0,v0}
			end
			x0+=dx
			u0+=du
			v0+=dv
		end
		x0,y0,u0,v0=_x1,_y1,_u1,_v1
	end
end