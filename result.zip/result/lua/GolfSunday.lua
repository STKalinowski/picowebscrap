-- golf sunday
-- by @jOHANpEITZ 

done_102=[[
* fixed cart sound not stopping if accelrating with z
]]

-- ★ todo ★

-- ★ polish ★

-- explode cart if hit from afar
--  animation
--  particles
--  sfx(45)

-- put the golf sign on top
-- don't shoot through trees
-- show score card anytime with z

-- -- --

-- sfx for driving in rough
-- indicate where flag is when aiming
-- repeat last aim if ob/cancel

-- time attack
--  time per hole
--  total time, inc between time

-- flatter parabola
-- cart shadows 
-- player shadow

-- birds
-- chance to get crappy cart
-- see player in car
-- custom font
-- turn car when jumping out
-- if closer to car than ball
--  draw arrow on car 
-- x hidden things



done_002=[[
* added proper cart label 
* added ability to hit flags with cart
* added ability to smash signs with cart
* added indication for last tee on score card
* added call outs for various results
* added a brief pause before the game music starts
* added more carts standing left on courses
* tweaked swing animation to allow for more angles
* tweaked putting ui
* tweaked putting to be slightly harder
* fixed empty carts getting pushed into buildings
* fixed 0's showing on score card
* fixed ball indicator showing on title screen post completion
* fixed issue in collision detection and response
* fixed animation issue when moving while leaving swing state
* fixed animation issue when moving vertically
* performance improvements


]]

done_003=[[
* added version number to title (press z)
* added staff greeting
* added sfx to putt ui
* added hole par to hud
* added storing best result
* added swimming
* added sinking carts
* added new sounds
* tweaked putting power slightly
* tweaked water obstacles 
* tweaked flag bounce chance 
* tweaked putting animation 
* tweaked existing sounds
* removed black pixel from aiming reticule
* removed swing sound when putting
* fixed putting ui to allow for longer putts
* fixed bunker and green getting mixed up in some cases
* fixed crash caused by empty vehicles rolling into walls/trees
* fixed occasional jitter when camera was tracking player
]]

done_100=[[
* added waves to water
* added fading when transitioning from title screen
* added ball bouncing on carts
* added sound for hitting carts with carts
* added water particles when driving in water
* added free roaming after hole 9
* tweaked text skipping
* tweaked course tilemap
* tweaked water sound
* tweaked well done sign
* tweaked cart positions on map
* tweaked putting to be slightly easier
* fixed shooting ball outside of the map
* fixed driving cart outside of the map
* fixed walking/swimming outside of the map
* fixed footstep sound played swimming
* fixed cart trails appearing in water
* fixed aiming circle being too narrow
* fixed hole 9 being outside the map
* performance improvements
]]

done_101=[[
 * added ability to accelerate with z
]]

-->8
-- game

version="1.0.2"

my_pal={
 0, 133, 2, 3,
 4, 131, 6, 7,
 136, 10, 139, 11,
 12, 13, 143, 15
}

dpal={
 0, 0, 1, 5,
 2, 1, 13, 6,
 2, 1, 3, 10,
 13, 1, 4, 14
}

intros={
 { "wELCOME! hOPE\nYOU'LL HAVE A\nGREAT DAY.",
   "mORNING.\nwEATHER'S\nNICE TODAY.",
   "wHAT'S UP?\nhERE TO PLAY\ni GUESS...",
   "hELLO HELLO!\ntHE SUN IS\nSHINING!",
   "hI THERE,\nTIME FOR SOME\nGOLF, HUH?",
   "zZZ...\noH, HI.\nsORRY.",
 },
 {
  "dON'T WRECK\nTHE CARTS.\npLEASE.",
  "wEIRD, NO ONE\nELSE HERE\nTO PLAY.",
  "hERE'S YOUR\nEQUIPMENT.",
  "iS IT YOUR\nFIRST TIME\nHERE?",
  "tIME TO BREAK\nTHE RECORD?\n",
  "i JUST MOWED\nTHE GRASS.\n",
 },
 {
  "pAR IS 31 PTS\ngOOD LUCK!"
 }
}


-- tree data
tree_data={}
tree_data[181]=163
tree_data[180]=162
tree_data[179]=163
tree_data[178]=162
tree_data[177]=171
tree_data[176]=170
tree_data[160]=171
tree_data[161]=170

function _init()
 cartdata("jpgolfsunday")
 seed=rnd(32000)
 gid=0
 fade_progress=1

 -- reset best
 best_result=dget(0)
 if best_result==0 then
  reset_best()
 end
 
 -- set up new pal
 for i=1,16 do
  pal(i-1, my_pal[i], 1)
 end
 poke(0x5f2e,1)
  
	-- go into 64x64
	poke(0x5f2c, 3)
	
	-- repeat delay
	poke(0x5f5c,255)
	poke(0x5f5d,255)
	
	show_title()
end

function reset_best()
 dset(0,35) 
 best_result=dget(0)
end

function record_result(result)
 if result<best_result then
  best_result=result
  new_best=true
  dset(0,best_result)
 end
end

function set_score_string()
 caddie_text[3]="pAR IS 31 PTS\nbEST, "..best_result.." PTS\ngOOD LUCK!"
end


function show_title()
 ⧗=0

 -- cam
 camx=0
 camy=0
 track_spd=0.05
 
 restart=false
	
 -- 0=title
 -- 1=playing
 -- 2=ball in hole
 -- 3=end summary
 state=0
 score_card_y=999
 put_ui_x=64
 ui_delay=0
 track_delay=0
 put_⧗=0
 
 ball=nil
 hole=nil
 	 
 setup_world()
end

function setup_world()
 reload()
 
 -- cooldowns
 btnx_cooldown=0 
 counter=0
 
 -- swining
 swing_state=0
 reticule=nil

 -- trails & particles
 trails={}
 particles={}
 waves={}
 wtiles={}

 -- entities	
	entities={}
	statics={}
	dynamics={}
	carts={}
	
	-- greens
 terrain={}
	
	-- scan map
	local bonus_carts=0
	for x=0,127 do
		for y=0,31 do
			local tile=mget(x,y)
			
			-- water?
			if tile==68 then
			 add(wtiles, {x=x,y=y})
			end
			
			-- tree?
			if (tile>=176 and tile <=181) or tile==160 or tile==161 then
	   local t2=mget(x,y-1)
	   if not fget(t2,0) then
	    gid+=1
		   local tree=add(entities,{
		    type="tree",
		    gid=gid,
		    x=x*8+4, y=y*8+8,
		    spr=tree_data[tile],
      tw=1,th=2,
      frame=0,sw=8,sh=16,
      df=draw_entity,
      cr=2,cox=3.5,coy=-1.5
		   })
		   if tile==180 or tile==178 then
 		   add(statics,tree)
		   end
		   if tile==180 or tile==181 then
		    mset(x,y,65)
		   end
		   if tile==178 or tile==179 then
		    mset(x,y,0)
		   end
		  end
			end
			
			-- is it a character
			if tile==16 then
   	pl=make_player(x*8+4,y*8+7)
   	pl.cr=1
    pl.cox=-1
    pl.coy=0
    pl.cprio=10
   	add(dynamics,pl)
   	mset(x,y,240)
			end
			-- is it a course cart
			local cart=nil
			if tile>=2 and tile<=5 then
			 cart=make_cart(x*8+4,y*8+7,(tile-2)*0.25)
   	mset(x,y,0)
			end
			-- is it a start cart
			if rnd()>0.4 and (tile==224 or tile==225) and bonus_carts<2 then
			 cart=make_cart(x*8+(tile==224 and 5 or 3),y*8+5,tile==224 and 0 or 0.5)
			 cart.nox=true
    bonus_carts+=1
			end
			if cart then
   	cart.cr=3
    cart.hit_by_cart=0
    cart.cox=0
    cart.coy=-2
			 cart.cprio=20
    add(dynamics,cart)
    add(carts,cart)
			end
			-- is it a sign?
			if tile>=87 and tile<=95 then
			 -- sign
			 local sign=make_entity(x*8+3,y*8+5,{
			  type="sign",
			  spr=tile,
			  cprio=17,
     cr=2,cox=0,coy=-1,
     on_hit=function(e,src)
      add(to_delete,e)
      mset(e.x/8,e.y/8,86)
      make_sign_smash(e.x,e.y)
      sfx(47)
     end
     
 		 })
			 add(dynamics,sign)
			 mset(x,y,0)
			end
			-- is it a hole?
			if tile>=103 and tile<=111 then
			 -- flag
			 local f=make_entity(x*8+3,y*8+5,{
			  type="flag",
			  spr=1,
			  cprio=15,
     cr=1,cox=0,coy=-1,
     on_hit=function(e,src)
	     e.spr=6
      e.dx=2*src.s*cos(src.a)
      e.dy=-2*src.s*sin(src.a)
      e.ix=0.93
      e.iy=0.93
      del(dynamics, e)
      sfx(46)
     end
			 })
			 add(dynamics, f)
			 
			 -- hole
			 make_entity(f.x,f.y,{
			  type="hole",
		   df=function(e) end,
			  id=tile-102
			 })
			 
			 -- generate green
			 srand(x+y+tile*5)
			 local ox=rnd(8)-4
			 local oy=rnd(8)-4
			 for i=3,5 do
			-- for i=6,8 do
			  add(terrain, {
			   x=ox+x*8+4+2.4*i*(rnd()-0.5),
			   y=oy+y*8+4+2.4*i*(rnd()-0.5),
			   r=2+i+rnd(6),
			   c=11
			  })
			 end
   	srand(seed*x)
			end
		end
	end
	
 panner={
  x=159,y=64,
  uf=function(e)
   e.x=480+300*cos(t()/100)
   e.y=128+ 64*sin(t()/50)
  end
 }
	track(panner,1)	
	
	music(0)
end

function start_game()
 sfx(62)
 state=1
 
 setup_world()
 
 local par={3,2,4,4,3,4,3,4,4,0}
 courses={}
 for i=1,9+1 do
  add(courses,{
   score=0,
   par=par[i],
   started=false
  })
 end

 track(pl,1)
 pl.has_control=true
	
	-- set up first tee
	tee=0 
 next_tee()
 
 msg=nil
 
	music(-1)
	
	-- place instructions
	local e=make_entity(
	 175,208, {
	 df=function(e) end,
  type="hello",
  cprio=1,
  cr=8,cox=0,coy=0,
  on_hit=function(e,src)
   pl.frame=0
   pl.dir=-1
   caddie_count=0
   caddie_y=0
   caddie_page=1
   caddie_tc=0
   caddie_text={
    rnd(intros[1]),
    rnd(intros[2]),
    "i am error."
   }
   set_score_string()
   sfx(63)
   mset(20,26,230)
   add(to_delete, e)
  end	 
	})
	add(entities,e)
	add(dynamics,e)
 
 fadeout()
end


function show_message(txt)
 msg={
  str=txt,
  ⧗=0,
  x=31 - 2 * #txt,
  y=-8
 }
end

function next_tee()
 tee+=1
 
 if tee==10 then --10 then
  state=3
  tee=11
  record_result(total_result)
  return
 end
 
 local teex,teey
 -- search for tee
	for x=0,127 do
		for y=0,31 do
			local tile=mget(x,y)-118
			if tile==tee then
			 teex,teey=x,y
			end
  end
 end 

 state=1
 if tee>1 then
  sfx(63)
 end
  
 if tee<10 then
	 -- place ball
	 ball=make_ball(teex*8+5,teey*8+5)
		poi=ball  
	 -- find and assign hole
	 hole=nil
	 for e in all(entities) do
	  if e.type=="hole" then
	   if e.id==tee then
	    hole=e
	   end
	  end
	 end
 else
  track(pl)
  swing_state=0
  pl.has_control=true
  ball=nil
  pl.frames=4
  pl.spr=16
  poi=nil
  
 	local e=make_entity(
		 163,214, {
			 df=function(e) end,
		  type="bye",
		  cprio=1,
		  cr=3,cox=0,coy=0,
		  nocart=true,
		  on_hit=function(e,src)
			  sfx(49,-2)
			  sfx(51,-2)
					music(-1)
     sfx(62)
		   pl.frame=0
		   pl.dir=-1
		   caddie_count=0
		   caddie_y=0
		   caddie_page=1
		   caddie_tc=0
		   caddie_text={
		    total_result.." POINTS,\nWHAT A GREAT\nRESULT!",
		    "hOPE YOU\nHAD FUN.",
		    "sEE YOU\nNEXT TIME!"
		   }
		   poi=nil
		   sfx(63)
		   add(to_delete, e)
   		restart=true
		  end	 
		})
		add(dynamics,e)
		add(entities,e)
		poi=e
		 
	end
 
end

function track(o,spd,delay)
 ctrack=o
 track_spd=spd or 0.05
 track_delay=delay or 0
end

function _update60()
 if fade_progress>0 then
  fade_progress-=0.1
 end
 
 if (btnp(3,1)) debug=not debug

 to_delete={}

 ⧗+=1
 
 -- animate water
 if rnd()<0.75 then
	 local wtile=rnd(wtiles)
	 add(waves,{
	  x=wtile.x*8+rnd(8),
	  y=wtile.y*8+rnd(8),
	  ⧗=0,
	  df=function(e)
	   if e.⧗>60 then
	    del(waves,e)
	   end
	   local len=-flr(4*sin(e.⧗/120))/2
	   line(e.x-len,e.y,e.x+len,e.y,7)
	   pset(e.x-len,e.y,6)
	   pset(e.x+len,e.y,6)
	   e.⧗+=1
	  end,
	 })
 end
 
 if state==3 then
  if btnpx() then
   next_tee()
--   show_title()
   return 
  end
 end

 if ui_delay>0 then
  ui_delay-=1
 end
 
 if state==0 then
  panner.uf(panner)
  if btnpx() then
   start_game()
  end
  return
 end
 
 if state==2 then
  if btnp(❎) then
   next_tee()
  end
 end
 
 if btnx_cooldown>0 then
  btnx_cooldown-=1
 end

 if caddie_count and btnpx() then
  sfx(63)
  local txt=caddie_text[min(3,caddie_page)]
  if caddie_tc<#txt*4 then
   caddie_tc=#txt*4
  else
	  caddie_page+=1
	  if caddie_page<4 then
	   caddie_tc=0
	  else
	   caddie_count=61
	   mset(20,26,229)
	   if restart then
 	   fadeout()
 	   show_title()
    else
 	   music(5)
    end	   
	  end
	 end
 end
 
 if ui_delay==0 and not caddie_count then
	 if swing_state>=2 then
	  counter+=1
	  if counter==30 then
	   pl.spr=39
	   if not ball.putting then
	    pl.spr=33
	    sfx(60)
	   end
	  end 
	  if counter==60 then
	   pl.spr=pl.rev_swing and 37 or 34
	   if ball.putting then
	    pl.spr=40
	   end
	   sfx(59)
	  end

	  if counter==64 then
	   pl.spr=pl.rev_swing and 38 or 35 
	  end 
	  if counter==68 then
	   pl.spr=36
	  end 
	  if ball.putting and counter>=64 then
    pl.spr=40
   end
	  if counter==100 then
	   pl.spr=16
	  end 
	 end
 
	 if swing_state>0 then
	  if swing_state==1 then
	   if ball.terrain!="green" then
	    ball.putting=false
		   reticule.x+=(reticule.tx-reticule.x)*0.05
		   reticule.y+=(reticule.ty-reticule.y)*0.05
		   -- adjust aim
		   if (btn(⬅️)) reticule.tx-=0.5
		   if (btn(➡️)) reticule.tx+=0.5
		   if (btn(⬆️)) reticule.ty-=0.5
		   if (btn(⬇️)) reticule.ty+=0.5
		   aim_power=distance(reticule,ball)
		   local dx=reticule.tx-ball.x
		   local dy=reticule.ty-ball.y
		   in_bunker=is_bunker(ball.x,ball.y)
		   local max_p=in_bunker and 20 or 80
		   if aim_power>max_p then
		    local a=atan2(dx,dy)
		    reticule.tx=ball.x+(max_p-1)*cos(a)
		    reticule.ty=ball.y+(max_p-1)*sin(a)
		    reticule.max=8
		   end
		   
		   if btnpx() then
				  local dx=reticule.x-ball.x
			   local dy=reticule.y-ball.y
		  	 reticule.r=get_reticule_r()
			   aim_angle=atan2(dx,dy)
		    track(ball)
		    swing_state=2
		    counter=0
		   end
		  else
		   -- ball on green
		   ball.putting=true
		   
		   if btnpx() then
				  local dx=hole.x-ball.x
			   local dy=hole.y-ball.y
			   aim_angle=atan2(dx,dy)
			   aim_power=ball.power+0.025
		    track(ball)
		    swing_state=2
		    counter=0
		    ui_delay=30
		    sfx(63)
		   end
		  end
	   if btnp(🅾️) then
		   pl.spr=16
		   track(pl)
		   swing_state=0
	   end
	  elseif swing_state==2 and counter>60 then
	   -- power meter
	   if ball.putting then
	    swing_power=0.42*aim_power
	   else
	    swing_power=0.3*aim_power
	   end
	   swing_state=3
	  elseif swing_state==3 then
	   -- animate power selection
	   -- done
	   swing_state=4
	  elseif swing_state==4 then
	   -- aim meter
	   swing_angle=aim_angle
	   swing_state=5
	  elseif swing_state==5 then
	   -- animate angle selection
	   -- done
	   swing_state=6
	  elseif swing_state==6 then
	   if not ball.putting then
		   --let the ball fly!
		   -- target 
		   local tx=swing_power*cos(swing_angle)
		   local ty=swing_power*sin(swing_angle)
		   -- adjust
		   local a=rnd()
		   reticule.adj=rnd(reticule.r)/reticule.r
		   reticule.adj=reticule.adj^2
		   local r=reticule.adj*reticule.r
		   tx+=r*cos(a)/2.5
		   ty+=r*sin(a)/2.5
	
	    hit_ball(ball,tx,ty)
	   else
	    put_ball(ball,swing_power,swing_angle)
	   end
	   
	   
	   swing_state=7
	  elseif swing_state==7 then
	   if ball.state==0 then
	    swing_state=0
	    track(pl)
	    pl.frame=0
	    pl.spr=16
	   end
	  end
	 end
 
	 for e in all(entities) do
	 	if (e.uf) e.uf(e)
		end
 end
 
 -- handle collisions
 -- statics
 for sc in all(statics) do
 	for dc in all(dynamics) do
 		local dx=(sc.x+sc.cox)-(dc.x+dc.cox)
 		if abs(dx)<8 then
	 		local dy=(sc.y+sc.coy)-(dc.y+dc.coy)
	 		if abs(dy)<8 then
	  		local d2=dx*dx+dy*dy
	  		if d2<=(sc.cr+dc.cr)^2 then
	 	 	 local a=atan2(dx,dy)
		 	  dc.x-=cos(a)
			   dc.y-=sin(a)
			   dc.pusher=sc
	 	  end
	 	 end
 		end
		end
 end
 
 -- dynamics
 -- sort in prio order
 sort(dynamics,"cprio")
 -- detect collision
 for i=1,#dynamics-1 do
  dc1=dynamics[i]
  for j=i+1,#dynamics do
   dc2=dynamics[j]
 		local dx=(dc1.x+dc1.cox)-(dc2.x+dc2.cox)
 		if abs(dx)<10 then
 			local dy=(dc1.y+dc1.coy)-(dc2.y+dc2.coy)
 			if abs(dy)<10 then
	  		local d2=dx*dx+dy*dy
	  		if d2<=(dc1.cr+dc2.cr)^2 then
	 	 	 local a=atan2(dx,dy)
			   if dc1.is_cart then
			  	 dc1.a+=rnd(0.1)-0.05
			  	 dc1.trail_chance=1
							dc1.ox=dc1.x
							dc1.oy=dc1.y
							if dc1.hit_by_cart==0 then
 							sfx(48)
 							dc1.hit_by_cart=20+flr(rnd(20))
							end
	     end
	     dc1.pusher=dc2
	     dc2.pusher=dc1
	   	 dc1.x+=cos(a)
			   dc1.y+=sin(a)
			   if dc1.on_hit then
			    dc1.on_hit(dc1,dc2)
			   end
	 	  end
	 	 end
			end
	 end 
 end
 
 if not btn(❎) then
  btnx_cooldown=0
 end
 
 for e in all(to_delete) do
 	del(entities,e)
 	del(dynamics,e)
 end

end

function _draw()
	cls(10)

 if track_delay>0 then
  track_delay-=1
 else
	 camlx=camx
	 camly=camy
		camx+=(ctrack.x-31-camx)*track_spd
		camy+=(ctrack.y-31-camy)*track_spd
		if not debug then
 		camx=max(0,min(camx,768))
	 	camy=max(0,min(camy,192))
		end
		
--		if abs(camlx-camx)<0.05 and abs(camly-camy)<0.05 then
		if abs(camlx-camx)<0.1 and abs(camly-camy)<0.1 then
		 track_spd=1
		end
	end
	camera(flr(camx),flr(camy))
	
	-- terrain
	for c in all(terrain) do
	 circfill(c.x,c.y,c.r,c.c)	
	end
	
 local cx=camx-8*(camx\8)
 local cy=camy-8*(camy\8)
	map(camx\8,camy\8,camx-cx,camy-cy,9,9)
	for w in all(waves) do
		w.df(w)
	end
	for p in all(trails) do
		pset(p.x,p.y,p.c)
		p.life-=1
		if p.life<=0 then
		 del(trails,p)
		end
	end
	
	-- particles
	for p in all(particles) do
		update_particle(p)
		pset(p.x,p.y-p.z,p.col)
	end
	
	if swing_state==1 and ball.terrain!="green" then
	-- if swing_state==1 then
 	 reticule.r=get_reticule_r()
	 --end
	 local c=reticule.max>0 and 8 or 11
	 draw_reticule(reticule.x, reticule.y, reticule.r, c)
  if reticule.max>0 then
   reticule.max-=1
  end
 end

	sort(entities,"y")
	
 for e in all(entities) do
 	if (e.df) e.df(e)
	end
	
	-- poi direction
	if poi then
		if ⧗%30<25 and swing_state==0 then
			if poi.x<camx or poi.y<camy or poi.x>camx+63 or poi.y>camy+63 then
		 	local bx=min(max(poi.x,camx+3),camx+60)
		 	local by=min(max(poi.y,camy+3),camy+60)
		 	spr(55,bx-4,by-4)
		 	local bx=min(max(poi.x,camx+5),camx+58)
		 	local by=min(max(poi.y,camy+5),camy+58)
		 	spr(50,bx-4,by-4)
			else
			 if not pl.can_hit_ball then
		   draw_arrow(poi) 
			 end
			end
	 end
	end
	
	-- debug
	if debug then
	 for sc in all(statics) do
	 	circ(sc.x+sc.cox,
	 	     sc.y+sc.coy,
	 	     sc.cr,15)
  end

	 for dc in all(dynamics) do
	 	circ(dc.x+dc.cox,
	 	     dc.y+dc.coy,
	 	     dc.cr,9)
  end
	end
 
	-- hud
	camera()
	if state==0 then
	 draw_title()
	elseif state==3 then
	 pal(7,5)
	 draw_done(14,13)
	 pal(7,7)
	 draw_done(14,12)
	end
	
	if courses and courses[tee] and courses[tee].started then 
 	local dist=flr(distance(ball,hole)/1.5)
 	spr(48,0,49)
 	print(dist.."YDS",1,58,5)
 	print(dist.."YDS",1,57,7)
 	print("PAR"..courses[tee].par,48,58,5)
 	print("PAR"..courses[tee].par,48,57,7)
 end

 if state>=2 then
  if score_card_y>36 then
   score_card_y-=1
  end
  draw_score_card(3,score_card_y)
 end
 if state==1 and score_card_y<64 then
  score_card_y+=1
  draw_score_card(3,score_card_y)
 end
 
 if ball and swing_state>0 and ball.terrain=="green" then
  -- targetx 11
  if put_ui_x==11 then
   put_⧗+=1
  end
  ball.power=draw_putt_ui(put_ui_x,47)
  if swing_state==1 then
   put_ui_x=max(11,put_ui_x-2)
  end
  if swing_state==2 then
   if counter>30 then
    put_ui_x=min(64,put_ui_x+2)
   end
  end
 end
 
--	spr(49,57,49)
--	local mm=⧗\3600
--	local ss=(⧗-mm*3600)\60
--	local ss=(⧗-mm*3600)\60
--	local str=mm.."M"..(ss<10 and "0" or "")..ss.."S"
--	print(str,64-4*#str,58,5)
--	print(str,64-4*#str,57,7)
	
	-- hit ui
-- if swing_state>1 then
--	 draw_swinger(40,17)
--	end

 if msg then
  rectfill(0,msg.y,63,msg.y+6,7)
  line(0,msg.y+7,63,msg.y+7,5)
  print(msg.str,msg.x,msg.y+1,1)
  msg.⧗+=1
  if msg.⧗<60 and msg.y<-1 then
   msg.y+=1
  end
  if msg.⧗>120 then
   msg.y-=1
   if msg.y<-8 then
    msg=nil
   end
  end
 end
 
 if caddie_count then
  caddie_tc+=1
  draw_bubble(sub(caddie_text[min(3,caddie_page)],1,caddie_tc\4),4,36+32-min(32,caddie_y*3))
 
  if caddie_count<16 then
   caddie_y+=1
   caddie_count+=1 
  end
  if caddie_count>60 then
   caddie_count+=1 
   caddie_y-=1
   if caddie_count>86 then
    caddie_count=false
   end
  end
 end
	
	-- debug
	if debug then
 	?flr(100*stat(1)),1,1,0
 	?#carts,1,7,0
 --	?#dynamics.." | "..#statics.." | "..#entities,1,13,0
 end

 update_fade()
 
end


-->8
-- entities

function make_entity(x,y,p)
 gid+=1
 local e={
  gid=gid,
  ⧗=0,
  x=x,
  y=y,
  dx=0,dy=0, -- delta movement
  ix=0,iy=0,
  
  w=8,h=8,

  spr=1,
  frame = 0,
  frames = 0,
  fs = 4,
  tw=1,th=1,
  sw=8,sh=8,
  
  df=draw_entity,
  uf=update_entity
 }
 
 add_params(p,e)
 
 return add(entities,e)
end

function update_entity_x(e)
 e.x += e.dx
 e.dx *= e.ix
 if abs(e.dx)<0.001 then
  e.dx=0
 end
end

function update_entity_y(e)
 e.y += e.dy
 
 e.dy *= e.iy
 if abs(e.dy)<0.001 then
  e.dy=0
 end
end

function update_entity(e)
 e.⧗ += 1

 -- store old values
 e.odx=e.dx
 e.ody=e.dy
 e.ox=e.x
 e.oy=e.y
 
 -- collide with world
 update_entity_x(e)
 
 update_entity_y(e)
  
 update_entity_a(e)
end

function update_entity_a(e)
 if e.frames>0 then
  if (e.⧗ % e.fs == 0) e.frame += 1
  if (e.frame>=e.frames) e.frame=0
 end 
end

function draw_entity(e)
 spr(e.spr+e.frame*e.tw,
  e.x - e.sw/2, 
  e.y - e.sh + 1, 
  e.tw, e.th,
  e.dir==-1)  

 if (debug) then
  pset(e.x,e.y,8)
  print(e.frames,e.x-8,e.y,7)
  if e.pusher then
	  print(e.pusher.type.."-"..e.pusher.gid,e.x,e.y-8,7)
	  line(e.pusher.x,e.pusher.y,e.x,e.y,9)
	  --e.pusher=nil
  end
 end
end

----------------
-- ball


function make_ball(x,y)
	return make_entity(x,y,{
	 type="ball",
	 ix=0.9,iy=0.9,
	 z=0, dz=0,
	 state=0,
	 uf=update_ball,
	 df=draw_ball
	})
	
end

function update_ball(b)

 if b.state==1 then
  
  if not b.putting then
   b.z+=b.dz
   b.dz-=0.01
  end
  

  local stop_ball=false
  
  if b.z<=0 then
   local snd=nil
   b.z=0
   b.dz=-b.dz/2
   b.terrain="grass"
   
   if is_tree(b.x,b.y) or not on_map(b) then
    sfx(54)
    snd=true
    b.terrain="tree"
    kill_ball(b)
    stop_ball=true
			 show_message("OUT OF BOUNDS")
   end
   
   if is_bunker(b.x,b.y) then
    sfx(57)
    snd=true
    b.terrain="sand"
			 -- particles
			 make_dust(b.x,b.y,b.dx,b.dy,b.dz)
    -- stop in the bunker
    b.dz=0
    stop_ball=true
			end
			
   if is_rough(b.x,b.y) then
    b.terrain="rough"
    -- bad bounce
    b.dz/=2
			end

 
	  if is_water(b.x,b.y) then
    sfx(56)
    snd=true
    b.terrain="water"
    -- stop and die
    kill_ball(b)
			
			 -- particles
			 make_splash(b.x,b.y)
    stop_ball=true   
			 show_message("OUT OF BOUNDS")
			end
			
			-- ball in hole?
	  local d=distance(b,hole)
	  if d<1.5 and not b.bounce then
	   local spd=sqrt(b.dx*b.dx+b.dy*b.dy)
	   if b.putting and spd>0.25 then
	    local a=atan2(b.dx,b.dy)
	    a+=rnd(0.4)-0.2
	    b.dx=spd*cos(a)
	    b.dy=spd*sin(a)
	    b.bounce=true
	    sfx(55)
	   else
		   pl.spr=16
		   del(entities,b)
		   state=2
		   score_card_y=96
     sfx(52)
     snd=true
     if courses[tee].score==1 then
 	  	 show_message("HOLE IN ONE")
	    else
	     local diff=courses[tee].score-courses[tee].par 
	     if (diff==-3) show_message("ALBATROSS")
	     if (diff==-2) show_message("EAGLE")
	     if (diff==-1) show_message("BIRDIE")
	     if (diff==0) show_message("PAR")
	     if (diff==1) show_message("BOGEY")
	     if (diff==2) show_message("DOUBLE BOGEY")
	     if (diff==3) show_message("TRIPPLE BOGEY")
	    end
		   return
		  end
	  end
	  
	  if not snd and not b.putting then
 	  sfx(58)
	  end

   -- stopped bouncing?
   if abs(b.dz)<0.1 and not ball.putting then
    stop_ball=true
   end
   if abs(b.dx)<0.05 and
      abs(b.dy)<0.05 and
      ball.putting then
    stop_ball=true
   end
    
   if stop_ball then
    b.state=2
    b.count=0
    b.dx=0
    b.dy=0
    b.bounce=false
    
    -- is on green?
    if not is_bunker(b.x,b.y) then
	    for g in all(terrain) do
	     local dist=distance(g,b)
	     if dist<=g.r then
	      b.terrain="green"
	      if not b.on_green then
	       b.on_green=true
	       show_message("ON THE GREEN")
	      end
	     end
     end
    end
    
   elseif not ball.putting then
    b.dx/=2
    b.dy/=2
	  end
  end
 elseif b.state==2 then
  b.count+=1
  if b.count>=30 then
   b.state=0
  end
 end
 
 update_entity(b)	

 if b.state==1 and not b.hit_cart then
	 -- check against carts
	 if b.z>0.1 and b.z<6 then
	  for c in all(carts) do
	  	-- overlap?
	 		local dx=(c.x+c.cox)-b.x
	 		if abs(dx)<8 then
	 		local dy=(c.y+c.coy)-b.y
		 		if abs(dy)<8 then
 	  		local d2=dx*dx+dy*dy
	   		if d2<=c.cr^2 then
			 		 b.x-=b.dx
			 		 b.y-=b.dy
			 		 local a=atan2(b.dx,b.dy)
			 		 local f=sqrt(b.dx*b.dx+b.dy*b.dy)
			 		 b.dx=-f*cos(a)/2
			 		 b.dy=-f*sin(a)/2
			 		 sfx(53)
			 		 b.hit_cart=true
		 			 c.a+=rnd(0.1)-0.05
			 		end
		 		end
	   end
	  end
	 end
	end
end

function kill_ball(b)
 swing_state=0
 pl.frames=4
 track(pl,nil,30)
 del(entities, b)
 ball=make_ball(b.orgx, b.orgy)
 poi=ball
end

function put_ball(b,pow,a)
 b.orgx=b.x
 b.orgy=b.y
 b.dx=2.5*pow*cos(a)
 b.dy=2.5*pow*sin(a)
 b.ix=0.95
 b.iy=0.95
 b.dz=0
 b.state=1
 b.hit_cart=false
 courses[tee].score+=1
end

function hit_ball(b,dx,dy)
 b.dist=sqrt(dx*dx+dy*dy)
 b.odist=b.dist
 b.dx=dx/b.dist/2.5
 b.dy=dy/b.dist/2.5
 b.ix=1
 b.iy=1
 b.dz=b.dist/24
 b.state=1
 b.hit_cart = false
 
 b.orgx=b.x
 b.orgy=b.y
 
 courses[tee].score+=1
 
 if in_bunker then
  make_dust(b.x,b.y,b.dx/2,b.dy/2,1)
 end
end   
   
function draw_ball(e)

 if swing_state==0 and not pl.can_hit_ball then
  if ⧗%120<15 then
   circ(e.x,e.y,1,15)
  end
 end

 pset(e.x,e.y,dpal[pget(e.x,e.y)+1])
 pset(e.x,e.y-e.z,7)
 
-- print(e.dy,e.x,e.y-10,7)
-- print(e.iy,e.x,e.y-16,7)
end


----------------
-- characters

function make_player(x,y)
 return make_entity(x,y,{
	 type="character",
	 spr=16,
	 frames=0,
	 fs=6,
	 df=draw_character,
	 uf=update_character,
	 has_control=false
	})
end

function draw_character(e)
 draw_entity(e)
 
 local c=e.can_enter_cart
 local b=e.can_hit_ball
 if swing_state==0 then
	 if e.has_control and c and not c.nox and btnx_cooldown==0 then
   draw❎(c.x-4,c.y-13,7,13)
	 elseif e.has_control and b and btnx_cooldown==0 then
   draw❎(b.x-4,b.y-13,7,13)
	 end
	end
end

function update_character(e)
 if e.has_control and swing_state==0 then
	 if (btn(⬅️)) e.dx-=0.25
	 if (btn(➡️)) e.dx+=0.25
	 if (btn(⬆️)) e.dy-=0.25
	 if (btn(⬇️)) e.dy+=0.25
 end
 
 if not e.swimming then
  if (e.dx!=0 or e.dy!=0) and ⧗%16==0 then
   sfx(rnd()>0.5 and 61 or 42)
  end
 end
  
 if ssgn(e.dx)!=0 or ssgn(e.dy)!=0 then
  if e.dx!=0 then
   e.dir=ssgn(e.dx)
  end
  e.frames=4
 else
  e.frames=0
  e.frame=0
 end
 
 e.swimming=false
 if swing_state==0 then
	 if is_water(e.x,e.y) then
	  e.dx*=0.7
	  e.dy*=0.7
	  e.swimming=(mget(e.x/8,e.y/8)==68)
	 end
	  
	 if e.swimming then
	  if e.frames>2 then
 	  e.frames=2
	  end
	  if not e.was_swimming then
 	  e.spr=20
 	  e.fs=18
	   make_splash(e.x,e.y)
    sfx(56)
	  end
	  e.dx*=0.7
	  e.dy*=0.7
	  if rnd()>0.9 and (abs(e.dx)>0.01 or abs(e.dy)>0.01) then
	   local a=atan2(e.dx,e.dy)+0.15*(rnd()-0.5)
				make_swim_trail(e.x,e.y,a)
			end
	  
	  e.dx/=2
	  e.dy/=2
	 elseif e.was_swimming then
	  e.fs=6
	  e.spr=16
	  e.frames=4
	 end
 end
 e.was_swimming=e.swimming

 update_entity(e)
  
 if is_blocked(e.x,e.y) or not on_map(e) then
  e.x=e.ox
  e.y=e.oy
  e.dx,e.dy=0,0
 end

 -- check for carts
 e.can_enter_cart=nil
 e.can_hit_ball=nil
 
 if e.has_control then
  e.y+=1

  -- check carts
  for _,e2 in ipairs(carts) do
   local dx=abs(e.x-e2.x)
   local dy=abs(e.y-e2.y)
   if dx<10 and dy<10 then
	 	 local dist=distance(e,e2)
	 	 if dist<6 then
	 	  e.can_enter_cart=e2
		  end
	  end
	 end

  -- check ball
  if ball then
   if distance(e,ball)<4 then
    e.can_hit_ball=ball
	 	 e.can_enter_cart=nil
	  end
  end

	 e.y-=1
 end
 
 if btnpx() then
	 if e.can_enter_cart then
	  -- enter cart
	  e.has_control=false
	  e.can_enter_cart.nox=false
	  e.can_enter_cart.has_control=true
	  e.can_enter_cart.character=e
	  track(e.can_enter_cart,1)
	  del(entities,e)
	  del(dynamics,e)
 	 e.can_enter_cart.cprio=30
	  
	 elseif e.can_hit_ball and swing_state==0 then
	  -- hit ball
	  put_⧗=0
			courses[tee].started=true
   local dx=hole.x-e.can_hit_ball.x
   local dy=hole.y-e.can_hit_ball.y
   local a=atan2(dx,dy)+rnd(0.1)-0.05
   e.spr=32
   e.y=e.can_hit_ball.y
   e.rev_swing=hole.y>e.y
   if hole.x>e.x then
    e.x=e.can_hit_ball.x-2
    e.dir=1
   else
    e.x=e.can_hit_ball.x+3
    e.dir=-1
   end
   swing_state=1
   local dist=(rnd(0.2)+0.5)*min(80,distance(hole,e.can_hit_ball))
   reticule={
    max=0,
    r=0,adj=0,
    x=e.can_hit_ball.x,
    y=e.can_hit_ball.y,
    tx=e.can_hit_ball.x+dist*cos(a),
    ty=e.can_hit_ball.y+dist*sin(a)
   }
		 swing_a=-0.35
		 track(reticule)
	 end
	end
	
	-- push player into the tilemap
 if (e.x>=830) e.x-=0.25
 if (e.x<=2)   e.x+=0.25
 if (e.y>=254) e.y-=0.25
 if (e.y<=2)   e.y+=0.25
	
	
end


------------------
-- carts

function make_cart(x,y,a)
	return make_entity(x,y,{
	 type="cart",
	 a=a,ta=a,
	 is_cart=true,
	 s=0,
	 uf=update_cart,
	 df=draw_cart,
	 col=rnd({1,2,4,8,0}),
	 gcol=7,
	 trail_chance=0,
	 throttle_count=0
	})
end
	
function draw_cart(e)
 if e.x>camx-9 and e.x<camx+72 and 
    e.y>camy-9 and e.y<camy+72 then
	  
	 e.gcol=pget(e.x,e.y)
	 
	 pal(8,my_pal[e.col+1])
		-- draw stack
		for i=11+flr(e.sinking),15 do
		 local sx = 8 * (i%16)
		 local sy = 8 * flr(i/16)
		 rspr(sx,sy, e.x-4, e.y-i*1+6+flr(e.sinking),e.a, 1)
		end

	 pal(8,my_pal[9])
	 
	 if (debug) then
	  pset(e.x,e.y,7)
	  if e.sinking then
 	  print(e.sinking,e.x,e.y-8,7)
 --	  line(e.pusher.x,e.pusher.y,e.x,e.y,9)
 	  --e.pusher="bob"
	  end
	 end
	end
end

function update_cart(e)
 if e.hit_by_cart>0 then
  e.hit_by_cart-=1
 end

 local oa=e.a
 local throttle=false
 if e.has_control then
  if not e.sinking  then
	 	if btn(⬆️) or btn(🅾️) then
	 	 e.s+=0.03
	 	 e.throttle_count+=1
	 	end
	 	if btn(⬇️) then
	 	 e.s-=0.015
	 	 e.throttle_count+=1
	 	end
	 	if (btn(⬅️)) e.a-=0.008
	 	if (btn(➡️)) e.a+=0.008
  end
 	
 	if btnpx() then
 	 if e.character then
 	  -- leave cart
 	  leave_cart(e)
 	 end
 	end
 end
 
 e.x+=e.s*cos(e.a)
 e.y-=e.s*sin(e.a)
 
	e.s*=0.95
	if oa!=e.a then
	 e.s*=0.98
	end
	if e.s>0.1 and is_bunker(e.x,e.y-1) then
	 e.s*=0.9
	 e.a+=rnd(0.04)-0.02
	end
	local tile=mget(e.x/8,(e.y-1)/8)
	if tile==68 and not e.sinking then
	 e.sinking=0
	 e.s=0
-- 	if is_water(e.x,e.y-1) then
--	  e.s*=0.3
--	 end
	end
	local nx=e.x+3*cos(e.a)*ssgn(e.s)
	local ny=e.y-3*sin(e.a)*ssgn(e.s)
	if is_blocked(nx,ny) or not on_map(e) then
	 e.s=-e.s
	 if not e.character then
	  e.x=e.ox
	  e.y=e.oy
	 end
	end

 e.trail_chance*=0.9
 if e.s>0.1 and (oa!=e.a or e.character==nil) then
  e.trail_chance+=0.075
 end
	
 if e.gcol!=12 then
		if rnd()<e.trail_chance then
		 add(trails,{
		  x=e.x-2.5*cos(e.a+0.1),
		  y=e.y+2.5*sin(e.a+0.1)-1,
		  c=dpal[e.gcol+1],
		  life=399+rnd(99),
		 })
	 end
		if rnd()<e.trail_chance then
		 add(trails,{
		  x=e.x-2.5*cos(e.a-0.1),
		  y=e.y+2.5*sin(e.a-0.1)-1,
		  c=dpal[e.gcol+1],
		  life=399+rnd(99),
		 })
		end
	else --if rnd()<e.trail_chance then
  make_swim_trail(e.x,e.y,e.a-0.3+rnd(0.4))	
	end
 -- sound
 if e.throttle_count==1 then
  sfx(49,-2)
  sfx(51)
 elseif (not btn(⬆️) and not btn(⬇️) and not btn(🅾️)) and e.s<0.5 and e.throttle_count>1 then
  sfx(51,-2)
  sfx(49)
  e.throttle_count=0
 end
 
 if (not btn(⬆️) and not btn(⬇️) and not btn(🅾️)) then
  if e.throttle_count>0 then
   e.throttle_count-=1
  end
 end

 if e.sinking then
  e.sinking+=0.1
  if rnd()>0.9 then
   make_splash(e.x,e.y)
  end
  if (e.sinking==0.1) sfx(56)
  if e.sinking>5 then
   leave_cart(e)
   sfx(51,-2)
   sfx(49,-2)
   del(entities,e)
   del(dynamics,e)
   del(carts,e)
  end
 end
 e.ox=e.x
 e.oy=e.y

end

function leave_cart(e)
 if e.character then
  e.character.x=e.x
  e.character.y=e.y
  add(entities,e.character)
  add(dynamics, e.character)
  track(e.character,1)
  e.character.has_control=true
 end
 e.cprio=20
 e.has_control=false
 e.character=nil
end
-->8
-- particles

function make_splash(x,y)
	for i=1,8 do
		add(particles, {
		 x=x, y=y,
		 z=0, g=1,
		 dx=rnd(0.2)-0.1,
		 dy=rnd(0.1)-0.05,
		 dz=rnd(0.3)+0.6,
		 life=100,
		 col=7
		})
	end
end

function make_swim_trail(x,y,a)
	add(particles, {
				 x=x-cos(a), y=y-sin(a),
				 z=0,
				 g=0,
				 dx=-0.1*cos(a),
				 dy=-0.1*sin(a),
				 dz=0,
				 life=15+rnd(30),
				 col=7
				})
end


function make_sign_smash(x,y)
	for i=1,8 do
		add(particles, {
		 x=x, y=y,
		 z=0, g=1,
		 dx=rnd(0.4)-0.2,
		 dy=rnd(0.4)-0.2,
		 dz=rnd(0.5)+0.5,
		 life=100,
		 col=rnd() > 0.5 and 7 or 6
		})
	end
end

function make_dust(x,y,dx,dy,dz)
	for i=1,8 do
		add(particles, {
		 x=x, y=y,
		 z=0, g=1,
		 dx=rnd(0.2)-0.1+dx,
		 dy=rnd(0.1)-0.05+dy,
		 dz=rnd(0.3)+dz/2,
		 life=200,
		 col=rnd()>0.7 and 14 or 6
		})
	end
end

function update_particle(p)
 p.z+=p.dz
 p.dz-=0.05*p.g
 p.y+=p.dy
 p.x+=p.dx
 p.life-=1
 if p.z<0 or p.life<=0 then
  del(particles,p)
 end
end
-->8
-- helpers


function update_fade()
 for i=0,15 do
  local col,k=i,6*fade_progress
  for j=1,k do
   col=dpal[col+1]
  end
  pal(i,my_pal[col+1],1)
 end
end

function fadeout()
 while fade_progress<1 do
  fade_progress=min(fade_progress+0.1,1)
  update_fade()
  flip()
 end
 
 for i=0,4 do
  flip()
 end

end

function get_reticule_r()
 local dist=distance(reticule,ball)
 if dist>40 then
  dist+=2*(dist-40)
 end
 
 if ball.terrain=="sand" then
  dist+=40
 end
 
 return dist/8+4
end

function is_bunker(x,y)
 -- get tile
 local tile=mget(x/8,y/8)
 
 -- skip non-bunker tiles
 if (not fget(tile,6)) return false

 -- get pos in sprite mem
 local sx=8*(tile%16)
 local sy=8*(tile\16)
 
 -- check pixel
 local tx=flr(x)%8
 local ty=flr(y)%8
 local c=sget(sx+tx,sy+ty)

 return c!=0
end

function is_tree(x,y)
 -- get tile
 local tile=mget(x/8,y/8)
 
 -- skip non-tree tiles
 if (not fget(tile,0)) return false

 return true
end

function on_map(b)
 if b.x<=2 or b.y<=2 or b.x>=830 or b.y>=254 then
  return false
 end
 return true
end

function is_rough(x,y)
 -- get tile
 local tile=mget(x/8,y/8)
 
 -- skip non-bunker tiles
 if (not fget(tile,2)) return false

 -- get pos in sprite mem
 local sx=8*(tile%16)
 local sy=8*(tile\16)
 
 -- check pixel
 local tx=flr(x)%8
 local ty=flr(y)%8
 local c=sget(sx+tx,sy+ty)

 return c!=0
end

function is_blocked(x,y)
 -- get tile
 local tile=mget(x/8,y/8)
 
 -- skip non-blocked tiles
 if (not fget(tile,0)) return false

 -- get pos in sprite mem
 local sx=8*(tile%16)
 local sy=8*(tile\16)
 
 -- check pixel
 local tx=flr(x)%8
 local ty=flr(y)%8
 local c=sget(sx+tx,sy+ty)

 return c!=0
end


function is_water(x,y)
 -- get tile
 local tile=mget(x/8,y/8)
 
 -- skip non-water tiles
 if (not fget(tile,4)) return false

 -- get pos in sprite mem
 local sx=8*(tile%16)
 local sy=8*(tile\16)
 
 -- check pixel
 local tx=flr(x)%8
 local ty=flr(y)%8
 local c=sget(sx+tx,sy+ty)

 if c==12 or c==7 then
  return true
 end
 
 return false
end


function dcirc(x,y,r,c,step1,step2)
 step1=step1 or 0.05
 step2=step2 or 0.05
 local base=⧗/250
 local x1=r*cos(base)
 local y1=r*sin(base)
 local j=0
 local a=0
 while a<1 do
 	local x2=r*cos(a+base)
 	local y2=r*sin(a+base)
 	if j%2==0 then
  	line(x+x1,y+y1,x+x2,y+y2,c)
  	a+=step1
  else
   a+=step2
  end
 	x1=x2
 	y1=y2
  j+=1
 end
 
-- for a=0,1,step do
-- 	local x2=r*cos(a+base)
-- 	local y2=r*sin(a+base)
-- 	if j%2==0 then
--  	line(x+x1,y+y1,x+x2,y+y2,c)
--  end
-- 	x1=x2
-- 	y1=y2
-- 	j+=1
-- end
end

function btnpx()
 if btnx_cooldown==0 then
  if btnp(❎) then
   btnx_cooldown=16
   return true
  end
 end
 return false
end

function distance(a,b)
 local dx=abs(a.x-b.x)/10
 local dy=abs(a.y-b.y)/10
 return sqrt(dx*dx+dy*dy)*10	
end

function sort(a,p)
 for i=1,#a do
  local j = i
  while j > 1 and a[j-1][p] > a[j][p] do
   a[j],a[j-1] = a[j-1],a[j]
   j = j - 1
  end
 end
end

function add_params(src,dst)
 for k,v in pairs(src) do
  dst[k]=v
 end
end

function ssgn(x)
	if (x<0) return -1
	if (x>0) return 1
	return 0
end

-- sprite rotation by @fsouchu

-- rotate a sprite
-- col 0 is transparent
-- sx,sy - sprite sheet coords
-- x,y - screen coords
-- a - angle
-- w - width in tiles
function rspr(sx,sy,x,y,a,w)
 local ca,sa=cos(a),sin(a)
 local srcx,srcy
 local ddx0,ddy0=ca,sa
 local mask=shl(0xfff8,(w-1))
 w*=4
 ca*=w-0.5
 sa*=w-0.5
 local dx0,dy0=sa-ca+w,-ca-sa+w
 w=2*w-1
 for ix=0,w do
  srcx,srcy=dx0,dy0
  for iy=0,w do
   if band(bor(srcx,srcy),mask)==0 then
    local c=sget(sx+srcx,sy+srcy)
				-- set transparent color here
    if (c!=0) pset(x+ix,y+iy,c)
   end
   srcx-=ddy0
   srcy+=ddx0
  end
  dx0+=ddx0
  dy0+=ddy0
 end
end


-->8
-- ui


function draw_arrow(e)
 spr(51+(⧗\8)%4,e.x-3,e.y-12+2*sin(t()))
end

function draw_bubble(txt,x,y)
 local yy=y+184-camy
 rectfill(x-1,yy,x+57,yy+18,1)
 rectfill(x,yy-1,x+56,yy+19,1)
 rectfill(x,yy,x+56,yy+18,7)
 spr(46,x+158-camx,yy-4)
 print(txt,x+1,yy+1,1)
 draw❎(x+49,yy+16,6,1)
end


function set_ticker(str)
 ticker={
  str=str,
  x=64,
  y=-8,
  life=4 * #str + 64
 }
end

function update_ticker()
 
end

function draw_score_card(x,y)
 rectfill(x,y,x+57,y+24,13)
 rectfill(x,y,x+57,y+23,7)
 spr(74,x+1,y+1,2,1)
 spr(76,x+1,y+20,2,1)
 spr(78,x+46,y+20,2,1)
 local sum=0
 for i=1,9 do
  rectfill(x-4+i*5,y+5,x+i*5,y+11,i%2==1 and 15 or 7)
  print(i,x-3+i*5,y+6,14)
  rectfill(x-4+i*5,y+12,x+i*5,y+18,i%2==1 and 6 or 7)
--  if courses[i].score>0 or i==tee then
  if courses[i].score>0 then
   if i<tee or ⧗%30>15 then
    local col=1
    if (courses[i].score<courses[i].par) col=5
    if (courses[i].score>courses[i].par) col=2
    print(courses[i].score,x-3+i*5,y+13,col)   
   end
  end
  sum+=courses[i].score
 end
 local len=#(""..sum)*4
 print(sum,x+58-len,y+13,1)
 total_result=sum
 
 draw❎(x+50,y,6,13)
end

function draw❎(x,y,c1,c2)
 print("❎",x,y,c2)
 print("x",x+2,y,c2)
 print("❎",x,y-(⧗%60>20 and 1 or 0),c1)
end



function draw_reticule(x,y,r,c)
 dcirc(x,y+1,r,1)
 dcirc(x,y,  r,c)
-- pset(x,y+1,1)
-- pset(x,y+1,1)
 pset(x,y,7)
end

function draw_putt_ui(x,y)
	local d=distance(hole,ball)/2
	local r=d/10 --7

 -- bar
	spr(58,x,y,5,1)
	spr(63,x+1+r*30,y+1)

	-- marker
	local dy=-4
	if (r*30>16) dy=-5
	if (r*30>27) dy=-6
	spr(47,x+1+r*30,y+dy)
	
	-- x
	if swing_state==1 then
 	draw❎(x+38,y+2,7,5)
	end
	
	-- ball
	local r=1-abs(cos(put_⧗/120))
	if swing_state==2 then
	 r=ball.power
	end
	local id=56
	if swing_state==2 and ⧗%16>7 then
	 id=57
	end
	spr(id,x+33*r-1,y+1)
	
	return r
end

function draw_done(x,y)
 local ltrs={9,10,24,24,64,29,23,28,10}
 local i=0
 for l in all(ltrs) do
  spr(ltrs[i+1],x+i*9,y)
  if ltrs[i+1]==64 then
   x-=45 -- 9*5
   y+=10
  end
  i+=1
 end
end

function draw_logo(x,y)
 for i=0,3 do
  spr(22+i,x+i*9,y)
 end
 for i=0,5 do
  spr(26+i,x-9+i*9,y+10)
 end
end

function draw_title()
 pal(7,5)
 draw_logo(14,13)
 pal(7,7)
 draw_logo(14,12)
 
 draw❎(28,40,7,5)
 
 local ticker="CREATED BY @jOHANpEITZ     MUSIC & SFX BY @gRUBER_mUSIC  "
 local tx=64-(⧗%((#ticker*4+64)*4))/4
 print(ticker,tx,58,5)
 print(ticker,tx,57,7)
 
 if btn(🅾️) then
  print("V"..version,1,2,5)
  print("V"..version,1,1,7)
 end
end