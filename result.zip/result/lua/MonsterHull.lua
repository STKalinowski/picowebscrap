-- monster hull
-- by william anderson
-- code + art: 
--    william anderson
--    twitter: @thewaanderson
-- music and sfx:
-- 			brendan byrne
--    twitter: @bigwetdognose

function set_globals()
 -- title screen
 titley = 24
 titled = true
 tstars = {}
 transition = 0

	-- global groups
 actors = {}
 bullets = {}
 stars = {}
 flares = {}
 mons = {}

 -- time
 met = 0
 met_c = 0
 met_inc = 10
 tur_c = 0
 tur_i = 0
 met_freeze = false

 -- global objects
 pl = {}

 -- screen
 screenr = true
 screenx = 0
 screenc = 0
 is_shake = false
 left_ui = 128-52
 score = 0
 state = "title"
 flash_mon = false
 lva = 40 -- level up animation
 lvac = 40
 lvai = 0
 lvat = ""

 -- consts
 bnds = {}
 bnds.l = -7
 bnds.r = 79
 bnds.b = 1
 bnds.w = bnds.r - 4
 edge = bnds.w-11

 -- ship stats
 ship = {}
 ship.forms = {"base", "heart"}
 ship.unlocks = {"star","diamond","comet"}
 ships = {}
 ship.form = 1

 -- enemy units
 en = {}
 fire = {}
 queue = {}
 hitmarks = {}
 diff = 1

 -- ng+
 ng = 0

 -- game over
 go = {}
 go.x = -60
 go.y = 60
 go.sx = -8
 go.color = 7
 go_confirm = false

 set_soundmap()
end

function set_soundmap()
	snds = {}
	snds.pshoot = 1
 snds.eshoot = 2
 snds.cannon = 13
 snds.laser = 8
 snds.hit = 3
 snds.phit = 6
 snds.death = 7
 snds.kill = 4
 snds.confirm = 3
 snds.drop = 12
 snds.capture = 15
 snds.levelup = 11
 snds.absorb = 0--5
 snds.switch = 0
 snds.bossd = 14
 snds.burst = 13
 snds.shield = 10
 snds.start = 9
end

function psfx(key)
	if snds[key] then
		local snd = snds[key]
		if snd > -1 then
			sfx(snd)
		end
	end
end

function _init()
 delay = 0
 set_globals()
 create_ships()
 create_pl()
 create_stars()
 create_armada()
 create_tstars()
 music(-1)
end

function _update()
 ctrl_in()

 if state == "title" then
  update_title()
  foreach(tstars,update_tstar)
  update_trans()
 end
 if state != "title" then
		update_play()
	end
end

function update_play()
 shake()
 check_damages()
 foreach(hitmarks, update_hitmark)
 if pl.active then
 	update_met()
 	adj_pl()
 	foreach(mons,update_mon)

 	if tur_c == 1 then
 		fire_turrets()
 		tur_c = 0
 	end

 	if count(queue) == 0 and count(en) == 0 then
 	 create_armada()
 	 met = 0
 		met_c = 0
 	 ng += 1
 	 music(4)
 	elseif count(en) == 0 and met_freeze then
 	 met_freeze = false
 	else
 	 foreach(queue,check_queue)
 	end
 end
	update_bullets()
	foreach(flares, update_flare)
	foreach(fire, update_fire)
	update_stars()
	foreach(en,step_en)
	update_lva()

	if state == "gameover" then
	 update_go()
	end
end

function _draw()
 cls()
 if state == "title" then
  draw_title()
  if transition == 0 then
  	foreach(tstars,draw_actor)
  end
 else
  draw_game()
 end
end

function draw_game()
 if is_shake and screenx == 1 then
  rectfill(0,0,85,128,8)
 end
 camera(screenx,0)
 draw_stars()
	draw_pl()
	foreach(en,draw_en)
	draw_bullets()
	draw_fire()
	foreach(flares, draw_flare)
	foreach(hitmarks, draw_hitmark)

	pal(11,pl.color)
	palt(0,false)
	map(0,0, 0,0, 16,16)
	pal() palt()
	draw_interface()
	if pl.active then
		foreach(mons,draw_actor)
	end

	draw_lva()

	if state == "gameover" then
	 draw_go()
	end
end


function update_hitmark(sh)
	if sh.r > 0 then
		sh.w += 1
	else
		sh.w -= 1
	end
end

function draw_hitmark(sh)
	local colk = sh.r + 2
	local cols = {7,0,9,8}
	local x = sh.x - 3

	if sh.r > 0 then
		circfill(sh.x,sh.y,sh.w*.75,cols[colk])
	else
		circ(sh.x,sh.y,sh.w,cols[colk])
	end

	if sh.w <= 0 then del(hitmarks,sh) end
	if sh.r > 0 and sh.w > 2 then
		del(hitmarks,sh)
	end
end

function add_hitmark(bul,en,r)
	local sh = {}
	sh.x = bul.x
	sh.y = bul.y -- en.y + en.h*8
	sh.w = 0
	if r < 0 then sh.w = 3 end
	sh.r = r
	add(hitmarks,sh)
end

function update_title()
 update_logo()
 update_stars()
end

function lva_anim(icn,t)
	lva = 0
	lvac = 0
	lvai=icn
	lvat=t
end

function update_lva()
	lvac += 1

	if lvac < 40 then
		lva += 1
	end
end

function draw_lva()
	local lva_ys = {12,8,9,10,14,12}
	local lva_xs = {-4,0,4,7,10,12}
	local lva_sp = {1,.5,.7,1.25,1,.75}
	local txt = lvat.." up!!"
	local txtl = (edge-(#txt-2)*4)/2
	--lva_ys = {-3,0,4,7,10,14,15,16,18}
	for i=1,count(lva_xs),1 do
		local y = pl.y+(lva_ys[i]+4)-lva*lva_sp[i]
		if y > pl.y - 5 then
			pal(11,pl.color)
			spr(105,pl.x+lva_xs[i],y)
			palt()

			spr(lvai,txtl-6,28)
			print(txt,txtl+6,30)
		end
	end
end

function fire_turrets()
 local turx = {-5,20}

	if pl.tur > 0 then
		psfx('pshoot')
  for i=1,pl.tur,1 do
  	local b = make_actor(0,pl.x+turx[i],pl.y+3,1,2)
	 	b.drift = 0
	 	b.sp = 5
	 	b.color = pl.color
	 	b.turret = true
	 	pl.xtraammo += 1
	 	add(bullets,b)
  end
 end
end

function create_tstars()
 local tsx = {40,65,80}
 local tsy = {30,55,45}
 local ssp = {0,2,3}
 local bdel = {2,15,8}
 for i=1,count(tsx),1 do
  local s = {}
  s.x = tsx[i]
  s.y = tsy[i]
  s.w = 1
  s.h = 1
  s.bdel = bdel[i]
  s.cnt = 0
  s.sprite = 136 + ssp[i]
  s.sspr = 136
  s.sprm = 140

  add(tstars,s)
 end
end

function update_tstar(s)
 if s.bdel > 0 then
  s.bdel -= 1
  s.sprite = 135
 else
  s.cnt += 1
  if s.sprite == 135 then
   s.sprite = s.sspr
  end
  if s.cnt == 3 then

   if s.spd then
    s.sprite -=1
   else
    s.sprite +=1
   end

   if s.sprite == s.sprm
   or s.sprite == s.sspr then
    s.spd = not s.spd
   end

   if s.sprite == s.sspr then
    s.bdel = 15
   end

   s.cnt = 0
  end
 end
end


function draw_title()
 foreach(stars,draw_title_star)
 spr(128,65-32,titley,8,6)
 print("press z+x to play",30,100,12)

 print("code+art @thewaanderson",19,128-20,1)
 print("music @bigwetdognose",25,128-14,1)

 print("(c)2016 william anderson",16,128-5,1)
 if transition > 0 then
  draw_trans()
 end
end

function update_trans()
 if transition > 0 and transition < 20 then
  transition += 1
 else
  if transition == 20 then
   state = "play"
  end
 end

end

function draw_trans()
 palt(0,false)

 if transition > 15 then
  rectfill(0,0,128,128,0)
 else
  tfr = flr(transition/3)

  palt(11,true)
  for i=1,4,1 do
   map(16+(tfr*4),0, (i-1)*4*8,0, 4,16)
  end
 end
 palt()
end

function update_logo()
	if titled then
  titley += .1
 else
  titley -= .1
 end
 if titley >= 28 or titley <= 24 then
  titled = not titled
 end
end
function draw_title_star(s)
	local x = s.x*1.75
 rectfill(x,s.y,x+s.w-1,s.y+s.h-1,s.color)
end

function draw_interface()
 draw_st()

 -- draws ships
	for i=1,count(ship.forms),1 do
 	foreach(ships,
  function (s)
   if s.model == ship.forms[i] then
    draw_ship_stats(s,i,i==count(ship.forms))
   end
  end)
 end

 if ng > 0 then
  print("ng+",1,1,7)
  if ng > 1 then print(ng,13,1,7) end
 end
end

function draw_st()
 local y = 13

 print("ship stats",left_ui+4,4,13)

 spr(102,left_ui,y-1)
 local hpc = 8
 if pl.hp == 2 then hpc = 9 end
 if pl.hp > 2 then hpc = 11 end
 for i=1,pl.maxhp,1 do
  local color = 5
  if i<= pl.hp then color = hpc end
  circ(left_ui+(i*4)+7,y,1,color)
 end

 spr(118,left_ui,y+5)
 for i=1,pl.powt,1 do
 	circ(left_ui+(i*4)+7,y+6,1,7)
 end

 spr(103,left_ui,y+11)
 for i=1,pl.blastt,1 do
 	circ(left_ui+(i*4)+7,y+12,1,7)
 end

 for i=0,pl.shield-1,1 do
  local lb = left_ui+(i*4)
  rectfill(lb,y+17,lb+2,y+19,12)
 end

 spr(119,left_ui+24,y+17,2,1)
 spr(121+pl.icn,left_ui+39,25)
end

function draw_ship_stats(s,i,l)
  local y = (i-1)*18 + 40
  local lper = s.percent_xp()

 	if flash_mon and l then
 	 rectfill(left_ui-2,y-2,left_ui+48,y+11,7)
 	 flash_mon = false
 	end

 	if s.active then
 		rectfill(left_ui-2,y-2,left_ui+48,y+11,1)
 	end

 	--name+icon
 	spr(67+(s.icn*2), left_ui,y-1, 2,2)
 	print(s.name,left_ui+14,y,7)

 	-- lv + xp
 	if lper != 0 then
 	 local bw = (lper*19)
 	 if bw > 19 then bw = 19 end
 	 if s.lv == s.mlv then bw = 19 end
 	 rectfill(left_ui+25,y+7,
 	 	left_ui+25+bw,y+9,s.color)
 	end
 	rect(left_ui+24,y+6,left_ui+45,y+10,6)
 	spr(113,left_ui+14,y+6)
 	local lv = s.lv
 	if lv == s.mlv then lv = "m" end
 	print(lv,left_ui+20,y+6)

 	-- indicator
 	if s.active then
 	 spr(114,left_ui-9,y+1)
 	 spr(114,left_ui+48,y+1,1,1,true)
 	end
end

-- updates metronome
function update_met()
 if not met_freeze then
  met_c += 1
 end

 tur_i += 1

 if met_c == met_inc then
 	met += 1
 	met_c = 0
 end

 if tur_i == met_inc then
 	tur_c += 1
 	tur_i = 0
	end
end

-- handles controller inputs
function ctrl_in()
 if state == "title" and transition == 0 then
  if btn(4) and btn(5) then
   transition = 1
   psfx('confirm')
   music(3)
  end
 end

	if pl.active and state != "title" then
 	-- z
 	if btnp(4) then pl.shoot() end

 	-- x
 	if btnp(5) then switch_ship() end

 	-- left/right
		if btn(0) then pl.x -= pl.sp end
 	if btn(1) then pl.x += pl.sp end
	end

	if go.x == 17 and btnp(4) then
	 go_confirm = true
	 psfx('confirm')
	end
end

-- shakes screen

function shake()
 if is_shake then
 	if screenr then
  	screenx += 1
  	if screenx > 2 then screenr = false end
 	else
  	screenx -= 1
  	if screenx < -2 then screenr = false end
 	end

 	if screenx < -2 then
  	screenx = 0
  	screenr = true
  	is_shake = false
 	end
 end
end

-- adjusts player position
function adj_pl()
	if pl.x < bnds.l then
	 pl.x = bnds.l
	end

	if pl.x > bnds.r - 16 then
	 pl.x = bnds.r - 16
	end

	pl.refill_hp()
end

-- creates all gameplay
function create_armada()
 w1(0+delay) --0
 w2(20+delay)--30
 w3(45+delay)--55
 w4(80+delay)--90
	w5(140+delay)--150
	boss(190+delay)--200
end

function train()
	met_freeze = true


	for i=0,18,1 do
		local e = make_enemy(9,1,1,1,1)
		e.hp = 1
		e.xp = 100
		e.drops = true
		e.move = function() end
		e.fire = function() end
		add(en,e)
	end

end

function boss(t)
 q_e("boss",0+t,true)
end


function w5(t)
	q_e("mant",0+t,false,0)
	q_e("mant",0+t,false,edge-8)

 for i=1,3,2 do
 	q_e("pwog",2+t,false,(((edge+16)/5)*i),0)
 end

 q_e("horse",6+t)
 q_e("hor-r",6+t)
 q_e("mant",8+t,false,(edge-8)/2)

	w2(16+t,true)
	w1(16+t,true)
end

function w4(t)
	q_e("snap",0+t,false)
	q_e("snap",5+t,true)

	q_e("beet",6+t,false,1,16)
	q_e("beet",6+t,false,-1,16)
	q_e("pwog",6+t,true,edge/2,0)

	q_e("pwog",13+t,false,0,20)
	q_e("pwog",13+t,false,edge,20)

	local mantc = 3
	for i=0,mantc-1,1 do
		q_e("mant",13+i*5+t,false,i*(edge+8)/mantc)
	end

	q_e("beet",22+t,false,1,32)
	q_e("beet",22+t,false,-1,32)
	q_e("pwog",29+t,false,0,50)
	q_e("pwog",29+t,true,edge,50)

	for i=1,3,2 do
 	q_e("pwog",30+t,false,(((bnds.w+8)/5)*i),0)
 end

 for i=0,4,2 do
 	q_e("tad",i*2+t+30)
 	q_e("tad-i",i*2+t+30)
 end
 q_e("tad",t+39,true)

 q_e("tort",40+t,false,0)
 q_e("tort-d",40+t,false,edge-8)
 q_e("pede",40+t,false)
 q_e("pede",50+t,false)
 q_e("pede",55+t,true)
end

function w3(t)
 q_e("horse",2+t)
 q_e("hor-r",2+t)
 q_e("snap",2+t,false)
 q_e("pwog",1+t,false,0,40)
	q_e("pwog",1+t,false,edge,40)

 for i=2,6,1 do
 	q_e("tad",15+i+t)
 end

 q_e("tad",22+t,true)

 q_e("tort",31+t,true,0)
 q_e("tort",31+t,false,edge-8)
end

function w2(t,skip)
	for i=0,4,2 do
 	q_e("tad",i*2+t)
 	q_e("tad-i",i*2+t)
 end

	for i=1,5,2 do
	 local f = false
	 if i==5 then f=true end
 	q_e("pwog",12+i+t,f,(bnds.w/5)*(i-1),0)
 end
 q_e("pede",12+t,false)

 for i=1,3,2 do
 	q_e("pwog",10+t,false,((bnds.w/5)*i),0)
 end

 q_e("beet",20+t,false,1,16)
	q_e("beet",20+t,false,-1,16)
	q_e("snap",20+t,true)

	local boss = "tort-d"

	q_e(boss,21+t,false,(edge/2)-4)
	q_e("pwog",23+t,false,16,40)
	q_e("pwog",23+t,true,edge-16,40)
end

function w1(t)
	q_e("tad",1+t,true)
 for i=2,6,1 do
 	q_e("tad",i+t)
 end
 q_e("tad",7+t,true)
 for i=1,6,2 do
 	local freeze = false
 	if i==5 then freeze = true end
 	q_e("pwog",7+i+t,freeze,(bnds.w/5)*(i-1),(5*i))
 end

	q_e("tort",14+t,true,(edge/2)-4)
end

-- queues an enemy for play
function q_e(t,d,f,x,y)
 local qe = {}
 qe.type = t
 qe.delay = d
 qe.freeze = f
 qe.x = x
 qe.y = y

 add(queue,qe)
end

-- checks enemy queue
function check_queue(qe)
 -- adds enemy for queue
 if qe.delay == met then
  add_enemy_unit(qe)
  if qe.freeze then
  	met_freeze = true
  end
  del(queue,qe)
 end
end

-- creates an enemy unit
function add_enemy_unit(u)
	local e = {}

	local t = u.type

	if t == "boss" then
		e = make_boss()
		pl.rec = pl.maxhp - pl.hp
		music(25)
	end

 if t == "tad" then
  e = make_tp()
 elseif t=="tad-i" then
  e = make_tp(true)
 end

 if t == "pede" then
  e = make_cp()
 end

 if t == "pwog" then
  e = make_pw(u.x,u.y)
 end

 if t == "tort" then
  e = make_to(false,u.x)
 end

 if t == "horse" then
  e = make_sh(1)
 elseif t == "hor-r" then
 	e = make_sh(-1)
 end

 if t == "snap" then
  e = make_snap()
 end

 if t == "mant" then
  e = make_mant(u.x)
 end

 if t == "beet" then
  e = make_beet(u.x,u.y)
 end

 if t == "tort-d" then
  e = make_to(true,u.x)
 end

 add(en,e)
end

-- game boss
function make_boss()
 local e = make_enemy(200,4,-32,4,4,true)

 e.ymax = 0
 e.sp = .4
 e.hp = 1250 + (ng*100)
 e.mhp = e.hp
 e.xp = 200 + ng*20
 e.color = 8
 e.boss = true
 e.weak=7

 e.can = 1
 e.cand = {-1.5,-.5,0,.5,1.5}
 e.altbur = true

 e.burctr = 0
 e.lctr = 0
 e.llap = 6
 e.lfir = 1
 e.lazs = {e.llap,e.llap}

 e.shs = 2 -- sea horses
 e.hshs = false
 --
 e.phase = 0
 e.f1rythm = 1
 e.f2rythm = 0

 e.flame = true
 e.f1 = 9
 e.f2 = 8
 e.f3 = 8

 e.move = function()
  if e.y<e.ymax then
 		e.y += e.sp
 	else
  	e.lazers()
 	end
 end

 e.drop = function()
  if ng == 0 then
			local d = ship.unlocks[1]
			del(ship.unlocks,d)
			drop_mon(d,e)
		end
 end

 e.next_can = function()
  e.can += 1
  if e.can > 5 then e.can = 1 end
 end

 e.fire = function()

  -- tortoiuse cannon
 	if e.y >= e.ymax then
 	 local per = (e.hp/e.mhp) - .001
 		e.phase_atk(5 - flr(per*6))
		end

		e.phase_atk = function(p)
		 if p == 0 then
		 	e.phase0()
		 elseif p == 1 then
		  e.phase1()
		 elseif p == 2 then
		  e.phase2()
		 elseif p == 3 then
		  e.phase3()
		 elseif p == 4 then
		  e.phase4()
		 elseif p == 5 then
		  e.phase5()
		 end
		end

		e.phase5 = function()
			e.to_can(1)
			e.to_can(2)
			e.next_can()
			if e.lctr == 0 then
 		 e.f_laz(1)
 		 e.f_laz(2)
 		end
		end

		e.phase4 = function()
			if e.burctr == 0 then
 			e.phase0()
 		end
			e.to_can(1)
			e.to_can(2)
			e.next_can()
		end

		e.phase3 = function()
			if e.burctr == 0
			or e.burctr == 2 then
 			e.burst()
 		end
 		e.to_can(1)
 		e.next_can()
		end

		e.phase1 = function()
			e.phase0()
			if e.f1rythm == 1 then
				e.burst()
			end
		end

		e.phase2 = function()
			e.phase0()
			if e.hshs == false then
				e.shs = 0
				e.hshs = true
			end
		end

		e.phase0 = function()
			e.f1rythm += 1

			e.tur(e.f1rythm)

			if e.f1rythm == 4 then e.f1rythm = 0 end
		end


		if e.shs == 0 then
 		e.callsh()
 	end

 	e.ctr = 0
 	e.cntrs()
 end

 e.tur = function(t)
 	e.tursx = {2,24,39,61}
 	e.tursy = {26,16,16,26}
 	psfx('eshoot')

 	local b = make_actor(0,e.x+e.tursx[t],e.y+e.tursy[t],1,1)
		b.sp = e.sp + 2
 	b.color = 12
 	add(fire,b)
 end

 e.callsh = function()
 	local sh1 = make_sh(-1)
 	local sh2 = make_sh(1)
 	sh1.y = 40
 	sh2.y = 40
 	sh1.hp = 30
 	sh2.hp = 30
 	add(en,sh1)
 	add(en,sh2)
 	e.shs += 2
	end

 e.f_laz = function(l)
 	e.lazs[l] = 0
 	psfx('laser')
 end

 e.lazers = function()
 	e.lazer(1)
  e.lazer(2)
 end

 e.lazer = function(l)
 	if e.lazs[l] < e.llap then
 		e.lazs[l] += 1
  	local xs = {e.x+23,e.x+40}
 		local b = make_actor(0,xs[l],e.y+26,2,1)
			b.sp = e.sp + 3
 		b.color = 7
 		b.drift = d
 		add(fire,b)
 	end
 end

 e.cntrs = function()
 	e.burctr += 1
 	if e.burctr == 3 then
 		e.burctr = 0
 	end

 	e.lctr += 1
 	if e.lctr == e.llap then
 	 e.lctr = 0
 	end
 end

 e.burst = function()
 	psfx('burst')
 	e.altbur = not e.altbur
 	e.burdri = {-1.25,-.25,.25,1.25}
 	if e.altbur then
 		e.burdri = {-.75,0,0,.75}
 	end

 	foreach(e.burdri, function(d)
 		local b = make_actor(0,e.x+32,e.y+32,1,1)
			b.sp = e.sp + 2
 		b.color = 10
 		b.drift = d
 		add(fire,b)
 	end)
 end

 e.to_can = function(wc)
 	psfx('cannon')
 	e.canx = {6,11,13,16,22}
 	e.cany = {30,32,27,32,30}
 	if wc == 2 then
 		for i=1,count(e.canx),1 do
 			e.canx[i] = e.canx[i] + 38
 		end
 	end

 	local b = make_actor(0,e.x+e.canx[e.can],e.y+e.cany[e.can],2,1)
		b.sp = e.sp + 2
 	b.color = 11
 	b.drift = e.cand[e.can]
 	add(fire,b)
 end

 return e
end

-- makes a pollywog
function make_pw(x,y)
 local e = make_enemy(53,x,-8,1,1)

 e.fire_rate = 50
 e.hp = 6 + (ng*2)
 e.xp = 3 + ng*2
 e.color = 10
 e.weak = 7
 e.sp = .5
 e.my = y
 e.res = 10

 e.move = function()
  if e.y < e.my then
 		e.y += e.sp
 	end
 end

 e.fire = function()
 	local b = make_actor(0,e.x+e.fire_x,e.y+e.fire_y,2,1)
		b.sp = (e.sp + 1) * (e.sp + 1)
 	b.color = e.color
 	add(fire,b)
 	psfx('cannon')

 	e.y -= 1
 	e.ctr = 0
 end

 return e
end

-- makes a beetle turret
function make_beet(d,y)
	local x = 0
	if d == -1 then x = bnds.w end
 local e = make_enemy(52,x+(-8*d),y,1,1)

 e.fire_rate = 30
 e.hp = 2 + (ng*2)
 e.xp = 1 + ng*2
 e.color = 10
 e.weak = 10
 e.dir = d
 e.sp = .2

 if d == -1 then e.flip = true end


 e.move = function()
  if e.dir == 1 and e.x<0
  or e.dir == -1 and e.x>bnds.w-11 then
 	 e.x += e.dir
 	end

 	e.y += e.sp
 end

 e.fire = function()
  local fx = e.x+8
  if e.dir == -1 then fx = e.x end
 	local b = make_actor(0,fx,e.y+8,1,1)
		b.sp = e.sp + 2
 	b.color = e.color
 	b.drift = 1.1 * e.dir
  add(fire,b)
  psfx('eshoot')

  e.ctr = 0
 end

 return e
end

-- makes a seashorse
function make_sh(d)
	local x = -16
	local y = 1
	if d == -1 then x = bnds.w-3 end
 local e = make_enemy(6,x,1,2,2)

 e.fire_rate = 100
 e.hp = 60 + (ng*2)
 e.xp = 1 + ng*2
 e.color = 10
 e.weak = 10
 e.dir = d
 e.cl = false
 if d == -1 then e.flip = true end


 e.move = function()
  if d == 1 then
 	 if e.x < -3 then
  	 e.x += .25
  	else e.cl = true
   end
  else
  	if e.x > bnds.w-16 then
  	 e.x -= .25
  	else e.cl = true
   end
  end
 end

 e.fire = function()
  if e.cl then
 	 local bsh = make_bsh(e)
 	 add(en,bsh)
 	end
 	e.ctr = 0
 end

 return e
end

-- make a baby seahorse
function make_bsh(l)
 local hbx = 0
 if l.dir == 1 then hbx = 9 end
 local e = make_enemy(39,l.x+hbx,l.y+4,1,1)

 e.fire_rate = 40
 e.hp = 1
 e.xp = 1
 e.color = 10
 e.weak = 4
 e.dir = l.dir
 e.sp = .2

 e.move = function()
		e.x += e.dir
		e.y += .2

		if e.x <= 0 then e.dir = 1 end
		if e.x >= bnds.w-10 then e.dir = -1 end
	end

	return e
end

-- makes a centipede
function make_cp()
	local x = -24
	local y = 1
 local e = make_enemy(36,x,1,3,1,false)

 e.fire_rate = 28
 e.hp = 22 + (ng*2)
 e.xp = 8 + ng*2
 e.color = 10
 e.weak = 7
 e.flip = false
 e.sp = 2 + (ng-1)
 if e.sp > 3 then e.sp = 3 end
 e.res = 14

 e.move = function()
  if e.flip then
 		e.x -= e.sp
 		if e.x < -36 then
 		 e.flip = false
 		 e.y += 16
 		end
 	else
 		e.x += e.sp
 		if e.x > bnds.w + 12 then
 			e.flip = true
 			e.y += 16
 		end
 	end
 end

 e.fire = function()
 end

 return e
end

-- makes a tortoise unit
function make_to(dd,x)
 local e = make_enemy(34,x,-16,1,2,true)

 e.ymax = 30
 e.sp = .4
 e.hp = 28 * (ng+1) * (count(ship.forms))
 e.xp = 6 + ng
 e.color = 8
 e.res = 14
 e.weak = 12

 e.can = 1
 e.canx = {0,5,8,10,16}
 e.cany = {11,13,11,13,11}
 e.cand = {-.75,-.25,0,.25,.75}
 e.recoil = 0

 e.flame = true
 e.f1 = 9
 e.f2 = 8
 e.f3 = 12

 e.drops = dd

 e.move = function()
  if e.y<e.ymax then
 		e.y += e.sp
 	elseif e.recoil == 2 then
 	 e.y -= 4
 	 e.recoil = 1
 	end
 end

 e.next_can = function()
  e.can += 1
  if e.can > 5 then e.can = 1 end
 end

 e.fire = function()
  if e.recoil == 1 then
   e.y += 2
   e.recoil = 0
  end

 	if e.y >= e.ymax then
 		local b = make_actor(0,e.x+e.canx[e.can],e.y+e.cany[e.can],2,1)
			b.sp = e.sp + 2
 		b.color = e.color
 		b.drift = e.cand[e.can]
 	 add(fire,b)

 	 e.recoil = 2
 	 e.next_can()
 	 psfx('cannon')
		end

 		e.ctr = 0
 end

 return e
end

-- drop down low, drop bombs, exit
function make_mant(x)
	local e = make_enemy(49,x,-8,1,1,true)

 e.sp = .8
 e.fire_rate = 2
 e.hp = 24.0 * (count(ship.forms)/2)
 e.xp = 8 + ng*3
 e.ey = 128 - 55
 e.can_m = true
 e.shots = 0
 e.maxs = 20
 e.color = 7
 e.ret = false
 e.weak = 14

 e.move = function()
 	local ease = (e.ey-e.y)/10
 	if ease > 4 then ease = 4 end
		if ease < .5 then ease = .5 end

  if e.ret then
  	if e.y > -8 then
  	 e.y -= ease
  	else
  	 e.y = 200
  	end
  end

  if e.can_m then
 		if e.y < e.ey - 1 then
  		e.y += ease
 		else
  		e.y = e.ey
  		e.can_m = false
 		end
 	end
 end

 e.fire = function()

 	if not e.can_m and e.shots < e.maxs then
 	 e.shoot()
 	 e.shots += 1
 	 psfx('laser')
 	end

 	if e.shots == e.maxs then
 		e.ret = true
 	end

 	e.ctr = 0
 end

 e.shoot = function()
 	local b = make_actor(
			0,
			e.x+7,
			e.y+12,
			4,
			4)
		b.sp = (e.sp + 1) * (e.sp + 1)
 	b.color = e.color
 	add(fire,b)
 end

 return e
end

-- makes a snapper unit
function make_snap()
 local e = make_enemy(35,1,1,1,2)

 e.curve = .2
 e.sp = .8
 e.fire_y = 16
 e.fire_rate = 20
 e.hp = 10 + (ng*2)
 e.xp = 5 + ng
 e.color = 9
 e.weak = 10
 e.dir = 1

 e.can = 1
 e.cans = {}
 e.cansd = {}
 e.cans[0] = {0,4}
 e.cans[1] = {8,5}
 e.cansd[0] = {-.75,-.65}
 e.cansd[1] = {.75,.65}
 e.can_s = 0

 e.move = function()
 	e.curve -= .009
  if e.curve > 360 then e.curve = 0 end
  e.y = sin(e.curve) * bnds.w/3 + bnds.w/2 - 8
  e.x = cos(e.curve) * bnds.w/3 + bnds.w/2 - 8

 	e.can_s += 1
 	if e.can_s == 10 then
 	 e.can += 1
 	 if e.can > count(e.cans[0]) then
 	  e.can = 1
 	 end

 	 e.can_s = 0
  end
  if e.x < 1 then
  	e.x = 1
  	e.dir = 1
  end
 	if e.x > bnds.r - 16 then
 		e.x = bnds.r - 16
 		e.dir = -1
 	end
 end

 return e
end

-- makes a tadpole unit
function make_tp(inv)
	local x = 1
	local y = 1
	if inv then x = bnds.w end
 local e = make_enemy(33,x,1)

 e.curve = .2
 e.sp = .4
 e.fire_rate = 28
 e.hp = 2 + (ng*2)
 e.xp = 3 + ng
 e.color = 10
 e.weak = 7
 e.inv = inv

 e.move = function()
 	e.curve += .01
  if e.curve > 360 then e.curve = 0 end
  e.y += e.sp
  local sc = sin(e.curve)

  e.x = sc * (bnds.w/3) + (bnds.w-8)/2
  if e.inv then
  	e.x = bnds.w - e.x -8
  end

  if e.x < 1 then e.x = 1 end
 	if e.x > bnds.w - 12 then e.x = bnds.w-12 end
 end

 return e
end

-- drops a mon for capture
function drop_mon(mon,e)
 local k = {}
 k.heart = 12
 k.star = 13
 k.diamond = 14
 k.comet = 15

 local m = make_actor(k[mon],20,20,1,1)
	m.mon = mon
	add(mons,m)
	psfx('drop')
end

function update_mon(m)
 local y = (count(ship.forms))*18 + 40
 local addm = 0

 if m.x < left_ui+12 then m.x +=2 else addm += 1 end
 if m.y < y + 2 then m.y +=2 else addm += 1 end

 if addm == 2 then
  del(mons,m)
  if m.mon == "diamond" then
   pl.mshield = 1
  end
  add(ship.forms,m.mon)
  flash_mon = true
  psfx('capture')
 end
end

-- draw for enemies
function draw_en(e)
 adjust_engine(e)

 draw_actor(e,e.flip)

 if e.m == true then
  e.x += e.w*8
  draw_actor(e, true)
  e.x -= e.w*8
 end
 pal()
end

-- updates enemy fire
function update_fire(f)
 if f then
		f.y += f.sp

		if f.drift then
		 f.x += f.drift
		end

 	if f.y > 128 then
 	 del(fire, f)
 	end
 end
end

-- makes a generic enemy
function make_enemy(s,x,y,w,h,m)
 if not w then w=1 end
 if not h then h=1 end
 if not m then m=false end
 local e = make_actor(s,x,y,w,h)

 e.curve = 0
 e.ctr = 0
 e.fire_rate = 10
 e.fire_x = 4
 e.fire_y = 8
 e.hp = 10
 e.blink = 0
 e.xp = 0
 e.color = 9
 e.m = m
 e.weak = 0

 -- flames
 e.flame = false
 e.flacnt = 0
 e.flamax = 3

 e.step = function()
  if e.y > 128 then
   del(en,e)
  elseif e.hp <= 0 then
   get_kill(e)
  else
   e.move()
   if pl.hp > 0 then e.check_fire() end
  end
 end

 e.check_fire = function()
 	e.ctr += 1

 	if e.ctr == e.fire_rate then
 		e.fire()
		end
 end

 e.fire = function()
 	local b = make_actor(
			0,
			e.x+e.fire_x,
			e.y+e.fire_y,
			1,
			1)
		b.sp = (e.sp + 1) * (e.sp + 1)
 	b.color = e.color
 	add(fire,b)
 	psfx('eshoot')

 	e.ctr = 0
 end

 e.drop = function()
  if ng == 0 and count(ship.unlocks) != 0 then
			local d = ship.unlocks[1]
			del(ship.unlocks,d)
			drop_mon(d,e)
		end
 end

 return e
end

function get_kill(e)
 for i=1,count(ships),1 do
  if ships[i].active then
   ships[i].add_xp(e.xp)
   score += e.xp
  end
 end

 if not e.bonus then
  if e.drops then e.drop() end

  del(en,e)
  explode(e)
  psfx('kill')
 end
end

-- steps enemy
function step_en(e)
 e.step()

 if pl.hp > 0 then
 	local er = {x=e.x,y=e.y,w=8,h=8}
 	local px = {x=pl.x,y=pl.y,w=16,h=16}
 	if rect_intersect(er,px) then
 		pl.hp = 1
 		pl.hit()
 		e.hp = 0
	 end
 end
end

-- checks for collisions and dmg
function check_damages()
 check_en_fir_dmg()
 check_bul_hit()
end

-- checks for pl bullet collisions
function check_bul_hit()
 foreach(en, function(e)
  local w = e.w*8
  local h = e.h*8
  if e.m then w = w*2 end
  local r1 = {x=e.x,y=e.y,w=w,h=h}

 	foreach(bullets, function(bul)
  	r2 = {x=bul.x,y=bul.y,w=bul.w,h=bul.h}

 		if rect_intersect(r1,r2) then
 	 	if bul.color != e.res then
 	 		e.hp -= pl.pow
 	 		if e.weak == bul.color
 	 		then e.hp -= 1
 	 			add_hitmark(bul,e,2)
 	 		else
 	 			add_hitmark(bul,e,1)
 	 		end
 	 		psfx('hit')

				else
					add_hitmark(bul,e,-1)
					psfx('absorb')
				end

 	 	if bul.turret == true then
   		pl.xtraammo -= 1
  		end

 	 	del(bullets,bul)
 		end
  end)
 end)
end

-- checks for collisions with
--  enemy bullets
function check_en_fir_dmg()
	foreach(fire, function(f)
 	local r1 = {x=f.x,y=f.y,w=f.w,h=f.h}
  local r2 = {}

  if r1.y > 128 - 16 - bnds.b then
   if not pl.active then
  		return
 		end

   r2 = {x=pl.x+2,y=pl.y,w=12,h=8}
  	if rect_intersect(r1,r2) then
  	 del(fire,f)
  	 if pl.current != "diamond" or pl.shield==0 then
  	  pl.hit()
  	  psfx('phit')
  	 else
  	  local e = {xp=4,bonus=true}
  	  pl.shield -= 1
  	  get_kill(e)
  	  psfx('shield')
  	 end
  	end
  end
 end)
end

-- creates stars
function create_stars()
 local colors = {6,5}

 for i=1,32 do
  local x = rnd(bnds.r)
		local y = rnd(128-bnds.b)
		local r = rnd(2)+1
  s = make_actor(0,x,y,1,1)
  s.sp = (4 - r)
  s.color = colors[flr(r)]

  add(stars,s)
 end
end

--updates and draw stars
function update_stars()
 foreach(stars,up_star)
end
function up_star(s)
 s.y += s.sp
 if s.y > 128 then
  s.y = 0 - s.w/2
 end
end
function draw_stars()
	foreach(stars,draw_rect)
end

-- creates explosion for actor
function explode(a)
 local runs = {0,1.73,1.73,0,-1.73,-1.73}
	local rise = {-1.73,-1,1,1.73,1,-1}

 if a.boss then
 	psfx('bossd')
 	delay = 10
  for i=0,8,1 do
 		for j=1,6,1 do
  		local f = make_flare(a.x+(8*i),a.y,rise[j],runs[j])
  		add(flares,f)
  		local f2 = make_flare(a.x+(8*(i+1)),a.y+16,rise[j],runs[j])
 			add(flares,f2)
 		end
 	end
 else
 	for i=1,6,1 do
  	local f = make_flare(a.x,a.y,rise[i],runs[i])
  	add(flares,f)
 	end
 end
end

function make_flare(x,y,ri,ru)
 local f = {}
 f.x = x
 f.y = y
 f.xinc = ru
 f.yinc = ri
 f.color = 8
 f.count = 0
 f.rad = 1

 return f
end

function update_flare(f)
 f.x += f.xinc
 f.y += f.yinc
 f.count += 1
 if f.count == 6 then
  f.color = 9
  f.rad +=1
 elseif f.count == 14 then
  f.color = 10
  f.rad +=1
 elseif f.count == 22 then
  del(flares,f)
 end

 if f.count != 22 and f.y > 128 - 16 - bnds.b then
  if not pl.active then
  	return
 	end
 	local fr = {x=f.x,y=f.y,w=f.rad,h=f.rad}
 	local pr = {x=pl.x,y=pl.y,w=16,h=16}

 	if rect_intersect(fr,pr) then
 		pl.hit()
 		del(flares,f)
	 end
 end
end

function draw_flare(f)
 circ(f.x,f.y,f.rad,f.color)
end


-- creates the player
function create_pl()
	pl = make_pl(1,1,128-16-bnds.b,1,2)
	pl.right = make_actor(1,pl.x+8,pl.y,1,2)
 set_ship("base")
end

-- create player ships ships
function create_ships()
	ships = {}

	-- base model
 local base = create_ship(
  "base",
  1,
  9,8,8,
  {7},
  {0},
  7,
  3,
  9
 )
 base.name = "jakrabit"
 base.icn = 0
 add(ships,base)

 -- heart
 local heart = create_ship(
  "heart",
  2,
  1,12,11,
  {3,12},
  {0,0},
  14,
  8,
  9
 )
 heart.name = "heartwal"
 heart.icn = 1
 add(ships,heart)

 -- star
 local star = create_ship(
  "star",
  3,
  1,12,11,
  {0,15},
  {-1,1},
  10,
  8,
  9
 )
 star.name = "onistar"
 star.icn = 2
 add(ships,star)

 -- diamond
 local dia = create_ship(
  "diamond",
  4,
  1,12,11,
  {},
  {},
  12,
  0,
  3
 )
 dia.name = "tentagem"
 dia.icn = 3
 dia.shield = 1
 add(ships,dia)

 -- comet
 local comet = create_ship(
  "comet",
  5,
  9,8,8,
  {6,9},
  {0,0},
  4,
  12,
  9
 )
 comet.name = "meteoth"
 comet.icn = 4
 comet.shield = 0
 add(ships,comet)
end

-- creates data for a player ship class
function create_ship(t,sp,f1,f2,f3,can,cand,c,a,mlv)
	local s = {}
 s.model = t
 s.sprite = sp
 s.f1 = f1
 s.f2 = f2
 s.f3 = f3
 s.cannons = can
 s.candrif = cand
 s.color = c
 s.exp = 0
	s.lv = 1
	s.ammo = a
	s.shield = 0
	s.mlv = mlv

	s.percent_xp = function()
	 local xp_curve = {15,24,34,45,57,68,80,99,120}--{15,18,24,28,34,45,55,60,90}
	 local prev = 0
	 if s.lv != 1 then
	 	prev = xp_curve[s.lv-1]
	 end

	 return (s.exp-prev)/xp_curve[s.lv]
	end

	s.add_xp = function(xp)
		if s.exp < 200 then
	 	s.exp += xp
	 end
	 if s.percent_xp() then
	 	if s.percent_xp() >= 1 and s.lv < s.mlv then
	  	s.lv += 1
	  	level_up(s.model)
	 	end
	 end
	end

 return s
end

-- stat increases
function level_up(t)
	local icn = 11
	local lt = "hp"

 if t == "base" then
  pl.hp += 1
  pl.maxhp += 1
 end

 if t == "heart" then
  pl.powt +=1
  if pl.powt == 3
  or pl.powt == 6
  or pl.powt == 9 then
   pl.pow +=1
  end
  icn = 12
  lt = "power"
 end

 if t == "star" then
  pl.blastt +=1
  if pl.blastt == 3
  or pl.blastt == 6
  or pl.blastt == 9 then
   pl.blast +=1
  end
  icn = 13
  lt = "blast"
 end

 if t == "diamond" then
  pl.mshield +=1
  pl.shield +=1
  icn = 14
  lt = "shield"
 end

 if t == "comet" then
  pl.turc +=1
  if pl.turc == 5
  or pl.turc == 9
  then
   pl.tur += 1
  end
  icn = 15
  lt = "turret"
 end

 lva_anim(icn,lt)
 psfx('levelup')
end

-- function switch ship
function switch_ship()
 local fcount = count(ship.forms)

 if ship.form < fcount  then
  ship.form += 1
 else
  ship.form = 1
 end

 set_ship(ship.forms[ship.form])
	psfx('switch')
end

-- switches player ship
function set_ship(s)
 for i=1,count(ships),1 do
  ships[i].active = false
  if s == ships[i].model then
   ships[i].active = true
   pl.current = s
   pl.icn = ships[i].icn
  	pl.sprite = ships[i].sprite
  	pl.f1 = ships[i].f1
  	pl.f2 = ships[i].f2
  	pl.f3 = ships[i].f3
  	pl.cannons = ships[i].cannons
  	pl.candrif = ships[i].candrif
   pl.color = ships[i].color
   pl.ammo = ships[i].ammo
   pl.shield = pl.mshield
  end
 end
end

-- draws the player sprite
function draw_pl()
 if not pl.active then
  return
 end
 --adjusts flames
 adjust_engine(pl)

 if is_shake then
  pal(7,8)
  pal(6,8)
  pal(15,8)
 end

 -- draws halfs of ship
 draw_actor(pl)
 pl.right.sprite = pl.sprite
 pl.right.x = pl.x + 8
 pl.right.y = pl.y
 draw_actor(pl.right, true)

 if pl.current == "diamond" and pl.shield > 0 then
  local s = make_actor(16,pl.x,pl.y-4,1,2)
  local sl = make_actor(16,pl.x+8,pl.y-4,1,2)
  draw_actor(s)
  draw_actor(sl,true)
 end

 local turx = {-8,16}
 local turf = {false,true}
 if pl.tur > 0 then
  for i=1,pl.tur,1 do
   spr(32,pl.x+turx[i],pl.y,1,2,turf[i])
  end
 end

 -- resets colors
 pal()
end

-- adjusts player flames
function adjust_engine(a)
	a.flacnt += 1
 if a.flacnt == a.flamax then
 	a.flame = not a.flame
 	a.flacnt = 0
 end
 if a.flame then
 	pal(a.f1,a.f2)
 	pal(a.f3,a.f1)
 else
 	pal(a.f3,a.f2)
 end
end

-- makes an actor and adds it
--  to the global actors array
--  returns actor
function make_actor(s,x,y,w,h)
	local a = {}

	-- draw
	a.sprite = s
	a.x = x
	a.y = y
	a.w = w
	a.h = h

	-- movement
	a.sp = 2

	return a
end

-- makes ship object
function make_pl(s,x,y,w,h)
 local a = make_actor(s,x,y,w,h)

 -- flames
 a.flame = true
 a.flacnt = 0
 a.flamax = 3

 -- player stats
 a.hp = 1
 a.maxhp = 1
 a.rec = 0
 a.pow = 1
 a.powt = 1
 a.blast = 1
 a.blastt = 1
 a.mshield = 0
 a.tur = 0
 a.turc = 1
 a.xtraammo = 0

 -- player states
 a.active = true


	-- methods
	a.shoot = function()
	 if a.ammo + a.xtraammo > count(bullets) then
	 	for i=1,count(pl.cannons),1 do
	 		local b = make_actor(0,a.x+pl.cannons[i],a.y+a.sp,a.blast,2)
	 		b.drift = pl.candrif[i]
	 		b.sp = 5
	 		b.color = pl.color
	 		add(bullets,b)
	 	end
	 	psfx('pshoot')
	 end
	end

	-- take damage
	a.hit = function()
		is_shake = true
		a.hp -= 1

  if a.hp == 0 then
   explode({x=a.x+8,y=a.y+8})
   a.active = false
   game_over()
   psfx('death')
  end
	end

	a.refill_hp = function()
	 if a.maxhp <= a.hp then
	 	a.rec = 0
	 	return
	 end
		if a.rec > 0 then
			a.hp += 1
			a.rec -= 1
		end
	end

	return a
end

-- updates all bullet locations
function update_bullets()
	foreach(bullets, update_bullet)
end
function update_bullet(b)
	b.y -= b.sp
	b.x += b.drift

 if b.y < 0 - b.w then
  if b.turret == true then
   pl.xtraammo -= 1
  end
  del(bullets, b)
 end
end

-- draws all bullets to screen
function draw_bullets()
 foreach(bullets, draw_circ)
end

-- draws enemy attacks
function draw_fire()
 foreach(fire, draw_circ)
end

-- draws a circle from actor
function draw_circ(b)
 circfill(b.x,b.y,b.w,b.color)
end

-- draws a rect from actor
function draw_rect(b)
 rectfill(b.x,b.y,b.x+b.w-1,b.y+b.h-1,b.color)
end

-- draws an actor to stage
function draw_actor(a, flipx)
 spr(a.sprite,a.x,a.y,a.w,a.h,flipx)
end

-- checks if two rects inter
function rect_intersect(r1,r2)
	if  r1.x < r2.x + r2.w
	and r1.x+r1.w > r2.x
	and r1.y < r2.y + r2.h
	and r1.y+r1.h > r2.y then
  return true
 end

 return false
end

--end game
function game_over()
 state = "gameover"
 music(-1)
end


function update_go()
	if go.sx < 45 then
 	go.sx += .5
 else
 	if go.x < 17 then
 		go.x += 1
 	elseif go_confirm then
 	 if go.y < 75 then
  	 go.y += 1
  	 if go.y == 65 then go.color = 6 end
  	 if go.y == 70 then go.color = 5 end
  	end
 	end
 end
end

function draw_go()
	local scx = 15
	local score_text = "score:"..(score*10)
 if go.y < 75 then
 	--print(,scx,go.sx,go.color)
 	print(score_text,(((bnds.w-8)-((#score_text*4-1)))/2)+1,go.sx,go.color)
	 print("game over",go.x,go.y,go.color)
	else
	 reset()
	end
end

--reset game to starting state
function reset()
 _init()
end