--xmas tree
--pico-8 doodle by trasevol_dog


drk={[0]=0,0,1,1,2,1,5,6,2,4,9,3,1,1,8,10}


function _init()
 cls()
 balls={}
 t=0
end

function _update()
 t+=0.01
 
 
 for b in all(balls) do
  b.y-=1
  b.t+=0.01
  
  if b.y<-16 then
   del(balls,b)
  end
 end
 
 
 if t%0.15<0.01 then
  add(balls,{
   x=rnd(128),
   y=128+8,
   t=0,
   c=flr(rnd(6))+8
  })
 end
 
end

function _draw()
 memcpy(0x2000,0x6000,0x2000)
 
 cls()
 for b in all(balls) do
  local a=0.75+0.2*cos(b.t)
  dx=cos(a)
  dy=sin(a)
  
  circfill(b.x+10*dx,b.y+10*dy,9,7)
  circfill(b.x+4*dx,b.y+4*dy,4,10)
  circ(b.x+dx,b.y+dy,3,10)
  circfill(b.x+10*dx,b.y+10*dy,8,b.c)  
  circfill(b.x+10*dx+4,b.y+10*dy-3,2,7)
 end
 
 memcpy(0x0,0x6000,0x2000)
 memcpy(0x6000,0x2000,0x2000)
 
 spr(0,0,0,16,16)
 for i=0,749 do
  local x,y=rnd(128),rnd(128)
  local c=sget(x,y)
  
  if c==0 then
   c=flr(y/32+abs(x%32-16)/32+t*3)%2
   
   local k
   if c==0 then
    k=0.8
   else
    k=0.2
   end
   
   if rnd(1)<k then
    c=3
   else
    c=11
   end
   
  elseif rnd(2)<1 then
   c=drk[c]
  end
  
  circ(x,y,1,c)
 end

 --print(stat(1),0,0,7) 
end

