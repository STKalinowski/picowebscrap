-- picochill2
-- by gruber & zep

-- v.1: removed debugging stuff

-- get the full album!
-- https://gruber99.bandcamp.com/album/pico-chill

--inp_mode = "rec"
inp_mode = "playback"


function _init()
	poke(0x5f2d,1) -- mouse

-- tweetcart=true

 view = 4 -- 0 output 1 code.. 4 terminal
 size = 1
 cspr = 0
 col  = 14
 map_x = 0
 map_y = 0
 code_x = 5
 code_y = 0
 
 if (inp_mode == "rec") 
 then
  -- clear recording data area
  memset(0xa000,0,0x3000)
 else
  -- playback: move rec data
  -- to high
  memcpy(dat_pos0,0,0x3000)
  
  
  load_gfx()
 end
 
 -- always load sprite gfx
 -- (bank 0)
 load_sp_gfx()
 
 -- store starting from sprite
 -- bank 1
 if (inp_mode=="rec") then
  menuitem(1,"store rec", 
  	function()
		  local len=dat_pos-dat_pos0
		  cstore(0, dat_pos0, 0x3000) 
--		  printh"---" 
--  		printh("stored "..len.." bytes")
	 end)
	end
	
	music(0)
	
	minutes=0
	show_scrolly = 
	 inp_mode == "playback"

 menuitem(1,"toggle text",
	function()
	 show_scrolly = not show_scrolly
	end
	)
 
end

frame_n = 0
function _update()

 minutes+=1/900

 last_b = inp.b or 0

 if (inp_mode == "rec") then
	 read_devices()
	elseif inp_mode == "playback" then
	 read_state()
	else
	 -- finished
	end
	
	
	nano_update()
	
	-- lmb: debug event timing
--	if (inp.b&64>0) printh(frame_n)
 frame_n += 1
end

function _draw()
 
 pal()cls()

 nano_draw()
 --copy to spritesheet
 for y=0,31 do
  memcpy(0+y*64,0x6000+y*64,16)
 end
 
 spr(0,0,0,16,16)
 pal()
 
 if (inp_mode == "rec") then
  cls()
  sspr(0,0,32,32,0,0,128,128)
  
  -- show capacity
  local len=dat_pos-dat_pos0
  line(0,0,127,0,1)
  line(0,0,len/(0x3000/128),0,7)
  pset(minutes*128/43,0,14)
 else
  draw_scene()
 end
 
 
 
 -- show display
-- poke(0x5f54,0x60)
-- palt(0)
-- 
-- sspr(0,0,32,32,0,0,128,128)
-- 
-- poke(0x5f54,0x00)
-- pal()
-- 
 -- show recording data
-- spr(128,0,0,16,8)

 if (show_scrolly) then
	 local str=
	 "♪ track: picochill2  "..
	 "░ album: gruber99.bandcamp.com"
	 
	 rectfill(0,0,127,6,0)
	 local ww=(#str*4+64)
	 for i=0,0 do
	 --local q=128-(time()*30)%ww
	 local q=128-mid(0,
	  time()*30, 215)
	 
	 if (stat(54) == 60) then
	  print(" (♪ looping..)",30,1,7)
	 else
	  print(str,q+i*ww,1,13)
	 end
	 
	 end
	end
 
end
-->8
-- nano draw

-- allowed to assume
-- 0x6000 0,0 - 31,31
function nano_draw()

 cls(5)

 if (view == 0) draw_output() return
 if (view == 1) draw_codeed()
 if (view == 2) draw_gfxed()
 if (view == 3) draw_maped()
 if (view == 4) then
  cls(0)
  pset(1,1,7)pset(3,1,7)
  pset(5,1,7)pset(6,1,7)pset(8,1,7)
  pset(1,3,7)
  if (t()%1<.50)pset(3,3,8)
  
  
  return
 end
 
 
 -- sprite picker (gfx / map)
 if (view == 2 or view == 3)
 then
  rectfill(0,22,31,29,0)
  palt()
  sspr(32,0,64,16,0,22,32,8)
 end
 
 -- red bars
 rectfill(0,0,31,1,8)
 rectfill(0,30,31,31,8)
 
 -- view tabs
 for i=1,5 do
  pset(20+i*2,0,
  	view==i and 14 or 2)
 end
 
 
 -- mouse cursor
 pset(inp.mx, inp.my, 7)
 pset(inp.mx+1, inp.my+1, 7)
 
end

function draw_gfxed()

 rectfill(2,3,19,20,0)
 
local xx = 32 + (cspr%8) * 8
 local yy = 0  + (cspr\8) * 8
 palt(0)
 
 
 sspr(xx,yy,8,8,3,4,16,16)
 
 
 -- palette
 for y=0,3 do
  for x=0,3 do
  	local sx=22+x*2
  	local sy=3 +y*2
  	rectfill(sx,sy,sx+1,sy+1,x+y*4)
  end
 end
 
 -- sliders
 
 line(22,13,29,13,13)
 line(22,15,29,15,13)
 
 print("…",22,15,1)
 -- tabs
 for i=0,3 do
  local sx=22+i*2
  local sy=20
  rectfill(sx,sy,sx+1,sy+1,
  i==0 and 6 or 13)
 end
 
 
end

-- map
function draw_maped()

-- 32x16 map 
--  8x 5 view (32x20)

clip(0,2,32,20)

-- outside map area
rectfill(0,2,32,21,0)
for i=1,52,3 do
 line(i,2,i-21,23,1)
end


rectfill(0-map_x,2-map_y,
 0+32*8-map_x,2+16*4-map_y,0)

rect(-1-map_x,1-map_y,
 0+32*8-map_x,2+16*4-map_y,6)
  
for y=0,15 do
 for x=0,63 do
  local sx=x*4   - map_x
  local sy=2+y*4 - map_y
  local v=sget(32+x,16+y)
  local xx=32+(v%8)*8
  local yy=00+(v\8)*8
  if(v>0)sspr(xx,yy,8,8,sx,sy,4,4)
 end
end
clip()

end


code_ln={}


function draw_codeed()
 
 cls(1)
 
 sy=2-max(0,code_y)
 
 for i=1,5 do
  spr(12,0,sy,4,4)sy+=32
 end
 
 
 if (t()%1<.5) then
  pset(code_x, 2+15+min(0,code_y), 8)
 end
 
end

-->8
-- nano state

--[[
 0b00 small mouse delta
 0b01 absolute mouse pos
 0b10 button state change
 0b11 span of no change
 
]]


inp={
 mx=0,
 my=0,
 b=0
}

inp_f = 0

function read_devices()

 inp0=inp
 inp={}

 inp.mx = mid(0,stat(32)\4,31)
 inp.my = mid(0,stat(33)\4,31)

 inp_f += 1
 
 inp.b  = btn() & 0x3f3f
 inp.b |= stat(34)<<6
 
 write_state()
end


pbf=0
function read_state()
 
 dp("read state frame "..pbf)
 pbf +=1

 
 -- read commands
 
 local found_delta_cmd = false
 
 while (true) do
  local val=read_byte()
  
  local cmd=val&3
  

  if (cmd == 0) then
   if (found_delta_cmd) then
    -- must be for next frame
    --> unread byte
    dat_pos -= 1
    return
   end
   found_delta_cmd = 1
  end
  
  dp(" cmd: "..cmd)
  
  if (val==0) then
   inp_mode="finished"
   dp(" @@ finished")
   return
  end
  
  
  if (cmd == 0) then
   -- small mouse delta
   local dx=((val>>2)&0x7)-4
   local dy=((val>>5)&0x7)-4
   inp.mx += dx
   inp.my += dy
   
   dp(" delta "..dx.." "..dy)
   
   
  elseif (cmd == 1) then
   -- absolute
   local val2=(val>>2)&31
   if(val&0x80>0) then
    dp(" my "..val2)
    inp.my = val2
    -- always written 2nd
   else
   	dp(" mx "..val2)
    inp.mx = val2
   end
  elseif (cmd == 2) then
   -- button
   local bindex=(val>>2)\1
   dp(" button toggle "..bindex)
   inp.b ^^= (1<<bindex)
  else
   -- cmd 3: idle frames
   if (val >= 4) then
    dat_pos -= 1
    poke(dat_pos, val-4)
   end
   return
  end
  
 end
 
 
end

function dp(...)
-- printh(...)
end


-- 0..5,8..13 gamepad btns
-- 6,7 mouse buttons
function bts(i, state)
 state = state or inp
 return (state.b & (1<<i)) > 0
end

-- record to 0xa000, but
-- store at 0x2000
dat_pos = 0xa000
dat_pos0= dat_pos

function read_byte()
	dat_pos +=1
	return @(dat_pos-1)
end

function write_byte(v)
 
 -- if cmd==0 and prev is 0x3
 -- and one before that is
 -- also cmd==0 can overwrite
 -- previous byte
  
 if (v&3) == 0 and
    dat_pos >= dat_pos0 + 2 and
    @(dat_pos-1) == 0x3 and
    (@(dat_pos-2)&3) == 0
 then
  dat_pos -= 1
 end
 
  
-- printh("frame "..inp_f.." cmd "..(v&3).." val: "..tostr(v,1).." len:"..tostr(dat_pos-dat_pos0))
 
 poke(dat_pos, v)
 dat_pos += 1
end

function write_state()

 local dx=inp.mx - inp0.mx
 local dy=inp.my - inp0.my
 
 -- write mouse delta
 if (dx!=0 or dy!=0) then

--  printh("delta "..dx..","..dy)
	
	 if (dx>=-4 and dx <= 3 and
	     dy>=-4 and dy <= 3 and
	     not (dx==-4 and dy==-4))
	 then
	  -- small delta (frequent)
	  -- never zero though (reserved
	  -- for end-of-data)
	  write_byte(0x0 |
	   ((dx+4) << 2) |
	   ((dy+4) << 5))
	 else
	 	-- absolute (2 bytes)
	 	-- (infrequent)
	 	write_byte(0x1 | (inp.mx<<2))
	 	write_byte(0x81 | (inp.my<<2))
  end
 end
 
 -- button change
 
 for i=0,13 do
  if bts(i) != bts(i,inp0) then
   -- just toggle
   write_byte(0x2 | (i<<2))
  end
 end
 
 -- state length
 -- means: repeat state for
 --        n frames

 local val0=@(dat_pos-1)
 if dat_pos > dat_pos0 and
    (val0 & 3)==3 and
     val0 < 255 then
  -- increment existing span
  poke(dat_pos-1,val0+4)
 else
  -- start new span
  write_byte(0x3)
 end
 
end

-->8
-- nano update

function nano_update()

 last_view = view
 
 -- view switching
 
 if (last_b&~2048==0) then
  if (inp.b&256>0) view-=1
  if (inp.b&512>0) view+=1
  if (inp.b&1024>0 and 
      inp.b&2048>0 and
      not tweetcart) then
   tweetcart=true
   memset(0,0,0x800)
   for y=0,31 do
    for x=96,127 do
     sset(x,y,1) -- empty code
     code_x=1
     code_y=-14
    end
   end
  end
  
  if (view<0)view=4
  if (view>4)view=1
  
 end
 
 if (view ~= last_view and
    view == 0 and
    not tweetcart) then
    
    -- gonna run; back up gfx
    memcpy(0xf000,0,0x800)
    
 end
 
 if (view ~= last_view and
    last_view == 0 and
    not tweetcart) then
    
    -- finished running;
    --> restore gfx
    
    memcpy(0,0xf000,0x800)
    
 end
 
 
 if (view == 0) update_output()
 if (view == 1) update_codeed()
 if (view == 2) update_gfxed()
 if (view == 3) update_maped()
 
 
 
end

function update_gfxed()

 local mb=(inp.b>>6)&3
 
 if (mb > 0) then
 
  -- sprite
  local sx=(inp.mx-3)\2
  local sy=(inp.my-4)\2
  
  if (sx>=0 and sx<8 and
      sy>=0 and sy<8) then
      
   sx+=(cspr%8)*8
   sy+=(cspr\8)*8
   
   if (mb==1)sset(32+sx,sy,col)
   if (mb==2)col=sget(32+sx,sy)
  end
 
  -- sprite picker
		if (inp.my >=22) then
		 local xx=inp.mx\4
		 local yy=(inp.my-22)\4
		 cspr=xx+yy*8
		end
	
		-- col picker
		local sx=(inp.mx-22)\2
  local sy=(inp.my-3)\2
  
  if (sx>=0 and sx<4 and
      sy>=0 and sy<4) then
   col=sx+sy*4
  end
  
 end
 
	
	
end

function update_maped()

 local mb=(inp.b>>6)&3
 
 -- slow becuase doesn't cost
 -- any extra rec data!
 if (inp.b&1>0)map_x-=1
 if (inp.b&2>0)map_x+=1
 if (inp.b&4>0)map_y-=1
 if (inp.b&8>0)map_y+=1
 
 if (mb > 0) then
 
  -- place cel
  local sx=(inp.mx-0+map_x)\4
  local sy=(inp.my-2+map_y)\4
  
  if (sx>=0 and sx<32 and
      sy>=0 and sy<16) then
      
   sx+=32
   sy+=16
   
   if (mb==1)sset(sx,sy,cspr)
   if (mb==2)cspr=sget(sx,sy)
  end
 
  -- sprite picker
		if (inp.my >=22) then
		 local xx=inp.mx\4
		 local yy=(inp.my-22)\4
		 cspr=xx+yy*8
		end
	end
end

function update_codeed()

 if (last_b == 0) then
	 if (inp.b&1>0)code_x-=1
	 if (inp.b&2>0)code_x+=1
	 
	 -- new line (tweetcart)
	 -- do at end of line
	 if (inp.b&2048>1) then
	  for y=31,code_y+17,-1 do
	   for x=96,127 do
	    sset(x,y,sget(x,y-2))
	   end
	  end
	  
	  code_y+=2
	  code_x=2
	  for x=96,127 do
 	   sset(x,code_y+15,1)
	  end
	  
	 end
	 
	 
	 -- ❎ typeity
	 if (inp.b&32>0) then
	   sset(96 + code_x,
	    (code_y+15)%32,
	    rnd{6,6,12,11})
	   code_x += rnd{1,1,1,2,2}
	   
	 end
	 
	 -- 🅾️ delete
	 if (inp.b&16>0) then
	   sset(96 + code_x,
	    (code_y+15)%32,1)
	    code_x-=1
	   sset(96 + code_x,
	    (code_y+15)%32,1)
	 end
	 
 end
 
 if (last_b==0) then
  if (inp.b&4>0)code_y-=2
  if (inp.b&8>0)code_y+=2
	end
	
end



-->8
-- run


function solid(x,y)
 local v=sget(32+x,16+y)
 return v>=1 and v<=5
end


function update_output()
 if last_view != view then
  --init
  pl={
  x=9,
  y=4,
  dx=0,
  dy=0,
  f=0,
  d=1,
  st=false
  }
  
  if (tweetcart) tcfi+=1
 end
 
 accel= pl.atk and 0 or .02 
 
 if (inp.b&1>0) pl.dx-=accel pl.d=-1
 if (inp.b&2>0) pl.dx+=accel pl.d= 1
-- if (inp.b&4>0) pl.dy-=accel
-- if (inp.b&8>0) pl.dy+=accel
-- 
 if (not solid(pl.x+.5*pl.d+pl.dx,pl.y-.5)) then
  pl.x+=pl.dx
 else
  pl.dx*=-1
 end
 
 if (pl.dy>0) then
  -- going down
  if (not solid(pl.x,pl.y+pl.dy)) then
   pl.y+=pl.dy
   pl.st=false
  else
   pl.dy *= 0
   pl.y=(pl.y+.5)\1
   pl.st=true
  end
 
  
 else
  -- going up
  pl.st = false
  if (not solid(pl.x,pl.y-.5+pl.dy)) then
   pl.y+=pl.dy
  else
   -- bump head
   pl.dy = 0
  end
 
 end
 
 
 -- up: jetpack
 if (inp.b&4>0) then
  pl.dy=-.5
 end
 
 -- down: jump too low
 if (pl.st and inp.b&8>0) then
  pl.dy=-.15
 end
 
 -- jump
 if (pl.st and inp.b&16>0) then
  pl.st=false
  pl.dy=-.4
 end
 
 
 -- attack
 pl.atk = inp.b&32>0
 
 pl.y+=pl.dy
 pl.dx*=.8
 pl.dy*=.8
 pl.dy+=.02 -- gravity
 
 -- attack ground
 if (pl.atk) then
 
  local xx=pl.x+.7*pl.d
  local yy=pl.y-.5
  v=sget(32+xx,16+yy)
  if (v>=3 and v<=5) then
   -- breakable
   
    sset(32+xx, 16+yy, 0)
  
  end
 
 end
 
 -- pick up gem
 local xx=pl.x yy=pl.y-.5
 if (sget(32+xx,16+yy)==9) then
  sset(32+xx,16+yy,0)
 end

end

function draw_output()

 clip()
 pal()fillp()
 
 if (tweetcart) then
  draw_tweetcart()
  return
 end
 
 cls(12)
 
 cam_x = pl.x*8-16
 cam_y = pl.y*8-24
 
 -- background
 
 local bx=0-cam_x/4
 local by=8-cam_y/4
 
 for i=-20,20 do
  spr(10,bx+i*16,by,2,2)
 end
 rectfill(0,by+16,31,32,sget(95,15))
 
 
 local ww=8
 for y=0,15 do
 for x=0,63 do
  local sx=x*ww  - cam_x
  local sy=y*ww- cam_y
  local v=sget(32+x,16+y)
  local xx=32+(v%8)*8
  local yy=00+(v\8)*8
  if(v>0)sspr(xx,yy,8,8,sx,sy,8,8)
 end
 end

 pl.f+=abs(pl.dx*2)
 
 local sx=pl.x*8-cam_x-4
 local sy=pl.y*8-cam_y-8
 local bi=(pl.f&1)
 if (pl.atk)bi=2 sx+=pl.d*4
 spr(22+bi,sx,sy,1,1,pl.d<0)

end
-->8

local typeity_t=0
local typeity_fr=64
local typeity_frr=199
local typeity_frr_x=0
local typeity_frr_y=0
local ht=0
function draw_jetgirl()
	palt(0)
	palt(4,true)
	
	--body offset
	local bx,by=0,0
	
	sx=57 +bx
	sy=99+by
	
	-- arm

 -- gfx/map editor: rare
 fr=({64,68,72})[1+((t()*2)%2.5)\1]
	if (t()%6<2)fr=72
	fr=68
	
	--typing
	if (view==1 and inp.b>=16) typeity_t=15
	typeity_t=max(0,typeity_t-1)
	
	if (typeity_t>0) then
	 fr=typeity_fr
	 if (frame_n&3==0) then
	  if (rnd(2)<1) then
	  typeity_fr=
	   rnd{64,68,72,200,204}
	  else
	   typeity_frr=
	   rnd{199,215,231,247}
	   typeity_frr_x=rnd(4)
	   typeity_frr_y=rnd(2)
	  end
	 end
	end
	
	-- playing cart
	if (view==0) then
	  fr= inp.b>0 and 140 or 136
	end
	
	spr(fr,sx,sy,4,4)
	spr(76,sx+32,sy,4,4)
	
	if(typeity_t>0) then
	
	 spr(typeity_frr,
	  74+typeity_frr_x,
	  91+typeity_frr_y)
	 
	end
	
	-- head
	sx=78 +bx
	sy=49 +by
	
	-- head pos: lean forward
	-- when looking at code
	local htt=-.5+cos(t()/6)/3
	if(view==1) htt=-1.5
	ht=(ht*7+htt*1)/8
	
--	ht=htt
	
	spr(128,
	 sx+ht*2,
	 sy+ht*1,7,7)
end

-- use spritesheet 0,0~31,31 
function draw_display(x,y)
	for i=0,31 do
		sspr(i,0,1,32,x+i,y-i/2)
	end
	
	pal()
	
--[[ too messy
	palt(0b1111111100000100)
	pal({1,2,3,4,5,6,7,
	     9,10,15,11,12,13,14,15})
	for i=0,5 do
	 sspr(i,0,1,32,x-4,y+2)
	 sspr(i,0,1,32,x-4,y+1)
	end
--]]
	
end
	
function draw_scene()

 -- background
 memcpy(0x6000,0x8000,0x2000)

 -- screem
 draw_display(33,44)
 
 draw_jetgirl()
 
end


-->8
-- binstr

function escape_binary_str(s)
 local out=""
 for i=1,#s do
  local c  = sub(s,i,i)
  local nc = ord(s,i+1)
  local pr = (nc and nc>=48 and nc<=57) and "00" or ""
  local v=c
  if(c=="\"") v="\\\""
  if(c=="\\") v="\\\\"
  if(ord(c)==0) v="\\"..pr.."0"
  if(ord(c)==10) v="\\n"
  if(ord(c)==13) v="\\r"
  out..= v
 end
 return out
end

--[[
local bin_str=""
for i=0x0,0x7ff do
 bin_str..=chr(@i)
end
local e_str=escape_binary_str(bin_str)

printh(e_str,"@clip")
]]

function load_gfx()

-- bgdat (from bg.png)
bgdat="\0▮U\0\0オ。\0\0▮■\0\0▮■\0\0▮■\0\0▮■■\0■■▮\0▮■\0\0▮■\0\0▮■\0\0▮■\0\0▮¹\0003▮⁙\0\0▮■カツ\0\0\0\0\0\0\0▮■\0\0オツ\0\0▮■\0\0▮■\0\0▮■\0\0▮■▮\0▮■\0▮▮■\0\0▮■\0\0▮■\0\0▮■\0\0▮■\0\0003■³\0▮■\0ツツ\0\0\0\0\0\0\0■\0\0オツ\0\0▮■\0\0▮■\0\0▮■\0\0▮■\0▮\0オ。¹▮■\0\0▮■\0\0▮■\0\0▮■\0\0▮■\0\0\0003\0³▮■\0\0ツツ\0\0\0\0\0\0\0\0\0オツ\0\0▮■\0\0▮■\0\0▮■\0\0▮■\0\0▮¹\0ツ■■\0\0▮■\0\0▮■\0\0▮■\0\0▮■0³3\0003\0⁙1³3⁙カツ\0\0\0\0\0\0\0\0▮ツ\0\0`◀\0\0▮■\0\0▮■\0\0▮■\0\0▮■■\0■■▮\0▮■\0\0▮■\0\0▮■\0\0▮■\000333\0003▮⁙333め■ツ\0\0\0\0\0\0\0▮■\0\0`f\0\0▮■\0\0▮■\0\0▮■\0\0▮■▮\0▮■\0▮▮■\0\0▮■\0\0▮■\0\0▮■\0\00033³\0003■³333はツツ\0\0\0\0\0\0\0■\0\0`f\0\0▮■\0\0▮■オツ。■\0\0▮■\0▮\0オ。¹▮■\0\0▮■\0\0▮■\0\0▮■\0\0\00033\0³3\0³⁙3めはツツ\0\0\0\0\0\0\0\0\0`f\0\0▮■\0\0▮■ツツ]UU\0▮■\0\0▮¹\0ツ■■\0\0▮■\0\0▮■\0\0▮■\0\0▮¹0³\00033\0⁙⁙\0ぬめタツ\0\0\0\0\0\0\0\0▮f\0\0`◀\0\0▮■ツツ]UUコツ。\0\0▮■■\0■■█☉「■\0\0▮■\0\0▮■\0\0▮■\0000▮¹03▮3³\0▮めタツ\0\0\0\0\0\0\0▮■\0\0`f\0\0▮■ツツ]UUコツ]UU▮■▮\0▮■\0x♥☉\0\0▮■\0\0▮■\0\0▮■\0\0▮■\0\0003▮3³▮■\0ツツ\0\0\0\0\0\0\0■\0\0`f\0\0▮■ツツ]UUコツ]UUコツ\r▮\0オ。¹☉☉(\0▮■\0\0▮■\0\0▮■\0\0▮■\0\0¹3\0003\0■\0\0ツツ\0\0\0\0\0\0\0\0\0`f\0\0▮■ツツ]UUコツ]UUコツ]U‖¹\0ツ■(ヘモツ■\0\0▮■\0\0▮■\0\0▮■\0\0■¹3\0003\0\0\0▮カツ\0\0\0\0\0\0\0\0▮f\0\0P‖ツツ]UUコツ]UUコツ]UUUU⁵■カ☉🅾️ヘツツ\0▮■\0\0▮■\0\0▮■\0\0■¹\0;▮3\0\0▮■■ツ\0\0\0\0\0\0\0▮■\0\0PUツツ]UUコツ]UUコツ]UUUUUUコツ♪モテ♪スツ■\0\0▮■\0\0▮■\0\0■13\0;▮3\0▮■\0コツ\0\0\0\0\0\0\0■\0\0PUツツ]UUコツ]UUコツ]UUUUUUコツ☉♪☉ス☉ツツツ\0▮■\0\0▮■\0めめ3³\0003;\0003▮■\0 🐱ツ\0\0\0\0\0\0\0\0\0▮Uツツ]UUコツ]UUコツ]UUUUUUコツツ♪☉☉☉Xコツツツ■\0\0▮■\0ぬめ3め\0\00003\0;▮\0☉ツ♪☉\0\0\0\0\0\0\0\0▮■ツツ]UUコツ]UUコツ]UUUUUUコツツ]U🐱X☉ツツツツツツ\0▮■\0\0ぬ;はめ▮■\0003▮;\0000め☉ツ●☉\0\0\0\0\0\0▮■ツツ]UUコツ]UUコツ]UUUUUUコツツツツ✽☉U✽スツツツff◀■\0\0▮ねめめ▮■\0\0003▮;ぬ;は⬅️☉f●☉\0\0\0\0\0■ツツ]UUコツ]UUコツ]UUUUUUコツツツツツツツツツツツツffff\0\0▮■ぬめ▮■\0\0\0;\0003ぬめはめ☉☉f●☉\0\0\0\0ツツ]UUコツ]UUコツ]UUUUUUコツツツツツツツツツツツツfffff⁶▮■\0ぬ▮■\0\0▮¹;\00031めめめ☉☉☉f●⁸\0\0\0ツ]UUコツ]UUコツ]UUUUUUコツツツツツツツツツツツツffffff◀■\0\0▮■\0\0▮■\0;\00033\0めめ\"☉☉☉f●⁸\0\0]UUコツ]UUコツ]UUUUUUコツツツツツツツツツツツツfffffff◀\0\0▮■\0\0▮ねめ³3\0;³I░め\"🐱☉☉☉f◀¹\0UUコツ]UUコツ]UUUUわ\\コツツツツツツツツツツツツffffffff⁶\0▮■\0\0ぬ;3\00033\0;cサD)\"\"☉☉☉「■¹\0Uコツ]UUコツ]UUUUアわチツツツツツツツツツツツツfffffffff⁶▮■\0\0 め3め•■;3;Cケm▥)\"☉☉☉「■¹\0コツ]UUコツ]UUUUUアわチツツツツツツツツツツツffffffffff◀■\0\0 \"めはめ•\0;⁙;D⬆️if▥)🐱☉☉「■¹\0ツ]UUコツ]UUUUUUアイチツツツツツツツツツツffffff\0pgff◀\0\0▮\"\0めめ•\0\0003■;▥D▥if▥웃☉☉「Q¹\0]UUコツ]UUUUUUコアアカツツツツツツツツツffffff\0\0\0wff⁶\0▮■\0\0め•\0\0▮3\0003DDD⬆️if▥웃☉「U¹\0UUコツ]UUUUUUコツ、アチツツツツツツツツffffff\0\0\0\0wff⁶▮■\0\0█ま\0\0▮■3\0003DDDD▥if\"☉「■¹\0Uコツ]UUUUUUコツツアアツツツツツツツツffffff\0\0\0\0\0wff◀■\0\0█☉ぬ\0▮■\0;▮3⬆️▥ID▥▥\"\"☉「■¹\0Uツ]UUUUUUコツツツ-Bツツツツツツツffffff\0\0\0\0\0\0wff◀\0\0█☉\0\0…」\0\0;■;▥▥▥▥▥▥\"\"☉「U¹\0UツUUUUUUコツツツUEDチツツツツツffffff\0\0\0\0\0\0\0wff⁶\0▮☉\0\0…▥\0\0▮;0;▥3め▥▥▥\"\"☉「‖¹\0コ]UUUUUコツツツツ]Eチツツツツツffffff\0\0\0\0\0\0\0\0wff⁶▮■\0\0…▥\0\0▮■3ぬ;み;はK⬆️▥\"\"☉「■¹\0コ]UUUUコツツツツツツツツツツツツffffff\0\0\0\0\0\0\0\0\0wff◀■\0\0…▥\0\0▮■\0003ぬ39めめめD▥\"\"☉「Q¹\0コ]UUUUツツツツツツツツツツツツffffff\0\0\0\0\0\0\0\0\0\0wff◀\0\0…▥\0\0█「オツ3=³0⧗めめD▥\"\"☉「‖¹\0ツUUUU‖ツツツツツツツツツツツffffff\0\0\0\0\0\0\0\0\0\0\0wff⁶\0▮▥\0\0█☉オ。■31⁙1A▥めI▥\"\"☉「■¹\0ツUUUU‖fツツツツツツツツツffffff\0\0\0\0\0\0\0\0\0\0\0\0wff⁶▮■\0\0█☉\0。■■31⁙1■D▥▥▥\"\"☉「U¹\0ツUUUU‖efツツツツツツツffffff\0\0\0\0\0\0\0\0\0\0\0\0\0wff◀■\0\0█☉\0オ■■U34#3■D▥▥▥\"\"☉「‖¹\0]UUUU‖Uefツツツツツffffff\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff◀\0\0█☉\0\0`■UU22#2□D⬆️▥▥\"\"☉「■¹\0]UUUU‖UUefツツツffffff\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff⁶\0▮☉\0\0 bVU\"\"\"\"\"キD⬆️▥▥\"\"☉「■¹\0]UUUU‖UUUefツmfffff\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff⁶▮■\0\0 \"`gVUEDDdツD⬆️▥▥\"\"☉「■¹\0]UUUU‖UUUUeコfffff\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff◀■\0\0 \"\0`wfffツツmツD⬆️▥▥\"\"☉「■¹\0UUUUU‖UUUUUeffff\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff◀\0\0▮\"\0\0\0vfffツツmツD⬆️▥▥\"\"☉「■¹\0UUUUU‖UUUUUefff⁶\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff⁶\0▮■\0\0\0\0`fffツツツ-D⬆️▥▥\"\"☉「■¹\0UUUUU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff⁶▮■\0\0\0\0\0オツfサツツ。!B⬆️▥▥\"\"☉「■¹\0UUUUU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff◀■\0\0\0\0\0オeサUUU■a。B⬆️▥▥\"\"☉「■¹\0UUUUU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff◀\0\0\0\0\0オツコffツツツm。B⬆️▥▥\"\"☉「■¹\0UUUUU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff⁶\0\0\0\0オツ]コmffツツm。B⬆️▥▥\"\"☉「■¹\0UUU‖Q‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff⁶\0\0\0オツ]Uコツffツツm。B⬆️▥▥\"\"☉「■¹\0UU‖■U‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff⁶\0\0オツ]UUカツmfツツm。B⬆️▥▥\"\"☉「■D⁴U‖■UU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff⁶\0オツ]UU■カツツfツツm。\"★▥▥\"\"░「DDDU■U‖Q‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff⁶オツ]UU■!\"ツツツツfサMDD⬆️▥\"BDDDDDUU‖■U‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wffVツ]UU■!\"\"キツツツツツDDDDDDDDDDDDU‖■UU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wffV]UU■!\"\"\"\"キツツツDDDDDDDDDDDDDU■U‖Q‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wffVUU■!\"\"\"\"\"\"BDDDDDDDDDDDDDDDUU‖■U‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wffVU■!\"\"\"\"\"\"\"DDDDDDDDDDDDDDDDU‖■UU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wffV■!\"\"\"\"\"\"\"BDDDDDDDDDDDDDDDDU■U‖Q‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff◀!\"\"\"\"\"\"\"\"DDDDDDDDDDDDDDDDDUU‖■U‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff&\"\"\"\"\"\"\"\"BDDDDDDDDDDDDDDDDDU‖■UU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff&\"\"\"\"\"\"\"\"DDDDDDDDDDDDDDDDDDU■U‖Q‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0wff&\"\"\"\"\"\"\"BDDDDDDDDDDDDDDDDDDUU‖■U‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0gff&\"\"\"\"\"\"\"DDDDDDDDDDDDDDDDDDDU‖■UU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0fff&\"\"\"\"\"\"BDDDDDDDDDDDDDDDDDDDU■U‖Q‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0fすjf\"\"\"\"\"\"\"DDDDDDDDDDDDDDDDDDDDUU‖■U‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0fすちjf\"\"\"\"\"\"BDDDDDDDDDDDDDDDDDDDDU‖■UU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0fすちjち\"\"\"\"\"\"\"DDDDDDDDDDDDDDDDDDDDDU■UUU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ffすjすち3\"\"\"\"\"BDDDDDDDDDDDDDDDDDDDDDUUUUU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0\0fffサちちj:#\"\"\"\"DDDDDDDDDDDDDDDDDDDDDDUUUUU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0\0ffffサちfちち+\"\"\"BDDDDDDDDDDDDDDDDDDDDDD■UUUU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0\0fffff3こちちめめ\"\"\"DDDDDDDDDDDDDDDDDDDDDDD■■UUU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0\0fffff333ちめめめ\"\"BDDDDDDDDDDDDDDDDDDDDDDD■■■UU‖UUUUUeffv\0\0\0\0\0\0\0\0\0\0fffff33333fめめ\"\"DDDDDDDDDDDDDDDDDDDDDDDD■■■■U‖UUUUUeffv\0\0\0\0\0\0\0\0\0fffff333は;はめめめ\"BDDDDDDDDDDDDDDDDDDDDDDDD■■■■■‖UUUUUeffv\0\0\0\0\0\0\0\0fffff333はめkめfめめ\"DDDDDDDDDDDDDDDDDDDDDDDDD■■■■■■UUUUUeffv\0\0\0\0\0\0\0fffff333はめkkへへめ+BDDDDDDDDDDDDDDDDDDDDDDDDD■■■■■■UUUUUeffv\0\0\0\0\0\0fffff333はめへfkめめ+\"BDDDDDDDDDDDDDDDDDDDDDDDDD■■■■■■QUUUUeffv\0\0\0\0\0fffff333はめkへfめめ+\"\"DDDDDDDDDDDDDDDDDDDDDDDDDD■■■■■■QUUUUeffv\0\0\0\0fffff333はめkkめへめ+\"★)DDDDDDDDDDDDDDDDDDDDDDDDDD■■■■■■■UUUUeffv\0\0\0fffff333はめめへkへめ+\"★▥IDDDDDDDDDDDDDDDDDDDDDDDDDD3■■■■■■QUUUeffv⁷\0fffff333はめめめfめめ+\"★▥▥DDDDDDDDDDDDDDDDDDDDDDDDDDD33■■■■■■UUUefffwfffff333はめめめめfめ+\"★▥▥DDDDDDDDDDDDDDDDDDDDDDDDDDDD133■■■■■QUUeffffffff333はめめめめめめ+\"★▥▥DDDDDDDDDDDDDDDDDDDDDDDDDDDDD■133■■■■■UUefffffff333はめめめめめめ+\"★▥▥DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDツ■133■■■■QUeffffff333はめめめめめめ+\"★▥▥DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDコツ■133■■■■Uefffff333はめめめめめめ+\"★▥▥DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDUコツ■133■■■■effff333はめめめめめめ+\"★▥▥DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD3Uコツ■133■■■■fff333はめkへめめめ+\"★▥▥DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD13Uコツ■133■■■af633はめkfへめめ+\"★▥▥DDDDDDDDDDDDD⁴@DDDDDDDDDDDDDDDDDDDD■13Uコツ■133■■1333はめkffへめ+\"★▥▥DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDDDDDDDDD■■13Uコツ■1333333はめkfffめ+\"★▥▥DDDDDDDDDDDDD⁴\0\0\0@DDDDDDDDDDDDDDDDDDD■■■13Uコツ■13333はめkfffめ+\"★▥▥DDDDDDDDDDDDD⁴\0\0\0\0\0DDDDDDDDDDDDDDDDDDD\"■■■13Uコツ■133はめkfffめ+\"★▥▥DDDDDDDDDDDDD⁴\0\0\0\0\0\0@DDDDDDDDDDDDDDDDDD\"\"■■■13Uコツ■13めkfffめ+\"★▥▥DDDDDDDDDDDDD⁴\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDDD\"\"\"■■■13Uコツ■1はkffめ+\"★▥▥DDDDDDDDDDDDD⁴\0\0\0\0\0\0\0\0\0@DDDDDDDDDDDDDDDDD\"\"\"\"■■■13Uコツ5はkfめ+\"★▥▥DDDDDDDDDDDDD⁴\0\0U\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDD\"\"\"\"\"■■■13Uコ53ク3#\"★▥▥DDDDDDDDDDDDD⁴\0\0\0\0\0\0\0\0\0\0\0\0@DDDDDDDDDDDDDDDDD$Bモモモモモモモモモモモ3モモモ▥モモNDDDDDDDDDDD⁴\0\0U\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDDDノ~wwモwwwモ~wフモ~wフモ~wNDDDDDDDDDD⁴\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮DDDDDDDDDDDDDDDDDDヌwDwモDwDモwDwモwDwモwtモNDDDDDDDD⁴\0\0U\0\0\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDDD$ヌwwwモモwモモwモDモwモwモtw~NDDDDDDD⁴\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■D$ヌwDDモモwモモwモモモwモwモwtwNDDDDDD⁴\0\0U\0\0\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■D$ヌwモモモモwモモwモwモwモwモwNGNDDDDD⁴\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0D$ヌwフ$ヌwwwモwwwモwwwモwwwNDDDD⁴\0\0U\0\0\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0D$ヌwフ$ヌwwwモtwGモtwGモtwtNDDD⁴\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0D$ヌDノ$ヌDDDモNDノモNDノモNDNNDD⁴\0\0U\0\0\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0D$ヌモモ$ヌモモモ.モモモ\"モモモ\"モモモNDD\r\0⁸P⁵\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0D$\"\"B$\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"BDDDオ\0\0\0\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0DD\"モモモヌモモモモモモモモモ.\"ヌモ.BDDD\0\r\0\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0DDヌ~wフモwモwモwwwモwN$ヌwNDDDD\0オ\0\0\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0D$ヌwDwモwモwモDwDモwN$ヌwNDDDD\0\0\r\0\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0D$ヌwモDモwwwモモwモモwN$ヌwNDDDD\0\0オ\0\0\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0D$ヌwモモモwDwモモwモモwモモモwモモNDD²\0\0\r\0\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0D$ヌwモwモwモwモモwモモwモwモwモwNDD\"²\0オ\0\0\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0D$ヌwwwモwモwモwwwモwwwモwwwNDD$\"²\0\r\0▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0D$ヌtwGモwモwモwwwモtwwモtwwNDDDD\"²オ▮■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0D$ヌNDノモDモDモDDDモNDDモNDDNDDDDD\"□■DDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0D$\"モモモヌモモモモモモモ.モモモ.モモモNDDDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0D$\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"BDDDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DD\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"\"BDDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDtGtwDGGtwDwGtwDDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDGDttDGGttDGDttDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDFDdFDFFdFDfDdFDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDFFddDFFddDFDddDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDfFddDdFdfDfFddDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
poke(0x8000,ord(bgdat,1,#bgdat))

-- fgdat (from anim8.p8)
fgdat="DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD⁘■■■■■■■■\0\0\0\0\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD⁘■■■■■■■■■¹\0\0\0\0DDDDDDDDDDDDDDDDDDDルDDDDDDDDDDDDDDDDDDDDDDDDDDDD⁘■■■■■■■■■■¹\0\0\0\0DDD◝ODDDDDDDDDD⁘DDル◜DDDDDDDDDDD⁘DDDDDODDDDDDDDD⁘■■■■■■■■■■■■\0\0\0\0DD◝◝DDDDDDDDDD⁘■DD◝◝DDDDDDDDDD⁘■DDDDヤODDDDDDDD⁘■■■■■■■■■■■■■\0\0\0\0Dル◝◝NルDDDDDDD⁴\0■Dル◝◝NルDDDDDDD⁴\0■DDD◝◝ODDDDDDD⁴\0■■■■■■■■■■■¹\0\0\0\0\0Dル◝◝ヤモDDDDDDD■¹▮Dル◝◝ヤモDDDDDDD■¹▮DDモ◝◝ヤDDDDDDD■¹▮■■■■■■■■■\0\0\0\0\0\0\0D◝◝◝◝NDDDDDD⁘■■\0D◝◝◝◝NDDDDDD⁘■■\0DD◝◝◝◝◜ODDDDD■■\0■■■■■■■\0\0\0\0\0\0\0\0\0D◝◝◝ヤDDDDDDD⁘■■¹D◝◝◝ヤDDDDDDD⁘■■¹DDル◝◝◝ヤDDDDD⁘■■¹▮■■■■\0\0\0\0\0\0\0\0\0\0\0Dル◝ヤモLDDDDDD⁘■■■Dル◝ヤモLDDDDDD⁘■■■DDル◝◝◝NDDDDD⁘■■■▮■■■\0\0\0\0\0\0\0\0\0\0\0\0DD◝モアLDDDDDD■■■■DD◝モアLDDDDDD■■■■DDD◝◝モウDDDDD⁘■■■\0▮\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDノアチツDDDDDD■■■■DDノアチツDDDDDD■■■■DDDルヤウアDDDDD■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDろアツイアLDDD⁘■■■¹DDろアツイアLDDD⁘■■■¹DDDDウアツイDDDD■■■¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDチイアアアLDD⁘■■¹▮DDDチイアアアLDD⁘■■¹▮DDDDアチツアアDD⁘■■¹▮¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDキイアアアアLD⁘■■\0\0DDDキイアアアアLD⁘■■\0\0DDDDチイアアアLD⁘■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDD\"ツイアアアアL■■¹\0\0DDD\"ツイアアアアL■■¹\0\0DDDDキイアアアアL■■¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDD$■ツアアアア、■¹\0\0\0DDD$■ツアアアア、■¹\0\0\0DDDD□ツイアアアア■¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDD□カツアアア■■¹\0\0\0DDDD□カツアアア■■¹\0\0\0DDDD$■ツアアアア■¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDD$■カツアア■■\0\0\0\0DDDD$■カツアア■■\0\0\0\0DDDD$■カツアア、■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDD□■カツ。■¹\0\0\0\0DDDDD□■カツ。■¹\0\0\0\0DDDDD□■カツア■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDD■■■■¹\0\0\0\0\0DDDDDD■■■■¹\0\0\0\0\0DDDDDD■■■ツ■¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDD⁘■■■\0\0\0\0\0\0DDDDDD⁘■■■\0\0\0\0\0\0DDDDDD⁘■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDD■■\0\0\0\0\0\0\0DDDDDDD■■\0\0\0\0\0\0\0DDDDDDD■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDD⁘\0\0\0\0\0\0\0\0DDDDDDD⁘\0\0\0\0\0\0\0\0DDDDDDD⁘■¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDD\0\0\0\0\0\0\0\0DDDDDDDD\0\0\0\0\0\0\0\0DDDDDDDD¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDD\0\0\0\0\0\0\0DDDDDDDDD\0\0D⁴\0\0\0DDDDDDDDD\0\0\0D\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDD\0\0\0\0DDDDDDDDDDDDD\0\0\0DDDDDDDDDDDDDD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDD\0\0\0\0DDDDDDDDDDDDD\0\0\0DDDDDDDDDDDDDD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDD⁴\0\0\0DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDDD⁴\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDD⁴\0\0\0DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDDD⁴\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDD⁴\0\0\0DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDDD⁴\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDD⁴\0\0\0DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDDD⁴\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDD░☉☉☉☉HDDDDDDDDDD\0\0\0\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDモ☉(\"\"\"\"\"DDDDDDDDD\0\0\0\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDモ🅾️☉\"\"■■■\"\"\"DDDDDDDD\0\0\0\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDノ🅾️☉\"\"■■■■■■\"DDDDDDDD\0\0\0\0DDDDDDDDDDDDDDD⁘DDDDDDDDDDDDDDD⁘DDDDDDDモモ☉☉\"■■■■■■\0\0ADDDDDDD\0\0\0\0DDDDDDDDDDDDDD⁘■DDDDDDDDDDDDDD⁘■DDDDDDノモ🅾️☉(□■¹■\0\0\0\0\0\0ADDDDDD\0\0\0\0DDDDDDDDDDDDD⁴\0■DDDDDDDDDDDDD⁴\0■DDDDDノモモ☉☉\"■■¹\0\0\0\0\0\0\0\0DDDDDD\0\0\0\0DDDDDDDDDDDDD■¹▮DDDDDDDDDDDDD■¹▮DDDDDモモ🅾️☉(□■\0\0\0\0\0\0\0\0\0\0@DDDDD\0\0\0\0DDDDノODDDDDD⁘■■\0DDDDDDDDDDDD⁘■■\0DDDDノモモ☉☉\"■■\0\0\0\0\0\0\0\0\0\0\0DDDDD\0\0\0\0DDDノ◝ODDDDDD⁘■■¹DDDノ◝NDDDDDD⁘■■¹DDDDモモn☉(□■¹\0\0\0\0\0\0\0\0\0\0\0@DDDD\0\0\0\0DDDル◝ヤDODDDD⁘■■■DDDル◝ヤDODDDD⁘■■■DDDDモモn☉(□■\0\0\0\0\0\0\0\0\0\0\0\0\0DDDD\0\0\0\0DDD◝◝◝◜NDDDD■■■■DDD◝◝◝◜NDDDD■■■■DDDノモモf☉\"▮■\0\0\0\0\0\0\0\0\0\0\0\0\0@DDD\0\0\0\0DDノ◝◝◝ヤDDDDD■■■■DDノ◝◝◝ヤDDDDD■■■■DDDモモモ●☉\"▮¹\0\0\0\0\0\0\0\0\0\0\0\0\0▮DDD\0\0\0\0DDル◝◝◝ウDDDDD■■■¹DDル◝◝◝ウDDDDD■■■¹DDDモモ~●(²▮\0\0\0\0\0\0\0\0\0\0\0\0▮¹\0DDD\0\0\0\0DDD◝◝モアLDDDD■■¹▮DDD◝◝モアLDDDD■■¹▮DDノモモ~☉(²■\0\0\0\0\0\0\0\0\0\0\0\0\0■\0@DD\0\0\0\0DDDルヤウアツDDD⁘■■\0\0DDDルヤウアツDDD⁘■■\0\0DDノモモw☉(\0■\0\0\0\0\0\0\0\0\0\0\0\0\0■\0@DD\0\0\0\0DDDDモアチツLDD⁘■¹\0\0DDDDモアチツLDD⁘■¹\0\0DDモモモ♥☉\"▮■\0\0\0\0\0\0\0\0\0\0\0\0\0■¹@DD\0\0\0\0DDDDろアツアアDD⁘■\0\0\0DDDDろアツアアDD⁘■\0\0\0DDモモモ♥☉\"▮¹\0\0\0\0\0\0\0\0\0\0\0\0\0▮■\0DD\0\0\0\0DDDD⁘ツアアアアD⁘¹\0\0\0DDDD⁘ツアアアアD⁘¹\0\0\0Dノモモモ.\"\0▮¹\0\0\0\0\0\0\0\0\0\0\0\0\0▮■\0DD\0\0\0\0DDDD⁘カイアアアL■¹\0\0\0DDDD⁘カイアアアL■¹\0\0\0Dノモモモ🅾️(\0■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■\0@D\0\0\0\0DDDDD■ツイアアア■\0\0\0\0DDDDD■ツイアアア■\0\0\0\0Dノモモモ🅾️(\0■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■¹@D\0\0\0\0DDDDD⁘■ツイア、¹\0\0\0\0DDDDD⁘■ツイア、¹\0\0\0\0DDモモモ🅾️(\0■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮¹@D\0\0\0\0DDDDDD■■ツア■¹\0\0\0\0DDDDDD■■ツア■¹\0\0\0\0DDノモモ(\"\"□\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮¹@D\0\0\0\0DDDDDD⁘■■■■\0\0\0\0\0DDDDDD⁘■■■■\0\0\0\0\0DDノモモ(\"\"□\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮¹\0D\0\0\0\0DDDDDDD■■■■\0\0\0\0\0DDDDDDD■■■■\0\0\0\0\0DDノモモ(\"R%²\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮¹\0D\0\0\0\0DDDDDDD⁘■■\0\0\0\0\0\0DDDDDDD⁘■■\0\0\0\0\0\0DDノモ🅾️(\"\"R■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0D\0\0\0\0DDDDDDDD■\0\0\0\0\0\0\0DDDDDDDD■\0\0\0\0\0\0\0DDノモ☉☉☉\"□‖¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0D\0\0\0\0DDDDDDDDD\0\0\0\0\0\0\0DDDDDDDDD\0\0\0\0\0\0\0DDノ🅾️☉☉☉(■Q¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0D\0\0\0\0DDDDDDDDD\0\0\0\0\0\0\0DDDDDDDDD\0\0\0\0\0\0\0DDノ🅾️☉☉☉(■Q\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0D\0\0\0\0DDDDDDDDD⁴\0\0\0\0\0\0DDDDDDDDD⁴\0\0\0\0\0\0DDノ☉w☉☉(□\0⁵\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0D\0\0\0\0DDDDDDDDDD\0\0\0\0\0\0DDDDDDDDDD\0\0\0\0\0\0DDノ☉w☉☉(²\0⁵\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0D\0\0\0\0DDDDDDDDDD⁴\0\0\0\0\0DDDDDDDDDD⁴\0\0\0\0\0DDノ☉☉☉☉(²\0\r\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0D\0\0\0\0DDDDDDDDDD⁴\0\0\0\0\0DDDDDDDDDD⁴\0\0\0\0\0DDノ☉☉☉☉(²\0\r\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDノ☉☉☉☉(²\0⁶\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0DDDD◜DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDノ☉☉☉☉(²\0⁶\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0DDル◝◝DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDノ☉☉☉☉(²\0\r\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0DD◝◝◝DDDDDDDDDDDDDDD⁘DDDD◝ODDDDDDDDD⁘DDノ🅾️☉☉☉\"\0オ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0¹\0Dル◝◝◝DDDヤ◝DDDDDDDDD⁘■DDDル◝DDDDDDDDD⁘■DDノ.☉☉(\"\0オ\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮¹\0DDDノ◝DDル◝ODDDDDDDD⁴\0■DDル◝◝NDDDDDDD⁴\0■DDノ.\"\"\"□¹\r\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮¹\0DDD◝◝DD◝◝ヤDDDDDDDD■¹▮DDル◝◝ヤODDDDDD■¹▮DDノモ\"□■■Q¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0▮¹\0DDDDDDD◝◝◝ノDDDDDDD■■\0DD◝◝◝◝NDDDDD⁘■■\0DDノモテ\"■■‖¹▮\0\0\0\0\0\0\0\0\0\0\0\0\0▮¹\0DDDDDDル◝◝◝◜DDDDDD⁘■■¹DD◝◝◝ヤDDDDDD⁘■■¹DDノモテ\0\0\0\0\0■\0\0\0\0\0\0\0\0\0\0\0\0\0▮¹\0DDDDDDル◝◝◝モDDDDDD⁘■■■DDル◝ヤモLDDDDD■■■■DDノモテ\"\0\0\0■■\0\0\0\0\0\0\0\0\0\0\0\0\0■¹\0DDモ◝◝DD◝◝モウDDDDDD■■■■DDD◝モアLDDDDD■■■■DDノモテ-■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0■¹\0Dル◝◝◝DDルヤウアDDDDDD■■■■DDDノアチツDDDDD■■■■DDモモテツ。■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0■¹\0D◝◝◝◝DDDウアツMDDDDD■■■¹DDDろアツイLDDD⁘■■■¹DDモモツテツツ■■\0¹\0\0\0\0\0\0\0\0\0\0\0\0■¹\0DDD◜◝DDDアチツアアDDD⁘■■¹▮DDDろツイアアLDD⁘■■¹▮DDモモツモツツ□■▮¹\0\0\0\0\0\0\0\0\0\0\0\0■\0\0DDD◝◝DDDケツアアアアDD⁘■■\0\0DDD$ツアアアアLD⁘■■\0\0DDモモテモメツ□■\0¹\0\0\0\0\0\0\0\0\0\0\0\0¹\0\0@DDDDDDD$ツイアアアアD■■¹\0\0DDD$キツアアアアL■■¹\0\0Dノモモモモメツ□■¹¹\0\0\0\0\0\0\0\0\0\0\0\0¹\0\0\0DDDDDDD$■ツアアアア、■■\0\0\0DDDD□カイアアア、■¹\0\0\0Dノテモモモメテ□■¹¹▮\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDD□カツアアア、■¹\0\0\0DDDD$■ツイアア■■¹\0\0\0Dノテモモモメテ\"カ¹¹▮\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0Dモ◝◝DDDD$■カツアア■■\0\0\0\0DDDDD□■ツアア■■\0\0\0\0DDDモモテメテ\"カ¹¹▮\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ル◝◝◝DDDDD□■カツア■¹\0\0\0\0DDDDD$■■ツ。■¹\0\0\0\0DDDDノテメテ\"カ■¹▮¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0ヤD◝◝DDDDDD■■カ。■\0\0\0\0\0DDDDDD■■■■¹\0\0\0\0\0DDDDDDノテ\"カ。¹▮¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0DD◜◝DDDDDD⁘■■■¹\0\0\0\0\0DDDDDD⁘■■■\0\0\0\0\0\0DDDDDDDテ□■。¹▮¹\0\0⁴\0\0\0\0\0\0\0\0\0\0\0DD◝◝DDDDDDD■■■\0\0\0\0\0\0DDDDDDD■■\0\0\0\0\0\0\0DDDDDDDDD¹\r\0⁘¹\0\0⁴@\0@D\0\0\0\0\0\0\0DDDDDDDDDDD⁘¹\0\0\0\0\0\0\0DDDDDDD⁘\0\0\0\0\0\0\0\0DDDDDDDDD\0\0\0⁴\0⁴DDD@DD\0\0\0\0\0\0\0DDDDDDDDDDDD\0\0\0\0\0\0\0\0DDDDDDDD\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDDDDDD\0\0\0\0\0\0\0DDDDDDDDDDDDD\0\0D⁴\0\0\0DDDDDDDDD\0\0D⁴\0\0\0DDDDDDDDDDDDDDDDDDDDD\0\0\0\0\0\0\0D◜◝◝DDDDDDDDDDDDD\0\0\0DDDDDDDDDDDDD\0\0\0DDDDDDDDDDDDDDDDDDDDD\0\0\0\0\0\0\0ル◝◝◝DDDDDDDDDDDDD\0\0\0DDDDDDDDDDDDD\0\0\0DDDDDDDDDDDDDDDDDDDDD\0\0\0\0\0\0\0Dノ◝◝DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDDDDDDDDD⁴\0\0\0\0\0\0\0Dヤ◜◝DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDDDDDDDDD⁴\0\0\0\0\0\0\0Dル◝◝DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDDDDDDDDD⁴\0\0\0\0\0\0\0DDDDDDDDDDDDDDDDD⁴\0\0DDDDDDDDDDDDD⁴\0\0"
poke(0x800,ord(fgdat,1,#fgdat))

end

function load_sp_gfx()

-- spdat "
spdat="\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0}wwwめめめめ\"\"\"\"\0\0\0\0\0\0\0\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0effv3333\"\"\"\"\0\0\0\0\0\0\0\0\0\0\0\0ニ゛f■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0⁷p\0\0\0\0\0effv3⁙■⁙\"\"\"\"\0\0\0\0\0\0w\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0p⁷\0\0\0\0\0effv1\"□■\"\"\"\"\0\0\0\0⁷pw⁷\0オ\0p■モaカ。。■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0p⁷\0\0\0\0\0effv■\"\"□\"\"\"\"\0\0\0\0wwww⁷サ\rw■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0⁷p\0\0\0\0\0effv\"\"■\"\"\"\"\"\0\0\0\0ww}wgサツw■゛v■め◀•kりa◀■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0effv\"キ□\"キ\"\"\"\0\0\0\0wgツwgfツ}■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0UUUコ\"\"-\"キ-\"\"\0\0\0\0wfツ}ffサツ■■をv■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0p…\0	\0…\0		…\0\0\0\0\0\0ffツツffサツ■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0p…▥	p…▥	▥▥\0\0\0\0\0\0ffサツツmサツ■■faほ◀▶、■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0p…➡️」p…➡️」」▥¹\0\0\0\0\0ツffツツツツツ■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0p@yqp@yq⬆️▶⁷\0\0\0\0\0ツツfツツツ]ツ■モ■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0w'\"\0p \"\0\"r\0\0\0\0\0\0ツコツツツツUコ■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0p\0☉\0wG☉\0█www\0\0\0\0]UツコツツUコニ゛■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0@\0⁴p\0⁴⬆️⁴p\0\0\0\0\0\0]U]Uツツ]ツ■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0	\0	\0\0	\0	…\0\0\0\0\0\0ツコツコ]UUU■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0カ。。ツ。。ツ■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ニ゛f▶◀v■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■モaカ。。■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\000333333333³\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDD3\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■モa◀◀ka◀■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■゛v、め◀◀■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■゛vアねka■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDD333333\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■fw■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0■■■■■■■■■■■■■■■■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0DDDDDDDDDDDDDDDD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ニ゛ツカ■。。■■■■■■■■■"
poke(0x0,ord(spdat,1,#spdat))
end
-->8

--[[


]]

tcfi=0 -- incremented on each run

function draw_tweetcart()

	cls()
	local fn=
	 tcf[1+#tcf-mid(1,tcfi,#tcf)]
--	fn=tcf[1]
	for y=0,15,1 do
		for x=0,15,1 do
		 fn(x,y)
		end
	end

end

tcf={


function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t()/2)*8,
  x*2 + sin(x/6+y/7+t()/6)*1,
  7+(x+y)%7)
end,

function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t()/2)*8,
  x*2 + sin(x/6+y/7+t()/6)*1,
  7+(x+y)%5)
end,

function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t()/4)*8,
  x*2 + sin(x/6+y/7+t()/7)*20,
  7+(x+y)%5)
end,

function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t()/4)*8,
  x*2 + sin(x/6+y/7+t()/2)*4,
  7+(x+y)%5)
end,

function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t()/2)*8,
  x*2 + sin(x/6+y/7+t())*1,
  7+(x+y)%5)
end,


function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t())*4,
  x*2 + sin(x/6+y/7+t())*1,
  7+(x+y)%5)
end,

function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t())*4,
  x*2 + sin(x/6+y/7+t())*1,
  7+(x+y)%5)
end,

function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t())*4,
  x*2 + sin(x/6+y/7+t())*1,
  7+(x*y)%5)
end,

function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t())*4,
  x*2 + sin(x/6+y/7+t())*4,
  7+(x*y)%5)
end,

function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t())*2,
  x*2 + sin(x/6+y/7+t())*2,
  7+(x*y)%3)
end,

function(x,y)
 pset(
  y*2 + cos(y/14+x/9+t())*2,
  x*2 + sin(x/6+y/7+t())*2,
  7)--+(x+y)%9)
end,

function(x,y)
 pset(
  y*2 + cos(x/9+t())*2,
  x*2 + sin(x/6+y/7+t())*2,
  7)--+(x+y)%9)
end,

function(x,y)
 pset(
  y*2 + cos(x/9+t())*2,
  x*2 + sin(x/6+y/7+t())*2,
  7+(x+y)%9)
end,

function(x,y)
 pset(
  y*2 + cos(x/9+t())*2,
  x*2 + sin(x/6+y/7+t())*2,
  12+(x+y)%5)
end,


function(x,y)
 pset(
  y*2 + cos(x/9+t())*2,
  x*2 + sin(x/6+y/7+t())*2,
  8+(x+y)%8)
end,

function(x,y)
 pset(
  x*2 + cos(x/9+t())*2,
  y*2 + sin(y/9+t())*2,
  8+(x+y)%8)
end,

function(x,y)
 pset(
  x*2 + cos(x/9+t())*2,
  y*2,
  8+(x+y)%8)
end,


function(x,y)
 pset(
  x*2 + cos(x/5+t())*2,
  y*2,
  8+(x+y)%8)
end,

function(x,y)
 pset(
  x*2,
  y*2,
  8+(x*y*t()/4)%16)
end,

function(x,y)
 pset(
  x*2,
  y*2,
  8+(x*y+t()*4)%8)
end,

function(x,y)
 pset(
  x*2,
  y*2,
  8+(x+y+t()*4)%8)
end,

function(x,y)
 pset(
  x*2,
  y*2,
  x+y)
end,



}