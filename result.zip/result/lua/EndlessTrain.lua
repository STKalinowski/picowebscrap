--endless train
--by marc-antoine renaud

--don't judge my bad code!
--
--...actually do, everybody
--needs constructive critisism
--
--todo:
--actual gameplay...?

function top_because_im_lazy()
end

debug=false

t = 0
timer = 0
hr = 0
mn = 0

char = {
	f=0,
	x=24,
	y=0,
	spd=1,
	animoffset = 0,
	flip=false,
	hold=false,
	sit=false,
	moving=false,
	intunnel=false,
	out=false
}

monologue = ""
nextmonologue = 400

hint = {
	active = false,
	key = ""
}

menu = {
	open = false,
	tweentime = 0,
	passport = {}
}

bg = {
	atmo = 12,
	env = 0,
	nxtenv = 0,
	tile={},
}

gradient = {
	time = -1,
	finish = 0,
	finished = true,
	color1 = 6,
	color2 = 7,
}

cam = {
	x=0,
	y=0
}

tunnel = {
	playing=false,
	shown=false,
	time=0,
	last=0,
	tile={},
	length=0
}

train = {
	chaka = 0,
	bump = 0,
	timetodest=0,
	timeleft=0,
	spd = 1,
	spdrel = 0,
	lane=11
}

handles = {
	f=0,
	tile={}
}

seats = {}

envdat={
	--mountains
	{ox=14, oy= 16,h=5, s=11,
	 l={5,4,3,2,2,1,1,1,1,1,2,1,1,1}
	},	
	--forest
	{ox=14, oy= 9,h=7, s=15,
	 l={5,3,5,3,4,5,3,1,3}
	},	
	--city
	{ox=14, oy= 0,h=7, s=2,
	 l={4,7,5,3,11,9,1,1}
	},
	--beach
	{ox=14, oy= 7,h=2, s=6,
	 l={2,2,1,1,1,1,2,1,1,1,1,2,3}
	}
}

world={}
visitedworld = false

start = false
startsugarcoat = 11
showprompt = true

song=false

function _init()
	bg.env = flr(rnd(4))
	bg.nxtenv = bg.env

	train.timetodest = 200
	train.timeleft = 100
	
	for i=0,18 do
		bg.tile[i] = {id=flr(rnd(6)),x=i*8,origin=i*8}
	end
	
	music(0,3000,3)
end

function _update()
	if(start)train.timeleft -= 1
 if(train.timeleft <= 0) train.timeleft = 0
	t+=1
	
	if(t == 1800) hr += 1
	hr = flr(hr)%24
	if(t%30 == 0) mn += 1
	mn = flr(mn)%60
	if(t > 1800) t=0
	
	if(song==false and char.out)then
		music(envdat[bg.env+1].s,3000)
		song=true
	elseif(song==true and not char.out)then
		music(0,6000,3)
		song=false
	end
		
	if(start)then
		char.sit=false
		char.hold=false
		
		if(btnp(4))getout()
		
		checkrun()
		
		char.moving = false	
		
		if(btn(3) and not char.out) then
			char.sit=true
		elseif(btn(2)) then
			char.f=32
			char.hold=true
		elseif(btn(0))then
			move(0)
		elseif(btn(1))then
			move(1)
		else
			char.f=0
		end
		
		if(btnp(5))then
			openmenu()
		end
		
		if(t == nextmonologue)then
			generatemonologue()
		end
		if(t == (nextmonologue+200)%1800)then
			monologue = ""
			nextmonologue = (nextmonologue+250+flr(rnd(400)))%1800
		end
		
		checkhints()	
	else
		if(btnp(4))start = true
	end

	if(train.timeleft == 1)then
		generateworld()
	end
	
	if char.out then
		continueworld()
	end
	
	train.chaka+=1
	if(train.chaka >= 32*(1+abs(train.spd-1)) and train.spd > 0)then
		sfx(4,0)
		train.chaka = 0
	end

	if(flr(rnd(300))==1 and train.spd>0.1)then
		sfx(5)
		train.bump = 1
	else
		train.bump = 0
	end

	--generate monologue
	--if(btn(5)) generatemonologue()
end

function _draw()
	cls()
	train.spdrel = abs(train.spd-1)

	if not start then
		if(train.bump==1)startsugarcoat = 8+flr(rnd(4))
		pal(11,startsugarcoat)
		sspr(56,96,56,24,36,10+train.bump)
		pal()
		if(t%24 == 0)then
			showprompt = not showprompt
		end
		if(showprompt)print("press action",40,40,7)
	end

	
	drawbg()
	drawworld()
	drawcharandtrain()
	if(start)then
		drawhud()
		drawmonologue()	
		drawhint()
		drawmenu()
	end
end

function generateworld()
	local env = envdat[bg.env+1]
	visitedworld = false

	for i=0,12 do
		if(i==0) then
			lx = 132
		else
			lst = world[i-1]
			p = flr(rnd(#env.l))+1
			while(p == lst.prst)do
				p = flr(rnd(#env.l))+1
			end
			if(i-1 == 0)then
				lx = flr(rnd(8))
								+lst.x
			else
				lx = flr(rnd(8))
								+lst.x
								+(env.l[lst.prst]
								*8)
			end
		end
		world[i] = {prst=p, x=lx}
	end
	
	if(bg.env == 0)then
		sprite = 47
	elseif(bg.env == 1)then
		sprite = 62
	elseif(bg.env == 2)then
		sprite = 46
	elseif(bg.env == 3)then
		sprite = 63
	end
	
	stampx = 22+flr(rnd(77))
	stampy = 136+flr(rnd(53))
	
	if(stampx>=54 and stampx<=66)then
		if(stampx<=60)then
			stampx = 54
		else
			stampx = 66
		end
	end
	
	stamp = {s=sprite, x=stampx, y=stampy}
	add(menu.passport, stamp)
	
end

--this is hell waiting to happen
function continueworld()
	local env = envdat[bg.env+1]
	lst = world[#world]
	
	if(char.x+127 >= lst.x)then
		p = flr(rnd(#env.l))+1
		while(p == lst.prst)do
			p = flr(rnd(#env.l))+1
		end
		lx = flr(rnd(8))
							+lst.x
							+(env.l[lst.prst]
							*8)
		world[#world+1] = {prst=p, x=lx}
	end
end

--hardcoding seats? never!
function addseats()
	if(#seats == 0)then
		for j=0,127 do
			if(pget(j,54-train.bump)==6 and j%8==0)then
				add(seats, {x=j})
				add(seats, {x=j-7})
			end
		end
	end
	
	if(char.flip)then
	 flippos = 4
	else
		flippos = 0
	end
	
	for seat in all(seats)do
		if(char.sit and seat.x<=char.x+flippos and seat.x+6>=char.x+flippos) char.f=33
		spr(24,seat.x,64-train.bump)
	end
end

--hardcoding handles? neveeer!
function addhandles()
	if(#handles.tile == 0)then
		for j=0,127 do
			if(pget(j,54-train.bump)==6 and j%4==0)then
				add(handles.tile, {x=j-3})
			end
		end
	end
	
	if(t%16==0) handles.f+=1
	if(handles.f>=2) handles.f=0
	
	if(char.flip)then
	 hldpos = 2
	else
		hldpos = -1
	end
	
	for tile in all(handles.tile) do
		if(char.hold and tile.x-1<=flr(char.x)+hldpos and tile.x+1>=flr(char.x)+hldpos) then
			spr(8,tile.x,53-train.bump)
		else
			spr(8+handles.f,tile.x,53-train.bump)
		end
	end
end

function addtunnel(len)
	if(len*5<train.timeleft)then
		tunnel.length=len
		tunnel.tile = {}
		for l=0,len do
			tunnel.tile[l] = {x=l*8+128}
		end
		return true
	else
		return false
	end
end

--this one's a mess...
function drawcharandtrain()
	if(char.out)then
		cam.x = flr(char.x-64)
	else
		rectfill(0-(train.spdrel*10),0,9-(train.spdrel*10),127,0)
		rectfill(118+(train.spdrel*10),0,127+(train.spdrel*10),76,0)
		cam.x = 0
	end	
	
	camera(cam.x,cam.y)
	
	if(cam.x == 128)train.lane = 8+flr(rnd(4))
	
	if(train.spd < 0.5)then
		if(not char.out)then
			spr(char.f+char.animoffset,char.x,58-train.bump+char.y,1,1,char.flip)
			spr(char.f+16+char.animoffset,char.x,66-train.bump+char.y,1,1,char.flip)
		end
		addseats()
		pal(0,1)
		pal(1,5)
		pal(2,5)
		pal(4,train.lane)
		pal(13,6)
		map(0,0,8,52-train.bump,14,3)
		pal()
		if(char.out)then
			spr(char.f+char.animoffset,char.x,58-train.bump+char.y,1,1,char.flip)
			spr(char.f+16+char.animoffset,char.x,66-train.bump+char.y,1,1,char.flip)
		end
	else
		pal(5,6)
		map(0,0,8,52-train.bump,14,3)
		addhandles()
		pal()
		addseats()
		spr(char.f+char.animoffset,char.x,58-train.bump+char.y,1,1,char.flip)
		spr(char.f+16+char.animoffset,char.x,66-train.bump+char.y,1,1,char.flip)
	end
	
	if(train.timeleft == 0)then
		train.spd = 0
		map(0,3,8,42,14,5)
	elseif(train.timeleft <= 100)then
		tween = sin((1-train.timeleft/100)/4)+1
		train.spd = tween
		map(0,3,8+128*tween,42,14,5)
	elseif(train.timetodest-train.timeleft <= 100)then
		tween = 1-cos(((train.timetodest-train.timeleft)/100)/4)
		train.spd = tween
		map(0,3,8-128*tween,42,14,5)
	else
		if(train.timeleft == tunnel.time)
	 then
			changebg(flr(rnd(4)))
		end
		--old broken system
		--if(train.timeleft == train.timeleft+flr(rnd(100))
		--and not tunnel.shown
		--and train.timeleft-tunnel.last>150+rnd(90)) then
		--	changebg(flr(rnd(4)))
		--end
	end
end

function drawtunnel()
	tunmin = 128
	tunmax = 0
	for tile in all(tunnel.tile) do		
		tunmin = min(tunmin,tile.x)
		tunmax = max(tunmax,tile.x)
		if(tile.x < 128 and tile.x > 0)then
			spr(78,tile.x,52)
			spr(94,tile.x,60)
		end
		tile.x-=5*train.spd
		if(tile.x <= -16)then
			tunnel.length-=1
			del(tunnel.tile, tile)
		end
	end
	if(tunnel.length == 1) tunnel.last = t
	if(tunnel.length == 0)then 
		tunnel.shown = false
	else
		tunnel.shown = true
	end
	if(char.x+8 >= tunmin and char.x <= tunmax)then
			char.intunnel = true
		else
			char.intunnel = false
	end	
	playtunnel()
end

function drawworld()
	local env = envdat[bg.env+1]
	local mappos = {}
	
	for i=0,#env.l do
		if(i==0)then
			mappos[i] = env.ox
		else
			mappos[i] = mappos[i-1]+env.l[i]
		end
	end

	if char.out then
		for struct in all(world) do
			if(struct.x+(env.l[struct.prst]*8) > char.x - 75
			and struct.x < char.x +75)then
				map(
				mappos[struct.prst-1],
				env.oy,
				struct.x,
				77-(env.h*8),
				env.l[struct.prst],
				env.h
				)
			end
		end
	end

end

function drawbg()
	i=0
	newtile = nil
	lasttile = 0
	firsttile = 300

	--day/night cycle? yeaaah..
 if(mn==30 and gradient.finished)then
 	startgradient(0,bg.atmo)
 end
	if(mn==0 and gradient.finished)then
		startgradient(12,bg.atmo)
	end

	rectfill(-1+cam.x,57-(train.spdrel*57),128+cam.x,67+(train.spdrel*9),bg.atmo)
	drawgradient()
	
	for tile in all(bg.tile) do
		if not char.out and train.spd != 0 then
			tile.x-=0.2*train.spd
			tile.origin = tile.x
		end
		
		tile.x=tile.origin+(cam.x-cam.x/20)
		
		spr(tile.id+64+bg.env*16,flr(tile.x),60+(train.spdrel*9))	
		
		if(char.out and char.flip)then
			if(tile.x>=cam.x+128)then
				newtile = tile
			end
		elseif(tile.x<=cam.x-16) then 
			newtile = tile
		end
		
		if(tile.origin > lasttile)then
			lasttile = tile.origin
		end
		
		if(tile.origin < firsttile)then
			firsttile = tile.origin
		end
		
	end
	
	if newtile != nil then
		bgid=flr(rnd(6))
		if(char.flip and char.out)then
			add(bg.tile, {id=bgid, x=firsttile-8+cam.x, origin=firsttile-8})
		else
			add(bg.tile, {id=bgid, x=lasttile+8+cam.x, origin=lasttile+8})
		end
		del(bg.tile, newtile)
		newtile = nil
	end
	
	if(t-timer >= 40/train.spd) then
		bg.env=bg.nxtenv
	end
	
	drawtunnel()
	
end

function changebg(env)
	timer=t
	
	if(bg.env==env)env = (env+1)%4
	
	if(addtunnel(64+flr(rnd(64))))then
		bg.nxtenv=env
	end
end

function startgradient(c1,c2)
	gradient.finished = false
	gradient.time = 0
	gradient.finish = 320
	gradient.color1 = c1
	gradient.color2 = c2
end

function drawgradient()
	g = gradient
	c1 = g.color1
	c2 = g.color2
	
	clip(0,57-(train.spdrel*57),128,11+(train.spdrel*66))
	
	pal(6,c1)
	pal(7,c2)
	
	if not g.finished then		
		for y=0,15 do
			for x=0,15 do
				if(y==flr(g.time*15/g.finish))then
					spr(52,x*8+cam.x,y*8)
					spr(53,x*8+cam.x,y*8-8)
					spr(54,x*8+cam.x,y*8-16)
				elseif(y<flr(g.time*15/g.finish))then
					spr(55,x*8+cam.x,y*8-16)
				end
			end
			g.time+=1
		end
		
		if (g.time >= g.finish) then
			bg.atmo = c1
			g.finished = true
			g.start = -1
		end
	end
	
	clip()
	pal()
end

function drawhud()
	--[[debug]]
	if(debug)then
		print("",cam.x,0,8)
		print("ram:" .. stat(0))
		print("cpu:" .. stat(1))
		--print("last tunnel:" .. tunnel.last)
		--print("#tunnel:" .. tunnel.length)
		print("time:" .. t)
		--print("delay:" .. t-tunnel.last)
		--print("bg tiles:" .. #bg.tile)
		print("char.x:" .. char.x)
		--print("char.y:" .. char.y)
		--print("#world:" .. #world)
		print("tunnel time:" .. tunnel.time)
	end
	
	rectfill(0+cam.x,77,127+cam.x,127,0)
	
	line(16+cam.x,90,111+cam.x,90,11)

	if(train.timeleft == 0)then
		minitrainpos = 88
	else
		minitrainpos = 88-(train.timeleft/train.timetodest)*88
	end
	
	spr(40,16+minitrainpos+cam.x,84)
	
	if(hr<10) hr="0" .. hr
	if(mn<10) mn="0" .. mn
	
	print(hr .. ":" .. mn,54+cam.x,80,1)
end

function drawmonologue()
	if(monologue != "")then
		x = 64-#monologue*2+cam.x
		y = 20
		
		--corners
		spr(43,x-4,y-4)
		spr(43,x+#monologue*4-6,y-4,1,1,true)
		spr(43,x+#monologue*4-6,y+1,1,1,true,true)
		spr(43,x-4,y+1,1,1,false,true)
		--center
		rectfill(x+3,y-4,x+#monologue*4-6,y+8,7)
		--text
		print(monologue,x,y,0)
		
		--bubbles
		if not char.out then
			circfill(char.x+3,55,2,7)
			circfill((char.x+2)-(char.x-62)/4,46,3,7)
			circfill((char.x+2)-(char.x-62)/2,35,4,7)
		else
			circfill(x+#monologue*2+2,55,2,7)
			circfill(x+#monologue*2,46,3,7)
			circfill(x+#monologue*2-1,35,4,7)
		end
	end
end

function drawhint()
	if hint.active then
		sspr(64,24,8,8,char.x,char.y+49,8,9)
		print(hint.key,char.x+2,char.y+51,7)
	end
end

function drawmenu()
	--passport tab
	spr(59,34+cam.x,120)
	rectfill(42+cam.x,120,85+cam.x,127,5)
	line(42+cam.x,120,85+cam.x,120,6)
	spr(59,85+cam.x,120,1,1,true)
	print("passport(x)",42+cam.x,122,7)
	line(35+cam.x,128,91+cam.x,128,6)

	tweenlength = 60
	if(menu.open)then
		if(menu.tweentime < tweenlength)then
			menu.tweentime += 1 
		end
		cam.y = -sin((menu.tweentime/tweenlength)/4)*78
	else
		if(menu.tweentime > 0)then
			menu.tweentime -= 1
		end
		cam.y = 78-cos((menu.tweentime/tweenlength)/4)*78
	end
	
	if(menu.tweentime > 0)then
		--passport
		--left side
		spr(44,16+cam.x,136)
		sspr(96,24,8,8,16+cam.x,144,8,48)
		spr(44,16+cam.x,190,1,1,false,true)
		
		--center
		rectfill(24+cam.x,136,104+cam.x,197,7)
		sspr(104,16,8,8,60+cam.x,137,8,60)
		
		--right side
		spr(44,104+cam.x,136,1,1,true)
		sspr(96,24,8,8,104+cam.x,144,8,48,true)
		spr(44,104+cam.x,190,1,1,true,true)
		
		--stamps
		for stamp in all(menu.passport) do
			spr(stamp.s,stamp.x+cam.x,stamp.y)
		end
	end	
end

function playtunnel()
	if(char.intunnel and tunnel.playing)then
		return
	elseif(char.intunnel and not tunnel.playing)then
		sfx(7,3)
		tunnel.playing=true
	else
		sfx(15,3)
		sfx(-2,3)
		tunnel.playing=false
	end
end

function checkhints()
	hint.active = false
	
	--doors hint
	if(train.spd == 0
		and char.spd == 1
		and( 
			(char.x >= 29 
			and char.x <= 46)
			or  
			(char.x >= 77
   and char.x <= 94)
		)	
	)then
		sethint("z")
	end
end

function sethint(key)
	hint.active = true
	hint.key = key
end

--was this really necessary? xp
function openmenu()
	menu.open = not menu.open
end

function getout()
	if(train.spd == 0
		and
			char.spd == 1
		and( 
			(char.x >= 29 and char.x <= 46)
			or  
			(char.x >= 77 and
    char.x <= 94)
		)	
	)then
		char.out=not char.out
		visitedworld = true
		if(not char.out and visitedworld)then
			world = {}
			train.timetodest = 800+flr(rnd(1000))
			if(train.timeleft == 0)then
				train.timeleft = train.timetodest
				tunnel.time = train.timetodest-200-flr(rnd(300))
			end
		end
	end
end

function checkrun()
	if(btn(4) and char.moving)then
		char.animoffset = 11
		char.spd = 2	
	else
		char.animoffset = 0
		if(char.f > 4)char.f = 0
		char.spd = 1
	end
end

function move(d)
	char.moving = true
	if(d==0 and (char.x>=9 or char.out)) then
		char.x-=0.4*char.spd
		char.flip = true
	end
	if(d==1 and (char.x<=113 or char.out)) then
		char.x+=0.4*char.spd
		char.flip = false
	end
	
	local xflr = flr(char.x)
	--i'm lazy >.<
	if(xflr==114 or xflr == 6)char.y=1
	if(xflr==115 or xflr == 5)char.y=2
	if(xflr==116 or xflr == 4)char.y=3
	if(xflr>=117 or xflr <= 3)char.y=4
	
	if(xflr<=114 and xflr >= 6)char.y=0

	if(t%8==0) char.f+=1
	if(char.f>=4) char.f=0
end

--monologue engine
function generatemonologue()
	if(char.x <= -32)then
		monologue = "there's nothing here."
		return
	end
	
	if(char.x >= 800 and not char.flip)then
		if(char.x >= 1200)then
			if(char.x >= 1600)then
				if(char.x >= 2000)then
					monologue = "go back."
					return
				end
				monologue = "there's no other station."
				return
			end
			monologue = "i'm way too far."
			return
		end
		monologue = "i should go back."
		return
	end
	
	subject = {
	 "i"
	}

	verb = {
		"like",
		"love",
		"hate",
		"miss",
		"want",
		"need"
	}

	object = {
		"potatoes",
		"love",
		"this",
		"that",
		"the mountains",
		"the city",
		"the temple",
		"the forest",
		"videogames",
		"cats",
		"dogs",
		"birds",
		"benches",
		"water",
		"soda",
		"burgers",
		"pizza",
		"hot-dogs",
		"candies",
		"my home",
		"money",
		"bikes",
		"snacks",
		"shoes",
		"friends",
		"books",
		"trees",
		"people",
		"her",
		"tacos",
		"sushis",
		"hats",
		"fun",
		"computers",
		"music",
		"glasses"
	}

	s = flr(rnd(#subject))+1
	v = flr(rnd(#verb))+1
	o = flr(rnd(#object))+1
	monologue = subject[s] .. " " ..
													verb[v] .. " " ..
													object[o] .. "."
end









