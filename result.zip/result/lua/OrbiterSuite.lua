-- orbiter suite
-- by kittenm4ster

-- cover art
-- and choreography assistance
-- by aubrianne anderson

-- global constants
master_planet_palette = {
  4, 7, 8, 9, 11, 12, 13, 14, 15
}
trail_palette = {14, 8, 9}
locomotion_dot_palette = {9, 10}
maxsq = 180
gc = 1
pi = 3.14159
min_path_spacing = 7
max_path_spacing = 13
min_planet_r = 2
max_planet_r = 7
path_r_limit = 59
fps = 60
min_stars = 33
max_stars = 90
note_pitch_mask = 0b00111111
center_accel_limit = { -- keyed by radius
  [2] = 0.26315,
  [3] = 0.15543,
  [4] = 0.13157,
  [5] = 0.11526,
  [6] = 0.09471,
  [7] = 0.08918,
}
pat30ticks = (24 * 36)


-- index boost sfx pitch offsets by pattern number
pattern_pitch_offset = {
  -- mvmt i
  [0] = 0,
  [5] = -2,
  [6] = -3,

  -- mvmt ii
  [9] = 0,
  [12] = -2,
  [13] = -3,
  [14] = 4,
  [15] = 2,
  [16] = 4,
  [17] = 2,

  -- mvmt iii
  [20] = 0,
  [22] = 5,
  [23] = 8,
  [24] = 2,
  [25] = 5,
  [26] = 8,
  [27] = 0,

  -- finale
  [30] = 0
}


-- fade table adapted from
-- http://kometbomb.net/pico8/fadegen.html
-- creditz to kometbomb :)
fade_table = {
  {1,1,1,1,1,1,1,0,0,0,0,0,0,0,0},
  {2,2,2,2,2,2,1,1,1,0,0,0,0,0,0},
  {3,3,3,3,3,3,1,1,1,0,0,0,0,0,0},
  {4,4,4,2,2,2,2,2,1,1,0,0,0,0,0},
  {5,5,5,5,5,1,1,1,1,1,0,0,0,0,0},
  {6,6,13,13,13,13,5,5,5,5,1,1,1,0,0},
  {7,6,6,6,6,13,13,13,5,5,5,1,1,0,0},
  {8,8,8,8,2,2,2,2,2,2,0,0,0,0,0},
  {9,9,9,4,4,4,4,4,4,5,5,0,0,0,0},
  {10,10,9,9,9,4,4,4,5,5,5,5,0,0,0},
  {11,11,11,3,3,3,3,3,3,3,0,0,0,0,0},
  {12,12,12,12,12,3,3,1,1,1,1,1,1,0,0},
  {13,13,13,5,5,5,5,1,1,1,1,1,0,0,0},
  {14,14,14,13,4,4,2,2,2,2,2,1,1,0,0},
  {15,15,6,13,13,13,5,5,5,5,5,1,1,0,0}
}

-- start button library
buttons = {}
for i = 0, 5 do
  buttons[i] = {
    down = false
  }
end
function update_buttons()
  for i, b in pairs(buttons) do
    if btn(i) then
      if not b.down then
        b.down = true
        btn_pushed(i)
      end
    else
      if b.down then
        b.down = false
        btn_released(i)
      end
    end
  end
end
-- end button library

-- start timer library
function create_timer(frames)
  return {
    length = frames,
    value = frames,
    reset = function(self)
      self.value = self.length
    end,
    update = function(self)
      if self.value > 1 then
        self.value -= 1
      else
        return true
      end
    end
  }
end
-- end timer library

-- start vec2 vector library
vec2 = {}
vec2.__index = vec2
vec2.__add = function (a, b)
  if type(a) == 'number' then
    return vec2.new(a + b.x, a + b.y)
  elseif type(b) == 'number' then
    return vec2.new(a.x + b, a.y + b)
  else
    return vec2.new(a.x + b.x, a.y + b.y)
  end
end
vec2.__sub = function (a, b)
  if type(a) == 'number' then
    return vec2.new(a - b.x, a - b.y)
  elseif type(b) == 'number' then
    return vec2.new(a.x - b, a.y - b)
  else
    return vec2.new(a.x - b.x, a.y - b.y)
  end
end
vec2.__mul = function (a, b)
  if type(a) == 'number' then
    return vec2.new(a * b.x, a * b.y)
  elseif type(b) == 'number' then
    return vec2.new(a.x * b, a.y * b)
  else
    return vec2.new(a.x * b.x, a.y * b.y)
  end
end

function vec2.new(x, y)
  local obj = {
    x = x or 0,
    y = y or 0
  }

  setmetatable(obj, vec2)
  return obj
end

function vec2:magsq()
  return (self.x * self.x) + (self.y * self.y)
end

function vec2:magnitude()
  return sqrt(self:magsq())
end

function vec2:str()
  return '(' .. self.x .. ', ' .. self.y .. ')'
end

function vec2:sqrt()
  return vec2.new(sqrt(self.x), sqrt(self.y))
end

function vec2:copy()
  return vec2.new(self.x, self.y)
end

function vec2:dot(v)
  return (self.x * v.x) + (self.y * v.y)
end

function vec2:normalize(n)
  local n = n or 1
  local m = self:magnitude()
  if m ~= 0 then
    self.x = (self.x / m) * n
    self.y = (self.y / m) * n
  end
end

function vec2:normalized()
  local v = self:copy()
  v:normalize()
  return v
end

function vec2:limit(max)
  if (self:magsq() > max * max) then
    self:normalize(max)
  end
end

function vec2:dot(v)
  return (self.x * v.x) + (self.y * v.y)
end

function vec2:rotate(angle, origin)
  local c = cos(angle)
  local s = sin(angle)

  self.x -= origin.x
  self.y -= origin.y

  local rx = (self.x * c) - (self.y * s)
  local ry = (self.x * s) + (self.y * c)

  rx += origin.x
  ry += origin.y

  self.x = rx
  self.y = ry
end

function vec2:rotated(angle, origin)
  local v = self:copy()
  v:rotate(angle, origin)
  return v
end
-- end vec2 library

function _init()
  channelnote = {}
  original_pitches = {}
  currentpattern = -1

  player = create_player()
  conduct_cr = cocreate(conduct)

  prompttimer = create_timer(2 * fps)
  promptfadev = 0

  hidingtimer = create_timer(0)
  numplanets = 5

  stars = {}
  for i = 1, min_stars do
    add_star()
  end

  camy = 0
  state = 'intro'
  restart()
end

function restart()
  bodies = {player}
  planets = {}
  disabledplanets = {}
  planet_palette = shallow_copy(master_planet_palette)
  bresendot = 0
  bresendottimer = create_timer(8)
  beadfalltimer = create_timer(fps)
  fillsfx = 0
  litcount = 0
  twinkle1 = {
    timer = create_timer(8)
  }
  twinkle2 = {
    timer = create_timer(8)
  }
  lineson = false
  beadlines = nil
  beadintro = {
    numvisiblelines = 0
  }
  planetlineangle = 0
  planetlineanglev = 0
  locomotion = {
    vel = 0,
    ttl = 0,
    coli = 1, -- color index
    colt = 0  -- color timer
  }
  warpv = 0
  peeksfxoffset = 0
  twirl = {
    n = 0,
    sin = 0,
  }
  twirltween = create_tween(0, 1, 12 * 36, 22 * 36)
  risetween = create_tween(127, 64, 0, pat30ticks + (12 * 36))
  fadetween = create_tween(1, 0, 18 * 36, 24 * 36)
  wiggleyoyo = {
    val = 0,
    n = 0,
  }

  set_planet_mode('hiding')

  if not hidingtimer then
    hidingtimer = create_timer(fps * 3)
  end

  init_planets()

  -- add some effects to the boost sfx channel (0)
  poke(0x5f43, 0b0001) -- lowpass
  poke(0x5f41, 0b0001) -- echo

  if not postscherzo then
    music(-1, 500)
    sfx(-1, 0)
  end
end

function init_planets()
  planets = {}

  -- to prevent clustering, slice up the circle into pieces so we can apportion
  -- them out such that no two planets are in the same slice
  local angleslices = {}
  local angle = rnd(1) -- start at a random angle
  local numslices = numplanets
  for i = 1, numslices do
    add(angleslices, angle % 1)
    angle += (1 / numslices)
  end

  -- create circle paths for planets
  local paths = {}
  local totalspacing = path_r_limit
  local prevr = 0
  for i = 1, numplanets do
    local planetsleft = numplanets - i + 1
    local spacing = rnd_int(min_path_spacing, totalspacing / planetsleft)
    spacing = mid(min_path_spacing, spacing, max_path_spacing)
    totalspacing -= spacing
    local r = prevr + spacing
    if r > path_r_limit then
      break
    end

    local path = {
      x = 64,
      y = 64,
      r = r,
      speed = 0,
      angle = rnd_pop(angleslices),
      dir = rnd_choice({-1, 1})
    }

    if flr(rnd(2)) == 0 then
      path.speed *= -1
    end

    add(paths, path)
    prevr = path.r
  end

  -- create a planet on each ring
  for i, path in pairs(paths) do
    local r = find_good_radius(i, paths)
    local p = create_planet(r)

    p.path = path
    path.planet = p

    add(planets, p)
    add(bodies, p)
  end

  vary_planet_path_directions()

  if movement == 3 then
    -- assign angles in spiral shape
    local angle = rnd(1)
    for i, p in pairs(planets) do
      p.path.angle = angle
      angle += (rnd_int(1, 3) / 10)
    end
  end

  for _, p in pairs(planets) do
    move_planet_on_path(p)
  end
end

function find_good_radius(i, paths)
  local a = max(1, i - 1)
  local b = min(i + 1, #paths)

  local r1 = paths[a].r
  local r2 = paths[b].r
  local r = ((r2 - r1) / 2)

  -- if there is a previous path/planet
  if a < i then
    -- subtract some size based on the previous planet's radius
    r -= (paths[a].planet.r * 2)
  end
  r = mid(min_planet_r, r, max_planet_r)

  return flr(r)
end

function play_next_peek_note()
  sfx(51, 2, peeksfxoffset, 1)
  peeksfxoffset += 2
end

function btn_pushed(b)
  if state == 'curtain' then
    return
  end

  if b == 4 then
    if state == 'intro' then
      state = nil
      player.isactive = true
    end
    if planetmode == 'peek-a-boo' then
      if #notpeekingplanets > 0 then
        local p = rnd_pop(notpeekingplanets)
        p.ispeeking = true

        if #notpeekingplanets > 0 then
          play_next_peek_note()
        end
      end
    elseif not player.isfalling and not postscherzo then
      if not player.boost.on then
        player.boost.on = true
        player.boost.vel = player.vel:normalized()
        sfx(rnd_int(1, 3), 0)
      end
    end
  end
end

function detect_note_starts(ch)
  local known = channelnote[ch]

  local n = stat(20 + ch) -- note index
  if n ~= known then
    local s = stat(16 + ch) -- sfx index
    local note = get_note(s, n)
    note_started(ch, s, n, note)
    channelnote[ch] = n
  end
end

-- @param ch channel index
-- @param s sfx index
-- @param n note index
-- @param note note object
function note_started(ch, s, n, note)
  if ch == 2 or (ch == 1 and s == 48) then
    if beadintro.isactive and note.volume > 0 and note.effect == 4 then
      beadintro.numvisiblelines += 1
    end

    if note.volume > 0 then
      if (s == 17 or s == 18) then
        if n % 2 == 0 then
          trigger_twinkle1()
        else
          trigger_twinkle2()
        end
      elseif note.instrument == 4 and s > 7 and s ~= 52 then
        trigger_twinkle1()
      end
    end
  elseif ch == 3 then
    if note.volume > 0 then
      if note.instrument == 5 and s > 7 and s ~= 44 then
        trigger_twinkle2()
      end
    end
  end
end

function update_twinkle()
  if twinkle1.timer:update() then
    twinkle1.on = false
  end
  if twinkle2.timer:update() then
    twinkle2.on = false
  end
end

function trigger_twinkle1()
  twinkle1.timer:reset()
  twinkle1.on = true
  twinkle1.col = rnd_choice({7, 11, 14})
end

function trigger_twinkle2()
  twinkle2.timer:reset()
  twinkle2.on = true
  twinkle2.col = rnd_choice({8, 9, 10})
end

function update_music()
  for ch = 1, 3 do
    detect_note_starts(ch)
  end

  detect_pattern_start()
end

function detect_pattern_start()
  -- stat(24) returns 0 if no music is playing (this is probably a bug), so we
  -- also check the note number on channel 1 (bass) to make sure something is
  -- actually playing
  local p = stat(24)
  if p ~= currentpattern and stat(21) > -1 then
    currentpattern = p
    pattern_started(p)
  end
end

function pattern_started(p)
  local offset = pattern_pitch_offset[p]
  if offset then
    transpose_boost_sfx(offset)
  end
end

function transpose_boost_sfx(offset)
  for s = 1, 3 do
    transpose_sfx(s, offset)
  end
end

function release_boost()
  if player.boost.on then
    player.boost.vel = vec2.new()
    sfx(-2, 0)
  end
end

function btn_released(b)
  if state == 'curtain' then
    return
  end

  if b == 4 then
    release_boost()
  end
end

function _update60()
  if costatus(conduct_cr) ~= 'dead' then
    assert(coresume(conduct_cr))
  else
    run()
  end

  if state == 'intro' then
    update_prompt()
  end

  if hidingtimer and hidingtimer:update() then
    set_planet_mode('hide and seek')
    hidingtimer = nil
  end

  pre_update_physics()

  update_buttons()
  update_bg()
  update_music()
  update_twinkle()
  process_input()

  if bresendottimer:update() and not beadlinesfalling then
    bresendottimer:reset()
    bresendot += 1
  end

  pre_update_planets()

  if player.isactive then
    update_player()
  end
  update_trail(player.trail)

  if planetmode ~= 'hiding' then
    update_planets()
  end

  apply_physics()
  litcount = count_by_condition(planets, function(p) return p.fill == 1 end)

  if not player.isactive then
    wiggleyoyo.n += .01
    wiggleyoyo.n %= 1
    wiggleyoyo.val = sin(wiggleyoyo.n) * cos(wiggleyoyo.n)
  end
end

function pre_update_physics()
  -- reset acceleration for all bodies
  for b in all(bodies) do
    b.accel = vec2.new()
  end
end

function apply_physics()
  -- apply acceleration and velocity for all bodies
  for b in all(bodies) do
    if b.isactive ~= false then
      if b.maxaccel then
        b.accel:limit(b.maxaccel)
      end

      b.vel += b.accel
      b.vel:limit(b.maxvel)

      b.pos += b.vel
    end
  end

  -- make the player wrap around the edges of the screen
  if not player.isfalling then
    if player.wrapx then
      if player.pos.x > 127 then
        player.pos.x = 0
      elseif player.pos.x < 0 then
        player.pos.x = 127
      end
    end
    player.pos.y = player.pos.y % 128
  end
end

function points_overlap(a, b)
  if flr(a.x) == flr(b.x) and flr(a.y) == flr(b.y) then
    return true
  else
    return false
  end
end

-- transfer the planet "bead" to the next line if necessary
function transfer_bead(p)
  if not p.lineindex then
    p.maxvel = 2
    return
  end

  if p.lineprog == 0 then
    if p.lineindex > 1 then
      local prevline = beadlines[p.lineindex - 1]
      if points_overlap(p.cpos, prevline.orig.b) then
        p.lineindex -= 1
        p.lineprog = 1
      end
    elseif beadlines[p.lineindex].uncapped then
      -- fall off
      p.lineindex = nil
    end
  elseif p.lineprog == 1 then
    if p.lineindex < #beadlines then
      local nextline = beadlines[p.lineindex + 1]
      if points_overlap(p.cpos, nextline.orig.a) then
        p.lineindex += 1
        p.lineprog = 0
      end
    elseif beadlines[p.lineindex].uncapped then
      -- fall off
      p.lineindex = nil
    end
  end
end

function make_beadlines_fall()
  if not beadlinesfalling then
    beadlinesfalling = true

    -- apply some random upward velocity to the points to start with
    for line in all(beadlines) do
      line.vela.x = rnd(2) - 1
      line.vela.y = -rnd(2)
      line.velb.x = rnd(2) - 1
      line.velb.y = -rnd(2)
    end
  end

  -- make the lines fall
  for line in all(beadlines) do
    line.vela.y += 0.1
    line.velb.y += 0.1

    line.a.x += line.vela.x
    line.a.y += line.vela.y
    line.b.x += line.velb.x
    line.b.y += line.velb.y

    if line.a.y > 256 and line.b.y > 256 then
      del(beadlines, line)
    end
  end
end

function update_bead_lines()
  -- if all the planets have dropped off
  if #planets == 0 then
    if beadfalltimer:update() then
      make_beadlines_fall()
    end
    return
  end

  -- apply velocity to the rotation of the lines
  planetlineangle += planetlineanglev

  -- apply a default clockwise spin
  planetlineanglev -= 0.0001

  if abs(planetlineanglev) > 0.0005 then
    planetlineanglev *= 0.94 -- friction
  end

  -- update line positions based on the rotation
  local origin = vec2.new(64, 64)
  for _, line in pairs(beadlines) do
    line.a = line.orig.a:rotated(planetlineangle, origin)
    line.b = line.orig.b:rotated(planetlineangle, origin)

    local rise = line.b.y - line.a.y
    local run = line.b.x - line.a.x
    if abs(run) > 0 then
      line.slope = abs(rise / run)
    else
      line.slope = 1
    end
    line.slope = min(line.slope, 1)

    -- find which direction beads should travel, based on which line-end is
    -- lower
    if rise > 0 then
      line.gravitydir = 1
    elseif rise < 0 then
      line.gravitydir = -1
    else
      line.gravitydir = 0
    end
  end
end

function pre_update_planets()
  for p in all(planets) do
    p.fillanim.on = false
  end
end

function update_planets()
  if planetmode == 'beads' and not beadintro.isactive then
    update_bead_lines()
  end

  if planetmode == 'motor' and locomotion.isenabled then
    update_motor_locomotion()
  end

  for p in all(planets) do
    if planetmode == 'motor' then
      update_motor_planet(p)
    elseif planetmode == 'beads' then
      if not beadintro.isactive then
        transfer_bead(p)
        apply_bead_gravity(p)
      end
    elseif planetmode == 'dance' then
      update_planet_dance(p)
    elseif planetmode == 'peek-a-boo' then
      update_peek(p)
    elseif planetmode == 'rise' then
      p.pos.y = risetween.val
    end

    if p.fillanim.timer:update() then
      p.fillanim.timer:reset()
      update_fillanim(p.fillanim, p.r)
    end
  end
end

function update_motor_locomotion()
  local product = player.vel.x * player.vel.y
  local switched = false

  if product < 0 then
    if not locomotion.neg then
      locomotion.neg = true
      switched = true
    end
  else
    if locomotion.neg then
      locomotion.neg = false
      switched = true
    end
  end

  if locomotion.vel > 20 and player.planet then
    -- cheat
    if locomotion.ttl == 1 then
      switched = true
    end
  end

  if switched then
    locomotion.ttl = flr(fps / 4)
    if locomotion.vel == 0 then
      locomotion.vel = 0.1
    end
    locomotion.vel *= 1.05
  end

  if locomotion.ttl > 0 then
    locomotion.ttl -= 1
  end

  if locomotion.ttl == 0 then
    -- apply leftward "gravity" toward center of screen
    if planets[1].path.x > 64 then
      locomotion.vel -= .5
      locomotion.vel = max(-1, locomotion.vel)
    else
      locomotion.vel = 0
      locomotion.wrap = false
    end
  end

  locomotion.planetlock = false

  if locomotion.ttl > 0 and locomotion.vel > .05 then
    locomotion.planetlock = true
    locomotion.colt += 1
    locomotion.wrap = true
    if locomotion.colt % 4 == 0 then
      locomotion.coli += 1
      if locomotion.coli > #locomotion_dot_palette then
        locomotion.coli = 1
      end
    end

    locomotion.col = locomotion_dot_palette[locomotion.coli]
  else
    locomotion.col = nil
  end

  apply_locomotion()

  warpv = locomotion.vel / 7
  warpv = max(0, warpv)
end

function update_peek(p)
  if p.ispeeking then
    p.peek.vel.y -= .1
  end

  if p.pos.y > 127 then
    p.pos.y += p.peek.vel.y
  end
  p.pos.y = max(127, p.pos.y)
end

function update_fillanim(anim, r)
  anim.i += anim.dir

  if anim.dir == 1 then
    if anim.i == (r * 2) + 1 then
      anim.dir = -1
    end
  else
    if anim.i == 0 then
      anim.dir = 1
    end
  end
end

function apply_locomotion()
  for _, p in pairs(planets) do
    p.path.x += locomotion.vel
    p.path.x = max(64, p.path.x)
  end

  player.pos.x += locomotion.vel

  if locomotion.wrap and planets[1].path.x >= 192 then
    for _, p in pairs(planets) do
      p.path.x %= 128
    end
    player.pos.x %= 128
  end
end

-- make a planet fall along lines like a bead
function apply_bead_gravity(p)
  -- if this bead fell off
  if not p.lineindex then
    if p.pos.y - p.r * 2 > 128 then
      add(disabledplanets, p)
      del(planets, p)
      del(bodies, p)
      return
    end

    -- make the bead fall toward the bottom of the screen
    p.vel.y += .1
    return
  end

  local line = beadlines[p.lineindex]

  if line.gravitydir == 0 then
    return
  end

  local origline = {
    a = line.orig.a,
    b = line.orig.b
  }

  if not p.isbeadcap then
    local accel = line.slope * 0.02

    p.lineprogv += (accel * line.gravitydir)

    -- limit line-progression velocity to 1 pixel
    p.lineprogv = mid(-line.maxprogvel, p.lineprogv, line.maxprogvel)

    -- add friction based on the planet radius
    p.lineprogv *= p.beadfc

    local newprog = mid(0, p.lineprog + p.lineprogv, 1)

    if p.lineprog ~= newprog then
      local hit = false
      local linediff = origline.b - origline.a
      local testpos = linediff_to_pos(origline, linediff, newprog)

      -- collide with other planets (limit progess along the line)
      for other in all(planets) do
        if other ~= p then
          if collide_along_line(p, testpos, other) then
            hit = true
            break
          end
        end
      end

      if not hit then
        p.lineprog = newprog
      end
    end
  end

  -- update the planet position based on its progress along its line
  p.cpos = lineprog_to_pos(origline, p.lineprog) -- collision position
  p.pos = lineprog_to_pos(line, p.lineprog) -- real position
end

function lineprog_to_pos(line, prog)
  local diff = line.b - line.a
  return line.a + (diff * prog)
end

function linediff_to_pos(line, linediff, prog)
  return line.a + (linediff * prog)
end

function collide_along_line(p, testpos, other)
  if not other.lineindex then
    return
  end

  -- early escape if we are not moving toward the other planet
  local vel = (testpos - p.cpos):normalized()
  local c = other.cpos - p.cpos
  local d = vel:dot(c)
  if d <= 0 then
    return false
  end

  local sumrsq = (other.r + p.r) ^ 2
  local distsq = distsq(other.cpos, testpos)

  if distsq <= sumrsq then
    return true
  end
end

function distsq(a, b)
  return ((b.x - a.x) ^ 2) + ((b.y - a.y) ^ 2)
end

function distance(a, b)
  return sqrt(
    ((b.x - a.x) ^ 2) +
    ((b.y - a.y) ^ 2)
  )
end

function move_planet_on_path(p)
  local path = p.path

  path.angle += path.speed
  p.pos.x = path.x + cos(path.angle) * path.r
  p.pos.y = path.y + sin(path.angle) * path.r
end

function set_planet_mode(mode)
  if planetmode == mode then
    return
  end

  planetmode = mode
  lineson = false

  if planetmode == 'dance' then
    for _, p in pairs(planets) do
      p.path.speed = 0.001 * p.path.dir
    end
  elseif planetmode == 'motor' then
    -- initialize planet path directions to look good for motor-ness
    vary_planet_path_directions()
    lineson = true
    motormodeframes = 0
  elseif planetmode == 'beads' then
    planets[1].isbeadcap = true
    planets[#planets].isbeadcap = true
    beadlines = create_bead_lines()
    lineson = true
  elseif planetmode == 'peek-a-boo' then
    sort_r(planets)
    notpeekingplanets = {}

    -- re-sort, putting biggest in center
    local i = 1
    for j = 0, 3 do
      notpeekingplanets[1 + j] = planets[i]
      if i + 1 <= #planets then
        notpeekingplanets[#planets - j] = planets[i + 1]
      end
      i += 2
    end

    local margin = 20
    local d = (128 - (margin * 2)) / (#planets - 1)
    local x = margin
    for p in all(notpeekingplanets) do
      p.pos.x = x
      p.pos.y = 128 + (p.r * 2)
      p.peek = {
        vel = {
          y = 0
        }
      }

      x += d
    end
  end
end

function sort_r(t)
  for i = 2, #t do
    local j = i
    while j > 1 and t[j - 1].r > t[j].r do
      t[j - 1], t[j] = t[j], t[j - 1]
      j -= 1
    end
  end
end

function vary_planet_path_directions()
  -- start with random directions
  for _, p in pairs(planets) do
    p.path.dir = rnd_choice({-1, 1})
  end

  -- ensure that no more than 2 consecutive planets will orbit in
  -- the same direction
  local samedirsinarow = 0
  local prevdir
  for p in all(planets) do
    if p.path.dir == prevdir then
      samedirsinarow += 1

      if samedirsinarow == 3 then
        p.path.dir = -p.path.dir
        samedirsinarow = 1
      end
    else
      samedirsinarow = 1
    end

    prevdir = p.path.dir
  end
end

function update_planet_dance(p)
  if abs(p.path.speed) < 0.001 then
    p.path.speed += (0.0001 * p.path.dir)
  end

  move_planet_on_path(p)
end

function update_motor_planet(p)
  local d = (p.path.dir * ((player.vel.x * player.vel.y) / 250))

  p.path.speed += d

  -- add friction
  p.path.speed *= .75

  move_planet_on_path(p)
end

function update_trail(trail)
  for t in all(trail) do
    t.pos += t.vel

    if flr(rnd(100)) == 0 then
      del(trail, t)
    end
  end
end

function add_to_trail(player)
  player.trailf += 1
  player.trailf %= 5

  if player.trailf == 0 or player.boost.on then
    if #player.trail > 100 then
      del(player.trail, player.trail[1])
    end

    local col
    local vel = player.vel * .01
    if player.boost.on then
      col = 10
      vel *= -1
      vel += (rnd(2) - 1) / 10
    else
      -- add some variance to the particle position, in perpendicular direction
      -- to the player's velocity
      local perp = vec2.new(-player.vel.y, player.vel.x)
      perp:normalize()
      shakex = rnd_int(-abs(perp.x), abs(perp.x)) / 100
      shakey = rnd_int(-abs(perp.y), abs(perp.y)) / 100
      vel.x += shakex
      vel.x += shakey

      player.trailci += 1
      player.trailci %= #trail_palette
      col = trail_palette[player.trailci + 1]
    end

    local t = {
      pos = player.pos:copy(),
      col = col,
      vel = vel,
      v = 1
    }

    add(player.trail, t)
  end
end

function process_input()
  if player.isactive then
    if planetmode == 'beads' then
      -- rotate the lines on which the beads are strung
      local d = 0.001
      if btn(4) or btn(0) then
        planetlineanglev += d
      elseif btn(1) then
        planetlineanglev -= d
      end
    end
  end
end

function update_player()
  add_to_trail(player)

  if state == 'curtain' then
    return
  end

  if planetmode ~= 'hiding' then
    add_gravity_from_other_bodies(player)
  end

  if player.isfalling then
    player.maxvel = 3
    player.vel.y += .1
    player.boost.on = false
    return
  elseif postscherzo then
    return
  end

  player.isseeking = true

  if player.boost.on then
    if player.boost.vel:magsq() <= 0.0025 then
      player.boost.on = false
      sfx(-1, 0)
    end
  end

  if player.boost.on then
    player.isseeking = false
    player.col = 10

    local accel = player.boost.vel:copy()
    accel:limit(player.maxaccel)
    player.accel += accel
    player.boost.vel *= .88
    player.maxvel = 1.25
  end

  if not player.boost.on then
    player.col = 12
    if abs(player.vel.x) <= 1 and abs(player.vel.y) <= 1 then
      player.maxvel = 1
    end
    player.isseeking = true
  end

  -- try to make player stay in orbit around the target planet or all planets,
  -- depending on the planetmode
  if player.isseeking then
    if (not locomotion.planetlock) or (not player.planet) then
      player.planet = find_closest_planet(player)
    end

    if player.planet then
      seek_orbit(player, player.planet)
    end
  else
    player.planet = nil
  end
end

function find_closest_planet(src)
  if planetmode == 'hiding' then
    return nil
  end

  local best = {
    dist = 32767,
    body = nil
  }
  for p in all(planets) do
    local dist = approx_distance(src.pos, p.pos)

    if dist < best.dist then
      best.dist = dist
      best.body = p
    end
  end

  return best.body
end

function _draw()
  cls()

  if screenfadev then
    for c0 = 1, 15 do
      local c1 = fade(c0, screenfadev)
      pal(c0, c1, 1)
    end
  end

  if state == 'curtain' then
    camera(0, camy)
    color(7)
    cprint('thanks for playing', 64, 62)

    cprint('orbiter suite', 64, 128)
    cprint('by andrew anderson', 64, 134)
    cprint('cover art', 64, 160)
    cprint('and choreography assistance', 64, 166)
    cprint('by aubrianne anderson', 64, 172)

    rectfill(player.pos.x - 1, 0, 127, 127, 0)
    draw_player(player)

    return
  end

  draw_bg()
  draw_planets()
  draw_player(player)

  if locomotion.wrap then
    camera(128, 0)
    draw_planets()
    draw_player(player)
    camera()
  end

  if state == 'intro' then
    local platform = peek(0x5f80)
    color(fade(7, promptfadev))
    if platform == 1 then
      cprint('press any key', 64, 62) -- non-bbs desktop web
    elseif platform == 2 then
      cprint('tap anywhere', 64, 62) -- mobile web
    else
      print('🅾️', 60, 62) -- bbs/native
    end
  end

  --local cpu = flr(stat(1) * 2 * 100)
  --print(cpu .. '%', 10, 0, 5) -- display cpu usage
end

function draw_planets()
  if planetmode == 'beads' then
    if beadlines then
      color(7)
      for i = min(beadintro.numvisiblelines, #beadlines), 1, -1 do
        local line = beadlines[i]
        bresenham_line(line.a.x, line.a.y, line.b.x, line.b.y, true)
      end
    end
  elseif lineson then
    color(7)
    for i = 1, #planets - 1 do
      local a = planets[i]
      local b = planets[i + 1]
      bresenham_line(a.pos.x, a.pos.y, b.pos.x, b.pos.y, true)
    end
  end

  if planetmode ~= 'hiding' then
    for p in all(planets) do
      draw_planet(p)
    end
  end
end

function create_bead_lines()
  local lines = {}

  for i = 1, #planets - 1 do
    local p1, p2

    p1 = planets[i]
    p2 = planets[i + 1]

    local a = p1.pos:copy()
    local b = p2.pos:copy()
    local line = {
      a = a,
      b = b,
      orig = {
        a = a:copy(),
        b = b:copy()
      },
      vela = vec2.new(),
      velb = vec2.new()
    }

    local linediff = line.b - line.a
    line.maxprogvel = 1 / linediff:magnitude()

    add(lines, line)

    p1.lineindex = #lines
    p1.lineprog = 0
    p1.lineprogv = 0
    p1.beadfc = find_bead_friction_coefficient(p1)
    p1.cpos = p1.pos:copy()

    if i == #planets - 1 then
      p2.lineindex = #lines
      p2.lineprog = 1
      p2.lineprogv = 0
      p2.beadfc = find_bead_friction_coefficient(p2)
      p2.cpos = p2.pos:copy()
    end
  end

  return lines
end

-- determine bead friction coefficient based on the planet radius
function find_bead_friction_coefficient(p)
  local r = p.r / 13
  return 0.75 - (r / 2)
end


function shallow_copy(t)
  local t2 = {}
  for k, v in pairs(t) do
    t2[k] = v
  end
  return t2
end

function add_star()
  local star = {
    x = rnd_int(0, 127),
    y = rnd_int(0, 127),
    on = true,
    timer = create_timer(rnd_int(15, 60))
  }

  add(stars, star)
end

function update_bg()
  if #stars < max_stars then
    if rnd_int(0, #stars) == 0 then
      add_star()
    end
  end

  if #stars > min_stars then
    if rnd_int(0, 100 - #stars) == 0 or #stars > max_stars then
      del(stars, stars[1])
    end
  end

  for _, s in pairs(stars) do
    if s.timer:update() then
      s.on = not s.on
      s.timer.length = rnd_int(15, 60)
      s.timer:reset()
    end
  end
end

function rnd_choice(t)
  local i = rnd_int(1, #t)
  return t[i], i
end

function rnd_pop(t)
  local choice, i = rnd_choice(t)

  -- shift items over to close the gap
  for j = i, #t - 1 do
    t[j] = t[j + 1]
  end
  t[#t] = nil

  return choice
end

function draw_bg()
  local half = #stars / 2

  for i, s in pairs(stars) do
    local c = 1
    if twinkle1.on and i < half then
      c = twinkle1.col
      s.on = true
    end
    if twinkle2.on and i >= half then
      c = twinkle2.col
      s.on = true
    end

    if s.on then
      pset(s.x, s.y, c)
    end
  end
end

function approx_distance(v1, v2)
  return abs(v1.x - v2.x) + abs(v1.y - v2.y)
end

function seek_orbit(player, planet)
  local accel = vec2.new()
  local dir = planet.pos - player.pos
  local distsq = dir:magsq()
  local force = (planet.mass) / distsq
  local minforce = 0.07

  if force < minforce and planetmode ~= 'motor' then
    return
  end

  if force >= 0.075 then
    if planet.fill < 1 then
      planet.fillanim.on = true

      planet.fill += max(.0048, .12 / (planet.r ^ 2))
      planet.fill = min(planet.fill, 1)
      if planet.fill == 1 and litcount < #planets - 1 then
        play_found_sfx()
      end
    end
  end

  -- rotate 90 degrees clockwise
  local t1 = vec2.new(-dir.y, dir.x)

  -- rotate 90 degrees counter-clockwise
  local t2 = vec2.new(dir.y, -dir.x)

  -- pick whichever target vector is in front of the player
  local v
  if player.vel:dot(t1) > 0 then
    v = t1:copy()
  else
    v = t2:copy()
  end

  -- add slighly outward spiral orbit direction vector
  v:limit(player.maxaccel / 2)
  accel += v

  -- also add acceleration toward the middle of the planet
  local dir = planet.pos - player.pos
  local limit = center_accel_limit[planet.r] --planet.r / (planet.mass * 1.9)
  dir:limit(limit)
  dir:limit(player.maxaccel / 2)
  accel += dir

  accel:limit(player.maxaccel)
  player.accel += accel
end

function play_found_sfx()
  sfx(11 + fillsfx, 2)

  -- transpose all boost sfx to match the fillsfx
  transpose_boost_sfx(fillsfx == 2 and 1 or 0)

  fillsfx += 1
  fillsfx %= 3
end

function add_gravity_from_other_bodies(body)
  for other in all(bodies) do
    if other ~= body then
      local dir = other.pos - body.pos
      local dist = dir:magnitude()

      if dist > min(other.mass * 2, 50) and dist <= maxsq then
        local force = (gc * body.mass * other.mass) / (dist * dist)

        force = max(0, force) -- mitigate overflow
        dir:normalize()
        body.accel += force * dir
      end
    end
  end
end

function rnd_int(min, max)
  return flr(rnd((max + 1) - min)) + min
end

function draw_player(p)
  if player.isactive then
    circfill(p.pos.x, p.pos.y, 1, p.col)
  end

  draw_trail(p.trail)
end

function draw_trail(trail)
  for t in all(trail) do
    local c = t.col

    -- fade the value of the color
    t.v -= rnd(1) / 100
    if t.v < 0.4 then
      c = 5
    end

    -- twinkle
    if flr(rnd(3)) == 0 then
      pset(t.pos.x, t.pos.y, c)
    end
  end
end

-- @param v value from 0 to 1
function fade(col, v)
  local t = fade_table[col]
  local i = #t - flr((#t - 1) * v)
  return t[i]
end

function bresenham_line(x0, y0, x1, y1, dotted)
  local x0 = flr(x0)
  local y0 = flr(y0)
  local x1 = flr(x1)
  local y1 = flr(y1)

  local dx = abs(x1 - x0)
  local dy = abs(y1 - y0)
  local sx, sy
  if x0 < x1 then sx = 1 else sx = -1 end
  if y0 < y1 then sy = 1 else sy = -1 end
  local err = dx - dy

  local i = bresendot
  while true do
    if (dotted and i % 3 == 0) or not dotted then
      local c = 7
      if locomotion.isenabled and locomotion.col then
        if i % 6 == 0 then
          c = locomotion.col
        else
          c = 0
        end
      end
      pset(x0, y0, c)
    end
    i += 1

    if x0 == x1 and y0 == y1 then
      break
    end
    local e2 = 2 * err
    if e2 > -dy then
      err = err - dy
      x0 = x0 + sx
    end
    if e2 < dx then
      err = err + dx
      y0 = y0 + sy
    end
  end
end

function circ_scanline(ox, oy, r, col, fillanim)
  local i = 0
  if flr(rnd(2)) == 0 then
    i = 1
  end
  if player.isactive then
    i = flr(player.pos.y / 6) % 2
  else
    i = flr(wiggleyoyo.n * 10) % 2
  end

  local highlighti
  if fillanim.on then
    highlighti = i + fillanim.i
  end

  local r2 = r * r + (r * 0.8)
  for cy = -r, r do
    local x = sqrt(r2 - (cy * cy)) + 0.5
    local y = oy + cy

    -- add some imperfection to x position
    local wiggle = rnd(2)
    if player.isactive then
      wiggle *= (player.vel.x * player.vel.y)
    else
      wiggle *= wiggleyoyo.val
    end
    wiggle += rnd(warpv * 2)
    x += wiggle

    local c = col
    i += 1
    if i % 2 == 0 then
      if c > 0 then
        c = fade(col, 0.5)
      end
    end

    if fillanim.on then
      if i == highlighti then
        c = 7
      end
    end

    rectfill(ox - x, y, ox + x, y, c)
  end
end

function draw_planet(p)
  local pos = p.pos
  local c = fade(p.col, p.fill)
  circ_scanline(pos.x, pos.y, p.r, c, p.fillanim)

  if p.fill == 1 then
    local x = pos.x - 1
    local y = pos.y - 1

    if not facecamera then
      if player.pos.x < pos.x then
        x -= 1
      elseif player.pos.x > pos.x then
        x += 1
      end

      if player.pos.y < pos.y then
        y -= 1
      elseif player.pos.y > pos.y then
        y += 1
      end
    end

    local faceisvisible = true

    if twirl.isactive then
      if twirl.n >= 0.25 and twirl.n <= 0.75 then
        faceisvisible = false
      end

      local facew = 3
      local extraw = 1
      local halffacew = flr(facew / 2)
      local centerx = pos.x - halffacew
      local scale = p.r + facew + extraw
      x = centerx + (twirl.sin * scale)

      local r2 = p.r * 2
      clip(pos.x - p.r - extraw, pos.y - p.r, r2 + (extraw * 2) + 1, r2)
    end

   if faceisvisible then
     pal(7, 0)
     spr(1, x, y)
     pal(7, 7)
   end
   if twirl.isactive then
     clip()
   end
  end
end

function create_player()
  return {
    isactive = false,
    pos = vec2.new(-2, 64),
    vel = vec2.new(2, 0),
    r = 1,
    col = 12,
    mass = 1,
    maxvel = 1,
    maxaccel = .33,
    boost = {
      on = false
    },
    trail = {},
    trailf = 0,
    trailci = 0,
    wrapx = false
  }
end

function create_planet(r)
  local col = rnd_choice(planet_palette)
  del(planet_palette, col)

  return {
    pos = vec2.new(),
    vel = vec2.new(0, 0),
    r = r,
    col = col,
    fill = 0,
    fillanim = {
      on = false,
      timer = create_timer(3),
      i = 0,
      dir = 1
    },
    mass = (r ^ 2),
    maxvel = 1
  }
end

function get_note(sfx, n)
  local addr = 0x3200 + (68 * sfx) + (2 * n)
  local byte1 = peek(addr)
  local byte2 = peek(addr + 1)
  local inst_r = shr(band(byte1, 0b11000000), 6)
  local inst_l = shl(band(byte2, 0b00000001), 2)

  return {
    addr = addr,
    byte1 = byte1,
    byte2 = byte2,
    pitch = band(byte1, note_pitch_mask),
    volume = shr(band(byte2, 0b00001110), 1),
    effect = shr(band(byte2, 0b01110000), 4),
    instrument = bor(inst_l, inst_r)
  }
end

function sfx_addr(n)
  return 0x3200 + (68 * n)
end

function transpose_sfx(n, offset)
  local firstnote = get_note(n, 0)
  local firstpitch = firstnote.pitch

  local origfirstpitch = original_pitches[n]
  if origfirstpitch then
    -- add the amount to get back to the original pitch, so that the new offset
    -- is still relative to the original pitch
    offset += (origfirstpitch - firstpitch)
  else
    original_pitches[n] = firstpitch
  end

  -- offset all notes in the sfx
  for i = 0, 31 do
    local note = get_note(n, i)
    local byte1 = note.byte1
    local newpitch = note.pitch + offset

    byte1 = band(byte1, bnot(note_pitch_mask)) -- clear pitch
    byte1 = bor(byte1, newpitch) -- set new pitch

    poke(note.addr, byte1)
  end
end

function count_by_condition(t, fn)
  local count = 0

  for _, item in pairs(t) do
    if fn(item) then
      count += 1
    end
  end

  return count
end

function cprint(s, x, y)
  local w = max(0, (#s* 4) - 1)
  print(s, x - flr(w / 2), y)
end

function ease_linear(t, b, c, d)
  return ((t / d) * c) + b
end

function ease_in_out_twirl(t, b, c, d)
  local v = (1 - cos((t / d) * .5)) * .5
  if v < 0.25 then
    v *= 3
  end
  return (v * c) + b
end

function create_tween(src, dst, ticksrc, tickdst)
  return {
    -- output
    src = src,
    dst = dst,
    val = src,

    -- ticks on pattern
    ticksrc = ticksrc,
    tickdst = tickdst,
    ticktot = tickdst - ticksrc,
  }
end

function update_tween(tween, ticks, func)
  ticks = mid(0, ticks - tween.ticksrc, tween.ticktot)
  tween.val = func(
    ticks,
    tween.src,
    tween.dst - tween.src,
    tween.ticktot)
end

function update_prompt()
  if prompttimer:update() then
    if promptfadev < 1 then
      promptfadev += (1 / (fps / 2))
      promptfadev = min(promptfadev, 1)
    end
  end
end

function conduct()
  repeat
    yield()
  until player.pos.x >= 0
  player.wrapx = true

  -------------------------------------
  -- i: andante
  repeat
    yield()
  until litcount == #planets
  music(0)
  set_planet_mode('dance')

  repeat
    yield()
  until stat(24) == 7
  numplanets = 6
  restart()


  -------------------------------------
  -- ii: scherzo meccanico
  repeat
    yield()
  until litcount == #planets
  music(9)
  set_planet_mode('dance')

  local mode = 'dance'
  repeat
    local note = stat(23)
    local pattern = stat(24)

    if pattern >= 11 and pattern <= 13 then
      if note >= 16 then
        mode = 'motor'
      else
        mode = 'dance'
      end
    end

    set_planet_mode(mode)
    yield()
  until stat(24) == 14
  set_planet_mode('motor') -- failsafe
  locomotion.isenabled = true
  player.wrapx = false

  local maxv = 120
  repeat
    yield()
  until locomotion.vel >= maxv
  numplanets = 7
  movement = 3
  postscherzo = true
  music(18)
  restart()

  player.maxvel = maxv
  player.vel.x = maxv
  player.wrapx = true
  repeat
    player.vel.x *= .97
    yield()
  until player.vel.x <= 1
  postscherzo = false


  -------------------------------------
  -- iii: andante sentimentale
  repeat
    yield()
  until litcount == #planets
  music(19)

  set_planet_mode('beads')

  -- wait for all lines to appear and for pattern 20 to be reached
  beadintro.isactive = true
  repeat
    yield()
  until beadintro.numvisiblelines == #beadlines and stat(24) == 20
  beadintro.isactive = false

  -- wait for frantic music
  repeat
    yield()
  until stat(24) == 27

  -- uncap the bead-lines on the ends, i.e. allow planets to fall off
  beadlines[1].uncapped = true
  beadlines[#beadlines].uncapped = true

  -- make the end planets fall off
  for i = 1, #planets, #planets - 1 do
    planets[i].isbeadcap = false
    planets[i].lineindex = nil
  end

  -- wait for all planets and lines to fall off the screen
  repeat
    yield()
  until #beadlines == 0
  music(-1)

  player.isfalling = true
  player.vel.y = -1
  release_boost()
  repeat
    yield()
  until player.pos.y > 127

  player.isactive = false
  player.vel = vec2.new()
  player.pos = vec2.new(64, 0) -- put player at top so planets will face up

  planets = disabledplanets -- restore all planets
  set_planet_mode('peek-a-boo')

  local fn = function (p)
    return p.ispeeking and p.pos.y == 127
  end
  repeat
    local numpeeking = count_by_condition(planets, fn)
    yield()
  until numpeeking == #planets
  music(30)
  set_planet_mode('rise')

  -- make planets rise with music
  facecamera = true
  repeat
    local pattern = stat(24)
    local ticks = stat(26) -- ticks played on current pattern

    if pattern == 30 and ticks >= twirltween.ticksrc then
      twirltween.isactive = true
    end
    if ticks > twirltween.tickdst then
      twirltween.isactive = false
      twirl.isactive = false
    end
    if twirltween.isactive then
      twirl.isactive = true
      update_tween(twirltween, ticks, ease_in_out_twirl)
      twirl.n = twirltween.val
      twirl.sin = sin(twirl.n)
    end

    if pattern == 31 then
      -- add ticks from previous (now completed) pattern
      ticks += pat30ticks
    end
    update_tween(risetween, ticks, ease_linear)

    yield()
  until risetween.val == risetween.dst
  twirl.isactive = false

  -- adjust the screen fade-out
  repeat
    local ticks = stat(26)

    -- if music is no longer playing
    if stat(17) == -1 then
      ticks = fadetween.tickdst
    end

    update_tween(fadetween, ticks, ease_linear)
    screenfadev = fadetween.val
    yield()
  until fadetween.val == fadetween.dst

  for t = 1, fps do
    yield()
  end
  screenfadev = 1
  state = 'curtain'

  -- make player fly in from left
  player.isactive = true
  player.isfalling = false
  player.pos = vec2.new(0, 64)
  player.vel = vec2.new(2, 0)
  player.boost.on = true
  player.wrapx = false

  repeat
    yield()
  until player.pos.x > 192
  player.isactive = false

  for y = 0, 192, 0.1 do
    camy = y
    yield()
  end
end
