mapdata={}

function _update()
 for i=1,50 do
  stary[i] += stars[i]
  if (stary[i]>127) stary[i]=0
  pal(4,flr(rnd(15)+1))
 end
 if gmode==1 then
  pacmove()
  obakemove()
 end
 if (gmode==2) title()
 if (gmode==3) obakemove()
 if (gmode==4) pmv2()
 if (gmode==5) gstart()

 if (yuretime>0) yure()
 if (m_bonus>1) mbonus() 

 for i=1,10 do
  if (efec[i]==1) efec_1(i)
 end
 
end

function _draw()
 rectfill(0,0,128,128,0)
 for i=1,50 do
  spr(33,starx[i],stary[i])
 end
 for i=1,13 do
  if (efec[i]==1) draw_efec1(i)
  if (efec[i]==2) draw_efec2(i)
 end
 if (gmode==1) draw_game()
 if (gmode==2) draw_title()
 if (gmode==3) draw_rclr()
 if (gmode==4) draw_yarare()
 if (gmode==5) draw_gstart()
 if (gmode==6) draw_gover()

 if (m_bonus>1) print(bonusscorel,mbx,mby,4)
end

function draw_game()
 map(roundx,0,0,0,16,16)
 if (gmode~=6) and (gmode~=2) then pacdisp(x,y) end
 obakedisp()
 scdisp() zkdisp()
end

function draw_title()
 draw_game()
 for i=1,10 do
   spr(191+i,i*8+16,30)
   spr(207+i,i*8+16,38)
   spr(223+i,i*8+16,46)
 end
 ttlcnt += 1 if ttlcnt>20 then ttlcnt=0 end
 if ttlcnt<15 then
    print("push button to game start!",14,98, 2)
    print("push button to game start!",13,97, 8)
    print("push button to game start!",12,96, 7)
 end
 print("play",53,20,7)
 print("(c) 2016 konimiru presents",12,70,4)
end

function draw_rclr()
 draw_game()
 print("good!! round clear!!",30,90-rctime,4)
 rctime += 1
 if rctime>100 then r_clr() end
end

function draw_yarare()
 map(roundx,0,0,0,16,16)
 obakedisp() scdisp() zkdisp()
 spr(ysp[yararesp],x,y)
end

--pacmane move------------------
function pacmove()
 xstat=0
 if (x%8 ==0 ) xstat=1
 ystat=0
 if (y%8 ==0 ) ystat=1

 if (xstat==1) and (ystat==1) then
  pac_now = chrscr(x,y)
 end

 if ystat==1 then
    if (btn(0)) p_left()
    if (btn(1)) p_right()
 end
 if xstat==1 then
    if (btn(2)) p_up()
    if (btn(3)) p_down()
 end

 if (xstat==1) and (ystat==1) then
    pac_a = chrscr(x+vx,y+vy)
    if pac_a==12 then pacd=0 end
 end
  
 if pacd ==1 then x=x-1 end
 if pacd ==2 then x=x+1 end
 if pacd ==3 then y=y-1 end
 if pacd ==4 then y=y+1 end

 if (muteki>0) muteki -=1

end

--left
function p_left()
 if (pac_now ~= 7) and (pac_now ~=4) and (pac_now ~=1) and (pac_now ~= 10) then
    pacmuki=1
    pacd=1
    vx = -8
    vy = 0
 end
end
--right
function p_right()
 if (pac_now ~= 9) and (pac_now ~=6) and (pac_now ~=3) and (pac_now ~= 10) then
    pacmuki=5
    pacd=2
    vx = 8
    vy = 0
 end
end
--up
function p_up()
 if (pac_now ~= 7) and (pac_now ~=8) and (pac_now ~=9) and (pac_now ~= 11) then
    pacmuki=9
    pacd=3
    vx = 0
    vy = -8
 end
end
--down
function p_down()
 if (pac_now ~= 1) and (pac_now ~=2) and (pac_now ~=3) and (pac_now ~= 11) then
    pacmuki=13
    pacd=4
    vx = 0
    vy = 8
 end
end


--pacmane disp
function pacdisp(_x,_y)
 if pacd>0 then
    pacanimel += 1
    if (pacanimel>1) then
       pacanimel=0
       pacanime += 1
       if pacanime>3 then pacanime=0 end
    end
 end      
 spr(pacanime+pacmuki,_x,_y)
 if muteki > 0 then
    spr(38+(muteki%4),_x+rnd(8),_y-8+rnd(16))
    spr(38+(muteki%4),_x-8+rnd(8),_y-8+rnd(16))
 end
end

--pac yarare animation----------
function pmv2()
 yararecnt += 1
 if (yararecnt%5) == 0 then
    if (yararesp<8) yararesp+=1
 end
 if yararecnt > 70 then
    gmode = 1 
    sfx(2,3,0)
    muteki = 100
    if zanki<1 then gover_ap() end
 end
 obakemove()
end

--obake move--------------------
function obakemove()
 for ii=1,12 do
   if (mm[ii]>0) then obmv(ii) end
 end
end

function obmv(iii)
 if (mst[iii]>0) and (mst[iii]<5) then m_chase(iii) end 
 if mst[iii]==5 then m_yum(iii) end
 if mst[iii]==6 then m_ohaka(iii) end
end

--monster move(chase)-----------
function m_chase(iii)
 mxstat=0
 if (mx[iii]%8 ==0 ) mxstat=1
 mystat=0
 if (my[iii]%8 ==0 ) mystat=1

 if (mxstat==1) and (mystat==1) then m_dir(iii) end
 if md[iii] ==1 then mx[iii]-=mspee[iii] meye[iii]=152 end
 if md[iii] ==2 then mx[iii]+=mspee[iii] meye[iii]=156 end
 if md[iii] ==3 then my[iii]-=mspee[iii] meye[iii]=160 end
 if md[iii] ==4 then my[iii]+=mspee[iii] meye[iii]=164 end 

 if (x-4<mx[iii]) and (x+4>mx[iii]) and (y-4<my[iii]) and (y+4>my[iii]) then tkhit(iii) end

end

function m_dir(iii)
 mns_now = chrscr(mx[iii],my[iii])

 px = x         py = y
 qx = mx[iii]   qy = my[iii]

 if mst[iii]==2 then px = x + vx*16     py = y + vy*16     end
 if mst[iii]==3 then px = 128-x         py = 128-y         end
 if mst[iii]==4 then px = flr(rnd(128)) py = flr(rnd(128)) end

 --left
 a=md[iii]
 if a==1 then
    if mns_now==1  then md[iii]=3 end
    if mns_now==2  then mleft2(iii) end
    if mns_now==4  then mleft4(iii) end
    if mns_now==5  then mleft5(iii) end
    if mns_now==7  then md[iii]=4 end
    if mns_now==8  then mleft8(iii) end
    if mns_now==11 then md[iii]=1 end
 end
 --right
 if a==2 then
    if mns_now==2  then mright2(iii) end
    if mns_now==3  then md[iii]=3 end
    if mns_now==5  then mright5(iii) end
    if mns_now==6  then mright6(iii) end
    if mns_now==8  then mright8(iii) end
    if mns_now==9  then md[iii]=4 end
    if mns_now==11 then md[iii]=2 end
 end
 --up
 if a==3 then
    if mns_now==4  then mup4(iii) end
    if mns_now==5  then mup5(iii) end
    if mns_now==6  then mup6(iii) end
    if mns_now==7  then md[iii]=2 end
    if mns_now==8  then mup8(iii) end
    if mns_now==9  then md[iii]=1 end
    if mns_now==10 then md[iii]=3 end
 end
 --down
 if a==4 then
    if mns_now==1  then md[iii]=2 end
    if mns_now==2  then mdown2(iii) end
    if mns_now==3  then md[iii]=1 end
    if mns_now==4  then mdown4(iii) end
    if mns_now==5  then mdown5(iii) end
    if mns_now==6  then mdown6(iii) end
    if mns_now==10 then md[iii]=4 end
 end
end

--left janction
function mleft2(iii)
 md[iii]=1 if (px>qx) or (py<qy) then md[iii]=3 end
end
function mleft4(iii)
 md[iii]=flr(rnd(2))+3
 if py>qy then md[iii]=4 end
 if py<qy then md[iii]=3 end
end
function mleft5(iii)
 md[iii]=1
 if py<qy then md[iii]=3 end
 if py>qy then md[iii]=4 end
 if px>qx then md[iii]=flr(rnd(2))+3 end
end
function mleft8(iii)
 md[iii]=1 if (px>qx) or (py>qy) then md[iii]=4 end
end
--right janction
function mright2(iii)
 md[iii]=2 if (px<qx) or (py<qy) then md[iii]=3 end
end
function mright5(iii)
 md[iii]=2
 if py<qy then md[iii]=3 end
 if py>qy then md[iii]=4 end
 if px<qx then md[iii]=flr(rnd(2))+3 end
end
function mright6(iii)
 md[iii]=flr(rnd(2))+3
 if py<qy then md[iii]=3 end
 if py>qy then md[iii]=4 end
end
function mright8(iii)
 md[iii]=2 if (py>qy) or (px<qy) then md[iii]=4 end
end
--up janction
function mup4(iii)
 md[iii]=3 if (py>qy) or (px>qx) then md[iii]=2 end
end
function mup5(iii)
 if px>qx then md[iii]=2 end
 if px<qx then md[iii]=1 end
 if py>qy then md[iii]=flr(rnd(2))+1 end
end
function mup6(iii)
 md[iii]=3 if (px<qx) or (py>qy) then md[iii]=1 end
end
function mup8(iii)
 md[iii]=flr(rnd(2))+1
 if px<qx then md[iii]=1 end
 if px>qx then md[iii]=2 end
end 
--down javction 
function mdown2(iii)
 md[iii]=flr(rnd(2))+1
 if px<qx then md[iii]=1 end
 if px>qx then md[iii]=2 end
end
function mdown4(iii)
 md[iii]=4 if (px>qx) or (py<qy) then md[iii]=2 end
end 
function mdown5(iii)
 md[iii]=4
 if px<qx then md[iii]=1 end
 if px>qx then md[iii]=2 end
 if py<qy then md[iii]=flr(rnd(2))+1 end
end
function mdown6(iii)
 md[iii]=4 if (px<qx) or (py<qy) then md[iii]=1 end
end

--monster move(yum yum----------
function m_yum(iii)
 mpal1[iii] += 1 if mpal1[iii]>6 then mpal1[iii]=0 end
 mpal2[iii]=15 if mpal1[iii] > 3 then mpal2[iii]=8 end
 pal(1,mpal2[iii])
 my[iii]  -= 0.5
 mtm[iii] += 1
 if mtm[iii]>20 then mm[iii]=0 end
end

--ohaka move--------------------
function m_ohaka(iii)
 my[iii] -= 1
 if my[iii] < -50 then
    mst[iii]=vmst[iii]
    msp[iii]=vmsp[iii]
    mx[iii]=vmx[iii]
    my[iii]=vmy[iii]
 end
end

--bonus point move--------------
function mbonus()
 m_bonus -= 1 mby -= 0.5
end

--monster disp------------------
function obakedisp()
 mcntl += 1
 if mcntl>3 then
    mcntl = 0
    mcnt += 1
    if mcnt>3 then mcnt=0 end
 end
 for ii=1,12 do
  if mm[ii]>0 then
     if mst[ii]<5 then
        spr(mcnt+msp[ii],mx[ii],my[ii])
        if (mm[ii]==1) then
           if muteki==0 then
              spr(mcnt+meye[ii],mx[ii],my[ii])
           else
              spr(mcnt+168,mx[ii],my[ii])
           end
        end
     end
     if mst[ii]==5 then
      spr(72,mx[ii]-12,my[ii])
      spr(73,mx[ii]- 4,my[ii])
      spr(72,mx[ii]+ 4,my[ii])
      spr(73,mx[ii]+12,my[ii])
     end
     if mst[ii]==6 then
      spr(172,mx[ii],my[ii])
      spr(173,mx[ii],my[ii]-8)
      spr(174,vmx[ii],vmy[ii])
     end
  end
 end
end

--yure--------------------------
function yure()
 yuretime -= 0.4
 camera( rnd(yuretime),rnd(yuretime) )
 if yuretime <=0 then
    yuretime = 0
    camera(0,0)
 end
end

--effect------------------------
function efec_1(ii)
 efeccnt[ii] +=1
 if (efeccnt[ii]>60) efec[ii]=0
 efec1[ii] += 2
 efec2[ii] += 4
end
function draw_efec1(ii)
 circ(efecx[ii],efecy[ii],efec1[ii],7)
 circ(efecx[ii],efecy[ii],efec2[ii],8)
end
function efec_1a(ii)
 efno += 1 if (efno>9) efno=0
 efec[efno] = 1
 efeccnt[efno] = 0
 efecx[efno] = mx[ii]
 efecy[efno] = my[ii]
 efec1[efno] = 0
 efec2[efno] = 0
end
function draw_efec2(ii)
 efecy[ii] -= efec1[ii]
 efecx[ii] += rnd(2)-1
 if efecy[ii]<-16 then efec_2a(ii) end
 spr(78,efecx[ii]  ,efecy[ii])
 spr(79,efecx[ii]+8,efecy[ii])
 spr(94,efecx[ii]  ,efecy[ii]+8)
 spr(95,efecx[ii]+8,efecy[ii]+8)
end
function efec_2a(iii)
 efec[iii]=2
 efecx[iii]=rnd(128)
 efecy[iii]=128+rnd(128)
 efec1[iii]=rnd(3)+1
end

--sessyoku hantei---------------
function tkhit(iii)
 if gmode==1 then
    if mm[iii] ==1 then
       if muteki == 0 then
          hit_monster(iii)
       else
          sfx(6,2,0)
          vmx[iii]=mx[iii] vmy[iii]=my[iii]
          vmsp[iii]=msp[iii] vmst[iii]=mst[iii]
          mst[iii]=6
          msp[iii]=172
          bonusscore += 200
          bonusscorel = bonusscore
          score += bonusscore
          m_bonus=50 mbx=mx[iii] mby=my[iii]
          efec_1a(iii)
       end      
    end
    if mm[iii] ==2 then get_fruit(iii) end
 end
end

function get_fruit(iii)
 sfx(0,2,0)
 mst[iii] = 5
 mtm[iii] = 0
 score += 50
 muteki = rmuteki
 bonusscore = 0
 esa -= 1
 if esa<1 then
    music(4)
    gmode=3
    rctime=0
 end
end

function hit_monster(iii)
 sfx(1,3,0)
 gmode=4 yararecnt=1 yararesp=1
 yuretime = 8
 bonusscore = 0
 zanki -= 1
end

--round clear-------------------
function r_clr()
 round = round + 1
 if round>6 then round = 1 end
 r_ini()
end

--game start--------------------
function gstart()
end
function draw_gstart()
 draw_game()
 print("game start!!",37,100-(rctime),4)
 rctime += 1
 if rctime>100 then
    gmode = 1
    sfx(2,3,3)
 end 
end

--game over---------------------
function gover_ap()
 sfx(-1,0) sfx(-1,1) sfx(-1,2) sfx(-1,3)
 gmode  = 6
 rctime = 0
 music(2)
end
function draw_gover()
 draw_game()
 print("game over!!",40,94-(rctime),4)
 rctime += 1
 if rctime>100 then
    g_ini() r_ini()
    gmode = 2
 end 
end

--some function-----------------
function xy_cng(x,y)
 mapxx = x/8
 mapyy = y/8
 return mapxx,mapyy
end

--(x,y) -> (mapx,mapy)
function chrscr(_x,_y)
 return mapdata[_y/8*16+_x/8+1]
end

--score disp
function scdisp()
 scorecnt += scoremode
 if scorecnt<8 then 
    print("score",8,120,8)
    print("round",60,120,8)
 end
 if scorecnt>10 then scorecnt=0 end
 print(score,35,120,7)
 print(round,85,120,7)
 if extend==0 and score>2000 then zanki+=1 extend=1 sfx(14,-1) end
 if extend==1 and score>5000 then zanki+=1 extend=2 sfx(14,-1) end
end
--zanki disp
function zkdisp()
 a = pacmuki+pacanime
 if zanki>1 then spr(a,120,119) end
 if zanki>2 then spr(a,111,119) end
 if zanki>3 then spr(a,102,119) end
 if zanki>4 then spr(a, 93,119) end
end

--title-------------------------
function title()
 scoremode = 0
 extend=5
 obakemove()
 if btnp(4) or btnp(5) then
    score = 0
    g_ini()
    r_ini()
    music(0) gmode=5
 end
end

--round init--------------------
function r_ini()
 scoremode = 1
 rmuteki = 30
 gmode  = 1
 rctime = 0
 efno   = 0
 
 pacanime  = 0   --anime sp no
 pacanimel = 0   --anime count
 pac_now   = 11  --now location
 pac_a     = 11  --next location
 yarare    = 0   --yarare flug
 yararesp  = 0   --yarare sp no
 yararecnt = 0   --yarare pattern

 maze_pat()
 
 mcnt = 0
 mcntl= 0
 msn_now = 10
 
 muteki = 50
 yuretime = 0
 m_bonus = 0
 bonusscore  = 0
 bonusscorel = 0

end

--game init---------------------
function g_ini()
 gmode = 1
 round = 1
 scoremode = 0
 scorecnt  = 0
 zanki     = 3
 ttlcnt    = 0
 extend    = 0
end

--init--------------------------
function _init()
 cls()
 mtm={0,0,0,0,0,0,0,0,0,0,0,0}
 mpal1={0,0,0,0,0,0,0,0,0,0,0,0}
 mpal2={0,0,0,0,0,0,0,0,0,0,0,0}
 ysp ={25,26,27,28,29,30,31,32}
 meye={164,164,164,164,164,164,164,164,164,164,164,164}
 vmsp={0,0,0,0,0,0,0,0,0,0,0,0}
 vmst={0,0,0,0,0,0,0,0,0,0,0,0}
 vmx ={0,0,0,0,0,0,0,0,0,0,0,0}
 vmy ={0,0,0,0,0,0,0,0,0,0,0,0}
 starx={} stary={} stars={}
 efec={} efecx={} efecy={} efeccnt={} efec1={} efec2={}
 for i=0,50 do
  add(starx,flr(rnd(128)))
  add(stary,flr(rnd(128)))
  add(stars,flr(rnd(3)+1))
  add(efec,0) add(efecx,0) add(efecy,0) add(efeccnt,0) add(efec1,0) add(efec2,0)
 end
 
 score = 4805

 efec_2a(11) efec_2a(12) efec_2a(13)
 
 g_ini()  
 r_ini()

 gmode = 2
 efno  = 0


end

--maze set----------------------
function maze_pat()

 mspee={1,1,1,1,1,1,1,1,1,1,1,1}

 if (round==1) r1_set()
 if (round==2) r2_set()
 if (round==3) r3_set()
 if (round==4) r4_set()
 if (round==5) r5_set()
 if (round==6) r6_set()
end

function r1_set()
 mapdata={12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,
          12, 7,11,11, 9,12, 7,11, 9,12, 7,11,11,11, 9,12,
          12,10,12,12,10,12,10,12,10,12,10,12,12,12,10,12,
          12,10,12, 7, 2, 8, 3,12, 1,11, 5,11,11, 8, 3,12,
          12, 1, 8, 3,12,10,12,12,12,12,10,12,12,10,12,12,
          12,12,10,12,12, 4,11, 8,11,11, 3,12, 7, 2, 9,12,
          12, 7, 2,11, 8, 3,12,10,12,12,12,12,10,12,10,12,
          12,10,12,12,10,12,12, 4,11,11, 9,12,10,12,10,12,
          12,10,12, 7, 2, 9,12,10,12,12,10,12,10,12,10,12,
          12,10,12,10,12,10,12, 1, 9,12, 4,11, 2, 8, 3,12,
          12, 4,11, 6,12,10,12,12, 4,11, 6,12,12,10,12,12,
          12,10,12,10,12, 1,11,11, 6,12, 1, 9,12, 1, 9,12,
          12,10,12,10,12,12,12,12,10,12,12,10,12,12,10,12,
          12, 1,11, 2,11,11,11,11, 2,11,11, 2,11,11, 3,12,
          12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12}
 roundx=0 esa=8 rmuteki=60

 x = 7  * 8  y  = 13 * 8
 vx = -8     vy = 0
 pacd = 1    pacmuki  = 1
 
 mm = {1,1,1,1,2,2,2,2,2,2,2,2}
 mx = {  8,112,  8,96, 24, 48,100,112, 8, 32,64,112}
 my = { 12, 10, 96,64, 24,  8,  8, 40,72,104,56, 92}
 md = {4,4,3,3,2,2,2,4,3,1,1,3}
 mst={1,2,3,4,4,3,4,3,4,4,4,4}
 msp={128,132,136,140,17,17,17,17,17,17,17,17}
 mspee={0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5,0.5}
 pal(12,12)
end

function r2_set()
 mapdata={12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,
          12, 7,11, 8,11, 9,12, 7,11,11, 8,11, 8,11, 9,12,
          12,10,12,10,12,10,12,10,12,12,10,12,10,12,10,12,
          12,10,12,10,12,10,12, 1, 9,12,10,12,10,12,10,12,
          12,10,12, 1,11, 6,12,12,10,12, 4,11, 3,12,10,12,
          12,10,12,12,12,10,12, 7, 3,12,10,12,12,12,10,12,
          12,10,12,12,12, 4,11, 6,12,12,10,12,12,12,10,12,
          12, 4,11,11,11, 6,12, 1, 9,12, 4,11,11,11, 6,12,
          12,10,12,12,12,10,12,12, 4,11, 6,12,12,12,10,12,
          12,10,12,12,12,10,12, 7, 3,12,10,12,12,12,10,12,
          12,10,12, 7,11, 6,12,10,12,12, 4,11, 9,12,10,12,
          12,10,12,10,12,10,12, 1, 9,12,10,12,10,12,10,12,
          12,10,12,10,12,10,12,12,10,12,10,12,10,12,10,12,
          12, 1,11, 2,11, 2,11,11, 3,12, 1,11, 2,11, 3,12,
          12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12}
 roundx=16 esa=8 rmuteki=50

 x = 7  * 8  y  = 13 * 8
 vx = -8     vy = 0
 pacd = 1    pacmuki  = 1
 
 mm = {1,1,1,1,2,2,2,2,2,2,2,2}
 mx = {  8,112, 64,112, 30, 8,100,112,80,64, 98, 16}
 my = { 12, 10,  8, 56,  8,64,  8, 40,40,63,104,104}
 md = {4,4,2,4,2,3,2,4,3,3,2,1}
 mst={1,2,3,4,4,3,4,3,4,4,4,4}
 msp={128,132,136,140,21,21,21,21,21,21,21,21}
 mspee={0.5,0.5,0.5,1,1,1,1,1,1,1,1,1}
 pal(12,14)
end
function r3_set()
 mapdata={12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,
          12, 7,11,11,11,11,11,11,11,11,11,11,11,11, 9,12,
          12,10,12,12,12,12,12,12,12,12,12,12,12,12,10,12,
          12,10,12, 7,11,11,11,11,11,11,11,11,11,11, 6,12,
          12,10,12,10,12,12,12,12,12,12,12,12,12,12,10,12,
          12,10,12,10,12, 7,11,11,11,11,11,11,11,11, 6,12,
          12,10,12,10,12,10,12,12,12,12,12,12,12,12,10,12,
          12,10,12,10,12,10,12, 7,11,11,11,11,11,11, 6,12,
          12,10,12,10,12,10,12,10,12,12,12,12,12,12,10,12,
          12,10,12,10,12,10,12,10,12, 7,11,11,11,11, 6,12,
          12,10,12,10,12,10,12,10,12,10,12,12,12,12,10,12,
          12,10,12,10,12,10,12,10,12,10,12, 7,11,11, 6,12,
          12,10,12,10,12,10,12,10,12,10,12,10,12,12,10,12,
          12, 1,11, 2,11, 2,11, 2,11, 2,11, 2,11,11, 3,12,
          12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12}
 roundx=32 esa=8 rmuteki=40

 x = 7  * 8  y  = 13 * 8
 vx = -8     vy = 0
 pacd = 1    pacmuki  = 1
 
 mm = {1,1,1,1,2,2,2,2,2,2,2,2}
 mx = {  8,112, 24,112, 20, 48,100,112, 8,56,24,64}
 my = { 12, 86, 56, 10,  8,  8,  8, 40,76,24,70,56}
 md = {4,4,3,4,1,2,2,4,3,1,3,2}
 mst={2,2,2,4,4,3,4,3,4,4,4,4}
 msp={132,132,132,140,34,34,34,34,34,34,34,34}
 mspee[10]=2 mspee[11]=2 mspee[12]=2
 pal(12,2)
end
function r4_set()
 mapdata={12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,
          12, 7,11,11, 9,12,12, 7,11,11, 9,12, 7,11, 9,12,
          12,10,12,12, 4,11,11, 3,12,12, 4,11, 6,12,10,12,
          12,10,12,12,10,12,12,12,12,12,10,12,10,12,10,12,
          12, 1,11, 8, 3,12, 7,11, 9,12, 1,11, 5,11, 3,12,
          12,12,12,10,12,12,10,12,10,12,12,12,10,12,12,12,
          12,12,12,10,12, 7, 3,12,10,12,12,12,10,12,12,12,
          12, 7,11, 5,11, 6,12,12,10,12, 7,11, 2,11, 9,12,
          12,10,12,10,12,10,12, 7, 3,12,10,12,12,12,10,12,
          12, 1, 8, 2,11, 2,11, 6,12,12,10,12,12, 7, 3,12,
          12,12,10,12,12,12,12,10,12, 7, 2, 8,11, 6,12,12,
          12, 7, 2,11, 9,12, 7, 3,12,10,12,10,12, 1, 9,12,
          12,10,12,12, 4,11, 6,12,12,10,12,10,12,12,10,12,
          12, 1,11,11, 3,12, 1,11,11, 3,12, 1,11,11, 3,12,
          12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12}
 roundx=48 esa=8 rmuteki=30

 x = 7  * 8  y  = 13 * 8
 vx = -8     vy = 0
 pacd = 1    pacmuki  = 1
 
 mm = {1,1,1,1,2,2,2,2,2,2,2,2}
 mx = {  8,112,  8,112, 20, 48,100,112,64,64,104, 8}
 my = { 12, 10, 60, 56,  8, 40,  8, 30, 8,64, 76,88}
 md = {4,4,4,4,1,3,2,3,1,3,3,4}
 mst={1,2,3,4,4,4,4,4,4,4,4,4}
 msp={128,132,136,140,42,42,42,42,42,42,42,42}
 pal(12,14)
end
function r5_set()
 mapdata={12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,
          12, 7,11,11,11,11, 8,11,11, 8,11,11,11,11, 9,12,
          12,10,12,12,12,12,10,12,12,10,12,12,12,12,10,12,
          12,10,12, 7,11,11, 5,11,11, 5,11,11, 9,12,10,12,
          12,10,12,10,12,12,10,12,12,10,12,12,10,12,10,12,
          12,10,12,10,12, 7, 2, 8,11, 2, 9,12,10,12,10,12,
          12, 1, 8, 2, 8, 3,12,10,12,12, 1, 8, 2, 8, 3,12,
          12,12,10,12,10,12,12, 1, 9,12,12,10,12,10,12,12,
          12, 7, 2, 8, 2, 9,12,12,10,12, 7, 2, 8, 2, 9,12,
          12,10,12,10,12, 1, 8,11, 2, 8, 3,12,10,12,10,12,
          12,10,12,10,12,12,10,12,12,10,12,12,10,12,10,12,
          12,10,12, 1,11,11, 5,11,11, 5,11,11, 3,12,10,12,
          12,10,12,12,12,12,10,12,12,10,12,12,12,12,10,12,
          12, 1,11,11,11,11, 2,11,11, 2,11,11,11,11, 3,12,
          12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12}
 roundx=64 esa=8 rmuteki=30

 x = 7  * 8  y  = 13 * 8
 vx = -8     vy = 0
 pacd = 1    pacmuki  = 1
 
 mm = {1,1,1,1,2,2,2,2,2,2,2,2}
 mx = {  8,112,  8,112, 20, 48,92,112,64,64,96, 8}
 my = { 12, 10, 60, 56,  8, 40, 8, 30, 8,64,76,88}
 md = {4,4,4,4,1,3,2,3,1,3,3,4}
 mst={1,2,4,4,4,4,4,4,4,4,4,4}
 msp={128,132,136,140,46,46,46,46,46,46,46,46}
 mspee={0.5,1,0.5,2,0.5,1,1,2,2,2,4,4}
 pal(12,8)
end
function r6_set()
 mapdata={12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,
          12,12,12,12, 7,11,11,11,11,11, 9,12, 7,22, 9,12,
          12,12, 7,11, 3,12,12,12,12,12, 1,11, 3,12,10,12,
          12, 7, 3,12,12,12, 7,11, 9,12,12,12,12,12,10,12,
          12,10,12,12, 7,11, 3,12,10,12, 7,11, 9,12,10,12,
          12, 1,11,11, 3,12,12,12,10,12,10,12,10,12,10,12,
          12,12,12,12,12,12, 7,11, 5,11, 3,12, 1,11, 3,12,
          12, 7,11,11, 9,12,10,12,10,12,12,12,12,12,12,12,
          12,10,12,12,10,12,10,12,10,12, 7,11,11,11, 9,12,
          12, 1, 9,12, 1,11, 3,12, 1,11, 3,12,12,12,10,12,
          12,12,10,12,12,12,12,12,12,12,12,12, 7,11, 3,12,
          12, 7, 3,12, 7,11, 9,12, 7,11, 9,12,10,12,12,12,
          12,10,12,12,10,12,10,12,10,12,10,12,10,12,12,12,
          12, 1,11,11, 3,12, 1,11, 3,12, 1,11, 3,12,12,12,
          12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12}
 roundx=80 esa=10 rmuteki=5

 x = 8  * 8  y  = 6 * 8
 vx = -8     vy = 0
 pacd = 1    pacmuki  = 1
 
 mm = {1,1,2,2,2,2,2,2,2,2,2,2}
 mx = { 64,64,  8,112, 20, 48,92,112,64,48,96, 8}
 my = { 64, 8, 60, 64, 16, 32, 8, 40,24,64,80,88}
 md = {4,1,4,4,1,1,2,3,1,4,3,4}
 mst={2,2,4,4,4,4,4,4,4,4,4,4}
 msp={132,132,21,34,42,46,50,54,58,46,46,46}
 mspee={4,0.5,1,1,1,1,1,0.5,1,0.5,1,1}
 pal(12,12)
end