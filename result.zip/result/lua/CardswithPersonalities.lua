-- a deck building game
-- by sebastian lind

m_t="♪ music off"
a_n_t="⬅️ auto next"
a_a_t="🐱 auto attack"
function _init()
	load_save()
	menuitem(1,m_t..is_on(music_off), function() toggle_music() end)
	menuitem(2,a_n_t..is_on(auto_next), function() toggle_auto_next() end)
	menuitem(3,a_a_t..is_on(auto_attack), function() toggle_auto_attack() end)
	if (not music_off)music(1,300)

	pal(0, 129, 1)
end

function is_on(boolean) 
	if boolean then 
		return ":♥"
	end
	return ":✽"
end

function bool_to_num(value)
  return value and 1 or 0
end

function num_to_bool(value)
  return value==1 and true or false
end

function change_menu(bool,menu_i)
	bool=not bool
	sfx(1)
	dset(6+menu_i,bool_to_num(bool))
	return bool
end

function toggle_auto_next()
	auto_next=change_menu(auto_next,2)
	menuitem(2,a_n_t..is_on(auto_next),function() toggle_auto_next()  end)
end

function toggle_music()
	music_off=change_menu(music_off,1)
	if music_off then
		music(0,200)
	else
		music(game_state == 0 and 1 or 11,200)
	end
	menuitem(1,m_t..is_on(music_off),function() toggle_music()  end)
end

function toggle_auto_attack()
	auto_attack=change_menu(auto_attack,3)
	menuitem(3,a_a_t..is_on(auto_attack),function() toggle_auto_attack()  end)
end

function reset_match()
 play_cards,lane_cards,graveyard,game_state={},{},{},1
end

function start_match(boss_id)
	if(not music_off)music(11,200)
	sfx(1)
	ba_unlock_s,bo_unlock_s,tim,lane_i="","",0,0
	shake+=0.1
	for i=0,20 do
		init_particle(rnd(128),rnd(128),30+rnd(30),0,0,-4-rnd(3))
	end
	init_boss(boss_id)
	reset_stats(true)
	shuffle(deck)
	shuffle(lane_deck)
	start_lane(2)
end

function start_lane(total)
	local m_total=0
	local i=1
	while (#lane_cards < 4) do
		init_card(get_next_lane_index(),i,false)
		if lane_cards[i].type == 2 then
				if m_total < total then
					m_total+=1
					i+=1
				else
					del(lane_cards,lane_cards[i])
				end
		else
			i+=1
		end
	end
	init_card(3,5,false)
end

function _update60()
	tim = time()
	handle_game_over()
	if game_state == 1 then
		is_draw_ready,is_shuffle_ready,is_grave_ready=can_draw(),can_shuffle(),can_grave()
		update_heart()
		update_shield()
		update_boss()
		handle_graveyard()
		handle_turn_over()
	end
	foreach(play_cards,update_card)
	foreach(lane_cards,update_card)
	foreach(resources,update_resource)
	foreach(card_effects,update_card_effect)
	foreach(particles,update_particle)

	if game_state == 0 then
		handle_menu()
	elseif game_state == 1 then
		if not card_played and not next_turn and not graveyard_show and confirm==-1 then
			if (btnp(⬅️) or btnp(➡️)) change_selected()
			if (btnp(⬆️) or btnp(⬇️)) change_row()
			if btnp(4) then
				if is_draw_ready then
					draw_from_deck()
				elseif is_shuffle_ready then
					shuffle_deck()
				elseif is_grave_ready and not graveyard_show then
					show_graveyard()
				elseif b_select == 1 and row_select == 2 then
					attack_boss()
				end
			end
		end
		handle_confirm_box()
		react_to_confirmation()
	elseif game_state == 2 then
		update_xp()
	end
end

function _draw()
 cls(0)
 for c=0,255 do
  spr(graveyard_show and 198 or (207+background_id),c%16*8,flr(c/16)*8)
 end
 if game_state == 0 then
	draw_menu()
 else
	draw_game()
 end
end

function drawp(p,func,...)
 fillp(p)
 func(...)
 fillp()
end

function draw_menu()
	local wave=sin(tim)*1.1
	camera(0,m_camera_y)
	spr(119,28,4-wave*2,9,6)

	print("⬅️ choose background ➡️",18,88,menu_lane == 0 and 12 or 7)
	print("⬅️    choose boss    ➡️",18,96,menu_lane == 1 and 8 or 7)
	foreach(particles,draw_particle)
	if menu_lane == 0 then
		draw_b_menu()
	elseif menu_lane == 1 then
		draw_bo_menu()
	elseif menu_lane == 2 then
		drawp(0b0011001111001100.1,rectfill,30-bu_l_i,104,98+bu_l_i,120,1)
	elseif menu_lane == 3 then
		draw_about(wave)
	elseif menu_lane == -1 then
		draw_stats(wave)
	end

	rect(30-bu_l_i,104,98+bu_l_i,120,7)
	print("start" .. (menu_lane == 2 and " ❎/🅾️" or ""), menu_lane == 2 and 42 or 54,110,7)

	if(menu_lane > -1)spr(150,119,m_camera_y+4+wave)
	if(menu_lane < 3)spr(166,119,114+m_camera_y+3-wave)
end

function draw_b_menu()
	rectfill(0,64,128,80,0)
	for i=0,8 do
		spr(208+i,4+i*16,68)
		if (i >= back_unlock) spr(192,4+i*16,68)
		drawp(0b0011001111001100.1,rect,4+back_l_i*16-1,67,4+back_l_i*16+8,76,7)
	end
end

function draw_bo_menu()
	rectfill(0,64,128,80,0)
	local b=(1-boss_l_i)*16
	for i=0,7 do
		spr(224+i*2,8+i*24+b,64,2,2)
		if i >= boss_unlock then
			spr(193,1+i*24+b+12,68)
		end
	end
	print(boss_stats[boss_i][2], 8+boss_l_i*24-1+b,56,8)
	drawp(0b0011001111001100.1,rect,8+boss_l_i*24-1+b,63,8+boss_l_i*24+15+b,80,7)
end

-- this was painful to do, hopefully helpful for some!

htp_text = "\^icontrols\^-i\n\nmove cursor: ⬅️➡️⬆️⬇️\naction button: 🅾️/z\nsecondary button: ❎/x\n\n\^irules\^-i\n\nevery turn starts by you\ndrawing five cards from your\ndeck.\n\nyour deck always starts with\nthe same ten cards, seven\nmediocre bards and the three\ncommon guards.\n\nin order to win you will need\nto buy and defeat cards in the\nmiddle lane to build a better\ndeck.\n\nto do that,first draw from\nyour deck by pressing\nthe action button,then\nselect which card you want to\nplay and again press\nthe action button.\nafter that,select the monster\nor minion you want to\nslay/buy.\n\nif you want to read more about\nthe cards,press the secondary\nbutton on them at any time.\n\n"
htp_1 = "\^icards\^-i\n\nthere are three types of cards:\n\n\^wminions\^-w\n\ncost gold to buy and are\nindicated by the color of light\nblue or brown for common cards.\n\nwhen bought,they are put in the\ngraveyard and will be shuffled\nin the deck when there are no\ncards left to draw from your\ndeck.the effects of the minions are\nactivated when they are played.\n\n\^wmonsters\^-w\n\ncost attack to slay and are\nindicated by the color of\ndark purple.\n\nmonsters in the lane attack\nevery turn for one damage\nso keep that in mind.\nthe effects are played out\nwhen slaying them.\n\nafter doing its effects the\nmonster is removed from play.\n\n"
htp_2 = "\^wbosses\^-w\n\neach boss has different effects.\nthey will only attack when\ntheir criteria are met.\n\nthe criteria are always\ndepending how many turns\na player have taken.\nwhen the number of turns\ncorresponds to the criteria,\nthe boss will attack and\nthe turns will reset to zero.\n\nbosses will also boost up their\nattack,it follows a\nsimilar pattern to the\ncriteria.\n\non every turn end\nthe boss will add one\npoint to the boost,when all\nthe dots are filled up\nthe boss attack will increase\nand the dots will reset to zero.\n\none really important thing\nto keep in mind is to\nremember to attack the boss,\nthis will attack the boss\nwith your remaining attack\nso if you plan to slay monsters\ndo that first.\n\n* an option exist in the\npause menu to auto attack\non turn end.\n\n"
htp_3 = "\^iend turn\^-i\n\nif you have no cards left\nto play and you have done\neverything you planned this\nturn,press the action button on\nyour deck and the turn will end.\n\nthree things will always\nbe checked.\n\nfirst all your resources will\nreset (excluding block\nthat will reset last).\nthen if monsters exist in the\nlane they will attack.\nand lastly if the criteria of\nthe boss are met,it too\nwill attack.\n\nthen five new cards can be\ndrawn again and a\nnew turn starts.\n\n\^igame end\^-i\n\neach game will have you trying\nto reduce the current boss\nhealth to zero.\n\nif you manage that you will\nbe rewarded with lots of xp\nto unlock more bosses\nand backgrounds.\n\nif the boss manages to reduce\nyour health to zero the game\nends as well,only rewarding\nyou xp for how much health you\nmanaged to reduce\nfrom the boss.\n"
function draw_about(wave)
	print(htp_text..htp_1..htp_2..htp_3,2,m_camera_y+24+scroll_text_y,7)
	rectfill(0,m_camera_y,128,m_camera_y+18,0)
	print("how to play",1,4+m_camera_y,12)
	print("scroll text: ⬅️ ➡️",1,m_camera_y+12,13)
end

function draw_stats(wave)
	print("info",2,4+m_camera_y,14)
	local win_rate = games_won > 0 and flr(games_won / games_played * 100) or 0
	local stat_s= "level: " .. level .. "\n\nxp: " .. xp .. " / " .. xp_goal .. "\n\ngames played: " .. games_played .. "\n\nwin rate: " .. win_rate .. " %"
	print(stat_s,4,m_camera_y+18,7)
		print("this game was made by:\nsebastian lind @elastiskalinjen\n\nmusic/sfx:\njose ramon garcia @bibikigl\n\nmain tester:\nsimon lind @ytfftw",2,m_camera_y+72,14)
end

function draw_game()
	draw_grave_deck()

	if graveyard_show then
		draw_show_graveyard()
	else
		draw_boss()
		for i=1,max_cards_out do
			draw_card_line(d_s_x+2-i*20,d_l_y,i == 5 and 12 or 1)
		end
		for i=1,3 do
			circfill(5+i*5,80,1,i > g_pick and 1 or 12)
		end
		for i=1,max_cards_out do
			draw_card_line(d_s_x+2-i*20,d_s_y,2)
		end
		foreach(lane_cards,draw_card)
		foreach(play_cards,draw_card)

		if game_state == 1 then
			draw_deck()
			draw_lane_deck()
			draw_pointer()
			draw_confirm()
			draw_timer()
		end
	end

	doshake()
	foreach(card_effects,draw_card_effect)
	draw_ui()
	foreach(particles,draw_particle)
	foreach(resources,draw_resource)

	if (game_state == 2 and level_delay <=10) draw_xp()
end

local function splitd(input, delim, ...)
 local out, pos = {}, 0
 if type(input) == "string" then
  local item
  for i = 1, #input do
   if sub(input, i, i) == delim then
    item = sub(input, pos, i - 1)
    add(out, tonum(item) or item)
    pos = i + 1
   end
  end
  item = sub(input, pos)
  add(out, tonum(item) or item)
 end
 if ... then
  for i = 1, #out do
   out[i] = splitd(out[i], ...)
  end
 end
 return out
end


-->8
-- gameplay

function reset_stats(start)
	if start then
		row_select,c_select,l_select,b_select,active_card_index,grave_index,deck_index,max_cards_out,start_draws,turns,next_turn,next_turn_timer=0,0,1,1,-1,1,0,5,5,0,false,0
		deck={1,1,1,1,1,1,1,2,2,2}
  	play_area,r_draws,r_health,r_block,g_pick,r_attack={false,false,false,false,false},start_draws,30,0,0,0
	else
		r_draws=0
	end
	r_gold,r_destroy,r_remove,r_discard,r_gravedig,r_convert,r_boost=0,0,0,0,0,0,0,0
end

function attack_boss()
 sfx(r_attack>0 and 0 or 5)
	boss_health-=r_attack
	shake=0.1
	for i=1,r_attack do
		init_particle(boss_x+rnd(74),boss_y+rnd(card_s_h),3+rnd(3),8)
	end
	boss_h_y,r_attack=r_attack,0
end

function show_graveyard()
	sfx(1)
	graveyard_show,grave_index=true,1
	for c in all(graveyard) do
		c.y,c.x,c.w,c.h=card_r_y,card_r_x,card_r_w,card_r_h
		c.state=5
	end
end

function go_to_next_turn()
	next_turn,confirm=true,-1
	turns+=1
	reset_stats(false)
	next_turn_timer=180
end

timer_y,block_t=130,0
function handle_turn_over()
	if next_turn_timer > 0 then
		timer_y = lerp(timer_y,49,0.3)
		if next_turn_timer == 1 then
			if(r_block < 0)block_t+=1
			if (r_block > 0 or block_t > 1) r_block,block_t=0,0
			next_turn=false
			b_select,row_select=0,0
		elseif next_turn_timer == 30 then
			check_turn_boss()
		elseif next_turn_timer == 60 then
			if r_attack > 0 and auto_attack then
				b_select,row_select=1,2
				attack_boss()
			else
				r_attack=0
			end
		elseif next_turn_timer == 64 then 
			if (auto_attack)b_select,row_select=1,2
		elseif next_turn_timer == 120 then
			sfx(1)
			local a=false
			for c in all(lane_cards) do
				if c.type == 2 then
					a=true
					shake+=0.05
					init_resource("o",218,c.x,c.y-4)
					init_particle(c.x+rnd(c.w),c.y+rnd(c.h),1+rnd(2),6)
				end
			end
			if (a)sfx(0)
		elseif next_turn_timer == 150 then
			draw_from_deck()
		elseif next_turn_timer == 180 then
			r_draws=5
			for c in all(play_cards) do
				c.state=4
			end
			if is_shuffle_ready then 
				shuffle_deck()
			end
		end
		next_turn_timer-=1
	else
		timer_y=lerp(timer_y,130,0.2)
	end
end

function handle_game_over()
	if game_state == 1 and (r_health < 1 or boss_health < 1) then
		music(-1,300)
		game_state=2
		shake+=0.3
		for i=0,#deck do
			init_card_effect(d_s_x,d_s_y,rnd(128),rnd(128),2,8)
		end
		for c in all(lane_cards) do
			c.state=6
		end
		for c in all(play_cards) do
			c.state=6
		end
		games_played+=1
		dset(5,games_played)
		if boss_health <= 0 then
			sfx(6)
			games_won+=1
			dset(6,games_won)
		else
			sfx(7)
		end
		get_xp()
	end

	if game_state == 2 and c_xp == xp then
		if btnp(4) then
			reset_match()
			start_match(boss_i)
		end
		if btnp(5) then
			sfx(2)
			reset_match()
			if(not music_off)music(1,300)
			menu_lane,game_state=0,0
		end
	end
end

function shuffle_deck()
	if #graveyard > 0 then
		sfx(9)
		deck_index,deck=0,{}
		shake+=0.05
		for c in all(graveyard) do
			add(deck,c.id)
			init_card_effect(grave_x+rnd(4),grave_y+rnd(4),d_s_x,d_s_y,2,8)
		end
		graveyard={}
		shuffle(deck)
	end
end

function handle_graveyard()
	grave_x=lerp(grave_x,row_select == 2 and b_select == 0 and grave_s_x-16 or grave_s_x,0.1)

	if graveyard_show then
		if btnp(4) then
			dig_the_grave()
		elseif btnp(5) then
			sfx(2)
			graveyard_show=false
		end

		for c in all(graveyard) do
			c.y=lerp(c.y,card_r_y,0.1)
		end
		if btnp(➡️) then
			sfx(4)
			if grave_index < #graveyard then
				grave_index+=1
			else
				grave_index=1
			end
			graveyard[grave_index].y=48
		elseif btnp(⬅️) then
			sfx(4)
			if grave_index > 1 then
				grave_index-=1
			else
				grave_index=#graveyard
			end
			graveyard[grave_index].y=48
		end
	end
end

function dig_the_grave()
	if can_grave_dig() then
		sfx(1)
		r_gravedig-=1
		local remove_i=grave_index
		grave_index=1
		local play_area_index = find_a_card_position()
		if play_area_index ~= -1 then
			init_card(graveyard[remove_i].id,play_area_index,true)
		end
		del(graveyard,graveyard[remove_i])
	end
end

function draw_from_deck()
	sfx(3)
	for i=1, #play_area do
		if can_draw() and not play_area[i] then
			local play_area_index = find_a_card_position()
			if play_area_index ~= -1 then
				deck_index+=1
				r_draws-=1
				init_card(deck[deck_index],play_area_index,true)
			end
		end
	end
end

function get_next_lane_index()
	if lane_i == #lane_deck then
		lane_i=0
		shuffle(lane_deck)
	end
	lane_i+=1
	return lane_deck[lane_i]
end

function change_row()
	if btnp(⬆️) then
		if row_select < 2 then
			row_select+=1
			sfx(4)
		end
	end
	if btnp(⬇️) then
		if row_select > 0 then
			row_select-=1
			sfx(4)
		end
	end
	if row_select ~= 0 then
		for i=1,#play_cards do
			play_cards[i].active=false
		end
	end
	if row_select ~= 1 then
		for i=1,#lane_cards do
			lane_cards[i].active=false
		end
	end
	highlight_active_card()
end

function change_selected()
	if #play_cards == 0 and row_select == 0 then
		c_select = 0
		return
	end

	if btnp(➡️) then
		sfx(4)
		if row_select == 0 then
			if c_select-1 == -1 then
				c_select = #play_area+1
			end
			c_select = find_next_card_in_area(c_select-1,-1)
		elseif row_select == 1 then
   l_select = (l_select-2)%#play_area+1
		elseif row_select == 2 then
   b_select = 1-b_select
		end
	elseif btnp(⬅️) then
		sfx(4)
		if row_select == 0 then
			c_select = find_next_card_in_area(c_select+1,1)
		elseif row_select == 1 then
   l_select = l_select%#play_area+1
		elseif row_select == 2 then
   b_select = 1-b_select
		end
	end
	highlight_active_card()
end

function highlight_active_card()
	if row_select == 0 then
		active_card_index=-1
		for i=1,#play_cards do
			if play_cards[i].play_index == c_select then
				play_cards[i].active=true
				active_card_index=i
			else
				play_cards[i].active=false
			end
		end
	elseif row_select == 1 then
		active_card_index=-1
		for i=1,#lane_cards do
			if lane_cards[i].play_index == l_select then
				lane_cards[i].active=true
				active_card_index=i
			else
				lane_cards[i].active=false
			end
		end
	end
end

function find_a_card_position()
	for i=1, #play_area do
		if not play_area[i] then
			play_area[i]=true
			return i
		end
	end
	return -1
end

function find_next_card_in_area(index,dir)
	if index == 0 or index > #play_area then
		return 0
	elseif play_area[index] then
		return index
	else
		return find_next_card_in_area(index+dir,dir)
	end
end

function react_to_confirmation()
	if btnp(5) and not next_turn and ((c_select == 0 and row_select == 0) or (b_select == 1 and row_select == 2)) then
		if confirm == -1 then
			if (b_select == 1 and row_select == 2) or check_resources_resources_left() then
				confirm=0
			else 
				confirm=1
			end
			sfx(1)
		elseif confirm == 2 then
			confirm=-1
		end
	end

	if confirm == 1 then
		if b_select == 1 and row_select == 2 then
			r_health,confirm=0,-1
		elseif c_select == 0 and row_select == 0 then
			go_to_next_turn()
		end
	end
end

function check_resources_resources_left() 
	local monsters=0
	local mineons=0
	for e in all(lane_cards) do 
		if e.type == 2 and r_attack >= e.cost then
			monsters+=1
		elseif e.type <= 1 and r_gold >= e.cost then
			mineons+=1
		end
	end

	return r_draws > 0 or (r_attack > 0 and monsters > 0) or (r_gold > 0 and mineons > 0) 
	or (r_gravedig > 0 and #graveyard > 1) or (r_convert > 0 and monsters > 0) or #play_cards > 0
	or (r_attack > 0 and not auto_attack)
end

confirm,confirm_y=-1,150
function handle_confirm_box()
	if confirm == 0 then
		confirm_y=lerp(confirm_y,40,0.2)
		if btnp(4) then
			confirm=1
			sfx(1)
		end
		if btnp(5) then
			confirm=2
			sfx(2)
		end
	else
		confirm_y=lerp(confirm_y,150,0.2)
	end
end

function can_draw()
	return deck_index < #deck and
	#play_cards < max_cards_out and
	c_select == 0 and
	row_select == 0 and
	not card_played and r_draws > 0
end

function can_shuffle()
	return c_select == 0 and
	row_select == 0 and
	deck_index == #deck
end

function can_grave()
	return b_select == 0 and
	row_select == 2 and
	#graveyard > 0
end

function can_grave_dig()
	return r_gravedig > 0 and
	#play_cards < max_cards_out and
	#graveyard > 1
end

background_id,boss_i,menu_lane,m_camera_y,back_l_i,boss_l_i,bu_l_i,scroll_text_y,scroll_text_sp=1,1,0,0,0,0,0,0,0.4
function handle_menu()
	if btnp(2) and menu_lane > -1 then
		scroll_text_y=0
		menu_lane-=1
		sfx(4)
	end
	if btnp(3) and menu_lane < 3 then
		menu_lane+=1
		sfx(4)
	end

	if menu_lane == 0 then
		if btnp(0) and background_id > 1 then
			background_id-=1
			sfx(4)
		end
		if btnp(1) and background_id < back_unlock then
			background_id+=1
			sfx(4)
		end
		back_l_i=lerp(back_l_i,background_id-1+0.05,0.2)
	elseif menu_lane == 1 then
		if btnp(0) and boss_i > 1 then
			boss_i-=1
			sfx(4)
		end
		if btnp(1) and boss_i < boss_unlock then
			boss_i+=1
			sfx(4)
		end
		boss_l_i=lerp(boss_l_i,boss_i-1+0.05,0.2)
	elseif menu_lane == 2 then
		if btnp(4) or btnp(5) then
			reset_match()
			start_match(boss_i)
		end
	elseif menu_lane == 3 then
		if btn(0) then
			if(scroll_text_sp < 1.2)scroll_text_sp+=0.01 
			if(scroll_text_y < 0)scroll_text_y +=scroll_text_sp
		elseif btn(1)  then
			if(scroll_text_sp < 1.2)scroll_text_sp+=0.01
			if(scroll_text_y > -800)scroll_text_y -=scroll_text_sp
		else
			if(scroll_text_sp > 0.4)scroll_text_sp-=0.02
		end
	elseif menu_lane == -1 then
		if (flr(tim * 1000) % 2 == 0)init_particle(rnd(128),rnd(128)-128,5+rnd(5),2,0,-2-rnd(3))
	end

	if menu_lane == 2 then
		bu_l_i=lerp(bu_l_i,12,0.2)
	else
		bu_l_i=lerp(bu_l_i,0,0.2)
	end

	if menu_lane < 0 then
		m_camera_y=lerp(m_camera_y,-128,0.15)
	elseif menu_lane > 2 then
		m_camera_y=lerp(m_camera_y,128,0.15)
	else
		m_camera_y=lerp(m_camera_y,0,0.15)
	end
end

-->8
-- draw

grave_s_x,grave_x,grave_y,gold_x,attack_x,block_x,draw_x,discard_x,destroy_x,remove_x,health_x=114,114,24,1,19,37,55,73,91,109,120
function draw_ui()
rectfill(0,121,128,128,1)
print(get_action_string(),2,122,7)

rectfill(0,0,128,8,1)
spr(1,gold_x,0)
print(r_gold,10,2,10)

spr(2,attack_x,0)
print(r_attack,28,2,6)

spr(8,block_x,sh_time/10)
print(r_block,47,2,13)

spr(3,draw_x,0)
print(r_draws,64,2,2)

spr(9,discard_x,0)
print(r_discard,82,2,5)

spr(4,destroy_x,0)
print(r_destroy,100,2,9)

rectfill(109,0,128,19,1)

spr(6,remove_x,0)
print(r_remove,118,2,4)

spr(h_spr,110,11)
print(r_health,health_x,13,8)
end

function draw_card_line(x,y,c)
	rect(x-1,y-1,x+card_s_w+1,y+card_s_h+1,c)
end

function draw_deck()
	draw_card_line(d_s_x,d_s_y,0)
	if deck_index ~= #deck then
		rectfill(d_s_x,d_s_y,d_s_x+card_s_w,d_s_y+card_s_h,2)
		spr(196,d_s_x+2,d_s_y+8)
	end
	rect(d_s_x,d_s_y,d_s_x+card_s_w,d_s_y+card_s_h,8)
	if c_select == 0 and row_select == 0 then
		drawp(0b0011001111001100.1,rect,d_s_x-1,d_s_y-1,d_s_x+card_s_w+1,d_s_y+card_s_h+1,not is_draw_ready and 14 or 7)
		print("d:"..#deck - deck_index, d_s_x-1, d_s_y-8,14)
	elseif r_draws > 0 then
		rect(d_s_x-1,d_s_y-1,d_s_x+card_s_w+1,d_s_y+card_s_h+1,14)
	end
end

function draw_lane_deck()
	if not card_read then
		if lane_i < #lane_deck then
			rectfill(l_d_s_x,d_l_y,l_d_s_x+card_s_w,d_l_y+card_s_h,1)
			spr(197,l_d_s_x+2,d_l_y+8)
		end
		rect(l_d_s_x,d_l_y,l_d_s_x+card_s_w,d_l_y+card_s_h,12)
		draw_card_line(l_d_s_x,d_l_y,0)
	end
end

function draw_grave_deck()
	if #graveyard > 0 then
		rectfill(grave_x,grave_y-1,grave_x+card_s_h,grave_y+card_s_w,5)
		rect(grave_x+1,grave_y,grave_x+card_s_h-1,grave_y+card_s_w-1,1)
	end
	if r_gravedig > 0 and not graveyard_show then 
		spr(5,grave_x-9,grave_y+2)
	end
	spr(15,grave_x+4,grave_y+2)
	drawp(row_select == 2 and b_select == 0 and 0b0011001111001100.1 or nil,rect,grave_x,grave_y-1,grave_x+card_s_h,grave_y+card_s_w,6)
end

function get_action_string()
	if (game_state == 2 and c_xp == xp) return "🅾️ = retry | ❎ = back to menu"
	if game_state == 1 then
		if c_select == 0 and row_select == 0 then
   return (is_draw_ready and "🅾️ = draw" or
          (is_shuffle_ready and "🅾️ = shuffle" or
          (#play_cards == max_cards_out and "😐 = area full" or
          (r_draws == 0 and "😐 = no draws" or
          "")))) .. " | ❎ = end turn"
		else
			if card_read then
				return "❎ = close"
			elseif row_select == 0 then
    return (r_discard > 0 and "🅾️ = discard" or
           (r_destroy > 0 and "🅾️ = destroy" or
            "🅾️ = play")) .. " | ❎ = " .. (card_choose and "cancel" or "read")
			elseif row_select == 1 then
    return (r_convert > 0 and lane_cards[active_card_index].type == 2 and "🅾️ = convert" or
           (r_remove == 0 and
            (lane_cards[active_card_index].type ~= 2 and
             (r_gold >= lane_cards[active_card_index].cost and "🅾️ = buy" or "😐 = coins missing") or
             (r_attack >= lane_cards[active_card_index].cost and "🅾️ = slay" or "😐 = attack missing")) or
            "🅾️ = remove")) .. " | ❎ = " .. (card_choose and "cancel" or "read")
			elseif row_select == 2 then
    return (b_select == 0 and
            (graveyard_show and
             (can_grave_dig() and "🅾️ = dig grave | " or
             (r_gravedig > 0 and #play_cards == max_cards_out and "😐 = play area full | " or
             (r_gravedig > 0 and #graveyard == 1 and "😐 = 1 card left | " or ""))
            ) .. "❎ = close" or
            (is_grave_ready and "🅾️ = show graveyard" or "😐 = no cards in graveyard")) or
           (r_attack > 0 and "🅾️ = attack" or "😐 = no attack") .. " | ❎ = forfeit")
			end
		end
	else
		return ""
	end
end

function draw_timer()
	if timer_y < 128 then
		local anim=2*(3-flr(next_turn_timer/60))-2
		spr(160+anim,56,timer_y+4,2,2)
		spr(216,2,100 - anim*20)
	end
end

function draw_pointer()
	if play_cards ~= nil and play_area[c_select] == false then
		spr(row_select==0 and 13 or 14,card_s_x+2-((c_select-1)*20),d_s_y+10)
	end
end

function draw_confirm()
	rectfill(0,confirm_y,128,confirm_y+32,2)
	local is_deck_selected = c_select == 0 and row_select == 0
	local c_text = is_deck_selected and "end turn?" or "forfeit?"
	local d_text = is_deck_selected and "you have resources left" or " sure you want to give up?"
	print(d_text, is_deck_selected and 16 or 7, confirm_y+15,is_deck_selected and 9 or 14)
	print(c_text,46,confirm_y+4,7)
	print("🅾️ = yes | ❎ = no", 26, confirm_y+26,7)
end

function draw_show_graveyard()
	print(grave_index ..  " of " .. #graveyard .. " is shown",4,32,6)
	draw_card(graveyard[grave_index])
	print("⬅️/➡️ browse cards",4,graveyard[grave_index].y+52,7)
	if r_gravedig > 0 then 
		print("shovels left: ", 4,14,6)
	end
	for i=0,r_gravedig-1 do 
		spr(5,56+i*10,12)
	end
end

-->8
-- play_cards
d_s_x,d_s_y,d_e_y,l_d_s_x,l_d_s_y,d_l_x,d_l_y=107,93,81,107,48,89,52
card_s_x,card_s_y,card_s_h,card_s_w=89,93,24,12

--play
card_dp_y=52 --deck
card_lp_y=20 --lane

card_r_y,card_r_x,card_r_w,card_r_h,card_played,card_read,card_destroyed,card_choose=42,2,124,46,false,false,false,false

reset_match()

game_state=0

function init_card(id,play_index,is_in_deck)
	local the_card=all_cards[id]

	local c={
		is_in_deck=is_in_deck,
		x=is_in_deck and d_s_x or l_d_s_x,
		y=is_in_deck and d_s_y-4 or l_d_s_y,
		ex=is_in_deck and card_s_x-((play_index-1)*20) or d_l_x-((play_index-1)*20),
		ey=is_in_deck and card_s_y or d_l_y,
		id=id,
		im_id=15+id+((flr((id-1)/16))*16),
		cost=the_card[1],
		name=the_card[2],
		type=the_card[3],
		effects=parse_effects(the_card[4]),
		play_index=play_index,
		active=false,
		state=0,
		w=card_s_w,
		h=card_s_h,
		pc=8,
	}

	c.s_desc = c.type >= 2 and not is_in_deck and "when slain:" or "when played:" 
	c.desc,c.col,c.hcol,c.ccol=get_effects_desc_id(c.effects),parse_type_col(c.type)

	add(is_in_deck and play_cards or lane_cards,c)
end

function card_intro_s(c)
	if distance(c.x,c.y,c.ex,c.ey) > 0.5 then
		c.x,c.y,c.w,c.h=lerp(c.x,c.ex,0.1),lerp(c.y,c.ey,0.1),lerp(c.w,card_s_w,0.2),lerp(c.h,card_s_h,0.2)
	else
		c.x,c.y,c.w,c.h=c.ex,c.ey,card_s_w,card_s_h
		c.state=1
	end
end

function card_idle_s(c)
	if c.active then
		c.y=lerp(c.y,c.ey-8,0.1)
		if not card_played then
			if btnp(4) then -- play
				local fail=false
				if c.is_in_deck then
					if r_discard > 0 or r_destroy > 0 then
						card_choose,c.state=true,8
					else
						c.state=2
					end
					card_played=true
				elseif c.type == 2 and not c.is_in_deck and r_convert > 0 then -- convert
					card_played,c.state=true,2
				elseif c.type >= 1 and not c.is_in_deck and r_remove > 0 then --destroy mid
					card_choose,card_played,c.state=true,true,8
				elseif c.type <= 1 and r_gold >= c.cost then --buy
					card_played,c.state=true,2
				elseif c.type == 2 and r_attack >= c.cost then --slay
					sfx(0)
					card_played,c.state=true,2
				else
					fail=true
					shake+=0.06
				end
    sfx(fail and 5 or 1)
			end
			if btnp(5) then --read
				sfx(2)
				card_played,card_read,c.state=true,true,5
			end
		end
	else
		c.y=lerp(c.y,c.ey+1,0.5)
	end
end

function card_choose_s(c)
	c.y=lerp(c.y,c.is_in_deck and d_s_y-12+sin(tim)*2 or l_d_s_y-12+sin(tim)*2,0.4)
	if btnp(4) then
		sfx(1)
		if c.is_in_deck then
			if r_discard > 0 then
				c.state=4
				r_discard-=1
			elseif r_destroy > 0 then
				r_destroy-=1
				card_destroyed,c.state=true,4
			else
				c.state=2
			end
		else
			r_remove-=1
			card_destroyed,card_played,c.state=true,true,4
		end
	end
	if btnp(5) then
		card_played,card_choose,c.state=false,false,0
		sfx(2)
	end
end

function card_play_s(c)
	local dest = c.is_in_deck and card_dp_y or card_lp_y
	c.y=lerp(c.y,dest,0.3)
	if (c.y < dest+2)c.state = 3
end

function card_action_s(c)
local init_resources=false
	if c.is_in_deck then
		init_resources=true
	else
		if c.type <= 1 then
			r_gold-=c.cost
			init_particle(grave_x,grave_y,1+rnd(3),6)
			add(graveyard,c)
		elseif c.type == 2 then
			if r_convert > 0 then
				r_convert-=1
				shake+=0.075
				init_particle(grave_x,grave_y,1+rnd(3),6)
				add(graveyard,c)
			else
				r_attack-=c.cost
				shake+=0.05
				init_resources=true
			end
		end
	end
	if init_resources then
		for e in all(c.effects) do
			for i=1,e.num do
				init_resource(e.id,e.s_id,c.x+rnd(c.w),c.y+rnd(c.h))
			end
		end
	end
	c.state = 4
end

function card_destroy_s(c)
	card_played,card_read,card_choose=false,false,false

	if c.is_in_deck then
		play_area[c.play_index]=false
		if not card_destroyed then
			add(graveyard,c)
			init_particle(grave_x+rnd(c.w),grave_y+rnd(c.h),1+rnd(2),6)
		end
		del(play_cards,c)
	else
		del(lane_cards,c)
		local id=1
		if c.play_index == 5 and g_pick < 3 then
			id=3
			g_pick+=1
		else
			id=get_next_lane_index()
		end
		init_card(id,c.play_index,false)
		change_selected()
	end

	if not card_destroyed then
		for i=0,4 do
			init_particle(c.x+rnd(c.w),c.y+rnd(c.h),1+rnd(2),random_col(0,c.hcol,c.col))
		end
	else
		sfx(10)
		shake+=0.1
		for i=0,10 do
			init_particle(c.x+rnd(c.w),c.y+rnd(c.h),2+rnd(4),random_col(0,8,9),rnd(4)-2,-3+rnd(2))
		end
		card_destroyed=false
	end

	if row_select == 0 and auto_next then 
		c_select = find_next_card_in_area(c_select,1)
		highlight_active_card()
	end
end

function card_read_s(c)
	c.y,c.x,c.w,c.h=lerp(c.y,card_r_y,0.4),lerp(c.x,card_r_x,0.4),lerp(c.w,card_r_w,0.3),lerp(c.h,card_r_h,0.3)

	if btnp(5) then
		sfx(1)
		card_played,card_read,c.state=false,false,0
	end
end

function explode_card(c)
		init_particle(c.x+rnd(c.w),c.y+rnd(c.h),1+rnd(2),6)
		c.ex+=rnd(100)-rnd(50)
		c.ey+=rnd(100)-rnd(50)
		c.state=7
end

function card_exploded(c)
	c.y,c.x=lerp(c.y,c.ey,0.3),lerp(c.x,c.ex,0.3)
	if c.pc > 0 then
		c.pc-=1
	else
		init_particle(c.x+rnd(c.w),c.y+rnd(c.h),1+rnd(2),random_col(1,5,0),0,-3)
		c.pc=8
	end
end

local update_card_funcs={[0]=card_intro_s,card_idle_s,card_play_s,card_action_s,card_destroy_s,card_read_s,explode_card,card_exploded,card_choose_s}

function update_card(c)
 update_card_funcs[c.state](c)
end

function draw_card(c)
	if (card_read == true and c.state == 5) or card_read == false then
		rectfill(c.x,c.y,c.x+c.w,c.y+c.h,c.col)

		line(c.x,c.y,c.x+c.w,c.y,c.hcol)
		rectfill(c.x+1,c.y+4,c.x+10,c.y+24,0)
		line(c.x+1,c.y+4,c.x+10,c.y+4,1)
		spr(c.im_id,c.x+2,c.y+8,1,2)
		print(c.cost,c.x+1,c.y+1,c.ccol)

		drawp(c.active and 0b0011001111001100.1 or nil,line,c.x,c.y+c.h,c.x+c.w,c.y+c.h,1)

		if c.active then
   local hcol = row_select == 0 and (r_destroy > 0 and 8 or (r_discard > 0 and 12 or 7)) or (row_select == 1 and (r_convert > 0 and 13 or (r_remove > 0 and 2 or 7)))

			drawp(c.active and 0b0011001111001100.1 or nil,rect,c.x-1,c.y-1,c.x+c.w+1,c.y+c.h+1,hcol)
			if c.state ~=5 then
				rectfill(0,11,106,19,1)
				local eff=c.effects
				local x_b=1
				print(c.name,2,13,c.hcol)
				for e in all(c.effects) do
					for n=1,e.num do
						spr(e.s_id,(#c.name*3.5)+4+x_b*8,11)
						x_b+=1
					end
				end
				if r_convert > 0 and c.type == 2 and not c.is_in_deck then
					spr(221,c.x+2,c.y-10)
				end
			end
		end
		if c.state == 5 then --read
			if c.y < card_r_y+1 then
				print(c.name,c.x+card_s_w+4,c.y+4,7)
				print(c.s_desc,c.x+card_s_w+4,c.y+14,c.hcol)
				print(c.desc,c.x+card_s_w+4,c.y+21,7)
			end
			line(c.x+card_s_w+4,c.y+12,c.x+c.w-2,c.y+12,1)
			if not c.is_in_deck and c.type == 2 then
				spr(12,c.x+c.w-16,c.y+2)
				spr(218,c.x+c.w-8,c.y+2)
			end
		end
	else --not active
		if (c.is_in_deck) drawp(0b0011001111001100.1,rect,c.x+1,c.y+1,c.x+c.w-1,c.y+c.h-1,2)
	end
end

resources={}
function init_resource(id,spr,x,y)
	local r={
		id=id,
		spr=spr,
		x=x,
		y=y,
		speed=0.08+(flr(rnd(10))/100)
	}

	local col,ex,ey=0,8,-2
	if id == "c" then
		ex,col=gold_x,10
		r_gold+=1
	elseif id == "a" then
		ex,col=attack_x,7
		r_attack+=1
	elseif id == "d" then
		ex,col=draw_x,2
		r_draws+=1
	elseif id == "b" then
		ex,col=block_x,5
		r_block+=1
	elseif id == "t" then
		ex,col=discard_x,6
		r_discard+=1
	elseif id == "k" then
		ex,col=destroy_x,0
		r_destroy+=1
	elseif id == "h" then
		ex,ey,col=health_x-8,11,9
		r_health+=1
	elseif id == "r" then
		ex,col=remove_x,2
		r_remove+=1
	elseif id == "o" then
		if r_block > 0 then
			ex,ey,sh_time=block_x+rnd(4),rnd(6),50
			r_block-=1
			init_particle(block_x,2,2,2)
		else
			ey,ex=11,health_x-8
			r_health-=1
		end
		col=8
	elseif id == "g" then
		ex,ey,col=grave_x+2,16,4
		r_gravedig+=1
	elseif id == "m" then
		init_particle(gold_x,2,2,9)
		r_attack+=r_gold
		ex,r_gold,col=attack_x,0,9
	elseif id == "e" then
  	ex,ey,col=l_d_s_x+2,l_d_s_y+8,2
		r_convert+=1
	elseif id == "i" then
  	ex,ey,col=d_s_x+2,d_s_y+8,10
		for c in all(play_cards) do
			local need_re_desc=false
			for e in all(c.effects) do
				if e.id == "a" then
					e.num+=1
					need_re_desc,shake=true,0.1
					for i=0,4 do init_particle(c.x+rnd(card_s_w),c.y,2+rnd(2),8+rnd(2),0,-2-rnd(2)) end
				end
			end
			if (need_re_desc)c.desc=get_effects_desc_id(c.effects)
		end
	elseif id == "s" then
		init_particle(block_x,2,2,12)
		r_attack+=r_block
		ex,r_block,col=attack_x,0,13
	elseif id == "p" then
		init_particle(block_x,2,2,12)
		ex,col=block_x,5
		if (r_block > 0)r_block=0
		r_block-=1
	elseif id == "j" then
		for i=1,4 do
			lane_cards[i].state=4
		end
  	ex=l_d_s_x+2,l_d_s_y+8
	end
	r.ex,r.ey,r.tcol=ex,ey,col
	add(resources,r)
end

function update_resource(r)
	r.x,r.y=lerp(r.x,r.ex,r.speed),lerp(r.y,r.ey,r.speed)
	init_particle(r.x+4,r.y+4,1,r.tcol,0.01,0.01)
	if distance(r.x,r.y,r.ex,r.ey) <= 1 then
		if (r.tcol ~= 8)sfx(8)
		del(resources,r)
	end
end

function draw_resource(r)
	spr(r.spr,r.x,r.y)
end

-->8
--boss

boss_s_x=12
function init_boss(id)
	local boss_p=boss_stats[id]
	boss_turns,boss_name,boss_effects,boss_health,boss_b_threshold=boss_p[1],boss_p[2],parse_effects(boss_p[3]),boss_p[4],boss_p[5]
	boss_sprite,boss_y,boss_x,boss_i_y,boss_h_y,boss_s_y,boss_t_boost,boss_w,boss_s_hp=222+id*2,11,boss_s_x,0,0,0,0,86,boss_health
end


boss_stats=splitd("3,earl dracula,o4,42,3;2,baby sharky,o2t2,32,2;5,captain l,o1d1c1,48,1;2,number two,o2p3,40,4;4,gassy bat,o6j1,46,4;1,spitfire lama,o1k1,44,3;4,gloomy leo,o7e1,52,4;6,spark-Y,o6j1t1,60,2",";",",")

function update_boss()
	if (row_select == 2 and b_select == 1) or card_read or (row_select == 0 and c_select == 0) then
		boss_x,boss_i_y=lerp(boss_x,boss_s_x,0.1),lerp(boss_i_y,0,0.1)
		boss_s_y=3*abs(sin(0.4*tim))
		boss_h_y=lerp(boss_h_y,0,0.1)
	else
		boss_x,boss_i_y=lerp(boss_x,-68,0.2),lerp(boss_i_y,10,0.2)
	end
end

function check_turn_boss()
	if turns == boss_turns then
		sfx(0)
		for e in all(boss_effects) do
			for i=1,e.num do
				shake+=0.05
				init_particle(boss_x+rnd(74),boss_y+rnd(card_s_h),3+rnd(3),9)
				init_resource(e.id,e.s_id,boss_x+6,boss_y+4+rnd(16))
			end
		end
		boss_x+=24
		turns=0
	end

	boss_t_boost+=1
	sfx(54)
	if boss_t_boost == boss_b_threshold then
		boss_t_boost=0
		for e in all(boss_effects) do
			for i=1,e.num do
				if e.id == "o" then 
					e.num+=1
					break
				end
			end
		end
	end
end

function draw_boss()
	rectfill(boss_x,boss_y,boss_x+boss_w,boss_y+card_s_h+1,2)
	if (boss_health > 0) spr(boss_sprite,boss_x+2,boss_y+card_s_h-16+boss_s_y-boss_h_y,2,2)

	print(boss_name,boss_x+2,boss_y+2,8)

	drawp(row_select == 2 and b_select == 1 and 0b0011001111001100.1 or nil,rect,boss_x,boss_y,boss_x+boss_w,boss_y+card_s_h+1,8)

	print(boss_health,boss_x+77,boss_y+10+boss_i_y,8)
	spr(217,boss_x+77,boss_y+1+boss_i_y)
	print(turns,boss_x+70,boss_y+10+boss_i_y,9)
	spr(12,boss_x+68,boss_y+1+boss_i_y)

	if boss_x > -32 and boss_health > 0 then
		print(boss_turns.."  =",boss_x+20,boss_y+18,7)
		spr(12,boss_x+23,boss_y+16)
		local x_b,b_sp=1,0
		for e in all(boss_effects) do
			print(e.num,boss_x+23+b_sp+x_b*14,boss_y+18,7)
			if (e.num >= 10) b_sp+=4
			spr(e.s_id,boss_x+28+b_sp+x_b*14,boss_y+16)
			x_b+=1
		end
		local boss_l=#boss_name
		for i=0,boss_b_threshold-1 do
			local c=i < boss_t_boost and 8 or 1
			circfill(boss_x+16+boss_l*3+i*4, boss_y+3,1,c)
		end
	end
end

-->8
--help

function lerp(var,target,pow)
	return var+pow*(target-var)
end

function shuffle(tbl)
	for i=#tbl,2,-1 do
		local j = 1+flr(rnd(i))
		tbl[i],tbl[j] = tbl[j],tbl[i]
	end
	return tbl
end

shake=0
function doshake()
	local shakex,shakey=16-rnd(32),16-rnd(32)
	shakex*=shake
	shakey*=shake
	camera(shakex,shakey)
	shake=shake*0.95
	if(shake < 0.05)shake=0
	if(shake >= 0.3)shake=0.25
end

function distance(x1,y1,x2,y2)
	return sqrt(((x2-x1)/10)^2+((y2-y1)/10)^2)*10
end

-->8
-- misc

h_time,h_spr=0,10
function update_heart()
	if r_health < 15 then
		if h_time < 60 then
			h_time+=1
		else
			h_time=0
			h_spr=21-h_spr
		end
	end
end

sh_time=0
function update_shield()
	if (sh_time > 0)sh_time-=1
end

function random_col(c1,c2,c3)
 return ({c1,c2,c3})[flr(rnd(3))+1]
end

--8
-- effects

particles={}
function init_particle(x,y,rad,col,dx,dy)
	local p={
		x=x,
		y=y,
		dx=dx or rnd(2)-1,
		dy=dy or rnd(2)-1,
		rad=rad,
		col=col,
		sp=rad > 20 and 0.8 or 0.1,
	}
	add(particles,p)
end

function update_particle(p)
	p.dx*=0.9
	p.dy*=0.9
 p.x+=p.dx
 p.y+=p.dy
	p.sp+=rnd(1)/100
	p.rad-=p.sp
	if (p.rad <=0)del(particles,p)
end

function draw_particle(p)
	circfill(p.x,p.y,p.rad,p.col)
end

card_effects={}
function init_card_effect(x,y,ex,ey,col,hcol)
	local c={
		x=x,
		y=y,
		ex=ex,
		ey=ey,
		speed=0.1+flr(rnd(25))/100,
		col=col,
		hcol=hcol
	}

	add(card_effects,c)
end

function update_card_effect(c)
	c.x,c.y=lerp(c.x,c.ex,c.speed),lerp(c.y,c.ey,c.speed)
	if distance(c.x,c.y,c.ex,c.ey) <= 1 then
		del(card_effects,c)
	end
end

function draw_card_effect(c)
	rectfill(c.x,c.y,c.x+card_s_w,c.y+card_s_h,c.col)
	rect(c.x,c.y,c.x+card_s_w,c.y+card_s_h,c.hcol)
	spr(196,c.x+2,c.y+8)
end

-->8
-- all cards

--par: cost,name,type,effects
--type: 0 starter,1 purchased,2 monster
--effect: c coin,a attack,b block,d draw,k destroy
--        g gravedig,r remove mid,t discard,h heal,
--				o hurt player,m transform,e convert,i boost,
--				s slam,p unblock, j boom

all_cards=splitd("0,mediocre bard,0,c1;0,common guard,0,a1;2,shiny knight,0,a2;2,crafty chef,1,t1d2;1,apprentice distiller,1,k1;1,'giant' spider,2,c1;5,shifty barkeep,1,g1;1,young wizard,1,t1d1c1;4,legendary sword,1,k1a3;2,redheaded dragon,2,k1;2,light priest,1,c3;4,sacred tree,1,t1d3;4,bob the ghost,2,t1d2b1;3,fleshy planty,2,c3;4,rabbit warrior,1,a4c1;2,friendly goul,1,r1;3,confused cyclope,2,o1a2;7,old hero,1,a5d1;6,slimey friend,1,b2a2d1;5,flaming faun,2,d2b1;4,holiday spirit,1,c3b2;4,sneaky sage,2,t1d2c1;4,proud skeleton,1,a3b2;8,wise king,1,b4d1r1k1;5,sleepy witch,1,d1k2;4,senile enchantress,2,d2;3,defensive wanderer,1,b4;2,weird slimey,2,b1c2;3,business woman,1,a1d1c1;3,vacant paladin,1,a3;4,fabled monkey,2,a2b1;1,borug the orc,1,a2;3,magical fox,1,k1r1;3,great fishing rod,1,t1g1;2,♥living potion,1,h1a1;2,mean flower,2,c1h1;7,flaming body,2,h4d2;1,chill shield,1,b2s1;2,old hermit,1,o2d2;8,paragon,1,a8;8,STRAWBERRY g,2,d3a3;2,water blobs,2,c3;2,ethernal feral demon,2,d1;2,batty bat,1,t1h1b1;4,ninja splatty,2,g1;1,underground alchemist,1,m1;5,double agent witch,1,e1;5,death's wife,2,e1c1;3,persevering florist,1,c2k1;2,sad trumpet,2,i1;4,dj-bOnEy,1,i2;4,shiny godness,2,c1m1;3,blocky buddy,2,b1s1;8,the wall,2,b6d2;3,shy ninja,1,c2a2",";",",")


lane_i=0
lane_deck=splitd("4,4,5,5,6,6,6,7,7,8,8,9,9,10,10,11,11,11,12,13,13,14,14,15,15,16,16,17,17,18,18,19,20,20,21,21,22,22,23,23,24,25,25,26,26,27,27,28,28,28,29,29,30,30,30,31,31,32,32,32,33,33,34,34,35,35,36,36,37,38,39,39,40,41,42,42,43,43,44,44,45,46,46,47,47,48,49,49,49,50,50,51,51,52,53,54,55,55,55",",")


function parse_effects(effects_string)
	local nr_of_effects=#effects_string/2
	local all_effects={}
	for i=1, nr_of_effects do
		local c_effect_i=i-1+i
		local c_effect_char=sub(effects_string,c_effect_i,c_effect_i)
		local c_number_i=c_effect_i+1
		local c_number_char=sub(effects_string,c_number_i,c_number_i)

		add(all_effects,init_effect(c_effect_char,c_number_char))
	end
	return all_effects
end

function card_char_form(nr)
 return nr>1 and " cards" or " card"
end

function shovel_char_form(nr)
 return nr>1 and " shovels" or " shovel"
end

local desc_funcs = {card_char_form, shovel_char_form}

-- {{"c",1,"gain ",0," gold"},...}
-- effect id: "c", sprite: 1, description: "gain " .. num .. " gold"
-- 0 is num,1 is card_char_form(num),2 is shovel_char_form(num)
local effects_data = splitd("c,1,gain ,0, gold;a,2,gain ,0, attack;d,3,draw ,0,1;k,4,destroy ,0,1;g,5,gain ,0,2,\n to take ,0,1,\n from the graveyard;r,6,remove ,0,1, from lane;t,9,discard ,0,1;b,8,add ,0, armor;h,219,heal ,0, health;o,218,take ,0, health;m,220,transform all gold \ninto attack;e,221,convert an enemy \ninto an ally;i,222,boost all your current\nattack cards by ,0;s,223,transform all block \ninto attack;p,144;j,194",";",",")
for e in all(effects_data) do
 effects_data[e[1]]=e
end

function get_effects_desc_id(effects)
	local desc="-"
	for e in all(effects) do
		if (desc~="-") desc = desc .. "\n-"
  for i=3,#effects_data[e.id] do
   local part = effects_data[e.id][i]
   desc = desc .. (part==0 and e.num or (type(part) == "number" and desc_funcs[part](e.num) or part))
  end
 end
	return desc
end

function parse_type_col(t)
	if t == 0 then
		return 4,15,9
	elseif t == 1 then
		return 13,12,10
	elseif t == 2 then
		return 2,14,8
	end
end

function init_effect(id,nr_string)
	local c={
		id=id,
		num=tonum(nr_string)
	}
	local s_id=1
 	s_id=effects_data[id][2]
	c.s_id=s_id
	return c
end

level_delay=80
function update_xp()
	if level_delay > 0 then
		level_delay-=1
	else
		c_xp=lerp(c_xp,xp,0.075)
		if xp-c_xp < 1 then
			c_xp=xp
		end
		if c_xp >= xp_goal then
			level_up()
		end
	end
end

-- xp

c_xp,xp_x,xp_y,xp_w=0,12,56,104
function get_xp()
	xp+=abs(boss_health-boss_s_hp)
	if boss_health <= 0 then
		xp+=15
		xp+=(30-(30-r_health))
		if boss_unlock < 8 and boss_i == boss_unlock then
			boss_unlock+=1
			bo_unlock_s="boss"
			dset(3,boss_unlock)
		end
	end
	dset(0,xp)
end

function load_save()
 	cartdata("elastiskalinjen_xp")
	xp,xp_goal=dget(0),dget(1)
 	c_xp=xp
 	if (xp_goal == 0)xp_goal=50
	level=max(dget(2),1)
	boss_unlock,back_unlock=max(dget(3),1),max(dget(4),1)
	games_played,games_won=dget(5),dget(6)
	music_off,auto_next,auto_attack=num_to_bool(dget(7)),num_to_bool(dget(8)),num_to_bool(dget(9))
end

function level_up()
	xp,c_xp=xp-flr(c_xp),0
	level+=1
	xp_goal=50+level*20
	dset(0,xp)
	dset(1,xp_goal)
	dset(2,level)
	if back_unlock < 8 then
		ba_unlock_s="background"
		back_unlock+=1
		dset(4,back_unlock)
	end
end

xp_s=" xp"
function draw_xp()
	drawp(0b0011001111001100.1,rectfill,0,0,128,120,0)

	rectfill(xp_x-4,xp_y-20,xp_x+xp_w-2,xp_y+48,0)
	spr(147,xp_x+60,xp_y-18)
	print("level:" .. level,xp_x+69, xp_y-16,13)
	print("" .. flr(c_xp) .. "/" .. xp_goal .. xp_s,xp_x,xp_y-6,7)
	line(xp_x,xp_y,xp_w,xp_y,1)
	line(xp_x,xp_y,xp_x+(xp_w-xp_x)*(c_xp/xp_goal),xp_y,7)
	print("damage dealt: " .. boss_s_hp - boss_health .. xp_s,xp_x+2,xp_y+4,12)
	spr(149,xp_x+xp_w-11,xp_y)
	if boss_health <= 0 then
		print("you won!",xp_x+8,xp_y-16,7)
		if xp - c_xp <= 20 then
			print("boss killed: 15" .. xp_s,xp_x+2,xp_y+12,12)
		end
		if xp - c_xp < 3 then
			print("health left: " .. (30-(30-r_health)) .. xp_s,xp_x+2,xp_y+20,12)
		end
	end

	local won_s = boss_health <= 0 and "you won!" or "you lost!"
	print(won_s,xp_x+8,xp_y-16,7)
	local won_spr = boss_health <= 0 and 145 or 146
	spr(won_spr,xp_x-2,xp_y-18)

	line(xp_x,xp_y+28,xp_w,xp_y+28,1)

	if xp - c_xp < 2 then
		u_p(bo_unlock_s,9,32)
		if boss_unlock < 8 and bo_unlock_s == "" then
			spr(193,xp_x-2,xp_y+31)
			print("win next boss to unlock",xp_x+8,xp_y+32,7)
		end

		u_p(ba_unlock_s,9,42)
		if back_unlock < 8 and ba_unlock_s == "" then
			spr(192,xp_x-2,xp_y+40)
			print("level up to unlock",xp_x+8,xp_y+42,7)
		end
	end
end

function u_p(s,x,y)
	if s ~= "" then
		spr(148,xp_x-2,xp_y+y-3)
		print("new " .. s .. " unlocked",xp_x+x,xp_y+y,9)
	end
end
