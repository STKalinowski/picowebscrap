-- thunder bella the cloud chaser 
-- by evilpaper, music by gruber

-- todo
-- add a game over tune
-- add a game won tune
-- add "electric" lighting effect on thunderbolts

-- sfx
sfx_rain=0
sfx_start_game=1
sfx_game_over=9
sfx_p_stun=3
sfx_p_recover=4
sfx_p_knocked_down=5
sfx_thunder=6
sfx_bounce=7
sfx_fireworks=8
sfx_rocket=2
sfx_rocket_storm=25
sfx_create_powerup=10
sfx_pickup_powerup=11
sfx_extra_life=12
sfx_thunderstrike=13
sfx_bomb=19

-- initialize game ------------
function _init()
 t = 0
 shake = 0
 time_since_last_thunderbolt=0
 max_number_of_thunderbolts=2
 time_to_next_thunderbolt=120
 btn_counter=0
 boss = {
   x=51,
   y=7,
   t=0,
   lives=50,
   dx=0.4,
   ddx=0.05,
   left_eye_sprite=36,
   right_eye_sprite=36,
   destination=51,
   left_pupil_sprite=39,
   left_pupil_x=53,
   left_pupil_y=6,
   right_pupil_sprite=39,
   right_pupil_x=72,
   right_pupil_y=6,
   hitbox={x=0,y=5,w=32,h=8},
   state="idle",
   flashing_timer=0
  }
  cloud = {
   y=0,
   sprite=80
 }
 explosions = {}
 glows = {}
 fireworks = {}
 freeze_timer=0
 p = {
   x=56,
   y=112,
   t=0,
   lives=3,
   sprite=0,
   direction=0,
   state="idle",
   hitbox={x=2,y=5,w=12,h=10},
   flashing_timer=0,
   attack="regular",
   shoot_count=0,
   att_pow=1
  }
 popups = {}
 powerups = {}
 puffts = {}
 rain_fg = {}
 rain_bg = {}
 rockets = {}
 score = 0
 splashes = {}
 smoke={}
 start_time=0
 game_time=0
 thunder=0
 thunderbolts = {}
 thunderstrikes = {}
 time_between_ts = 240
 time_since_last_thunderbolt_was_created=0
 time_since_last_thunderbolt_was_deleted=0
 wind = {
   dx=rnd(1.5)-0.5
  }
 music(00)
 create_rain_in_background()
 create_rain_in_foreground()
end
-- end of initalization -------

-- scenes ---------------------
scene = {}
scene.active = 0
scene.update = {}
scene.draw = {}

scene.cycle = function(num)
  t=0
  scene.active = num
end

scene.reset = function()
 scene.active = 0
end

scene.updates = function()
 if scene.update[scene.active] != nil then
  scene.update[scene.active]()
 end
end

scene.drawing = function()
 if scene.draw[scene.active] != nil then
  scene.draw[scene.active]()
 end
end
-------------------------------

-- title scene specifics ------
scene.update[0] = function()
  if x_btn then
   sfx(sfx_start_game)
   start_time=time()
   scene.cycle(1)
  end
end

scene.draw[0] = function()
  print("left/right arrow to move",16,84,6)
  print("x button to shoot rockets",14,92,6)
  if (t%50<16) then
   spr(192,34,50,8,4)
  elseif (t%50<32) then
   spr(192,34,49,8,4)
  else
   spr(192,34,48,8,4)
  end
  if (abs(t % 30) <= 20) print("press x to start", 36,103,7)
end
-------------------------------

-- game on scene specifics ----
scene.update[1] = function()
 update_time()
 shoot_rocket()
 check_collision_rocket_vs_thunderbolt()
 check_collision_rocket_vs_boss()
 check_collision_thunderbolt_vs_player()
 check_collision_thunderstrike_vs_player()
end

scene.draw[1] = function()
  draw_score()
  draw_lives()
end
-------------------------------

-- game over scene specifics --
scene.update[2] = function()
  update_rockets()
  if t>60 and x_btn then
    _init()
    start_time=time()
    scene.cycle(1)
  end
end

scene.draw[2] = function()
  draw_backdrop()
  if (abs(t % 30) <= 20) print("ouch!",57,56,7)
  if (abs(t % 30) <= 20) print("game over",48,64,7)
  if t>60 then
    if (abs(t % 30) <= 20) print("press x to try again",25,99,7)
  end
  draw_score()
  draw_lives()
end
-------------------------------

-- game won scene specifics ---
scene.update[3] = function()
  if t>60 and x_btn then
    _init()
    scene.cycle(1)
  end
end

scene.draw[3] = function()
  draw_backdrop()
  if (abs(t % 30) <= 20) print("boss",57,56,7)
  if (abs(t % 30) <= 20) print("defeated",50,64,7)
  if (abs(t % 30) <= 20) print("press x for a new round",19,99,7)
  draw_score()
  draw_lives()
end

-------------------------------

--- create functions ----------

function create_firework(_x,_y)
 sfx(sfx_fireworks)
 for i=0,50 do
  create_firework_particles(_x,_y)
 end
end

function create_firework_particles(_x,_y)
 local angle = rnd()
 local speed = 0.5+rnd(1)
 local new = {
   x=_x,
   y=_y,
   dx=sin(angle)*speed,
   dy=cos(angle)*speed,
   age=flr(rnd(25))
 }
 add(fireworks,new)
end

function create_pufft(x,y,dx)
 local pufft = {
   x=x+rnd(7),
   y=y,
   dx=dx,
   dy=-rnd(0.4),
   r=3+rnd(1),
   age=0,
   maxage=25,
   col=7
 }
 add(puffts,pufft)
end

function create_explosion(x,y)
 for i=0,2 do
   local explosion = {
     x=x-4+rnd(8),
     y=y-4+rnd(8),
     r=10,
     age=0-i,
     maxage=12,
     col={7,7,7,0,0,7,9,9,9,0,4,4}
   }
   add(explosions,explosion)
 end
end

function create_glow(x,y)
 for i=1,10 do
  local glow = {
   x=x+(rnd(16)),
   y=y+(rnd(8)),
   dx=-0.2+rnd(0.4),
   dy=-0.3-rnd(0.7),
   r=1+rnd(1),
   age=0,
   maxage=70,
   col=7
  }
  add(glows,glow)
 end
end

function create_smoke(x,y,dx,dy,quantity)
 for i=1,quantity do
   local smoke_particle = {
     x=x+rnd(6),
     y=y+16+rnd(4),
     dx=dx,
     dy=dy,
     r=1+rnd(2),
     age=0,
     maxage=10,
     col=6
   }
   add(smoke, smoke_particle)
 end
end

function create_rain_in_background()
 for i=1,256 do
  add(rain_bg, {
   x=rnd(384)-128,
   y=rnd(128),
   dx=0,
   dy=rnd(2)+1
  })
 end
end

function create_rain_in_foreground()
 for j=1,256 do
  add(rain_fg, {
   x=rnd(384)-128,
   y=rnd(128),
   dx=0,
   dy=rnd(1.5)+1.5,
   color=12,
   sprite=55,
   state="falling"
   })
 end
end

function create_splash(x,y)
 for i=1, rnd(10)+2 do
  local splash = {
   x=x,
   y=y,
   dx=(rnd(3)-2),
   dy=-rnd(2)-1,
   r=(rnd(2)+1),
   colour=12
  }
  if splash.r <= 2 then splash.colour = 6 end
  add(splashes,splash)
 end
end

-------------------------------

--- reset functions ----------

function reset_raindrop(raindrop)
 raindrop.x=rnd(384)-128
 raindrop.y=rnd(128)-128
 raindrop.sprite=55
 raindrop.state="falling"
end

function game_won()
 freeze_timer=2
 boss.lives=0
 boss.state="laughing"
 reset_thunderbolts()
 reset_thunderstrikes()
 create_powerup(boss.x,boss.y,flr(rnd(4)+2))
 create_powerup(boss.x,boss.y,flr(rnd(4)+2))
 create_powerup(boss.x,boss.y,flr(rnd(4)+2))
 scene.cycle(3)
end

--- update functions  ---------

function update_input()
 left_btn=btn(0)
 right_btn=btn(1)
 x_btn=btn(5)
end

function update_clouds()
  if (t%50<16) then
   cloud.y=0
   cloud.sprite=80
   boss.y=11
   boss.left_pupil_y=boss.y
   boss.right_pupil_y=boss.y
  elseif (t%50<32) then
   cloud.y=-1
   cloud.sprite=82
   boss.y=9
   boss.left_pupil_y=boss.y
   boss.right_pupil_y=boss.y
  else
   cloud.y=-2
   cloud.sprite=84
   boss.y=7
   boss.left_pupil_y=boss.y
   boss.right_pupil_y=boss.y
  end
end

function update_fireworks()
 for p in all(fireworks) do
  if p.age > 40
   or p.y > 128
   or p.y < 0
   or p.x > 128
   or p.x < 0
   then
   del(fireworks,p)
  else
   p.x+=p.dx
   p.y+=p.dy
   p.age+=1
   p.dy+=0.075
  end
 end
end

function update_puffts()
 for p in all(puffts) do
  if p.age >= p.maxage
   or p.y > 128
   or p.y < 0
   or p.x > 128
   or p.x < 0
   then
   del(puffts,p)
  else
   if p.age>=0 then
    p.x+=p.dx
    p.y+=p.dy
    p.r-=0.1
   end
   p.age+=1
  end
 end
end

function update_glows()
 for g in all(glows) do
   if g.age >= g.maxage
    or g.y > 128
    or g.y < 0
    or g.x > 128
    or g.x < 0
    then
     del(glows,g)
   else
    if g.age>=0 then
     g.x+=g.dx
     g.y+=g.dy
     g.r-=0.02
    end
    g.age+=1
   end
  end
end

function update_explosions()
 for e in all(explosions) do
   if e.age >= e.maxage then
     del(explosions,e)
   else
     e.r-=0.5
     e.age+=1
   end
 end
end

function update_smoke()
 for s in all(smoke) do
  if s.age >= s.maxage
    or s.y > 128
    or s.y < -16
    or s.x > 128
    or s.x < 0
  then
     del(smoke,s)
  else
    if s.age>=0 then
      s.x+=s.dx + wind.dx
      s.y+=s.dy
      s.r-=0.05
    end
    s.age+=1
  end
 end
end

function update_splash()
 for splash in all(splashes) do
  splash.x+=splash.dx
  splash.y+=splash.dy
  splash.dy+=1
  if (splash.y>130) del (splashes,splash)
 end
end

function update_wind()
 if t%20==0 then
  wind.dx=wind.dx+rnd(1)-0.5
  if wind.dx > 1 then
   wind.dx = 1
  end
  if wind.dx < -1 then
   wind.dx = -1
  end
 end
end

function update_rain_fg()
 for raindrop_fg in all(rain_fg) do
  if raindrop_fg.state=="falling" then
   raindrop_fg.dx *= 0.45 -- add friction
   raindrop_fg.x += wind.dx
   raindrop_fg.y += raindrop_fg.dy
   if raindrop_fg.y > 128 then
    raindrop_fg.state="splashing"
   end
  end
  if raindrop_fg.state=="splashing" then
   raindrop_fg.y=120
   raindrop_fg.sprite+=0.5
   if raindrop_fg.sprite==59 then
    reset_raindrop(raindrop_fg)
   end
  end
 end
end

function update_rain_bg()
 for raindrop_bg in all(rain_bg) do
  raindrop_bg.x += wind.dx
  raindrop_bg.y += raindrop_bg.dy
  if raindrop_bg.y >= 128 then
   raindrop_bg.y = 0
   raindrop_bg.x=rnd(384)-128
  end
 end
end

function update_time()
 game_time=time()-start_time
end

function _update60()
 t=t+1
 if freeze_timer==2 then
  music(00)
 end
 if freeze_timer>0 then
  freeze_timer-=1
 end
 scene.updates()
 update_input()
 update_player()
 update_puffts()
 if freeze_timer==0 then
  update_wind()
  update_clouds()
  update_boss()
  update_rain_fg()
  update_rain_bg()
  update_thunderbolts()
  update_thunderstrikes()
 end
 update_explosions()
 update_glows()
 update_smoke()
 update_splash()
 update_rockets()
 update_fireworks()
 update_popups()
 update_powerups()
 check_collision_player_vs_powerup()
end

--- draw functions  -----------

function draw_backdrop()
  circfill(48,54+(flr(t/8)%2),8,1)
  circfill(68,60+(flr(t/8)%2),20,1)
  circfill(46,66+(flr(t/8)%2),10,1)  circfill(84,58+(flr(t/8)%2),10,1)
  circfill(80,70+(flr(t/8)%2),10,1)
  circfill(58,72+(flr(t/8)%2),12,1)
end

function draw_splash()
 for splash in all(splashes) do
  circfill(splash.x,splash.y,splash.r,splash.colour)
 end
end

function draw_puffts()
 for p in all(puffts) do
  if p.age>=0 then
   draw_pufft(p)
  end
 end
end

function draw_pufft(p)
 circfill(p.x,p.y,p.r,p.col)
end

function draw_glows()
 for g in all(glows) do
  if g.age>=0 then
   draw_glow(g)
  end
 end
end

function draw_glow(g)
 circfill(g.x,g.y,g.r,g.col)
end

function draw_explosions()
 for e in all(explosions) do
  if e.age>=0 then
   draw_explosion(e)
  end
 end
end

function draw_explosion(e)
 local color = e.col[e.age]
 circfill(e.x,e.y,e.r,color)
end

function draw_smoke()
 for s in all(smoke) do
  if s.age>=0 then
    draw_smoke_particle(s)
  end
 end
end

function draw_smoke_particle(s)
 circfill(s.x,s.y,s.r,s.col)
end

function draw_fireworks()
 local col
 for p in all(fireworks) do
  if p.age > 60 then col=8
  elseif p.age > 40 then col=9
  elseif p.age > 20 then col=10
  else col=7 end
  line(p.x,p.y,p.x+p.dx,p.y+p.dy,col)
 end
end

function change_colors_to_white()
  for i=1,15 do
    pal(i,7)
  end
end

function reset_color_to_normal()
  return pal()
end

function draw_background_rain()
  for raindrop_bg in all (rain_bg) do
   pset(raindrop_bg.x,raindrop_bg.y,1)
  end
end

function draw_foreground_rain()
  for raindrop_fg in all(rain_fg) do
    if raindrop_fg.state=="falling" then
      color(raindrop_fg.color)
      if wind.dx > 1 then
        line (raindrop_fg.x,raindrop_fg.y,raindrop_fg.x+0.3,raindrop_fg.y+1)
      elseif wind.dx < -1 then
        line (raindrop_fg.x,raindrop_fg.y,raindrop_fg.x-0.3,raindrop_fg.y+1)
      else
        line (raindrop_fg.x,raindrop_fg.y,raindrop_fg.x,raindrop_fg.y+1)
      end
    else
     spr(raindrop_fg.sprite,raindrop_fg.x,raindrop_fg.y)
    end
  end
end

function draw_cloud()
  map(0,0,0,cloud.y,16,16)
  spr(cloud.sprite,-6,20+cloud.y,2,1)
  spr(cloud.sprite,7,28+cloud.y,2,1)
  spr(cloud.sprite,10,18+cloud.y,2,1)
  spr(cloud.sprite,19,23+cloud.y,2,1)
  spr(cloud.sprite,36,23+cloud.y,2,1)
  spr(cloud.sprite,82,22+cloud.y,2,1)
  spr(cloud.sprite,47,29+cloud.y,2,1)
  spr(cloud.sprite,71,28+cloud.y,2,1)
  spr(cloud.sprite,96,28+cloud.y,2,1)
  spr(cloud.sprite,108,21+cloud.y,2,1)
  spr(cloud.sprite,118,18+cloud.y,2,1)
end

function draw_lives()
  for i=1,p.lives do
   spr(52,128-i*8,2)
  end
end

function shake_screen()
  local shakex=8-rnd(16)
  local shakey=8-rnd(16)

  shakex*=shake
  shakey*=shake

  camera(shakex,shakey)

  shake=shake*0.95
  if (shake<0.05) shake = 0
end

function draw_score()
 if boss.lives>=0 then
  print(boss.lives,1,1,13)
 -- print(start_time,64-16,18,13)
  print(timeformat(game_time),64-((#"timeformat(game_time)")/2)-1,1,13)
 end
end

function _draw()
 if (thunder>0) then
  rectfill(0,0,128,128,7)
 else
  rectfill(0,0,128,128,13)
 end
 draw_background_rain()
 draw_foreground_rain()
 draw_thunderstrikes()
 draw_cloud()
 draw_boss()
 draw_thunderbolts()
 draw_splash()
 draw_player()
 draw_glows()
 draw_explosions()
 draw_smoke()
 draw_rockets()
 draw_fireworks()
 shake_screen()
 draw_popups()
 draw_powerups()
 scene.drawing()
end
-->8
--player

function player_hit()
 sfx(sfx_p_stun)
 shake+=1
 p.lives-=1
 change_state(p,"electric")
 if p.lives == 0 then
   boss.state="laughing"
   scene.cycle(2)
 end
end

function update_player()
  if p.state=="idle" then
	 local start_frame=0
   local animation_speed=12
   p.sprite=start_frame+flr((t/animation_speed)%4)*2
   if (left_btn or right_btn) then
     change_state(p,"walking")
   end
   if (x_btn) change_state(p,"shooting")
  end

  if p.state=="walking" then
   if (left_btn) p.direction=-1
   if (right_btn) p.direction=1
   local start_frame=12
   local animation_speed=4
   if (x_btn) and p.sprite!=73 then
     p.sprite=73 else
     p.sprite=start_frame+flr((t/animation_speed)%2)*2
   end
   p.x+=p.direction*1.5
   if (not (left_btn or right_btn)) change_state(p,"idle")
   --if p.x>128 and p.direction==1 then p.x=-20 end
   --if p.x<-16 and p.direction==-1 then p.x=132 end
   if p.x<=0 then p.x=0 end
   if p.x>=112 then p.x=112 end
  end

  if p.state=="shooting" then
   p.sprite=73
   change_state(p,"idle")
  end

  if p.state=="electric" then
   local start_frame=8
   local animation_speed=12
   p.sprite=start_frame+flr((t/animation_speed)%2)*2
   p.y=112
   p.t+=1
   if p.t > 70 then
    if p.lives>0 then
     create_glow(p.x,p.y)
     change_state(p,"idle")
     p.flashing_timer=60
     boss.state="idle"
     sfx(sfx_p_recover)
    else
     sfx(sfx_p_knocked_down)
     change_state(p,"falling")
    end
    p.t=0
   end
  end

  if p.state=="falling" then
   local start_frame=96
   local animation_speed=26
   p.sprite=start_frame+flr((t/animation_speed)%6)*2
   if p.sprite==104 then
     change_state(p,"knocked_out")
   end
  end

  if p.state=="knocked_out" then
   reset_thunderbolts()
   game_over=true
	 local start_frame=106
   local animation_speed=8
   p.sprite=start_frame+flr((t/animation_speed)%3)*2
  end
end

function draw_player()
  if (isflashing(p)) then
    change_colors_to_white()
  end
  spr(p.sprite,p.x,p.y,2,2,p.direction==-1)
  reset_color_to_normal()
--  if (#glows>0) then

--  end
end
-->8
--enemy

function get_boss_sprite(state)
  if (t%50<16) then
    if state=="idle" or "moving" then return 36
    elseif state=="laughing" then return 36 end
  elseif (t%50<32) then
    if state=="idle" or "moving" then return 34
    elseif state=="laughing" then return 36 end
  else
    if state=="idle" or "moving" then return 32
    elseif state=="laughing" then return 36 end
  end
end

function get_boss_destination()
 if p.x<=60 then return p.x+16+rnd((128-(p.x+16+32))) end
 if p.x>60 then return rnd((p.x-42)) end
end

function get_moving(boss)
 boss.destination=get_boss_destination()
 boss.t=0
 boss.dx=0.4
 boss.ddx=0.07
 if boss.x > boss.destination then
  boss.dx=-boss.dx
  boss.ddx=-boss.ddx
 end
 boss.state="moving"
end

function decrease_boss_lives(damage)
 boss.lives-=damage
 if boss.lives<=0 then
  game_won()
 end
 if boss.lives<20 then
  time_between_ts=120
 elseif boss.lives<30 then
  time_between_ts=180
 end
end

function update_boss()
 boss.t+=1
 boss.x+=boss.dx
 boss.dx+=boss.ddx
 if boss.x <=0 then 
  boss.x=1 
  boss.state="idle"
 end
 if boss.x >=96 then 
  boss.x=95 
  boss.state="idle"
 end
 if boss.state=="idle" then
    boss.left_pupil_sprite=39
    boss.right_pupil_sprite=39
    boss.dx=0
    boss.ddx=0
    boss.left_eye_sprite=get_boss_sprite("idle")
    boss.right_eye_sprite=get_boss_sprite("idle")
    if scene.active==1 and boss.t>45 then
     get_moving(boss)
    end
 end
 if boss.state=="moving" then
    boss.left_pupil_sprite=39
    boss.right_pupil_sprite=39
    boss.dx=boss.dx+boss.ddx
    boss.left_eye_sprite=get_boss_sprite("moving")
    boss.right_eye_sprite=get_boss_sprite("moving")
    if boss.dx > 0 and boss.t>2 and boss.t<8 then
      create_pufft(boss.x-8,boss.y,-0.3)
    elseif boss.dx < 0 and boss.t>2 and boss.t<8 then
      create_pufft(boss.x+34,boss.y,0.3)
    end
    if boss.dx < 0 and boss.x <= boss.destination then
     boss.t=0
     boss.state="idle"
    elseif boss.dx > 0 and boss.x >= boss.destination then
     boss.t=0
     boss.state="idle"
    end
 end
 if boss.state=="laughing" then
    boss.dx=0
    boss.ddx=0
    boss.left_pupil_sprite=38
    boss.right_pupil_sprite=38
    boss.left_eye_sprite=get_boss_sprite("laughing")
    boss.right_eye_sprite=get_boss_sprite("laughing")
 end

 update_boss_pupils()
end

function update_boss_pupils()
  if p.x < boss.x-10 then
   boss.left_pupil_x=boss.x+1
   boss.right_pupil_x=boss.x+20
  elseif p.x >= boss.x-10 and p.x <= boss.x+30 then
   boss.left_pupil_x=boss.x+2
   boss.right_pupil_x=boss.x+21
  else
   boss.left_pupil_x=boss.x+3
   boss.right_pupil_x=boss.x+22
  end
end

function draw_boss_eyes()
  spr(boss.left_eye_sprite,boss.x,boss.y,2,1)
  spr(boss.right_eye_sprite,boss.x+16,boss.y,2,1,true)
  spr(boss.left_pupil_sprite,boss.left_pupil_x,boss.left_pupil_y)
  spr(boss.right_pupil_sprite,boss.right_pupil_x,boss.right_pupil_y)
end

function draw_boss()
  if (isflashing(boss)) then
    for i=1,15 do
      pal(i,7)
    end
  end
  draw_boss_eyes()
  pal()
  draw_puffts()
end

function draw_boss_laugh()
  if boss.state=="laughing" then
    if (t%50<16) then
      spr(44,boss.x+8,boss.y+8,1,1)
      spr(44,boss.x+16,boss.y+8,1,1,true)
    elseif (t%50<32) then
      spr(45,boss.x+8,boss.y+8,1,1)
      spr(45,boss.x+16,boss.y+8,1,1,true)
    else
      spr(46,boss.x+8,boss.y+8,1,1)
      spr(46,boss.x+16,boss.y+8,1,1,true)
    end
  end
end


-->8
--helpers (collision etc.)

function animate(thing)
  thing.t=(thing.t+1)%thing.step
  if (thing.t==0) thing.frame=thing.frame%#thing.sprite+1
end

function change_state(thing,new_state)
 thing.state=new_state
end

function collide(a,b)
 if a.x+a.hitbox.x+a.hitbox.w < b.x+b.hitbox.x then return false end
 if a.y+a.hitbox.y+a.hitbox.h < b.y+b.hitbox.y then return false end
 if a.x+a.hitbox.x > b.x+b.hitbox.x+b.hitbox.w then return false end
 if a.y+a.hitbox.y > b.y+b.hitbox.y+b.hitbox.h then return false end
 return true
end

function check_collision_rocket_vs_thunderbolt()
 if count(rockets) > 0 then
  for thunderbolt in all(thunderbolts) do
   for rocket in all(rockets) do
    if collide(thunderbolt,rocket) then
     create_firework(rocket.x,rocket.y)
     create_smoke(thunderbolt.x,thunderbolt.y-16,0.1,-0.3,100)
     shake+=0.1
     thunderbolt.age=thunderbolt.age-p.att_pow
     if (thunderbolt.age<=0) then
      if (thunderbolt.radius==8) then
        create_thunderbolt(thunderbolt.x,thunderbolt.y, thunderbolt.dx, -1, 1, 4)
        create_thunderbolt(thunderbolt.x,thunderbolt.y, -thunderbolt.dx, -1, 1, 4)
      end
      del(thunderbolts,thunderbolt)
      time_since_last_thunderbolt_was_deleted=0
     end   
     thunderbolt.dy=-2
     create_explosion(thunderbolt.x,thunderbolt.y)
     del(rockets,rocket)
     time_since_last_thunderbolt=0
     if (rnd(10)<=8) then create_powerup(thunderbolt.x,thunderbolt.y,1) end
    end
   end
  end
 end
end

function check_collision_rocket_vs_boss()
 if count(rockets) > 0 then
   for rocket in all(rockets) do
    if collide(rocket,boss) then
     create_firework(rocket.x,rocket.y)
     del(rockets,rocket)
     sfx(17)
     get_moving(boss)
     boss.flashing_timer=30
     shake+=0.1
     decrease_boss_lives(p.att_pow)
    end
   end
 end
end

function check_collision_thunderbolt_vs_player()
 for thunderbolt in all(thunderbolts) do
  if collide(thunderbolt,p) and p.state!=("electric") and p.flashing_timer==0 then
     -- del(thunderbolts,thunderbolt)
     player_hit()
  end
 end
end

function check_collision_thunderstrike_vs_player()
 for ts in all(thunderstrikes) do
  if collide(ts,p) and ts.t>60 and p.state!=("electric") and p.flashing_timer==0 then
    player_hit()
  end
 end
end

function check_collision_player_vs_powerup()
 for powerup in all(powerups) do
  if collide(powerup,p) then
     create_popup(p.x,p.y,powerup.type)
     if (powerup.type=="extra life") then
       p.lives=p.lives+1
       sfx(sfx_extra_life)
     elseif (powerup.type=="freeze" and scene.active==1) then
      freeze_timer=60
      music(-1, 200)
      sfx(-1, 1)
      sfx(-1, 2)
      sfx(-1, 3)
      sfx(-1, 4)
      sfx(16)
     elseif (powerup.type=="double freeze" and scene.active==1) then
      freeze_timer=120
      music(-1, 200)
      sfx(-1, 1)
      sfx(-1, 2)
      sfx(-1, 3)
      sfx(-1, 4)
      sfx(16)  
     elseif (powerup.type=="bomb blast") then
      create_explosion(boss.x,boss.y)
      boss.flashing_timer=30
      sfx(sfx_bomb)
      for thunderbolt in all(thunderbolts) do
       create_explosion(thunderbolt.x,thunderbolt.y)
       create_explosion(thunderbolt.x-rnd(2),thunderbolt.y+rnd(2))
       create_explosion(thunderbolt.x+rnd(3),thunderbolt.y-rnd(3))
       del(thunderbolts,thunderbolt)
      end
      shake+=2
      decrease_boss_lives(4)
     elseif (powerup.type=="rocket storm") then
      sfx(sfx_pickup_powerup)
      p.shoot_count=0
      p.attack=powerup.type
     elseif (powerup.type=="double damage") then
      sfx(sfx_pickup_powerup)
      p.shoot_count=0
      p.attack=powerup.type
      p.att_pow=2
     else
       sfx(sfx_pickup_powerup)
       score=score+powerup.score
     end
     del(powerups,powerup)
  end
 end
end

function isflashing(thing)
  if (thing.flashing_timer>0) and (abs(t % 12) < 6) then
    thing.flashing_timer=thing.flashing_timer-1
    return true
  else
    return false
  end
end

function timeformat(secs)
 if (secs < 1) then
  return "00:00:00"
 end
 local mins = "00"
 local msec = "00"
 
 mins = flr(secs / 60)
 if (mins < 10) then
  mins = "0"..mins
 end
 
 msec=flr((secs-flr(secs))*100)
 
 secs=flr(secs-mins*60)
 if (secs < 10) then
  secs = "0"..secs
 end

 return mins..":"..secs..":"..msec
end
-->8
--rockets and power-ups

function create_rocket()
 local rocket_sprite=53
 if p.attack=="double damage" then
  rocket_sprite=54
 end 
 local rocket={
  sp=rocket_sprite,
  x=p.x+2,
  y=p.y,
  dx=0,
  dy=-3.8,
  ddy=0.06,
  hitbox={x=2,y=0,w=4,h=8},
  fire={}
 }
 add(rockets,rocket)
 sfx(sfx_rocket)
end

function create_rocket_storm()
 for i=1, 3 do
  local rocket={
   sp=48,
   x=p.x+2+rnd(16)-8,
   y=p.y-8+rnd(16)-8,
   dx=(rnd(2)-1)/3,
   dy=-2.3,
   ddy=0.0,
   hitbox={x=2,y=0,w=4,h=8},
   fire={},
  }
  add(rockets,rocket)
 end
 sfx(sfx_rocket_storm)
end

function max_number_of_rockets()
 if p.attack=="rocket storm" then
  return 2
 else
  return 1
 end
end

function shoot_rocket()
  if btnp(5) and p.state!="electric" and #rockets<=max_number_of_rockets() then
   p.shoot_count+=1
   if p.attack=="rocket storm" and p.shoot_count>5 then
    p.attack="regular"
    p.shoot_count=0
   end
   if p.attack=="double damage" and p.shoot_count>10 then
    p.attack="regular"
    p.att_pow=1
    p.shoot_count=0
   end
   
   if p.attack=="rocket storm" then
    create_rocket_storm()
   else
    create_rocket()
   end
  end
  -- if (btn(5)) btn_counter+=1
  -- if (not btn(5)) btn_counter=0
  -- if (btn_counter>60) then p.flashing_timer=60 end
end

function reset_thunderbolts()
 for l in all(thunderbolts) do
   del(thunderbolts,l)
 end
end

function update_rockets()
 for r in all(rockets) do
  if (r.sp==48) and (t%20==0) then
   r.sp=49
  elseif (r.sp==49) and (t%20==0) then
   r.sp=48
  end
  r.dy+=r.ddy
  r.x+=r.dx+wind.dx*0.4
  r.y+=r.dy
  create_smoke(r.x,r.y,0.2,0.3+rnd(1),1)
  add(r.fire,{x=r.x+3,y=r.y+9})
  srand(p.f)
  for i=1,count(r.fire) do
    local fire=r.fire[i]
    fire.x+=(rnd(2)-1)
    fire.y+=(rnd(2)-1)
  end
  if count(r.fire)>10 then
    del(r.fire[1])
  end
  if r.y < -32 then
   del(rockets,r)
  end
  if r.dy > 0 then
   create_firework(r.x,r.y)
   del(rockets,r)
  end
 end
end

function draw_rockets()
  for r in all(rockets) do
   spr(r.sp,r.x,r.y)
   --  this part just draw the hitboxm used to test
   --  rect(r.x+r.hitbox.x,r.y+r.hitbox.y,r.x+r.hitbox.x+r.hitbox.w,r.y+r.hitbox.y+r.hitbox.h,2)
   --  rectfill(r.box.x1,r.box.y1,r.box.x2,r.box.y2,4)
   local colors={10,9,8,2}
   local c=count(r.fire)
   for i=1,c do
     local fire=r.fire[i]
     local col=colors[flr(4*(1-i/c))+1]
     pset(fire.x,fire.y,col)
   end
  end
end

function get_powerup_type()
  -- srand(t)
  local random=flr(rnd(7))
  if random==0 or boss.lives==0 then
   return "yummy"
  elseif random==1 then
   return "double freeze"
  elseif random==2 then
   return "bomb blast"
  elseif random==3 then
   return "rocket storm"
  elseif random==4 then
   return "freeze"
  elseif random==5 then
   return "double damage"
  elseif random==6 then
   if p.lives>2 then
    return "yummy"
   else
    return "extra life"
   end
  end
end

function get_powerup_sprite(type)
 if type=="extra life" then
  return 51
 elseif type=="double freeze" then
  return 43
 elseif type=="bomb blast" then
  return 44
 elseif type=="rocket storm" then
  return 42
 elseif type=="freeze" then
  return 40
 elseif type=="double damage" then
  return 45
 elseif type=="yummy" then
  if boss.lives==0 then
   return 60+flr(rnd(3))
  else
   return 41
  end
 end
end

function create_powerup(x,y,quantity)
  local type = get_powerup_type()
  local sprite = get_powerup_sprite(type)
  for i=1, quantity do
    local powerup = {
      x=quantity>1 and 8+rnd(120) or x,
      y=quantity>1 and 8+rnd(16) or y,
      dy=-1.6,
      ddy=0.1,
      age=0,
      lifespan=120,
      type=type,
      score=20,
      sprite=sprite,
      flashing_timer=0,
      hitbox={x=0,y=0,w=8,h=8},
    }
    add(powerups, powerup)
  end
  sfx(sfx_create_powerup)
end

function update_powerups()
 for powerup in all(powerups) do
   powerup.age+=1
   powerup.dy += powerup.ddy
   powerup.y += powerup.dy
   if powerup.y > 120 then
     powerup.dy=0
     powerup.y=120
   end
   if powerup.age==180 then
     powerup.flashing_timer=60
   end
   if powerup.age>=240 then
     del(powerups,powerup)
   end
 end
end

function draw_powerups()
  for powerup in all(powerups) do
    if (isflashing(powerup)) then
    else
      spr(powerup.sprite,powerup.x,powerup.y)
    end
  end
  pal()
end

function get_length_in_px(string)
 return (#string)*4
end

function create_popup(x,y,type)
 local popup = {
   x=x,
   y=y,
   dy=-0.30,
   t=0,
   life=70,
   copy=type,
   length=get_length_in_px(type)
 }
 add(popups, popup)
end

function update_popups()
  for popup in all(popups) do
    popup.y += popup.dy
    popup.t += 1
    if popup.t == popup.life then
      del(popups,popup)
    end
  end
end

function draw_popups()
 for popup in all(popups) do
  local c = 2
  for i=0,1 do
    if i==1 then
     c=t%4<2 and 10 or 14
    end
   print(popup.copy,popup.x+8-(popup.length/2)+i,popup.y+i,c)
  end
 end
end
-->8
-- thunderbolts

function create_thunderbolt(x,y,dx,dy,age,radius)
 local thunderbolt={
  t=0,
  x=x,
  y=y,
  dx=dx,
  dy=dy,
  age=age,
  radius=radius,
  state="falling",
  hitbox={x=0-radius,y=0-radius,w=radius*2,h=radius*2}
 }
 if t%2 == 0 then thunderbolt.dx=-thunderbolt.dx end
 add(thunderbolts,thunderbolt)
end

function shoot_thunderbolt()
 for i=1, 1 do
    local x = 16+rnd(96)
    local y = 0
    local dx = 0
    local dy = 2
    local age = 2
    local radius = 8
    create_thunderbolt(x,y,dx,dy,age,radius)
    sfx(sfx_thunder)
 end
 thunder=8
 time_since_last_thunderbolt_was_created=0
end

function reset_thunderbolts()
 for l in all(thunderbolts) do
   del(thunderbolts,l)
 end
end

function update_thunderbolts()
 local delay=rnd(240)+240
 time_since_last_thunderbolt_was_created+=1
 time_since_last_thunderbolt_was_deleted+=1

 thunder=thunder-1
 if (thunder<0) then thunder=0 end

 for tb in all(thunderbolts) do
  tb.t+=1
  if tb.t >= 20 then
   tb.x+=tb.dx
   tb.y+=tb.dy
   tb.dy+=0.1
  end

  -- bouning off left and right screen border
  if tb.x<=0+tb.radius then
   tb.dx=-tb.dx
  elseif tb.x>=128-tb.radius then
   tb.dx=-tb.dx
  end

  -- bouning off bottom screen border
  if tb.y > 128-tb.radius then
   if (tb.state=="falling") then
    tb.state="bouncing"
    if tb.radius == 8 then
     tb.dx=(t%2==0 and 1 or -1)
    else
     tb.dx=tb.dx
    end
   end
   if tb.radius == 4 then
    tb.dy=-2.9
   else
    tb.dy=-3.6
   end
   create_splash(tb.x,tb.y)
   sfx(sfx_bounce)
  end
 end

 if scene.active==1 and t>60 then
  if boss.lives<15 then
   if #thunderbolts<2
    and time_since_last_thunderbolt_was_deleted>delay 
    and time_since_last_thunderbolt_was_created>60 then
    shoot_thunderbolt()
   end
  else
   if #thunderbolts<1
    and time_since_last_thunderbolt_was_deleted>delay 
    and time_since_last_thunderbolt_was_created>60 then
    shoot_thunderbolt()
   end
  end
 end

end

function draw_thunderbolts()
  for tb in all(thunderbolts) do
   if (tb.t < 20 and tb.radius == 8) then
    if tb.t%4==0 then
     circfill(tb.x,tb.y,20,7)
    end
   else
    if (tb.t%6==0) or (tb.t%6==1) then
      circ(tb.x,tb.y,tb.radius,12)
      circfill(tb.x,tb.y,tb.radius-1,7)
    elseif (tb.t%6==2) or (tb.t%6==3) then
      circfill(tb.x,tb.y,tb.radius-1,7)
    else
      circ(tb.x,tb.y,tb.radius,12)
    end
   end
  end
end

-->8
-- thunderstrike

function create_thunderstrike(x,y,age)
 local thunderstrike={
  t=0,
  x=x,
  y=y,
  age=120,
  hitbox={x=-3,y=0,w=4,h=127}
 }
 add(thunderstrikes,thunderstrike)
end

function reset_thunderstrikes()
 for ts in all(thunderstrikes) do
   del(thunderstrikes,ts)
 end
end


function update_thunderstrikes()
 if scene.active==1 and t>90 then 
  if t%time_between_ts==0 then
   create_thunderstrike(rnd(100)+10,0,120)
   sfx(sfx_thunderstrike)
  end
 end

 for ts in all(thunderstrikes) do
  ts.t+=1
  if ts.t==40 then
   shake+=0.1
   create_splash(ts.x,ts.y+128)
  end
  if ts.t==ts.age then
   del(thunderstrikes, ts)
  end
 end
end

function draw_thunderstrikes()
 for ts in all(thunderstrikes) do

 -- rect(ts.x+ts.hitbox.x,ts.y,ts.x+ts.hitbox.w,ts.y+ts.hitbox.h,8)

  if ts.t >= 0 and ts.t < 5 then
   line(ts.x+4,ts.y+40,ts.x+4,ts.y+40,7)
   line(ts.x-1,ts.y+46,ts.x-1,ts.y+46,7)
   line(ts.x-3,ts.y+50,ts.x-3,ts.y+50,15)
   line(ts.x,ts.y+58,ts.x,ts.y+58,7)
 		line(ts.x,ts.y+90,ts.x,ts.y+90,7)
   line(ts.x+5,ts.y+96,ts.x+5,ts.y+90,7)
   line(ts.x,ts.y+102,ts.x,ts.y+102,15)
   line(ts.x+2,ts.y+106,ts.x+2,ts.y+106,7)
  end

  if ts.t >= 10 and ts.t < 15 then
   line(ts.x+2,ts.y+40,ts.x+2,ts.y+40,7)
   line(ts.x,ts.y+48,ts.x,ts.y+48,7)
   line(ts.x-2,ts.y+52,ts.x-2,ts.y+52,15)
   line(ts.x,ts.y+62,ts.x,ts.y+62,7)
 		line(ts.x+1,ts.y+91,ts.x+1,ts.y+91,7)
   line(ts.x+2,ts.y+96,ts.x+2,ts.y+96,7)
   line(ts.x,ts.y+100,ts.x,ts.y+100,15)
   line(ts.x+2,ts.y+104,ts.x+2,ts.y+104,7)
  end

  if ts.t >= 20 and ts.t < 25 then
   line(ts.x,ts.y+40,ts.x,ts.y+41,7)
   line(ts.x,ts.y+50,ts.x,ts.y+50,7)
   line(ts.x,ts.y+60,ts.x,ts.y+61,7)
   line(ts.x,ts.y+70,ts.x,ts.y+70,7)
   line(ts.x,ts.y+77,ts.x,ts.y+77,7)
   line(ts.x,ts.y+89,ts.x,ts.y+89,7)
   line(ts.x,ts.y+96,ts.x,ts.y+96,7)
   line(ts.x,ts.y+116,ts.x,ts.y+116,7)
  end
  if ts.t >= 25 and ts.t < 30 then
   line(ts.x,ts.y+39,ts.x,ts.y+40,7)
   line(ts.x,ts.y+50,ts.x,ts.y+52,7)
   line(ts.x,ts.y+60,ts.x,ts.y+62,7)
   line(ts.x,ts.y+69,ts.x,ts.y+70,7)
   line(ts.x,ts.y+77,ts.x,ts.y+78,7)
   line(ts.x,ts.y+89,ts.x,ts.y+91,7)
   line(ts.x,ts.y+96,ts.x,ts.y+97,7)
   line(ts.x,ts.y+116,ts.x,ts.y+117,7)
  end
  if ts.t >= 30 and ts.t < 35 then
   line(ts.x,ts.y,ts.x,ts.y+128,7)
  end
  if ts.t >= 35 and ts.t < 40 then
   line(ts.x-2,ts.y,ts.x-2,ts.y+128,12)
   line(ts.x-1,ts.y,ts.x-1,ts.y+128,7)
   line(ts.x,ts.y,ts.x,ts.y+128,7)
   line(ts.x+1,ts.y,ts.x+1,ts.y+128,7)
   line(ts.x+2,ts.y,ts.x+2,ts.y+128,12)
  end
  if ts.t >= 40 and ts.t < 45 then
   line(ts.x,ts.y,ts.x,ts.y+128,7)
  end
  if ts.t >= 45 and ts.t < 50 then
   line(ts.x-2,ts.y,ts.x-2,ts.y+128,12)
   line(ts.x-1,ts.y,ts.x-1,ts.y+128,7)
   line(ts.x,ts.y,ts.x,ts.y+128,7)
   line(ts.x+1,ts.y,ts.x+1,ts.y+128,7)
   line(ts.x+2,ts.y,ts.x+2,ts.y+128,12)
  end
  if ts.t >= 50 and ts.t < 55 then
   line(ts.x,ts.y,ts.x,ts.y+128,7)
  end
  if ts.t >= 55 and ts.t < 60 then
   line(ts.x-2,ts.y,ts.x-2,ts.y+128,12)
   line(ts.x-1,ts.y,ts.x-1,ts.y+128,7)
   line(ts.x,ts.y,ts.x,ts.y+128,7)
   line(ts.x+1,ts.y,ts.x+1,ts.y+128,7)
   line(ts.x+2,ts.y,ts.x+2,ts.y+128,12)
  end
  if ts.t >= 60 and ts.t < 65 then
   rectfill(ts.x-6,ts.y,ts.x+6,ts.y+128,0)
  end
  if ts.t >= 65 and ts.t < 70 then
   rectfill(ts.x-6,ts.y,ts.x+6,ts.y+128,12)
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,7)
  end
  if ts.t >= 70 and ts.t < 75 then
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,12)
   rectfill(ts.x-4,ts.y,ts.x+4,ts.y+128,7)
  end
    if ts.t >= 75 and ts.t < 80 then
   rectfill(ts.x-6,ts.y,ts.x+6,ts.y+128,12)
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,7)
  end
  if ts.t >= 80 and ts.t < 85 then
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,12)
   rectfill(ts.x-4,ts.y,ts.x+4,ts.y+128,7)
  end
  if ts.t >= 85 and ts.t < 90 then
   rectfill(ts.x-6,ts.y,ts.x+6,ts.y+128,12)
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,7)
  end
  if ts.t >= 90 and ts.t < 95 then
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,12)
   rectfill(ts.x-4,ts.y,ts.x+4,ts.y+128,7)
  end
  if ts.t >= 95 and ts.t < 100 then
   rectfill(ts.x-6,ts.y,ts.x+6,ts.y+128,12)
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,7)
  end
  if ts.t >= 100 and ts.t < 105 then
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,12)
   rectfill(ts.x-4,ts.y,ts.x+4,ts.y+128,7)
  end
    if ts.t >= 105 and ts.t < 110 then
   rectfill(ts.x-6,ts.y,ts.x+6,ts.y+128,12)
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,7)
  end
  if ts.t >= 110 and ts.t < 115 then
   rectfill(ts.x-5,ts.y,ts.x+5,ts.y+128,12)
   rectfill(ts.x-4,ts.y,ts.x+4,ts.y+128,7)
  end
  if ts.t >= 115 and ts.t < 120 then
   line(ts.x+2,ts.y+40,ts.x+2,ts.y+40,7)
   line(ts.x,ts.y+48,ts.x,ts.y+48,7)
   line(ts.x-2,ts.y+52,ts.x-2,ts.y+52,15)
   line(ts.x,ts.y+62,ts.x,ts.y+62,7)
 		line(ts.x+1,ts.y+91,ts.x+1,ts.y+91,7)
   line(ts.x+2,ts.y+96,ts.x+2,ts.y+96,7)
   line(ts.x,ts.y+100,ts.x,ts.y+100,15)
   line(ts.x+2,ts.y+104,ts.x+2,ts.y+104,7)
  end
  
 -- if ts.t >= 115 and ts.t < 120 then
 --  line(ts.x,ts.y,ts.x,ts.y+128,7)
 -- end
  

 end
end