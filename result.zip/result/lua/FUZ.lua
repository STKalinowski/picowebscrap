--fuz
--a fez demake by jusiv

--[[
!!!disclaimer!!!
this is a fan project based on
fez, a game released in 2012
by polytron corporation. it was
not made in collaboration with
or endorsed by them.

although i made all assets used
in this cart, they are based
heavily on those from the
original game.

i do not claim ownership of
the original game or its
assets in any way.

- j. henry "jusiv" stadolnik
]]

n1 = -1

function split(str,num)
--splits string into list
--num is bool
local ll,c1 = {},1
for i=1,#str do
 local last = i==#str
 if last or sub(str,i,i) == "," then
  --include current char if at end
  if last then i+=1 end
  --negate
  local neg = false
  if sub(str,c1,c1) == "-" then
   neg = true
   c1 += 1
  end
  --add list item
  local new = sub(str,c1,i-1)
  if num then
   new = tonum(new)
   if neg then
    new *= n1
   end
  end
  add(ll,new)
  c1 = i+1
 end
end
return ll
end

function ssplit(str)
return split(str,false)
end

function nsplit(str)
return split(str,true)
end

title,title_y,title_idle,side,area,aplus,active,intro,ending,pwait,happy = true,0,0,0,0,1,{},-30,0,0,0
function supdate()
sfront,sleft,sback,sright = side==0,side==1,side==2,side==3
end
--area
atrans,atmax,achange,anext,transcolor = 0,12,false,nsplit("0,0,0,0,0"),nsplit("6,6,5,4,5,3,2,2")
-- anext: {area id,side,px,py,pz}
a_sky,skycolor,cldcolor,cloud_y = {},nsplit("12,12,1,14,5,3,2,1"),nsplit("7,6,5,2,1,5,1,15"),nsplit("28,45,3,97,76,100,106,12")
--idle+input
idle,maxidle,keys,lastkey,lkeywait = 0,180,{false,false,false,false,false,false},6,0
function reset_input()
input = {}
for i=1,6 do
 add(input,6) -- 6=none
end
end
--items n stuff
bitget,bits,cubes,rel1,rel2,rel3,item,itname,r_wait,r_dir,r_factor,atiles,tiles = {},0,0,false,false,false,0,"anti-cube",10,1,0,{},{}
for i=1,14 do
add(bitget,false)
add(active,false)
add(atiles,{})
end
--player vars
p_xreal,p_yreal,p_zreal,cur_x,cur_y,cur_z,cur_sx,cur_sy = 48,32,73,0,0,0,0,0
function savelast()
p_slast,p_xlast,p_ylast,p_zlast,p_olast = side,p_xreal,p_yreal,p_zreal,p_open
end
function pgetpos()
p_x,p_y,p_z = from_real(p_xreal),from_real(p_yreal),from_real(p_zreal)
end
p_dpos,p_dz,p_jump,p_maxfall,p_coyotemax,p_coyote,p_floor,p_open,p_reswait = 0,0,13,-9,5,5,false,true,0
p_otrans,p_otransmax,p_otcolors = 0,4,nsplit("13,5,1,0")
p_landed,p_lwait,p_dropwait,p_dwaitmax,p_canuse,p_usewait,p_useidle,p_mir,p_frame,p_still = true,0,0,8,false,0,0,false,0,165
--dot
dot,dotsort,d_rx,d_ry = {},{},-4,-4
d_x,d_y,d_show,d_fmax,d_f,d_shrink,d_idle,d_imax,d_amax,d_da,d_axy = d_rx,d_ry,false,10,0,false,0,300,240,1,0
dvx,dvy,dvz,dvw,dv1,dv2,dv3,dv4,dcolor = nsplit("0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0"),nsplit("1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0"),nsplit("0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1"),nsplit("0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1"),nsplit("2,1,2,1,1,2,3,4,1,2,3,4,5,6,7,8"),nsplit("4,3,4,3,6,5,6,5,10,9,10,9,9,10,11,12"),nsplit("5,6,7,8,8,7,8,7,12,11,12,11,14,13,14,13"),nsplit("9,10,11,12,13,14,15,16,13,14,15,16,16,15,16,15"),{nsplit("11,7,11,6"),nsplit("11,7,11,15"),nsplit("7,12,12,6"),nsplit("7,12,12,15"),nsplit("11,11,7,6"),nsplit("11,11,7,15"),nsplit("12,7,12,6"),nsplit("12,7,12,15"),nsplit("6,10,10,9"),nsplit("15,10,10,9"),nsplit("6,10,10,9"),nsplit("15,10,10,9"),nsplit("6,9,14,14"),nsplit("15,9,14,14"),nsplit("6,9,14,14"),nsplit("15,9,14,14")}
--text
chars,chars2,rrr,talklines,talkline,talkchar,talk = {a=0,b=1,c=2,d=3,e=4,f=5,g=6,h=7,i=8,j=9,k=10,l=11,m=12,n=13,o=14,p=15,q=16,r=17,s=18,t=19,u=20,v=21,w=22,x=23,y=24,z=25},"abcdefghijklmnopqrstuvwxyz /",0,{},0,1,{ssplit("gomez...,something went wrong.,the warp gate broke!,we're stranded here!,maybe you can find,some way to fix it?,(use ⬅️ and ➡️ to move)  ,(⬆️ to jump) ,(z and x to rotate),(and ⬇️ to drop or interact!) "),ssplit("looks like we'll need a cube,to get through here.,you can make one,if you find 8 cube bits.,now get going,it's gomez time!"),ssplit("you assembled a cube!,that should open,a door somewhere."),ssplit("excellent find!,that should fix,the warp gate!,now let's go home!"),ssplit("this door needs 4 cubes.,...are there even that many,around here?"),ssplit("woah nice!,you found an anti-cube!,i had no idea,any were out here!"),ssplit("um... congrats?,i don't know what,the point of that is,...but...,you sure did find it!"),ssplit("what even...,that is not supposed to,be here at all.")}
-->8
--actors
function tadd(t)
add(tiles,t)
end

function tcurrent(t)
return cur_sx == t.sx and cur_sy == t.sy
end

--basic actor
function tmake(inp)
local ii = nsplit(inp)
local t = {
--level coords
sx = ii[1],
sy = ii[2],
--world coords
rx = ii[3],
ry = ii[4],
rz = ii[5],
scx = 0,
--sprite
ix = ii[6],
iy = ii[7],
f = 0, --frame
w = ii[8],
h = ii[9],
m = false, --does it mirror
sm = false, --mirrored
upd = function(t) end,
draw = function(t)
 if tcurrent(t) then
  draw_tile(t)
 end
end,
--front layer draw
fdraw = function(t) end,
}
if ii[10] != 0 then t.m = true end
return t
end

function checkhid(h,x,y)
if sget(x,y)%15 == 0 then
 return h
else
 return true
end
end 

function add_tile(t)
tadd(tmake(t))
end

function is_hidden(t)
local hid,sx,sy = false,t.sx,t.sy
if sfront then
 for i=sy,8*flr(sy/8+1) do
  hid = checkhid(hid,sx,i)
 end
elseif sleft then
 for i=12*ceil(sx/12-1),sx do
  hid = checkhid(hid,i,sy)
 end
elseif sback then
 for i=sy,8*ceil(sy/8-1) do
  hid = checkhid(hid,sx,i)
 end
elseif sright then
 for i=sx,12*flr(sx/12+1) do
  hid = checkhid(hid,i,sy)
 end
end
return hid
end

function add_bfly(tt)
local t = tmake(tt)
t.fp = t.rx
t.upd = function(t)
 local fp = t.fp
 local ps = 3.5*cos(fp/80)
 t.fp,t.rx,t.ry,t.rz,t.sm = incmod(fp,80),-ps,ps,sin(fp/20)-4,fp>=40
 if flr(fp/4)%2 == 0 then
  t.ix = 104
 else
  t.ix = 108
 end
end
tadd(t)
end

function add_door(tt,swl,an)
local t = tmake(tt)
local vars = nsplit(swl)
t.s,t.wd,t.lk,t.lw,t.an = vars[1],vars[2],vars[3],20,nsplit(an)
t.upd = function(t)
 local tx,ty,tz = t.sx%12,7-t.sy%8,flr(t.sy/8)-4
 --unlock
 if not istalk() and happy <= 0 and t.lk > 0 and cubes+flr(bits/8) >= t.lk and side == t.s then
  t.lw -= 1
  sfx(23)
  if t.lw <= 0 then
   t.lk = 0
  end
 end
 --player at door
 if side == t.s and p_z+1 == tz then
  if ptouch(t) then
   p_canuse = true
   if t.lk <= 0 then
    d_show = false
    if use() then
     anext,achange = t.an,true
     sfx(24)
    end
   else
    d_show = true
    if talkline <= 0 and use() then
     if t.lk == 4 then
      starttalk(5)
     else
      starttalk(2)
     end
    end
   end
  end
 end
end
t.draw = function(t)
 if tcurrent(t) then
  draw_tile(t)
  if t.lk > 0 then
   local x1,y1,dl,cb = t.scx+4,122-8*(flr(t.sy/8)-4),{},cubes
   local y2 = y1+14-min(14,t.lw)
   if bits >= 8 then
    add(dl,10)
   end
   while cb > 0 do
    cb -= 1
    add(dl,12)
   end
   while #dl < 4 do
    add(dl,5)
   end
   raid()
   rectfill(x1,y2,x1+7,y2+14,13)
   if t.lk == 1 then
    square(x1,y2,dl[1])
   else
    for i=1,4 do
     square(x1+2*cos(i/4),y2+2*sin(i/4),dl[i])
    end
   end
   hornet()
  end
 end
end
tadd(t)
end

function frcomp(n1,ff,n2)
return from_real(n1-ff) == n2 or from_real(n1+ff) == n2
end

function ptouch(t)
local tz = flr(t.sy/8)-4
if ismid(tz,p_z,p_z+1) and p_open then
 if ((sfront or sback) and frcomp((t.sx%12)*8+t.rx,t.rx,p_x)) or ((sleft or sright) and frcomp((7-t.sy%8)*8+t.ry,t.ry,7-p_y)) then
  return not istalk()
 end
end
return false
end

function remove(t,c)
 sset(t.sx,t.sy,c)
 del(tiles,t)
end

function add_bit(tt,id)
local t = tmake(tt..",0,0,0,0,0")
t.id = id
t.upd = function(t)
 if bitget[t.id] then
  remove(t,0)
 elseif not is_hidden(t) then
  --collect
  if ptouch(t) then
   bitget[t.id],happy,item = true,30,0
   bits += 1
   if bits == 8 then
    starttalk(3)
   end
   sfx(24+bits)
  end
 end
end
t.draw = function(t)
 if tcurrent(t) then
  get_scx(t)
  local zz,x1,c1,c2 = 117-8*cur_z,t.scx+1,10,10
  local x2 = x1+5
  local x3 = x2
  if idle < 10 then
   local ww = max(n1,1.5*sin(idle/20))
   x1 += ww
   x3 -= ww
   x2 -= idle/2
   if idle > 5 then c2 = 9 else c1 = 9 end
  end
  raid()
  rectfill(x2,zz,x3,zz+5,c1)
  rectfill(x1,zz,x2,zz+5,c2)
  hornet()
 end
end
t.fdraw = function(t)
 if idle < 30 then
  --pulse
  local x2,z2 = t.scx+4,get_scz(t)
  local x1,z1,x3,z3 = x2-idle,z2-idle,x2+idle,z2+idle
  line(x1,z2,x2,z1,10)
  line(x2,z1,x3,z2)
  line(x1,z2,x2,z3)
  line(x2,z3,x3,z2)
 end
end
tadd(t)
end

function flickerdraw(t)
if tcurrent(t) then
 local iii = t.id==11
 if iii then
  pal(12,8)
  pal(13,4)
 end
 if t.fi > 18 or flr(t.fi/3)%2 == 1 then
  blackpal()
 end
 draw_tile(t)
 if iii then
  sspr(3,41,5,5,t.scx+3,get_scz(t))
 end
 pal()
 hornet()
end
end

function add_item(tt,id)
--item (9=r1,10=r2,11+=acube)
local t = tmake(tt)
sset(t.sx,t.sy,15)
t.id,t.fi,t.zo = id,0,t.rz --fade-in
if id >= 11 then t.fi = 24 end
t.upd = function(t)
 if t.fi > 0 then t.fi -= 1 end
 if bitget[t.id] then
  remove(t,0)
 else
  t.rz = t.zo+1.5*sin(idle/90)
  if is_hidden(t) or t.fi > 2 then
   return
  end
  --collect
  if ptouch(t) then
   local iid = t.id-8
   item,happy = iid,30
   if iid == 1 then
    rel1,rrr,active[1] = true,420,true
    music(n1)
    starttalk(4)
   elseif iid == 2 then
    rel2 = true
    starttalk(7)
   elseif iid == 3 then
    rel3 = true
    starttalk(8)
   else
    cubes += 1
    if cubes == 1 then
     starttalk(6)
    end
   end
   bitget[t.id] = true
   sfx(13,0)
  end
 end
end
t.draw = function(t)
 flickerdraw(t)
end
tadd(t)
end

function add_fadeblock(tt)
local t = tmake(tt)
sset(t.sx,t.sy,15)
t.fi = 24
t.upd = function(t)
 t.fi -= 1
 if t.fi < 3 then
  remove(t,4)
 end
end
t.draw = function(t)
 flickerdraw(t)
end
tadd(t)
end

function add_obelisk(tt,p)
local t = tmake(tt)
t.p = nsplit(p) --pattern
t.upd = function(t)
 if listcomp(t.p,input) then
  activate()
 end
end
t.draw = function(t)
 if tcurrent(t) then
  local zz = 120-8*cur_z
  get_scx(t)
  --draw obelisk
  spr(204,t.scx,zz,1,2)
  spr(220,t.scx,zz+16)
  --pattern
  zz += 3
  local pp = t.p
  for i=1,#pp do
   local sym,chh = pp[i],3
   if ismid(sym,2,3) then
    chh = 2
   end
   sspr(109,40+4*sym,3,chh,t.scx+2,zz)
   zz += chh
  end
 end
end
tadd(t)
end

function add_fork(t,p)
t.p,t.pi,t.pw,t.px = nsplit(p),0,0,0 --pattern
t.upd = function(t)
 if not active[aplus] then
  t.pw += 1
  if t.pw > 20 then
   t.pi = incmod(t.pi,12)
   t.pw = 0
   if t.pi > 5 then
    local pp = t.p
    if pp[t.pi-5] == 4 then
     t.px = 0
     sfx(20)
    else
     t.px = 7
     sfx(21)
    end
   else
    t.px = 4
   end
  end
  if listcomp(t.p,input) then
   activate()
  end
 end
end
t.fdraw = function(t)
 if not active[aplus] and 
  t.px != 4 and t.pw < 10 then
  --pulse
  local zz = 112-8*(flr(t.sy/8)-4)
  circ(t.scx+t.px,zz,t.pw/2,7)
 end
end
tadd(t)
end

function add_nuish(txy,s,n)
local t = tmake(txy..",0,0,0,0,0,0,0,0")
t.s,t.n = nsplit(s),n
t.draw = function(t)
 local sl = t.s
 if tcurrent(t) and
  sl[1+side] == 1 then
  local zz = 128-8*cur_z
  get_scx(t)
  draw_nuish(t.n,t.scx,zz+1)
 end
end
tadd(t)
end

function get_scx(t)
--screen x
if sfront then
 t.scx = 16+t.rx+8*cur_x+r_factor*(cur_y-4)
elseif sleft then
 t.scx = 32-t.ry+8*cur_y+r_factor*(cur_x-6)
elseif sback then
 t.scx = 16-t.rx+8*cur_x+r_factor*(cur_y-4)
elseif sright then
 t.scx = 32+t.ry+8*cur_y+r_factor*(cur_x-6)
end
end

function get_scz(t)
 return 120-8*(flr(t.sy/8)-4)+t.rz
end

function draw_tile(t)
local mm,zz = t.sm,120+t.rz-8*cur_z
get_scx(t)
if side >= 2 then
 if t.m then mm = not mm end
end
--center sprite
t.scx -= flr((t.w-8)/2)
--draw
sspr(t.ix+t.f*t.w,t.iy,t.w,t.h,t.scx,zz,t.w,t.h,mm,false)
end

function add_cloud()
local a={
x = rnd(512)-256,
w = 16+rnd(24),
h = 4+rnd(7),
upd = function(a)
 a.x -= 1/8
 if a.x < -256 then
  a.x += 512
 end
end,
draw = function(a)
 local xx = flr(a.x)
 local yy = cloud_y[aplus]+1
 rectfill(xx,yy,xx+a.w,yy+a.h,cldcolor[aplus])
 rect(xx+1,yy+a.h+1,xx+a.w-1,yy+a.h+1)
 rect(xx-1,yy,xx+a.w+1,yy)
end
}
add(a_sky,a)
end

function sky_shift(a)
--move cloud while rotating
local dx = r_dir*128/10
a.x -= dx
if a.x < -256 then
 a.x += 512
elseif a.x >= 256 then
 a.x -= 512
end
end

function dotsort_clear()
--reset depth sorting
dotsort = {}
for i=1,32 do
 add(dotsort,{})
end
end

function add_dv(i)
--dot vertice
local a={
id = i,
ox = 2*dvx[i]-1,
oy = 2*dvy[i]-1,
oz = 2*dvz[i]-1, --depth
ow = 2*dvw[i]-1, --scale
x = 0,
y = 0,
z = 0,
w = 0,
c = dcolor[i] --edge colors
}
add(dot,a)
end

function calc_dv(v)
--calculate vertice position
local nx,ny,nz,nw = v.ox,v.oy,v.oz,v.ow
--1. yz rotate
local axyz = d_axy/d_amax
local acos,asin,ty,tz = cos(axyz),sin(axyz),ny,nz
ny,nz = ty*acos+tz*asin,-ty*asin+tz*acos
--2. xy rotate
local tx = nx
ty = ny
nx,ny = tx*acos+ty*asin,-tx*asin+ty*acos
--3. yw rotate
local ayw,tw = -axyz,nw--d_ayw/d_amax
acos,asin,ty = ny,cos(ayw),sin(ayw)
ny,nw = ty*acos+tw*asin,-ty*asin+tw*acos
--4. apply
v.x,v.y,v.z,v.w = nx,ny,nz,nw
end

function sort_dv(v)
local depth = flr(v.y*4+v.w)+16
add(dotsort[depth],v)
end

function dot_line(v1,v2,c)
line(d_x+(d_f+v1.w)*(v1.x/(3+v1.y)),d_y+(d_f+v1.w)*(v1.z/(3+v1.y)),d_x+(d_f+v2.w)*(v2.x/(3+v2.y)),d_y+(d_f+v2.w)*(v2.z/(3+v2.y)),c)
end

function draw_dv(v)
local id,cc = v.id,v.c
dot_line(v,dot[dv1[id]],cc[1])
dot_line(v,dot[dv2[id]],cc[2])
dot_line(v,dot[dv3[id]],cc[3])
dot_line(v,dot[dv4[id]],cc[4])
end

function draw_dot()
--every line drawn twice
if happy <= 0 and d_f > 0 then
 --1. reset sorting
 dotsort_clear()
 --2. depth sort
 foreach(dot,sort_dv)
 --3. iterate though depths
 if skycolor[aplus] == 12 then
  pal(12,11)
 end
 for i=#dotsort,1,n1 do
  --4. iterate through vertices
  local sortbin = dotsort[i]
  foreach(sortbin,draw_dv)
 end
 pal()
end
end
-->8
--main
function from_real(n)
return flr(n/8)
end

function incmod(n,m)
return (n+1)%m
end

function use()
if btn(3) and intro >= 85 and p_usewait <= 0 then
 p_usewait = 5
 return true
else
 return false
end
end

function listcomp(l1,l2)
local same = true
for i=1,#l1 do
 if l1[i] != l2[i] then
  same = false
 end
end
return same
end

function sc(str)
local str2 = ""
for i=1,#str do
 local ch = sub(str,i,i)
 local cc = 26
 if ch == "/" then
  cc += 1
 elseif ch != " " then
  cc = chars[ch]
 end
 cc = 1+(cc+co)%(2*co)
 str2 = str2..sub(chars2,cc,cc)
end
return str2
end

function load_map(a)
mstore(aplus)
area,aplus,a_sky = a,a+1,{}
tiles = atiles[aplus]
for i=1,16 do
 add_cloud()
end
reset_input()
if area == 5 then
 menuitem(1,itname,activate)
else
 menuitem(1)
end
supdate()
pgetpos()
end

function rotate()
r_wait += 1
if r_wait == 5 then
 side = (side+4+r_dir)%4
 supdate()
 if not title then
  p_open = false
  p_floor = find_floor(p_z)
 end
end
foreach(a_sky,sky_shift)
end

function pzmove()
pgetpos()
--vertical movement
p_floor = find_floor(p_z)
-- if in the air
if not p_floor or p_dz > 0 then
 p_landed = false
end
-- if falling
if p_dz <= 0 then
 -- if floor approaching
 if p_floor then
  local znext = from_real(p_zreal+flr(p_dz/3))
  if znext < p_z then
   --land
   p_zreal = p_z*8
   if p_zreal%8 == 0 and not p_landed then
    p_landed,p_lwait,p_dz,p_coyote = true,3,0,p_coyotemax
    sfx(23)
   end
  end
 end
end
--jump/drop if landed
if intro >= 85 and talkline == 0 and (p_landed or p_coyote > 0) then
 if p_lwait <= 0 then
  --drop down
  if btn(3) and p_usewait <= 0 then
   p_dropwait += 1
  else
   p_dropwait = 0
  end
  --execute jump/drop
  if btn(2) or p_dropwait >= p_dwaitmax then
   if p_dropwait >= 5 then
    p_dz = -2
   else
    p_dz = p_jump
    sfx(8)
   end
   p_dropwait,p_floor,p_landed,p_coyote = 0,false,false,0
  else p_dz = 0
  end
 end
end
--gravity/coyote time
if not p_landed and p_dz > p_maxfall then
 if p_coyote > 0 then
  p_coyote -= 1
 else
  p_dz -= 1
 end
end
--save last safe position
if p_coyote >= p_coyotemax then
 savelast()
end
--update position
p_zreal += flr(p_dz/3)
--respawn
if p_zreal < 0 then
 if p_reswait <= 0 then
    sfx(9)
    p_reswait = 30
 else
    p_reswait -= 1
    if p_reswait <= 0 then
       p_xreal,p_yreal,p_zreal,side,p_open,p_landed,p_dz,p_coyote = p_xlast,p_ylast,p_zlast,p_slast,p_olast,true,0,p_coyotemax
    end
 end
end
end

function move_player()
--actions
if p_lwait > 0 then p_lwait -= 1 end
if intro >= 85 then
 --rotate right
 if btn(5) and p_landed then
  r_dir,r_wait = n1,0
  sfx(11)
 --rotate left
 elseif btn(4) and p_landed then
  r_dir,r_wait = 1,0
  sfx(10)
 else
  --move
  local dp = 0
  if btn(0) then dp -= 1 end
  if btn(1) then dp += 1 end
  if dp < 0 then p_mir = true
  elseif dp > 0 then p_mir = false end
  p_dpos = dp
  if sfront then
   p_xreal += p_dpos
  elseif sleft then
   p_yreal += p_dpos
  elseif sback then
   p_xreal -= p_dpos
  elseif sright then
   p_yreal -= p_dpos
  end
 end
end
--animate
if p_dpos == 0 then
 if p_still == 0 then
  p_frame = 0
 elseif p_still > 200 then
  p_frame += 1
  if p_frame > 5 then
   p_still,p_frame = 0,0
  end
 end
 p_still += 1
else
 if p_still > 0 then
  p_still,p_frame = 0,0
 end
 p_frame = incmod(p_frame,24)
end
pzmove()
end

function find_floor(layer)
local tile,minpos,maxpos,floors,walls = 0,1,8,{},{}
--min/maxpos are min/max player coord
--if outside map, don't collide
if not ismid(layer,1,12) then
 --if falling in front, move to front
 if (sfront and p_y >= 8) or (sleft and p_x <= 1) or (sback and p_y <= 1) or (sright and p_y >= 12) then
  p_open = true
 end
 return false
--front view
elseif sfront then
 if ismid(p_x,0,11) then
  local ppos,xlr = 8-p_y,p_x+12*area
  --1. grab spritesheet columns
  for i=0,7 do
   local ylr = 8*layer-i
   add(floors,sget(xlr,ylr+31))
   add(walls,sget(xlr,ylr+39))
  end
  --2. locate front wall
  -- (skip if at front)
  if not p_open and ppos > 1 then
   for i=ppos-1,1,n1 do
    tile = walls[i]
    if tile > 0 then
     minpos = i+1
     p_open = false
     break
    end
   end
   --if no walls hit
   if minpos <= 1 then
    p_open = true
   end
  else
  --already at front
   p_open = true
  end
  --3. find back wall
  if p_open then
   for i=1,8 do
    tile = walls[i]
    if tile > 0 then
     maxpos = i
     break
    end
   end
  end
  --4. find nearest floor to camera
  for i=minpos,maxpos do
   tile = floors[i]
   if ismid(tile,1,9) then
    p_yreal = (8-i)*8+4
    return true
   end
  end
  --5. if no floor, jump to front
  p_yreal = (8-minpos)*8+4
  --(then go to eof)
 else
  --if off side of map, exposed
  p_open = true
 end
--left view
elseif sleft then
 if ismid(p_y,0,7) then
  maxpos = 12
  local ppos,ylr = p_x+1,p_y+8*layer
  --1. grab spritesheet rows
  for i=0,11 do
   local xlr = i+12*area
   add(floors,sget(xlr,ylr+24))
   add(walls,sget(xlr,ylr+32))
  end
  --2. locate front wall
  -- (skip if at front)
  if not p_open and ppos > 1 then
   for i=ppos-1,1,n1 do
    tile = walls[i]
    if tile > 0 then
     minpos = i+1
     p_open = false
    break
    end
   end
   --if no walls hit
   if minpos <= 1 then
    p_open = true
   end
  else
  --already at front
   p_open = true
  end
  --3. find back wall
  if p_open then
   for i=1,12 do
    tile = walls[i]
    if tile > 0 then
     maxpos = i
     break
    end
   end
  end
  --4. find nearest floor
  for i=minpos,maxpos do
   tile = floors[i]
   if tile > 0 and tile <= 9 then
    p_xreal = i*8-4
    return true
   end
  end
  --5. if no floor, jump to front
  p_xreal = minpos*8-4
  --(then go to eof)
 else
  --if off side of map, exposed
  p_open = true
 end
--back view
elseif sback then
 if ismid(p_x,0,11) then
  local ppos,xlr = p_y+1,p_x+12*area
  --1. grab spritesheet columns
  for i=0,7 do
   local ylr = i+8*layer
   add(floors,sget(xlr,ylr+24))
   add(walls,sget(xlr,ylr+32))
  end
  --2. locate front wall
  -- (skip if at front)
  if not p_open and ppos > 1 then
   for i=ppos-1,1,n1 do
    tile = walls[i]
    if tile > 0 then
     minpos = i+1
     p_open = false
     break
    end
   end
   --if no walls hit
   if minpos <= 1 then
    p_open = true
   end
  else
   --already at front
   p_open = true   
  end
  --3. find back wall
  if p_open then
   for i=1,8 do
    tile = walls[i]
    if tile > 0 then
     maxpos = i
     break
    end
   end
  end
  --4. find nearest floor to camera
  for i=minpos,maxpos do
   tile = floors[i]
   if ismid(tile,1,9) then
    p_yreal = i*8-4
    return true
   end
  end
  --5. if no floor, jump to front
  p_yreal = minpos*8-4
  --(then go to eof)
 else
  --if off side of map, exposed
  p_open = true
 end
 --right view
 elseif sright then
  if ismid(p_y,0,7) then 
   maxpos = 12
   local ppos,ylr = 12-p_x,p_y+8*layer
   --1. grab spritesheet rows
   for i=0,11 do
    local xlr = 12*area+11-i
    add(floors,sget(xlr,ylr+24))
    add(walls,sget(xlr,ylr+32))
   end
   --2. locate front wall
   -- (skip if at front)
   if not p_open and ppos > 1 then
    for i=ppos-1,1,n1 do
     tile = walls[i]
     if tile > 0 then
      minpos = i+1
      p_open = false
      break
     end
    end
    --if no walls hit
    if minpos <= 1 then
     p_open = true
    end
   else
   --already at front
    p_open = true
   end
   --3. find back wall
   if p_open then
    for i=1,12 do
     tile = walls[i]
     if tile > 0 then
      maxpos = i
      break
     end
    end
   end
  --4. find nearest floor to camera
  for i=minpos,maxpos do
   tile = floors[i]
   if ismid(tile,1,9) then
    p_xreal = (12-i)*8+4
    return true
   end
  end
  --5. if no floor, jump to front
  p_xreal = (12-minpos)*8+4
  --(then go to eof)
 else
 --if off side of map, exposed
  p_open = true
 end
end
return false
end

function mstore(a)
atiles[a] = tiles
tiles = {}
end

function _init()
supdate()
nsh,co = ssplit("iodbnuofs,pgffsdtzwse, aa/mhwsi,s/fsdnfvsnbogesn s/g,fvsneywsenapesdhsngemfaa,fvsmqvo psdmatmfvs,tslmiszqa semkagmm,fvjmtadmbzokw/u, orsmpkmxgewhmm,s/r"),14
for i=1,16 do
 add_dv(i)
end
foreach(dot,calc_dv)
for i=1,#nsh do
 local s = sc(nsh[i])
 nsh[i] = s
end
add_door("22,69,-4,4,0,96,80,16,16,0","3,4,0","0,0,48,60,16")
add_door("18,68,4,-4,0,96,80,16,16,0","1,4,1","6,0,48,60,8")
add_door("20,70,0,0,0,96,112,8,16,0","0,0,0","2,0,44,52,8")
add_nuish("13,57","1,1,1,1",2)
add_obelisk("17,110,0,0,0,96,96,8,16,0","4,2,4,1,3,5")
add_bit("20,59,0,0,0",2)
add_bfly("14,64,50,0,0,104,11,3,5,1")
add_bfly("12,80,20,0,0,104,11,3,5,1")
add_bfly("12,90,40,0,0,104,11,3,5,1")
add_tile("20,83,1,-1,0,1,8,8,8,1")
add_tile("21,84,-1,1,0,7,8,8,8,1")
mstore(2)
add_door("29,53,0,0,0,96,112,8,16,0","0,0,0","1,0,68,52,24")
add_door("29,50,0,0,0,96,112,8,16,0","2,0,0","3,0,76,36,8")
add_door("33,103,0,0,0,96,112,8,16,0","0,0,0","4,1,28,32,16")
add_door("25,97,0,0,0,96,112,8,16,0","0,0,0","5,0,52,44,8")
add_obelisk("0,0,0,0,0,96,96,8,16,0","1,2,3,0,3,2")
add_bit("34,119,4,-4,0",3)
add_bit("24,124,-4,4,0",4)
add_nuish("26,113","1,1,1,1",3)
add_nuish("32,118","1,1,1,1",3)
mstore(3)
add_door("45,51,0,0,0,96,112,8,16,0","0,0,0","2,2,44,12,8")
add_obelisk("44,115,0,0,0,96,96,8,16,0","5,5,2,0,1,4")
add_bit("46,113,4,-4,0",5)
add_bit("39,127,0,0,0",6)
add_nuish("47,35","0,0,0,1",5)
add_tile("46,81,1,-1,-8,112,88,10,16,1")
add_tile("47,82,-1,1,-8,118,88,10,16,1")
mstore(4)
add_door("52,59,4,-4,0,96,80,16,16,0","1,4,0","2,0,76,60,56")
add_fork(tmake("53,124,4,4,-8,104,96,8,16,0"),"4,4,5,4,5,5")
add_bit("49,127,4,-4,0",7)
add_tile("48,46,1,-1,0,1,8,8,8,1")
add_tile("49,47,-1,1,0,7,8,8,8,1")
add_tile("58,40,1,-1,0,1,8,8,8,1")
add_tile("59,41,-1,1,0,7,8,8,8,1")
mstore(5)
add_door("66,52,0,0,0,96,112,8,16,0","0,0,0","2,0,12,12,56")
add_bit("71,112,4,0,0",8)
add_nuish("65,100","1,0,0,0",4)
add_nuish("67,98","0,0,1,0",4)
mstore(6)
add_door("77,54,4,4,0,96,80,16,16,0","0,4,0","1,1,44,40,24")
add_door("78,49,-4,-4,0,96,80,16,16,0","2,4,4","7,2,48,12,48")
add_item("77,123,4,-4,-4,88,8,8,8,0",9)
mstore(7)
add_door("90,90,-4,-4,0,96,80,16,16,0","2,4,0","6,2,48,4,8")
add_item("88,124,4,5,-1,96,8,8,8,1",10)
add_nuish("84,32","1,1,1,1",6)
add_nuish("95,39","1,1,1,1",7)
mstore(8)
add_door("5,61,4,4,0,96,80,16,16,0","0,4,0","1,3,92,40,24")
add_nuish("6,50","0,0,1,0",1)
add_bit("9,56,0,0,0",1)
load_map(0)
poke(0x5f41,0b1000)
music(4)
end

function activate()
if not active[aplus] then
 active[aplus] = true
 if area == 1 then
  add_item("20,123,4,-4,-4,99,64,11,16,0",12)
 elseif area == 2 then
  add_item("29,75,0,-4,-4,99,64,11,16,0",11)
 elseif area == 3 then
  add_fadeblock("39,111,0,0,0,32,0,8,8,0")
  add_fadeblock("41,101,0,0,0,32,0,8,8,0")
 elseif area == 4 then
  add_item("53,83,4,-4,-4,99,64,11,16,0",13)
 elseif area == 5 then
  add_item("66,83,0,0,0,99,64,11,16,0",14)
 end
 sfx(14)
end
end

function starttalk(n)
if not istalk() then
 talklines,talkline,talkchar,d_show = talk[n],1,1,true
end
end

function istalk()
return talkline > 0
end

function ismid(v,mn,mx)
return mid(v,mn,mx) == v
end

function _update()
if rrr > 0 then
 rrr -= 1
 if rrr == 295 then
  sfx(15) --thx jwinslow23
 elseif rrr == 300 then
  sfx(n1,0)
 elseif rrr == 0 or rrr > 300 then
  sfx(13,0)
 end
 return
end
idle = incmod(idle,maxidle)
if ending > 0 then
 if ending == 1 then
  p_xreal,p_yreal = 48,32
  p_zreal += sgn(69-p_zreal)/4
  if p_zreal >= 69 then
   ending = 2
  end
 elseif ending == 2 then
  title_idle += 1
  if title_idle > 100 then
   ending = 3
  end
 elseif ending == 3 then
  if atrans < 40 then
   atrans += 1
  elseif rel2 then
   ending = 4
  end
 elseif atrans > 0 then
  atrans -= 1
  if atrans == 5 then
     sfx(13)
  end
 end
 return
end
--record input
if lkeywait > 0 then
 lkeywait -= 1
 if lkeywait <= 0 then
  lastkey = 6
 end
end
local istart = 0
if area == 4 then
 istart = 4
end
for i=istart,5 do
 local hit = keys[i]
 if btn(i) then
  if not hit then
   keys[i],lastkey,lkeywait = true,i,35
   add(input,i)
   del(input,input[1])
  end
 elseif hit then
  keys[i] = false
 end
end
--update player interaction
p_canuse = false
if p_usewait > 0 and atrans <= 0 then
 p_usewait -= 1
end
--player transition effect
if p_open then
 if p_otrans > 0 then p_otrans -= 1 end
elseif p_otrans < p_otransmax then
 p_otrans += 1
end
--title
if title then
 if title_y > 0 then
  title_y += 6
  if side > 0 and r_wait >= 10 then r_wait = 0 end
  if title_y >= 150 then
   title = false
  end
 else
  title_idle += 1
  if title_idle >= 100 then
   r_wait,title_idle = 0,0
  end
  if btn() != 0x0000 then
   title_y = 6
   music(n1,1000)
   sfx(22)
  end
 end
 if r_wait < 10 then rotate() end
--gameplay
else
 if r_wait < 10 then rotate()
 elseif achange or atrans > 0 then
  --area change
  if achange then
   atrans += 1
   if atrans >= atmax then
    side,p_xreal,p_yreal,p_zreal,achange = anext[2],anext[3],anext[4],anext[5],false
    savelast()
    local an = anext[1]
    if an >= 4 then
     if an == 6 then
      music(4,1000)
     elseif an == 4 then
      music(n1,1000)
     else
      music(0,1000)
     end
    elseif area >= 4 then
     music(13,1000)
    end
    load_map(an)
   end
  else
   atrans -= 1
  end
 elseif happy > 0 then
  happy -= 1
 elseif istalk() then
  if p_landed then
   --dialogue
   local tl = talklines[talkline]
   if talkchar < #tl then
    if talkchar%3 == 0 then
     sfx(17+flr(rnd(3)))
    end
    talkchar += 1
    if talkchar >= #tl then
     p_useidle = 0
    end
   else
    p_useidle = incmod(p_useidle,120)
    if use() then
     talkchar = 1
     talkline += 1
     if talkline > #talklines then
      talkline,p_usewait = 0,20
      if intro < 86 then
       music(13)
       intro = 86
      end
     end
    end
   end
  else
   pzmove()
  end
 else
  if area == 0 and active[1] and pwait < 15 then
   pwait += 1
  end
  --gameplay
  if intro < 85 then
   intro += 1
   if intro == 15 then
    p_otrans = p_otransmax
    sfx(16)
   elseif intro == 85 then
    starttalk(1)
   end
  end
  if intro >= 15 then
   move_player()
  end
  -- dot
  pgetpos()
  if area == 0 then
   if p_z == 7 and (ismid(p_x,5,6) or ismid(p_y,3,4))then
    if intro >= 85 then
     p_canuse = true
    end
    if active[1] then
     if use() then
      ending,title_idle = 1,0
      music(n1,250)
      sfx(12)
     end
    else
     if intro >= 85 then
      d_show = true
      if use() then
       starttalk(1)
      end
     end
    end
   else
    d_show = false
   end
  end
 end
end
--tiles/actors
if r_wait >= 10 then
 foreach(tiles,function(a) a:upd() end)
end
foreach(a_sky,function(a) a:upd() end)
--use prompt
if istalk() then
 p_dropwait = 0
else
 if p_canuse then
  if p_usewait <= 0 then
   p_useidle = incmod(p_useidle,120)
  end
 else
  p_useidle = 0
  if area > 0 then
   d_show = false
  end
 end
end
--dot
if d_show and not d_shrink then
 if sfront then
  d_rx = 16+p_xreal
 elseif sleft then
  d_rx = 32+p_yreal
 elseif sback then
  d_rx = 112-p_xreal
 elseif sright then
  d_rx = 96-p_yreal
 end
 d_x = d_rx-2.5*sin(d_idle/d_imax)
 d_ry = 104-p_zreal
 d_y = d_ry+2*sin(2*d_idle/d_imax)
 if d_f < d_fmax and p_landed and happy <= 0 then
  d_f += 2
 end
else
 if d_f > 0 then
  d_f -= 2
  d_shrink = true
 else
  d_rx = -4
  d_ry = d_rx
  d_x = d_rx
  d_y = d_ry
  d_shrink = false
 end
end
d_idle = incmod(d_idle,d_imax)
d_axy = (d_axy+d_da)%d_amax
foreach(dot,calc_dv)
end
-->8
--text
function draw_speech()
local str,xoff,mm = talklines[talkline],p_xreal-47,false
local x1,y1 = 63-2*#str,max(1,d_ry-22)
local x2,y2 = x1+4*#str,y1+10
if sleft then
 xoff = p_yreal-31
elseif sback then
 xoff = 49-p_xreal  
elseif sright then
 xoff = 32-p_yreal
end
rectfill(x1-1,y1,x2+1,y2,0)
rect(x1-2,y1+1,x2+2,y2-1)
sspr(108,8,4,4,max(x1+1,d_x-13-xoff),y2+1)
print(sub(str,1,talkchar),x1+1,y1+3,7)
if talkchar >= #str and p_useidle%60 >= 30 then
 spr(15,x2-3,y2-1)
end
end

function draw_nuish(n,x,y)
--1. size
local str,cols,rows,mrows = nsh[n],1,0,0
for i=1,#str do
 local ch = sub(str,i,i)
 if ch == "/" then
  cols += 1
  rows = 0
 else
  rows += 1
  if mrows < rows then
   mrows = rows
  end
 end
end
--2. back
rows = mrows*5
cols = cols*5
local ww,hh = 8*ceil((cols+3)/8),8*ceil((rows+3)/8) 
local x2,y1,y2 = x+ww-1,y-hh-1,y-2
rectfill(x,y1,x2,y2,15)
rect(x+1,y1,x2,y1,7)
rect(x2,y1,x2,y2-1)
rect(x,y1+1,x,y2,6)
rect(x,y2,x2-2,y2)
--3. text
local xx,ytop = x2-4-flr((ww-cols-1)/2),y1+1+flr((hh-rows-1)/2)
local yy = ytop
for i=1,#str do
 local ch = sub(str,i,i)
 if ch == "/" then
  xx -= 5
  yy = ytop
 else
  if ch != " " then
   local cid = chars[ch]
   sspr(96+4*flr(cid/8),32+4*(cid%8),4,4,xx,yy)
  end
  yy += 5
 end
end
end
-->8
--draw
function square(x,y,c)
rect(x+3,y+6,x+4,y+7,c)
end

function blackpal()
for i=2,15 do
 pal(i,0)
end
end

function hornet()
pal(10,0)
end

function raid()
pal(10,10)
end

function pal_hidden()
local val = p_otrans
if val == 0 then
 val = min(4,1+flr(atrans/3))
end
for i=1,15 do
 pal(i,p_otcolors[val])
end
end

function draw_player(front)
if p_otrans > 0 or atrans > 0 then
 pal_hidden()
end
local sp = 48+p_frame/2
if happy > 0 then sp = 59
elseif p_dz > 0 or istalk() then sp = 60
elseif p_floor == false then sp = 61
elseif p_dpos != 0 then sp = 51+p_frame/3
end
draw_player_feet(front,sp)
draw_player_head(front,sp-16)
pal()
end

function draw_player_feet(front,sp)
if front or (p_x == cur_x and p_y == cur_y and p_z == cur_z) then
 local zz,xx = 120-p_zreal,12+p_xreal+r_factor*(p_yreal/8-4)
 if sleft then
  xx = 28+p_yreal-r_factor*(p_xreal/8-6)
 elseif sback then
  xx = 108-p_xreal-r_factor*(p_yreal/8-4)
 elseif sright then
  xx = 92-p_yreal+r_factor*(p_xreal/8-6)
 end
 spr(sp,xx,zz,1,1,p_mir,false)
end
end

function draw_player_head(front,sp)
if front or (p_x == cur_x and p_y == cur_y and p_z+1 == cur_z) then
 local zz,xx = 112-p_zreal,12+p_xreal+r_factor*(p_yreal/8-4)
 if p_usewait <= 0 and
  not istalk() and
  (p_lwait > 0 or p_dropwait > 0) then
  zz += 1
 end
 if sleft then
  xx = 28+p_yreal-r_factor*(p_xreal/8-6)
 elseif sback then
  xx = 108-p_xreal-r_factor*(p_yreal/8-4)
 elseif sright then
  xx = 92-p_yreal+r_factor*(p_xreal/8-6)
 end
 sspr(8*flr(sp-32),16,8,10,xx,zz,8,10,p_mir,false)
 end
end

function draw_front()
local p = 0
for yy=0,7 do
 cur_y = yy
 for xx=0,11 do    
  cur_x,cur_sx = xx,xx+12*area
  for zz=0,11 do
   cur_z = 11-zz
   cur_sy = yy+8*cur_z+32
   p = sget(cur_sx,cur_sy)
   if p == 15 then
    foreach(tiles,function(t) t:draw() end)
   elseif p > 0 then
    spr(p,16+8*xx+r_factor*(yy-4),120-8*cur_z)
   end
  end
 end
end
end

function draw_left()
local p = 0
for xx=0,11 do
 cur_x,cur_sx = xx,11-xx+12*area
 for yy=0,7 do
  cur_y = yy
  for zz=0,11 do
   cur_z = 11-zz
   cur_sy = yy+8*cur_z+32
   p = sget(cur_sx,cur_sy)
   if p == 15 then
    foreach(tiles,function(t) t:draw() end)
   elseif p > 0 then
    spr(p,32+8*yy+r_factor*(xx-6),120-8*cur_z)
   end
  end
 end
end
end

function draw_back()
local p = 0
for yy=0,7 do
 cur_y = yy
 for xx=0,11 do
  cur_x,cur_sx = xx,11-xx+12*area
  for zz=0,11 do
   cur_z = 11-zz
   cur_sy = 7-yy+8*cur_z+32
   p = sget(cur_sx,cur_sy)
   if p == 15 then
    foreach(tiles,function(t) t:draw() end)
   elseif p > 0 then
    spr(p,16+8*xx+r_factor*(yy-4),120-8*cur_z)
   end
  end
 end
end
end

function draw_right()
local p = 0
for xx=0,11 do
 cur_x,cur_sx = xx,xx+12*area
 for yy=0,7 do
  cur_y = yy
  for zz=0,11 do
   cur_z = 11-zz
   cur_sy = 7-yy+8*cur_z+32
   p = sget(cur_sx,cur_sy)
   if p == 15 then
    foreach(tiles,function(t) t:draw() end)
   elseif p > 0 then
    spr(p,32+8*yy+r_factor*(xx-6),120-8*cur_z)
   end
  end
 end
end
end

function r_trans()
local pos = (r_wait-5)*40*r_dir
rectfill(pos+15,0,pos+112,127,transcolor[aplus])
fillp(0b1011111111101111.1)
rectfill(pos,0,pos+127,127)
fillp(0b1010010110100101.1)
rectfill(pos+5,0,pos+122,127)
fillp(0b0000010000000001.1)
rectfill(pos+10,0,pos+117,127)
fillp()
end

function draw_title()
--borders
rectfill(0,-title_y,127,23-title_y,1)
rectfill(0,104-title_y,127,127-title_y)
rectfill(0,24-title_y,14,109-title_y)
rectfill(111,24-title_y,127,109-title_y)
fillp(0b0000010000000001.1)
rectfill(0,128-title_y,127,133-title_y)
fillp(0b1010010110100101.1)
rectfill(0,134-title_y,127,138-title_y)
fillp(0b1011111111101111.1)
rectfill(0,139-title_y,127,143-title_y)
fillp()
--logo
map(0,0,15,24-title_y,12,10)
rect(30,83-title_y,30,87-title_y)
rect(38,73-title_y,38,78-title_y)
pset(40,64-title_y)
rect(62,72-title_y,62,76-title_y)
pset(72,72-title_y)
pset(101,39-title_y)
pset(104,56-title_y)
pset(104,32-title_y)
rect(31,88-title_y,31,99-title_y,7)
rect(39,72-title_y,39,79-title_y)
pset(39,55-title_y)
pset(55,47-title_y)
pset(71,39-title_y)
rect(79,72-title_y,79,75-title_y)
pset(103,23-title_y)
rect(111,27-title_y,111,43-title_y)
rect(111,51-title_y,111,59-title_y)
if title_y == 0 then
 print("press any key",76,122,0)
end
end

function spr_outline(sp,y)
blackpal()
spr(sp,117,y)
spr(sp,119,y)
spr(sp,118,y-1)
spr(sp,118,y+1)
pal()
spr(sp,118,y)
end

function drrr()
if rrr >= 300 then
 for i=0,15 do
  for j=0,15 do
   spr(165,8*i,8*j)
  end
 end
else
 cls()
 if rrr < 295 then
  sspr(16,11,30,5,1,5)
  sspr(3,34,5,5,31,1)
 end
 if rrr < 290 then
  print("pico-8 0.1.12x",0,18,6)
 end
 if rrr < 285 then
  print("(c) 2014-xx lexaloffle games llp",0,24)
  print("type help for help",0,36)
 end
 if rrr < 280 then
  local pp = mid(7-flr((rrr+60)/40),2,5)
  print(sub("> run",1,pp),0,48,7)
  if flr(rrr/8)%2 >= 1 then
   rectfill(4*pp,48,4*pp+3,52,8)
  end
 end
end
end

function bns()
cls(13) 
if rel3 then
 for i=1,32 do
  local aa = -0.5*idle/maxidle+i/32
  print("♥",61+54*cos(aa),63+54*sin(aa),14)
 end
end
for i=0,5 do
 local aa = idle/maxidle+i/5
 for j=1,10 do
  local sf = j*9
  circfill(64+sf*cos(aa),64+sf*sin(aa),sf/3,14)
 end
end
circfill(64,64,22)
draw_nuish(9,16,104)
draw_nuish(8,104,104)
sspr(88,16,8,16,48,32+2.5*sin(2*idle/maxidle),32,64)
end

function _draw()
--draw world
local pzr = 120-p_zreal
cls(skycolor[aplus])
local rff = -32*r_wait*r_dir
if ismid(r_wait,5,10) then
 rff = 32*(10-r_wait)*r_dir
end
if area == 2 then
 local x1 = 53
 if r_wait < 10 then
  x1 += rff
 end
 rectfill(x1,5,x1+19,24,7)
 rectfill(x1+1,6,x1+11,16,6)
end
rectfill(0,0,127,cloud_y[aplus],cldcolor[aplus])
local cxx = p_xreal-47
if ismid(intro,36,44) then
 cxx += (rnd(2)-1)*4
 camera(cxx,0)
end
foreach(a_sky,function(a) a:draw() end)
if area == 3 then
 for xx=0,3 do
  for yy=0,3 do
   local x1,y1 = 44+12*xx,2+12*yy
   if r_wait < 10 then
    x1 += rff
   end
   if sget(111-yy,40+xx+4*lastkey) != 0 then
     rect(x1,y1,x1+12,y1+12,13)
   end
   pset(x1,y1,7)
  end
 end
end
hornet()
if sleft then
 cxx = p_yreal-31
elseif sback then
 cxx = 49-p_xreal
elseif sright then
 cxx = 33-p_yreal
end
camera(cxx,0)
if r_wait < 5 then r_factor = r_wait*r_dir/2
elseif r_wait < 10 then r_factor = (r_wait-10)*r_dir/2
else r_factor = 0
end
if area == 0 then
 local mx,xp,yp = 17,44,24
 if active[1] or intro < 40 then
  mx,xp = 12,48
  if pwait >= 15 or flr(pwait/2)%3 >= 2 or intro < 25 or flr(intro/3)%3 == 0 then
   rectfill(54,yp+14,73,yp+33,0)
  end
 else
  yp += 1.5*cos(idle/maxidle)
 end
 map(mx,0,xp,yp,5,5)
end
if sfront then draw_front()
elseif sleft then draw_left()
elseif sback then draw_back()
else draw_right()
end
if ending == 0 and intro >= 15 then
 draw_player(true)
end
pal()
foreach(tiles,function(a) a:fdraw() end)
draw_dot()
--draw front layer
camera()
if r_wait < 10 then r_trans() end
local ypos,bts,cbs,hp = 2,bits,cubes,happy>15
if hp and item == 0 then bts -= 1 end
if bts >= 8 then
 spr_outline(26,ypos)
 bts = 1
else
 rect(120,ypos,126,ypos+6,0)
 rectfill(121,ypos+1,125,ypos+5,10)
end
print(bts,116,ypos+1,0)
if cbs > 0 then
 ypos += 10
 if hp and item >= 3 then cbs -= 1 end
 spr_outline(26,ypos)
 pal(9,13)
 pal(10,12)
 spr(26,118,ypos)
 pal()
 print(cbs,116,ypos+1,0)
end
local yp2 = ypos
if rel1 then
 ypos += 10
 if not (hp and item == 1) then
  spr_outline(27,ypos)
 end
end
local yp3 = ypos
if rel2 then
 ypos += 10
 if not (hp and item == 2) then
  spr_outline(28,ypos)
 end
end
if hp then
 local yp = 2
 if item == 1 then
  yp = yp3
 elseif item == 2 then
  yp = ypos
 elseif item >= 3 then
  yp = yp2
 end
 local hf = (happy-15)/15
 local x1,y1 = 120-60*hf,yp+(pzr-yp-6)*hf
 if ismid(item,1,2) then
  spr(26+item,x1,y1)
 elseif item == 0 then
  rectfill(x1,y1,x1+5,y1+5,10)
 elseif item > 3 then
  sspr(98,64,12,16,x1,y1,6+6*hf,8+8*hf)
 end
end
if ending == 4 then bns()
elseif ending > 0 then
 local zz,xf = 108-p_zreal,7*title_idle/20
 color(6)
 if title_idle >= 20 then
  xf = 24-title_idle
  color(7)
 end
 if xf > 0 then
  rectfill(64-xf,zz-title_idle*3,63+xf,zz+17)
 end
 if ending < 2 or title_idle < 20 then
  spr(44,59,zz,1,2)
 end
end
hornet()
if istalk() and p_landed and happy <= 0 then
 draw_speech()
elseif p_canuse and ending == 0 and atrans <= 0 and p_usewait <= 0 and p_useidle%60 < 30 then
 local py = 106-p_zreal
 spr(15,59,py)
 sspr(104,8,4,2,59,py+6)
end
pal()
if rrr > 0 then drrr() end
if title then draw_title()
elseif atrans > 0 then
 local ff = 64-64*atrans/10
 rectfill(n1,n1,63-ff,128,0)
 rectfill(63+ff,n1,128,128)
 rectfill(n1,n1,128,pzr-2*ff)
 rectfill(n1,pzr+2*ff,128,128)
 if ending == 3 and not rel2 and atrans >= 40 then
  draw_nuish(10,112,120)
 end
end
end