--sonic 2.5
--by bonevolt

function spl_unp(s)
 return unpack(split(s))
end

poke(0x5f5c,255)

--memset(0x4300,0,0x1b00)
poke(0x5f2e,1)

--old room size 24*128=3072
--ehz1 size 52*686=35672
--ehz is 11.6 time bigger than the old room

--[[
bt={}
b_rec=--{press},{release}
{
--⬅️
[0]={{[265]=true},{[300]=true}},
--➡️
{{[1]=true,[300]=true},{[260]=true,[600]=true}},
--⬆️
{{},{}},
--⬇️
{{},{}},
--🅾️
{{[30]=true,[193]=true,[450]=true},{[60]=true,[200]=true,[451]=true}},
--❎
{{},{}},
}
obtn=btn
obtnp=btnp
function btnp(b)
 return obtnp(b) or b_rec[b][1][dt]
end
function btn(b)
 if (b_rec[b][1][dt]) bt[b]=true
 if (b_rec[b][2][dt]) bt[b]=false
 return obtn(b) or bt[b]
end
--]]

obtn=btn
obtnp=btnp
function btn(b)
 return obtn(b,0) or obtn(b,1)
end
function btnp(b)
 return obtnp(b,0) or obtnp(b,1)
end

--solids
t_height=
{
[6]={8,8,8,8,8,8,8,8},
[21]={8,8,8,8,8,8,8,8},
[22]={8,8,8,8,8,8,8,8},
[35]={8,8,8,8,8,8,8,8},
[36]={8,8,8,8,8,8,8,8},
[37]={8,8,8,8,8,8,8,8},
[55]={8,8,8,8,8,8,8,8},
[100]={8,8,8,8,8,8,8,8},
[101]={8,8,8,8,8,8,8,8},
[116]={8,8,8,8,8,8,8,8},
[117]={8,8,8,8,8,8,8,8},
[87]={8,8,8,8,8,8,8,8},
[104]={8,8,8,8,8,8,8,8},
[105]={8,8,8,8,8,8,8,8},
[120]={8,8,8,8,8,8,8,8},
[121]={8,8,8,8,8,8,8,8},
[222]={8,8,8,8,8,8,8,8},
[235]={8,8,8,8,8,8,8,8},
[236]={8,8,8,8,8,8,8,8},
[62]={8,8,8,8,8,8,8,8},

--semi-solid
[237]={8,8,8,8,8,8,8,8},

--acid
[69]={6,6,6,6,6,6,6,6},
[68]={8,8,8,8,8,8,8,8},

[52]={1,1,1,1,1,1,2,2},
[53]={2,2,2,3,3,3,4,4},
[54]={5,5,6,6,7,8,8,8},
[38]={0,0,0,0,0,0,1,2},
[39]={3,4,5,6,7,8,8,8},
[23]={0,0,0,0,1,2,3,4},
[7]={0,0,0,0,0,0,1,2},

[71]={1,1,1,0,0,0,0,0},
[20]={8,8,8,8,8,8,8,8},
[84]={8,8,8,8,8,8,8,8},
[85]={8,8,8,8,8,8,8,8},
[86]={8,8,8,8,8,8,8,8},

[112]={1,1,1,1,1,1,2,2},
[113]={2,2,2,3,3,3,4,4},
[114]={5,5,6,6,7,8,8,8},
[98]={0,0,0,0,0,0,1,2},
[99]={3,4,5,6,7,8,8,8},
[83]={0,0,0,0,1,2,3,4},
[67]={0,0,0,0,0,0,1,2},

[179]={0,0,0,0,0,0,1,2},
[163]={0,0,0,0,1,2,3,4},
[147]={3,4,5,6,7,8,8,8},
[146]={0,0,0,0,0,0,1,2},
[130]={5,5,6,6,7,8,8,8},
[129]={2,2,2,3,3,3,4,4},
[128]={1,1,1,1,1,1,2,2},

[136]={2,2,1,1,1,1,1,1},
[135]={4,4,3,3,3,2,2,2},
[134]={8,8,8,7,6,6,5,5},
[150]={2,1,0,0,0,0,0,0},
[149]={8,8,8,7,6,5,4,3},
[165]={4,3,2,1,0,0,0,0},
[181]={2,1,0,0,0,0,0,0},

[138]={2,1,0,0,0,0,0,0},
[154]={4,3,2,1,0,0,0,0},
[170]={8,8,8,7,6,5,4,3},
[171]={2,1,0,0,0,0,0,0},
[187]={8,8,8,7,6,6,5,5},
[188]={4,4,3,3,3,2,2,2},
[189]={2,2,1,1,1,1,1,1},
}

t_width=
{
[6]={8,8,8,8,8,8,8,8},
[21]={8,8,8,8,8,8,8,8},
[22]={8,8,8,8,8,8,8,8},
[35]={8,8,8,8,8,8,8,8},
[36]={8,8,8,8,8,8,8,8},
[37]={8,8,8,8,8,8,8,8},
[55]={8,8,8,8,8,8,8,8},
[100]={8,8,8,8,8,8,8,8},
[101]={8,8,8,8,8,8,8,8},
[116]={8,8,8,8,8,8,8,8},
[117]={8,8,8,8,8,8,8,8},
[87]={8,8,8,8,8,8,8,8},
[104]={8,8,8,8,8,8,8,8},
[105]={8,8,8,8,8,8,8,8},
[120]={8,8,8,8,8,8,8,8},
[121]={8,8,8,8,8,8,8,8},
[222]={8,8,8,8,8,8,8,8},
[235]={8,8,8,8,8,8,8,8},
[236]={8,8,8,8,8,8,8,8},
[62]={8,8,8,8,8,8,8,8},

--semi-solid
[237]={0,0,0,0,0,0,0,0},

--acid
[69]={0,0,8,8,8,8,8,8},
[68]={8,8,8,8,8,8,8,8},

[52]={0,0,0,0,0,0,1,2},
[53]={0,0,0,0,1,2,3,4},
[54]={3,4,5,6,7,8,8,8},
[38]={0,0,0,0,0,0,1,2},
[39]={5,5,6,6,7,8,8,8},
[23]={2,2,2,3,3,3,4,4},
[7]={1,1,1,1,1,1,2,2},

[71]={0,0,0,0,0,0,0,3},

[20]={8,8,8,8,8,8,8,8},
[84]={8,8,8,8,8,8,8,8},
[85]={8,8,8,8,8,8,8,8},
[86]={8,8,8,8,8,8,8,8},

[112]={0,0,0,0,0,0,1,2},
[113]={0,0,0,0,1,2,3,4},
[114]={3,4,5,6,7,8,8,8},
[98]={0,0,0,0,0,0,1,2},
[99]={5,5,6,6,7,8,8,8},
[83]={2,2,2,3,3,3,4,4},
[67]={1,1,1,1,1,1,2,2},

[179]={2,2,1,1,1,1,1,1},
[163]={4,4,3,3,3,2,2,2},
[147]={8,8,8,7,6,6,5,5},
[146]={2,1,0,0,0,0,0,0},
[130]={8,8,8,7,6,5,4,3},
[129]={4,3,2,1,0,0,0,0},
[128]={2,1,0,0,0,0,0,0},

[136]={2,1,0,0,0,0,0,0},
[135]={4,3,2,1,0,0,0,0},
[134]={8,8,8,7,6,5,4,3},
[150]={2,1,0,0,0,0,0,0},
[149]={8,8,8,7,6,6,5,5},
[165]={4,4,3,3,3,2,2,2},
[181]={2,2,1,1,1,1,1,1},

[138]={1,1,1,1,1,1,2,2},
[154]={2,2,2,3,3,3,4,4},
[170]={5,5,6,6,7,8,8,8},
[171]={0,0,0,0,0,0,1,2},
[187]={3,4,5,6,7,8,8,8},
[188]={0,0,0,0,1,2,3,4},
[189]={0,0,0,0,0,0,1,2},
}

t_ang=
{
[6]=0,
[21]=0,
[22]=0,
[35]=0,
[36]=0,
[37]=0,
[55]=0,
[100]=0,
[101]=0,
[116]=0,
[117]=0,
[87]=0,
[104]=0,
[105]=0,
[120]=0,
[121]=0,
[222]=0,
[235]=0,
[236]=0,
[62]=0,

--semi-solid
[237]=0,

--acid
[69]=0,
[68]=0,

[52]=0x.08,
[53]=0x.1,
[54]=0x.18,
[38]=0x.2,
[39]=0x.28,
[23]=0x.3,
[7]=0x.38,

[71]=0,
[20]=0,
[84]=0,
[85]=0,
[86]=0,

[112]=0x.08,
[113]=0x.1,
[114]=0x.18,
[98]=0x.2,
[99]=0x.28,
[83]=0x.3,
[67]=0x.38,

[179]=0x.48,
[163]=0x.5,
[147]=0x.58,
[146]=0x.6,
[130]=0x.68,
[129]=0x.7,
[128]=0x.78,

[136]=0x.88,
[135]=0x.9,
[134]=0x.98,
[150]=0x.a,
[149]=0x.a8,
[165]=0x.b,
[181]=0x.b8,

[138]=0x.c8,
[154]=0x.d,
[170]=0x.d8,
[171]=0x.e,
[187]=0x.e8,
[188]=0x.f,
[189]=0x.f8,
}

checked={}
for i=-10,16 do
 checked[i]={}
end

s_clr=
{
{[0]=7,12,0,8,9},
{[0]=7,13,1,0,14},
{[0]=7,13,10,11,3},
{[0]=7,6,5,5,4},
{[0]=6,5,4,3,2},
{[0]=12,14,8,9,2},
{[0]=7,6,6,4,4},
}

--grid=split("128,30,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,0,0,0,0,0,20,20,149,165,181,0,0,138,154,170,85,20,20,20,149,165,181,0,0,0,138,154,170,85,20,0,0,0,0,0,20,134,150,0,0,0,0,0,0,171,187,20,20,134,150,0,0,0,0,0,0,0,171,187,20,0,0,0,0,0,20,135,0,0,0,0,0,0,0,0,188,85,20,135,0,0,0,0,0,0,0,0,0,188,85,0,0,0,0,0,20,136,0,0,0,0,0,0,0,0,189,84,20,136,0,0,0,0,0,0,0,0,0,189,22,0,0,0,0,0,20,0,0,0,0,0,0,0,0,238,254,84,20,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0,0,20,0,0,0,0,0,0,0,0,239,255,84,20,0,0,0,0,0,0,0,0,0,238,254,6,0,0,0,0,0,20,0,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,0,0,0,239,255,22,0,0,0,0,0,20,0,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0,0,20,0,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0,0,20,128,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,0,0,0,0,52,22,0,0,0,0,0,20,129,0,0,0,0,84,20,20,20,20,20,20,0,0,0,0,0,0,0,0,0,0,53,6,0,0,0,0,0,20,130,146,0,0,0,0,138,154,170,85,20,20,0,0,0,0,0,0,0,0,0,38,54,6,0,0,0,0,0,20,20,147,163,179,0,0,0,0,171,187,20,20,0,0,0,0,0,0,0,7,23,39,55,22,0,0,0,0,0,20,20,20,20,20,20,0,0,0,0,188,85,20,0,0,0,0,0,0,22,21,37,37,37,36,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,189,84,20,0,0,0,0,0,0,6,21,100,116,21,116,0,0,0,0,0,16,32,48,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,6,21,101,117,21,117,0,0,0,0,0,17,33,49,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,22,21,37,37,36,20,0,0,0,0,0,18,34,50,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,22,21,20,100,116,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,6,21,20,101,117,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,6,21,20,20,20,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,22,21,20,20,20,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,0,0,0,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,0,0,0,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,84,20,0,0,0,0,0,0,0,238,254,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,112,84,20,128,0,0,0,0,0,0,239,255,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,113,86,20,129,0,0,0,0,0,0,0,0,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,98,114,20,20,130,146,0,0,0,0,0,0,0,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,67,83,99,86,20,20,20,147,0,0,0,0,0,0,0,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,0,0,0,0,0,0,71,170,85,20,20,20,0,0,0,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,0,0,0,0,0,0,0,171,187,20,20,20,0,0,0,0,0,0,0,0,0,0,0,0,84,20,100,116,100,116,0,0,0,0,0,0,0,0,188,85,20,20,0,0,0,0,0,0,0,0,0,0,0,0,84,20,101,117,101,117,0,0,0,0,0,0,0,0,189,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,0,0,0,0,0,0,0,238,254,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,84,100,116,100,116,20,0,0,0,0,0,0,0,239,255,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,84,101,117,101,117,20,0,0,0,0,0,0,0,0,0,84,20,20,0,0,0,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,0,0,0,0,0,0,0,0,0,22,100,116,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,36,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,21,36,0,0,0,0,0,0,0,0,0,0,84,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,21,36,0,0,0,0,0,0,0,0,0,0,84,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,36,0,0,0,0,0,0,0,0,0,0,84,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,21,36,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,101,117,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,37,36,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,21,0,0,0,0,0,20,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,112,84,20,20,0,0,0,0,0,20,129,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,113,86,20,20,0,0,0,0,0,20,130,146,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,98,114,20,20,20,0,0,0,0,0,20,20,147,163,179,0,0,0,0,0,0,0,0,0,0,0,0,0,67,83,99,86,20,20,20,0,0,0,0,0,20,20,20,20,20,20,0,0,0,0,84,20,20,20,20,20,20,20,20,20,20,20,20,20,20,0,0,0,0,0,20,20,20,20,20,20,0,0,0,0,84,20,20,20,20,20,20,20,20,20,20,20,20,20,20,0,0,0,0,0,35,35,100,116,35,35,51,51,51,51,22,21,100,116,35,35,35,35,21,21,35,35,35,35,35,0,0,0,0,0,35,35,101,117,35,35,51,51,51,51,6,21,101,117,35,35,35,35,21,21,35,35,35,35,35,0,0,0,0,0,35,35,51,51,35,35,51,51,51,51,6,21,100,36,37,36,35,35,21,21,35,35,20,20,35,0,0,0,0,0,35,35,51,51,35,35,51,51,51,51,22,21,101,36,37,36,35,35,21,21,35,35,20,20,35,0,0,0,0,0,35,35,100,116,35,35,51,51,51,51,22,21,36,37,37,37,37,37,36,100,116,21,20,20,20,0,0,0,0,0,35,35,101,117,35,35,51,51,51,51,6,21,36,37,37,37,37,37,36,101,117,21,20,20,20,0,0,0,0,0,35,35,51,51,35,35,51,51,51,51,6,21,100,116,35,35,35,35,35,35,35,35,20,20,20,0,0,0,0,0,35,35,51,51,35,35,51,51,51,51,22,21,101,117,35,35,35,35,35,35,35,35,20,20,20,0,0,0,0,0,20,20,149,165,181,0,51,51,51,51,51,51,0,0,0,0,0,0,0,138,154,170,85,20,20,0,0,0,0,0,20,134,150,0,0,0,51,51,51,51,51,51,0,0,0,0,0,0,0,0,0,171,187,20,20,0,0,0,0,0,20,135,0,0,0,0,51,51,51,51,6,21,36,37,37,36,0,0,0,0,0,0,188,85,20,20,20,20,20,20,20,136,0,0,0,0,51,51,51,51,22,21,36,37,37,36,0,0,0,0,0,0,189,84,20,20,20,20,20,20,20,0,0,0,0,0,0,0,0,0,22,21,51,51,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,20,20,0,0,0,0,0,0,0,0,0,6,21,51,51,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,20,20,0,0,0,0,0,0,0,0,0,6,21,100,116,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,20,20,0,0,0,0,0,0,0,0,0,22,21,101,117,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,20,20,128,0,0,0,0,0,0,0,52,22,21,35,35,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,20,20,129,0,0,0,0,0,0,0,53,6,21,35,35,0,0,0,0,0,0,0,0,0,84,20,20,20,20,20,20,20,130,146,0,0,0,0,0,38,54,6,21,35,35,0,0,0,0,0,0,0,0,0,21,20,20,20,20,20,20,20,20,147,163,179,0,7,23,39,55,22,21,35,35,0,0,0,0,0,0,0,0,0,21,20,20,20,20,20,20,22,21,35,35,35,35,100,116,35,35,51,51,51,51,0,0,0,0,0,0,0,0,0,21,20,0,0,0,0,0,6,21,35,35,35,35,101,117,35,35,51,51,51,51,0,0,0,0,0,0,0,0,0,21,20,0,0,0,0,0,6,21,35,35,35,35,36,37,37,37,37,37,37,37,36,0,0,0,0,0,0,0,52,21,35,0,0,0,0,0,22,21,35,35,35,35,36,37,37,37,37,37,37,37,36,0,0,0,0,0,0,0,53,21,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,38,54,21,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,23,39,55,21,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,35,35,100,116,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,21,35,35,101,117,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,21,35,35,100,116,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,35,35,101,117,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,100,116,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,21,101,117,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,21,100,116,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,101,117,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,21,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,21,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,22,21,36,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,6,21,36,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,6,21,36,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,22,21,36,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,22,21,36,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,6,21,35,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,6,21,35,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,0,0,0,22,21,35,0,0,0,0,0,0,0,0,0,69,68,68,68,68,68,68,68,0,0,0,0,0,0,0,22,21,36,37,21,36,37,37,0,0,0,0,0,0,0,22,21,35,35,35,35,35,35,0,0,0,0,0,0,0,6,21,35,35,21,35,35,35,0,0,0,0,0,0,0,6,21,37,37,37,37,37,36,0,0,0,0,0,0,0,6,21,35,35,21,35,35,35,0,0,0,0,0,0,0,6,21,37,37,37,37,37,36,0,0,0,0,0,0,0,22,21,36,37,21,36,37,37,0,0,0,0,0,0,0,22,21,35,35,35,35,35,35,0,0,0,0,0,0,0,22,21,100,116,21,100,116,21,0,0,0,0,0,0,0,22,21,35,35,35,35,35,35,0,0,0,0,0,0,0,6,21,101,117,21,101,117,21,0,0,0,0,0,0,0,6,21,35,35,35,35,35,35,0,0,0,0,0,0,0,6,21,36,37,21,36,37,21,0,0,0,0,0,0,0,6,21,37,37,37,37,37,36,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,22,21,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,52,6,21,37,37,37,37,37,36,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,53,6,21,37,37,37,37,37,36,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,38,54,22,21,35,35,35,35,35,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,23,39,55,22,21,35,35,35,35,35,35,0,0,0,0,0,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,6,21,35,35,35,35,35,35,0,0,0,0,0,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,6,21,37,37,37,37,37,36,0,0,0,0,0,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,22,21,37,37,37,37,37,36,0,0,0,0,0,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,35,22,21,35,35,35,35,35,35,0,0,0,0,0,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,6,21,35,35,35,35,35,35,0,0,0,0,0,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,6,21,35,35,35,35,35,35,0,0,0,0,0,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,37,22,21,37,37,37,37,37,36,0,0,0,0,0,")
grid=split("█゜⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘⁘ミWテhx⁘⁘⁘¹⁘⁘ˇしふ¹¹⌂あちU⁘⁘⁘ˇしふ¹¹¹⌂あちU⁘iyミテ⁘¹⁘●∧¹¹¹¹¹¹つめU⁘●∧¹¹¹¹¹¹¹つめ>ムムムムム¹⁘♥¹¹¹¹¹¹¹¹もT>♥¹¹¹¹¹¹¹¹¹も>⁘ミWWテ¹⁘☉¹¹¹¹¹¹¹¹やT>☉¹¹¹¹¹¹¹¹¹や◀‖t‖⁘⁘¹⁘¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹¹¹¹¹¹⁶‖u‖⁘⁘¹⁘¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹¹¹¹¹¹⁶‖t‖hx¹⁘¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹¹¹¹¹¹◀‖u‖iy¹⁘¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹¹¹¹¹¹⁶‖t‖ミテ¹⁘¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹¹¹¹¹¹⁶‖u‖⁘⁘¹⁘█¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹¹¹¹¹4◀‖t‖hx¹⁘▒¹¹¹NTT>ムムムム¹¹¹¹¹¹¹¹¹¹5⁶‖u‖iy¹⁘🐱★¹¹¹¹⌂あちU⁘⁘¹¹¹¹¹¹¹¹¹&6⁶‖t‖⁘⁘¹⁘⁘⧗こは¹¹¹¹つめU⁘¹¹¹¹¹¹¹⁷▶'7◀‖u‖⁘⁘¹⁘⁘⁘⁘⁘⁘¹¹¹¹もT>¹¹¹¹¹¹◀‖%%%%%%$⁘⁘¹¹¹¹¹¹¹¹¹¹¹やT>¹¹¹¹¹¹⁶‖dt‖t⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹⁶‖eu‖u⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹◀‖%%$⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹◀‖⁘dt⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹⁶‖⁘eu⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹⁶‖⁘⁘⁘⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹◀‖ムムムムムムムム¹¹¹¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹¹¹NT>⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹¹¹NT>⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹¹NT>¹¹¹¹¹¹¹¹NT>⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹¹pT>█¹¹¹¹¹¹¹NT>⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹¹qT>▒¹¹¹¹¹¹¹NT>⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹¹¹brV⁘🐱★¹¹¹¹¹¹NT>⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹¹CScV⁘⁘⁘⧗¹¹¹¹¹¹NT>⁘⁘⁘⁘⁘¹¹¹¹¹¹¹¹NT>⁘⁘hx¹¹¹¹¹¹GちUミWテ¹¹¹¹¹¹¹Nメ^ョュャT>ミテiy¹¹¹¹¹¹¹つめU⁘⁘¹¹¹¹¹¹¹Nメ^ョュャT>dtdt¹¹¹¹¹¹¹¹もT>⁘¹¹¹¹¹¹¹Nメ^ョュャT>eueu¹¹¹¹¹¹¹¹やT>⁘¹¹¹¹¹¹¹Nメ^ョュャT>ミテ⁘⁘¹¹¹¹¹¹¹¹NT>⁘¹¹¹¹¹¹¹Nメ^ョュャTdtdt⁘¹¹¹¹¹¹¹¹NT>⁘¹¹¹¹¹¹¹Nメ^ョュャTeueu⁘¹¹¹¹¹¹¹¹NT>⁘¹¹¹¹¹¹¹¹¹¹¹¹NT>ムムムム¹¹¹¹¹¹¹¹¹◀dt¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖$¹¹¹¹¹¹¹¹¹¹⁶¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶‖$¹¹¹¹¹¹¹¹¹¹T¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶‖$¹¹¹¹¹¹¹¹¹¹T¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖$¹¹¹¹¹¹¹¹¹¹T¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶‖$¹¹¹¹¹¹¹¹¹¹⁶¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶eu¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶%$¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖‖¹¹¹¹¹¹⁘█¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹pT>⁘¹¹¹¹¹¹⁘▒¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹qT>⁘¹¹¹¹¹¹⁘🐱★¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹brV⁘⁘¹¹¹¹¹¹⁘⁘⧗こは¹¹¹¹¹¹¹¹¹¹¹¹¹CScVミWテ¹¹¹¹¹¹⁘ムムムムム¹¹¹NT>⁘ミWテhx⁘ムムムムム⁘¹¹¹¹¹¹⁘⁘⁘⁘⁘⁘¹¹¹NT>⁘⁘⁘⁘iyミWWWテ⁘⁘¹¹¹¹¹¹##dt##3333◀‖dt####‖‖#####¹¹¹¹¹¹##eu##3333⁶‖eu####‖‖#####¹¹¹¹¹¹##33##3333⁶‖d$%$##‖‖##⁘⁘#¹¹¹¹¹¹##33##3333◀‖e$%$##‖‖##⁘⁘#¹¹¹¹¹¹##dt##3333◀‖$%%%%%$dt‖⁘⁘⁘¹¹¹¹¹¹##eu##3333⁶‖$%%%%%$eu‖⁘⁘⁘¹¹¹¹¹¹##33##3333⁶‖dt########⁘⁘⁘¹¹¹¹¹¹##33##3333◀‖eu########⁘⁘⁘¹¹¹¹¹¹⁘⁘ˇしふ¹333333¹¹¹¹¹¹¹⌂あちU⁘⁘¹¹¹¹¹¹⁘●∧¹¹¹333333¹¹¹¹¹¹¹¹¹つめ⁘⁘¹¹¹¹¹¹⁘♥¹¹¹¹3333⁶‖$%%$¹¹¹¹¹¹もU⁘⁘⁘⁘⁘⁘¹⁘☉¹¹¹¹3333◀‖$%%$¹¹¹¹¹¹やT⁘⁘⁘⁘⁘⁘¹⁘¹¹¹¹¹¹¹¹¹◀‖33¹¹¹¹¹¹¹¹¹T⁘⁘⁘⁘⁘⁘¹⁘¹¹¹¹¹¹¹¹¹⁶‖33¹¹¹¹¹¹¹¹¹T⁘⁘⁘⁘⁘⁘¹⁘¹¹¹¹¹¹¹¹¹⁶‖dt¹¹¹¹¹¹¹¹¹T⁘⁘⁘⁘⁘⁘¹⁘¹¹¹¹¹¹¹¹¹◀‖eu¹¹¹¹¹¹¹¹¹T⁘⁘⁘⁘⁘⁘¹⁘█¹¹¹¹¹¹¹4◀‖##¹¹¹¹¹¹¹¹¹T⁘⁘⁘⁘⁘⁘¹⁘▒¹¹¹¹¹¹¹5⁶‖##¹¹¹¹¹¹¹¹¹T⁘⁘⁘⁘⁘⁘¹⁘🐱★¹¹¹¹¹&6⁶‖##¹¹¹¹¹¹¹¹¹‖⁘⁘⁘⁘⁘⁘¹⁘⁘⧗こは¹⁷▶'7◀‖##¹¹¹¹¹¹¹¹¹‖⁘⁘⁘⁘⁘⁘¹◀‖####dt##3333¹¹¹¹¹¹¹¹¹‖⁘¹¹¹¹¹¹⁶‖####eu##3333¹¹¹¹¹¹¹¹¹‖⁘¹¹¹¹¹¹⁶‖####$%%%%%%%$¹¹¹¹¹¹¹4‖#¹¹¹¹¹¹◀‖####$%%%%%%%$¹¹¹¹¹¹¹5‖#¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹&6‖#¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁷▶'7‖#¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖##dt######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶‖##eu######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶‖##dt######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖##eu######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖dt####¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶‖eu####¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶‖dt####¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖eu####¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶‖######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁶‖######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹◀‖$¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹⁶‖$¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹⁶‖$¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹◀‖$¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹◀‖$¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹⁶‖#¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹⁶‖#¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹¹¹¹◀‖#¹¹¹¹¹¹¹¹¹EDDDDDDD¹¹¹¹¹¹¹¹◀‖$%‖$%%¹¹¹¹¹¹¹◀‖######¹¹¹¹¹¹¹¹⁶‖##‖###¹¹¹¹¹¹¹⁶‖%%%%%$¹¹¹¹¹¹¹¹⁶‖##‖###¹¹¹¹¹¹¹⁶‖%%%%%$¹¹¹¹¹¹¹¹◀‖$%‖$%%¹¹¹¹¹¹¹◀‖######¹¹¹¹¹¹¹¹◀‖dt‖dt‖¹¹¹¹¹¹¹◀‖######¹¹¹¹¹¹¹¹⁶‖eu‖eu‖¹¹¹¹¹¹¹⁶‖######¹¹¹¹¹¹¹¹⁶‖$%‖$%‖¹¹¹¹¹¹¹⁶‖%%%%%$¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹◀‖######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹4⁶‖%%%%%$¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹5⁶‖%%%%%$¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹&6◀‖######¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹¹⁷▶'7◀‖######¹¹¹¹¹¹%%%%%%%%%%%%%%%%%⁶‖######¹¹¹¹¹¹%%%%%%%%%%%%%%%%%⁶‖%%%%%$¹¹¹¹¹¹#################◀‖%%%%%$¹¹¹¹¹¹#################◀‖######¹¹¹¹¹¹%%%%%%%%%%%%%%%%%⁶‖######¹¹¹¹¹¹%%%%%%%%%%%%%%%%%⁶‖######¹¹¹¹¹¹%%%%%%%%%%%%%%%%%◀‖%%%%%$¹¹¹¹¹¹","")

tilew=ord(grid[1])
tileh=ord(grid[2])
tilegrid={}
for i=0,tilew+2 do
 tilegrid[i]={}
 for j=0,tileh+2 do
  tilegrid[i][j]=0
 end
end
for i=0,tilew-1 do
 for j=0,tileh-1 do
  --tilegrid[i][j]=mget(i,j)
  tilegrid[i][j]=ord(grid[i*tileh+j+3])
 end
end
--mouse
poke(0x5f2d,1)

--tiletyp={}
--n=1
--for k,v in pairs(t_ang) do
-- if v==0 then
--	 tiletyp[n]=k
--	 n+=1
-- end
--end
--
----ramps
--add(tiletyp,138)
--add(tiletyp,67)
--add(tiletyp,181)
--add(tiletyp,179)
--add(tiletyp,7)
----non-solid
--add(tiletyp,51)
--add(tiletyp,253)
--add(tiletyp,252)
--add(tiletyp,251)
--add(tiletyp,78)
--add(tiletyp,94)
--
--ramp_seq=
--{
--[138]=
--{138,0,0,0,
--154,0,0,0,
--170,171,0,0,
--85,187,188,189},
--[67]=
--{0,0,0,67,
--0,0,0,83,
--0,0,98,99,
--112,113,114,86},
--[181]=
--{20,134,135,136,
--149,150,0,0,
--165,0,0,0,
--181,0,0,0},
--[179]=
--{128,129,130,20,
--0,0,146,147,
--0,0,0,163,
--0,0,0,179},
--[7]=
--{0,0,0,7,
--0,0,0,23,
--0,0,38,39,
--52,53,54,55}
--}

--function save_level()
-- local str=chr(tilew)..chr(tileh)
--	for i=0,tilew-1 do
--	 for j=0,tileh-1 do
--	  --str..=tilegrid[i][j]..","
--	  local s=tilegrid[i][j]
--	  s=s==0 and 1 or s
--	  str..=chr(s)
--	 end
--	end
--	printh(str,"@clip")
--end
-->8
--init
function _init()
 game=false
 gdt=0
end

function init_game()
 pre_dt=0
 opening=0
 dt=0
 tim=0
 
 music(7)
 
 --consts
 acc=0x.06
 air_acc=0x.0c
 dec=.25
 frc=0x.06
 slp=0x.1
 fal=1.25
 
 top=4
 
 jmp=3.25
 grv=0x.1c
 
 --vars
 sgs,swin,sdead=0,0
 sang=0
 v_sang=0
 sx=45
 sxs=0
 sy=--[[150--]]80
 sys=0
 set_mode(0)
 sground=false
 sflip=false
 sstate="walk"
 hlock=0
 s_anim="stand"
 s_anim_timer=0
 s_anim_frame=0
 spin_rev=0
 invinc=0
 
 rings=0
 
 --camera
 cx,cy=sx,sy
 
 --curr_shield=false--rnd(7)\1+1
 
 obj={}
 --rings
 init_obj(spl_unp"1,252,2")
 init_obj(spl_unp"1,264,2")
 init_obj(spl_unp"1,276,2")
 
 init_obj(spl_unp"1,132,140")
 init_obj(spl_unp"1,144,140")
 init_obj(spl_unp"1,156,140")
 
 --monitors
 init_obj(spl_unp"2,70,79,0")
 init_obj(spl_unp"2,64,183,1")
 
 --badnik
 init_obj(spl_unp"6,224,44")
 
 --spike
 init_obj(spl_unp"7,202,167")
 
 --end ring
 init_obj(spl_unp"8,995,-40")
 
-- init_obj(4,160,80,79)
 init_obj(spl_unp"4,700,80,79")
end
-->8
--init functs
function init_obj(t,x,y,s)
 return add(obj,
 {
 typ=t,
 x=x,
 y=y,
 dead=-1,
 dt=0,
 w=({10,10,10,20,0,12,12,16})[t],
 solid=({false,true,false,false,false,false,1,false})[t],
 eff=0,--bumper expand time
 subtyp=s,
 }
 )
end
-->8
--update
function _update60()
 gdt+=1
 
 if not game and gdt>60 and (btnp(❎) or btnp(🅾️)) then
  game=true
  init_game()
 end
 
 if game then
  upd_game()
 end
end

function upd_game()
 if (sdead and sdead>180) _init()
 if pre_dt<110 then
  pre_dt+=1
 else
  dt+=1
  if (swin>0) swin+=1
  if swin<=20 then
   _upd()
  end
 end
 
 --camera
 if not (sdead or swin>0) then
	 cx+=max(0,abs(sx-cx)-4)*sgn(sx-cx)
	 if not sground then
	  cy+=max(0,abs(sy-cy)-16)*sgn(sy-cy)
	 else
	  local camspd=max(3,abs(sgs))
	  cy+=mid(-camspd,camspd,sy-cy)
	 end
	 --cx=mid(64,cx,336)
	 --cx=mid(64,cx,336+336+288)
	 cx=mid(64,cx,tilew*8-56-8)
	 --cy=mid(-64,cy,136)
	 cy=mid(0,cy,tileh*8-56-56)
	-- sx=40
	-- sy=80
 end
end

function _upd()
 if (sdead) sdead+=1
 if (dt%60==0) tim+=1
	for i=-10,16 do
	 checked[i]={}
	end
	
	if spdshoes_dt then
		spdshoes_dt+=1
		if spdshoes_dt>1200 then
			mus_spd_nxt=13
		 acc,spdshoes_dt=0x.06
		 air_acc=0x.0c
		 top=4
	 end
 end
 
 if mus_spd_nxt and last_mus~=stat(24) then
		for i=33,61 do
		 poke(0x3200+68*i+65,mus_spd_nxt)
		end
	 music(stat(24))
	 mus_spd_nxt=nil
 end
 last_mus=stat(24)
	
	if (invinc>0 and sstate~="hurt") invinc-=1

 --slope
 if sground then
  sgs+=slp*sin(sang)
 end
 
 --input and ground spd upd
 
 if sstate~="spdash"
 and sstate~="crouch"
 and sstate~="hurt"
 then
	 if sground then
	  sgs=input_x(sgs,acc,dec,frc)
	 else
	  sxs=input_x(sxs,air_acc,air_acc,0)
	 end
 end
 
-- if band(btn(),3)==0 then
--  launch=false
-- end
 
 hlock=max(0,hlock-1)
 
 djump=djump and not sground
 --jump
 if sstate~="hurt" then
  grv=0x.1c
	 if (btnp(❎) or btnp(🅾️)) then
		 if sground then
		  if sstate=="walk" or sstate=="spin" then
     sfx(16)
			  jmp_press=true
			  sstate="spin"
			  sground=false
			  sxs+=jmp*sin(sang)
			  --sgs=sxs
			  sys-=jmp*cos(sang)
			  set_mode(0)
			  sang=0
		  end
		 elseif not djump then
		  djump=true
		  sstate="spin"
		  if curr_shield==1 then
		   sfx(11)
			  sxs=sflip and -3 or 3
			  sys=btn(⬆️) and -3 or 3
		  end
		 end
	 end
	 if jmp_press
	 and (not (btn(❎) or btn(🅾️))
	 or sys>-2)
	 then
	  jmp_press=false
	  sys=max(-2,sys)
	 end
	else
  grv=0x.18
 end
 
 if not sground then
  --sxs=sgs
  sys+=grv
  hlock=0
  --air drag
  if sys<0 and sys>-4 then
   sxs-=sxs\0x.2/256
  end
 else
	 sxs=sgs*cos(sang)
	 sys=sgs*sin(sang)
	 
	 --fall
  if abs(sgs)<fal
  and sang>0x.2
  and sang<0x.e
  and hlock==0
  then
	  if sang>=0x.4
	  and sang<=0x.c then
	   sground=false
    --sgs=sxs
    set_mode(0)
    sang=0
	  end
   hlock=30
  end
 end
 
 sys=mid(8,-8,sys)
 
 sx+=sxs
 sy+=sys
 
 if sx<5 or sx>tilew*8 then
  sx=mid(5,sx,tilew*8)
  sxs=0
  sgs=0
 end
 
 if not sdead then
	 --wall collision
	 if smode~=0 then
		 for i=-5,6,11 do
		  local hh,tile=gr_check(0,i-(smode==3 and 0 or 1),last,true)
		  if hh==8 then
		   sgs=0
		   set_mode(0)
		   sang=0
		  end
		 end
		end
	 if smode==0 then
		 for i=-5,6,11 do
		  local hh,tile=gr_check(0,i,last,true)
		  if hh==8 then
		   for pix=1,8 do
		    if t_height[tile][pix]==8 then
		     wall=pix
		     if (i>0) break
		    end
		   end
		   
		   sx=(flr(sx)+i)\8*8-i+wall-sgn(i)*.5-.5
		   sgs=0
		   sxs=0
		  end
		 end
	 end
	 
	 --"for loop" once in case of falling on a wall (detects floor 1st,switches mode and detects wall) 
	 for i=0,sground and 0 or 1 do
		 --ground collision/snap
		 if sground or sys>0 or abs(sxs)>abs(sys) then
		  grn_coll(1)
		 end
		 
		 --ceil collision/snap
		 if not sground and (sys<0 or abs(sxs)>abs(sys)) then
		  grn_coll(-1,true)
		 end
	 end
	 
	 --obj coll
	 for o in all(obj) do
	  if o.solid and o.dead<0
	  and (sstate~="spin" or o.solid==1) then
	   if abs(sx-o.x)<=o.w
	   and abs(sy-o.y)<=o.w then
	    sx=o.x-(o.w+.01)*sgn(sxs)
		   sgs=0
		   sxs=0
	   end
	   if abs(sx-o.x)<=o.w
	   and abs(sy+sgn(sys)*4-o.y)<=o.w then
	    sy=o.y-(o.w+sgn(sys)*4)*sgn(sys)
		   sys=0
		   sground=true
		   sgs=sxs
		   if (o.typ==7) s_hurt()
	   end
	  end
	 end
 end

 --obj
 for o in all(obj) do
  o.dt+=1
  --move
  if o.typ==3 then
   o.y-=.15
   o.x+=sin(o.dt/60)/5
   if o.dt>1200
   and o.dead<0 then
    o.dead=1
   end
  elseif o.typ==6 then
   o.x-=o.flip and -.3 or .3
   if dt%300==299 then
    o.flip=not o.flip
   end
  end
  --collision
	 if o.dead<0 then
   if sstate~="hurt"
   and abs(sx-o.x)<=o.w
   and abs(sy-o.y)<=o.w then
    if o.typ==1
    and invinc<90 then
     --ring
     sfx(21)
     rings+=1
     o.dead=1
    elseif o.typ==2
    and sstate=="spin" then
     --monitor
     sfx(17)
     sfx(18)
     if o.subtyp==1 then
      --speed shoes
						mus_spd_nxt=10
						spdshoes_dt=0
					 acc=0x.0c
					 air_acc=0x.18
					 top=6
					else
					 --shield
      curr_shield=1
     end
     sys*=-1
     jmp_press=true
     init_obj(5,o.x,o.y)
     --expl.dead=0
     o.dead=1
    elseif o.typ==3 then
     --bubble
     jmp_press=true
     sground=false
     sys=-3.5
     o.dead=1
     sfx(20)
    elseif o.typ==4 then
     --bumper
     local dx,dy=o.x-sx,o.y-sy
     if sqrt(dx^2+dy^2)<=20 then
	     sfx(28)
	     local ang=atan2(dx,dy)
	     sys=sin(ang+.275)*4
	     sxs=cos(ang+.275)*4
	     sx=o.x-cos(ang)*22
	     sy=o.y-sin(ang)*22
	     o.dt=-20
				  sstate="spin"
				  sground=false
			  end
    elseif o.typ==6 then
     if sstate=="spin" then
	     --badnik
	     sfx(17)
	     sfx(18)
	     sys*=-1*sgn(sys)
	     jmp_press=true
	     init_obj(5,o.x,o.y)
	     o.dead=40
	    else
	     s_hurt()
     end
    elseif o.typ==8 and swin==0 then
     --giant ring
     sfx(62)
     swin+=1
    end
   end
   --scattered rings
	  if o.scatter then
	   o.x+=o.xs
	   o.y+=o.ys
	   o.ys+=0x.0c
	   local tile=o.x>0 and o.x<tilew*8 and tilegrid[o.x\8][(o.y+4)\8]
	   local ang=tile and t_ang[tile]
	   if o.dt%4==o.scatter
	   and o.ys>0
	   and ang
	   and ang==0
	   then
	    o.ys=min(-1.5,o.ys*-.75)
	   end
	   if (o.dt>256) del(obj,o)
	  end
  else
   o.dead+=1
   if o.dead>=24 and o.typ~=2 then
    del(obj,o)
   end
	 end
 end
 
-- if dt==15 then
--  s_hurt()
-- end
 
 spin_rev-=spin_rev\0x.2/256
 if sstate~="hurt" then
	 if btn(⬇️) then
	  if abs(sgs)>=.5 or not sground or -abs(-sang+.5)+.5>0x.2 then
	   if sstate~="spin" then
	    sfx(9)
	   end
	   sstate="spin"
	  else
	   if sstate~="spdash" then
	    sstate="crouch"
	   end
	   sgs=0
	   sxs=0
	   if btnp(❎) or btnp(🅾️) then
	    if sstate=="spdash" then
	     spin_rev=min(4,spin_rev+1)
	    else
	     sstate="spdash"
	     spin_rev=0
	    end
	    for i=0,31 do
	     poke(0x35fc+2*i,min(117,i+105)+spin_rev*2\1)
	    end
	    sfx(15)
	   end
	  end
	 else
	  if sstate=="spdash" then
	   for i=0,3 do
	    if (stat(i+16)==15) sfx(-1,i)
	   end
	   sfx(10)
	   sfx(11)
	   sstate="spin"
	   sgs=(4+spin_rev)*(sflip and -1 or 1)
	  elseif sground
		 and (btn(⬆️)
		 or abs(sgs)<.25) then
			 sstate="walk"
		 end
	 end
 end
 
 if sground then
  v_sang=sang
 else
  ang=abs(v_sang*2-1)-1
  if ang==0 then
   v_sang=0
  else
   v_sang+=sgn(v_sang-.5)/64
  end
 end

 --acid sprite animation
 if dt%6==0 then
  local acid_t={}
  for j=0,3 do
	  for i=0,7 do
	   acid_t[i]=sget(40+i,32+j)
	  end
	  for i=0,7 do
	   sset(40+i,32+j,acid_t[(i-1)%8])
	  end
  end
 end
 if dt%30==0 then
	 for i=0,7 do
	  for j=0,3 do
	   sset(40+i,32+j,sget(40+i,32+j+1))
	  end
	 end
 elseif dt%30==15 then
	 for i=0,7 do
	  for j=4,1,-1 do
	   sset(40+i,32+j,sget(40+i,32+j-1))
	  end
	  sset(40+i,32,0)
	 end
 end
 
 if dt%230==0 then
  init_obj(3,736+(dt%460/6),142)
 end
 
 --mouse
-- mousex,mousey=stat(32),stat(33)
--	tgttilex,tgttiley=(mousex+cx-64)\8,(mousey+cy-64)\8
-- if stat(34)==1 then
--  if mousey<94 or not show_tilesel then
--   --increase w
--	  if tgttilex>=tilew then
--	   tilew+=1
--	   local i=tilew+2
--			 tilegrid[i]={}
--			 for j=0,tileh+2 do
--			  tilegrid[i][j]=0
--			 end
--	  end
--   --increase h
--	  if tgttiley>=tileh then
--	   tileh+=1
--				for i=0,tilew+2 do
--				 local j=tileh+2
--				 tilegrid[i][j]=0
--				end
--	  end
--	  --place tile
--	  tilegrid[tgttilex][tgttiley]=draw_typ or 0
--	  if ramp_seq[draw_typ] then
--	   for i=0,15 do
--	    tilegrid[tgttilex+i%4][tgttiley+i\4]=ramp_seq[draw_typ][i+1]
--	   end
--	  end
--	 else
--	  draw_typ=tiletyp[mousex\8+(mousey-94)\8*16+1]
--	 end
--	elseif stat(34)==2 then
--	 draw_typ=tilegrid[tgttilex][tgttiley]
-- end
-- if (btnp(⬆️)) show_tilesel=not show_tilesel
end
--menuitem(1,"save level",save_level)

-->8
--upd functs
function input_x(xs,acc,dec,frc)
 local cap,roll=mid(top,8,abs(xs))
 
-- local ⬅️,➡️=⬅️,➡️
-- if launch then
--  ⬅️,➡️=➡️,⬅️
-- end
 if sstate=="spin" and sground then
  roll=true
  frc/=2
  acc=-frc
  dec=dec/2+frc
 end
 if btn(⬅️) and (hlock==0 or not sground) then
  if xs<=0 then
   xs-=acc
  else
   xs-=dec
  end
  sflip=true
 elseif btn(➡️) and (hlock==0 or not sground) then
  if xs>=0 then
   xs+=acc
  else
   xs+=dec
  end
  sflip=false
 else
  if (abs(xs)<=frc) xs=0
  xs-=frc*(xs==0 and 0 or sgn(xs))
 end
 
 return mid(-cap,xs,cap)
end

function gr_check(v1,v2,last,ign_semi)
 local xx,yy=flr(sx)+cos(m_ang)*v2-sin(m_ang)*v1,flr(sy)+cos(m_ang)*v1-sin(m_ang)*v2
 local tile=tilegrid[xx\8][yy\8]

 if tile~=237 or not ign_semi then
	 if t_height[tile] or last then
	  local tn,nn=t_height,xx
	  if smode%2==1 then
	   tn,nn=t_width,yy
	  end
	  local h=tn[tile]==nil and 0 or tn[tile][flr((nn)%8)+1]
	  return h,tile
	 end
 end
 
 return 0,0
end

function set_mode(n)
 smode=n
 m_ang=smode/4
end

function s_hurt()
 if invinc<=0 then
  invinc=120
  sys=-2
  sxs=1
  sstate="hurt"
		sground=false
		set_mode(0)
		sang=0
		v_sang=0
		
		if curr_shield then
		 curr_shield=nil
		 sfx(25)
		elseif rings>0 then
	  sfx(13)
	  sfx(14)
			for i=0,min(rings-1,31) do
			 local ang=i/16-0x.08
			 local spd=i\16-2
			 local last=init_obj(1,sx,sy)
			 last.scatter=i%4
			 last.xs=spd*sin(ang)
			 last.ys=spd*cos(ang)
			end
			rings=0
		else
		 sdead=0
		 sfx(25)
		end
 end
end
-->8
function _draw()
 cls(1)
 if game then
  drw_game()
 else
  ?"    sonic 2.5 sage 2020\n\n\nthis version of the game\nfeatures a very small level\nto test basic mechanics.\n\na new version with a bigger\nlevel and more content will\nbe released in the following\nweeks.\n\n\n⬅️⬇️➡️ move\nz x jump\nhold ⬆️ to use shield upwards\n\n(has controller support too)\n\n                    -bonevolt",10,5,6
 end
end

function drw_game()
 if pre_dt>60 then
	 _draw_stage()
 end
	
	if tim<1 then
	 opening+=(pre_dt<60) and 1 or -1
	 if (pre_dt<60) cls(2)
		rectfill(0,-1,127,opening*8,3)
		
		rectfill(224-opening*8,85,128,127,13)
		
		for i=0,127 do
		 rectfill(-1,i,min(44,opening*8-256)+(i-3)%12-min(5,(i-3)%12)*2,i,2)
		 rectfill(-1,i,min(44,opening*8-256)+i%12-min(5,i%12)*2,i,8)
		end
	end
	
	if swin>120 then
	 rectfill(20,20,107,107,2)
	 rect(21,21,106,106,6)
	 ?"\n     the end...\n\n...of this demo\n\n\n\nthanks for playing!\n\n press enter/pause\n     to reset",27,30,7
	end
	
	pal((
	{
	9,1,140,
	13,12,6,7,
	8+(curr_shield==6 and 128 or 0),2,138,139,
	143,10,4,15,137,}),1)
end

function _draw_stage()
 cls(2)
 
 --clouds
 if (dt==1) pre_gfx()
 
 if cx<650 then
	 --copy cloud from data
	 memcpy(0x6000+64*19,0x4300,37*64)
	 --bg water
	 rectfill(0,56,127,127,3)
	 --horizon line
	 rectfill(0,56,127,56,7)
	 pal(2,3)
	 pal(7,5)
	 pal(6,5)
	-- for i=0,19 do
	--  sspr(0,i,128,1,sin((i+dt\6)/6),57+i)
	-- end
	-- for i=0,19 do
	--  memcpy(i*64,0x4300+64*55+i*64,64)
	-- end
	
	 --water reflection
	 for i=0,19 do
	  memcpy(0x5dc0,0,64)
	  memcpy(0,0x4300-i*128+38*64,64)
	  sspr(0,0,128,1,sin((i+dt\6)/6),57+i)
	  memcpy(0,0x5dc0,64)
	 end
	 
	 --hills
	 memcpy(0x6000+79*64,0x4300+37*64,19*64)
	 
	 --field paralax
	 rectfill(0,98,127,99,11)
	 for i=0,27 do
	  local n=(cx/(i\2*2-30))%128
	  memcpy(0x5dc0,0,64)
	  memcpy(0,0x4300+i*64+56*64,64)
	  sspr(0,0,128,1,n,100+i)
	  sspr(0,0,128,1,n-128,100+i)
	  memcpy(0,0x5dc0,64)
	 end
	 
	 pal()
	 
	 --horizon water glimmer
	 for i=0,17 do
	  spr(70,i*8-dt\12%2,57,1,1,dt\6%2==0)
	 end
	else
	 rectfill(0,0,127,15,9)
	 fillp(0xbebe)
	 rectfill(0,15,127,30,0x92)
	 fillp(0x5a5a)
	 rectfill(0,30,127,45,0x92)
	 fillp(0x8282)
	 rectfill(0,45,127,60,0x92)
	 fillp(0x5a5a)
	 rectfill(0,119,127,127,0x92)
	 fillp()
	 palt(0,false)
	 for j=0,10 do
	  for i=12,127,32 do
		  spr(207,i,j*8+88-i%60)
		  spr(i%64==12 and 207 or 223,i+8,j*8+88-i%60,1,1,1)
	  end
	 end
	end
 
 camera(cx-64,cy-64)
 palt(0,true)
 --bg
-- for j=72,64,-8 do
--	 for i=0,128,64-16 do
--	  spr(8,i,j,6,7)
--	 end
-- end
-- 

 --cave
 for i=14,41 do
  for j=13,21 do
   spr((j==13 or j==18 and i<22 or j==21) and 111 or 95,i<<3,j<<3,1,1,j>17,j>17)
  end
 end
 
 palt(0,false)
 for i=73,89 do
  for j=-20,22 do
   spr(127,i<<3,j<<3)
  end
 end
 pal()
 
 --rectfill(73<<3,-20<<3,90<<3,23<<3,0x92)
 
 --map(0,0,0,0,16*8,16*4,0)
 
 --tileset
 for i=cx\8-8,cx\8+8 do
  for j=cy\8-8,cy\8+8 do
		 local t=tilegrid[i][j]
		 if j>=0 then
    draw_tile(i*8,j*8,t,i,j)
   end
  end
 end
 pal()
 
 --flower
 function flower(x,y)
	 palt(0,false)
	 palt(2,true)
	 local st=({0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,0,0,2,2,0,0,2,0,2,0})[dt\6%36+1]
	 sspr(120,24,8,8,x*8+st/2-1,y*8-st-7,9-st,7+st)
	 spr(79,x*8,y*8,1,1)
	 --spr(63,32*8,5*8,1,2)
	 palt(2,false)
	 palt(0,true)
 end
 flower(40,8)
 flower(18,10)
 flower(21,10)
 
 --waterfalls back
 if cx<650 then
	 for i=1,4 do
	  pal(i,(-dt\8+i)%4+3)
	 end
	 for i=37,41 do
	  for j=6,12 do
	   spr(143,i*8,j*16+2,1,2)
	  end
	  spr(175,i*8,6.5*16-9)
	  spr(175,i*8,11.5*16-9)
	 end
	else
	 for i=1,4 do
	  pal(i,({2,11,10,13})[(-dt\8+i)%4+1])
	 end
	 for i=100,104 do
	  for j=4,8 do
	   spr(143,i*8,j*16+2,1,2)
	  end
	  spr(175,i*8,4.5*16-9)
	 end
	end
 
 pal()
 
 for o in all(obj) do
  if abs(cx-o.x)<64+o.w
  and abs(cy-o.y)<64+o.w then
	  if o.typ==1 then
    --rings
		  if o.dead<0 then
		   spr(dt\5%6,o.x-4,o.y-4)
		  end
		 elseif o.typ==2 then
		  --monitor
			 palt(0,false)
			 palt(15,true)
			 if o.dead<0 then
				 spr(224,o.x-7,o.y-7,2,2)
				 sspr(16,108+o.subtyp*5,7,5,o.x-3,o.y-2)
				 palt(0,true)
				 palt(15,false)
				 pal(dt%12>6 and {7,6,4} or {4,7,6})
				 if (dt%6<2) sspr(23,112,9,7,o.x-4,o.y-3)
			 else
				 spr(218,o.x-7,o.y+1,2,1)
				end
			 pal()
		 elseif o.typ==3 then
		  --bubble
		  if o.dead<0 or dt%4<2 then
		   spr(102,o.x-8,o.y-8,2,2)
		  end
		 elseif o.typ==4 then
		  --conveyor bumper
			 local cx,cy=camera()
			 camera(cx-o.x,cy-o.y)
			 circfill(0,0,21-min(o.dt\20,0),10+dt\4%2)
			 circfill(0,0,20,9)
			 circfill(0,-1,19,4)
			 for k=2,14 do
			  i=({0,1,2,3,4,5,6,7,14,13,12,11,10,9,8})[k+1]
			  circfill(cos(i/32)*17+.5,sin(i/32)*17+.5,2,({2,4,6,7})[-sin(i/32)*3\1+1])
			 end
			 for i=0,15,.5 do
			  circfill(sin(t()*1.5+i/16)*15+.5,cos(t()*1.5+i/16)*15+.5,2,({11,10,13,7})[i\1%4+1])
			 end
			 circfill(0,0,12,9)
			 circfill(0,-1,11,4)
			 circfill(0,-4,7,6)
			 circfill(0,-5,4,7)
			 camera(cx,cy)
		 elseif o.typ==5 then
				for i=1,5 do
				 local c=o.dt\2+i-3
				 pal(i,({7,6,4})[mid(1,3,c)])
				 if (c>5) palt(i,true)
				end
				spr(204,o.x-8,o.y-8-o.dt/8,2,2)
				pal()
		 elseif o.typ==6 then
			 palt(0,false)
			 palt(5,true)
			 if dt\2%2==0 then
			  palt(0,true)
			  palt(1,true)
			  palt(3,true)
			  palt(13,true)
			 end
			 pal(3,7)
			 spr(185,o.x-12,o.y-7,3,2,o.flip)
			 pal()
		 elseif o.typ==7 then
		  --spike
				spr(238,o.x-8,o.y-7,2,2)
		 elseif o.typ==8 and swin<40 then
			 --giant ring
			 --pal(s_clr[dt\90%7+1])
			 pal(s_clr[2])
			 if (swin>0) pal(s_clr[dt\2%7+1])
			 for l=0,3 do
				 for i=0,1,0x.08 do
				  local x,y=sin(i)*sin(t()/1.5)*14,cos(i)*14
				  local r=min(5-l,5-l*2+(l>0 and sin(i+(t()-sin(t()/.75)/16-.5)/-1.5+.125)*4+4 or 0)-l)
				  circfill(o.x+x+l-r/4,o.y+y-l/2,r,3-l+dt\1%2)
				 end
			 end
			 pal()
		 end
		end
 end
 
 --sonic
 if swin==0 or swin<20 and dt%2==0 then
	 palt(0,false)
	 palt(5,true)
	 palt(3,true)
	 palt(3,false)
	 --ashura
	-- pal(2,11)
	-- pal(3,2)
	 spr_w=12
	 function upd_anim(new_anim,max_dur,anim_frames)
	  local dur=flr(max(0,max_dur-abs(sgs*2)))
	  if new_anim~=s_anim then
	   s_anim_frame=0
	   s_anim=new_anim
	  else
	   if s_anim_timer>0 then
	    s_anim_timer-=1
	   else
	    s_anim_timer=dur
	    s_anim_frame=(s_anim_frame+1)%anim_frames
	   end
	  end
	  return s_anim_frame
	 end
	 
	 spr_h=19
	 if sstate=="spin" then
	  --spinning
	  spr_index=14
	  spr_w=8
	 elseif sstate=="hurt" then
	  spr_index=232
	  spr_h=15
	 else
		 if sgs==0 then
		  --standing
		  spr_index=64
		  spr_w=8
		  upd_anim("stand",1,1)
		 elseif abs(sgs)<3 then
		  --walking
		  spr_index=({[0]=128,131,134,137,140,176,179,182})[upd_anim("walk",8,8)]
		 else
		  --running
		  spr_index=({[0]=8,11,56,59})[upd_anim("run",10,4)]
		 end
	 end
	 
	 local spmem=spr_index%16*4+spr_index\16*8*64
	 
	 for j=0,19*64,64 do
	  --remove: cleans copied area
	  memset(0x200+j,0x55,12)
	  
	  if j<=spr_h*64 then
	   memcpy(0x200+j,spmem+j,spr_w)
	  end
	 end
	
	-- for i=0,2 do
	--  for j=0,2 do
	--   mset(16+i,j,spr_index+i+j*16)
	--  end
	-- end
	 
	 --if sground then
	 if invinc%8<4 then
		 if sstate=="spin" then
		  local spin_spr=upd_anim("spin",5,8)
		  if spin_spr%2==0 then
		   rspr(136,12,13,13,sx,sy,spin_spr*(sflip and 1 or -1)/8,sflip)
		  else
		   spr(107,sx-8,sy-7,2,2)
		  end
		 elseif sstate=="crouch" then
		  spr(230,sx-8,sy-8,2,2,sflip)
		 elseif sstate=="spdash" then
			 for i=8,15 do
			  pal(i,3)
			 end
			 if dt%2==0 then
			  pal(dt\2%5+11,4)
			  pal(8,4)
			  pal(1,6)
			  pal(6,3)
			 else
			  pal(1,4)
			  pal(4,3)
			  pal(6,4)
			  pal(9,4)
			 end
			 if dt%4<2 then
			  pal(8,2)
			 else
			  palt(8,true)
			 end
			 spr(109,sx-8,sy-8,2,2,sflip)
		  dash_dust(7)
		 else
		  spr_ang=(v_sang==mid(0x.18,v_sang,0x.e8) or (abs(sgs)>=1.5) or not sground) and flr(v_sang*32)/32 or 0
		  rspr(136,12,13,13,sx,sy,spr_ang,sflip)
		 end
	 end
	 local _,acid_tile=gr_check(8,0,1)
	 if acid_tile==69 then
	  if abs(sgs)>=3 then
	   dash_dust(10)
	  else
	   s_hurt()
	  end
	 end
 end
 pal()
 palt(0,true)
 
 --rings
 for o in all(obj) do
  if o.dead>=0 and o.typ==1 then
   spr(19,o.x-4,o.y-4,1,1,o.dead%12<6,o.dead%24<12)
  end
 end
 
 --waterfalls front
 if cx<650 then
	 for i=1,4 do
	  pal(i,(-dt\8+i)%4+4)
	 end
	 for i=37,41 do
	  for j=6,12 do
	   spr(143,i*8+1,j*16,1,2)
	  end
	  spr(175,i*8+1,6.5*16-8)
	  spr(175,i*8+1,11.5*16-8)
	 end
	else
	 for i=1,4 do
	  pal(i,({11,10,13,7})[(-dt\8+i)%4+1])
	 end
	 for i=100,104 do
	  for j=4,8 do
	   spr(143,i*8+1,j*16,1,2)
	  end
	  spr(175,i*8+1,4.5*16-8)
	 end
	end
 pal()
 
 --acid
 for i=cx\8-8,cx\8+8 do
  for j=cy\8-8,cy\8+8 do
   local t=tilegrid[i][j]
   if t==69 or t==68 then
    spr(t,i*8,j*8,1,1,f,v)
   end
  end
 end
 
 --map check
-- for i=0,16 do
--	 for j=0,16 do
--	  rect(
--	  i*8,j*8,
--	  i*8+7,j*8+7,
--	  checked[i][j])
--	 end
-- end
 
 --shield
-- if (dt%120==0) curr_shield=curr_shield%7+1
 if (swin==0 and curr_shield) draw_shield(curr_shield)
 
 --debug
 --[[
 --sonic center
 pset(sx,sy,8)
 
 --ground detectors
 for i=-4,4,8 do
  --⬇️
  pset(sx+i,sy+7,0)
  --➡️
  pset(sx+7,sy+i,0)
  --⬅️
  pset(sx-7,sy+i,0)
  --⬆️
  pset(sx+i,sy+-7,0)
 end
 
 --wall detectors
 for i=-5,5,10 do
  pset(sx+i,sy,0)
 end
 
 pset(sx,sy+17,7)
 
-- if (btn(⬅️)) print("⬅️",50,40,8)
-- if (btn(➡️)) print("➡️",60,40,8)
 
-- ]]
 cursor()
 camera()
 
-- line(40,10,40+cos(sang)*10,10+sin(sang)*10,8)
-- pset(40,10,7)
 color(7)
 outline(print,2,0,"time",6,3,13)
 outline(print,2,0,"rings",6,11,rings==0 and dt%16<8 and 8 or 13)
 outline(print,2,0,tim\60 ..":"..tim\10%6 ..tim%10,26,3,7)
 outline(print,2,0,rings,38,11,7)
 --[[
 ?"∧"..stat"1"
 ?"sxs "..sxs
 ?"sys "..sys
 ?"sgs "..sgs
 ?"hlock "..hlock
 ?"mode "..smode
 ?tt
 ?t2
--]]
-- cls(2)

--sspr(({[0]=0,24,48,72,96,0,24,48})[dt\4%8],({[0]=64,64,64,64,64,84,84,84})[dt\4%8],24,20,40,40)
--sspr(({[0]=72,96,72,96})[dt\4%4],({[0]=85,85,104,104})[dt\4%4],24,20,60,40)

	
--	?"∧"..stat(1),5,20,8
--	∧∧=∧∧ or 0
--	if (dt>1) ∧∧=max(stat(1),∧∧)
--	?"\n∧max "..∧∧
	--?sstate,5,20,8
--	?"\n"..tostr(sx)
--	?"\n"..tostr(sy)
--draw user memory
--memcpy(0x6000,0x4300,0x1b00)
-- c1=btn(⬅️) and 8 or 4
-- c2=btn(➡️) and 8 or 4
-- outline(print,2,0,"⬅️",55,110,c1)
-- outline(print,2,0,"➡️",65,110,c2) 
-- ?"\n"..tostr(btn(⬆️,1))

--mouse
--if show_tilesel then
--	rectfill(0,94,127,127,2)
--	for i=0,63 do
--	 draw_tile(i%16*8,95+i\16*8,tiletyp[i+1] or 0,0,0)
--	end
--end
--pal()
--if (ramp_seq[draw_typ]) rect(mousex,mousey,mousex+31,mousey+31,8)
--draw_tile(mousex,mousey,draw_typ or 0,0,0)
--pal()
--pset(mousex,mousey,8)
--	?"w:"..tilew,5,26,8
--	?"h:"..tileh,5,32,8
 
----values 0x10 and 0x30 to 0x3f change the efffect
--poke(0x5f5f,0x10)
----new colors on the affected line
----water
--pal({0x8d,1,0x81,0x8d,0x8c,0x86,0x87,0x88,0x81,3,0x83,0x86,0x8a,0x82,0x87,2},2)
----dark
--	 pal((
--		{
--		137,129,1,
--		141,13,13,6,
--		2,130,3,131,
--		142,138,132,143,
--		4}),2)
--waterlevel=64
--scr_wlevel=64-cy\1+waterlevel
--ll=0x5f70+scr_wlevel\8
--if scr_wlevel<0 then
-- scr_wlevel=0
-- ll=0x5f70
--end
--memset(0x5f70,0,15)
--memset(ll,0xff,min(15,0x5f7f-(ll)+1))
--if (scr_wlevel>0) poke(ll,255-(2^((scr_wlevel)%8)-1))
--water waves
--if dt%2==0 then
-- for i=0,127 do
--		 rectfill(i,scr_wlevel+1,i,scr_wlevel-2-sin(i/16+t())*sin(t())*1.1,7)
--	end
--end
--	?"∧"..stat(1),5,20,8
end
-->8
--draw functs
function rspr(sx,sy,sw,sh,dx,dy,a,f)
 f=f and -1 or 1
 a*=f
 a+=.25
 local sina8=sin(a)>>3 --equivalent to sin(a)/8, but faster
 local cosa8=cos(a)>>3
 sx>>=3 --since only used as sx/8 in loop, might as well change these variables as well
 sy>>=3
 for i=-sh,sh do
  tline(dx-sh*f,dy+i,dx+sh*f,dy+i,
   sw*sina8+i*cosa8+sx,
   sw*cosa8-i*sina8+sy,
   -sina8,-cosa8,1)
 end
end

function draw_shield(c)
 --dt=2
 --curr_shield=4
 local x,y=sx,sy
 if sground then
  x+=sin(spr_ang)*3
  y+=-cos(spr_ang)*3
 end
 if dt%2==0 then
	 for i=5,1,-1 do
	  circfill(x,y,sin(i/20)*-12,s_clr[c][max(i-2,(i-dt\2)%5)])
	 end
 end
 --circ(sx,sy,12,2)
end

function pre_gfx()
 cls(2)
 rectfill(40,50,120,60,6)
 outline(
 function()
  for i=0,20 do
   srand(10+i)
   circfill(i*4+40,(rnd(30)-2)*sin(i/40)+53,(rnd(10))*-sin(i/40)+3,7)
  end
 end,6,0)
 for i=0,36 do
--  --copy sheet to user data
--  memcpy(0x4300+i*64,i*64,64)
--  --copy screen to sheet
--  memcpy(i*64,0x6000+64*55-i*128,64)
  --copy screen to user data
  memcpy(0x4300+i*64,0x6000+64*19+i*64,64)
 end
 cls(3)
 --bg hills
 for h=0,1 do
	 for c=0,1 do
		 for i=0,127 do
		  rectfill(
		  i,84+h*10+c+sin((i-c*4+h*15)/60)*(3.5-c)+sin((i+h*15)/80)*(1.5),
		  i,127,c+10)
		 end
	 end
 end
 for i=0,18 do
  --copy screen to user data
  memcpy(0x4300+i*64+37*64,0x6000+64*79+i*64,64)
 end
 --field paralax
 for i=100,127 do
  for n=0,(i-95)*4 do
   pset((rnd()*127+cx/(i-130)/2)%128,i,rnd({1,10,13}))
  end
 end
 for i=0,27 do
  --copy screen to user data
  memcpy(0x4300+i*64+56*64,0x6000+64*100+i*64,64)
 end
end

function dash_dust(c)
 for i=0,15 do
  pal(i,c)
 end
 palt(0xffff)
 palt(({0b1011110111011111,0b1010110011001111,0b1010010001000111,0b1111110000000011,0b1111111111000000})[dt\2%5+1])
  spr(228,sx-8+(sflip and 12 or -12),sy-8,2,2,sflip)
end

function draw_tile(x,y,t,i,j)
 if t>1 then
	 pal()
	 local clr,f,v=(t==20 or t>=250) and (i+j)%2 or 0
	 pal(8,clr*14)
	 if clr==1 and (t>64 or t==20) then
	  pal(15,12)
	  pal(12,1)
	  pal(1,0)
	  pal(14,9)
	  pal(9,2)
	 end
	 if t>=128 and t<222 then
	  if t%16<5 then
	   v=1
	   t=128-16+t%16-((t-128)\16)*16
	  elseif t%16<10 then
	   t=128-16-(t%16-5)+4-1-((t-128)\16)*16
	   v,f=1,1
	  else
	   t=128-16-(t%16-10)+4-1+((t-128)\16)*16-64+16
	   f=1
	  end
	 elseif t==35 then
	  f=i%2==0
	  v=j%2==1
	  if f then
	   pal(6,2)
	  end
	  if v then
	   pal(2,7)
	   pal(7,2)
	   pal(3,2)
	  else
	   pal(3,6)
	  end
	 elseif t==36 then
	  v=j>13
	 end
	 if t~=69 and t~=68 then
	  spr(t,x,y,1,1,f,v)
	 end
	end
end
-->8
function grn_coll(o,ign_semi)
 --ground collision
 max_tile=0
 local higst_gr=-8
 for i=-4,4 do
  --normal
  g_ch,tile=gr_check(7*o,i,false,ign_semi)
	 --high
	 if g_ch==8 then
	  hi_ch,htile=gr_check(-1*o,i,true,ign_semi)
	  if (hi_ch>0) g_ch,tile=8+hi_ch,htile
	 --low
	 elseif g_ch==0 then
	  low_ch,ltile=gr_check(15*o,i,true,ign_semi)
	  g_ch,tile=-8+low_ch,ltile
	 end
	 --compare highest
	 if g_ch>higst_gr
	 or g_ch==higst_gr and hi_i and abs(i)<abs(hi_i) then
	  higst_gr,hi_i=g_ch,i
	  max_tile=tile
	 end
 end
 
 local function setgrnd(n)
  local sign=(smode\2*2-1)*o
  return (n-7*sign)\8*8+higst_gr*sign+3.5+3.5*sign
 end
 
 local xgrnd=setgrnd(sx)
 local ygrnd=setgrnd(sy)
 
 if t_height[max_tile] and
 sground
 and (t_ang[max_tile]==0
 or abs(t_ang[max_tile]-sang)<.15)
 or (sy*o>=ygrnd*o
 and (smode==0 or o==-1))
 then
  local landing=not sground
	 --adjust sx sy to ground
	 if smode%2==0 then
	  sy=ygrnd
	 else
	  sx=xgrnd
	 end
	 
	 if t_ang[max_tile]~=0
	 or o==1 then
		 local _,stand_ang=gr_check(8*o,hi_i,false,ign_semi)
		 sang=t_ang[stand_ang]==0 and m_ang or t_ang[stand_ang] or sang
		 set_mode(flr((sang+0x.2)*4)%4)
   
		 local steep=-abs(-sang+.5)+.5
	  if o==1 then
			 --landing on ground
			 if landing then
			  sgs=sxs
			  --shallow is ignored (sgs=sxs)
			  if steep>0x.1 then
			   if sys>=abs(sxs) then
				   --half/full steep with ys>=xs
				   if (steep<=0x.4) then
				    sgs=sys*((steep<=0x.2) and .5 or 1)*(sgn(sin(sang)))
				   end
			   end
--				  else
--				   launch=false
			  end
			 end
			 sground=true
		 else
			 --ceiling
	   if steep<=0x.6 then
	    if sys<-1.5 then
		    sgs=sys*(-sgn(-sin(sang)))
		    sground=true
		   else
		    sang=0
		    set_mode(0)
	    end
		  else
		   if abs(sxs)>=2 then
		    --launch=true
		    sgs=-sxs
		    sground=true
		   else
		    sang=0
		    set_mode(0)
		   end
	   end
 		end
  end
	 if landing then
   if sground then
	   sstate="walk"
	  end
	  sys=0
	 end
	elseif sground then
	 --launch
	 --launch=sang>0x.4 and sang<0x.c
	 sground=false
	 sxs=sgs*cos(sang)
	 set_mode(0)
	 sang=0
 end
end
-->8
--clouds
--by bonevolt

--draw functions
function pal_all(c)
 for n=0,15 do
  pal(n,c)
 end
end

function outline(draw,c,t,...)
 local o_pal,camx,camy={},camera()
 for i=0,15 do
  o_pal[i]=pal(i,c)
 end
-- o_pal=pal()
 --t:0 normal t:1 bold
 for i=-1,1 do
  for j=-1,1 do
   if abs(i^^j)==1 or t==1 then
    camera(camx+i,camy+j)
    draw(...)
   end
  end
 end
 camera(camx,camy)
 pal(o_pal)
 draw(...)
end

--function _draw()
-- camera()
-- dt=dt or 0
-- dt+=1
-- n=n or 31
-- --if (btnp(❎)) 
-- if (dt%3==0)n+=1
-- cls()
-- for i=0,10 do
--  srand(n+i)
--  outline(circfill,12,0,i*6+40,(rnd(10)-2)*sin(i/20)+50,(rnd(10))*-sin(i/20)+3,7)
-- end
--
-- camera(0,-40)
-- outline(
-- function()
--  for i=0,10 do
--   srand(n+i)
--   circfill(i*6+40,(rnd(10)-2)*sin(i/20)+50,(rnd(10))*-sin(i/20)+3,7)
--  end
-- end,12,0)
--
-- pal(0,1,1)
-- --?stat(1),0,20,7
--end