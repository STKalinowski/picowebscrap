-- pirate's trial
-- 2020 benjamin soule

msel=0
--dev=true
function _init()
 extcmd("rec")
 t=0
 fd=0
 logs={}
 ents={}
 streak=0
 best_streak=0
 --new_game()
 new_menu()
end

function new_menu()
 ents={}
 music(0)
 fd=7
 fad(0,16)
 
 
 t=0
 dp=0
 local ce=.75
 
 sea=112
 boat_y=100
 msel=nil
 fch=nil
 
 mdr=function()
  rpal()

  -- sky
  sspr(16,80,8,8,0,0,128,max(256-t*8,128))
  -- title
  spr(1,4,min(t*2-48,6),15,3)
  
  --camera(0,-max(0,64-t*4))
  -- 
  rectfill(0,sea,127,127,12)  
  -- ecume
  foreach(ents,dre)  
  --island
  spr(163,128*ce-20,sea-8,5,2)
  -- boat
  spr(140,0,boat_y,4,4)
  --
		--camera()

  if msel then
   
   local s=names[msel+1]
   print(s,64-#s*2,30,7)
   local s=power_desc[msel+1]
   print(s,64-#s*2,37,13)
   
   local s="choose your pirate"
   print(s,64.5+cos(t/60)*8-#s*2,87,15)
   
   if fch then fch+=1 end
   
   for i=0,2 do
    local x=8+i*40
    local y=48
    local cl=13
    if msel==i then
     cl=sget(t%8,1)
    end
    
    if (msel==i or not fch or t%2==0) and (not fch or fch<32 or msel==i ) then
    
	    rectfill(x-2,y-2,x+33,y+33,cl)
	    rectfill(x,y,x+31,y+31,1)
	    palt(0,false)
	    palt(11,true)
	    spr(192+i*4,x,y,4,4)   
	    palt(0,true)
	    palt(11,false)
    end
      
   end
   
  
  else
   local vis=blk and (t%2==0) or (t%24<12)
	  if vis then
	   print("press ❎ to start",28,48,7)
	  end
	  
	  local sa="current streak..."..streak
	  local sb="best streak......"..best_streak
	  print(sa,26,65,14)
	  print(sb,26,73,14)
	  
	  if t>27 then
	   local s="the scavenger hunt"
	   for i=1,#s do
	    print(sub(s,i,i),(i-1)*4+62-#s*2,28,13)
	   end   
	  end
	  
	  
	 end
  
 end


	
	
	local tp=200
	
	
 for i=0,64 do
 
  local e=mke()
  e.cx=rnd()
  e.t=rnd(tp)
  
  e.upd=function()
   local c=e.t/tp
   c=c^4
   e.ox=e.x
   e.oy=e.y
   e.x=128*ce+(e.cx-.5)*(128*(.1+c)*4)  
   e.y=sea+c*32
   
   if e.t>tp then
    e.t-=tp
    e.x=nil
    e.y=nil
   end
  end  
  e.dr=function(e,x,y)
   --pset(x,y,7)
   if e.ox and e.x then
    line(e.x,e.y,e.ox,e.oy,7)
   end
  end 
  
 end
  
  
 loop(upd_menu)
 
end

function upd_menu()
 sea=112+cos(t/120)*4 
 boat_y=104+cos(t/120+.2)*8
 
 if msel then
  mt+=1
  
  if not fch then
	  function inc(n)
	   msel=(msel+n)%3
	   sfx(15)
	  end
	  if btnp(0) then inc(-1) end
	  if btnp(1) then inc(1) end
	  if btnp(4) or btnp(5) then
	   sfx(16)
	   fch=0
	   local f=function()
	    fad(6,8,new_game)
	   end
	   wt(32,f)
	  end
  end
 else
  if not blk then
	  if btnp(4) or btnp(5) then
	   sfx(16)
	   music(-1,2000)
	   blk=16
	  end
	 else
	  blk-=1
	  if blk==0 then
	   blk=nil
	   msel=0
	   mt=0
	  end
	 end
 end
 
end










function new_game()
 
 mdr=dr_game 
 scores={0,0,0}
 round=0
 reset_isle()
 
 --clues=all_clues
 
end


function reset_isle()
 round+=1
 ents={}
 actors={} 
 clues={}
 boats={}	
	boats_timing={8,36,80}
	--boats_timing={1,8,16}
 shores={0,1,2,3}
 
 monkey=nil
 winner=nil
 frz=false
 turns=0 
 fd=0
 t=0
 
 -- grid
 grid={}
 for x=0,15 do for y=0,15 do
  local sq={ 
   x=x,y=y,k=2,
   nei={},wnei={},fnei={},
   path={0,0,0},visited={}
  }
  add(grid,sq)
  -- scan map
  local ms=mget(x,y)
  if fget(ms,4) then sq.k=0 end
  if fget(ms,7) then sq.k=1 end
  if fget(ms,5) then sq.k=3 end
  if fget(ms,1) then sq.k=4 end
  if fget(ms,0) then sq.k=5 end
  if fget(ms,2) then sq.k=6 end
  sq.r=rnd()
  sq.rr=rnd()
  
  sq.tl=ms
 end end
 for sq in all(grid) do
  for i=0,7 do
   local nx=sq.x+di[1+i*2]
   local ny=sq.y+di[2+i*2]
   local nsq=gsq(nx,ny)
   nsq=nsq or -1
   add(sq.nei,nsq)
  end
 end

 -- actors 
 mk_hut(9,1)
 mk_hut(7,8)
 mk_hut(12,12) 
 mk_palm(2,11)
 --mk_palm(3,2)
 mk_palm(1,3)
 mk_palm(10,7) 
 
 mk_monkey(2,1)

 
 -- players
 players={}
 
 function chk(sq)
 	if sq.k==4 or not chk_clue(sq,1,0) then
 	 return false
 	end
  for p in all(players) do
   if abs(sq.x-p.px)<4 and abs(sq.y-p.py)<4 then
    return false
   end  
  end
  return true
 end
 
 for i=0,2 do
  
  local pid=i 
  local sq=get_free_sq(chk)
  if pid==1 then
   sq=gsq(8,7)
  end
  
  local e=mka(-1,sq.x,sq.y)
  e.pnum=i
  e.pid=pid
  e.dr=dr_pirate
  e.clues={}
  e.shovel=pid==0
  add(players,e)  
  e.ia=i!=msel  
 end
 
 hero=players[msel+1]
 clues=hero.clues
 hero.upd=upd_hero
 hero.⧗show=80
 
 
 -- bury treasure
 local sq=get_free_sq()
 --log(sq.x..";"..sq.y)
 bury_it(sq)
 
 
 -- build walk path
 build_walk_path() 
 updpath()
 
 -- fade in
 fd=6
 fad(0,8)
 

 --test_double_tiles()
 

end



function build_walk_path()
 for sq in all(grid) do
  sq.wnei={}
  sq.fnei={}
 end
 
 

 for sq in all(grid) do
  for i=0,3 do
   local nx=sq.x+di[1+i*2]
   local ny=sq.y+di[2+i*2]
   local nsq=gsq(nx,ny)
   
   -- jump cliff
   local cjmp=(nsq.k==5 and i==1) or 
  																		(fget(sq.tl,1) and not fget(nsq.tl,1) and i!=3)				 
   if cjmp then
    nsq=gsq(nx,ny+1)
   end   
   
   -- sea hut and palm
   local blk=nsq.k==0 or nsq.k==7 or nsq.k==8
   local mblk= not fget(sq.tl,1) and fget(nsq.tl,1) and not fget(sq.tl,2)
   local cblk= fget(nsq.tl,0)   
   osq=nsq   
   if blk or mblk or cblk then    
    nsq=nil
   end  
   add(sq.wnei,nsq or -1)
   
   if osq.cl and not mblk and not cblk and not cjmp then
    nsq=osq
   end
   
   if nsq then
			 add(nsq.fnei,sq)
   end
   
  end
 end

end


function build_path(e)
 --[[
 if gr and gr>50 then return end
 log("!!")
 if not gr then gr=0 end
 gr+=1
 --]]
 
 --log(rand(4))
 local huts={}
	for sq in all(grid) do
  sq.tmp=99  
  if sq.cl and not has(e.clues,sq.cl) then
   add(huts,sq)
  end  
 end


 function seek(a,start)
  local work={}
	 for sq in all(a) do
	  if sq.tmp>=start then
	   sq.tmp=start
	   add(work,sq)
	  end
	 end	 
	 while #work>0 do
	  local sq=work[1]
	  del(work,sq)
		 for nsq in all(sq.fnei) do
	   if nsq.tmp>sq.tmp+1 then
	    nsq.tmp=sq.tmp+1
	    add(work,nsq)
	   end
	  end 
	 end
 end 
 
 -- seek
 seek(huts,0)

 if e.shovel then -- seek bury spots
  local a=bury_spots(e.clues)
  seek(a,#a-8)  
 elseif shovel then -- seek shovel 
  ssq=gsq(shovel.px,shovel.py)
  seek({ssq},-5)
 end
 

 -- register results
 for sq in all(grid) do
  sq.path[e.pid+1]=sq.tmp  
 end
 

end

function bury_spots(clues)
 local a={}
 for sq in all(grid) do
  local ok=not sq.dirt and is_spot(sq)
  for cl in all(clues) do
   ok=ok and chk_clue(sq,cl.y,cl.k)
  end
  if ok then add(a,sq) end
 end
 return a
end



function bury_it(sq)

	deck={}
	all_clues={}
 ships_clues={}

 tsq=sq
 tsq.treasure=true

 -- build deck
 for k=0,8 do 
  local acl={0,1}  

  if k>=1 and k<=4 then   
   add(acl,5)
  else
   add(acl,2)
	  if k>=6 then
	   add(acl,3)
	  end     
   add(acl,4)
  end  
  for cl in all(acl) do
   if chk_clue(tsq,cl,k) then
    local cl={y=cl,k=k}
    add(deck,cl)
    add(all_clues,cl)
    break
   end   
  end  
 end 
 
 -- sort deck
 ysort(deck)
 
 -- dispatch clues
 for sq in all(grid) do
  if sq.k==7 then
   sq.cl=draw_clue()
  end
 end 
 
 -- ships
 for i=0,2 do
  add(ships_clues,draw_clue())
 end
 for pl in all(players) do
  if pl.pid==2 then
   add(pl.clues,ships_clues[3])
  end
 end
 
 
 -- monkey
 if monkey then
  
  local a={}
  if tsq.x>=8 then
   add(a,0)
  else
   add(a,2)
  end
  if tsq.y>=8 then
   add(a,1)
  else
   add(a,3)
  end
  
  gsq(monkey.px,monkey.py).cl={y=10,k=arand(a)}
  
 
 
 end
 
 
end

function draw_clue()
 
 local c=rnd(.6)
 local cl=deck[flr(c*#deck)+1]
 
 
 
 del(deck,cl)
 return cl 
end

function steal(a)
 local n=arand(a)
 del(a,n)
 return n
end

function fad(n,tempo,nxt) 
 local sn=fd 
 local f=function(e) 
  fd=sn+(n-sn)*e.t/tempo
 end 
 loop(f,tempo,nxt)
end


function chk_clue(tsq,cl,k)

	 --0-- inside
	 if cl==0 then
	  return k==tsq.k
	 end
	  
	 --1-- near
  if cl==1 then
   return is_near(tsq,k)
  end
  
  --2-- one_away
  if cl==2 then
   return is_one_away(tsq,k)
  end
  
  --3-- in sight
  if cl==3 then
   return in_sight(tsq,k)
  end
  
  --4-- not near
  if cl==4 then
   return not is_near(tsq,k)
  end
  
  --5-- not inside
  if cl==5 then
   return tsq.k != k
  end
  
  
  --10-- map side
  if cl==10 then
   if k==0 then return tsq.x>=8 end
   if k==1 then return tsq.y>=8 end
   if k==2 then return tsq.x<8 end
   if k==3 then return tsq.y<8 end
  end

end 

function is_near(sq,k)
 if sq.k==k then 
  return false
 end
 for nsq in all(sq.nei) do
  if nsq.k==k then
   return true
  end
 end
 return false 
end

function is_one_away(sq,k)
 if sq.k==k then 
  return false
 end
 for i=0,3 do
  local nx=sq.x+di[1+i*2]*2
  local ny=sq.y+di[2+i*2]*2
  if is_in(nx,ny) and gsq(nx,ny).k==k then
   return true
  end
 end
 return false 
end

function in_sight(sq,k)
 for i=0,3 do
 	for n=3,15 do
	  local x=sq.x+di[1+i*2]*n
	  local y=sq.y+di[2+i*2]*n
	  if not is_in(x,y) then
	   break
	  else
	   if gsq(x,y).k==k then
	    return true
	   end
	  end
 	end
 end 
 return false
end

function is_in(x,y)
 return x>=0 and x<16 and y>=0 and y<16
end

function get_free_sq(chk)

 if not chk then
  chk= function(sq)
    return true
  end
 end


 local a={}
 for sq in all(grid) do
  if is_spot(sq) and chk(sq) then
   add(a,sq)
  end
 end
 return arand(a)
end

function is_spot(sq)
 return sq.k>=1 and sq.k<=4
end


function arand(a)
 return a[1+rand(#a)]
end

function rand(n)
 return flr(rnd(n))
end

function gsq(x,y)
 return grid[1+(x%16)*16+(y%16)]
end


function mk_monkey(px,py)
 monkey=mka(178,px,py) 
 monkey.z=-4
 monkey.float=true
 gsq(px,py).k=10
end

function mk_hut(px,py)
 local e=mka(85,px,py)
 e.dry=-4
 e.hh=10
 local sq=gsq(px,py)
 sq.k=7 
end
function mk_boat(px,py,di)
 local e=mka(0,px,py)
 e.bdi=di
 add(boats,e)
 gsq(px,py).k=9
 
 e.dr=function(e,x,y) 
  local wy=gsl(e.px,e.py)-2.5
  local ww=12/8
  local hh=11/8
  if fd==0 then
	  apal(13)
	  spr(160,x-2,y+wy,ww,hh)
	  rpal()
  end
  
  clip(x-cmx-2,y-cmy-4,16,10)
  spr(160,x-2,y+wy,ww,hh)
  clip()  
 end
 
end

function rpal()
 if fd>0 then
  for i=0,15 do
   pal(i,sget(56+i,32+fd))
  end
 else
  pal()
 end
end


function mk_palm(px,py)
 local e=mka(0,px,py)
 local psq=gsq(px,py)
 psq.k=8
 psq.act=e 
 e.vl=0
 e.da=0 
 
 e.dr=function(e,x,y) 
  local an=e.da+.25 + sin(e.t/80)*.02
 	
 	local sx=e.x+3
 	local sy=e.y+6
 	local ex=sx+cos(an)*10+.5
 	local ey=sy+sin(an)*10+.5 
  for i=0,1 do  	
   tline(sx+i,sy,ex+i,ey,16,0.5)
  end 
  spr(81,ex-7,ey-4,2,1)
 end
 

 
 e.upd=function(e)
  e.da+=e.vl
  e.vl+=-e.da*.1
  e.vl*=.92
 end
 

end

function kick_palm(e,sq)
 -- patch
 if not sq.act then
  return
 end
 
 sq.act.vl=(e.px<sq.x and -1 or 1)/20
end


function upd_hero(e)

 if not anybut() then
  ready=true
 end

 if frz or not ready then
  return
 end
 
 
 
 if     btn(0) then hmov(2) 
 elseif btn(1) then hmov(0)
 elseif btn(2) then hmov(3)
 elseif btn(3) then hmov(1)
 elseif btn(4) then 
  if #clues>0 then
	  frz=true
	  fad(3,8,show_maps)
  else
   sfx(17)
   ready=false
  end
 elseif btn(5) and hero.shovel then
  frz=true
  dig(hero,gsq(hero.px,hero.py))
  wt(4,play)
 else
 
 
 end
 
end

function show_maps()
 
 local k=0
 local maps={}
 for cl in all(clues) do 
  local e=mkc(cl) 
  e.x=44+rnd()--2+(k%3)*42
  e.y=44+rnd()--2+flr(k/3)*42
  e.dp=1
  k+=1
  add(maps,e)
 end  
 

 
 function place(ev)
  local r=40
  for i=1,#maps do for j=i+1,#maps do
   local a=maps[i]
   local b=maps[j]
   local dx=a.x-b.x
   local dy=a.y-b.y
   if abs(dx)<r and abs(dy)<r then
    local an=atan2(dx,dy)
    local dd=(r-sqrt(dx*dx+dy*dy))/2
    if dd>0 then
     a.x+=cos(an)*dd
     a.y+=sin(an)*dd
     b.x-=cos(an)*dd
     b.y-=sin(an)*dd
    end   
   end  
  end end 
  for m in all(maps) do
   m.x=mid(0,m.x,88)
   m.y=mid(0,m.y,88)
  end
 end
 pll=loop(place)
 
 function lv()
  for m in all(maps) do
   kl(m)
  end
  kl(pll)
  fad(0,8)  
  play()
  ready=false
 end
 
 on_anybut(lv)
 
 
end


function hmov(di)
 
 local jmp=3

	local hsq=gsq(hero.px,hero.py)
	local nsq=hsq.wnei[di+1]
	local dsq=hsq.nei[di+1]
	
	
	-- check trig
 if dsq.cl and fget(dsq,1)==fget(hsq,1)  then
  trig(dsq)
	 return
	end

	--
	if nsq==-1 or not nsq then	
  frz=true
  hero.jmp=2
  moveto(hero,dsq.x*8,dsq.y*8,6,play)
	 hero.twcv=function(c)
	  return -sin(c/2)*.25
	 end
	 sfx(6)	 
	 if dsq and dsq.k==8 then
	  kick_palm(hero,dsq)
	 end	 
	 return
	end
	
	
	--


 -- sfx
 local f=function()
	 local n=1
	 if fg(hero,5) then n=2 end
	 if fg(hero,5) then n=2 end
	 if fg(hero,7) then n=3 end
	 if nsq.dirt then n=1 end
	 sfx(n)
	 play()
 end
 wt(8,f)
 -- move
 frz=true
 pmov(hero,nsq)
	play_all()
   
 
 
end




function trig(sq)
 frz=true
 fad(3,8)
 sfx(7)  
 
 local e=mkc(sq.cl)
 e.dp=1
 e.x=44
 e.y=128 
 moveto(e,e.x,44,8) 
 
 local inst=mke() 
 inst.dp=1
 inst.dr=function(e)
  local s=""
  if sq.cl.y==10 then
   s="search chest in the "..dir_names[sq.cl.k+1].."..."
  else
	  s=instructions[sq.cl.y+1]
	  s=s..el_names[sq.cl.k+1]
	  
  end
  
  print(s,64-#s*2,128-(fd*3),7)
 end
 
 
 function lv()
  kl(inst)
  kl(e)  
 end 
 
 function go()
  ready=false
 	play()
  fad(0,8)
  moveto(e,e.x,128,8,lv)			 
	 if not has(clues,sq.cl) then
	  add(sq.visited,hero.pid)
	  add(clues,sq.cl)
	 end
 end
 on_anybut(go) 

end




function on_anybut(nxt)
 ready=false 
 function ctrl(ev)
  if anybut() then
   if ready then
	   kl(ev)
	   nxt()
   end
  else
   ready=true
  end
 end 
 loop(ctrl)


end

function has(a,v)
 for n in all(a) do 
  if v==n then return true end
 end
 return false
  
end

function anybut()
 local ok=false
 for i=0,5 do ok=ok or btn(i) end
 return ok
end


function mkc(cl)


 local e=mke(0)
 e.mdx=rnd()
 e.mdy=rnd()
 e.⧗fold=8
 
 e.dr=function(e,x,y)
 
  if e.⧗fold then 
   local c=e.⧗fold/8
   local n=flr(20*c*c)  
   clip(x+n,y+n,40-n*2,40-n*2)
  end
 
 
  x+=.5+cos(t/(80+e.mdx*80))*2
  y+=.5+sin(t/(80+e.mdy*80))*2
 
  map(16,1,x,y,5,5) 
  function tl(n,dx,dy,ddx,ddy)
   ddx=ddx or 0
   ddy=ddy or 0
   spr(n,x+(dx+1)*8+ddx,y+ddy+(dy+1)*8)
  end  
  local n=144+cl.k  
  if cl.y==0 then
   tl(n,0,0) tl(n,1,0)   tl(n,2,0)
   tl(n,0,1) tl(128,1,1) tl(n,2,1)
   tl(n,0,2) tl(n,1,2)   tl(n,2,2)
  elseif cl.y==1 then
   tl(128,0,1,4) tl(n,1,1,4)
  elseif cl.y==2 then
   tl(128,0,1) tl(130,1,1) tl(n,2,1)
  elseif cl.y==3 then
   tl(128,0,1) tl(131,1,1) tl(n,2,1)
  elseif cl.y==4 then
   tl(129,0,1,4) tl(n,1,1,4)
  elseif cl.y==5 then
   tl(n,0,0) tl(n,1,0) tl(n,2,0)
   tl(n,0,1) tl(129,1,1) tl(n,2,1)
   tl(n,0,2) tl(n,1,2) tl(n,2,2)
  elseif cl.y==10 then
   local ff={0,1,0,1, 0,0,1,1, 1,0,1,0, 1,1,0,0 }

  
   for i=0,3 do   
    local x=i%2
    local y=flr(i/2)
    local fr=74-ff[1+cl.k*4+i]
    if fr==73 then
     fr+=(flr(t/4)%3)*16
    end
    tl(fr,x+1,y,0,4)    
   end
    tl(128,0,1,-4)
   
   
   
  
  end  
  clip()  
 end
 return e

end


function updpath()
 for p in all(players) do
	 build_path(p)
	end
end

function pmov(e,to)
 local tempo=6 
 local jmp=3 
 local ptx=to.x
 local pty=to.y
 local from=gsq(e.px,e.py)

 
 -- shovel
 if shovel and not e.shovel and shovel.px==ptx and shovel.py==pty then
  kl(shovel)
  shovel=nil
  e.shovel=true
  sfx(12)
  updpath()
 end
 
 -- jump 
 if fget(from.tl,1) and not fget(to.tl,1) then
  jmp=10
  tempo=12
  sfx(5) 
 end 
 
 
 e.px=ptx
 e.py=pty  
 moveto(e,ptx*8,pty*8,tempo,nxt)
 e.jmp=jmp
 if to.x!=from.x then
  e.flx=to.x>from.x
 end
end



function play() 
 
 if winner then
  return
 end
 frz=false
 ysort(ents)
 
 if not shovel then
 	for p in all(players) do
	  if not p.shovel then
	   local sq=get_free_sq()
	   shovel=mka(126,sq.x,sq.y)
	   shovel.float=true
	   shovel.brd=1
	 		updpath()
	   break
	  end
	 end
 end
 
 
 
end

function play_all()
 turns+=1
 
 --ia
 for e in all(players) do 
  if e.ia then
   play_ia(e) 
  end
 end	
 
 --boats

 if turns==boats_timing[1] then
  
  del(boats_timing,boats_timing[1])
  local sh=steal(shores)

  local bps=boats_pos[sh+1]  
  local x=sh<2 and -2 or 17
  local y=arand(bps)
  if sh%2==1 then
   x,y=y,x
  end
  
  mk_boat(x,y,sh)
  --log("mk_boat"..x..","..y..","..sh)
  

 end
 
 
 for b in all(boats) do
 	local dx=di[b.bdi*2+1]
 	local dy=di[b.bdi*2+2]    
 	local nx=b.px+dx
 	local ny=b.py+dy
  local nsq=gsq(nx,ny)
  if nsq and nsq.k>0 and is_in(nx,ny) then
   -- 
   local sq=gsq(b.px,b.py)
   sq.k=8  
   --sq.cl=draw_clue()
   sq.cl=ships_clues[1]
   del(ships_clues,sq.cl)
   
   del(boats,b)
   updpath()
   build_walk_path()
  else   
   b.px+=dx
   b.py+=dy   
   moveto(b,b.px*8,b.py*8,16)
  end
 end
	  
end

function play_ia(e)
 
 --build_path(e)
 --
 local sq=gsq(e.px,e.py)
  
 -- get_clue 
 for i=1,4 do
  local nsq=sq.nei[i]
  if nsq.cl and not has(e.clues,nsq.cl) then
   add(nsq.visited,e.pid)
   grab_clue(e,nsq.cl)
   return
  end
 end
 
 -- dig
 if e.shovel then
  local a=bury_spots(e.clues)  
  if #a<turns/2 then
	  for dsq in all(a) do
	   if dsq==sq then
	    dig(e,sq)
	    return
	   end
	  end 
  end 
 end
 
 -- wander
 if rand(6+streak*2)==0 then
  local a={}
	 for nsq in all(sq.wnei) do 	
	  if nsq!=-1 and no_one_at(nsq) then
	   add(a,nsq)
	  end
	 end
	 if #a>0 then
	  pmov(e,arand(a))
	  return
	 end
 end 
 
 -- move  
 local best=nil  
 for nsq in all(sq.wnei) do 	
  if nsq!=-1 and no_one_at(nsq) and (not best or best.path[1+e.pid]> nsq.path[e.pid+1]) then
   best=nsq
  end
 end
 if best then
  pmov(e,best)
 end
end

function no_one_at(sq)
 for pl in all(players) do
  if sq.x==pl.px and sq.y==pl.py then
   trace("here")
   return false
  end
 end
 return true
end


function grab_clue(p,cl)
 add(p.clues,cl)
	build_path(p)
 sfx(7)
 
 --show(p,111)

end

function show(p,fr,life)
 local e=mke(fr,p.x,p.y)
 e.x=p.x
 e.y=p.y+24
 e.blk=8
 e.life=life or 32
 e.dry=-24
 e.⧗rainbow=32
 move(e,0,-8,16)
end


function dig(e,sq)
 sfx(8)
 sq.dirt=true
 e.shovel=nil
 updpath()
 
 if sq==tsq then
  winner=e
  wt(6,new_treasure)
 end
 
 for i=0,3 do
  local e=mke(185,e.x+rnd(8),e.y+rnd(y))
  local d=8
  local an=.125+i/4
  move(e,cos(an)*d,sin(an)*d,8+rnd(8),function() kl(e) end )
  e.jmp=2+rnd(4)
 end
 
 
end
function wt(t,f,a,b,c)
 local e=mke()
 e.life=t
 e.nxt=function() f(a,b,c) end
end

function new_treasure() 
 
 sco=scores[winner.pnum+1]
 sfx(11)
 scores[winner.pnum+1]=sco+1
 show(winner,127,60)
 wt(64,show_score)
 
end

function show_score()
 
 local f=function()
	 sfx(9+sco)
	 local e=mke()
	 e.dp=1
	 e.dr=dr_score
	 
	 local lim=96
	 if sco==1 then	  
	  if not winner.ia then
	   streak+=1
	   best_streak=max(best_streak,streak)
	  else
	   streak=0
	  end
	  lim=128
	 end
	 
	 e.upd=function()
	  if e.t>lim then
	   kl(e)
	   fad(5,8,sco==1 and new_menu or reset_isle)
	  end
	 end 
 end
 
 fad(5,8,f)
end

function dr_score(e)
 local ⧗=e.t
 
 for i=0,1 do
  local s=i*2-1
  local x=(⧗*s)%16-16
  local y=i*120
  map(0,16,x,y,18,1)
  
  
  
 end
 
 for p in all(players) do   
  local i=p.pnum
  --local x=min(⧗*4-32-8*i,8)
  local x=8
  local y=12+i*36  
  palt(0,false) 
  palt(11,true)
  spr(192+p.pid*4,x,y,4,4,true)
  palt(0,true)
		palt(11,false)
		
  local score=scores[p.pnum+1]

  for k=1,score do
   
   local tx=x+k*40
   local ty=y
   if k==score and p==winner then
    tx+= max(64-⧗*4,0)
   end
   
   if score==2 and ⧗>8 then
    ty+=cos(⧗/40+k/3)*min((⧗-8)/4,4)
   end
   
   if t%8<4 and winner==p and sco==1 then
    apal(7)
   end
   spr(204,tx,ty,4,4)
   pal()    
  end
    
 end 

end



function dr_aura(fr,x,y,cl)
 if fd>0 then return end
 apal(cl)
 for i=0,3 do
  spr(fr,x+di[i*2+1],y+di[i*2+2])
 end 
 rpal()
end

function apal(cl) 
 for i=0,15 do pal(i,cl) end
end


function ysort(a)
 for i=1,#a do
  local j = i
  while j > 1 and a[j-1].y > a[j].y do
   a[j],a[j-1] = a[j-1],a[j]
   j = j - 1
  end
 end
end


function loop(f,t,nxt)
 local e=mke(0)
 e.upd=f
 e.life=t
 e.nxt=nxt
 return e
end


function fg(e,f)
 return fget(mget(e.px,e.py),f)
end


function dr_pirate(e,x,y)
	local fr=137+e.pid*16	
	local hsq=gsq(e.px,e.py)
	
	-- shade
	local sy=y-e.z
	--ovalfill(x,sy+6,x+8,sy+8,1)
 local bx= e.flx and x or x-1
	for sx=bx+2,bx+6 do for sy=sy+6,sy+7 do
	 local p=pget(sx,sy)
	 
	 pset(sx,sy,sget(56+p,33))
	end end
	
	
	-- herbs
	local herbs=fg(e,5) and not hsq.dirt
	if herbs then
	 spr(64,e.px*8,e.py*8)
	end
	--[[
	if fg(e,5) and not hsq.dirt then	
	 clip(x-8,e.py*8-24,24,28)
	end
	--]]
	
	-- shovel
	if e.shovel then
	 local shx=e.flx and 6 or -6 
	 spr(126,x+shx,y-1,1,1,not e.flx,true)
	end
	
	-- body
 local bfr=fr+1
 if e.jmp then bfr+=1 end 
 spr(bfr,x,y,1,1,e.flx)
 
 -- head
 local hdx=e.flx and 1 or -1 
 spr(fr,x+hdx,y-2,1,1,e.flx)
 
 --
	if herbs then	
	 --clip(x-8,e.py*8-24,24,28)
	 spr(88,e.px*8,e.py*8)
	end 
 --
 clip()
 
end




function mka(fr,px,py)
 local e=mke(fr,px*8,py*8)
 e.px=px
 e.py=py
 add(actors,e)
 return e
end

function mke(fr,x,y)
 local e={
  x=x or 0,
  y=y or 0,
  z=0,
  fr=fr or 0,
  ww=8,hh=8,
  t=0,dp=0,
 }
 add(ents,e)
 return e
end

function upe(e)
 e.t=e.t+1
 if e.upd then e.upd(e) end
 
 -- tweening
 if e.twc then tween(e) end
 
 -- life
 if e.life then
  e.life-=1
  if e.blk and e.life<e.blk  then
   e.invis=t%2==0
  end  
  if e.life<=0 then
   kl(e)
   if e.nxt then
    local f=e.nxt
    e.nxt=nil
    f()
   end
  end
 end
 
 -- counters
 for v,n in pairs(e) do
  if sub(v,1,1)=="⧗" then
   n-=1
   if n<=0 then
    e[v]=nil
   else
    e[v]=n
   end
  end
 end  
 
end

function kl(e)
 del(ents,e)
 del(actors,e)
end

function dre(e)
 if e.dp!=dp or e.invis then
  return
 end
 local x=e.x
 local y=e.y
 if e.y then y+=e.z end
 local fr=e.fr
 
 if e.dry then y+=e.dry end
 
 if e.float then
  y+=cos(e.t/32)-.5
 end
 
 if e.⧗rainbow or e.rainbow then
  dr_aura(fr,x,y,8+(t/2)%8)
 end
 

 
 if e.brd then
  dr_aura(fr,x,y,e.brd)
 end
 
 if fr>0 then 
  spr(fr,x,y,e.ww/8,e.hh/8)
 end
 if e.dr then
  e.dr(e,x,y)
 end
 
 if e.⧗show then
  spr(133,x,y+cos(t/8)-7.5 )
 end
  
end




function _update()
 --log(#ents)



 t+=1
 foreach(ents,upe)
 --logs={}
 --log(hero.px..","..hero.py)
 --[[
 if hero then
  logs={}
  log(hero.px..","..hero.py)
 end
 --]]
 
end


function dr_game()
 --cls(12)
 camera()
	rpal()
	rectfill(0,0,127,127,12)
	--
	cmx=(hero.x-64)/4
	cmy=(hero.y-64)/4
	camera(cmx,cmy)
 --
 map(0,0,0,0,16,16)
 
 -- holes & waves
 for sq in all(grid) do
  if sq.dirt then
   spr(110,sq.x*8,sq.y*8)
  end
  
  if sq.k==5 and sq.nei[2].k==0 then
   --spr(71,sq.x*8,sq.y*8)
    local x=sq.x*8
    local y=sq.y*8
    local sy=5.5+gsl(sq.x,sq.y)*2
    rectfill(x,y+sy,x+7,y+7,7)
    rectfill(x,y+sy+1,x+7,y+7,13)
  end 
  if sq.k==0 and sq.rr<.2 then
   local x=sq.x*8
   local y=sq.y*8+5.5+gsl(sq.x,sq.y)*2
   local ln=cos(t/120+sq.r)*6
   if ln>0 then
     line(x+4-ln/2,y,x+4+ln/2,y,7)
   end
  end
   
  
  
 end
 
 -- ents
 dp=0
 foreach(ents,dre)
 
 -- visited 
 for sq in all(grid) do
  local i=0
  for n in all(sq.visited) do
   local x=sq.x*8+i*3
   local y=sq.y*8+cos(t/40+i/3)-4.5
   rectfill(x-1,y-1,x+2,y+2,7)
   rectfill(x,y,x+1,y+1,sget(n,0))
   i+=1
  end
 end


 
 
 -- show treasure
 if dev and btn(5,1) and t%2==0 then
  spr(127,tsq.x*8,tsq.y*8) 
 end
 
 -- inter
 camera()
 pal()
 dp=1
 foreach(ents,dre)
 
 for i=1,#clues do
  spr(111,127-i*10,118.5+cos(t/40+i/4)+fd*4)
 end
 
 -- round
 if t<32 then
  local y=min(-sin(t/64)*32-14,2)
  print("round "..round,51,y+1,1)
  print("round "..round,50,y,7)
 end
 
 --
 if dev and btn(4,1) then
  test_path(1)
 end
 
 --
 
 --[[ chk grid
 for sq in all(grid) do
  local x=sq.x*8
  local y=sq.y*8
  rectfill(x,y,x+2,y+2,8+sq.k)
 end
 --]]
 
 -- show double groups
 local n=0
 for g in all(dgr) do
  for sq in all(g) do  
   circfill(sq.x*8+3,sq.y*8+3,3,1)
   circfill(sq.x*8+3,sq.y*8+3,2,8+n)
  end
  n+=1
 end
end



function _draw()
 
 mdr() 
 
 -- log
 camera(0,0)
 cursor(0,0)
 color(8)
 for l in all(logs) do
  print(l)
 end

end

function log(str)
 add(logs,str)
 while #logs>20 do
  del(logs,logs[1])
 end
 
end

di={1,0,0,1,-1,0,0,-1,1,1,-1,1,-1,-1,1,-1}

boats_pos={
 {4,5,7,10,11,12,14}, 
 {4,5,6,12,13}, 
 {5,6,7,8,9,10,11,12},
 {3,4,5,6,7,8},
}

names={
 "petrus g.edward",
 "blood lilly",
 "ginger kent",
}

instructions={
 "chest is inside ",
 "chest is near ",
 "chest is one square away from ",
 "chest is in sight of ",
 
 "chest is not near ",
 "chest is not inside ",
}

power_desc={
 "start with a shovel",
 "start on the mountain",
 "start with the last ship map",
}

dir_names={
 "east","south","west","north"
}

el_names={
 "the sea",
 "the beach",
 "the plain",
 "the high grass",
 "the mountain",
 "a cliff",
 "a ladder",
 "a hut",
 "a palm",
}

-->8
-- tweening
function move(e,dx,dy,n,f)
 moveto(e,e.x+dx,e.y+dy,n,f)
end

function moveto(e,tx,ty,n,f)
 
 e.sx=e.x
 e.sy=e.y
 e.ex=tx
 e.ey=ty
 e.twc=0
 e.tws=n
 e.twf=f 
 if n<0 then
  local dx=hmod(e.ex-e.sx)
  local dy=e.ey-e.sy
  local dd=sqrt(dx^2+dy^2)
  e.tws=-dd/n
 end
end

function tween(e)
 local c=min(e.twc+1/e.tws,1)
 cc=e.twcv and e.twcv(c) or c
 e.x=e.sx+(e.ex-e.sx)*cc
 e.y=e.sy+(e.ey-e.sy)*cc
 if e.jmp then   
  --e.y+=sin(c/2)*e.jmp
  e.z=sin(c/2)*e.jmp
 end  
 e.twc=c  
 if c==1 then
  e.twc=nil
  e.jmp=nil
  e.twcv=nil
  local f=e.twf
  if f then
   e.twf=nil
   f()
  end
 end
end
-->8
-- dev

function test_path(i)
 for sq in all(grid) do
  print(sq.path[1+i],sq.x*8,sq.y*8,7)
  
 end

end



function test_double_tiles()
 local spots={}
 for sq in all(grid) do
  if sq.k>=1 and sq.k<=4 then
   add(spots,sq)
  end
 end
 
 local mp={} 
 for sq in all(spots) do 
  clues={}
  bury_it(sq)
  local s=""
  for i=0,8 do
   s=s..all_clues[i+1].y
  end
  if not mp[s] then
   mp[s]={}
  end
  add(mp[s],sq)
 end
 
 
 dgr={}
	for k, v in pairs(mp) do
	  if #v>1 then
	   add(dgr,v)
	  end
	end
 
end


function log_clues()
 for cl in all(clues) do 
  log("cl:"..cl.cl.." k:"..cl.k)
 end
end


-->8
-- tools
function gsl(x,y)
 
 return cos(t/80+x/16+y/128)

end