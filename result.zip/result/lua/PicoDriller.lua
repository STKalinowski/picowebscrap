-- pico driller 
-- by @johanpeitz & @johanvinet
-- demake of the namco classic

-- internal data structs
_glyphs,_kerning={},{}
_alphabet="  ! \" # $ % & ' ( ) * + , - . / "..
     "0 1 2 3 4 5 6 7 8 9 : ; < = > ? "..
     "@ ^a^b^c^d^e^f^g^h^i^j^k^l^m^n^o"..
     "^p^q^r^s^t^u^v^w^x^y^z[ \\ ] ^^_ "..
     "` a b c d e f g h i j k l m n o "..
     "p q r s t u v w x y z { | } ~ ^*"

-- loads a font which will then be used by
-- all pr operations
function load_font(fnt)
 _current_font=fnt

 for i=0,#fnt.data/11 do
  local p=1+i*11
  local char=sub(fnt.data,p,p+1)
  _glyphs[char]=
   tonum("0x"..sub(fnt.data,p+2,p+10))
   -- force kerning calculation
   -- makes tlen work without rendering first
   pr(char,-9,-9) 
 end
end

-- prints a string at x0 y0
-- with color c1
-- if c2 is specified a shadow is added of that color
function pr(str,x0,y0,c1,c2)
 local x1,i=x0,1
 
 while i<=#str do
  local char=sub(str,i,i)
  
  if char=="\n" then
   y0+=_current_font.gh+1
   x1=x0
  else
   if char=="^" then
    char=sub(str,i,i+1)
    i+=1
   else
    char=char.." "
   end
   
   local px,k=_glyphs[char],_current_font.gw+1

   -- handle kerning
   for j=1,2 do
    px=shr(px,1)
    if (band(px,0x0.0001)>0) k-=j
   end
   _kerning[char]=k

   -- draw glyph
   for y=0,_current_font.gh-1 do
    for x=0,_current_font.gw-1 do
     px=shr(px,1)
     if band(px,0x0.0001)>0 then
      pset(x1+x,y0+y,c1)
      if (c2) pset(x1+x,y0+y+1,c2)
     end
    end
   end 
   
   x1+=k
  end
  
  i+=1
 end
end

-- custom font text length
-- kerning is calculated on first draw
function tlen(str)
 local l,i=0,1
 while i<=#str do
  local char=sub(str,i,i)
  if char=="^" then
   char=sub(str,i,i+1)
   i+=1
  else
   char=char.." "
  end
  if (_kerning[char]) l+=_kerning[char]
  i+=1
 end
 return l
end

-- returns position of first occurence 
-- of char c in string str
-- or 0 if not found
function indexof(str,c) 
 for i=1,#str do
  if (sub(str,i,i)==" ") return i
 end
 return 0
end



-- font data
font={
 name="font_playful",
 author="johan peitz",
 gw=4,
 gh=7,
 data=[[  0000.0004! 0080.888e" 0000.02aa# 007c.cf80$ 0013.9392% 00d1.22c0& 03eb.9300' 0000.008e( 0108.8894) 0091.110c* 0029.2802+ 0013.9002, 0900.0004- 0003.8002. 0080.0006/ 0091.22400 034c.ccb01 0111.11942 0788.b4303 034c.24304 0447.ccc05 03c4.38b86 034c.b8887 0112.24788 034c.b4b09 0447.4cb0: 0080.0806; 0900.1004< 0210.9202= 0038.3802> 0092.1082? 0103.4438@ 030e.ecb0^a04cf.ccb0^b03cc.bcb8^c0708.88f0^d03cc.ccb8^e0788.b8f8^f008b.88f8^g034c.e8b0^h04cc.fcc8^i0391.113a^j034c.4470^k04a9.9ac8^l0788.8888^m04cc.cfc8^n04cc.edc8^o034c.ccb0^p008b.ccb8^q434c.ccb0^r04cb.ccb8^s03c4.30b0^t0111.113a^u034c.ccc8^v012c.ccc8^w04fc.ccc8^x04cc.b4c8^y0447.4cc8^z0789.2478[ 0188.889c\ 0422.1108] 0191.111c^^0000.0292_ 0780.0000` 0000.010ca 074f.4300b 03cc.cb88c 0308.8b02d 074c.cf40e 070f.cb00f 1113.9122g 3474.cf00h 04cc.cb88i 0088.880ej 1a22.2022k 04a9.ac88l 0108.888cm 04cc.fc80n 04cc.cb80o 034c.cb00p 0bcc.cb80q 474c.cf00r 0088.9e80s 03c3.0f00t 0211.1392u 034c.cc80v 012c.cc80w 04fc.cc80x 02a9.2a82y 1a74.cc80z 0389.2382{ 3110.9132| 0888.888e} 1912.111a~ 0000.6d80^*0024.0900]]
}



-- good things
tilesize=16 					 -- pixels
fall_speed=0.125  -- tiles
move_speed=0.125  -- tiles
climb_speed=0.124 -- seconds
climb_delay=6  			-- frames
fall_align_speed=0.25 --seconds
drop_delay=1 				 -- seconds
blink_delay=0.5   -- seconds

-- title waves
wave_sync=0.37 -- (0-1)
title_music_start=66 -- frames until music starts
bpm=0.83333333
-- algo: 60 / (8 / (120 / 9))/120


function _init()
 cartdata("jppicodriller")
 
 pal_reset()
 load_font(font)
 start_intro()
 
 hiscores={}
 for i=1,8 do
  hiscores[i]=dget(i)
 end
end

function start_title(_tick)
 retry=false
 new_best=false
 game_state=0
 -- 0 = title
 -- 1 = transition to play
 -- 2 = playing
 -- 3 = game over
 -- 4 = win!!!
 menu=menues["title"]
 menu_slot=1
 menu_hint_y=1000
 desc_text1=""
 desc_text2=nil
 bg_col=1
 
 camy=-128
 tick=_tick
 title_tick=_tick
 parallax_y=0

	clusters={}
	pl=nil
 screenshake=0
 
 btnbits=0 
end

function start_game()
 camy=-128

 title_tick=0
 game_state=2
 
 started_drilling=false
 next_air_x=3
 next_air_y=6
 last_air_x=-999
 last_air_y=-999
 player_level=1
 world_level=1
 current_ld=level_data[world_level]
 screenshake=0
 depth_indicator=nil
 lives_shake=0
 air_shake=0
 
 airtank_sx=0
 airtank_sy=0
 airtank_t=-1
 
	pl={
	 x=3,x0=3,x1=3,
	 y=-7,
	 max_y=0,
	 dir=4,
	 wall=0,
	 wall_count=0,
	 speed=move_speed,
	 air=101,
	 state=0,
	 lives=3,
	 -- 0-falling
	 -- 1-on ground - idle
	 -- 2-climbing	
	 -- 3-squashed
	 -- 4-asphyxiated
	 drilling=0, 
	 walking=0,
	 beam_count=0
	}
 	
	-- other things
	static_block=make_block(-1,-1)
	static_block.cluster={state=0}
	static_block.col=-1
	static_block.static=true
	
	drill_penalty=0
	drill_pressed=false

	clusters={}
	cluster_count=0
 
 blocks={}
 for x=0,7 do
	 blocks[x]={}
 end
	last_row=0
	
	last_cpu=0
	
 music(22)
end

function add_row()
 last_row += 1

	if last_row%level_length==0 then
		world_level+=1
	 current_ld=level_data[min(#level_data, world_level)]

		next_air_y=last_row+current_ld.c_freq
	 next_air_x=flr(rnd()*8)
	end

	-- level variables
	local tot_levels=#level_data
	local ld=current_ld
	local num_colors=ld.cols
 local max_x_per_line=ld.max_x
 local air_freq=ld.c_freq
 local x_freq=ld.x_freq

 local max_x = max_x_per_line

 for x=0,7 do
  local type="color"
  local col=flr(1+rnd()*num_colors)
  
  -- start area
  if last_row<6 then
   if x-4-((last_row-1)/2)>0 then
    type="x"
 		end
   if ((last_row-1)/2)+x<3 then
    type="x"
 		end
  end

		-- random x's
  if rnd()<x_freq and max_x>0 and last_row>7 and last_row%2==0 then
   type="x"
   max_x-=1
   
   -- make sure we don't surround a capsules
   if ld.c_prot==2 or ld.c_prot==0 then
    if last_row==last_air_y and x==last_air_x+1 then
     local b=get_block(x-2,last_row) 
    	if b and b.hits then
    	 -- revert to color
    	 type="color"
    	 max_x+=1
    	end
    end
   end
   
  end
  
  -- nice rows in the beginning
  if last_row<8 then
   local lr=last_row
   if last_row>5 then 
   	lr-=1
   end
   col = 1+lr%num_colors
  end

		-- air protection
		-- 0 - x on top, not surrounded
		-- 1 - x on top
		-- 2 - x on top&below, not surrounded
  -- 3 - x on all sides
  if last_row>6 then
   -- top block
	  if last_row+1==next_air_y and x==next_air_x then
	   type="x"
	   max_x-=1
	  end
  	-- side blocks
  	if ld.c_prot==3 then
    if last_row==next_air_y and x==next_air_x-1 then 
 	   type="x"
     max_x-=1
    end
    if last_row==last_air_y and x==last_air_x+1 then 
 	   type="x"
     max_x-=1
    end 	 
  	end
	  -- btm block
	  if ld.c_prot>1 then
		  if last_row-1==last_air_y and x==last_air_x then
 	   type="x"
	    max_x-=1
				end
  	end  	

  end
  
  if last_row==next_air_y and x==next_air_x then
  	type="a"
  	last_air_x=x
  	last_air_y=last_row

 		next_air_y+=ld.c_freq
 	 next_air_x=flr(rnd()*8) 		
	 end

  -- separators (always override)
  local lr=last_row%(level_length)
  if lr>level_length-5 or lr==0 then
  	type="-"
  end
  
  if last_row>=max_depth+1 then
   type="s"
  end
  
  -- add the block
  if last_row<=max_depth+2 then
	  add_block(make_block(type,col),x,last_row)
  end
 end
 
 
end

function _update()
 tick+=1
 title_tick+=1
 
 if title_tick==20 and game_state==0 then
	 sfx(32,3)
 end

 if game_state==1 then
  if title_tick-transition_tick>15 then
   start_game()
  end
 elseif game_state==0 then
 	-- title
 	 
 	if tick==title_music_start then
 	 music(0)
 	end
 	
  parallax_y+=fall_speed*tilesize
  if tick>60 then
   update_menu()
		end
 elseif game_state==3 then
  update_menu()
 elseif game_state==4 and tick-gameover_tick>60 then
  update_menu()
 end
 
 if game_state>1 then
  -- game
  update_game()
 end
 
 
end

function update_game()
 btnbits=0
 for i=0,5 do
  if btn(i) then
   btnbits+=2^i
  end
 end

 -- update clusters
 update_clusters()
 
	-- reached the goal?
 if game_state<3 and pl.y==max_depth then
  reach_bottom()
	end
 
 
 -- victory animation
 if game_state==4 then
  local dirs={1,4,2,4}
  pl.dir=dirs[1+flr(tick/8)%4]

  if pl.x>1 and pl.x<4 then
   pl.x-=pl.speed/2
   pl.dir=1
   pl.walking=2
  end
  if pl.x>=4 and pl.x<6 then
   pl.x+=pl.speed/2
   pl.dir=2
   pl.walking=2
  end
 end
 -- update player
 if drill_penalty<2 then
	 if pl.state>=3 then
	  if tick-pl.death_tick>45 then
	   if game_state!=3 then
 	   respawn()
	   end
	  end
	 elseif pl.state==0 then
	  -- falling  
	  pl.y += fall_speed*(pl.y<0 and 2 or 1)
	  if pl.x!=pl.x1 then
		  pl.t+= fall_align_speed
		  pl.x = ease_outquad(pl.t,pl.x0,pl.x1-pl.x0,1)
		 elseif pl.x != flr(pl.x) then
	   -- center player?
	   center_player(flr(pl.y)+1)
		 end  
		 
		 if pl.drilling<=4 then
		  pl.dir=4
			end
	  -- landed?
	  local px=flr(pl.x+0.5)
	  local py=flr(pl.y)+1
	  local b=get_block(px,py)
	  local land=false
	  if (b and b.blocking) land=true
		 if land then
		 	pl.y=flr(pl.y)
		 	pl.state=1
		 	if pl.y>pl.max_y then
		 		pl.max_y=pl.y
					if pl.max_y%level_length==0 then
						player_level+=1
			  end
			 end 
		 end
	 elseif pl.state==1 then 
	  -- standing
	  
	  if pl.tt then
	   pl.tt+=0.25
    pl.x = ease_inquad(pl.tt,pl.x0,pl.x1-pl.x0,0.5)
	   if pl.tt>=1 then
	    pl.tt=nil
	   end
	  end
	  
	  if drill_penalty==0 and pl.beam_count==0 and game_state<3 then
			 if band(btnbits,1)>0 then
			 	pl.x -= pl.speed
			 	if (pl.dir!=1) pl.drilling=0
			 	pl.dir = 1
			 	pl.walking=2
			 elseif band(btnbits,2)>0 then
			 	pl.x += pl.speed
			 	if (pl.dir!=2) pl.drilling=0
			 	pl.dir = 2
			 	pl.walking=2
			 elseif band(btnbits,4)>0 then
			 	if (pl.dir!=3) pl.drilling=0
			  pl.dir = 3
			 elseif band(btnbits,8)>0 then
			 	if (pl.dir!=4) pl.drilling=0
			  pl.dir = 4
			 end
	  end
	  
			-- trying to climb?
			if pl.wall != 0 then
			 -- make sure no
			 -- cluster is falling into
			 -- player target tile
			 local try_climb = true
				local px=flr(pl.x+0.5)
				local destb=get_block(px+pl.wall,pl.y-1)
	 		if not get_block(px,pl.y-1) and
	 		   (not destb or destb.air) then
				 if destb and destb.cluster and destb.cluster.state>=3 then
				  pl.wall_count = 0
				 else
				  -- make sure no cluster 
				  -- is falling into
			   -- player target tile
			   local stop_climb=false
				  for c in all(clusters) do
				   if c.state==2 then
				    for b in all(c.blocks) do
				     if not b.air then
				      if flr(b.y+c.y+2)>=flr(pl.y-0.1) then
				       stop_climb=true
				       pl.wall_count=0
				      end
				     end
				    end
				   end
				  end
				 
				  -- looks like all is well
				  if not stop_climb then
				  	pl.wall_count += 1
				 	end
				 end
				end
			else
				pl.wall_count = 0
		 end
		
			local climbing=false
	 	if pl.wall_count>climb_delay then
				pl.y0 = pl.y
				pl.y1 = pl.y - 1
				pl.x0 = pl.x
				
				pl.x1 = pl.x+1*(pl.dir==1 and -1 or 1)
				pl.t=0
				
				pl.wall_count = 0
				climbing=true
				pl.state=2
	 	end
			
			if not climbing then
			 -- move left/right
				local px=flr(pl.x)
				local py=flr(pl.y)
				local bl=get_block(px,py)
				local br=get_block(px+1,py)
				
				if band(btnbits,1)>0 and bl and bl.blocking and bl.cluster.state<4 then
					pl.x=flr(pl.x+1)
					pl.wall=-1	
				elseif band(btnbits,2)>0 and br and br.blocking and br.cluster.state<4 then
					pl.x=flr(pl.x)
					pl.wall=1
				else
					pl.wall=0
				end
			
			 -- start falling?
	   local py=flr(pl.y)+1
	   local px=flr(pl.x+0.5)
	   local b=get_block(px,py)
	   local fall=true
	   if not (b and b.blocking) then
	    -- start falling
	    pl.state=0
	    -- center player?
	    center_player(py)
    end
		 end	
		 			
	 	-- drilling?
	 	if (band(btnbits,16)>0 or band(btnbits,32)>0) and not drill_pressed and not climbing then
		 	pl.drilling=12
		 	pl.wall_count=-16 -- don't climb straight after
		 	if drill() then
		 	 started_drilling=true
		 	 drill_penalty=4
		  end
		  drill_pressed=true 
		 end
		 

	 elseif pl.state==2 then
	  -- climbing
	  pl.y = ease_outquad(pl.t,pl.y0,pl.y1-pl.y0,1)
   pl.x = ease_inquart(pl.t,pl.x0,pl.x1-pl.x0,1)
	  
	  pl.t += climb_speed
	  if pl.t >= 1 then
	  	pl.y = pl.y1
	  	pl.x = flr(pl.x+0.5)
	  	pl.state = 1
	  end
	 end
	end
 
	-- should any clusters fall?
 while check_clusters()>0 do
	end 
 -- only do this once if low cpu
 -- check_clusters()
 
 -- move counters
 if (pl.drilling>0) pl.drilling-=1
 if (pl.walking>0) pl.walking-=1
 if (drill_penalty>0) drill_penalty-=1
 if (lives_shake>=0) lives_shake-=1
 if (air_shake>=0) air_shake-=1
 if (airtank_t>=0) airtank_t+=1
 if (not btn(❎) and not btn(🅾️)) drill_pressed=false

 if depth_indicator and depth_indicator.move then 
  depth_indicator.dy-=2
  if depth_indicator.dy<-64 then
   depth_indicator=nil
  end

 end
 
 -- new blocks?
 if pl.y+16>last_row then
  --local cpu=stat(1)
 	add_row()
 end
 
 -- pick something up?
 local b=get_block(flr(pl.x+0.5), flr(pl.y))
	if b then
		if b.air then
			del(clusters, b.cluster)
			blocks[b.x][b.y]=nil
			sfx(26,2)
			
			airtank_sx=b.x*tilesize
			airtank_sy=b.y*tilesize-camy
			airtank_t=0
		end
	end
	 
 -- air decrease
 local oxy_usage=level_data[min(#level_data,player_level)].air_usage-less_air
 if airtank_t<0 and started_drilling and tick%oxy_usage==0 then
 	if pl.air>0 and pl.state<3 and game_state<3 then
 	 pl.air-=1
 	end
 end

 -- out of air?
 if pl.state<3 then
	 if pl.air<=0 then
	  knock_out(4)
	  sfx(35,3)
	 end
 end
	-- camera
 -- autoscroll 
 for y=40,72,8 do
  if camy<pl.y*16-y then
   camy+=0.5
  end
 end
 
 camy=min(camy,max_depth*16-80)

end

function center_player(py)
 local pxl=flr(pl.x+1/16)
 local pxr=flr(pl.x+15/16)

 local bl=get_block(pxl,py)
 local br=get_block(pxr,py)

 local bl=(bl and bl.blocking)
 local br=(br and br.blocking)

	pl.x0 = pl.x
	pl.x1 = pl.x
	pl.t=0

 if bl then
 	pl.x1=flr(pl.x+1)
 elseif br then
 	pl.x1=flr(pl.x)
 end
 
end

function wipe_blocks_above(y, spd)
 for c in all(clusters) do
  if c.state!=4 then
  	if c.blocks[1].y<y then
  	 wipe_cluster(c, spd)
	 	end
	 end
 end 		
end


function drill()
	-- drill what?
	local dx=flr(pl.x+0.5+0.6*dirx[pl.dir])
	local dy=flr(pl.y+0.5+0.6*diry[pl.dir])
	
	-- drilled block
	local b=get_block(dx,dy)
	if b then
		
		-- blow away all clusters above
 	if b.separator then
   wipe_blocks_above(b.y, 1)
   depth_indicator.move=true
 	end

		-- remove cluster
	 if b.blocking and not b.hits and not b.static then
	  remove_cluster(b.cluster, true, true)
 		if b.separator then
    set_sfx_speed(27,6)
 			sfx(27,3)
 		else
  		sfx(25,3)
   end
 		return true
 	end
	 if b.hits then
	  b.hits+=1
	  if b.hits>=5 then
    set_sfx_speed(27,3)
 			sfx(27,3)
		  remove_block(b)
		  pl.air=max(0, pl.air-20)
 			return true
 		else
 			sfx(28,3)
 		end
 	end
 	
 end
 
 return false -- nothing was drilled
 
end

function draw_bg_slice(s,y)
 for tx=s*2,s*2+1 do
  for ty=0,3 do
   local tile=ty*16+tx+1
  
	  spr(32+parallax[tile],
	      tx*8,
	      y+ty*8,
	      1,1,tile>32 )
  end
 end
end

function draw_depth_indicator()
 local y=depth_indicator.y+depth_indicator.dy
 palt(0,false)
 palt(10,true)
 pal(8,palette[3])
 pal(14,palette[11])
 pal(15,palette[7])
 pal(2,palette[3])

 spr(158,25,y,1,2)
 spr(158,96,y,1,2,true)
 sspr(127,80,1,12,32,y,64,12)
 spr(143,32,y+2)
 spr(143,89,y+2)

 pr_c(depth_indicator.depth.." ft",64,y+3,7)

 pal()
end

function _draw() 

 cls()
 camera()
 
 if game_state>0 then
  pal_set(bg_pal)
 end
 if game_state==3 then
	 pal_shift(1, dark_pal) 
	 go_fade_steps=min(3,max(0,flr(tick-gameover_tick)/2)) 
 end
 
 -- draw bg tile
 
	-- colors for bg tiles
	if game_state!=1 then
		if tick<30 then
   -- fade in if in title
	 	local steps=max(0,15-flr(tick/1.5))
 	 pal_shift(steps, dark_pal)
	 end
	else
	 -- flash to correct color
	 local steps=5-flr(min(5,(title_tick-transition_tick)/3))
 	pal_shift(steps, light_pal)
	end
 
 palt(0,false)
 for y=0,4 do
	 for s=0,7 do
	 	local cy=flr((camy+parallax_y)/p_speeds[s+1])%32
	 	draw_bg_slice(s,y*32-cy)
	 end
	end
 palt(0,true)

 -- draw game world
 if screenshake>0 then
  screenshake-=1
  camera(rnd(6)-3,camy+rnd(6)-3)
 else
  camera(0,camy)
 end
 pal_reset()
 
 -- draw blocks
 for c in all(clusters) do
	 draw_cluster(c)
 end
	 
 if depth_indicator then	
	 if game_state==3 then
	  pal_reset()
 		pal_shift(go_fade_steps, dark_pal)  
		end
  draw_depth_indicator()
	end
	
	-- tutorial
	if game_state==2 and pl.y<5 then
 	
 	print_s("  move\n⬅️➡️⬆️⬇️",8,2,7,5)
	 print_s("drill\n🅾️/❎",94,2,7,5)
	end
 -- draw player & hud
 if pl then
  draw_pl(pl.x*tilesize, pl.y*tilesize)
  draw_hud()
	end

 -- draw ui	
	camera()
	tt=title_tick
	if game_state>=3 then
		tt=tick-gameover_tick
	end

 -- draw menu
 if game_state!=2 then
 	draw_menu(tt-30)
 end
 
 -- draw waves
	if game_state!=2 then
		wave_y=ease_outquad(tt/10, -50, 50, 3)
	else
 	wave_y=ease_inquad(tt/10, 0, -50, 3)
 end
 if wave_y>-50 then
  draw_waves(wave_y)
 end
 
 -- draw logo
 if not retry then
		if game_state<2 then
	 	logo_y1=ease_outbounce(max(0, (tt-27))/10, -50, 50, 2)
	 	logo_y2=ease_outbounce(max(0, (tt-15))/10, -50, 50, 2)
		else
	 	logo_y1=ease_inquad(tt/10, 0, -70, 5)
	 	logo_y2=ease_inquad(tt/10, 0, -70, 5)
		end
		if logo_y1>-60 and game_state<3 then
	  draw_logo(logo_y2,logo_y1)
	 end
	end
 
 -- draw menu description
 if game_state==0 then
  local x1=63-2*#desc_text1
  if desc_text2 then
   x1=10
   local x2=127-4*#desc_text2
   print(desc_text2,
         x2,menu_hint_y,15)
  
   spr(92,1,menu_hint_y)
   spr(93,x2-8,menu_hint_y)
  end
  print(desc_text1,
        x1,menu_hint_y,15)
 end 

 last_cpu=stat(1)
	
end

function prep_hud_pal()
 pal()
 palt(10,true)
 palt(0,false)
end


function draw_hud()
 camera()
 
 local cap_x=ease_outquad(max(0,tick-90)/5,-100,100,4)

 -- lives
 prep_hud_pal()
 pal(12,14)
 if (lives_shake>5) pal(white_pal) 
 draw_capsule(1+cap_x+lives_shake%2,116,20,pl.lives)

 
 -- depth
 prep_hud_pal()
 pal(12,9)
 draw_capsule(2+cap_x,2,42,max(0,flr(pl.y*5)),6)
 -- air
 if pl.air>=30 or tick%10>=2 then
		pal(12,12)
		if (air_shake>5) pal(white_pal)
	 draw_capsule(102-cap_x+air_shake%2,2,23,min(100,pl.air).."%")
		sspr(0,32,5,10,98-cap_x+air_shake%2,2)
	end
 palt()

	if airtank_t>=0 then
	 spr(135,
	     ease_inquad(airtank_t/15,airtank_sx,112-airtank_sx,1),
	     ease_inquart(airtank_t/15,airtank_sy,-airtank_sy,1),
	     2,2)
	 if airtank_t>15 then
	  airtank_t=-1
	  -- tank arrived - give air
 	 pl.air = min(101, pl.air+20)	  
	  air_shake=10
	 end
	end
	

 --icons
 pal()
 spr(82,5+cap_x,2) -- drill
 spr(67,35+cap_x,6) -- ft
 if pl.air<30 then
 	pal(15,12)
 	pal(9,13)
 end	
 if (lives_shake>5) pal(white_pal)
	spr(66,4+cap_x+lives_shake%2,116) -- head
end

function draw_capsule(x,y,w,str,pad)
 pad=pad or 0 
 sspr(5,32,5,16,x,y)
 sspr(11,32,1,16,x+5,y,w-10,16)
 sspr(11,32,5,16,x+w-5,y)
 
 str=""..str
 print(str,x+w-#str*4-3-pad,y+3,10)
end

-->8
-- blocks & clusters

function make_block(block_type,col)
 if block_type=="s" then
	 return {
	 	basetile=78, 
	 	tile=0,
	 	single_tile=true,
	 	static=true,
	 	blocking=true,	
	 	col=5
	 }
 elseif block_type=="a" then
	 return {
	 	basetile=135, 
	 	tile=0,
	 	air=20,
	 	col=7,
	 	single_tile=true
	 }
 elseif block_type=="x" then
	 return {
	 	basetile=128, 
	 	tile=0,
	 	col=5,
	 	sticky=true,
	 	hits=0,
	 	blocking=true,
	 	single_tile=true,
	 }
	elseif block_type=="-" then
	 return {
	 	basetile=232, 
	 	tile=0,
	 	autotile=true,
	 	col=6,
	 	sticky=true,
	 	separator=true,
	 	blocking=true
	 }
	end
	
	-- return regular
	return {
 	basetile=current_ld.tileset,
 	tile=0, 
 	autotile=true,
 	draw_block=true,
	 sticky=true,
 	blocking=true,
 	col=col,
 }
 
end

_lb=nil
function add_block(b,x,y)
 b.x=x
 b.y=y
 blocks[x][y]=b
 
 if _lb and _lb.separator and b.separator then
  b.cluster=_lb.cluster
  add(_lb.cluster.blocks, b)
  update_block_tile(b,b.x,b.y)
  
  for d=1,4 do
   local bb=get_block(b.x+dirx[d], b.y+diry[d])
	 	if (bb and not bb.static) update_block_tile(bb,bb.x,bb.y)
	 end 

 else
	 
	 -- check for clusters
	 local friends={b}
	 for d=1,4 do
		 local b2=get_block(x+dirx[d], y+diry[d])
	  if b2 then
				if b.col == b2.col then
				 add(friends, b2)
				end
		 end
		end
		
		-- do autotiling
		for b2 in all(friends) do
	 	update_block_tile(b2,b2.x,b2.y)
	 end 
	 
		-- merge clusters
		local new_cluster=make_cluster()
		
		local new_blocks={}
		if b.sticky then
			for f in all(friends) do
		 	if f.cluster then
		 	 for bb in all(f.cluster.blocks) do
				 	if not contains(new_blocks, bb) then
				 		add(new_blocks, bb)
						end
		 	 end
		 	else
			 	if not contains(new_blocks, f) then
			 		add(new_blocks, f)
					end
		  end
			end
		else
	 	if not contains(new_blocks, b) then
	 		add(new_blocks, b)
			end
		end
	
		for nb in all(new_blocks) do
		 if nb.cluster then
		 	del(clusters, nb.cluster)
		 end
		 nb.cluster=new_cluster
			add(new_cluster.blocks, nb)
	 end
	
		add(clusters, new_cluster)
	end
	
	--if bg_col==5 then -- test_mode
	 _lb=b
	--end
	
end

function make_cluster()
	cluster_count += 1
	
	return {
	 id=cluster_count,
	 blocks={},
	 y=0,
	 drop_timer=-1,
	 state=0
	 -- 0 = stuck
	 -- 1 = shaking
	 -- 2 = falling
	 -- 3 = blinking
	 -- 4 = exploding
	 -- 5 = flying away
	}
end


function get_block(x,y)
 if (x<0 or x>7) return static_block
 if (y<0) return nil

	if (not blocks[x]) return nil
	
	return blocks[x][y]
end


function update_block_tile(b,x,y)
	if b.autotile then
		local bitmask={2,4,1,8}
	 b.tile=0
	 for d=1,4 do
	  local xx=x+dirx[d]
	  local yy=y+diry[d]
	 	local b2=get_block(xx,yy)
	  if b2 then
	   if b.col==b2.col then
		   b.tile += bitmask[d]
	 	 end
	  end
		end
	end
end

function remove_block(b)
 -- remove from current cluster
 
 -- leave statics alone
 if b.static then
  return
 end
 
 local old_cluster=nil
 -- remove it from its cluster
 del(b.cluster.blocks, b)
 if #b.cluster.blocks == 0 then
  del(clusters, b.cluster)
 else
  old_cluster=b.cluster
 end
 
 -- add to a new cluster
 local c=make_cluster()
 add(c.blocks, b)
 b.cluster=c
 -- add new cluster to game
 add(clusters, c)	
 -- remove new cluster
 remove_cluster(c, true, false, true)


 if old_cluster then
  -- autotile old cluster
  for b2 in all(old_cluster.blocks) do
   update_block_tile(b2,b2.x,b2.y)
  end
  -- check if cluster has 
  -- been split and make 
  -- new ones if so
  local new_cluster=make_cluster()
  move_blocks(old_cluster.blocks[1], new_cluster)
  add(clusters, new_cluster)
  if #old_cluster.blocks==0 then
   del(clusters, old_cluster)
  end
 
 end
 
end

function move_blocks(b, c)
 -- move to new cluster
 local oc=b.cluster
 del(oc.blocks, b)
 b.cluster=c
 add(c.blocks, b)
 b.moved=true
 
 -- check neighbours
 for d=1,4 do
  local bb=get_block(b.x+dirx[d], b.y+diry[d])
  if bb and 
     bb.cluster==oc and 
     not bb.moved then
   move_blocks(bb, c)
  end
 end
 
 b.moved=nil
end

function delete_cluster(c)
	for b in all(c.blocks) do
 	blocks[b.x][b.y]=nil 
 end
 del(clusters, c)
end


function remove_cluster(c, instantly, delayed_effect, skip_sound)
	if instantly then
	 -- explode
	 c.state=4
	 local deepy=0
	 for b2 in all(c.blocks) do
	  b2.explode_frame=0
	  if delayed_effect then
		  local dist=distance(pl.x,pl.y,b2.x,b2.y)
	   b2.explode_frame=-flr(dist-1)
	  end
	 	blocks[b2.x][b2.y]=nil 
	 	if b2.y>deepy then
	 	 deepy=b2.y
	 	end
	 end
	 if deepy>pl.y-5 and not skip_sound then
 	 sfx(29,3)
	 end
	else
	 -- blink first
	 c.state=3
	 c.blink_timer=0
 end
end

function drop_cluster(c)
 -- start shaking
 c.state=1
 c.drop_timer=0
end

function check_clusters()
	local count = 0

 -- check if clusters should 
 for c in all(clusters) do
	 if c.state==0 then
		 c.drop_count=0
	  
	 	for b in all(c.blocks) do
	 		if not b.static then
		 		local b2=get_block(b.x,b.y+1)
		 		
		 		if b.y<last_row-2 then
			 		if not b2 then
			 		 -- no block beneath
			 		 -- no support!
			 		 c.drop_count += 1
			 		elseif b2.cluster == b.cluster then
			 		 -- same cluster
			 		 -- no support!
			 		 c.drop_count += 1
		 	  elseif b2.cluster.state==2 then
			 		 -- already falling
			 		 -- no support!
			 		 c.drop_count += 1
			 		elseif b2.cluster.state==1 then
			 		 -- already shaking
			 		 -- no support!
			 		 c.drop_count += 1
			 		end
		 		end
			 end
	 	
	 	end
	 	
	 	if c.drop_count==#c.blocks then
	 		drop_cluster(c)
	 		count += 1
	 	end

	 end
 	
 end
 
 return count
 
end

function reattach_cluster(c)
	local new_cluster=nil

	c.state=0
	del(clusters, c)
	
	for b2 in all(c.blocks) do
		b2.y+=flr(c.y)
		add_block(b2, b2.x, b2.y)
		new_cluster=b2.cluster
	end
	c.y=0
	
	if #new_cluster.blocks > 3 then
		remove_cluster(new_cluster,false,false)
	end
	
end



function update_clusters()

 for c in all(clusters) do
 
 	if c.state==0 then -- normal
 	 -- cull clusters if too far above
 	 local limit=25
 	 -- cull more if cpu is high!
 	 if last_cpu>0.8 then
 	  limit=15
 	 end
 	 if #c.blocks>0 then
  	 if c.y+c.blocks[1].y<pl.y-limit then
  	  delete_cluster(c)
 	  end 
   end
  elseif c.state==1 then 
   -- shaking
  	c.drop_timer+=1/30
  	if c.drop_timer>=drop_delay then
   	c.drop_timer=-1
	  	c.state=2
 		 for b in all(c.blocks) do
		  	blocks[b.x][b.y]=nil
 			end
			end
  elseif c.state==3 then 
   -- blink
			c.blink_timer+=1/30
			if c.blink_timer>=blink_delay then
				remove_cluster(c, true, false)
			end 
		elseif c.state==5 then 
		 -- wipe
			for b in all(c.blocks) do
				b.x+=b.dx
				b.y+=b.dy
			end
			c.wipe_timer+=1/30
			if c.wipe_timer>1 then
				del(clusters, c)
			end 
  elseif c.state==4 then 
   -- explode
			local done_blocks=0
			for b in all(c.blocks) do
			 if tick%2==0 then
					b.explode_frame+=1
				end
				if b.explode_frame>4 then
				 done_blocks+=1
				end
	  end
			if #c.blocks==done_blocks then
				del(clusters, c)
			end
		elseif c.state==2 then 
		 -- falling
			c.y += fall_speed
			
			for b in all(c.blocks) do

				if c.blocks[1].sticky then
					-- check blocks on the right
					if c.state==2 then	
					 local br=get_block(b.x+1,flr(b.y+c.y))
						if br and br.col==b.col and
					   (br.cluster.state==0 or 
						   br.cluster.state==1 or 
						   br.cluster.state==3)
						then
						 reattach_cluster(c)
						end
					end
				
					-- check blocks on the left
					if c.state==2 then	
					 local bl=get_block(b.x-1,flr(b.y+c.y))
						if bl and bl.col==b.col and
					   (bl.cluster.state==0 or 
						   bl.cluster.state==1 or 
						   bl.cluster.state==3)
						then
						 reattach_cluster(c)
						end
					end
				end
			
				-- check ground
				if c.state==2 then		
				 local bd=get_block(b.x,flr(b.y+c.y+1))
					if bd and 
				   (bd.cluster.state==0 or 
					   bd.cluster.state==1 or 
					   bd.cluster.state==3)
					then
					 reattach_cluster(c,true)
					end

				end
				
				-- did we squash the player?
			 local dx=pl.x-b.x
			 if b.sticky and abs(dx)<1 then
			  local by=b.y+c.y
			  if by>pl.y-0.5 and by<pl.y then		     
			   -- squash opportunity
	     if abs(dx)<0.5 then
							-- squash!
							knock_out(3)
	     else
	      -- push out of block
	      pl.tt=0
	      pl.x0=pl.x
	      if dx<0 then
	       pl.x1=flr(pl.x)
	      else
	       pl.x1=flr(pl.x+1)
	      end
	     end
	    end
			 end
			end
		end
 end
  
end


function wipe_cluster(c, spd)
 c.state=5
 c.wipe_timer=0
 for b in all(c.blocks) do
	 blocks[b.x][b.y]=nil
 	b.dx=0.06*(b.x-pl.x)+0.03*(b.y-pl.y)
 	b.dy=spd*(-0.05+0.03*(b.y-pl.y))
 end
end

function draw_cluster(c)

 local cy=tilesize*c.y

 -- draw blocks
 local first=true
	for b in all(c.blocks) do

  local by=b.y*tilesize
  local bx=b.x*tilesize

		if cy+by>camy-16 and
					cy+by<camy+128 then

	  local cx=c.state==1 and 1.5*sin(b.cluster.blocks[1].y/5+t()*4) or 0

		 -- set colors
		 if first then
			 pal_reset()
			 pal_pal(12,block_pals[1][c.blocks[1].col])
			 pal_pal(13,block_pals[2][c.blocks[1].col])
			 if game_state==3 then
					pal_shift(go_fade_steps, dark_pal)  
				end
				first=false
			end
		
			if c.state==4 then
				-- explosion
				local tile=160
				if b.explode_frame>=0 then
				 tile=160+2*b.explode_frame
				 if tile<170 then
						spr(tile, cx+bx, cy+by, 2, 2)
				 end
				else
					draw_block(b,cx+bx, cy+by) 
				end
			else
			
				-- regular
				if c.state!=3 or sin(t()*10)>0 then
					if b.autotile then
					 -- color block
					 draw_block(b,cx+bx, cy+by) 
					end
						
					if b.single_tile then
					 spr(b.basetile, 
			 							cx+bx,
			 							cy+by,
					      2, 2)
					end	
					
					if b.air then
							spr(148+(tick/4)%4, 
		 				    cx+bx, cy+by+8)
					end	
				           
			  if b.hits then            	 
			  	if b.hits>0 then
			  	 spr(130, cx+bx, cy+by) 
			  	end
			  	if b.hits>1 then
			  	 spr(131, 8+cx+bx, cy+by) 
			  	end
			  	if b.hits>2 then
			  	 spr(146, cx+bx, 8+cy+by) 
			  	end
			  	if b.hits>3 then
			  	 spr(147, 8+cx+bx, 8+cy+by) 
			  	end
			  end
			  
			 end
			  
  	end
 		
 	end 		
	end
end

function draw_block(b,x,y)
	local td=tiles[b.tile+1]
	spr(b.basetile+td[1], x,y)
	spr(b.basetile+td[2], x+8,y)
	spr(b.basetile+td[3], x,y+8)
	spr(b.basetile+td[4], x+8,y+8)
	
	if not depth_indicator and b.basetile+td[2]==239 then
  depth_indicator={dy=0,depth=b.y*5+20,y=y+4}
	end
end
-->8
-- helpers

function contains(a,e1)
	for e2 in all(a) do
		if (e1==e2) return true 
	end
	return false
end

function distance(ax,ay,bx,by)
 local dx,dy=ax-bx,ay-by
 return sqrt(dx*dx+dy*dy)
end


function pr_c(str,x,y,c1,c2)
 local w=tlen(str)/2
 pr(str,x-w,y,c1,c2)
 return w
end

function print_s(str,x,y,c1,c2)
 print(str,x,y+1,c2)
 print(str,x,y,c1)
end

-- explode strings into arrays
function explode(s,delim)
 if (not delim) delim=","
 local retval,lastpos={},1
 for i=1,#s do
  if sub(s,i,i)==delim then
   add(retval,sub(s, lastpos, i-1))
   i+=1
   lastpos=i
  end
 end
 add(retval,sub(s,lastpos,#s))
 return retval
end


function explodekv(s)
 local r,a={},explode(s)
 for e in all(a) do
  local kv=explode(e,"=")
  if sub(kv[2],1,1)=="\"" then
   kv[2]=sub(kv[2],2,#kv[2]-1)
  else
   kv[2]=tonum(kv[2])
  end
  
  r[kv[1]]=kv[2]
 end
 return r
end

function explodeval(_arr)
 return toval(explode(_arr))
end

function toval(_arr)
 local _retarr={}
 for _i in all(_arr) do
  add(_retarr,flr(_i+0))
 end
 return _retarr
end


function tsspr(tx,ty,tw,th,dx,dy)
 for x=tx,tx+tw-1 do
  for y=ty,ty+th-1 do
   local c=mget(x,y)
   if c!=9 then
    pset(dx+x-tx,dy+y-ty,mget(x,y))
   end
  end
 end
end


function set_sfx_speed(id, speed)
 poke(0x3200 + 68*id + 65, speed)
end


-->8
-- draw player & respawn


	 -- 0-falling
	 -- 1-on ground - idle
	 -- 2-climbing	
	 -- 3-squashed
	 -- 4-asphyxiated

function draw_pl(px,py)
 pal_reset()
 if pl.air<30 then
 	pal_pal(15,12)
 	pal_pal(9,13)
	end
 if game_state==3 then
		pal_shift(go_fade_steps, dark_pal)  
	end
 
 if pl.state>=3 then
  -- dead
  local st=min(7,(pl.state==3 and 4 or 1)*flr(tick-pl.death_tick))
		if (st<4)	spr(18,px,py+8,2,1)
		spr(0+st>4 and 14 or 0,px,py+2+st,2,1) 
		if st<4 then
			spr(20,px,py+10,2,1) 
 	end 
 	
 elseif pl.state==2 then
		spr(12, px, py, 2, 2, pl.dir==2)
		spr(5,px+(pl.dir==1 and 8 or 0),
		      py+5,
		      1,1,pl.dir==2)
 else 
	 if pl.dir>2 then
		 local dy=py+8
	  if pl.state==0 and pl.drilling==0 then
	   local t2=flr(tick/2)
	   -- falling
			 -- legs
	  	spr(18+66*(t2%2),px,py+6,2,1)
	  	-- head
	  	spr(88+t2%4,px,py)
	  	spr(4,px+8,py)
	  	-- drill
	  	spr(20+66*(t2%2),px,py+8,2,1)
	  	dy=nil
	  else
			 local hy=py + (pl.dir==3 and 2 or 0)
			 if pl.drilling>0 then
			 	dy+=tick%2
			 	if (pl.dir==4) hy+=(tick+1)%2
			 end
			 if pl.dir==3 then
			 	dy-=9
			 end
			 
			 spr(0,px,hy,2,1) 
			 local bt=flr(tick/3)%20
			 if pl.drilling==0 and (bt==15 or bt==17) then
			  -- blink
			  spr(2,px,hy,2,1)
			 end
			 
			 spr(pl.dir==4 and 16 or 18,
			     px,py+8,2,1)
			
				-- drill
			end
			if dy then
			 spr(20,px,dy,2,1,false,pl.dir==3)
		 end
		else
		 -- dir 1&2
			if pl.drilling>0 then
				spr(8, px, py, 2, 1, pl.dir==2)
				spr(30, px, py+8, 2, 1, pl.dir==2)
				-- drill
			 local dx=px+(tick%2)*(pl.dir==1 and -1 or 1)
	 		spr(5,dx+(pl.dir==1 and 0 or 8),
	 		      py+5+tick%2,
	 		      1,1,pl.dir==1)
			else
			 local frame=6
			 if (pl.walking>0) frame+=2*(flr(tick/4)%4)
				spr(frame, px, py, 2, 2, pl.dir==2)
	
	 		spr(20,px+(pl.dir==1 and 1 or -1),py+8,2,1,false,pl.dir==3)
			end
		end
 end

 pal()
 if pl.air<11 and pl.air>0 then
  spr(137,px+1,py-16,1,2)
  spr(137,px+8,py-16,1,2,true)
  if pl.air<6 then
   print(pl.air.."",px+7,py-11,13)
  else
   spr(134,px+4,py-12)
  end
 end 
 
 if pl.beam_count>0 then
  pl.beam_count-=1
  local id=25-pl.beam_count
  local r1=beam_ray[id]
  local r2=beam_ball[id]
  if id==1 then
  	sfx(33,3)
  	-- remove blocks above
  	-- sorry for doing this in draw
  	-- but who cares? :)
  	for x=-1,1 do
  	 for y=0,-50,-1 do
  	  local b=get_block(flr(pl.x+x+0.5),flr(pl.y+y+0.5))
  	  if b then
  	  	remove_block(b)
  	  end
  	 end
  	end
  	-- also check for falling clusters
   for c in all(clusters) do
    if c.state==2 then
     for b in all(c.blocks) do
      if b.x>=flr(pl.x-0.5) and
         b.x<=flr(pl.x+1.5) and
         b.y<=pl.y then
       remove_block(b)
      end
     end
    end
   end
     	
  end
  if r2 then
   if r1>0 then
    screenshake=2
    rectfill(px+8-r1-2,-16,
         px+7+r1+2,py+7,10)
   end
   circfill(px+7,py+7,r2+2,10)
  end
  if r2 then
   if r1>0 then
    rectfill(px+8-r1,-16,
         px+7+r1,py+7,7)
   end
   circfill(px+7,py+7,r2,7)
  end
 end
 
end

 
function respawn()
 if pl.lives>0 then
	 pl.air=101
	 pl.state=1
	 pl.dir=4
	else
	 local dp=flr(pl.y*5)
  if register_result(dp) then
   game_over_str="^new record!"
  else
   game_over_str="^best: "..hiscores[game_mode].." ft"
  end
	 game_state=3
	 gameover_tick=tick
	 menu=menues["gameover"]
	 menu_hint_y=1000
	 menu_slot=1
	 retry=true
	 music(38)
	end
end

function knock_out(new_state)
 if pl.state<3 then
 	sfx(34,3)
		pl.state=new_state
  pl.death_tick=tick
  pl.lives = max(0, pl.lives-1)
		lives_shake=10
		if pl.lives>0 then
		 pl.beam_count=55
  end 
 end
end



function reach_bottom()
 register_result(flr(pl.y*5))
 game_over_str="^congratulations!"
 game_state=4
 gameover_tick=tick
 wipe_blocks_above(pl.y+1, 3)
 menu=menues["gameover"]
 menu_hint_y=1000
 menu_slot=1
 retry=true
 music(40)
end


function register_result(y)
 if y>hiscores[game_mode] then
  hiscores[game_mode]=y
  dset(game_mode,y)
  new_best=true  
  return true
 end
 
 return false
end
-->8
-- lookup
menues={
 title={
  explodekv'txt="^arcade",desc="BITE SIZED CHALLENGES",cmd="menu",menu="arcade",slot=1',
  explodekv'txt="^marathon",desc="DRILL FOREVER",cmd="start",depth=30000,ll=100,bg=6,mode=1',
  explodekv'txt="^credits",desc="WHO DUNNIT?",cmd="menu",menu="credits",slot=5'
 },
 arcade={
  explodekv'txt="^beginner",desc="1000 FT",cmd="start",depth=200,ll=100,bg=1,mode=5,less_air=-1',
  explodekv'txt="^intermediate",desc="2500 FT",cmd="start",depth=500,ll=100,bg=5,mode=3,less_air=0',
  explodekv'txt="^expert",desc="5000 FT",cmd="start",depth=1000,ll=100,bg=4,mode=4,less_air=1',
  explodekv'txt="^back",desc="",cmd="menu",menu="title",slot=1',
 }, 
 credits={
  explodekv'txt="^a ^p^i^c^o-8 demake"',
  explodekv'txt="of the ^n^a^m^c^o classic!"',
  explodekv'txt="^art+^audio: @^johan^vinet"',
  explodekv'txt="^code: @^johan^peitz"',
  explodekv'txt="^back",desc="",cmd="menu",menu="title",slot=3,locked=1',
 },
 gameover={
  explodekv'txt="^retry",desc="PLAY AGAIN!",cmd="start"',
  explodekv'txt="^title",desc="RETURN TO TITLE",cmd="menu",cmd="title"',
 }
}

level_data={
 explodekv'tileset=192,cols=4,x_freq=0.15,max_x=3,air_usage=23,c_freq=6,c_prot=0',
 explodekv'tileset=192,cols=3,x_freq=0.17,max_x=3,air_usage=23,c_freq=8,c_prot=2',
 explodekv'tileset=200,cols=4,x_freq=0.2,max_x=3,air_usage=19,c_freq=10,c_prot=2',
 explodekv'tileset=200,cols=4,x_freq=0.23,max_x=4,air_usage=19,c_freq=10,c_prot=3',
 explodekv'tileset=224,cols=2,x_freq=0.15,max_x=4,air_usage=19,c_freq=10,c_prot=1',
 explodekv'tileset=104,cols=4,x_freq=0.25,max_x=4,air_usage=17,c_freq=12,c_prot=3',
 explodekv'tileset=104,cols=3,x_freq=0.26,max_x=5,air_usage=17,c_freq=14,c_prot=3',
 explodekv'tileset=96,cols=3,x_freq=0.26,max_x=5,air_usage=17,c_freq=14,c_prot=3',
 explodekv'tileset=96,cols=4,x_freq=0.26,max_x=5,air_usage=15,c_freq=16,c_prot=3',
 explodekv'tileset=200,cols=4,x_freq=0.26,max_x=5,air_usage=15,c_freq=16,c_prot=3',
 explodekv'tileset=96,cols=4,x_freq=0.26,max_x=5,air_usage=12,c_freq=18,c_prot=3',
}
  

-- background cols
bg_cols={
 explodeval"0,1,2,3,4",  -- brown
 explodeval"0,1,5,3,13", -- blue/grey
 explodeval"0,1,5,3,4",  -- blue/brown
 explodeval"0,1,2,3,8",  -- red
 explodeval"0,0,1,3,5",  -- dark blue
 explodeval"0,0,1,3,3",  -- dark green
}

-- fade pal
dark_pal=explodeval"0,0,1,5,2,1,13,6,4,4,9,3,13,5,4,4"
light_pal=explodeval"1,5,4,11,9,13,7,7,14,10,7,10,6,6,15,7"
white_pal=explodeval"7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7"

-- parallax speeds
-- higher = slower
p_speeds=explodeval"2,3,4,4,4,4,3,2"

-- parallax tiles
parallax=explodeval"0,1,2,3,4,5,6,7,8,9,10,11,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,14,13,12,10,11,10,9,8,7,31,5,4,3,2,1,0,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15"

-- cardinal offsets
dirx=explodeval"-1,1,0,0"
diry=explodeval"0,0,-1,1"

-- autotile data
tiles={
 explodeval"0,1,16,17", explodeval"4,5,16,17",
 explodeval"6,1,22,17", explodeval"2,5,22,17",
 explodeval"0,7,16,23", explodeval"4,3,16,23",
 explodeval"6,7,22,23", explodeval"2,3,22,23",
 explodeval"0,1,20,21", explodeval"4,5,20,21",
 explodeval"6,1,18,21", explodeval"2,5,18,21",
 explodeval"0,7,20,19", explodeval"4,3,20,19",
 explodeval"6,7,18,19", explodeval"2,3,18,19",
}

-- palette swaps
block_pals={
 explodeval"12,8,11,9,14,11,12",
 explodeval"13,2, 3,4,4,3,13",
}

beam_ray=explodeval"1,2,7,11,12,12,11,7,7,11,12,12,11,7,2,0,0,0,0,0,0,0,0,0,0"
beam_ball=explodeval"3,7,12,14,15,15,14,13,13,14,15,15,14,13,13,14,15,15,14,12,7,3"




-->8
-- title & menus
ltrs={}
ltrs[3]=explodeval"68,69,70,71,-1,72,73,71,74"
ltrs[4]=explodeval"75,76,77,77,71,75,75"

function draw_logo(y1,y2)
	-- pico
	tsspr(104,0,17,15,13,6+y1)
	tsspr(104,16,24,15,30,6+y1)
	-- dr + iller
	tsspr(0,0,37,29,18,20+y2)
	tsspr(37,0,49,28,62,11+y2)
	-- driller dude
 if game_state<2 then
 	tsspr(86,0,18,31,48,11+y2)
 end
 
 if game_state==2 then
  circfill(55,28+y2,16-title_tick*2,7)
 end
 
end

function update_menu()
 menu_hint_y += (121-menu_hint_y)*0.5

 local m=menu[menu_slot]
 
 if btnp(❎) or btnp(🅾️) then
  sfx(31,3)
  if m.cmd=="start" then
   game_state=1
   if (m.mode) game_mode=m.mode
   less_air = m.less_air or 0
   clusters={}
   pl=nil
   camy=-128
   bg_col=m.bg or bg_col
   
   -- set mode specific bg colors
	  for i=1,5 do
	   pal_pal(bg_cols[1][i], 
	           bg_cols[bg_col][i]) 
	  end
   bg_pal=pal_get()
   
   transition_tick=title_tick
		 max_depth=m.depth or max_depth
			level_length=m.ll or level_length
			if (m.seed) srand(m.seed)
	 elseif m.cmd=="menu" then
	  menu=menues[m.menu]
	  menu_slot=m.slot
   menu_hint_y=1000
	 elseif m.cmd=="title" then
	  music(-1)
	  start_title(15)
	  return
	 end
 end
 
 if not m.locked then
  if btnp(⬆️) then
   menu_slot-=1
   sfx(30,3)
   menu_hint_y=1000
  elseif btnp(⬇️) then
   menu_slot+=1
   sfx(30,3)
   menu_hint_y=1000
  end
 end
 menu_slot=(menu_slot-1)%#menu+1
 desc_text1=menu[menu_slot].desc
 if menu[menu_slot].mode then
  desc_text2=hiscores[menu[menu_slot].mode].." FT"
 else
  desc_text2=nil
 end 
end


function draw_menu(mt)
	 
 for i=1,#menu do
  local mdesty=51+i*10-#menu*2
  if game_state>=3 then
   mdesty+=20
  end
  
  local my=ease_outquad(mt/10,128+mdesty,-128,1+i)
  local nx
  
  if game_state==0 or game_state>=3 or (i==menu_slot and tick%4>1) then
   nx=pr_c(menu[i].txt,64,my,i==menu_slot and 10 or 7,0)
	 end    
  
  if i==menu_slot and (game_state==0 or game_state>=3) then
   local adj=3.1*sin(wave_sync+time()*bpm)
   palt(9,true)
   palt(0,false)
   spr(83,63-nx-adj-3-10,my-1)
   spr(83,63+nx+adj-3+10,my-1,1,1,true)
   palt(9,false)
   palt(0,true)
  end
 end
 
 if game_state>=3 then
  draw_results(ease_outquad(mt/10,-43,86,2))
 end
 
 palt()
end

function draw_results(y)
 palt(0,false)
 palt(10,true)
 if game_state==3 then
  pal(8,3)
  pal(14,11)
  pal(15,7)
  pal(2,3)
 end
 spr(158,16,y,2,3)
 spr(158,95,y,2,3,true)
 sspr(127,80,1,12,32,y+8,64,12)
 spr(139+game_state,32,y+10)
 spr(139+game_state,89,y+10)
 pal()
 pr_c("^you've reached",64,y,7,1)
 pr_c(flr(pl.y*5).." ft",64,y+11,7)
 if game_state>=3 then
  pr_c(game_over_str,64,y+21,9,1)
 end
end

function draw_waves(y)
 pal_reset()
	local amp=7.2*sin(wave_sync+time()*bpm)
	
	for x=0,127 do
	 local tt=x/125+time()/2
		-- black
	 line(x,y+35+amp*sin(0.56+tt),
	      x,-10,0)
		-- orange
		local aa=amp*sin(0.5+tt)
	 line(x,y+31+aa,
	      x,-9,9)

		-- white
	 line(127-x,-y+106+amp*sin(0.441+tt),
	      127-x,128,7)
		-- red
	 line(127-x,-y+110+aa,
	      127-x,128,8)
	end
	
	if game_state>=3 then
 	local header=ltrs[game_state]
	 for i=1,#header do
	  spr(header[i],
	      57-4*#header+i*8,
	      y+10)
	 end
	end
	
end
-->8
-- easing

-- easing functions by robert penner
-- http://robertpenner.com/easing/

-- t = elapsed time
-- b = begin
-- c = change == ending - beginning
-- d = duration (total time)

function ease_inquad(t,b,c,d)
 if (t>=d) return b+c
	t=t/d
	return c * (t^2) + b
end

function ease_outquad(t,b,c,d)
 if (t>=d) return b+c
	t=t/d
	return -c * t * (t-2) + b
end

function ease_inquart(t,b,c,d)
 if (t>=d) return b+c
	t=t/d
	return c * (t^4) + b
end

function ease_outbounce(t, b, c, d)
 if (t>=d) return b+c
 t = t / d
 if t < 1 / 2.75 then
  return c * (7.5625 * t * t) + b
 elseif t < 2 / 2.75 then
  t = t - (1.5 / 2.75)
  return c * (7.5625 * t * t + 0.75) + b
 elseif t < 2.5 / 2.75 then
  t = t - (2.25 / 2.75)
  return c * (7.5625 * t * t + 0.9375) + b
 else
  t = t - (2.625 / 2.75)
  return c * (7.5625 * t * t + 0.984375) + b
 end
end


-->8
-- palette manipulation

function pal_reset()
 palette={}
 for i=0,15 do
  palette[i]=i
 end
 pal()
end

function pal_set(p)
 for i=0,15 do
  palette[i]=p[i]
  pal(i,palette[i])
 end
end

function pal_pal(c1,c2)
 palette[c1] = c2
 pal( c1, palette[c1] )
end

function pal_get()
 local p={}
 for i=0,15 do
  p[i]=palette[i]
 end
 
 return p
end


function pal_shift(iterations, ref_pal, scr)
 scr=scr or 0
 for i=0,15 do
  for j=1,iterations do
   palette[i]=ref_pal[palette[i]+1]
  end
  pal(i, palette[i], scr)
 end
end


-->8
-- intro
intro_fade_cols=explodeval"1,1,5,13,6,7,7"
intro_y=30
it=0
function start_intro()
 cls()
 sleep"15"
 fadetext(1,#intro_fade_cols)
 for i=0,1,0.05 do
  local x=min(1,i*3)
  pal()
  rectfill(0,44,127,72,0)
  if flr(i*100)==34 then
   pal(white_pal)
  end
  spr(138,48*x-16*(1-x),44,2,4)
  spr(140,128-64*x,44,2,4)
  flip()
  if (flr(i*100)==24) sfx"26"
 end
 sleep"5"
 spr(132,56,52,2,1)
 sleep"5"
 spr(155,56,52,2,1)
 sleep"45"

 for j=0,5 do
  pal_shift(1,dark_pal,1)
	 flip()
 end
 start_title"0"
end

function fadetext(a,b)
 for i=a,b,sgn(b-a) do
  cls()
  pr_c("made by",64,intro_y,intro_fade_cols[i])
  pr_c("johan & johan",64,intro_y+44,intro_fade_cols[i])
  sleep"2"
  intro_y+=0.5
 end
end

function sleep(ticks)
 for i=1,ticks do
  flip()
 end
end
