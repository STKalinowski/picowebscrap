-- scumm-8 (return of the scumm)
-- paul nicholas
show_debuginfo=false show_collision=false a=true show_perfinfo=false enable_mouse=true b=printh verbs={{{c="open"},text="open"},{{d="close"},text="close"},{{e="give"},text="give"},{{f="pickup"},text="pick-up"},{{g="lookat"},text="look-at"},{{i="talkto"},text="talk-to"},{{j="push"},text="push"},{{k="pull"},text="pull"},{{l="use"},text="use"}} verb_default={{m="walkto"},text="walk to"} function n() verb_maincol=12 verb_hovcol=7 verb_shadcol=1 verb_defcol=10 end o={data=[[
			map = {0,16}
		]],objects={},enter=function(p) cutscene(3,function() if not p.q then
print_line("return of the...",64,40,8,1) for x=1,11 do print_line(sub("   scumm",1,x),55,45,11,1,true) end change_room(r,1) else print_line("congratulations!:you've completed the game!",64,45,8,1) fades(1,1) while true do break_time(10) end end end) end,exit=function() end,} s={data=[[
					x=1
					y=1
					classes = {class_untouchable}
				]],draw=function(p) set_trans_col(8,true) map(56,23,136,60,6,1) end,} t={data=[[
					state=state_here
					x=80
					y=24
					w=1
					h=2
					state_here=47
					trans_col=8
					repeat_x = 8
					classes = {class_untouchable}
				]],} u={data=[[
					state=state_here
					x=176
					y=24
					w=1
					h=2
					state_here=47
					trans_col=8
					repeat_x = 8
					classes = {class_untouchable}
				]],} v={data=[[
					name = front door
					state=state_closed
					x=152
					y=8
					w=1
					h=3
					state_closed=78
					flip_x = true
					classes = {class_openable,class_door}
					use_dir = face_back
				]],init=function(p) p.target_door=ba end} bb={data=[[
					name = bucket
					state = state_open
					x=208
					y=48
					w=1
					h=1
					state_closed=143
					state_open = 159
					trans_col=15
					use_with=true
					classes = {class_pickupable}
				]],verbs={g=function(p) say_line("it's an old bucket") end,f=function(p) pickup_obj(p) end,l=function(p,bc) if bc==bd then
put_at(bd,0,0,be) put_at(bf,88,32,bg) bb.state="state_open"say_line("the fire's out now") elseif bc==bh then say_line("let's fill this up...") p.state="state_closed"p.name="full bucket"say_line("that's better!") end end}} r={data=[[
				map = {0,24,31,31}
			]],objects={s,t,u,v,bb},enter=function(p) if not p.bi then
p.bi=true selected_actor=bj put_at(selected_actor,30,55,r) camera_follow(selected_actor) cutscene(1,function() camera_at(144) camera_pan_to(selected_actor) wait_for_camera() say_line("wow! look at that old house:i wonder if anyone's home...") end) end end,exit=function(p) end,} ba={data=[[
					name = front door
					state = state_closed
					x=8
					y=16
					z=1
					w=1
					h=4
					state_closed=79
					classes = {class_openable}
					use_pos = pos_right
					use_dir = face_left
				]],verbs={m=function(p) come_out_door(p,v) end,c=function(p) open_door(p,v) end,d=function(p) close_door(p,v) end}} bk={data=[[
					name=clock
					x=32
					y=0
					w=2
					h=5
					z=2
				]],draw=function(p) set_trans_col(8,true) map(56,16,32,16,2,6) end,verbs={g=function(p) say_line("wow. that is impressive...:must've taken ages to code that!") end,}} bl={data=[[
					x=40
					y=20
					w=1
					z=1
				]],draw=function(p) rectfill(35,20,43,56,0) line(p.x,p.y,bl.bm,bl.bn,9) circfill(bl.bm,bl.bn,2) end} bo={data=[[
					x=1
					y=1 
					w=1
					h=1
					state=state_here
					state_here=3
					classes = {class_untouchable}
				]],draw=function(p) set_trans_col(8,true) map(56,23,68,52,6,1) end,} bp={data=[[
					state=state_here
					x=1
					y=1
					w=1
					h=2
					z=30
					state_here=3
					classes = {class_untouchable}
				]],draw=function(p) set_trans_col(8,true) map(59,19,100,12,4,4) end,} bq={data=[[
					name=upstairs
					state=state_open
					x=106
					y=0
					w=3
					h=2
					use_pos = pos_center
					use_dir = face_back
				]],verbs={m=function(p) come_out_door(p,br) end}} bs={data=[[
					name=library
					state=state_open
					x=136
					y=16
					w=1
					h=3
					use_dir = face_back
				]],verbs={m=function(p) come_out_door(p,bt) end}} bu={data=[[
					name = kitchen
					state = state_open
					x=176
					y=16
					w=1
					h=4
					use_pos = pos_left
					use_dir = face_right
				]],verbs={m=function(p) come_out_door(p,bv) end}} bw={data=[[
				map = {32,24,55,31}
				col_replace = {5,2}
			]],objects={bk,bl,ba,bo,bp,bq,bs,bu,},enter=function(p) start_script(p.scripts.bx,true) end,exit=function(p) stop_script(p.scripts.bx) end,scripts={bx=function() local by=0.5149 local bz=0 local ca=-10 local cb=false while true do local cc=-6.81/31*sin(by) bz+=cc*0.1*0.2 by+=bz*0.1 bl.bm=bl.x+sin(by)*31 bl.bn=bl.y-cos(by)*31 if by<=0.4850
and not cb then sfx(0) cb=true elseif by>=0.5140 and not cb then sfx(1) cb=true elseif by>0.49 and by<0.50 then cb=false end break_time() end end}} bt={data=[[
					name=hall
					state=state_open
					x=48
					y=16
					w=1
					h=3
					state_open=128
					use_dir = face_back
					classes = { class_door }
					lighting = 1
				]],init=function(p) p.target_door=bs end} cd={data=[[
					name=light switch
					state=state_here
					x=56
					y=23
					w=1
					h=1
					state_here=125
					lighting=0.6
				]],verbs={l=function(p) if p.ce then
bg.lighting=0.25 bt.lighting=1 cd.lighting=0.6 p.ce=false else bg.lighting=1 bt.lighting=0 cd.lighting=1 p.ce=true end end}} bd={data=[[
					name=fire
					x=88
					y=32
					w=1
					h=1
					state=1
					states={81,82,83}
					use_pos={97,42}
					lighting = 1
				]],verbs={g=function() say_line("it's a nice, warm fire...") break_time(10) do_anim(selected_actor,"anim_face","face_front") say_line("ouch! it's hot!:*stupid fire*") end,i=function() say_line("'hi fire...'") break_time(10) do_anim(selected_actor,"anim_face","face_front") say_line("the fire didn't say hello back:burn!!") end,f=function(p) pickup_obj(p) end}} cf={data=[[
					state=state_closed
					x=120
					y=16
					z=-1
					w=1
					h=3
					state_closed=80
					state_open=80
					classes = {class_untouchable}
					use_dir = face_back
				]],verbs={}} cg={data=[[
					name=secret passage
					state=state_closed
					x=120
					y=16
					z=-10
					w=1
					h=3
					state_closed=77
					use_dir = face_back
					dependent_on_state = state_open
				]],dependent_on=cf,dependent_on_state="state_open",verbs={m=function(p) o.q=true change_room(o,1) end}} ch={data=[[
					name=loose book
					state=state_gone
					x=136
					y=16
					w=1
					h=1
					state_gone=66
					state_here=65
					use_pos={144,40}
					classes = {class_pickupable}
				]],verbs={g=function(p) if p.state=="state_gone"then
say_line("this book sticks out") else say_line("it's a secret lock that was hidden behind the book") end end,k=function(p) p.state="state_here"p.name="secret lock"end,f=function(p) p.verbs.k(p) end}} bf={data=[[
					name=gold key
					state=state_gone
					x=1
					y=1
					z=30
					w=1
					h=1
					state_gone=32
					state_here=173
					use_with=true
					classes = {class_pickupable}
				]],verbs={g=function(p) say_line("it's a gold key") end,f=function(p) p.state="state_here"pickup_obj(p) end,l=function(p,bc) if(bc==ch) then
put_at(p,0,0,be) cf.state="state_open"shake(true) while(cf.y>-8) do cf.y-=1 break_time(10) end shake(false) end end,}} bg={data=[[
				map = {56,24,79,31}
				trans_col = 10
				col_replace={7,4}
				lighting=0.25
			]],objects={bt,cd,bd,cg,cf,ch},enter=function(p) start_script(p.scripts.ci,true) end,exit=function(p) stop_script(p.scripts.ci) end,scripts={ci=function() while true do for cj=1,3 do bd.state=cj break_time(8) end end end}} ck={data=[[
					name=spinning top
					x=148
					y=50
					w=1
					h=1
					state=1
					states={158,174,190}
					col_replace={12,7}
					trans_col=15
				]],scripts={cl=function() cm=-1 while true do for x=1,3 do for cj=1,3 do ck.state=cj break_time(4) end ck.x-=cm end cm*=-1 end end,},verbs={l=function(p) if script_running(p.scripts.cl) then
stop_script(p.scripts.cl) p.state=1 else start_script(p.scripts.cl) end end}} bv={data=[[
					name = hall
					state=state_open
					x=8
					y=16
					w=1
					h=4
					use_pos = pos_right
					use_dir = face_left
					classes = { class_door }
				]],init=function(p) p.target_door=bu end} cn={data=[[
					name=back door
					state=state_closed
					x=176
					y=16
					z=1
					w=1
					h=4
					state_closed=79
					flip_x=true
					classes = { class_openable, class_door }
					use_pos = pos_left
					use_dir = face_right
				]],init=function(p) p.target_door=co end} cp={data=[[
				map = {80,24,103,31}
			]],objects={ck,bv,cn},enter=function(p) start_script(p.scripts.cq,true) end,exit=function(p) stop_script(p.scripts.cq) end,scripts={cq=function() while true do if proximity(bj,cn)<40
and not cr.cs and cr.in_room==selected_actor.in_room then cr.cs=true cr.ct=true cutscene(2,function() stop_actor(selected_actor) say_line(cr,"stop!:come back here!",true) walk_to(selected_actor,cr.x-8,cr.y) do_anim(selected_actor,"anim_face",cr) cr.cs=false end) end break_time(10) end end,},} co={data=[[
					name=kitchen
					state=state_closed
					x=104
					y=8
					w=1
					h=3
					state_closed=78
					classes = { class_openable, class_door }
					use_dir = face_back
				]],init=function(p) p.target_door=cn end} bh={data=[[
					name=swimming pool
					x=96
					y=48
					w=3
					h=2
					use_pos = pos_above
					use_dir = face_front
				]],verbs={m=function(p) say_line("i can't swim!") end,g=function(p) say_line("it's filled with water") end,}} cu={data=[[
				map = {104,24,127,31}
			]],objects={co,bh,},enter=function() end,exit=function() end,} t={data=[[
					state=state_here
					x=0
					y=47
					w=1
					h=2
					state_here=47
					trans_col=8
					repeat_x = 16
					classes = { class_untouchable }
				]],} u={data=[[
					state=state_here
					x=144
					y=47
					w=1
					h=2
					state_here=47
					trans_col=8
					repeat_x = 6
					classes = { class_untouchable }
				]],} br={data=[[
					name=hall
					state=state_open
					x=124
					y=56
					w=3
					h=2
					use_pos = pos_center
					use_dir = face_front
					classes = { class_door }
				]],init=function(p) p.target_door=bq end} cv={data=[[
				name = computer room
				state = state_open
				x=176
				y=16
				w=1
				h=4
				use_pos = pos_left
				use_dir = face_right
				classes = { class_door }
			]],init=function(p) p.target_door=cw end} cx={data=[[
					name = door #1
					state = state_closed
					x=8
					y=16
					z=1
					w=1
					h=4
					state_closed=79
					state_open=0
					classes = {class_openable}
					use_pos = pos_right
					use_dir = face_left
				]],verbs={c=function(p) cy.scripts.cz(p,da) end}} db={data=[[
					name = door #2
					state = state_closed
					x=48
					y=16
					z=1
					w=1
					h=3
					state_closed=78
					classes = {class_openable}
					use_pos = pos_infront
					use_dir = face_back
				]],verbs={c=function(p) cy.scripts.cz(p,da) end}} da={data=[[
					name = door #3
					state = state_closed
					x=136
					y=16
					z=1
					w=1
					h=3
					state_closed=78
					state_open=0
					classes = {class_openable}
					use_pos = pos_infront
					use_dir = face_back
				]],verbs={c=function(p) cy.scripts.cz(p,cx) end}} cy={data=[[
				map = {32,16,55,31}
			]],objects={t,u,br,cx,db,da,cv},enter=function(p) end,exit=function(p) end,scripts={cz=function(dc,dd) cutscene(2,function() open_door(dc) break_time(10) put_at(selected_actor,0,0,be) close_door(dc) camera_pan_to(dd) wait_for_camera() open_door(dc,dd) break_time(10) come_out_door(dc,dd) close_door(dc,dd) camera_follow(selected_actor) end) end},} cw={data=[[
					name = first floor
					state=state_open
					x=8
					y=16
					w=1
					h=4
					use_pos = pos_right
					use_dir = face_left
					classes = { class_door }
				]],init=function(p) p.target_door=cv end} de={data=[[
					name=computer
					state=state_here
					state_here=1
					x=56
					y=16
					z=1
					w=2
					h=2
					use_pos={64,40}
					use_dir = face_back
				]],draw=function(p) set_trans_col(8,true) map(58,16,40,28,6,4,0x80) end,verbs={g=function(p) say_line("it's old \"286\" pc-compatible") end,l=function(p) p.cb=true change_room(df,1) end}} dg={data=[[
					x=56
					y=12
					w=1
					h=1
					trans_col=8
					state=1
					states={74,76}
					classes = {class_untouchable}
				]],verbs={}} dh={data=[[
					name=window
					state=state_closed
					x=32
					y=8
					w=2
					h=2
					state_closed=68
					state_open=70
					classes = {class_openable}
				]],verbs={c=function(p) p.state="state_open"end,d=function(p) p.state="state_closed"end,}} di={data=[[
					name=pico-8
					x=60
					y=44
					w=1
					h=1
					state=state_here
					state_here=189
					trans_col=11
					use_with=true
					classes={class_pickupable}
				]],verbs={g=function(p) say_line("it's a licenced copy of pico-8:\"a fantasy console for making, sharing and playing tiny games and other computer programs\":sounds like fun!") end,f=function(p) pickup_obj(p) end,l=function(p,bc) if(bc==de) then
say_line("there's already a disk inserted") end end,e=function(p,bc) if bc==cr then
say_line("do you like programming?") say_line(cr,"yes, why?") say_line("give pico-8 a go,;see what you can make") p.owner=cr say_line(cr,"this is perfect!",true) say_line(cr,"thank you!:i shall start making a game right now...") stop_script(cp.scripts.cq) walk_to(cr,bv.x+4,bv.y+30) put_at(cr,0,0,be) else say_line("i might need this") end end,}} dj={data=[[
				map = {64,16}
			]],objects={cw,de,dg,dh,di,},enter=function(p) start_script(p.scripts.dk,true) if de.cb then
de.cb=false cutscene(3,function() reload() n() selected_actor=bj camera_follow(selected_actor) do_anim(selected_actor,"anim_face","face_front") say_line("well, that was short!:developers are so lazy...") end) end end,exit=function(p) stop_script(p.scripts.dk) end,scripts={dk=function() while true do for cj=1,2 do dg.state=cj break_time(15) end end end},} df={data=[[
				map = {72,0}
			]],objects={},enter=function(p) reload(0,0x3b00,0x800) reload(0x3000,0x3a00,0x100) cutscene(3,function() break_time(50) print_line("deep in the caribbean:on the isle of...; ;thimbleweed!",64,45,8,1,true) change_room(dl,1) end) end,exit=function() end,} dm={data=[[
					x=0
					y=0
					w=1
					h=1
					z=-10
					classes = {class_untouchable}
					state=state_here
					state_here=1
				]],draw=function(p) map(88,0,0,16,40,7) end} dn={data=[[
					name=poster
					x=32
					y=40
					w=1
					h=1
				]],verbs={g=function(p) say_line("\"re-elect governor marly\"") end}} dp={data=[[
					name = door
					state=state_closed
					x=240
					y=40
					w=1
					h=2
					state_closed=43
					state_open=12
					classes = {class_openable}
					use_dir = face_back
				]],verbs={m=function(p) if p.state=="state_open"then
change_room(dj,1) else say_line("the door is closed") end end,c=function(p) open_door(p,ba) end,d=function(p) close_door(p,ba) end}} dl={data=[[
				map = {88,8,127,15}
				trans_col = 11
			]],objects={dm,dn,dp},enter=function(p) verb_maincol=11 verb_hovcol=10 verb_shadcol=0 verb_defcol=10 selected_actor=dq put_at(selected_actor,212,60,dl) camera_at(0) break_time(30) camera_pan_to(212,60) wait_for_camera() camera_follow(selected_actor) say_line("this all seems very famililar...") camera_follow(selected_actor) end,exit=function(p) end,} be={data=[[
			map = {0,0}
		]],objects={bf},} rooms={be,o,r,bw,cp,cu,bg,cy,dj,df,dl} bj={data=[[
			name = humanoid
			w = 1
			h = 4
			idle = { 193, 197, 199, 197 }
			talk = { 218, 219, 220, 219 }
			walk_anim_side = { 196, 197, 198, 197 }
			walk_anim_front = { 194, 193, 195, 193 }
			walk_anim_back = { 200, 199, 201, 199 }
			col = 12
			trans_col = 11
			walk_speed = 0.6
			frame_delay = 5
			classes = {class_actor}
			face_dir = face_front
		]],dr={ds},verbs={l=function(p) selected_actor=p camera_follow(p) end}} cr={data=[[
			name = purple tentacle
			x = 140
			y = 52
			w = 1
			h = 3
			idle = { 154, 154, 154, 154 }
			talk = { 171, 171, 171, 171 }
			col = 11
			trans_col = 15
			walk_speed = 0.4
			frame_delay = 5
			classes = {class_actor,class_talkable}
			face_dir = face_front
			use_pos = pos_left
		]],in_room=cp,dr={dt},verbs={g=function() say_line("it's a weird looking tentacle, thing!") end,i=function(p) cutscene(1,function() say_line(p,"what do you want?") end) while(true) do dialog_set({(not p.ct and""or"why did you stop me?"),(p.du and""or"where am i?"),(p.dv and""or"how much wood would a wood-chuck chuck, if a wood-chuck could chuck wood?"),"nevermind"}) dialog_start(selected_actor.col,7) while not selected_sentence do break_time() end dialog_hide() cutscene(1,function() say_line(selected_sentence.msg) if selected_sentence.num==1 then
say_line(p,"i need your help:i'm bored with this spinning top...:if you can you find something i can play with, i'd appreciate it") p.dw=true elseif selected_sentence.num==2 then say_line(p,"you are in paul's demo scumm-8 game, i think!") p.du=true elseif selected_sentence.num==3 then say_line(p,"a wood-chuck would chuck no amount of wood, coz a wood-chuck can't chuck wood!") p.dv=true elseif selected_sentence.num==4 then say_line(p,"ok bye!") dialog_end() return end end) dialog_clear() end end,l=function(p) selected_actor=p camera_follow(p) end}} dq={data=[[
			name = guybrush
			w = 1
			h = 2
			idle = { 47, 47, 15, 47 }
			walk_anim_side = { 44, 45, 44, 46 }
			col = 7
			trans_col = 8
			walk_speed = 0.5
			frame_delay = 8
			classes = {class_actor}
			face_dir = face_front
		]],dr={},verbs={}} actors={bj,cr,dq} function startup_script() n() change_room(o,1) end function shake(dx) if dx then
dy=1 end dz=dx end function ea(eb) local ec=nil if has_flag(eb.classes,"class_talkable") then
ec="talkto"elseif has_flag(eb.classes,"class_openable") then if eb.state=="state_closed"then
ec="open"else ec="close"end else ec="lookat"end for ed in all(verbs) do ee=get_verb(ed) if ee[2]==ec then ec=ed break end
end return ec end function ef(eg,eh,ei) local ej=has_flag(eh.classes,"class_actor") if eg=="walkto"then
return elseif eg=="pickup"then if ej then
say_line"i don't need them"else say_line"i don't need that"end elseif eg=="use"then if ej then
say_line"i can't just *use* someone"end if ei then
if has_flag(ei.classes,class_actor) then
say_line"i can't use that on someone!"else say_line"that doesn't work"end end elseif eg=="give"then if ej then
say_line"i don't think i should be giving this away"else say_line"i can't do that"end elseif eg=="lookat"then if ej then
say_line"i think it's alive"else say_line"looks pretty ordinary"end elseif eg=="open"then if ej then
say_line"they don't seem to open"else say_line"it doesn't seem to open"end elseif eg=="close"then if ej then
say_line"they don't seem to close"else say_line"it doesn't seem to close"end elseif eg=="push"or eg=="pull"then if ej then
say_line"moving them would accomplish nothing"else say_line"it won't budge!"end elseif eg=="talkto"then if ej then
say_line"erm... i don't think they want to talk"else say_line"i am not talking to that!"end else say_line"hmm. no."end end function camera_at(ek) el=em(ek) en=nil eo=nil end function camera_follow(ep) stop_script(eq) eo=ep en=nil eq=function() while eo do if eo.in_room==room_curr then
el=em(eo) end yield() end end start_script(eq,true) if eo.in_room!=room_curr then
change_room(eo.in_room,1) end end function camera_pan_to(ek) en=em(ek) eo=nil eq=function() while(true) do if el==en then
en=nil return elseif en>el then el+=0.5 else el-=0.5 end yield() end end start_script(eq,true) end function wait_for_camera() while script_running(eq) do yield() end end function cutscene(type,er,es) et={eu=type,ev=cocreate(er),ew=es,ex=eo} add(ey,et) ez=et break_time() end function dialog_set(fa) for msg in all(fa) do dialog_add(msg) end end function dialog_add(msg) if not fb then fb={fc={},fd=false} end
fe=ff(msg,32) fg=fh(fe) fi={num=#fb.fc+1,msg=msg,fe=fe,fj=fg} add(fb.fc,fi) end function dialog_start(col,fk) fb.col=col fb.fk=fk fb.fd=true selected_sentence=nil end function dialog_hide() fb.fd=false end function dialog_clear() fb.fc={} selected_sentence=nil end function dialog_end() fb=nil end function get_use_pos(eb) local fl=eb.use_pos local x=eb.x local y=eb.y if type(fl)=="table"then
x=fl[1] y=fl[2] elseif fl=="pos_left"then if eb.fm then
x-=(eb.w*8+4) y+=1 else x-=2 y+=((eb.h*8)-2) end elseif fl=="pos_right"then x+=(eb.w*8) y+=((eb.h*8)-2) elseif fl=="pos_above"then x+=((eb.w*8)/2)-4 y-=2 elseif fl=="pos_center"then x+=((eb.w*8)/2) y+=((eb.h*8)/2)-4 elseif fl=="pos_infront"or fl==nil then x+=((eb.w*8)/2)-4 y+=(eb.h*8)+2 end return{x=x,y=y} end function do_anim(ep,fn,fo) fp={"face_front","face_left","face_back","face_right"} if fn=="anim_face"then
if type(fo)=="table"then
fq=atan2(ep.x-fo.x,fo.y-ep.y) fr=93*(3.1415/180) fq=fr-fq fs=fq*360 fs=fs%360 if fs<0 then fs+=360 end
fo=4-flr(fs/90) fo=fp[fo] end face_dir=ft[ep.face_dir] fo=ft[fo] while face_dir!=fo do if face_dir<fo then
face_dir+=1 else face_dir-=1 end ep.face_dir=fp[face_dir] ep.flip=(ep.face_dir=="face_left") break_time(10) end end end function open_door(fu,fv) if fu.state=="state_open"then
say_line"it's already open"else fu.state="state_open"if fv then fv.state="state_open"end
end end function close_door(fu,fv) if fu.state=="state_closed"then
say_line"it's already closed"else fu.state="state_closed"if fv then fv.state="state_closed"end
end end function come_out_door(fw,fx,fy) if fx==nil then
fz("target door does not exist") return end if fw.state=="state_open"then
ga=fx.in_room if ga!=room_curr then
change_room(ga,fy) end local gb=get_use_pos(fx) put_at(selected_actor,gb.x,gb.y,ga) gc={face_front="face_back",face_left="face_right",face_back="face_front",face_right="face_left"} if fx.use_dir then
gd=gc[fx.use_dir] else gd=1 end selected_actor.face_dir=gd selected_actor.flip=(selected_actor.face_dir=="face_left") else say_line("the door is closed") end end function fades(ge,gf) if gf==1 then
gg=0 else gg=50 end while true do gg+=gf*2 if gg>50
or gg<0 then return end if ge==1 then
gh=min(gg,32) end yield() end end function change_room(ga,ge) if ga==nil then
fz("room does not exist") return end stop_script(gi) if ge and room_curr then
fades(ge,1) end if room_curr and room_curr.exit then
room_curr.exit(room_curr) end gj={} gk() room_curr=ga if not eo
or eo.in_room!=room_curr then el=0 end stop_talking() if ge then
gi=function() fades(ge,-1) end start_script(gi,true) else gh=0 end if room_curr.enter then
room_curr.enter(room_curr) end end function valid_verb(eg,gl) if not gl
or not gl.verbs then return false end if type(eg)=="table"then
if gl.verbs[eg[1]] then return true end
else if gl.verbs[eg] then return true end
end return false end function pickup_obj(eb,ep) ep=ep or selected_actor add(ep.gm,eb) eb.owner=ep del(eb.in_room.objects,eb) end function start_script(gn,go,gp,gq) local ev=cocreate(gn) local scripts=gj if go then
scripts=gr end add(scripts,{gn,ev,gp,gq}) end function script_running(gn) for gs in all({gj,gr}) do for gt,gu in pairs(gs) do if gu[1]==gn then
return gu end end end return false end function stop_script(gn) gu=script_running(gn) if gu then
del(gj,gu) del(gr,gu) end end function break_time(gv) gv=gv or 1 for x=1,gv do yield() end end function wait_for_message() while gw!=nil do yield() end end function say_line(ep,msg,gx,gy) if type(ep)=="string"then
msg=ep ep=selected_actor end gz=ep.y-(ep.h)*8+4 ha=ep print_line(msg,ep.x,gz,ep.col,1,gx,gy) end function stop_talking() gw,ha=nil,nil end function print_line(msg,x,y,col,hb,gx,gy) local col=col or 7 local hb=hb or 0 if hb==1 then
hc=min(x-el,127-(x-el)) else hc=127-(x-el) end local hd=max(flr(hc/2),16) local he=""for hf=1,#msg do local hg=sub(msg,hf,hf) if hg==":"then
he=sub(msg,hf+1) msg=sub(msg,1,hf-1) break end end local fe=ff(msg,hd) local fg=fh(fe) hh=x-el if hb==1 then
hh-=((fg*4)/2) end hh=max(2,hh) gz=max(18,y) hh=min(hh,127-(fg*4)-1) gw={hi=fe,x=hh,y=gz,col=col,hb=hb,hj=(#msg)*8,fj=fg,gx=gx} if#he>0 then
hk=ha wait_for_message() ha=hk print_line(he,x,y,col,hb,gx) end if not gy then
wait_for_message() end end function put_at(eb,x,y,hl) if hl then
if not has_flag(eb.classes,"class_actor") then
if eb.in_room then del(eb.in_room.objects,eb) end
add(hl.objects,eb) eb.owner=nil end eb.in_room=hl end eb.x,eb.y=x,y end function stop_actor(ep) ep.hm=0 gk() end function walk_to(ep,x,y) local hn=ho(ep) local hp=flr(x/8)+room_curr.map[1] local hq=flr(y/8)+room_curr.map[2] local hr={hp,hq} local hs=ht(hn,hr) ep.hm=1 for hu in all(hs) do local hv=(hu[1]-room_curr.map[1])*8+4 local hw=(hu[2]-room_curr.map[2])*8+4 local hx=sqrt((hv-ep.x)^2+(hw-ep.y)^2) local hy=ep.walk_speed*(hv-ep.x)/hx local hz=ep.walk_speed*(hw-ep.y)/hx if ep.hm==0 then
return end if hx>5 then
ep.flip=(hy<0) if abs(hy)<0.4 then
if hz>0 then
ep.ia=ep.walk_anim_front ep.face_dir="face_front"else ep.ia=ep.walk_anim_back ep.face_dir="face_back"end else ep.ia=ep.walk_anim_side ep.face_dir="face_right"if ep.flip then ep.face_dir="face_left"end
end for hf=0,hx/ep.walk_speed do ep.x+=hy ep.y+=hz yield() end end end ep.hm=2 end function wait_for_actor(ep) ep=ep or selected_actor while ep.hm!=2 do yield() end end function proximity(eh,ei) if eh.in_room==ei.in_room then
local hx=sqrt((eh.x-ei.x)^2+(eh.y-ei.y)^2) return hx else return 1000 end end ib=16 el,en,eq,dy=0,nil,nil,0 ic,id,ie,ig=63.5,63.5,0,1 ih={7,12,13,13,12,7} ii={{spr=208,x=75,y=ib+60},{spr=240,x=75,y=ib+72}} ft={face_front=1,face_left=2,face_back=3,face_right=4} function ij(eb) local ik={} for gt,ed in pairs(eb) do add(ik,gt) end return ik end function get_verb(eb) local eg={} local ik=ij(eb[1]) add(eg,ik[1]) add(eg,eb[1][ik[1]]) add(eg,eb.text) return eg end function gk() il=get_verb(verb_default) im,io,ip,iq,ir=nil,nil,nil,false,""end gk() gw=nil fb=nil ez=nil ha=nil gr={} gj={} ey={} is={} gh,gh=0,0 it=0 function _init() if enable_mouse then poke(0x5f2d,1) end
iu() start_script(startup_script,true) end function _update60() iv() end function _draw() iw() end function iv() if selected_actor and selected_actor.ev
and not coresume(selected_actor.ev) then selected_actor.ev=nil end ix(gr) if ez then
if ez.ev
and not coresume(ez.ev) then if ez.eu!=3
and ez.ex then camera_follow(ez.ex) selected_actor=ez.ex end del(ey,ez) if#ey>0 then
ez=ey[#ey] else if ez.eu!=2 then
it=3 end ez=nil end end else ix(gj) end iy() iz() ja,jb=1.5-rnd(3),1.5-rnd(3) ja=flr(ja*dy) jb=flr(jb*dy) if not dz then
dy*=0.90 if dy<0.05 then dy=0 end
end end function iw() rectfill(0,0,127,127,0) camera(el+ja,0+jb) clip(0+gh-ja,ib+gh-jb,128-gh*2-ja,64-gh*2) jc() camera(0,0) clip() if show_perfinfo then
print("cpu: "..flr(100*stat(1)).."%",0,ib-16,8) print("mem: "..flr(stat(0)/1024*100).."%",0,ib-8,8) end if show_debuginfo then
print("x: "..flr(ic+el).." y:"..id-ib,80,ib-8,8) end jd() if fb
and fb.fd then je() jf() return end if it>0 then
it-=1 return end if not ez then
jg() end if(not ez
or ez.eu==2) and it==0 then jh() else end if not ez then
jf() end end function iy() if ez then
if btnp(4) and btnp(5) and ez.ew then
ez.ev=cocreate(ez.ew) ez.ew=nil return end return end if btn(0) then ic-=1 end
if btn(1) then ic+=1 end
if btn(2) then id-=1 end
if btn(3) then id+=1 end
if btnp(4) then ji(1) end
if btnp(5) then ji(2) end
if enable_mouse then
jj,jk=stat(32)-1,stat(33)-1 if jj!=jl then ic=jj end
if jk!=jm then id=jk end
if stat(34)>0 then
if not jn then
ji(stat(34)) jn=true end else jn=false end jl=jj jm=jk end ic=mid(0,ic,127) id=mid(0,id,127) end function ji(jo) local jp=il if not selected_actor then
return end if fb and fb.fd then
if jq then
selected_sentence=jq end return end if jr then
il=get_verb(jr) elseif js then if jo==1 then
if(il[2]=="use"or il[2]=="give")
and im then io=js else im=js end elseif jt then il=get_verb(jt) im=js ij(im) jg() end elseif ju then if ju==ii[1] then
if selected_actor.jv>0 then
selected_actor.jv-=1 end else if selected_actor.jv+2<flr(#selected_actor.gm/4) then
selected_actor.jv+=1 end end return end if im!=nil
then if il[2]=="use"or il[2]=="give"then
if io then
elseif im.use_with and im.owner==selected_actor then return end end iq=true selected_actor.ev=cocreate(function() if(not im.owner
and(not has_flag(im.classes,"class_actor") or il[2]!="use")) or io then jw=io or im jx=get_use_pos(jw) walk_to(selected_actor,jx.x,jx.y) if selected_actor.hm!=2 then return end
use_dir=jw if jw.use_dir then use_dir=jw.use_dir end
do_anim(selected_actor,"anim_face",use_dir) end if valid_verb(il,im) then
start_script(im.verbs[il[1]],false,im,io) else if has_flag(im.classes,"class_door") then
if il[2]=="walkto"then
come_out_door(im,im.target_door) elseif il[2]=="open"then open_door(im,im.target_door) elseif il[2]=="close"then close_door(im,im.target_door) end else ef(il[2],im,io) end end gk() end) coresume(selected_actor.ev) elseif id>ib and id<ib+64 then iq=true selected_actor.ev=cocreate(function() walk_to(selected_actor,ic+el,id-ib) gk() end) coresume(selected_actor.ev) end end function iz() if not room_curr then
return end jr,jt,js,jq,ju=nil,nil,nil,nil,nil if fb
and fb.fd then for gs in all(fb.fc) do if jy(gs) then
jq=gs end end return end jz() for eb in all(room_curr.objects) do if(not eb.classes
or(eb.classes and not has_flag(eb.classes,"class_untouchable"))) and(not eb.dependent_on or eb.dependent_on.state==eb.dependent_on_state) then ka(eb,eb.w*8,eb.h*8,el,kb) else eb.kc=nil end if jy(eb) then
if not js
or(not eb.z and js.z<0) or(eb.z and js.z and eb.z>js.z) then js=eb end end kd(eb) end for gt,ep in pairs(actors) do if ep.in_room==room_curr then
ka(ep,ep.w*8,ep.h*8,el,kb) kd(ep) if jy(ep)
and ep!=selected_actor then js=ep end end end if selected_actor then
for ed in all(verbs) do if jy(ed) then
jr=ed end end for ke in all(ii) do if jy(ke) then
ju=ke end end for gt,eb in pairs(selected_actor.gm) do if jy(eb) then
js=eb if il[2]=="pickup"and js.owner then
il=nil end end if eb.owner!=selected_actor then
del(selected_actor.gm,eb) end end if il==nil then
il=get_verb(verb_default) end if js then
jt=ea(js) end end end function jz() is={} for x=-64,64 do is[x]={} end end function kd(eb) gz=-1 if eb.kf then
gz=eb.y else gz=eb.y+(eb.h*8) end kg=flr(gz) if eb.z then
kg=eb.z end add(is[kg],eb) end function jc() if not room_curr then
print("-error-  no current room set",5+el,5+ib,8,0) return end rectfill(0,ib,127,ib+64,room_curr.kh or 0) for z=-64,64 do if z==0 then
ki(room_curr) if room_curr.trans_col then
palt(0,false) palt(room_curr.trans_col,true) end map(room_curr.map[1],room_curr.map[2],0,ib,room_curr.kj,room_curr.kk) pal() else kg=is[z] for eb in all(kg) do if not has_flag(eb.classes,"class_actor") then
if eb.states
or(eb.state and eb[eb.state] and eb[eb.state]>0) and(not eb.dependent_on or eb.dependent_on.state==eb.dependent_on_state) and not eb.owner or eb.draw then kl(eb) end else if eb.in_room==room_curr then
km(eb) end end kn(eb) end end end end function ki(eb) if eb.col_replace then
ko=eb.col_replace pal(ko[1],ko[2]) end if eb.lighting then
kp(eb.lighting) elseif eb.in_room and eb.in_room.lighting then kp(eb.in_room.lighting) end end function kl(eb) ki(eb) if eb.draw then
eb.draw(eb) else kq=1 if eb.repeat_x then kq=eb.repeat_x end
for h=0,kq-1 do local kr=0 if eb.states then
kr=eb.states[eb.state] else kr=eb[eb.state] end ks(kr,eb.x+(h*(eb.w*8)),eb.y,eb.w,eb.h,eb.trans_col,eb.flip_x) end end pal() end function km(ep) kt=ft[ep.face_dir] if ep.hm==1
and ep.ia then ep.ku+=1 if ep.ku>ep.frame_delay then
ep.ku=1 ep.kv+=1 if ep.kv>#ep.ia then ep.kv=1 end
end kw=ep.ia[ep.kv] else kw=ep.idle[kt] end ki(ep) ks(kw,ep.fm,ep.kf,ep.w,ep.h,ep.trans_col,ep.flip,false) if ha
and ha==ep and ha.talk then if ep.kx<7 then
kw=ep.talk[kt] ks(kw,ep.fm,ep.kf+8,1,1,ep.trans_col,ep.flip,false) end ep.kx+=1 if ep.kx>14 then ep.kx=1 end
end pal() end function jg() ky=""kz=12 la=il[2] if il then
ky=il[3] end if im then
ky=ky.." "..im.name if la=="use"then
ky=ky.." with"elseif la=="give"then ky=ky.." to"end end if io then
ky=ky.." "..io.name elseif js and js.name!=""and(not im or(im!=js)) and(not js.owner or la!=get_verb(verb_default)[2]) then ky=ky.." "..js.name end ir=ky if iq then
ky=ir kz=7 end print(lb(ky),lc(ky),ib+66,kz) end function jd() if gw then
ld=0 for le in all(gw.hi) do lf=0 if gw.hb==1 then
lf=((gw.fj*4)-(#le*4))/2 end lg(le,gw.x+lf,gw.y+ld,gw.col,0,gw.gx) ld+=6 end gw.hj-=1 if gw.hj<=0 then
stop_talking() end end end function jh() hh,gz,lh=0,75,0 for ed in all(verbs) do li=verb_maincol if jt
and ed==jt then li=verb_defcol end if ed==jr then li=verb_hovcol end
ee=get_verb(ed) print(ee[3],hh,gz+ib+1,verb_shadcol) print(ee[3],hh,gz+ib,li) ed.x=hh ed.y=gz ka(ed,#ee[3]*4,5,0,0) kn(ed) if#ee[3]>lh then lh=#ee[3] end
gz+=8 if gz>=95 then
gz=75 hh+=(lh+1.0)*4 lh=0 end end if selected_actor then
hh,gz=86,76 lj=selected_actor.jv*4 lk=min(lj+8,#selected_actor.gm) for ll=1,8 do rectfill(hh-1,ib+gz-1,hh+8,ib+gz+8,1) eb=selected_actor.gm[lj+ll] if eb then
eb.x,eb.y=hh,gz kl(eb) ka(eb,eb.w*8,eb.h*8,0,0) kn(eb) end hh+=11 if hh>=125 then
gz+=12 hh=86 end ll+=1 end for hf=1,2 do lm=ii[hf] if ju==lm then pal(verb_maincol,7) end
ks(lm.spr,lm.x,lm.y,1,1,0) ka(lm,8,7,0,0) kn(lm) pal() end end end function je() hh,gz=0,70 for gs in all(fb.fc) do if gs.fj>0 then
gs.x,gs.y=hh,gz ka(gs,gs.fj*4,#gs.fe*5,0,0) li=fb.col if gs==jq then li=fb.fk end
for le in all(gs.fe) do print(lb(le),hh,gz+ib,li) gz+=5 end kn(gs) gz+=2 end end end function jf() col=ih[ig] pal(7,col) spr(224,ic-4,id-3,1,1,0) pal() ie+=1 if ie>7 then
ie=1 ig+=1 if ig>#ih then ig=1 end
end end function ks(ln,x,y,w,h,lo,flip_x,lp) set_trans_col(lo,true) spr(ln,x,ib+y,w,h,flip_x,lp) end function set_trans_col(lo,dx) palt(0,false) palt(lo,true) if lo and lo>0 then
palt(0,false) end end function iu() for hl in all(rooms) do lq(hl) if(#hl.map>2) then
hl.kj=hl.map[3]-hl.map[1]+1 hl.kk=hl.map[4]-hl.map[2]+1 else hl.kj=16 hl.kk=8 end for eb in all(hl.objects) do lq(eb) eb.in_room=hl eb.h=eb.h or 0 if eb.init then
eb.init(eb) end end end for lr,ep in pairs(actors) do lq(ep) ep.hm=2 ep.ku=1 ep.kx=1 ep.kv=1 ep.gm={} ep.jv=0 end end function kn(eb) local lt=eb.kc if show_collision
and lt then rect(lt.x,lt.y,lt.lu,lt.lv,8) end end function ix(scripts) for gu in all(scripts) do if gu[2] and not coresume(gu[2],gu[3],gu[4]) then
del(scripts,gu) gu=nil end end end function kp(lw) if lw then lw=1-lw end
local hu=flr(mid(0,lw,1)*100) local lx={0,1,1,2,1,13,6,4,4,9,3,13,1,13,14} for ly=1,15 do col=ly lz=(hu+(ly*1.46))/22 for gt=1,lz do col=lx[col] end pal(ly,col) end end function em(ek) if type(ek)=="table"then
ek=ek.x end return mid(0,ek-64,(room_curr.kj*8)-128) end function ho(eb) local hp=flr(eb.x/8)+room_curr.map[1] local hq=flr(eb.y/8)+room_curr.map[2] return{hp,hq} end function ma(hp,hq) local mb=mget(hp,hq) local mc=fget(mb,0) return mc end function ff(msg,hd) local fe={} local md=""local me=""local hg=""local mf=function(mg) if#me+#md>mg then
add(fe,md) md=""end md=md..me me=""end for hf=1,#msg do hg=sub(msg,hf,hf) me=me..hg if hg==" "
or#me>hd-1 then mf(hd) elseif#me>hd-1 then me=me.."-"mf(hd) elseif hg==";"then md=md..sub(me,1,#me-1) me=""mf(0) end end mf(hd) if md!=""then
add(fe,md) end return fe end function fh(fe) fg=0 for le in all(fe) do if#le>fg then fg=#le end
end return fg end function has_flag(eb,mh) for mi in all(eb) do if mi==mh then
return true end end return false end function ka(eb,w,h,mj,mk) x=eb.x y=eb.y if has_flag(eb.classes,"class_actor") then
eb.fm=x-(eb.w*8)/2 eb.kf=y-(eb.h*8)+1 x=eb.fm y=eb.kf end eb.kc={x=x,y=y+ib,lu=x+w-1,lv=y+h+ib-1,mj=mj,mk=mk} end function ht(ml,mm) local mn,mo,mp,mq,mr={},{},{},nil,nil ms(mn,ml,0) mo[mt(ml)]=nil mp[mt(ml)]=0 while#mn>0 and#mn<1000 do local mu=mn[#mn] del(mn,mn[#mn]) mv=mu[1] if mt(mv)==mt(mm) then
break end local mw={} for x=-1,1 do for y=-1,1 do if x==0 and y==0 then
else local mx=mv[1]+x local my=mv[2]+y if abs(x)!=abs(y) then mz=1 else mz=1.4 end
if mx>=room_curr.map[1] and mx<=room_curr.map[1]+room_curr.kj
and my>=room_curr.map[2] and my<=room_curr.map[2]+room_curr.kk and ma(mx,my) and((abs(x)!=abs(y)) or ma(mx,mv[2]) or ma(mx-x,my)) then add(mw,{mx,my,mz}) end end end end for na in all(mw) do local nb=mt(na) local nc=mp[mt(mv)]+na[3] if not mp[nb]
or nc<mp[nb] then mp[nb]=nc local h=max(abs(mm[1]-na[1]),abs(mm[2]-na[2])) local nd=nc+h ms(mn,na,nd) mo[nb]=mv if not mq
or h<mq then mq=h mr=nb ne=na end end end end local hs={} mv=mo[mt(mm)] if mv then
add(hs,mm) elseif mr then mv=mo[mr] add(hs,ne) end if mv then
local nf=mt(mv) local ng=mt(ml) while nf!=ng do add(hs,mv) mv=mo[nf] nf=mt(mv) end for hf=1,#hs/2 do local nh=hs[hf] local ni=#hs-(hf-1) hs[hf]=hs[ni] hs[ni]=nh end end return hs end function ms(nj,ek,hu) if#nj>=1 then
add(nj,{}) for hf=(#nj),2,-1 do local na=nj[hf-1] if hu<na[2] then
nj[hf]={ek,hu} return else nj[hf]=na end end nj[1]={ek,hu} else add(nj,{ek,hu}) end end function mt(nk) return((nk[1]+1)*16)+nk[2] end function fz(msg) print_line("-error-;"..msg,5+el,5,8,0) end function lq(eb) local fe=nl(eb.data,"\n") for le in all(fe) do local pairs=nl(le,"=") if#pairs==2 then
eb[pairs[1]]=nm(pairs[2]) else printh("invalid data line") end end end function nl(gs,nn) local no={} local lj=0 local np=0 for hf=1,#gs do local nq=sub(gs,hf,hf) if nq==nn then
add(no,sub(gs,lj,np)) lj=0 np=0 elseif nq!=" "and nq!="\t"then np=hf if lj==0 then lj=hf end
end end if lj+np>0 then
add(no,sub(gs,lj,np)) end return no end function nm(nr) local ns=sub(nr,1,1) local no=nil if nr=="true"then
no=true elseif nr=="false"then no=false elseif nt(ns) then if ns=="-"then
no=sub(nr,2,#nr)*-1 else no=nr+0 end elseif ns=="{"then local nh=sub(nr,2,#nr-1) no=nl(nh,",") nu={} for ek in all(no) do ek=nm(ek) add(nu,ek) end no=nu else no=nr end return no end function nt(ko) for nv=1,13 do if ko==sub("0123456789.-+",nv,nv) then
return true end end end function lg(nw,x,y,nx,ny,gx) if not gx then nw=lb(nw) end
for nz=-1,1 do for oa=-1,1 do print(nw,x+nz,y+oa,ny) end end print(nw,x,y,nx) end function lc(gs) return 63.5-flr((#gs*4)/2) end function ob(gs) return 61 end function jy(eb) if not eb.kc
or ez then return false end kc=eb.kc if(ic+kc.mj>kc.lu or ic+kc.mj<kc.x)
or(id>kc.lv or id<kc.y) then return false else return true end end function lb(gs) local nv=""local le,ko,nj=false,false for hf=1,#gs do local ke=sub(gs,hf,hf) if ke=="^"then
if ko then nv=nv..ke end
ko=not ko elseif ke=="~"then if nj then nv=nv..ke end
nj,le=not nj,not le else if ko==le and ke>="a"and ke<="z"then
for ly=1,26 do if ke==sub("abcdefghijklmnopqrstuvwxyz",ly,ly) then
ke=sub("ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\",ly,ly) break end end end nv=nv..ke ko,nj=false,false end end return nv end
if(_update60)_update=function()_update60()_update_buttons()_update60()end