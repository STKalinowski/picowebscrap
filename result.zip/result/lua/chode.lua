--chode
--by hubol

x = 32 y = 8
hsp = 0
vsp = 0
img = 0
runimg = 0
lastrun = 0
xsc = 1

letters = {{5,9,17},{7,9,18},{8,9,19},{9,9,20},{10,9,21},{7,10,22},{8,10,19},{9,10,23}}
hearts = {{14,13},{2,3},{11,2},{5,15},{8,11},{1,10},{8,11}}
points = 0

	function _update()
	 left = btn(0)
	 right = btn(1)
	 up = btn(2)
	 if (left) hsp = max(-2, hsp - 3)
	 if (right) hsp = min(2, hsp + 3)

	 if (up and vsp < 0) vsp -= .2
	 if (up and solid(x, y, 0, 1) and not solid(x, y, 0, -1)) vsp = -4 sfx(7)
	 
	 if (not left and hsp < 0) hsp = min(0, hsp + 4)
	 if (not right and hsp > 0) hsp = max(0, hsp - 4)
	 
	 safety()
	 
	 vsp=min(vsp+.7, 8)
	 down = btn(3)
	 if (down and not up) vsp+=.3
	 
	 did=false
	 
	 safety()
	 
	 h = sign(hsp)
	 for i = 0,abs(hsp) do
	  if (not solid(x, y, h, 0) and h~=0) then x+=h safety() else h=0 hsp=0 end
	 end
	 
	 v = sign(vsp)
	 for i = 0, abs(vsp) do
	  if (not solid(x, y, 0, v) and v~=0) then y+=v safety() else v=0 vsp=0 end
	 end
	 
	 temp = sign(hsp)
	 if (hsp~=0) xsc = temp
	 
	 if (vsp==0) then
	  if (hsp==0) then
	   img = 1
	  else
	   runimg=(runimg+abs(hsp/5))%4
	   temp=flr(runimg)
	   if (temp%2==0 and lastrun!=temp) sfx(6)
	   lastrun=temp
	   if (temp==0 or temp==2) img=2
	   if (temp==1) img=3
	   if (temp==3) img=4
	  end
	 else
	  if (vsp==0) then
	   if (hsp==0) then img=5 else img=6 end
	  else
	   if (hsp==0) then img=8 else img=9 end
	  end
	 end 
	 
	 if (down and img < 7) then
	  if (vsp==0 and hsp==0) img = 7
	  if (vsp!=0 and hsp==0) img = 8
	  if (vsp!=0 and hsp!=0) img = 9
	 end
	 
	 heart() 
	end
	
function heart()
 if (at(x,y,0,0,7)) then
 points+=1
 clear()
 sfx(8)
 if (points < 8) then mset(hearts[points][1],hearts[points][2],16) else
 music(0)
 end
 mset(letters[points][1],letters[points][2],letters[points][3])
end
end

function clear()
for xx=0,16 do
for yy=0,16 do
if (mget(xx,yy)==16) then mset(xx,yy,0) end
end
end
end
	
function safety()
 if (x > 128) then x-=128 end
	if (x < 0) then x+=128
end
	if (y >128) then y-=128
end
	if (y<0) then y+=128 end
end

function solid(x,y,h,v)
 return at(x,y,h,v,1)
end

function at(x, y, h, v, id)
 return fuck(x, y, h, v,id) or fuck(x+128,y,h,v,id) or fuck(x-128,y,h,v,id) or fuck(x,y+128,h,v,id) or fuck(x,y-128,h,v,id)
end

function fuck(x, y, h, v,id)
 x += h
 y += v
 x /= 8
 y /= 8
 return test(flr(x), flr(y),id) or test(ceil(x), ceil(y),id) or test(flr(x), ceil(y),id) or test(ceil(x), flr(y),id)
end

function ceil(x)
 part = x % 1.0
 if (part ==0) then
  return flr(x)
 else
  return 1 + flr(x)
 end
end

function test(x, y, id)
	return fget(mget(x,y), id)
end

function sign(x)
 if (x == 0) return 0
 if (abs(x) == x) return 1
 return -1
end

function me(ax, ay)
 spr(img, x+ax, y+ay, 1, 1, xsc==-1)
end

	function _draw()
	 color(10)
	 rectfill(0,0,128,128)
	 mapdraw (0,0,0,0,128,128)
		me(0,0)
		me(128,0)
		me(-128,0)
		me(0,128)
		me(0,-128)
	end










