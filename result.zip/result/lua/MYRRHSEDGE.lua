-- myrrh's edge
-- by three unwise men
-- a religious parkour game
-------------------------------
-- design/sfx: that tom hall
-- code: squirrel eiserloh
-- art / anims: toby hefflin
-- also featuring
--  music: gruber
-------------------------------

cls(0)

spr_player = 64
spr_key = 47
spr_myrrh = 44
spr_star = 27
spr_fire = 106
spr_stairs_up = 31
spr_stairs_down = 20
spr_door_open = 22
spr_door_locked = 23
spr_wire = 10
spr_wire_end = 13
spr_zip_top = 11
spr_zip_bottom = 12
spr_zip_end = 13
spr_slide1 = 116
spr_slide2 = 117
spr_melee_idle = 95
spr_sheep_idle = 101
spr_mouse_idle = 76

sfx_title = 54
sfx_jump = 5
sfx_getkey = 53
sfx_getmyrrh = 6
sfx_open_y = 7
sfx_open_n = 1
sfx_door = 46
sfx_zip = 7
sfx_wire = 7
sfx_charge = 49
sfx_hit = 45

bit_solid_u = 0
bit_solid_r = 1
bit_solid_l = 2
bit_solid_d = 3
bit_ladder = 5

g_pr = 3
g_grab_ladder_dist_x = 3
g_walk_vx = 1
g_wjump_vx = 50
g_wjump_vy = 65
g_wjump_dist = 4
g_max_wally_vy = 60
g_max_speed = 0.95 * g_pr * 60
g_zip_vx = 70
g_zip_vy = 35
g_zip_jump_vx = 50
g_zip_jump_vy = 65
g_awn_vx = 75
g_awn_vy = 75
g_air_friction_x = 1.0
g_air_control = 0.5
g_slide_min_vx = 40
g_slide_max_vx = 70
g_wall_jump_delay = 10
g_player_max_runx = 50
g_melee_see_x = 60
g_melee_see_y = 3
g_melee_walk_dx = 0.3
g_melee_charge_dx = 1.2
g_min_myrrh = 50
g_hs_myrrh = 0
g_hs_time = 9999.9

g_state = "title"
g_actordefs = {}
g_actors = {}
g_layers = { fg={}, mid={}, bg={} }
g_buckets = {}
g_nbuckets = 6
g_player = nil
g_time = 0.0
g_frame = 0
g_sign = { fr=0, msg1="", msg2="", wx=0, wy=0 }
g_track_col = 12

g_signs = {
 { 20,46,"bethlehem inn","no vacancy" },
 { 39,46,"sunshade market","sheep 4 cheap!" },
 { 35,23,"guard watchtower","watch guards beat thieves!" },
 { 125,7,"grain silo","hayyyyyy" },
 { 17,36,"tenements","much better than ninements" },
 { 125,51,"king herod sux","" },
 { 126,42,"town myrrh storage","do not take" },
 { 2,51,"cave","of souls" },
 { 54,61,"cave of","the lost" },
 { 79,62,"cave of","gentle winds" },
 { 87,62,"tomb of","zombie bill myrrhy" },
 { 100,32,"manger","(that's a feeding trough, btw)" },
 { 73,9,"getting good at","wall-jumping, huh?" },
 { 111,30,"baby jesus's xmas wish:","50 myrrh"}
}

g_snarkers = { "caspar", "melchior", "mary", "joseph", "jesus", "sheep", "fruit" }
g_snark_xys = { {113,30}, {114,30}, {116.7,30.25}, {117.3,30.25}, {116,30}, {119,29}, {110,29.25} }
g_snarks = {
 {1,"gold, frankincense, and"      ,"a heartfelt apology"},
 {2,"what happened, did your"      ,"sundial break again?"},
 {1,"you had one job, bal."        ,"one.  job."},
 {2,"i'm sure next time a savior"  ,"is born you'll make it on time"},
 {1,"it's cool, we put a crown on" ,"a sheep and said it was you."},
 {2,"ladies and gentlemen,"        ,"the king of punctuality"},
 {1,"sheep here for the birth: 2"  ,"kings of tarse and egypt: 0"},
 {2,"apologize to the lovely"      ,"couple, bal..."},
 {1,"missed the print deadline:"   ,"two wise men at savior's birth"},
 {2,"we put this hay bale there...","cuz hay, you bailed on us"},
 {1,"nice, bal, real classy-like." ,"guess you won't be in the song"},
 {3,"i gave birth to the one true" ,"god's kid, and you overslept?"},
 {3,"baby jesus' first word was:"  ,"'late'"},
 {4,"jesus,"                       ,"this guy's late."},
 {4,"hey, thanks for showin' up...","you know, eventually..."},
 {6,"baaaaad job,"                 ,"baaaaal"},
 {7,"i have no limbs, and"        ,"even *i* made it to the birth"}
}

g_spr_best={89,121,59,51,50,89,24,52,59}
g_spr_title={54,55,56,56,57,58,59,50,121,120,62,121}
g_rainbow1={3,11,1,0,12,15,4,9,10,7,6,5,14,13}

-------------------------------
function _init()
 load_hs()
 init_anims()
 init_defs()
-- init_map()
 if(init_debug) init_debug()
 init_buttons()
 set_pal()
 sfx(8, 3)

 g_fakebal = spawn_actor(g_actordefs[spr_player],64,61,true)
end


-------------------------------
function load_hs()
 cartdata("myrrhs_edge")
 g_hs_time = dget(0)
 if(g_hs_time==0) g_hs_time = 9999.9
 g_hs_myrrh = dget(1)
end


-------------------------------
function save_hs()
 dset(0, g_hs_time)
 dset(1, g_hs_myrrh)
end


-------------------------------
function _update60()
  start_frame()

 if g_state=="title" then
  update_title()
 elseif g_state=="story" then
  update_story()
 elseif g_state=="game" then
  tick_actors()
  if gd_noclip then
   noclip_actor(g_player)
  else
   move_actor(g_player)
   world_push_actor(g_player)
  end
  update_state(g_player)
  anim_player(g_player)
  anim_buckets()
 elseif g_state=="endgame" then
  g_endfr += 1
  update_end()
  anim_player(g_player)
  anim_buckets()
 end

end


-------------------------------
function update_title()
 if btnp(🅾️) then
  g_state="story"
  g_frame = 0
 end
end


-------------------------------
function update_story()
 if btnp(🅾️) then
  g_state="game"
  sfx(8, -2)
  music(0, 100)
  init_map()
 end
end


-------------------------------
function _draw()
 cls(0)
 if g_state=="title" then
  draw_title()
 elseif g_state=="story" then
  draw_story()  
 elseif g_state=="game" then
  cam_world()
  draw_world()
  camera()
  draw_ui()
  if(gd_stats) draw_stats()
 elseif g_state=="endgame" then
  cam_end()
  draw_world()
  draw_endworld()
  camera()
  draw_endui()
  if(gd_stats) draw_stats()
 end
end


-------------------------------
function draw_title()

 -- title blocks
 local t = .5 * time()
 for i=1,#g_spr_title do
  local s = sin( t + i/30 )
  local x = 10+i*8
  local y = 10 + 5*s*s*s*s*s*s*s*s
  spr(g_spr_title[i],x,y)
 end

 print("a",62,25,5)
 print("christmas speedrun parkour game",3,32,5)

 -- moving ground (repeating)
 xofs = g_frame % 232
 map(17,0, -xofs,40, 29,4)
 map(17,0, 232-xofs,40, 29,4)

 -- running bal
 local bal = g_fakebal
 bal.wy = 61
 bal.state = "walk"
 bal.direction = 1
 bal.vx = 20
 local len=40
 local jmp=128
 local t = mid( (xofs-jmp)/len, 0,1 )
 if t>0 and t<1 then
  bal.wy = 61 - 7 + 7 * cos( t )
  bal.state = "jump"
  if(t>.5) bal.state="fall"
 end
 anim_player( bal )
 draw_actor( bal )

 -- credits
 local r = g_rainbow1
 local f = flr(g_frame / 8)
 local c1=r[4+(f+3)%11]
 local c2=r[4+(f+2)%11]
 local c3=r[4+(f+1)%11]
 local c4=r[4+(f+0)%11]
 print( "design/sfx: that tom hall", 13,105-24, c1 )
 print( "code and such: squirrel eiserloh", 1,105-16, c2 )
 print( "art and anims: toby hefflin", 1,105-8, c3 )
 print( "music by: gruber", 21,105, c4 )

 print("press 🅾️ to begin",21,120,5)
end


-------------------------------
function draw_story()
 sspr(112,48,16,16,48,5,32,32)
 print("balthazar",47,38,14)
 print("bal:",16,54,7)
 print_t("i woke up late!",34,54, 9, 0)
 print_t("gotta get to",41,62, 9, 35)
 print_t("the manger, fast!",36,70, 9, 45)
 print_t("(and pick up some",30,90, 4, 80)
 print_t("myrrh on the way!)",32,98, 4, 95)
 print("press 🅾️ to continue",25,120,5)
end


-------------------------------
function draw_world()
  if(gd_track and gd_track>0) debug_draw_tracking()
  draw_map()
  draw_actors("bg")
  draw_actors("mid")
  draw_map(128) -- fg tiles
  draw_actors("fg")
  draw_signs()
  if(gd_stats) debug_draw_points()
end


-------------------------------
function update_end()
 local p = g_player

 if(g_endfr > 100 and btn(❎) and btn(🅾️)) run()

 local lerp = mid((g_endfr-20) / 50, 0, 1)
 p.wx = g_lastbalx + lerp * (924 - g_lastbalx)
 p.wy = 245
 if lerp == 1 then
  p.direction = 1
  p.spr_mirror = false
  p.state = "idle"
  p.vx = 2
 else
  p.direction = -1
  p.spr_mirror = true
  p.state = "walk"
  p.vx = -2
 end

end


-------------------------------
function cam_end()
 local t = smoothstep(mid(g_endfr / 30, 0, 1))
 g_camx = g_ocamx + t * (840 - g_ocamx)
 g_camy = g_ocamy + t * (122 - g_ocamy)
 camera(g_camx, g_camy)
end


-------------------------------
function draw_endworld()
 if(g_endfr>150) draw_snark(g_snark1,0,6,5)
 if(g_endfr>300) draw_snark(g_snark2,1,10,9)
end


-------------------------------
function fit(amin,amax,bmin,bmax)
 if amax > bmax then
  amin -= amax-bmax
  amax = bmax
 end
 if amin < bmin then
  amax += bmin-amin
  amin = bmin
 end
 return amin,amax
end


-------------------------------
function draw_snark( s,n,edge,fill )
 local p=g_snarkers[s[1]]
 local sxy=g_snark_xys[s[1]]
 local sx,sy=sxy[1]*8+4,sxy[2]*8-1
 local len = max(#s[2],#s[3])
 local minx = sx-2*len-1
 local maxx = sx+2*len+1
 local miny = 194+n*18
 local maxy = miny+15
 minx,maxx = fit(minx,maxx,841,966)
 line(sx-1,sy-1, sx-8,maxy,edge)
 line(sx,sy-1, sx-7,maxy,edge)
 rectfill(minx,miny,maxx,maxy,edge)
 rect(minx,miny,maxx,maxy,fill)
 print(s[2],minx+2,miny+2,0)
 print(s[3],minx+2,miny+8,0)
end


-------------------------------
function draw_endui()

 spr(40, 12,12)
 spr(40, 108,12)
 for i=1,#g_spr_best do spr(g_spr_best[i],20+i*8,12) end
 for i=1,#g_spr_title do spr(g_spr_title[i],10+i*8,0) end

 p1 = g_rainbow1[ 4 + flr(g_frame/5) % 11 ]
 local tcol,mcol = 6,10
 if g_hs_time == g_sc_time then
  print_o("new record!", 10,54, p1, 0 )
  tcol = p1
 end
 if g_player.myrrh >= 200 then
  print_o("perfect!", 81,54, p1, 0 )
  mcol = p1
 elseif g_hs_myrrh == g_player.myrrh then
  print_o("new record!", 75,54, p1, 0 )
  mcol = p1
 end

 print_o("best time       most myrrh", 12,22, 9, 0)
 print_o(g_hs_time.."", 20,28, tcol, 0)
 print_o(g_hs_myrrh.."", 90,28, mcol, 0)

 print_o("your time       your myrrh", 12,40, 3, 0)
 print_o(g_sc_time.."", 20,46, tcol, 0)
 print_o(g_player.myrrh.."", 90,46, mcol, 0)

 print_o("(❎+🅾️ to try again!)", 2,62, 5, 0)
end

-------------------------------
function start_frame()

 g_dt = 1 / 60 -- deltaseconds
 g_time += g_dt
 g_frame = (g_frame + 1) % 28800 -- mods nicely by everything
 foreach(g_buttons, update_btn)
 if g_state == "game" then
  local ptx = flr(g_player.wx / 8)
  local pty = flr(g_player.wy / 8)
  if(mget(ptx,pty)==123 and g_player.myrrh >= g_min_myrrh) end_game()

 end
 if(g_sign) g_sign.fr += 1
 
end


-------------------------------
function init_buttons()
 g_button_keys = {⬅️,➡️,⬆️,⬇️,❎,🅾️}
 g_buttons = {}
 for k in all(g_button_keys) do
  g_buttons[k] = { key=k, isdown=false, was=false }
 end
end


-------------------------------
function update_btn(button)
 button.was = button.is
 button.is = btn(button.key)
end


-------------------------------
-- a more-useful version of btnp() which ignores repeats
function btnpp(key)
 local bs = g_buttons[ key ]
 return bs.is and not bs.was
end


-------------------------------
function set_pal()
 pal()
 pal(1,129,1)
 pal(10,135,1)
 pal(11,131,1)
 pal(12,128,1)
 pal(13,130,1)
 pal(14,133,1)
 pal(15,132,1)
 poke(0x5f2e,1) --keep pal after exit
end


-------------------------------
function init_map()

 for ty = 0,3 do
  for tx = 17,46 do
   mset(tx,ty,0)
  end
 end

 -- spawn actors
 for ty = 0,63 do
  for tx = 0,127 do

   local tile = mget(tx,ty)

   -- tile corrections (for multiple tiles representing the same thing)
   if(tile==107 or tile==108)  tile = spr_fire
   if(tile==28 or tile==29)    tile = spr_star
   if(tile==45)                tile = spr_myrrh
   if(tile==77)                tile = spr_mouse_idle
   if(tile==73 or tile==102)   tile = spr_sheep_idle
   if(tile==94)                tile = spr_melee_idle

   if tile==38 then
    get_sign(tx,ty)
   end

   local def = g_actordefs[ tile ]
   if def != nil then
    local wx = 4 + (8 * tx)
    local wy = 4 + (8 * ty)
    local a = spawn_actor(def, wx,wy)
    local default_spawntile = 8
    if( ty > 47 ) default_spawntile = 26
    local replacetile = def.spawntile or default_spawntile
    mset(tx,ty, replacetile)
    if def.category=="player" then
     g_player = a
    end
   end
   
  end
 end

 g_player.fr_since_air_jump = 0

end


-------------------------------
function end_game()
 g_state = "endgame"
 g_endfr = 0
 g_lastbalx = g_player.wx
 g_ocamx = g_camx
 g_ocamy = g_camy
 g_snark1 = 1+flr(rnd(#g_snarks))
 g_snark2 = g_snark1
 while g_snark2==g_snark1 do
  g_snark2 = 1+flr(rnd(#g_snarks))
 end
 g_snark1 = g_snarks[g_snark1]
 g_snark2 = g_snarks[g_snark2]

 -- scoring
 g_sc_time = flr(g_time*10)/10
 g_new_hs_time = false
 g_new_hs_myrrh = false
 if g_sc_time < g_hs_time then
  g_hs_time = g_sc_time
  g_new_hs_time = true
 end
 if g_player.myrrh > g_hs_myrrh then
  g_hs_myrrh = g_player.myrrh
  g_new_hs_myrrh = true
 end
 save_hs()

end


-------------------------------
function cam_world()
 local goalx = flr(g_player.wx) - 64
 local goaly = flr(g_player.wy) - 64

 if g_camx==nil then
   g_camx = goalx
   g_camy = goaly
 end

 local d = 9
 if(g_camx < goalx-d) g_camx = goalx-d
 if(g_camx > goalx+d) g_camx = goalx+d
 if(g_camy < goaly-d) g_camy = goaly-d
 if(g_camy > goaly+d) g_camy = goaly+d

 if(g_camx < 0) g_camx = 0
 if(g_camy < 0) g_camy = 0
 if(g_camx > 896) g_camx = 896
 if(g_camy > 384) g_camy = 384
  
 camera(g_camx, g_camy)
end


-------------------------------
function draw_map(layer_bits_value)
 map(0,0, 0,0, 128,64, layer_bits_value)
end


-------------------------------
function draw_signs()
 local s = g_sign
 if s.fr < 60 then
  w1 = #s.msg1
  w2 = #s.msg2
  x1 = s.wx - 2*w1
  x2 = s.wx - 2*w2
  w = max(w1, w2)
  minx = min(x1, x2) - 3
  maxx = minx + 4*w + 4
  y1 = s.wy - 40
  y2 = y1 + 6
  miny = y1 - 2
  maxy = y2 + 6
  if minx < 0 then
   local over = -minx
   minx = 0
   maxx += over
   x1 += over
   x2 += over
  end
  if maxx > 1023 then
   local over = maxx - 1023
   minx -= over
   maxx -= over
   x1 -= over
   x2 -= over
  end
  rectfill(minx,miny, maxx,maxy, 9)
  print(s.msg1, x1,y1, 0)
  print(s.msg2, x2,y2, 0)
  line(minx+1,miny, maxx-1,miny, 10)
  line(minx,miny+1, minx,maxy-1, 10)
  line(minx+1,maxy, maxx-1,maxy, 4)
  line(maxx,miny+1, maxx,maxy-1, 4)
  pset(minx,miny, 7)
  pset(maxx,maxy, 15)

 end
end


-------------------------------
function draw_actors(layer)
 local actors_in_layer = g_layers[ layer ]
 for a in all(actors_in_layer) do
  draw_actor(a)
 end
end


-------------------------------
function init_anims()
 for i=1,g_nbuckets do
  add(g_buckets, {})
 end
end


-------------------------------
function init_defs()

 local def = new_actordef("player", spr_player)
 def.category = "player"
 def.tick = tick_player
 def.anim = anim_player
 def.jump_vel = 68
 def.jump_sustain = 3.0
 def.can_climb = true
 def.can_zip = true
 def.climb_down_speed = 30
 def.climb_up_speed = 30
 def.radius = g_pr
 def.health = 3
 def.draw_ofs_x = 0 -- -1
 def.draw_ofs_y = -1
 def.does_physics = true

 local def = new_actordef("melee", spr_melee_idle)
 def.category = "npc"
 def.tick = tick_melee

 local def = new_actordef("sheep", spr_sheep_idle)
 def.category = "npc"
 def.tick = tick_sheep
 def.anim = anim_sheep
 def.sfx_die = sfx_sheep_died

 local def = new_actordef("mouse", spr_mouse_idle)
 def.category = "npc"
 def.tick = tick_mouse
 def.anim = anim_mouse
 def.sfx_die = sfx_mouse_died

 local def = new_actordef("myrrh", spr_myrrh)
 def.category = "pickup"
 def.tick = tick_pickup
 def.anim = anim_myrrh
 def.radius = 5
 def.myrrh = 1
 def.sfx_die = sfx_getmyrrh

 local def = new_actordef("key", spr_key)
 def.category = "pickup"
 def.tick = tick_pickup
 def.radius = 5
 def.keys = 1
 def.sfx_die = sfx_getkey

 local def = new_actordef("fire", spr_fire)
 def.anim = anim_fire
 def.draw_layer = "bg"

 local def = new_actordef("star", spr_star)
 def.anim = anim_star
 def.spawntile = 0
 def.draw_layer = "bg"

 local def = new_actordef("pillarbottom", 48)
 def.spawntile = 48
 def.draw_layer = "fg"
 def.draw_spr = 49

 local def = new_actordef("pillarmid", 71)
 def.spawntile = 71
 def.draw_layer = "fg"
 def.draw_spr = 72

 local def = new_actordef("pillartop", 32)
 def.spawntile = 32
 def.draw_layer = "fg"
 def.draw_spr = 33

end


-------------------------------
function spawn_actor(def, wx,wy, is_fake)
 local a = {}
 a.def = def
 def.count += 1
 def.spawncount += 1
 a.sprite = def.draw_spr
 a.spr_frames = 0
 a.spr_mirror = false
 a.wx = wx
 a.wy = wy
 a.vx = 0
 a.vx_max = a.def.vx_max
 a.vy = 0
 a.direction = 1
 a.radius = def.radius
 a.state = "idle"
 a.on_ground = false
 a.on_rwall = false
 a.on_lwall = false
 a.on_ladder = false
 a.head_on_ladder = false
 a.on_zip = false
 a.on_wire = false
 a.on_awn = false
 a.awn_dir = 0
 a.on_slide = false
 a.keys = def.keys
 a.myrrh = def.myrrh
 a.is_atk = false
 a.cool = 0

 if not is_fake then
  add(g_actors, a)
  local draw_layer_list = g_layers[ def.draw_layer ]
  add(draw_layer_list, a)
  local dc = def.category
  if dc=="pickup" or dc=="decoration" or dc=="npc" then
   next_bucket = next_bucket or 0
   next_bucket = 1 + (next_bucket % g_nbuckets)
   local bucket = g_buckets[ next_bucket ]
   add(bucket, a)
  end
 end

 return a
end


-------------------------------
function new_actordef(name, spawn_spr)
 local def = {}
 def.count = 0 -- current count
 def.spawncount = 0 -- spawned count
 def.spawn_spr = spawn_spr
 def.draw_spr = spawn_spr
-- def.spawntile = -1 -- open bricks
 def.name = name
 def.health = 1
 def.radius = 4
 def.accelx = 1000
 def.vx_max = g_player_max_runx
 def.does_physics = false
 def.gravity = 300
 def.jump_vel = 0
 def.jump_sustain = 0
 def.category = "decoration"
 def.tick = nil
 def.can_climb = false
 def.can_zip = false
 def.climb_down_speed = 0
 def.climb_up_speed = 0
 def.draw_layer = "mid"
 def.draw_ofs_x = 0
 def.draw_ofs_y = 0
 def.keys = 0
 def.myrrh = 0

 if spawn_spr > 0 then
  -- file in map under spawn sprite #
  g_actordefs[ spawn_spr ] = def
 else
  -- file in map under def name
  g_actordefs[ name ] = def
 end

 return def
end


-------------------------------
function delete_actor(a)
 a.def.count -= 1
 del(g_actors, a)
 local draw_layer_list = g_layers[ a.def.draw_layer ];
 del(draw_layer_list, a)
 for i=1,g_nbuckets do
  del(g_buckets[ i ], a)
 end
end


-------------------------------
function tick_actors()
 for a in all(g_actors) do
  if(a and a.def.tick) a.def.tick(a)
 end
end


-------------------------------
function tick_melee(a)

 a.cool -= 1

 local dx = g_melee_walk_dx
 local p = g_player

 -- check if charging and hit player
 if a.is_atk then
  if a.cool < -70 then
    a.is_atk = false
    a.cool = 50
  elseif a.wy > p.wy - p.radius and a.wy < p.wy + p.radius then
   local dmgx = a.wx + (a.direction * 3)
   if dmgx > p.wx - p.radius and dmgx < p.wx + p.radius then
    p.vy = -82
    p.vx = (a.direction * 120)
    p.vx_max = abs(p.vx)
    p.state = "jump"
    sfx(sfx_hit)
    a.is_atk = false
    a.cool = 50
   end
  end
 end

 -- check to start charging
 if not a.is_atk and a.cool <= 0 then
  local miny = a.wy-g_melee_see_y
  local maxy = a.wy+g_melee_see_y
  if p.wy > miny and p.wy < maxy then
   local minx = a.wx - (a.direction * 5)
   local maxx = minx + (a.direction * g_melee_see_x)
   if minx > maxx then
    local tempswap = minx
    minx = maxx
    maxx = tempswap
   end
   if p.wx > minx and p.wx < maxx then
    if((p.wx - a.wx) * a.direction < 0) a.direction = -a.direction
    a.is_atk = true
    a.cool = 50
    sfx(sfx_charge)
   end
  end
 end

-- if(a.is_atk and a.cool < 1*60) a.is_atk = false
 if(a.is_atk) dx = g_melee_charge_dx

 -- check for turn-around
 local nx = a.wx + (dx * a.direction)
 local tx = flr(nx / 8)
 local ty = flr(a.wy / 8)
 local next_tile = mget(tx,ty)
 local next_tile_below = mget(tx,ty+1)
 local turn_around = false
 if(fget(next_tile, bit_solid_r) or fget(next_tile, bit_solid_l)) turn_around = true
 if(not fget(next_tile_below, bit_ladder) and not fget(next_tile_below, bit_solid_u)) turn_around = true
 if turn_around then
  a.direction = -a.direction
  a.is_atk = false
 else
  a.wx = nx
 end

 anim_melee(a)
end


-------------------------------
function anim_melee(a)
 a.sprite = spr_melee_idle
 a.spr_mirror = (a.direction < 0)

 if a.is_atk or a.cool > 40 then
  a.sprite = 94
  a.spr_mirror = (a.direction > 0)
 end
end


-------------------------------
function tick_sheep(a)
 local speedx_wander = 0.2
 local speedx = speedx_wander
 local direction = -1
 if a.spr_mirror then
  direction = 1
 end

 local nx = a.wx + (speedx * direction)
 local tx = flr(nx / 8)
 local ty = flr(a.wy / 8)
 local next_tile = mget(tx,ty)
 local next_tile_below = mget(tx,ty+1)
 local turn_around = false
 if(fget(next_tile, bit_ladder) or fget(next_tile, bit_solid_r) or fget(next_tile, bit_solid_l)) turn_around = true
 if(not fget(next_tile_below, bit_ladder) and not fget(next_tile_below, bit_solid_u)) turn_around = true
 if turn_around then
  a.spr_mirror = not a.spr_mirror
 else
  a.wx = nx
 end

-- anim_sheep(a)
end


-------------------------------
function anim_sheep(a)
 a.spr_frames = (a.spr_frames + 1) % 6
 a.sprite = spr_sheep_idle
 if(a.spr_frames < 3) a.sprite = spr_sheep_idle+1
end


-------------------------------
function tick_mouse(a)
 local speedx_wander = 0.5
 local speedx = speedx_wander
 local direction = -1
 if a.spr_mirror then
  direction = 1
 end

 local nx = a.wx + (speedx * direction)
 local tx = flr(nx / 8)
 local ty = flr(a.wy / 8)
 local next_tile = mget(tx,ty)
 local next_tile_below = mget(tx,ty+1)
 local turn_around = false
 if(fget(next_tile, bit_ladder) or fget(next_tile, bit_solid_r) or fget(next_tile, bit_solid_l)) turn_around = true
 if(next_tile==spr_slide1 or next_tile==spr_slide2) turn_around = false
 if(not fget(next_tile_below, bit_ladder) and not fget(next_tile_below, bit_solid_u)) turn_around = true
 if turn_around then
  a.spr_mirror = not a.spr_mirror
 else
  a.wx = nx
 end
end


-------------------------------
function anim_mouse(a)
 a.spr_frames = (a.spr_frames + 1) % 2
 a.sprite = spr_mouse_idle
 if(a.spr_frames < 1) a.sprite = spr_mouse_idle+1
end


-------------------------------
function tick_pickup(a)
 local p = g_player
 if do_actors_overlap(a,p) then
  p.keys += a.keys
  p.myrrh += a.myrrh
  sfx(a.def.sfx_die)
  delete_actor(a)
 end 
end


-------------------------------
function anim_fire(a)
 local fr_adv = 0 + flr(rnd(3))
 a.sprite = spr_fire + (fr_adv + a.sprite - spr_fire) % 3
end


-------------------------------
function anim_star(a)
 a.spr_frames = (a.spr_frames + 1) % 4
 a.sprite = spr_star + a.spr_frames
 if(a.spr_frames==3) a.sprite = 28
end


-------------------------------
function anim_myrrh(a)
 a.spr_frames -= 1  
 if a.spr_frames <= 0 then
  a.sprite = 44 + (1 + a.sprite - 44) % 2
  a.spr_frames = 1 + rnd(5)
 end
end


-------------------------------
function tick_player(p)

 p.vx_max -= 1
 if(p.vx_max < g_player_max_runx) p.vx_max = g_player_max_runx

 p.fr_since_air_jump += 1

 local tx = flr(p.wx / 8)
 local ty = flr(p.wy / 8)
 local tile_here = mget(tx,ty)

 local gs = g_sign
-- gs.fr += 1
 if tile_here==38 then
  local sign = get_sign(tx,ty)
  gs.msg1 = sign[3]
  gs.msg2 = sign[4]
  gs.wx = 8 * tx + 4
  gs.wy = 8 * ty
  gs.fr = 0
 end

 if p.state=="slide" and is_slide(tile_here) then
  return
 end

 local movex = 0
 if(btn(➡️)) movex += 1
 if(btn(⬅️)) movex -= 1

 -- awning
 if p.on_awn and not p.on_ground and p.vy > 0 then
  p.vx = p.awn_dir * g_awn_vx
  p.vy = -g_awn_vy
  p.state = "jump"
  sfx(sfx_jump)
 end

 -- spikes
 if tile_here==118 and p.vy >= 0 then
  p.vx = -p.vx
  p.vx_max = abs(p.vx)
  p.vy = -65
  p.state = "fall"
  sfx(45)
 end

 -- use
 if btnpp(❎) then
  if(tile_here==spr_door_locked) try_unlock(tx,ty)
  if(tile_here==spr_door_open) try_portal(tx,ty)
 end

 -- end zip/wire
 if(p.state=="zipline" and ((btn(⬇️) and btn(🅾️)) or (not p.on_zip or not btn(❎)))) p.state = "fall"
 if(p.state=="brachiate" and ((btn(⬇️) and btn(🅾️)) or (not p.on_wire or not btn(❎)))) p.state = "fall"

 -- start zip/wire
 if btn(❎) and not btn(🅾️) and not btn(⬇️) then
  if p.state ~= "zipline" and p.on_zip then
   p.state = "zipline"
   p.on_ground = false
   p.vx = g_zip_vx
   p.vy = g_zip_vy
   snap_to_zip(p)
   sfx(sfx_zip)
  elseif p.state ~= "brachiate" and p.on_wire then
   p.state = "brachiate"
   p.on_ground = false
   p.vy = 0
   snap_to_wire(p)
   sfx(sfx_wire)
  end
 end

 -- start climb
 local is_ud = btn(⬆️) or btn(⬇️)
 if p.on_ladder and btn(⬇️) then
  p.state = "climb"
 elseif p.head_on_ladder and btn(⬆️) and p.state ~= "slide" then
  p.state = "climb"
 end

 -- end climb
 if p.state=="climb" then
  if((p.on_ground and not is_ud) or (not p.on_ladder) or (not is_ud and (btn(⬅️) or btn(➡️)))) p.state = "fall"
 end

 -- climbing
 if p.state=="climb" then
  p.vy = 0
  if is_ud then
   p.wx = p.ladderx
   p.vx = 0
  end
 end

 -- check for jump from slide
 if p.state=="slide" and movex ~= 0 and btnpp(🅾️) then
   if(p.vy > 0) p.vy = 0
   p.vy -= p.def.jump_vel
   p.state = "jump"
   p.on_ground = false
   sfx(sfx_jump)
 end

 -- check for jump
 if btnpp(🅾️) and not btn(⬇️) then -- can't jump if pushing down since that's for semi-solid fall-through...
  if p.state=="zipline" then
   -- jump off zipline
   p.vx = g_zip_jump_vx
   p.vy = -g_zip_jump_vy
   p.state = "jump"
   p.on_ground = false
   sfx(sfx_jump)
  elseif p.state=="brachiate" then
   -- jump off brachiate wire
   p.vy = -g_zip_jump_vy
   p.state = "jump"
   p.on_ground = false
   sfx(sfx_jump)
  else
   -- normal ground (or stairs) jump attempt
   local jump_ok = p.on_ground
   if not jump_ok and p.vy > 0 then
    -- falling toward stairs close under?
    local r = p.radius
    local ltx = flr((p.wx - r) / 8)
    local rtx = flr((p.wx + r) / 8)
    local fty = flr((p.wy + r + 3) / 8)
    local lftile = mget(ltx,fty)
    local rftile = mget(rtx,fty)
    if(lftile==20 or lftile==31 or rftile==20 or rftile==31) jump_ok = true
   end
   if jump_ok then
    if(p.vy > 0) p.vy = 0
    p.vy -= p.def.jump_vel
    p.state = "jump"
    p.on_ground = false
    sfx(sfx_jump)
   end
  end
 elseif btn(🅾️) and p.state=="jump" then
  p.vy -= p.def.jump_sustain -- sustain higher jump as we hold the button
 end

 -- reset frames-since-air-jump counter
 if btnpp(🅾️) and p.on_ground==false then
  p.fr_since_air_jump = 0
 end

 -- check for wall jump
 if p.on_ground==false and p.vy > 0 and movex ~= 0 and p.fr_since_air_jump < g_wall_jump_delay then
   local footy = p.wy - (p.radius / 2)
   local wall_ty = flr(footy / 8)
   local can_wall_jump = false
   if movex > 0 then
    -- check for wall-jump-off-left-to-right
    local footx = p.wx - p.radius - g_wjump_dist
    local wall_tx = flr(footx / 8)
    local wall_tile = mget(wall_tx, wall_ty)
    can_wall_jump = fget(wall_tile, bit_solid_r)
   elseif movex < 0 then
    -- check for wall-jump-off-right-to-left
    local footx = p.wx + p.radius + g_wjump_dist
    local wall_tx = flr(footx / 8)
    local wall_tile = mget(wall_tx, wall_ty)
    can_wall_jump = fget(wall_tile, bit_solid_l)
   end
   if can_wall_jump then
    if(p.vy > 0) p.vy = 0
    p.vy -= g_wjump_vy
    p.vx = movex * g_wjump_vx
    p.state = "jump"
    p.on_ground = false
    sfx(sfx_jump)
   end   
 end

 -- check for slide begin
 if p.state=="walk" and btn(⬇️) and abs(p.vx) > g_slide_min_vx then
  p.state = "slide"
  p.vx /= abs(p.vx)
  p.vx *= g_slide_max_vx
 end

 -- check for slide end
 if p.state=="slide" then
  if not btn(⬇️) or btn(⬆️) or abs(p.vx) < g_slide_min_vx then
   p.state = "idle"
  end
  if (p.vx > 0 and movex <= 0) or (p.vx < 0 and movex >= 0) then
   p.state = "walk"
  end
  if movex==0 and btn(⬇️) and btn(🅾️) then
   p.state = "fall" -- drop through semi-solid from slide
  end
 end

 -- compute u/d move intentions - apply climb y-velocity directly (not acceleration-based)
 if p.state=="climb" then
  if btn(⬇️) then
   p.vy = p.def.climb_down_speed
  end
  if btn(⬆️) then
   p.vy = -p.def.climb_up_speed
  end
 end

 -- apply friction if on ground
 if p.state=="slide" then
  local friction = 0.01
  if (p.vx > 0 and btn(➡️)) or (p.vx < 0 and btn(⬅️)) then
   friction = 0
   p.vx /= abs(p.vx)
   p.vx *= g_slide_max_vx
  end
  if (p.vx > 0 and btn(⬅️)) or (p.vx < 0 and btn(➡️)) then
   friction = 0.3
  end
  p.vx *= (1 - friction)
 else
  local friction = 1 - abs(movex)
  local f = friction * 0.05
  if(p.on_ground or p.state=="brachiate") f = friction * 0.3
  p.vx *= (1 - f)
 end

 -- apply horizontal movement acceleration
 if(not p.on_ground) movex *= g_air_control
 local vx_limit = p.vx_max -- max(p.def.vx_max, abs(p.vx)) 
 if(p.state=="zipline") vx_limit = g_zip_vx
 local accelx = movex * p.def.accelx
 if p.vx * movex < p.def.vx_max then
  p.vx += accelx * g_dt
 end

 -- apply speed limit (anti-tunneling, corrective physics)
 if abs(p.vx) > vx_limit then
  local old = p.vx
  p.vx /= abs(p.vx)
  p.vx *= vx_limit
 end

 if(p.vy < -100) p.vy = -100
 
end


-------------------------------
function set_mirror(a)
 if(a.vx >  2) a.spr_mirror = false
 if(a.vx < -2) a.spr_mirror = true
end


-------------------------------
function anim_player(a)

 local fr = g_frame
 local s = a.state
 if s=="idle" then
  a.sprite = 64
  a.spr_frames += 1
  if(a.spr_frames > 20 + rnd(1000)) a.spr_frames = 0
  if(a.spr_frames < 10) a.sprite = 65
  if(g_state ~= "endgame" and rnd() < 0.01) a.spr_mirror = not a.spr_mirror

 elseif s=="walk" then
  a.sprite = 80 + flr(fr / 8) % 4
  set_mirror(a)

 elseif s=="slide" then
  a.sprite = 86
  set_mirror(a)

 elseif s=="climb" then
  if abs(a.vy) > 1 then
   local fr = flr(fr / 4) % 4
   a.sprite = 96 + (fr % 2)
   a.spr_mirror = fr < 2
  end

 elseif s=="jump" then
  a.sprite = 67
 
 elseif s=="fall" then
  a.sprite = 66
  if a.vy > 125 then
   a.sprite = 99 + flr(fr / 3) % 2
  end

 elseif s=="lwally" then
  a.sprite = 98
  a.spr_mirror = false
 
 elseif s=="rwally" then
  a.sprite = 98
  a.spr_mirror = true

 elseif s=="zipline" then
  a.sprite = 103
  if(fr%6 < 3) a.sprite = 104

 elseif s=="brachiate" then
  if( abs(a.vx) > 10 ) a.spr_frames += 1
  a.sprite = 112 + flr( a.spr_frames / 5 ) % 4
  set_mirror(a)
 
 end
end


-------------------------------
function snap_to_zip(a)
 -- asdf
end


-------------------------------
function snap_to_wire(a)
 local ty = flr(a.wy / 8)
 a.wy = (ty*8) + 4
end


-------------------------------
function is_slide(tile)
 return tile==spr_slide1 or tile==spr_slide2
end


-------------------------------
function try_unlock(tx,ty)

 local tile = mget(tx,ty)

 if tile==spr_door_locked and g_player.keys > 0 then
  g_player.keys -= 1
  mset(tx,ty, spr_door_open)
  ox,oy = find_door_twin(tx,ty)
  if(ox ~= nil) mset(ox,oy, spr_door_open) -- unlock twin
  sfx(sfx_open_y)
 else
  sfx(sfx_open_n)
 end
end


-------------------------------
function try_portal(tx,ty)

 local tile = mget(tx,ty)

 if tile==spr_door_open then
  ox,oy = find_door_twin(tx,ty)
  if ox==nil then
   err("door at "..tx..","..ty.." had no glyph-twin!")
  end

  g_player.wx += ((ox - tx) * 8)
  g_player.wy += ((oy - ty) * 8)
  sfx(sfx_door)
 end

end


-------------------------------
function find_door_twin(tx,ty)

 local this_glyph = mget(tx,ty-1) -- glyph above door
 for oy = 0,63 do
  for ox = 0,127 do

   if (ox ~= tx) or (oy ~= ty) then
    local twin_door = mget(ox,oy)
    if (twin_door==spr_door_open) or (twin_door==spr_door_locked) then
     local twin_glyph = mget(ox,oy-1) -- above twin door
     if twin_glyph==this_glyph then
      return ox,oy
     end
    end
   end

  end
 end

 return nil
end


-------------------------------
function anim_buckets()
 local bucket = 1 + (g_frame % g_nbuckets)
 local anim_list = g_buckets[ bucket ]
 for a in all(anim_list) do
  if(a.def.anim) a.def.anim(a)
 end
end


-------------------------------
function draw_actor(a, layer)
 local minx = a.wx - 4
 local miny = a.wy - 4
 local dx = minx + a.def.draw_ofs_x
 local dy = miny + a.def.draw_ofs_y
 spr(a.sprite, dx,dy, 1,1, a.spr_mirror)
end


-------------------------------
function do_actors_overlap(a, b)
 local ar = a.radius
 local br = b.radius
 return (a.wx - ar < b.wx + br) and
        (a.wx + ar > b.wx - br) and
        (a.wy - ar < b.wy + br) and
        (a.wy + ar > b.wy - br)
end


-------------------------------
function update_states()
 for i = 1,#g_actors do
  local a = g_actors[ i ]
  update_state(a)
 end
end


-------------------------------
function update_state(a)
 local s = a.state

 if (s=="jump" and a.vy >= 0) a.state = "fall"
 
 if not a.on_ground and
  (s=="idle" or
   s=="walk" or
   s=="duck" or
   s=="slide" or
   s=="use") then
  a.state = "fall"
 end
 
 if (s=="fall" and a.on_lwall) a.state = "lwally"
 if (s=="fall" and a.on_rwall) a.state = "rwally"
 if ((s=="lwally" and not a.on_lwall) or (s=="rwally" and not a.on_rwall)) a.state = "fall"
    
 if a.on_ground and
  (s=="jump" or
   s=="fall" or
   s=="lwally" or
   s=="rwally" or
   s=="brachiate" or
   s=="zipline") then
  a.state = "walk" 
 end
 
 if (s=="walk" and abs(a.vx) < g_walk_vx) a.state = "idle"
 if (s=="idle" and abs(a.vx) > g_walk_vx) a.state = "walk"

end


-------------------------------
function menu_reset()
 g_hs_time = 9999.9
 g_hs_myrrh = 0
 save_hs()
end 

-------------------------------
function noclip_actor(a)
 if(btn(➡️)) a.wx += 2
 if(btn(⬅️)) a.wx -= 2
 if(btn(⬇️)) a.wy += 2
 if(btn(⬆️)) a.wy -= 2
end


-------------------------------
function move_actor(a)

 if(not a or not a.def.does_physics) return

 if a.state ~= "climb" then
  a.vy += (a.def.gravity * g_dt)
  if a.state=="lwally" or a.state=="rwally" then
   if(a.vy > g_max_wally_vy) a.vy = g_max_wally_vy
  end
 end

 -- anti-tunneling vel clamp
 a.vx = mid(a.vx, -g_max_speed, g_max_speed)
 a.vy = mid(a.vy, -g_max_speed, g_max_speed)

 if a.state=="zipline" then
  a.vx = g_zip_vx
  a.vy = g_zip_vy
 end

 if a.state=="brachiate" then
  a.vy = 0
 end

 a.wx += (a.vx * g_dt)
 a.wy += (a.vy * g_dt)

end


-------------------------------
function is_semi_solid(s)
 return fget(s, bit_solid_u) and not fget(s, bit_solid_l) and not fget(s, bit_solid_r) and not fget(s, bit_solid_d)
end


-------------------------------
function world_push_actor(a)
  local tx = flr(a.wx / 8)
  local ty = flr(a.wy / 8)
  
  a.on_ground = false
  a.on_rwall = false
  a.on_lwall = false

  push_up_out_of_stairs(a, tx,ty)

  pushtile_s(a, tx,ty+1) -- south tile (push up)
  pushtile_n(a, tx,ty-1)
  pushtile_e(a, tx+1,ty)
  pushtile_w(a, tx-1,ty)
  
  pushtile_ne(a, tx+1,ty-1)
  pushtile_nw(a, tx-1,ty-1)
  pushtile_se(a, tx+1,ty+1)
  pushtile_sw(a, tx-1,ty+1)

  update_ons(a)
end


-------------------------------
function pushtile_s(a, tx,ty)

 local s = a.state
 local tile = mget(tx,ty)
 if(s=="slide" and is_slide(tile)) return
 push_up_out_of_stairs(a, tx,ty)
 if(a.vy < 0) return

 local is_ladder = fget(tile, bit_ladder)
 local is_solid_ladder = is_ladder and s ~= "climb" and not a.head_on_ladder
 if(not fget(tile, bit_solid_u) and not is_solid_ladder) return

 -- fall-through semi-solid if down + jump
 if(btn(⬇️) and btn(🅾️) and is_semi_solid(tile)) return

 -- overlapping?
 local tminy = ty * 8
 if(a.wy + a.radius <= tminy) return
 
 -- push out & kill v
 a.wy = tminy - a.radius
 if(a.vy > 0) a.vy = 0
 
 a.on_ground = true
 a.on_lwall = false
 a.on_rwall = false
 if(s=="fall") a.state = "walk"
 
end


-------------------------------
function pushtile_e(a, tx,ty)

 local tile = mget(tx,ty)
 if (a.state=="slide" and is_slide(tile)) return
 push_up_out_of_stairs(a, tx,ty)
 if (not fget(tile,bit_solid_l)) return

 -- overlapping?
 local rx = a.wx + a.radius
 local tminx = tx * 8
 if(rx <= tminx) return
 
 -- push & kill v
 a.wx = tminx - a.radius
 if(a.vx > 0) a.vx = 0
 if(not a.on_ground) a.on_rwall = true -- pushed left!
 
end


-------------------------------
function pushtile_w(a, tx,ty)

 local tile = mget(tx,ty)
 if(a.state=="slide" and is_slide(tile)) return
 push_up_out_of_stairs(a, tx,ty)
 if(not fget(tile,bit_solid_r)) return

 -- overlapping?
 local tmaxx = tx*8 + 8
 if(a.wx - a.radius >= tmaxx) return
 
 -- push & kill v
 a.wx = tmaxx + a.radius
 if(a.vx < 0) a.vx = 0
 if(not a.on_ground) a.on_lwall = true -- pushed right!
 
end


-------------------------------
function pushtile_n(a, tx,ty)

 local s = a.state
 local tile = mget(tx,ty)
 if(s=="slide" and is_slide(tile)) return
 if(not fget(tile,bit_solid_d)) return

 local tmaxy = ty*8 + 8
 if(a.wy - a.radius >= tmaxy) return
 
 -- push & kill v
 a.wy = tmaxy + a.radius
 if(a.vy < 0) a.vy= 0
 if(s=="lwally" or s=="rwally" or s=="jump") a.state = "fall"
 
end


-------------------------------
function pushtile_nw(a, tx,ty)
 local tile = mget(tx,ty)
 if(a.state=="slide" and is_slide(tile)) return
 if(not fget(tile,bit_solid_d) and not fget(tile,bit_solid_r)) return
 push_out_of(a, tx*8 + 8,ty*8 + 8, false, true)
end


-------------------------------
function pushtile_ne(a, tx,ty)
 local tile = mget(tx,ty)
 if(a.state=="slide" and is_slide(tile)) return
 if(not fget(tile,bit_solid_d) and not fget(tile,bit_solid_l)) return
 push_out_of(a, tx*8,ty*8+8, false, true) 
end


-------------------------------
function pushtile_se(a, tx,ty)

 local tile = mget(tx,ty)
 if(a.state=="slide" and is_slide(tile)) return
 push_up_out_of_stairs(a, tx,ty)
 if(a.vy < 0) return

 local is_climbing = (a.state=="climb")
 local is_ladder = fget(tile, bit_ladder)
 local is_solid_ladder = is_ladder and not is_climbing and not a.head_on_ladder
 if(not fget(tile, bit_solid_u) and not is_solid_ladder) return

 -- fall-through semi-solid (solid on top only) if holding down + jump
 if(btn(⬇️) and btn(🅾️) and is_semi_solid(tile)) return

 push_out_of(a, tx*8,ty*8)

end


-------------------------------
function pushtile_sw(a, tx,ty)

 local tile = mget(tx,ty)
 if(a.state=="slide" and is_slide(tile)) return
 push_up_out_of_stairs(a, tx,ty)
 if(a.vy < 0) return

 local is_climbing = (a.state=="climb")
 local is_ladder = fget(tile, bit_ladder)
 local is_solid_ladder = is_ladder and not is_climbing and not a.head_on_ladder
 if(not fget(tile, bit_solid_u) and not is_solid_ladder) return

 -- fall-through semi-solid (solid on top only) if holding down + jump
 if(btn(⬇️) and btn(🅾️) and is_semi_solid(tile)) return

 push_out_of(a, tx*8 + 8,ty*8)

end


-------------------------------
function push_up_out_of_stairs(a, tx,ty)

 local tile = mget(tx,ty)
 if(tile ~= spr_stairs_up and tile ~= spr_stairs_down) return

 local r = a.radius
 local a_minx = a.wx - r
 local a_maxx = a.wx + r
 local a_miny = a.wy - r
 local a_maxy = a.wy + r

 local t_minx = 8 * tx
 local t_maxx = t_minx + 8 -- or is 7, or 7.99 more appropriate?
 local t_miny = 8 * ty
 local t_maxy = t_miny + 8 -- ditto

 if(a_minx > t_maxx or a_maxx < t_minx or a_miny > t_maxy or a_maxy < t_miny) return

 local tile = mget(tx,ty)
 if tile==spr_stairs_up then
  local px = min(a_maxx, t_maxx)
  local dx = px - t_minx
  local dy = dx
  local py = t_maxy - dy
  if a_maxy > py then
   push_out_of(a, px-.01,py, true)
  end
 elseif tile==spr_stairs_down then
  local px = max(a_minx, t_minx)
  local dx = px - t_minx
  local dy = 8-dx
  local py = t_maxy - dy
  if a_maxy > py then
   push_out_of(a, px+.01,py, true)
  end
 end

end


-------------------------------
function push_out_of(a, px,py, up_only, prefer_x)

 local r = a.radius
 if(px<=a.wx-r or px>=a.wx+r or py<=a.wy-r or py>=a.wy+r) return false
 
 -- push and kill v
  local dx = a.wx - px
  local dy = a.wy - py
  if not up_only and (prefer_x==true or abs(dx) > abs(dy)) then
    -- push out horiz. (x)
    if dx > 0 then
      a.wx += (r-dx)
      if(a.vx < 0) a.vx = 0
     a.on_ground = false
     a.on_lwall = true 
     a.on_rwall = false
    else
      a.wx -= (r+dx)
      if(a.vx > 0) a.vx = 0
     a.on_ground = false
     a.on_lwall = false
     a.on_rwall = true
    end
  else
    -- push out vertically (y)
    local push_down = (up_only ~= true)

    if push_down and dy > 0 then
      a.wy += (r-dy)
      if(a.vy < 0) a.vy = 0
    else
      a.wy -= (r+dy)
      if(a.vy > 0) a.vy = 0
     a.on_ground = true -- pushed up! 
     a.on_lwall = false
     a.on_rwall = false
     if(a.state=="fall") a.state = "walk"
    end
  end

 return true -- was pushed!
end


-------------------------------
function update_ons(a)
 a.on_ladder = false
 a.head_on_ladder = false
 a.on_zip = false
 a.on_wire = false
 a.on_ow = false
 a.on_awn = false
 a.awn_dir = 0
 a.on_slide = false

 local r = a.radius
 local min_wx = a.wx - r
 local max_wx = a.wx + r
 local min_wy = a.wy - r
 local mid_wy = a.wy
 local max_wy = a.wy + r

 local min_tx = flr(min_wx / 8)
 local max_tx = flr(max_wx / 8)
 local min_ty = flr(min_wy / 8)
 local mid_ty = flr(mid_wy / 8)
 local max_ty = flr(max_wy / 8)

 local dist_x_to_closest_ladder = g_grab_ladder_dist_x
 for ty = min_ty,max_ty do
  for tx = min_tx,max_tx do
   local tile = mget(tx,ty)

   -- on ladder?
   if fget(tile, bit_ladder) then
    local tile_center_wx = (tx * 8) + 4
    local dist_x_to_ladder = abs(tile_center_wx - a.wx)
    if ty <= mid_ty then
     a.head_on_ladder = true
    end
    if dist_x_to_ladder < dist_x_to_closest_ladder then
     a.on_ladder = true -- at least one tile i overlap is climbable
     dist_x_to_closest_ladder = dist_x_to_ladder -- this is closest ladder
     a.ladderx = tile_center_wx - 0.01 -- snap x to here if climbing
    end -- if closest ladder
   end -- if ladder

   -- zip, wire, slide, spikes?
   if (tile==spr_zip_top or tile==spr_zip_bottom) a.on_zip = true
   if ((tile==spr_wire or tile==spr_wire_end) and a.wy >= ty*8+2 and a.wy <= ty*8+6) a.on_wire = true
   if (is_slide(tile)) a.on_slide = true 

   -- on awning?
   if a.wy>=ty*8+2 and a.wy<=ty*8+6 then
    if tile==36 or tile==35 then
     a.on_awn = true
     a.awn_dir += 1
    elseif tile==15 or tile==14 then
     a.on_awn = true
     a.awn_dir -= 1
    end
   end
 
   if(abs(a.awn_dir) > 1) a.awn_dir /= abs(a.awn_dir)

  end
 end
end


-------------------------------
function cam_ui()
 camera(0,0)
end


-------------------------------
function draw_ui()

 local k = g_player.keys
 spr_o(spr_key, 0,0, 0)
 print_o(k.."", 8,1, 10, 0)

 local m = g_player.myrrh
 local mc,oc = 10,0
 if m >= g_min_myrrh and g_state=="game" then
  print_o("get to the manger!", 21,1, 3, 0)
  mc = 3
  oc = 3
 end
 spr_o(spr_myrrh, 94,0, oc)
 print_o(m.."/"..g_min_myrrh, 104,1, mc, 0)

 if g_state=="game" then
  local tm = flr(g_time/60)
  local sec = g_time - (tm*60)
  local tsec = flr(sec/10)
  sec -= (tsec*10)
  secf = flr(10*(sec-flr(sec)))
  sec = flr(sec)
  if tm > 9 then
   print_o(tm..":"..tsec..sec, 104,8, 6, 0)
  else
   print_o(tm..":"..tsec..sec.."."..secf, 104,8, 6, 0)
  end
 end
 
 if(gd_msg and #gd_msg>0) print_o(gd_msg, 0,0, 8, 0)
 
end


-------------------------------
function get_sign(tx,ty)
 for sign in all(g_signs) do
  if(sign[1]==tx and sign[2]==ty) return sign
 end
 err("sign at "..tx..","..ty.." was unlisted!")
end


-------------------------------
function spr_o(s, x,y, outline_color)
 pal()
 for c=1,15 do
  pal(c, outline_color)
 end
 spr(s,x+1,y+1)
 spr(s,x+0,y+1)
 spr(s,x-1,y+1)
 spr(s,x+1,y+0)
 spr(s,x-1,y+0)
 spr(s,x+1,y-1)
 spr(s,x+0,y-1)
 spr(s,x-1,y-1)
 set_pal()
 spr(s, x,y)
end


-------------------------------
-- print string s at x,y with
-- color c and outline optional
function print_o(s,x,y,c,o)
 if o ~= nil then
  print(s,x+1,y+1,o)
  print(s,x+0,y+1,o)
  print(s,x-1,y+1,o)
  print(s,x+1,y+0,o)
  print(s,x-1,y+0,o)
  print(s,x+1,y-1,o)
  print(s,x+0,y-1,o)
  print(s,x-1,y-1,o)
 end
 print(s,x,y,c)
end


-------------------------------
function print_t( s,x,y,c,t )
 local l = mid(flr(g_frame/2) - t,0,#s)
 print( sub(s,1,l),x,y,c )
end


-------------------------------
function smoothstep(t)
 return t * t * (3 - 2*t)
end

--#include dev.p8
