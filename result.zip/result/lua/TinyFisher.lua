function a()
srand(rotl(time()*1.234123,16))
music(1+rnd(8))
c={}
c.d=64*8
c.e=32*8+28
c.f=0
c.g=0
c.h=.4
c.i=.85
j=false
k=false
l=0
m=0
n=0
o=0
p=.125
q=c.d
r=c.e
s=0
t=u()
v=u()
w=x()
y=x()
z=.95
ba=c.d
bb=c.e
bc=0
bd=0
be=0
bf=0
bg=1
bh=false
bi=0
bj=0
bk=0
bl={}
bm=0
bn=false
bo=false
bp=false
bq=false
br=c.d
bs=c.e
bt=0
bu={}
bv={}
bv.d=rnd(1024)
bv.e=rnd(512)
bv.f=0
bv.g=0
bv.i=.8
bv.bw=false
bv.bx=0
bv.by=0
bz=false
ca=64*8
cb=32*8
reload(0,0,0x3000)
cc={}
cd={}
ce={}
for d=0,127 do
cc[d]={}
ce[d]={}
for e=0,63 do
cc[d][e]={0,0}
end
end
local cf=rnd(128)
local cg=rnd(64)
local f=0
local g=0
for ch=1,6000 do
f+=rnd(.5)-.25
g+=rnd(.5)-.25
f*=.9
g*=.9
cf+=f
cg+=g
for d=cf,cf+1 do
for e=cg,cg+1 do
d=flr(d)%128
e=flr(e)%64
local ci=d-ca/8
local cj=e-cb/8
if ci*ci+cj*cj>10*10 then
mset(d,e,19)
local ck=cc[d][e]
ck[1]+=f
ck[2]+=g
end
end
end
end
for d=0,127 do
for e=0,63 do
if mget(d,e)!=19 then
if mget(d+1,e)==19 then
if mget(d-1,e)==19 then
if mget(d,e+1)==19 then
if mget(d,e-1)==19 then
mset(d,e,19)
end
end
end
end
end
end
end
cf=rnd(128)
cg=rnd(64)
f=0
g=0
for ch=1,5000 do
local cl=.001
local cm=mget(cf,cg)
if cm==19 or cm==21 then
cl=.2
end
if rnd()<cl then
cf=rnd(128)
cg=rnd(64)
end
f+=rnd(.2)-.1
g+=rnd(.2)-.1
f*=.97
g*=.97
cf+=f
cg+=g
for d=cf,cf+1 do
d%=128
local e=cg%64
local cm=mget(d,e)
if cm!=19 and cm!=21 then
mset(d,e,1)
else
mset(d,e,21)
end
end
end
for d=0,127 do
for e=0,63 do
local cm=mget(d,e)
if cm==19 or cm==21 then
local cn=false
for ch=d-1,d+1 do
for co=e-1,e+1 do
if ch!=d or co!=e then
if ch==d or co==e then
local cp=mget(ch,co)
if cp<19 or cp>22 then
cn=true
end
end
end
end
end
if(cn) mset(d,e,cm+1)
end
end
end
for d=0,127 do
cd[d]={}
for e=0,63 do
cd[d][e]=cq(d,e)
end
end
for d=0,127 do
for e=0,63 do
local cm=mget(d,e)
if cm==16 then
local cr=sin(d*e/234.34)*cos(d*d*e/137.79)
local cs=5
for ch=d-4,d+4 do
for co=e-4,e+4 do
local cp=mget(ch,co)
if cp==1 then
cs=min(cs,
sqrt((ch-d)^2+(co-e)^2))
end
end
end
cr-=(1-cs/5)*(1+rnd())
if cr<-.5 then
cm=48
elseif cr<0 then
cm=32
end
mset(d,e,cm)
end
end
end
end
function _init()
ct="title"
cu=1
cv=0
cw=0
cx=60
cy={25,"clock",
100,"sensor",
250,"compass",
1000,"harpoon"}
cz={"       counts\n------>down to\n       sunset",
"       finds\n  ---->valuable\n       fish",
"       points\n   --->toward\n       home",
"       catches\n    -->fish\n       instantly"}
da={}
db={1,2,12,13}
dc={5,4,9}
dd={4,3,11}
end
function _draw()
if ct=="title"then
cls(1)
fillp(0b1010010110100101.1)
rectfill(0,30,127,97,2)
fillp()
for ch=0,1 do
if(ch==0) pal(7,5)
spr(64,46,7-ch,5,3)
pal()
end
de("a game by eli piilonen",20,101,13,5)
de("with music by david carney",12,110,6,5)
de("press 🅾️ (keyboard: z)",20,119,14,2)
srand(1)
for ch=1,900 do
local d=(rnd(128)-time()*15+sin(cos(time()*(.05+rnd(.05))))*(5+rnd(5)))%128
local e=44+rnd(40)+sin(cos(time()*(.03+rnd(.06))))*(5+rnd(5))
pset(d,e,db[ch%#db+1])
end
elseif ct=="game"then
cls(3)
camera(br-64,bs-64)
for df=flr((br-71)/8),(br+71)/8 do
for dg=flr((bs-71)/8),(bs+71)/8 do
local dh=df%128
local di=dg%64
srand(dh*64+di)
local cm=mget(dh,di)
if cm==16 or cm==32 then
if rnd()<.5 then
pal(11,8+rnd(4))
spr(cm+1,
df*8+rnd(3)-1,
dg*8+rnd(2),
1,1,
rnd()<.5,
rnd()<.5)
pal()
end
local dj=sin(time()+dh/8.1+di/12.2)
local dk=rnd()>.5
local dl=rnd()>.5
spr(cm+1,
df*8,
dg*8,
1,1,
dk,
dl)
pal(11,8+rnd(4))
spr(cm+1,
df*8+.5+dj*(.5+rnd()),
dg*8-1,
1,1,
dk,
dl)
pal()
elseif cm==1 then
spr(2+rnd(6),
df*8,
dg*8,
1,1,
rnd()<.5)
elseif cm>18 and cm<23 then
if cm==20 or cm==22 then
for ch=1,6 do
circfill(df*8+1+rnd(6),
dg*8+1+rnd(6),
4,
1)
end
else
rectfill(df*8,dg*8,
df*8+7,
dg*8+7,
1)
end
local dm=13
if rnd()<.5 then
dm=12
end
local ck=cc[dh][di]
local cl=rnd(8)
local dn=rnd(8)
local dp=time()*4
local dq=df*8+flr(cl+ck[1]*dp)%8
local dr=df*8+flr(cl+ck[1]*(dp+.3))%8
local ds=dg*8+flr(dn+ck[2]*dp)%8
local dt=dg*8+flr(dn+ck[2]*(dp+.3))%8
pset(dq,ds,dm)
pset(dr,dt,dm)
if cm>20 then
local du=0
if abs(dh*8+4-c.d)<6 and abs(di*8+4-c.e)<6 then
du=1
end
spr(34+rnd(4),df*8,dg*8+du,1,1,rnd()<.5)
else
if da.sensor then
if j then
if ce[dh][di] then
spr(51,df*8,dg*8)
else
local ck=cc[dh][di]
local dw=cd[dh][di]
local dx=(abs(ck[1])+abs(ck[2])+1)*dw
if dx>40 and time()*dx/10%1<.5 then
local dm=2
if(dx>100) dm=14
fillp(0b1010010110100101.1)
rect(df*8,dg*8,
df*8+7,
dg*8+7,
dm)
fillp()
end
end
end
end
end
end
end
end
dy(-1)
if c.dz and bb<y.e then
dz()
end
if ea and ea.eb<y.e then
ec()
end
for ch,ed in pairs(bu) do
line(ed.ee,ed.ef-ed.eg,
ed.d,ed.e-ed.eh,
ed.ei[flr(ed.ej*#ed.ei*ed.ek)+1])
end
for ch=c.d-2,c.d+2 do
el(ch,c.e+1)
if ch>c.d-2 and ch<c.d+2 then
el(ch,c.e)
el(ch,c.e+2)
end
end
for ch=0,1,.2 do
for co=1,2 do
for em=1,2 do
local en=t
local eo=w
if(em==2) en,eo=v,y
el(q+(en.d-q)*ch,
r+(en.e-r)*ch+co)
el(c.d+(eo.d-c.d)*ch,
c.e+(eo.e-c.e)*ch+co-1)
end
end
end
local ep=cos(s)
local eq=sin(s)
for ch=1,2 do
local en=t
if(ch==2) en=v
er(q,r,5.5,en.d,en.e,en.eh,7,ep,eq,0,14,2)
end
es(c.d,c.e-9,q,r-5.5,2,2)
for ch=1,2 do
local eo=w
if(ch==2) eo=y
er(c.d,c.e,9,eo.d,eo.e,eo.eh,6.5,(-ep+eq*(1.5-ch))*.7,(-eq-ep*(1.5-ch))*.7,0,14,2)
end
if k then
for ch=0,1 do
line(y.d,y.e-y.eh-ch,
y.d+ep*1.5,y.e-y.eh-ch+eq*1.5,
5+ch)
end
end
circfill(c.d,c.e-11,3,2)
circfill(c.d,c.e-11,2,14)
if c.dz and bb>=y.e then
dz()
end
if ea and ea.eb>=y.e then
ec()
end
if j then
local et=time()
for d=-2,2 do
for e=-2,2 do
if abs(d)-abs(e)!=0 then
local eu=5
if(k) eu=8
pset(l+d,m+e,eu+(et*4+d/4+e/4)%3)
end
end
end
end
dy(1)
if bt>1 then
ev()
end
local ew="🅾️ (hold) aim"
local dm=6
if da.harpoon then
ew="🅾️/❎ (hold) aim"
end
if bh then
ew="🅾️ reel"
if ey<0 then
print("🅾️",ba-4,bb-8-(time()*8)%2,8+(time()*8)%3)
end
end
if bn then
ew="🅾️ enter"
dm=7
circfill(ca-1,cb,5,1)
de("🅾️",ca-4,cb-3,13+(time()*4)%2,2)
end
if j or bo then
ew=""
end
ez(ew,br-62,bs+57,dm,1)
local fa=max((1-bt)*9,0)
local fb=shr(0b0001000100010001.0001000100010001,4*flr(fa*8))
local et=time()/64
for ch=0x6000,0x7fff,4 do
poke4(ch,peek4(ch)-rotr(fb,flr(ch*et)*4))
end
local ff="$"..cw.." in cash"
ez(ff,br+62-#ff*4,bs-62,11,3)
ff="$"..bm.." in fish"
ez(ff,br+62-#ff*4,bs-54,14,2)
if da.clock and bt<1 then
local fh=flr((1-bt)*cx)
local fi=flr(fh/60)..":"
local fj=fh%60
if(fj<10) fj="0"..fj
ez(fi..fj,br+46,bs-46,11-bt*3,4-bt*3)
end
if da.compass then
local ci=(ca-c.d)/8
local cj=(cb-c.e)/8
ci-=flr((ci+64)/128)*128
cj-=flr((cj+32)/64)*64
local fl=atan2(ci,cj)
local fm=flr(cos(fl)*5+.5)
local fn=flr(sin(fl)*5+.5)
local d=br+55
local e=bs+54
circ(d,e+1,7,5)
circ(d,e,7,7)
line(d,e+1,d+fm,e+fn+1,5)
line(d,e,d+fm,e+fn,7)
end
elseif ct=="fish"then
cls()
camera()
sspr(0,0,128,64,0,0,128,128)
local fa=1-fo
fa=1-(fa^4*2-fa^2)
fillp(0b1010010110100101.1)
circfill(64,64,fa*fp.fq*5+15,13)
fillp()
fr(fp,64,256-fa*192,1)
ez("size: "..flr(fp.fq*10)/10,40,130-30*fa,12,1)
ez("quality: "..flr(fp.fs*10)/10,42,147-40*fa,14,2)
ez("value: $"..fp.dx,44,164-50*fa,11,3)
if fp.ft==0 then
ez("(dead: 1/4 value)",28,121,9,5)
end
ez("press 🅾️",3,-7+9*fa,7,5)
elseif ct=="store"then
cls()
if fu=="sell"then
camera(0,-cv^2*128)
fv="you didn't catch any fish"
if c.fw then
fv="you were caught by a monster"
end
if bm>0 then
fv="you sold "..#bl.." fish for $"..bm.."!"
end
de(fv,64-#fv*2,10,11,3)
de("press 🅾️",1,120,14,2)
if#bl>0 then
if#bl<3 then
for ch=1,#bl do
local fx=bl[ch]
local d=(ch-1)*48+64-(#bl-1)*24
fr(fx,d,64,.4)
ez("$"..fx.dx,d-6,64-15,11,3)
end
else
for ch=0,3 do
local fx=bl[flr(ch+time()/2)%#bl+1]
local d=32-time()/2%1*64+ch*64
fr(fx,d,64,.4)
ez("$"..fx.dx,d-6,64-15,11,3)
end
end
end
elseif fu=="buy"then
cls()
camera(cv^2*128,0)
de("you have $"..cw,5,5,11,3)
for ch=1,#cz+1 do
local d=18
local e=45+ch*7
local fy=9
local fz=4
local ff="all done"
local ga=true
if(ch<=#cz) then
fy=6
fz=5
local gb=cy[ch*2]
if(da[gb]) then
ga=false
fy=4
fz=2
end
ff="$"..cy[ch*2-1].."-"..gb
e-=5
if gc==ch then
local gd=cz[ch]
de(gd,56,e-6,14,2)
end
end
if gc==ch then
d+=2
if ga then
fy+=1
end
end
de(ff,d,e,fy,fz)
if not ga then
line(d-1,e+2,d+#ff*4,e+2,13)
end
end
end
elseif ct=="victory"then
cls()
camera()
local ge={"you have quieted the source",
"of your anxiety",
"",
"your nightmares fade",
"and you rest peacefully"}
for ch=1,5 do
de(ge[ch],64-#ge[ch]*2,30+ch*7,7,5)
end
end
if cu>0 then
for ch=1,15 do
pal(ch,ch*(1-min(cu,1))+rnd(),1)
end
end
end
function _update()
if bp or bq then
cu+=.05
if cu>1 then
if bp then
ct="store"
fu="sell"
cw+=bm
end
if bq then
ct="game"
a()
end
cu=1
bp=false
bq=false
end
elseif cu>0 then
cu-=.05
end
local by=32
if ct=="game"then
by=32+(bt-.9)*80
by=mid(by,32,99)
end
for ch=2,27 do
poke(0x3200+68*ch+65,by)
end
if ct=="title"then
if btnp(4) then
bq=true
end
elseif ct=="game"then
bt+=1/30/cx
if ea then
ea.ej-=1/20
if ea.ej<0 then
ea=nil
end
end
for ch,ed in pairs(bu) do
ed.ee=ed.d
ed.ef=ed.e
ed.eg=ed.eh
ed.gf-=.3
ed.f*=.95
ed.g*=.95
ed.gf*=.95
ed.d+=ed.f
ed.e+=ed.g
ed.eh+=ed.gf
ed.ej-=.03/ed.gg
if ed.eh<0 then
ed.eh=0
ed.f*=.8
ed.g*=.8
ed.gf*=-.5
end
if(ed.ej<0) del(bu,ed)
end
if bh then
c.dz=true
else
local ci=y.d-ba
local cj=y.e-bb
local gh=y.eh-bc
ba+=ci/2
bb+=cj/2
bc+=gh/2
local gi=ci*ci+cj*cj+gh*gh
if gi>64 then
c.dz=true
else
c.dz=false
end
end
if btn(4) or(btn(5) and da.harpoon) then
if not j and not bh and not gj then
j=true
l=c.d+cos(s)*32
m=c.e+sin(s)*32
n=0
o=0
if btn(5) and da.harpoon then
k=true
end
end
s=atan2(l-c.d,m-c.e)
else
gj=false
if j then
j=false
if k then
k=false
gk(l,m)
gj=true
else
bh=true
sfx(30)
ey=gl()
bj=0
ba=c.d
bb=c.e
bc=8
local gm=l-c.d
local gn=m-c.e
bd=gm/12
be=gn/12
bf=3
bg=sqrt(gm*gm+gn*gn)+4
end
end
end
if btnp(4) and bh then
bh=false
gj=true
if go and ey<0 then
gp()
gq(ba,bb)
ba=y.d
bb=y.e
bc=y.eh
end
end
local gr=0
local gs=0
if not bo then
if(btn(0)) gr-=1
if(btn(1)) gr+=1
if(btn(2)) gs-=1
if(btn(3)) gs+=1
else
if ca>c.d+2 then
gr=1
elseif ca<c.d-2 then
gr=-1
end
if c.e>cb+5 then
gs=-.6
else
bp=true
end
end
if gr!=0 and gs!=0 then
gr*=.707
gs*=.707
end
if not j then
c.f+=gr*c.h
c.g+=gs*c.h
else
n+=gr*c.h
o+=gs*c.h
end
c.f*=c.i
c.g*=c.i
n*=c.i
o*=c.i
l+=n
m+=o
local gm=l-c.d
local gn=m-c.e
local gt=sqrt(gm*gm+gn*gn)
if gt>64 then
gm/=gt
gn/=gt
l=c.d+gm*64
m=c.e+gn*64
end
if k then
bk+=1/10
else
bk-=1/10
end
bk=mid(bk,0,1)
if bh then
bj+=1/10
if(bj>1) bj=1
go=false
bf-=.3
ba+=bd
bb+=be
bc+=bf
local ci=ba-c.d
local cj=bb-c.e
local gu=sqrt(ci*ci+cj*cj)
if gu>bg then
ba+=(c.d+ci/gu*bg-ba)/2
bb+=(c.e+cj/gu*bg-bb)/2
gu=bg
end
gv=(bg-gu)/2
s=atan2(ba-c.d,bb-c.e)
if bc<=0 then
bc=0
local dh=flr(ba/8)%128
local di=flr(bb/8)%64
local cm=mget(dh,di)
if cm==19 or cm==20 then
if(bf<-1) sfx(33)
bf=0
go=true
if not ce[dh][di] then
ey-=1/30
if ey<-1 then
ey=gl()
end
else
ey=gl()
end
local ck=cc[dh][di]
bd+=ck[1]/80
be+=ck[2]/80
else
bf*=-.8
bd*=.8
be*=.8
end
end
bd*=z
be*=z
bf*=z
if not go then
ey=gl()
end
else
bj-=1/20
if(bj<0) bj=0
end
if gr!=0 or gs!=0 then
if abs(c.f)>.3 or abs(c.g)>.3 then
local gw=atan2(c.f,c.g)
if(gw>s+.5) gw-=1
if(gw<s-.5) gw+=1
if abs(gw-s)<.025 then
s=gw
else
s+=sgn(gw-s)*.025
end
end
end
bn=false
if not bo then
local ci=c.d+c.f-ca
local cj=c.e+c.g-cb
if abs(ci)<40 and abs(cj)<40 then
local dw=sqrt(ci*ci+cj*cj)
if dw<26.5 then
c.f=0
c.g=0
end
if cj>0 and abs(ci)<10 then
bn=true
if btnp(4) then
bo=true
j=false
k=false
gj=true
music(-1)
end
end
end
end
if not gx(c.d+c.f,c.e) then
c.d+=c.f
else
c.f=0
end
if not gx(c.d,c.e+c.g) then
c.e+=c.g
else
c.g=0
end
q=(t.d+v.d+c.d*3)/5
r=(t.e+v.e+c.e*3)/5
local fm=cos(s)*1.5
local fn=sin(s)*1.5
for ch=1,2 do
local en=t
local gy=v
local eo=w
local gz=fn
local ha=-fm
if(ch==2) then
gz,ha=-gz,-ha
en,gy=v,t
eo=y
end
local ci=q+c.f+gz-en.d
local cj=r+c.g+ha-en.e
local dw=ci*ci+cj*cj
if en.hb then
en.hc+=p
if en.hc>1 then
en.hc=1
en.hb=false
end
local hd=c.d+gz+c.f*2
local he=c.e+ha+c.g*2
en.d=en.hf+(hd-en.hf)*en.hc
en.e=en.hg+(he-en.hg)*en.hc
en.eh=(1-abs(en.hc-.5)*2)*4
else
if gy.hc>.7 then
if dw>2.25 then
en.hb=true
en.hc=0
en.hf=en.d
en.hg=en.e
end
end
end
eo.d=c.d+(gy.d-q)*.5+gz*2
eo.e=c.e+(gy.e-r)*.5+ha*2
eo.eh=5.5+gy.eh*.5
end
y.d+=(fm*3-fn)*bj
y.e+=(fn*3+fm)*bj
y.eh+=2*bj
y.d+=(fm*4+fn)*bk
y.e+=(fn*4-fm)*bk
y.eh+=2*bk
local hh=c.d+c.f*12
local hi=c.e+c.g*12
if j then
hh+=(l-c.d)/2
hi+=(m-c.e)/2
elseif bh then
hh+=(ba-c.d)/2
hi+=(bb-c.e)/2
end
br+=(hh-br)/8
bs+=(hi-bs)/8
local hj=0
local hk=0
if c.d<0 then
hj=1024
end
if c.d>1024 then
hj=-1024
end
c.d+=hj
br+=hj
q+=hj
t.d+=hj
v.d+=hj
t.hf+=hj
v.hf+=hj
w.d+=hj
y.d+=hj
l+=hj
ba+=hj
if c.e<0 then
hk=512
end
if c.e>512 then
hk=-512
end
c.e+=hk
bs+=hk
r+=hk
t.e+=hk
v.e+=hk
t.hg+=hk
v.hg+=hk
w.e+=hk
y.e+=hk
m+=hk
bb+=hk
if bt>1 then
local ci=c.d-bv.d
local cj=c.e-bv.e
if ci>64*8 then
ci-=128*8
bv.d+=128*8
end
if ci<-64*8 then
ci+=128*8
bv.d-=128*8
end
if cj>32*8 then
cj-=64*8
bv.e+=64*8
end
if cj<-32*8 then
cj+=64*8
bv.e-=64*8
end
if stat(20)==31 or bv.bx==0 then
local hl=ci/8
local hm=cj/8
local hn=sqrt(hl*hl+hm*hm)
local ho=flr(hn*.3)+3
ho=mid(ho,4,30)
poke(0x3200+65,ho)
poke(0x3200+133,ho)
end
if bt>1.04 and not bz and not bo then
bz=true
music(0)
elseif bt>1 and bt<1.04 then
music(-1)
end
bv.bx+=.01
if(bv.bx>1) bv.bx=1
bv.by+=.0005
if abs(ci)>10 then
bv.f+=sgn(ci)*bv.by
end
if abs(cj)>10 then
bv.g+=sgn(cj)*bv.by
end
if not c.fw and not bo and bv.bx>=1 then
if abs(ci)<=10 and abs(cj)<=10 then
c.fw=true
bm=0
bl={}
music(-1)
bp=true
end
end
bv.f*=bv.i
bv.g*=bv.i
bv.d+=bv.f
bv.e+=bv.g
end
elseif ct=="fish"then
if(fo<1) then
fo+=1/32
if(fo==.75) then
sfx(32)
end
end
if btnp(4) then
hp()
end
elseif ct=="store"then
if fu=="sell"then
if cu<=0 then
if stat(20)==-1 then
music(9)
end
if btnp(4) then
cv+=.01
sfx(31)
end
end
if(cv>0) cv+=1/10
if cv>1 then
fu="buy"
gc=1
end
elseif fu=="buy"then
cv=max(cv-1/15,0)
local hq=#cy/2+1
if btnp(2) then
gc-=1
sfx(31)
end
if btnp(3) then
gc+=1
sfx(31)
end
if(gc==0) gc=hq
if(gc>hq) gc=1
if btnp(4) then
if gc==hq then
bq=true
music(-1)
else
local hr=cy[gc*2-1]
local gb=cy[gc*2]
if cw>=hr and not da[gb] then
da[gb]=true
cw-=hr
sfx(32)
end
end
end
end
elseif ct=="victory"then
if btnp(4) and cu<.1 then
cls()
flip()
_init()
cu=5
end
end
end
function hs(d,e,ht,count)
local cm=mget(d/8%128,e/8%64)
local ei=db
if cm==21 or cm==22 then
ei=dc
elseif cm!=19 and cm!=20 then
ei=dd
if(rnd()<.5) ei=dc
end
for ch=1,count do
local ed={}
ed.d=d
ed.e=e
ed.eh=0
ed.ee=d
ed.ef=e
ed.eg=0
ed.f=rnd(ht)-ht/2
ed.g=rnd(ht)-ht/2
ed.gf=rnd(ht)
ed.ei=ei
ed.ek=rnd()
ed.ej=1
ed.gg=rnd()+.5
add(bu,ed)
end
end
function u()
local en={}
en.d=c.d
en.e=c.e
en.eh=0
en.hc=1
en.hb=false
en.hf=en.d
en.hg=en.e
return en
end
function x()
local eo={}
eo.d=c.d
eo.e=c.e
eo.eh=4
return eo
end
function el(d,e)
local hu=pget(d,e)
if hu!=1 then
pset(d,e,hu-1)
end
end
function gx(d,e)
for ch=0,3 do
local cm=mget((d+ch%2)/8%128,(e+ch/2)/8%64)
if(cm!=19 and cm!=20) return false
end
return true
end
function cq(df,dg)
local hv=32000
local hw=1
while hv==32000 do
for d=df-hw,df+hw do
for e=dg-hw,dg+hw do
local cm=mget(d,e)
if cm<19 or cm>22 then
local ci=abs(d-df)
local cj=abs(e-dg)
if ci==hw or cj==hw then
local dw=ci*ci+cj*cj
if dw<hv then
hv=dw
end
end
end
end
end
hw+=1
end
return hv
end
function gp()
camera()
for d=0,127 do
for e=0,127,2 do
local dm=pget(d,e)+pget(d+1,e)+pget(d-1,e)
sset(d,e/2,dm/3)
end
end
end
function gk(l,m)
sfx(29)
ea={}
ea.hx=y.d
ea.hy=y.e
ea.hz=y.eh
ea.ia=l
ea.eb=m
ea.ib=0
ea.ej=1
hs(l,m,4,30)
local cm=mget(ea.ia/8%128,ea.eb/8%64)
if cm==19 or cm==20 then
if not ce[flr(l/8)%128][flr(m/8)%64] then
ec()
gp()
gq(l,m,true)
end
end
if bt>1 and abs(l-bv.d)<25 and abs(m-bv.e)<25 then
ct="victory"
cu=5
music(-1)
end
end
function gq(d,e,fw)
d=flr(d/8)%128
e=flr(e/8)%64
fo=0
ce[d][e]=true
local ck=cc[d][e]
local cq=cd[d][e]
ct="fish"
sfx(34)
fp={}
fp.ft=1
if(fw) fp.ft=0
fp.fq=cq+rnd()
fp.fs=sqrt(ck[1]*ck[1]+ck[2]*ck[2])
fp.dx=flr(fp.fq*(fp.fs+1)*(.25+.75*fp.ft))+1
fp.ic=d*64+e+time()*100
for em=0,1 do
local id={0,0,0,0}
if fp.fs>2 then
for ch=0,16 do
if rnd()<.2 then
for co=1,4 do
local d=(ch%4-co)%4
local e=flr(ch/4)
local em=e*4+d
id[co]+=2^em
end
end
end
for ch=1,4 do
id[ch]=bor(id[ch],rotr(id[ch],16))
end
end
if em==0 then
fp.ie=id
elseif em==1 then
fp.ig=id
end
end
add(bl,fp)
bm+=fp.dx
end
function fr(fp,ih,ii,ij)
srand(fp.ic)
local gu=flr(20+fp.fq*5)
gu=min(gu,120)
local ik=-flr(-gu/(5+rnd(20)))
local il={}
il[1]=0
for ch=2,ik do
il[ch]=(rnd(gu/8)+gu/16)*ij
if ch==ik-2 then
il[ch]*=.5
end
end
local eu=flr(rnd(15))
local im=fp.fs/2
local io=mid(im,0,1)
local ip=flr(rnd(15)*io)
local iq=flr(rnd(4)*io)
local ir=flr(rnd(4)*io)
local is=flr(rnd(25)*(1-io)+7)
local it=flr(rnd(25)*(1-io)+7)
local iu=rnd(is)
local iv=flr(rnd(3)*io+1)
local iw=rnd(.3)+.3
local ix=rnd(.8)*im+.7
local iy=rnd(3)+2
local iz=-rnd(gu/20)
local ja=rnd(gu/20)
local jb=(rnd(.5)+.5)*fp.ft
local jc=rnd(.15)+.1
local jd=rnd(.6)+.2
local je=2+rnd(gu/40)
jf=rnd(15)
local jg=flr(rnd(9))+2
local jh=flr(rnd(9))+2
local ji,jj
local ie=fp.ie
local ig=fp.ig
local jk=ih-gu*ij/2
for ch=0,gu-1,1/ij do
local fa=ch/gu
local jl=flr(fa*(ik-1))+1
local jm=fa*(ik-1)-jl+1
jm=3*jm*jm-2*jm*jm*jm
local jn=il[jl]+(il[jl+1]-il[jl])*jm
local jo=flr(ch/is)
local jp=flr((ch+iu)/it)
local jq=cos(time()*jb-fa)*(1+iz*fa)
local d=ih+(-gu/2+ch+jq)*ij
local e=ii+(sin(time()*jb-fa)*(1+ja*fa))*ij
fillp(band(rotr(ie[flr((jq+ih)%4)+1],flr(e%4)*4),bnot(0b0.1)))
if ch<gu*jc and ch+1/ij>=gu*jc then
ji=d
jj=e-jn*jd
end
for co=0,iv-1 do
jr=e-jn+co*jn*2/iv
js=e-jn+(co+1)*jn*2/iv
local dm=((ip*jo+iq*(co%2))%8+eu)%15+1
rectfill(jk+1,jr,d,js,dm+16*jg)
end
for ch=0,jn/2 do
if rnd()*io>(ch/(jn/2)) then
for co=-1,1,2 do
pset(d,e+(jn-ch)*co,pget(d,e+(jn-ch)*co)-1)
end
end
end
local jt=(1-mid(abs(fa-iw)/iw,0,1))^iy+mid(1-abs(fa-.95)*2,0,1)^iy
local ju=gu/3*jt*ix*ij
ju=min(ju,60)
if ju>jn then
fillp(band(rotr(ig[flr((jq+ih)%4)+1],flr(e%4)*4),bnot(0b0.1)))
dm=((ip*jp+ir)%8+eu)%15+1
rectfill(jk+1,e-ju,d,e-jn-2,dm+16*jh)
rectfill(jk+1,e+jn+2,d,e+ju,dm+16*jh)
line(d,e-ju-1,d,e-ju-2,0)
line(d,e+ju+1,d,e+ju+2,0)
for ch=0,(ju-jn)/2 do
if rnd()*io>(ch/((ju-jn)/2)) then
local dm=pget(d,e-ju+ch)
pset(d,e-ju+ch,dm-1)
local fz=pget(d,e+ju-ch)
pset(d,e+ju-ch,fz-1)
end
end
end
rect(jk,e-jn-1,d,e-jn-2,0)
rect(jk,e+jn+1,d,e+jn+2,0)
jk=d
end
fillp()
circfill(ji,jj+1,je*ij,5)
circfill(ji,jj,je*ij,6)
circfill(ji,jj,(je-1)*ij,7)
if fp.ft>0 then
circfill(ji-je/3,jj,je/2*ij,jf)
end
end
function ev()
local fa=time()
local jv=sin(fa)*.4+.6
for em=0,1 do
for co=1,-1,-2 do
for ch=-3.5,3.5 do
local fq=(3.5-abs(ch))*2+4
d=bv.d+ch*3.5
e=bv.e-10
e+=co*(4-abs(ch))*(jv+.1)*3
hx=64
if(ch>0) hx=80
if(co==1) e+=8-fq
clip(d-fq/2-br+64,e-bs+64,
fq,fq+8)
e+=(1-bv.bx)*20
if em==1 then
sspr(hx,0,16,16,
d-fq/2,
e,
fq,fq,
false,
co==1)
else
for jw=1,15 do
el(d+rnd(fq)-fq/2,
e+rnd(fq)-fq/2+8)
end
end
end
end
end
clip()
for ch=10,100 do
local d=cos(fa/4+ch/35.19)*20
local e=sin(fa*.318+ch/30.93)*20
local eh=sin(cos(fa/6.57+ch/40.71))*20+bv.bx*10
local dw=sqrt(d*d+e*e+eh*eh)
d=d/dw*25
e=e/dw*25
eh=eh/dw*25
if ch%2==0 then
fillp(0b1010010110100101.1)
end
if eh>0 then
local ij=(sin(fa*ch/30)/2+.5)
ij*=min(eh/4,1)
ij*=bv.bx*8
if(ij>1) then
circfill(bv.d+d,
bv.e+e-eh,
ij-2,
1)
circ(bv.d+d,
bv.e+e-eh,
ij,
1)
end
end
fillp()
end
end
function hp()
ct="game"
reload(0,0,0x1000)
end
function er(jx,jr,jy,jz,js,ka,gu,kb,kc,kd,dm,fz)
local ci=jz-jx
local cj=js-jr
local gh=ka-jy
local dw=sqrt(ci*ci+cj*cj+gh*gh)
if dw>gu then
jz=jx+ci/dw*gu
js=jr+cj/dw*gu
ka=jy+gh/dw*gu
es(jx,jr-jy,jz,js-ka,dm,fz)
else
local ke=(jx+jz)/2
local kf=(jr+js)/2
local kg=(jy+ka)/2
local kh=(gu-dw)/1.4
ke+=kb*kh
kf+=kc*kh
kg+=kd*kh
es(jx,jr-jy,ke,kf-kg,dm,fz)
es(jz,js-ka,ke,kf-kg,dm,fz)
end
end
function es(jx,jr,jz,js,fy,fz)
line(jx+1,jr,jz+1,js,fz)
line(jx-1,jr,jz-1,js,fz)
line(jx,jr+1,jz,js+1,fz)
line(jx,jr,jz,js,fy)
end
function de(ff,d,e,fy,fz)
print(ff,d,e+1,fz)
print(ff,d,e,fy)
end
function ez(ff,d,e,fy,fz)
print(ff,d+1,e,fz)
print(ff,d-1,e,fz)
print(ff,d,e+1,fz)
print(ff,d,e-1,fz)
print(ff,d,e,fy)
end
function gl()
return 1+rnd(9)
end
function ki(fa)
fa=abs(fa-.5)*2
fa*=fa
return 1-fa
end
function dz()
local kj=(bc)
local ci=ba-y.d
local cj=bb-y.e
local dw=sqrt(ci*ci+cj*cj)
for ch=0,1,1.5/dw do
el(y.d+ci*ch,
y.e+cj*ch)
end
for co=1,0,-1 do
for ch=0,.95,.05 do
local jx=ba+(y.d-ba)*ch
local jr=bb+(y.e-bb)*ch
local jy=bc+(y.eh-bc)*ch
local jz=ba+(y.d-ba)*(ch+.05)
local js=bb+(y.e-bb)*(ch+.05)
local ka=bc+(y.eh-bc)*(ch+.05)
local kk=gv
if not bh then
kk=0
kj=0
end
jy-=ki(ch)*(kk-kj)
ka-=ki(ch+.05)*(kk-kj)
if(jy<0) jy=0
if(ka<0) ka=0
line(jx,jr-jy+co,jz,js-ka+co,5-3*co)
end
end
if not go or not bh then
spr(50,ba-1,bb-bc-1)
end
end
function ec()
local dm=5+ea.ej*2.9
if ea.ej<.5 then
fillp(0b1010010110100101.1)
end
line(ea.hx,ea.hy-ea.hz,
ea.ia,ea.eb-ea.ib,
dm)
fillp()
end
function dy(kl)
for co=0,5 do
local count=flr((6-co)*1.5)
for em=0,1 do
for ch=0,count do
local km=ch/count
if em==0 then
km=.25-km*.4
else
km=.25+km*.4
end
local fa=co/5
local d=ca+cos(km)*20*(1-fa)
local e=cb+sin(km)*20*(1-fa)
if abs(d-c.d)>64*8 then
d+=sgn(c.d-d)*128*8
end
if abs(e-c.e)>32*8 then
e+=sgn(c.e-e)*64*8
end
local eh=co*5
if sgn(e-c.e)==kl then
spr(15,d-4,e-eh-4)
end
end
end
end
end