--froggi knight
	debx=1000
	deby=200
	debug=false
function _init()
	player={
		x=8,y=220,
		w=16,h=16,
		dx=0,dy=0,
		max_dx=2,
		max_dy=3,
		jump=4,
		first_sp=true,
		sp=64,
		anim_time=.15,
		facing=false,--right=false
		atk_state=0,
		a_length=12,
		speed=1.333,
		delta_t=0,
		moving=false,
		jumping=false,
		falling=false,
		upgrading=false,
		max_health=3,
		health=3,
		sword_box={
			x=8,y=0,s=12
		},
		vul=true,
		flash=false,
		hurt=false,
		move_lock=false,
		
		dub_jump=false,
		jumps=1,
		bubble=false,
		
		m_move=0,
		m_sp=-1,
	}
	cors={
		p_inv=nil,
		sword=nil,
		death=nil,
		upgrade=nil,
		door=nil,
		end_sc=nil,
		start=nil,
		intro=nil
	}
	if debug then
		player.bubble=true
		player.dub_jump=true
		player.x=debx
		player.y=deby
		game_state="game"
	end	
	title_sc={
	0x2c23,0x2323,0x2344,
	0x8c06,0x0003,0x0397,
	0x5d55,0x9a9a,0x9a9a,
	0xdddd,0xdddd,0xdddd,
	0x4483,0x4234,0x44dd,
	0x0600,0x0038,0x78cd,
	0x5555,0x59a5,0x59ad}
	the_end={
	0x4d44,0x2c2c,0x8343,
	0x8c87,0x8c8c,0x0000,
	0x9c55,0x9c9c,0x555a
	}
	gravity=.4
	friction=.5	
	max_dy=3
	cur_sc=0
	palt(1, true)
	palt(0,false)

	signs={}
	swim={
		x=552,y=200,
		msg={
			"frog fact:",
			"frogs can hold",
			"their breath for",
			"4 to 6 hours!"
		}
	}
	jump={
		x=935,y=96,
		msg={
			"frog fact:",
			"a frog can",
			"jump over 44",
			"times its body",
			"length!"
		}
	}	
	
	add(signs,swim)
	add(signs,jump)
	
	add_enemies()
	--actor key: ypos/16,xpos16,
	--type,screen
	actor_list={0x08420,0x6a34,0xb908,
	0xa909,0x7b19,0x7b18,0x821a,0xff5a,
	0xaa60,0x6760,0x9061,0x6c46,
	0x8145,0x4845,0xa146,0xfb5b,
	0x7b1c,0xa90d,0x4e1d,0x4e0d
	}
	if(not debug)cors.intro=cocreate(intro)
end

function intro()
	game_state="intro"
	music(32)
	player.move_lock=true
	fade_pal(true,.2)
	wait(3)
	fade_pal(false,.2)
	game_state="title"
	wait(.5)
	fade_pal(true,.2)
	player.move_lock=false
end

function fade_pal(fade_in,s)
	if fade_in then
		shift_pal(1,15,0)
		wait(s)
		shift_pal(5,15,5)
		wait(s)
		shift_pal(1,15,-1)
		return
	else
		shift_pal(5,15,5)
		wait(s)
		shift_pal(1,15,0)
		return
	end
end

function title_screen()
	game_state="title"
	active_actors={}
	cur_sc=0
	music(32)
end

function start_game()
	player.move_lock=true
	cur_sc=8
	player.x=8
	player.y=220
	door_open=false
	end_cutscene=false
	end_close=false	
	player.bubble=false
	player.dub_jump=false
	player.jumps=1
	sfx(60)
	fade_pal(false,.2)
	game_state="game"
	wait(1.2)
	music(-1)
	fade_pal(true,.2)
	load_actors(0)
	load_actors(1)
	music(0)
	player.move_lock=false
end

function add_enemies()
	--enemy info
	scorpion={
		w=16,h=16,
		sp_list={98,100},
		speed=1,
		facing=0,
		anim_length=.15,
		name="scorpion"
	}
	spider={
		w=16,h=16,
		sp_list={96,97},
		speed=.8,
		facing=3,
		anim_length=.35,
		name="spider",
		
		wait_time=-1,
		start_y=-1
	}
	water_upgrade={
		w=8,h=8,
		speed=.03,
		sp_list={5},
		anim_length=0,
		name="upgrade",
		bob=4
	}
	jump_upgrade={
		w=8,h=8,
		speed=.03,
		sp_list={21},
		anim_length=0,
		name="upgrade",
		bob=4
	}
	bird={
		w=16,h=16,
		sp_list={108,110},
		speed=.15,
		facing=1,
		anim_length=.15,
		name="bird"
	}
	fish={
		w=16,h=16,
		sp_list={104,106},
		speed=1.4,
		facing=0,
		anim_length=100,
		name="fish",
		
		jumping,
		start_x,
		jump_wait
	}	
	jelly={
		w=16,h=16,
		sp_list={128,130},
		speed=.2,
		facing=0,
		anim_length=.3,
		name="jelly",
		bob=8
	}
	health={
		x=-1,y=-1,
		w=8,h=8,
		sp_list={16},
		facing=0,
		anim_length=0,
		name="health",
		active=false		
	}
	bubble={
		x=-1,y=-1,
		w=8,h=8,
		sp_list={5},
		facing=0,
		anim_length=0,
		name="bubble",
		active=false,
		speed=4
	}
	
	add(actors,scorpion)
	add(actors,spider)
	add(actors,water_upgrade)
	add(actors,jump_upgrade)
	add(actors,bird)
	add(actors,fish)
	add(actors,jelly)
	
	health_drop=new_actor(0,0,health,0)
	bub_shot=new_actor(0,0,bubble,0)
end

function get_band(data)
	return band(0x000f,data)
end

function coresume_check(cor)
	if cor and costatus(cor)!= 'dead' then
		coresume(cor)
		return true
	else
		cor=nil
		return false
	end
end

function player_attack()
	local hold_vul=player.vul
	local atk_timer=time()
	player.vul=false
	player.atk_state=1
	local x_off
	if(player.facing) then x_off=-8
	else x_off=8
	end
	player.x+=x_off
	if(player.bubble)spawn_bubble()
	while(time()-atk_timer<.1)yield()
	player.atk_state=2
	player.x-=x_off
	while(time()-atk_timer<.25)yield()
	player.atk_state=0
	player.vul=hold_vul
end

function player_hurt()
	sfx(61,1)
	player.health-=1
	cors.p_inv=cocreate(player_inv)
end

function player_inv()
	player.vul=false
	player.hurt=true
	local inv_time=time()
	local flash=time()
	while(time()-inv_time<2.5) do
		if(time()-inv_time>.5) player.hurt=false
		if time()-flash>.1 then
			flash=time()
			player.flash = not player.flash
		end
		yield()
	end
	player.flash=false
	player.vul=true
end

function update_screen()
	local lower = cur_sc>7
	local px = flr(player.x/128)
	local py = 8*flr(player.y/128)
	local cs = px+py
	local load_offset=0
	if cur_sc != cs then
		if lower and cs>7 
		or (not lower) and cs<7 then
			if cur_sc<cs then
				load_offset=1
			else
				load_offset=-1
			end
		end		
		cur_sc=cs
		load_actors(load_offset)
	end
end

function player_die()
	player.move_lock=true
	 wait(.3)
	shift_pal(1,4,0)
	shift_pal(5,15,5)
	 wait(.2)
	player.x=8
	player.y=210
	player.facing=false
	player.health=player.max_health
	active_actors={}
	load_actors(0)
	load_actors(1)
	shift_pal(5,15,0)
	wait(.4)
	shift_pal(5,15,5)
	wait(.2)
	shift_pal(1,15,-1)
	player.move_lock=false
end

function shift_pal(a,b,col)
	for i=a,b do
		if col==-1 then
			pal(i,i,1)
		else
			pal(i,col,1)
		end
	end
end
-->8
--update and draw

function _update()
coresume_check(cors.start)
coresume_check(cors.intro)
if game_state=="intro" then
	camera(0,0)
	rect(0,0,127,127,0)
elseif game_state=="title" then
	camera(0,0)
	rect(0,0,127,127,0)	
	if(not player.move_lock and btnp(🅾️)) cors.start=cocreate(start_game)

elseif game_state=="game" then
	update_player()
	update_actors()
	update_screen()
	
	coresume_check(cors.p_inv)
	coresume_check(cors.sword)
	coresume_check(cors.death)
	coresume_check(cors.upgrade)
	
	coresume_check(cors.end_sc)	
	
	if player.atk_state==0 and not end_cutscene then
		local c_min=0 local c_max=895
		if cur_sc<4 then c_max=383
		elseif cur_sc<8 then c_min=512
		end
		camera(mid(c_min,player.x-64,c_max),128*flr(cur_sc/8))
	elseif end_cutscene then
		camera(0,128)
	end
	coresume_check(cors.door)
end
end

function _draw()
	cls()
if game_state=="intro" then
	spr(195,58,58,2,2)
	print("a game by grant ross",28,78,7)
elseif game_state=="title" then
	camera(0,0)
	rect(0,0,127,127,0)
	draw_big_text(title_sc,24,24)
elseif game_state=="game" then
	local cx = peek2(0x5f28)
	rectfill(512,0,1023,128,12)
	rectfill(0,242,511,256,1)
	rectfill(0,0,511,128,1)
	if end_cutscene then	
		rectfill(0,128,128,256,1)
		map(112,32,0,128,128,128)
		
	else		
		map()
	end
	draw_signs()
	draw_player()
	draw_actors()
	if(not end_cutscene) draw_ui()
	if(player.upgrading) draw_upg()
	if not end_cutscene
	and door_open
	and player.x>976
	and player.y>195 then
		cors.end_sc=cocreate(end_scene)
	end
	if(end_close)end_scr_wipe()
	--if(active_actors[2]!=nil)print(active_actors[2].x,player.x,player.y-5,7)
	--print(bub_shot.x,player.x,player.y-10,7)
	--print(player.vul,player.x,player.y-5,7)
end
end

function update_player()
	
	local swimming=cur_sc<4 or player.y>232
	player.dy+=gravity
	if(swimming)player.dy-=.2
	player.moving=false
	if player.atk_state==0 and not player.hurt then	
		if player.move_lock and player.m_move!=0 then
			player.dx=player.speed*player.m_move
			player.moving=player.m_move!=0
			player.facing=player.m_move==-1
		elseif not player.move_lock then
		for i=-1,1,2 do
		--l=0,r=1
			local b=mid(0,i,1)
			if btn(b) then
				player.moving=true
				if not collide_check(player,b,1) then
					player.dx=player.speed*i
				else player.dx=0
				end			
				player.facing=i==-1
			end
		end end
	end
	player.dy=min(player.max_dy, player.dy)
		
	if not player.moving then
		player.first_sp=true
		player.dx*=friction
		player.delta_t = time()
	end
	if player.dy>0 and collide_check(player,3,0) then
		player.dy=0
		if(player.dub_jump) then
			player.jumps=2
		else
			player.jumps=1
		end
		player.y-=(player.y+16)%8
	end
	if player.dy<0 and collide_check(player,2,1) then
		player.dy=0
		player.y=flr(player.y)+1
	end
	if btnp(❎) and not player.move_lock then
		if swimming then
			player.dy-=2.8
			player.dy=max(player.dy,-4)
			sfx(56,1)
		elseif player.jumps>0 then
			player.jumps-=1
			player.dy=-player.jump		
			player.landed=false
			sfx(63,1)
		end
	end
	if not player.move_lock and btnp(🅾️) and player.atk_state==0 then
		cors.sword=cocreate(player_attack)
		sfx(62,1)
	end
	
	if(player.upgrading)player.dx=0	
	player.x=mid(1,player.x+player.dx,1007)
	player.y+=player.dy
	
	
	if player.y>256 then
		if (player.x<512) then
			player.y=0
		else
			player.y=120
		end
	end
	if(player.y<0) player.y=256
	--check for enemy hurt
	if player.vul then
		if spr_col_check(4)then
			player_hurt()
		else
			for i=0,3 do			
				if collide_check(player,i,2)then
					player_hurt()
					i=4
				end			
			end
		end
		if player.health<=0 then
			cors.death=cocreate(player_die)
		end
	end
end

function draw_player()
	if(player.flash) return

	local sp = player.sp
	local x = player.x
	if player.atk_state==1 then
		sp+=8
	elseif player.atk_state==2 then
	 	sp+=10
	else 
		if(player.dy<0) then sp+=4
		elseif(player.dy>0) then sp+=6
		else
			if time()-player.delta_t>player.anim_time then	
				player.first_sp = not player.first_sp
				player.delta_t=time()
			end
			if (not player.first_sp) sp+=2
		end		
	end
	if(player.hurt) sp=76
	if(player.upgrading)sp=78
	if(player.m_sp!=-1)player.sp=player.m_sp
	spr(sp,x,player.y, 2,2,player.facing)
end

function draw_ui()
	cx = peek2(0x5f28)
	cy = peek2(0x5f2a)
	rectfill(cx,cy,cx+46,cy+13,19)
	rect(cx-1,cy-1,cx+47,cy+14,0)
	--print("health:",cx+2,cy+2,0)
	--print("health:",cx+1,cy+1,7)
	for i=1,player.max_health do
		local sp=2
		local x=cx+i*15-15
		if(i>player.health)sp+=1
		spr(sp,x,cy-2,1,2)
		spr(sp,x+8,cy-2,1,2,true)
	end
end

function draw_signs()
	for i=1,#signs do
		local s=signs[i]
		if mid(s.x-12,player.x+8,s.x+12)==player.x+8 then
			local msg=s.msg
			rectfill(s.x-34,s.y-#msg*8-2,s.x+32,s.y-2,15)
			rect(s.x-35,s.y-#msg*8-3,s.x+33,s.y-1,4)
			for i=#msg,1,-1 do
				local msg_y=s.y-i*8				
				print(msg[#msg-i+1],s.x-32,msg_y,0)
			end
		end
	end
end

upg_x=0
upg_y=0
function draw_upg()
	if upg_x<28then
		upg_x+=2
		upg_y+=.7
	end
	local y_off=player.y-15
	rectfill(player.x-upg_x+8,y_off-upg_y,player.x+upg_x+8,y_off+upg_y,3)
	rect(player.x-upg_x+8,y_off-upg_y,player.x+upg_x+8,y_off+upg_y,0)
	if upg_x>=25 then
		print("you found the",player.x-17,y_off-6,7)
		local item_str
		if cur_sc<4 then
			item_str="bubble shot!"
		else
			item_str="double jump!"
		end
		print(item_str,player.x-15,y_off+1,7)
	end
end

function draw_big_text(data,tx,ty)
	for i=1,21 do
		tx+=24
		for k=0,3 do
			tx-=8
			local tile=164+get_band(title_sc[i]>>>(k*4))
			if (tile>170)tile+=9
			spr(tile,tx,ty)		
		end
		tx+=40
		if i!=1 and i%3==0 then
			ty+=8		
			tx=24
			if(i>9)tx+=4
		end
		print("lost in the forest",28,82,11)
		print("press z to start",32,98,7)
	end	
end

function draw_the_end()
	local tx=20
	local ty=160
	for i=1,9 do
		tx+=24
		for k=0,3 do
			tx-=8
			local tile=164+get_band(the_end[i]>>>(k*4))
			if (tile>170)tile+=9
			if((i+1)%3==0 and k==0)tx+=8
			if((i+1)%3==0 and k==2)tx-=8
			spr(tile,tx,ty)		
		end
		tx+=40
		if((i+1)%3==0)tx=92
		if i!=1 and i%3==0 then
			ty+=8		
			tx=20			
		end
	end
end
-->8
--collisions

col_x_offset=0
col_y_offset=0

function collide_check(obj,aim,flag)
	local x1 local y1
	local x2 local y2
	local x = obj.x+(8*col_x_offset)
	local y = obj.y+(8*col_y_offset)
	local w = obj.w
	local h = obj.h
	if(aim<2) then
		x1=x+(w*aim)-1	y1=y+2
		x2=x+(w*aim) y2=y+h-3
	else
		x1=x+2	y1=y+(h*(aim-2))-(-3+aim)
		x2=x+w-3 y2=y+(h*(aim-2))
	end
	x1/=8	y1/=8
	x2/=8	y2/=8
	return fget(mget(x1,y1), flag)
	or fget(mget(x1,y2), flag)
	or fget(mget(x2,y1), flag)
	or fget(mget(x2,y2), flag)
end

function spr_col_check(flag)
		for i=1,#active_actors do
			local a=active_actors[i]
			if fget(a.sp_list[1])==flag 
			and spr_overlap(a) then
				return true
			end
		end
	return false
end

function spr_overlap(a)
	local ox = player.x local oy=player.y
	return (mid(ox,a.x+1,ox+player.w)==a.x+1
		or mid(ox,a.x+a.w-1,ox+player.w)==a.x+a.w-1)
		and (mid(oy,a.y,oy+player.h)==a.y
		or mid(oy,a.y+a.h,oy+player.h)==a.y+a.h)
end

function sprs_overlap(a,a2)
	local ox = a2.x local oy=a2.y
	return (mid(ox,a.x,ox+a2.w)==a.x
		or mid(ox,a.x+a.w,ox+a2.w)==a.x+a.w)
		and (mid(oy,a.y,oy+a2.h)==a.y
		or mid(oy,a.y+a.h,oy+a2.h)==a.y+a.h)
end
-->8
--actors

actors={}
actor_list={}
active_actors={}

function load_actors(off)
	--active_actors={}
	for i=1,#actor_list do
		local act=actor_list[i]
		if get_band(act)==cur_sc+off then 	
			local a_inst=new_actor(
				get_band(act>>>8)+(16*((cur_sc+off)%8)),
				get_band(act>>>12)+(16*flr(cur_sc/7)),
				actors[get_band(act>>4)+1],
				cur_sc+off)
			add(active_actors,a_inst)
		end
	end
	for i=#active_actors,1,-1 do
		local aa=active_actors[i]
		if aa.scr<cur_sc-1
		or aa.scr>cur_sc+1 then
			del(active_actors,active_actors[i])
		end
	end
			
end

function update_actors()
	for i=1,#active_actors do
		local a=active_actors[i]
		if a.alive then			
			if(a.name=="scorpion")scorp_move(a) 
			if(a.name=="spider")spid_move(a) 
			if(a.name=="upgrade")upgrade_idle(a)
			if(a.name=="fish")fish_move(a)
			if(a.name=="jelly")jelly_move(a)
			if(a.name=="bird")bird_move(a)
		end
	end
	move_health()
	move_bubble()
	if(end_cutscene)update_cs_actors()
end

function draw_actors()
	for i=1,#active_actors do
		local a=active_actors[i]
		if a.alive then				
			
			if a.name=="spider" then 
				spid_draw(a)
			else
				basic_draw(a)
			end
		elseif a.circ_size>0 then
			circfill(a.dead_x,a.dead_y,a.circ_size,7)
			a.circ_size-=1			
		end
	end
	if(health_drop.active)basic_draw(health_drop)
	if(bub_shot.active)basic_draw(bub_shot)
	if(end_cutscene)draw_cs_actors()
end

function new_actor(ax,ay,data,load_sc)
	local a={
		scr=load_sc,
		sp=1,
		sp_list=data.sp_list,
		x=ax*8,
		y=ay*8,
		dx=0,
		dy=0,
		alive=true,
		w=data.w,
		h=data.h,
		facing=data.facing,
		speed=data.speed,
		name=data.name,
		anim_time=time(),
		anim_length=data.anim_length,
		circ_size=5,
		dead_x=dx,dead_y=dy,
		--spider
		start_y=ay*8,
		wait_time=data.wait_time,
		--fish
		jump_state=0,
		start_x=ax*8,
		jump_wait=time(),
		flip_y=false,
		--bob move
		bob=data.bob,
		--health
		active=data.active
	}	
	return a
end

function basic_draw(a)
	update_actor_spr(a)
	spr(a.sp_list[a.sp],a.x,a.y,a.w/8,a.h/8,a.facing==1,a.flip_y)
end

function mirror_y_draw(a)
	update_actor_spr(a)
	spr(a.sp_list[a.sp],a.x,a.y,1,2)
	spr(a.sp_list[a.sp],a.x+8,a.y,1,2,true)
end
function quad_draw(sp,x,y)

	for i=0,3 do
		local fx=i%2 
		local fy=flr(i/2)
		spr(sp,x+(8*fx),y+(8*fy),
		1,1,fx==1,fy==1)
	end
end

function spid_draw(spid)
	quad_draw(102,spid.x,spid.start_y)
	rect(spid.x+7,spid.start_y+7,spid.x+7,spid.y,7)
	mirror_y_draw(spid)
end

function update_actor_spr(a)
	if time()-a.anim_time>a.anim_length then	
		if a.sp==#a.sp_list then
			a.sp=1
			a.anim_time=time()
		else 
			a.sp+=1
			a.anim_time=time()
		end
	end
end

function kill_check(a)
	if (player.atk_state==1 
	and spr_overlap(a))
	or (bub_shot.active 
	and sprs_overlap(bub_shot,a)) then
		if(sprs_overlap(bub_shot,a))bub_shot.active=false
		a.alive=false
		a.dead_x=a.x+a.w/2
		a.dead_y=a.y+a.h/2
		if(flr(rnd(8))==0)spawn_health(a.dead_x,a.dead_y)
		a.x=-1 a.y=-1		
	end
end

function scorp_move(s)
	if not collide_check(s,s.facing,0) then
		s.x+= -s.speed+(s.speed*2*s.facing)
	else	
		s.facing=abs(s.facing-1)
	end
	s.dy+=gravity
	s.dy=min(max_dy, s.dy)
	if collide_check(s,3,0) then
		s.dy=0
		s.y-=(s.y+16)%8	
	end
	s.y+=s.dy
	kill_check(s)	
end

function spid_move(spid)
	--turn around
	if spid.wait_time==-1
	and (collide_check(spid,spid.facing,0) 
	or spid.y<spid.start_y) then
		spid.wait_time=time()
		spid.facing=abs(spid.facing-5)
		spid.y+=1
	end
	if spid.wait_time!=-1 then
		if(time()-spid.wait_time>1) spid.wait_time=-1
	else
		spid.y+=spid.speed-(spid.speed*-2*(spid.facing-3))	
	end
	kill_check(spid)	
end

function upgrade_idle(upg)
	if(cur_sc<4 and player.bubble)
	or(cur_sc>3 and player.dub_jump)then
		upg.alive=false
	end
	bob_move(upg)
	if spr_overlap(upg) and mid(upg.x-4,player.x+4,upg.x+12)==player.x+4 then
		upg.alive=false
		cors.upgrade=cocreate(upgrade_get)--bubble
	
	end
end

function jelly_move(j)
	bob_move(j)
	kill_check(j)
end

function bob_move(a)
	if a.y>a.start_y-a.bob then
		a.dy-=a.speed
	else
		a.dy+=a.speed
	end
	a.y+=a.dy
end

function fish_move(f)
	if f.jump_state==0 then
		if time()-f.jump_wait>1.5 then
			f.jump_state=1
			f.dy=-5
			f.sp=1
		end
	elseif f.jump_state==1 then
		f.dx=-f.speed+(f.speed*2*f.facing)
		f.dy+=.25
		if f.dy>=0 then 
			f.jump_state=2
			f.sp=2
		end
	else
		f.dx=-f.speed+(f.speed*2*f.facing)
		f.dy+=.25
		if f.y>255 then
			f.jump_state=0
			f.jump_wait=time()
			f.dx=0
			f.dy=0
			f.x=f.start_x
			f.y=248
			f.sp=1	
		end
	end	
	f.x+=f.dx
	f.y+=f.dy
	kill_check(f)
end

function bird_move(b)
	if player.x>b.x then
		b.facing=1
	else
		b.facing=0
	end
	b.dx-=b.speed-(b.speed*2*b.facing)
	b.dx=mid(-4,b.dx,4)
	b.x+=b.dx
	kill_check(b)
end

function spawn_health(hx,hy)
	health_drop.active=true
	health_drop.x=hx
	health_drop.y=hy-8
	health_drop.dy=-3
end

function move_health()
	if health_drop.active then
	if not collide_check(health_drop,3,1)then
		health_drop.dy=min(health_drop.dy+.7,max_dy)
	
	else
		health_drop.dy=0
		--health_drop.y=(health_drop.y+16)%8
	end
	health_drop.y+=health_drop.dy

	if spr_overlap(health_drop) and mid(health_drop.x-4,player.x+4,health_drop.x+12)==player.x+4 then
		health_drop.active=false
		player.health=min(player.health+1,player.max_health)
	end
	end
end

function spawn_bubble()
	bub_shot.active=true
	bub_shot.x=player.x
	if player.facing then
		bub_shot.facing=0
		bub_shot.x+=8
	else
		bub_shot.facing=1
	end
	bub_shot.y=player.y+2	
end

function move_bubble()
	if bub_shot.active then
		bub_shot.x-=bub_shot.speed-(bub_shot.speed*2*bub_shot.facing)
		--lol
		if not door_open 
		and mid(980,bub_shot.x,984)==bub_shot.x
		and mid(168,bub_shot.y,172)==bub_shot.y then
			bub_shot.active=false
			door_open=true		
			cors.door=cocreate(open_door)
		end
	end
end




-->8
--cutscenes

function upgrade_get()
	local timer=time()
	player.upgrading=true
	if(cur_sc<4) then
		player.bubble=true
	else
		player.dub_jump=true
	end
	while(time()-timer<2)yield()
	player.upgrading=false
end

function open_door()
	music(36)
	mset(122,21,8)
	mset(123,21,9)
	player.move_lock=true
	local door_timer=time()
	local sh_timer=time()
	local camx = peek2(0x5f28)
	local camy = peek2(0x5f2a)
	for i=1,6 do
		camera(camx-1,camy)
		wait(.2)
		camera(camx+1,camy)
		wait(.2)
	end
	wait(1)
	sfx(57)
	mset(122,25,0)
	mset(123,25,0)
	mset(122,26,0)
	mset(123,26,0)
	player.move_lock=false	
end

function end_scene()
	player.move_lock=true
	active_actors={}
	end_cutscene=true
	--cs_end_t=time()
	col_x_offset=112
	col_y_offset=16
	
	player.x=0 player.y=150
	fade_pal(true,.2)	
	player.m_move=1
		wait(1.4)
	player.m_move=0
		wait(1.5)
	player.m_move=.5
		wait(.5)
	player.m_move=0
		wait(1)
	player.anim_time=.3
	player.m_move=.5	
		wait(1)
	player.anim_time=.15
	player.m_move=0
		wait(1.5)
	player.m_sp=138	
		wait(.2)
	player.m_sp=64
		wait(.6)
	mset(124,43,186) mset(124,44,186)
	mset(125,43,186) mset(125,44,186)
	player.dy=-2
	player.dx=-20
	sfx(63)
	frog_girl.active=true
		wait(2)
	frog_girl.state=1
	frog_girl.sp=1
	player.dy=-.8
	player.dx=-5	
		wait(1.5)
	music(33)
	frog_girl.dx=-.8
		wait(.2)
	player.dx=-4
		wait(.8)
	frog_girl.dx=0
		wait(.8)
	frog_girl.state=2
		wait(.2)
	player.x-=-1
	player.m_sp=160
		wait(.05)
	player.x+=2
		wait(.05)
	player.x-=1.5
	heart.active=true
		wait(1.8)
	heart.active=false
	frog_girl.x+=2
	frog_girl.state=3
		wait(.5)
	player.m_sp=64
		wait(1.2)
	player.m_sp=78
	end_close=true
	wait(8)
	fade_pal(false,.2)
	wait(.5)
	game_state="title"
	col_x_offset=0
	col_y_offset=0
	player.move_lock=false
	end_cutscene=false
	player.m_sp=-1
	player.sp=64
	cors.intro=cocreate(intro)	
end


function wait(t)
local timer=time()
while time()-timer<t do
		yield()
end
	return false	
end

frog_girl={
	x=96,y=216,
	h=16,w=16,
	dx=0,
	sp=164,	
	sp_list={132,134},
	state=0,
	anim_time=0,
	anim_length=.15,
	active=false
}
heart={
	x=72,y=214,
	h=8,w=8,
	dx=2,dy=0,
	sp=1,
	sp_list={194},
	state=0,
	anim_time=0,anim_length=0,
	active=false
}

function update_cs_actors()
	if(frog_girl.active)update_frog_girl()
	if(heart.active)update_heart()
end

function draw_cs_actors()
	if(frog_girl.active)draw_frog_girl()
	if(heart.active)basic_draw(heart)
end

function update_frog_girl()
	if frog_girl.state==0 then
		if time()-frog_girl.anim_time>.2 then
			frog_girl.anim_time=time()	
			if frog_girl.sp==171 then frog_girl.sp=187
			else frog_girl.sp=171
			end
		end
	elseif frog_girl.state==1 then
		if frog_girl.dx!=0 then
		frog_girl.x+=frog_girl.dx
			if time()-frog_girl.anim_time>.2 then
				frog_girl.anim_time=time()	
				--frog_girl.sp=134+abs(frog_girl.sp-134)
			end
		else
			frog_girl.sp=1
			frog_girl.anim_time=time()
		end
	elseif frog_girl.state==2 then
		frog_girl.sp_list[1]=136
		frog_girl.sp=1
		frog_girl.anim_length=100
	else
		frog_girl.sp_list[1]=132
		frog_girl.anim_length=.2
		frog_girl.state=1
	end
end

function draw_frog_girl()
	local x = frog_girl.x
	local y = frog_girl.y
	local sp= frog_girl.sp
	if frog_girl.state==0 then
		quad_draw(sp,x,y)
	else
		basic_draw(frog_girl)		
	end
end

function update_heart()
	if heart.x>72 then
		heart.dx-=.3
	else
		heart.dx+=.3
	end
	heart.y-=.2
	heart.x+=heart.dx
end

end_close=false
wipe=1
function end_scr_wipe()
	if wipe<63 then
		rectfill(0,128,wipe,256,0)
		rectfill(128,128,128-wipe,256,0)
		wipe+=1
	else		
		rectfill(0,128,128,256,0)
		draw_the_end()
	end
end