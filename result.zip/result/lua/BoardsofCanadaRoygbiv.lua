pal({136,8,137,9,10,138,139,3,140,13,141,2},1)s=rectfill
music(0)cls(12)c=-.5r=rnd::_::o=p
p=stat(24)
if(p<0)p=t()\5
if(o!=p)c+=.5
s(54,54,73,73,c%12+1)for n=0,599 do
x=r(128)y=r(128)v=x+(x-64)/16w=y+(y-64)/16
line(v,w,x+r(2)-1,y+r(2)-1,pget(x,y))
end
s(54,54,73,73,0)flip()goto _