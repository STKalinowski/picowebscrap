-- 8venture
-- ktb v7.1

ticks=0
in_title=true
hardcore=true
enddelay=false

-- util functions
function rndi(lo,hi)
 return flr(rnd(hi-lo+1))+lo
end

function sign(x)
 if(x==0) return 0
 return sgn(x)
end

-- this is an octagonal metric
-- bcuz overflow, sqrt crash
function dist(x1,y1,x2,y2)
 local s1=abs(x2-x1)
 local s2=abs(y2-y1)
 return max(s1,s2)+0.4142*min(s1,s2) --sqrt(2)-1
end
-- *approx* dist between
-- centers of sprites
function distobjs(s1,s2)
 return flr(dist(
   s1.x+s1.sw/2,s1.y+s1.sh/2,
   s2.x+s2.sh/2,s2.y+s2.sh/2))
end

function in_sprite(x,y,s)
 if (not s) or 
    x<s.x or x>=s.x+s.sw or
    y<s.y or y>=s.y+s.sh then
  return false
 end
 return true
end

-- flags
-- 1 solid
-- 2 overlay
-- 4 quicksand

function has_flag(x,y,f)
 local s=mget(flr(x/8),flr(y/8))
 return band(fget(s),f)>0
end

function any_flag(x,y,w,h,f,oob)
 if x<0 or y<0 or x+w>8*128 or y+h>4*128 then
  return oob
 end
 local mv
 for mx=flr(x/8),flr((x+w-1)/8) do
  for my=flr(y/8),flr((y+h-1)/8) do
   if band(fget(mget(mx,my)),f) > 0 then
    return true
   end
  end
 end
 return false
end

function can_stand(x,y,w,h,f)
 return not any_flag(x,y,w,h,1,true)
end

function try_nudge(ob,dx,dy,samescreen)
 local ox,oy=ob.x,ob.y
 ob.x+=dx ob.y+=dy
 if can_stand(ob.x,ob.y,ob.sw,ob.sh) then
  if (not samescreen) or 
     (flr(ox/128)==flr(ob.x/128) and
      flr(oy/128)==flr(ob.y/128)) then
   return true
  end
 end
 ob.x,ob.y=ox,oy
 return false
end
 
function collides(a,b)
 if (not a) or (not b) then return false end
 if a.x+a.sw-1<b.x or
    a.x>b.x+b.sw-1 or
    a.y+a.sh-1<b.y or
    a.y>b.y+b.sh-1 then
  return false
 end
 return true
end

function inside(a,b) --sprites
 return a.x>=b.x and a.y>=b.y and
    a.x+a.sw<= b.x+b.sw and
    a.y+a.sh<= b.y+b.sh
end

function rndxy(s,rx,ry)
 local x,y,ok
 ok=false
 while not ok do
  x=rx*128+rndi(8,120-s.sw)
  y=ry*128+rndi(8,120-s.sh)
  ok=can_stand(x,y,s.sw,s.sh)
 end
 s.x,s.y = x,y
end

-- set some common sprite info
function set_sinfo(obj,snum,
           w,h,fgc,bgc,fh,fv)
 obj.sn=snum -- spritesheet num
 obj.sw=w -- width in pixels
 obj.sh=h -- height in pixels
 if(fgc) obj.sfgc=fgc--array
 if(bgc) obj.sbgc=bgc
 if(fh) obj.sfh=fh
 if(fv) obj.sfv=fv
end

function draw_sprite(s)
 if s.dead and ticks%3!=0 then return end
 if s.magic then
  pal(15,rndi(0,14))
 else
  pal(15,s.sfgc)
 end
 if s.sbgc then pal(1,s.sbgc) end
 if(s.cursed and s.cursed>0 and ticks%2==0) pal(15,0)
 if(s.hurt and s.hurt>0 and ticks%2==1) pal(15,8)
 if(s.stunned and s.stunned>0 and ticks%5<2) pal(15,10)
 sspr(s.sn%16*8,flr(s.sn/16)*8,
      s.nsw or s.sw,s.nsh or s.sh,
      s.x,s.y,
      s.sw,s.sh,
      s.sfh,s.sfv)
 pal()
 if s==p and p.shielded then
  local dx=p.x-shield.x
  local dy=p.y-shield.y
  shield.x+=1.5*dx+1
  shield.y+=1.5*dy+1
  draw_sprite(shield)
 end
end

function unpack(s)
 local a={}
 local key,val,c,auto
 local l=0
 s=s..","  auto=1
 for i=1,#s do
  c=sub(s,i,i)
  if c=="=" then
   key=sub(s,l+1,i-1)
   l=i
  elseif c=="," then
   val=sub(s,l+1,i-1)
   local valc=sub(val,#val,#val)
   if valc>="0" and valc<="9" then
    val=val*1
    -- cover for a bug in string conversion
    val=shl(shr(val,1),1)
   elseif val=="true" then
    val=true
   elseif val=="false" then
    val=false
   end
   l=i
   if not key then
    key=auto
    auto+=1
   end
   a[key]=val
   key=false val=false
  end
 end
 return a
end


p={}
sw={}
items={}
dying={}
cup={}
shield={}
altar={}
mag={}
dot={}
ship={}
snorcs={} -- (snow orcs)
scorps={} -- (scow orps)
function init_objs()

 p=unpack("sn=0,sw=5,sh=7,sfgc=10,wang=0,x=573,y=228,weap=false,cursed=0,hurt=0")
 
 sw=unpack("sn=2,sw=7,sh=7,sfgc=10,sbase=1")
 rndxy(sw,rndi(2,6),rndi(1,2))
 add(items,sw)

 shield=unpack("sn=35,sw=5,sh=6,sfgc=12")
 rndxy(shield,rndi(0,7),rndi(0,3))
 add(items,shield)
 
 altar=unpack("sn=48,sw=8,sh=6,sfgc=5,magic=true,x=32,y=464")


 -- keys
 function add_key(col,rx,ry)
  local k=unpack("sn=16,sw=8,sh=3,sfgc="..col)
  rndxy(k,rx,ry)
  add(items,k)
 end
 add_key(10,rndi(5,7),rndi(0,3))
 local wkey_in_black=rnd(1)<0.5
 if wkey_in_black then
  add_key(7,4,3)
  -- blue key can go anwhere
  -- west of yellow castle
  add_key(12,rndi(0,3),rndi(0,3))
 else
  add_key(7,7,2)
  -- blue key not in white castle
  add_key(12,rndi(0,6),rndi(2,3))
 end
 add_key(0,2,3)
 add_key(8,rndi(0,7),rndi(0,3)) --useless
 
 cup=unpack("sn=33,sw=16,sh=16,sfgc=7,magic=true,x=80,y=80")
 add(items,cup)
 
 dot=unpack("sn=32,sw=1,sh=1,sfgc=0,magic=true,x=20,y=440")
 add(items,dot)
 
 mag=unpack("sn=18,sw=6,sh=5,sfgc=8")
 if wkey_in_black then
  rndxy(mag,7,2)
 else
  rndxy(mag,4,3)
 end
 add(items,mag)

 ship=unpack("sn=11,nsw=16,nsh=16,sw=48,sh=48,sfgc=0,x=8,y=322,sbgc=8")
 if rnd(1)<0.5 then
  ship.x=128*7+60 ship.y=128+70
  ship.sfh=true
  ship.sbgc=7
 end
 
 for i=1,10 do
  local s=unpack("sn=75,sw=8,sh=8,sfgc=12,dx=0,dy=0,spd=1")
  if i<=5 then
   repeat rndxy(s,5,3) until s.y>448
  else
   rndxy(s,6,3)
  end
  s.x=flr(s.x/8)*8
  s.y=flr(s.y/8)*8
  if rnd(1)<0.5 then
   s.dx=rndi(0,1)*2-1
  else
   s.dy=rndi(0,1)*2-1
  end
  
  add(snorcs,s)
 end
end

duck={}
ghosts={}
knights={}
nommer={}
function init_mons()

 for i=1,6 do
  local s=unpack("sn=91,sw=13,sh=8,sfgc=7,bored=0")
  rndxy(s,rndi(6,7),rndi(0,1))
  add(scorps,s)
 end

 for i=1,4 do
  local g=unpack("sn=78,sw=16,sh=16,sfgc=5,rad=20,cursed=1,stunned=0")
  g.ang=rnd(2)-1 -- als rot dir
  rndxy(g,2,2)
  g.xr=g.x g.yr=g.y
  add(ghosts,g)
 end
 
 for i=1,3 do
  local kn=unpack("sn=17,sw=6,sh=6,sfgc=7")
  rndxy(kn,0,0)
  kn.x=flr(kn.x/8)*8+1
  kn.y=flr(kn.y/8)*8+1
  add(knights,kn)
 end
 knights[1].winx=rc(0,3)+4
 knights[1].winy=rc(1,4)+4
 knights[2].winx=rc(0,5)+4
 knights[2].winy=rc(1,7)+4
 knights[3].winx=rc(0,11)+4
 knights[3].winy=rc(1,4)+4
 
 duck=unpack("wait=100,action=0,sn=64,sw=24,sh=32,top=64,bottom=96,asleep=true")
 rndxy(duck,7,0)
 duck.dx=duck.x duck.dy=duck.y
 
 nommer=unpack("sn=73,sw=15,sh=16,sfgc=14,x=568,y=440,asleep=true,cursed=1,wasseen=false")
 
end

function sroom(s)
 local r=rooms[flr(s.x/128)][flr(s.y/128)]
 if(not r)return rooms["default"]
 return r
end

rooms={}

function set_room(x,y,str)
 rooms[x][y]=unpack(str)
end

function init_rooms()
 rooms["default"]={6,5}
 for x=0,7 do
  rooms[x]={}
  for y=0,3 do
   rooms[x][y]=rooms["default"]
  end
 end
 set_room(4,1,"10,5")
 set_room(4,0,"10,13")
 set_room(2,0,"3,2,swamp=true")
 set_room(2,1,"3,2,swamp=true")
 set_room(3,0,"3,2,swamp=true")
 set_room(3,1,"3,2,swamp=true")
 set_room(0,0,"7,13")
 set_room(0,1,"7,5,arrows=true")
 set_room(0,2,"7,5,arrows=true")
 set_room(2,2,"5,0")
 set_room(2,3,"0,1")
 set_room(0,3,"3,11,overlay=true,shrine=true,forest=true")
 set_room(1,3,"3,11,overlay=true,forest=true")
 set_room(3,3,"0,1,flash13=true")
 set_room(4,3,"0,2")
 set_room(5,3,"12,6,snow=200")
 set_room(6,3,"12,7,snow=500")
 set_room(7,3,"12,7,snow=400")
 set_room(7,2,"12,13,backsnow=5")
 set_room(1,0,"3,5,arrows=true")
 set_room(1,1,"3,5,arrows=true")
 set_room(1,2,"3,5,arrows=true")
 set_room(5,1,"8,13,sewer=25")
 set_room(6,0,"8,4")
 set_room(6,1,"8,4")
 set_room(7,0,"8,4")
 set_room(7,1,"8,4")
 set_room(5,0,"0,3,sewer=15,droom=true")
end

function rc(screen,tile)
 return screen*128+tile*8
end

tps={}
function init_tps()
 function add_tp(str)
  local a=unpack(str)
  a.id=a[1] a.dest=a[2]
  a.x=rc(a[3],a[5])
  a.y=rc(a[4],a[6])
  a.sw=a[7]*8 a.sh=a[8]*8
  tps[a[1]]=a
 end  -- i d  room tile  h/w
 add_tp("1,2, 4,1, 7,8,  2,1")
 add_tp("2,1, 4,0, 7,15, 2,1")
 add_tp("3,4, 0,1, 3,9,  1,2") 
 add_tp("4,3, 0,0, 2,15, 1,1") 
 add_tp("5,6, 0,0, 6,14, 1,1") 
 add_tp("6,5, 0,0, 1,3,  1,1") 
 add_tp("7,8, 0,0, 6,6,  1,1") 
 add_tp("8,7, 0,1, 6,3,  1,1") 
 add_tp("9,10, 0,1, 9,3,  1,1") 
 add_tp("10,9, 0,0, 9,6,  1,1") 
 add_tp("11,12, 0,0, 14,5, 1,1") 
 add_tp("12,11, 0,0, 14,14,1,1") 
 
 add_tp("13,14, 2,3, 11,11,1,1")
 add_tp("14,13, 3,3, 2,15, 1,1")
 add_tp("15,16, 3,3, 8,7,  1,2")
 add_tp("16,15, 4,3, 12,12,1,1")
 
 add_tp("17,18, 7,3, 7,9,  2,2")
 add_tp("18,17, 7,2, 12,14,1,1")
 add_tp("19,20, 7,2, 12,0, 1,1")
 add_tp("20,19, 7,3, 11,2, 1,1")
 
 local tpx=rndi(1,14)
 local tpy=rndi(1,14)
 add_tp("21,22, 7,0, "..tpx..","..tpy..", 1,1")
 mset(7*16+tpx,0+tpy,61)
 add_tp("22,21, 5,1, 9,9, 1,1")
 
 add_tp("23,24, 5,1, 6,4, 1,1")
 add_tp("24,23, 5,0,14,1, 1,1")

 add_tp("25,26, 5,0,1,14, 1,1")
 add_tp("26,-1, 3,0,15,0, 1,1")

end

last_dest_tp=0
function check_tps()
 if last_dest_tp>0 and
    inside(p,tps[last_dest_tp]) then
  return
 end
 last_dest_tp=0

 for tp in all(tps) do
  if inside(p,tp) and tp.dest!=-1 then
   local ox,oy=p.x,p.y
   local dtp=tps[tp.dest]
   p.x=dtp.x+flr(dtp.sw/2-p.sw/2)
   p.y=dtp.y+flr(dtp.sh/2-p.sh/2)
   if p.weap then
    p.weap.x+=p.x-ox
    p.weap.y+=p.y-oy
   end
   last_dest_tp=tp.dest
   sfx(13)
   return
  end
 end
end


doors={}
function add_door(col,rx,ry,tx,ty,w,h)
 local d={}
 set_sinfo(d,30,w,h,col)
 d.x=rx*128+tx*8 d.y=ry*128+ty*8
 add(doors,d)
end
add_door(10,4,1,7,8,16,24)
add_door(7 ,0,1,3,9,8,16)
add_door(0, 2,3,11,11,8,8)
add_door(12,7,3,7,9,16,32) 

function check_doors(obj)
 if (not obj) return
 for d in all(doors) do
  if collides(obj,d) and
     ((obj==duck and not duck.hurtfeet) or
      (obj.sn==16 and (obj.sfgc==d.sfgc or obj.magic)))
  then
   for x=d.x/8,(d.x+d.sw)/8-1 do
    for y=d.y/8,(d.y+d.sh)/8-1 do
     mset(x,y,14)
    end
   end
   del(doors,d)
   if obj==p.weap then
    drop_item(p,true)
    del(items,obj)
    sfx(3)
   elseif obj==p then
    sfx(15)
   elseif obj==duck then
    duck.hurtfeet=true
    sfx(15)
   end
  end
 end
end

-- really only meant for player
function step_player(m,dx,dy)
 if not can_stand(m.x+dx,m.y+dy,m.sw,m.sh) then
  return false
 end
 local ox,oy
 ox=m.x oy=m.y
 m.x+=dx m.y+=dy
 for kn in all(knights) do
  if kn != m and
     collides(kn,m) then
   hurt_player(false,true)
   sfx(11)
   m.x,m.y=ox,oy return false
  end
 end
 if m!=duck and collides(m,duck) then
  m.x,m.y=ox,oy return false
 end

 return true
end
 


-- deltas by dir
dx_a=unpack("1,1,0,-1,-1,-1,0,1")
dy_a=unpack("0,-1,-1,-1,0,1,1,1")

d1=0 d2=2 dd=0
function move_player(o,d,spd)
 local good_dir
 for i=1,spd do
  good_dir=false
  if step_player(o,dx_a[d],dy_a[d]) then
   good_dir=d
  else
   -- try adjacent dirs
   dd=flr(rnd(2))*2-1
   d1=(d+dd-1)%8+1
   d2=(d-dd-1)%8+1
   if step_player(o,dx_a[d1],dy_a[d1]) then
    good_dir=d1
   elseif step_player(o,dx_a[d2],dy_a[d2]) then
    good_dir=d2
   end
  end
  if o.weap and good_dir then
   o.weap.x+=dx_a[good_dir]
   o.weap.y+=dy_a[good_dir]
  end
 end
end

clouds={}

function do_clouds(camx,camy,circs)
 for c in all(clouds) do
  if circs then
   local x,y=camx+c.x+c.w/2,c.y+camy
   circfill(x,y,c.w/2,5)
   circfill(x-2,y-4,c.w/2,6)
  else
   rectfill(c.x+camx,c.y+camy,camx+c.x+c.w,camy+c.y+c.h,7)
  end
  c.x+=c.dx/2
  if c.x>128 then
   c.x=-c.w
  end
 end
end

function flipmappart(l,t,r,b)
 local v1,v2,sx,sy
 function flippy(horiz)
  local maxx,maxy=r,b
  if horiz then
   maxx=flr((l+r)/2)
  else
   maxy=flr((t+b)/2)
  end
  for x=l,maxx do
   for y=t,maxy do
    if horiz then
     sx,sy=r-x+l,y
    else
     sx,sy=x,b-y+t
    end
    v1,v2=mget(x,y),mget(sx,sy)
    if v1!=61 and v2!=61 then
     mset(x,y,v2) mset(sx,sy,v1)
    end
   end
  end
 end
 if rnd(2)<1 then
  flippy(true)
 end
 if rnd(2)<1 then
  flippy(false)
 end
end

function mazify(x,y)
 function trywalk(x,y,d)
  local dx=({0,1,0,-1})[d]
  local dy=({-1,0,1,0})[d]
  local nx,ny=x+2*dx,y+2*dy
  if nx<81 or ny<1 or nx>94 or ny>14
     or mget(nx,ny)!=15 then
   return
  end
  mset(x+dx,y+dy,14)
  if mget(nx,ny)==15 then
   mset(nx,ny,14)
  end
  mazify(nx,ny)
  return
 end
 local dirs={1,2,3,4}
 for i=1,3 do
  local j=rndi(i,4)
  dirs[i],dirs[j]=dirs[j],dirs[i]
 end
 for i=1,4 do
  trywalk(x,y,dirs[i])
 end
end

function _init()
 flipmappart(81,49,94,62)
 flipmappart(97,49,110,62)
 flipmappart(33,33,46,46)
 flipmappart(81,01,94,14)
 flipmappart(81,17,94,30)
 cls()
 init_rooms()
 init_tps()
 init_objs()
 init_mons()
 init_camera()
 while mget(93,1)==15 do
  -- how can this fail???
  mazify(81,1)
 end
 
 for i=1,280 do
  local x=rndi(33,62)
  local y=rndi(1,30)
  mset(x,y,63)
 end
 
 for i=1,20 do
  local c={}
  c.x=rndi(-40,80)
  c.y=rndi(0,100)
  c.w=rndi(20,40)
  c.h=rndi(5,15)
  c.dx=(rnd(1)+1)/5
  add(clouds,c)
 end

end

function angdir(theta)
 local r
 r=flr((theta+0.0625)/0.125)%8
 return r+1
end

function btndir()
 local r=0
 if btn(0) then
 	if btn(2) then r=4
 	elseif btn(3) then r=6
 	else r=5 end
 elseif btn(1) then
  if btn(2) then r=2
  elseif btn(3) then r=8
  else r=1 end
 elseif btn(2) then r=3
 elseif btn(3) then r=7 end

 return r
end



ss_a=unpack("1,2,0,2,1,2,0,2")
fh_a=unpack("0,0,0,1,1,1,0,0")
fv_a=unpack("0,0,0,0,0,1,1,1")
function update_wang()
 local w=p.weap
 local hoff=4+flr(p.sw/2+w.sw/2)
 local voff=4+flr(p.sh/2+w.sh/2)
 w.x=p.x+hoff*cos(p.wang)-1
 w.y=p.y+voff*sin(p.wang)
 w.x+=flr(4-w.sw/2)
 w.y+=flr(4-w.sh/2)
 
 w.x=flr(w.x+0.5)
 w.y=flr(w.y+0.5)
 
 if w.sbase then
  local oct=angdir(p.wang)
  w.sn=w.sbase+ss_a[oct]
  w.sfh=(fh_a[oct]==1)
  w.sfv=(fv_a[oct]==1)
 end
end

function drop_item(o,force,rndloc)
 local w=o.weap
 if(not w)return false
 if rndloc or not can_stand(w.x,w.y,w.sw,w.sh) then
  if(not force) return false
  -- goes in *player's* room
  rndxy(w,flr(p.x/128),flr(p.y/128))
 end
 o.weap = false
 
 if w==cup and flr(p.x/128)==4 and
    flr(p.y/128)==0 then
  sfx(16)
  cup.incastle=true
  show_win=true
  duck.asleep=false
  duck.top=64 duck.bottom=96
  del(items,cup)
 end
 
 return true
end

function pickup_item(o,w)
 if o.weap then
  drop_item(o,true)
 end
 o.weap = w
 o.wang = atan2(
   w.x+w.sw/2-o.x-o.sw/2,
   w.y+w.sh/2-o.y-o.sh/2)
 update_wang()
end

function hurt_player(shieldable,soft)
 if shieldable and p.shielded then
  sfx(21) return
 end
 drop_item(p,true,true)
 if (not soft) or p.hurt<5 then
  sfx(29)
  draw_hit()
  p.hurt+=5
  if hardcore then p.dead=true end
 end
end

function move_ghosts()
 for g in all(ghosts) do
  if g.stunned>0 then
   g.stunned-=1
  else
   if ticks%5==0 then
    g.xr += rndi(0,1)*2-1
    g.yr += rndi(0,1)*2-1
    g.rad+= rndi(0,1)*2-1
   end
   local c22=128*2+64
   if dist(g.x,g.y,c22,c22)>128 then
    g.xr,g.yr=c22,c22
    g.rad=20
   end
   g.y=g.xr+sin(g.ang)*g.rad
   g.x=g.yr+cos(g.ang)*g.rad
   g.ang+=0.005*sgn(g.ang)--deliberate
  end
 end
end

function move_scorps()
 for s in all(scorps) do
  if s.bored<=0 then
   if rnd(1)<0.5 then
    s.ang=atan2(p.x-s.x,p.y-s.y)
   else
    s.ang=rnd(1)
   end
   s.bored=rndi(30,90)
   s.moving=rnd(1)<0.5
  end
  s.bored-=1
  if s.moving then
   if ticks%3==0 then
    s.sn=(91+107)-s.sn
   end
   local spd=rndi(0,3)
   if (s.weap==sw) spd=3
   if try_nudge(s,spd*cos(s.ang),
     spd*sin(s.ang))
   then
    s.ang%=1
    s.sfh=(s.ang>0.25 and s.ang<0.75)
   else
    s.ang-=rndi(0,1)*0.25-0.125
   end    
  end
 end
end

ktempo=60 
function move_knights()
 function new_dir(kn)
  local ok
  while not ok do
   kn.dx=rndi(0,1)*2-1 kn.dy=rndi(0,1)*2-1
   -- sometimes track player
   if rnd(1)<0.5 then
    kn.dx=sgn(p.x-kn.x)
    kn.dy=sgn(p.y-kn.y)
   end
   kn.more_h=(rnd(1)<0.5)
   if kn.more_h then kn.dx*=2
   else kn.dy*=2 end
   kn.swx=kn.x+3+kn.dx*8
   kn.swy=kn.y+3+kn.dy*8
   ok=can_stand(kn.swx,kn.swy,1,1)
  end
 end
 if #knights<1 then return end
 ktempo=20*#knights
 if p.weap==cup then ktempo=20 end
 if ticks%ktempo==0 then
  if ticks%(ktempo*2)==0 then
   sfx(35)
  else
   sfx(rndi(36,37))
  end
 end
 for kn in all(knights) do
  if(not kn.dx) new_dir(kn)
  if ticks%ktempo==0 then
   local ok=true
   for kk in all(knights) do
    if in_sprite(kn.swx,kn.swy,kk) then
     ok=false
    end
   end
   if ok then 
    try_nudge(kn,kn.dx*8,kn.dy*8)
   end
   new_dir(kn)
  end
 end
end

arrows={}

function move_arrows()
 for k in all(knights) do
  if rnd(100)<1 then
   a={x=k.winx,y=k.winy}
   a.ang=atan2(p.x+2-a.x,p.y+3-a.y)
   a.ang+=rnd(0.05)-0.025
   add(arrows,a)
   sfx(28)
  end
 end
 for a in all(arrows) do
  local del_a
  a.x+=1.5*cos(a.ang)
  a.y+=1.5*sin(a.ang)
  if a.x<-10 or a.y<-10 or
     a.x>255 or a.y>382 then
   del_a=true
  elseif not a.ref and
    in_sprite(a.x,a.y,p.weap)
  then
   if p.weap==sw and sw.magic then
    a.ang+=0.4+rnd(0.2)
   else
    a.ang=rnd(1)
   end
   a.ref=true
   sfx(21)
  elseif in_sprite(a.x,a.y,p) then
   del_a=true
   hurt_player(true)
  elseif a.ref then
   for kk in all(knights) do
    if dist(a.x,a.y,kk.winx,kk.winy)<=3 then
     sfx(26)
     add(dying,kk)
     del(knights,kk)
     del_a=true
    end
   end
  else
   for g in all(ghosts) do
    if in_sprite(a.x,a.y,g) then
     add(dying,g)
     del(ghosts,g)
     del_a=true
     sfx(30)
    end
   end
  end
  if del_a then
   del(arrows,a)
  end
 end
end


function draw_hit(s1,s2,s3)
 memset(0x6000,136,8192)
 if(s1) draw_sprite(s1)
 if(s2) draw_sprite(s2)
 if(s3) draw_sprite(s3)
 flip() flip()
end

function check_magnet()
 function pull_item(t)
  t.x+=sign(mag.x-t.x-flr(t.sw/2-mag.sw/2))
  if(t.x<0) t.x=0
  t.y+=sign(mag.y-t.y-t.sh-1)
  if(t.y<0) t.y=0
 end
 
 local closest
 local refx,refy=mag.x,mag.y
 if mag==p.weap then
  refx,refy=p.x,p.y
 end
 for it in all(items) do
  if it!=mag and --it.sn!=48 and
     it!=p.weap and
     (not closest or distobjs(mag,it)<distobjs(mag,closest))
  then
   if mag.magic or
     (flr(refx/128)==flr(it.x/128) and
      flr(refy/128)==flr(it.y/128))
   then
    closest=it
   end
  end
 end
 if closest then
  for i=1,mag.magic and 4 or 1 do
   pull_item(closest)
  end
 end
end

function check_altar()
 p.magic=false
 if(not sroom(p).shrine) return
 if(not altar) return
 if not altar.magic
    and p.weap==dot
    and collides(dot,altar)
    then
  altar.magic=true
  p.weap=false
  sfx(38)
  del(items,dot)
 end
 if(not altar.magic) return
 if collides(altar,p) then
  p.magic=true
  if p.cursed>0 then
   music(0)
   p.cursed=0
   altar.magic=false
  end
  return
 end
 if(not p.weap) return
 if(p.weap.magic) return
 if collides(altar,p.weap) then
  p.weap.magic=true
  music(0)
  altar.magic=false
 end
 
end


--
--
--
--
--
--
--
spd=0
was_in_snow=false
spring_wait=0
function _update()
 ticks+=1 if(ticks==32767) ticks=0
 
 if you_monster then return end

 if in_title then
  if btnp(4) then
   in_title=false
   sfx(7)
   hardcore=false
  end
  if btn(5) and btn(3) then
   in_title=false
   hardcore=true
   sfx(17)
   ticks=0
  end
  return
 end
 
 if show_win or p.dead then
  if not enddelay then
   enddelay=240
  elseif enddelay>0 then
   enddelay-=1
  end
  if enddelay==0 and btn"5" then
   run()
  end
 end

 
 local proom=sroom(p)

 if ticks%30==0 then
  p.cursed=max(p.cursed-1,0)
  p.hurt=max(p.hurt-1,0)
 end
 
 if proom.swamp and ticks%2==0 then
  local x=rndi(32,63)
  local y=rndi(0,31)
  local m=14
  if rnd(1)<0.4 then m=63 end
  mset(x,y,m)
 end
 
 if proom.snow then
  if(not was_in_snow)sfx(24,3)
  was_in_snow=true
 elseif was_in_snow then
  sfx(-1,3)
  was_in_snow=false
 end
 
 if p.shielded then
  shield.x=p.x
  shield.y=p.y
 end

 pdir=btndir()
 if btn(4) and p.weap and pdir>0 then
  -- update the sword angle
  ideal=(pdir-1)*0.125
  local da=sign(ideal-p.wang)*0.05
  local diff=abs(ideal-p.wang)
  if diff<abs(da) then
   p.wang=ideal
  else
  	if(diff>0.5 or (diff==0.5 and rnd(1)<0.5)) da=-da
 	 p.wang += da
 	 if(p.wang<0) p.wang+=1
 	 if(p.wang>=1) p.wang-=1
 	 update_wang()
  end
 elseif btn(5) and p.weap then
  if drop_item(p,false) then
   sfx(1)
  else
   sfx(2)
  end
 elseif not btn(4) then
  -- move player
  if pdir==0 then
   spd=0
  else
   spd+=ticks%2
   if(spd>3) spd=3
   if(p.cursed>0) spd=1
   if(p.hurt>0) spd=rndi(0,2)%2
   -- in swamp?
   if proom.swamp and ticks%5>0 and
      mget(flr((p.x+2)/8),
           flr((p.y+3)/8))==63
   then
    pdir=(flr((p.x+2)/8)+flr((p.y+3)/8))%8+1
   end
   if(p.dead) spd=0
   if(p.carried) spd=0
   move_player(p,pdir,spd)
  end
 end
 
 for it in all(items) do
  if it != p.weap and 
     collides(p,it) then
   if it==shield then
    p.shielded=true
    del(items,it)
   else
    drop_item(p)
    pickup_item(p,it)
   end
   sfx(0)
  end
 end
 
 if proom.shrine then
  check_altar()
 end

 if proom.droom and p.weap==dot
    and mget(dot.x/8,dot.y/8)==19
    and dot.x%8==3 and dot.y%8==3 then
  sfx(38)
  p.weap=false
  del(items,dot)
  mset(dot.x/8,dot.y/8,15)
  proom.sewer=false
  proom.dotted=true
  proom[1]=6 proom[2]=7
  for i=81,94 do
   for j=1,14 do
    if mget(i,j)==15 then
     mset(i,j,14)
    end
   end
  end  
 end
 
 move_scorps()
 for s in all(scorps) do
  if p.weap==sw and collides(s,sw) then
   sfx(31)
   add(dying,s)
   del(scorps,s)
  elseif collides(s,p) then
   hurt_player(false,true)
  else
   for it in all(items) do
    if collides(s,it) then
     if it==p.weap then
      drop_item(p,true)
     end
     if distobjs(it,p)<128 then
      sfx(4)
     end
     rndxy(it,5,1)
     rndxy(s,5,1)
    end
   end
  end
 end

 check_magnet()
 if not show_win then
  check_tps()
 end
 check_doors(p.weap)
 move_ghosts() 

 for g in all(ghosts) do
  if collides(g,sw) then
   if g.stunned==0 and not in_title then
    sfx(21)
   end
   g.stunned=150
   if sw==p.weap and sw.magic then
    sfx(30)
    add(dying,g)
    del(ghosts,g)
    sw.magic=false
   end
  elseif collides(g,p) then
   draw_hit(p,g)
   local it=p.weap
   if it then
    drop_item(p,true)
    rndxy(it,rndi(2,3),rndi(0,1))
   end
   if hardcore then p.dead=true end
   rndxy(p,2,3)
   p.cursed=500
   sfx(6)
  end
 end

 if not proom.arrows then
  arrows={}
 else
  move_arrows()
 end
 

 if proom==rooms[0][0] or
    proom==rooms[0][1] then
  for kn in all(knights) do
   if kn.hurt and kn.hurt>0 then
    kn.hurt-=1
   end
   if collides(sw,kn) then
    if not kn.hurt then
     draw_hit(kn,p)
     sfx(5)
     kn.hurt=60
    elseif kn.hurt==0 then
     draw_hit(kn,p)
     sfx(9)
     add(dying,kn)
     del(knights,kn)
    end
   elseif kn.dx and in_sprite(kn.swx,kn.swy,p) then
    sfx(8)
    for i=1,30 do
     circfill(kn.swx,kn.swy,30,rnd(16)*rnd(16))
     draw_sprite(kn)
     p.x+=rndi(-1,1) p.y+=rndi(-1,1)
     draw_sprite(p)
     line(kn.swx,kn.swy,kn.x+1,kn.y+1,rnd(16))
     line(kn.swx,kn.swy,kn.x+4,kn.y+1,rnd(16))
     flip()
    end
    local it=p.weap
    if it then
     drop_item(p,true)
     if not it.magic then
      -- take your junk with you
      rndxy(it,1,rndi(0,2))
     elseif it==cup then
      it.x,it.y=80,80
     end
    end
    if hardcore then p.dead=true end
    rndxy(p,1,rndi(0,2))
   end
  end
  move_knights()
 end
 
 if p.weap==sw then
  if collides(sw,duck) then
   if not sw.magic then
    if ticks%3==0 then sfx(21) end
   else
    p.dead=true
    you_monster=true
    sfx(30)
   end
  elseif collides(sw,nommer) then
   if not sw.magic then
    if ticks%3==0 then sfx(21) end
   else
    add(dying,nommer)
    nommer=false
    sfx(30)
    sw.magic=false
   end
  end
 end 

 if duck.asleep then
  if distobjs(p,duck)<50 and
    not cup.incastle then
   duck.asleep=false
   duck.top=64 duck.bottom=96
   sfx(10)
  elseif distobjs(p,duck)<128 and ticks%120==0 then
   sfx(27)
  end
 end
 if not duck.asleep then
  duck.fh=duck.x+12<p.x

  for s in all(scorps) do
   if collides(s,duck) then
    sfx(31)
    add(dying,s)
    del(scorps,s)
   end
  end

  if duck.x!=duck.dx or duck.y!=duck.dy then
   for i=1,3 do
    duck.x+=sign(duck.dx-duck.x)
    duck.y+=sign(duck.dy-duck.y)
   end
  elseif cup.incastle then
   duck.dx=cup.x-4
   duck.dy=cup.y-26
   if duck.x==duck.dx and
      duck.y==duck.dy then
    duck.asleep=true
   end
  else
   check_doors(duck)
    
   duck.wait-=1
   if duck.wait<1 then
    if flr(duck.x/128)==7 and
       flr(duck.y/128)==0 and
       distobjs(p,duck)>200 then
     duck.asleep=true
    else
     duck.wait=flr(30*rnd(4))
     if proom[2]==13 or --safe
        proom==rooms[4][1] or --home
        proom.sewer or -- clippy
        proom[0]==0 or -- scary
        distobjs(p,duck)>200--meh
        then
      duck.dx=7*128+80
      duck.dy=25
     else
      duck.dx=flr(p.x/128)*128+rndi(20,90)
      duck.dy=flr(p.y/128)*128+rndi(20,90)
     end
    end
   end
  end
  -- smackin time
  if (not cup.incastle)
     and distobjs(duck,p) < 16 then
   draw_hit(p,duck)
   drop_item(p,true)
   if p.cursed>0 then
    rndxy(p,1,3) -- trying to help
   else
    rndxy(p,4,1)
   end

   -- duck trip, it's not a
   -- duck trip, so you feel
   -- a bit insulted
   camera(0,0)   
   pal(15,10)
   local py=13
   local dpy=0
   for i=127,1,-3 do
    memset(0x6000,12*17,8192)
    do_clouds(0,0)
    spr(67,i,8,3,4)
    spr(0,i,py)
    if (i==91) sfx(22)
    if i<91 then dpy+=0.25 end
    py+=dpy
    flip()
   end
   camera(cam.x,cam.y)
   black_pause()
  end
 end
 
 if nommer then
  if nommer.asleep or
     proom[2]==13 then
   if distobjs(p,nommer)<40 then
    nommer.asleep=false
   end
  else
   if ticks%3==0 then
    nommer.dx=p.x-5-nommer.x
    nommer.dy=p.y-2-nommer.y
    if nommer.dx==0 and
       nommer.dy==0 and
       not p.dead
    then
     memset(0x6000,0,8192)
     draw_sprite(p)
     draw_sprite(nommer)
     flip()
     p.dead=true
    else
     nommer.x+=rndi(0,3)*sign(nommer.dx)
     nommer.y+=rndi(0,3)*sign(nommer.dy)
    end 
   end
  end
  if (nommer.asleep and proom==rooms[4][3])
     or (not nommer.asleep and distobjs(p,nommer)<128)
  then
   if(ticks%90==0) sfx(19)
  end
 end
  
 -- i ship it
 if(ship) ship.y+=cos(ticks/128)/6
 if ship and distobjs(p,ship)<20 then
  camera(0,0)
  sfx(23)
  for i=0,127,3 do
   ship.x=i
   ship.y=35+2*sin(i/16)
   if(not ship.sfh) ship.x=110-ship.x
   memset(0x6000,204,4480)
   do_clouds(0,0)
   for k=70,126,2 do
    memset(0x6000+64*k,205,128)
    memset(0x6000+64*k,220,64)
   end
   pal(15,10)
   p.x=ship.x+22
   p.y=ship.y+32-3*sin(i/16+0.0625)
   ticks+=1
   draw_sprite(p)
   draw_sprite(ship)
   flip() flip()
  end
  camera(cam.x,cam.y)
  if proom==rooms[7][1] then
   rndxy(p,0,2)
  else
   rndxy(p,7,1)
  end
  if(p.weap) update_wang()
  ship=false
 end
 
 for s in all(snorcs) do
  local any_rushed=false
  if p.weap==sw and collides(sw,s) then
   draw_hit(p,sw,s)
   add(dying,s)
   del(snorcs,s) sfx(26)
  elseif collides(p,s) then
   draw_hit(p,s)
   sfx(20)
   drop_item(p,true)
   p.hurt+=4
   if hardcore then p.dead=true end
   rndxy(p,6,3)
  elseif proom.snow then

   local ok=try_nudge(s,s.spd*s.dx,s.spd*s.dy,true)
   if not ok then
    if rnd(1)<0.5 then
     s.dx,s.dy=s.dy,s.dx
    else
     s.dx,s.dy=-s.dy,-s.dx
    end
    if (not p.shielded) and
       (abs(p.x-s.x)<8 or
        abs(p.y-s.y)<8) then
     s.spd=4 s.sfgc=8
     any_rushed=true
    else
     s.spd=1 s.sfgc=12
    end
   end
  end
  if any_rushed then sfx(25) end
 end

 -- update water 
 if ticks%10==0 then
  for y=16,23 do
   local f=sget(112,y)
   for x=112,118 do
    sset(x,y,sget(x+1,y))
   end
   sset(119,y,f)
  end
 end
  
end

snow={}
function draw_snow(sx,sy,amt)
 if #snow<amt then
  for l=#snow+1,amt do
   snow[l]={x=rndi(0,127),y=rndi(0,127),
            sz=rndi(1,3)} --speed
  end
 end
 for i=1,amt do
  local f=snow[i]
  if (f.x+f.y)%2==0 then
   rectfill(sx+f.x,sy+f.y,
            sx+f.x+f.sz-1,
            sy+f.y+f.sz-1,7)
  end
  f.x+=rndi(-1,1)
  f.y+=rndi(0,f.sz)/2
  f.x%=128
  f.y%=128
 end
end

function draw_room(overlay)
 local sx,sy=cam.x,cam.y
 local mapx=flr(sx/8)
 local mapy=flr(sy/8)
 local r=rooms[flr(sx/128)][flr(sy/128)]
 if (not r) r=rooms["default"]
 pal(15,r[1])	
 pal(1,r[2])
 pal(8,r[2])
 palt(o,false)
 if r.flash13 then
  if rnd(1)<0.02 then pal(13,7) pal(1,0)
  else pal(13,1) end
 end
 if r.backsnow and not overlay then
  memset(0x6000,r.backsnow*17,8192)
  draw_snow(sx,sy,200)
  palt(5,true)
 end
 if r==rooms[4][1] and not overlay then
  memset(0x6000,17*12,8192)
  do_clouds(cam.x,cam.y)
  palt(5,true)
 end
 if r==rooms[0][1] and not overlay then
  memset(0x6000,13*17,0x2000)
  do_clouds(cam.x,cam.y,true)
  for i=0,0xfc0,0x40 do
   memcpy(0x6000+i,0x6000+i*2,64)
  end
  palt(5,true)
 end 

 local l
 if (overlay) pal(14,r[1]) l=2
 map(mapx,mapy,sx,sy,16,16,l)
 if (r.snow and overlay) draw_snow(sx,sy,r.snow)

 if r.forest and overlay then
  for x=mapx,mapx+16 do
   for y=mapy,mapy+16 do
    local mv=mget(x,y)
    if mv==62 or mv==15 then
     circfill(x*8+4,y*8+4,
        (x*y)%3+6,3)
    end
   end
  end
 end
 
 pal() palt()
  
end

cam={}
function init_camera()
 cam.x=flr(p.x/128)*128
 cam.y=flr(p.y/128)*128
 camera(cam.x,cam.y)
end

function update_camera()
 local rpx=flr(p.x/128)*128
 local rpy=flr(p.y/128)*128
 cam.x=rpx cam.y=rpy
 camera(cam.x,cam.y)
end
  
function black_pause()
 memset(0x6000,0,8192)
 for i=1,30 do flip() end
end

function cprint(s,row,clr)
 print(s,cam.x+64-#s*2,cam.y+row*6,clr)
end

function draw_dying()
 for d in all(dying) do
  if not (d.ang and d.shrink) then
   d.ang=atan2(d.x-p.x,d.y-p.y)
   d.shrink=0
  end
  d.x+=2*cos(d.ang)+rndi(-1,1)
  d.y+=2*sin(d.ang)+rndi(-1,1)
  pal(15,d.sfgc)
  sspr((d.sn%16)*8,flr(d.sn/16)*8,
    d.sw,d.sh,d.x,d.y,
    d.sh-d.shrink,d.sw-d.shrink,d.sfh,d.sfv)
  pal()
  d.shrink+=1
  if d.shrink>max(d.sh,d.sw) then
   del(dying,d)
  end
 end
end

function _draw()
 if you_monster then
  camera(0,0)
  cls()
  print("error line 1459",0,0,14)
  print("<no duck>",0,6,7)
  print("you monster",0,12,6)
  print(">",0,18,7)
  if ticks%16<8 then
   rectfill(8,18,11,22,8)
  end
  return
 end

 if in_title then
  memset(0x6000,0,8192)
  for i=0,7 do
   pal(10,rndi(1,15))
   local sx,sy=32+i*8,16
   local dx=i*16+cam.x
   local dy=20+cam.y+100*sin((i+ticks)/10)/ticks
   if i==6 and ticks%50<25 then sy=0 end
   sspr(sx,sy,7,16,dx,dy,14,32,i==4 and ticks%113<41,i==7 and ticks%20<10)
--   spr(sp,31+cam.x+i*9+cos((ticks-i)/30)*1.5,cam.y+30+sin((ticks+i)/60)*1.5,1,2,i==4 and ticks%113<41,i==7 and ticks%20<10)
  end
  cprint("🅾️+dir - rotates held item",11,12)
  cprint("❎ - drops held item",12,12)
  cprint("--> 🅾️ to start <--",15,10)
  cprint("⬇️+❎ to start hardcore",18,2+ticks%2*6)
  return
 end
 local proom=sroom(p)
 
 if proom==rooms[0][0] then
--  clip() palt(0,false)
--  rectfill(0,0,256,256,0)
  memset(0x6000,0,8192)
  clip(flr(p.x/64)*64,flr(p.y/64)*64,64,64)
 elseif proom.sewer then
--  clip()
  memset(0x6000,0,8192)
  local w=proom.sewer
  clip(p.x%128-w+2,p.y%128-w+3,2*w,2*w)
 else
  clip() palt()
 end
 
 update_camera()
 draw_room()
 draw_sprite(p)
  
 if proom.shrine then
  draw_sprite(altar)
 end

 for g in all(ghosts) do
  g.sfh=p.x+p.sw/2 < g.x+g.sw/2
  draw_sprite(g)
 end
 
 for s in all(scorps) do
  draw_sprite(s)
 end

 for it in all(items) do
  draw_sprite(it)
 end
 
 draw_dying()
 
 for kn in all(knights) do
  if proom==rooms[0][0] and
     kn.dx and ticks%2==0 then
   line(kn.swx-2,kn.swy-2,
        kn.swx+2,kn.swy+2,rnd(16))
   line(kn.swx-2,kn.swy+2,
        kn.swx+2,kn.swy-2,rnd(16))
  end
  draw_sprite(kn)
  if rnd(1)>0.01 then
   local qq=sign(p.x+2-kn.winx)
   rectfill(kn.winx-3+qq,kn.winy-1,
      kn.winx+2+qq,kn.winy+3,7)
   pset(kn.winx-2+qq,kn.winy,8)
   pset(kn.winx+1+qq,kn.winy,8)
  end
 end
 
	spr(duck.top,duck.x,duck.y,3,2,duck.fh)
	if(duck.hurtfeet) pal(14,6)
	spr(duck.bottom,duck.x,duck.y+16,3,2,duck.fh)
	pal()

 if duck.asleep then
  duck.top=70 duck.bottom=102
 else
  if rnd(1)<0.1 then
 	 duck.top = (67-duck.top)+64
 	 if duck.top==67 then
 	  if distobjs(p,duck)<200 then sfx(12)
 	  else sfx(14) end
 	 end
  end
  if rnd(1)<0.1 then
   duck.bottom = (99-duck.bottom)+96
  end
 end
 
 draw_sprite(cup) --after duck

 if proom.snow then
  for s in all(snorcs) do
   if(s.spd<=1) pal(7,12)
   if ticks%16==0 then
    s.sfh=not s.sfh
   end
   draw_sprite(s)
   pal()
  end
 end
 
 if proom.arrows then
  for a in all(arrows) do
   line(a.x,a.y,a.x-7*cos(a.ang),a.y-7*sin(a.ang),rnd(16))
  end
 end

 draw_room(true) --overlay layer
 -- things after this will appear
 -- on top of the overlay tiles
 
 -- the deadly nommer
 if nommer then
  if not nommer.asleep and
     distobjs(p,nommer)<32
  then
   if true then
    draw_sprite(nommer)
    if rnd(1)<0.1 then
     nommer.sn=178-nommer.sn
     if nommer.sn==105 and p.dead then
      sfx(18)
     end
    end
   end
   if not nommer.wasseen then
    sfx(17)
    nommer.wasseen=true
   end
  else
   nommer.wasseen=false
  end
 end
 
 if ship and distobjs(p,ship)<256 then
  draw_sprite(ship)
 end

 if proom.sewer then
  local cx,cy=p.x+2,p.y+3
  local w=proom.sewer
  for a=0,1,0.0625 do
   r=w*1.5+rndi(-2,2)+2
   circfill(cx+r*cos(a),cy+r*sin(a),w*0.75,0)
  end
 end


 if p.dead then
  clip()
  cprint("game over",3,rndi(0,15))
 end
 
 if show_win then
  cprint("you win!",15,ticks/4%16)
  if hardcore then
   for i=1,8 do
    print(sub("hardcore",i,i),
       cam.x+40+5*i+cos(i*ticks/10),
       cam.y+103+sin(i*ticks/10),
       rndi(8,10))
   end
  end
 end
 
 if proom.dotted then
  local s="b.lyeosus...w.arrorbeinn.e.t.t"
  for i=1,#s,2 do
   cprint(sub(s,i,i+1),(i+1)/2+2,rnd(16))
  end
 end
 
 if enddelay and enddelay==0 then
  cprint("❎ to restart",19,rnd(16))
 end
 
end
