--update------------------------
function _update()
 if (gmode==0) g_title() --title
 if (gmode==1) g_main()  --game
 gcnt +=1 if (gcnt>20000) gcnt=10000
end

--draw--------------------------
function _draw()
 rectfill(0,0,128,128,0)
 d_star() zankidisp()
 dorudsp()
 if gmode==1 then
    if (mystat==1) mydsp1()
    if (mystat==2) mydsp2()
    if (mystat==4) mydsp1() mydsp3()
    if (mystat==5) gover_dsp()
    mybeam_dsp()
    if (rcnt<50) rounddisp()    
 end
 tekidisp()
 tekidandisp()
 scoredisp()
 for i=1,round do
   spr(6+(rcnt/6)%2,i*8-8,120)
 end
 if msscnt>0 then
    spr(38,x+3,y-16) for _k=0,5 do spr(39,x+11+_k*8,y-16) end
    print(msss,x+12,y-21,(rcnt/2)%2+7)
    msscnt-=1
 end
 if gmode==0 then ttldisp() end
end

function d_star()
 for i=1,80 do
  stary[i] += starvy[i]
  if (stary[i]>128) stary[i]=0
  spr(starsp[i],starx[i],stary[i])
 end
end

function tekidisp()
 for i=1,100 do
  if mm[i]~=99 then
   spr(msp[i],mx[i]-4,my[i]-4)
  else
   a=flr(mcnt[i]/2)*2
   spr(24+a,mx[i]-8,my[i]-8)
   spr(25+a,mx[i]  ,my[i]-8)
   spr(40+a,mx[i]-8,my[i])
   spr(41+a,mx[i]  ,my[i])
  end
 end
end

function dorudsp()
 for i=1,50 do
  spr(dosp[i],dox[i]-4,doy[i]-4)
 end
 print("next event",80,0,scorecol*1.5)
 print(5-(mycoin%5),124,0,scorecol/8*10)
 print(event,128-#event*4,6,scorecol/8*7)
end

function tekidandisp()
 for i=1,50 do
  spr(tdsp[i],tdx[i]-4,tdy[i]-4)
 end
end

function rounddisp()
 if (gmode==0) return 0
 print("-- persec     --",30,60,8)
 _a=80 if (round>=10) _a=76
 print(round,_a,60,7)
end

function zankidisp()
 if (zanki>1) spr(1,120,120)
 if (zanki>2) spr(1,111,120)
 if (zanki>3) spr(1,102,120) 
end

--main loop---------------------
function g_main()
 mymove()
 mybeammove()
 dorumove()
 tekimove()
 tekidanmove()
 r_dsg()
 rcnt += 1 if (rcnt>20000) rcnt=10000
end

--my move-----------------------
function mymove()
 if (mystat==1) mymv1()
 if (mystat==2) mymv2()
 if (mystat==3) mymv3()
 if (mystat==4) mymv1() mymv4()
 if (mystat==5) gover()
end

function mymv1()
 if (btn(0)) x-=myspee
 if (btn(1)) x+=myspee
 if (btn(2)) y-=myspee
 if (btn(3)) y+=myspee
 if (x<4) x=4
 if (x>124) x=124
 if (y<72) y=72
 if (y>120) y=120
 if (btnp(4) or btnp(5)) mybeam_ap()
end
function mymv2()
 yararecnt += 1 if (yararecnt>15) mystat=3
end
function mymv3()
 yararecnt += 1 if (yararecnt>80) deadfunc()
end
function mymv4()
 mutekicnt += 1 if (mutekicnt>80) mystat=1
end
function deadfunc()
 zanki-=1
 if zanki<1 then
    mystat=5 yararecnt=0 return 0
 end
 myinit()
end
function mydsp1()
 spr(1,x-4,y-4)
 if mbchr==5 then
    spr(gcnt%2+2,x-4,y+4)
 end
end
function mydsp2()
 a=(flr(yararecnt/4)%4)*2
 spr(192+a,x-8,y-8) spr(193+a,x,y-8)
 spr(208+a,x-8,y  ) spr(209+a,x,y  )
end
function mydsp3()
 a=(flr(mutekicnt/2)%4)*2
 b=224
 if (mutekicnt>20) b=200
 if (mutekicnt>50) b=232
 spr(b+a   ,x-8,y-8) spr(b+a+1 ,x,y-8)
 spr(b+a+16,x-8,y  ) spr(b+a+17,x,y  )
end 

function myyarareap()
 sfx(3)
 mystat=2 yararecnt=0
end

--my beam-----------------------
function mybeam_ap()
 for i=1,mbmax do
  if mbm[i]==0 then
   sfx(mbse)
   mbm[i]=1
   mbx[i]=x mby[i]=y-3
   mbvy[i]=-5 if (mbchr==5) mbvy[i]=-7
   break
  end
 end
end
function mybeammove()
 for i=1,3 do
  if mbm[i] then
     mby[i]+=mbvy[i]
     if (mby[i]<0) mby[i]=-999 mbm[i]=0 
  end
 end
end

function mybeam_dsp()
 for i=1,3 do
  spr(mbchr,mbx[i]-4,mby[i]-4)
 end
end

--dorumove----------------------
function dorumove()
 for ii=1,50 do
  doy[ii] += dovy[ii]
  if dovy[ii]>0 then
     dosp[ii]=(gcnt/2)%4+48
     if (doy[ii]>130) doy[ii]=444 dovy[ii]=0
     if ((abs(x-dox[ii])<8) and (abs(y-doy[ii])<8)) doruget(ii)
  end
  if dovy[ii]<0 then
     dosp[ii] += 0.5
     if (dosp[ii]>56) doy[ii]=444 dovy[ii]=0
  end
 end
end
function doruget(ii)
 if ((mystat==2) or (mystat==3)) return
 local getsound=5
 mystat=4 if (mutekicnt>60) mutekicnt=60
 dosp[ii]=51 dovy[ii]=-0.5 doy[ii]=y-8
 score += 1
 mycoin += 1
 if (mycoin==5)  myspee=4 mbchr=5 mbhit=9 mbmax=3 mbse=7 event="shield" getsound=6 msss="power up!!!" msscnt=40
 if (mycoin==10) mystat=4 mutekicnt=-40 event="bonus+1000" getsound=6              msss="get shield!" msscnt=40
 if (mycoin==15) score+=10 event="power up" getsound=6                             msss="bonus +1000" msscnt=40
 if (mycoin==20) myspee=4 mbchr=5 mbhit=9 mbmax=3 mbse=7 event="shield" getsound=6 msss="power up!!!" msscnt=40
 if (mycoin==25) mystat=4 mutekicnt=-40 event="extend" getsound=6                  msss="get shield!" msscnt=40
 if mycoin==30 then
    mycoin=0 event="power up"
    if (zanki<4) zanki+=1 msss="extend!" msscnt=40 sfx(14)
 end
 sfx(getsound)
end
function doruap(ii)
 dorucnt += 1 if (dorucnt>50) dorucnt=1
 dox[dorucnt] = mx[ii]
 doy[dorucnt] = my[ii]
 dovy[dorucnt]= 1+rnd(2)  
end

--tekimove----------------------
function tekimove()
 for ii=1,100 do
  if (mm[ii]==1) m1(ii)
  if (mm[ii]==2) m2(ii)
  if (mm[ii]==3) m3(ii)
  if (mm[ii]==4) m4(ii)
  if (mm[ii]==5) m5(ii)
  if (mm[ii]==6) m6(ii)
  if (mm[ii]==7) m7(ii)
  if (mm[ii]==8) m8(ii)
  if (mm[ii]==9) m9(ii)
  if (mm[ii]==10) m10(ii)
  if (mm[ii]==11) m11(ii)
  if (mm[ii]==99) m99(ii)
  if ((abs(x-mx[ii])<4) and (abs(y-my[ii])<4) and mystat==1) myyarareap()
 end
 
 if ((rcnt>flyend) and (flr(rnd(40))==1)) m1tobi()
 
 m1cnt += m1cntv
 if (m1cnt<=8)   m1cntv=0.1
 if (m1cnt>=12) m1cntv=-0.1
 baseang += 0.01 if (baseang>=1) baseang=0 
 basex=64+cos(baseang)*16
 basey=10+sin(baseang*2)*8
end

--teki1- - - - - - - - - - - - -
function m1(ii)
 mx[ii]=hx[ii]*m1cnt+basex
 my[ii]=hy[ii]*m1cnt+basey
 msp[ii]=hc[ii]*16+64+((baseang)*16%4)
 thit(ii)
end
function m1tobi()
 a=tekiserch()
 if (a>0) then
   b=rnd(10)
   if (b<6) ma2(a)
   if ((b<=8) and (b>=6)) ma4(a)
   if ((b<=10) and (b>8)) ma7(a)
 end
end

--teki2- - - - - - - - - - - - -
function m2(ii)
 m_bx[ii]=mx[ii] m_by[ii]=my[ii]
 for j=0,r_speed do
   mx[ii] += m1vx[mcnt[ii]]*mflg1[ii] my[ii] += m1vy[mcnt[ii]]
   if (mcnt[ii]<600) mcnt[ii] += 1
 end
 if (my[ii]>160) ma3(ii)
 msp[ii]=tekimuki(ii,m_bx[ii],m_by[ii],mx[ii],my[ii])
 if (flr(rnd(tamapar))==1 and my[ii]<50)  tekidanap(ii)
 thit(ii)
end
function ma2(ii)
 if (gmode==1) sfx(2)
 mm[ii]=2
 mcnt[ii]=1
 mflg2[ii]=hc[ii]*16+68
 mflg1[ii]=1 if (mx[ii]>64) mflg1[ii]=-1
end

--teki3- - - - - - - - - - - - -
function m3(ii)
 m_bx[ii]=mx[ii] m_by[ii]=my[ii]
 a=hx[ii]*m1cnt+basex
 b=hy[ii]*m1cnt+basey
 c=atan2(a-mx[ii],b-my[ii])
 if (c>mflg1[ii]) mflg1[ii] += 0.05
 if (c<mflg1[ii]) mflg1[ii] -= 0.05
 mx[ii] += cos(mflg1[ii])*4
 my[ii] += sin(mflg1[ii])*4
 if (abs(a-mx[ii])<4) and (abs(b-my[ii])<4) then
    mm[ii]=1
 end
 if ((mx[ii]<-50) or (mx[ii]>178)) ma3(ii)
 msp[ii]=tekimuki(ii,m_bx[ii],m_by[ii],mx[ii],my[ii])
 thit(ii)
end
function ma3(ii)
 mm[ii]=3
 my[ii]=0 mx[ii]=rnd(128)
 mflg1[ii]=rnd(0.25)+0.62
end

--teki4- - - - - - - - - - - - -
function m4(ii)
 m_bx[ii]=mx[ii] m_by[ii]=my[ii]
 for j=0,r_speed do
   mx[ii] += m2vx[mcnt[ii]]*mflg1[ii] my[ii] += m2vy[mcnt[ii]]
   if (mcnt[ii]<600) mcnt[ii] += 1
 end
 if (my[ii]>130) ma3(ii)
 msp[ii]=tekimuki(ii,m_bx[ii],m_by[ii],mx[ii],my[ii])
 if (flr(rnd(tamapar))==1 and my[ii]<50)  tekidanap(ii)
 thit(ii)
end
function ma4(ii)
 mm[ii]=4
 mcnt[ii]=1
 mflg2[ii]=hc[ii]*16+68
 mflg1[ii]=1 if (mx[ii]>64) mflg1[ii]=-1
 if (gmode==1) sfx(2)
end

--teki5-------------------------
function m5(ii)
 m_bx[ii]=mx[ii] m_by[ii]=my[ii]
 for j=0,r_speed do
   mx[ii] += m3vx[mcnt[ii]]*mflg1[ii] my[ii] += m3vy[mcnt[ii]]
   mcnt[ii]+=1
 end
 if mcnt[ii]>=120 then
    mm[ii]=3 mflg1[ii]=0.25
 end
 msp[ii]=tekimuki(ii,m_bx[ii],m_by[ii],mx[ii],my[ii])
 if (flr(rnd(tamapar))==1 and my[ii]<50)  tekidanap(ii)
 thit(ii)
end
function ma5(_b,_c)
 mm[_b]=5
 mcnt[_b]=1
 mflg2[_b]=hc[_b]*16+68
 mflg1[_b]=1 if (_c==1) mflg1[_b]=-1
end

--teki 06(star)-----------------
function m6(ii)
 mcnt[ii]+=1
 if (mcnt[ii]>=0) msp[ii]=flr(mcnt[ii]/2)+32
 if mcnt[ii]==12 then
    _a=mflg2[ii]
    if (_a==1) ma5(ii,mflg1[ii])
    if (_a==2) ma8(ii,mflg1[ii])
    if (_a==3) ma9(ii,mflg1[ii])
    if (_a==4) ma10(ii,mflg1[ii])
    if (_a==5) ma10(ii,mflg1[ii])
    if (_a==6) ma11(ii,mflg1[ii])
 end
end
function ma6(_b,_c,_d,_e)
 
 mm[_b]=6
 mflg1[_b]=_c mflg2[_b]=_e
 mcnt[_b]=-_d
 msp[_b]=0
 if _e==1 then mx[_b]=50 my[_b]=8   end
 if _e==2 then mx[_b]=8  my[_b]=100 end 
 if _e==3 then mx[_b]=10 my[_b]=8   end
 if _e==4 then mx[_b]=4  my[_b]=30  end
 if _e==5 then mx[_b]=4  my[_b]=90  end
 if _e==6 then mx[_b]=4  my[_b]=80  end
 if (_c==1) mx[_b]=128-mx[_b]
end

--teki 07-----------------------
function m7(ii)
 m_bx[ii]=mx[ii] m_by[ii]=my[ii]
 for j=0,r_speed do
   mx[ii] += m4vx[mcnt[ii]]*mflg1[ii] my[ii] += m4vy[mcnt[ii]]
   if (mx[ii]<-4) mx[ii]=132
   if (mx[ii]>132) mx[ii]=-4
   if (mcnt[ii]<202) mcnt[ii] += 1
 end
 if mcnt[ii]>200 then
    mm[ii]=3 mflg1[ii]=0.25
 end
 msp[ii]=tekimuki(ii,m_bx[ii],m_by[ii],mx[ii],my[ii])
 if (flr(rnd(tamapar))==1 and my[ii]<50)  tekidanap(ii)
 thit(ii)
end
function ma7(ii)
 if (gmode==1) sfx(2)
 mm[ii]=7
 mcnt[ii]=1
 mflg2[ii]=hc[ii]*16+68
 mflg1[ii]=1 if (mx[ii]>64) mflg1[ii]=-1
end

--teki 08-----------------------
function m8(ii)
 m_bx[ii]=mx[ii] m_by[ii]=my[ii]
 for j=0,r_speed do
   mx[ii] += m5vx[mcnt[ii]]*mflg1[ii] my[ii] += m5vy[mcnt[ii]]
   if (mcnt[ii]<170) mcnt[ii] += 1
 end
 if mcnt[ii]>168 then mm[ii]=3 mflg1[ii]=0.25 end
 msp[ii]=tekimuki(ii,m_bx[ii],m_by[ii],mx[ii],my[ii])
 if (flr(rnd(tamapar))==1 and my[ii]<50)  tekidanap(ii)
 thit(ii)
end
function ma8(_b,_c)
 mm[_b]=8
 mcnt[_b]=1
 mflg2[_b]=hc[_b]*16+68
 mflg1[_b]=1 if (_c==1) mflg1[_b]=-1
end

--teki9-------------------------
function m9(ii)
 m_bx[ii]=mx[ii] m_by[ii]=my[ii]
 for j=0,r_speed do
   mx[ii] += m6vx[mcnt[ii]]*mflg1[ii] my[ii] += m6vy[mcnt[ii]]
   mcnt[ii]+=1
 end
 if mcnt[ii]>=341 then
    mm[ii]=3 mflg1[ii]=0.25
 end
 msp[ii]=tekimuki(ii,m_bx[ii],m_by[ii],mx[ii],my[ii])
 if (flr(rnd(tamapar))==1 and my[ii]<50)  tekidanap(ii)
 thit(ii)
end
function ma9(_b,_c)
 mm[_b]=9
 mcnt[_b]=1
 mflg2[_b]=hc[_b]*16+68
 mflg1[_b]=1 if (_c==1) mflg1[_b]=-1
end

--teki10------------------------
function m10(ii)
 m_bx[ii]=mx[ii] m_by[ii]=my[ii]
 for j=0,r_speed do
   mx[ii] += m7vx[mcnt[ii]]*mflg1[ii] my[ii] += m7vy[mcnt[ii]]
   mcnt[ii]+=1
 end
 if mcnt[ii]>=358 then
    mm[ii]=3 mflg1[ii]=0.25
 end
 msp[ii]=tekimuki(ii,m_bx[ii],m_by[ii],mx[ii],my[ii])
 if (flr(rnd(tamapar))==1 and my[ii]<50)  tekidanap(ii)
 thit(ii)
end
function ma10(_b,_c)
 mm[_b]=10
 mcnt[_b]=1
 mflg2[_b]=hc[_b]*16+68
 mflg1[_b]=1 if (_c==1) mflg1[_b]=-1
end

--teki11------------------------
function m11(ii)
 m_bx[ii]=mx[ii] m_by[ii]=my[ii]
 for j=0,r_speed do
   mx[ii] += mflg1[ii] mcnt[ii] += 1
   if (mx[ii]<-4) mx[ii]=132
   if (mx[ii]>132) mx[ii]=-4
 end
 if (mcnt[ii]>300) mm[ii]=3 mflg1[ii]=-(mflg1[ii]-1)*0.25
 msp[ii]=tekimuki(ii,m_bx[ii],m_by[ii],mx[ii],my[ii])
 thit(ii)
end
function ma11(_b,_c)
 mm[_b]=11 mcnt[_b]=1
 mflg1[_b]=1 if (_c==1) mflg1[_b]=-1
 mflg2[_b]=hc[_b]*16+68
end

--teki zouen 1------------------
function zouenap(_a,_d,_f)
 sfx(4)
 _c=0 _b=0
 for j=1,_f do
  i=0
   while (i==0) do
   a=flr(rnd(tekinow-1))+1
   if mm[a]==0 then
      i=1 _b+=4 ma6(a,_a,_b,_d)
   end
  end
 end
end

--teki sini---------------------
function m99(ii)
 mcnt[ii] += 1
 if mcnt[ii]>6 then
  mm[ii]=0 my[ii]=999
 end
end

--tekimuki func-----------------
function tekimuki(_ii,_a,_b,_c,_d)
 a=flr(atan2(_c-_a,_d-_b)*24)+1
 return mflg2[_ii]+muki[a]
end

--tekikie func------------------
function tkie(ii)
 mm[ii]=0 my[ii]=999
end

--teki serch--------------------
function tekiserch()
 a=flr(rnd(50)) b=-1
 for i=0,55 do
  a+=1 if (a>55) a=1
  if (mm[a]==1) b=a break
 end
 return b
end

--thit hantei-------------------
function thit(ii)
 for jj=1,3 do
  if abs(mx[ii]-mbx[jj])<mbhit and abs(my[ii]-mby[jj])<mbhit then
     if (mm[ii]<99) tekisini(ii,jj)
  end    
 end
end

--tekisini----------------------
function tekisini(ii,jj)
 if (beanon==1) tekidanap2(ii)
 mby[jj]=-999 mbvy[jj]=0
 mm[ii]=99 mcnt[ii]=0
 sfx(1)
 score+=hc[ii]
 gekiha+=1
 if (gekiha>boncnt) beanon=1
 if ((gekiha%3)==0) doruap(ii)

 if (round==1) r1_zouen()
 if (round==2) r2_zouen()
 if (round==3) r3_zouen()
 if (round==4) r4_zouen()
 if (round==5) r5_zouen()
 if (round==6) r6_zouen()
 if (round==7) r7_zouen()
 if (round==8) r8_zouen()
 if (round>8)  r8_zouen()

 if tekimax<=gekiha then
    round +=1 if (round>8) round=1 rr=1
    r_ini()
 end

end

--tekidan move------------------
function tekidanmove()
 for ii=1,50 do
  if (tdm[ii]==1) tekidn1(ii)
  if (tdm[ii]==2) tekidn2(ii)
  if (tdm[ii]==3) tekidn3(ii)
  if (tdm[ii]==4) tekidn4(ii)  
  if (tdm[ii]==5) tekidn5(ii)  
  if (tdm[ii]==6) tekidn6(ii)  
  if (tdm[ii]==7) tekidn7(ii)  
  if ((abs(x-tdx[ii])<3) and (abs(y-tdy[ii])<3) and mystat==1) myyarareap()
 end
end
-- normal tekidan- - - - - - - -
function tekidn1(ii)
 tdx[ii] += tdvx[ii] tdy[ii] += tdvy[ii]
 if tdy[ii]>130 then tdy[ii]=999 tdvy[ii]=0 tdm[ii]=0 end
end
function tekidn2(ii)
 tdx[ii] += tdvx[ii] tdy[ii] += tdvy[ii]
 tdsp[ii]=19+(flr((gcnt/3))%4)
 if tdy[ii]>130 then tdy[ii]=999 tdvy[ii]=0 tdm[ii]=0 end
end
function tekidn3(ii)
 a=atan2(x-tdx[ii],y-tdy[ii])
 tdr[ii]+=tddirec(ii)
 if (tdr[ii]<0) tdr[ii]=1
 if (tdr[ii]>1) tdr[ii]=0
 tdx[ii]+=cos(tdr[ii])*2
 tdy[ii]+=sin(tdr[ii])*2
 tdsp[ii]=57+(flr((gcnt/3))%2)
 if ((tdy[ii]>130) or (tdx[ii]<-4) or (tdx[ii]>132)) then tdy[ii]=999 tdvy[ii]=0 tdm[ii]=0 end
end
function tekidn4(ii)
 tdx[ii] += 1
 if (tdx[ii]>10000) tdm[ii]=0
 if ((tdx[ii]%50)==0) tekidanap5(ii)
end
function tekidn5(ii)
 tdr[ii] += 1
 if (tdr[ii]>25) tekidnap6(ii)
 tdsp[ii]=59+(flr((gcnt/3))%2)
end
function tekidn6(ii)
 tdr[ii] += 1
 tdx[ii] += tdvx[ii] tdy[ii] += tdvy[ii]
 if (tdr[ii]>10) tekidnap7(ii)
 for jj=1,3 do
  if abs(tdx[ii]-mbx[jj])<mbhit and abs(tdy[ii]-mby[jj])<mbhit then
     mby[jj]=-999 mbvy[jj]=0
  end    
 end
end
function tekidn7(ii)
 tdx[ii] += tdvx[ii] tdy[ii] += tdvy[ii]
 if tdy[ii]>130 then tdy[ii]=999 tdvy[ii]=0 tdm[ii]=0 end
 for jj=1,3 do
  if abs(tdx[ii]-mbx[jj])<mbhit and abs(tdy[ii]-mby[jj])<mbhit then
     mby[jj]=-999 mbvy[jj]=0 tdm[ii]=0 tdy[ii]=999
  end    
 end
end
function tddirec(ii)
 local qqq=tdr[ii]-a
 if (qqq<0)  b=0.01
 if (qqq>=0) b=-0.01
 if (tdr[ii]+0.5<a) b=-0.01
 if (tdr[ii]-0.5>a) b=0.01
 return b
end
function tekidanap(ii)
 if ((round>4) and (rnd(10)<2)) tekidanap3(ii) return 0
 tdcnt += 1 if (tdcnt>50) tdcnt=1
 if (tdm[tdcnt]==4) return
 tdx[tdcnt]  = mx[ii]
 tdy[tdcnt]  = my[ii]
 tdsp[tdcnt] = flr(rnd(3))+16
 tdvy[tdcnt] = rnd(2)+2
 tdvx[tdcnt] = sgn(x-mx[ii])
 tdm[tdcnt]  = 1
end
function tekidanap2(ii)
 tdcnt += 1 if (tdcnt>50) tdcnt=1
 if (tdm[tdcnt]==4) return
 tdx[tdcnt]  = mx[ii]
 tdy[tdcnt]  = my[ii]
 tdsp[tdcnt] = 19
 tdvy[tdcnt] = rnd(1.5)+1.5
 tdvx[tdcnt] = rnd(3)-1.5
 tdm[tdcnt]  = 2
end
function tekidanap3(ii)
 tdcnt += 1 if (tdcnt>50) tdcnt=1
 if (tdm[tdcnt]==4) return
 tdx[tdcnt]  = mx[ii]
 tdy[tdcnt]  = my[ii]
 tdsp[tdcnt] = 57
 tdvy[tdcnt] = 0 tdvx[tdcnt] = 0
 tdr[tdcnt]  = 0.75
 tdm[tdcnt]  = 3
end
function tekidanap4()
 tdcnt += 1 if (tdcnt>50) tdcnt=1
 tdm[tdcnt] = 4
 tdx[tdcnt] = 0 tdy[tdcnt] = 0
 hosi=tdcnt
end
function tekidanap5(ii)
 tdcnt += 1 if (tdcnt>50) tdcnt=1
 if (tdm[tdcnt]==4) return
 sfx(8)
 tdm[tdcnt] = 5
 tdx[tdcnt] = rnd(64) if (x<64) tdx[tdcnt] += 64
 tdy[tdcnt] = 72+rnd(10)
 tdvx[tdcnt] = 0
 tdvy[tdcnt] = 0
 tdsp[tdcnt] = 59
 tdr[tdcnt]  = 0
end
function tekidnap6(ii)
 tdcnt += 1 if (tdcnt>50) tdcnt=1
 tdm[tdcnt] = 6
 tdx[tdcnt] = tdx[ii]
 tdy[tdcnt] = tdy[ii]
 tdr[tdcnt] = 0
 tdsp[tdcnt] = 61
 tdvx[tdcnt] = rnd(1)
 tdvy[tdcnt] = 1.5
 if (x<tdx[tdcnt]) tdvx[tdcnt]=-tdvx[tdcnt]
 tdy[ii]=999 tdvy[ii]=0 tdm[ii]=0
end
function tekidnap7(ii)
 for jj=0,3 do
  tdcnt += 1 if (tdcnt>50) tdcnt=1
  tdm[tdcnt] = 7
  tdx[tdcnt] = tdx[ii]
  tdy[tdcnt] = tdy[ii]
  tdvy[tdcnt] = 2
  tdvx[tdcnt] = (jj*1.5)-2.25
  tdsp[tdcnt] = 62
 end
 tdy[ii]=999 tdvy[ii]=0 tdm[ii]=0
end

--round design------------------
function r_dsg()
 if (round==1) rg1()
 if (round==2) rg2()
 if (round==3) rg3()
 if (round==4) rg4()
 if (round==5) rg5()
 if (round==6) rg6() 
 if (round==7) rg7() 
 if (round==8) rg8() 
 if (round>8)  rg8()
 
 if (rr==1) boncnt=0 tamapar=30
end

--round 1- - - - - - - - - - - -
function rg1()
 if (rcnt==80)  henseiap(0,1,7) henseiap(1,1,8)
 if (rcnt==180) henseiap(0,2,8) henseiap(1,2,8)
 if (rcnt==280) henseiap(0,1,8) henseiap(1,1,8)
 if (rcnt==380) henseiap(0,2,4) henseiap(1,2,4)
end
function r1_ini()
 r_speed = 1   --enemy speed
 tamapar = 0   --tekidan per
 tekimax = 55  --enemy max
 boncnt  = 999 --beanon switch
 flyend  = 480
end
function r1_zouen()
end

--round 2- - - - - - - - - - - -
function rg2()
 if (rcnt==80)  henseiap(0,1,7) henseiap(1,1,8)
 if (rcnt==180) henseiap(0,2,8) henseiap(1,2,8)
 if (rcnt==280) henseiap(0,1,8) henseiap(1,1,8)
 if (rcnt==380) henseiap(0,2,4) henseiap(1,2,4)
end
function r2_ini()
 r_speed = 2   --enemy speed
 tamapar = 100 --tekidan per
 tekimax = 71  --enemy max
 boncnt  = 999 --beanon switch
 flyend  = 480
end
function r2_zouen()
 if (gekiha==40) zouenap(0,1,8)
 if (gekiha==50) zouenap(1,1,8)
end

--round 3- - - - - - - - - - - -
function rg3()
 if rcnt==80 then henseiap(0,3,27) henseiap(1,3,28) end
end
function r3_ini()
 r_speed = 3   --enemy speed
 tamapar = 100 --tekidan per
 tekimax = 125 --enemy max
 boncnt  = 115 --beanon switch
 flyend  = 320
end
function r3_zouen()
 if (gekiha==50) zouenap(0,4,15)
 if (gekiha==60) zouenap(1,4,15)
 if (gekiha==75) zouenap(0,3,10) zouenap(1,3,10) tekidanap4()
 if (gekiha==90) zouenap(0,1,10) zouenap(1,2,10)
end

--round 4- - - - - - - - - - - -
function rg4()
 if rcnt==80 then henseiap(0,1,7) henseiap(1,1,8) end
 if rcnt==180 then henseiap(0,2,8) henseiap(1,2,8) end
 if rcnt==280 then henseiap(0,1,8) henseiap(1,1,8) end
 if rcnt==380 then henseiap(0,2,4) henseiap(1,2,4) end
end
function r4_ini()
 r_speed = 2   --enemy speed
 tamapar = 40  --tekidan per
 tekimax = 103 --enemy max
 boncnt  = 50  --beanon switch
 flyend  = 480
end
function r4_zouen()
 if (gekiha==30) zouenap(0,1,6)
 if (gekiha==40) zouenap(1,1,6) tekidanap4()
 if (gekiha==50) zouenap(0,2,8)  zouenap(1,2,8)
 if (gekiha==60) zouenap(1,1,10) zouenap(0,2,10)
end
--round 5- - - - - - - - - - - -
function rg5()
 if rcnt==80 then henseiap(0,1,7) henseiap(1,2,8) end
 if rcnt==130 then henseiap(0,2,8) henseiap(1,1,8) end
 if rcnt==180 then henseiap(0,1,8) henseiap(1,2,8) end
 if rcnt==230 then henseiap(0,2,4) henseiap(1,1,4) end
end
function r5_ini()
 r_speed = 4   --enemy speed
 tamapar = 80  --tekidan per
 tekimax = 115 --enemy max
 boncnt  = 50  --beanon switch
 flyend  = 280
end
function r5_zouen()
 if (gekiha==40) zouenap(0,4,10)
 if (gekiha==50) zouenap(1,4,10) tekidanap4()
 if (gekiha==70) zouenap(0,5,10)
 if (gekiha==80) zouenap(1,5,10)
 if (gekiha==90) zouenap(0,1,10) zouenap(1,1,10)
end

--round 6- - - - - - - - - - - -
function rg6()
 if rcnt==80 then henseiap(0,1,7) henseiap(1,1,8) end
 if rcnt==150 then henseiap(0,2,8) henseiap(1,2,8) end
 if rcnt==220 then henseiap(0,1,8) henseiap(1,1,8) end
 if rcnt==290 then henseiap(0,2,4) henseiap(1,2,4) end
end
function r6_ini()
 r_speed = 4   --enemy speed
 tamapar = 50  --tekidan per
 tekimax = 115 --enemy max
 boncnt  = 40  --beanon switch
 flyend  = 380
end
function r6_zouen()
 if (gekiha==50) zouenap(0,1,10) zouenap(1,1,10) zouenap(0,4,10) zouenap(1,4,10)
 if (gekiha==70) tekidanap4()
 if (gekiha==80) zouenap(0,2,10) zouenap(1,2,10)
end

--round 7- - - - - - - - - - - -
function rg7()
 if (rcnt==80)  henseiap(0,3,7) henseiap(1,3,8)
 if (rcnt==180) henseiap(0,2,10) henseiap(1,2,10)
 if (rcnt==220) henseiap(0,4,10) henseiap(1,4,10)
end
function r7_ini()
 r_speed = 5   --enemy speed
 tamapar = 30  --tekidan per
 tekimax = 103 --enemy max
 boncnt  = 50  --beanon switch
 flyend  = 320
end
function r7_zouen()
 if (gekiha==30) zouenap(0,1,6)
 if (gekiha==40) zouenap(1,1,6)
 if (gekiha==50) zouenap(0,6,8) tekidanap4()
 if (gekiha==55) zouenap(1,2,8)
 if (gekiha==60) zouenap(1,6,10) tekidanap4()
 if (gekiha==65) zouenap(0,2,10)
end

--round 8- - - - - - - - - - - -
function rg8()
 if rcnt==80 then henseiap(0,1,7) henseiap(1,1,8) end
 if rcnt==140 then henseiap(0,2,8) henseiap(1,2,8) end
 if rcnt==200 then henseiap(0,1,8) henseiap(1,1,8) end
 if rcnt==240 then henseiap(0,2,4) henseiap(1,2,4) end
end
function r8_ini()
 r_speed = 6   --enemy speed
 tamapar = 50  --tekidan per
 tekimax = 173 --enemy max
 boncnt  = 30  --beanon switch
 flyend  = 280
end
function r8_zouen()
 if (gekiha==30) zouenap(0,1,6)
 if (gekiha==40) zouenap(1,1,6) tekidanap4()
 if (gekiha==50) zouenap(0,2,8)  zouenap(1,2,8) tekidanap4()
 if (gekiha==60) zouenap(1,1,10) zouenap(0,2,10) tekidanap4()
 if (gekiha==80) zouenap(0,1,10) tekidanap4()
 if (gekiha==85) zouenap(1,0,10)
 if (gekiha==90) zouenap(0,6,10) tekidanap4()
 if (gekiha==100) zouenap(1,6,10)
 if (gekiha==130) zouenap(0,3,20) zouenap(1,3,20)
end

--hensei appear-----------------
function henseiap(_a,_d,_f)
 if (gmode==1) sfx(4)
 _c=0 _b=0
 for j=1,_f do
  _b+=4 ma6(tekinow,_a,_b,_d)
  tekinow += 1
 end
end

--score disp--------------------
function scoredisp()
if (score>9999) score=9999
scorecnt +=1 scorecol=8
if (scorecnt<3) scorecol=0
if (scorecnt>15) scorecnt=0
print("score",0,0,scorecol)
print("000000",28,0,5)
a=""..score.."00" print(a,52-#a*4,0,7)
--print("teki gekiha",0,8,8)
--print(gekiha,48,8,7)
end

--game over---------------------
function gover()
 yararecnt+=1
 if (yararecnt>100) ttl_ini() 
end
function gover_dsp()
 print("g a m e  o v e r",32,60,8)
end

--title-------------------------
function g_title()
 scorecnt=10
 if btnp(4) then
    gmode=1 g_ini() r_ini() score=0
 end
 tekimove()
 tekidanmove()
 r_dsg()
 rcnt += 1 if (rcnt>20000) rcnt=10000
end
function ttldisp()
 if (rcnt%18)>6 then
   print("push any button",36,30,8)
   print("to game start!!",36,38,8)
 end
 print("(c)2016          presents",20,50,7)
 print("konimiru",52,50,14)
 sspr(0,64,120,32,8-(ttls/2),ttly-(ttls/2),120+ttls,32+ttls)
 if (ttly>72) ttly-=0.3
 ttls += ttlvy
 if ((ttls>16) or (ttls<0)) ttlvy=-ttlvy
end
function ttl_ini()
 gmode=0 zanki=3
 g_ini() round=5 r_ini()
 ttly=140 ttls=0 ttlvy=1
end

--ini---------------------------
function g_ini()
 rr=0 round=1 if (gmode==0) round=4
 mycoin=0
 event="power up"
 myinit()
 tdinit()

 mbm={0,0,0} mby={-999,-999,-999}
end
function r_ini()
 for i=1,100 do my[i]=999 mm[i]=0 end 
 for i=1,55 do mm[i]=0 end

 gekiha=0
 gcnt=0
 rcnt=0
 beanon=0
 tekinow=1
 tdm[hosi]=0
 
 if (gmode==1) music(0,0,15)
 
 if (round==1) r1_ini()
 if (round==2) r2_ini()
 if (round==3) r3_ini()
 if (round==4) r4_ini()
 if (round==5) r5_ini()
 if (round==6) r6_ini()
 if (round==7) r7_ini()
 if (round==8) r8_ini() 
 if (round>8)  r8_ini() 
  
end
function myinit()
 x=60 y=120 myspee=2 mbse=0
 mbchr=4 mbhit=4 mcoin=0 mbmax=2
 mystat=4 mutekicnt=-60
end
function tdinit()
 for i=1,50 do tdm[i]=0 tdy[i]=999 tdvy[i]=0 end
end

--init--------------------------
function _init()
 cls()
 starx={}  stary={}
 starvy={} starsp={}
 for i=1,100 do
  add(starx,rnd(128)) add(stary,rnd(128))
  add(starvy,rnd(3))  add(starsp,flr(rnd(8))+8)
 end
 mbm={} mbx={} mby={} mbvy={}
 for i=1,3 do
  add(mbm,0)
  add(mbx,0) add(mby,0) add(mbvy,0)
 end
 hx={0,0,0,0,0, 1,1,1,1,1, -1,-1,-1,-1,-1, 2,2,2,2,2, -2,-2,-2,-2,-2, 3,3,3,3,3, -3,-3,-3,-3,-3, 4,4,4,4,5, -4,-4,-4,-4,-5, 5,5,5,6,6, -5,-5,-5,-6,-6}
 hy={0,1,2,3,4, 0,1,2,3,4,  0, 1, 2, 3, 4, 0,1,2,3,4,  0, 1, 2, 3, 4, 0,1,2,3,4,  0, 1, 2, 3, 4, 1,2,3,4,1,  1, 2, 3, 4, 1, 2,3,4,3,4,  2, 3, 4, 3, 4}
 hc={0,1,2,3,3, 0,1,2,3,3,  0, 1, 2, 3, 3, 0,1,2,3,3,  0, 1, 2, 3, 3, 0,1,2,3,3,  0, 1, 2, 3, 3, 1,2,3,3,1,  1, 2, 3, 3, 1, 2,3,3,3,3,  2, 3, 3, 3, 3}
 hm={} for i=1,55 do add(hm,0) end

 mm={} mx={} my={} mvx={} mvy={} mcnt={} msp={} mflg1={} mflg2={}
 m_bx={} m_by={}
 for i=1,100 do
  add(mx,0) add(my,0) add(mm,0)
  add(mvx,0) add(mvy,0) add(mcnt,0) add(msp,0)
  add(mflg1,0) add(mflg2,0)
  add(m_bx,0) add(m_by,0)
 end

 tdm={} tdx={}  tdy={} tdvx={} tdvy={} tdsp={} tdr={}
 for i=1,50 do
  add(tdx,-999) add(tdy,-999) add(tdm,0)
  add(tdvx,0) add(tdvy,0) add(tdsp,0) add(tdr,0)
 end

 dox={} doy={} dovy={} dosp={}
 for i=1,50 do add(dox,444) add(doy,444) add(dovy,0) add(dosp,0) end

 muki={2,1,1,0,0,11,11,10,10,9,9,8,8,7,7,6,6,5,5,4,4,3,3,2}

 gmode=0
 score=56
 hscore=48050
 scorecol=0
 m1cnt=8
 m1cntv=0.1
 mycoin=0
 event="power up"
 dorucnt=1
 basex=64 basey=16 baseang=0
 scorecnt=0
 tdcnt=0
 gcnt=10000
 gekiha=0
 tekimax=100
 zanki=3
 mystat=0
 mbse=0
 hosi=0
 msscnt=0
 msss=""
 a=0 rr=0 b=0 c=0 ii=0
 
--move pattern sikomi-----------

--no 01
 m1vx={} m1vy={}
 for i=0.25,0.9,0.01 do add(m1vx,cos(i)) add(m1vy,sin(i)) end
 for i=0,60 do add(m1vx,cos(0.9)) add(m1vy,sin(0.9)) end
 for i=0.9,0,-0.005 do add(m1vx,cos(i)) add(m1vy,sin(i)) end
 for i=0.995,0,-0.005 do add(m1vx,cos(i)) add(m1vy,sin(i)) end
 for i=0.995,0.6,-0.005 do add(m1vx,cos(i)) add(m1vy,sin(i)) end
 for i=0,80 do add(m1vx,cos(0.6)) add(m1vy,sin(0.6)) end
--no 02
 m2vx={} m2vy={}
 for i=0.25,0.75,0.02 do add(m2vx,cos(i)) add(m2vy,sin(i)) end
 for i=0.75,0.83,0.002 do add(m2vx,cos(i)) add(m2vy,sin(i)) end
 for i=0.83,1.83,0.01 do add(m2vx,cos(i)) add(m2vy,sin(i)) end
 for i=0.83,0.9,0.002 do add(m2vx,cos(i)) add(m2vy,sin(i)) end
 for i=0.9,1.86,0.01 do add(m2vx,cos(i)) add(m2vy,sin(i)) end
 for i=0.86,0.99,0.0005 do add(m2vx,cos(i)) add(m2vy,sin(i)) end
--no 03
 m3vx={} m3vy={}
 for i=0.72,0.58,-0.003 do add(m3vx,cos(i)) add(m3vy,sin(i)) end
 for i=0.58,1.22,0.007 do add(m3vx,cos(i)) add(m3vy,sin(i)) end

--no 04
 m4vx={} m4vy={}
 for i=0.25,1.25,0.04 do add(m4vx,cos(i)) add(m4vy,sin(i)) end
 for k=0,500 do
     for i=0.25,0.75,0.01 do add(m4vx,-cos(i)) add(m4vy,sin(i)) end
     for i=0.75,0.25,-0.01 do add(m4vx,-cos(i)) add(m4vy,sin(i)) end
 end
 
--no 05
 m5vx={} m5vy={}
 for i=0,0.18,0.003 do add(m5vx,cos(i)*1.02) add(m5vy,sin(i)) end
 for i=0.18,1.25,0.01 do add(m5vx,cos(i)) add(m5vy,sin(i)) end
 for i=0,100 do add(m5vx,0) add(m5vy,-1) end

--no 06
 m6vx={} m6vy={}
 for i=0,80 do add(m6vx,cos(0.96)) add(m6vy,sin(0.96)) end
 for i=0.96,0.54,-0.02 do add(m6vx,cos(i)) add(m6vy,sin(i)) end
 for i=0,80 do add(m6vx,cos(0.54)) add(m6vy,sin(0.54)) end
 for i=0.54,0.96,0.02 do add(m6vx,cos(i)) add(m6vy,sin(i)) end
 for i=0,60 do add(m6vx,cos(0.96)) add(m6vy,sin(0.96)) end
 for i=0.96,1.5,0.006 do add(m6vx,cos(i)) add(m6vy,sin(i)) end

--no 07
 m7vx={} m7vy={}
 for i=1,0.75,-0.015 do add(m7vx,cos(i)) add(m7vy,sin(i)) end
 for j=0,1 do
  for i=0,30 do add(m7vx,0) add(m7vy,1) end
  for i=0.75,1.25,0.013 do add(m7vx,cos(i)) add(m7vy,sin(i)) end
  for i=0,30 do add(m7vx,0) add(m7vy,-1) end
  for i=1.25,0.75,-0.013 do add(m7vx,cos(i)) add(m7vy,sin(i)) end
 end
 for i=0,20 do add(m7vx,0) add(m7vy,1) end
 for i=0.75,0.2,-0.013 do add(m7vx,cos(i)) add(m7vy,sin(i)) end

 ttl_ini()

end