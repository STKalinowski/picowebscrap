--crowded dungeon crawler
--by bonevolt
cartdata"bonevolt_crowded_dungeon_crawler"
function a(b)
local c,d={},{}
b=split(b)
for f=1,#b do
local g=b[f]
if g=="|"then
add(d,c) c={}
else
g=({[g]=g,[""]=0,t=true,f=false,["{"]={}})[g]
if tonum(g) and type(g)~="boolean" then
g=tonum(g)
end
add(c,g)
end
end
if(#d>0) return d
return c
end
function i(j)
return unpack(a(j))
end
l=a"cls,pal,palt,camera,rectfill,spr,print,memcpy,reload,music,sspr,sfx,clip,poke,memset,run"
function m(n)
local c=a(n)
for f=1,#c do
_ENV[l[c[f][1]]](unpack(c[f],2))
end
end
p,q,r=a"1,3,|,2,3,|,3,6,|,5,1,|,4,1,|",a"1,1,5,13,6,13,5,|,1,1,2,2,4,4,2,|,2,2,8,14,15,14,8,|",a"1,2,5,13,5,|,2,15,10,9,4,|,2,11,3,5,4,|,12,7,6,13,5,|,2,9,4,5,,|"
s,t,u,v,w,x,y,z,ba,bb,bc,bd=i"shock,poison,arrow,fire,slash,smash,crush,ultra,bomb,arcane,freeze,key,|,2,2,2,8,8,14,15,8,8,8,8,8,8,14,15,|,1,1,1,13,13,6,7,12,12,6,12,12,13,12,6,|,1,1,1,1,2,8,9,10,7,7,7,|,f,f,f,shock,f,fire,f,fire,f,f,f,f,f,f,f,arcane,f,f,f,f,f,f,f,f,f,freeze,fire,fire,f,fire,f,shock,|,4,9,10,7,|,8,9,10,7,|,9,10,7,|,,,,,,,,,,,,,,,,1,1,|,|,|,|"
for f=1,#s do
local be=s[f]
bb[be]=a"3,15,|,45,45,|,7,7,|,8,12,|,6,6,|,6,6,|,6,6,|,6,6,|,45,45,|,14,15,|,6,600,|,0,0,|"[f]
bc[be]=a"1,2,1,2,1,2,3,3,1,2,0,1"[f]
bd[be]=a"f,f,f,f,f,f,f,f,f,f,f,f,2,f,f,f,f,f,f,f,f,f,f,f,2,1,f,f,f,f,1,1,2,2,f,f,|,f,f,f,f,2,f,f,2,2,2,2,2,2,f,2,f,2,f,f,2,2,2,2,f,2,f,f,f,f,f,f,f,2,2,f,f,|,f,f,f,f,f,f,f,f,f,f,f,f,2,f,f,2,f,f,f,f,f,f,f,f,2,1,f,f,f,f,f,f,2,2,f,f,|,f,f,f,1,f,1,1,f,f,f,f,f,2,f,f,f,f,f,f,f,f,f,f,f,2,f,f,f,f,f,1,f,2,2,f,f,|,f,f,f,f,f,f,f,f,f,f,f,f,2,f,f,2,f,f,f,f,f,f,f,f,2,1,f,f,f,f,f,f,2,2,f,f,|,f,f,f,f,f,f,f,f,f,f,f,f,2,f,f,2,f,f,f,f,f,f,f,f,2,f,f,f,f,f,f,f,2,2,f,f,|,f,f,f,f,f,f,f,f,f,f,f,f,2,f,f,2,f,f,f,f,f,f,f,f,2,f,f,f,f,f,f,f,2,2,f,f,|,f,f,f,f,f,f,f,f,f,f,f,f,2,f,f,f,f,f,f,f,f,f,f,f,2,f,f,f,f,f,f,f,2,2,f,f,|,|,f,f,f,f,f,f,f,f,f,f,f,f,2,f,f,f,f,f,f,f,f,f,f,f,2,f,f,f,f,f,1,f,2,2,f,f,|,f,f,f,f,f,f,f,f,f,f,f,f,2,f,f,f,f,f,f,f,f,f,f,f,2,f,f,f,f,f,1,f,2,2,f,f,|,2,2,2,2,2,2,2,2,2,2,2,2,f,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,f,f,|"[f]
end
bf,
bg,
bh,
bi,
bj=i"3,4,4,4,6,7,7,4,4,5,6,5,3,7,4,6,6,5,4,6,4,4,6,6,7,6,1,6,7,4,6,7,4,5,6,4,7,7,7,7,7,|,4,4,4,4,6,6,6,4,3,3,4,5,7,1,7,4,3,5,5,3,3,6,5,6,6,5,7,6,6,7,5,7,5,4,6,7,6,7,8,8,8,|,1,1,1,1,1,1,1,4,1,1,1,1,1,1,1,5,1,1,1,1,1,1,1,6,1,1,1,1,1,1,1,7,1,1,1,1,1,1,1,8,0x7fff,|,6,12,12,14,12,18,20,15,9,12,10,18,18,10,20,20,10,11,16,18,10,20,12,25,18,16,9,34,26,18,15,30,16,14,15,21,28,24,30,35,40,|,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,|"
bk=a"1,,103,3,,2,,3,,,2,3,1,,,1,,,,,|,,108,103,,,1,2,1,3,,2,2,2,1,,1,2,2,2,,3,1,2,3,,|,,102,103,,,3,2,3,3,,2,2,2,3,,3,2,2,2,,3,3,2,3,,|,3,2,4,4,4,3,2,1,2,3,3,2,1,2,3,4,4,4,2,3,102,104,3,,,|,4,9,4,105,3,16,16,9,8,8,8,8,8,16,4,9,,7,16,6,3,,,,,8,6,,,6,8,6,8,103,,,,6,8,6,,,,,,6,8,6,,|,106,104,2,1,2,,,2,,,,,,,,,3,4,4,4,4,4,,6,2,4,,9,23,4,,1,1,16,9,,9,4,,6,,16,23,9,,4,,,,16,16,16,4,4,,,|,9,9,9,105,105,9,9,9,9,,9,108,7,9,,9,9,9,9,9,9,9,9,9,3,3,,,,,,3,3,,3,,,,3,3,8,8,8,8,8,8,8,8,3,8,1014,,3,3,3,,|,,,,,,,,,,,,103,102,104,,,,,,,,,,,,|,7,7,9,9,,7,9,20,9,,7,9,9,9,,7,7,103,105,,,,,,|,24,24,24,24,24,,24,3,24,3,24,,24,24,24,24,24,,108,103,,,,,|,,9,,,,9,,9,16,9,,9,26,9,,16,,105,,26,,,,,,,,,2,104,2,,1,6034,,|,16,,,24,4,4,9,,,24,16,16,16,,16,16,26,26,16,,,24,24,,16,,,24,24,,13034,102,,24,24,,|,9,1,26,1,1,9,1,26,3,3,3,3,3,3,3,3,2,1,2,1,1,2,1,2,2,26,9,108,26,2,107,,|,9,9,9,3,3,2,9014,108,3,9,2,9,9,3,5013,,|,,2,3,,,110,2,9,,,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,,,9,2,,103,,3,2,,|,,,,,,,,,103,,,,105,,,,,102,,,,,106,,,,104,,,,,,,,,|,108,3,,,2,17,2,1,,,1,,26,,1,,,,,,,2,17,2,3,,3,,|,103,,18,,,16,102,,18,,,,,,18,,17,,,,18,,2,,3,,18,,2,,2,,18,,1,,|,27,27,27,27,108,27,3,27,3,27,27,27,27,27,,27,3,27,3,,27,27,,,,27,3,,,,|,8,26,30,3,30,26,30,26,8,26,30,26,30,26,,26,30,2,30,26,,,,8,30,105,103,,|,9,3,9,,26,3,23,3,,,9,3,9,,9,26,108,114,3,,|,30,30,3,30,30,9,9,3,9,9,9,30,4,30,9,9,4,4,4,9,30,30,4,30,30,,4,3,4,,,114,119,111,,|,27,26,,,27,,1,,4,27,8,,4,27,27,4,,4,27,4,,,,27,4,,16,27,27,4,,4,27,4,,114,4,101,24,115,4,,|,,,,,,,,,,,,,,,,108,,,,107,,,,,119,,,,,110,,,,111,,,,,,,,,,,,,,,,|,6,6,31,,19034,6,6,6,6,6,4,7,4,6,6,6,6,6,,14014,31,6,6,6,,,4,3,4,,,,,,4,3,4,,,,31,,31,104,31,119,31,,31,,31,,31,102,,,|,4,4,16,4,4,20,4,31,4,16,4,4,18,4,,16,18,,,20,4,26,,16,31,4,20,4,,,,4,4,4,,26,,,115,108,120,,|,9,9,9,16,31,9,9,3,16,3,9,4,115,103,120,,|,2,2,26,26,26,3,3,26,26,2,31,2,26,26,2,2,31,2,31,3,3,18,,26,3,26,,31,18,18,,26,,31,31,18,18,18,26,31,31,31,,108,18,119,31,122,,|,16,16,16,,,16,16,16,1,9,9,,,9,9,1,1,9,9,,,9,9,16,16,16,16,,,1,1,1,2,2,2,,,16,16,16,4,4,4,111,,9,9,9,1,1,1,111,122,119,118,,|,31,16,31,16,31,16,26,16,31,16,31,16,31,16,31,16,31,16,26,16,31,16,31,16,31,16,31,16,,,2,,,,2,1014,123,2,103,,|,16,26,16,,,,,4,9,4,,,2,,2,2,2,,,,,4,4,4,,,,,4,4,4,,,9,2,,111,102,119,122,118,,|,,,,,,,,,,,,,,,,,,,108,,,122,,,,,,,,,,,,,,,,,,,,,115,,,118,,,,,,,,,,,,,,,,,,,|,32,32,3,108,,17,2,3,2,1,32,2,2,2,,32,2,2,2,,17,2,2,2,1,32,32,2,120,,|,9,16,9,,,6,7,1,7,9,16,9,9,16,9,7,1,7,6,,,9,16,9,,,116,105,120,,|,2,2,2,32,2,2,2,1,,,2,,,1,,,,1,,,,,26,26,1,26,26,,,32,32,1,32,32,,,1,,,,1,,,,102,122,104,,,|,32,,32,,32,,32,,32,,16,32,16,32,16,9,9,9,9,9,16,32,16,32,16,,32,,32,,32,,32,,32,2,108,122,121,,|,7,7,7,,32,32,32,,,,,26,26,26,,,104,9,,26,23,,,7,122,9,,26,,32,23,26,102,9,,26,23,,,7,,,,26,26,26,,,7,7,7,,32,32,32,,|,9,18,18,32,32,9,16,16,18,9,18,,,16,9,16,18,18,9,,,16,16,9,,,9,9,32,32,,,9,,32,9,9,32,,9,,,32,32,9,9,,,16,,,116,117,,,18,,,16,107,,18,,,|,7,,,18,18,,,7,7,,,7,7,,,7,7,,,18,18,,,7,,9,32,32,32,32,9,,32,32,32,7,7,32,32,32,,16,2,18,18,23,,,,16,2,18,23,18,,,16,2,2,23,18,18,,,,16,,,120,106,123,,|,,,,,,,,,,,,,,,,,,,121,,,122,,,,,,,,,,,,115,,,,,107,,,,,,,,,,,,104,,,106,,,,,,,,,,,,,,,,,,,,,,,,,,,,|,,101,,,129,,,,,,,,,,,,,,,,,,,,,127,,,112,,,,,,,,,,,,,,,,,,,,,128,,,131,,,,,,,,,,,,,,,,,,,,|"
bl,bm,bn,bo,bp,bq=a"45,,13,7,1,8,|,16,,15,7,1,8,|,16,7,15,11,1,4,|,91,,10,6,4,9,|,70,46,11,11,3,4,|,45,16,13,8,3,7,|,,8,16,10,1,5,|,,18,16,15,1,,|,,33,16,9,1,6,|,,33,16,9,1,6,|,,33,16,9,1,6,|,31,42,14,14,2,1,|,31,30,14,12,2,2,|,110,8,6,3,6,12,|,31,18,14,12,2,3,|,,,,,,,|,81,20,10,4,3,11,|,110,43,6,7,8,8,|,110,43,6,7,8,8,|,,42,16,13,1,3,|,,42,16,13,1,3,|,,42,16,13,1,3,|,58,10,12,15,2,1,|,70,57,11,6,3,10,|,16,32,15,8,1,8,|,81,34,20,11,-2,6,|,,,,,,,|,,,,,,,|,28,70,10,5,5,10,|,,31,16,2,1,12,|,,69,15,6,1,9,|,16,39,14,15,2,,|,16,54,14,15,2,,|,31,30,14,12,2,2,|,110,8,6,3,6,12,|,76,72,16,13,1,2,|",a"70,20,11,10,3,2,|,70,,11,10,3,2,|,70,10,11,10,4,2,|,45,7,13,9,2,1,|,|,58,,12,10,1,2,|,45,24,13,11,2,-1,|,|,31,,14,6,,,|,31,6,14,6,,,|,31,12,14,6,,,|,|,|,16,18,15,14,1,,|,|,45,35,13,14,2,-1,|,45,49,13,11,2,2,|,31,56,14,14,,1,|,45,60,13,12,1,3,|,|,102,36,8,8,2,3,|,102,44,8,8,2,3,|,|,,55,16,14,1,2,|,|,58,65,17,11,-1,-1,|,58,25,12,16,2,,|,113,67,14,18,2,-3,|,94,73,19,12,-2,,|,,18,16,13,,,|,84,60,15,9,,,|,58,41,12,12,1,-1,|,58,53,12,12,1,-1,|,|,16,18,15,14,1,,|,99,60,13,13,2,-6,|",a"110,,8,8,2,2,|,101,,9,9,1,1,|,101,9,9,9,1,,|,81,,10,11,,,|,91,6,10,9,,,|,110,11,7,8,2,1,|,110,19,7,8,2,2,|,101,18,9,9,1,,|,81,11,10,9,1,,|,110,11,7,8,2,1,|,110,11,7,8,2,1,|,91,15,10,9,,,|,70,39,11,7,,1,|,112,60,7,7,1,2,|,102,52,8,8,2,1,|,101,27,9,9,,1,|,81,24,10,10,,,|,110,50,6,10,2,,|,91,24,10,10,,,|,95,45,6,14,2,-3,|,75,63,9,9,1,,|,54,76,13,7,-1,,|,15,69,13,6,-1,2,|,110,11,7,8,2,1,|,75,63,9,9,1,,|,72,96,8,8,1,1,|,81,,10,11,,,|,101,18,9,9,1,,|,110,27,7,12,2,,|,118,85,8,9,2,1,|,110,27,7,12,2,,|",a"|,|,|,|,|,|,|,|,|,1,1,2,4,5,6,7,8,9,10,8,|,1,2,1,4,5,6,7,8,9,10,12,|,|,|,|,|,|,|,|,|,|,|,|,|,1,,1,4,5,6,7,8,9,10,2,|,1,12,3,6,|,|,1,2,9,4,5,6,7,8,9,10,10,12,4,|,4,2,3,4,9,15,7,8,9,10,11,12,10,|,|,|,1,2,3,4,5,6,7,3,9,10,11,12,13,11,10,|",a"54,24,|,55,24,|,56,16,|,56,16,16,|,57,8,|,57,4,8,|,57,12,12,|,57,8,24,|,58,nil,7,|,59,9,|,59,19,9,|,59,12,28,|,60,20,|,60,12,20,|,62,16,|,62,10,16,|,62,6,26,|,63,|,58,5,|,58,2,5,|,61,|,54,8,24,|,55,4,28,|",a"1,2,3,|,27,14,22,|,28,19,7,|,29,30,2,19,22,|,12,16,18,|,31,30,5,10,11,|"
br,bs,bt,bu,bv,bw,bx,by,bz,ca,cb,cc,cd,ce,cf,cg,ch,ci,cj,ck,cl,cm,cn,co,cp,cq,cr,cs,ct,cu,cv,cw,cx,cy=i"20,22,26,24,,20,30,,,,,,,22,,15,23,25,20,,,,,28,,30,4,6,17,28,36,27,25,,22,34,|,f,f,f,t,,t,f,,,,,,,t,f,f,f,f,f,,,,,f,,f,f,f,f,t,f,f,f,,t,f,|,15,15,15,15,15,15,15,15,15,15,15,,15,9,15,,,3,3,,,,,3,,3,3,3,3,15,,3,3,15,9,,|,,3,,3,2,,,,,,,1,1,,1,2,5,8,8,1,1,1,3,1,8,,8,6,4,,3,4,,1,,,|,2,4,3,2,,3,5,,8,,,,,,,5,-3,6,,,,,-4,3,,5,2,,,4,6,6,,,,,|,1,1,2,1,,1,2,,1,1,1,,,,,1,3,2,1,,,,,1,,2,2,5,3,3,1,2,2,,,2,|,1,1,1,1,,1,2,,4,4,4,,10,,,3,3,2,2,,,,,2,2,5,1,2,5,5,2,2,2,10,,10,|,,1,,,,,,,10,11,,,,,,,,19,,21,22,,,,,,,,,29,,,,,,,|,f,f,t,f,f,f,f,t,f,f,f,t,f,t,t,t,t,f,f,t,f,f,t,f,f,f,f,t,f,t,f,|,,3,,,,,,,,,-4,,,,,,1,4,3,,3,2,,-9,3,-2,,,1,,1,|,,,,,,,,,,9,,,,,,,,,,,,,,9,,5,,,,,,|,1,,,1,1,1,1,,1,1,1,1,1,,,1,,1,,,,,,1,,1,1,,,,,|,,1,4,,,,,3,,,,7,,7,8,9,10,11,2,12,14,15,13,,,,,3,,7,,|,17,,,14,17,5,16,,6,7,7,,8,,,,,,,,,,,7,8,7,14,,8,,5,|,,16,2,2,,2,,1,,,,,16,,2,2,2,20,2,2,16,16,2,,20,,2,1,2,,,|,,1,2,3,,4,,,,,,,7,,5,2,,6,,1,3,6,6,,3,,7,,3,,,|,f,shock,slash,arrow,f,poison,smash,slash,key,f,f,smash,arcane,crush,fire,ultra,smash,arcane,fire,shock,smash,freeze,arcane,f,freeze,f,arrow,smash,arcane,slash,poison,|,4,1,1,5,2,2,10,1,1,1,1,10,3,1,1,20,1,3,1,1,1,1,1,1,1,1,7,1,1,1,1,|,8,1,1,12,5,5,20,1,1,1,1,10,3,1,1,40,1,5,1,1,1,1,1,1,1,9,12,1,1,1,1,|,50,15,10,30,25,35,20,15,25,30,30,75,2,50,20,15,100,30,30,15,120,30,30,1,3,,,,,,|,1,11,2,19,20,21,17,8,22,24,25,10,18,3,4,7,9,16,12,5,13,14,6,24,15,26,,,,,,|,1,,,,,,,,,,,5,,,,,,,,,,,,,,,2,3,4,,6,|,,,,,,,,,,,,25,,,,,,,,,,,,,,,5,10,15,,35,|,5,,9,,,,|,1,1,1,2,1,1,|,1,1,1,1,.6666,1,|,2,.25,.5,.5,.5,.5,3,1,|,7,7,11,10,8,12,14,6,|,15,10,3,9,8,12,8,12,|,15,3,7,15,20,10,7,7,7,15,25,15,15,20,20,|,18,15,16,13,10,12,14,13,13,16,3,13,13,2,1,|,,,7,7,,,7,9,12,7,,10,14,|,,,6,6,,,6,14,11,12,,9,8,|,,,,,,,,|"
cz,da,db,cy[0],dc=max(dget"7",1),i"0,1,0,0"
function dd()
local de=df.dg
if dh(df) then
local di=dj[dk][dl]
local dm=di.dn
if de==1 then
if dp and not dm then
dp.dq,dp.dr,dp.ds,dp.dt,di.dn,dj[dp.dq][dp.dr].dn=dk,dl,dk*15,dl*11,dp
du[1].dv-=1
end
if not dm or dm and(not dw(dm.dg,i"8,16,20,21,22,25,30") or dx.dy.freeze) then
dp=not dp and dx or ea()
end
end
if ce[de]>0 then
eb(ce[de])
end
ec-=ca[de]
ed(dk,dl,cd[de])
ee(dk,dl,de==5 and 5)
if cb[de]>0 then
ef,eg=ceil(ef+cb[de]),0
end
ec,ef=min(ec,9),min(ef,9)
local ei,poison,ek=i"0,0,0"
if ch[de] then
foreach(el,
function(self)
local em,en=eo(self,
ch[de],false,dw(de,18,21,22) and-16 or 1)
ek+=min(1,max(em,en))
if em and em>ei then
ei=em
end
if en and en>poison then
poison=en
end
end)
end
if(#el>0 or dw(de,5,10,11,24,26) or de==12 and not di.ep) and de>1 then
eq()
er(df)
end
if bz[de] then
if es then
ei,poison=0,0
er(es,ek)
end
eg+=max(0,poison-ei)
ef=max(ef-ei,0)
end
if de==12 and not dm and not di.ep then
et(10,eu,ev,1)
if rnd()<.12 then
ew((ex)[ey(#ex)],dk,dl)
end
end
end
ez()
end
function _init()
m"14,0x5f2d,1,|"
fa,fb,fc,fd,fe,ff,fg,fh=fi,fj,i",t,t,{,0,t,"
end
function fk()
fb,fa=fl,fm
end
function fn()
fo,fp,fb,fa=fq%10000+fr%100*100,fq\10000+fr\100,fs,ft
end
function fu()
m"12,58,-2,|,12,61,-2,|"
reload()
while(peek(0x5e30+cz)==1 or cz%8==0 and cz<dget"7") cz+=1
fv,fw,fx,fy=cz==41,da>0,da,cz
fz,ga,fb,fa,gb,gc,fg,gd,ge,gf,dn,gg,fc,gh,fh,gi,gj,gk,gl,gm,gn,go=not fw,(da-1)\5*5,gp,gq,gr,co[db],i",,90,{,{,{,-10"
gs,gt=fz and fv
gu,gr,gv=min(30,10+ga),bj[cz] or gs and 1 or gw,fu
if da%3==0 then
repeat
gw=bj[cz] or ey"5"
until gr~=gw or fz or not fv
end
if fz then
gx,ef,eg,ec,gy,gz,fq,fr,du=i"-30,9,0,8,1,0,0,0,{"
add(du,ew(1))
du[1].dv=0
else
du[1].dv=ci[du[1].dg]\cq[db]
end
gx+=5
ha,hb,gz=bf[cz],bg[cz],fw and 900 or 1
ez()
ex,dj,hc,hd,he,hf,dk,dl=i"{,{,{,{,,,,"
if fv then
hg,hh=a"1,2,3,4,6,9,16,18,27,32,|,1,2,3,4,6,9,16,24,26,32,|,1,2,3,4,9,16,18,24,26,27,|,1,2,3,4,6,9,16,18,26,31,32,|,1,2,3,7,9,16,18,26,27,32,|"[gr],a"17,23,|,8,20,23,|,8,17,20,30,|,20,23,|,17,23,|"[gr]
hi,hj,hk=i"4,5,6,10,11,|,2,3,7,8,14,15,16,17,18,19,20,21,22,23,|,13,24,25,|"
else
hg,hh,hi,hj=a"1,2,3,4,6,9,16,|,1,2,3,4,6,9,16,24,26,|,1,2,3,4,9,16,18,24,26,27,|,1,2,3,4,6,9,16,18,26,31,|,1,2,3,7,9,16,18,26,27,32,|"[gr],a"23,|,8,20,23,|,8,17,20,30,|,20,23,|,17,23,|"[gr],a"4,5,6,|,4,5,6,10,|,4,5,6,10,11,|,4,5,6,10,11,|,4,5,6,10,11,|"[gr],a"2,3,8,|,2,3,7,8,|,2,3,7,8,14,15,19,|,2,3,7,8,14,15,18,19,20,22,23,|,2,3,7,8,14,15,16,17,18,19,20,21,22,23,|"[gr]
end
repeat
hl,hm=cz<40 and a"12,15"or db==6 and a"12,12,12,15"or a"12,12,15",cz<12 or hn()
add(hl,hm and 13 or 34)
add(hl,(not fv or rnd()<.75) and 14 or 35)
if(da>=15) add(hl,36)
ho,hp,hq=i",{,{"
while#hq<4 do
local hr=ey(#hg)
if not hp[hr] then
add(hq,hg[hr])
hp[hr]=true
end
end
for f=1,rnd"6"+(dw(gr,2,3) and 6 or 0) do
local dg=hh[ey(#hh)]
ho+=bv[add(hl,dg) or 0]
end
hs=((ha+1)*(hb+1)-1)
while#hl<hs do
local dg=hq[ey"4"]
ho+=bv[add(hl,dg)]
end
until abs(ho-(hs*3-16)-min(100,da*5))<=25 or fz
ht={dq=ey(ha),dr=ey(hb)}
hu(ex,hi)
hu(ex,hj)
for f=0,ha do
dj[f]={}
for hv=0,hb do
dj[f][hv]={}
if fw then
hw(f,hv)
else
hx(f,hv)
end
dj[f][hv].hy=hn() and p[gr][1] or p[gr][2]
end
end
if fw and hm then
local hz
repeat
hz=dj[flr(rnd(ha+1))][flr(rnd(hb+1))].dn
until hz and bw[hz.dg]>0 and not dw(hz.dg,27,36)
hz.ia=true
end
ib=min(bi[cz]+(fv and min(20,ga) or 0),fw and hf\1.15 or hf)
ic()
id()
if(gb~=gr or stat"16"==-1) music(a"0,14,23,44,30"[gr])
gp()
end
function hw(f,hv)
if f~=ht.dq or hv~=ht.dr then
repeat
local hr,ie=ey(#hl)
if not dw(hl[hr],14,35) or hv>1 then
ie=del(hl,ee(f,hv,hl[hr]).dg)
end
until ie
end
end
function hx(f,hv)
local c=bk[cz][f+hv*(ha+1)+1]
if c%1000>100 then
ew(c%100,f,hv)
else
local ig=ee(f,hv,c%100)
dj[f][hv].dn=ig
if(c>1000) ig.ep=ew(c\1000)
end
ht.dq,ht.dr=bf[cz],bg[cz]
end
function ih()
da=0
fu()
end
menuitem(3,"clear progress",function() m"15,0x5e1c,0,100,|,16,|"end)
menuitem(4,"clear score",function() m"15,0x5e04,0,24,|"end)
function ee(dq,dr,dg)
if dg and dg>0 then
local ig=add(dn,{
dg=dg,
dy={},
dq=dq,
dr=dr,
ds=dq*15,
dt=dr*11,
ii=rnd"100",
ij=0
})
if(dg==5) eo(ig,"bomb")
dj[dq][dr].dn=ig
if(bw[dg]>0 and dg~=36) hf+=(dg==26 and 2 or 1)
local ik=dg==14 and ex or dg==35 and hk or dw(dg,12,13,34) and hi or dg==15 and hj
ig.ep=ik and ew(ik[ey(#ik)])
if dg==27 then
add(gg,ig)
end
if dg==34 then
gt=ig
end
return ig
end
end
function ew(dg,dq,dr)
il=dg
if not dq or not dj[dq][dr].ep then
local ep={
dg=dg,
dq=dq,
dr=dr,
dv=ci[dg]\cq[db],
im=cj[dg]\cq[db],
io=ck[dg],
}
if dq then
local c=dj[dq][dr]
c.ep=ep
if(c.dn) c.dn=nil
end
return ep
end
end
function eo(ip,iq,ir,is)
for it in all(s) do
if ip.dy[it] and it~="freeze"and it~="poison"then
iu(ip,it,9999)
end
end
local iv
for ig in all(dn) do
if ig==ip then
iv=true
end
end
if not iv then
return
end
local ei=(ip.dy.freeze or iq=="fire"and ip.dg==30) and 0 or bw[ip.dg]
ip.ij=0
if not hd[iq] then
hd[iq]={}
end
if not ip.dy[iq] then
ip.dy[iq]=is or 1
add(hd[iq],ip)
end
if dw(ip.dg,17,27,28) then
return 0,ei
end
return ei,0
end
function iw(be,ig,c,dr,dq)
et(be,ig.ds+(dq or 0),ig.dt+(dr or 0),c)
end
function et(be,dq,dr,c)
for f=0,be do
add(gf,
{
c=c,
dq=dq+(c==2 and 4 or dw(c,3,4) and rnd"16"or 8),
dr=dr+(c==2 and 5 or dw(c,3,4) and rnd"16"or 8),
ix=c==5 and .75 or rnd(),
fg=fg,
iy=rnd()+cr[c]
}
)
end
end
function ed(dq,dr,c,g)
if c>0 then
if(stat"17"~=58 and(c~=5 or stat"17"<54)) eb(cv[c])
return add(hc,
{
c=c,
dq=dq*15,
dr=dr*11,
fg=0,
g=g
}
)
end
end
function _update()
if(dc>0) dc-=.5
fg+=1
for f=0,7 do
cy[f]=iz(f) and cy[f]+1 or 0
end
ja,jb,jc=dw(1,cy[4],cy[6]),fg\2%2,fg%5+8
jd,je,jf=jb+1,jb+9,jb*6+8
if fc~=0 then
fc+=1
else
fb()
end
if fc>20 then
gv()
fc=-15
end
end
function fj()
if ja then
if fg<90 then
fg=89
else
gv,fc=fk,1
end
end
end
function fl()
if ja then
gv,fc=fu,1
jg=a[[■right click to grab item
 ■left click to use item
■right click to exit room,15,86,7
,|,  ■z/x (🅾️/❎) to swap items
 ■can't attack enemies if hp=0
     ■each weapon affects a
        different area
,1,80,7
,|,    ■magic items use mana
   but you take no damage!,8,88,7
,|,  ■arrow is a consumable item
   ■it hits 3 random enemies
■water elementals are immune to
  fire but spread electricity
,2,80,7
,|,  ■imps get stonger with fire
■ghosts are immune to physical,4,93,7,
,|,■poison spreads to same type
   ■barrels are explosive!,8,91,7
,|,  ■golems give lots of coins
■use the glove to move enemies!,3,91,7
,|,■the last level of each world
is a sequence of random levels
 ■there's a time limit! hurry!,4,86,7
,|,■rocks can be destroyed,16,88,7
,|,■moles hide when targeted
        directly,14,84,7
,|,   ■ogres are immune to low
      damaging weapons
 ■defeat enemies to open the
         combo chest,8,78,7
,|,■lamp hits all of the same type
  ■ghosts spread magic damage,2,88,7
,|,■shield prevents damage but
costs 1 for each enemy hit,12,93,7
,|,|,
■red potion restores health,12,92,7
,|,|,■mushroom poisons neighbors
 when killed. but it also
  poisons you! be quick!,12,82,7
,|,■slimes get weaker when hit
 but they grow back after
        a while!,12,85,7
,|,      ■bees poison you
■if the queen is killed a new
       bee turns queen
 ■the last queen drops honey!,8,80,7
,|, ■some bushes have bandits!
 ■if it's moving there's a
       bandit hidden!
   ■use fire before they
        ambush you!,8,72,7
,|,■dagger hits 1 tile
   for 3 damage!,25,85,7
,|,■blue potion recovers 4 mana!,6,96,7
,|,■bees spread fire,26,95,7
,|,
,|,■yetis are immune to elements
 ■demons give more gold than
      imps. farm them!,6,87,7
,|,■rocks can be helpful
      sometimes,23,91,7
,|,
,|,■frozen enemies can't attack
    ■ogre spreads freeze,8,92,7
,|,■frozen enemies have no 
      immunities,18,92,7
,|,
,|,
,|,
,|,  ■lightning makes revenants
 invincible for a few seconds,4,92,7
,|,  ■crystal sword ignores all
immunities and deals 3 damage!,4,89,7
,|,■frozen revenants can't turn
        invincible!,8,91,7
,|,■quake deals physical damage
    to 10 random enemies!,8,93,7
,|,■demons die after freezing
     if you wait a bit,12,92,7
,|,■magic mace costs hp and mana,6,99,7
,|,
,|,
,|,
,|,
]]
if(btnp"4") jh,fd=a"❎/x to grab item\n🅾️/z to use item,30,89,7,|,      ■x/❎ to swap items\n ■can't attack enemies if hp=0\n     ■each weapon affects a\n        different area,1,80,7,|"
end
end
function fs()
if fp>dget(db)
or fp==dget(db)
and fo>dget(db+56) then
dset(db,fp)
dset(db+56,fo)
gi=db
end
if cy[4]==1 then
gv,da,fc=fu,0,1
end
end
function gp()
menuitem(1,"disable hints",function() fe=false end)
menuitem(2,"replay puzzles",function() cz=1 ih() end)
ji,jj,jk,jl=stat"31",ha*7.5-55,a"-24,-18,-24,-18,-10,-8,-8,-24,-28,-24,-14,-12,0,-36,-4,-24,-28,-12,-8,-20,-28,-12,-20,-16,-4,-20,-10,-8,-8,-10,-20,-10,-20,-24,-8,0,-8,-6,-6,-6,-6"[cz],db==6 and 9 or 8
if(ji=="r") ih()
if(ji=="t"and cz<=40) cz=41 ih()
if(fq>=30100) fq-=100 fr+=1
if fd then
jm,jn=stat"32",stat"33"
dk,dl=(jm+jj-1)\15,(jn+jk)\11
else
if(btnp"0") dk-=1
if(btnp"1") dk+=1
if(btnp"2") dl-=1
if(btnp"3") dl+=1
end
dk,dl=mid(0,dk,ha),mid(0,dl,hb)
eu,ev=dk*15,dl*11
if fd then
jo,jp=jm-11.5+jj,jn-7+jk
else
jo,jp=eu,ev
end
if gh then
if gz>20 and fw then
gz-=20
if(fg%10==0) eb"23"
ec=min(ec+.1*cp[db],9)
elseif gc>0 and fw and(ef<9 or eg>0) then
if(gc%1==0) eb"22"
gc-=0x.2
ef+=0x.2
if ef>9 then
eg-=ef-9
ef=min(9,ef)
end
else
fc=1
da+=1
if da>=bh[cz] then
da=0
cz+=1
dset(7,max(cz,dget"7"))
end
end
elseif not gl then
if ge<=0 then
local jq=min(ceil(da/2),20)
gz-=.5*jq
ec+=.0025*jq*cp[db]
gd=0
elseif fw or ge>1 then
ge-=.5
end
if gm then
gm=gm>0 and gm-1
else
if gz<=100 and ge<=30 and fw then
eb"20"
gm=60
end
end
if eg>0 then
if ef>0 then
ef-=.01
else
ef=0
end
eg-=.01
end
if jr then
jr=jr>0 and jr-1
end
eg,ef,ec=max(eg,0),max(ef,0),min(ec,9)
js=dj[dk][dl]
dx=js.dn
if cy[7]==1 then
if not dp then
local jt=js.ep
if jt then
gj=he>=ib
if gs then
if cm[jt.dg]>0 and $0x5e20>=cn[jt.dg] then
db,du=cm[jt.dg],{}
for f=1,#bq[db] do
add(du,ew(bq[db][f]))
end
else
gj=false
end
else
local ju,jv=jw(jt.dg)
if ju and not dw(ju.dg,i"9,10,11,24") then
ju.dv+=jt.dv
if ju.dv<=ju.im or cc[ju.dg]==0 then
js.ep=nil
if cc[ju.dg]==0 then
for be=1,10 do
ed(dk,dl,5)
fq+=1
end
end
else
local jx=ju.dv-ju.im
ju.dv-=jx
jt.dv=jx
end
gy=jv
else
if#du==jl and gy>1 then
js.ep,du[gy]=df,jt
elseif#du<jl then
add(du,jt)
gy,js.ep=#du
else
ez"1"
end
ic()
end
end
ez()
elseif dk==ht.dq
and dl==ht.dr
and gj then
gh=true
eb"11"
elseif dx and dw(dx.dg,14,35) then
local io=dx.ep.io
if io>10 and fq>=io or io<10 and fr>=io then
eq()
if io>10 then
fq-=io
else
fr-=io
end
eb"6"
ew(dx.ep.dg,dk,dl)
jy(dx,"smash")
end
elseif not fd then
ez"1"
elseif du[1].dv>0 and du[1].dg==1 then
jz,gy=gy,1
ez()
dd()
end
else
ea()
end
end
if not dp and fd then
if cy[6]==1 then
ez"-1"
elseif cy[5]==1 then
ez"1"
end
end
for ig in all(dn) do
if dw(ig.dg,19,33) then
ig.ij+=1
if ig.ij>240 then
ig.dg-=1
iw(10,ig,4,-4)
end
end
if ig.dq==dk and ig.dr==dl then
if ig.dg==24 and not ig.dy.freeze and ig~=dp then
ig.dg=25
iw(5,ig,1,3)
end
elseif ig.dg==25 then
ig.dg=24
end
end
dx=dj[dk][dl].dn
el=ka(cg[df.dg],cf[df.dg],dk,dl,ch[df.dg])
es=jw(7)
ei,ek=kb(el,df.dg)
if(cy[4]==1 and not gs) dd()
if cy[4]>20 and ca[df.dg]>0 and gz>20 and fg%2==0 then
gz-=20
jr,ec,ge=6,min(ec+.1*cp[db],9),max(5,ge)
for f=1,5 do
ed(jo/15+rnd"2"+.7,jp/11+rnd"2"+.5,6)
end
if ec>=ca[df.dg] then
cy[4]=0
end
end
if dp then
kc=(not dx or dx==dp) and 3 or 8
else
kd,ke=true
local kf=cg[df.dg]
local el=ka(kf,cf[df.dg],dk,dl,ch[df.dg])
foreach(el,
function(ig)
if dw(kf,3,7)
and(ig.dq~=dk or ig.dr~=dl)
then
if not dw(df.dg,21,25) then
ig.kg=2
end
else
ig.kg=1
end
end
)
if bz[df.dg] then
kh,ek,ke=kb(el,df.dg)
if(ke) ke.kg=3
end
kd=nil
end
end
for it in all(s) do
for ig in all(hd[it]) do
iu(ig,it,1)
end
end
if gd>=gu and gt then
jy(gt,"smash")
gt=nil
end
for ki in all(gf) do
ki.iy*=.9
ki.dq+=sin(ki.ix)*ki.iy*(ki.c==5 and 4 or 1)
ki.dr+=cos(ki.ix)*ki.iy
ki.dr-=(ki.c==2 and .25 or ki.c==4 and 1 or 0)
if(ki.iy<.3) del(gf,ki)
end
for kj in all(hc) do
kj.fg+=1
if(kj.fg>=cu[kj.c]) del(hc,kj)
if kj.c==5 then
kj.kk,kj.kl,kj.spr,kj.fg=(kj.kk or km"1"),(kj.kl or rnd"1"-2.5)+.2,((kj.spr or rnd"4"\1)+1)%8,kj.fg>1 and kj.fg or rnd"8"+2
kj.dq+=kj.kk
kj.dr+=kj.kl
elseif kj.c==6 then
kj.kk,kj.kl=(kj.kk or km"1"),(kj.kl or km"1")
kj.kk+=kj.dq>jo+25 and-1.25 or 1.25
kj.kl+=kj.dr>jp+17 and-0.875 or 0.875
kj.dq+=kj.kk
kj.dr+=kj.kl
end
end
if go then
go=go>0 and go-1
kn-=0.16
end
if gn then
gn=gn>0 and gn-1
ko-=0x.3
end
if gz<=0 then
if(stat"17"~=61) eb"9"
music"-1"
gv,fc=fn,1
else
if gk then
if(not gn) gz-=20
if(gl and stat"17"==-1) eb"21"
else
if gl then
m"10,-1,500,|"
if kp<kq then
kp+=.5
else
kq/=1.5
ed(gl.dq-2+ey"3",gl.dr-2+ey"3",2)
dc,kp=2,0
if kq<=.01 then
kr(gl)
fq*=2
fr*=2
gk=true
end
end
end
end
end
end
function ks(g,f,hv,dq,dr,kt)
local ku=dq-f
return({
[0]=true,
f==dq,
ku==dr-hv,
true,
ku==0 or dr-hv==0,
ku==hv-dr,
hv==dr or hv==dr+1 and kt>=20,
true
})[g]
end
function ka(kf,kv,dq,dr,dg)
local kw,kx={}
local ky,kz=la(dq,kv)
local lb,lc=la(dr,kv)
for f=max(0,ky),min(ha,kz) do
for hv=max(0,lb),min(hb,lc) do
if ks(kf,f,hv,dq,dr,kv) then
local ld=dj[f][hv].dn
if ld and ld~=dp and
(ld.dg==25 and df.dg==12 or
(not(bd[dg] and bd[dg][ld.dg]==2) or ld.dy.freeze)) then
add(kw,ld)
end
end
end
end
if not kd and kf==3 then
while#kw>kv/2+2 do
local le=kw[ey(#kw)]
if(le.dq~=dq or le.dr~=dr) then
del(kw,le)
end
end
end
if kf==7 then
for ig in all(kw) do
local lf=dj[dq][dr].dn
if not lf or ig.dg~=lf.dg and not lg(ig.dg,lf.dg,18,19) and not lg(ig.dg,lf.dg,9,10,11) then
del(kw,ig)
end
end
end
return kw,kx
end
function la(be,kv)
lh=be-kv\2
return lh,lh+kv
end
function li(dq,dr,dg)
foreach
(
ka(4,2,dq,dr,dg)
,
function(ip)
local lj,lk=dj[dq][dr].dn.dg,ip.dg
if(w[lk] and dg==w[lk] or
(dg=="poison"and(lk==lj
or lg(lk,lj,18,19)))
) and
not ip.dy[dg] then
eo(ip,dg)
end
end
)
end
function jy(ig,ll)
iw(10,ig,1)
local dg,ei,dq,dr=ig.dg,ig.dy.freeze and 3 or bc[ll],ig.dq,ig.dr
if dg==36 and ei<gx then
gx-=ei
else
for f=1,dg==30 and ll~="fire"and 1 or ei do
if by[dg]>0 then
ig.dg=by[dg]
dg=ig.dg
else
if(dj[dq][dr].dn==dp) ea()
for be=1,bx[dg] do
ed(dq,dr,5)
fq+=1
end
if bw[dg]>0 or dg==25 then
he+=(dg==26 and 2 or dg==36 and 0 or 1)
local lm=gj
gj=he>=ib
if(gj and not lm) eb"19"
if he==hf and dg~=36
then
kr(ig)
if(fz and peek(0x5e30+cz)==0) dset(8,$0x5e20+1) poke(0x5e30+cz,1)
end
gd+=1
if gd>1 then
go,ln,kn=30,ig.ds,ig.dt
end
end
for lo in all(s) do
ig.dy[lo]=nil
del(hd[lo],ig)
end
if dg==17 then
foreach(
ka(4,2,dq,dr,"poison"),
function(self)
eo(self,"poison")
end)
end
if(ig.ep and not dw(dg,14,35)) ew(ig.ep.dg,dq,dr)
if(ig.ia) ew(9,dq,dr)
if dw(dg,27,28) then
del(gg,ig)
end
if dg==28 then
if#gg<=0 then
ew(26,dq,dr)
else
id()
end
end
if dg==36 then
gl,kp,kq=ig,0,30
else
dj[dq][dr].dn=nil
del(dn,ig)
end
break
end
end
end
ig.dy[ll],ig.dy.freeze=nil
del(hd.freeze,ig)
end
function kr(ig)
eb"4"
fr+=1
gn,lp,ko=70,ig.ds,ig.dt
end
function ez(f)
gy=(gy-1+(f or 0))%#du+1
df=du[gy]
f=f or 1
end
function jw(c)
for f=1,#du do
if du[f].dg==c then
return du[f],f
end
end
end
function hu(c,lq)
for lr,kj in pairs(lq) do
add(c,kj)
end
end
function ic()
repeat
lt=true
for f=2,#du-1 do
if cl[du[f].dg]>cl[du[f+1].dg] then
du[f],du[f+1],lt=du[f+1],du[f]
if gy==f then
gy+=1
elseif gy==f+1 then
gy-=1
end
end
end
until lt
end
function er(lu,be)
lu.dv-=cc[lu.dg]*(be or 1)
if lu.dv<=0 and lu~=du[1] then
del(du,lu)
end
end
function kb(lv,lu)
local ei,ek=0,0
foreach(lv,
function(self)
if ch[df.dg]
then
lw=(self.dy.freeze or self.dg==30) and 0 or bw[self.dg]
if(lw>0 and bz[lu]) ek+=1
if(lw>ei) ke=self
ei=max(ei,lw)
end
end)
return ei,ek,ke
end
function dh(de)
local de=df.dg
return ec>=ca[de]
and(ef>0 or ei==0 or es or not bz[de])
and(de~=5 or not(dj[dk][dl].dn or dj[dk][dl].ep))
and df.dv>0
end
function iz(lr)
if fd then
return lr==4 and stat"34"&1==1 or lr==5 and btn"5"or lr==6 and btn"4"or lr==7 and stat"34"&2==2
else
return btn(min(lr,5))
end
end
function ea()
gy,jz=jz or gy
ez()
dp=false
end
function eq()
ge=max(ge,90-min(50,da)-gd/2)
end
function id()
local lx=gg[ey(#gg)]
if lx then
lx.dg=28
iw(10,lx,4,-4)
end
end
function dw(be,...)
local ly={...}
for f=1,#ly do
if(be==ly[f]) return true
end
end
function lg(ig,lz,...)
return dw(ig,...) and dw(lz,...)
end
function iu(ig,it,be)
ig.dy[it]+=be
local ma,mb=ig.dy[it],(not ig.dy.freeze or ig.dg==31) and bd[it][ig.dg]==1
if ma>bb[it][1]
then
if(ig.dg==6) and it=="fire"and not ig.dy.freeze then
ig.dg=7
elseif ig.dg==32 and it=="shock"then
ig.dg=33
end
li(ig.dq,ig.dr,it)
if mb then
if(it=="freeze") iw(10,ig,6)
ig.dy[it]=false
del(hd[it],ig)
end
end
if ma>bb[it][2] then
if dw(ig.dg,5,23) then
jy(ig,"smash")
ed(ig.dq,ig.dr,2)
foreach
(
ka(0,2,ig.dq,ig.dr,"fire"),
function(self) eo(self,"fire") end
)
elseif it=="freeze"and not dw(ig.dg,6,7) then
ig.dy.freeze=nil
iw(10,ig,6)
elseif not mb then
jy(ig,it)
end
del(hd[it],ig)
end
if ma==2 and it=="freeze"then
iw(5,ig,8,2,1)
end
end
function ey(be)
return rnd(be)\1+1
end
function hn()
return rnd()>.5
end
function km(be)
return rnd(be*2)-be
end
function eb(be)
local mc=bp[be-0]
sfx(mc[1],1,mc[3] or 0,mc[2])
end
function _draw()
fa()
if fc~=0 or dc>0 then
for f=0,15 do
pal(f,sget(f,122+abs(fc/2)-dc),1)
end
end
end
function md(me,mf)
mf=tostr(mf)
if me>0 then
while#mf<4 do
mf="0"..mf
end
return me..mf
end
return mf
end
function ft()
local mg=md(fp,fo)
m"4,|,1,1,|,7,$=1,4,121,5,|,7,◆=100,26,121,|,7,🐱 X2 MULTIPLIER,62,121,|,7, ,,,7,|,2,|"
mh(print,13,1,"      game over\n\n\nscore ......... "..a"       $,      $,     $,    $,   $,  $, $,$"[#mg]..mg,i"14,10,7")
for f=1,6 do
local me,mf=dget(f),dget(f+56)
local mg=md(me,mf)
?a"adventurer .... ,archer ........ ,warrior ....... ,mage .......... ,scavenger ..... ,alchemist ..... "[f]..a"       $,      $,     $,    $,   $,  $, $,$"[#mg]..mg,14,f*10+38,gi==f and jc or 6
end
end
function gq()
for kj in all(hc) do
if kj.c<4 or dw(kj.c,10,14,15) or kj.c==11 and kj.fg>8 then
local mi=kj.c==11 and 3 or kj.c==14 and 2 or 1
jj-=km"1.5"*mi
jk-=km"1.5"*mi
break
end
end
m"1,|,2,|"
camera(jj,jk)
mj(gr)
for f=0,ha do
for hv=0,hb do
sspr(dj[f][hv].hy*15,85,15,11,f*15+1,hv*11+7)
end
end
pal()
if gs then
mh(print,i"1,, adventurer     mage\n 5 hp regen    mana x2\n\n\n\n\n   archer    scavenger\n  sp arrow  +50% consumables\n\n\n\n warrior     alchemist\n9 hp regen +1 slot +1 bag,1,20,15")
end
local mk,ml=ht.dq*15+1,ht.dr*11+5
if gj then
pal(r[gw])
mh(sspr,0,0,105,85,13,9,mk+1,ml+3)
else
mh(sspr,0,0,0,84,15,12,mk,ml)
end
pal()
rect(eu+1,ev+7,eu+15,ev+17,jc)
for hv=0,hb do
for f=0,ha do
local dn=dj[f][hv].dn
if dn then
if dn~=dp then
mm(dn,dn.ds,dn.dt)
if dw(dn.dg,14,35) and dk==f and dl==hv then
mn((dn.dg==14 and"$"or"◆")..dn.ep.io,1.2,dn.dg==14 and 9 or 6,18,dn.dg==14 and je or jf,dn)
end
end
dn.kg=nil
end
local ep=dj[f][hv].ep
if ep then
mo(ep,f*15+3,hv*11+6,0,sin((fg+(f+3)*(hv+3))/40)*1.6+4)
if cn[ep.dg]>$0x5e20 then
if(fg%18<12) sspr(119,0,9,9,f*15+4,hv*11+2)
if gs and dk==f and dl==hv then
mn("◆"..cn[ep.dg],.6,6,10,je)
end
end
end
end
if hv==ht.dr and not gl then
local mp=gj and"❎ open"or he.."/"..ib
mh(print,jd,0,mp,mk-#mp*2+8,ml+sin(fg/80)*1.3-2,gj and jc or 7)
end
end
pal()
for ig in all(dn) do
local arrow=ig.dy.arrow
if(arrow) mh(spr,1,0,242,ig.ds+arrow*20-140,ig.dt+8-arrow*20+140)
end
foreach(gf,function(self)
circfill(self.dq,self.dr,self.iy*2,ct[self.c])
end)
foreach(gf,function(self)
circfill(self.dq-self.iy/2,self.dr-self.iy/2,self.iy*1.5,cs[self.c])
end)
for kj in all(hc) do
if kj.c==1 then
local mr,ms,mt,mu=rnd"3",rnd"3"-12,hn(),hn()
pal()
if fg%6<3 then
pal(7,a"7,10"[fg%3])
m"3,9,t,|,3,10,t,|"
end
for f=-2,5 do
sspr(56,96,16,22,kj.dq+mr,f*22+ms,16,22,mt,mu)
end
elseif kj.c==2 then
circfill(kj.dq+rnd"4"+7,kj.dr+rnd"3"+6,6+rnd"3"-sin(kj.fg/6)*16,7)
elseif dw(kj.c,3,4,7,8,9,10,12,13) then
mv"7"
for f=1,15 do
palt(f,abs(f-kj.fg)>1)
pal((kj.fg),cw[kj.c])
pal((kj.fg-1),cx[kj.c])
end
sspr(
(a",,,24,,,24,24,24,,,119,56")[kj.c],
(a",,96,96,,,96,96,96,96,,33,120")[kj.c],
(a",,24,32,,,32,32,32,24,,9,40")[kj.c],
(a",,24,32,,,32,32,32,24,,34,8")[kj.c],
kj.dq+34-(a",,30,40,,,34,40,40,43,,30,45")[kj.c],
kj.dr+26-(a",,24,32,,,26,32,32,32,,40,22")[kj.c],
(a",,24,32,,,16,32,32,36,,9,40")[kj.c],
(a",,24,32,,,16,32,32,36,,34,8")[kj.c],
kj.c==8,false)
elseif kj.c==5 then
pal()
mh(spr,2,0,204+kj.spr\2,kj.dq+5,kj.dr+2)
elseif kj.c==6 then
circfill(kj.dq,kj.dr,3-kj.fg/3,fg%2*5+7)
elseif dw(kj.c,11,15) then
if kj.c==11 then
mw,mx,my=a"7,15,14,8",min(50-kj.fg*2,min(4,kj.fg-8))*4,8
else
mw,mx,my=a"7,6,12,12",min(30-kj.fg*2,min(4,kj.fg-4))*2,0
end
for f=4,1,-1 do
local mz=mw[f]
if(mx<.5) mx,mz=.25,mw[4]
rectfill(-100,kj.dr+6+my+sin(f/20)*mx,138,kj.dr+6+my-sin(f/20)*mx,mz)
end
if(kj.fg>=cu[kj.c]-5) then
et(4,rnd"200"-50,kj.dr+my,kj.c==11 and 5 or 6)
end
end
end
pal()
if ke and not dp and not gl then
local dq,dr=ke.ds+7,ke.dt+sin(fg/24)*1.9
if es then
mh(spr,jb*6+9,1,220,dq-2,dr-1)
end
mh(print,jb+1,1,kh,dq,dr,jf)
end
if go then
if go>23 then
circfill(ln+8,kn+2,go*5-133,10)
end
mh(print,jd,1,"combo x"..gd,ln-6,kn,je)
end
if gn and(gn>10 or fg%2==0) then
if(fz) m"2,2,4,|,2,8,9,|,2,14,10,|"
circfill(lp+8,ko+7,8+sin(fg/10)*1.5,7)
mh(sspr,jb*8+7,1,fg\2%6*9,76,9,8,lp+4,ko+4)
end
m"4,0,-3,|,2,|,5,0,109,127,127,5,|,5,0,109,127,109,13,|,3,0,f,|,3,3,t,|,6,221,8,106,|,6,221,14,106,|,6,221,20,106,|,6,221,26,106,|,6,221,32,106,|,6,221,38,106,|,6,221,44,106,|,6,221,50,106,|,6,221,56,106,|,6,221,70,106,|,6,221,76,106,|,6,221,82,106,|,6,221,88,106,|,6,221,94,106,|,6,221,100,106,|,6,221,106,106,|,6,221,112,106,|,6,221,118,106,|"
pal()
local na={{0,max(0,ef-eg),ef},{0,flr(ec),ec}}
local nb=a"8,11,|,12,13,|"
for nc=1,2 do
for nd=1,2 do
clip(na[nc][nd]*6+nc*62-54,0,(na[nc][nd+1]-na[nc][nd])*6,127)
if nd==2 then
if nc==1 then
m"2,14,15,|,2,8,11,|,2,2,3,|"
else
m"2,12,13,|"
end
end
for f=1,9 do
spr(221+nc,nc*62-60+f*6,106)
end
end
m"2,|,13,|"
local io=nc==1 and(bz[df.dg] and kh or 0) or ca[df.dg]
local count=nc==1 and ef or ec
if fg%4==0 and io>0 then
local mz,lh=12,nc*62-55+max(0,count-io)*6
if io>count then
mz,lh=8,nc*62-54
end
rectfill(lh,106,nc*62-55+count*6,110,(nc==1 or jr) and 7 or mz)
end
end
if eg>=ef and eg>0 then
m"2,14,15,|,2,8,11,|,2,2,3,|"
end
mh(spr,i"1,0,234,2,105")
mh(spr,i"1,0,235,65,104")
m"3,0,f,|,3,15,t,|"
for f=1,jl-1 do
sspr(119,9,9,9,f*10,114-f%2*2)
end
if dp then
m"2,|,3,,f,|"
camera(jj,jk+3)
dp.kg=1
mm(dp,jo+1,jp-kc,true)
m"2,|,3,0,f,|,3,15,t,|"
sspr(70,30,11,9,jo+6,jp-kc-1)
end
m"2,|,4,0,-3,|"
for f,ep in pairs(du) do
local ne=ba[f]
if f==gy then
ne=jb*13
end
mo(ep,10*f-11,111+f%2*2,ne,0)
end
m"2,|,6,236,92,111,1,2,|,6,237,120,111,1,2,|,5,100,112,120,127,15,|,5,100,111,120,111,9,|"
?"$"..fq,120-nf(fq),113,4
if fw then
?"lv"..fx,116-nf(fx),-1,12
else
if fy<=40 and fy%8==0 then
m"7,\"t\" skip to adventure,2,-1,12,|"
end
?"◆"..$0x5e20,116-nf($0x5e20),-1,9
if fe then
?unpack(jh and jh[fy] or jg[fy])
end
if(fy<=7) m"7,\"r\" to restart level,2,-1,15,|"
?((fy-1)\8+1).."-"..(fy-1)%8+1,88,-1,8
end
?"◆"..fr,116-nf(fr),119,2
camera(jj,jk+3)
for f=17,13,-4 do
m"3,0,f,|,3,15,t,|"
if(f==17) mv"1"
spr(233,jo+11,jp+f)
pal()
end
if not dp then
mo(df,
jo+19+
(jr and rnd"2"or 0),
jp+18+
(jr and rnd"2"or 0),
jr and fg%2*5+7 or 0,
4)
if not dh(df) and fg%14>5
and df.dg>1
and not jr
then
sspr(119,0,9,9,jo+19,jp+14)
end
end
if fw then
local ng=ceil(5+gz/900*79)
m"4,0,-3,|,5,5,-1,84,2,2,|,5,5,-1,84,-1,1,|"
rectfill(ng,-1,min(ng+ge/900*79,84),2,7)
if(gm and jb==0) mv"8"
for f=1,4 do
rectfill(5,f-2,ng,2,a"6,7,6,13,15,7,15,9"[f+(ge<=0 and 4 or 0)])
end
mh(spr,i"1,0,217,0,-2")
end
m"2,|,2,0,0x80,1,|"
end
function mm(dn,dq,dr,nh)
local dg,ni=dn.dg,dn.dy
local shock,fire,arcane,freeze=ni.shock,ni.fire,ni.arcane,ni.freeze
if shock then
for be=1,3 do
pal(7,z[be])
spr(238,dq+rnd"4"-1,dr+rnd"3"-1,2,2,hn(),hn())
end
end
local nm,mz=0,1
if(shock) mz=0 nm=rnd"2"
camera(nm+jj,jk)
pal()
palt(0,false)
if shock and fg%4>0
or fire and fg%6>1 then
mv()
end
if fire then
for be=0,2 do
circfill(dq+rnd"4"+7,dr+rnd"3"+6,6-be*2+rnd"3"-sin(fire/24)*4,8+be)
end
iw(1,dn,4)
end
if ni.poison then
if fg%8<4 then
mv"11"
mz=11
iw(1,dn,3)
end
end
if ni.bomb then
iw(1,dn,2)
if(fg%8<2) mv"6"
end
m"3,15,f,|"
palt(bt[dg],true)
if(dg==34) m"2,8,12,|,2,2,1,|,2,14,6,|"
if(dg==35) m"2,11,8,|,2,3,2,|"
pal(bu[dg],dn.kg and q[dn.kg][fg%7+1] or dw(dg,32,5) and 0 or 1)
if(dg==33) pal(0,fg%2*4+9)
local no,np,nq,nr,ns,nt=unpack(bl[dg])
local nu,nv,nw,nx,ny,nz=unpack(bm[dg])
if freeze then
pal(0,1)
pal(u)
nh=true
rectfill(dq+2,dr+1,dq+15,dr+13,1)
end
if arcane and arcane>0 then
pal(0,2)
pal(t)
if(fg%4<2) mv"15"
end
if dw(dg,27,28) then
local oa=dg==28 and 1 or 0
spr(0,ns+dq+1+oa,nt+dr+4-oa,2,1,fg%2==0)
end
sspr(no,np,nq,nr,ns+dq,nt+dr)
if nv then
local is=nh and 1 or(fg+dn.ii)/br[dg]%2
if(ig==gl or dg~=36) sspr(nu,nv,nw,nx,ny+dq+(bs[dg] and is or 0),nz+dr+(bs[dg] and 0 or is))
end
pal()
if freeze and freeze>0 then
sspr(81,45,14,15,dq+2,dr)
end
ob(dg,dq,dr)
camera(jj,jk)
end
function ob(dg,dq,dr)
local mp=dg==34 and gu-gd or dg==36 and gx
if(mp and not gl) mh(print,jd,0,mp,dq+9-#tostr(mp)*2,dr-1+sin(fg/30)*1.5-(dg==36 and 8 or 0),je)
end
function mo(f,dq,dr,oc,od)
oe(f)
local no,np,nq,nr,ns,nt=unpack(bn[f.dg])
ns+=dq
nt+=dr
if od>0 then
mv"1"
mh(sspr,1,0,no,np,nq,nr,ns,nt)
oe(f)
end
mh(sspr,oc,0,no,np,nq,nr,ns,nt-od)
local dv=f.dv
if f.im>1 and dv>0 then
mh(print,0,0,dv,dq-nf(dv)+11,dr+6-od,dv<f.im and 7 or 10)
end
pal()
end
function oe(f)
local dg=f.dg
m"2,|,3,0,f,|"
palt(dg==5 and 3 or 0,true)
pal(bo[dg])
end
function mv(n)
for be=0,15 do
pal(be,n)
end
end
function mh(of,n,c,...)
local og,oh,oi={},camera()
for f=0,15 do
og[f]=pal(f,n)
end
for f=-1,1 do
for hv=-1,1 do
if abs(f^^hv)==1 or c==1 then
camera(oh+f,oi+hv)
of(...)
end
end
end
camera(oh,oi)
pal(og)
of(...)
end
function mj(gr)
pal(a"1,2,3,4,5,6,7,8,5,10,11,12,13,2,|,|,1,2,3,4,5,6,7,8,5,|,1,2,12,4,13,6,7,8,9,10,11,12,13,5,|,1,2,13,13,5,6,7,8,3,10,11,12,13,1,|"[gr])
if gr==5 then
for f=4,9 do
pal(v[f],v[f+flr(sin(fg/90)*1.9-.5)])
end
end
end
function nf(kj)
return#tostr(kj)*4
end
function mn(mp,oj,ok,ol,mz,dn)
local om,on=eu,max(ev,6)+sin(fg/30)*oj
m"3,9,true,|"
mh(spr,1,0,202,om+1,on-14,2,2)
if(dn) mo(dn.ep,eu+3,on-12,0,0)
mh(print,jd,0,mp,om+ok-#mp*2,on-ol,mz)
end
function fi()
local on=max(0,1-fg\90)*6
me=min(3,fg\30)*6-1
m"1,5,|,3,5,t,|,7,crowded\ndungeon\ncrawler,0,0,0,|,8,0x1800,0x6000,0x0800,|,1,|"
if fg>90 then
oo=hn() and 0xa5a5.1 or 0x5a5a
fillp(oo)
m"5,0,0,127,127,0x12,|"
for be=0,1 do
for f=1,4 do
circfill(8+107.5*be+rnd"3",32+rnd"3",(max(80,115-#ff/2))/(f+1)-5,a"0x54,0x59,0x5a,0x57"[f])
end
end
fillp()
for n=0,1 do
for hv=0,8 do
for f=0,5 do
rect(f*32+(hv*16%32)-6+n,hv*16-4+n,f*32+(hv*16%32)+32-6+n,hv*16+12+n,2-n)
end
end
end
end
function op()
sspr(0,96+on,27,me,22,6+on*3,27*3,me*3)
end
mh(op,1,1)
if fg>90 then
fillp(~oo)
for be=0,1 do
for f=1,4 do
circfill(8+107.5*be+rnd"3",32+rnd"3",60/(f+1)-5,x[f])
end
end
fillp()
end
if(fc==0) m"2,,15,|"
op()
m"9,|,2,|,3,15,t,|,3,5,f,|"
function oq(ii,kt,os)
for be=10,120,107.5 do
add(ff,
{
dq=be+km(ii),
dr=35+km(ii),
kt=kt,
os=os
})
end
end
if fg==90 then
for f=0,10 do
oq(i"5,15,.5")
end
end
if fg>90 then
m"11,117,18,11,15,4,38,|,11,117,18,11,15,112,38,|"
oq(i"0,7,.2")
for f=1,4 do
foreach(ff,
function(self)
if f==1 then
self.dr-=(km".8"+self.os*4)
self.dq+=km".5"
self.kt-=self.os
end
circfill(self.dq,self.dr,self.kt/(1.1-f/10)-(f-1)*2,y[f])
if(self.kt<=0) del(ff,self)
end)
end
m"8,0,0x2000,0x1000,|,3,0,f,|,6,0,0,64,16,8,|"
end
if(dw(fg,i"30,60,89")) eb(15)
if(fg==89) m"10,54,|,1,5,|"
m"3,0,f,|,2,14,129,1,|,2,15,128,1,|"
end
function fm()
m"1,|,7,press 🅾️/z to play with the\n   controller or keyboard\n\n\nclick to play with the mouse\n       and keyboard\n\n\n\n\n\nthis game autosaves. you can\ncontinue playing at any time,10,46,7,|"
end