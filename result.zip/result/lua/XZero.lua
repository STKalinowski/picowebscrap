-- x-zero
-- by paranoid cactus

-- prefab map blocks
-- [1][2]=x,y offset into pico-8 map for top left tile of prefab (all prefabs are 16x16 tiles)
-- scr: position to draw terminal screen
-- sp: special prefab for boss chamber and entrance corridor
prefabs={{{112,16}},{{0,0,scr={52,72}},sp={80,32}},{{16,0,scr={84,80}}},{{32,0}},{{48,0,scr={52,72}}},{{64,0},{0,32},sp={64,32}},{{80,0}},{{96,0}},{{112,0,scr={44,48}}},{{0,16}},{{16,16},{16,32}},{{32,16}},{{48,16}},{{64,16}},{{80,16}},{{96,16}}}

-- fully solid prefab block
nullmap={paths=0,visited=false,keytaken=false,mbx=112,mby=16}

-- sprites used to draw minimap [1]=spritesheet x,[2]=spritesheet y,fx=flip x axis,fy=flip y axis
mapbits={{0,13},{5,8},{0,11},{0,8,fx=true,fy=true},{5,8,fx=true},{4,8},{0,8,fy=true},{4,10,fy=true},{0,11,fy=true},{0,8,fx=true},{0,10},{2,10,fx=true},{0,8},{4,10},{2,10},{2,8}}

-- player sprite parts {x,y,w,h}
psprs={{0,0,6,8},{6,0,8,4},{14,0,7,6},{21,0,4,6},{25,0,5,6},{30,0,8,6},{38,0,8,6},{46,0,4,6},{50,0,5,6},{55,0,8,6},{63,0,8,6},{70,0,8,7},{78,0,8,6},{86,0,7,7}}

-- player animations {index in psprs,x draw offset, y draw offset}
pstand={{{3,0,-6},{1,0,-13},{2,2,-8}}}
prun={{{4,1,-6},{1,1,-14},{2,3,-9}},{{5,1,-6},{1,1,-14},{2,3,-10}},{{6,-1,-6},{1,1,-13},{2,3,-10}},{{7,-1,-6},{1,1,-13},{2,3,-9}},{{8,1,-6},{1,1,-14},{2,3,-9}},{{9,1,-6},{1,1,-14},{2,3,-10}},{{10,-1,-6},{1,1,-13},{2,3,-10}},{{11,-1,-6},{1,1,-13},{2,3,-9}}}
pjump={{{12,-1,-6},{1,0,-14},{2,2,-9}},{{13,-1,-6},{1,0,-13},{2,2,-9}},{{14,-1,-6},{1,0,-14},{2,2,-11}}}

-- gun sprites (3 aiming directions)
gsprs={{93,0,7,6,oy=0,by=5,a=0},{6,0,8,4,oy=0,by=0,a=0},{100,0,7,7,oy=-4,by=-4,a=0}}

-- bullet sprites
bsprs={{11,4,3,5,ox=-1,oy=-1},{8,8,3,5,fx=1,ox=-1,oy=-1},{11,9,4,4,fx=1,ox=-1,oy=-1},{14,6,5,3,fx=1,ox=-1,oy=-1},{6,5,5,3,fx=1,ox=-1,oy=-1},{14,6,5,3,fx=1,fy=1,ox=-1,oy=-1},{11,9,4,4,fx=1,fy=1,ox=-1,oy=-2},{8,8,3,5,fx=1,fy=1,ox=-1,oy=-3},{11,4,3,5,fy=1,ox=-1,oy=-3},{8,8,3,5,fy=1,ox=-1,oy=-3},{11,9,4,4,fy=1,ox=-2,oy=-2},{14,6,5,3,fy=1,ox=-3,oy=-1},{6,5,5,3,ox=-3,oy=-1},{14,6,5,3,ox=-3,oy=-1},{11,9,4,4,ox=-2,oy=-1},{8,8,3,5,ox=-1,oy=-1}}

-- gun data (was going to have multiple weapon types but didn't get implemented)
gun={rate=10,spd=3,sprs=bsprs,bullets={0,0.0625,-0.0625,0.125,-0.125}}

-- boss bullet sprites
ebsprs={{86,21,5,5,ox=-2,oy=-2},{90,21,5,5,ox=-2,oy=-2,fx=1},{90,21,5,5,ox=-2,oy=-2},anms={1,1,2,2,3,3}}

-- flying enemy
enemy1={fly=1,hp=3,hbx1=-1,hby1=-9,hbx2=9,hby2=1,sprs={{119,0,9,7,ox=0,oy=-8},{110,0,9,8,ox=0,oy=-8},{120,7,8,5,ox=0,oy=-5}},anms={1,1,2,3,3,3,2}}

-- walking enemy
enemy2={hp=5,hbx1=-5,hby1=-11,hbx2=11,hby2=1,sprs={{14,22,16,10,ox=-6,oy=-10},{0,14,15,9,ox=-5,oy=-9},{30,22,16,10,ox=-6,oy=-10},{46,22,15,10,ox=-6,oy=-10},
{15,12,15,10,ox=-6,oy=-10},{0,23,14,9,ox=-5,oy=-9},{30,12,15,10,ox=-6,oy=-10},{45,12,16,10,ox=-6,oy=-10}},anms={1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8}}

-- 3rd enemy type that never got implemented
enemy3={fly=1,shoot=1,hp=5,hbx1=-4,hby1=-8,hbx2=4,hby2=1,sprs={{76,6,9,8,ox=-4,oy=-8}},anms={1}}


-- power up
pickuppowerup={prop="bcount",propadd=2,propmax="maxbullets",sprs={{33,6,8,6,ox=-4,oy=-6},{41,6,8,6,ox=-4,oy=-6},{48,6,6,6,ox=-3,oy=-6},{54,6,4,6,ox=-2,oy=-6},{54,6,4,6,fx=1,ox=-2,oy=-6},{48,6,6,6,fx=1,ox=-3,oy=-6},{41,6,8,6,fx=1,ox=-4,oy=-6}}}
-- health pickup
pickuphealth={prop="hp",propadd=1,propmax="maxhp",sprs={{120,12,5,4,ox=-2,oy=-4}}}
-- pickup types
pickuptypes={pickuppowerup,pickuphealth}


-- fade palette used for paranoid cactus logo (default pico-8 palette)
fadepal={
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,129,0,130,130,129,129,0,130,130},{0,0,0,129,128,128,129,1,128,2,136,1,1,129,2,136},{0,129,130,1,130,130,1,141,130,136,8,131,131,130,136,8},{0,129,130,131,132,133,141,13,2,8,137,3,140,2,8,142},{0,1,2,131,136,133,13,6,136,137,9,139,13,141,142,143},{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}}

-- fade palette used for game
fadepal2={
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,128,0,130,130,0,129,0,0,0},{0,0,0,0,0,128,128,133,128,2,136,0,1,128,0,0},{0,0,0,128,0,133,133,5,130,136,8,129,131,130,128,0},{0,129,128,130,128,133,5,134,2,8,137,1,140,2,133,0},{0,1,133,2,130,5,134,6,136,137,9,131,13,141,5,128},{0,1,133,136,141,5,6,7,8,142,10,140,12,13,134,128}}

function _init()
	-- l,t,r,b: (left,top,right,bottom) indicate which directions of a map cell have paths. can be added together to determine which map block is used
	-- w,h: width,height of map in map blocks (16x16 tiles)
	-- fdi,fpt,fpo,fpd: used for fading screen palette - palette index, fade time, origin index, destination index
	l,t,r,b,w,h,fpi,fpt,fpo,fpd=1,2,4,8,20,6,7,0,7,1
	nextmode,gamemode,waittimer,flashtime,jbtn,sbtn=0,-1,30,0,4,5
	sfx(42)
	menuitem(2,"swap controls",function() jbtn,sbtn=sbtn,jbtn end)
end

function _update60()
	-- timer used for anything that flashes/blinks
	flashtime=(flashtime+1)%16
	-- if we are going to change game modes but have a wait timer
	if gamemode~=nextmode and waittimer>0 then
		waittimer-=1
		return
	end
	-- if screen palette is transitioning (ie fading in or out)
	if fpi~=fpd then
		-- fade screen
		fpt=min(1,fpt+0.05)
		fpi=flr(lerp(fpo,fpd,fpt))
	elseif fpd==1 then
		-- when screen has finished fading change game mode
		gamemode,fpt,fpo,fpd,fadepal=nextmode,0,1,7,fadepal2
		if gamemode==0 then
			-- switching to title screen
			-- clear user memory so we can use it to store the x brush stroke image
			memset(0x4300,0,0x1b00)
			-- initialise the brush for drawing the x
			brushx,brushy,brushxv,brushyv,brushyd,brushw,bossevent,waittimer=34,20,1.2,1.2,96,2.5,false,1
			-- remove "end game" menu item from system menu
			menuitem(1)
		else
			-- non title screen mode
			-- add "end game" to system menu
			menuitem(1,"end game",function() changemode(0) end)
			if gamemode==2 then
				-- game over so fade music
				music(-1,3000)
				waittimer=580
			elseif gamemode==3 then
				-- victory music
				music(22)
			end
		end
	else
		if gamemode==0 then
			if waittimer==1 then
				-- title music
				music(18)
			end
			if waittimer>0 then
				waittimer-=1
				return
			end
			if brushyd<112 and brushy>=brushyd then
				-- initialise second brush stroke
				brushx,brushy,brushxv,brushyd,brushw=102,18,-1.4,256,4
			end
			if btnp(4) or btnp(5) then
				-- start game
				changemode(1)
				genmap()
				music(0,0,6)
			end
		elseif gamemode==1 then
			if waitfunc then
				waittimer-=1
			else
				-- only update player if we don't have a wait timer (wait timer is set when the player dies or kills the boss)
				player:update()
			end
			-- mark player's position on map as visited
			local mg=mgr[flr(player.x/128)+1][flr(player.y/128)+1]
			mg.visited=true
			-- update all the things
			for e in all(enemies) do
				e:update()
			end
			for b in all(bullets) do
				b:update()
			end
			for p in all(particles) do
				p:update()
			end
			for p in all(pickups) do
				p:update()
			end
			if boss then
				boss:update()
				-- fixed camera position on boss fight
				local camxd,camyd=mg.x*128-128,mg.y*128-128
				camx,camy=camx+(camxd-camx)*0.025,camy+(camyd-camy)*0.025
			else
				-- scroll camera
				camx,camy=flr(player.x-64),flr(player.y-64)
			end
			-- wait timer has expired and we have a function to call then call that function
			if waitfunc and waittimer==0 then
				waitfunc()
				waitfunc=nil
			end
		elseif gamemode==2 then
			-- game over
			if waittimer>0 then
				waittimer-=1
			end
			if btnp(4) or btnp(5) or waittimer==0 then
				changemode(0)
			end
		elseif gamemode==3 then
			-- victory
			if btnp(4) or btnp(5) then
				changemode(0)
			end
		end
	end
end

function changemode(v)
	-- prepare to fade screen and switch game modes
	nextmode,fpt,fpo,fpd=v,0,7,1
end

function _draw()
	if gamemode==-1 then
		-- paranoid cactus logo
		cls()
		sspr(0,96,29,12,49,59)
		sspr(86,119,10,9,59,50)
	elseif gamemode==0 then
		-- title screen
		cls()
		-- copy user memory to screen memory
		memcpy(0x6280,0x4300,0x1b00)
		if waittimer==0 and brushy<brushyd then
			-- draw a peice of the x brush stroke
			for i=0,4 do
				circfill(brushx,brushy,brushw+rnd(3),8)
				brushx+=brushxv
				brushy+=brushyv
				brushw-=0.085
			end
			-- copy screen memory to user memory
			memcpy(0x4300,0x6280,0x1b00)
		end
		if brushy<256 and brushy>250 then
			-- flash screen when "zero" appears
			cls(8)
		elseif brushy>=256 then
			-- finished drawing brush strokes so display "zero"
			sspr(0,108,86,20,21,39)
			print("press 🅾️ or ❎ to start",18,112,flashtime>8 and 1 or 11)
			-- corrupt screen a little bit
			if flrrnd(48)==0 then
				corruptlines(flrrnd(10))
			end
		end
	elseif gamemode==1 then
		cls()
		-- draw parallax background
		for bgx=0,4 do
			for bgy=0,3 do
				map(118,56,flr(-camx*0.5%80)+bgx*80-80,flr(-camy*0.5%64)+bgy*64-64,10,8)
			end
		end
		
		-- draw map
		palt(0,false)
		palt(10,true)
		-- find out the map block that the top left of the screen is in
		local mbixl,mbiyt=getmbxy(camx,camy)
		-- draw each visible map block
		for mbix=mbixl,mbixl+1 do
			for mbiy=mbiyt,mbiyt+1 do
				-- determine which section of the pico-8 map to draw for this prefab block
				local mb,mbscrx,mbscry=(mbix<1 or mbix>#mgr or mbiy<1 or mbiy>#mgr[mbix]) and nullmap or mgr[mbix][mbiy],-camx+(mbixl-1)*128+(mbix-mbixl)*128,-camy+(mbiyt-1)*128+(mbiy-mbiyt)*128
				-- draw the block
				map(mb.mbx,mb.mby,mbscrx,mbscry,16,16,mb.key and 0x3 or 1)
				-- if there is a terminal and it hasn't been hacked then draw the flashing screen
				if mb.key and not mb.keytaken then
					pal(11,10)
					if flashtime<8 then
						pal(9,8)
						pal(8,2)
						pal(6,9)
					end
					sspr(96,11,8,5,mbscrx+mb.scr[1],mbscry+mb.scr[2])
					pal(11,11)
					pal(9,9)
					pal(8,8)
					pal(6,6)
				end
			end
		end
		palt()
		if door then
			door:draw()
		end
		for p in all(pickups) do
			p:draw()
		end
		for b in all(bullets) do
			b:draw()
		end
		if boss then
			boss:draw()
		end
		if not waitfunc or (boss and boss.hp<=0) then
			player:draw()
		end
		for e in all(activeenemies) do
			e:draw()
		end
		for p in all(particles) do
			p:draw()
		end
		-- hud map
		if not boss then
			rectfill(127-w*2,0,127,h*2,15)
			for mx=1,#mgr do
				for my=1,#mgr[mx] do
					local mg=mgr[mx][my]
					if mg.visited then
						local mb=mapbits[mg.paths+1]
						sspr(mb[1],mb[2],3,3,125-w*2+mx*2,my*2-2,3,3,mb.fx,mb.fy)			
					end
					if mg.key then
						pset(126-w*2+mx*2,my*2-1,mg.keytaken and 1 or 3)
					end
					if mg.boss and keycount==0 then
						pset(126-w*2+mx*2,my*2-1,flashtime<8 and 8 or 10)
					end
				end
			end
			pset(128-w*2+flr(player.x/128)*2,flr(player.y/128)*2+1,11)
		end
		-- player ui
		rectfill(0,0,player.maxhp*3+6,5,15)
		sspr(120,12,5,4,1,1)
		for i=1,player.maxhp do
			rectfill(4+i*3,1,5+i*3,4,0)
			if player.hp>=i then
				sspr(125,12,2,4,4+i*3,1)
			end
		end
		rectfill(25,0,40,5,15)
		for i=1,player.lives do
			sspr(0,0,5,4,20+i*5,1)
		end
		-- boss health bar
		if boss then
			rectfill(13,124,114,127,15)
			rectfill(14,125,113,126,0)
			if boss.hp>0 then
				rectfill(14,125,13+ceil(boss.hp/1.5),126,8)
			end
		end
		
		-- if player was hit or is hacking then corrupt the screen
		if player.hit>0 then
			corruptlines(3)
		end
		if player.hackt>0 then
			corruptlines(1+flrrnd(player.hackt/6))
		end
	elseif gamemode==2 then
		-- game over
		cls()
		sspr(29,96,39,12,45,57)
		corruptlines(6)
	elseif gamemode==3 then
		-- win
		cls()
		sspr(68,64,60,44,34,40)
	end
	-- screen pallete
	for i=1,16 do
		pal(i-1,fadepal[fpi][i],1)
	end
end

function corruptlines(n)
	-- randomly copy bits of screen memory around
	for i=0,n do
		memcpy(0x6000+flrrnd(0x1fc0),0x6000+flrrnd(0x1fc0),flrrnd(64))
		local addr=0x6000+flrrnd(0x1fc0)
		poke4(addr,bxor(peek4(addr),0xffff.ffff))
	end
end

function new_player(x,y)
	local jtm,anm,anmf,flp,onground,ft,nft,canjmp,btm,gunf,guna,hackdonet,canhack=0,pstand,1,false,false,4,4,true,0,1,0,0,false
	return {
		sx=x,sy=y,x=x,y=y,vx=0,vy=0,maxbullets=5,bcount=1,hit=0,maxhp=5,hp=5,invulnerable=0,lives=3,hackt=0,
		update=function(p)
			-- find which map block player is in
			local mbix,mbiy,mg=getmb(p.x,p.y)
			-- see if player is in front of terminal
			canhack=onground and mg and mg.key and not mg.keytaken and mfget(p.x,p.y-1,2)
			-- see if we've triggered the boss fight
			if not bossevent and mg and mfget(p.x,p.y-1,3) then
				music(23,0,3)
				bossevent,p.sx,p.sy=true,p.x,p.y
				spawn_boss((mbix-1)*128+100,(mbiy-1)*128+32)
				for e in all(activeenemies) do
					e:kill(true)
				end
				spawn_door(mbix*128-124,mbiy*128-64)
			end
			-- see if player has fallen into the boss pit
			if mg and mfget(p.x,p.y-6,5) then
				p:hurt()
				p.x,p.y,p.vx,p.vy=p.sx,p.sy,0,0
			end
			
			if btn(3) then
				-- if we're in front of a hackable terminal
				if canhack then
					guna,gunf,p.vx,p.vy=flp and 0.25 or 0.75,2,0,0
					if p.hackt==0 then
						sfx(41,3)
					end
					-- increment hack timer
					p.hackt+=1
					if p.hackt>=128 then
						-- hacking complete
						mg.keytaken,hackdonet,p.hackt=true,120,0
						sfx(42,3)
						keycount-=1
						-- open door when all terminals are hacked
						if keycount==0 then
							door=nil
						end
					end
				else
					-- aim down
					guna,gunf,p.hackt=flp and 0.375 or 0.625,1,0
				end
			elseif btn(2) then
				-- aim up
				guna,gunf,p.hackt=flp and 0.125 or 0.875,3,0
			else
				-- aim forward
				guna,gunf,p.hackt=flp and 0.25 or 0.75,2,0
			end
			-- if not hacking
			if p.hackt==0 then
				sfx(41,-2)
				-- move
				if btn(0) then
					p.vx,flp=max(p.vx-0.25,-1.5),true
				elseif btn(1) then
					p.vx,flp=min(p.vx+0.25,1.5),false
				elseif onground then
					p.vx*=0.5
				else
					p.vx*=0.95
				end
				-- jump
				if btn(jbtn) then
					if onground and canjmp then
						p.vy-=1.25
						-- jtm: counts down while player is holding jump for variable height jump
						-- canjmp: keeps track of whether the player has released the jump button
						jtm,canjmp=8,false
					elseif jtm>0 then
						-- increase jump velocity while player holds jump
						p.vy-=0.2
					end
				else
					-- not pressing jump so kill jump time and allow jump
					jtm,canjmp=0,true
				end
			end
			
			if jtm==0 then
				-- only apply gravity when jump height isn't increasing
				p.vy+=0.15
			else
				-- reduce jump timer
				jtm-=1
			end
			-- cap fall speed
			p.vy=min(p.vy,3)
			-- collide with map
			p.x,p.y,p.vx,p.vy,onground=collideworld(p.x,p.y,p.vx,p.vy,8,14)

			p.x+=p.vx
			p.y+=p.vy
			
			-- set animation sequence and frame
			if not onground then
				-- not on ground so use jump sequence set frame to 1
				anm,anmf=pjump,1
				if p.vy>1.3 then
					-- if going down use frame 3
					anmf=3
				elseif p.vy>-1 then
					-- if near peak of jump use frame 2
					anmf=2
				end
			elseif abs(p.vx)>0.01 then
				-- if on ground and moving use run sequence
				-- set time til next frame based on velocity
				nft=flr(6-(abs(p.vx)*2))
				-- set run sequence
				if anm~=prun then
					anm,anmf,ft=prun,0,1
				end
				ft-=1
				-- if frame timer hits 0 increment frame
				if ft==0 then
					ft,anmf=nft,anmf%#anm+1
				end
			else
				-- standing still
				anm,anmf=pstand,1
			end
			
			-- shooting
			if p.hackt==0 and btn(sbtn) and btm==0 then
				-- set gun sprite based on the aim direction
				gspr=gsprs[gunf]
				-- spawn bullets (bcount is bullets player has upgraded to
				for i=1,p.bcount do
					local b=gun.bullets[i]
					-- angle of bullet
					local a=((guna+b)%1)
					-- x,y velocity of bullet
					local bvx,bvy=sin(a)*gun.spd,-cos(a)*gun.spd
					new_bullet(p.x+(flp and -1 or 9),p.y+anm[anmf][3][3]+gspr.by,bvx,bvy,a,bsprs,player)
				end
				-- fire rate counter
				btm=gun.rate
			end
			btm=max(0,btm-1)
			-- hack complete message timer
			hackdonet=max(hackdonet-1,0)
			-- hit damage flash timer
			p.hit=max(p.hit-1,0)
			-- invulnerabilty timer
			p.invulnerable=max(p.invulnerable-1,0)
			
			-- if not invulnerable check enemy collision
			if p.invulnerable==0 then
				-- only check against active enemies
				for e in all(activeenemies) do
					if not (p.x+4<e.x+e.hbx1+3 or p.x-4>e.x+e.hbx2-3 or p.y-2<e.y+e.hby1+3 or p.y-10>e.y+e.hby2-3) then
						p:hurt()
						break
					end
				end
			end
			-- check collision with pickups
			for pu in all(pickups) do
				if not (p.x+4<pu.x-3 or p.x-4>pu.x+3 or p.y<pu.y-3 or p.y-12>pu.y) then
					local putype=pu.pickuptype
					-- increment property the pickup affects
					p[putype.prop]=min(p[putype.prop]+putype.propadd,p[putype.propmax])
					del(pickups,pu)
					sfx(44)
				end
			end
			
			if p.hp<=0 then
				playerdie()
			end
		end,
		hurt=function(p)
			p.hp-=1
			p.invulnerable,p.hit,p.hackt=129,10,0
			p.bcount=max(1,p.bcount-2)
			sfx(40)
		end,
		reset=function(p)
			-- reset when player dies but still has lives
			p.x,p.y,p.vx,p.vy,p.bcount,p.hit,p.maxhp,p.hp,p.invulnerable,jtm,anm,anmf,flp,onground,ft,nft,canjmp,btm,gunf,guna,p.hackt=p.sx,p.sy,0,0,1,0,5,5,120,0,pstand,1,false,false,4,4,true,0,1,0,0
		end,
		draw=function(p)
			-- don't draw if dead
			if p.hp<=0 then
				return
			end
			-- only draw if we're not invulnerable blink frame
			if p.invulnerable%20<10 then
				-- set pallete to white if hit
				if p.hit>0 then
					for c=0,15 do
						pal(c,7)
					end
				end
				if p.hackt>0 then
					-- special sprite for hacking
					sspr(85,7,11,14,p.x-camx,p.y-14-camy)
				else
					-- each layer in frame
					for i=1,#anm[anmf] do
						local af,ox=anm[anmf][i],0
						-- layer 2 is gun so switch depending on aim
						local s=anm[anmf][i][1]==2 and gsprs[gunf] or psprs[af[1]]
						-- y offset from position to draw
						local oy=af[3]+(s.oy or 0)
						-- if flipped adjust x offset for sprite
						if flp then
							ox=8-(af[2]+s[3])
						else
							ox=af[2]
						end
						sspr(s[1],s[2],s[3],s[4],p.x+ox-camx,p.y+oy-camy,s[3],s[4],flp)
					end
				end
				pal()
			end
			
			-- hack message
			if p.hackt>0 then
				rectfill(54,38,82,46,15)
				rectfill(55,45,81,45,0)
				rectfill(55,45,55+min(p.hackt/4.6,26),45,8)
				print("hacking",55,39,3)
			elseif hackdonet>0 then
				rectfill(54,38,82,46,1)
				rectfill(55,45,81,45,12)
				print("success",55,39,11)
			elseif canhack then
				rectfill(60,38,76,44,15)
				print("hack",61,39,3)
				sspr(89,26,7,6,65,31)
			end
		end
	}
end

function new_enemy(x,y,enemytype)
	local sprs,anm,anmf,flp,active,dest,destt=enemytype.sprs,enemytype.anms,1,false,false,player,1
	return add(enemies,{sx=x,sy=y,x=x,y=y,vx=0,vy=0,hit=0,hp=enemytype.hp,hbx1=enemytype.hbx1,hby1=enemytype.hby1,hbx2=enemytype.hbx2,hby2=enemytype.hby2,fly=enemytype.fly,dir=1,
		update=function(p)
			-- distance from player
			local dx,dy=player.x-p.x,player.y-4-p.y
			local nearplayer=abs(dx)<80 and abs(dy)<80
			-- if not dead
			if p.hp>0 then
				-- only update if near player
				if nearplayer then
					-- if enemy was previously inactive add to active list
					--   the active enemies list is used for performance optimisation.
					--   inactive enemies won't be drawn or used when checking collision with the player or bullets.
					if not active then
						add(activeenemies,p)
						active=true
					end
					
					-- if this is a flying enemy
					if p.fly then
						-- timer before we choose a new destination
						destt=max(destt-1,-30)
						if destt==0 then
							-- set player as destination
							dest=player
						end
						-- direction to destination
						dx,dy=dest.x-p.x,dest.y-4-p.y
						-- get direction vector
						local nx,ny=normalize(dx,dy,0.25)
						-- set velocity to head towards destination
						p.vx=mid(p.vx+nx*0.25,-0.5,0.5)
						p.vy=mid(p.vy+ny,-0.5,0.5)
						if destt==-30 then
							-- see if we're on top of another flying enemy
							for e in all(activeenemies) do
								if e~=p and e.fly and abs(p.x-e.x)<4 and abs(p.y-e.y)<4 then
									-- we are overlapping another flyng enemy so choose a random destination to fly to get away from them
									local dir=rnd(1)
									dest,destt={x=p.x+sin(dir)*24,y=p.y-cos(dir)*24},30
									break
								end
							end
						end
					else
						-- walking enemy
						-- turn if hit wall or reach edge of platform
						if p.vx==0 or not is_solid(p.x+p.vx+(p.dir<0 and p.hbx1+5 or p.hbx2-2),p.y+2) then
							p.dir=-p.dir
						end
						p.vx=p.dir*0.5
						p.vy=0.5
					end
					-- increment anim frame
					anmf=(anmf+1)%(#anm*2)
					-- flip if moving left
					if p.vx<0 then
						flp=true
					else
						flp=false
					end
					-- hit flash timer
					p.hit=max(p.hit-1,0)
					-- collide with map
					p.x,p.y,p.vx,p.vy=collideworld(p.x,p.y,p.vx,p.vy,8,8)
					p.x+=p.vx
					p.y+=p.vy
				elseif active then
					-- too far from player so deactivate
					del(activeenemies,p)
					active=false
				end
			else
				-- enemy is dead
				
				-- remove from active enemies list
				if active then
					del(activeenemies,p)
					active=false
				end
				-- decrease hp (used for respawn timer)
				p.hp-=1
				if p.hp==-5940 and not nearplayer then
					-- don't respawn if too far away from player
					p.hp=-5939
				end
				if p.hp<=-6000 then
					-- respawn
					p.x,p.y,p.vx,p.vy,p.hp=p.sx,p.sy,0,0,enemytype.hp
				elseif p.hp<-5940 and p.hp%3==0 and nearplayer then
					-- create respawn particle effect
					local a=rnd(1)
					local vx,vy=sin(a),-cos(a)
					new_particle(p.sx+vx*8,p.sy+vy*8-5,-vx*0.25,-vy*0.25,rnd(1)>0.5 and 6 or 7,32,0,true)
				end
			end
		end,
		reset=function(p)
			-- reset when player dies but still has lives
			p.x,p.y,p.vx,p.vy,p.hit,p.hp,active=p.sx,p.sy,0,0,0,enemytype.hp,false
		end,
		kill=function(e,nodrop)
			e.hp=0
			sfx(43)
			-- explode
			local cols={2,8,9}
			for i=0,8 do
				new_particle(e.x,e.y-5,(rnd(2)-1)*0.75,-rnd(2),cols[flrrnd(3)+1],30+flrrnd(30),0.15)
			end
			-- nodrop is true when enemies are killed before boss fight starts
			if not nodrop then
				-- if the drop table is empty create a new one
				if #droptable==0 then
					-- for every 31 enemies killed your guaranteed to get 2 powerups and 1 heart
					droptable={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2}
				end
				-- randomly pull entry from drop table
				local drop=droptable[flrrnd(#droptable)+1]
				del(droptable,drop)
				-- if the entry wasn't nothing then spawn pickup
				if drop>0 then
					new_pickup(e.x+2,e.y-4,pickuptypes[drop])
				end
			end
		end,
		draw=function(p)
			-- if not dead draw enemy
			if p.hp>0 then
				-- get animation frame
				local s,ox=sprs[anm[flr(anmf/2)+1]],0
				-- adjust x draw offset if flipped
				if flp then
					ox=8-(s.ox+s[3])
				else
					ox=s.ox
				end
				-- set pal to white if hit
				if p.hit>0 then
					for c=0,15 do
						pal(c,7)
					end
				end
				sspr(s[1],s[2],s[3],s[4],p.x+ox-camx,p.y+s.oy-camy,s[3],s[4],flp)
				pal()
			end
		end
	})
end

function spawn_boss(x,y)
	-- boss sequence {a=action to perform,t=action duration,y=move to position}
	local seq,seqv,seqi,seqt,py,dy,prevhp={{a=3,t=90},{a=2,t=45,y=y-32},{a=3,t=90},{a=2,t=45,y=y+24},{a=3,t=90},{a=2,t=45,y=y+52},{a=3,t=90},{a=4,t=45},{a=1,t=160},{a=4,t=45},{a=1,t=160},{a=4,t=45},{a=1,t=160},{a=2,t=45,y=y}},{a=2,y=y,t=180},0,0,y+100,y,150
	local beam=0
	boss={x=x,y=y+100,sx=x,sy=y,hp=150,hit=0,
		update=function(p)
			if prevhp<=0 then
				-- boss is dying
				sfx(61,-2)
				beam,p.hit=0,0
				-- create explosion every 8 frames
				if waittimer%8==0 then
					local ppx,ppy=flrrnd(20),flrrnd(32)
					for i=0,16 do
						local a=rnd(1)
						local vx,vy=sin(a),-cos(a)
						new_particle(p.x-5+ppx,p.y+ppy,-vx,-vy,rnd(1)>0.5 and 7 or 10,15+flrrnd(8),0,true)
					end
					sfx(43)
				end
				return
			end
			-- move to next action in sequence when current timer has expired
			if seqt>=seqv.t then
				-- increment sequence index
				seqi=(seqi%#seq)+1
				-- get next sequence entry, set timer to 0 and remember our y offset so we can lerp from it
				seqv,seqt,py=seq[seqi],0,p.y
				-- stop beam sound if it was playing
				sfx(61,-2)
				beam=0
				-- get y position for aiming at player
				if player.y<=y then
					dy=y-32
				elseif player.y<=y+32 then
					dy=y
				elseif player.y<=y+56 then
					dy=y+24
				else
					dy=y+52
				end
			end
			-- sequence timer
			seqt+=1
			-- execute current action
			if seqv.a==1 then
				-- action 1: fire big beam
				if seqt<30 and seqt%2==0 then
					-- weapon warm up particles
					local a=rnd(1)
					local vx,vy=sin(a),-cos(a)
					new_particle(p.x-5+vx*8,p.y+24+vy*8,-vx*0.5,-vy*0.5,rnd(1)>0.5 and 9 or 8,15,0,true)
				end
				if seqt>30 and seqt<40 then
					-- red warning line
					new_particle(p.x-5,p.y+24,-7-rnd(4),0,8,10,0,true)
					new_particle(p.x-112,p.y+24,7+rnd(4),0,8,10,0,true)
				end
				if seqt==52 then
					sfx(61,2)
				end
				if seqt>60 then
					-- fire beam
					if seqt%4==0 then
						local a=rnd(1)
						local vx,vy=sin(a),-cos(a)
						new_particle(p.x-5,p.y+24,-vx*0.75,-vy*0.75,7,15,0,true)
					end
					-- wiggle beam width
					if beam>10 then
						beam-=2
					else
						beam+=1
					end
					-- check if beam hit player
					if player.invulnerable==0 and not (player.y<p.y+24-beam or player.y-12>p.y+24+beam) then
						player:hurt()
					end
				end
			elseif seqv.a==3 then
				-- action 3: fire blue bullets
				if seqt<30 and seqt%2==0 then
					-- warm up warning particles
					local a=rnd(1)
					local vx,vy=sin(a),-cos(a)
					new_particle(p.x-5+vx*8,p.y+24+vy*8,-vx*0.5,-vy*0.5,rnd(1)>0.5 and 11 or 12,15,0,true)
				end
				if seqt>30 and seqt%10==0 then
					-- fire
					new_bullet(p.x-4,p.y+25,-1.5,0,0.25,ebsprs,boss)
					new_bullet(p.x-4,p.y+25,-1.4,-0.5,0.25,ebsprs,boss)
					new_bullet(p.x-4,p.y+25,-1.4,0.5,0.25,ebsprs,boss)
				end
			elseif seqv.a==2 then
				-- action 2: move to scripted position
				p.y=smoothlerp(py,seqv.y,seqt/seqv.t)
			elseif seqv.a==4 then
				-- action 4: move to aim at player
				p.y=smoothlerp(py,dy,seqt/seqv.t)
			end
			p.hit=max(p.hit-1,0)
			-- speed up sequence as boss looses hp
			if prevhp~=p.hp and p.hp%10==0 then
				for i=1,#seq do
					seq[i].t-=(i%2==1 and 0 or 2)
				end
			end
			-- remember boss's hp from this frame to check if it decreased
			prevhp=p.hp
			-- boss died
			if prevhp<=0 then
				waitfunc,waittimer,player.invulnerable,beam,p.hit=wingame,360,360,0,0
			end
		end,
		draw=function(p)
			if p.hit>0 then
				for c=0,15 do
					pal(c,7)
				end
			end
			sspr(57,42,13,14,p.x-camx,p.y-camy)
			pal()
			sspr(61,7,24,22,p.x-camx-6,p.y-camy+13)
			-- draw beam
			if beam>0 then
				for i=1,3 do
					local bw,col=beam*(1-i/6),i==1 and 9 or (i==2 and 10 or 7)
					circfill(p.x-bw-6-camx,p.y+25-camy,bw,col)
					rectfill(0,p.y+25-bw-camy,p.x-bw-6-camx,p.y+25+bw-camy,col)
				end
			end
		end
	}
end

function spawn_door(x,y)
	-- door to boss chamber
	door={x=x,y=y,
		draw=function(p)
			-- electrical zappy thing
			local x1,x2,x1p,x2p=0,0,x+flrrnd(8)-4-camx,x+flrrnd(8)-4-camx
			for i=0,5 do
				x1,x2=x+flrrnd(8)-4-camx,x+flrrnd(8)-4-camx
				line(x1p,y-i*4-camy-1,x1,y-i*4-camy-4,11)
				line(x2p,y-i*4-camy-1,x2,y-i*4-camy-4,12)
				x1p,x2p=x1,x2
			end
		end
	}
end

function new_bullet(x,y,vx,vy,a,bullettype,owner)
	local anmf,anmfi=1,1
	add(bullets,{x=x,y=y,vx=vx,vy=vy,a=a,t=80,
		update=function(p)
			p.x+=p.vx
			p.y+=p.vy
			p.t-=1
			-- animate bullet
			if bullettype.anms then
				anmfi=(anmfi%#bullettype.anms)+1
				anmf=bullettype.anms[anmfi]
			else
				anmf=flr((p.a)*16)%16+1
			end
			-- hit is used to determine if the bullet should be deleted
			local hit=p.t<=0 or abs(p.x-player.x)>112 or abs(p.y-player.y)>112
			-- player's bullet
			if owner==player then
				if boss then
					-- hit boss's head
					if p.x>boss.x and p.x<boss.x+12 and p.y>boss.y-1 and p.y<boss.y+16 then
						boss.hp-=1
						boss.hit,hit=5,true
					end
					-- hit boss's body
					if (p.x>boss.x-2 and p.x<boss.x+12 and p.y>boss.y+14 and p.y<boss.y+20) or
						(p.x>boss.x-5 and p.x<boss.x+15 and p.y>boss.y+19 and p.y<boss.y+34) then
						hit=true
					end
					if hit then
						-- hit splash and sfx
						sfx(35)
						for i=0,3 do
							new_particle(p.x,p.y,(rnd(2)-1)*0.5,(rnd(2)-1)*0.5,10,10+flrrnd(5),0,true)
						end
					end
				end
				-- see if we hit an enemy
				for e in all(activeenemies) do
					if e.hp>0 and p.x>e.x+e.hbx1 and p.x<e.x+e.hbx2 and p.y>e.y+e.hby1 and p.y<e.y+e.hby2 then
						e.hit,hit=5,true
						e.hp-=1
						if e.hp==0 then
							e:kill()
						else
							sfx(35)
							for i=0,3 do
								new_particle(p.x,p.y,(rnd(2)-1)*0.5,(rnd(2)-1)*0.5,10,10+flrrnd(5),0,true)
							end
						end
						break
					end
				end
			-- boss's bullet so see if it hit player
			elseif player.invulnerable==0 and p.x>player.x-2 and p.x<player.x+6 and p.y>player.y-13 and p.y<player.y then
				player:hurt()
				hit=true
				for i=0,4 do
					new_particle(p.x,p.y,(rnd(2)-1)*0.5,(rnd(2)-1)*0.5,12,10+flrrnd(5),0,true)
				end
			end
			-- if it hit someone or it hit a wall then delete
			if hit or is_solid(p.x,p.y) then
				del(bullets,p)
			end
		end,
		draw=function(p)
			local s=bullettype[anmf]
			sspr(s[1],s[2],s[3],s[4],p.x+s.ox-camx,p.y+s.oy-camy,s[3],s[4],s.fx,s.fy)
		end
		})
end

function new_pickup(x,y,pickuptype)
	add(pickups,{x=flr(x),y=flr(y),vy=-1,anmf=0,pickuptype=pickuptype,
		update=function(p)
			-- if pickup hasn't hit floor
			if not p.stop then
				local d1,d2,collision=0,0,false
				-- fall
				p.vy=mid(-3,p.vy+0.2,3)
				-- check collision
				p.x,p.y,d1,d2,collision=collideworld(p.x,p.y,0,p.vy,6,4)
				if collision then
					-- bounce
					p.vy=-p.vy*0.5
					-- if bounce amount is very small then stop pickup from moving
					if abs(p.vy)<0.05 then
						p.stop,p.vy,p.y=true,0,flr(p.y)
					end
				end
				p.y+=p.vy
			end
			-- set animation frame
			p.anmf=(p.anmf+1)%(#p.pickuptype.sprs*3)
		end,
		draw=function(p)
			local s=p.pickuptype.sprs[flr(p.anmf/3)+1]
			sspr(s[1],s[2],s[3],s[4],p.x+s.ox-camx,p.y+s.oy-camy,s[3],s[4],s.fx,s.fy)
		end
	})
end

function new_particle(x,y,vx,vy,c,t,g,nonsolid)
	add(particles,{x=x,y=y,vx=vx,vy=vy,c=c or 8,st=t or 60,t=t or 60,g=g or 0.2,nonsolid=nonsolid,
		update=function(p)
			p.vy=min(p.vy+g,7)
			
			-- if particle is solid then bounce
			if not nonsolid then
				if (p.vx>0 or p.vx<0) and is_solid(p.x+p.vx,p.y) then
					p.vx=-p.vx*0.75
					p.vy*=0.9
				end
				if (p.vy>0 or p.vy<0) and is_solid(p.x,p.y+p.vy) then
					p.vy=-p.vy*0.75
					p.vx*=0.9
				end
			end
			
			p.x+=p.vx
			p.y+=p.vy
			
			-- delete when its timer expires
			p.t-=1
			if p.t==0 then
				del(particles,p)
			end
		end,
		draw=function(p)
			local x,y,s=p.x-camx,p.y-camy,flr(p.t/p.st+0.5)
			rectfill(x,y,x+s,y+s,c)
		end
	})
end

function collideworld(x,y,vx,vy,w,h)
	local hhalf,topclip,onground=flr(h/2),h>8 and h-7 or 7,false
	-- only check collision in direction we are moving
	if vx<0 and (is_solid(x+vx,y-1) or is_solid(x+vx,y-hhalf) or is_solid(x+vx,y-(h-1))) then
		x,vx=flr((x+vx)/8)*8+8,0
	end
	if vx>0 and (is_solid(x+vx+w,y-1) or is_solid(x+vx+w,y-hhalf) or is_solid(x+vx+w,y-(h-1))) then
		x,vx=flr((x+vx)/8)*8+8-w,0
	end
	if vy>0 and (is_solid(x,y+vy) or is_solid(x+w-1,y+vy)) then
		-- hit the floor so set onground to true
		y,vy,onground=flr((y+vy)/8)*8,0,true
	end
	if vy<0 and (is_solid(x,y+vy-h) or is_solid(x+w-1,y+vy-h)) then
		y,vy=flr((y+vy)/8)*8+topclip,0
	end
	return x,y,vx,vy,onground
end

function getmbxy(x,y)
	return flr(x/128)+1,flr(y/128)+1
end

function getmb(x,y)
	-- get index into map table
	local mbix,mbiy=getmbxy(x,y)
	-- return x and y index and map block (if outside the map return full solid block)
	return mbix,mbiy,(mbix<1 or mbix>#mgr or mbiy<1 or mbiy>#mgr[mbix]) and nullmap or mgr[mbix][mbiy]
end

function mfget(x,y,f)
	-- get map block from table
	local mbix,mbiy,mb=getmb(x,y)
	-- see if tile on map block is solid
	return fget(mget(flr(x/8)-(mbix-1)*16+mb.mbx,flr(y/8)-(mbiy-1)*16+mb.mby),f)
end

function is_solid(x,y)
	return mfget(x,y,0) or (door and mfget(x,y,4))
end

function playerdie()
	player.lives-=1
	waittimer,waitfunc=240,resetgame
	sfx(41,-2)
	sfx(61,-2)
	sfx(43)
	local cols={1,11,12}
	for i=0,48 do
		new_particle(player.x,player.y-5,(rnd(4)-2),-rnd(4),cols[flrrnd(3)+1],60+flrrnd(90),0.15)
	end
end

function resetgame()
	if player.lives==0 then
		-- game over
		changemode(2)
	else
		-- reset everything and put player back at start
		bullets,activeenemies,particles,pickups={},{},{},{}
		for e in all(enemies) do
			e:reset()
		end
		player:reset()
		if boss then
			-- boss fight so reset the boss and give player max weapon
			player.bcount=5
			spawn_boss(boss.sx,boss.sy)
			music(23,0,3)
		end
	end
end

function wingame()
	changemode(3)
end

function genmap()
	mgr,sx,sy,bullets,enemies,activeenemies,particles,pickups,droptable,keycount,exity={},1,1+flrrnd(h),{},{},{},{},{},{},0,flrrnd(h-1)+1
	-- initialise map grid
	for x=1,w do
		mgr[x]={}
		local removed=(x-1)%3
		for y=1,h do
			-- initialise map cell
			mgr[x][y]={dirs={x~=1 and l,y~=1 and t,x~=w and r,y~=h and b},paths=0,visited=false,x=x,y=y,keytaken=false,frame=-1,dist=0}
			-- right 2 columns of the map
			if x>=w-1 then
				mgr[x][y].visited=true
				-- if this is the row for the exit
				if y==exity then
					mgr[x][y].sp=true
					mgr[x][y].paths=l
					-- second from right is corridor to boss
					if x==w-1 then
						mgr[x][y].paths+=r
						mgr[x-1][y].paths=r
						mgr[x-1][y].dirs[3]=nil
						mgr[x-1][y].endpoint=true
						spawn_door(x*128-60,y*128-64)
						new_pickup(x*128-8,y*128-60,pickuptypes[2])
						new_pickup(x*128-16,y*128-60,pickuptypes[1])
						new_pickup(x*128-24,y*128-60,pickuptypes[2])
						new_pickup(x*128-32,y*128-60,pickuptypes[1])
						new_pickup(x*128-40,y*128-60,pickuptypes[2])
					else
						-- far right is the boss room
						mgr[x][y].boss=true
					end
				end
			-- randomly place solid (non-corridor) areas into map
			elseif x<w-2 and removed>0 and flrrnd(3)==0 then
				mgr[x][y].visited=true
				removed-=1
			end
		end
	end
	-- start poisiton
	mgr[sx][sy].start=true
	-- recurively step through map to create maze
	stepmaze(sx,sy,0)
	-- setup completed maze for gameplay
	for x=1,w do
		for y=1,h do
			local mb=mgr[x][y]
			-- choose prefab block to use
			local prefab=prefabs[mb.paths+1]
			local prefabi=flrrnd(#prefab)+1
			-- visited: used for minimap to know where player has been
			-- enemies: the enemies that spawn here
			-- mbx and mby: the x and y coords for prefab in pico-8 map memory
			-- scr: contains details for computer terminal
			mb.visited,mb.enemies,mb.mbx,mb.mby,mb.scr=false,{},prefab[prefabi][1],prefab[prefabi][2],prefab[prefabi].scr
			-- if this is boss room or entrance corridor
			if mb.sp then
				mb.mbx,mb.mby=prefab.sp[1],prefab.sp[2]
			end
			-- randomise enemy placements
			if mb.dist>0 then
				-- enemy count increases further away from player start
				local ecount=mid(0,ceil((mb.dist-1)/3),12)
				for i=1,ecount do
					-- pick location within this block
					-- x postion increments across block for each enemy
					local px,py=flr((i-1)*ecount/12)+1,flrrnd(12)+1
					-- if it's not a wall
					if not fget(mget(mb.mbx+px,mb.mby+py),0) then
						-- start by choosing flying enemy
						local et=enemy1
						if i%4==0 then
							-- check for ground below enemy
							for ey=py,15 do
								-- if we find ground change to walking enemy
								if fget(mget(mb.mbx+px,mb.mby+ey),0) then
									et,py=enemy2,ey-1
									break
								end
							end
						end
						-- add enemy
						add(mb.enemies,new_enemy(x*128-128+px*8,y*128-120+py*8,et))
					end
				end
			end
		end
    end
	-- create player, remember total number of terminals
	player,keycounttotal=new_player(sx*128-64,sy*128-64),keycount
	camx,camy,flashtime=player.x-64,player.y-64,0
end

function stepmaze(x,y,dist)
	local m=mgr[x][y]
	-- if cell hasn't been visited
	if not m.visited then
		-- mark as visited and record distance from start
		m.dist,m.visited=dist,true
		-- keep track of how many times we couldn't move from this cell to determine when we hit a deadend
		local failcount=#m.dirs
		-- while there are directions we haven't tried to move
		while #m.dirs>0 do
			-- choose direction and remove from the list
			local dir,rsx,rsy=del(m.dirs,m.dirs[flrrnd(#m.dirs)+1]),(x-1)*8,(y-1)*8
			-- try moving in chosen direction
			if dir==l then
				failcount-=setstepvals(m,x-1,y,l,r,dist)
			elseif dir==t then
				failcount-=setstepvals(m,x,y-1,t,b,dist)
			elseif dir==r then
				failcount-=setstepvals(m,x+1,y,r,l,dist)
			elseif dir==b then
				failcount-=setstepvals(m,x,y+1,b,t,dist)
			elseif not dir then
				failcount-=1
			end
		end
		-- if deadend add terminal
		if failcount==0 and not m.endpoint then
			m.key=true
			keycount+=1
		end
		return true
	end
end

function setstepvals(m1,mx,my,dir,backdir,dist)
	if stepmaze(mx,my,dist+1) then
		local m2=mgr[mx][my]
		-- if we succeeded set a path between cells
		m1.paths+=dir
		m2.paths+=backdir
		return 0
	end
	return 1
end

function flrrnd(a)
	return flr(rnd(a))
end

function normalize(x,y,mul)
	local l,m=sqrt(x*x+y*y),mul or 1
	if l<=0 then
		return 0,0
	end
	return x/l*m,y/l*m
end

function lerp(a,b,t)
	return a+(b-a)*t
end

function smoothlerp(a,b,t)
	return a+(b-a)*(t*t*(3-2*t))
end
