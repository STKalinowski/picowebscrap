--friday night funkin' in pico-8
--made by carson k and chris w

function _init()
	poke(0x5f2d,1)
	cartdata("ckcw_fnfp8")
	step = 0
	inc = 509/64--509/32
	logo = 1
	menustate = -1
	fade = 0
	fading = -1
	splash_init()
	music(0)
	synctime = 509
	dset(60,0)
	if(flr(rnd(100)) == 0) logo = 2
end

function _update60()
	--step = stat(26) + (stat(24)*  509)
	if(menustate == 0 or menustate == 1) menu_update()
	if(menustate == -1) splash_update()
	step+=1
	poke(0x5f30,1)
	--if(stat(26) > synctime) synctime = stat(26)
end

function _draw()
	cls()
	palt(0,false)
	palt(9,true)
	rectfill(0,0,128,128,0)
	color(6)
	if(menustate == -1) splash_draw()
	if(menustate == 0 or menustate == 1) menu_draw()
	if fading > -1 then
		if(fading == 0) fade0(ceil(fade))
		if(fading == 1) fade1(ceil(fade))
		if(fading == 2) fade0(15-ceil(fade))
		if(fading == 3) fade1(15-ceil(fade))
		if(fade > 0) fade -= 0.5
		if fade == 0.5 and menustate == 0 and fading == 2 then
			--fade = 15
			--fading = 0
			--menustate = 1
			dset(59,max(0,stat(24)-2))
			load("#fnf_select")
		end
		if fade == 0 and menustate == 1 and fading == 2 then
			--load cart
			if not loading then
				music(-1)
				load(menubtns[state+1][4])
				loading = true
			end
		end
	end
end
-->8
--main menu
function menu_init()
	menustate = 0
	state = 0
	nextstate = -1
	starting = -1
	loading = false
end

function menu_update()
	if nextstate > 0 then
		nextstate -= 1
		if nextstate == 0 then
			fading = 2
			fade = 15
			nextstate = 0
		end
	end
	
	if starting > 0 then
		starting -= 1
		if starting == 0 then
			fading = 2
			fade = 15
		end
	end
	
	if menustate == 0 and nextstate == -1 then
		--press enter to start
		if btnp() == 64 then
			nextstate = 30
			sfx(5,2)
			poke(0x5f30,1)
		end
	end
end

function menu_draw()
	if menustate == 0 then
		rectfill(0,0,128,128,0)
		--girlfriend outline
		for i=0,15 do
			pal(i,12)
		end
		draw_girlfriend(49-1,60)
		for i=0,15 do
			pal(i,14)
		end
		draw_girlfriend(49+1,60+1)
		for i=0,15 do
			pal(i,i)
		end
		--girlfriend
		draw_girlfriend(49,60)
		
		--logo
		draw_logo(logo,63,6)
		
		local _incc = 4
		if(nextstate > 0) _incc = 1
		if flr(step/(inc*_incc))%2 == 1 then
			local _tx = "pRESS eNTER TO bEGIN"
			for i=-1,1 do
				for j=-1,1 do
					print(_tx,i+64-#_tx*2,j+114,0)
				end
			end
			print(_tx,64-#_tx*2,114,7)
		end
	end
end
-->8
--splash screen

function splash_init()
	splashstate = 0
	splashtext = get_splash_text()
	ispresident = flr(rnd(100)) == 0
end

function splash_update()
	if btnp() == 64 then
		splashstate = 0
		menu_init()
		fading = 1
		fade = 15
		poke(0x5f30,1)
	end
	if splashstate == 0 and step >= inc*6 then
		splashstate = 1
	elseif splashstate == 1 and step >= inc*16 then
		splashstate = 2
	elseif splashstate == 2 and step >= inc*22 then
		splashstate = 3
	elseif splashstate == 3 and step >= inc*32 then
		splashstate = 4
	elseif splashstate == 4 and step >= inc*38 then
		splashstate = 5
	elseif splashstate == 5 and step >= inc*48 then
		splashstate = 6
	elseif splashstate == 6 and step >= inc*52 then
		splashstate = 7
	elseif splashstate == 7 and step >= inc*56 then
		splashstate = 8
	elseif splashstate == 8 and step >= inc*60 then
		splashstate = 9
	elseif splashstate == 9 and step >= inc*64 then
		splashstate = 0
		menu_init()
		fading = 1
		fade = 15
	end
end

function splash_draw()
	--print(splashtext[1],63,63)
	local _tx = ""
	if splashstate == 0 or splashstate == 1 then
		_tx = "cARSON kOMPON"
		print(_tx,64-#_tx*2,54)
		_tx = "& cHRIS wEST"
		print(_tx,64-#_tx*2,60)
		if splashstate == 1 then
			_tx = "present"
			if(ispresident) _tx = "& tHE pRESIDENT"
			print(_tx,64-#_tx*2,66)
		end
	elseif splashstate == 2 or splashstate == 3 then
		_tx = "originally created by:"
		print(_tx,64-#_tx*2,48)
		if splashstate == 3 then
			_tx = "nINJAmUFFIN"
			print(_tx,64-#_tx*2,54)
			_tx = "pHANTOMaRCADE"
			print(_tx,64-#_tx*2,60)
			_tx = "kAWAIsPRITE"
			print(_tx,64-#_tx*2,66)
			_tx = "eVILsKER"
			print(_tx,64-#_tx*2,72)
		end
	elseif splashstate == 4 or splashstate == 5 then
		_tx = splashtext[1]
		print(_tx,64-#_tx*2,56)
		if splashstate == 5 then
			_tx = splashtext[2]
			print(_tx,64-#_tx*2,62)
		end
	elseif splashstate == 6 or splashstate == 7 or splashstate == 8 or splashstate == 9 then
		_tx = "fRIDAY"
		print(_tx,64-#_tx*2,52)
		if splashstate >= 7 then
			_tx = "nIGHT"
			print(_tx,64-#_tx*2,58)
			if splashstate >= 8 then
				_tx = " fUNKIN'"
				print(_tx,64-#_tx*2,64)
				if splashstate >= 9 then
					_tx = "pico-8"
					print(_tx,64-#_tx*2,70)
				end
			end
		end
	end
end

--splash texts
function get_splash_text()
	local _splashs = "SHOUTOUTS TO TOM FULP:LMAO|DA BABY:BIGGEST INSPIRATION|THIS GAME IS DEDICATED TO RINGO:MY FAVORITE BEATLE|THAT'S A HEALTHY LOOKING PENIS:THAT'S AN AMERICAN PENIS|pico-8 EXCLUSIVE:SPLASH TEST|REFINED TASTE IN MUSIC:IF I SAY SO MYSELF|SWAGSHIT:MONEYMONEY|RHYTHM GAMING:DEMADE|RITZ DX:REST IN PEACE LOL|nEWGROUNDS IS DOWN!:pLEASE sTAND bY ♥ |BACK THE FULL ASS GAME:NOW|NEWGROUNDS:FOREVER|RATE FIVE:PLS NO BLAM|GAME OF THE YEAR:FOREVER|STREAM CHUCKIE FINSTER:ON SPOTIFY|NEVER FORGET TO:PRAY TO GOD|LIKE PARAPPA:BUT COOLER|HATSUNE MIKU:BIGGEST INSPIRATION|WOMEN ARE REAL:THIS IS OFFICIAL|DANCIN:FOREVER|DOPE ASS GAME:PLAYSTATION MAGAZINE|GO MANGO:GO MANGO|DONT PLAY RUST:WE ONLY FUNKIN'|GOODBYE:MY PENIS|HOW I ACCIDENTALLY:MADE FNF IN pico-8|YOOOOOOOOO:yooooooooo|YOU ALREADY KNOW:WE REALLY OUT HERE| :WE HAVE FUN HERE|CLOUD BASHERS:BEST RHYTHM GAME|SUPER PICKLE MILK:ITS THE SAME THING|TURNIP BOY:COMMITS FUNK EVASION|THE LAST FUNK:PIPIN' HOT|PERFECT LAWN:ONE BROWN SPOT|wEEK 7:YES ITS HERE|YOURE SO SUSSY:I KNOW YOU TOOK MY FORTNITE CARD|$19 FORTNITE CARD:WHO WANTS IT?|DARNELL FOR PRESIDENT!:HE STILL HAS 5 YEARS TO LIVE|THAT'LL BE 15 DOLLARS:YOU ARE THE PRESIDENT| :NAME A WOMAN|FUCKIN' STEAK BABY:YEAH|NINJAMUFFIN'S BEEN REAL QUIET:SINCE WEEK 7 DROPPED|DOWNSCROLL:NEVER HEARD OF IT|WE ACTUALLY FUCKING:UPDATED IT|YES...:WE ADDED WEEK 2|CHECK OUT THE MODS:ON LEXALOFFLE|THE MODDING SCENE:IS INSANE|I ADDED MORE:SPLASH TEXT|NOW WITH:WEEK 2|HORSE:OOH AH OOH AH|WEEK 8:NEVER HAPPENING LMAO|JINGLE:BALLS| :PROBLEM NOOB?|WE UPDATED IT:TWICE|WE NEED:MORE SPLASH TEXT|WE MADE WEEK 5:IN A DAY|GO PICO GO GO:GO PICO, YEAH|YOU CAN USE dfjk NOW:CRY ABOUT IT|dfjk IS REAL:THIS IS OFFICIAL|KEYBINDS?:WHAT?|FUNKY-US MCPUNK:HE'S FUNKING OUT HIS PUNK|WE HAVE ALL THE WEEKS NOW:YES, ACTUALLY|DID YOU KNOW JOE SWANSON SAYS:FORTNITE IN FAMILY GUY LOL"
	local _splash = split(_splashs,"|")
	return split(_splash[flr(rnd(#_splash))+1],":")
end
-->8
--fades

--fade to black
local fadetable0={
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1,1,1,1,1,1,1,0,0,0,0,0,0,0,0},
{2,2,2,2,2,2,1,1,1,0,0,0,0,0,0},
{3,3,3,3,3,3,1,1,1,0,0,0,0,0,0},
{4,4,4,2,2,2,2,2,1,1,0,0,0,0,0},
{5,5,5,5,5,1,1,1,1,1,0,0,0,0,0},
{6,6,13,13,13,13,5,5,5,5,1,1,1,0,0},
{7,6,6,6,6,13,13,13,5,5,5,1,1,0,0},
{8,8,8,8,2,2,2,2,2,2,0,0,0,0,0},
{9,9,9,4,4,4,4,4,4,5,5,0,0,0,0},
{10,10,9,9,9,4,4,4,5,5,5,5,0,0,0},
{11,11,11,3,3,3,3,3,3,3,0,0,0,0,0},
{12,12,12,12,12,3,3,1,1,1,1,1,1,0,0},
{13,13,13,5,5,5,5,1,1,1,1,1,0,0,0},
{14,14,14,13,4,4,2,2,2,2,2,1,1,0,0},
{15,15,6,13,13,13,5,5,5,5,5,1,1,0,0}
}

function fade0(i)
for c=0,15 do
  if flr(i+1)>=16 then
pal(c,0,1)
else
pal(c,fadetable0[c+1][flr(i+1)],1)
end
 end
end

-- fade to white
local fadetable1={
{0,0,1,1,5,5,5,13,13,13,6,6,6,6,7},
{1,1,5,5,13,13,13,13,13,6,6,6,6,6,7},
{2,2,2,13,13,13,13,13,6,6,6,6,6,7,7},
{3,3,3,3,13,13,13,13,6,6,6,6,6,7,7},
{4,4,4,4,4,14,14,14,15,15,15,15,15,7,7},
{5,5,13,13,13,13,13,6,6,6,6,6,6,7,7},
{6,6,6,6,6,6,6,6,7,7,7,7,7,7,7},
{7,7,7,7,7,7,7,7,7,7,7,7,7,7,7},
{8,8,8,8,14,14,14,14,14,14,15,15,15,7,7},
{9,9,9,10,10,10,15,15,15,15,15,15,15,7,7},
{10,10,10,10,10,15,15,15,15,15,15,15,7,7,7},
{11,11,11,11,11,11,6,6,6,6,6,6,6,7,7},
{12,12,12,12,12,12,6,6,6,6,6,6,7,7,7},
{13,13,13,13,6,6,6,6,6,6,6,6,7,7,7},
{14,14,14,14,14,15,15,15,15,15,15,7,7,7,7},
{15,15,15,15,15,15,15,7,7,7,7,7,7,7,7}
}

function fade1(i)
 for c=0,15 do
  if flr(i+1)>=16 then
   pal(c,7,1)
  else
      pal(c,fadetable1[c+1][flr(i+1)],1)
     end
 end
end
-->8
--draw chars
function draw_girlfriend(_x,_y)
	if flr(step/(inc*4))%2==0 then
		sspr(2,95,13,15,_x+30,_y+31)
		sspr(2,95,13,15,_x-12,_y+31,12,15,true)
		sspr(0,0,30,46,_x,_y)
	else
		sspr(15,95,12,15,_x+30,_y+31)
		sspr(15,95,12,15,_x-12+1,_y+31,11,15,true)
		sspr(0,46,30,47,_x,_y-1)
	end
end
-->8
--draw logo

function draw_logo(_id,_x,_y)
	if _id == 0 then
		sspr(58,0,70,42,_x-35,_y)
	elseif _id == 1 then
		sspr(57,43,71,42,_x-35,_y)
	elseif _id == 2 then
		sspr(58,86,70,43,_x-35,_y)
	end
end