--the.green.legion
--by guerragames 
cartdata("the_green_legion")

time=0
one_frame=.0333333
file=0
shake_t=0

function get_file()
 local fi=file*4
 cur_score=dget(fi)
 cur_gp=dget(fi+1)
 cur_lvl=dget(fi+2)
 cur_gm=dget(fi+3)

 if cur_lvl<1 or cur_lvl>10 then
  cur_lvl=1
 end 

 ps_level=1
 ps_active_count=1
 ps_max_active_count=1
 ps_shoot_rate=.3
 ps_pshoot_cdown=10
 ps_pshoot_damage=10
end

function store_file()
 local fi=file*4
 dset(fi,cur_score)
 dset(fi+1,cur_gp)
 dset(fi+2,cur_lvl)
 dset(fi+3,cur_gm)
end

function save_and_reset()
 cur_gm+=1
 store_file()
 run()
end

function reset_score()
 cur_score=0
 cur_gp=0
 cur_lvl=1
 cur_gm=0
 store_file()
 run()
end

function nl(s)
 local a={}
 local ns=""
 
 while #s>0 do
  local d=sub(s,1,1)
  if d=="," then
   add(a,ns+0)
   ns=""
  else
   ns=ns..d
  end
  
  s=sub(s,2)
 end
 
 return a
end

function unpack(y,i)
 i=i or 1
 local g=y[i]
 if(g)return g,unpack(y,i+1)
end

align_c,align_l,align_r=0,1,2

function po(t,x,y,c,bc,a)
  local ox=#t*2 
  if a==align_l then
   ox=0
  elseif a==align_r then
   ox=#t*4
  end
  local tx=x-ox
  color(bc)
  print(t,tx-1,y)print(t,tx-1,y-1)print(t,tx,y-1)print(t,tx+1,y-1)
  print(t,tx+1,y)print(t,tx+1,y+1)print(t,tx,y+1)print(t,tx-1,y+1)
  print(t,tx,y,c)
end

function normalize(x,y)
  local m=sqrt(x*x+y*y)
  return x/m,y/m,m
end

function force_sep(fo,mo,min_sep,max_sep)
  local xdiff,ydiff=fo.x-mo.x,fo.y-mo.y
  local nx,ny,mag=normalize(xdiff,ydiff)
  local min_sep,max_sep=mag-min_sep,mag-max_sep
  if max_sep>0 then
   mo.x+=nx*max_sep
   mo.y+=ny*max_sep
  elseif min_sep<0 then
   mo.x+=nx*min_sep
   mo.y+=ny*min_sep
  end
end

function rnd_i(c)
 return flr(rnd(c))+1
end

function next_i(l,i)
 i+=1
 if(i>#l)i=1
 return i
end

function lerp(min,max,t)
 return min+(max-min)*t
end

function rnd_range(min,max)
 if min and max then
  return lerp(min,max,rnd())
 end
 return 0
end

function scr_text(val)
 local s,v="",abs(val)
 repeat
  s=shl(v%0x0.000a,16)..s
  v/=10
 until v==0
 
 if val<0 then
  s="-"..s
 end
 
 return s
end

function gp_perc(p)
 return 1+p*cur_gp
end

sf={}
sf_next,sf_scroll_speed,sf_max_speed,sf_target_rate,sf_rate,sf_to_spawn=1,.3,10,2,1.5,0

for i=1,200 do
 s={lasty=-1,blink=5,bt=5}
 add(sf,s)
end

function sf_init()
 for k,s in pairs(sf)do
  s.y=128
 end

 sf_rate=0
end

function sf_update()
 sf_to_spawn+=sf_rate

  while sf_to_spawn>1 do
   local s=sf[sf_next]
   s.speed=rnd(sf_max_speed)
   s.x,s.y=rnd_i(128),-rnd(sf_scroll_speed+s.speed)
   s.lasty=s.y
   s.blink=rnd(.2)
   s.bt=s.blink
   sf_next=next_i(sf,sf_next)
   sf_to_spawn-=1
  end

 for k,s in pairs(sf)do
  s.lasty=s.y
  if s.y<128 then
   s.y+=s.speed+sf_scroll_speed
  else
   s.y=128
  end
 end
end

function sf_draw()
 for k,s in pairs(sf)do
  s.bt-=one_frame
  if s.bt<=0 then
   s.bt=s.blink
   s.color=(s.color==5)and 6 or 5
  end
  line(s.x,s.lasty,s.x,s.y,s.color)
 end
end

bs={}
bs_next=1
bs_cos={}
bs_sin={}

for i=1,101 do
  local angle=i/100
  add(bs_cos,cos(angle))
  add(bs_sin,sin(angle))
end

bs_lines={"boom!","bang!","bam!","pow!"}
bs_b_lines={"ka-booooooom!","ka-baaaaaang!","ka-baaaaaam!","ka-poooooow!"}

for i=1,20 do
 local boom={}
 for j=1,21 do
  add(boom,{})
 end
 
 add(bs,boom)
end

function bs_reset()
 for k,boom in pairs(bs)do
  boom.active=false
 end
end

function bs_spawn(x,y,min_size,max_size,max_time,bl,flash)
 local boom=bs[bs_next]
 boom.max_time=max_time
 boom.t=0
 boom.x,boom.y=x,y
 boom.flash=flash
 boom.active=true
 boom.text=nil
 
 if bl then
  boom.text=bl[rnd_i(#bl)]
 end
 
 boom.a_offset=rnd()

 for i=1,21 do
  local b=boom[i]
  b.r=0
  b.a=i/20
  b.max_r=min_size+rnd((max_size-min_size)*(i%2))
 end
 
 bs_next=next_i(bs,bs_next)
end


function bs_update()
 for k,boom in pairs(bs)do
  if boom.active then 
   boom.t+=one_frame
 
   for j=1,21 do
    local b=boom[j]
    b.r=b.max_r*boom.t/.2
    if b.r>b.max_r then
     b.r=b.max_r
    end
   end  
  
   if boom.t>=boom.max_time then
    boom.active=false
   end
  end
 end
end

function bs_index_to_ai(boom,i)
 return flr(1+100*(boom.a_offset+i/20)%100)
end

function bs_draw_l(boom,i1,i2,c,offr)
 local cx,cy=boom.x,boom.y
 local a1,a2=bs_index_to_ai(boom,i1),bs_index_to_ai(boom,i2)
 local m1,m2=boom[i1].r+offr,boom[i2].r+offr
 line(cx+m1*bs_cos[a1],cy+m1*bs_sin[a1],cx+m2*bs_cos[a2],cy+m2*bs_sin[a2],c)
end

function bs_draw()
 for k,boom in pairs(bs)do
  if boom.active then 
   if boom.flash and boom.t<.1 then
    rectfill(0,0,128,128,7)
    return
   end 
   
   local color,ocolor=10,8

   for j=2,19 do
    bs_draw_l(boom,j,j+1,ocolor,-4)
    bs_draw_l(boom,j,j+1,ocolor,-2)
   end

   bs_draw_l(boom,20,1,ocolor,-4)
   bs_draw_l(boom,1,2,ocolor,-4)
   bs_draw_l(boom,20,1,ocolor,-2)
   bs_draw_l(boom,1,2,ocolor,-2)

   for j=2,19 do
    bs_draw_l(boom,j,j+1,color,0)
   end

   bs_draw_l(boom,20,1,color,0)
   bs_draw_l(boom,1,2,color,0)

   if boom.text then
    po(boom.text,boom.x+2,boom.y-3,9+(boom.t*12)%2,0)
   end
  end
 end
end

exs={}
exs_next=1

for i=1,20 do
 local ex={} 
 ex.timer=0
 ex.bits={}

 for j=1,20 do
  add(ex.bits,{})
 end
 
 add(exs,ex)
end

function exs_reset()
 for k,ex in pairs(exs)do
  ex.timer=0
 end
end

function make_ex(x,y,size,dsize,speed,timer)
 local ex=exs[exs_next]
 
 ex.timer=timer

 for k,bit in pairs(ex.bits)do
  bit.x,bit.y=x,y
  local dx,dy,mag=normalize(rnd_range(-1,1),rnd_range(-1,1))
  local s=speed+rnd(2)
  bit.size,bit.dsize=size,dsize
  bit.dx,bit.dy=dx*s,dy*s
 end
 
 exs_next=next_i(exs,exs_next)
end

function exs_update()
 for k,ex in pairs(exs)do
  if ex.timer>0 then
   ex.timer-=one_frame
   local alive_count=0
   for k,bit in pairs(ex.bits)do
    bit.dx*=.9
    bit.dy*=.9
    bit.x+=bit.dx
    bit.y+=bit.dy
	bit.size+=bit.dsize
    if bit.size>0 then
     alive_count+=1
    end
   end
   if alive_count==0 then
    ex.timer=0
   end
  end
 end
end

function exs_subdraw(ex,size_offset,color)
 for k,bit in pairs(ex.bits)do
  circfill(bit.x,bit.y,bit.size+size_offset,color)
 end
end

function exs_draw()
 for k,ex in pairs(exs)do
  if ex.timer>0 then
   exs_subdraw(ex,1,5)
   exs_subdraw(ex,0,6)
  end
 end
end

ps={}

ps_level=1
ps_max_active_count=1
ps_shoot_rate=.3
ps_pshoot_cdown=10
ps_pshoot_damage=10

ps_active_count=1

attack_held=0
attack_queued=false

ps_shoot_timer=0
pattack_held=0

pattack_anim=nl("0,0,0,0,0,0,0,0,0,0,2,2,2,4,4,")

function player_init(p,i)
 p.active=false
 p.x,p.y=66,136
 p.spr=i-1
 p.pattack_i=#pattack_anim+1
 p.cdown=0
 p.muzzle_flash,p.blink=0,0
end

for i=1,8 do
 local p={}  
 player_init(p,i)
 add(ps,p)
end

function ps_reset_ng()
 for k,p in pairs(ps) do
  p.active=false
 end
 
 for i=1,ps_max_active_count do
  local p=ps[i]
  p.x,p.y=60,136+8*i
  p.active=true
  p.cdown=0
  p.getting_back=true
 end

 ps_active_count=ps_max_active_count
end
 
function ps_reset_nl()
 for i=ps_active_count+1,ps_max_active_count do
  local p=ps[i]
  p.x,p.y=60,136
  p.active=true
  p.cdown=0
  p.getting_back=true
 end

 ps_active_count=ps_max_active_count
end

function add_to_score(amount,enemy_health)
 if enemy_health>0 then
  cur_score+=shr(amount,16)
 else
  cur_score+=shr(amount+enemy_health,16)
 end
end

function upgrade_row(n,s,t)
 return {score=shr(n,s),type=t}
end

upgrade_table =
{
 upgrade_row(100,16,1),upgrade_row(200,16,2),upgrade_row(400,16,3),
 upgrade_row(800,16,1),upgrade_row(1300,16,2),upgrade_row(2000,16,3),
 upgrade_row(3000,16,1),upgrade_row(4500,16,2),upgrade_row(6500,16,3),
 upgrade_row(9000,16,1),upgrade_row(12000,16,2),upgrade_row(16000,16,3),
 upgrade_row(21000,16,1),upgrade_row(27000,16,2),upgrade_row(32000,16,3),
 upgrade_row(32000,15,1),upgrade_row(32000,14,2),upgrade_row(32000,13,3),
 upgrade_row(32000,12,1),upgrade_row(32000,11,2),upgrade_row(32000,10,3),
 upgrade_row(32000,9,1),upgrade_row(32000,8,2),upgrade_row(32000,7,3),
}

function next_upgrade_txt()
 local next_upgrade=upgrade_table[ps_level]
 if next_upgrade then
  return "nxt:"..scr_text(next_upgrade.score)
 end
 return "max lvl!"
end

function ps_upgrades_update()
 local upgraded=true
 while upgraded do
  upgraded=false
  local lv_upgrade=upgrade_table[ps_level]

  if lv_upgrade then
   if cur_score>=lv_upgrade.score then
    upgraded=true
    ps_level+=1
  
    if lv_upgrade.type==1 then
     if ps_max_active_count<#ps then
      ps_max_active_count+=1
      ps_active_count+=1
    
      local new_ship=ps[ps_active_count]
      new_ship.x,new_ship.y=56,128
      new_ship.active=true
      new_ship.cdown=0
      new_ship.getting_back=true
     end
    elseif lv_upgrade.type==2 then
     if ps_shoot_rate>0.1 then
      ps_shoot_rate-=0.025
     end
    elseif lv_upgrade.type==3 then
     if ps_pshoot_cdown>6 then
      ps_pshoot_cdown-=.5
      ps_pshoot_damage*=2
     end
    end
   end
  end
 end
end

function ps_player_bounds()
 local p1=ps[1]
 return p1.x+3,p1.y+1,p1.x+3,p1.y+3
end

function pshoot_collision_checker(bullet,x,y,x2,y2)
 local xmin=ps[1].x
 return x<=xmin+8 and x2>=xmin
end

function ps_check_pshoot()
 local xmin=ps[1].x
 for k,eb in pairs(ebs)do
  eb.active=false
 end 
 
 for k,e in pairs(es)do
  if e.active then
   local emin_x,emin_y,emax_x,emax_y=es_enemy_bounds(e)
   
   if emin_x<=xmin+8 and emax_x>=xmin then
    es_damage(e,ps_pshoot_damage,emin_x+e.spr_width/2,emax_y)
   end   
  end
 end
 
 boss_check_damage(ps[1],5,pshoot_collision_checker)
end

function ps_pshoot()
 if ps[2].active and
    ( ps[2].cdown<=0 and ps[2].pattack_i>#pattack_anim ) then
  sfx(1)
  
  shake_t=.2
 
  local splayer=ps[1]
  ps_check_pshoot(splayer)
  
  for i=2,ps_active_count do
   if ps[i].active then
    ps[i-1]=ps[i]
   end
  end 

  splayer.pattack_i=1
  splayer.y=2
  ps[ps_active_count]=splayer
 end 
end

function ps_check_seps()
 for i=2,ps_active_count do
  local p=ps[i]
  if p.active then
   if not p.getting_back then
    if p.pattack_i>#pattack_anim then
     force_sep(ps[i-1],p,10,10)
     force_sep(ps[1],p,10+2*i-4,i*10)
    end
   end
  end
 end
end

function ps_update_shooting()
 if btn(4)then
  if attack_held==0 then
   attack_queued=true
  end

  attack_held+=one_frame
 else
  attack_held=0
 end
 
 if attack_held>0 or attack_queued then
  if ps_shoot_timer <=0 then
   sfx(0)
 
   for k,p in pairs(ps) do
    if p.active and p.cdown<=0 then
     bullets_make_bullet(p.x+2,p.y-3)
     p.muzzle_flash=0.05
    end
   end
   ps_shoot_timer=ps_shoot_rate
   attack_queued=false
  end
 end
 
 ps_shoot_timer-=one_frame
end

function ps_explode()
 local p1=ps[1]

 sfx(7)
 for i=1,4 do
  make_ex(p1.x+2+rnd(4),p1.y+2+rnd(4),8+rnd(4),-0.2,2,4)
 end
 
 local x,y=p1.x+4,p1.y+4
 
 bs_spawn(x,y,12,40,.7)
 bs_spawn(x,y,8,30,.7)
 bs_spawn(x,y,6,20,.7,bs_lines)
 
 shake_t=.5

 for i=2,ps_active_count do
  if ps[i].active then
   ps[i-1]=ps[i]
  end
 end  
 
 p1.active=false
 ps[ps_active_count]=p1
 
 ps_active_count-=1
 
 local new_p1=ps[1]
 if ps_active_count<=0 or new_p1.cdown>0 then
  gameover=true
  title_timer=0
  cur_gm+=1
  store_file()
 else
  new_p1.blink=3
 end
end

function ps_check(x,y,x2,y2)
 local p1=ps[1]
 
 if p1.blink<=0 then
  local xmin,ymin,xmax,ymax=ps_player_bounds()

  if x <=xmax and x2>=xmin and
     y <=ymax and y2>=ymin then
   ps_explode()
   return true
  end
 end
 
 return false
end

function ps_update()
 local p1=ps[1]
 
 if p1.muzzle_flash>0 then
  p1.muzzle_flash-=one_frame
 end
 
 if p1.blink>0 then
  p1.blink-=one_frame
 end

 local speed=(attack_held>0.2)and 1 or 2
 
 if btn(0)then
  p1.x-=speed
 end

 if btn(1)then
  p1.x+=speed
 end

 if btn(2)then
  p1.y-=speed
 end

 if btn(3)then
  p1.y+=speed
 end

 p1.x,p1.y=max(0,min(121,p1.x)),max(0,min(120,p1.y))

 ps_check_seps()
 ps_update_shooting()

 -- power attack
 if btn(5)then
  if pattack_held==0 then
   ps_pshoot()
  end

  pattack_held+=one_frame
 else
  pattack_held=0
 end
 
 for i=2,ps_active_count do
  local p=ps[i]
  if p.active then
   if p.muzzle_flash>0 then
    p.muzzle_flash-=one_frame
   end  
  
   if p.pattack_i<=#pattack_anim then
    p.pattack_i+=1
    
    if p.pattack_i>#pattack_anim then
     p.cdown=ps_pshoot_cdown
     p.getting_back=true
    end
   end
   
   if p.cdown>0 then
    p.cdown-=one_frame
   end 

   if p.getting_back then
    local pi2=ps[i-1]
      
    local nx,ny,mag=normalize(pi2.x-p.x,pi2.y-p.y)
      
    if mag<=10 then
     p.getting_back=false
    else
     p.x+=nx*2
     p.y+=ny*2
    end
   end
  end
 end
 
 ps_upgrades_update()
end

function ps_spr_draw(p,ox,oy,r)
 local x,y=p.x+ox,p.y+oy
 spr((r>.5)and 192 or 193,x+2,y+7)
 spr(p.spr,x,y)
end

function pal_color(c)
 for i=1,15 do
  pal(i,c)
 end
end

function ps_draw_shadows(p,r,c)
 pal_color(c or 0)
 ps_spr_draw(p,1,0,r)
 ps_spr_draw(p,-1,0,r)
 ps_spr_draw(p,0,1,r)
 ps_spr_draw(p,0,-1,r)
 pal()
 
 if p.muzzle_flash>0 then
  circfill(p.x+3,p.y-1,3,10)
 end  
end

function ps_draw_secondary()
 for i=ps_active_count,2,-1 do
  local p=ps[i]
  
  if p.active then
   local r=rnd()
   ps_draw_shadows(p,r)
 
   if p.cdown>0 then
    pal(7,8)
    pal(6,2)
   elseif p.pattack_i<#pattack_anim then
    local anim_frame=pattack_anim[p.pattack_i]
    local px,py=p.x-2,p.y-2
  
    spr(16+anim_frame,px,py,2,1)
 
    for ty=1,13 do
     spr(32+anim_frame,px,py+ty*8,2,1)
    end
    
    spr(48+anim_frame,px,py+112,2,1)
    pal(7,8)
    pal(6,2)
   else  
    pal(7,5)
    pal(6,1)
   end

   ps_spr_draw(p,0,0,r)
  end
 end
end

function ps_draw_first()
 local p1=ps[1]
 local should_blink=p1.blink>0 and p1.blink%.2>=.1
 if not should_blink then
  local r=rnd()
  ps_draw_shadows(p1,r,ebs_blink_on and 9 or 0)
  --ps_draw_shadows(p1,r,0)
  
  --if(ebs_blink_on)pal(7,13)
  ps_spr_draw(p1,0,0,r)
 end
end

bullets={}
bullets_anim=nl("241,242,243,242,")
bullets_next=1

for i=1,200 do
 add(bullets,{})
end

function bullets_make_bullet(x,y)
 local nb=bullets[bullets_next]
 nb.x,nb.y=x,y
 nb.active=true
 nb.anim_index=1
 bullets_next=next_i(bullets,bullets_next)
end

function bullets_check(b,x,y,x2,y2)
 return b.x+4>=x and b.x-1<=x2 and b.y+8>=y and b.y<=y2
end

function bullets_update()
 for k,b in pairs(bullets)do
  if b.active then
   if b.y>0 then
    b.y-=5
    b.anim_index=next_i(bullets_anim,b.anim_index)
   else
    b.active=false
   end
  end
 end
end

function bullets_draw()
 for k,b in pairs(bullets)do
  if b.active then
   spr(bullets_anim[b.anim_index],b.x,b.y)
  end
 end
end

ebs={}
ebs_next=1
ebs_blink=0
ebs_blink_on=true

for i=1,2000 do
 add(ebs,{})
end

function ebs_reset()
 for k,eb in pairs(ebs)do
  eb.active=false
 end
end

function ebs_make_bullets(x,y,speed,count,inc_a,start_a)
 sfx(5)
 local ia=start_a
 for i=1,count do
  local eb=ebs[ebs_next]
  eb.x,eb.y=x,y
  eb.velx,eb.vely=speed*sin(ia),speed*cos(ia)
  eb.active=true
  ebs_next=next_i(ebs,ebs_next)
  
  ia-=inc_a
 end 
end

function ebs_update()
 if ebs_blink<=0 then
  ebs_blink=.05
  ebs_blink_on=not ebs_blink_on
 else
  ebs_blink-=one_frame
 end

 for k,eb in pairs(ebs)do
  if eb.active then
   if eb.y<-8 or eb.x<-8 or eb.y>142 or eb.x>142 then
    eb.active=false
   else
	eb.y+=eb.vely
    eb.x+=eb.velx

	if not gameover then
     if ps_check(eb.x,eb.y,eb.x+3,eb.y+3)then
	  eb.active=false
	 end
    end
   end
  end
 end
end

function ebs_draw()
 pal()

 if ebs_blink_on then
  pal(14,8)
 end
  
 for k,eb in pairs(ebs)do
  if eb.active then
   spr(224,eb.x,eb.y)
  end
 end
 
 pal()
end

function ebs_shoot_aimed(x,y,speed,count,angle)
 local to_player_x,to_player_y=ps[1].x-x,ps[1].y-y
 local nx,ny,mag=normalize(to_player_x,to_player_y)
 local a=atan2(ny,nx)
 ebs_make_bullets(x,y,speed,count,angle/count,a+.5*angle)
end

function ebs_shoot_spread(x,y,speed,count,angle)
 ebs_make_bullets(x,y,speed,count,1/count,angle)
end

boss_x=20
boss_y=8

boss_active=false
boss_exploding_timer=0
boss_desc = nil

parts={}
max_parts_w=9
max_parts_h=11

thruster_parts=nl("252,253,254,255,")

flame_parts={
 { idle=nl("236,236,237,237,")},
 { idle=nl("238,238,239,239,")},
}

glue_parts=nl("201,202,203,204,205,206,207,217,218,219,220,221,222,234,235,250,251,")

shooter_parts={
 {
  idle=nl("199,"),
  open=nl("199,199,199,199,198,197,196,196,196,196,197,198,"),
  shoot=nl("197,196,"),
  close=nl("196,197,198,199,"),
  dead=nl("200,"),
 },
 {
  idle=nl("215,"),
  open=nl("215,214,213,212,213,214,"),
  shoot=nl("213,212,"),
  close=nl("212,213,214,215,"),
  dead=nl("216,"),
 },
 {
  idle=nl("231,"),
  open=nl("231,230,229,228,229,230,"),
  shoot=nl("229,228,"),
  close=nl("228,229,230,231,"),
  dead=nl("232,"),
 },
 {
  idle=nl("247,"),
  open=nl("247,246,245,244,245,246,"),
  shoot=nl("245,244,"),
  close=nl("244,245,246,247,"),
  dead=nl("248,"),
 },
}

for j=1,max_parts_h do
 add(parts,{})
 for i=1,max_parts_w do
  add(parts[j],{})
 end
end

function boss_reset()
 boss_active,boss_phase,boss_exploding_timer,boss_base_y=false,0,0,-128
end

function add_thruster(j,i)
 local t1=parts[j-1][i]
 t1.active,t1.shooter,t1.anims=true,false,nil
 t1.spr=thruster_parts[rnd_i(#thruster_parts)]
 
 local t1=parts[j-2][i]
 t1.active,t1.shooter=true,false
 t1.anims=flame_parts[rnd_i(#flame_parts)]
 t1.current_anim,t1.anim_index,t1.anim_time=t1.anims.idle,1,0
end

function boss_init_shooter_part(part)
 part.active,part.shooter=true,true
 part.anims=shooter_parts[rnd_i(#shooter_parts)]
 
 part.current_anim,part.anim_index,part.anim_time,part.shooting_timer=part.anims.idle,1,0,0
 
 part.aimed = (rnd() < boss_desc.aimed_bullet_chance)

 part.shoot_rate=rnd_range(boss_desc.min_shoot_rate,boss_desc.max_shoot_rate)/gp_perc(.01)

 part.bullet_speed=rnd_range(boss_desc.min_bullet_speed,boss_desc.max_bullet_speed)
 
 part.bullet_count=min(40,flr(rnd_range(boss_desc.min_bullet_count,boss_desc.max_bullet_count)*gp_perc(.1)))
 
 part.closed_time=rnd_range(boss_desc.min_closed_time,boss_desc.max_closed_time)
 part.opened_time=rnd_range(boss_desc.min_opened_time,boss_desc.max_opened_time)
 part.bullet_a=0
 part.bullet_a_inc=rnd_range(boss_desc.min_bullet_a_inc,boss_desc.max_bullet_a_inc)
 part.bullet_a_spread=rnd_range(boss_desc.min_bullet_a_spread,boss_desc.max_bullet_a_spread)

 part.lifetime=0
 part.health=boss_desc.health*gp_perc(.2)
end

function clone_part(t_part,s_part)
 t_part.active,t_part.shooter,t_part.anims,t_part.spr=s_part.active,s_part.shooter,s_part.anims,s_part.spr
 t_part.current_anim,t_part.anim_index,t_part.anim_time=s_part.current_anim,s_part.anim_index,s_part.anim_time
 t_part.shooting_timer,t_part.aimed,t_part.shoot_rate=s_part.shooting_timer,s_part.aimed,s_part.shoot_rate
 t_part.bullet_speed,t_part.bullet_count,t_part.closed_time,t_part.opened_time=s_part.bullet_speed,s_part.bullet_count,s_part.closed_time,s_part.opened_time
 t_part.bullet_a=0
 t_part.bullet_a_inc,t_part.bullet_a_spread=s_part.bullet_a_inc,s_part.bullet_a_spread
 
 t_part.lifetime,t_part.health=s_part.lifetime,s_part.health
end

function make_boss()
 boss_active=true
 boss_exploding_timer=0
 
 for k,v in pairs(parts)do
  for k2,p in pairs(v)do
   p.active,p.shooter=false,false
   p.anim_index=1
  end
 end

 local cx=5

 local x=cx
 local y=2+flr(rnd(max_parts_h-2))+1

 boss_init_shooter_part(parts[y][x])

 local count=boss_desc.size-1
 local tries=0

 while count>0 do
  local rnd_dir=rnd(1)

  if rnd_dir<.25 then
   if y>3 then
    y-=1
   end
  elseif rnd_dir<.5 then
   if y<max_parts_h-1 then
    y+=1
   end
  elseif rnd_dir<.75 then
   if x>1 then
    x-=1
   end
  elseif rnd_dir<1 then
   if x<cx then
    x+=1
   end
  end
  
  local part=parts[y][x]

  --if not part.active or not part.shooter then
  if not part.active or tries>10 and not part.shooter then
   part.active=true
   tries=0
   
   if rnd()<boss_desc.shooter_chance then
    count-=1
	boss_init_shooter_part(part)
    part.current_anim=part.anims.idle
   else
    part.shooter=false
	part.anims=nil
    part.spr=glue_parts[rnd_i(#glue_parts)]
   end
  else
   tries+=1
  end
 end

 local start_index=rnd_i(2)

 local added_thruster=false

 for i=start_index,cx,2 do
  for j=3,max_parts_h do
   if parts[j][i].active then
    add_thruster(j,i)

	added_thruster=true
	break
   end
  end
 end

 if not added_thruster then
  for j=3,max_parts_h do
   if parts[j][cx].active then
    add_thruster(j,cx)

	added_thruster=true
	break
   end
  end
 end

 for j=1,max_parts_h do
  for i=1,cx do
   if parts[j][i].active then
    local mirror_part=parts[j][max_parts_w-i+1]
	clone_part(mirror_part,parts[j][i])
   end
  end
 end

 local empty_row=true

 while empty_row do
  for i=1,max_parts_w do
   if parts[1][i].active then
    empty_row=false
   end
  end

  if empty_row then
   local temp_row=parts[1]
   for j=2,max_parts_h do
    parts[j-1]=parts[j]
   end
   parts[max_parts_h]=temp_row
  end
 end
end

function set_current_anim(part,anim)
 part.current_anim,part.anim_index=anim,1
 part.anim_time=0
end

function boss_check_damage(bullet,damage_amount,collision_checker)
 for j=1,max_parts_h do
  for i=1,max_parts_w do
   local part=parts[j][i]

   if part.shooter and part.active and part.health>0 then
    if part.current_anim!=part.anims.idle then 
     local part_x,part_y=boss_x+i*8,boss_y+j*8
   
     if collision_checker(bullet,part_x,part_y,part_x+8,part_y+8)then
      part.health-=damage_amount
      
      add_to_score(damage_amount,part.health)
      
      if part.health<=0 then
	   sfx(2)
       part.health=0
     
       set_current_anim(part,part.anims.dead)
         
       local ex,ey=part_x+4,part_y+4
     
       make_ex(ex,ey,6,-.5,1,2)      
       bs_spawn(ex,ey,6,20,.4,bs_lines)
      else
	   sfx(3)
       local ex,ey=bullet.x+1.5,part_y+8
       make_ex(ex,ey,2,-.2,1,2)
       bs_spawn(ex,ey,4,16,.2)
      end 
      
      return true
     end
    end
   end
  end
 end
 
 return false
end

function boss_update()
 if not boss_active then
  return
 end

 if boss_base_y<0 then
  boss_base_y+=.5
 end

 boss_x=lerp(8,32,.5+.5*sin(boss_desc.speedx*time))
 boss_y=boss_base_y+lerp(0,8,.5+.5*cos(boss_desc.speedy*time))
 
 local alive_parts=0
 
  for j=1,max_parts_h do
   for i=1,max_parts_w do
    local part=parts[j][i]

    if part.active then
	 local part_x,part_y=boss_x+i*8+2,boss_y+j*8+2
    
	 if part.shooter then
      part.lifetime+=one_frame

      if part.health>0 then     
       alive_parts+=1
      end
      
      if part.current_anim==part.anims.idle then
	   if part.anim_time>=part.closed_time then
	    set_current_anim(part,part.anims.open)
	   end
	  elseif part.current_anim==part.anims.open then
       if part.anim_index>=#part.current_anim then
	    set_current_anim(part,part.anims.shoot)
	    part.shooting_timer=0
	   end
	  elseif part.current_anim==part.anims.shoot then
	   part.shooting_timer-=one_frame

	   if part.shooting_timer<=0 then
	    part.shooting_timer=part.shoot_rate
        if part.aimed then
         ebs_shoot_aimed(part_x,part_y,part.bullet_speed,part.bullet_count,part.bullet_a_spread)
        else
         part.bullet_a+=part.bullet_a_inc
         ebs_shoot_spread(part_x,part_y,part.bullet_speed,part.bullet_count,part.bullet_a)
	    end
       end

       if part.anim_time>=part.opened_time then
	    set_current_anim(part,part.anims.close)
	   end
	  elseif part.current_anim==part.anims.close then
       if part.anim_index>=#part.current_anim then
	    set_current_anim(part,part.anims.idle)
	   end
	  end
	 end

     if part.anims then
	  part.anim_time+=one_frame
      part.anim_index=next_i(part.current_anim,part.anim_index)
     end
    end
   end
  end
 
 if alive_parts<=0 then
  if boss_exploding_timer==0 then
   boss_exploding_timer=1
   shake_t=1
   --ebs_reset()
   
	if boss_phase==0 and cur_lvl==10 then
	 boss_phase=1
	else
	 music(0)
	end   
  else
   boss_exploding_timer-=one_frame
   
   if boss_exploding_timer<=0 then
	local ex,ey=boss_x+44,boss_y+24
    
	sfx(7)
    make_ex(ex,ey,10,-.15,1,5)      
    make_ex(ex,ey,8,-.15,4,5)      
    make_ex(ex,ey,6,-.15,6,5)      

    bs_spawn(ex,ey,15,60,1,bs_b_lines,true)
    boss_active=false
    shake_t=1
	
	if boss_phase==1 then
	 boss_reset()
     make_boss()
	 boss_phase=2
	end
   else
     sfx(2)
     for q=1,5 do
      local j,i=rnd_i(max_parts_h),rnd_i(max_parts_w)

      local part=parts[j][i]

      if part.active then
	   local ex,ey=boss_x+i*8+rnd(8),boss_y+j*8+rnd(8)
       make_ex(ex,ey,2,-.1,1,2)
       bs_spawn(ex,ey,4,16,.2)
      end
     end
   end
  end  
 end
end

function boss_draw()
 if boss_active then
  pal()

  for j=1,max_parts_h do
   for i=1,max_parts_w do
    local part=parts[j][i]
    if part.active then
     local x,y=boss_x+i*8,boss_y+j*8
     if part.anims then
      spr(part.current_anim[part.anim_index],x,y,1,1,i>5)
     else
      spr(part.spr,x,y,1,1,i>5)
     end
    end
   end
  end
 end
end

function enemy_regen(spr_index,size,max_count)
 local colors={11,3,5}
 local s=size*8
 local half_s=s/2
 local bx,by=(spr_index%16)*8,flr(spr_index/16)*8
 
 for i=0,s*s do
  sset(bx+i%s,by+i/s,0)
 end

 local x,y=half_s,rnd_i(s-1)

 local smallest_x=x
 
 local count=max_count
 
 while count>0 do
  local sx,sy=bx+x,by+y
  if sget(sx,sy)==0 then
   if count>=max_count-1 then
    sset(sx,sy,8)
   else
    sset(sx,sy,colors[rnd_i(#colors)])
   end
   count-=1
  end
  
  local rnd_dir_y=rnd(3)

  if rnd_dir_y<1 then
   if y>2 then
    y-=1
   end
  elseif rnd_dir_y<2 then
   if y<s-1 then
    y+=1
   end
  end 
   
  local rnd_dir_x=rnd(3)
  
  if rnd_dir_x<1 then
   if x>1 then
    x-=1
    
    if x<smallest_x then
     smallest_x=x
    end
    
   end
  elseif rnd_dir_x<2 then
   if x<half_s then
    x+=1
   end
  end
 end
 
 local start_index=rnd_i(2)

 local added_thruster=false

 for i=start_index,half_s-1,2 do
  for j=1,s-1 do
   if sget(bx+i,by+j)!=0 then
    sset(bx+i,by+j-1,10)

	added_thruster=true
	break
   end
  end
 end

 if not added_thruster then
  for j=1,s-1 do
   if sget(bx+half_s,by+j)!=0 then
    sset(bx+half_s,by+j-1,10)

	added_thruster=true
	break
   end
  end
 end

 for j=0,s do
  for i=0,half_s do
   local sp=sget(bx+i,by+j)
   if sp!=0 then
    sset(bx+s-i,by+j,sp)
   end
  end
 end

 palt(0,false)
 
 local empty_row=true
 local empty_row_count=0

 while empty_row and empty_row_count<s do
  for i=0,half_s do
   if sget(bx+i,by)!=0 then
    empty_row=false
	break
   end
  end

  if empty_row then
   empty_row_count+=1

   for j=1,s-1 do
    for i=0,s do
     sset(bx+i,by+j-1,sget(bx+i,by+j))
    end
   end
   
   for i=0,s do
    sset(bx+i,by+s-1,0)
   end
  end
 end
 
 palt()

 local height=0
 for j=0,s do
  local empty_row=true
  
  for i=0,s do
   if sget(bx+i,by+j)!=0 then
    height+=1
    empty_row=false
    break
   end   
  end
  
  if empty_row then
   break 
  end
 end

 local width=s-2*max(0,smallest_x)+1
 
 return -flr(-width),-flr(-height)
end

es={}
es_next=1
es_active_count=0
es_sprs=nl("8,9,10,11,12,13,14,15,22,23,24,25,26,38,40,42,44,46,")
es_sprs_w={}
es_sprs_h={}

es_slots={}
es_slots_avail=0

for i=1,100 do
 add(es,{})
end

function es_reset()
 for k,e in pairs(es)do
  e.active=false
 end
 
 es_next=1
 es_active_count=0
end

function es_enemy_bounds(e)
 local x,y=e.x+flr((8*e.spr_size-e.spr_width)/2),e.y
 return x,y,x+e.spr_width,y+e.spr_height
end

function enemy_behaviors(e)
   local p1x=ps[1].x
   
   if p1x>e.basex+e.track_rate then
    e.basex+=e.track_rate
   elseif p1x<e.basex-e.track_rate then
    e.basex-=e.track_rate
   else
    e.basex=p1x
   end

   e.y+=e.speed
   e.x=e.basex+e.sin_mag*sin(e.sin_phase*e.lifetime)
   
   if e.y<10 then
    e.y=.9*e.y+1
   elseif e.y>128 then
    e.active=false
    es_active_count-=1
	dead_count+=1
   end
end

function es_init_launch_slots()
  for i=1,12 do
   es_slots[i]=i-1
  end
  
  es_slots_avail=#es_slots
end

function es_spawn(ed)
 if es_active_count>=#es then
  return
 end

 local e=es[es_next] 
 
 while e.active do
  es_next=next_i(es,es_next)
  
  e=es[es_next]
 end
 
 if es_slots_avail<=0 then
  es_init_launch_slots()
 end
 
 local slot_index=rnd_i(es_slots_avail)
 local last_slot=es_slots_avail
 
 local used_slot_value=es_slots[slot_index]
 
 es_slots[slot_index]=es_slots[es_slots_avail]
 es_slots[es_slots_avail]=-1
 
 es_slots_avail-=1
 
 e.basex=16+used_slot_value*8
 
 e.speed=rnd_range(ed.min_speed,ed.max_speed)
 e.x,e.y=e.basex,-8-e.speed
 
 e.sin_mag=rnd_range(ed.min_sin_mag,ed.max_sin_mag)
 e.sin_phase=rnd_range(ed.min_sin_phase,ed.max_sin_phase)
 e.spr=es_sprs[ed.spr]
 e.spr_size=(ed.spr<=13)and 1 or 2
 e.spr_width=es_sprs_w[ed.spr]
 e.spr_height=es_sprs_h[ed.spr]
 e.track_rate=rnd_range(ed.min_track_rate,ed.max_track_rate)
 
 e.bullet_type=ed.bullet_type
 
 e.shoot_rate=rnd_range(ed.min_shoot_rate,ed.max_shoot_rate)/gp_perc(.01)
 e.shoot_timer=e.shoot_rate
 e.bullet_speed=rnd_range(ed.min_bullet_speed,ed.max_bullet_speed)
 e.bullet_count=flr(ed.bullet_count*gp_perc(.1))
 
 e.bullet_count=min(40,e.bullet_count)
 
 e.bullet_a_inc=ed.bullet_a_inc
 e.bullet_a=0
 
 e.active=true
 e.lifetime=0
 e.health=ed.health*gp_perc(.2)
 e.damaged_timer=0
 
 es_active_count+=1
end

function es_damage(e,damage_amount,hit_x,hit_y)
 e.health-=damage_amount
 add_to_score(damage_amount,e.health)
 e.damaged_timer=0.1
 
 if e.health<=0 then
  sfx(2)
  e.active=false
  es_active_count-=1
  local ex=e.x+4*e.spr_size
  local exs_y=e.y+e.spr_height/2
  local ex_w=2+4*e.spr_size
  make_ex(ex,exs_y,ex_w,-.5,1,2)      
  bs_spawn(ex,exs_y,ex_w,20*e.spr_size,.4,bs_lines)
  dead_count+=1
 else
  sfx(3)
  make_ex(hit_x,hit_y,2,-0.2,1,2)
  bs_spawn(hit_x,hit_y,4,16,.2)
 end
end

function es_update()
 for k,e in pairs(es)do
  if e.active then
   e.lifetime+=one_frame
  
   if e.damaged_timer>0 then
    e.damaged_timer-=one_frame
   end
   
   enemy_behaviors(e)
   
   if e.bullet_type and e.shoot_rate>0 then
    e.shoot_timer+=one_frame
	
	if e.shoot_timer>=e.shoot_rate then
	 e.shoot_timer=0
	 
     local bx,by=e.x+e.spr_size*4-2,e.y+e.spr_height
     
     if e.bullet_type==0 then
      e.bullet_a+=e.bullet_a_inc
      ebs_shoot_spread(bx,by,e.bullet_speed,e.bullet_count,e.bullet_a)
     else
      ebs_shoot_aimed(bx,by,e.bullet_speed,e.bullet_count,e.bullet_a_inc)
     end
    end
   end
  end
 end
end

function es_draw_spr(e,ox,oy)
 spr(e.spr,e.x+ox,e.y+oy,e.spr_size,e.spr_size)
end

function es_draw()
 for k,e in pairs(es)do
  if e.active then
   pal_color((e.damaged_timer>0)and 7 or (e.shoot_rate!=0 and e.shoot_timer<.2)and 14 or 0)
   es_draw_spr(e, 1, 0)
   es_draw_spr(e,-1, 0)
   es_draw_spr(e, 0, 1)
   es_draw_spr(e, 0,-1)
   pal()

   if e.damaged_timer>0 then
     pal(11,10)
     pal(3,8)
     pal(5,9)
   end
 
   es_draw_spr(e,0,0)
   pal()
  end
 end
end

function enemy_desc(s,mi_s,ma_s,mi_p,ma_p,mi_m,ma_m,mi_tr,ma_tr,mi_sr,ma_sr,mi_bs,ma_bs,bt,bc,ba,h)
 return {
  spr=s,
  min_speed=mi_s,
  max_speed=ma_s,
  min_sin_phase=mi_p,
  max_sin_phase=ma_p,
  min_sin_mag=mi_m,
  max_sin_mag=ma_m,
  min_track_rate=mi_tr,
  max_track_rate=ma_tr,
  min_shoot_rate=mi_sr,
  max_shoot_rate=ma_sr,
  min_bullet_speed=mi_bs,
  max_bullet_speed=ma_bs,
  bullet_type=bt,
  bullet_count=bc,
  bullet_a_inc=ba,
  health=h,
 }
end

es_desc={
  enemy_desc(unpack(nl("1,1.5,2.5,0,0,0,0,0,0,0,0,0,0,0,0,0,1,"))),
  enemy_desc(unpack(nl("4,.5,1,.1,.5,4,6,0,0,0,0,0,0,0,0,0,2,"))),
  enemy_desc(unpack(nl("15,.05,.1,.1,.2,10,20,0,0,1,2,.5,1,0,6,.01,40,"))),
  enemy_desc(unpack(nl("10,.05,.1,.1,.2,10,20,0,0,1,3,1,2,0,1,0,4,"))),
  enemy_desc(unpack(nl("13,.05,.1,.1,.2,6,15,0,0,2,4,1,2,1,4,.25,4,"))),

  enemy_desc(unpack(nl("3,2,3,0,1,0,10,.5,1,0,0,0,0,0,0,0,1,"))),
  enemy_desc(unpack(nl("12,.01,.1,0,0,0,0,0,0,1,2,1,2,0,10,0,6,"))),
  enemy_desc(unpack(nl("18,.01,.05,.1,.2,10,16,.05,.2,1,2,1,2,1,10,.25,20,"))),
  enemy_desc(unpack(nl("14,.1,.2,.1,.2,10,16,0,0,.4,.8,1,2,0,4,.0125,6,"))),
  enemy_desc(unpack(nl("16,.05,.1,.2,.4,20,30,0,0,2,4,.2,.8,0,20,0,15,"))),

  enemy_desc(unpack(nl("17,.05,.1,0,0,0,0,0,0,.5,1,.5,1,0,3,.05,20,"))),
  enemy_desc(unpack(nl("2,2,4,0,0,0,0,0,0,.8,1.2,1,2,1,1,0,1,"))),
  enemy_desc(unpack(nl("11,.5,1,0,0,0,0,0,0,1,2,.2,.5,0,20,0,2,"))),
  enemy_desc(unpack(nl("9,.1,.2,.1,.2,2,4,0,0,.4,.8,1,2,0,5,.02,3,"))),
  enemy_desc(unpack(nl("7,.01,3,.01,.6,0,20,0,1,.1,4,.1,3,0,6,.05,3,"))),

  enemy_desc(unpack(nl("8,.01,1,.01,.6,0,20,0,.2,1,2,.1,.5,0,40,.05,5,"))),
  enemy_desc(unpack(nl("6,.01,.5,.01,.6,0,10,0,.2,.08,.1,.4,.6,0,1,.05,10,"))),
  --spr left:5
}

function m_boss_desc(h,sx,sy,s,sc,mi_o,ma_o,mi_c,ma_c,mi_sr,ma_sr,mi_bs,ma_bs,mi_bc,ma_bc,mi_bai,ma_bai,mi_bas,ma_bas,abc)
 return {
  health=h,
  speedx=sx,
  speedy=sy,
  size=s,
  shooter_chance=sc,
  min_opened_time=mi_o,
  max_opened_time=ma_o,
  min_closed_time=mi_c,
  max_closed_time=ma_c,
  min_shoot_rate=mi_sr,
  max_shoot_rate=ma_sr,
  min_bullet_speed=mi_bs,
  max_bullet_speed=ma_bs,
  min_bullet_count=mi_bc,
  max_bullet_count=ma_bc,
  min_bullet_a_inc=mi_bai,
  max_bullet_a_inc=ma_bai,
  min_bullet_a_spread=mi_bas,
  max_bullet_a_spread=ma_bas,
  aimed_bullet_chance=abc,
 }
end

levels={
 { --1
  spawn_rate=1,
  wave_str="10-1,10-2; 10-4,10-2,10-1; 1-3; 20-4,20-2; 2-3,10-1",
  boss=m_boss_desc(unpack(nl("5,.1,.2,6,.2,2,4,.2,.4,2,3,.5,1,2,8,.1,.2,.1,.5,.5,"))),
 },

 { --2
  spawn_rate=1,
  wave_str="10-5; 10-4,10-5,20-2; 1-8; 1-10; 1-8,1-10,1-8,1-10",
  boss=m_boss_desc(unpack(nl("10,.4,.7,8,.5,2,4,.2,.4,3,4,.4,.8,2,4,.02,.1,.1,.2,.5,"))),
 },
 
 { --3
  spawn_rate=.95,
  wave_str="4-9; 4-7,10-6; 6-9,2-3; 10-9,4-3,50-1",
  boss=m_boss_desc(unpack(nl("20,.8,.1,10,.7,2,3,.2,.6,4,6,.2,.4,10,16,.02,.1,1,1,.5,"))),
 },

 { --4
  spawn_rate=.9,
  wave_str="5-1,5-2,5-6,5-1,5-2,5-6,5-1,5-2,5-6; 10-4,10-5; 10-7,10-5; 6-7,6-5,6-4; 1-3,1-10,1-8,6-9",
  boss=m_boss_desc(unpack(nl("40,.05,.01,5,.3,.4,.8,1,2,.03,.06,.8,1,3,5,.001,.01,.05,.1,0,"))),  
 },
 
 { --5
  spawn_rate=.85,
  wave_str="2-11; 10-5,20-6; 10-7; 6-11; 6-7,20-6",
  boss=m_boss_desc(unpack(nl("60,.5,.1,2,.1,1,2,2,3,.03,.06,.8,1,4,8,.001,.005,.05,.1,0,"))),
 },
 
 { --6
  spawn_rate=.8,
  wave_str="20-12; 12-13,20-6; 12-14,20-6; 12-14,12-13,20-6; 6-8; 6-10",
  boss=m_boss_desc(unpack(nl("40,.6,.5,4,.4,.5,1,2,3,.05,.1,.8,1,4,8,0,0,.05,.1,1,"))),
 },

 { --7
  spawn_rate=.75,
  wave_str="20-14; 20-13; 20-12,2-9; 8-9,20-12; 10-11,20-12;",
  boss=m_boss_desc(unpack(nl("20,.1,.6,18,.8,.2,1,1,2,.5,2,.5,1,6,6,.02,.05,.01,.01,.5,"))),
 },
 { --8
  spawn_rate=.1,
  wave_str="100-1; 100-2; 100-6; 2-3,80-1; 6-7,100-2; 20-6,4-13,20-6,4-13,20-6,4-13,20-6,4-13,20-6,4-13; 4-8,40-1,40-1,40-6",
  boss=m_boss_desc(unpack(nl("20,.5,.5,10,.1,.1,.2,1,2,.03,.06,.8,1,3,7,.001,.01,.05,.1,0,"))),
 },

 { --9
  spawn_rate=.6,
  wave_str="1-3; 1-8; 1-9; 1-10; 1-11; 20-3; 3-8,12-9; 20-9; 20-11; 10-10,10-11;",
  boss=m_boss_desc(unpack(nl("10,.1,.2,8,.1,.4,.4,4,4,1,1,.8,.8,10,20,.01,.02,.5,.75,1,"))),
 }, 

 { --10
  spawn_rate=.8,
  wave_str="10-15; 10-16; 10-17; 40-15; 40-16; 40-17;",
  boss=m_boss_desc(unpack(nl("20,.3,.8,20,.5,.1,4,.1,4,.1,3,.3,1,1,30,.01,.25,.01,.99,.5,"))),
 },
}


function lv_waves_parse(levels)
 for k,level in pairs(levels)do
  local wave_index,bunches_index=1,1
 
  level.waves={}
  level.waves[wave_index]={}
  local current_wave=level.waves[wave_index]
  current_wave.bunches={}
 
  local current_num_str=""
  local current_bunch=nil
  local str=level.wave_str

  while #str>0 do
   current_wave=level.waves[wave_index]
  
   local d=sub(str,1,1)
  
   if d==" " then
   elseif d=="-" then
    current_wave.bunches[bunches_index]={}
    current_bunch=current_wave.bunches[bunches_index]
    current_bunch.count=current_num_str+0
    current_num_str=""
   elseif d=="," then
    current_bunch.type=current_num_str+0
    current_num_str=""
    bunches_index +=1
   elseif d==";" then
    current_bunch.type=current_num_str+0
    current_num_str=""
    wave_index +=1
    bunches_index=1
    level.waves[wave_index]={}
    current_wave=level.waves[wave_index]
    current_wave.bunches={}
   else
    current_num_str=current_num_str..d
   end
  
   str=sub(str,2)
  end
 
  if current_num_str!="" then
   current_bunch.type=current_num_str+0
   current_num_str=""
  end
 end
end

lv_waves_parse(levels)
get_file()
cur_level=levels[cur_lvl]

save_msg_timer=0
lv_timer=0
lv_scrolly1,lv_scrolly2=0,0
lv_target_scroll_speed=0
lv_scroll_speed=0
lv_wave_index=1
enemy_bunch_index=1
enemy_i=1
enemy_count=0
dead_count=0
lv_spawn_timer=0
lv_finished_timer=0
in_boss=false

function lv_regen_es()
 for i=1,#es_sprs do
  local num_pixels=6+i
  local size=(i<=13)and 1 or 2 
  local w,h=enemy_regen(es_sprs[i],size,size*num_pixels)
  es_sprs_w[i],es_sprs_h[i]=w,h
 end
end

function lv_start_level()
 cur_level=levels[cur_lvl]
 
 lv_scrolly1,lv_scrolly2=0,0
 in_boss=false
 lv_timer,lv_finished_timer=0,0
 lv_target_scroll_speed=1.5

 lv_wave_index=0
 
 lv_next_wave()
 lv_regen_es()
 
 boss_reset()
 
end

function lv_next_wave()
 enemy_count,dead_count=0,0
 enemy_i,enemy_bunch_index=1,1
 lv_wave_index+=1
 
 local cur_wave=cur_level.waves[lv_wave_index]
 lv_spawn_timer=cur_level.spawn_rate/gp_perc(.1)
 
 if lv_spawn_timer<.1 then
  lv_spawn_timer=.1
 end
 
 for i=1,#cur_wave.bunches do
  enemy_count+=cur_wave.bunches[i].count
 end
 
 es_init_launch_slots()
 
end

function lv_update()
 lv_timer+=one_frame
 save_msg_timer=max(0,save_msg_timer-one_frame)

 if lv_finished_timer>0 then
  lv_finished_timer-=one_frame
  
  if lv_finished_timer<=8 then
   lv_target_scroll_speed=10
  end
  
  if lv_finished_timer<=0 then
   cur_lvl=next_i(levels,cur_lvl)
   
   if cur_lvl==1 then
    cur_gp+=1
   end
   
   save_msg_timer=2
   store_file()
   ps_reset_nl()
   lv_start_level()
  end
  
 elseif in_boss then
  if not boss_active then
   lv_finished_timer=10
  end
 
 else
  lv_spawn_timer-=one_frame
  
  local cur_wave=cur_level.waves[lv_wave_index]  

  if lv_spawn_timer<=0 and es_active_count<#es then 
  
   if enemy_bunch_index<=#cur_wave.bunches then
    local enemy_bunch=cur_wave.bunches[enemy_bunch_index]
    es_spawn(es_desc[enemy_bunch.type])
	
    enemy_i+=1
    
    if enemy_i>enemy_bunch.count then
     enemy_bunch_index+=1
     enemy_i=1
    end
    
    lv_spawn_timer=cur_level.spawn_rate/gp_perc(.1)
   end
  end
 
  if dead_count>=enemy_count then
   
   if lv_wave_index>=#cur_level.waves then
    if cv!=fev then
	 music(30)
	end
	
    in_boss=true
    lv_target_scroll_speed=.1

    boss_desc=cur_level.boss
	make_boss()
   else
    lv_next_wave()
   end
   
  end
 end
 
 -- scrolling map
 local scroll_accel=.1
 
 if lv_scroll_speed+scroll_accel<lv_target_scroll_speed then
  lv_scroll_speed+=scroll_accel
 elseif lv_scroll_speed-scroll_accel>lv_target_scroll_speed then
  lv_scroll_speed-=scroll_accel
 else
  lv_scroll_speed=lv_target_scroll_speed
 end 
 
 sf_scroll_speed=lv_scroll_speed
 sf_target_rate=lv_scroll_speed
 
 if sf_rate+scroll_accel<sf_target_rate then
  sf_rate+=scroll_accel
 elseif sf_rate-scroll_accel>sf_target_rate then
  sf_rate-=scroll_accel
 else
  sf_rate=sf_target_rate
 end 
 
 sf_max_speed=4*lv_scroll_speed
 
 sf_update()

 lv_scrolly1+=.2*lv_scroll_speed
 lv_scrolly2+=lv_scroll_speed
 
end

function lv_draw()

 sf_draw()

 local lv_map_type=cur_lvl-1
 local l_cell=lv_map_type*8
 local r_cell=l_cell+4

 local ox=0
 
 if lv_timer<=5 then
  ox=48*(5-lv_timer)/5
 elseif lv_finished_timer>0 then
  ox=48*(10-lv_finished_timer)/10
 end
 
 local s1endy=lv_scrolly1%128
 local s1starty=s1endy-128
 local s1startx,s1endx=-ox,96+ox
 
 map(l_cell,0,s1startx,s1starty,4,16)
 map(r_cell,0,s1endx,s1starty,4,16)

 map(l_cell,0,s1startx,s1endy,4,16)
 map(r_cell,0,s1endx,s1endy,4,16)

 local s2endy=lv_scrolly2%128
 local s2starty=s2endy-128
 local s2startx,s2endx=s1startx-3,s1endx+3
 
 map(l_cell,16,s2startx,s2starty,4,16)
 map(r_cell,16,s2endx,s2starty,4,16)

 map(l_cell,16,s2startx,s2endy,4,16)
 map(r_cell,16,s2endx,s2endy,4,16)

end

fev={}
fev.start=function()
 sf_init()
 lv_start_level()
 title_timer=0
end

fev.update=function()

 if btnp(2) then
  file-=1
  file%=3
  get_file()
 end

 if btnp(3) then
  file+=1
  file%=3
  get_file()
 end
 
 title_update()
 sf_update()
 lv_update()
 ps_upgrades_update()
 es_update()
 ebs_update()
 if btn(4) then
  set_view(gv)
 end

 blink_text_update()
end

function fev_title_draw(by,phase,c,bc)
 local x,y=64+10*cos(time/3-phase),by+5*sin(time-phase)
 po("<_____>",x,y-12,c,bc)
 po(".the.",x,y-12,c,bc)
 po("<_.green._>",x,y-6,c,bc)
 po(".legion.",x,y,c,bc)
 po(".______.",x,y+2,c,bc)
 po("  .___.  ",x,y+4,c,bc)
 po("<   __   >",x,y+6,c,bc)
 po("< >",x,y+10,c,bc)
end

title_timer=0

function title_update()
 if title_timer<1 then
  title_timer+=one_frame
 end
end

function title_draw()
 local by=lerp(-20,40,title_timer)
 fev_title_draw(by,.2,5,1)
 fev_title_draw(by,.1,2,3)
 fev_title_draw(by,0,8,11)
end

blink_text,blink_text_on=0,true

function blink_text_update()
 blink_text-=one_frame
 
 if blink_text <=0 then
  blink_text=.1
  blink_text_on=not blink_text_on
 end
end

fev.draw=function()
 lv_draw()
 draw_ui()
 
 es_draw()
 ebs_draw()
 title_draw()
 
 po("ship a: "..scr_text(dget(0)),32,80,8,11,align_l)
 po("ship b: "..scr_text(dget(4)),32,88,8,11,align_l)
 po("ship c: "..scr_text(dget(8)),32,96,8,11,align_l)
 
 po(">",25,80+file*8,8,11,align_l)
 
 po("press z to start",64,110,8,blink_text_on and 11 or 3)
 po("guerragames 2016",64,121,2,3)
end

gv={}

gv.start=function()
 music(0)

 shake_t=0
 exs_reset()
 bs_reset()
 boss_reset()
 lv_start_level()
 es_reset()
 ebs_reset()
 ps_reset_ng()
 ps[1].x=60
 ps[1].y=136
 
 gameover=false
end

gv.update=function()
 if shake_t>0 then
  shake_t-=one_frame
  camera(rnd_range(-1,1),rnd_range(-1,1))
 else
  camera()
 end
 
 blink_text_update()
 
 if gameover then
  title_update()
  
  if title_timer>1 then
   if btn(4) then
    gv.start()
   end
  end
 end

 lv_update()
 
 if not gameover then
  ps_update()
 end
 
 bullets_update()
 
 boss_update()

 es_update()

 ebs_update()
 
 if not gameover then
  _touch()
 end
 
 exs_update()
 bs_update()
end

function print_ui_l(txt,y)
 po(txt,1,y,7,1,align_l)
end

function draw_ui()
 print_ui_l("exp:"..scr_text(cur_score),1)
 
 local lvl_text="w-"..cur_lvl
 if cur_gp>0 then
  lvl_text="ng+"..cur_gp.." "..lvl_text
 end
 
 po(lvl_text,128,1,7,1,align_r)
 
 print_ui_l(next_upgrade_txt(),7)
 print_ui_l("lvl:"..ps_level,13)
 
 if cv==fev or gameover then
  print_ui_l("deaths:"..cur_gm,19)
 end
end

gv.draw=function()
 lv_draw()
 
 --local line=128
 --line-=6
 --print("mem:"..stat(0),0,line,7)
 --line-=6
 --print("cpu:"..stat(1),0,line,7)
 --line-=6

 if save_msg_timer>0 then
  po("game saved!",64,110,8,blink_text_on and 11 or 3) 
 end
 
 draw_ui() 
 
 boss_draw()

 exs_draw()

 if not gameover then
  ps_draw_secondary()
 end
 
 es_draw()

 if not gameover then
  ps_draw_first()
 end
 
 bs_draw()

 bullets_draw()

 ebs_draw()

 if gameover then
  title_draw()
  po("game over",64,70,blink_text_on and 8 or 2,blink_text_on and 11 or 3)
  po("press z to continue",64,80,blink_text_on and 8 or 2,blink_text_on and 11 or 3)
 end
end

cv=fev

function set_view(new_view)
 cv=new_view
 cv.start()
end

function views_update()
 cv.update()
end

function views_draw()
 cv.draw()
end

function _init()
 menuitem(1,"die and save!?",save_and_reset)
 menuitem(2,"reset score!?",reset_score)
 
 music(40)

 sf_init()

 set_view(fev)
end

function _touch()
 if in_boss then
  for k,b in pairs(bullets)do
   if b.active then
    if boss_check_damage(b,1,bullets_check)then
     b.active=false
    end
   end
  end
 end
 
 for k,e in pairs(es)do
  if e.active then
   local min_x,min_y,max_x,max_y=es_enemy_bounds(e)

   local hit=ps_check(min_x,min_y,max_x,max_y)
   local hit_x,hit_y=e.x+4,max_y
   
   for k2,b in pairs(bullets)do
    if b.active then
	 if bullets_check(b,min_x,min_y,max_x,max_y)then
      b.active=false
	  hit=true
	  hit_x=b.x+1.5
	  break
     end
    end
   end

   if hit then   
    es_damage(e,1,hit_x,hit_y) 
   end
  end
  
 end
end

function _update()
 time+=one_frame
 views_update()
end

function _draw()
 cls()
 views_draw()
end
