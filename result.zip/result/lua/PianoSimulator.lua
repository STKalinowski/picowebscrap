-- piano simulator
-- by josh millard

lox = 16
loy = 10
lx = lox
ly = loy
ldown = false
lready = false
ls = 12

rox = 65
roy = 12
rx = rox
ry = roy
rdown = false
rready = false
rs = 44

function _update()
 do_input()
 do_drift()
end

function do_drift()
 if(not ldown) then
  if(lx != lox) then
   local diff = lx-lox
   lx -= diff/4
  end
 end
 
 if(not rdown) then
  if(rx != rox) then
   local diff = rx-rox
   rx -= diff/4
  end
 end
 
end

c=0 d=1 e=2 f=3
g=4 a=5 b=6 
c2=7 d2=8 e2=9 f2=10
g2=11 a2=12 b2=13
c3=14 d3=15 e3=16 f3=17
g3=18 a3=19 b3=20 c4=21
function do_input()
 -- quick animation checks
 ldown = false
 lready = false
 if(not btn(4)) then
  lready = true
  if(btn(0) or btn(1) or
     btn(2) or btn(3)) then
   ldown = true
  end
 end

 rdown = false
 rready = false
 if(btn(4)) then
  rready = true
  if(btn(0) or btn(1) or
     btn(2) or btn(3)) then
   rdown = true
  end
 end


 if(not btn(4) and not btn(5)) then
  if(btnp(0)) then
   chord(c,e,g)
   lx = 2 
  elseif(btnp(2)) then
   chord(d,f,a)
   lx = 6
  elseif(btnp(1)) then
   chord(e,g,b)
   lx = 10
  elseif(btnp(3)) then
   chord(f,a,c2)
   lx = 14
  end
 elseif(not btn(4) and btn(5)) then
  if(btnp(0)) then
   chord(g,b,d2)
   lx = 18 
  elseif(btnp(2)) then
   chord(a,c2,e2)
   lx = 22
  elseif(btnp(1)) then
   chord(b,d2,f2)
   lx = 26
  elseif(btnp(3)) then
   chord(c2,e2,g2)
   lx = 30
  end
 -- right hand notes
 elseif(btn(4) and not btn(5)) then
  if(btnp(0)) then
   note(c3)
   rx = 51
  elseif(btnp(2)) then
   note(d3)
   rx = 55
  elseif(btnp(1)) then
   note(e3)
   rx = 59
  elseif(btnp(3)) then
   note(f3)
   rx = 63
  end
 elseif(btn(4) and btn(5)) then
  if(btnp(0)) then
   note(g3)
   rx = 67
  elseif(btnp(2)) then
   note(a3)
   rx = 71
  elseif(btnp(1)) then
   note(b3)
   rx = 75
  elseif(btnp(3)) then
   note(c4)
   rx = 79
  end
 end
end

function chord(x,y,z)
 sfx(x,0)
 sfx(y,1)
 sfx(z,2)
end

function note(x)
 sfx(x,3)
end

function _draw()
 cls()
 camera(-8,-16)
 -- keyboard
 spr(0,0,0,4,2)
 spr(0,28,0,4,2)
 spr(0,56,0,4,2)
 spr(0,84,0,4,2)
 -- piano frame
 spr(4,-8,-12,1,5)
 spr(4,112,-12,1,4)
 for x=0,104,8 do
  spr(32,x,-16,1,2)
 end
 print("picoway",40,-10,4)

 -- left hand
 local fr = ls
 local y = ly
 if(not lready) then
  pal(15,6)
  pal(9,5)
  pal(4,1)
  y += 2
 end
 if(ldown) fr -= 3  y -= 2  
 spr(fr,lx,y,3,2)
 spr(38,lx,y+16,2,2)
 pal()
  
 -- right hand
 fr = rs
 y = ry
  if(not rready) then
  pal(15,6)
  pal(9,5)
  pal(4,1)
  y += 2
 end
 if(rdown) fr -= 3  y -= 2
 spr(fr,rx,y,2,2)
 spr(38,rx,y+16,2,2)
 pal()
 
 -- instructions
 print("arrows to play",
  0,60,7)
 print("+ z for right hand",
  0,66,7)
 print("+ x for higher notes",

  0,72,7)
end