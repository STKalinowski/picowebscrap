


------------maze dog------------
----------eggnog games----------
-----a game by andrew reist-----
---------@platformalist---------
------thanks for playing!!------


--------------------------------
---thanks @planti_maceta for----
----the awesome label image-----
--thanks to paige, daniel and---
-----chris for playtesting!-----
--------------------------------






--------------init--------------

hiscore={}
 for i=1,3 do
  hiscore[i]=99
 end

function _init()
game={}
 game.win=false
 --switch to false when testing
 game.start=true
 game.endwipex=0
 game.endgameswipey=-2
 game.endt=0
 game.startwipex=0
 game.startwipe2x=130
 game.startwipe2xmove=false
 game.startclicker=0
 game.eggnogx=200
 game.eggnogy=60
 game.dogturn=-1 
 game.showcount=0
 game.showcountbool=false

bg={}
 bg.x=0
 bg.y=0
 bg.r=124
 bg.l=-4
 bg.u=-4
 bg.d=124
 bg.levelx=0
 bg.levely=0
 bg.roll=false
 bg.click=16
 bg.swipex=bg.r+200
 bg.f=true
 bg.cloud=5
 bg.cloudpass=500
 bg.shad=200
 bg.ssc=0
 bg.ss=0
 bg.buttonpatchx=200
 bg.buttonpatchy=200
 bg.moundpatchx=200
 bg.moundpatchy=200
 bg.whatget=false
 bg.tune=99
 
guy={}
 guy.x=130
 guy.y=75
 guy.xd=0
 guy.yd=0
 guy.s=1
 guy.sc=0
 guy.sf=false
 guy.m=false
 guy.tx=guy.x
 guy.ty=guy.y
 guy.bark=0
 guy.digging=false
 guy.digc=0
 guy.df1=false
 guy.digclick=0

block={}
 block.x=200
 block.y=200
 block.s=7
 block.xd=0
 block.yd=0
 block.t=0

waterdrop={}
 for i=1,15 do
  waterdrop[i]=false
 end

water={}
 water.x=200
 water.y=200
 water.s=64
 water.del=false
 
bird={}
 bird.x=200
 bird.y=200
 bird.fly=false
 bird.count=0

birdcatch={}
 for i=1,8 do
  birdcatch[i]=false
 end

bridge={}
 bridge.x=200
 bridge.y=200
 bridge.s=80

splash={}

tbox={}
 tbox.x=0
 tbox.y=70
 tbox.c=0
 tbox.grow=false
 tbox.active=false
 tbox.t1=0
 tbox.t2=0
 tbox.t3=0
 tbox.tc=3
 tbox.s=122

duck={}
 duck.x=200
 duck.y=200
 duck.jump=0

dsplash={}
 dsplash.x=200
 dsplash.y=200

bomb={}
 bomb.splode=false

bombdrop={}
 for i=1,15 do
  bombdrop[i]=false
 end
 
poof={}

hole={}
 hole.diggable=false
 hole.dug=false

treasure={}
 for i=1,8 do
  treasure[i]=false
 end
 treasure.count=0

prize={}
 prize.s=96
 prize.x=200
 prize.y=-200

timer={}
 for i=1,3 do
  timer[i]=0
 end
 timer[4]=200
 timer[5]=67

dirt={}
end

------------update--------------

function _update()
 if game.start==true then
  startgame()
  anim()
  guymove()
 end
 if game.win==false and
    game.start==false then
  if bg.roll==false then
   if guy.digging==false then
    guymove()
   end
  end
  if game.startwipe2x>-130 then
   game.startwipe2x-=3
  end
  foreach(bomb,bombbehavior)
  foreach(water,waterbounds)
  collision()
  scrollbox()
  screenshake()
  anim()
  foreach(bird,birdfly)
  foreach(block,blockbump)
  foreach(bridge,bridgeanim)
  foreach(dirt,dirtspray)
  foreach(splash,splashfall)
  foreach(dsplash,dsplashgrow)
  foreach(duck,duckfloat)
  foreach(poof,poofshrink)
  if bg.f==true then
   itemplacement()
   itemgen()
   bg.f=false
  end
  if guy.s==33 then
   guy.s=1
  end
  bark()
  secretblock()
  timecount()
  dig()
 end
 if game.win==true then
  endgame()
  screenshake()
 end
 showcount()
 patchcheck()
end

--allow player to quit mid-game
--and play / mute music
menuitem(1,"quit to menu", function() menuquit() end)
menuitem(2,"music on/off", function() tunes() end)

function menuquit()
_init()
end

function tunes()
 if bg.tune==99 then
  bg.tune=5
 elseif bg.tune==5 then
  bg.tune=13
 else
  bg.tune=99
 end
 music(bg.tune)
end

function showcount()
 local gsc=game.showcount
 if gsc>0 then
  game.showcount-=1
 else
  game.showcount=0
 end
 if gsc>15 then
  game.showcountbool=true
 elseif
  gsc<16 and
  gsc%2==0 and
  gsc>0 then
  game.showcountbool=true
  sfx(29)
 else
  game.showcountbool=false
 end
end

function startgame()
 if game.startclicker<195 then
  game.startclicker+=1
 end
 local gs=game.startclicker
--timed animations movement
 if gs==1 then
  music(0)
--eggnog logo
 elseif gs==74 then
  game.eggnogx=42
--make game name appear
 elseif gs==178 then
  game.startwipex=35
 elseif gs==183 then
  game.startwipex=95
 elseif gs==188 then
  game.startwipex=130
--dogwalk
 elseif gs>120 and
        guy.x>68 then
  guy.xd=-2
 end
--move away eggnog logo
 if gs>97 and
    gs<300 then
  game.eggnogy+=3
 end
--dogdance
 local l=33
 local r=88
 if gs>193 then
  if game.startwipe2xmove==false then
   guy.xd=game.dogturn
  end
  if guy.x<l or
     guy.x>r then
   game.dogturn*=-1
   guy.x+=(game.dogturn*3)
  end
--swipe and kick off the game
  if btn(5) and
     game.startwipe2x==130 then
   music(-1)
   sfx(27)
   game.startwipe2xmove=true
  end
  if game.startwipe2xmove==true and
     game.startwipe2x>-20 then
   game.startwipe2x-=3
  end
  if game.startwipe2x<0 then
   guy.xd=0
   guy.x=27
   guy.y=35
   sfx(-1)
   music(-1)
   game.startwipe2xmove=false
   game.start=false
  end
 end
end

function scoreset()
--set hiscore
 local t=((timer[1]/1800)+(timer[2]/60)+(timer[3]))
 local h=((hiscore[1]/1800)+(hiscore[2]/60)+(hiscore[3]))
 if t<h then
  hiscore[1]=timer[1]
  hiscore[2]=timer[2]
  hiscore[3]=timer[3]
 end
end

function endgame()
 if game.endt<100 then
  game.endt+=1
 end
 if game.endwipex>121 and 
    btn(5) and
    game.endt>95 and
    game.endgameswipey==-2 then
  game.endgameswipey+=5
  music(-1)
  sfx(30)
 end
 if game.endgameswipey>0 then
  if game.endgameswipey<128 then
   game.endgameswipey+=2
  else
   game.win=false
   _init()
  end
 end  
 timer[4]=game.endwipex-121
 if game.endwipex<121 then
  game.endwipex+=10
 elseif game.endwipex>121 then
  bg.ssc+=5
  game.endwipex=127
 end
end

function dig()
 if btn(4) then
  if hole.diggable==true and
     guy.digclick==2 then
   digcheck()
  end
  if guy.digc==1 then
   for i=1,32 do
    add(dirt,make_dirt(x,y,r,c,xdir,ydir,t,s))
   end
  end
 end
 if prize.y>(guy.y-15) and
    bg.roll==false then
  prize.y-=.2
 else
  prize.x=200
  prize.y=-200
 end
 if btn(4) then
  guy.digging=true
  guy.df1=true
 else
  guy.digging=false
  guy.digclick=0
  if guy.df1==true then 
   guy.s=1
   guy.digc=0
   guy.df1=false
  end
 end
end

function make_dirt(x,y,r,c,xdir,ydir,t,s)
 local p=0
 if guy.sf==true then
  p=-6
 else 
  p=2
 end
 local q=flr(rnd(2))  
 local z=0
 if q==1 then
  z=2
 else
  z=4
 end
 local new_dirt={
 x=(guy.x+1)-(p*1.5),
 y=guy.y+6,
 r=0,
 c=z,
 xdir=rnd(4)+p,
 ydir=rnd(2)-5.3,
 t=0,
 s=0,
 }
 return new_dirt
end

function draw_dirt(thisdirt)
 circfill(thisdirt.x,thisdirt.y+bg.ss,thisdirt.r,thisdirt.c)
end

function dirtspray(thisdirt)  
 if bg.roll==true then
  del(dirt,thisdirt)
 end
 if thisdirt.t==0 then
  thisdirt.s=guy.y+4
 end
 thisdirt.y+=thisdirt.ydir
 thisdirt.x+=thisdirt.xdir 
 thisdirt.ydir+=.7
 thisdirt.xdir*=.9
 if thisdirt.y>thisdirt.s then
  thisdirt.xdir=0
  thisdirt.ydir=0
 end
 if thisdirt.t<(30+rnd(5)) then
  thisdirt.t+=1
 else 
  del(dirt,thisdirt)
 end
end

function timecount()
 if timer[1]<30 then
  timer[1]+=1
 else 
  timer[2]+=1
  timer[1]-=30
 end
 if timer[2]>59 then
  timer[3]+=1
  timer[2]-=60
 end
 if bird.count==8 then
  sfx(-1)
  scoreset()
  music(4)
  game.win=true
 end
end

function make_poof(x,y,r,c)
 local new_poof={
 x=bomb.x+(rnd(13)-3),
 y=bomb.y+(rnd(13)-2),
 r=rnd(8)+5,
 c=flr(rnd(2))+6,
 }
 return new_poof
end

function draw_poof(thispoof)
 circfill(thispoof.x,thispoof.y,thispoof.r,thispoof.c)
end

function poofshrink(thispoof)
 if thispoof.r>0 then
  thispoof.r-=.4
 else
  del(poof,thispoof)
 end
 if thispoof.r<2 then
  thispoof.x+=(rnd(2))
  thispoof.y-=(rnd(2))
  thispoof.c=5
 end
end

function bombcheck()
 bomber(1,6,3)
 bomber(2,6,1)
 bomber(3,7,0)
 bomber(4,6,0)
 bomber(5,1,2)
 bomber(6,3,3)
 bomber(7,1,3)
 bomber(8,4,1)
 bomber(9,4,2)
 bomber(10,2,2)
 bomber(11,3,1)
 bomber(12,0,1)
 bomber(13,0,0)
end

function bomber(i,x,y)
 if bg.levelx==x and
    bg.levely==y and
    bombdrop[i]==false then
  bombdrop[i]=true
  bomb.splode=true
 end
end

function make_bomb(x,y,s)
 local new_bomb={
 x=bomb.x,
 y=bomb.y,
 s=54,
 }
 return new_bomb
end

function draw_bomb(thisbomb)
 spr(thisbomb.s,thisbomb.x,thisbomb.y+bg.ss)
end

function bombbehavior(thisbomb)
 if bomb.splode==true then
  bg.ssc=9
  sfx(24)
  for i=1,30 do
   add(poof,make_poof(x,y,r,c))
  end
  del(bomb,thisbomb)
 end
 local hbxl=thisbomb.x
 local hbxr=thisbomb.x+8
 local hbyt=thisbomb.y+1
 local hbyb=thisbomb.y+8
--horizontal pushing
 if guy.x<hbxr and
    guy.x>hbxl+3 and
    guy.y>hbyt-6 and
    guy.y<hbyb-2 then
  guy.x+=1.5
 end
 if guy.x>hbxl-8 and
    guy.x<hbxr-3 and
    guy.y>hbyt-6 and
    guy.y<hbyb-2 then
  guy.x-=1.5
 end
--vertical pushing
 if guy.y<hbyb and
    guy.y>hbyt+3 and
    guy.x>hbxl-6 and
    guy.x<hbxr-2 then
  guy.y+=1.5
 end
 if guy.y>hbyt-8 and
    guy.y<hbyb-3 and
    guy.x>hbxl-6 and
    guy.x<hbxr-2 then
  guy.y-=1.5
 end
 if bg.roll==true then
  del(bomb,thisbomb)
 end
end

function texty(a,b,c)
 tbox.t1=a
 tbox.t2=b
 tbox.t3=c
end

function textcheck()
 local bgx=bg.levelx
 local bgy=bg.levely
 if bgx==0 then
  if bgy==0 then
   if guy.y<40 and
      guy.x<40 then
    texty("maze dog's house: welcome!","it is a charming doghouse","filled with many snacks")
   else
    if guy.x<20 then
     texty("there are eight lost birds","free them all to win the game","and have a long nap")
    elseif guy.x<90 then
     texty("bark at a white switch","to demolish the white bombs","and clear a safe path")
    else
     texty("do you like music?","[enter] opens the menu","so you can bump tunes")
    end
   end 
  elseif bgy==3 then
   if guy.x<60 then
    texty("i smell a dog treat","investigate the north wall","to find hidden snacks")
   else
    texty("a hidden secret","a room forgotten by time","remembered by birds")
   end
  end  
 end
 if bgx==1 then
  if bgy==0 then
   if guy.y>50 then
    texty("you might fail sometimes","leave the region then return","bulldogs will reset")   
   else
    if guy.x<60 then
     texty("warning: lazy dog!","shove a bulldog hard enough","and you might get past")
    else
     texty("stuck at a puddle?","bulldogs function as bridges","if you push them in")
    end
   end
  elseif bgy==1 then
   texty("this is a snack mound","hold [z] to dig up a snack","there are eight to find!")
  elseif bgy==3 then
   if guy.x<12 then
    texty("what's this strange feeling?","something magical is here","follow the odor")
   else
    texty("this place holds secrets","investigate oddball walls","to find a new path")
   end
  end
 end
 if bgx==2 then 
  if bgy==0 then
   texty("do not bark at ducks","they are a precious resource","and a bit jumpy")
  elseif bgy==2 then
    texty("maze cat wuz here furst","a supeerior creatuur","smartor than tha dog")
  elseif bgy==3 then
   if guy.x<100 then
    texty("the hedge is a lie","an invisible pathway","lies inside this maze")
   else
    texty("a vague scent of stone","chiseled and long forgotten","mossy and earthy")
   end
  end
 end
 if bgx==3 then
  if bgy==3 then
   if guy.x<90 then
    if guy.x<30 then
     texty("a secret garden","long abandoned to nature","lush and overgrown")
    else  
     texty("an ancient statue","when six birds return to bed","follow my shadow")
    end
   else
    if bird.count<6 then
     texty("something smells amiss","you should return here later","something might have changed")
    else
     texty("the shadow was cast","the statue opened the way","new paths lie ahead")
    end
   end
  end
 end
 if bgx==4 and
    bgy==3 then
  texty("lost deep in the hedge","a tiny bird calls for you","it's not far ahead")
 end
 if bgx==5 then
  if bgy==0 then
   if guy.x<60 then
    texty("you made it, maze dog!","capturing this final bird","ends your current game")
   else
    texty("did you find eight snacks?","if you didn't, that's okay!","but grab them next time!")
   end
  elseif bgy==2 then
   texty("a storm old as time","until seven birds are safe","the squall will rage on")
  end
 end
 if bgx==6 then
  if bgy==2 then
   texty("this is maze castle","labyrinthine halls await you","as does the last bird")
  elseif bgy==0 then
   texty("are you stuck, maze dog?","travel the third passageway","come back here later")
  end
 end
 if bgx==7 and
    bgy==2 then
--top left statue
  if guy.x<60 and
     guy.y<60 then
   texty("mine is the third path","your road will be troublesome","if you come here first")
--top right statue
  elseif guy.x>60 and
         guy.y<60 then
   texty("i am the second","envision your bulldog's path","to avoid mistakes")
--bottom left statue
  elseif guy.x<60 and
         guy.y>60 then
   texty("my path is the first","leave the puzzle then return","to reset bulldogs")
--bottom right statue
  elseif guy.x>60 and
         guy.y>60 then
   texty("this is the last path","once every puzzle is solved","my way will be clear")
  end
 end   
 if hole.diggable==true then
  dugcheck()
  if hole.dug==false then
   texty("a strange mound of dirt","remember: hold [z] to dig","you might find something")
  else
   texty("a small empty mound","the delicious snack was found","and raised from the ground")
  end
 end
end

function bark()
 if btn(5) and
    guy.bark==0 then
  sfx(14)
  guy.bark=10
  textcheck()
  if tbox.grow==false then
   tbox.grow=true
  else
   tbox.grow=false
  end
  if bomb.button==true then
     bombcheck()
  end
 end
 if guy.bark>0 then
  guy.bark-=1
 end
 if guy.bark>6 then
  guy.s=33
 end
 if tbox.active==true and
    tbox.grow==true then
  if tbox.x<128 then
   tbox.x+=16
  end
  if tbox.y<112 then
   tbox.y+=6
  end
 end
 if tbox.grow==false then
  if tbox.x>0 then
   tbox.x-=16
  end
  if tbox.y>70 then
   tbox.y-=6
  end
 end
end


function itemgen()
 add(bird,make_bird(x,y,s,sf))
 add(block,make_block(x,y,s))
 add(water,make_water(x,y,s))
 add(bridge,make_bridge(x,y,s))
end

function make_bird(x,y,s,sf,xdir)
 local z=flr(rnd(2))
 if z==1 then
  k=true
 else
  k=false
 end
 if z==1 then
  d=-.9
 else
  d=.9
 end
 local new_bird={
 x=bird.x,
 y=bird.y,
 s=49,
 sf=k,
 xdir=d,
 ydir=-.25,
 }
 return new_bird
end

function draw_bird(thisbird)
 spr(thisbird.s,thisbird.x,thisbird.y+bg.ss,1,1,thisbird.sf)
end

function birdfly(thisbird)
 local gxr=guy.x+6
 local gxl=guy.x-4
 local gyu=guy.y-6
 local gyd=guy.y+4 
 if thisbird.x<gxr and
    thisbird.x>gxl and
    thisbird.y<gyd and
    thisbird.y>gyu then
  bird.fly=true
 end
 if bird.fly==true then
  thisbird.x+=thisbird.xdir
  thisbird.y+=thisbird.ydir
  thisbird.ydir*=1.09
  if thisbird.s==49 then
   thisbird.s=50
  end
  if thisbird.s>49 then
   if thisbird.s<50.8 then
    thisbird.s+=.2
   else
    thisbird.s-=1.8
   end
   if thisbird.s==50.2 then
    sfx(1)
   end
  end
 end
 if thisbird.y<-8 then
  bird.fly=false
  bg.whatget=true
  bird.count+=1
  if bird.count<8 then
   game.showcount=90
  end
  birdlog()
  del(bird,thisbird)
  sfx(28) 
 end
 if bg.roll==true then
  del(bird,thisbird)
 end
end

function catchbird(i,x,y)
 if bg.levelx==x and
    bg.levely==y then
  birdcatch[i]=true
 end
end

function birdlog()
 catchbird(1,0,0)
 catchbird(2,1,0)
 catchbird(3,2,2)
 catchbird(4,0,1)
 catchbird(5,0,3)
 catchbird(6,2,3)
 catchbird(7,4,1)
 catchbird(8,5,0)
 if bird.count>6 then
  bg.cloudpass=10
 end
 if bird.count>5 then
  bg.shad=72
 end
end

function waterlogger(i,x,y)
 if bg.levelx==x and
    bg.levely==y and
    waterdrop[i]==false then
  waterdrop[i]=true
  sfx(10)
 end
end

function waterlog()
 waterlogger(1,1,2)
 waterlogger(2,1,3)
 waterlogger(3,0,2)
 waterlogger(4,4,3)
 waterlogger(5,4,2)
 waterlogger(6,2,3)
 waterlogger(7,2,1)
 waterlogger(8,3,1)
 waterlogger(9,7,3)
 waterlogger(10,6,3)
 waterlogger(11,7,1)
 waterlogger(12,6,1)
 waterlogger(13,7,0)
 waterlogger(14,6,0)
 waterlogger(15,1,0)
end

function itemplacement()
 bird.x=200
 bird.y=200
 block.x=200
 block.y=200
 water.x=200
 water.y=200
 bridge.x=200
 bridge.y=200
 bomb.x=200
 bomb.y=200
 bomb.splode=false
 sfx(-1)
 local lx=bg.levelx
 local ly=bg.levely 
 if lx==0 then
  if ly==0 then
   if birdcatch[1]==false then
    birdspot(80,38)
   end
   bombdropper(13,104,8)
  elseif ly==1 then
   if birdcatch[4]==false then
    birdspot(96,110)
   end
   bombdropper(12,40,104)
  elseif ly==2 then
   placeblock(waterdrop[3],64,112,40,40,64,112)
  elseif ly==3 then
   if birdcatch[5]==false then
    birdspot(76,58)
   end
  end
 end
 if lx==1 then
  if ly==0 then
   if birdcatch[2]==false then
    birdspot(60,54)
   end
   placeblock(waterdrop[15],72,64,80,64,72,64)
  elseif ly==2 then
   placeblock(waterdrop[1],96,96,96,80,96,96)
   bombdropper(5,72,64)
  elseif ly==3 then
   placeblock(waterdrop[2],40,48,64,48,40,48)
   bombdropper(7,104,80)
  end
 end
 if lx==2 then
  if ly==0 then
   placeduck(5,60,10,20)
   placeduck(5,90,10,70)
  elseif ly==1 then
   placeduck(3,109,5,5)
   placeblock(waterdrop[7],112,88,104,56,112,88)
  elseif ly==2 then
   if birdcatch[3]==false then
    birdspot(60,74)
   end
   bombdropper(10,80,88)
  elseif ly==3 then
   if birdcatch[6]==false then
    birdspot(72,15)
   end
   placeblock(waterdrop[6],24,24,72,40,24,24)
  end
 end
 if lx==3 then
  if ly==1 then
   placeduck(9,15,5,10)
   placeduck(9,70,5,5)
   placeblock(waterdrop[8],56,72,16,56,56,72)
   bombdropper(11,0,104)
  elseif ly==3 then
   bombdropper(6,8,24)
  end
 end
 if lx==4 then
  if ly==1 then
   placeduck(5,45,5,5)
   if birdcatch[7]==false then
    birdspot(24,78)
   end
   bombdropper(8,96,64)
  elseif ly==2 then
   placeblock(waterdrop[5],112,48,80,64,112,48)
   bombdropper(9,112,80)
  elseif ly==3 then
   placeduck(5,105,5,110)
   placeblock(waterdrop[4],72,72,44,60,72,72)
  end
 end
 if lx==5 then
  if ly==1 then
   placeduck(9,75,7,17)
   placeduck(5,100,5,85)
  elseif ly==0 then
   if birdcatch[8]==false then
    birdspot(60,76)
   end
  elseif ly==3 then
   placeduck(5,100,5,80)
   placeduck(5,30,5,90)
   placeduck(5,95,5,100)
  end
 end
 if lx==6 then
  if ly==3 then
   placeblock(waterdrop[10],48,48,48,24,48,48)
   bombdropper(1,112,104)
  elseif ly==1 then
   placeblock(waterdrop[12],56,24,40,96,56,24)
   bombdropper(2,48,64)
  elseif ly==0 then
   placeblock(waterdrop[14],88,112,24,104,88,112)
   bombdropper(4,96,48)
  end
 end 
 if lx==7 then
  if ly==0 then
   placeblock(waterdrop[13],8,48,16,88,8,48)
   bombdropper(3,112,8)
  elseif ly==1 then
   placeblock(waterdrop[11],8,80,48,96,8,80)
  elseif ly==3 then
   placeblock(waterdrop[9],8,40,64,48,8,40)
  end
 end
end

function birdspot(x,y)
 bird.x=x
 bird.y=y
end

function bombdropper(i,x,y,bx,by)
 if bombdrop[i]==false then
  bomb.x=x
  bomb.y=y
  add(bomb,make_bomb(x,y,s))
 end
end

function patchcheck()
--set default for patch
--if not on a patched screen
 bg.buttonpatchx=200
 bg.buttonpatchy=200
 bg.moundpatchx=200
 bg.moundpatchy=200
--set patch location for bomb
--buttons only
 patcher(1,6,3,57,57)
 patcher(2,6,1,73,9)
 patcher(3,7,0,97,25)
 patcher(4,6,0,113,65)
 patcher(5,1,2,57,89)
 patcher(6,3,3,81,9)
 patcher(7,1,3,9,9)
 patcher(8,4,1,89,112)
 patcher(9,4,2,57,32)
 patcher(10,2,2,97,73)
 patcher(11,3,1,105,57)
 patcher(12,0,1,9,113)
 patcher(13,0,0,41,56)

--set patch locations for
--mounds only
 moundpatcher(1,1,1,104,17)
 moundpatcher(2,5,1,40,81)
 moundpatcher(3,0,2,16,113)
 moundpatcher(4,5,3,32,25)
 moundpatcher(5,5,0,112,65)
 moundpatcher(6,1,2,72,96)
 moundpatcher(7,3,2,88,81)
 moundpatcher(8,6,2,112,88)
end

function moundpatcher(i,x,y,bx,by)
 if bg.levelx==x and
    bg.levely==y and
    bg.roll==false and
    treasure[i]==true then
  bg.moundpatchx=bx
  bg.moundpatchy=by
 end
end

function patcher(i,x,y,bx,by)
 if bg.levelx==x and
    bg.levely==y and
    bg.roll==false and
    bombdrop[i]==true then
  bg.buttonpatchx=bx
  bg.buttonpatchy=by
 end
end

function placeduck(xvar,xpos,yvar,ypos)
 duck.x=(flr(rnd(xvar))+xpos)
 duck.y=(flr(rnd(yvar))+ypos)
 add(duck,make_duck(x,y,s,p,sf,t))   
end

function placeblock(watval,watx,waty,blox,bloy,brix,briy)
 if watval==false then
  water.x=watx
  water.y=waty
  block.x=blox
  block.y=bloy
 else
  bridge.x=brix
  bridge.y=briy
 end
end

function make_block(x,y,s)
 local new_block={
 x=block.x,
 y=block.y,
 s=block.s,
 xd=0,
 yd=0,
 }
 return new_block
end

function draw_block(thisblock)
 spr(thisblock.s,thisblock.x,thisblock.y+bg.ss)
 if thisblock.x<150 then
  if block.t<150 then
   block.t+=1
  else
   block.t-=150
  end
 end
 if block.t==130 then
  thisblock.s=8
  sfx(3)
 elseif block.t==135 then
  thisblock.s=7
  sfx(3)
 elseif block.t==140 then
  thisblock.s=9
  sfx(3)
 elseif block.t==145 then
  thisblock.s=7
  sfx(3)
 end
end

function blockbump(thisblock)
 local r=mget(((thisblock.x+8)/8)+bg.x,((thisblock.y+4)/8)+bg.y)
 local l=mget(((thisblock.x/8)+bg.x)-.5,((thisblock.y+4)/8)+bg.y)
 local t=mget(((thisblock.x+4)/8)+bg.x,(((thisblock.y/8))+bg.y)-.5)
 local b=mget(((thisblock.x+4)/8)+bg.x,((thisblock.y+8)/8)+bg.y)
 local rt=false
 local lt=false
 local tt=false
 local bt=false
 --detecting walls
 if fget(r,1) then
  thisblock.x=flr((thisblock.x)/8)*8  
  rt=true
 end
 if fget(l,1) then
  thisblock.x=flr((thisblock.x)/8)*8  
  lt=true
 end
 if fget(b,1) then
  thisblock.y=flr((thisblock.y)/8)*8  
  bt=true
 end
 if fget(t,1) then
  thisblock.y=flr((thisblock.y)/8)*8  
  tt=true
 end
 local hbxl=thisblock.x
 local hbxr=thisblock.x+8
 local hbyt=thisblock.y
 local hbyb=thisblock.y+8
--horizontal pushing
 if rt==false and
    guy.x<hbxr and
    guy.x>hbxl+3 and
    guy.y>hbyt-6 and
    guy.y<hbyb-2 then
  if lt==false then
   thisblock.x-=4
   guy.x+=1
   sfx(2)
  else 
   guy.x+=1.5
  end
 end
 if lt==false and
    guy.x>hbxl-8 and
    guy.x<hbxr-3 and
    guy.y>hbyt-6 and
    guy.y<hbyb-2 then
  if rt==false then
   thisblock.x+=4
   guy.x-=1
   sfx(2)
  else 
   guy.x-=1.5
  end
 end
--vertical pushing
 if bt==false and
    guy.y<hbyb and
    guy.y>hbyt+3 and
    guy.x>hbxl-6 and
    guy.x<hbxr-2 then
  if tt==false then
   thisblock.y-=4
   guy.y+=1
   sfx(2) 
  else 
   guy.y+=1.5
  end
 end
 if tt==false and
    guy.y>hbyt-8 and
    guy.y<hbyb-3 and
    guy.x>hbxl-6 and
    guy.x<hbxr-2 then
  if bt==false then
   thisblock.y+=4
   guy.y-=1
   sfx(2)
  else
   guy.y-=1.5
  end
 end
 if bg.roll==true then
  del(block,thisblock)
 end
--water detection
 if water.x<hbxr and
    water.x>hbxl+3 and
    water.y>hbyt-6 and
    water.y<hbyb-2 then
  water.del=true
  del(block,thisblock)
 end
 if water.x>hbxl-8 and
    water.x<hbxr-3 and
    water.y>hbyt-6 and
    water.y<hbyb-2 then
  water.del=true
  del(block,thisblock)
 end
 if water.y<hbyb and
    water.y>hbyt+3 and
    water.x>hbxl-6 and
    water.x<hbxr-2 then
  water.del=true
  del(block,thisblock)
 end
 if water.y>hbyt-8 and
    water.y<hbyb-3 and
    water.x>hbxl-6 and
    water.x<hbxr-2 then
  water.del=true
  del(block,thisblock)
 end
end

function secretblock()
 if bg.levelx==3 and
    bg.levely==3 then
  if bird.count<6 and
     guy.y>30 then
   if guy.x>112 then
    guy.x=112
    guy.xdir=-1
   end
  end
 end
end

function make_water(x,y,s)
 local new_water={
 x=water.x,
 y=water.y,
 s=water.s,
 }
 return new_water
end

function draw_water(thiswater)
 spr(thiswater.s,thiswater.x,thiswater.y+bg.ss)
end

function waterbounds(thiswater)
 local hbxl=thiswater.x
 local hbxr=thiswater.x+8
 local hbyt=thiswater.y
 local hbyb=thiswater.y+8
 local gx=guy.x
 local gy=guy.y
 if gx<hbxr and
    gx>hbxl+3 and
    gy>hbyt-6 and
    gy<hbyb-2 then
  guy.x+=1.5
 end
 if gx>hbxl-7 and
    gx<hbxr-3 and
    gy>hbyt-6 and
    gy<hbyb-2 then
  guy.x-=1.5
 end
 if gy<hbyb and
    gy>hbyt+3 and
    gx>hbxl-6 and
    gx<hbxr-2 then
  guy.y+=1.5
 end
 if gy>hbyt-7 and
    gy<hbyb-3 and
    gx>hbxl-6 and
    gx<hbxr-2 then
  guy.y-=1.5
 end
 if bg.roll==true then
  del(water,thiswater)
 end
 if water.del==true then
  waterlog()
  del(water,thiswater)
  bridge.x=water.x
  bridge.y=water.y
  for i=1,15 do
   add(splash,make_splash(x,y,xdir,ydir))
  end
  add(bridge,make_bridge(x,y,s))
  water.del=false
 end
 if thiswater.s<68.9 then
  thiswater.s+=.1
 else
  thiswater.s-=4.9
 end
end

function make_dsplash(x,y,r,c,t)
 local new_dsplash={
 x=dsplash.x,
 y=dsplash.y,
 r=1.5,
 c=7,
 t=(rnd(20)+20)/150,
 }
 return new_dsplash
end

function draw_dsplash(thisdsplash)
 circ(thisdsplash.x,thisdsplash.y,thisdsplash.r,thisdsplash.c)
end

function dsplashgrow(thisdsplash)
 local tdsr=thisdsplash.r
 if tdsr<(rnd(2)+7) then
  thisdsplash.r+=thisdsplash.t
 else
  del(dsplash,thisdsplash)
 end
 if tdsr>3.5 and
    tdsr<4 then
  thisdsplash.c=12
 elseif tdsr>4 and
        tdsr<6 then
  thisdsplash.c=13
 elseif tdsr>6 then
  thisdsplash.c=12
 end
 if bg.roll==true then
  del(dsplash,thisdsplash)
 end
end

function make_duck(x,y,s,p,sf,t)
 local new_duck={
 x=duck.x,
 y=duck.y,
 s=73,
 p=flr(rnd(5)),
 sf=false,
 t=flr(rnd(30))+9,
 tl=flr(rnd(20))+20,
 }
 return new_duck
end

function draw_duck(thisduck)
 if thisduck.p==3 then
  pal(3,7)
  pal(5,7)
  pal(2,14)
  pal(4,6)
 elseif thisduck.p==4 then
  pal(3,10)
  pal(5,10)
  pal(2,9)
  pal(4,5)
  pal(6,5)	 
 elseif thisduck.p==2 then
  pal(3,15)
  pal(5,15)
  pal(2,14)
  pal(4,2)
  pal(6,2) 
 elseif thisduck.p==1 then
  pal(3,10)
  pal(5,10)
  pal(2,15)
  pal(4,9)
  pal(6,9) 
 end
 spr(thisduck.s,thisduck.x,thisduck.y+bg.ss,1,1,thisduck.sf)
 pal()
end

function duckfloat(thisduck)
--reverse direction when limit hit
 if thisduck.tl>thisduck.t then
   thisduck.tl=0
  if thisduck.sf==false then
   thisduck.sf=true
  else
   thisduck.sf=false
  end
 else
  thisduck.tl+=.5
 end
 if thisduck.sf==false then
  thisduck.x-=.25
 else
  thisduck.x+=.25
 end
 if bg.roll==true then
  del(duck,thisduck)
 end
--ducks twitch when barking
 if guy.bark>0 then
  thisduck.y+=(5-guy.bark)
 end
--add a ducksplash
 if guy.bark==1 then
  dsplash.x=thisduck.x+4
  dsplash.y=thisduck.y+7
  sfx(23)
  for i=1,5 do
   add(dsplash,make_dsplash(x,y,r,c,t))   
  end
 end
end

function make_splash(x,y,xdir,ydir)
 local new_splash={
 x=bridge.x+3,
 y=bridge.y+6,
 xdir=(rnd(4)-2),
 ydir=(rnd(2)-6),
 }
 return new_splash
end

function draw_splash(thissplash)
 circfill(thissplash.x,thissplash.y,1,12)
end

function splashfall(thissplash)
 thissplash.y+=thissplash.ydir
 thissplash.x+=thissplash.xdir
 thissplash.ydir+=.8
 if thissplash.y>(bridge.y+((rnd(5)+13))) then
  del(splash,thissplash)
 end
end

function make_bridge(x,y,s)
 local new_bridge={
 x=bridge.x,
 y=bridge.y,
 s=bridge.s,
 }
 return new_bridge
end

function draw_bridge(thisbridge)
 spr(thisbridge.s,thisbridge.x,thisbridge.y+bg.ss)
end

function bridgeanim(thisbridge)
 if bg.roll==true then
  del(bridge,thisbridge)
 end
 if thisbridge.s<84.9 then
  thisbridge.s+=.1
 else
  thisbridge.s-=4.9
 end
end

function anim()
 if guy.xd<.1 and guy.xd>-.1 then
  if guy.yd<.1 and guy.yd>-.1 then
   guy.m=false
   guy.s=1
   guy.sc=0
  else
   guy.m=true
  end
 else 
  guy.m=true
 end
 if guy.xd>=0 then
  guy.sf=true
 else
  guy.sf=false
 end
 if guy.m==true then
  if guy.sc<3.8 then
   guy.sc+=.2
  else 
   guy.sc-=3.8
  end
 end
 if guy.sc>0 then
  if guy.sc-(flr(guy.sc))<.2 then
   if game.start==false and
      bg.tune==99 then
    sfx(0)
   end
  end
 end
 if guy.digging==true then
  guy.digc+=1
  guy.sc=0
  if guy.digc>9 then
   guy.digc-=10
   guy.digclick+=1
  end
  if guy.digc<5 then
   guy.s=60
  else
   guy.s=59
  end
  if guy.digc==1 then
   sfx(26)
   bg.ssc=2
  end
 end
end

function guymove()
 if game.startwipe2xmove==false then
  guy.x+=guy.xd
  guy.y+=guy.yd
  guy.xd*=.8
  guy.yd*=.8
 end
 if game.start==false then
  if btn(0) then
   if guy.xd>-1.16 then
    guy.xd-=.4
   end
  elseif btn(1) then
   if guy.xd<1.16 then
    guy.xd+=.4
   end
  end
  if btn(2) then
   if guy.yd>-1.16 then
    guy.yd-=.4
   end
  elseif btn(3) then
   if guy.yd<1.16 then
    guy.yd+=.4
   end
  end
 end
end

function collision()
 local r=mget(((guy.x+8)/8)+bg.x,((guy.y+4)/8)+bg.y)
 local l=mget(((guy.x/8)+bg.x),((guy.y+4)/8)+bg.y)
 local t=mget(((guy.x+4)/8)+bg.x,((guy.y/8))+bg.y)
 local b=mget(((guy.x+4)/8)+bg.x,((guy.y+8)/8)+bg.y)
--walls
 if fget(r,1) then
  guy.x=flr((guy.x)/8)*8  
  guy.xd*=.5
 elseif fget(l,1) then
  guy.x=flr((guy.x+8)/8)*8  
  guy.xd*=.5
 end
 if fget(b,1) then
  guy.y=flr((guy.y)/8)*8  
  guy.yd*=.5
 elseif fget(t,1) then
  guy.y=flr((guy.y+8)/8)*8  
  guy.yd*=.5
 end
--text boxes
 if fget(r,3) or
    fget(l,3) or 
    fget(b,3) or
    fget(t,3) then
  tbox.active=true
 else
  tbox.active=false
  tbox.grow=false
 end
--bomb buttons
 if fget(r,4) or
    fget(l,4) or 
    fget(b,4) or
    fget(t,4) then
  bomb.button=true
 else
  bomb.button=false
 end
--diggable holes
 if fget(r,5) or
    fget(l,5) or 
    fget(b,5) or
    fget(t,5) then
  hole.diggable=true
 else
  hole.diggable=false
 end
end

function scrollset()
 bg.roll=false
 bg.click=16
 bg.l=-4
 bg.r=124
 bg.u=-4
 bg.d=124
 guy.tx=guy.x
 guy.ty=guy.y
 itemplacement()
 itemgen()
 block.t=0
end

function scrollright()
 if bg.click>0 then
  bg.roll=true
  bg.click-=1
  bg.x+=1
  guy.x-=7.5
  bg.r=(guy.x-1)
 else
  guy.x=4
  bg.levelx+=1
  guy.xd=.5
  scrollset()
 end 
end

function scrollleft()
 if bg.click>0 then
  bg.roll=true
  bg.click-=1
  bg.x-=1
  guy.x+=7.5
  bg.l=(guy.x+1)
 else
  guy.x=116
  bg.levelx-=1
  guy.xd=-.5
  scrollset()
 end 
end

function scrollup()
 if bg.click>0 then
  bg.roll=true
  bg.click-=1
  bg.y-=1
  guy.y+=7.5
  bg.u=(guy.y+1)
 else
  guy.y=116
  bg.levely-=1
  guy.yd=-.5
  scrollset()
 end 
end

function scrolldown()
 if bg.click>0 then
  bg.roll=true
  bg.click-=1
  bg.y+=1
  guy.y-=7.5
  bg.d=(guy.y-1)
 else
  guy.y=4
  bg.levely+=1
  guy.yd=.5
  scrollset()
 end 
end

function screenshake()
 if bg.ssc>0 then
  bg.ssc-=1
  if bg.ssc%2==0 then
   bg.ss=0
  else
   bg.ss=1
  end
 end
end

function scrollbox()
 if guy.x>bg.r then
  scrollright()
 end
 if guy.x<bg.l then
  scrollleft()
 end
 if guy.y>bg.d and
    guy.x<bg.r and 
    guy.x>bg.l then
  scrolldown()
 end
 if guy.y<bg.u and
    guy.x<bg.r and
    guy.x>bg.l then
  scrollup()
 end
end

function digcheck()
 digger(1,1,1)
 digger(2,5,1)
 digger(3,0,2)
 digger(4,5,3)
 digger(5,5,0)
 digger(6,1,2)
 digger(7,3,2)
 digger(8,6,2)
end

function dugcheck()
 dugger(1,1,1)
 dugger(2,5,1)
 dugger(3,0,2)
 dugger(4,5,3)
 dugger(5,5,0)
 dugger(6,1,2)
 dugger(7,3,2)
 dugger(8,6,2)
end

function digger(i,x,y)
 if bg.levelx==x and
    bg.levely==y and
    treasure[i]==false then
--get treasure
  treasure[i]=true
  prize.x=guy.x+2
  prize.y=guy.y-6
  bg.whatget=false
  treasure.count+=1
  game.showcount=90
  sfx(28)
 end
end

function dugger(i,x,y)
 if bg.levelx==x and
    bg.levely==y and
    treasure[i]==false then
  hole.dug=false
 end
 if bg.levelx==x and
    bg.levely==y and
    treasure[i]==true then
  hole.dug=true
 end
end

function statues(x,y)
  spr(74,x+0,y+0)
  spr(75,x+8,y+0)
  spr(92,x+4,y+16)
  spr(90,x+0,y+8)
  spr(91,x+8,y+8)
end

-------------draw---------------

function _draw()
cls()
local bgss=bg.ss
rectfill(0,0,128,128,3)
 if bg.levelx==3 and
    bg.levely==3 and
    bg.roll==false then
  if bg.shad<150 then
   rectfill(bg.shad-1,86,bg.shad+48,87,2)
  end
 end
--maze castle palette swap
 if bg.levelx>5 then
  pal(1,2)
  pal(2,2)
  pal(4,2)
  pal(5,2)
  pal(6,2)
  pal(8,2)
  pal(11,2)
  pal(13,2)
  pal(3,0)
  pal(9,0)
  pal(10,0)
  rectfill(0,0,128,128,0)
 end
--draw background map
 map(bg.x,bg.y,0,0+bgss,16,16+bgss)
--bomb-button patch
 rectfill(bg.buttonpatchx,bg.buttonpatchy,bg.buttonpatchx+5,bg.buttonpatchy+7,3)
 spr(53,bg.buttonpatchx-1,bg.buttonpatchy+bgss)
--hole-dig patch
 rectfill(bg.moundpatchx,bg.moundpatchy,bg.moundpatchx+7,bg.moundpatchy+7,3)
 spr(100,bg.moundpatchx-1,bg.moundpatchy+bgss)
 pal()
--nests
 if bg.levelx==0 and
    bg.levely==0 and
    bg.roll==false then
  for i=1,bird.count do
   if i/2==flr((i/2)+.4) then
    d=2
   else
    d=1
   end
  spr(49,(64+(flr((i/2)-.5))*16),77+d*16+bgss)
  end
 end
 foreach(bridge,draw_bridge)
 foreach(dirt,draw_dirt)
--maze dog sprite
 spr(guy.s+guy.sc,guy.x,guy.y+bgss,1,1,guy.sf)
--shadow dog
 if bg.levelx==6 and
    bg.levely==2 and
    bg.roll==false then
  if guy.y<40 or guy.y>80 then
   for i=1,7 do
    pal(i,flr(rnd(15))+1)
   end
   if guy.y<40 then
    u=(64-guy.y)+56
   else
    u=56-(guy.y-64)
   end
   spr(guy.s+guy.sc,guy.x,u,1,1,guy.sf)
   pal()
  end
 end
 foreach(bird,draw_bird)
 foreach(block,draw_block)
 foreach(bomb,draw_bomb)
 foreach(water,draw_water)
 foreach(splash,draw_splash)
 foreach(dsplash,draw_dsplash)
 foreach(duck,draw_duck)
 foreach(poof,draw_poof)
 rectfill(bg.swipex,0,bg.swipex+140,128,0)
--cloud of doom
 if bg.levelx==5 and
    bg.levely==2 and
    bg.roll==false then
  for i=1,(guy.y/1.5) do
   circfill((142-((flr(rnd(guy.x))/3.7))-flr(rnd(20))),(flr(rnd(guy.y))-((guy.x/bg.cloudpass)*(bg.cloud/2))),guy.x/8,(flr(rnd(2))+6))
  end
  for i=1,(128-(guy.y*1.1)) do
   circfill((142-((flr(rnd(guy.x))/3.7))-flr(rnd(20))),(guy.y+flr(rnd((128-guy.y)))+((guy.x/bg.cloudpass)*(bg.cloud/2))),guy.x/8,(flr(rnd(2))+6))
  end
  if bg.cloudpass>10 then
   if guy.x>115 then
    guy.xd=-3
   end
  end
 end
--mystical statue of mystery
 if bg.levelx==3 and
    bg.levely==3 and
    bg.roll==false then
  spr(74,56,56)
  spr(75,64,56)
  spr(92,60,72)
  spr(90,56,64)
  spr(91,64,64)
 end
--castle statues of mystery
 if bg.levelx>5 then
  pal(11,8)
  pal(6,2)
  pal(5,2) 
 end
 if bg.levelx==7 and
    bg.levely==2 and
    bg.roll==false then
  local vx=24
  local vy=24
  local wx=72
  local wy=72
--statue top left
 statues(24,24)
 statues(24,72)
 statues(72,24)
 statues(72,72)
 end
 pal()
--alert box
 if tbox.active==true or 
    bomb.button==true or
    hole.diggable==true then
  local j=-8
        d=true
  if guy.sf==true then
   j=8
   d=false
  end
  spr(tbox.s,guy.x+j,guy.y-8,1,1,d)
 end
--happy snack voice box
 if bg.whatget==false and
    game.showcountbool==true then
  local j=-8
        d=true
  if guy.sf==true then
   j=8
   d=false
  end
  spr(97,guy.x+j,guy.y-8,1,1,d)
 end
--text box palette swap
 if bg.levelx>5 then
  pal(3,0)
  pal(11,2)
  pal(4,1)
  pal(13,0) 
 end
--draw text box
 if tbox.x>0 then
  rectfill(0,70,tbox.x,tbox.y,11)
  rect(2,72,tbox.x-3,tbox.y-2,3)
 end
--text box words
 if tbox.x==128 and
    tbox.y==112 then
  print(tbox.t1,8,78,tbox.tc)
  print(tbox.t2,8,89,tbox.tc)
  print(tbox.t3,8,100,tbox.tc)
 end
 pal()
--wifi bark and anim
 if guy.bark>0 then
  local l=guy.x-10
        q=true
  if guy.sf==true then
   l=guy.x+10
   q=false
  end
  if guy.bark>5 then
   local v=guy.bark+117
   spr(v,l,guy.y-1,1,1,q)
  end 
 end
--countbar
 if game.showcountbool==true then
  if bg.levelx>5 then
   pal(3,0)
   pal(11,2)
   pal(4,1)
   pal(13,0) 
  end
--bird and cushion count bar
  rectfill(44,4,84,16,3)
  rect(44,4,84,16,11)
--bird sprite and count
  spr(49,46,5)
  print(bird.count,55,8,7)
--cushion sprite and count
  print(treasure.count,78,8,7)
  spr(96,69,7)
--player prompt
  local b=(8-bird.count)
  local t=(8-treasure.count)
  if bg.whatget==true then
   print(b,40,20,7)
   print("birds left!",48,20,7)
  elseif bg.whatget==false then
   print(t,37,20,7)
   print("snacks left!",45,20,7)
  else
   print("that's it! return home to win!",5,20,7)
  end
 end
 pal()
--endgame
 if game.win==true then
  rectfill(game.endwipex-127,16+bgss,game.endwipex,112+bgss,3)
  rect(game.endwipex-127,16+bg.ss,game.endwipex,112+bgss,11)
  print("congratulations!",game.endwipex-94,23+bgss,11)
  print("-----------------------------",game.endwipex-121,31+bgss,11)
  print("you found all eight birds!",game.endwipex-115,37+bgss,11)
  print("snack score:  /8",game.endwipex-95,43+bgss,11)
  print(treasure.count,game.endwipex-43,43+bgss,11)
  print("maze land is safe! for now...",game.endwipex-121,49+bgss,11)
  print("-----------------------------",game.endwipex-121,55+bgss,11)
--timer
 local v=timer[4]
  print("your time",v,61,11)
  print(timer[3],v,67,11)
  print("minutes",v+20,67,11)
  print(timer[2],v,73,11)
  print("seconds",v+20,73,11)
  print(timer[1],v,79,11)
  print("moments",v+20,79,11)
--hiscore - restore when ready
  print("best time",v+68,61,11)
  print(hiscore[3],v+68,67,11)
  print("minutes",v+88,67,11)
  print(hiscore[2],v+68,73,11)
  print("seconds",v+88,73,11)
  print(hiscore[1],v+68,79,11)
  print("moments",v+88,79,11)
  print("-----------------------------",game.endwipex-121,85+bgss,11)
  print("well done, noble maze dog!",game.endwipex-115,91+bgss,11)
  print("you've earned a nice long nap",game.endwipex-121,97+bgss,11)
  print("press [x] to continue",game.endwipex-105,103+bgss,11)
--endgameswipe
  rectfill(-2,-2,130,game.endgameswipey,3)
  rect(-2,-2,130,game.endgameswipey,11)
 end
--startgame
 if game.start==true then
  rectfill(0,0,128,128,3)
  map(64,0,4,-8,79,15)
--instructions
  print("⬆️⬇️⬅️➡️ to walk",33,92,11)
  print("[x] to bark and read",25,99,11)
  print("[z] to dig",45,106,11)
  print("press [x] to start",29,113,11)
--instruct border lines
  rect(22,89,106,120,11)
  rect(20,87,108,122,11)
--logo border lines
  rect(-1,2,129,67,11)
  rect(-1,4,129,69,11)
--mask
  rectfill(game.startwipex,0,128,128,3)
  spr(guy.s+guy.sc,guy.x,guy.y,1,1,guy.sf)
  print("eggnog games",game.eggnogx,game.eggnogy+2,11)
  rect(game.eggnogx-2,game.eggnogy,game.eggnogx+48,game.eggnogy+8,11)
 end
--start-game swipe
 rectfill(game.startwipe2x,-3,game.startwipe2x+128,130,3)
 rect(game.startwipe2x,-3,game.startwipe2x+128,130,11)
end