
-- hollow seeker
-- by obono

-- bland logo

function init_logo()
 gm=1
 gc=60 -- wait 2s
 gd=true
end

function update_logo()
 gc-=1
 if (gc<=0) init_title()
end

function draw_logo()
 rectfill(0,0,127,127,5)
 map(122,29,38,56,2,2) -- o
 map(124,28,56,48,2,3) -- b
 map(126,29,74,56,2,2) -- n
 map(125,31,66,72,3,1) -- soft
 print("obn-p01 ver 0.61",
   32,82,6)
end

-- title screen

function init_title()
 gm=2
 cg=153
 ck=8
 px=0
 pa=0
 gd=true
end

function update_title()
 if (px<128) do_attraction()
 if (btnp(4) or btnp(5)) then
  if (px<128) then
   px=128 cg=8 ck=0
  else
   init_game()
  end
 end
end

function do_attraction()
 if (cg<8) then
  if (ck>0) then ck-=1
    else cg+=1 end
 else
  if (cg>8) cg-=max(px-38,0)
  if (cg==0) sfx(1)
  local v=1
  if (cg==8) v=2
  px+=v pa=(pa+v/2)%4
  if (pa==1) sfx(0)
 end
 gd=true
end

function draw_title()
 cls()
 local t=ck%2-flr(cg/2)
 local b=t+cg
 if (cg<152) then
  map(0,0,28,36+t,8,2)
  map(0,2,36,52+b,8,2)
 end
 spr(pa+16,px,max(52+t,48))
 if (px==128) then
  print("press any button",
    32,88,7)
 end
 print("2015.10 "..
   "programmed by obono",
   10,112,5)
end

-- game functions

function init_game()
 gm=3
 gc=60
 cv={} -- columns of cave
 cs=0 -- wave phase
 cr=32 -- wave amplitude
 cg=0 -- current gap size
 ct=0 -- top offset
 cb=0 -- bottom offset
 cx=0 -- scroll offset
 cp=7 -- next column pos
 cm=1 -- next hollow counter
 cq={} -- fragments
 pp=0 -- player logical pos
 px=0 -- player x
 py=72 -- player y
 pv=0 -- player vx
 pw=0 -- player vy
 pa=0 -- player anim no.
 pf=false -- player direction
 pe=false -- player dead
 sc=0 -- score
 for i=0,17 do
  set_column(i,72,80)
 end
 for i=8,16 do
  grow_cave()
 end
 sfx(2)
 gd=true
end

function update_game()
 calc_gap()
 update_fragments()
 handle_input()
 move_player()
 if (pe) then
  game_over()
 elseif (gc==0) then
  judge_crushed()
 else
  gc-=1
  if (gc==0) start_music()
 end
 gd=true
end

function calc_gap()
 cg=flr((1-cos(cs/192))*cr)
 ct=-flr(cg/2)
 if (cs>=187) ct+=cs%2
 cb=ct+cg
end

function set_column(x,t,b)
 local i
 for i=0,15 do
  -- top
  if (i*8<t-7) then v=8
  elseif (i*8>t) then v=0
  else v=t%8
  end
  mset(x,i+16,v)
  -- bottom
  if (i*8<b-7) then v=0
  elseif (i*8>b) then v=8
  else v=b%8+8
  end
  mset(x+18,i+16,v)
 end
 cv[x]={t=t,b=b}
end

function grow_cave()
 local t,b,g
 cm-=1 g=(cm<0)
 extend_column(g)
 if (g) then
  cm=(rnd(1)+1)*sc/128+1
 end
 if (gc==0) then
  sc+=1
  if (sc%200==0) start_music()
 end
end 

function extend_column(g)
 local d,h,l,r,y
 d=cv[cp].b-cv[cp].t
 h=rndi(3)
 if (g) h=8-h
 l=flr((cv[cp].b-58)/12)
 r=rndi(17-abs(h-d)-abs(l))-8
 if (h>d) r+=h-d
 if (l<0) r-=l
 y=mid(32,cv[cp].b+r,96)
 cp=(cp+1)%18
 set_column(cp,y-h,y)
end

function rndi(x)
 return flr(rnd(x))
end

function start_music()
 local i,s
 s=max(13-flr(sc/200),6)
 -- set speed
 for i=8,11 do
  poke(0x3241+i*68,s)
 end
 music(0,0,3)
end

function update_fragments()
 foreach(cq,fall_fragment)
 if (gc==0 and rnd(128)>cs) then
  local x=rnd(144)
  local y=cv[flr(x/8)].t+ct
  add(cq,{x=x,y=y,w=0})
 end
end

function fall_fragment(q)
 q.y+=q.w q.w+=0.125
 local p=flr(q.x/8)
 if (q.y>=cv[p].b+cb) del(cq,q)
end

function handle_input()
 if ((cx+px)%8>0) return
 pv=0 pw=0
 if (btn(0)) pv=-1 pf=true
 if (btn(1) or gc>0) then
  pv=1 pf=false
 end
 local p=(pp+pv)%18
 local g=min(cv[pp].b-cv[p].t,
  cv[p].b-cv[pp].t)+cg
 if (px+pv<0 or g<8 or pe) then
  pv=0 pa=0
 elseif (pv!=0) then
  pw=(cv[p].b-cv[pp].b)/4
  pp=p
  if (px+pv>56) grow_cave()
  sfx(0)
 end
end

function move_player()
 if (px+pv>56) then
  cx=(cx+pv*2)%144
 else
  px+=pv*2
 end
 py+=pw
 if (pv!=0) then
  pa=(pa+1)%4
 else
  pa=0
 end
end

function judge_crushed()
 cs=(cs+1)%192
 if (cs==0) then
  if (cv[pp].b-cv[pp].t<4) then
   pe=true music(-1,0,3)
  end
  cr+=2
 end
 if (cs==187) sfx(1)
end

function game_over()
 cs+=.5
 if (btnp(4) or btnp(5)) then
  init_game()
 elseif (cs>=128) then
  init_title()
 end
 if (cs==8) sfx(3)
end

function draw_game()
 cls()
 draw_background()
 draw_ridges()
 foreach(cq,draw_fragment)
 draw_player()
 draw_cave()
 draw_strings()
end

function draw_background()
 local i,x
 for i=0,3 do
  x=i*48-cx/3
  map(0,4,x,0,6,8)
  map(0,4,x,64,6,8)
 end
end

function draw_ridges()
 local t,b=ct/2,cb/2
 rectfill(0,-1,127,49+t,0)
 rectfill(0,82+b,127,128,0)
 pal(2,0)
 local i,x
 for i=0,2 do
  x=i*72-cx/2
  map(6,4,x,50+t,9,4)
  map(6,8,x,50+b,9,4)
 end
 pal(2,2)
end

function draw_fragment(q)
 pset((q.x-cx)%144,q.y,5)
end

function draw_player()
 local y=max(py+cb,cv[pp].t+ct)
 if (pe) y=cv[pp].t+cb
 spr(16+pa,px,y,1,1,pf)
end

function draw_cave()
 map(0,16,-cx,ct,18,16)
 map(18,16,-cx,cb,18,16)
 if (cx>16) then
  map(0,16,144-cx,ct,18,16)
  map(18,16,144-cx,cb,18,16)
 end
end

function draw_strings()
 print("score "..sc,6,6,7)
 if (gc>0) then
  print("ready?",52,61,7)
 end
 if (pe and cs>=8) then
  print("game over",46,61,7)
 end
end

-- pico-8 special functions

function _init()
 init_logo()
end

update_fn={
 update_logo,
 update_title,
 update_game
}

function _update()
 update_fn[gm]()
end

draw_fn={
 draw_logo,
 draw_title,
 draw_game
}

function _draw()
 if (gd) draw_fn[gm]() gd=false
end
