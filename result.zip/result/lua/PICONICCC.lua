-- piconiccc
-- by megus, demarche & stardust
function _init()
	poke(0x5f34, 1)
	poke(0x5f2d, 1)
	pal({129},1)
	load_data()
	music(0)
	next_fx()
end



function oprint(str,x,y,col)
	for c=0,2 do
		for d=0,2 do
			print(str,x+c,y+d,0)
		end
	end
	print(str,x+1,y+1,col)
end

function sease_elastic(t,scale)
	return scale*(2^(-10*t))*-sin(t-0.25)+scale
end

function sease_cubic(t,scale)
	return (t<0.5) and (scale*(t*2)^3/2) or (scale-scale*((1-t)*2)^3/2)
end

function add_text(dots,text,ox,oy,fr)
	cls()
	print(text,0,0,7)
	local f,a=fr+60,0x4300
	memset(a,0,512)
	memcpy(a,0x6000,512)
	for y=oy,oy+23,3 do
		for x=ox,ox+383,6 do
			local v=peek(a)
			if v&15~=0 then
				add(dots,{x,y,f+rnd(#text*20)})
				f+=1
			end
			if v&0xf0~=0 then
				add(dots,{x+3,y,f+rnd(#text*20)})
				f+=1
			end
			a+=1
		end
	end
end



sc_idx,mfx_idx,ptn,otick=1,1,0,0

function loop_int(r)
	yield()
	frame+=1
	if (not r) frame=0
	return r
end

function loop_frames(frames)
	return loop_int(frame<=frames)
end

function wait_frames(frames)
	while loop_frames(frames) do end
end

function loop_sync()
	local r=mfx_time<scenario[sc_idx]
	if (not r) sc_idx+=1
	return loop_int(r)
end

function wait_sync()
	while loop_sync() do end
end

function next_fx()
	fx_coupdate,fx_update,fx_draw,fx_bg=scenario[sc_idx]()
	fx_coupdate,frame=cocreate(fx_coupdate),-1
	sc_idx+=1
end

function _update60()
	local tick = stat(26)
	if (tick<otick) ptn+=1
	otick=tick
	mfx_time=ptn+tick/4096

	if mfx_time>=mfx_scenario[mfx_idx] then
		local cmd=mfx_scenario[mfx_idx+1]
		mfx_idx+=2
		poke4(0x5f40,cmd)
	end

	if (not coresume(fx_coupdate)) next_fx()
	fx_update()
end

function _draw()
	if (fx_bg~=-1) cls(fx_bg or 0)
	fx_draw()
	--oprint(ptn,0,0,15)
end



function eg_triangle(x1,y1,x2,y2,x3,y3,color)
	local x1,x2,y1,y2,x3,y3,nsx,nex,min_y=x1&0xffff,x2&0xffff,y1&0xffff,y2&0xffff,x3&0xffff,y3&0xffff
	if (y1>y2) y1,y2,x1,x2=y2,y1,x2,x1
	if (y1>y3) y1,y3,x1,x3=y3,y1,x3,x1
	if (y2>y3) y2,y3,x2,x3=y3,y2,x3,x2

	if y1~=y2 then
		local delta_sx,delta_ex=(x3-x1)/(y3-y1),(x2-x1)/(y2-y1)

		if y1>0 then
			nsx,nex,min_y=x1,x1,y1
		else
			nsx,nex,min_y=x1-delta_sx*y1,x1-delta_ex*y1,0
		end

		local max_y=min(y2,128)-1
		for y=min_y,max_y do
			rectfill(nsx,y,nex,y,color)
			nsx+=delta_sx
			nex+=delta_ex
		end
	else
		nsx,nex=x1,x2
	end

	if y3~=y2 then
		local delta_sx,delta_ex=(x3-x1)/(y3-y1),(x3-x2)/(y3-y2)

		min_y=y2
		local max_y=min(y3,127)
		if y2<0 then
			nex,nsx,min_y=x2-delta_ex*y2,x1-delta_sx*y1,0
		end

		for y=min_y,max_y do
			rectfill(nsx,y,nex,y,color)
			nex+=delta_ex
			nsx+=delta_sx
		end
	else
		rectfill(nsx,y3,nex,y3,color)
	end
end

function striangle(x1,y1,x2,y2,x3,y3)
	eg_triangle(x1,y1,x2,y2,x3,y3,0x1100.5a5a)
	line(x1,y1,x2,y2,0x1001)
	line(x2,y2,x3,y3,1)
	line(x3,y3,x1,y1,1)
end


v2d,znear,zfar={},0.04,30

function normalize(v)
	local x,y,z=v[1],v[2],v[3]
	local len=sqrt(x*x+y*y+z*z)
	return {x/len,y/len,z/len}
end

function cross(v1,v2)
	local x1,y1,z1,x2,y2,z2=v1[1],v1[2],v1[3],v2[1],v2[2],v2[3]
	return {y1*z2-z1*y2,z1*x2-x1*z2,x1*y2-y1*x2}
end

function dot(v1,v2)
	return v1[1]*v2[1]+v1[2]*v2[2]+v1[3]*v2[3]
end

function mmult(m1,m2)
	local r={}
	for c=0,3 do
		for d=0,3 do
			local t=0
			for e=0,3 do
				t+=m1[c*4+e+1]*m2[e*4+d+1]
			end
			add(r,t)
		end
	end
	return r
end

function radix_sort(arr,mask,idx1,idx2,sortmin)
	local c,rb=idx1,idx2+1
	while c<rb do
		if arr[c][1]&mask~=0 then
			repeat
				rb-=1
				if (rb==c) break
			until arr[rb][1]&mask==0
			arr[c],arr[rb]=arr[rb],arr[c]
		end
		c+=1
	end
	if mask>=sortmin then
		mask/=2
		if (rb-1>idx1) radix_sort(arr,mask,idx1,rb-1,sortmin)
		if (rb<idx2) radix_sort(arr,mask,rb,idx2,sortmin)
	end
end

function z_clip_line(p1x,p1y,p1z,p2x,p2y,p2z,clip)
	local alpha=(p1z-clip)/(p1z-p2z)
	return lerp(p1x,p2x,alpha),lerp(p1y,p2y,alpha),lerp(p1z,p2z,alpha)
end

function lerp(a,b,alpha)
	return a+(b-a)*alpha
end

function m3d(obj,eye,dir,up,zp,sortmax,sortmin,angle)
	local xaxis=normalize(cross(dir,up))
	local yaxis=cross(xaxis,dir)
	local m={xaxis[1],xaxis[2],xaxis[3],-dot(xaxis,eye),yaxis[1],yaxis[2],yaxis[3],-dot(yaxis,eye),dir[1],dir[2],dir[3],-dot(dir,eye),0,0,0,1}
	if (angle~=nil) m=mmult(m,{cos(angle),0,sin(angle),0,0,1,0,0,-sin(angle),0,cos(angle),0,0,0,0,1})

	sorted={}

	for c=1,#obj.v do
		local v=obj.v[c]
		local v1,v2,v3=v[1],v[2],v[3]
		local x,y,z=m[1]*v1+m[2]*v2+m[3]*v3+m[4],m[5]*v1+m[6]*v2+m[7]*v3+m[8],m[9]*v1+m[10]*v2+m[11]*v3+m[12]
		v2d[c]={x,y,z,x/z,y/z}
	end

	for c=1,#obj.f do
		local tri=obj.f[c]
		local p1,p2,p3=v2d[tri[2]],v2d[tri[3]],v2d[tri[4]]
		local p1z,p2z,p3z=p1[3],p2[3],p3[3]
		local z_paint=-0.08*zp(p1z,zp(p2z,p3z))

		if p1z<zfar or p2z<zfar or p3z<zfar then
			if p1z>znear and p2z>znear and p3z>znear then
				local s1x,s1y,s2x,s2y,s3x,s3y=p1[4],p1[5],p2[4],p2[5],p3[4],p3[5]

				if (min(s1x,min(s2x,s3x))<1 and max(s1x,max(s2x,s3x))>=-1 and (s2x-s1x)*(s3y-s1y)-(s2y-s1y)*(s3x-s1x)>0) add(sorted,{z_paint,s1x,s1y,s2x,s2y,s3x,s3y,tri[1]})
			elseif p1z>znear or p2z>znear or p3z>znear then
				local p1x,p2x,p3x,p1y,p2y,p3y=p1[1],p2[1],p3[1],p1[2],p2[2],p3[2]
				if (p1z<p2z) p1z,p2z,p1x,p2x,p1y,p2y=p2z,p1z,p2x,p1x,p2y,p1y
				if (p1z<p3z) p1z,p3z,p1x,p3x,p1y,p3y=p3z,p1z,p3x,p1x,p3y,p1y
				if (p2z<p3z) p2z,p3z,p2x,p3x,p2y,p3y=p3z,p2z,p3x,p2x,p3y,p2y

				if p1z>znear and p2z>znear then
					local n2x,n2y,n2z=z_clip_line(p2x,p2y,p2z,p3x,p3y,p3z,znear)
					local n3x,n3y,n3z=z_clip_line(p1x,p1y,p1z,p3x,p3y,p3z,znear)

					local s1x,s2x,s3x,s4x,s2y,s4y=p1x/p1z,p2x/p2z,n2x/n2z,n3x/n3z,p2y/p2z,n3y/n3z

					if (min(s1x,min(s2x,s4x))<1 and max(s1x,max(s2x,s4x))>=-1) add(sorted,{z_paint,s1x,p1y/p1z,s2x,s2y,s4x,s4y,tri[1]})
					if (min(s4x,min(s2x,s3x))<1 and max(s4x,max(s2x,s3x))>=-1) add(sorted,{z_paint,s2x,s2y,s4x,s4y,s3x,n2y/n2z,tri[1]})
				else
					local n1x,n1y,n1z=z_clip_line(p1x,p1y,p1z,p2x,p2y,p2z,znear)
					local n2x,n2y,n2z=z_clip_line(p1x,p1y,p1z,p3x,p3y,p3z,znear)
					local s1x,s2x,s3x=p1x/p1z,n1x/n1z,n2x/n2z

					if (min(s1x,min(s2x,s3x))<1 and max(s1x,max(s2x,s3x))>=-1) add(sorted,{z_paint,s1x,p1y/p1z,s2x,n1y/n1z,s3x,n2y/n2z,tri[1]})
				end
			end
		end
	end

	radix_sort(sorted,sortmax,1,#sorted,sortmin)
	for c=1,#sorted do
		local tri=sorted[c]
		triangle(64-64*tri[2],64-64*tri[3],64-64*tri[4],64-64*tri[5],64-64*tri[6],64-64*tri[7],tri[8])
	end
end



colors,fp,renderlist,arcs,objects,campath,emus,emusl,esfx,esfxl={{128,132,4,137,9,135,6},{128,132,4,134,6},{129,1,140,12,5,6,10},{133,130,5,13,134,6,10},{128,133,5,13,134,6,10},{128,131,3,5,134,6,10},{128,132,4,131,3,5,134},{128,131,3,139,133,5,6},{129,1,130,140,5,6,10},{128,130,132,4,9,137,10},{130,2,133,4,134,143}},{{1,2,3},{4,5,1},{-1,2,1},{-4,-1,3},{-1,3,4},{1,-3,-4},{8,9,1},{8,1,-7},{8,54,53},{1,47,46},{-8,47,46},{-1,52,55},{3,4,7},{9,19,10},{-1,9,10},{1,5,4},{-3,1,4},{1,7,6},{-6,-11,-5},{4,9,8},{-5,6,5},{6,12,11},{-4,7,6},{-1,7,11},{1,6,5},{-4,1,5},{4,18,17},{-6,15,14},{7,22,21},{-4,16,15},{-1,16,20},{4,27,26},{-7,24,23},{8,32,31},{-4,25,24},{-1,25,29},{4,36,35},{-8,33,32},{5,42,41},{-4,38,37},{3,38,42},{1,3,4},{-2,4,-2},{-7,-4,-7},{-1,-5,-4},{-6,4,-6},{-3,1,-3},{-10,-3,-10},{-1,-4,2},{1,4,6},{-6,-5,1},{2,6,4},{-2,2,4},{4,1,-3},{16,17,1},{16,1,-15},{16,94,93},{1,79,78},{-16,79,78},{-1,92,95},{1,-14,-13},{1,4,5},{5,8,13},{1,9,8},{-7,1,8},{-17,-16,-1},{9,8,1},{-13,-12,-1},{5,4,1},{17,18,7},{-9,-2,1},{12,11,-1},{12,19,7},{8,15,7},{1,4,3},{1,10,9},{3,10,9},{-1,8,7},{-3,6,9},{-11,-17,6},{6,17,23},{13,12,-1},{-1,12,13},{5,6,1},{8,9,-3},{1,15,14},{-3,11,14},{1,-17,-18},{-9,-27,-18},{1,-9,-10},{-9,-19,-10},{1,2,11},{3,6,9},{1,-11,-12},{-11,-23,-12},{5,8,9},{1,5,6},{3,2,1},{20,9,8},{-2,4,1},{-1,-2,-3},{1,22,21},{-20,1,21},{1,2,8},{1,-8,-9},{-8,-17,-9},{-9,6,5},{-1,16,15},{9,18,17},{1,6,9}},{"cubes","room","cubes2","room","room","arch2","tonnel5","arch2","arch2","arch2","arch1","rotor","tonnel4","rotor","rotor","rotor","rotorin","rotor","tonnel3","tonnel2","tonnel2","tonnel2","tonnel1","tonnel2","tonnel0","tonnel0","O","oxygene","X","oxygene","E1","oxygene","N","oxygene","E","oxygene","G","oxygene","Y","oxygene","oxygenein","oxygene"},{{0,"........4043.4668..8090.a2ab...b2d9.ecf9.64e0...0c7f..1f47.5d6b...7988.a5ac..bed035....95b4...040b.2528..5355.637d....8a93.a8ca..dbdd29..2f3b.586e....7581.aeb06d66......e9.e610.45a1..d4ef..1617.181c99.....1d52.8baa..d6d8.dfe2...e8f04c.5c67...6f8f.d7.fd.08e34f....d3.0d779f...a0b1.c7..e7f601.33..0912.1538..bf...5457.6992..9ab8.cbce....e1ed.f2f3.393e..4961.84b3.......f1.f8.fb9cc9..2a5a.7a.0a23.3f...2b2c.343a..6272.7478.....7e85.8e96..9dbd.cdd5.fe.82.fa.a9b6..cc4a...1314.262d..3044.4b4d......5665.7071..adbb6a..83a6..d1.e51b87..da.97.193d5fff.....24b7.c8..76a7.b5c3....cfd221.89f7.a3..f5.1e426000....915b....bcde05.272e..3c48.4e59....6c73.7b7c..8d94.9ba4...bac0.c1c4..c6e4.ebf4...9e36...fc06.1a22..3750.8c98....b9c232.41.c5.0307....0e0f.1151..5e86.afdc...eaee02.2031"},{5860,"...23..01...67475354.0335.12..453613...4411....153756..7425..634664.6632...5522...57.14000277.3334"},{6859,"...0102..0305.0709...0a0b.0c0d....0f130406..080e.1415"},{6893,"......f7..08100607...0bf903..fe11fcff.04....f8fa....090e.22b4..ccd4.ebec...edee.f0f3.1926....e3f50c.0ff205...00.fd0afb0201"},{7337,"....1201.07.665e..104052......080e5a.48.1369.0304..065302...05......090a.0b0c..0d2a.2b2c...2d2e.2f30..3132.3334....3539.3a3b..3c3d.3e3f...5051.5455..5759.5d60.....6162.6364..6568.6b6c...6d6e14.1516...1718.1b1c..1d1e.1f20......2122.2324..2526.2728...295c.676a.4243...4445.4647..494a.4b4c.19...4d4e.4f5f.1a41.0f.37.11..58.38.565b36"},{8434,"..88......20.4044.11.d0...8dd80424..22dc..0d1d.82.dd2d0c.08....48cd842c.18..1c..42c101.28.1002cc00"}},{{name="cubes",o={-0xa.e51e,0xa.5c28,-0xa.8},s={0x12.7ddd,0x20.5c43,0x33.c6d2},vn=240,f3n=0,f4n=180,fstart=1617,fend=9999,pal=11,},{name="cubes2",o={-0xa.e51e,0xa.5c28,-0x4.970a},s={0x12.7ddd,0x20.5c43,0x33.c6d2},vn=240,f3n=0,f4n=180,fstart=1450,fend=9999,pal=11,},{name="room",o={-0xa.961b,-0x25.849f,0xa.3e59},s={0x1b.8683,0x12.3a88,0x18.b349},vn=108,f3n=0,f4n=102,fstart=1245,fend=1617,pal=10,},{name="tonnel5",o={-0x6.ca8c,-0x19.19be,0x12.e447},s={0x3b.bcb6,0xa.ea2d,0x19.c1cc},vn=160,f3n=0,f4n=150,fstart=1080,fend=1347,pal=9,},{name="arch2",o={-0x6.2596,-0x3.1ced,0x2.ae14},s={0x23.6ea9,0x38.50f6,0xc.7459},vn=128,f3n=0,f4n=94,fstart=800,fend=1193,pal=8,},{name="arch1",o={-0x13.ebf3,-0xf.e3b5,0xc.1b5f},s={0xb.3a43,0xf.3a69,0xa.217f},vn=117,f3n=0,f4n=100,fstart=670,fend=941,pal=7,},{name="tonnel4",o={-0x.98dd,-0x9.c8c5,-0x.98dd},s={0x1e.2e01,0x20.a5b6,0xf.2de1},vn=92,f3n=0,f4n=80,fstart=500,fend=723,pal=6,},{name="rotor",o={-0x1.d906,-0x3.7333,-0x1.d906},s={0x3c.ba86,0x2c.590b,0x3c.ba86},vn=100,f3n=0,f4n=88,fstart=315,fend=600,pal=5,},{name="rotorin",o={-0x.8de8,-0x3.7333,-0x.8de8},s={0xe6.0222,0x2c.590b,0xe6.0222},vn=80,f3n=0,f4n=72,fstart=315,fend=600,pal=5,},{name="tonnel3",o={0xe.63d5,-0x.6c5e,0x3.ec8e},s={0x14.f94a,0x27.9d1,0x1a.79f1},vn=144,f3n=0,f4n=108,fstart=215,fend=350,pal=4,},{name="tonnel2",o={-2,-0x1.547c,-0x.0a46},s={0xe.fb9f,0x45.9bd9,0x19.687c},vn=150,f3n=0,f4n=114,fstart=149,fend=276,pal=3,},{name="tonnel1",o={-0x8.466a,-0x5.b945,-0xf.efaa},s={0x17.962b,0x20.6a96,0x10.0056},vn=247,f3n=0,f4n=216,fstart=103,fend=180,pal=2,},{name="tonnel0",o={-0xb.d999,-0x3.4003,-0xd.8},s={0x8.4061,0x8.b5d6,0x3.bc},vn=78,f3n=0,f4n=60,fstart=75,fend=103,pal=2,},{name="O",o={-0x15.792e,-0x5.2d0e,0},s={0x29.0ed,0x16.dda8,0x56.61d2},vn=42,f3n=10,f4n=30,fstart=0,fend=71,pal=1,},{name="X",o={-0xc.e161,-0x5.1957,0},s={0x29.ef6e,0x17.2fa4,0x56.61d2},vn=36,f3n=0,f4n=29,fstart=0,fend=71,pal=1,},{name="E1",o={0x1d.f1ae,-0x5.1476,0},s={0x39.f4d4,0x17.4447,0x56.61d2},vn=36,f3n=0,f4n=28,fstart=0,fend=71,pal=1,},{name="N",o={0x14.6e9c,-0x5.1d34,0},s={0x28.0b7a,0x17.1f62,0x56.61d2},vn=30,f3n=0,f4n=23,fstart=0,fend=71,pal=1,},{name="E",o={0xd.8b48,-0x5.1476,0},s={0x39.f4d4,0x17.4447,0x56.61d2},vn=36,f3n=0,f4n=28,fstart=0,fend=71,pal=1,},{name="G",o={0x4.2d1d,-0x5.2b5f,0},s={0x27.68c3,0x16.e11c,0x56.61d2},vn=63,f3n=11,f4n=46,fstart=0,fend=71,pal=1,},{name="Y",o={-0x4.7e1c,-0x5.1476,0},s={0x28.1624,0x17.39c3,0x56.61d2},vn=47,f3n=1,f4n=40,fstart=0,fend=71,pal=1,},{name="oxygenein",o={-0x2.8726,-0x5.1476,0x.eb1c},s={0x68.dba,0xb6.2492,0x7d.64b5},vn=24,f3n=0,f4n=20,fstart=70,fend=90,pal=1,}},{room={{-1,0x.040b,-0x.8ba4,-0xa.765c,-0x.ec14,0x.4639,0x.45c9,-0x.6b04,-0x.47a,-0x.dd4},{1334,0x.040b,-0x.8ba4,-0xa.765c,-0x.ec14,0x.4639,0x.45c9,-0x.6b04,-0x.47a,-0x.dd4},{1335,0x.7418,-0x.c708,-0xc.5e93,-0x.e325,0x.5f57,0x.45a4,-0x.741f,-0x.430e,-0x.da12},{1344,0x.040b,-0x.8ba4,-0xa.765c,-0x.ec14,0x.4639,0x.45c9,-0x.6b04,-0x.47a,-0x.dd4},{1352,-0x.6a9a,-0x.2872,-0x8.aa9,-0x.f4d7,0x.29f4,0x.3de,-0x.5921,-0x.4fbb,-0x.e259},{1367,-0x1.1a01,-0x.13b8,-0x5.d971,-0x.e936,-0x.60ea,0x.29e5,-0x.0d7e,-0x.683a,-0x.e96e},{1400,0x1.0fec,0x1.c8af,-0x3.e2c8,0x.854c,-0x.d67b,0x.2a03,0x.5c93,-0x.019e,-0x.eeab},{1450,-0x2.d411,-0x.6d4e,-0x3.6193,0x.f4d3,0x.441c,0x.1eee,0x.0efd,0x.5b64,-0x.eea9},{1493,-0x2.4fb3,-0x2.6d6e,-0x2.061b,0x.c9da,0x.96ac,0x.2db3,-0x.08b,0x.5c51,-0x.ee9d},{1538,-0x.160f,-0x2.ea6d,-0x2.83f6,0x.19c8,0x.df04,0x.7b06,-0x.494e,0x.7cea,-0x.d316},{1565,0x2.09b1,-0x1.e7a8,-0x2.7512,-0x.9243,0x.9def,0x.8a9,-0x.913f,0x.2dfa,-0x.cdba},{1585,0x1.db59,-0x.36bb,-0x2.7d42,-0x.8a56,0x.ac34,0x.8165,-0x.89fc,0x.2f3d,-0x.d264},{1615,0x.45fe,0x3.b28e,-0x2.11e7,-0x.2fd5,0x.f2f3,0x.40fc,-0x.43d9,0x.333b,-0x.f178},{1640,0x.2934,0x9.f934,-0x1.d26c,-0x.933f,0x.cd5f,0x.28ef,-0x.2e3a,0x.10ed,-0x.fb38},{1679,0x.c96,0x10.c39e,-0x1.fe7e,-0x.f709,0x.403f,0x.1385,-0x.1ae6,-0x.1a8,-0x.fd33},{1706,0x.021b,0x12.8e23,-0x2.79a2,-0x.ff6f,-0x.07b,0x.0f23,-0x.0df9,-0x.1ca2,-0x.fe02},{1742,-0x3.fddd,0x12.8d4c,-0x3.dc8e,-0x.db57,-0x.8377,0x.0be5,-0x.03cd,-0x.105b,-0x.ff72},{1768,-0x7.4d4b,0x12.cdc9,-0x4.a623,-0x.c33,-0x.a32b,-0x.1c81,0x.2bd4,-0x.082c,-0x.fc16},{1790,-0x8.bc3,0x10.a906,-0x6.1bb8,-0x.caeb,-0x.9b31,-0x.108e,0x.2986,-0x.1b47,-0x.fb21},{1799,-0x8.76d5,0xe.f19d,-0x6.42dc,-0x.ecde,-0x.5c19,-0x.1ec5,0x.2af1,-0x.1a31,-0x.fb02},{-1,-0x8.76d5,0xe.f19d,-0x6.42dc,-0x.ecde,-0x.5c19,-0x.1ec5,0x.2af1,-0x.1a31,-0x.fb02}},arch2={{-1,-0x1.5428,0x.3de8,-0x4.cc0c,-0x.7a1b,-0x.3a2b,0x.d959,-0x.537b,0x.f157,0x.11ed},{800,-0x1.5428,0x.3de8,-0x4.cc0c,-0x.7a1b,-0x.3a2b,0x.d959,-0x.537b,0x.f157,0x.11ed},{808,-0x1.5428,0x.3de8,-0x4.cc0c,-0x.7439,-0x.3868,0x.dd02,-0x.537b,0x.f157,0x.11ed},{825,-0x1.39f2,0x.09a7,-0x4.6cc2,-0x.5917,-0x.3012,0x.eb21,-0x.537b,0x.f157,0x.11ed},{855,-0x1.a7d6,-0x.59a3,-0x2.e5d3,0x.0ec5,-0x.0da2,0x.ff35,-0x.537b,0x.f157,0x.11ed},{900,-0x.fc2c,-0x.e837,-0x.7bc5,0x.51ac,0x.1271,0x.f1eb,-0x.5469,0x.f178,0x.0a16},{925,-0x.dc1e,-0x.5a7e,0x1.14f,0x.370c,0x.09ba,0x.f9d2,-0x.545c,0x.f186,0x.092f},{957,-0x.0be3,0x.05f7,0x3.eade,-0x.2085,0x.0055,0x.fdec,-0x.57a4,0x.f04,-0x.0b8a},{997,-0x.3656,0x.1aab,0x6.c4eb,-0x.706b,0x.0486,0x.e5f3,-0x.44c7,0x.f393,-0x.266b},{1035,-0x2.19b,0x.38e9,0x8.cdb1,-0x.db72,-0x.056,0x.83b8,-0x.2b6a,0x.f477,-0x.3e5a},{1075,-0x4.188a,-0x.2e7,0xb.6596,-0x.8bab,-0x.0073,0x.d68a,-0x.4631,0x.f201,-0x.2d3},{1135,-0x5.2c7,-0x.2f46,0xe.416b,-0x.04dd,0x.08a9,0x.ffce,-0x.540a,0x.f19d,-0x.09c7},{1190,-0x4.7b83,-0x2.2e8f,0x16.c2fc,0x.2f28,-0x.5e4f,0x.e946,-0x.3888,0x.e34c,0x.6753},{1223,-0x4.250d,-0x4.8dc,0x1b.4167,0x.17f,-0x.db12,0x.8245,-0x.336a,0x.7c01,0x.d9fa},{1256,-0x4.1262,-0x9.034e,0x1b.fac2,0x.15f4,-0x.fefb,0x.062,-0x.336a,0x.0199,0x.fac7},{1289,-0x4.6ac6,-0xd.a315,0x19.e058,0x.3672,-0x.f9d6,0x.0c5b,-0x.2223,0x.051b,0x.fda9},{1311,-0x4.c3ef,-0x11.704b,0x17.9ca9,0x.4b64,-0x.ed6a,0x.3b0c,-0x.1d27,0x.34a,0x.f8d4},{1333,-0x5.2143,-0x15.42b,0x15.4d19,0x.603,-0x.d663,0x.6597,-0x.1c44,0x.627d,0x.ea99},{1344,-0x5.5331,-0x17.44eb,0x14.15f6,0x.6a3a,-0x.c737,0x.78ae,-0x.1d6,0x.781e,0x.e026},{1352,-0x5.314,-0x1a.a25b,0x12.30ca,0x.32f6,-0x.b4bf,0x.adfa,-0x.2d89,0x.9a2f,0x.c739},{1367,-0x5.678d,-0x1d.679d,0x11.5c27,-0x.54f4,-0x.941d,0x.bebc,-0x.4a27,0x.c87e,0x.8cd9},{1400,-0x3.f284,-0x1e.1d32,0xe.4c5b,-0x.e2a7,0x.2eb,-0x.6d78,0x.14c8,0x.fbfa,0x.2822},{1450,-0x5.edf7,-0x20.60a4,0x11.a621,0x.2eda,0x.5d9,-0x.e9a3,0x.763d,0x.ce04,0x.5f75},{1493,-0x8.1c22,-0x21.23e,0x10.c49a,0x.81cc,0x.354e,-0x.d61e,0x.78c8,0x.c1d8,0x.73a1},{1538,-0x8.b,-0x1f.8cfd,0xf.2a13,0x.cc4,-0x.6bbb,-0x.6e8,0x.9a33,0x.870e,0x.995a},{1565,-0x7.d701,-0x1e.9673,0xd.311f,0x.95c8,-0x.cc43,0x.251e,0x.5057,0x.633b,0x.dde3},{1585,-0x6.2617,-0x1e.c4e2,0xd.28c6,0x.a479,-0x.c158,0x.212f,0x.51a6,0x.6ad8,0x.d9d6},{1615,-0x2.3781,-0x20.348d,0xd.d60c,0x.ec0f,-0x.60da,-0x.14c,0x.5483,0x.a8f8,0x.acbf},{1640,0x3.f9eb,-0x20.e86,0xd.0d5b,0x.d098,-0x.7c4e,0x.510f,0x.323a,0x.beb7,0x.a337},{1679,0xa.adc5,-0x20.e8be,0xb.c87f,0x.4e4b,-0x.9314,0x.c25a,0x.062,0x.cd42,0x.98dd},{1706,0xc.906c,-0x21.044b,0xc.79b2,0x.0829,-0x.8ea4,0x.d46b,0x.0338,0x.d4af,0x.8e71},{1742,0xd.00ed,-0x21.ddc3,0x10.996b,-0x.7483,-0x.70f,0x.c6,0x.0ed9,0x.da42,0x.84f4},{1768,0xd.937c,-0x22.e54,0x13.cd2f,-0x.90b4,-0x.3fcb,0x.c95,0x.1344,0x.ef17,0x.597},{1790,0xb.ba58,-0x22.3a0e,0x16.04c4,-0x.89b6,-0x.4e88,0x.c901,0x.0064,0x.ee6a,0x.5d3d},{1799,0xa.0721,-0x21.d6db,0x16.11d1,-0x.472c,-0x.57fe,0x.e59f,0x.015a,0x.eef5,0x.5bd5},{-1,0xa.0721,-0x21.d6db,0x16.11d1,-0x.472c,-0x.57fe,0x.e59f,0x.015a,0x.eef5,0x.5bd5}},rotor={{-1,0x.1ffc,0x2.cfde,-0x3.42a9,0x.7c46,0x.259c,0x.dca,-0x.3cd9,0x.f892,-0x.06b5},{315,0x.1ffc,0x2.cfde,-0x3.42a9,0x.7c46,0x.259c,0x.dca,-0x.3cd9,0x.f892,-0x.06b5},{330,0x.4e3,0x1.acb4,-0x2.d39d,0x.592c,0x.3fa7,0x.e75e,-0x.4806,0x.f284,-0x.2726},{350,0,2,-2,0,0,1,-0x.4241,0x.f746,0},{360,0x.3087,0x2.00be,-0x1.acec,-0x.3264,-0x.13a,0x.fa39,-0x.4e87,0x.f39b,0x.04ee},{380,0x.f4cc,0x1.cd36,-0x1.15ea,-0x.6f53,-0x.465c,0x.db86,-0x.7d4c,0x.df19,0x.07e6},{390,0x1.3bb3,0x1.8208,-0x.855b,-0x.8012,-0x.6c39,0x.c172,-0x.98c9,0x.cc75,0x.13b3},{410,0x1.34df,0x.ae0b,0x.37e9,-0x.9cbd,-0x.a8e4,0x.6f8d,-0x.bcad,0x.acef,0x.056d},{420,0x1.0458,0x.24ab,0x.8c8b,-0x.ae35,-0x.b945,0x.1d58,-0x.c31d,0x.a4eb,-0x.105f},{430,0x.7c81,-0x.4b3c,0x.b282,-0x.90ed,-0x.bb9e,-0x.6097,-0x.ac21,0x.ace4,-0x.4d8d},{450,-0x.431,-0x.9707,0x.bca7,0x.05a2,-0x.a5a7,-0x.c319,-0x.3099,0x.d73b,-0x.81cd},{470,-0x.e0c6,-0x1.0ba,0x.b604,0x.312f,-0x.4939,-0x.f052,-0x.21d2,0x.fd28,0x.116c},{490,-0x.f80d,-0x1.a921,-0x.13b8,0x.6d05,-0x.00ca,-0x.e79f,0x.0cd1,0x.dd3,0x.803e},{520,-0x.5f83,-0x2.af5f,-0x1.2d6c,0x.b222,0x.392f,0x.aebd,-0x.3142,0x.f62c,0x.3213},{540,0x.29b9,-0x2.eba5,-0x1.2683,0x.263a,0x.1f73,0x.fb2b,-0x.5014,0x.f279,-0x.122c},{550,0x.5464,-0x3.098e,-0x.eb7,-0x.0a5,0x.1ea8,0x.fdf2,-0x.4f2a,0x.f14b,-0x.2058},{575,0x.b1c7,-0x2.edcf,0x.5081,0x.853d,0x.236,0x.d7b6,-0x.4f37,0x.f344,0x.0908},{593,0x1.8aee,-0x2.e31e,0x1.5a3,0x.b3a1,-0x.039e,0x.b65c,-0x.4a98,0x.e75e,0x.5041},{616,0x4.0b01,-0x3.2898,0x3.b28c,0x.b7ed,-0x.40bb,0x.a5e1,-0x.2467,0x.dbc6,0x.7e21},{641,0x6.8409,-0x4.bc4b,0x6.5c96,0x.59ae,-0x.9afc,0x.b6f4,-0x.0256,0x.c2c2,0x.a621},{667,0x6.cee5,-0x7.3f5,0x9.56e9,-0x.5f31,-0x.8815,0x.c2d2,0x.0263,0x.d14f,0x.935f},{692,0x4.b284,-0x8.c578,0xc.4fa7,-0x.bcd2,-0x.23d2,0x.a91c,0x.36bc,0x.e12a,0x.6ccf},{723,0x.cd5e,-0x8.df56,0xf.491d,-0x.e59d,0x.3741,0x.62cb,0x.62b7,0x.cf15,0x.719c},{753,-0x6.961c,-0x5.de0f,0x13.d067,-0x.deae,-0x.07b,0x.7e0d,0x.497f,0x.c7e5,0x.8e09},{788,-0xd.9758,-0x3.81d4,0x17.8228,-0x.c7bc,-0x.2c2,0x.99ed,0x.5089,0x.b903,0x.9d8a},{802,-0x10.33eb,-0x2.8881,0x18.88a1,-0x.ac45,-0x.5cb3,0x.a51f,0x.4a0a,0x.ac7b,0x.ae14},{826,-0x12.306c,-0x.f814,0x19.8fe6,-0x.7887,-0x.941b,0x.aa81,0x.499a,0x.9cf5,0x.bc5e},{870,-0x12.124e,-0x5.165e,0x1c.f43a,-0x.0572,-0x.c2c7,0x.a608,0x.49cc,0x.9d18,0x.bc2d},{900,-0x11.f638,-0x8.30a6,0x1e.ac9e,0x.195,-0x.c7bd,0x.9e1c,0x.46d,0x.9d69,0x.bd0e},{930,-0x11.432b,-0xc.1968,0x22.1eb5,-0x.1e35,-0x.b41a,0x.b367,0x.48fe,0x.a635,0x.b481},{941,-0x11.8874,-0xd.b5d1,0x23.b98f,-0x.191a,-0x.b595,0x.b2b3,0x.48fe,0x.a635,0x.b481},{942,-0x11.8874,-0xd.b5d1,0x23.b98f,-0x.191a,-0x.b595,0x.b2b3,0x.48fe,0x.a635,0x.b481},{-1,-0x11.8874,-0xd.b5d1,0x23.b98f,-0x.191a,-0x.b595,0x.b2b3,0x.48fe,0x.a635,0x.b481}},tonnel2={{-1,-0x7.724b,-0x4.bf53,-0x5.e09c,0x.c8e9,0x.0278,-0x.9ea2,0x.38c,0x.e9f4,0x.571},{103,-0x7.724b,-0x4.bf53,-0x5.e09c,0x.c8e9,0x.0278,-0x.9ea2,0x.38c,0x.e9f4,0x.571},{107,-0x7.4025,-0x4.63a3,-0x6.fba5,0x.8846,0x.502a,-0x.c957,0x.221,0x.deb,0x.7998},{110,-0x7.349f,-0x4.04d4,-0x7.cd93,0x.81ff,0x.43e2,-0x.d1d3,0x.11f4,0x.ec38,0x.6106},{113,-0x7.3bd,-0x3.7c4,-0x8.c9c3,0x.9719,-0x.1bee,-0x.ccc1,0x.3b4c,0x.f843,0x.139a},{116,-0x7.4b42,-0x2.c074,-0x9.ad34,0x.b129,-0x.5f1,-0x.9e78,0x.48df,0x.f03d,-0x.3219},{119,-0x7.323d,-0x2.4324,-0xb.4af4,0x.d832,-0x.5c9c,-0x.6514,0x.4325,0x.f062,-0x.38f3},{122,-0x6.e329,-0x2.01c3,-0xd.03a7,0x.faf3,-0x.28bf,-0x.1dfc,0x.1d09,0x.fc27,-0x.2152},{125,-0x6.453,-0x1.a581,-0xe.0a8d,0x.ffe8,-0x.05ba,0x.03c4,-0x.0192,0x.fd81,-0x.239f},{128,-0x5.93fd,-0x1.a196,-0xe.bfa1,0x.f18e,0x.227,0x.4d74,-0x.1bc1,0x.f984,-0x.3211},{131,-0x4.2f3e,-0x2.31b6,-0xe.99ff,0x.c5f2,0x.5962,0x.8782,-0x.57f2,0x.ecaa,-0x.2a5},{134,-0x3.65e,-0x2.48d5,-0xe.be8,0x.90d9,0x.665b,0x.b89a,-0x.5ff9,0x.e4f8,-0x.3e6c},{137,-0x2.9cc6,-0x2.5e74,-0xe.a174,0x.749e,0x.5f8,0x.ceeb,-0x.507f,0x.e846,-0x.4771},{140,-0x1.daa6,-0x2.472a,-0xe.20e6,0x.7b9b,0x.383,0x.d906,-0x.2d8,0x.f77,-0x.2f4f},{143,-0x1.3a76,-0x2.30cb,-0xd.7fc,0x.756,0x.15e3,0x.e273,-0x.0402,0x.fe0d,-0x.1f42},{146,-0x.6c1a,-0x2.225b,-0xc.d66d,0x.20a1,0x.0c7,0x.fd9b,0x.19b7,0x.fd9c,-0x.1796},{149,0x.2f17,-0x2.0e1a,-0xb.d284,-0x.3d63,0x.175e,0x.f76e,0x.2998,0x.fbae,-0x.157c},{152,0x.ab34,-0x1.e0ec,-0xa.26c,-0x.85f3,0x.1a62,0x.d88e,0x.2456,0x.fccd,-0x.1181},{155,0x.eabe,-0x1.ab,-0x8.b533,-0x.a6,0x.1e3d,0x.c086,0x.2c04,0x.fbe7,-0x.0bf1},{158,0x.e45e,-0x1.6f72,-0x7.5205,-0x.aacf,0x.21cc,0x.bba9,0x.3364,0x.faa,-0x.08f6},{161,0x.ac05,-0x1.2c01,-0x6.17ef,-0x.9e9a,0x.1e44,0x.c6a8,0x.327e,0x.fad8,-0x.07ed},{164,0x.9a0c,-0x.dbea,-0x4.e502,-0x.943b,0x.15a2,0x.cf97,0x.2e95,0x.fbb6,-0x.028e},{167,0x.50c,-0x.a1bb,-0x3.a01c,-0x.7914,0x.10c8,0x.e0ee,0x.2e95,0x.fbb6,-0x.028e},{170,0x.1ee5,-0x.7a03,-0x2.9201,-0x.5654,0x.0c54,0x.f0b,0x.2f3,0x.fb93,-0x.043b},{173,0x.1919,-0x.45be,-0x1.7189,-0x.3215,0x.028c,0x.fb0a,0x.2e54,0x.fbc5,-0x.013d},{177,0x.5844,-0x.6113,-0x.08b2,-0x.007,-0x.029a,0x.fffc,0x.2c74,0x.fc18,0x.02a3},{187,0x1.363d,-0x.2972,0x4.354c,0x.86f8,0x.0084,0x.d987,0x.33a6,0x.fabc,-0x.005b},{196,0x3.fd4a,-0x.62dd,0x7.4697,0x.372a,0x.56ec,0x.ea63,0x.0cf3,0x.f14a,-0x.5489},{202,0x6.49ce,-0x.1805,0x8.18ef,0x.4aca,0x.38c9,0x.ee27,0x.1987,0x.f933,-0x.34c1},{205,0x7.3fe1,0x.2a77,0x8.2d81,0x.6974,0x.0311,0x.e94,0x.29cf,0x.fc8e,-0x.01c},{211,0x9.0d01,0x.1ea5,0x8.5858,0x.85b6,0x.0923,0x.da1c,0x.29f7,0x.fc88,-0x.0125},{217,0xa.0834,0x.2ad5,0x8.0538,0x.875a,0x.0afd,0x.d903,0x.2a2c,0x.fc7e,-0x.01ff},{230,0xa.d515,0x.1694,0x7.9754,0x.a878,0x.06cd,0x.c0a1,0x.47f7,0x.f3dd,-0x.1dc3},{238,0xa.7e1,0x.6f2a,0x7.1898,0x.d244,-0x.0759,0x.91d7,0x.4c4d,0x.f09b,-0x.2aaf},{248,0xa.80ce,0x1.6411,0x6.4489,0x.ce4f,-0x.4522,0x.86e,0x.7bcd,0x.df9,-0x.0f18},{258,0xa.cf54,0x1.ab26,0x6.307c,0x.da8a,-0x.639f,0x.589a,0x.8bcc,0x.d60b,-0x.0d49},{265,0xc.2275,0x1.0789,0x6.5753,0x.fb7c,-0x.29ce,0x.174a,0x.4ba6,0x.f1b,-0x.2564},{272,0xd.bf7c,0x.523d,0x6.090e,0x.f77f,0x.3f4e,0x.1082,-0x.1c37,0x.fa07,-0x.2f2e},{287,0x11.5385,0x.b52a,0x6.6933,0x.e21d,0x.6752,0x.3d17,-0x.42e6,0x.f489,-0x.2387},{305,0x15.17b5,0x1.d6c,0x7.78dd,0x.b1bc,0x.88f8,0x.7b3a,-0x.6db8,0x.e506,-0x.2051},{325,0x17.5e78,0x3.9998,0x9.8297,0x.9355,0x.5627,0x.bece,-0x.695,0x.e8b5,0x.111},{340,0x18.6df2,0x4.b621,0xb.5dcd,0x.6d8f,-0x.0c18,0x.e70d,-0x.506b,0x.e43b,0x.538a},{350,0x18.f348,0x4.d239,0xc.726b,0x.52b3,-0x.193,0x.f0f6,-0x.5574,0x.e1d7,0x.5505},{-1,0x18.f348,0x4.d239,0xc.726b,0x.52b3,-0x.193,0x.f0f6,-0x.5574,0x.e1d7,0x.5505}},tonnel0={{-1,0x14.9285,0xd.cf45,-0x69.0d9f,-0x.3548,-0x.257b,0x.f792,-0x.2fe9,0x.f9f6,0x.1b8a},{75,0x14.9285,0xd.cf45,-0x69.0d9f,-0x.3548,-0x.257b,0x.f792,-0x.2fe9,0x.f9f6,0x.1b8a},{80,0xf.85b8,0xb.f12a,-0x5c.faf3,-0x.3548,-0x.257b,0x.f792,-0x.2fe9,0x.f9f6,0x.1b8a},{85,0x8.dd91,0x8.ff67,-0x3f.2f6,-0x.4093,-0x.2861,0x.f468,-0x.3009,0x.f9d2,0x.1c96},{86,0x7.08b8,0x8.2dad,-0x36.1533,-0x.4239,-0x.28b4,0x.f3e9,-0x.3015,0x.f9ce,0x.1ca2},{87,0x5.aa38,0x5.c187,-0x26.d09c,-0x.49da,-0x.2848,0x.f1c8,-0x.30f6,0x.f9da,0x.1aac},{88,0x4.46ae,0x2.c616,-0x18.df6e,-0x.4f81,-0x.2181,0x.f105,-0x.312e,0x.fa8a,0x.129a},{89,0x3.990d,0x1.7bae,-0xf.dc44,-0x.55d9,-0x.20d4,0x.eeee,-0x.31dd,0x.fa8d,0x.1082},{92,0x2.b0df,0x1.2a34,-0x8.5d12,-0x.5357,-0x.1e51,0x.f025,-0x.31b,0x.fab7,0x.0e68},{94,0x1.4998,0x1.4b88,0x.37ab,-0x.444,-0x.1b88,0x.f531,-0x.317f,0x.fac1,0x.0e61},{96,-0x.4d1d,0x1.9e22,0x9.2659,-0x.3f2b,-0x.282f,0x.f4ce,-0x.3c73,0x.f76c,0x.19be},{98,-0x1.2d6b,0x1.abc7,0x13.6c4,-0x.3b0b,-0x.2d46,0x.f4f2,-0x.3f4d,0x.f632,0x.1e3f},{102,0x.8677,0x2.59e8,0x1e.62bf,-0x.30dc,-0x.27ac,0x.f824,-0x.480d,0x.f463,0x.18dd},{106,0x6.c341,0x3.7cf3,0x2a.36e3,0x.5201,0x.10ec,0x.f1ea,-0x.35bf,0x.fa4a,0x.00a4},{108,0xa.af2,0x3.f434,0x30.9e28,0x.61e6,0x.145a,0x.eba9,-0x.35bf,0x.fa4a,0x.00a4},{111,0x11.476d,0x5.b107,0x3a.7481,0x.605,-0x.0b1c,0x.ecee,-0x.2a2f,0x.fad8,0x.1cd9},{115,0x1a.fead,0xa.9e5e,0x46.3779,0x.3e32,-0x.631f,0x.e3b,-0x.2e4d,0x.e2,0x.6ef9},{119,0x22.9187,0xc.ce89,0x4f.0063,0x.0b9f,-0x.7558,0x.e339,-0x.360e,0x.dd23,0x.7519},{177,0x22.9187,0xc.ce89,0x4f.0063,0x.0b9f,-0x.7558,0x.e339,-0x.360e,0x.dd23,0x.7519},{-1,0x22.9187,0xc.ce89,0x4f.0063,0x.0b9f,-0x.7558,0x.e339,-0x.360e,0x.dd23,0x.7519}},oxygene={{-1,-0x3.05bb,-0x8.bd31,-0x14.080f,0x.2894,0x.5ab4,0x.ebed,-0x.0665,0x.ef3d,-0x.5ae},{0,-0x3.05bb,-0x8.bd31,-0x14.080f,0x.2894,0x.5ab4,0x.ebed,-0x.0665,0x.ef3d,-0x.5ae},{25,-0x2.9595,-0x7.55e,-0x8.a562,0x.05f8,0x.a06,0x.c773,-0x.050f,0x.c781,-0x.a056},{50,-0x1.929c,-0x6.4802,-0x1.3079,-0x.0f66,0x.c9e5,0x.9ca3,0x.08e2,0x.9d4,-0x.c9d},{70,-0x1.3ec5,-0x5.c431,0x1.9a9f,-0x.0f02,0x.fda4,0x.1f3e,0x.1911,0x.20ca,-0x.fca6},{85,-0x1.4f16,-0x4.6972,0x1.f107,-0x.4965,0x.f256,-0x.25b2,0x.2582,-0x.1be8,-0x.fbb1},{88,-0x1.4684,-0x3.eaac,0x1.ec1c,-0x.6bde,0x.e0ff,-0x.393c,0x.2b88,-0x.2a82,-0x.f8aa},{89,-0x1.4eae,-0x3.c2d6,0x1.eb8b,-0x.15bd,0x.fe37,-0x.14ee,0x.3dce,-0x.0f3d,-0x.f7f5},{90,-0x.5368,-0x.a063,0x.7adf,-0x.3c1f,0x.f74b,-0x.1bac,0x.1c8e,-0x.1575,-0x.fd7e},{-1,-0x.5368,-0x.a063,0x.7adf,-0x.3c1f,0x.f74b,-0x.1bac,0x.1c8e,-0x.1575,-0x.fd7e}},},10187,48,10235,1020


function hnode(etree,pos)
	local char,l,r= sub(etree,pos,pos)
	if char=="." then
		l,pos=hnode(etree,pos+1)
		r,pos=hnode(etree,pos)
		return {l=l,r=r},pos
	else
		return tonum("0x"..sub(etree,pos,pos+1)),pos+2
	end
end

function huffman(arc)
	local tree,addr,mask=hnode(arc[2],1),arc[1],128
	return function()
		local node=tree
		while true do
			node=(peek(addr)&mask==0) and node.l or node.r
			mask/=2
			if mask<1 then
				mask=128
				addr+=1
			end
			if type(node)=="number" then
				return node
			end
		end
	end
end


function load_data()
	local avertices,acolors,atris,aquads,afp,nobjects=huffman(arcs[1]),huffman(arcs[2]),huffman(arcs[3]),huffman(arcs[4]),huffman(arcs[5]),{}
	for i=1,#objects do
		local obj=objects[i]
		nobjects[obj.name]=obj

		if obj.name=="E" then
			obj.v,obj.f=nobjects["E1"].v,nobjects["E1"].f
			for c=1,#obj.v do
				for d=1,3 do
					obj.v[c][d]+=obj.o[d]-nobjects["E1"].o[d]
				end
			end
		else
			obj.v,obj.f={},{}
			local col_add=(obj.pal%2==0) and 0x1088.5a5a or 0x1000.5a5a

			for c = 1,obj.vn do
				local v={}
				for d=1,3 do
					add(v,avertices()/obj.s[d]+obj.o[d])
				end
				add(obj.v,v)
			end

			for c=1,obj.f3n do
				add(obj.f,{acolors()+col_add,atris(),atris(),atris()})
			end

			local v=0
			for c=1,obj.f4n do
				local color,p = acolors()+col_add,fp[afp()]
				v=(v+aquads())&0xff
				add(obj.f,{color,v,v+p[1],v+p[2]})
				add(obj.f,{color,v+p[2],v+p[3],v})
			end
		end
	end
	objects=nobjects

	memcpy(0x4300,arcs[6][1],1753)
	arcs[6][1]=0x4300
	local a=huffman(arcs[6])
	for i=0,8191 do
		poke(i,a())
	end
end


function fx_fade(c1,c2,dots)
if (c1~=-1) cls(c1)
return function()
  wait_sync()
end,
function()
end,
function()
  for c=1,dots do
    pset(rnd(128),rnd(128),c2)
  end
end,
-1

end


function fx_intro()

	local dots,fr,fl={},0,false
	pal({129,130,1,131,141,140,12},1)

return function()
	wait_frames(4)
	add_text(dots,"this is",22,11,fr)
	wait_frames(100)
	add_text(dots,"not your",16,32,fr)
	wait_frames(100)
	add_text(dots,"regular",22,53,fr)
	wait_frames(100)
	add_text(dots,"stniccc",22,74,fr)
	wait_frames(100)
	add_text(dots,"clone",34,95,fr)
	wait_sync()
	fl=true
	wait_sync()
end,

function ()
	fr+=1
end,

function ()
	if fl then
		cls(15)
		fl=false
	end
	for c=1,#dots do
		local t=max(0,(dots[c][3]-fr)/3)
		local x,y,col=dots[c][1]+t*sin(t/17)+rnd(t/3),dots[c][2]+t*cos(t/20)+rnd(t/2),7-(t/10)
		rectfill(x,y,x+1,y+1,(col<1) and 1 or flr(col))
	end
end,
1
end


function fx_landscape()
	pal({129,1,133,5,134,6,7},1)
	local a1,a2,a3,t1,t2,t3,land,my=20,37,43,300,353,221,{},{}

	for c=1,32 do
		add(land,{})
		for d=1,32 do
			add(land[c],0)
		end
	end
	for c=1,128 do
		add(my,0)
	end

return function()
	while loop_sync() do
		if (frame%95==0) a1,a2,a3,t1,t2,t3=rnd(40)+10,rnd(30)+10,rnd(20)+5,rnd(200)+100,rnd(200)+100,rnd(200)+100
	end
end,

function()
	for c=1,32 do
		for d=1,32 do
			land[c][d]=sin(c/a1+sin(frame/t1))+cos(d/a2+sin(frame/t2))+sin(d/a3+cos(frame/t3))*0.7
		end
	end
end,

function()
	if (frame%95==0) cls(4)
	if (frame%95==1) cls(3)
	for c=1,128 do
		my[c]=128
	end
	for c=32,1,-1 do
		for d=1,32 do
			local x,y=c*4-d*3+32,d*2+c/2+32-land[c][d]*20
			if x>=0 and x<128 then
				if my[x+1]>y then
					pset(x,y,min(7,flr((c+d)/6)))
					my[x+1]=y
				end
			end
		end
	end
end

end


function fx_ball()
	pal()
	local gpal,sn,gmode,balls,at={1,5,6,15,10},15,2,{{o={0,0,0},a={1.6,0.91,0.4},g={}},{o={0,0,0},a={0.94,0.33,0.43},g={}}},0

	local function pj(u,v,r,o)
		local y,r,s=cos(v/sn/2)+o[2],u/sn+r,sin(v/sn/2)
		local x,z=cos(r)*s+o[1],sin(r)*s+o[3]
		return 250*x/z+64,250*y/z-32,z
	end

	local function ag(g)
		local gg,u,v,u1,v1={},flr(rnd(sn)),flr(rnd(sn))
		for c=1,8 do
			u1,v1=u+flr(rnd(2)-1),v+flr(rnd(2)-1)
			add(gg,{u,v,u1,v1,6.9-c/1.5})
			u,v=u1,v1
		end
		add(g,gg)
	end

	for c=1,#balls do
		for d=1,12 do
			ag(balls[c].g)
		end
	end

return function()
	while loop_sync() do
		if (frame%48==24) at+=0.2
		if (frame%95==0) gmode = 2
		if (frame%95==72) gmode = 1
	end
end,

function()
	for c=1,#balls do
		local t=time()/2+c/2.7+at
		local b=balls[c]
		b.o={sin(t*b.a[1]),cos(t*b.a[2])+3,10+3*sin(t*b.a[3])}
		for g in all(b.g) do
			if rnd()<0.4 then
				for d=#g,2,-1 do
					g[d][4],g[d][3],g[d][2],g[d][1]=g[d-1][4],g[d-1][3],g[d-1][2],g[d-1][1]
				end
				g[1][1],g[1][2],g[1][3],g[1][4]=g[1][1]+flr(rnd(2)-1),g[1][2]+flr(rnd(2)-1),g[1][1],g[1][2]
			end
		end
	end
end,

function()
	cls((gmode==1) and rnd({0,1,5}) or 0)
	local r=time()/3
	for c = 1, #balls do
		local b=balls[c]

		for d=1,#b.g do
			for e=1,#b.g[d] do
				local g=b.g[d][e]
				local x1,y1,z=pj(g[1],g[2],r,b.o)
				local x2,y2=pj(g[3],g[4],r,b.o)
				line(x1+rnd(2),y1-rnd(),x2-rnd(2),y2+rnd(),gpal[(z<b.o[3]) and (flr(g[5])+gmode-3) or 1])
			end
		end

		for v=1,sn-1 do
			for u=1,sn do
				local x,y,z = pj(u,v,r,b.o)
				if (z<b.o[3]) circfill(x, y, 1, c)
				pset(x,y,c+((gmode==1 or z>b.o[3]) and 0 or 11))
			end
		end
	end

	if gmode==1 then
		for c=1,frame%24 do
			local y=flr(rnd(128))
			memcpy(0x6000+y*64,y*64,64)
		end
	end
end,
-1

end


function fx_logo()
  local nl,gl,gli,gll,fi,fpal=0,0,1,{1,48,96,108,114},1,{7,6,134,5,133,1,128,0}
return function()
  while loop_frames(30) do
    nl+=2
  end
  wait_sync()
  while loop_sync() do
    if frame==gll[gli] then
      gl=10
      gli+=1
    end
  end
end,
function ()
  fi,gl=min(fi+0.5,#fpal),max(gl-1,0)
end,
function ()
  pal(0,fpal[flr(fi)],1)
  cls(0)
  for y = 64-nl,62+nl do
    memcpy(0x6000+y*64+flr(rnd(gl)-gl/2),y*64,64)
  end
end,
-1
end


function fx_niccc()

nframe,dframe,triangle=0,0,eg_triangle
pal(0,0,1)
pal(8,0,1)
local cg,lp=0,true

return function()
	local omt=ptn
	while loop_sync() do
		nframe+=0.4
		if (ptn~=omt and ptn%2==0) cg=8
		omt=ptn
	end
	lp,cg=false,8
	wait_sync()
end,

function()
	if (lp) cg=max(cg-0.3,0)
	dframe+=1
end,
function()
	if (lp) cls(0)
	camera(flr(rnd(cg)-cg/2),0)
	if (lp) draw3d()
	if (cg>0) then
		local n=rnd(30)+10
		for c=1,n do
			local y=flr(rnd(119))+1
			memcpy(0x6000+y*64+flr(rnd(cg)-cg/2),0x6000+y*64,128*flr(rnd(4)+1))
		end
	end
end,
-1
end

function draw3d(usepals)
	local oldcam
	for c=1,#renderlist,2 do
		local model=objects[renderlist[c]]
		if model.fstart<=nframe and model.fend>nframe then
			cam = campath[renderlist[c + 1]]

			if usepals~=false then
				local pn=model.pal
				local padd=(pn&1==1) and 0 or 8
				for i=1,#colors[pn] do
					pal(i+padd,colors[pn][i],1)
				end
			end

			if oldcam~=cam then
				for d=1,#cam do
					if cam[d][1]~=-1 and nframe>=cam[d][1] then
						cam_idx=d
					end
				end

				local cframe=cam[cam_idx][1]
				local t=(nframe-cframe)/(cam[cam_idx+1][1]-cframe)
				eye,dir,up=spline(2,t),normalize(spline(5,t)),normalize(spline(8,t))
			end
			oldcam=cam

			local srt=modelsort[renderlist[c]]
			if renderlist[c]=="rotorin" then
				m3d(model,eye,dir,up,srt[1],srt[2],srt[3],-dframe/150)
			else
				m3d(model,eye,dir,up,srt[1],srt[2],srt[3])
			end
		end
	end
end

function spline_kmr(v0,v1,v2,v3,p)
	return (p*p*p*(3*v1-3*v2+v3-v0)+p*p*(2*v0-5*v1+4*v2-v3)+p*(v2-v0)+2*v1)*0.5
end

function spline(i,p)
	local d0,d1,d2,d3,i1,i2=cam[cam_idx-1],cam[cam_idx],cam[cam_idx+1],cam[cam_idx+2],i+1,i+2
	return {spline_kmr(d0[i],d1[i],d2[i],d3[i],p),spline_kmr(d0[i1],d1[i1],d2[i1],d3[i1],p),spline_kmr(d0[i2],d1[i2],d2[i2],d3[i2],p)}
end

modelsort = {
	oxygenein={max,1,0x.1},
	O={min,1,0x.02},
	X={max,1,0x.02},
	Y={min,1,0x.01},
	G={min,1,0x.04},
	E={min,2,0x.04},
	N={min,2,0x.04},
	E1={min,1,0x.02},
	cubes={max,2,0x.1},
	cubes2={max,2,0x.1},
	room={max,2,0x.08},
	tonnel5={max,1,0x.8},
	arch2={max,2,0x.2},
	arch1={max,2,0x.4},
	tonnel4={max,1,0x.8},
	rotor={max,0x.8,0x.04},
	rotorin={max,0x.8,0x.01},
	tonnel3={max,2,0x.4},
	tonnel2={max,1,0x.04},
	tonnel1={max,4,0x.01},
	tonnel0={max,4,0x.01}
}


greetz = "|greetz|||lexaloffle|oxygene|ate bit|hprg|mATTcURRENT|mayhem|fairlight|nuance|caroline|proxima|gasman|5711|razor1911|the sands|nedopc|offence|jumalauta|excess team|agenda|inversion|AND|ALL|dIhALT|visitors"

function fx_ending()
camera()
poke4(0x5f40,0)
memcpy(0x3100,emus,emusl)
memcpy(0x3420,esfx,esfxl)
music(0)
local fade,gr,dots,gframe,gp,gidx,ff={0,128,129,130,133,141,141,141,133,130,129,128},split(greetz,"|",false),{},300,1,1,0
nframe,dframe,triangle=225,0,striangle
pal({1,11,7,0x81,5,6,7},1)

return function()
	while gidx<#gr do
		wait_frames(240)
	end
	wait_frames(300)
	music(-1,8000)
	wait_frames(400)
	while loop_sync() do
		if (ff%240==0) break
	end
	cls()
	stop()
end,

function()
	ff+=1
	if (ff%240==0) nframe=rnd({0,225,350,420,570,690,750,1000,1200})
	gframe+=1
	dframe-=0.5
	nframe+=0.08
	if gframe >= 200 then
		gframe = 0
		if gp == 1 then
			gp,dots=0,{}
			local y=12
			if gidx<#gr then
				for c=gidx,min(gidx+3,#gr) do
					add_text(dots,gr[c],(132-#gr[c]*12)/2,y,0)
					y+=24
				end
				gidx+=4
			end
		else
			gp=1
		end
	end
end,

function()
	pal(1,fade[flr(ff%240/240*#fade)+1],1)
	draw3d(false)

	local dx={}
	for c=1,#dots do
		local x,y=dots[c][1],dots[c][2]
		if dx[y]==nil then
			local t=max(0,gframe-y)
			dx[y]=(gp==0) and (128-sease_elastic(t/100,128)) or sease_cubic(t/100,-160)
		end
		x+=dx[y]
		if x<128 and x>-3 then
			rectfill(x,y,x+2,y+2,3)
		end
	end

	camera(0,-16)
	oprint("CODE",6,96,2)
	oprint("mEGUS",4,104,3)
	oprint("3D",33,96,2)
	oprint("MODELS",43,96,2)
	oprint("tMk",44,104,3)
	oprint("MUSIC",76,96,2)
	oprint("N1K-O",76,104,3)
	oprint("GFX",108,96,2)
	oprint("dIVER",104,104,3)

	--oprint("cpu: " ..stat(1), 0, -16, 3)
	--oprint(nframe, 64,-16,3)
	camera()
end
end


scenario,mfx_scenario={
	fx_intro,4,0x4.01,
	function() return fx_fade(-1,0,600) end,5,
	fx_landscape,8,
	fx_ball,12,
	fx_logo,13,0x0d.150,
	function() return fx_fade(-1,0,1000) end,14,
	fx_niccc,38,0x26.0c0,
	fx_ending,32767,
},
{
	-- 0x0F0D.0R0H
	0,0x0.08,
	4,0,
	26,0x2,
	30,0x2.08,
	34,0,
	38,0x0f.0f0f,
	39,0,
	51,0x0.08,
	32767
}



