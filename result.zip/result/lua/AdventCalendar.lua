--2019 pico8 advent calendar
cartdata("pico8advent2019")

--hammer, but it's carts so..

poke(0x5f2d, 1) -- enable devkit input mode
function updatemouse()

 if band(stat(34),1)==1 then
	 ctrl=2
	end
	if ctrl==2 then
	 mousex,mousey=stat(32),stat(33)
	else
		if btn(⬆️) then
			mousey-=1
		elseif btn(⬇️) then
			mousey+=1
		end
		
		if btn(⬅️) then
			mousex-=1
		elseif btn(➡️) then
			mousex+=1
		end
	end
 olmb=lmb
 ormb=rmb
 lmb=band(stat(34),1)==1 or btn(🅾️)
 rmb=band(stat(34),2)==2
 if not olmb and lmb then
  lclick=true
 else
  lclick=false
 end
 if not ormb and rmb then
  rclick=true
 else
  rclick=false
 end
end

function _init()
	
	fluff={s=160
	      ,es=200
	      ,x=24
	      ,y=63
	      ,a=0}
	tokens={}
	pats = {[0]=0b0110110010010011,
	         0b1100100100110110,
	         0b1001001101101100,
	         0b0011011011001001}
	ptimer=0
	poff=0
	selspacer=.05
	rc=0
	mousex,mousey=64,64
	ctrl=1
	
	descs={'cart: ufo santa candy blaster\ndev: thetomster\n"it\'s unidentified!\nit\'s flying!\nit\'s santa!\n..how can it be both santa\nand unidentified, you ask?!\n --stop asking questions\nand just break candies!"'
	,'cart: snow\ndev: freds72	\n"blow your mind with next gen\npolygonal graphics! but don\'t\nbust your skull on hazards!\n(fyi there are --zero-- yeti\nhiding in this game. (zero!!)\n so don\'t search for him.)"'
	,'cart: xmas in the coral caves\ndev: kittenm4ster	\n"your mission, should you\nchoose to accept it, is to \nfulfill your destiny as the\nsanta of the seas.\n"why," you ask?\nwhat.. does something about\nthat seem fishy to you?"'
	,'cart: snowfight\ndev: mboffin\n"remember snowcraft? the old\nshockwave flash snowball\nfight game from 1998?\nit\'s old enough to drink now!\nso raise your glass to this\ndemake and have fun blasting\nyour enemies with snowballs!"'
	,'cart: polar panic\ndev: megapeitz\n"cross the ice flows while\nfilling your tummy with\nyummy fishes!\njust look out for\ngarbage and other waste!\nhuh.. now who put\nall that stuff there..? :/"'
	,'cart: creed fighter\ndev: nextlevelbanana\n"grab a friend (or foe!)\nand throw down, st nick style!\nas the wise ones say..\n"may he who is without sin,\n break the first bone!"\n [cue metal guitar solo]"'
	,'cart: seasons greetings\ndev: nextlevelbanana\n"shhh.. just take a moment\nto relax and enjoy\nthis nice holiday card.\nbased on a wholly generic and\nnon-infringing holiday scene.\n\n(please don\'t sue us! :/ )"'
	
 
	}
	
		carts = {"#ufo_santa","#freds72_snow","#xmasfish","#mb_advent2019","#polarpanic","#creedfighter","#snoopytime"}

		
 _update60=update60
 _draw=draw
	
	
	w,h=16,16
	
	tags = {}
	local t1=maketag(43,42,42,4)
	t1.id=1
	if peek(0x5e00)==1 then
		t1.w1=-19
		t1.xo=128
		t1.yo=128
		add(tokens,1)
	end
	add(tags,t1)
	
	local t2=maketag(12,90,42,14,12)
	t2.id=2
	if peek(0x5e01)==1 then
		t2.w1=-19
		t2.xo=128
		t2.yo=128
		add(tokens,2)
	end
	add(tags,t2)
	
	local t3=maketag(100,19,42,36,12)
	t3.id=3
	if peek(0x5e02)==1 then
		t3.w1=-19
		t3.xo=128
		t3.yo=128
		add(tokens,3)
	end
	add(tags,t3)
	local t4=maketag(4,28,42,8,12)
	t4.id=4
	if peek(0x5e03)==1 then
		t4.w1=-19
		t4.xo=128
		t4.yo=128
		add(tokens,4)
	end
	add(tags,t4)
	local t5=maketag(92,49,42,64,12)
	t5.id=5
	if peek(0x5e04)==1 then
		t5.w1=-19
		t5.xo=128
		t5.yo=128
		add(tokens,5)
	end
	add(tags,t5)

	local t6=maketag(60,91,42,44,12)
	t6.id=6
	if peek(0x5e05)==1 then
		t6.w1=-19
		t6.xo=128
		t6.yo=128
		add(tokens,6)
	end
	add(tags,t6)
	
	local t7=maketag(11,64,42,70,12)
	t7.id=7
	if peek(0x5e06)==1 then
		t7.w1=-19
		t7.xo=128
		t7.yo=128
		add(tokens,7)
	end
	add(tags,t7)
	
	if stat(80)>=2019 then
		if stat(82)>=8 then
			//add(descs,'cart: winter words \ndev: enargy\n"chill out with a little\nwinter-themed word search.\nsip some cocoa and\nsee if you can find\nthem all!"')
			add(descs,'cart: dance santa revolution \ndev: matthias\n"this year santa is in an\nincredible mood for dancing..\nenjoy a small christmas\ndoodle!"')
			
			local t8=maketag(76,11,42,68,12)
			t8.id=8
			if peek(0x5e07)==1 then
				t8.w1=-19
				t8.xo=128
				t8.yo=128
				add(tokens,8)
			end
			add(tags,t8)
			
			add(carts,"#dancesantarevolution")

		end
	if peek(0x5efe)==3 then
		stuffedstocking=true
	end
	end
				add(descs,'cart: starswing \ndev: tom brinton\n"engage in a timeless\ntale of swinging amongst\nthe stars.\nsee how many you can\nget in a row!"')
			
			local t9=maketag(26,8,42,76,12)
			t9.id=9
			if peek(0x5e08)==1 then
				t9.w1=-19
				t9.xo=128
				t9.yo=128
				add(tokens,9)
			end
			add(tags,t9)
			
			add(carts,"#starswing")

add(descs,'cart: snow plower \ndev: jwinslow23\n"a scathing critique of our\nmodern society?!\nsurely this is a first in\nthe indie game community...\nbetter plow that snow! just\nmake sure to be efficient or\nyou may get sacked!"')
			
			local t10=maketag(12,62,42,130,12)
			t10.id=10
			if peek(0x5e09)==1 then
				t10.w1=-19
				t10.xo=128
				t10.yo=128
				add(tokens,10)
			end
			t10.page=2
			add(tags,t10)
			
			add(carts,"#snowplower")

add(descs,'cart: deer santa... \ndev: megapeitz\n"a milk-sleepy santa left you\nin charge and now storm clouds\nhave come to rain on\nyour dawn trip home! well rein\nin your fears and get everyone\nhome safely! \'cause this..?\nthis.. is your reign, deer!"')
local t11=maketag(104,36,42,78,12)
			t11.id=11
			if peek(0x5e0a)==1 then
				t11.w1=-19
				t11.xo=128
				t11.yo=128
				add(tokens,11)
			end
			t11.page=2
			add(tags,t11)
			
			add(carts,"#deersanta")
add(descs,'cart: winter words \ndev: enargy\n"chill out with a little\nwinter-themed word search.\nsip some cocoa and\nsee if you can find\nthem all!\ndislaimer:do not use this\ncart to summon the krampus!"')
local t12=maketag(24,32,42,74,12)
			t12.id=12
			if peek(0x5e0b)==1 then
				t12.w1=-19
				t12.xo=128
				t12.yo=128
				add(tokens,12)
			end
			t12.page=2
			add(tags,t12)
			
			add(carts,"#winterwords")
--13--
add(descs,'cart: toboggoban \ndev: 2darray\n"a sokoban-variant featuring\nwintery vibes and sliding\ntoboggans.\nincludes a time rewind\nfunction, just like you\nremember from the days of your\nyouth! !yvoorg ,haey ho"')
local t13=maketag(8,2,42,6,12)
			t13.id=13
			if peek(0x5e0c)==1 then
				t13.w1=-19
				t13.xo=128
				t13.yo=128
				add(tokens,13)
			end
			t13.page=2
			add(tags,t13)
			
			add(carts,"#toboggoban")
add(descs,'cart: wrap\'a\'gift \ndev: eiyeron\n"things are running late\nat the north pole this year!\ndon\'t those lazy elves know\nthat the owe us presents?!\nget in a groove and show\nthose lil\' pointy-eared\nslackers how it\'s done!"')
local t14=maketag(106,4,42,96,12)
			t14.id=14
			if peek(0x5e0d)==1 then
				t14.w1=-19
				t14.xo=128
				t14.yo=128
				add(tokens,14)
			end
			t14.page=2
			add(tags,t14)
			
			add(carts,"#mowenuraga")
add(descs,'cart: katamari christmassy \ndev: p01 & gasmanic\n"this demake brings us to\ntears!\n128x128 pixels..?\nwe could make it larger\nbut... the groovy gameplay!!\n..this is enough to earn a\nplace among.. the stars! ♥★"')
local t15=maketag(52,4,42,108,12)
			t15.id=15
			if peek(0x5e0e)==1 then
				t15.w1=-19
				t15.xo=128
				t15.yo=128
				add(tokens,15)
			end
			t15.page=2
			add(tags,t15)
			
			add(carts,"#katamari_christmassy")

add(descs,'cart: winter www.ariors \ndev: thecomicfiend\n"seasons greetings from comic\nfiend and the www.ariors!\nenjoy holiday art and effects\nwith some (always awesome!)\nmusical accomrpar..accompria.. accomp..ri..\n...\nsome music by @gruber! :d"')
local t16=maketag(2,96,42,106,12)
			t16.id=16
			if peek(0x5e0f)==1 then
				t16.w1=-19
				t16.xo=128
				t16.yo=128
				add(tokens,16)
			end
			t16.page=2
			add(tags,t16)
			
			add(carts,"#rahiropasa")

add(descs,'cart:snowy\'s skating adventure \ndev: dddaaannn & tim swast\n"in what many have referred to\nas the cutest lil snowman\nskating exploration game\nof 2019, help snowy on a quest\nto find trinkets.. and the\n*true* meaning of friendship.\n(giving each other trinkets)"')
local t17=maketag(30,96,42,34,12)
			t17.id=17
			if peek(0x5e10)==1 then
				t17.w1=-19
				t17.xo=128
				t17.yo=128
				add(tokens,17)
			end
			t17.page=2
			add(tags,t17)
			
			add(carts,"#snowysskatingadventure")
add(descs,'cart: snowman builder\ndev: jusiv\n"love the snow but hate the\ncold?\nthen stay cozy inside\nwhile decorating your own\nsnowman with this little\nvirtual toy!"')
local t18=maketag(2,97,42,12,12)
			t18.id=18
			if peek(0x5e11)==1 then
				t18.w1=-19
				t18.xo=128
				t18.yo=128
				add(tokens,18)
			end
			t18.page=3
			add(tags,t18)
			
			add(carts,"#snowman_builder")

add(descs,'cart: santa panic\ndev: dollarone\n"santa has lost his list!\nit\'s up to you to creep\non social media and profile\neveryone to see who\nwould want each gift!\njust like homeland security!\nor an unstable ex!♥"')
local t19=maketag(106,57,42,132,12)
			t19.id=19
			if peek(0x5e12)==1 then
				t19.w1=-19
				t19.xo=128
				t19.yo=128
				add(tokens,19)
			end
			t19.page=3
			add(tags,t19)
			
			add(carts,"#santa_panic")

add(descs,'cart: patrick\'s xmas challenge\ndev: tobiasvl\n"a mind bending movement\npuzzler!\nfire up this one to give\nyour noodle a workout.\ndon\'t forget to read the\nstory for that deep lore, my\ndudes!"')
local t20=maketag(106,27,42,110,12)
			t20.id=20
			if peek(0x5e13)==1 then
				t20.w1=-19
				t20.xo=128
				t20.yo=128
				add(tokens,20)
			end
			t20.page=3
			add(tags,t20)
			
			add(carts,"#patrick_xmas")

add(descs,'cart: present dude\ndev: 2tie\n"the story of a dude\nwho is.. here!\njust kidding!\nit\'s a really\ndope take on block dude.\nwith collectibles!\ncalc gamers uniiiiiite!"')
local t21=maketag(26,97,42,104,12)
			t21.id=21
			if peek(0x5e14)==1 then
				t21.w1=-19
				t21.xo=128
				t21.yo=128
				add(tokens,21)
			end
			t21.page=3
			add(tags,t21)
			
			add(carts,"#presentdude")

add(descs,'cart: snow tower\ndev: the tomster\n"hot! (cold!) arcade action!\nfreeze enemies! climb on their\nbacks to get yourself higher!\n..\nwait is this another\ncapitalist satire?\n is that like a thing now? :/"')
local t22=maketag(63,97,42,134,12)
			t22.id=22
			if peek(0x5e15)==1 then
				t22.w1=-19
				t22.xo=128
				t22.yo=128
				add(tokens,22)
			end
			t22.page=3
			add(tags,t22)
			
			add(carts,"#snow_tower")

----
add(descs,'cart: crafty christmas cats\ndev: burning_out\n"cat burglars are at it again!\ndefend your home!\nsoon to be optioned\nas a major motion picture\nstarring...\nmacatlay kitten."')
local t23=maketag(2,97,42,138,12)
			t23.id=23
			if peek(0x5e16)==1 then
				t23.w1=-19
				t23.xo=128
				t23.yo=128
				add(tokens,23)
			end
			t23.page=4
			add(tags,t23)
			
			add(carts,"#craftyxmascats")

add(descs,'cart: myrrhs edge\ndev: tom hall, toby hefflin,\nsquirrel eiserloh, gruber\n"help ya king balthazar run to\na very important engagement\nand get myrrh without getting\nmyrrh-dered! biblical scholars\nare calling this \'basically\nwhat totally happened\'"')
local t24=maketag(32,97,42,136,12)
			t24.id=24
			if peek(0x5e17)==1 then
				t24.w1=-19
				t24.xo=128
				t24.yo=128
				add(tokens,24)
			end
			t24.page=4
			add(tags,t24)
			
			add(carts,"#myrrhs_edge")
add(descs,'cart: a perfect snowflake\ndev: zep\n"in a post-apocalyptic world\nwhere water is scarce\na young boy quenches\nhis thirst by eating\nsnow.\nok fine it\'s just a cute game.\ni made the dark backstory up."')
local t25=maketag(63,97,42,66,12)
			t25.id=25
			if peek(0x5e18)==1 then
				t25.w1=-19
				t25.xo=128
				t25.yo=128
				add(tokens,25)
			end
			t25.page=4
			add(tags,t25)
			
			add(carts,"#aps")
add(descs,'cart: jezzle bells\ndev: enargy\n"yarrr! capture as much\nterritory as possible\nwithout hitting the balls!\nthis is also a commentary\non imperialism -- jk but srsly\ngames can be political come on\ndebate me irl m8 lol ;^)"')
local t26=maketag(94,40,42,102,12)
			t26.id=26
			if peek(0x5e19)==1 then
				t26.w1=-19
				t26.xo=128
				t26.yo=128
				add(tokens,26)
			end
			t26.page=4
			add(tags,t26)
			
			add(carts,"#jezzlebells")

----

	title = 0
	calendar = 1
	menu = 2
	
	maxpage = 4
	
	page = maxpage
	
	mb = { x=88
	      ,y=84
	      ,w=32
	      ,h=32}
	
	state = calendar
	cmark,curs=0,0
	
	nxtbtn = {x=118,y=56,w=8,h=16,s=47}
	prvbtn = {x=2,y=56,w=8,h=16,s=47}

end
function update60()
	updatemouse()
	rc+=1
	rf=flr(rc/15)%2
	
	ptimer+=1
	if ptimer>=5 then
		ptimer-=5
		poff-=1
		if poff<0 then
			poff=#pats
		end
	end
	
	if state == menu then
		if not interstita then
	 	cmark=curs
	 	if btnp(⬅️) then
	 	 cmark=curs-1
	 	 interstita=0
	 	 ilet=.015
	 	 sfx(11)
	 	elseif btnp(➡️) then
	 	 cmark=curs+1
	 	 interstita=0
	 	 ilet=-.015
	 	 sfx(11)
	 	end
	 	if cmark>#tokens-1 then
				cmark=0
				interstita=nil
		 	curs=cmark
		 elseif cmark<0 then
		 	cmark=#tokens-1
		 	interstita=nil
		 	curs=cmark
			end
	 				
	 elseif abs(interstita)<=selspacer then
	 	interstita+=ilet
	 	if abs(interstita)>=selspacer then
	 		interstita=nil
				curs=cmark
			end
	 end
					
		if btnp(🅾️) then
			daynumber=""..tokens[curs+1]
			_update60=introupd
			_draw=nil
		elseif btnp(❎) then
			state=calendar
		end
	elseif state == calendar then
		--[[if not lmb then
			if held then
				held.aflag = true
			end
			held = nil
			woff = nil
		end]]
				
		
		
		if nxtbtn.held and not lmb then
			nxtbtn.held=nil
			if collide({x=mousex,y=mousey,w=2,h=2},nxtbtn) then
				sfx(13)
				page+=1
			end
		elseif prvbtn.held and not lmb then
			prvbtn.held=nil
			if collide({x=mousex,y=mousey,w=2,h=2},prvbtn) then
				sfx(13)
				page-=1
			end
		
		elseif lclick then
			for k,v in pairs(tags) do
				if (v.page or 1)==page then
					if collide({x=mousex,y=mousey,w=2,h=2},{x=v.x,y=v.y,w=v.w1,h=v.h1}) then
						v.opentimer=15
						sfx(12)
					end
				end
			end
			if collide({x=mousex,y=mousey,w=2,h=2},{x=53,y=22,w=32,h=32}) and stuffedstocking and page==3 then
				sfx(15)
				load("#adventsimulator19")
			end
			if collide({x=mousex,y=mousey,w=2,h=2},{x=mb.x,y=mb.y,w=mb.w,h=mb.h}) and #tokens>0 then
				state=menu
				sfx(13)
			end
			if collide({x=mousex,y=mousey,w=2,h=2},prvbtn) then
				if page>1 then
					prvbtn.held=true
				end
				
			else
				prvbtn.held=nil
			end
			if collide({x=mousex,y=mousey,w=2,h=2},nxtbtn) then
				if page<maxpage then
					nxtbtn.held=true
				end
				
			else
				nxtbtn.held=nil
			end
		end
		
		for k,v in pairs(tags) do
			if v.opentimer then
				v.w1 = mid(v.w1-.5,20,-19)
				if v.w1==-19 then
					v.opentimer-=1
				end
				if v.opentimer<= 0 then
				
					v.aflag = true
					poke(0x5e00+k-1,1)
					add(tokens,k)
					v.opentimer=nil
				end
			end
		end
	end
	
end
function draw()
	cls(12)
	palt(11,true)
	palt(0,false)
	
	if state == menu then
		
		draw_shop()
		
	elseif state == calendar then
	 
	 if page==1 then
		 for i=0,132,8 do
		 	circfill(i,127,14,7)
		 end
		 
		 
		 fillp(pats[poff])
		 rectfill(32+16,72,72-16,127,0x78)
		 fillp()
		 rect(32+16,72,72-16,127,0)
		 
		 circfill(52,32,7,10)
		 circ(52,32,7,0)
		 rectfill(32,32,72,72,9)
		 rect(32,32,72,72,0)
		elseif page==2 then
			for i=0,132,8 do
		 	circfill(i,127,14,7)
		 end
		 
		 sspr(0,64,16,8,72,70,24,8,true)
		 
		 circfill(64-2,100,18,6)
		 circfill(64,100,16,7)
		 circfill(64-2,78,16,6)
		 circfill(64,78,14,7)
		 circfill(64-2,55,12,6)
		 circfill(64,55,10,7)
		 
		 circfill(60,55,2,0)
		 circfill(70,55,2,0)
		 circfill(66,59,3,9)
		 circfill(68,59,2,9)
		 circfill(70,59,1,9)
		 
		 circfill(66,74,2,0)
		 circfill(66,80,2,0)
		 circfill(66,86,2,0)
		 
		 
		 sspr(0,64,16,8,28,70,24,8)
		 
		 snow()
		 
		elseif page==3 then
			fillp()
			rectfill(12,22,116,110,4)
			rect(12,22,128-12,110,0)
			rectfill(21,36,107,107,6)
			rect(21,36,107,107,0)
			fillp(0b0101101001011010)
			rectfill(24,46,104,105,0x01)
			
			fillp()
			rectfill(4,14,123,21,7)
			rect(4,14,123,21,0)
			clip(24,30,80,75)
			
			draw_fire(24,70)
			
			clip()
			local s=0
			if stuffedstocking then
				s=2
			end
			for i=s,s do
				psspr(16+i*16,112,16,16,9+i*22,22,32,32)
			end
			
		elseif page==4 then
			
			
			--roof
			cls(1)
			circfill(120,4,8,10)
			rectfill(0,fluff.y+18,127,127,7)
			--clip(0,fluff.y+18,127,127)
			snow()
			--clip()
			drawfluff(fluff)
			circfill(fluff.x+48,fluff.y+16,12,4)
			circfill(fluff.x+48,fluff.y+14,10,9)
			circ(fluff.x+48,fluff.y+16,12,0)
			
			spr(142,fluff.x+47,fluff.y-2)
	

		end
		for k,v in pairs(tags) do
			if (v.page or 1)==page then
				local sx2 = (v.s2%16)*8
				local sy2 = flr(v.s2/16)*8
				
				rectfill(v.x,v.y,v.x+20,v.y+20,9)
				for i=0,5 do
					rectfill(v.x+i,v.y+i,v.x+20-i,v.y+i,4)
					rectfill(v.x+i,v.y+20-i,v.x+20-i,v.y+20-i,15)
				end
				rect(v.x,v.y,v.x+20,v.y+20,0)
				//rectfill(v.x,v.y,v.x+v.w,v.y+v.h,1)
				if v.id==3 or v.id==15 then
					palt(11,false)
				end
				psspr(sx2,sy2,v.w,v.h,v.x+v.xo,v.y+v.yo,v.w2,v.h2)
				palt(0,false)
				palt(11,true)
	
				local sx1 = (v.s1%16)*8
				local sy1 = flr(v.s1/16)*8
				if v.c1 then
					pal(4,v.c1)
				end
				
				
				sspr(sx1,sy1,v.w,v.h,v.x,v.y,v.w1,v.h1)
				pal(4,4)
				
				
				if v.w1<0 then
					rectfill(v.x+v.w1,v.y,v.x,v.y+v.h1,4)
					
				end
				rect(v.x+v.w1,v.y,v.x-1,v.y+v.h1,0)
				pprint(k,v.x+9,v.y+24,10,0)
			end
		end
		for k,v in pairs(tags) do
			if v.aflag then
				v.d*=1.1
				v.d=mid(1,v.d,127)
				v.a+=.02
				v.xo=v.sxo+cos(v.a)*v.d
				v.yo=v.syo+sin(v.a)*v.d
				
				if v.d >=100 
				 or v.xo>=127
				 or v.xo<=-16
				 or v.yo>=127
				 or v.yo<=-16 then
					v.aflag = false
					v.xo,v.yo=128,128
				end
			end
			local sx2 = (v.s2%16)*8
			local sy2 = flr(v.s2/16)*8
			
			if v.aflag then
				if v.id==3 then
					palt(11,false)
				end
				psspr(sx2,sy2,v.w,v.h,v.x+v.xo,v.y+v.yo,v.w2,v.h2)
				palt(0,false)
				palt(11,true)
		
			
			end
		end
		//rectfill(mb.x,mb.y,mb.x+mb.w,mb.y+mb.h,13)
		//rect(mb.x,mb.y,mb.x+mb.w,mb.y+mb.h,0)
	 psspr(0,16,16,16,mb.x,mb.y,mb.w,mb.h)
	   
	      
	 pprint("toy",mb.x-12+(mb.w/2),mb.y+32,8,0)
	 pprint("box",mb.x+2+(mb.w/2),mb.y+32,3,0)
		
		pprint("⬆️⬇️⬅️➡️ - move | 🅾️ to open",8,10,3,0)
		pprint("(click for mouse control)",14,18,8,0)
		
		pprint("the 2019 pico-8 advent calendar",2,2,7,0)
		
		if page<maxpage then
			if nxtbtn.held then
				pal(14,2)
			end
			spr(nxtbtn.s,nxtbtn.x,nxtbtn.y,1,2)
			pal(14,14)
		end
		if page>1 then
			if prvbtn.held then
				pal(14,2)
			end
			spr(prvbtn.s,prvbtn.x,prvbtn.y,1,2,true)
			pal(14,14)
		end
		
		if lmb then
			pspr(2,mousex,mousey,2,2)
		else
			pspr(0,mousex,mousey,2,2)
		end
		
	end
	
end
-->8
function collide(a,b)
	if a.x>b.x+b.w
	 or a.x+a.w<b.x
	 or a.y>b.y+b.h
	 or a.y+a.h<b.y then
	else
		return true
	end
end
function psspr(sx,sy,sw,sh,x,y,w,h,c1)
 for i=0,15 do
  pal(i,c1)
 end
 for ix=-1,1 do for iy=-1,1 do
  sspr(sx,sy,sw,sh,x+ix,y+iy,w,h)
 end end
 for i=0,15 do
  pal(i,i)
 end
 sspr(sx,sy,sw,sh,x,y,w,h)
end
function pspr(id,x,y,w,h,c1)
 for i=0,15 do
  pal(i,c1)
 end
 for ix=-1,1 do for iy=-1,1 do
  spr(id,x+ix,y+iy,w,h)
 end end
 for i=0,15 do
  pal(i,i)
 end
 spr(id,x,y,w,h)
end
-->8
function snow()
	if not sparts then
		sparts={}
		for i=0,200 do
			add(sparts,{x=rnd(128),y=rnd(128),yvel=max(rnd(2),.2),xvel=max(rnd(.01),.001),a=0,s=max(flr(rnd(3)),1)})
		end
	end
	for k,v in pairs(sparts) do
		v.y+=v.yvel
		v.a+=v.xvel
		circfill(v.x+cos(v.a)*3,v.y,v.s,7)
		if v.y>=130 then
			v.y = -3
		end
	end
end
-->8
function introupd()

if not _timer then
 	_timer = 0
end

_timer+=2
if (btnp()>0) _timer=8*60
cls()
f=4-abs(_t()-4)
for z=-3,3 do
 for x=-1,1 do
  for y=-1,1 do
   b=mid(f-rnd(.5),0,1)
   b=3*b*b-2*b*b*b
   a=atan2(x,y)-.25
   c=8+(a*8)%8
   if (x==0 and y==0) c=7
   u=64.5+(x*13)+z
   v=64.5+(y*13)+z
   w=8.5*b-abs(x)*5
   h=8.5*b-abs(y)*5
   if (w>.5) rectfill(u-w,v-h,u+w,v+h,c) rect(u-w,v-h,u+w,v+h,c-1)
  end
 end
end
 
if rnd()<f-.5 then
 ?daynumber,69-#daynumber*2,65,2
end
 
if f>=1 then
 for j=0,1 do
  for i=1,f*50-50 do
   x=cos(i/50)
   y=sin(i/25)-abs(x)*(.5+sin(_t()))
   circfill(65+x*8,48+y*3-j,1,2+j*6)
  end
 end
 
 for i=1,20 do
  ?sub("pico-8 advent calendar",i),17+i*4,90,mid(-1-i/20+f,0,1)*7
 end
end
 
if (_t()>=8) load(carts[tonum(daynumber)],"back to calendar") --_update60=update60 _draw = draw _timer=nil 
flip()
end
function _t()
 
 return _timer/60
end

function pprint(s,x,y,c1,c2)
 for ix=-1,1 do for iy=-1,1 do
 	?s,x+ix,y+iy,c2
 end end
 ?s,x,y,c1
end
-->8

				
function draw_shop()
	rectfill(1,13,126,120,0)
 rectfill(3,15,124,118,13)
 palt(0,false)
 palt(11,true)
 
 
 sorted={}
 cm=cmark+1
 add(sorted,cm)
 fig=#tokens/2
 while #sorted<fig do
 	if cm==0 then cm=#tokens end
 	add(sorted,cm)
 	cm-=1
 end
 cm=cmark+2
	while #sorted<=#tokens do
 	if cm==#tokens+1 then cm=1 end
 	add(sorted,cm)
 	cm+=1
 end
 del(sorted,curs+1)
 add(sorted,curs+1)
	--reverse the list	
	
	for k=1,#sorted do
		k=sorted[k]
  v=tokens[k]
  if k==0 then
  	return
  else
    local a=(interstita or 0)+.6+(k-curs)*selspacer
    
    k-=1
    local x=32+cos(a)*48
    
    local y=26+sin(a)*12
    x+=26
    y+=4
    if k==curs and (curs==cmark or not cmark) then
     --use rotate effect
      y+=rf
 	 			pprint(descs[tags[v].id],x-24,y+23-rf,7,0)
  	 		spr(62,x+4,y-8-rf)
    end
    
    
    local v = tags[v]

    local sx2 = (v.s2%16)*8
				local sy2 = flr(v.s2/16)*8
				if v.id==3 or v.id==15 then
					palt(0,false)
					palt(11,false)
				end
    psspr(sx2,sy2,v.w,v.h,x,y,v.w2,v.h2)
  		palt(0,false)
				palt(11,true)
		
  		//todo: black out if not opened
  		
  		
  		
   end
 end
 pprint("⬅️➡️ - select | ",2,2,9,0)
 pprint("                🅾️ - load cart",2,2,3,0)
 pprint("❎ - return",2,122,14,0)
end
-->8
function maketag(x,y,s1,s2,c1)
	return { x=x
	          ,y=y
	          ,w=16
	          ,h=16
	          ,w1=20
	          ,h1=20
	          ,w2=16
	          ,h2=16
	          ,s1=s1
	          ,s2=s2
	          ,sxo=2
	          ,syo=2
	          ,xo=2
	          ,yo=2
	          ,d=.1
	          ,a=0
	          ,c1=c1}
end
-->8
function draw_fire(xo,yo)
	spr(224,40+12,89,2,2)
	spr(224,41,89,2,2)
	spr(224,40+28,89,2,2,1)
	local ctbl = {[0]=8,8,9,9,10,5,13,6,7}
	dels={}
	if not fire then
		fire={}
		for i=0,150 do
			local f={ x=22+rnd(32)
			        ,y=16
			        ,s=8
			        ,yvel=max(rnd(1),.1)
			        ,xvel=max(rnd(4),.01)
			        ,a=rnd(3)}
			add(fire,f)
		end
	end
	
	for k,v in pairs(fire) do
		v.a+=.01
		v.y-=v.yvel
		v.s=(4+(v.y/6))
		local c = ctbl[flr(10-v.s)]
		fillp()
		--if (c or 1)%2==1 then fillp(0b0101101001011010) end
		circfill(cos(v.a)*v.xvel+v.x+xo,v.y+yo,v.s,c)
		if v.s<=0 then
			add(dels,v)
			
		end
	end
	for k,v in pairs(dels) do
		del(fire,v)
		local f={ x=22+rnd(32)
			        ,y=16
			        ,s=8
			        ,yvel=max(rnd(1),.1)
			        ,xvel=max(rnd(4),.01)
			        ,a=rnd(3)}
		add(fire,f)
	end
	fillp()
	
	
	
end

-->8
function drawfluff(f)
 f.a+=.01
	pspr(168,f.x-4,f.y+20,2,1)
	pspr(f.s,f.x,f.y+(2.5*sin(f.a)),4,4)
	spr(f.es,f.x+5,f.y+8+(2.5*sin(f.a)),2,2)
	pspr(184,f.x+20,f.y+24,2,1)
	pspr(236,f.x+4,f.y-4+(2.5*sin(f.a)),4,2)
end