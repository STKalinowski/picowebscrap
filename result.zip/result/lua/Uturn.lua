time_max=600--450--900
force={}
paliers={2,5,10,15}
pool_start={2,3,4,5,6,7,11,12}
force_nxt=nil

function _init()
 t=0
 hisc=0
 power=0
 logs={}
 ents={}
 --init_game()
 init_menu()
end

function mod(n)
 return (t%n)/n
end

function init_menu()
 sfx(1)
 vl=0
 
 t=0
 ents={}
 upd=function()
  t=t+1
  if vl>32 then
   init_game()
  end
 end
 
 dr=function()
  pal(8,13)
  if t>36 and vl==0 then
   n=max(40-t,0)
   cl= n==0 and 7 or 1
   line(36,7-n,91,7-n,cl)
   line(36,27+n,91,27+n,cl)
  end
  if t>40 then
   pal(8,sget(16+min((t-40)/2,7),2))
   
   cx=64
   cy=80

   for i=0,15 do
    an =i/16
    c=cos(i/16+t/50)
	   r = 30+c*12+max((70-t)*4,0)+vl*2
    ray=6+c*3-vl/2
    cl=sget(22-c*6,2)

    circ(cx+cos(an)*r,cy+sin(an)*r,ray,cl)
   end

   
   if mod(vl>0 and 2 or 16)<.5 and vl<24 then
    print("press <x> to start",28,120,8)
   end
   if vl>0 then
    vl+=1
    
   elseif btnp(5) then
    vl=1
    sfx(6)
    music(-1,1000)
   end
   
  end  
  
  hdy=min(t*6-712,0)-vl*vl

  camera(0,hdy)
   --
   for x=32,96 do for y=48,100 do
    pix=pget(x,y)
    if pix>0 then
     for i=0,2 do pix=dark(pix) end
     pset(x,y,pix)
    end
   end end
   --
   print("--objectives--",37,50,13)
   for i=1,4 do
    cl=1
    y=52+i*8
    pal()
    if power>=i then
     apal(2)
    end
    sspr(16,3,4,5,38,y)
    print(gdd(paliers[i]),44,y,7)
    pal()
    if power<i then apal(1) end
    print(powers_str[i],56,y,14)
   end
   pal()
   print("hi-score:",38,94,13)
   print(gdd(hisc),80,94,7)
   sspr(16,3,4,5,74,94)
   
  camera()
   
  dx=(cos(mod(32)))*max(80-t*2,0)
  sspr(56,48,58,16,36+dx,8-vl*2)

  if t==40 then
   music(1,3000)
   sfx(2)
  end
 end
 
end

function dark(pix)
 return sget(48+pix,3)
end

function gdd(n)
 n=""..n
 if #n<2 then n="0"..n end
 return n
end

function init_game()
 music(8)
 fade=40
 drk=-1
 upd =upd_game
 dr=dr_game
 water_y=120
 bgx=0
 cvx=0
 cmx=0
 rr=0
 wlk_dist=0
 wlk=0
 cmx=0
 scr_shk=0
 reset_counter()
 flags=0
 start=0
 gmo=nil
 lvl={0,1}
 flaws={}
 for x=0,128 do for y=16,32 do
  mset(x,y,0)
 end end
 
 -- birds
 init_birds()
 
 -- build_pool
 pool={}
 for n in all(pool_start) do add(pool,n) end
 if power>=2 then add(pool,13) end
 scan(0)
 scan(1)
 
 -- hero
 hero=mke(16,8,80)
 hero.phys=true
 hero.we=0.5
 hero.upd=upd_hero
 hero.dr=dr_hero
 hero.cst=16

 -- 
 for n in all(force) do
  add_flaw(n)
 end
 build_lvl()

end

function dr_hero(e)
 if e.shield or (e.csh and t%4<2 ) then
	 
	 n=-flr(abs(e.vx))
	 local flp=e.sns==-1
	 x=e.x+3+n
			
	 if flp then
	  x-=6+2*n
	 end
	 autopal()
	 spr(22,x,e.y,1,1,flp)
 end
end

function init_birds()
 for i=1,5 do
  local cc=i/5
  local c=rnd()
  b=mke(0,rnd(128),rnd(128))
  b.vy=-cc/3
  b.dp=-1
  b.eternal=true
  b.fr=0
  
  b.upd=function(b)
   
   b.vx=cos(t/(100+cc*250))*cc/2
   b.vy=sin(t/(100+c*200))*cc/2
   b.x-=cvx*(0.25+cc/4)
   b.x=b.x%128
   b.y=b.y%128
  end
  b.dr=function(e)
  
   fr=0
   if e.vy<0 then
    fr=flr((t/12)%2)
   end
  
   sspr(24+fr*3,3,3,3,e.x,e.y)
   
  end
 end
end

function announce(fr)
 
 if fr<8 then fr=8 end
 local str="no desc"
 for i=0,16 do
  if mget(i,0)==fr then
   str=flaws_str[i+1]
  end
 end
 
 ww=10+8+#str*4
 hh=8
 local e=mke(0,(128-ww)/2,128)
 e.dp=3
 e.dr=function(e)
  rectfill(x+1,y+1,x+ww+1,y+11,1)
  rectfill(x,y,x+ww,y+10,13)
  for i=0,1 do
  	x=e.x+1-i
  	y=e.y+1-i  
   pal()
   if i==0 then apal(1) end
   print(str,x+14,y+3,7)
   spr(fr,x+1,y+1)
  end
 end
 mvt(e,e.x,115,2)
 function vanish()
  mvt(e,e.x,128,2)
  e.life=40
 end
 wt(48,vanish)
 

end


function build_lvl()
 hero.shield=power>=4
 
 k=0
 for n in all(lvl) do
  for x=0,15 do for y=2,15 do
   tl=mget(x+n*16,y)
   
   if fget(tl,7) then
    
    local e=spawn(tl,(x+k*16)*8,y*8,n,x..","..y)
 
    if fget(tl,2) and e then
     tl=1

    else
     tl=0
    end
 
   end
   mset(x+k*16,y+16,tl)
  end end
  k+=1
 end
end

function in_pool(fr)
 for n in all(pool) do
  if n==fr then return true end
 end
 return false
end
function flw(fr)
 for n in all(flaws) do
  if n==fr then return true end
 end
 return false
end

function spawn(fr,x,y,at,uid)
 if in_pool(fr) then return nil end
 for e in all(ents) do
  if e.uid == uid then
   return nil
  end
 end
 
 local e=mke(fr,x,y)
 e.uid=uid
 e.ox=x
 e.oy=y
 e.flyer=fr==19
 e.bad=fget(fr,1)
 e.spikes=fr==48
 if e.flyer then
  e.phys=true
  e.dr=function(e)
   spr(20,e.x,e.y+4)
  end
 end
 if e.fr==35 then
  e.ddx=0
  e.dr=function()
   spr(36,e.x+e.ddx,e.y)
   spr(35,e.x,e.y)
  end
 end
 
 if fr==24 then
  e.lps=1
  e.spikes=true
  e.immune=true
 end
 
 if fr==50 then
  e.upd = upd_fish
 elseif fr==32 then -- flag
  if at!=start then
   flag=e 
  else
   kl(e)
  end
 else
  e.upd=upd_mon
 end
 
 if fr==43 then
  e.upd=upd_spitter
 end
 -- fx
 if is_in(e) then
  e.cspawn=16
 end
 
 return e
 
end

function upd_fish(e)
 c=((t+e.x*2)%100)/100
 e.y=128-cos(c)*48
 e.fr=50
 if e.y<100 then
  e.fr+=(t/4)%2
 end
end

function upd_mon(e)

 -- walk
 if e.fr==48 or e.fr==38 then

   walk(e)
 
 end
 
 -- fly
 if e.flyer then
  if is_in(e) then
   fly(e)
  end
 end
 
 -- canon
 if e.fr==35 then
  e.ddx*=0.75
  tt=(t+e.x)%120
  if tt%60==0 then
   sfx(12)
   p=mke(37,e.x,e.y)
   p.sns=tt==0 and -1 or 1
   p.vx=p.sns
   p.bad=true
   e.ddx=-p.vx*2
   p.phys=true
   p.proj=true
   p.cgh=8
   p.oncol=function(p)
    explo(p,4)
    kl(p)
   end
  end
 end
 

 
end

function upd_spitter(e)
  
  dx=hero.x-e.x
  dy=hero.y-e.y
  
  if e.cdn and e.cdn>34 then
   if e.cdn==54 then
    e.fr=46
    sfx(26)
    --fireball
    p=mke(59,e.x,e.y)
    p.bad=true
    p.proj=true
    p.phys=true
    p.spikes=true
    p.immune=true
    p.lps=2
    p.oncol=function(e) 
     explo(e,6)
     kl(e) 
    end
    p.vx=e.sns*2
   end
   if e.cdn==44 then
    e.fr=45
   end

  elseif is_in(e) and not e.cdn and  abs(dy)<4 and dx*e.sns>0 then
   e.cdn=64
   e.fr=45
  else
   e.fr=43
   walk(e)
  end

end


function fly(e)
  
 if (e.ox+t)%200==0 then
  e.fr=21
  
  -- bottle
  function f()
   sfx(22)
   e.fr=19
   local p=mke(54,e.x,e.y)
   p.we=0.25
   p.vy=-3
   p.vx=sgn(hero.x-e.x)*2
   p.phys=true
   p.bad=true
   p.proj=true
   p.oncol=function(p)
    sfx(21)
    xpl(p,32,0)
   end
  end
  wt(24,f)
 end
 e.frict = 0.95
 lim=.12
 dx=hero.x-e.x
 if abs(dx)<64 then
  e.vx+=mid(-lim,dx/100,lim)
  e.vy+=(max(hero.y-48,0)-e.y)/100
 end
 e.vy*=0.9
end

function xpl(e,x,y)
 
 for i=0,3 do
  
  local p=mke(0,e.x+2,e.y+2)
  imp(p,i/4+0.15,1)
  p.vx+=rnd()*e.vx
  p.vy-=rnd(2)
  p.we=0.15
  p.bad=true
  p.proj=true
  p.sz=3
  p.life=8+rand(8)
  p.dr=function(p)
   sspr(x+4*i,y,4,4,p.x,p.y)
  end
 end
 kl(e)
 
 
end

function mvt(e,x,y,tt)
 e.twc=0
 e.sx=e.x
 e.sy=e.y
 e.tx=x
 e.ty=y
 dx=x-e.sx
 dy=y-e.sy
 e.spc=tt
 if tt>0 then
  e.spc=tt/sqrt(dx*dx+dy*dy)
 end
 
 
end

function dist(a,b)
 dx=a.x-b.x
 dy=a.y-b.y
 return sqrt(dx*dx+dy*dy)
end


function walk(e)
 dx=0.5*e.sns
 gr=pcol(e.x+dx,e.y+e.sz) and pcol(e.x+dx+7,e.y+e.sz)
 if ecol(e,dx) or not gr  then
  e.sns*=-1
 end
 e.x+=0.5*e.sns
end


function upd_hero(e)
 
 if e.vy>4 then
  e.vy*=0.95
 end
 if not e.cfz then
  e.vx*=0.8
 end
 e.water=e.y+8 > gwy(e.x)
 if e.water then
  e.vx*=0.5
  e.vy*=0.5
 end
 
 
 e.running=false
 ngr=nil
 if ecol(hero,0,1) then
  ngr=mget((hero.x+4)/8,17+hero.y/8)
 end
 if e.ground and not ngr and power>1 then
  e.burning=true
 end
 e.ground=ngr
 
 if e.ground and e.burning then
  e.burning=false
 end
 
 if btn(0) then hmov(-1) end
 if btn(1) then hmov(1) end
 if btnp(2) then jump() end
 
 -- check ground
 check_faller(e) 

 
 -- check death
 for a in all(ents) do
  if a.bad and dcol(a,e)  then 
   if not e.ground and e.vy>0 and e.y<a.y and not a.spikes then
     sfx(11)
     p=stun(a)
     p.vx=hero.vx*0.5
     e.vy=-5
   elseif not e.cim then
    if a.proj and a.vx*e.sns<0 and (e.shield or e.csh) then
     hero.vx=a.vx
     hero.cfz=20
     hero.shield=false
     hero.csh=28
     p=stun(a)
     p.vx=-a.vx/2
     sfx(31)
    else
     die()
     a.killer=true
    end
   end
  end
  if a.hcol then a.hcol(a) end
 end
 -- check fall
 if e.y>125 then
  die()
  return
 end

 -- check flag
 if dcol(e,flag) then
  local f=flag
  level_up()
  kl(f)
  function pop()
   local p=mkp(48,f.x+rand(8),f.y+7,1)
   --p.we=-rnd(0.5)
   p.vy=-rnd(8)
   p.frict=0.85
   p.life=8+rand(8)
   p.dp=0
  end
  for i=0,16 do wt(i,pop) pop() end
 end

end

function splash(x)
 local p=mkp(24,x,gwy(x),2)
 p.we=0.1+rnd()/10
 p.vy=-rnd(2)
 return p
end

function stun(e)
 sfx(32)
 kl(e)
 local p=mke(e.fr,e.x,e.y)
 p.vy=-2
 p.we=0.5
 p.life=40
 p.stun=true
 return p
end

function mkp(fx,x,y,sc)
 sc=sc or 1
 local p=mke(0,x,y)
 p.life=8+rnd(8)
 p.dr=function()
  sspr(fx+8-p.life/2,0,1,1,p.x,p.y,sc,sc)
 end
 return p
end

function burn()
 
 hero.cim=8
 hero.burning=false
 explo(hero,5)
 
 if flw(13) then
  hero.churt=20
  count-=60
  if count<1 then count=1 end
 end
 
 ray=16
 for e in all(ents) do
 	if not e.immune and e.bad and dist(e,hero)<24 then
   p=stun(e)
   imp(p,atan2(dx,dy),3)
   p.fir=true   
  end
 end

 
end


function explo(from,mx)
 scr_shk=8
 sfx(15)
 local e=mke(0,from.x,from.y)
 e.life=8
 e.dp=0
 e.dr=function(e)
  c=1-e.life/8
  circ(e.x+4,e.y+3,6+sqrt(c)*16,10)
  circ(e.x+4,e.y+3,4+sqrt(c)*4,7)  
 end 

 for i=0,mx-1 do
  local p=mkp(16,from.x+rnd(8), from.y+rnd(8))
  imp(p,rnd(),rnd(2))
 end
end

function die()
 music(-1,1000)
 gmo=16
 sfx(9)
end

function check_faller(e)

 for i=0,1 do 
	 local px=flr((e.x+i*7)/8)
	 
	 for k=0,8 do
	  local py=max(flr(e.y/8+1)-k,0)
	  tl=mget(px,py+16)
	  if fget(tl,1) and flw(tl) then
	   sfx(29)
	   mset(px,py+16,1)
	   local e=mke(tl,px*8,py*8+1)
	   e.wfl=true
	   function fall()
	    sfx(30)
		   mset(px,py+16,0)
		   e.wfl=false
		   e.we=0.5
		   e.vy=1
		   e.life=40
		   e.bad=true
		   e.spikes=true
	   end
	   wt(16,fall)
	  end
	 end
 end
end


function power_up()
 power+=1
 rr=paliers[power]

end

function reset_counter()
 count=time_max
 if power>=3 then count+=150 end
end

function level_up()
 flags+=1
 hisc=max(flags,hisc)
 if power<4 and flags==paliers[power+1] then
  power_up()
 end
 reset_counter()
 start=1-start
 --sfx(8)
 sfx(42)
 --clean ents
 for e in all(ents) do
  if not is_in(e) and not e.eternal then
   kl(e)
  end
 end
 
 --
 if force_nxt then
  add_flaw(force_nxt)
  force_nxt=nil
 elseif #pool>0 then
  n=pool[rand(#pool)+1]
  add_flaw(n)
 end
	build_lvl()
end

function is_in(e)
 px=e.x-cmx
 return px>=-8 and px<128
end

function add_flaw(n)


 announce(n)
 add(flaws,n)
 del(pool,n)
 
 -- insert shark
 if n==12 then
  e=mke(0,0,120)
  e.sns=-1
  e.eternal=true
  e.frict=0.9
  e.upd=upd_shark
  e.dr=function(e)
   flp=e.sns==-1
   -- body
   x=e.x
   if e.sns==-1 then x+=8 end
   spr(26,x,e.y,3,1,flp)
   spr(26,x,e.y+8,3,1,flp,true)
   -- head
   x=e.x+24
   if e.sns==-1 then
    x=e.x
   end
   
   df=0
   
   if e.cc then
    df=flr(-sin(e.cc)*2+.5)
   end
   spr(29+df,x,e.y,1,1,flp)
   spr(29+df,x,e.y+8,1,1,flp,true)
   --eye
   circfill(x+2,y+6-df*2,1,13)
   
  end
  e.hcol=function(e)
 	 hdx=e.x+16-(hero.x+4)
	  hdy=e.y+8-(hero.y+4)
	  if abs(hdx)<18 and abs(hdy)<9 then
	   die()
	  end  
  end

  
 end
 
 
 -- insert_lvl
 if n<8 then
  pos=1+rand(#lvl-1)
  insert(lvl,pos,n)
  scan(n)
  for e in all(ents) do
   if e.x>pos*128 then
    e.x+=128
   end
  end  
  cmx=hero.x-64
 end
end

function upd_shark(e)

 e.vx+=e.sns*.25
 dx=hero.x-e.x
 dy=hero.y-e.y
 if abs(dx)>64 then
  e.sns = sgn(dx)
 end
 
 e.y=water_y+get_tide(e.x)-abs(cos(t/200)*8) 
 wy=gwy(x-cmx)
 


 e.cc=nil
 if e.cjmp  then
  e.cc=max((e.cjmp-96)/64,0)
  e.y+=sin(e.cc)*24
  
 elseif abs(dx)<32 and abs(dy)<32 and dx*e.sns>0 then
  e.cjmp=128
  sfx(25)
 end
 
 -- water drop
 if abs(e.y+7-wy)<4 then
  x=e.x+12+e.sns*14+rnd(8)
  
  p=splash(x)
  p.vx=-e.vx
  
 end

end

function scan(lvl)
 for x=0,15 do for y=2,15 do
  tl=mget(lvl*16+x,y)
  if tl!=32 and ( fget(tl,7) or fget(tl,1) ) and not flw(tl) and not in_pool(tl) then
   add(pool,tl)
  end
 end end
end
function insert(a,pos,el)
 for i=0,#a do
  n=#a-i
  if n==pos then
   a[n+1]=el
   return
  else
   a[n+1]=a[n]
  end

 end
 
end

function rand(n)
 return flr(rnd(n))
end

function dcol(a,b)
 box=a.x<b.x+b.sz and a.x+a.sz>b.x and
    a.y<b.y+b.sz and a.y+a.sz>b.y
 if not box then return false end

 if a.fr==0 or b.fr==0 then
  return true
 end
 
 for i=0,63 do 
  x=i%8
  y=flr(i/8)
  if gpix(a,x,y)>0 then
   bx=x-(b.x-a.x)
   by=y-(b.y-a.y) 
   if gpix(b,bx,by) > 0 then
    return true
   end
  end  
 end
 return false
end

function gpix(e,x,y)
 if e.sns==-1 then 
  x=7-x 
 end
 if x<0 or y<0 or x>=8 or y>=8 then
  return 0
 end
 
 return sget((e.fr%16)*8+x,flr(e.fr/16)*8+y)
end


function jump()
 if hero.ground or hero.burning then
  sfx(7)
  hero.vy = -5
  if power>1 then
   hero.burning = not hero.burning
   if not hero.burning then
    burn()
   end
  end
 end
end

function hmov(d)
 if hero.ground then
  wlk_dist+=abs(hero.vx)
  if hero.water then
   p=splash(hero.x+rnd(8))
   p.vx=rnd()*hero.vx*2
  end
  lim=hero.water and 4 or 8
  
  if wlk_dist>lim then
   wlk_dist-=lim
   wlk+=1
   bss=13
   
   local g=hero.ground
   if g==65 then
    bss=17
   end
   if g==70 or g==74 then
    bss=19
   end   
   if hero.water then
    bss=27
   end
   sfx(bss+wlk%2)
  end
 end

 hero.running=true
 spd=0.3
 if power>0 then spd=0.5 end
 if hero.cfz then 
  spd*=1-hero.cfz/20
 end
 hero.vx+=d*spd
 hero.sns=d
end

function mke(fr,x,y)
 e={fr=fr,x=x,y=y,vx=0,vy=0,
  sz=8,we=0,frict=1,sns=1,n=0,
  dp=1,lps=8,
 }
 add(ents,e)
 return e
end

function upe(e)
 
 -- counters
 for v,n in pairs(e) do
  if sub(v,1,1)=="c" then
   n-=1
   if n==0 then
    e[v]=nil
   else
    e[v]=n
   end
  end
 end 
 
 --move
 if e.phys and not e.cgh then
  pmove(e)
 else
  e.x+=e.vx
  e.y+=e.vy
 end
 
 e.vy+=e.we
 e.vx*=e.frict
 e.vy*=e.frict 
 
 if e.upd then e.upd(e) end
 
 -- tweening
 if e.twc then
  e.twc=min(e.twc+e.spc,1)
  c=e.twc
  e.x=e.sx+c*(e.tx-e.sx)
  e.y=e.sy+c*(e.ty-e.sy)
  if e.twc==1 then
   e.twc=nil
  end
 end
 
 if e.life then
  e.life-=1
  if e.life<= 0 then
   kl(e)
  end
 end
 
 if e.cspawn and t%3==0 then
  p=mke(52,e.x,e.y)
  p.x+=rnd(8)-4
  p.y+=rnd(8)-4
  p.we=-0.1
  p.life=8+rand(10)
  p.twinkle=true
 end
 
end



function pmove(e)
 col=false
 e.x+=e.vx
 sgx=sgn(e.vx)
 while ecol(e) do
  e.x-=sgx
  e.vx=0
 	col=true
 end
 e.y+=e.vy
 sgy=sgn(e.vy)
 while ecol(e) do
  e.y-=sgy
  e.vy=0
  col=true
 end
 if col and e.oncol then e.oncol(e) end

end

function ecol(e,dx,dy)
 dx = dx or 0
 dy = dy or 0
 a={0,0,1,0,0,1,1,1}
 for i=0,3 do
  x=e.x+a[1+i*2]*(e.sz-1)+dx
  y=e.y+a[2+i*2]*(e.sz-1)+dy
  if pcol(x,y) then
   return true
  end
 end
 return false
 
end

function pcol(x,y)
 if y<0 or x<0 or x>=#lvl*16*8 then
  return false
 end
 tl=mget(x/8,16+y/8)
 if x<0 then return true end
 return fget(tl,0)
end



function dre(e)
 if e.dp != depth then return end
 flp=e.sns==-1
 x=e.x
 y=e.y
 fr=e.fr
 
 -- running
 if e.running then
  if e.ground then
   fr+=(t/5)%2
  else
   fr+=1
  end
 end

 --
 if e.wfl then
  y = y+((t+e.x/8)/2)%2
 end
 if e.twinkle then
  fr=fr+t%2
 end
 
 
 if e.flyer then
  y=y+flr(cos(mod(16))+0.5)
 end
 
 -- loop
 loop=0
 while fget(fr+loop,3) do loop+=1 end
 if loop>0 then
  fr=fr+(t/e.lps)%loop
 end
 
 -- jump
 if fget(fr,0) then
  y-=1
 end
 
 -- map
	autopal()
	if e==hero or e.killer then
	 pal()
	end
	
 if e.burning then
  pal(13,9+t%2)
  pal(5,8+t%2)
  
  cl=10+t%2
  if cl==11 then cl=7 end
  pal(14,cl)
 end
 
 if e.fir then
  for i=0,15 do pal(i,sget(48+i,4+mod(4)*3)) end
 end
	
 spr(fr,x,y,e.sz/8,e.sz/8,flp,e.stun)

 if e.dr then e.dr(e) end
	--if e.burning then
  --spr(40,x,y+5.5+cos(mod(5)))
	--end
end

function wt(n,func)
 e=mke(0,0,0)
 e.life=n
 e.dth=func
end

function kl(e)
 del(ents,e)
 if e.dth then e.dth() end
end

function upd_game()

 -- game over
 if gmo then
  gmo-=1
  if gmo==0 then
   sfx(10)
   gmo=nil
   kl(hero)
   for i=0,7 do
    e=mke(52,hero.x,hero.y)
    imp(e,i/8,2)
    e.frict=0.95
    e.life=40
    e.twinkle=true
   end
   wt(36,init_menu)
  end
  return
 end
 
 -- chrono
 count-=1
 if count%30==0 and count>=-30 and count<=90 then
  if count==-30 then  die()
  elseif count==0 then 
   sfx(24)
   hero.churt=8
  else 
   sfx(23)
   hero.churt=8
  end
 end
 
 -- water
 wty=flw(11) and 110 or 120
 water_y += (wty-water_y)*0.1 
 
 t+=1
 foreach(ents,upe)
end

function _update()
 if fade then
  fade=mid(0,fade+drk*2,40)
  if fade==40 or fade==0 then
   fade=nil
  end
 end
 if upd then upd() end
end

function imp(e,an,spd)
 e.vx+=cos(an)*spd
 e.vy+=sin(an)*spd
end

function autopal()
 pal()
 if gmo then
  for i=0,15 do
   pal(i,sget(16+i,1))
  end
 end
 
 --
 if fade then
  for i=0,15 do
   pal(i,sget(8+i,72+fade*8/40))
  end
 end  

 
end

function get_tide(x)
 tide=4
 if flw(11) then tide+=4 end
 return cos(t/300)*tide
end
function gwy(x)
 local n=cos((cmx*1.5+x)/48)*cos(t/40)*3
 local wy=water_y+get_tide(x-cmx)+n
 if hero.cst then wy+=hero.cst end
 return wy
end
function dr_game()
 autopal()
 
 --bg
 rectfill(0,0,127,127,14)

 map(48,48,bgx/2-16)
 depth=-1
 foreach(ents,dre)
 
 map(0,48,bgx)
 ncmx=hero.x-64
 cvx=ncmx-cmx
	--bgx+=(cmx-ncmx)/2
	bgx-=cvx/2
 cmx=ncmx
 
 camera(cmx,scr_shk)
 scr_shk*=-0.25
 
 depth=0
 foreach(ents,dre)
 
 --
 map(0,16,0,0)
 depth=1
 foreach(ents,dre)
 
 -- game over
 if gmo then
  c=gmo/16
  ray=c*c*128
  circ(hero.x+4,hero.y+4,ray,7)
 end
 
 -- inter
 y=0
 if hero.cst then
  y=hero.cst 
 end
 camera(0,y)
 pal()
 for i=0,1 do
  camera(i,y+i)
  pal()
  if i==0 then apal(2) end
  sspr(16,3,4,5,3,2)
  print(flags,9,2,7)
  tpx=110
  if hero.churt then
   tpx+=(t%2)*2-1
  end
  --if count>0 and count<90 	and count%30 >20 then
  -- tpx+=(t%2)*2-1
  --end
  str=""..max(flr(count/30,0)+1,0)
  if #str<=1 then str="0"..str end
  sspr(20,3,4,5,tpx,2)
  print(str,tpx+6,2,count<90 and 8+6*(t%2) or 7)
 
  -- unlock
  if power<4 then
   rectfill(48,2,80,6,7)
   rectfill(49,3,79,5,2)
   c=(flags-rr)/(paliers[power+1]-rr)
   rectfill(49,3,49+30*c,5,8)
   str=powers_str[power+1]
   print(str,65-#str*2,9,7)
  end
  
 end
 camera()

 
 
 
 -- ocean
 for x=0,127 do

  first=2
		by=gwy(x)
  for y=by,128 do
   pix=pget(x,y)
   if first>0 then
    for i=1,first do
     pix=sget(48+pix,1)
    end
    first-=1
   end
   pset(x,y,sget(48+pix,2))
  end
 end
 
 --
 depth=3
 foreach(ents,dre) 
 
 --dx=cmx%16
 --for i=0,18 do
 -- fr=112+(t/2)%6
 -- flp=i%2==1
 -- if (t/2)%12 < 7 then flp = not flp end
 -- spr(f0r,i*8-dx,120,1,1,flp)
 --end 
 
end

function _draw()
 cls()



 
 if dr then dr() end
 
 -- log
 color(7)
 cursor(0,8)
 for n in all(logs) do
  print(n)
 end
 
end

function apal(n)
 for i=0,15 do pal(i,n) end
end

function log(n) 
 add(logs,n)
 if #logs>18 then
  del(logs,logs[1])
 end
end

powers_str={
 "speed up",
 "bomb jump",
 "xtra time",
 "shield"
}
flaws_str={
 "island extention",
 "flying drunkard",
 "razor discs",
 "double-sided canons",
 "carefree pangolins",
 "armoured beetles",
 "starving piranhas",
 "weak bridges",
 "rusty platforms",
 "high tides",
 "mischevious shark",
 "potatoes spitter",
 "time costing bomb",
 "todo",
 "todo",
}

