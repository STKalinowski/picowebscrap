--dominion ex 2
--extar 2019, 2020, 2021

version="1.11"

function init_variables()

	has_collected_coin=false
	has_visited_hangar=false

	menu_cursor_y=85

	boss_population=0
	coins={}
	coin_accumulator=0
	--container for weapon cooldowns
	
	cooldown_machinegun=0
	cooldown_machinegun_cooldown=2
	cooldown_missile=0
	cooldown_missile_cooldown=25
	cooldown_weaponswitch=0
	cooldown_weaponswitch_cooldown=10
	
	cur_function='select_start'
	cur_menu_a=1
	cur_upg=1
	cur_upg_cost=5
	difficulty='easy'
	enemies={}
	--level 1 enemy population
	enemy_population=100
	enemy_projectiles={}
	enemies_on_screen=0
	exhausts={}
	explodes={}
	explosions={}
	game_state='splash_screen'
	hangar_c='select upgrade'
	heatbartime=0
	level_state=0
	mapscroll=-384
	max_enemies_on_screen=5
		
	projectiles={}
	pl_trail={}
	
	player_sp=1
	player_x=64
	player_y=96
	player_c1=12
	player_coins=10
	player_currentweap=1
	--player_exc=14
	--player_exdmg=2
	player_ext=30
	player_ftl_charge=0
	player_ftl_max=30
	player_ftl_spd=0
	player_heat=0
	player_heatlock=false
	--player_hei=1
	player_invincibility=0
	player_lives_max=6
	player_lives=6
	player_missile_damage=20
	player_missile_exdmg=4.5
	player_missile_ext=18
	player_machinegun_damage=3
	player_plasma_damage=12
	--plasma wobble effect
	player_plasmax=-3
	player_plasmaxn=1
	player_reactor_cooling=21
	player_reactor_max=100
	player_reactor_status="core temp"
	player_show_coins=0
	player_size=1
	player_speed=1
	player_weapon='missile'
	--player_wid=1
		
	score=0
		
	stars={}
	
	upg_repair_cost=5
	upg_repair_value=1
	upg_lives_max_cost=5
	upg_lives_max_value=1
	upg_cooling_cost=5
	upg_cooling_value=1
	upg_reactor_cost=5
	upg_reactor_value=10
	upg_speed_cost=5
	upg_speed_value=0.25
	upg_machinegun_damage_cost=5
	upg_machinegun_damage_value=1
	upg_missile_ext_cost=5
	upg_missile_ext_value=1
	upg_plasma_damage_cost=5
	upg_plasma_damage_value=1
	upg_ftl_max_cost=5
	upg_ftl_max_value=-3
	upg_ftl_max_num=0
	upg_ftl_max_max=5
		
	game_time=0

	--bugfix 04/03/2020
	you_win_music=nil
	
end

function _init()
	init_variables()
	high_score=0
end

-->8
--function setup
--animates the ships engines

function delete_entities()
	for e in all (enemies) do
		del (enemies, e)
		if e.type=='boss' then
			boss_population-=1
		else
			enemy_population+=1
		end
	end
	enemy_projectiles={}
	projectiles={}
	exhausts={}
	explodes={}
	explosions={}
	pl_trail={}
end

function sprite_highlight(_colour,_spn,_spx,_spy,_spw,_swh,noclear)
	for i=1,15 do
		pal(i,_colour)
	end
	for xh=-1,1 do
		for yh=-1,1 do
			spr(_spn,_spx+xh,_spy+yh,_spw or 1,_swh or 1)
		end
	end
	--if noclear=='noclear' then
		--pal()
	--end
end

function randint(_num)
	return flr(rnd(_num))
end

function animate_sprites()
	if btn(0) or btn(1) or btn(2) or btn(3) then
		if game_time%2==0 then
			player_sp+=16
		end
		if player_sp>17 then
			player_sp=1
		end
		player_heat+=2
		
		
		--player ship exhaust
		create_player_exhaust()		
	else
		player_sp=1
	end
	for p in all(projectiles) do
		if p.name=='missile' then
			p.sp+=16
			if p.sp>18 then
				p.sp=2
			end
		end
	end
end

--enemies bounce off the screen side
function side_bounce()
	for e in all (enemies) do
		if e.x>128-(e.w*4) then
			e.lr=0-e.movespeed
		end
		if e.x<0-(e.w*4) then
			e.lr=e.movespeed
		end
	end
end

function centre_print(_string,_y,_c)
	print(_string,64-#_string*2,_y,_c)
end

--change current active weapon
function changeweapon()
 if cooldown_weaponswitch<game_time then
 	player_currentweap+=1
 	sfx(13)
 	if player_currentweap>4 then
 		player_currentweap=1
 	end
 	if player_currentweap==1 then
		player_weapon='missile'
		player_c2=8
	elseif player_currentweap==2 then
		player_weapon='machinegun'
		player_c2=10
	elseif player_currentweap==3 then
		player_weapon='plasma'
		player_c2=13
	elseif player_currentweap==4 then
		player_weapon='ftl'
		player_c2=2
	end
	cooldown_weaponswitch=game_time+cooldown_weaponswitch_cooldown
	end
end

function clear_trails()
	for trail in all(pl_trail) do
		del(pl_trail,trail)
	end
end

function coin_chance(cx,cy,cc)
	local coin_roll=rnd(99)
	if coin_roll<(cc or 0)+coin_accumulator then
		local coin={
			x=cx,
			y=cy
		}
		--consider just making this a simple rnd(20)>19 if too many lives are given out with high max lives and low lives
		if player_lives<player_lives_max then
			if difficulty=='easy' then
				if rnd(14+player_lives_max)>14+player_lives then
					coin.special='lifeup'
				end
			else
				if rnd(20)>19 then
					coin.special='lifeup'
				end
			end
		end
		add (coins,coin)
		coin_accumulator=0
	else 
		coin_accumulator+=coin_roll
	end
end

function collide(ax,ay,apxwid,bx,by,bhei,bwid)
	local pix=apxwid/2
	if ax+4>bx-pix and ax+4<bx+(bwid*8)+pix and ay+4>by-pix and ay+4<by+(bhei*8)+pix then
		return true
	end
end

--used for explosion/radius-based collision
--pythagoras' theorem ftw
function pythagoras(ax,bx,ay,by,r)
	return sqrt((ax-bx)^2+(ay-by)^2)<r
end

--collision detection. damage and keeping player on screen.
function collision()
	--keeps player on screen unless player is going to game over
	if game_over_wait==nil then
		if player_x<0 then player_x=0 end
		if player_y<0 then player_y=0 end
		if player_x>120 then player_x=120 end
		if player_y>120 then player_y=120 end
	end
	--player collision with coins
	for coin in all(coins) do
		if collide(coin.x,coin.y,4,player_x,player_y,player_size,player_size) then
			if coin.special=='lifeup' then
				player_lives+=1
				sfx(25)
			else
				player_coins+=1
				score+=player_coins
				player_show_coins=game_time
				sfx(4)
			end
			has_collected_coin=true
			del (coins,coin)
		end
	end

	--player collision
	if game_time>player_invincibility then
		
		for ep in all(enemy_projectiles) do
			if collide(ep.x,ep.y,4,player_x,player_y,player_size,player_size) then
				kill_player()
				del(enemy_projectiles,ep)
			end
		end
		--player collision with bomber explosions
		for ex in all(explosions) do
			--pythagoras theorem ftw.
			--bomber explosion can kill the player
			--if sqrt(((player_x-ex.x)^2)+((player_y-ex.y)^2))-6<ex.r and ex.name=='bomber' then
			if pythagoras(player_x+4,ex.x,player_y+4,ex.y,ex.r) and ex.name=='bomber' then
				ex.name='hit'
				kill_player()
			end
		end
	end
	
	--collision detection for enemies
	for e in all(enemies) do
		
		if collide(player_x,player_y,8,e.x,e.y,e.h,e.w) and game_time>player_invincibility then	
			kill_player()
		end
		--enemy collision with player projectiles
		for p in all(projectiles) do
			local process_damage=0
			if collide(p.x,p.y,2,e.x,e.y,e.h,e.w) then
				process_damage=1
			end
			
			--projectile collision detection for multi-sprite-width enemies
			if p.x>e.x and p.x<(e.x+e.w*8) and p.y>e.y and p.y<(e.y+e.h*8) then
				process_damage=1
			end
			if process_damage==1 then	
				if p.name=='missile' then
						create_explosion(p.x+4,p.y+4,p.exc,30)
						explode(p.x,p.y,p.ext,p.exc,p.exdmg,p.name)
						sfx(7)
					end
				if e.immune==p.name then
					sfx(5)
					e.draw_immune=true
				else
					e.hp-=p.damage
					e.flash=1	
				end
				if p.name=='missile' or p.name=='plasma' then
					create_explosion(p.x+4,p.y+4,p.exc,7)
				end
				del (projectiles,p)
			end
		end
		--enemy collision detection with explosions
		for ex in all(explosions) do
			--pythagoras theorem ftw.
			if e.name=='mega_purps' and pythagoras(e.x+16,ex.x,e.y+8,ex.y,ex.r) then
				do_hit=true
			elseif pythagoras(e.x+e.w*4,ex.x,e.y+e.h*4,ex.y,ex.r) then
				do_hit=true
			end
			if do_hit==true then
				if e.name=='res' or e.name=='comans' and ex.name=='missile' then
					sfx(5)
					e.draw_immune=true
				else
					e.hp-=ex.damage
					e.flash=1
				end
				do_hit=false
			end
			
		end
		--kill enemies
		if e.hp<=0 then
			if e.name!='grees_child' then
				coin_chance(e.x,e.y,e.coin_chance)
				enemies_on_screen-=1
			end
			if e.type=='boss' then
				boss_population-=1
			end
			score+=e.points
			sfx(3)
			if e.w==4 then
				for i=1,8 do
					explode(e.x+rnd(32),e.y+rnd(32),e.ext,e.exc,4,e.name)
				end
			else
				explode(e.x+e.w*4,e.y+e.h*4,e.w*6,e.exc,1,e.name)
			end
			
			create_explosion(e.x+e.w*4,e.y+e.h*4,e.exc,20)
			
			del (enemies,e)
		end
	end
	
	--enemy projectiles collision detection with death nova explosions
	for ep in all(enemy_projectiles) do
		for ex in all(explosions) do
			if pythagoras(ep.x+4,ex.x,ep.y+4,ex.y,ex.r) and ex.name=='player' then
				del (enemy_projectiles,ep)
			end
		end
	end
end

function cool_print(_string,_x,_y,_c)
	for x=-1,1 do
		for y=-1,1 do
			print(_string,_x+x,_y+y,0)
		end
	end
	print(_string,_x,_y,_c)
end

function upg_update(upg_cost)
	player_coins-=upg_cost
	sfx(8)
end
	
function do_upg(cur_upg)
	if cur_upg==1 then
		if player_lives>=player_lives_max and player_coins>=upg_lives_max_cost then
			player_lives_max+=upg_lives_max_value
			player_lives+=1
			player_coins-=upg_lives_max_cost
			upg_lives_max_cost+=1
			sfx(8)
			cur_upg_cost=upg_lives_max_cost
		elseif player_lives<player_lives_max and player_coins>=upg_repair_cost then
			player_lives+=upg_repair_value
			player_coins-=upg_repair_cost
			sfx(8)
			cur_upg_cost=upg_repair_cost
		else
			sfx(9)
		end
	elseif cur_upg==2 then 
		if player_coins>=upg_speed_cost then
			player_speed+=upg_speed_value
			upg_update(upg_speed_cost)
			upg_speed_cost+=1
		else
			sfx(9)
		end
	elseif cur_upg==3 then
		if player_coins>=upg_cooling_cost then
			player_reactor_cooling+=upg_cooling_value
			upg_update(upg_cooling_cost)
			upg_cooling_cost+=1
		else
			sfx(9)
		end
	elseif cur_upg==4 then
		if player_coins>=upg_reactor_cost then
			player_reactor_max+=upg_reactor_value
			player_ext+=3
			upg_update(upg_reactor_cost)
			upg_reactor_cost+=1
		else
			sfx(9)
		end
	elseif cur_upg==5 then
		if player_coins>=upg_missile_ext_cost then
			player_missile_ext+=upg_missile_ext_value
			upg_update(upg_missile_ext_cost)
			upg_missile_ext_cost+=1
		else
			sfx(9)
		end
	elseif cur_upg==6 then
		if player_coins>=upg_machinegun_damage_cost then
			player_machinegun_damage+=upg_machinegun_damage_value
			upg_update(upg_machinegun_damage_cost)
			upg_machinegun_damage_cost+=1
		else
			sfx(9)
		end
	elseif cur_upg==7 then
		if player_coins>=upg_plasma_damage_cost then
			player_plasma_damage+=upg_plasma_damage_value
			upg_update(upg_plasma_damage_cost)
			upg_plasma_damage_cost+=1
		else
			sfx(9)
		end
	elseif cur_upg==8 then 
		if player_coins>=upg_ftl_max_cost and upg_ftl_max_num<upg_ftl_max_max then
			player_ftl_max+=upg_ftl_max_value
			upg_update(upg_ftl_max_cost)
			upg_ftl_max_cost+=1
			upg_ftl_max_num+=1
		else
			sfx(9)
		end
	end
end

--lr is orans projectiles
--plr is for yels projectiles
function enemy_fire(x,y,name,_c,lr,plr)
	ep={
		x=x,
		y=y,
		name=name,
		c=_c
	}
	if name=='grees' then
		ep.sp=5
		ep.dy=1
		
		sfx(12)
		add(enemy_projectiles,ep)
	elseif name=='purps' then
		ep.sp=6
		ep.dy=2

		sfx(16)
		add(enemy_projectiles,ep)
	--if statement for super_purps firing
	elseif name=='super_purps' then
		if game_time%120<90 then
			ep.sp=6
			ep.dy=2
			ep.x=x+4
			ep.y=y+4
			sfx(16)
			add(enemy_projectiles,ep)
		end
	--if statement for orans firing
	elseif name=='orans' or name=='super_orans' then
		--left firing projectile
		ep.sp=7
		ep.lr=-0.6
		ep.dy=2
		ep.x=x
		ep.y=y
		ep.lr=lr
		
		ep2=ep
		
		add(enemy_projectiles,ep)
		
		sfx(15)
		
	--if statement for mega_purps firing
	elseif name=='mega_purps' then
		if game_time%120<75 then
			ep.sp=25
			ep.x=x+24
			ep.y=y+15
			ep.dy=2
			sfx(19)
			add(enemy_projectiles,ep)
		end
	--if statement for yels firing
	elseif name=='yels' then
		ep.sp=22
		ep.x=x+4
		ep.y=y+4
		ep.lr=0
		ep.plr=plr
		ep.dy=0
		sfx(14)
		add(enemy_projectiles,ep)
	
	--if statement for azurs firing
	elseif name=='azurs' then
		ep.sp=20
		ep.x=x+4
		ep.y=y+4
		ep.dy=2

		sfx(21)
		add(enemy_projectiles,ep)
	
	--if statement for bomber firing
	elseif name=='bomber' then
		ep.sp=23
		ep.x=x+4
		ep.y=y+4
		ep.age=game_time
		ep.dy=0.5

		sfx(24)
		add(enemy_projectiles,ep)
	
	--super_grees doesn't fire projectiles so has no entry here
	elseif name=='grees_child' then
		ep.sp=5
		ep.dy=1
		
		sfx(12)
		add(enemy_projectiles,ep)
	
	--if statement for comans firing
	elseif name=='comans_mis' then
		if game_time%120<90 then
			ep.sp=50
			ep.lr=rnd(1)-0.5
			ep.dy=1.5
			
			sfx(20)
			add(enemy_projectiles,ep)
		end
	
	elseif name=='comans_las' then
		if game_time%120<90 then
			ep.sp=8
			ep.dy=3.5
			
			sfx(19)
			add(enemy_projectiles,ep)
		end
	
	elseif name=='masts_las' then
		if game_time%160<120 then
			ep.sp=8
			ep.dy=3.5
			
			sfx(19)
			add(enemy_projectiles,ep)
		end
	elseif name=='masts_lasran' then
		if game_time%160>150 then
			ep.sp=8
			ep.dy=3.5
			ep.ran=rnd(2)-1
			
			sfx(19)
			add(enemy_projectiles,ep)
		end
	end
end

--adds enemies to the screen
function enemy_manager()
	--level 1 enemy sequence
	if enemy_population>0 and level_state==0 and enemies_on_screen<max_enemies_on_screen then
		if game_time%61==0 and enemy_population>20 then
			--debug test crap
			--add_enemy('brain')
			add_enemy('grees')
		end
		if game_time%127==0 and enemy_population<75 then
			add_enemy('purps')
		end
		if game_time%241==0 and enemy_population<15 then
			add_enemy('orans')
		end
		if game_time%401==0 and enemy_population<33 then
			add_enemy('res')
		end
	end
	
	--level 1 boss
	if game_state=='main' and enemy_population<1 and enemies_on_screen<1 and level_state==0 then
		add_enemy('super_purps',64,-32,'boss')
		add_enemy('yels',0,-32,'boss')
		add_enemy('yels',108,-32,'boss')
		level_state=1
		music(19)
	end
	if boss_population<1 and level_state==1 then
		level_state=2
		hard_difficulty_bonus()
	end
	--level 2 enemy sequence
	if level_state==3 and enemy_population>0 and enemies_on_screen<max_enemies_on_screen then
		if game_time%61==0 and enemy_population>20 then
			add_enemy('grees')
		end
		if game_time%83==0 and enemy_population<90 then
			add_enemy('purps')
		end
		if game_time%353==0 and enemy_population>50 and enemy_population<80 then
			add_enemy('orans')
		end

		if game_time%409==0 and enemy_population<50 and enemy_population>25 then
			add_enemy('azurs')
		end
		if game_time%257==0 and enemy_population<30 and enemy_population>10 then
			if rnd(2)<1 then
				add_enemy('res')
			else
				add_enemy('yels')
			end
		end
		if game_time%509==0 and enemy_population<20 and enemy_population>10 then
			add_enemy('super_purps')
		end
	end

	--level 2 boss
	if enemy_population<1 and enemies_on_screen<1 and game_state=='main' and level_state==3 then
		add_enemy('comans',64,-32,'boss')
		add_enemy('super_grees',0,-16,'boss')
		add_enemy('super_grees',112,-16,'boss')
		level_state=4
		music(19)
	end
	if boss_population<1 and level_state==4 then
		level_state=5
		hard_difficulty_bonus()
	end

	--level 3 enemy sequence
	if level_state==6 and enemy_population>0 and enemies_on_screen<max_enemies_on_screen then
		if game_time%127==0 and enemy_population>20 and enemies_on_screen<max_enemies_on_screen-2 then
			add_enemy('grees',16,nil,group)
			add_enemy('grees',112,nil,group)
		end
		if game_time%151==0 and enemy_population<90 then
			add_enemy('purps')
		end
		if game_time%257==0 and enemy_population<80 and enemy_population>10 then
			if rnd(2)<1 then
				add_enemy('super_orans')
			else
				add_enemy('yels')
			end
		end
		if game_time%307==0 and enemy_population<70 and enemy_population>30 then
			if rnd(2)<1 then
				add_enemy('azurs')
			else
				add_enemy('bomber')
			end
			
		end
		if game_time%409==0 and enemy_population<60 and enemy_population>15 then
			add_enemy('super_grees')
		end
		if game_time%409==0 and enemy_population<20 then
			if rnd(2)<1 then			
				add_enemy('brain')
			else
				add_enemy('super_purps')
			end
		end
		if game_time%521==0 and enemy_population<10 then
			add_enemy('mega_purps')
		end
	end
	
	--level 3 boss
	if enemy_population<1 and enemies_on_screen<1 and game_state=='main' and level_state==6 then
		add_enemy('masts', 64, nil, 'boss')
		level_state=7
		music(19)
	end
	if boss_population<1 and level_state==7 then
		level_state=8
		hard_difficulty_bonus()
	end
	if level_state==7 and game_time%90==0 and enemies_on_screen<max_enemies_on_screen then
		max_enemies_on_screen=4
		if rnd(2)<1 then
			add_enemy('grees')
		else
			add_enemy('purps')
		end
	end

end

function enemy_into_table(_e)
	if _e.name!='grees_child' then
		enemy_population-=1
		enemies_on_screen+=1
	end
	add (enemies,_e)
end

--x and y co-ordinates only used when enemies should be spawned in a specific place, e.g. bosses
function add_enemy(name, specific_x, specific_y, type)
	--green enemy
	--advances slowly, slowly fires slow shots. slow.
	if name=='grees' then
		local e={
			sp=33,
			x=randint(120),
			y=-8,
			name='grees',
			age=game_time,
			coin_chance=10,
			exc=11,
			firspd=120,
			firstp=120,
			hp=10,
			lr=0,
			movespeed=0.5,
			points=5,
			target_y=randint(64)+32,
			h=1,
			w=1
		}
		enemy_into_table(e)
--		add (enemies,e)
--		enemy_population-=1
--		enemies_on_screen+=1
	end
	--purple enemy
	if name=='purps' then
		local e={
			sp=34,
			x=randint(120),
			y=-8,
			name='purps',
			coin_chance=20,
			exc=2,
			firspd=45,
			firstp=45,
			hp=20,
			lr=0,
			movespeed=0.5,
			points=15,
			h=1,
			w=1,
			target_y=randint(32)+32,
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--orange enemy
	if name=='orans' then
		local e={
			sp=35,
			x=randint(120),
			y=-8,
			name='orans',
			coin_chance=30,
			exc=9,
			firspd=60,
			firstp=60,
			hp=30,
			lr=0,
			movespeed=1,
			points=25,
			h=1,
			w=1,
			target_y=randint(64)
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--red enemy
	--hangs back and tries to charge player immune to missiles.
	if name=='res' then
		local e={
			sp=36,
			x=randint(112),
			y=-16,
			name='res',
			charging=0,
			coin_chance=40,
			exc=8,
			hp=60,
			immune='missile',
			lr=0,
			movespeed=0.5,
			points=50,
			h=2,
			w=2,
			target_y=randint(16)+32
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--super purple enemy
	--hangs back and fires long salvoes
	if name=='super_purps' then
		local e={
			sp=44,
			x=randint(112),
			y=-16,
			name='super_purps',
			age=game_time,
			coin_chance=50,
			exc=2,
			firspd=5,
			firstp=5,
			hp=480,
			lr=0,
			movespeed=0.5,
			points=250,
			h=2,
			w=2,
			target_y=randint(32)+32
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--yellow enemy
	--fires sideways, immune to mgun
	if name=='yels' then
		local e={
			sp=38,
			x=randint(112),
			y=-16,
			name='yels',
			age=game_time,
			coin_chance=40,
			exc=10,
			firspd=45,
			firstp=45,
			hp=180,
			immune='machinegun',
			lr=0,
			movespeed=1.5,
			plr=1,
			points=50,
			h=2,
			w=2
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--azurs squid enemy	
	if name=='azurs' then
		local e={
			sp=40,
			x=randint(112),
			y=-16,
			name='azurs',
			coin_chance=40,
			exc=1,
			firspd=60,
			firstp=60,
			hp=120,
			lr=0,
			movespeed=1,
			points=60,
			h=2,
			w=2,
			target_y=randint(16)
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--super grees enemy
	--hangs back and spawns grees children
	if name=='super_grees' then
		local e={
			sp=42,
			x=randint(112),
			y=-16,
			name='super_grees',
			age=game_time,
			coin_chance=40,
			exc=11,
			firspd=30,
			firstp=30,
			hp=360,
			lr=0,
			movespeed=0.5,
			points=100,
			h=2,
			w=2,
			target_y=randint(32)+8,
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--green child enemy
	if name=='grees_child' then
		local e={
			sp=49,
			x=randint(120),
			y=-8,
			name='grees_child',
			age=game_time,
			exc=11,
			firspd=130,
			firstp=130,
			hp=10,
			lr=0,
			movespeed=0.5,
			points=1,
			h=1,
			w=1,
			target_y=randint(56)+40
		}
		enemy_into_table(e)
--		add (enemies,e)
	end
	--bomber
	--drops special bombs, teleports from bottom of screen to top
	if name=='bomber' then
		local e={
			sp=10,
			x=randint(112),
			y=-16,
			name='bomber',
			coin_chance=20,
			exc=3,
			firspd=40,
			firstp=40,
			hp=120,
			lr=0,
			movespeed=1.5,
			points=75,
			h=2,
			w=2
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--red boss enemy
	--hangs back and fires long salvoes
	if name=='comans' then
		local e={
			sp=136,
			x=randint(96),
			y=-32,
			name='comans',
			age=game_time,
			exc=8,
			ext=96,
			firepoint=1,
			firspd=7,
			firstp=7,
			hp=1000,
			immune='missile',
			lr=0,
			movespeed=0.5,
			points=1000,
			h=4,
			w=4,
			target_y=8,
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--brain enemy	
	if name=='brain' then
		local e={
			sp=12,
			x=randint(112),
			y=-16,
			name='brain',
			coin_chance=10,
			exc=14,
			firspd=14,
			firstp=14,
			hp=200,
			immune='plasma',
			lr=0,
			movespeed=0.5,
			points=80,
			h=2,
			w=2,
			target_y=16
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--purple end boss enemy
	--twin plasma bastard
	if name=='masts' then
		local e={
			sp=140,
			x=64,
			y=-32,
			name='masts',
			age=game_time,
			exc=13,
			ext=192,
			firepoint=1,
			firspd=6,
			firstp=6,
			hp=1500,
			immune='plasma',
			lr=0,
			movespeed=0.5,
			points=2500,
			h=4,
			w=4,
			target_y=8
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--super orange enemy
	if name=='super_orans' then
		local e={
			sp=46,
			x=randint(112),
			y=-16,
			name='super_orans',
			coin_chance=100,
			exc=9,
			firspd=10,
			firstp=10,
			hp=120,
			lr=0,
			movespeed=1,
			points=85,
			h=2,
			w=2,
			target_y=randint(64)
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	--mega purple enemy
	--hangs back and fires long salvoes
	if name=='mega_purps' then
		local e={
			sp=200,
			x=randint(96),
			y=-16,
			name='mega_purps',
			coin_chance=50,
			exc=2,
			firspd=1,
			firstp=1,
			hp=480,
			lr=0,
			movespeed=0.5,
			points=275,
			h=2,
			w=4,
			target_y=randint(32)+32
		}
		enemy_into_table(e)
--		enemy_population-=1
--		enemies_on_screen+=1
--		add (enemies,e)
	end
	
	for e in all (enemies) do
		if e.age==game_time and e.unique==nil then
			if specific_x!=nil then
				e.x=specific_x
				e.unique=1
			end
			if specific_y!=nil then
				e.y=specific_y
				e.unique=1
			end
			if type!=nil then
				e.type=type
				e.unique=1
			end
			if e.type=='boss' then
				boss_population+=1
			end
		end
	end
end

--draws explosions
-- t - explosion time
-- c - explosion colour
function explode(x, y, t, c, damage, name)
	local ex={
		x=x,
		y=y,
		r=4,
		t=(t or 0)+rnd(4),
		c=c or 1,
		damage=damage,
		name=name
	}
	add(explosions,ex)
end

function fire(weapon)
	if player_heatlock==false then
		if weapon=='missile' and cooldown_missile<game_time then
			local p={
				name='missile',
				sp=2,
				x=player_x,
				y=player_y,
				damage=player_missile_damage,
				ext=player_missile_ext,
				exc=8,
				exdmg=player_missile_exdmg
				}
			player_heat+=6
			add (projectiles,p)
			sfx(1)
			cooldown_missile=game_time+cooldown_missile_cooldown
		end
		if weapon=='machinegun' and cooldown_machinegun<game_time then
			local p={
				name='machinegun',
				sp=3,
				x=player_x,
				y=player_y,
				drift=1-(rnd(20)/10),
				damage=player_machinegun_damage
			}
			player_heat+=3
			add (projectiles,p)
			sfx(0)
			cooldown_machinegun=game_time+cooldown_machinegun_cooldown
		end
		if weapon=='plasma' then
			local p={
				name='plasma',
				sp=4,
				exc=12,
				x=player_x+player_plasmax,
				y=player_y,
				damage=player_plasma_damage
			}
			player_plasmax=player_plasmax+player_plasmaxn
			if player_plasmax==3 then
				player_plasmaxn=-1
			elseif player_plasmax==-3 then
				player_plasmaxn=1
			end
			player_heat+=5
			add (projectiles,p)
			sfx(2)
		end
		if weapon=='ftl' then
			player_ftl_charge+=1
			--cheats
			--player_lives+=1
			--player_coins+=10
			player_heat+=4
			if player_ftl_charge==player_ftl_max then
				hangar_c='select upgrade'
				time_since_ftl=game_time+30
				sfx(10)
				cur_upg=9
				--resets boss if not killed outright
				if level_state==1 then
					level_state=0
				end
				if level_state==4 then
					level_state=3
				end
				if level_state==7 then
					level_state=6
				end
				leave_main_screen()
				music(17)
				game_state='hangar'
				if level_state==2 then
					level_state=3
					enemy_population=100
					mapscroll=-384
					for s in all(stars) do
						del (stars, s)
					end
				end
				if level_state==5 then
					level_state=6
					enemy_population=100
					mapscroll=-384
				end
				if level_state==8 then
					game_state='you_win'
				end
			end
		end
	end
end

--damage flicker effect
function flash()
	for i=1,15 do
		pal(i,7)
	end
end

function hard_difficulty_bonus()
	if difficulty=='hard' then
		score=flr(score*1.5)
	end
end


function kill_player()

	player_lives-=1
	player_invincibility=game_time+90
	sfx(6)
	explode(player_x,player_y,player_ext,14,2,'player')

end

--takes player away from the main screen but doesn't reset the level
function leave_main_screen()
	player_x=0
	player_y=112
	delete_entities()
--	for p in all (projectiles) do
--		del (projectiles, p)
--	end
	-- for e in all (enemies) do
		-- del (enemies, e)
		-- if e.type=='boss' then
			-- boss_population-=1
		-- else
			-- enemy_population+=1
		-- end
	-- end
--	for ep in all(enemy_projectiles) do
--		del (enemy_projectiles,ep)
--	end
	-- enemy_projectiles={}
	-- projectiles={}
	-- exhausts={}
	-- explodes={}
	-- explosions={}
	-- pl_trail={}
	--clear_trails()
	--resets the boss if not killed outright
	if level_state==1 then
		level_state=0
	end
	if level_state==4 then
		level_state=3
	end
	if level_state==7 then
		level_state=6
	end
	player_ftl_charge=0
	player_heat=0
	enemies_on_screen=0
	music(-1)
end

function player_trail(px,py)
	local trail={
		x=px,
		y=py,
		age=game_time
	}
	add (pl_trail,trail)
	for trail in all(pl_trail) do
		if game_time-trail.age>12 then
			del (pl_trail,trail)
		end
	end	
end

function reset()
	init_variables()
	for p in all (projectiles) do
		del (projectiles, p)
	end
	for e in all (enemies) do
		del (enemies, e)
	end
	delete_entities()
	--clear_trails()
end


--star field effect
function starfield(col1,col2)

	local s={
		x=rnd(128),
		y=0,
		col=7,
		speed=(rnd(9)+1)/10
		}
	
	if game_time%5==0 then
	
		add (stars,s)
	
	end
	
	for s in all(stars) do
		circ(s.x,s.y,0,s.col)
		s.y+=s.speed
		if 0.4<s.speed and s.speed<0.7 then
			s.col=col2
		elseif s.speed<0.4 then
			s.col=col1
		end
	end
	
end

function toggle_difficulty()

	if difficulty=='hard' then
		difficulty='easy'
		max_enemies_on_screen=5
		player_lives_max=6
		player_lives=6
		player_coins=10
		player_missile_exdmg=4.5
		player_missile_ext=18
		player_machinegun_damage=3
		player_plasma_damage=12
	elseif difficulty=='easy' then
		difficulty='hard'
		max_enemies_on_screen=10
		player_lives_max=3
		player_lives=3
		player_coins=0
		player_missile_exdmg=3
		player_missile_ext=12
		player_machinegun_damage=2
		player_plasma_damage=8
	end

end

function toggle_upg(direction)

	if direction==1 then
		cur_upg+=1
	else
		cur_upg-=1
	end
	if cur_upg>9 then
		cur_upg=1
	end
	if cur_upg<1 then
		cur_upg=9
	end
	if cur_upg==1 then
		if player_lives>=player_lives_max then
			hangar_c='upgrade hull'
			cur_upg_cost=upg_lives_max_cost
		else
			hangar_c='repair ship'
			cur_upg_cost=upg_repair_cost
		end
	elseif cur_upg==2 then
		hangar_c='upgrade ship engines'
		cur_upg_cost=upg_speed_cost
	elseif cur_upg==3 then
		hangar_c='upgrade cooling'
		cur_upg_cost=upg_cooling_cost
	elseif cur_upg==4 then
		hangar_c='upgrade reactor'
		cur_upg_cost=upg_reactor_cost
	elseif cur_upg==5 then
		hangar_c='upgrade missile yield'
		cur_upg_cost=upg_missile_ext_cost
	elseif cur_upg==6 then
		hangar_c='upgrade vulcan cannon'
		cur_upg_cost=upg_machinegun_damage_cost
	elseif cur_upg==7 then
		hangar_c='upgrade plasma'
		cur_upg_cost=upg_plasma_damage_cost
	elseif cur_upg==8 then
		hangar_c='upgrade ftl'
		cur_upg_cost=upg_ftl_max_cost
	elseif cur_upg==9 then
		hangar_c='leave hangar'
	end
end
-->8
--update section
function _update()

	game_time=(game_time+1)%32000
	
	if game_time%4==0 then
	
		player_trail(player_x,player_y)

	end
	
	if score>high_score then
		high_score=score
	end
		
	if game_state=='main' then
					
		if player_heat>0 then
			player_heat-=player_reactor_cooling/10
		elseif player_heat<0 then
			player_heat=0
		end
		
		--heatlock
		
		if player_heat>player_reactor_max then
			player_heatlock=true
			player_heat=player_reactor_max
			player_reactor_status=" overheat"
		end
		
		if player_heat<player_reactor_max/2 and player_heatlock==true then
			player_heatlock=false
			player_reactor_status="core temp"
		end
		
		--overheat klaxon
		if player_heatlock==true then
			if stat(19)!=26 then
				sfx(26,3)
			end
			player_c1=9	
			create_player_exhaust()	
		else
			sfx(-2,3)
			player_c1=12
		end
		
		--ftl update stuff
		if (player_ftl_charge>0 and player_weapon!='ftl') or player_ftl_charge<0 then
		
			player_ftl_charge=0
			
		end
		
		if not btn(4) and game_time%2==0 then
			
			player_ftl_charge-=1
			
		end
		
		--ship controls
		if player_lives>0 then
			if player_weapon=='ftl' then
				sfx(11,-1,player_ftl_charge,1)
				player_ftl_spd=1
			else
				player_ftl_spd=0
			end
	
			if btn(0) then player_x-=player_speed+player_ftl_spd end
			if btn(1) then player_x+=player_speed+player_ftl_spd end
			if btn(2) then player_y-=player_speed+player_ftl_spd end
			if btn(3) then player_y+=player_speed+player_ftl_spd end
			
			if btn(4) then fire(player_weapon) end
			if btnp(5) then changeweapon() end
		else
			if game_over_wait==nil then
				--player level bounding in collision is switched off by this too
				game_over_wait=game_time+90
				player_x=-8
				player_y=-8
			end
			if game_time>game_over_wait then
				game_state='game_over'
				game_over_wait=nil
				--dramatic_music=nil
			end
		end
		enemy_manager()
		collision()
		animate_sprites()
		
		update_particles()
	end
	
	for coin in all(coins) do
	
		if coin.y<128 then
		
			coin.y+=0.5
			
		else
		
			del (coins,coin)
			
		end
	
	end
	
	--projectiles update stuff
	for p in all (projectiles) do
		
		if p.name=='missile' then
		
			p.y-=5
			
			create_exhaust(p.x+4,p.y+4,8,12)
			
		elseif p.name=='machinegun' then
		
			p.y-=7
			
			p.x+=p.drift
			
		elseif p.name=='plasma' then
		
			p.y-=5
			
			create_exhaust(p.x+4,p.y+4,13,12,0,1)
			
		end

		if p.y>136 or p.y<-8 or p.x>136 or p.x<-8 then
		
			del(projectiles,p)	
		
		end
		
	end
	
	--enemy projectiles update stuff
	
	for ep in all(enemy_projectiles) do
		if ep.name=='grees' or 'grees_child' then
			en_pr_ex_spd=-0.5
		else
			en_pr_ex_spd=0
		end
		if ep.name=='yels' or ep.name=='mega_purps' then
		
		else
			create_exhaust(ep.x+4,ep.y+4,ep.c,ep.c,en_pr_ex_spd,1)
		end	
		--enemy projectile flipping animation
		if game_time%2==0 then
			ep.x_flip=true
		else
			ep.x_flip=false
		end
		
		ep.y+=ep.dy
		
		if ep.name=='orans' or ep.name=='super_orans' then
			ep.x+=ep.lr
		end
		--yels projectiles go sideways
		if ep.name=='yels' then
			ep.x+=ep.plr
		end
		if ep.name=='azurs' then
			if ep.y<96 then
				if player_x<ep.x then
					ep.x-=0.5
				else
					ep.x+=0.5
				end
			end
		end
		if ep.name=='comans_mis' then
			ep.x+=ep.lr
		end
		if ep.name=='masts_lasran' then
			ep.x+=ep.ran
		end
		--deletes off-screen projectiles
		if ep.y>128 or ep.y<0 or ep.x<0 or ep.x>128 and ep.name!='bomber' then
			del(enemy_projectiles,ep)
		end
		--bomber bombs explode
		if ep.name=='bomber' and game_time-ep.age>30 then
			del(enemy_projectiles,ep)
			explode(ep.x,ep.y, 24, 11, 1, 'bomber')
		end
	end
	--enemy behaviour
	for e in all(enemies) do
		--res movement behaviour
		if e.name=='res' then
			if e.lr==0 then
				if player_x<64 then
					e.lr=e.movespeed
				else
					e.lr=0-e.movespeed
				end
			end
			if e.x>128-(e.w*8) then
				e.lr=0-e.movespeed
			end
			if e.x<0 then
				e.lr=e.movespeed
			end
			if e.y<e.target_y and e.charging==0 then
				e.y+=e.movespeed
			end
			if e.charging==0 and e.y==e.target_y then
				e.x+=e.lr
			end
			if e.y==e.target_y and abs(e.x-player_x)<6 then
				e.charging=1
				sfx(23)
			end
			if e.y<=128-(e.h*8) and e.charging==1 then 
				e.y+=3
			end
			if e.y>128-(e.h*8) and e.charging==1 then
				e.charging=2
			end
			if e.charging==2 and e.y>e.target_y then
				e.y-=0.5
			end
			if e.charging==2 and e.y==e.target_y then
				e.charging=0
			end
		--end

		--yels movement/firing behaviour
		elseif e.name=='yels' then
 
			e.y+=e.movespeed
			
			e.firstp-=1
			
			if e.y>116 then
			
				e.movespeed=-1
				
			end
			
			if e.y<0 then
			
				e.movespeed=1
				
			end
			
			--yels only fires when it's lined up with the player
			if abs(e.y+8-player_y)<2 and e.firstp<1 then
				if player_x>e.x then
					e.plr=1.5
				else
					e.plr=-1.5
				end
				enemy_fire(e.x,e.y,e.name,e.exc,e.lr,e.plr)
				e.firstp=e.firspd
			end
		--end
		
		--standard movement/firing for other enemies
			
		elseif e.name=='grees' or e.name=='purps' or e.name=='orans' or e.name=='super_purps' or e.name=='azurs' or e.name=='super_grees' or e.name=='grees_child' or e.name=='comans' or e.name=='brain' or e.name=='masts' or e.name=='super_orans' or e.name=='mega_purps' then 
			if e.lr==0 then
				if e.x<player_x then
					e.lr=e.movespeed
				else
					e.lr=0-e.movespeed
				end
			end
			--enemies reach target y coord then move side to side.
			side_bounce()
			if e.y<e.target_y then
				e.y+=e.movespeed
			--then they move side-to-side			
			else
				e.x+=e.lr
			end
			--enemy firing countdown.
			if e.firspd>0 then
				e.firstp-=1
				--only yels uses plr
				if e.firstp<1 then
					--red boss fire sequence
					if e.name=='comans' then
						e.firepoint+=1
						if e.firepoint==3 then
							e.firepoint=1
						end
						if e.firepoint==1 then
							enemy_fire(e.x+4,e.y+24,'comans_mis',e.exc,lr,plr)
						else
							enemy_fire(e.x+28,e.y+24,'comans_mis',e.expx,lr,plr)
						end
						if player_x>e.x and player_x<e.x+32 then
							enemy_fire(e.x+12,e.y,'comans_las',e.exc)
						end
					--end
					elseif e.name=='orans' or e.name=='super_orans' then
						enemy_fire(e.x,e.y,e.name,e.exc,-0.4)
						enemy_fire(e.x,e.y,e.name,e.exc,0.4)
					--purple end boss fire sequence
					elseif e.name=='masts' then
						enemy_fire(e.x,e.y+24,'masts_las',e.exc)
						enemy_fire(e.x+24,e.y+24,'masts_las',e.exc)
						for i = 1,8 do
							enemy_fire(e.x+16,e.y+16,'masts_lasran',e.exc)
						end
					--end
					--brain fire sequence
					elseif e.name=='brain' then
						if player_x>e.x-8 and player_x<e.x+24 then
							enemy_fire(e.x+4,e.y,'comans_las',e.exc)
						end
					--end
					--super_grees don't fire projectiles, but spawn grees_childs
					elseif e.name=='super_grees' and (e.age+game_time)%150<90 and e.y==e.target_y then
						add_enemy('grees_child', e.x, e.y, 'grees_child')
						sfx(22)
					else
						enemy_fire(e.x,e.y,e.name,e.exc,e.lr,e.plr)
					end
					e.firstp=e.firspd
				end
			end
			if e.name=='orans' and abs(e.x-player_x)<6 then
				e.firstp-=2
			end
		--end
		--grees child movement/firing behavior
		elseif e.name=='grees_child' then
			if game_time-e.age>300 then
				e.y+=2
				if player_x<e.x then
					e.x-=0.5
				else
					e.x+=0.5
				end
			end	
			if e.y>128 then
				del (enemies,e)
			end
			if level_state==5 then
				del (enemies,e)
				explode(e.x+e.w*4,e.y+e.h*4,e.w*6,e.exc,1,e.name)
				sfx(3)
			end
		--end
		--movement and firing for bomber	
		elseif e.name=='bomber' then 
			if e.lr==0 then
				if e.x<player_x then
					e.lr=1
				else
					e.lr=-1
				end
			end
			--bomber always moves side to side.
			side_bounce()

			e.y+=e.movespeed
			
			if e.y>128 then
			
				e.y=-64
				
			end

			e.x+=e.lr/4
			
			if e.firspd>0 then
		
				e.firstp-=1
			
				if e.firstp<1 then
				
					enemy_fire(e.x,e.y,e.name,e.exc,lr,plr)
					e.firstp=e.firspd	
					
				end
			end
		end
	end
	
	for ex in all(explosions) do
		ex.r+=1
		ex.t-=1
		if ex.t<0 then
			del (explosions,ex)
		end
		if ex.name=='player' then
			ex.r+=1
		end
	end
	
	if level_state<3 then
		starfield(1,13)
	elseif level_state<6 then
		starfield(4,9)
	else
		starfield(3,11)
	end
end

-->8
--draw section
function _draw()
	cls()

	--splash screen
	if game_state=='splash_screen' then
		splash()
		if game_time>59 or (btn()>0 and btn()<16) then
			game_state='title_screen'
		end
	end
	if game_state=='title_screen' then
		title()
	end
	if game_state=='hangar' then
		hangar()
	end
	if game_state=='game_over' then
		game_over()
	end
	if game_state=='you_win' then
		you_win()
	end
	if game_state=='main' then
		for s in all(stars) do
			circ(s.x,s.y,s.speed,s.col)
		end
		--map scrolls based on enemy population
		if level_state>2 then
			if enemy_population*3<abs(mapscroll) and game_time%10==0 and mapscroll<0 then
				mapscroll+=1
			end
			if level_state>2 and level_state<6 then
				pal(1,2)
				pal(3,4)
				pal(9,2)
				pal(10,8)
				map(0,0,0,mapscroll,16,64)
				pal()
			end
			if level_state>5 then
				if level_state>6 then
					pal(1,2)
					pal(3,8)
					pal(9,14)
					pal(10,15)
				end
				map(16,0,0,mapscroll,16,64)	
				pal()
			end
		end
		for ex in all(explosions) do
			
			circ(ex.x, ex.y, ex.r, ex.c)
		end

		if player_weapon=='ftl' then
			for trail in all(pl_trail) do
				if game_time%4<2 then
					spr(16, trail.x, trail.y)
				end
			end
		end
		--particles
		
		draw_particles()
		
		
		--draw player
		pal()
		if player_lives>0 and game_time<player_invincibility then
			if game_time%2==0 then
				spr(player_sp, player_x, player_y)
			end
		else
			spr(player_sp, player_x, player_y)
		end
		--ftl charge effect
		if player_ftl_charge>0 and game_time%2==0 then
			circ(player_x+4,player_y+4,player_ftl_charge*0.7,2)
			circ(player_x+4,player_y+4,player_ftl_charge*0.5,14)
			circ(player_x+4,player_y+4,player_ftl_charge*0.3,15)
		end
		for p in all(projectiles) do
			
			spr(p.sp, p.x, p.y)
		end
		for coin in all(coins) do
			if game_time%30<6 then
				sprite_highlight(7,9,coin.x,coin.y)
			end
			if coin.special=='lifeup' then
				if game_time%30<15 then
					pal(10,8)
					pal(9,2)
					pal(7,14)
				else
					pal(10,14)
					pal(9,8)
					pal(7,7)
				end
			else
				pal()
			end
			--tutorial
			if has_collected_coin==false then
				print("collect",min(100,coin.x+7),coin.y,9)
			end
			spr(9,coin.x,coin.y)
			--pal()
		end
		--draw enemy projectiles
		for ep in all(enemy_projectiles) do
			if ep.name=='comans_las' or ep.name=='masts_las' or ep.name=='masts_lasran' then
				spr(ep.sp, ep.x, ep.y, 1, 2, ep.x_flip)
			else
				spr(ep.sp, ep.x, ep.y, 1, 1, ep.x_flip)
			end
		end
		for e in all(enemies) do
			
			if e.draw_immune==true then
				-- for i=1,15 do
					-- pal(i,12)
				-- end
				
				-- for x=-1,1 do
					-- for y=-1,1 do
						-- spr(e.sp,e.x+x,e.y+y,e.w,e.h)
					-- end
				-- end
				sprite_highlight(12,e.sp,e.x,e.y,e.w,e.h)
				e.draw_immune=false
			end
			pal()
			if e.flash==1 then
				flash()
				e.flash=0
			end
			if e.name=='masts' and game_time%160>120 and game_time%4<3 then
				pal(3,8)
				pal(11,14)
			end
			if e.name=='masts' and e.hp<500 and game_time%4<3 then
				pal(13,6)
				pal(2,5)
			end
			spr(e.sp,e.x,e.y,e.w,e.h)
		end
		pal()
		--player ui section
		if player_coins>0 and game_time-player_show_coins<60 then
			spr(9,112,0)
			print(player_coins,121,1,10)
		end
		if player_heat>1 then
			heatbartime=game_time+15
		end
		
		--player_heat=min(player_heat,player_reactor_max)
		
		if player_heat>=player_reactor_cooling or game_time<heatbartime then
			rect(125,125-(player_reactor_max/2),127,127,1)
			if player_heat<player_reactor_max*0.8 then
				line(126,flr(126-(player_heat/2)),126,126,10)
			-- elseif player_heat>player_reactor_max*0.8 and player_heat<player_reactor_max then
				-- line(126,flr(126-(player_heat/2)),126,126,8)
			else
				line(126,126-min(player_heat/2,player_reactor_max/2),126,126,8)
				line(126,126-player_reactor_max/2*0.8,126,126,10)
			end
			if player_heatlock==true then
				heatlockcolour=(game_time%2)+8
				rect(125,125-(player_reactor_max/2),127,127,heatlockcolour)
			else
				heatlockcolour=1
			end
			print(player_reactor_status,89,123,heatlockcolour)
		end
		--ftl display
		if player_lives>0 then
			if player_ftl_charge>0 then
				rectfill(122,120-player_ftl_charge,122,120,14)
			end
			if player_weapon=='ftl' then
				rect(121,121-player_ftl_max,123,121,2)
				print("drive",101,117,2)
			end
			
		end
		cool_print('score: '..score,0,0,0)
		print('score: '..score,0,0,10)
		
		--tutorial
		if score<10 then
			print("🅾️/z shoot\n❎/x change weapon\n⬆️⬇️⬅️➡️ move",1,109,9)
		else
			if player_weapon=='ftl' and has_visited_hangar==false then
				print("charge ftl to warp to\nupgrade hangar",1,115,9)
			end
		end
		--current weapon hud
	
		if player_weapon=='missile' then
			hud_weapon_sprite=2
		elseif player_weapon=='machinegun' then
			hud_weapon_sprite=3
		elseif player_weapon=='plasma' then
			hud_weapon_sprite=4
		elseif player_weapon=='ftl' then
			hud_weapon_sprite=32
		end
		
		rectfill(0,6,7,13,1)
		
--		for i=0,15 do
--			pal(i,0)
--		end
--		for x=-1,1 do
--			for y=-1,1 do
--				spr(hud_weapon_sprite,0+x,6+y)
--			end
--		end
--		pal()
		
		spr(hud_weapon_sprite,0,6)
		
		rectfill(0,15,7,22,1)
		
		-- for i=0,15 do
			-- pal(i,0)
		-- end
		-- for x=-1,1 do
			-- for y=-1,1 do
				-- spr(16,0+x,15+y)
			-- end
		-- end
		-- pal()
		
		spr(16,0,15)
		print(player_lives,3,17,7)
		
		if enemy_population>97 then
			print("sector "..level_state/3+1,48,48,10)
			if level_state==0 then
				print("outer solar system",28,54,7)
			elseif level_state==3 then
				print("asteroid base",38,54,7)
			elseif level_state==6 then
				print("dyson sphere",40,54,7)
			end
		end
		
		clear_messages={}
		if level_state==2 then
			clear_messages={'sector 1 clear','use ftl to leave area'}
		end
		if level_state==5 then
			clear_messages={'sector 2 clear','use ftl to leave area'}
		end
		if level_state==8 then
			clear_messages={'sector 3 clear','ex-tar is defeated','use ftl to return to earth'}
		end
		
		for i=1,#clear_messages do
			if i==1 then
				clear_line_colour=10
			else
				clear_line_colour=7
			end
			centre_print(clear_messages[i],42+i*6,clear_line_colour)
		end
	end
	
	--debug stuff
end
-->8
--particles

function create_exhaust(x,y,c1,c2,speed,number)
	for i=1,number or 3 do
		local exhaust={
			x=x,
			y=y,
			c=c1,
			c1=c1,
			c2=c2,
			age=ceil(rnd(10))+5,
			speed=speed or 0
			}

		add(exhausts,exhaust)
	end
end

function create_player_exhaust()
	create_exhaust(player_x+2+ceil(rnd(2)),player_y+6,player_c1,player_c2,player_speed)
end

function create_explosion(x,y,c1,size)
	for i=1,size or 10 do
		local explode={
			x=x,
			y=y,
			c=c1,
			age=ceil(rnd(20))+10,
			dx=1-rnd(2),
			dy=1-rnd(2),
		}
		add(explodes,explode)
	end
end

function update_particles()
	for exhaust in all (exhausts) do
		exhaust.y+=1+exhaust.speed
		exhaust.x+=0.6-rnd(1.2)
		exhaust.age-=1
		if exhaust.age%3==0 then
			exhaust.c=exhaust.c2
		else
			exhaust.c=exhaust.c1
		end
		if exhaust.age<0 then
			del(exhausts,exhaust)
		end
	end
	
	for explode in all (explodes) do
		explode.x+=explode.dx
		explode.y+=explode.dy
		explode.age-=1
		if explode.age<0 then
			del(explodes,explode)
		end
	end
end

function draw_particles()
	for exhaust in all (exhausts) do
		pset(exhaust.x,exhaust.y,exhaust.c)
	end
	for explode in all (explodes) do
		pset(explode.x,explode.y,explode.c)
	end
end
-->8
--screens
function game_over()

	enemies={}
	enemy_projectiles={}

	starfield(1,13)
	spr(44,56,8,2,2)
	for i=1,5 do
		spr(34,24+(i*12),24)
	end
	for i=1,7 do
		spr(33,12+(i*12),32)
	end
	dramatic_music=nil
	if game_over_music==nil then
		music(18)
		game_over_music=1
	end
	cursor(22,48,7)
	print('game over\n')
	color(6)
	print('with our last ship\ndestroyed there is\nnothing to stop ex-tar\nfrom galactic tyranny.\n\nyour score: '..score..'\nhigh score: '..high_score)
	color(7)
	print('\npress 🅾️+❎ to restart')
	if btnp(🅾️) and btn(❎) then
		reset()
		game_time=0
		game_state='splash_screen'
		game_over_music=nil
	end
end

function hangar()
	
	has_visited_hangar=true
	
	pal(4,1)
	pal(15,4)
	pal(9,13)
	pal(10,12)
	pal(3,9)
	pal(11,10)
	
	map(112,48,0,0,16,16)
	
	pal()
	
	hangar_a='⬆️⬇️: select system'
	hangar_b='🅾️: upgrade system'
	hangar_d='upgrade cost: '
		
	rectfill(15,64,113,116,1)
	rect(15,64,113,116,5)
	rectfill(0,121,36,128,1)
	rectfill(1,1,66,55,5)
	rectfill(2,2,5,54,1)
	
	print('ship hull\nship engines\nreactor cooling\nreactor output\nmissile yield\nvulcan cannon\nplasma\nftl charge\nleave hangar',7,2,7)
	
	spr(9,0,(cur_upg*6)-5)
		
	if cur_upg==1 then
		if player_lives>=player_lives_max then
			cur_upg_tex1='ship strength: '..player_lives..'/'..player_lives_max
			cur_upg_tex2='increase by '..upg_lives_max_value
			cur_upg_cost=upg_lives_max_cost
		else
			cur_upg_tex1='ship strength: '..player_lives..'/'..player_lives_max
			cur_upg_tex2='repair by '..upg_repair_value
			cur_upg_cost=upg_repair_cost
		end
	elseif cur_upg==2 then
		cur_upg_tex1='ship speed: '..player_speed*100
		cur_upg_tex2='improve by '..upg_speed_value*100
		cur_upg_cost=upg_speed_cost
	elseif cur_upg==3 then
		cur_upg_tex1='cooling rate: '..player_reactor_cooling.."gw"
		cur_upg_tex2='improve by '..upg_cooling_value.."gw"
		cur_upg_cost=upg_cooling_cost
	elseif cur_upg==4 then
		cur_upg_tex1='reactor output: '..(player_reactor_max*8)..'gw'
		cur_upg_tex2='improve by '..(upg_reactor_value*8)..'gw'
		cur_upg_cost=upg_reactor_cost
	elseif cur_upg==5 then
		cur_upg_tex1='missile yield: '..player_missile_ext..'mt'
		cur_upg_tex2='improve by '..upg_missile_ext_value..'mt'
		cur_upg_cost=upg_missile_ext_cost
	elseif cur_upg==6 then
		cur_upg_tex1='vulcan damage: '..player_machinegun_damage
		cur_upg_tex2='improve by '..upg_machinegun_damage_value
		cur_upg_cost=upg_machinegun_damage_cost
	elseif cur_upg==7 then
		cur_upg_tex1='plasma power: '..(player_plasma_damage*5)..'gw'	cur_upg_tex2='improve by '..(upg_plasma_damage_value*5)..'gw'
		cur_upg_cost=upg_plasma_damage_cost
	elseif cur_upg==8 then
		cur_upg_tex1='ftl charge rate: '..player_ftl_max
		cur_upg_tex2='improve by '..upg_ftl_max_value
		cur_upg_cost=upg_ftl_max_cost
	elseif cur_upg==9 then
		cur_upg_tex1=''
		cur_upg_tex2=''
		cur_upg_cost=''
	end
	
	print(cur_upg_tex1,17,66,6)
	print(cur_upg_tex2,17,72,6)
	
	centre_print(hangar_a,84,7)
	centre_print(hangar_b,90,6)
	centre_print(hangar_c,102,7)
	centre_print(hangar_d..cur_upg_cost,110,7)
	print('coins: '..player_coins,1,122,10)
	
	if btnp(2) then
	
		toggle_upg(-1)
		sfx(18)
		
	end
	
	if btnp(3) then
	
		toggle_upg(1)
		sfx(18)
		
	end
	
	if game_time>time_since_ftl then
		if btnp(4) then
			if cur_upg<9 then
				do_upg(cur_upg)
			--returns player to game. leave hangar
			elseif cur_upg==9 then
				game_state='main'
				--clear_trails()
				delete_entities()
				player_x=64
				player_y=96
				if mapscroll<-384 then
					mapscroll=-384
				end
				if level_state==0 then
					music(8)
				elseif level_state==3 then
					music(41)
				elseif level_state==6 then
					music(29)
				end
			end
		end
	end
end

function splash() --draw
	if splash_music==nil then
		music(0)
		splash_music=1
	end
	rect(51, 56, 73, 81, 4)
	rectfill(52, 55, 74, 79, 5)
	rect(52, 55, 74, 80, 9)
	spr(14, 55, 56, 2, 2)
	print('extar', 53, 74, 4)
	print('extar', 54, 73, 9)
end

function title() --draw

	--title splash graphics
	if view_story==1 then
		for i=1,7 do
			pal(i,0)
		end
		for i=8,15 do
			pal(i,1)
		end
	end
	sspr(0,32,64,32,0,16,128,64)
	pal()
	
	print("start game\ndifficulty:"..difficulty.."\nview story",32,86,7)
	
	print("⬆️⬇️ select option\n🅾️ or ❎ to select",32,110,1)
	
	print("V"..version,0,122,1)
	
	if game_time%20<10 then
		spr(9,24,menu_cursor_y)
	end
	
	if btnp(⬆️) then
		view_story=0
		menu_cursor_y-=6
		if menu_cursor_y<85 then
			menu_cursor_y=97
		end
	end
	if btnp(⬇️) then
		view_story=0
		menu_cursor_y+=6
		if menu_cursor_y>97 then
			menu_cursor_y=85
		end
	end
	
	if btnp()>0 then
		sfx(18)
	end
	
	if view_story==1 then
			
		--rectfill(3,3,127,45,5)
		--rectfill(2,2,126,44,1)
		
		if story_screen==1 then
			cool_print('our fleet has been destroyed \nby the extarians.\nall that remains is the\nprototype ship: red venom\nyou are our best pilot. you\nmust defeat ex-tar',3,19,7)
			cool_print('for great justice!',3,59,8)
		elseif story_screen==2 then
			cool_print('ship name: red venom',3,19,8)
			cool_print('reactor: twin super-cold-fusion\npower output: 800gw (estimated)\nmain weapon: atomic missile\nsecondary: vulcan cannon\nspecial: multi-phase plasma\nftl drive: experimental',3,34,7)
		end
		cool_print(story_screen.."/2",3,77,6)	
	end
	
	if btnp(🅾️) or btnp(❎) then
	
		if menu_cursor_y==85 then
		
			game_state='main'
			music(8)
			splash_music=nil
			cooldown_missile=game_time+cooldown_missile_cooldown
		
		elseif menu_cursor_y==91 then
		
			toggle_difficulty()
			
		elseif menu_cursor_y==97 then
			
			if view_story==0 then
				story_screen=0
			end
			view_story=1
			story_screen+=1
			
			if story_screen>2 then
				story_screen=1
			end
			
		end
	
	end
	
	if btnp(⬆️) or btnp(⬇️) then
		
		view_story=0
		story_screen=0
		
	end

end


function you_win()

	starfield(1,13)
	
	spr(44,24,4,2,2)
	spr(140,48,4,4,4)
	spr(44,88,4,2,2)
	
	if you_win_music==nil then
	
		music(23)
		you_win_music=1
	
	end

	you_win_1='victory!'
	
	centre_print(you_win_1,38,7)
	cursor(0,50,7)
	color(6)
	print('with the evil mastermind\ndefeated, the remnants of the\nalien fleet scatter.\nearth is saved.\nfor now...\n')
	color(10)
	print('your score: '..score..'\nhigh score: '..high_score)
	color(7)
	print('\npress 🅾️ or ❎ to restart')
	
	if btnp(5) or btnp(4) then
	
		game_time=0
		game_state='splash_screen'
		game_over_music=nil
		init_variables()
		
	end
	
end
