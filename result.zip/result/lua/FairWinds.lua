--FAIR WINDS
--A Sailing Adventure!

--Trinagle drawing improved from: http://www.lexaloffle.com/bbs/?tid=2734
function lerp(a, b, alpha)
	return a*(1 - alpha) + b*alpha
end

function clip(v)
	return max(-1, min(128, v))
end

function clamp(x, mn, mx)
	return max(mn, min(x, mx))
end

function dtri(x1, y1, x2, y2, x3, y3, c)
	if y2 < y1 then
		if y3 < y2 then
			x1, x3 = x3, x1
			y1, y3 = y3, y1
		else
			x1, x2 = x2, x1
			y1, y2 = y2, y1
		end
	elseif y3 < y1 then
		x1, x3 = x3, x1
		y1, y3 = y3, y1
	end

	y1 += shr(1, 15)
	local d12, d13 = y2 - y1, y3 - y1
	if d12 ~= 0 then d12 = 1.0/d12 end
	if d13 ~= 0 then d13 = 1.0/d13 end

	local miny = min(y2, y3)
	local maxy = max(y2, y3)
	local cl_y1 = clip(y1)
	local cl_miny = clip(miny)
	local cl_maxy = clip(maxy)

	for y = cl_y1, cl_miny do
		local sx = lerp(x1, x3, (y - y1)*d13)
		local ex = lerp(x1, x2, (y - y1)*d12)
		rectfill(sx, y, ex, y, c)
	end
	
	local df = maxy - miny
	if df ~= 0 then df = 1.0/df end

	local fx = (y2 < y3 and x3 or x2)
	local dmin = miny - y1
	local sx = lerp(x1, x3, dmin*d13)
	local ex = lerp(x1, x2, dmin*d12)
	for y = cl_miny, cl_maxy do
		local alpha = (y - miny)*df
		local sx2 = sx + (fx - sx)*alpha
		local ex2 = ex + (fx - ex)*alpha
		rectfill(sx2, y, ex2, y, c)
	end
end

function trs(tx, ty, angle, sx, sy)
	rx, ry = cos(angle), -sin(angle)
	return {rx, ry, -ry, rx, tx, ty}
end

function transform_mult(t1, t2)
	return {
		t1[1]*t2[1] + t1[3]*t2[2],
		t1[2]*t2[1] + t1[4]*t2[2],
		t1[1]*t2[3] + t1[3]*t2[4],
		t1[2]*t2[3] + t1[4]*t2[4],
		t1[1]*t2[5] + t1[3]*t2[6] + t1[5],
		t1[2]*t2[5] + t1[4]*t2[6] + t1[6],
	}
end

function transform_inv(t)
  local inv_det = 1/(t[1]*t[4] - t[3]*t[2])
  return {
		 t[4]*inv_det, -t[2]*inv_det,
		-t[3]*inv_det,  t[1]*inv_det,
		(t[3]*t[6] - t[5]*t[4])*inv_det,
		(t[5]*t[2] - t[1]*t[6])*inv_det,
  }
end

function transform_v(m, x, y)
	return m[1]*x + m[3]*y, m[2]*x + m[4]*y
end

function transform_p(m, x, y)
	return m[1]*x + m[3]*y + m[5], m[2]*x + m[4]*y + m[6]
end

ticks = 0

wind_dir = {x = 2, y = 0}
winds = {}
waves = {}
wakes = {}

mastx = 6

wayx, wayy = 0, 0
wayr = 20
waypoints = {
	{x =  83*8 + 4, y = 29*8 + 4},
	{x =  82*8 + 4, y = 10*8 + 4},
	{x = 114*8 + 4, y = 12*8 + 4},
	{x = 115*8 + 4, y = 53*8 + 4},
	{x =  95*8 + 4, y = 51*8 + 4},
	{x =  83*8 + 4, y = 29*8 + 4},
	{x =  68*8 + 4, y = 52*8 + 4},
	{x =  30*8 + 4, y = 53*8 + 4},
	{x =  28*8 + 4, y = 32*8 + 4},
	{x =   9*8 + 4, y = 31*8 + 4},
	{x =  14*8 + 4, y = 10*8 + 4},
	{x =  54*8 + 4, y = 19*8 + 4},
	{x =  62*8 + 4, y = 34*8 + 4},
	{x =  12*8 + 4, y = 32*8 + 4},
	{x =  11*8 + 4, y = 55*8 + 4},
	{x =  73*8 + 4, y = 49*8 + 4},
	{x =  45*8 + 4, y = 13*8 + 4},
	{x =  82*8 + 4, y = 10*8 + 4},
	{x = 105*8 + 4, y = 45*8 + 4},
}

function pop_waypoint()
	local wayp = waypoints[1]
	del(waypoints, wayp)
	
	if wayp then
		return wayp.x, wayp.y
	else
		finish = ticks
	end
end

function _init()
	for i = 1, 16 do
		add(winds, {x = rnd(128), y = rnd(128)})
		add(waves, {x = rnd(128), y = rnd(128)})
	end
	
	boat = {
		alive = true,
		m = {1, 0, 0, 1, 105*8 + 4, 45*8 + 4},
		mast_m = trs(mastx, 0, 0, 1, 1),
		rotation = 0.25,
		boom = 0.25,
		limit = 0.25,
		draw_limit = false,
		vel = {x = 0, y = 0},
	}
	
	wayx, wayy = pop_waypoint()
	speed = 0
end

function _update()
	if boat.alive then
		local m = boat.m
		local mast = transform_mult(m, boat.mast_m)
		local vx, vy = boat.vel.x, boat.vel.y
		
		local vrx = wind_dir.x - vx
		local vry = wind_dir.y - vy
		
		local fn = mast[3]*vrx + mast[4]*vry
		local wind_drag = 0.06
		local fx, fy = mast[3]*fn + wind_drag*wind_dir.x, mast[4]*fn + wind_drag*wind_dir.y
		local drag = 0.995
		local mass = 10
		vx = drag*vx + fx/mass
		vy = drag*vy + fy/mass
		
		local keel_drag = 0.6*(m[3]*vx + m[4]*vy)
		vx -= keel_drag*m[3]
		vy -= keel_drag*m[4]
		
		boat.vel.x = vx
		boat.vel.y = vy
		speed = 30*sqrt(vx*vx + vy*vy)
		
		local tiller = (btn(0, 0) and -1 or 0) + (btn(1, 0) and 1 or 0)
		boat.rotation += tiller*(speed + 20)/5000
		
		local sail = (btn(4, 0) and -1 or 0) + (btn(5, 0) and 1 or 0)
		boat.limit = clamp(boat.limit + 0.006*sail, 0.01, 0.25)
		boat.draw_limit = (sail ~= 0)
		
		local x = boat.m[5] + vx
		local y = boat.m[6] + vy
		boat.m = trs(x, y, boat.rotation, 1, 1)
		
		local btorque = wind_dir.x*mast[3] + wind_dir.y*mast[4]
		boat.boom = clamp(boat.boom - 0.1*btorque, -boat.limit, boat.limit)
		boat.mast_m = trs(mastx, 0, boat.boom, 1, 1)
		
		if wayx then
			local dx, dy = (x - wayx)/wayr, (y - wayy)/wayr
			if boat.alive and dx*dx + dy*dy < 1 then
				wayx, wayy = pop_waypoint()
			end
		end
		
		if mget(x/8, y/8) ~= 0 then
			boat.alive = false
		end
	end
	
	if ticks%3 == 0 then
		local wx, wy = transform_p(boat.m, -10, 0)
		local wdx, wdy = transform_v(boat.m, 0, 1)
		
		if speed > 15 then
			add(wakes, {x = wx, y = wy, dx = wdx, dy = wdy})
		else
			add(wakes, {x = 1000, y = 1000, dx = 0, dy = 0})
		end
		
		if #wakes > 15 then
			del(wakes, wakes[1])
		end
	end
	
	ticks += 1
end

black = 0
navy = 1
maroon = 2
dgreen = 3
brown = 4
dgrey = 5
lgrey = 6
white = 7
red = 8
orange = 9
yellow = 10
lgreen = 11
blue = 12
purple = 13
peach = 15

function draw_wind(tx, ty)
	local count = #winds
	local gust = 0.3
	
	for i = 1, #winds do
		local phase = 0.01*ticks + i/count
		
		local dx = wind_dir.x + gust*sin(phase)
		local dy = wind_dir.y + gust*sin(0.6*phase + 0.5)
		
		local wind = winds[i]
		wind.x = (wind.x + dx)%128
		wind.y = (wind.y + dy)%128
		
		pset((wind.x + tx)%128, (wind.y + ty)%128, lgrey)
	end
end

function draw_waves(tx, ty)
	local count = #waves
	local duration = count*3
	
	for i = 1, count do
		local phase = (ticks/2 + i)/count%1
		
		local wave = waves[i]
		spr(flr(6*phase), (wave.x + tx)%128, (wave.y + ty)%128)
		
		if phase == 0 then
			wave.x, wave.y = rnd(128), rnd(128)
		end
	end
end

function draw_boat(view)
	local m = transform_mult(view, boat.m)
	local x1, y1 = transform_p(m, -10, -4)
	local x2, y2 = transform_p(m,   8, -4)
	local x3, y3 = transform_p(m,   8,  4)
	local x4, y4 = transform_p(m, -10,  4)
	local x5, y5 = transform_p(m,  12,  0)
	dtri(x1, y1, x2, y2, x3, y3, brown)
	dtri(x1, y1, x3, y3, x4, y4, brown)
	dtri(x2, y2, x3, y3, x5, y5, brown)
	
	local d1x, d1y = transform_p(m, -7, -2)
	local d2x, d2y = transform_p(m,  4, -2)
	local d3x, d3y = transform_p(m,  4,  2)
	local d4x, d4y = transform_p(m, -7,  2)
	local d5x, d5y = transform_p(m,  7,  0)
	dtri(d1x, d1y, d2x, d2y, d3x, d3y, peach)
	dtri(d1x, d1y, d3x, d3y, d4x, d4y, peach)
	dtri(d2x, d2y, d3x, d3y, d5x, d5y, peach)
	
	local mast = transform_mult(m, boat.mast_m)
	local sdir = wind_dir.x*mast[3] + wind_dir.y*mast[4]
	local luff = 5*clamp(2*sdir + 0.5*sin(ticks/5), -1, 1)
	
	local mx, my = transform_p(mast, 0, 0)
	
	if boat.draw_limit and ticks%2 == 0 then
		local m1 = transform_mult(m, trs(mastx, 0,  boat.limit, 1, 1))
		local m2 = transform_mult(m, trs(mastx, 0, -boat.limit, 1, 1))
		local lx1, ly1 = transform_p(m1, -16, 0)
		local lx2, ly2 = transform_p(m2, -16, 0)
		line(mx, my, lx1, ly1, red)
		line(mx, my, lx2, ly2, red)
	end
	
	
	local sx1, sy1 = transform_p(mast, -15, 0)
	local sx2, sy2 = transform_p(mast, -13, luff)
	dtri(mx, my, sx1, sy1, sx2, sy2, white)
	
	local mx2, my2 = transform_p(mast, -16, 0)
	line(mx, my, mx2, my2, dgrey)
end

function draw_wakes(tx, ty)
	local count = #wakes
	for i = 1, count do
		local wake = wakes[i]
		local x, y = wake.x + tx - 2, wake.y + ty - 6
		local t = 3 + 0.5*(count - i)
		local dx, dy = wake.dx*t, wake.dy*t
		local sn = 1 + min((count - i)/1.75, 4)
		spr(sn, x + dx, y + dy)
		spr(sn, x - dx, y - dy)
	end
end

function draw_waypoint(tx, ty)
	if not wayx then return end
	
	local x, y = wayx + tx, wayy + ty
	local sx, sy = x - 64, y - 64
	local div = max(abs(sx), abs(sy))
	if div > 64 then
		circ(64/div*sx + 64, 64/div*sy + 64, 2, red)
	end
	
	circ(x, y, wayr + 5*sin(ticks/60), red)
end

function draw_text(dx, dy, c)
	color(c)
	camera(dx, dy)
	
	print("speed: "..flr(speed).." knots", 16, 3)
	
	if finish then
		print("finished: "..(finish/30).." s", 32, 110)
	else
		print("time: "..flr(ticks/30).." s", 16, 11)
	end
end

function _draw()
	debug_str = ""
	cls()
	rectfill(0, 0, 128, 128, blue)
	
	local m = boat.m
	local tx = -clamp(m[5] - 64, 0, 1023 - 128)
	local ty = -clamp(m[6] - 64, 0,  511 - 128)
 	local view = {1, 0, 0, 1, tx, ty}
 	
	draw_wakes(tx, ty)
	draw_waves(tx, ty)
	
	map(0, 0, tx, ty, 128, 64)
	
	draw_waypoint(tx, ty)
	
	if boat.alive then
		draw_boat(view)
	else
		spr(10, m[5] + tx - 8, m[6] + ty - 8, 2, 2)
	end
	
	
	draw_wind(tx, ty)
	
	draw_text(0, 0, black)
	draw_text(1, 1, white)
	
	color(red)
	print(debug_str)
end
