--           lemonhunter
--  the quest for the golden lemon
--------------------------------

--[[ license stuff
lemonhunter is released under cc4-by-nc-sa license
https://creativecommons.org/licenses/by-nc-sa/4.0/
you are free to release remixes or use parts of the code for your own non-commercial projects

death, tree and big mushroom based on art by sebastiaan van hijfte
http://i.imgur.com/rfkvq.png cc by-nc 3.0

background music by gruber
https://www.lexaloffle.com/bbs/?pid=38442#p38440
space: 14
sand: 10
village: 19
pastoral: 24
]]

-- to switch between throwing bombs and just laying them down search for
-- 'throw bomb' (line 1142)

-- objects
base_hitbox={xoffset=0,yoffset=0,w=8,h=8}
object = {
  sprite=1,
  x=0,
  y=0,
  dx=0,
  dy=0,
  life=1,
  bounciness=.5,
  lastgrounded=0,
  hitbox=base_hitbox,
  type="unset",
  bounce=true,

  move=function(self)
    move(self,false,self.bounce)
    self.dx*=.975
    if abs(self.dx)<.3 then self.dx=0 end
  end,
  damage=function(self,n)
    self.life-=n
  end,
  die=function(self)
    del(objects,self)
  end,
  draw=function(self)
    spr(self.sprite,self.x,self.y,1,1,self.flip)
  end,
}

function object:new(o)
	--o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

bomb = object:new({
  sprite=33,
  type="bomb",
  --hitbox={xoffset=0,yoffset=2,w=5,h=6},
  dmg=3,
  radius=15,
  thrown=true,
})

red_bomb = bomb:new({
  sprite=34,
  dmg=5,
  radius=23,
})

box = object:new({
  sprite=117,
  pushable=true,
  solid=true,
  bounciness=.1,
  hitbox={xoffset=1,yoffset=2,w=6,h=6},
  damage=function(self,n,type)
    if type=="bomb" then
      del(objects,self)
      spawn_powerup(self.x,self.y)
    end
  end,
})

door = object:new({
  sprite=116,
  type="door",
})

item_plant = object:new({
  sprite=118,
  type="chest",
  damage=function(self,n)
    if n>=2 then
      del(objects,self)
      blood_anim(self.x,self.y,true)
      spawn_powerup(self.x,self.y)
    end
  end,
})

powerup = object:new({
  type="powerup",
})

gold_powerup = powerup:new({
  sprite=36,
  action="score",
  value="50",
  --hitbox={xoffset=1,yoffset=4,w=4,h=4}
})

health_powerup = powerup:new({
  sprite=32,
  value=1,
  action="health",
})

bomb_powerup = powerup:new({
  sprite=33,
  value=2,
  action="bombs",
})

skull_coin_powerup = powerup:new({
  sprite=39,
  action="skull_coin",
})

blood = object:new({
  bounce=false,
})

monster = object:new({
  sprites={base=1,walk_anim=2,walk1=1,walk2=1},
  dmg=1,
  invincible=0,
  type="monster",

  ai=function(self)
    self:move()
  end,
  move=function(self)
    move(self,true,self.thrown)
  end,
  damage=function(self,n)
    if self.invincible==0 then
      action_text("-"..n,self.x+6,self.y,8)
      self.life-=n
      if self.life>0 then
        sfx"1"
        self:bleed()
        self.invincible,self.thrown,self.dy,self.dx=16,true,-2.5,-sgn(p1.x-self.x)*(.5+n/2)
      else
        self:die()
      end
    end
  end,
  bleed=function(self)
    blood_anim(self.x,self.y)
  end,
  die=function(self)
    self:bleed()
    sfx"1"
    del(monsters,self)
    if rnd()<.2 then
      add(objects,gold_powerup:new({x=self.x,y=self.y,value=flr(rnd"50")+1}))
    end
  end,
})

ogre = monster:new({
  sprites={base=9,walk_anim=2,walk1=9,walk2=10},
  life=3,
  flip=true,

  ai=function(self)
    if not text_pause then
      self.flip=false
      self.dx=1
      if self.dy==0 and on_object(self,"door") then self:die() end
      self:move()
    end
  end,
  move=function(self)
    move(self,false,self.thrown)
  end,
  die=function(self)
    del(monsters,self)
  end
})

boss = ogre:new({
  life=15,
  flip=true,
  speed=2,
  sprite=11,
  sprites={base=11,walk_anim=2,walk1=11,walk2=12},
  ai_jump=0,
  ai=function(self)
    local self_x,self_y,self_dx,self_flip,p1_x=self.x,self.y,self.dx,self.flip,p1.x
    ai_timer+=1
    if not self.thrown then
      if ai_timer-self.ai_jump<20 and ai_timer>self.ai_jump and not self.isgrounded then
        self_dx=self_flip and 0xfffe or 2
      end
      if not (self.ai_throw_attack or self.ai_jump_attack) and self.isgrounded then
        if jumpable_step(self,self_flip) then
          self.ai_jump,self.dy,self_dx,ai_timer=30,-4,self_flip and 0xfffd or 3,30
        elseif frame%90==0 and rnd()<.50 and abs(p1_x-self_x)<48 then
          self.ai_throw_attack,ai_timer=true,0
        elseif frame%40==0 and rnd()<.42 and abs(p1_x-self_x)<32 then
          self.ai_jump_attack,self.dy,self_flip=true,0xfffd,self_x>p1_x
          self_dx=self_flip and 0xfffc or 4
        elseif frame%300==0 and rnd()<.5 and #monsters<5 then
          self_dx=0
          action_text("\\summon!",self_x+4,self_y,8)
          spawn_demon(self_x-24,self_y)
          spawn_demon(self_x+24,self_y)
        elseif frame%60==0 then
          self_flip=self_x>p1_x
          self_dx=self_flip and -1.5 or 1.5
        end
      end
      if self.ai_jump_attack and self.isgrounded then
        self.ai_jump_attack,self_dx=false,sgn(self_dx)*1.5
      elseif self.ai_throw_attack then
        if ai_timer==0 then
          self_flip=self_x<p1_x
          self_dx=self_flip and 0xfffe or 2
        elseif ai_timer<40 and self_dx==0 then
          ai_timer=39
        elseif ai_timer==40 then
          self_dx,self_flip=0,self_x>p1_x
        elseif ai_timer==50 then
          add(monsters,fireball:new({x=self_x-2,y=self_y-2,dx=self_flip and 0xfffd or 3,dy=-1.6,flip=self_flip}))
        elseif ai_timer==60 then
          self.ai_throw_attack,self_flip=false,self_x>p1_x
          self_dx=self_flip and 0xffff or 1
        end
      end
    end
    self.dx,self.flip=self_dx,self_flip
    move(self,false)
    if self.thrown then
      ai_timer=0
      if self.dy==0 then
        self.thrown=false
        self.flip=self.x>p1_x
        reset_mon_speed(self)
      end
    end
  end,
  die=function(self)
    sfx"11"
    bomb_particles(24,self.x,self.y)
    blood_anim(self.x,self.y)
    add(objects,skull_coin_powerup:new({x=self.x,y=self.y}))
    del(monsters,self)
    for i=1,8 do
      mset(22,4+i,100)
    end
    mset(22,6,101)
    add(actions,cocreate(function() pause_game(60) end))
  end
})

birbnana = monster:new({
  sprite=1,
  sprites={base=1,walk_anim=2,walk1=1,walk2=2},
  hitbox={xoffset=0,yoffset=0,w=7,h=8},
  dx=.6,
  ai=function(self)
    if level>1 then --don't jump in level 1
      if self.isgrounded then
        if line_of_sight(self,8,16) then
          self.dy=-2.6
        end
      end
    end
    if not self.isgrounded then
      self.dx=1.5*sgn(self.dx)
    else
      self.dx=.6*sgn(self.dx)
    end
    move(self,true)
  end
})

little_devil = monster:new({
  sprite=5,
  sprites={base=5,walk_anim=2,walk1=5,walk2=6},
  dx=.3,
  speed=.3,
  life=2,
  turn_delay=15,
  ai=function(self)
    local run=false
    if not self.thrown then
      if line_of_sight(self,12,64) then
        run=true
      end
      if run and abs(self.dx)<2.2 then
        self.dx+=sgn(self.dx)*.075
      elseif not run and abs(self.dx)>.3 then
        self.dx-=sgn(self.dx)*.05
        if abs(self.dx)<.3 then self.dx=sgn(self.dx)*.3 end
      end
    end
    move(self,not run)
    if self.dx==0 then
      turn_around(self)
      reset_mon_speed(self)
    end
    if self.dy==0 and self.thrown then
      self.thrown,self.flip=false,self.x-p1.x>0
      reset_mon_speed(self)
    end
  end,
})

bloodless_monster = monster:new({
  bleed=function(self) end,
})

rope = bloodless_monster:new({
  sprites={base=13,walk_anim=2,walk1=13,walk2=14},
  hitbox={xoffset=1,yoffset=6,w=6,h=2},
  dx=.1,
  dmg=0,
})

spikes = bloodless_monster:new({
  sprite=46,
  sprites={base=46,walk_anim=0},
  hitbox={xoffset=0,yoffset=3,w=7,h=5},
  dmg=2,
  dx=0,
  life=9,
  type="spikes",
  damage=function(self,n)
    if self.invincible==0 and n>=3 then
      self.life-=n
      if self.life>0 then
        self.invincible,self.thrown=16,true
      else
        self:die()
      end
    end
  end,
  die=function(self) del(monsters,self) end
})

fireball = bloodless_monster:new({
  sprite=47,
  sprites={base=47,walk_anim=0},
  hitbox={xoffset=0,yoffset=3,w=6,h=3},
  ai=function(self)
    self.dy-=0.14 --g/1.5
    move(self)
    if self.dy==0 then
      self.dx=0
      add(actions,cocreate(function() delayed_death(self,30) end))
    end
  end,
  die=function(self) del(monsters,self) end
})

p1=ogre:new({
  sprite=16,
  --sprites={base=16,walk1=17,walk2=18,ladder1=19,ladder2=20},
  hitbox={xoffset=0,yoffset=0,w=7,h=8},
  speed=2,

  damage=function(self,n)
    if not self.hidden and self.invincible==0 then
      sfx"6"
      action_text("-"..n,self.x+6,self.y,8)
      self.life-=n
      self:bleed()
      if self.life>0 then
        self.invincible=45
      else
        self:die()
      end
    end
  end,
  die=function(self)
    sfx"6"
    music"-1"
    add(actions,cocreate(function() delayed_death(p1,60) end))
  end,
})

particle=object:new({
  col=6,
  draw=function(self)
    --should be split into update&draw, but i ran out of tokens...
    self.dx*=.95
    self.dy*=.95
    self.x+=self.dx
    self.y+=self.dy
    self.size-=.09
    if (self.size<=0) self:die()
    circfill(self.x,self.y,self.size,self.col)
  end
})

-- globals
--g=0.42
frame,timer,shake,ai_timer,btn_,stop_input,cutscene_timer,jump_start,screen,paused,text_pause,monsters,objects,actions,particles,rooms,cam_x,cam_y,camera_y_offset,level,room_w,room_h,mon_sprites,obj_sprites = 0,0,0,0,0,true,0,0,nil,true,false,{},{},{},{},{},0,0,0,1,496,504,{birbnana,little_devil,spikes,rope,ogre,boss},{door,box,item_plant,gold_powerup,health_powerup}

function _init()
  --cls()
  load_rooms()
  --reset_stats()
  title_screen()
  --generate_level()
  --transition_level()
  --boss_level()
  --ending()
  --credits()
  jump_button,attack_button,button_set=4,5,false
end

function reset_stats()
  p1.life,p1.dx,p1.dy,p1.hidden,frame,timer,level,score,bombs,super_bombs,double_jump,weapon,fall_damage,skull_coin,powerups,stop_input,cutscene_timer,stop_time=3,0,0,false,0,0,1,0,3,false,false,26,true,false,{},false,0,false
end

function title_screen()
  if (not screen) music"24"
  generate_level()
  screen="title"
end

function transition_level()
  screen,paused,p1.flip,room_w,room_h="transition",false,false,128,128
  set_room(0,0,rooms[6])
  if level==2 then
    text_box("\\you seek our treasure?","\\turn back, it won't be","so easy from here on.")
  elseif level==4 then
    text_box("\\you will never find","the secret","lemon treasure!")
  else
    text_box("\\d\\e\\a\\t\\h guards","the lemon treasure.")
  end
end

function boss_level()
  clear_objects()
  screen,paused,p1.flip,room_w,room_h="boss",false,false,248,128
  set_room(0,0,rooms[7],30,15)
  music"10"
  text_box("\\you should not","have come here.")
end

function ending()
  clear_objects()
  p1.dx,p1.dy,stop_time,screen,paused,stop_input,cam_x,p1.flip,room_w,room_h=0,0,true,"ending",false,true,8,false,128,128
  set_room(0,0,rooms[8],16,15)
  music"19"
end

function credits()
  camera()
  --music"-1"
  screen,paused,frame="credits",true,0
end

function _draw()
  cls()
  if not paused then draw_level() end
  if screen=="title" then
    draw_title()
  elseif screen=="ending" then
    draw_ending()
  elseif screen=="credits" then
    draw_credits()
  end
  high_load=stat"1">=.93
  over_load=stat"1">1
  --rectfill(cam_x,cam_y+122,cam_x+127,cam_y+127,0)
  --print("load "..stat"1".." / "..flr(stat"0"/10.24).."% "..#monsters..","..#objects,cam_x+1,cam_y+123,stat"1"<=1 and 12 or 8)
end

function draw_sprite(obj)
  obj:draw()
end

function draw_level()
  if screen!="title" and screen!="ending" then
    cam_x,cam_y=p1.x-64,p1.y-64
    if (p1.flip) cam_x+=1
    if cam_x<0 then cam_x=0
    elseif cam_x>room_w-128 then cam_x=room_w-128 end
    if cam_y<0 then cam_y=0
    elseif cam_y>room_h-128 then cam_y=room_h-128 end
    if shake>0 then
      cam_x+=rnd(3)-1
      cam_y+=rnd(3)-1
    end
  end
  camera(cam_x,cam_y)
  map_x,map_y=flr(cam_x/8)-1,flr(cam_y/8)-1
  map(map_x,map_y,map_x*8,map_y*8,18,18)
  foreach(objects, draw_sprite)
  palt(0,false)
  palt(12,true)
  foreach(monsters, draw_sprite)
  palt()
  if screen!="title" then
    info_bar()
    if not p1.hidden then
      if p1.invincible==0 or frame%2==0 then
        p1:draw()
      end
      if up_icon(p1) then
        spr(62,p1.x+5,p1.y-3,1,1)
      end
    end
    for c in all(actions) do
      if costatus(c) then
        coresume(c)
      else
        del(actions,c)
      end
    end
  end
  foreach(particles, draw_sprite)
end

function draw_title()
  if frame>10 and btn(jump_button) or btn(attack_button) then
    if btn"5" and not button_set then
      jump_button,attack_button=5,4
    end
    button_set=true
    music"14"
    reset_stats() generate_level() return
  end
  btn_,cam_y=127,32
  rectfill(cam_x+31,65,cam_x+85,71,0)
  spr(48,cam_x+32,64)
  print("lemonhunter",cam_x+42,66,10)
  rectfill(cam_x-1,148,cam_x+127,159,0)
  sspr(64,16,16,16,cam_x+2,141)
  if frame%840<240 then
    if not button_set then
      shorttext("select jump key",cam_x+38,152)
    else
      shorttext("press \x8e /\x97  to start",cam_x+30,152)
    end
  elseif frame%840<480 then
    if jump_button == 4 then
      shorttext("\x8e jump \x97 attack \x83 \x97 bomb",cam_x+22,152)
    else
      shorttext("\x97 jump \x8e attack \x83 \x8e bomb",cam_x+22,152)
    end
  elseif frame%840<720 then
    shorttext("1000  = 1",cam_x+52,152)
    spr(36,cam_x+68,149)
    spr(32,cam_x+89,149)
  else
    shorttext("2017 - blizzz",cam_x+42,152,5)
  end
  if title_left then
    cam_x-=.5
    if (cam_x<=0) title_left=false
  else
    cam_x+=.5
    if (cam_x>=368) title_left=true
  end
end

function draw_ending()
  if not text_pause then
    cutscene_timer+=1
    if cutscene_timer==10 then
      text_box("\\d\\e\\a\\t\\h","\\i lost my skull coin.")
    end
    if skull_coin then
      if cutscene_timer==40 then
        text_box("\\d\\e\\a\\t\\h","\\give me my coin","and you may take","a lemon!")
      elseif cutscene_timer==90 then
        del(powerups,skull_coin_powerup.sprite)
        add(objects,skull_coin_powerup:new({x=p1.x,y=p1.y,dx=2,dy=0xfffc}))
      elseif cutscene_timer>90 and cutscene_timer<200 then
        objects[1]:move()
      elseif cutscene_timer==200 then
        p1.dx=1
      elseif cutscene_timer==320 then
        p1.dx=0
        action_text("\x87",112,93,8)
      elseif cutscene_timer==350 then
        local speedrun,timebonus=300-timer,0
        if speedrun>0 then
          if speedrun>240 then
            timebonus=(speedrun-240)*250+10200
          elseif speedrun>180 then
            timebonus=(speedrun-180)*100+4200
          elseif speedrun>120 then
            timebonus=(speedrun-120)*50+1200
          elseif speedrun>60 then
            timebonus=(speedrun-60)*15+300
          else
            timebonus=speedrun*5
          end
          text_box("\\you won!","","\\speedrun \\bonus: +"..timebonus,"\\score: "..score+timebonus)
        else
          text_box("\\you won!","","\\score: "..score)
        end
      elseif cutscene_timer==360 then credits()
      end
    else
      if cutscene_timer==60 then
        text_box("\\d\\e\\a\\t\\h","\\you don't have it...","\\go back.")
      elseif cutscene_timer==70 then
        p1.flip=true
        p1.dx=-.5
      elseif cutscene_timer==128 then
        action_text("meow",98,93,2)
      elseif cutscene_timer==230 then
        credits()
      end
    end
    p1:move()
  end
end

function draw_credits()
  if frame>100 and (btn"4" or btn"5") then title_screen() return end
  frame+=1
  local credit_text={
    "\\lemonhunter",
    "",
    "a game by",
    "blizzz",
    "",
    "music by @gruber_music",
    "",
    "\\special \\thanks",
    "\\lemon, \\h'orvuhst, old\\ganon",
    "\\snuki (who liked this game)",
    "\\pan, \\tom, \\seb, \\wash, \\nab",
    "\\natori, \\michelle, \\baka, \\twig",
    "",
    "\\basic \\thanks",
    "\\bananasaurus_rex",
    "",
    "\\thanks for playing!",
  }
  for i=1,#credit_text do
    shorttext(credit_text[i],hcenter(credit_text[i]),128+8*i-frame/4)
    if i==#credit_text and 128+8*i-frame/4==0xfff8 then title_screen() end
  end
end

function info_bar()
  rectfill(cam_x,cam_y,cam_x+127,cam_y+7,0)
  spr(32,cam_x+1,cam_y-2)
  print(p1.life,cam_x+8,cam_y+1,5)
  spr(super_bombs and 34 or 33,cam_x+17,cam_y-2)
  print(bombs,cam_x+24,cam_y+1,5)
  spr(weapon,cam_x+33,weapon!=28 and cam_y-2 or cam_y)
  local item_x=cam_x+47
  for powerup in all(powerups) do
    spr(powerup,item_x,cam_y-1)
    item_x+=10
  end
  spr(35,cam_x+77,cam_y-2)
  spr(0,cam_x+85,cam_y+2)
  print(score,cam_x+90,cam_y+1,5)
  t_min,t_sec=flr(timer/60),timer%60
  print(t_min..":"..(t_sec<10 and "0" or "")..t_sec,cam_x+(t_min>9 and 108 or 112),cam_y+1,5)
end

function hcenter(s)
  c=64-flr((#s*4)/2)
  for i=1,#s do
    if sub(s,i,i)=="\\" then
      c+=2
    end
  end
  return c
end

function move(obj,patrol,bounce)
  local patrol,bounce,w,h,x_gap_l=patrol or false,bounce or false,obj.hitbox.w,obj.hitbox.h,obj.hitbox.xoffset
  local x_gap_r=8-(x_gap_l+w)
  if obj.flip then
    x_gap_l=x_gap_r
    x_gap_r=obj.hitbox.xoffset
  end

  obj.x+=obj.dx/2

  --hit side walls
  local xoffset,hit_object,object_x=x_gap_l,false
  if obj.dx>0 then xoffset=x_gap_l+w-1 end

  if abs(obj.dx)!=0 then
    if obj!=p1 then
      for o in all(objects) do --check boxes
        if o.solid and o!=obj then
          if obj.x-x_gap_r>=o.x-7 and obj.x+x_gap_l<=o.x+7 and
              obj.y+5>=o.y and obj.y<=o.y and
              (obj.dx>0 and obj.x<o.x or obj.dx<0 and obj.x>o.x) then
            hit_object=true
            object_x=o.x
          end
        end
      end
    end

    if _fget_xy(obj.x+xoffset,obj.y+2,2) or _fget_xy(obj.x+xoffset,obj.y+7,2) or hit_object then
      obj.x=flr((obj.x)/8)*8
      if obj.dx<0 then
        obj.x+=8-x_gap_l
        if hit_object then obj.x=object_x+7-x_gap_l end
      else
        obj.x+=x_gap_r
        if hit_object then obj.x=object_x-7+x_gap_r end
      end
      if patrol then
        turn_around(obj)
      else
        if bounce and abs(obj.dx)>=.5 then
          obj.dx*=0xffff*obj.bounciness
          obj.flip=not obj.flip
        else
          obj.dx=0
        end
      end
    end

    if hit_object and _fget_xy(obj.x+(object_x>obj.x and 0 or 7),obj.y+7,2) then --crushed
      if obj.type=="bomb" then
        obj.x=object_x+(object_x>obj.x and 0xfffc or 3)
      else
        obj:die()
      end
      return
    end
  end

  --gravity
  if not obj.onladder then
    obj.dy+=0.21
    if obj.dy>8.5 then obj.dy=8.5 end
  end

  obj.y+=obj.dy/2

  if obj.onladder and obj.dy<0 then
    if not on_ladder(obj) then
      obj.y=flr((obj.y)/8)*8+3
    end
  end

  --check floor
  obj.isgrounded=false
  local ground_offset=obj.hitbox.yoffset+obj.hitbox.h
  local vl,vr,hit_object,object=mget((obj.x+x_gap_l+1)/8,(obj.y+ground_offset)/8),mget((obj.x+x_gap_l+w-2)/8,(obj.y+ground_offset)/8),false

  if obj.dy>=0 then
    for o in all(objects) do --check boxes
      if o.solid and o!=obj then
        if obj.x-x_gap_r>=o.x-5 and obj.x+x_gap_l<=o.x+5 then
          if obj.y+7>=o.y and obj.y<=o.y then
            hit_object=true
            object=o
          end
        end
      end
    end

    if fget(vl,2) or fget(vr,2) or hit_object
      or not obj.onladder and (fget(vl,4) or fget(vr,4)) and (obj.dy>4 or obj.y%8<3) then
      if obj==p1 and obj.dy>=7.5 then
        jump_particles()
        if p1.invincible==0 and fall_damage then
          p1:damage"1"
          bounce,p1.thrown,p1.invincible=true,true,60
        end
      end
      obj.y = flr((obj.y)/8)*8+8-ground_offset
      if object!=nil then
        obj.y=object.y-8+object.hitbox.yoffset
      end
      if bounce and abs(obj.dy)>=.5 then
        sfx"4"
        obj.dy*=0xffff*obj.bounciness
        obj.dx*=.8
      else
        obj.dy,obj.isgrounded=0,true
      end
    end

    if patrol and obj.dx!=0 and obj.isgrounded then
      if obj.dx<0 and not (fget(vl,2) or fget(vl,4)) or obj.dx>0 and not (fget(vr,2) or fget(vr,4)) then
        obj.dy=0
        turn_around(obj)
      end
    end
  end

  obj.lastgrounded=(obj.isgrounded or obj.onladder) and 0 or obj.lastgrounded+1

  --hit ceiling
  if obj.dy<=0 then
    if _fget_xy(obj.x+x_gap_l+1,obj.y+2,2) or _fget_xy(obj.x+x_gap_l+w-2,obj.y+2,2) then
      obj.y,obj.dy=flr((obj.y+7)/8)*8-2,0
    end
  end
  local screen_top=screen=="level" and 0 or 8
  if obj.y<screen_top then
    obj.y=screen_top
    obj.dy*=.90
  end
end

function turn_around(obj)
  obj.flip=not obj.flip
  obj.dx*=0xffff
end

function reset_mon_speed(mon)
  mon.dx=mon.flip and -mon.speed or mon.speed
end

function jumpable_step(mon,flip)
  local xoffset=flip and 0xfff8 or 16
  return _fget_xy(mon.x+xoffset,mon.y+1,2) and not _fget_xy(mon.x+xoffset,mon.y-7,2)
end

function collision(x,y,hitbox,flip,group)
  local hits,hitbox={},hitbox or base_hitbox
  if group==nil then --all
    hits=collision(x,y,hitbox,flip,monsters)
    for hit in all(collision(x,y,hitbox,flip,objects)) do
      add(hits,hit)
    end
  else
    local x_left=x+hitbox.xoffset
    local x_right=x_left+hitbox.w
    if flip then
      local xoffset=8-hitbox.xoffset-hitbox.w
      x_left,x_right=x+xoffset,x+xoffset+hitbox.w
    end
    local y_top=y+hitbox.yoffset
    local y_bottom=y_top+hitbox.h

    for obj in all(group) do
      if abs(x-obj.x)<8 and abs(y-obj.y)<8 then
        local obj_x_left=obj.x+obj.hitbox.xoffset
        local obj_x_right=obj_x_left+obj.hitbox.w
        if obj.flip then
          xoffset=8-obj.hitbox.xoffset-obj.hitbox.w
          obj_x_left,obj_x_right=obj.x+xoffset,obj.x+xoffset+obj.hitbox.w
        end
        local obj_y_top=obj.y+obj.hitbox.yoffset
        local obj_y_bottom=obj_y_top+obj.hitbox.h
        if x_right-1>obj_x_left and x_left<obj_x_right then
          if y_bottom>obj_y_top and y_top<obj_y_bottom then
            add(hits,obj)
          end
        end
      end
    end
  end
  return hits
end

function box_crush()
 for obj in all(objects) do
   if obj.solid and obj.dy>0 then
     mons = collision(obj.x,obj.y,obj.hitbox,obj.flip,monsters)
     for mon in all(mons) do
       if mon.type=="spikes" then
         obj:damage(999,"bomb")
       else
          mon:die()
       end
     end
   end
 end
end

function dist(obj,x,y)
  local xoffset,yoffset=obj.x+7<=x and 7 or 0,obj.y+7<=y and 7 or 0
  local x_dist=x-(obj.x+xoffset)
  if x>=obj.x and x<=obj.x+7 then
    x_dist=0
  end
  local y_dist=y-(obj.y+yoffset)
  if y>=obj.y and y<=obj.y+7 then
    y_dist=0
  end
  local dsq=(x_dist/1000)^2+(y_dist/1000)^2
  if dsq>32 then
    return 32767
  elseif dsq>0 then
    return sqrt(dsq)*1000
  else
    return 0
  end
end

function on_ladder(char)
  x,y=char.x,char.y
  return (_fget_xy(x+3,y,3) or _fget_xy(x+5,y,3) or _fget_xy(x+3,y+5,3) or _fget_xy(x+5,y+5,3))
end

function on_object(char,type1,type2)
  local objs,hit=collision(char.x,char.y,char.hitbox,char.flip),false
  for obj in all(objs) do
    if obj.type==type1 or obj.type==type2 then
      hit=obj
      break
    end
  end
  return hit
end

function up_icon(char)
  return on_object(char,"door","chest")
end

function line_of_sight(char,dy,dx)
  local x=char.x
  local dist=x-p1.x
  if abs(char.y-p1.y)>dy or abs(dist)>dx or char.flip and dist<0 or not char.flip and dist>0 then
    return false
  else
    local los=true
    for i=1,flr(abs(p1.x-x)/8) do
      local x=char.flip and (x+2)/8-i or (x+5)/8+i
      if _fget_xy(x*8,char.y,2) then los=false end
    end
    return los
  end
end

function get_random_item(obj)
  local luck=rnd()
  if luck<.05 then
    if not add_powerup"double_jump" then get_random_item() end
  elseif luck<.15 then
    upgrade_weapon()
  elseif luck<.25 then
    if not add_powerup"super_bombs" then get_random_item() end
  elseif luck<.35 then
    if not add_powerup"fall_damage" then get_random_item() end
  elseif luck<.70 then
    add_powerup("bombs",2)
  elseif luck<.85 then
    add_powerup"health"
  else
    add_powerup("score",flr(rnd"101")+50)
  end
  if obj then obj:die() end
end

function upgrade_weapon()
  local x_=p1.x+2
  if weapon==26 then
    if rnd()<.3 then
      weapon=15
      action_text("\\magical \\twig",x_,p1.y)
    else
      weapon=27
      action_text("\\spear",x_,p1.y)
    end
    sfx"13"
  elseif weapon==27 and rnd()>.5 then
    weapon=28
    action_text("\\flame \\sword",x_,p1.y)
    sfx"13"
  else
    get_random_item()
  end
end

powerup_objs_lv1={gold_powerup,bomb_powerup,health_powerup}
function spawn_powerup(x,y,l)
  local item,r=1,rnd()
  if r<.21 then
    item=3
  elseif r<.42 then
    item=2
  end
  add(objects,powerup_objs_lv1[item]:new({x=x,y=y}))
end

function add_powerup(action,n,x,y)
  local x,y=x or p1.x+2,y or p1.y
  if action=="score" then
    if flr(score/1000)!=flr((score+n)/1000) then
      p1.life+=1
      action_text("life +1",x,y,11,30)
      sfx"14"
    else
      sfx"2"
    end
    score+=n
    action_text(n.." gold",x,y,9)
  elseif action=="health" then
    p1.life+=1
    action_text("life +1",x,y,11)
    sfx"14"
  elseif action=="bombs" then
    bombs+=n
    action_text("bombs +"..n,x,y)
    sfx"14"
  elseif action=="double_jump" and not double_jump then
    double_jump=true
    add(powerups,38)
    action_text("\\birb \\feather",x,y)
    sfx"13"
  elseif action=="fall_damage" and fall_damage then
    fall_damage=false
    add(powerups,37)
    action_text("\\cat's \\paws",x,y)
    sfx"13"
  elseif action=="super_bombs" and not super_bombs then
    super_bombs=true
    action_text("\\crimson \\coating",x,y)
    sfx"13"
  elseif action=="skull_coin" and not skull_coin then
    skull_coin=true
    add(powerups,39)
    action_text("?",x,y)
    sfx"12"
  else
    return false
  end
  return true
end

function _update60()
  if (shake>0) shake-=1
  if paused or over_load and frame<60 then return end

  frame+=1
  --if frame==32767 then frame=1 end
  if frame%60==0 and not stop_time then timer+=1 end
  if text_pause then return end

  if p1.invincible>0 and not p1.thrown then p1.invincible-=1 end
  for mon in all(monsters) do
    if mon.invincible>0 then mon.invincible-=1 end
  end

  if not p1.hidden and not stop_input then
    --walk
    if not p1.thrown then
      if btn"0" then --left
        if p1.dx>-p1.speed then p1.dx-=p1.speed/8 end
        if p1.dx<-p1.speed then p1.dx=-p1.speed end
        if not p1.flip then p1.x=flr(p1.x) p1.x-=1 end --for hitbox reasons
        p1.flip=true
      end
      if btn"1" then --right
        if p1.dx<p1.speed then p1.dx+=p1.speed/8 end
        if p1.dx>p1.speed then p1.dx=p1.speed end
        if p1.flip then p1.x+=1 end --for hitbox reasons
        p1.flip=false
      end
      if not (btn"0" or btn"1") then
        p1.dx*=.8
        if abs(p1.dx)<.2 then p1.dx=0 end
      end
      if p1.onladder then p1.dx*=.7 end
      if btn"2" then --ladder up
        if on_ladder(p1) then
          if not p1.onladder then p1.sprite=19 end
          p1.onladder,p1.dy=true,-.5*p1.speed
        end
      end
      if btnp_(2) then
        local chest_check=on_object(p1,"chest")
        if chest_check then --chest
          get_random_item(chest_check)
        elseif on_object(p1,"door") then --door
          p1.dx,p1.dy=0,0 --snuki fix
          if screen=="boss" then
            ending()
          elseif level<7 then
            next_floor()
          else
            boss_level()
          end
        end
      end
      if btn"3" then --ladder down
        if on_ladder(p1) then
          if not p1.onladder then p1.sprite=19 end
          p1.onladder,p1.dy=true,.5*p1.speed
        end
      end
      if p1.onladder then
        if not btn"2" and not btn"3" then p1.dy=0 end
        if not on_ladder(p1) or _fget_xy(p1.x+4,p1.y+8,2) then p1.onladder=false end
      end
      --jump
      if (btnp_(jump_button) and (p1.lastgrounded<=2 or p1.onladder or (double_jump and p1.lastgrounded<200))) then
          p1.onladder,p1.dy,jump_start=false,-4.2,frame
          sfx"5"
          jump_particles()
          if p1.lastgrounded>2 then
            p1.lastgrounded+=200
          end
      elseif frame-jump_start==5 and not btn(jump_button) then --smol jump
          p1.dy+=1.6
      end
    else --throw animation
      p1.dx-=sgn(p1.dx)*0.021 --g*.1
      if (p1.dy==0) p1.thrown=false
      p1.onladder=false
    end

    p1:move()

    local objs = collision(p1.x,p1.y,p1.hitbox,p1.flip,objects)
    if #objs>0 then
      for obj in all(objs) do
        if obj.type=="powerup" then --pickup powerup
          add_powerup(obj.action,obj.value,obj.x+2,obj.y)
          del(objects,obj)
        elseif obj.pushable and p1.dx!=0 then --push boxes
          if sgn(obj.x-p1.x)==sgn(p1.dx) and
              abs(obj.x-p1.x)<5 and
              obj.y<=p1.y+3 and obj.y>=p1.y-4 then
            obj.dx=p1.dx/2
            obj:move"false"
            obj.dx=0
            for o in all(collision(obj.x,obj.y,base_hitbox,false,monsters)) do
              o.x=obj.x+(p1.dx<0 and 0xfffa or 6)
            end
            p1.x=obj.x+(p1.dx<0 and 5 or 0xfffb)
          end
        end
      end
    end

    if (btnp_(attack_button) and p1.attacking==false) then
      if btn"3" and bombs>0 and not p1.onladder then --throw bomb
        --enable the next two lines and disable the third to drop bombs instead
        --add(actions,cocreate(function() set_bomb(p1.x+(p1.flip and 1 or 0xffff),p1.y,0,0) end))
        --sfx"4"
        add(actions,cocreate(function() set_bomb(p1.x+(p1.flip and 0 or 4),p1.y,p1.dx+(p1.flip and 0xffff or 1),p1.dy-2.5) end))
      else --attack
        p1.attacking=true
        add(actions,cocreate(attack_anim))
      end
    end

    if p1.invincible==0 then --monster collision detection
      local mons = collision(p1.x,p1.y,p1.hitbox,p1.flip,monsters)
      if #mons>0 then
        local pick_mon={1,0}
        for i=1,#mons do --don't take damage from monsters we just hit
          if mons[i].invincible==0 and mons[i].dmg>pick_mon[2] then pick_mon={i,mons[i].dmg} end
        end
        if pick_mon[2]>0 then
          p1:damage(pick_mon[2])
          p1.thrown,p1.dx,p1.dy=true,1.5,-3.5
          if mons[pick_mon[1]].x>p1.x then
            p1.dx*=0xffff
          end
        end
      end
    end
  end

  for obj in all(objects) do
    if abs(obj.x-p1.x)<96 and abs(obj.y-p1.y)<96 and screen!="title" then
      obj:move()
    end
  end
  box_crush()

  for mon in all(monsters) do
    if abs(mon.x-p1.x)<128 and abs(mon.y-p1.y)<128 or screen=="title" and mon.y>=26 and mon.y<=160 and mon.x>=cam_x-8 and mon.x<=cam_x+136 then
      mon:ai()
      if mon.dy>0 and mon.type!="spikes" then --spikes
        mons=collision(mon.x,mon.y,mon.hitbox,mon.flip,monsters)
        for m in all(mons) do
          if m.type=="spikes" and m!=mon then mon:die() break end
        end
      end
    end
  end

  --animation
  if not p1.attacking then
    if p1.onladder then
      if frame%8==0 and p1.dy!=0 then
        p1.sprite=p1.sprite==19 and 20 or 19
      end
    elseif p1.dx!=0 then
      if frame%8==0 then
        p1.sprite=p1.sprite==17 and 18 or 17
      end
    end
    if p1.dx==0 and not p1.onladder then p1.sprite=16 end
  end

  if frame%12==0 then
    for mon in all(monsters) do
      if mon.dx!=0 and mon.sprites.walk_anim==2 then
        mon.sprite=mon.sprite==mon.sprites.walk1 and mon.sprites.walk2 or mon.sprites.walk1
      end
    end
  end

  btn_ = btn()
end

--load room layouts into ram
function load_rooms()
  rooms={{load_room(1,1),load_room(16,1),load_room(62,0)}, --1 start
        {load_room(31,1),load_room(46,1),load_room(1,16),load_room(31,46), --2 passage
        load_room(77,32),load_room(92,32),load_room(107,32),load_room(92,0),
        load_room(46,46),load_room(107,0),load_room(62,15),load_room(77,15)},
        {load_room(1,46),load_room(16,46)}, --3 drop
        {load_room(31,16),load_room(46,16),load_room(77,0)}, --4 goal
        {load_room(1,31),load_room(16,31),load_room(31,31),load_room(46,31), --5 optional
        load_room(16,16),load_room(62,32),load_room(92,15),load_room(107,15)},
        load_room(63,49), --transition
        load_room(78,49,30), --boss
        load_room(108,49,16)} --ending
end

--return room layout from map rom
function load_room(x,y,w,h)
  local w,h,room=w or 15,h or 15,{}
  for i=1,h do
    room[i]={}
    for j=1,w do
      room[i][j]=mget(x+j-1,y+i-1)
    end
  end
  return room
end

function clear_objects()
  monsters,objects,actions,particles,p1.attacking,shake={},{},{},{},false,0
end

--set a new floor
function next_floor()
  clear_objects()
  level+=1
  if level%2==0 then
    sfx"8"
    transition_level()
  else
    generate_level()
  end
end

--procedurally generate a level
function generate_level()
  clear_objects()
  screen,frame,paused,room_w,room_h,goal_,map_="level",0,false,496,504,false,{{},{},{},{}}
  -- goal, map should be local
  local x,y=flr(rnd"100"%4)+1,1
  map_[y][x]=1
  while not goal_ do
    d=get_direction(x)
    if d!=0 then
      x+=d
      if map_[y][x]==nil then map_[y][x]=2 end
    elseif map_[y][x]!=3 then --prevent multiple drops
      if y<4 then
        y+=1
        map_[y][x]=3
      else
        map_[y][x],goal_=4,true
      end
    end
  end
  --create rooms
  for i=0,3 do
    for j=0,3 do
      place_room(j,i,map_[j+1][i+1])
    end
  end
  --despawn objects to save cpu time
  while #monsters>50 do
    del(monsters,monsters[flr(rnd"100"%#monsters)+1])
  end
  while #objects>42 do
    local o=objects[flr(rnd"100"%#objects)+1]
    if not o.solid and o.type!="door" then
       del(objects,o)
     end
  end
end

function get_direction(i)
  local d=flr(rnd"100"%3)-1
  if d==0xffff and i==1 then
    d=1
  elseif d==1 and i==4 then
    d=0xffff
  end
  return d
end

function place_room(x,y,n)
  local n=n or 5
  set_room(x,y,rooms[n][flr(rnd"100"%#rooms[n])+1])
  if n==3 then --drop
    local ladder_x=y*15+3
    mset(ladder_x,x*15,101)
    mset(ladder_x,x*15-1,100)
  end
end

function set_room(x,y,room,w,h)
  local w,h=w or 15,h or 15
  for i=1,h do
    for j=1,w do
      set_tile(y*15+j,x*15+i,room[i][j])
    end
  end
end

--parse tile data and place tile or monster
function set_tile(x,y,n)
  if n==16 then
    p1.x,p1.y=x*8,y*8
    mset(x,y,0)
  else
    if (n==118 and rnd()<.60) n=36
    local obj=is_object(n)
    if obj then
      obj=obj:new({x=x*8,y=y*8})
      random_flip(obj)
      if (obj.action=="score") obj.value=flr(rnd"26"+25)
      if obj.type!="chest" and obj.action!="score" or rnd()>.42 then
        add(objects,obj)
      end
      mset(x,y,0)
    else
      local mon=is_monster(n)
      if mon then
        mon=mon:new({x=x*8,y=y*8})
        if level>1 and n==1 then --indicate jumping
          mon.sprites={base=3,walk_anim=2,walk1=3,walk2=4}
        elseif n==5 and rnd()<.01 then
          mon.sprites={base=7,walk_anim=2,walk1=7,walk2=8}
        end
        mon.sprite=mon.sprites.base
        random_flip(mon)
        add(monsters,mon)
        mset(x,y,0)
      else
        if n!=0 then
          mset(x,y,n)
        else
          if rnd()>.92 then
            mset(x,y,flr(124.3+rnd"3"))
          else
            mset(x,y,0)
          end
        end
      end
    end
  end
end

--convert sprite to object
function is_object(n)
  local obj=false
  for x in all(obj_sprites) do
    if x.sprite==n then
      obj=x
    end
  end
  return obj
end

--convert sprite to monster object
function is_monster(n)
  local mon=false
  for x in all(mon_sprites) do
    if x.sprites.base==n then
      mon=x
    end
  end
  return mon
end

function random_flip(obj)
  if rnd()>=.5 then
    obj.dx*=0xffff
    obj.flip=true
  end
end

--spawn a demon
function spawn_demon(x,y)
  if x>=8 and x<=240 then
    add(actions,cocreate(function() spawn_demon_co(x,y-24) end))
  end
end

function spawn_demon_co(x,y)
  local mon,fire=little_devil:new({x=x,y=y}),115
  random_flip(mon)
  for i=1,60 do
    if i==30 then fire=99 end
    spr(fire,x,y,1,1,mon.flip)
    yield()
  end
  add(monsters,mon)
end

--spawn a bomb
function set_bomb(x,y,dx,dy)
  bombs-=1
  local bomb_obj_data={x=x,y=y,dx=dx,dy=dy,flip=rnd()<.5}
  local b=super_bombs and red_bomb:new(bomb_obj_data) or bomb:new(bomb_obj_data)
  if b.flip then b.x-=2 end
  add(objects,b)
  for i=1,120 do
    if flr(i/2)%3==0 then
      circ(b.x+(b.flip and 7 or 0), b.y+2, 1, 8)
    end
    yield()
  end
  del(objects,b)
  x,y=b.x+2,b.y+4
  x_,y_=flr(x/8),flr(y/8)
  local range,r,dmg=super_bombs and 3 or 2,b.radius,b.dmg
  for i=-range,range do
    local xoffset=0
    if i<0 then xoffset=7 end
    for j=-range,range do
      local yoffset=0
      if j<0 then yoffset=7 end
      local tile_x,tile_y=x_+i,y_+j
      local tile=mget(tile_x,tile_y)
      if fget(tile,7) then
        if (x-((flr(x/8)+i)*8+xoffset))^2 + (y-((flr(y/8)+j)*8+yoffset))^2 <= r^2 then
          mset(tile_x,tile_y,0)
          if fget(mget(tile_x,tile_y-1),6) then
            mset(tile_x,tile_y-1,0)
          end
        end
      end
    end
  end
  sfx"3"
  if dist(p1,x,y)<=r then
    p1:damage(dmg)
    p1.thrown,p1.dx,p1.dy=true,4.2,-4.2
    if x>p1.x then
      p1.dx*=0xffff
    end
  end
  for mon in all(monsters) do
    if dist(mon,x,y)<=r then
      mon:damage(dmg)
    end
  end
  for obj in all(objects) do
    if dist(obj,x,y)<=r then
      obj:damage(dmg,"bomb")
    end
  end
  shake=15
  if not high_load then
    bomb_particles(r,x,y)
  end
  for i=0,5 do
    circfill(x,y,r,10-flr(i/2))
    yield()
  end
end

function bomb_particles(r,x,y)
  for i=1,r>15 and 20 or 10 do
    p=particle:new({x=x+rnd(r)-r/2,y=y+rnd(r)-r/2,size=rnd"7",dx=rnd"1"-.5,dy=rnd"1"-.5,col=5.5+rnd"2"})
    add(particles,p)
  end
end

function jump_particles()
  if not high_load then
    jump_particle(p1.flip and p1.x+3 or p1.x+1,p1.y+6,-.42)
    jump_particle(p1.flip and p1.x+6 or p1.x+4,p1.y+6,.42)
  end
end

function jump_particle(x,y,dx)
  add(particles,particle:new({x=x,y=y,dx=dx,size=1.9}))
end

--attack with main weapon (coroutine)
function attack_anim()
  if weapon==28 then
    sfx"10"
  else
    sfx"0"
  end
  local dmg,hitbox=1,{xoffset=0,yoffset=4,w=7,h=3}
  if weapon==27 then
    dmg,hitbox=2,{xoffset=0,yoffset=3,w=7,h=5}
  elseif weapon==28 then
    dmg,hitbox=3,base_hitbox
  elseif weapon==15 then
    dmg,hitbox=999,{xoffset=0,yoffset=2,w=8,h=5}
  end
  local wpn_spr=weapon
  for i=0,14 do
    if weapon==28 and (i==2 or i==4) then wpn_spr+=1 end
    x,x2=p1.x,p1.x
    if p1.flip then
      x-=7
      if weapon!=28 then x+=i/7*3 end
      x2-=14
    else
      x+=7
      if weapon!=28 then x-=i/7*3 end
      x2+=14
    end
    p1.sprite=21
    spr(wpn_spr,x,p1.y,1,1,p1.flip)
    local hits1=collision(x,p1.y,hitbox)
    if #hits1>0 then
      for obj in all(hits1) do
        obj:damage(dmg,"attack")
        if weapon==15 and obj.type=="monster" then
          weapon=26
          if screen=="boss" then
            text_box("\\twig broke,","but fulfilled his goal.")
          else
            action_text("\\twig broke :(",p1.x+6,p1.y,6,30)
          end
        end
      end
    end
    if weapon==28 and i>=4 then
      spr(31,x2,p1.y,1,1,p1.flip)
      local hits2=collision(x2,p1.y,{xoffset=2,yoffset=0,w=4,h=5})
      if #hits2>0 then
        for obj in all(hits2) do
          obj:damage(2)
        end
      end
    end
    yield()
  end
  p1.sprite,p1.attacking=p1.onladder and 19 or 16,false
end

--spawn blood effect (coroutine)
function blood_anim(x,y,green)
  add(actions,cocreate(function() blood_anim_co(x,y,green) end))
end

function blood_anim_co(x,y,green)
  local sprite=green and 53 or 50
  local blood_obj=blood:new({x=x,y=y,sprite=sprite})
  random_flip(blood_obj)
  add(objects,blood_obj)
  for i=0,12 do
    if i==8 then blood_obj.sprite=sprite+1 end
    blood_obj.dy-=0.14
    yield()
  end
  while not blood_obj.isgrounded do
    if green then
      blood_obj.dy-=0.105
      if blood_obj.dy>4 then blood_obj.dy=4 end
    end
    yield()
  end
  blood_obj.sprite=sprite+2
  for i=0,60 do
    yield()
  end
  del(objects,blood_obj)
end

function delayed_death(mon,n)
  if mon==p1 then
    p1.hidden=true
    p1:bleed()
  end
  for i=1,n do
    yield()
  end
  if mon==p1 then
    --sfx"17"
    stop_time=true
    text_box("\\you died.","","\\score: "..score,"",true)
  else
    mon:die()
  end
end

--text box coroutine
function text_box(line1,line2,line3,line4,death)
  text_pause=true
  add(actions,cocreate(function() text_box_co(line1,line2,line3,line4,death) end))
end

function text_box_co(line1,line2,line3,line4,death)
  for i=1,240 do
    if (btnp_(jump_button) or btnp_(attack_button)) break
    local text_x=cam_x+20
    rectfill(cam_x+16,cam_y+30,cam_x+112,cam_y+66,1)
    shorttext(line1,text_x,cam_y+34)
    shorttext(line2,text_x,cam_y+42)
    shorttext(line3,text_x,cam_y+50)
    shorttext(line4,text_x,cam_y+58)
    yield()
  end
  text_pause,btn_=false,127
  if (death) credits()
end

--text coroutine
function action_text(text,x,y,col,delay)
  if not high_load then
    add(actions,cocreate(function() action_text_co(text,x,y,col,delay) end))
  end
end

function action_text_co(text,x,y,col,delay)
  col,delay=col or 6,delay or 0
  if delay>0 then for i=1,delay do yield() end end
  for i=1,50 do
    local offset=i/4
    shorttext(text,x-1,y-offset,0)
    shorttext(text,x+1,y-offset,0)
    shorttext(text,x,y-1-offset,0)
    shorttext(text,x,y+1-offset,0)
    shorttext(text,x,y-offset,col)
    yield()
  end
end

function pause_game(n)
  text_pause=true
  for i=1,n do yield() end
  text_pause=false
end

--button press without auto-repeat
function btnp_(i)
  return (btn(i) and 2^i!=band(2^i,btn_))
end



--get sprite flag at x/y position
function _fget_xy(x,y,f)
  return fget(mget(x/8,y/8),f)
end

-- short text by lrp
alphabet,text_bytes,alphadict="abcdefghijklmnopqrstuvwxyz",{
 0x001c.1408, 0x0008.141f, 0x0014.1408, 0x001f.1408, 0x0014.140c, 0x0005.1e04,
 0x003c.5458, 0x0018.041f, 0x0000.1d00, 0x0000.1d20, 0x0014.081f, 0x0000.100f,
 0x001c.0c1c, 0x0018.041c, 0x0008.1408, 0x0018.147c, 0x007c.140c, 0x0004.0418,
 0x0004.1c10, 0x0014.0e04, 0x001c.100c, 0x000c.180c, 0x001c.181c, 0x0014.0814,
 0x003c.505c, 0x0010.1c04
},{}
for i=1,#text_bytes do
  alphadict[sub(alphabet,i,i)]=text_bytes[i]
end
function shorttext(text,x,y,col)
  text,x,y,col,captial=text or "",x,y,col or 6,false
  for l=1,#text do
    letter=sub(text,l,l)
    if letter=="\\" and not capital then
      capital=true
    elseif capital or alphadict[letter]==nil then
      print(letter,x,y,col)
      x+=4
      capital=false
    else
      image=alphadict[letter]
      for i=0,31 do
        if band(image,shl(0x0000.0001,i))!=0 then
          pset(x,y+i%8,col)
        end
        if i%8==7 then x+=1 end
      end
    end
  end
end
