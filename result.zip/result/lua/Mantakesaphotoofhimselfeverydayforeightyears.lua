points={}
total=60
spx=48
spy=70
t=0

function _init()
 for i=1,total do
  add(points,{
   x=64+sin(i*1/total)*40,
   y=64+cos(i*1/total)*40
  })
 end
end

function _update()
 if btn(4) then
  if (not musicplaying)	music(0)
  musicplaying=true
  
  spx+=rnd(.5)-.25
  spy+=rnd(.5)-.25
  for i=1,#points do
   points[i].x+=rnd(0.4)-.2
   points[i].y+=rnd(0.4)-.2
  end
  t+=1
 else
  music(-1)
  musicplaying=false
 end
end

function _draw()
 cls()
 rectfill(0,0,128,128,7)
 
 --eyes
 spr(1,spx,spy)
 spr(1,spx+24,spy)
 --mouth
 spr(2,spx+8,spy,2,1,false,t>600)
 
 for i=1,#points do
  local p=points[i]
  local pn=points[i+1]
  if pn then
   line(p.x,p.y, pn.x,pn.y, 5)
  else
   local pf=points[1]
   line(p.x,p.y, pf.x,pf.y, 5)
  end
 end
end