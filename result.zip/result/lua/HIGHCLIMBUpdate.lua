--high climb
--by trasevol_dog

--find me on twitter @trasevol_dog
--or contact me at trasevol.dog@gmail.com

--have fun!


cartdata("trasevol_dog_climbs_higher_kong")
cls()

--for i=0,63 do dset(i,0) end

--music(0)

px=64
py=32
pvx=0
pvy=0
pst=0
psp=0
psf=false
pgr=0
pwjt=0
pgd=false
pdj=true

pgrt=0

pchar=0--flr(rnd(3))

ptarg=false

rockbotm=120


flngp=true

blck={}--{{x=64,y=64}}

e={}

xmod=0
ymod=0
ycam=0
lycam=0

oycam=0

shkx=0
shky=0

score=0
scoreb=0
scomu=1
rscomu=1
hiscore=0
hiscoreb=0

bsc=dget(30)*256+dget(31)

pbsc=0

lsco=-1

strk=0
jstrk=0

fostrk=true


cuach=false
cachy=0
cacht=0
nachi=0

achiceiling=-16*32+96

--dachi={}

wbexists=0
achiroom=false

function _init()
 hiscore=0
 hiscoreb=0
 
 --reload(0x2000,0x2000,8)
 
 local k=1
 for i=0,3 do
  --poke(0x5f80+i,dget(i))
  hiscore+=k*dget(i)
  k*=10
 end

 local k=1
 for i=0,3 do
  --poke(0x5f84+i,dget(4+i))
  hiscoreb+=k*dget(4+i)
  k*=10
 end
 
 
 for i=1,16 do
  if dget(8+i)==1 then
   nachi+=1
   --poke(0x5f88+i,1)
  end
 end
 
 --poke(0x5f80+31,1)

 create_enemy(64,-128,8)
end

t=0
rt=0
function _update()
 rt+=0.01
 if ptarg and (not btnp(4)) and rt%0.03<0.01 then return end

 jstrk=0

 t+=0.01

 update_shake()

 update_player()
 update_playersprite()
 update_enemies()
 update_blocks()
 
 local nycam=min(rockbotm-112,py-80)

 --if pycm<64 or pycm>96 then
 lycam=0.9*lycam+0.1*nycam
 --end

 ycam=flr(lycam)
 
 --rockbotm-=0.1
 
 if achiroom then
  if #e<3 then
   --create_enemy(64,ycam-64,1+flr(rnd(4)))
  end
 else
  if #e<min(flr(bsc/2)+1,3)+wbexists then
   create_enemy(64,ycam-64)
  end
 end
 
 if nachi>0 and score==0 and wbexists==0 then
  create_enemy(64,ycam-64,7)
  wbexists=1
 end


 scoreb+=flr(score/10000)
 score=score%10000

 scoreb=scoreb%10000
 
 if py-4>ycam+127 and (score>0 or scoreb>0) then
  --end_streak()
  jstrk=strk
  strk=0
  fostrk=true
  camera(0,0)
  if scoreb>hiscoreb or (scoreb==hiscoreb and score>=hiscore) then
   hiscoreb=scoreb
   hiscore=score
   
   k=score
   for i=0,3 do
    --poke(0x5f80+i,k%10)
    dset(i,k%10)
    k=flr(k/10)
   end
   k=scoreb
   for i=0,3 do
    --poke(0x5f84+i,k%10)
    dset(4+i,k%10)
    k=flr(k/10)
   end

   rectfill(0,0,127,29,0)
   rectfill(0,0,127,25,7)
   sfx(14)
  else
   rectfill(0,0,127,25,0)
   sfx(13)
  end
  
  score=0
  scoreb=0
  
  local nchar=flr(rnd(3))
  if nchar>=pchar then
   pchar=nchar+1
  else
   pchar=nchar
  end
  sfx(8,3)
  flngp=true
  music(-1)
 end
 
 if pvy>=8 then
  add_shake(1)
 end
 
 if flngp and py>rockbotm-8 then
  sfx(-1,3)
  sfx(9)
  flngp=false
  music(0,3)
 end
 
 update_achievement()
end


function _draw()
 xmod=shkx
 ymod=-ycam+shky

 camera(0,0)
  --rectfill(0,0,127,127,0)
 ---[[
 local yspd=ycam-oycam
 oycam=ycam
 for i=0,999 do
  local x=rnd(128)
  local y=rnd(128)
  local c=pget(x,y+yspd)
  local mi=mid(0,y+yspd,128)
  if false and mi==0 or mi==128 then
   c=flr(rnd(2))*(8+rnd(8))
  elseif c==7 then c=0
  elseif c==0 then c=pget(x+flr(rnd(3))-1,y+flr(rnd(3))-1) if c==7 then c=0 end--c=rnd(8)+8
  else c=(c+rnd(99)/98)%8+8
  end
  circfill(x,y,1,c)
  --rectfill(x-1,y-1,x+1,y+1,c)
 end
 --]]

 if achiroom then
  draw_achiroombackground()
 else
  draw_background()
 end

 draw_prewall()
  
 camera(-xmod,-ymod)
 
 draw_preblocks()
 draw_preenemies()
 
 if pgd or pgr~=0 then
  superoutlined(draw_player,0)
 else
  r=5
  if pdj then r+=1 end
  circfill(px,py,r,col)
  circfill(px-1,py,r,col)
  circfill(px,py-1,r,col)
  circfill(px-1,py-1,r,col)
 end
 
 if ptarg then
  local col=0
  circfill(ptarg.x,ptarg.y,8,col)

  local foo=function()
       line(px,py,ptarg.x,ptarg.y,7)
      end
  superoutlined(foo,0)
  outlined(foo,7)
 end

 draw_enemies()
 pal(1,1)
 pal(8,8)
 outlined(draw_player,7)
 allcolorsto()
 draw_blocks()

 camera(0,0)
 draw_walls()
 
 camera(-xmod,-ymod)
 
 draw_text("⬅️   |   🅾️ / z   |   ➡️   ",64,130,1,0)

end


function update_player()
 pwjt=max(pwjt-1,0)
 
 if pgd then pdj=true end_streak() end

 local spd=0.5
 if btn(0) and pwjt==0 then pvx=min(pvx-spd,0) end
 if btn(1) and pwjt==0 then pvx=max(pvx+spd,0) end
 if btnp(4) then
  if ptarg and not(pgd or pgr~=0) then
   blockize()
  else
   if not(pgd or pgr~=0 or pdj) then
    camera(-xmod,-ymod)
    circfill(px,py,16,7)
    pvy=8
    pvx=0
    sfx(15)
   end
  
   if pgd or pdj or pgr~=0 then
    pvy=-4.2
    if not(pgd or pgr~=0) then
     sfx(5)
    else
     sfx(3)
    end
   end
   if pgr<0 then
    pvx=4
    pwjt=8
    camera(-xmod,-ymod)
    rect(px-2,py-16,px-3,py+15,0)
   elseif pgr>0 then
    pvx=-4
    pwjt=8
    camera(-xmod,-ymod)
    rect(px+1,py-16,px+2,py+15,0)
   elseif pgd or pdj then
    camera(-xmod,-ymod)
    rect(px-16,py+1,px+15,py+2,0)
   end
   
   if pdj and not (pgd or pgr~=0) then pdj=false end
   pgr=0
  end
 end
 
 if not (pwjt>0 or btn(0) or btn(1)) then
  pvx*=0.7
 end

 pvx=sgn(pvx)*min(abs(pvx),3)
 
 if abs(pvx)<0.2 then pvx=0 end
 
 if achiroom then
  if pvy>0 then
   pvy=max(pvy-0.5,min(pvy,2))--min(max(pvy,1),2))
  elseif pvy<0 then
   pvy=min(pvy+0.5,max(pvy,-2))--max(min(pvy,1),-2))
  end
 else
  pvy+=0.5
 end

 if pgr~=0 then
  pvy*=0.8
  
  --[[
  if achiroom then
   if pvy>0 then
    pvy=max(pvy,1)
   elseif pvy<0 then
    pvy=min(pvy,-1)
   end
  end
  --]]
  
  if achiroom and abs(pvy)<0.1 then
   sfx(-1,3)
   wglp=false
   --pvy=sgn(pvy)*0.15
  end
  
  pvx=0.3*sgn(pvx)
 end 
 
 pvy=min(pvy,8)

 update_playerpos()
 if pvy==8 then pgr=0 end
 
 --if pgr~=0 then
  --if pgrt%0.04<0.01 then
   --sfx(4)
  --end
  --pgrt+=0.01
 --end
 
 update_target()
end


function update_playerpos()

 local spgd=pgd
 local spgr=pgr
 pgd=false
 ny=py+pvy
 nx=px+pvx
 
 local col=false
 if nx-4<8 then
  px=8+4
  pgr=-1
  col=true
 elseif nx+4>120 then
  px=120-4
  pgr=1
  col=true
 else
  local bcol=false
  for b in all(blck) do
   if (py+4>b.y-4 and py-4<b.y+4)
   and (nx+4>b.x-4 and nx-4<b.x+4) then
    if px>b.x then
     px=b.x+8
     pgr=-1
    else
     px=b.x-8
     pgr=1
    end
    col=true
   end
  end
 end
 
 if col then
  pvx=sgn(pvx)*min(abs(pvx),1)
 else
  px=nx
  pgr=0
 end
 
 if ny+4>rockbotm then
  py=rockbotm-4
  pvy=0
  pgd=true
 elseif achiroom and ny-5<achiceiling then
  py=achiceiling+5
  pvy=-0.2
 else
  local bcol=false
  for b in all(blck) do
   if (ny+4>b.y-4 and ny-4<b.y+4)
   and (px+4>b.x-4 and px-4<b.x+4) then
    if py>b.y then
     py=b.y+8
     pvy=0
    else
     py=b.y-8
     pvy=0
	 pgd=true
    end
    bcol=true
   end
  end
  
  if not bcol then
   py=ny
  end
 end
 
 if pgd then pgr=0 end
 
 if pgd and not spgd then sfx(2) end
 if spgr==0 and pgr~=0 and pvy<8 then sfx(2) sfx(4,3) wglp=true end
 if pgr==0 and wglp then sfx(-1,3) wglp=false end
end

function update_target()
 ptarg=false
 
 if pgd or pgr~=0 then return end
 
 local dist=32*32

 for en in all(e) do
  if abs(en.y-py)<32 then
   local ndist=sqr(en.x-px)+sqr(en.y-py)
   if ndist<dist then
    dist=ndist
    ptarg=en
   end
  end
 end
end

function update_playersprite()
 pst+=1
 
 if pvx<0 then psf=true end
 if pvx>0 then psf=false end
 
 local opsp=psp
 
 if pgr~=0 then psp=4
 elseif pvy<-0.01 then psp=2
 elseif pvy>0.01 then psp=3
 elseif abs(pvx)>0.1 then psp=1
 else psp=0 end
 
 if psp~=opsp then
  pst=0
 end
 
end

function blockize()
 if ptarg.c==7 then
  rectfill(0,0,127,127,7)
  add_shake(32)
  achiroom=not achiroom
  e={}
  add(e,ptarg)
  blck={}
  score=0
 else
 
 if not achiroom then
  score+=scomu
  strk+=1
  bsc=min(bsc+1,10000)
  pbsc=min(pbsc+1,10000)
  dset(30,flr(bsc/256))
  dset(31,bsc%256)
 end
 
 --add(blck,{x=ptarg.x,y=ptarg.y,c=ptarg.c})
 create_block(ptarg)

 camera(-xmod,-ymod)
 circfill(px,py,8,0)
 circfill(ptarg.x,ptarg.y,20,0)
 circfill(ptarg.x,ptarg.y,16,ptarg.c)

 px=ptarg.x
 py=ptarg.y-8
 pvx=0
 pvy=-4.2
 pdj=true
 camera(-xmod,-ymod)
 rect(px-16,py+1,px+15,py+2,0)
 
 del(e,ptarg)

 add_shake(8)
 sfx(1)
 end
end

function end_streak()
 if strk==0 then return end
 
 jstrk=strk
 
 if strk>=10 then fostrk=false end
 
 if strk>=5 then
  camera(0,0)
  score+=flr(strk/5)*50
  rectfill(0,106,127,127,0)
  rectfill(0,110,127,127,7)
  sfx(12)
 end
 
 strk=0
end

function update_enemies()
 for en in all(e) do
  local nenx=en.x+en.vx
  local neny=en.y+en.vy
  
  if nenx-4<8 then
   en.x=8+4
   --en.vx*=-1
   en.vx=3+rnd(2)
   if en.c==7 then
    en.vx*=0.1
   end
   --sfx(6)
  elseif nenx+4>120 then
   en.x=120-4
   --en.vx*=-1
   en.vx=-3-rnd(2)
   if en.c==7 then
    en.vx*=0.1
   end
   --sfx(6)
  else
   en.x=nenx
  end
  
  if neny+4>rockbotm then
   en.y=rockbotm-4
   --en.vy*=-1
   en.vy=-4+rnd(1)
   if en.c==7 then
    en.vy*=0.1
   end
   --sfx(6)
  elseif neny+4>ycam+127 then
  
   if en.c==7 then
    if not achiroom then
     del(e,en)
     wbexists=0
    end
   else
    en.y=ycam+127-4
    en.vy=-4.5+rnd(2)
   end
   
   --sfx(6)
   camera(xmod,0)
   rectfill(en.x-18,124,en.x+18,127,0)
   rect(en.x-16,126,en.x+16,127,en.c)
  else
   en.y=neny
  end
  
  if en.c==7 then
   en.vy+=0.002
  else
   en.vy+=0.1
  end
  
  if en.c~=7 then
   if achiroom then
    en.vx-=sgn(en.x-px)/2
   else
    en.vx+=sgn(en.x-px)/5
   end
  end
  
  camera(-xmod,-ymod)
  for b in all(blck) do
   if abs(b.x-en.x)<8 and abs(b.y-en.y)<8 then
    circfill(b.x,b.y,20,0)
    circfill(b.x,b.y,16,b.c)
    del(blck,b)
    sfx(7)
   end
  end
 end
end

function update_blocks()
 for b in all(blck) do
  if b.y>ycam+127 then
   camera(xmod,0)
   circfill(b.x,123,20,0)
   circfill(b.x,123,16,b.c)
   rectfill(b.x-32,123,b.x+32,127,0)
   del(blck,b)
   sfx(7)
  elseif b.y<ycam then
   camera(xmod,0)
   circfill(b.x,4,20,0)
   circfill(b.x,4,16,b.c)
   rectfill(b.x-32,4,b.x+32,0,0)
   del(blck,b)
   sfx(7)
  end
 end
end


function update_achievement()
 if cuach then
  cacht-=0.01
  if cacht<0 then
   cuach=false
  end
 end
 
 savach=cuach
 
 local n=0
 
 n+=1
 if scomu>=2 and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if scomu>=4 and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if scomu>=8 and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if scomu>=16 and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if scomu>=32 and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if bsc>=128 and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if bsc>=1024 and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if jstrk==5 and (not flngp) and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if jstrk>=25 and (not flngp) and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if jstrk>=50 and (not flngp) and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if jstrk>=50 and flngp and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if score>=500 and fostrk and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if jstrk==8 and scomu==8 and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if score>=500 and scomu==1 and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 if score>0 and flngp and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 
 n+=1
 local all=true
 for i=1,16 do
  if dget(8+i)==0 then
   all=false
   break
  end
 end
 
 if all and dget(8+n)==0 then
  cuach=n
  dset(8+n,1)
  nachi+=1
  sfx(16)
  --poke(0x5f88+n,1)
 end
 

 
 
 if cuach and ((not savach) or (cuach!=savach)) then
  cacht=1
  cachy=ycam+64*4
  
  nachi+=1
  
  camera(-xmod/4,-ymod/4)
  local wi=#achi[cuach][2]*2-6
  local y=cachy/4
  circfill(64-wi,y,20,7)
  circfill(63+wi,y,20,7)
  rectfill(64-wi,y-20,63+wi,y+20,7)
 end
end


function add_shake(p)
 local a=rnd(1)
 shkx+=p*cos(a)
 shky+=p*sin(a)
end

function update_shake()
 if abs(shkx)+abs(shky)<0.5 then
  shkx=0
  shky=0
 end
 
 shkx*=-0.7-rnd(0.2)
 shky*=-0.7-rnd(0.2)
end



function draw_background()
 camera(-xmod/2,-ymod/2)
 local high=-flr(ycam/400+0.5)*400
 circfill(63,-high/2+64,12,0)
 if rscomu~=scomu or (-high/2+56>ycam/2 and scomu<high/400+1) then
  if rscomu==scomu and scomu<high/400+1 then
   sfx(10)
  end
  rscomu=min(rscomu+0.2,high/400+1)
  scomu=flr(rscomu)
  local cy=-high/2+64
  circfill(63,cy,8,7)
  for i=0,7 do
   local an=rnd(1)
   circfill(63+8*cos(an),cy+8*sin(an),2+rnd(4),flr(rnd(2))*7)
  end
 elseif -high/2+64<ycam/2+128 and scomu>high/400+1 then
  sfx(11)
  scomu=high/400+1
  local cy=-high/2+64
  circfill(63,cy,8,7)
  for i=0,7 do
   local an=rnd(1)
   circfill(63+8*cos(an),cy+8*sin(an),2+rnd(4),flr(rnd(2))*7)
  end
 else
  draw_text("\88"..(high/400+1).."",64,-high/2+64,1,0)
 end
 
 
 if pbsc>=0 and pbsc<3 then
  circfill(64,64,44,0)
 
   local xa=64-39
   local ya=64-18

   for i=0,999 do
   local xx=rnd(39*2)
   local yy=rnd(18*2)
    local x=xx/2
    local y=yy/2
    circ(xa+xx,ya+yy,1,sget(x,32+y))
   end
   
 elseif pbsc>1 and pbsc<6 then
  circfill(64,64,28,0)
  draw_text("\66\89",64,59,1,0)
  draw_text("trasevol_dog",64,69,1,0)
 end
 
 
 draw_achievement()
 
 
 camera(0,0)
 y=0
 
 local bgc=0
 if score>lsco then
  bgc=7
  lsco=score
 end
 
 local hisline
 if hiscoreb>0 then
  local k=1000
  hisline=hiscore.." \80\84\83"

  while k>hiscore and k>1 do
   hisline="0"..hisline
   k/=10
  end

  hisline="h\73: "..hiscoreb..hisline
 else
  hisline="h\73: "..hiscore.." \80\84\83"
 end
 
 local sline
 if scoreb>0 then
  --sline=scoreb..score.." \80\84\83"
 
  local k=1000
  sline=score.." \80\84\83"
  
  while k>score and k>1 do
   sline="0"..sline
   k/=10
  end
  
  sline=scoreb..sline
 else
  sline=score.." \80\84\83"
 end
 
 hscow=#hisline*4
 scow=#sline*4
 
 if hiscore>0 or hiscoreb>0 then
  hscow=max(hscow,scow)
  
  rectfill(64-hscow/2,0,64+hscow/2,9,bgc)
  circfill(64-hscow/2+2,0,9,bgc)
  circfill(64+hscow/2-2,0,9,bgc)
  
  y+=8
 end
 
 --scow=(scow+1)*4+16+2
 
 rectfill(64-scow/2+2,y,64+scow/2-2,y+9,bgc)
 circfill(64-scow/2+2,y,9,bgc)
 circfill(64+scow/2-2,y,9,bgc)

 y=0
 if hiscore>0 or hiscoreb>0 then
  draw_text(hisline,65,y+3,1,0)
  
  y+=8
 end
 
 draw_text(sline,65,y+3,1,0)

 if strk>1 then
  sline="\83\84\82\69\65\75: "..strk
  if strk>=5 then
   sline=sline.." (+"..(flr(strk/5)*50).." \80\84\83)"
  end
  hstkw=#sline*4
  rectfill(64-hstkw/2+4,118,64+hstkw/2-4,127,0)
  circfill(64-hstkw/2+3,127,9,0)
  circfill(64+hstkw/2-3,127,9,0)
  draw_text(sline,65,123,1,0)
 end
end

function draw_player()
 local sp
 
 if psp==0 then sp=flr(pst/8)%4
 elseif psp==1 then sp=4+flr(pst/4)%2
 elseif psp==2 then sp=6
 elseif psp==3 then sp=7
 elseif psp==4 then sp=8
 end

 spr(sp+pchar*16,flr(px)-4,flr(py)-4,1,1,psf)
end

function draw_enemies()
 for en in all(e) do
  circfill(en.x,en.y,5,7)
  circfill(en.x,en.y,4,en.c)
 end
end

function draw_preenemies()
 for en in all(e) do
  circfill(en.x,en.y,6,0)
 end
end


function draw_blocks()
 for b in all(blck) do
  rectfill(b.x-4,b.y-4,b.x+3,b.y+3,b.c)
  rect(b.x-4,b.y-4,b.x+3,b.y+3,7)
 end
end

function draw_preblocks()
 for b in all(blck) do
  rect(b.x-5,b.y-5,b.x+4,b.y+4,0)
 end
end

function draw_walls()

 if achiroom then
  rectfill(0,0,127,ymod+achiceiling,0)
 end
 
 rectfill(0,0,xmod+7,127,0)
 rectfill(xmod+120,0,127,127,0)
 rectfill(0,ymod+rockbotm,127,127,0)
 
 if achiroom then
  rect(xmod+7,ymod+achiceiling,xmod+120,ymod+rockbotm,7)
 else
  rect(xmod+7,-1,xmod+120,ymod+rockbotm,7)
 end
end

function draw_prewall()
 if achiroom then
  --rect(xmod+8,ymod+achiceiling+1,xmod+119,ymod+rockbotm-1,0)
 else
  rect(xmod+8,-1,xmod+119,ymod+rockbotm-1,0)
 end
end


function draw_achievement()
 if cuach then
  local cu=cuach
  camera(-xmod/4,-ymod/4)
  local wi=#(achi[cu][2])*2-6
  local y=cachy/4
  
  local c=0
  if cacht==1 then c=7 end
  
  circfill(64-wi,y,16,c)
  circfill(63+wi,y,16,c)
  rectfill(64-wi,y-16,63+wi,y+16,c)
  draw_text(achi[cu][2],64,y-8,1,c)
  rect(58,y+2,69,y+13,5)

  local s=(cu-1)%4+flr((cu-1)/4)*16+10

  if c==0 then spr(s,60,y+8-4) end
 end
end

function draw_achiroombackground()
 rectfill(0,0,127,127,0)

 camera(-xmod,-ymod)

 for i=1,#achi do
  local y=-i*32+127
  local wi=40
  
  --circfill(64-wi,y,15,c)
  --circfill(63+wi,y,15,c)
  --rectfill(64-wi,y-15,63+wi,y+15,c)
  
  if dget(8+i)==1 then
   draw_text(achi[i][2],64,y-8,1,c)
   rect(58,y+2,69,y+13,5)
   local s=(i-1)%4+flr((i-1)/4)*16+10
   spr(s,60,y+8-4)
  else
   draw_text(achi[i][3],64,y-8,1,c)
   rect(58,y+2,69,y+13,5)
   
   draw_text("?",64,y+8,1,5)
  end  

 end
end


function draw_text(blah,x,y,a,c1)
 if a==1 then x-=#blah*2
 elseif a==2 then x-=#blah*4 end
 y-=2
 for i=-1,1 do
 for j=-1,1 do
  print(blah,x+i,y+j,7)
 end end
 
 print(blah,x,y,c1)
end


eneside=0
function create_enemy(x,y,c)
 local a=rnd(1)
 local en={x=x,y=y,vx=(1+rnd(7))*sgn(eneside%2-0.5),vy=2+rnd(2),c=c or 8+flr(rnd(7))}
 add(e,en)
 eneside+=1
end


function create_block(en)
 local b={x=en.x,y=en.y,c=en.c}
 add(blck,b)
end



function rectrect(x1,y1,x2,y2,x3,y3,x4,y4)
 return ((x1>x3 and x1<=x4) or (x2>x3 and x2<=x4))
        and
        ((y1>y3 and y1<=y4) or (y2>y3 and y2<=y4))
end



function allcolorsto(c)
 if c then
  for i=0,15 do
   pal(i,c)
  end
 else
  for i=0,15 do
   pal(i,i)
  end
 end
end

function outlined(draw,c)
 allcolorsto(c)
 camera(-xmod-1,-ymod)
 draw()
 camera(-xmod+1,-ymod)
 draw()
 camera(-xmod,-ymod-1)
 draw()
 camera(-xmod,-ymod+1)
 draw()
 
 allcolorsto()
 camera(-xmod,-ymod)
 draw()
 
end

function superoutlined(draw,c)
 allcolorsto(c)
 camera(-xmod-2,-ymod)
 draw()
 camera(-xmod+2,-ymod)
 draw()
 camera(-xmod,-ymod-2)
 draw()
 camera(-xmod,-ymod+2)
 draw()
 
 camera(-xmod-1,-ymod-1)
 draw()
 camera(-xmod+1,-ymod-1)
 draw()
 camera(-xmod-1,-ymod+1)
 draw()
 camera(-xmod+1,-ymod+1)
 draw()
 
 allcolorsto()
 camera(-xmod,-ymod)
 --outlined(draw,c)
end



function sqr(a)
 return a*a
end



--seizure warning thingy
bli=0
while not btnp(5) do
 bli+=0.01
 
 cls()
 draw_text("hi!",64,10,1,0)
 draw_text("thank you for playing this game!",65,20,1,0)
 
 draw_text("just a little warning though",65,40,1,0)
 draw_text("the game contains bright colors",65,50,1,0)
 draw_text("and they move too.",65,60,1,0)
 
 draw_text("if that sounds like something",65,80,1,0)
 draw_text("that could hurt you",65,90,1,0)
 draw_text("please be wary!",65,100,1,0)
 
 if bli%0.4>0.1 then
 draw_text("- press ❎ to start the game - ",65,120,1,0)
 end
 
 flip()
end

cls()
sfx(8,3)


achi={
{0,"it is about the score",
"get to x2"},

{10,"getting there",
"get to x4"},

{11,"no sky, no limit",
"get to x8"},

{12,"celeste",
"get to x16"},

{0,"higher climb",
"get to x32"},

{0,"game of balls",
"get more balls"},

{0,"balls' bane",
"get more balls"},

{0,"high five",
"???"},

{0,"airborne",
"land a streak of 25+"},

{0,"dragon",
"land a streak of 50+"},


{0,"icarus",
"???"},

{0,"cautious",
"score 500+ only 50\80 streaks"},

{0,"pico-8",
"\"8\""},

{0,"u havin fun?",
"???"},


{0,"foolish game",
"cheat death"},

{0,"achiever",
"achieve everything"}

}