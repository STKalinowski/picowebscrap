-- skull dude
--by guerragames

one_frame=1/60
epsilon=.001

--
cartdata("skulldude")

--
function load_game()
 player_deaths,game_time=dget(0),dget(1)
 lup_range,lup_power,lup_rate,lup_health=dget(2),dget(3),dget(4),dget(5)
 pickups_levels_cleared1,pickups_levels_cleared2,enemies_levels_cleared1,enemies_levels_cleared2=dget(6),dget(7),dget(8),dget(9)
 player_health=dget(10)
 if(player_health==0)player_health=lup_healths[lup_health+1]
end

--
function save_game()
 dset(0,player_deaths)
 dset(1,game_time)
 dset(2,lup_range)
 dset(3,lup_power)
 dset(4,lup_rate)
 dset(5,lup_health)
 dset(6,pickups_levels_cleared1)
 dset(7,pickups_levels_cleared2)
 dset(8,enemies_levels_cleared1)
 dset(9,enemies_levels_cleared2)
 dset(10,player_health)
end

--
function reset_game()
 -- save state vars
 player_deaths,game_time=0,0
 lup_range,lup_power,lup_rate,lup_health=0,0,0,0
 pickups_levels_cleared1,pickups_levels_cleared2,enemies_levels_cleared1,enemies_levels_cleared2=0,0,0,0
 player_health=lup_healths[lup_health+1]
 save_game()
 run()
end

--
align_l,align_r=1,2

function print_outline(t,x,y,c,bc,a)
  local ox=#t*2 
  if a==align_l then
   ox=0
  elseif a==align_r then
   ox=#t*4
  end
  local tx=x-ox
  color(bc)
  print(t,tx-1,y)print(t,tx-1,y-1)print(t,tx,y-1)print(t,tx+1,y-1)
  print(t,tx+1,y)print(t,tx+1,y+1)print(t,tx,y+1)print(t,tx-1,y+1)
  print(t,tx,y,c)
end

--
cam_shake_x,cam_shake_y,cam_shake_damp=0,0,0
screen_flash_timer,screen_flash_color=0,7

--
function screenflash(duration,color)
 screen_flash_timer,screen_flash_color=duration,color
end

--
function screenshake(max_radius,damp)
 local a=rnd()
 cam_shake_x,cam_shake_y,cam_shake_damp=max_radius*cos(a),max_radius*sin(a),damp
end

--
function update_screeneffects()
 cam_shake_x*=cam_shake_damp+rnd(.1)
 cam_shake_y*=cam_shake_damp+rnd(.1)
 
 if abs(cam_shake_x)<1 and abs(cam_shake_y)<1 then
  cam_shake_x,cam_shake_y=0,0
 end

 if screen_flash_timer>0 then
  screen_flash_timer-=one_frame
 end
end

--
function nl(s)
 local a={}
 local ns=""
 
 while #s>0 do
  local d=sub(s,1,1)
  if d=="," then
   add(a,ns+0)
   ns=""
  else
   ns=ns..d
  end
  
  s=sub(s,2)
 end
 
 return a
end

--
function mag(x,y)
  local d=max(abs(x),abs(y))
  local n=min(abs(x),abs(y))/d
  return sqrt(n*n+1)*d
end

--
function normalize(x,y)
  local m=mag(x,y)
  return x/m,y/m,m
end

--
function fix_angle(a)
 while a>.5 do
  a-=1
 end
 
 while a<-.5 do
  a+=1
 end
 
 return a
end

--
function force_sep(fo,mo,min_sep,max_sep)
  local xdiff,ydiff=fo.x-mo.x,fo.y-mo.y
  local nx,ny,mag=normalize(xdiff,ydiff)
  local min_sep,max_sep=mag-min_sep,mag-max_sep
  if max_sep>0 then
   mo.x+=nx*max_sep
   mo.y+=ny*max_sep
  elseif min_sep<0 then
   mo.x+=nx*min_sep
   mo.y+=ny*min_sep
  end
end

--
function next_i(l,i)
 i+=1
 if(i>#l)i=1
 return i
end

--
function find_next_i(l,i,active_count)
 if active_count>=#l then
  return nil,0
 end
 
 local o=l[i]
 while o.active do
  i=next_i(l,i)
  o=l[i]
 end
 
 return o,i
end

--
function time_to_text(time)
 local mins,secs=flr(time/60),flr(time%60)
 
  if mins >= 100 then
   return "99:59"
  elseif mins > 0 then
   if secs < 10 then
    return mins..":0"..secs
   else
    return mins..":"..secs
   end
  else
   return ""..secs
  end
end

--
function spr_index_to_xy(spr_index)
 return spr_index%16*8,flr(spr_index/16)*8
end

--
function create_button(btn_num)
 return 
 {
  time_since_press=100,
  time_held=0,
  button_number=btn_num,

  button_init=function(b)
   b.time_since_press,b.time_held=100,0
  end,

  button_update=function(b)
   b.time_since_press+=one_frame

   if btn(b.button_number) then
    if b.time_held==0 then
     b.time_since_press=0
    end
  
    b.time_held+=one_frame
   else
    b.time_held=0
   end
  end,

  button_consume=function(b)
   b.time_since_press=100
  end,
 }
end

--
shoot_button=create_button(4)
dash_button=create_button(5)
shoot_button:button_init()
dash_button:button_init()


--
function round(x) return flr(x+.5) end

--
function map_coords(x,y)
 return flr(round(x)/8),flr(round(y)/8)
end

--
function solid_tall(x,y)
 local mx,my=map_coords(x,y)
 local val=mget(mx,my)
 return not fget(val,4) and (fget(val,0) or fget(val,1) or fget(val,2) or fget(val,3))
end


--
function s_floor(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx,my-1)
 return fget(val,0) and not fget(val2,2)
end

function s_ceil(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx,my+1)
 return fget(val,2) and not fget(val2,0)
end

function s_lwall(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx+1,my)
 return fget(val,3) and not fget(val2,1)
end

function s_rwall(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx-1,my)
 return fget(val,1) and not fget(val2,3)
end

--
function collision_checks(x,y,vx,vy,ws,we,hs,he)
 local new_x,new_y=x,y
 
 local on_floor,on_ceiling,on_lwall,on_rwall=false,false,false,false
 
 local nvx,nvy,vel_mag=normalize(vx,vy)
 
 local keep_looking=true
 
 while keep_looking do
  local temp_x,temp_y=new_x,new_y
  
  if vel_mag>epsilon then
   local i_vx=(vel_mag>=1) and nvx or (vel_mag*nvx) 
   local i_vy=(vel_mag>=1) and nvy or (vel_mag*nvy)
        
    if not on_floor and not on_ceiling then
     if i_vy>0 then
      if s_floor(new_x+ws+1,new_y+he+1) and not s_floor(new_x+ws+1,new_y+he-1) or 
         s_floor(new_x+we-1,new_y+he+1) and not s_floor(new_x+we-1,new_y+he-1) then
       on_floor=true
       temp_y=round(temp_y)
       nvy=0
       i_vy=0
      end
     else
      if s_ceil(new_x+ws+1,new_y+hs-1) and not s_ceil(new_x+ws+1,new_y+hs+1) or
         s_ceil(new_x+we-1,new_y+hs-1) and not s_ceil(new_x+we-1,new_y+hs+1) then
       on_ceiling=true
       temp_y=round(temp_y)
       nvy=0
       i_vy=0
      end
     end
    end
    
    if not on_rwall and not on_lwall then
     if i_vx > 0 then
      if s_rwall(new_x+we+1,new_y+hs+1) and not s_rwall(new_x+we-1,new_y+hs+1) or
         s_rwall(new_x+we+1,new_y+he-1) and not s_rwall(new_x+we-1,new_y+he-1) then
       on_rwall=true
       temp_x=round(temp_x)
       nvx=0
       i_vx=0
      end
     else
      if s_lwall(new_x+ws-1,new_y+hs+1) and not s_lwall(new_x+ws+1,new_y+hs+1) or
         s_lwall(new_x+ws-1,new_y+he-1) and not s_lwall(new_x+ws+1,new_y+he-1) then
       on_lwall=true
       temp_x=round(temp_x)
       nvx=0
       i_vx=0
      end
     end
    end
    --[[]]
    if abs(i_vy)>epsilon and abs(i_vx)>epsilon and not on_floor and not on_ceiling and not on_lwall and not on_rwall then
    if not on_floor and not on_ceiling then
     if i_vy > 0 then
      if s_floor(new_x+ws-1,new_y+he+1) and not s_floor(new_x+ws+1,new_y+he-1) or 
         s_floor(new_x+we+1,new_y+he+1) and not s_floor(new_x+we-1,new_y+he-1) then
       on_floor=true
       temp_y=round(temp_y)
       nvy=0
       i_vy=0
      end
     else
      if s_ceil(new_x+ws-1,new_y+hs-1) and not s_ceil(new_x+ws+1,new_y+hs+1) or
         s_ceil(new_x+we+1,new_y+hs-1) and not s_ceil(new_x+we-1,new_y+hs+1) then
       on_ceiling=true
       temp_y=round(temp_y)
       nvy=0
       i_vy=0
      end
     end
    end
    
    if not on_floor and not on_ceiling and not on_rwall and not on_lwall then
     if i_vx > 0 then
      if s_rwall(new_x+we+1,new_y+hs-1) and not s_rwall(new_x+we-1,new_y+hs+1) or
         s_rwall(new_x+we+1,new_y+he+1) and not s_rwall(new_x+we-1,new_y+he-1) then
       on_rwall=true
       temp_x=round(temp_x)
       nvx=0
       i_vx=0
      end
     else
      if s_lwall(new_x+ws-1,new_y+hs-1) and not s_lwall(new_x+ws+1,new_y+hs+1) or
         s_lwall(new_x+ws-1,new_y+he+1) and not s_lwall(new_x+ws+1,new_y+he-1) then
       on_lwall=true
       temp_x=round(temp_x)
       nvx=0
       i_vx=0
      end
     end
    end
    end
    --]]
    if not on_floor and not on_ceiling then
     temp_y+=i_vy
    end
  
    if not on_rwall and not on_lwall then
     temp_x+=i_vx
    end    
  
    vel_mag-=1
  else
   keep_looking=false
  end

  new_x,new_y=temp_x,temp_y
  
  if on_floor or on_ceiling then
   new_y=round(new_y)
  end
 
  if on_rwall or on_lwall then
   new_x=round(new_x)
  end
 end
 
 return {x=new_x,y=new_y,floor=on_floor,lwall=on_lwall,rwall=on_rwall,ceil=on_ceiling}
end

-- part
parts={}
parts_next=1

for i=0,400 do
 add(parts,{t=0})
end

--
function parts_spawn(t,x,y,vx,vy,d,s,ds,c,bc)
 parts_next=next_i(parts,parts_next)
 
 local p=parts[parts_next]
 
 p.t,p.x,p.y,p.vx,p.vy,p.d,p.s,p.ds,p.c,p.bc=t,x,y,vx,vy,d,s,ds,c,bc
end

--
function parts_explode(count,br,rr,t,bx,by,rx,ry,d,s,rs,ds,c,bc)
 for i=1,count do
  local a,r=rnd(),br+rnd(rr)
  local vx,vy=r*cos(a),r*sin(a)
  parts_spawn(t,bx+rnd(rx),by+rnd(ry),vx,vy,d,s+rnd(rs),ds,c,bc)
 end
end

--
function parts_update()
 for k,p in pairs(parts) do
  if p.t>0 then
   p.t-=one_frame
   
   p.vx*=p.d
   p.vy*=p.d
   
   p.x+=p.vx
   p.y+=p.vy
   
   p.s=max(0,p.s+p.ds)
   
   if p.s<=0 then
    p.t=0
   end
  end
 end
end

--
function part_draw(p,o,c)
 circfill(flr(p.x),flr(p.y),p.s+o,c)
end

--
function parts_draw()
 for k,p in pairs(parts) do
  if p.t>0 then
   part_draw(p,1,p.bc)
  end
 end

 for k,p in pairs(parts) do
  if p.t>0 then
   part_draw(p,0,p.c)
  end
 end
end


-- pbullets
pbullets={}
pbullets_next=1
pbullets_active_count=0

pbullets_speed=3

for i=0,50 do
 add(pbullets,{active=false})
end

--
function pbullets_spawn(t,x,y,vx,vy,s)
 local pb,i=find_next_i(pbullets,pbullets_next,pbullets_active_count)
 
 if pb then
  pbullets_next=i
  
  pbullets_active_count+=1
  pb.active=true
  
  pb.t,pb.sx,pb.sy,pb.x,pb.y,pb.vx,pb.vy,pb.s=t,x,y,x,y,vx,vy,s
  
  sfx(rnd()>.5 and 0 or 1)
 end
end

--
function pbullets_update()
 for k,pb in pairs(pbullets) do
  if pb.active then
   pb.t-=one_frame
   
   if pb.t<0 then
    pb.active=false
    pbullets_active_count-=1
   end
   
   pb.x+=pb.vx
   pb.y+=pb.vy
   
   parts_spawn(.1,pb.x,pb.y+1-rnd(2),0,0,0,1+rnd(pb.s),-.2,8,0)
   
   
   if solid_tall(pb.x,pb.y) then
    pb.active=false
    pbullets_active_count-=1

    parts_explode(20,.5,2,.2,pb.x-1,pb.y-1,2,2,.9,0,pb.s,-.2,8,0)
   end
   
   
   local m=mag(pb.x-pb.sx,pb.y-pb.sy)
   if m>=lup_ranges[lup_range+1] then
    pb.active=false
    pbullets_active_count-=1
   end
   
   --[[]]
   local x,y=pb.x,pb.y
   for k,e in pairs(enemies) do
    if e.active then
     local size=e.size
     if x+1<e.x-size or
        x-1>e.x+size or
        y+1<e.y-size or
        y-1>e.y+size then
      if(e.type.pbullets_check)e.type.pbullets_check(e,pb)
     else
      pb.active=false
      pbullets_active_count-=1
      
      enemy_damage(e,pb,lup_powers[lup_power+1])
     end
    end
   end
   --]]
  end
 end
end

-- camera

function cam_reset()
 cam_x,cam_y,target_cam_x,target_cam_y=0,0,0,0
end

--
function cam_update()
 if player_x>cam_x+128 then
  target_cam_x+=128
  enemies_reset()
 elseif player_x<cam_x then
  target_cam_x-=128
  enemies_reset()
 end
 
 if player_y>cam_y+128 then
  target_cam_y+=128
  enemies_reset()
 elseif player_y<cam_y then
  target_cam_y-=128
  enemies_reset()
 end

 if abs(cam_x-target_cam_x)>1 then
  cam_x+=.15*(target_cam_x-cam_x)
 end
 if abs(cam_y-target_cam_y)>1 then
  cam_y+=.15*(target_cam_y-cam_y)
 end
end

-- player
player_z=0

player_acc,player_damp,player_dash_rate=.2,.8,.3

lup_ranges={48,72,96,180}
lup_powers={1,2,3,4}
lup_rates={.3,.25,.2,.1}
lup_healths={3,4,5,6}

--
function player_level_up_menu()
 level_up_menu,level_up_menu_t,level_up_menu_sel,level_up_menu_sel_t=true,0,0,0
end

--
function player_level_up_update()
 level_up_menu_t+=one_frame
 
 if level_up_menu_t>1 and
    (shoot_button.time_since_press<.05 or dash_button.time_since_press<.05) and 
    level_up_menu_sel_t==0 then
  if level_up_menu_sel==0 then
   if lup_range<3 then
    lup_range+=1
    level_up_menu_sel_t=.5
   end
  elseif level_up_menu_sel==1 then
   if lup_power<3 then
    lup_power+=1
    level_up_menu_sel_t=.5
   end
  elseif level_up_menu_sel==2 then
   if lup_rate<3 then
    lup_rate+=1
    level_up_menu_sel_t=.5
   end
  elseif level_up_menu_sel==3 then
   if lup_health<3 then
    lup_health+=1
    player_health=lup_healths[lup_health+1]
    level_up_menu_sel_t=.5
   end
  end
 end
 
 if level_up_menu_sel_t>0 then
  level_up_menu_sel_t-=one_frame
  if level_up_menu_sel_t<=0 then
   level_up_menu=false
   save_game()
  end
 else
  if btnp(2) then
   level_up_menu_sel=max(0,level_up_menu_sel-1)
  end
  if btnp(3) then
   level_up_menu_sel=min(3,level_up_menu_sel+1)
  end
 end
end

--
function draw_level_up_text(t,y,index)
print_outline(t,43,y,level_up_menu_sel==index and 8 or 0,7,align_l)
end

-- 
function drawdot(i,mi,x,y)
 if(i<=mi)circfill(x,y,2,8)
 circ(x,y,2,7)
end

--
function player_level_up_draw()
 local scale=min(level_up_menu_t*level_up_menu_t,.2)*5
 
 if(level_up_menu_sel_t>0 and level_up_menu_sel_t<.2)scale=min(level_up_menu_sel_t,.2)*5
 
 local base_y=-80+scale*80+32
 
 if(level_up_menu_t>.2)base_y+=3*sin(level_up_menu_t)
 
 rectfill(32,base_y-9,96,base_y+40,0)
 rect(34,base_y-7,94,base_y+38,7)
 
 print_outline("power-up!",65,base_y-4,0,7)
 draw_level_up_text("range:",base_y+6,0)
 draw_level_up_text("power:",base_y+14,1)
 draw_level_up_text(" rate:",base_y+22,2)
 draw_level_up_text(" life:",base_y+30,3)

 for i=0,3 do
  local x=70+i*6
  drawdot(i,lup_range,x,base_y+8)
  drawdot(i,lup_power,x,base_y+16)
  drawdot(i,lup_rate,x,base_y+24)
  drawdot(i,lup_health,x,base_y+32)
 end

 print_outline(">",37,base_y+6+level_up_menu_sel*8,8,7,align_l)
end

--
function player_reset()
 player_t,player_x,player_y,player_speed,player_va,player_vx,player_vy,player_fa,player_sa,player_shooting_cooldown,player_dash_cooldown,player_closest_time,player_damaged=0,64,64,0,0,0,0,0,0,0,0,0,0
 
 player_fx,player_fy=1,0
 player_sx,player_sy=1,0
 player_closest_e=nil
 level_up_menu=false 
 
 player_gameover,player_gameover_timer=false,0
end

--
function player_damage()
  player_damaged=2

  player_health-=1
  
  local died=(player_health<=0)

  for i=1,died and 100 or 40 do
   local a,r=rnd(),.5+rnd(3)
   local vx,vy=r*cos(a),r*sin(a)
   
   if died then
    parts_spawn(2,player_x-3+rnd(6),player_y-5+rnd(6),vx,vy,.96,2+rnd(6),-.1,8,7)
   else
    parts_spawn(.4,player_x-3+rnd(6),player_y-5+rnd(6),vx,vy,.95,2+rnd(4),-.2,8,7)
   end
  end

  if died then
   sfx(9)
   player_deaths+=1
   player_gameover=true
  else
   sfx(8)
  end

  screenshake(6,.7)
  screenflash(.05,8)

  save_game()
end

--
function player_find_closest_enemy()
 local ce=nil
 local closest_m=lup_ranges[lup_range+1]

 for k,e in pairs(enemies) do
  if e.active and not e.type.chest then
   local dx,dy=e.x-player_x,e.y-(player_y-2)
   local nx,ny,m=normalize(dx,dy)
    
   if m<closest_m then
    ce=e
    closest_m=m
   end
  end
 end
 
 if ce!=player_closest_e then
  player_closest_e,player_closest_time=ce,0
 end
end

--
function player_update_aiming()
 player_closest_time+=one_frame
 
 if shoot_button.time_held<=0 then
  player_find_closest_enemy()
 else
  if player_closest_e==nil then
   player_find_closest_enemy()
  end
 end
 
 --[[]]
 if player_closest_e then
  local e=player_closest_e
   
  local closest_m=lup_ranges[lup_range+1]
   
   if e.active then
    local dx,dy=e.x-player_x,e.y-(player_y-2)
   
    if abs(dx)<closest_m and abs(dy)<closest_m then
     local nx,ny,m=normalize(dx,dy)
     
     if m<closest_m then
      
      local t=m/pbullets_speed
      
      local dx,dy=e.x+e.vx*t-player_x,e.y+e.vy*t-(player_y-2)
      local nx,ny,m=normalize(dx,dy)
      
      player_sx,player_sy=nx,ny
      player_sa=atan2(player_sx,player_sy)
     else
      player_closest_e=nil
     end
    else
     player_closest_e=nil
    end
   else
    player_closest_e=nil
   end
  end
 --]]
 
 if player_closest_e==nil then
  player_sx,player_sy,player_sa=player_fx,player_fy,player_fa
 end
end

--
function player_update()
 player_t+=one_frame
 
 if player_y<0 and not game_finished then
  game_finished,game_finished_timer=true,0
 end
 
 if game_finished then
  game_finished_timer+=one_frame
  return
 end
 
 if player_gameover then
   player_gameover_timer+=one_frame
   
   if player_gameover_timer>=1 then
    if btnp(4) or btnp(5) then
     player_gameover=false
     game_view.start()
     player_health=lup_healths[lup_health+1]
     save_game()
    end
   end
   return
 end 
 
 if(player_shooting_cooldown>0)player_shooting_cooldown-=one_frame
 if(player_dash_cooldown>0)player_dash_cooldown-=one_frame
 if(player_damaged>0)player_damaged-=one_frame
 
 local cx,cy=0,0
 
 if(btn(0))cx-=1
 if(btn(1))cx+=1
 if(btn(2))cy-=1
 if(btn(3))cy+=1
 
 local ncx,ncy,m=normalize(cx,cy)
 
 if m>0 then
  local ca=atan2(ncx,ncy)
  player_fa=atan2(player_fx,player_fy)
  
  local angle_diff=fix_angle(ca-player_fa)
  
  if abs(angle_diff)>.25 then
   player_fa=ca
  else
   player_fa+=mid(-.04,angle_diff,.04)
  end

  player_fx,player_fy=cos(player_fa),sin(player_fa) 
 end
 
 if m>0 and player_dash_cooldown<=player_dash_rate/2 then
  local max_speed=shoot_button.time_held>.2 and .4 or 1

  
  player_speed=mid(0,player_speed+player_acc,max_speed)
 else
  player_speed*=player_damp
 end
 
 -- dash mechanic
 if dash_button.time_since_press<.2 then
  if player_dash_cooldown<=0 then
   sfx(2)
   dash_button:button_consume()
   player_dash_cooldown,player_speed=player_dash_rate,6
  end
 end
 
 player_update_aiming()
 
 player_vx,player_vy=player_speed*player_fx,player_speed*player_fy
 
 
 player_cr=collision_checks(player_x,player_y,player_vx,player_vy,-3,3,-3,3)
 player_x,player_y=player_cr.x,player_cr.y
 
 if level_boss_arena then
   if (player_x-3<cam_x+9)player_x=cam_x+12
   if (player_x+3>cam_x+117)player_x=cam_x+114
   if (player_y-5<cam_y+9)player_y=cam_y+14
   if (player_y+1>cam_y+117)player_y=cam_y+116
 end
 
 if shoot_button.time_held>0 then
  if player_shooting_cooldown<=0 then
   player_shooting_cooldown=lup_rates[lup_rate+1]
   pbullets_spawn(1,player_x,player_y-2,pbullets_speed*player_sx,pbullets_speed*player_sy,lup_powers[lup_power+1])
  end
 end
 
 local shooting=(player_shooting_cooldown>0 or player_speed>.5)
 
 if shooting then
  player_z=-6+sin(player_t*10)
 else
  player_z=-6+2*sin(player_t)
 end
 
 if player_dash_cooldown<=player_dash_rate/2 then
  parts_spawn(.2+rnd(.4),player_x,player_y+player_z+4,-.2+rnd(.4),-.5-rnd(),.95,4,-.2,8,0)
 else
  parts_spawn(.2+rnd(.4),player_x,player_y+player_z+4,0,0,.95,4,-.2,8,0)
 end
end

--
function pdraw(ox,oy)
 local spri=(player_dash_cooldown>player_dash_rate/2) and 1 or 2
 spr(spri,player_x-3+ox,player_y+player_z+oy)
end

--
function player_draw()
 if player_gameover then
  local blink=(player_gameover_timer%.2>.1)
  local c=blink and 8 or 0
  local bc=blink and 0 or 8
  
  local a=min(.25,player_gameover_timer/2)
  local x,y=cam_x+64,cam_y-128+128*16*a*a
  
  print_outline("you died... again!",x,y+48,c,bc)
  print_outline("deaths:"..player_deaths,x,y+64,c,bc)
  print_outline("press any button",x,y+80,c,bc)
  print_outline("to continue!",x,y+86,c,bc)
  
  return
 end
 
 if player_damaged>0 and player_damaged%.2>.1 then
  return
 end

 for i=1,15 do
  pal(i,0)
 end 
  
 pdraw( 1, 0)
 pdraw( 1, 1)
 pdraw(-1, 0)
 pdraw(-1,-1)
 pdraw( 0, 1)
 pdraw(-1, 1)
 pdraw( 0,-1)
 pdraw( 1,-1)
 
 pal()
 
 pdraw(0,0)
end

--
function player_draw_hud()
 pal(14,0)
 for i=1,lup_healths[lup_health+1] do
  spr((i<=player_health) and 18 or 19,6*i-5,1)
 end
 pal()
 
 print_outline("-"..time_to_text(game_time).."-",64,3,8,0)
end

--
function player_draw_crosshair()
 
 if player_closest_e then
  local e=player_closest_e
  local x,y=e.x,e.y
  local s=12*mid(.6,player_closest_time*4,1)+sin(player_t*4)
  local xc=x-1
  color(0)
  circ(xc-1,y,s)
  circ(xc+1,y,s)
  circ(xc,y-1,s)
  circ(xc,y+1,s)
  circ(xc,y+2,s)
  circ(xc,y,s,8)
 
  for i=0,2,2/5 do
   local t=player_t/2+i
   local x1,y1=x+s*cos(t),y+s*sin(t)
   local x2,y2=x+s*cos(t+5/8),y+s*sin(t+5/8)
   
   line(x1+1,y1,x2+1,y2,0)
   line(x1-1,y1,x2-1,y2,0)
   line(x1,y1+1,x2,y2+1,0)
   line(x1,y1-1,x2,y2-1,0)
   line(x1,y1,x2,y2,8)   
  end
  
  rectfill(cam_x+80,cam_y+1,cam_x+126,cam_y+5,7)
  rectfill(cam_x+81,cam_y+2,cam_x+125,cam_y+4,0)
  local d=42*e.health/e.type.health
  rectfill(cam_x+82,cam_y+3,cam_x+82+d,cam_y+3,8)
 end
end

-- enemy bullets
ebs={}
ebs_next=1

for i=1,400 do
 add(ebs,{})
end

function ebs_reset()
 for k,eb in pairs(ebs)do
  eb.active=false
 end
end

function ebs_make_bullets(x,y,s,speed,count,inc_a,start_a)
 sfx(3)
 
 local ia=start_a
 for i=1,count do
  local eb=ebs[ebs_next]
  eb.x,eb.y,eb.s,eb.velx,eb.vely=x,y,s,speed*cos(ia),speed*sin(ia)
  eb.active,eb.t=true,10
  ebs_next=next_i(ebs,ebs_next)
  
  ia-=inc_a
 end 
end

--
function ebs_shoot_aimed(x,y,s,speed,count,angle)
 local nx,ny,mag=normalize(player_x-x,player_y-2-y)
 ebs_make_bullets(x,y,s,speed,count,angle/count,atan2(nx,ny))
end

--
function ebs_shoot_spread(x,y,s,speed,count,angle)
 ebs_make_bullets(x,y,s,speed,count,1/count,angle)
end

--
function ebs_check_player(eb)
 if(player_dash_cooldown>player_dash_rate/2) return
 if (player_damaged>0) return
 
 local s=eb.s/2
 
 if player_x+1<eb.x-s or
    player_x-1>eb.x+s or
    player_y-1<eb.y-s or
    player_y-3>eb.y+s then
 else
  eb.active=false
  player_damage()
 end
end

--
function ebs_update()
 for k,eb in pairs(ebs)do
  if eb.active then
   if eb.t<=0 then
    eb.active=false
   else
    eb.t-=one_frame
    eb.y+=eb.vely
    eb.x+=eb.velx
    
    if solid_tall(eb.x,eb.y) then
     eb.active=false

     parts_explode(10,.5,2,.2,eb.x-1,eb.y-1,2,2,.9,0,eb.s,-.2,7,8)
    end

    ebs_check_player(eb)
   end
  end
 end
end

--
function ebs_draw()
 for k,eb in pairs(ebs)do
  if eb.active then
   local c,bc=7,8
   if(eb.t%.2>.1)c,bc=8,7
   circfill(eb.x,eb.y,eb.s,bc)
   circfill(eb.x,eb.y,eb.s-1,c)
  end
 end
end

-- enemies
enemy_types={}

--
function enemy_shooter_init(e,size,wait)
 e.shoot_bullet_time,e.bullet_size=wait,size
 e.bullet_timer=e.shoot_bullet_time-one_frame
end

--
function enemy_shooter_adjust(e,max_shoot_rate,max_health)
 e.shoot_bullet_time=max_shoot_rate+(1-max_shoot_rate)*e.health/max_health
 if(e.bullet_timer>e.shoot_bullet_time)e.bullet_timer=e.shoot_bullet_time-one_frame
end

--
function enemy_shooter_spread(e,speed,count,angle)
 if e.bullet_timer<e.shoot_bullet_time then
  e.bullet_timer+=one_frame
   
  if e.bullet_timer>=e.shoot_bullet_time then
   e.bullet_timer=0
   ebs_shoot_spread(e.x,e.y,e.bullet_size,speed,count,angle)
  end
 end
end

--
function enemy_shooter_aimed(e,speed)
 if e.bullet_timer<e.shoot_bullet_time then
  e.bullet_timer+=one_frame
   
  if e.bullet_timer>=e.shoot_bullet_time then
   e.bullet_timer=0
   ebs_shoot_aimed(e.x,e.y,e.bullet_size,speed,1,0)
  end
 end
end

-- 
function enemy_follow_player(e,maxd,speed,aspeed)
 local nx,ny,m=normalize(player_x-e.x,player_y-e.y)

 local va,angle_diff=atan2(e.vx,e.vy),0
 
 if m>0 and m<=maxd then
  local ca=atan2(nx,ny)
  angle_diff=fix_angle(ca-va)
 else
  angle_diff=rnd(2*aspeed)-aspeed
 end

 va+=mid(-aspeed,angle_diff,aspeed)
 e.vx,e.vy=speed*cos(va),speed*sin(va) 
end

--
function enemy_follow_player_and_bounce(e,maxd,chance)
  if rnd()<chance then
   enemy_follow_player(e,maxd,e.type.speed,e.type.aspeed)
  end
  
  if (e.cr.rwall or e.cr.lwall)e.vx*=-1
  if (e.cr.floor or e.cr.ceil)e.vy*=-1
end

--
function boss_init_children(e,counter,size)
  e.children={}
  e.size,e.next_child_counter,e.next_child_size=6,counter,size
end

--
function boss_damage_spawn_children(e,d,child_counter,child_size_inc)
 local retval=nil
 if d>0 then
  e.next_child_counter-=d
  
  if e.next_child_counter<=0 then
   e.next_child_counter=child_counter
   retval={x=e.x,y=e.y,bs=e.next_child_size,size=0,t=0}
   add(e.children,retval)
   e.next_child_size+=child_size_inc
  end
 end
 
 return retval
end

--
function boss_children_pbullets_check(e,pb)
 local x,y=pb.x,pb.y
 for k,v in pairs(e.children) do
  local size=v.size
  if x+1<v.x-size or
     x-1>v.x+size or
     y+1<v.y-size or
     y-1>v.y+size then
      
  else
   pb.active=false
   pbullets_active_count-=1
   
   enemy_damage(e,pb,0)
  end
 end
end

--
function boss_draw_children(e,o,c)
 for k,v in pairs(e.children) do
  circfill(v.x,v.y,v.size+o,c)
 end
end

--
function boss_draw_eye(e)
 local x,y=e.x,e.y
 circfill(x,y,6,8)
 circfill(x,y,5,7)

 local nx,ny,m=normalize(player_x-x,player_y-y)
 circfill(x+2*nx,y+2*ny,2,0)
end

--
function boss_draw(e)
 boss_draw_children(e,1,0)
 circfill(e.x,e.y,7,0)
 boss_draw_children(e,0,8)
 boss_draw_eye(e)
end


-- angry slime
enemy_types[10]=
{
 idle_anim=nl("10,10,10,10,10,10,10,10,10,10,11,11,11,11,11,11,11,11,11,11"),
 health=10,
 speed=.5,
 aspeed=.02,
 
 init=function(e)
  enemy_shooter_init(e,2,.3)
 end,

 update=function(e)
  enemy_shooter_aimed(e,1)
  enemy_follow_player_and_bounce(e,32,.9)
 end,
}

-- hidden chest
enemy_types[16]=
{
 idle_anim={16},
 health=5,
 chest=true,
}

-- chest
enemy_types[17]=
{
 idle_anim={17},
 health=1,
 chest=true,
}

-- blob
enemy_types[32]=
{
 idle_anim=nl("32,32,32,32,32,32,32,32,32,32,33,33,33,33,33,33,33,33,33,33,"),
 health=4,
 speed=.1,
 aspeed=.04,

 update=function(e)
  enemy_follow_player_and_bounce(e,32,.8)
 end,
}

-- fast shooter
enemy_types[34]=
{
 idle_anim=nl("34,34,34,34,34,34,34,34,34,34,35,35,35,35,35,35,35,35,35,35,"),
 health=10,
 
 init=function(e)
  enemy_shooter_init(e,2,.3)
  e.shoot_a=0
 end,

 update=function(e)
  e.shoot_a+=.0005
  enemy_shooter_spread(e,.5,4,e.shoot_a)
 end,
}

-- chomper
enemy_types[36]=
{
 idle_anim=nl("36,36,36,36,36,36,36,36,36,36,37,37,37,37,37,37,37,37,37,37,"),
 health=20,
 speed=.5,
 aspeed=.01,
 
 update=function(e)
  enemy_follow_player_and_bounce(e,32,.8)
 end,
}

-- puffer
enemy_types[38]=
{
 idle_anim=nl("38,38,38,38,38,38,38,38,38,38,39,39,39,39,39,39,39,39,39,39,"),
 health=20,
 
 init=function(e)
  enemy_shooter_init(e,3,2)
  e.shoot_a=0
 end,

 update=function(e)
  e.shoot_a+=.0004
  enemy_shooter_spread(e,.5,4,e.shoot_a)
 end,
}

-- shooter blob
enemy_types[40]=
{
 idle_anim=nl("40,40,40,40,40,40,40,40,40,40,41,41,41,41,41,41,41,41,41,41,"),
 health=10,
 speed=.1,
 aspeed=.04,
 
 init=function(e)
  enemy_shooter_init(e,2,1)
 end,

 update=function(e)
  enemy_follow_player_and_bounce(e,48,.8)
  enemy_shooter_aimed(e,.6)
 end,
}


-- big boom blob
enemy_types[42]=
{
 idle_anim=nl("42,42,42,42,42,42,42,42,42,42,43,43,43,43,43,43,43,43,43,43,"),
 health=40,
 speed=.1,
 aspeed=.1,
 
 init=function(e)
  enemy_shooter_init(e,4,1)
 end,

 update=function(e)
  enemy_follow_player_and_bounce(e,96,.5)
  enemy_shooter_aimed(e,.8)
 end,
}

-- circle shooter
enemy_types[56]=
{
 idle_anim=nl("56,56,56,56,56,56,56,56,56,56,57,57,57,57,57,57,57,57,57,57,"),
 health=30,
 
 init=function(e)
  enemy_shooter_init(e,3,2)
  e.shoot_a=0
 end,

 update=function(e)
  e.shoot_a+=.0001
  enemy_shooter_spread(e,.5,16,e.shoot_a)
 end,
}

-- tiny seeker
enemy_types[58]=
{
 idle_anim=nl("58,58,58,58,58,58,58,58,58,58,59,59,59,59,59,59,59,59,59,59,"),
 health=2,
 speed=.75,
 aspeed=.01,
 
 update=function(e)
  enemy_follow_player_and_bounce(e,16,.9)
 end,
}

-- spikes
enemy_types[60]=
{
 idle_anim=nl("60,60,60,60,60,60,60,60,60,60,61,61,61,61,61,61,61,61,61,61,"),
 health=2,
}

-- growing snake boss
enemy_types[63]=
{
 idle_anim={63},
 health=100,
 speed=.8,
 aspeed=.01,

 isboss=true,
 
 init=function(e)
  enemy_shooter_init(e,2,1)
  enemy_shooter_adjust(e,.05,100)
  boss_init_children(e,5,5)
 end,

 update=function(e)
  enemy_follow_player_and_bounce(e,128,.25)
  enemy_shooter_aimed(e,1.5)
  
  local fo=e
  for k,mo in pairs(e.children) do
   mo.t+=one_frame
   mo.size=5*min(.2,mo.t)*mo.bs+sin(mo.t*3)
   
   force_sep(fo,mo,8,8)
   fo=mo
   
   enemy_check_player(mo)
  end
 end,
 
 damaged=function(e,d)
  boss_damage_spawn_children(e,d,5,.5)
  enemy_shooter_adjust(e,.05,100)
 end,
 
 pbullets_check=boss_children_pbullets_check,
 
 draw=boss_draw,
}

-- child circle boss
enemy_types[47]=
{
 idle_anim={47},
 health=250,
 speed=.5,
 aspeed=.01,

 isboss=true,
 
 init=function(e)
  enemy_shooter_init(e,2,1)
  enemy_shooter_adjust(e,.2,250)
  boss_init_children(e,5,4)

  e.shoot_a=0
 end,

 update=function(e)
  enemy_follow_player_and_bounce(e,128,.25)
  
  e.shoot_a+=.0005
  enemy_shooter_spread(e,.8,4,e.shoot_a)

  local a_sep,a,r=1/#e.children,e.t/10,40*sin(e.t/13)*(1-e.health/100)+45
  
  for k,mo in pairs(e.children) do
   mo.t+=one_frame
   mo.size=5*min(.2,mo.t)*mo.bs+sin(mo.t*3)
   
   local dx,dy=e.x+r*cos(a),e.y+r*sin(a)
   local nx,ny,m=normalize(dx-mo.x,dy-mo.y)
   
   local mag=min(1,.1*m)
   mo.x+=mag*nx
   mo.y+=mag*ny
   
   a+=a_sep
   
   enemy_check_player(mo)
  end
 end,

 damaged=function(e,d)
  boss_damage_spawn_children(e,d,5,0)
  enemy_shooter_adjust(e,.2,250)
 end,
 
 pbullets_check=boss_children_pbullets_check,
 
 draw=boss_draw,
 
}

-- poop children boss
enemy_types[46]=
{
 idle_anim={46},
 health=500,
 speed=.5,
 aspeed=.01,
 isboss=true,
 
 init=function(e)
  enemy_shooter_init(e,2,1)
  enemy_shooter_adjust(e,.15,500)
  boss_init_children(e,10,6)

  e.shoot_a=0
 end,

 update=function(e)
  enemy_follow_player_and_bounce(e,128,.25)
  
  e.shoot_a+=.002
  enemy_shooter_spread(e,.8,5,e.shoot_a)
  
  local fo=e
  for k,mo in pairs(e.children) do
   mo.t+=one_frame
   mo.size=5*min(.2,mo.t)*mo.bs+4*sin(mo.t/9)
   
   if rnd()>.9 then
    enemy_follow_player(mo,128,.2,.01)
   end
   
   mo.x+=mo.vx
   mo.y+=mo.vy

   local sep=fo.size+mo.size-2
   force_sep(fo,mo,sep,sep)
   fo=mo
   
   enemy_check_player(mo)
  end
 end,

 damaged=function(e,d)
  local child=boss_damage_spawn_children(e,d,10,0,2,.15)
  if child then
   child.vx,child.vy=0,0
  end
  
  enemy_shooter_adjust(e,.15,500)
 end,
 
 pbullets_check=boss_children_pbullets_check,
 
 draw=boss_draw,
}


-- final boss
enemy_types[62]=
{
 idle_anim={62},
 health=800,
 speed=.3,
 isboss=true,
 no_collison=true,
  
 init=function(e)
  enemy_shooter_init(e,2,.3)
  enemy_shooter_adjust(e,2,.2,800)
  boss_init_children(e,5,5)

  e.shoot_a=0
 end,

 update=function(e)
  local bx,by=cam_x+64,cam_y+64
  
  local a=e.t/8
  
  local sint=sin(a/4)
  
  local ox,oy=e.x,e.y
  e.x,e.y=bx+48*sint*cos(a),by+48*sint*sin(a)
  e.vx,e.vy=e.x-ox,e.y-oy
  
  e.shoot_a+=.001+.0005*sint
  enemy_shooter_spread(e,.5,6,e.shoot_a)

  for k,mo in pairs(e.children) do
   a-=.03
   
   mo.t+=one_frame
   mo.size=5*min(.2,mo.t)*mo.bs+sin(mo.t)

   local r=48*sin(a/4)
   dx,dy=bx+r*cos(a),by+r*sin(a)

   local nx,ny,m=normalize(dx-mo.x,dy-mo.y)
   
   local mag=min(1,.1*m)
   mo.x+=mag*nx
   mo.y+=mag*ny
   
   enemy_check_player(mo)
  end
 end,

 damaged=function(e,d)
  boss_damage_spawn_children(e,d,10,0)
  enemy_shooter_adjust(e,.2,800)
 end,
 
 pbullets_check=boss_children_pbullets_check,
 
 draw=function(e)
  circfill(e.x,e.y,7,0)
  boss_draw_children(e,0,8)
  boss_draw_eye(e)
 end,
}

--
enemies={}

level_boss_arena=false

for i=1,30 do
 add(enemies,{active=false})
end

--
function enemy_spawn(spr,x,y,level_cleared)
 
 local e,i=find_next_i(enemies,enemies_next,enemies_active_count)
 
 if e then
  enemies_next=i+1
  
  enemies_active_count+=1
  e.active=true
  
  e.type_i,e.type=spr,enemy_types[spr]
  e.anim=e.type.idle_anim
  e.health=e.type.health
  e.spawned,e.spawn_x,e.spawn_y,e.x,e.y=true,x,y,x+4,y+4
  
  local speed,a=e.type.speed or 0,rnd()
  
  e.vy,e.vx=speed*cos(a),speed*sin(a)
  
  e.size,e.anim_index,e.t,e.damaged_timer=3,1,0,0
 
  if(e.type.init)e.type.init(e)
 
  if level_cleared then
   if (e.type.isboss or e.type.chest) and not pickups_level_cleared() then
    enemy_kill(e,false,false)
   else
    enemy_kill(e,false,level_cleared)
   end
  end
 end
 
 return e
end

----
function enemy_kill(e,effect,level_precleared)
 e.active=false
 enemies_active_count-=1
 
 enemies_check_level_cleared()
 
 if(not level_precleared and (e.type.isboss or e.type.chest))pickups_spawn(e.x,e.y)
 
 if e.type.isboss then
  level_boss_arena=false

  if(effect)screenflash(.1,7)sfx(7)

 else
  if(effect)screenflash(.025,7)sfx(5)
 end

 if(effect)screenshake(6,.7)
end

--
function enemy_damage(e,pb,d)
 
 if(e.type.chest and enemies_active_count>1)return

 if d>0 then
  e.health-=d
  if(e.type.damaged)e.type.damaged(e,d)
  e.damaged_timer=.1
 end
 
 if e.health<=0 then
  if e.type.isboss then
   parts_explode(80,.5,5,2,e.x+1,e.y+1,6,6,.98,1,8,-.1,8,0)
  else
   parts_explode(20,.5,3,.4,e.x+1,e.y+1,6,6,.95,1,3,-.2,8,0)
  end
  
  enemy_kill(e,true,false)
 else
  parts_explode(10,.5,2,.2,pb.x+1,pb.y+1,2,2,.9,0,pb.s+2,-.2,8,0)
 end
end

--
function enemy_draw(e,ox,oy)
 spr(e.anim[e.anim_index],e.x-4+ox,e.y-4+oy,1,1,e.anim_flip)
end

--
function enemy_check_player(e)
 if(e.type and e.type.chest)return
 if(player_dash_cooldown>player_dash_rate/2) return
 if (player_damaged>0) return
 
 local size=e.size
 if player_x+1<e.x-size or
    player_x-1>e.x+size or
    player_y-1<e.y-size or
    player_y-3>e.y+size then
 else
  player_damage()
 end
end

--
function enemies_update_level_spawn()
 level_boss_arena=false
 
 local level_cleared=false 
 local level_mask1,level_mask2=cam_to_level_mask()
 if band(enemies_levels_cleared1,level_mask1)!=0 or band(enemies_levels_cleared2,level_mask2)!=0 then
  level_cleared=true
 end
 
 for x=target_cam_x,target_cam_x+128,8 do
  for y=target_cam_y,target_cam_y+128,8 do
   local mx,my=map_coords(x,y)
   
   local tile_spr=mget(mx,my)
   if fget(tile_spr,7) then
    local e=enemy_spawn(tile_spr,mx*8,my*8,level_cleared)
   
    if(not level_cleared and e.type.isboss)level_boss_arena=true
   end
  end
 end
end

--
function cam_to_level_num()
 return flr(target_cam_y/128)*8+flr(target_cam_x/128)
end

--
function cam_to_level_mask()
 local level_num=cam_to_level_num()
 
 if level_num<16 then
  return shl(0x1,level_num),0
 else
  return 0,shl(0x1,level_num-16)
 end
end

--
function enemies_check_level_cleared()
 if enemies_active_count<=0 then
  local level_mask1,level_mask2=cam_to_level_mask()
  enemies_levels_cleared1,enemies_levels_cleared2=bor(enemies_levels_cleared1,level_mask1),bor(enemies_levels_cleared2,level_mask2)
  save_game()
 end
end

--
function enemies_reset()
 pickups_reset()
 
 for k,e in pairs(enemies) do
  e.active,e.spawned=false,false
 end
 
 enemies_next,enemies_active_count,enemies_spawn_x=1,0,0
 
 enemies_update_level_spawn()
end

--
function enemies_update()
 for k,e in pairs(enemies) do
  if e.active then
   e.t+=one_frame
   
   local damaged=(e.damaged_timer>0)
   
   if damaged then
    e.damaged_timer-=one_frame
   end
   
   if not damaged or e.type.isboss then
    e.anim_index=next_i(e.anim,e.anim_index)
   end
   
   enemy_check_player(e)
   
   if not e.type.no_collison then
    e.cr=collision_checks(e.x,e.y,e.vx,e.vy,-e.size,e.size,-e.size,e.size)
    e.x,e.y=e.cr.x,e.cr.y
   end
  
   if (e.x<target_cam_x+8)e.x=target_cam_x+8
   if (e.x>target_cam_x+120)e.x=target_cam_x+120
   if (e.y<target_cam_y+8)e.y=target_cam_y+8
   if (e.y>target_cam_y+120)e.y=target_cam_y+120
  
   if(e.type.update)e.type.update(e)
   
   if(e.anim_flip and e.vx>.01)e.anim_flip=false
   if(not e.anim_flip and e.vx<-.01)e.anim_flip=true
  end
 end
 
end

--
function enemies_level_draw()
 --[[]]
 for k,e in pairs(enemies) do
  if e.spawned then
   local mx,my=map_coords(e.spawn_x,e.spawn_y)
   local tile_spr=mget(mx-1,my)
   spr(tile_spr,e.spawn_x,e.spawn_y)
  end
 end
 --]]
 
 if level_boss_arena then 
  rect(cam_x+10,cam_y+10,cam_x+118,cam_y+118,8)
  rect(cam_x+8,cam_y+8,cam_x+120,cam_y+120,8)
 end
end

--
function enemies_draw()
 
 for k,e in pairs(enemies) do
  if e.active then
   if not e.type.isboss then
    for i=1,15 do
     pal(i,(e.damaged_timer>0) and 7 or 0)
    end
    
    enemy_draw(e, 1, 0)
    enemy_draw(e,-1, 0)
    enemy_draw(e, 0, 1)
    enemy_draw(e, 0,-1)
    enemy_draw(e, 1, 1)
    enemy_draw(e,-1,-1)
    enemy_draw(e,-1, 1)
    enemy_draw(e, 1,-1)
   end
   
   if e.damaged_timer>0 then
    pal(7,8)
    pal(8,7)
   else
    pal()
   end
   
   if(not e.type.isboss)enemy_draw(e,0,0)
   
   if(e.type.draw)e.type.draw(e)
  end
 end

 pal()
end


-- pickups
pickups={}

for i=1,12 do
 add(pickups,{active=false})
end

--
function pickups_reset()
 for k,pu in pairs(pickups) do
  pu.active=false
 end

 pickups_next,pickups_active_count=1,0
end

--
function pickups_check_level_cleared()
 local level_mask1,level_mask2=cam_to_level_mask()
 pickups_levels_cleared1,pickups_levels_cleared2=bor(pickups_levels_cleared1,level_mask1),bor(pickups_levels_cleared2,level_mask2)
 save_game()
end

--
function pickups_level_cleared()
 local level_mask1,level_mask2=cam_to_level_mask()
 return band(pickups_levels_cleared1,level_mask1)!=0 or band(pickups_levels_cleared2,level_mask2)!=0
end

--
function pickups_spawn(x,y)
 if(pickups_level_cleared())return
 
 local pu,i=find_next_i(pickups,pickups_next,pickups_active_count)

 if pu then
  pickups_next=i
  
  pickups_active_count+=1
  pu.active,pu.x,pu.y,pu.t=true,x,y,0  
 end
end

--
function pickups_update()
 for k,pu in pairs(pickups) do
  if pu.active then
   pu.t+=one_frame
   
   -- check for player touch
   if pu.x+3<player_x-3 or
      pu.x-3>player_x+3 or
      pu.y+3<player_y-3 or
      pu.y-3>player_y+3 then
   else
    sfx(4)
    pickups_active_count-=1
    pu.active=false
    pickups_check_level_cleared()
    if lup_range>=3 and lup_power>=3 and lup_rate>=3 and lup_health>=3 then
     player_health=lup_healths[lup_health+1]
    else
     player_level_up_menu()
    end
   end
  end
 end
end

--
function pickups_draw()
   
 for k,pu in pairs(pickups) do
  if pu.active then
   pal(14,0)
   spr(5,pu.x-3,pu.y-5-2*sin(pu.t*2))
   pal()
  end
 end
end


-- level

function level_draw()
 map(0,0,0,0,128,64,0x20)
 enemies_level_draw()
end

-- front end
fe_view={}

fe_time,fe_button_presses,fe_button_impulse,fe_fullscale=0,0,0,false

--
fe_view.start=function()
end

--
fe_view.update=function()
 fe_time+=one_frame
 
 if not fullscale then
  if(fe_time*fe_time>.5)fe_fullscale=true
 end
 
 if shoot_button.time_since_press<.2 or dash_button.time_since_press<.2 then
  shoot_button:button_consume()
  dash_button:button_consume()
  fe_button_presses+=.4
  fe_button_impulse=.1
  
  sfx(6)
  
  if fe_button_presses>3 then
   current_view=game_view
   current_view.start()
  end
 end
 
 
 if fe_button_presses>0 then
  fe_button_impulse,fe_button_presses=max(0,fe_button_impulse-one_frame),max(0,fe_button_presses-one_frame)
  
  parts_spawn(4+rnd(4),64,88,-2+rnd(4),-2-rnd(4),.97,36*min(1,fe_button_presses)+50*fe_button_impulse,-1-rnd(.5),8,7)
 end
 
 parts_update()
end

--
function draw_big_skull(ox,oy,s)
 pal(14,0)
 local spr1x,spr1y=spr_index_to_xy(12)
 sspr(spr1x,spr1y,16,16,64-s/2+ox,64-s/2+oy,s,s)
end

--
fe_view.draw=function()
 --[[
 cls()
 map(0,0,0,0,128,64)
 --]]
 
 --[[
 for r=100,0,-4 do
  v=r/64+fe_time
  circfill(64+8*sin(v),77+8*cos(v),r,flr(r/8%2)*7)
 end 
 --]]
 
 --[[]]
  local t=fe_time/2
  for r=220,0,-8 do
   circfill(61+cos(t)*r*.55,77+sin(t)*r*.55,r,flr(r/8%2)*7)
  end 
 --]]
 
 parts_draw()
 
 local scale=fe_fullscale and 1 or 2*min(.5,fe_time*fe_time)
 
 draw_big_skull(rnd(4*fe_button_presses)-2,rnd(4*fe_button_presses)+14,64*scale)

 pal()
 print_outline("skulldude",64,40*scale-8,8,0)
 print_outline("press any button to start!",64,172-64*scale,8,0)
 print_outline("guerragames 2017",64,181-60*scale,8,7)

end

-- game view
game_view={}

--
game_view.start=function()
 cam_reset()
 enemies_reset()
 player_reset()
end

--
game_view.update=function()
 if(not game_finished and not player_gameover)game_time+=one_frame

 update_screeneffects()
 if screen_flash_timer>0 then
  return
 end
 
 if level_up_menu then
  player_level_up_update()
  return
 end
 
 --[[debug cheats
 if btnp(0,1) then
  if flr(player_x/128)>0 then
   enemies_check_level_cleared()
   target_cam_x-=128
   cam_x-=128
   player_x-=128
   enemies_reset()
  end
 end
 if btnp(1,1) then
  if flr(player_x/128)<7 then
   enemies_check_level_cleared()
   target_cam_x+=128
   cam_x+=128
   player_x+=128
   enemies_reset()
  end
 end
 if btnp(2,1) then
  if flr(player_y/128)>0 then
   enemies_check_level_cleared()
   target_cam_y-=128
   cam_y-=128
   player_y-=128
   enemies_reset()
  end
 end
 if btnp(3,1) then
  if flr(player_y/128)<3 then
   enemies_check_level_cleared()
   target_cam_y+=128
   cam_y+=128
   player_y+=128
   enemies_reset()
  end
 end
 --]]

 parts_update()
 player_update()
 enemies_update()
 ebs_update()
 cam_update()
 pbullets_update()
 pickups_update() 
end

--
function drawswirls(scale,os,c)
 for r=0,90*scale do
  local q=.05*sin(r/32-player_t)
  for a=0,1,.1 do
   circfill(64+r*cos(a+q),64+r*sin(a+q),r/14+os,c)
  end
 end
end

--
game_view.draw=function()
 cls()
 
 --if(not game_finished)game_finished_timer=0
 --game_finished=true
 if game_finished then
  local scale=min(2,game_finished_timer)/2
  drawswirls(scale,0,8)
  local s=max(0,64*scale+24*sin(player_t/2))
  draw_big_skull(8*cos(player_t/4),8*sin(player_t),s)
  
  pal()
  player_draw_hud()
  
  print_outline("congratulations!",64,56,8,0)
  print_outline("skulldude's reign of terror",64,64,8,0)
  print_outline("prevails!",64,72,8,0)
  print_outline("deaths:"..player_deaths,64,88,8,0)
  return
 end
 
 if screen_flash_timer>0 then
  cls(screen_flash_color)
  return
 end
 
 camera(cam_x+cam_shake_x,cam_y+cam_shake_y)
 
 level_draw()
 
 player_draw_crosshair()
 enemies_draw()
 parts_draw()
 pickups_draw()
 player_draw()
 ebs_draw()
 
 camera()
 player_draw_hud()
 
 if level_up_menu then
  player_level_up_draw()
 end
end


--

current_view=fe_view
current_view.start()

--
function _init()
 music(0)
 --menuitem(1,"level up!",player_level_up_menu)
 menuitem(1,"reset progress!?",reset_game)

 load_game()
end

--
function _update60()
 shoot_button:button_update()
 dash_button:button_update()
 
 current_view.update()
end

--
function _draw()
 current_view.draw()
 
 --print_outline("mem:"..stat(0),1,116,0,7,align_l) 
 --print_outline("cpu:"..stat(1),1,122,0,7,align_l) 
end
