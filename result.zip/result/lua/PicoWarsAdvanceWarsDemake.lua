-- pico wars
-- by lambdanaut
-- https://lambdanaut.com
-- https://lambdanaut.itch.io/
-- https://twitter.com/lambdanaut
-- thanks to nintendo for making advance wars
-- special thanks to caaz for making the original picowars that gave me so much inspiration along the way

palette_orange = "orange star★"
palette_blue = "blue moon●"

team_index_to_palette = {
  palette_orange,
  palette_blue
}

team_icon = {}

dead_str = 'dead'

last_checked_time = 0
delta_time = 0
unit_id_i = 0
attack_timer = 0
end_turn_timer = 0
memory_i = 0x1000
in_splash_screen = true
map_index_selected = 0
ai_index_selected = 0
splash_option_selected = 0

map_index_options = {"eezee island", "arbor island", "lil highland", "long island", "duble truble", "haard knocks"}
map_index_mapping = { {{57, 1, 39, 18}, 12}, {{0, 0, 14, 21}, 12}, {{15, 0, 15, 12}, 3}, {{31, 0, 26, 25}, 12}, {{15, 14, 15, 15}, 3}, {{97, 0, 30, 19}, 12} }
ai_index_options = {"vs ai", "vs human"}


function _init()
  load_assets()
end

function _update()
  t = time()
  delta_time = t - last_checked_time
  last_checked_time = t
  attack_timer += delta_time
  end_turn_timer += delta_time

  btnp4 = btnp(4)
  btnp5 = btnp(5)

  if in_splash_screen then
    if splash_option_selected == 0 then 
      if btnp(0) then 
        map_index_selected -= 1 
        sfx(6)
      elseif btnp(1) then 
        map_index_selected += 1
        sfx(6)
      end
    elseif btnp(0) or btnp(1) then 
      ai_index_selected += 1 
      sfx(6)
    end
    if btnp(2) or btnp(3) then
      splash_option_selected += 1
        sfx(6)
    end
    map_index_selected = map_index_selected % 6
    ai_index_selected = ai_index_selected % 2
    splash_option_selected = splash_option_selected % 2

    if btnp4 or btnp5 then 
      in_splash_screen = false 

      current_map = make_war_map(map_index_mapping[map_index_selected+1][1])
      map_bg_color = map_index_mapping[map_index_selected+1][2]
      players_human[1] = not (btnp(1) and btnp(2))
      players_human[2] = ai_index_selected == 1 and players_human[1]

      current_map:load()
      make_cam()
      end_turn()
      selector_init()
      players_turn_team = players[players_turn]
    end
  else
    selector_update()
    cam:update()

    for unit in all(units) do
      unit:update()
    end
  end
end

function _draw()
 
  cls()

  if in_splash_screen then
   
    rectfill(0, 0, 128, 128, 0)
    spr(160, 31, 29, 8, 2)
    print("version 0.5", 42, 40, 9)
    for y = 0, 1 do
      for x = 0, 1 do
        spr(168 + last_checked_time*2 % 2, 24 + x*70, 54 + y*20, 1, 2, x==1)
      end
    end
    rectfill(38, 58 + (splash_option_selected) * 19, 86, 64 + (splash_option_selected) * 19, 4)
    print(map_index_options[map_index_selected+1], 39, 59, 7)
    print(ai_index_options[ai_index_selected+1], 53 + ai_index_selected*-6, 78, 7)
    print("press ❎ to play", 32, 98, 7)
  elseif game_over then 
    camera(0, 0)
    local game_over_text = "victory!"
    if game_over == 2 then game_over_text = " defeat" end
    local game_over_text2 = "your army capture their hq"
    if game_over == 2 then game_over_text2 = "the enemy captured your hq" end
    rectfill(0, 0, 128, 128, (players_turn - 1)*2)
    print(game_over_text, 48, 58, 9)
    line(46, 64, 79, 64, 9)
    print(game_over_text2, 14, 70, 7)
    print("press enter and reset cart", 14, 78, 7)
  else
    current_map:draw()

    for structure in all(structures) do
      structure:draw()
    end
    for i = 1, 2 do
      local hq = players_hqs[i]
      set_palette(hq.team)
      spr(67, hq.p[1], hq.p[2] - 11)
      pal()
    end
    sort_table_by_f(units, function(u1, u2) return u1.p[2] > u2.p[2] end)
    for unit in all(units) do
      unit:draw()
    end
    selector_draw()
    if active_end_turn_coroutine and costatus(active_end_turn_coroutine) == dead_str then
      active_end_turn_coroutine = nil
    elseif active_end_turn_coroutine then
      coresume(active_end_turn_coroutine)
    end
    if not active_end_turn_coroutine then
      ai_update()
    end
  end
end

players_turn = 0
players = {}
players_human = {}
players_co_name = {}
players_hqs = {} 
players_gold = {0, 0}
players_units_lost = {0, 0}
players_units_built = {0, 0}
players_unit_types = {{}, {}}
players_music = {}
players_co_icon = {}
units = {}
turn_i = 0
function end_game()
  game_over = players_turn
end
function end_turn()
 
  players_turn = players_turn % 2 + 1
  players_turn_team = players[players_turn]
 
  turn_i += 2 - players_turn

  for unit in all(units) do
    unit.is_resting = false

   
    local struct = get_struct_at_pos(unit.p, players_turn_team)
    if unit.team == players_turn_team and struct then
      unit.hp = min(unit.hp + 2 + unit.struct_heal_bonus, 10)
    end
  end

  for struct in all(structures) do
    if struct.team == players_turn_team then
     
      players_gold[players_turn] += 1
    end
  end

  selector_p = players_hqs[players_turn].p

 
  active_end_turn_coroutine = cocreate(end_turn_coroutine)

end

function ai_update()
  if players_human[players_turn] then return end 
  
  if not active_ai_coroutine then
    active_ai_coroutine = cocreate(ai_coroutine)
  elseif costatus(active_ai_coroutine) == dead_str then
    active_ai_coroutine = nil
  else
    coresume(active_ai_coroutine)
  end

end

function ai_coroutine()
  ai_units_ranged = {}
  ai_units_infantry = {}
  other_ai_units = {}
  non_ai_units = {}
  for u in all(units) do
    if u.team == players_turn_team then
      if u.ranged then
        add(ai_units_ranged, u)
      elseif u.index < 3 then
        add(ai_units_infantry, u)
      else
        add(other_ai_units, u)
      end
    else
      add(non_ai_units, u)
    end
  end
  ai_units = {}
  merge_tables(ai_units, ai_units_ranged) 
  merge_tables(ai_units, ai_units_infantry) 
  merge_tables(ai_units, other_ai_units) 

  enemy_attackables = {}
  if #ai_units_ranged > 0 then
    for u2 in all(non_ai_units) do
      if u2.ranged then merge_tables(enemy_attackables, u2:ranged_attack_tiles())
      else
        local u2_movable = u2:get_movable_tiles()[1]
        for t in all(u2_movable) do
          for u2_attackable in all(get_tile_adjacents(t)) do
            add(enemy_attackables, u2_attackable)
          end
        end
      end
      yield()
    end
  end

  for i = 1, 3 do
    for u in all(ai_units) do 
      if u.active and not u.is_resting then
       
        local unit_movable_tiles = u:get_movable_tiles()[1]
        add(unit_movable_tiles, u.p)

        local has_attacked

       
        if u.ranged then
         
          local ranged_targets = u:targets()

          if #ranged_targets > 0 then
            local best_target_u
            local best_target_value = -32767 
            for u2 in all(ranged_targets) do
              local attack_value = ai_calculate_attack_value(u, u2)
              if attack_value > best_target_value then
                best_target_value = attack_value
                best_target_u = u2
              end
            end

            if best_target_u then
              attack_coroutine_u1 = u
              attack_coroutine_u2 = best_target_u
              attack_coroutine()
              has_attacked = true
            end
          end
        elseif (u.index > 2 or not get_struct_at_pos(u.p, nil, players_turn_team)) then
          local attackables = {}
          for t in all(unit_movable_tiles) do
            attackables[t] = u:targets(t)
          end
          local best_fight_u
          local best_fight_pos
          local best_fight_value = -32767 
          for t, attackable_unit in pairs(attackables) do
            for u2 in all(attackable_unit) do
             
              local attack_value = ai_calculate_attack_value(u, u2, t)
              if attack_value >= 0 and attack_value > best_fight_value then
                best_fight_value = attack_value
                best_fight_u = u2
                best_fight_pos = t
              end
            end
          end

          if best_fight_pos then
           
            ai_move(u, best_fight_pos)

            attack_coroutine_u1 = u
            attack_coroutine_u2 = best_fight_u
            attack_coroutine()
            has_attacked = true

            u:complete_move()
          end
        end

        if not has_attacked then
         
          local enemy_hq = players_hqs[3 - players_turn].p
          local goal = enemy_hq

          if manhattan_distance(goal, u.p) < 5 and u.index > 2 then
           
            goal = players_hqs[players_turn].p
          elseif u.hp < 4 or (u.hp < 9 and get_struct_at_pos(u.p, players_turn_team, nil, nil, 3)) then
           
           
            local nearest_struct
            local nearest_struct_d = 32767
            for struct in all(structures) do
              local d = manhattan_distance(u.p, struct.p)
              local unit_at_struct = get_unit_at_pos(struct.p)
              if d < nearest_struct_d and struct.team == players_turn_team and (struct.type == 1 or struct.type == 2) and
                  (not unit_at_struct or unit_at_struct.id == u.id) then
                nearest_struct = struct
                nearest_struct_d = d
              end
            end
            if nearest_struct then
              goal = nearest_struct.p
            end
          elseif u.index < 3 then
           
            local nearest_struct
            local nearest_struct_d = 32767
            for struct in all(structures) do
              local struct_weight = 0
              if struct_type ~= 2 then struct_weight = 3 end 
              local d = manhattan_distance(u.p, struct.p) - struct_weight
              local unit_at_struct = get_unit_at_pos(struct.p)
              if d < nearest_struct_d and struct.team ~= players_turn_team and
                  (not unit_at_struct or (unit_at_struct.id == u.id or unit_at_struct.team ~= players_turn_team)) then
                nearest_struct = struct
                nearest_struct_d = d
              end
            end
            if nearest_struct then
              goal = nearest_struct.p
            end

          end

          local goal_path = ai_pathfinding(u, goal, true, true)
          local path = {}
          if u.ranged then
            for t in all(goal_path) do
              if point_in_table(t, enemy_attackables) then
                insert(path, 1, t)
              else
                add(path, t)
              end
            end
          else
            path = goal_path
          end

          local p
          for t in all(path) do
            if point_in_table(t, unit_movable_tiles) and (u.index < 3 or not points_equal(t, enemy_hq)) then
              p = t
            end
          end
          
          if p then
            ai_move(u, p)

            if u.index < 3 then
             
              local struct = get_struct_at_pos(u.p, nil, players_turn_team)
              if struct then
                struct:capture(u)
              end
            end

            u:complete_move()
          end
        end

      end
    end
  end

  for struct in all(structures) do
    if struct.type == 3 and struct.team == players_turn_team and not get_unit_at_pos(struct.p) then
      local infantry_count = 1
      local mech_count = 1
      local total_unit_count = 1
      local unit_counts = {0, 0, 0, 0, 0, 0, 0, 0}

      for u in all(units) do
        if u.team == players_turn_team then
          unit_counts[u.index] += 1
          total_unit_count += 1
        end
      end

      local to_build
      for i = #players_unit_types[players_turn], 1, -1 do
       
       
        local unit_type = players_unit_types[players_turn][i]
        if unit_type.cost <= players_gold[players_turn] then
          to_build = i
          if unit_counts[i] * 100 / total_unit_count < unit_type.ai_unit_ratio then
            break
          end
        end
      end

      if to_build then
        struct:build(to_build)
        selector_p = copy_v(struct.p)
      end

    end
  end

  for i=1,35 do
    yield()
  end

  end_turn()

end
  
function ai_move(u, p)
  local path = ai_pathfinding(u, p)
  u:move(path)
  while u.is_moving do
    selector_p = copy_v(u.p)
    yield()
  end
end

function ai_pathfinding(unit, target, ignore_enemy_units, weigh_friendly_units)
 
  local tiles_to_explore = {}
  local tiles_to_explore = prioqueue.new()
  tiles_to_explore:add(unit.p, manhattan_distance(unit.p, target))
  local current_tile

  local to_explore_parents = {} 
  local to_explore_travel = {unit.travel} 

  local g_scores = {} 
  g_scores[unit.p] = 0

  while #tiles_to_explore.values > 0 and #tiles_to_explore.values < 100 do
   


   
   
    current_tile = tiles_to_explore:pop()
    local current_t = current_tile[1]

    if points_equal(current_t, target) then
     
      local return_path = {current_t}
      while point_in_table(current_t, to_explore_parents, true) do

        current_t = table_point_index(to_explore_parents, current_t)

        if point_in_table(current_t, return_path) then
          return {unit.p}
        end

        insert(return_path, 1, current_t)
      end
      return return_path
    end
   
    local current_t_g_score = table_point_index(g_scores, current_t)
   
    for t in all(get_tile_adjacents(current_t)) do

      local unit_at_t = get_unit_at_pos(t)
      if ignore_enemy_units or not unit_at_t or unit_at_t.team == unit.team then
        local tile_m = unit:tile_mobility(mget(t[1] / 8, t[2] / 8))

        local friendly_units_weight = 0
        if weigh_friendly_units and unit_at_t and unit_at_t.team == unit.team then friendly_units_weight = 2 end

        local new_g_score = current_t_g_score + tile_m + friendly_units_weight
 
        if new_g_score < table_point_index(g_scores, t) and tile_m < 255 then
          local tiles_to_explore_point_i_or_nil = point_in_table(t, tiles_to_explore.values)

          to_explore_parents[t] = current_t
          g_scores[t] = new_g_score
          local new_f_score = new_g_score + manhattan_distance(t, target)
          if not tiles_to_explore_point_i_or_nil then
           
            tiles_to_explore:add(t, new_f_score)
          end
        end
      end
    end
  end
 
  return {unit.p}
end

function manhattan_distance(p, target)
  return abs(p[1] - target[1]) / 8 + abs(p[2] - target[2]) / 8
end

function ai_calculate_attack_value(u, u2, tile)
  local damage_done = u:calculate_damage(u2)
  local gain = (damage_done + min(0, u2.hp - damage_done)) * u2.cost
  local loss
  if u.ranged then
    loss = 0
  else
    local damage_loss = u2:calculate_damage(u, true, tile, u2.hp - damage_done)
    loss = (damage_loss + min(0, u.hp - damage_loss)) * u.cost
  end
  local s = get_struct_at_pos(u2.p)
  if s and u.index < 3 then
    gain += 5
  end

  return gain - loss
end

function get_unit_at_pos(p)
 
  for unit in all(units) do
    if points_equal(p, unit.p) then
      return unit
    end
  end
end

function get_struct_at_pos(p, team, not_team, struct_type, not_struct_type)
  for struct in all(structures) do
    if points_equal(p, struct.p) and (not team or struct.team == team) and (not not_team or struct.team ~= not_team) and (not struct_type or struct.type == struct_type) and (not not_struct_type or struct.type ~= not_struct_type) then
      return struct
    end
  end
end

function get_selection(p, include_resting)
  local unit = get_unit_at_pos(p)
  if unit and (include_resting or not unit.is_resting) then
   
    return {0, unit}
  end

  local tile = mget(p[1] / 8, p[2] / 8)

  if fget(tile, 1) and fget(tile, 4) then
   
    return {1, tile}
  end
 
  return {2, tile}
end

function attack_coroutine()
  attack_coroutine_u1.currently_attacking = true
  attack_coroutine_u2.currently_attacking = true

  selector_p = copy_v(attack_coroutine_u2.p)
  attack_timer = 0
  local damage_done = attack_coroutine_u1:calculate_damage(attack_coroutine_u2)
  attack_coroutine_u2.hp = max(0, attack_coroutine_u2.hp - damage_done)
  sfx(attack_coroutine_u1.combat_sfx)
  while attack_timer < 1.4 do
    print("-" .. damage_done, attack_coroutine_u2.p[1], attack_coroutine_u2.p[2] - 4 - attack_timer * 8, 8)
    yield()
  end
 
  if attack_coroutine_u2.hp > 0 and not attack_coroutine_u1.ranged and not attack_coroutine_u2.ranged then
    selector_p = copy_v(attack_coroutine_u1.p)
    attack_timer = 0
    damage_done = attack_coroutine_u2:calculate_damage(attack_coroutine_u1)
    attack_coroutine_u1.hp = max(0, attack_coroutine_u1.hp - damage_done)
    sfx(attack_coroutine_u2.combat_sfx)
    while attack_timer < 1.4 do
      print("-" .. damage_done, attack_coroutine_u1.p[1], attack_coroutine_u1.p[2] - 4 - attack_timer * 8, 8)
      yield()
    end
  end

 
  if attack_coroutine_u1.hp < 1 then
    explode_at = attack_coroutine_u1.p
    attack_coroutine_u1:kill()
  else
    -- rest
    attack_coroutine_u1:complete_move()
  end

  if attack_coroutine_u2.hp < 1 then
    explode_at = attack_coroutine_u2.p
    attack_coroutine_u2:kill()
  end

  if explode_at then
    attack_timer = 0
    while attack_timer < 1.5 do
      spr(71 + flr(attack_timer*6), explode_at[1], explode_at[2] - 3 - attack_timer * 10)
      yield()
    end
  end
  explode_at = nil

  attack_coroutine_u1.currently_attacking = false
  attack_coroutine_u2.currently_attacking = false
end

end_turn_coroutine = function()
  end_turn_timer = 0

 
  sfx(7)
  music(-1, 300)

  local played_music = false

  while end_turn_timer < 1.6 do
    set_palette(players_turn_team)
    rectfill(cam.p[1], cam.p[2] + 51, cam.p[1] + 128, cam.p[2] + 76, 9)
    line(cam.p[1], cam.p[2] + 77, cam.p[1] + 128, cam.p[2] + 77, 8)
    local rect_offset = 0
    if turn_i > 9 then
      rect_offset = 4
    end
    rectfill(cam.p[1] + 57, cam.p[2] + 61, cam.p[1] + 77 + rect_offset, cam.p[2] + 67, 8)
    print("day " .. turn_i, cam.p[1] + 58, cam.p[2] + 62, 2)
    pal()

    if not played_music and end_turn_timer > 0.7 then
     
      music(players_music[players_turn], 500, 12)
      played_music = true
    end

    yield()
  end

end

function make_cam()
  cam = {}

 
  cam.p = {selector_p[1] - 64, selector_p[2] - 64}

  cam.update = function (self) 
   
    local shake_x = 0
    local shake_y = 0
    if explode_at and attack_timer < 1 then
      shake_x = rnd((1 - attack_timer) * 9) - 1
      shake_y = rnd((1 - attack_timer) * 9) - 1
    end

    local move_x = (selector_p[1] - 64 - self.p[1]) / 15
    local move_y = (selector_p[2] - 64 - self.p[2]) / 15

    self.p[1] += move_x
    self.p[2] += move_y
    camera(self.p[1] + shake_x, self.p[2] + shake_y)
  end

end

function selector_init()
  selector_p = selector_p or {0, 0}

  selector_time_since_last_move = 0

 
  selector_movable_tiles = {}

 
  selector_arrowed_tiles = {}

  selector_prompt_selected = 1
  selector_prompt_options = {}
  selector_prompt_options_disabled = {}

 
  selector_prompt_texts = {}
  selector_prompt_texts[2] = {}
  add(selector_prompt_texts[2], "rest")
  add(selector_prompt_texts[2], "attack")
  add(selector_prompt_texts[2], "capture")
  selector_prompt_texts[4] = {}
  add(selector_prompt_texts[4], "cancel")
  add(selector_prompt_texts[4], "end turn")
  selector_prompt_texts[8] = {} 

  for unit_type in all(players_unit_types[players_turn]) do
   
    add(selector_prompt_texts[8], unit_type.cost .. "g: " .. unit_type.type)
  end

 
  selector_attack_targets = {}

 
 
end

function selector_update()
 
  if not players_human[players_turn] then return end

 
  if not selector_selecting or selector_selection_type == 0 then
    selector_move()
  end

  if selector_selecting then
   

   
    local arrow_val
    if btnp(2) or btnp(1) then arrow_val = 1 elseif btnp(3) or btnp(0) then arrow_val = -1 end

    if not btn(5) and selector_selection_type == 5 then
     
      selector_stop_selecting()

    elseif not btn(4) and selector_selection_type == 6 then
     
      selector_stop_selecting()

    elseif btnp4 then 
      if selector_selection_type == 0 then
       
        local unit_at_pos = get_unit_at_pos(selector_p)
        if unit_at_pos and unit_at_pos.id ~= selector_selection.id then
         
          sfx(4)
        else
         
          selector_selection:move(selector_arrowed_tiles)

          selector_selection_type = 1 
          return
        end
      elseif selector_selection_type == 2 then
       
        if selector_prompt_options[selector_prompt_selected] == 1 then
          selector_selection:complete_move()
          sfx(1)
          selector_stop_selecting()
        elseif selector_prompt_options[selector_prompt_selected] == 2 then
          selector_start_attack_selection()
        else
          selector_selection:capture()
          selector_stop_selecting()
        end
      elseif selector_selection_type == 3 then
       

       
        attack_coroutine_u1 = selector_selection
        attack_coroutine_u2 = selector_attack_targets[selector_prompt_selected]
        active_attack_coroutine = cocreate(attack_coroutine)
        selector_selection_type = 7
      elseif selector_selection_type == 4 then
       

        selector_stop_selecting()
        if selector_prompt_selected == 2 then
          end_turn()
        end
      elseif selector_selection_type == 8 then
       

        if players_gold[players_turn] > 0 then
         
          selector_selection:build(selector_prompt_selected)
          selector_stop_selecting()
        end
      end
    elseif btnp5 and selector_selection_type ~= 5 and selector_selection_type ~= 7 then
     
     
      if 0 < selector_selection_type and selector_selection_type < 4 then
       
      
        sfx(5)
        selector_selection:unmove()
        selector_p = selector_selection.p
      end

      selector_stop_selecting()

    elseif selector_selection_type == 2 or selector_selection_type == 4 or selector_selection_type == 8 then
      selector_update_prompt(arrow_val)
    elseif selector_selection_type == 3 then
     
     
      selector_update_prompt(arrow_val)
      selector_p = selector_attack_targets[selector_prompt_selected].p
    end

  else
   

    local selection = {}
    if btnp4 then
      selection = get_selection(selector_p)
    elseif btn(5) then
      selection = get_selection(selector_p, true)
    end

    if selection[1] == 0 then
     
      selector_selection = selection[2]
      if btnp4 then
        sfx(2)
        selector_selecting = true
        if selector_selection.team == players_turn_team then
         
          local movable_tiles = selector_selection:get_movable_tiles()
          merge_tables(movable_tiles[1], movable_tiles[2])
          selector_movable_tiles = movable_tiles[1]
          selector_selection_type = 0
          selector_arrowed_tiles = {selector_selection.p}
        else
         
          selector_movable_tiles = selector_selection:get_movable_tiles()[1]
          selector_selection_type = 6
        end
      elseif btnp5 and selector_selection.ranged then
        sfx(2)
        selector_selecting = true
        selector_movable_tiles = selector_selection:ranged_attack_tiles()
        selector_selection_type = 5
      end
    elseif btnp4 and selection[1] == 1 and not get_unit_at_pos(selector_p) then
     
      local struct = get_struct_at_pos(selector_p, players_turn_team, nil, 3)
      if struct then
          selector_selecting = true
          selector_selection = struct
          selector_start_build_unit_prompt()
      end

    elseif btnp4 then
     
      selector_selecting = true
      selector_start_menu_prompt()
    end

  end

end

function selector_draw()
 
  local draw_prompt 
  if players_human[players_turn] then 
    if selector_selecting then
     

      local flip = last_checked_time * 2 % 2 
      if selector_selection_type == 0 or selector_selection_type == 5 or selector_selection_type == 6 then

       

        for i, t in pairs(selector_movable_tiles) do
          if selector_selection_type == 5 then
           
            pal(7, 8)
          end
          spr(flip + 3, t[1], t[2], 1, 1, flip > 0.5 and flip < 1.5, flip > 1)
          if selector_selection_type == 5 then
            pal(7, 7)
          end
        end

        if selector_selection_type == 0 then
         
          selector_draw_movement_arrow()
        end

      elseif selector_selection_type == 3 then
       
        for unit in all(selector_attack_targets) do
          pal(7, 8)
          spr(flip + 3, unit.p[1], unit.p[2], 1, 1, flip > 0.5 and flip < 1.5, flip > 1)
          pal(7, 7)
        end

      elseif selector_selection_type == 2 or selector_selection_type == 4 or selector_selection_type == 8 then
       
        draw_prompt = true
      elseif selector_selection_type == 7 then
        if costatus(active_attack_coroutine) == dead_str then
          selector_stop_selecting()
        else
          coresume(active_attack_coroutine)
        end
      end

    end
    
    if selector_selection_type ~= 7 and selector_selection_type ~= 8 then
     

      local frame_offset = flr(last_checked_time * 2.4 % 2)
      local offset = 8 - frame_offset * 3

      spr(frame_offset, selector_p[1], selector_p[2])
      spr(2, selector_p[1] + offset, selector_p[2] + offset)
    end
  end

  if last_checked_time % 3 > 1.5 then
    for u in all(units) do
      if u.hp < 10 and not u.currently_attacking then
        set_palette(u.team)
        rectfill(u.p[1] + 1, u.p[2], u.p[1] + 5, u.p[2] + 6, 8)
        print(u.hp, u.p[1] + 2, u.p[2] + 1, 0)
        pal()
      end
    end
  else
    for struct in all(structures) do
      if struct.capture_left < 20 then
        local rect_offset = 0
        if struct.capture_left > 9 then
          rect_offset = 4
        end
        rectfill(struct.p[1] + 1, struct.p[2], struct.p[1] + 5 + rect_offset, struct.p[2] + 6, 6)
        print(struct.capture_left, struct.p[1] + 2, struct.p[2] + 1, 0)
      end
    end
  end

 
  local tile = mget(selector_p[1] / 8, selector_p[2] / 8)
  local tile_info = get_tile_info(tile)
  local struct_type = tile_info[3] 
  set_palette(players_turn_team)
  local x_corner = cam.p[1]
  local y_corner = cam.p[2]
  local gold = players_gold[players_turn]
  local team_name = players_turn_team
  if last_checked_time % 4 < 2 then team_name = players_co_name[players_turn] end
  if gold < 10 then gold = "0" .. gold end
  rectfill(x_corner, y_corner, x_corner + 81, y_corner + 19, 8) 
  rectfill(x_corner + 1, y_corner + 1, x_corner + 18, y_corner + 18, 0) 
  rectfill(x_corner + 17, y_corner + 1, x_corner + 26, y_corner + 9, 0) 
  line(x_corner, y_corner + 20, x_corner + 80, y_corner + 20, 2) 
  rectfill(x_corner + 114, y_corner, x_corner + 128, y_corner + 7, 2) 
  rectfill(x_corner + 115, y_corner, x_corner + 128, y_corner + 6, 8)
  print(gold .. "g", x_corner + 116, y_corner + 1, 7 + (flr((last_checked_time*2 % 2)) * 3))
  pal()
  print(team_name, x_corner + 29, y_corner + 3, 0)
  print(tile_info[1], x_corner + 30, y_corner + 12, 0)
  spr(players_co_icon[players_turn], x_corner + 2, y_corner + 2, 2, 2) 
  spr(team_icon[players_turn], x_corner + 19, y_corner + 2, 1, 1) 

 
  local struct = get_struct_at_pos(selector_p)
  if struct then
   
    local type_to_sprite_map = {28, 29, 30}
    tile = type_to_sprite_map[struct_type]
    rectfill(x_corner + 71, y_corner + 11, x_corner + 79, y_corner + 17, 0) 
    local capture_left = struct.capture_left
    if struct.capture_left < 10 then capture_left = "0" .. struct.capture_left end
    print(capture_left, x_corner + 72, y_corner + 12, 7 + (flr((last_checked_time*2 % 2)) * 3))
  end
  spr(tile, x_corner + 20, y_corner + 11, 1, 1) 

  if draw_prompt then
   
   
    selector_draw_prompt()
  end

end

function selector_stop_selecting()
  selector_selecting = false
  selector_selection = nil
  selector_selection_type = nil
  selector_movable_tiles = {}
  selector_arrowed_tiles = {}
  selector_prompt_options = {}
  selector_prompt_options_disabled = {}
  selector_prompt_title = nil
end 

function selector_start_unit_prompt()
  selector_selection_type = 2

  selector_prompt_options = {1} 

 
  selector_attack_targets = selector_selection:targets()
  if #selector_attack_targets > 0 and (not selector_selection.ranged or not selector_selection.has_moved) then 
   
    add(selector_prompt_options, 2)
  end

  local struct = get_struct_at_pos(selector_selection.p, nil, players_turn_team)
  if struct and selector_selection.index < 3 then
   
   
    add(selector_prompt_options, 3)
  end

  selector_prompt_selected = #selector_prompt_options
end

function selector_start_build_unit_prompt()
  selector_selection_type = 8

  selector_prompt_options = {}
  selector_prompt_title = "total gold: " .. players_gold[players_turn]

  for i, unit_type in pairs(players_unit_types[players_turn]) do
    if players_gold[players_turn] >= unit_type.cost then
      add(selector_prompt_options, unit_type.index)
    else
      add(selector_prompt_options_disabled, unit_type.index)
    end
  end

  selector_prompt_selected = 1
  sfx(6)
end

function selector_start_menu_prompt()
  selector_selection_type = 4
  selector_prompt_options = {1,2}
  selector_prompt_selected = 1

  sfx(6)
end

function selector_start_attack_selection()
  selector_selection_type = 3
  selector_prompt_options = {}

  for i = 1, #selector_attack_targets do
    add(selector_prompt_options, i)
  end
  selector_prompt_selected = 1

  sfx(6)
end

function selector_draw_prompt()
  local y_offset = 15
  if selector_selection_type == 8 then y_offset = -25 end
  local prompt_text
  for i, prompt in pairs(selector_prompt_options) do
    local bg_color = 6
    prompt_text = selector_prompt_texts[selector_selection_type][prompt]
    if i == selector_prompt_selected then 
      bg_color = 14
      prompt_text ..= "!"
    end

    draw_msg({selector_p[1], selector_p[2] - y_offset}, prompt_text, bg_color, bg_color == 14)
    y_offset += 9
  end
  for disabled_prompt in all(selector_prompt_options_disabled) do
    prompt_text = selector_prompt_texts[selector_selection_type][disabled_prompt]
    draw_msg({selector_p[1], selector_p[2] - y_offset}, prompt_text, 8)
    y_offset += 9
  end
  if selector_prompt_title then

    draw_msg({selector_p[1], selector_p[2] - y_offset}, selector_prompt_title, 10)
  end
end

function selector_update_prompt(change_val)
  if not change_val then return end

  selector_prompt_selected = (selector_prompt_selected + change_val) % #selector_prompt_options
  if selector_prompt_selected < 1 then selector_prompt_selected = #selector_prompt_options end
  if #selector_prompt_options > 1 then
    sfx(6)
  end
end

function selector_move()
  selector_time_since_last_move += delta_time

 
  local change = selector_get_move_input()

 
 
  if selector_time_since_last_move > 0.1 then
    if change[1] and change[2] then
     
      local move_result = selector_move_to(change[1], 0)
      if move_result then
        selector_move_to(0, change[2])
      end
    elseif change[1] then
     
      selector_move_to(change[1], 0)
    elseif change[2] then
     
      selector_move_to(0, change[2])
    end
  end

end

function selector_get_move_input()
  local x_change
  local y_change
  if btn(0) then x_change = -8 end
  if btn(1) then x_change = 8 end
  if btn(2) then y_change = -8 end
  if btn(3) then y_change = 8 end
  return {x_change, y_change}
end

function selector_move_to(change_x, change_y)
  local new_p = {selector_p[1] + change_x, selector_p[2] + change_y}
  local in_bounds = point_in_rect(new_p, {current_map.r[1]*8, current_map.r[2]*8, current_map.r[3]*8, current_map.r[4]*8})

  if selector_selecting and selector_selection_type == 0 then
   
    in_bounds = in_bounds and point_in_table(new_p, selector_movable_tiles)
  end

  if in_bounds then
    selector_p = new_p

    if selector_selecting and selector_selection_type == 0 then
     
      local point_i = point_in_table(new_p, selector_arrowed_tiles)
      if point_i then
        local new_arrowed_tiles = {}
        for i = 1, point_i - 1 do
          new_arrowed_tiles[i] = selector_arrowed_tiles[i]
        end
        selector_arrowed_tiles = new_arrowed_tiles
      end

     
      add(selector_arrowed_tiles, new_p)

    end

    selector_time_since_last_move = 0
    sfx(0)
    return true
  end
end

function selector_draw_movement_arrow()
 
 
  local last_p = selector_arrowed_tiles[1]
  local last_p_direction
  local next_p
  local next_p_direction
  local current_p
  local opposite_directions
  local sprite
  local flip_x
  local flip_y
  local flip_horizontal = false

  local arrowhead = 90
  local arrowhead_l = 91
  local vertical = 89
  local horizontal = 106
  local curve_w_n = 123
  local curve_n_e = 121
  local curve_n_w = 105

  for i = 2, #selector_arrowed_tiles do
    sprite = nil
    next_p = nil
    flip_x = false
    flip_y = false

    current_p = selector_arrowed_tiles[i]
    if last_p[2] < current_p[2] then last_p_direction = 0 
    elseif last_p[2] > current_p[2] then last_p_direction = 1 
    elseif last_p[1] > current_p[1] then last_p_direction = 2 
    elseif last_p[1] < current_p[1] then last_p_direction = 3 
    end
    next_p = selector_arrowed_tiles[i+1]
    if next_p then
     
      if next_p[2] < current_p[2] then next_p_direction = 0 
      elseif next_p[2] > current_p[2] then next_p_direction = 1 
      elseif next_p[1] > current_p[1] then next_p_direction = 2 
      elseif next_p[1] < current_p[1] then next_p_direction = 3 
      end
    end

    if next_p then
      if next_p_direction == 0 then
        if last_p_direction == 2 then
          sprite = curve_w_n
          flip_x = true
        elseif last_p_direction == 3 then
          sprite = curve_w_n
        end
      elseif next_p_direction == 1 then
        if last_p_direction == 2 then
          sprite = curve_n_e
          flip_y = true
        elseif last_p_direction == 3 then
          sprite = curve_w_n
          flip_y = true
        end
      elseif next_p_direction == 2 then
        if last_p_direction == 0 then
          sprite = curve_n_e
          flip_horizontal = true
        elseif last_p_direction == 1 then
          sprite = curve_n_e
          flip_y = true
          flip_horizontal = false
        end
      elseif next_p_direction == 3 then
        if last_p_direction == 0 then
          sprite = curve_n_w
          flip_x = true
          flip_y = true
          flip_horizontal = true
        elseif last_p_direction == 1 then
          sprite = curve_n_w
          flip_x = true
          flip_horizontal = false
        end
      end
      if not sprite then
        if last_p_direction < 2 then
          sprite = vertical
        else
          sprite = horizontal
          flip_y = flip_horizontal
        end
      end
    else
     
      if last_p_direction == 0 then
        sprite = arrowhead
      elseif last_p_direction == 1 then
        flip_y = true
        sprite = arrowhead
      elseif last_p_direction == 2 then
        sprite = arrowhead_l
        if flip_horizontal then flip_y = true end
      elseif last_p_direction == 3 then
        flip_x = true
        sprite = arrowhead_l
        if flip_horizontal then flip_y = true end
      end
    end

    spr(sprite, current_p[1], current_p[2], 1, 1, flip_x, flip_y)

    last_p = current_p

  end
end

function make_war_map(r)
  war_map = {}

 
  war_map.r = r

  war_map.draw = function(self)
   
    local x = self.r[1]*8
    local y = self.r[2]*8
    local w = self.r[3]*8
    local h = self.r[4]*8
    fill_color = bor(0b00010000, map_bg_color)
    fillp(0b1111011111111101)
    rectfill(x-38, y-38, x+w+45, y+h+45, fill_color)
    fillp(0b1011111010111110)
    rectfill(x-30, y-30, x+w+37, y+h+37, fill_color)
    fillp(0b0101101001011010)
    rectfill(x-24, y-24, x+w+29, y+h+29, fill_color)
    fillp(0b0100000101000001)
    rectfill(x-16, y-16, x+w+23, y+h+23, fill_color)
    fillp(0)
   
    rectfill(x-8, y-8, x+w+15, y+h+15, map_bg_color)

   
    map(self.r[1], self.r[2], self.r[1] * 8, self.r[2] * 8, self.r[3] + 1, self.r[4] + 1)
  end

  war_map.load = function(self)
   
    structures = {}
    for tile_y = self.r[2], self.r[2] + self.r[4]  do
      for tile_x = self.r[1], self.r[1] + self.r[3] do
        local tile_info = get_tile_info(mget(tile_x, tile_y))
        if tile_info[3] then
         
          add(structures, make_structure(tile_info[3], {tile_x * 8, tile_y * 8}, tile_info[4]))
        end
      end
    end
  end

  return war_map
end

function make_structure(struct_type, p, team)
  local struct = {}

 
 
 
 
  struct.type = struct_type
  struct.p = p
  struct.team = team
  struct.capture_left = 20

 
  local struct_sprite
  if struct_type == 1 then 
    struct_sprite = 64
    players_hqs[players_reversed[team]] = struct 
    if team == players[1] then
      selector_p = p
    end
  elseif struct_type == 2 then struct_sprite = 65
  else struct_sprite = 66 end

 
  local active_animator
  if not team then 
   
    team = 5 
    active_animator = false
  end
  struct.animator = make_animator(struct, 0.4, struct_sprite, -58, team, {0, -3}, nil, active_animator)

  struct.draw = function(self)
    rectfill(self.p[1], self.p[2], self.p[1] + 7, self.p[2] + 7, 3)
    self.animator:draw()
  end

  struct.capture = function(self, unit)
    self.capture_left -= unit.hp + unit.capture_bonus
    if self.capture_left <= 0 then
      sfx(10)
      self.team = unit.team
      self.animator.palette = unit.team
      self.animator.animation_flag = true
      self.capture_left = 20
      if self.type == 1 then
       
        end_game()
      end
    else
      sfx(9)
    end
  end

  struct.build = function(self, unit_type_index)
    sfx(11)
    local new_unit = make_unit(unit_type_index, {self.p[1], self.p[2]}, players_turn_team)
    players_gold[players_turn] -= new_unit.cost
    new_unit.is_resting = true
    players_units_built[players_turn] += 1
    add(units, new_unit)
  end

  return struct

end

function make_unit(unit_type_index, p, team)
  local unit = {}

 
  local unit_type = players_unit_types[players_reversed[team]][unit_type_index]
  for k, v in pairs(unit_type) do
    unit[k] = v
  end

  unit_id_i += 1
  unit.id = unit_id_i
  unit.p = p
  if not team then team = palette_orange end
  unit.team = team
  unit.cached_animator_fps = 0.4
  unit.hp = 10

 
  unit.active = true

  -- points to move to one at a time
  -- unit.cached_p = {}
  unit.movement_points = {}
  unit.cached_sprite = unit.sprite
 
  unit.animator = make_animator(
    unit,
    unit.cached_animator_fps,
    unit.sprite,
    64,
    team,
    {0, -1},
    true
    )

  unit.update = function(self)
    if self.is_moving then
      self:update_move()
    end
  end

  unit.draw = function(self)
    if self.is_resting then
      self.animator.palette = 7
    else
      self.animator.palette = self.team
    end
    self.animator:draw()
  end

  unit.get_movable_tiles = function(self, add_enemy_units_to_return)
    travel_offset = travel_offset or 0

    local current_tile
    local tiles_to_explore = {{self.p, self.travel}}
    local movable_tiles = {}
    local tiles_with_our_units = {}
    local explore_i = 0 

    while #tiles_to_explore > explore_i do
      explore_i += 1
      current_tile = tiles_to_explore[explore_i]

     
      local current_t = current_tile[1]

     
      local has_added_to_movable_tiles = false
      for t2 in all(movable_tiles) do
        has_added_to_movable_tiles = points_equal(current_t, t2)
        if has_added_to_movable_tiles then break end
      end
      if not has_added_to_movable_tiles then
        if get_unit_at_pos(current_t) then
          add(tiles_with_our_units, current_t)
        else
          add(movable_tiles, current_t)
        end
      end

     
      for t in all(get_tile_adjacents(current_t)) do

       
        local travel_left = current_tile[2] - self:tile_mobility(mget(t[1] / 8, t[2] / 8))

       
        local checked = false
        for t2 in all(tiles_to_explore) do

          checked = points_equal(t, t2[1]) and travel_left <= t2[2]
          if checked then break end
        end

        local unit_at_tile = get_unit_at_pos(t)
        if travel_left > 0 then
          if not checked and (not unit_at_tile or unit_at_tile.team == self.team) then
            local new_tile = {t, travel_left}
            add(tiles_to_explore, new_tile)
          end
          if add_enemy_units_to_return and unit_at_tile and unit_at_tile.team ~= self.team then
            add (movable_tiles, t)
          end
        end
      end
    end
    return {movable_tiles, tiles_with_our_units}
  end

  unit.move = function(self, points)
    self.cached_p = copy_v(self.p)
    self.is_moving = true
    self.movement_i = 1
    self.movement_points = points
    self.animator.fps = 0.1

   
    self.has_moved = #points > 1

    sfx(self.moveout_sfx)
  end

  unit.update_move = function(self)
    local x_change = 0
    local y_change = 0

    local next_p = self.movement_points[self.movement_i]

    if next_p then
     

      local reached = points_equal(self.p, next_p)

      if reached then
       
        self.movement_i += 1
        return self:update_move()
      end

     
      self.animator.sprite = self.cached_sprite

      if next_p[2] > self.p[2] then 
       
        self.animator.sprite = self.cached_sprite + 32
        y_change = 1
      elseif next_p[2] < self.p[2] then 
        y_change = -1
       
        self.animator.sprite = self.cached_sprite + 16
      elseif next_p[1] > self.p[1] then 
        self.animator.flip_sprite = false
        x_change = 1
      elseif next_p[1] < self.p[1] then 
        self.animator.flip_sprite = true
        x_change = -1
      end

      self.p[1] += x_change
      self.p[2] += y_change

    else
     
      if players_human[players_turn] then
        selector_start_unit_prompt() 
      end

      self:cleanup_move()
    end

  end

  unit.complete_move = function(self)
    self.is_resting = true

    -- reset capture on structure if we're leaving it
    if self.cached_p and not points_equal(self.p, self.cached_p) then
      local struct = get_struct_at_pos(self.cached_p)
      if struct and self.index < 3 then
        struct.capture_left = 20
      end
    end

    self.cached_p = nil
  end

  unit.unmove = function(self)
   
    self.p = self.cached_p
    self:cleanup_move()
  end

  unit.cleanup_move = function(self)
    self.animator.sprite = self.cached_sprite 
    self.animator.fps = self.cached_animator_fps
    self.animator.flip_sprite = false
    self.is_moving = false
    self.has_moved = false
    self.movement_i = 1
    self.movement_points = {}
  end

  unit.capture = function(self)
    for struct in all(structures) do
      if points_equal(struct.p, self.p) then
        struct:capture(self)
        self:complete_move() -- rest
        break
      end
    end
  end

  unit.kill = function(self)
    sfx(8)

    -- uncapture struct at position
    local struct = get_struct_at_pos(self.p)
    if struct then
      struct.capture_left = 20
    end

    self.active = false
    players_units_lost[players_reversed[unit.team]] += 1
    del(units, self)
  end

  unit.tile_mobility = function(self, tile)
   
    if fget(tile, 0) then
      if fget(tile, 1) then return 1
      elseif fget(tile, 6) then
        if self.mobility_type == 2 then return 2
        else return 1 end
      elseif fget(tile, 3) then
        if self.mobility_type == 2 then return 3
        elseif self.mobility_type == 3 then return 2
        else return 1 end
      elseif fget(tile, 4) or fget(tile, 2) then
        if self.mobility_type == 0 then return 2
        elseif self.mobility_type == 1 then return 1
        end
       
      end
    elseif fget(tile, 1) then return 1 end
    return 255
  end

  unit.ranged_attack_tiles = function(self, p)
    local tiles = {}
    if not p then p = self.p end
    for t_y = -self.range_max * 8, self.range_max * 8, 8 do
      for t_x = -self.range_max * 8, self.range_max * 8, 8 do
        local d = manhattan_distance({p[1] + t_x, p[2] + t_y}, p)
        if d >= self.range_min and d <= self.range_max then
          add(tiles, {p[1] + t_x, p[2] + t_y})
        end
      end
    end
    return tiles
  end

  unit.targets = function(self, p)
    local targets = {}
    local tiles
    if not p then p = self.p end
    if self.ranged then
      tiles = self:ranged_attack_tiles(p)
    else
      tiles = get_tile_adjacents(p)
    end
    for t in all(tiles) do
      local u = get_unit_at_pos(t)
      if u and u.team ~= self.team then
        add(targets, u) 
      end
    end
    return targets
  end

  unit.calculate_damage = function(self, u2, return_strike, tile_p, our_life)
    if not our_life then our_life = self.hp end
    if not tile_p then tile_p = u2.p end
    if return_strike and self.ranged then return 0 end
    local tile_defense = get_tile_info(mget(tile_p[1] / 8, tile_p[2] / 8))[2]
    return flr(self.damage_chart[u2.index] * 1.25 * max(0, our_life) / 10 * tile_defense + rnd(self.luck_max))
  end

  return unit
end

function make_animator(parent, fps, sprite, sprite_offset, palette, draw_offset, draw_shadow, animation_flag)
  local animator = {}
  animator.parent = parent
  animator.fps = fps
  animator.sprite = sprite
  animator.sprite_offset = sprite_offset
  animator.palette = palette
  if animation_flag ~= nil then animator.animation_flag = animation_flag else animator.animation_flag = true end
  if draw_offset then animator.draw_offset = draw_offset else animator.draw_offset = {0, 0} end
  animator.draw_shadow = draw_shadow 

  animator.time_since_last_frame = 0
  animator.animation_frame = 0
  animator.flip_sprite = false

  animator.draw = function(self)
   
    self.time_since_last_frame += delta_time
    if self.animation_flag and self.time_since_last_frame > self.fps then
      self.animation_frame = (self.animation_frame + 1) % 2
      self.time_since_last_frame = 0
    end

    local animation_frame
    if self.animation_flag then
      animation_frame = self.sprite + self.sprite_offset * self.animation_frame
    else
      animation_frame = self.sprite
    end

   
    if(self.palette) then
      set_palette(self.palette)
    end

    if self.draw_shadow then
     
      outline_sprite(animation_frame, 0, self.parent.p[1] + self.draw_offset[1], self.parent.p[2] + self.draw_offset[2], self.flip_sprite, self.palette)
    else
     
      spr(animation_frame, parent.p[1] + self.draw_offset[1], parent.p[2] + self.draw_offset[2], 1, 1, self.flip_sprite)
    end

    pal()

  end

  return animator

end

function peek_increment()
  local v = peek(memory_i)
  memory_i += 1
  return v
end

function poke_increment(poke_value)
  poke(memory_i, poke_value)
  memory_i += 1
end

function load_string(n)
 
  local str = ""
  for i = 1, n do
    local charcode_val = chr(peek_increment())
    str ..= charcode_val
  end
 
  return str
end

function load_assets()

 
  for i=1, 2 do

   
    players_human[i] = peek_increment() == 1
    players_co_name[i] = load_string(10)
    players[i] = team_index_to_palette[peek_increment()]
    players_co_icon[i] = peek_increment()
    team_icon[i] = peek_increment()
    players_music[i] = peek_increment()

    for j=1, 7 do
     
      local u = {}
      u.index = peek_increment()
      u.type = load_string(10)
      u.sprite = peek_increment()
      u.mobility_type = peek_increment()
      u.travel = peek_increment()
      u.cost = peek_increment()
      u.range_min = peek_increment()
      u.range_max = peek_increment()
      u.ranged = u.range_min > 0 
      u.luck_max = peek_increment()
      u.capture_bonus = peek_increment()
      u.struct_heal_bonus = peek2(memory_i)
      memory_i += 2
      u.ai_unit_ratio = peek_increment()
      u.moveout_sfx = peek_increment()
      u.combat_sfx = peek_increment()

      u.damage_chart = {}
      for k=1, 7 do
        local v = peek4(memory_i)
        memory_i += 4 

        add(u.damage_chart, v)
      end

      add(players_unit_types[i], u)
    end
  end

  players_reversed = {} 
  players_reversed[players[1]] = 1
  players_reversed[players[2]] = 2

 
  current_map = make_war_map({peek_increment(), peek_increment(), peek_increment(), peek_increment()})
  map_bg_color = peek_increment()

  peek_increment()
  
end


function set_palette(palette)
  if palette == palette_orange then
    return
  elseif palette == palette_blue then
    pal(9, 6)
    pal(8, 12)
    pal(2, 5)  
  elseif palette == 5 then
    pal(9, 13)
    pal(8, 6)
    pal(2, 5)
  else
    for i = 0, 15 do
      pal(i,  palette)
    end
  end
end

function points_equal(p1, p2)
  return p1[1] == p2[1] and p1[2] == p2[2]
end

function copy_v(v)
  return {v[1], v[2]}
end


function point_in_rect(p, r)
  return p[1] >= r[1] and p[1] <= r[1] + r[3] and p[2] >= r[2] and p[2] <= r[2] + r[4]
end

function sort_table_by_f(a, f)
  for i=1,#a do
    local j = i
      while j > 1 and f(a[j-1], a[j]) do
        a[j],a[j-1] = a[j-1],a[j]
        j = j - 1
      end
  end
end

function point_in_table(p, t, keys)
 
 

 
  for i, p2 in pairs(t) do
    if keys then 
      if points_equal(p, i) then return p2 end 
    else
      if points_equal(p, p2) then return i end 
    end
  end
end

function table_point_index(t, p)
 
 
  for k, v in pairs(t) do
    if points_equal(p, k) then return v end
  end
  return 32767 
end

function merge_tables(t1, t2)
 
  i = #t1 + 1
  for _, v in pairs(t2) do 
    t1[i] = v 
    i += 1
  end
end

function insert(list, pos, value)
  if pos and not value then
    value = pos
    pos = #list + 1
  end
  if pos <= #list then
    for i = #list, pos, -1 do
      list[i + 1] = list[i]
    end
  end
  list[pos] = value
end

function remove(list, pos)
  if not pos then
    pos = #list
  end
  for i = pos, #list do
    list[i] = list[i + 1]
  end
end

function outline_sprite(n,col_outline,x,y,flip_x,sprite_palette)
 
  for c=1,15 do
    pal(c,col_outline)
  end
 
  for xx=-1,1 do
    for yy=-1,1 do
      spr(n,x+xx,y+yy,1,1,flip_x,flip_y)
    end
  end
  pal()
 
  set_palette(sprite_palette)
  spr(n,x,y,1,1,flip_x,flip_y) 
  pal()
end

function draw_msg(center_pos, msg, bg_color, draw_bar)
  msg_length = #msg

  local x_pos = center_pos[1] + 5 - msg_length * 4 / 2 
  local y_pos = center_pos[2]

 
  rectfill(
    x_pos - 2,
    y_pos - 2,
    x_pos + msg_length * 4 ,
    y_pos + 5,
    bg_color)
  
  if draw_bar then
    line(
      x_pos - 2,
      y_pos + 5,
      x_pos + msg_length * 4,
      y_pos + 5,
      2)
  end

  print(msg, x_pos, y_pos - 1, 0)
end

function get_tile_adjacents(p)
    return {{p[1], p[2] - 8},
     {p[1], p[2] + 8},
     {p[1] + 8, p[2]},
     {p[1] - 8, p[2]}}
end

function get_tile_info(tile)
  if fget(tile, 1) then
    local team
    if fget(tile, 6) then team = players[1] elseif fget(tile, 7) then team = players[2] end
    if fget(tile, 2) then return {"hq★★★★", 0.6, 1, team}
    elseif fget(tile, 3) then return {"city★★", 0.7, 2, team}
    elseif fget(tile, 4) then return {"base★★", 0.7, 3, team}
    end
  end
  if fget(tile, 0) then
    if fget(tile, 1) then return {"road", 1.0}
    elseif fget(tile, 2) then return {"river", 1.0}
    elseif fget(tile, 3) then return {"wood★★", 0.7}
    elseif fget(tile, 4) then return {"mntn★★★★", 0.4}
    elseif fget(tile, 5) then return {"cliff", 1.0}
    elseif fget(tile, 6) then return {"plain★", 0.85}
    end
  end
  return {"unmovable", 0}
end

prioqueue = {}
prioqueue.__index = prioqueue

function prioqueue.new()
  newqueue = {}
  setmetatable(newqueue, prioqueue)

  newqueue.values = {}
  newqueue.priorities = {}

  return newqueue
end

local function siftup(queue, index)
  local parentindex
  if index ~= 1 then
    parentindex = flr(index/2)
    if queue.priorities[parentindex] > queue.priorities[index] then
      queue.values[parentindex], queue.priorities[parentindex], queue.values[index], queue.priorities[index] =
        queue.values[index], queue.priorities[index], queue.values[parentindex], queue.priorities[parentindex]
      siftup(queue, parentindex)
    end
  end
end

local function siftdown(queue, index)
  local minindex
  local lcindex = index*2
  local rcindex = index*2+1
  if rcindex > #queue.values then
    if lcindex > #queue.values then
      return
    else
      minindex = lcindex
    end
  else
    if queue.priorities[lcindex] < queue.priorities[rcindex] then
      minindex = lcindex
    else
      minindex = rcindex
    end
  end

  if queue.priorities[index] > queue.priorities[minindex] then
    queue.values[minindex], queue.priorities[minindex], queue.values[index], queue.priorities[index] =
      queue.values[index], queue.priorities[index], queue.values[minindex], queue.priorities[minindex]
    siftdown(queue, minindex)
  end
end

function prioqueue:add(newvalue, priority)
  insert(self.values, newvalue)
  insert(self.priorities, priority)

  if #self.values > 1 then
    siftup(self, #self.values)
  end
end

function prioqueue:pop()
  if #self.values <= 0 then
    return nil, nil
  end

  local returnval, returnpriority = self.values[1], self.priorities[1]
  self.values[1], self.priorities[1] = self.values[#self.values], self.priorities[#self.priorities]
  remove(self.values, #self.values)
  remove(self.priorities, #self.priorities)
  if #self.values > 0 then
    siftdown(self, 1)
  end

  return {returnval, returnpriority}
end

