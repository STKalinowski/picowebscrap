-- pico world race 1.1
-- by pak-9

-- Menus.lua ---------------------------------------

-- 1. Title 2. Campaign 3. Custom race
MenuState,TitleOption=1,1

MenuLvlTokenReq=split"0,0,0,0,0,60,80,120"

-- 1. Level/Theme 2. Hills 3. Curves 4. Seed
CustomOption,CustomLevel=1,1

-- 1. Low 2. Medium 3. High 4. Extreme
CustomHills=1

-- 1. Low 2. Medium 4. High 4. Extreme
CustomCurves,CustomSeed=1,1

CUSTOM_SETSTR=split"low,medium,high,extreme"

function SetLevel( n )
  Level=n
  Theme=LEVELDEF[Level][1]
  BuildPreviewTrack()
end

function RenderFlag( x,y,lvl )
  -- flattened x,y pairs (top left of sprite)
  FLAGDEF=split"79, 72, 86, 93, 107, 100, 114, 121"
  sspr( 118,FLAGDEF[lvl], 10, 7, x, y )
end

function RenderTextOutlined( str, x, y, ocol, incol )
print( str, x-1,y, ocol )
print( str, x+1,y, ocol )
print( str, x,y-1, ocol )
print( str, x,y+1, ocol )
print( str, x,y, incol )
end

function PrintTime( secs,x,y )
mins=flr(secs/60)
secs=flr(secs%60)
if secs > 9 then
  secstr=tostr(secs)
else
  secstr="0"..tostr(secs)
end
hnd=flr(secs%1*100)
if hnd > 9 then
  hndstr=tostr(hnd)
else
  hndstr="0"..tostr(hnd)
end
print( tostr( mins )..":".. secstr.."."..hndstr , x, y, 7 )
end

function BestParticles( x, y )

srand(Frame+x)
if (Frame+x)%60==0 then
  AddParticle( 10, x+rnd(8), y+rnd(5) )
end
end

-- Campaign
function UpdateMenu_Campaign()
if btnp(⬅️) then
  SetLevel( max(Level-1,1) )
elseif btnp(➡️) then
  SetLevel( min(Level+1,#LEVELDEF) )
elseif btnp(🅾️) and CountProfileTokens() >= MenuLvlTokenReq[Level] then
  InitRace()
elseif btn(❎) then
  OpenMenu(1)
end
end

function RenderMenu_BG( y, h )
rectfill( 13, y, 115, h, 13 )
rect( 12, y-1, 116, h+1, 1 )

-- logo
sspr(unpack(split"33, 57, 56, 14, 27, 5"))
sspr(unpack(split"89, 61, 19, 10, 83, 9"))

-- car
pd_draw(0,38,88)
end

function RenderMenu_Campaign()

RenderMenu_BG(25,92)
-- Country
RenderFlag( 43, 29, Level )
RenderTextOutlined( LEVELDEF[Level][6], 56, 30, 0, 7 )

TotalTkns=CountProfileTokens()
if TotalTkns >= MenuLvlTokenReq[Level] then
  -- position
  ProfStnd=ReadProfile(Level,1)
  rectfill( 16, 41, 46, 64, 1 )
  sspr(unpack(split"65, 49, 8, 8, 27, 43")) -- trophy
  col=7
  if ProfStnd == 1 then
    BestParticles( 27, 43 )
    rect( 16, 41, 46, 64, 10 )
    col=10
  end

  if ProfStnd == 0 then
    print( "none", 24, 57, 7 )
  else
    print( tostr(ProfStnd)..tostr( GetStandingSuffix(ProfStnd) ), 26, 57, col )
  end

  ProfTkns=ReadProfile(Level,2)
  rectfill( 49, 41, 79, 64, 2 )
  sspr(unpack(split"17, 121, 7, 7, 61, 44")) -- token
  col=7
  if ProfTkns == 20 then
    BestParticles( 61, 43 )
    rect( 49, 41, 79, 64, 10 )
    col=10
  end
  print( tostr(ProfTkns).."/20", 56, 57, col )

  rectfill( 82, 41, 112, 64, 3 )
  sspr(unpack(split"73, 50, 7, 7, 94, 44")) -- clock
  PrintTime( ReadProfile(Level,3), 84, 57 )

  print( " \142  race", 38, 70, 6 )
else
  sspr(unpack(split"120, 34, 8, 11, 30, 44")) -- lock
  sspr(unpack(split"120, 34, 8, 11, 91, 44")) -- lock
  print( "race locked", 43, 48, 9 )

  sspr(unpack(split"17, 121, 7, 7, 36, 61")) -- token
  print( tostr(TotalTkns).."/".. tostr(MenuLvlTokenReq[Level]) .. " tokens", 46, 62, 6 )
end
print( "\139\145 country", 38, 77, 6 )
print( "\151  back", 42, 84, 6 )

-- arrows
xoff=sin(time())*1.2
if Level < #LEVELDEF then
  sspr( 113, 80, 5, 7, 120+xoff, 49 ) -- arrow
end
if Level > 1 then
  sspr( 113, 80, 5, 7, 5-xoff, 49, 5, 7 ,1 ) -- arrow
end

end

function RenderMenu_Custom()
RenderMenu_BG(24,92)
RenderTextOutlined( "custom race", 42, 29, 0, 7 )

-- cursor
xoff=(flr(time()*3  )%2)
ypos=32 + CustomOption * 8
rectfill( 68, ypos-1, 104, ypos+5, 1 )
sspr( 113, 75, 3, 5, 64-xoff, ypos, 3, 5, 1 )
sspr( 113, 75, 3, 5, 106+xoff, ypos )

-- Level/Theme
print( "country", 29, 40, 6 )
print( LEVELDEF[CustomLevel][6], 65, 40, 7 )
print( "hills", 37, 48, 6 )
print( CUSTOM_SETSTR[CustomHills], 69, 48, 7 )
print( "curves", 33, 56, 6 )
print( CUSTOM_SETSTR[CustomCurves], 69, 56, 7 )
print( "seed", 41, 64, 6 )
print( CustomSeed, 69, 64, 7 )
print( " \142 race", 44, 76, 6 )
print( " \151 back", 44, 83, 6 )
end

function UpdateMenu_Custom()
if btnp(⬅️) or btnp(➡️) then -- left/right
  if btnp(⬅️) then dir=-1 else dir=1 end
  if CustomOption==1 then
    CustomLevel=max(min(CustomLevel+dir,#LEVELDEF),1)
    TotalTkns=CountProfileTokens()
    if TotalTkns < MenuLvlTokenReq[CustomLevel] then
      CustomLevel-=1
    end
    SetLevel( CustomLevel )
  elseif CustomOption==2 then
    CustomHills=max(min(CustomHills+dir,4),1)
  elseif CustomOption==3 then
    CustomCurves=max(min(CustomCurves+dir,4),1)
  else --if CustomOption==4 then
    CustomSeed=max(min(CustomSeed+dir,100),1)
  end
elseif btnp(❎) then
  OpenMenu(1)
elseif btnp(⬆️) then
  CustomOption=max( CustomOption-1, 1 )
elseif btnp(⬇️) then
  CustomOption=min( CustomOption+1, 4 )
elseif btnp(🅾️) then
  IsCustomRace=1
  InitRace()
end
end

function RenderMenu_Title()
RenderMenu_BG(33,62)

ypos=31 + TitleOption * 10
rectfill( 30, ypos-2, 96, ypos+6, 1 )

sspr(unpack(split"24, 121, 7, 7, 35, 40")) --globe
print( "world tour", 48, 41, 7 )

sspr(unpack(split"33, 49, 7, 7, 35, 50")) --gear
print( "custom race", 48, 51, 7 )

RenderTextOutlined( "a game by pak-9", 35, 70, 0,6 )
RenderTextOutlined( "thx theroboz", 40, 80, 0,6 )
end

function UpdateMenu_Title()
if btnp(⬆️) then
  TitleOption=1
elseif btnp(⬇️) then
  TitleOption=2
elseif btnp(🅾️) then
  OpenMenu(TitleOption+1)
end
end

function RenderMenus()

RenderSky()
RenderHorizon()
RenderRoad()
fillp(0)
if MenuState==1 then
  RenderMenu_Title()
elseif MenuState==2 then
  RenderMenu_Campaign()
elseif MenuState==3 then
  RenderMenu_Custom()
end
RenderParticles()
end

function OpenMenu( i )

BuildPreviewTrack()
Position = SEG_LEN
PlayerX, PlayerY = 0,0
UpdatePlayer()

MenuState,TitleState=i,1

menuitem(1)
menuitem(2)
if MenuState==3 then
  SetLevel(CustomLevel)
end
end

function UpdateMenus()
if MenuState==1 then
  UpdateMenu_Title()
elseif MenuState==2 then
  UpdateMenu_Campaign()
elseif MenuState==3 then
  UpdateMenu_Custom()
end
UpdateParticles()
end


------------------ Particle.lua

-- 1.sx, 2.sy, 3.sw, 4.sh, 5.life 6.dx 7.dy 8.dsc 9. sc
PDEF=split([[
27, 99, 5, 5, 0.5, -0.5,0.25, -0.05, 1 /
27, 99, 5, 5, 0.5, 0.5, 0.25, -0.05, 1 /
83, 23, 7, 7, 0.2, 0.15, 0.25,  -0.02, 1.2 /
86, 48, 4, 4, 1, 0.6, -0.5, -0.025, 1 /
85, 53, 4, 4, 1, -0.6,-0.5, -0.025, 1 /
80, 48, 3, 3, 0.2, -2, -2, -0.005, 0.4 /
113,71, 4, 4, 0.2, 2, -0.5, -0.005, 0.5 /
83, 48, 4, 4, 0.3, 0.25,-0.5, -0.02, 0.8 /
27, 99, 5, 5, 4,   0.25,-0.5, 0.1, 0.2 /
80, 52, 5, 5, 0.8, 0, -0.01, -0.05, 1 /
80, 52, 5, 5, 0.8, 0, -0.01, -0.05, 1 /
]],"/")

sPartic, sParticT, sParticSc, sParticX, sParticY, NextPartic = {},{},{},{},{},1

function InitParticles()
for i=1, #PDEF do PDEF[i]=split(PDEF[i]) end
for i=1,40 do
  sPartic[i] = 0
end
end

function AddParticle( p, x, y )
srand( time() )
sPartic[NextPartic] = p
sParticT[NextPartic] = time()
sParticSc[NextPartic] = 1
sParticX[NextPartic] = x
sParticY[NextPartic] = y
NextPartic=(NextPartic+1)%#sPartic+1
end

function ClearParticles()
for i=1, #sPartic do
  sPartic[i] = 0
end
end

function UpdateParticles()
--npart=0
for i=1, #sPartic do
  local p = sPartic[i]
  if p != 0 then
    --npart += 1
    srand(p)
    sParticSc[i] += ( PDEF[p][8] + rnd(0.5) * PDEF[p][8] )
    sParticX[i] += ( PDEF[p][6] + rnd(0.5) * PDEF[p][6] )
    sParticY[i] += ( PDEF[p][7] + rnd(0.5) * PDEF[p][7] )
    if sParticSc[i] <= 0 or time() - sParticT[i] > PDEF[p][5] then
      sPartic[i] = 0
    end
  end
end
end

function RenderParticles()
for i=1, #sPartic do
  local p = sPartic[i]
  if p != 0 then
    local ssc=sParticSc[i]*10*PDEF[p][9]
    local rrect= { sParticX[i] - ssc * 0.5, sParticY[i] - ssc * 0.5, ssc, ssc }
    sspr( PDEF[p][1], PDEF[p][2], PDEF[p][3], PDEF[p][4], rrect[1], rrect[2], rrect[3], rrect[4] )
  end
end
end


-- RenderUtils.lua ---------------------------------------

BAYER =split" 0, 0x0208,   0x0A0A,   0x1A4A,   0x5A5A,   0xDA7A,   0xFAFA,   0xFBFE, 0xFFFF "
BAYERT=split" 0, 0x0208.8, 0x0A0A.8, 0x1A4A.8, 0x5A5A.8, 0xDA7A.8, 0xFAFA.8, 0xFBFE.8 "

opcols1 = split" 12, 11, 10, 9, 8, 6 "
opcols2 = split" 1, 3, 4, 4, 2, 5 "

function BayerRectT( fact, ...)
--render a rect with a bayer pattern
if fact < 1 and fact >= 0 then
  fillp(BAYERT[(1+fact*#BAYERT)\1])
  rectfill( ... )
end
end

function BayerRectV( x1, y1, x2, y2, c1, c2 )
-- render a vertical bayer dither
col = bor( c1 << 4, c2 );
h=y2-y1
for i = 1,#BAYER do
  fillp(BAYER[i])
  rectfill( x1\1, y1\1, x2\1, y1\1+h/#BAYER\1, col )
  y1 += h/#BAYER;
end
end

pd_modes = split"rect,oval,line,map,pal,rectfill,ovalfill,pd_tri,pset,spr,pd_draw,clip,_trifill"
pd_fillp = split"32768, 32736, 24544, 24416, 23392, 23391, 23135, 23131, 6747, 6731, 2635, 2571, 523, 521, 9, 1, 1"


function pd_draw(index,x,y,s_start,s_end,flip_h)

function _trifill(x1,y1,x2,y2,c) --@JadeLombax
  local inc=sgn(y2-y1)
  local fy=y2-y1+inc/2
  for i=inc\2,fy,inc do
    line(x1+.5,y1+i,x1+(x2-x1)*i/fy+.5,y1+i,c)
  end
  line(x1,y1,x2,y2)
end

local l,cmd= #brush[index]

local function _flip(p,f,o,n)
  for i=0,o==0 and 2 or 0,2 do cmd[p+i] = f-cmd[p+i]-o end
  cmd[n] = not cmd[n]
end

camera(%0x5f28-x,%0x5f2a-y)

for i=s_start and s_start or 1, s_end and s_end or l do

cmd={unpack(brush[index][i])}


local s_cmd,px,ox = deli(cmd,1),2,0

if ((s_cmd<=9 or s_cmd==13) and cmd[6]>0) fillp(-pd_fillp[cmd[6]]+.5,x,y)
  if(flip_h and flip_h!=0) _flip(px,flip_h,ox,6)
  _ENV[pd_modes[s_cmd]](unpack(cmd))
  fillp()
end

camera(%0x5f28+x,%0x5f2a+y)

end


-- Sound.lua ---------------------------------------

Chan0=-1

function UpdateRaceSound()

-- channel 0
-- player
tgtsnd=-1
if RecoverStage == 0 and RaceState < 3 and TitleState==2 then
  if (PlayerDrift != 0 or IsBurnout()) and PlayerAir == 0 then -- z / btn1)
    tgtsnd=3
  elseif PlayerVl < 0.8 then
    tgtsnd=0
  elseif btn(4)==false then -- z / btn1
    tgtsnd=4
  elseif PlayerAir > 0 then
    tgtsnd=12
  else
    if PlayerVl > 7 then
      tgtsnd=2
    else
      tgtsnd=1
    end
  end
end
if Chan0 != tgtsnd then
  if Chan0 != -1 then
    sfx(-1,0)
  end
  if tgtsnd != -1 then
    sfx(tgtsnd,0)
  end
end
Chan0=tgtsnd

-- channel 1
-- offroad
if RecoverStage == 0 and RaceState < 3 and IsOffRoad() and PlayerVl > 0.5 then
  sfx(5,1)
else
  sfx(-1,1)
end
end


-- Spritedef.lua ---------------------------------------
-- (bottom of sprite on the ground)
-- 1.sx, 2.sy, 3.sw, 4.sh, 5.scalemin, 6.scalemax, 7.flip, 8.collidable

SDEF=split([[
16, 104, 16, 16, 1.4, 1.4, 0, 1 /
16, 104, 16, 16, 1.4, 1.4, 1, 1 /
48, 53, 8, 4, 0.4, 0.6, 0, 0 /
0, 80, 27, 24, 2.5, 4.5, 0, 1 /
41, 50, 8, 7, 0.5, 1.5, 0, 0 /
48, 71, 20, 10, 4, 4, 0, 1 /
0, 0, 16, 24, 1, 1, 0, 0 /
16, 0, 36, 24, 1, 1, 0, 0 /
16, 0, 36, 24, 1, 1, 1, 0 /
17, 121, 7, 7, 1, 1, 0, 0 /
112, 87, 6, 41, 1, 1, 0, 1 /
110, 59, 18, 12, 1, 1, 0, 0 /
110, 59, 18, 12, 1, 1, 1, 0 /
83, 71, 6, 14, 0.6, 0.6, 0, 1 /
106, 31, 7, 14, 0.6, 0.6, 0, 1 /
113, 31, 7, 14, 0.6, 0.6, 0, 1 /
110, 45, 18, 15, 1.2, 1.2, 0, 1 /
110, 45, 18, 15, 1.2, 1.2, 1, 1 /
82, 85, 8, 23, 1, 1, 0, 1 /
82, 85, 8, 23, 1, 1, 1, 1 /
105, 16, 16, 15, 1.8, 3, 0, 1 /
0, 48, 33, 32, 6, 6, 0, 1 /
42, 71, 6, 11, 0.6, 0.6, 0, 1 /
90, 86, 22, 22, 2, 3.5, 0, 1 /
57, 49, 8, 8, 1, 2, 0, 1 /
107, 72, 5, 10, 0.2, 0.5, 0, 0 /
49, 48, 8, 5, 0.4, 0.8, 0, 0 /
75, 25, 8, 4, 0.2, 0.8, 0, 1 /
115, 0, 8, 15, 0.9, 0.9, 0, 1 /
115, 0, 8, 15, 0.9, 0.9, 1, 1 /
100, 0, 15, 16, 4, 9, 0, 1 /
91, 71, 15, 15, 1.1, 1.1, 0, 1 /
91, 71, 15, 15, 1.1, 1.1, 1, 1 /
0, 104, 16, 24, 2, 3, 0, 1 /
123, 0, 4, 15, 0.4, 0.4, 0, 1 /
80, 108, 32, 20, 2.5, 2.5, 0, 1 /
104, 45, 5, 15, 1, 1, 1, 1 /
104, 45, 5, 15, 1, 1, 0, 1 /
68, 71, 8, 11, 0.6, 0.6, 0, 1 /
27, 80, 5, 19, 0.4, 0.4, 0, 1 /
76, 71, 6, 19, 0.4, 1, 0, 0 /
89, 50, 15, 11, 0.4, 2.2, 0, 1 /
33, 71,  9, 11, 1, 1, 0, 0 /
52, 29, 18, 19, 1, 1, 0, 0 /
70, 29, 34, 19, 1, 1, 0, 0 /
70, 29, 34, 19, 1, 1, 1, 0 /
0, 24, 16, 24, 1, 1, 0, 0 /
16, 24, 36, 24, 1, 1, 0, 0 /
16, 24, 36, 24, 1, 1, 1, 0 /
]],"/")

-- sprite pattern definitions, when conflict first is used
-- 1. SDEF, 2. interval, 3. interval offset, 4. minx (*roadw), 5. maxx (*roadw), 6. rand l/r
SPDEF = {
-- 1. Green raceway
split(
[[
2, 6, 0, 1.6, 1.6, 0 / 4, 4, 0, 2, 8, 1 / 3, 2,1, 1.5, 2, 1 `
1, 6, 0, -1.6, -1.6, 0 / 4, 4, 0, 2, 8, 1 / 3, 2,1, 1.5, 2, 1 `
4, 6, 2, 1.5, 8, 1 / 5, 5, 1, 2, 4, 1 / 3, 2,0, 1.4, 3, 1 `
6, 18, 0, 2, 2, 0 / 4, 2, 0, 1.5, 8, 1 / 5, 3,0, 2, 4, 1 / 3, 1,0, 1.4, 3, 1 `
14, 12, 0, -1.1, -1.1, 0 / 4, 6, 2, 1.1, 4, 1 `
15, 8, 0,-1.1,-1.1, 0 / 16, 8, 1, 1.1, 1.1, 0 / 5, 5, 0, 2, 4, 1
]], "`"),
-- 2. Snowy
split(
[[
33, 6, 0, 1.4, 1.4, 0 / 34, 7, 0, 1.2, 8, 1 / 27, 6,0, 1.1, 2, 1 `
32, 6,0, -1.4, -1.4, 0 / 34, 7, 0, 1.2, 8, 1 / 27, 6,0, 1.1, 2, 1 `
35, 12, 0, -1.1, -1.1, 0 / 34, 7, 0, 1.2, 3, 1 `
36, 26, 0, 1.8, 4.5, 1 / 34, 7, 0, 1.2, 3, 1 / 28, 9, 0, 1.2, 3, 1
]], "`"),
-- 3. Japan
split(
[[
18, 6, 0, 1.6, 1.6, 0 / 21, 2, 0, 1.2, 8, 1 / 3, 1,0, 1.5, 2, 1 `
17, 6, 0, -1.6, -1.6, 0 / 21, 2, 0, 1.2, 8, 1 / 3, 1,0, 1.5, 2, 1 `
19, 6, 0, 1.05, 1.1, 0  / 20, 6, 1, -1.1, -1.1, 0 `
21, 5, 0, 1.5, 6, 1 / 5, 5, 0, 2, 4, 1 / 3, 1,0, 1.4, 3, 1 `
15, 8, 0,-1.1,-1.1, 0 / 16, 8, 1, 1.1, 1.1, 0 / 5, 5, 0, 2, 4, 1 `
22, 8, 0, 2.5, 5, 1 / 21, 3, 0, 1.5, 6, 1 `
23, 6, 0, 1.2, 1.2, 0 / 23, 6, 2, -1.2, -1.2, 0 / 21, 7, 0, 1.5, 6, 1 `
19, 8, 0, 1.02, 1.02, 0 / 3, 5, 0, 2, 2, 1 `
20, 8, 0, -1.1, -1.1, 0 / 3, 5, 0, 2, 2, 1
]] ,"`"),
-- 4. Red desert
split(
[[
30, 7, 0, 1.6, 1.6, 0 / 27, 8, 0, 1.5, 2, 1 / 28, 5, 1, 2, 4, 1 `
29, 7, 0, -1.6, -1.6, 0 / 27, 8, 0, 1.5, 2, 1 / 28, 5, 1, 2, 4, 1 `
24, 12, 0, 1.5, 6, 1 / 26, 5, 0, 1.2, 4, 1 / 28, 4,0, 1.4, 5, 1 `
25, 12, 0, 1.5, 6, 1 / 26, 8, 2, 1.2, 4, 1 / 28, 6,1, 1.4, 5, 1 `
27, 6, 0, 1.6, 6, 1 `
31, 18, 0, 5, 9, 1 / 25, 20, 0, 1.5, 6, 1 / 27, 8, 2, 1.2, 4, 1
]] ,"`"),
-- 5. fun land
split(
[[
30, 7, 0,  1.6,  1.6, 0 / 41, 5, 0, 1, 1.5, 1 / 21, 8, 1.5, 2, 4, 1 `
29, 7, 0, -1.6, -1.6, 0 / 41, 5, 0, 1, 1.5, 1 / 21, 8, 1.5, 2, 4, 1 `
37, 8, 0, 1.02, 1.02, 0 / 41, 5, 0, 0.2, 2, 1 `
38, 8, 0, -1.1, -1.1, 0 / 41, 5, 0, 0.2, 2, 1 / 40, 10, 5, 1.2, 1.2, 1 `
39, 6, 0, -1.2, -1.2, 1 / 41, 8, 0, 0.5, 2, 1 `
42,12, 0,  1.5, 2, 1 / 41, 8, 0, 0.5, 2, 1 / 40, 10, 5, 1.2, 1.2, 1
]] ,"`"),
}

function InitSpriteDef()
  -- Sprite def
  for i=1, #SDEF do SDEF[i]=split(SDEF[i]) end

  for i=1, #SPDEF do
   for j=1, #SPDEF[i] do SPDEF[i][j]=split(SPDEF[i][j],"/")
    for k=1, #SPDEF[i][j] do SPDEF[i][j][k]=split(SPDEF[i][j][k]) end
   end
  end
end


-- Trackdef.lua ---------------------------------------

CT_HILLS=split"0.5,0.8,1.1,1.3" -- custom track hills
CT_CURVES=split"0.8,1.0,1.15,1.4" -- custom track curves

function BuildCustomTrack( lvl, ysc, cmax, seed )

sp=LEVELDEF[Level][2]

len=28
--len=5
srand(seed)
for n=1,len do
  w=rnd(1)
  slen=((w*1.4)*(w*1.4))*0.5 -- tend towards shorter
  if rnd(4)<2 or n==1 or n==len then
    --straight
    sptn=flr(rnd(#SPDEF[sp]-2))+3
    cnt=slen*30+10
    AddStraight( cnt, 0, sptn )
  else
    --curve
    c=rnd(cmax)+0.2
    if rnd(1)>0.5 then
      c=-c
    end
    if c > 0.85 then
      sptn=1 -- right turns are spdef 2
    elseif c < -0.85 then
      sptn=2 -- left turns are spdef 1
    else
      -- random pick of all other spdefs
      sptn=flr(rnd(#SPDEF[sp]-2))+3
    end
    cnt=flr((2-rnd(cmax))*(slen+rnd(1))*18)+6
    cntin=flr((2-rnd(cmax))*(slen+rnd(1))*18)+6
    cntout=flr((2-rnd(cmax))*(slen+rnd(1))*18)+6
    AddCurve(cntin,cnt,cntout,c,0,sptn)
  end
end

-- y values
ydelt1=0 -- first derivative
ydelt2=0 -- second derivative
y=0
for i=1,NumSegs do
  ydelt2=(ydelt2+rnd(1)-0.5)*0.9
  ydelt1=(ydelt1+ydelt2)*0.9
  y=y+ydelt1
  sPointsY[i]=y*sin(i/NumSegs*0.5)*ysc
end

-- tokens, always 4 groups of 5
for i=1,4 do
  sttkn=(NumSegs-200)/4*i
  xx=rnd(0.7)-0.35
  AddTokens( flr(sttkn), xx, 5 )
end

end

function BuildPreviewTrack()
EraseTrack()
for i=0,2 do
  AddCurve(10,10,10,2,0,1)
end
end

function EraseTrack()
sPointsX,sPointsY,sPointsZ,sPointsC,sTokensX,sTokensExist,sSprite,sSpriteX,sSpriteSc,NumSegs={},{},{},{},{},{},{},{},{},0
end


-- Utility.lua ---------------------------------------

function lerp( a,b,f )
return a+(b-a)*f
end

function easein( a, b, fact )
return a + (b-a)*fact*fact
end

function easeout( a, b, fact )
return a + (b-a)*(1-(1-fact)*(1-fact))
end

function easeinout( a, b, fact )
  if fact <= 0.5 then
    return easein(a,lerp(a,b,0.5),fact*2)
  else
    return easeout(lerp(a,b,0.5),b,(fact-0.5)*2)
  end
end


-- Profile.lua ---------------------------------------

-- 1. Standing 2. Tokens 3. Time
PlayerProfile = {}

-- note: 1 based in cart memory
function LoadProfile()
cartdata("pak9_pwr_1")
for i=1,#LEVELDEF*3 do
  add(PlayerProfile, dget(i))
  assert( PlayerProfile[i] != nil )
end
end

function SaveProfile()
for i=1,#PlayerProfile do
  dset( i, PlayerProfile[i] )
end
end

function ReadProfile( lvl, id )
idx=(lvl-1)*3+id
return PlayerProfile[idx]
end

function WriteProfile( lvl, id, val )
idx=(lvl-1)*3+id
PlayerProfile[idx]=val
SaveProfile()
end

function EraseProfile()
for i=0,#PlayerProfile do
  PlayerProfile[i]=0
end
SaveProfile()
end

function CountProfileTokens()
tkns=0
for i=1,#LEVELDEF do
  tkns+=ReadProfile( i, 2 )
end
return tkns
end



-- custom font
font="8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,240,248,252,28,28,0,0,0,15,31,63,56,56,0,0,0,192,192,192,128,128,0,0,0,3,3,3,3,3,0,0,0,252,252,252,0,240,0,0,0,15,31,63,56,63,0,0,0,252,252,252,0,252,0,0,0,15,31,63,56,63,0,0,0,224,240,120,60,28,0,0,0,28,28,28,28,28,0,0,0,252,252,252,28,252,0,0,0,63,63,63,0,15,0,0,0,240,248,252,28,252,0,0,0,31,31,31,0,15,0,0,0,240,248,252,28,0,0,0,0,15,31,63,56,56,28,28,28,252,248,240,0,0,56,56,56,63,31,15,0,0,128,128,128,128,128,128,0,0,3,3,3,3,3,3,0,0,248,252,28,252,252,252,0,0,31,15,0,63,63,63,0,0,252,252,0,252,252,252,0,0,63,63,56,63,31,15,0,0,28,252,248,0,0,0,0,0,28,63,63,28,28,28,0,0,252,252,0,252,252,252,0,0,31,63,56,63,31,15,0,0,252,252,28,252,248,240,0,0,31,63,56,63,31,15,0,0,0,0,0,0,128,128,0,0,56,60,30,15,7,3,0,0,0,0,0,240,248,252,28,252,0,0,0,15,31,63,56,63,0,0,0,240,248,252,28,252,0,0,0,15,31,63,56,63,0,0,0,240,248,252,28,156,0,0,0,63,63,63,0,63,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,252,252,28,252,248,240,0,0,63,63,56,63,31,15,0,0,252,248,0,248,248,248,0,0,63,63,56,63,63,31,0,0,156,156,28,252,248,240,0,0,63,63,56,63,63,63,0,0,0,0,0,0,0,0,0,0,0"

CType = split"0,37,40"

Frame, SEG_LEN, DRAW_DIST, CANVAS_SIZE, CAM_HEIGHT = 0,10,100,128,21

ROAD_WIDTH = 60 -- half
CAM_DEPTH = 0.55; -- 1 / tan((100/2) * pi/180) (fov is 100)

-- horizon sprite def: 1. sx 2. sy 3. sw 4. sh 5. xscale 6. yscale
HORZSDEF = {
  split"32,  83, 48, 15,   1,   1", -- 1. City
  split"32,  98, 48, 10, 1.2, 0.8", -- 2. Mountain
  split"32, 109, 45,  9, 1.2, 0.8", -- 3. Glacier
  split"32, 119, 46,  9, 1.4, 0.7", -- 4. Hills
}

-- 1. Road c1 2. Road c2 3. Road pat 4. Ground c1 5. Ground c2(x2) 6. Edge c1 7. Edge c2(x2) 8. Lane pat 9. Sky c1 10. Sky c2 11. horizon spr
-- Road patterns: 1. alternating stripes 2. random patches
-- Lane patterns: 1. edges 2. centre alternating 3. 3 lane yellow
THEMEDEF = {
--  r1 r2   rp g1  g2   e1  e2   lp sk1 sk2 hz
split"5, 0x5D, 1, 3, 0x3B, 6, 0x42, 1, 6, 12, 1 ", -- 1. USA
split"5, 0x05, 1, 6, 0x6D, 6, 0x15, 3, 6, 12, 3 ",-- 2. Alaska
split"5, 0x15, 1, 3, 0x23, 6, 0xC5, 2, 7, 12,  4 ", -- 3. Japan
split"5, 0x25, 2, 2, 0x21, 5, 0x42, 3, 13, 2, 2 ", -- 4. Oz
split"4, 0x45, 2, 4, 0x34, 1, 0xD5, 2, 13, 12, 2 ", -- 5. kenya
split"5, 0x65, 2, 6, 0x76, 6, 0x15, 2, 6, 12, 3 ", -- 6. Nepal
split"5, 0x51, 1, 5, 0x35, 6, 0x82, 1, 1, 0, 1 ", -- 7. Germany
split"13, 0xCD, 1, 2, 0x2E, 10, 0xBD, 3, 6, 14, 2 ", -- 8. Funland
  }

-- 1. Theme 2. spr pattern 3. yscale 4. curvescale 5. seed 6. name
LEVELDEF={
split"1, 1, 0.5, 0.8, 1, usa ",
split"4, 4, 0.8, 1, 4, australia",
split"2, 2, 1.1, 0.8, 8, alaska",
split"3, 3, 0.9, 1.1, 13, japan",
split"5, 4, 0.8, 1, 30, kenya",
split"6, 2, 1.2, 0.9, 14, nepal",
split"7, 1, 0.9, 1.2, 88, germany",
split"8, 5, 1.3, 1.4, 29, funland"
}

Theme, Level, IsCustomRace=1,1,0

NumSegs = 0
sPointsX, sPointsY, sPointsZ, sPointsC = {},{},{},{}

NUM_LAPS = 3

sSprite,sSpriteX,SpriteCollideRect = {},{},{}
sSpriteSc = {} -- scale
SpriteCollideIdx=-1
sTokensX, sTokensExist = {},{}
TokenCollected,NumTokens = 0,0

LastY = 0 -- last y height when building a track
Position = 0 -- current position around the track

-- -1 to 1 TODO: maybe don't make relative to road width
PlayerX, PlayerXd, PlayerY, PlayerYd, PlayerVl, PlayerVf, PlayerDrift, PlayerAir, PlayerLap, Pfrm = 0,0,0,0,0,0,0,0,0,0

PlayerSeg = 0 -- current player segment
PlayerStandF = 0 -- final standing

BURNOUT_SPD = 1.3

RecoverStage = 0 -- 1. pause 2. lerp to track 3. flash
RecoverTimer, InvincibleTime = 0,0

OpptPos, OpptLap, OpptSeg, OpptX, OpptV = {},{},{},{},{}

HznOffset = 0
HUD_HEIGHT = 16
sScreenShake = {0,0}

-- 1. Menus 2. Racing
TitleState=1
-- 1. countdown 2. race 3. end standing 4. Summary UI
RaceState = -1
RaceStateTimer, RaceCompleteTime = 0,0
RaceCompletePos = 0 -- player standing

function LoopedTrackPos(z)
lps=flr(z/(SEG_LEN*NumSegs))
return z-SEG_LEN*NumSegs*lps
end

function DepthToSegIndex(z)
return flr(z/SEG_LEN) % NumSegs + 1
end

function AddSeg( c, y )
NumSegs+=1
add( sPointsC, c )
add( sPointsX, 0 )
add( sPointsY, y )
add( sPointsZ, NumSegs * SEG_LEN + 1 )
add( sTokensX, 0 )
add( sTokensExist, 0 )
end

function AddSprites( n, p )
sp=LEVELDEF[Level][2]
sd=SPDEF[sp][p]
for i = 1, n do

  if p == 0 then
    add( sSprite, 0 )
    add( sSpriteX, 0 )
    add( sSpriteSc, 0 )
  else
    srand( #sSprite )
    added = false
    for j = 1, #sd do
      sdi=sd[j]
      if (#sSprite+sdi[3]) % sdi[2] == 0 then
        -- SDEF, interval, interval offset, minx (*roadw), maxx (*roadw), rand l/r

        xrand = 1
        if (sdi[6] == 1 and rnd( 30000 ) > 15000) xrand = -1

        spindex=sdi[1]
        add( sSprite, spindex )
        add( sSpriteX, ( sdi[4] + rnd( sdi[5] - sdi[4] ) ) * xrand )
        add( sSpriteSc, 0.3*(SDEF[spindex][5]+rnd(SDEF[spindex][6]-SDEF[spindex][5])) )
        added = true
        break
      end
    end
    if added == false then
      add( sSprite, 0 )
      add( sSpriteX, 0 )
      add( sSpriteSc, 0 )
    end
  end
end
end

function AddCurve( enter, hold, exit, c, y, sprp )

tot=(enter+hold+exit)
AddSprites( tot, sprp )

for i=1,enter do
  AddSeg( easein( 0, c, i/enter ), easeinout( LastY,y,i/tot ) )
end
for i=1,hold do
  AddSeg( c, easeinout( LastY,y,(i+enter)/tot ) )
end
for i=1,exit do
  AddSeg( easeout(c, 0, i/exit ), easeinout( LastY,y,(i+enter+hold)/tot ) )
end
LastY=y

end

function AddStraight( n, y, sprp )
AddSprites( n, sprp )
for i=1,n do
  AddSeg( 0, easeinout( LastY, y, i/n ) )
end
LastY=y
end

function AddTokens( seg, x, n )
for i=1,n do
  sTokensX[seg+i*3-3] = x
  sTokensExist[seg+i*3-3]=1
end
NumTokens += n
end

function InitOps()
for i=1,8 do
  OpptPos[i] = SEG_LEN+SEG_LEN *  i
  OpptX[i]=((i%2)*2-1)*0.2
  OpptV[i]=0
  OpptLap[i]=1
end
end

function MenuRestart()
InitRace()
end

function MenuQuit()
OpenMenu(MenuState)
end

function InitRace()

TitleState=2

menuitem( 1, "restart race", MenuRestart )
menuitem( 2, "abandon race", MenuQuit )

NumTokens=0
TokenCollected=0

EraseTrack()
if IsCustomRace==1 then
  BuildCustomTrack( CustomLevel, CT_HILLS[CustomHills], CT_CURVES[CustomCurves], CustomSeed )
else
  BuildCustomTrack( Level, LEVELDEF[Level][3], LEVELDEF[Level][4], LEVELDEF[Level][5] )
end
InitOps()
RaceStateTimer = time()
RaceState = 1

Position = SEG_LEN
PlayerX = -0.2 -- -1 to 1 TODO: maybe don't make relative to road width
PlayerXd, PlayerY, PlayerYd, PlayerVl, PlayerVf, PlayerDrift, PlayerAir, Pfrm = 0,0,0,0,0,0,0,0
PlayerSeg = 0 -- current player segment
PlayerLap = 1

RecoverStage = 0 -- 1. pause 2. lerp to track 3. flash
RecoverTimer, InvincibleTime = 0,0
UpdatePlayer()
end

function _init()
--font init
memset(0x5600,0,256*8)
poke(0x5600,unpack(split(font)))

brush={}

for n=0,4,4 do

  brush[n]={}

  local start = 0x2000+n*128
  local l=peek(start)

  for i=1, l do

    local cmd={}

    for j=1,5 do
      cmd[j]=peek(start+(i-1)*6+j)-64
    end
    cmd[6]=peek(start+(i-1)*6+6)
    cmd[7],cmd[6]=(cmd[6]&240)>>4,(cmd[6]&15)
    add(brush[n],cmd)
  end

end

LoadProfile()
--EraseProfile()
InitSpriteDef()

palt(0, false)
palt(15, true)

InitParticles()
OpenMenu(1)
end

function RaceStateTime()
return time()-RaceStateTimer
end

function IsOffRoad()
return abs( PlayerX*ROAD_WIDTH ) > ROAD_WIDTH and PlayerAir == 0
end

function IsBurnout()
return PlayerAir==0 and IsOffRoad() == false and PlayerVf < BURNOUT_SPD and btn(🅾️) -- z / btn1
end

function UpdateRaceInput()

if RaceState == 2 and PlayerAir == 0 then
  if btn(❎) then -- btn2
    if abs( PlayerXd ) > 0.1 then
      PlayerDrift=sgn(PlayerXd)
      Pfrm=max(.2,Pfrm)
    else
      PlayerVl=PlayerVl-0.08
    end
  end

  if btn(🅾️) then -- z / btn1
    PlayerVl=PlayerVl+0.09
  end

  if btn(⬅️) then -- left
    PlayerXd-= (0.022 + -PlayerDrift*0.01) * (1-PlayerVl*0.0005)*min(PlayerVl*0.125,1)
  elseif btn(➡️) then -- right
    PlayerXd+= (0.022 + PlayerDrift*0.01) * (1-PlayerVl*0.0005)*min(PlayerVl*0.125,1)
  end
end
end

function UpdatePlayer()

if InvincibleTime-time() < 0 then
  InvincibleTime = 0
end

if PlayerAir == 0 then
  if RecoverStage == 0 then
    UpdateRaceInput()
  end
    
  local drftslw=(1-abs(PlayerDrift)*0.001)
    
  if IsOffRoad() then
    PlayerVl=PlayerVl*0.989*drftslw
    PlayerXd=PlayerXd*0.96
  else
    PlayerVl=PlayerVl*0.995*drftslw
    PlayerXd=PlayerXd*0.95
  end
end
if PlayerVl < 0.02 then
  PlayerVl = 0
end

PlayerVf = PlayerVl*0.35
Position=Position+PlayerVf
if Position > SEG_LEN*NumSegs then
  Position -= SEG_LEN*NumSegs
  PlayerLap += 1
end

PlayerSeg=DepthToSegIndex(Position)

nxtseg=(PlayerSeg)%NumSegs + 1
posinseg=1-(PlayerSeg*SEG_LEN-Position)/SEG_LEN

if RaceState == 3 then
  PlayerX=lerp(PlayerX,sPointsX[PlayerSeg],0.05)
end
if abs( PlayerXd ) < 0.005 then
  PlayerXd = 0
end
PlayerX+=sPointsC[PlayerSeg]*0.45*PlayerVl*0.01 + PlayerXd*0.15

if abs( PlayerXd ) < 0.08 then
  PlayerDrift=0
end

HznOffset = HznOffset + sPointsC[PlayerSeg] * 0.14 * (PlayerVf)

if PlayerDrift==0 then
  Pfrm-=.2
else
  Pfrm+=.2
end
Pfrm=mid(0,Pfrm,1)

-- jumps / player y

local ground = lerp( sPointsY[PlayerSeg], sPointsY[nxtseg], posinseg)
PlayerY=max(PlayerY+PlayerYd, ground)
if( PlayerY == ground ) then
  if PlayerYd < -2 and PlayerAir > 4 then
    sScreenShake = {1.5,4}
    sfx( 11, 2 )
    AddParticle( 6, 52, 122 )
    AddParticle( 7, 78, 126 )
    AddParticle( 1, 52, 122 )
    AddParticle( 2, 78, 122 )
  end
  local nposinseg=1-(PlayerSeg*SEG_LEN-(Position+PlayerVf ))/SEG_LEN
  local nground = lerp( sPointsY[PlayerSeg], sPointsY[nxtseg], nposinseg )
  PlayerYd = ( nground - ground ) - 0.2
  PlayerAir = 0
else
  PlayerYd=PlayerYd-0.25
  PlayerAir = PlayerAir + 1
end

-- particles

if RecoverStage < 2 then
  if IsOffRoad() then
    if PlayerVf > 1 then
      if Frame%5 == 0 then
        srand(Frame)
        AddParticle( 3, 64 + flr(rnd(32))-16, 120 + rnd( 1 ) )
      end
      if Frame%10 == 0 then
        sScreenShake[1],sScreenShake[2] = 1,1
      end
    end
  else
    if Frame%8 == 0 and PlayerAir == 0 then
      if PlayerDrift < 0 then
        AddParticle( 1, 62 - rnd( 4 ), 120 + rnd( 2 ) )
      elseif PlayerDrift > 0 then
        AddParticle( 2, 74 + rnd( 4 ), 120 + rnd( 2 ) )
      elseif IsBurnout() then
        AddParticle( 1, 50 - rnd( 4 ), 122 )
        AddParticle( 2, 80 + rnd( 4 ), 122 )
      end
    end
  end
end
end

function UpdateRecover()

if RecoverStage == 0 then
  return
else

  t1,t2,t3=1.5,2.5,3.5
  if RecoverStage == 1 then
    srand( time() )
    if Frame%2==0 then
      AddParticle( 8, 64 + rnd(8)-4, 98 + rnd( 2 ) )
    end
    if Frame%4==0 then
      AddParticle( 9, 64 + rnd(8)-4, 88 + rnd( 8 ) )
    end

    if time() - RecoverTimer >= t1 then
      RecoverStage = 2
      ClearParticles()
    end
  elseif RecoverStage == 2 then
    instage=(time()-RecoverTimer-t1)/(t2-t1)
    PlayerVl=8
    PlayerX=lerp(PlayerX,0,instage)
    if time() - RecoverTimer >= t2 then
      RecoverStage = 3
      InvincibleTime=time()+1
    end
  elseif RecoverStage == 3 then
    PlayerX = 0
    PlayerVl=8
    if time() - RecoverTimer >= t3 then RecoverStage = 0 end
  end
end
end

function UpdateOpts()

for i=1,#OpptPos do

  OpptPos[i]=OpptPos[i]+OpptV[i]

  if OpptPos[i] > SEG_LEN*NumSegs then
    OpptPos[i] -= SEG_LEN*NumSegs
    OpptLap[i] += 1
  end
  OpptSeg[i]=DepthToSegIndex(OpptPos[i])
  plsegoff1=(OpptSeg[i]-PlayerSeg)%NumSegs+1

  if RaceState > 1 then
    local opv=(NUM_LAPS-OpptLap[i])*0.017
    local opspd=(0.04+PlayerVl*0.022+i*0.008+opv)
    if RaceState >= 3 then
      opspd=0.08
    end
    OpptV[i]=OpptV[i]+opspd
    OpptV[i]=OpptV[i]*0.92

    if RecoverStage == 0 then
      srand(i)
      OpptX[i] = min( max( OpptX[i] + sPointsC[OpptSeg[i]] * (0.008+rnd(0.01)), -0.6 ), 0.6 ) * (0.99+rnd(0.005))
    end
  end
end
end

function AddCollisionParticles()
AddParticle( 4, 64 + rnd(32)-16, 96 + rnd( 8 ) )
AddParticle( 5, 64 + rnd(32)-16, 96 + rnd( 8 ) )
AddParticle( 6, 64 + rnd(16)-8, 102 - rnd( 8 ) )
AddParticle( 7, 54 + rnd(32)-16, 102 + rnd( 8 ) )
AddParticle( 7, 64 + rnd(16)-8, 102 - rnd( 8 ) )
AddParticle( 6, 74 + rnd(32)-16, 102 + rnd( 8 ) )
end

function UpdateCollide()

if InvincibleTime > 0 or RecoverStage > 0 or RaceState >= 3 then
  return
end

local nxtseg=(PlayerSeg)%NumSegs + 1

-- opponents

local carlen=2+PlayerVl*0.1

local ground = lerp( sPointsY[PlayerSeg], sPointsY[nxtseg], posinseg)
for i=1,#OpptPos do

  local opposl = LoopedTrackPos( OpptPos[i] )

  if ( Position + PlayerVf ) > ( opposl - carlen + OpptV[i] ) and
      ( Position + PlayerVf ) < ( opposl + OpptV[i] ) and
    ROAD_WIDTH * abs( PlayerX - OpptX[i] ) < 12 and
    ( PlayerY-ground ) < 2 then

    sfx( 7, 2 )

    PlayerVl = OpptV[i]
    PlayerXd = -sgn(PlayerX) * 0.2

    sScreenShake[1],sScreenShake[2] = 4, 2

    AddCollisionParticles()

  end
end

-- tokens

if sTokensX[nxtseg] != 0 and sTokensExist[nxtseg] != 0 then
  hitbox=0.2
  if PlayerDrift != 0 then
    hitbox=0.25
  end
  if abs( PlayerX - sTokensX[nxtseg] ) < hitbox and
    ( Position + carlen + PlayerVf ) > PlayerSeg*SEG_LEN then
    sTokensExist[nxtseg] = 0
    TokenCollected+=1
    if TokenCollected == NumTokens then
      sfx( 10, 3 )
    else
      sfx( 9, 3 )
    end
  end
end

-- sprites

if SpriteCollideIdx > 0 then --and ( Position + carlen + PlayerVf ) > PlayerSeg*SEG_LEN then

  sdef1=SDEF[SpriteCollideIdx]
  if sdef1[8]==1 then

    -- work out range of pixels in the source sprite that we overlap
    -- player is ~40-80px
    local insprx1=(48-SpriteCollideRect[1])/SpriteCollideRect[3]
    local insprx2=(80-SpriteCollideRect[1])/SpriteCollideRect[3]

    it1=flr(max(sdef1[3]*insprx1,0))
    it2=flr(min(sdef1[3]*insprx2,sdef1[3]))

    collided=0
    if sdef1[7]==0 then
      for colit=flr(it1), flr(it2)-1 do
        if sget(sdef1[1]+colit,sdef1[2]+sdef1[4]-1)!=15 then
          collided=1
          break
        end
      end
    else
      --flipped
      for colit=sdef1[3]-flr(it2), (sdef1[3]-flr(it1))-1 do
        if sget(sdef1[1]+colit,sdef1[2]+sdef1[4]-1)!=15 then
          collided=1
          break
        end
      end
    end

    if collided == 1 then

  if PlayerVf < 4 then
    -- small hit
    sfx( 7, 2 )
    sScreenShake[1],sScreenShake[2] = 3, 1
    PlayerVl = PlayerVl * 0.2
    PlayerXd = -sgn(PlayerX) * 0.2
    InvincibleTime=time()+1
    AddParticle( 4, 64 + rnd(32)-16, 96 + rnd( 8 ) )
    AddParticle( 5, 64 + rnd(32)-16, 96 + rnd( 8 ) )
  else
    -- big hit
    sfx( 6, 2 )
    sScreenShake[1],sScreenShake[2] = 10, 4

    PlayerXd = sgn(PlayerX) * 0.2
    PlayerVl = PlayerVl * 0.2
    RecoverStage = 1
    RecoverTimer = time()
    AddCollisionParticles()
  end

    end
  end
end
end

function UpdateRaceState()
if RaceState==1 and RaceStateTime() > 3 then
  RaceState=2
  RaceStateTimer=time()
elseif RaceState==2 and PlayerLap == NUM_LAPS+1 then
  RaceState=3
  RaceCompleteTime=RaceStateTime()
  RaceCompletePos=GetPlayerStanding()
  RaceStateTimer=time()
  ProfTime=ReadProfile( Level, 3 )
  if ProfTime==0 or RaceCompleteTime < ProfTime then
    WriteProfile( Level, 3, RaceCompleteTime )
  end
  ProfStand=ReadProfile( Level, 1 )
  if ProfStand==0 or RaceCompletePos < ProfStand then
    WriteProfile( Level, 1, RaceCompletePos )
  end
  if TokenCollected > ReadProfile( Level, 2 ) then
    WriteProfile( Level, 2, TokenCollected )
  end
end
end

function UpdateRace()
if RaceState < 4 then
  -- screenshake
  sScreenShake[1]=lerp(sScreenShake[1],0, 0.1)
  sScreenShake[2]=lerp(sScreenShake[2],0, 0.1)
  if Frame%3 == 0 then
    sScreenShake[1]=-sScreenShake[1]
    sScreenShake[2]=-sScreenShake[2]
  end
  if( abs( sScreenShake[1] ) + abs( sScreenShake[2] ) < 1 ) then
    sScreenShake = {0,0}
  end

  UpdatePlayer()
  UpdateRecover()
  UpdateCollide()
  UpdateOpts()
  UpdateParticles()
  UpdateRaceState()
else
  if btnp(🅾️) then
    OpenMenu(MenuState)
  elseif btnp(❎) then
    InitRace()
  end
end
end

function _update60()

--DebugUpdate()
Frame=Frame+1
if TitleState == 1 then
  UpdateMenus()
elseif TitleState == 2 then
  UpdateRace()
end
UpdateRaceSound()
end

function HrzSprite( x, ssx, ssy, f )
hsprdef=HORZSDEF[THEMEDEF[Theme][11]]
ssy=ssy*hsprdef[6]
sspr( hsprdef[1],hsprdef[2],hsprdef[3],hsprdef[4],
  (HznOffset + x) % 256 - 128, 64 - flr( ssy * 16 ), ssx*hsprdef[5] * 48, ssy * 16, f )
end

function RenderHorizon()

fillp(0)
rectfill( 0, 64, 128, 128, THEMEDEF[Theme][4] ) -- block out the ground
HrzSprite(10, 1.0, 0.7, true)
HrzSprite(64, 0.3, 1.2, false)
HrzSprite(60, 2.3, 0.3, false)
HrzSprite(128, 1, 1, false)
HrzSprite(178, 1.5, 0.5, true)

end

function RenderSky()
local thm = THEMEDEF[Theme]
fillp(0)
rectfill( 0, 0, 128, 20, thm[10] ) -- block out
BayerRectV( 0, 20, 138, 50, thm[9], thm[10] )
fillp(0)
rectfill( 0, 50, 128, 64, thm[9] ) -- block out
end

function RenderP4( xlt, xrt, xlb, xrb, yt, yb, c )

if yt - yb < 1 then
return
elseif yt - yb < 2 then
  line( xlt, yt, xrt, yt, c)
else
  yd=yt-yb
  rp=1/yd
  xldlt=(xlt-xlb)*rp
  xrdlt=(xrt-xrb)*rp
  for i=yb,yt do
    if i > 126 then return end
    line( xlb, i, xrb, i, c)
    xlb+=xldlt
    xrb+=xrdlt
  end
end
end

function RenderSeg( x1, y1, w1, x2, y2, w2, idx )

local thm=THEMEDEF[Theme]

-- Ground, We only render intermittent strips, most of the ground has been
-- blocked out in the road render before this
if idx % 8 <= 3 then
  fillp(0x5A5A)
  RenderP4( -1, x1-w1, -1, x2-w2, y1, y2, thm[5] )
  RenderP4( x1+w1, 128, x2+w2, 128, y1, y2,thm[5] )
end

-- Edge
if idx % 4 > 1 then
  fillp(0)
  col = thm[6]
else
  fillp(0x5A5A)
  col = thm[7]
end
edgew1=w1*0.86
edgew2=w2*0.86
RenderP4( x1-edgew1, x1-w1,x2-edgew2, x2-w2, y1, y2, col )
RenderP4( x1+w1, x1+edgew1, x2+w2, x2+edgew2, y1, y2, col )

-- Road
fillp(0)
if thm[3] == 1 then
  -- stripes
  if idx == 1 then
    col = 1
  else
    if idx % 3 == 0 then
      fillp(0x5A5A)
      col = thm[2]
    else
      col = thm[1]
    end
  end
  RenderP4( x1-edgew1, x1+edgew1, x2-edgew2, x2+edgew2, y1, y2, col )
elseif thm[3] == 2 then
  -- patches
  fillp(0x5A5A)
  -- TODO: dont overdraw
  RenderP4( x1-edgew1, x1+edgew1, x2-edgew2, x2+edgew2, y1, y2, thm[2] )
  fillp(0)
  if idx == 1 then
    col = 1
  else
    col = thm[1]
  end
  srand( idx )
  rx1=rnd( 0.6 ) + 0.3
  rx2=rnd( 0.6 ) + 0.3
  RenderP4( x1-edgew1*rx1, x1+edgew1*rx2, x2-edgew2*rx1, x2+edgew2*rx2, y1, y2, col )
end

  -- Lanes
  if thm[8] == 1 then
  -- edge lane
  if idx % 2 > 0 then
    fillp(0)
    RenderP4( x1-w1*0.74, x1-w1*0.78, x2-w2*0.74, x2-w2*0.78, y1, y2, 6 )
    RenderP4( x1+w1*0.78, x1+w1*0.74, x2+w2*0.78, x2+w2*0.74, y1, y2, 6 )
  end
elseif thm[8] == 2 then
  -- centre alternating
  if idx % 4 > 2 then
    fillp(0)
    lanew=0.02
    RenderP4(x1-w1*lanew,x1+w1*lanew,x2-w2*lanew,x2+w2*lanew,y1,y2,6 )
  end
elseif thm[8] == 3 then
    -- 3 lane yellow
  if idx % 4 == 0 then
    fillp(0)
    RenderP4( x1-w1*0.3, x1-w1*0.34, x2-w2*0.3, x2-w2*0.34, y1, y2, 9 )
    RenderP4( x1+w1*0.34, x1+w1*0.3, x2+w2*0.34, x2+w2*0.3, y1, y2, 9 )
  end
end
end


function _draw()
--cls()
if TitleState == 1 then
  RenderMenus()
elseif TitleState == 2 then
  if RaceState < 4 then
    camera( sScreenShake[1], HUD_HEIGHT + sScreenShake[2] )
    RenderSky()
    RenderHorizon()
    RenderRoad()
    camera( 0, 0 )
    RenderRaceUI()
  else
    RenderSummaryUI()
  end
end
--DebugRender()
end

function PrintBigDigit( n, x, y,nrend)
x-=2
if not nrend then
poke(0x5f58, 0x1 | 0x80) --custom font
  n1=n*2+16+n\8*16
  print(chr(n1)..chr(n1+1).."\n"..chr(n1+16)..chr(n1+17),x,y-3,7) --4 chars to print 1 big
poke(0x5f58, 0x0) --default font
end
if (n==1) return 12
return 16
end

function PrintBigDigitOutline( n, x, y, col )
i=n+1
pal( 7, col )
PrintBigDigit( n, x-1, y )
PrintBigDigit( n, x+1, y )
PrintBigDigit( n, x, y-1 )
PrintBigDigit( n, x, y+1 )
pal( 7, 7 )
end

function GetPlayerStanding()
s=#OpptPos+1
for i=1,#OpptPos do
  if OpptLap[i] < PlayerLap then
    s-=1
  elseif OpptLap[i] == PlayerLap and OpptPos[i]<Position then
    s-=1
  end
end
return s
end

function GetStandingSuffix(n)
stnd=split"st,nd,rd"
if n < 4 then
  return stnd[n]
end
return "th"
end

function RenderCountdown()
if RaceState == 2 and RaceStateTime() < 1 then
  frac=( time() - RaceStateTimer )%1
  x=64-16
  PrintBigDigitOutline( 10,x,30, 0 )
  PrintBigDigit( 10,x,30)
  x=x+16
  PrintBigDigitOutline( 0,x,30, 0 )
  PrintBigDigit( 0,x,30)
elseif RaceState == 1 then
  num= 3-flr( RaceStateTime() )
  frac=( RaceStateTime() )%1
  if num <= 0 then
    return
  elseif frac < 0.9 then
    x=64-8
    PrintBigDigitOutline( num,x,30, 0 )
    PrintBigDigit( num,x,30)
  end
end
end

function RenderRaceEndStanding()
if (RaceState != 3) return

if RaceStateTime() < 1 then
  clip( 0, 0, (RaceStateTime()*8)*128, 128 )
elseif RaceStateTime() > 3 then
  clip( ((RaceStateTime()-3)*8)*128, 0, 128, 128 )
end
rectfill( 0, 25, 128, 49, 1 )
tw=PrintBigDigit( RaceCompletePos, 0, 0, 1 )
PrintBigDigit( RaceCompletePos, 53, 32)
print( GetStandingSuffix(RaceCompletePos), 64+tw*0.5-5, 32, 7 )

sspr(unpack(split"120, 16, 7, 18, 37, 27, -7, 18"))
sspr(unpack(split"120, 16, 7, 18, 84, 27, 7, 18"))

clip()

if RaceStateTime() > 3.6 then
  fade=max( (0.5-(time()-(RaceStateTimer+3.6)))/0.5, 0 )
  BayerRectT( fade, 0, 0, 128, 128, 0xE0 )
  if RaceStateTime() > 4.8 then
    RaceState = 4
    RaceStateTimer=time()
  end
end
end

function RenderSummaryUI()

rectfill( 0, 0, 128, 128, 0 )

if RaceStateTime() < 1 then
  clip( 0, 0, 128, ((RaceStateTime())*3)*128 )
end

for x=-1,7 do
  for y=-1,7 do
    off=(Frame*0.5)%16
    xoff=x*16+off
    yoff=y*16+off
    RenderFlag( xoff, yoff, Level )
    BayerRectT( max(sin(Frame/120+xoff/53+yoff/63)+1,0.1), xoff, yoff, xoff+10, yoff+7 )
  end
end
fillp()

if RaceStateTime() > 1 then

  if (RaceStateTime() < 2) then
    clip( 0, 0, ((RaceStateTime()-1)*16)*128, 128 )
  end

  rectfill( 0, 10, 128, 23, 13 )
  rectfill( 0, 34, 128, 90, 13 )
  line( 0, 33, 128, 33, 1 )
  line( 0, 91, 128, 91, 1 )
  rectfill( 0, 101, 128, 117, 13 )

  fillp(0x33CC)
  col = bor( 6 << 4, 0 )
  rectfill(0,12,33,21, col)
  rectfill(94,12,128,21, col)
  RenderTextOutlined( "race complete", 38, 15, 0, 7 )
  fillp()

  -- position
  rectfill(0,39,64,51, 1)
  print( "position", 19, 43, 6 )
  sspr( 65, 49, 8, 8, 54, 41 ) -- trophy

  -- tokens
  rectfill(0,56,64,68, 2)
  print( "tokens", 27, 60, 6 )
  sspr( 17, 121, 7, 7, 55, 59 )

  -- time
  rectfill(0,73,64,85, 3)
  print( "time", 35, 77, 6 )
  sspr( 73, 50, 7, 7, 55, 76 )

  -- position text
  col=RaceCompletePos == 1 and 9 or 7
  print( tostr( RaceCompletePos ).. tostr( GetStandingSuffix(RaceCompletePos) ), 69, 43, col )

  -- tokens text
  col=7
  if TokenCollected == NumTokens then
    col = 9
  end
  print( tostr( TokenCollected ).."/".. tostr( NumTokens ), 69, 60, col )

  -- time text
  PrintTime( RaceCompleteTime, 69, 77 )

  -- controls
  print( " \142  menu", 45, 104, 6 )
  print( " \151  retry", 45, 110, 6 )

  clip()
end
end

function RenderRaceUI()

fillp(0)
rectfill( 0,111, 127, 127, 0 )
rect( 0, 111, 127, 127, 6 )
rect( 1, 112, 126, 126, 13 )

stand=GetPlayerStanding()
strlen=PrintBigDigit( GetPlayerStanding(), 3, 114)
print( GetStandingSuffix(stand), strlen+1, 114, 7 )

sspr(unpack(split"52, 24, 7, 5, 38, 120"))
sspr(unpack(split"59, 24, 9, 5, 37, 114"))
print( min(PlayerLap, NUM_LAPS), 49, 114, 6 )
print( "/"..tostr(NUM_LAPS), 57, 114, 5 )
print( TokenCollected, 49, 120, 6 )
print( "/" ..tostr(NumTokens), 57, 120, 5 )

for i=80, 124, 2 do
  y1 = flr(lerp( 121, 115, (i-107)/(113-107) ))
  y1=max(min(y1,121),115)
  -- top speed is ~17.5 m/s
  norm=(i-80)/(128-80)

  col = 5
  if norm < PlayerVl/19 then
    if i < 104 then col = 6
    elseif i < 118 then col = 7
    elseif i < 122 then col = 9
    else col = 8
    end
  end
  line( i, y1, i, 124, col )
end

spd=flr( PlayerVl * 8.5 )
x1=88
if spd > 9 then
  x1 -= 4
end
if spd > 99 then
  x1-= 4
end
print( spd, x1, 114, 6 )
print( "mph", 94, 114, 6 )
RenderCountdown()
RenderRaceEndStanding()

end

function RenderPlayer()

if RecoverStage == 2 or ( InvincibleTime-time() > 0 and time()%0.4>0.2 ) then
  return
end

local woby=0

function drawDrift()
  if Pfrm==0 and (PlayerXd <= 0.28 and PlayerXd >=-0.28) then
    fillp()
    local px=48+woby
    pd_draw(4,px+PlayerXd,92,1,9)
    pd_draw(4,px-PlayerXd*6\1,92,10,17)
    pd_draw(4,px-PlayerXd*11\1,92,18,40)
  elseif Pfrm > .6 then
    sspr(52, 0, 47, 23, 44, 100+woby, 47, 23, PlayerXd > 0 ) --drift
  else
    sspr(16, 0, 35, 23, 47+woby, 100, 35, 23, PlayerXd>0) --turn
  end
end

if PlayerDrift != 0 or IsBurnout() then -- z / btn1
  srand(time())
  woby=rnd(1.2)
end

drawDrift()

end

function GetSpriteSSRect( s, x1, y1, w1, sc )
ssc = w1*sc
aspx = ssc
aspy = ssc
if SDEF[s][3] > SDEF[s][4] then
  aspx = ssc*SDEF[s][3]/SDEF[s][4]
else
  aspy = ssc*SDEF[s][4]/SDEF[s][3]
end

rrect= { x1 - aspx * 0.5,
  y1 - aspy,
  aspx,
  aspy }
return rrect
end

function RenderSpriteWorld( s, rrect, f)
local w = ceil(rrect[3] + 1)
sspr( SDEF[s][1], SDEF[s][2], SDEF[s][3], SDEF[s][4], rrect[1]+(f and w or 0), rrect[2], w, ceil(rrect[4] + 1), f or SDEF[s][7] == 1 )
end

function RenderRoad()

local loopoff,xoff = 0,0

local pscreenscale, psx, psy, psw, pcamx, pcamy, pcamz, pcrv, clipy={},{},{},{},{},{},{},{},{}

local camx = PlayerX * ROAD_WIDTH

local function RenderOpponent(o,i,t)

  -- Imposters, render at the seg pos/middle of road
  local opsx,opsy,opsw =psx[i],psy[i],psw[i]
  local seg = OpptSeg[o]

  if i<50 then

    local plsegoff1=(seg-PlayerSeg)%NumSegs+1
    local opinseg=1-(seg*SEG_LEN-OpptPos[o])/SEG_LEN
    local nxtseg = seg % NumSegs + 1
    local plsegoff2=(nxtseg-PlayerSeg)%NumSegs+1
    local ppos=Position

    if OpptLap[o] > PlayerLap then
      ppos-=SEG_LEN*NumSegs
    end

    local ocrv=lerp( pcrv[plsegoff1], pcrv[plsegoff2], opinseg )
    local optx=OpptX[o]*ROAD_WIDTH

    local opcamx = lerp( sPointsX[seg ] + optx, sPointsX[nxtseg] + optx, opinseg ) - camx - ocrv
    local opcamy = lerp( sPointsY[seg ], sPointsY[nxtseg], opinseg ) - ( CAM_HEIGHT + PlayerY )
    local opcamz = lerp( sPointsZ[seg ], sPointsZ[nxtseg], opinseg ) - ppos

    local opss = CAM_DEPTH/opcamz
    opsx = flr(64 + (opss * opcamx * 64))
    opsy = flr(64 - (opss * opcamy * 64))
    opsw = flr(opss * ROAD_WIDTH * 64)
  end

  pal( 14, opcols1[o%#opcols1+1] )
  pal( 2, opcols2[o%#opcols2+1] )

  if sPointsC[seg ] > 0.5 then
    local rrect = GetSpriteSSRect( 8, opsx, opsy,opsw, .16 )
    RenderSpriteWorld( 8+t, rrect)
  elseif sPointsC[seg ] < -0.5 then
    local rrect = GetSpriteSSRect( 9, opsx, opsy,opsw, .16 )
    RenderSpriteWorld( 9+t, rrect )
  else
    local rrect = GetSpriteSSRect( 7, opsx, opsy,opsw, .12 )
    RenderSpriteWorld( 7+t, rrect )
    RenderSpriteWorld( 7+t, rrect,1)
  end
end

local posinseg=1-(PlayerSeg*SEG_LEN-Position)/SEG_LEN
local dxoff = - sPointsC[PlayerSeg] * posinseg

-- calculate projections
local hrzny=128
local hrzseg=DRAW_DIST

for i = 1, DRAW_DIST do

  -- fun foreshortening hack (add to i in statement below)
  -- oop=flr(max(i/DRAW_DIST-0.4,0)*50)
  local segidx = (PlayerSeg - 2 + i ) % NumSegs + 1

  pcrv[i] = xoff - dxoff
  pcamx[i] = sPointsX[segidx] - camx - pcrv[i]
  pcamy[i] = sPointsY[segidx] - ( CAM_HEIGHT + PlayerY )
  pcamz[i] = sPointsZ[segidx] - (Position - loopoff)

  if segidx == NumSegs then
    loopoff+=NumSegs*SEG_LEN
  end

  xoff = xoff + dxoff
  dxoff = dxoff + sPointsC[segidx]

  pscreenscale[i] = CAM_DEPTH/pcamz[i]
  psx[i] = (64 + (pscreenscale[i] * pcamx[i]  * 64))
  psy[i] = flr(64 - (pscreenscale[i] * pcamy[i]  * 64))
  psw[i] = (pscreenscale[i] * ROAD_WIDTH * 64)

  -- store the min y to block out the ground
  if psy[i] < hrzny then
    hrzny=psy[i]+1
    hrzseg=i
  end

end

SpriteCollideIdx=-1

for i = DRAW_DIST - 1, 1, -1 do

  segidx = (PlayerSeg - 2 + i ) % NumSegs + 1

    if i+1== hrzseg then
    fillp(0)
    rectfill( 0, hrzny, 128, 128, THEMEDEF[Theme][4] ) -- block out the ground
  end

  -- segments
  local j=i+1
  if psy[i] > psy[j] and ( psy[i] >= hrzny ) then
    RenderSeg( psx[i], psy[i], psw[i], psx[j], psy[j], psw[j], segidx )
  end
  if i==1 and TitleState == 2 then
    RenderPlayer()
    RenderParticles()
  end

  -- sprites

  --local d = min( ( 1 - pcamz[i] / (DRAW_DIST*SEG_LEN) ) * 8 , 1 ) --passed to RenderSpriteworld but unused?
  local pcamx,psscale,rrect=pcamx[i],pscreenscale[i]
  if sSprite[segidx] != 0 then
    local psx1 = flr(64 + (psscale * ( pcamx + sSpriteX[segidx] * ROAD_WIDTH ) * 64))

    local sindx=sSprite[segidx]
    rrect = GetSpriteSSRect( sindx, psx1, psy[i],psw[i], sSpriteSc[segidx] )
    RenderSpriteWorld( sindx, rrect)
    if i == 2 then
      SpriteCollideRect = rrect
      SpriteCollideIdx=sSprite[segidx]
    end
  end

  -- Start gantry
  if segidx == 1 or segidx == 2 then
    local psx1l = flr(64 + (psscale * ( pcamx + ROAD_WIDTH * -1.2 ) * 64))
    local psx1r = flr(64 + (psscale * ( pcamx + ROAD_WIDTH * 1.2 ) * 64))
    rrect = GetSpriteSSRect( 11, psx1l, psy[i],psw[i], 0.14 )
    RenderSpriteWorld( 11, rrect)
    rrect = GetSpriteSSRect( 11, psx1r, psy[i],psw[i], 0.14 )
    RenderSpriteWorld( 11, rrect )

    if segidx == 1 then
      psx1l = flr(64 + (psscale * ( pcamx + ROAD_WIDTH * -0.55 ) * 64))
      psx1r = flr(64 + (psscale * ( pcamx + ROAD_WIDTH * 0.55 ) * 64))
      for j=12,13 do
        rrect = GetSpriteSSRect( j, j==12 and psx1l or psx1r, psy[i], psw[i], .75 )
        rrect[2]-=.25*psw[i]
        RenderSpriteWorld( j, rrect )
      end
    end
  end

  -- tokens
  if sTokensX[segidx] !=0 and sTokensExist[segidx] != 0 then
    local psx1 = flr(64 + (psscale * ( pcamx + sTokensX[segidx] * ROAD_WIDTH ) * 64))
    local psy1 = flr(64 - (psscale * ( pcamy[i] + 4 )  * 64))
    rrect = GetSpriteSSRect( 43, psx1, psy1,psw[i], 0.15 )
    RenderSpriteWorld( 43, rrect)
  end

  -- opponents
  for o = 1,#OpptPos do
    if (OpptSeg[o] == segidx) RenderOpponent(o,i,CType[o%3+1])
  end
  pal( 14, 14 )
  pal( 2, 2 )

-- snow
if Theme==6 then
fillp()
rdst=60
if i < rdst and i > 1 then
  for r=1,(rdst-i)*0.2 do
  srand( segidx * r * 777 )
  local psx1 = flr(64 + (psscale * ( pcamx + (rnd(10)-5) * ROAD_WIDTH ) * 64))
  tt=(Frame*0.5*(rnd(2)+1) + rnd(128))%200
  sz=psw[i]*0.02
  circfill( psx1, min( tt, psy[i] ), sz, 7 )
  end
end
end

end

end
