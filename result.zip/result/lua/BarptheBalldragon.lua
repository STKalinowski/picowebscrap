-- barp the balldragon

a,b,
c,d=
0,
1,
1,
{0,0,0,0}
e=0
f={0,0xffff}
g={0xffff,0,h=f}
i={0,1,h=g}
j={1,0,h=i}
f.h=j
k="abcdefghijklmnopqrstuvwxyz1234567890`~!@#$%^&*()-_=+[{]}|;:',./?"
function l()
m={}
for n=1,64 do
m[sub(k,n,n)]=n-1
end
end
function o(p,q)
q,r,s=
q or 6,{},1
if type(p)=="string"then
for n=1,#p do
local t=m[sub(p,n,n)]
for u=0,q-1 do
add(r,v(band(t,shl(1,u))))
end
end
else
for n=p,p+q-1 do
local t=peek(n)
for u=0,7 do
add(r,v(band(t,shr(128,u))))
end
end
end
end
function w(q)
q=q or 5
local x=0
for n=1,q do
x*=2
x+=r[s]
s+=1
end
return x
end
function y()
return w(1)==1
end
function z(q,ba)
if y() then
return w(q)
else
return ba
end
end
function bb()
o(bc)
bc={}
local bd=w(8)
for n=1,bd do
local be,bf={},w(4)
be.bg=w(4)
for n=1,bf do
add(be,w(8))
end
be.bd=be[1]
add(bc,be)
end
end
function bh()
o(bi)
bi={}
local bj=w(4)
for n=1,bj do
local bk={}
for bl=1,20 do
bk[bl-1]=w(4)
end
add(bi,bk)
end
o(bm)
bm,bj=
{},
w(8)
for n=1,bj do
local bk={}
for bl=1,16 do
if y() then
bk[bl-1]=w()
end
end
add(bm,bk)
end
end
function bn()
o(bo)
bo={}
local bd=w(8)
for n=1,bd do
local bp={
map=w(7),
bq=w(8),
br=w(8),
b=y()
}
bo[n]=bp
end
end
function bs()
for n=1,#bt do
o(bt[n])
bt[n]={
bu=w(8),
bv={
w(3),
w(3),
w(3),
w(3)
}
}
end
end
function bw()
local bx={
by,
bz,
ca,
cb,
cc
}
o(cd)
cd={}
local bj=w(8)
for n=1,bj do
local ce={
cf=w(8),
cg=bm[w()],
ch=w(8),
ci=bx[w(3)],
cj=y(),
ck=y()
}
add(cd,ce)
end
end
function cl()
for cm,be in pairs(cn) do
o(be[1])
be.ck=z(6)
be.co=y()
be.cg=z(6)
be.cp=z(5)
be.cq=z(5)
be.cr=z(5)
be.cs=y()
be.ct=z(8)
be.cu=z(4)
end
for cm,be in pairs(cn) do
be.cg=bm[be.cg]
end
end
function cv(cw,cx,cy)
o(cw,cx)
local bd=w(6)
for n=1,bd do
local p,cx=
"",
w(10)
for u=1,cx do
local cz=w(6)+1
p=p..sub(k,cz,cz)
end
add(cy,p)
end
end
function da()
cv(0x2000,0x1000,db)
cv(0x3200,0x0c7c,dc)
end
function dd()
for bq=0,15 do
for br=0,15 do
mset(16+bq,br,106+sget(72+bq,48+br))
mset(32+bq,br,123+sget(111,32+br))
mset(64+bq,br,196+sget(112+bq,32+br))
end
end
end
de=false
function df()
de,dg,dh=
true,
16,
0xffff
end
function di()
de,dg,dh=
true,
0,
1
end
function dj()
local br=56+dk(dg,4)
for n=1,15 do
pal(n,sget(8+n,br),1)
end
dg+=dh
if dg==0 or dg==16 then
de=false
end
end
function dl()
if dm==3 then
circfill(64,48,20,10)
elseif dm>0 then
map(dm*16,0,0,0,16,16)
end
end
function dn(dp)
if dp<1 then
music(0xffff,1500)
return
elseif dp!=dq then
if dp<60 then
o(dc[dp])
local dr,ds=
w(7),w(7)
local bj
for n=1,dr*4 do
poke(0x30ff+n,w(8))
end
local dt,du={},{}
bj=w()
for n=1,bj do
add(dt,w(9))
end
bj=w()
for n=1,bj do
add(du,w(6))
end
for dv=0,ds do
local cw,dw,dx=
0x3200+dv*68,
w(6),
w(1)
for n=cw,cw+63,2 do
local dy,dz=0,0
if y() then
local ea,bk=dt[w()],
du[w()]
dy,dz=
ea*64+bk,
ea/4
end
poke(n,dy)
poke(n+1,dz)
end
poke(cw+65,dw)
poke(cw+66,0)
poke(cw+67,dx*32)
end
music(0,0,12)
dq=dp;
else
reload(0x3100,0x3100,2432)
music(dp,15)
dq=0xffff;
end
end
end
function eb(bl,be,t)
if(bl) return be
return t
end
function v(ec)
return eb(ec==0,0,sgn(ec))
end
function dk(ed,ee)
return flr(ed/(ee or 8))
end
function ef()
end
function eg()
eh,ei=
mid(ej-64,0,ek*8-128),
mid(el-64,0,em*8-128)
en,eo=
dk(eh),
dk(ei)
camera(eh,ei)
end
function ep()
ej,el=
eq.bq+4,
eq.br+4
eg()
end
function er(be)
if(be.bq<0) be.bq+=128
if(be.bq>=128) be.bq-=128
end
function es()
if e<2 then
ej,el=
eq.bq+4,
eq.br+4
elseif e==2 then
ej+=0.3
el=eq.br+4
else
ej=eq.bq+4
el-=0.3
end
eg()
if e==1 then
er(eq)
foreach(et,er)
foreach(eu,er)
foreach(ev,er)
foreach(ew,er)
else
eq.bq,eq.br=
mid(eq.bq,eh,eh+120),
max(eq.br,ei-16)
if ex(eq.bq+7,eq.br,8) then
ey(eq,true)
end
end
end
function ez(bk)
fa=bi[bk]
end
function fb(bk)
if fc!=bk then
fc=bk
if bk then
for n=0,15 do
if bk[n] then
palt(n,false)
pal(n,fa[bk[n]])
else
palt(n,true)
end
end
else
for n=0,15 do
palt(n,false)
pal(n,fa[n])
end
palt(0,true)
end
end
end
function fd(bq,br)
return fe[bq] and
fe[bq][br]
end
function ff(bd)
local p=db[bd]
local cq,cr,fg
o(p)
fh,fi,
fj,a,
dm,fk,fl,
fm=w(3),w(3),
w(4),w(8),
w(4),w(1),
w(3)+1,w(7)
if fk==0 then
cq,cr=w(),w(2)
fg=cq
else
cq,cr=w(2),w()
fg=cr
end
ek,em,e=
cq*8+8,
cr*8+8,
w(2)
fn={}
fo={}
for n=0,fg do
fn[n]={}
local fp=w()
for u=1,fp do
bd=w(6)
local ce={
fq=n,
fr=cd[bd]
}
if fk==0 then
ce.bq,ce.br=w(3),w()
else
ce.bq,ce.br=w(),w(3)
end
ce.cq,ce.cr=w(4)+1,w(4)+1
add(fn[n],ce)
end
fo[n]={}
local fs=w(3)
for u=1,fs do
bd=w()
local be={
fq=n,
ft=bd
}
if fk==0 then
be.bq,be.br=w(3),w()
else
be.bq,be.br=w(),w(3)
end
be.fu,be.fv=w(1),
w(cn[bd].cu)
add(fo[n],be)
end
end
fw()
fx()
end
function fy()
ez(fh)
fb()
local g,ed=dk(eh),
dk(ei)
for bq=g,g+16 do
for br=ed,ed+16 do
local fz=fd(bq,br)
if fz and fz.ga>0 then
fb(fz.cg)
local ga=fz.ga
if fz.ck then
ga+=dk(gb)
end
spr(ga,bq*8,br*8)
end
end
end
end
function gc(bq,br,i)
br=mid(dk(br),0,em-1)
bq=dk(bq)
if e==1 then
bq=(bq+16)%16
elseif bq<0 or bq>=ek then
return true
end
local fz=fd(bq,br)
if fz then
if i and fget(fz.ga,1) then
return true
end
return fget(fz.ga,0)
end
end
function gd(bq,br,cq,ed)
bq=max(bq,0)
for n=band(bq,2040),band(bq+cq-1,2040),8 do
if(gc(n,br,ed)) return true
end
end
function ex(bq,br,cr)
br=max(br,0)
for n=band(br,2040),band(br+cr-1,2040),8 do
if(gc(bq,n)) return true
end
end
function ge(ce)
if fk==0 then
return ce.fq*8+ce.bq,ce.br
end
return ce.bq,ce.fq*8+ce.br
end
function by()
return 0
end
function ca(bq,br,gf,gg,gh,gi)
if(bq-gf>=gi-br) return 0
end
function cb(bq,br,gf,gg)
if(bq-gf<=br-gg) return 0
end
function bz(bq,br,gf,gg)
if(br>gg) return 16
return 0
end
function cc(bq,br,gf,gg,gh,gi)
local ga=0
if(bq>gf) ga+=2
if(bq<gh) ga+=1
if(br>gg) ga+=32
if(br<gi) ga+=16
return ga
end
function gj()
fe={}
for bq=0,ek-1 do
fe[bq]={}
for br=0,em-1 do
fe[bq][br]={ga=a}
end
end
end
function fw()
gj()
for gk=0,#fn do
local gl=fn[gk]
for ce in all(gl) do
gm(ce,ge(ce))
end
end
end
function gm(gn,gf,gg)
local gh,gi=min(gf+gn.cq-1,ek-1),
min(gg+gn.cr-1,em-1)
for bq=gf,gh do
for br=gg,gi do
local ga=gn.fr.ci(bq,br,gf,gg,gh,gi)
if ga then
fe[bq][br]={
ga=gn.fr.cf+ga,
go=gn,
cg=gn.fr.cg,
ck=gn.fr.ck
}
end
end
end
if gn.fr.cj then
for bq=gf-1,gh+1 do
for br=gg-1,gi+1 do
if gp(bq,br,gn) then
local ga=gn.fr.cf
if(bq==0 or gp(bq-1,br,gn)) ga+=2
if(bq==ek-1 or gp(bq+1,br,gn)) ga+=1
if(br==0 or gp(bq,br-1,gn)) ga+=32
if(br==em-1 or gp(bq,br+1,gn)) ga+=16
fe[bq][br].ga=ga
end
end
end
end
end
function gp(bq,br,gn)
local fz=fd(bq,br)
if fz and fz.go then
return fz.go.fr==gn.fr
end
end
function fx()
gq={}
for gk=0,#fo do
local gr=fo[gk]
for be in all(gr) do
gs(be,ge(be))
end
end
end
function gs(be,bq,br)
if(not gq[bq]) gq[bq]={}
gq[bq][br]={
ft=be.ft,
fu=be.fu,
fv=be.fv
}
end
function gt(bq,br)
local fz=gq[bq] and
gq[bq][br]
if fz then
if fz.gu and not fz.gu.gv then
return
end
local be=gw(fz.ft,bq*8,br*8,fz.fv)
be.fu=fz.fu
fz.gu=be
add(eb(be.cp,et,ew),be)
end
end
function gx(br)
for bq=en-4,en+19 do
gt(bq,br)
end
end
function gy(bq)
for br=eo-4,eo+19 do
gt(bq,br)
end
end
function gz(ha)
for be in all(ha) do
if be.bq<eh-128 or
be.bq>eh+256 or
be.br<ei-128 or
be.br>ei+256 then
be.gv=true
end
if(be.gv) del(ha,be)
end
end
hb={
bq=0,br=0,
cq=8,cr=8,
fu=0,
ck=1,
hc=0,
hd=0,
cu=0,
he=ef,
hf=ef,
hg=0,
hh=0
}
hb.__index=hb
function hi(hj,hk)
if hj.hl or hk.hl then
return false
end
return hj.bq+hj.cq>hk.bq and
hk.bq+hk.cq>hj.bq and
hj.br+hj.cr>hk.br and
hk.br+hk.cr>hj.br
end
function hm(be,hn)
return not eb(hn<0,
ex(be.bq+hn,be.br,be.cr),
ex(be.bq+be.cq-1+hn,be.br,be.cr))
end
function ho(be,fu)
if(fu[1]!=0) return hm(be,fu[1])
return hp(be,fu[2])
end
function hq(be,hn)
if hm(be,hn) then
local br=be.br+be.cr
local bq=be.bq
if(hn>0) bq+=be.cq
return gc(bq,br,true)
end
end
function hp(be,hn)
if hn<=0 then
return not gd(be.bq,be.br+hn,be.cq)
else
local ed=(be.br+be.cr-1)%8+hn>=8
return not gd(be.bq,be.br+be.cr-1+hn,be.cq,ed)
end
end
function hr(be,hn)
be.bq+=hn
if(be.cs) return
if hn<0 then
if ex(be.bq,be.br,be.cr) then
be.bq=band(be.bq+7,2040)
end
elseif hn>0 then
if ex(be.bq+be.cq-1,be.br,be.cr) then
be.bq=band(be.bq+be.cq,2040)-be.cq
end
end
end
function hs(be,hn)
if hq(be,hn) then
be.bq+=hn
elseif hn<0 then
be.bq=band(be.bq+7,2040)
else
be.bq=band(be.bq+be.cq,2040)-be.cq
end
end
function ht(be,hn)
local ed=(be.br+be.cr-1)%8+hn>=8
be.br+=hn
if(be.cs) return
if hn<0 then
if gd(be.bq,be.br,be.cq) then
be.br=band(be.br+7,2040)
end
elseif hn>0 then
if gd(be.bq,be.br+be.cr-1,be.cq,ed) then
be.br=band(be.br+be.cr,2040)-be.cr
end
end
end
function hu(be,fu)
if fu[1]!=0 then
hr(be,fu[1])
else
ht(be,fu[2])
end
end
function hv(be,hn)
if(be.fu==1) hn=-hn
return be,hn
end
function hw(be)
be.fu=abs(be.fu-1)
end
function hx(be,hn)
hr(hv(be,hn))
if not hm(hv(be,hn)) then
hw(be)
end
end
function hy(be,hn)
hs(hv(be,hn))
if not hq(hv(be,hn)) then
hw(be)
end
end
function hz(be)
if(be.ia) return
ht(be,be.ib)
be.ib=min(be.ib+0.15,7)
if(not hp(be,v(be.ib)) or be.ia) be.ib=0
end
function ic(be)
be.br+=be.ib
be.ib=min(be.ib+0.15,7)
end
function id(be)
if(be.ia) return false
if(be.ib<0 or hp(be,1)) return true
end
function ie(be,ig,ih)
be.hg+=1
be.br=be.ii+ig*sin(be.hg/ih)
end
function ij(be)
be.gb+=1
if be.gb==be.ck.bg then
be.gb=0
be.ik=(be.ik+1)%#be.ck
end
end
function il(be,im)
if(be.co) return
fb(be.cg)
local ea=be.ck[be.ik+1]+be.hc
local ib=not fget(ea,2)
if be.hd%4<2 then
spr(
ea,
be.bq,be.br+im,
be.cq/8,be.cr/8,
be.fu==1 and ib,be.flip)
if e==1 and be.bq+be.cq>128 then
spr(
be.ck[be.ik+1]+be.hc,
be.bq-128,be.br+im,
be.cq/8,be.cr/8,
be.fu==1 and ib,be.flip)
end
end
end
function he(be)
be.he(be)
ij(be)
if(be.hd>0) be.hd-=1
if(be.ct) then
be.ct-=1
if be.ct<=0 then
be.gv=true
if be.io then
ip(be.io,be.bq,be.br)
end
end
end
end
function iq(be,ck)
be.ck=bc[ck]
be.ik=0
be.gb=0
end
function gw(ir,bq,br,fv)
local fr=cn[ir]
local be={
bq=bq,
br=br,
is=0,
ib=0,
hd=0,
fr=fr,
he=fr[2],
fv=fv
}
setmetatable(be,fr)
iq(be,cn[ir].ck)
if(be[3]) be[3](be,fv)
return be
end
function ip(ft,bq,br)
local be=gw(ft,bq,br)
add(ew,be)
return be
end
function it(ft,bq,br,fu)
local be=gw(ft,bq,br)
be.fu=fu
be.iu=it
add(ev,be)
return be
end
function iv(ft,bq,br,fu)
local be=gw(ft,bq,br)
be.fu=fu
be.iu=iv
add(eu,be)
return be
end
function iw(bk)
local ix=btn(0) and not btn(1)
local iy=btn(1) and not btn(0)
local iz=0.5
if(id(bk)) iz=0.25
if ix then
bk.is=max(bk.is-iz,-0.9)
elseif iy then
bk.is=min(bk.is+iz,0.9)
elseif bk.is!=0 then
if not id(bk) then
bk.is=mid(0,bk.is+0.15,bk.is-0.2)
end
end
if hm(bk,v(bk.is)) then
hr(bk,bk.is)
else
bk.is=0
end
if bk.is>0 then
bk.fu=0
elseif bk.is<0 then
bk.fu=1
elseif iy then
bk.fu=0
elseif ix then
bk.fu=1
end
end
function ja(bk)
local bq,br=bk.bq,bk.br
local jb=bk.bq-bk.jc
if jd=="beam"then
sfx(59)
else
sfx(62)
end
if jd!="3way"then
if(jd=="beam") br-=7
if(bk.fu==0) bq+=3
local cq=it(jd,bq,br+3,bk.fu)
cq.ib=rnd(1)-2
cq.is=jb
else
local cq=it("straight_ball",bq,br,bk.fu)
cq.is=2
cq.je=jb
cq=it("straight_ball",bq,br,bk.fu)
cq.jf=1.4
cq.is=1.4
cq.je=jb
cq=it("straight_ball",bq,br,bk.fu)
cq.jf=-1.4
cq.is=1.4
cq.je=jb
end
end
function jg(bk)
if(jh) return
local ji=bk.is==0
local jj=id(bk)
iw(bk)
local jk=eq.ia
if jk then
if bk.bq+7<jk.bq or
bk.bq>jk.bq+jk.cq-1 then
jl()
end
end
if btnp(4) then
if id(bk) then
if jm then
jm=false
bk.ib=-2.2
sfx(63)
end
else
bk.ib=-2.8
sfx(63)
jl()
jn=true
end
end
if btn(5) then
if bk.jo<2 then
bk.jo=bk.jp
bk.hc=16
ja(bk)
bk.jp=min(bk.jp+2,60)
end
elseif bk.jp>15 then
bk.jp-=1
end
if(bk.ib<-0.5 and not btn(4)) bk.ib=-0.5
hz(bk)
if bk.jo>0 then
bk.jo-=1
if(bk.jo==0) bk.hc=0
end
if bk.br>=ei+144 then
ey(bk,false)
end
if id(bk) then
if(not jj) iq(bk,3)
elseif jj then
if(jq) jm=true
if bk.is==0 then
iq(bk,1)
else
iq(bk,2)
end
elseif ji then
if(bk.is!=0) iq(bk,2)
elseif bk.is==0 then
iq(bk,1)
end
bk.jc=bk.bq
bk.jr=bk.br
end
function js(bk)
ic(bk)
bk.hg-=1
if(bk.hg==0) bk.gv=true
end
function jt(bk)
if id(bk) then
hz(bk)
if(not id(bk)) iq(bk,5)
else
if bk.ju>0 then
bk.ju-=1
else
bk.ib=-2
bk.ju=8
iq(bk,7)
end
end
if bk.hg>0 then
bk.hg-=1
if(bk.hg==0) bk.hg=-180
else
if bk.hg==-180 and not bk.jv then
dn(62)
bk.jv=true
end
bk.hg+=1
if bk.hg==0 then
jw=true
di()
end
end
end
function jx(bk)
sfx(60)
jy-=1
if jy<=0 then
ey(bk,true)
else
bk.hd=60
end
end
function ey(bk,jz)
jy=0
iq(bk,4)
bk.hc=0
bk.he=js
bk.hl=true
bk.hg=180
if(jz) bk.ib=-3
jl()
dn(63)
end
function ka(kb)
iq(eq,5)
eq.hc,
eq.he,
eq.ju=
0,
jt,
8
eq.hl=true
music(0xffff,100)
if kb then
eq.hg=30
else
eq.hg=-180
end
end
function kc(jk)
if(eq.ia or eq.ib<0) return
if eq.bq+eq.cq>=jk.bq and
eq.bq<=jk.bq+jk.cq and
eq.br+eq.cr>=jk.br and
eq.br+eq.cr-2-eq.ib<jk.br then
eq.ia=jk
if(jq) jm=true
jk.kd=eq
eq.br=jk.br-8
eq.ib=0
if eq.is==0 then
iq(eq,1)
else
iq(eq,2)
end
end
end
function jl()
if eq.ia then
eq.ia.kd=nil
eq.ia=nil
end
end
function ke(kf,kg,bq,br,is,jf)
local cq=iv(kf,kg.bq,kg.br+br,kg.fu)
if kg.fu==0 then
cq.bq+=bq
else
cq.bq+=kg.cq-bq-cq.cq
end
return cq
end
function kh(be)
be.hd=30
ki(be)
end
function kj(be,cq)
be.he=kk
be.ib=-1.3
be.hd=30
be.kl=eb(cq.fu==0,1,0xffff)
end
function kk(be)
hr(be,be.kl)
hz(be)
if not id(be) then
be.he=be.fr[2]
ki(be)
end
end
function ki(be)
be.cp-=1
if be.cp<=0 then
ip("death",be.bq,be.br)
sfx(53)
be.gv=true
end
end
function km(be)
if eq.bq>be.bq+4 then
be.fu=0
else
be.fu=1
end
end
function kn(be)
if be.hg>0 then
be.hg-=1
if(be.hg==0) iq(be,24) be.ib=-1.5
elseif id(be) then
hr(hv(be,1))
else
hs(hv(be,0.5))
if not hm(hv(be,1)) then
hw(be)
elseif not hq(hv(be,1)) then
if hp(be,0xffff) then
iq(be,22)
be.hg=30
else
hw(be)
end
end
end
local ko=id(be)
hz(be)
if(ko and not id(be)) iq(be,23)
end
function kp(be)
hz(be)
if id(be) then
hx(be,0.5)
else
hy(be,0.5)
end
end
function kq(be)
be.br+=6
be.hg=90
end
function kr(be)
local ga=(be.hg+1)%240
be.hg=ga
if ga==166 then
km(be)
be.hl=false
elseif ga>166 and
ga<180 and
ga%2==0 then
be.br-=1;
be.cr+=1;
elseif ga==210 then
ke("bouncy_ball",be,5,0)
elseif ga>210 and
ga<224 and
ga%2==0 then
be.br+=1;
be.cr-=1;
elseif ga==224 then
be.hl=true
end
end
function ks(be)
if be.hg>0 then
be.hg-=1
if be.hh==2 and be.kt then
be.kt.br-=0.25
end
elseif not be.kt or be.kt.gv then
be.kt=gw("fish",be.bq,be.br+8)
add(et,be.kt)
be.hh=1
elseif be.hh==1 then
if abs(eq.bq-be.bq)<=32 then
be.hh=2
be.hg=32
end
else
be.kt.ib=-5
be.kt.he=ic
be.hg=100
end
end
function ku(be)
hz(be)
hx(be,0.6)
end
function kv(be)
if be.hg<60 then
be.hg+=1
else
local iy=gw("roller",be.bq,be.br)
add(et,iy)
iy.fu=be.fu
be.hg-=120
end
end
function kw(be)
be.hg+=1
if be.hg>=120 then
local t=ke("bomb",be,5,0)
t.is+=rnd()-0.5
t.ib,be.hg=
0xfffe,
rnd(20)
end
end
function kx(be)
hz(be)
if id(be) then
hx(be,1.6)
else
hy(be,1.6)
if(jn) be.ib=-2
end
end
function ky(be)
if ho(be,be.kz.h) then
be.kz=be.kz.h
end
hu(be,be.kz)
end
function la(be)
be.ii=be.br
end
function lb(be)
km(be)
ie(be,20,180)
end
function lc(be)
kh(be)
be.he=ld
be.hf=kh
be.hg=0
iq(be,36)
end
function ld(be)
if be.hg<30 then
hr(hv(be,0xffff.8))
be.hg+=1
else
hr(hv(be,1.5))
if be.br<eq.br then
ht(be,0.4)
elseif be.br>eq.br then
ht(be,0xffff.9999)
end
end
end
function le(be)
be.bq+=be.is
ie(be,24,120)
end
function lf(be)
be.bq=eq.bq
be.br=eq.br
if be.hg<140 then
be.hg+=1
else
local ib
if eq.bq>ek*8-40 or
eq.bq>40 and rnd()<0.5 then
ib=gw("flier3",eh-8,eq.br+rnd(48)-24)
ib.is,ib.fu=
0.8,
0
else
ib=gw("flier3",eh+128,eq.br+rnd(48)-24)
ib.is,ib.fu=
0xffff.333,
1
end
ib.ii=ib.br
add(et,ib)
be.hg=0
end
end
function lg(be)
if be.hh==0 then
if abs(eq.bq-be.bq)<40 then
be.hh=1
end
elseif be.hh==1 then
if eq.br>=be.br then
be.hh=2
end
elseif be.hh==2 then
hz(be)
if be.br>eq.br-16 then
be.hh=3
iq(be,35)
if be.bq<eq.bq then
be.fu=0
else
be.fu=1
end
end
else
hr(hv(be,0.6))
if be.br<eq.br-1 then
ht(be,0.4)
elseif be.br>eq.br+1 then
ht(be,0xffff.a)
end
end
end
function lh(be)
be.br-=4
end
function li(be)
be.he,be.hf,be.cr=
hz,
ef,
8
be.br+=4
iq(be,38)
sfx(55)
for n=1,4 do
local ea=gw("shard",be.bq,be.br)
add(ew,ea)
end
end
function lj(be)
be.is,be.ib=
rnd(1)-0.5,
0xfffe-rnd(1)
end
function lk(be)
ic(be)
be.bq+=be.is
end
function ll(be)
km(be)
if id(be) then
hz(be)
hr(hv(be,be.is))
else
if abs(eq.bq-be.bq)<32 then
be.is,be.ib=
0xffff,
0xfffe.8
elseif abs(eq.bq-be.bq)>60 then
be.is,be.ib=
1,
0xfffe.8
end
end
if be.hg<90 then
be.hg+=1
if be.hg>60 then
if be.hg%4<2 then
be.cg=bm[13]
else
be.cg=bm[12]
end
end
else
iv("beam",be.bq,be.br-4,be.fu)
sfx(59)
be.hg=0
end
end
function lm(be,cq)
be.hg,be.cg=
min(be.hg,60),
bm[12]
kj(be,cq)
end
function ln(be)
local cq=gw("boss_watcher")
cq.lo=be
add(ew,cq)
end
function lp(be)
local t=ke("ball",be,6,0)
t.ib-=2
t.is-=0.5
t=ke("ball",be,6,0)
t.ib-=2
t.is+=0.5
end
function lq(be)
local t=ke("bomb",be,6,0)
t.ib-=2
end
function lr(be)
if id(be) then
hz(be)
hr(be,be.is)
if not id(be) then
be.is=0
iq(be,45)
end
else
km(be)
be.hg+=1
if be.hg==60 then
iq(be,47)
be.lt(be)
elseif be.hg==85 then
iq(be,45)
elseif be.hg==120 then
be.hg=0
be.ib,be.is=
rnd(2)-4.5,
0.35+rnd(0.5)
iq(be,46)
if(be.fu==1) be.is*=0xffff
end
end
end
function lu(be)
if(eq.gv or id(eq)) return
if be.lo.gv then
ka(true)
be.gv=true
end
end
function lv(be)
sfx(61)
local lw=be.iu("explosion",be.bq,be.br,be.fu)
lw.ej,lw.el,lw.count,be.gv=
be.bq,
be.br,
10,
true
end
function lx(be)
ip("wpn_death",be.bq,be.br)
be.gv=true
end
function ly(lz,bq,br)
bq,br=dk(bq),dk(br)
local fz=fd(bq,br)
if fz then
local ib=band(lz,fget(fz.ga))
if ib!=0 then
if fz.ma then
fe[bq][br]=fz.ma
else
fz.ga=a
end
ip("death",bq*8,br*8)
return true
end
end
end
function mb(be,is)
if not hm(be,sgn(is)) then
local jb=0xffff
if(is>0) jb=6
if ly(128,be.bq+jb,be.br) or
ly(128,be.bq+jb,be.br+4) then
be.gv=true
end
return true
end
end
function mc(be,jf)
if not hp(be,v(jf)) then
local md=0xffff
if(jf>0) md=6
if ly(128,be.bq,be.br+md) or
ly(128,be.bq+4,be.br+md) then
be.gv=true
end
return true
end
end
function me(be)
local is=1+be.is
if(be.fu==1) is-=2
hr(be,is)
local ib=be.ib
hz(be)
if mb(be,is) then
if be.mf then
hw(be)
be.is=-be.is
else
be.gv=true
end
end
if not be.gv and
mc(be,ib) and
ib>0 then
if be.mf then
be.ib=-ib*0.8
else
be.gv=true
end
end
if be.gv then
if be.mg then
sfx(61)
local lw=be.iu("explosion",be.bq,be.br,be.fu)
lw.ej,lw.el,lw.count=
be.bq,
be.br,
10
else
lx(be)
end
end
end
function mh(be)
local is=be.is
if(be.fu==1) is=-is
is+=be.je
hr(be,is)
if(mb(be,is)) be.gv=true
if be.jf and not be.gv then
ht(be,be.jf)
if(mc(be,be.jf)) be.gv=true
end
if be.gv then
ip("wpn_death",be.bq,be.br)
end
end
function mi(be)
if be.fu==0 then
be.bq+=3
else
be.bq-=3
end
end
function mj(be)
ly(192,be.bq+3,be.br+3)
if be.count>0 and be.ct==15 then
local mk=be.iu("explosion",be.ej+rnd(16)-8,be.el+rnd(16)-8)
mk.fu,mk.ej,mk.el,mk.count=
be.fu,
be.ej,
be.el,
be.count-1
end
end
function ml(n)
if n.kf then
sfx(54)
jd=n.kf
mm=n.ck[1]
mn=1799
elseif n.type=="boots"then
sfx(54)
jq=true
eq.cg=bm[12]
jm=true
elseif n.type=="heart"then
sfx(57)
if(jy<3) jy+=1
elseif n.type=="heart2"then
sfx(58)
jy=5
else
sfx(56)
if(mo<9) mo+=1
end
n.gv=true
del(mp,n)
end
function mq()
mm=nil
jd="ball"
end
function mr(be)
if abs(be.bq-eq.bq)<4 and
abs(be.br+8-eq.br)<2 and
btnp(2) and
not jh then
jh,eq.hl=
be.fv,
true
di()
end
end
function ms(be,hn)
be.bq+=hn
if(be.kd) hr(be.kd,hn)
end
function mt(be,hn)
be.br+=hn
if(be.kd) ht(be.kd,hn)
end
function mu(be)
be.hg=(be.hg+1)%240
if be.fv==0 then
if be.hg<120 then
mt(be,-0.6)
else
mt(be,0.6)
end
elseif be.fv==1 then
if be.hg<120 then
mt(be,0.6)
else
mt(be,-0.6)
end
elseif be.fv==2 then
if be.hg<120 then
ms(be,0.6)
else
ms(be,-0.6)
end
end
end
function mv(be)
if not be.mw or be.mw.gv then
be.hg-=1
if be.hg<=0 then
local jk=gw("fallplat",be.bq,be.br)
be.mw,be.hg=
jk,
60
add(ew,jk)
end
end
end
function mx(be)
if be.hh==0 then
if(be.kd) be.hh=1
elseif be.hh==1 then
be.hg+=1
if(be.hg==16) be.hh=2
else
local my=be.br
ic(be)
my=be.br-my
if(be.kd) ht(be.kd,my)
end
end
function mz(be)
be.ii,be.na=
be.br,
""..nb..
"-"..be.bq.."-"..be.br
for n in all(nc) do
if n==be.na then
be.gv=true
return
end
end
end
function nd(be)
ie(be,3,90)
end
function ne(be,cq)
add(nc,be.na)
be.gv=true
cq.hf(cq)
ip("death",be.bq,be.br)
local n=gw("item"..be.fv,be.bq,be.br)
add(mp,n)
end
function nf(be)
if(jh or be.ng) return
if eq.bq>=be.bq+2 and
abs(eq.br-be.br)<16 then
ka(false)
be.gv=true
end
end
bi="c7el%;rw.&}d02as&#!hz{+5)p(baaaaaaaaaa|:g7`j%;rw/&}d02"
bm="|gegf@`!~xuwv}[%}aaaa+t-ieeuxxhh@`exw!uoee`~f`!!~~g`~gemqq4334r344t2x?abv~~vf~v{n*4.de[ff{ve{v}[]{piii^n^*#&%($*^6qyy3s1w5rux4t2t)-#|`[&,9#9:!](58r_j$z;f~v{n*4.c0kts+=lk^%11':d:tktk0ss:'09::hc==991t2t2010::hc==kl^s^s^k^k':hc==kkctdtdlcl::hccssc99ss9cs9ccg7i#d[drqc#e87uq2qw2222y222222222qvzzzzszzzzzzzzzqwwttx1x1xtxtx?qqww4431313434x?7-||`[&,:=%:!](588_j$z;n~v{n*4.brr_j$z;f~v{n*:ds99ts^=lk^%2k{d"
cd="e/pee=?qqn?dbl,he3=6qim?b8m3pek=.q#n}d8j,lewsae|1r-7)ebh~secul8ar^eaf.]mym`ri_&e0d^sm5&l_e-$ete}saj,1_[`#ftt=wm4$1_[~(f+q!smtzlry9&ma,;=ah,ld3j#a"
bc="[0p998a9i8i/i0p6|+a/a9p0|dol7aky&7c%#8)c|dm/q7p`|df/q0pm|dl/-8p,|'k/uib;uqjf|tf/[^cj`sg$`q!$!8p?`=jxb0b!y8no|9h/e_oh|'7zg1`_!y&r|^#ik$&kk2`8gz&jg2`eutd*[7p4|2o/99)||lg/%9)+|lb/s8)m"
cn={
{"$f9bg",mr},
{"za`b",nd,mz,hf=ne},
{"v_b=",mu,nh=true},
{"{jea",kn,hf=kj},
{"{~kea",kp,hf=kj},
{"*jea",kx,hf=kj},
{"4iea",kw},
{"njuea",kr,kq,hf=ki,hl=true},
{"ca",ks},
{".jes",ky,kz=j},
{"daa",kv},
{"d{k`a",lb,la,hf=kh},
{"dj9a",lb,la,hf=lc},
{"0i`a",lg,hf=kj},
{"ceb",lf},
{"tjuda",kp,lh,hf=li},
{"liga",ll,hf=lm,is=0},
{"ca",mv},
{"2qd=",},
{"2$)$b",lr,ln,hf=kh,lt=lp},
{"2z$$b",lr,ln,hf=kh,lt=lp},
{"2;&$b",lr,ln,hf=kh,lt=lq},
{"bj3ya",},
{"cma",nf},
shard={"+ba",lk,lj},
bomb={"_uv1ka",me,hf=lv,mg=true},
item2={";ba",hz,kf="bomb"},
item0={"zba",hz,kf="bouncy_ball"},
roller={".ica",ku,hf=kh},
ball={"_q1ka",me,hf=lx},
item3={"faa",hz,kf="beam"},
item1={";aa",hz,kf="3way"},
death={"jbcd"},
wpn_death={"$q1%-a"},
beam={"j78;b",mi,hf=lx},
player={"b~ga",jg,hf=jx,jo=2,jp=15,jc=0},
explosion={"*a9c",mj},
item7={"vaa",hz,type="1-up"},
fish={"4jea",hf=kh},
item5={"~aa",hz,type="heart"},
boss_watcher={"ca",lu},
item4={"fba",hz,type="boots"},
flier3={"d{o`a",le,hf=kh},
item6={"~ba",hz,type="heart2"},
bouncy_ball={"_uw1%1b",me,mf=true,hf=lx,io="wpn_death"},
straight_ball={"_ur1ka",mh,hf=lx,io="wpn_death"},
fallplat={"^_ba",mx,nh=true},
}
db={
"`daia[ku1y69xk7|$ey/ia86gga9_k8|cxis)m0g]@#jtn#7j9xua|jfa`+meu:8#76qc|$ba5za7pggin[eo%i94k9#8ni/ya7`lt#j?d50j!)qs8g8i77c~q/+a79rs$$*i51y7)cq|@ey]^ycy1lmh&ug|d@at~m;,#0we4nm+xnd7q2$z,raa6fa-6bb`5re.&p_6j_7av8k,7tk6ma-2da7q2(em!iex7erdn8cwu7e`h",
"u-4qascczaisgdc~zaqzocu]j[`bgfz`bsgnhf`~a0eo|=aq#&0ill&9=a89m*kidos=]s&#1~=s%mqkk+&a=o9%&/ckdc1!9j%q$!~jtzb=a07miikd!8=wr`&^i2%aj|!-6$mfmk+~a=o97&till@8=9b#m4ekd%q=a798yhe99j=g",
"`daiauhy1u69}bs|$~3cvo#yg`i9+5w$)r1rzm*(q5#z7yilm4yccve+[r|p--elc4e?+6oa7r6e$&~7m@zi=ye=,hsap|aao*yi=lka,!cat,c+ffjmx0m4=9ib7$l~+rl_&msenlpth![,fde?ia=6ii`kto.u,=~e9mmqm^&m_dka,t=ahf`q_~j[=/f)na-hda,+ya73vjejx!ql8/ugao?-7-xkq3e5-a",
"`daiaukm1y69xk7|*ae/ib!?1a#)ba-;)ca:^f75gd#$cj52i7g1a;8caq#*4i1#i~6s7;)aek#mdreiqobce$5ar,hqe;bq+zq`=s9jdjeia0gq1y69@ga|~ba/zi-ejtolz!mes7a`ca$)gq:za761a|)caq#8cv1zx9}cs|d~3#qabce#3ab,bqaza`q7a&3ca$9a51i76ga|)bajg^q=1`qbe`ec#8.j1#59o,!|$eb5lb76e7|pgyqiaebua$q|e/_a7?ma|f!y5qb`qtdo",
"u-4qa1m5z-qw]&e`b!izfqu/bu`daz;eawodb~haq;jeu!og`jqr;xrw]ag~b7j$lm9;vi0*a=7s`mqaj6n$={%7,`gkdfs=487[lfszif=a8%magk6l==?c&m$oi'nd=z`7,0itn8&=a09mqiida8=p09,~ek@ks=_c`&5kk^g7=`$#3{mix!0=w#a8[ec",
"`daia`ly1#fb$!fya0fc~muas$o0]s{|*aa/rb!)yq;)aa/ia7u$0q#9q`$i`[l0r&9q:jf06cb#|9qe2jaie#ja$sciz9e1_{7pis|n7m/+a7-qdn",
"`oaqaobi%m7qda[brlqbu{!b{kjtfa=*=imki&j]942a4nvy-fa=z9_ev;f-$o=v1avnaq@|qd9dau#_ldoe_722#lf0jz59liy#bism8+&w4`i3m8s4q3a~mo)z{$zu4`qa!3l~r68u1e4nwyqfe[vnub$|oi2w!gim^sw9((1`w~`_1~s3s_m8&eg",
"`daiaule1yd9xcs|^8b5-ide11mgks!|$ga5$b7`l9#0~i/yi7g_t$$!e:ji@@kc|hha/+bq#tt=;r7!ka|nmaey`makmd=ay0ej7[%a|vmawcd77ra-[t-o.am_6oa_31tyju!a3d*u8slqaic1i=_#8i87ic0csya9em7i~7aszi7mka,7d7j8!m3=|bkf_[z87!=7mbhv[9$ftt/9i!pas~8#-sch",
"u-*aaspe4,5uh'g[r9c4q+x:ua{j,i.pfqx#?bwp87{'_a4b58(vs{'sa.gnq)bc[~oa4$u-ow%n8]1k4oeqhtc[4@b.[iq)fe{0ta.kmqx7hrkcu.xqay4-vqxmb[)sa:ocwx7~[~va.@d-(7;&0^oy.`uq?rc[byt:9cvhbb[0{b.a5hjk`[8ha;`9/3q4{=ci49/d8rqauh^ifs.f]rea",
"`daia[3m1q'@]_?;j9i5bi86i7|pae-qc+q5ab!@aq|2aa/fa7?w7b8]aj#4q55|a9}5b`j!!z=$ru5:1^@fw8;`sig=z9/u_$6;2s*m~lk~ypxi!qj8@ea|fbakaj0oi.;vwa5ea!@5q|d`a/dba3:ue8(x0|!tu!#f96ha|?ba5ab-j[9/:$l@+_fr&&tedler@3o&jqe4`js6*;[irj|ue7m)c[2/g6ya_lci,gdk?2a_)m#7^q7q9*cikq#=a-|za&fcqy8b5oy7)da|}aa/}acu1q~@hea|jba5ta7hdg#;*y1oi@/*i;z@a11n98rr|rfac4j9",
"`daaaaku1y69$k8af@a51q7}gam=`e54`q@6uq_j7pk7|^ey/$a9}k7i=`a",
"`oaaafjknqzq'gg4bgr}|yufmuu99yh_-[ba`ueafx#rby}zruz5eu8trw!ox4iuucfr*-ztvge47+r@7q=nagb",
}
dc={
}
bo="&beeyccmqb[w7bgiuccysabeycfu3br1-adi#cfu#ahmrb0h-7aey9ei38qxq8ceq9giy9bmi8fi50di#8fw78hiw9thyqai78hiqreyuscezqgyytbyzqfi`sdq7rdqirvhyrv2[qhiitdho_am#+eui-cyy=gy#_biy=fyn_de7+hi&-d1zjamtkeyyiae7jcwukgi7jci|jbmekfi#ldu#a"
bt={
"acaa",
"7zga",
"-kbd",
"i0ic",
"yb^a",
"|zsd",
"`l9a",
"uhfa",
"msdb",
}
function oc()
eq,jy,jd,
mm,jq,jm,
nc=
gw("player"),
3,
"ball",
nil,
false,
false,
{}
od(b)
end
function oe(of)
c,b,jw=
of,
bt[of].bu,
false
for n=1,4 do
d[n]=bt[of].bv[n]
end
end
function od(bd)
et,ev,eu,
ew,mp,bp=
{},{},{},{},{},
bo[bd]
if(bp.b) b=bd
nb,eq.bq,
eq.br,eq.is,eq.ib=
bp.map,bp.bq*8,
bp.br*8,0,0
iq(eq,1)
ff(nb)
dn(fm)
ep()
for bq=en-4,en+19 do
gy(bq)
end
end
function og(br,oh)
for n=1,4 do
if oh or n!=oi+1 or oj%4<2 then
spr(64+d[n],35+10*n,br)
end
end
end
function ok()
if btnp(2) or btnp(3) then
ol=abs(ol-8)
end
return btnp(4)
end
function _init()
l()
bh()
bb()
bn()
bs()
bw()
cl()
da()
dd()
for cm,om in pairs(cn) do
om.__index=om
setmetatable(om,{__index=hb})
end
on()
gb=0
end
function on()
_update60,_draw,ol,mo=
oo,
op,
0,
3
pal()
end
function oo()
if ok() then
if ol==0 then
oe(1)
oq()
else
os()
end
end
end
function op()
cls()
spr(212,32,36,8,3)
print("the balldragon",36,60,7)
print("start",48,88)
print("password",48,96)
spr(2,40,86+ol)
end
function os()
_update60,_draw,oi,oj=
ot,
ou,
0,
0
end
function ot()
local jb,md=0,0
if(btnp(0)) oi+=3
if(btnp(1)) oi+=1
oi%=4
if(btnp(2)) d[oi+1]+=1
if(btnp(3)) d[oi+1]+=4
d[oi+1]%=5
if btnp(4) then
for n=1,#bt do
if ov(n) then
oe(n)
oq()
return
end
end
elseif btnp(5) then
on()
end
oj+=1
end
function ou()
cls()
og(60)
end
function ov(ow)
for n=1,4 do
if d[n]!=bt[ow].bv[n] then
return false
end
end
return true
end
function oq()
pal()
ox,_update60,_draw=
0,
oy,
oz
end
function oy()
ox+=1
if ox==180 then
pa()
end
end
function oz()
cls()
camera()
print("level "..
dk(c+2,3)..
"-"..(c-1)%3+1,
46,40,7)
spr(51,52,68)
print("x "..mo,64,70)
if(c>1) og(96,true)
end
function pb()
_update60,_draw,ol=
pc,
pd,
0
end
function pc()
if ok() then
mo=3
if ol==0 then
oe(c)
oq()
else
on()
end
end
end
function pd()
cls()
print("game over",46,48,7)
og(68,true)
print("continue",48,92)
print("quit",48,100)
spr(2,40,90+ol)
end
function pa()
_update60,_draw=
pe,
pf
oc()
end
function pe()
gb+=33
gb%=32
he(eq)
if eq.gv then
mo-=1
if mo>0 then
oq()
else
pb()
end
return
end
if jw and not de then
if c<9 then
oe(c+1)
oq()
else
pg()
end
return
end
if mm then
mn-=1
if(mn==0) mq()
end
for n in all(mp) do
he(n)
if hi(n,eq) then
ml(n)
end
end
for cq in all(ev) do
he(cq)
for lw in all(et) do
if lw.hd==0 and hi(cq,lw) then
lw.hf(lw,cq)
cq.hf(cq,lw)
end
end
for fz in all(ew) do
if hi(cq,fz) then
fz.hf(fz,cq)
end
end
end
for cq in all(eu) do
he(cq)
if eq.hd==0 and hi(cq,eq) then
eq.hf(eq)
end
end
for lw in all(et) do
he(lw)
if eq.hd==0 and lw.hd==0 and hi(eq,lw) then
eq.hf(eq)
end
end
for fz in all(ew) do
if fz.nh then
kc(fz)
end
he(fz)
end
local ph,pi=en,eo
if jy>0 then
es()
end
if jh and not de then
od(jh)
jh,eq.hl=
nil,
false
df()
end
jn=false
gz(ev)
gz(eu)
gz(et)
gz(ew)
if en>ph then
gy(en+19)
elseif en<ph then
gy(en-4)
end
if eo>pi then
gx(eo+19)
elseif eo<pi then
gx(eo-4)
end
end
function pf()
camera()
rectfill(0,0,127,127,fj)
palt()
dl()
camera(eh,ei)
fy()
ez(fi)
local pj={
ew,
ev,
eu,
et,
mp
}
for n=1,#pj do
for be in all(pj[n]) do
il(be,eb(n>=4,1,0))
end
end
il(eq,1)
camera()
pal()
for n=1,max(jy,3) do
local ga=52
if(n>jy) ga=53
if(n>=4) ga=54
spr(ga,(n-1)*8,1)
end
if mm then
spr(mm,40,1)
rectfill(48,2,77,7,0)
rectfill(49,3,49+(mn/1800)*28,6,8)
end
if de then
dj()
end
end
function pg()
_update60,_draw=
pk,
pl
end
function pk()
if btnp(4) then
on()
end
end
function pl()
cls()
pal()
print("with the defeat of",
28,32,7)
print("the evil balldragons,",
22,40,7)
print("peace returns to the land.",
12,48,7)
print("the end",50,76,7)
end