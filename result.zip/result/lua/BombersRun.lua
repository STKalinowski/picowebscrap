-- bombers run pico edition
-- @melvinsa and @gruber_music
-- code/design: melvin samuel
-- sound/music: chris donnelly

--  some helper variables
-- -----------------------------

init_lvl=0                   -- start level, use to cheat
last_lvl=20
bnsscr={50,100,150,200,200,200,200,200} -- score bonuses
time_limit=60*12                        -- game time limit
time_start=0
level_start=0
nobombbon=true
nodeathbon=true
game_time=time_limit                 -- game time limit
last_time=game_time
enddelay=60*1.5
trondeath=20
tckr=0                               -- total ticks
go=0                                 -- game start variable
ttt=0 
ftt=0
stm_h=2
ttl=0
ttl_dth=0
ttl_bm=0
ttl_mn=0
ver=1.07

-- sfx
m_lvlend=0   -- level end
s_bbounce=2 -- bomb bounce 
s_bthrow=3  -- bomb throw 
s_jump=4    -- jump 
s_nostun=5  -- hit without stun 
s_stun=6    -- hit stun 
s_grab=7    -- grab 
s_throw=8   -- throw 
s_bounce=9  -- bounce 
s_tick=10    -- bonus spawn / clock tick 
s_die=11     -- death 
s_exp=12     -- explo / mon fireball 
s_bns=13     -- bonus 
s_dmg=14     -- red bat stmp damage 
s_hammer=15   -- hammer fall ( hammer bro enemy ) 
s_fball=16   -- fireball shot ( red bat ) 
s_monexp=17  -- monster hits sound after bomb 
s_pickup=18  -- bomb pickup sound 
s_bsshit=19  -- boss hit 
s_bssexp=20  -- boss explode 
s_start=21   -- game start 
s_shake=22   -- stomp monster quake 
s_fall=23    -- stomp fall sound 

-- music
m_set1=1  -- 0,1,2
m_set2=7  -- 3,4,5
m_set3=15 -- 6,7,8
m_set4=19 -- 9,10,11
m_set5=25 -- 12,13,14
m_set6=31 -- 15,16,17
m_set7=37 -- 18,19
m_set8=43 -- 20


--  init function 

function _init()
 logs={}
 ents={}
 t=0
  init_menu()
end

--  draw function 

function _draw()
 cls()
 
 -- draw current main draw
 if mdraw then mdraw() end
 
 -- fade
  draw_fade()
 
 -- draw log
  draw_log()
end

-- generic update function
function _update()
 
 t+=1
 upd_flash()

 if loop then
  loop() 
 end
 
 if nsfx then
  sfx(nsfx)
  nsfx=nil
 end

end


-- init main menu 
function init_menu()
 
 reload()            
 camera()
 x=0
 t=0
 go=0

 music(-1)
 mdraw=draw_menu
end

-- begin helper functions
--  update bg flasher

function upd_flash()
  ftt-=1
  if ftt<=0 then
   ftt=0
   flash_bg=nil
  end
end

--  initialize fade functions

function fadeto(nxt,rev)
 fade_rev=rev
 fade_nxt=nxt
 fade_n=0
end

--  log function

function log(str)
 add(logs,str)
 while #logs>20 do
  del(logs,logs[1])
 end
end

--  log draw function

function draw_log()
 
 --log 
 cursor(0,0)
 color(7) 
 for l in all(logs) do
  print(l)
 end 
 
end
--]]

--  fade draw function

function draw_fade() 

 if fade_n then

  fade_n+=1
  n=fade_rev and fade_n or 15-fade_n
  
  for i=0,15 do
   -- uses lut starting at (8,4) to (8,8)
   pal(i,sget(8+i,4+flr(n/4)),1) 
  end

  if fade_n==15 then
   fade_nxt()
   fade_n=nil
   if fade_rev then
    fadeto(pal,false)
   end
  end 

 end  

end

-- make entity

function mkentity(fr,x,y)
 fr=fr or -1
 x=x or 0
 y=y or 0
 
 e={
  fr=fr,x=x,y=y,t=0,size=8,
  frict=1.0,
  flp=1, lp=true, vis=true,
  raymod=0,ofy=0,dp=1,
  bncx=function(e) e.vx=0 end,
  bncy=function(e) e.vy=0 end,
  van=kill,
  tdust=0,
  xpsmk=false
 }
 still(e)
 add(ents,e)
 return e
end

--  null function / no function

nf=function() end

--  get/set map x,y sprite 

function lget(x,y)
 return mget((lvl%8)*16+x,flr(lvl/8)*16+y)
end

function lset(x,y,n)
 return mset((lvl%8)*16+x,flr(lvl/8)*16+y,n)
end

--  set something ablaze .. fx

function burn(e)
 p=mka(e.x+rand(3)-1,e.y+rand(3)-1,16,12,4,4,4,2)
 p.rmp=e.rmp
end

function smoke(e)
 p=mka(e.x+rand(3)-1,e.y+rand(3)-1,48,0,4,4,4,2)
 p.rmp=e.rmp
end

-- value updates ever md ticks

function mod(md,lp)
 return flr(t/md)%lp
end

--  add impulse to entity

function impulse(e,an,spd)
 e.vx=cos(an)*spd
 e.vy=sin(an)*spd
end

-- random number helper

function rand(n)
 return flr(rnd(n))
end

-- make a time object with timer 

function delay(t,f,l)
 e=mkentity(-1,0,0)
 e.life=t
 e.ondeath=f
 e.upd=l
end

-- rand pick obj and return it

function takeone(a)
 local p=a[rand(#a)+1]
 del(a,p)
 return p
end

-- helper func. to draw popup 

function popup(h,sc,x,y,adds,tmer)
 tmer=tmer or 25
 adds=adds or false

 if adds and h then
  h.score+=sc
 end
 
 e=mkentity(-1,x,y-4)
 e.vy=-0.25
 e.life=tmer
 e.dp=0
 local s=sc..""
 local sx = hcenter(s)

 e.draw=function(e,x,y)
  for i=0,1 do
   cl=1
   if i==1 then
    cl=t%4<2 and 10 or 9
   end
   print(s,hcenter(s,x)-i,y+2-i,cl)
  end
 end
 
end

function drawstats(show,oft)
  show=show or true
  oft=oft or 0

  fscore=""..heroes[1].score
  lvls=""..lvl
  while #lvls<2 do lvls="0"..lvls end
  while #fscore<5 do fscore="0"..fscore end
  --local oft=-15

  if lvl < 10 then
   print("level:0"..lvl.."/20",2,70+oft,6)
  else
   print("level:"..lvl.."/20",2,70+oft,6)
  end
  print("score:"..fscore,2,78+oft,6)

  print("deaths:"..ttl_dth,2,86+oft,6)
  print("bombs:"..ttl_bm,2,95+oft,6)
  print("lvl avr:"..timeformat(ttl/(lvl+1)),2,103+oft,6)
  if show then
   print("run time:"..timeformat(game_time).." ("..timeformat(time_limit-game_time) ..")",2,111+oft,6)
  end

end

--  menu: gameover function call

function gamecomplete()
 pal()
 t=0
 mdraw=function()
  local ofs = -15
  rectfill(0,0,127,127,0)
  --print("congrats!",48,62+ofs,7,1)
  local str=""
  if game_time >= 90 then 
  str="amazing run, well done!"
  end

  sspr(0,96,16,24, 52, 15)

  print("congrats!!",43,54+ofs,8,1)
  print("----------",43,62+ofs,8,1)

  am=5+sin(t%30/30)
  for i=1,#str do
   print( sub(str,i,i), 14+i*4, 10+sin((t+i)%20/20)*am, 8+i%8)
  end  

  bspd=3
  drawstats(true,ofs)

  
  if btn(5) then
   game_time=time_limit
   init_menu()
  end
 end
 rectfill(0,0,127,127,0)
end

--  menu: gameover function call

function gameover()
 pal()
 t=0
 mdraw=function()
 local ofs = -15
  rectfill(0,0,127,127,0)
  print("time's up!",43,54+ofs,8,1)
  print("----------",43,62+ofs,8,1)
  bspd=3
  drawstats(true,ofs)


  if btn(5) then
   game_time=time_limit
   init_menu()
  end
 end
 rectfill(0,0,127,127,0)
end

-- timer

function timeformat(secs)
 if (secs < 1) then
  return "00:00:00"
 end
 local mins = "00"
 local msec = "00"

 if (secs > 59) then
  mins = flr(secs / 60)
  if (mins < 10) then
   mins = "0"..mins
  end
  secs = secs % 60
  msec = secs % 100
 end
 secs=flr(secs)
 msec=flr(msec*100%100)
 
 if (secs < 10) then
  secs = "0"..secs
 end
 if (msec < 10) then
  msec = "0"..msec
 end

 return mins..":"..secs..":"..msec
end


--  title screen draw

function draw_menu()
 

 -- if start increment go
 if go>0 then go+=1 end
 
 gosq=0

 m = "@melvinsa"
 g = "@gruber_music"

 hcenter(m)
 print(m,hcenter(m),98,1)
 print(g,hcenter(g),106,1)

 sspr(16,96,80,32, 26, 30)
 
 -- blink start
 pr=t%24<16

 -- blink every frame if start
 if go>0 then pr=(t%2<1 and go<39) end
 
 -- draw start game
 if pr then
  tx="x to start"
  print(tx,hcenter(tx),121,7)
 end
 
 -- if button x is press start game
 if btn(5) and go==0 and t>5 and not fade_n then
  sfx(s_start)
  music(-1)
  go=1
 end 
 
 -- after delay go to game
 if go==64 then
  init_game()
 end
end

-- -----------------------------

function hcenter(s,pt)
 pt=pt or 64

return pt-flr((#s*4)/2)

end

--  init for game
-- -----------------------------

function init_game()
 
 fadeto(pal,nil)
 monsters={}
 bombs={}
 heroes={} 
 ents={}
 nodeathbon=true
 nobombbon=true

 game_time=time_limit
 last_time=game_time

 ttl_dth=0
 ttl_bm=0
 ttl_mn=0

 blid=0
 lvb=4
 bnum=0
 pickups=48
 lives=2000

 boss=nil
 boss2=nil

 -- shuffle artefacts
 a={}
 apool={}
 for i=0,21 do
  add(a,mget(i,15))
 end
 while #a>0 do
  add(apool,takeone(a))
 end 

 -- hero
 act=1                
 i=0
 
 h=mkentity(32,0,0)
 del(ents,h)
 h.act=i==0   
 h.score=0
 h.bombs=5
 h.hid=i
 h.powerbombs={}
 for i=0,5 do h["bomb"..i]=1 end
 add(heroes,h)
 
 time_start=time() 

 goto_level(init_lvl)
 init_level()
 mdraw=draw_lvl
 

end

-- -----------------------------
--  init the current level
-- -----------------------------

function init_level()
 clean=false
 lt=0
 
 -- spawn based on active flag
 for h in all(heroes) do
  if h.act then spawn_hero(h) end
 end

 -- items
 items={}
 it=apool[1]
 del(apool,it)
 add(items,rand(128)==0 and 127 or it)
 --
 loop=upd_lvl
end

--  go to level
-- -----------------------------

function goto_level(n)
 lvl=n
 level_start = time()

 if n < 3 then
  music(m_set1)
 elseif n < 6 then
  music(m_set2)
 elseif n < 9 then
  music(m_set3)
 elseif n < 12 then
  music(m_set4)
 elseif n < 15 then
  music(m_set5)
 elseif n < 18 then
  music(m_set6)
 elseif n < 20 then
  music(m_set7)
 else
  music(m_set8)
 end

 bop={}                       -- spawn points
 ggpos={}                     -- grownd

 -- loop through level 
 for x=0,14 do for y=0,13 do

  -- get the frame at x,y
  fr=lget(x,y)
  gfr=lget(x,(y+1)%14)
  px=x*8+4
  py=y*8+4

  -- get ground positions
  if not fget(fr,0) and not fget(fr,1)
     and (fget(gfr,0) or fget(gfr,1) ) then
   add(ggpos,{x=px,y=py})
  end  
  
  -- spawn players 
  if fr==32 or fr==33 then  
   h=heroes[fr-31]
   h.spx=px
   h.spy=py   
  -- if enemies
  elseif fr>=64 and fr<=100 then
   mkmonster(fr-64,px,py)   
  end  
  
  -- 0,14 is always a blank tile
  if fget(fr,4) then
   lset(x,y,lget(0,14) )
  end
  
  end 
 end

 if lvl==last_lvl then
  boss=mkboss(130,44,120,44)
  boss.flp=-boss.flp
  boss2=mkboss(0,44,8,44)
 end

end

function mkboss(x1,y1,x2,y2)

  local e=mkentity(110,x1,y1)
  e.dp=2
  e.lp=false 
  e.size=16
  e.hp=4
  e.obj=true
  e.stp=0
  e.dead=false
  add(monsters,e)
  e.bad=true
  e.hit=function() end
  e.xpl=function(from)
   if e.flash then return end
   sfx(s_bsshit)
   e.hp-=1
   e.flash=10
   if e.hp==0 then
    e.upd=nil
    e.twc=nil   


    local kl = function()
     e.upd=nil
     e.twc=nil  
     kill_boss(e)
    end

    delay(20,kl)
  
   end
  
  end

  tw(e,x2,y2,64,0,intro_boss)--64
  return e

end

function kill_boss(e)
 --
 if e.dead then return end

 kill(e)
 flash_bg=0
 tt=7
 shk=16
 
 -- pieces
 for i=0,3 do
  dx=i%2
  dy=flr(i/2)
  p=mkentity(110+dx+dy*16,e.x+dx*8-4,e.y+dy*8-4)
  p.vx=dx*2-1
  p.vy=dy*2-1
  p.life=80
  p.flp=e.flp
  p.blink=40
  p.frict=0.92
  p.lp=false
 end
 
 sfx(s_bssexp)
 
end

function intro_boss()
 
 boss.upd=function(bss)
  if bss.t>64+rnd(50) then
   bss.t=0
   bss.cfocus=16
  end

  if bss.cfocus==1 then
   if rnd(10) <= 2 and getnummon() < 4 then
    e2=mkb(flr(rnd(3)),bss) 
    e2.x=bss.x+bss.flp*16
    e2.y=bss.y
    an=sgda(heroes[1],bss)
    impulse(e2,an,1)
   else
    fball(bss)
    if bss.y == 44 then
    tw(bss,bss.x,22,64,0,nil)
    else
     tw(bss,bss.x,44,64,0,nil)
    end

   end
  end
 end

 boss2.upd=boss.upd

end


--  function to spawn a hiro
-- -----------------------------

function spawn_hero(h)
 add(ents,h)
 h.vis=true
 h.fr=32
 h.dead=false
 h.x=h.spx
 h.y=h.spy
 h.we=0.5
 h.frict=0.9
 h.upd=upd_hero
 h.phys=true
 h.lp=true     
 h.special=nil
 h.tdust=0

 lt=0

end

--  make a monster
-- -----------------------------

function mkmonster(mt,x,y)
 
 local e=mkentity(64+mt,x,y) 
 e.raymod=2
 add(monsters,e)
 e.phys=true
 e.obj=true
 e.bad=true
 e.dmg=0
 e.res=3
 e.mt=mt
 e.spd=0.5 
 e.tdust=0
 e.hit=hit
 e.shoot_cd=80
 e.stomp=true

 e.upd=upd_mon
 e.draw=function(e,x,y)
  if e.stun and not e.stunshk then
		 sspr(mod(2,4)*8,8,8,4,x,y-4)
  end
 end 
 
 e.xpl=function(from)
  sfx(s_monexp)
  shk=4
		local b=mkb(e.mt,e)
  xpl(b)
  kill(e)
  ttl_mn+=1
  return b
 end  
 init_mon(e)

 return e
end


--  init monsters
-- -----------------------------

function init_mon(e)

 e.bhv=crawl
 e.wfrmax=2
 e.shoot=shoot
 e.bncx=function(e)
  e.flp=-e.flp
 end  
 
 -- bat
 if e.mt==1 then  
  e.wfrmax=3
  e.bhv=nil
		setfly(e,0.7)
 end 
 
 -- ogre
 if e.mt==2 then
  e.test_shoot=function(h)
   return abs(h.y-e.y)<8 and face(e,h)
  end
 end 
  
 -- hammer bro
 if e.mt==3 then
  e.test_shoot=function(h)
   return dst(h,e)<48 and face(e,h) and not e.rmpo
  end
 end
 
 -- saws
 if e.mt==32 then
  e.turn=1
  e.spd=1
  e.wfrmax=1
  e.stomp=false 
 end 
 
 -- stompster
 if e.mt==36 then
  e.wfrmax=1
  e.spd=0
  e.stomp=false
  e.bhv=waiter
  e.test_shoot=function(h)
   return abs(h.x-e.x)<9 and abs(h.y-e.y)<48 and h.y >= e.y
  end  
  e.shoot=dash
 end 
 
 -- red bat
 if e.mt==5 then 
  e.res=6
		setfly(e,0.5)
 end  
 
  
end


--  count the number of mon left
-- -----------------------------

function getnummon()
 sum=0
 for m in all(monsters) do
  if not m.blk then sum+=1 end
 end
 for h in all(heroes) do if h.lift then sum+=1 end end
 return sum
end


--  set fly for entity bird,vamp
-- -----------------------------

function setfly(e,spd)
 e.spd=spd
 e.bhv=fly
 e.vx=e.flp*e.spd
 e.vy=-e.spd
 e.bncy=nf
end

-- flying behaviour
-- -----------------------------

function fly(e)
	advf(e)

 e.we=0
 e.vx=e.flp*e.spd

 if e.t>64+e.y and e.mt==5 then
  e.t=0
  e.cfocus=16
 end

 if e.cfocus==1 then
  fball(e)
 end
 
end

function fball(el)
  h=hcl(el)
  sfx(s_fball)  
  an=sgda(h,el)           
  smax=e.mad and 1 or 1
  for i=0,smax do
   ba=(i-smax/2)*0.025
   f1=frshot(113,el)  
   impulse(f1,an+ba,1.25)
   f1.raymod=3
   f1.upd=function(f1)
    f1.flh=t%4<2 and 1 or nil
    burn(f1)
    f1.turn=1
   end
   if ba==0 then    
    e.bvx=-f1.vx
    e.bvy=-f1.vy
   end   
  end
end

-- shoot at player
-- -----------------------------

function frshot(fr,e)
 local f=mkentity(fr,e.x,e.y)  
 f.bad=true
 f.shot=true
 f.bncx=function(b)
  kill(b)
 end
 f.lp=false
 return f
end



function haunt(e)
 advf(e)
 h=hcl(e)
 
 local dx=mdx(h.x-e.x,60)
 local dy=mdy(h.y-e.y,56)
 local an=atan2(dx,dy) 
 spd=e.spd*(1+cos(t/40)*0.5)
 impulse(e,an,spd)
 e.spd+=0.001
 e.shot=true
 e.flp = sgn(mdx(h.x-e.x,64))
 if getnummon()==1 or lt<time_limit then 
  vanish(e)
 end
 
end

-- face direction of player
-- -----------------------------

function face(e,h)
 return e.flp==sgn(h.x-e.x) or e.mad 
end

-- adcance frame
-- -----------------------------
function advf(e)
 e.fr=64+e.mt+mod(4,e.wfrmax)*16
end

-- update monster
-- -----------------------------

function upd_mon(e)

  -- heal
 if e.dmg>=e.res then
  e.stuncd-=1
  if e.stuncd <= 0 then
   if e.stun then
    e.vy-=2
    init_mon(e)
    gomad(e) 
   end
   e.dmg=0
  end 
 end
 
 -- stun
 e.stun=e.dmg>=e.res
 if e.stun then
  e.we=0.25
  e.stunshk = e.stuncd<20 and t%2==0
  return
 end

 -- bhv
 if e.bhv then 
  e.bhv(e)
 end
 
 -- saw
 if e.mt==32 then
  e.turn=e.flp
 end


 if e.ground and abs(e.vx) >0.05 and e.tdust + 10 < e.t then
  e.tdust = e.t
  dust(0,e)
 end
 
end


-- make mosnter angry
-- -----------------------------

function gomad(e)

 if e.mad or e.mt==36 or e.mt==32 then return end
 e.mad=true
 e.rmp=1  
end

function hmod(n,md)
 n+=md
 n=n%(md*2)
 n-=md
 return n
end

-- monster crawl behaviour
-- -----------------------------
function waiter(e)

  h=heroes[1]
  hdy=hmod(h.y-e.y,60)

  -- try shoot
  scd=e.bad and e.shoot_cd or 8
  if e.t>scd and e.test_shoot and rand(4)==0 then
   h=hcl(e)
   if e.test_shoot(h) then
    e.t=0
    e.shoot(e,h)
   end
  end

  advf(e)
end

-- monster crawl behaviour
-- -----------------------------
function crawl(e) 

 h=heroes[1]
 hdy=hmod(h.y-e.y,60)
 
 if e.ground then
  if e.fall then
   e.vy=0
   e.fall=false
   if e.mt==32 then
    h=hcl(e)
    if h then
     e.flp=sgn(h.x-e.x)
    end
    if not e.mad then
     e.flp=rand(2)*2-1
    end
   end   
  end
  

  fall=e.mt==32 or (e.mad and hdy>2) 

  --uturn= (not seek or hdy<2) and e.mt!=4
  
  if col(e,e.flp*8,1)==0 and not fall then
   e.flp=-e.flp
  end
  e.vx = e.flp*e.spd
  advf(e)

  -- try jump
  if seek and hdy<-2 and rand(2)==0 then
   px=flr(e.x/8)
   py=flr(e.y/8) 
   ok=false
   for i=1,2 do
    fr=lget(px,(py-i)%15)
    if fget(fr,1) then
     ok=true
    end
   end
   if ok then
    e.bhv=mon_jmp
    e.t=0
    e.vx=0
    e.fr=64+e.mt
   end  
  end 
  
  -- try shoot
  scd=e.bad and e.shoot_cd or 8
  if e.t>scd and e.test_shoot and rand(4)==0 then
   h=hcl(e)
   if e.test_shoot(h) then
    e.t=0
    e.shoot(e,h)
   end
  end
  
  else
   -- fall
   e.vx=0
   e.vy=2
   e.fall=true
  end 
end

-- shoot behaviour
-- -----------------------------

function shoot(e,h)
 e.trg=h
 e.flp=sgn(h.x-e.x)
 e.bhv=mon_fire 
 e.vx=0  
 e.fr=96+e.mt
end

-- dash behaviour
-- -----------------------------

function dash(e,h,rt)
 rt=rt or false
 
 if not rt then
  sfx(s_fall)
 end 

 e.phys=true
 local an=flr(sgda(h,e,true)*4+0.5)/4
 still(e) 
 e.cgh=36
 local f=function(sh)
  delay(24,function() 
   

   init_mon(e)
   if not rt then
     dash(e,h,true)
   end
   
   end
   )
  shk=8
  sfx(s_shake)
  e.bhv=nil
  e.fr=116
  still(e)
  e.bncy=nf
 end 

 local acc=0.2
 local spd=0
 e.bhv=function()
  spd+=acc

  if not rt then
   impulse(e,0.75,spd)
  else
   impulse(e,0.25,spd)
  end

  if not e.cgh then   
   spd*=0.85
   acc=0
			if spd<0.1 then
			  init_mon(e)
    if not rt then
     dash(e,h,true)
    end
			end
  end
 end
 e.bncx=f
 e.bncy=f 
end

-- get the closest hiro to e
-- -----------------------------

function hcl(e) 
 best=nil
 bdist=999
 for h in all(heroes) do
  dd=dst(h,e)
  if dd<bdist and h.act then
   best=h
   bdist=dd
  end
 end
 if not best then
  return heroes[1]
 end
 return best
end

-- distance from a to b
-- -----------------------------

function dst(a,b)
 local dx=a.x-b.x
 local dy=a.y-b.y
	return sqrt(dx*dx+dy*dy)
end

-- monster behaviour shoot
-- -----------------------------

function mon_fire(e)
 
 if e.t==12 then 
  
  e.fr=112+e.mt
  local b=frshot(68,e)
  --b.y+=1
  b.x+=e.flp
  b.turn=1 
  
  if e.mt==3 then
   e.rmpo={5,0}
   b.lp=false
   b.rmp=e.rmp
   b.fr=112  
   b.raymod=2
   an=sgda(e.trg,b)
   b.we=0.25
   b.frict=0.99999
   
   sfx(s_hammer)
   b.vx=e.flp*(0.5+1/2)
   b.vy=-rnd(2)-2

   b.ondeath=function()
    e.rmpo=nil 
   end
   b.upd=function(b)

    --if b.t%4==0 then
     --sfx(s_hammer)
    --end

    smoke(b)
    
    if e.dead then
     --b.frict=1.0
    else--if b.t%5 then
     --[[spd+=0.15
     an=sgda(e,b)
     impulse(b,an,spd) ]]

     --spd+=0.25
     --if spd > 1 then spd=1 end
     --an=sgda(heroes[1],b)

     --if spd < 3 then
     --impulse(b,an,spd) 
     --log("dist ".. an)
    --end 
     

     if b.t > 1 then
      e.rmpo=nil     
     end
     if b.t > 300 then
      --sfx(s_dmg)
      kill(b)
      e.rmpo=nil     
     end
     
    end

   end
  else
   b.vx=e.flp*2      
   b.phys=true  
   b.upd=function(b)
    burn(b)
   end
   sfx(s_fball)
  end
 end
 
 if e.t==20 then
  e.bhv=crawl
 end 
 
end

-- -----------------------------

function sgda(a,b,xonly,yonly)
 xonly=xonly or false
 yonly=yonly or false


 local dx=a.x-b.x
 local dy=a.y-b.y
 
 if xonly then dx = 0 end
 if yonly then dy = 0 end


 return atan2(dx,dy)
end

-- monster behaviour jump
-- -----------------------------

function mon_jmp(e)

 lim=e.mad and 6 or 32
 if e.t<lim then
  e.flp =(flr(e.t/8)%2)*2-1
 elseif e.we==0 then
  e.fr=80+e.mt
  e.vy=-3.6
  e.we=0.25
  e.bncy=function(e)
   still(e)
   e.bhv=crawl
  end
 end
end

-- do this on hit
-- -----------------------------

function hit(e,n,sd) 
 e.flh=7
 ftt=2
 if e.dmg then 

   e.dmg+=n
   if e.dmg>=e.res then
    stun(e,sd)
   else
    sfx(s_nostun)
   end

 end 
end

-- behaviour stun
-- -----------------------------

function stun(e,sd)
 sfx(s_stun)
 e.stuncd=sd
 e.vx=0 
 e.fr=64+e.mt
 e.we=0.25
 e.bncy=function(e) e.vy=0 end
end

-- hiro logic for update
-- -----------------------------

function upd_hero(h)
 
 -- walking
 h.vx=0

 function walk(n)
  h.flp=n
  h.vx=n*1.5
 end  
 
 if btn(0,h.hid) then walk(-1) end
 if btn(1,h.hid) then walk(1) end
 
 -- jumping / anim
 if h.ground then 
  if btnp(4,h.hid) then
   sfx(s_jump)
   h.vy=-7.5
   dust(1,h)
   if btn(3,h.hid) then
    h.vy=2
    h.cgh=1
   end
  end

  -- walk
  h.fr=32
  if t%8<4 and h.vx!=0 then 
   h.fr=33 
  end

 else
  if not btn(4,h.hid) then
   if h.vy <= 0 then
    h.vy*=0.5
   end
  end

  h.fr=33 
  if h.vy > 1 then
   h.fr=35
  end
  if h.vy < -1 then
   h.fr=34
  end  
 end

 -- autograb
 m=moncol(h)
 if m and m.stun and not h.lift then
  kill(m)
  h.lift=m
  sfx(s_grab)
 elseif m and m.y < h.y+stm_h and not m.stun then
    hit(m,4,160)
    h.vy=-7.5
 end

 -- head stomp

 -- shooting / grab / drop
	if btnp(5,h.hid) then
	 
	 if h.lift then	 
	  --if h.ground and btn(3,h.hid) then
	  -- drop(h)   
	  --else
	   launch(h)
	  --end
	 --elseif #bombs<h.bomb0+3 then
  else 
   
   -- reduce bomb count
   local bomb=false
   for e in all(ents) do
    if e.blid==blid then
     bomb=true
    end
   end

   local prebomb = h.bombs
   if not bomb then 
    h.bombs-=1 
    if h.bombs < 0 then h.bombs = 0 end
   end

   if prebomb == 0 and not bomb then
    prebomb=1
    lostime(5)
   end

   if bomb or prebomb > 0 then

    if btn(2) then
     shoot_bomb(h,3.25)
    elseif btn(3) then
     shoot_bomb(h,-3.25)
    else
     shoot_bomb(h,2.3)
    end
   
   end

  end
 end
 
 -- invincible 
 h.vis=not h.cinv or h.cinv%2==1   
 
end

-- drop any objects your are carrying
-- -----------------------------

function drop(h)
 e=h.lift
 h.lift=nil
 add(monsters,e)
 add(ents,e)
 e.x=h.x+h.flp*8
 e.y=h.y	   
end

function lostime(te)
 
 h=heroes[1]
 local e=mkentity(-1,95,220)
 e.vy=-0.15
 e.draw=function(e)  

  print("-"..timeformat(te) ,h.x-20,h.y-10,7+(t%2))
 end
 e.life=34
 time_start-=te

end

-- kill player
-- -----------------------------

function die(h)
 kill(h)
 ttl_dth+=1
 
 
 nodeathbon=false

 if h.lift then
  drop(h)
 end

 lostime(trondeath)

 sfx(s_die)
 e=mkentity(36,h.x,h.y)
 e.size=7
 e.we=1
 e.phys=true
 e.vy=-5
 e.flp=h.flp
 e.bncy=function(e) 
  e.vy*=-0.75 
  if e.t>20 then 
   e.we=0
   e.vy=0
  end
 end
 e.life=40
 e.blink=12   
 if lives>0 then
  lives-=1
  life_lost=30
  e.ondeath=function()
   spawn_hero(h)
   h.cinv=64
   if h.bombs < 5 then
    h.bombs=1
   end
  end
 else
  h.act=false
  act-=1 	
 end
 
 shk=6
 flash_bg=0
 ftt=3 

 dust(5,h)
 
end

function dust(c,en,xf,yf)
  xf=xf or rnd(6)-e.flp*6
  yf=yf or -1

  for i=0,c do
  --e=mkentity(74,h.x,h.y)
  e=mka(en.x,en.y+2,0,12,4,4,4,2+rand(4))
  impulse(e,(i+xf)/5,yf)
  e.frict=0.5+rnd(0.15)
  
  --e.blid=h.hid

  e.phys=true
  e.we=0.1
  --e.size=0.5
  
  e.bncy=function(e) e.vy*=-0.15 end
  e.bncx=function(e) e.vx*=-0.15 end
  end


end

-- player shoot bomb
-- -----------------------------

function shoot_bomb(h,yang)


 sfx(s_bthrow)
 
 nobombbon=false

 for e in all(ents) do
  if e.blid==blid then
   sfx(s_exp)
   shk=32
   kill(e)
   return
  end
 end
 
 local bb=mkentity(-1,h.x,h.y)
 bb.pow=pw
 bb.raymod=-2
 bb.vx=h.flp*(0.5+h.bomb2/2)
 bb.vy=-yang
 bb.we=0.25 
 bb.phys=true
 bb.size=3
 bb.life=h.bomb1*60
 bb.blid=blid
 ttl_bm+=1

 bb.bncx=function(bb) 
  sfx(s_bbounce)
 end
 bb.bncy=function(bb)
  bb.vy=max(bb.vy,-2.5)
  sfx(s_bbounce)
 end 
 
 bb.upd=function(bb)
  burn(bb)
  
  for e in all(ents) do
   if e.hit and ecol(e,bb) then
  
    bb.vx*=-1 
    bb.bncx(e) 

   end
  end
 end 

 bb.ondeath=function(bb)
 
  apply_effect(-1,bb)
 end
 add(bombs,bb)
end
 
-- spawn thing you are throwing
-- -----------------------------

function mkb(mt,from)
 local e=mkentity(64+mt,from.x,from.y-3)
 e.mt=mt
 e.obj=true
 e.phys=true
 e.proj=true
 e.vx=2
 e.lvb=lvb
 bnum=bnum+1
 lvb=lvb+1
 e.stomp=false

 if lvb >=6 then
  lvb=4
 end 

 e.ondeath=function()bnum=bnum-1 end
 e.bncx=function(e)
  sfx(s_bounce)
  if e.proj then
   xpl(e)
   
   local bf=pickups
   delay(4,function() mkbonus(bf,e) end)
   pickups+=1
   if pickups>=53 then pickups=48 end
   sfx(s_monexp)
   shk=4  
  end
 end 
 
 local lim=32+rnd(48)
 e.bncy=function(e)
  sfx(s_bounce)
  if e.ground then
   e.t+=2
   if e.t>lim and not e.proj then

    if rnd(2)==0 then
     b=mkbonus(e.lvb,e)
    end

    e.phys=false
    e.lp=false
   end
  end
 end  
 
 e.rot=0
 e.turn=1
 e.upd=function(e)  
  m=moncol(e)

  if e.t>40 then 
   e.vy=0
   b=mkmonster(e.mt,e.x,e.y)
   stun(b,50)
   b.stun=true
   b.dmg=b.res
   kill(e)
  elseif m and not e.cdt then
   b=mkbonus(e.lvb,e)
   m.xpl(e) 
   xpl(e)
  end

 end
 return e

end

-- explode a entity
-- -----------------------------

function xpl(e)

 if e.proj then
  if bnsscr[e.mt+1] then
  popup(heroes[1],bnsscr[e.mt+1],e.x,e.y,true)
  end

  e.t=0
  e.proj=false
  e.lp=true
  e.vy=-1
  e.upd=nil
  e.frict=0.97
  e.we=0.25  
  
  if e.xpsmk then
   e.xpsmk=true
  end

 end

end

-- launch whatever you are carrying
-- -----------------------------

function launch(h)
 nsfx=s_throw
 e=mkb(h.lift.mt,h) 
 e.vx=h.flp*2
 h.lift=nil
 if e.y < 12 then
  e.y=12
 end

end

-- spawn a bonus item
-- -----------------------------

function mkbonus(fr,p)
 sfx(s_bns)
 e=mkentity(fr,p.x,p.y)
 e.obj=true
 e.van=vanish 
 e.dp=0
 e.vy=-2
 e.we=0.25
 e.phys=true 
 
 e.upd=function(e)
  local h=herocol(e)  
  if h then

   if fget(fr,6) then
    nsfx=s_tick
    popup(h,50*(fr-47),h.x+4,h.y,true)
   else
    apply_effect(fr,h)
   end
   kill(e)
  end  
 end
 e.life=240
 e.blink=60
 
 return e 
end

-- apply effect of item pickup
-- -----------------------------

function apply_effect(fr,h)
  
 -- grenade
 if fr==-1 then
  sfx(s_exp)
  shk=12
  local e3=mkentity(-1,h.x,h.y)
  e3.phys=false
  e3.killmon=true
  e3.xpsmk=true
  e3.turn=1
  e3.size=16
  ftt=3
  flash_bg=7
  dust(10,e3,8,10)

   e3.draw=function(e3)
    burn(e3)
    frms=4
    if e3.t <= frms/4 then
     circfill(e3.x, e3.y, e3.size/2, 1)
    elseif e3.t <=frms/2 then
     circfill(e3.x, e3.y,e3.size/1.5, 7)
    else 
     circ(e3.x, e3.y, e3.size/1.5, 7)
    end

    if e3.t >= 10 then
     kill(e3)
    end
  end

  local f3=mkentity(-1,h.x,h.y)
  f3.phys=false
  f3.killmon=false
  f3.turn=1
  f3.size=24
  f3.stunmon=true
  
  f3.draw=function(f3)
    if f3.t >= 10 then
     kill(f3)
    end
  end


 end

 -- bomb pickup
 if fr==4 then
  sfx(s_pickup)
  h.bombs+=1
  popup(h,50,h.x+4,h.y,true)
 end
 
 
end

-- are a and b colliding?
-- -----------------------------

function ecol(a,b)
 dx=a.x-b.x
 dy=a.y-b.y
 if a.lp and b.lp then
  dx=mdx(a.x-b.x,60)
  dy=mdy(a.y-b.y,54)
 end
 dx=abs(dx)+a.raymod+b.raymod
 dy=abs(dy)+a.raymod+b.raymod
 local l=(a.size+b.size)/2
 return dx<l and dy<l
end

-- is e collidng with a monster?
-- -----------------------------

function moncol(e)
 for m in all(monsters) do
  if ecol(m,e) and m.hit then
		 return m
  end
 end
 return nil
end

-- is e collidng with a hiro?
-- -----------------------------

function herocol(e)
 for h in all(heroes) do
  if h.act and ecol(h,e) and not h.dead then
		 return h
  end
 end
 return nil
end


-- -----------------------------

function tw(e,tx,ty,n,twj,nxt)
 e.sx=e.x
 e.sy=e.y
 e.tx=tx
 e.ty=ty
 e.twc=0
 e.twj=twj
 e.spc=1/n
 if n<0 then
  local dx=tx-e.x
  local dy=ty-e.y
  local dd=sqrt(dx*dx+dy*dy)
  if twj then dd+=twj*1.4 end
  e.spc=-n/dd
 end
 e.twnxt=nxt
end

-- update the entity
-- -----------------------------

function upe(e)
 e.t+=1
 e.ox=e.x
 e.oy=e.y
 
 -- counters
 for v,n in pairs(e) do
  if sub(v,1,1)=="c" then
   n-=1
   if n<=0 then
    e[v]=nil
   else
    e[v]=n
   end
  end
 end

 if e.upd then e.upd(e) end
 if e.obj or e.lift then objs+=1 end
 if e.turn and t%2==0 and not e.stun then
  e.rot=e.rot or 0
  e.rot=(e.rot+e.turn)%4 
 end
 e.vy+=e.we
 e.vx*=e.frict
 e.vy*=e.frict

 --and not col(e)

 local c=e.mad and 2 or 1
 local vvx=e.vx*c
 if e.bhv!=fly then c=1 end
 local vvy=e.vy*c

 if e.bvx then
  vvx+=e.bvx
  vvy+=e.bvy
  e.bvx*=0.85
  e.bvy*=0.85
 end
 
 if e.xpsmk then
  smoke(e)
 end

 if e.cfocus then
  vvx=0
  vvy=0
 end

	if e.phys and e.x then
	 -- horizontal
	 e.x+=vvx
	 sx=sgn(vvx)	 
	 if col(e)==2 then	
   brkcount=0  
	  while col(e)==2 and brkcount < 10 do
    brkcount+=1
	   e.x-=sx	  
	  end
	  e.vx*=-1	
	  e.bncx(e) 
	 end 
	 
	 -- vertical
	 pcol=col(e)
	 e.y+=vvy
	 sy=sgn(vvy)

	 function hcol(e)
	  local n=col(e)
	  if n==1 and e.cgh then 
	   n=0 
	  end
	  return n==2 or (n==1 and sy>0 and pcol==0)
	 end	 
	 
  if hcol(e) then	
   brkcount=0  
	  while hcol(e) and brkcount < 10 do
    brkcount+=1
	   e.y-=sy
	  end

   majground(e)
			e.vy*=-1
			e.bncy(e) 
	 end

  -- ground test
  majground(e)
  
  if e.ground and abs(e.vx) >0.5 and e.tdust + 10 < e.t then

   e.tdust = e.t
   dust(1,e)
  end

	else
	 e.x+=vvx
	 e.y+=vvy
	end
	
	-- tween
 if e.twc then
  tx=e.twt and e.twt.x or e.tx
  ty=e.twt and e.twt.y or e.ty
  e.twc=min(e.twc+e.spc,1)
  c=0.5-cos(e.twc*0.5)*0.5
  e.x=e.sx+(tx-e.sx)*c
  e.y=e.sy+(ty-e.sy)*c
  if e.twj then
   e.y+=sin(c*0.5)*e.twj
  end	
  if e.twc==1 then
   e.twc=nil  
   if e.twnxt then e.twnxt() end
  end
 end
 -- life
 if e.life then
  e.life-=1
  if e.blink and e.life < e.blink then
   e.vis=t%4<2
  end
  if e.life<=0 then
   e.van(e)
  end
 end
 
 -- ba
 if e.bad and not e.stun then
  h=herocol(e)
  if h and h.y+stm_h < e.y and e.stomp then 
   h.vy=-12.5 
   hit(e,4,160) 
  end
  if h and not h.cinv then
   if e.shot then kill(e) end
   
   if h.special==1 then
    if e.xpl then 
     e.xpl()
    end
   elseif h.y+stm_h >= e.y or not e.stomp then
    die(h)   
   end

  end
 end 

 
 if e.killmon then
  for m in all(monsters) do
   if ecol(m,e) then
   
    m.xpsmk=e.xpsmk
    m.xpl()
   
   end
  end
 end

 -- stunmon
 if e.stunmon then
  for m in all(monsters) do
   if ecol(m,e) and not m.stun then
    if not e == boss and not e == boss2 then 
     hit(m,4,160)   
     popup(h,"stun",m.x,m.y)
    end
   end
  end
 end
 
	-- mod
	if e.lp then
	 e.x=mdx(e.x)
	 e.y=mdy(e.y)
	else 
	 if out(e) and not e.ores then	  
	  kill(e)
	 end
	end
	
	
end

-- default vanish function
-- -----------------------------

function vanish(e)
 mka(e.x,e.y,32,8,8,8,3,4)
 kill(e)
end

-- grounded check 
-- -----------------------------

function majground(e)
 e.ground=col(e,0,1)>0 and col(e,0,0)==0
end

-- -----------------------------

function out(e)
 return e.x<-4 or e.y<-4 or e.x>132 or e.y>132
end

-- generic entity kill function
-- -----------------------------

function kill(e)
 e.dead=true
 del(ents,e)
 del(bombs,e)
 del(monsters,e)
 if e.ondeath then 
  e.ondeath(e) 
 end
end

-- -----------------------------

function mdx(n,k)
 k=k or 0
 n+=k
 return (n%120)-k
end
function mdy(n,k)
 k=k or 0
 n+=k
 return (n%112)-k
end

-- check collision dx dy direction
-- -----------------------------

function col(e,dx,dy)
 dx=dx or 0
 dy=dy or 0
	local x=mdx(e.x+dx-e.size/2)
	local y=mdy(e.y+dy-e.size/2)
	local ex=mdx(x+e.size-1)
	local ey=mdy(y+e.size-1)
 a={x,y,ex,y,ex,ey,x,ey}
 
 n=0
 for i=0,3 do
  x=a[i*2+1]/8
  y=a[i*2+2]/8
  local fr=lget(flr(x),flr(y))
  if n==0 and fget(fr,1) then
   n=1
  end
  if fget(fr,0) or fget(fr,4) then 
   return 2
  end  
 end 
 return n
 
end

-- draw and entity e
-- -----------------------------

function dre(e)
 if not e.vis or e.dp!=dp then return end
	fr=e.fr
	x=e.x-e.size/2
	y=e.y+e.ofy-e.size/2
	
	
	-- frame flag
	
 if fget(fr,0) then
	 y-=1
	end	


	if fget(fr,3) and e.t%4>2 then
	 fr+=1
		if fget(fr,2) then
		 kill(e)
		 return
		end	
		if fget(fr,1) then
			while not fget(fr-1,5) do
			 fr-=1
			end
		end	
	end
	e.fr=fr
	
	
 -- remap
	if e.rmp then
	 for i=0,15 do

    -- sget get from sprite loc x, y	  
   pal(i,sget(8+i,e.rmp))
	 
  end
	end

	if e.rmpo then
	 pal(e.rmpo[1],e.rmpo[2])
	end
	
	-- flh
	if e.flh then
	 for i=0,15 do
	  pal(i,e.flh)
  end
  if ftt<=0 then 
   e.flh=nil
  end
	end
	
	if e.flash then
	 e.flash-=1
	 for i=0,15 do
	  pal(i,8+rand(8))
  end
	 if e.flash==0 then
	  e.flash=nil
	 end
	end
	
	if e.stunshk then x+=1 end

	-- draw
	function dr(x,y) 
	 if e.lift then
   spr(64+e.lift.mt,x,y-6,1,1,e.flp==-1,-1)	
 	end
  
 

 	if e.rot then
   for gx=0,7 do for gy=0,7 do
	   px=flr(fr%16)*8
	   py=flr(fr/16)*8	 

	   if px+gx > 0 and py+gy > 0 then
     p=sget(px+gx,py+gy)
     if p>0 then
 	    dx=gx
 	    dy=gy	 
      for i=1,e.rot do
       dx,dy=7-dy,dx
      end
      pset(x+dx,y+dy,p)
     end
    end

	  end	end
 	else
	  spr(fr,x,y,e.size/8,e.size/8,e.flp==-1)
	 end
	 if e.draw then e.draw(e,x,y) end
	end
 dr(x,y) 
 if e.lp then
  if x<8 then dr(x+120,y) end
  if x>120-e.size then dr(x-120,y) end
  if y<8 then dr(x,y+112) end
  if y>112-e.size then dr(x,y-112) end


 end
 
 pal()

 -- draw mad !
 if e.mad and (t%4 == 0 or t%4 == 1) then
   spr(23,x,y-9,1,1,e.flp==-1,false) 
 end
 
end


-- update level
-- -----------------------------

function upd_lvl()
 -- ents
 if bnum==0 then lvb=4 end
	objs=0
 foreach(ents,upe)
 
 -- check gameover
 if act==0 or game_time<=0 then
  act=-1

  function f()
   loop=nil
   fadeto(gameover,true)
  end  
  delay(40,f) 
 end
 
 if objs==0 and not clean then
  if lvl+1 > last_lvl then
   function f()
    loop=nil
    fadeto(gamecomplete,true)
   end  
   delay(20,f) 
  else
   finish_lvl()
  end
 end

 -- timer
 if not clean then
  run_timer() 
 end



end

-- make entity stop moving
-- -----------------------------

function still(e)
 e.we=0
 e.vy=0
 e.vx=0
end

-- called when level is done
-- -----------------------------

function finish_lvl()

 clean=true
 music(m_lvlend)
 local kn=0
 for h in all(heroes) do
  if h.act then 

   h.t=0
   still(h)
   h.lp=false 
   
   local px=h.x
   local py=h.y
    
   h.upd=function()
     local offv= -20;
     if kn == 0 then
     local tx1 = "stage "..(lvl+1).." cleared!"
     local tx2 = "time: "..timeformat(time()-level_start).." sec"
     
     local cntr = 68
     popup(h,tx1,cntr,66+offv,false,enddelay)
     popup(h,tx2,cntr,76+offv,false,enddelay)
     ttl=ttl+time()-level_start
     extra=-10
     if nobombbon then
      local tx3 = "no bomb bonus:+"..20*(lvl+1)
      popup(h,tx3,cntr,86+offv,false,enddelay)
      h.score+=20*(lvl+1)
      extra=0
     end

     if nodeathbon then
      local tx4 = "no death bonus:+"..50*(lvl+1)
      popup(h,tx4,cntr,96+extra+offv,false,enddelay)
      h.score+=50*(lvl+1)
     end

     end

     if kn > enddelay then
      leave()
     end
     
     kn+=1
   end
   
  end
 end
end

-- clear ents go to next level
-- -----------------------------

function leave()
 ents={}
 monsters={}
 nxl=0
 nobombbon=true
 nodeathbon=true
 loop=nil
 goto_level(lvl+1) -- + 1

end

function spop(h,spd)
 return mka(h.x+rnd(8)-4,h.y+rnd(8)-4,40,5,3,3,5,spd)
end

--  make animated object
-- -----------------------------

function mka(x,y,dx,dy,dw,dh,fmax,spd)
 local e=mkentity(-1,x,y)
 e.lp=false
 e.size=dw
 e.draw=function(e,x,y)
  f=flr(e.t/spd)
  if f>=fmax then 
   kill(e) 
  else
   sspr(dx+dw*f,dy,dw,dh,x,y)
  end
 end
	return e
end

-- spawn item
-- -----------------------------

function spawn_item(it)
 --log("spawned :" .. it)
 p=takeone(bop)
 if p==nil then return end
 b=mkbonus(it,p)
 b.life=320
end

-- level timer function
-- -----------------------------

function run_timer()
 lt+=1
 game_time = time_limit + time_start + 3*lvl - time() 

 if game_time < 20 and last_time > flr(game_time) then 
 last_time=flr(game_time)
 sfx(s_tick)
 end

 h=heroes[1]  
 if getnummon()==0 and not h.lift then return end
  
  if #items>0 and rand(flr((time_limit-lt)/2))==0 then 
  spawn_item(takeone(items))
 end
 

end


-- draw a lvl tile map at y location 
-- -----------------------------

function drmap(lvl,dy)
 local bx=flr(lvl%8)*16
 local by=flr(lvl/8)*16

 map(bx,by,0,dy,15,14) 
 map(bx,by,120,dy,1,14)
 map(bx,by,0,112+dy,15,1)
 map(bx,by,120,112+dy,1,1)
end


-- draw a lvl
-- -----------------------------
function draw_lvl()

 -- shake
 ddx=0
 if shk then
  shk=-shk
  shk*=0.75
  if abs(shk)<1 then
   shk=nil
   ddx=0
  else 
   ddx=shk
  end
  
 end 
 camera(ddx,-8)
 
 -- flash the bg
 if flash_bg then  
  -- uses the first 3 luts for flashing bg
  rectfill(0,0,128,120,sget(ftt+flash_bg-1,flash_bg))
 end
 
 if nxl then
    nxl=nil
    fadeto(init_level,false)
 else
  drmap(lvl,0)

  for i=0,2 do
   dp=i
    foreach(ents,dre)
  end

 end

 -- inter
 camera(0,0)
 rectfill(0,0,127,7,0)
 
 -- score
 h=heroes[1]  
 sc=h.score..""
 while #sc<5 do sc="0"..sc end
 print(sc,108,1,7)
 
 -- bombs
 bc=h.bombs..""
 while #bc<2 do bc="0"..bc end
 print(bc,7,1,7)
 
 sspr(24,0,5,5,1,1)

 -- draw timer
 tc=timeformat(game_time)
 if game_time < 20 and t%2 == 0 then
  print(tc,47,1,8)
 else
  print(tc,47,1,7)
 end

 tckr+=1

end