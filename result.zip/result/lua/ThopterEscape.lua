-- thopter escape
-- by josh millard

fcount = 0 -- global frame count
 -- incremented every update()

tstate = "anim" -- title substate
state = "title" -- game state

pstate = "preplay" -- play sub
preroll = 60 -- countdown for preplay

p = {} -- player object

mx = 0 -- map x offset value
scrollspeed = 0.5
gravity = 1
drag = 2.4

-- precompute some simple
-- vector components for the
-- flight model at various
-- tilts
vec = {}
vec.up    = {0.3,-0.3}
vec.level = {0.4,-0.1}
vec.down  = {0.5,0.1}

thaccel = 0.7
thdecel = 0.02
thbrake = 0.12
thmax = 10
thcost = 0.5
threcover = 0.05
 
fuelmax = 10

thrusting = 0 -- anim tracker

mapend = 895 -- mx stop point
glevel = 0 -- game level
glevs = {"harkonnen treachery ",
         "the deep desert",
         "grip of shaitan"}
gwinlevel = count(glevs) + 1

scrolling = true

ithrust = false -- input tracking
ibrake = false  --  flags

music(9)

function new_game()
 -- set things up for a fresh
 -- go at the game
 glevel = 0
 mx = 0
 scrolling = true
 
 -- talking paul anim stuff
 ttalkc = 0
 tpanim = 1
 ts1 = ""
 ts2 = ""
 
 -- set up player
 p = {}
 p.w = 16 -- pixel dimensions
 p.h = 8 
 p.sp = {}
 p.sp.up = 0  -- sprite indices
 p.sp.level = 16
 p.sp.down = 32
 p.lives = 3
 p.alive = true
 reset_ship()
 
 -- later levels overwrite the
 -- mapsheet, this retores the
 -- map to orig rom contents
 reload(0x2000,0x2000,0x1000)
 next_level()
end

function reset_ship()
 p.x = 20 -- screenpos
 p.y = 20
 p.vx = 0 -- horiz/vert veloc.
 p.vy = 0
 p.tilt = "level" -- ship angle
 p.thrust = 7 -- rocket thrust
 p.fuel = 10
 p.alive = true
end

function move_player()

 p.fuel += threcover
 if(p.fuel>fuelmax) p.fuel=fuelmax
 p.thrust -= thdecel
 if(p.thrust>thmax) p.thrust=thmax
 if(p.thrust<0) p.thrust=0
 

 -- apply forces
 p.y += gravity
 p.x -= drag 

 -- adjust pos
 p.x += p.vx + p.thrust * vec[p.tilt][1]
 p.y += p.vy + p.thrust * vec[p.tilt][2]

 -- cap speed
 if(p.vx > 3) p.vx = 3
 if(p.vx < -3) p.vx = -3
 if(p.vy > 3) p.vy = 3
 if(p.vy < -3) p.vy = -3

 -- enforce roving bounds
 
 if(p.x < -8) then
  p.x = -8
  p.vx = 0
 end
 if(p.x > 120) then
  p.x = 120
  p.vx = 0
 end
 if(p.y < 0) then
  p.y = 0
  p.vy = 0
  p.tilt = "level"
 end
 if(p.y > 120) then
  p.y = 120
  p.vy = 0
 end

end

crashanim = 0
function kill_ship()
 p.alive = false
 crashanim = 0
 sfx(4,3)
 music(-1)
end

function next_life()
 pstate = "preplay"
 preroll = 60
 scrolling = true
-- todo: put a bunch of this
-- into a "spawn player"
-- routine to avoid duplication
 reset_ship()
 mx = 0
end

function add_storm(l)
 local levs = {{},{},{}}
 levs[1].u={168,104}
 levs[1].r={169,120}
 levs[1].d={170,72}
 levs[1].l={171,88}
 levs[2].u={172,104} 
 levs[2].r={173,120}
 levs[2].d={174,72}
 levs[2].l={175,88}
 levs[3].u={188,104}
 levs[3].r={189,120}
 levs[3].d={190,72}
 levs[3].l={191,88}
 
 for x=0,127 do
  for y=0,15 do
   local m = mget(x,y)
   if(m == levs[l].u[1]) then
    mset(x,y,levs[l].u[2]+(x%8))
   elseif(m == levs[l].r[1]) then
    mset(x,y,levs[l].r[2]+(y%8))
   elseif(m == levs[l].d[1]) then
    mset(x,y,levs[l].d[2]+(x%8))
   elseif(m == levs[l].l[1]) then
    mset(x,y,levs[l].l[2]+(y%8))
   end
  end
 end
end



function collisions()
 -- check for object collisions
 if(p.alive) then
  local col = collide_terrain()
  if(col) kill_ship()
  dv = collide_storm()
  if(dv.col) then
   p.x += 1.5 * dv.x
   p.vx += 0.003 * dv.x
   p.y += 1 * dv.y
   -- shake the ship around
   p.x += rnd(2)-1
   p.y += rnd(2)-1
  end
  if(p.x <= -3) then
-- todo: justify this with a
-- wall of deathsand on the 
-- left edge of screen?
   kill_ship()
  end
 end
end

function collide_terrain()
 return collide_flag(0)
end

function collide_storm()
 local dv = {}
 dv.col = false
 dv.x = 0
 dv.y = 0
 if(collide_flag(2)) then
  dv.col = true
  dv.x = -1
 end
 if(collide_flag(3)) then
  dv.col = true
  dv.y = -1
 end
 if(collide_flag(4)) then
  dv.col = true
  dv.x = 1
 end
 if(collide_flag(5)) then
  dv.col = true
  dv.y = 1
 end
-- return collide_flag(2)
 return dv
end

function collide_flag(fl)
 local iscol = false
 -- ship is two adjacent
 -- sprites on sheet, do
 -- check for each
 local sps = {p.sp[p.tilt],
              p.sp[p.tilt]+1}   
                       
 for spx = 0,1 do
  local sp = sps[spx+1]
  local px = p.x + spx*8
  local py = p.y

  -- top left and bottom right
  -- map tiles near sprite
  local c=mapcoord(px+mx,py)
  local c2=mapcoord(px+mx+8,
   py+8)

  -- pixel offset of ship from
  -- upper left map tile c
  local ox=flr(px-(c.x*8-mx))
  local oy=flr(py-(c.y*8))
 
  local cw = (c2.x-c.x)
  local ch = (c2.y-c.y)
 
  for x=0,cw do
   for y=0,ch do
    local m=mget(c.x+x,c.y+y)
    if(m == 0) then
     -- no collision for empty
     -- map tile
    elseif(not fget(m,fl)) then
     -- no collision for tile
     -- that doesn't match
     -- given flag
    else
     if(collide_pixel(m,sp,
       ox-(x*8),oy-(y*8)))
     then
--      mset(c.x+x,c.y+y,
--       72 + rnd(7))
      iscol = true 
      -- could bail here with
      -- an immediate return
      -- true to save time
     end
    end
   end
  end
 end
 if(iscol) return true
 return false
end



function do_gameover()
 -- set up the end-game state
 state = "gameover"
end

function do_winscreen()
 state = "win"
end

function tilt(dir)
 if(dir == "u") then
  if(p.tilt == "level") then
   p.tilt = "up"
  elseif(p.tilt == "down") then
   p.tilt = "level"
  end
 elseif(dir == "d") then
  if(p.tilt == "level") then
   p.tilt = "down"
  elseif(p.tilt == "up") then
   p.tilt = "level"
  end
 end
end

function _init()
 -- stuff to execute once
 -- at the start of program
 new_game()
end

-- input routines --

function do_input_play()
 if(pstate=="preplay") then
  -- nothing
 elseif(pstate=="play") then
  ithrust=false
  ibrake=false
-- handy for debugging
--  if(btnp(2)) next_level()
  if(btn(4)) then
   thrust("b")
   ibrake = true
  end
  if(btn(5)) then
   thrust("f")
   ithrust = true
  end
  if(btnp(0)) tilt("u")
  if(btnp(1)) tilt("d")
 end
end

function thrust(d)
 if(d=="b") then
  p.thrust -= thbrake
  p.vy -= 0.01 * p.thrust
 end
 if(d=="f") then
  if(p.fuel>thcost) then
   -- can't thrust if low fuel
   p.thrust += thaccel
   p.fuel -= thcost
   thrusting += 1.5
   if(thrusting>6) then
    thrusting -= 2
   end
  end
 end
end

function do_input_gameover()
 if(btnp(4)) then
  state = "title"
  tstate = "anim"
  music(9)
 end
end

function do_input_win()
 if(btnp(4)) then
  state = "title"
  tstate = "anim"
  music(9)
 end
end



function do_input_title()
 -- handle input on the 
 -- title screen
 if(tstate=="anim") then
  if(btnp(4)) then
   tstate = "prompt"
   music(-1)
  end
 elseif(tstate=="prompt") then
  if(btnp(4)) then
   new_game()
   state = "play"
   pstate = "preplay"
   preroll = 60
  end
 end
end

function scroll_terrain()
 if(scrolling) then
  mx += scrollspeed
 else
  p.x += scrollspeed
 end
end

-- update routines --

function update_play()
 if(pstate=="preplay") then
  preroll -= 1
  if(preroll <= 0) then
   pstate="play"
   music(1)
  end
 elseif(pstate=="play") then 
  if(p.alive) then
   scroll_terrain()
   do_input_play()
   move_player() 
   collisions()
   if(mx >= mapend) then
    scrolling = false
   end
   if(not scrolling) then
    if(p.x >= 120) then
     next_level()
    end
   end
  end
  -- gameover check 
  if(p.lives == 0) then
   do_gameover()
  end
 end
end

function next_level()
 glevel += 1
 if(glevel == gwinlevel) then
  do_winscreen()
  return
 end
 add_storm(glevel)
 next_life()
end

function update_gameover()
 -- gameover updates
 do_input_gameover()
end

function update_win()
 do_input_win()
end

function update_title()
 -- title updates
 do_input_title()
end

slowcount = 0
slowmo = false
function _update()
 fcount += 1
 if(state == "play") then
  if(slowmo) then
   slowcount += 1
   if(slowcount%5!=0) return
  end
  update_play()
 elseif(state == "gameover") then
  update_gameover()
 elseif(state == "win") then
  update_win()
 elseif(state == "title") then
  update_title()
 end
end

-- draw routines --
fcount = 0
tod = 1
function draw_terrain()
 local pals = {
  {9,10,7},{9,10,7},{9,10,7},
  {9,10,7},{9,10,7},
 
  {4,10,7},{4,9,7},{4,9,10},
  {5,9,10},{5,4,10},{5,4,9},
  {1,4,9},{1,13,9},
  {1,13,4},{1,13,2},
  {1,13,0},
  
  {1,13,0},{1,13,0},{1,13,0},
  {1,13,0},{1,13,0},
 
  {1,1,0},{1,1,0},{1,1,0},

  {13,1,0},{13,1,0},{13,1,0},
  {13,1,0},{13,1,0},  

  {13,1,0},
  {13,1,4},
  {13,1,9},{4,1,9},
  {4,5,9},{4,5,10},{9,5,10},
  {9,4,10},{9,4,7},{10,4,7},
  
  {10,9,7},{10,9,7},{10,9,7},
  {10,9,7},{10,9,7},
  {9,9,7}

 }
 if(fcount % 30 == 0) then
  tod += 1
  if(tod > count(pals)) then
   tod -= count(pals)
  end
 end
 
 rectfill(0,0,127,127,
  pals[tod][3])
 local mapx = flr(mx/8) 
 local scrx = -(mx%8)

 -- palette swapping
 pal(9,pals[tod][1])
 pal(10,pals[tod][2])

 -- map ground background
 animate_storm(mapx,0,17,16)
 map(mapx,0,scrx,0,17,16,0x1)
 pal()
 -- player mid
 draw_player()
 -- sand foreground
 map(mapx,0,scrx,0,17,16,0x2)
 -- deadly wall of sand behind
 draw_chasesand()

end

chspr = {70,71,86,87}
chs = {1,2,3,4,1,3,4,2,
       3,1,4,3,2,1,2,4}
function draw_chasesand()
 for i=1,16 do
  if(fcount % 3 == 0) then
   chs[i] %= count(chspr)
   chs[i] += 1
  end
  spr(chspr[chs[i]],0,i*8-8)
 end
end
 

-- rotate through tileset of
-- sand tiles on map
sacount = 0
function animate_storm(x1,y1,w,h)
 sacount+=1
 if(sacount % 2 == 0) then
 for x = x1,x1+w-1 do
  for y = y1,y1+h-1 do
   local m = mget(x,y)
   if(m >=72 and m <= 127 and
      m%16>=8) then
    if(m%8 == 7) then
     m -= 7
    else
     m += 1 
    end
    mset(x,y,m)
   end
  end
 end
 end
end 

function draw_storm()
 local mapx = flr((2*mx-96)/8)
 local scrx = -(2*mx%8)
 map(mapx,16,scrx,0,17,16)
end

function draw_player()
 if(p.alive) then
  -- draw main craft body
  local fr = 0
  if(p.tilt=="up") then
   fr=0
  elseif(p.tilt=="level") then
   fr=16 
  elseif(p.tilt=="down") then
   fr=32
  end
  spr(fr,p.x,p.y,2,1)
  -- draw wings
  local wing
  if(ithrust) then
   wing = 39
  elseif(ibrake) then
   wing = 38
  else
   wing = 22+((fcount/4)%4)
  end
  spr(wing,p.x+2,p.y+0)
 
  -- draw rocket fire
  if(thrusting > 0) then
   local thy = 0
   local fr = 4 + flr(thrusting)
   if(p.tilt=="up") then
    thy = 1
   elseif(p.tilt=="down") then
    thy = -1
   end
   spr(fr,p.x-8,p.y+thy,1,1)
 
   -- play rocket sfx
   sfx(0,3,thrusting*4)
 
   -- steadily reduce thrusting
   thrusting -= 0.3
   if(thrusting < 0) then
    thrusting = 0
   sfx(-1,3)
   end
  end
 else
  -- player is dead, do death
  -- animation stuff
  local fr
  if(crashanim < 8) then
   fr=128+flr(crashanim)*2 
   crashanim += 0.33
   spr(fr,p.x,p.y-8,2,2)
  else
   -- done animating crash
   p.lives -= 1
   if(p.lives > 0) then
    next_life()
   end
  end 
 end
end

function draw_stats()
-- onscreen ship stat stuff
 -- draw fuel gauge
 local fx = 100
 local fy = 2
 rect(fx,fy,fx+21,fy+6,2)
 rectfill(fx+1,fy+1,
  fx+flr(p.fuel*2),fy+5,3)
 
end

function draw_play()
 if(pstate=="preplay") then
  draw_preplay()
 elseif(pstate=="play") then
-- todo: consider working with
-- this scroll-fast threshold
-- idea (but as is it makes
-- the game play too quickly
-- given the short maps)
  if(scrolling and false) then
   local cline = 50
   local maxline = 60
   local spread = maxline-cline
   local diff = p.x-cline
   local mshare = (diff/spread)
   local pshare = 1-mshare
   if(diff > 0) then
    mx += mshare * scrollspeed
    p.x += 2*pshare * scrollspeed
   end
  end
  draw_terrain()
  draw_stats() 
 end
end

function draw_preplay()
 print("chapter "..glevel..":",
  20,50,7)
 print(glevs[glevel],
  26,60,fcount%3+8)
 print("lives: "..p.lives,
  31,80,7)
end


function draw_title() 
 -- draw title screen stuff
 if(tstate=="anim") then
  spr(201,35,30,7,2)
  spr(234,39,46,6,2)
  print("(z to start)",40,80,7)
 end
 
 if(tstate=="prompt") then 
 -- haaaaacky solution
  local speech={	
 {"fear",""},
	{"fear",""},
	{"fear",""},
	{"fear",""},
	{"fear",""},
	{"fear is",""},	
	{"fear is",""},
	{"fear is",""},
	{"fear is the",""},
	{"fear is the",""},
	{"fear is the",""},
	{"fear is the","mind"},
	{"fear is the","mind"},
	{"fear is the","mind"},
	{"fear is the","mind"},
	{"fear is the","mind-kil"},
	{"fear is the","mind-kil"},
	{"fear is the","mind-kil"},
	{"fear is the","mind-killer"},
	{"fear is the","mind-killer"},
	{"fear is the","mind-killer"},
  }
 
  local px = 20
  local py = 50  
  rect(px-1,py-1,px+82,py+32,1)
  rectfill(px,py,px+31,py+31,0)
  spr(192,px,py,4,4)
  
  -- and soundtrack for same
  ttalkc += 0.25
  if(tpanim <= count(speech)) then
   ts1=speech[flr(tpanim)][1]
   ts2=speech[flr(tpanim)][2] 
   sfx(1,1,flr(tpanim))
   sfx(2,2,flr(tpanim))
   sfx(3,3,flr(tpanim))
   tpanim += 0.5
   if(flr(ttalkc) % 2 == 0) then
    spr(244,px+8,py+24,2,1)
   end
  end
  -- add some blinking
  if(flr(ttalkc) % 15 == 0) then
   spr(212,px+8,py+8,2,1)
  end
  
  print(ts1,px+35,py+10,7)
  print(ts2,px+35,py+18,7)

 end
end

function draw_gameover()
 print("game over",
  47,52,7)
end

function draw_win()
 spr(12,47,20,4,4)
 print("paul and jessica",
  31,62,7)
 print("escaped the sandstorm",
  21,70,7)
 print("will they find refuge",
  21,82,7)
 print("in the rocks ahead...",
  21,90,7)

 print("...or new dangers?",
  27,106,7)

end

function draw_debug()
 print("thr:"..p.thrust,0,0,8)
 print("vx: "..p.vx,0,6,8)
 print("vy: "..p.vy,0,12,8)
end


-- translate a sprite sheet num
-- to x,y pixel coords on sheet
function sheetcoord(sp)
 local shc = {}
 shc.x = (sp%16)*8
 shc.y = flr(sp/16)*8
 return shc
end

-- translate screen coords to
-- 1/8 scale map data coords
function mapcoord(sx,sy) 
 local mx = flr((sx)/8)
 local my = flr((sy)/8)
 local coords = {}
 coords.x = mx
 coords.y = my
 return coords
end

function _draw()
 -- call appropriate draw
 -- functions based on 
 -- game state
 cls()
 if(state == "gameover") then
  draw_gameover() 
 elseif(state == "win") then
  draw_win() 
 elseif(state == "title") then
  draw_title()
 elseif(state == "play") then
  draw_play()
 end
end

-- library: collision routines 
-- by josh millard

-- utility function:
-- returns rect structure
-- based on x,y position
-- and 8*8 sprite size
function new_rect(x,y)
 local r = {}
 r.x1 = x
 r.y1 = y
 r.x2 = x + 7
 r.y2 = y + 7
 return r
end

-- utility function:
-- return object with x,y pixel
-- coords on sprite sheet of
-- given sprite number
function shtcoord(sp)
 local sh = {}
 sh.x = (sp%16)*8
 sh.y = flr(sp/16)*8
 return sh
end

-- simple box collision:
-- takes rectangle coords for
-- two sprites.
-- return true if bounding
-- rectangles overlap, false
-- otherwise
function collide_rect(r1,r2)
 if((r1.x1 > r2.x2) or
    (r2.x1 > r1.x2) or
    (r1.y1 > r2.y2) or
    (r2.y1 > r1.y2)) then
  return false
 end
 return true
end

-- pixel-perfect collsion:
-- takes two sprite sheet 
-- numbers and a pixel offset
-- in x and y of the second
-- sprite from the first.
-- return true if any pixels in
-- sprites overlap, false
-- otherwise
function collide_pixel(sp1,sp2,xoff,yoff)
 
 local sh1 = shtcoord(sp1)
 local sh2 = shtcoord(sp2)
 
 -- a whack o' local vals
 local a = nil
 local b = nil
 local colcount = 0
 
 local xstart = 0
 local xend = 7
 local ystart = 0
 local yend = 7
 local x1off = 0
 local x2off = 0
 local y1off = 0
 local y2off = 0
 
 -- narrow range of collision
 -- test based on offset of
 -- two sprites
 if(xoff > 0) then
  xend = 7-xoff
  x1off = xoff
 elseif(xoff < 0) then
  xend = 7+xoff
  x2off = -xoff
 end
 if(yoff > 0) then
  yend = 7-yoff
  y1off = yoff
 elseif(yoff < 0) then
  yend = 7+yoff
  y2off = -yoff
 end

 -- do the actual test over
 -- the overlap rectangle
 for x=xstart,xend do
  for y=ystart,yend do
   a = sget(sh1.x+x+x1off,
    sh1.y+y+y1off)
   b = sget(sh2.x+x+x2off,
    sh2.y+y+y2off)
   if(a!=0 and b!=0) then
    -- pixel overlap means
    -- we collided at:
    -- x+x1off,y+y1off
    colcount += 1
    -- but lets bail asap to
    -- save time, yeah?
    return true
   end
  end
 end
 if(colcount > 0) then
  return true
 end
 return false
end