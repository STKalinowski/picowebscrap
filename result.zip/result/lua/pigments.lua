tempo=8
chars="abcdefghijklmnopqrstuvwxyz."
fmax=6

ddr={1,0,0,1,-1,0,0,-1}
threshold={0,50,100,250,25,180}


-- apple:start with 16 paint
-- 
-- kiwi:+50% speed on painted tiles
cartdata("disc")

function _init()
 t=0
 fd=0
 logs={}
 st=rand(999)

 
 
 hid=rand(fmax)
 hid=3

 sfx(25)
 init_menu()
 --init_game() 
 --disp_score() 
 --for i=0,fmax do dset(i,0) end
 

end


function ysort(a)
 for i=1,#a do
  local j = i
  while j > 1 and a[j-1].y+a[j-1].ssy > a[j].y+a[j].ssy do
   a[j],a[j-1] = a[j-1],a[j]
   j = j - 1
  end
 end
end




function disp_score()
 t=0
 fad(0,16) 
 
 local sco=flr(tot*100/obj) 
 local a={
  "your score:",
  gprc(sco),
 } 
 --dset(hid,0)
 local prev=dget(hid) or 0
 if sco>prev then
  add(a,"new record !!!")
  dset(hid,sco)
 end 
 
 
 local function f(ev)
  if bta() and t>16 then
   fad(8,16,init_menu)
   kl(ev)
  end
 end
 loop(f)
 
 
 mdr=function() 
  spr(64+hid*16,60,32)  
  local cl=sget(3,8+hid)
  
  for i=1,#a do
   local s=a[i]   
   local dy=max(80+i*32-t*8)
   if i==3 then cl=12 end
   if i<3 or ( t%2==0 and dy==0) then
    print(s,64-#s*2,46+i*8+dy,cl)
   end
  end 
 end
 
 
 

end


function init_menu()
 ents={}
 fad(0,8)
 t=0
 --local at={8,2,9,10,4,11,12,6}
 sel=dget(10)>=10 and dget(10)-10 or 1
 go=nil
 score=0 
 wrong=0
 
 for i=0,fmax do
  local n=dget(i)
  if n then score+=n end 
 end
 
 
 mdr=dr_menu
	loop(upd_menu) 

end


function upd_menu(ev)

  if t==16 then
   music(0) 
  end 

 function cmov(n)
  sfx(7)
  sel=(sel+n)%fmax
 end
 
 f=sget(sel,6)
 fok=score>=threshold[1+f]

 if not go and t>16 then
	 if btnp(0) then cmov(-1) end
	 if btnp(1) then cmov(1) end
	 if bta() then
	  if score>=threshold[1+f] then	
		  sfx(8)
		  hid=sget(sel,6)
		  go=40
		  fad(8,40,init_game)
		  music(-1,800)
		  dset(10,10+sel)
		 else
		  wrong=8
		  sfx(27)
		 end
	 end
 end
 wrong-=1 
end


function bta()
 return btnp(4) or btnp(5)
end

function dr_menu()
 --rectfill(0,0,127,127,13)
 srand(0)
 -- title
 local fc=1-min(t/32,1)
 for i=0,7 do
  pushpal()
  local n=sget(i,reseted and 5 or 7)   
  n+=max(16-t,0)%10   
  local fr=192+(n%8)*2+flr(n/8)*32
  local cl=8+(i+t/16+i/8)%8   
  local cl=8+(i+i/8)%8   
  if t<16 then
   cl=1
  end      
  pal(7,flr(cl))
  pal(13,sget(8+cl,2))   
  _applypal()
  local x=1+i*16+cos(i/16+t/64)*(2+fc^2*16)
  local y=8.5+cos(i/4+t/32)*2
  y-=fc^4*(32+cos(i/4)*32)
  if i==7 then x-=2 end
  spr(fr,x,y,2,2)   
  poppal()
 end
 
 -- title parts
 for i=0,47 do
  local cx=rnd()
  local x=cx*128
  local y=rand(32)
  palt(0,false)
  x+=cos(cx/2+t/64)*(fc^2*64+rnd(8))
  y+=cos(cx*2+t/32)*(2+rnd(2))
  y-=fc^4*(32+cos(i/4)*32)
  spr(6,x,y,3/8,3/8)
  cl=8+(cx*8+rnd(1.5)-.5)%8
  if t<16 then
   cl=13
  end
  pset(x+1,y+1,cl)
  
 end
 palt(0,true)
 
 -- fruits 
 local mx=(128-fmax*16-(fmax-1)*4)/2
 
 if t>24 then	 
	 for i=0,fmax-1 do	  
	  if (i==sel and (not go or t%2==0) ) or not go then
		  pushpal()
		  local n=sget(i,6)	
		  local blu=score<threshold[1+n]		  
		  if blu then
		   apal(1)
		  end		  
		   
		  local x=mx+i*20
		  local y=68+sin(i/4+t/40)+.5
		  --+sin(i/4+t/40)+.5
		  spr(64+n*16,x,y)	  
		  local kn=dget(n) or 0	  
		  
		  if not blu then
		  local prc=gprc(kn)
		  local cl=sget(3,8+n)
		  print(prc,x+5-#prc*2,y+12,cl)
		  end 
		  poppal()
		  if sel==i and not go then
		   spr(32,x,y+20+abs(sin(t/16)*4+.5))
		  end
	  end
	 end
	 
	 -- meta score
	 local s="metascore:"..score.." pts"
	 local y=108-fc^1.5*128
	 print(s,64-#s*2,y,wrong>0 and 8 or 1)
	 --[[
	 for i=0,#s do
	  
	  print(sub(s,i,i),64+i*4-#s*2,y,1)
	 end	 
	 --]]
	 
	 -- desc	 
	 local d=hdesc[f+1]	 
	 if not fok then
	  d={
	   "",
	   "need "..threshold[f+1].." pts"
	  }	 
	 end
	 for i=1,#d do
	  local s=d[i]
	  local cl=13
	  if i==1 then cl=sget(3,f+8) end
	  local y=34+i*7
	  local x=64-#s*2
	  if wrong>0 then
	   x+= wrong*((wrong%2)*2-1)
	   cl=8
	  end
	  print(s,x,y,cl)
	 end
	
	 
 end
 

 
 -- parts 
 local hor=116-fc^1.5*128
 line(0,hor,127,hor,1)
 
 --[[
 for i=0,16 do
  local cl=8+(t+i)%8
  line(i*8,hor-1,i*8+8,hor-1,cl)
 end
 --]]
 
 
 
 for i=0,64 do
  
  local dx=rnd()
  local dy=rnd()
  local dh=rnd()
  
  local s=16--8+rnd(16)
  
  dy=(dy+t/s)%1
  local cy=dy*dy
  
  local x=64+(dx-.5)*(.5+cy)*256
  local y=hor+cy*(128-hor)
  
  --y-=dh*96*cy
  
  --pset(x,y,8+rnd(8))
  local cl=8+rnd(8)
  cl=sget(8+cl,fc^2*7)
  circfill(x,y,.5+cy*2,cl)
  
  --spr(64+rand(4)*16,x,y)
 end
 
  
end

function gprc(n)
 local prc=flr(n)..""
 while #prc<2 do prc="0"..prc end
 if #prc<3 then 
  prc=prc.."%"
 elseif t%2==0 and t>10 then
  prc="" 
 end
 return prc
end



function init_game()
 srand(t+st)
 reload()
 ents={}
 tot=0
 reseted=false
 mdr=dr_game
 
 --
 fd=10
 fad(0,16)
 

 
 -- load level
 obj=0
 mons={}

 for x=0,15 do for y=0,15 do
  local tl=mget(x+hid*16+16,y)
  if tl==64 then
   mk_hero(x,y)
   tl=12
  elseif fget(tl,2) then
   add(mons,{x=x,y=y,t=tl-48})
   tl=12
  end  
  if is_grey(tl) then
   obj+=1
   --tl+=64
   --tot+=1
  end

  mset(x,y,tl)
 end end 
 for m in all(mons) do
  mk_disc(m.x,m.y,m.t,true)
 end


 -- disc above
 --[[
 for e in all(ents) do
  if e.disc then
		 del(ents,e)
		 add(ents,e)
	 end
	end
	--]]
	

 -- droplet
 mk_droplet()

 -- disc sfx
 local disc_noise=function()
  local c=max(1-h.md/64,0)
	 set_vol(flr(c*c*7))
	 if t%4==0 then sfx(0) end
  if h.sliced then
   h.md+=4
  else
   h.md=128
  end	  
	 
	end
 loop(disc_noise)
 
 --
 play()
end



function mk_hero(x,y)
 h=mke()

 h.fr=64+hid*16
 h.ddy=-3
 place(h,x,y)
 h.h=2
 h.shd=4
 h.paint=hid==1 and 24 or 0
 h.md=128
 
 for x=80,127 do for y=32,63 do
  if sget(x,y)==1 then
   sset(x,y,sget(2,8+hid))
  end 
  if sget(x,y)==5 then
   sset(x,y,sget(3,8+hid))
  end  
  
  
 end end


end

function mk_droplet()
 
 local a={}
 for x=0,15 do for y=0,15 do  
  if not pcol(x,y) and not fg(x,y,4) and not fg(x,y,3) then   
   if abs(h.px-x)+abs(h.py-y)>7 then
    add(a,{x=x,y=y}) 
   end   
  end   
 end end
 
 dp=a[rand(#a)+1]
 e=mke(22)
 e.dl=true
 place(e,dp.x,dp.y)
 e.h=0
 e.upd=function(e)
  e.z=cos(t/40)*2-3.5
  if h.px==e.px and h.py==e.py then
   kl(e)
   mk_droplet()
   mk_disc(dp.x,dp.y,0)
   h.⧗drop=16
   h.paint=min(h.paint+16,24)
   if hid==0 then
    h.paint+=8
   end
   
   h.⧗warn=nil
   sfx(3)
  end  
 end
 e.shd=2.5 
 drl=e

end
function rand(n)
 return flr(rnd(n))
end


function place(e,px,py)
 e.px=px
 e.py=py
 e.x=px*8
 e.y=py*8
end


function play()
 h.upd=upd_hero
end


function upd_hero()
 
 
 -- razor sfx

 if h.sliced then
  return
 end 
 
 if btnp(0) then hmov(-1,0)
 elseif btnp(1) then hmov(1,0)
 elseif btnp(2) then hmov(0,-1)
 elseif btnp(3) then hmov(0,1)
 end
 
 --
 h.water=fg(h.px,h.py,4)
end

function super_jump()
 sfx(1)
 local k=tempo
 mvt(h,trg.px*8,trg.py*8,k)
 h.jmp=6    
 h.px=trg.px
 h.py=trg.py
 h.⧗inv=k 
 tic(k)
end


function aggro()
 for e in all(ents) do
  if e.disc then
   local dx=h.x-e.x
   local dy=h.y-e.y
   e.an=atan2(dx,dy)
   e.vx=cos(e.an)*e.spd
   e.vy=sin(e.an)*e.spd
   e.⧗anger=16
  end
 end
end


function hmov(dx,dy)
 
 
 local nx=h.px+dx
 local ny=h.py+dy  
 
 if pcol(nx,ny) then  
  sfx(2)
  mv(h,dx*4,dy*4,tempo)
  h.twcv=function(c)
   return -sin(c/2)
  end
 else
	 h.px=nx
	 h.py=ny
	 local f=nil	 
	 local tl=mget(nx,ny)
	 
	 if fget(tl,1) then
	  aggro()
	  sfx(13)
	 end

  if h.paint>0 and is_grey(tl) then
   f=paint 
   sfx(6)
  else  
   if fg(nx,ny,4) then     
    h.paint=max(h.paint-1,0)
    sfx(12)
   else
    sfx(1)
   end 
   if is_grey(tl) then
    h.⧗warn=8
   end
  end	 
	 mvt(h,nx*8,ny*8,tempo-1,f)
	 
 end 
 h.jmp=4
 tic(tempo) 
 
 
 if not h.goal and tot==obj then
  finish()  
 end 
end

function finish()
 sfx(26)
 h.⧗goal=40
 h.goal=true
 local f=function()
  fad(8,32,disp_score)
 end
 wt(80,f)
 
 
 for e in all(ents) do
  if e.disc then
   kl(e)
   splash(e.x+4,e.y+4)
  end
 end
 
end




function is_grey(tl)
 return tl%16>=10 and tl<64
end


function paint()
 local tl=mget(h.px,h.py)
 if h.paint>0 and is_grey(tl) then
  mset(h.px,h.py,tl+64)
  h.paint-=1
  tot+=1
 end
 

 
end


function tic(k)
 h.upd=nil 
 for e in all(ents) do
  if e.r then
   e.r+=k
  end
 end 
 wt(k,play)
 
end



function loop(f,n,nxt)
 local e=mke()
 e.upd=f
 e.life=n
 e.nxt=nxt
 e.y=256
 return e
end
function wt(n,f)
 return loop(nil,n,f)
end

function mk_disc(px,py,t,lvl_gen)
 local spd={2,4,1}
 
 local e=mke(48,px*8,py*8)
 e.shd=4
 e.flp=3
 e.upd=upd_disc
 e.r=0
 e.h=2
 e.an=rnd()
 e.spd=spd[1+t]
 e.disc=true
 -- silver
 if t==1 then
  e.taint={ [13]=6,[1]=5,[5]=13 }
 elseif t==2 then
  e.taint={ [13]=4,[1]=5,[5]=1,[7]=9 }
 
 end 
 
 -- sticky
 if lvl_gen then
	 for di=0,3 do  
	  local nx=px+ddr[1+di*2]
	  local ny=py+ddr[2+di*2]
	  if pcol(nx,ny) then
	   e.wall=di
	   e.an=di/4+.25
	  end  
	 end
 end
 
 if e.wall then
  e.px=px
  e.py=py
  e.d=0
  --e.spd=1
 else 
  e.pcol=function(x,y)
   return pcol(x,y) or fg(x,y,3)
  end
	 e.vx=cos(e.an)*e.spd
	 e.vy=sin(e.an)*e.spd 
 end
 
 

 

 return e
end


function show_tile(x,y)
 local e=mke(22,x*8,y*8)
 e.life=16
 e.blk=true
end

function upd_disc(e)
 
 -- apple collision
 local hdx=h.x-e.x
 local hdy=h.y+2+h.ddy-e.y
 local dd=sqrt(hdx*hdx+hdy*hdy)
 if not h.sliced then
  h.md=min(dd,h.md)
 end
 
 local lim=6
 if hid==4 then lim=8 end
 if hid==3 then lim=5 end
 
 
 if dd<lim and not h.sliced and not h.⧗inv and not h.water then
  slice()
 end
  
 -- wall
 if e.wall then
 
  --local wx=e.px+ddr[1+e.wall*2]
  --local wy=e.py+ddr[2+e.wall*2]
  e.d+=e.spd*e.co
  local f=(e.wall+1)%4 
  local dx=ddr[1+f*2]
  local dy=ddr[2+f*2]
  
  if e.d>=8 then
   e.d-=8
   e.px+=dx
   e.py+=dy
   chk_wall(e)
  end

  e.x=e.px*8+dx*e.d
  e.y=e.py*8+dy*e.d
  
 --[[trail
 if e.r>0 and e.t%3==0 and false then  
  local sh=mke(51,e.x,e.y)
  sh.life=16
  sh.lifepal=1
  sh.dp=0 
 end
 --]]
 
 
 end
 
 

end


function wcol(e,d)
 local wx=e.px+ddr[1+d*2]
 local wy=e.py+ddr[2+d*2]
 return pcol(wx,wy)
end

function chk_wall(e)
 if not wcol(e,e.wall) then
  e.wall=(e.wall-1)%4
 elseif wcol(e,(e.wall+1)%4) then
  e.wall=(e.wall+1)%4
 end
end


function slice()
 sfx(5)
 h.sliced=true
 h.⧗sl=48
 h.fr=65+hid*16
 h.ssy=-8
 
 local e=mke(66+hid*16,h.x,h.y+h.ddy,h.z-2)
 e.vz=-4
 e.z=-1
 e.we=.15
 e.vx=rnd(5)-2
 e.vy=rnd(4)-4
 e.r=0 
 e.shd=3
 e.frict=.98
 e.h=1 
 
	splash(h.x+4,h.y+4) 
  
 local f=function()
  fad(8,16,disp_score)
 end   
 wt(40,f)
 
end

function splash(xx,yy)
 for i=0,7 do
  local e=mke(0,xx,yy)
  e.vz=-2-rnd(6)
  imp(e,rnd(),rnd(5)-1)
  e.we=.1+rnd(.1)
  e.dr=function(e,x,y)
   pset(x,y,sget(1,hid+8))
  end
  e.frict=.97
  e.r=0
  e.h=1
  e.shd=-1
 end 
end

function imp(e,a,s)
 e.vx+=cos(a)*s
 e.vy+=sin(a)*s
end

function fad(n,tempo,nxt) 
 local sn=fd 
 local f=function(e) 
  fd=sn+(n-sn)*e.t/tempo
 end 
 loop(f,tempo,nxt)
end

function ecol(e,dx,dy)


 dx = dx or 0
 dy = dy or 0 
 local a={0,0,0,1,1,1,1,0}
 for i=0,3 do
  local x=e.x+a[i*2+1]*(e.ww-1)+dx
  local y=e.y+a[i*2+2]*(e.hh-1)+dy
  if e.pcol(x/8,y/8) then 
   return true 
  end
 end
 return false
end

function pcol(x,y)
 if x<0 or y<0 or x>16 or y>=16 then
  return true
 end
 return fg(x,y)
end

function fg(px,py,fl)
 return fget(mget(px,py),fl)
end


function pmov(e,dx,dy)

 local clx,cly=false,false

 e.x+=dx 
 while ecol(e) do
  e.x-=sgn(dx)
  clx=true
 end
 
 e.y+=dy 
 while ecol(e) do
  e.y-=sgn(dy)
  cly=true
 end


 local adx=cos(e.an)
 local ady=sin(e.an)
	if clx then e.vx*=-1	end
	if cly then e.vy*=-1	end
 --e.an=atan2(e.vx,e.vy)
 
 
end



function mke(fr,x,y,z)
 local e={
  fr=fr or 0,
  x=x or 0,
  y=y or 0,
  z=z or 0,
  h=0,
  t=0,ww=8,hh=8,  
  vx=0,vy=0,vz=0,
  we=0,frict=1,dp=1,
  ddx=0,ddy=0,ssy=0,
 }
 e.bz=z
 
 add(ents,e) 
 return e
end

function mv(e,dx,dy,n,f)
 mvt(e,e.x+dx,e.y+dy,n,f)
end
function mvt(e,tx,ty,n,f)
 e.sx=e.x
 e.sy=e.y
 e.ex=tx
 e.ey=ty
 e.twc=0
 e.tws=n
 e.twf=f  
 if n<0 then
  dx=e.ex-e.sx
  dy=e.ey-e.sy
  e.tws=-sqrt(dx^2+dy^2)/n
 end
end

function upe(e)
 e.t=e.t+1
 
 
 -- slow motion
 e.co=1
 if e.r then
  e.co=.1
  if e.r>0 then
   e.r-=1
   e.co=1
  end
 end  
 
 --
 if e.upd then e.upd(e) end
 
 
 -- phys
 local vx=e.vx*e.co 
 local vy=e.vy*e.co 
 local vz=e.vz*e.co 
 if e.pcol then  
  pmov(e,vx,vy)
 else
  e.x+=vx
  e.y+=vy 
 end 
 e.z+=vz 
 e.vz+=e.we 
 
 local fr=e.frict^e.co
 e.vx*=fr
 e.vy*=fr
 e.vz*=fr
 
 if e.z>0 then
  e.z=0
  e.vz*=-.5
  e.vx*=.75
  e.vy*=.75
  if abs(e.vz)<.5 then
   e.we=0
   e.vz=0
  end
 end
 
 -- counters
 for v,n in pairs(e) do
  if sub(v,1,1)=="⧗" then
   n-=1
   e[v]= n>0 and n or nil
  end
 end 
 
 --  tweens
 if e.twc then
  local c=min(e.twc+1/e.tws,1)
  cc=e.twcv and e.twcv(c) or c
  e.x=e.sx+(e.ex-e.sx)*cc
  e.y=e.sy+(e.ey-e.sy)*cc
  if e.jmp then
   e.z=sin(c/2)*e.jmp
  end  
  e.twc=c  
  if c==1 then
   e.twc=nil
   e.jmp=nil
   e.twcv=nil
   local f=e.twf
   if f then
    e.twf=nil
    f()
   end
  end
 end 
  
 -- life
 if e.life then
  e.life-=1
  if e.life<=0 then
   kl(e)
  end 
 end
 
end

function kl(e)
 del(ents,e)
 if e.nxt then
  local f=e.nxt
  e.nxt=nil
  f()
 end
end

function dre(e,drx,dry)

 if e.blk and t%2==0 then
  return
 end

 local drx= drx or 0
 local dry= dry or 0
 local x=e.x+drx+e.ddx
 local y=e.y+dry+e.ddy
 local fr=e.fr 
 local pp=0
 
 --water
 if e.water then
  local n=16
  clip(h.px*8-8,h.py*8-n,24,4+n)
  y+=3
 end
 
 if e.⧗anger and t%2==0 then
  pushpal()
  apal(8)
  pp+=1
 end
 
 
 if e.flp then
  fr+=e.t%e.flp
 end
 
 if e.lifepal then
  pushpal()
  apal(sget(e.life/2,e.lifepal))
  pp+=1
 end
 
 if e.dl then
  pushpal()
  pal(14,sget(3,8+hid))
  pal(2,sget(2,8+hid))
  pp+=1
 end
 
 if e.taint then
  pushpal()
  for i,j in pairs(e.taint) do
   pal(i,j)
  end
  --pal{[13]=10,[1]=3,[5]=9}
  --pal(13,10)
  --pal(e.taint)
  pp+=1
 end

  
 local dr=function(x,y)  
  if fr>0 then
   spr(fr,x,y)
  end
  if e.dr then
   e.dr(e,x,y)
  end  
 end
 
 if e.⧗drop and t%2==0 then
  brd(dr,x,y,12)
 else
  brd(dr,x,y,0)
  --dr(x,y)
 end

 for i=1,pp do
  poppal()
 end
 
 clip()
 
end

function apal(n)
 for i=0,15 do pal(i,n) end
 _applypal()
end


function drs(e)
 if e.shd then
  if e.shd<0 then
	   
	   local cl=sget(8+pget(e.x,e.y),2)
	   pset(e.x,e.y,cl)
	   return
  end
 
 
  local x=e.x+e.ddx
  local y=e.y+e.ddy
  local r=max(1,e.shd)
  local fc=nil
  if e.water then
   y+=3+e.z
   fc=1
  else
   x+=e.h-e.z/2
   y+=e.h-e.z/2
  end

  for dx=0,7 do for dy=0,7 do
   local px=x+dx
   local py=y+dy   
   local bx=(e.fr%16)*8
   local by=flr(e.fr/16)*8   
   if sget(bx+dx,by+dy)>0 then   
	   local cl=fc or sget(8+pget(px,py),2)
	   pset(px,py,cl)
   end
  end end
  
  if e.water then
   local py=flr(e.y/8)  
   local y=py*8+4
   local w=max(8+e.z*2,0)
   if w>0 then
    line(e.x+3-w/2,y,e.x+3+w/2,y,7)
   end
  end
  
  
  --dre(e,e.h-e.z/2,e.h-e.z/2)
 end 
end



function _update()
 t=t+1
 
 
 foreach(ents,upe)
 
 ysort(ents)
 
 if btn(4,1) and btnp(1,1) then
  for i=0,fmax do dset(i,0) end
  reseted=true
  _init()
 end
 
 --log(#ents)
 --[[
 if t%10==0 then
  for e in all(ents) do
   if e.r and e.r==0 then
    e.r+=1
   end 
  end
 end
 --]]
 
end

function dr_game()

 -- tiles
 if h.⧗goal and t%4<2 then
  pushpal()
  local cl=8+t%8

  pal(sget(2,hid+8),sget(3,hid+8))
  pal(sget(3,hid+8),7)
  _applypal()
		map() 
		poppal()
  
 else
  map() 
 end
 
 

 -- inter
 local prc=gprc(tot*100/obj)
 local cl=sget(3,8+hid)
 print(prc,58,121-8,cl)
 for i=0,23 do
  local px=i%8
  local x=57+px*2-8
  if px>3 then x+=14 end
  local y=117-flr(i/8)*2
  local cl=sget(3,8+hid)
  local emp=(h.⧗warn and t%2==0) and 8 or 1
  local fcl=i<h.paint and cl or emp
  
  if i<h.paint and h.water and t%4<2 then
   fcl=12
  end  
  
  pset(x,y,fcl)
  --line(x,121,x,125,i<h.paint and cl or 1)
 end
 -- shades
 pushpal()
 foreach(ents,drs)
 poppal()
 
 -- ents
 for dp=0,1 do
	 for e in all(ents) do
	  if e.dp==dp then
	   dre(e,0,e.z)
	  end
	 end
 end

 
 
 --print(gprc(h.paint),114,121,cl)


 -- sliced msg
 if h.⧗sl then
 
  local ds=function(kx,ky)
	  local c=h.⧗sl/48
	  local cx=64
	  local cc=16-min(sqrt(h.⧗sl/16),1)*15
	  local by=h.y>40 and 16 or 56
	  for i=0,7 do   
	   local dx=8+i*16-cx
	   local ec=max(c-.75,0)*128
	   local dy=sin(i/7+t/8)*ec
	   spr(192+i*2,cx+kx+dx*cc,by+ky+dy,2,2)
	  end 
  end  
  brd(ds,0,0,0)
 end
 

end


function _draw()
 cls()
 respal()
 
 
 -- fad
 if fd>0 then
  pushpal()
  for i=0,15 do
   local cl=fd<8 and sget(8+i,fd) or 0
   pal(i,cl,1)
  end
  _applypal()
 end
 
 
 
 -- 
	mdr()
 --
 -- unfad
 if fd>0 then
  poppal()
 end
 
 
 
 _pal(11,138,1)
 
 
 -- log 
 color(8+t%3) 
 cursor(0,0)
 for str in all(logs) do
  print(str)
 end 
 
end

function brd(f,x,y,n)
 pushpal()
 apal(n)

 
 f(x,y-1) 
 f(x+1,y) 
 f(x,y+1) 
 f(x-1,y)
 
 --[[
 f(x-1,y-1)
 f(x+1,y-1)
 f(x+1,y+1)
 f(x-1,y+1) 
 
 --]]
 
 
 poppal()
 f(x,y)
end


--
function log(str)
	add(logs,str)
	while #logs>20 do
	 del(logs,logs[1])
	end
end



--
hdesc={
 {
  "apple",
  "+50% pigments from droplet",
  "grass area:25%",
 },{
  "orange",
  "+1 silver disc",
  "start with 24 pigments",
 },{
  "banana",
  "+5 bronze crawlers"
 },{
  "kiwi",
  "size -25%",
  "+6 bronze discs",
 },{
  "watermelon",
  "size +25%",
  "water area:25%",
 },{  
  "coconut",
  "+20 aggro traps",
 }
 

}
-->8
-- pal

_stack={}
add(_stack,{})
_pal=pal
_pct=0

function respal()
 _stack={}
 add(_stack,{})
 _pct=0
end

function _mpal(a,b) 
 if #_stack>0 then
  _stack[#_stack][a]=b
 end
end

function pushpal()
 add(_stack,{})
 
end
function poppal()
 del(_stack, _stack[#_stack])
 _applypal()
end

function _applypal()
 sum={}
 _pct+=1
 for si=1,#_stack do 
  local cr=_stack[#_stack+1-si]
  local will={}  
  for i,j in pairs(cr) do
   for g,h in pairs(sum) do
    if h==i then
     will[g]=j
    end  
   end
	  if not sum[i] then
	   will[i]=j
	  end	      
  end  
  for i,j in pairs(will) do
   sum[i]=j
  end
 end
 _pal()
 for i,j in pairs(sum) do
  _pal(i,j)
 end 
end


pal=_mpal
respal()
-->8
--__draw,_bp=_draw,0 function _draw() _bp=(_bp+1)%4 poke(0x5f5e,0xf0|(1<<_bp)) __draw() end function cls() rectfill(0,0,127,127,0) end
-->8
-- sfx
function make_note(pitch, instr, vol, effect)
 return { pitch + 64*(instr%4) , 16*effect + 2*vol + flr(instr/4) } -- flr may be redundant when this is poke'd into memory
end

--16*effect + 2*vol + flr(instr/4) } -- flr may be redundant when this is poke'd into memory

function set_vol(v)
 for tm=0,1 do
  local addr = 0x3200+2*tm
  local n=2*v+4*16+1 -- ( +1 if inst>=4
  poke(addr+1,n)
 end
end