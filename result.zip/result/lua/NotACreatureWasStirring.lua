-- 07. not a creature was stirring
-- by kittenm4ster for advent 2018


-- global constants
fps = 60
keyboard_y = 95
key_count = 29
key_pos_type = {
  [0] = {22, 1},
  {25, 4},
  {28, 2},
  {31, 4},
  {34, 3},
  {40, 1},
  {43, 4},
  {46, 2},
  {49, 4},
  {52, 2},
  {55, 4},
  {58, 3},
}
for i = 12, key_count - 1 do
  local src = key_pos_type[i - 12]
  key_pos_type[i] = {
    src[1] + 42,
    src[2]
  }
end
key_sx = {
  110,
  116,
  122,
  105, -- black
}
top_platform_y = 14
snowman_start = {22, 22}
snowman_speed = .9
headdrop_x = 24
rope_gravity = 0.2
rope_tightness = .8
rope_damping = .50
curtain_min_y = -33
curtain_max_y = keyboard_y
title_fade_len = 6
title_fade_table = {
   [0] = {2,  2,  1,  1,  1},
   [3] = {2,  5,  5,  3,  3},
   [7] = {8, 14, 14, 14, 15},
   [9] = {2,  4,  4,  4,  9},
  [10] = {8,  8,  9,  9, 10},
  [11] = {8,  4,  5,  5, 11},
  [12] = {2, 13, 13, 13, 12},
  [15] = {8,  8, 14, 14, 15},
}
switcher = {y = 128}
switchers = {
  {18, 0, 101, 2, 2},
  {18, 15, 152},
  {18, 22, 152},
  {18, 27, 1, 1, 2, true},
}
stripe_fill = {0x1248, 0x8124, 0x4812, 0x2481}

function _init()
  channelnote = {}
  songpos = {prevticks = 0}
  notesubs = {}
  melodynotes = {}
  actors = {}
  coroutines = {}

  snowflakes = {}
  for i = 1, 256 do
    local s = {}
    init_snowflake(s)
    s.y = rnd_int(-32, keyboard_y)
    add(snowflakes, s)
  end

  rope = new_rope()
  lightsn = 0
  lightstimer = timer.new(fps / 8)

  snowman_body = add_actor({
    x = -9,
    y = 87,
    anims = {
      default = anim.new(1, 1,
        {95, 95, 79, 79, 95, 111, 111, 0, 0, 111, 95, 95, 95, 95}, 4, false)
    }
  })
  snowman_head = add_actor({
    x = -8,
    y = 83,
    anims = {
      default = anim.new(1, 1, {33}, 0, false),
      hop = anim.new(1, 1,
        {33, 16, 16, 16, 16, 16, 35, 49, 51, 127, 127, 51, 49, 35}, 4, false),
      slump = anim.new(1, 1, {33, 16}, 4, false),
    }
  })

  init_bell_ringers()
  init_bigringers()
  init_ballet()

  tubamouse = add_actor({
    x = -30,
    y = 85,
    targetx = 55,
    w = 12,
    anims = {
      default = anim.new(2, 2, {160}, 0, false),
      run = anim.new(1, 2, {128, 129, 130, 131, 132}, 4, true),
      stand = anim.new(1, 2, {128}, 0, false),
      play = anim.new(2, 2, {162, 164, 162, 160}, 3, false)
    },
    pal = {[2] = 7}
  })
  tuba = {
    visible = true,
    x = 60,
    y = 80,
    sx = 5,
    sy = 81,
    sw = 10,
    sh = 15,
    palt = {1, 3, 6, 7, 8, 14}
  }

  horsemouse1 = new_horsemouse(-30, 87)
  horsemouse2 = new_horsemouse(-30, 87)
  horse = add_actor({
    x = -48,
    y = 79,
    w = 34,
    anims = {
      default = anim.new(5, 2, {64, 96}, 999, true)
    }
  }, true)

  snowboarder = add_actor({
      x = -56,
      y = 86,
      anims = {
        default = anim.new(1, 2, {234, 235}, 4, true),
        fall = anim.new(2, 2, {170, 236}, 4, true)
      },
      pal = {[9] = 7, [6] = -1, [7] = -1, [13] = -1}
  })
  particles = {}

  cat = {pawx = 83, pawy = -16}
  curtainy = curtain_max_y
  titles = {}

  add_coroutine(run_snowman_head)
  add_coroutine(run_snowman_body)
  add_coroutine(run_cat)
  add_coroutine(run_fallingbell)
  add_coroutine(run_curtain)
  add_coroutine(run_tubamouse)
  add_coroutine(run_tuba)
  add_coroutine(run_switchers)

  add(horse.actions, run_horse)
  if stat(100) ~= 'back to calendar' then
    menuitem(5, 'load calendar', function()
      load('#pico8adventcalendar2018')
    end)
  end
end

function add_coroutine(f)
  add(coroutines, cocreate(f))
end

function follow_body(head, dropx)
  local body = snowman_body

  set_anim(head, 'hop')
  head.y = body.y - 4

  repeat
    if head.x < body.x then
      head.x += (snowman_speed * .5)
      head.x = min(head.x, body.x)
    end

    if dropx then
      head.x = min(head.x, dropx)
    end

    if body.anim:is_done() and (songpos.n + 1) % 4 == 0 then
      head.anim:reset()
    end

    yield()
  until dropx and head.x == dropx
end

function run_snowman_head()
  local head, body = snowman_head, snowman_body

  wait_until(snowman_start)

  follow_body(head, headdrop_x)

  head.maxy = 87
  head.vx = 0
  head.vy = 0

  tubabox = {x = tubamouse.x + 5, y = tubamouse.y + 2, w = 11, h = 2}
  head.w = 6
  head.h = 8

  local gravity = .015
  local airxfriction = .99
  local states = {
    fall = 0,
    wait_for_kick = 1,
    fly_to_tuba = 2,
    wait_for_tuba = 3,
    fly_to_body = 4,
  }
  local state = states.fall

  while true do
    if state == states.wait_for_kick and kicker.readytokick then
      kicker.anim = kicker.anims.kick

      if kicker.anim.i == 3 then
        state = states.fly_to_tuba
        head.vx = .58
        head.vy = -1.1
        head.anim = head.anims.default
      end
    end

    if state == states.fly_to_tuba then
      if overlap(head, tubabox) then
        head.y = tubabox.y - 8
        head.vy = 0
        head.vx = 0
        state = states.wait_for_tuba
      end
    end

    if state == states.wait_for_tuba and tubaisblowing then
      state = states.fly_to_body
      head.vx = .29
      head.vy = -.75
    end

    if state == states.fly_to_body and head.y >= body.y - 4 then
      break
    end

    head.vx *= airxfriction
    head.vy += gravity

    head.x += head.vx
    head.y += head.vy

    if state == states.wait_for_tuba then
      head.y = tubabox.y - 8
    end

    head.y = min(head.y, head.maxy)

    if state == states.fall and head.y == head.maxy then
      state = states.wait_for_kick
      head.anim = head.anims.slump
    end

    yield()
  end

  follow_body(head)
end

function run_snowman_body()
  wait_until(snowman_start)

  while snowman_body.x < 128 do
    if snowman_body.anim:get_index() == 0 then
      snowman_body.x += snowman_speed
    end

    if snowman_body.anim:is_done() and (songpos.n + 1) % 4 == 0 then
      snowman_body.anim:reset()
    end

    yield()
  end
end

function new_horsemouse(x, y)
  return add_actor({
    x = x,
    y = y,
    anims = {
      default = anim.new(1, 1, {152}, 0, false),
      run = anim.new(1, 1, {152, 153, 154, 155, 156}, 4, true)
    }
  })
end

function new_ballerina(x, y)
  return add_actor({
    x = x,
    y = y,
    pal = {[1] = 1},
    anims = {
      default = anim.new(1, 2, {1}, 0),
      pointe = anim.new(1, 2, {2}, 0),
      pointewalk = anim.new(1, 2, {3, 4}, 5, true),
      pointewalkmanual = anim.new(1, 2, {3, 4}, 999, true),
      slump = anim.new(1, 2, {5, 6, 7, 6}, 8),
      unslump = anim.new(1, 2, {5, 1}, 4),
      turn = anim.new(1, 2, {8, 9, 10, 11, 12, 13, 14, 15}, 4),
      leap = anim.new(2, 2,
        {32, 34, 36, 36, 38, 40}, 8, false,
        {[32] = {1}, [34] = {1}, [36] = {2, 1}},
        {[32] = 1, [34] = 2}),
      hop = anim.new(1, 2, {42, 42, 43, 44, 45, 45, 45, 44, 43}, 3),
      kick = anim.new(1, 2, {32, 71, 34, 34, 34, 34, 34, 34, 34, 71, 32}, 5),
    },
    set_flipx = function(self, flipx)
      if (not not self.flipx) ~= flipx then
        self.flipx = flipx
        self.x += (3 * (self.flipx and 1 or -1))
      end
    end
  },
  true)
end

function new_bell(x, y)
  return add_actor({
    x = x,
    y = y,
    anims = {
      default = anim.new(1, 1, {133}, 0, false),
      ring = anim.new(
        1,
        1,
        {133, 134, 190, 136, 133, 137, 138, 139, 133, 140, 133},
        2,
        false,
        {[134] = {2}, [190] = {2}})
    }
  })
end

function new_ringer(x, y)
  return add_actor({
    x = x,
    y = y,
    anims = {
      default = anim.new(2, 2, {101}, 0, false),
      run = anim.new(2, 2, {101, 107, 109, 75, 77}, 4, true),
      ring = anim.new(2, 2, {105, 103, 101}, 4, false)
    }
  }, true)
end

function new_bigringer(x, y)
  return add_actor({
    x = x,
    y = y,
    anims = {
      default = anim.new(2, 2, {69}, 0, false),
      walk = anim.new(2, 2, {166, 168}, 8, true),
      ring = anim.new(3, 2, {72, 69}, 8, false, {[69] = {2}})
    }
  }, true)
end

function wait(n, skippable)
  for n = 1, n do
    yield()
    if skippable and (btnp(4) or btnp(5)) then
      break
    end
  end
end

function add_actor(props, enablecr)
  local actor = add(actors, props)

  actor.anim = actor.anims.default

  if enablecr then
    actor.actions = {}
    add(coroutines, cocreate(
        function()
          while true do
            local action = actor.actions[1]
            if action then
              action()
              del(actor.actions, action)
            end

            yield()
          end
        end
    ))
  end

  return actor
end

-- compensate for bug where stats don't change in sync
function poll_songpos()
  local pat = stat(24)
  local n = stat(21)
  local ticks = stat(26)

  if pat ~= songpos.pat and n ~= songpos.n then
    songpos.pat = pat
    songpos.n = n

    if songpos.prevticks > 0 and ticks >= songpos.prevticks then
      songpos.ticks = 0
      songpos.waitingforticksync = true
    end
  elseif pat == songpos.pat and n ~= songpos.n then
    songpos.n = n
  end

  if songpos.waitingforticksync then
    if ticks < songpos.prevticks then
      songpos.waitingforticksync = false
    end
  else
    songpos.ticks = ticks
    songpos.prevticks = ticks
  end
end

-- @param songcoords an array of {pattern, note}
function wait_until(songcoords)
  while songpos.pat < songcoords[1] do
    yield()
  end
  while songpos.n < songcoords[2] and songpos.pat == songcoords[1] do
    yield()
  end
end

function walk_tween(actor, args)
  local destx = args[1]
  local ticksrc = args[2]
  local tickdst = args[3]
  local flipxoverride = args[4]

  local flipx = flipxoverride
  if flipx == nil then
    flipx = destx < actor.x
  end
  actor:set_flipx(flipx)

  actor.anim = actor.anims.pointewalk

  local t = tween.new(actor.x, destx, ticksrc, tickdst, ease_linear)
  while actor.x ~= destx do
    local ticks = songpos.ticks

    actor.x = t:update(ticks)

    if ticks >= tickdst then
      break
    end
    yield()
  end
  actor.anim = actor.anims.default
end

function ease_linear(t, b, c, d)
  return ((t / d) * c) + b
end

function ease_in_quad(t, b, c, d)
  t = t / d
  return c * (t ^ 2) + b
end

function ease_out_quad(t, b, c, d)
  t = t / d
  return -c * t * (t - 2) + b
end

function hop_on_beat(actor, args)
  local dir = args[1]
  local destx = args[2]

  actor.anim = actor.anims.hop
  if dir == -1 then
    if not actor.flipx then
      actor.x += 3
    end
    actor.flipx = true
  end
  actor.vx = 0

  local sub = note_subscribe(
    function (ch, s, n, note)
      return ch == 1 and (n + 2) % 4 == 0
    end,
    function()
      actor.anim:reset(true)
      actor.vx = 0
    end)

  repeat
    local i = actor.anim.i

    if i == 4 and actor.vx == 0 then
      actor.vx = .94
    end

    actor.vx *= .89

    if i == #actor.anim.indexes then
      actor.vx = 0
    end

    actor.x += (actor.vx * dir)
    if dir == 1 then
      actor.x = min(actor.x, destx)
    else
      actor.x = max(destx, actor.x)
    end

    yield()
  until actor.x == destx

  note_unsubscribe(sub)
end

function walk_leap(actor, args)
  local walkpattern = args[1]
  local dir = args[2]

  actor:set_flipx(dir == -1)
  actor.anim = actor.anims.pointe

  wait_until({walkpattern, 0})
  actor.anim = actor.anims.pointewalkmanual

  local sub = note_subscribe(
    function (ch, s, n, note, p)
      return p == walkpattern and ch == 1 and note.volume > 0
    end,
    function() actor.anim:update(true) end)
  repeat
    actor.x += (.1 * dir)
    yield()
  until songpos.n >= 15
  note_unsubscribe(sub)

  actor.anim = actor.anims.leap
  actor.anim:reset()
  if actor.flipx then
    actor.x -= 8
  end

  repeat
    local i = actor.anim.i
    if i >= 3 and i <= 5 then
      actor.x += (.3 * dir)
    end
    yield()
  until actor.anim:is_done()

  actor.anim = actor.anims.default
  if actor.flipx then
    actor.x += 8
  end
end

function note_subscribe(filter, callback)
  return add(notesubs, {filter = filter, callback = callback})
end

function note_unsubscribe(sub)
  del(notesubs, sub)
end

function prop_all(t, props)
  for _, item in pairs(t) do
    for k, v in pairs(props) do
      item[k] = v
    end
  end
end

function add_action(actor, start, f, args)
  add(actor.actions,
    function()
      if start then
        wait_until(start)
      end
      f(actor, args)
    end)
end

function init_ballet()
  local y = keyboard_y - 11
  local b1 = new_ballerina(-20, y)
  local b2 = new_ballerina(-10, y)
  local mice1 = {b1, b2}
  for i, b in pairs(mice1) do
    local destx1 = 2 + ((i - 1) * 10)
    local destx2 = 44 + ((i - 1) * 10)

    add_action(b, {14, 15}, walk_tween, {destx1, 14 * 15, 14 * 28})
    add_action(b, {15, 12}, walk_leap, {16, 1})
    add_action(b, {18, 0}, walk_tween, {destx2, 0, 14 * 15})
    add_action(b, {19, (i - 1) * 4}, spin_after_fairy)
  end

  local b3 = new_ballerina(128)
  local b4 = new_ballerina(138)
  local mice2 = {b3, b4}
  prop_all(mice2, {y = y, flipx = true})
  for i, b in pairs(mice2) do
    local destx1 = 108 + ((i - 1) * 10)
    local destx2 = 64 + ((i - 1) * 10)

    add_action(b, {15, 0}, walk_tween, {destx1, 0, 7 * 24})
    add_action(b, {16, 28}, walk_leap, {17, -1})
    add_action(b, {18, 0}, walk_tween, {destx2, 0, 14 * 15, false})
    add_action(b, {19, (i + 1) * 4}, spin_after_fairy, {b == b4})
  end

  local fairy1 = new_ballerina(-8, y)
  kicker = fairy1
  local fairy2 = new_ballerina(128, y)
  fairy2.flipx = true
  prop_all({fairy1, fairy2}, {pal = {[1] = 1, [15] = 12}})
  local start = {18, 0}
  add_action(fairy1, start, fairy_solo, {24, 1})
  add_action(fairy2, start, fairy_solo, {97, -1})

  -- make silly mouse stand up
  add_action(b4, {20, 0}, function()
    set_anim(b4, 'unslump')
  end)

  local catch_up = function(actor, args)
    local other = args[1]
    walk_tween(actor, {other.x + 10, 14 * 20, 14 * 28})
  end

  local everyone = {fairy1, b1, b2, b3, b4, fairy2}
  for b in all(everyone) do
    if b == b4 then
      add_action(b, {20, 1}, walk_leap, {20, -1})
      add_action(b, {20, 20}, catch_up, {b3})
    else
      add_action(b, {19, 28}, walk_leap, {20, -1})
    end

    add_action(b, {20, 28}, walk_leap, {21, 1})
    add_action(b, {21, 24}, set_anim, 'pointe')
    add_action(b, {21, 28}, set_anim, 'default')
  end

  local destx = -8
  local leftgroup = {b2, b1, fairy1}
  for b in all(leftgroup) do
    add_action(b, {22, 0}, walk_tween, {destx, 0, 14 * 28})
    destx -= 10
  end

  local destx = 128
  local rightgroup = {b3, b4, fairy2}
  for b in all(rightgroup) do
    add_action(b, {22, 0}, walk_tween, {destx, 0, 14 * 28})
    destx += 10
  end

  for i, b in pairs({fairy1}) do
    local x = -(10 * 2) + (i * 10)
    add_action(b, {22, 29}, function(actor)
      actor.x = x
      actor.flipx = false
    end)
    add_action(b, {24, 9}, hop_on_beat, {1, headdrop_x - 6})
    add_action(b, {24, 30}, function(actor) actor.readytokick = true end)
    add_action(b, {27, 27}, do_anim, 'turn')
    add_action(b, nil, hop_on_beat, {-1, -28})
  end

  local destx = 40
  for b in all(leftgroup) do
    add_action(b, {35,  0}, function(a, args) a.x = args[1] end, {destx - 50})
    add_action(b, {36,  0}, walk_tween, {destx, 0, 14 * 27})
    add_action(b, {37,  0}, do_anim, 'turn')
    add_action(b, {37, 16}, do_anim, 'turn')
    add_action(b, {37, 24}, set_anim, 'pointe')
    add_action(b, {37, 28}, set_anim, 'default')
    add_action(b, {38,  0}, do_anim, 'hop')
    add_action(b, {38,  4}, do_anim, 'hop')
    add_action(b, {38,  8}, walk_tween, {destx + 10, 14 * 8, 14 * 13})
    destx -= 10
  end

  local destx = 80
  for b in all(rightgroup) do
    add_action(b, {35,  0}, function(a, args) a.x = args[1] end, {destx + 50})
    add_action(b, {36,  0}, walk_tween, {destx, 0, 14 * 27})
    add_action(b, {37,  b == b4 and 10 or 8}, do_anim, 'turn')
    add_action(b, {37, 24}, set_anim, 'pointe')
    add_action(b, {37, 28}, set_anim, 'default')
    add_action(b, {38,  0}, do_anim, 'hop')
    add_action(b, {38,  4}, do_anim, 'hop')
    add_action(b, {38,  8}, walk_tween, {destx - 10, 14 * 8, 14 * 13})
    destx += 10
  end

  local destx = -10
  local runstarts = {19, 16, 18, 17, 16, 14}
  for i, b in pairs(everyone) do
    add_action(b, {38, runstarts[i]}, function(actor)
      actor.anim = actor.anims.pointewalk
      local vx = 0
      while actor.x > destx do
        vx -= .1
        vx = max(-1, vx)
        actor.x += vx
        yield()
      end
    end)
  end
end

function set_anim(actor, animkey)
  actor.anim = actor.anims[animkey]
  actor.anim:reset()
end

function do_anim(actor, animkey)
  actor.anim = actor.anims[animkey]
  actor.anim:reset()
  repeat yield() until actor.anim:is_done()
  actor.anim = actor.anims.default
end

function spin_after_fairy(actor, args)
  local silly = args and args[1]

  set_anim(actor, 'turn')
  if silly then
    actor.anim.timer.length = 2
    actor.anim.loop = true
    while in_song_range({19, 0}, {19, 23}) do
      if actor.x < 120 then
        actor.x += 0.05
      end
      yield()
    end
    actor.anim.loop = false
    set_anim(actor, 'slump')
  else
    repeat yield() until actor.anim:is_done()
    set_anim(actor, 'default')
  end
end

function fairy_solo(actor, args)
  local destx = args[1]
  local dir = args[2]

  for i = 1, 4 do
    actor.anim = actor.anims.pointewalk
    while stat(21) % 8 ~= 0 do
      actor.x += (.17 * dir)
      if dir == -1 then
        actor.x = max(destx, actor.x)
      else
        actor.x = min(actor.x, destx)
      end
      yield()
    end

    set_anim(actor, 'turn')
    repeat
      actor.x += (.17 * dir)
      if dir == -1 then
        actor.x = max(destx, actor.x)
      else
        actor.x = min(actor.x, destx)
      end
      yield()
    until actor.anim:is_done()
  end
  set_anim(actor, 'default')
end

function run_tubamouse()
  repeat
    yield()
  until curtainy <= 64

  tubamouse.anim = tubamouse.anims.run
  while tubamouse.x < tubamouse.targetx do
    local dist = tubamouse.targetx - tubamouse.x
    local vx = dist * .1
    tubamouse.x += min(vx, .5)
    if dist < .5 then
      tubamouse.x = tubamouse.targetx
    end
    yield()
  end
  tubamouse.anim = tubamouse.anims.stand
  wait(fps / 2)
  tubamouse.y -= 6
  tubamouse.anim = tubamouse.anims.default
  tubamouse.hastuba = true
  tuba.visible = false

  wait(fps / 2)
  music(2)

  wait_until({14, 0})
  tubastage = {
    x1 = tubamouse.x + 3,
    y1 = tubamouse.y + 16,
    x2 = tubamouse.x + 14,
    y2 = keyboard_y
  }
  for y = tubamouse.y, tubamouse.y - 14, -.1 do
    tubamouse.y = y
    tubastage.y1 = y + 16
    yield()
  end
  tuba.y = tubamouse.y + 1

  wait_until({38, 24})

  tubamouse.hastuba = false
  tubamouse.anim = tubamouse.anims.run
  tubamouse.y += 6
  tubamouse.flipx = true
  tubamouse.vy = 0
  for x = tubamouse.x, -8, -1 do
    tubamouse.x = x
    if tubamouse.x < tubamouse.targetx - 3 then
      tubamouse.vy += .1
    end
    tubamouse.y += tubamouse.vy
    tubamouse.y = min(tubamouse.y, keyboard_y - 10)
    yield()
  end
end

function run_tuba()
  wait_until({38, 24})
  tuba.visible = true

  wait_until({38, 26})
  tuba.rotate = true
  tuba.x -= 7
  tuba.y += 12

  local ty = tween.new(
    tuba.y, tuba.y + 11,
    songpos.ticks, 14 * 31,
    ease_in_quad)
  repeat
    tuba.y = ty:update(songpos.ticks)
    yield()
  until ty:is_done()
end

function apply_palette(p)
  for k, v in pairs(p) do
    if v == -1 then
      palt(k, true)
    else
      pal(k, v)
    end
  end
end

function run_horse()
  -- enter from left, push tubamouse, exit to right
  wait_until({7, 0})
  move_horse(-40, 128, 1, 14 * 50, function(x)
    if x + horse.w > tubamouse.x then
      tubamouse.x = x + horse.w
    end
  end)

  -- enter from right, put tubamouse back
  wait_until({9, 0})
  move_horse(128 + tubamouse.w, tubamouse.targetx + tubamouse.w, -1, 14 * 15,
    function(x) tubamouse.x = horse.x - tubamouse.w end)

  set_anim(horsemouse1, 'default')
  set_anim(horsemouse2, 'default')
  wait(12)

  -- exit to right
  move_horse(tubamouse.targetx + tubamouse.w, 128, -1, 14 * 31)

  wait_until({30, 0})

  -- enter from left, pulling snowboarder
  snowboarder.hasline = true
  move_horse(-37, 184, 1, 14 * 52, function(x)
    snowboarder.x = x - 24
    add_particle(snowboarder.x + 2, snowboarder.y + 9, -1)
  end)
  snowboarder.hasline = false

  -- snowboarder: do a sick jump from the right
  wait_until({32, 0})
  set_anim(snowboarder, 'fall')
  local vx, vy, maxy, landed = -1, -0.6, keyboard_y - 10, false
  snowboarder.x = 128
  snowboarder.y = 21
  while snowboarder.x > -32 do
    vy += .09
    snowboarder.x += vx
    snowboarder.y += vy
    if snowboarder.y >= maxy then
      snowboarder.y = maxy
      landed = true
    end
    if snowboarder.x <= 47 then
      snowboarder.anim = snowboarder.anims.default
      snowboarder.flipx = true
      snowboarder.y = maxy + 1
    end
    if landed then
      add_particle(snowboarder.x + 5, snowboarder.y + 9, 1)
    end
    yield()
  end
end

function add_particle(x, y, vx)
    add(particles, {
      x = x,
      y = y,
      vx = vx,
      vy = -(rnd_int(1, 10) / 10),
      ttl = fps * 2
    })
end

function move_horse(src, dst, dir, tickdst, callback)
  local flipx = dir == -1

  horse.flipx = flipx
  horsemouse1.flipx = flipx
  horsemouse2.flipx = flipx
  horsemouse1.offsetx = flipx and 15 or 17
  horsemouse2.offsetx = flipx and 7 or 25
  horse.x = src

  set_anim(horsemouse1, 'run')
  set_anim(horsemouse2, 'run')
  horsemouse2.anim:update(true)

  local wrappedcallback = function(x)
    horsemouse2.x = x + horsemouse2.offsetx
    horsemouse1.x = x + horsemouse1.offsetx
    if callback then
      callback(x)
    end
  end

  move_to_target(horse, 'x', dst, tickdst, ease_linear, wrappedcallback)
end

function move_to_target(actor, axis, target, tickdst, easefunc, callback)
  local t = tween.new(actor[axis], target, songpos.ticks, tickdst, easefunc)
  local startpat = songpos.pat
  repeat
    local ticks = songpos.ticks
    if songpos.pat > startpat then
      ticks += (14 * 32)
    end

    local v = t:update(ticks)

    actor[axis] = v
    if callback then
      callback(v)
    end
    yield()
  until t:is_done()
end

function init_bell_ringers()
  local h = 16
  local positions = {
    {x = -18, targetx =   3, y = 45, dir =  1, pitch = 36},
    {x = 130, targetx = 109, y = 45, dir = -1, pitch = 41},
    {x = -18, targetx =   3, y = 13, dir =  1, pitch = 43},
    {x = 130, targetx = 109, y = 13, dir = -1, pitch = 48},
    {
      x = 50,
      targetx = 50,
      y = -h * 2,
      targety = top_platform_y - h,
      dir = 1,
      pitch = 53
    }
  }

  local cr = function(ringer)
    local waitoffset = flr(((ringer.pitch - 36) / 17) * 4)
    for pat in all({10, 33}) do
      wait_until({pat - 1, 20 - waitoffset})

      -- move out to target position
      set_anim(ringer, 'run')
      local oldx = ringer.x
      move_to_target(ringer, 'x', ringer.targetx, 14 * (28 - waitoffset),
        ease_out_quad)
      ringer.anim = ringer.anims.default
      wait_until({pat + 1, 8 + waitoffset})

      -- go back offscreen
      set_anim(ringer, 'run')
      move_to_target(ringer, 'x', oldx, 14 * (16 + waitoffset), ease_in_quad)
    end
  end

  local cr5 = function(ringer)
    local inity, i = ringer.y, 1
    for pat in all({10, 33}) do
      wait_until({pat, 14})

      local vy = 0
      while ringer.y < ringer.targety do
        vy += .04
        ringer.y += vy
        ringer.y = min(ringer.y, ringer.targety)
        yield()
      end

      if i == 2 then
        wait_until({38, 3})
      else
        wait_until({pat + 2, 28})
      end

      -- jump up
      local vx, vy = 0, -1.8
      if i == 2 then
        -- jump away from cat
        set_anim(ringer, 'run')
        vx = -0.3
        vy = -.85
        ringer.x -= 5
        ringer.flipx = true
      end
      while ringer.y > -16 do
        vy += .04
        ringer.x += vx
        ringer.y += vy
        yield()
      end

      ringer.y = inity
      i += 1
    end
  end

  for i, pos in pairs(positions) do
    local dir = pos.dir

    local belloffsetx = 10 * dir
    if dir == -1 then
      belloffsetx += 8
    end
    local belly = pos.targety and pos.targety + 4 or pos.y + 3
    local bell = new_bell(pos.targetx + belloffsetx, belly)
    if i == 5 then
      fallingbell = bell
    end
    bell.flipx = dir == -1

    local ringer = new_ringer(pos.x, pos.y)
    add_props(ringer, pos)
    ringer.flipx = dir == -1

    if i == 5 then
      add(ringer.actions, function() cr5(ringer) end)
    else
      add(ringer.actions, function() cr(ringer) end)
    end

    local ringfunc = function()
      set_anim(bell, 'ring')
      set_anim(ringer, 'ring')
    end

    note_subscribe(
      function(ch, s, n, note, p)
        return (p == 10 or p == 33) and ch == 1
           and note.volume > 0 and note.pitch == pos.pitch
           and note.effect ~= 2
      end,
      ringfunc)

    if i == 5 then
      note_subscribe(
        function(ch, s, n, note, p)
          return (p == 11 or p == 34) and n == 0
        end,
        ringfunc)
    end
  end
end

function init_bigringers()
  local cr = function(m)
    local exitdir = -m.dir
    local initial = {x = m.x, dir = m.dir, flipx = m.flipx, firstring = true}

    for pat in all({10, 33}) do
      add_props(m, initial)
      wait_until({pat, 0})

      -- move out to target position
      m.anim = m.anims.walk
      move_to_target(m, 'x', m.targetx, 9 * 14, ease_out_quad)

      m.anim = m.anims.default
      wait_until({pat + 1, 8})

      -- failsafe: turn in correct direction even if ringing was skipped
      m.dir = exitdir
      m:set_flipx(exitdir == -1)

      -- go back offscreen
      m.anim = m.anims.walk
      if m.dir == -1 then
        m.x += 8
      end
      local tickdst = (16 * 14) + (dir == -1 and 2 or 0)
      move_to_target(m, 'x', initial.x, tickdst, ease_in_quad)
    end
  end

  local trigger1 = function(ch, s, n, note, p)
    return (p == 10 or p == 33) and ch == 2
      and note.pitch == 51 and note.effect ~= 2
  end
  local trigger2 = function(ch, s, n, note)
    return s == 37 and (n == 0 or n == 2)
  end

  local br1 = new_bigringer(-16, 79)
  br1.targetx = 14
  br1.dir = 1
  br1.flipx = false
  local br2 = new_bigringer(128, 79)
  br2.targetx = 98
  br2.dir = -1
  br2.flipx = true
  local bigringers = {br1, br2}
  for br in all(bigringers) do
    add(br.actions, function() cr(br) end)

    br.firstring = true

    br.set_flipx = function(self, flipx)
      if self.flipx ~= flipx then
        self.flipx = flipx
        self.x += (15 * (self.flipx and -1 or 1))
      end
    end

    br.ringfunc = function()
      set_anim(br, 'ring')
      if br.firstring then
        if br.dir == -1 then
          br.x -= 8
        end
      else
        br:set_flipx(not br.flipx)
      end
      br.firstring = false
    end
  end

  note_subscribe(trigger1, br1.ringfunc)
  note_subscribe(trigger2, br2.ringfunc)
end

function add_props(t, props)
  for k, v in pairs(props) do
    t[k] = v
  end
end

function _update60()
  poll_songpos()
  for ch = 0, 3 do
    detect_note_starts(ch)
  end

  for cr in all(coroutines) do
    if costatus(cr) ~= 'dead' then
      assert(coresume(cr))
    else
      del(coroutines, cr)
    end
  end

  update_tuba()

  erase_things_for_snow()
  update_snow()
  update_particles()

  for _, a in pairs(actors) do
    a.anim:update()
  end

  update_rope(rope)

  update_titles()

  if stat(24) <= 0 and curtainy >= keyboard_y / 2 then
    if lightstimer:update() then
      lightstimer:reset()
      lightsn += 1
      lightsn %= 32
      change_lights(lightsn)
    end
  end
end

function erase_things_for_snow()
  rectfill(20, 15, 107, 40, 0) -- xmas lights
  pset(59, tubamouse.y + 7, 0) -- below hat pom
  draw_top_platform()
end

function draw_top_platform()
  spr(172, 48, top_platform_y - 5)
  spr(53, 56, top_platform_y - 5)
end

function new_rope()
  local nodes = {}

  local count = 20
  local x1 = 20
  local x2 = 108
  local x, y = x1, 15
  for i = 1, count do
    add(nodes,
      {
        x = x,
        y = y,
        vx = 0,
        vy = 0,
        light = {}
      })
    x += (x2 - x1) / (count - 1)
  end

  local light_colors = {8, 10, 11, 12, 14}
  local ci = 1
  local on = true
  local mod = 4
  for i = 2, #nodes do
    if i % 1 == 0 then
      on = not on
    end

    nodes[i].prv = nodes[i - 1]
    if i + 1 <= #nodes then
      nodes[i].nxt = nodes[i + 1]
    end
    nodes[i].light = {
      c = light_colors[ci],
      on = on,
      mod = mod
    }

    ci += 1
    if ci > #light_colors then
      ci = 1
    end

    if i % 2 == 0 then
      mod += 4
      if mod > 8 then
        mod = 4
      end
    end
  end

  nodes[#nodes].nxt = nodes[#nodes]
  nodes[#nodes].fixed = true

  return nodes
end

function update_rope(rope)
  for i = 2, #rope do
    local node = rope[i]
    if not node.fixed then
      local target = {
        x = node.prv.x + (node.nxt.x - node.prv.x) / 2,
        y = node.prv.y + (node.nxt.y - node.prv.y) / 2
      }
      local dx = (target.x - node.x) * rope_tightness
      local dy = (target.y - node.y) * rope_tightness

      dx -= (node.vx * rope_damping)
      dy -= (node.vy * rope_damping)

      node.vx += dx
      node.vy += dy

      node.vy += rope_gravity

      node.x += node.vx
      node.y += node.vy
    end
  end
end

function draw_rope()
  for i = 1, #rope - 1 do
    local a = rope[i]
    local b = rope[i + 1]

    line(a.x, a.y, b.x, b.y, 3)

    if i > 1 then
      circfill(a.x, a.y + 2, 1, a.light.on and a.light.c or 1)
    end
  end
end

function update_tuba()
  tubamouse.blowbox = {
    x = tubamouse.x + 4,
    y = tubamouse.y - 14,
    w = 13,
    h = 16
  }
  if tubamouse.anim.i == 3 or tubamouse.anim ~= tubamouse.anims.play then
    tubaisblowing = false
  end
end

function _draw()
  cls()

  for _, s in pairs(snowflakes) do
    pset(flr(s.x), flr(s.y), s.c)
  end

  if tubastage then
    fillp(stripe_fill[flr(tubastage.y1 % 4) + 1])
    rectfill(tubastage.x1, tubastage.y1, tubastage.x2, tubastage.y2, 0xd1)
    fillp()
    map(16, 0, tubastage.x1 - 6, tubastage.y1 - 5, 3, 1)
  end

  map(0, 0, 0, 0, 64, 64)
  draw_top_platform()
  draw_keyboard()
  draw_switchers()

  for _, p in pairs(particles) do
    pset(p.x, p.y, 7)
  end

  for i = 1, #actors do
    draw_actor(actors[i])
  end

  if snowboarder.hasline then
    line(snowboarder.x + 7, snowboarder.y + 4, horse.x - 1, horse.y + 5, 12)
  end

  if tuba.visible then
    draw_tuba()
  end

  draw_cat()
  draw_rope()
  draw_curtain()
  draw_titles()
end

function update_particles()
  for _, p in pairs(particles) do
    p.ttl -= 1
    if p.ttl <= 0 then
      del(particles, p)
    else
      p.vy += .05
      p.vx *= .99

      p.x += p.vx
      p.y += p.vy
    end
  end
end

function draw_switchers()
  if not keyboardon then
    spr(188, 24, 96)
  end

  for i = 1, 2 do
    local xo, yo = 0, 0
    if i == 1 then
      for c = 1, 15 do
        pal(c, 5)
      end
      xo, yo = -2, -1
    end

    for s in all(switchers) do
      if i == 2 then
        if s[6] then
          pal(15, 12)
        end
        pal(1, s[6] and 1 or 0)
      end
      spr(s[3], s[1] + xo, switcher.y + s[2] + yo, s[4] or 1, s[5] or 1)
    end
    pal()
  end
end

function draw_tuba()
  pal(2, 7)
  if tuba.rotate then
    draw_rot_90_ccw(tuba.sx, tuba.sy, tuba.sw, tuba.sh, tuba.x, tuba.y,
      tuba.palt)
  else
    for _, c in pairs(tuba.palt) do
      palt(c, true)
    end
    sspr(tuba.sx, tuba.sy, tuba.sw, tuba.sh, tuba.x, tuba.y)
  end
  pal()
end

function run_switchers()
  wait_until({2, 0})
  move_to_target(switcher, 'y', 93, 14 * 20, ease_out_quad)

  wait_until({2, 24})
  switchers[1][3] = 103
  keyboardon = true
  sfx(7, 3, 31)
  wait(5)
  switchers[1][3] = 101

  move_to_target(switcher, 'y', 128, 14 * 40, ease_in_quad)
end

function run_fallingbell()
  wait_until({38, 6})

  local vx, vy, maxy = -.6, 0, top_platform_y - 6

  while fallingbell.y < maxy do
    vy += .2
    vy = min(vy, 2)

    fallingbell.x += vx
    fallingbell.y += vy
    fallingbell.y = min(fallingbell.y, maxy)

    yield()
  end
end

function run_cat()
  wait_until({38, 0})

  -- extend a little
  move_cat_arm(
    57, 61,
    -16, 7,
    14 * 2, 14 * 4, ease_out_quad)

  -- retract
  move_cat_arm(
    cat.pawx, 60,
    cat.pawy, -16,
    songpos.ticks, 14 * 8, ease_in_quad)

  -- go out farther
  move_cat_arm(
    79, 86,
    -16, 23,
    14 * 11, 14 * 15, ease_out_quad)

  -- make lights fall
  rope[#rope].fixed = false
  rope_gravity *= 2
  rope_tightness *= 1.2

  -- retract quickly
  move_cat_arm(
    cat.pawx, 94,
    cat.pawy, -32,
    songpos.ticks, 14 * 18, ease_in_quad)

  -- go out one last time
  move_cat_arm(
    cat.pawx, 74,
    -16, 23,
    14 * 24, 14 * 30, ease_out_quad)
end

function move_cat_arm(xsrc, xdst, ysrc, ydst, ticksrc, tickdst, easefunc)
  local tx = tween.new(xsrc, xdst, ticksrc, tickdst, easefunc)
  local ty = tween.new(ysrc, ydst, ticksrc, tickdst, easefunc)
  repeat
    cat.pawx = tx:update(songpos.ticks)
    cat.pawy = ty:update(songpos.ticks)
    yield()
  until tx:is_done()
end

function draw_cat()
  -- draw arm extension
  local sh = 3
  for y = cat.pawy - (sh * 10), cat.pawy - 1, sh do
    sspr(115, 29, 9, sh, cat.pawx + 3, y, 9, sh, false, true)
  end

  -- draw paw
  sspr(112, 16, 16, 16, cat.pawx, cat.pawy, 16, 16, false, true)
end

function draw_keyboard()
  palt(0, false)
  palt(4, true)

  rectfill(1, keyboard_y, 126, keyboard_y, 6)
  pset(21, keyboard_y, 13)
  pset(89, keyboard_y, 13)
  sspr(0, 96, 128, 127, 0, keyboard_y + 1)
  sspr(22, 104, 42, 24, 64, 104) -- dup. some keys to cover up other sprites

  palt()

  for _, note in pairs(melodynotes) do
    if note and note.pitch then
      draw_key(note)
    end
  end
end

function move_curtain(vd)
  local vy = 0
  repeat
    vy += vd
    vy = mid(-1, vy, 1.5)
    curtainy += vy
    curtainy = mid(curtain_min_y, curtainy, curtain_max_y)
    yield()
  until curtainy == curtain_min_y or curtainy == curtain_max_y
end

function fadeout_titles(waitlen, skippostwait)
  wait(waitlen * fps, true)
  prop_all(titles, {d = -.1})
  if not skippostwait then
    wait(fps * .5)
  end
end

function run_curtain()
  wait(fps * .66)
  local t = add_title({'', '',
    'kittenm4ster',
    '',
    'in association with',
    'the pico-8 advent project',
    '',
    'presents...'})
  t.logo = true
  fadeout_titles(6)

  add_title({
    'not a creature was stirring',
    '',
    '',
    '', '', '', ''})
  wait(fps * 4, true)
  add_title({
    '',
    '',
    '(...except squeaky whiskerson',
    'and his',
    'marvelous musical mice!)',
    '',
    '♪⌂♪   ',
  })

  fadeout_titles(6, true)
  move_curtain(-0.1)

  wait_until({38, 26})
  move_curtain(.15)
  wait(fps * .75)

  add_title({'the end'})
  fadeout_titles(6)

  add_title({
    'made by andrew anderson',
    'for the pico-8 advent project',
    '2018-12-07',
    '',
    'with choreography assistance',
    'from',
    'aubrianne anderson',
  })
  fadeout_titles(12)

  add_title({
    'music adapted from',
    '"sleigh ride"',
    'composed by leroy anderson',
    'in 1948'})
  fadeout_titles(10)

  add_title({
    'squeaky whiskerson',
    'would like to thank',
    'whoever left the',
    'old keyboard in the attic'
  })
  fadeout_titles(12)

  add_title({'merry xmas!'})
end

function draw_curtain()
  if curtainy >= -33 then
    local i = 0
    for x = 0, 127, 8 do
      local offsety = 0
      offsety = ceil((x + 1) / 8) * 2

      local maxy = keyboard_y - 7
      maxy += ((i % 2 == 0) and 1 or 0)

      for y = ((curtainy + offsety - 127) % 8) - 8, curtainy + offsety, 8 do
        spr(189, x, min(y, maxy))
      end
      i += 1
    end
  end
end

function draw_key(note)
  local i = note.pitch - 24
  if in_song_range({17, 30}, {19, 21}) or in_song_range({21, 30}, {23, 1}) then
    i += 12
  end
  if note.ch == 1 and (in_song_range({19, 23}, {19, 31})
      or in_song_range({38, 26}, {38, 29})) then
    -- don't draw silly slide notes
    return
  end
  if in_song_range({24, 0}, {26, 0}) then
     i -= 12
  end

  i %= key_count

  local key = key_pos_type[i]
  local keytype = key[2]
  local x = key[1]
  local y = keyboard_y + 12
  local w = keytype == 4 and 4 or 5
  local h = 20
  local sx = key_sx[keytype]

  sspr(sx, 64, w, h, x, y)
end

function in_song_range(a, b)
  if ((songpos.pat == a[1] and songpos.n >= a[2]) or songpos.pat > a[1]) and
     (songpos.pat < b[1] or (songpos.pat == b[1] and songpos.n <= b[2])) then
    return true
  end
end

function draw_actor(actor)
  pal(1, 0)

  if actor.pal then
    apply_palette(actor.pal)
  end

  local s = actor.anim:get_index()
  local offsetx = actor.anim:get_offset()
  if actor.flipx then
    offsetx *= -1
  end
  local sw, sh = actor.anim:get_size()
  if actor.flipx and sw ~= actor.anim.w then
    offsetx += 8 * (actor.anim.w - sw)
  end

  spr(
    s,
    actor.x + offsetx,
    actor.y,
    sw,
    sh,
    actor.flipx)
  pal()
end

function detect_note_starts(ch)
  local n = stat(20 + ch) -- note index
  if n ~= channelnote[ch] then
    -- <= 31 is to compensate for bug where faster patterns overflow
    if n >= 0 and n <= 31 then
      local s = stat(16 + ch) -- sfx index
      if s ~= -1 then
        local note = get_note(s, n)
        note_started(ch, s, n, note)
        channelnote[ch] = n
      end
    elseif ch > 0 then
      melodynotes[ch] = nil
    end
  end
end

-- @param ch channel index
-- @param s sfx index
-- @param n note index
-- @param note note object
function note_started(ch, s, n, note)
  for _, sub in pairs(notesubs) do
    if sub.filter(ch, s, n, note, songpos.pat) then
      sub.callback()
    end
  end

  if note.instrument == 2 and not note.issfxinst and note.volume > 0
     and tubamouse.hastuba then
    set_anim(tubamouse, 'play')
    tubaisblowing = true
  end

  if note.instrument == 7 and note.issfxinst and note.volume > 0 then
    if n % 2 == 0 then
      horse.anim:update(true)
    end
  end

  if ch == 1 or (ch > 0 and songpos.pat >= 15 and songpos.pat <= 21) then
    if note.instrument == 1 and note.volume > 0 then
      note.ch = ch
      melodynotes[ch] = note
    else
      melodynotes[ch] = nil
    end
  end

  if ch == 1 then
    change_lights(n)
  end
end

function change_lights(n)
  for i = 2, #rope - 1 do
    local node = rope[i]
    if n % node.light.mod == 0 then
      node.light.on = not node.light.on
    end
  end
end

function get_note(sfx, n)
  local addr = 0x3200 + (68 * sfx) + (2 * n)
  local byte1 = peek(addr)
  local byte2 = peek(addr + 1)
  local inst_r = shr(band(byte1, 0b11000000), 6)
  local inst_l = shl(band(byte2, 0b00000001), 2)

  return {
    addr = addr,
    byte1 = byte1,
    byte2 = byte2,
    pitch = band(byte1, 0b00111111),
    volume = shr(band(byte2, 0b00001110), 1),
    effect = shr(band(byte2, 0b01110000), 4),
    instrument = bor(inst_l, inst_r),
    issfxinst = band(byte2, 0b10000000) > 0
  }
end

function init_snowflake(s)
  s.y = 0
  s.x = rnd_int(0, 127)
  s.w = 1
  s.h = 1
  s.vx = rnd_int(1, 3) / 12
  if rnd_int(0, 1) == 1 then
    s.vx *= -1
  end
  s.vy = rnd_int(3, 8) / 10
  s.maxv = rnd_int(2, 9) / 10
  s.c = rnd_choice({5, 7, 7})
  s.collidable = (s.c == 7)
  s.landed = false
end

function snow_hit(c)
  return c ~= 0 and c ~= 7 and c ~= 5
end

function update_snow()
  for _, s in pairs(snowflakes) do
    local ignorehits = false
    if  curtainy >= s.y - 32 then
      ignorehits = true
    end

    if s.collidable and not ignorehits and
       snow_hit(pget(flr(s.x), flr(s.y))) then
      s.ttl = 0
    end

    if s.landed and s.ttl <= 0 then
      init_snowflake(s)
    end

    s.vy += .05

    local hit = false
    if s.collidable and not ignorehits then
      local cx = pget(flr(s.x + s.vx), flr(s.y))
      local cy = pget(flr(s.x), flr(s.y + s.vy))
      hit = snow_hit(cx) or snow_hit(cy)
    end

    if (hit or s.y > 125) then
      s.y = flr(s.y)
      s.vx = 0
      s.vy = 0

      if not s.landed then
        s.landed = true
        s.ttl = rnd_int(fps, fps * 4)
        if flr(s.y) == keyboard_y - 1 then
          s.ttl = fps
        end
      end
    end

    if s.landed then
      s.ttl -= 1
    end

    if tubaisblowing then
      if overlap(s, tubamouse.blowbox) then
        local dist = max(1, tubamouse.blowbox.y + tubamouse.blowbox.h - s.y)
        s.vy -= (1.2 / dist)
        local xdir = (s.x < tubamouse.blowbox.x + 6 and -1 or 1)
        s.vx += rnd(2) * (.1 / dist) * xdir
      end
    end

    s.vy = mid(-s.maxv, s.vy, s.maxv)
    s.vx = mid(-s.maxv, s.vx, s.maxv)

    s.x += s.vx
    s.y += s.vy
  end
end

function overlap(a, b)
  return (a.x + a.w > b.x
    and a.x < b.x + b.w
    and a.y + a.h > b.y
    and a.y < b.y + b.h)
end

function add_title(lines)
  return add(titles, {lines = lines, v = 0, d = .05})
end

function update_titles()
  for _, t in pairs(titles) do
    t.v += t.d
    t.v = mid(0, t.v, 1)
    if t.v == 0 then
      del(titles, t)
    end
  end
end

function fade(v)
  for c = 0, 15 do
    pal(c, get_fade_col(c, v))
  end
end

function get_fade_col(c, v)
  local i = flr(v * title_fade_len) + 1
  if i < title_fade_len and title_fade_table[c] then
    return title_fade_table[c][i]
  end

  return c
end

function draw_logo(fadev)
  local x, y, bg = 58, 9, get_fade_col(0, fadev)

  -- draw black border/background
  for c = 0, 15 do
    pal(c, bg)
  end
  for a = -1, 1 do
    for b = -1, 1 do
      spr(232, x + a, y + b, 2, 2)
    end
  end
  pal()

  fade(fadev)
  spr(232, x, y, 2, 2)
  pal()
end

function draw_titles()
  for t in all(titles) do
    local y = ((keyboard_y / 2) - ((#t.lines * 8) / 2))

    if t.logo then
      draw_logo(t.v)
    end

    fade(t.v)
    for line in all(t.lines) do
      cprint(line, 64, y, 7, 0)
      y += 8
    end
    pal()
  end
end

-- animation class
anim = {}
anim.__index = anim

function anim.new(w, h, indexes, delay, loop, indexwh, indexoffset)
  local obj = {
    indexes = indexes,
    i = 1,
    timer = timer.new(delay),
    loop = loop or false,
    w = w,
    h = h,
    indexwh = indexwh or {},
    indexoffset = indexoffset or {}
  }

  setmetatable(obj, anim)
  return obj
end

function anim:update(force)
  if self.timer:update() or force then
    self.timer:reset()

    if self.i < #self.indexes then
      self.i += 1
    elseif self.loop then
      self:reset()
    end
  end
end

function anim:get_index()
  return self.indexes[self.i]
end

function anim:get_offset()
  return self.indexoffset[self:get_index()] or 0
end

function anim:get_size()
  local wh = self.indexwh[self:get_index()]
  if wh then
    return wh[1], wh[2] or self.h
  end

  return self.w, self.h
end

function anim:reset()
  self.i = 1
  self.timer:reset()
end

function anim:is_done()
  return (self.i == #self.indexes and self.timer.value == 1)
end

-- timer class
timer = {}
timer.__index = timer
function timer.new(frames)
  local obj = {
    length = frames,
    value = frames
  }

  setmetatable(obj, timer)
  return obj
end

function timer:reset()
  self.value = self.length
end

function timer:update()
  if self.value > 1 then
    self.value -= 1
  else
    return true
  end
end

-- tween class
tween = {}
tween.__index = tween

function tween.new(src, dst, ticksrc, tickdst, func)
  local obj = {
    src = src,
    dst = dst,
    val = src,
    ticksrc = ticksrc,
    tickdst = tickdst,
    ticktotal = tickdst - ticksrc,
    func = func
  }

  setmetatable(obj, tween)
  return obj
end

function tween:is_done(ticks)
  return self.val == self.dst
end

function tween:update(ticks)
  ticks = mid(0, ticks - self.ticksrc, self.ticktotal)
  self.val = self.func(ticks, self.src, self.dst - self.src, self.ticktotal)

  return self.val
end

function rnd_int(min, max)
  return flr(rnd((max + 1) - min)) + min
end

function rnd_choice(t)
  return t[flr(rnd(#t)) + 1]
end

function cprint(s, x, y, c, b)
  local w = max(0, (#s * 4) - 1)
  bprint(s, x - flr(w / 2), y, c, b)
end

function table_has_value(t, value)
  for _, v in pairs(t) do
    if v == value then
      return true
    end
  end
end

function draw_rot_90_ccw(sx, sy, sw, sh, dx, dy, skipcolors)
  for y = sy, sy + sh - 1 do
    for x = sx, sx + sw - 1 do
      local c = sget(x, y)
      if c ~= 0 and not table_has_value(skipcolors, c) then
        pset(dx + y - sy, dy - x - sx + (sw * 2), c)
      end
    end
  end
end

function bprint(s, x, y, c, b)
  for yo = -1, 1 do
    for xo = -1, 1 do
      if not (yo == 0 and xo == 0) then
        print(s, x + xo, y + yo, b)
      end
    end
  end
  print(s, x, y, c)
end
