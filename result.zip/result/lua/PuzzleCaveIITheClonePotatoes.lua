--puzzle cave - episode ii
--the clone potatoes
--a game by hackefuffel
--written by christoph 'gizmo' muetze and rick 'gideon' shaikh
--copyright hackefuffel 2015
--version 1.3.1
--2016-05-22

--flags
--1   = visible
--2   = blocking
--4   = key
--8   = jewel
--16  = potato
--32  = stone
--64  = plasma
--128 = blinking star

ts=0
tm=0
th=0
dt=0
cs=8
fs=4
cl=1
st=0
ctrl=0
pc=0
atk=0
door=2
key=3
death=0
reset=0
pushes=0
steps=0
leveltime=0
totaltime=0
logic={}
title={}
intro={}
outro={}
bonus={}
level={}
bunny={}
enemy={}
water={}
stone={}
stars={}
space={}
state={}
stats={}
story={}
state[1]=title
state[2]=intro
state[3]=level
state[4]=story
state[5]=outro
state[6]=stats

function space:init()  
  self.stars = {}
  for i = 1, 60 do
    local star = {}
    star.x = flr(rnd(128))
    star.y = flr(rnd(55)+58)
    star.f = 0
    star.s = flr(rnd(5))+1
    add(self.stars, star)
  end
  for i = 1, 30 do
    local star = {}
    star.x = flr(rnd(128))
    star.y = flr(rnd(55)+58)
    star.f = 1
    star.s = flr(rnd(10))+1
    add(self.stars, star)
  end
end

function space:update()
  for star in all(self.stars) do
    if star.x < 0 then
      star.x = flr(rnd(128))+130
      star.y = flr(rnd(55)+58)
      if (star.f == 0) then
        star.s = flr(rnd(5))+1
      elseif (star.f == 1) then
        star.s = flr(rnd(10))+1
      end
    else      
      star.x = star.x - star.s
    end
  end
end

function space:draw()
  for star in all(self.stars) do
    local a = flr(star.s/4)
    if (star.f == 0) then    
      line(star.x, star.y, star.x+a, star.y, 1)  
    elseif (star.f == 1) then      
      line(star.x, star.y, star.x+a, star.y, 12)    
    end
  end  
end

function stats:init()
  sfx(7,1)
end

function stats:update()  
end

function stats:draw()
  cls()
  print("congratulations",33,5,2)
  print("bunny hops",5,30,12)
  print(steps,120-(#(""..steps)*4),30,11)
  print("times reset",5,45,12)
  print(reset,120-(#(""..reset)*4),45,11)
  print("times fried",5,60,12)
  print(death,120-(#(""..death)*4),60,11)
  print("times pushed",5,75,12)
  print(pushes,120-(#(""..pushes)*4),75,11)  
  local hr=""
  local min=""
	local sec=""
	if (ts<10) sec="0"
	if (tm<10) min="0"
	if (th<10) hr="0"
	print("total time:",5, 90, 12)
	print(hr..th..":"..min..tm..":"..sec..ts, 88, 90, 11)
	if dt<15 then
    print("make a snapshot", 35, 115, 7)
  else
    print("post it to the forums!", 20, 115, 2)
  end
end

function story:init()
  story.go = false
  story.char = 1
  story.chars = 0
  story.lines = {}  
  if (cl == 3) then
    add(story.lines, "pinkbunny!? don't you dare")
    add(story.lines, "enter my lair!")
    add(story.lines, "")
    add(story.lines, "give up! you'll never get")
    add(story.lines, "the potato cloner back!")
    add(story.lines, "you can't escape this maze")
    add(story.lines, "so... stay a while.")
    add(story.lines, "stay forevaaaaa..hahaha!")    
  end  
  if (cl == 7) then
    add(story.lines, "aaahhrgggg...how did you..")
    add(story.lines, "...damn you pinkbunny!")
    add(story.lines, "i really... well... 'hate'")
    add(story.lines, "is such a strong word.")
    add(story.lines, "i just want you to be...")
    add(story.lines, "well, 'dead' would be")
    add(story.lines, "kinda harsh, i think...")
    add(story.lines, "...uhm. just forget it!")
  end  
  if (cl == 9) then
    add(story.lines, "you are seriously trying,")
    add(story.lines, "i'll give you that.")
    add(story.lines, "and your efforts will be")
    add(story.lines, "rewarded... with... ")
    add(story.lines, "death!!! d'ya hear me?!")
    add(story.lines, "death!! die! die die die!!")
    add(story.lines, "")
    add(story.lines, "go, my minions! get him!!")
  end
  if (cl == 15) then
    add(story.lines, "what!? you are still")
    add(story.lines, "alive? inconceivable!")
    add(story.lines, "well well...")
    add(story.lines, "no time for delays...")
    add(story.lines, "my plans are progressing")
    add(story.lines, "quite nicely! prepare to..")
    add(story.lines, "")
    add(story.lines, "fryyyyyyyyy!! nyahahahaaa!")
  end  
  if (cl == 16) then
    add(story.lines, "ok.. enough!")
    add(story.lines, "")
    add(story.lines, "look deeeeep into my eyes.")
    add(story.lines, "relax, breathe deeply!")
    add(story.lines, "")
    add(story.lines, "you don't see any walls,")
    add(story.lines, "there 'are' no walls!!")
  end     
  sfx(13,1)
end

function story:update()
  if dt % 2 == 0 then
    self.char += 1
  end  
  if (self.go and ctrl==0 and btn(5)) then
	  ctrl=fs
	  state:set(3)
	end
end

function story:draw()
  cls()  
  if flr(rnd(100)) == 1 then    
    sspr(80,48,16,8,52,5,32,16)
  else
    sspr(96,40,16,8,52,5,32,16)    
  end
  rect(10,50,118,110,1)  
  rect(51,4,84,37,1)  
  rectfill(10,43,60,49,1)
  print("dr. eyevil",16,44,0)
  local i = 0
  local offset = 0
  for txt in all(self.lines) do
    if (offset == 56) then
      for d = 1, 8 do
        del(self.lines, self.lines[1])
      end
      self.char = 1
      self.chars = 0
      break
    end
    i = i + #txt
    if (self.char > i) then
      print(txt, 13, 53+offset, 12)
      offset = offset + 7
      self.chars = i
      sspr(96,48,16,8,52,21,32,16)
    else
      local c = sub(txt, self.char-self.chars, self.char-self.chars)
      if (c == "a" or c == "i" or c == "u" or c == "e" or c == "o") then        
        sspr(112,48,16,8,52,21,32,16)
      elseif (c == "b" or c == "c" or c == "d" or c == "f" or c == "g"
          or c == "n" or c == "p" or c == "u" or c == "v" or c == "z") then        
        sspr(112,40,16,8,52,21,32,16)
      elseif (c == "h" or c == "j" or c == "k" or c == "l" or c == "m" 
          or c == "q" or c == "r" or c == "s" or c == "t" or c == "w"
          or c == "x" or c == "y") then
        sspr(112,56,16,8,52,21,32,16)
      else        
        sspr(112,32,16,8,52,21,32,16)
      end
      print(sub(txt, 1, self.char-self.chars), 13, 53+offset, 12)      
      break
    end
  end
  if (offset/7 == #self.lines) then
    sfx(15,1)
    self.go = true
    if dt<15 then
      print("press x to continue", 26, 115, 11)
    end
  end
end

function title:init()
  level:init()
  space:init()
end

function title:update()
	if (ctrl==0 and btn(5)) then
	  ctrl=fs
	  state:set(2)
	end
	bunny:update()
	space:update()
	stars:update()
end

function title:draw()
  cls()
  space:draw()
  for y = 1,15 do
		for x = 0,15 do
			local c = lvl[y][x]
			local flag = fget(c)
			if (band(flag,1) == 1) then
				spr(c,x*cs,y*cs)
			elseif not (x==bunny.x and y==bunny.y and bunny.d==0) and c ~= 24 then
				spr(34,x*cs,y*cs)
			end
		end
	end
	bunny:draw()
	stars:draw()
	print("episode 2",44,25,11)
	print("a pico-8 game by",32,60,1)
	spr(48,35,70,8,1,false)
	line(36,78,90,78,7)
	if dt<15 then
		print("press x button to play",18,95,12)
	end
	print("v1.3 2015 - www.hackefuffel.com",4,118,1)
end

function intro:update()
	if (ctrl==0 and btn(5)) then
	  cl=2
		ctrl=fs
		state:set(3)
	end
end

function intro:draw()
	cls()
	print("pinkbunny's arch nemesis", 15, 10, 12)
	print("dr eyevil stole the potato", 11, 17, 12)
  print("cloner and escaped to his ", 13, 24, 12)
  print("space station hideout.", 21, 31, 12)
  print("help pinkbunny to clear", 17, 38, 12)
  print("all 15 levels and beat", 19, 45, 12)
  print("dr eyevil!", 44, 52, 12)
  print("good luck!", 44, 70, 11)
	--print("<insert amazing intro here>",10,60,8)	
	if dt<=15 then
		print("press x to continue",27,110,12)
	end	
end

function outro:init()
  cl=18
	ctrl=-1
	self.p=0
	self.t=0
	level:init()
	sfx(9,1)
end

function outro:update()  
  self.t += 1
	stars:update()
	if (self.p == 0 and self.t/30 > 3) then
	  self.doc = {}	  
	  self.doc.x = -10
	  self.doc.y = 80
	  self.doc.f = 35
	  self.p = 1
	  self.t = 0
	  sfx(10,2)
	end
	if (self.p == 2 and self.t/30 > 3) then
	  self.p = 3
    self.t = 0
    sfx(10,2)
	end
	if (self.p == 4 and self.t/30 >= 1) then
	  self.bunny = {}
	  self.bunny.x = -10
	  self.bunny.y = 80
	  self.bunny.f = 100
	  self.p = 5
	  self.t = 0
	  sfx(10,-2)
	  sfx(11,2)
	end	
	if (self.p == 6 and self.t/30 > 3) then
	  cl=19
	  self.p=7
  	self.t=0
  	sfx(12,1)
	  level:init()
	end
	if (self.p == 1 or self.p == 3) then
  	if (dt%2 == 0) then
	    if (self.doc.f == 35) then
	      self.doc.f = 36
	    else
	      self.doc.f = 35
	    end
	  end
	end
	if (self.p == 5) then
  	if (dt%2 == 0) then
	    if (self.bunny.f == 100) then
	      self.bunny.f = 101
	    else
	      self.bunny.f = 100
	    end
	  end
	end
	if (self.p == 1) then	  	
	  if self.doc.x <= 30 then
	    self.doc.x += 1
	  else
	    if self.doc.y <= 38 then
	      self.p = 2
	      self.t = 0
	      sfx(10,-2)
	    else
	      self.doc.y -= 1
	    end
	  end
	end
	if (self.p == 3) then	  
	  if self.doc.x <= 55 then
	    self.doc.x += 1
	  else
	    self.p = 4
	    self.t = 0
	    sfx(10,-2)
	  end
	end
	if (self.p == 5) then	  
	  if self.bunny.x <= 15 then
	    self.bunny.x += 1
	  else
	    self.bunny.f = 103
	    self.p = 6
	    self.t = 0
	    sfx(11,-2)
	  end
	end
	if (self.p == 7) then
    self.bunny.y = 80
    if (ctrl==0 and btn(5)) then
      ctrl=fs      
      sfx(12,-2)
      state:set(6)
    end
	end
end

function outro:draw()
	cls()
	if self.p <= 6 then
		for y = 0,15 do
  		for x = 0,15 do
	  		local c = lvl[y][x]
	  		local flag = fget(c)
	  		if (band(flag,1) == 1) then
	  			spr(c,x*cs,y*cs)	  		
	  		end
	  	end
	  end
	  if dt<15 then  	  	    
   	  spr(44,56,74)
	    spr(44,64,74)	    
	  else
	    spr(44,72,66)
	    spr(44,48,66)
	  end
  	stars:draw()
	end
	if (self.p == 2) then	  
  	print("you win... this time!", 22, 7, 7)
  	line(36,45,36,45,6)
	end
	if (self.p == 7) then
  	for y = 0,15 do
  		for x = 0,15 do
	  		local c = lvl[y][x]
	  		local flag = fget(c)
	  		if (band(flag,1) == 1) then
  	  		spr(c,x*cs,y*cs)
	  		  if (c >= 112 and c <= 117 and flr(rnd(100)) == 5) then
	  		    c = flr(rnd(6))+112
  	  		  lvl[y][x] = c
  	  		  spr(c,x*cs,y*cs)
	  			else
	  			  spr(c,x*cs,y*cs)
	  			end
	  		end
	  	end
	  end
	end
	if (self.p > 0 and self.p < 4) then
	  spr(self.doc.f, self.doc.x, self.doc.y)
	end	
	if (self.p > 4 and self.p < 7) then
	  spr(self.bunny.f, self.bunny.x, self.bunny.y)
	end
	if (self.p == 7) then
	  print("dr. eyevil uses his rocket", 8, 100, 7)
	  print("to fly back in time.", 8, 107, 7)
	  print("oh noooo!", 8, 114, 7)	 
	  if dt<=15 then
	  	print("press x to continue",27,121,7)
  	end	
	end
end

function state:set(s)
	st=s
	if state[st].init then
		state[st]:init()
	end
end

function control()
	if (ctrl>0)	ctrl-=1
end

function bunny:init(x,y)
	self.x=x
	self.y=y
	self.c=1
	self.s=15
	self.f={6,7}
	self.d=0
end

function bunny:die()
	if self.d == 0 then
		ctrl = 60
		death += 1
	  sfx(4,3)
		self.d = 1
		self.c = 1
		self.s = 10
		self.f = {12,13,14}
	end
end

function bunny:hop(dx,dy)
	if (cl <= 1 or self.d == 1) return
	if (level.ready == false) level.ready = true
	local x1 = self.x
	local y1 = self.y
	local flag = fget(lvl[y1+dy][x1+dx])
	if (band(flag, 163)==163) then
	  local c=lvl[y1+dy][x1+dx]
		x1+=dx
		y1+=dy
		if (fget(lvl[y1+dy][x1+dx]) <= 1) then
			lvl[y1][x1]=0
			lvl[y1+dy][x1+dx]=c
			local s = stone:get(x1,y1)
			s.x = x1+dx
			s.y = y1+dy
			sfx(0)
			steps+=1
			pushes+=1
			return 1
	  elseif (band(fget(lvl[y1+dy][x1+dx]),64) == 64) then
	    lvl[y1][x1]=0
			lvl[y1+dy][x1+dx]=0
			local s = stone:get(x1,y1)
			local w = water:get(x1+dx,y1+dy)
			del(water, w)
			s.x = x1+dx
			s.y = y1+dy
			stone:sink(s)
			sfx(0)
			pushes+=1
			steps+=1
		  return 1
		else
			return 0
		end
	elseif (band(flag,19)==19) then
		pc-=1
		lvl[y1+dy][x1+dx]=0
		sfx(2)
	elseif (band(flag,10)==10) then
		local c=lvl[y1+dy][x1+dx]
		x1+=dx
		y1+=dy
		if (fget(lvl[y1+dy][x1+dx]) <= 1) then
			lvl[y1][x1]=0
			lvl[y1+dy][x1+dx]=c
			sfx(0)
			pushes+=1
			steps+=1
			return 1
		else
			return 0
		end
	elseif (band(flag,7)==7) then
	  fset(key,0)
		fset(door,0)
		sfx(6)
		lvl[y1+dy][x1+dx]=0
	elseif (band(flag,2)==2) then
		return 0
	end
	sfx(1)
	steps+=1
	return 1
end

function bunny:update()
  if dt % self.s == 0 then
    if self.f[self.c+1] ~= nil then
      self.c +=1
    else
      self.c = 1
    end
  end
	if self.d == 1 then
		if ctrl == 0 then
			sfx(5,1)
			state:set(3)
		end
	else	  
	  if (cl <= 1) return
		if (btn(0) and ctrl==0) then
			self.x=bunny.x-self:hop(-1,0)
			ctrl=fs			
		end
		if (btn(1) and ctrl==0) then
			self.x=self.x+self:hop(1,0)
			ctrl=fs
		end
		if (btn(2) and ctrl==0) then
		  self.y=self.y-self:hop(0,-1)
		  ctrl=fs
		end
		if (btn(3) and ctrl==0) then
  	 	self.y=self.y+self:hop(0,1)
	   	ctrl=fs
		end
	end
end

function bunny:draw()
	spr(self.f[self.c],self.x*cs,self.y*cs)
end

function enemy:init(x,y,dx,dy)
	local e={}
	e.x = x
	e.y = y
	e.dx = dx
	e.dy = dy
	e.a = 0
	e.c = 1
	e.s = 15
	if dx == 1 then
	  e.f = {8,9}
	elseif dx == -1 then
	  e.f = {9,8}
	elseif dy == 1 then
	  e.f = {73,74}
	elseif dy == -1 then
	  e.f = {76,75}
	end
	add(enemy, e)
end

function enemy:update()
  local snd = false
  for i=1, count(enemy) do
		local e=enemy[i]
    if dt % e.s == 0 then
      if e.f[e.c+1] ~= nil then
        e.c += 1
      else
        e.c = 1
      end
    end
    local tc = 0
    local attack = false    
    if (bunny.y==e.y and ((e.dx==1 and bunny.x>e.x)	
        or (e.dx==-1 and bunny.x<e.x))) then
	   attack = true
	   for x=e.x+e.dx, bunny.x, e.dx do
	    tc = tc + lvl[e.y][x]
	    if (lvl[e.y][x] == 1) then
		    attack = false
		    break
	    end
	   end
    end
    if (bunny.x==e.x and ((e.dy==1 and bunny.y>e.y)	
        or (e.dy==-1 and bunny.y<e.y))) then
	   attack = true
	   for y=e.y+e.dy, bunny.y, e.dy do
	    tc = tc + lvl[y][e.x]
	    if (lvl[y][e.x] == 1) then
		    attack = false
		    break
	    end
	   end
    end    
    e.a=attack
    if (e.a) then
      snd = true
      if atk == 0 then
        sfx(3,2)        
        atk = 1
      end
      e.c=1      
      if (e.dx ~= 0) then
        e.f={10}
      elseif (e.dy == 1) then
        e.f={89}
      elseif (e.dy == -1) then
        e.f={91}
      end
      if (tc == 0) then
        bunny:die()
      end
    else
      if e.dx == 1 then
        e.f = {8,9}
      elseif e.dx == -1 then
        e.f = {9,8}
      elseif e.dy == 1 then
        e.f = {73,74}
      elseif e.dy == -1 then
        e.f = {76,75}
      end
    end    
  end
  
  if snd == false and atk == 1 then
    sfx(15,2)
    atk = 0
  end
end

function enemy:draw()
	for i=1, count(enemy) do
	  local e = enemy[i]
		if (e.a) then
		  if (e.dx ~= 0) then
	      for x=e.x+e.dx, bunny.x-e.dx, e.dx do
		      if (band(fget(lvl[e.y][x]),2)~=2 and level.ready) then
			      spr(11,x*cs,e.y*cs)
		      else
			      break
		      end
	      end
	    elseif (e.dy ~= 0) then
	      for y=e.y+e.dy, bunny.y-e.dy, e.dy do
		      if (band(fget(lvl[y][e.x]),2)~=2 and level.ready) then
			      spr(90,e.x*cs,y*cs)
		      else
			      break
		      end
	      end
	    end
		end
		spr(e.f[e.c], e.x*cs, e.y*cs, 1, 1, e.dx == -1)
	end
end

function water:init(x,y,t)
  local w = {}
  if (t>69) then
    t = 80
  else
    t = 64
  end
  w.x = x
  w.y = y
  w.t = t
  w.s = 15
  w.f = {t+rnd(4)}
  add(water, w)
end

function water:update()
  for i=1, count(water) do
    local w = water[i]
    if (dt % w.s == 0) then
      w.f = {w.t+rnd(4)}
    end
  end  
end

function water:draw()
  for i = 1, count(water) do
    local w = water[i]
    spr(w.f[1],w.x*cs,w.y*cs,1,1,(w.t!=1))
  end
end

function water:get(x,y)
  for i = 1, count(water) do
    if (water[i].x == x and water[i].y == y) then
      return water[i]
    end
  end
end

function stone:init(x,y)
  local s = {}
  s.x = x
  s.y = y
  s.c = 1
  s.f = {85,86,87}
  s.s = 32
  add(stone, s)
end

function stone:update()
  for i=1, count(stone) do
    local s = stone[i]
    if dt % s.s == 0 then
      if s.f[s.c+1] == nil then        
        lvl[s.y][s.x] = 0
        del(stone, s)
        s = nil
        break
      else
        s.c = s.c +1
      end
    end
  end
end

function stone:draw()
  for i = 1, count(stone) do
    local s = stone[i]
    if (s.c >= 1) then
      spr(s.f[s.c],s.x*cs,s.y*cs)
    end
  end
end

function stone:sink(s)
  s.c = 1
  s.s = 15
  sfx(8)
end

function stone:get(x,y)
  for i = 1, count(stone) do
    if (stone[i].x == x and stone[i].y == y) then
      return stone[i]
    end
  end
end

function stars:init(x,y)
  stars.w = 10
  local s = {}
  s.a = 0
  s.x = x
  s.y = y
  s.c = 1
  s.s = 32
  s.f = {24,25,26,25,24}
  add(stars,s)
end

function stars:update()
  if stars.w > 0 then
    stars.w -= 1
  end
  for i = 1, count(stars) do
    local s = stars[i]
    if s.a == 1 then
      if dt % s.s == 0 then
        if s.f[s.c+1] ~= nil then
          s.c += 1
        else
          s.a = 0
          s.c = 1
          s.s = 32
        end
      end
    end
    if stars.w == 0 then
      r = flr(rnd(count(stars)))
      if i == r then
        s.a = 1
        s.c = 1
        s.s = 2
        stars.w = flr(rnd(120))+20
      end      
    end
  end
end

function stars:draw()
  for i = 1, count(stars) do
    local s = stars[i]
    if s.a == 1 then
      spr(s.f[s.c],s.x*cs,s.y*cs)
    end
  end
end

function level:init()
	pc=0
	fset(key,4)
	fset(door,3)
	if (ctrl<=4) ctrl=4
	for e in all(enemy) do
		del(enemy,e)
	end
	for s in all(stone) do
		del(stone,s)
	end
	for w in all(water) do
		del(water,w)
	end
	for s in all(stars) do
		del(stars,s)
	end
	for s in all(space.stars) do
		del(space.stars,s)
	end
	sfx(15,2)
	level:load(cl)
end

function level:update()
	if pc<=0 then
		fset(key,7)
	end
	if (lvl[bunny.y][bunny.x]==2) then
		if cl < 16 then
			cl += 1
			if (cl==3 or cl==7 or cl==9 or cl==15 or cl==16) then
  			state:set(4)
			else
			  state:set(3)
			end
		else
			state:set(5)
		end
	end
	if (ctrl==0 and btn(5)) then
		ctrl = 24
		reset += 1
		sfx(5,1)
		state:set(3)
	end
	water:update()
	stone:update()
	bunny:update()
	enemy:update()
	stars:update()
end

function level:draw()
	cls()
	for y = 1,15 do
		for x = 0,15 do
			local c = lvl[y][x]
			local flag = fget(c)
			if (band(flag,1) == 1) then
				spr(c,x*cs,y*cs)
			elseif not (x==bunny.x and y==bunny.y and bunny.d==0) and c ~= 24 then
			  if ((band(fget(lvl[y][x-1]),32) == 32 and fget(lvl[y][x-1]) < 128 and band(fget(lvl[y][x+1]),32) == 32 and fget(lvl[y][x+1]) < 128) or
 			      (band(fget(lvl[y-1][x]),32) == 32 and fget(lvl[y-1][x]) < 128 and band(fget(lvl[y+1][x]),32) == 32 and fget(lvl[y+1][x]) < 128)) then
			    spr(87,x*cs,y*cs)
			  else  
				  spr(34,x*cs,y*cs)
				end
			end
		end
	end
	if (cl==3) and dt<15 then
		print("got stuck?",45,20,11)
		print("press x to reset level",20,30,11)
	end
	water:draw()
	stone:draw()
	bunny:draw()
	enemy:draw()
	stars:draw()
	level:info()
end

function level:load(l)
  self.ready = false
	local o=flr((l-1)/8)
	local x2=(l-1)*16-(o*128)
	local y2=o*16
	lvl={}
	for y=0,15 do
		lvl[y]={}
		for x=0,15 do
			local c=mget(x+x2,y+y2)
			local f=fget(c)
			lvl[y][x]=c
			if c==6 then
				bunny:init(x,y)
				lvl[y][x]=0
			elseif c==5 then
				pc+=1
			elseif c==8 then
				enemy:init(x,y,1,0)
			elseif c==9 then
				enemy:init(x,y,-1,0)
		  elseif c==73 then
				enemy:init(x,y,0,1)
			elseif c==75 then
				enemy:init(x,y,0,-1)					  
		  elseif band(f,163)==163 then
		    stone:init(x,y)
		  elseif band(f,64)==64 then
		    water:init(x,y,c)
  	  elseif band(f,128)==128 and band(f,163)~=163 then
		    stars:init(x,y)
			end
		end
	end
end

function _init()
	state:set(1)
end

function _update()
  dt+=1
  if dt>30 then 
		dt=1
		if st==3 then
			if ts>=59 then
				ts=0
				if tm>=59 then
				  tm=0
				  th+=1
				else
				  tm+=1
				end
			else
				ts+=1
			end
		end
  end
  control()
  state[st]:update()
end

function _draw()
	state[st]:draw()
end

function level:info()
  local hr=""
	local min=""
	local sec=""
	if (ts<10) sec="0"
	if (tm<10) min="0"
	if (th<10) hr="0"
	spr(60,85,0)
	print("level "..(cl-1).."/15",0,1,12)	
  print(hr..th..":"..min..tm..":"..sec..ts,97,1,12)
end
