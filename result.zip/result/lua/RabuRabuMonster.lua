-------------------------
--- rabu rabu monster ---
-------------------------
--by the pedroest--------
--pedro of'em all--------
------------------------- 
------gosh, i hope this--
------will turn out fun--
-------------------------

-- global stuff --
------------------
game=false
title=true

difficulty="easy"
canisetdifficulty=true

start=false
camerax=0
--cameray=0
gravity=0.4
--speed=1
--loops=1
maxspeed=5

time=0
gametime=0
maxmins=2

killcount=0

-- player stuff --
------------------
phealth=82
px = 0
py = 88
pspeedx = 0
pspeedy = 0

pframe = 1
pfacing = 1
pstate = "normal"
panimspeed = 24

pjumppower=5

pholdtime=0

function healthcheck()
	if(phealth<0)phealth=0 gameover=true
	if(py>130)gameover=true
	if(phealth>82)phealth=82
end

function gameoveryet()
	if night
	then
		colours={0,1,1,1,13,1,6,7,2,10,10,3,1,2,14,6}
		for x=1,16 do if x~=8 then pal(x-1,colours[x]) end end
	end

	if twilight
	then
		colours={0,1,2,2,4,8,6,7,8,10,10,9,8,2,14,15}
		for x=1,16 do if x~=8 then pal(x-1,colours[x]) end end
	end
	
	if gameover
	then
		colours={0,2,2,2,2,8,14,7,8,8,14,14,8,2,14,14}
		for x=1,16 do if x~=8 then pal(x-1,colours[x]) end end
	end
end

function pmove()
	if pspeedx>0
	then
		if not pcolr then px+=pspeedx end
	end
	if pspeedx<0
	then
		if not pcoll then px+=pspeedx end
	end

	--correct x coordinate--
	dontcorrectme=false
	iwannabeherey=round(px/8)*8
	if(solid(pmapx2+2,pmapy))px=iwannabeherey pstate="jumping" dontcorrectme=true
	if(solid(pmapx4,pmapy))px=iwannabeherey pstate="jumping" dontcorrectme=true

		
	if pspeedy<0	
	then
	 if not solid(pmapx4,pmapy-2) and not solid(pmapx2+2,pmapy-2) then py+=pspeedy else if not dontcorrectme then pspeedy=max(pspeedy,0) end end
	end
	if pspeedy>0
	then
		if not pcold then py+=pspeedy end
	end
	
	if pcold and pstate=="jumping" and pspeedy>=0
	then
		pclock=0
		pframe=1
		panimcount=0
		panimation="standing"
		pstate="normal"
		pspeedy=0
	end

	
	pspeedy+=gravity
	if (pspeedy>maxspeed)pspeedy=maxspeed
	if pcold and pspeedy>=0 and not dontcorrectme then pspeedy=0 end
	if pspeedy~=0 then pstate="jumping" end

	--correct y coordinate--
	iwannabeherey=flr(py/8)*8
	if(not dontcorrectme and pcold and pspeedy==0 and py>iwannabeherey)py=iwannabeherey

 ----iwannabeherey=flr(py/8+1)*8
	--if(not pcold and pcoldd and pspeedy>3)py=iwannabeherey

	--if(solid(pmapx4,pmapxy))px=iwannabeherey+8

	--if(pinn)px=iwannabeherey
	--if solid(pmapx,pmapy)
	--then
		--if px%8<5 then px=pmapx*8+7
		--else px=0 end
	--end

	--player facing--
	if pspeedx>0 then pfacing=1 end
	if pspeedx<0 then pfacing=0 end


	--a good boy eats slowly--
	if pstate=="omnomnom"
	then
		peattimer+=1
		if(peattimer>20)pstate="normal" create_skull(px,py) phealth+=human_deliciousness speechbubble=1 sfx(35,3)
	end
	
	if(not done and px>1000)px=1000
	if(px<0)px=0
	if(title and px<9)px=9
	if(title and px>142)px=0 py=88 title=false startinggame=true for ball in all(fireballs)do del(fireballs,ball) end
	if(title and py>64)px=98 py=-8
	
end

function panimate()
	pclock+=1
	if(pclock>30)pclock=0

	if pstate~="capture"
	then
		if(pclock>=30-panimspeed)
		then
			pclock=0
			pframe+=1
			if pframe>4 then pframe=1 panimcount+=1 if panimcount>4 then panimcount=0 end end
		end
	
		if(pfiring)pfiring+=1
		if(pfiring and pfiring>3)pfiring=nil
	end
	
	if pstate=="capture"
	then
		if(pclock>15) pholding=true pstate="normal"
	end
end

function playerdraw()
	rectfill(px,py,px+15,py+31,10)
	rectfill(px,py,px+7,py+31,14)
end

function pdraw()
	--flash when firing--
	if(pfiring)pal(2,10)pal(8,9)
	
	gameoveryet()
	
	--offset if facing left--
	if(pfacing==0)px+=8
	--bobbing movement--
	if panimation=="walking"
	then
		bobx=(pframe+1)%2
		boby=-(pframe%2)

		px+=bobx
		py+=boby
	end

	--facing multiplier--
	local f=pfacing*2-1
	if f==1 then fp=false
	else fp=true end

	if panimation=="standing" and pstate~="jumping"
	then
		--lower body--
		spr(32,px-4+4*f,py+16,3,2,fp)
	end
	
	if panimation=="walking" and pstate=="normal"
	then
		if(pframe==1)legsprite=4
		if(pframe==2 or pframe==4)legsprite=32
		if(pframe==3)legsprite=36	
	
		--lower body--
		spr(legsprite,px-4+4*f,py+16,3,2,fp)
	end
	
	--left hand sprite--
	lhspr=3
	if(pholding)lhspr=2

	if pstate=="normal" or pstate=="capture"
	then
		--torso--
		if(pframe==1 or pframe==4)spr(0,px,py,2,2,fp)
		if(pframe==2 or pframe==3)spr(0,px,py+1,2,2,fp)
		--stiff upper lip--
		if(pframe==1 or pframe==4)pset(px+16+((f-1)/2*17),py+10,3)
		if(pframe==2 or pframe==3)pset(px+16+((f-1)/2*17),py+11,3)
		--amazing left hand--
		if pstate~="capture"
		then
			if(pframe==1 or pframe==2)spr(lhspr,px+4+12*f,py+12,1,1,fp)
			if(pframe==3 or pframe==4)spr(lhspr,px+4+12*f,py+13,1,1,fp)
			--to die for right hand--
			if(pframe==1 or pframe==2)spr(3,px+6+((f-1)/2*4),py+14,1,1,fp)
			if(pframe==3 or pframe==4)spr(3,px+6+((f-1)/2*4),py+15,1,1,fp)
		end
		--sexy lower lip--
		if(pframe==1 or pframe==4)pset(px+16+((f-1)/2*17),py+15,11)
		if(pframe==2 or pframe==3)pset(px+16+((f-1)/2*17),py+16,11)line(px+12+((f-1)/2*10),py+17,px+13+((f-1)/2*10),py+17,3)
		--drool--
		droolx=px+9+((f-1)/2*3)
		drooloffsety=min(1,(pframe-1)%3)
		--if((((panimcount-1)/5)%1==0) or (((panimcount+1)/5)%1==0))
		--then
				--pset(droolx,py+15+drooloffsety,12)
		--end
		--if((panimcount/5)%1==0)
		--then
			if(panimcount~=2 and panimcount~=3)line(droolx,py+15+drooloffsety,droolx,py+15+0^panimcount+drooloffsety,12)
		--end			

		--captured human sweat--
		if pholding
		then
			pholdtime+=1
			if(pholdtime>100)pholdtime=0
			
			if ((pholdtime>10 and pholdtime<20) or (pholdtime>30 and pholdtime<40))
			then
				if pfacing==1
				then
					pset(px+18,py+14,7)
					pset(px+20,py+15,7)
				else
					pset(px-4,py+14,7)
					pset(px-6,py+15,7)					
				end
			end
		end
				
	end

	if pstate=="jumping"
	then			
		--unbelievable legs--
		spr(7,px,py+16,2,2,fp)
		--torso--
		spr(0,px,py,2,2,fp)
		--stiff upper lip--
		pset(px+16+((f-1)/2*17),py+10,3)
		--amazing left hand--
		spr(lhspr,px+4+12*f,py+12,1,1,fp)
		--to die for right hand--
		spr(3,px+4+2*f,py+14,1,1,fp)
		--sexy lower lip--
		pset(px+16+((f-1)/2*17),py+15,11)
	end		
	
	
	if pstate=="omnomnom"
	then

		if peattimer<10
		then
			spr(0,px,py,2,2,fp)
			spr(41,px+8*f,py+8,2,1,fp)

			--stiff upper lip--
			pset(px+16+((f-1)/2*17),py+10,3)
		else
			spr(80,px,py,2,2,fp)
		end
		
		--amazing left hand--
		spr(lhspr,px+4+12*f,py+12,1,1,fp)
		--to die for right hand--
		spr(3,px+4+2*f,py+14,1,1,fp)
		--sexy lower lip--
		pset(px+16+((f-1)/2*17),py+15,11)

	end
	
	--bobbing movement correction--
	if panimation=="walking"
	then
		px-=bobx
		py-=boby
	end
	
	--offset correction--
	if(pfacing==0)px-=8
	pal()
end

function round(x)
	if x-flr(x)>=0.5 then return flr(x)+1
	else	return flr(x) end
end

function pupdatecollision()
	pmapx=flr(px/8)
	pmapx2=flr((px-1)/8)
	pmapx3=flr((px+7)/8)
	pmapx4=flr((px+8)/8)
	pmapy=flr(py/8)+3
	pmapy2=flr((py-1)/8)+3

	if(floor(pmapx4,pmapy) or floor(pmapx+1,pmapy) or floor(pmapx2+2,pmapy) or solid(pmapx4,pmapy+1) or solid(pmapx+1,pmapy+1) or solid(pmapx2+2,pmapy+1))pcold=true else pcold=false
	if(solid(pmapx+2,pmapy) or solid(pmapx+2,pmapy2+1))pcolr=true else pcolr=false
	if(solid(pmapx3,pmapy) or solid(pmapx3,pmapy2+1))pcoll=true else pcoll=false


end


--function pdrawcollisionbox()
	--rectfill(pcolx,pcoly-8,pcolx+7,pcoly-1,10)
	--rectfill(pmapx*8,(pmapy-16)*8,pmapx*8+7,(pmapy-16)*8+7,13)
--end


--	map stuff --
---------------
function solid(x,y)
	return fget(mget(x,y),0)
end

function floor(x,y)
	return fget(mget(x,y),3)
end

function flag(x,y,f)
	return fget(mget(x,y),f)
end

-- fireball stuff --
--------------------
fireballs = {}
max_fireballs = 3

--molten = {}
--molten[148]=true
--molten[167]=true
--molten[168]=true
--molten[175]=true

--molten[138]=true
--molten[139]=true
--molten[140]=true
--molten[141]=true

----molten[154]=true
----molten[155]=true
----molten[156]=true
----molten[157]=true

--molten[128]=148
--molten[129]=167
--molten[130]=168
--molten[131]=175

--molten[144]=148
--molten[145]=167
--molten[146]=168
--molten[147]=175

--molten[160]=138
--molten[65]=139
--molten[66]=140
--molten[161]=167
--molten[162]=168
--molten[163]=141
--molten[164]=175

function create_fireball(x,y,speedx,speedy)
	fireball={}
	fireball.x=x
	fireball.y=y
	fireball.speedx=speedx
	fireball.speedy=speedy
	--fireball.mapx=0
	--fireball.mapy=0
	fireball.trail={}
	fireball.timeout=0
	
	if(count(fireballs)<max_fireballs)add(fireballs,fireball)
end

flames={}
function create_flame(x,y)
	local flame={}
	flame.x=flr(x)
	flame.y=flr(y)
	flame.timer=0
	flame.trail={}
	
	local stop=false
	for fire in all(flames) do
		if (fire.x==flame.x and fire.y==flame.y)stop=true
	end
	
	if(not stop)add(flames,flame) 
end

function burn_flames()
	for flame in all(flames) do
		
		if flame.timer>9
		then
			tile=155
			fx=flame.x
			fy=flame.y

			if(flag(fx-1,fy,6) or flag(fx+1,fy,6))tile=155
			if(not flag(fx-1,fy,5) and not flag(fx-1,fy,6))tile=154
			if(not flag(fx+2,fy,5) and not flag(fx+2,fy,6))tile=156
			if(not flag(fx+1,fy,5) and not flag(fx+1,fy,6))tile=157
			
			if(flag(fx,fy+1,4))tile-=16
			if(flag(fx,fy,1))tile=255
			if(flag(fx,fy,2))tile=233
			mset(flame.x,flame.y,tile) killcount+=1
		end
		
	end
	
	for flame in all(flames) do
		if flame.timer>9 then
			if(flag(flame.x,flame.y+1,6))mset(flame.x,flame.y,255)
			if(flag(flame.x,flame.y-1,6)) mset(flame.x,flame.y-1,255)
			del(flames,flame)
		end
		flame.timer+=1
	end	
end

function draw_flame(flame)	
	if(night or twilight)pal()
	if(flame.timer==1 or flame.timer==2 or flame.timer==7 or flame.timer==8)pal(7,8)pal(8,9)pal(9,10)pal(10,7)
	if(flame.timer==3 or flame.timer==4 or flame.timer==9 or flame.timer==10)pal(7,9)pal(8,10)pal(9,7)pal(10,8)
	if(flame.timer==5 or flame.timer==6 or flame.timer==11 or flame.timer==12)pal(7,10)pal(8,7)pal(9,8)pal(10,9)
	
	if(gameover)gameoveryet()
	spr(39,flr(flame.x)*8,(flr(flame.y))*8)
	pal()
end

function burn(mapx,mapy)
	local offset=0
	negoffset=0
	while flag(mapx+offset,mapy,5) or flag(mapx+negoffset,mapy,5)
	do
		raiseoff=false
		raisenego=false
		if flag(mapx+offset,mapy,5)
		then
			create_flame(mapx+offset,mapy)
			raiseoff=true
			sfx(30,3)
			--mset(mapx+offset,mapy,molten[mget(mapx+offset,mapy)])
		end
		if flag(mapx+negoffset,mapy,5)
		then
			create_flame(mapx+negoffset,mapy)
			raisenego=true
			--mset(mapx+offset,mapy,molten[mget(mapx+offset,mapy)])
		end
		
		local offsety=1
		while flag(mapx+offset,mapy-offsety,5)
		do
			create_flame(mapx+offset,mapy-offsety)
			--mset(mapx+offset,mapy-offsety,192)
			
			offsety+=1
		end

		offsety=1
		while flag(mapx+negoffset,mapy-offsety,5)
		do
			create_flame(mapx+negoffset,mapy-offsety)
			--mset(mapx+offset,mapy-offsety,192)
			
			offsety+=1
		end

	if(raiseoff)offset+=1
	if(raisenego)negoffset-=1
	
	end
	
end

function move_fireballs()
	for fireball in all(fireballs)
	do
		if fireball.timeout==0
		then
			--move--
			fireball.x+=fireball.speedx
			fireball.y+=fireball.speedy
		
			fireball.speedy+=gravity/2
			if(fireball.speedy>maxspeed)fireball.speedy=maxspeed

			--leave trail--
			spark={}
			spark.x=fireball.x+flr(rnd(7))
			spark.y=fireball.y+flr(rnd(7))
			spark.timer=1
			spark.loops=0
			add(fireball.trail,spark)

			--collide--
			--if(fireball.x>298+camerax or fireball.x<-178)fireball.timeout=1
			if(fireball.x<-18 or fireball.y>130)fireball.timeout=1

			if((fireball.x/8)-(flr(fireball.x/8)))>0.5
			then
				fireball.mapx=flr(fireball.x/8)+1
			else
				fireball.mapx=flr(fireball.x/8)
			end
			fireball.mapy=fireball.y/8
			--if(fireball.mapy<6)fireball.mapy=256

			imherelol=mget(fireball.mapx,fireball.mapy)

			if game and (fget(imherelol,3) or solid(fireball.mapx,fireball.mapy))	then burn(fireball.mapx,fireball.mapy) fireball.timeout=1 end

		else
			 fireball.timeout+=1
			 if(fireball.timeout>10)del(fireballs,fireball)
		end
	
	end
end

function draw_fireballs()
	if(night or twilight)pal()
	for fireball in all(fireballs)
	do		
		if(fireball.timeout==0)spr(39,fireball.x,fireball.y)	

		--rectfill(fireball.mapx*8,(fireball.mapy-16)*8,fireball.mapx*8+7,(fireball.mapy-16)*8+7,12)
		for spark in all(fireball.trail) do
			local x=spark.loops
			increment=spark.loops
			while x<5 do
				firecolor=7-spark.loops
				if(firecolor<4)firecolor=8
				if(firecolor<7)firecolor+=4
				pset(spark.x+rnd(7)-3,spark.y+rnd(7)-3,firecolor)
				increment+=1
				x+=increment
			end
			
			spark.timer+=1

			if(spark.timer>3)spark.timer=0 spark.loops+=1
			if(spark.loops>5)del(fireball.trail,spark)
		end
		
	end
end


-- enemy stuff --
-----------------
max_humans=10
max_helicopters=2
max_tinies=30

damage_human=0.5
damage_helicopter=1
human_deliciousness=20


-- human stuff --
-----------------
humans={}

function create_human(x,y)
	human={}
	human.x=x
	human.y=y
	human.speedx=speedx
	human.speedy=speedy
	--human.mapx=0
	--human.mapy=0
	--human.close=false
	human.timer=-1
	--human.caught=false
	
	if count(humans)<max_humans
	then add(humans,human) end	
end

function move_humans()
	for human in all(humans) do
		if(px-human.x+camerax/2>150)del(humans,human)
		
		if human.close
		then
			human.timer+=1
			if(human.timer>60)human.timer=-1
			
			--cause damage--
			if(start and human.timer%5==0 and human.timer<26)phealth-=damage_human sfx(32,3)
		end
	end
end

function ai_human(human)
	local offset=camerax/2
	
	if not human.caught
	then
		if abs(human.x-offset-px-8)<40 and abs(human.y-py)<70 then human.close=true else human.close=false end
	else
		human.close=false
		
		if(pstate=="capture" and pclock>14)del(humans,human)
	end
end

function draw_humans()
	gameoveryet()
	local offset=camerax/2
		
	for human in all(humans) do
		if px+8-human.x+offset<0
		then
			if not human.caught
			then
				if not human.close then spr(9,human.x-offset,human.y) else if human.timer%5==0 and human.timer<26 then spr(26,human.x-offset,human.y) else spr(10,human.x-offset,human.y) end end
			else
				spr(25,human.x-offset,human.y)
			end
		else
			if not human.caught
			then
				if not human.close then spr(9,human.x-offset,human.y,1,1,true) else if human.timer%5==0 and human.timer<26 then spr(26,human.x-offset,human.y,1,1,true) else spr(10,human.x-offset,human.y,1,1,true) end end
			else
				spr(25,human.x-offset,human.y)
			end
		end

	end
		
end


-- tiny stuff --
----------------
tinies={}

function create_tiny(x,y)
	tiny={}
	tiny.x=x
	tiny.y=y
	--tiny.mapx=0
	--tiny.mapy=0
	--tiny.dead=false
	tiny.deadtimer=0
	
	if(count(tinies)<max_tinies)add(tinies,tiny)
end

function draw_tinies()
	for tiny in all(tinies) do
		if not tiny.dead then pset(tiny.x,tiny.y,1)
		else pset(tiny.x,tiny.y,8) end
	end
end

function animate_tinies()
	for tiny in all(tinies) do
		if(abs(tiny.x-px)>200)del(tinies,tiny)
	
		if not tiny.dead
		then
			tiny.mapx=flr(tiny.x/8)
			tiny.mapy=flr(tiny.y/8)
		
			if(flr(rnd(5))==0)tiny.x+=rnd(2)-1
			if(tiny.x<tiny.mapx*8)tiny.x=tiny.mapx*8
			if(tiny.x>tiny.mapx*8+7)tiny.x=tiny.mapx*8+7

			if(flr(rnd(5))==0)tiny.y+=rnd(2)-1
			if(tiny.y<(tiny.mapy)*8+1)tiny.y=(tiny.mapy)*8+1
			if(tiny.y>(tiny.mapy)*8+7)tiny.y=(tiny.mapy)*8+7

			--let's collide!--
			if(abs(tiny.x-px-12)<3 and py==(tiny.mapy-3)*8)tiny.dead=true create_skull(tiny.x,tiny.y-8) sfx(38,3)

			for flame in all(flames) do
				if(flame.x==tiny.mapx and flame.y==tiny.mapy)tiny.dead=true create_skull(tiny.x,tiny.y-8)
			end
					
		else
			tiny.deadtimer+=1
			if(tiny.deadtimer>10)del(tinies,tiny)
		end
		
	end
	
end


-- helicopter stuff --
----------------------
helicopters={}

function create_helicopter(x,y)
	helicopter={}
	helicopter.x=x
	helicopter.y=y
	--helicopter.mapx=0
	--helicopter.mapy=0
	helicopter.timer=0
	--helicopter.facing=false
	--helicopter.close=false
	--helicopter.direction=false
	--helicopter.cooldown=false
	--helicopter.dethklok=nil
	
	if(count(helicopters)<max_helicopters) add(helicopters,helicopter)
end

function ai_helicopters()
	for helicopter in all(helicopters) do
		if(px-helicopter.x>130)del(helicopters,helicopter)
		
		if not helicopter.dethklok
		then
			helicopter.timer+=1
			if helicopter.timer>16
			then
		
				helicopter.timer=1
				if helicopter.cooldown==false
				then
					helicopter.cooldown=true
				else
					helicopter.cooldown=false
				end
		
			end
			
			--cause some damage yo--
			if(start and helicopter.close and helicopter.timer%2==1 and not helicopter.cooldown)phealth-=damage_helicopter sfx(32,3)

			--where the player at?--		
			if helicopter.x-px-8<0 then helicopter.facing=true
			else helicopter.facing=false end
		
			--oh he close?--
			if abs(helicopter.x-px-8)<40 and py-helicopter.y>-40 then helicopter.close=true
			else helicopter.close=false end
		
		
			--never mind i'll just move around--
			helicopter.mapx=flr(helicopter.x/8)
			helicopter.mapy=flr(helicopter.y/8)
			local mapx=helicopter.mapx+1
			local mapy=helicopter.mapy
			stufftotheleft=false
			stufftotheright=false
		
			--where i headed to?--
			if solid(mapx-1,mapy) or floor(mapx-1,mapy) or solid(mapx-2,mapy) or floor(mapx-2,mapy) or helicopter.x<5
			then
				helicopter.direction=true stufftotheleft=true
			end
		
			if solid(mapx,mapy) or floor(mapx,mapy) or solid(mapx+1,mapy) or floor(mapx+1,mapy)
			then
				helicopter.direction=false stufftotheright=true
			end

			--off i go!--
			if not helicopter.close
			then
		
				if helicopter.direction
				then 
					if not stufftotheright then helicopter.x+=1 end
				else
					helicopter.x-=1
				end
		
			else
			
				if helicopter.facing
				then
	
					if not stufftotheright
					then
						if(px-helicopter.x<18 and not stufftotheleft)helicopter.x-=1
						if(px-helicopter.x>18 and not stufftotheright)helicopter.x+=1
					end
	
				else

					if not stufftotheleft
					then	
						if(helicopter.x-px<32 and not stufftotheright)helicopter.x+=1
						if(helicopter.x-px>32 and not stufftotheleft)helicopter.x-=1
					end

				end

			end
		
		
			--me no like fire--
			for fireball in all(fireballs) do
				if (abs(fireball.x-helicopter.x)<10 and abs(fireball.y-helicopter.y)<7)helicopter.dethklok=1 sfx(36,3)
			end
		
	
		else
			--me dead :(--
			helicopter.dethklok+=1
			if(helicopter.dethklok>9)create_skull(helicopter.x,helicopter.y) del(helicopters,helicopter)
		
		end

	end
end

function draw_helicopters()
	for helicopter in all(helicopters) do
	
		if helicopter.cooldown or not helicopter.close then sprite=11
		else sprite=27 end
		
		if not helicopter.dethklok
		then
		
			if not helicopter.close
			then
				local t=flr(helicopter.timer/2)
				local offsety=-t+5+2*(t-5)*flr(t/6)
				spr(sprite+(helicopter.timer%4),helicopter.x,helicopter.y+offsety,1,1,helicopter.direction)
			else
			spr(sprite+(helicopter.timer%4),helicopter.x,helicopter.y,1,1,helicopter.facing)
			end
		
		else
			sprite=55
			if(helicopter.close)spr(sprite+helicopter.dethklok-1,helicopter.x,helicopter.y,1,1,helicopter.facing)
			if(not helicopter.close)spr(sprite+helicopter.dethklok-1,helicopter.x,helicopter.y,1,1,helicopter.direction)
		end

	end
	
end

-- inputsies --
---------------
function input()
	--change speed :p--
	--if (btn(2,1)) speed+=0.1
	--if (btn(3,1)) speed-=0.1
	--if btn(4,1)
	--then
		--if peek(0x4301)==7
		--then
			--load("english")
		--else
			--load("nihongo")
		--end
		--run()
	--end
	
	if btn(0,0) and pstate~="capture" and pstate~="omnomnom" then if pspeedx>-1 then pspeedx=-1 end if panimation~="walking" then pclock=0 pframe=1 panimcount=0 end panimation="walking"
	elseif btn(1,0) and pstate~="capture" and pstate~="omnomnom" then if pspeedx<1 then pspeedx=1 end if panimation~="walking" then pclock=0 pframe=1 panimcount=0 end panimation="walking"
	else if panimation~="standing" then pclock=0 pframe=1 panimcount=0 end panimation="standing" if pstate=="normal" then pspeedx=0 end end
	
	if pstate~="jumping" and pstate~="capture" and not btn(2,0)
	then
		if(pspeedx>1)pspeedx=1
		if(pspeedx<-1)pspeedx=-1
	end
		
	if btn(2,0) and pstate=="normal" then pclock=0 pframe=1 panimcount=0 pstate="jumping" pspeedy=-pjumppower pspeedx+=pspeedx sfx(37,3) end
	if not btn(2,0) and pstate=="jumping" and pspeedy<0 then pspeedy+=gravity*2 end
	if (pspeedy>maxspeed)pspeedy=maxspeed

	if pspeedx>3 then pspeedx=3 end
	if pspeedx<-3 then pspeedx=-3 end

	--fire fire!--
	if btnp(4,0)
	then
		if pfacing==1 then create_fireball(px+8,py+10,3+pspeedx,-1+pspeedy/2)
		else create_fireball(px+8,py+10,-3+pspeedx,-1+pspeedy/2) end
		sfx(31,3)
		
		pfiring=0
	end

	--c'mere, human!--
	local offset=camerax/2
	
	if btnp(3,0) and py==88 and not pholding and pstate=="normal" and pspeedx==0
	then
		for human in all(humans) do
			if abs(px+8-human.x+offset)<10 and not human.caught then if pstate~="capture" then human.caught=true end pstate="capture" sfx(33,3) end
		end
	end

	if btn(3,0) and pstate=="normal" and pholding
	then
		if pfacing==1
		then
			if(floor(pmapx+2,pmapy) and floor(pmapx+3,pmapy) and not flag(pmapx+2,pmapy,6)) create_tiny(px+24,py+24) pholding=false
		else
			if(floor(pmapx-2,pmapy) and floor(pmapx-3,pmapy) and not flag(pmapx-2,pmapy,6)) create_tiny(px-8,py+24)	pholding=false
		end
	end
	
	
	--human yummy<3--
	if btn(5,0) and pstate=="normal" and pspeedx==0 and pholding
	then
		pstate="omnomnom"
		peattimer=0
		pholding=false
	end
	
end


-- graphical stuff --
---------------------
--function speechbubble(x,y)
	--circfill(x,y,5,7)
	--pset(x-3,y+5,7)
	--pset(x-2,y+6,7)
	--pset(x-3,y+6,7)
	--pset(x-4,y+6,7)
	--spr(64,x-4,y-3)
--end

speechbubble=0
function animate_speechbubble()
	if speechbubble>0
	then
		speechbubble+=1
		if(speechbubble>36)speechbubble=0
	end
end

function draw_speechbubble(x,y)
	if(night or twilight)pal()
	if speechbubble>0
	then
		if(speechbubble<31) speechsprite=87+flr((speechbubble-13)%6/3)
		if(speechbubble<13) speechsprite=83+flr((speechbubble-1)/3)
		if(speechbubble>=31) speechsprite=89+flr((speechbubble-31)/3)
		spr(speechsprite,x,y)
	end
end

skulls={}
function create_skull(x,y)
	skull={}
	skull.x=x
	skull.y=y
	skull.timer=0
	
	add(skulls,skull)
	
	killcount+=1
end

function animate_skulls()
	for skull in all(skulls) do
		skull.timer+=1
		if(skull.timer>16)del(skulls,skull)
	end
end

function draw_skulls()
	if(night or twilight)pal()
	for skull in all(skulls) do
		skullsprite=43+max(0,skull.timer-12)
		local offsetx=abs(5-(skull.timer%5)-3)-1
		
		if(not gameover)skull.x-=offsetx
		
		if(skull.timer==1)skullsprite=47
		if(skull.timer==2)skullsprite=45
		if(skull.timer==3)skullsprite=44

		spr(skullsprite,skull.x,skull.y-skull.timer)
	end
end

phantom_health=phealth

function draw_hud()
	if(night or twilight)pal()
	healthcheck()
	--phantom health bar--
	rectfill(12+camerax,5,12+flr(phantom_health/2)+camerax,10,9)
		
	--health bar--
	spr(82,2+camerax,4)
	rectfill(12+camerax,5,12+flr(phealth/2)+camerax,10,8)
	line(12+camerax,6,12+flr(phealth/2)+camerax,6,2)
	if(phealth>80)line(53+camerax,6,53+camerax,9,2)
	rect(12+camerax,5,54+camerax,10,7)

	if(phantom_health>phealth)phantom_health-=1
	if(phantom_health<1)phantom_health=1

	--killcount--
	spr(43,2+camerax,13)
	print("x " .. killcount,12+camerax,14,7)
	
end

function fixcamera()
	if(px-camerax>82)camerax+=1
	if(px-camerax<30)camerax-=1
	
	if(camerax<0)camerax=0
	if(camerax>896)camerax=896
	
	camera(camerax,0)
end

function rendermountains()
	local offset=camerax/1.5

	for x=0,20 do
		spr(165,x*64+offset,70,2,1)
		spr(181,x*64+offset,78,4,1)		
		spr(135,48+x*64+offset,70,2,1)
		spr(149,32+x*64+offset,78,4,1)
	end
	
	rectfill(0,86,1280+offset,128,1)
	if(night)pal()spr(73,200+offset,83)
end

cloudoffset=-100
cloudspeed=0.1
backcloudoffset=-120
backcloudspeed=0.03
function renderclouds()
	local offset=camerax/1.2

	pal()
	gameoveryet()
	for x=0,20 do
		spr(185,x*56+backcloudoffset+camerax,59,7,1)
	end
	
	rectfill(0,67,1280+backcloudoffset+camerax,128,7)

	if not gameover then pal(7,6)
	else pal(7,14) end
	gameoveryet()

	for x=0,20 do
		spr(185,x*56+cloudoffset+offset,72,7,1)
	end
	
	rectfill(0,80,1280+cloudoffset+offset,128,7)
	pal()
	gameoveryet()

	if(not gameover)cloudoffset-=cloudspeed
	if cloudoffset<=-156 then cloudoffset=-100 end

	if(not gameover)backcloudoffset-=backcloudspeed
	if backcloudoffset<=-176 then backcloudoffset=-120 end
end

function drawbg()
	gameoveryet()
	--sky--
	if(night)rectfill(0+camerax,0,128+camerax,128,5)
	if(not night)rectfill(0+camerax,0,128+camerax,128,12)
	circfill(174+camerax-flr(time)/5,20+((flr(time)-500)/50)^2,20,7)
	if(night)circfill(174+camerax-flr(time)/5-5,20+((flr(time)-500)/50)^2-5,15,5)
	if night
	then
		spr(35,120+camerax,48)
		spr(51,300+camerax/1.5,48)		
		for star in all(stars) do
			pset(star.x+camerax,star.y,7)
		end
	end
	
	renderclouds()
	
	--mountains--
	rendermountains()
	
	spr(31,712,88)
	spr(98,704,96,3,1)

	--background--
	gameoveryet()
	if(night)pal(6,13)
	map(0,0,0,0,128,16)
	--secrets of twilight!--
	if(twilight)	map(0,16,0,64,24,8) map(24,16,192,0,104,8)
	
	--buildings--
	--map(0,0,0,-1,64,16)
	
end

function drawfg()
	--background covering player--
	gameoveryet()
	if(night)pal(6,13)
	palt(11,true)
	for x=0,4 do
		if(flag(pmapx,pmapy-x,7)) map(pmapx,pmapy-x,(pmapx)*8,(pmapy-x)*8,1,1)
		if(flag(pmapx,pmapy-x,7)) map(pmapx,pmapy-x,(pmapx)*8,(pmapy-x)*8,1,1)
	end
	palt()
	
end

function drawfglayer()
	gameoveryet()
	--foreground layer--
	local offset=camerax/2
	if(night)pal(6,13)
	map(0,24,-offset,69,128,8)
end


-- game functions --
--------------------
function update_gameover()
	if(btn(4,0)) run()
end

--update some logic yo!--
function _update()
--	if speed <= 1
--	then
--		if loops>=1
--		then
		if true --game
		then
			if not gameover
			then
				if px>999 and py==88
				then
					done=true
					px+=1
									
					if px>1010	
					then
						--poke(0x4302,7)--ending
						--poke(0x4303,flr(killcount/256))--kills 1
						--poke(0x4304,killcount%256)--kills 2
						--poke(0x4305,flr(gametime/256))--time 1
						--poke(0x4306,gametime%256)--time 2
					
						--if peek(0x4302)==7
						--then
							--if peek(0x4301)==7
							--then 
								--load("english")
							--else
								--load("nihongo")
							--end run()
						--end
					end
			
				else
					--poke(0x4302,0)
				end
				
				time+=1
				gametime+=1
				if time>700 then twilight=true fset(130,3,true) end
				if time>1017 then time=0 twilight=false fset(130,false) if night then night=false fset(233,false) else night=true fset(233,3,true) end end
				generate_helicopters(px+228)
				generate_tinies(px+128)
				generate_humans(px+150+camerax/2)
				move_humans()			
				if(not done)input()
				pupdatecollision()
				healthcheck()
				pmove()
				pupdatecollision()
				for human in all(humans) do
					ai_human(human)
				end
				ai_helicopters()
				move_fireballs()
				burn_flames()
				panimate()
				animate_speechbubble()
				animate_tinies()
				animate_skulls()
				fixcamera()
				fixcamera()
			else
				update_gameover()
			end
		end
--			loops=0
--		end
--		loops+=speed
--	else
--		while (loops<=speed) do
--			input()
--			pupdatecollision()
--			healthcheck()
--			pmove()
--			for human in all(humans) do
--				ai_human(human)
--			end
--			move_humans()
--			ai_helicopters()
--			move_fireballs()
--			burn_flames()
--			panimate()
--			animate_tinies()
--			animate_skulls()
--			fixcamera()
--			fixcamera()

--			loops+=1	
--		end
--		loops=1
		
--	end
	
	if title --title
	then
		if(not done)input()
		pupdatecollision()
		panimate()
		move_fireballs()
		pmove()
		
		if py==40
		then
			if canisetdifficulty
			then
				if difficulty=="easy" then difficulty="medium"
				elseif difficulty=="medium" then difficulty="hard"
				elseif difficulty=="hard" then difficulty="doemu"
				elseif difficulty=="doemu" then difficulty="easy" end
				canisetdifficulty=false
			end
		else
			canisetdifficulty=true
		end
	end
	
	if startinggame --startinggame
	then
		if cameray<0
		then
			cameray+=1
			if(camerax>0)camerax-=2/5
			camera(camerax,cameray)
		else
			startinggame=false
			game=true
		end
		
		if difficulty=="easy"
		then
			max_humans=10
			max_helicopters=1
			max_tinies=15
			maxmins=5

			damage_human=0.5
			damage_helicopter=0.5
			human_deliciousness=100
		end
		if difficulty=="medium"
		then
			max_humans=10
			max_helicopters=2
			max_tinies=20
			maxmins=2

			damage_human=0.5
			damage_helicopter=1
			human_deliciousness=20
		end
		if difficulty=="hard"
		then
			max_humans=10
			max_helicopters=2
			max_tinies=30
			maxmins=1

			damage_human=1
			damage_helicopter=3
			human_deliciousness=20
		end
		if difficulty=="doemu"
		then
			max_humans=10
			max_helicopters=5
			max_tinies=80
			maxmins=0

			damage_human=1
			damage_helicopter=2
			human_deliciousness=-20
		end

		
	end
	
end

-- generators --
----------------
function generate_humans(minx)	
	local giveup=0
	while count(humans)<max_humans and giveup<20
	do

		place=flr(rnd(400))+minx
		local stop=false
		if mget(flr(place/8),29)==129
		then
		
			for human in all(humans) do
				if(abs(human.x-place)<8)stop=true
			end
		
			if(not stop)create_human(place,105)

		end

		giveup+=1
	end
	
end

function generate_tinies(minx)
	local giveup=0
	while count(tinies)<max_tinies-10 and giveup<20
	do
	
		x=flr(rnd(100))+minx
		y=flr(rnd(120))
		if(floor(flr(x/8),flr(y/8)) and floor(flr(x/8)+1,flr(y/8)) and floor(flr(x/8)-1,flr(y/8)))create_tiny(x,y)
	
	giveup+=1
	end
end

function generate_helicopters(minx)
	local giveup=0
	while count(helicopters)<max_helicopters and giveup<20
	do
		
		local stop=false
		x=flr(rnd(100))+minx

		for helicopter in all(helicopters) do
			if(helicopter.stufftotheleft or helicopter.stufftotheright)del(helicopters,helicopter)
			if(abs(x-helicopter.x)<8)stop=true			
		end

		if(not stop)create_helicopter(x,80)
		ai_helicopters()

		giveup+=1
	end
end

stars={}
--initialize da good stuff yo!--
function _init()
	start=true
	music(0)
	
	local x=0
	while count(stars)<30 do
		star={}
		star.x=flr(rnd(128))
		star.y=flr(rnd(86))
		add(stars,star)
		x+=1
		
		for otherstar in all(stars) do
			if(abs(otherstar.x-star.x)<2 and abs(otherstar.y-star.y)<2) del(stars)
		end
	end

		--ram=peek(0x4300)
		--if(ram==0)load("nihongo")run()
		--if(ram==1)difficulty="easy"
		--if(ram==2)difficulty="normal"
		--if(ram==3)difficulty="hard"
		--if(ram==4)difficulty="doemu"

		--if difficulty=="easy"
		--then
			--max_humans=10
			--max_helicopters=1
			--max_tinies=15
			--maxmins=5

			--damage_human=0.5
			--damage_helicopter=0.5
			--human_deliciousness=100
		--end
		--if difficulty=="medium"
		--then
			--max_humans=10
			--max_helicopters=2
			--max_tinies=20
			--maxmins=2

			--damage_human=0.5
			--damage_helicopter=1
			--human_deliciousness=20
		--end
		--if difficulty=="hard"
		--then
			--max_humans=10
			--max_helicopters=2
			--max_tinies=30
			--maxmins=1

			--damage_human=1
			--damage_helicopter=3
			--human_deliciousness=20
		--end
		--if difficulty=="doemu"
		--then
			--max_humans=10
			--max_helicopters=5
			--max_tinies=80
			--maxmins=0

			--damage_human=1
			--damage_helicopter=2
			--human_deliciousness=-20
		--end
	
end

--draw some cuties yo!--
function _draw()	
	if game --game
	then
		drawbg()
		draw_tinies()
		pdraw()
		drawfg()
		for flame in all(flames) do
			draw_flame(flame)
		end
		draw_fireballs()
		drawfglayer()
		draw_humans()
		draw_helicopters()
		draw_skulls()
		draw_speechbubble(px+20-pfacing*4,py-2)
		draw_hud()
	
	--print("time " .. flr(time),0,30)
	--print (pmapx .. "," .. pmapy,camerax,20)
		if(gameover)pal()print("game over!",48+camerax,50,12) print("game over!",47+camerax,49,7)
		
		minutes=maxmins-1-flr((gametime-30)/1800)
		seconds=-flr(gametime/30)%60		
		spr(198,camerax+2,21)		
		if minutes>=0
		then
			if seconds<10 then print(minutes .. ":0" .. seconds,camerax+11,21)
			else print(minutes .. ":" .. seconds,camerax+11,21) end
		else
			minutes=flr((gametime)/1800)-maxmins-1
			seconds=flr(gametime/30)%60
			if seconds<10 then print("-" .. minutes+1 .. ":0" .. seconds,camerax+11,21)
			else print("-" .. minutes+1 .. ":" .. seconds,camerax+11,21) end
			
		end
		
	end
	
	if(title)camerax=16 cameray=-40 camera(camerax,cameray)
	if title or startinggame
	then
		colours={0,0,5,5,6,5,6,7,5,6,7,7,6,6,6,7}
		for x=1,16 do pal(x-1,colours[x]) end
		rectfill(0,-40,143,168,12)
		renderclouds()
		for x=1,16 do pal(x-1,colours[x]) end		
		rendermountains()
		map(0,0,0,0,24,16)
		spr(117,136,8)
		pal()
		print("difficulty",72,64,8)
		print("options",24,40,8)
		print(difficulty,104,16,8)
		
		if(py==16)pal()	map(2,4,16,32,6,3)
		if(py==-8)pal()	map(11,0,88,0,7,4) spr(117,136,8)
		if(py==40)pal()	map(8,6,64,48,8,4)
		
		pal()
		pdraw()
		draw_fireballs()		
		print("rabu rabu monster!",47,-20,8)
		print("rabu rabu monster!",46,-20,7)
	end
end