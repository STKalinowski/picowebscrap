-- tRIAL OF THE sORCERER
-- bY mOT

-- immediate mode gui
do	
 poke(0x5f2d,3)

	-- private
	local itms,dolast,co,autonl,nextregions,regions,rstack={},{},{},true,{}
	
	-- public 
	
	-- current position & margins
	-- mouse state
	g_x,g_y,g_left,g_right,g_mx,g_my,g_mb,g_mbp,g_mbb=1,1,1,128,0,0,false,false,0
	local pmx,pmy=stat(32),stat(33)
	
	-- private functions
	local function getitm(typ,props)
	
	 -- look for matching item
		for itm in all(itms) do
			if itm.x==g_x and itm.y==g_y and itm.typ==typ then
				itm.active=true
				return itm
			end
		end
		
		-- create new item
		local itm={typ=typ,x=g_x,y=g_y,active=true}
		if props then
			for k,v in pairs(props) do
				itm[k]=v
			end
		end  
		add(itms,itm)
		return itm
	end	

	-- public functions

 -- begin gui rendering
 -- all rendering should be between
 -- g_beg() and g_end()

	function g_beg()
		-- deactivate items
		for itm in all(itms) do
			itm.active=false
		end
		-- reset state
		g_x,g_y,g_left,g_right,autonl=1,1,1,128,true
		-- reset regions
		regions=nextregions
		nextregions,rstack={},{{0,g_left,g_right}}

		-- tab stops and focus
		g_tabs,g_focus={},false
		
		-- read mouse
  local mx,my=stat(32),stat(33)
  if mx~=pmx or my~=pmy then
  	g_mx,g_my=mx,my
  	pmx,pmy=mx,my
  	g_mousemode=true
  end
  g_mbb=stat(34)
		g_mbp=g_mb
		g_mb=g_mbb~=0
		g_clk=(g_mbb==1 and not g_mbp) or btnp(❎)
	end

	function g_end()
	 runcoroutines(co)
		
		-- do scheduled "do last" tasks
		for fn in all(dolast) do
			fn()
		end
		dolast={}
		for itm in all(itms) do
			if(not itm.active)del(itms,itm)
		end
		
		-- mouse ptr keyboard input
		if not g_focus then
		 local xd,yd=0,0
		 if(btnp(⬅️))xd-=1
		 if(btnp(➡️))xd+=1
		 if(btnp(⬆️))yd-=1
		 if(btnp(⬇️))yd+=1
		 
	  local n,nx,ny=32000,g_mx,g_my
		 if xd~=0 then
		  for t in all(g_tabs) do
		   local dx,dy=t.x-g_mx,t.y-g_my
		   local d=dx*dx+dy*dy
		   if dx~=0 and sgn(dx)==sgn(xd) and abs(dy)<=abs(dx) and d<n then
		    n=d
		    nx,ny=t.x,t.y
		   end
		  end
		  g_mousemode=false
		 elseif yd~=0 then
		  for t in all(g_tabs) do
		   local dx,dy=t.x-g_mx,t.y-g_my
		   local d=dx*dx+dy*dy
		   if dy~=0 and sgn(dy)==sgn(yd) and abs(dx)<=abs(dy) and d<n then
      n=d
      nx,ny=t.x,t.y
     end
    end
    g_mousemode=false
   elseif not g_mousemode then
		  for t in all(g_tabs) do
		   local dx,dy=t.x-g_mx,t.y-g_my
		   local d=dx*dx+dy*dy
		   if d<n then
      n=d
      nx,ny=t.x,t.y
     end
    end   
   end		   
   g_mx,g_my=nx,ny
		end
		
		-- draw pointer
		if #g_tabs>0 then
	  local fr=1
	  if(btn(❎))fr+=framect\3%2*32
			spr(fr,g_mx,g_my,2,2)
		end
	end
	
	function g_beginregion(x1,y1,x2,y2,col,bdrcol,modal)
	
	 -- add to regions to apply next frame
	 -- (region logic is always applied using
	 -- the previous frame's regions, because 
	 -- we don't know what is still to be 
	 -- drawn in the current frame)
		add(nextregions,{x1,y1,x2,y2,modal})
		
		-- add to stack
		add(rstack,{#nextregions,g_left,g_right})
		
		-- border and background
		if(col)rectfill(x1,y1,x2-1,y2-1,col)
		if(bdrcol)rect(x1,y1,x2-1,y2-1,bdrcol)
		
		-- reposition cursor and set column
		g_x,g_y,g_left,g_right=x1,y1,x1,x2
	end
	
	function g_endregion()
		local top=rstack[#rstack] 
		deli(rstack)
		
		-- restore previous columns
		g_left,g_right=top[2],top[3]
	end

	function g_autonewline(v)
		autonl=v
	end  

	function g_newline(h)
		g_x=g_left
		g_y+=(h or 10)
	end

	function g_makespc(w,h)
		if(g_x+w>g_right and g_x>g_left)g_newline(h)
	end
	
	function g_advance(w,h)
		if autonl then g_newline(h)
		else           g_x+=w
		end
	end 

	function g_gethoverraw(w,h)
		return g_mx>=g_x and g_my>=g_y and g_mx<g_x+w and g_my<g_y+(h or 10)-1 
	end 

	function g_gethover(w,h)	
		-- is mouse in the correct region?
		local i=#regions
		local r=regions[i]
		while i>0 
			and not (g_mx>=r[1] and g_my>=r[2] and g_mx<r[3] and g_my<r[4]) do
			if(r[5])return false -- modal region found. block hover notifications to underneath regions
			i-=1
			r=regions[i]
		end
		if(i~=rstack[#rstack][1])return false
		
		-- check if hovering over ui element
		return g_gethoverraw(w,h)
	end
	
	function g_getactive(w,h)
	 -- control is active if placing
	 -- the cursor directly over it 
	 -- is treated as hovering.
		local sx,sy=g_mx,g_my
		g_mx,g_my=g_x+w/2,g_y+(h or 10)/2
		local active=g_gethover(w,h)
		g_mx,g_my=sx,sy
		return active
	end
	
	function g_tabstop(w,h)
	 if g_getactive(w,h) then
	  add(g_tabs,{x=g_x+w-4,y=g_y+(h or 10)-4})
	 end
	end
	
	function g_strwidth(s)
	 return #s*4
	 
	 -- this version handles high
	 -- ascii characters, if you can
	 -- spare the tokens
--		local w=0 s=""..s
--		for i=1,#s do
--			if ord(sub(s,i,i))<128 then
--				w+=4
--			else 
--				w+=7
--			end
--		end
--		return w
	end 
	
	function g_getpos() return g_x,g_y end
	function g_setpos(nx,ny) g_x=nx g_y=ny end

	function g_column(l,r,t)
		g_left=l or 1
		g_right=r or 127
		g_x,g_y=l,t or g_y
	end
	
	function g_btnex(drawfn,w,h,state)
		w=w or 16 h=h or 16
		g_makespc(w,h)

		local itm=getitm("btn")
		local hover=g_gethover(w,h)
		g_tabstop(w,h)

		-- behaviour
		local clicked=false
		
		if hover and g_clk then
			itm.down=true
		elseif itm.down and not g_mb then
			itm.down=false
			clicked=hover  
		end
		
		-- draw
		drawfn(itm.down,hover,g_x,g_y,w,h,state)
		g_advance(w,h)
		
		return clicked  
	end

	function g_btn(text,w,dep)
	 return g_txtbtn(text,w,dep)
	end

	local function drawtxtbtn(down,hover,x,y,w,h,state)
		local col=7
		if(hover)col=10
		if((hover and down)or state.dep)col=7
		local textw=g_strwidth(state.text)
		printp(state.text,x+(state.leftalign and 0 or (w-textw)/2),y+2,col)
	end

	function g_txtbtn(text,w,dep,leftalign)
		return g_btnex(drawtxtbtn,w or 10,10,{text=text,dep=dep,leftalign=leftalign})
	end

	local function drawspritebtn(down,hover,x,y,w,h,state)
	 local s1,s2,s3=state.s1,state.s2,state.s3
  s2=s2 or s1
  s3=s3 or s1
  local s=s1
  if(hover)s=s2
  if(down)s=s3
  spr(s,x,y,state.w,state.h)  
	end
	
	function g_spritebtn(s1,s2,s3,w,h)
	 w=w or 1
	 h=h or w
	 return g_btnex(drawspritebtn,w*8+2,h*8+2,{s1=s1,s2=s2,s3=s3,w=w,h=h})
	end

	function g_chk(checked,text,value,w)
		if not w then 
			w=text and 53 or 10
		end
		g_makespc(w)
		local itm=getitm("chk",{checked=checked})
		local hover=g_gethover(w)
		
		-- behaviour
		local clicked=false
		
		if hover and g_clk then
			itm.down=true
		elseif itm.down and not g_mb then
			itm.down=false
			if hover then
				checked=value or not checked
			end
		end
		
		-- draw
		local col=0
		if(hover)col=6
		if(hover and itm.down)col=10
		if value then
			circfill(g_x+4,g_y+4,4,col)
			circ(g_x+4,g_y+4,4,5)
			if checked==value then
				circfill(g_x+4,g_y+4,2,7)
			end
		else
			rectfill(g_x,g_y,g_x+8,g_y+8,col)
			rect(g_x,g_y,g_x+8,g_y+8,5)  
			if checked then
				line(g_x+2,g_y+2,g_x+6,g_y+6,7)
				line(g_x+6,g_y+2,g_x+2,g_y+6,7)   
			end
		end
		if(text)print(text,g_x+12,g_y+2,7)  
		
		g_advance(w)  
		return checked
	end
	
	function g_label(text,w,centered,col)
		w=w or 63
		col=col or 13
		g_makespc(w)
		local lx=g_x
		if(centered)lx+=(w-g_strwidth(text))/2
		printp(text,lx,g_y+2,col)
		g_advance(w)
	end

	function g_txtbox(text,w,cols)
		w=w or 63
		g_makespc(w)
		local itm=getitm("txt")
		local hover=g_gethover(w)
		g_tabstop(w,h)
		
		-- behaviour
  if btnp(❎) and itm.sel then
  	itm.sel=false
		elseif g_clk then
			itm.sel=hover
			if hover then
				itm.c=(g_mx-(g_x+2))\4+1
			end
		end			
		
		-- draw
		local col=6
		if(hover)col=10
		if(itm.sel)col=7
		rectfill(g_x,g_y,g_x+w-1,g_y+8,col)
		local ptext,maxl=text,flr((w-4)/4)
		if(#ptext>maxl)ptext=sub(ptext,#ptext-maxl+1)  
		printcol(ptext,cols or {0},g_x+2,g_y+2)
		if itm.sel and itm.c then
		 print("_",g_x+2+itm.c*4-4,g_y+3,12)
		end

		g_advance(w)
		
		-- input
		local c
		if itm.sel then
   c=itm.c or #text
	  local key=stat(31)
--	  if(key and key~="")printh(key..","..ord(key))
   if(btnp(⬅️) or key==chr(8))c-=1
   if(btnp(➡️))c+=1
   c=clamp(c,1,#text)
   local v=tonum(sub(text,c,c))
   if(btnp(⬆️))v+=1
   if(btnp(⬇️))v-=1
   local v=clamp(v,0,9)
   local char,adv=tostr(v)
   if key>="0" and key<="9" then
    v=key adv=true
   end    
   text=sub(text,1,c-1)..tostr(v)..sub(text,c+1)   
   if(adv)c+=1
   if(key==chr(194))printh(text,"@clip")
   if key==chr(213) then 
    local paste=stat(4)
    text=""
				for i=1,9 do
				 if i<=#paste then
				  local c=sub(paste,i,i)
				  if c>="0" and c<="9" then
				  	text..=c
				  else
				  	text..="0"
				  end
				 else
				  text..="0"
				 end
				end
   end
		end
  itm.c=c

		-- text and enter state from previous frame
		text=itm.text or text
		enter=itm.enter or enter
		
		-- clear previous frame state
		itm.text,itm.enter=nil,nil
		
		if(itm.sel)g_focus=true
		
		return text,enter
	end
	
	function g_co(fn)
  add(co,cocreate(fn))	 
	end
	
	function g_choosefromlist(list,gettextfn,callbackfn,curidx,nonetext)
  g_co(function()
   local first=(curidx or 1)-5
  	while true do
  	 first=max(min(first,#list-9),1)
 	
	 		-- modal window
	 		g_beginregion(24,8,104,120,6,5,true)
	 	 g_column(26,102,10)
	 	 local hover=g_gethover(80,112)
 	 
	 	 -- none option	 	 
	 	 if nonetext and g_txtbtn(nonetext,76,not curidx) then
 	 	 g_endregion()
	 	  callbackfn(nil,0)
 		  return
	 	 end
 	 
 	  -- items
	 	 local i=first
	 	 while i<=#list and g_y<110 do
	 	  local item=list[i]
 		  if g_txtbtn(gettextfn and gettextfn(item) or item,76,curidx==i,true) then
  	 	 g_endregion()
	 	   callbackfn(item,i)
	 	   return
 		  end 	  
	 	 	i+=1
 		 end
 	 
	 	 g_endregion()

	 	 -- mouse wheel logic
	 	 if hover then
	 	  first-=stat(36)
	 	 end
 	 
 		 -- click outside to close
	 	 if g_clk and not hover then
 		  return
	 	 end 	 

	 	 yield()
	 	end
  end)	
	end
	
	function g_msgbox(text,buttons,callbackfn)
	 g_co(function()
	  local result
	  while not result do
	 	 g_autonewline(false)
	  
	   -- modal region
	 		g_beginregion(24,50,104,88,nil,nil,true)
	 		map(0,21,16,42,12,6)
	 	 g_column(26,102,52)
	 	 
	 	 -- text
	 	 for t in all(text) do
		 	 g_label(t,90) g_newline()
		 	end
	 	 
	 	 -- buttons
	 	 for b in all(buttons) do
	 	  if(g_btn(b,32))result=b
	 	 end
	 	 
	 	 g_endregion()
	 	 yield()
	 	end
	 	if(callbackfn)callbackfn(result)	 		
		end)
	end	
end

-->8
-- data

-- constants
leveltypect=5

staffs={
	"1.sTARTING",
 "2.bLAST",
 "3.fLAME",
 "4.lIGHTNING",
 "5.fIREBALL"
}

editorcols={3,2,1,4,8,5}
editordesc={
 "tHEME",
 "dIFFICULTY",
 "sIZE",
 "sTAFF",
 "bOSS",
 "rANDOM sEED"
}

mainquest={
	"111006734",
	"121208244",
 "245004785",
	"256307653",
	"365007234",
	"374016996",
	"477405332",
	"489001976",
	"588508696",
	"593019494"
}

paldata=
[[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
1,2,3,4,5,6,6,8,9,10,11,12,13,14,15
1,2,3,4,5,6,6,8,9,10,11,12,13,14,15
1,2,3,4,5,13,6,8,9,10,11,12,5,14,6
1,2,3,2,5,13,6,8,9,9,11,12,5,4,6
1,2,3,2,5,13,6,4,4,9,3,13,5,4,13
1,2,3,2,1,13,13,4,4,4,3,13,5,4,13
1,2,3,2,1,13,13,2,4,4,3,13,5,4,13
1,1,3,5,1,5,13,2,4,4,3,1,5,2,13
1,1,1,2,1,5,13,2,4,4,3,1,1,2,5
0,1,1,2,1,5,5,2,5,5,3,1,1,2,5
0,0,0,1,1,5,5,2,5,5,3,1,1,2,5
0,0,0,0,1,5,5,0,5,5,0,1,1,2,5
0,0,0,0,1,1,5,0,0,5,0,1,1,2,5
0,0,0,0,0,1,1,0,0,1,0,1,1,1,1
0,0,0,0,0,1,1,0,0,1,0,1,1,1,1
0,0,0,0,0,1,1,0,0,0,0,0,0,0,1]]

leveltext={
[[aN OVERGROWN GRAVEYARD]],
[[a DESOLATE mAUSOLEUM]],
[[a HAUNTED GRAVEYARD]],
[[tUNNELS INTO THE MOUNTAIN]],
[[aN UNHOLY PLACE]]
}

-- state
fade,fadev=0,0
-->8
-- initialisation

function _init()
 cartdata("mot_sorcerer")

--	for i=0,100 do dset(i,0) end	

 pals={}
	for p in all(split(paldata,chr(10))) do
	 add(pals,split(p))
	end

	initanims()
	readplayerstate()
	loadepisode()
	
	local result=dget(2)	
	dset(2,0)

	if result==1 then
	
		-- level completed
		savelevelstats()

	 -- next level
		level+=1
  saveplayerstate()
  
  if main and level>#levels then
   setstate("gamewon")
  else
		 setstate("leveldone")
		end
 else
 	setstate("mainmenu")
	end	
end

-->8
-- misc

function rndrng(a,b)
 return a+flr(rnd(b-a))
end

-- pretty print
function printp(txt,x,y,col)
 col=col or 13
 print(txt,x,y+1,5) 
 print(txt,x,y,col) 
end

-- print centered
function printc(txt,col,y)
 x=(128-#txt*4)\2
 printp(txt,x,y,col)
end

function printcol(txt,cols,x,y)
 for i=1,#txt do
  local c=cols[min(i,#cols)]
  print(sub(txt,i,i),x+i*4-4,y,c) 
 end
end

function circinv(cx,cy,r)
	for y=0,96 do
	 local dy=y-cy
	 local dx2=r*r-dy*dy
	 if dx2<=0 then
	  rectfill(0,y,128,y,0)
	 else
	  dx=sqrt(dx2)
	  rectfill(0,y,cx-dx,y,0)
	  rectfill(cx+dx,y,128,y,0)
	 end
	end
end

function timestr(timer)
 local s=timer\1%60
 local m=timer\60%60
 local h=timer\3600%60
 return h..":"..digits(m)..":"..digits(s)
end
	
function digits(n)
 local str=tostr(n)
 if(#str==1)str="0"..str
 return str
end

-->8
-- ui

framect=0
nextupdatefn=nil

function _draw()
	if nextupdatefn then
		nextupdatefn()
		nextupdatefn=nil
	end
	if predraw[state] then
		predraw[state]()
	else
	 cls(0)
	end
 if anim then
  fadepal()
  clip(0,0,128,96)
  if animloop then
   anim:draw(animt%anim:duration(),animx,animy)
  else
   anim:draw(animt,animx,animy)
  end
  pal()
  clip()
  if postdraw[state] then
   postdraw[state]()
  end
  
  anim_events:framedone()
 end
 g_beg()
 if showui and ui[state] then
		g_column(32,96,70)
	 ui[state]()
 end
 g_end()
end

function _update()
 framect+=1
 if(anim)animt+=1/30
 fade=clamp(fade+fadev,0,1)
end

function setstate(newstate)
 -- exit current state
 anim_events:clr()
 
 -- switch
 local prvstate=state
 state=newstate
 
 -- initialise new state
 showui=true
 if(init[state])init[state](prvstate)
end

function transition(anim,fnorstate)
 if type(fnorstate)=="string" then
  aftertran=function()
   setstate(fnorstate)
  end
 else
 	aftertran=fnorstate
 end
 
 playanim(anim)
 setstate("transition")
end

init={
 mainmenu=function(prvstate)
  if prvstate~="newgame" then
   showui=false
	  playanim("title",false,64,40)
	 end
  defcursorpos(0,0)
  fade,fadev=0,0
  fadepal()
 end,
 newgame=function(prvstate)
  defcursorpos(0,0)
 end,
 editor=function()
  clearanim()
  defcursorpos(128,128)
 end,
 intro=function()
  playanim("intro",false)
 end,
 leveldone=function()
  local l=levels[level-1]
  local anim="l"..l.typ
  playanim(anim,false,64,48)
  fade,fadev=.5,0
  fadepal()  
 end,
 gamewon=function() 
  playanim("victory",false)
  fade,fadev=1,0
  fadepal() 
 end,
 levelintro=function()
  local l=levels[level]
  local anim="l"..l.typ
  playanim(anim,false,64,48)
  fade,fadev=1,-1/(30*1.5)
  fadepal()
 end,
 gamestats=function()

  -- read level stats
  stats={}
  gamestat={
   totalenem=0,
   gameenem=0,
   timer=0
  }
   
  local o=32
  for i=1,#levels do
		                       o+=1
	  local enemval=dget(o) o+=1
   local leveltimer=dget(o) o+=1
   local levelstat={
  		totalenem=enemval&0xffff,
  		levelenem=enemval<<16,
  		timer=leveltimer    
   }
   add(stats,levelstat)
   gamestat.totalenem+=levelstat.totalenem
   gamestat.gameenem +=levelstat.levelenem
   gamestat.timer    +=levelstat.timer   
  end

  playanim("stats",true,64,48)
  fade,fadev=0.8,0
  fadepal() 
 end
}

predraw={
 levelintro=function()
 	cls()
  local t=levels[level].typ  
  cols={13,6,0,0,0}
  fadepal()
  rectfill(0,0,128,96,cols[t])
 end
}

function fadecirc(x,y,crad,cstp)
 fillp(0x5f5f.8)
 circinv(x,y,crad-cstp*3)
 fillp(0x5a5a.8)
 circinv(x,y,crad-cstp*2)
 fillp(0x0a0a.8)
 circinv(x,y,crad-cstp)  
	fillp()
	circinv(x,y,crad)
end

postdraw={
 leveldone=function()
  fadecirc(64,48,44,2) 
 end,
 levelintro=function()
  fadecirc(64,48,44,2)
 end,
 gamestats=function()
  fadecirc(64,48,48,3)
 end
}

ui={
 mainmenu=function()
		if level>0 and level<=#levels then
			if(g_btn("cONTINUE gAME",64))transition("titlerv","levelintro")
		else
		 g_label("cONTINUE gAME",64,true,5)
		end
		if(g_btn("nEW gAME",64))setstate("newgame")
		if(g_btn("eDITOR",64))setstate("editor")
		if g_btn("qUICK lEVEL",64) then
		 if #levels>1 then
			 checkquitgame(quicklevel)
			else
				quicklevel()
			end
		end
	end,
	
	newgame=function()
  if g_btn("mAIN qUEST",64) then
  	checkquitgame(function()
  	 transition("titlerv",function()newstorygame(mainquest)end)
  	end)
  end
  if g_btn("rANDOM qUEST",64) then
   checkquitgame(function()newrandomgame(false)end)
  end
		if g_btn("aRCHMAGE qUEST",64) then
   checkquitgame(function()newrandomgame(true)end)
		end
  if(g_btn("bACK",64))setstate("mainmenu")
	end,
	
	leveldone=function()
		g_column(32,96,10)
	 g_label("lEVEL cOMPLETE",64,true,7)
	 g_label("")
	 g_label("tIME "..timestr(timer),64,true,7)
	 g_label("eNEMIES "..levelenem.."/"..totalenem,64,true,10)
  g_label("")
  local txt
  if not main then
	  txt=getleveltxt(levels[level-1])
	  g_label("sEED:"..txt,64,true,6)
	  g_label("(cTRL+c TO COPY)",64,true,6)
	 end
  	 
		g_column(32,96,100)
	 if g_btn("cONTINUE",64) then
			if level<=#levels then
		 	setstate("levelintro")
		 else
	   level=0
	   saveplayerstate()
	   if main then
				 setstate("gamewon")
				elseif #levels>1 then
				 setstate("gamestats")
				else
				 setstate("mainmenu")
				end		 
		 end	 	
	 end
	 if level<=#levels and g_btn("mAIN mENU",64) then
	  if(level>#levels)level=0
	  saveplayerstate()
	 	fade=0 
	 	setstate("mainmenu")
	 end
	 -- ctrl+c to copy key
  if not main and stat(31)==chr(194) then
  	printh(txt,"@clip")  	 
  	g_msgbox({txt,"cOPIED TO cLIPBOARD"},{"ok"})
  end
	end,
	
	gamewon=function()
		g_column(0,128,0)
	 g_setpos(100,115)
	 if(isanimdone() or g_btn("❎ skip",27) or btnp(❎))setstate("gamestats")
	end,
	
	editor=function()
		map()
 	g_column(16,120,6)
 	g_autonewline(false)
	 for i,l in ipairs(levels) do
	  local txt=getleveltxt(l)	  
	  txt=g_txtbox(txt,40,editorcols)
	  updatelevelfromtxt(l,txt)
	  if g_spritebtn(16,32) then
	   g_choosefromlist(staffs,nil,function(txt,staffi)	   
	    if txt then
			  	saveepisode()
			  	level =i
		 	 	health=10
		  		staff =staffi
		  		rungame()
		  	end
		  end)
	  end
	  if(g_spritebtn(5,6))levels[i]=generatelevel(i,#levels)
	  if #levels>1 and g_spritebtn(21,22) then
	   confirm("dELETE lEVEL?",function()del(levels,l)end)
   end	   
		 if g_spritebtn(37,38) and i>1 then
		  levels[i-1],levels[i]=levels[i],levels[i-1]
		 end
		 if g_spritebtn(53,54) and i<#levels then
		  levels[i+1],levels[i]=levels[i],levels[i+1]		 
		 end
	  g_newline()
	 end
	 if(#levels<10 and g_btn("aDD",16))add(levels,generatelevel(#levels+1,7))
	 g_setpos(68,105)
 	if g_spritebtn(3,35,35,2,2) then
 	 confirm("rEPLACE aLL lEVELS?",generateepisode)
 	end
 	g_y+=3
	 if g_btn("bACK",20) then
	  saveepisode()
	  setstate("mainmenu")
	 end
	 printcol("tdswbseed",editorcols,18,104)
	end,
	
	intro=function()
		g_column(0,128,0)
	 g_setpos(100,115)
	 if(isanimdone() or g_btn("❎ skip",27) or btnp(❎))startnewgame(true,false)
	end,
	
	transition=function()
	 if(isanimdone())aftertran()
	end,
	
	levelintro=function()
	 local t=levels[level].typ
--	 printp("sTAGE "..level,0,100,6)
	 printp(level..". "..leveltext[t],0,100,7)
		g_column(0,128,0)
	 g_setpos(95,115)
	 if(g_btn("❎ start",27) or btnp(❎))rungame()
	end,
	
	gamestats=function()
		printp("tIME",18,10,7)	
		printp("eNEMIES",84,10,10)	
	 for i,l in ipairs(stats) do
	  local y=i*8+10
	  printp(i,8,y,6)	  
	  printp(timestr(l.timer),18,y,7)
	  printp(l.levelenem.."/"..l.totalenem,84,y,10)
	 end

	  local y=102
--	  printp(i,8,y,6)	  
	  printp(timestr(gamestat.timer),18,y,7)
	  printp(gamestat.gameenem.."/"..gamestat.totalenem,84,y,10)
	
		g_column(0,128,0)
	 g_setpos(79,115)
	 if(g_btn("❎ main menu",48) or btnp(❎))setstate("mainmenu")
	end
}

function checkquitgame(fn)
 if level>0 then
  confirm("qUIT CURRENT GAME?",fn)
 else
  fn()
 end
end

function confirm(msg,fn)
 if(type(msg)=="string")msg={msg}
 g_msgbox(msg,{"yES","nO"},
 	function(choice)
 	 if(choice=="yES")fn()
 	end)
end

function getleveltxt(l)
 return l.typ..l.dif..l.roomct..l.staff..l.boss..(l.seed\1000%10)..(l.seed\100%10)..(l.seed\10%10)..(l.seed%10)
end

function updatelevelfromtxt(l,txt)
 local d=split(txt,"")
 l.typ   =clamp(d[1],1,leveltypect)
 l.dif   =clamp(d[2],1,9)
 l.roomct=clamp(d[3],1,9)
 l.staff =clamp(d[4],0,#staffs)
 l.boss  =clamp(d[5],0,1)
 l.seed  =d[6]*1000+d[7]*100+d[8]*10+d[9]
end

function fadepal()
 pal(pals[flr(fade*(#pals-1))+1])
end

function defcursorpos(x,y)
 if not g_mousemode then
	 nextupdatefn=function()
	  g_mx,g_my=x,y
	 end
	end
end

function quicklevel()
 g_co(function()
  local result,done
  local l=generatelevel(rnd(8)+1,8)
  while not done do
 	 g_autonewline(false)
  
   -- modal region
 		g_beginregion(24,50,104,88,nil,nil,true)
 		map(0,21,16,42,12,6)
 	 g_column(26,102,52)
	  local txt=getleveltxt(l)	  
	  txt=g_txtbox(txt,40,editorcols)
	  updatelevelfromtxt(l,txt)
	  if(g_spritebtn(5,6))l=generatelevel(rnd(8)+1,8)
		 printcol("tdswbseed",editorcols,28,61)
	 	g_newline()		  
	 	g_newline()
	 	if(g_btn("ok",32))    result=true  done=true
	 	if(g_btn("cancel",32))result=false done=true
 	 g_endregion()
 	 yield()				 	
	 end
	 if result then
   g_choosefromlist(staffs,nil,function(txt,staffi)
   	if txt then
					levels={l}
		  	saveepisode()
					main  =false
		  	level =1
	 	 	health=10
	  		staff =staffi
	  		rungame()
	  	end
	  end)
	 end
 end) 
end
-->8
-- animation system

-- shared animation code
-- tHIS TAB CONTAINS ALL CODE 
-- NECESSARY TO LOAD AND PLAY
-- ANIMATIONS.

-- constants
animfilever=1

-- routines

function runcoroutines(co)
	for c in all(co) do
		if costatus(c)=="dead"then
			del(co,c)
		else
			assert(coresume(c))
		end
	end
end

function lerp(a,b,f)
 return (1-f)*a+f*b
end

function clamp(v,mn,mx)
	return min(max(v,mn),mx)
end

function sprcoords(n)
	return (n%16)*8,flr(n/16)*8
end

function tilecoords(n)
 return n%128,flr(n/128)
end

function smap(cx,cy,cw,ch,sx,sy,sw,sh,flipx,flipy)
 -- delta
 local dx,dy=cw/sw,ch/sh
 
 -- apply flip
 if flipx then
  cx+=cw
  dx=-dx
 end
 if flipy then
  cy+=ch
  dy=-dy
 end
 
 local x0,x1=sx,sx+sw
 local y0,y1=sy,sy+sh
 cx+=(ceil(x0)-x0)*dx
 cy+=(ceil(y0)-y0)*dy
 x0,y0,x1,y1=ceil(x0),ceil(y0),ceil(x1)-1,ceil(y1)-1

 -- render with tlines
 for y=y0,y1 do
  tline(x0,y,x1,y,cx,cy,dx,0)
  cy+=dy
 end
end

-- file i/o

-- stream helpers

function read2(self)
 return self:read1()|(self:read1()<<8)
end

-- memory stream

function mem_size(self)
	return self.addr-self.baseaddr
end

function mem_r1(self)
 local v=peek(self.addr)
 self.addr+=1
 return v
end

function readmemstream(addr)
	return {
		baseaddr=addr,
		addr=addr,
		size=mem_size,
		read1=mem_r1,
		read2=read2
	}
end

-- hex string stream

function fromhexchar(c)
 return ord(c)-(c>"9" and 87 or 48)
end

function str_size(self)
	return #self.str/2
end

function str_r1(self)
 local str,offs=self.strs[flr(self.offs>>10)+1],self.offs&0x3ff
 offs+=1
 local hi=fromhexchar(sub(str,offs,offs))
 offs+=1
 local lo=fromhexchar(sub(str,offs,offs))
 self.offs+=2
 return (hi<<4)|lo
end 

function readstrstream(strs)
	return {
		strs=strs,
		offs=0,
		size=str_size,
		read1=str_r1,
		read2=read2
	}
end

-- helper functions

function readstrfixed(stream,len)
	local result=""
	for i=1,len do
		result..=chr(stream:read1())
	end
	return result
end

function readstr(stream)
	local len=stream:read1()
	return readstrfixed(stream,len)
end

-- file io

function loadanims(stream)
	printh("*** loading animations ***")

	-- verify header and version
	local hdr=readstrfixed(stream,3)
	if hdr~="mas" then
		printh("'mas' header not found")
		stop()
	end
	
	local ver=stream:read1()
	if ver>animfilever then
		printh("unsupported file version: "..ver)
		stop()
	end
	
	-- load each animation
	local ct=stream:read1()
	local anims={}
	for i=1,ct do
		local typ=stream:read1()
		local anim
		if typ==1 then
			anim=loadspriteanim(stream)
		else
		 anim=loadtlanim(stream,typ)
		end
		add(anims,anim)
		anims[anim.name]=anim
	end
	
	-- convert indices into references
	for anim in all(anims) do
	 if anim.typ~="sprite" then
	  for tl in all(anim.tls) do
	   for k in all(tl.keyframes) do
	    k.anim=k.anim and anims[k.anim]
	   end
	  end
	 end
 end

	return anims
end

function loadspriteanim(stream)
	local anim=makespriteanim()
	
	-- properties
	anim.name=readstr(stream)
	anim.subtype=stream:read1()
	anim.fps=stream:read1()/4
	anim.w=stream:read1()
	anim.h=stream:read1()
	anim.ox=stream:read1()/100
	anim.oy=stream:read1()/100

	-- frames
	anim.frames={}
	local ct=stream:read1()
	for i=1,ct do
		local frame={}
		frame.frame=stream:read2()
		local flags=stream:read1()
		frame.flipx=(flags&1)==1
		frame.flipy=(flags&2)==2
		add(anim.frames,frame)
	end
	
	return anim   
end

function loadtlanim(stream,typ)
 local anim=maketlanim()
 if(typ==3)anim.typ="storyboard"
 
	-- properties
	anim.name=readstr(stream)
	anim.d=stream:read2()/100
	
	-- timelines
	anim.tls={}
	local ct=stream:read1()
	for i=1,ct do
	 local keyframes={}
	 local kct=stream:read1()
	 for j=1,kct do
	 
	  -- time
	  local t=stream:read2()/100
	  local k=makekeyframe(t)
	  
	  -- content 
	  local flags=stream:read1()
	  if (flags&1)~=0 then 
	  	k.anim=stream:read1()		-- will be converted to object reference later
			end
	  if (flags&2)~=0 then
	  	k.x=stream:read2()
	  	k.y=stream:read2()
	  end
	  if (flags&4)~=0 then
	   k.xscale=stream:read2()/100
	   k.yscale=stream:read2()/100	   
	  end
	  if (flags&8)~=0 then
	   k.animt=stream:read2()/100
	   k.animspd=stream:read2()/100
	  end 
	  
	  -- state flags
	  flags=stream:read1()
	  k.flipx=(flags&1)~=0
	  k.flipy=(flags&2)~=0
	  k.visible=(flags&4)~=0
	  k.loop=(flags&8)~=0
	  
	  add(keyframes,k)
	 end
	 add(anim.tls,{keyframes=keyframes})	 
	end
	
	-- events
	anim.events.keyframes={}
	local ct=stream:read1()
	for i=1,ct do
	
  -- time
  local t=stream:read2()/100
	 local k=makeevent(t)
	 
	 -- type
	 k.typ=readstr(stream)
	 local flags=stream:read1()
	 if (flags&1)~=0 then
  	k.x=stream:read2()
  	k.y=stream:read2()	 	
  end
  if (flags&2)~=0 then
   k.n=stream:read1()
  end
  if (flags&4)~=0 then
   k.txt=readstr(stream)
  end	 
  add(anim.events.keyframes,k)
	end
	
	return anim
end

-- sprite animations

function drawanim(
		self,
		t,
		x,y,
		xscale,yscale,
		flipx,flipy,
		dt)
		
 self:dodraw(
 	t or 0,
 	x or 64,
 	y or 64,
 	xscale or 1,
 	yscale or 1,
 	flipx,
 	flipy,
 	dt or 1/(_update and 30 or 60),
 	0)
end

function spriteanim_draw(self,t,x,y,xscale,yscale,flipx,flipy)

	-- find frame
	local f=clamp(flr(t*self.fps)+1,1,#self.frames)
	local frame=self.frames[f]

	-- display width and height
	local dw,dh=self.w*8*xscale,self.h*8*yscale
	
	-- flip flags
	if(frame.flipx)flipx=not flipx
	if(frame.flipy)flipy=not flipy

	-- adjust for orgin pt
	x-=dw*(flipx and (1-self.ox) or self.ox)
	y-=dh*(flipy and (1-self.oy) or self.oy)

	-- draw
 if self.subtype==1 then	

		-- as sprite coords
		local sx,sy=sprcoords(frame.frame)
		sspr(
			sx,sy,
			self.w*8,self.h*8,
			x,y,
			dw,dh,
			flipx,flipy)
	
	else
	
		-- as tilemap coords
		local cx,cy=tilecoords(frame.frame)
		smap(
		 cx,cy,
		 self.w,self.h,
		 x,y,
		 dw,dh,
		 flipx,flipy)
	end		
end

function spriteanim_duration(self)
	return #self.frames/self.fps
end

function makespriteanim()
	return {
		typ="sprite",
		subtype=1, -- 1=sprite, 2=tiles
		name="sprite",
		fps=10,
		w=1,h=1,
		ox=0.5,oy=0.5,
		frames={
			makespriteframe(1),
		},
		duration=spriteanim_duration,
		dodraw=spriteanim_draw,
		draw=drawanim
	}
end

function makespriteframe(n)
	return {
		frame=n--,
--		flipx=false,
--		flipy=false
	}
end

-- timelined animations

function tlanim_duration(self)
	return self.d
end

keyframeswitch=split("anim,animt,animspd")
keyframelerp=split("x,y,xscale,yscale")
keyframeflags=split("flipx,flipy,visible,loop")

function findrefkeyframes(tl,prop,t)
 -- find nearest frames before/after t
 -- where property is not null
 local before,after
 local beforet,aftert=-1000,1000
 for k in all(tl.keyframes) do
  if k[prop] then
   if k.t<=t and k.t>beforet then
    before,beforet=k,k.t
   end
   if k.t>t and k.t<aftert then
    after,aftert=k,k.t
   end
  end
 end
 return before,after
end

function getvirtualkeyframe(tl,t)

 -- calculate the effective 
 -- "virtual" keyframe at time t
 -- on the timeline, interpolating
 -- as necessary.
 local props={
  visible=true,
  animt=0,animspd=1,
  x=0,y=0,
  xscale=1,yscale=1,
  flipx=false,flipy=false
 }

	-- switchover properties
 local animtt				
	for prop in all(keyframeswitch) do
	 before,after=findrefkeyframes(tl,prop,t)
	 local frame=before or after
	 if(frame)props[prop]=frame[prop]
		if prop=="animt" then
		 animtt=before and before.t
		end
	end

	-- interpolated properties
	for prop in all(keyframelerp) do
	 before,after=findrefkeyframes(tl,prop,t)
  if before and after then
   props[prop]=lerp(before[prop],after[prop],(t-before.t)/(after.t-before.t))
  else
		 local frame=before or after
		 if(frame)props[prop]=frame[prop]
		end			  
	end
	
	-- flags
	before,after=findrefkeyframes(tl,"t",t)
	local k=before or after
	if k then 
	 for prop in all(keyframeflags) do
	  props[prop]=k[prop]
	 end
	end
	
	-- calculate effective animt
	-- at time t, taking into account
	-- animation speed an looping.
	if animtt then
	 props.animt+=(t-animtt)*props.animspd
	end
	if props.loop and props.anim then
	 props.animt%=props.anim:duration()
	end
	return props
end

function tlanim_draw(self,t,x,y,xscale,yscale,flipx,flipy,dt,r)
 -- recursion limit
 r+=1
 if(r>10) return
 
	-- trigger events
	if dt then
	 for k in all(self.events.keyframes) do
	  if k.t>t-dt and k.t<=t and anim_events[k.typ] then
    anim_events[k.typ](k,x,y)
	  end
	 end
	end	 
 
 -- draw anims for each timeline
 for tl in all(self.tls) do

  -- get effective keyframe for t
		local props=getvirtualkeyframe(tl,t)
		
		-- draw child animation
		if props.visible and props.anim then
		
		 -- calculate effective position,scale and flip
		 local cx=x+props.x*xscale*(flipx and -1 or 1)
		 local cy=y+props.y*yscale*(flipy and -1 or 1)
		 local cxscale,cyscale=xscale*props.xscale,yscale*props.yscale
		 local cflipx,cflipy=flipx,flipy
   if(props.flipx)cflipx=not cflipx
   if(props.flipy)cflipy=not cflipy
   local cdt=dt and dt*props.animspd
		 
		 -- draw
		 props.anim:dodraw(props.animt,cx,cy,cxscale,cyscale,cflipx,cflipy,cdt,r)
		end		
	end	
end

function makekeyframe(t)
	return {
		t=t,
		anim=nil,
		loop=true,
		after=false,
--		animt=nil,
--		animspd=nil,
--		x=nil,
--		y=nil,
--		xscale=nil,
--		yscale=nil,
		visible=true,
		flipx=false,
		flipy=false
	}
end

function makeevent(t,typ)
 return {
  t=t,
  typ=""--,
--  x=nil,
--  y=nil,
--  n=nil,
--  txt=nil
 }
end

function maketl()

 -- default keyframe
 local k=makekeyframe(0)
 k.animt,k.animspd,k.x,k.y=0,1,0,0
 
	return {
		keyframes={k}	
	}
end

function maketlanim()
	return {
		typ="tl",
		name="timeline",
		d=10,
		tls={ maketl() },
		events={ keyframes={} },
		duration=tlanim_duration,
		dodraw=tlanim_draw,
		draw=drawanim
	}
end

-- events

do 
 local afterframeco={}
	local function doafterframe(fn)
		 add(afterframeco,cocreate(fn))
 end
 
 anim_events={
  sfx=function(ev)	sfx(ev.n)         end,
  mus=function(ev) music(ev.n or -1) end,
  txt=function(ev)
   doafterframe(function()
    for i=1,ev.n or 30 do
     print(ev.txt,ev.x,ev.y)
     yield()
    end
   end)
		end,
  reltxt=function(ev,x,y)
   doafterframe(function()
    for i=1,ev.n or 30 do
     print(ev.txt,x+(ev.x or 0),y+(ev.y or 0))
     yield()
    end
   end)
		end,
		clr=function()
		 afterframeco={}
		end,

		-- schedule code to execute after the frame
		-- can use yield() to execute after multiple frames
		doafterframe=doafterframe,
  
  -- call this after the frame is rendered
		framedone=function()
		 runcoroutines(afterframeco)
		end
 }
end
-->8
-- implementation

function continuegame()
 rungame()
end

function newstorygame(leveltxts)
 levels={}
 for txt in all(leveltxts) do
  local l={}
  updatelevelfromtxt(l,txt)  
  add(levels,l)
 end

 -- save to cart data
 saveepisode()
 
 setstate("intro")
end

function newrandomgame(hard)
	epseed=rnd(0xffff.ffff)

	-- generate episode
 srand(epseed)
 generateepisode(hard)
 
 -- save to cart data
 saveepisode()
 
 startnewgame(false,hard)
end

function startnewgame(ismain,hard)
 -- initial player state
 level =1
 staff =hard and 2 or 1
 health=10
 main  =ismain
 
 setstate("levelintro")
end

function rungame()
 saveplayerstate()
 load("#mot_sorcerergame")
end

function readplayerstate()
 level =dget(5)
 staff =dget(6)
 health=dget(7)
 main  =dget(9)~=0
end

function saveplayerstate()
 dset(5,level)
 dset(6,staff)
 dset(7,health)
 dset(9,main and 1 or 0)
end

function generateepisode(hard)
 local epct=hard and rndrng(7,10) or rndrng(5,10)
 levels={}
	local startstaff=hard and 2 or 1
	local prvstaff=startstaff
 local genstaff=rnd(.75)+startstaff
 for i=1,epct do
		genstaff+=(#staffs-startstaff)/epct
  local l=generatelevel(i,epct,hard)
  l.staff=genstaff\1>prvstaff and genstaff\1 or 0
 	add(levels,l)
		prvstaff=genstaff\1
 end
 main=false
 saveplayerstate()
end

function generatelevel(i,epct,hard)
	local typ,roomct,dif,boss
	typ=flr(i/epct*leveltypect+rnd(2)-.5)
	if hard then
 	roomct=flr(i/epct*6+rnd(4)+1)
 	dif=flr(i/epct*6+5)
		boss=i==epct or (i>=epct\2 and i%2==0)
	else
 	typ=flr(i/epct*leveltypect+rnd(2)-.5)
 	roomct=flr(i/epct*8+rnd(4)-1)
 	dif=flr(i/epct*8+1)
		boss=(i==epct or i==epct\2) and rnd(2)<1
	end
 return {
	 typ=mid(typ,1,leveltypect),
	 roomct=mid(roomct,1,9),
	 dif=mid(dif,1,9),
	 staff=0,
	 boss=boss and 1 or 0,
	 seed=rnd(10000)\1
	}
end

function saveepisode()
 local o=10
 dset(o,epseed) o+=1
 dset(o,#levels) o+=1
 for l in all(levels) do
	 dset(o,
	   (l.boss>>4)
	 	|(l.typ)
	 	|(l.roomct<<4)
	 	|(l.dif<<8)
	 	|(l.staff<<12)) o+=1
 	dset(o,l.seed) o+=1
 end
end

function loadepisode()
 local o=11
 levels={}
 local ct=dget(o) o+=1
 for i=1,ct do
  local flags=dget(o) o+=1
  local seed=dget(o) o+=1
--  printh(tostr(flags,true)..","..tostr(seed,true))
  add(levels,{
  	typ=flags&0x0f,
  	roomct=(flags>>4)&0x0f,
  	dif=(flags>>8)&0x0f,
  	staff=(flags>>12)&0x0f,
			boss=(flags<<4)&0x0f,
  	seed=seed
  })
 end
end

function initanims()
	stream=readstrstream(animdata)
	anims=loadanims(stream)
	anim_events.ui=function(ev)
	 showui=ev.n~=0
	end
 anim_events.txt=function(ev)
  anim_events.doafterframe(function()
   for i=1,ev.n or 30 do
    printp(ev.txt,ev.x,ev.y,7)
    yield()
   end
  end)
	end
	anim_events.fin=function(ev)
	 fade,fadev=1,-1/((ev.n or 3)*30)
	 fadepal()
	end
	anim_events.fout=function(ev)
	 fade,fadev=0,1/((ev.n or 3)*30)
	 fadepal()
	end
end

function playanim(name,loop,x,y)
 anim=anims[name]
 animloop=loop
 animt=0
 animx,animy=x,y
end

function clearanim()
 anim=nil
end

function isanimdone()
 return not anim or animt>=anim:duration()
end

function savelevelstats()

 -- read stats for just completed level
 local enemval=dget(63)
 totalenem,levelenem=enemval&0xffff,enemval<<16  
 timer=dget(4)
  
 -- save stats in level slot
 local o=(level-1)*3+32
	                o+=1
 dset(o,enemval) o+=1
 dset(o,timer)   o+=1  
end
-->8
animdata={
"6d6173014e0103626174022803013232021900001c0000010462617432022803013232029900009c00000103626c64022802013232014506000105626f6e6573022802013232014306000105626f6f6d31012801013232058800008900008a00008b00007a00000105626f6f6d32012801013232068800009800009900009a00009b00007a00000104626f737302280603323201c002000104627573680228020232320123000001046368616e022802043232014304000103636f6c0228020a323201c70200010563726f737302280305326401400400010564656d6f6e02230402326402150000150100010664656d6f6e32022304023264021901001d0100010365796501280101323201a800000105666c616d65022801023232042c06002d06002e06002f060001046761746502280c083264014900000103676e64022810083232014904000104676e6432022810083232014908000103676f62022802023264040808000a08000809000a090001046772617902281002323201300b00010468616e6402280102326401460500010568696c6c7302281208326401150300010668696c6c733202281b063264010f07000105686f757365022803023264012d04000106686f75736533022803023264012d050001036d6f740128030123320156000001066f662074686501280301323201460000010470696b65022801",
"03326401c603000104736b656c021302053264040008000208000408000608000103736b79022810103232013000000104736b7932022810103232013007000105736d6f6b65012801013232059300008300009200008200007a00000103736f7202130305323d024300004600000104736f7232022804043232010c0a000108736f726365726f7201280b022d32016000000105737461666602280508323201100000010673746166663202170303323202100a00130a0001047374616c02280202320001c006000103746f7202280102323201c602000106747265656c67022805083264012b00000106747265656d6402280305325a01280000010674726565736d022803023264012500000105747269616c01280602323201400000010476696e65022801043232014504000305696e74726f882c010800000b3b000000000000640004e803093c00006400049411093d0000640004d417093e0000640004901a09300000640004bc1b093f00006400049821094000006400045c2b09300000640004000307766963746f72791c0c010300000b300000000000006400042c01094e0000640004f00a0930000064000400020462617473e803040100000b0100000000000064000c0100000b01d8fffaff000064000c0100000b012200fcff000064000c0100000b010700f5ff000064000c000205626c616e6b2c010101",
"00000a00000000000064000c00020666697265776b6400040100000b05000000000000640004021e000b06090006000000640004000000000228000b05f4ff03000000640004000000080237000b050a00fbff000064000402000000000206676174656267e803030100000b1e00000000000064000c0100000f100000100086008600000064000c0100000f1100006e006400c800000064000c00020668696c6c7333e803030100000b1677ff0000000064000c0100000b1727000000000064000c0100000b16db000000000064000c00020668696c6c7334e803040100000b169cff0000000064000c0100000f176900000050006400000064000c0100000b1746010000000064000d0100000b16d3fe0000000064000c000206686f75736532e803020100000b490800f1ff000064000c0100000b1800000000000064000c000206686f75736566e803060100000b1800000000000064000c0100000b0ff8fff5ff000064000c0100000b0f0800f8ff1e0064000c0100000b0ffefff1ff140064000c0100000f49fbfff3ffc800c800000064000c0100000b490200f4ff460064000c000206686f75736573e803030100000b18e2ff0700000064000c0100000b3504000400320064000c0100000b3522000a00000064000c000207686f7573657332e803030100000b19e5ff0500000064000c0100000f36060001005b00",
"5b003c0064000c0100000b362d000700000064000c000207686f7573657333e803040100000b3a00000000000064000c0100000b3a60ff0000000064000c0100000b3a8d000000000064000c0100000b18bcff0100000064000c000207686f7573657334e803030100000b18d7ff0400000064000c0100000f18000000005a005a00000064000c0100000b1824000500000064000c00020a693120646964206e6f74e803010100000a00000000000064000c01c800037478740700006400961f776520646964206e6f7420616c7761797320636f77657220696e2066656172020769322066726565ac0d070100000b1e0000f0ff000064000c0200000b172a000000000064000c580202ecff00000c0200000b3761000000000064000c580202000000000c0200000b1611000d00000064000c5802029fff0d000c0203020b1691001b00000064000c58020278001b000c04dc050b21b2ff1400000000000c6c0702d1ff14000c7d0808000064000cbb0c08000000000c031e090b31f4ffcfff000064000c00000008bb0c0008086400037478740700006400961774686973206c616e6420776173206f6e6365206672656500000366696e002003037478740700006400961570656f706c65206c6976656420696e20706561636540060374787407000064007820616e6420776520736f72636572657273207374726f646520",
"746865206c616e64d007037478740700006400780d6c696b652064656d69676f6473c3090374787407000064007813666c61756e74696e67206f7572206d61676963540b037478740700006400780e666f7220616c6c20746f207365657f0c04666f757400020969332061776f6b656e4006020100000a00000000000064000c0300000f072400130064006400000064000890010624000800640064000c400606f1fffbffc800c8000c056400037478740700006400961a627574206f757220707269646520776173206f7572207275696e90010366696e020abc020374787407000064007820666f72206f7572207370656c6c73206177616b656e656420746865206576696c4c0403747874070000640078196261686d6f74742c206465657020696e20686973206c616972510404666f75740205020a6934206d696e696f6e73bc020a0100000b1f0000f0ff000064000c0100000b1700000000000064000c0300000f132600080032003200000064000c96000618000800320032000c5e010e17001500640064001e0000000c0100000b3800000400000064000c0300000f13cdff0f0046004600000064000c2c0102fbff0f000cc2010e0500160064005a00000000000c0100000b1774ff1600000064000c0100000b178b001c00000064000c0300000f2f0000d0ff0f000f00000064000c3101060000d0ff64006400",
"0c5d0206000092ffc800c8000c02bc020f1df0ff200064005a00000000000c00000ef7ff0f0032003200000064000c032c010f0c4b00c0ff28002800000064000cf401050d640064000cbc0206fdff2000900190010c0300000366696e006400037478740700006400961e77686f20666c6f6f64656420746865206c616e642077697468206576696cf40104666f757402020209693520726573697374dc05090100000b1f0000f0ff000064000c0100000b1789ff0000000064000c0100000f1d1a000d0050005000000000000c0100000b0d050008000a0014000c0200000b0cecff070000001e000cbc02010d0c0300000f31f3ffeeffbe00be0000006400085e01000c200300080300000f311400f9ff960096006e006400093601000d6504000903fa000f21deff1100be00c800000064000c000002a5ff11000cc003094a00006400040313010f2128001a00fa00fa00000064000d3200025f001a000d3903094a00006400050400000366696e020164000374787407000064009619736f7263657265727320747269656420746f20726573697374bc0203747874070000640096097765206661696c6564b00404666f75740002086936206272617665c4090203d0070f320000f8ff64006400000064000c000002000088ff0cc30904c800c8000c0297080b241a001300000064000cd606022e0045000c07c8000366",
"696e020a64000374787407000064008c176e6f772070656f706c65206869646520696e20666561725802037478740700006400781c6177616974696e67206120736f72636572657220736f206272617665e803037478740700006400781a617320746f20656e746572206261686d6f74742773206c6169727805037478740700006400780e736c6179207468652064656d6f6e0807037478740700006400781d616e6420726573746f726520706561636520746f20746865206c616e645f0904666f7574020102026c31e803060100000b1e0000fcff000064000c0100000b2a1b001000000064000c0100000b0825000f00000064000c0100000f0b1400140046004600000064000c0100000b28e8ff1d00000064000c0100000b0b06002200000064000c0002026c32e803060100000b0af2ffedff000064000c0100000f0a0600eeff3c003c00000064000c0100000f0a1300edff28002800000064000c0100000f2cffffdbff96009600000064000c0100000b2c1f00d4ff000064000c0100000b041f000a00000064000c0002026c33e803070100000b1f0000e9ff000064000c0100000b1200003800000064000c0100000b1c1a00feff000064000c0100000f0bfeff030046004600000064000c0100000b27f2ff0000000064000c0100000b0be1ff1600000064000c0100000f0b0d004600c800c800000064000c00",
"02026c34e803080100000f140000250064009001000064000c0100000b091100e8ff000064000c0100000f26f9ffd0ff9600c800000064000c0100000f09eaffe1ffc800c800000064000c0100000f261d00d4ff64009600000064000c0100000f04fcff210096009600000064000c0100000b041b001500000064000c0100000f260b00d2ff3c006400000064000d0002026c35e803060100000f03eaff0b00aa007800000064000c0100000f031000fdff73005000000064000d0100000b1cf4fff7ff000064000c0100000b150a001500000064000c0100000f030500f3ff50003200000064000c0100000f1c1300ebff32003200000064000c0002096c616e64677265656ee803010100000e0000000064006400000064000c0002067363726f6c6ca00f040100000b1e00000000000064000c0200000f335400100046004600000064000ca00f027fff10000c0200000b39d2001200000064000ca00f0274ff12000c0200000b3419012800000064000ca00f02e9fe28000c000206736d6f6b65326400010200000b200000000000003200046400020000f2ff04000206736d6f6b6533c800030100000b4800000000000064000c0100000b4800000000280064000c0100000b4800000000500064000c000207736f7266616c6c9001020300000b250300efff000064000c2c010203001d000ca7000a03000400000000",
"000c0200000b2200000000000064000cfa0002000030000c0002057374617473a00f010100000b4700000000000050000c0002057469746c65f401050200000b2bacfff2ff000064000c3200020000f2ff0c022d000b236c000700000064000c640002000007000c0300000b1b00000000000064000c280004640000000c640004640064000c030000091a000064000c96000624001500640000000cb40004640065000c022c010a40001400000064000cbe00032456001d000c0200000275690200c800027569020102077469746c657276c800010100000b4c0000e8ff2c0138ff04000205766d61696ec409020200000b470000f1ff8c0564000cd007085c0d00000c02d00707212c000a00c800c8000def060a58000a00000000000d0532000366696e0205c80003747874070000640096167468652064656d6f6e2069732064657374726f7965642003037478740700006400961c686973206372656174757265732068617665207363617474657265647805037478740700006400962070656f706c652063616e2066696e616c6c79206c69766520696e207065616365970804666f75740203",
"",
"",
"",
"",
"",
"",
"",
""}