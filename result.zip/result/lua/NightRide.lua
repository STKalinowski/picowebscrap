--night ride
--vlad-constantin comarlau
--august 2020

function _init()
	init()
	reset()
end

----------------------------

function _update()

--title
if level==0 then
	car_x=1
	if time()<0.1 then
		music(2)
	end
	if ty1>20 then ty1=11 end
	if ty2>20 then ty2=11 end
	if (btn(4) or btn(5)) 
	and time()>4 then
		trans=1
		music(-1,400,3)
		sfx(15)
	end
	if trans_e>0.9 then
		level=1
		reset()
	end
end

if level==7 then
	if level_p>-1.2 and level_p<-1 then
			music(47,3000,2)
	end
	if level_p>70 and level_p<71 then
			music(-1,8000,2)
	end
end

	if level==8 and level_p > -9 and level_p < -8 then
		music(51,0,3)
	end
	
	if level>7 and level_p>247 and level_p<266 then
		music(0,0,3)
	end
	
if level_p>1 and level_p<2 then
	if	 level==1 then
		music(4,3000,2)
	end
end
if level==9 and level_p>304 and level_p<305 then
	music(23)
end
if col_d then
	music(-1)
end

--car
--horizontal movement
if btn(0) then
	if not s_disable then
		car_r_target = 10
	end
elseif btn(1) then
	if not s_disable then
		car_r_target = -10
	end
else
 car_r_target = 0
end
--shooting
if (level==5 and level_p>30) 
or level>5
then
	shoot_enabled=true
end
shoot_x+=((car_x*0.6-shoot_x)/7)+2

if shoot>0 then
	shoot-=1
end
if level>4 and not hit
and (btn(4) or btn(5))
and shoot<1
and level_p > 2
then
	if shoot_enabled then
		shoot=15
	end
end

--vertical movement
add_speedometer = 0
if   btn(2) 
and  c_disable==0
and  not hit
and  not (level==8 and level_p>240)
then
	car_y_target = 
	-10*((5-abs(rotation*1.3))*0.4)
	
	add_speedometer = -3
elseif btn(3) and c_disable==0 then
	car_y_target = 175
else
	car_y_target = 100
end
c_disable=0

if hit then
	car_y+=car_s*1.3
	for i=1,3 do
		add_spark(car_x*0.6+27,car_y*0.7-5,
												8,level_p-0.1,0)
	end
	add_explosion(car_x*0.6+17,car_y*0.7-10,
												20,0.7,level_p-0.1)
--e=x, r=y, l=life, s=size, t=time 
end

if level>0 then
	car_s=150/(car_y+195) * 10
else
	car_s=0
end
if hit then
	car_s=4
end
--road
lines_y  -= car_s*v_speed
walls_y  -= car_s*v_speed
lights_y -= car_s*v_speed
bridge_y -= car_s*v_speed

if lines_y < 30 then
	lines_y = 54
end

if walls_y < 30 then
	walls_y = 45
end

if lights_y < -8 then
	lights_y = 90
end

if bridge_y < -2000 then
	bridge_y = 90
end

car_x -= rotation*0.7

--limits horizontal sidewalls 
if sidewall_y > 80 and
			sidewall_y < 220 
			then
				steer_limit=-1
elseif sidewall_y2 > 80 and
			sidewall_y2 < 220 
			then
				steer_limit=1
else
				steer_limit=0
end

if steer_limit==-1 then
	if car_x<70 then 
		car_x,car_r_target=70,-20
		sfx(2)
		add_spark(car_x*0.05+62,car_y*0.7+12,
												8,level_p-0.1,0)
	end
else
	if car_x<-37 then 
		car_x,car_r_target=-37,-20
		sfx(2)
		for i=1,2 do
			add_spark(car_x*0.05+4,car_y*0.7+12,
												8,level_p-0.1,0)
		end
	end
end
if steer_limit==1 then
	if car_x>55 then 
		car_x,car_r_target=55,20
		sfx(2)
		add_spark(car_x*0.77+20,car_y*0.7+12,
												8,level_p-0.1,0)
	end
else
	if car_x>162 then 
		car_x,car_r_target=162,20
		sfx(2)
		for i=1,2 do
			add_spark(car_x*0.77+2,car_y*0.7+12,
												8,level_p-0.1,0)
		end
	end
end

--limits vertical
if  not hit 
and not (level==8 and level_p>240)
then
	if car_y>135 then 
		car_y,car_y_target=135,135 
	end
	if car_y<-10 then 
		car_y,car_y_target=-9,-9
	end
	
	if  limit_v==1 
	and car_y<30
	then
		car_y,car_y_target=30,30
	end
end

--traffic collisions
if col_l and rotation<0 then
	car_r_target=20
	add_spark(car_x*0.5+37,car_y*0.7+12,
												8,level_p-0.1,0)
end
if col_r and rotation>0 then
	car_r_target=-20
	add_spark(car_x*0.5+32,car_y*0.7+12,
												8,level_p-0.1,0)
end
if col_d
and not hit
then
	hit = true
	sfx(3)
end
rotation+=(car_r_target-rotation)/12

collide_sw()

-- heli
move_heli()

--vertical movement
car_y+=(car_y_target-car_y)/50

--collision with traffic
col_l,col_r,col_u,col_d 
= false,false,false,false

--traffic
	for car in all(cars) do
		if car.y > 128 then
			del(cars,car)
		end
		
		--ai
		if not hit then
			car.y += car_s*0.5+level*0.2
			if car.y>20 and car.y<23 then
				sfx(0)
			end
		else
			car.y -= 2
		end
		car.nearby=-1
		--check other cars nearby
		for v=1,count(cars) do
			if  cars[v].x>car.x-30
			and	cars[v].x<car.x+30
			and cars[v].y>car.y-20
			and	cars[v].y<car.y+20
			then
					car.nearby+=1
			end
		end
		--check player collision
		if  car_x*0.6+26>car.x-8
		and car_x*0.6+26<car.x+20
		and car_y*0.6+32>car.y
		and car_y*0.6+32<car.y+40
		then
			if car_x*0.6+26<car.x+8 then
				col_l=true
			else
				col_r=true
			end
			sfx(2)
			if car_y*0.6+32>car.y+35 then
				if  car_x*0.6+26>car.x-4
				and car_x*0.6+26<car.x+15
				then
					col_d=true
				end
			else
				col_u=true
			end
		end
		
		--lane switching
		if time()%(ceil(car.random))
					+ceil(rnd(2)) == 1
					and car.y       <  40
					and car.y							> -28
					and car.nearby  ==  0
					and steer_limit ==  0
					and level       !=  6
					then
							car.v=true
		end
		if car.v==true then
			car.timer=21
			car.v=false
		end
		if car.timer>0 then
			if car.random >0.5 then
				if car.x>4 then
					car.x-=0.7
				end
			else
				if car.x<110 then
					car.x+=0.7
				end
			end
			car.timer-=0.7
		end
	end
	
	--effects
	sparks()
	explosions()										
		
	--level logic
	if level>0 then
		level_p+=0.114
		level_percent=max(1-level_p
																			/100,0)
	end
	
	if level_p>100 and level<8 then
		level+=1
		level_p=-10
	end
	
	if level>6 then
		boss_fight()
	
  rt  += 0.05
		rt2 += 0.05
		if  rt>100 then  rt = 0 end
		if rt2>100 then rt2 = 0 end
		
		heli_s_c = 0
		
		cir_col()
		
		if	 heli_s   == 2
		and heli_s_c == 1
		then
			col_d = 1
		end
	end
	if heli_hit>0 then
		heli_hit-=1
	end
	limit_v=0
	
	--game over
	if car_y>100
	and hit then
		if car_y>280 then
			reset()
		end
	end
	--◆maps	
	levels()
end

function _draw()
	cls()
	
	--title
	if level==0 then
		fillp(0b101101001011010.1)
		draw_title_anim()
		fillp()
		palt()
		palt(0b0000000000000001)
		draw_title()
		transition(trans,64,64)
		palt()
	end
	
	if  level>0 
	and	level<9
	then
		rectfill(0,0,128,128,0)
			
		col=1
		--road
		line(0,0,0,128,col)
		line(127,0,127,128,col)
		
		--center
		line(63,0,63,128,col)
		line(62,0,62,128,col)
		line(65,0,65,128,col)
		line(66,0,66,128,col)
		
		--lanes
		for i=1, 10 do
	 	--right lanes
		 	line(105,25*i-5-lines_y,
		 						105,25*i+5-lines_y,col)
				line(106,25*i-5-lines_y,
									106,25*i+5-lines_y,col)			
			
				line(86,25*i-5-lines_y,
									86,25*i+5-lines_y,col)
				line(87,25*i-5-lines_y,
									87,25*i+5-lines_y,col)

			--left lanes
				line(19,25*i-5-lines_y,
									19,25*i+5-lines_y,col)
				line(20,25*i-5-lines_y,
									20,25*i+5-lines_y,col)		
			
				line(40,25*i-5-lines_y,
									40,25*i+5-lines_y,col)
				line(41,25*i-5-lines_y,
									41,25*i+5-lines_y,col)
		end	
		
		--walls
		if level==1 then
			for i=1, 12 do
				spr(49,1,15*i-walls_y)
				spr(49,119,15*i-walls_y,1,1,true,false)
			end
		end
		if level==2 then
			for i=1, 12 do
				spr(0,1,15*i-walls_y)
				spr(0,119,15*i-walls_y,1,1,true,false)
			end
		end
		if level==3 or 6 then
			for i=1, 12 do
				spr(16,1,15*i-walls_y)
				spr(16,119,15*i-walls_y,1,1,true,false)
			end
		end
		if level==4 then
			for i=1, 12 do
				spr(19,1,15*i-walls_y)
				spr(19,119,15*i-walls_y,1,1,true,false)
			end
		end
		if level==5 then
			for i=1, 12 do
				spr(35,1,15*i-walls_y)
				spr(35,119,15*i-walls_y,1,1,true,false)
			end
		end
		
		--traffic
		palt(0b0000000000000001)
		for  car in all(cars) do
			a,b = car.x,car.y
			 draw_traffic(car.k)
			--rect(car.x,car.y,
					--			car.x+12,car.y+25,6)
		end
		--bikers
		draw_biker(biker1_y,1)
		draw_biker(biker2_y,1)
		draw_biker_s()
		
		--barrel car
		for i=1,6 do
			if barrel_c_y[i]>-20 then
				draw_barrel_c(
									barrel_c_x[i],
									barrel_c_y[i],
									barrel_x[i],
									barrel_y[i])
			end
		end
		palt()
		
		draw_sparks()
		
		--draw car	
			for i=1,2 do
				if i>1 then
					drawsprite(sprite1,
					car_x+2*(rotation*0.1),
					car_y-3.5,
					4,
					7,
					rotation*0.5
					*(car_y/128+0.5),
					car_scale)
					
				else
				drawsprite(sprite,
					car_x,
					car_y-i*4,
					4,
					7,
					rotation*0.5
					*(car_y/128+0.5),
					car_scale)
				end
			end
		draw_explosion()
		
		--driver hands
		hands_x=car_x*0.6+15+rotation*0.2
		hands_y=car_y*0.57+25.5-rotation*-0.2
		
		if shoot>0 then
			spr(32,hands_x,hands_y)
		end
			
		--shooting
		if shoot>14.99 then
			line(hands_x+12-6,hands_y+1,
							shoot_x+12,hands_y-100,8)
			pset(hands_x+6,hands_y+2,10)
			pset(hands_x+6,hands_y+1,8)
			sfx(1)
		end
		
		--lights
		draw_lights()
		
		--side walls
		wall=0
		sidewall()
		sidewall2()
		
		--bridges
		if finished == false then
			draw_bridge()
		end
		--finish line----------
			draw_finish(93)
			
		--heli
		draw_heli
		(
			heli_x,
			heli_y,
			heli_f,
			heli_s,
			heli_ts
		)

		--hud
		--speed-o-meter
		if not hit then
			if  car_x >113 
			and car_y > 90
			then
				move+=0.35-move/10
				fillp(0b101101001011010.1)
			else
				move+=0-move/10
			end
			offset,offset_y=
			0,car_y*-0.08+5+move*2.5
			pal(13,8)
			circ(110+offset,112+offset_y,12,2)
			circ(110+offset,111+offset_y,12,8)
			circ(110+offset,110+offset_y,1,8)
			--meter
				pal(13,2)
				drawsprite(sprite2,
				142+offset*1.4,
				147.5+offset_y*1.5,
				0,
				0,
				max((time()%0.14*7)+car_s*-16+102+add_speedometer,-7),
				0.6)
				
				pal(13,8)
				
				drawsprite(sprite2,
				142+offset*1.4,
				145+offset_y*1.5,
				0,
				0,
				max((time()%0.14*7)+car_s*-16+102+add_speedometer,-7),
				0.6)
				--graded lines
				for i=1,12 do
					drawsprite(sprite3,
					130+offset*2,
					146+offset_y*1.5,
					14,
					0,
					4*i+16,
					0.6)
				end
				fillp()
				pal()
				--progress bar
				if level < 8 then
					fillp(0b1000000000000)
					line(127,128*level_percent,
										127,128,2)
					fillp()
					pset(125,128*level_percent,8)
					pset(127,128*level_percent,8)
					pset(124,128*level_percent,8)
				end
	 	end
			--messages
 		if level_p > 0 
 		and	level_p < 6 
 		then
				text_center(level)
	 	end
	 	if (level_p > 95
	 	or level_p < 0)
	 	and level<8
	 	then
	 		text_center(-1)
		 end
			--shoot tutorial
			if level==5 then	
				if tut==1 then
					text_center(-2)
				end
			end
			
			--boss health
			if 	level == 8 
			and	level_p>10
			then
				?"boss",10,1,8
				fillp(0b1010101010101010)
				rect(29,2,121,5,8)
				local h=heli_h/75
				line(30,3,91*h+30,3,14)
				line(30,4,91*h+30,4,14)
				fillp()
			end
	end
	if level==9 then
		if level_p<326 then
			end_screen()
		else
			draw_end(30,20)
		end
	end
	if level>0 and level_p<10 then
		palt(0b0000000000000001)
			transition(0,64,64)
		palt()
	end
	if hit and car_y>250 then
		transition(80,64,64)
	end
end
-->8
--functions

function reset()
	level_p,tut,finished,ty1,ty2,
	trans,trans_e,
	car_x,car_y,car_r_target,
	car_v_target,car_s,c_disable,
	steer_limit,car_scale,rotation,
	scale,limit_v,v_speed,shoot,
	shoot_enabled,hit,
	col_l,c0l_r,col_u,col_d,lines_y,
	walls_y,lights_y,bridge_y,
	sidewall_y,sidewall_y2,wall,e,
	q,k,l,r,t,car,cars,biker1_y,
	biker2_y,biker1_s,biker2_s,
	barrel_c_x,barrel_c_y,barrel_x,
	barrel_y,heli_h,heli_x,heli_y,
	heli_t_x,heli_t_y,heli_f,heli_s,
	heli_ts,rt,rt2,heli_s_c,heli_hit,
	move,level_percent,sparks_obj,
	spark,explosion_obj,explosion,
	circles,t,logo_f
	= 0,0,false,11,8,0,0.9,85,100,0,
	0,2,0,0,0.6,0.1,0,0,1.6,0,false,false,false,false,false,
	false,12,12,12,12,513,513,0,4,24,
	46,70,90,110,{},{},-20,128,false,
	false,{5,25,45,70,90,110},{-30,-30,-30,-30,-30,-30},
	{5,25,45,70,90,110},{-30,-30,-30,-30,-30,-30},
	74,30,150,30,150,1,0,0,0,0,0,0,4,
	10,{},{x=0,y=0,life=20},{},{x=0,y=0,life=20},
	{},0,500
	
	if level==2 then
		music(9,3000,2)
	end
	if level==3 then
		music(16,3000,2)
	end
	if level==4 then
		music(23,3000,2)
	end
	if level==5 then
		music(31,3000,2)
	end
	if level==6 then
		music(41,3000,2)
	end
	if level==7 and level_p<1 then
		music(47,3000,2)
	end
	if level==8 then
		music(51,0,3)
	end
	
	shoot_x=car_x
	
	for i=-5,5 do
		circle=
		{
			x=0,
			y=0,
			n=i	
		}
		add(circles,circle)
	end
end

function drawsprite
			(sprite,
			x,y,
			centerx,centery,
			angle,scale)
		--origin
		center_x,center_y = 
		x+centerx, y+centery
		
		--angle
		unghi=angle*(3.1/180)
		
		for i=1,#sprite do
			u=flr((i-1)/15)
			
			--original coords
			initial_x,initial_y = 
			x+i-15*u-4, y+u
			
			--rotated coords
			r_x,r_y=
							cos(unghi)*(initial_x-center_x)-
							sin(unghi)*(initial_y-center_y)+center_x
					,	sin(unghi)*(initial_x-center_x)+
							cos(unghi)*(initial_y-center_y)+center_y
			pixel = sub(sprite,i,i)
			
			if pixel == "a" then
				converted_pixel=-1
			end
			if pixel == "b" then
				converted_pixel=0
			end
			if pixel == "c" then
				converted_pixel=1
			end
			if pixel == "d" then
				converted_pixel=7
			end
			if pixel == "e" then
				converted_pixel=8
			end
			if pixel == "f" then
				converted_pixel=13
			end
			
			if  converted_pixel!=-1 then
				rectfill(r_x*scale-scale*68+64+0.9,
												r_y*scale-scale*71+64+0.9,
												r_x*scale-scale*68+64+scale*1.35,
												r_y*scale-scale*71+64+scale*1.35,
												converted_pixel)
			end
		end
end

function add_car(timee,a)
--add_car(time,x)
	if level_p > timee and 
	level_p < timee+0.114
	then
		car={x=a,
							y=car_s*0.5-100,
							k=2*flr(rnd(4)),
							v=false,
							timer=0,
							random=rnd(1),
							nearby=0,
						}
		add(cars,car)
	end
end
function add_truck(timee,a)
--add_car(time,x)
	if level_p > timee and 
	level_p < timee+0.114
	then
		car={x=a,
							y=car_s*0.5-100,
							k=8,
							v=false,
							timer=0,
							random=rnd(1),
							nearby=0,
						}
		add(cars,car)
	end
end

function draw_finish(timee)
	if level_p > timee and 
				level_p < timee + 40 then
			
			finished = true
			
			y-=4.5*1.5
			
			spr(33, 3,100-y-60)
			spr(18, 3,100-y+8-60)
			
			for i=1,15 do
				spr(34, 8*i-4,100-y-60)
				spr(34, 8*i-4,100-y-56)
			end
			line(8,y*-1+40,120,y*-1+40,13)
			line(3,y*-1+39,125,y*-1+39,13)

			spr(33, 118,100-y-60,1,1,true,false)
			spr(18, 118,100-y+8-60,1,1,true,false)
	else
		finished = false
		y = 70
	end
end

function text_center(x)
	c_disable=1
	nr=x
	if x>0 then
		rectfill(48,59,80,69,0)
		rect(48,59,80,69,8)
		?"level "..x,51,62
	end
	if x==-1 then
		rect(36,55,92,74,8)
		?"great job!",46,58
		?"level cleared",39,66
	end
	if x==-2 then
		a=64
		b=0
		fillp(0b1100110000110011.1)
		rectfill(66-a,56-b,
							126-a,73-b,0)
		fillp()
		rect(66-a,56-b,
							126-a,73-b,8)
		?"press ❎ or z",69-a,58-b
		?"to shoot",80-a,66-b
	end
end

function draw_traffic(s)
			sspr(32+s*8,0,16,16,a,b)
			if s!=8 then
				sspr(32+s*8,16,16,8,a,b+16)
			end
			if s==8 then
				sspr(96,0,16,32,a,b,16,42)
			end			
			--warning
			if b<8 then
			line_y = 3
			 line(a,line_y,a+11,line_y,8)
			 line(a+4,line_y+2,a+7,line_y+2,8)
			end
end

function draw_bridge()
			fillp(0b1010010110100101.1)
				rectfill(-3,102-bridge_y-30,129,100-bridge_y-30+8,0)
			fillp()
			spr( 2, 3,40-bridge_y)
			spr(18, 3,48-bridge_y)
			
			for i=1,15 do
				spr( 3, 8*i-4,40-bridge_y)
			end
			
			spr( 2, 118,40-bridge_y,1,1,true,false)
			spr(18, 118,48-bridge_y,1,1,true,false)
end

function draw_lights()
	for i=1, 2 do
			--right
			if wall!=-1 then
				spr( 1,115,100*i-lights_y-60)
				line(122,100*i-lights_y-58,128,100*i-lights_y-58,1)
	 		line(117,100*i-lights_y-59,128,100*i-lights_y-59,1)
			end
			--left
			if wall!=1 then
				spr( 1,5,100*i-lights_y-60,1,1,true,false)
				line(-5,100*i-lights_y-58,4,100*i-lights_y-58,1)
				line(-5,100*i-lights_y-59,9,100*i-lights_y-59,1)
			end		
			--shadows
			for a=0,15 do
				pal(a,0)
			end
			--right
			fillp(0b1010010110100101.1)
			rectfill(109,100*i-lights_y-40,
												125,100*i-lights_y-35,0)
			--left
			rectfill(4,100*i-lights_y-40,
												16,100*i-lights_y-35,0)
			fillp()
			pal()
			end
end

function sidewall()
	fillp(0b1000111100101111)
	rectfill( 0,sidewall_y-128,
										63,sidewall_y+18,1)
	
	if sidewall_y <512 then
		sidewall_y-=car_s*-1.5
		wall=1
		for x=0,63 do
			line(x,sidewall_y-128,
								x,sidewall_y-320-(64-x*4),1)
			
			line(x,257-x*4+sidewall_y,
								x,sidewall_y,1)
		end
		for a=2,6 do
				spr(48,
							10*a-10,
							sidewall_y+315-40*a,
							1,1,true,false)
		end
	end
	fillp()
end

function sidewall2()
	fillp(0b1000111100101111)
	rectfill( 65,sidewall_y2-128,
										128,sidewall_y2+18,1)
	
	if sidewall_y2 <512 then
		sidewall_y2-=car_s*-1.5
		wall=-1
		for x=0,63 do
			line(x+65,sidewall_y2-128,
								x+65,sidewall_y2-64-(64+x*4),1)

			line(x+65,1+x*4+sidewall_y2,
								x+65,sidewall_y2,1)
		end
		for a=2,6 do
				spr(48,
								130-10*a,
								sidewall_y2+300-40*a,
								1,1,false,false)
		end
	end
	fillp()
end

function spawn_sw_l(start,finish)
	if ceil(level_p)==start then
			sidewall_y=-256
		end
		if sidewall_y   > 113 and
					sidewall_y	  < 512 and
					ceil(level_p)<finish 
			then
				sidewall_y=110
		end
end

function spawn_sw_r(start,finish)
		if ceil(level_p)==start then
			sidewall_y2=-256
		end
		if sidewall_y2  > 113 and
					sidewall_y2  < 512 and
					ceil(level_p)<finish 
			then
				sidewall_y2=110
		end
end

function collide_sw()
	local d_x = 1-(car_x/64+0.5)

	if  car_x < 64
	and sidewall_y > car_y-135-60*(0.8-car_s/5)-d_x*150
	and sidewall_y < 115
	then
		rotation = -4.4*(car_s/5)
		add_spark(car_x*0.6+28,car_y*0.7+12,
												8,level_p-0.1,0)
												sfx(2)
	end
	
	if  car_x > 64
	and sidewall_y2 > car_y-132-60*(0.8-car_s/5)-(1-d_x-2)*150
	and sidewall_y2 < 115
	then
		rotation = 4.4*(car_s/5)
		add_spark(car_x*0.6+25,car_y*0.7+12,
												8,level_p-0.1,0)
												sfx(2)
	end
end

function draw_vehicle(a,b,s)
	sspr(32+s*8,0,16,24,a,b)
end

function draw_biker(y,f)
	if y>-10 and y<128 then	
		--biker
		draw_vehicle(0,y,4)
		--hand
		line(8,y+10,12,y+10,13)
		line(8,y+9,8,y+7,0)
	end
end

function draw_biker_s()
	if biker1_s then
		if time()%0.2>0.15 then
		--shoot
		 sfx(1)
			line(16,biker1_y+9,
								128,biker1_y+9,9)
			pset(16,biker1_y+9,7)
			pset(15,biker1_y+9,10)
			if  car_y*0.6+23>biker1_y-5
			and car_y*0.6+20<biker1_y+5
			then
				col_d=true
			end
		end
	else
			--target
			line(13,biker1_y+10,
							128,biker1_y+10,2)
	end
	if biker2_s then
		--shoot
			if time()%0.2>0.15 then
				sfx(1)
				line(16,biker2_y+9,
								128,biker2_y+9,9)
				pset(16,biker2_y+9,7)
				pset(15,biker2_y+9,10)
				if  car_y*0.6+23>biker2_y-5
				and car_y*0.6+20<biker2_y+5
				then
					col_d=true
				end
			end
		else
			--target
			line(13,biker2_y+10,
							128,biker2_y+10,2)
		end
end

function add_biker(t,n,y)
--time, number, height
	if level_p>t	then
	--upper biker
		if n == 1 then
			--show
			if level_p<t+10 then
				if biker1_y < y then
					biker1_y+=(y-biker1_y)/20+0.2
				end
			end
			--shoot
			if  level_p>t+10
			and level_p<t+15
			then
				biker1_s=true
			else
				biker1_s=false
			end
			--disappear
			if (level_p>t+15
			and level_p<t+24)
			or heli_h==0 
			then
					biker1_y+=(-40-biker1_y)/40+0.2
			end
		end
		
		--lower biker
		if n == 2 then
			--show
			if level_p<t+10 then
				if biker2_y > y then
					biker2_y+=(y-biker2_y)/20+0.2
				end
			end
			--shoot
			if  level_p>t+10
			and level_p<t+15
			then
				biker2_s=true
			else
				biker2_s=false
			end	
			--disappear
			if  (level_p>t+15
			and level_p<t+24)
			or heli_h==0
			then
					biker2_y+=(140-biker2_y)/40+0.2
			end
		end
		
		if heli_h==0 then
			biker1_s,biker2_s = false,false
		end
	end
end

function draw_title_anim()
 color(1)
	line(64,55,-128,120)
	line(64,55, 256,120)
	line(64,55,-128,123)
	line(64,55, 256,123)
	for i=-20,20 do
		line(64,60,64+i,158,1)
	end
	ty1*=1.04
	ty2*=1.04
	rectfill(64-ty1*0.7,8*ty1-51,
										64+ty1*0.7,15*ty1-150,
										0)
	rectfill(64-ty2*0.7,8*ty2-51,
										64+ty2*0.7,15*ty2-150,
										0)
end

function draw_title()
	sspr(8,64,128,32,8,0)
	sspr(0,96,128,32,0,32)
	--press to start
	x=35
	if time()>4 then
		t_y-=(t_y-100)/15
	end
	for v=0,6 do
		for i=0,60 do
			a=sget(24+i,24+v)
			pset(
			x+i,
			t_y+v-cos((60-i)*0.02+time()/3)*2,a)
		end
	end
	--title shine effect
	for t_y=37,63 do
		for x=6,123 do
			a,m,t,f=
			pget(x+1,t_y),--position
			5,
			(time()+13)*-16,--speed
			(t_y+t)%24-x*0.01--mod=thickness
			if f<20 and f>-1 then--length
				if a==2 then
					if f<7 or f>13 then--fade
						fillp(▒)--fade pattern
					else
						fillp()
					end
					pset(x,t_y,8)--color
				end
			end
		end
	end
end

function draw_barrel_c(x,y,bx,by)
	pal(13,2)
		draw_vehicle(x,y,6)
	pal()
palt(0b0000000000000001)

	--barrel
	spr(50,bx+2,by+9)
	line(bx+10,by+11,bx+10,by+14,13)
	line(bx+1,by+11,bx+1,by+14,13)
end

function add_barrel_car(t,n)
	--reset positions
	if  level_p>t
	and level_p<t+1
	then
		barrel_c_y[n],barrel_y[n]=
		-30,-30
	end
	
	if level_p>t and level_p<t+20 
	then
		limit_v = 1
	end
	
	--appear
	if 	level_p>t+1
	and level_p<t+5
	then
		if barrel_c_y[n] < 15 then
					barrel_c_y[n]+=(15-barrel_c_y[n])/20+0.2
		end
		if barrel_y[n] < 15 then
					barrel_y[n]+=(15-barrel_y[n])/20+0.2
		end
	end
	--throw_barrel
	if level_p>t+7
	and level_p<t+14
	and barrel_y[n]>10
	and barrel_y[n]<128
	then
		barrel_y[n]+=1.7*(v_speed-0.1)
		if  car_x*0.6+27>barrel_x[n]
		and car_x*0.6+27<barrel_x[n]+15
		and car_y*0.6+27>barrel_y[n]+5
		and car_y*0.6+27<barrel_y[n]+15
		then
			col_d=true
		end
	end
	--disappear
	if		(level_p>t+9
	and level_p<t+14)
	or hit
	then
		barrel_c_y[n]-=1
	end
	if  shoot_x>barrel_x[n]-20
	and shoot_x<barrel_x[n]+10
	and shoot>10
	and barrel_y[n]>20
	and barrel_y[n]<130
	and barrel_y[n]<car_y*0.6+30
	then	
		add_explosion
		(
			barrel_x[n],
			barrel_y[n],
			25,
			1,
			level_p-1
		)
		add_explosion
		(
			barrel_x[n],
			barrel_y[n],
			25,
			1,
			level_p-1
		)
		barrel_y[n]=-30
	end
end

function tutorial()
		if  level_p>15
		and level_p<30
		then
			car_x-=(car_x-120)/25
			car_r_target,s_disable,c_disable=
			0,true,1
		else
			s_disable,c_disable = false,0
		end
		if  level_p>27.5
		and level_p<28
		and tut==0 then
			tut=1
		end
		if tut==1 then
			shoot_enabled,level_p,v_speed
			=true,27.5,0.1
				if btn(❎)or btn(🅾️) then
				tut,v_speed=0,1.6
				level_p+=1
				music(35,3000,2)
			end
		end
end

function transition(t,x,y)
		if trans_e>t	then
			trans_e-=0.03
		end
		if trans_e<t	then
			trans_e+=0.03
		end
 t=60*trans_e+20
 effect_x,effect_y = x,y
 palt(0b0010000000000000)
 if level<1 and time()<4 then
 	pal(1,0)
 else
 	pal(1,1)
 end
 fillp(0b1111111111111110.1)
 circfill(effect_x,effect_y,t*7-200,1)
 fillp(0b1111101111111110.1)
 circfill(effect_x,effect_y,t*7-210,1)
 fillp(0b101101101011110.1)
 circfill(effect_x,effect_y,t*7-220,1)
 fillp(0b100100001010010.1)
 circfill(effect_x,effect_y,t*7-230,1)
 fillp(0b1000000000100000.1)
 circfill(effect_x,effect_y,t*7-250,1)
 fillp()
	pal()
	fillp()
end

function add_spark(e,r,l,t,u)
--e=x, r=y, l=life, t=time
	for i=1,4+(car_s-5) do
		if level_p > t 
		and count(sparks_obj) < 150
		and level_p < t+0.114+i*0.1
		then
			if u==0 then
				spark =
				{
					x     = e+rnd(4)-2,
					y     = r+rnd(30),
					life  = l,
					rndom = rnd(2),
					typee = u
				}
			end
			if u==1 then
				spark =
				{
					x     = e,
					y     = r,
					life  = l,
					rndom = rnd(2),
					typee = u
				}
			end
			add(sparks_obj,spark)
		end
	end
end

function sparks(x,y)
		for spark 
		in all(sparks_obj) do
			if spark.typee==0 then
				spark.y+=spark.rndom*1.5+car_s*0.5+0.5
				spark.x+=spark.rndom*sin(time()*spark.rndom)
				spark.life-=0.5
			end	
			if spark.typee==1 then
				spark.y+=spark.rndom*1.5+car_s+2			
				spark.life-=0.5
			end
			if spark.life < 1 then
				del(sparks_obj,spark)
			end
		end
end

function draw_sparks()
	for spark
	in all(sparks_obj) do
		if spark.typee==0 then
			line(spark.x,spark.y,
								spark.x,spark.y
								+spark.rndom*2-1,8)
		end
	end
end

function add_explosion(e,r,l,s,t)
--e=x, r=y, l=life, s=size, t=time 
	for i=1,6+(car_s-5) do
		if  level_p > t
		and level_p < t+0.6+i*0.1
		and count(explosion_obj) < 250
		then
			explosion =
			{
				x     = e+rnd(4)-2,
				y     = r+rnd(30),
				life  = l,
				rndom = rnd(2),
				size  = s
			}
			add(explosion_obj,explosion)
		end
	end
end

function explosions(x,y)
		for explosion 
		in all(explosion_obj) do
			explosion.y+=explosion.rndom*1.2+car_s*0.5+0.3*(v_speed)
			explosion.x+=explosion.rndom*sin(time()*explosion.rndom)
			explosion.life-=0.5
			if explosion.life < 1 then
				del(explosion_obj,explosion)
			end
		end
end

function draw_explosion()
	for explosion
	in all(explosion_obj) do
	if heli_h == 0 then
		pal(6,8)
		if heli_y<128 then
			music(-1)
		end
	end
		fillp(0b1010101001010101.1)
		if explosion.y > 80 then
			fillp(0b11110000111100.1)
		end
		if explosion.y > 100 then
			fillp(0b1010010110100101.1)
		end
		if explosion.y < 80 then
			fillp(0b100000000010000.1)
		end
		circfill
						(explosion.x+5+explosion.rndom,
							explosion.y-explosion.rndom-15,
							explosion.rndom*4*explosion.size,13)
		circfill
						(explosion.x,explosion.y+5,
						7*explosion.size,1)	
		circfill
						(explosion.x+5,explosion.y,
							8*explosion.size,6)
		fillp()
		pal()
	end
end

function draw_heli(x,y,r,s)
	if y>-30 and y<130 then sfx(25)	 end
	if   y > -30
	and  y < 145 
	then
		local e = x + 4
		--pre shoot
		if heli_ts == 1 then
			line(e,y,e,y+128,2)
			if s==0 and stat(17) !=26 then 
				sfx(26,1) 
			end
		end
		if heli_ts == 2 then
		if s==0 and stat(17) !=26 then sfx(26) end
			line(x+200*sin(rt*-0.15)+4,
 		 				y+200*cos(rt* 0.15)*-1+15*r,
 		 				x+200*sin(rt* 0.15)+4,
 		 				y+200*cos(rt* 0.15)+15*r,
 		 				2)
		end
		--shoot
		if s == 1 then
			sfx(27)
			fillp(0b1110111110111111.1)
				rectfill(e-10*sin(time()),y+20,
													e+10*sin(time()),128,2)
			fillp(0b1000001000000.1)	
				rectfill(e-4*sin(time()),y+20,
													e+4*sin(time()),128,2)
			fillp(0b1010010110100101.1)
				rectfill(e-2,y+20,e+2,128,8)
				rectfill(e,y+20,e,128,8)
			fillp()
		end
	 if s == 2 then
	 	sfx(28)
	 	line(x+200*sin(rt*-0.15)+4,
 		 				y+200*cos(rt* 0.15)*-1+15*r,
 		 				x+200*sin(rt* 0.15)+4,
 		 				y+200*cos(rt* 0.15)+15*r,
 		 				8)
 		line(x+200*sin(rt*-0.15)+5,
 		 				y+200*cos(rt* 0.15)*-1+16*r,
 		 				x+200*sin(rt* 0.15)+5,
 		 				y+200*cos(rt* 0.15)+16*r,
 		 				8)
 		fillp(0b1010010110100101.1)
 		line(x+200*sin(rt*-0.15)+3,
 		 				y+200*cos(rt* 0.15)*-1+18*r,
 		 				x+200*sin(rt* 0.15)+3,
 		 				y+200*cos(rt* 0.15)+18*r,
 		 				8)
 		line(x+200*sin(rt*-0.15)+3,
 		 				y+200*cos(rt* 0.15)*-1+13*r,
 		 				x+200*sin(rt* 0.15)+3,
 		 				y+200*cos(rt* 0.15)+13*r,
 		 				8)
	 	fillp()
	 	if rt>0.2 then
	 	local g=1-(cos((rt+0.6)*0.30))
				add_spark(
				4,
				128*g,
				8,
				level_p-0.1,
				0)
				
				if g >1.9 then
		 		add_spark(
		 		122,
					10,
					8,
					level_p-0.1,
					0)
				end
				if g > 1 and g < 1.3 then
		 		add_spark(
		 		122,
					60,
					8,
					level_p-0.1,
					0)
				end
				if g > 0.7 and g < 0.1 then
		 		add_spark(
		 		122,
					90,
					8,
					level_p-0.1,
					0)
				end
			end
	 end
	 
		r*=2
		--hit effect
		if  heli_hit > 0 
		and time()%1 > 0.5
		then
			pal(3,6)
			pal(11,6)
			pal(2,6)
		else
			pal(3,2)
			pal(11,8)
			pal(2,1)
		end
		palt(0b0000000000000001)
		--body
		if heli_h > 0 then
			if heli_f==1 then	
				sspr(112,0,16,32,heli_x-4,heli_y-4)
			else
				sspr(112,32,16,32,heli_x-4,heli_y-4)
			end
		end
		pal()
		--blades
		fillp(0b101101001011010.1)
		fillp(0b1010010110100101.1)
		if rt2%0.03 > 0.01 then
			circfill(x+4,y+r*7,19,1)
			line(x+18*sin(time()*-1)+4,
 		 				y+18*cos(time()* 1)*-1+7*r,
 		 				x+18*sin(time()* 1)+4,
 		 				y+18*cos(time()* 1)+7*r,
 		 				13)
		end
		fillp()
		--smoke
		if 	heli_h < 30
		and	heli_h > 15
		and rt2%1 > 0.8
		then
			add_explosion
			--e=x, r=y, l=life, 
			--s=size, t=time 
			(
				heli_x,
				heli_y+8,
				8,
				rnd(0.3),
				level_p-1
			)
		end
		
		if 	heli_h < 16
		and	heli_h > 0
		and rt2%0.5 > 0.25
		then
			add_explosion
			--e=x, r=y, l=life, 
			--s=size, t=time 
			(
				heli_x,
				heli_y+8,
				8,
				rnd(0.4),
				level_p-1
			)
		end
		--final explosion
		if 	heli_h == 0
		and level  == 8
		then
			if time()%8000 then
				rndsnd=flr(rnd(3))+29
			end
			if stat(17)!=29 and stat(17)!=30 and stat(17)!=31 then
				sfx(rndsnd)
			end
			add_explosion
			--e=x, r=y, l=life, 
			--s=size, t=time 
			(
				heli_x+rnd(32)-16,
				heli_y-8,
				15,
				rnd(2),
				level_p-1
			)
			add_spark(
		 		heli_x+rnd(40)-12,
					heli_y+rnd(40)-28,
					10,
					level_p-0.1,
					0)
		end
	end
end

function move_heli()
	heli_x += (heli_t_x-heli_x)/40
	heli_y += (heli_t_y-heli_y)/40
end

function set_heli(t,x,y,z,s)
--time,x,y,dir,shoot
	if 	level_p > t-2
	and level_p < t-1.5
	then
	end
	if  level_p > t-2
	and level_p < t
	then
		heli_ts = s
	end
	if  level_p > t
	and level_p < t+1
	then
		heli_t_x,heli_t_y,heli_f = 
		x,y,z
	end
	if  level_p > t+2
	and level_p < t+3
	then
		heli_s = s
	end
end

function boss_fight()
	if	 heli_h == 0
	and level_p < 200 
	then
		level_p = 200
	end
	if  car_x*0.6+27 > heli_x-4
	and car_x*0.6+27 < heli_x+18
	then
			if heli_s==1	then
				col_d=1
			else if shoot  > 14 
			and					heli_h >  0
			and 				level==8
			then
				heli_h  -= 1
				heli_hit = 10
				add_spark(
		 		heli_x+6,
					heli_y,
					8,
					level_p-0.1,
					0)
			end
		end
	end
end

function cir_col()
	local cx,cy = 
	car_x*0.6+27,car_y*0.6+32 
	for circle in all(circles) do
		local n = circle.n
		circle.x=heli_x+(14*n)*sin(rt* 0.15)+4
		circle.y=heli_y+(14*n)*cos(rt* 0.15)*1+15
		if dist(circle.x,
										circle.y,
										cx,
										cy) < 8
		then
			heli_s_c = 1
		end
	end
end

function draw_cir_col()
	for circle in all(circles) do
		circ(circle.x,circle.y,5,7)
	end
end

function dist(x1,y1,x2,y2)
	a,b=
	(x1-x2)^2,(y1-y2)^2
	c=sqrt(a+b)
	return c
end

function text(t,tx,x,y,c)
	if level_p>t then
		?tx,x,y,c
	end
end

function end_screen()
	if level_p <295 then
		?"thank you for playing!",22,40,8
	end
end

function end_car(x,y)
palt(0b0000000000000001)
	rectfill(x-48,y+32,x+15,y+47,0)
	sspr(80,32,32,32,x,y)
	sspr(64,32,16,8,x+8,y-8)
	sspr(56,56,24,8,x,y+32)
	sspr(24,32,8,8,x+8,y-8,-32,8)
	sspr(16,32,8,8,x,y,-32,8)
	sspr(48,32,16,8,x-40,y-8)
	sspr(32,56,24,8,x-48,y)
	sspr(32,32,16,24,x-64,y+8)
	sspr( 8,48,8,8,x,y+8,-48,8)
	sspr( 8,56,8,8,x,y+16,-48,8)
	spr(114,x-8,y+16)
	sspr(16,48,8,8,x,y+24,-48,8)
	sspr(48,40,8,16,x-56,y+32)
	spr(82,x+16,115)
	sspr(56,40,24,8,x-40,y+8)
	sspr(56,48,24,8,x-40,y+23)
	spr(99,x-32,y+16)
	spr(65,x+2,115)
	spr(128,x+24,100)
	spr(144,x-57,109)
palt()
end

function draw_end(x,y)
local a,b = 110,55
fillp(…)
	circfill(a,b,40*sin(rt*0.1),2)
fillp(░)
	circfill(a,b,30,2)
fillp(▤)
	circfill(a,b,20,8)
fillp(❎)
	circfill(a,b,10,9)

rectfill(a-200,b+5,a+200,128,0)

t+=6
if t>128 then t=84 end
for i=1,400 do
	line(-200,100+i,128,70+i/16,1)
	line(-200,90+i,148,90+i/16,1)
end
for i=1,10 do
	line(70+i,140,128+i/5,92,6)
end
rectfill(64,t,128,t+10,1)
	end_car(65+sin(rt*0.1)*8,76+sin(rt*3)*0.1)
	if level_p>359 then
		print("made with ♥ \n\nby vlad comarlau \naugust 2020", 17,7,8)
	end
	if level_p>386 then
		print("\nthanks:cristina \nsnital  robert \nteodor  rased ", 17,33,8)
	end
end

-->8
--levels

function init()
--progession--------------
	level,level_p,tut,finished,t_y
	= 0,0,0,false,135
end

function levels()
	--level 1
	--e q k l r t
	if level==1 then
		add_car( 5, q)
		add_car(10, q)
		add_car(18, t)
		add_car(20, r)
		add_car(22, q)
		add_car(30, r)
		add_car(32, r)
		add_car(32, e)
		add_car(37, l)
		add_car(52, q)
		add_car(52, r)
		add_car(57, k)
		add_car(57, l)
		add_car(57, t)
		add_car(60, q)
		add_car(62, e)
		add_car(65, q)
		add_car(65, e)
		add_car(65, k)
		add_car(70, e)
		add_car(72, e)
		add_car(70, l)
		add_car(70, r)
		add_car(70, t)
		add_car(80, r)
		add_car(81, q)
		add_car(81, t)
		add_car(85, e)
		add_car(86, e)
		add_car(85, l)
		add_car(86, t)
	end
	--e q k l r t
	--level 2
	if level==2 then
		spawn_sw_l(8,40) --3 40
		add_truck(12, r)
		add_car(17, l)
		add_truck(20, l)
		add_car(23, l)
		add_car(27, t)
		add_car(29, t)
		spawn_sw_r(42,83)
		add_truck(45, q)
		add_car(53, e)
		add_truck(55, e)
		add_car(55, q)
		add_car(58, e)
		add_car(58, k)
		add_car(61, e)
		add_car(61, q)
		add_car(65, e)
		add_car(65, k)
		add_truck(72, q)
		add_truck(84, q)
		add_car(86, e)
		add_truck(89, t)
	end
	--e q k l r t
	if level==3 then	
		add_biker( 8,1,80)
		add_car(25, k)
		add_car(28, l)
		spawn_sw_r(35,55)
		add_biker(36,1,30)
		add_biker(36,2,75)
		add_truck(58, e)
		add_car(60, r)
		add_car(65, t)
		add_car(67, q)
		add_car(67, e)
		add_car(69, e)
		add_car(71, q)
		add_car(71, k)
		add_car(73, q)
		add_biker(74,1,30)
		add_biker(74,2,75)
		add_car(75, k)
		add_car(75, q)
		add_car(76, k)
		add_car(78, k)
		add_car(80, q)
		add_car(80, k)
		add_car(83, k)
		add_car(85, q)
		add_truck(88, t)
	end
	--e q k l r t
	if level==4 then
		add_barrel_car(10,3)
		add_barrel_car(10,4)
		add_barrel_car(20,1)
		add_barrel_car(20,6)
		add_barrel_car(21,2)
		add_barrel_car(21,5)
		add_truck(32,l)
		add_truck(34,l)
		add_barrel_car(37,1)
		add_barrel_car(37,3)
		add_car(38,t)
		add_car(39,r)
		add_car(44,r)
		add_truck(48,q)
		add_barrel_car(52,1)
		add_barrel_car(53,2)
		add_barrel_car(54,3)
		add_barrel_car(55,4)
		add_barrel_car(56,5)
		add_barrel_car(59,6)
		add_barrel_car(68,3)
		add_barrel_car(68,4)
		add_car(73,t)
		add_barrel_car(72,2)
		add_barrel_car(72,5)
		add_barrel_car(78,1)
		add_barrel_car(78,6)
		add_truck(88,q)
		add_barrel_car(80,3)
		add_barrel_car(80,4)
		add_car(86,e)
	end
	--e q k l r t
	if level==5 then
		spawn_sw_l(10,40)
		add_barrel_car(20,6)
		add_barrel_car(20,5)
		add_barrel_car(20,4)
		tutorial()
		add_barrel_car(42  ,1)
		add_barrel_car(41.5,2)
		add_barrel_car(41  ,3)
		add_barrel_car(41  ,4)
		add_barrel_car(41.5,5)
		add_barrel_car(42  ,6)
		add_barrel_car(55,1)
		add_barrel_car(55,2)
		add_barrel_car(55,3)
		add_barrel_car(60,4)
		add_barrel_car(60,5)
		add_barrel_car(60,6)
		add_barrel_car(75  ,6)
		add_barrel_car(74.5,5)
		add_barrel_car(73.5,4)
		add_barrel_car(73.5,3)
		add_barrel_car(74.5,2)
		add_barrel_car(75  ,1)
		add_truck(88,q)
	end
	--e q k l r t
	if level==6 then
		add_barrel_car(7.5,4)
		add_car(11,e)
		add_car(11,q)
		add_car(11,k)
		add_car(11,r)
		add_car(11,t)
		add_barrel_car(16.5,3)
		add_car(20,e)
		add_car(20,q)
		add_car(20,l)
		add_car(20,r)
		add_car(20,t)
		add_barrel_car(26.5,4)
		add_car(30,e)
		add_car(30,q)
		add_car(30,k)
		add_car(30,r)
		add_car(30,t)
		spawn_sw_r(40,90)
		add_barrel_car(46.5,2)
		add_car(50,e)
		add_car(50,k)
		add_biker(58,1,30)
		add_biker(58,2,75)
		add_barrel_car(75,1)
		add_barrel_car(75,2)
		add_barrel_car(75,3)
	end
	--e q k l r t
	if level==7 then
		add_truck(9,q)
		add_car(9/5,t)
		add_truck(13,r)
		add_car(15,l)
		add_car(15.5,q)
		add_car(15,t)
		add_car(16,l)
		add_car(18,r)
		add_car(19,l)			
		add_car(19.5,t)
		add_car(20,r)
		add_car(21.5,t)
		add_truck(22,r)
		add_car(24,l)
		add_car(25,l)
		add_truck(28,t)
		add_car(28.5,r)
		set_heli(29,30,-35,0)
		add_truck(31.5,q)
		add_car(34,q)
		add_car(37,e)
		add_car(37.5,k)
		add_car(37,q)
		add_car(41.5,k)
		add_car(41,q)
		add_car(42,e)
		add_truck(46,k)
		add_biker(50,1,51)
		add_biker(50,2,75)
		add_car(54.5,r)
		add_car(57,t)
		add_car(61,r)
		add_car(63,t)
		add_truck(66,r)
		add_car(70.5,l)
		add_car(70,t)
		add_car(75,r)
		add_car(75,l)
		add_car(78,r)
		add_car(79.5,r)
		add_car(81.5,q)
		add_truck(83,e)
		add_truck(86,l)
		add_car(86,k)
		add_car(87,k)
		add_car(87.5,e)
	end
	--e q k l r t
	if level==8 then
		if level_p<8 then
			heli_x =  30
			heli_y =	-35
		end
		set_heli( 8,80,13,1,0)
		set_heli(26,80,13,1,1)
		set_heli(28,10,13,1,1)
		set_heli(36,10,13,1,0)
		add_biker(40,2,80)
		set_heli(55,  0,13,1,1)
		set_heli(58,110,13,1,1)
		set_heli(66,110,13,1,0)
		add_biker(70,2,70)
		set_heli(80,110,13,1,1)
		set_heli(83, 10,13,1,1)
		set_heli(92, 10,13,1,0)
		add_barrel_car(103,1)
		add_barrel_car(103,2)
		add_barrel_car(103,3)
		add_barrel_car(103,4)
		add_barrel_car(103,5)
		add_barrel_car(103,6)
		set_heli(115, 10,13,1,1)
		set_heli(119,110,13,1,1)
		set_heli(125,110,13,1,0)
		add_truck(130,e)
		add_truck(130,q)
		add_truck(130,k)
		set_heli(135, 61,64,1,0)
		set_heli(150, 61,64,1,2)
		set_heli(183, 61,64,1,0)
		set_heli(186, 80,13,1,0)
		--loop
		if  level_p>200
		and	heli_h>0
		then
			level_p = 20
		end
		--ending
		
		--lock player
		if level_p>200 
		then
			if level_p<250 then
				if car_x>63 then
					car_x-=(car_x-130)/25
				else
					car_x-=(car_x+24)/25
				end
			else
				car_x-=(car_x-85)/25
				if level_p>260 then
					car_y-=5
				end
			end
			car_r_target,s_disable,c_disable=0,true,1
		end
		
		set_heli(201,58, 30,1,0)
		set_heli(225,58, 50,1,0)
		set_heli(240,58,170,1,0)

		--switch to end screen
		if level_p>273 then
			level=9
		end
	end
end
-->8
--data
sprite="aaabbbbbbbbbbaaaabbbbbbbbbbbbaabcddcfcfcddcbabbcdccfcfcccdbabbccccfcfccccbbbcccccfcfcccccbbcccccfcfcccccbbcccccfcfcccccbbcccccfcfcccccbbcccccbbbcccccbbcccbbbbbbbcccbbccbbbbbbbbbccbbcbbbbbbbbbbbcbccbbbbbbbbbbbcccccbbbbbbbbbcccbcbbbbbbbbbbbcbbcbbbbbbbbbbbcbbcbbbbbbbbbbbcbbcbbbbbbbbbbbcbbcbbbbbbbbbbbcbbcbbbbbbbbbbbcbbcbbbbbbbbbbbcbbcbbbbbbbbbbbcbbcbbbbbbbbbbbcbbcccbbbbbbbcccbbcccbbbbbbbcccbbcccbbbbbbbcccbbceeebbbbbeeecbbbeeebbbbbeeebbaabcccfcfcccbaa"
sprite1="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabbbaaaaaaaaaabbbbbbbaaaaaaabbbbbbbbbaaaaaaaccfcfccaaaaaaacccfcfcccaaaaaacccfcfcccaaaaaacccfcfcccaaaaaacccfcfcccaaaaaacccfcfcccaaaaaacccfcfcccaaaaaacccfcfcccaaaaaaaccfcfccaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
sprite2="ffffffffffffffffffffffffffffffffffffffff"
sprite3="ffff"