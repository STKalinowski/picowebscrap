-- ~passengers~
--francois alliot + arnaud debock


--overall data
scene=-1
selector=0
money=1000
journeys=0
txtcol1 = 5
txtcol2 = 4
txtcol3 = 8
money_modif=0
arrowx=0
arrowy=0
arrow=false

--route data
ori=3
origin = {"oran",8,80,0.4,
"algiers",30,73,0.6,
"tripoli",60,86,0.8,
"cairo",94,82,0.3
}

dest=0
destination = {"spain",18,45,0.3,
"italy",70,47,0.8,
"malta",72,71,1,
"greece",90,55,0.3
}


ris=0
surveillance = {"low",
"medium",
"high"
}

boat = {"a wreck",
"an old fishboat",
"a rusty tanker",
"a large speedboat"
}

boat_price={0,
-500,
-1200,
-6000
}

boa=1

bribe = {"no bribe",
"a baksheesh",
"the usual sum",
"a lot of money"
}

bribe_price={0,
-200,
-1000,
-8000
}

bri=1

--migrants data
names_fem = {"lia",
"salome",
"bunia",
"maria",
"gina",
"flora",
"noah",
"olivia",
"ava",
"mia",
"sarah",
"ula",
"calanthe",
"femke",
"hedda",
"abigail",
"aaliyah",
"naima",
"amber",
"nashwa",
"zahra",
"thana",
"malika",
"lupe",
"layla",
"inbar",
"ishtar",
"farah",
"eshe",
"nura",
"sabah",
"sahar",
"agata"
}

names_mas = {"richard",
"alexander",
"jacob",
"bilal",
"ajmal",
"jafar",
"david",
"gaetano",
"gaidar",
"hamlet",
"jelani",
"hosni",
"azzam",
"fazil",
"pawel",
"lattrell",
"damien",
"laurens",
"fahim",
"cairo",
"pascal",
"jamon",
"malik",
"qusay",
"rashad",
"rakim",
"tamir",
"zaire",
"talal",
"amare",
"femi",
"achab",
"mohamed",
"javier",
"gregorio"
}

jobs = {"a beggar",
"a wanderer",
"a teenager",
"a mechanic",
"a student",
"a peasant",
"a potter",
"a plumber",
"a farmer",
"a smith",
"a cook",
"a cleaner",
"a teacher",
"a driver",
"a mechanic",
"a builder",
"a nurse",
"a grocer",
"an accountant",
"an artist",
"a merchant",
"a lawyer",
"a scholar",
"a doctor",
"a chirurgian",
"a drug dealer"
}

countries = {"germany",
"frankfurt",
"france",
"london",
"scotland",
"berlin",
"dublin",
"marseille",
"hamburg",
"manchester",
"birmingham",
"edinburgh",
"paris",
"lisbon",
"bruxelles",
"copenhagen",
"madrid",
"stuttgart",
"rome",
"leipzig",
"the hague",
"barcelona",
"amsterdam",
"spain",
"portugal",
"italy",
"denmark",
"sweden"}

stories = {"has fled war in syria",
"wants to learn a new job",
"is a manchester united's fan",
"likes to look at birds",
"likes american movie stars",
"has lost everything",
"is looking for some family",
"is in love with a girl",
"is a very good cook",
"and a bit of a crook too",
"knows a lot about you",
"looks wearily at the port",
"has a rich cousin in europe",
"has lost many children",
"is thanking you politely",
"complains about the weather",
"dreams of marrying",
"looks nervoulsy on the right",
"has left everything behind",
"has done terrible things",
"has made a long journey",
"has left family behind",
"is annoyed at the others",
"seems angry and tired",
"seems lost",
"looks at an airplane",
"came here running",
"is eating a lot",
"is afraid of the sea",
"is in charge of a family",
"is lonely and proud",
"seems calm and composed",
"ignores you superbly",
"won't talk to you",
"is just trying to survive",
"is fleeing a country at war"}

attitudes = {
"swearing a lot",
"patiently waiting in a corner",
"dreaming and smilling largely",
"with many scars and injuries",
"looking at you, unflinching",
"singing very softly to a child",
"drawing on an old magazine",
"believing in god",
"and a most excellent one",
"and a reader of comics",
"and a bit of an historian too",
"with many plans for the future",
"with an injured arm",
"smoking nervously",
"hoping for a better life",
"playing with some children",
"without any story to tell",
"pacing around the quay",
"telling stories to a child",
"soothing an upset child",
"talking very loudly",
"hiding a child under a blanket",
"defying you with a large grin",
"silently reading a novel",
"silently weeping",
"jumping when you approach",
"oblivious of the others"
}

volume = {
"empty",
"almost empty",
"half-full",
"full",
"overcrowded"
}



-- init and game mode

fcount = 20

logoanim=1
logostop=31
logofr=104

function logo()
 local cx = 55
 local cy = 20
 local frx=logofr%16*8
 local fry=flr(logofr/16)*8
 for s=8,logoanim do
  for x=0,15 do
   camera(rnd(120/fcount),
          rnd(120/fcount))
          
   for y=0,15 do
    if(x+y==s) then 
     pset(cx+x,cy+y,7)
    elseif(x+y == s-60) then
     pset(cx+x,cy+y,12)
    elseif(x+y<s-1) then
     pset(cx+x,cy+y,
      sget(frx+x,fry+y))
      
    end
   end
  end
 end
 if(logoanim<=logostop) logoanim+=1
 
 if(fcount > 35) then
  print("francois",36,cy+40,1)
  print("alliot",72,cy+40,1)
  
  
  print("arnaud",38,cy+50,1)
  print("de bock",64,cy+50,1)
  print("#ld33",54,cy+60,4)
 end
	print("x  next",96,120,txtcol1)
	map(0,6,0,0,18,18)
	
	
end

function _init()
	cls()
	music(0,0,30)
	sfx(14)
end

confirm=false
function showconfirm()

 	rectfill(0,0,128,128,0)
 	rectfill(12,12,116,100,1)
	map(0,6,0,0,18,18)

	if(scene==0) print("ready to embark?",33,60,12)
	if(scene==1) print("ready to go?",36,60,12)
	print("x  yes",28,80,12)
	print("no",92,80,12)
    spr(005,76,78,2,1)

end

function changescene()
 dead=false
 payback=false
 arrested = false
 arrived=false
 scene += 1
 if(money_modif!=0) then
  money+=money_modif
  money_modif=0
 end
 if(scene>2) scene=0
 if(scene==1)music(1,0,30) init_migrants() new_migrant() 
 if(scene==0)music(2,0,30) passengers=1 ori = flr(rnd(3)+.5)
 if(scene==2)music(3,3,30) init_route() 
end

function updatescene()
 if(scene==0) then open_map() end
 if(scene==1) then open_migrants() end
 if(scene==2) then open_route() end
 if(confirm) showconfirm()
end


function updateoverall()
 rectfill(0,0,127,27,0)
 print("journey",4,4,txtcol1)
 print(journeys,38,4,txtcol2)
 
 print("money",64,4,txtcol1)
 print(money,90,4,txtcol2)

 
 if(money_modif>0) then
	 print("+"..money_modif,90,10,12)
	end
	if(money_modif<0) then
	 print(money_modif,90,10,8)
	end
	
 if(scene==0) getrisk()

--bribe
 print("surveillance",4,16,txtcol1)
 if(ris>.6) print(surveillance[3],58,16,txtcol2)
 if(ris<=.6 and ris>.3) print(surveillance[2],58,16,txtcol2)
 if(ris<=.3) print(surveillance[1],58,16,txtcol2)
	
end

function _draw()
cls()
	if(scene==-1) logo() return
	updateoverall()
	updatescene()
 if(arrow) then updatearrow() end
end

function _update()
if(scene==-1) then
 fcount += 1
 if(btnp(5)) changescene()
  return
  end
 if(confirm) then
 	if(btnp(5)) sfx(12) confirm=false changescene()
 	if(btnp(0) or btnp(1) or btnp(2) or btnp(3)) sfx(12) confirm=false
 	return
 end
 if(scene==0) control_map() return
 if(scene==1) control_migrants() return
 if(scene==2) control_route() return
end

rboat=0
rbribe=0
dist=0
ris=0

function getrisk()
 ox=origin[ori*4+2]
 oy=origin[ori*4+3]
 dx=destination[dest*4+2]
 dy=destination[dest*4+3]
 dist=sqrt(abs(ox-dx)*abs(ox-dx)+abs(oy-dy)*abs(oy-dy))/100
 
 rboat=1-boa/count(boat)
 rbribe=1-bri/count(bribe)
 ris=(origin[ori*4+4]+destination[dest*4+4]+rbribe/2)/2.5
 --if(ris<.1) ris=.1
end


--ui and other things
function showarrow(x,y)
 arrowx=x
 arrowy=y
 arrow=true
end

function updatearrow()
 if(confirm) return
 spr(000,arrowx,arrowy-sin(time())*2-6)
end

--map scene

function control_map()

 if(btnp(5)) sfx(12) confirm=true return

 if(btnp(2)) sfx(5) selector-=1
 if(btnp(3)) sfx(6) selector+=1
 selector = rotate(selector,3,1,0)
 
 if(selector==0)
  then dest= select(dest,count(destination),4,0) end
 if(selector==1)
  then boa= select(boa,count(boat),1,1) end
 if(selector==2)
  then bri= select(bri,count(bribe),1,1) end
end

function select(ind,count,decal,initval)

 if(btnp(0)) sfx(12) ind-=1
 if(btnp(1)) sfx(12) ind+=1
 
 return rotate(ind,count,decal,initval)
end

function rotate(ind,cnt,decal,initval)
 if(ind==(cnt+initval)/decal)
  then ind=initval
 end 
 if(ind==initval-1)
  then ind=(cnt-decal+initval)/decal
 end
 return ind
end

function open_map()
-- map
 --spr(128,0,28,8,4)
 
 sspr(8*8,8*8,8*8,4*8,0,28,127,72)
 --sspr(0,8*8,8*8,4*8,0,28,127,72)
-- rectfill(0,28,127,99,1)


 for i=0,count(origin)-4,4 do
  xp=origin[i+2]
  yp=origin[i+3]
  if(ori*4==i) then
 	  spr(003,xp,yp) 
  print(origin[i+1],xp+10,yp+2,
  txtcol3)
  else
	  spr(001,xp,yp)
  end
 end
 for i=0,count(destination)-4,4 do
  xp=destination[i+2]
  yp=destination[i+3]
  if(dest*4==i) then
 	  spr(004,xp,yp) 
  print(destination[i+1],xp+10,yp+2,
  txtcol3)
  else
	  spr(002,xp,yp)
  end
 end
 if(selector==0) then
 showarrow(destination[dest*4+2],
 destination[dest*4+3]) end

--boat
	print("boat",4,108,txtcol1)
 print(boat[boa],22,108,txtcol2)
 if(selector==1) then
 showarrow(9,106) end
 
--bribe
 print("bribe",4,120,txtcol1)
 print(bribe[bri],28,120,txtcol2)
 if(selector==2) then
 showarrow(9,118) end


 
money_modif=boat_price[boa]+bribe_price[bri]-flr(dist*10+5)*20
 
 
 print("x  next",96,120,txtcol1)
 spr(005,90,106,2,1)
 print("modif",108,108,txtcol1)
 
 
 
end

--migrants scene
passengers = 1
nextspr = {}
nextaddspr = {}
queue=1
female=true
name=""
pro=""
job=""
country=""
attitude=""
story=""
price=0
minprice=0
maxprice=10000
maxresistance=1
alerte=0
timealerte=0
ontheboat={}

function init_migrants()
nextspr = {}
nextaddspr = {}
queue=1
for i=0,100,1 do
tmp = nextspr[count(nextspr)]
while(tmp==nextspr[count(nextspr)]) do 
	tmp = flr(rnd(16)+16)
end
add(nextspr,tmp)

 add(nextaddspr,flr(rnd(16)+48))
end
end

function open_migrants()

	map(18,0,0,30,20,9)
	--map(20+flr(2*cos(time())),3+flr(2*sin(time())),0,30,20,9)
	map(0,0,0,94,14,1)

	vol=5
	if(passengers<15*(2-rboat)) vol=4
	if(passengers<10*(2-rboat)) vol=3
	if(passengers<5*(2-rboat)) vol=2
	if(passengers<2*(2-rboat)) vol=1

	print("boat is",4,120,txtcol1)
	print(volume[vol],38,120,txtcol2)


	if(alerte>0) then
		if(time()-timealerte>1) then
			if(alerte==4 or alerte==5) alerte=0 changescene() return
			if(alerte==1 or alerte==2 or alerte==3) then
				if(passengers>20*(2-rboat)) setalerte(4) else alerte=0
				queue+=1 arrow=true new_migrant()
			end
		else
			if(alerte==1) then
				print(name.." enters the boat.",4,34,txtcol1)
			end

			if(alerte==2) print(name.." is firmly pushed away.",4,34,txtcol1)
			if(alerte==3) print(name.." espaces.",4,34,txtcol1)
			if(alerte==4) print("the boat is dangerously full.",4,34,txtcol1) print("you decide to go.",4,44,txtcol1)
			if(alerte==5) then
				print("all the people on the quay disappear.",4,34,txtcol1) print("you decide to go.",4,44,txtcol1)
			else 
				drawpassengers()
			end
			money_modif=0
			return
		end
	end

	drawpassengers()

	print(name.." is "..job,4,34,txtcol1)
	print(attitude..".",4,44,txtcol1)
	print(pro.." "..story..".",4,54,txtcol1)
	print(pro.." wants to reach "..country..".",4,64,txtcol1)

	spr(7,4,108)
	print("decline",14,110,txtcol1)

	--spr(8,45,108)
	--print("accept",55,110,txtcol1)

	spr(9,52,108,2,1)
	print("nego",69,110,txtcol1)

	spr(8,94,108)
	print("accept",104,110,txtcol1)

	print("x  next",96,120,txtcol1)

	money_modif=price

	
end

function drawpassengers() 

	for i=0,10,1 do
	 spr(nextspr[queue+i],90-14*i,80,1,2)
	 spr(nextaddspr[queue+i],92-14*i,88)
	end

end

function randa(ar)
	id = flr(1+rnd(count(ar)))
	return ar[id]
end

function randi(ar)

	return flr(1+rnd(count(ar)))
end

function new_migrant()
	resistance=0
	showarrow(90,80)

	if(nextspr[queue]<24) female=false else female=true

	if(female) then
	 pro="she"
	else
	 pro="he" 
	end
	if(female) then
		tmp=name while(tmp==name) do tmp=randa(names_fem) end
 		name=tmp
	else
		tmp=name while(tmp==name) do tmp=randa(names_mas) end
 		name=tmp
	end
	
	tmp=job while(tmp==job) do idjob=randi(jobs) tmp=jobs[idjob] end
 	job=tmp

	price = 100+flr(rnd(20)*10+idjob*10)
	maxprice = price+flr(rnd(20)*100*idjob)
	maxresistance = 1+rnd(1)

	tmp=country while(tmp==country) do tmp=randa(countries) end
 	country=tmp

	tmp=story while(tmp==story) do tmp=randa(stories) end
 	story=tmp

	tmp=attitude while(tmp==attitude) do tmp=randa(attitudes) end
 	attitude=tmp
	
end

function setalerte(id)
	alerte=id
	arrow=false
	timealerte=time()

	if(alerte==1) then
		money += money_modif
		passengers+=1
		add(ontheboat,name)
	end

end

resistance = 0

function control_migrants()
	if(alerte>0) return

	if(btnp(5)) sfx(12) confirm=true return

	if(btnp(2)) then 

		resistance += 0.2
		sfx(6) 
		if(price<maxprice and rnd(1)>resistance) sfx(5) price += 5*flr(rnd(10))+flr(5*(1-resistance))
		if(resistance>maxresistance or price>maxprice) then
			if(rnd(1)<.2) setalerte(3)
			if(rnd(1)>.7) resistance -=0.5
		end
	end
	if(btnp(3)) then
	 sfx(12)
	 resistance -= 0.3
	 if(resistance<0) resistance=0
	 price -= 25
	 if(price<minprice) price=minprice
	end

	if(btnp(1)) then
	 sfx(5)
	 setalerte(1)
	end

	if(btnp(0)) then
	 sfx(6)
	 setalerte(2)
	end
end

--route scene
events={"you're running out of water.",
"you enter a violent storm.",
"another smuggler attacks you.",
"the coast guard is chasing you.",
"an accident is slowing you down"
}
deathrythme=0.1
tim=40

function init_route()
	arrived = false
	dead=false
	calamite = 0
	deadname="none"
	payback = false
	arrested = false
	deadtime=time()+7
	calamitime = time()+5
	arrow=false
	rboat += rboat*passengers/60
	tim = time()+20+rboat*40
end

arrived = false
dead=false
calamite = 0
deadname="none"
payback = false
arrested = false

function open_route()
	map(20+flr(2*cos(time())),3+flr(2*sin(time())),0,30,20,9)

	--map(18,0,0,30,20,9)
	if(not dead) then
	if(boa==1) spr(116,64,80)
	if(boa==2) spr(100,64,80)
	if(boa==3) spr(118,64,80)
	if(boa==4) spr(101,64,80,1,2)
	end
	rtime = (tim-time())*(passengers/40)/60

	if(payback) then
		print("you're on you way home when",4,34,txtcol1) 
		print("the guys you owe money find you.",4,44,txtcol1) 
		print("you are dead.",4,54,txtcol1) 
		print("x  next",96,120,txtcol1)
		money=0
		journeys=0
		return
	end

	if(arrested) then
		print("you're on you way home when",4,34,txtcol1) 
		print("the coast guards arrest you.",4,44,txtcol1) 
		print("you go in prison.",4,54,txtcol1) 
		print("x  next",96,120,txtcol1)
		money=0
		return
	end

	if(passengers<2) then
		print("you go back home.",4,34,txtcol1) 
		print("x  next",96,120,txtcol1)
		arrived = true
		return
	end

	if(time()>tim and not dead) then
		firstsent = "you arrived in "..destination[dest*4+1]
		print("x  next",96,120,txtcol1)
		arrived = true
	else firstsent = "you are on your way to "..destination[dest*4+1]
	end
	
	if(dead) then
		firstsent = "your boat has sunk"
		print("x  next",96,120,txtcol1)
		maxp = flr(time()-deadtime)
		if(maxp>passengers-1) maxp=passengers-1
		for i=0,maxp,1 do spr(226,4+8*i,64) end
	end


	if(rboat>1.1+rnd(.3) and calamite==0 and not arrived) then
		arrived = false
		dead = true
	end


	if(time()-deadtime>2 and rnd(6)<deathrythme and deathrythme>0.3 and not arrived and not dead) then
		deadtime = time()
		candid = randi(ontheboat) 
		if(ontheboat[candid] != "dead") then
			deathrythme -= 0.3
			if(deathrythme<0.2) deathrythme=0.2
			passengers -= 1
			deadname = ontheboat[candid]
			ontheboat[candid] = "dead"
		end
	end

	if(deadname!="none" and not dead and not arrived) print(deadname.." is dead.",4,54,txtcol1) spr(226,4,64+time()-deadtime)

	if(calamite>0 and not dead and not arrived) then
		if(time()-calamitime>6) then
			money += money_modif
			money_modif=0
			calamite=0
			calamitime=time()
		else print(events[calamite],4,110,txtcol1) end
	end

	print(firstsent,4,34,txtcol1) 
	print("with",4,44,txtcol1) 
	print(passengers-1,24,44,txtcol2) 
	print("people on board.",34,44,txtcol1)

	if(not arrived and calamite==0 and time()-calamitime>3 and not dead) then
		calamitime=time()
		if(rnd(3)<rtime*0.4) setcalamite(1) return
		if(rnd(3)<0.3) setcalamite(2) return
		if(rnd(3)<rbribe*0.2+ris*0.3+rboat*0.2) setcalamite(3) return
		if(rnd(3)<ris*0.8) setcalamite(4) return
		if(rnd(3)<rboat*0.6) setcalamite(5) return
	end
end

function setcalamite(id)
	calamite=id
	calamitime=time()


	if(calamite==1) sfx(8) deathrythme += 2*(0.4+rboat)
	if(calamite==2) sfx(8) deathrythme +=0.7*(0.4+rboat) rboat += 0.2
	if(calamite==3) then
	 	sfx(10) 
		deathrythme +=0.8*(0.4+rboat) rboat += 0.1 
		money_modif -= 1000+1000*flr(rnd(5))
	end
	if(calamite==4) sfx(9)  money_modif -= 500+500*flr(rnd(10))
	if(calamite==5) sfx(7)  rboat += 0.2
	if(money>0 and money<-money_modif and money_modif<0) money_modif=-money

	if(money<0) money_modif=0

end

function control_route()
	if(btnp(5)) then
		if(arrested and passengers<2) changescene() return
		if(arrested and arrived) journeys+=1 changescene() return
		if(payback) money_modif=0 money=1000 journeys=0 scene=-1 return
		if(ris>0.6 and rnd(1)>0.7) arrested=true return
		if(money<-2000 and (arrived or passengers<2)) payback=true return 
		if(arrived) journeys+=1 changescene() return
		if(dead) money_modif=0 money=1000 journeys=0 scene=-1 return
	end
end