cartdata("phammond_bb_2p8")
_a=1
_b=1
_c=dget(0)
_d=max(dget(1),1)
_e=.7
_f=0
_g=1
_h=3
_i=4
_j=2
_k={[0]=0,0,1,0,-1}
_l={[0]=0,-1,0,1,0}
_m={_h,_i,_g,_j}
_n=-2
_o=-1
_p=-3
_q=0
_r=9
_s=10
_t=0
_u=1
_v=11
_w=13
_x=14
_y=15
_z=132
_0=0
_1=1
_2=2
_3=1
_4=2
_5=3
_6=4
_7=5
_8=6
_9=7
_aa=8
_ab=9
_ac=10
_ad="paul hammond (@paulhamx) 2020 v0.80 ◆ 🅾️ start controller optimised ◆ testing finn & lucas ◆ low-res gfx thanks dwedit.org & @justin_cyr" mi=1
_ae=1
_af={"normal","super" }
_ag=true
function _init()
_ai=0
_aj=0
_ak=0
_al=0
_am=0
_an=0
_ao=3
_ah()
end
function _ah()
_ap=0
_aq=0
sfx(-1)
music(35)
_gg()
end
function _update60()
if _ap==0 then
local _ar=0
if(btnp(0)) _ar=-1
if(btnp(1)) _ar=1
if(btnp(2)) mi-=1
if(btnp(3)) mi+=1
mi=mid(1,mi,3)
if mi==1 then
_a=mid(1,_a+_ar,2)
elseif mi==2 then
_b=max(1,(min(_b+5*_ar,_d)\5)*5)
else
_ae=mid(1,_ae+_ar,2)
end
if btnp(4) or btnp(5) then
_ag=btnp(5)
_ap=1
_as()
end
else
_be()
if _at then
if(max(p1._b3,p2._b3)>_c) _c=max(p1._b3,p2._b3)
dset(0,_c)
_d=max(_d,_au)
dset(1,_d)
_ah()
end
end
_aq+=.0167
_gf()
end
function _draw()
cls()
if _ap==0 then
_fy()
for i=1,3 do
local c,ox=12,0
local s={"players: " .._a,"level: " .._b,"mode: " .._af[_ae]}
if(i==mi) s[i],ox,c="⬅️ " ..s[i].." ➡️",-4,8
pc(s[i],56+i*10,c,ox)
end
pc("high " .._c.."0",2,7)
map(0,26,27,10,8,6)
if(_aq%1<.5) pc("❎ or 🅾️ start",102,7,-4)
ps(_ad,128-(_aq*60)%900,121,7)
else
_bp()
end
_ge()
end
function _as()
_at=false
_au=_b-1
p1=_by(1)
p2=_by(2)
_av={p1,p2}
_aw(true)
_bd(_n)
_ay=0
_az=0
_gg()
music(2)
end
function _aw(_ax)
local ol=_au
_au+=1
sfx(-1)
_a0={}
_a1={}
_a2={}
_a3={}
_bd(_o)
_a4=_c1(_au,false)
_a5=_a4._c5
for p in all(_av) do
if _ax then
_bz(p,true)
else
_b0(p)
end
end
_a6=0
_a7=0
_a8=999
_a9=-1
_ba=false
_eb(ol,_au,2,_au==_b)
_bb={9+flr(rnd(15))}
local sp
if _au%90==0 then
_bb={29}
elseif _ak>=50 then
sp=25
_ak=0
elseif _al>=50 then
sp=24
_al=0
elseif _aj>=1500 then
sp=28
_aj=0
elseif _an>=9 then
sp=27
_an=0
elseif _am>=10 then
sp=26
_am=0
elseif _ai>=32 then
sp=27
_ai=0
end
if(sp) add(_bb,sp)
_bc="round " .._au
end
function _bd(s,c)
gs=s
_bf=c or 0
end
function _be()
local ec=0
for p in all(_a3) do
p._bg-=1
p.r-=.09
p.x+=p.dx
p.y+=p.dy
if(p._bg==0 or p.r<.5) del(_a3,p)
end
_bw()
for i in all(_a2) do
_fv(i)
if(not i._bk) del(_a2,i)
end
if gs!=_o and gs!=_n then
for e in all(_a1) do
_fe(e)
if(e._bk and e.st!=_2 and e.type!=_ac) ec+=1
end
end
if gs==_n then
if(_bf==400) _bd(_o)
elseif gs==_o then
if _bf==100 then
_bd(_q)
_bc="ready!"
if _az>0 then
_az-=1
_aw()
end
end
_ef()
elseif gs==_q then
if(_bf>60) _bc=""
if(#_do>0 and _bf%(150)==1) _et()
if #_bb>0 and (_bf%120==0 or _bf%960==0) then
_fm(_a4.sx[#_bb]*4,_a4.sy[#_bb]*4,_bb[1],500,false,true)
del(_bb,_bb[1])
end
if(ec==0) _bd(_p)
if(ec==1) _fl(1)
_a6+=1
if _a6==0 then
_fl(0)
elseif _a6==_a4.time then
music(-1)
sfx(0)
for i=0,90 do
pc("hurry up!!",50,8+2*((i/4)%2))
flip()
end
music(7)
_fl(1)
elseif _a6==_a4._dd then
for p in all(_av) do
if p._bk and not p._bh then
local b=_ez(_ac,p._cd/4,p._ce/4,p._cc,1)
p._bh=b
b._bi=p
if(p.y>60) b.y=20
_bs(8,b,4,7)
sfx(4)
end
end
else
for p in all(_av) do
if p._bj==63 then
music(32)
for i=0,520 do
cls(0)
_dx(_a4)
for j=0,5 do
spr(132+j,34+j*10,32+cos((i+j*12)/75)*8)
end
flip()
end
music(7)
p._b2+=1
p._bj=0
_aw()
end
end
end
if(not p1._bk and not p2._bk) _bd(_r)
elseif gs==_p then
if _bf==1 then
if _au%5==0 or _ba then
local f=1+#_a0%12
if _ba then
_fm(56,0,50,-1,true)
end
for b in all(_a0) do
b._bk=false
_fm(b.x,b.y,f)
end
end
elseif _bf>=400 then
_aw(false)
end
elseif gs==_s then
_a1={}
_bl={}
_bs(5,{x=rnd(128),y=rnd(128),w=16,h=16},3,7+rnd(9))
if _bf==520 then
_bc="but all is not well!"
music(2)
_bd(_p)
end
elseif gs==_r then
if _bf==60 then
_bc="game over" elseif _bf==240 then
_at=true
end
end
for p in all(_av) do
if p._bk then
_ck(p)
if gs==_q and p._bm==0 and p.st==_t then
for e in all(_a1) do
if e.st==_0 and _f3(p,e) then
if p._bo and e.type!=_ac then
_fk(e)
e._bn=1
else
_cj(p,_u)
_a6=-1
end
end
end
end
end
p._bo=false
end
_bf+=1
if(_a8!=999) _a8-=1
end
function _bp()
if gs==_n then
_fy()
pc("now begins a fantastic story!",10,8)
pc("let's make a journey to the",20,8)
pc("cave of monsters!",30,8)
pc("good luck!",40,8)
else
clip(0,12,128,104)
if gs==_o then
camera(0,-ms._c3)
if(not ms._ee) _dx(ms._ej)
camera(0,-ms._c3-128)
_dx(ms._ek)
camera()
clip()
else
camera(0,-12)
_dx(_a4)
clip()
?"high score",44,-12,8
pc(_c.."0",-6,7)
ps(_au,0,2,15)
for p in all(_av) do
local _bq=({{16,32,0,5},{100,116,124,-5}})[p._cb]
?p._cb.."p",_bq[1],-12,p.c1
local t=p._b3.."0"
?t,_bq[2]-#t*4,-6,7
if p._bk then
for i=0,p._b2-2 do spr(29+p._b1,_bq[3]+_bq[4]*i,101) end
end
for i=0,5 do
if(p._bj & 2^i !=0) spr(132+i,120*p._b1,20+i*10)
end
end
end
camera(0,-12+_a4._c3)
clip(0,0,128,116)
for b in all(_a0) do
if b._bg<150 then
pal(11,8)
if(b._bg<75 and b._bg%4<2) pal(11,14)
pal(3,2)
pal(10,9)
elseif b._bg<300 then
pal(11,9)
pal(3,4)
end
spr(b.spr+b._ev,b.x,b.y)
pal()
end
foreach(_a2,_f2)
foreach(_a1,_f2)
end
for p in all(_a3) do circfill(p.x,p.y,p.r,p.c) end
for p in all(_av) do
if p._bk then
pal(11,p.c1)
pal(3,p.c2)
pal(10,p.c3)
if(gs==_n or gs==_o) spr(174,p.x-4,p.y-4,2,2)
if p._bm==0 or p._bm%2==1 then
if p.st!=_u and p._br==0 then
for i=2,5 do
local t1,t2=p._cz[i],p._cz[i-1]
line(t1.x,t1.y,t2.x,t2.y,p.c1)
if(i<3) line(t1.x,t1.y,p._c0,p.y+5)
end
end
_f2(p)
end
pal()
end
end
camera()
if(_a9>1) rectfill(39,113,39+_a9,114,11)
if(_bc and gs!=_n) pc(_bc,48,7)
end
function _bs(count,e,r,c,_bt)
_bt=_bt or 1
for i=1,count do
add(_a3,{x=e.x+(e.w/2)-r+rnd(r*2),y=e.y+(e.h/2)-r+rnd(r*2),r=.5+rnd(r),c=c or 7,dx=(.5-rnd(1))*_bt,dy=(.5-rnd(1))*_bt,_bg=30+rnd(15)})
end
end
function _bu(bb,p)
bb._bk=false
bb._bv=p
sfx(6)
_al+=1
if(bb.type==_y) _am+=1
if(bb.type==_z) p._bj|=2^bb._eo
for b in all(_a0) do
if(b._bk and _f4(b,bb)) _bu(b,p)
end
end
function _bw()
local kc,kp=0,p1
for b in all(_a0) do
_ew(b)
if not b._bk or b._bg<=0 then
_bs(6,b,2)
local te=b._ep
if te then
if b._bv then
_fk(te)
kc+=1
kp=b._bv
else
te.st=_0
te._bx=1
end
end
if b._bv then
_cv(b._bv,1)
if b.type==_y then
_fu(b)
elseif b.type==_w or b.type==_x then
_fp(b,_m[b._bv._ch],b.type)
end
end
del(_a0,b)
end
end
if kc>0 then
for e in all(_a1) do e._bn=kc end
_cv(kp,10*2^(kc-1))
if(kc>2) _ay+=kc-2
end
end
function _by(i)
return {_cb=i,_b1=i-1,_bj=0,_b2=5,_b3=0,_b4={i=i-1}}
end
function _bz(s,_ax)
_f5(s,12,108,.8)
s._b5=24
s._b6=0
s._b7=1.5
s._b8=30
s._b9=.07
s._ca=-1.75
if s._cb==1 then
s._cc=_j
s.c1=11
s.c2=3
s.c3=10
else
s.x=108
s._cc=_i
s.c1=12
s.c2=1
s.c3=8
end
s._cd=s.x
s._ce=s.y
_b0(s)
if _ax then
s._bk=(s._cb==1 or _a==2)
else
s._bm=120
end
_ct(s)
_cj(s,_t)
end
function _b0(s)
s._cf=0
s._cg=false
s.spr=1
s._bm=0
s._ch=s._cc
s._ci=0
s._br=0
if s._bh then
del(_a1,s._bh)
s._bh=nil
end
end
function _cj(s,st,c)
s.st=st
s._cl=c or 0
end
function _ck(s)
local i=s._b4
_f6(i)
if gs==_n then
local n=s._cl/120
s.x=17+s._b1*87-sin(n)*12*_k[s._ch]
s.y=52+cos(n)*12
elseif gs==_o then
s.x=_f1(s.x,s._cd)
s.y=_f1(s.y,s._ce-4)
elseif s.st==_t then
local _cm,_cf,_cn,ox,oy,_co=false,false,s._d2,s.x,s.y,s._ch
if(not s._cg) s._cp=_f
local dx=_k[s._cp]*_cn*.6
if(s._cg or s.dy>0) _cn*=.25
if i._f9 then
s._ch=_i
if(s._cp!=_i) s._cp,dx=_f,-_cn
elseif i._d8 then
s._ch=_j
if(s._cp!=_j) s._cp,dx=_f,_cn
end
if(s._ch==_m[_co]) s._cf=3
if s._cf>0 then
s._cf-=1
elseif s._br==0 then
if(dx!=0) _d7(s,abs(dx),dx>0)
if(ox!=s.x) _aj+=1
end
if s._cg then
s.dy+=s._b9
else
s.dy=s._b9*10
end
if s.dy>=0 then
s._cq=not _d3(s,s.dy)
if(s._cq or (s._cg and s.y>=s._cr)) s.dy,s._cg=0,false
else
s._cq=false
s.y+=s.dy
_f0(s)
end
if(oy>100 and s.y<10) _ai+=1
for b in all(_a0) do
if not b._es and _f4(b,s) then
if s.dy>0 and i.up and s.y+5<=b.y then
_cm=true
break
elseif _f3(s,b) then
_bu(b,s)
break
end
end
end
if(_cm or (i._f7 and (s._cq or s._bo))) and s._br==0 then
s.dy=s._ca
s._cg=true
s._cr=s.y
s._cp=_f
if i._f9 then
s._cp=_i
elseif i._d8 then
s._cp=_j
end
_ak+=1
sfx(2)
end
if(i._gb or (s._b5<20 and i._ga)) and s._b6==0 then
s._b6=s._b5
if s._ci>0 then
s._ci-=1
_fp(s,s._ch,_w)._cs=s
sfx(8)
else
_em(s)
end
end
if(s._b6>0) s._b6-=1
if(s._bm>0) s._bm-=1
if s._br>0 then
s._br-=1
if(s._br==0) s._bm=20
end
elseif s.st==_u then
if s._cl==1 then
sfx(7)
elseif s._cl==120 then
s._b2-=1
if s._b2==0 then
s._bk=false
else
_bz(s,false)
end
end
end
s._cl+=1
_cu(s)
if s.st==_u or s._br>0 then
s.spr=5+(s._cl/6)%4
elseif s._b6>0 then
s.spr=4
elseif s._cg then
s.spr=3
else
s.spr=1+(s.x\6)%2
end
end
function _ct(s)
s._cz={}
for i=1,5 do add(s._cz,{x=s.x+4,y=s.y+6}) end
end
function _cu(s)
local _cw,_cx=s.x+3.5-3*_k[s._ch],s.y+7
s._c0=_cw
for i=1,5 do
local t=s._cz[i]
t.x=mid(_cw-.25,_f1(t.x,_cw,s._d2/i),_cw+.25)
t.y=mid(_cx-.75,_f1(t.y,_cx,.25+s._d2/i),_cx+.75)
_cw=t.x-_k[s._ch]*i*.3
_cx=t.y
if(s._cq and i>3 and _aq%3<1) _cx=s.y+5+(_aq*4)%3
end
end
function _cv(s,v)
local _cy=s._b3\2500
s._b3+=v
if(s._b3\2500!=_cy) s._b2+=1
end
function _c1(l,_c2)
local s={
_c2=_c2,_c3=16,_c4=false,_c5={},sx={},sy={}
}
local _c5=s._c5
for y=0,34 do
local _c6={}
for x=1,32 do
add(_c6,{_dl=y<6 or y>29,x=(x-1)*4,y=(y-1)*4,w=4,h=4,_c7=_g})
end
_c5[y]=_c6
end
local _c8=_gn[1+(l-1)%90]
local _c9,_da=18,1
local _db=_gl(_c8,0,17)
s._dc=_db[1]+63
s.time=_db[2]*120
s._dd=s.time+_db[3]*120
s._de=_db[4]/10
s._df=_db[5]
s._dg=_db[6]*2
s._dh=_db[7]
s._di=_db[8]+s._dh
s._dj=_db[9]+s._di
s.sx[1]=_db[10]
s.sy[1]=_db[11]
s.sx[2]=_db[12]
s.sy[2]=_db[13]
s._dk=_db[14]
s.c1=_db[15]
s.c2=_db[16]
s.c3=_db[17]
if _au>90 then
s.c1+=1
s.c2+=1
end
while _c9<#_c8 do
_c9+=1
local t=sub(_c8,_c9,_c9)
_db={}
if t=="|" then
_da+=1
elseif _da<3 then
if t=="m" or t=="n" then
_dv(_c5,t=="m")
elseif t=="s" then
_db=_gl(_c8,_c9,3)
for y=0,7 do
for x=0,7 do
local spr=_db[3]
_c5[_db[2]+y][_db[1]+x]._dl=sget(spr%16*8+x,96+y+(spr\16)*8)!=0
end
end
elseif t=="t" then
_db=_gl(_c8,_c9,6)
_dq(_c5,_db[1],_db[2],_db[3],_db[4],_db[5],_db[6])
else
_db=_gl(_c8,_c9,4)
local v=t=="r"
if(_da==2) v=flr(t)
_dm(_c5,_db[1],_db[2],_db[3],_db[4],v)
end
else
local e=flr(_gm[t])
local _ch=_i
if e>16 then
e-=16
_ch=_j
end
_db=_gl(_c8,_c9,2)
if(not _c2) _ez(e,_db[1],_db[2],_ch,s._df)
end
_c9+=#_db
end
for i=0,3 do
_dm(_c5,({10,20,10,20})[i+1],({1,1,30,30})[i+1],4,5,not _fz(s._dk,2^i))
end
_do={}
for y=1,33 do
for x=3,30 do
local t=_c5[y][x]
if t._dl then
t._dp=(_c5[y-1][x]._dl or _c5[y+1][x]._dl)
else
if(((y==5 and t._c7==_h) or (y==30 and t._c7==_g)) and (x==11 or x==21)) add(_do,{x=t.x,y=t.y})
end
end
end
return s
end
function _dm(_c5,x,y,w,h,_dn)
for py=y,y+h-1 do
for px=x,x+w-1 do
if type(_dn)=="number" then
_c5[py][px]._c7=_dn
else
_c5[py][px]._dl=_dn
end
end
end
end
function _dq(_c5,mx,my,_dr,_ds,_dt,_du)
for y=0,_du-1 do
for x=0,_dt-1 do
local spr=mget(x+_dr*4,y+_ds*4)-239
local tx,ty=mx+x*2,my+y*2
_c5[ty][tx]._dl=_fz(spr,1)
_c5[ty][tx+1]._dl=_fz(spr,2)
_c5[ty+1][tx]._dl=_fz(spr,4)
_c5[ty+1][tx+1]._dl=_fz(spr,8)
end
end
end
function _dv(_c5,_dw)
for y=1,32 do
for x=1,16 do
local tl,tr=_c5[y][x],_c5[y][33-x]
if(_dw) tr._dl=tl._dl
if tl._c7==_i or tl._c7==_j then
tr._c7=_m[tl._c7]
else
tr._c7=tl._c7
end
end
end
end
function _dx(s)
if(_a8!=999) rectfill(0,_a8,128,128,1)
if s._c4 and _a8==999 then
memcpy(0x6300,0x4300,6656)
else
pal(14,s.c1)
pal(8,s.c2)
pal(2,s.c3)
rectfill(9,4,2,100,2)
for y=1,32 do
for x=3,30 do
local t=s._c5[y][x]
if(t._dl) spr(s._dc,t.x,t.y-s._c3)
end
end
for y=0,128,8 do
for i=0,1 do
spr(s._dc+16,120*i,y-s._c3)
end
end
if not s._c2 and _a8==999 then
memcpy(0x4300,0x6300,6656)
s._c4=true
end
pal()
end
end
function _dy(e)
local _d0,oy=false,e.y
e.y-=20
for i=0,4 do
if(not _d3(e,2)) _d0=true
e.y+=2
end
e.y=oy
return _d0
end
function _dz(e,_ch)
return not _a5[1+flr((e.y+10)/4)][1+flr((e.x+4+_k[_ch]*4)/4)]._dl
end
function _d1(e,_d2)
if e._ch==_h then
return _d3(e,_d2)
elseif e._ch==d_update then
return _d6(e,_d2)
else
return _d7(e,_d2,e._ch==_j)
end
end
function _d3(e,_d2)
local _d4=999
local _cd=1+e.x\4
local _d5=1+(e.x+e.w-1)\4
local _ce=mid(1,1+ceil((e.y+e.h-1)/4),32)
for x=_cd,_d5 do
local t=_a5[_ce][x]
if t._dl then
if _ce>1 and _a5[_ce-1][x]._dl then
_d4=999
break
else
_d4=flr(t.y-e.h)
end
end
end
if(_d4<16) _d4=999
if e.y<_d4 then
e.y=min(_d4,e.y+_d2)
_f0(e)
return true
end
return false
end
function _d6(e,_d2)
local _d4=-999
local _cd=1+e.x\4
local _d5=1+(e.x+e.w-1)\4
local _ce=mid(1,((e.y+e.h)\4)-1,32)
for x=_cd,_d5 do
local t=_a5[_ce][x]
if t._dl then
_d4=t.y+t.h
end
end
if e.y>_d4 then
e.y=max(_d4,e.y-_d2)
_f0(e)
return true
end
return false
end
function _d7(e,_d2,_d8)
local _d9=8
if(_d8) _d9=120-e.w
local _ce=mid(1,1+e.y\4,32)
local _ea=mid(1,1+(e.y+e.h-1)\4,32)
if(not e._cg) _ce=_ea
local n=e.x\4
if(_d8) n=1+ceil((e.x+e.w-1)/4)
local _cd=mid(1,n,32)
if not e._cg or _ea>6 then
for y=_ce,_ea do
local t=_a5[y][_cd]
if((e._cq or e._fd) and t._dl) or (not e._cq and t._dp) then
if _d8 then
if(_cd>29 or e._cq or not _a5[y][_cd-1]._dl) _d9=min(_d9,t.x-e.w)
else
if(_cd<4 or e._cq or not _a5[y][_cd+1]._dl) _d9=max(_d9,t.x+t.w)
end
end
end
end
if not _d8 and e.x>_d9 then
e.x=max(_d9,e.x-_d2)
return true
elseif _d8 and e.x<_d9 then
e.x=min(_d9,e.x+_d2)
return true
end
return false
end
function _eb(_ec,_ed,_d2,_ee)
ms={
_ee=_ee,_eg=(_ec==_ed),_ec=_ec,_ed=_ed,_eh=_ec,_ei=0,_d2=_d2,_c3=12
}
ms._ej=_c1(_ec,true)
ms._ek=_c1(_ec+1,true)
end
function _ef()
if(ms._eg) return
if ms._ei>0 then
ms._ei-=1
else
ms._c3-=ms._d2
if ms._c3==-116 or ms._c3==12 then
ms._eh+=1
if ms._eh==ms._ed then
ms._eg=true
else
ms._ei=30
ms._c3=12
ms._ej=_c1(ms._eh,true)
ms._ek=_c1(ms._eh+1,true)
end
end
end
end
function _el()
local s={
type=_v,_en=0,_eo=0,spr=9,_ep=nil,_eq=0,_bg=900,_er=0
}
_f5(s,x,y,0)
_a7+=1
return add(_a0,s)
end
function _em(p)
local s=_el()
s._es=true
s.x=p.x
s._eu=0
s.y=p.y
s._ch=p._ch
s._d2=p._b7
s._cl=p._b8/p._b7
s._ev=p._b1*16
s._bi=p
sfx(1)
end
function _et()
local s=_el()
local sp=_do[1+#_a0%#_do]
local n=_a7%16
if _ay>0 and (n%3==0) then
s.type=_z
s._eo=_ao%6
_ao+=1
_ay-=1
elseif n<_a4._dh then
s.type=_y
elseif n<_a4._di then
s.type=_x
elseif n<_a4._dj then
s.type=_w
else
s.type=_v
if(n%2==0) s._eo=16
end
if sp.y<50 then
s._ch=_h
s.y=0
else
s._ch=_g
s.y=128
end
s.x=sp.x
s.spr=s.type
s._ev=s._eo
end
function _ew(s)
local sp=s._d2
if _a8<s.y then
s._bk=false
elseif s._es then
s._eu+=s._d2
_d1(s,sp)
if s._eu>7 then
local _ex=1+s.x\4
for x=_ex,_ex+2 do
local t=_a5[2+s.y\4][x]
if(t._dl and _f4(t,s)) s._bk=false
end
end
s.spr=9+min(2,s._eu/12)
if s._bk then
for e in all(_a1) do
if e.st==_0 and _f4(s,e) then
e.st=_1
e._ey=s
s._ep=e
s.spr=12
s._es=false
if(e._bm>0) s._bk=false
break
end
end
end
if(s._cl<=0) s._es,s.spr=false,_v
else
s._d2=_a4._de
if s.dx!=0 or s.dy!=0 then
s.x+=s.dx
s.y=max(20,s.y+s.dy)
s.dx*=.5
s.dy*=.5
if(abs(s.dx)<.1) s.dx=0
if(abs(s.dy)<.1) s.dy=0
else
if s._en<=0 then
local t=_a5[max(1,1+flr((s.y+4)/4))][1+flr((s.x+3+_k[s._ch])/4)]
if s._ch!=t._c7 then
if(t._c7==_m[s._ch]) s._en=2
s._ch=t._c7
end
else
sp=min(.25,sp)
s._en-=sp
end
s.x+=_k[s._ch]*sp
s.y+=_l[s._ch]*sp
end
_f0(s)
s._bg-=1
if(s._bg<100 and s.type!=_z) s._ev=0
if s.dx==0 and s.dy==0 then
if s._en<=0 then
for b in all(_a0) do
if b!=s and b._en<=0 and b.dx==0 and b.dy==0 and _f3(s,b) then
b.dy=sgn(b.y-s.y)*sp*.75
b.dx=sgn(b.x-s.x)*sp*3.2
end
end
end
for p in all(_av) do
if p._bk and _f4(s,p) and abs(p.y-s.y)<4 then
_d7(p,1,s.x<p.x)
s.dx=sgn(s.x-p.x)
end
end
end
end
s.x=mid(8,s.x,112)
s._cl-=1
end
function _ez(t,x,y,_ch,_e0)
if _au>90 or _ae>1 then
if(t==_3) t=_6
if(t==_5) t=_aa
end
local e={
_cb=#_a1,type=t,_ch=_ch,_bx=0,_ey=nil,_e1=60,_bm=0,_e2=-1,_bn=7,_b9=.05,_e3=1.5,_e4=0
}
_f5(e,x*4,y*4,_e0/10)
e._e5=({16,32,50,123,105,41,96,114,72,59})[t]
e._b3=(t-1)*100
if(t==1) e._b3=50
if t==_5 then
e._e2=0
elseif t==_aa or t==_6 then
e._d2*=1.1
e._e2=0
elseif t==_ab then
e._e6=true
e._b9=.04
e._e3=1.5
e._d2*=.55
e._bm=50
e.w=16
e.h=16
e._e7=2
elseif t==_7 then
e._e8=true
e.dy=1
e._e9=e._d2*.5
elseif t==_8 then
e._e8=true
e.dy=1
e._e9=e._d2*1.12
elseif t==_4 then
e._e6=true
e._b9=.02
e._e3=.85
elseif t==_9 then
e._e2=0
elseif t==_ac then
e._d2=.25
e._bm=9999
e._fa=true
e._fb=20
e._fc=0
end
e._fd=e._e6 or e._e8
e.spr=e._e5
return add(_a1,e)
end
function _fe(s)
if(not s._bk) return
local _cn=s._d2*(1+s._bx*.5)
if s.st==_2 then
if(s._ch!=_i and s._ch!=_j) s._ch=_j
if s._cl<120 then
s.x+=_k[s._ch]
if(s.x<=8 or s.x>=112) s._ch=_m[s._ch]
end
s.dy=min(s.dy+.07,_e)
if s.dy>.5 and s._cl>100 then
if not _d3(s,s.dy) then
s._bk=false
_fm(s.x,s.y,s._bn)
end
else
s.y+=s.dy
end
s.spr=s._e5+5+(s._cl*_cn*.5)%4
elseif s.st==_0 then
local _co=s._ch
if s._e1>0 then
s._e1-=1
elseif s.type==_ac then
local p=s._bi
if p.st!=_t or gs!=_q then
s._bk=false
_bs(8,s,4,7)
elseif s._fa then
s.y=_f1(s.y,p.y)
else
local ox=s.x
s.x=_f1(s.x,p.x)
if s.x>ox then
s._ch=_j
elseif s.x<ox then
s._ch=_i
end
end
s._fb-=1
if s._fb<=0 then
s._fc+=1
s._fb=20+s._fc*2
s._fa=not s._fa
s._e1=80-s._fc*2
end
else
if s._cq or s._e6 or s._e8 then
if _d1(s,_cn) then
s._e4=0
else
s._ch=_m[s._ch]
s._e4+=1
end
end
if s._e6 then
s._cg=true
s.dy=min(s.dy+s._b9,_e)
if s.dy>=0 then
if(not _d3(s,s.dy)) s.dy=-s._e3
else
s.y+=s.dy
end
elseif s._e8 then
if s.dy>0 then
if(not _d3(s,s._e9)) s.dy*=-1
else
if(not _d6(s,s._e9)) s.dy*=-1
end
else
local _cs=p1
if(not p1._bk or (p2._bk and s._cb%2==0)) _cs=p2
if s._cg then
if(s._cp!=_f) _d7(s,_cn,s._cp==_j)
s.dy+=s._b9
if(s.y>s._cr) s._cg=false
else
s.dy=_e
end
if s.dy>=0 then
s._cq=not _d3(s,s.dy)
if s._cq then
s._cg=false
end
else
s._cq=false
s.y+=s.dy
end
local _ff=(s.type==_9 and s._cq)
local _fg,_fh=false,1
local _fi=_cs.st==_t and flr((_bf+s.x)%22)==s._cb*3
if s.type==_9 or not _cs then
elseif not s._cg then
if s._cq and abs(_cs.y-s.y)<5 then
if _fi then
_ff=true
if s.x>_cs.x then
s._ch=_i
elseif s.x<_cs.x then
s._ch=_j
end
end
if s._cq and _dz(s,s._ch) then
_fg=true
_fh=.6
s._cp=s._ch
end
elseif s._e4>20 or (_cs.y+4<s.y and _fi and s._cq) then
if _dy(s) then
_fg=true
s._cp=_f
s._e1=15
end
end
if _co==_m[s._ch] then
s._e1=5
if(s._e2!=-1) s._e2=15
end
end
if _fg then
s.dy=-s._e3*_fh
s._cg=true
s._cr=s.y
end
if _ff and s._e2==0 then
_fp(s,s._ch,s.type)._fj=s
s._e2=90
if s.type==_5 then
s._e1=30
elseif s.type==_aa then
s._e1=120
end
end
if(s._e2>0) s._e2-=1
end
end
local t=(s._cl*_cn*.20)%2
if s.type==_ac then
s.spr=s._e5+t
elseif s.type==_ab then
s.spr=72+flr(t)*2
_a9=s._bm
else
s.spr=s._e5+(s._bx*2)+t
end
if(_a8<s.y) _fk(s)
elseif s.st==_1 then
s.x=s._ey.x
s.y=s._ey.y
s.spr=s._e5+4
if(s._cl%16==1) s._ch=_m[s._ch]
end
_f0(s)
s._cl+=1
end
function _fk(s)
if s.type==_ab then
_bs(100,s,3,8)
s._bk=false
_bd(_s)
music(32)
_bc="well done!" elseif s._bk then
s.st=_2
s._cl=0
s.dy=-1.75
end
end
function _fl(_bx)
for e in all(_a1) do e._bx=_bx end
end
function _fm(x,y,t,_bg,_fn,_fo)
local s={
_bn=true,type=t,_bg=_bg,_b3=5*t,spr=138+t
}
_f5(s,x,y,_e)
if(_fo) s._d2=0
if _fn then
s.spr=76+2*(_au%2)
s.w=16
s.h=16
s._e7=2
end
return add(_a2,s)
end
function _fp(e,_ch,bt)
local s={
_fq=true,_ch=_ch,_fr=0,
spr=63,type=bt,_fs=1,
_bg=-1
}
_f5(s,e.x,e.y,1)
if bt==-1 then
s.w=4
s.h=4
s.spr=172
s._bg=240
s._fs=6
elseif bt==_x then
s._ch=_h
s._ft=_ch
s.spr=62
s._d2=_e
s._fs=0
elseif bt==_w then
s.spr=61
s._fs=14
sfx(8)
elseif bt==_5 then
s._d2=.75
elseif bt==_6 then
s._d2=1.35
elseif bt==_aa then
s.spr=159
s._fx=true
elseif bt==_9 then
s.spr=138
s._d2=1
s._fr=_h
s._ch=_f
end
return add(_a2,s)
end
function _fu(e)
local s={
_fw=true,_bi=e._bv,_ch=_m[e._bv._ch],spr=31
}
_f5(s,e.x,e.y-4,2)
s.w=4
s.h=4
add(_a2,s)
end
function _fv(s)
if s._fq then
s.y+=_l[s._fr]*s._d2
s._bk=s.x>=8 and s.x<=112 and s.y<128
if s.type==_9 then
_bs(3,s,1,8,.5)
elseif s.type==_w then
s.x+=_k[s._ch]*1.5
elseif not _d1(s,s._d2) then
if s.type==_x then
s._bk=false
_fp(s,_h,-1)
local b=_fp(s,_h,-1)
_d7(b,8,s._ft==_j)
elseif s._fx then
s._fx=false
s._ch=_m[s._ch]
elseif s._bg>0 then
s._bg-=1
s.spr=172+((s._bg/10)%2)
if(s._bg%20==1) _bs(3,s,1,9,.5)
else
s._bk=false
end
elseif s.type==_5 or s.type==_6 then
_bs(2,s,1.5,8,.1)
elseif s.type==_aa then
s.spr=168+(s.x/2)%4
end
s._cl+=1
elseif s._fw then
if(s._cq and not _d1(s,s._d2)) s._ch=_m[s._ch]
s._cq=not _d3(s,s._d2)
_bs(4,s,1.25,12,0)
if(s.y<2) s._bk=false
else
if s.w==16 and s.y<100 then
s.y+=s._d2*1.5
else
_d3(s,s._d2)
end
if s._bg and _au!=90 then
s._bg-=1
if(s._bg==0) s._bk=false
end
end
for p in all(_av) do
if p._bk and (_f3(p,s) or (s.w!=8 and _f4(p,s))) then
if _fz(s._fs,2) and s._cl>30 and p._br==0 and p._bm==0 then
p._br=15
elseif s._bn then
_cv(p,s._b3)
s._bk=false
sfx(5)
if(s.type==23) _ba=true
if(s.type==24) p._b8=50
if(s.type==25) p._b7,p._b5=3,12
if s.type==26 then
_az=2
_aw()
end
if(s.type==27) _a8=128
if(s.type==28) p._d2,p._b9,p._ca=1,.17,-2.75
if s.type==29 then
_bb={29,29}
p._ci=10
end
if(s.type>12) _an+=1
elseif s._fw then
if(not (p._cg and p.dy<-1)) p.x,p.y,p._bo=s.x,s.y-4,true
elseif _fz(s._fs,1) and p.st==_t and p._bm==0 and not p._bo then
_cj(p,_u)
s._bk=false
end
end
end
for e in all(_a1) do
if e._bk and e.st==_0 and _f4(e,s) then
if s._fj==e and e.type==_aa then
if(not s._fx) s._bk,e._e1=false,0
elseif _fz(s._fs,4) then
if(e._bm>0) e._bm-=1
if(e._bm==0) _fk(e)
if e.type==_ab then
s._bk=false
sfx(3)
_bs(8,s,2,8)
end
end
end
end
if _fz(s._fs,8) then
for b in all(_a0) do
if _f3(b,s) then
b._bk=false
b._bv=s._cs
end
end
end
if(not s._bk) _bs(8,s,s.w/6,10)
end
function _fy()
srand(10)
for i=0,100 do pset(rnd(128),(-_aq*20+rnd(128))%128,1) end
end
function _fz(a,b)
return band(a,b)==b
end
function _f0(s)
if(s.y<-8) s.y=122
if(s.y>122) s.y=-8
end
function _f1(c,d,s)
s=s or 1
if(c<d) return min(c+s,d)
if(c>d) return max(c-s,d)
return c
end
function _f2(e)
if(e._bk) spr(e.spr+e._ev,e.x/1,e.y/1,e._e7,e._e7,e._ch==_j)
end
function _f3(e1,e2)
if(e2.w==16) return _f4(e1,e2)
return abs(e1.x-e2.x)<5 and abs(e1.y-e2.y)<6
end
function _f4(e1,e2)
return e1.x<e2.x+e2.w and
e2.x<e1.x+e1.w and
e1.y<e2.y+e2.h and
e2.y<e1.y+e1.h
end
function _f5(s,x,y,_d2)
s.x=x
s.y=y
s._d2=_d2
s._bk=true
s.w=8
s.h=8
s.dx=0
s.dy=0
s.st=0
s._cl=0
s._cg=false
s._cr=0
s._ev=0
s._e7=1
end
function pc(s,y,c,o)
ps(s,64-#s*2+(o or 0),y,c)
end
function ps(s,x,y,c)
for y1=-1,1 do
for x1=-1,1 do
?s,x+x1,y+y1,0
end
end
?s,x,y,c
end
function _f6(s)
local i=s.i
s.up=btn(4,i) or (_ag and btn(2,i))
s._f7=s.up and not s._gc
s._f8=btn(3,i)
s._f9=btn(0,i)
s._d8=btn(1,i)
s._ga=btn(5,i)
s._gb=s._ga and not s._gd
s._gc=s.up
s._gd=s._ga
end
function _ge()
if(_gh) rectfill(0,_gi,128,128,0)
end
function _gf()
if _gh then
_gi+=4
_gh=_gi<128
end
end
function _gg()
_gh,_gi=true,0
end
_gj="1f525f000ackc0e82|r3fs1r3ks1r3ps1b583k|236c43f643m|1f61f91fc~2f525f000fhfm0a94|rea31rbf51r8k91r5p71rep31|236c43f643m|1e7hg71cchic~2f525u000a7k7fa84|r6a81r6f91r6ka1rap31r3p51r6a1a|3f648236d22c84227b9417d2227g8417i2245lc323qc41fn47m|h6cha71oc1k7~6f525f0002rsrf835|r9612r9731r6b9fb7c63bac3db7l94b6g74bak61bdp21rgp11|236ek3g62h3367313a3613j3b36pb245rc23bc1d4cb1c1gl242an22m|h581p8h7c1nch9m1lm~3f525ac00fhfrf8e2|t79h461t7eh461t7jh461t7oh461mb8a11bpf11b8k11bgp21|33ue546qb423ld246gb225bb2331s623761n288g24a7g138721|1i71gc1eh1cm~7f525ac0087q7f482|r7ao1r3fo1r7ko1r5pb1ripb1|311vw469q122eq146jq123or123t814dt412ht414nt911gp21|1o71qh3kcjfh~7f525a00057p7f1cd|r3a71r3f91r3kb1r5pa1|3a17n2368o2bb2j2dg252dl243au452dp35m|j273s7j4c3qc~7f525a00089m9367d|r681cr9c21r9h21r9m81r3q51raq21req31|321uj457c11782a4889i45k4623k264ar73m|j893m9h8e1me~6f525a00067o73982|r6a41r5e41r6i41r7m41r9q61r1111rga11rfe21rei31rdm31|331et4575b4da4846j4348n8323sc24ck42m|j773n7j5b3pb3ff~2f525ac0026s6f615|t39n06a|32uf52e73c4b73637536321f62375427b323ab2229d323cd222bf323ed142ch22m|h6a1erhgr1oamfcmhe6de~8f5256400f5fif65d|r6m51rem31ret31rgr12t980044|321ff457c123d1824g9245sa23au45m|1d51f5hh5697679ml7mn9~2f525f800a6k6fd65|sa9gs8kwrgg12r6811r6d1cr3o11r5o11|3254j456c71g8152f8184ad564fg174gk1a2ar5322c2c45c1cm|m2lm2km2j6sl6sk6sj~8f5256e00cjijf782|t78656ambhb1h|226922382m4d641n|mac6kc6ifmcfmfim4m6qm~2f5256000d8njfc15|s997sh98s9hnshhoras21rms21|45pc422m6345jc323f4445c63226944d635n|6g96ia6jb6kc6lejmi37c~8f5255c00c8p8bd65|r9714r9b64rgbf1rgcf5r4gc1r5ho6b6im5bpc65r7mk1r5qo1r3i11r4k11r3m11|486o43j1a822ss235qo233355226242j771|h98hc81j81m81fj3ojj6j~3f52660009dld08e2|t37p07cr3ue1|22q642ap334eq222cm4227i7222cc435a8232537445832c6473f34532b52m|m456q5mc86i8m2a6sa6fh~8f5255008bcjcfaf4|r3637b5b12b4c11teom623mr8aibt8a8595r7nk1|321u632uu546lb522c2924j223464d46h22477a3n|3ahjkh69k6ckmfkmikmlk~6f5256600b6j6f842|t380273t3e0273t3k0273t3q0273r3u72reu32|321f532uf5236333662423ab24869245dc223gb245jc24gh1123mb24gn1145pc223sc24gt11m|189hkfhm91af1clhil~5f525600846q6fe82|r59cer6nb1rco51b5gc1b692db992dbc92dbf92drdp41req34bfp15r3o13r3q53b3r42|336e1369b7237d22f91d23fe245n1146o824aq43m|65j68j6bj6fjmjjmmjmpj~2f5256c0098l8f6d5|t3lc075t67e063mrup11brp11|33637366b144md336cb1n2aej1477o21s83537722279i2|j683o858b5mb5fe~6f535600098k83865|r5g1cr6ra1r9e1drdc1frem31r6i31r6m31rag31rak31rao31bar31rei31t58i364|22se22ed2em225j34n593|3fajff3fj1lhh9hh9l1ll~1f525c00g2fsffca1|ras41r8991r7aa1r6bbcr8o91r7na1b8b2cb7c4abdb2c|236834d6432391247pa445n32m|57f5cf5if5nf~4f535k0006cocf9f5|t376423taar039|321f6236732a7613g71g3fg172ck242dj112ei112fh114fn2223o2249k1739q8249s822592124a2123b2123c1225i224ca284ai2232uc1m|lf5lb7lj7ln9l79~1f525f0009lll0d15|r3ra1r3o41r9o41rgo11r9s11mr36s9t5687c4|33dtf23mb817o2117tk13are24fm22n|l9flbfldflff5hf5jf5lf~3f52560c08lfl3a92|t4701d3t5k41d3|321uh236814c6512h6414m69137kd326j1422i4249if24nh92|66l68l6al6cl6el6gl~7f53560808fmf376d|r3841r3b31r3e21r3h21r3k11r3n11r3qe4b4r23r9o11rfo11re831reb31rfe21rfh21rgk11|321uom|j253s5jf5j283s83f8jfb~4f535f000dghgf892|r59bhb5bb3b5gb3b5lb3b692hb992hbc92h|226e23g61a44sc225c1225l1348c1248l134ec222eg234el23m|m5gmbg6jg6pgl8glfglmg~6f535c060b8j838e2|t76v04br375f|321fq2863n2e53o22rc2126613g5231gr124ce214ci214cm2112m61m|3fajfb3fcjfd3fejff3fg~7f53560c0ocflfcd5|t37c2ec|321u6|j2564f6db6akmkmmkfml9~4f537f00c36r6f655|r5966b6945re936bf925r9j66baj45|225934d54422fa44df4422qe3m|5aflkfi6bifbiob2al2kl~6f535c0008eoe0982|t3d62e7|321u622br145fq123jq145nq123sq21tg211dn21|32a36a3aa3eajiajmajqa~1f536k000fdff0d75|r6cbbb8d99b7e17b6c11b6m11bgc11r3p11r3k11r3f11r3a11|236e637ca627g9446nb7m3g61a|5ejlgj5ehlgh5eflgf5fd~2f53660c0a5k5fe82|r58ojb69m3bp821boc49bmo32b6g32b5j83bmj22b5ng3b5q71bgq21bek32|235824d5432h5434n592368j32lj4244rd22hrd2|1a516f1aj1ej1in1mn~8f5256008c7i73e82|r9811r5a21rda21rad11r5f21rdf21r5k21rdk21r5p21rdp21r9i11ran11mrg811rhd11rgi11rhn11|321us11111|3fa34c34m3chjqcjihjqm~3f53650002ese3a94|s9dms9l#rcc11r9d11rae11t3fm534mt5710c2|33rs222cf232537321u5456922e6313e766n|15ehpehle19e18mhmm1fr~2f5368000fdf90cd1|sdcxrfk32|225b54k5c53d573|2f92ja2mc2of26f28c2ba~8f53670a066p61605|r79oer5pq1bt922bjbc6b8g36bbg12bcc27beh12bfe36bie11br912bp912bn912rlb13bmh91bja21|46nq2321u7225943ja223cc2228g424ai142fe434hh13|1i61lf1fh18j1am1hm1nm~4f53360a0aqkqca52|rg812rgb1gr7ta1t3lt325t3ct325|326f54e633m|26q29q2cq2fqiiqilqioq~4f52660g0d5h5f984|re83mr8a2kb8a11bf811bfq24ber12|236e2458922aa1l4da1lm|15rh9rhbrhfr1jr1lrhpr~2f5377000fbfjfa82|r5ab1r3e71rce51r5ib1r3m71rcm51r3qd1r9r13|321f6226f23a681258b222be322f834cf5322je345nc32ar63m|k974l74qbk4b4fbjc73i7~8f53510006lol0c61|t57k0c8|321u74f62335go74ei3425n92n|56f52ilailfmlji5of5ri~3e536400036r60825|r3aehb5bc1b5dc2b5gc2b5jc2b5mc2b5pc1r9a1gred1db5ec1b9h11|335e322r53m|4a94f94k945c4pc4ff4fl~1e536a00c8omo5a92|r3r41r3o31r3l21r3i11s470mt96u58b|22b253216a4c66449c1137d2247f2227c11|m2f6sf3rij3ik4l4qlifr~1e53620009ili0ef2|r3r12r6r22rar22rer22mr36sct47b6d5|32huc22p2227p122bp122fp122rp1246p124ap124ep12n|46r49r4cr4frkirklrkor~2a536f000dghg0ab8|r8j9bb9k8abcj21rcq51r3q31r3m11b8n13mt36f7e3|32bu422fb44ef343df1839jg228m54n|19r1br1dr1frhhrhjrhlr~3d5361000bmjm0a92|r3p41rbp41r7k41rfk21mr35s6t46j7d3|324up17i421fi421ni4213n421bn421jn421rn42|2fb2fc2fd2fe2ff2fg2fh~2d53660c0f6f9f67d|r6961r6c71r6f61r6i61r6l61r5o71r5rc1rb91ircq51res32|225934d5442cd4d2as32m|456kp6ip925925cipckfn~3fafb20006joj0d65|r7p11rcp11mt3580e6|32gu3|53hl7h5bhlfh5jhlnh5rh~1c53640009glgff45|t58a26a|226f344rd32d944m|lbflbkl8kljklmkljf~1c5376000fdfi0cd1|r3b21r7ba1rcc22r5gc1r7h22rgh12r3lb1rgl12r5qc1|236923c652m|3983c83c63f83i83i63l8~6b537a000f7ff0982|r3a21r3e21r3i21r3m41r3q41r9a81r7ea1r7i21rbi21rgi11rgm11r9m51r9q71r6n11r6r11r9b13reb13|22fe3m|ja7jf5jf7jk73kb3fb3ab~6b5373000fmfr0865|r3ae1r3fe1r3ke1r3pe1|235a53d543m|3f7j6c3ncj8h3lhj4m3qm~5b5373222a7k7fc1d|r5a1ir8a1irba1ire91j|225934e5354589244sd1m|l5gl8glbglfg5jg5mg5pg~2c536800099l907d5|saaysdf!salzr4h92rg811rgr11rga11|3dl474ds423958222573m|3aejkejfhj5j37j4qjkoj~8b5272000fhfmfed2|r3a61rea31r3f41rcf51r3k21r3p11rak71r8p91|236b43e3363eb423cg5235kc338q9222bc422f6522l5447sa223q12m27nj21qk2a4mg44|hd7hfc1hh1jm3o73shj4c~24337400068o8f675|saa1sia2saihsiii|2h5473e6614ah6b2giba3cna348e28227924e733325823o5824n7922kc6649a54|4673972c71f7li7ml7mo7~8b5374000f9fife25|t36p37b|321f63273l32sf722s9235pc136mb137ja138g91457b13aa323fa223g713m|3a93f9jk9jlcjhc3dc39c~8b5274000j7n7a3b1|t7ak2c8|37645226734b6222d6824n6922i8b23gaf14fbg22edf23dfi14ggg229ik23akl149lm226nn239pm145sf22ks9248qn2|3j73n73r71cc1gc1kc1oc~6b5f7a00098l8f865|r5bobt6d37c4btb2b|44ld3226924d642n|1684985c86f8li8jl8ho8~2b53d400065o5faf5|r58q1r3bq1r5eq1r3hq1r5kq1r3nq1r5qq1||7s57p57m57j5~3f5274000f9fjfa82|r3674r8c31re631re711rd921rea11t4gc532tanc532tagc532rgg12r3c31rgn12r3j11r3q71r9a11|321fy1c831m1b811|n897n9nf9n5cnpcnof7cf~2b537400c56p6fc71|t39d574t3hd574t3ld574b3qe3|32uf5m3e1i632681227814d7i1|j56j96nd67h63l63p6nfc~2ka16400069o936d5|r5b12r6cb1r7g21r7n21|321fs16bb112c31m12j21|7997b97d97f97h97j97l9~5b5374c00blklac7d|tf9g278t5kg444rdk21rdo21|321uy12tt122sj12kt113lr334ns8145ie34id252pd264f7532j7222o75348ni14oe29|7lb7ld7lf7lh7lj7ll~2a5372111d5h5f765|t46i06c|331ey1263a126a9296712da311d72312t914dt413ae3119f1b1ap23m4h611|jbbjjbjjf4bf4fn7fp7fr~2a53720c0eigifa95|t56n56c|325823e5322a5122279245j5a45d26459143af742bj524ao232ar62m|567lo7lpm55mkdlkfl4hl~2f52760c085m53822|r981mtb8t53bmrhi18rha33|321u7227324t732487912h791|k2j46i46k4sjkoikok~8a5371444f5fff435|r8a51r7f71r6k91r5pb1|326f1227d22d9222db143f633m|n973l74mck8cj7h3nh4f5~3a53830003iri0925|t3522e6r3hs1|32huc|29h2dhihhilhjjh3fh3bh~1a52310c07kokfa94|r5aceb6abds883rbg25|321f63273m3ao4b25o554eo3622s91457c3m|26k29k2ck2fk2ik2lk2ok~5a53880004fqffef2|r38egb384fb882gbb86freo36|49q8339187224a42b812m|13khrk2ck2fkiik5iflcf~2ka372000fjfp0d65|r3f41r6f1fr7sa2r7p81rbm61mt47f6d3|32du631ku133j3a3sj3a37j133qj13|2fc2fd2fe2ff2fg56hloh~1a538380896j6fa95|t79s0ca|326u13au454u7122k7a23562m467e245s2123722|4c64o6ibcibj57hlkh4op~1f528f000abkb0a82|r5ecbr7pa1r3r21b6gb3b5h12b7ja1|321f936gb137qa344p323283923h514ah7244ad3m|37h3ag3dh3fgjhhjkgjnh~2f555h0007fmf0a82|t7934a9|22qr43255n455q81qa542ni422om263ir21|l68l885l85n85jplfplap~5fa476000aakaf972|rda31rad41r6g31rcg51raj41rdm31r7p51|m|7d7nh77fdnpd75d29a3la~8f525a008j8alfad4|t6804aa|3255n32ocb22s824ds422hsc24n692321c74d5432h546458d147a8d|hg5hl9jnb1a917d~5f53724449flff6d5|||7f8ncb5iblle6oh66h59e~5k5362000a8k808a4|t6ip666r6729rb729rg719b68b3b6cb3|226e14g6113d7412d843m|6586a86f86k86p86kc6ac~5f46580005kpa0dc1|t67j4bb|23ra33217r3r15r391i6487932h7a32p9354dsi23br5145i46|1eb1cf18lhdlhhlhll~5fa3640007ini09a8|t36f5e3|32bud22mb2n|j3c39c3cc3fcjicjlc3rc~7f53810a0a6k63a92|t58u368t5og052|321fs117g245662m|j8fj8ij8l3ml3mi3mfnf6~1f525f0004dqdf9f0|t5dr368t570363|36831m|74c77m79mnqcnnmnlm~5uf1750006ioi0675|rf719r39e1|329fj47ha9m|n56n967l67p6mfd~5f535f0009rlr0de1|t4840d4r4hp1r4jp1r4lp1|32mu222nb24lnb2|79i7bi7di7fi7hi7ji7li~2f54860004jqj0a82|t36e1f3t9gn385|32bu3|6fe6fe6fe6fe6fe6fe6fe~2fa3b34446dodf782|t47b532to78432rgh22||5fe5fe5fe5fe5fe5fe5fe~5c5355000c6k60615|rgo11rhk11rgf11rha11|224b64l4bb3d385|47r3ar4drkhrjkrknr~3f535a0c0a7k7f6d5|r3ee1r3keab3l34b3q34m||k65k95kc5kf54i54l54o5~1k037h2226coc0e82|r7f21rgf11rak21r7p21rgp11r38e1|236a53d645m|33a5ba6ja9ekn257s5~"
_gk="0123456789abcdefghijklmnopqrstuvwxyz!@#$%" _gm={}
for i=1,40 do
_gm[sub(_gk,i,i)]=i-1
end
function _gl(s,p,l)
local a={}
for i=p+1,p+l do
add(a,_gm[sub(s,i,i)])
end
return a
end
_gn={}
s="" for i=1,#_gj do
local c=sub(_gj,i,i)
if c=="~" then
add(_gn,s)
s="" else
s..=c
end
end