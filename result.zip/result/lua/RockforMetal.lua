--rock for metal
--by jumalauta

function flip_to_spr()
 memcpy(0,0x6000,8192)
end

function drawverse(verse)
 for i in all(verse) do textbox(i[1],i[2],i[3],i[4],i[5]) end
end

function shade(shadecol)
 lightstep,lightphase=flr(light/16),light%16+1
 color(16*shdpal[shadecol][lightstep+1]+shdpal[shadecol][lightstep])
 fillp(shades[lightphase])
end

function dot3d(x,y,z)
 return round(-64*(x/z)+64),round(-64*(y/z)+64)
end

function dot3d_rotate_z(x,y,z,q)
 return x*cos(q)-y*sin(q),x*sin(q)+y*cos(q),z
end

function trifill(v)

  for i2=1,#v do
   local j=i2
   while j>1 and v[j-1][2]>v[j][2] do
    v[j],v[j-1]=v[j-1],v[j]
    j-=1
   end 
  end
 
 x1,x2,x3,y1,y2,y3=v[1][1],v[2][1],v[3][1],v[1][2],v[2][2],v[3][2]
  
 x4=x1+((y2-y1)/(y3-y1))*(x3-x1)
  
 flat_trifill(x1,y1,x2,y2,x4,1)
 flat_trifill(x3,y3,x2,y2,x4,-1) 

end

function flat_trifill(xa,ya,xb,yb,xc,direction)
 slope1,slope2,xa2=(xb-xa)/(yb-ya),(xc-xa)/(yb-ya),xa
 for scany=ya,yb,direction do
  line(xa,scany,xa2,scany)
  xa+=direction*slope1
  xa2+=direction*slope2
 end
end

function unpack_object(str)
 local vr,i,ns,vs=false,1,"",{}
 while vr==false do
  rc=sub(str,i,i)
  if rc!="c" and rc!="d" then
   ns=ns..rc
  end
  if rc=="c" then
   nw=""
   for i2=1,#ns do
    rc2=sub(ns,i2,i2)
	if rc2=="a" then nw=nw.."-" end
	if rc2=="b" then nw=nw.."." end
	if rc2!="a" and rc2!="b" then nw=nw..rc2 end
   end
   ns=""
   add(vs, tonum(nw))
  end
  if rc=="d" then vr=true end
  i+=1
 end
 local op=""
 for i2=i,#str,25 do
  rv=sub(str, i2, i2+24)
  for i3=1,23,2 do
   op=op..tostr(vs[tonum("0x"..sub(rv,i3,i3+1))]).."_"
  end
  op=op.."!"..sub(rv,25)
 end
 return op
end

function parse_table(str)
 local nextstr,nextindex,tbl,i="",{},{},1
 for i=1,#str do
  nc=sub(str,i,i)
  if nc!="_" and nc!="|" then nextstr=nextstr..nc end
  if nc=="_" or nc=="|" then
   add(nextindex, nextstr)
   nextstr=""
  end
  if nc=="|" then
   add(tbl, nextindex)
   nextindex={}
  end
 end
 return tbl
end

function rle_decomp(str)
 output=""
 i=1
 while i<#str do
  length=tonum("0x0"..sub(str,i,i))
  i+=1
  chr=sub(str,i,i)
  for i2=1,length do
   output=output..chr
  end
  i+=1
 end
 return output
end

function spr_to_str_scan(startx, starty, endx, endy)
 local str=""
 for ready=starty, endy do
  if ready>starty then startx_this=0 else startx_this=startx end
  if ready<endy then endx_this=127 else endx_this=endx end
  for readx=startx_this, endx_this do
   str=str..sub(tostr(sget(readx,ready), true),6,6)
  end
 end
 return str  
end

function str_to_spr_scan(writex, writey, str)
 for i=1,#str do
  sset(writex, writey, tonum("0x0"..sub(str, i, i)))
  writex+=1
  if writex==128 then
   writey+=1
   writex=0
  end
 end
end
 
function str_to_spr(offsetx,offsety,str)
 x=0
 y=0
 for i=1,256 do
  sset(offsetx+x,offsety+y,tonum('0x'..sub(str,i,i)))
  x+=1
  if x==16 then
   x=0
   y+=1
  end
 end
end
 
function textbox(startframe,endframe,x,y,word)
 if f>=startframe+0 and f<=endframe+0 then
  fillp(0b1010010110100101.1)
  local xr=x+4+4*#word
  rectfill(x+2,y+2,xr+2,y+10+2,0)
  fillp()
  rectfill(x,y,xr,y+10,bordercol)
  rectfill(x+1,y+1,xr-1,y+9,bgcol)
  color(textcol)
  print(word,x+3,y+3)
 end
end

function round(t)
 return flr(t+0.5)
end

function parse_object(str)
 local vert, coord, obj, face, coord_str,i=1,1,{},{{0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, col=0},"",1
 while i<=#str do
  if sub(str,i,i)!="_" and sub(str,i,i)!="!" then
   coord_str=coord_str..sub(str,i,i)
  end
  if sub(str,i,i)=="_" then
   face[vert][coord]=tonum(coord_str)
   coord_str=""
   coord+=1
   if coord==4 then
    coord=1
	vert+=1
   end
  end
  if sub(str,i,i)=="!" then
   i+=1
   face["col"]=tonum("0x"..sub(str,i,i))
   add(obj, face)
   face,vert,coord={{0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}, col=0},1,1
  end
  i+=1
 end
 return obj
end

function render_queue()

 --sort by depth
 for i=1,#rq do
 local j=i
  while j>1 and rq[j-1]["depth"]>rq[j]["depth"] do
   rq[j],rq[j-1]=rq[j-1],rq[j]
   j-=1
  end 
 end
 
 for i in all(rq) do
 
  v={{i[1][1],i[1][2]},{i[2][1],i[2][2]},{i[3][1],i[3][2]}}
  
  col=i["col"]+1
 
  light=i["light"]
 
  shade(col)

  trifill(v)
   
 end
 
 fillp()
 
end

function rotate_x(object, q)
 
 if rotate_normals==true then
  i3=4
 else
  i3=3
 end

 sinr,cosr=sin(q),cos(q)
   
 for i in all(object) do  --each vertex
  for i2=1,i3 do          --each xyz coord, plus normal if rotate_normals is true
   ny,nz=i[i2][2]*cosr-i[i2][3]*sinr,i[i2][2]*sinr+i[i2][3]*cosr
   i[i2][2],i[i2][3]=ny,nz
  end
 end
end

function rotate_y(object, q)

 if rotate_normals==true then
  i3=4
 else
  i3=3
 end

 sinr,cosr=sin(q),cos(q)
 
 for i in all(object) do  --each vertex
  for i2=1,i3 do          --each xyz coord, plus normal if rotate_normals is true
   nz,nx=i[i2][3]*cosr-i[i2][1]*sinr,i[i2][3]*sinr+i[i2][1]*cosr
   i[i2][1],i[i2][3]=nx,nz
  end
 end
end

function rotate_z(object, q)

 if rotate_normals==true then
  i3=4
 else
  i3=3
 end

 for i in all(object) do  --each vertex
  for i2=1,i3 do          --each xyz coord, plus normal if rotate_normals is true
   --nx,ny=i[i2][1]*cosr-i[i2][2]*sinr,i[i2][1]*sinr+i[i2][2]*cosr
   i[i2][1],i[i2][2]=dot3d_rotate_z(i[i2][1],i[i2][2],i[i2][3],q)
  end
 end
end

function translate(object, x,y,z)
 for i in all(object) do
  for i2=1,3 do
   i[i2][1]+=x
   i[i2][2]+=y
   i[i2][3]+=z
  end
 end
end

function copy(object, x,y,z)
 local c
 c={}
 for i in all(object) do
  tri=
  {
   {i[1][1], i[1][2], i[1][3]}, {i[2][1], i[2][2], i[2][3]}, {i[3][1], i[3][2], i[3][3]}, {i[4][1], i[4][2], i[4][3]},
   col=i["col"]
  }
  add(c, tri)
 end
 return c
end

function send_to_queue(object)

 for i in all(object) do
 
  --map to 2d
 
  v={
   {
    round(-63.5*(i[1][1]/i[1][3])+63.5),
    round(-63.5*(i[1][2]/i[1][3])+63.5)
   },
   {
    round(-63.5*(i[2][1]/i[2][3])+63.5),
    round(-63.5*(i[2][2]/i[2][3])+63.5)
   },
   {
    round(-63.5*(i[3][1]/i[3][3])+63.5),
    round(-63.5*(i[3][2]/i[3][3])+63.5)
   }
  }
  
  area=((v[2][1]-v[1][1])*(v[3][2]-v[1][2])-(v[3][1]-v[1][1])*(v[2][2]-v[1][2]))/2  

  if area>0 then  
  
   if recalc_normals==true then
    d1={
     i[2][1]-i[1][1],
     i[2][2]-i[1][2],
     i[2][3]-i[1][3]
    }
    d2={
     i[3][1]-i[2][1],
     i[3][2]-i[2][2],
     i[3][3]-i[2][3]
    }
    cross={
     d1[2]*d2[3]-d1[3]*d2[2],
     d1[3]*d2[1]-d1[1]*d2[3],
     d1[1]*d2[2]-d1[2]*d2[1]
    }
    dist=sqrt(cross[1]^2+cross[2]^2+cross[3]^2)
    i[4]={
     cross[1]/dist,
     cross[2]/dist,
     cross[3]/dist
    }
   end

   depth=(i[1][3]+i[2][3]+i[3][3])/3 

   light=max(16,min(256,flr((i[4][3]+light_compensation)*200)+96))
 
   add(rq, {v[1],v[2],v[3],col=i["col"],light=light,depth=depth})
  end
 end
end

function twist(start, wavelength, amplitudex, amplitudey)
 if f>start and f<start+wavelength then
  phase=1+sin(0.25+(f-start)/wavelength)
  modvalx,modvaly=amplitudex*phase,amplitudey*phase
  modx+=modvalx
  mody+=modvaly
 end
end

function twirl(start,length,direction)
 if f>start then
  phase=1+sin(min(0.25+(f-start)/length, 0.75))
  qmod+=0.125*direction*phase
 end
end

function newring()

 tunnel_progress+=1
 dx[tunnel_progress],dy[tunnel_progress],fill[tunnel_progress],currcol={},{},{},8
 
 for i in all(tunncols) do
  if f>i[1]+0 then currcol=i[2] end
  if f>800 and f<925 then currcol=flr(rnd(12)+4) end
 end
 
 for i=1,9 do
  x,y,q=1,0,i/9+qmod
  dx[tunnel_progress][i],dy[tunnel_progress][i],depth[tunnel_progress],ringcol[tunnel_progress],fill[tunnel_progress][i]=x*cos(q)-y*sin(q)+modx,x*sin(q)+y*cos(q)+mody,15*0.5,currcol+0,rnd(72)
 end 
end

function water(horizon)
 if horizon<127 then
  horizon_address=0x6000+64*horizon
  for y=1,127-horizon do
   offset=y+flr(sin((y*10-f*0.5)/50)*3)
   memcpy(horizon_address+64*y,horizon_address-64*offset,64)
  end
 end
end

--main init

function _init()

 recalc_normals,rotate_normals=false,true
 
 sprite={}
 sprcoords=parse_table("116_47_51_49|52_49_119_50|120_50_21_52|22_52_53_52|54_52_83_53|86_53_57_54|58_54_101_55|102_55_9_57|10_57_73_57|74_57_126_57|126_57_81_58|82_58_6_59|67_99_28_100|29_100_54_101|55_101_70_102|71_102_54_104|")

 for i=1,16 do sprite[i]=rle_decomp(spr_to_str_scan(sprcoords[i][1],sprcoords[i][2]+0,sprcoords[i][3],sprcoords[i][4]+0)) end
 
 flyingv=parse_object(unpack_object(spr_to_str_scan(6,59,33,69))) 
 rotate_z(flyingv, 0.5)
 rotate_y(flyingv, 0.5)
 
 sword=parse_object(unpack_object(spr_to_str_scan(34,69,19,80)))
 rotate_x(sword, 0.75)
 translate(sword, 0, 0.3, 0)
 rotate_z(sword, 0.75)
 
 helmet=parse_object(unpack_object(spr_to_str_scan(20,80,66,99)))
 rotate_x(helmet, 0.75)
 translate(helmet, 0, 0.5, 0)
 
 nwojml=rle_decomp(spr_to_str_scan(55,104,112,127))
 
 startgfx=rle_decomp(spr_to_str_scan(0,0,115,47))
 str_to_spr_scan(0,0,startgfx)
 reload_scanline=0
 

 
  shades={
  0b1000000000000000,
  0b1000000000100000,
  0b1000001010000000,
  0b1010000010100000,
  0b1010010010100000,
  0b1010010010100001,
  0b1010010110100100,
  0b1010010110100101,
  0b1110010110100101,
  0b1110010111100101,
  0b1110011111100101,
  0b1110011111100111,
  0b1111011111100111,
  0b1111011111110111,
  0b1111111111110111,
  0b1111111111111111
 }
 
 shdpal={}
 for i=0,15 do
  row={}
  add(row, 0)
  for i2=23,8,-1 do
   add(row, sget(i2,i))
  end
  add(shdpal, row)
 end
 
 controlverse=parse_table("525_1000_0_15_now|615_1000_0_25_let|627_1000_-6_25_let it|640_1000_-2_35_take|655_1000_-10_35_take con|668_1000_-18_35_take control|750_1000_0_50_you'll|773_1000_-10_50_you'll have|865_1000_6_60_all|875_1000_-2_60_all the|895_1000_-8_60_all the po|905_1000_-14_60_all the power|925_1000_8_70_of|935_1000_0_70_of the|945_1000_-10_70_of the gods|")
  
 ugverse=parse_table("0_24_10_10_can|25_49_10_10_can you|50_74_10_10_can you hear|75_99_10_10_can you hear the|100_1000_10_10_can you hear the sound|290_309_48_32_the|310_334_48_32_the un|335_349_48_32_the under|350_1000_48_32_the underground|230_244_8_22_co|245_261_8_22_coming|262_1000_8_22_coming from|575_1000_99_56_brin|600_1000_83_56_bringing|628_1000_99_66_free|653_1000_87_66_freedom|693_1000_107_76_to|725_1000_99_86_your|747_1000_95_96_soul?|")
 
 hurricaneverse=parse_table("510_609_56_10_fly|610_624_40_10_fly through|625_639_36_10_fly through a|640_651_28_10_fly through a hur|652_661_24_10_fly through a hurri|662_1000_16_10_fly through a hurricane|750_769_56_102_and|770_859_44_102_and taste|860_877_36_102_and taste sac|878_897_30_102_and taste sacred|898_909_24_102_and taste sacred me|910_1000_18_102_and taste sacred metal|926_937_58_112_in|938_948_48_112_in your|948_1000_36_112_in your blood|")
 
 lifeverse=parse_table("1025_1121_54_10_life|1122_1139_48_10_life on|1140_1154_40_10_life on the|1155_1169_30_10_life on the flee|1170_1179_22_10_life on the fleeting|1180_10000_12_10_life on the fleeting edge|1265_1274_58_102_is|1275_1374_50_102_is how|1375_1389_44_102_is how it|1390_1409_36_102_is how it was|1410_1419_30_102_is how it was al|1420_10000_22_102_is how it was always|1436_1447_52_112_meant|1448_1457_46_112_meant to|1458_10000_40_112_meant to be|")
  
 steelverse=parse_table("0_15_5_5_now|15_235_5_5_now you|27_42_5_15_have|42_235_5_15_have the|55_235_5_25_steel|118_125_59_27_and|125_235_31_27_and you'll|137_150_63_37_ne|150_162_51_37_never|162_174_31_37_never have|174_183_19_37_never have to|183_235_19_37_never have to kneel|286_300_85_105_there's|300_318_85_95_there's|300_318_105_105_no|318_348_85_85_there's|318_348_105_95_no|318_332_105_105_go|332_348_93_105_going|348_365_85_75_there's|348_365_105_85_no|348_365_93_95_going|348_365_97_105_back|365_375_85_65_there's|365_375_105_75_no|365_375_93_85_going|365_375_97_95_back|365_375_105_105_no|375_395_85_55_there's|375_408_105_65_no|375_423_93_75_going|375_435_97_85_back|375_449_105_95_no|375_466_97_105_more|")

 roadwords_flash=parse_table("810_36_rock for metal|")
 roadwords=parse_table("0_12_play it louder than before|110_10_give in to the devil's roar|220_20_'cos you know what for|310_36_rock for metal|500_16_our songs will never die|610_14_we scream them to the sky|720_18_you know the reason why|810_36_rock for metal|")
 
 rq={}
 light_compensation=0
 
 scn={}
 scn[3],scn3itd_a,scn3itd_b,scn[4],scn4itd,scn5itd_a,scn5itd_b,fbzoom,scn6itd,scn7itd,scn8itd,scn8froze,scn9itd,ended={},false,false,{},false,false,false,0,false,false,false,false,false,false
 
 initscn1()
 
 rects={}
 for i=1,25 do
  x=rnd(128)
  newrect={x,128+rnd(500),x+rnd(10),128+rnd(500),0.2-rnd(0.4),0}
  add(rects, newrect)
 end
 
 script=parse_table("0_11_1|11_13_2|13_17_3|17_19_4|19_23_5|23_29_6|29_31_7|31_36_8|36_46_9|48_100_10|")
  
 f=0
 fadjust=flr(60*time())
 
 music()
 maxcpu=0
end


function initscn1()
 flyingv_spinloop={}
 for i=1,120 do
  frame=copy(flyingv)
  rotate_y(frame, i/120)
  flyingv_spinloop[i]=frame
 end

 scn1camspeed,scn1elevation,scn1horizon,scn1reloaded=0,0,100,false
 scn1starfield={}
 srand(4)
 scn1starfieldx,scn1starfieldy,scn1starfieldhyperx,scn1starfieldhypery={},{},{},{}
  for i=1,50 do
  scn1starfield[i]={}
  scn1starfieldx[i],scn1starfieldy[i]=rnd(128),rnd(128)
  scn1starfieldhyperx[i]=scn1starfieldx[i]-64
  scn1starfieldhypery[i]=scn1starfieldy[i]-64
 end
 scn1exosphere,scn1hypercharge,scn1hypercharge_accel,scn1camerarumble,scn1gtrspinspd,scn1gtrspin,scn1gtrtilt,scn1hypy,scn1hypz,scn1hypyspd,scn1hypzspd=0,0,0,0,0.00833,0,0,0,0,0,0
 --0.00833 = 1/120
 
 scn2guitardrawn,scn2whitefade=false,0
 scn2grid={}
 grid={}
 for x=1,20 do
  scn2grid[x]={}
  for y=1,20 do
   scn2grid[x][y]=24
  end
 end
 lines={}
 for i=1,6 do scn2_createline(i) end
 
end

function initscn3a()
 
 scn3twister,scn3twisterphase={},{}
 for i=1,128 do
  scn3twisterphase[i]=i/128
 end
 scn3twistercolors,scn3line3pos,scn3line3speed,scn3line3acc,scn3purplines={9,10,11,10},110,0,0.008,{}
 for i=1,40 do
  scn3purplines[i]={}
  scn3purplines[i].y=rnd(128)
  scn3purplines[i].spd=2-4*rnd(100)/100
 end
 scn3yelllines={}
 for i=1,20 do
  scn3yelllines[i]={}
  scn3yelllines[i].y=rnd(128)
  scn3yelllines[i].spd=2-4*rnd(100)/100
 end
 scn3blinkedonce,scn3blinkedtwice,scn3blinklight,scn3itd_a=false,false,255,true
end

function initscn3b()
 cls(7)
 flip_to_spr()
 fadjust=flr(60*time())
 scn3itd_b=true
end

function initscn4()
 fillp()
 cls()
 --background
 rectfill(0,70,128,88,2)
 flip_to_spr()
 --fist
 
 str_to_spr(0,0,sprite[1])
 scn4rotowidth,fadjust,scn4itd=64,flr(60*time()),true
end

function initscn5a()

 scn5firepal,scn5fireedge,scn5firebuf={0,1,2,8,9,10},"888886633566552244463315577788777788",{}

 for x=1,36 do
  scn5firebuf[x]={}
  for y=1,8 do
   scn5firebuf[x][y]=0
  end
 end
 
 scn5lutab={}
 for x=0,128 do
  scn5lutab[x]={}
  for y=0,128 do
   scn5lutab[x][y]={}
   scn5lutab[x][y].y=((64*9)/(y-64))
   scn5lutab[x][y].x=max(0,min(31,((scn5lutab[x][y].y-((x*scn5lutab[x][y].y)/64))+16)))
   scn5lutab[x][y].y%=32
  end
 end
 
 sprs=parse_table("0_64_2|16_64_3|32_64_4|36_64_5|52_64_6|64_64_7|80_64_8|96_64_9|0_80_10|16_80_11|")
 for i in all(sprs) do str_to_spr(i[1],i[2],sprite[i[3]+0]) end
 
 scn5itd_a=true
 
end



function _update60()
 
 if stat(24)>11 then flyingv_spinloop={} end
 
 if stat(24)<11 then scn1_update() end
 if stat(24)>=11 and stat(24)<13 then scn2_update() end
 if stat(24)>=13 and scn3itd_b==false then initscn3b() end
 if stat(24)>=13 and stat(24)<17 then scn3_update() end
 if stat(24)>=17 and scn4itd==false then initscn4() end
 if stat(24)>=17 and stat(24)<19 then scn4_update() end
 if stat(24)>=18 and scn4rotowidth<-4 and scn5itd_a==false then initscn5a() end
 if stat(24)>=19 and scn5itd_b==false then
  fadjust=flr(60*time())
  scn5itd_b=true
 end
 if stat(24)>=19 and stat(24)<23 then scn5_update() end
 if stat(24)>=23 and scn6itd==false then
  fadjust=flr(60*time())
  cls(0)
  flip_to_spr()
  light_compensation=0.6
  scn6itd=true
 end
 if stat(24)>=23 and stat(24)<29 then scn6_update() end
 if stat(24)>=29 and scn7itd==false then
 
  cls()
  for i=0,15 do
   line(0,i,80-i,i,4)
   line(96-i,i,128,i,10)
   for i2=1,31 do
    fillp(shades[flr(i2/2)+1])
	camera(i,0)
    pset(80+i2,i,4+10*16)
	camera()
   end
   fillp()
    
  end
  memcpy(0x4300,0x6000,1024)
  cls()
  
  str_to_spr(8,0,sprite[12])
  
  fadjust=flr(60*time())
  scn7itd=true
 end
 
 if stat(24)>=31 and scn8itd==false then

  fire={}
 
  for x=1,128 do
   fire[x]={}
   for y=1,11 do
    fire[x][y]=0
   end
   fire[x][12]=rnd(32)
  end

  rain={}
  for i=1,100 do
   rain[i]={}
   rain[i].x,rain[i].y,rain[i].spd,rain[i].scale=rnd(136),rnd(66),1+rnd(1),0.5+rnd(0.5)
   if i>10 then rain[i].y=100 end
  end  
  cls()
 
  for y=64,128 do
   for x=0,128 do
    z2=-((64*-8)/(y-64))
    x2=z2-(x*z2/64)
    color(flr(x2)%16)
    pset(x,y)
   end
  end
  
  rectfill(0,0,7,7,7)
  circfill(3,3,3,0)
  circfill(3,3,1,7)
  line(2,3,4,3,1)
 
  rectfill(8,0,15,7,7)
  circfill(11,3,3,0)
  circfill(11,3,1,7)
  line(11,2,11,4,1)
 
  memcpy(0x0000,0x6000,8192) --remove this later!!!!
 
  cycleterrain=parse_table("2_2_2_2_4_4_4_4_2_2_2_2_4_4_4_4|")
  cycleroad=parse_table("5_5_5_5_5_5_5_5_7_7_7_7_7_7_7_7|")
 
  for i=0,3 do str_to_spr(i*16,8,sprite[13+i]) end
  
  fadjust=flr(60*time())
  scn8itd=true
 end
 
 if stat(24)>=36 and scn9itd==false then
 
  tunnel_progress,modx,mody,camx,camy,camq,dx,dy,depth,fill,ringcol=15,0,0,{},{},{},{},{},{},{},{}
    
  for i=1,90 do
   camy[i],camx[i],camq[i]=0,0,0
  end
 
  for i=1,15 do
   depth[i],ringcol[i],dx[i],dy[i],fill[i]=i*0.5,7,{},{},{}
   for i2=1,9 do
    dx[i][i2],dy[i][i2],fill[i][i2]=100,100,2
   end
  end
 
  stars={}
  for i=1,75 do
   stars[i]={}
   stars[i][1],stars[i][2],stars[i][3]=-100+rnd(200),-100+rnd(200),5+flr(rnd(3))
  end
 
  blinkframes=parse_table("140_155|295_320|650_670|745_770|900_1030|")
  tunncols=parse_table("50_9|100_8|200_3|220_10|310_11|320_13|470_8|720_14|725_11|925_8|")
  twists=parse_table("0_700_-0.05_0.12|100_900_0.17_-0.11|0_130_0.4_-0.1|125_50_0_0.5|165_100_0.3_-0.1|320_50_-0.5_0.5|350_100_0.1_-0.4|450_50_0.6_0|500_50_0_-0.3|620_70_0_-0.5|750_100_-0.7_0|770_200_0_0.3|")
  twirls=parse_table("0_1000_2|300_800_-3|520_100_-1|640_150_2|800_300_6|320_60_-0.5|360_60_0.3|")
  
  fadjust,scn9itd=flr(60*time()),true
  
 end
 
 if stat(24)>=31 and stat(24)<36 then
  for i=1,27 do
   rain[i].x-=0.25*rain[i].spd
   rain[i].y+=0.5*rain[i].spd
   if rain[i].y>70 then rain[i].x,rain[i].y,rain[i].spd=rnd(144),-16,1+rnd(1) end
  end
 end
 
 if stat(24)>=36 and f<1120 then

  blink_walls,ring_passed,modx,mody,qmod=false,false,0,0,0
 
  for i in all(blinkframes) do
   if f>i[1]+0 and f<i[2]+0 then blink_walls=true end
  end
 
  for i=tunnel_progress,tunnel_progress-15+1,-1 do
   depth[i]-=0.08
   if depth[i]<0.1 then ring_passed=true end
   if blink_walls==true then for i2=1,9 do fill[i][i2]=rnd(40) end end
  end
 
  for i in all(twists) do twist(i[1]+0,i[2],i[3],i[4]) end
  for i in all(twirls) do twirl(i[1]+0,i[2],i[3]) end
 
  cx,cy=dot3d_rotate_z(-80*modx,-80*mody,0,-qmod)
  add(camx, cx)
  add(camy, cy)
  add(camq, qmod)
 
  if ring_passed==true then newring() end
 
 end
  
 f=flr(time()*60)-fadjust
 
end

function scn1_update()

 if f>2200 then
  scn1hypyspd,scn1hypzspd=min(0.0095,scn1hypyspd+0.002),min(0.004,scn1hypzspd+0.00007)
  scn1hypy,scn1hypz=min(4,scn1hypy+scn1hypyspd),min(4,scn1hypz+scn1hypzspd)
 end
 
 if f>2000 then light_compensation,scn1gtrspinspd,scn1gtrtilt=min(0.75,light_compensation+0.001),max(0, scn1gtrspinspd-1/22222),max(-0.25, scn1gtrtilt-0.0005) end
 
 if scn1gtrspinspd>1/444 then
  scn1gtrspin+=scn1gtrspinspd
  scn1gtrspin%=1
 else
  scn1gtrspin=min(1,scn1gtrspin+1/555)
  if scn1gtrspin==1 then scn1gtrspin=-1 end
 end
 
 if f>600 then
  scn1camspeed=min(1,scn1camspeed+0.05)
  scn1elevation+=scn1camspeed
 end
 
 if f>1220 then
  scn1exosphere+=scn1camspeed*0.17
 end
 
 if f>2750 then
  scn1hypercharge_accel+=0.002
  scn1hypercharge+=scn1hypercharge_accel
  scn1camerarumble+=0.1
 end
 
end

function scn2_update()
 if scn3itd_a==false then initscn3a() end
end

function scn3_update()
 if f<10 then scn3blinkedtwice=false end --no idea why i need this bugfix
 if f<=990 then scn3_updatetwister() else scn3_updateblinks() end
end

function scn3_updatetwister()

 for i=1,40 do
  scn3purplines[i].y+=scn3purplines[i].spd*0.4
  if scn3purplines[i].y<0 or scn3purplines[i].y>128 then
   scn3purplines[i].y,scn3purplines[i].spd=rnd(128),2-4*rnd(100)/100
  end
 end
 
 for i=1,20 do
  scn3yelllines[i].y+=scn3yelllines[i].spd*0.4
  if scn3yelllines[i].y<0 or scn3yelllines[i].y>128 then
   scn3yelllines[i].y,scn3yelllines[i].spd=rnd(128),2-4*rnd(100)/100
  end
 end
 
 if f>525 then
  scn3line3speed=min(0.18,scn3line3speed+scn3line3acc)
  scn3line3pos-=scn3line3speed
 end
 
end

function scn3_updateblinks()
 
 scn3blinklight=max(100,scn3blinklight-50)
 
 --990
 if f>990 and scn3blinkedonce==false then
  scn3blinklight,scn3blinkedonce=500,true
 end
 
 if f>1000 and scn3blinkedtwice==false then
  scn3blinklight,scn3blinkedtwice=500,true
 end
 
end

function scn4_update()
  
 if f>950 then scn4rotowidth-=5 end
 
end

function scn5_update()
 for x=1,36 do
  for y=1,8 do
   if y==tonum(sub(scn5fireedge,x,x)) then scn5firebuf[x][y]=flr(rnd(5))+2
    else if y>tonum(sub(scn5fireedge,x,x)) then scn5firebuf[x][y]=0
     else if y<8 then
      scn5firebuf[x][y]=scn5firebuf[x][y+1]
      if x>1 then scn5firebuf[x][y]+=scn5firebuf[x-1][y+1] end
      if x<36 then scn5firebuf[x][y]+=scn5firebuf[x+1][y+1] end
      if y<7 then scn5firebuf[x][y]+=scn5firebuf[x][y+2] end
	  scn5firebuf[x][y]=max(2,flr(scn5firebuf[x][y]/4.00000001))
	 end
    end
   end
  end
 end
end

function scn6_update()
 if f>1500 then fbzoom+=1 end
end



function scn1_drawguitar1()
 rq={}
 if f<1000 then
  obu=copy(flyingv_spinloop[f%120+1])
 else
  flyingv_spinloop={}
  obu=copy(flyingv)
  if scn1gtrspin>=0 then rotate_y(obu, scn1gtrspin) end
  if scn1gtrtilt!=0 then
   translate(obu, 0, 0, 2)
   rotate_x(obu, scn1gtrtilt)
   translate(obu, 0, 0, -2)
  end
 end
 translate(obu,0,max(0,8-0.01*f)+scn1hypy,-4+scn1hypz)
 send_to_queue(obu)
 render_queue()
end

function scn2_createline(line_index)
 xspd,yspd,z=dot3d_rotate_z(1+0.5*rnd(100)/100,0,0,rnd(360)/360)
 --nx,ny=xspd,yspd
 --xspd,yspd,x1,y1,x2,y2=nx,ny,10,10,10+nx,10+ny
 x1,y1,x2,y2=10,10,10+xspd,10+yspd
 lines[line_index]={x1=x1,y1=y1,x2=x2,y2=y2,xspd=xspd,yspd=yspd}
end

function scn3_drawtwister()

 fillp()
 
 memcpy(0x6000,0,8192)
 for i=1,20 do
  line(0,scn3purplines[i].y,128,scn3purplines[i].y,4)
 end

 for i=1,10 do
  line(0,scn3yelllines[i].y,128,scn3yelllines[i].y,2)
 end
 flip_to_spr()
 
 bordercol,bgcol,textcol=9,1,7
 
 textbox(516,524,109-max(1,1.5^(525-f)),15,"now")
 
 for y=0,127 do
  if f+rnd(50+f*2)>50 then
   for i=0,3 do
    if (scn3twisterphase[y+1]+i*0.25)%1<0.5 then
     --sinr=sine[flr((stabres*q)%stabres+1)]
	 bluh=64+20*sin(f/123)*sin((f+y)/100)
     x1,x2=bluh+32*sin(scn3twisterphase[y+1]+0.125+i*0.25),bluh+32*sin(scn3twisterphase[y+1]+0.375+i*0.25)
	 light=min(256,flr(150+(x2-x1)*3))
     shade(scn3twistercolors[i+1])
     line(x1,y,x2,y)
     color(0)
    end
   end
  end
  scn3twisterphase[y+1]+=0.001*sin(f/233)*sin(y/100)+0.02

 end
 clip()
 
 
 flameverse=parse_table("1_525_5_5_there|100_525_5_15_is|112_525_5_25_a|128_525_5_35_flame|140_151_5_45_in|152_525_5_45_inside|245_259_109_65_a|260_525_85_65_a blaze|355_369_97_75_that|370_384_77_75_that will|385_525_57_75_that will burn|395_407_101_85_for|408_422_97_85_fore|423_525_85_85_forever|435_525_97_95_more|")
 
 if f>500 then camera(0,-((f-500)^1.5)) end
 drawverse(flameverse)
 
 camera(-scn3line3pos,0)

 drawverse(controlverse)
 camera(0,0)
 
end

function scn3_drawblinks()
 light=min(255,scn3blinklight)
 shade(8)
 rectfill(0,0,127,127)
end

function scn5_draw()

 cls(2)
 camera(0,f%32)

 for y=0,3 do
  rectfill(0,y*16,31,y*16+8,4)
 end
 
 rectfill (2,0,30,64,5)
 for y=0,3 do
  rectfill(15,y*32,17,y*32+15,7)
 end
 camera()
 clip()
 memcpy (0, 0x6000, 4096)
 cls()
 for x=0,22 do
  for y=64,128 do
   sset(32+x,y-64,sget(scn5lutab[x*3][y].x,scn5lutab[x*2][y].y))
  end
 end
 sspr(32,1,22,64,0,64,64,64)
 sspr(32,1,22,64,64,64,64,64,true,false)
 
 rectfill(0,0,128,64,1)
 for x=1,36 do
  for y=1,8 do
   pset(x+46,y+56,scn5firepal[scn5firebuf[x][y]])
  end
 end

 color(7)
 if f<515 then
  if f<130 then print("play it louder than before",12,40-f*0.1) end
  if f>129 and f<260 then print("give in to the devil's roar",10,40-(f-130)*0.1) end
  if f>259 then print("'cos you know what for",20,40-(f-260)*0.1) end
  rfmw=0
  if f>350 then rfmw=32 end
  if f>362 then rfmw=64 end
  if f>376 then rfmw=80 end
  if f>387 then rfmw=104 end
  if f>350 then sspr(0,65,rfmw,15,12,40+(350-f)*0.075 ) end
 end
 if f>=515 then
  if f<645 then print("our songs will never die",16,40-(f-520)*0.1) end
  if f>644 and f<770 then print("we scream them to the sky",14,40-(f-645)*0.1) end
  if f>769 then print("you know the reason why",20,40-(f-770)*0.1) end
  if f>865 then print("rock for metal",38,56) end
 end
 
 if f>900 then
  cols=parse_table("900_7_0_0_0_0|908_0_7_1_0_0|922_7_0_2_0_0|940_0_7_4_1_0|956_7_0_4_2_0|970_0_7_5_5_1|986_7_2_6_7_1|995_8_7_7_9_1|1002_9_8_8_10_1|1008_0_9_9_14_1|")
  for i in all(cols) do
   if f>i[1]+0 then bgcol,textcol,u,d,w=i[2],i[3],i[4],i[5],i[6] end
  end
  cls(bgcol)
  for x=-w,w do
   for y=-u,d do
    print ("rock for metal",38+60*x,56+6*y,textcol)
   end
  end
 end

 if f>480 and f<515 then
  cls()
  for i=0,4 do
   line(10,44+i*10,118,44+i*10)
  end
  rectfill(15,54,18,74)
  rectfill(22,54,25,74)
  sspr(0,80,16,16,30,51)
  sspr(16,80,16,16,30,36)
  line(44,15,44,56)
  
  if f>488 then
   sspr(0,80,16,16,50,71)
   line(64,50,64,76)
  end
  
  if f>496 then
   sspr(0,80,16,16,70,71)
   line(84,50,84,76)
   sspr(16,80,16,16,70,36)
   line(84,15,84,39)
  end
  
  if f>504 then
   sspr(0,80,16,16,90,51)
   line(104,30,104,56)
  end
  
 end
 
end

function scn6_draw()

 cls()
 fillp()
 sspr(0,32,128,64,-3+fbzoom,29+fbzoom,134-2*fbzoom,70-2*fbzoom)

 fbtable=parse_table("0_1015_3_9|0_1015_6_8|0_1015_9_0|1015_1500_3_12|1015_1500_4_1|1015_1500_5_0|")
 for i in all(fbtable) do
  if f>=i[1]-0 and f<i[2]-0 then circfill(52+rnd(24),52+rnd(24),rnd(i[3]),i[4]) end
 end

 memcpy(0x0800,0x6800,4096)
 
 rq={}
 
 if f<1025 then
  obu=copy(sword)
  rotate_x(obu, f/400)
  rotate_y(obu, f/200)
  rotate_x(obu, f/600) 
  translate(obu, 0, 0, -2.5-1.8*max(0, f-1000))
 end
 
 if f>=1025 then
  light_compensation=0.4
  obu=copy(helmet)
  rotate_y(obu, f/307+0.1)
  translate(obu, 0, 0, -3-max(0, 1035-f)+min(0, 2*(1500-f)))
 end
 
 send_to_queue(obu)
 render_queue()
 
 bordercol,bgcol,textcol=8,9,0
 drawverse(hurricaneverse)
 
 bordercol,bgcol,textcol=12,1,7
 drawverse(lifeverse)
 
end

function scn7_draw()

 cls()
 for i=0,7 do
  for i2=flr(max(0,f-480)),min(15,f*0.5) do
   i3=flr(i2-f*0.5)%16
   memcpy(0x6000+i*1024+i2*64,0x4300+i3*64,64)
  end
 end

 x,y,z=dot3d_rotate_z(7+3*sin(f/350),0,0,-f/200)
 pal(9,8)
 pal(8,2)
 pal(2,0)
 palt(4, true)
 palt(10, true)
 sspr(0,8,128,120,0+x,0+y,128,127)
 pal()
 palt()
 for i=max(1,f*2-750),min(250,f*2) do
  q,x=i/250,10
  x+=30*(sin(f*0.004)+sin((q-f*0.008)*4))
  nx,ny=60+x*cos(q),60+x*sin(q)
  spr(1,nx,ny)
 end
 
 memcpy(512,0x6000,7680)
 
 bordercol,bgcol,textcol=0,8,7
 drawverse(steelverse)
 
end

function scn8_draw()

 if scn8froze==false then
  cls(0)
  palt(0,false)
  for i=0,15 do
   pal(i, cycleterrain[1][(i-f)%16+1])
  end
  sspr(0,66,128,62,0,66)
   for i=0,15 do
   pal(i, cycleroad[1][(i-f)%16+1])
  end
  sspr(0,98,128,1,0,98)
  palt()
  pal()
  color(5)
  rectfill(0,92,128,97)
  rectfill(0,99,128,106)
  
  palt(0,false)
  palt(7,true)
  spr(f%2,15,97)
  spr(f%2,32,97)
  palt(7,false)
  palt(11,true)
  sspr(0,8,21,16,16,86+(f/27)%1.25)
  sspr(35,8,6,6,25,83+((f/27)+2)%1.12)
  sspr(24,8,11,16,24,86+((f/27)+1)%1.25)
   
  clip(0,0,127,66)
  
  for i=1,27 do
   sspr(40+6*flr(rnd(4)),8+8*flr(rnd(2)),6,8,rain[i].x,rain[i].y,6*rain[i].scale,8*rain[i].scale)
  end
  
  if f>895 then roadwords=roadwords_flash end
  
  for i in all(roadwords) do
   y=70+(-f+i[1])/6
   if y>37 then
    color(1)
    if y>38 then color(2) end
    if y>39 then color(8) end
    if y>40 then color(9) end
    if y>41 then color(10) end
    print(i[3],i[2],y)
   end
  end
  
  palt()
 
  clip()
 
  for x=1,128 do
   fire[x][9]=rnd(32)
   for y=1,8 do
    newval=0
    if x>1 then newval+=fire[x-1][y+1] end
    if x<128 then newval+=fire[x+1][y+1] end
    if y<8 then newval+=fire[x][y+2] end
    newval+=fire[x][y+1]
    fire[x][y]=newval/4.15
    if newval>54 then
     color(2)
     if newval>56 then color(8) end
     if newval>64 then color(10) end
     pset(x,y+57)
    end
   end
  end
  

  
 end
 
  
  flashrects=parse_table("895_0_0_128_128|927_0_0_128_128|959_0_0_128_128|991_0_0_128_128|1023_0_0_128_128|1055_0_0_128_128|1087_0_0_128_128|1119_0_0_128_128|1151_0_0_128_128|1183_0_0_128_128|1215_0_0_128_128|1231_0_0_128_128|1247_0_0_128_128|1263_0_0_128_128|")
  for i in all(flashrects) do
   brightness=i[1]+15-f
   if brightness>0 and brightness<16 then
    fillp(shades[16-brightness]+0.5)
	color(7)

	rectfill(0,0,128,128)
	fillp()
   end
  end
 
end

function _draw()

 
 for i in all(script) do if stat(24)>=i[1]-0 then scn=i[3]-0 end end
 if ended==true then scn=10 end
 if scn==1 then 
  if f>2790 and scn2guitardrawn==false then
   cls(11)
   old_light_compensation=light_compensation
   light_compensation=0.7
   scn1_drawguitar1()
   light_compensation=old_light_compensation
   memcpy(0x1000,0x7000,4096)
   cls()
   gradient={0,1,12,7}
  x,y,shd0,shd1,shdphase=8,0,1,2,2
  for i=1,24 do
   color(16*gradient[shd1]+gradient[shd0])
   fillp(shades[shdphase])
   --rectfill(x,y,x+7,y+7)
   clip(x,y,x+7,y+7)
   circfill(x+4,y+4,32*0.81^(25-i))
   clip()
   x+=8
   if x>=128 then
    x=0
    y+=8
   end
   shdphase+=2
   if shdphase>16 then
    shdphase=2
    shd0+=1
    shd1+=1
   end
  end
  memcpy(0,0x6000,1024)
  fillp()
   scn2guitardrawn=true
  end
   
  cls()
  
  if f<750 then
   sspr(0,0,43,128,0,0)
   fillp()
   rectfill(44,0,84,127,11)
   scn1_drawguitar1()
   if f<750 then water(116,1,10) end
   memcpy(0,0x6000,0x2000)
   cls()
  end
  
  if f>750 and scn1reloaded==false then

   str_to_spr_scan(0,reload_scanline,sub(startgfx, reload_scanline*128+1, reload_scanline*128+128))
   reload_scanline+=1
   if reload_scanline==128 then scn1reloaded=true end
  end
 
  clip(0,0,128,100+scn1elevation*0.13)
  for x=0,15 do
  --spr(3,x*8,0,1,16)
  sspr(16,0,8,127,x*8,-127+scn1elevation*0.19)
  sspr(24,0,8,127,x*8,0+scn1elevation*0.19)
  end
  clip()
  fillp()
 
  color(9)
  circfill(64,64+scn1elevation*0.1,24)
  
  color(0)
  camera(0,0-scn1elevation*0.13)
  isles=parse_table("0_93_13|11_98_8|22_101_8|24_151_56|127_103_15|117_107_15|103_111_16|")
  for i in all(isles) do circfill(i[1],i[2],i[3]) end
  camera(0,0)
 
  water(96+flr(scn1elevation*0.13))
 
  if f>2750 then 
   camera(scn1camerarumble-2*rnd(100*scn1camerarumble)/100, scn1camerarumble-2*rnd(100*scn1camerarumble)/100)
  end
 
  if f>1220 then
   fillp()
   clip(0,0,128,scn1exosphere)
   for i=1,50 do
    color(1)
    if scn1exosphere-scn1starfieldy[i]>22 then color(5) end
    if scn1exosphere-scn1starfieldy[i]>44 then color(6) end
    if scn1exosphere-scn1starfieldy[i]>66 then color(7) end
    pset(scn1starfieldx[i], scn1starfieldy[i])
    if f>2750 and stat(24)<11 then
     hyperx,hypery=scn1hypercharge*scn1starfieldhyperx[i],scn1hypercharge*scn1starfieldhypery[i]
     line(scn1starfieldx[i]-hyperx,scn1starfieldy[i]-hypery,scn1starfieldx[i]+hyperx,scn1starfieldy[i]+hypery,5)
     line(scn1starfieldx[i]-0.5*hyperx,scn1starfieldy[i]-0.5*hypery,scn1starfieldx[i]+0.5*hyperx,scn1starfieldy[i]+0.5*hypery,6)
	 line(scn1starfieldx[i]-0.25*hyperx,scn1starfieldy[i]-0.25*hypery,scn1starfieldx[i]+0.25*hyperx,scn1starfieldy[i]+0.25*hypery,7)
     circfill(64,64,20*scn1hypercharge,7)
    end
   end
   clip()
  end
 
  if f<750 then
   palt(11, true)
   palt(0, false)
   sspr(44,0,40,128,44,0)
   palt()
  else
   scn1_drawguitar1()
  end
  
  if f>1600 and f<2050 then
   if f<1610 or f>2035 then
    left,top=rnd(64),rnd(64)
    right,bottom=left+rnd(64),top+rnd(64)
    sspr(32,0,64,64,4-left,40-top,64+right,64+bottom)
    sspr(32,64,64,64,68-left,56-top,64+right,64+bottom)
   else 
    sspr(32,0,64,64,4,40)
    sspr(32,64,64,64,68,56)
   end

  end
 
  camera(0,0)
 end

 if scn==2 then
 
  cls()
  color(15)

  s2circs=parse_table("0_7|2_4|4_0|")
  for i in all(s2circs) do circfill(8+rnd(4),8+rnd(4),1.1^((f-i[1])*1.2%28),i[2]) end
 
  for i=1,6 do
   line(lines[i].x1,lines[i].y1,lines[i].x2,lines[i].y2,10)
   lines[i].x1,lines[i].y1=lines[i].x2,lines[i].y2
   lines[i].x2+=lines[i].xspd
   lines[i].y2+=lines[i].yspd
   lines[i].xspd+=3-rnd(6)
   lines[i].yspd+=3-rnd(6)
  
   if lines[i].x1<0 or lines[i].x1>20 or lines[i].y1<0 or lines[i].y1>20 then scn2_createline(i) end
  end
 
  circfill(8+rnd(4),8+rnd(4),2,4)
  circfill(9+rnd(2),9+rnd(2),2,0)
 
  if f>3250 then
   scn2whitefade=min(24,scn2whitefade+0.4)
  end
 
  for x=1,20 do
   for y=1,20 do
    scn2grid[x][y]=min(24,scn2grid[x][y]+pget(x-1,y-1))
    scn2grid[x][y]=max(scn2whitefade,scn2grid[x][y]*0.93)
   end
  end
 
  cls()
  camera(3-rnd(6),3-rnd(6))
  for y=0,19 do
   for x=0,19 do
    spr(scn2grid[x+1][y+1],x*6.5-(scn2whitefade/24-1)*(2-rnd(4)),y*6.5-(scn2whitefade/24-1)*(2-rnd(4)))
	--spr(scene2grid[x+1][y+1],x*6.5-4+rnd(2),y*6.5-4+rnd(2))
   end
  end

  camera(10-rnd(20),3-rnd(6))
 
  palt(11, true)
  sspr(40,64,44,64,40,64)
  palt(11, false)
 
  camera()
 end
 
 if scn==3 then 
  cls()
  if f<=990 then scn3_drawtwister() else scn3_drawblinks() end
 end
 
 if scn==4 then
  f=f*2
 
  cls()
  if scn4rotowidth>0 then
   memcpy(0x6800,0x0800,5120)
   xrot,yrot,zoom=cos(f/300),sin(f/300),2+sin(f/500)
   for y=0,24 do
    for x=0,24 do
     u,v=y*yrot+x*xrot,y*xrot-x*yrot
     sset(x+16,y,sget(u%16,v%16))
    end
   end
   clip(56-f*0.045,16,scn4rotowidth,96)
   size=max(3,flr(8/zoom))
   palt(0,false)
   for x=-size,size do
    for y=-size,size do
     xz16,yz16=x*zoom*16,y*zoom*16
     xdot,ydot=64+xz16*xrot-yz16*yrot,64+yz16*xrot+xz16*yrot
     sspr(16,0,24,24,xdot,ydot,24*zoom,24*zoom)
    end
   end
   palt(0,true)
  end
  clip()
 
  bordercol,bgcol,textcol=9,1,7
 
  drawverse(ugverse)
 end
 
 if scn==5 then scn5_draw() end
 if scn==6 then scn6_draw() end
 if scn==7 then scn7_draw() end
 
 if scn==8 then scn8_draw() end
 if scn==9 then
  
  if f<1 then f=1 end
 
  if f>=1120 and f<3500 then
   cls()

   y=1120-f
  
   color(1)
   for i in all(rects) do
    i[6]+=i[5]
    i[6]%=128
    camera(i[6]-64,-0.2*y)
    rectfill(i[1],i[2],i[3],i[4])
   end

   camera()
   sspr(0,0,128,128,0,0)
   rq={}
   obu=copy(flyingv)
   rotate_y(obu, 0.01*f)
   translate(obu, 0, 0.021*(1920-f), -10)
   rotate_z(obu, 0.885)
   send_to_queue(obu)
   render_queue()
   camera(0,-0.25*y)
   color(7)
   credits=parse_table("rock for metal_10_259|by jumalauta_10_267|a celebration of_10_290|true metal spirit_10_298|code, gfx and music_10_326|p-kl_60_334|never surrender_10_360|never compromise_12_368|never turn it down_14_376|")
   for i in all(credits) do print(i[1],i[2],i[3]) end

  end
 
  if f<1120 then 
   --camq[91],camx[91],camy[91]=0,0,0
   q=-camq[f]
  
   cls()
   camera(-64+0.05*camx[f],-64+0.05*camy[f])
   fillp()
  
   for i in all(stars) do
    color(i[3])
    sx,sy,sz=dot3d_rotate_z(i[1],i[2],0,q)
    pset(sx,sy)
   end
  
   camera(camx[f],camy[f])
  
   for i=min(172,tunnel_progress),tunnel_progress-15+1,-1 do
    for i2=1,9 do 

     light=mid(170,255,355-depth[i]*30)

     shade(ringcol[i])
     
     sx,sy=dot3d(dot3d_rotate_z(dx[i][i2],dy[i][i2],depth[i],q))
     if fill[i][i2]<2 or i%12==4 then
     sx2,sy2=dot3d(dot3d_rotate_z(dx[i][i2%9+1],dy[i][i2%9+1],depth[i],q))
     end
     if i<tunnel_progress and i>15 then
      sx3,sy3=dot3d(dot3d_rotate_z(dx[i+1][i2],dy[i+1][i2],depth[i+1],q))
	  if i<172 then line(sx,sy,sx3,sy3) end
      if fill[i][i2]<2 and i<172 then
	   sx4,sy4=dot3d(dot3d_rotate_z(dx[i+1][i2%9+1],dy[i+1][i2%9+1],depth[i+1],q))
       trifill({{sx,sy},{sx2,sy2},{sx3,sy3}})
       trifill({{sx2,sy2},{sx3,sy3},{sx4,sy4}})
      end
     end
     if i%12==4 then line(sx,sy,sx2,sy2) end
    end
   end
   if f>1115 then flip_to_spr() end
  end
 
  camera()
 end
 
 if scn==10 then
  ended=true
  cls()
  flip_to_spr()
  str_to_spr_scan(0,0,nwojml)
  sspr(0,0,128,128,11,41)
 end
 
end