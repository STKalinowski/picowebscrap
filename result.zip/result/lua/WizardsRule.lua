--     copyright (c) 2015
--        chris dawson
--    all rights reserved
--
--    (www.chrisdawson.ca)
--

function is_even(v)
  local h = v/2
  return (h == flr(h))
end

function v2_equal(a,b)
  return (a[1] == b[1]) and (a[2] == b[2])
end

function print_center(s, y, colr)
  local x = #s / 2 * 4
  print(s,64-x,y,colr)
end

function print_right(s, x, y, colr)
  print(s,x-(#s * 4),y,colr)
end

function grid_2_pixel(c, p, offset)
  offset = offset or {0,0}
  p[1] = -19 + (c[1] * 11) + offset[1]
  p[2] = 6 + (c[2] * 12) + offset[2]
end

function pixel_2_grid(p, c, offset)
  offset = offset or {0,0}
  c[1] = flr((p[1] + 19 + offset[1]) / 11)
  c[2] = flr((p[2] - 6 + offset[2]) / 12)
end

function set_grid_cell(c, dir, blocked)
  local dirbit = 2^dir
  grid[c[2]][c[1]] = (blocked) and (bor(grid[c[2]][c[1]], dirbit)) or (band(grid[c[2]][c[1]], bnot(dirbit)))
end

function get_speed(sfx)
  return peek(0x3200 + 68*sfx + 65)
end

function set_speed(sfx, speed)
  poke(0x3200 + 68*sfx + 65, speed)
end

function add_score(score, value)
  score[2] = score[2] + value
  if (score[2] >= 1000) then
    local t = flr(score[2] / 1000)
    score[2] = score[2] - t * 1000
    score[1] = score[1] + t
  end
end

function _fscore(s)
  local r = ""
  for i=1,3-#s do r = r .. "0" end
  return r .. s
end

function format_score(score)
  return _fscore("" .. score[1]) .. _fscore("" .. score[2])
end

-- maps
--
num_maps = 12

level = 0
ready_level = nil
game_over = nil
screen = 0
p1_hscore = {0,0}
p2_hscore = {0,0}
doublescore = false
multiplier = 1
grid = {}
keep_door_open = false
door_open = false
door_left = {1,3}
door_right = {13,3}
msg = "radar"
entity_offset = {2,3}

players = {}
monsters = {}
stars = {} -- of {x,y,color}
ctrls = {}

tempo = {spd=175,min=175,max=15,cnt=0,sound=11}
speed = 0.125

-- animation {hs,vs,a,delay,sound}
--   a: frame sequence; use frame# -1 to stop playback
--   delay: #updates per frame (30 updates / sec)
-- state {animation, frame, delay}
sprite = {}

pts = {
  beast=100,
  lizard=200,
  manticore=500,
  warrior=1000,
  imp=1000,
  wizard=2500
}

-- character sprite flags:
-- bit 0: true == facing left
--
-- dir {0,1,2,3} == left,right,up,down

function new_sprite(_sprite, _cell, _points, _speed)
  local p = {0,0}
  grid_2_pixel(_cell, p, entity_offset)
  return {
    sprite = _sprite,
    state = {nil,0,0},
    cell = {_cell[1],_cell[2]},
    cell_default = {_cell[1], _cell[2]},
    pos = p,
    points = _points,
    speed = _speed or 1,
    max_speed = 3,
  }
end

-- call with sprite.laser1 or sprite.laser2
function new_laser(_sprite, _parent, _pos, _dir, _speed)
  local c = {0,0}
  pixel_2_grid(_pos, c, {3,3})
  return {
    sprite = _sprite,
    parent = _parent,
    state = {nil,0,0},
    cell = c,
    pos = {_pos[1], _pos[2]},
    dir = _dir,
    steer = _dir,
    speed = _speed or 6,
    max_speed = 6,
    is_laser = true,
  }
end

function set_cell(e, cell)
  local c = cell or e.cell_default
  if c then
    e.cell[1] = c[1]
    e.cell[2] = c[2]
    grid_2_pixel(c, e.pos, entity_offset)
  end
end

timers = {}
processing_timers = false
function clear_timers()
  if (processing_timers) then assert() end
  timers = {}
end
function add_timer_secs(nsec, clbk, times)
  add_timer(nsec*30, clbk, times)
end
function add_timer(cnt, clbk, times)
  timers[#timers+1] = {cnt, cnt, clbk, times}
end
function update_timers()
  processing_timers = true
  local i = 1
  while (i <= #timers) do
    if (timers[i]) then
      timers[i][2] -= 1
      if (timers[i][2] <= 0) then
        timers[i][3]()
        if (timers[i][4]) then timers[i][4] -= 1 end
        if (timers[i][4]) and (timers[i][4] <= 0) then
          timers[i] = timers[#timers]
          timers[#timers] = nil
          i -= 1
        else
          timers[i][2] = timers[i][1] -- reset the timer
        end
      end
    end
    i += 1
  end
  processing_timers = false
end

function draw_stars()
  for s in all(stars) do
    if rnd(1) < 0.05 then
      s[3] = 5 + flr(rnd(2)) -- color 5-6
    end
    line(s[1],s[2],s[1],s[2],s[3])
  end
end

function draw_bgnd()
  rectfill(0,0,127,127,0)
  draw_stars()
  spr(96,4,0,15,2) -- marquee
end

function draw_map(colr)
  local cell
  local neighbor
  local p = {0,0}
  for row = 1,7 do
    for col = 1,13 do
      grid_2_pixel({col,row}, p)
      cell = grid[row][col]
      neighbor = (col > 1) and (grid[row][col-1]) or (nil)
      if (band(cell, 1) == 1) and ((not neighbor) or (band(neighbor,2) == 2)) then
        line(p[1],p[2],p[1],p[2]+12,colr)
      end
      neighbor = (col < 13) and (grid[row][col+1]) or (nil)
      if (band(cell, 2) == 2) and ((not neighbor) or (band(neighbor,1) == 1)) then
        line(p[1]+11,p[2],p[1]+11,p[2]+12,colr)
      end
      neighbor = (row > 1) and (grid[row-1][col]) or (nil)
      if (band(cell, 4) == 4) and ((not neighbor) or (band(neighbor,8) == 8)) then
        line(p[1],p[2],p[1]+11,p[2],colr)
      end
      neighbor = (row < 7) and (grid[row+1][col]) or (nil)
      if (band(cell, 8) == 8) and ((not neighbor) or (band(neighbor,4) == 4)) then
        line(p[1],p[2]+12,p[1]+11,p[2]+12,colr)
      end
    end
  end

  if door_open then
    spr(17,-4,45,1,1,not fget(17,0))
    spr(17,124,45,1,1,fget(17,0))
  end
end

-- 2x2 cells with 1 pxl spacing
function draw_radar()
  rect(63-17,102,63+18,102+20,1) -- 14x11 cells
end

function draw_radar_entity(e)
  if e and e.sprite then
    local p = {e.cell[1], e.cell[2]}
    p[1] = ((p[1]-2)*3)+1
    p[2] = ((p[2]-1)*3)+1
    rect(63-16+p[1],103+p[2],63-16+p[1]+1,103+p[2]+1,e.sprite.colr)
  end
end

function draw_score()
  rectfill(0,103,32,115,sprite.warrior_blue.colr)
  rectfill(3,106,29,112,0)
  print(format_score(players[2].score),5,107,sprite.warrior_blue.colr)
  rectfill(95,103,127,115,sprite.warrior_yellow.colr)
  rectfill(98,106,124,112,0)
  print(format_score(players[1].score),100,107,sprite.warrior_yellow.colr)
end

function _draw_lives(p, sprite)
  local pos = {0,0}
  grid_2_pixel(p.cell_default, pos, entity_offset)
  if (p.lives > 0) then
    local s = sprite.hs
    if p == players[1] then
      spr(s,pos[1],pos[2],1,1,not fget(s,0))
      if (p.door_closed_in and p.door_closed_in > 0 and p.door_closed_in < 6) then
        print("(" .. p.door_closed_in .. ")", pos[1]-16, pos[2]+2, sprite.colr)
      elseif (p.lives > 1) then
        print("" .. p.lives .. " x", pos[1]-16, pos[2]+2, sprite.colr)
      end
    else
      spr(s,pos[1],pos[2],1,1,fget(s,0))
      if (p.door_closed_in and p.door_closed_in > 0 and p.door_closed_in < 6) then
        print("(" .. p.door_closed_in .. ")", pos[1]+13, pos[2]+2, sprite.colr)
      elseif (p.lives > 1) then
        print("x " .. p.lives, pos[1]+13, pos[2]+2, sprite.colr)
      end
    end
  end
end

function draw_lives()
  _draw_lives(players[1], sprite.warrior_yellow)
  _draw_lives(players[2], sprite.warrior_blue)
end

function draw_msg(name)
  msg = (doublescore) and "double score" or name or msg
  print_center(msg,95,10)
end

function draw_entities()
  for i=1,#monsters do
    draw_entity(monsters[i].laser)
    if (not monsters[i].invisible or can_see(monsters[i], players[1]) or can_see(monsters[i], players[2])) then draw_entity(monsters[i]) end
    draw_radar_entity(monsters[i])
  end

  for i=1,2 do
    draw_entity(players[i].laser)
    draw_entity(players[i])
  end
end

function draw_entity(e)
  if (e and e.pos ~= nil) then
    local hs = e.sprite and e.sprite.hs
    local vs = e.sprite and e.sprite.vs
    local s_offset = 0
    local anim = e.state
    if (anim[1] ~= nil and anim[1].a[anim[2]] ~= -1) then
      hs = anim[1].hs
      vs = anim[1].vs
      s_offset = anim[1].a[anim[2]]
    end
    if (hs) then
      local flipx = false
      local flipy = false
      local s = hs + s_offset
      if (vs) then
        if ((e.dir == 2) or (e.dir == 3)) then s = vs + s_offset end
        flipx = ((e.dir == 0) and not fget(s,0)) or ((e.dir == 1) and fget(s,0))
        flipy = ((e.dir == 2) and not fget(s,0)) or ((e.dir == 3) and fget(s,0))
      end
      spr(s,e.pos[1],e.pos[2],1,1,flipx,flipy)
    end
  end
end

function door(open)
  door_open = open
  set_grid_cell({1,3}, 1, not open)
  set_grid_cell({2,3}, 0, not open)
  set_grid_cell({12,3}, 1, not open)
  set_grid_cell({13,3}, 0, not open)
end

function dist2target(start_cell, target_cell)
  local dx = abs(start_cell[1] - target_cell[1])
  local dy = abs(start_cell[2] - target_cell[2])
  return (dx * dx) + (dy * dy)
end

function dir2target(start_cell, target_cell)
  local dir = nil
  if target_cell then
    local dx = start_cell[1] - target_cell[1]
    local dy = start_cell[2] - target_cell[2]
    dir = (abs(dx) > abs(dy)) and ((dx < 0) and 1 or 0) or ((dy < 0) and 3 or 2)
  end
  return dir
end

function nearest_target(start_cell, r_sqrd, t1, t2)
  local d_p1 = t1 and dist2target(start_cell, t1) or 1000
  local d_p2 = t2 and dist2target(start_cell, t2) or 1000
  local m = min(d_p1, d_p2)
  return (m <= r_sqrd) and ((m == d_p1) and t1 or t2) or nil
end

-- t1, t2 are target cells
function steer(e, blocked, t1, t2)
  local back = (e.dir == 0) and 1 or ((e.dir == 1) and 0 or ((e.dir == 2) and 3 or 2))
  local dir2 = (e.dir == 0) and 3 or ((e.dir == 1) and 2 or ((e.dir == 2) and 0 or 1))
  local dir3 = (e.dir == 0) and 2 or ((e.dir == 1) and 3 or ((e.dir == 2) and 1 or 0))

  local go_dir2 = (band(grid[e.cell[2]][e.cell[1]], 2^dir2) == 0) and 100 or 0
  local go_dir3 = (band(grid[e.cell[2]][e.cell[1]], 2^dir3) == 0) and 100 or 0

  if (blocked or (go_dir2 > 0) or (go_dir3 > 0)) then
    local targetdir = dir2target(e.cell, nearest_target(e.cell, 36, t1, t2)) or e.dir
    if ((go_dir2 > 0) and (go_dir3 > 0)) then
      go_dir2 = (targetdir == dir2) and 75 or ((targetdir == dir3) and 25 or 50)
      go_dir3 = 100 - go_dir2
    end

    local changedir = blocked and 100 or ((targetdir == e.dir) and 10 or 90)
    if (rnd(100) < changedir) then
      if (blocked and rnd(100) < 5) then
        e.steer = back
      elseif (rnd(100) < go_dir2) then
        e.steer = dir2
      elseif (go_dir3 > 0) then
        e.steer = dir3
      else
        e.steer = back
      end
    end
  end
end

function remove_wizard(m, killed)
  if (m.spawntype == 5) then
    if killed then
      sfx(19,1)
    else
      add_timer(1, function() kill(m) end, 1)
    end
  end
end

function update_entities()
  local i = 1
  while i <= #monsters do
    local m = monsters[i]
    if (m) then
      m.speed = min(m.max_speed, max(m.speed, speed))
      update_animation(m)
      if not is_alive(m) then
        if not m.state[1] then -- wait for death animation to complete
          monsters[i] = monsters[#monsters]
          monsters[#monsters] = respawn(m) -- or nil
          i -= 1
        end
      else
        local prev_cell = {m.cell[1],m.cell[2]}
        local moved = update_entity(m)
        if (not moved) or (not v2_equal(m.cell, prev_cell)) then
          steer(m,
                not moved,
                is_alive(players[1]) and players[1].cell or door_left,
                is_alive(players[2]) and players[2].cell or door_right)
        end

        if collision_test(m, players, nil, function(p) if is_alive(p) then kill(p, p.sprite.die); clear_game_ctrls(p) end end) then
          remove_wizard(m)
        end

        if (m.laser) then
          if not update_entity(m.laser) then
            m.laser = nil
          else
            if collision_test(m.laser, players, nil, function(p) if is_alive(p) then kill(p, p.sprite.die); clear_game_ctrls(p) end end) then
              m.laser = nil
              remove_wizard(m)
            end
          end
--        elseif ((m.speed <= 1) and (rnd(100) <= 1) and (can_see(m, players[1]) or can_see(m, players[2]))) then
        elseif (m.can_fire and (not m.reloading) and (not m.invisible) and (m.speed < 1.5)) then
          m.reloading = m.can_fire
          if (rnd(100) <= 50) then
            m.laser = new_laser(sprite.laser2, m, m.pos, m.dir, 2)
            sfx(14,1)
          end
        end
      end
    end
    i += 1
  end

  i = 1
  while i <= #players do
    update_animation(players[i])
    if not is_alive(players[i]) then
      if not players[i].state[1] then -- wait for death animation to complete
        next_up(players[i])
      end
    else
      update_entity(players[i])
      if (players[i].laser) then
        if not update_entity(players[i].laser) then
          players[i].laser = nil
        else
          if collision_test(players[i].laser, monsters, nil, function(m) if is_alive(m) then m.invisible = nil; kill(m, sprite.explosion.explode); remove_wizard(m, true); add_score(players[i].score, m.points * multiplier); doublescore = doublescore or (m.spawntype == 4) end end) then
            players[i].laser = nil
          else
            if collision_test(players[i].laser, players, {[players[i]]=true}, function(p) if is_alive(p) then kill(p, p.sprite.die); add_score(players[i].score, p.points * multiplier); clear_game_ctrls(p) end end) then
              players[i].laser = nil
            end
          end
        end
      end
    end
    i += 1
  end
end

function update_entity(e)
  local moved = false
  if (e and e.steer) then
    if move(e, e.steer) then
      e.dir = e.steer
      moved = true
    elseif (e.dir and (e.dir ~= e.steer)) then
      if move(e, e.dir) then
        moved = true
      end
    end
  end

  if moved then
    -- only start walk anim when no other is playing
    if (e.state[1] == nil) then set_animation(e, e.sprite.walk) end
  else
    if (e.state[1] == e.sprite.walk) then e.state[1] = nil end
  end

  if (e.turn_invisible and e.turn_invisible > 0) then
    e.turn_invisible -= 1
    if (e.turn_invisible <= 0) then
      e.turn_invisible = 60
      e.invisible = (rnd(100) <= 75)
    end
  end

  if (e.can_fire and e.reloading) then
    e.reloading -= 1
    if (e.reloading <= 0) then
      e.reloading = nil
    end
  end

  if (e.can_teleport) then
    e.can_teleport -= 1
    if (e.can_teleport <= 0) then
      e.can_teleport = 30
      if (rnd(100) <= 33) then
        set_cell(e, rnd_cell())
        moved = true
      end
    end
  end

  return moved
end

function update_animation(e)
  local anim = e.state
  if (anim[1] ~= nil) then
    if (anim[1].a[anim[2]] == -1) then
      anim[1] = nil
    else
      anim[3] -= 1
      if (anim[3] <= 0) then
        anim[3] = anim[1].delay - e.speed
        anim[3] = anim[1].delay
        anim[2] = (anim[2] < #anim[1].a) and (anim[2]+1) or 1
      end
    end
  end
end

function is_alive(e)
  return e.sprite
end

function kill(e, death)
  if is_alive(e) then
    set_animation(e, death)
    if (death) then
      sfx(death.sound,2)
    end
    e.sprite = nil
    e.laser = nil
  end
end

function player_game_over(p)
  return (not is_alive(p)) and (p.lives <= 0)
end

function next_up(p)
  if not p.next_up then
    p.next_up = true
    set_cell(p) -- default
    if (p.lives > 0) then
      setup_push(p)
    else
      if player_game_over(players[1]) and player_game_over(players[2]) then
        add_timer_secs(3, function() game_over = true end, 1)
      end
    end
  end
end

-- return all targets colliding with e
function collision_test(e, targets, exclude, fn)
  local result = {}
  for i=1,#targets do
    local t = targets[i]
    if (not exclude or not exclude[t]) then
      if (abs(e.pos[1] - t.pos[1]) < 7) and (abs(e.pos[2] - t.pos[2]) < 7) then
        result[#result+1] = t
      end
    end
  end
  foreach(result, fn)
  return (#result > 0) and result or nil
end

function process_btn(b)
  for bit=1,16 do
    if (band(b,shl(1,bit-1)) > 0) then
      if ctrls[bit] then ctrls[bit]() end
    end
  end
end

-- update e's pos and cell if can move
-- return false if can't move
function move(e, dir)
  local dirbit = 2^dir
  local move_axis = ((dir == 0) or (dir == 1)) and 1 or 2
  local perp_axis = (move_axis == 1) and 2 or 1
  local pos = e.pos
  local cell = e.cell
  local cell_pos = {0,0}
  grid_2_pixel(cell, cell_pos, entity_offset)

  -- snap
  if (abs(pos[perp_axis] - cell_pos[perp_axis]) <= 3) then
    if (band(grid[cell[2]][cell[1]], dirbit) == 0) then
      pos[perp_axis] = cell_pos[perp_axis]
    end
  end
  if (pos[perp_axis] ~= cell_pos[perp_axis]) then
    return false
  end

  if (band(grid[cell[2]][cell[1]], dirbit) == dirbit) then
    local d = cell_pos[move_axis] - pos[move_axis]
    local m = (d >= 0) and 1 or -1
    d = min(abs(d), e.speed)
    if (d > 0) then
      pos[move_axis] += (d * m)
      return true
    end
  else
    local spd = (band(dirbit, 10) > 0) and e.speed or -e.speed
    pos[move_axis] += spd

    -- teleport
    if door_open and ((pos[1] < 3) or (pos[1] > 117)) then
      if (e.spawntype and e.spawntype == 4) then
        add_timer(1, function() kill(e); msg = "escaped" end, 1)
        sfx(16,1)
        return true
      elseif e.is_laser then
        return false
      else
        pos[1] = (pos[1] < 3) and 115 or 5
        if (not keep_door_open) then
          door(false)
          add_timer_secs(10, function() door(true) end, 1)
        end
      end
    end

    pixel_2_grid(pos, cell, {3,3})
    return true
  end
end

-- state = {animation,frame-index,delay}
function set_animation(e, a)
  local anim = e.state
  if (anim[1] ~= a) then
    anim[1] = a
    anim[2] = 1
    anim[3] = (a) and a.delay or 0
  end
end

-- return true if e1 & e2 in same row/col & not separated by a wall
function can_see(e1, e2)
  local e1_cell = e1.cell
  local e2_cell = e2.cell
  if (e1_cell[1] == e2_cell[1]) then
    if (e1_cell[2] == e2_cell[2]) then return true end

    local top,bottom = e1_cell,e2_cell
    if (e1_cell[2] > e2_cell[2]) then
      top,bottom = e2_cell,e1_cell
    end
    for y = top[2], bottom[2]-1 do
      if (band(grid[y][top[1]], 8) == 8) then
        return false -- blocked
      end
    end
    return true
  elseif (e1_cell[2] == e2_cell[2]) then
    local left,right = e1_cell,e2_cell
    if (e1_cell[1] > e2_cell[1]) then
      left,right = e2_cell,e1_cell
    end
    for x = left[1], right[1]-1 do
      if (band(grid[left[2]][x], 2) == 2) then
        return false -- blocked
      end
    end
    return true
  end
  return false
end

function clear_game_ctrls(p)
  local shift = (p == players[2]) and 8 or 0
  for i=1,5 do
    ctrls[i + shift] = nil
  end
end

function set_game_ctrls(p)
  local s = p.sprite
  local shift = (p == players[2]) and 8 or 0
  ctrls[1 + shift] = function() p.steer = 0 end
  ctrls[2 + shift] = function() p.steer = 1 end
  ctrls[3 + shift] = function() p.steer = 2 end
  ctrls[4 + shift] = function() p.steer = 3 end
  ctrls[5 + shift] = function() if (s and not p.laser) then p.laser = new_laser(sprite.laser1, p, p.pos, p.dir); set_animation(p, s.fire); sfx(s.fire.sound,3) end end
end

function push(e)
  e.lives -= 1
  e.door_closed_in = -1
  e.sprite = (e == players[1]) and sprite.warrior_yellow or sprite.warrior_blue
  e.next_up = nil
  add_timer(12, function() set_grid_cell(e.cell_default, 2, true); set_game_ctrls(e) end, 1)
  add_timer(1, function() e.pos[2] -= 1; pixel_2_grid(e.pos, e.cell, {3,3}) end, 12)
end

function setup_push(e)
  local shift = (e == players[2]) and 8 or 0
  e.dir = (e == players[1]) and 0 or 1
  e.door_closed_in = 10
  ctrls[3 + shift] = function() p.steer = 2 end
  add_timer_secs(1, function() e.door_closed_in -= 1; if (e.door_closed_in == 0) then ctrls[3+shift] = nil; push(e) end; end, e.door_closed_in)
  ctrls[3+shift] = function() ctrls[3+shift] = nil; push(e) end
  set_grid_cell(e.cell_default, 2, false)
end

function rnd_cell(cell)
  cell = (cell) or {0,0}
  cell[1] = flr(rnd(11)+2)
  cell[2] = flr(rnd(6)+1)
  while nearest_target(cell,
                       9,
                       is_alive(players[1]) and players[1].cell or nil,
                       is_alive(players[2]) and players[2].cell or nil) do
    cell[1] = flr(rnd(11)+2)
    cell[2] = flr(rnd(6)+1)
  end
  return cell
end

spawn_cnt=0 -- at most 6
spawn2_cnt=0
spawn2_pending=0
spawn4_pending=0
function spawn()
  spawn_cnt = 6
  spawn2_cnt = min(level,6)
  spawn2_pending = spawn2_cnt
  spawn4_pending = (level > 1) and 1 or 0
  local cell = {0,0}
  for i=#monsters+1,#monsters+6 do
    rnd_cell(cell)
    monsters[i] = new_sprite(sprite.beast, cell, pts.beast, speed)
    monsters[i].max_speed = 1.5
    monsters[i].spawntype = 1
    monsters[i].can_fire = 150
    monsters[i].reloading = monsters[i].can_fire
    set_animation(monsters[i], monsters[i].sprite.walk)
  end
end

function respawn(e)
  local result = nil
  if (e.spawntype == 4 and doublescore) then
    if (rnd(100) <= 40) then
      result = new_sprite(sprite.wizard, rnd_cell(), pts.wizard, 1.45)
      result.max_speed = 1.45
      result.can_fire = 4
      result.can_teleport = 30
      set_speed(15,1)
    else
      sfx(17,1)
      spawn_cnt -= 1
    end
  elseif (e.spawntype == 2) then
    result = new_sprite(sprite.manticore, rnd_cell(), pts.manticore, speed)
    result.max_speed = 2.5
    result.can_fire = 90
    result.turn_invisible = 60
  elseif (e.spawntype == 1) and (spawn_cnt <= spawn2_cnt) and (spawn2_pending > 0) then
    spawn2_pending -= 1
    result = new_sprite(sprite.lizard, rnd_cell(), pts.lizard, speed)
    result.max_speed = 2
    result.can_fire = 90
    result.turn_invisible = 60
  else
    spawn_cnt -= 1
  end

  if result then
    result.spawntype = e.spawntype + 1
    result.reloading = result.can_fire
  end

  if (spawn_cnt <= 0) then -- next level or imp
    if (spawn4_pending >= 1) then
      spawn4_pending -= 1
      spawn_cnt += 1
      result = new_sprite(sprite.imp, rnd_cell(), pts.imp, 2.25)
      result.max_speed = 2.25
      result.spawntype = 4
      if (door_open) then
        door(false)
        add_timer_secs(5, function() door(true) end, 1)
      end
      keep_door_open = true
      set_speed(15,3)
      sfx(15,0)
    else
      sfx(-2,0)
      add_timer_secs(2, function() if is_alive(players[1]) then players[1].lives += 1 end; if is_alive(players[2]) then players[2].lives += 1 end; ready_level = level+1 end, 1)
    end
  end

  if result then set_animation(result, result.sprite.walk) end
  return result
end

function loadmap()
  local num = ((level-1) % num_maps) + 1
  local mapinfo = get_mapinfo(num)
  msg = mapinfo[1]
  to_grid(mapinfo[2])
  door_open = true
  keep_door_open = false
  multiplier = (doublescore) and 2 or 1
  doublescore = false

  for i=1,2 do
    players[i].laser = nil
    players[i].door_closed_in = nil
    players[i].next_up = nil
    next_up(players[i])
  end

  speed = 0.125 + min(((level-1) / 10), 1)
  spawn()

  tempo.spd = tempo.min
  set_speed(tempo.sound,tempo.spd)
  sfx(tempo.sound,0)
  add_timer(7, function() tempo.spd = max(tempo.max, tempo.spd - 1); set_speed(tempo.sound,tempo.spd); speed = min(3, speed + 0.001) end)
end

function reset_game()
  -- players
  for i=1,2 do
    players[i] = new_sprite(nil, {12-((i-1)*10),7}, pts.warrior)
    players[i].score = {0,0}
    players[i].lives = 0
  end
  monsters={}
  level = 0
  msg = "radar"
  clear_grid()
  door_open = false
  keep_door_open = false
  set_screen(1)
end

function set_screen(n)
  ctrls = {}
  screen = n
  if screen == 1 then
    add_timer_secs(4, function() set_screen(3) end, 1)
    ctrls[3] = function() sfx(12,3); players[1].lives = 3; clear_timers(); set_screen(2) end
  elseif screen == 2 then
    ctrls[3] = function() sfx(12,3); players[1].lives = 7; if (players[2].lives > 0) then players[2].lives = players[1].lives end; ctrls[3] = nil end
    ctrls[5] = function() ctrls = {}; draw_bgnd(); ready_level = 1; set_screen(20) end
    ctrls[13] = function() sfx(sprite.warrior_blue.fire.sound,3); players[2].lives = players[1].lives; ctrls[13] = nil end
  elseif screen == 3 then
    add_timer_secs(4, function() set_screen(1) end, 1)
    ctrls[3] = function() sfx(12,3); players[1].lives = 3; clear_timers(); set_screen(2) end
  end
end

function clear_grid()
  for row=1,7 do grid[row] = {} end
end

function set_hscore(hscore, score)
  if (score[1] > hscore[1]) or ((score[1] == hscore[1]) and (score[2] > hscore[2])) then
    hscore[1] = score[1]
    hscore[2] = score[2]
  end
end

function _init()
  load_table(10823, sprite) -- sprite data from cart
	for i=1,75 do stars[i] = {flr(rnd(128)),flr(rnd(128)),5} end
  camera(0,0)
  reset_game()
end

function _update()
  update_timers()
  if screen == 20 then
    if game_over then
      game_over = nil
      clear_timers()
      sfx(-2, 0) -- release sound from looping
      set_screen(13)
      add_timer_secs(1, function() music(2,0,7); print_center("game over", 47, 8) end, 1)
      add_timer_secs(9, function() reset_game() end, 1)
      set_hscore(p1_hscore, players[1].score)
      set_hscore(p2_hscore, players[2].score)
    elseif ready_level then
      level = ready_level
      ready_level = nil
      clear_timers()
      sfx(-2, 0) -- release sound from looping
      set_screen(10)
      add_timer_secs(1, function() music(0,0,7); print_center("get ready", 47, 10) end, 1)
      add_timer_secs(3, function() print_center("go", 57, 10) end, 1)
      add_timer_secs(4.5, function() set_screen(20); loadmap(); end, 1)
    else
      players[1].steer = nil
      players[2].steer = nil
      process_btn(btn())
      update_entities()
    end
  else
    process_btn(btnp())
  end
end

function _draw()
  if screen == 1 then
    draw_bgnd()
    to_screen(2)
    print_right(format_score(p2_hscore), 42, 62, 12)
    print_right(format_score(p1_hscore), 110, 62, 10)
  elseif screen == 2 then
    draw_bgnd()
    draw_lives()
    if (players[2].lives <= 0) then
      to_screen(3)
    else
      to_screen(4)
    end
    if (players[1].lives == 3) then
      to_screen(5)
    else
      to_screen(6)
    end
  elseif screen == 3 then
    draw_bgnd()
    to_screen(1) -- roster
  elseif screen == 20 then
    draw_bgnd()
    draw_map(8)
    draw_radar()
    draw_score()
    draw_lives()
    draw_msg()
    draw_entities()
  end
end

-- default : returned if no result
function get_map_cell(base_addr, x, y, default)
  local result = default
  if (x >= 1 and x <= 25 and y >= 1 and y <= 15) then
    local bit_num = ((y-1)*25)+(x-1)
    local byte = peek(base_addr + flr(bit_num / 8))
    local bit_pos = 8 - (bit_num % 8)
    local mask = shl(1,bit_pos-1)
    result = band(byte,mask)
  end
  return result
end

-- create a 7x13 {row,col} nav grid
-- cell bits:
--   1 : left blocked
--   2 : right blocked
--   4 : up blocked
--   8 : down blocked
function to_grid(addr)
  local row = 1
  local y = 2
  while (y <= 14) do
    local col = 1
    local x = 1
    while (x <= 25) do
      local l = (get_map_cell(addr, x-1, y, 0) == 0) and 0 or 1
      local r = (get_map_cell(addr, x+1, y, 0) == 0) and 0 or 2
      local u = (get_map_cell(addr, x, y-1, 0) == 0) and 0 or 4
      local d = (get_map_cell(addr, x, y+1, 0) == 0) and 0 or 8
      grid[row][col] = bor(l, bor(r, bor(u, d)))
      col += 1
      x += 2
    end
    row += 1
    y += 2
  end
end

function get_mapinfo(num)
  local addr = 8756 + ((num-1) * 12) -- indices start addr == 8756
  return {decode(addr+2,10), bor(shl(peek(addr),8), peek(addr+1))}
end

-- menu screens
--
cipher = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6","7","8","9","'","_"}
screens = {
  {10240, 22}, -- roster
  {10507, 6},  -- hscores
  {10598, 3},  -- credits1
  {10682, 2},  -- credits2
  {10732, 4},  -- credits3
  {10809, 1},  -- credits4
}

function to_screen(num)
  local addr = screens[num][1]
  for i=1,screens[num][2] do
    if peek(addr) == 1 then -- print command
      print(decode(addr+5,peek(addr+3)),peek(addr+1),peek(addr+2),peek(addr+4))
      addr += peek(addr+3) + 5
    elseif peek(addr) == 2 then -- spr command
      spr(peek(addr+1),peek(addr+2),peek(addr+3),peek(addr+4),peek(addr+5),(peek(addr+6)==1),(peek(addr+7)==1))
      addr += 8
    end
  end
end

function decode(addr, cnt)
  local s = ""
  for i=0,cnt-1 do
    s = s .. (cipher[peek(addr+i)] or " ")
  end
  return s
end

function load_table(addr, t)
  local size = 0
  local key
  if peek(addr) == 3 then
    size = peek(addr+1)
    addr += 2
    for i=1,size do
      -- key
      key = decode(addr+1, peek(addr))
      addr += peek(addr) + 1

      -- value
      local value = nil
      if peek(addr) == 3 then
        value = {}
        addr = load_table(addr, value)
      elseif peek(addr) == 4 then
        value = {}
        addr = load_array(addr, value)
      elseif peek(addr) == 5 then
        value = decode(addr+2, peek(addr+1))
        addr += peek(addr) + 2
      elseif peek(addr) == 6 then
        value = bor(shl(peek(addr+1),8), peek(addr+2))
        addr += 3
      end
      t[key] = value
    end
  end
  return addr
end

function load_array(addr, a)
  local size = 0
  if peek(addr) == 4 then
    size = peek(addr+1)
    addr += 2
    for i=1,size do
      local value = nil
      if peek(addr) == 6 then
        value = bor(shl(peek(addr+1),8), peek(addr+2))
        addr += 3
      end
      a[i] = value
    end
  end
  return addr
end
