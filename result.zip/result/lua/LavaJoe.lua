-- lava joe
-- by paranoid cactus

ver=1

function _init()
	cartdata("lavajoe")
	btnjmp,btnshoot,blinktimer,gamemode,scores,particles,titletimer=5,4,0,0,{},{},0
	wavet1,wavet2,wavem=0,0,0
	for t in all(title) do
		t.x1,t.y1,t.x2,t.y2,t.s1,t.s2=t[1]+rnd(2),t[2]+rnd(2),t[1]+rnd(2),t[2]+rnd(2),3+rnd(3),3+rnd(3)
	end
	if peek(0x5e00)==ver then
		for i=1,3 do
			namei[i]=peek(0x5e00+i)
		end
		for i=0,9 do
			local namestr=""
			for n=0,2 do
				local v=peek(0x5e04+i*7+n)
				namestr=namestr..sub(chars,v,v)
			end
			scores[i+1]={namestr,peek2(0x5e04+i*7+3),peek2(0x5e04+i*7+5)}
		end
		btnjmp=peek(0x5e4a)
		btnshoot=peek(0x5e4b)
	else
		resetscores()
	end
	nametostr()
	music(25)
	
	titlemenu={{t="play",f=new_game,x=36},{t="swap buttons",f=invertbuttons,x=75}}
	titlemenui=1
	
	menuitem(1,"swap buttons",invertbuttons)
end

function _update60()
	local jbtnp=btnp(btnjmp)
	if gamemode==0 then
		titletimer=(titletimer+1)%600
		local lt=0
		if titletimer>540 then
			lt=mid(0,1,(titletimer-540)/-60+1)
		elseif titletimer>240 then
			lt=mid(0,1,(titletimer-240)/60)
		end
		titlecamx=smooth_lerp(0,128,lt)
		if blinktimer==31 then
			for t in all(title) do
				t.x1,t.y1,t.x2,t.y2,t.s1,t.s2=t.x2,t.y2,t[1]+rnd(2),t[2]+rnd(2),t.s2,3+rnd(3)
			end
		end
		if btnp(0) then
			titlemenui=max(titlemenui-1,1)
			sfx(0)
		elseif btnp(1) then
			titlemenui=min(titlemenui+1,2)
			sfx(0)
		elseif jbtnp or btnp(btnshoot) then
			titlemenu[titlemenui]:f(jbtnp)
			sfx(5)
		end
		local cols={10,9,8,11}
		new_particle(flr(rnd(128)),108+rnd(56),0,-0.75,cols[flr(rnd(4))+1],48,0,true)
	else
		if gamemode==3 then
			if cursori then
				if btnp(2) then
					namei[cursori]=namei[cursori]%#chars+1
					scores[winindex][1]=nametostr()
					sfx(20)
				elseif btnp(3) then
					namei[cursori]-=1
					if namei[cursori]==0 then
						namei[cursori]=#chars
					end
					scores[winindex][1]=nametostr()
					sfx(20)
				end
				if btnp(0) then
					cursori=max(cursori-1,1)
					sfx(0)
				elseif btnp(1) then
					cursori=min(cursori+1,3)
					sfx(0)
				elseif jbtnp or btnp(btnshoot) then
					cursori+=1
					sfx(0)
					if cursori>=4 then
						savescores()
						cursori=nil
						music(25)
					end
				end
			elseif jbtnp or btnp(btnshoot) then
				dying,winindex,gamemode,particles,titletimer,titlecamx=nil,nil,0,{},0,0
				return
			end
		elseif dying and dying<60 then
			totalscore=flr(distance)+score*10
			winindex,cursori=nil,nil
			for i=1,10 do
				if scores[i][3]<totalscore then
					winindex=i
					break
				end
			end
			if winindex then
				for i=9,winindex,-1 do
					scores[i+1]=scores[i]
				end
				scores[winindex]={name,flr(distance),totalscore}
				cursori=1
				music(24)
			else
				music(25)
			end
			gamemode=3
		end
		if not dying or dying>0 then
			player:update()
		end
		for e in all(enemies) do
			e:update()
		end
		for b in all(bullets) do
			b:update()
		end
		for s in all(shooters) do
			s:update()
		end
		for f in all(fireballs) do
			f:update()
		end
		for t in all(ftexts) do
			t:update()
		end
		camshake=max(camshake-1,0)
		if dying then
			if dying>0 then
				dying-=1
			end
		else
			wavey-=waveinc
		end
		local cols={10,9,8,11}
		new_particle(flr(rnd(128)),wavey+12+rnd(56),0,-0.75,cols[flr(rnd(4))+1],48,0,true)
	end
	for p in all(particles) do
		p:update()
	end
	wavem=(wavem+0.005)%1
	wavet1=(wavet1+1.241)%32
	wavet2=(wavet2+0.03)%1
	blinktimer=(blinktimer+1)%32
end

function _draw()
	cls()
	if gamemode==0 then
		drawwave(85)
		for p in all(particles) do
			p:draw()
		end
		camera(titlecamx,0)
		local lerpt=blinktimer/32
		for t in all(title) do
			local x,y,s=6+lerp(t.x1,t.x2,lerpt),lerp(t.y1,t.y2,lerpt),lerp(t.s1,t.s2,lerpt)
			circfill(x,y,s,8)
		end
		for t in all(title) do
			local x,y,s=6+lerp(t.x1,t.x2,lerpt),lerp(t.y1,t.y2,lerpt),lerp(t.s1,t.s2,lerpt)
			circfill(x,y,s-1,11)
		end
		for t in all(title) do
			local x,y,s=6+lerp(t.x1,t.x2,lerpt),lerp(t.y1,t.y2,lerpt),lerp(t.s1,t.s2,lerpt)
			circfill(x-1,y-1,s-1,9)
			if t.h then
				local s2=flr(s/2)
				rectfill(x-s2,y-1-s2,x-s2+1,y-s2,10)
				pset(x-s2,y-1-s2,7)
				pset(x-1-s2,y-s2+2,10)
			end
		end
		
		for i=1,16 do
			pal(i-1,dark[i])
		end
		palt(0,false)
		for i=0,3 do
			memcpy(0x1800,0x6200+i*1536,1536)
			sspr(140-titlecamx,96,104,24,140,8+i*24)
		end
		pal()
		for i=1,10 do
			print(scores[i][1],148,4+i*9,7)
			printr(scores[i][2].."FT",204,4+i*9,9)
			printr(scores[i][3],236,4+i*9,12)
		end
		
		camera()
		if btnjmp==4 then
			printc("🅾️ jump ❎ shoot  ",64,121,11)
		else
			printc("🅾️ shoot ❎ jump  ",64,121,11)
		end
		rectfill(25,106,102,118,2)
		rectfill(24,107,103,117,2)
		for k,m in pairs(titlemenu) do
			printc(m.t,m.x,110,k==titlemenui and 1 or 12,k==titlemenui and (blinktimer<16 and 7 or 12) or 1)
		end
	else
		if not dying then
			camyd=mid(-128,player.y-60,128)
		end
		camy=camy+(camyd-camy)*0.2
		if wavey>camy+134 then
			wavey=camy+134
		end
		if camshake>0 then
			local ca=flr(camshake/10)+1
			camera(-ca+flr(rnd(2+ca)),camy-ca+flr(rnd(2+ca)))
		else
			camera(0,camy,0)
		end
		pal(5,14)
		pal(6,4)
		pal(7,11)
		map(16,0,0,-128,16,16)
		map(0,0,0,0,16,32)
		pal()
		pal(14,11)
		pal(15,10)
		pal(4,11)
		map(16,0,0,-128,16,16,128)
		map(0,0,0,0,16,32,128)
		pal()
		for e in all(enemies) do
			pal(11,9)
			pal(3,11)
			e:draw()
		end
		pal()
		player:draw()
		for b in all(bullets) do
			b:draw()
		end
		for f in all(fireballs) do
			f:draw()
		end
		pal(5,15)
		for s in all(shooters) do
			s:draw()
		end
		pal()
		drawwave(wavey)
		for p in all(particles) do
			p:draw()
		end
		for t in all(ftexts) do
			t:draw()
		end
		camera()
		printl(flr(distance).."FT",1,121,9,1)
		printr((flr(distance)+score*10),126,121,12,1)
		if gamemode==3 then
			for i=1,16 do
				pal(i-1,dark[i])
			end
			palt(0,false)
			for i=0,3 do
				memcpy(0x1800,0x6340+i*1664,1664)
				sspr(12,96,104,26,12,13+i*26)
			end
			pal()
			if winindex then
				printc("new high score",64,4,blinktimer<16 and 7 or 10,12)
				rectfill(12,6+winindex*10,115,14+winindex*10,8)
				if cursori then
					rectfill(15+cursori*4,7+winindex*10,19+cursori*4,13+winindex*10,blinktimer<16 and 12 or 11)
					palt(13,true)
					sspr(114,20,4,2,16+cursori*4,4+winindex*10)
					sspr(114,20,4,2,16+cursori*4,15+winindex*10,4,2,false,true)
					palt()
				end
			else
				printc("game over",64,4,10,8)
			end
			for i=1,10 do
				print(scores[i][1],20,8+i*10,7)
				printr(scores[i][2].."FT",76,8+i*10,9)
				printr(scores[i][3],108,8+i*10,12)
			end
		end
	end
	pal(11,137,1)
	pal(3,136,1)
	pal(14,132,1)
	pal(15,134,1)
end

function drawwave(wy)
	for i=0,127 do
		local y=(sin((i+wavet1)/32)+sin((i+wavet2)/64)*1.5)*1.25
		rectfill(i,wy+y,i,wy+127,10)
		rectfill(i,wy+1+y,i,wy+127,9)
		rectfill(i,wy+4+y*0.7,i,wy+127,11)
		rectfill(i,wy+9+y*1.25,i,wy+127,8)
		rectfill(i,wy+14+y*0.5,i,wy+127,3)
	end
end

function invertbuttons()
	btnjmp,btnshoot=btnshoot,btnjmp
	poke(0x5e4a,btnjmp)
	poke(0x5e4b,btnshoot)
end

function printc(str,x,y,c,bgc)
	local strl=(#tostr(str)*4)/2
	if bgc then
		rectfill(x-strl-1,y-2,x+strl+1,y+6,bgc)
		rectfill(x-strl-2,y-1,x+strl+2,y+5,bgc)
	end
	print(str,x-strl+1,y,c)
end

function printl(str,x,y,c,bgc)
	local strl=(#tostr(str)*4)
	if bgc then
		rectfill(x-1,y-2,x+strl+1,y+6,bgc)
		rectfill(x-2,y-1,x+strl+2,y+5,bgc)
	end
	print(str,x+1,y,c)
end

function printr(str,x,y,c,bgc)
	local strl=(#tostr(str)*4)
	if bgc then
		rectfill(x-strl-1,y-2,x+1,y+6,bgc)
		rectfill(x-strl-2,y-1,x+2,y+5,bgc)
	end
	print(str,x-strl+1,y,c)
end

function nametostr()
	name=""
	for i=1,3 do
		name=name..sub(chars,namei[i],namei[i])
	end
	return name
end

function resetscores()
	for i=10,1,-1 do
		add(scores,{"cpu",flr(flr(i*i/5*130)/10)*10,flr(flr(i*i/5*275)/10)*10})
	end
end

function savescores()
	poke(0x5e00,ver)
	for i=1,3 do
		poke(0x5e00+i,namei[i])
	end
	for i=0,9 do
		for n=1,3 do
			poke(0x5e04+i*7+n-1,charindex(sub(scores[i+1][1],n,n)))
		end
		poke2(0x5e04+i*7+3,scores[i+1][2])
		poke2(0x5e04+i*7+5,scores[i+1][3])
	end
	poke(0x5e4a,btnjmp)
	poke(0x5e4b,btnshoot)
end

function charindex(c)
	for i=1,#chars do
		if sub(chars,i,i)==c then
			return i
		end
	end
	return 1
end

------------------------------

function new_game(a,btn)
	memset(0x2000,0,0x1000)
	wavet1,wavet2,wavem,wavey,dying,diff,mapbx,waveinc,distance,score=0,0,0,192,nil,10,0,0.24,0,0
	gen_mapchunk(0,16)
	local psx,psy=gen_mapchunk(0,0)
	gen_mapchunk(16,0)
	bullets,enemies,spawnx,spawnxi,spawntimer,gamemode,particles,ftexts,camshake,shooters,fireballs={},{},{24,120},1,1,1,{},{},0,{},{}
	spawn_player(psx,psy,not btn,btn)
	music(29)
	camyd=mid(0,player.y-60,896)
	camy=camyd
end

function nextmapchunk()
	for y=0,15 do
		for x=0,15 do
			mset(x,y+16,mget(x,y))
			mset(x,y,mget(x+16,y))
			mset(x+16,y,0)
		end
	end
	for e in all(enemies) do
		e.active=true
		e.y+=128
	end
	for b in all(bullets) do
		b.y+=128
	end
	for p in all(particles) do
		p.y+=128
	end
	for f in all(ftexts) do
		f.y+=128
	end
	for s in all(shooters) do
		s.y+=128
	end
	for f in all(fireballs) do
		f.y+=128
	end
	player.y+=128
	player.sy+=128
	camy+=128
	wavey+=128
	if diff>1 then
		waveinc+=0.013
	end
	diff=max(diff-0.5,1)
	gen_mapchunk(16,0)
end

function gen_mapchunk(startx,starty)
	local psx,psy=nil,nil
	for y=starty+15,starty,-1 do
		mset(startx,y,max(59,56+flr(rnd(8))))
		mset(startx+15,y,max(59,56+flr(rnd(8))))
		if y%4==0 then		
			local sx,w=startx+2+mapbx*4,flr(rnd(3))
			for x=sx+1-w,sx+2+w do
				mset(x,y,max(59,56+flr(rnd(8))))
				if not psx then
					psx=x*8
					psy=y*8-8
				end
			end
			if rnd(diff)<2 then
				if startx>15 then
					if mapbx>0 then
						new_shooter(4,y*8-128,1,flr(rnd(diff*8))+4+diff*16,157)
					end
					if mapbx<2 then
						new_shooter(124,y*8-128,-1,flr(rnd(diff*8))+4+diff*16,173)
					end
				end
			end			
			if rnd(diff)<5 then
				if startx>15 and w>0 then
					if diff<2.5 and rnd(3)<2 then
						spawn_enemy((sx-15-w)*8+rnd(8),(y-16)*8-8,etypes[mid(1,#etypes,flr(diff/2+rnd(2)))])
						spawn_enemy((sx-15-w+(1+w*2))*8,(y-16)*8-8,etypes[mid(1,#etypes,flr(diff/2+rnd(2)))])
					else
						spawn_enemy((sx-15-w+flr(rnd(2+w*2)))*8,(y-16)*8-8,etypes[mid(1,#etypes,flr(diff/2+rnd(2)))])
					end
				end
			end
			local mapbxn=(mapbx+flr(rnd(2))+1)%3
			if starty==0 then
				if rnd(4)<1 and mapbx>0 then
					mset(sx-w,y-2,treasure[flr(rnd(#treasure-1))+1])
				end
				if rnd(4)<1 and mapbx<2 then
					mset(sx+3+w,y-2,treasure[flr(rnd(#treasure-1))+1])
				end
				local wx=w==0 and 1 or w
				if rnd(3)<2 and mapbx==0 then
					local tcount=mapbxn==2 and #treasure or #treasure-1
					mset(sx+2-wx,y-4,treasure[flr(rnd(tcount))+1])
				end
				if rnd(3)<2 and mapbx==2 then
					local tcount=mapbxn==0 and #treasure or #treasure-1
					mset(sx+1+wx,y-4,treasure[flr(rnd(tcount))+1])
				end
			end
			mapbx=mapbxn
		end
	end
	return psx,psy
end

function spawn_player(x,y,canjmp,canshoot)
	local onground,flp,frameset,frame,framedelay,nextframedelay,jtm,shoottime,climbing,fflp,anims=false,false,2,1,1,1,0,0,false,false,{{128,129},{144,145,146,147},{131,129,130},{160,161},{133,163,164}}
	player={x=x,y=y,vx=0,vy=0,sy=y,dist=0,
		die=function(p)
			if not dying then
				dying,onground,p.vx,p.vy,camshake=180,false,0,-2,20
				camyd=mid(-128,player.y-60,128)
				music(23)
			end
		end,
		update=function(p)
			if not dying then
				for e in all(enemies) do
					if not (p.x+6<e.x+1 or p.x+1>e.x+6 or p.y+6<e.y+1 or p.y+1>e.y+6) then
						p:die()
					end
				end
			end
			
			if dying then
				p.vy=min(p.vy+0.1,2)
			else			
				if btn(0) then
					p.vx,flp,climbing=max(p.vx-0.25,-1.25),true,false
				elseif btn(1) then
					p.vx,flp,climbing=min(p.vx+0.25,1.25),false,false
				elseif onground then
					p.vx*=0.5
				else
					p.vx*=0.95
				end
				
				local canclimbup,canclimbdown=fget(mget(flr((p.x+4)/8),flr((p.y+7)/8)),1),fget(mget(flr((p.x+4)/8),flr((p.y+8)/8)),1)
				
				if climbing and (not canclimbup or not canclimbdown) then
					climbing=false
				end
				
				if canclimbup and btn(2) then
					p.x,p.vx,p.y,p.vy,climbing=flr(p.x/8+0.5)*8,0,flr(p.y),-1,true
				end
				if canclimbdown and btn(3) then
					p.x,p.vx,p.y,p.vy,climbing=flr(p.x/8+0.5)*8,0,flr(p.y),1,true
				end
				
				if shoottime>0 then
					shoottime-=1
				end
				
				if not climbing then
					if btn(btnshoot) then
						if canshoot and shoottime==0 then
							shoottime,canshoot=10,false
							local vx=flp and -1 or 1
							spawn_bullet(p.x+4+4*vx,p.y+2,vx*2,1)
							sfx(2)
						end
					else
						canshoot=true
					end
					
					if btn(btnjmp) then
						if onground and canjmp then
							sfx(7)
							p.vy-=0.8
							jtm,canjmp=8,false
						elseif jtm>0 then
							p.vy-=0.25
						end
					else
						jtm,canjmp=0,true
					end
					
					if jtm>0 and p.vy>=0 then
						jtm=0
					end
					
					if jtm==0 then
						p.vy+=0.1
					else
						jtm-=1
					end
				end
				
				p.vy=min(p.vy,2)
				
				if climbing then
					--jtm,canjmp=0,true
					--onground=true
					if p.vy>0 and (is_solid(p.x,p.y+p.vy+8) or is_solid(p.x+7,p.y+p.vy+8)) then
						p.y,p.vy=flr((p.y+p.vy)/8)*8,0
					end
				else
					p.x,p.y,p.vx,p.vy,onground=collideworld(p.x,p.y,p.vx,p.vy)
				end			
			end
			
			p.x+=p.vx
			p.y+=p.vy
			
			if p.sy-p.y>distance then
				distance=p.sy-p.y
			end
			
			if not dying then
				local gem=get_gem(p)
				if gem then
					sfx(1)
					score+=gem
					new_ftext(gem*10,p.x+3,p.y-3,gem==10 and 10 or (gem==3 and 9 or 12))
				end
				if p.y>wavey-4 then
					p:die()
					sfx(17)
				end
				if p.y<64 then
					nextmapchunk()
				end
			end
			if climbing then
				frameset=4
				if p.vy~=0 then
					framedelay-=1
					if framedelay<=0 then
						framedelay=8
						fflp=not fflp
					end
				end
				frame=ceil(((framedelay%8)+1)/4)
				p.vy=0
			elseif not onground then
				frameset,frame=dying and 5 or 3,1
				if p.vy>0.25 then
					frame=3
				elseif p.vy>-0.5 then
					frame=2
				end
			else
				if abs(p.vx)>0.01 then
					if frameset~=2 then
						frameset,frame,framedelay,nextframedelay=2,1,6,6
					end
				elseif frameset~=1 then
					frameset,frame,framedelay,nextframedelay=1,1,10,10
				end
				framedelay-=1
				if framedelay==0 then
					framedelay,frame=nextframedelay,frame%#anims[frameset]+1
				end
			end
			
		end,
		draw=function(p)
			local sx,sy,xflp=(anims[frameset][frame]%16)*8,flr(anims[frameset][frame]/16)*8,flp
			if climbing then
				xflp=fflp
			end
			sspr(sx,sy,8,8,p.x,p.y,8,8,xflp)
		end
		}
end

function spawn_enemy(x,y,etype)
	local frame,framedelay,anims,onground,vxdir=1,8,etype.sprs,false,(flr(rnd(2))*2-1)*0.25
	local flp=vxdir<0 and true or false
	add(enemies,{x=x,y=y,vx=0,vy=0,hp=etype.hp,hit=0,active=false,
		update=function(p)
			if not p.active then
				return
			end
			if p.y>wavey then
				del(enemies,p)
				return
			end
			p.vy=min(p.vy+0.1,2)
			if onground then
				p.vx=p.vx+(vxdir-p.vx)*0.1
			end
			local vxprev=p.vx
			p.x,p.y,p.vx,p.vy,onground=collideworld(p.x,p.y,p.vx,p.vy)
			if p.vx~=vxprev or ((p.vx<0 and not is_solid_top(p.x+p.vx,p.y+9)) or (p.vx>0 and not is_solid_top(p.x+7+p.vx,p.y+9))) then
				flp=not flp
				vxdir*=-1
				p.vx*=-1
			end
			if not onground then
				p.vx*=0.9
			end
			p.x+=p.vx
			p.y+=p.vy
		
			framedelay-=1
			if framedelay==0 then
				frame,framedelay=(frame%#anims)+1,8
			end
			
			p.hit=max(p.hit-1,0)
			
			if p.hp==0 then
				del(enemies,p)
				sfx(15)
				score+=5
				camshake=10
				new_ftext(50,p.x+3,p.y-3,8)
				local cols={2,8,9}
				for i=0,8 do
					new_particle(p.x+3,p.y+3,(rnd(2)-1)*0.75,-rnd(2),cols[flr(rnd(3))+1],30+flr(rnd(30)),0.15)
				end
			end
		end,
		draw=function(p)
			pal(14,11)
			if p.hit>0 then
				for i=0,15 do
					pal(i,7)
				end
			end
			local sx,sy,xflp=(anims[frame]%16)*8,flr(anims[frame]/16)*8,flp
			sspr(sx,sy,8,8,p.x,p.y,8,8,xflp)
			pal()
		end
	})
end

function spawn_bullet(x,y,vx,vy)
	add(bullets,{x=x,y=y,vx=vx,vy=vy,t=0,
		update=function(p)
			p.vy+=0.15
			if (p.vx>0 or p.vx<0) and is_solid(p.x+p.vx,p.y) then
				p.vx=-p.vx
			end
			if p.vy>0 and is_solid_top(p.x,p.y+p.vy) then
				p.vy=-p.vy*0.5
			end
			if p.vy<0 and is_solid(p.x,p.y+p.vy) then
				p.vy=-p.vy
			end
			p.x+=p.vx
			p.y+=p.vy
			
			if p.y>wavey then
				del(bullets,p)
				return
			end
			
			for e in all(enemies) do
				if p.x>e.x and p.x<e.x+7 and p.y>e.y and p.y<e.y+7 then
					e.hp-=1
					e.hit=10
					e.vx=p.vx*0.75
					del(bullets,p)
					sfx(2)
					break
				end
			end
			p.t+=1
		end,
		draw=function(p)
			spr(p.t%8<4 and 77 or 78,p.x-3,p.y-3)
		end
	})
end

function new_shooter(x,y,xdir,tmax,sprite)
	add(shooters,{y=y,t=flr(rnd(tmax)),st=0,
		update=function(p)
			p.st=max(0,p.st-1)
			if p.y>camy then
				p.t+=1
				if p.t==tmax-8 then
					p.st=11
					sfx(19)
				end
				if p.t>=tmax then
					new_fireball(x+xdir*4,p.y+3,xdir)
					p.t=0
				end
			end
			if p.y>wavey then
				del(shooters,p)
			end
		end,
		draw=function(p)
			spr(sprite,x-4+xdir,p.y)
			if p.st>0 then
				local sx=((70-flr(p.st/4))%16)*8
				sspr(sx,32,8,8,x+xdir*8-4,p.y-4,8,8,xdir==1)
				sspr(sx,32,8,8,x+xdir*8-4,p.y+4,8,8,xdir==1,true)
			end
		end
		})
end

function new_fireball(x,y,vx)
	add(fireballs,{y=y,t=0,
		update=function(p)
			p.t+=1
			x+=vx
			if x>player.x+1 and x<player.x+6 and p.y>player.y+1 and p.y<player.y+6 then
				player:die()
				del(fireballs,p)
			end
			if x<8 or x>120 or p.y>wavey or is_solid(x,p.y) then
				del(fireballs,p)
				local cols={8,9,10}
				for i=0,8 do
					new_particle(x-vx,p.y+3,(rnd(2)-1),-rnd(2)-0.2,cols[flr(rnd(3))+1],10+flr(rnd(5)),0.15)
				end
			end
		end,
		draw=function(p)
			local s=flr(p.t%8*0.25)
			spr(71+s,x-3,p.y-3)
		end
		})
end

function new_particle(x,y,vx,vy,c,t,g,nonsolid)
	add(particles,{x=x,y=y,vx=vx,vy=vy,c=c or 8,st=t or 60,t=t or 60,g=g or 0.2,nonsolid=nonsolid,
		update=function(p)
			p.vy=min(p.vy+g,7)
			
			if not nonsolid then
				if (p.vx>0 or p.vx<0) and is_solid(p.x+p.vx,p.y) then
					p.vx=-p.vx*0.75
					p.vy*=0.9
				end
				if (p.vy>0 or p.vy<0) and is_solid(p.x,p.y+p.vy) then
					p.vy=-p.vy*0.75
					p.vx*=0.9
				end
			end
			
			p.x+=p.vx
			p.y+=p.vy
			p.t-=1
			if p.t==0 then
				del(particles,p)
			end
		end,
		draw=function(p)
			local x,y,s=p.x,p.y,flr(p.t/p.st+0.5)
			if p.nonsolid then
				x=x+sin(p.t/30)*2
			end
			rectfill(x,y,x+s,y+s,c)
		end
	})
end

function new_ftext(str,x,y,c)
	local t=0
	str="+"..str
	add(ftexts,{y=y,
		update=function(p)
			t+=1
			if t==60 then
				del(ftexts,p)
			end
		end,
		draw=function(p)
			printc(str,x,p.y-t*0.2,c)
		end
	})
		
end

function collideworld(x,y,vx,vy)
	local onground=false
	if vx<0 and (is_solid(x+vx,y) or is_solid(x+vx,y+7)) then
		x,vx=flr((x+vx)/8)*8+8,0
	end
	if vx>0 and (is_solid(x+vx+8,y) or is_solid(x+vx+8,y+7)) then
		x,vx=flr((x+vx)/8)*8,0
	end
	if vy>0 and y<=flr((y+vy)/8)*8 and (is_solid_top(x,y+vy+8) or is_solid_top(x+7,y+vy+8)) then
		y,vy,onground=flr((y+vy)/8)*8,0,true
	end
	if vy<0 and (is_solid(x,y+vy) or is_solid(x+7,y+vy)) then
		y,vy=flr((y+vy)/8)*8+8,0
	end
	return x,y,vx,vy,onground
end

function is_solid(x,y)
	return fget(mget(flr(x/8),flr(y/8)),0)
end

function get_gem(p)
	return is_gem(p.x,p.y) or is_gem(p.x+7,p.y) or is_gem(p.x,p.y+7) or is_gem(p.x+7,p.y+7)
end

function is_gem(x,y)
	x,y=flr(x/8),flr(y/8)
	local result=fget(mget(x,y),7)
	if result then
		if fget(mget(x,y),6) then
			result=10
		elseif fget(mget(x,y),5) then
			result=3
		else
			result=2
		end
		mset(x,y,0)
	end
	return result
end

function is_solid_top(x,y)
	local m=mget(flr(x/8),flr(y/8))
	return fget(m,0) or fget(m,2)
end

function lerp(a,b,t)
	return a+(b-a)*t
end

function smooth_lerp(a,b,t)
	return lerp(a,b,t*t*(3-2*t))
end

etypes={{hp=4,sprs={100,101}},{hp=3,sprs={102,103}},{hp=2,sprs={104,105}},{hp=1,sprs={98,99}}}
dark={1,1,1,2,14,2,5,15,3,8,11,3,13,2,2,5}
treasure={122,122,122,122,122,66,66,75}
chars="abcdefghijklmnopqrstuvwxyz "
namei={1,1,1}
title={
{12,16},{12,20},{12,24},{12,28},{12,32},{12,36},{16,36},{20,36},{23,36},{12,12,h=1},
{42,16},{40,20},{39,24},{38,28},{37,32},{36,36},{46,16},{48,20},{50,24},{51,28},{52,32},{53,36},{42,32},{46,32},{44,12,h=1},
{63,16},{64,20},{65,24},{66,28},{68,32},{70,36},{78,12},{77,16},{76,20},{75,24},{74,28},{72,32},{62,12,h=1},
{93,16},{91,20},{90,24},{89,28},{88,32},{87,36},{97,16},{99,20},{101,24},{102,28},{103,32},{104,36},{93,32},{97,32},{95,12,h=1},
{24,52},{28,52},{32,52},{36,52},{30,56},{30,60},{30,64},{28,67},{26,69},{23,71},{20,71},{20,52,h=1},
{57,52},{51,56},{50,59},{49,63},{50,65},{51,68},{53,71},{57,72},{61,53},{63,56},{64,59},{65,63},{64,65},{63,68},{61,71},{53,53,h=1},
{84,52},{88,52},{92,52},{96,52},{80,55},{80,65},{80,58},{80,68},{80,62},{84,62},{88,62},{80,72},{84,72},{88,72},{92,72},{96,72},{80,52,h=1}
}
