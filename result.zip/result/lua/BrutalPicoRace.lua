-- brutal pico race 1.0.4
-- @yourykiki

local scale,
      rdz--rb length
      =48,64
local frm,endfrm,nb_finish,
      nb_player,nb_ai,
      nb_player_and_ai,
      num_trk,
      spxmax,
      trklen,lastnss,nss,
      racepos,rd_info,
      nb_rb,--rb number
      road
      
-- player infos
local cam,
      ss,sss,--ship,shadow
      zz,zzz,--rot ss,sss
      ship,ctrl,ssp,sssp,rot,
      ird,--pl road indice
      spd,sdx,--,skyx
      height,yoffset,ctr,csy,
      ai_skill
      ={},
       {},{},
       {},{},
       {},{},{},{},{},
       {},
       {},{},
       128,{},{},128,
       0

local ship_info={
{name="aura  ",accel=2},
{name="blitz ",accel=2},
{name="astral",accel=3},
{name="surge ",accel=2},
{name="storm ",accel=3},
{name="titan ",accel=3},
{name="viper ",accel=2},
{name="blaze ",accel=2},
{name="tiger ",accel=1},
{name="raven ",accel=1}
}

function _init()
 cartdata"brutalpicorace"
	menuitem(1,"reset time",
  function()
   for i=0,24 do
    dset(i,21600)
   end
  end)
 scn_intro={
  init=init_intro,
  update=update_intro,
  draw=draw_intro
 }
 scn_game={
  init=init_game,
  update=update_game,
  draw=draw_game
 }
 start_scene(scn_intro)
end
function _update()
 scn.update()
end
function _draw()
 scn.draw()
end
function init_game()
 if nb_player==1 then
  music(10,0,12)
 else
  music"-1"
 end

 sfx"42"
 cls""
 frm,endfrm,nb_finish,racepos=
  0,0,0,{}
 init_all_road(
  parse_trk(num_trk))
 -- half-pipe
 rd_info={}
 for i=0,6 do
  local lof7,at=(24+i)*128,0
  local stp={
   dx=peek(0x2000+lof7),
   dy=peek(0x2001+lof7),
   sx=peek(0x2002+lof7),
   sy=peek(0x2003+lof7),
   fl=peek(0x2004+lof7)
  }
  stp.dst=sqrt(sqrdist(0,0,stp.dx,stp.dy))
  if i>2 then
   stp.dy,stp.sx,stp.fl,at=
    -stp.dy,-stp.sx,-stp.fl,1
  end
  stp.rotz=at+atan2(stp.dx,stp.dy)
  add(rd_info,stp)
 end 

 if nb_player==2 then
  height,nb_rb,cdz,
  rd_grd1,rd_grd2,rd_grd3=
   64,12,48,
   0.55,0.65,0.75
 else
  height,nb_rb,cdz,
  rd_grd1,rd_grd2,rd_grd3=
   128,17,32,
   0.58,0.68,0.75
 end
 csy=height
 --loading
 for p=1,nb_player_and_ai do
  loadship(p,nss[p]-1)
  initshipaccel(ship[p])
  -- human
  if p<=nb_player then
   cam[p],sdx[p],
   yoffset[p],ctr[p]=
    {x=0,y=128,z=0,flw=p},0,
    height*(p-1),
    {x=64,y=height/4}
  end
  --start on segment 1
  add(road[1].pl,p)
 end
end

function initshipaccel(shipp)
 val0,val1,
 shipp.accurv,
 shipp.r_acc,
 absc,coef=
  0,0,{},{},{0,25,50,100},1
 if (ai_skill>1) coef=1-(3-ai_skill)*0.2
  
 for j=1,#absc-1 do
  val1=peek_spr(0x2c+64*(shipp.accel),j*2)
  from,to=absc[j],absc[j+1]
  for i=from,to do
   shipp.accurv[i]=lerp(
    val0,val1,
    (i-from)/(to-from))*coef
   if not shipp.r_acc[
    shipp.accurv[i]\1] then
    shipp.r_acc[
     shipp.accurv[i]\1]=i
   end   
  end
  val0=val1
 end
 shipp.spxmax=9-shipp.accel*1.5
end

-- loading a ship
function loadss(nbss,ss,sss)
 local m,xmin,xmax,zmin,zmax=
  0,8,0,8,0
 for k=7,0,-1 do-- y
  for j=0,7 do-- x
   local shad=false
   for i=2,0,-1 do
    c=sget(8*i+j,k+nbss*8)
    if c~=0 then
     v,shad=
      {x=j-4,y=i-1,z=4-k,
       oz=4-k,c=c,pat=0},
      c~=10
     m+=1
     add(ss,v)
    end
   end
   --half z
   if shad and k%2==0 then
    v={x=j-4,y=0,z=4-k,
     oz=0,c=9,pat=1}
    add(sss,v)
    xmin,xmax,zmin,zmax=
     min(v.x,xmin),max(v.x,xmax),
     min(v.z,zmin),max(v.z,zmax)
   end
  end
 end
 -- /5 because half_width*scale
 local si=ship_info[nbss+1]
 si.mass,si.width,si.height=
  m,(xmax-xmin)/5,(zmax-zmin)/5
end

function update_cntdn(p,ctrlp,spdp,sspp)
 if frm>150 then
  if p<=nb_player then
   sspp.update=update_player
  else
   sspp.update=update_ai
  end
 end
end

function update_end(p,ctrlp,spd,ssp)
 ctrlp.left,ctrlp.right,ctrlp.boost,
  ctrlp.accel,ctrlp.brake,pbtn=
 false,false,false,false,false,p-1
 if p<=nb_player then
  if frm>endfrm+45 then
   local flw=cam[p].flw
   if (btnp(2,pbtn)) flw+=1
   if (btnp(3,pbtn)) flw-=1
   cam[p].flw=mid(1,flw,nb_player_and_ai)
  end
  snd_engine(pbtn,spd)
 end
 if ssp.hp<=0 then
   create_pspark(ssp,spd.z,0,0)
 end
end

function update_game()
 frm+=1
 for p=1,nb_player_and_ai do
  -- where is the spaceship ?
  local sspp,backcam,spdp
   =ssp[p],false,spd[p]
  if (sspp.z-4)>=trklen then
   sspp.z-=trklen
   backcam=true
   sspp.rlap+=1
  end
  --old ship location on road
  -- +1 for array access
  local oird=ird[p]+1
  local oldpl=road[oird].pl
  --new ship location
  ird[p]=get_ird(sspp)
  local irdp=ird[p]+1
  v=road[irdp]
  vn=road[irdp%#road+1]
  -- update road link
  if oird~=irdp then
   del(oldpl,p)
   add(v.pl,p)
  end
  -- update a player/ai
  spxmax=ship[p].spxmax
  --handle control
  sspp.update(p,ctrl[p],spdp,sspp)
  updateship(p,v,vn,sspp,rot[p],spdp,ctrl[p],ship[p])
  -- camera tracking
  for i=1,nb_player do
   local camp=cam[i]
   if camp and camp.flw==p then
    if (backcam) camp.z-=trklen
    --sky
    sdx[i]-=spdp.z*v.fx/32
    --set with 30fps 10/30
    camp.x,camp.y,camp.z=
     lerp(camp.x,ssp[p].x,0.3333333),
     14+lerp(camp.y,ssp[p].y,0.3333333),
     lerp(camp.z,ssp[p].z-cdz,0.5)
   end
  end
 end
 --if (frm%15==0)
  calcrank()
 update_particles(p_spark)
 update_particles(p_boost)
 update_particles(p_trail)
 race_end()
end

function calcrank()
 local ranks={}
 for p=1,nb_player_and_ai do
  ranks[p]={
   key=ssp[p].z+ssp[p].rlap*trklen,
   p=p
  }
 end
 shellsort(ranks)
 for p=1,nb_player_and_ai do
  ssp[ranks[p].p].rank=
   nb_player_and_ai-p+1
 end
end

function race_end()
 if nb_finish>=nb_player then
  if endfrm==0 then
   endfrm=frm
  elseif frm>endfrm+150 
   and btnp(4) then
    start_scene(scn_intro)
  end
 end
end

-- road index
function get_ird(pos)
 -- 4 offset for shadow
 return ((pos.z-4)\rdz)%#road
end

function update_ai(p,ctrlp,spd,sspp)
 -- +skill=+decision
 if rnd"10">6-ai_skill then
  -- where to go ?
  local xmin,xmax=
   sspp.xmin,sspp.xmax
  local v=road[ird[p]+1]
  if v.t&2==2 
   and v.fx<-2 then
   xmin,xmax=58,70
  elseif v.t&8==8
   and v.fx>2 then
   xmin,xmax=-70,-58
  end
  -- avoid other ships
  for pn=1,nb_player_and_ai do
   local irdist=ird[pn]-ird[p]
   if p~=pn and irdist>=0
     and irdist<=2
     and ssp[pn].z>sspp.z
     and is_collide(sspp,ssp[pn],
      ship[p],ship[pn],0) then
    local dx=sgn(sspp.xflat
     -ssp[pn].xflat)*10
    xmin,xmax=xmin+dx,xmax+dx
    sspp.xmin,sspp.xmax=xmin,xmax
   end
  end
  -- correcting position
  if sspp.xflat<xmin then
   ctrlp.right,ctrlp.left=
    true,false 
  elseif sspp.xflat>xmax then
   ctrlp.right,ctrlp.left=
    false,true
  else
   ctrlp.right,ctrlp.left=
    false,false
  end
  --adaptive boost among 1st player
  if rnd"32">30-ai_skill+ssp[1].rank
    and abs(v.fx)<8 then
   if ctrlp.cdn_bst==10 then
    ctrlp.boost=false
   elseif ctrlp.can_bst then
    ctrlp.boost=true
   end
  end
 end
 -- accel,decel
 if spd.prc<=55+ai_skill*10 then
  ctrlp.accel=true
 else
  ctrlp.accel=rnd"10">5-ai_skill
 end
 
 -- race finished
 if is_race_ended(sspp) then
  sspp.update=update_end
  if (sspp.hp>0) add(racepos,p)
 end
 sspp.frm+=1
end


function update_player(p,ctrlp,spd,ssp)
 -- left / right
 local pbtn=p-1
 ctrlp.left,ctrlp.right,ctrlp.boost,
 ctrlp.accel,ctrlp.brake=
  btn(0,pbtn),btn(1,pbtn),
  btn(2,pbtn) and ctrlp.can_bst,
  btn(4,pbtn),btn(5,pbtn)
 -- sfx
 if ctrlp.cdn_bst>0 then
  sfx(46,pbtn*2,mid(0,ctrlp.cdn_bst,9)*2,2)
 else
  snd_engine(pbtn,spd)
 end
 ssp.frm+=1
 
 -- race finished
 if is_race_ended(ssp) then
  ssp.update=update_end
  nb_finish+=1
  if ssp.hp>0 then
   add(racepos,p)
   -- update time
   local iscr=num_trk*4+ai_skill-1
   if ssp.frm<dget(iscr) 
    or dget(iscr)==0 then
    dset(iscr,ssp.frm)
   end
  else
   sfx"63"
  end
 end
end

function is_race_ended(sspp)
 return sspp.rlap>2 
    and sspp.z>256
     or sspp.hp<=0
end

function updateship(p,v,vn,sspp,
  rot,spdp,ctrlp,shipp)
 if ctrlp.left then
  spdp.x=lerp(spdp.x,-spxmax,0.2)
 end
 if ctrlp.right then
  spdp.x=lerp(spdp.x,spxmax,0.2)
 end
 if not ctrlp.left and
    not ctrlp.right then
  spdp.x=lerp(spdp.x,0,0.2) 
 end
 if ctrlp.boost then
  -- charging
  ctrlp.cdn_bst=min(10,
    ctrlp.cdn_bst+recover_cdn(sspp))
 elseif not ctrlp.boost
  and ctrlp.cdn_bst>0 then
  -- applying
  playersfx(p,45)
  spdp.bz+=ctrlp.cdn_bst*0.5
  ctrlp.cdn_bst,ctrlp.can_bst=
   -ctrlp.cdn_bst*2,false
 else 
  local bef=ctrlp.can_bst
  ctrlp.cdn_bst=min(0,
   ctrlp.cdn_bst+recover_cdn(sspp))
  ctrlp.can_bst=not btn(2,p-1) and ctrlp.cdn_bst>=0
  if not bef and ctrlp.can_bst then
   playersfx(p,49)
  end
 end
 -- 1 secs for locking drafting
 if ctrlp.drft==30 then
  playersfx(p,62)
 end
 if ctrlp.drft>=45 then
  spdp.bz,ctrlp.drft=
   min(spdp.bz+3,6),0
 end
 spdp.bz=max(0,spdp.bz-0.025)
 local dy=(v.y-vn.y)/8
 if ctrlp.accel then
  spdp.prc,spdp.gz=
   min(spdp.prc+0.25,100),
   lerp(spdp.gz,dy,0.1)
 end
 if ctrlp.brake then
  spdp.prc,spdp.gz=
   max(spdp.prc-1,0),
   lerp(spdp.gz,0,0.1)
 end
 if not ctrlp.accel and
    not ctrlp.brake then
  spdp.z=sgn(spdp.z)
   *max(0,abs(spdp.z)-0.05)
  spdp.prc=get_r_accel(
   shipp.r_acc,spdp.z)
  spdp.gz=lerp(spdp.gz,dy,0.05)
 else
  spdp.z=getaccel(shipp.accurv,spdp.prc)
 end

 -- epsilon
 if (abs(spdp.gz)<0.1) spdp.gz=0
 -- new pos,spd gz and boost z
 local spdpz=spdp.z+spdp.gz+spdp.bz
 sspp.z=sspp.z
  +sin(atan2(spdp.x,spdpz))
   *spdpz*sgn(spdpz)
 sssp[p].z=sspp.z
 -- speed/boost/draft fx
 if spdpz>12 and frm%10==0 
  or ctrlp.drft>0 then
  p_boost.nb=ctrlp.drft>0
   and 4 or flr(spdpz-11)*1.5
  create_particles(p_boost,
   sspp,spdp,p)
 end

 -- move ship left/right
 -- phx pseudo phy
 local phx=
  -(1*spdpz/getaccel(shipp.accurv,100)
     *v.fx*0.78)
 sspp.xflat+=spdp.x+phx+spdp.gx
 -- ship col
 for pn=1,nb_player_and_ai do
  if p~=pn and
    abs(ird[p]-ird[pn])<=1 then
   --close enough for testing
   local shippn,ssppn,spdpn=
    ship[pn],ssp[pn],spd[pn]
   -- drafting
   if ctrlp.drft>=30 or
     is_collide(sspp,ssppn,
     shipp,shippn,0.15)
     and sspp.z<ssppn.z
     and spdp.z>6 then
    ctrlp.drft+=1
    else
    ctrlp.drft=0
   end
   -- collision ?
   if is_collide(sspp,ssppn,
     shipp,shippn,2) then
    -- response
    local resx,resz,sgnx,mn_m=
     spdp.x+phx/2,
     (spdp.z+spdpn.z)/2*0.95,
     sgn(sspp.xflat-ssppn.xflat),
     shippn.mass/shipp.mass
    -- ship mass
    sspp.xflat-=resx
    sspp.z-=resz
    spdp.x+=abs(spxmax)*sgnx*mn_m
    spdp.z=resz*mn_m
    spdp.prc=get_r_accel(
     shipp.r_acc,spdp.z)
    --ship pn
    ssppn.xflat+=resx
    ssppn.z+=resz
    spdpn.x-=abs(shippn.spxmax)*sgnx/mn_m
    spdpn.z=resz/mn_m
    spdpn.prc=get_r_accel(
     shippn.r_acc,spdpn.z)
    -- fx with cooldown
    if frm-spdp.cdn>10 then 
     sspp.hp-=getdamage()
     ssppn.hp-=getdamage()
    end
    -- fx
    if not isnotvisible(sspp,cam[1],0) then
     sfx"43"
    end
    create_pspark(
     {x=(sspp.x+ssppn.x)/2,
      y=(sspp.y+ssppn.y)/2,
      z=(sspp.z+ssppn.z)/2},
     (spdp.z+spdpn.z)/2,
     0,0
    )
   end
  end
 end
 --progress on rb
 local prc=(sspp.z-v.z)/rdz
 local xtmp,ytmp=
  lerp(v.x,vn.x,prc),
  lerp(v.y,vn.y,prc)
 handle_road_collision(sspp,v,vn,xtmp,spdp,shipp,prc)
 --prepare for rendering
 sssp[p].y=ytmp
 -- convert flat to "real" x,y
 convert_xflat_to_x(sspp,xtmp,ytmp,rot,spdp,shipp)
 rot.y=spdp.x/64
 
 local mat=calcrotmat(rot)
 zz[p],zzz[p]=
  applyrot(ss[p],mat,p<=nb_player),
  applyrot(sss[p],mat,false)
 -- shadow
 -- token sssp[p] ==> ssspp en param
 sssp[p].xflat=sspp.xflat
 convert_xflat_to_x(sssp[p],xtmp,ytmp,rot)
 sssp[p].y+=ytmp
end

function handle_road_collision(
  sspp,v,vn,xtmp,spdp,shipp,prc)

 local xl,xr=v.x-56,v.x+56
 local l1,l2,l3,r1,r2,r3=
  xl-35.7,xl-80.9,xl-162.4,
  xr+35.7,xr+80.9,xr+162.4

 local lborx,rborx=l1,r1
 
 if v.t&4==4 then
  if vn.t&8==8 
   and v.t&8==0 then
   lborx=lerp(l1,l2,prc)
  end
  if vn.t&2==2 
   and v.t&2==0 then
   rborx=lerp(r1,r2,prc)
  end
 end
 
 lborx=road_part_collision(
  l1,l2,l3,prc,8,16,lborx)
 rborx=road_part_collision(
  r1,r2,r3,prc,2,1,rborx)
 lborx=road_part2_collision(
  l2,l3,prc,16,lborx)
 rborx=road_part2_collision(
  r2,r3,prc,1,rborx)

 lborx+=shipp.width*8
 rborx-=shipp.width*8
 
 --handle collision
 sspp.xflat=mid(lborx,sspp.xflat,rborx)
 local coll=0
 if sspp.xflat==lborx then
  spdp.x=abs(spdp.x)/2
  coll=-1
 end
 if sspp.xflat==rborx then
  spdp.x=-abs(spdp.x)/2
  coll=1
 end
 -- collision common
 if coll~=0 then
  if frm-spdp.cdn>10 then 
   spdp.z*=0.85
   sspp.hp-=getdamage()
   spdp.prc,spdp.cdn,
   sspp.xmin,sspp.xmax=
    get_r_accel(
     shipp.r_acc,spdp.z),
    frm,-5,5
   if not isnotvisible(sspp,cam[1],0) then
    sfx"44"
   end
  end
  -- fx
  create_pspark(sspp,spdp.z,
   rot.z,coll)
 end
end

function create_pspark(sspp,
  spdpz,rz,coll)
 create_particles(p_spark,
  {x=sspp.x+coll*cos(rz)*8,
   y=sspp.y+sin(rz)*8,
   z=sspp.z},{z=spdpz*0.8})
end

function applyrot(ss,m,sort)
 -- faster 0.02cpu but +30 tokens
 local xx,xy,xz,
       yx,yy,yz,
       zx,zy,zz,rr
          =m.xx,m.xy,m.xz,
           m.yx,m.yy,m.yz,
           m.zx,m.zy,m.zz,
           {}

 for v in all(ss) do
   local r={}
   r.x,r.y,r.z,
   r.c,r.pat=
    xx*v.x+xy*v.y+xz*v.z,
    yx*v.x+yy*v.y+yz*v.z,
    zx*v.x+zy*v.y+zz*v.z,
    v.c,v.pat
   r.key=r.z
   add(rr,r)
 end
 -- z sort
 if (sort) shellsort(rr)
 return rr
end

function init_all_road(trk)
 local i,h=0,0
 trklen,road=0,{}
 for t in all(trk) do
  local len,hgt,hln,
    alp,last_h=
   t.len or 16,
   t.hgt or 0,
   t.hln or 1,
   0,h
  for j=1,len do
   v={x=0,y=0,z=i*rdz,
    fx=t.curv,c=13,t=4,
    pl={},parts={}}
   --curvy road
   local fx=v.fx
   if i==4 then
    v.t=0x0104 --start+flat
   elseif fx>4 then
    v.t=0x001c --border left
   elseif fx<-4 then
    v.t=0x0007 --border right
   elseif fx>2 then
    v.t=0x000c --li'l border left
   elseif fx<-2 then
    v.t=0x0006 --li'l border right
   end 
   -- force road type
   if (t.frc) v.t=t.frc
   -- height
   if hgt~=0 then
    alp+=1
    h=last_h+(1-sin(-alp/(len*hln)-0.25))*hgt
   end
   v.y=h
   -- colors
   if i%2==0 then 
    v.c=5
   end
   add(road,v)
   trklen+=rdz
   i+=1
  end
 end
end

function draw_game()
 for p=1,nb_player do
  -- clip/camera
  local h=height*(p-1)
  clip(0,h+(p-1),128,height)
  camera(0,-h)
  -- sky
  local flw=cam[p].flw
  local sdy=(ctr[p].y+ssp[flw].y/16)\1
  rectfill(0,0,128,sdy-1,skyc1)
  rectfill(0,sdy,128,sdy,skyc2)
  rectfill(0,sdy+1,128,sdy+1,skyc3)
  rectfill(0,sdy+2,128,128,skyc4)
  local b=true
  for i=0,128,32 do
   b=not b
  	spr(ofsky,(sdx[p]+i)%160-32,sdy-16,4,2,b)
  end
  -- draw game
  cx,cy=ctr[p].x,ctr[p].y
  drawroad(cam[p],ird[flw],flw)
  -- speed
  local spz,sspp=
   spd[flw].z+spd[flw].gz+spd[flw].bz,
   ssp[p]
  -- hud
  drawbar(7,spz,12,9)
  drawbar(5,ctrl[flw].cdn_bst,12,
   ctrl[flw].can_bst and 11 or 8)
  drawbar(3,ssp[flw].hp,100,8)
  rectfill(95,0,123,18,1)
  print("lap "..
    min(sspp.rlap+1,3)
   .."/3",96,1,7)
  print("pos "..sspp.rank.."/"
   ..nb_player_and_ai,96,7)
  print(formattime(sspp.frm),96,13)
  rectfill(4,12,4,height-4,6)
  for i=1,nb_player_and_ai do
   local h=lerp(height-4,12,
    ssp[i].z/trklen) 
   rectfill(4,h,7,h,i==flw and 7 or 6)
  end
  if endfrm>0 then
   spr_grd(racepos[1]==p 
     and 195 or 227,
    48,24,32,15,0x1b0,offset)
  end
 end
 --restore
 clip()
 camera(0,0)
 -- countdown
 if frm<150 then
  local start=107+frm\30
  offset+=1
  spr_grd(start,60,32,8,15,0x1b0,offset)
  print("press ⬆️ to charge boost",
   16,height-6,5)
 end
 -- endrace
 if endfrm>0 then
  offset+=1
  local w,h=66,#racepos*6+2
  local by=(124-h)/2
  rectfill(31,by,31+w,by+h,1)
  rect(31,by,31+w,by+h,0)
  for i=1,#racepos do
   print(i..
    " "..ship[racepos[i]].name..
    " "..formattime(
      ssp[racepos[i]].frm),
    33,(i-1)*6+by+2,7)
  end
 end
 if nb_player==1 then
  palt(0, false)
  rectfill(48,16,79,16,6)
  for i=0,3 do
   pal(peek_spr(0x02b0,i),
    ((ssp[1].z/32-i)\1)%4==0
     and 10 or 0)
  end
  spr(7,48,0,4,2)
  local hps=3-(ssp[1].hp\25)
  if hps>0 then
   hps=min(hps,4)
   spr(161+2*hps,56,0,2,2)
  end
  palt()
  pal()
 end
 -- debug
-- print(stat(1),0,0,6)
-- print("cpu="..stat(1))
--  .." fps="..stat(7)
--  .." ram="..stat(0)
--  ,0,height-5,1)
end

function drawroad(cam,ird,p)
 -- calculating road
 local r,rn,cfx,v,vn,vz=
  nil,nil--render info
 -- first partial offset
 local irdn=ird+1
 local irdlast=ird+nb_rb-1
 cfx=-(ssp[p].z-road[irdn%#road+1].z)
  /rdz*road[ird+1].fx

 -- all other
 for i=irdn,irdlast do
  cfx+=road[i%#road+1].fx
 end

 -- ready to draw road
 for i=irdlast,ird-1,-1 do
  v,vn=road[i%#road+1],
   road[(i+1)%#road+1]
  vz,xl,xr,iy,ylgt=
   v.z+(i\#road)*trklen,
   v.x-56,v.x+56,v.y,
   lerp(v.y,vn.y,0.5)
  -- clip
  dz=max(vz-cam.z,7)

  prc=(cam.z+7-vz)/rdz
  if dz==7 then
   --interpolation
   xl=lerp(xl,vn.x-56,prc)
   xr=lerp(xr,vn.x+56,prc)
   iy=lerp(v.y,vn.y,prc)
  end
  -- current part
  fct,cfx=scale/dz,cfx-v.fx

  r={
   x1=proj_fct_x(xl-cam.x,cfx),
   x2=proj_fct_x(xr-cam.x,cfx),
   y=proj_fct_y(iy-cam.y),

   xl1=proj_fct_x(xl-32-cam.x,cfx),
   xr1=proj_fct_x(xr+32-cam.x,cfx),
   y2=proj_fct_y(iy+16-cam.y),
   xl2=proj_fct_x(xl-64-cam.x,cfx),
   xr2=proj_fct_x(xr+64-cam.x,cfx),
   xl3=proj_fct_x(xl-80-cam.x,cfx),
   xr3=proj_fct_x(xr+80-cam.x,cfx),
   y3=proj_fct_y(iy+48-cam.y),
   y4=proj_fct_y(iy+128-cam.y),
  }
  -- drawing road
  if rn then 
   --color fade (-2 for lights)
   local tx,even,odd,flp=
    (i-ird)/(nb_rb-2),
    v.c,vn.c,nil
   
   if tx>=rd_grd3 then
--    even,odd=1,1
      flp=0b1111111111111111.1
--      even,odd=0,0
   elseif tx>=rd_grd2 then
--    flp=0xa5a5
      flp=0b1010010110100101.1
   elseif tx>=rd_grd1 then
--    flp=0xa0a0
      flp=0b1010000010100000.1
   end
   -- colors are the same
   if tx>=rd_grd1 
     and tx<rd_grd3 
     and v.c~=5 then
    even,odd=odd,even
   end

   if v.t&256==256 then
    drawstartlane(r,rn,cfx,
     odd,flp,cam,vz)
   end
   -- other ? (if possible)
   local lborx,lbory,
    rborx,rbory,lcol=
    xl-32,ylgt+16,xr+32,ylgt+16,
    peek_spr(0x0170,irdlast-i-1)
   if v.t&4==4 then
    --main road
    pfill(r.x1,r.y, r.x2,r.y, rn.x2,rn.y, rn.x1,rn.y, even,flp)
    -- tokens left1=right1
    -- but see perfs
    -- left 1
    pfill(r.xl1,r.y2, rn.xl1,rn.y2, rn.x1,rn.y, r.x1,r.y, even,flp)
    if vn.t&8==8 
     and v.t&8==0
     then --left1 to left2
     pfill(r.xl1,r.y2,rn.xl2,rn.y3,rn.xl1,rn.y2,nil,nil,even,flp)
     lborx,lbory=xl-48,ylgt+32
    end
    -- right 1
    pfill(r.xr1,r.y2,rn.xr1,rn.y2,rn.x2,rn.y,r.x2,r.y,even,flp)
    if vn.t&2==2 
     and v.t&2==0
     then --right1 to right2
     pfill(r.xr1,r.y2,rn.xr2,rn.y3,rn.xr1,rn.y2,nil,nil,even,flp)
     rborx,rbory=xr+48,ylgt+32
    end
   end
   if v.t&8==8 then
  	 -- left 2
   	lborx,lbory=xl-64,ylgt+48
    if vn.t&8==8
  	  or v.t&16==16 then
   	 pfill(rn.xl2,rn.y3,rn.xl1,rn.y2,r.xl1,r.y2,r.xl2,r.y3,even,flp)
    else
     --left2 to left1
     lborx,lbory=xl-48,ylgt+32
     pfill(r.xl2,r.y3,rn.xl1,rn.y2,r.xl1,r.y2,nil,nil,even,flp)
    end
    if vn.t&16==16
     and v.t&16==0 then
     --left2 to left3
     pfill(r.xl2,r.y3,rn.xl3,rn.y4,rn.xl2,rn.y3,nil,nil,even,flp)
     lborx,lbory=xl-72,ylgt+88
    end
   end
   if v.t&2==2 then
    -- right 2
   	rborx,rbory=xr+64,ylgt+48
    if vn.t&2==2
     or v.t&1==1
     then
     pfill(rn.xr2,rn.y3,rn.xr1,rn.y2,r.xr1,r.y2,r.xr2,r.y3,even,flp)
    else
     rborx,rbory=xr+48,ylgt+32
     pfill(r.xr2,r.y3,rn.xr1,rn.y2,r.xr1,r.y2,nil,nil,even,flp)
    end
    if vn.t&1==1
     and v.t&1==0 then
     --right2 to right3
     pfill(r.xr2,r.y3,rn.xr3,rn.y4,rn.xr2,rn.y3,nil,nil,even,flp)
     rborx,rbory=xr+72,ylgt+88
    end
   end
   if v.t&16==16 then
   	--left 3
    if vn.t&16==16 then
     lborx,lbory=xl-80,ylgt+128
     pfill(rn.xl3,rn.y4,rn.xl2,rn.y3,r.xl2,r.y3,r.xl3,r.y4,even,flp)
    else
     --left 3 to left 2
     lborx,lbory=xl-72,ylgt+88
     pfill(r.xl3,r.y4,rn.xl2,rn.y3,r.xl2,r.y3,nil,nil,even,flp)
    end
   end
   if v.t&1==1 then
    --right 3
    if vn.t&1==1 then
     rborx,rbory=xr+80,ylgt+128
     pfill(rn.xr3,rn.y4,rn.xr2,rn.y3,r.xr2,r.y3,r.xr3,r.y4,even,flp)
   	else 
     rborx,rbory=xr+72,ylgt+88
     pfill(r.xr3,r.y4,rn.xr2,rn.y3,r.xr2,r.y3,nil,nil,even,flp)
   	end
   end
  	-- lights
   lz=vz-cam.z+rdz/2
   if lz>7 then   	
    local mfct=scale/lz
    local lsize=max(0.8,mfct*4)
    circfill(cx+mfct*(lborx-cam.x)+cfx+v.fx/2,
     cy-mfct*(lbory-cam.y),lsize,lcol)
    circfill(cx+mfct*(rborx-cam.x)+cfx+v.fx/2,
     cy-mfct*(rbory-cam.y),lsize,lcol)
   end
  end
  -- players,ai ships
  -- ntrk=>lapsloop
  local pl,pcfx,ntrk,pls=
   v.pl,0,(i\#road)*trklen,{}
  -- sort on z
  if #pl>1 then
   for inp=1,#pl do
    add(pls,
     {np=pl[inp],key=ssp[pl[inp]].z})
   end
   shellsort(pls)
   for inp=1,#pls do
    pl[inp]=pls[#pls-inp+1].np
   end
  end
  for inp=1,#pl do
   np=pl[inp]
   pcfx=(ssp[np].z-vz)/rdz*v.fx+cfx
   local shake=spd[np].z+spd[np].gz+spd[np].bz>=14
   if shake then
    ox,oy=cam.x,cam.y
    cam.x+=rnd"2"-1
    cam.y+=rnd"2"-1
   end
   -- shadow
   drawvoxel(zzz[np],sssp[np],cam,pcfx,ntrk)
   -- spaceship
   drawvoxel(zz[np],ssp[np],cam,pcfx,ntrk,spd[np],ctrl[np])
   if shake then
    cam.x,cam.y=ox,oy
   end
  end
  --particles
  for inp=1,#v.parts do
   part=v.parts[inp]
   pcfx=(part.z-vz)/rdz*v.fx+cfx
   part.draw(part,cam,pcfx,ntrk,p)
  end
  rn=r
 end
end

function drawstartlane(r,rn,cfx,col,flp,cam,vz)
 pfill(rn.xl3,rn.y4,rn.xl1,rn.y2,r.xl1,r.y2,r.xl3,r.y4,col)
 pfill(rn.xr3,rn.y4,rn.xr1,rn.y2,r.xr1,r.y2,r.xr3,r.y4,col)
 --laser
 if cam.z+7<vz then
  local lsrc=frm%2==0 and 12 or 7
  lsrc=frm<150 and 9 or lsrc
  lsrc=frm<120 and 8 or lsrc
  local mfct=scale/(vz-cam.z+rdz/2)
 	local stxl1,stxr1,sty=
 	 cx+mfct*(xl-48-cam.x)+cfx,
 	 cx+mfct*(xr+48-cam.x)+cfx,
   cy-mfct*(iy+53-cam.y)
  drawthunder(stxl1,sty,stxr1,sty,mfct,lsrc)
 	stxl1,stxr1,sty=
 	 cx+mfct*(xl-64-cam.x)+cfx,
 	 cx+mfct*(xr+64-cam.x)+cfx,
   cy-mfct*(iy+90-cam.y)
  drawthunder(stxl1,sty,stxr1,sty,mfct,lsrc)
 end
end

function drawthunder(x1,y1,x2,y2,zfct,col)
 x,y=x1,y1
 local zrnd=max(0.1,zfct*8) 
 for i=1,4 do
  xn,yn=x1+(x2-x1)/5*i+rnd(zrnd),
   y1+(y2-y1)/5*i+rnd(zrnd)-zrnd/2
  line(x,y,xn,yn,col)
  x,y=xn,yn 
 end
 line(xn,yn,x2,y2)
end

function isnotvisible(pos,cam,ntrk)
 return pos.z+ntrk<cam.z+7 or
  pos.z+ntrk>cam.z+10*rdz
end

function brilar()
 return max((rnd"8")\1-6,0)
end

function drawvoxel(zz,ssp,cam,
 cfx,ntrk,spd,ctrl)
 if isnotvisible(ssp,cam,ntrk) then
  return
 end
 local brighter,larger=
  brilar(),brilar()

 local pre,spcx,spcy,ofsx,ofsy=
  init_draw_voxel(ssp,cam,ntrk,cfx)

 -- draw reverse
 for i=#zz,1,-1 do
  r=zz[i]
  fct=scale/(r.z+pre)--flatten
  vfct=2.5*fct--zoom model
  if r.c==10 or r.c==9 and r.pat==1 then
   x,y=
    ofsx+fct*spcx+vfct*(r.x+0.5),
    ofsy-fct*spcy-vfct*(r.y-0.5)
   if r.c==10 then
    --engine
    if spd then
     col=(spd.prc*0.03)\1+brighter
     if ctrl.cdn_bst>0 then col+=5
     elseif spd.bz>0 then col+=1
     end
     larger=spd.prc<50 and 0 or larger
     -- trail
     if (larger~=0 and ctrl.accel)
       or ctrl.cdn_bst<-6 then
      create_particles(
       p_trail,ssp,spd,r)
     end
    else
     col,larger=5,0
    end
    drawengine(x,y,vfct,larger,col)
   else
    --shadow
    circfill(x,y,vfct,0x50)
   end
  else
   x,y=
    ofsx+fct*spcx+vfct*r.x,
    ofsy-fct*spcy-vfct*r.y
   rectfill(x,y,x+vfct-1,y+vfct-1,r.c)
  end
 end
end

function drawengine(x,y,vfct,
 larger,col)
 local col1,col2=
  peek_spr(0x0070,col),
  peek_spr(0x00b0,col)
 circfill(x,y,vfct,col1)
 circfill(x,y,vfct-.5,col2)
 if larger~=0 then
  fillp(0b1010010110100101.1)
  circfill(x,y,vfct-.5+larger*1.5,col1)
  fillp()
 elseif vfct>1 then
  circ(x,y,vfct,6)
 end
end

function convert_xflat_to_x(pos,decx,ytmp,rot,spdp,shipp)
 
 local xflat,cumx,cumy,newz=
  pos.xflat-decx,0,0,1
 pos.x,pos.y=pos.xflat,0 

 for stp in all(rd_info) do
  if xflat > stp.fl then
   -- startx,y
   stx,sty=stp.sx,stp.sy
   cumx,cumy=stx+stp.dx,sty+stp.dy
   pos.x=decx+lerp(stx,cumx,(xflat-stp.fl)/stp.dst)
   pos.y=lerp(sty,cumy,(xflat-stp.fl)/stp.dst)
   newz=stp.rotz
   break
  end
 end
 if rot then
  rot.z=lerp(rot.z,newz,0.25)
  newz=rot.z
 end
 if pos.yflat then
  pos.x=pos.x
   +sin(1-newz)*pos.yflat
  pos.y=ytmp+pos.y
   +cos(newz)*pos.yflat
 end
 if spdp then 
  local gx=sin(newz)
  -- meme sens, speed bonus
  -- sens oppose, speed malus
  if spdp.x*gx<0 then
   spdp.gz=min(spdp.gz+abs(gx)/2,
                4-shipp.accel)
  elseif spdp.x*gx>0 then
   spdp.gz=max(spdp.gz-abs(gx)/2,
               -4+shipp.accel)
  end
  spdp.x-=gx
 end
end

-- intro
local nb_ship,nb_choice
local intro_mnu={
 {name="player   ",values={1,2},maxval=2},
 {name="ai skill ",values={"no","easy","normal","hard"},maxval=4,val=3},
 {name="track    ",maxval=6},
 {name="ship 1   ",maxval=#ship_info},
 {name="ship 2   ",maxval=#ship_info}
}
function init_intro()
 nb_choice,nb_player,track_id,
  cam_int,cy,rot_intro,offset,
  lastnss,nss=
  1,1,1,
  {x=0,y=72,z=40},
  32,{x=0,y=0,z=0},0,
  {},{}
 music"0"
end

function update_intro()
 --handle controls
 if btnp"2" then
  nb_choice=max(1,nb_choice-1)
  sfx"40"
 elseif btnp"3" then
  nb_choice=min(#intro_mnu,nb_choice+1)
  sfx"40"
 end
 local mnuitem=intro_mnu[nb_choice]
 if (mnuitem.val==nil) mnuitem.val=1
 --
 if btnp"0" then
  mnuitem.val=max(1,mnuitem.val-1)
  sfx"40"
 elseif btnp"1" then
  mnuitem.val=min(mnuitem.maxval,mnuitem.val+1)
  sfx"40"
 end
 local ship2=intro_mnu[5]
 if btnp(0,1) then
  ship2.val=max(1,ship2.val-1)
  sfx"40"
 elseif btnp(1,1) then
  ship2.val=min(ship2.maxval,ship2.val+1)
  sfx"40"
 end
 -- start game
 if offset>0 and btnp"4" then
  sfx"41"
  nb_ai,ai_skill,num_trk=
   0,intro_mnu[2].val,
   intro_mnu[3].val-1
  if ai_skill>1 then
   nb_ai=4-nb_player
   nss[4]=3
   nss[3]=2
   if (nb_player<2) nss[2]=10
  end
  nb_player_and_ai=nb_player+nb_ai
  offset,ofsky,skyadr=
   0,3+32*(num_trk%2),
   0x0230+64*(num_trk%2)
  skyc1,skyc2,skyc3,skyc4=
   peek_spr(skyadr,0),
   peek_spr(skyadr,1),
   peek_spr(skyadr,2),
   peek_spr(skyadr,3)
  start_scene(scn_game)
 end
 --updating
 rot_intro.y+=0.015
 for p=1,2 do
  nss[p]=intro_mnu[3+p].val or 1
  --loading ship
  if lastnss[p]~=nss[p] then
   lastnss[p]=nss[p]
   loadship(p,nss[p]-1)
   initshipaccel(ship[p])
   ssp[p].xflat,ssp[p].z,
    sssp[p].z=0,88,88
  end
 
  local mat=calcrotmat(rot_intro)
  zz[p]=applyrot(ss[p],mat,true)
  zzz[p]=applyrot(sss[p],mat,false)
 end
end
function draw_intro()
 cls(0)
 offset+=1
 spr_grd(67,32,4,64,31,0x1b0,offset)

 --choice
 nb_player=intro_mnu[1].val
 local y=39
 for yitem=1,#intro_mnu do
  entry=intro_mnu[yitem]
  col=7
  if (entry.val==nil) entry.val=1
  -- 2nd ship
  if entry.name~="ship 2   " 
    or nb_player~=1 then
   if entry.values then
    entry.value=entry.values[entry.val]
   else
    entry.value=entry.val
   end

   local msg=entry.name..entry.value
   if nb_choice==yitem then
    col=8
    print("⬅️             "
     .."        ➡️",16,y,col)
   end
   print(msg,46,y,col)
  end
  y+=6
 end
 spr(39,60,122,2,1)
 print("start ❎🅾️    yourykiki",
  16,122,1)
 if nb_choice==3 then
  local itrk=intro_mnu[3].val-1
  spr(204,16,72,4,4)
  spr(131+2*itrk,24,80,2,2)
  print("best race time",56,72,5)
  print(formattime(
          dget(itrk*4+
             intro_mnu[2].val-1)),
        64,78,5)
 else
  -- ships
  for p=1,nb_player do
   cx=-32*(nb_player-1)+p*64
   spr(44,cx-15,96,4,4)
   drawvoxel(zzz[p],sssp[p],cam_int,0,0)
   drawvoxel(zz[p],ssp[p],cam_int,0,0)
   -- stats
   cx=cx-14
   print(ship[p].name,cx,70,5)
   print("   m:"..ship[p].mass,cx,82)
   local j,k=0
   for i=1,28 do
    k=ship[p].accurv[(i*100/28)\1]
    line(cx+i-1,86-j,cx+i,86-k,7)
    j=k
   end
  end
 end
-- print("cpu:"..stat(1),0,0,1)
end

function formattime(tm)
 local mm="0"..((tm\30)%60)
 return (tm\1800)..":"
  ..sub(mm,#mm-1).."."
  ..(tm\3)%10
end

-->8
-- rasterization @fsouchu
function polyfill(p,col,flp)
	color(col)
 if (flp) fillp(flp)
	local p0,nodes=p[#p],{}
	local x0,y0=p0[1],p0[2]
	for i=1,#p do
		local p1=p[i]
		local x1,y1=p1[1],p1[2]
		local _x1,_y1=x1,y1
		if(y0>y1) x1=x0 y1=y0 x0=_x1 y0=_y1
		local dx=(x1-x0)/(y1-y0)
		if(y0<0) x0-=y0*dx y0=-1
		local cy0=y0\1+1
		x0+=(cy0-y0)*dx
		for y=cy0,min(y1\1,127) do
			local x=nodes[y]
			if x then
				rectfill(x,y,x0,y)
			else
				nodes[y]=x0
			end
			x0+=dx
		end
		x0=_x1
		y0=_y1
	end
	fillp()
end
--helper
function pfill(x1,y1,x2,y2,x3,y3,x4,y4,c,flp)
 local q={}
 add(q,{x1,y1})
 add(q,{x2,y2})
 add(q,{x3,y3})
 if (x4 and y4) add(q,{x4,y4})
 polyfill(q,c,flp)
end

-->8
--triplefox with ciura's sequence
--https://www.lexaloffle.com/bbs/?tid=2477
shell_gaps={701,301,132,57,23,10,4,1} 
function shellsort(a)
 for gap in all(shell_gaps) do
  if gap<=#a then
   for i=gap,#a do
    local t=a[i]
    local j=i
    while j>gap and
       a[j-gap].key>t.key do 
     a[j]=a[j-gap]
     j-=gap
    end
    a[j]=t
   end
  end
 end
end

-->8
-- math lerp
function lerp(v0,v1,prc)
 return (1-prc)*v0+prc*v1
end

function sqrdist(x1,y1,x2,y2)
 return (x2-x1)^2+(y2-y1)^2
end

function getaccel(accurv,prc)
 return accurv[mid(0,prc\1,100)]
end

function get_r_accel(r_accurv,val)
 local prc=r_accurv[val\1]
 if (prc) return prc
 if (val>0) return 100
 return 0 
end

function calcrotmat(rot)
 --pitch x yaw y roll z
 local cosa,sina,cosb,sinb,cosc,sinc=
  cos(rot.z),sin(rot.z),
  cos(-rot.y),sin(-rot.y),
  cos(rot.x),sin(rot.x)
 
 local axx,axy,axz=
  cosa*cosb,
  cosa*sinb*sinc-sina*cosc,
  cosa*sinb*cosc+sina*sinc

 local ayx,ayy,ayz=
  sina*cosb,
  sina*sinb*sinc+cosa*cosc,
  sina*sinb*cosc-cosa*sinc

 local azx,azy,azz=
  -sinb,cosb*sinc,cosb*cosc 

 return {xx=axx,xy=axy,xz=axz,
  yx=ayx,yy=ayy,yz=ayz,
  zx=azx,zy=azy,zz=azz}
end

function recover_cdn(ssp)
 return 0.3/(6-ssp.hp\25.0001)
end
-->8
--particles
function create_particles(part,
 pos,sp,obj)
 for i=1,part.nb do
  local new_part=part.create(pos,sp,obj)
  local v=road[get_ird(new_part)+1]
  add(v.parts,new_part)
  add(part.parts,new_part)
 end
end
function update_particles(part)
 for p in all(part.parts) do
  local oird=get_ird(p)
  if not part.update(p) then
   -- dead particle
   del(road[oird+1].parts,p)
   del(part.parts,p)
  else
   -- placing in draw state
   local nird=get_ird(p)
   if oird~=nird then
    del(road[oird+1].parts,p)
    add(road[nird+1].parts,p)
   end
  end
  p.frm-=1
 end
end
function draw_part_line(
 part,cam,cfx,ntrk,col)
 if isnotvisible(part,cam,ntrk) then
  return
 end
 local pre,ofsx,ofsy,wz2=
  ntrk-cam.z,
  cx+cfx,cy,
  part.z+part.spz
 local fct1,fct2=
   scale/(part.z+pre),
   scale/(wz2+pre)
 local pos1,pos2=
  {x=part.x,y=part.y,z=part.z},
  {x=part.x+part.spx,
   y=part.y+part.spy,z=wz2}
 local x1,y1,x2,y2=
  ofsx+(pos1.x-cam.x)*fct1,
  ofsy-(pos1.y-cam.y)*fct1,
  ofsx+(pos2.x-cam.x)*fct2,
  ofsy-(pos2.y-cam.y)*fct2
	line(x1,y1,x2,y2,col)
end
function init_draw_voxel(pos,cam,ntrk,cfx)
 --pre,spcx,spcy,ofsx,ofsy
 return
  pos.z-cam.z+ntrk,
  pos.x-cam.x,pos.y-cam.y,
  cx+cfx,cy
end
-- sparks 
function create_spark(pos,sp)
	local ang,speed=
	 rnd(),.1+rnd"1"
	return {
		x=pos.x,y=pos.y,z=pos.z,
		spx=sin(ang)*speed,
		spy=cos(ang)*speed,
		spz=sp.z,
		frm=10+(rnd"20")\1,
		draw=draw_spark
	}
end
function update_spark(part)
	part.x+=part.spx
	part.y+=part.spy
	part.z+=part.spz
	part.spy-=0.1
	return part.frm>0
end
function draw_spark(part,cam,cfx,ntrk)
 draw_part_line(part,cam,cfx,ntrk,
  peek_spr(0x0030,part.frm))
end
p_spark={
	create=create_spark,
	update=update_spark,
	draw=draw_spark,
	parts={},
	nb=2
}
-- trails
function create_trail(pos,spd,obj)
	return {
		x=pos.x,y=pos.y,z=pos.z,
		spz=spd.z*0.98,
		frm=4,
		draw=draw_trail,
		trail=obj
	}
end
function update_trail(part)
	if part.frm <= 0 then
		return false
	end
	part.spz*=0.96
	part.z+=part.spz
	return true
end
function draw_trail(part,cam,cfx,ntrk)
 if isnotvisible(part,cam,ntrk) then
  return
 end
 local pre,spcx,spcy,ofsx,ofsy=
  init_draw_voxel(part,cam,ntrk,cfx)
 local r=part.trail
 local fct=scale/(r.z+pre)
 local vfct=2.5*fct
 local x,y=
  ofsx+fct*spcx+vfct*(r.x+0.5),
  ofsy-fct*spcy-vfct*(r.y-0.5)
 fillp(0b1010010110100101.1)
 circfill(x,y,min(vfct,2),
  peek_spr(0x00f0,part.frm))
 fillp()
end

p_trail={
 create=create_trail,
 update=update_trail,
 draw=draw_trail,
 parts={},
 nb=1
}
-- boost 
function create_boost(pos,sp,obj)
 local col=
  peek_spr(0x0130,(rnd"3")\1)
 return {
  x=rnd"256"-128,
  y=pos.y+rnd"56",
  z=pos.z+64+rnd"384",
  spx=0,spy=0,spz=-sp.z*0.75,
  frm=32+(rnd"32")\1,
  draw=draw_boost,
  col=col,
  player=obj
 }
end
function update_boost(part)
 if part.frm <=0 then
  return false
 end
 part.z+=part.spz
 part.spz*=0.9
 return true
end
function draw_boost(part,cam,cfx,ntrk,p)
 if (part.player~=p) return
 draw_part_line(part,cam,cfx,ntrk,
  part.col)
end
p_boost={
	create=create_boost,
	update=update_boost,
	draw=draw_boost,
	parts={},
	nb=2
}
-->8
-- token quest
function peek_spr(addr,offset)
 return peek(addr+offset/2) >>
  offset%2*4
end

function spr_grd(nbs,x,y,w,h,col_addr,offset)
 local sprx,spry,scol=
  nbs%16 *8,(nbs\16)*8,0
 for i=0,w do
  for j=0,h do
   scol=sget(sprx+i,spry+j)
   if scol==3 then
    pset(x+i,y+j,
     peek_spr(col_addr,(offset+(j\3))%30)+128)
   elseif scol!=0 then
    pset(x+i,y+j,scol)
   end
  end
  offset+=1
 end
end

function drawbar(yp,val,vmax,col)
 	rectfill(4,yp-1,
 	 lerp(4,24,abs(val/vmax)),
 	 yp,col)
end

function proj_fct_x(worldx,cfx)
 return cx+fct*worldx+cfx
end

function proj_fct_y(worldy)
 return cy-fct*worldy
end

function start_scene(scene)
  scn=scene
  scn.init()
  scn.update()
end

function loadship(p,nbss)
 ss[p],sss[p],xflat={},{},
  (p%2)*32-16
 loadss(nbss,ss[p],sss[p])
 ssp[p],rot[p],spd[p],
 ctrl[p],ird[p]=
  {x=0,y=8,z=72+24*p,
   xflat=xflat,yflat=9,
   rlap=0,rank=0,update=update_cntdn,
   frm=0},
  {x=0,y=0,z=1},
  {x=0,z=0,gx=0,gz=0,prc=0,cdn=0,bz=0},
  {cdn_bst=0,can_bst=true,drft=0},1
 sssp[p]={x=ssp[p].x,y=0,z=56}
 ship[p]=ship_info[nbss+1]
 ssp[p].hp=100
 ssp[p].xmin,ssp[p].xmax=
  xflat-5,xflat+5   
end

 
-- b1,b2,b3 border
-- prc on rb
-- flg1 flg2, rb type
-- borx
function road_part_collision(
  b1,b2,b3,prc,flg1,flg2,borx)
 if v.t&flg1==flg1 then
  --right 2
  if vn.t&flg1==flg1
   and v.t&flg2==0 then
   borx=b2
  else
   --right 2 to right 1
   borx=lerp(b2,b1,prc)
  end
  if vn.t&flg2==flg2
   and v.t&flg2==0 then
   --right 2 to right 3
   borx=lerp(b2,b3,prc)
  end
 end
 return borx
end
-- test coll 2
function road_part2_collision(
  b2,b3,prc,flg,borx)
 if v.t&flg==flg then
 	--left 3
 	if vn.t&flg==flg then
  	borx=b3
  else 
   borx=lerp(b3,b2,prc)
  end
 end
 return borx
end

function parse_trk()
 local trk={}
 byte_offset=num_trk*256
 for i=1,read_byte() do
  trk[i]={curv=read_byte(),
   len=read_byte(),
   frc=read_byte(),
   hgt=read_byte(),
   hln=read_byte()}
 end
 return trk
end

function read_byte()
 local val=peek(0x2000+byte_offset)-128
 byte_offset += 1
 if (val==-128) return nil
 return val
end

function is_collide(sspp,ssppn,
 shipp,shippn,dz)
 --/8 /4 scale
 return
  abs(sspp.xflat-ssppn.xflat)/8
   <=shipp.width+shippn.width
  and abs(sspp.z-ssppn.z)/4*dz
   <=shipp.height+shippn.height
end

function snd_engine(p,spd)
 sfx(47+p,p*2+1,mid(0,spd.z\1,11)*2,2)
end

function getdamage()
 return max(2,ai_skill)
end

function playersfx(p,nfx)
 if (p<=nb_player) sfx(nfx,(p-1)*2)
end
