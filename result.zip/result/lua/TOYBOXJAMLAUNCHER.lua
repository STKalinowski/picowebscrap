-- toy box jam launcher
-- by that tom hall & friends
-- songs: by gruber
-- large toy box: toby hefflin
-------------------------------
-- please excuse the crappy coding.
-- just wanted to get it done! 😐
-------------------------------
function _init()
	--direction and walk anim
	north=1
	east=2
	south=3
	west=4
	walkspeed=1
	walkframe=1 -- not used really
 -- animation counters
	twoframe=0 --two frame anims
 threeframe=2 -- three frame anims
	fourframe=1 -- four frame anims
 fiveframe=3 -- five frame anims
 sixframe=4 -- six frame anims
 maxdelay=16
 framedelay=maxdelay-1
 
 frame60=0
 -- data for all the carts! 
 cartnum=1
 cart={"spaghetti forever",
       "toy box tournament",
       "alfredo's stupendous surprise",
       "noobish dungeon",
       "food trail!",
       "chalice of the gods",
       "cecio of the valley",
       "max",
       "roombanator",
       "lava joe",
       "alien rescue mission",
       "toy box pipe",
       "myrtle takes the city",
       "arcane nectar",
       "monster speeddating",
       "thangkagen",
       "battlewing alliance",
       "flappy boffin: advanced",
       "skills of detection",
       "toy box dungeon",
       "ninjoe's trials",
       "rocket dude"
       }
 author={"mr. mandolino",
         "googroker",
         "liquidream",
         "bul71",
         "vapidvial",
         "geeitsomelaldy",
         "damngoodcocoa",
         "ghostronaut",
         "bttrs_",
         "paranoid cactus",
         "blodyavenger",
         "ximo",
         "paloblancogames",
         "dogsplusplus",
         "lu_bu",
         "disused",
         "skaarjslayer",
         "danb91",
         "kittenm4ster",
         "dollarone",
         "svntax",
         "damienmurtagh"
         }
 cartname={"#spaghettiforever",
       "#grokemanstoyboxtournament",
       "#alfredo",
       "#noob_dg",
       "#food_trail",
       "#chalice_of_the_gods",
       "#cecioofthevalley",
       "#ghostronaut_max_tbj2019",
       "#roombanator",
       "#lavajoe",
       "#alienrescuemission",
       "#tuberias_ximo",
       "#myrtlecity",
       "#arcanenectar",
       "#monster_speeddating",
       "#thangkagen",
       "#battlewing_alliance",
       "#flappy_boffin_advanced_danb91",
       "#skills_of_detection",
       "#dollarone_toyboxdungeon",
       "#ninjoes_trials",
       "#rocketdude"
       }
 --
 wallpos=0
 ----------------------------
 -- state to show off interesting
 gs_idle=0
 gs_title=1
 gs_showcarts=2
 gs_thanks=3
  
 -- set up demo data
 init_stars()
 game={}
 game.state=gs_title 

 frame_counter=0
 -- for ord and chr, sprint
 setup_asciitables()

 music(0)

end

--------------------------------
function init_stars()
 -- stars for space stuff
 -- you have to declare tables
 -- with ={} or their direct contents
 starsx={} -- x location of star
 starsy={} -- y location of star
 starsc={} -- color of star (darker = moves slower)
 numstars=40 -- decent number for not cluttery
 for i=1,numstars do
  starsx[i]=rnd(128) -- 0-127
  starsy[i]=rnd(128) -- 0-127
  --colors dark gray, light gray, white
  starsc[i]=5+flr(rnd((i%3)+.5)) -- 5, 6, 7 
  -- this with be 5, 6, or 7 without a fractional part
  -- i added +.5 to get more foreground stars
 end
 -- pick a direction! 0-3
 -- 0= up
 -- 1= upright
 -- 2= right
 -- 3= downright
 -- 4= down
 -- 5= downleft
 -- 6= left
 -- 7= upleft
 stars_direction=flr(rnd(8)) -- 0-7 integers
end
----------------------------
-- sets up ascii tables
-- by yellow afterlife
-- https://www.lexaloffle.com/bbs/?tid=2420
-- btw after ` not sure if 
-- accurate
function setup_asciitables()
 chars=" !\"#$%&'()*+,-./0123456789:;<=>?@abcdefghijklmnopqrstuvwxyz[\\]^_`|██▒🐱⬇️░✽●♥☉웃⌂⬅️🅾️😐♪🅾️◆…➡️★⧗⬆️ˇ∧❎▤▥~"
 -- '
 s2c={}
 c2s={}
 for i=1,#chars do
  c=i+31
  s=sub(chars,i,i)
  c2s[c]=s
  s2c[s]=c
 end
end
---------------------------
function asc(_chr)
 return s2c[_chr]
end
---------------------------
function chr(_ascii)
 return c2s[_ascii]
end


-->8
-- update tab
-------------------------------
function _update60()
 local old_gs, temp
 
 old_gs=game.state
 -- update state, check input
 framedelay-=1
 if (framedelay==0) then
  twoframe = (twoframe+1) % 2 --two frame anims
  threeframe = (threeframe+1) % 3 --two frame anims
  fourframe = (fourframe+1) % 4 -- four frame anims
  fiveframe = (fiveframe+1) % 5 -- five frame anims
  sixframe = (sixframe+1) % 6 -- six frame anims
  framedelay=maxdelay
  scroll_tile(16) -- scroll water down
 end --framedelay
 frame60 = (frame60+1) % 60

 move_stars(stars_direction)
 if (btnp(⬅️)) then
  if (cartnum==1 and game.state==gs_showcarts) or (game.state!=gs_showcarts) then
	  game.state -= 1
	  if (game.state==gs_showcarts) cartnum=#cart
	  stars_direction=7-stars_direction
	  if (game.state<1) game.state=gs_thanks 
  elseif (game.state==gs_showcarts) then
    cartnum-=1
    poop=stars_direction
    stars_direction=flr(rnd(8))
    if (stars_direction==poop) stars_direction=7-poop
  end
 --end
 elseif (btnp(➡️)) then
  if (cartnum==#cart) or (game.state!=gs_showcarts) then
   game.state += 1
	  if (game.state==gs_showcarts) cartnum=1
	  stars_direction=7-stars_direction
   if (game.state>gs_thanks) game.state=gs_title 
  elseif (game.state==gs_showcarts) then
    cartnum+=1
    poop=stars_direction
    stars_direction=flr(rnd(8))
    if (stars_direction==poop) stars_direction=7-poop
  end
 elseif (btnp(❎) and game.state==gs_showcarts) then
  load(cartname[cartnum],"back to launcher")
 end -- if btn
  -- change music on state change
 if (old_gs != game.state) then
  if (game.state == gs_showcarts) then music(6)
  elseif (game.state==gs_title) then music(0)
  elseif (game.state==gs_thanks) then music(25) -- 29
  end -- state
 end -- gamestate
end -- fn


----------------------------
function move_stars(direction)
 for i=1,numstars do
  -- here we see what direction we are moving the stars
  -- for up, we subtract the movement in y direction
  -- for others, the same x and y, plus or minus
  -- for a final version, i'd have a "move table"
  -- containing the deltax and deltay, but this will
  -- be a lot clearer what we are doing
  move=(starsc[i]-4)/2 -- how far to move this star
  if (direction==0) then -- up
   starsy[i]=(starsy[i]-move)%128
  elseif (direction==1) then -- upright
   starsx[i]=(starsx[i]+move)%128
   starsy[i]=(starsy[i]-move)%128
  elseif (direction==2) then -- right
   starsx[i]=(starsx[i]+move)%128
  elseif (direction==3) then -- down right
   starsx[i]=(starsx[i]+move)%128
   starsy[i]=(starsy[i]+move)%128
  elseif (direction==4) then -- down
   starsy[i]=(starsy[i]+move)%128
  elseif (direction==5) then -- down left
   starsx[i]=(starsx[i]-move)%128
   starsy[i]=(starsy[i]+move)%128
  elseif (direction==6) then -- left
   starsx[i]=(starsx[i]+move)%128
  elseif (direction==7) then -- up left
   starsx[i]=(starsx[i]-move)%128
   starsy[i]=(starsy[i]-move)%128
  end
 if (frame60==0 and game.state == gs_explodestars) stars_direction=flr(rnd(8))
 end
end
-->8
--draw tab
-------------------------------
function _draw()
 cls()
 --title bar on bottom
 sprint("<              >",0,15)
 if (game.state==gs_title) then
  -- instructions
  -- use left and right arrows
  draw_stars()
  palt(0,false)
  palt(14,true)
  spr(140,47,20,4,4)
  if (time() > 20) then
   clip(47,0,80,28)
   spr(128+twoframe,48,23)
   if (time() > 40) spr(100+twoframe,62+twoframe,23)
   if (time() > 60) spr(102+twoframe,61,13-twoframe)
   clip()
   if (time() > 80) then
    spr(104+(twoframe*2),104,8,2,2)
    spr(108+(twoframe*2),8,8,2,2)
   end
  end
  palt()
  printc("welcome to the",60,9)
  printc("toy box jam",68,7)
  printc("launcher",76,9)
  print("⬅️➡️ for games",34,92,4)
  
  sprintc("toy box jam",15)
 elseif (game.state==gs_showcarts) then
  draw_stars()
  palt(0,false)
  palt(14,true)
  spr(140,47,20,4,4)
  palt()
  printc("toy box jam",60,7)
  printc("game entry",68,7)

  printc(cart[cartnum],80,10)
  printc(author[cartnum],90,9)
  printc("❎ to launch",100,4)

  
  sprintc("game cart "..cartnum,15,9)
 elseif (game.state==gs_thanks) then
  -- stuff
  draw_boxes()
  --ship draw at shipx with easing slowdown
  printoc("a little message",60,9,4)
  printoc("thanks to everyone",70,7,5)
  printoc("for participating!",78,7,5)
  printoc("tox boy jam will return",108,10,4)

  sprint("<              >",0,15)
  sprintc("thanks",15,9)
 end -- big state if
end -- draw

----------------------------
function draw_stars()
  -- draw stars color c at x,y
  for i=1,numstars do
   pset(starsx[i],starsy[i],starsc[i])
  end
end
----------------------------
function draw_boxes()
  -- draw stars color c at x,y
  for i=1,numstars do
   spr(186,starsx[i],starsy[i]) -- ,starsc[i]
  end
end




-->8
-- support library
-------------------------------
-- scroll tile
-- see that water tile?
-- this scrolls it down by 1
function scroll_tile(_tile)
 local temp
 local sheetwidth=64 -- bytes
 local spritestart=0 -- starts at mem address 0x0000
 local spritewide=4 -- 8 pixels=four bytes
 local spritehigh=sheetwidth*8 -- how far to jump down
 local startcol=_tile%16
 local startrow=flr(_tile/16)
 
 if (_tile>255) return
 -- save bottom row of sprite
 temp=peek4(spritestart+(startrow*sheetwidth*8)+(7*sheetwidth)+startcol*spritewide) -- 7th row
 for i=6,0,-1 do
  poke4(spritestart+(startrow*sheetwidth*8)+((i+1)*sheetwidth)+startcol*spritewide,peek4(spritestart+(startrow*sheetwidth*8)+(i*sheetwidth)+startcol*spritewide)) 
 end
 --now put bottom row on top!
 poke4(spritestart+(startrow*sheetwidth*8)+startcol*spritewide,temp) 
end 

-------------------------------
-- print string s at x y with
-- color c and outline optional
function print6(_s,_x,_y,_c,_o)
end
-------------------------------
-- collision detection function;
-- returns true if two boxes overlap, false if they don't;
-- x1,y1 are the top-left coords of the first box, while w1,h1 are its width and height;
-- x2,y2,w2 & h2 are the same, but for the second box.
function checkcollision(x1,y1,w1,h1, x2,y2,w2,h2)
  return x1 < x2+w2 and
         x2 < x1+w1 and
         y1 < y2+h2 and
         y2 < y1+h1
end

-------------------------------
function printc(_str,_y,_c)
 len=#_str
 where=63-(len*2)
 if (where<0) where=0
 print(_str,where,_y,_c)
end
-------------------------------
function printo(str, x, y, c0, c1)
for xx = -1, 1 do
 for yy = -1, 1 do
 print(str, x+xx, y+yy, c1)
 end
end
print(str,x,y,c0)
end
-------------------------------
function printoc(_str, y, c0, c1)
 len=#_str
 where=63-(len*2)
 if (where<0) where=0
 for xx = -1, 1 do
  for yy = -1, 1 do
  print(_str, where+xx, y+yy, c1)
  end
 end
print(_str,where,y,c0)
end
-------------------------------
-- sprite print
-- _c = letter color
-- _c2 = line color
-- _c3 = background color of font
-- collapse all these sprite
-- printing routines into one
-- function if you want!
function sprint(_str,_x,_y,_c,_c2,_c3)
 local i, num
 palt(0,false) -- make sure black is solid
 if (_c != nil) pal(7,_c) -- instead of white, draw this
 if (_c2 != nil) pal(6,_c2) -- instead of light gray, draw this
 if (_c3 != nil) pal(5,_c3) -- instead of dark gray, draw this
 -- make color 5 and 6 transparent for font plus shadow on screen
  
 for i=1,#_str do
  num=asc(sub(_str,i,i))+160
  spr(num,(_x+i-1)*8,_y*8)
 end
 pal()
end
-------------------------------
-- sprite print centered on x
function sprintc(_str,_y,_c,_c2,_c3)
 local i, num
 _x=63-(flr(#_str*8)/2)
 palt(0,false) -- make sure black is solid
 if (_c != nil) pal(7,_c) -- instead of white, draw this
 if (_c2 != nil) pal(6,_c2) -- instead of light gray, draw this
 if (_c3 != nil) pal(5,_c3) -- instead of dark gray, draw this
 -- make color 5 and 6 transparent for font plus shadow on screen
  
 for i=1,#_str do
  num=asc(sub(_str,i,i))+160
  spr(num,_x+(i-1)*8,_y*8)
 end
 pal()
end
-------------------------------
-- sprite print at x,y pixel coords
function sprintxy(_str,_x,_y,_c,_c2,_c3)
 local i, num
 palt(0,false) -- make sure black is solid
 if (_c != nil) pal(7,_c) -- instead of white, draw this
 if (_c2 != nil) pal(6,_c2) -- instead of light gray, draw this
 if (_c3 != nil) pal(5,_c3) -- instead of dark gray, draw this
 -- make color 5 and 6 transparent for font plus shadow on screen
  
 for i=1,#_str do
  num=asc(sub(_str,i,i))+160
  spr(num,_x+(i-1)*8,_y)
 end
 pal()
end
-------------------------------
-- double-sized sprite print at x,y pixel coords
function dsprintxy(_str,_x,_y,_c,_c2,_c3)
 local i, num,sx,sy
 palt(0,false) -- make sure black is solid
 if (_c != nil) pal(7,_c) -- instead of white, draw this
 if (_c2 != nil) pal(6,_c2) -- instead of light gray, draw this
 if (_c3 != nil) pal(5,_c3) -- instead of dark gray, draw this
 -- make color 5 and 6 transparent for font plus shadow on screen
 -- (btw you can use this technique
 -- just to draw sprites bigger)
 for i=1,#_str do
  num=asc(sub(_str,i,i))+160
  sy=flr(num/16)*8
  sx=(num%16)*8
  sspr(sx,sy,8,8,_x+(i-1)*16,_y,16,16)
 end
 pal()
end
