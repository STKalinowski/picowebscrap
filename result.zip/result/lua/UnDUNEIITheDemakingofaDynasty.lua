-- undune ii
-- by paul nicholas
_a={
{ 12, 1},
{ 11, 3},
{ 8,  2},
{ 14, 2},
}
_b=1
_c=2
_d=3
_e=4
_f=5
_g={
{
{1,999,1000,4,1,88,72,2,24,64,2,160,64,2,160,152,2400,32,32,16},{2,1200,2700,2,1,144,200,2,120,96,nil,nil,nil,nil,nil,nil,960,32,88,144},{3,1500,nil,2,1,176,112,3,408,440,nil,nil,nil,nil,nil,nil,840,62,120,56},{4,1500,nil,3,1,176,432,3,296,16,4,320,0,nil,nil,nil,720,62,120,376},{5,1500,nil,2,1,88,200,2,448,288,nil,nil,nil,nil,nil,nil,600,62,32,144},{6,1700,nil,3,1,264,312,3,8,24,3,480,136,nil,nil,nil,480,62,208,256},{7,2000,nil,4,1,200,72,2,280,408,nil,nil,nil,nil,nil,nil,360,62,144,16},{8,2000,nil,4,1,192,240,3,328,8,2,248,448,2,424,424,240,62,136,184},{9,2500,nil,4,1,232,416,4,360,40,3,112,40,2,408,136,120,62,176,360},},{
{1,999,1000,4,2,88,72,3,24,64,3,160,64,3,160,152,2400,32,32,16},{2,1200,2700,2,2,144,200,3,120,96,nil,nil,nil,nil,nil,nil,960,32,88,144},{3,1500,nil,2,2,176,112,1,408,440,nil,nil,nil,nil,nil,nil,840,62,120,56},{4,1500,nil,3,2,176,432,1,296,16,4,320,0,nil,nil,nil,720,62,120,376},{5,1500,nil,2,2,88,200,3,448,288,nil,nil,nil,nil,nil,nil,600,62,32,144},{6,1700,nil,3,2,264,312,1,8,24,1,480,136,nil,nil,nil,480,62,208,256},{7,2000,nil,4,2,200,72,3,280,408,nil,nil,nil,nil,nil,nil,360,62,144,16},{8,2000,nil,4,2,192,240,3,328,8,1,248,448,1,424,424,240,62,136,184},{9,2500,nil,4,2,232,416,4,360,40,3,112,40,1,408,136,120,62,176,360},},{
{1,999,1000,4,3,88,72,1,24,64,1,160,64,1,160,152,2400,32,32,16},{2,1200,2700,2,3,144,200,1,120,96,nil,nil,nil,nil,nil,nil,960,32,88,144},{3,1500,nil,2,3,176,112,2,408,440,nil,nil,nil,nil,nil,nil,840,62,120,56},{4,1500,nil,3,3,176,432,2,296,16,4,320,0,nil,nil,nil,720,62,120,376},{5,1500,nil,2,3,88,200,1,448,288,nil,nil,nil,nil,nil,nil,600,62,32,144},{6,1700,nil,3,3,264,312,2,8,24,2,480,136,nil,nil,nil,480,62,208,256},{7,2000,nil,4,3,200,72,1,280,408,nil,nil,nil,nil,nil,nil,360,62,144,16},{8,2000,nil,4,3,192,240,2,328,8,1,248,448,1,424,424,240,62,136,184},{9,2500,nil,4,3,232,416,4,360,40,2,112,40,1,408,136,120,62,176,360},}
}
_h={
[0]={"tHE PLANET aRRAKIS,\nKNOWN AS dUNE.\n\nlAND OF SAND;\nHOME OF THE sPICE mELANGE.:tHE sPICE CONTROLS THE eMPIRE.\n\nwHOEVER CONTROLS dUNE \nCONTROLS THE sPICE.:tHE eMPEROR HAS PROPOSED A \nCHALLENGE TO EACH OF THE hOUSES.:tHE hOUSE THAT PRODUCES THE \nMOST sPICE WILL CONTROL dUNE.\n\ntHERE ARE NO SET TERRITORIES \nAND NO RULES OF ENGAGEMENT.","vAST ARMIES HAVE ARRIVED.\n\nnOW, THREE HOUSES FIGHT FOR \nCONTROL OF dUNE.","tHE NOBLE aTREIDES,","THE INSIDIOUS oRDOS, ","AND THE EVIL hARKONNEN. ","oNLY ONE HOUSE WILL PREVAIL.","yOUR BATTLE FOR dUNE BEGINS...\n\n           ...now.",},{"gREETINGS,\ni AM YOUR mENTAT cYRIL.:tOGETHER WE WILL PURGE THIS\nPLANET OF THE FOULNESS OF THE\nOTHER hOUSES.:tHE hIGH cOMMAND WISHES YOU\nTO PRODUCE 1000 CREDITS.:yOU MAY EARN CREDITS BY\nBUILDING A REFINERY AND\nHARVESTING SPICE","gREETINGS,\ni AM HONORED TO SEE YOU AGAIN.:tHE hIGH cOMMAND NOW REQUIRES\nTHAT YOU PRODUCE 2700 CREDITS\nIN A NEW HARVESTING AREA.:uNFORTUNATELY, WE HAVE\nCONFIRMED THE PRESENCE OF AN\noRDOS BASE IN THIS REGION.:gOOD LUCK!","tHE BATTLE WITH THE OTHER \nhOUSES HAS INTENSIFIED AND WE \nARE NOW FORCED TO ENGAGE IN \nSOME SELECTED OFFENSIVE \nMANEUVERS.:tHE hARKONNEN ARE BEING \nEXTREMELY TROUBLESOME IN YOUR \nNEXT REGION, AND WE MUST ASK \nYOU TO REMOVE THEIR PRESENCE \nFROM THIS AREA.","yOUR DEMONSTRATION OF MILITARY \nSKILLS NOW FORCES US TO ASSIGN \nYOU TO ANOTHER OFFENSIVE \nCAMPAIGN AGAINST THE hOUSE \nhARKONNEN.:tHEY HAVE CONTINUED TO ATTACK \nOUR PEACEFUL HARVESTERS, AND \nMUST BE REMOVED FROM THE AREA.","wELCOME.\n\ntHE RULES SEEM TO HAVE CHANGED.:\naS YOU HAVE WITNESSED THE \neMPEROR HIMSELF HAS BEEN AIDING \nTHE EFFORTS OF OUR COMPETITORS!:aS A PART OF OUR NEW STRATEGY, \nWE MUST ASK THAT YOU ELIMINATE \nTHE TREACHEROUS oRDOS FORCES \nTHAT PRESENTLY CONTROL THIS \nREGION.","aS THE BATTLE FOR THIS PLANET \nINTENSIFIES, ALL EFFORTS MUST \nBE TAKEN TO ENSURE SUCCESS.:oNCE AGAIN WE MUST CALL UPON \nYOU TO DESTROY OUR ENEMIES IN A \nTROUBLED SECTOR.:hOUSE hARKONNEN MUST BE TAUGHT \nA LESSON.\n\ntHANK YOU, AND GOOD LUCK!","tHE BATTLE GOES WELL, BUT THERE \nIS NO TIME TO RELAX.:wE HAVE AN URGENT NEED FOR YOU \nTO SUBDUE ALL oRDOS FORCES IN \nTHIS REGION PROMPTLY.:oUR ONGOING NEGOTIATIONS ARE \nAIDED IMMEASURABLY BY \nCORRESPONDING VICTORIES IN THE \nFIELD.:wE ARE COUNTING ON YOU.","aLTHOUGH YOU HAVE EARNED A WELL \nDESERVED REST, i'M AFRAID THE \nPOLITICAL SITUATION REQUIRES \nTHAT WE SEND YOU BACK INTO THE \nFIELD IMMEDIATELY.:bOTH oRDOS AND hARKONNEN FORCES \nHAVE BUILT UP TO UNACCEPTABLE \nLEVELS IN THIS REGION, AND NOW \nMUST BE REMOVED COMPLETELY.","yOUR NEXT ASSIGNMENT WILL \nDETERMINE THE ENTIRE OUTCOME OF \nOUR EFFORTS ON dUNE.:vICTORY WILL NOT COME EASILY.:iN ADDITION TO DESTROYING ALL \nREMAINING oRDOS AND hARKONNEN \nTROOPS...:...YOU ARE ALSO INSTRUCTED TO \nSUBDUE eMPEROR fREDERICK'S \nFORCES.:aLL OF OUR HOPES AND DREAMS ARE\nRIDING ON YOU, AND WE HUMBLY \nBEG YOU TO PROVIDE ONE FINAL \nVICTORY FOR OUR NOBLE \nhOUSE aTREIDES.","gOOD MORNING YOUR LORDSHIP,\nAND CONGRATULATIONS!\n\nyOU SERVED hOUSE aTREIDES WELL.:wE WILL NOT SOON FORGET OUR \nMOST NOBLE WARRIOR.:i GO NOW TO RELAY THE NEWS OF \nYOUR MOST GLORIOUS VICTORY AND \nDELIVER YOUR TERMS TO THE \neMPEROR.","mY GOODNESS, WHAT AN AWFUL \nDEFEAT!:pERHAPS WE HAVE GIVEN YOU TOO\nMUCH RESPONSIBILITY.:iF YOU FAIL AT YOUR NEXT\nASSIGNMENT,\nWE WILL HAVE TO SERIOUSLY\nCONSIDER SENDING YOU HOME!",},{"wELCOME.\ni AM YOUR mENTAT, AND YOU MAY \nCALL ME aMMON.:tO BE OF ANY VALUE TO THE \ncARTEL, YOU MUST PROVIDE US \nWITH CREDITS.:aS A TEST, WE WILL ASSIGN YOU \nTO A REGION, AND ASK THAT YOU \nMEET A PRODUCTION QUOTA OF \n1000 CREDITS.:bUILD A REFINERY AND HARVEST \nTHE SPICE IN THE AREA. i AM \nVERY BUSY, BUT YOU MAY CALL \nUPON ME IF YOU HAVE FURTHER \nQUESTIONS.","yOUR QUOTA IS NOW 2700 CREDITS, \nAND THIS SPICE ACCUMULATION IS \nYOUR PRIMARY DIRECTIVE.:wE DO NOT EXPECT YOU TO DESTROY \nTHE hARKONNEN FORCES IN THE \nAREA,:HOWEVER YOU SHOULD CONSIDER THE \nTIME THAT COULD BE SAVED BY \nAPPROPRIATING THEIR SILOS.","wE FIND THE ACTIVITIES OF \naTREIDES TROOPS IN THIS REGION \nINCONVENIENT.:pLEASE REMOVE THIS OBSTACLE.\n\nwE CANNOT ALLOW THE MYTHICAL \nVALUE OF FAIR PLAY TO IMPEDE \nOUR PROGRESS.","tHE aTREIDES FORCES IN THIS \nAREA MUST BE ELIMINATED.:aS ALWAYS, WE APPRECIATE YOUR \nCAPTURE OF ANY ENEMY SILOS OR \nOTHER STRUCTURES THAT MIGHT BE \nSALVAGEABLE.","sO, OUR SPIES REVEAL WHY THE \nsARDAUKAR ATTACKED US IN YOUR \nLAST MISSION.\n\ni WILL NEED TO LOOK INTO THIS.:aLTHOUGH THE hARKONNEN \nCOMMANDERS ARE LAUGHABLY STUPID\nTHEIR MILITARY STRENGTH IS A \nTHREAT TO US IN THIS AREA.:tHEY MUST BE ELIMINATED AS SOON\nAS POSSIBLE.","tHE aTREIDES HAVE BECOME FAR \nTOO VOCAL IN THIS SECTOR, AND \nWHINE CONSTANTLY ABOUT THEIR \nRIGHTS.:wE oRDOS DO NOT HAVE THE \nLEISURE OF POINTLESS \nCONVERSATION, AND MUST ASK YOU \nELIMINATE THIS DISTRACTION.","hARKONNEN FORCES CONTINUE TO \nTHWART OUR EFFORTS IN THIS \nREGION, AND MUST BE REMOVED \nCOMPLETELY.:cRUSH THEIR BELOVED TROOPERS \nAND THEY WILL RUN CRYING BACK \nTO THEIR UGLY MOTHERS!","bOTH aTREIDES AND hARKONNEN \nFORCES OPPOSE OUR CONTROL OF \nTHIS AREA AND MUST THEREFORE BE\nDESTROYED.:tHE TIME OF COOPERATION AND \nCOMPROMISE IS PAST, AND ALL \nENEMIES OF hOUSE oRDOS MUST BE\nELIMINATED!","eMPEROR fREDERICK HAS JOINED \nTHE LIST OF oRDOS' ENEMIES, AND \nMUST BE PUNISHED.:dESTROY HIS TROOPS AND ANY \naTREIDES AND hARKONNEN REMNANTS \nTHAT STILL OPPOSE US ON THIS \nPLANET.:wE HAVE RISKED EVERYTHING ON \nTHIS FINAL BATTLE, AND CANNOT \nTOLERATE LESS THAN YOUR BEST \nEFFORT.","gOOD mORNING, YOUR LORDSHIP, \nAND CONGRATULATIONS!\n\nyOU'VE SERVED hOUSE oRDOS WELL.:wE WILL NOT SOON FORGET OUR \nMOST NOBLE WARRIOR!:i GO NOW TO RELAY THE NEWS OF \nYOUR MOST GLORIOUS VICTORY, AND \nDELIVER YOUR TERMS TO THE \neMPEROR.","aPPARENTLY, i WAS MISTAKEN \nABOUT YOUR POTENTIAL.:iT WILL COST US A GREAT DEAL TO\nRETAKE THIS REGION.:oNLY COMPLETE SUCCESS WITH YOUR\nNEXT ASSIGNMENT COULD POSSIBLY\nRESURRECT YOUR CAREER.",},{"i AM THE mENTAT, rADNOR.:wITH MY GUIDANCE, YOU MAY BE \nABLE TO ASSIST US IN CONQUERING \nTHIS DUSTY LITTLE PLANET.:fOR YOUR FIRST TEST YOU WILL BE\nEXPECTED TO PRODUCE 1000 \nCREDITS, AND NOT A GRANULE LESS:yOU MAY EARN CREDITS BY \nHARVESTING SPICE, AND WILL NEED\nTO BUILD A REFINERY TO CONVERT\nSPICE TO CREDITS.:iF ANY OF OUR FOOLISH ENEMIES \nATTEMPTS TO ATTACK YOUR BASE \nYOU WILL HAVE THE PLEASURE OF\nSEEING THE INVINCIBLE hARKONNEN\nTROOPS IN ACTION.","hOUSE hARKONNEN HAS GENEROUSLY \nGRANTED YOU A NEW OPPORTUNITY \nTO SERVE US.:wE WILL NOW ALLOW YOU TO TAKE \nCOMMAND IN A MORE DANGEROUS \nAREA, AND ACCUMULATE 2700 \nCREDITS.:aLTHOUGH THE WORTHLESS aTREIDES\nYOU MAY ENCOUNTER IN THIS \nREGION SHOULD BE ELIMINATED AS \nA MATTER OF PRINCIPLE,:...THE SPICE QUOTA IS \nYOUR OBJECTIVE.","tHE DESPISED oRDOS ARE WELL \nESTABLISHED IN THIS REGION, AND \nARE HARVESTING SPICE THAT \nSHOULD RIGHTFULLY BELONG TO \nhOUSE hARKONNEN.:dESTROY THE oRDOS INSTALLATIONS \nIN THIS AREA AND ASSERT CONTROL \nIN THE NAME OF hOUSE hARKONNEN.","oNE SMALL VICTORY DOES NOT WIN \nTHE WAR.:aNOTHER REGION HAS THE \nMISFORTUNE TO BE INFESTED WITH \nVERMIN FROM hOUSE oRDOS, AND \nYOU MUST NOW REPEAT YOUR \nSUCCESS.:i HAVE MANY DELICATE POLITICAL \nNEGOTATIONS ON MY MIND, AND i \nDON'T NEED TO BE WORRYING ABOUT\nLOOSE ENDS.","sO, THE eMPEROR WAS HELPING THE \noRDOS IN YOUR LAST MISSION.:nEVERTHELESS, hOUSE aTREIDES \nHAS GROWN STRONGER DUE TO OUR \nNEGLIGENCE, AND MUST NOW BE \nTAUGHT A LESSON.:yOU WILL REMOVE ALL THE \naTREIDES FROM THIS REGION.","yOU ARE TO PROCEED INTO YET \nANOTHER REGION DOMINATED BY \nTHOSE PESKY oRDOS, AND i EXPECT\nYOU TO OVERCOME THIS RATHER \nTROUBLESOME oRDOS GROUP.:wE HAVE ESTABLISHED A GOOD \nREPUTATION ON THIS PLANET.\n\ndO NOT EMBARRASS ME NOW!","rEPORTS OF NEW aTREIDES \nACTIVITY REQUIRE THAT i SEND \nYOU IMMEDIATELY BACK TO THE \nFRONT LINE.:yOU DO NOT SEEM TO ENJOY REST \nAND RELAXATION ANYWAY.\n\ni THINK YOU WOULD PREFER TO \nCRUSH THE aTREIDES.","i HAVE USED MY INFLUENCE TO \nARRANGE A pALACE FOR YOU.:a COMMANDER OF YOUR STATUS MAY \nREQUIRE RELAXATION OCCASIONALLY \nBUT i EXPECT AN EVEN GREATER \nEFFICIENCY ON YOUR PART WILL \nCOME FROM OUR GENEROSITY.:bOTH aTREIDES AND oRDOS FORCES \nEXIST IN THIS REGION,\nAND ALL MUST BE ELIMINATED!","wE HAVE BEEN DECEIVED!:oUR BARGAINING IN GOOD FAITH \nHAS ONLY BROUGHT A TREACHEROUS \nHARVEST. aLL HAVE CONSPIRED \nAGAINST US, AND ALL MUST DIE!:yOUR MILITARY SKILLS ARE THE \nLAST REMAINING HOPE FOR THIS \nPLANET.:dESTROY ALL REMAINING aTREIDES \nAND oRDOS FORCES, AND CONQUER \nTHE eMPEROR'S pALACE.\nhE HAS TREATED US POORLY, AND \nMUST NOT LIVE ANOTHER DAY!","gOOD mORNING, YOUR LORDSHIP, \nAND CONGRATULATIONS!\n\nyOU HAVE SERVED ME, i MEAN \nhOUSE hARKONNEN, WELL.:oUR hOUSE WILL NOT SOON FORGET \nOUR MOST NOBLE WARRIOR!:i GO NOW TO RELAY THE NEWS OF \nYOUR MOST GLORIOUS VICTORY, AND \nDELIVER YOUR TERMS TO THE \neMPEROR.","yOU ARE BENEATH MY COMTEMPT.:dO YOU KNOW WHAT HAPPENS TO \nTHOSE WHO HAVE FAILED \nhOUSE hARKONNEN?",}
}
_i="   ♥ sUPPORTER tHANKS: ★ tHATtOMhALL ★ vITORIO mILIANO ★ aNDREW dICKER ★ kURT kLEMM ★ BBSAMURAI ★ dALJIT cHANDI ★ rOY fIELDING ★ gRAHAM wENZ ★ fRANZ tORMER ★ cHRISTOPHER cASTILLO ★ oLIVER hUNT ★ cODY dILL ★ wILMAN ★ mICHAEL sULLIVAN ★ mANDO ★ UENA ★ sTRIPESBYnw ★ mORGAN bROWN ★"
_j=_b
_k=nil
t_=0
_l=0
function _init()
cartdata("pn_undune2")
poke(0x5f2d, 0x5)
_ad()
_u()
if(_j==_b) _ae()
if(_j==_c or dget"39" >0) _ak() dset(39,0)
if(_j==_d)  _as()
if(_j==_e)  _a7()
if(_j==_f) _bo()
menuitem(1,"show credits",function() load"#undune2_credits" end)
menuitem(2,"level: ⬅️ " .._n.." ➡️",_m)
menuitem(3,"!start new game!",function()
for i=0,63 do
dset(i,nil)
end
dset(39,1)
run()
end)
end
function _m(b)
if(b&1>0) _n=max(_n-1,1)
if(b&2>0) _n=min(_n+1,9)
if(b&32>0) _as() return false
menuitem(2,"level: ⬅️ " .._n.." ➡️",_m)
return true
end
function _update60()
if _j==_b then
_af()
if _q() then
_as()
end
elseif _j==_c then
_al()
if _q() then
_o=_an
_as()
end
elseif _j==_d then
_aw()
elseif _j==_e then
_bk()
if _q() then
if _n<=9 then
_bo()
else
_as()
end
end
elseif _j==_f then
_b0()
if _q() then
_as()
end
end
t_+=1
end
function _draw()
if _df !=_p then
reload()
_dd(_df,0,0)
memcpy(0x0000,0x6000,0x2000)
_p=_df
cls()
end
if _j==_b then
_ah()
elseif _j==_c then
_am()
elseif _j==_d then
_az()
elseif _j==_f then
_b1()
elseif _j==_e then
_bl()
end
end
function _q(_r)
local _s=btnp"5" or (stat"34" >0 and not _t)
_t=stat"34" >0
return _s
end
function _u()
_o=dget(6)
_n=max(1, dget(0))
_l=dget(40)
if _l>0 then
if _l==3 then
_j=_d
else
_j=_e
end
_v=dget(2)
_w=flr(dget(41))
_x=dget(42)
_y=dget(43)
_z=dget(44)
_0=dget(45)
_1=dget(46)
_2=dget(47)
if _l < 3 then
music(10)
else
music(6)
end
else
music(0)
end
end
function _3(_4)
_5=_a[_o][1]
_6=_a[_o][2]
_7=_g[_o][_4]
_8=_7[8]
_9=_7[11]
_aa=_7[14]
dset(0, _4)
dset(1, _7[17])
_ab=_7[4]
dset(5, _ab)
dset(6, _o)
dset(7, _5)
dset(8, _6)
dset(9, _7[6])
dset(10,_7[7])
dset(11, _8)
dset(12, _8 and _a[_8][1] or nil)
dset(13, _8 and _a[_8][2] or nil)
dset(14, _7[9])
dset(15, _7[10])
dset(16, _9)
dset(17, _9 and _a[_9][1] or nil)
dset(18, _9 and _a[_9][2] or nil)
dset(19, _7[12])
dset(20, _7[13])
dset(21, _aa)
dset(22, _aa and _a[_aa][1] or nil)
dset(23, _aa and _a[_aa][2] or nil)
dset(24, _7[15])
dset(25, _7[16])
dset(26, _7[18])
dset(27, _7[19])
dset(28, _7[20])
dset(35, _7[2])
dset(36, _7[3])
dset(41, 0)
dset(42, 0)
dset(43, 0)
dset(44, 0)
dset(45, 0)
dset(46, 0)
dset(47, 0)
_ad()
local _ac="#undune2_map" .._4
load(_ac)
end
function _ad()
printh("--- cart data ---------")
for i=0,63 do
printh("[" ..i.."] " ..tostr(dget(i)))
end
end
function _ae()
_db(0)
_ag,cy=0.25,-96
end
function _af()
_set_fps(60)
if _ag>.0 then
_ag-=.1/128
cy+=.25
else
_ag=0
end
end
function _ah()
cls()
if _ag~=0 then
_cq(0,0,123,20,cy,_ag,1)
else
spr(0, 3,38, 15,3)
end
local start⧗=375
if t_>start⧗ then
local _ai="the demaking of a dynasty" _cr(_ai,12,62, (t_-start⧗)/5,3)
_cr(_ai,12,61, (t_-start⧗)/5)
_cr("v1.4",96,72, (t_-start⧗)/5,3)
_cr(" bY pAUL nICHOLAS  liquidream",4,104, (t_-start⧗)/5, 5)
_cr("♪cHRIS dONNELLY  gruber_music",4,112, (t_-start⧗)/5, 4)
_cr("\^.⁶	\r¹⁶\0\0\0",75,104, (t_-start⧗)/5, 5)
_cr("\^.⁶	\r¹⁶\0\0\0",71,112, (t_-start⧗)/5, 4)
_cr("(oRIGINAL BY wESTWOOD sTUDIOS)" .._i,4-max(t_/2-250), 120,(t_-start⧗)/5, 3)
end
if t_>start⧗+1 then
local _aj="❎ / \^.⁶	>.>\"\"、 TO " ..(_o>0 and"cONTINUE" or"sTART")
if(t_\60%2==0) _cx(_aj,52-(#_aj*2)/2,82,7,3)
end
end
function _ak()
_j=_c
_db(0)
_an=1
t_=0
end
function _al()
if((btnp(0) or (t_%5==0 and stat(38)<-10)) and _an>1) _an-=1
if((btnp(1) or (t_%5==0 and stat(38)>10)) and _an<3) _an+=1
t_+=1
end
function _am()
cls()
pal()
pal(10,139,1)
pal(14,140,1)
pal(15,130,1)
_c4("select your house",28,28, 9,2,7)
spr(48, 5,47,  4,4)
spr(52, 47,47, 4,4)
spr(56, 89,47, 4,4)
map(48,0, 1,45, 5,7)
map(48,0, 43,45, 5,7)
map(48,0, 85,45, 5,7)
_ao={"aTREIDES","  oRDOS","hARKONNEN" }
for i=0,2 do
local _ap=i*29+(i*5)
local _aq=i*8
rectfill(_ap+_aq,84,41+_ap+_aq,94,15)
rectfill(_ap+_aq+2,86,39+_ap+_aq,92,9)
rect(_ap+_aq,84,41+_ap+_aq,94,_an==i+1 and 7 or 0)
?_ao[i+1],4+_ap+_aq,87,1
end
local _ar=_a[_an]
_cx("press ❎ to select",30,108,_ar[1],1)
end
function _as()
_j=_d
_at=nil
_au=false
cls()
_db(max(2,_o+1))
music(_o==0 and 2 or 6)
printh("p_level=" ..tostr(_n))
_av()
end
function _av()
if(_l!=3) then
_l=0
_aj=_h[_o][_n+_ay]
else
_aj=_h[_o][11]
end
_ax=cocreate(_a5)
end
function _aw()
_set_fps(30)
if(_ax!=nil and costatus(_ax)!="dead") then
coresume(_ax)
else
_ax=nil
end
if _q() and _au then
if _o==0 then
_ay+=1
if _ay>6 then
_ay=0
_ak()
else
_av()
end
else
if _l==3 then
_l=0
if _n>1 then
_bo()
else
_as()
end
elseif _n<=9 then
_3(_n)
else
load"#undune2_credits" end
end
end
end
_ay=0
function _az()
cls()
_a0={[0]=0,-1,1,2,3,-1,0}
_a1(_o==0 and _a0[_ay] or 0)
if(_at) _a4()
_cx("pRESS ❎/\^.⁶	>.>\"\"、",80,120,7,10)
end
function _a1(_a2)
pal({[0]=0,1,3,4,5,6,9,13,15,128,129,132,10,140,142,143},1)
_a3(_a2)
rect(40,36,128,112,7)
palt(0,false)
if _o==0 then
palt(12, true)
spr(0, 0,40,  6,16)
elseif _o==1 then
palt(2, true)
spr(6, 0,40,  16,16)
else
palt(12, true)
spr(0, 0,40,  16,16)
end
end
function _a3(_a2)
dx=100
dy=75
srand(_a2)
clip(40,36,88,76)
for i=1,150 do
pset(rnd(128),rnd(128),rnd{1,13})
end
clip()
if _a2 > -1 then
c=(
{[0]={0,9,11,14,15,8,8,8},
{0,10,1,13,2,15},
{0,10,1,7,5,15,15},
{0,9,2,15,6,6,6}
})[_a2]
p=({
[0]={[0]=0,1,3,4,5,6,9,13,15,128,129,132,10,140,142,143},{[0]=0,1,3,4,5,6,12,13,15,128,129,132,10,140,142,139},{[0]=0,1,8,4,5,6,139,13,15,128,129,132,10,140,142,7},{[0]=0,1,2,4,5,6,8,13,15,128,129,132,10,140,142,136}
})[_a2]
g=({[0]=.5,.65,0.75,.5})[_a2]
pal(p,1)
u=cos(.5)
v=sin(.4)
circfill(dx-1,dy-1,22,10)
circfill(dx-1,dy-1,21,13)
circfill(dx-1,dy-1,20,10)
for x=-1,.95,.05 do
for y=-1,.95,.05 do
h=x*x+y*y
z=(1-h)^.5
r=x*u+y*v+g+2*((x+y)%.1)
r=max(min(1,z*r))
r=(c)[flr(r*(#c-1))+1]
if(h<1)pset(dx+x*20,dy+y*20,r)
end
end
end
end
function _a4()
?_at,2,5,11
?_at,2,4,6
end
function _a5()
local _a6=split(_aj,":")
for j=1,#_a6 do
_aj=_a6[j]
for i=1,#_aj,0.5 do
_at=sub(_aj,1,i)
if(_q("s")) break
yield()
end
yield()
_at=_aj
_au=(j==#_a6)
while not (_q() or _au) do yield() end
_update_buttons()
end
end
function _a7()
_db(1)
pal()
pal(3, 137, 1)
_5=_a[_o][1]
_6=_a[_o][2]
local _a8=flr(_w / 3600 )
_w=_w - _a8 * 3600
local _a9=flr(_w / 60)
_w=_a8.."H " .._a9.."M"
_v +=_z-_0 + _1-_2 + _x\100
_ba=_bb()
dset(2, _v)
_n +=1
printh("p_level now set to = " .._n)
dset(0, _n)
dset(40, 0)
local _bc=max(_x,_y)
local _bd=max(_z,_0)
local _be=max(_1,_2)
_bf={
{ 0, _x, 62, _5, 60, _bc },{ 0, _y, 68, 6, 60, _bc },{ 0, _z, 85, _5, 40, _bd },{ 0, _0, 91, 6, 40, _bd },{ 0, _1, 107, _5, 20, _be},{ 0, _2, 113, 6, 20, _be }
}
_bg=1
_bh=100
end
function _bb()
_bi=split"25,sAND sNAKE,50,dESERT mONGOOSE,100,sAND wARRIOR,150,dUNE tROOPER,200,sQUAD lEADER,400,oUTPOST cOMMANDER,500,bASE cOMMANDER,700,wARLORD,1000,cHIEF wARLORD,1400,rULER OF aRRAKIS,18000,eMPEROR" _bj="sAND fLEA" for i=1,#_bi,2 do
if _v>=_bi[i] then
_bj=_bi[i+1]
end
end
return _bj
end
function _bk()
if _bh > 0 then
_bh-=1
return
end
if _bg <=#_bf then
_bf[_bg][1] +=(_bf[_bg][6]/_bf[_bg][5])/3
if _bf[_bg][1] >=_bf[_bg][2] then
_bf[_bg][1]=_bf[_bg][2]
_bg+=1
_bh=50
end
end
end
function _bl()
cls()
palt(0,false)
pal(14, 137, 1)
pal(6, 14, 1)
map()
map(17,1,8,2,14,6)
local _bm=3+(3*_o)
spr(_bm,1,22,3,3)
spr(_bm,103,22,3,3)
_c2("sCORE:" .._v,16,7,7)
_c2("tIME:" .._w,70,7)
_c2("yOU'VE ATTAINED\n  THE RANK OF",36,24)
_c2(_ba,65-#_ba*2,37,8)
rect(8,56,120,75,4)
line(26,56,100,56,9)
_c2("SPICE HARVESTED BY",28,53)
_c2("  YOU:\nENEMY:",11,61)
_bn={0,0}
for i=1,2 do
_bn[i]=_bf[i][1]>>16
for j=1,3 do
_bn[i]+=_bf[i][1]>>16
end
end
_c2(tostr(_bn[1],0x2).."\n" ..tostr(_bn[2],0x2),100,61)
rect(8,79,120,98,4)
line(26,79,100,79,9)
_c2("UNITS DESTROYED BY",28,76)
_c2("  YOU:\nENEMY:",11,84)
_c2(flr(_bf[3][1]).."\n" ..flr(_bf[4][1]),100,84)
rect(8,102,120,120,4)
line(18,102,108,102,9)
_c2("BUILDINGS DESTROYED BY",20,99)
_c2("  YOU:\nENEMY:",11,106)
_c2(flr(_bf[5][1]).."\n" ..flr(_bf[6][1]),100,106)
for i=1,#_bf do
_c6(
35,_bf[i][3],_bf[i][5],_bf[i][1],_bf[i][6],_bf[i][4])
end
if(_bg>6) _cx("pRESS ❎ / \^.⁶	>.>\"\"、",40,120,7,0)
end
function _bo()
_j=_f
_db(1)
music(12)
_bp=_b8(_da,",","\n")
_bq={
[-1]={6,5,13},
[0]={0,0,0},
{12,1,0},
{11,10,1},
{8,2,1,5,5},
{5,2,0}
}
_br=-1
_bs=0
_bt=1
_bu=2
_bv=3
_bw=4
_bx="" _by="" _bz=0
t_=0
_k=cocreate(_b2)
end
function _b0()
_set_fps(60)
if _k and costatus(_k)~="dead" then
assert(coresume(_k, _n))
end
end
function _b1()
end
function _b2(_b3)
printh("seqnum = " .._b3)
yield()
local _b4
local _b5
cls()
pal()
pal(1,6)
pal(2,5)
pal(3,13)
map(32,0,0,0)
spr(48,4,20,15,8)
local _bm=3+(3*_o)
spr(_bm,0,96,3,3)
spr(_bm,104,96,3,3)
pal()
palt(0,false)
pal(14, 137, 1)
pal(12, 140, 1)
pal(11, 139, 1)
pal(10, 3, 1)
pal(6, 143, 1)
pal(13, 134, 1)
if _n < 9 then
pal(5, 142, 1)
else
pal(5, 14, 1)
end
_cx("your next conquest",28,7,8,0)
_c4("your next conquest",28,7, 8,0,5)
if _b3 > 2 then
_ck(0, _bq[_bs])
end
if _o==1 then
if _b3==1 then
elseif _b3==2 then
_b7()
_c9(20)
_b6("tHREE hOUSES HAVE\nCOME TO dUNE.")
_b6("tHE LAND HAS\nBECOME DIVIDED.")
_ca(0,  _bq[_bs])
_b7()
_b6("aTREIDES CLAIMED\nSTRATEGIC REGIONS")
_ca({13,7,20,14,21,22}, _bq[_bt])
_b7()
_b6("oRDOS MOVED IN\nFROM THE EAST.")
_ca({19,27,26,25,24,23}, _bq[_bu])
_b7()
_b6("hARKONNEN INVADED\nFROM THE NORTH.")
_ca({6,5,4,10,3,9}, _bq[_bv])
_b4=23
_b5=_bq[_bu]
elseif _b3==3 then
_ck({13,7,20,14,21,22}, _bq[_bt])
_ck({19,27,26,25,24,23}, _bq[_bu])
_ck({6,5,4,10,3,9}, _bq[_bv])
_b6("aTREIDES CAPTURED\nMORE TERRITORY...")
_ca({8,15},  _bq[_bt])
_b6("...AND DROVE THE\noRDOS OUT.")
_ca({23}, _bq[_bt])
_b6("oRDOS HEADED\nFOR hARKONNEN.")
_ca({12,18,16,17}, _bq[_bu])
_b6("hARKONNEN EXPANDED\nTHEIR BORDERS.")
_ca({1,2,11}, _bq[_bv])
_b4=2
_b5=_bq[_bv]
elseif _b3==4 then
_ck({13,7,20,14,21,22,8,15,23}, _bq[_bt])
_ck({19,27,26,25,24,12,18,16,17}, _bq[_bu])
_ck({6,5,4,10,3,9,1,2,11}, _bq[_bv])
_b6("hARKONNEN BORDERS\nWERE WEAK...")
_ca({1,2,3}, _bq[_bt])
_ca({11}, _bq[_bu])
_b6("...EXCEPT FOR\nONE OUTPOST.")
_ca({16}, _bq[_bv])
_b4=9
_b5=_bq[_bv]
elseif _b3==5 then
_ck({13,7,20,14,21,22,8,15,23,1,2,3}, _bq[_bt])
_ck({19,27,26,25,24,12,18,17,11}, _bq[_bu])
_ck({6,5,4,10,9,16}, _bq[_bv])
_b6("hARKONNEN CONTINUED\nTO RETREAT.")
_ca({4,9,16}, _bq[_bt])
_b6("...INTO TERRITORY\nOF THE oRDOS.")
_ca({11}, _bq[_bv])
_b4=25
_b5=_bq[_bu]
elseif _b3==6 then
_ck({13,7,20,14,21,22,8,15,23,1,2,3,4,9,16}, _bq[_bt])
_ck({19,27,26,25,24,12,18,17}, _bq[_bu])
_ck({6,5,10,11}, _bq[_bv])
_b6("aLL FORCES WERE\nAIMED AT oRDOS.")
_ca({17,25,24}, _bq[_bt])
_ca({18}, _bq[_bv])
_b4=11
_b5=_bq[_bv]
elseif _b3==7 then
_ck({13,7,20,14,21,22,8,15,23,1,2,3,4,9,16,17,25,24}, _bq[_bt])
_ck({19,27,26,12}, _bq[_bu])
_ck({6,5,10,11,18}, _bq[_bv])
_b6("aTREIDES PUSHED\nhARKONNEN BACK.")
_ca({10,11,18}, _bq[_bt])
_b4=26
_b5=_bq[_bu]
elseif _b3==8 then
_ck({13,7,20,14,21,22,8,15,23,1,2,3,4,9,16,17,25,24,10,11,18}, _bq[_bt])
_ck({19,27,26,12}, _bq[_bu])
_ck({6,5}, _bq[_bv])
_b6("oRDOS WERE NEARLY\nWIPED OUT.")
_ca({26,27,19}, _bq[_bt])
_b4=5
_b5=_bq[_bv]
elseif _b3==9 then
_ck({13,7,20,14,21,22,8,15,23,1,2,3,4,9,16,17,25,24,10,11,18,26,27,19}, _bq[_bt])
_ck({12}, _bq[_bu])
_ck({6,5}, _bq[_bv])
_b6("oNLY THE eMPEROR'S\nFORCES REMAIN.")
_ca({5,12}, _bq[_bt])
_ca({6}, _bq[_bw])
_b4=6
_b5=_bq[_bw]
end
elseif _o==2 then
if _b3==1 then
elseif _b3==2 then
_b7()
_c9(20)
_b6("tHREE hOUSES HAVE\nCOME TO dUNE.")
_b6("tHE LAND HAS\nBECOME DIVIDED.")
_ca(0,  _bq[_bs])
_b7()
_b6("oRDOS TOOK THE\nBEST LAND")
_ca({19,27,26,25,24,23}, _bq[_bu])
_b7()
_b6("hARKONNEN ARE\nA THREAT.")
_ca({6,5,4,10,3,9}, _bq[_bv])
_b7()
_b6("hOUSE aTREIDES\nIS NEARBY.")
_ca({13,7,20,14,21,22}, _bq[_bt])
_b4=16
_b5=_bq[_br]
elseif _b3==3 then
_ck({19,27,26,25,24,23}, _bq[_bu])
_ck({6,5,4,10,3,9}, _bq[_bv])
_ck({13,7,20,14,21,22}, _bq[_bt])
_b6("oRDOS ADVANCED\nWITHOUT CHALLENGE.")
_ca({15,16,17},  _bq[_bu])
_b6("tHE hARKONNEN\nDREW CLOSER.")
_ca({11,12,18}, _bq[_bv])
_b6("tHE aTREIDES\nSPREAD TOO THIN.")
_ca({1,2,8}, _bq[_bt])
_b4=14
_b5=_bq[_bt]
elseif _b3==4 then
_ck({19,27,26,25,24,23,15,16,17}, _bq[_bu])
_ck({6,5,4,10,3,9,11,12,18}, _bq[_bv])
_ck({13,7,20,14,21,22,1,2,8}, _bq[_bt])
_b6("aLL ATTACKS WERE\nAIMED AT aTREIDES.")
_ca({8,14,22}, _bq[_bu])
_ca({2}, _bq[_bv])
_b4=13
_b5=_bq[_bt]
elseif _b3==5 then
_ck({19,27,26,25,24,23,15,16,17,8,14,22}, _bq[_bu])
_ck({6,5,4,10,3,9,11,12,18,2}, _bq[_bv])
_ck({13,7,20,21,1}, _bq[_bt])
_b6("oRDOS OVERPOWERED\nTHE aTREIDES...")
_ca({21,20,13}, _bq[_bu])
_b6("...WHILE THEY WERE\nFIGHTING hARKONNEN")
_ca({2,3}, _bq[_bt])
_b4=18
_b5=_bq[_bv]
elseif _b3==6 then
_ck({19,27,26,25,24,23,15,16,17,8,14,22,21,20,13}, _bq[_bu])
_ck({6,5,4,10,9,11,12,18}, _bq[_bv])
_ck({7,1,2,3}, _bq[_bt])
_b6("hARKONNEN HAD TO\nBE TURNED BACK.")
_ca({18,11,12}, _bq[_bu])
_b4=2
_b5=_bq[_bt]
elseif _b3==7 then
_ck({19,27,26,25,24,23,15,16,17,8,14,22,21,20,13,18,11,12}, _bq[_bu])
_ck({6,5,4,10,9}, _bq[_bv])
_ck({7,1,2,3}, _bq[_bt])
_b6("oRDOS KILLED OFF\nMOST OF aTREIDES")
_ca({7,1,2}, _bq[_bu])
_b4=6
_b5=_bq[_bv]
elseif _b3==8 then
_ck({19,27,26,25,24,23,15,16,17,8,14,22,21,20,13,18,11,12,7,1,2}, _bq[_bu])
_ck({6,5,4,10,9}, _bq[_bv])
_ck({3}, _bq[_bt])
_b6("oRDOS GAINED MORE\nhARKONNEN LAND.")
_ca({6,5,10}, _bq[_bu])
_b4=3
_b5=_bq[_bt]
elseif _b3==9 then
_ck({19,27,26,25,24,23,15,16,17,8,14,22,21,20,13,18,11,12,7,1,2,6,5,10}, _bq[_bu])
_ck({4,9}, _bq[_bv])
_ck({3}, _bq[_bt])
_b6("sOON oRDOS WILL\nRULE ALL OF dUNE.")
_ca({3,9}, _bq[_bu])
_ca({4}, _bq[_bw])
_b4=4
_b5=_bq[_bw]
end
elseif _o==3 then
if _b3==1 then
elseif _b3==2 then
_b7()
_c9(20)
_b6("tHREE hOUSES HAVE\nCOME TO dUNE.")
_b6("tHE LAND HAS\nBECOME DIVIDED.")
_ca(0,  _bq[_bs])
_b7()
_b6("hARKONNEN ARRIVED\nFIRST.")
_ca({6,5,4,10,3,9}, _bq[_bv])
_b7()
_b6("tHE WEAK aTREIDES\nWILL BE EASY.")
_ca({13,7,20,14,21,22}, _bq[_bt])
_b7()
_b6("tHE oRDOS ARE\nGETTING CLOSER.")
_ca({19,27,26,25,24,23}, _bq[_bu])
_b4=2
_b5=_bq[_br]
elseif _b3==3 then
_ck({6,5,4,10,3,9}, _bq[_bv])
_ck({13,7,20,14,21,22}, _bq[_bt])
_ck({19,27,26,25,24,23}, _bq[_bu])
_b6("hARKONNEN SPREAD\nOUT STRONG FORCES.")
_ca({2,1,8},  _bq[_bv])
_b6("aTREIDES WENT\nAFTER oRDOS.")
_ca({15,16,23}, _bq[_bt])
_b6("oRDOS STOLE EVEN\nMORE LAND.")
_ca({17,11,18,12}, _bq[_bu])
_b4=11
_b5=_bq[_bu]
elseif _b3==4 then
_ck({6,5,4,10,3,9,2,1,8}, _bq[_bv])
_ck({13,7,20,14,21,22,15,16,23}, _bq[_bt])
_ck({19,27,26,25,24,17,11,18,12}, _bq[_bu])
_b6("oRDOS DID NOT\nSTAND A CHANCE.")
_ca({17,11,12}, _bq[_bv])
_b6("aTREIDES AND oRDOS\nTRADED LAND.")
_ca({24}, _bq[_bt])
_ca({16}, _bq[_bu])
_b4=18
_b5=_bq[_bu]
elseif _b3==5 then
_ck({6,5,4,10,3,9,2,1,8,17,11,12}, _bq[_bv])
_ck({13,7,20,14,21,22,15,23,24}, _bq[_bt])
_ck({19,27,26,25,18,16}, _bq[_bu])
_ca(25,  _bq[_bv])
_b6("aN oRDOS OUTPOST\nWAS SURROUNDED.")
_ca({18,19},  _bq[_bv])
_b6("tHE oRDOS BROKE\nTHROUGH aTREIDES.")
_ca(24, _bq[_bu])
_b4=7
_b5=_bq[_bt]
elseif _b3==6 then
_ck({6,5,4,10,3,9,2,1,8,17,11,12,25,18,19}, _bq[_bv])
_ck({13,7,20,14,21,22,15,23}, _bq[_bt])
_ck({27,26,16,24}, _bq[_bu])
_b6("sOON tHE aTREIDES\nWILL BE EXTINCT.")
_ca({7,14,13}, _bq[_bv])
_ca({23}, _bq[_bu])
_b4=26
_b5=_bq[_bu]
elseif _b3==7 then
_ck({6,5,4,10,3,9,2,1,8,17,11,12,25,18,19,7,14,13}, _bq[_bv])
_ck({20,21,22,15}, _bq[_bt])
_ck({27,26,16,24,23}, _bq[_bu])
_b6("hARKONNEN CRUSHED\nMOST OF THE oRDOS.")
_ca({24,26,27},  _bq[_bv])
_b6("aTREIDES RECLAIMED\nITS LAND.")
_ca(23, _bq[_bt])
_b4=21
_b5=_bq[_bt]
elseif _b3==8 then
_ck({6,5,4,10,3,9,2,1,8,17,11,12,25,18,19,7,14,13,24,26,27}, _bq[_bv])
_ck({20,21,22,15,23}, _bq[_bt])
_ck({16}, _bq[_bu])
_b6("hARKONNEN CRUSHED\nTHE aTREIDES.")
_ca({20,21,22},  _bq[_bv])
_b4=16
_b5=_bq[_bu]
elseif _b3==9 then
_ck({6,5,4,10,3,9,2,1,8,17,11,12,25,18,19,7,14,13,24,26,27,20,21,22}, _bq[_bv])
_ck({15,23}, _bq[_bt])
_ck({16}, _bq[_bu])
_b6("oNLY THE hARKONNEN\nWILL PREVAIL.")
_ca({16,23},  _bq[_bv])
_ca({15},  _bq[_bw])
_b4=15
_b5=_bq[_bw]
end
end
_b6(" ❎/\^.⁶	>.>\"\"、 tO sTART")
while true do
_ck(_b4, _bq[_o])
_c9(20)
_ck(_b4, _b5)
_c9(20)
end
end
function _b6(_aj)
_by=_bx
_bx=_aj
_bz=80
clip(27,99,75,18)
for i=1,85 do
_b7()
?_bx,29,_bz,0
?_by,29,_bz+22,0
yield()
if(i<46) _bz+=.5
end
clip()
end
function _b7()
rectfill(27,99,101,116,9)
end
function _b8(_b9,d,dd)
d=d or","
if(dd) _b9=split(_b9,dd)
if type(_b9)=="table" then
local t={}
while #_b9>0 do
local s=_b9[1]
add(t,split(s,d))
del(_b9,s)
end
return t
else
return split(_b9,d)
end
end
function _ca(_cb, _cc)
sx=0
sy=20
sw=119
sh=64
dx=4
dy=20
_cd=0
_ce=4
_cf=3
_4=0
_cg=0x3006
_ch=0x3fff
if type(_cb)=="table" then
_ci=_cb
else
_ci={_cb}
end
for _cb in all(_ci) do
for _x=0,127 do
for _y=0,127 do
_4+=1
if(_4==0x4000) then
_4=0
x,y=0,0
end
x,y=band(_ch,0x7f),flr(lshr(_ch,7))
_ch=bxor(flr(lshr(_ch,1)),band(-band(_ch,1),_cg))
if x>=sx and x<=sx+sw
and y>=sy and y<=sy+sh
then
if not _cb or _bp[y-sy+1][x-sx+1]==_cb
then
local _cj=sget(x+_cd,y+_ce)
pset(dx-sx+x,dy-sy+y, _cc[_cj])
end
end
end
if(_x%_cf==0)yield()
end
end
end
function _ck(_cb, _cc)
sx=0
sy=20
sw=119
sh=64
dx=4
dy=20
_cd=0
_ce=4
_ci=nil
if type(_cb)=="table" then
_ci={}
for k in all(_cb) do
_ci[k]=k
end
end
for x=0,127 do
for y=0,127 do
if x>=sx and x<=sx+sw
and y>=sy and y<=sy+sh
then
if not _cb
or (_ci and _ci[_bp[y-sy+1][x-sx+1]])
or _bp[y-sy+1][x-sx+1]==_cb
then
local _cj=sget(x+_cd,y+_ce)
pset(dx-sx+x,dy-sy+y, _cc[_cj])
end
end
end
end
end
function _cl(a,b)
return a[1]*b[1]+a[2]*b[2]
end
function _cm(a,b)
return {b[1]-a[1],b[2]-a[2]}
end
function _cn(a)
local x,z=a[1],a[2]
local d=sqrt(x*x+z*z)
return {
x/d,z/d
},d
end
function _co(a,b,_cp)
_cp=_cp or 1
return {
a[1]+_cp*b[1],a[2]+_cp*b[2]}
end
function _cq(sx,sy,sw,sh,y,_ag,_cp)
local c={0,sw}
local v={sin(_ag),-cos(_ag)}
local u={-v[2],v[1]}
for i=0,127 do
local n,d=_cn(_cm(c,{i-63.5,0}))
local t0=(-_cl(c,v))/_cl(n,v)
if t0>0 then
local x=_co(c,n,t0)
local t1=_cl(x,u)/(_cp*sw)+0.5
if t1>=0 and t1<1 then
local w=_cp*d/t0
local y0=63.5-(sh/2-y)*w
sspr(sx+sw*t1,sy,1,sh,i,y0,1,sh*w+y0%1)
end
end
end
end
_cv={0,128,130,2,136,8}
pal(_cv,1)
function _cr(_cs, x, y, _ct, _cu)
local _cw=mid(0,flr(_ct),_cu or #_cv)
print(_cs, x, y, _cw)
end
function _cx(_b9,_cy,_cz,_c0,_c1)
for xx=-1, 1 do
for yy=-1, 1 do
print(_b9, _cy+xx, _cz+yy, _c1)
end
end
print(_b9,_cy,_cz,_c0)
end
function _c2(_b9,x,y,_c0,_c3)
print(_b9, x, y+1, _c3 or 2)
print(_b9, x, y,    _c0 or 7)
end
function _c4(_b9,x,y,_c0,_c3,_c5)
_c2(_b9,x,y,_c0,_c3)
clip(x,y+1,#_b9*4,3)
print(_b9,x,y,_c5)
clip()
end
function _c6(x,y,_c7,_s,_c8,_c0)
if(_s <=0) return
local w=mid(0,_s/_c8*_c7,_c7)
rectfill(x+1,y+1,x+w+1,y+4,2)
rectfill(x,y,x+w,y+3,_c0)
end
function _c9(_4)
for i=1,_4 do
yield()
end
end
local _r=tostr(stat"102")
if(_t!="\48" and _t!="" and _t!=nil and _t!="\119\119\119\46\108\101\120\97\108\111\102\102\108\101\46\99\111\109") stop()
_da=[[
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,0,5,5,5,5,5,5,5,5,5,5,0,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,0,5,5,5,5,5,5,5,5,5,5,5,5,0,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,7,7,7,0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,5,5,5,5,5,5,5,5,5,5,5,5,5,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,5,5,5,5,5,5,5,5,5,5,5,5,5,0,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,5,5,5,5,5,5,5,5,5,5,5,5,5,5,0,6,6,6,6,0,0,0,0,6,6,6,6,6,6,6
1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,0,0,0,4,4,0,5,5,5,5,5,5,5,5,5,5,5,5,5,5,0,6,6,0,0,0,12,12,0,0,0,6,6,6,6,6
0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,0,0,0,0,10,10,0,0,0,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,12,12,12,12,12,12,0,6,6,6,6,6
7,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,4,0,0,0,10,10,10,10,10,10,10,0,11,0,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,0,0,12,12,12,12,12,12,12,12,0,6,6,6,6
7,7,7,7,0,0,1,1,1,1,1,1,1,1,1,1,0,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,0,0,10,10,10,10,10,10,10,10,10,0,11,0,0,5,5,5,5,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,0,0,6,6,6
7,7,7,7,7,7,0,0,1,1,1,1,1,1,1,1,0,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,0,10,10,10,10,10,10,10,10,10,0,11,11,11,0,0,5,5,5,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,0,6,6
7,7,7,7,7,7,7,7,0,0,1,1,1,1,1,0,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,0,0,10,10,10,10,10,10,10,10,10,0,11,11,11,11,0,5,5,5,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,0,0
7,7,7,7,7,7,7,7,7,7,0,0,0,0,0,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,0,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,0,0,5,5,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,0,0,10,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,0,5,5,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,0,10,10,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,0,0,5,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,0,0,10,10,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,11,0,5,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,4,4,4,4,4,4,4,4,4,4,4,4,0,0,10,10,10,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,11,0,5,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,0,0,0,0,0,0,0,0,0,4,4,0,0,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,11,0,0,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,0,9,9,9,9,9,9,9,9,0,0,0,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,0,0,11,11,11,11,11,0,5,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,3,3,3,3,3,3,3,3,0,9,9,9,9,9,9,9,9,9,9,9,0,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,11,0,5,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12
7,7,7,0,0,0,0,0,0,0,0,7,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,8,8,8,8,8,8,8,8,0,0,0,3,3,3,3,3,0,9,9,9,9,9,9,9,9,9,9,9,9,9,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,11,11,0,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12
7,0,0,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,8,8,8,8,8,8,8,8,8,8,8,8,8,0,0,3,3,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,11,11,0,5,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12
0,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,7,7,0,2,2,2,2,2,2,2,0,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,0,3,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0,0,0,10,10,10,10,10,10,10,10,10,10,10,10,0,0,11,11,11,11,11,11,0,5,5,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12
13,13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,7,0,0,0,2,2,2,0,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,16,16,0,0,0,0,10,10,10,10,10,10,10,10,10,10,0,11,11,11,11,11,11,11,0,5,5,5,5,5,0,12,12,12,12,12,12,12,12,12,12,0,0,0,0,12,12
13,13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,7,7,0,0,0,0,0,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,16,16,16,0,17,17,0,0,0,0,0,0,10,10,10,10,10,0,11,11,11,11,11,11,11,11,0,5,5,5,5,0,12,12,12,12,12,12,12,12,0,0,19,19,19,19,0,0
13,13,13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,7,0,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,0,17,17,17,17,17,17,17,0,0,0,0,0,0,11,11,11,11,11,11,11,11,11,11,0,0,0,0,0,0,12,12,12,12,12,0,0,19,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,0,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,16,16,16,0,0,17,17,17,17,17,17,17,17,17,17,17,17,17,0,11,11,11,11,11,11,11,11,11,11,0,18,18,18,0,0,0,0,0,0,19,19,19,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,0,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,0,17,17,17,17,17,17,17,17,17,17,17,17,17,17,0,0,11,11,11,11,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,0,0,19,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,0,14,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,0,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,0,11,11,11,11,11,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,0,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,0,14,14,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,0,17,17,17,17,17,17,17,17,17,17,17,17,17,17,17,0,0,11,11,11,11,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,0,14,14,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,0,0,0,17,17,17,17,17,17,17,17,17,17,17,17,17,17,0,11,11,11,11,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,0,14,14,14,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,16,16,0,0,0,17,17,17,17,17,17,17,17,17,17,17,17,0,11,11,11,11,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,7,7,0,14,14,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,16,16,16,16,0,0,17,17,17,17,17,17,17,17,17,17,17,0,11,11,11,11,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,7,7,0,14,14,14,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,16,16,16,16,0,17,17,17,17,17,17,17,17,17,17,17,0,0,11,11,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,0,7,7,7,7,7,7,7,7,7,7,0,14,14,14,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,16,16,16,16,0,0,17,17,17,17,17,17,17,17,17,17,17,0,11,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,13,0,0,0,7,7,7,7,7,7,7,0,14,14,14,14,14,14,14,14,14,14,0,0,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,16,16,16,16,16,16,16,16,16,0,17,17,17,17,17,17,17,17,17,17,17,0,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,13,0,14,14,14,0,0,7,7,7,0,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,9,0,0,0,9,9,9,9,9,9,9,0,16,16,16,16,16,16,16,16,0,0,17,17,17,17,17,17,17,17,17,17,17,0,11,11,11,11,11,0,18,18,18,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,0,14,14,14,14,14,14,0,0,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,9,9,9,9,9,0,16,16,16,0,0,9,9,9,9,0,16,16,16,16,16,16,16,16,16,0,17,17,17,17,17,17,17,17,17,17,17,17,0,11,11,11,11,0,18,18,18,18,18,18,18,18,18,18,18,18,18,0,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,0,8,8,8,8,8,8,8,8,8,8,0,0,0,9,9,9,9,0,16,16,16,16,16,16,0,0,0,0,16,16,16,16,16,16,16,16,16,16,0,17,17,17,17,17,17,17,17,17,17,17,17,0,0,0,11,11,0,18,18,18,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,0,0,0,8,8,8,8,0,0,15,15,15,0,0,0,0,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,0,17,17,17,17,17,17,17,17,17,17,0,0,25,25,0,0,0,18,18,18,18,18,18,18,18,18,18,18,18,18,0,0,19,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,0,0,15,15,15,15,0,0,0,0,15,15,15,15,15,15,15,15,15,0,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,25,0,0,0,17,17,17,17,17,0,0,0,25,25,25,25,0,18,18,18,18,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,0,25,25,25,0,0,0,0,0,0,0,25,25,25,25,25,25,0,18,18,18,18,18,18,18,18,18,18,18,18,18,18,0,19,19,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,18,18,18,18,18,18,18,18,18,18,18,0,0,0,0,0,0,19,19,19,19,19,19,19
13,13,13,13,13,13,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,18,18,18,18,18,18,18,18,0,0,27,27,27,27,27,27,0,19,19,19,19,19,19
0,0,13,13,13,13,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,18,18,18,18,18,18,18,0,27,27,27,27,27,27,27,27,0,19,19,19,19,19,19
20,20,0,0,13,13,13,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,0,0,14,14,14,14,14,14,14,14,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,18,18,18,18,18,18,18,0,27,27,27,27,27,27,27,27,27,0,19,19,19,19,19
20,20,20,20,0,0,13,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,14,14,0,22,22,22,0,0,14,14,14,14,14,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,18,18,18,18,18,0,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19,19
20,20,20,20,20,20,0,0,13,13,0,14,14,14,14,14,14,14,14,14,14,14,14,0,22,22,22,22,22,22,0,0,14,14,14,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,0,18,18,0,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19,19
20,20,20,20,20,20,20,20,0,0,0,14,14,14,14,14,14,0,0,0,0,0,14,0,22,22,22,22,22,22,22,22,0,14,14,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,16,16,16,16,16,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,0,27,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19
20,20,20,20,20,20,20,20,20,20,20,0,0,0,14,14,14,0,21,21,21,21,0,0,22,22,22,22,22,22,22,22,22,0,14,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,16,16,0,0,0,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19
20,20,20,20,20,20,20,20,20,20,20,20,20,20,0,0,0,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,0,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,16,16,16,16,16,16,16,16,16,0,0,24,24,24,24,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19
20,20,20,20,20,20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,0,0,16,16,16,16,16,16,16,0,24,24,24,24,24,24,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19
20,20,20,20,20,20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,0,16,16,16,16,16,0,24,24,24,24,24,24,24,24,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19
20,20,20,20,20,20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,0,0,16,16,0,24,24,24,24,24,24,24,24,24,24,0,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19
20,20,20,20,20,20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,0,16,0,24,24,24,24,24,24,24,24,24,24,0,25,25,25,25,25,25,0,0,0,0,0,0,0,0,25,25,25,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19,19
20,20,20,20,20,20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,22,22,0,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,23,0,24,24,24,24,24,24,24,24,24,24,24,24,0,0,0,0,0,0,26,26,26,26,26,26,26,26,0,0,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19,19
20,20,20,20,20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,22,22,22,0,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,23,23,23,0,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,0,26,26,26,26,26,26,26,26,26,26,0,0,27,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19,19,19
20,20,20,20,20,20,20,20,20,20,0,0,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,23,23,23,23,0,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,0,26,26,26,26,26,26,26,26,26,26,26,26,0,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19,19,19
20,20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,23,23,23,23,23,0,24,24,24,24,24,24,24,24,24,24,24,24,24,24,24,0,26,26,26,26,26,26,26,26,26,26,26,26,26,0,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,19,19,0
20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,0,22,0,0,0,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,23,23,23,23,23,0,24,24,24,24,24,24,24,24,24,24,24,24,24,24,0,0,26,26,26,26,26,26,26,26,26,26,26,26,26,0,27,27,27,27,27,27,27,27,27,27,27,27,0,19,19,19,0,27
20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,0,0,21,21,21,0,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,23,23,23,23,23,23,0,24,24,24,24,24,24,24,24,24,24,24,24,24,0,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,0,27,27,27,27,27,27,27,27,27,27,27,27,0,0,0,27,27
20,20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,0,24,24,24,24,24,24,24,24,24,24,24,24,0,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27
20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,0,24,24,24,24,24,24,24,24,24,24,0,0,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27
20,20,20,20,20,20,20,0,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,0,22,22,22,22,22,22,22,22,22,22,22,0,15,15,15,15,15,15,15,15,15,15,0,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,0,24,24,24,24,24,24,24,24,24,24,0,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,0,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27,27
]]
_df=-1
_p=-1
function _db(_dc)
_df=_dc
end
function _dd(_de,x,y)
local _dg=0x0000
for i=0,_de-1 do
_dg +=peek(_dg+0) + peek(_dg+1)*256 + 2
end
_dh(x,y,_dg+2,pget,pset)
end
function _dh(x0,y0,_di,_dj,_dk)
local function _dl(l, _s)
local v,i=l[1],1
while v!=_s do
i+=1
v,l[i]=l[i],v
end
l[1]=_s
end
local _do,_dp=0,0
function _dm(_dn)
if _dp<16 then
_do+=%_di>>>16-_dp
_dp+=16
_di+=2
end
local _s=_do<<32-_dn>>>16-_dn
_do=_do>>>_dn
_dp-=_dn
return _s
end
function _dq(n)
local _dn=0
repeat
_dn+=1
local vv=_dm(_dn)
n+=vv
until vv<(1<<_dn)-1
return n
end
local
w,h_1,eb,el,pr,x,y,_dr,_ds
=
_dq"1",_dq"0",_dq"1",{},{},0,0,0
for i=1,_dq"1" do
add(el,_dm(eb))
end
for y=y0,y0+h_1 do
for x=x0,x0+w-1 do
_dr-=1
if(_dr<1) then
_dr,_ds=_dq"1",not _ds
end
local a=y>y0 and _dj(x,y-1) or 0
local l=pr[a]
if not l then
l={}
for e in all(el) do
add(l,e)
end
pr[a]=l
end
local v=l[_ds and 1 or _dq"2" ]
_dl(l, v)
_dl(el, v)
_dk(x,y,v)
end
end
end