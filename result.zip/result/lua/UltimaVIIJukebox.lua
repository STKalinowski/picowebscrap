--ultima vii jukebox
--arranged by viggles

-----------------------
--globals and constants
-----------------------

--tics in a second
sec=30

--how many tics it takes to scroll
--from one song to another
scroll_time=0.25*sec

--list of songs
songs={
  { title="harpsichord",
    pattern=0,length=22*sec,
    sprite=0,
    dx=-3,dy=-2 },

  { title="xylophone",
    pattern=6,length=9*sec,
    sprite=8 },

  { title="panpipes",
    pattern=14,length=63*sec,
    sprite=70,spr_size=1 },

  { title="lute",
    pattern=8,length=11*sec,
    sprite=12 },

  { title="music box",
    pattern=19,length=40*sec,
    sprite=102,playing_sprite=100,spr_size=2,dx=-2,dy=-1},

  { title="harp",
    pattern=12,length=7*sec,
    sprite=64,dx=-2 },
}

--animation data for floating notes
--positions are negative: left/up from origin
--cycle is a color cycle row from sprite 7
note_sm=22
note_lg=23
notes_anim={
  { sprite=note_lg,
    delta={{10,12}, {3,2}, {2,1}, {1,2}, {3,3}, {1,1}, {2,1}, {2,3}},
    cycle=0,
  },

  { sprite=note_sm,
    delta={{ 5, 9}, {3,2}, {3,2}, {1,2}, {2,1}, {2,3}, {2,3}, {2,1}},
    cycle=1,
  },

  { sprite=note_lg,
    delta={{11, 4}, {1,1}, {2,1}, {1,4}, {3,1}, {3,0}, {2,3}, {1,2}},
    cycle=2,
  },

  { sprite=note_sm,
    delta={{ 7, 2}, {0,0}, {3,4}, {2,3}, {2,1}, {3,3}, {1,2}, {2,0}},
    cycle=3,
  },

  { sprite=note_lg,
    delta={{ 1, 8}, {3,2}, {1,2}, {1,1}, {3,3}, {2,1}, {2,3}, {3,3}},
    cycle=4,
  },

  { sprite=note_sm,
    delta={{-4, 6}, {3,2}, {3,2}, {1,2}, {2,3}, {2,1}, {2,1}, {3,2}},
    cycle=5,
  },
}

------------------------------
--lifecycle and event handling
------------------------------

function _init()
  --currently selected song index
  cur_idx=0
  cur_song=song_at(cur_idx)

  --scroll offset when switching songs
  scroll_offset=0

  --currently playing song
  playing_song=nil

  --tic time at which the
  --playing song will finish
  finish_tics=0
  start_tics=0

  --tics since start of program
  tics=0

  --button-down bits from previous frame
  oldbtn=btn()

  --default palette in use
  custom_pal=0

  --start playing the intro at startup
  intro_playing=true
end

function _update()
  --advance timer
  tics+=1

  if intro_playing then
    update_intro()
  end

  --x: play/restart selected song
  if btnup(4) then
    if is_playing(cur_song) then
      stop()
    else
      play(cur_song)
    end
  end

  --scroll when switching songs
  if scroll_offset!=0 then
    local delta=1/scroll_time
    if abs(scroll_offset)<delta then
      scroll_offset=0
    elseif scroll_offset>0 then
      scroll_offset-=delta
    else
      scroll_offset+=delta
    end
  else
    --if not scrolling, then allow
    --left/right to switch songs
    if (btnp(0)) select_song(cur_idx-1)
    if (btnp(1)) select_song(cur_idx+1)
  end
  --record button states
  oldbtn=btn()
end

--animates elements fading in at start
function update_intro()
  --timings for intro animation
  local switch=0.1*sec
  local spot_start=0.75*sec
  local spot_end=1.25*sec

  local title_start=2.25*sec
  local title_end=3.0*sec

  local prompt_start=3.5*sec
  local prompt_end=4.25*sec

  local intro_end=prompt_end

  if tics>intro_end then
    intro_playing=false
    return
  end

  --play spotlight switch-on sound
  if tics==flr(switch) then
    sfx(63)
  end

  --calculate progress for elements
  --revealing themselves
  spot_progress=progress(tics,spot_start,spot_end)
  title_progress=progress(tics,title_start,title_end)
  prompt_progress=progress(tics,prompt_start,prompt_end)
  caption_progress=prompt_progress
end

--whether the specified button
--was lifted on this frame
function btnup(button,player)
  player=player or 0
  local mask=shl(1,button+(player*6))
  local wasdown=band(oldbtn,mask)!=0
  local isdown=btn(button,player)
  return wasdown and not isdown
end

---------
--drawing
---------

function _draw()
  cls()
  reset_pal()

  --center of spotlight
  local spotx,spoty=64,64
  --spacing from one instrument to the next
  local spacing=48
  --scroll offset of instruments and floor
  local scroll=flr(scroll_offset*spacing)
  --visibility of spotlight and instruments
  local light_level

  --flicker spotlight while it is still fading in
  if spot_progress>0 and 
     (spot_progress>=1 or tics%4==0) then
    light_level=1
  else
    light_level=0.5
  end

  --draw spotlight in center,
  --covered by floor
  if light_level==1 then
    --inner and outer radius of spotlight
    local outer,inner=29,24
    draw_spot(spotx,spoty,outer,inner,1)
    draw_floor(
      spotx-outer,spoty-outer,
      spotx+outer,spoty+outer,
      scroll)
  end

  --draw row of instruments
  --centered in spotlight
  draw_instruments(spotx,spoty,spacing,scroll,light_level)

  --draw screen title
  if title_progress>0 then
    --fade in title
    if title_progress<1 then
      fade_pal(title_progress)
    end
    draw_caption(64,16)
  end

  --draw song name
  if caption_progress>0 then
    --fade in prompt
    if caption_progress<1 then
      fade_pal(caption_progress)
    end

    --draw title of selected song
    local title_x=centered(cur_song.title,64)
    local title_y=100

    text_shadowed(cur_song.title,
      title_x,title_y,
      9,4)
  end

  --draw control prompts
  if prompt_progress>0 then
    --fade in prompt
    if prompt_progress<1 then
      fade_pal(prompt_progress)
    end

    draw_prompt(64,112)
  end

  --if a song is playing, draw notes anim
  if playing_song != nil then
    local song_tics=tics-start_tics

    frame=flr(song_tics/3)+1

    draw_notes(64,64,frame)
  end
end


--draw dithered spotlight
function draw_spot(x,y,rad,inner_rad,col)
  --draw outer spot
  circfill(x,y,rad,col)

  --dither outer spot with black
  for dy=-rad,rad do
    for dx=-rad,rad do
      if (dx+dy)%2>0 then
        pset(x+dx,y+dy,0)
      end
    end
  end

  --draw inner spotlight
  circfill(x,y,inner_rad,col)
end

--draw spaced row of instruments
--centered on specified location,
--with additional scroll offset.
--light_level affects overall
--brightness of instruments.
function draw_instruments(centerx,y,spacing,scroll,light_level)
  --distance from center
  --beyond which instruments
  --are completely dark
  local max_distance=spacing*1.5

  --potentially visible songs,
  --as offsets from current
  --song index
  local song_offsets={-2,-1,0,1,2}

  for offset in all(song_offsets) do
    local song=song_at(cur_idx+offset)

    local x=centerx+scroll+(spacing*offset)
    local distance=abs(centerx-x)

    --fade instrument based on
    --distance from center
    local falloff=distance/max_distance
    local fade=lerp(
      light_level,
      light_level*0.2,
      falloff)

    fade_pal(fade)
    draw_instrument(song,x,y)
  end

  --restore palette after light effects
  reset_pal()
end

--draw song's instrument sprite
--centered on location
function draw_instrument(song,x,y)
  local size=song.spr_size or 4
  local sprx=x-(size*4)+(song.dx or 0)
  local spry=y-(size*4)+(song.dy or 0)

  local sprite=song.sprite
  if is_playing(song) and song.playing_sprite!=nil then
    sprite=song.playing_sprite
  end
  spr(sprite,sprx,spry,size,size)
end

--draw silhouetted floor texture
--to cover region, a la rectfill
function draw_floor(x0,y0,x1,y1,offsetx)
  local sprw,sprh=2,2
  local tilew,tileh=sprw*8,sprh*8

  local startx=x0-(tilew-(offsetx%tilew))

  for y=y0,y1,tileh do
    for x=startx,x1,tilew do
      spr(38,x,y,sprw,sprh)
    end
  end
end

--draw control prompts centered on location
function draw_prompt(centerx,y)
  --colors for inactive/active states
  function statecol(isactive)
    if (isactive) return 6,5
    return 13,1
  end

  --draw play/restart button prompt
  local prompt
  if is_playing(cur_song) then
    prompt="(z) to stop"
  else
    prompt="(z) to play"
  end

  local promptl,promptr=centered(prompt,centerx)

  --highlight while play is pressed
  local col,shadow=statecol(btn(4))
  text_shadowed(prompt,
    promptl,y,
    col,shadow)

  --left arrow
  local col,shadow=statecol(btn(0))
  glyph_shadowed(21,
    promptl-12,y,
    col,shadow)

  --right arrow
  local col,shadow=statecol(btn(1))
  glyph_shadowed(20,
    promptr+4,y,
    col,shadow)

end

--draw caption centered on location
function draw_caption(centerx,y)
  local caption="songs in the key of  "
  local key_spr=5

  local col=13
  local shadow=1

  local cap_start,cap_end=centered(caption,centerx)
  text_shadowed(caption,
  cap_start,y,col,shadow)

  --draw key glyph at last
  --char pos in caption,
  --tinted with caption color
  local key_x=cap_end-4

  glyph_shadowed(key_spr,
    key_x,y,col,shadow)

  --underline
  local underline_y=y+8

  line(cap_start,underline_y,cap_end,underline_y,col)
  line(cap_start,underline_y+1,cap_end,underline_y+1,shadow)
end


--draw notes animation at location
function draw_notes(x,y,frame)
  if (frame<=8) then
    reset_pal()

    --color cycle palettes are
    --stored in sprite 7
    local palx=56+(frame-1)
    local paly=0

    for note in all(notes_anim) do
      local dx=0
      local dy=0
      for i=1,frame do
        local delta=note.delta[i]
        --deltas are inverted so
        --positive goes left/up
        dx-=delta[1]
        dy-=delta[2]
      end

      local cycle=note.cycle
      local color=sget(palx,paly+cycle)
      remap_col(7,color)
      spr(note.sprite,x+dx,y+dy)
    end

    remap_col(7)
  end
end

--------------
--draw helpers
--------------

--restores default palette mappings
function reset_pal()
  pal()

  --black opaque
  palt(0,false)

  --pink transparent
  palt(14,true)

  custom_pal=0
end

--remaps from 1 color to another
--for draw operations
--behaves like pal() but respects
--any currently-loaded palette
--if to_col is omitted, resets
--from_col to its original value
--in the current palette
function remap_col(from_col,to_col)
  if (to_col==nil) to_col=from_col

  local final_col=mapped_col(to_col,custom_pal)
  pal(from_col,final_col)
end

--given a color index, returns
--what that color is mapped to
--in the specified palette
function mapped_col(col,pal_idx)
  if pal_idx==0 then
    return col
  else
    --custom palettes are located
    --in sprite #36
    local x=32+col
    local y=16+pal_idx
    return sget(x,y)
  end
end

--remaps draw calls to use
--specified palette index
--(0=normal, 1,2,3,4,5=fades)
--mode optional, remaps either
--draw (default) or display palette
--(as per pico-8's pal())
function load_pal(pal_idx,mode)
  if mode~=1 then
    --already using this palette, do nothing
    if (custom_pal==pal_idx) return
    custom_pal=pal_idx
  end

  for from_col=0,15 do
    local to_col=mapped_col(from_col,pal_idx)
    pal(from_col,to_col,mode)
  end
end

--fade palette based on progress ratio:
--1.0=full brightness, 0=full darkness
function fade_pal(ratio,mode)
  local palette=flr(lerp(5,0,ratio))
  load_pal(palette,mode)
end

--draw centered text
--with shadow
function text_shadowed(text,x,y,col,shadow_col)
  if shadow_col!=nil then
    print(text,x,y+1,shadow_col)
  end
  print(text,x,y,col)
end

--draw template glyph
--with shadow
function glyph_shadowed(sprite,x,y,col,shadow_col)
  remap_col(7, shadow_col)
  spr(sprite,x,y+1)

  remap_col(7, col)
  spr(sprite,x,y)

  remap_col(7)
end

--calculate start and end offsets
--for centered text
function centered(text,centerx)
  local width=#text*4
  local left=centerx-(width/2)
  local right=left+width
  return left,right
end


-------------
--custom font
-------------

glyphs={}
glyphs["a"]={128}
glyphs["c"]={129}
glyphs["d"]={130}
glyphs["e"]={131}
glyphs["f"]={132}
glyphs["g"]={133}
glyphs["h"]={134}
glyphs["i"]={135,4}
glyphs["k"]={136,7}
glyphs["l"]={137}
glyphs["n"]={138,7}
glyphs["o"]={139}
glyphs["p"]={140}
glyphs["r"]={141}
glyphs["s"]={142}
glyphs["t"]={143}
glyphs["u"]={144}
glyphs["v"]={145}
glyphs["w"]={146,7}
glyphs["x"]={147,7}
glyphs["y"]={148}
glyphs["z"]={149}

glyphs["("]={150,3}
glyphs[")"]={151,3}
glyphs["<"]={152,8}
glyphs[">"]={153,8}
glyphs["@"]={154,8}
glyphs[" "]={-1,4}

function centered_fnt(text,centerx)
  local width=width_fnt(text)
  local left=flr(centerx-(width/2))
  local right=left+width
  return left,right
end

function width_fnt(text)
  local width=0
  for i=1,#text do
    local char=sub(text,i,i)
    local sprite,charwidth=glyph_fnt(char)
    if (i>1)width+=1
    width+=charwidth
  end
  return width
end

function print_fnt(text,x,y,col,shadow)
  remap_col(0,shadow)
  remap_col(7,col)
  for i=1,#text do
    local char=sub(text,i,i)
    local sprite,charwidth=glyph_fnt(char)

    if (i>1)x+=1

    if sprite>-1 then
      spr(sprite,x,y,1,1)
    end

    x+=charwidth
  end
  remap_col(0)
  remap_col(7)
end

function glyph_fnt(char)
  local glyph=glyphs[char]
  return glyph[1],glyph[2] or 6
end


----------------
--song functions
----------------

--play specified song
function play(song)
  music(song.pattern,0)
  playing_song=song
  start_tics=tics
  finish_tics=tics+song.length
end

function stop()
  music(-1,200)
  playing_song=nil
  finish_tics=0
  start_tics=0
end

--whether a specified song is playing
--if song=nil, returns whether any
--song is playing
function is_playing(song)
  return tics<finish_tics and
    (song==nil or song==playing_song)
end

function select_song(idx)
  scroll_offset=idx-cur_idx

  idx=idx % #songs

  cur_idx=idx
  cur_song=song_at(idx)
end

function song_at(idx)
  idx=idx % #songs
  return songs[idx+1]
end

--------------
--misc helpers
--------------

--clamps a value to fall
--between two extremes.
function clamp(val,min_val,max_val)
   return min(
    max(val,min_val),
    max_val)
end

--interpolate between two values
function lerp(from,to,progress)
  return from+((to-from)*progress)
end

--progress of value between
--from and to.
--logical inverse of lerp.
function progress(value,from,to)
  local duration=to-from
  local remaining=to-value
  return 1-clamp(remaining/duration,0,1)
end

