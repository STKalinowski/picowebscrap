--scrapboy
--by bonevolt
cartdata"bonevolt_scrapboy"
poke(0x5f2e,1)
poke(0x5f5c,255)
power_messg={}
msg=split("charge: hold the shooting\nbutton to charge!\n\n\ndouble jump: jump then\njump again!,bomb: use your movement\nto throw bombs further!\n\n\narmor: this form is immune\nto spikes,jet: dash into enemies\nto defeat them!\n\n\nyou can dash in any\ndirection!,boomerang: throw it in\nany direction!\n\n\nhover jump: jump higher\nand floatier!,magnet: pull enemies and\nthrow them into other\nenemies!\n\nwall jump: the magnet\nsticks to walls!,autoaim laser: try to\nhit multiple enemies\nwith one shot!\n\njetpack: air jump for\nunlimited flight!")
-->8
function _init()
s,f_btn,title,stage,dt,collect,diff="アアアアアアア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0らアアム■\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ら]UmUUUわ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0]UUム゛¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\サ]\\サツツU\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0サツツわニ、\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0Ugサ゛}ff]\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0vvfムウわ¹\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0eUわニアUUわ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0Wわアウア]ᶜ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0]UU、るUコわ\0\0\0アアアム\0アア\0\0アア\0\0\0らアᶜらアᵉらアアアアᶜ\0\0\0V]わ\\イチᶜ\0\0オわアアモ\0\0らア\0\0\0\0アᶜ]UU,\\UUわ\0\0ア]UUわオUUᶜアUUᶜ\0ら\\Uわ]Uᶜ$\"\"\"\"る¹\0\0]UU\\わU\r\0\0l]UUわᵉ\0]Uᵉ\0\0らUわUUU\\\\UUわ\0らUサツツイpツツわUツツᶜ\0\\UmUサツ⁵JDDDD\"、\0\0]UUUわコ⁵\0ら}ツツツ]ム\0サツム\0\0\\ツU]UU\\\\Uコわ\0\\ツgffV`gf]ツff⁵らコツ゛ツgf⁵たた▥▥IDる¹\0]Uハ^UU⁵\0\\}gfツコわᵉgfわᵉらコw]UUU\\わアアアらコmUUUわ`UUチgわUᶜP}Vムg]Uᶜ)\"\"\"\"\"$ᶜ\0]UハニわUᶜ\0コWUUわ\\]ᵉVU]ム\\}UわUUU\\わモ¹\0PmU]UコわオコUlUわ]ᶜオWUeUU]ᶜゅ$,アア,B□\0わUハチUUᶜ\0mU]Uコ\\コᶜ]]コわコVUわPUUUUム゛\0オVU\\UUわオわUテUUUᶜ`コUわUUUᶜ)\"るアアア,る\0,UコVUわ゛\0VUUUU\\U⁵]UU]m]Uわ\0UUUUわモ¹`コU\\UUわオUUUUU]ᶜeUUわUUUᶜ)アアアアアア\"\0,\\UUUUム¹]UUUU\\]ᶜUUUチサ\\Uわ\0PUUUUム゛オわUUUUわオUU\\UUUᶜコUUUUUUᶜ)るア\"\"アアB\0,\\UUUUわᵉ]]UUUUUᶜ]UUわア\\UわらムUUUUわモオUUUハモモオUUUUハモᵉコUUモUUUᶜ$ア,ム.\"アB\0,\\UUUUUᶜ]UUモ^UUᶜU]UわアUUわ\\ア^UUUわムPUUU゛■¹オコUU\\ᵉ\0\0UUハ■^UUᶜ$ア,、ニ\"ア,\0%UUUUU]ᶜ]Uわ■りUUᶜらUUU\\Uコわツイ^UUUわわオコUハモモ゛オUUUモ\0\0\0コU‖モQU]ᶜ$る,、ウ\"ア,\0イUハモUUわᶜ]UわモテUUᶜナ\\UU\\UUハ}f]UUUUUPUUわアアムオUUUᵉ\0\0\0UUコア]UUᶜ$ろ,ムL\"ア,\0]Uハ■\\UアᶜUUUツVUUᶜわウUUUUUᵉVUUUUUわわPUUUツツイPUUわ\0\0\0\0UUUツUUUᶜ$\",D)るアる\0U]ハり]アアᶜ]UUUUUUᶜ]ム\\UUハモ\0]]UUUUUわらUわ\"\"\"るオUわヌ\0\0\0\0わUUUUUUᶜ$る,\"るアアヌ\0]UコmアアわᶜU]UUUU]ᶜgサUUU゛ᵉ\0]UUわUU,ヌナU,,る\"アPU%²\0\0\0\0ナUUUUUUᶜ$るアアアア,ᶜ\0UUUU\\アアᵉ\\UUUUUUᵉVUUUムニ\0\0UU\\UU%\"ᵉ\0ウ,\"\"るムPU\"²\0\0\0\0\0\\]UUU]ᶜ$アアアア,るᵉ\0Uわアアムウム\0らU]UチUハ\0]UU,\"ᵉ\0\0\\U\\U,\"ム\0\0ナ\"\",,モらわ\"ᶜ\0\0\0\0\0らUUハ\\Uᶜ$ア\"ア\"\"モ\0\0\\Uわア゛モᵉ\0\0\\U゛^Uᵉ\0]UU,ヌ\0\0\0ナモモモモモᵉ\0\0\0モモモモᵉ\0モモᵉ\0\0\0\0\0\0モモᵉモモ\0$ろ\"モモモ\0\0\0ナモモモニニ\0\0\0ナモニニモ\0\0UUわ,ᵉ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0$\"る\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ナモモモ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0$\"ア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0$,ア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0$るア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\"るア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0$アア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0るアア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ナモᵉ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",{},true,spl_unp"1,0,0,0"
music()
for i=0,0x7ff do
poke(i+0x1000,ord(s,i))
end
end
function spawn_char()
hp,obj,double_jump,charge,dash_dur,stage_init,char_mode,hp,hurt,invinc,grab,pull,show_collect=maxhp,{},true,spl_unp"240,-30,90,-1"
music(split"16,0,8"[stage])
c=
{
x=xstart,
y=ystart,
xs=0,
ys=0,
}
for i=0,127 do
for j=0,47 do
local ii,jj=i<<3,j<<3
local tile=mget(i,j)
if tile==32 and not xstart then
c.x,c.y=ii,jj-2
end
if tile>=74
and tile<80 then
new_obj(tile-74,ii,jj)
elseif tile==210 then
new_obj(6,ii,jj)
elseif tile==211 then
new_obj(7,ii,jj)
elseif tile==248 then
new_obj(8,ii,jj)
end
end
end
upd_cam()
end
function init_stage()
str={
"zw\0\0xz|}~|d~|}~xyz\0\0\0xyz|}~pr|d~|}~xz|d~|}~ptrpqrpqrwxyz|d}}~wxyzptrxuzxyyuyzpqrw|d~|}~hijhiijxuzpqrxzptr|d~|d~xyz|d~|}~xuz|}~|dmn\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0`b\0\0\0\0\0\0\0ア`ab\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xyzxyyzhUj\0\0\0\0\0\0\0\0\0\0\0\0\r\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0`ad~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0pr\0\0\0\0\0\0\0\0ptr\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xyz\0\0\0\0\0\0\0\0\0ア\0\0。\0\0\0\0\0\0\0\0\0\0\0\0\0\0ヲ\0pqij\0\0\0\0\0\0\0\0\0\0\0キ\0\0\0\0\0\0\0xz\0\0\0PR\0\0\0hij\0\0ヲ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0C\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0。\0\0\0\0\0\0\0\0\0\0\0ノ\0\0\0\0hiyz\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0`b\0\0\0`b\0\0\0xyz\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ヒ\0\0AD\0\0\0\0キ\0D@B\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0。\0PFRPQRPQRXYZXYZxyij\0\0\0\0\0\0\0ヌ\0\0\0\0\0\0\0\0\0\0\0pr\0\0\0pr\0\0\0`abXGYZ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0AD@DD\\H^@@B\0\0\0\0\0\0\0\0\0\0\0\0\0\0ヒ\0\0\0\0\0\0\0\0\0\0\\]^PQR\0\0\0\0\\-^`Tbptrpqrxuzxyz`ayz\\]^\0\0\0\0XZ\0\0\0\0\0\0\0\0\0\0hj\0\0\0gg\0\0\0pqrxyuz\0\0\0\0²\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0AD@@@|d~@DB\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0PQRPFRlmnptr\0\0\0\0|}~pqr\0\0\0\0\0\0\0\0\0\0\0\0pqUjlmn\0\0\0\0xz\0\0\0\0\0\0\0\0\0\0xz\0\0\0ww\0\0\0xuz\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0XGZ\0\0\0\0\0A@@DDD@\0DDB\0ヌ\0XYZ\\]^\0\0\0\0\\]^\0\0\0pqrptr|}~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hiyz|d~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xz\0\0\0ln\0\0\0`ab\0\0\0\0\0²\0\0\0\0\0XYYZW\0\0\0\0xuz\0\0\0\0\0A@D\0\0EEEDEBXYZhijlmn\0\0\0\0|}~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xy`abhj\0\0\0\0²\0\0\0\0\0\0\0\0\0\0\0ln\0\0\0|~\0\0\0ptr\0\0\0\0\0\0\0\0\0\0\0hiijg\0\0\0\0\0\0\0\0\0\0\0\0A@DEEE\0EDノBhijxuz|}~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ヒ\0\0\0\0ク\0\0lmpqr[z\\]^\0\0\0\0\0\0\0\0\0\0\0\0\0|~\0\0\0gg\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xuyzw\0\0\0\0\0\0\0\0\0\0\0\0A@\0DDDDDE\\HxuzD\0\0hijエエエエエナナナウウ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\H^\\H^\0\0\0\0\0\0\0\0\0\0\0\0|}Ujhcjlmn\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ww\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ニglmVn\0\0\0\0\0\0\0\0²\0\0\0A@@@@@XYZlVnhjDヲDxuzトトトトトユユユテテ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0|d~|d~\0\0\0\0\0\0\0\0\0\0\0\0lmuzxc[|}~Z\\]^\0\0\0\0\0\0\0\0\0\0\0\0L\0hj\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0w|}d~\0\0K\0\0\0\0\0\0\0\0\0A@@@@@hij|}~xz\0DEhjlmnlVn`Tbhjナナナウウウエエエ\0\0ア\0\0\0\0g`abhj\0\0\0WXYZ\0\0\0\0\0|}hijccbhijlmn\0\0\0\0\0⁷\0\0\0\0\0\0\0\0xz\\]^PFR\\]^ウウウウウウエエlmmngエエウウウウウウウウウ\\]^\\]^XxyzhjlmnXYZxz|d~|}~ptrxzユユユテテテトトト\0\0\0\0\0M\0wpqrxzウウウghijウウエエエhixy[ccrxuz|d~XGZXYZ\\]^\\H^\\^hjlmn`TblVnテテテテテテトト|d}~wトトテテテテテテテテテlVnlmnhUjwxz|d~hijhj@DEED@hj`Tb`abhijlmnPQRPFRWhUj`TbテテテwxyzテテトトトxyhicccjhijhijhUjhizlmnlVnlnxz|d~pqr|d~xuzhijlVnhijlVnhijhijhij|}~|d~xyzlnhijhxyzxzDEEEEDxzpqrptrxyz|d~`ab`Tbgxuzptrhijlmnhijlmnhi\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hcjlcn\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ム\0\0\0\0\0\0lmnhj\0\0\0\0\0ム\0\0\0\0\0\0\0x\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0J\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xcz|c~\0\0\0\0\0\0ム\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ヲ\0\0|}~xz\0\0\0\0\0\0\0\0\0\0\0\0\0l\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hcjl○n\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hjlmn\0\0ヲ\0\0\0\0\0\0\0\0\0\0|\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0XYZ\\^XGZ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ニxcz|}~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xz|}~\\^\\^\0\0\0\0\0\0\0\0\0`\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hijlnhUjXYZ\0\0\0\0\0\0\0\0XYZ\\]^XYZ\\]^W\0\0\0`sb\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0²\0\0\0²\0\0\0\0\0\0\0\0\0\0\0\0\0\0ア\0\0`TablVnlnニ\0\0\0\0\0\0\0\0p\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xyz|~xyzhij\0\0\0\0\0\0\0\0hij|d~xyz|d~w\0\0\0ptr\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0²\0\0\0²\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0pttr|}~|~\0\0\0\0\0\0\0\0\0`\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0²\0\0\0\0\0\0\0\0xuz^\0\0\0\0\0\0\0xyz\0\0\0\0\0\0\0\0\0\0\0\0\0lmn\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xyzxuzpqr\0\0\0\0\0\0\0\0\0p\0\0\0\0\0\0\0\0\0\0\0\0\0²\0\0\0\0C\0\0\0\0\0²\0\0C\0\0\0\0\0\0\0\0|~lnPR\0\0\0\0\0hUj\0\0\0\0\0\0\0\0\0\0\0\0\0|d~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\r\0\0\0\0\0\0\0\0\0\0\0\0\0ヌ\0\0g\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0A@@@@@@@@B\0\0\0\0\0\0\0\0\0\0|~pr\0\0\0\\Hxuz\0\0\0\0\0\0\0\0\0\0\0\0\0`Tb\0\0\0\0K\0\0\0\0\0\0\0\0\\]^W\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0。\0\0\0\0\0\0\0\0\0\0\0\0\0\\]^w\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0A@@@@@@@@B\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0lVnhjニ\0\0\0\0\0\0\0\0\0\0\0\0pqr\0\0\0\0\0\0\0\0\0\0\0\0\0|}~w\0\0\0\0\0\0\0\0\0\0\0\0PR\0\0\0\0\0\0\0\0\0\0\0\0\0。\0\0\0\0\0J\0\0\0\0\0\0\0lmn`\0 \0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0A@@@@@@WPQR\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0|_~[z\0\0\0\0PQRPQRPFR`ab\0\0\0\0\0\0XYZ\0\0ヲ\0g`ab\0\0\0\0\0XYZ\0\0\0\0`b\0\0\0\0\0\0\0\0\0\0\0\0\0。\0\0\0\0\0\0\0\0\0\0\0\0\0|_~p\\]^\0\0\0\0\0\0\0\0\0\0\0XZPQR@@@XYZg`ab\0\0\0\0\0\0\0\0\0\0\0\0\0\\]^hk`cb\0\0\0\0pqrptrpqrptr\0\0\0\0XZhij\0\0\0\0wSqr\0\0\0\0\0hijナナナウprXYZ\0\0\0\0\0\0\0\0\0\\-^\\]^\0\0\0\0\0\0\0\0\0gcSblmn\0\0\0PR\0ナウ\0\\^hj`abXGZhijwSqr\0\0\0\0\0\0\0\0\0\0\0\0\0lmn[kpcr\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hjxyzウウウウlcngウウナナナxyzユユユテhjhij\0\0\0\0\0\0\0\0\0lmnlmn\0\0\0\0\0\0\0\0\0wccr|}~PFR`bPユユRlnxzSqrhUjxyz[obg\0\0\0\0\0\0\0\0\0\0\0ノ\0|}_ckjcj\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0XZxzlmnテテテテ|c_wテテユユユlmn`abjx[xyz^\0\0\0\0\0XGY|}~|}~YYZ\\H^\\]^`csghij`Tbpr`aab|~h[cjwxyzlmncorwZ\\H^\\]^\\]^XYZ`acckzc[\0\0\0\0\0\0\0\0\0\0ノ\0\0\0\0\0\0\0hjpr|d~jhijhcchij`ab|d~ptrzhcjlmn\0\0\0\0\0hUij`bhiUiijlVnlmnpcrwxuzpqrhjptqr`bxcczlmng|}~{ohijlVnl_nlmnhijpqccklccWXYZ\\]^WXYZXGZ\\^PRxzlmnhijxyzxccxyzSSr`abwxuzxcz|}~\0\0\0\0\0xuyzprxyyyuz|d~|}~gcabk}~|}~xzxyyzprxuyz|}~wxuuzwxyz|}~|d~|d~xyz`abxz|d~wxyzlmnwxuzxyz|~prxz|d~xyzzzzzzzzzptrwpqrln|~xyz`Tb\0\0\0\0\0pqrxzptrxuzpqr|d~wwptrkb\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ptr\0\0\0\0\0\0\0\0\0|}~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ADDDDDD|~Khjlnpqr\0\0\0\0\0\0\0\0\0ア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xkr\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ム\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0キ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0²\0\0\0\0\0\0\0\0\0\0\0\0\0\0AEEEDD@@wYxz|~`ab\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hkj\0ヲ\0ヒ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ADE\0EDE@xyz`abpqr\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ヒ\0\0キ\0\0xkz\0\0\0\0\0\0\0\0\0\0\0\0\0PQR\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0²\0\0\0\0\0\0\0\0\0\0\0\0A\0\0EE@@@@@@pqrlmn\0⁷\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0l○n\0\0\0\0\0\0C\0\0\0\0\0\0`ab\0\0\0\0\0\0\0\0\0\0XGZ\\]^\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ヌ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0²\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0AEEE@@DDD@@`Tb|d~PFRPQR\0\0\0PQQR\0\0\0\0\0\0\0\0\0\0M\0\0|d~\0\0\0\0\0\0ADDD\0DDpqr\0\0\0\0\0\0\0\0\0\0hUjlmnニ\0\0\0\0\0\0\0\0\0\0\0PFQR\\]^\0\0\0\0\0\0\0L\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ADD@@DEEED@pqr`ab`Tb`ab\0\0\0`aab\0\0\0\0\0\0\0\0\0\0\0\0\0hgg\0\0\0\0\0\0ADEDDD@`bg\0\0\0\0\0\0\0\0\0\0xuz|}~\0\0\0\0\0\0\0\0\0\0\0\0`Tablmn\0\0\0\0\0XZPQRPFR\0\0\0\0\0\0\0\0\0\0XYZPFRXYZD@@DDE\0ED@@@@ptrpqrptr\0\0\0pqqr\0\0\0\0\0\0\0\0\0\0PFRxww\0\0PQR\0A@DDED@prw\0\0\0\0\0\0\0\0\0\0\0\0\0`ab\0\0\0\0\0\0\0\0\0\0\0\0pqtr|}~\0\0\0\0\0hjpqrpqr\0\0\0\0\0\0\0\0\0\0xuz`Tbhijヌ@@DE\0EED@@@@B\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0`Tblmn\0\0`ab\0ADDED@Wgln\0\0\0\0\0\0\0\0\0\0\0ヲ\0ptr\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xz\0\0\0\0\0\r\0\0\0\0\0\0\0\0\0\0\0\0\0pqr[yz\\]^DE\0\0ED@@@DB\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\\]^ptr|d~\0\0pqr\0A@@D@@gw|~\0\0\0\0\0\0\0\0\0\0\0\0\0`Tbニ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ln\0\0\0\0\0。\0\0\0\0\0\0\0\0\0\0\0キ\0hijcTblmnDDEEDD@DE@B\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0lmnhijlij\0\0`abPQRXGZXwlmn\0\0\0\0\0\0\0\0\0\0ウXZpqrXYZPQR\0\0\0PQR\0\0\0\0\0\0\0\0\0\0\0\0|~\0O\0\0\0。\0\0\0\0\0\0\0\0\0\0PQRxyzcSr|}~\\]^DD@@@D@B\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0PQRPFR|}~xuz|yz\0\0ptr`abxuzhj|}~\0\0\0\0\0\0\0エエウテhjlmnhij`abXYZ`abXYZ\\H^ノ\0\0\0\0\0hj\0\0\0\0\0。\0\0\0\0ノ\0エナナナ`ablmnccj`TblmnDD@@@@@Bノ\0\0\0\0ノ\0\0\0\0\0\0\0\0\0\0`ab`Tbhij@@DDmn\0\0lmnpqrlmnxz`abW\0\0PQR\\トトテwxz|_~xyzptrhijpqrhijlVnXYZ\\]^xzZXZ\\]-^XYZ\\]トユユユpqr|_~cczpqr|}~XGZPQRXGZ\\H^\\H^\\]^XGZXGZptrpqrxuzDEEDd~\0\0|}~hij|}~hjptrg\0\0`ablmnhUjlmc`ablmnjxuzhijxuz|}~hijlmnhijhjlmmnhijlmn`abhijhkjccn`ab`abhUj`abhUjlVnlVnlmnhUjhUjhjhij`ab\0E\0EDjg\0\0xyzxuzxyzxzhijw\0\0pqr|}~xuz|}cptr|}~zhUjxyzxz`aTbxyz|d~xyzxz|}_~xyz|_~pqrxyzxkzcc~ptrpqrxuzptrxyz|d~|d~|}~xuzxuzxzxuzpqrEDE\0@",
"~\0\0\0\0\0\0\0\0\0\0\0\0\0pqr\0\0\0\0\0\0[\0\0\0w\0\0\0xuzxzpqrwpqrptrpqrpqr|}~|}~pqrxyzxyz|~|~\0\0\0|}~xyzwpqrpqrxyzxyzw|}~pqrpqrpqr\0\0\0\0lmn\0\0\0xyzxuzxyzxuzb\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0c\0\0\0g\0\0\0ln\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ln\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ln\0\0\0\0`b\0\0\0\0\0\0\0\0\0\0\0\0\0|}~\0\0\0\0\0\0\0\0\0\0\0\0\0\0`r\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0PQRWc\0\0\0w\0\0\0|~\0\0\0\0\0\0\0\0\0\0\0\0ア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0|~\0\0\0\0\0\0\0\0\0\0\0\0C\0\0\0\0\0\0\0C\0\0\0|~\0\0\0\0pr\0\0\0\0\0\0\0\0\0\0\0\0ニl_n\0\0\0\0\0\0\0\0\0\0\0\0\0\0pn\0\0O\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0pqrw{\0\0\0g\0\0\0ln\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ln\0\0\0\0\0\0\0\0\0\0\0\0A@@@@@@@B\0\0\0hj\0ヲ\0\0`b\0\0\0\0\0\0\0\0\0\0\0\0\0|c~\0\0\0\0\0\0\0\0\0\0\0ヒ\0\0g~ニ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0w\0\0\0|~\0\0\0PQRPQRPQRXZ\\^\\]^\\]^W\\]^\0\0\0\0|~\0\0\0\0\0XZXZ\0\0\0A@@@@@@@B²\0\0xz\0\0\0\0pr\0\0\0\0\0\0\0\0\0\0\0\0\0lcn\0\0\0\0\0\0\0XZ\0\0\0\0\0wn\0\0\0\0\\]^\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0g\0\0\0hj\0\0\0pqrptrpqrxzln|d~|}~w|d~\0\0\0\0hj\0\0\0\0\0xzxz\0\0\0A@@@@@@@B\0\0\0\0\0\0\0\0\0gg\0\0\0\0\0\0\0\0\0\0\0\0\0|c~\0\0\0\0\0\0\0hj\0\0\0\0\0`~\0\0\0\0|d~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0キ\0w\0\0\0xz\0\0\0\0\0\0\0\0\0\0\0\0\0\0|~\0\0\0\0\0\0\0\0\0\0\0\0\0\0xzH^\0\0\0\0\0\0\0\0\0PQR@@@@@@B\0\0\0²\0\0\0\0ニww\0\0\0\0\0PQR\0\0\0\0ニlcnXYZ\0\0\0\0xz\0\0\0PFpjニ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ノ\0\0\0\0\0\0g\0\0\0ln\0\0\0\0\0\0\0\0\0\0\0\0\0\0`b\0\0\0\0\0\0\0\0\0\0\0\0\0\0xlVn\0\0\0\0\0\0\0\0\0pqrPQRXYZXZ\0\0\0\0\0\0\0\0`b\0\0\0\0\0pqr\0\0\0\0\0|c~hij\0\0\0\0|~\0\0\0`Tbz\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0C\0PRPQRPQQw\0C\0|~\0\0\0\0\0\0ノ\0\0\0\0\0\0\0pr\0\0\0\0\0\0\0\0\0\0\0\0\0,.|d~\0\0\0\0\0\0\0\0\0\rxzptrxyzxz\0\0\0\0\0\0\0\0pr\0\0\0\0\0\0\0\0\0\0\0\0\0xczxuz\0\0\0\0hj\0\0\0pqrn\0\0\0\0\0\0\0\0\0XYZ\0\0\0\0A\0prpqrpqqr\0B\0hjPQRPQRPQRPR\0\0\0`b\0\0\0PQRPQRW\\]^<>jprPR\0\0\0ア\0\0\0。\0\0\0\0\0\0\0\0ln\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0l○n\0\0\0\0\0PQxz\0\0\0xyz~ニ\0\0\0\0\0\0\0\0xyz\0\0\0\0ADEEDDD\0\0\0\0\0B\0xzptrpqrpqrpr\0\0\0pr\0\0\0pqrptrw|}~xuz\0\rpr\0\0\0\0\0\0\0。\0\0\0\0\0\0\0\0|~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0²\0\0\0\0\0\0|}~\0\0\0\0\0`abg\0\0\0,./j\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ADDEEDED\0\0\0DB\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hj\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0。\0\0\0\0\0\0\0\0\0。\0\0\0\0\0\0\0\0ln\0\0\0\0\0\0\0\0\0\0\0\0\0PFRW\0\0\0\0\0\0\0\0\0\0\0\0\0\0pqrw\0N\0<>?z\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ADEEEEEED\0DDB\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xz\0\0\0\0\0\0\0\0\0\0ア\0\0\0\0\0\0。\0\0\0\0\0\0XZ\\-^XZ\0\0ク\0\0|~\0\0\0\0\0\0\0\0\0\0\0\0\0`Tbg\0\0\0\0\0\0\0\0\0\0\0\0PQw`ab\0\0\0hijjニ\0ヲ\0ウウウウウウウウ\0\0\0\0ADDDDEDDDDDDB\0\0\0\0\0\0J\0\0ノ\0\0\0\0\0\0\0`b\0\0\0\0\0\0\0\0\0\0\0\0\0K\0\0\0。\0\0\0\0\0\0hjlmnhj\0\0\0\0\0ln\0\0\0\0ノ\0\0\0\0\0\0\0\0pqrw\0\0\0\0\0\0\0\0\0\0\0\0`abpqr\0\0\0xyzz]^XGテテテテテテテテGZXYZ\\]^\\H^\\^XZ\\]^PQR\\]^XYZXYZ\\H^Xpr\\H^XYZXGZXYZ\\]^W\\-^XZ\\^Xxz|}~xzPQRPQ|~YZPFRPQRXYZ\\]w`TbPQRWXYZPQRXYpqrhij\\]^hijlmnhUjxyzhijhUjhizlmnlVnlnxz|d~pqr|d~xuzhijlVnhijlVnhijhUjhij|}~glmnhjlnhijhj`ab`ab`abxyz`Tbptrxyz|d~pqr`Tbgxuz`abhijlnxyzlmnxyzb\0\0\0\0\0\0\0\0\0\0\0\0\0lVn\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0`abpqrw\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0`b\0\0\0\0\0\0\0\0\0\0\0\0\0\0g`ab`abr\0ヲ\0\0\0\0キ\0\0\0\0ヲ\0|}~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0pqrg`ab\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0pr\0\0\0\0\0\0\0\0\0\0\0\0\0\0wptrpqrb\0\0\0\0\0\0\0\0\0\0\0\0\0lmn\0ア\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ム\0\0\0\0\0\0\0\0\0\0\0\0`abwpqr\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0`b\0\0\0\0\0\0\0\0\0\0\0\0\0\0`ab`Tbgr\0\0\0\0\0\0\0\0\0\0\0\0\0|d~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0キ\0\0\0\0\0\0\0ヌ\0ヌ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0pqrDEDS\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0pr\0\0\0\0\0\0\0\0\0\0\0\0\0\0pqrpqrwb\0\0\0\0\0\0\0\0\0\0\0\0,./w\0\0\0\0\0\0\0キ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0PQQR\0\0\0\0\0\0\0\0\0\0\0\0\0PFRW\0\0\0\0\0\0\0\0\0\0\0\0`abEアEc\0\0\0\0\0\0PQRPFRPQR\0\0\0\0\0\0\0\0\0\0PQR\0\0\0\0\0\0\0\0\0\0\0\0\0`r\0\0\0\0\0\0\0\0\0\0\0\0<>?g\0\0\0\0\0\0XZ\0\0\0\0WXYZ\0\0\0\0\0\0\0\0\0\0\0\0\0pqqr\0\0\0\0\0\0\0\0\0\0\0\0\0`Tbg\0\0\0\0\0\0\0\0\0\0J\0pqrDE\0c\0\0\0\0\0\0`ab`Tb`ab\0\0\0\0\0\0\0キ\0\0`ab\0\0\0\0\0\0\0\0\0\0\0キ\0pg\0\0\0\0\0\0\0\0\0\0\0\0xyzw\0\0\0\0\0\0hj\0\0\0\0wxyz\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ptrw\0\0\0\0\0\0\0\0\0PQR`ab`abc\0\0\0\0\0\0pqrpqrptr\0\0\0\0\0\0\0\0\0\0ptr\0\0\0\0\0\0\0\0\0\0\0\0\0`w\0\0\0\0\0\0\0ヒ\0\0\0\0\0`ab\0\0\0\0\0\0xz\0\0ウウlmng\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0x[yz\0\0\0\0\0\0\0\0\0pqrpqrpqrs\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ウ\0\0\0PFRpb\0\0\0\0\0\0\0\0\0\0\0\0\0pqr\0\0\0\0\0ウhj\0\0テテ|d~w^\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ADEEヒEEEDB\0XYZc\0\0\0\0\0\0\0\0\0\0\0,./g`ab`ab\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0テ\0\0\0`Tb`r\0\0\0\0\0\0\0\0\0\0\0\0\0pqr\0\0\0\0\0テxz\0\0xyyzlVn\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0A@DDEEED@B\0xyzc\0\0\0\0\0PQR\0\0\0<>?wpqrpqr\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0`\0\0\0ptrpn\0\0\0\0\0\0\0²\0\0\0\0,./g\0\0\0\0\0whj\0\0\0\0\0\0|}~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0A@@@DEDDDB\0,./c\0\0\0\0\0ptr\0\0\0xyz\0\0\0\r\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\r\0\0\0\0\0\0w~\0\0\0\0\0\0\0\0\0\0\0\0<>?w\0\0\0\0\0\0xz\0\0\0\0ヲ\0ln\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0A@@\0@DEEEB\0<>?c\0キ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0。\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0。\0\0\0\0K\0`g\0\0\0\0\0\0\0\0\0\0\0\0xyzgウ\0\0\0\0\0hj\0\0\0\0\0\0|~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0A@@@@DE\0EB\0xyzsQR\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0。\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0。\0\0\0\0\0\0pw\0\0\0\0\0\0\0\0\0\0\0\0\0lnwテ\0\0\0\0\0xz\0\0\0PQRlnニ\0\0\0エナ\0\0\0ウウ\0\0\0\0\0\0A@@@@@DEEB\0\0\0g`ab\0\0\0\0ノ\0\0\0\0\0\0⁷\0\0\0。\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ウウウウウナナウウウナナナエエウウウエエエ。エウウウウウ`n\0\0\0\0\0\0\0\0\0\0\0\0\0|~xz\0\0\0\0\0lnウ\0\0pqr|~ZW\\]トユRWXテテXGZPQRXGZXYZPFR\\]H^wptr\\H^\\^XGZ\\]^XYZ\\-^WPQR\0\0\0\0XYZXGZXテテテテテユユテテテユユユトトテテテトトト-トテテテテテp~\0\0\0\0\0\0\0\0\0\0\0\0\0hj_\0\0\0\0\0\0|~テ\0\0`Tbhijglmn`bghijhUj`abhUjhij`TblmVnghijlVnlnhUjlmnhijlmng`ab\0\0\0\0hijhUjhijhij`bhij`ablnhijlnlmnhijhij_\0\0\0\0\0\0\0\0\0\0\0\0\0xzc\0\0\0\0\0ウ`bw\0\0pqrxyzw|}~prwxuzxyzptrxyzxuzpqr|d}~wxuz|d~|~xyz|}~xuz|}~wpqr\0\0\0\0xuzxyzxuzxyzprxuzptr|~xuz|~|}~xyzxuzc\0\0\0\0\0\0\0\0\0\0\0\0\0hjc\0\0\0\0\0テpr\0\0\0\0\0\0`abヲ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hj\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0g\0\0\0\0`c\0\0\0\0\0\0\0\0\0\0\0\0\0xzc\0\0ヲ\0\0wln\0\0\0\0\0\0pSr\0\0\0ム\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xz\0\0\0²\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0w\0ヲ\0\0pc\0\0\0\0\0\0\0\0\0\0\0\0\0|~c\0\0\0\0\0\0|~\0\0\0\0\0\0lcn\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ln\0\0ヲ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0²\0\0\0\0\0\0\0\0\0\0\0L\0\0\0\0\0g\0\0\0\0`c\0\0\0\0\0\0\0\0\0\0\0\0\0lncウ\0\0\0\0\0gg\0\0\0\0N\0|c~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0M\0|~\0²\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0w\0\0\0\0pc\0\0\0\0\0²\0\0\0\0\0\0\0|~sテ\0\0\0\0\0ww\0\0\0\0\0\0lcn\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ヌ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0ln\0\0\0\0ナウ\0\0\0\0\0\0\\^\\]^PQR\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hc\0\0\0\0\0\0\0\0\0\0\0\0\0pqqr\0\0\0\0\0`bPQR\0\0\0|c~\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0XGZPQRWPFR\0\0\0\0\0\0\0XY|~FRPQユテ\0\0\0\0\0\0lnlmn`abナナナナナ\0\0\0\0\0\0\0⁷\0\0\0\0\0\0\0\0\0\0\0\0\0xc\0\0キ\0\0\0\0\0\0\0キ\0\0`ab\0\0\0\0\0\0prpqr\0\0\0`sb\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0XYZ\0\0\0hUj`abg`Tb\0\0\0\0\0\0\0hij`Tb`abg\0\0\0\0\0\0_~|}~ptrユユユユユ\0\0\0\0\\]]^XZ\0\0\0\0\0\0\0\0\0\0\0hc\0\0\0\0\0\0\0\0\0\0\0\0\0pqr\0\0\0\0\0\0`Tabg\0\0\0pqr\0\0\0\0\0\0\0\0\0\0\0\0\\]^PR\0\0\0hij\0\0\0xyzpqrwpqr\0\0\0\0\0\0\0xuzpqrpqrw\0\0\0\0\0\0clVnxyzpqrptr\0\0\0\0lmmnhjYZ\0\0\0\0\0\0\0\0\0xc\0\0\0\0\0\0\0\0\0\0\0\0\0wln\0\0\0\0\0\0pqtrw\0\0\0lmn\0\0\0\0XYZW\0\0\0\0lmn`b\0\0\0xuz\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0|}\0\0\0\0\0\0\0\0\0\0\0\0{|}~\0\0\0\0\0\0\0\0\0\0\0\0\0___~xz[[\0\0\0\0ウ\0\0\0\0lc\0\0\0\0\0\0\0\0²\0\0\0,.|~\0\0\0\0\0\0\0\0\0\0\0\0\0\0|}~\0\0\0\0xuzw\0\0\0\0|}~pr\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hj\0\0\0\0\0\0\0\0\0\0\0\0xyzg\0\0\0\0\0\0\0\0\0\0\0\0\0ook\0\0\0ck\0\0\0\0テ\0\0\0\0|c\0\0\0\0\0\0\0\0\0\0\0\0<>?g\0\0\0\0\0\0\0\0\0\0\0\0\0\0hij \0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0XYZW\0\0\0\0\0\0\0\0\0\0\0\0\0xz\0\0キ\0L\0\0\0\0\0\0\0,./w\0\0\0\0\0\0\0\0\0\0\0\0\0ooo\0ヲ\0cc\0\0\0\0g\0\0\0\0hc\0\0\0\0\0\0\0\0\0\0\0\0xyzw\0\0\0キ\0\0\0\0\0\0\0\0\0\0xuzGZ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0hijg\0\0J\0\0\0\0\0\0\0キ\0\0hj\0\0\0キ\0\0\0\0\0\0\0\0<>?g\0\0\0\0\0\0\0\0\0\0\0\0\0ooo\0\0\0cc\0\0\0\0w\0\0\0\0xc\0\0\0\0\0\0\0\0\0\0\0\0\0`ab\0\0\0\0\0\0ウ\0\0\0ウ\0\0\0hjhUj\0\0\0\0\0\0ノ\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0xuzw\0\0\0\0\0\0\0\0\0\0\0\0\0xz\0\0\0\0\0\0\0ウウウウウhijwニ\0\0\0ノ\0\0\0\0\0\0\0\0ooo\0\0\0ccウウウウgウウウウl○\0\0\0\0\0\0\0\0\0\0\0\0\0pqr\0\0\0\0\0\0テ\0\0\0テ\0\0\0xzxyz\0\0\0\0PFRPQR\0\0\0\0\0\0\0\0\0ノ\0\0\0\0\0\0glmn\0\0\0\0\0\0\0\0\0\0\0\0\0hjPFRPQRXテテテテテxyzwPQRPQRPQR\0\0\0\0ooo\0\0\0ccテテテテwテテテテ|n\0\0\0\0\0\0\0\0\0\0\0\0\0`ab\0\0\0\0\0\0g\0\0\0g\0\0\0hijhjPQRW`Tb`abPQRPQR\\]^\\]^PQRXw|}~Z\\^\\^\0\0\0\\]^XYxz`Tb`abhijhijglmn`ab`ab`ab\0\0\0\0ooo\0\0\0{{jhijhUjhij",
}
if stage<3 then
local n=1
for i=0x1000,0x2fff do
local t=ord(str[stage],n)
if i<0x1800 or i>=0x2000 then
n+=1
poke(i,t)
end
end
else
reload()
end
charlight,camx,camy,dt,xstart,ystart=spl_unp"23,0,0,0"
spawn_char()
spawn_screen()
end
function spawn_screen()
if boomer_obj then
if boomer_obj.typ<6 then
del(obj,boomer_obj)
else
boomer_obj.x,boomer_obj.y=boomer_obj.ix,boomer_obj.iy
end
end
roomdt,roomdt480,enm,lgt,shot,trail,ptc,boomer_thrown,closest,boomer_obj,lamp=0,0,{grab or pull},{},{},{},{}
local x,y=camx\8,camy\8
for i=x,x+15 do
for j=y,y+15 do
local ii,jj=i<<3,j<<3
local tile=mget(i,j)
if tile==2 then
new_enm(0,ii,jj)
elseif tile==225 then
local e=new_enm(1,ii,jj)
if is_solid(i-1,j) then
e.flip=true
end
elseif tile==226 then
new_enm(2,ii,jj)
elseif tile==228 then
new_enm(3,ii,jj)
elseif tile==230 then
new_enm(4,ii,jj)
elseif tile==236 then
new_enm(5,ii,jj)
elseif tile==204 then
new_enm(6,ii,jj)
elseif tile==11 or tile==203 then
lamp=true
elseif tile==59 then
lamp=false
end
end
end
end
-->8
function new_ptc(x,y)
return add(ptc,
{
x=x\1+rnd(2),
y=y\1+rnd(2),
g=0,
dt=rnd(10),
typ=2,
dur=8,
ys=0,
xs=0,
clr=11,
siz=2,
}
)
end
function new_light(x,y,r,dt)
return add(lgt,
{
x=x,
y=y,
r=r,
dt=dt,
}
)
end
function new_shot(typ,x,y,xs,ys,is_enm)
if typ==4 then
new_expl(x+4,y+4)
else
sfx(split"52,53,54,54,0,56,57,52"[typ+1],-1,split"16,0,0,16,0,0,0,16"[typ+1],split"16,16,16,16,16,16,13,16"[typ+1])
end
local tt=typ+1
return add(shot,
{
typ=typ,
x=x,
y=y+4,
xs=xs,
ys=ys,
is_enm=is_enm,
dt=0,
spr=split"28,74,0,75,-10,9,0,73,"[tt],
siz=split"1,1,2,1,5,2,0,1"[tt],
spd=split"5,4,3,0,0,0,0,0"[tt],
dur=split"30,42,55,9999,2,9999,75,120"[tt],
wal=({false,false,false,true,false,false,false,false})[tt],
lgt=split"15,25,45,0,0,30,0,15"[tt],
dmg=split"1,2,3,5,5,1,1,.61"[tt],
flinch=split".1,.1,1,1,.1,.1,.05,.1"[tt]*60,
}
)
end
function new_enm(typ,x,y)
local tt=typ+1
return add(enm,
{
typ=typ,
x=x,
y=y,
xs=0,
ys=0,
dt=0,
ang=0,
sprt=split"2,225,226,228,230,236,204"[tt],
sprx=split"16,8,16,32,48,96,96"[tt],
spry=split"0,112,112,112,112,112,96"[tt],
w=split"1,1,2,2,2,2,2"[tt],
h=split"1,2,2,2,2,2,2"[tt],
cdwn=split"0,60,120,120,120,30,120"[tt],
mxcd=split"0,120,120,120,120,120,120"[tt],
hp=split"1,3,3,3,3,3,3"[tt],
}
)
end
function new_obj(typ,x,y)
return add(obj,
{
typ=typ,
ix=x,
iy=y,
x=x,
y=y,
}
)
end
-->8
function _update60()
if title then
if (btnp(❎) or btnp(🅾️)) and dt~=1 then
if sel_diff then
tim,maxhp,title=0,5-diff*2
init_stage()
else
sel_diff,diff=0,0
end
end
if btnp(⬆️) then
diff-=1
elseif btnp(⬇️) then
diff+=1
end
diff%=3
else
if message then
if message.dt~=90
or btnp(❎)
or btnp(🅾️) then
message.dt+=1

if message.dt>120 then
message=nil
end
end
elseif stage_init==0 then
upd_game()
else
stage_init-=1
end
if wait_sound then
wait_sound+=1
if wait_sound>30 then
ssfx,wait_sound=osfx
end
end
end
end
function upd_game()
roomlight=stage<3 or camy==0 or lamp
if swap_mode_eff then
swap_mode_eff-=1
if (swap_mode_eff<=0) swap_mode_eff=nil
end

if show_collect then
show_collect-=1
if (show_collect<=0) show_collect=nil
end
roomdt+=1
roomdt480=roomdt%480

dt+=1
if dt%60==0 then
tim+=1
end
if hp<=0 then
wait_death=wait_death and wait_death+1 or 0
if wait_death==0 then
music"30"
end
if wait_death>25 then
for i=0,120 do
wait_death+=1
flip()
for x=0,128,16 do
for y=0,128,16 do
circfill(x,y,(wait_death-25)/2+y/8-12,0)
end
end
end
if t_att then
_init()
else
spawn_char()
spawn_screen()
end
wait_death=nil
end
end

if invinc and invinc>0 then
invinc-=1
else
invinc=nil
end

charlight,walk=23
prev_spd=max(.75,abs(c.xs)-.05)
if hurt then
hurt-=1
if (hurt<=0) hurt=nil
else
if dash_dur<0 then
if btn(⬅️) and not btn(➡️) then
c.xs-=.2
c.flip,walk=true,true
elseif btn(➡️) and not btn(⬅️) then
c.xs+=.2
walk,c.flip=true
elseif dash_dur==-30 then
c.xs*=.8
end

if dash_dur==-30 then 
c.xs=mid(c.xs,.75,-.75)
else
c.xs=mid(c.xs,prev_spd*.9,-prev_spd*.9)
end
else
charlight=40
mini_expl(c.x+6,c.y+6,rnd(5)+10)
if btn(⬅️) and not btn(➡️)
and not c.flip then
dash_dur=0
elseif btn(➡️) and not btn(⬅️)
and c.flip then
dash_dur=0
end
end
end

if dash_dur>-30 then
dash_dur-=1
if dash_dur>0 then
c.xs,c.ys=dash_h,dash_v
end
end
if (dash_dur<0) c.ys+=jetp and 0.05 or char_mode~=3 and .1 or (abs(c.ys)>.5) and .08 or .075

if type(ground)=="number" then
ground-=1
if (ground==1) ground=true
else
ground=false
end
wmag=nil
if char_mode==4 then
for i=(c.x-1)\8,(c.x+3+1)\8+1 do
for j=ceil(c.y+8)\8,ceil(c.y-2)\8+2 do
if is_solid(i,j)
and (i*8>c.x+6 and btn(➡️)
or i*8<c.x+6 and btn(⬅️)) then
if (c.ys>0) c.ys=0 wmag=true
ground=10

goto _mag
end
end
end
end
::_mag::

c.y+=c.ys
c.y=max(c.y,-40)
nextcy,spike_hurt=c.y
for i=c.x\8,(c.x+3)\8+1 do
for j=ceil(c.y+4)\8,ceil(c.y+1)\8+2 do
local tile=mget(i,max(0,j))
if tile==248 then
mset(i,j,0)
end
if fget(tile,7) then    
if c.ys>0 and j>=(c.y+8)\8 then
nextcy,ground,double_jump,dash_dur,hurt,jetp=j*8-18,10,true,min(dash_dur,-25)
end
if c.ys<0 and j<=(c.y+8)\8 then
nextcy=j*8+4
end
c.ys=0
spike_hurt=char_mode~=1 and fget(mget(i,j),6)
end
end
end
::_y::
for i=(c.x+4)\8,(c.x-1)\8+1 do
for j=ceil(c.y+4)\8,ceil(c.y+1)\8+2 do
local tile=mget(i,max(0,j))
if char_mode~=1
and fget(mget(i,j),6) then
spike_hurt=true
end
end
end
c.y=nextcy
if spike_hurt then
char_hurt()
end
if btnp(🅾️) and not hurt then
if (ground or double_jump and char_mode==0) then
c.ys=char_mode~=3 and -2.5 or -3.1
if not ground then
double_jump=false
end
ground=ssfx"52,-1,0,16"
elseif char_mode==5 then
jetp=true
end
end
if c.ys<-1
and not jetp
and dash_dur<=-30
and not btn(🅾️) then
c.ys=-1
end
if btn(🅾️) and jetp and char_mode==5 then
ssfx"53,-1,16,16"
local exp=mini_expl(c.x+(c.flip and 12 or -1),c.y+12,4+rnd(2))
exp.xs,exp.ys=c.flip and .5 or -.5,1
c.ys-=(c.ys>0) and .15 or .075
end

if (char_mode==5 and jetp) c.ys=max(c.ys,-1.5)

c.x+=c.xs
c.x=max(c.x,-2)
for i=c.x\8,(c.x+3)\8+1 do
for j=ceil(c.y+4)\8,ceil(c.y+1)\8+2 do
if is_solid(i,max(0,j)) then
c.x,c.xs,dash_dur=i*8+(c.xs>=0 and -12 or 8),0,min(0,dash_dur)
goto _x
end
end
end
::_x::

if waitshot then
waitshot-=1
if (waitshot<=0) waitshot=nil
end
if char_mode==-1 then
if btnp(❎) and
not waitshot then
waitshot=6
local s=new_shot(7,c.x+(c.flip and -4 or 8),c.y,c.flip and -1 or 1,0)  
s.xs*=2
end
elseif char_mode==0 then
if btnr(❎) then
ssfx"-1,0"
end
if not waitshot
and (btnr(❎) and charge>=30
or btnp(❎)) then
waitshot=6
local charge_lvl=min(charge\30,2)
local s=new_shot(charge_lvl,c.x+(c.flip and -4 or 8),c.y,c.flip and -1 or 1,0)
s.xs*=s.spd
end

if btn(❎) then
charge+=1
if charge==20 then
ssfx"57,0,13"
end
else
charge=0
end
elseif char_mode==1 then
charge=min(charge+1,30)
if btnp(❎) and charge>=30 then
new_shot(3,c.x+3,c.y,c.xs/2+(c.flip and -1.25 or 1.25),min(0,c.ys)/1.5-2)
charge=0
end
elseif char_mode==2 then
if btnp(❎) and double_jump then
double_jump=ssfx"55,-1,16,16"
dash_dur,dash_h,dash_v=20,get_btn_dir(2.5)
end
elseif char_mode==3
and not boomer_thrown then
if btnp(❎) then
boomer_thrown=new_shot(5,c.x,c.y,get_btn_dir(5))
end
elseif char_mode==4 then
if btnp(❎) then
if grab then
ssfx"54,-1,16,16"
grab.thrown,grab.xs,grab.ys,grab=true,c.flip and -3 or 3,-1.5
else
if not pull
and closest then
ssfx"56,-1,16,16"
pull=closest
end
end
end
elseif char_mode==5 then
charge=min(charge+1,180)
if (charge==120) ssfx"57,0,13"
if btnp(❎)
and charge>=180 then
if closest then
local s=new_shot(6,c.x,c.y,0,0)
s.tgt,charge=closest,0
end
end
end
for o in all(obj) do
local otyp=o.typ
if boomer_thrown 
and o==boomer_obj then
o.x=boomer_thrown.x
o.y=boomer_thrown.y
end
if abs(o.x+4-(c.x+4))<10
and abs(o.y+4-(c.y+6))<10 then
if otyp<6 then
swap_mode(otyp)

if not power_messg[otyp] and not t_att then
power_messg[otyp]=true
message=
{
dt=0,
typ=otyp,
}
end
for i=d128m16(o.x),d128m16(o.x)+15 do
for j=d128m16(o.y),d128m16(o.y)+15 do
if mget(i,j)==48 then
xstart,ystart=i*8,j*8-3
end
end
end
elseif otyp==7 then
for i=180,-50,-2 do
outline(circ,0,0,(o.x+4)%128,(o.y+4)%128,i,0)
flip()
end
if stage==3 then
cls()
?"     congratulations!\n\n         you win!\n\n\n\n        time: "..tim\60 ..":"..tim\10%6 ..tim%10 .."\n\n"..(t_att and "" or "  time attack unlocked!").."\n\n"..(collect<28 and "" or "you got all special orbs!").."\n\n\nby bonevolt and julio maass",spl_unp"12,40,13"
sel_diff=nil
dset(diff,1)
if collect==26 then
dset(diff+3,1)
end
if t_att then
dset(diff+6,dget(diff+6)==0 and tim or min(dget(diff+6),tim))
end
while not btn(🅾️) 
and not btn(❎) do
flip()
end
_init()
else
stage+=1
init_stage()
end
end
if o==boomer_obj then
boomer_obj=nil
del(obj,o)
end
if (otyp==6) hp=min(hp+1,maxhp)
if (otyp==6 or otyp==8) ssfx"61" del(obj,o)
if (otyp==8) collect+=1 show_collect=180
end
end
closest=nil
for e in all(enm) do
local etyp=e.typ
if e.invinc then
e.invinc-=1
if e.invinc<=0 then
e.invinc=nil
end
end
local dx=mid(c.x+6-e.x-e.w*4,-127,127)
local dy=mid(c.y+8-e.y-e.h*4,-127,127)
e.range=sqrt(dx^2+dy^2)
if char_mode~=4
or (abs(e.y-c.y)<30
and abs(e.x-c.x-(c.flip and -25 or 25))<30)
then
if not closest
and not e.thrown then
closest=e
end
if not e.thrown then
if e.range<=closest.range then
closest=e
end
end
end
if e==pull then
local fflip=(c.flip and -4 or 8)
local ang=atan2(dx+fflip,dy)
e.xs,e.ys=cos(ang)*1.5,sin(ang)*1.5
local distx=(c.x+fflip)-(e.x+e.w*4)
local disty=c.y+6-(e.y+e.h*4)
if abs(distx)<8
and abs(disty)<8 then
grab,pull=e
end
e.x+=e.xs
e.y+=e.ys
elseif e==grab then
e.xs,e.ys,e.x,e.y=0,0,c.x+(c.flip and -4 or 8)-e.w*4+4,c.y+10-e.h*4
elseif e.thrown then
e.ys+=.1
e.x+=e.xs
e.y+=e.ys
else
if e.cdwn>0 then
e.cdwn-=1
end
if etyp==0 then
local ang=atan2(dx,dy)
e.xs,e.ys=cos(ang)*.1,sin(ang)*.1
e.x+=e.xs
e.y+=e.ys
e.flip=c.x>e.x
elseif etyp==1 then
if e.cdwn==0
and abs(e.y-c.y)<10 then
local s=new_shot(7,e.x,e.y,e.flip and 1 or -1,0,true)
s.dur,e.cdwn=120,e.mxcd
end
elseif etyp==2 then
if e.cdwn==0 then
e.flip=c.x>e.x
local dist=c.x-e.x
local s=new_shot(3,e.x+(e.flip and 8 or 0),e.y,dist/80,-abs(dist)/80-.5,true)
e.cdwn=e.mxcd
end
elseif etyp==3 then
e.ys+=.075

e.y+=e.ys
e.ground=false
for i=(e.x+3)\8,e.x\8+1 do
for j=ceil(e.y+4)\8,ceil(e.y+2)\8+2 do
local tile=mget(i,j)
if fget(tile,7) then
e.y=j*8+(e.ys>=0 and -19 or 4)

if e.ys>0 then
e.ground=true
e.xs=0
end

e.ys=0

goto _y
end
end
end
::_y::

if e.ground then
if e.cdwn<=0 then
local dist=c.x-e.x
e.ys,e.xs=mid(-2,-1,-abs(dist)/35),mid(1,-1,dist)
e.cdwn=e.mxcd
end
else
e.cdwn+=1
end

e.x+=e.xs

for i=(e.x+3)\8,e.x\8+1 do
for j=ceil(e.y+4)\8,ceil(e.y+2)\8+2 do
if is_solid(i,j) then
e.x=i*8+(e.xs>=0 and -9 or 5)
e.xs*=-.9
goto _x
end
end
end
::_x::
elseif etyp==4 then
local ang=atan2(dx,dy)
e.xs,e.ys=cos(ang)*.05,sin(ang)*.05
e.x+=e.xs
e.y+=e.ys
if e.cdwn==0 then
for i=0,.75,.25 do
local s=new_shot(7,e.x+3,e.y+1,sin(i+e.ang),cos(i+e.ang),true)
s.dur,s.wal=120
end
e.cdwn,e.ang=e.mxcd,e.ang+.125
end
elseif etyp==5 then
if e.xs==0 then
e.xs=.25
end
for i=e.x\8-1,e.x\8+3 do
for j=ceil(e.y+4)\8,ceil(e.y+2)\8+2 do
if is_solid(i,j) then
e.xs*=-1
goto _hx
end
end
end
::_hx::
if e.x%128>110
or e.x%128<10 then
e.xs*=-1
end
e.x+=e.xs
e.y+=sin(dt/40)/6
if e.cdwn==0
and abs(e.x-c.x)<10 then
local s=new_shot(7,e.x+4,e.y+4,0,1,true)
s.dur,e.cdwn=120,e.mxcd
end
elseif etyp==6 then
local ang=atan2(dx,dy)
if e.cdwn==0 then
local s=new_shot(7,e.x+4,e.y,cos(ang),sin(ang),true)
s.dur,e.cdwn,s.wal=120,e.mxcd
end
e.x+=sin(dt/120)/5
e.y+=sin(dt/70)/5
end
if dash_dur<=-30
and abs(e.x+e.w*4-(c.x+6))<6
and abs(e.y+e.w*4-(c.y+6))<e.h*4 then
char_hurt()
elseif dash_dur>-30
and abs(e.x+e.w*4-(c.x+6))<10
and abs(e.y+e.w*4-(c.y+6))<e.h*4+4 then
dmg_enm(e,{dmg=1,flinch=.05})
end
end
end
local expl_en=nil
for t in all(enm) do
if t.thrown then
for e in all(enm) do
if e~=t
and e~=pull
and abs(e.x-t.x)<10
and abs(e.y-t.y)<10 then
expl_en=t
goto _en
end
end
t.wal=true
if wall_coll(t) then
expl_en=t
goto _en
end
end
end
::_en::
if expl_en then
new_shot(4,expl_en.x+expl_en.w*4,expl_en.y+expl_en.h*4,0,0)
end
for l in all(lgt) do
l.dt-=1
l.y-=.25
if (l.dt<0) del(lgt,l)
end
for s in all(shot) do
local styp=s.typ
if styp<3 then
s.xs*=.96
s.xs-=sgn(s.xs)/50
local p=new_ptc(s.x+rnd(s.siz*4)-s.siz*2+4,s.y+rnd(s.siz*4)-s.siz*2+4)
p.clr,p.siz=10+rnd(2)\1*5,styp+1
p.dur+=styp*3
for i=0,3 do
if mget(s.x\8+i\2,s.y\8+i%2)==59 then
lamp=true
end
end
end
s.x+=s.xs
s.y+=s.ys
s.dt+=1
if styp==7 then
new_ptc(s.x+3,s.y+3)
end
if s.dt>=s.dur or wall_coll(s) then
if styp==3 then
new_shot(4,s.x,s.y,0,0,s.is_enm)
end
del(shot,s)
end
if styp==3 then
s.ys+=s.is_enm and 0.05 or .1
elseif styp==5 then
local ang=atan2(c.x+4-s.x,c.y+4-s.y)
local dir_ang=atan2(s.xs,s.ys)
local dif=dif_ang(ang,dir_ang)
local mult=dif>.5 and .05 or .1
s.xs+=cos(ang)*mult
s.ys+=sin(ang)*mult
s.xs,s.ys=mid(s.xs*.985,4,-4),mid(s.ys*.985,4,-4)

trail[1]={x=s.x,y=s.y}
if abs(s.x-2-c.x)<10
and abs(s.y-4-c.y)<10
and s.dt>30 then
del(shot,s)
boomer_thrown,trail[1]=false
if boomer_obj then
boomer_obj.x=c.x
boomer_obj.y=c.y
end
end
if not boomer_obj then
for o in all(obj) do
local ox,oy=o.x,o.y
if abs(s.x-ox)<8 
and abs(s.y-oy)<8
and ox>camx
and oy>camy
and ox<camx+128
and oy<camy+128
and o.typ~=7 then
boomer_obj=o
if o.typ<6 then
new_obj(o.typ,ox,oy)
end
break
end
end
end
elseif styp==6 then
roomlight=true
local e=s.tgt
local aim=atan2(e.x+e.w*4-c.x-5,e.y+e.h*4-c.y-9)
s.ang=s.ang or aim

for e in all(enm) do
if circ_line_coll(c.x+5,c.y+9,c.x+5+cos(s.ang)*200,c.y+9+sin(s.ang)*200,e.x+e.w*4,e.y+e.h*4,e.h*5) then
dmg_enm(e,s)
end
end
s_laser,c.flip=true,(s.ang-.25)%1<.5
end
if styp~=6 then
if s.is_enm then
if abs(c.x+5-(s.x+4))<s.siz*4+4
and abs(c.y+7-(s.y+4))<s.siz*4+4 then

if styp==0
or styp==1
or styp==3
or styp==7 then
if styp==3 then
new_shot(4,s.x-4,s.y-4,0,0,s.is_enm)
end
del(shot,s)
end
if dash_dur<=-30 then
char_hurt()
end
end
else
for e in all(enm) do
if abs(e.x+e.w*4-(s.x+4))<e.w*4+s.siz*4
and abs(e.y+e.w*4-(s.y+4))<e.h*4+s.siz*4 then
dmg_enm(e,s)
if styp==0
or styp==1
or styp==3
or styp==7 then
if styp==3 then
new_shot(4,s.x-4,s.y-4,0,0,s.is_enm)
end
del(shot,s)
end
break
end
end
end
end
end
for i=6,2,-1 do
trail[i]=trail[i-1]
end

local xx,yy=d128m16(camx),d128m16(camy)
for i=xx,xx+15 do
for j=yy,yy+15 do
local mm=mget(i,j)

if mm==7 then
xstart,ystart=i*8,j*8-3
end

if mm==44
and roomdt480>120
and roomdt480<=240
or (mm==11
or mm==203) and lamp then
roomlight=true
end
end
end

for p in all(ptc) do
p.dt+=1
p.ys+=p.g
p.x+=p.xs
p.y+=p.ys
if p.typ==1 then
p.siz=p.siz*.97-.1
if (p.siz>10) p.siz*=.9
p.x+=sin(p.dt/42)/4
if (p.dt>=p.dur) del(ptc,p)
end
end

for i=0,5 do
f_btn[i]=btn(i)
end

local last_camx,last_camy=camx,camy
upd_cam()
if last_camx~=camx
or last_camy~=camy then
spawn_screen()
end
end
-->8
menuitem(1,"swap buttons 🅾️❎",function() ❎,🅾️=🅾️,❎ end)
function btnr(b)
return not btn(b) and f_btn[b]
end

function is_solid(i,j)
return fget(mget(i,j),7)
end

function char_hurt()
if not invinc then
hp-=1
ssfx"58,-1,0,16"
c.ys,c.xs,hurt,invinc=-1,c.flip and .75 or -.75,60,90
end
end

function new_expl(x,y)
ssfx"55,-1,0,16"
for i=0,10 do
mini_expl(x+rnd(16)-8,y+rnd(16)-8,rnd(8)+10)
end
new_light(x,y,30,30)
end

function mini_expl(x,y,sz)
local p=new_ptc(x,y)
p.siz,p.ys,p.dt,p.typ,p.xs,p.dur,p.g,p.wal=sz,rnd(.5)-.5,rnd(60),spl_unp"1,0,120,-.01"
return p
end

function dmg_enm(e,s)
if not e.invinc then
ssfx"62,-1,0,10"
e.hp-=s.dmg
if e.hp<=0 then
del(enm,e)
new_expl(e.x+e.w*4,e.y+e.h*4)
else
e.invinc=s.flinch\1
end
end
end

function swap_mode(m)
if m~=char_mode then
ssfx"61"
swap_mode_eff,char_mode=120,m
charge,pull=char_mode==0 and 0 or 600
if grab then
grab.thrown,grab.xs,grab.ys=true,c.flip and -1 or 1,-.5
grab=nil
end
end
end

function wall_coll(o)
if o.wal then
for i=(o.x+3)\8,(o.x-3)\8+1 do
for j=(o.y+5)\8,(o.y+3)\8+1 do
if is_solid(i,j) then

if o.typ==3
and mget(i,j)==29 then
for jj=j,j-5,-1 do
if mget(i,jj)==13 then
mset(i,jj,3)
break
else
mset(i,jj,0)
end
end
for jj=j,j+5 do
if mget(i,jj)==45 then
mset(i,jj-1,4)
break
else
mset(i,jj,0)
end
end
end

return true
end
end
end
end
end

function get_btn_dir(n)
local v,h=btn(⬆️) and -1 or btn(⬇️) and 1 or 0,btn(⬅️) and -1 or btn(➡️) and 1 or 0
if h==0 and v==0 then
h=c.flip and -1 or 1
elseif h~=0 and v~=0 then
h*=.75
v*=.75
end
return h*n,v*n
end

function dif_ang(ang,dir_ang)
return min(min(abs(ang-dir_ang),abs(ang-dir_ang+1)),abs(ang-dir_ang-1))
end

function ssfx(s)
sfx(spl_unp(s))
end

function spl_unp(s)
return unpack(split(s))
end

function upd_cam()
camx,camy=mid(0,128*7,(c.x+4)\128*128),mid(0,128*2,(c.y+4)\128*128)
end

function to_time(t)
return t\60 ..":"..t\10%6 ..t%10
end

function d128m16(n)
return n\128*16
end
-->8
function _draw()
dt22,dt84,dt53,dt42,dt2,trand=dt\2%2*2,dt%8<4,dt%5<3,dt%4<2,dt%2,rnd"0xffff.ffff"
srand(dt)
if title then
dt+=1
draw_bg()

if sel_diff then
?spl_unp"normal\n\n hard\n\nbadass,54,44,0"
?"▶",50,44+diff*12
for i=0,2 do
if dget(i)==1 then
?"★",80,44+i*12
has_t_att=true
end
if dget(i+3)==1 then
?"●",90,44+i*12
has_t_att=true
end
if dget(i+6)>0 then
?to_time(dget(i+6)),104,44+i*12
end
end

if has_t_att then
if t_att then
?spl_unp"time attack enabled!,26,100"
else
?spl_unp"press ⬅️ to enable\n   time attack\n (no checkpoints),30,100"
end

if btnp(⬅️) then
t_att=not t_att
end
end

for i=1,5-diff*2 do
spr(210,34+i*9+diff*9,78)
end
else
outline(sspr,spl_unp"0,0,0,64,80,32,25,22")
outline(sspr,spl_unp"0,0,80,64,48,32,40,50")
if dt%40<20 then
?"  press ❎ or 🅾️",spl_unp"30,100,0"
end
end
elseif stage_init>0 then
cls()
?split"    stage 1\n\n  rust harbor,    level 2\n\nscrap labirinth,    stage 3\n\n   last spark"[stage],spl_unp"34,54,7"
else
dt20=dt2==0
cls()
if stage==1 then
draw_bg()
elseif stage==2 or camy==0 then
for i=0,127,16 do
for j=-8,127,16 do
spr(14,i,j+i/2%16,2,2)
end
end
end
local shake=hurt and hurt>53 and 2 or 0
camera(camx+rnd(shake*2)-shake,camy+rnd(shake*2)-shake)

for o in all(obj) do
if o.typ==7 then
pal(split"1,3,8")
for i=10,-6,-2 do
local cx,cy=o.x+4,o.y+4
circfill(cx+sin((dt+i)/60)*(i/2-5),cy+cos((dt+i)/60)*(i/2-5),sin((dt+i)/90)*2+5+i,(i-dt\4)%3)
end
pal()
end
end

if lamp then
local x,y=camx\8,camy\8
for i=x,x+15 do
for j=y,y+15 do
if dt20
and (mget(i,j)==11
or mget(i,j)==203) then
for n=1,7 do
circfill(i*8+4,j*8+4,36-n*4+rnd(2),split"14,12,2,4,10,15,7"[n])
end
end
end
end
end

map(spl_unp"0,0,0,0,128,48,8")

if roomlight then
map(spl_unp"0,0,0,0,128,48,1")

maph=c.y\8+1
map(0,maph,0,maph*8,128,48-maph,2)
else
light(c.x+5,c.y+8,charlight,3)

for p in all(ptc) do
if p.typ==1 then
light(p.x,p.y,p.siz,3)
end
end
for l in all(lgt) do
light(l.x,l.y+4,l.r,3)
end
for s in all(shot) do
light(s.x+4,s.y+4,s.lgt,3)
end
end

local clr=8
for tile_x=(c.x+6)\8-1,(c.x+6)\8+1 do
clr+=1
local r=5.5
for i=c.y\8+2,c.y\8+10 do
if (fget(mget(tile_x,i),6)) break
if is_solid(tile_x,i) then
clip((tile_x*8)%128,spl_unp"0,8,0x7fff")
local r=max(r\1,3)
ovalfill(c.x+10-r*2\1,i*8-1-r,c.x+1+r*2\1,i*8-7+r,14)
break
end
r-=.5
end
end
clip()

if not invinc or dt84
or wait_death or
swap_mode_eff
then
if char_mode==5 and charge>=180 then
for i=1,3 do
for n=0,1 do
circfill(c.x+(c.flip and -3 or 14),c.y+8+n,6-i-dt22,split"11,15,7"[i])
end
end
end
if char_mode==2
or char_mode==5 then
if char_mode==5 then
pal(4,3)
pal(9,8)
pal(10,11)
end
spr(214,c.x+(c.flip and 7 or -3),c.y+5,1,1,c.flip)
end
if char_mode==-1
or char_mode==0
or char_mode==5 then
spr(56,c.x+(c.flip and -5 or 9),c.y+5,1,1,c.flip)
elseif char_mode==4 then
if (wmag or grab or pull)
and dt%10<5 then
pal(6,11)
pal(13,8)
end
spr(213,c.x+(c.flip and -3 or 7),c.y+5,1,1,c.flip)
elseif char_mode==1 then
spr(212,c.x+(c.flip and -2 or 6),c.y-1,1,1,c.flip)
elseif char_mode==3
and not boomer_thrown then
spr(215,c.x+(c.flip and -2 or 6),c.y+5,1,1,c.flip)
end
pal()
spr(32+(walk and dt\8*2%8 or 0),c.x+(c.flip and -4 or 0),c.y,2,2,c.flip)

if (char_mode==0 
or char_mode==2 and dash_dur>-15)
and dt53 then
if (char_mode==0 and charge>=30) spr(5,c.x+(c.flip and -10 or 6),c.y,2,2,rnd()<.5,rnd()<.5)
if charge>=60 or char_mode==2 then
spr(7,c.x+(c.flip and -4 or 0),c.y,2,2,c.flip)
end
end

if (char_mode==5 and charge>=180
or s_laser)
and dt53 then
pal(split"1,2,3,8,5,6,7,8,11,11,11,12,13,14,11,0")
spr(7,c.x+(c.flip and -4 or 0),c.y,2,2,c.flip)
s_laser=nil
end
end
pal()

if roomlight then
map(0,0,0,0,128,maph,2)
end

for i=d128m16(camx),d128m16(camx)+15 do
for j=d128m16(camy),d128m16(camy)+15 do
local ii,jj=i*8+4,j*8+8
if mget(i,j)==44 then
if roomdt480>120
and roomdt480<=240 then
if roomdt480==121 then
ssfx"59"
end
circfill(ii,jj,7+dt22,10)
for x=i*8-12,camx-20,-16 do
spr(238,x,j*8,2,2,dt84,dt42)
end
circfill(ii,jj,6+dt22,15)
circfill(ii,jj,4+dt22,7)

if c.x<i*8
and abs(c.y+8-(j*8+8))<12 then
char_hurt()
end
elseif roomdt480>30
and roomdt480<200
or roomdt480<255
and roomdt480>120 then
new_light(i*8+4,j*8+8,28,2)
circfill(ii,jj,7+dt22,10)
circfill(ii,jj,6+dt22,15)
circfill(ii,jj,4+dt22,7)
end
end
end
end

function heli_pal(e)
if e and e.typ==5 then
clr={[0]=13,6,7,6}
pal(2,clr[dt\4%4])
pal(4,clr[(dt\4+1)%4])
pal(15,clr[(dt\4+2)%4])
end
end
for e in all(enm) do
local etyp=e.typ
if etyp==0 and dt42 then
spr(18,e.x,e.y+8)
end
if e.invinc
and dt42 then
pal(split"12,4,8,9,13,7,7,11,10,15,15,3,6,2,7")
end
heli_pal(e)
if etyp==3 then
local hh=e.cdwn==120 and 0 or e.cdwn<55 and 3 or sin(e.cdwn/30)*1.4+1.5
sspr(32,121,16,7,e.x,e.y+9)
sspr(32,112,16,9,e.x,e.y+hh)
else
if e.cdwn<=10 and dt42 then
if etyp==1 then
pal(split"3,2,8,4,5,6,7,11,9,10,15,12,13,14,7")
elseif etyp==5 then
pal(9,15)
pal(10,7)
end
end
spr(e.sprt,e.x,e.y,e.w,e.h,e.flip)
end
pal()
if etyp==6 then
circ(e.x+8,e.y+8,10+sin(dt/85)*2,7)
end
end

if char_mode==4 then
local e=closest or grab or pull
heli_pal(e)
if (e) outline(spr,11+dt22*2,0,e.sprt,e.x,e.y,e.w,e.h,e.flip)
pal()
end

if char_mode==5
and charge>=180
and dt20 then
for e in all(enm) do
if e==closest then
local ang=atan2(e.x+4-c.x-5,e.y+4-c.y-9)
line(e.x+e.w*4,e.y+e.h*4,c.x+5,c.y+9,11)
break
end
end
end

if trail then
if trail[6] then
pal(7,13)
spr(9,trail[6].x-4,trail[6].y-4,2,2,dt20,dt22==0)
end
if trail[4] then
pal(7,6)
spr(9,trail[4].x-4,trail[4].y-4,2,2,dt20,dt22==0)
end
pal()
end

for p in all(ptc) do
if p.typ~=1 then
circfill(p.x,p.y,p.siz,p.clr)
p.siz*=.9
if p.wal 
and is_solid(p.x\8,p.y\8)
and p.dt>10
or p.dt>p.dur
then
del(ptc,p)
end
end
end

for s in all(shot) do
if s.typ==7 then
pal(15,dt\2*4%12+7)
end
spr(s.spr,s.x-s.siz*4+4,s.y-s.siz*4+4,s.siz,s.siz,dt20,dt22==0)
pal()
if s.tgt then
for w=1,3 do
rr=split"6,4,2"[w]
local clr=split"11,15,7"[w]
circfill(c.x+5+cos(s.ang)*10,c.y+9+sin(s.ang)*10,rr+sin(dt/3)+1,clr)
for i=10+dt2*3,180,rr+1 do
circfill(c.x+5+cos(s.ang)*i,c.y+9+sin(s.ang)*i,rr+sin(dt/3),clr)
end
end
end
end

for i=0,4 do
for p in all(ptc) do
if p.typ==1 then
local x,y,sz,ys=p.x,p.y,p.siz,p.ys
xx,yy=sin(p.dt/60)/sz*2+rnd(1.5)-.75,cos(p.dt/60)/sz*2+rnd(1.5)-.75
circfill(x+xx*i,y+yy*i,sz*(1+max(0,i/10-.1))-i*1.5,i==0 and ((sz>5) and 4 or 5) or split"9,10,15,7"[i])
end
end
end

for o in all(obj) do
local otyp=o.typ
if otyp<6 then
palt(0,false)
local rot=ceil(sin(dt/120)*4-.5)
x1,x2=o.x+3-rot,o.x+4+rot
if x1>x2 then
x1+=1
x2-=1
end
local hh=ceil(cos((dt+40)/90)*3)
rectfill(x1,o.y-1+hh,x2,o.y+8+hh,1+dt\4%2*2)
pal(0,dt\4%2*12)
sspr(otyp*8+80,32,8,8,o.x+4-rot,o.y+hh,rot*2,8)
pal()
elseif otyp==6 or otyp==8 then
spr(otyp==6 and 210 or 248,o.x+sin(dt/95)*2+.5,o.y+sin(dt/60)*2+.5)
end
end

if swap_mode_eff and not message then
local x1,y1,x2,y2=c.x+1,c.y-11,c.x+11,c.y-2
rectfill(x1,y1,x2,y2,0)
rect(x1,y1,x2,y2,1+dt22)
spr(char_mode+74,x1+1,y1+1)
end
camera()

spr(spl_unp"200,1,1,2,3")
palt(0,false)
spr(char_mode+74,4,4)
if (char_mode>=0)spr(char_mode+194,4,14)
pal()
for i=1,maxhp do
spr(i<=hp and 210 or 211,i*9+7,2)
end

if show_collect then
spr(spl_unp"248,108,2")
?collect,spl_unp"118,4,7"
end

if message then
mdt,messagedt=mdt and mdt+1 or 0,message.dt
local h=abs(-sin(messagedt/120)*40)
if messagedt>30 
and messagedt<=90 then
h=40
end
clip(0,64-h,128,h*2,0)
rectfill(spl_unp"0,0,128,128,0")

if messagedt>30
and messagedt<=90 then
palt(0,false)
outline(spr,1,1,message.typ+74,10,41)
outline(spr,1,1,message.typ+194,10,65)
?msg[message.typ+1],spl_unp"25,40,13"

if messagedt>=90 then
pressx=pressx and pressx+1 or 0
if pressx%60<30 then
?spl_unp"press 🅾️/❎,40,84,6"
end
end
end

?"▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒",0,64-h+2,1
?"▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒",0,64+h-7,1
clip()
pal()
end

if t_att then
?to_time(tim),spl_unp"16,12,7"
end

end
pal(split"129,132,131,4,5,6,7,3,137,9,11,133,13,128,10",1)
srand(trand)
end
-->8
function draw_bg()
cls"9"
camera()
rectfill(0,64,127,127,5)

for i=1,3 do
circfill(64,32,15-i*2+dt2,split"10,15,7"[i])
end

trand=rnd"0xffff.ffff"
for c=0,1 do
for i=0,20 do
srand(1+i)
local x,y=(i*4+40+dt/100)%160-16,(rnd(15)-2)*sin(i/40)+45+c
circfill(x,y,(rnd(10))*-sin(i/40)+3-c,15+c*-5)
end
end

srand"24"
for i=-8,127,8 do
rectfill(i+rnd(8),30+rnd(32),i+16+rnd(8),63,12)
end

for j=64,127 do
local spc=(j-63)/8+8
for i=0,148,spc do
local n,w=(i+rnd(8)+dt/120*spc)%148-10,sin(rnd(1)+dt/90)*spc/2
if w>0 then
local pxh=192-j*2
rectfill(n-w,j,n+w,j,pxh>0 and pget(n%128,pxh) or 4)
end
end
end
srand(trand)
end

function light(x,y,r,l)
srand(dt)
r=r+rnd(2)
for i=-r+1,r-1 do
local yy,w=y+i,(sqrt(r^2-i^2)-.01)\1
tline(
x-w,yy,
x+w,yy,
(x-w)/8,yy/8,
.125,0,l)
end
srand(trand)
end
-->8
function outline(draw,c,t,...)
local o_pal,camx,camy={},camera()
for i=0,15 do
o_pal[i]=pal(i,c)
end
for i=-1,1 do
for j=-1,1 do
if abs(i^^j)==1 or t==1 then
camera(camx+i,camy+j)
draw(...)
end
end
end
camera(camx,camy)
pal(o_pal)
draw(...)
end


-->8
function circ_line_coll(x1,y1,x2,y2,xc,yc,rc)
local delta_x,delta_y,x_intersect,y_intersect=x2-x1,y2-y1,xc,xc

if delta_x==0 then
x_intersect=x1
elseif delta_y==0 then
y_intersect=y1
else
local slope,right_slope=delta_y/delta_x,delta_x/delta_y*(-1)

x_intersect,y_intersect=(yc+slope*x1-y1-right_slope*xc)/(slope-right_slope),right_slope*(x_intersect-xc)+yc
end

local xx,yy=mid(x_intersect,x1,x2)-xc,mid(y_intersect,y1,y2)-yc

return abs(sqrt(xx*xx+yy*yy))<=rc
end
