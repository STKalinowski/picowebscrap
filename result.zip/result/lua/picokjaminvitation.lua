--pico 1k jam invitation
--by @p01
T=0H=0cls()
?"★ pico-1k jam SEPTEMBER 2021 SU\nBMIT A 1024 CHARS GAME,DEMO OR T\nOOL FOR PICO◆8 TO ITCH.IO/JAM/P\nICO-1K  ♥ @P01"
memcpy(0,24576,1920)::_::cls()T%=48P=T/8local s,V,i,u,w,a,b,B,f,g=sin,max(1,9+sin(P/12)*32)for y=0,135do
c=.2+abs(y/64-1)^2x=y^9.76%1pset((x-t()*c)%1*132-4,64+(y-64)*V*2,5+x*2)i=(P-1)*99+y/12
u=s(t()/19-y/512)*mid(0,1,P/2)/5+s(P/.9)/9-.25w=(24+H)*s(u)a=.5b=4*cos(u)B=72-w+9*s(u)f,g=i%128,i\128*6for z=1,5do
if(z*sgn(w)>4)a=P+y/135+8
pal(6,a+rnd())sspr(f,g,1,6,y-z,B+z*b,1,w*2)end
pset(y,@(4096+y)/4+32,6)end
if stat(108)<255then
local C,S,v={440,523,659,784}for i=0,255do
S=s(T*48)*64/V*(1-T*2%1^8)-128H=P&11>0and({8,2,4,2})[T*4\1%4+1]*(1-(T*4%1))^4or 0S+=s(rnd())*H
v=min(1,P^4)*4if(P%3>0)S+=v*s(T*C[(T*2&3)+1])
if(P%5>2)S+=v*s(T/2*C[(T*8&3)+1])
poke(4096+i,S)T+=1/5520end
serial(2056,4096,256)end
y=24*(2-V)-H
?"\^w\^i\^b pico-1k \n\^-i\*5 \^-w \^w\^i JAM ",14,y,7
?"ITCH.IO/JAM/PICO-1K",36,139-y
flip()goto _