t=0
rar=3			--3,9,27,81
pause=0
hi=0
dls={}
grid={}
ready=false


function menu()
 
 ents={}
 bads={}
 new_hishcore=nil
 dx=0 dy=0
 vx=1 vy=2
 page=0
 acc=1.5
 
 h.u=function() 
  dx=cos((t%200)/200)*32
  dy=4+cos((t%120)/120)*16
  dx=mod(dx,8)
  dy=mod(dy,8)
 end
 
 h.d=function()

  draw_menu_bg()
  for i=0,4 do
   x=42
   y=48+i*9
   spr(36+i,x,y)
   names={"ghost","snipe","demon","squid","guard"}
   print(names[1+i],x+12,y+2,7)
   sspr(88,0,3,3,x+36,y+4)
   print(i+1,x+40,y+2,7)
  end
 
 
  if hi>=0 then
   x-=2
   if(hi>9) x-=2
   if(hi>99) x-=2
   if(hi>999) x-=2
   print("high score:",x,100)
   print(hi,x+44,100)
  end
 
  if(t%16<8) print("press <z> to start",28,118,7)
  btnc(4,function() h.d=draw_menu end,7)
 end
 
end

function draw_menu()
 draw_menu_bg()
 labels={"single","cooperative","versus"}
 
 for i=1,3 do
  color=7
  if i==mode+1 then
   color=9
   spr(36,40,64+i*8)
  end
  print(labels[i],48,66+i*8,color)
 end
 
 if(btnp(2)) mode-=1
 if(btnp(3)) mode+=1
 if(btnp(4)) start()
 mode=mid(0,mode,2)
 
end


function draw_menu_bg()
 for i=0,1 do
  if i==0 then
   apal(1)
  else
   clip(8,8,112,104)
  end
  for x=0,16 do for y=0,16 do
   spr(16,x*8+dx-8,y*8+dy-8)
  end end
  clip()
  pal()
 end
 rect(0,0,127,127,1)
 sspr(0,32,40,20,21,0,80,40)
end


function mod(n,k)
 while(n>=k) do n-=k end
 while(n<0) do n+=k end
 return n
end

function start()

 gmo=nil
 
 h.u=upd
 h.d=draw_game
  
 heroes={}
 max_player=2
 if(mode==0) max_player=1
 for i=1,max_player do 
  e=mkh()
  e.pid=i-1
  e.x=64
  if(mode>0) e.x+=(e.pid*2-1)*24
  e.y=64
 end
 
 if mode>0 then
  heroes[1].opp=heroes[2]
  heroes[2].opp=heroes[1]
 end

 grid={}
 paint_grid()
 
 score=0
 time=99
 pow=0
end

function mkh()
 e=mke()
 e.u=ctrl
 e.player=true
 e.fr=3
 e.ca=0
 e.fam=0
 e.hb=1
 e.hp=1
 e.r=2
 e.score=0
 e.cd=0
 e.dr=function(e)
  spr(7+e.ca*4,e.x-4,e.y-4)
 end
 add(heroes,e)
 return e
end


function ctrl(e)
 e.cd-=1
 
 spd=1
 function move(vx,vy,a)
  e.vx=vx*spd
  e.vy=vy*spd
  if( not btn(4) ) e.ca=a*0.25
  e.fr=3+(a%2)*2+flr(t%16/8)
 end
 
 e.vx=0 e.vy=0 
 if(btn(0,e.pid)) move(-1,0,2)
 if(btn(1,e.pid)) move(1,0,0)
 if(btn(2,e.pid)) move(0,-1,1)
 if(btn(3,e.pid)) move(0,1,3)

 if btn(4,e.pid) and e.cd<=0 then
  fire(e,0.01)
  e.cd=8
 end
 
 if not is_in(e,10) then
  e.x=mid(10,e.x,129-10)
  e.y=mid(10,e.y,121-10)
 end
 

end

function fire(e,ra,da)
 if(gmo) return
 sfx(1)
 b=mke()
 b.r=1
 b.fam=e.fam
 b.x=e.x b.y=e.y
 b.fr=1 b.lp=2 b.lm=4
 b.spd=3
 b.a=e.ca
 b.from=e
 if b.fam==1 then 
  b.fr=52 b.lp=3
  trg=get_trg(e)
  if(trg) ori(b,trg.x,trg.y)
  b.spd=0.5
 end
 
 if(ra!=nil) b.a+=rnd(ra*2)-ra
 if(da!=nil) b.a+=da
 b.vx=cos(b.a)*b.spd
 b.vy=sin(b.a)*b.spd
 b.u=upd_bul
end

function get_trg(e)
 if(#heroes==1)  return heroes[1]
 
 px=flr(e.x/gs)
 py=flr(e.y/gs)
 return grid[py*gxm+px+1]
end

function upd_bul(e)
 if e.bc==nil then
  c=gcol(e)
  if c!=nil then
   hit(c,e)
   return
  end
  if not is_in(e,4)  then
   if e.fam==0 then
    e.bc=getc(e.x,e.y)
    e.vx=0 e.vy=0
    e.bs=0.02+rnd(0.02)
    e.bd=rand(2)*2-1
    sfx(2)
   else
    kl(e)
    return
   end
  else
   return
  end
 end
 
 e.bs*=0.95
 e.bc=(e.bc+e.bs*e.bd)%1
 e.x,e.y=getp(e.bc)

 if e.bs<0.001 then
  kl(e)
  b=mkb()
  b.x=e.x b.y=e.y
  sfx(3)
 end
end

function gcol(e) 
 if e.fam==1 then
  for he in all(heroes) do
   if(acol(e,he,0)) return he
  end
		return
 end
 
 for b in all(bads) do
  if( acol(e,b,0) ) return b
  if(b.sh and scol(e,b,4+b.sh*2)) return b
 end
end
function acol(a,b,er)
 l=a.r+b.r+er
 return abs(b.x-a.x)<l and abs(b.y-a.y)<l
end
function scol(a,b,c)
 dx=a.x-b.x
 dy=a.y-b.y
 return sqrt(dx*dx+dy*dy) < a.r+b.r+c
end

function bounce(a,b,r)
 bnc+=1
 dx=a.x-b.x
 dy=a.y-b.y
 d=(a.r+b.r-r-sqrt(dx*dx+dy*dy))/2
 if d>0 then
  n=atan2(dx,dy)
  rx=cos(n)*d
  ry=sin(n)*d
  a.x+=rx a.y+=ry
  b.x-=rx b.y-=ry
 end
end

function kill_player(e)
 if(e.dead) return
 e.dead=true
 paint_grid()
 red_flash=1
 pause=20
 sfx(5)
 dl(2,function() hero_xpl(e) end )
 
 go=true
 if mode==1 then
  for he in all(heroes) do
   if(not he.dead) go=false
  end 
 end
 
 if(go) game_over()
 
 
end

function game_over()
 
 if( score>hi ) then
  hi=score
  new_hishcore=1
 end
 gmo=1
 
 for e in all(ents) do
  if( not e.player ) kl(e)
 end
 h.u=function()
  btnc(4,menu,9)
 end
 
 if mode==2 then
  for he in all(heroes) do
   if(he.score < he.opp.score) he.dead=true
  end
 end
 
end

function hero_xpl(he)
 
 adc(he.x,he.y,8,96,4,4)

 sfx(6)
 
 kl(he)
 spd=2
 for i=0,32 do
  a=i/32
  e=pop(he)
  e.vx=cos(a)*spd
  e.vy=sin(a)*spd
  e.f=0.92+0.025*((i%2) + (i%3) +i%4)
  e.fr=19 e.lp=3 e.lm=2
  e.life=10+i%10
 end
  
end

function btnc(k,f,s)
  if btn(4)  then 
   if ready then
    ready=false
    sfx(s)
    f()
   end
  else
   ready=true
  end
end

function hit(e,b)

 if e.player then
  kill_player(e)
  return
 end
 
 if e.sh then
  adc(e.x,e.y,4+e.sh*2,nil,1)
  sfx(8)
  flh(e,3)
  e.sh-=1
  if(e.sh<=0) e.sh=nil
  kl(b)
  return
 end

 sfx(4)
 e.hp-=1
 flh(e,0)
 e.vx+=b.vx e.vy+=b.vy
 if(e.hp<=0) xpl(e,b.from)
 kl(b)
end

function flh(e,g)
 e.flh={}
 e.flh.t=8
 e.flh.g=g
end
function adc(x,y,sr,er,g,md)
 if(er==nil) er=sr
 if(g==nil) g=2
 if(md==nil) md=1
 e=mke()
 e.x=x
 e.y=y
 e.life=8*md
 e.dr=function(e)
  c=sget(e.life/md,24+g) 
  co=e.life/(8*md)
  co=1-co*co
  circ(e.x,e.y,sr+(er-sr)*co,c)
 end
 return e
end

function xpl(e,from)
 local pts=pow*(e.fr-35)
 score+=pts
 
 if(from) from.score += pts
 
 
 pow-=1
 kl(e)
 
 adc(e.x,e.y,8,12,4)
 sfx(e.fr-26)
 
 p=pop(e)
 p.life=20
 p.dp=1
 p.dr=function(e)
  c=7
  if( shade ) c=0
  print(pts,e.x-4,e.y-e.t/4,c)
 end
 
end
function pop(e)
 b=mke()
 b.x=e.x
 b.y=e.y
 return b
end

function kl(e)
 e.dead=true
 if(e.fam==1) del(bads,e)
 del(ents,e)
end

function mkb()
 e=mke()
 add(bads,e)
 pow+=1
 e.hb=1
 
 
 e.fam=1
 e.f=0.75
 e.t=rand(80)
 
 -- blue
 e.fr=36
 e.hp=3
 e.u=function(e)
  hcol(e)
  if(e.t%4==0) fol(e)
 end
 if(rand(rar)>0 ) return e
 
 -- yellow
 e.fr=37
 e.hp=3
 e.u=function(e)
  wander(e,0.15)
  hcol(e)
  if e.t>160 then
   fire(e,0.07)
   e.t=0
  end
 end
 if(rand(rar)>0) return e
 
 -- pink
 e.fr=38
 e.hp=10
 e.u=function(e)
  hcol(e)
  if(e.t%2==0) fol(e)
 end
 
 if(rand(rar)>0) return e
 
 -- green
 e.fr=39
 e.hp=10
 e.u=function(e)
  wander(e,0.3)
  hcol(e)
  if e.t>160 then
   for i=0,12 do fire(e,0,i/12)
end
   e.t=0
  end  
 end
 if(rand(rar)>0) return e
 
 -- orange
 e.fr=40
 e.hp=2
 e.sh=16
 e.u=function(e)
  hcol(e)
  if(e.t%4==0) fol(e)
 
 end
 return e
end

function hcol(e) 
 for he in all(heroes) do
  if(acol(e,he,-2)) kill_player(he) 
 end
end

function wander(e,spd)
 if(e.a==nil or not is_in(e,8)) ori(e,64,64)
 e.x+=cos(e.a)*spd
 e.y+=sin(e.a)*spd
 e.a+=(rnd(2)-1)/40
end

function ori(e,x,y)
 e.a=atan2(x-e.x,y-e.y)

end
function fol(e) 
 trg=get_trg(e)
 if(not trg) return
 ori(e,trg.x,trg.y)
 e.x+=cos(e.a)
 e.y+=sin(e.a) 
end


function getp(c)
 if(c<0.25) return 4+c*480,4
 if(c<0.5) return 124,4+c*448-112
 if(c<0.75) return 124-(c*480-240),116
 return 4,116-(c*448-336)
end

function getc(x,y)
 if(y<=4) return (x-4)/480
 if(x>=124) return (y-4)/448+0.25
 if(y>=116) return 0.75-(x-4)/480
 if(x<=4) return 1-(y-4)/448
end


function is_in(e,ma)
 return e.x>=ma and e.y>=ma and e.x<128-ma and e.y<120-ma
end


function upd()
 if(t%30==0) time-=1
 if(time==0) game_over()
 -- bounce
 bnc=0
 
 for a in all(bads) do a.done=false end
 for a in all(bads) do
  a.done=true
  for b in all(bads) do
   if not b.done and acol(a,b,-1) then
    bounce(a,b,1)
   end
  end
 end
 --
 if mode>0 then
  bounce(heroes[1],heroes[2],-2)
 end
 
 --log(bnc)
 paint_grid()
 

end

function paint_grid()

 f=function(k)
  grid[k]=dx^2+dy^2
 end
 
 for h in all(heroes) do
  for i=0,gxm*gym-1 do
   px=(i%gxm)*gs+gs/2
   py=flr(i/gym)*gs+gs/2
   dx=h.x-px
   dy=h.y-py
   if h.dead then
    dx=99 dy=99
   end
   f(i+1)  
  end 
  f=function(k)
   d=dx^2+dy^2 j=1
   if(d<grid[k]) j=2
   grid[k]=heroes[j]
  end
 end

end


function dl(t,f)
 d={} d.f=f d.t=t
 add(dls,d)
end

function draw_game()
 
 if red_flash and pause>0 then
  cl=sget(min(pause/3,7),24)
  apal(cl)
 end
 for x=0,15 do
  for y=0,15 do
   spr(mget(x,y),x*8,y*8)
  end
 end
 pal()
 
 -- test grid
 --for i=0,gxm*gym-1 do
  --px=i%gxm
  --py=flr(i/gxm)
  --cl=1
  --if(grid[i+1]==heroes[2])cl=2
  --rectfill(px*gs,py*gs,px*gs+gs,py*gs+gs,cl)
 --end

 --if gmo and t%32<16 then
 -- print("press <z> to continue",21,120,7)
 -- return
 --end
 
 
 -- score
 if mode==2 then
  i=0
  for he in all(heroes) do
   x=2+i*40
   print("pl"..(i+1),x,120,7)
   str=he.score
   if time>0 or t%32<16 then
    if(he.dead) str="loose"
    if(he.opp.dead) str="win!"
   end
   
   print(str,x+14,120,8+i) 
   i+=1
  end
  
 else
  if new_hishcore then 
   if t%16>4 then
    print("hi-score:",2,120,7)
    print(score,38,120,sget(t%8,29))
   end
  else
   print("score:",2,120,7)
   print(score,26,120,7)
  end
 end
 
 -- time
 c=7
 if(time<10 and t%8<4 and not gmo ) c=8
 print("time:",99,120,c)
 print(time,99+20,120,c) 
 
end


-- libs
function rand(n) return flr(rnd(n)) end


--
function upe(e)
 e.t=e.t+1
 e.vx *= e.f
 e.vy *= e.f
 e.x += e.vx
 e.y += e.vy
 if(e.u!=nil) e.u(e)
 
 if e.life!=nil then
  e.life-=1
  if(e.life==0) kl(e)
 end

end

function dre(e)
 f=e.fr
 if e.lp != nil then
  f+=(t%e.lp*e.lm)/e.lm
 end
 
 
 if not shade then
  if e.pid==1 then
   pal(2,4)
   pal(8,9)
  end
  if e.flh then
   l=e.flh
   l.t-=1
   apal(sget(l.t,24+l.g))
   if(l.t==0) e.flh=nil
  end
 end
 

 

 
 if(f>0) spr(f,e.x-4,e.y-4)
 if(e.dr!=nil) e.dr(e)
 if( not shade ) pal()
 
end

function mke()
 e={}
 e.x=0 e.y=0 e.fr=0 e.t=0 e.r=4
 e.vx=0 e.vy=0 e.life=0 e.f=1
 add(ents,e)
 return e
end


function apal(n)
 for i=0,15 do pal(i,n) end
end

function _init()
 h={}
 gs=8
 gxm=flr(128/gs)
 gym=flr(128/gs) 
 mode=0
 menu()
end

function _draw()
 cls()
 h.d()
 
 shade=true
 camera(-1,-1)
 apal(1)
 foreach(ents,dre)
 pal() 
 camera() 
 shade=false
 
 foreach(ents,dre)
 
 if(log_txt!=nil) print(log_txt,0,0,7)

end

function _update()
 if pause>0 then
  pause-=1
  return
 end
 t=t+1
 h.u()
 foreach(ents,upe)
 
 for d in all(dls) do
  d.t-=1
  if d.t<=0 then
   del(dls,d)
   d.f()
  end
 end

end

function log(n)
 log_txt=n
end




