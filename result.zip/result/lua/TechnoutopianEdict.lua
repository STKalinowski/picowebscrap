--techno-utopian edict
--by jumalauta

function draw_terrain(jumpheight, q)
 pal()
 palt()
 rq={}

 obj={}
 for x=1,4 do
  for z=max(11,flr(f2*0.1)+1),min(100,flr(f2*0.1)+4) do
   depth,c,d=f2*0.1-z,1,1
   if depth>-3 then c=2 end
   if depth>-1 then c=9 end
   if blink==true then c,d=7,jumpheight end
   newtri1,newtri2={{(-3+x)*3,terrain_grid[x][z]*d,-z*2.4},{(-3+x)*3,terrain_grid[x][z+1]*d,-(z+1)*2.4},{(-2+x)*3,terrain_grid[x+1][z+1]*d,-(z+1)*2.4},{0,0,0},col=c},{{(-2+x)*3,terrain_grid[x+1][z+1]*d,-(z+1)*2.4},{(-2+x)*3,terrain_grid[x+1][z]*d,-z*2.4},{(-3+x)*3,terrain_grid[x][z]*d,-z*2.4},{0,0,0},col=c}
   add(obj,newtri1)
   add(obj,newtri2)
  end
 end
 
 translate(obj,0,-3,-1+f2*0.1*2.4)
 rotate(obj,q,"z")
 send_to_queue_wireframe(obj)
 render_queue_wireframe()
 
end

function sparkles_object(start,a,b,c,d,e,rot1amount,rot1axis,rot2bool,rot2amount,rot2axis,zdepthmod,wireframebool)
 if sparkles_phase>start and sparkles_phase<start+1.5 then
  rq={}
  obj=polyring(a,b,c,d,e)
  rotate(obj,f*rot1amount,rot1axis)
  if rot2bool==true then rotate(obj,f*rot2amount,rot2axis) end
  translate(obj,0,0,zdepth*zdepthmod)
  send_to_queue(obj)
  if sparkles_phase<start+0.5 then clip(0,sparkles_y,128,128) end
  if sparkles_phase>start+1 then clip(0,0,128,sparkles_y) end
  if wireframebool==true then render_queue_wireframe() else render_queue() end
  clip()
 end
end
 
function horizontal_scramble(glitchlen, glitchamt, glitchdist)
 for i=1,glitchamt do
  y=flr(rnd(128))
  madd1=min(0x6000+y*64+flr(rnd(64)), 0x6000-glitchlen+(y+1)*64)
  madd2=mid(0x6000+y*64, 0x6000-glitchlen+(y+1)*64, madd1+flr(rnd(glitchdist))*2-glitchdist)
  for i2=0,glitchlen-1 do
   a=peek(madd1+i2)
   b=peek(madd2+i2)
   poke(madd1+i2, b)
   poke(madd2+i2, a)
  end
 end
end

function print_font(startx,y,strtable)
 local x
 x=startx
 for i in all(strtable) do
  sspr(i[1],i[2],i[3],10,x,y)
  x+=i[3]+2
 end
end
 

function rle_decomp(str)
 output=""
 i=1
 while i<#str do
  length=tonum("0x0"..sub(str,i,i))
  i+=1
  chr=sub(str,i,i)
  for i2=1,length do
   output=output..chr
  end
  i+=1
 end
 return output
end

function spr_to_str_scan(startx, starty, endx, endy)
 local str=""
 for ready=starty, endy do
  if ready>starty then startx_this=0 else startx_this=startx end
  if ready<endy then endx_this=127 else endx_this=endx end
  for readx=startx_this, endx_this do
   str=str..sub(tostr(sget(readx,ready), true),6,6)
  end
 end
 return str  
end

function str_to_spr_scan(writex, writey, str)
 for i=1,#str do
  sset(writex, writey, tonum("0x0"..sub(str, i, i)))
  writex+=1
  if writex==128 then
   writey+=1
   writex=0
  end
 end
end

function integer_script(script)
 local val
 for i in all(script) do
  if f>=i[1] then
   val=i[2]
  end
 end
 return val
end
 

function parse_table(str)
 local nextstr,nextindex,tbl,i="",{},{},1
 for i=1,#str do
  nc=sub(str,i,i)
  if nc!="_" and nc!="|" then nextstr=nextstr..nc end
  if nc=="_" or nc=="|" then
   add(nextindex, nextstr)
   nextstr=""
  end
  if nc=="|" then
   add(tbl, nextindex)
   nextindex={}
  end
 end
 return tbl
end

function copy(object, x,y,z)
 local c
 c={}
 for i in all(object) do
  tri=
  {
   {i[1][1], i[1][2], i[1][3]}, {i[2][1], i[2][2], i[2][3]}, {i[3][1], i[3][2], i[3][3]}, {i[4][1], i[4][2], i[4][3]},
   col=i["col"]
  }
  add(c, tri)
 end
 return c
end

function round(t)
 return flr(t+0.5)
end

function shade(shadecol)
 lightstep,lightphase=flr(light/16),light%16+1
 color(16*shdpal[shadecol][lightstep+1]+shdpal[shadecol][lightstep])
 fillp(shades[lightphase])
end

function trifill(v)

  for i2=1,#v do
   local j=i2
   while j>1 and v[j-1][2]>v[j][2] do
    v[j],v[j-1]=v[j-1],v[j]
    j-=1
   end 
  end
 
 x1,x2,x3,y1,y2,y3=v[1][1],v[2][1],v[3][1],v[1][2],v[2][2],v[3][2]
  
 x4=x1+((y2-y1)/(y3-y1))*(x3-x1)
  
 flat_trifill(x1,y1,x2,y2,x4,1)
 flat_trifill(x3,y3,x2,y2,x4,-1) 

end

function flat_trifill(xa,ya,xb,yb,xc,direction)
 slope1,slope2,xa2=(xb-xa)/(yb-ya),(xc-xa)/(yb-ya),xa
 for scany=ya,yb,direction do
  line(xa,scany,xa2,scany)
  xa+=direction*slope1
  xa2+=direction*slope2
 end
end

function send_to_queue_wireframe(object)

 for i in all(object) do
 
  v={
   {
    round(-63.5*(i[1][1]/i[1][3])+63.5),
    round(-63.5*(i[1][2]/i[1][3])+63.5)
   },
   {
    round(-63.5*(i[2][1]/i[2][3])+63.5),
    round(-63.5*(i[2][2]/i[2][3])+63.5)
   },
   {
    round(-63.5*(i[3][1]/i[3][3])+63.5),
    round(-63.5*(i[3][2]/i[3][3])+63.5)
   }
  }

  depth=1

  light=200
 
  add(rq, {v[1],v[2],v[3],col=i["col"],light=light,depth=depth})

 end
end

function send_to_queue(object)

 for i in all(object) do
 
  v={
   {
    round(-63.5*(i[1][1]/i[1][3])+63.5),
    round(-63.5*(i[1][2]/i[1][3])+63.5)
   },
   {
    round(-63.5*(i[2][1]/i[2][3])+63.5),
    round(-63.5*(i[2][2]/i[2][3])+63.5)
   },
   {
    round(-63.5*(i[3][1]/i[3][3])+63.5),
    round(-63.5*(i[3][2]/i[3][3])+63.5)
   }
  }
  
  --determine if backface
  area=((v[2][1]-v[1][1])*(v[3][2]-v[1][2])-(v[3][1]-v[1][1])*(v[2][2]-v[1][2]))/2  

  --cull backfaces and send rest to render queue
  if area>0 then  
  
   --calculate normal
   if recalc_normals==true then
    d1={
     i[2][1]-i[1][1],
     i[2][2]-i[1][2],
     i[2][3]-i[1][3]
    }
    d2={
     i[3][1]-i[2][1],
     i[3][2]-i[2][2],
     i[3][3]-i[2][3]
    }
    cross={
     d1[2]*d2[3]-d1[3]*d2[2],
     d1[3]*d2[1]-d1[1]*d2[3],
     d1[1]*d2[2]-d1[2]*d2[1]
    }
    dist=sqrt(cross[1]^2+cross[2]^2+cross[3]^2)
    i[4]={
     cross[1]/dist,
     cross[2]/dist,
     cross[3]/dist
    }
   end

   --calculate depth
   depth=(i[1][3]+i[2][3]+i[3][3])/3 

   light=max(16,min(256,flr((i[4][3]+light_compensation)*200)+96))
 
   add(rq, {v[1],v[2],v[3],col=i["col"],light=light,depth=depth})
  end
 end
end

function render_queue_wireframe()

 for i in all(rq) do
  color(i["col"])
  line(i[1][1],i[1][2],i[2][1],i[2][2])
  line(i[2][1],i[2][2],i[3][1],i[3][2])
  line(i[3][1],i[3][2],i[1][1],i[1][2])
 end

end


function render_queue()

 --sort by depth
 for i=1,#rq do
 local j=i
  while j>1 and rq[j-1]["depth"]>rq[j]["depth"] do
   rq[j],rq[j-1]=rq[j-1],rq[j]
   j-=1
  end 
 end
 
 for i in all(rq) do
 
  v={{i[1][1],i[1][2]},{i[2][1],i[2][2]},{i[3][1],i[3][2]}}
  
  col=i["col"]+1
 
  light=i["light"]
 
  shade(col)

  trifill(v)
   
 end
 
 fillp()
 
end

function dot3d_rotate(x,y,z,sinq,cosq,axis)
 if axis=="x" then return x,y*cosq-z*sinq,y*sinq+z*cosq end
 if axis=="y" then return z*sinq+x*cosq,y,z*cosq-x*sinq end
 if axis=="z" then return x*cosq-y*sinq,x*sinq+y*cosq,z end
end

function rotate(object, q, axis)
 
 if rotate_normals==true then
  i3=4
 else
  i3=3
 end

 sinr,cosr=sin(q),cos(q)
   
 for i in all(object) do
  for i2=1,i3 do
   i[i2][1],i[i2][2],i[i2][3]=dot3d_rotate(i[i2][1],i[i2][2],i[i2][3],sinr,cosr,axis)
  end
 end
end

function translate(object, x,y,z)
 for i in all(object) do
  for i2=1,3 do
   i[i2][1]+=x
   i[i2][2]+=y
   i[i2][3]+=z
  end
 end
end

function polyring(edges,outer_radius,inner_radius,depth,color)
 local obj
 obj={}
 for i=1,edges do
  x1,x2,x3,x4,y1,y2,y3,y4=outer_radius*cos(i/edges),outer_radius*cos((i+1)/edges),inner_radius*cos((i+1)/edges),inner_radius*cos(i/edges),outer_radius*sin(i/edges),outer_radius*sin((i+1)/edges),inner_radius*sin((i+1)/edges),inner_radius*sin(i/edges)
  newtri1={{x1,y1,-depth/2},{x2,y2,-depth/2},{x3,y3,-depth/2},{0,0,1},col=color}
  newtri2={{x3,y3,-depth/2},{x4,y4,-depth/2},{x1,y1,-depth/2},{0,0,1},col=color}
  newtri3={{x3,y3,depth/2},{x2,y2,depth/2},{x1,y1,depth/2},{0,0,-1},col=color}
  newtri4={{x1,y1,depth/2},{x4,y4,depth/2},{x3,y3,depth/2},{0,0,-1},col=color}
  newtri5={{x1,y1,-depth/2},{x1,y1,depth/2},{x2,y2,depth/2},{0,0,0},col=color}
  newtri6={{x2,y2,depth/2},{x2,y2,-depth/2},{x1,y1,-depth/2},{0,0,0},col=color}
  newtri7={{x3,y3,depth/2},{x4,y4,depth/2},{x4,y4,-depth/2},{0,0,0},col=color}
  newtri8={{x4,y4,-depth/2},{x3,y3,-depth/2},{x3,y3,depth/2},{0,0,0},col=color}
  add(obj,newtri1)
  add(obj,newtri2)
  add(obj,newtri3)
  add(obj,newtri4)
  add(obj,newtri5)
  add(obj,newtri6)
  add(obj,newtri7)
  add(obj,newtri8)
 end
 return obj
end

function _init()

 demo_over=false

 plasma_func1={}
 for i=0,199 do
  plasma_func1[i]={}
  for x=0,24 do
   plasma_func1[i][x]={}
   for y=0,24 do
    plasma_func1[i][x][y]=60*cos((0.1+0.05*sin(i/100))*sqrt((x*0.7*(1+sin(i/200))-(10+12*cos(i/200)))^2+(y-(10+16*sin(i/200)))^2)+i/50)
   end
  end
 end
 
 twisterphase={}
 for i=1,128 do
  twisterphase[i]=i/128
 end
 twistercolors={9,2,9,2}
 
 twister_square_grid={}
 for i=1,17 do
  twister_square_grid[i]={}
  for x=1,16 do
   twister_square_grid[i][x]={}
   for y=1,20 do
    if rnd(100)>80 then
	 twister_square_grid[i][x][y]=true
	else
	 twister_square_grid[i][x][y]=false
	end
   end
  end
 end
    

 spr1=rle_decomp(spr_to_str_scan(0,0,5,3))
 spr2=rle_decomp(spr_to_str_scan(6,3,35,49))
 
 font=rle_decomp(spr_to_str_scan(36,49,57,61))
 
 disclaimer=rle_decomp(spr_to_str_scan(58,61,115,74))
 
 plasma_dither="00000000100000001000000010001000100010001000100010001000100010002000100020001000200010002000200020002000200020002000200020002000000000000000000000000000000000000000000000000000000000000000000001000000010000000100000001000100010001000100010001000100010001000000000000000000000000000000000000100000001000000010000000100010001000100010001000100010001000100020001000200010002000100020002000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010000000100000001000000010002000000000000100010001000100010001000100010001000100010001000100010001000100020002000200020002000200020002000200020002000200020000000000000000000000000000000000000000000000000000000000000000000000000000000010001000100010001000100010001000100010001000100010000000000000000000000000000000000000000000000001000100010001000100010001000100010001000100010001000100010001000200020002000200020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100010001000100018000200080002000800020008000800080108000801080008010800080108010802080108020801080208010802080208020802080808020808080200000000002000100020001000200010002000200020002000200020002000200020002000201020002010200020102000201020102020202020202020202020200000000102000201020002010200020102010202080102020801020208010202080208080802080808020808080208080808080808080808080808080808080000000000001000200010002000100020001000201020002010200020102000201020102020201020202010202020102020201020202020202020202020202020000000020002000200080008000800080008000800080008000801080108010801080108010801080108020802080208020802080208020802080208080802000000000010001000100020002000200020002000200020002000200020002000200020002000200020002010201020102010201020202020202020202020202000000000020002000201020102010201020102010201020102020802080208020802080208020802080808080808080808080808080808080808080808080800000000000010001000100010001000100010001000100010001010201020102010201020102010201020102010201020102010202020202020202020202020200000000"
 
 str_to_spr_scan(0,0,spr1)
 str_to_spr_scan(0,66,spr2)
 str_to_spr_scan(0,15,disclaimer)

 shades={
  0b1000000000000000,
  0b1000000000100000,
  0b1000001010000000,
  0b1010000010100000,
  0b1010000010100000,
  0b1010010010100000,
  0b1010010010100001,
  0b1010010110100100,
  0b1010010110100101,
  0b1110010110100101,
  0b1110010111100101,
  0b1110011111100101,
  0b1110011111100111,
  0b1111011111100111,
  0b1111011111110111,
  0b1111111111110111,
  0b1111111111111111
 }
 
  --generate shading palette from sprite sheet
 shdpal={}
 for i=0,15 do
  row={}
  add(row, 0)
  for i2=23,8,-1 do
   add(row, sget(i2,i))
  end
  add(shdpal, row)
 end

 recalc_normals,rotate_normals=true,false
 
 print_thefutureis,print_perpetual,print_sustainable,print_growth,print_full,print_network,print_immersion,print_unfettered,print_by_states_and,print_governments,print_by_moral,print_restraints,print_never,print_miss,print_out,print_social,print_media,print_presence,print_participate,print_influence,print_recruit,print_pepe,print_the,print_frog,print_protected,print_from_luddite,print_critique,print_progress,print_at_any,print_cost,print_a_vision,print_without,print_compromise,print_guided_by,print_the_invisible,print_hand,print_a_celebration,print_of_human,print_virtues,print_unswayed,print_by_petty,print_concerns,print_inevitable,print_salvation,print_through_tech,print_well_worth,print_all_your_toil,print_and_suffering,print_smash,print_unions,print_mine,print_bitcoin,print_now,print_intellectual,print_dark,print_web,print_jack_dorsey,print_kim_dotcom,print_elon_musk,print_is_your,print_friend,print_techno,print_utopian,print_edict,print_greetings,print_accession,print_adapt,print_ajna,print_dekadence,print_ivory_labs,print_lexaloffle,print_mercury,print_paraguay,print_poobrain,print_quadtrip,print_rez,print_unique,print_jumalauta,print_mmxix=parse_table("0_0_8|9_0_8|18_0_8|11_11_4|27_0_8|36_0_8|0_0_8|36_0_8|45_0_8|18_0_8|11_11_4|54_0_2|57_0_8|"),parse_table("66_0_8|18_0_8|45_0_8|66_0_8|18_0_8|0_0_8|36_0_8|75_0_8|84_0_8|"),parse_table("57_0_8|36_0_8|57_0_8|0_0_8|75_0_8|54_0_2|93_0_8|75_0_8|102_0_8|84_0_8|18_0_8|"),parse_table("111_0_8|45_0_8|120_0_8|0_11_10|0_0_8|9_0_8|"),parse_table("27_0_8|36_0_8|84_0_8|84_0_8|"),parse_table("93_0_8|18_0_8|0_0_8|0_11_10|120_0_8|45_0_8|16_11_8|"),parse_table("54_0_2|25_11_10|25_11_10|18_0_8|45_0_8|57_0_8|54_0_2|120_0_8|93_0_8|"),parse_table("36_0_8|93_0_8|27_0_8|18_0_8|0_0_8|0_0_8|18_0_8|45_0_8|18_0_8|54_11_8|"),parse_table("102_0_8|63_11_8|11_11_4|57_0_8|0_0_8|75_0_8|0_0_8|18_0_8|57_0_8|11_11_4|75_0_8|93_0_8|54_11_8|"),parse_table("111_0_8|120_0_8|36_11_8|18_0_8|45_0_8|93_0_8|25_11_10|18_0_8|93_0_8|0_0_8|57_0_8|"),parse_table("102_0_8|63_11_8|11_11_4|25_11_10|120_0_8|45_0_8|75_0_8|84_0_8|"),parse_table("45_0_8|18_0_8|57_0_8|0_0_8|45_0_8|75_0_8|54_0_2|93_0_8|0_0_8|57_0_8|"),parse_table("93_0_8|18_0_8|36_11_8|18_0_8|45_0_8|"),parse_table("25_11_10|54_0_2|57_0_8|57_0_8|"),parse_table("120_0_8|36_0_8|0_0_8|"),parse_table("57_0_8|120_0_8|45_11_8|54_0_2|75_0_8|84_0_8|"),parse_table("25_11_10|18_0_8|54_11_8|54_0_2|75_0_8|"),parse_table("66_0_8|45_0_8|18_0_8|57_0_8|18_0_8|93_0_8|45_11_8|18_0_8|"),parse_table("66_0_8|75_0_8|45_0_8|0_0_8|54_0_2|45_11_8|54_0_2|66_0_8|75_0_8|0_0_8|18_0_8|"),parse_table("54_0_2|93_0_8|27_0_8|84_0_8|36_0_8|18_0_8|93_0_8|45_11_8|18_0_8|"),parse_table("45_0_8|18_0_8|45_11_8|45_0_8|36_0_8|54_0_2|0_0_8|"),parse_table("66_0_8|18_0_8|66_0_8|18_0_8|"),parse_table("0_0_8|9_0_8|18_0_8|"),parse_table("27_0_8|45_0_8|120_0_8|111_0_8|"),parse_table("66_0_8|45_0_8|120_0_8|0_0_8|18_0_8|45_11_8|0_0_8|18_0_8|54_11_8|"), parse_table("27_0_8|45_0_8|120_0_8|25_11_10|11_11_4|84_0_8|36_0_8|54_11_8|54_11_8|54_0_2|0_0_8|18_0_8|"),parse_table("45_11_8|45_0_8|54_0_2|0_0_8|54_0_2|72_11_8|36_0_8|18_0_8|"),parse_table("66_0_8|45_0_8|120_0_8|111_0_8|45_0_8|18_0_8|57_0_8|57_0_8|"),parse_table("75_0_8|0_0_8|11_11_4|75_0_8|93_0_8|63_11_8|"),parse_table("45_11_8|120_0_8|57_0_8|0_0_8|"),parse_table("75_0_8|11_11_4|36_11_8|54_0_2|57_0_8|54_0_2|120_0_8|93_0_8|"),parse_table("0_11_10|54_0_2|0_0_8|9_0_8|120_0_8|36_0_8|0_0_8|"), parse_table("45_11_8|120_0_8|25_11_10|66_0_8|45_0_8|120_0_8|25_11_10|54_0_2|57_0_8|18_0_8|"),parse_table("111_0_8|36_0_8|54_0_2|54_11_8|18_0_8|54_11_8|11_11_4|102_0_8|63_11_8|"),parse_table("0_0_8|9_0_8|18_0_8|11_11_4|54_0_2|93_0_8|36_11_8|54_0_2|57_0_8|54_0_2|102_0_8|84_0_8|18_0_8|"),parse_table("9_0_8|75_0_8|93_0_8|54_11_8|"),parse_table("75_0_8|11_11_4|45_11_8|18_0_8|84_0_8|18_0_8|102_0_8|45_0_8|75_0_8|0_0_8|54_0_2|120_0_8|93_0_8|"),parse_table("120_0_8|27_0_8|11_11_4|9_0_8|36_0_8|25_11_10|75_0_8|93_0_8|"),parse_table("36_11_8|54_0_2|45_0_8|0_0_8|36_0_8|18_0_8|57_0_8|"),parse_table("36_0_8|93_0_8|57_0_8|0_11_10|75_0_8|63_11_8|18_0_8|54_11_8|"),parse_table("102_0_8|63_11_8|11_11_4|66_0_8|18_0_8|0_0_8|0_0_8|63_11_8|"),parse_table("45_11_8|120_0_8|93_0_8|45_11_8|18_0_8|45_0_8|93_0_8|57_0_8|"),parse_table("54_0_2|93_0_8|18_0_8|36_11_8|54_0_2|0_0_8|75_0_8|102_0_8|84_0_8|18_0_8|"),parse_table("57_0_8|75_0_8|84_0_8|36_11_8|75_0_8|0_0_8|54_0_2|120_0_8|93_0_8|"),parse_table("0_0_8|9_0_8|45_0_8|120_0_8|36_0_8|111_0_8|9_0_8|11_11_4|0_0_8|18_0_8|45_11_8|9_0_8|"),parse_table("0_11_10|18_0_8|84_0_8|84_0_8|11_11_4|0_11_10|120_0_8|45_0_8|0_0_8|9_0_8|"),parse_table("75_0_8|84_0_8|84_0_8|11_11_4|63_11_8|120_0_8|36_0_8|45_0_8|11_11_4|0_0_8|120_0_8|54_0_2|84_0_8|"),parse_table("75_0_8|93_0_8|54_11_8|11_11_4|57_0_8|36_0_8|27_0_8|27_0_8|18_0_8|45_0_8|54_0_2|93_0_8|111_0_8|"),parse_table("57_0_8|25_11_10|75_0_8|57_0_8|9_0_8|"),parse_table("36_0_8|93_0_8|54_0_2|120_0_8|93_0_8|57_0_8|"),parse_table("25_11_10|54_0_2|93_0_8|18_0_8|"),parse_table("102_0_8|54_0_2|0_0_8|45_11_8|120_0_8|54_0_2|93_0_8|"),parse_table("93_0_8|120_0_8|0_11_10|"),parse_table("54_0_2|93_0_8|0_0_8|18_0_8|84_0_8|84_0_8|18_0_8|45_11_8|0_0_8|36_0_8|75_0_8|84_0_8|"),parse_table("54_11_8|75_0_8|45_0_8|16_11_8|"),parse_table("0_11_10|18_0_8|102_0_8|"),parse_table("81_11_8|75_0_8|45_11_8|16_11_8|11_11_4|54_11_8|120_0_8|45_0_8|57_0_8|18_0_8|63_11_8|"),parse_table("16_11_8|54_0_2|25_11_10|11_11_4|54_11_8|120_0_8|0_0_8|45_11_8|120_0_8|25_11_10|"),parse_table("18_0_8|84_0_8|120_0_8|93_0_8|11_11_4|25_11_10|36_0_8|57_0_8|16_11_8|"),parse_table("54_0_2|57_0_8|11_11_4|63_11_8|120_0_8|36_0_8|45_0_8|"),parse_table("27_0_8|45_0_8|54_0_2|18_0_8|93_0_8|54_11_8|"),parse_table("0_0_8|18_0_8|45_11_8|9_0_8|93_0_8|120_0_8|101_11_4|"),parse_table("36_0_8|0_0_8|120_0_8|66_0_8|54_0_2|75_0_8|93_0_8|"),parse_table("18_0_8|54_11_8|54_0_2|45_11_8|0_0_8|"),parse_table("111_0_8|45_0_8|18_0_8|18_0_8|0_0_8|54_0_2|93_0_8|111_0_8|57_0_8|"),parse_table("75_0_8|45_11_8|45_11_8|18_0_8|57_0_8|57_0_8|54_0_2|120_0_8|93_0_8|"),parse_table("75_0_8|54_11_8|75_0_8|66_0_8|0_0_8|"),parse_table("75_0_8|81_11_8|93_0_8|75_0_8|"),parse_table("54_11_8|18_0_8|16_11_8|75_0_8|54_11_8|18_0_8|93_0_8|45_11_8|18_0_8|"),parse_table("54_0_2|36_11_8|120_0_8|45_0_8|63_11_8|11_11_4|84_0_8|75_0_8|102_0_8|57_0_8|"),parse_table("84_0_8|18_0_8|90_11_10|75_0_8|84_0_8|120_0_8|27_0_8|27_0_8|84_0_8|18_0_8|"),parse_table("25_11_10|18_0_8|45_0_8|45_11_8|36_0_8|45_0_8|63_11_8|"),parse_table("66_0_8|75_0_8|45_0_8|75_0_8|111_0_8|36_0_8|75_0_8|63_11_8|"),parse_table("66_0_8|120_0_8|120_0_8|101_11_4|102_0_8|45_0_8|75_0_8|54_0_2|93_0_8|"),parse_table("72_11_8|36_0_8|75_0_8|54_11_8|0_0_8|45_0_8|54_0_2|66_0_8|"),parse_table("45_0_8|18_0_8|106_11_10|"),parse_table("36_0_8|93_0_8|54_0_2|72_11_8|36_0_8|18_0_8|"),parse_table("81_11_8|36_0_8|25_11_10|75_0_8|84_0_8|75_0_8|36_0_8|0_0_8|75_0_8|"),parse_table("25_11_10|25_11_10|90_11_10|54_0_2|90_11_10|")

 rq={}
 light_compensation=0 
 script=parse_table("0_2_1|2_4_2|4_8_3|8_12_4|12_16_5|16_20_6|20_24_7|24_28_8|28_32_9|32_36_10|36_40_11|")
 scene2itd,scene3itd,scene4itd,scene5itd,scene6itd,scene7itd,scene8itd,scene9itd,scene10itd,scene11itd=false,false,false,false,false,false,false,false,false,false
 
 scn4xstart,scn4xend=24,104
 
 music()
 maxcpu=0
 
 fadjust=flr(60*time())
 f=0
 
end

function _update60()
 for i in all(script) do if stat(24)>=i[1]-0 then scn=i[3]-0 end end
 if scn==2 and scene2itd==false then initscene2() end
 if scn==3 and scene3itd==false then initscene3() end
 if scn==4 and scene4itd==false then initscene4() end
 if scn==5 and scene5itd==false then initscene5() end
 if scn==6 and scene6itd==false then initscene6() end
 if scn==7 and scene7itd==false then initscene7() end
 if scn==8 and scene8itd==false then initscene8() end
 if scn==9 and scene9itd==false then initscene9() end
 if scn==10 and scene10itd==false then initscene10() end
 if scn==11 and scene11itd==false then initscene11() end
 
 f=flr(time()*60)-fadjust
end

function initscene2()
 fadjust=flr(60*time())
 scene2grid={}
 for i=1,16 do
  scene2grid[i]={}
  for i2=1,40 do
   scene2grid[i][i2]={x=flr(rnd(40))*16,y=flr(rnd(4))*16}
  end
 end
 scene2cyclepalette={2,8,2,0,0}
 for x=0,103 do
  for y=0,11 do
   if sget(x+2,y+68)==2 then
    sset(x+2,y+68,11+(x-y)%5)
   end
   if sget(x+2,y+85)==2 then
    sset(x+2,y+85,11+(x-y-3)%5)
   end
   if sget(x+2,y+102)==2 then
    sset(x+2,y+102,11+(x-y+3)%5)
   end
  end
 end
 scene2itd=true
end

function initscene3()
 str_to_spr_scan(0,0,font)
 fadjust=flr(60*time())
 scene3itd=true
end

function initscene4()
 str_to_spr_scan(0,0,font)
 memset(0x1e80,0,384)
 for i=1,6 do
  for i2=1,70/i do
   spark_col=7
   spark_value=rnd(100)
   if spark_value<50 then spark_col=6 end
   if spark_value<25 then spark_col=5 end
   sset(rnd(128),128-i,spark_col)
  end
 end
 fadjust=flr(60*time())
 scene4itd=true
end

function initscene5()

 str_to_spr_scan(0,0,font)
 str_to_spr_scan(0,64,plasma_dither)

 fadjust=flr(60*time())
 scene5itd=true

end

function terraingrid_generate()
 terrain_grid={}
 for x=1,5 do
  terrain_grid[x]={}
  for z=1,500 do
   terrain_grid[x][z]=rnd(1)
  end
 end
end

function initscene6()

 plasma_func1={}
 
 cls(0)
 memcpy(0,0x6000,8192)

 terraingrid_generate()
 
 fadjust=flr(60*time())
 scene6itd=true

end

function initscene7()

 cls(0)
 memcpy(0,0x6000,8192)

 fadjust=flr(60*time())
 scene7itd=true

end

function initscene8()

 cls(0)
 for y=64,128 do
  for x=0,128 do
   z2=-((64*-8)/(y-64))
   x2=z2-(x*z2/64)
   colmod=0
   if x2%10>5 then colmod=8 end
   color(flr(z2%16+colmod)%16)
   pset(x,y)
  end
 end
 rectfill(0,48,128,64,12)
 memcpy(0,0x6000,8192)
 
 cycleterrain=parse_table("0_0_0_0_1_1_1_1_2_2_2_2_2_2_2_2|")

 fadjust=flr(60*time())
 scene8itd=true
 
end

function initscene9()

 memcpy(0,0x6000,8192)
 str_to_spr_scan(0,0,font)
 str_to_spr_scan(0,24,plasma_dither)
 
 tunnel_angle={}
 for x=1,16 do
  tunnel_angle[x]={}
  for y=1,16 do
   rx=x-8
   ry=8-y
   if ry==0 then
    if rx<0 then
	 q=-0.25
	else
	 q=0.25
	end
   else
    q=atan2(ry,rx)
   end
   if ry>0 then q+=0.5 end
   tunnel_angle[x][y]=flr(q*32)%16
  end
 end
 
 tunnel_depth={}
 for x=1,16 do
  tunnel_depth[x]={}
  for y=1,16 do
   rx=x-8
   ry=8-y
   tunnel_depth[x][y]=100/(rx^2+ry^2)
  end
 end

 fadjust=flr(60*time())
 scene9itd=true

end

function initscene10()

 cls()
 memcpy(0,0x6000,8192)

 str_to_spr_scan(0,0,font)

 terraingrid_generate()

 fadjust=flr(60*time())
 scene10itd=true

end

function initscene11()

 str_to_spr_scan(0,0,font)

 fadjust=flr(60*time())
 scene11itd=true

end

function drawscene1()

 xstart=-(f%90)
 for x=xstart,127,90 do sspr(0,117,88,4,x,36) end
 xstart=f%12-120
 for x=xstart,127,12 do
  for y=1,min(23,478-f) do
   sspr(24,10,8,1,x+y,40+y)
   sspr(24,10,8,1,x+y,88-y)
  end
 end
 xstart=-(f%83)
 for x=xstart,127,83 do sspr(0,122,81,4,x,89) end
 xstart=f%12-120
 rq={}
 light_compensation=0.1
 e=integer_script({{0,3},{30,5},{60,7},{90,4},{120,6},{150,5},{180,3},{210,7},{240,5},{270,4},{300,7},{330,5},{360,3},{390,6},{420,7},{450,4}})
 c=9
 o=2
 i=1.8
 for i in all({0,30,60,90,120,150,180,210,240,270,300,330,360,390,420,450}) do
  if f==i then c,o,i=7,2.4,1.4 end
 end
 d=min(1, (478-f)/25)
 if d>0 then
  obu=polyring(e,o,i,d,c)
  rotate(obu, 0.2+f*0.002, "z")
  rotate(obu, 0.3+f*0.0017, "y")
  translate(obu, 0, 0, -4)
  send_to_queue(obu)
  render_queue()
 end
 if f>240 then
  sspr(0,15,65,11,31,5)
  sspr(0,27,61,11,33,112)
 end
 
end

function drawscene2()

 cls()
 color(2)
 if f%30<2 then color(9) end
 for i in all(scene2grid[1+flr(f/30)]) do
  rectfill(i.x+3-f,i.y+3,i.x+13-f,i.y+13)
 end
 for y=0,64,16 do
  line(0,y,128,y,8)
 end
 for x=0,640,16 do
  line(x-f,0,x-f,64,8)
 end
 memcpy(0,0x6000,4160)
 cls()
 
 for y=max(0,32-f),min(64,32+f) do
  for i=-1,1 do
   sspr(0,y,128,1,0+(10+5*sin(f*0.001))*sin(f*0.01+y*0.01)+128*i,y)
  end
 end
 memcpy(0,0x6000,4160)
 cls()
 
 for x=0,127 do
  sspr(x,0,1,65,x,32+5*sin(f*0.01+(x-64)*(0.02+0.01*sin(f*0.0067))))
 end
 
 xstart=-((f+fadjust)%90)
 for x=xstart,127,90 do sspr(0,117,88,4,x,36-(f*0.15)^2) end
 xstart=f%12-120
 xstart=-((f+fadjust)%83)
 for x=xstart,127,83 do sspr(0,122,81,4,x,89+(f*0.15)^2) end
 xstart=f%12-120
 
 palt(0,false)
 palt(1,true)
 for i=1,5 do
  pal(10+i,scene2cyclepalette[(i-flr(f*0.25))%5])
 end
 if f>240 then
  scene2cyclepalette={7,7,7,7,7}
  if f>243 then scene2cyclepalette={2,8,2,0,0} end
  for i=1,5 do
   pal(10+i,scene2cyclepalette[(i-flr(f*0.25))%5])
  end
  sspr(0,66,103,17,13,38)
 end
 if f>270 then
  scene2cyclepalette={7,7,7,7,7}
  if f>273 then scene2cyclepalette={2,8,2,0,0} end
  for i=1,5 do
   pal(10+i,scene2cyclepalette[(i-flr(f*0.25))%5])
  end
  sspr(0,83,109,17,10,56)
 end
 if f>300 then
  scene2cyclepalette={7,7,7,7,7}
  if f>303 then scene2cyclepalette={2,8,2,0,0} end
  for i=1,5 do
   pal(10+i,scene2cyclepalette[(i-flr(f*0.25))%5])
  end
  sspr(0,100,77,17,26,74)
 end
 
 if f>=450 then
  if f%7.65<2 then
   cls(7)
  end
 end
 
 palt()
 pal()

end

function drawscene3()
 rq={}
 
 ztrans=-2-0.05*(f%30)
 
 rcol1,rcol2,rcol3=2,8,9
 if f%30<6 then
  cls(7)
  rcol1,rcol2,rcol3=0,0,0
 end
 
 if f<240 then
  r1=polyring(6,2,1.9,0.5,rcol1)
  rotate(r1,f*0.005,"z")
  translate(r1,0,0,-ztrans)
  send_to_queue(r1)
 
  r2=polyring(5,1.8,1.7,0.5,rcol2)
  rotate(r2,f*0.006,"x")
  translate(r2,0,0,-ztrans)
  send_to_queue(r2)
 
  r3=polyring(4,1.6,1.5,0.5,rcol3)
  rotate(r3,f*0.004,"y")
  translate(r3,0,0,-ztrans)
  send_to_queue(r3)
 end
 
 if f>=240 and f<480 then
  r1=polyring(8,3,0.5,2,rcol1)
  rotate(r1,-f*0.006,"z")
  translate(r1,0,0,-ztrans)
  send_to_queue(r1)
  
  r2=polyring(6,2,1,0.5,rcol3)
  rotate(r2,f*0.003,"z")
  rotate(r2,0.3,"x")
  translate(r2,0,0,-ztrans)
  send_to_queue(r2)
 end
 
 if f>480 then
  r1=polyring(3,1.4,0.8,2.9,rcol1)
  rotate(r1,f*0.004,"x")
  translate(r1,0,0,-ztrans)
  send_to_queue(r1)
  
  r2=polyring(6,1.7,1.65,0.2,rcol2)
  rotate(r2,f*0.004,"y")
  translate(r2,0,0,-ztrans)
  send_to_queue(r2)
  
  r3=polyring(5,1,0.95,1,rcol3)
  rotate(r3,f*0.006,"z")
  rotate(r3,0.25,"x")
  translate(r3,0,0,-ztrans)
  send_to_queue(r3)
 end
 
 render_queue_wireframe()
 
 if f%30<6 then pal(7,0) end
 
 if f>30 then print_font(7,35,print_thefutureis) end
 if f<270 then
  if f>90 then print_font(20,50,print_perpetual) end
  if f>150 then print_font(13,65,print_sustainable) end
  if f>210 then print_font(34,80,print_growth) end
 end
 if f>270 and f<510 then
  if f>330 then print_font(45,50,print_full) end
  if f>390 then print_font(29,65,print_network) end
  if f>450 then print_font(24,80,print_immersion) end
 end
 if f>510 and f<750 then
  if f>570 then print_font(15,50,print_unfettered) end
  if f>630 then print_font(4,65,print_by_states_and) end
  if f>690 then print_font(9,80,print_governments) end
 end
  if f>750 and f<990 then
  if f>810 then print_font(15,50,print_unfettered) end
  if f>870 then print_font(26,65,print_by_moral) end
  if f>930 then print_font(18,80,print_restraints) end
 end
 
 pal()
 
end

function drawscene4_drawline(y)
 burst=max(0,20-(f%30)*2)+max(0,40-((f+30)%60)*2)
 
 if f>930 then
  scn4xstart,scn4xend=64-(64-scn4xstart)/1.2,64+(scn4xend-64)/1.2
 end
 
 line(scn4xstart,y,scn4xend,y,7)
 for x=scn4xstart,scn4xend-2,2 do
  burst_this=flr(rnd(burst))
  flipx=false
  if rnd(100)>50 then flipx=true end
  sspr(rnd(127),122,4,6,x,y-6-burst_this,4,6+burst_this,flipx,false)
  sspr(rnd(127),122,4,6,x,y+1,4,6+burst_this,flipx,true)
 end
end

function drawscene4()

 linedensity,maxlength,zdepth,sparkles_phase=20,5,-4,f*0.01
 
 if f%60>=30 then
  linedensity,maxlength=max(20,80-(f%30)*8),max(5,1000-(f%30)*50)
 end
 
 for i=1,linedensity do
  x,y,length=rnd(128),rnd(128),rnd(maxlength)
  color(2)
  if rnd(100)>95 then color(8) end
  line(x,y-length,x,y+length)
 end

 if f%30<5 and f%60>=30 then zdepth=-3 end

 sparkles_phase_mod,sparkles_y=sparkles_phase%1,64+38*sin(sparkles_phase)
 
 if sparkles_phase_mod>0.25 and sparkles_phase_mod<0.75 then drawscene4_drawline(sparkles_y) end
 
 sparkles_object(-0.25,3,1,0.9,0.2,8,0.008,"y",true,-0.002,"x",1,false)
 sparkles_object(0.75,4,1.3,0.8,0.5,3,-0.006,"x",false,0,"x",1,false)
 sparkles_object(1.75,3,1.4,0.6,0.01,9,-0.006,"z",true,0.004,"y",1,false)
 sparkles_object(2.75,4,1.3,0.8,0.3,4,-0.003,"x",true,0.007,"z",1,false)
 sparkles_object(3.75,5,1,0.8,1.5,12,0.006,"y",false,0,"x",1,true)
 sparkles_object(4.75,5,1.2,0.3,0.2,10,0.005,"y",true,-0.009,"z",1.5,false)
 sparkles_object(5.75,4,0.5,0.45,2,9,0.006,"x",true,0.004,"y",1,true)
 sparkles_object(6.75,5,1,0.2,0.2,5,0.005,"z",true,-0.004,"x",1,false)
 sparkles_object(7.75,3,1.2,0.8,0.6,8,-0.005,"z",true,0.004,"y",1,false)

 if sparkles_phase_mod<=0.25 or sparkles_phase_mod>=0.75 then drawscene4_drawline(sparkles_y) end
 
 if f%60>=30 and f%60<32 then cls(7) end
 
 if f%240>97 and f%240<120 then
  if f%7.5<2 then
   pal(0,7)
   pal(7,0)
  end
  cls(0)
  if f%7.5<2 then cls(7) end
  if f>97 and f<120 then
   print_font(40,44,print_never)
   print_font(47,59,print_miss)
   print_font(50,74,print_out)
  end
  if f>337 and f<360 then
   print_font(38,44,print_social)
   print_font(42,59,print_media)
   print_font(25,74,print_presence)
  end
  if f>577 and f<600 then
   print_font(16,44,print_participate)
   print_font(23,59,print_influence)
   print_font(33,74,print_recruit)
  end
  if f>817 and f<840 then
   print_font(45,44,print_pepe)
   print_font(50,59,print_the)
   print_font(45,74,print_frog)
  end
  line(32,39,96,39,7)
  line(32,88,96,88,7)
  pal()
  
 end

end

function drawscene5()
 
 blink=false
 if f%60>=30 and f%60<34 then blink=true end
 if f%240>=157 and f%240<161 then blink=true end
 if f%240>=170 and f%240<174 then blink=true end
 
 if blink==true then pal(8,9) end
 
 for y=0,24 do
  for x=0,24 do
   v=125
   v+=plasma_func1[f%200][x][y]
   v+=30*cos((x+y+f)*0.05)
   v+=60*sin((y+f)*0.006)
   if blink==true then v+=80 end
   v=flr(mid(128,158,v))
   if f<100 then v=max(128,min(v,y*2+f+75)) end
   if f>860 then v=max(128,min(v,-y*2-f+1060)) end
   spr(v,x*6,y*6)
  end
 end
 
 pal()
 
 if f<8 or f>942 then pal(7,6) end
 if f<4 or f>946 then pal(7,5) end
 if f<950 then
  camera(0,-5-10*sin(f*0.005))
  print_font(7,30,print_thefutureis)
  if f<240 then
   if f>60 then print_font(20,45,print_protected) end
   if f>120 then print_font(9,60,print_from_luddite) end
   if f>180 then print_font(31,75,print_critique) end
  end
  if f<480 then
   if f>300 then print_font(25,45,print_progress) end
   if f>360 then print_font(37,60,print_at_any) end
   if f>420 then print_font(45,75,print_cost) end
  end
  if f<720 then
   if f>540 then print_font(33,45,print_a_vision) end
   if f>600 then print_font(32,60,print_without) end
   if f>660 then print_font(16,75,print_compromise) end
  end
  if f<960 then
   if f>780 then print_font(25,45,print_guided_by) end
   if f>840 then print_font(11,60,print_the_invisible) end
   if f>900 then print_font(45,75,print_hand) end
  end
  camera()
 end
 pal()
 
end

function drawscene6()

 blink=false
 if f%60>=30 and f%60<37 then blink=true end
 if f%240>154 and f%240<160 then blink=false end
 if f%240>=157 and f%240<161 then blink=true end
 if f%240>=170 and f%240<174 then blink=true end

 scene6and10_1()
 
 sspr(0,0,128,128,3,3,122,122)

 draw_terrain(6,f*0.002)
 
 rq={}
 a,b,c=0.8,9,-2
 if blink==true then a,b,c=0.4,7,-1.5 end
 obj=polyring(3,1,a,0.2,b)
 rotate(obj, 0.006*f, "y")
 rotate(obj, -0.0032*f, "z")
 translate(obj,0,0,c)
 send_to_queue(obj)
 render_queue()
 
 memcpy(0,0x6000,8192)
 

end

function drawscene7()

 x,y,z,ringcol=-1,-2,0,8
 pal(7,14)
 pal(14,10)
 pal(10,8)
 pal(8,2)
 pal(2,1)
 pal(1,0)
 pal(9,0)
 palt(4, true)
 palt(10, true)
 sspr(32,32,64,64,29,29,70,70)
 pal()
 palt()
 
 if f%60>=30 and f%60<35 then ringcol=7 end
 
 rq={}
 square1=polyring(4,1.5,1.3,0.2,ringcol)
 if f%60<30 then rotate(square1,f/60,"y") end
 rotate(square1,0.004*f,"z")
 translate(square1,0,0,-2.5)
 send_to_queue(square1)
 if f%60<30 then render_queue() else render_queue_wireframe() end
 
 rq={}
 square2=polyring(4,1.1,0.9,0.2,ringcol)
 if f%60>30 then rotate(square2,f/60,"y") end
 rotate(square2,0.004*f,"z")
 translate(square2,0,0,-2.5)
 send_to_queue(square2)
 if f%60>=30 then render_queue() else render_queue_wireframe() end
 
 memcpy(0,0x6000,8192)
 
 for y=0-f%12,128,12 do
  line(4,y,12,y,1)
  line(4,y+4,12,y+4,2)
  line(4,y+8,12,y+8,1)
 end
 
  for y=0-(0-f)%12,128,12 do
  line(116,y,124,y,1)
  line(116,y+4,124,y+4,2)
  line(116,y+8,124,y+8,1)
 end
 
 if f>480 and f%7.5<1 then
  for i=1,3 do
   y=rnd(128)
   line(0,y,128,y,7)
  end
  horizontal_scramble(60,10,150)
 end
 
end

function drawscene8()

 n,m=7.5,1.5
 if f>720 then n,m=3.25,1 end

 if f%n<m then
  if f%30<2 then
   cls(7)
   pal(0,7)
   pal(5,6)
   pal(6,5)
   pal(7,0)
  end
  for i=1,50 do
   line(64,64,-10+rnd(148),-10+rnd(148),7)
  end
  rq,c,a={},7,rnd(100)
  if a>80 then c=8 end
  if a>90 then c=9 end
  obj=polyring(3,2,1.2,0.3,c)
  rotate(obj,1/12,"z")
  rotate(obj,0.005*f,"y")
  translate(obj,0,-0.4,-2)
  send_to_queue(obj)
  render_queue()
  pal(9)
 else
  twistercolors,gridphase,square_grid_y={9,10,9,10},1+flr((f+30)/60),1
  for y=0,110 do
   if y>66 then twistercolors={3,9,3,9} end
   square_grid_x,ygrid=1,y+3
   if ygrid%8==0 then square_grid_y+=1 end  
   for i=0,3 do
    if (twisterphase[y+1]+i*0.25)%1<0.5 then
     bluh=64+20*sin(f/123)*sin((f+y*0.1)/100)
	 if f%60>=35 and f%60<50 then bluh+=4-rnd(8) end
     x1,x2=bluh+32*sin(twisterphase[y+1]+0.125+i*0.25),bluh+32*sin(twisterphase[y+1]+0.375+i*0.25)
     light=min(256,flr(150+(x2-x1)*3/max(1,(y-66)*0.08)))
     shade(twistercolors[i+1])
     if ygrid%8==0 then
	  line(x1,y,x2,y)
	 else
	  xgrid_diff=(x2-x1)/3
	  if xgrid_diff>1 then
	   xgrid_square_of_side=0
	   for xgrid=x1,x2,xgrid_diff do
	    line(xgrid,y,xgrid+1,y)
	    if ygrid%8>1 and ygrid%8<7 and xgrid_square_of_side<3 and twister_square_grid[gridphase][square_grid_x+xgrid_square_of_side][square_grid_y]==true then
	     if f%60>=30 and f%60<40 then
 	      fillp() 
	      line(xgrid+1.5*xgrid_diff/6,y,xgrid+5*xgrid_diff/6,y,7)
	      shade(twistercolors[i+1])
         else
		  line(xgrid+1.5*xgrid_diff/6,y,xgrid+5*xgrid_diff/6,y)
		 end
	    end
	    xgrid_square_of_side+=1
	   end
	  end
	 end
     color(0)
    end
    square_grid_x+=4
   end
   twisterphase[y+1]=0.1*sin(f*0.01)*sin(y/100)+0.01*f
  end

  palt(0,false)
  a=flr(-0.8*f%16)
  for b=a+1,a+4 do
   palt(b%16,0)
  end
 

  for i=0,15 do
   pal(i, cycleterrain[1][(i+flr(f*0.8))%16+1])
  end
  if f%60>=30 and f%60<40 then
   for i=1,10-f%30 do
    a,b=flr(rnd(16)),flr(rnd(16))
    pal(a,7)
   end
  end
  sspr(0,68,128,60,0,68)

  pal()
  palt()
 
 end
  
end

function drawscene9()

 line(f/2%16,41,f/2%16,56,15)
 for i=1,18 do
  x=(sin((f+i)*0.005)*16)%16
  line(x,41,x,56,min(15,i))
 end
 for i=1,18 do
  y=57-((f+i)/2%16)
  line(0,y,15,y,min(15,i))
 end
 memcpy(2624,0x6000+2624,1024)
 
 cls()
 
 for x=1,16 do
  for y=1,16 do
   v=sget(tunnel_angle[x][y]%16,41+tunnel_depth[x][y]%16)
   spr(48+2*v,x*8-8,y*8-8)
  end
 end

 rq={}
 obj=polyring(5,2,1.5,0.5,9)
 rotate(obj,0.01*f,"z")
 rotate(obj,0.125*sin(0.01*f),"y")
 translate(obj,0,0,-62.75+f%60)
 send_to_queue(obj)
 render_queue()
 
 if f<8 or f>942 then pal(7,6) end
 if f<4 or f>946 then pal(7,5) end
 if f<950 then
  camera(0,-5-10*sin(f*0.005))
  print_font(7,30,print_thefutureis)
  if f<240 then
   if f>60 then print_font(5,45,print_a_celebration) end
   if f>120 then print_font(26,60,print_of_human) end
   if f>180 then print_font(33,75,print_virtues) end
  end
  if f<480 then
   if f>300 then print_font(24,45,print_unswayed) end
   if f>360 then print_font(27,60,print_by_petty) end
   if f>420 then print_font(25,75,print_concerns) end
  end
  if f<720 then
   if f>540 then print_font(21,45,print_inevitable) end
   if f>600 then print_font(23,60,print_salvation) end
   if f>660 then print_font(7,75,print_through_tech) end
  end
  if f<960 then
   if f>780 then print_font(15,45,print_well_worth) end
   if f>840 then print_font(7,60,print_all_your_toil) end
   if f>900 then print_font(5,75,print_and_suffering) end
  end
  camera()
 end
 pal()

end

function drawscene10()

 blink=false
 if f%30<7 then blink=true end
 if f%15<1 then blink=true end

 scene6and10_1()
 
 sspr(0,64,128,64,3,64,122,61)
 
 draw_terrain(4,0.5)

 rq={}
 a,b,c=0.8,9,-2
 if blink==true then a,b,c=0.4,7,-1.5 end
 obj=polyring(3,1,a,0.2,b)
 rotate(obj, 0.006*f, "y")
 rotate(obj, -0.01*f, "z")
 translate(obj,0,0,c)
 send_to_queue(obj)
 render_queue()
 
 palt(0,false)
 memcpy(0x1000,0x7000,4096)
 sspr(0,64,128,64,0,0,128,64,false,true)
 palt()
 
  if f%240>97 and f%240<120 then
  if f%7.5<2 then
   pal(0,7)
   pal(7,0)
  end
  cls(0)
  if f%7.5<2 then cls(7) end
  if f>97 and f<120 then
   print_font(39,44,print_smash)
   print_font(50,59,print_the)
   print_font(38,74,print_unions)
  end
  if f>337 and f<360 then
   print_font(47,44,print_mine)
   print_font(36,59,print_bitcoin)
   print_font(49,74,print_now)
  end
  if f>577 and f<600 then
   print_font(8,44,print_intellectual)
   print_font(45,59,print_dark)
   print_font(49,74,print_web)
  end
  if f>817 and f<840 then
   if f<824 then print_font(12,44,print_jack_dorsey) end
   if f>=824 and f<832 then print_font(18,44,print_kim_dotcom) end
   if f>=832 then print_font(21,44,print_elon_musk) end
   print_font(35,59,print_is_your)
   print_font(38,74,print_friend)
  end
  line(32,39,96,39,7)
  line(32,88,96,88,7)
  pal()
  
 end

end

function scene6and10_1()

 f2=f+60

 pal(7,15)
 pal(15,9)
 pal(9,8)
 pal(8,2)
 pal(2,1)
 pal(1,0)
 pal(6,5)
 pal(5,1)
 pal(4,2)
 if f%30==0 then
  pal(0,7)
  palt(0,false)
 end

end

function drawscene11()

 if rnd(100)>75 then pal(7,5) end
 
 if f<90 then
  print_font(32,43,print_techno)
  print_font(33,58,print_utopian)
  print_font(43,73,print_edict)
 end
 
 if f>=120 and f<210 then
  print_font(23,6,print_greetings)
  print_font(23,36,print_accession)
  print_font(40,51,print_adapt)
  print_font(45,66,print_ajna)
  print_font(20,81,print_dekadence)
  print_font(20,96,print_ivory_labs)
  print_font(14,111,print_lexaloffle)
 end
 
 if f>=240 and f<330 then
  print_font(23,6,print_greetings)
  print_font(29,36,print_mercury)
  print_font(25,51,print_paraguay)
  print_font(25,66,print_poobrain)
  print_font(28,81,print_quadtrip)
  print_font(49,96,print_rez)
  print_font(38,111,print_unique)
 end
 
 if f>=360 and f<450 then
  print_font(19,51,print_jumalauta)
  print_font(39,66,print_mmxix)
 end
 
 if f>451 then
  demo_over=true
 end
 
 pal()
 
 
end

function _draw()

 for i in all(script) do if stat(24)>=i[1]-0 then scn=i[3]-0 end end
 
 cls()
 if demo_over==false then
  if scn==1 then drawscene1() end
  if scn==2 then drawscene2() end
  if scn==3 then drawscene3() end
  if scn==4 then drawscene4() end
  if scn==5 then drawscene5() end
  if scn==6 then drawscene6() end
  if scn==7 then drawscene7() end
  if scn==8 then drawscene8() end
  if scn==9 then drawscene9() end 
  if scn==10 then drawscene10() end
  if scn==11 then drawscene11() end
 end
 
end
