--sewers of d'oh!
--by ultrabrite

ver="v1.2.1"

_dget,_dset=dget,dset
loadicon=0
function dget(slot)
 loadicon=60 return _dget(slot)
end

function dset(slot,v)
 loadicon=60 _dset(slot,v)
end
-------------------


function shuffle(t)
	for n=1,#t*2 do
		local a,b=1+flr(rnd(#t)),1+flr(rnd(#t))
		t[a],t[b]=t[b],t[a]
	end
end

function printp(s,x,y,c)
	x=mid(10,x,118-#s*4)
	for i=x-1,x+1 do
		for j=y-1,y+1 do
			print(s,i,j,0)
		end
	end
	print(s,x,y,c)
end

function printc(s,y,c)
	print(s,64-#s*2,y,c)
end

function printcp(s,y,c)
	printp(s,64-#s*2,y,c)
end

demo=false

function chance() return (rnd(100)<12) end

plut = {0,0,1,2,2,1,5,6,2,4,9,3,13,1,8,9}
mlut = {}
for i=0,15 do
	for j=0,15 do
		mlut[16*i+j]=16*plut[i+1]+plut[j+1]
	end
end

function gmemdim(n)
	for i=1,n do
		local a=0x6000+rnd(0x2000)
		poke(a,mlut[peek(a)])
	end
end

function glinedim(ad,ln)
	for i=0,ln-1 do
		local a=ad+i
		local v=mlut[peek(a)]
		poke(a,mlut[v])
	end
end


_btn=btn _btnp=btnp btn_noinp=0

function btnp(n) 
	local b=_btnp(n)
	if (b) btn_noinp=0
	return b
end

function btn(n)
	local b=_btn(n)
	if (b) btn_noinp=0
	return b
end

function button() return btnp(4) or btnp(5) end

_sfx=sfx
sfxp={}
function sfx_clear() for i=0,10 do sfxp[i]=false end end
function sfx(n) sfxp[n]=true end
function sfx_play() for i=0,10 do if sfxp[i] then _sfx(50+i) end end end

gs_intro='1intro'
gs_menu='2menu'
gs_play='3play'
gs_over='4over'

gstate=gs_menu
gtimer=0

function setgstate(s) gstate=s gtimer=0 end

--ball velocity
vels_setups={
num=1,
{vmin=1.25,vmid=1.50,vmax=1.75,vang=0.40},-- easy
{vmin=1.50,vmid=1.75,vmax=2.00,vang=0.50},-- norm
{vmin=1.75,vmid=2.00,vmax=2.25,vang=0.65},-- hard
}
bvel={inc=0x.001}

function set_gamespeed(n)
	vels_setups.num=mid(1,n,#vels_setups)
	bvel.min=vels_setups[vels_setups.num].vmin
	bvel.mid=vels_setups[vels_setups.num].vmid
	bvel.max=vels_setups[vels_setups.num].vmax
	bvel.ang=vels_setups[vels_setups.num].vang
end

set_gamespeed(1)

thicklut={
{1,1,1,2,3,3},
{1,1,2,2,4,6},
{1,2,3,4,5,6},
{2,2,3,4,6,6},
{2,3,4,4,6,6}
}

--score
score={
	num=0,
	reset=function() score.num=0 end,
	add=function(n) score.num+=shr(n,16) end,
	str=function(sc)
		local s,i="",sc or score.num
		repeat
			s = shl(i%0x.000a,16)..s
			i/=10
		until i==0
		return s
	end
}


-- diff path
path={
	diff=2,iron=false,

	--speed(1-3),thickness(1-5),last
	{{s=1,t=1,l=8 },{s=1,t=2,l=48},{s=2,t=3,l=192},{s=2,t=4,l=224},{s=3,t=3,l=256}},--easy
	{{s=2,t=2,l=16},{s=2,t=3,l=32},{s=2,t=3,l=96 },{s=2,t=4,l=160},{s=3,t=3,l=256}},--medium
	{{s=3,t=3,l=16},{s=3,t=3,l=32},{s=3,t=4,l=192},{s=3,t=5,l=256}},--hard

	setup=function(diff)
		if (diff) path.diff=diff

		path.diffset=path[mid(1,path.diff,#path)]
		path.lev=0
	end,

	nextlevel=function()
		path.lev+=1

		for i=#path.diffset,1,-1 do
			local d=path.diffset[i]
			if (path.lev<=d.l) path.spd,path.thk=d.s,d.t
		end

		set_gamespeed(path.spd)

		wall.build(path.thk)
	end
}

cartdata("sewersofdoh")

menuitem(1,"reset scores", function() menu:reset() menu:save() end)

dirtyword=0xdeaf

retry={
	butts={
		{inf=1, sp=104, name="go back"},
		{inf=2, sp=106, name="try again"},
	},

	sel=2,

	move=function(m,x)
		m.sel = flr(2*mid(0,x-24,80)/81)+1
	end,

	click=function(m)
		return (m.butts[m.sel].inf==2)
	end,

	draw=function(m)
		palt(0,false)
		palt(15,true)
		for i=1,#m.butts do
			local b=m.butts[i]
			local x=42-#m.butts*14+i*28
			if (i==m.sel) printp(b.name,x+8-#b.name*2,84,7)
			pal(6,(i==m.sel) and 7 or 13)
			spr(b.sp, x,90, 2,2)
		end
		pal()
	end
}

msc=0x.0001*500
menu={
	dat={best={msc,msc,msc,msc,msc,msc},blev={0,0,0,0,0,0},last={0,0,0,0,0,0},llev={0,0,0,0,0,0}},

	butts={{inf=1, sp=96, name="difficulty"},{inf=2, sp=108, name="warrior"},{inf=3, sp=102, name="play"}},

	sel=1,

	reset=function(m)
		m.dat.best={msc,msc,msc,msc,msc,msc}
		m.dat.blev={0,0,0,0,0,0}
		m.dat.last={0,0,0,0,0,0}
		m.dat.llev={0,0,0,0,0,0}
		m:update()
	end,

	setscore=function(m,sc)
		local n=path.diff+(path.iron and 3 or 0)
		local s=m.dat
		m.hi=false
		if (s.best[n]<sc) s.best[n]=sc s.blev[n]=path.lev m.hi=true
		s.last[n]=sc s.llev[n]=path.lev
		m:update()
		m:save()
	end,

	save=function(m)
		dset(0,dirtyword)
		dset(1,path.diff)
		dset(2,path.iron and 1 or 0)
		local k=3
		local s=m.dat
		for j=1,6 do
			dset(k,s.best[j])
			dset(k+1,s.last[j])
			dset(k+2,s.blev[j]+shr(s.llev[j],16))
			k+=3
		end

	end,

	load=function(m)
		if dget(0)==dirtyword then
			path.diff=mid(1,dget(1),3)
			path.iron=dget(2)==1
			k=3
			local s=m.dat
			for j=1,6 do
				s.best[j]=dget(k)
				s.last[j]=dget(k+1)
				s.blev[j]=flr(dget(k+2))
				s.llev[j]=shl(dget(k+2),16)
				k+=3
			end
		end
		m:update()
	end,

	update=function(m)
		local s=m.dat
		n=path.diff+(path.iron and 3 or 0)

		s.lst="last: "..score.str(s.last[n]).." l."..s.llev[n]
		s.bst="best: "..score.str(s.best[n]).." l."..s.blev[n]

		m.butts[1].sp=94+path.diff*2
		m.butts[2].sp=path.iron and 110 or 108
	end,

	move=function(m,x)
		m.sel = flr(#m.butts*mid(0,x-24,80)/81)+1
	end,

	click=function(m)

		local s=m.dat
		local ib=m.butts[m.sel].inf

		if ib==1 then
			path.diff=1+path.diff%3
		elseif ib==2 then
			path.iron=not path.iron
		elseif ib==3 then
			return true
		end

		m:update()
		--m:save()
	end,

	draw=function(m)
		palt(0,false)
		palt(15,true)
		local s=m.dat
		printcp(s.bst,66,6)
		printcp(s.lst,72,6)

		for i=1,#m.butts do
			local b=m.butts[i]
			local x=44-#m.butts*12+i*24
			if (i==m.sel) printp(b.name,x+8-#b.name*2,84,7)
			pal(6,(i==m.sel) and 7 or 13)
			spr(b.sp, x,90, 2,2)
		end
		pal()
	end
}
menu:reset()
menu:load()


menu:update()

pow_time = 20*60

-- powerups
pow={
	bat=function(n,t)
		bat.t=(bat.pup==n) and mid(t,bat.t+t,t*3/2) or t
		bat.pup=n
	end,

	batw=function(w,t)
		bat.wt=(bat.wd==n) and mid(t,bat.wt+t,t*3/2) or t
		bat.wd=w
	end,

	ball=function(b,s,t)
		b.t=(b.s==s) and mid(t,b.t+t,t*3/2) or t
		b.s=s
		if b.vel<bvel.mid then b.vel=bvel.mid end
	end,

	laser=function() pow.bat(1,pow_time) prx=180 end,
	small=function() pow.batw(2,pow_time*2) end,
	large=function() pow.batw(4,pow_time*2) end,
	glu=function() pow.bat(2,pow_time) prx=180 end,
	slow=function() for b in all(balls) do b.vel = bvel.min end end,
	fast=function() for b in all(balls) do b.vel = bvel.max end end,
	triple=function() balls.split() end,
	burn=function() for b in all(balls) do pow.ball(b,1,pow_time) end end,
	burn2=function() for b in all(balls) do pow.ball(b,2,pow_time) end end,
	exit=function() for b in all(balls) do pow.ball(b,3,0) end end,
	life=function() if bat.ssh>2 then bat.tsh=true else bat.ssh+=1 end end,
	shield=function() bat.tsh=true end
}

powup={

	list = {--spr,%,effect,validation
			{n=32, pc=16, cb=pow.laser},--laser!
			{n=33, pc=20, cb=pow.small, ch=function() return bat.wd>2 end},
			{n=34, pc=20, cb=pow.large, ch=function() return bat.wd<4 end},
			{n=35, pc=12, cb=pow.glu},
			{n=36, pc=20, cb=pow.slow},
			{n=37, pc=20, cb=pow.fast},
			{n=38, pc=16, cb=pow.triple, ch=function() return #balls<4 end},
			{n=39, pc= 4, cb=pow.life, ch=function() return not path.iron and bat.ssh<3  end},
			{n=43, pc= 4, cb=pow.shield, ch=function() return not path.iron and not bat.tsh end},
			{n=40, pc=24, cb=pow.burn}, --yello
			{n=41, pc=16, cb=pow.burn2, ch=function() return wall.nbs!=0 end},--red
			{n=42, pc= 1, cb=pow.exit} --pink
			},

	init=function()
		powup.bag={}
		for p=1,#powup.list do
			for k=1,powup.list[p].pc do
				add(powup.bag,powup.list[p])
			end
		end
	end,

	get=function()
		local p=powup.bag[flr(1+rnd(#powup.bag))]
		if (p.ch and not p.ch()) return nil
		return p
	end
}
powup.init()

-- wall
colorsets={{1,2,8,14,7},{1,2,4,9,10},{2,4,9,10,7},{0,1,3,11,7},{0,1,12,6,7},{0,1,13,6,7},{0,1,2,14,15}}

function set_brickpal(n)
	if (n<1 or n>#colorsets) return
	local s,d=colorsets[1],colorsets[n]
	for i=1,5 do pal(s[i],d[i]) end
end

levlut={}
rbag={0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,2,2,2,2,2,2,3,3,3,3,3,5,6}

wall={}


function wall.random()

	--bricks
	repeat
	local nbb,nbs=0,0
	for i=0,3 do
		for j=0,6 do
			local n=flr(1+rnd(#rbag))
			local b=rbag[n]+9
			if (b>9) nbb+=1
			if (b==15) nbs+=1
			sset(i,j,b)
			sset(6-i,j,b)
		end
	end
	until nbb>20 and nbs!=0
	for i=0,6 do sset(i,7,9) end

	--check access
	local st={{x=0,y=7}}
	while(#st!=0) do
		local t=st[#st] del(st,t)
		local c=sget(t.x,t.y)
		if c>8 then
			sset(t.x,t.y,c-9)
			if c<15 then
				if (t.x>0) add(st,{x=t.x-1,y=t.y})
				if (t.x<6) add(st,{x=t.x+1,y=t.y})
				if (t.y>0) add(st,{x=t.x,y=t.y-1})
				if (t.y<7) add(st,{x=t.x,y=t.y+1})
			end
		end
	end

	--bricks
	for i=0,6 do
		for j=0,6 do
			local c=sget(i,j)
			if (c>6) c=(c==15) and 6 or 0
			sset(8+i,j,c)
		end
	end

	--colors (source+symmetrize)
	local cs=48+flr(rnd(10))
	local sx,sy=(cs%16)*8,flr(cs/16)*8
	for i=0,3 do
		for j=0,6 do
			local c=sget(sx+i,sy+j)
			sset(i, j,c)
			sset(6-i,j,c)
		end
	end

	return 8,0,0,0
end

function wall.clear()
	for x=0,6 do
		for y=0,6 do
			mset(x,y,0)
		end
	end
end

function wall.build(thk)

	--background
	for i=1,14 do
		mset(112+i,0,2)--bar
		for j=1,13 do
			mset(112+i,j,8+rnd(8))
		end
	end

	local px,py,cx,cy=wall.random()

	local symb=(rnd(2)>1)
	local symc=(rnd(2)>1)
	local xx
	local dif=thicklut[thk]
	for x=0,6 do
		for y=0,6 do
			local b=sget(px+x,py+y)
			if (symb) x=6-x
			local c=sget(cx+x,cy+y)
			if (symc) c=8-c

			mset(y,x, b!=0 and dif[b] or 0)
			sset(x,y,c)
		end
	end

end

function wall.update()
	--count bricks
	local nbb,nbs=0,0
	for i=0,6 do
		for j=0,6 do
			local c=mget(j,i)
			if (c!=0 and c!=6) nbb+=1
			if (c==6) nbs+=1
		end
	end
	wall.nbb,wall.nbs,wall.nba = nbb,nbs,nbb+nbs
	return nbb,nbs
end

function wall.draw()
	palt(0,false)
	for y=0,15 do
		for x=0,6 do
			local b=mget(y,x)
			if b!=0 then
				if b==6 then
					pal() palt(0,false)
					spr(74,x*16+8,y*8+8,2,1)
				elseif b<6 then
					local c=sget(x,y)
					set_brickpal(c)
					spr(62+2*b,x*16+8,y*8+8,2,1)
				else
					pal()
					spr(90,x*16+8,y*8+8,2,1)
				end
			end
		end
	end
	pal()palt()
end

-- pit background
pit={ ofs=128 }

function pit.nextlevel(dust,clr)

	wall.clear()

	local rem=mget(113,0)==2--bar
	for j=0,15 do
		for i=113,126 do
			mset(i,j+16, clr and 0 or mget(i,j))
			if (rem) mset(i,16,0)--bar off
			mset(i,j, dust and rnd(4)>3 and 8+rnd(8) or 0)
		end
	end

	pit.ofs=128+pit.ofs%8

	if (gstate==gs_play) then
		bottom=bottom_ofs+pit.ofs
		bat.y=bottom
	end

	for i=1,#balls do balls[i].y+=128 end
	for i=1,#bulls do bulls[i].y+=128 end
	for i=1,#bonus do bonus[i].y+=128 end

end

function pit.draw() map(112,pit.ofs/8-1, 0,-8-pit.ofs%8, 16,18) end

function pit.update()
	if pit.ofs>0 then
		pit.ofs-=1
		if (pit.ofs==0 and gstate<gs_play) pit.nextlevel(true)

		if (gstate==gs_play) then
			bottom=bottom_ofs+pit.ofs
			bat.y=bottom
		end
	end
end

-- ball
ball={} ball.__index=ball

function ball.new(model)
	local b
	if model then --clone
		b={}
		for k,v in pairs(model) do b[k]=v end
	else
		b={ x=64,y=256,s=0,ovr=false,vx=0,vy=0,vel=bvel.mid,t=0,ang=60+rnd(60),com=1 }
	end
	setmetatable(b,ball)
	return b
end

function ball.hit(me) score.add(me.com) me.com+=1 end
function ball.brek(me) me.com=1 end

function ball.bounce_hrz(me) me.ang=360-me.ang+rnd(8)-4 end
function ball.bounce_vrt(me) me.ang=180-me.ang+rnd(8)-4 end

function ball.standard(me) me.s,me.t=0,0 end

function ball.hitmap(x,y,bs)

	local hit,bim=false,0
	local brk={}
	i,j=0,0
	--ball is 2x2px
	for i=0,1 do
		local tx=flr((x+i-8)/16)
		for j=0,1 do
			local ty=flr((y+j-8)/8)
			local tc=mget(ty,tx)
			if tc>0 and tc<7 then
				hit=true
				brk[tx*16+ty]=tc
			end
		end
	end

	for t,c in pairs(brk) do
		local tx=flr(shr(t,4))
		local ty=band(t,15)

		if bs==3 then -- pink ball
			mset(ty,tx,0) -- pops all
			if c==6 then
				bim=1 -- bounces on steel
				sfx(2)
			else
				sfx(3)
			end
		elseif bs==2 and c<6 then --red ball, not steel
			mset(ty,tx,0) -- pops all, no bounce
			sfx(3)
		elseif c>1 and c<6 then -- norm or yellow ball, multi-brick
			mset(ty,tx, c-1) -- brick down
			bim=1 -- bounce
			sfx(3)
		elseif c<2 then -- simple brick
			mset(ty,tx,0) -- pop
			if bs==0 then
				bim=1 -- norm ball bounces
				if chance() then
					bonus.create(16+tx*16,12+ty*8) -- brick mid
				end
			end
			sfx(3)
		else
			bim=2 -- steel
			sfx(2)
		end
	end

	return hit,bim
end

function ball.collide(me)

	local x,y = me.x,me.y
	local dbx = flr(me.x+me.vx)-flr(x)
	local dby = flr(me.y+me.vy)-flr(y)

	nbp = max(abs(dbx),abs(dby))

	if (nbp==0) me.x+=me.vx me.y+=me.vy return

	local dx,dy = me.vx/nbp,me.vy/nbp

	for i=1,nbp do
		local px,py=flr(x),flr(y)
		local nx,ny=flr(x+dx),flr(y+dy)


		if ny>bottom then

			if me.ang>180 then
				local bnc
				if ny<bat.y+4 then

					if bat.bxlf<nx and nx<bat.bxrt then
						local coef=(me.x-bat.x)/(bat.wd*4)						
						dy=-abs(dy)
						me:bounce_hrz()
						me.ang=mid(10,me.ang-coef*60,170)
						sfx(0)

						if bat.pup==2 then--glu
							me.stuck=true
							me.stuck_dx=mid(-bat.wd*4,me.x-bat.x,bat.wd*4)
							me.y=bat.y
						end

						bat.ofy+=2

						me.com=4-bat.wd
					end

				else
					if bat.tsh then
						bnc=1
						bat.tsh=false
						sfx(5)
					elseif bat.ssh>0 then
						if #balls==1 then
							bnc=1
							bat.ssh-=1
							bat.pup=0
						else
							del(balls,me)
						end
						sfx(5)
					end
				end

				if bnc then
					dy=-abs(dy)
					me:bounce_hrz()
					me.ang=mid(10,me.ang,170)
					me:standard()
					me.com=0
				end

				if ny>bottom+16 then --out
					del(balls,me)
					sfx(6)
					return
				end
			end

			if pit.ofs!=0 and me.ang<180 and (me.ang<60 or me.ang>120)then --pad&shield moving up
				me.ang = me.ang/3+60
			end

		elseif ny<4 then

			dy=abs(dy)
			me:bounce_hrz()
			sfx(1)

			if (wall.nbb==0 and wall.nbs==0) gonext=true sfx(9)

		end

		if nx<px then
			if nx<8 then
				dx=abs(dx)
				me:bounce_vrt()
				sfx(1)
			end
		elseif nx>px then
			if nx>118 then
				dx=-abs(dx)
				me:bounce_vrt()
				sfx(1)
			end
		end

		if ny!=py then

			local hit,pop=me.hitmap(px,ny,me.ovr and 3 or me.s)

			if hit then
				if pop!=0 then
					dy=(ny<py) and abs(dy) or -abs(dy)
					me:bounce_hrz()
				end
				sfx(1)
				if (pop!=2) me:hit()
			end
		end

		if nx!=px then

			local hit,pop=me.hitmap(nx,py,me.ovr and 3 or me.s)

			if hit then
				if pop!=0 then
					dx=(nx<px) and abs(dx) or -abs(dx)
					me:bounce_vrt()
				end
				sfx(1)
				if (pop!=2) me:hit()
			end

		end

		x+=dx y+=dy
	end

	me.x,me.y = x,y
end

function ball.update(me)

	if me.stuck then

		me.x,me.y=bat.x+me.stuck_dx,bat.y

		if (bat.pup!=2) me.stuck=false

	else
		me.ang = (me.ang+720)%360
		-- no flat angle
		local baf=me.ang%90
		if (baf<10) me.ang+=0.1
		if (baf>80) me.ang-=0.1

		if me.vel<bvel.mid and me.y<90 then
			me.ang -= sgn(me.vx)*bvel.ang
		end

		me.vx = me.vel * cos(me.ang/360)
		me.vy = me.vel * sin(me.ang/360)

		me:collide()
	end

	if me.t>0 then
		me.t-=1
		if me.t==0 then me.s=0 end
	end

	--ball vel
	if (me.vel<bvel.mid) me.vel += bvel.inc
	if (me.vel>bvel.mid) me.vel -= bvel.inc

end

function ball.draw(me)

	local sp=62
	if me.s==0 then
		if me.vel<bvel.mid then sp=61
		elseif me.vel>bvel.mid then sp=63
		else sp=62 end
	else
		sp=44+ me.s
	end
	spr(me.ovr and 47 or sp,me.x-3,me.y-3,1,1)

end

-- balls
balls={}

function balls.kill()
	for i=#balls,1,-1 do balls[i]=nil end
end

function balls.new() add(balls,ball.new()) end

function balls.split()
	for i=1,#balls do
		if (#balls>8) return
		local b,c=balls[i]:new(),balls[i]:new()--clones

		b.ang-=60 b.vel=min(b.vel,bvel.mid)
		c.ang+=60 c.vel=min(c.vel,bvel.mid)

		add(balls,b)
		add(balls,c)
	end
end

function balls.free()
	for i=1,#balls do balls[i].stuck=false end
end

function balls.update()
	for b in all(balls) do b:update() end
end

function balls.draw()
	for i=1,#balls do balls[i]:draw() end
end

-- bullet
bull={} bull.__index=bull

function bull.new(x,y)
	local b={ x=x-flr(rnd(2)), y=y, v=-2 }
	setmetatable(b,bull)
	bulls[#bulls+1]=b
	return b
end

function bull.hitmap(x,y)
	if (y<4) return true
	local tx,ty=flr((x-8)/16),flr((y-8+pit.ofs)/8)
	local tc=mget(ty,tx)
	if tc>0 then
		--sfx(0)
		if tc==1 then
			mset(ty,tx,0)
			sfx(4)
			score.add(1)
			if (chance()) bonus.create(x,y)
		elseif tc<6 then
			mset(ty,tx,tc-1)
			sfx(4)
		else
			--unbreakable
			sfx(2)
		end
		return true
	end
	return false
end

function bull.update(me)
	if (me.y<4) del(bulls,me) return
	local oy = flr(me.y)
	local ny = oy+flr(me.v)
	local hit=false
	while not hit and oy>ny do
		hit=me.hitmap(me.x,oy) oy-=1
		if (hit) del(bulls,me)
	end
	me.y+=me.v
end

function bull.draw(me)
	spr(44,me.x-3,me.y-3,1,1)
end

bulls=
{
	reset=function()
		for i=#bulls,1,-1 do bulls[i]=nil end
	end,

	update=function()
		for b in all(bulls) do b:update() end --! del() inside
	end,

	draw=function()
		for i=1,#bulls do bulls[i]:draw() end
	end
}

-- pad
pad={} pad.__index=pad

function pad.new(x,y,o)
	local p={ x=x or 64, y=bottom, ofy=o or 16, vx=0, wd=3, wt=0, k=0, pup=0, t=1800, dx=0, tsh=false, ssh=0 }
	setmetatable(p,pad)
	return p
end

function pad.update(me)
	me.ox=me.x

	if demo and balls[1] then
		if (balls[1].vy>0 and balls[1].x>me.x) me.x+=2
		if (balls[1].vy>0 and balls[1].x<me.x) me.x-=2
	end

	if btn(0) then me.x-=3 end
	if btn(1) then me.x+=3 end

	local wdp=me.wd*4
	me.x=mid(7+wdp,me.x,121-wdp)

	me.lf=me.x-wdp
	me.rt=me.x+wdp-1
	me.dx=me.x-me.ox

	--forgiving pad
	local mx=(me.ox+me.x)/2
	me.bxlf=min(me.x,mx)-wdp -3
	me.bxrt=max(me.x,mx)+wdp  -- -1 +1

	if button() then
		if me.pup==1 then -- laser
			bull.new(me.x,me.y)
			sfx(4)
		elseif me.pup==2 -- captive
			then balls.free()
		end
	end

	if me.pup>0 and me.t>0 then me.t-=1 else me.pup=0 end
	if me.wd!=3 and me.wt>0 then me.wt-=1 else me.wd=3 end
end

function pad.draw(me,o)
	palt(15,true)
	palt(0,false)
	local bx,by=(o and me.ox or me.x)-me.wd*4,me.y+me.ofy
	local so=(o and 7 or 0)
	local sp=17 + so

	for i=1,me.wd-2 do spr(18+so,bx+i*8,by) end
	spr(sp,bx,by)
	spr(sp,bx+me.wd*8-8,by,1,1,true)

	if me.pup==2 then --glu
		for i=1,me.wd-2 do spr(18+so+3,bx+i*8,by) end
		spr(sp+3,bx,by)
		spr(sp+3,bx+me.wd*8-8,by,1,1,true)
	elseif me.pup==1 then --laser
		spr(22,me.x-4,by)
	end

	palt()
end

function startgame()
	bat = pad.new(bat.x)
	bat.ssh= not path.iron and 3 or 0
	bulls.reset()
	balls.kill()
	balls.new()

	bonus.reset()
	score.reset()

	setgstate(gs_play)
	gonext=false
	sfx(9)
	music(-1)
end

bottom_ofs=114
bottom=bottom_ofs

function _init()
	--remap brick colors
	for i=0,80 do
		for j=24,31 do
			sset(i,j,sget(i,j)-7)
		end
	end

	bat = pad.new()

	path.diff=2

	setgstate(gs_intro)

	cls()
	music(0)
	
	prx=0
end

bonus={
	reset=function()
		for i=#bonus,1,-1 do bonus[i]=nil end
	end,

	create=function(x,y)
		if (#bonus>4) return
		local pup = powup.get()
		if (pup) add(bonus,{pup=pup,x=x,y=y})
	end,

	update=function()
		for b in all(bonus) do
			b.y+=1
			if bat.lf-4<=b.x and b.x<=bat.rt+4
				and b.y>=bat.y-4 and b.y<bat.y+4 then
				del(bonus,b)
				sfx(7)
				b.pup.cb()
			elseif b.y>bottom+16 then
				del(bonus,b)
			end
		end
	end,

	draw=function()
		for b in all(bonus) do
			spr(b.pup.n,b.x-4,b.y-4,1,1)
		end
	end
}

function scrolldown()
	for i=127,1,-1 do
		memcpy(0x6000+i*64,0x6000+i*64-64,64)
	end
	memset(0x6000,0,64)
end

frame=0
function _update60()
	frame+=1
	gtimer+=1

	sfx_clear()

	if (pit.ofs!=0) scrolldown()

	pit.update()

	bat:update()

	if gstate==gs_play then

		if (bat.ofy>0) bat.ofy-=1

		wall.update()
		bonus.update()
		balls.update()
		bulls.update()

		if wall.nbb==0 then
			if wall.nbs==0 then
				if gonext==true then
					for i=1,#balls do
						if (balls[i].s==3) balls[i].s=0
						balls[i].ovr=false
					end
					pit.nextlevel()
					path.nextlevel()
					gonext=false
				end
			else
				for i=1,#balls do
					balls[i].ovr=true
				end
			end
		end

		if #balls==0 then
			sfx(8)
			menu:setscore(score.num)
			setgstate(gs_over)
			bonus.reset()
			bulls.reset()
			bat = pad.new(bat.x,bat.y,0)
			music(0)
		end

	elseif gstate==gs_intro then

		if (button()) setgstate(gs_menu)

		if (bat.ofy<16) bat.ofy+=1

	elseif gstate==gs_over then

		btn_noinp+=1

		if gtimer>60 then
			if (bat.ofy>0) bat.ofy-=1

			retry:move(bat.x)
			if button() then
				if retry:click() then
					pit.nextlevel()
					path.setup()
					path.nextlevel()
					startgame()
					bat.ofy=8
				else
					setgstate(gs_menu)
					pit.nextlevel(true)
					bat.ofy=8
				end
			elseif btn_noinp>900 then
				setgstate(gs_intro)
				pit.nextlevel(true)
			end
		end

	elseif gstate==gs_menu then
		btn_noinp+=1
		if (bat.ofy>0) bat.ofy-=1
		menu:move(bat.x)
		if button() then
			if menu:click() then
				pit.nextlevel(false,true)
				path.setup()
				path.nextlevel()
				startgame()
				bat.ofy=8
			end
		elseif btn_noinp>900 then
			setgstate(gs_intro)
		end

	end

	sfx_play()

end

mess=
{ s="",t=0,b=false,
	set=function(m,s,t,blk)
		m.s=s m.t=t or 30 m.b=blk
	end,
	draw=function(m)
		if m.t>0 then
			local x1,x2=64-#m.s*2,64+#m.s*2
			rectfill(x1-3,66,x2+1,76,0)
			rect(x1-2,67,x2,75,7)
			if (not m.b or frame%40>20) print(m.s, x1, 69, 7)
			m.t-=1
		end
	end
}

sh_ad1=0x6000+bottom*64+64*3+4
sh_ad2=sh_ad1+64-9

sh_col={1+16,13+13*16,12+12*16,7+7*16} -- tempo shield
ss_col={{0,8+8*16},{0,9+9*16},{0,7+7*16}} -- supershield aka lives
prsx="press \151 "
function _draw()

	gmemdim(700)
	if (bat.tsh or bat.ssh!=0) glinedim(sh_ad1+64*2,56)

	pit.draw()
	camera(0,pit.ofs)

	if bat.ssh>0 then
		local scol=ss_col[bat.ssh]
		local dd=64
		for ad=sh_ad1+dd,sh_ad2+dd do
			poke(ad,scol[1+flr(rnd(#scol))])
		end
	end
	if bat.tsh then
		for ad=sh_ad1,sh_ad2 do
			poke(ad,sh_col[1+flr(rnd(#sh_col))])
		end
	end

	if gstate>=gs_play then
		print('sc:'..score.str(),9,122,7)
		local lst='lv:'..path.lev
		print(lst,120-#lst*4,122,7)
	end

	if (gstate<=gs_menu) pal() palt() camera()

	wall.draw()
	bonus.draw()
	bulls.draw()
	bat:draw(true)
	bat:draw()
	balls.draw()

	if gstate==gs_over and gtimer>60 then
		mess:set(menu.hi and "high score!" or "game over")
		retry:draw()
	end
		if (gstate==gs_menu) menu:draw()

	if (gstate<=gs_menu) spr(128, 20,28, 11,4)
	if (gstate==gs_intro) then
		if (band(frame,0x300)==0x300) then
			palt(15,true) palt(0,false)
			spr(192,20,100,11,3)
			palt(15,false) palt(0,true)
		else
			printcp(prsx,110,9)
			clip(0,0,127,111) printcp(prsx,110,10)
			clip(0,114,127,127) printcp(prsx,110,4)
			clip()
		end
	end
	mess:draw()

	camera()
	
	if (prx>0) prx-=1 printcp("(press \151) ",122,7)

	if (gstate==gs_intro and frame>=0 and frame<120) printp(ver,120,123,7)
	if (loadicon>0) spr(31,0,0) loadicon-=1

	
end
