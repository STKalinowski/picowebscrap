
function _init()
 paletti={0,3,11,10,7,10,9,8}
 texture={0,0,0,0,0,0,0,0,
 		  0,3,3,3,3,3,3,3,
 		  0,3,11,11,11,11,11,3,
 		  0,3,11,10,10,10,11,3,
 		  0,3,11,10,7,10,11,3,
 		  0,3,11,10,10,10,11,3,
 		  0,3,11,11,11,11,11,3,
 		  0,3,3,3,3,3,3,3
 		  }
 texture2={
	0,0,0,0,0,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,0,0,0,0,0,0,
	0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,
	0,0,5,5,5,6,6,6,6,6,5,5,5,0,0,0,0,0,5,5,5,6,6,6,6,6,5,5,5,0,0,0,
	0,5,5,6,6,6,6,6,6,6,6,6,5,5,0,0,0,5,5,6,6,6,6,6,6,6,6,6,5,5,0,0,
	0,5,5,6,6,6,7,7,7,6,6,6,5,5,0,0,0,5,5,6,6,6,7,7,7,6,6,6,5,5,0,0,
	5,5,6,6,6,7,7,7,7,7,6,6,6,5,5,0,5,5,6,6,6,7,7,7,7,7,6,6,6,5,5,0,
	5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,
	5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,
	5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,
	5,5,6,6,6,7,7,7,7,7,6,6,6,5,5,0,5,5,6,6,6,7,7,7,7,7,6,6,6,5,5,0,
	0,5,5,6,6,6,7,7,7,6,6,6,5,5,0,0,0,5,5,6,6,6,7,7,7,6,6,6,5,5,0,0,
	0,5,5,6,6,6,6,6,6,6,6,6,5,5,0,0,0,5,5,6,6,6,6,6,6,6,6,6,5,5,0,0,
	0,0,5,5,5,6,6,6,6,6,5,5,5,0,0,0,0,0,5,5,5,6,6,6,6,6,5,5,5,0,0,0,
	0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,
	0,0,0,0,0,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,0,0,0,0,0,0,
	0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,
	0,0,5,5,5,6,6,6,6,6,5,5,5,0,0,0,0,0,5,5,5,6,6,6,6,6,5,5,5,0,0,0,
	0,5,5,6,6,6,6,6,6,6,6,6,5,5,0,0,0,5,5,6,6,6,6,6,6,6,6,6,5,5,0,0,
	0,5,5,6,6,6,7,7,7,6,6,6,5,5,0,0,0,5,5,6,6,6,7,7,7,6,6,6,5,5,0,0,
	5,5,6,6,6,7,7,7,7,7,6,6,6,5,5,0,5,5,6,6,6,7,7,7,7,7,6,6,6,5,5,0,
	5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,
	5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,
	5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,5,5,6,6,7,7,7,7,7,7,7,6,6,5,5,0,
	5,5,6,6,6,7,7,7,7,7,6,6,6,5,5,0,5,5,6,6,6,7,7,7,7,7,6,6,6,5,5,0,
	0,5,5,6,6,6,7,7,7,6,6,6,5,5,0,0,0,5,5,6,6,6,7,7,7,6,6,6,5,5,0,0,
	0,5,5,6,6,6,6,6,6,6,6,6,5,5,0,0,0,5,5,6,6,6,6,6,6,6,6,6,5,5,0,0,
	0,0,5,5,5,6,6,6,6,6,5,5,5,0,0,0,0,0,5,5,5,6,6,6,6,6,5,5,5,0,0,0,
	0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,
	0,0,0,0,0,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

 cls()

 offmap={}
 for y=-31.5,31.5 do
  for x=-31.5,31.5 do
   local u=atan2(x,y)*128
   local v=512/sqrt(x*x+y*y)
   
   add(offmap,band(u,15)+band(v,15)*32+1)
  end
 end

 circles={}
 for y=-64,63 do
  for x=-64,63 do
   local col=sqrt(x*x+y*y)/8
   add(circles,band(col,1))
  end
 end

 initscroll()

 var=0
 fxcount=0
 xoff=0
 yoff=0
 music(0)
end

function initscroll()
    scrolltext = "dekadence presents our first pico-8 demo called \"babysteps\"! most code by britelite. scroller and music by ricky martin. greets to the pico-8 scene. special thanks to lexaloffle for making this awesome fantasy console!"
    scrolllength = #scrolltext * 4
    pos = 128
    colorcounter = 0
end

function scroll()
    pos -= 1
    colorcounter += 1

    if pos <= -scrolllength then
        pos = 128
    end

    local color = 5
    if colorcounter == 10 then
        color = 6
    elseif colorcounter == 11 then
        color = 7
    elseif colorcounter == 12 then
        color = 6
        colorcounter = 0
    end

    rectfill(0,123,127,127,0)
    print(scrolltext, pos, 123, color)
end

function dointerference()
 local t=var

 local xx=band(xoff,1)
 local yy=band(yoff/2,1)

 local palli={2,14,2}

 local i=1+band((32+sin(t*3)*32),63)+band((32+sin(t*9)*32),63)*128
 local j=1+band((32+sin(t*5)*32),63)+band((32+sin(t*7)*32),63)*128
 for y=0+yy,121+yy,2 do
  for x=0+xx,127+xx,2 do
   pset(x,y,palli[circles[i]+circles[j]+1])
   i+=1
   j+=1
  end
  i+=64
  j+=64
 end
 xoff+=1
 yoff+=1
end


function dotunnel()
 local t=var

 local xx=band(xoff,1)
 local yy=band(yoff/2,1)

 local offi=band(fxcount,15)*32+band(fxcount/2,15)

 local i=1
 for y=0+yy,121+yy,2 do
  for x=0+xx,127+xx,2 do
   pset(x,y,texture2[offmap[i]+offi])
   i+=1
  end
 end
 xoff+=1
 yoff+=1
end

function doplasma()
 local t=var

 local xx=band(xoff,1)
 local yy=band(yoff/2,1)
 
 local sintab={}
 local a=t*9
 local b=-t*7
 for i=0,63 do
  add(sintab,sin(a)+sin(b))
  a+=0.009
  b+=0.019
 end
 
 local c=t*5
 local d=-t*8
 for y=0+yy,121+yy,2 do
  local ycol=sin(c)+sin(d)
  local i=1
  for x=0+xx,127+xx,2 do
   pset(x,y,paletti[band(sintab[i]+ycol,7)+1])
   i+=1
  end
  c+=0.015
  d+=0.007
 end
 xoff+=1
 yoff+=1
end

function dorotozoom()
 local t=var
 
 local zoom=sin(t*3)/3+0.60

 local ux=sin(t)*zoom
 local vx=cos(t)*zoom*8

 local uy=sin(t+0.25)*zoom
 local vy=cos(t+0.25)*zoom*8

 local uu=-ux*64
 local vv=-uy*64*8
 
 local xx=band(xoff,1)
 local yy=band(yoff/2,1)
 
 for y=0+yy,121+yy,2 do
  local u=uu
  local v=vv
  for x=0+xx,127+xx,2 do
   pset(x,y,texture[band(u,7)+band(v,56)+1])
   u+=ux
   v+=vx
  end
  uu+=uy
  vv+=vy
 end
 xoff+=1
 yoff+=1
end

function _update()
 var+=0.002
 fxcount+=1
 if (fxcount >= 192*4) then fxcount = 0 end
end

function _draw()
 if (fxcount < 192) then
  doplasma()
 elseif (fxcount < 192*2) then
  dointerference()
 elseif (fxcount < 192*3) then
  dorotozoom()
 else
  dotunnel()
 end
 scroll()
end


