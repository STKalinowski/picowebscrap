-- minima
-- by feneric
a={
['true']=true,
['false']=false}
b={}
c={['{']="}",['[']="]"}
function d(e,f)
for i=1,#f do
if(e==sub(f,i,i)) return true
end
return false
end
function g(h, i, j, k)
if sub(h,i,i)!=j then
return i,false
end
return i+1,true
end
function l(h, i, m)
m=m or ''
local c=sub(h,i,i)
if(c=='"') return b[m] or m,i+1
return l(h,i+1,m..c)
end
function n(h,i,m)
m=m or ''
local c=sub(h,i,i)
if(not d(c,"-xb0123456789abcdef.")) return tonum(m),i
return n(h,i+1,m..c)
end
function o(h, i, p)
i=i or 1
local q=sub(h,i,i)
if d(q,"{[") then
local r,s,t={},true,true
i+=1
while true do
s,i=o(h, i, c[q])
if(s==nil) return r,i
if q=="{" then
i=g(h,i,':',true)
r[s],i=o(h,i)
else
add(r,s)
end
i,t=g(h, i, ',')
end
elseif q=='"' then
return l(h,i+1)
elseif d(q,"-0123456789") then
return n(h, i)
elseif q==p then
return nil,i+1
else
for u,v in pairs(a) do
local w=i+#u-1
if sub(h,i,w)==u then return v,w+1 end
end
end
end
x,y,z,ba=11,13,5,6
bb="\n\n\n\n\n\n  congratulations, you've won!\n\n\n\n\n\n\n\n\n\n    press p to get game menu,\n anything else to continue and\n      explore a bit more."
bc="\n\n\n\n\n\n      you've been killed!\n          you lose!\n\n\n\n\n\n\n\n\n\n\n\n    press p to get game menu"
bd="minima commands:\n\na: attack\nc: cast spell\nd: dialog, talk, buy\ne: enter, board, mount, climb,\n   descend\np: pause, save, load, help\nf: fountain drink; force chest;\n   flame torch\ns: sit & wait\nw: wearing & wielding\nx: examine, look (repeat to\n   search)\n\nfor commands with options (like\ncasting or buying) use the first\ncharacter from the list, or\nanything else to cancel."
msg=bd
be={f=1,mva=0,nm=0,mvp=0,hd=0,ch=0,z=0}
function bf(bg,bh)
return setmetatable(bg,{__index=bg.ot or bh})
end
bi={"plains","bare ground","tundra","scrub","swamp","forest","foothills","mountains","tall mountain","volcano","volcano","water","water","deep water","deep water","brick","brick road","brick","mismatched brick","stone","stone","road","barred window","window","bridge","ladder down","ladder up","door","locked door","open door","sign","shrine","dungeon","castle","tower","town","village","ankh"}
for bj=1,29 do
add(bi,"counter")
end
bk={}
for bj=1,38 do
add(bk,{})
end
bl=o('[{"t":[1,2,3,4,5,6,7,8,17,18,22,25,26,27,30,31,33,35],"gp":10,"hp":10,"ch":1,"mva":1,"hos":1,"ar":1,"exp":2,"dex":8,"dmg":13},{"mxx":128,"mn":0,"fri":1,"mxy":64,"mnx":80,"mxm":0,"newm":0,"mny":0},{"sz":1,"sy":1,"sx":1,"mnx":1,"sf":1,"dg":1,"c":{},"mxm":27,"mn":0,"ss":17,"mxy":9,"fri":false,"newm":25,"mxx":9,"mny":1},{"i":38,"ia":38,"n":"ankh","d":["yes, ankhs can talk.","shrines make good landmarks."]},{"ia":70,"p":1,"i":70,"f":2,"n":"ship","fm":1},{"ia":92,"shm":-2,"i":92,"szm":11,"n":"chest","p":1},{"iseq":12,"n":"fountain","fi":1,"i":39,"szm":14,"shm":-2,"p":1},{"ia":27,"shm":12,"i":27,"szm":20,"n":"ladder up","p":1},{"ia":26,"shm":-3,"i":26,"szm":20,"n":"ladder down","p":1},{"hos":false,"i":80,"exp":1,"gp":5,"ar":0},{"n":"orc","ch":8,"d":["urg!","grar!"]},{"dmg":14,"gp":5,"ch":5,"dex":6},{"dex":10,"gp":0,"ch":3,"ar":0},{"dex":9,"n":"fighter","cs":[{},[[1,12],[14,2],[15,4]]],"d":["check out these pecs!","i\'m jacked!"],"i":82,"hp":12,"dmg":20,"ar":3},{"ar":12,"n":"guard","cs":[{},[[15,4]]],"d":["behave yourself.","i protect good citizens."],"i":90,"hp":85,"dmg":60,"mva":0},{"n":"merchant","fi":1,"d":["consume!","stuff makes you happy!"],"i":75,"cs":[{},[[1,4],[4,15],[6,1],[14,13]],[[1,4],[6,5],[14,10]],[[1,4],[4,15],[6,1],[14,3]]]},{"n":"lady","fi":1,"d":["pardon me.","well i never."],"i":81,"cs":[{},[[2,9],[4,15],[13,14]],[[2,10],[4,15],[13,9]],[[2,11],[13,3]]]},{"i":76,"n":"shepherd","cs":[{},[[6,5],[15,4]],[[6,5]],[[15,4]]],"d":["i like sheep.","the open air is nice."]},{"i":78,"n":"jester","dex":12,"d":["ho ho ho!","ha ha ha!"]},{"i":84,"n":"mage","ac":[[9,6],[8,13],[10,12]],"d":["a mage is always on time.","brain over brawn."]},{"cs":[{},[[9,11],[1,3],[15,4]],[[9,11],[1,3]],[[15,4]]],"n":"ranger","fi":1,"d":["i travel the land.","my home is the range."]},{"hos":1,"n":"villain","d":["stand and deliver!","you shall die!"],"ar":1,"exp":5,"gp":15},{"mch":"food","n":"grocer"},{"mch":"armor","n":"armorer"},{"mch":"weapons","n":"smith"},{"mch":"hospital","n":"medic"},{"mch":"guild","n":"guildkeeper"},{"mch":"bar","n":"barkeep"},{"i":96},{"n":"troll","exp":4,"i":102,"hp":15,"gp":10,"dmg":16},{"exp":3,"gp":8,"i":104,"hp":15,"dmg":14,"ns":["hobgoblin","bugbear"]},{"exp":1,"gp":5,"i":114,"hp":8,"dmg":10,"ns":["goblin","kobold"]},{"n":"ettin","fi":1,"exp":6,"i":118,"hp":20,"ch":1,"dmg":18},{"i":98,"n":"skeleton","gp":12},{"i":100,"hp":10,"ns":["zombie","wight","ghoul"]},{"d":["boooo!","feeear me!"],"fi":1,"t":[1,2,3,4,5,6,7,8,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,33,35],"i":123,"hp":15,"exp":7,"ns":["phantom","ghost","wraith"]},{"exp":10,"cs":[{},[[2,8],[15,4]]],"d":["i hex you!","a curse on you!"],"i":84,"dmg":18,"ac":[[9,6],[8,13],[10,12]],"ns":["warlock","necromancer","sorcerer"]},{"cs":[{},[[1,5],[8,2],[4,1],[2,12],[15,4]]],"dex":10,"i":88,"th":1,"ch":2,"ns":["rogue","bandit","cutpurse"]},{"exp":8,"cs":[{},[[1,5],[15,4]]],"d":["you shall die at my hands.","you are no match for me."],"i":86,"gp":10,"po":1,"ns":["ninja","assassin"]},{"n":"giant spider","exp":5,"i":106,"hp":18,"gp":8,"po":1},{"n":"giant rat","exp":2,"eat":1,"i":108,"hp":5,"po":1,"dmg":10},{"po":1,"exp":6,"t":[4,5,6,7],"i":112,"hp":20,"ch":1,"ns":["giant snake","serpent"]},{"n":"sea serpent","t":[5,12,13,14,15,25],"i":116,"hp":45,"exp":10},{"n":"megascorpion","fi":1,"exp":5,"i":125,"hp":12,"ch":1,"po":1},{"exp":2,"eat":1,"cs":[{},[[3,9],[11,10]],[[3,14],[11,15]]],"t":[17,22,23],"i":122,"gp":5,"fi":1,"ns":["slime","jelly","blob"]},{"exp":8,"t":[12,13,14,15],"i":94,"hp":50,"ch":2,"ns":["kraken","giant squid"]},{"n":"wisp","fi":1,"t":[4,5,6],"i":120,"exp":3},{"exp":8,"n":"pirate","cs":[[[6,5],[7,6]]],"t":[12,13,14,15],"i":70,"f":1,"fi":false,"fm":1},{"cs":[{},[[2,14],[1,4]]],"t":[17,22],"i":119,"exp":4,"fi":1,"ns":["gazer","beholder"]},{"fi":1,"ac":[[9,6],[8,13],[10,12]],"hp":50,"ns":["dragon","drake","wyvern"],"exp":17,"i":121,"gp":20,"dmg":28,"ar":7},{"t":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,22,25,26,27,30,31,33,35],"ac":[[9,10],[8,9],[10,7]],"hp":50,"ch":0.25,"ns":["daemon","devil"],"exp":15,"i":110,"gp":25,"dmg":23,"ar":3},{"th":1,"n":"mimic","exp":4,"t":[17,22],"i":92,"gp":12,"ch":0,"mva":0},{"fi":1,"t":[17,22],"gp":8,"hp":30,"ch":0,"mva":0,"n":"reaper","i":124,"exp":5,"ar":5}]')
bm=bl[5]
for bn=1,#bl do
local bh
local bo=bl[bn]
if bn<10 then
bh=be
elseif bn<14 then
bh=bl[1]
elseif bn<23 then
bh=bl[10]
elseif bn<28 then
bh=bl[16]
elseif bn<29 then
bh=bl[17]
elseif bn<35 then
bh=bl[11]
elseif bn<38 then
bh=bl[12]
elseif bn<41 then
bh=bl[22]
elseif bn<48 then
bh=bl[13]
else
bh=bl[1]
end
bo.id=bn
bf(bo,bh)
if bn>28 then
for bp in all(bo.t) do
add(bk[bp],bo)
end
end
end
function bq(br,bs,bt)
bu(br)
bv=yield()
bw=bs(bv)
return bw and bt(bw) or bw==false and "you cannot afford that." or "no sale."
end
function bx(bw)
if bw and bw.p then
return by.gp>=bw.p and bw
else
return nil
end
end
function bz(br,ca,cb)
return bq(br,
function(bv)
return bx(ca[bv])
end,
function(bw)
if by[cb]>=bw.a then
return "that is not an upgrade."
else
by.gp-=bw.p
by[cb]=bw.a
return "the "..bw.n.." is yours."
end
end
)
end
cc={
food=function()
return bq({"$15 for 25 food; a\80\80\82\79\86\69? "},
function(bv)
if bv=='a' then
return by.gp>=15
else
return nil
end
end,
function()
by.gp-=15
by.fd=cd(by.fd+25)
return "you got more food."
end
)
end,
armor=function()
return bz({"buy \131cloth $12, \139leather $99,","\145chain $300, or \148plate $950: "},ce,'ar')
end,
weapons=function()
return bz({"buy d\65\71\71\69\82 $8, c\76\85\66 $40,","a\88\69 $75, or s\87\79\82\68 $150: "},weapons,'dmg')
end,
hospital=function()
return bq({"choose m\69\68\73\67 ($8), c\85\82\69 ($10),","or s\65\86\73\79\82 ($25): "},
function(bv)
cf=cg[bv]
return bx(cf)
end,
function(cf)
sfx(3)
by.gp-=cf.p
if cf.n=='cure' then
by.st=band(by.st,14)
else
ch(cf.a)
end
return cf.n.." is cast!"
end
)
end,
bar=function()
return bq({"$5 per drink; a\80\80\82\79\86\69? "},
function(bv)
if bv=='a' then
return by.gp>=5
else
return nil
end
end,
function()
by.gp-=5
ci=o('["faxon has many guards.","faxon is very powerful.","fountains respect injury.","dungeon fountains rule.","faxon fears a magic sword.","watch for secret doors.","fighters can bust doors.","good mages can zap doors."]')
bu{"while socializing, you hear:"}
return '"'..ci[flr(rnd(8)+1)]..'"'
end
)
end,
guild=function()
return bq({"5 \139torches $12 or a \145key $23: "},
function(bv)
local cj=ck[bv]
return bx(cj)
end,
function(bw)
by.gp-=bw.p
by[bw.attr]+=bw.q
return "you purchase "..bw.n
end
)
end
}
function cl(ca)
cm={}
for cn,co in pairs(ca) do
cm[co.a]=co.n
end
cm[0]='none'
return cm
end
ce=o('{"south":{"n":"cloth","a":8,"p":12},"west":{"n":"leather","a":23,"p":99},"east":{"n":"chain","a":40,"p":300},"north":{"n":"plate","a":70,"p":950}}')
cp=cl(ce)
weapons=o('{"d":{"n":"dagger","a":8,"p":8},"c":{"n":"club","a":12,"p":40},"a":{"n":"axe","a":18,"p":75},"s":{"n":"sword","a":30,"p":150},"t":{"n":"magic swd","a":40}}')
cq=cl(weapons)
cg=o('{"a":{"n":"attack","c":3,"a":1},"x":{"n":"medic","c":5,"a":1,"p":8},"c":{"n":"cure","c":7,"p":10},"w":{"n":"wound","c":11,"a":5},"e":{"n":"exit","c":13},"s":{"n":"savior","c":17,"a":6,"p":25}}')
ck=o('{"west":{"n":"5 torches","attr":"ts","p":12,"q":5},"east":{"n":"a key","attr":"keys","p":23,"q":1}}')
function cr()
local cs=ct.ss
ct=cu[cv]
cw=ct.con
if(cs and ct.ss)music(ct.ss)
by.hd=0
end
function cx()
cu=o('[{"sy":23,"mxx":105,"ex":13,"sx":92,"n":"saugus","signs":[{"x":92,"msg":"welcome to saugus!","y":19}],"mxy":24,"c":[{"x":89,"id":15,"y":21},{"x":84,"id":26,"y":9},{"x":95,"id":24,"y":3},{"x":97,"id":23,"y":13},{"x":82,"id":14,"y":21},{"x":101,"id":21,"y":5},{"x":84,"d":["the secret room is key.","the way must be clear."],"id":20,"y":5},{"x":103,"d":["faxon is in a tower.","volcanoes mark it."],"id":21,"y":18},{"x":85,"d":["poynter has a ship.","poynter is in lynn."],"id":17,"y":16},{"x":95,"id":15,"y":21}],"i":[{"x":84,"id":4,"y":4}],"ey":4},{"sy":23,"ex":17,"sx":116,"n":"lynn","signs":[{"x":125,"msg":"marina for members only.","y":9}],"mxy":24,"c":[{"x":118,"id":15,"y":22},{"x":106,"id":25,"y":1},{"x":118,"id":28,"y":2},{"x":107,"id":23,"y":9},{"x":106,"id":19,"y":16},{"x":122,"id":26,"y":12},{"x":105,"d":["i\'ve seen faxon\'s tower.","south of the eastern shrine."],"id":14,"y":4},{"x":106,"d":["griswold knows dungeons.","griswold is in salem."],"id":17,"y":7},{"x":119,"d":["i\'m rich! i have a yacht!","ho ho! i\'m the best!"],"id":16,"y":6},{"x":114,"id":15,"y":22}],"i":[{"x":125,"id":5,"y":5}],"mnx":104,"ey":4},{"sy":54,"mxx":112,"ex":45,"sx":96,"n":"boston","mxy":56,"c":[{"x":94,"id":15,"y":49},{"x":103,"id":25,"y":39},{"x":92,"id":24,"y":30},{"x":88,"id":23,"y":38},{"x":100,"id":26,"y":30},{"x":96,"id":19,"y":44},{"x":83,"d":["zanders has good tools.","be prepared!"],"id":14,"y":27},{"x":81,"id":16,"y":44},{"x":104,"d":["each shrine has a caretaker.","seek their wisdom."],"id":20,"y":26},{"x":110,"d":["i\'ve seen the magic sword.","search south of the shrine."],"id":16,"y":40},{"x":105,"mva":1,"id":15,"y":35},{"x":98,"id":15,"y":49}],"i":[{"x":96,"id":7,"y":40}],"mny":24,"ey":19},{"sy":62,"ex":7,"sx":119,"n":"salem","i":[{"x":116,"id":4,"y":53}],"c":[{"x":118,"id":15,"y":63},{"x":125,"id":27,"y":44},{"x":114,"id":28,"y":44},{"x":122,"id":23,"y":51},{"x":118,"id":17,"y":58},{"x":113,"d":["faxon is a blight.","daemons serve faxon."],"id":21,"y":50},{"x":123,"d":["increase stats in dungeons!","only severe injuries work."],"id":14,"y":57},{"x":120,"id":15,"y":63}],"mny":43,"mnx":112,"ey":36},{"c":[{"x":93,"id":23,"y":57},{"x":100,"id":28,"y":57},{"x":91,"d":["even faxon has fears.","lalla knows who to see."],"id":14,"y":60},{"x":82,"id":18,"y":57},{"x":102,"d":["gilly is in boston.","gilly knows of the sword."],"id":18,"y":63}],"sy":59,"mxx":103,"ex":27,"mny":56,"sx":82,"n":"great misery","ey":35},{"sy":62,"mxx":112,"ex":1,"sx":107,"n":"western shrine","c":[{"x":107,"d":["magic serves good or evil.","swords cut both ways."],"id":20,"y":59}],"mny":56,"mnx":103,"ey":28},{"sy":62,"mxx":112,"ex":49,"sx":107,"n":"eastern shrine","c":[{"x":107,"d":["some fountains have secrets.","know when to be humble."],"id":18,"y":59}],"mny":56,"mnx":103,"ey":6},{"sy":41,"newm":35,"ex":56,"sx":120,"n":"the dark tower","c":[{"x":119,"id":53,"y":41},{"x":126,"id":53,"y":40},{"x":123,"id":53,"y":38},{"x":113,"id":53,"y":40},{"x":121,"id":52,"y":37},{"x":119,"id":52,"y":38},{"x":120,"id":45,"y":34},{"x":118,"id":45,"y":35},{"ar":25,"dmg":50,"hp":255,"y":30,"x":118,"i":126,"id":50,"pn":"faxon"}],"i":[{"tm":12,"ty":8,"y":41,"x":117,"tz":3,"id":8,"tx":3},{"x":119,"id":6,"y":37},{"x":119,"id":6,"y":39},{"x":120,"id":6,"y":37},{"x":120,"id":6,"y":38},{"x":120,"id":6,"y":39},{"x":121,"id":6,"y":38},{"x":121,"id":6,"y":39}],"ss":17,"mxm":23,"mxy":43,"fri":false,"mny":24,"mnx":112,"ey":44},{"l":[[0,16382,768,12336,16380,13056,13308,192],[0,-13107,816,12336,15612,768,16332,704],[-32768,-3316,1020,12300,13116,13056,-3076,448],[29488,13116,0,-3073,0,-3124,780,13116]],"sy":8,"c":[{"x":8,"z":4,"id":50,"y":5},{"x":3,"z":4,"id":52,"y":1},{"x":1,"z":4,"id":52,"y":5},{"x":5,"z":4,"id":52,"y":1},{"x":3,"z":4,"id":53,"y":3}],"ex":4,"attr":"int","i":[{"x":1,"z":1,"id":8,"y":8},{"x":8,"z":2,"id":8,"y":2},{"x":4,"z":3,"id":8,"y":8},{"x":1,"z":4,"id":8,"y":1},{"x":1,"z":4,"id":6,"y":8},{"x":7,"z":4,"id":6,"y":1},{"x":3,"z":4,"id":6,"y":8},{"x":5,"z":4,"id":6,"y":8},{"x":8,"z":4,"id":6,"y":8},{"x":6,"z":3,"id":7,"y":8}],"n":"nibiru","ey":11},{"l":[[824,16188,768,13296,-4036,13056,13308,768],[13060,13116,12,16332,12540,15360,15311,768],[768,13116,-20432,-196,48,16140,14140,816],[0,-13108,19468,-13108,192,-13108,3084,-13108]],"c":[{"x":3,"z":4,"id":50,"y":5},{"x":1,"z":4,"id":52,"y":5},{"x":7,"z":4,"id":52,"y":5},{"x":5,"z":4,"id":53,"y":3},{"x":5,"z":4,"id":53,"y":7}],"ex":32,"attr":"str","i":[{"x":1,"z":1,"id":8,"y":1},{"x":7,"z":2,"id":8,"y":1},{"x":3,"z":3,"id":8,"y":7},{"x":1,"z":4,"id":8,"y":3},{"x":1,"z":4,"id":6,"y":1},{"x":1,"z":4,"id":6,"y":8},{"x":1,"z":4,"id":6,"y":7},{"x":2,"z":4,"id":6,"y":8},{"x":8,"z":4,"id":6,"y":8},{"x":7,"z":3,"id":7,"y":5}],"n":"purgatory","ey":5},{"l":[[768,16304,1020,13056,13299,12288,-4,0],[768,13180,12303,16382,252,15360,13263,12288],[768,13116,12348,13105,13119,13068,13116,512],[0,16188,12300,13260,12300,12300,16380,256]],"c":[{"x":3,"z":4,"id":50,"y":1},{"x":4,"z":4,"id":52,"y":5},{"x":5,"z":4,"id":52,"y":2},{"x":3,"z":4,"id":53,"y":4},{"x":6,"z":4,"id":53,"y":4}],"ex":33,"attr":"dex","i":[{"x":1,"z":1,"id":8,"y":1},{"x":5,"z":2,"id":8,"y":2},{"x":8,"z":3,"id":8,"y":4},{"x":4,"z":4,"id":8,"y":8},{"x":5,"z":4,"id":6,"y":5},{"x":3,"z":4,"id":6,"y":6},{"x":4,"z":4,"id":6,"y":6},{"x":5,"z":4,"id":6,"y":6},{"x":6,"z":4,"id":6,"y":6},{"x":6,"z":3,"id":7,"y":6}],"n":"sheol","ey":58},{"sz":3,"c":[{"x":4,"z":1,"id":51,"y":6},{"x":4,"z":2,"id":51,"y":7},{"x":1,"z":3,"id":51,"y":7},{"x":6,"z":3,"id":53,"y":8},{"x":8,"z":3,"id":53,"y":4},{"x":3,"z":3,"id":53,"y":1},{"x":6,"z":2,"id":53,"y":6},{"x":6,"z":1,"id":53,"y":8}],"ex":124,"sx":8,"n":"the upper levels","l":[[192,-17202,-817,204,16332,3276,204,3072],[192,31949,16323,14576,15555,3276,15566,192],[192,-13105,3264,13564,16320,207,13261,15104]],"mn":8,"i":[{"x":8,"z":3,"id":9,"y":1},{"tz":0,"tm":8,"z":3,"y":8,"x":3,"ty":41,"id":9,"tx":117},{"x":8,"z":3,"id":8,"y":7},{"x":3,"z":3,"id":8,"y":4},{"x":1,"z":2,"id":8,"y":2},{"x":8,"z":2,"id":8,"y":2}],"ey":26}]')
cu[0]=o('{"n":"world","mnx":0,"mny":0,"mxx":80,"mxy":64,"wrap":1,"newm":10,"mxm":12,"fri":false,"ss":0}')
cy={}
for cv=0,#cu do
local cz
ct=cu[cv]
if cv>0 then
if ct.l then
cz=bl[3]
else
cz=bl[2]
end
bf(ct,cz)
end
ct.w,ct.h=ct.mxx-ct.mnx,ct.mxy-ct.mny
cy[cv],ct.con={},{}
for bj=ct.mnx-1,ct.mxx+1 do
ct.con[bj]={}
for da=ct.mny-1,ct.mxy+1 do
ct.con[bj][da]={}
end
end
for co in all(ct.i) do
co.ot,db,dc,dd=bl[co.id],co.x,co.y,co.z or 0
ct.con[db][dc][dd]=bf(co)
if co.ot.n=='ladder up' and ct.dg then
dd-=1
ct.con[db][dc][dd]=bf{ot=bl[9]}
end
end
for de in all(ct.c) do
de.mn=cv
de.ot=bl[de.id]
df(de)
end
end
by=o('{"i":0,"ar":0,"dmg":0,"x":7,"y":7,"z":0,"exp":0,"lvl":0,"str":8,"int":8,"dex":8,"st":0,"hd":0,"f":0,"gp":20,"fd":25,"mvp":0,"mp":8,"hp":24,"keys":0,"ts":5,"lit":0}')
by.color=rnd(10)>6 and 4 or 15
cv=0
cr()
cy[0]={}
dg=bf(o('{"i":69,"iseq":23,"n":"maelstrom","t":[12,13,14,15],"mva":1,"x":13,"y":61}'),be)
cy[0][0]=dg
cw[13][61][0]=dg
dh=0
di=false
dj=0
_update=dk
_draw=dl
dm=dl
end
dn={"","","","",">"}
dp=5
dq=dp
function _init()
cx()
menuitem(1,"list commands",dr)
menuitem(2,"save game",ds)
menuitem(3,"load game",dt)
menuitem(4,"new game",run)
du=cocreate(dv)
cartdata("minima0")
end
function dr()
msg=bd
if _draw~=dw then
dm=_draw
_draw=dw
end
end
dx={'ar','dmg','x','y','str','int','dex','st','i','color','f','keys','ts','exp','lvl','gp','fd','mp','hp'}
function dy(dz,ea)
return bor(shl(dz,8),ea)
end
function ds()
if cv~=0 then
bu{"sorry, only outside."}
else
local eb=0
for ec in all(dx) do
dset(eb,by[ec])
eb+=1
end
for ed=1,12 do
local de=cy[0][ed]
if de then
dset(eb,de.id)
dset(eb+1,dy(de.x,de.y))
else
dset(eb,0)
end
eb+=2
end
bu{"game saved."}
end
end
function ee(ef)
return lshr(band(ef,0xff00),8),band(ef,0xff)
end
function dt()
cx()
local eb=0
for ec in all(dx) do
by[ec]=dget(eb)
eb+=1
end
for ed=1,12 do
eg=dget(eb)
if eg~=0 then
eh,ei=ee(dget(eb+1))
df{ot=bl[eg],x=eh,y=ei,mn=0}
eb+=2
else
break
end
end
bu{"game loaded."}
end
ej={
"west", "east", "north", "south",
"c", "x", "p", "?", "s", "f", "e", "d", "w", "a"
}
function ek(el)
local em=1
while el>1 do
el=lshr(el,1)
em+=1
end
return ej[em] or 'none'
end
function en(bv,eo)
local ep=cg[bv]
if by.mp>=ep.c then
by.mp-=ep.c
bu{ep.n.." is cast! "..(eo or '')}
return true
else
bu{"not enough mp."}
return false
end
end
function eq(er,es,et)
by.x,by.y,by.z,by.f,by.lit,cv=er or ct.ex,es or ct.ey,0,0,0,et or ct.mn
cr()
_draw=dl
end
function eu(ev,et,er,es,ew)
by.x,by.y=er or ev.sx,es or ev.sy
cv=et
cr()
if ev.dg then
_draw=ex
by.f,by.z=ev.sf,ev.sz
end
return "entering "..ev.n.."."
end
function dv(bv)
while true do
local ey=ez(by)
local db,dc,dd=by.x,by.y,by.z
local fa=cw[db][dc][dd]
local fb=fa and fa.n or nil
if _draw==dw then
if bv!='p' and by.hp>0 then
_draw=dm
end
elseif bv=='west' then
if ct.dg then
by.f-=1
if by.f<1 then
by.f=4
end
bu{"turn left"}
di=true
else
by.x,by.y=fc(ey[2],dc,bv)
end
elseif bv=='east' then
if ct.dg then
by.f+=1
if by.f>4 then
by.f=1
end
bu{"turn right."}
di=true
else
by.x,by.y=fc(ey[4],dc,bv)
end
elseif bv=='north' then
if ct.dg then
by.x,by.y,by.z=fd(1)
else
by.x,by.y=fc(db,ey[1],bv)
if by.x==121 and by.y==36 then
mset(116,41,22)
bu{"something clicks."}
end
end
elseif bv=='south' then
if ct.dg then
by.x,by.y,by.z=fd(-1)
else
by.x,by.y=fc(db,ey[3],bv)
end
elseif bv=='c' then
bu{"choose a\84\84\65\67\75, m\69\68\73\67, c\85\82\69,","w\79\85\78\68, e\88\73\84, s\65\86\73\79\82: "}
bv=yield()
if bv=='c' then
if en(bv) then
sfx(3)
by.st=band(by.st,14)
end
elseif bv=='x' or bv=='s' then
if en(bv) then
sfx(3)
ch(cg[bv].a*by.int)
end
elseif bv=='e' then
if not ct.dg then
bu{'not in a dungeon.'}
elseif(en(bv)) then
sfx(4)
eq()
end
elseif bv=='w' or bv=='a' then
if en(bv,'dir:') then
local fe=rnd(cg[bv].a*by.int)
if not ff(ey,fg,fe) then
bu{'nothing to target.'}
end
end
else
bu{"cast: huh?"}
end
di=true
elseif bv=='x' then
bu{"examine dir:"}
if not ff(ey,fh) then
if bv=='x' then
local fi={"search","you find nothing."}
fj=fk(db,dc)
if fj then
fi={"read sign",fj}
elseif db==1 and dc==38 and by.dmg<40 then
fi[2]="you find the magic sword!"
by.dmg=40
end
bu(fi)
else
bu{"examine: huh?"}
end
end
di=true
elseif bv=='p' then
bu{"pause / game menu"}
elseif bv=='s' then
di=true
bu{"sit and wait."}
elseif bv=='f' then
di=true
if fb=='fountain' then
sfx(3)
msg="healed!"
if ct.dg and by.hp<23 and by[ct.attr]<16 then
by[ct.attr]+=1
msg="you feel more capable!"
end
ch(100)
bu{msg}
elseif fb=='chest' then
local fl=ceil(rnd(100))
by.gp+=fl
bu{"you find "..fl.." gp."}
cw[db][dc][dd]=nil
elseif ct.dg and by.lit<1 then
if by.ts>1 then
by.lit=50
by.ts-=1
bu{"the torch is now aflame."}
else
bu{"you have no torches."}
end
else
bu{"nothing here."}
end
elseif bv=='e' then
di=true
local msg="nothing to enter."
if fb=='ladder up' or fb=='ladder down' then
if ct.dg then
if dd==ct.sz and db==ct.sx and dc==ct.sy then
msg="exiting "..ct.n.."."
eq()
elseif fb=='ladder up' then
msg="ascending."
by.z-=1
else
msg="descending."
by.z+=1
end
end
if fa.tm then
if ct.dg and not cu[fa.tm].dg then
eq(fa.tx,fa.ty,fa.tm)
else
msg=eu(cu[fa.tm],fa.tm,fa.tx,fa.ty,fa.tz)
end
end
elseif by.i>0 then
msg="exiting ship."
cw[db][dc][dd]=bf{f=by.f,ot=bm}
by.i,by.f=0,0
elseif fb=='ship' then
msg="boarding ship."
by.i,by.f=70,fa.f
cw[db][dc][dd]=nil
end
for fm=1,#cu do
local fn=cu[fm]
if cv==fn.mn and db==fn.ex and dc==fn.ey then
msg=eu(fn,fm)
end
end
bu{msg}
elseif bv=='d' then
bu{"dialog dir:"}
if not ff(ey,fo) then
bu{"dialog: huh?"}
end
di=true
elseif bv=='w' then
bu{
"worn: "..cp[by.ar].."; wield: "..cq[by.dmg],
by.ts..' torches & '..by.keys..' skeleton keys.'
}
elseif bv=='a' then
if by.i>0 then
bu{"fire dir:"}
else
bu{"attack dir:"}
end
if not ff(ey,fg) then
bu{"attack: huh?"}
end
di=true
end
if by.lit>1 then
by.lit-=1
if by.lit<1 then
bu{"the torch burnt out."}
end
end
if _draw==ex and by.lit<1 then
bu{"it's dark!"}
end
bv=yield()
end
end
function ff(ey,fp,fq,fr)
if ct.dg then
fr=fs[by.f]
elseif not fr then
fr=yield()
end
if fr=='east' then
fp(fr,ey[4],by.y,fq)
elseif fr=='west' then
fp(fr,ey[2],by.y,fq)
elseif fr=='north' then
fp(fr,by.x,ey[1],fq)
elseif fr=='south' then
fp(fr,by.x,ey[3],fq)
else
return false
end
return true
end
function bu(msg)
local br="> "
for ft in all(msg) do
dn[dq]=br..ft
dq+=1
if(dq>dp)dq=1
br=""
end
dn[dq]=">"
end
function df(fu)
local fv,db,dc,dd=fu.ot,fu.x,fu.y,fu.z or 0
fu.ot=fv
bf(fu)
if fu.pn then
fu.n=fu.pn
elseif fv.ns then
fu.n=fv.ns[flr(rnd(#fv.ns)+1)]
end
if(fv.cs)fu.co=fv.cs[flr(rnd(#fv.cs)+1)]
fu.iseq=flr(rnd(30))
fu.ia=false
add(cy[fu.mn],fu)
cu[fu.mn].con[db][dc][dd]=fu
return fu
end
function fw()
local fx=flr(rnd(ct.w))+ct.mnx
local fy=flr(rnd(ct.h))+ct.mny
local fz=ct.dg and flr(rnd(#ct.l)+1) or 0
if cw[fx][fy][fz] or fx==by.x and fy==by.y and fz==by.z then
fx=nil
end
if fx then
local ga=mget(fx,fy)
if ct.dg then
ga=gb(fx,fy,fz,1)
end
for fv in all(bk[ga]) do
if rnd(200)<fv.ch then
df{ot=fv,x=fx,y=fy,z=fz,mn=cv}
break
end
end
end
end
function gc(gd)
by.hp-=ceil(gd)
if by.hp<=0 then
msg=bc
_draw=dw
end
end
function ge(gf)
by.fd-=gf
if by.fd<=0 then
sfx(1,3,8)
by.fd=0
bu{"starving!"}
gc(1)
end
end
function cd(bj)
return min(bj,32767)
end
function gg(gf)
by.exp=cd(by.exp+gf)
if by.exp>=by.lvl^2*10 then
by.lvl+=1
ch(12)
bu{"you went up a level!"}
end
end
function ch(gf)
by.hp=cd(min(by.hp+gf,by.str*(by.lvl+3)))
end
function fd(gh)
local gi,gj=by.x,by.y
local db,dc,dd=by.x,by.y,by.z
local bv=gh>0 and 'advance' or 'retreat'
local co
local gk=false
if by.f==1 then
gj-=gh
gl=gb(db,gj,dd)
co=cw[db][gj][dd]
elseif by.f==2 then
gi+=gh
gl=gb(gi,dc,dd)
co=cw[gi][dc][dd]
elseif by.f==3 then
gj+=gh
gl=gb(db,gj,dd)
co=cw[db][gj][dd]
else
gi-=gh
gl=gb(gi,dc,dd)
co=cw[gi][dc][dd]
end
if co and co.hp then
gk=true
end
if gl==3 or gk then
gm(bv)
else
db,dc=gi,gj
sfx(0)
bu{bv}
end
di=true
return db,dc,dd
end
function gn(db,dc)
if not ct.wrap and(db>=ct.mxx or db<ct.mnx or dc>=ct.mxy or dc<ct.mny) then
bu{bv,"exiting "..ct.n.."."}
cv=0
return true
else
return false
end
end
function gm(bv)
sfx(5)
bu{bv,"blocked!"}
return false
end
go={north=1,west=2,south=3,east=4}
fs={"north","east","south","west"}
function fc(db,dc,bv)
local gp=true
local gq=mget(db,dc)
local gr=band(fget(gq),3)
local gs=fget(gq,2)
local gt=fget(gq,3)
local gu=cw[db][dc][by.z]
if by.i>0 then
by.f=go[bv]
local gv=mget(db,dc)
if gn(db,dc) then
db,dc=ct.ex,ct.ey
cr()
elseif gu then
if gu.n=='maelstrom' then
bu{bv,"maelstrom! yikes!"}
gc(rnd(25))
else
gp=gm(bv)
end
elseif gv<12 or gv>15 then
bu{bv,"must exit ship first."}
gp=false
else
bu{bv}
end
else
if gn(db,dc) then
db,dc=ct.ex,ct.ey
cr()
elseif gu then
if not gu.p then
gp=gm(bv)
end
elseif gq==28 then
bu{bv,"open door."}
gp=false
mset(db,dc,30)
elseif gq==29 then
if by.keys>0 then
bu{bv,"you jimmy the door."}
by.keys-=1
mset(db,dc,30)
else
bu{bv,"the door is locked."}
end
gp=false
elseif gt then
gp=gm(bv)
elseif gs then
gp=false
bu{bv,"not without a boat."}
elseif gr>by.mvp then
by.mvp+=1
gp=false
bu{bv,"slow progress."}
else
by.mvp=0
bu{bv}
end
end
if gp then
if by.i==0 then
sfx(0)
end
if gq==5 and rnd(10)>6 then
bu{bv,"poisoned!"}
by.st=bor(by.st,1)
end
else
db,dc=by.x,by.y
end
di=true
return db,dc
end
function fk(db,dc)
local fi=nil
if mget(db,dc)==31 then
for gw in all(ct.signs) do
if db==gw.x and dc==gw.y then
fi=gw.msg
break
end
end
end
return fi
end
function fh(gx,db,dc)
local bv,fj,gu="examine: "..gx,fk(db,dc),cw[db][dc][by.z] or nil
if fj then
bu{bv.." (read sign)",fj}
elseif gu then
bu{bv,gu.n}
elseif ct.dg then
bu{bv,gb(db,dc,by.z)<1 and 'passage' or 'wall'}
else
bu{bv,bi[mget(db,dc)]}
end
end
function fo(gy,db,dc)
local bv="dialog: "..gy
if bi[mget(db,dc)]=='counter' then
return ff(ez({x=db,y=dc}),fo,nil,gy)
end
local gz=cw[db][dc][by.z]
if gz then
if gz.mch then
bu{cc[gz.mch]()}
elseif gz.d then
bu{bv,'"'..gz.d[flr(rnd(#gz.d)+1)]..'"'}
else
bu{bv,'no response!'}
end
else
bu{bv,'no one to talk with.'}
end
end
function fg(fr,db,dc,fq)
local bv="attack: "..fr
local dd,de=by.z,cw[db][dc][by.z]
local gd=flr(rnd(by.str+by.lvl+by.dmg))
if fq then
gd+=fq
elseif by.i>0 then
bv="fire: "..fr
gd+=rnd(50)
end
if de and de.hp then
if fq or rnd(by.dex+by.lvl*8)>rnd(de.dex+de.ar) then
gd-=rnd(de.ar)
if fq then
de.hc={{9,6},{8,13},{10,12}}
else
de.hc=nil
end
de.hd=3
sfx(1)
de.hp-=gd
if de.hp<=0 then
by.gp=cd(by.gp+de.gp)
gg(de.exp)
if de.n=='pirate' then
cw[db][dc][dd]=bf{
f=de.f,
ot=bm
}
else
cw[db][dc][dd]=nil
end
bu{bv,de.n..' killed; xp+'..de.exp..' gp+'..de.gp}
if de.n=='faxon' then
msg=bb
_draw=dw
end
del(cy[cv],de)
else
bu{bv,'you hit the '..de.n..'!'}
end
if ct.fri then
for ha in all(cy[cv]) do
ha.hos=1
ha.d={"you're a lawbreaker!","criminal!"}
if ha.n=='guard' then
ha.mva=1
end
end
end
else
bu{bv,'you miss the '..de.n..'!'}
end
elseif mget(db,dc)==29 then
sfx(1)
if(not fq)gc(1)
if rnd(gd)>9 then
bu{bv,'you break open the door!'}
mset(db,dc,30)
else
bu{bv,'the door holds.'}
end
else
bu{bv,'nothing to attack.'}
end
end
function hb(hc,hd,he,hf)
local hg=abs(hc-he)
if ct.wrap and hg>ct.w/2 then
hg=ct.w-hg 
end
local hh=abs(hd-hf)
if ct.wrap and hh>ct.h/2 then
hh=ct.h-hh 
end
return hg+hh
end
function ez(de)
local hi,hj=ct.mxx,ct.mxy
local eh,ei=de.x,de.y
local hk,hl=(eh+ct.w-1)%hi,(eh+1)%hi
local hm,hn=(ei+ct.h-1)%hj,(ei+1)%hj
if not ct.wrap then
hm,hn,hk,hl=ei-1,ei+1,eh-1,eh+1
if de~=by then
hm,hn,hk,hl=max(hm,ct.mny),min(hn,hj-1),max(hk,ct.mnx),min(hl,hi-1)
end
end
return {hm,hk,hn,hl}
end
function ho()
local gothit=false
local hp=500
local db,dc,dd=by.x,by.y,by.z
for ed,de in pairs(cy[cv]) do
local hq,hr,hs,ht=de.f,de.x,de.y,de.z
if ht==dd then
while de.mva>=de.nm do
local ey=ez(de)
if de.hos then
local hu=0
hp=hb(de.x,de.y,db,dc)
local hv=hp
local hw=hv
for hx=1,4 do
if hx%2==1 then
hv=hb(de.x,ey[hx],db,dc)
else
hv=hb(ey[hx],de.y,db,dc)
end
if hv<hw or (hv==hw and rnd(10)<5) then
hw,hu=hv,hx
end
end
if hu%2==1 then
hs=ey[hu]
else
hr=ey[hu]
end
de.f=hu
else
if rnd(10)<5 then
if hq and rnd(10)<5 then
if hq%2==1 then
hs=ey[hq]
else
hr=ey[hq]
end
else
local hx=flr(rnd(4)+1)
de.f=hx
if hx%2==1 then
hs=ey[hx]
else
hr=ey[hx]
end
end
end
end
local gq=mget(hr,hs)
if ct.dg then
gq=gb(hr,hs,ht,1)
end
local hy=false
for bp in all(de.t) do
if gq==bp and de.mva>de.nm then
hy=true
break
end
end
de.nm+=1
if de.hos and hp<=1 then
local hz=by.dex+2*by.lvl
local ia="the "..de.n
if de.eat and by.fd>0 and rnd(de.dex*23)>rnd(hz) then
sfx(2)
bu{ia.." eats!"}
ge(flr(rnd(6)))
gothit=true
ib(9)
elseif de.th and by.gp>0 and rnd(de.dex*20)>rnd(hz) then
sfx(2)
local ic=min(ceil(rnd(5)),by.gp)
by.gp-=ic
de.gp+=ic
bu{ia.." steals!"}
gothit=true
ib(9)
elseif de.po and rnd(de.dex*15)>rnd(hz) then
sfx(1)
by.st=bor(by.st,1)
bu{"poisoned by the "..de.n.."!"}
gothit=true
ib(3)
elseif rnd(de.dex*64)>rnd(hz+by.ar) then
by.gothit=true
sfx(1)
local gd=max(rnd(de.dmg)-rnd(by.ar),0)
gc(gd)
bu{ia.." hits!"}
gothit=true
ib(3)
by.hd=3
by.hc=de.ac
else
bu{ia.." misses."}
end
break
elseif hy then
local gr=band(fget(gq),3)
de.mvp+=1
if de.mvp>=gr and not cw[hr][hs][dd] and not (hr==db and hs==dc and ht==dd) then
cw[de.x][de.y][de.z]=nil
cw[hr][hs][ht]=de
de.x,de.y=hr,hs
de.mvp=0
break
end
end
end
de.nm=0
end
end
return gothit
end
function dk()
local el=btnp()
if el~=0 then
coresume(du,ek(el))
end
if di then
di=false
dh+=1
if dh%500==0 then
ch(1)
end
if dh%50==0 then
ge(1)
end
if dh%10==0 then
by.mp=cd(min(by.mp+1,by.int*(by.lvl+1)))
end
if dh%5==0 and band(by.st,1)==1 then
gc(1)
sfx(1,3,8)
bu{"feeling sick!"}
end
gothit=ho()
if #cy[cv]<ct.mxm and rnd(10)<ct.newm then
fw()
end
end
end
function ib(id)
for ie=0,id do
flip()
end
end
function ig(ih)
local ii=flr(ih/16)*512+ih%16*4
if(fget(ih,7))then
for ij=0,448,64 do
reload(ii+ij,ii+ij,4)
fset(ih,band(fget(ih),64))
end
else
for ij=0,448,64 do
memcpy(ii+ij,ii+ij+4,4)
fset(ih,7,true)
end
end
fset(ih,2,true)
end
function ik()
local il,im,io=106,110,119
print("cond",il,0,5)
print(band(by.st,1)==1 and 'p' or 'g',125,0,6)
print("lvl",il,8,5)
print(by.lvl,io,8,6)
print("hp",il,16,5)
print(by.hp,il+8,16,6)
print("mp",il,24,5)
print(by.mp,il+8,24,6)
print("$",il,32,5)
print(by.gp,im,32,6)
print("f",il,40,5)
print(by.fd,im,40,6)
print("exp",il,48,5)
print(by.exp,il,55,6)
print("dex",il,63,5)
print(by.dex,io,63,6)
print("int",il,71,5)
print(by.int,io,71,6)
print("str",il,79,5)
print(by.str,io,79,6)
for ip=1,dp do
print(dn[(dq-ip)%dp+1],0,128-ip*8)
end
end
function iq(ir)
if ir then
for is in all(ir) do
pal(is[1],is[2])
end
end
end
function it(co)
local iu=false
if co.iseq then
co.iseq-=1
if co.iseq<0 then
co.iseq=23
if co.ia then
co.ia=false
if(co.fi==nil)co.i-=1
else
co.ia=true
if(co.fi==nil)co.i+=1
end
end
if co.fi then
iu=co.ia
end
end
palt(0,false)
iq(co.co)
return iu
end
function iv(x,y,iw,ix,iy,iz)
map(x,y,iw*8,ix*8,iy,iz)
for ja=x,x+iy-1 do
for jb=y,y+iz-1 do
local co=cw[ja][jb][0]
if co then
local iu=it(co)
local f=co.fm and co.f or 0
spr(co.i+f,(ja-x+iw)*8,(jb-y+ix)*8,1,1,iu)
pal()
if co.hd>0 then
iq(co.hc)
spr(127,(ja-x+iw)*8,(jb-y+ix)*8)
pal()
co.hd-=1
end
end
end
end
end
function gb(jc,jd,je,jf)
local blk=0
if jc>=ct.mxx or jc<ct.mnx or jd>=ct.mxy or jd<ct.mny then
blk=3
else
local ij=ct.l[je][jd]
ij=flr(shr(ij,(ct.w-jc)*2))
blk=band(ij,3)
end
return jf and (blk>1 and 20 or 22) or blk
end
function jg(jh)
local ji=jh[1]
jh[1]=jh[3]
jh[3]=ji
end
function jj(jc,jd,je,hx)
local jk={}
if hx%2==0 then
for jl=jd-1,jd+1 do
add(jk,{
blk=gb(jc,jl,je),
x=jc,
y=jl
})
end
if hx==4 then
jg(jk)
end
else
for jm=jc-1,jc+1 do
add(jk,{
blk=gb(jm,jd,je),
x=jm,
y=jd
})
end
if hx==3 then
jg(jk)
end
end
return jk
end
function jn(jc,jd,je,hx)
local jk={}
local jm,jl=jc,jd
if hx%2==0 then
for jm=jc+4-hx,jc+2-hx,-1 do
add(jk,jj(jm,jl,je,hx))
end
if hx==4 then
jg(jk)
end
else
for jl=jd-3+hx,jd-1+hx do
add(jk,jj(jm,jl,je,hx))
end
if hx==3 then
jg(jk)
end
end
return jk
end
function ex()
cls()
if by.lit>0 then
local jo=jn(by.x,by.y,by.z,by.f)
for jp,ij in pairs(jo) do
local jq,jr=(jp-1)*10,jp*10
local js,jt,ju,jv=30-jr,30-jq,52+jr,52+jq
local jw,jx,jy,jz,ka=30-jr*2,52+jr*2,42,31-jq,51+jq
if ij[1].blk==3 then
rectfill(js,js,jt,ju,0)
line(jw,js,js,js,5)
line(js,js,jt,jt)
line(js,ju,jt,jv)
line(jw,ju,js,ju)
end
if ij[3].blk==3 then
rectfill(jv,jt,ju,ju,0)
line(ju,js,jx,js,5)
line(jv,jt,ju,js)
line(jv,jv,ju,ju)
line(ju,ju,jx,ju)
end
if jp>1 then
local kb,kc,kd=jo[jp-1][1].blk,jo[jp-1][2].blk,jo[jp-1][3].blk
if (ij[1].blk==kc and ij[1].blk==3) or
(ij[1].blk~=kb) then
line(jt,jt,jt,jv,5)
end
if (ij[3].blk==kc and ij[3].blk==3) or
(ij[3].blk~=kd) then
line(jv,jt,jv,jv,5)
end
if kc==3 and kb==3 and ij[1].blk~=3 then
line(jt,jz,jt,ka,0)
end
if kc==3 and kd==3 and ij[3].blk~=3 then
line(jv,jz,jv,ka,0)
end
end
if ij[2].blk==3 then
rectfill(js,js,ju,ju,0)
line(js,js,ju,js,5)
line(js,ju,ju,ju)
if ij[1].blk<3 then
line(js,js,js,ju)
end
if ij[3].blk<3 then
line(ju,js,ju,ju)
end
end
ke(ij[2].x,ij[2].y,by.z,3-jp)
end
rectfill(82,0,112,82,0)
end
ik()
end
function ke(db,dc,dd,kf)
if db>0 and dc>0 then
local co=cw[db][dc][dd]
if co then
local iu,kg,shm,szm=it(co),kf*3,co.shm or 0,co.szm or 0
local kh,ki=20+kg+(szm*(kf+1)/8),35-(3-kf)*shm
local kj=60-szm-kg*4
sspr(co.i%16*8,flr(co.i/16)*8,8,8,kh,ki,kj,kj,iu)
pal()
if co.hd>0 then
palt(0,true)
iq(co.hc)
sspr(120,56,8,8,kh,ki,kj,kj)
pal()
co.hd-=1
palt(0,false)
end
end
end
end
function dw()
cls()
print(msg)
end
function dl()
local hi,hj,kk,kl=ct.mxx,ct.mxy,ct.mnx,ct.mny
local iy,iz,wrap=ct.w,ct.h,ct.wrap
local km,kn,ko,kp,iw,ix,kq,kr=0,0,0,0,0,0,by.x-ba,by.x+ba
if kq<kk then
ko=kk-kq
iw=ko
if wrap then
km=kq%iy+kk
end
kq=kk
elseif kr>=hi then
if wrap then
ko=y-kr+hi-1
iw=ko
km=kq
kq,kr=kk,kr%iy+kk
else
ko=kr-hi+1
kr=hi
end
end
local ks,kt=by.y-z,by.y+z
if ks<kl then
kp=kl-ks
ix=kp
if wrap then
kn=ks%iz+kl
end
ks=kl
elseif kt>=hj then
if wrap then
kp=x-kt+hj-1
ix=kp
ix,kn=kp,ks
ks,kt=kl,kt%iz+kl
else
kp=kt-hj+1
kt=hj
end
end
local ku,kv=min(y-ko,ct.w),min(x-kp,ct.h)
if dj%16==0 then
for ih=10,14,2 do
ig(ih)
end
end
dj+=1
cls()
if wrap then
if ko then
iv(km,ks,0,ix,ko,kv)
end
if kp then
iv(kq,kn,iw,0,ku,kp)
end
if ko and kp then
iv(km,kn,0,0,ko,kp)
end
end
iv(kq,ks,iw,ix,ku,kv)
palt(0,false)
if by.color==4 and by.i==0 then
iq{{4,1},{15,4}}
end
spr(by.i+by.f,48,40)
pal()
palt()
if by.hd>0 then
iq(by.hc)
spr(127,48,40)
pal()
by.hd-=1
end
ik()
end