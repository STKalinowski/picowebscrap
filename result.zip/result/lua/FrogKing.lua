--frog king
--by pixpnd
game_state="menu"
pl={}
msg1="the double jump is unlocked!"
pl.x=3*8
pl.y=8*8
pl.w=5
pl.h=5
pl.hsp=0
pl.vsp=0
pl.fr=1
pl.ms=2
pl.mv=0
pl.sx=1
pl.sy=2
pl.cx=8
pl.cy=13
pl.fl=false
pl.can_dj=false
pl.can_jump=true
pl.dj=true
pl.notset=true
pl.anim='stand'
pl.state='live'
pl.alr1=-1
timer=0
timer2=-1
mseconds=0
seconds=0
minutes=0
deaths=0
menu_frame=1 
sfx_enable=true
music_enable=true
restarted = false
k_jpress=false
curr_lvl=0
objs={}
particles={}
cam={}
squares={}
cam.x=pl.x-64+pl.hsp
cam.y=pl.y-64+pl.vsp
shrat=0
msg_timer=0
function cr_obj(x,y,t,s)
 local o={}
 o.x=x
 o.y=y
 o.t=t
 o.s=s
 o.alr1=15
 if (t==1) o.w,o.h,o.sx,o.sy=8,8,0,0
 if (t==2) o.w,o.h,o.sx,o.sy,o.state,o.dist,o.fr=15,15,0,0,"stand",0,37
 if (t==3) o.w,o.h,o.sx,o.sy=7,6,0,1
 if (t==4) o.w,o.h,o.sx,o.sy=7,4,0,1
 if (t==5) o.w,o.h,o.sx,o.sy,o.fr,o.a,o.alr1=8,16,0,0,34,false,0
 if (t==6) o.w,o.h,o.sx,o.sy=8,8,0,0
 if (s==1 and t==4) o.fliped=false
 if (s==-1 and t==4) o.fliped=true
 add(objs,o)
end
function sfx_onoff()
 if sfx_enable==true then
  sfx_enable=false 
  else 
  sfx_enable=true
 end
end
function music_onoff()
  if music_enable==true then
   music_enable=false
   music(-1)
  else 
   music_enable=true
   if (game_state=="menu") music(0)
   if (game_state=="game") music(3)
   if (game_state=="end") music(18)
 end
end
function cr_part(x,y,t,c,s)
 local p={}
 p.x=x
 p.y=y
 p.t=t
 p.c=c
 p.alr1=0
 if p.t==1 then
  local angle=rnd(60)+270
  p.vsp=lineartoy(1,angle)
  p.hsp=lineartox(1,angle)*s
  p.r=2+rnd(1)
 end
 if p.t==3 then 
  p.r=2+rnd(2)
  p.s=rnd(0.5)-0.25
 end
 if p.t==4 then 
  p.r=2+rnd(2)
  p.s=rnd(0.5)-0.25
 end
 if p.t==5 then
  local angle=rnd(10)
  p.vsp=lineartoy(2,angle)
  p.hsp=lineartox(2,angle)*s
  p.r=2+rnd(1)
 end
 if p.t==6 then
  local angle=rnd(120)-60
  if (s<0) angle-=180 p.x+=8
  if (angle<0) angle+=360
  p.vsp=lineartoy(2,angle)
  p.hsp=lineartox(2,angle)
  p.r=2+rnd(1)
 end
 add(particles,p)
end
function create_sqr(x,y,c)
 local sqr={}
 sqr.x=x
 sqr.y=y
 sqr.c=c
 sqr.w=1
 sqr.h=1
 sqr.st="+"
 add(squares,sqr)
end
function _init()
update_camera()
 for i=0,127 do
    for o=0,63 do
     if fget(mget(i,o),0)==false then
      if fget(mget(i,o),6) then
       cr_obj(i*8,o*8,2)
       mset(i,o,0)
      end

      if fget(mget(i,o),4) then
       cr_obj(i*8,o*8,1)
       mset(i,o,0)
      end

      if fget(mget(i,o),5) then
       cr_obj(i*8,o*8,5)
       mset(i,o,0)
      end

      if fget(mget(i,o),7) then
       cr_obj(i*8,o*8,3)
       mset(i,o,0)
      end
     end
     if fget(mget(i,o),0) then
      if fget(mget(i,o),4) then
       cr_obj(i*8,o*8,6)
       mset(i,o,0)
      end
      if fget(mget(i,o),6) then
       cr_part(i*8,o*8,2,1)
      end
     end
   end
end
music(0)
end
function _update()
 if sfx_enable==true then
  menuitem(1, "disable sfx", sfx_onoff)
 else
  menuitem(1, "enable sfx", sfx_onoff)
 end
  if music_enable==true then
  menuitem(2, "disable music", music_onoff)
 else
  menuitem(2, "enable music", music_onoff)
 end
 if game_state=="menu" then
  if (btn(4) or btn(0) or btn(1) or btn(2) or btn(3))==false then
   k_jpress = false
  end
  if (btn(4) or btn(0) or btn(1) or btn(2) or btn(3)) and k_jpress==false then 
   menu_frame+=1
   k_jpress = true
  end
  if menu_frame>2 then 
   game_state='game'
   music(3)
  end
 end
 if msg_timer>-1 then
  msg_timer-=1
 end
 if game_state=="game" then
  update_player()
  foreach(objs,update_obj)
  update_camera()
  foreach(squares,update_sqr) 
  mseconds+=100/30
  if (mseconds>100) seconds+=1 mseconds-=100
  if (seconds>60) minutes+=1 seconds-=60
  if (timer2>0) timer2-=1
  if timer2==0 then
  game_state='end' 
  menu_frame=1
  cam.x,cam.y=0,0
  camera(cam.x,cam.y)
  if (music_enable==true) music(18)
  timer2=60
  end
 end
 if game_state=="end" then
  if (btn(4) or btn(0) or btn(1) or btn(2) or btn(3))==false then
   k_jpress = false
  end
  if (btn(4) or btn(0) or btn(1) or btn(2) or btn(3)) and k_jpress==false and timer2==0 and menu_frame<3 then 
   menu_frame+=1
   k_jpress = true
  end
  if (timer2>0) timer2-=1
 end
  foreach(particles,update_part)
end

function _draw()
 cls()
 if game_state~="end" then
  map(0,0,0,0,128,64)
  foreach(objs,draw_objs)
  foreach(particles,draw_part)
  draw_player()
  --print(deaths,0+cam.x,0+cam.y,7)
  --print(minutes..":"..seconds..":"..mseconds-mseconds%1,0+cam.x,0+cam.y,7)
  --print(stat(0),0+cam.x,0+cam.y,7)
  --print(stat(1),0+cam.x,6+cam.y,7)
  --print(#objs,0+cam.x,12+cam.y,7)
  --print(#particles,0+cam.x,18+cam.y,7)
  if game_state=="menu" then
   rectfill(0,0,128,128,0)
   --rect(5,5,122,55,1)
   for i=0,15 do
    spr(11,0+8*i,116)
   end
   for i=0,15 do
    spr(27,0+8*i,124)
   end
   --print(menu_frame,0,0,7)
   if menu_frame==1 then
   sspr(56,40,32,16,48,24)
   spr(86,36,28,1,1)
   spr(86,84,28,1,1,true)
   print('a game by @pixpnd',31,43,7)
   end
   if menu_frame==2 then
    print("according to ancient legend,\nthe crown of the king of \nfrogs is hidden in the \nmysterious temple to the \nnorth of the marshes. \ni must try to get it and \nbecome a king.",8,16,7)
   end
   spr(93,52,92,3,3)
   sspr(64,24,24,16,65,57)
   sspr(24,56,24,8,65,73)
   --spr(56,65,65,3,3)
   sspr(88,26,24,13,24,72)
   sspr(88,26,24,13,80,72)
   --52 92
  end
  if msg_timer>0 then
   rectfill(6+cam.x,8+cam.y,122+cam.x,32+cam.y,0)
   rect(6+cam.x,8+cam.y,122+cam.x,32+cam.y,1)
   print(msg1,cam.x+64-(#msg1*2)+1,18+cam.y,2)
  end
 end
 foreach(squares,draw_sqr)
 if game_state=="end" then
  rectfill(0,0,128,128,0)
   --rect(5,5,122,55,1)
   for i=0,15 do
    spr(11,0+8*i,116)
   end
   for i=0,15 do
    spr(27,0+8*i,124)
   end
      spr(93,52,92,3,3)
      spr(1,60,108)
   sspr(64,24,24,16,65,57)
   sspr(24,56,24,8,65,73)
   --spr(56,65,65,3,3)
   sspr(88,26,24,13,24,72)
   sspr(88,26,24,13,80,72)
   if menu_frame==1 then
    print("congratulations!",64-#'congratulations!'*2-1,8,7)
    print("you have got a crown",64-#"you have got a crown"*2-1,14,7)
    print("and",64-#"and"*2-1,20,7)
    print("have become a king of frogs!",64-#"have become a king of frogs!"*2-1,26,7)
    print("time:"..minutes..":"..seconds..":"..mseconds-mseconds%1,64-#("time:"..minutes..":"..seconds..":"..mseconds-mseconds%1)*2-1,32,7)
    print("deaths:"..deaths,64-#("deaths:"..deaths)*2-1,38,7)
   end 
   if menu_frame==2 then
    print('frog king by @pixpnd\n',8,8,7)
    print('♥special thanks for support♥:',8,14,8)
    print('neutrino pretty, 33 dudes,\ntelegram group "gamin",\nblast,oem_def,echigrus',8,20,7)
   end
   if menu_frame==3 then
    print("thanks for playing!",64-#"thanks for playing!"*2-1,14,7)
   end
   if (menu_frame<3) spr(118,104,104) print("press\njump\nbutton",81,97,7)
 end
end
-->8
function collide_tile(x,y,w,h,sx,sy,nf)
 ul=mget(flr((x+sx)/8),flr((y+sy)/8))
 dl=mget(flr((x+sx)/8),flr((y+sy+h)/8))
 ur=mget(flr((x+sx+w)/8),flr((y+sy)/8))
 dr=mget(flr((x+sx+w)/8),flr((y+sy+h)/8))
return fget(ul,nf) or
       fget(dl,nf) or
       fget(ur,nf) or
       fget(dr,nf)
end

function collide_obj(x1,y1,w1,h1,x2,y2,w2,h2)
  return x1<=x2+w2 and
         x2<=x1+w1 and
         y1<=y2+h2 and
         y2<=y1+h1
end

function sign(a)
 if (a>0) return 1
 if (a<0) return -1
 if (a==0) return 0
end

function lerp(a,b,t) 
 return (1-t)*a+t*b 
end

function lineartox(r,t)
t=t/360
return r*cos(t)
end
function fade()
  for x=1,16 do
   for y=1,16 do
    create_sqr(x*8-8,y*8-8,1)
  end
 end
end
function lineartoy(r,t)
t=t/360
return r*sin(t)
end
-->8
function restart()
 pl.x=pl.cx
 pl.y=pl.cy
 pl.hsp,pl.vsp=0,0
 pl.state="live"
 restarted = true
 shrat=0
end

function update_camera()
 if pl.state=="live" then
   cam.x=lerp(cam.x,pl.x-64+pl.hsp*2,0.15)
   if collide_tile(pl.x,pl.y,pl.w,pl.h,pl.sx,pl.sy,1) then
   cam.y=lerp(cam.y,pl.y-64+pl.vsp*2,0.2)
   else
   cam.y=lerp(cam.y,pl.y-64+pl.vsp*2,0.07)
   end
  if (cam.x<0) cam.x=0
  if (cam.y<0) cam.y=0
  screenshake()
  camera(cam.x,cam.y)
 end
end
-->8
function update_player()
 if pl.state=="live" then
  buttons()
  move()
  grav()
  can_stand=0
  foreach(objs,coll_pl_obj)
  coll_pl_tile()
  if (can_stand>0) can_stand=true; pl.dj=true else can_stand=false
  anim()
  if collide_tile(pl.x,pl.y,pl.w-1,pl.h-1,pl.sx+1,pl.sy+1,2) then
   kill_pl()
  end
  if collide_tile(pl.x,pl.y,pl.w,pl.h,pl.sx,pl.sy,3) then
   next_level()
  end
 end
 if pl.state=="death" then
  dead_player()
 end
 pl.x+=pl.hsp
 pl.y+=pl.vsp
end

function buttons()
 if (btn(0)) k_l=1 else k_l=0
 if (btn(1)) k_r=1 else k_r=0
 if (btn(2) or btn(4)) k_jp=1 else k_jp=0
 pl.mv=-k_l+k_r
end


function move()
 pl.hsp+=pl.mv
 if pl.hsp > pl.ms or pl.hsp < -pl.ms then
  pl.hsp = sign(pl.hsp) * pl.ms
 end
 if pl.mv==0 then
  if collide_tile(pl.x,pl.y+1,pl.w,pl.h,pl.sx,pl.sy,3)==false then
   pl.hsp-=sign(pl.hsp); 
  end
 end
end

function grav()
 if (pl.vsp<8) pl.vsp+=0.75
 if k_jp==1 and k_jpress==false and (collide_tile(pl.x,pl.y+1,pl.w,pl.h,pl.sx,pl.sy,1) or pl.can_jump==true or can_stand==true) then
  pl.vsp=-5
  k_jpress=true
 end
 if k_jp==1 and k_jpress==false and not(collide_tile(pl.x,pl.y+1,pl.w,pl.h,pl.sx,pl.sy,1) or pl.can_jump==true or can_stand==true) and pl.dj==true and pl.can_dj==true then
  pl.vsp=-5
  pl.dj=false
  k_jpress=true
  if (sfx_enable==true) sfx(8)
  for i=1,6 do
   cr_part(pl.x+4+pl.hsp,pl.y+4,1,6,1)
   cr_part(pl.x+4+pl.hsp,pl.y+4,1,6,-1)
  end
 end
 if (k_jp==0) k_jpress=false
 if collide_tile(pl.x,pl.y+1,pl.w,pl.h,pl.sx,pl.sy,1)==false then
  pl.can_jump=false
 else
  pl.dj=true
  pl.can_jump=true
 end
end

function dead_player()
  cr_part(pl.x+4,pl.y+4,4,10)
  if (timer>10) pl.fr+=1; timer=0
  if (pl.fr>7) pl.fr=4
  if (pl.vsp<8) pl.vsp+=0.5
end

function coll_pl_tile()
 local x,y,hsp,vsp=pl.x,pl.y,pl.hsp,pl.vsp
 if collide_tile(x+hsp,y,pl.w,pl.h,pl.sx,pl.sy,1) then
  if collide_tile(x+hsp,y-1,pl.w,pl.h,pl.sx,pl.sy,1)==true then
   while collide_tile(x+sign(hsp),y,pl.w,pl.h,pl.sx,pl.sy,1)==false do
    x+=sign(hsp)
   end
  hsp=0
  else
   y-=1
  end
 end
 if collide_tile(x+hsp,y+vsp,pl.w,pl.h,pl.sx,pl.sy,1) then 
   while collide_tile(x+hsp,y+sign(vsp),pl.w,pl.h,pl.sx,pl.sy,1)==false do
    y+=sign(vsp)
   end
  if vsp > 6 then
   if collide_tile(pl.x,pl.y+6,pl.w,pl.h,pl.sx,pl.sy,1) then
    for i=1,3 do
     cr_part(x+rnd(8)+hsp,y+8,5,6,1)
     cr_part(x+rnd(8)+hsp,y+8,5,6,-1)
    end
   end
  end
  vsp=0
 end
 if collide_tile(x+hsp,y+vsp,pl.w,pl.h,pl.sx,pl.sy,7) and timer2==-1then
  timer2=60
 end
 pl.x,pl.y,pl.hsp,pl.vsp=x,y,hsp,vsp 
end

function coll_pl_obj(o)
 local x1,y1,w1,h1,hsp,vsp=pl.x+pl.sx,pl.y+pl.sy,pl.w,pl.h,pl.hsp,pl.vsp
 local x2,y2,w2,h2=o.x+o.sx,o.y+o.sy,o.w,o.h
 if pl.state=="live" then
  if collide_obj(x1+hsp,y1,w1,h1,x2,y2,w2,h2) and (o.t<4) then
   while collide_obj(x1+sign(hsp),y1,w1,h1,x2,y2,w2,h2)==false do
    x1+=sign(hsp)
   end
   hsp=0
  end
  if (x1+hsp<0) hsp=0
  if collide_obj(x1+hsp,y1+vsp,w1,h1,x2,y2,w2,h2) and (o.t<4) then
   while (collide_obj(x1+hsp,y1+sign(vsp),w1,h1,x2,y2,w2,h2))==false do
    y1+=sign(vsp)
   end
   vsp=0
  end
 end
 if collide_obj(x1,y1+1,w1,h1,x2,y2,w2,h2) and o.t==1 then
  vsp=-8
  if (sfx_enable==true) sfx(6);
  o.alr1=1
  pl.dj=true
 end
 if collide_obj(x1,y1+1,w1,h1,x2,y2,w2,h2) and (o.t==2 or o.t==3)then
  can_stand+=1
 end
 pl.x,pl.y,pl.hsp,pl.vsp = x1-pl.sx,y1-pl.sy,hsp,vsp
 if collide_obj(x1,y1,w1,h1,x2,y2,w2,h2) and o.t==4 then
  kill_pl()
 end
 if collide_obj(x1,y1,w1,h1,x2,y2,w2,h2) and o.t==6 then
  del(objs,o)
  pl.can_dj=true
  msg_timer=120
  if (sfx_enable==true) sfx(11)
 end
 if collide_obj(x1,y1,w1,h1,x2,y2,w2,h2) and o.t==5 and o.a==false then
  pl.cx=x2
  pl.cy=y2+8
  o.a=true
  if (sfx_enable==true) sfx(9)
 end
end
function anim()
  if (pl.hsp > 0) pl.fl=false
  if (pl.hsp < 0) pl.fl=true
  if (pl.hsp!=0 and pl.vsp==0) pl.anim='run'
  if (pl.vsp>0) pl.anim='fall'
  if (pl.vsp<0) pl.anim='jump'
  if (pl.hsp==0 and pl.vsp==0) pl.anim='stand'
  if (pl.anim=='stand' and pl.fr!=1) pl.fr=1
  if pl.anim=='run' then
   timer+=1
   if (timer>(pl.hsp*sign(pl.hsp))) timer=0; pl.fr+=1
   if (pl.fr>3) pl.fr=1
  end 
  if (pl.anim=='jump' and pl.fr!=2) pl.fr=2
  if (pl.anim=='fall' and pl.fr!=3) pl.fr=3
end

function kill_pl()
 local r=5
 local t=rnd(90)+45
 pl.hsp=lineartox(r,t)
 pl.vsp=lineartoy(r,t)
 pl.state='death'
 pl.fr=4
 deaths+=1
 if (sfx_enable==true) sfx(7)
 fade()
end
function screenshake()
 local angle=rnd(360)
 cam.x+=lineartox(shrat,angle)
 cam.y+=lineartoy(shrat,angle)
 shrat*=0.8
end
-->8
function update_obj(o1)
 o1.alr1+=1
 --spring
 if (o1.t==1 and o1.alr1>15) o1.fr=19
 if (o1.t==1 and o1.alr1<15) o1.fr=18
 --evil block
 if o1.t==2 then 
  if o1.state=="stand" and o1.x<pl.x+pl.w and pl.x<o1.x+o1.w and pl.state=="live" and o1.y<pl.y and collide_obj(o1.x+o1.sx,o1.y+o1.sy,o1.w,o1.h,cam.x,cam.y,128,128) then 
   o1.state="fall"
   o1.fr=8
  end
  if o1.state=="fall" then
   o1.y+=3
   o1.dist+=3
   if collide_tile(o1.x,o1.y+3,o1.w,o1.h,o1.sx,o1.sy,1) then
    if (sfx_enable==true) sfx(4)
    o1.state="wait"
    o1.fr=37
    o1.alr1=0
    shrat+=4
    for i=1,4 do
     cr_part(o1.x+rnd(16),o1.y+16,5,6,-1)
     cr_part(o1.x+rnd(16),o1.y+16,5,6,1)
    end
   end
   if pl.state=="live" and (collide_obj(pl.x+pl.sx,pl.y+pl.sy,pl.w,pl.h,o1.x,o1.y,o1.w,o1.h)) and (o1.y<pl.y) then
   kill_pl()
   end
  end
  if o1.state=="wait" then
   o1.alr1+=1
   if o1.alr1>30 then
    o1.state="return"
   end
  end
  if o1.state=="return" then
   o1.y-=1
   o1.dist-=1
   if collide_obj(pl.x+pl.sx,pl.y+pl.sy,pl.w,pl.h,o1.x,o1.y-1,o1.w,o1.h) and pl.state=="live" then
    pl.y-=1
   end
   if (o1.dist==0) o1.state="stand"
  end
 end
 --sentry gun
 if o1.t==3 then
  o1.alr1+=1
  if o1.alr1>=90 then
  o1.fr=36
  end
  if o1.alr1<90 then
  o1.fr=20
  end
  if o1.alr1>120 then
   if collide_obj(o1.x+o1.sx,o1.y+o1.sy,o1.w,o1.h,cam.x-64,cam.y-64,256,256) then
    if collide_tile(o1.x+8,o1.y,o1.w,o1.h,o1.sx,o1.sy,1)==false then
     cr_obj(o1.x+8,o1.y,4,1) 
    end
    if collide_tile(o1.x-8,o1.y,o1.w,o1.h,o1.sx,o1.sy,1)==false then
     cr_obj(o1.x-8,o1.y,4,-1)
    end
    if (sfx_enable==true) sfx(10)
   end
   o1.alr1=0
   end
  end
 --bullet
 if o1.t==4 then
  o1.x+=o1.s*2
  if collide_tile(o1.x+o1.s*2,o1.y,o1.w,o1.h,o1.sx,o1.sy,1) then
   del(objs,o1)
   if collide_obj(o1.x,o1.y,o1.w,o1.h,cam.x,cam.y,128,128) then
    for i=1,8 do
     cr_part(o1.x,o1.y+4,6,7,o1.s*-1)
     if (sfx_enable==true) sfx(5)
    end
   end
  end
  ob1 = o1
  foreach(objs,collide_bull)
 end
 --checkpoint
 if o1.t==5 then
  if o1.a==true then
   o1.f=49
   cr_part(o1.x+4,o1.y+4,4,10)
  else
   o1.f=34
  end
  if (collide_obj(o1.x+o1.sx,o1.y+o1.sy,o1.w,o1.h,cam.x,cam.y,128,128))==false and o1.a==true then
   o1.a=false
  end
 end
end

function collide_bull(o2)
 if ob1~=o2 then
  if collide_obj(ob1.x+ob1.sx,ob1.y+ob1.sy,ob1.w,ob1.h,o2.x,o2.y,o2.w,o2.h) then
   del(objs,ob1)
  end
 end
end

function update_part(p)
 --death part
 if p.t==1 then
  p.r-=rnd(0.4)
  p.x+=p.hsp
  p.y+=p.vsp
  if (p.r<0) del(particles,p)
  if (p.r<0) del(particles,p)
 end
 --torch
 if p.t==2 then
  if collide_obj(p.x,p.y,8,8,cam.x-8,cam.y-8,134,134) then
   cr_part(p.x+3,p.y+2,3,10)
  end
 end
 --fire
 if p.t==3 then
  if p.x>cam.x-8 and p.x+8>cam.x+8 and p.y>cam.y-8 and p.y+8>cam.y+8 then
   if (p.alr1>0 and p.c==10) p.c=9
   if (p.alr1<1) p.alr1+=1
   p.r-=rnd(0.3)
   p.y-=1+rnd(0.5)
   p.x+=p.s*sin(p.r/4)
   if (p.r<1.5) p.c=8
   if (p.r<1) p.c=1
   if (p.r<0) del(particles,p)
  end
 end
 if p.t==4 then
  if (p.alr1>0 and p.c==10) p.c=11
  if (p.alr1<1) p.alr1+=1
  p.r-=rnd(0.3)
  p.y-=1+rnd(0.5)
  p.x+=p.s*sin(p.r/4)
  if (p.r<1.5) p.c=3
  if (p.r<0) del(particles,p)
 end
 --dust
 if p.t==5 or p.t==6 then
  p.r-=rnd(0.4)
  if (p.r<0) del(particles,p)
  p.hsp=lerp(p.hsp,0,0.05)
  p.vsp=lerp(p.vsp,0,0.05)
  p.x+=p.hsp
  p.y+=p.vsp
 end
end
function update_sqr(s)
 if s.st=="-" then
  s.w=lerp(s.w,0,0.08)
  s.h=lerp(s.h,0,0.08)
  if s.w<1.5 then
   del(squares,s)
  end
 end
 if s.st=="+" then
  s.w=lerp(s.w,9,0.075)
  s.h=lerp(s.h,9,0.075)
  if s.w>8.5 then
   s.st="-"
   s.w=8
   s.h=8
   if pl.state=="death" then
   restart()
   cam.x=pl.x-64
   cam.y=pl.y-64
   camera(cam.x,cam.y)
   end
  end
 end
end
-->8
function draw_objs(o)
 if o.x+o.w>cam.x and o.x<cam.x+144 and o.y+o.h>cam.y and o.y<cam.y+144 then
  if (o.t==1) spr(o.fr,o.x,o.y)
  if (o.t==2) spr(o.fr,o.x,o.y,2,2)
  if (o.t==3) spr(o.fr,o.x,o.y)
  if (o.t==4) spr(33,o.x,o.y,1,1,o.fliped)
  if o.t==5 then 
   spr(50,o.x,o.y+8)
   spr(o.f,o.x,o.y)
  end
  if (o.t==6) spr(35,o.x,o.y)
 end
end
function draw_sqr(s)
 rectfill(s.x+cam.x,s.y+cam.y,s.x+s.w+cam.x,s.y+s.h+cam.y,s.c)
end
function draw_part(p)
 if p.x>cam.x-8 and p.x+8>cam.x+8 and p.y>cam.y-8 and p.y+8>cam.y+8 then
  if (p.t~=2) circfill(p.x,p.y,p.r,p.c)
  if (p.t==2) spr(100, p.x,p.y)
 end
end

function draw_player()
 spr(pl.fr,pl.x,pl.y,1,1,pl.fl,false)
 --rectfill(pl.x+pl.sx,pl.y+pl.sy,pl.x+pl.sx+pl.w,pl.y+pl.sy+pl.h,8)
end