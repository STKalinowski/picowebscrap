--rolly
--by davbo and rory

function _init()
 --constants
 pixel=0.125
 
 --collision offset
 coloffset=0.001
 
 jumpframesoffset=5
 
 --jump physics consts
 airgravity,airtvel=0.04,0.45
 wallgravity,walltvel=0.02,0.275
 
 currentgravity=airgravity
 currenttvel=airtvel
 
 --checkpoint
 
 --keep hub
 xcp=63
 ycp=26
 
 cpanim=makeanimt(10,5,4)

 --avatar
 av={
  --movement consts
  xgroundacc=0.025,
  xgrounddecel=0.4,
  xairacc=0.02,
  xairdecel=0.9,
  
  xmaxvel=0.2,
  xrollmaxvel=0.25,
  xcurrentmaxvel=xmaxvel,
  
  yjumpforce=0.4,
  ywalljumpforce=0.46,
  
  maxstickframes=8,
  maxjumpframes=10+jumpframesoffset,
  
  --width and height consts
  w=pixel*8,
  h=pixel*8,
  
  --hitradius for game object
  -- circle colision
  r=pixel*4,
  
  --non-resetting vars
  inventory="none"
 }
 
 --death reset vars
 avreset()
 
 --creates based on x,y,h,w
 updatehitboxes()
 
 --game objects
 switches={}
 switchesanim=makeanimt(114,2,15)
 
 keys={}
 keysanim=makeanimt(45,5,4)
 keysflipped=false
 
 exitorbs={}
 
 --check map and convert
 -- to game objects
 for x=0,127 do
  for y=0,63 do
   if checkflag(x,y,4) and
      checkflag(x,y,5) then
    createswitch(x,y)
    mset(x,y,0)
   end
   
   if checkflag(x,y,4) and
      checkflag(x,y,6) then
    createkey(x,y)
    mset(x,y,0)
   end
   
   if not checkflag(x,y,4) and
      checkflag(x,y,5) and
      not checkflag(x,y,6) then
    local orb={
     x=x,
     y=y
    }
    add(exitorbs,orb)
   end
  end
 end
 
 --crumble blocks-tab 4
 initcbs()
 
 --backgrounds-tab 5
 initbgs()
 
 playingtune=""
 
 xmap,ymap=2,0
 lockcamera=false
 
 --swap these out for states
 currentupdate=updateintro
 currentdraw=drawintro
 
 --comment this...
 initintro()
 
 --...and uncomment these three
 -- to skip intro
 --currentupdate=updateplaying
 --currentdraw=drawplaying
 --menuitem(1,"reset to hub",avpausetohub)
 
 --stats for end screen
 deaths=0
 milliseconds,seconds,minutes,hours=0,0,0,0

	playendingtune=false
 musictimer=0
 musicnext=0
 
 ylogo=19
 ylogovel=0
 logocounter=0
 
 --y pos for orbs
 yorboffset=0
 ycen=0
 
 friends={}
 friendsanim=makeanimt(99,2,2)
 prevreactions={}
end

function _update()
 yorboffset=sin(milliseconds/30)*1.5
 ycen=26.2*8+yorboffset

 currentupdate()
end

function updateplaying()
 updateplaytime()
 updatecamera()
 updatesfx()
 
 if not av.warping then
  if inhub() and
     not inhub(xcp,ycp) then
   --reset prev
   mset(xcp,ycp,9)
   xcp,ycp=63,26
  end
  
  --needs to be before input
  updatespikecollision()
 end
 
 if not av.warping then
  if av.pauseanim=="none" or
     av.pauseanim=="squish" then
   updateinput()
  end
 
  updatecbs() --tab 4
  updatecollision()
  updateav()
 end
 updatefriends()

 updatehitboxes()
 updateanim()
 
 --if turning kick up dust
 -- #lastminute #throwitwherever
 if av.anim.basesprite==78 then
  initdustkick(sgn(av.xvel),-0.7,
   0.5,1,
   1,1)
 end

 updatekeys() --tab 4
 updatebgs() --tab 5
 updateparticles() --tab 6
 updatemusic()
end

function updateplaytime()
 milliseconds+=1
 
 if milliseconds==30 then
  seconds+=1
  milliseconds=0
  if seconds==60 then
   minutes+=1
   seconds=0
   if minutes==60 then
    hours+=1
    minutes=0
   end
  end
 end
end

function updatecamera()
 if (lockcamera) return

 --screen by screen
 -- don't allow camera off map
 if av.x>0 and av.x<127 then
  xmap=flr((av.x+av.w*0.5)/16)
 end

 if av.y>0 and av.y<63 then
  --boost if moving up a screen
  local ytempmap=flr((av.y+av.h*0.5)/16)
  if ytempmap<ymap then
   av.yvel=-av.yjumpforce
  end
  
  ymap=ytempmap
 end

 --focus on centerpiece
 if av.x>55.5 and av.x<71.5 and
    ymap==1 then
  xmap=3.5
 elseif inhub() and logocounter>=0 then
  --logo fly off
  logocounter=160
 end

 camera(xmap*128,ymap*128) 
end

--some sfx require releasing
function updatesfx()
 --dont interupt cutscenes
 if (av.pauseanim!="none") return

 --warping
 if av.warping and
    av.playingsfx=="none" then
  av.playingsfx="warping"
  sfx(45,2)
 end
 
 if --warping
   not av.warping and
   (av.playingsfx=="none" or
   av.playingsfx=="warping") then
  av.playingsfx="none"
  sfx(-2,2)
 end
 
 --walking sfx
 if (av.rolling=="none" or
    av.rolling=="jumping") and
    av.onground and
    not av.warping then
  if av.xvel!=0 then
   walksfx()
  else
   releasesfx()
  end
 end
 
 --release various sfx
 if --stop walking
   not av.warping
   and
   (not av.onground
   and
   (av.playingsfx=="whub" or
   av.playingsfx=="wcave"))
   or --stopped ground roll
   (av.rolling!="ground" and
   av.playingsfx=="ground") then
  releasesfx()
 end
end

function updatespikecollision()
 --spikes
 if spikecol() then
  releasesfx()
  avsfx(25)
  deaths+=1
  initdeath() --particles
  av.warping=true
  av.yvel,av.xvel=0,0
  if (av.inventory=="tempkey") keyreset()
 end
end

function updateinput()
 --roll
 if btnp(❎) then
  if av.rolling!="air"
     and --in the air
     (not av.onground
     or --standing->air roll
     (btnp(🅾️) or btn(⬆️))
     or --ground roll->air roll
     av.rolling=="ground") then
   airroll()
  elseif av.onground and
         av.rolling=="none" then
   groundroll()
  end
 end

 --rolls have higher maxvel
 if av.rolling!="none" then
  av.xcurrentmaxvel=av.xrollmaxvel
 else
  av.xcurrentmaxvel=av.xmaxvel
 end

 --jump set dy
 if btnp(🅾️) and
    (av.rolling=="none" or
    av.rolling=="ground") then
  jump()
 end
 
 --variable jump hight calcs
 if av.jumping and
    av.jumpframes<av.maxjumpframes then
  av.jumpframes+=1
 end

 if not btn(🅾️) and
    av.jumping then
  local fraction=av.jumpframes/av.maxjumpframes
  av.yvel*=fraction
  av.jumpframes=jumpframesoffset
  av.jumping=false
 end
 
 if av.rolling=="none" or
    av.rolling=="jumping" then
  --x input reaction
  if av.onground then
   if btn(⬅️) then
    xaccelerate(av.xgroundacc,-1)
   elseif btn(➡️) then
    xaccelerate(av.xgroundacc,1)
   else --ground decel
    av.xvel*=av.xgrounddecel
   end
  else --air x movement
   if btn(⬅️) then
    stickorfall(-1)
   elseif btn(➡️) then
    stickorfall(1)
   else --air decel
    av.xvel*=av.xairdecel
    av.stickframes=av.maxstickframes
   end
  end
 end
end

function updatecollision()
 --prevent going into corner
 if av.yvel<0 and
   not av.onground and
   not mapcol(av.left,av.xvel,0,0) and
   not mapcol(av.right,av.xvel,0,0) and
   (mapcol(av.left,av.xvel,av.yvel,0) or
   mapcol(av.right,av.xvel,av.yvel,0)) and
 		mapcol(av.top,av.xvel,av.yvel,0) and
 		not mapcol(av.top,0,av.yvel,0) then
		av.yvel=0
 end
 
 --ground bounce
 if av.rolling=="air" and
    mapcol(av.bottom,0,av.yvel,3) then
  sfx(26)
  
  initdustkick(-0.8,-1.5,
   1.6,1,
   2,0,7,nil,true)

  moveavtoground()
  av.ypause=1
  
  --don't lose vel for
  -- this frame or ypause frame
  av.yvel+=currentgravity*2
  av.yvel*=-1
 end
 
 --on ground
 if mapcol(av.bottom,0,av.yvel,0) then
  resetswitches()
  moveavtoground()
  
  --land
  if not av.onground then
   sfx(30,2)
   initdustkick(av.xvel-0.5,-av.yvel*2,1,0.5,4,10)
   av.rolling="none"
   av.pauseanim="squish"
   av.animpause=2
  end
  
  if av.rolling=="ground" then
   if milliseconds%2==0 then
    initdustkick(av.xvel*-1,-0.5,sgn(av.xvel)*-1,1,0,0)
   end
  end
  
  av.yvel=0
  av.onground=true
  av.onleft,av.onright=false,false
 else
  av.onground=false

  --roll off edge
  if av.rolling=="ground" then
   av.rolling="air"
   avsfx(22)
  end

  --roof bounce or land
  if av.rolling=="air" and
     mapcol(av.top,0,av.yvel,3) then
   avsfx(26)
   
   initdustkick(-0.8,0.5,
    1.6,1,
    2,0,7,av.top,true)

   moveavtoroof()
   av.ypause=1
   av.yvel*=-1
  elseif mapcol(av.top,0,av.yvel,0) then
   av.yvel=0
   moveavtoroof()
  end
 end
 
 --apply bounce on bounce walls
 if (av.rolling=="air" or
    av.rolling=="ground")
    and
    mapcol(av.left,av.xvel,0,2) then
  sfx(26)
  moveavtoleft()

  initdustkick(-av.xvel,-0.8,
   1,1.6,
   2,0,7,av.left,true)

  av.xpause=1
  av.xvel*=-1
 elseif (av.rolling=="air" or
   av.rolling=="ground")
   and
   mapcol(av.right,av.xvel,0,2) then
  sfx(26)
  moveavtoright()
  
  initdustkick(-av.xvel-1,-0.8,
   1,1.6,
   2,0,7,av.right,true)

  av.xpause=1
  av.xvel*=-1
 else
  av.onleft=avsidecol(av.left,moveavtoleft)
  av.onright=avsidecol(av.right,moveavtoright)
 end
 
 --checkpoint
 if mapcol(av.hurtbox,0,0,4) then
 	-- save key
  if av.inventory=="tempkey" then
   av.inventory="key"
  end

  if xcp!=xhitblock or
     ycp!=yhitblock then
   --new checkpoint
   sfx(37,1)

   --[[reset previous cp
   if not in hub or start screen]]
   if not instart(xcp,ycp) and
      not inhub(xcp,ycp) then
    mset(xcp,ycp,9)
   end
   
   xcp,ycp=xhitblock,yhitblock
   mset(xcp,ycp,10)
   
   initburst(xcp,ycp,{7,10})
  end
 end
 
 if allboxcol(5) and
    allboxcol(6) then
  --put down friend in hub
  if inhub() and
     av.inventory=="friend" and
     av.onground then
   av.inventory="none"
   holdingfriend.x=av.x
   holdingfriend.y=av.y
   startfriendanim()
  end
 else
  --exit
  if allboxcol(5) and
     av.inventory=="friend" then
   --float anim
   startfloatanim()
   avsfx(47)
  end
  
  --chest
  if allboxcol(6) and
     av.onground and
     (av.inventory=="tempkey" or
     av.inventory=="key") then
   --no more key
   initburst(av.key.x,av.key.y,{7,10})
   av.inventory="trans"

   --open chest
   mset(xhitblock,yhitblock,31)
   sfx(41,2)

   --remember chest location
   xprevchest,yprevchest=xhitblock, yhitblock

   --get friend!
 		holdingfriend=nil
 		holdingfriend={
 		 x=av.x,
 		 y=av.y,
 		 s=99,
 		 flipped=av.flipped,
 		 colmap={},
 		 oncloud=false
 		}

   --friend level variations
   if inspikelvl() then
    holdingfriend.delay=5
   elseif inbouncelvl() then
    holdingfriend.delay=10
    holdingfriend.colmap={
     {6,14},
     {13,2},
     {1,15}}
   elseif inbreaklvl() then
    holdingfriend.delay=15
    holdingfriend.colmap={
     {6,11},
     {5,1},
     {1,11}}
   elseif inswitchlvl() then
    holdingfriend.delay=20
    holdingfriend.delay=10
    holdingfriend.colmap={
     {6,9},
     {13,15},
     {1,8}}
   end
 
 		add(friends,holdingfriend)
   startfriendanim()
  end
 end
 
 --game objects colision
 for s in all(switches) do
  if circlecollision(av,s) and
     s.active then
   
   if av.rolling!="ground" then
    initburst(s.x,s.y,{7,12})
    sfx(43,0)
   end
   
   s.active=false
   
   if av.rolling=="none" or
      av.rolling=="jumping" then
    if av.onground then
     groundroll()
    else
     av.rolling="air"
     av.rotvel=abs(av.xvel/2)
    end
   elseif av.rolling!="ground" then
    --keep apropriate maxvel
    if av.xvel==av.xrollmaxvel then
     av.rolling="jumping"
    else
     av.rolling="none"
    end
   end
  end
 end
 
 for k in all(keys) do
  if circlecollision(av,k) and
     av.inventory=="none" then
   sfx(32,1)
   initburst(k.x,k.y,{7,10})

   av.inventory="tempkey"
   av.key=k
   
   --if av has a temp key
   -- remember where to put it
   -- on death
   xtempkey,ytempkey=k.x,k.y
  end
 end
end

function updateav()
 --face correctly
 if av.pauseanim=="none" then
  if av.xvel>av.xgroundacc or
     av.onleft then
   av.flipped=false
  elseif av.xvel<av.xgroundacc*-1 or
         av.onright then
   av.flipped=true
  end
 end
 
 --update dy if falling
 if not av.onground then
  av.yvel+=currentgravity
  
  --prevent variable jump effect
  -- after jump apex
  if av.yvel>0 then
   av.jumping=false
   av.jumpframes=jumpframesoffset
  
   --slide down wall slower
   if av.onleft or
      av.onright then
    currentgravity=wallgravity
    currenttvel=walltvel
   else
    currentgravity=airgravity
    currenttvel=airtvel
   end
  end
  
  --terminal velocity
  if av.yvel>currenttvel then
   av.yvel=currenttvel
  end
 end
 
 if av.xpause<=0 then
  av.x+=av.xvel
 end
 
 if av.ypause<=0 then
  av.y+=av.yvel
 end
 
 if av.xpause<=0 and
    av.ypause<=0 and
    av.animpause<=0 then
  --finish anims
  if av.pauseanim=="getfriend" then
   if inhub() then
    --add friend obj to
    -- approp cloud
    -- and light approp eyes
    local cloudindex=1
  
     if inspikelvl(xprevchest,yprevchest) then
     cloudindex=2
     sset(112,50,12)
    elseif inbouncelvl(xprevchest,yprevchest) then
     cloudindex=6
     sset(108,51,14)
    elseif inbreaklvl(xprevchest,yprevchest) then
     cloudindex=7
     sset(123,52,11)
     sset(125,52,11)
    elseif inswitchlvl(xprevchest,yprevchest) then
     cloudindex=3
     sset(119,51,9)
    end
    
    holdingfriend.x=1-rnd(2)
    holdingfriend.y=1-rnd(2)
    holdingfriend.oncloud=true
    
    add(
     clouds[cloudindex].offsets,
     holdingfriend)
    
    xprevchest,yprevchest=nil,nil
   
    if gamecomplete() then
     --change gamestate
     initending()
     playendingtune=true
    end
   else
    av.inventory="friend"
   end
  elseif av.pauseanim=="float" then
   av.pauseanim="endtohub"
   if gamecomplete() then
    playendingtune=true
    menuitem(1)
   end
   avsfx(48)
   initburst(av.x,av.y,rollycolours)

   xcp,ycp=63,27
   av.x,av.y=63,27
   av.xpause,av.ypause=90,90
  elseif av.pauseanim=="endtohub" then
   --spin back
   startfloatanim()
   sfx(50,2)
   avsfx(49)
   initburst(av.x,av.y,rollycolours)
   av.pauseanim="hubfloat"
   av.rotvel=0.33
   lockcamera=false
   av.xvel=0
   av.yvel=0
  elseif av.pauseanim=="hubfloat" then
   releasesfx()
  end

  if av.xpause<=0 and
     av.ypause<=0 and
     av.animpause<=0 then
   av.pauseanim="none"
  end
 end

 if av.xpause>0 then
  av.xpause-=1
 end
 
 if av.ypause>0 then
  av.ypause-=1
 end
 
 if av.animpause>0 then
  av.animpause-=1
 end
 
 if av.xvel*sgn(av.xvel)<0.001 then
  av.xvel=0
 end
end

function gamecomplete()
 local chestleft=false

 for x=0,127 do
  for y=0,63 do
   if not checkflag(x,y,5) and
    checkflag(x,y,6) then
    chestleft=true
   end
  end
 end
 
 --no chests left-completed
 return not chestleft
end

function updatefriends()
 --this frame's friend instructions
 local reaction={
  s=friendsanim.sprite,
  x=av.x,
  y=av.y,
  rot=av.rot,
  flipped=av.flipped
 }
 
 add(prevreactions,reaction)
 
 if #prevreactions>30 then
  del(prevreactions,prevreactions[1])
 end

 if (not holdingfriend) return

 for f in all(friends) do
  local pr=prevreactions[#prevreactions-f.delay]
  f.s=pr.s
  f.rot=pr.rot*0.7
  f.flipped=pr.flipped
 end
 
 local pr=prevreactions[#prevreactions-holdingfriend.delay]
 
 if av.inventory=="friend" then
	 holdingfriend.x=pr.x
  holdingfriend.y=pr.y
 end
end

function updateanim()
 --tab 3
 
 --av and friend animate
 avanimfind(av.anim,friendsanim)
 updateanimt(av.anim)
 updateanimt(friendsanim)
 
 --checkpoints glow
 updateanimt(cpanim)
 
 if cpanim.sprite>=13 then
  cpanim.sprite=11
 end
 
 if not instart(xcp,ycp) and
    not inhub(xcp,ycp) then
  mset(xcp,ycp,cpanim.sprite)
 end
 
 --active switches glow
 updateanimt(switchesanim)
 
 if switchesanim.sprite>=
    switchesanim.basesprite+5 then
  switchesanim.sprite=
   switchesanim.basesprite
 end
 
 --keys rotate
 updateanimt(keysanim)
 
 if keysanim.sprite==keysanim.basesprite then
  keysflipped=not keysflipped
 end
 
 if flr(keysanim.sprite)==48 then
  keysanim.sprite=46
 end
end

function updatemusic()
 local tune=""
 local fade=1000
 
 if playendingtune then
  tune="win"
 elseif inhub() then
  tune="hub"
 else
  tune="cave"
 end
 
 if musictimer>0 then
  musictimer-=1
 elseif musictimer==0 then
  music(musicnext,fade)
  musictimer=-1
 end
 
 if tune!=playingtune then
  music(-1,fade)
  musictimer=30
  if tune=="hub" then
   musicnext=10
  elseif tune=="cave" then
   musicnext=0
  elseif tune=="win" then
   musicnext=13
   musictimer=30*9
  end
  
  playingtune=tune
 end
end

function _draw()
 currentdraw()
end

function drawplaying()
 drawgame()
end

function drawgame()
 cls()
 if (inhub()) cls(12)
 
 --tab 5
 drawbgs()
 
 --map
 map(xmap*16,ymap*16,xmap*128,ymap*128,16,16)
 
 --game objects
 for s in all(switches) do
  if s.active then
   spr(switchesanim.sprite,s.x*8,s.y*8)
  else
   spr(4,s.x*8,s.y*8)
  end
 end

 for k in all(keys) do
  spr(keysanim.sprite,k.x*8,k.y*8,1,1,keysflipped)
 end
 
 for o in all(exitorbs) do
  spr(95,o.x*8,((o.y-0.5)*8)+yorboffset)
 end
 
 --centerpiece orb
 pal(12,14)
 pal(1,8)
 pal(13,2)
 pal(6,15)
 spr(switchesanim.sprite,63*8,ycen)
 pal()

 --friend follow
 for f in all(friends) do
  if not f.oncloud and
     av.pauseanim!="endtohub" then
   mapcols(f.colmap)
  
   if f.s==84 then
    rspr(32,40,f.x*8,f.y*8,f.rot,1)
   else
    spr(f.s,f.x*8,f.y*8,1,1,f.flipped)
   end
   
   pal()
  end
 end
 
 --tab 6
 drawparticles(false)
 
 --draw avatar if alive
 if not av.warping and
    av.pauseanim!="endtohub" then
  if av.rolling=="air" or
     av.rolling=="ground" and
     av.pauseanim=="none" then

   rspr(0,0,av.x*8,av.y*8,av.rot,1)
  else
   spr(av.anim.sprite,av.x*8,av.y*8,1,1,av.flipped)
  end
 end
 
 drawparticles(true)
 
 if inhub() then
  drawlogo()
 end
 
 local wordscol=9
 local symbolscol=10
 
 --instructions yummy
 print("jump",33*8-3,8*8+2,wordscol)
 
 print("roll",53*8+5,6*8,wordscol)
 print("❎",54*8+1,7*8-1,symbolscol)
 
 print("dive",55*8+4,7,wordscol)
 print("➡️",58*8,7,symbolscol)
 print("❎",59*8,8,symbolscol)
 
 print("hop",70*8+6,3*8+4,wordscol)
 print("⬆️",70*8+5,4*8+3,symbolscol)
 print("❎",71*8+3,5*8,symbolscol)
end

-->8
--collision

function moveavtoground()
 av.y+=av.yvel
 av.y-=av.y%pixel
 updatehitboxes()
 av.y+=distanceinwall(av.bottom,0,1,-1)+pixel
 updatehitboxes()
end

function moveavtoroof()
 av.y+=distancetowall(av.top,0,1,-1)
 av.y+=pixel-av.y%pixel
end

function moveavtoleft()
 --unsure why offset needed :(
 av.left.x+=coloffset 
 av.x+=distancetowall(av.left,1,0,-1)
 av.left.x-=coloffset
 av.x+=pixel-av.x%pixel
end

function moveavtoright()
 av.x+=distancetowall(av.right,1,0,1)
 av.x-=av.x%pixel
end

function distancetowall(box,checkx,checky,direction)
 local distancetowall=0

 while not mapcol(box,distancetowall*checkx,distancetowall*checky,0) do
  distancetowall+=(pixel*direction)
 end

 return distancetowall
end

function distanceinwall(box,checkx,checky,direction)
 local distanceinwall=0

 while mapcol
 (box,distanceinwall*checkx,
      distanceinwall*checky,0) do
  distanceinwall+=(pixel*direction)
 end

 return distanceinwall
end

--all sides collision(flag)
function allboxcol(f)
 if mapcol(av.top,0,0,f) and
    mapcol(av.bottom,0,0,f) and
    mapcol(av.left,0,0,f) and
    mapcol(av.right,0,0,f) then
  return true
 end
 return false
end

function anyboxcol(xvel,yvel,flag)
 if mapcol(av.top,xvel,yvel,flag) or
    mapcol(av.bottom,xvel,yvel,flag) or
    mapcol(av.left,xvel,yvel,flag) or
    mapcol(av.right,xvel,yvel,flag) then
  return true
 end
 return false
end

--spike collision
function spikecol()
 if mapcol(av.hurtbox,0,0,1) then
  if hitsprite==5 then
   --top
   if mapcol(
      makebox(0,4,8,4),0,0,1) then
    return true
   end
  elseif hitsprite==6 then
   --right
   if mapcol(
      makebox(1,-1,2,8),0,0,1) then
    return true
   end
  elseif hitsprite==7 then
   --left
   if mapcol(
      makebox(5,-1,4,8),0,0,1) then
    return true
   end
  elseif hitsprite==8 then
   --bottom
   if mapcol(
      makebox(1,1,8,3),0,0,1) then
    return true
   end
   --corners
  elseif hitsprite==20 then
   if mapcol(av.left,0,0,1) or
      mapcol(av.top,0,0,1) then
    return true
   end
  elseif hitsprite==21 then
   if mapcol(av.right,0,0,1) or
      mapcol(av.top,0,0,1) then
    return true
   end
  elseif hitsprite==22 then
   if mapcol(av.left,0,0,1) or
      mapcol(av.bottom,0,0,1) then
    return true
   end
  elseif hitsprite==23 then
   if mapcol(av.bottom,0,0,1) or
      mapcol(av.right,0,0,1) then
    return true
   end
  end
 end
 return false
end

--mapcollision
function mapcol(box,xvel,yvel,flag)
 return checkflagarea(box.x+xvel,box.y+yvel,box.w,box.h,flag)
end

function checkflagarea(x,y,w,h,flag)
 return
  checkflag(x,y,flag) or
  checkflag(x+w,y,flag) or
  checkflag(x,y+h,flag) or
  checkflag(x+w,y+h,flag)
end

function checkflag(x,y,flag)
 local s=mget(x,y)
 --remember the last hit block
 xhitblock,yhitblock=flr(x),flr(y)
 --remember last hit sprite
 hitsprite=s
 return fget(s,flag)
end

-- https://stackoverflow.com/questions/345838/ball-to-ball-collision-detection-and-handling
function circlecollision(s1,s2)
 
 --get distance from cen to cen
 local dx=s1.x-s2.x
 local dy=s1.y-s2.y
 
 local distance=(dx*dx)+(dy*dy)
 
 --if radiuses less than c2c, collision
 if distance<=((s1.r+s2.r)*(s1.r+s2.r)) then
  return true
 end
 return false
end

-->8
-- avatar utils

function avpausetohub()
 if (av.pauseanim=="getfriend") return

 xcp,ycp=63,26
 
 --reset objectives
 if av.inventory=="friend" then
  mset(xprevchest,yprevchest,30)
 end
 
 if av.inventory!="none" then
  if av.inventory=="friend" then
   av.key.x=xtempkey
   av.key.y=ytempkey
   
   del(friends,holdingfriend)
  end
  keyreset()
 end
 
 if not av.warping then
  sfx(25)
  initdeath()
  av.warping=true
  lockcamera=false
 end
end

function getmaploc(x,y)
 --assume current screen
 local xm=xmap
 local ym=ymap
 
 --override if specific location
 -- requested
 if x and y then
  xm=flr(x/16)
  ym=flr(y/16)
 end
 
 return xm,ym
end

function instart(x,y)
 local xm,ym=getmaploc(x,y)
 return xm==2 and ym==0
end

function inhub(x,y)
 local xm,ym=getmaploc(x,y)
 return
  xm>=3 and xm<5 and
  ym==1
end

function inspikelvl(x,y)
 local xm,ym=getmaploc(x,y)
 return
  xm<2 and ym<2 or
  xm==2 and ym==1
end

function inbouncelvl(x,y)
 local xm,ym=getmaploc(x,y)
 return xm<4 and ym>=2
end

function inbreaklvl(x,y)
 local xm,ym=getmaploc(x,y)
 return xm>=4 and ym>=2
end

function inswitchlvl(x,y)
 local xm,ym=getmaploc(x,y)
 return xm>=5 and ym<=2
end

function airroll()
 av.playingsfx="none"
 avsfx(31)
 
 currentgravity=airgravity
 currenttvel=airtvel
 
 av.rolling="air"
 av.rotvel=pixel*2
 av.xvel,av.yvel=0.0,-0.2
 
 --on wall dives
 if btn(⬅️) and
    not av.onleft then
  av.xvel=-av.xrollmaxvel
 elseif btn(➡️) and
    not av.onright then
  av.xvel=av.xrollmaxvel
 else
  --normal dives
  setxrollvel()
 end
 
 --convert to hop
 if (not btn(⬅️) and
    not btn(➡️)) or
    btn(⬆️) then
  av.rotvel=pixel*0.5
  av.xvel*=0.5
  av.yvel-=0.2
  avsfx(22)
 end
end

function groundroll()
 av.playingsfx="ground"
 avsfx(23)
 av.rotvel=pixel
 
 av.rolling="ground"
 setxrollvel()
end

function setxrollvel()
 --todo:base off input?
 if av.flipped then
  av.xvel=-av.xrollmaxvel
 else
  av.xvel=av.xrollmaxvel
 end
end

function jump()
 av.playingsfx="none"

 currentgravity=airgravity
 currenttvel=airtvel
 
 if av.rolling=="ground" then
  av.rolling="jumping"
 end
 
 --different jumps
 --collision resets flags
 if av.onground==true then
  avsfx(20)
  av.jumping=true
  av.yvel=-av.yjumpforce
 elseif av.onleft==true then
  avsfx(21)
  av.jumping=true
  av.xvel=av.xcurrentmaxvel
  av.yvel=-av.ywalljumpforce
 elseif av.onright==true then
  avsfx(21)
  av.jumping=true
  av.xvel=-av.xcurrentmaxvel
  av.yvel=-av.ywalljumpforce
 end
end

function isavskidding()
 if av.onground and
     ((btn(⬅️) and av.xvel>0) or
     (btn(➡️) and av.xvel<0 and
     not btn(⬅️))) then
  return true
 end
end

function xaccelerate(acc,sign)
 if (av.xvel*sign)<av.xcurrentmaxvel then
  --quick turn around
  if isavskidding() then
   av.xvel*=0.7
  end
  
  av.xvel+=acc*sign
 else
  av.xvel=av.xcurrentmaxvel*sign
 end
end

--stick to wall to give player
-- time to press jump
function stickorfall(sign)
 if (av.onleft or av.onright) and
    av.stickframes>0 then
  av.stickframes-=1
 else
  xaccelerate(av.xairacc,sign)
  av.stickframes=av.maxstickframes
 end
end

function avreset()
 av.xvel,av.yvel=0,0
 
 av.xcurrentmaxvel=av.xmaxvel
 av.stickframes=0
 av.jumpframes=jumpframesoffset
 
 av.jumping,av.onground=false,false
 av.onleft,av.onright=false,false
 av.flipped,av.warping=false,false
 
 --lock movement
 av.xpause,av.ypause=0,0
 
 --play specific anim
 -- w/o locking movement
 av.animpause=0
 
 --animations when locked
 av.pauseanim="none"

 av.anim=makeanimt()
 
 av.rot=0
 av.rotvel=0
 av.rolling="none"
 av.playingsfx="none"
 
 --key and friend persist death
 if av.inventory=="tempkey" then
  keyreset()
 end
 
 resetswitches()
 
 --reset crumble blocks
 for cbc in all(cbcontrollers) do
  cbc.timer=(cbrespawntime-cbanimspeed*2-1)
 end
 
 av.x,av.y=xcp,ycp
end

function keyreset()
 av.inventory="none"
 
 --av.key is a reference
 av.key.xdest=xtempkey
 av.key.ydest=ytempkey
 
 av.key=nil
end

function updatehitboxes()
 --smaller than av
 av.hurtbox=makebox(1,2,5,3)
 
 local off=coloffset*9
 
 --cover top and bottom
 av.bottom=makebox(
 1,7,
 6,1,
 0,coloffset)
 
 av.top=makebox(
 1,1,
 6,1,
 0,coloffset)
 
 --space between top and bottom
 av.left=makebox(
 1,2,
 1,5,
 coloffset)
 
 av.right=makebox(6,2,1,5)
end

function makebox(x,y,w,h,xo,wo)
 return {
 	x=av.x+av.w*pixel*x-(xo or 0),
 	y=av.y+av.h*pixel*y,
 	w=av.w*pixel*w-(wo or 0),
 	h=av.h*pixel*h
 }
end

function avsidecol(box,reaction) 
 if mapcol(box,av.xvel,0,0) then
  av.xvel=0
  av.rolling="none"

  reaction()

  --don't wallslide if onground
  return not av.onground
 end
 return false
end

--want movement sfx to interupt
-- each other
function avsfx(no)
 sfx(-1,3)
 sfx(no,3)
end

function walksfx()
 if av.pauseanim=="none" then
  if inhub() then
   if av.playingsfx!="whub" then
    avsfx(28)
    av.playingsfx="whub"
   end
  else
   if av.playingsfx!="wcave" then
    avsfx(29)
    av.playingsfx="wcave"
   end
  end
 else
  releasesfx()
 end
end

function releasesfx()
 sfx(-1,3)
 av.playingsfx="none"
end
-->8
-- animation tools

function makeanimt(bs,sd,sprs)
 local t={
  basesprite=bs,
  speed=sd,
  sprites=sprs,
  sprite=bs,
  along=0,
  counter=0
 }
 return t
end

function avanimfind(t,ft)
 --default to idle
 t.basesprite=71
 t.sprites=4
 t.speed=5
 
 ft.basesprite=99
 ft.sprites=2
 ft.speed=6
 
 if btn(⬇️) then
  t.basesprite=79
  t.sprites=1
 end
 
 if btn(⬆️) then
  t.basesprite=77
  t.sprites=1
 end
 
 --running anim
 if abs(av.xvel)>0 then
  t.basesprite=87
  t.sprites=4
  t.speed=3
  
  ft.basesprite=101
  ft.sprites=2
  ft.speed=4
 end
 
 --skid/turning
 if isavskidding() and
    currentupdate==updateplaying then
  t.basesprite=78
  t.sprites=1
  
  ft.basesprite=100
  ft.sprites=1
 end
 
 --jumping
 if av.yvel<0 then
  t.basesprite=75
  t.sprites=1
  
  ft.basesprite=101
  ft.sprites=1
 elseif av.yvel>0 then
  t.basesprite=76
  t.sprites=1
  
  ft.basesprite=101
  ft.sprites=1
 end
 
 --wallslide
 if not av.onground and
    av.onleft or
    av.onright then
  t.basesprite=70
  t.sprites=1
  
  ft.basesprite=103
  ft.sprites=1
 end
 
 --rolling
 if av.rolling=="air" or
    av.rolling=="ground" then
  
  if av.flipped then
   av.rot-=av.rotvel
  else
   av.rot+=av.rotvel
  end
  
  --prevent overflow
  if abs(av.rot)>1 then
   av.rot=0
  end
  
  ft.basesprite=84
  ft.sprites=1
 end
 
 if av.warping then
  ft.basesprite=84
  ft.sprites=1
 end
 
 if av.pauseanim=="getfriend" then
  t.basesprite=77
  t.sprites=1
  
  ft.basesprite=99
  ft.sprites=1
  
  holdingfriend.y-=pixel*0.5
  holdingfriend.s=99
  holdingfriend.flipped=av.flipped
 elseif av.pauseanim=="float" then
  av.rolling="air"
  av.rotvel+=0.003
  --don't move behind rolly
  yorboffset=0
 elseif av.pauseanim=="endtohub" then
  if av.xpause<=30 then
   lockcamera=false
   holdingfriend.y=ycen/8
  end
 elseif av.pauseanim=="hubfloat" then
  av.y=ycen/8
  holdingfriend.y=av.y
  av.rolling="air"
  if av.rotvel>0 then
   av.rotvel-=0.003
  end
 elseif av.pauseanim=="squish" then
  t.basesprite=79
  t.sprites=1
 end
end

function startfriendanim()
 avsfx(40)
 av.rolling="none"
 
 av.pauseanim="getfriend"
 av.xpause,av.ypause=60,60
end

function startfloatanim()
 releasesfx()
 av.pauseanim="float"
 av.xpause,av.ypause=120,120
 av.x,av.y=xhitblock,yhitblock
 
 av.y-=pixel*4
 av.rotvel=0
 lockcamera=true
end

function updateanimt(t)
 t.counter+=1
 
 t.along=t.counter/t.speed
 
 if t.counter>=
    t.speed*t.sprites then
  t.along=0
  t.counter=0
 end
 
 t.sprite=t.basesprite+t.along
end

function movetopoint(obj,xdest,ydest,round,multi)
 local off=0
 if (round) off=pixel*4

 local xvec=obj.x-(xdest+off)*(multi or 1)
 local yvec=obj.y-(ydest+off)*(multi or 1)
 
 obj.xvel-=xvec*0.01
 obj.yvel-=yvec*0.01
 
 obj.xvel*=0.9
 obj.yvel*=0.9
 
 obj.x+=obj.xvel
 obj.y+=obj.yvel
end

--[[taken from
https://www.lexaloffle.com/bbs/?tid=3593
]]
function rspr(sx,sy,x,y,a,w)
 local ca,sa=cos(a),sin(a)
 local srcx,srcy,addr,pixel_pair
 local ddx0,ddy0=ca,sa
 local mask=shl(0xfff8,(w-1))
 w*=4
 ca*=w-0.5
 sa*=w-0.5
 local dx0,dy0=sa-ca+w,-ca-sa+w
 w=2*w-1
 for ix=0,w do
  srcx,srcy=dx0,dy0
  for iy=0,w do
   if band(bor(srcx,srcy),mask)==0 then
    local c=sget(sx+srcx,sy+srcy)
    if c!=0 then
     pset(x+ix,y+iy,c)
    end
   end
   srcx-=ddy0
   srcy+=ddx0
  end
  dx0+=ddx0
  dy0+=ddy0
 end
end

-->8
--game object management

--switch mgmt

function createswitch(x,y)
 s={
  x=x,
  y=y,
  r=pixel*3,
  active=true
 }
 add(switches,s)
end

function createkey(x,y)
 k={
  x=x,
  y=y,
  xvel=0,
  yvel=0,
  xdest=x,
  ydest=y,
  r=pixel*3
 }
 add(keys,k)
end

function resetswitches()
 for s in all(switches) do
  if not s.active then
   sfx(44,2)
  end
  s.active=true
 end
end

function updatekeys()
 for k in all(keys) do
  movetopoint(k,k.xdest,k.ydest,false)
 end
 
 if av.key then
  if (av.inventory=="tempkey" or
     av.inventory=="key") then
   av.key.ydest=av.y-0.5
   
   if av.flipped then
    av.key.xdest=av.x+0.5
   else
    av.key.xdest=av.x-0.5
   end
  else
   --move 'used' key from picture
   -- remember for if reset hub
   av.key.x=-5
   av.key.y=-5
   av.key.xdest=-5
   av.key.ydest=-5
  end
 end
end

--friend mgmt

function mapcols(colmap)
 for cm in all(colmap) do
  pal(cm[1],cm[2])
 end
end

--crumble block mgmt

function createcbcontroller(x,y)
 local cbc={
  x=x,
  y=y,
  r=pixel*3,
  timer=-1
 }
 add(cbcontrollers,cbc)
end

function initcbs()
 cbcontrollers={}
 
 --respawn in frames
 cbrespawntime=120
 cbanimspeed=3
end

function cbexists(x,y)
  for cbc in all(cbcontrollers) do
   if cbc.x==x and cbc.y==y then
    return true
   end
  end
  return false
end

function updatecbs() 
 --check each vel seperatley
 -- to match wall collision
 if (anyboxcol(av.xvel,0,7) or
    anyboxcol(0,av.yvel,7))
    and
    (av.rolling=="ground" or
    av.rolling=="air") then
  sfx(27)
  
  if not cbexists(xhitblock, yhitblock) then
   createcbcontroller(xhitblock, yhitblock)
  end
 end

 for cbc in all(cbcontrollers) do
  if cbc.timer<(cbanimspeed*2) or
     not circlecollision(av,cbc) then
   cbc.timer+=1
  end
  
  --animate out
  if cbc.timer<cbanimspeed then
   mset(cbc.x,cbc.y,2)
  elseif cbc.timer<cbanimspeed*2 then
   mset(cbc.x,cbc.y,3)
  else
   mset(cbc.x,cbc.y,0)
  end
  
  --sfx and animate in
  if cbc.timer==
     (cbrespawntime-cbanimspeed-1) then
   sfx(42)
  end
  
  --todo:rewrite to use animt
  if cbc.timer>
     (cbrespawntime-cbanimspeed) then
   mset(cbc.x,cbc.y,2)
  elseif cbc.timer>
    (cbrespawntime-cbanimspeed*2) then
   mset(cbc.x,cbc.y,3)
  end
 
  if cbc.timer==cbrespawntime then
   mset(cbc.x,cbc.y,1)
   del(cbcontrollers,cbc)
  end
 end
end

function drawlogo()
 --prevent overflow
 if ylogo<0 then
  return
 end

 local sign=0
 
 if currentupdate==
    updateplaying then
  sign=1
 else
  sign=-1
 end

 --i'm paranoyed about overflow
 if abs(logocounter)>1000 then
  logocounter=1
 end

 logocounter+=1*sign
  
 if logocounter>160 then
  ylogovel-=0.02
 else
  ylogovel=(sin(logocounter/40)/15)
 end
 
 ylogo+=ylogovel
 
 --shadow
 pal(3,1)
 pal(11,1)
 spr(104,62.2*8,ylogo*8,3,1)
 pal()
 
 spr(104,62*8,(ylogo-pixel+ylogovel*1.5)*8,3,1)
end

-->8
--backgrounds

bgs={}
clouds={}

function generatecloud(x,y,update)
 local cloudsprs={83,112,113}

 c={
  x=x,
  y=y,
  yinit=y,
  xvel=0,
  yvel=0,
  offsets={}
 }
 
 for i=0,15+flr(rnd(6)) do
  add(c.offsets,
     {x=1-rnd(2),y=1-rnd(2),
     s=cloudsprs[1+flr(rnd(3))],
     flipped=false})
 end
 
 c.update=update
 
 add(bgs,c)
 add(clouds,c)
end

function initbgs()
 inittiling(2)
 
 generatecloud(
  51+rnd(3),18+rnd(3),updatecloud)
  
 generatecloud(
  58+rnd(3),18+rnd(3),updatecloud)
  
 generatecloud(
  65+rnd(3),18+rnd(3),updatecloud)
  
 generatecloud(
  73+rnd(3),18+rnd(3),updatecloud)
  
  
 generatecloud(
  51+rnd(3),25+rnd(3),updatecloud)
  
 generatecloud(
  58+rnd(3),25+rnd(3),updatecloud)
  
 generatecloud(
  67+rnd(3),25+rnd(3),updatecloud)
  
 generatecloud(
  73+rnd(3),25+rnd(3),updatecloud)
end

function inittiling(s)
 bg={
  s=s,
  update=updatetiling,
  xoff=0,
  yoff=0
 }
 add(bgs,bg)
 
 tilingcounter=0
end

function updatebgs()
 for c in all(bgs) do
  c.update(c)
 end
end

function updatecloud(c)
 --move based on time
 -- sin ranges from 0-1 so get
 -- inputs to match then make
 -- small
 c.yvel+=sin((stat(95)%10)/10)/2000
 
 c.yvel*=0.9
 
 c.y+=c.yvel
 
 --prevent updrift
 if c.y<c.yinit-1 then
  c.yvel=0
 end
 
end

function updatetiling(bg)
 bg.x=xmap*16
 bg.y=ymap*16
 
 local factor=0
 
 tilingcounter+=1
 
 if tilingcounter==10 then
  factor=pixel
  tilingcounter=0
 end
 
 --level variations
 if inspikelvl() then
  bg.s=119
  bg.xoff-=factor
  bg.yoff-=factor
 elseif inbouncelvl() then
  bg.s=120
  bg.xoff-=factor
  bg.yoff+=factor
 elseif inbreaklvl() then
  bg.s=121
  bg.xoff+=factor
  bg.yoff+=factor
 elseif inswitchlvl() then
  bg.s=122
  bg.xoff+=factor
  bg.yoff-=factor
 else --tutorial or hub
  bg.s=-1
 end
 
 if abs(bg.xoff)>=1 then
  bg.xoff=0
 end
 
 if abs(bg.yoff)>=1 then
  bg.yoff=0
 end
 
 bg.offsets={}
 
 for x=-1,17 do
  for y=-1,17 do
   add(bg.offsets,
      {x=x+bg.xoff,y=y+bg.yoff,
      s=bg.s,flipped=false})
  end
 end
end

function drawbgs()
 for c in all(bgs) do
  for off in all(c.offsets) do
   local x=(c.x+off.x)*8
   local y=(c.y+off.y)*8
   
   if off.colmap then
    mapcols(off.colmap)
 		end
 		
   if flr(off.s)==84 then
    rspr(32,40,
        x,y,off.rot,1)
   else
    spr(off.s,
       x,y,1,1,
       off.flipped)
   end
   pal()
  end
 end
end

-->8
--particle effects

effects={}
rollycolours={3,7,11}
cavecolours={2,4,9,10}

function createeffect(update)
 e={
  update=update,
  front=false,
  particles={}
 }
 add(effects,e)
 return e
end

function updateparticles()
 for e in all(effects) do
  e.update(e)
 end
end

function drawparticles(front)
 for e in all(effects) do
  if e.front==front then
   for p in all(e.particles) do
    circfill(p.x,p.y,p.r,p.col)
   end
  end
 end
end

function createparticle(x,y,xvel,yvel,r,col)
 p={
  x=x,
  y=y,
  xvel=xvel,
  yvel=yvel,
  r=r,
  col=col
 }
 return p
end

function initdrip()
 e=createeffect(updatedrip)
 
 for i=1,3 do
  local p=createparticle(
   40*8+4+rnd(3)-1.5,-1,
   0,0,
   0,12)
   p.t=i*3-30
  add(e.particles,p)
 end
 
 local p=createparticle(
  40*8+4+rnd(3)-1.5,-1,
  0,0,
  0,7)
  p.t=-30
 add(e.particles,p)
  
end

function updatedrip(e)
 --only when onscreen
 -- to prevent sfx playing about
 if instart() then
  for p in all(e.particles) do
   if p.t<60 then
    --gather
    p.t+=1
    
    if p.t==0 then
     p.y=(3*8)-2+rnd(2)-1
    end
    
    if p.t==60 then
     sfx(38)
    end
   elseif p.y<12*8+4 then
    --fall
    p.yvel+=0.01
    p.y+=p.yvel
   else
    --land/reset
    p.r=0
    p.x=40*8+4+rnd(3)-1.5
    p.yvel=0
    p.y=-1
    p.t=-30
    
    sfx(39)
    
    --increase area
    if clipspace and clipspace<8.5 then
     clipspace+=1
    end
   end
  end
 end
end

function initdeath()
 e=createeffect(updatedeath)
 --create a bunch of particles
 for i=0,8 do
  local p=createparticle(
   av.x*8,av.y*8,
   av.xvel*rnd(25),
   av.yvel*rnd(25),
   1+rnd(2),rollycolours[1+flr(rnd(#rollycolours))])
  add(e.particles,p)
 end
end

function updatedeath(e)
 local cpcollision=true

 for p in all(e.particles) do
  --accelerate towards checkpoint
  movetopoint(p,xcp,ycp,true,8)
  
  --follow with camera..
  av.x=p.x/8
  av.y=p.y/8
  
  --.. until cp onscreen
  if xmap==flr(xcp/16) and
     ymap==flr(ycp/16) then
   lockcamera=true
  end
  
  --or in hub
  if inhub(xcp,ycp) and
     inhub() then
   lockcamera=false
  end
  
  if flr(p.x/8)!=xcp and
     flr(p.y/8)!=ycp then
   cpcollision=false
  end
 end
 
 --if cpcollision is still true
 -- all dots are colliding
 -- and check it's the right cp
 if cpcollision and
    flr(av.x)==xcp and
    flr(av.y)==ycp then
  initburst(xcp,ycp,rollycolours)
  releasesfx()
  sfx(46,1)
  avreset()
  del(effects,e)
  lockcamera=false
 end
end

function initdustkick(dx,dy,rdx,rdy,no,minlength,overridecol,overridebox,front)
 local e=createeffect(updatedustkick)
 e.front=front or false

 --create a bunch of particles
 for i=0,no do
 local col
  if inhub(av.x,av.y) then
   col=rollycolours[1+flr(rnd(#rollycolours))]
  else
   col=cavecolours[1+flr(rnd(#cavecolours))]
  end
  
  col=overridecol or col
  
  local lrdx=rnd(rdx)
  if rdx<0 then
   lrdx=rnd(abs(rdx))*-1
  end
  
  local box=overridebox or av.bottom
 
  local p=createparticle(
   (box.x+(box.w/2))*8,
   box.y*8,
   dx+lrdx,dy+rnd(rdy),
   0+flr(rnd(2)),col)
  
  p.timeout=minlength+rnd(10)
  add(e.particles,p)
 end
end

function updatedustkick(e)
 for p in all(e.particles) do
  p.x+=p.xvel
  p.y+=p.yvel
  
  p.timeout-=1
  
  if p.timeout<=0 then
   if p.r>0 then
    p.r=0
    p.timeout=5
   else
    del(e.particles,p)
   end
  end
 end
 
 if #e.particles==0 then
  del(effects,e)
 end
end

function initburst(x,y,cols)
 local e=createeffect(updatedustkick)

 for i=0,7 do
  local col=cols[1+flr(rnd(#cols))]

  local p=createparticle(
   (x+0.5)*8,(y+0.5)*8,
   rnd(1.6)-0.8,rnd(1.6)-0.8,
   0+flr(rnd(2)),col)
  
  	p.timeout=10+rnd(5)
  add(e.particles,p)
	end
end

-->8
--gamestates and management

function initintro()
 xcp=40
 ycp=12
 
 initdrip()
 
 chest={
  s=30,
  x=40*8,
  y=12*8,
  xbump=0,
  ybump=0
 }
 
 av.x=chest.x/8
 av.y=chest.y/8-2.5*pixel
 
 av.flipped=true
 openness=0
 clipspace=0
 instructiontimer=0
 bumpsfx={33,34,35}
end

function updateintro()
 updatecamera()
 updateparticles()
 
 --reduce bump
 chest.xbump*=0.9
 chest.ybump*=0.9
 
 if clipspace>0 then
  clipspace-=0.01
 end
 
 if instructiontimer<2000 then
  instructiontimer+=1
 end
 
 --allow bump
 if btnp(❎) then
  sfx(bumpsfx[1+flr(rnd(3))])
  --instructiontimer=0
  chest.xbump=rnd(6)-3
  chest.ybump=rnd(6)-3
  
  openness+=0.1
  
  if clipspace<8.5 then
   clipspace+=1
  end
 end
 
 if openness>=1 then
  --break out
  sfx(36)
  airroll()
  
  --change state
  currentupdate=updateplaying
  currentdraw=drawplaying
  
  --activate menu
  menuitem(1, "reset to hub", avpausetohub)
 
  chest=nil
  openness=nil
  clipspace=nil
  instructiontimer=nil
 end
end

function drawintro()
 cls()
 
 --where drip is coming from
 map(38,0,38*8,0,5,3)
 
 if instructiontimer>=8*30 then
   print("press ❎",xmap*128+53-chest.xbump,
        ymap*128+60-chest.ybump,3)
 end
 
 clip(chest.x+chest.xbump-(xmap*128)+4.5-(clipspace*0.5),
      chest.y+chest.ybump+2-(ymap*128),
      clipspace,clipspace)
 
 spr(chest.s,
     chest.x+chest.xbump,
     chest.y+chest.ybump)
 clip()
 
 drawparticles(false)
end

function initending()
 currentupdate=updateending
 currentdraw=drawending
 
 --remove reset to hub option
 menuitem(1)
 
 av.xvel,av.yvel=0,0
 
 walkright=true
 ycredits=128
 logocounter=175
 ylogo=15
 ylogovel=0.3
end

function updateending()
 updatesfx()
 updatemusic()
 updatecollision()
 updateav()
 updatefriends()
 updatehitboxes()
 updateanim()
 updatebgs()
 updateparticles()
 
 --make rolly run around yaaay
 xaccelerate(av.xgroundacc,
  walkright and 1 or -1)

 if av.x<((xmap*16)+1.6) then
  walkright=true
 elseif av.x>((xmap*16)+13.2) then
  walkright=false
 end

 --randomly jump with joy!!
 if av.onground and
    (flr(rnd(20))==0 or
    (mapcol(av.left,av.xvel,av.yvel,0) or
    mapcol(av.right,av.xvel,av.yvel,0))) then
  jump()
  --bug patch, don't know why
  -- avsfx doesn't work here...
  sfx(20)
 end
 
 --scroll credits
 if ycredits>20 then
  ycredits-=1
 end
end

function drawending()
 drawgame()
 
 --credits
 s="by davbo and rory"
 outline(s,
 (xmap*128)+hw(s),(ymap*128)+ycredits+8,1,7)
 
 s="deaths: "..deaths
 outline(s,
 (xmap*128)+hw(s),(ymap*128)+ycredits+16,1,7)

 s="playtime: "..
 twodigit(hours)..":"..
 twodigit(minutes)..":"..
 twodigit(seconds).."."..
 twodigit(milliseconds)
 outline(s,
 (xmap*128)+hw(s),(ymap*128)+ycredits+24,1,7)

 s="thanks for playing!"
 outline(s,
 (xmap*128)+hw(s),(ymap*128)+ycredits+32,1,7)
end

function twodigit(val)
 if val>9 then
  return val
 else
  return "0"..val
 end
end

--half width for printing
function hw(s)
 return 64-#s*2
end

function outline(s,x,y,c1,c2)
 for i=0,2 do
  for j=0,2 do
   print(s,x+i,y+j,c1)
  end
 end
 print(s,x+1,y+1,c2)
end
