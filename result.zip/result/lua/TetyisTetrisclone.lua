--tetyis
--by spaz48
function _init()
 prt={}
 frame=0
 ttlcnt=0
 mcur=0
 mode="title"
 level=1
 bg=true
 rotsys="srs" --"classic"
 goalsys="fixed"--"variable"
 randomizer="7bag"--"classic"
 currentblock=1--11--rnd(64)--1
 currentghost=1
 starttimer=0
 musicenabled=true
 prtenb=true
 if mode=="tet" then
  tetinit()
 end
end

--make guideline compliant
function _update60()
 frame+=1
 --camera(0,-128)--+frame%256)
 if mode=="menu" then
  currentsong=4
  musiccheck()
  if btnp(2) then mcur-=1 end
  if btnp(3) then mcur+=1 end
  if btnp(0) then
   if mcur==1 then
    currentblock-=1
    currentblock=mid(0,currentblock,63)
   end
   if mcur==2 then
    currentghost-=1
    currentghost=mid(0,currentghost,63)
   end
  end
  if btnp(1) then
   if mcur==1 then
    currentblock+=1
    currentblock=mid(0,currentblock,63)
   end
   if mcur==2 then
    currentghost+=1
    currentghost=mid(0,currentghost,63)
   end
  end
  if btnp(0) or btnp(1) or btnp(4) or btnp(5) then
   if mcur==3 then
    musicenabled=not musicenabled
   end
   if mcur==4 then
    if randomizer=="7bag" then randomizer="classic"
    else randomizer="7bag" end
   end
   if mcur==5 then
    if goalsys=="variable" then goalsys="fixed"
    else goalsys="variable" end
   end
   if mcur==6 then
    if rotsys=="srs" then rotsys="classic"
    else rotsys="srs" end
   end
   if mcur==7 then
    prtenb=not prtenb
   end
  end

  if btnp(4) or btnp(5) then
   if mcur==0 then
    tetinit()
    mode="tet"
    starttimer=2
   end
  end
 end
 if mode=="tet" then
  tetupdate()
 end
end

function _draw()
 if mode=="tet" then
  tetdraw()
 end
 if mode=="title" then
  level=frame%15
  cls()
  drawtitle()
 end
 if mode=="menu" then
  cls()
  --textbox("an error has occured.",63,63)
  level=frame%15
  drawbg()
  logodraw(16,0,0,1,1,120,1)
  menustr={"sTART gAME","mINO dESIGN:"..currentblock.."   ","gHOST dESIGN:"..currentghost.."   ","mUSIC:"..tostr(musicenabled),"rANDOMIZER:"..randomizer,"gOAL sYSTEM:"..goalsys,"rOTATION sYSTEM:"..rotsys,"pARTICLES:"..tostr(prtenb)}
  mcur=(mcur%#menustr)
  for i=-2,2 do
   pal(7,6)
   pal(6,13)
   textbox(menustr[(mcur-i)%#menustr+1],64,64-(i*12))--28+i*12)
  end
  pal(7,7)
  pal(6,6)
  textbox(menustr[mcur+1],64,64)
  if mcur<=3 or mcur==7 then
   local xo=0
   if currentblock>9 then xo=2 end
   palt(9,false)
   pal(4,4)
   pal(15,15)
   if mcur==7 then
    spr(currentblock,89+xo,63-((mcur-9)*12))

   else
    spr(currentblock,89+xo,63-((mcur-1)*12))
   end
  end
  if mcur<=4 then
   local xo=0
   if currentghost>9 then xo=2 end
   palt(9,true)
   pal(4,13)
   pal(15,7)
   spr(currentghost,89+xo,63-((mcur-2)*12))
  end
 end
 pal(5,140,1)
 if phase=="end" then
  if score>0 then
   textbox("fINAL sCORE:"..score.."0",64,52)
  else
   textbox("fINAL sCORE:"..score,64,52)
  end
  textbox("gAME oVER",64,64)
  textbox("cTRL+r tO rESTART",64,76)
 end
--[[ print('mem:'..stat(0),0,0,7)
 print('cpu:'..stat(1),0,6,7)
 print('particles:'..#prt,0,12,7)]]
end

function drawtitle()
 --play thunder sound
 if ttlcnt==0 then  sfx(40,2) end
 --increment counter
 if ttlcnt<200 then
  ttlcnt+=1
 end
 if (btnp(4) or btnp(5)) then
  --skip intro if button is pressed and mute thunder
  if ttlcnt<200 then ttlcnt=200 sfx(-1,2)
  --if already past info then go to menu
  else mode="menu" if btn(3) then bg=false end end
 end
 --draw logo with electricity effects using shake
 if ttlcnt<160 then
  local logox=16 logoy=32
  logodraw(logox,logoy,8,1,1,flr(ttlcnt/2),1)
  logodraw(logox+1,logoy+1,8,1,1,flr(ttlcnt/2),1)
  logodraw(logox,logoy,2,1,1,flr(ttlcnt/2),12)
  logodraw(logox+1,logoy+1,2,1,1,flr(ttlcnt/2),12)
  logodraw(logox,logoy,0,1,1,flr(ttlcnt/2),7)
 end
 --flash the screen
 for i=1,8 do
   if ttlcnt>=158+(i*2) and ttlcnt<163+(i*2) then
    colors={13,7,15,6,13,5,1,0,3}
    cls(colors[i])
    --palt(colors[j],true)
    --palt(colors[i],false)
   end
  end
  --draw the background
  if ttlcnt>190 or (ttlcnt>160 and colorblend(0,1)==1) then drawbg() end
  --draw the actual title screen
  if ttlcnt>162 then
   local counter
   if counter==nil then counter=0 else counter+=1 end
   --sspr(0,96,96,127,16,32,96,32)
   --sspr(96,96,128,128,48,64,32,32)
   spr(192,16,32,12,4)
   spr(204,48,64,4,4)
   logodraw(16,32,-min(0,-(20-(ttlcnt-160))*4),1,1,flr(ttlcnt/2),1)
   logodraw(16,32,-min(0,-(20-(ttlcnt-160))*3),1,1,flr(ttlcnt/2),12)
   logodraw(16,32,-min(0,-(20-(ttlcnt-160))*2),1,1,flr(ttlcnt/2),3)
   logodraw(16,32,0,1,1,flr(ttlcnt/2),11)
   textbox("-pRESS ❎ OR 🅾️-  ",64,max(80,counter))
   print("-sPAZ",108,122,7)
   print("1.01",1,122,7)
   --textbox("push the button to start the 2",64,max(96,counter)) --textbox("press ❎ or 🅾️",60,max(80,counter))
  end
end

function textbox(str,x,y)
 local strl=(#str*2)
 --[[spr(144,x-strl-12,y-2,2,2)
 spr(146,x+strl+6,y-2,2,2)]]
 --draw a rectangle behind the text
 rectfill(x-strl-4,y-2,x-1+strl+4,y+7,1)
 --define the colors
 local tbcltbl={6,7,7,6,1,1,1,1,1}
 for i=1,#tbcltbl do
  --draw the diagonal bits and fill in the rest of the blue
  line(x-strl-8+i-4,y+6,x-strl+i-4,y-2,tbcltbl[i])
  line(x+strl-i+3,y+7,x+strl+7-i+4,y-1,tbcltbl[i])
 end
 --draw lines on the top and bottom
 line(x-strl-1,y-2,x+strl+10,y-2,7)
 line(x-strl-11,y+7,x+strl+1,y+7,7)
 --print the shadow
 print(str,x+1-strl,y+1,13)
 --print the text
 print(str,x-strl,y,7)
end

function logodraw(lx,ly,shk,scx,scy,stp,clr)
 --vector system to draw the logo
 --lx=location x, ly=location y, shk=shake amount, scx=stretch width, scy=stretch height,
 --stp=number of lines to render, clr=color
 --offset the logo so shaken layers line up
 lx-=shk/2
 ly-=shk/2
 --the main "tetyis" logo
 logot="01011701170712071230063006070107010100001801330130072407241030102815241524243424373018301801000034014901510652074507453039303907340734010000490156016112660173016419643058305820490100007301770177077107000071097709773071307109000078019401930192068406850794249430783078237924862478077801"
  for  i=1,min((#logot/4)-1,stp) do
   --get data from string
   local drs=(i*4)-3
   local drs2=(i*4)+1
   local pos1=tonum(sub(logot,drs,drs+1))
   local pos2=tonum(sub(logot,drs+2,drs+3))
   local pos3=tonum(sub(logot,drs2,drs2+1))
   local pos4=tonum(sub(logot,drs2+2,drs2+3))

   if pos1!=0 and pos2!=0 and pos3!=0 and pos4!=0 then
    --draw lines based on data from the string
    line(
    lx+(pos1+rnd(shk))*scx,
    ly+(pos2+rnd(shk))*scy,
    lx+(pos3+rnd(shk))*scx,
    ly+(pos4+rnd(shk))*scy,clr)
   end
  end
end
-->8
function tetinit()
 --initialize variables
 mode="tet"
 press=false
 autorepeat=0
 --camera=0
 holdnum=0
 minoinit(true)
 minolastx1=6
 minolastx=6
 lockdelay=30
 ghminox=6
 ghminoy=18
 locktimer=0
 speed=60
 minotimer=0
 holdused=false
 tetnum=0
 tspin=false
 backtoback=0
 gameover=false
 hdrop=false
 danger=false
 lastsong=0
 currentsong=1

 lines=0
 score=0
 subscore=0
 level=1
 oldgoal=0
 if goalsys=="variable" then
  goal=5
 elseif goalsys=="fixed" then
  goal=10
 end

 truespeed=((0.8-((level-1)*0.007))^(level-1))
 --init 7 bag
 bag={0,0,0,0,0,0,0}
 queue={}
 --init grid
 hitlist={}
 grid={}
 --layer2={}
 for i=1,10 do
  grid[i-1]={}
  --layer2[i-1]={}
  for j=1,40 do
   grid[i-1][j]=0
   --layer2[i-1][j]=0
  end
 end
 phase="setup"
end

function tetupdate()
 minolastx1=minolastx
 minolastx=minox
 score=flr(score)
 if starttimer>0 then starttimer-=1 end
 musiccheck()

 if phase=="setup" then
  phase="gen"
 end
 --generation phases
 if phase=="gen" then
  gen()
 end
 --falling phase
 --hard drop?
 if phase=="fall" then
  fall()
 end
 --lock phase
 --moved?
 --space to fall?
 --reset lockdown timer?
 if phase=="lock" then
  lock()
 end
 --pattern phase
 --pattern match?
 --mark block for destruction
 if phase=="patt" then
  patt()
 end
 --iterate phase
 if phase=="iter" then
  phase="anim"
 end
 --animate phase
 --for i=1,#layer2 do
  --for j=1,#layer2[1] do
   --if layer2[i-1][j]>0 then layer2[i-1][j]-=1 end
   --if layer2[i-1][j]<0 then layer2[i-1][j]+=1 end
  --end
 --end
 --[[if phase=="anim" then
  anim()
 end]]
 --eliminate phase
 --line clear?
 if phase=="elim" then
  elim()
 end
 --completion phase
 if phase=="comp" then
  comp()

 end
 --game over
 if phase=="over" then
  if overc==nil then overc=0 currentsong=0 else overc+=1 end
  if overc==60 then currentsong=3 musiccheck() phase="end" end
 end
 --game over
 if phase=="end" then
 end

 minoshape()
end

function minoinit(initial)
 if initial==nil then intiial=false end
 minox=4
 minolastx=minox
 minolastx1=minox
 minoy=17
 rotation=0
 if tetnum==0 then minoy=16 end
 if not initial then minoshape() end
end

---------------------------------------------------

function gen()
 if #queue>0 then
  for i=1, #queue do
   queue[i]=queue[i+1]
   queue[i+1]=nil
  end
 end
 repeat
  queue[#queue+1]=rndgen()
 until #queue==7
 tetnum=queue[1]
end

function rndgen()
 local rndnum
 if randomizer=="7bag" then
  rndnum=flr(rnd(7))+1
  local bagcnt=0
  for i=1,#bag do
   bagcnt+=bag[i]
   if bagcnt==7 then
    for j=1,#bag do
     bag[j]=0
    end
   end
  end
  repeat
   rndnum=flr(rnd(7))+1
  until bag[rndnum]==0
  bag[rndnum]=1
  phase="fall"
  add(queue,tetnum)
 elseif randomizer=="classic" then
  rndnum=flr(rnd(7))+1
  phase="fall"
  add(queue,tetnum)
 end
 return rndnum
end


function fall()
 minotimer+=1
 if starttimer==0 then inputmain() end
 if hdrop then locktimer=5
 else locktimer=lockdelay end
 if minotimer>speed then
  minotimer=0
  if not gridcheck(0,-1) then
   minoy-=1
   if btn(3) then subscore+=1 end
  else
   minotimer=speed
   lockcount=true
   phase="lock"
  end
 end
end

function lock()
 if hdrop==false then inputmain() end
 if lockcount then
  if gridcheck(0,-1) then
   minotimer=speed
   locktimer-=1
   if locktimer==0 then placemino() end
  else
   minotimer=0
   lockcount=false
   minoy-=1
   minotimer+=1
   locktimer=lockdelay
   phase="fall"
  end
 end
end

function patt()
 for i=1,40 do
  linecount=0
  for j=1,10 do
   if grid[j-1][i]>0 and grid[j-1][i]<8 and i>16 then gameover=true end
   if grid[j-1][i]>0 and grid[j-1][i]<8 then linecount+=1 end
   if linecount==10 then add(hitlist,i) end
  end
 end
 if gameover==true then phase="over"
 else phase="iter" end
end

function anim()
 --local animcounter
 local atb={131,132,133,134,134,134,134,134,134,134,133}
 if animcounter==nil then animcounter=0
 else animcounter+=1 end
 if #hitlist>=4 then
  printsh("tetyis",0,82)
  --logodraw(16,(animcounter*animcounter/4),2,1,1,200,11)
  if backtoback>0 then
   printsh("back",4,89)
   printsh("to",8,96)
   printsh("back",4,103)
  end
 elseif #hitlist==3 then
  printsh("triple",0,82)
 elseif #hitlist==2 then
  printsh("double",0,82)
 elseif #hitlist==1 then
  printsh("single",0,82)
 end

 if animcounter==10+(#hitlist*3) or #hitlist==0 then phase="elim" animcounter=nil end
 for i=1,#hitlist do
  for j=1,10 do
   if animcounter!=nil then
    spr(atb[mid(0,flr(animcounter+1),10)],16+(j*8),128-hitlist[i]*8)
   end
  end
 end


end

function elim()
 if #hitlist>=4 then sfx(4) end
 for i=1, #hitlist do
  removeline(hitlist[#hitlist-i+1])
 end
 danger=false
 currentsong=1
 for i=1,40 do
  for j=1,10 do
   if grid[j-1][41-i]>0 and grid[j-1][41-i]<8 and i<28 then
    currentsong=2
    danger=true
   end
  end
 end
 phase="comp"
end

function comp()
 newlines=0
 local btbmp=1
 if backtoback>0 then
  btbmp=1.5
 end
 if #hitlist==1 then
  score+=1*level*btbmp
  backtoback=0
 elseif #hitlist==2 then
  score+=3*level*btbmp
  backtoback=0
 elseif #hitlist==3 then
  score+=5*level*btbmp
  backtoback=0
 elseif #hitlist==4 then
  score+=8*level*btbmp
  backtoback+=1
 end
 if goalsys=="variable" then
  if #hitlist==1 then
   if tspin then newlines+=8
   else newlines+=1 end
  elseif #hitlist==2 then
   if tspin then newlines+=12
   else newlines+=3 end
  elseif #hitlist==3 then
   if tspin then newlines+=16
   else newlines+=5 end
  elseif #hitlist==4 then
   newlines+=8 end
 elseif goalsys=="fixed" then
  newlines+=#hitlist
 end
 if backtoback>1 then
  newlines+=newlines/2
 end
 for i=1, #hitlist do
  hitlist[i]=nil
 end
 lines+=newlines
 newlines=0
 truespeed=((0.8-((level-1)*0.007))^(level-1))
 speed=60*truespeed
 if lines>=goal+oldgoal then
  level+=1 oldgoal+=goal
  if goalsys=="variable" then goal=level*5 end
  if goalsys=="fixed" then goal=10 end
 end
 phase="gen"
end

------------------------------------------------

function gridcheck(xf,yf)
 minoshape()
 local vtbl={x0=minox,y0=minoy,x1=minox1,y1=minoy1,x2=minox2,y2=minoy2,x3=minox3,y3=minoy3}
 if mid(0,vtbl.x0+xf,9)!=vtbl.x0+xf or mid(0,vtbl.x1+xf,9)!=vtbl.x1+xf or
 mid(0,vtbl.x2+xf,9)!=vtbl.x2+xf or mid(0,vtbl.x3+xf,9)!=vtbl.x3+xf then return true
 elseif
 grid[vtbl.x0+xf][vtbl.y0+yf]==nil or --grid[vtbl.x0][vtbl.y0+yf]>10) or
 grid[vtbl.x1+xf][vtbl.y1+yf]==nil or --grid[vtbl.x1][vtbl.y1+yf]>10) or
 grid[vtbl.x2+xf][vtbl.y2+yf]==nil or --grid[vtbl.x2][vtbl.y2+yf]>10) or
 grid[vtbl.x3+xf][vtbl.y3+yf]==nil then return true--grid[vtbl.x3][vtbl.y3+yf]>10) then return true
 elseif
  grid[vtbl.x0+xf][vtbl.y0+yf]>0 or
  grid[vtbl.x1+xf][vtbl.y1+yf]>0 or
  grid[vtbl.x2+xf][vtbl.y2+yf]>0 or
  grid[vtbl.x3+xf][vtbl.y3+yf]>0 then
   return true
  else
   return false
  end
end

function inputmain()
 if autorepeat>0 then autorepeat-=1 end
 if not btn(0) and not btn(1) then autorepeat=0 press=false end
 if btn(0) and btn(1) then autorepeat=0 end

 if btn(1) and press==true and autorepeat==0  then
  if not gridcheck(1,0) then
   minox+=1
   sfx(2,2)
   autorepeat=3
   locktimer=lockdelay
  end
 elseif btn(0) and press==true and autorepeat==0 then
  if not gridcheck(-1,0) then
   minox-=1
   sfx(2,2)
   autorepeat=3
   locktimer=lockdelay
  end
 end

 if btn(1) and press==false and autorepeat==0 then
  if not gridcheck(1,0) then
   minox+=1
   sfx(2,2)
   autorepeat=18
   press=true
   locktimer=lockdelay
  end
 elseif btn(0) and press==false and autorepeat==0 then
  if not gridcheck(-1,0) then
   minox-=1
   sfx(2,2)
   autorepeat=18
   press=true
   locktimer=lockdelay
  end
 end

 if btn(4) and btnp(5) then hold()
 elseif btnp(4) and btn(5) then hold() end

 if btnp(4) and not btn(5) then rotate(-1) end
 if btnp(5) and not btn(4) then rotate(1) end

 if btn(3) then minotimer+=truespeed*19 end
 if btnp(2) then
  sfx(7,2)
  harddrop()
 end
 ghost()
end

function rotate(dir)
 sfx(0)
 rotation+=dir
 if rotation<0 then rotation=3 end
 if rotation>3 then rotation=0 end
 minoshape()
 if gridcheck(0,0) then
  if rotsys=="classic" then
   rotation-=dir
  elseif rotsys=="srs" then
   if tetnum==2 or tetnum==3 or tetnum==5 or tetnum==6 or tetnum==7 then
    rightsrstable={
    {{-1,0},{-1,1},{0,-2},{-1,-2}}, --0>1
    {{1,0},{1,-1},{0,2},{1,2}}, --1>2
    {{1,0},{1,1},{0,-2},{1,-2}}, --2>3
    {{-1,0},{-1,-1},{0,2},{-1,2}}} --3>0
    --[y][x][1/2]
    leftsrstable={
     {{1,0},{1,-1},{0,2},{1,2}}, --1>0
     {{-1,0},{-1,1},{0,-2},{-1,-2}}, --2>1
     {{-1,0},{-1,-1},{0,2},{-1,2}}, --3>2
     {{1,0},{1,1},{0,-2},{1,-2}}} --0>3
   elseif tetnum==1 then
    rightsrstable={
    {{-2,0},{1,0},{-2,-1},{1,2}},--0>1
    {{-1,0},{2,0},{-1,2},{2,-1}},--1>2
    {{2,0},{-1,0},{2,1},{-1,-2}}, --2>3
    {{1,0},{-2,0},{1,-2},{-2,1}}} --3>0
    --[y][x][1/2]
    leftsrstable={
     {{2,0},{-1,0},{2,1},{-1,-2}}, --1>0
     {{1,0},{-2,0},{1,-2},{-2,1}}, --2>1
     {{-2,0},{1,0},{-2,-1},{1,2}}, --3>2
     {{-1,0},{2,0},{-1,2},{2,-1}}} --0>3
    end
    --if rotation-dir==0 and dir==1 then
   local solved=0
   for i=1,4 do
    if solved==0 and dir==1 then
     if not gridcheck(rightsrstable[rotation+1][i][1],rightsrstable[rotation+1][i][2]) then
      solved=i
     end
    elseif solved==0 and dir==-1 then
     if not gridcheck(leftsrstable[rotation+1][i][1],leftsrstable[rotation+1][i][2]) then
      solved=i
     end
    end
   end
   if solved>0 then
    minoshape()
    minox+=(rightsrstable[rotation+1][solved][1])*dir
    minoy+=(rightsrstable[rotation+1][solved][2])*dir
    solved=0
    locktimer=lockdelay
   else
    rotation-=dir
   end
  end
 end
 if rotation<0 then rotation=3 end
 if rotation>3 then rotation=0 end
 minoshape()
end

function harddrop()
 repeat
  if not gridcheck(0,-1) then
   minoy-=1
   subscore+=2
  end
 until gridcheck(0,-1)
 --layer2[minox][minoy+1]=12
 --layer2[minox1][minoy1+1]=12
 --layer2[minox2][minoy2+1]=12
 --layer2[minox3][minoy3+1]=12
 minotimer=speed
 hdrop=true
end

function ghost()
 ghminox=minox
 ghminoy=minoy
 repeat
  if not gridcheck(0,ghminoy-minoy-1) then ghminoy-=1 end
 until gridcheck(0,ghminoy-minoy-1)
end

function hold()
 if holdused==false then
  holdused=true
  local temp=holdnum
  if holdnum>0 then
   holdnum=tetnum
   tetnum=temp
   minoinit()
  else
   holdnum=tetnum
   gen()
   minoinit()
  end
 if holdused==true then end
 end
end

function placemino()
 sfx(5,2)
 minoshape()
 lockcount=false
 holdused=false
 hdrop=false
 grid[minox][minoy]=tetnum
 grid[minox1][minoy1]=tetnum
 grid[minox2][minoy2]=tetnum
 grid[minox3][minoy3]=tetnum
 minoinit()
 phase="patt"
end

--1=i 2=j 3=l 4=o 5=s 6=t 7=z
function minoshape()
 minor0={
 {-1,0,1,0,2,0},
 {-1,0,-1,-1,1,0},
 {-1,0,1,-1,1,0},
 {0,-1,1,0,1,-1},
 {-1,0,0,-1,1,-1},
 {-1,0,0,-1,1,0},
 {1,0,0,-1,-1,-1}}
 minor1={
 {0,-1,0,1,0,2},
 {0,-1,1,-1,0,1},
 {0,-1,1,1,0,1},
 {0,-1,1,0,1,-1},
 {0,-1,1,0,1,1},
 {0,-1,1,0,0,1},
 {0,1,1,0,1,-1}}
 minor2={
 {-1,0,1,0,2,0},
 {-1,0,1,1,1,0},
 {-1,0,-1,1,1,0},
 {0,-1,1,0,1,-1},
 {1,0,0,1,-1,1},
 {1,0,0,1,-1,0},
 {-1,0,0,1,1,1}}
 minor3={
 {0,-1,0,1,0,2},
 {0,-1,-1,1,0,1},
 {0,-1,-1,-1,0,1},
 {0,-1,1,0,1,-1},
 {0,1,-1,0,-1,-1},
 {0,1,-1,0,0,-1},
 {0,-1,-1,0,-1,1}}
  minox1=minox+rotatemath(tetnum,1)
  minoy1=minoy-rotatemath(tetnum,2)
  minox2=minox+rotatemath(tetnum,3)
  minoy2=minoy-rotatemath(tetnum,4)
  minox3=minox+rotatemath(tetnum,5)
  minoy3=minoy-rotatemath(tetnum,6)
  ghminox1=ghminox+rotatemath(tetnum,1)
  ghminoy1=ghminoy-rotatemath(tetnum,2)
  ghminox2=ghminox+rotatemath(tetnum,3)
  ghminoy2=ghminoy-rotatemath(tetnum,4)
  ghminox3=ghminox+rotatemath(tetnum,5)
  ghminoy3=ghminoy-rotatemath(tetnum,6)
end

function rotatemath(tee,ess)
 if rotation==0 then return minor0[tee][ess]
 elseif rotation==1 then return minor1[tee][ess]
 elseif rotation==2 then return minor2[tee][ess]
 elseif rotation==3 then return minor3[tee][ess]
 end
end

function removeline(line)
 sfx(3)
 for i=1,10 do
  grid[i-1][line]=0
  makeparticle(prt,i*8+20,128-line*8,0,-8,5,7,6,20,rnd(2)+1,-1,6)
  for j=1,40-line do
   grid[i-1][line+j-1]=grid[i-1][line+j]
  end
 end
end

function drawbg()
 if prtenb==true then
  poff={x=0,y=0}
  makeparticle(prt,sin(frame%level/level)*level*8+64,cos(frame%level/level)*level*8+64,-sin(frame%level/level),-cos(frame%level/level),0,level%10+6,level,200,rnd(3),-rnd(1),level%10)
  updateparticle(prt)
  drawparticle(prt)
 end
end

function musiccheck()
 if not musicenabled then
  music(-1)
  currentsong=-1
  lastsong=-1
 else
  if currentsong==0 and lastsong!=0 then music(-1)
  elseif currentsong==1 and lastsong!=1 then music(0)
  elseif currentsong==2 and lastsong!=2 then music(32)
  elseif currentsong==3 and lastsong!=3 then music(36)
  elseif currentsong==4 and lastsong!=4 then music(37)
  end
  lastsong=currentsong
 end
end

----------------------------------------------------------------

function tetdraw()
 cls()
 pal()
 mapx=110
 mapy=124
 yoff=-40
 if bg==true then drawbg() end
 map(0,0,0,-128)
 map(0,0,0,0)
 --if harddrop then drawbackfx() end
 rectfill(mapx,mapy,mapx+11,mapy+-21,0)
 rect(mapx,mapy,mapx+11,mapy+-17,1)
 for i=1,10 do
  for j=1,40 do
   if grid[i-1][j]>0 then
    minocolor(grid[i-1][j])
    spr(currentblock,(i*8)+16,yoff-((j-20)*8)+8)
    pset(i+mapx,mapy-j,9)
    --debug=minox
   end
  end
  if phase=="fall" then
   pal()
   palt(9,true)
   pal(4,13)
   pal(15,7)
   drawblock(currentghost,1)

  end
 minocolor(tetnum)
 if locktimer<5 and locktimer>0 then
  pal() pal(9,6) pal(4,13) pal(15,7)
  vtb={minox,minoy,minox1,minoy1,minox2,minoy2,minox3,minoy3}
  for i=1,4 do
   makeparticle(prt,vtb[i*2-1]*8+rnd(7)+24,128-vtb[i*2]*8+7,0,-rnd(32),-64-rnd(32),7,1,3,2,-.1,6)
  end

  end
 if hdrop==false and phase=="fall" then
  pset(ghminox+mapx+1,-ghminoy+mapy,7)
  pset(ghminox1+mapx+1,-ghminoy1+mapy,7)
  pset(ghminox2+mapx+1,-ghminoy2+mapy,7)
  pset(ghminox3+mapx+1,-ghminoy3+mapy,7)
 end
 pset(minox+mapx+1,-minoy+mapy,9)
 pset(minox1+mapx+1,-minoy1+mapy,9)
 pset(minox2+mapx+1,-minoy2+mapy,9)
 pset(minox3+mapx+1,-minoy3+mapy,9)
 drawblock(currentblock,0)
 --drawfrontfx()
 drawhud()
 end
 if phase=="anim" then
  anim()
 end
end

function drawblock(blk,fx)
 local vartable={}
 local smthy
 local smthx
 if fx==1 then
  vartable={ghminox,ghminoy,ghminox1,ghminoy1,ghminox2,ghminoy2,ghminox3,ghminoy3}
  smthy=8
  smthx=((minox-minolastx)+(minolastx-minolastx1))*-2
 else
  vartable={minox,minoy,minox1,minoy1,minox2,minoy2,minox3,minoy3}
  smthy=(minotimer/speed)*8
  smthx=((minox-minolastx)+(minolastx-minolastx1))*-2
 end
 for i=1,4 do
  spr(blk,(vartable[(i*2)-1]*8)+24+smthx,yoff-((vartable[i*2]-20)*8)+smthy)
 end
end

function drawhud()
 printsh("hold",4,0)
 printsh("next",108,0)
 printsh("lines",2,25)
 printsh(lines,(22-(#tostr(lines)*4)+2)/2,32)
 printsh("level",2,39)
 printsh(level,(22-(#tostr(level)*4)+2)/2,46)
 printsh("goal",4,53)
 printsh(goal+oldgoal-lines,(22-(#tostr(goal+oldgoal-lines)*4)+2)/2,60)
 printsh("score",2,67)
 if score>0 then
  printsh(tostr(score).."0",(22-(#tostr(score.."0")*4)+2)/2,74)
 else
  printsh(tostr(score),(22-(#tostr(score)*4)+2)/2,74)
 end

 spr(67,4,7,2,1)
 spr(69,4,15,2,1)
 spr(67,108,7,2,1)
 spr(69,108,15,2,1)
 spr(73,4,19,2,1)
 minocolor(holdnum)
 palt(0,true)
 if holdnum>0 then sspr((holdnum*8)-8,40,8,8,4,5,16,16) end
 pal()
 for i=1, #queue-1 do
  minocolor(queue[i+1])
  if i==1 then sspr((queue[i+1]*8)-8,40,8,8,108,(i*8)-3,16,16)
  else spr(queue[i+1]+79,112,(i*9)+2)
  spr(71,108,i*9+2,2,1) end
 end
 if debug!=nil then print(debug,0,64,7) end
end

function printsh(sstring,sx,sy)
 print(sstring,sx+1,sy+1,13)
 print(sstring,sx,sy,7)
end

function colorblend(color1,color2)
 if frame%2==0 then
  return color2
 else
  return color1
 end
end

function minocolor(m)
 pal()
 if m==1 then
  pal(9,12)
  pal(4,5)
  pal(15,7)
 elseif m==2 then
  pal(9,5)
  pal(4,1)
  pal(15,12)
 elseif m==3 then
  pal(9,9)
  pal(4,4)
  pal(15,15)
 elseif m==4 then
  pal(9,10)
  pal(4,9)
  pal(15,7)
 elseif m==5 then
  pal(9,11)
  pal(4,3)
  pal(15,7)
 elseif m==6 then
  pal(9,13)
  pal(4,2)
  pal(15,6)
 elseif m==7 then
  pal(9,8)
  pal(4,2)
  pal(15,14)
 end
end

function makeparticle(tb,x,y,dx,dy,g,c,rn,l,rd,drd,c2,c3,c4)
 if prtenb then
  if rd==nil then rd=0 end
  if drd==nil then drd=0 end
  tb[#tb+1]={x=x,y=y,dx=dx,dy=dy,g=g,c={c,c2,c3,c4},rn=rn,l=l,rd=rd,drd=drd,il=l}
 end
end

function updateparticle(tb)
 for i=1,#tb do
  local p=tb[i]
  if p!=nil then
   p.dx-=(rnd(p.rn)/16)
   p.dx+=(rnd(p.rn)/16)
   p.dy-=(rnd(p.rn)/16)
   p.dy+=(rnd(p.rn)/16)
   p.x+=p.dx/4
   p.y+=p.dy/4
   p.dy+=p.g/32
   p.rd+=p.drd/8
   p.rd=mid(0,p.rd,128)
   p.l-=1
   tb[i]=p
   if p.l==0 then
    del(tb,p)
   end
  end
 end
end

function drawparticle(tb)
 for i=1,#tb do
  local p=tb[i]
  if p!=nil then
   local cm=#p.c-flr(p.l/p.il*#p.c+.99)+1
   if cm<0 or cm>#p.c then cm=0 end
   if p.rd<1 then
    circfill(p.x+poff.x,p.y+poff.y,p.rd,p.c[cm])
   else
    circfill(p.x+poff.x,p.y+poff.y,p.rd,p.c[cm])
   end
  end
 end
end


