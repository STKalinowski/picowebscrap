--sybil's tail version 1.1.2
--by sol; label by sol & osmoru
--main
//build_id=peek2(2)

function _init()
 memset(0x4300,0,6911)
 cls()
 decode()
 mx,mxmx,cptx,cpty,lfb,sldln,tetrgrace,
 jspd,grav,yvel,
 fcnt,mapy,
 neg1,rads,flws,
 lgrace,rgrace,lk,et,poff=unpack(stab(vardat))
 tracks,npal,flw_cols,rib_pal,
 p_npal,p_dpal,cpt_gpal,sbn_trans,sbl_lpal,
 sbl_rpal,areas,jphzs,cyclopal,
 obj_st_d,ntb_pal,pltr_pal,pltg_pal,
 p_mod,cyc_mod,cld_pal,chk_a,
 chk_t,rad_p,flw_pal,sbk_pal,
 sclen,hrt,g_omit,pal_areas,
 area_cols_n,area_cols_d,
 flw_pal2,obj_st_l,thr_ani=unpack(smap(arrdat))
 nte_pals,sbk_cols,ai,wind,cargs,spal,spal2,obj_sigs=
  unpack(fmap({nte_pals,sbk_cols,ai,wind,cargs,spal,spal2,obj_sigs},smap))
 sz_dat,lines,musics,pts,
 blocks,objs,cols,clouds,
 obj_ini,obj_ups,t_map,
 z_lvl,ini_anis,fox_anis,stars=
  dup({},15)
 mlabs=spln(mlabs)
 p_dpal[4],p_dpal[6],p_npal[2]=14,8,8
 
 //radish graphics
 ent_asm=sub(ent_asm,0,254)..
[[03247937927736325b35b
03247937927736325b45b]]

 msgs[41]=
[[if someone throws something at
you, throw it right back!
														--bullying bureau]]
 
 //fix issue on p8 0.2.2c
 //where tab chars are not
 //printed for some reason
 for k,s in pairs(msgs) do
  for i=1,#s do
   if sub(s,i,i)=="\t" then
    s=sub(s,1,i-1).." "..sub(s,i+1,#s)
   end
   msgs[k]=s
  end
 end
 
 for i=1,26,2 do
  mlabs[mlabs[i]]=stab(mlabs[i+1])
 end
 music(4,5000)
 comet=cocreate(
   function()
    local x,y,t,s=-32,0,16,16
    repeat
     for i=0,3 do
      local xi,yi=x+i,y+i
      foreach(cargs,
        function(args)
         add(lines,{
          xi-t/args[1],
          yi-t/args[2],
          xi,yi,args[3]
         })
        end
       )
      end
      x+=s
      y+=s/2
      yield()
     until y>127
     sfx(39)
     music(neg1)
     whilst(30,boil)
     whilst"30"
     spani"run"
     while _px<44 do
      _px+=2
      yield()
     end
     sfx(38)
     whilst(50,spani,"strt")
    _px,lk,fs=44,false,true
    tog_fs()
   end
  )
 tit=cocreate(
  function()
   while true do
    whilst(12,print,
     "press 🅾️ to start",54,32,7)
    whilst"12"
   end
  end
 )
 makezs=
  function(x,y)
   zs=cocreate(
    function()
     while true do
      m_obj(x,y,"zed")
      whilst"72"
     end
    end
    )
  end
 makezs(-3,72)
 
 local nbtn=btn
 btn=
  function(b) 
   if not b then 
    return nbtn()
   elseif not lk then
    return nbtn(b)
   end
  end
 i_ani()

 for i=1,3 do
  add(sz_dat,{
    ani=fox_anis[i],
    sclen=sclen[i],
    hrt=hrt[i]
   })
 end

 respawn=neg1
 
 local i,chance=0,.99
 while i<8100 do
  if rnd(1)>chance then
   add(stars,{i,rnd(32)})
   i+=1
   chance=.99
  end
  chance-=0.005
  i+=2
 end
 init_obj()
 flip()
 apply(smap(cyc_arg),spr)
 apply(smap(mcs),memcpy)
end

function btnpp(b)
 return btn(b) and 
  band(shl(1,b),lfb)==0
end

function _update()
 aobjs,_px,_py,_pknbk,_psld=
  {},p.x,p.y,p.knbk,p.sld
  
 for obj in all(objs) do
  if obj.persist or
     rng(obj.tx,-128,256) then
   add(aobjs,obj)
  end
 end
 if (btnp(🅾️)) title_done=true
 
 if not lk then
  local ar,achange=area()
  if achange then
   music(neg1,1500)
  end
  if stat(24)==neg1 and
     respawn==neg1 then 
   music(tracks[ar],1500)
  end
 end
 text=""
 
 if tailco then
  coresume(tailco)
  spani(p.ani_nm)
 else
 fcnt+=1
 if fcnt%40==0 then
  reload(0x600,0x600,0x200)
 elseif fcnt%20==0 then
  apply(wind,sset)
 end
 lines={}
 if title_done then
  coresume(comet)
 end
 if day and not p.fall and 
    mx<=99 then
  if not ending then
   makezs(-3,72)
   music(neg1,1000)
  end
  p.sd,lk,ending=neg1,true,1
 end
 
 if (lk) _psld=0
 if ending==1 then
  if _px>-16 then
   spani"run"
   _px-=1
  else
   spani"stnd"
   if stat(24)==neg1 then
    music(14,1000)
   end
   ending=2
  end
  if flr(mx)!=99 then
   mx+=plr(mx<99)
  end
 elseif ending==0 then
  if et>700 then
   if not tease then
    m_obj(mx,80,"rad")
    tease=true
   end
  end
 end
 if (et>500) coresume(zs)
 
 while #pts>=sz"sclen" do
  del(pts,pts[1])
 end
 
 local xshk=0
 if p.xvel==0 and 
    not p.pstuck then
  if p.yvel!=0 then
   xshk=rnd(2)*p.sd
  end
 end

 add(pts,rt(mx+_px+
   iff(p.dr,3,4)+xshk,
   _py+iff(_psld>0,6,4)+p.offy
 ))
 for i=1,#pts do
  pts[i].y+=0.01*i
 end
 foreach(aobjs,u_obj)
 foreach(clouds,u_obj)
 
 if respawn==0 then
  del(objs,cyc)
  bank=bank and memcpy(0x1000,0x4900,1536)
  for obj in all(objs) do
   if obj:is"rib" then
    obj.y=obj.orgy
   end
  end
  pts,respawn,olda,
  mx,_px,_py,boss_tic,
  p.sz,p.ifrms,_psld=
  {},neg1,nil,
  cptx-poff,poff,cpty-2,
  nil,2,60,0
  p.y=_py
 elseif respawn>0 then
  respawn-=1
  return
 end
 
 stp,p.ifrms=
  xstp(),max(p.ifrms-1,neg1)
 local ystp,ftc1,ftc2=ystp()
 _py+=ystp
 if p.fall and p_abov() then
  while p.fall and p_abov() do
   _py+=1
   p.yvel=0
  end
  _py-=1
 end
 for i=neg1,1,2 do
  repeat
   mx+=i
  until not iff(i<0,sf,sb)()
  mx-=i
 end

 if mx>mxmx then
  if boss_tic then
   coresume(boss_tic)
  else
   new_boss()
  end 
  _px=mid(0,120,_px+stp)
 else
  mx+=stp
 end
 
 if not lk then
  if stp!=0 and _pknbk==0 then
   if abs(p.xvel)>1 then
    spani"run"
   else
    spani"walk"
   end
  else
   if not (ftc1 and ftc2) and 
      (ftc1 or ftc2) then
    if p.ani.int then
     p.sd=plr(ftc1)
    end
    spani"tetr"
    tetrgrace+=1
   else
    spani"stnd"
    tetrgrace,l_sd=0,p.sd
   end
  end
	 
  if _psld<=0 and 
     not p.j  and
     _pknbk==0 then
   if btnpp(⬇️) and 
      not p_ani"attk" then 
    sfx(8) 
    _psld=10
    if p_ani"tetr" and 
       tetrgrace<10 then
     p.sd=l_sd
    end
    if ongrass() then
     local pmx,a=_px+mx,
      {-2*p.sd,2,11}
     m_obj(pmx+iff(p.dr,0,7),
      p.ft,"par",a)
     m_obj(pmx+iff(p.dr,-2,9),
      p.y+5,"par",a)
    end
   end
  else
   _psld-=1
  end
	 
  if onfrm("attk",2) then
   p.yvel-=gat(p.sz==1)
   sfx(gat(p.sz==1,7))
  end
	 
  if btnpp(❎) and _pknbk==0 then
   throw(p.grab)
   if p_ani"tetr" and tetrgrace<10 then
    p.sd=l_sd
   end
   spani"attk"
  elseif _psld>0 or _pknbk>0 then
   throw(p.grab,true)
  end
  if p.yvel!=0 then
   spani("jump"..lchain(ystp,jphzs))
  end
  if _pknbk>0 then
   _pknbk-=1
   spani"knbk"
  end
  if _psld>0 then
   spani(iff(
    rng(_psld,3.3333,8.75),
        "slid2","slid1"))
  end
  if mx<mxmx then
  poff=
   iff(fs,
    iff(day,40,16),
    iff(day,70,44))
  mx+=_px-poff
  _px=poff
  end
  
  if (_py>105) die()
 end
 
 p.offy=0
 if p_ani"walk" then
  p.offy=-p.afrm+1
 elseif p_ani"run" then
  p.offy=gat(rng(p.afrm,2,3),
   neg1)
 end
 end
 if p.grab then
  if grb_ovrd or onfrm("attk",tailfrm(),true) then
   p.g_paws,p.grab.x,p.grab.y,grb_ovrd=
    false,_px+7*p.sd+mx,_py,false
  else
   p.g_paws,p.grab.x,p.grab.y=
    true,_px+p.grab.offx*p.sd+mx,
    _py-7+p.offy+p.grab.offy
  end
  p.grab.sd=p.sd
 end
	
 if (not lk) _px=max(_px,0)

 p.pstuck,lfb,mx,p.x,p.y,p.knbk,p.sld=
  nil,btn(),max(mx,0),_px,_py,_pknbk,_psld
end
 
function celat(x,y)
 return mget(to_cel(x,y,mx))
end

function set_celat(x,y,c)
 mmset(c,to_cel(x,y,0))
end

function to_cel(x,y,mx)
 return 
  ((mx+x)/8)%128,
  (mid(y,32,88)/8-mapy/8)+
   flr(((mx+x)/8)/128)*8
end

function _draw()
 cls()
 memcpy(0x6000,0x4300,1536)
 for obj in all(aobjs) do
  if obj.flwdone then
   d_obj(del(objs,obj))
  end
 end
 memcpy(0x4300,0x6000,1536)
 pal()
 
 print(text,0,106,7)
 clip(0,24,128,79)
 local mcx=flr((mx/128))*16
 local mpos=-mx+(mcx/16)*128
 
 rectfill(0,24,128,104,12)
 if not day then
  for star in all(stars) do
   pset(star[1]-mx-mx/32,
    star[2]+26,10)
  end
 end
 foreach(clouds,d_obj)
 
 for i=4832,5936,8 do
  for j=24,100,8 do
   spr(65,i-mx,j)
  end
 end

 for i=0,32 do
  local mposi8=mpos+i*8
  local c=celat(mposi8,mapy+56)
  if not fget(c,3) then
   if c==47 then
    c=18
   end
  elseif c<16 then
   c+=16
  elseif c==54 then
   c=29
  end
  if find(g_omit,c) then
   c=0
  end
  if c!=0 then
   spr(c,mposi8,96)
  end
  
  c=celat(mposi8,mapy)
  if fget(c,4) then
   c=13
  elseif fget(c,6) then
   c=0
  elseif c==35 then
   c=18
  end
  if c!=0 then
   spr(c,mposi8,24)
  end
 end
 
 for i=0,16,16 do
  mcx+=i
  map(mcx%128,flr(mcx/128)*8,
   mpos+8*i,mapy,16,8)
 end
 
 foreach(lines,function(l)line(unpack(l))end)
 foreach(aobjs,d_obj)
 
 p.pal[4],p.pal[6]=
  gat(not p.g_paws,4),
  gat(p.g_paws,4)
	
	for x=5968,7720,8 do
  spr(50,x-mx,95)
 end
 
 if flash then
  rectfill(0,24,128,104,7)
  flash=false
 end

 if not title_done then
  pal()
  coresume(tit)
  coresume(zs)
 end
 if ending then
  et=min(et+1,9999)
  if (fs) tog_fs()
  menuitem(2,nil)
  print(msgs[37+ending],16,28,7)
 end
 if et>515 then
  print(
[[a game by sol
thanks for playing!♥]],16,34,9)
 end
 
 if day then
  clip(136-mx,0,360,127)
  p.pal=p_dpal
  d_obj(p)
  p.pal=p_npal
 end
 
 if (not day) apply(spal,pal)
 
 pal(12,iff(day,area_cols_d,area_cols_n)[lchain(mx,pal_areas)],1)
 
 if fs then
  memcpy(0x6000,0x6780,0x1000)
 end
 clip()
 camera()
end

function die()
 sfx(17)
 music(neg1)
 if p.grab then
  p.grab.hl,p.grab=
   true,throw(p.grab,true)
 end
 m_flw(8,_px,_py-7)
 brk(_px+mx,_py,9)
 _px,p.sz,p.sd,
 _pknbk,p.yvel,p.xvel,
 p.ifrms,p.gpaws,respawn=
  poff,2,plr(not day),1,neg1,0,9,false,60
end

function brk(x,y,c)
 for i=0,1 do
  for j=0,1 do
   m_obj(x+7*j,y+7*i,"par",
   {-1.5+3*j,2-.5*i,c})
  end
 end
end

function play_note(note)
 poke(17084,note)
 poke(17085,14)
 sfx(63)
end

function p_ani(k)
 local ani=sz"ani"
 return iff(k,p.ani==ani[k],ani)
end

function ongrass()
 for xoff=2,6,4 do
  local r=
   fget(celat(_px+xoff,_py+8+p.yvel),5)
  if (r) return r
 end
end

function onfrm(ani,frm,whole,obj)
 return 
  (whole or p.acnt==0) and 
  p_ani(ani) and p.afrm==frm
end

function footfx()
 if not p.fall and
    (onfrm("run",4) or 
    onfrm("walk",1)) then
  if ongrass() then
   sfx(19)
   if abs(p.xvel)>1 then
    m_obj(
     _px+mx+rnd(2)*gat(p.dl,7),
     _py+6,"par",
     {(-0.3+rnd(1))*p.sd,
     1+rnd(2),11}
    )
   end
  else
   sfx(23)
  end
 end
end

function boil()
 camera(rnd(2),rnd(2))
end

function area()
 local preva,r=
  olda,lchain(mx+_px,areas)
 olda=r
 return r,r!=preva
end

function tailfrm()
 return iff(p.sz==1,2,4)
end

function sz(str)
 return sz_dat[p.sz][str]
end

function lchain(v,vs)
 local r=0
 repeat
  r+=1
 until v<vs[r]
 return r
end

function tog_fs()
 fs=not fs
 poke(0x5f2c,iff(fs,3,0))
 menuitem(2,iff(fs,"widescreen","fullscreen"),tog_fs)
end
--phys
function xstp()
 _pxvel=p.xvel
 if p.lj then
  _pxvel-=.1*sgn(_pxvel)
  goto no_input
 end
 
 if _psld>0 then
  _pxvel,sld=
   4.5*p.sd*_psld/10,10-_psld
  if btnpp(🅾️) then
   if rng(sld,2,6) then
    _psld,p.lj=0,true
    sfx(12) 
   else
    _pxvel=0
   end
  end
  goto no_input
 end
 
 if (_pknbk>0) goto no_input
 
 rgrace-=1
 lgrace-=1
  
 mult=1
 if((btnpp(➡️) and rgrace>0) or
   (btnpp(⬅️) and lgrace>0)) and 
   not p.grab then
    p_run=true
 elseif (not btn(➡️) and _pxvel>0) or 
        (not btn(⬅️) and _pxvel<0) or
        _pxvel==0 then
  p_run=false
 end
 
 if btnpp(⬅️) then
  lgrace=8
 elseif btnpp(➡️) then
  rgrace=8
 end
  
 if p_run then
  mult=1.5
 end
 if mult>1 and p.j then 
  mult-=0.2 
 end
 
 if btn(⬅️) then
  _pxvel=neg1*mult
  if (not p_ani"attk")p.sd=neg1
 elseif btn(➡️) then
  _pxvel=1*mult
  if (not p_ani"attk")p.sd=1
 else
  _pxvel=0
 end

 footfx() 
 ::no_input::

 if _pxvel>0 and sf() or 
  _pxvel<0 and sb() or 
  not p.j and p_ani"attk" then
  _pxvel=0
 end
 
 p.xvel=_pxvel
 return _pxvel
end

function ystp()
 local _pyvel=p.yvel
 if _pknbk<=0 then
  if btnpp(🅾️) and 
     not p.j then
   if (not p.lj) sfx(1)
   _psld,p.j=0,true
   _pyvel+=jspd*iff(p.lj,.8,1)
  end
 end
 local ny=_py+8+_pyvel
 
 ft1,ft2,pft=_px+3,_px+6,_py+7
 
 ftc1,ftc2=
  y_col(ft1,pft,ny) or 
  y_o_col(ft1,pft,ny),
  y_col(ft2,pft,ny) or 
 	y_o_col(ft2,pft,ny)
 
 if p_abov() then
  _pyvel=max(0,_pyvel)
 end
 ny=ftc1 or ftc2
 if ny then
  p.j,p.lj=false,false
  if _pknbk>0 then
   _pknbk,p.xvel=1,0
  end
  local y=-(_py+8-ny)
  if p.fall then
   if ongrass() then
    if _pyvel>5.5 then
     pft+=y
     m_obj(_px+mx,pft,"par",{-1.5,1.5,11})
     m_obj(_px+mx+7,pft,"par",{1.5,1.5,11})
     sfx(21)
    else
     sfx(19)
    end
   else
    sfx(23)
   end
  end
  p.yvel,p.fall=0,false
  return y,ftc1,ftc2
 else
  p.fall,_pyvel=
   true,min(_pyvel+grav,7)
 end
	
 p.yvel=_pyvel
 return _pyvel,ftc1,ftc2
end

function x_col(y,x1,x2)
 return fget(celat(x2,y),1)
end

function y_col(x,y1,y2)
 local fy=y2-y2%8
 return 
  fget(celat(x,y2),0) and 
   y2<96 and y1<fy and fy 
end

function y_abov(x,y1,y2)
 return 
  fget(celat(x,y2),2) and 
   y1>y2 and (y2-y2%8)+7
end

function p_abov()
 return y_abov(ft1,_py,_py-1) or
    y_abov(ft2,_py,_py-1)
end
function y_o_col(x,y1,y2)
 if y1<y2 then
  for o in all(cols) do
   local s=o.solid
   if s.y+o.y>=y1 and rect_col(
      x+mx,y2,1,1,
      s.x+o.x,s.y+o.y,
      s.w,s.h) then
    p.pstuck=o
    o.pstuck=true
    return o.y-s.y
   end
  end
 end
end

function rect_col(x1,y1,w1,h1,x2,y2,w2,h2)
 return 
  ((x1>=x2 and x1<=x2+w2) and 
  (y1+h1>=y2 and y1<=y2+h2)) or
  ((x2>=x1 and x2<=x1+w1) and 
  (y2+h2>=y1 and y2<=y1+h1))
end

function sf()
 local pwx=_px+9
 return 
  fget(celat(pwx,_py),1) or
  fget(celat(pwx,p.ft),1)
end

function sb()
 return 
  fget(celat(_px,_py),1) or
  fget(celat(_px,p.ft),1)
end

function stomp(o1,o2)
 if o1 and o2 then
  if iff(o1==p,p_col,obj_col)
     (o2,o1) and
     o1.y<=o2.y and
     o1.yvel>0 then
   return o1
  end
 end
end
--asm

function i_asm()
 flabs,sz2,sz3,elabs,
 ent_asm,fbase,sz1=
  stab(flabs),smap(sz2),smap(sz3),
  unpack(fmap({elabs,ent_asm,fbase,sz1},spln))
 
 //spikeball gfx patch
 ent_asm[15]="11200607d707776"
 
 for k,v in pairs(fbase) do
  local l=flabs[k]
  sz1[l] =
   m_asm(v.."10c 60c"..sz1[k])
  for sz in all{sz2,sz3} do
   local a=m_asm(v.."10c 60c")
   a.ssprect={sz[k]}
   sz[l]=a
  end
 end
 for i=1,25 do
  ent_asm[elabs[i]]=
   m_asm(ent_asm[i])
 end
end

function m_asm(str)
 str=trim(str)
 local sp,pxs,str=
  tonum(sub(str,1,3)),{},
  sub(str,4)
 for i=1,#str,3 do
  local px={}
  for j=0,2 do
   add(px,
    tonum("0x"..sub(str,i+j,i+j))
   )
  end
  add(pxs,px)
 end
 
 return {
  sp=sp,
  pxs=pxs,
 }
end

function d_asm(x,y,asm,flp,flpy)
 local sp,pxs,flp=
  asm.sp,asm.pxs,nif(flp,false)
 spr(sp,x,y,1,1,flp,flpy)
 for px in all(pxs) do
  local ax,ay,ac=unpack(px)
  if (flp) ax=8-ax-1
  if (flpy) ay=8-ay-1
  if band(peek(0x5f00+ac),16)!=16then
	  pset(x+ax,y+ay,ac)
	 end
 end
 if asm.ssprect then
  for r in all(asm.ssprect) do
   local ax,r2,r3,r4,r5,r6,r7=
    unpack(r)
   if flp then
    ax=nif(r7,4-ax-1)
   end
   sspr(r3,r4,r5,r6,x+ax,y+r2,r5,r6,flp)
  end
 end
end
--ani
function i_ani()
 i_asm()
 for fox in all({sz1,sz2,sz3})do
  fox_ani=
   upk_ani(fox_ani_txt,fox)
  fox_ani.walk.frms[2].pxs[5][3]=2

  fox_ani.attk.int,fox_ani.attk.loop=
   false,false
  add(fox_anis,fox_ani)
 end
 ent_ani=
  upk_ani(ent_ani_txt,ent_asm)
 ent_ani.bom_boom.loop,
  ent_ani.rad_spw.loop,
  fox_anis[1].attk.tim[1]=
  false,false,2
end

function upk_ani(txt,asms)
 local tab={}
 txt=smap(txt)
 for i=1,#txt,3 do
   local frms=
    fmap(txt[i+1],
    function(v)
     if is(v,"string") then
      v=asms[v]
     end
     return v
    end)
   tab[txt[i][1]]=
    m_ani(frms,txt[i+2])
 end
 return tab
end

function set_ani(obj,ani,ovrd)
 if is(ani,"string") then
  ani=ent_ani[obj.id.."_"..ani]
 end
 if (obj.ani==ani and not ovrd) 
    or (not obj.aint) then
  return
 end
 
 obj.afrm,obj.acnt,
 obj.aint,obj.ani=
  1,0,ani.int,ani
end

function spani(str)
 p.ani_nm=str
 set_ani(p,p_ani()[str])
end

function m_ani(frms,tim)	
 return {
  frm=1,
  frms=frms,
  cnt=0,
  tim=nif(tim,{neg1}),
  int=true,
  loop=true,
 }
end

function u_ani(obj)  
 local ani=obj.ani
 if ani and ani.tim then
  obj.acnt+=1
  if obj.acnt>=
   ani.tim[obj.afrm] then
   obj.acnt=0
   obj.afrm+=1
  end
  if obj.afrm>#ani.frms then
   if ani.loop then
    obj.afrm=1
   else
    obj.afrm=#ani.frms
    obj.aint=true
   end
  end
 end
end

function d_obj(obj)
 if obj.ifrms>0 and 
    obj.ifrms%10>5 then 
   return
 end
 set_pal(obj.pal)
 clp=peek4(0x5f20)
 if (obj.noclip) clip()
 cif(obj.bgdraw,obj)
 
 local ani=obj.ani
 if ani then
  local frm,x,y=
   ani.frms[obj.afrm],obj.tx,obj.y+gat(obj.offy)
  if is(frm,"number") then
   spr(frm,x-obj.offx,y,obj.spw,obj.sph,obj.dl,obj.flpy)
  else
   d_asm(x-obj.offx,y,frm,obj.dl,obj.flpy)
  end
 end
 cif(obj.draw,obj)
 set_pal(iff(day,nil,npal))
 poke4(0x5f20,clp)
end

--obj
function init_obj()
 for s in all(thr_ani) do
  thr_ani[sub(s,1,3)]=ent_ani[s]
 end
 
 local obj_st={}
 for i=1,11 do
  obj_st[obj_st_l[i]]=obj_st_d[i]
 end
 function obj_st:react(obj)
  if self.m>0 then
   ent_die(self)
  end
 end
 
 obj_mt = {
  __index = 
  function(t,k)
  if k=="tx" then 
   return iff(t.scroll,t.x-mx,t.x) 
  end
   return obj_st[k] or 
    ({
     w=7,
     h=7,
     ft=t.y+7,
     dr=t.sd==1,
     dl=t.sd==neg1,
    })[k]
  end
 }
 
 obj_code = {
  //fox
  function(obj)
   mod_obj(p_mod)
   p,obj.pal,obj.bgdraw=
    obj,p_npal,
    function()
     color(8)
     poke2(0x5f3c,pts[1].x-mx)
     poke2(0x5f3e,pts[1].y)
     for i=2,#pts do
      local pt=pts[i]
      line(pt.x-mx,pt.y)
     end
     line(p.x+iff(p.dr,4,2),p.y+3)
   end
  end,
  nil,
  
  //rub
  function(obj)
   mod_obj{1,neg1,grav,.6,6}
  end,
  function(obj)  
   if obj.m>0 and title_done then
    obj:sani"walk"
    local wx=obj.tx+gat(obj.dr)*7
    local xc=
     x_col(_objy,wx,wx+_objdir) or
     x_col(obj.ft,wx,wx+_objdir)
    local yc=
     y_col(wx,obj.ft,obj.ft+1)
    if xc or not yc then
     _objdir*=neg1
    else
     _objx+=0.5*_objdir
    end
   end
  end,
  
  //sig
  nil,
  function(obj)
   obj.bgdraw=function()
    obj.pal={2,iff(pget(obj.tx,obj.ft)==2 or pget(obj.tx+7,obj.ft)==2,4,2)}
   end
   if (day and _objarg==28) _objarg=29
   if _objarg==34 and sread then
    _objarg=31
   elseif _objarg==35 and sread2 then
    _objarg=36
   end
   if p_col(obj) and not p.j and
     _px-obj.tx<6 then
    if (_objarg==35) sread=true
    if (_objarg==31) sread2=true
    text=msgs[_objarg]
   end
   obj.arg=_objarg
  end,
  
  //rib,
  nil,
  function(obj)
   obj_flt(obj)
   _objpal=iff(p.sz>=2,rib_pal)
   if p_attking() and 
      (p_col(obj) or p_hrt(obj)) then
    if (p.sz!=3) m_tailco()
    grb_ovrd,p.sz,_objy=
     true,min(3,p.sz+1),1024
    sfx(3)
   end
  end,
  
  //frg
  function(obj)
   mod_obj{1,neg1,obj.y,5}
   obj.co=cocreate(    
    function()
     whilst(rnd(60))
     while true do
      obj:sani"jmp"
      if (rng(obj.tx,0,127)) sfx(6)
      local yvel=jspd
      repeat
       _objy=min(_objy+yvel,obj.oy) 
       yvel+=grav 
       yield()
      until _objy>=obj.oy
      obj:sani"stnd"
      whilst"60"
     end
    end
   )
  end,
  nil,
  
  //chk
  nil,
  function(obj)
   obj.w=6
   if not obj.s then
    o_mset(obj,
     chk_t[lchain(_objx,chk_a)])   
    if p_hrt(obj) then
     obj.s=0
     o_mset(obj,0)
     _objdir=-p.sd
     brk(_objx,_objy,4)
     sfx(9)
    end
   end
  end,
  
  //plt
  function(obj)
   mod_obj
    {rt(0,0,7,7),obj.x,obj.y}
  end,
  function(obj)
   if _objarg<2 then
    local pos=sin(fcnt/128)*
     iff(_objarg==0,20,10)
    if _objarg==1 then
     _objy=obj.orgy-pos
    else
     local cx,nx=_objx,obj.orgx-pos
     if obj.pstuck then
      mx-=_objx-nx
     end
     _objx=nx
    end
   else
    local vel=
     plr(_objarg==2,1.5)
    _objpal=iff(vel>0,
     pltr_pal,pltg_pal)
    if obj.pstuck then
     _objy+=vel
     _py=_objy-7
    elseif abs(_objy-obj.orgy)>1 then
     _objy-=vel/3
    end
   end
  end,

  //bey
   function(obj)
    mod_obj{
     obj.x,1,plr(obj.arg!=1),.5}
   end,
   function(obj)
    if obj.m>0 then
     local nx,drc=
     sin((obj.foff-fcnt)/64)*20,plr(_objarg!=1)
     if abs(nx/20)==1 then
      obj:sani("spn",true)
      _objdir=sgn(nx)*drc
     end
     _objx=obj.orgx+nx*drc
    end
   end,
   
   //nte
   function(obj)
    obj.pal=nte_pals[obj.arg%3+1]
   end,
   function(obj)
    if p_col(obj) or 
       obj.touched then
     play_note(32+(_objarg%3)*2)
     add(musics,_objarg)
     obj:bom()
    else
     obj_flt(obj)
    end
   end,
   
   //ntb
   function(obj)
    mod_obj{9,ntb_pal,101}
   end,
   function(obj)
    if not obj.active and
       find(musics,_objarg)then
     obj.active,_objpal=true,
      nte_pals[_objarg%3+1]
    elseif obj.active and
           abs(p.y-obj.y)<7 and
           abs(p.x-obj.tx)<10 then
     play_note(48+(_objarg%3)*2)
     obj:bom()
     obj.tno=0
    end
    o_mset(obj,obj.tno)
   end,
   
   //sbk
   function(obj)
    if obj.arg>=32 then
     obj.inverse=true
     obj.arg-=32
    end
    sbk_set_cols(obj)
    obj.pal=
     {8,obj.primc,unpack(sbk_pal)}
    obj.tpal=obj.pal
   end,
   function(obj)
    local crit=obj.blocks!=blocks[_objarg]
    if crit or (not crit and obj.blocks==blocks[_objarg]) then
     crit=blocks[_objarg]
     if obj.inverse then
      crit=not crit
     end
     if crit then
      _objpal={2,obj.primc,8,obj.subc,0,8,9,obj.subc}
      o_mset(obj,32)
     else
      _objpal=obj.tpal
      o_mset(obj,0)
     end
     obj.blocks=blocks[_objarg]
    end
   end,
   
   //sbn
   function(obj)
    sbk_set_cols(obj)
    obj.tpal={
     8,obj.primc,
     2,obj.subc,
     14,obj.terc,
    }
    obj.pal=obj.tpal
   end,
   function(obj)
    if (((stomp(p,obj) and 
     rng(p.x+4+mx,obj.x,obj.x+8)) or 
     (stomp(obj.touched,obj))and
     obj.touched!=obj.ltouch))and
     not obj.pushed
     then
     obj.ltouch,_objpal,obj.pushed=
      obj.touched,sbn_trans,true
     blocks[_objarg]=
      not blocks[_objarg]
     sfx(13)
    elseif obj.pushed and
           not p_col(obj) then
     _objpal=obj.tpal
     obj.pushed=false
    end
   end,
   
   //rad
   function(obj)
    obj.grbl=find(rad_p,obj.x)
   end,
   nil,
   
   //bal
   nil,
   function(obj)
    obj_flt(obj)
    local h=stomp(p,obj) or
     stomp(obj.touched,obj)
    _objy-=gat(_objy>obj.orgy)
    if h then
     brk(_objx,_objy,8)
     sfx(14)
     _objy,h.yvel,h.xvel=196,-4,
      iff(h==p,h.sd,1)
    end
   end,
   
   //flw
   function(obj)
    mod_obj{
     {unpack(flw_pal)},0,4}
   end,
   function(obj)
    local arg1=_objarg==1
    if arg1 and not obj.bloom then
     obj_flt(obj,rnd(30))
    end
    local crit =
     ((not p.j)and _py==_objy) or arg1
    if not obj.bloom and
       ((p_col(obj) and crit)
       or (obj.touched and 
       arg1)) then
     obj.color,obj.bloom,obj.fcnt=
      choose(flw_cols),true,0
     _objpal=fpal()
     obj.stamp=time()
     sfx(15)
     flws+=1
     _objx+=gat(arg1,4)
    end
    _objpal[2]=11
    if obj.bloom then
     obj.fcnt=(1+obj.fcnt)%32
     _objpal=fpal()
     _objpal[
      iff((time()-obj.stamp)%2<.25,6,4)
     ]=obj.color
     if arg1 then
      obj.persist,_objpal[2]=
       true,0
      if not obj.dest or 
         obj.y<obj.dest then
       _objy+=0.2
       _objx+=sin(obj.fcnt/32)
      else
       obj.flwdone,_objpal=true,
        {11,0,8,obj.color,9,0}
      end
      if _objy>104 or 
         not rng(obj.tx,-16,144) then
       obj.noclip,obj.scroll,
       _objx,_objy,obj.dest=
        true,false,rnd(127),-4,rnd(15)
      end
     end
    end 
   end,
   
   //cpt
   function(obj)
    obj.draw=function()
     if obj.pal then
      for i=1,3,2 do
       pset(obj.tx+i,obj.y-1,11)
      end
     end
    end
   end,
   function(obj)
    _objpal=nil
    if p.grab and 
       p.grab.oid=="rad" then 
     _objpal=cpt_gpal
     if p_col(obj) then
      p.grab:bom()
      del(objs,p.grab)
      s=m_obj(4+(p.grab.grbd.grbl-1)*8,16,"rad")
      s.scroll,s.noclip,
      p.grab,p.g_paws=
       false,true,nil,false
      rads+=1
      sfx(11) 
     end
    end
    if cptx!=_objx then
     obj:sani"idle"
     if p.yvel==0 and
        p_col(obj) then
      cptx,cpty=_objx,_objy
      if p.sz==1 then
       p.sz,grb_ovrd=2,m_tailco()
       sfx(3)
      else
       sfx(16)
      end
     end
    else
     obj:sani"actv"
    end
   end,

   //sbl
   function(obj)
    mod_obj{
     0,obj.x-4,obj.y-5,1,false
    }
   end,
   function(obj)
    obj.fcnt=((obj.fcnt+1)%78)
    local nx=(obj.fcnt/78)
    if nx>0.5 then
     nx=1-nx
     _objpal=sbl_lpal
    else
     _objpal=sbl_rpal
    end
    _objx,_objy=
     obj.orgx+nx*64,
     obj.orgy-sin(nx)*iff(_objarg==1,10,20)
    add(lines,{obj.tx+3,_objy+2,obj.orgx-mx+20,obj.orgy-3,5})
   end,
   
   //par
   function(obj,arg)
    mod_obj{
     abs(arg[1]),arg[2],arg[3],
     sgn(arg[1]),obj.x
    }
    obj.draw=
     function(obj)
      local x,y,c=
       obj.tx,obj.y,obj.c 
      if find({4,11},c) and
         fget(celat(x,y),7) then
       c=1
      end
      pset(x,y,c)
     end
   end,
   function(obj)
    obj.dx=max(0,obj.dx-0.1)
    obj.dy-=0.2
    _objx+=obj.dx*obj.d
    _objy-=obj.dy
    if _objy>127 then
     del(objs,obj)
    end
   end,
    
   //thr,
   function(obj,grbd)
    local oid=grbd.id
    set_ani(obj,thr_ani[oid])
    mod_obj{
     false,oid,0,1,false,
     grbd.parent,grbd.toffy,
     grbd.toffx,grbd,true,true,0
    }
   end,
   function(obj)
    if obj.thrown then
     obj.sui+=1
     if obj==throbj and 
      _objy>127 or obj.sui>90 then
      throbj=nil
      ent_die(obj)
      del(objs,obj)
     end
     local xv,ow=
      obj.xvel*_objdir,
      _objx+iff(obj.dr,7,0)
     cx=x_col(_objy,ow-mx,ow+xv-mx) or
        x_col(_objy+7,ow-mx,ow+xv-mx)
     if not cx then
      _objx+=obj.xvel*_objdir
      obj.x=_objx
     else
      sfx(18)
      obj.yvel=0.5
      _objdir*=neg1
     end

     cy=y_col(obj.tx+3,obj.ft,
         _objy+obj.yvel+7) or
        y_col(obj.tx+6,obj.ft,
         _objy+obj.yvel+7)
     
     if not cy then
      _objy+=obj.yvel
     end
     
     if cy and not cx then
      obj.thrown=false
       if obj.oid=="rad" then
        ent_die(obj)
       else
        local o=
         m_obj(_objx,cy-8,obj.oid)
        o.sd,o.parent,throbj=
        _objdir,obj.oparent,nil
       end
       throbj=nil
       del(objs,obj)
       obj.thrown=false
     else
      obj.yvel=
       max(-7,obj.yvel)+grav
     end
    end
   end,
   
   //cld
   function(obj)
    obj.spw,obj.persist=2,true
   end,
   function(obj)
    _objpal=iff(day,cld_pal,npal)
    _objx-=0.1
    if (_objx<-20) _objx=8220
   end,
   
   //gre
   function(obj,arg)
    mod_obj{
     true,arg or 0.4,neg1,3,
     0,1
    }
   end,
   function(obj)
    if obj.det>0 then
     obj.yvel+=0.1
     local yc=y_col(obj.tx+4,_objy,_objy+obj.yvel+7)
     if yc and yc-yc%8>_objy+7-(_objy+7)%8 then
      if abs(obj.yvel)>0.5 then
       sfx(10)
       obj.yvel=(obj.yvel-0.2)*neg1
       obj.xvel=abs(obj.xvel)*plr(obj.tx<_px)
      end
      obj.det-=1
     else
      _objy+=obj.yvel
     end
     _objx+=obj.xvel
    else
     if not obj.sploded then
      sfx(9)
      obj.sploded=true
     end
     obj:sani"splode"
     obj.m,obj.grbl=1,false
     if obj.afrm==2 then
      del(objs,obj)
      if obj.parent then
       obj.parent.gre=nil
      end
     end
    end
   end,
   
   //cyc,
   function(obj)
    mod_obj(cyc_mod)
    obj.react=
     function(self,other)
      sfx(9)
      obj.bom,obj.gre,obj.gre_t=
       15,nil,200
      local x,y=other.tx,other.y
      cyc.hp-=1
      flash,obj.draw=true,
       function()
        spr(126,x,y)
        obj.bom-=1
        if obj.bom<=0 then
         obj.draw=nil
        end
       end
      return true
     end
   end,
   function(obj)
    _objpal=
     iff(fcnt%6>2,cyclopal)
    obj.gre_t-=1
    if not obj.gre and obj.gre_t<0 and rng(obj.tx,32,114) then
     obj.gre,obj.gre_t=
      m_obj(_objx,_objy,"gre",0.4*plr(obj.tx<_px)),rnd(60)+30
     obj.gre.parent=obj
    end 
   end,
   
   //bom
   nil,
   function(obj)
    if (obj.afrm==3) then
     del(objs,obj)
    end
   end,
   
   //zed
   function(obj)
    obj.draw=function()
     print("z",obj.x,obj.y,7)
    end
    obj.scroll=false
   end,
   function(obj)
    _objx+=0.2
    _objy-=0.4
    if (_objy>132) del(objs,obj)
   end,
   
   //arr
   nil,
   function(obj)
    _objx=obj.orgx+(fcnt%48)/24
   end
  }

 local oc=obj_code
 for i=1,25 do
  local i,id,tile,z,a=i*2-1,unpack(obj_sigs[i])
  obj_ini[id],obj_ups[id]=
   oc[i],oc[i+1]
  if tile then
   t_map[tile],z_lvl[id]=id,z
  end
  if a then
   ini_anis[id]=ent_ani[id..a]
  end
 end
 
 //1.1.2 extra sign
 m_obj(7992,80,"sig",41)
 
 map_objs()
end

function map_objs()
 local layers={{},{},{},{}}
 for i=0,127 do
  for j=0,63 do
   local id = t_map[mget(i,j)]
   if id!=nil then 
    local dirty,pend={{i,j}},
    {
     (i*8)+1024*flr(j/8),
     ((j%8)*8)+mapy,id
    }

    local arg,dt=find_arg(i,j)
    
    pend[4]=arg
    add(dirty,dt)
    
    if id=="cld" then
     local x,y,id,a=unpack(pend)
     add(clouds,m_obj(x,y,id,a,true))
    else
     add(
      layers[z_lvl[id]],
      pend
     )
    end
    
    foreach(dirty,
     function(t)
      local rt,x,y=0,unpack(t)
      mset(x,y,rt)
     end
    )
   end
  end
 end
 
 for z=1,2 do
 for i=0,127 do
  for j=0,63 do
   local t=mget(i,j)
   if z==2 then
    if t==32 then
     mset(i,j,mget(i,j-1))
    end
   else
   local v=fget(128+t)
   if v!=0 then
    for k=j+1,j+(8-j%8)-1 do
     if (mget(i,k)!=0) break
     mset(i,k,v)
    end
   end
   end
  end
 end
 end

 for i=1,4 do
  for j=1,#layers[i] do
   m_obj(unpack(layers[i][j]))
  end
 end
end

function find_arg(x,y)
 for i in all({neg1,1}) do
  local s=mget(x+i,y)
  if s>127 then
   return s-128,{x+i,y}
  end
 end
 return 0
end
 
function m_obj(x,y,id,arg,noadd)
 local obj = {
  x=x,
  y=y,
  orgx=x,
  orgy=y,
  id=id,
  foff=fcnt,
  offy=0,
  arg=arg,
  is=
   function (o,...)
    for s in all{...} do
     if (s==o.id) return true
    end
   end,
  sani=set_ani,
  alive=function(obj) return obj.m>0 end
 }
 function obj:bom()
  local b=m_obj(self.x,self.y,"bom")
  b.pal=self.pal
  del(objs,obj)
 end
 
 setmetatable(obj,obj_mt)
 _modobj=obj
 local oa=ini_anis[obj.id]
 if (oa) set_ani(obj,oa)
 cif(obj_ini[obj.id],obj,arg)
 if obj.m>=0 and 
    obj.grbl!=false then 
  obj.grbl=true
 end
 if (not noadd) add(objs,obj)
 if (obj.solid) add(cols,obj)
 return obj
end

function set_pal(p)
 pal()
 p=p or {}
 for i=1,#p-1,2 do
  if p[i+1]==0 then
   palt(p[i],true)
  else
   pal(p[i],p[i+1])
  end
 end
end

function u_obj(obj)
 _objx,_objy,_objdir,
 _objpal,_objarg=
   obj.x,obj.y,obj.sd,
   obj.pal,obj.arg
 
 cif(obj_ups[obj.id],obj)
 if obj.co and obj.m>0 then
  coresume(obj.co)
 end
 obj.x,obj.y,
 obj.sd,obj.pal,obj.touched=
  _objx,_objy,_objdir,_objpal,nil
	 
 if not p.grab and
    obj.grbl and
    (p_hrt(obj) or 
    obj:is"rad" and p_col(obj)) and 
    _pknbk<=0 and
    not throbj and
    p_attking() then
  sfx(2)
  del(objs,obj)
  p.grab=
   m_obj(_px,-_py-7,"thr",obj)
  obj.m=0
 end
 if obj.m>0 and not lk then
  if p.ifrms<=0 and p_col(obj) and p.grab!=obj then
   local xf=
    iff(obj.x<mx+_px,2,-2)
   if _pknbk==0 then
    _psld,_pknbk,
    p.xvel,p.yvel=
     0,30,
     xf,-3
    p.sz-=1
    if p.sz<=0 then
     die()
    else
     p.ifrms=60
     for i=sz"sclen",#pts do
      local pt=pts[i]
      m_obj(pt.x,pt.y,"par",
       {xf,3,8})
     end
    end
    sfx(4)
   end
  end
 end 
 if throbj and 
    not throbj.hl then
  if obj_col(obj,throbj) then
   if obj:react(throbj) then
    del(objs,throbj)
    throbj=nil
   end
   obj.touched=throbj
  end
 end
 obj.pstuck=false
 u_ani(obj)
end

function ent_die(obj)
 sfx(2)
 if obj.oid=="rad" then 
  m_obj(obj.grbd.orgx,obj.grbd.orgy,"rad")
 else
  m_flw(4,64,107)
 end
 obj.m,obj.gone,obj.grbl=0,true,false
 obj:bom()
end

function p_hrt(o)
 local ox = o.x-mx
 return p_hrt_rect(ox,o.y+1,7,6)
end

function p_hrt_rect(x,y,w,h)
 local s=sz_dat[p.sz]
 local px,pw=_px+7,s.hrt
 if p.dl then
  px-=pw+7
 else
  pw+=1
 end
 return p_attking() and
  rect_col(px,_py,pw,8,x,y,w,h)
end

function p_col(obj)
 p.h=iff(_psld>0,-4,7)
 return obj_col(p,obj)
end

function obj_col(o1,o2)
 return o1!=o2 and rect_col(
 	o1.tx,
 	iff(o1.h<0,o1.y-o1.h,o1.y),
  o1.w,o1.h,o2.tx,o2.y,o2.w,o2.h)
end

function p_attking()
 return p_ani"attk" and p.afrm>=tailfrm()
end

function obj_flt(obj,r)
 obj.float=nif(
  obj.float,gat(r)
 )
 obj.float+=1
 obj.offy=plr(obj.float>30,0.1)
 if obj.float>60 then
  obj.offy,obj.float=0,0
 end
end

function o_mset(obj,tno)
 mmset(tno,to_cel(obj.x,obj.y,0))
end

function sbk_set_cols(obj)
 local cols=sbk_cols[obj.arg+1]
 obj.primc,obj.subc,obj.terc=
  unpack(cols)
end

function throw(thr,drop)
 if thr then
  thr.xvel,thr.yvel,thr.thrown,
  thr.x,thr.y,thr.hl,
  throbj,thr.flpy,p.grab,p.g_paws=
   iff(drop,0,2.5),-1.8,true,
   mx+_px,_py-7,drop,
   thr,false,nil,false
  local c=celat(_px+1,_py-7)
  if fget(c,0) and fget(c,2) then
   ent_die(thr)
   del(objs,throbj)
   throbj=nil
  end
 end
end

function m_tailco()
 tailco=cocreate( 
  function()    
   for i=1,2 do
    p.afrm=4
    p.sz-=1
    p.ani=sz"ani".attk
    whilst"4"
    p.sz+=1
    p.ani=sz"ani".attk
    whilst"6"
   end
   tailco=false
  end
 )
end

function fpal()
 return {unpack(flw_pal2)}
end

--boss
function new_boss()
 memcpy(0x4900,0x1000,1536)
 memcpy(0x1000,0x4f00,1536)
 bank,boss_tic=true,cocreate(
 function()
  cyc=m_obj(mx-48,64,"cyc")
  sfx(39)
  if (fs) tog_fs()
  lk,p.sd,p.aint=
   true,neg1,true
  spani"shok"
  whilst(40,boil)
  lk=music(10)
  while true do
   for phz in all(ai) do
    xvel,destx=0,nil
    tspeed,destx,newy=unpack(phz)
    if destx then
     cyc.sd,tspeed=
      sgn(tspeed),abs(tspeed)
     repeat
      xvel=min(tspeed,xvel+0.1)
      cyc.x+=xvel*cyc.sd
      if (cyc.hp==0) goto ending
      yield()  
     until (cyc.sd<0 and cyc.tx<destx) or (cyc.sd>0 and cyc.tx>destx)
     cyc.y=newy
    else
     whilst(tspeed)
    end
   end
  end
  ::ending::
  lk,p.aint=true,true
  spani"shok"
  music(neg1)
  whilst(10,
   function()
    boil()
    brk(cyc.x+rnd(16),cyc.y+rnd(16),6)
    sfx(9)
    whilst(5)
   end
  ) 
  del(objs,cyc)
  sfx(39)
  p.sd,_px,_py,day=
   neg1,64,64,true
  whilst(120,
   function()
    flash=true
   end
  )
  
  if rads<15 then
  	music(14)
   spani"dead"
   makezs(_px+8,_py)
   p.bgdraw,ending=nil,0
  else
   m_obj(mx+8,64,"arr")
   mxmx,lk,poff,tracks[4],areas[4]=
    9999,false,70,0,9999
  end
  bank=memcpy(0x1000,0x4900,1536)
 end
)
end

function m_flw(c,x,y)
 local f=m_obj(mx+x,y,"flw",1)
  f.bloom,f.color,f.stamp=true,c,time()
end
--util
function find(t,v)
 for k,o in pairs(t) do
  if (v==o) return k
 end
end

function mmset(c,x,y)
 mset(x,y,c)
end

function fmap(t,f)
 for k,v in pairs(t) do
  t[k]=f(v)
 end
 return t
end

function smap(str)
 return fmap(spln(str),stab)
end

function iff(c,a,b)
 if c then 
  return a 
 else 
  return b 
 end
end

function nif(a,d)
 return iff(a!=nil,a,d)
end

function apply(t,fun)
 for args in all(t) do
  fun(unpack(args))
 end
end

function cif(f,...)
 if is(f,"function") then
  return f(...)
 end
end

function choose(t)
 return t[flr(rnd(#t))+1]
end

function stab(str)
 if str then
  local t=spln(str,",")
  fmap(t,
   function(s) 
    local r=tonum(s) or trim(s)
    if (r=="t") return true
    if (r=="f") return false
    return r
   end
  )
  return t
 end
end

function dup(v,t)
 local r={}
 for i=1,t do
  add(r,iff(is(v,"table"),{},v))
 end
 return unpack(r)
end

function is(v,t)
 return type(v)==t
end

function trim(str)
 local nstr = ""
 for i=1,#str do
  local c=sub(str,i,i)
  if not find({" ","\n","\t"},c) then
   nstr=nstr..c
  end
 end
 return nstr
end

function spln(str,lim)
 return split(str, lim or "\n", false)
end

function whilst(dur,fun,...)
 dur=tonum(dur)
 for i=1,dur do
  cif(fun,...) yield()
 end
end

function rng(n,lb,ub)
 return n>=lb and n<=ub
end

function mod_obj(t)
 for i=1,#t do
  _modobj[mlabs[_modobj.id][i]]=t[i]
 end
end

function plr(bool,mag)
 return iff(bool,1,-1)*(mag or 1)
end

function gat(b,mag)
 if (is(b,"number")) return b
 return iff(b,mag or 1,0)
end

function rt(x,y,w,h)
 return {x=x,y=y,w=w,h=h}
end
function decyph(n)
 return n and sub("▥░ \n,.-0123456789abcdefxtghijklmnopqrsuvwyz<>!?:'@#[➡️⬅️⬆️⬇️❎🅾️\"♥\t∧_",n,n)
end
function decode()
 txt=""
 for saddr=0x3200,0x42ff,68 do
	 for addr=saddr,saddr+63,2 do
		 local byt=%addr
		 if 0b1000000000000000&byt!=0 then
		  byt^^=0b1000000000000000
		  for i=0,2 do
		   txt=txt..decyph(byt>>5*i&31)
		  end
		  poke2(addr,0)
		 end
  end
 end

 for addr=0x1000,0x2fff do
  local v=@addr
  if v>=192 then
   local n=v-191
   c=decyph(n)
   if c=="\t" then
    rle=true
   elseif rle then
    for i=1,n do
     txt=txt.."\t"
    end
    rle=false
   else
    txt=txt..c
   end
   poke(addr,0)
  end
 end
 
 txt=spln(txt,"▥")
 msgs=spln(txt[2],"░")
 fbase,sz1,sz2,sz3,
 ent_asm,vardat,
 nte_pals,sbk_cols,cyc_arg,
 wind,ai,cargs,spal,spal2,arrdat,obj_sigs,flabs,
 elabs,mlabs,
 fox_ani_txt,ent_ani_txt,mcs=
  unpack(spln(txt[1],"░"))
end
