function un_sp(s)
return unpack(split(s))
end

function mspl(s)
local s2={}
for ss in all(split(s,"&")) do
add(s2,split(ss))
end
return s2
end

dr,db=split"1,0,0,-1,-1,0,0,1,1,-1,-1,-1,-1,1,1,1",split"-1,0,1,0,0,-1,0,1"
cartdata"moon_race"

function end_game()
ents,mute_win,fast,h={},true
fade_to(function()
if mode==2 then
_init()
return
end

music"41"
race_count+=1
rc1,scr_pal=race_count+1
for x=0,17 do for y=0,17 do
mset(x,y,(x+y)%2==0 and 32 or 48)
end end
for p in all(scores) do
p.rsc=9-p.pos
p.csc=p.rsc+p.frags-p.death
p.score+=p.csc
if p.hum then 
p.score+=.1
end
end  

local e=mke()  
e.dr=function()
map(0,0,t16-16,t16-16,18,18)
mfunc"rectfill,0,16,127,112,1,rect,-1,16,128,112,7"
rectshade(un_sp"0,14,127,15")
rectshade(un_sp"0,113,127,114")
end

mk_table(0)
end)
end

function mk_table(k)
ysort(scores,k==0 and "csc" or "score")

local e=mke()
local ready
e.upd=function()

if e.kl then   
e.x=(e.x-2)*1.5
else
e.x*=.85
end

if btn"5" then  
if ready and not e.kl then
mfunc"sfx,7,-1,11,2"

if solo then   
for i=1,3 do
local p,save_score=scores[i]
if p.hum then
  if k==0 then
  save_score=p.id*4+race_count-1
  elseif race_count==3 then
  save_score=p.id*4+3
  end
  if save_score then
        dset(save_score,max(4-i,dget(save_score)))
  end
end
end
end		 
e.kl=true 
if k==1 or mode>0 then
  if race_count==3 or mode>0 then
  fade_to(_init)
  else
  fade_to(init_game)
  end
else
wt(9,mk_table,1)
end		  
end
else
ready=true
end
end

e.dr=function(e,x,y)    
camera(-x,-y)
y=20
?k==0 and "pos kil pen tot" or "   score",64,y,13
y+=10

for p in all(scores) do  
local cl=8+p.id
pal(8,8+p.id)
pal(2,sget(16+p.id,1))
spr(128+p.id*16+4,12,y-2)
?ship_names[p.id+1],24,y,cl
pal()

--[[
if p.hum then
?"p"..p.hum,2.5+cos(t/24+p.hum/4),y,7
end
--]]

if k==0 then
?p.rsc,68,y,p.dead and 8 or 7
?p.csc,116,y,7
if p.frags>0 then
?"+"..p.frags,84,y,7
end

if p.death>0 then
?"-"..p.death,100,y,7
end 
else
?flr(p.score),84,y,7
end  
y+=10
end 

-- medals
if k==0 or race_count==3 then for i=1,3 do
local p=scores[i] 
if p.hum then
local g=e.t-32
if g==0 then 
mfunc"sfx,8,-1,9,4"     
elseif g==64 then
mfunc"sfx,7,-1,24,8"
end
--	   local c=1-mid(0,g/64,1)
--	   local cc=sqrt(c)*32
--	   local mx,my=2+c*96+cos(c*2)*cc,18+i*10+c*96+sin(c*2)*cc

local lc=mid(0,g/64,1)
local c,slc=(1-lc)*3,sin(lc/2)
local mx,my=lc*2+(cos(c)*slc+c)*20,lc*(18+i*10)+(sin(c)*slc+c)*20
pal(pp[5-i])
if g>16 or g>0 and t42
then
if k==0 then
spr(34,mx,my)
else
if g>64 and g<96 and t42 then
  apal"7"
end
spr(39,104-mx,my-4,2,2)
if g==64 then
for i=0,6 do
  shockwave(112-mx,my+8,16,64+i*32,un_sp"24,0,1")
end
end
if g>64 then
local r=rnd"ffff.ffff"
      srand"1"      
      for i=0,32 do
      local m=rnd()
      print("◆",rnd"128"+cos(rnd()+t/64)*16*m,(rnd"128"+t*m)%136-8,8+rand"4")
      end  
      srand(r)
end     
end
end

pal()
end
end end

-- title & footer
function f()
s=k==0 and "race result" or "championship ("..race_count.."/3)" 
for i=1,#s do   
?sub(s,i,i),x+60+i*4-#s*2,4.5+sin(i/16+t/24),7
end
if e.t>16 and t16<12 and not e.twc then
?un_sp"press ❎ to continue,24,119,7"
end   
end
apal"1"
for i=0,7 do
camera(dr[i*2+1],dr[i*2+2])
f()
end
mfunc"camera,pal"
f()    
end
e.x=128

end

function hmod(n,k)
while n>=k do n-=k*2 end
while n<-k do n+=k*2 end
return n
end

function wpa(e) 
local dx=e.next.x-e.x
local dy=e.next.y-e.y
return atan2(dx,dy) 
end

function init_game()
local mus=split"4,25,33"
music(mus[rc1],0,8)

mfunc"memset,0x5f70,0,15"
map_width,map_dx,players,wps,mdrs,ents,shades,finish_count,space,smi,mute_win=map_ws[rc1],map_xs[rc1],{},{},solo and drs or drs_basic,{},{},0,race_count==2,1

-- map
mp=mke()
mp.dp,mp.⧗start=0,97

mp.dr=function()
map_pal(rc1)

local mpx,mpy,mpw,mph=max(cmx\8,0),cmy\8,win.ww/8+1,win.hh/8+1
mpw-=max(mpx+mpw-map_width,0)  
mph-=max(mpy+mph-32,0)  
map(mpx+map_dx,mpy,mpx*8,mpy*8,mpw,mph) 
scr_pal=race_count==1 and split"129,130,131,4,133,134,15,136,137,9,139,12,5,14,143,0"
end

mp.upd=function() 
-- bounce players
for i,a in ipairs(players) do for j=i+1,#players do
local b=players[j]
local dx,dy,lm=a.x-b.x,a.y-b.y,8
if abs(dx)<lm and abs(dy)<lm then
local dd=lm-sqrt(dx^2+dy^2)
if dd>0 then
col_hit(a,b,dd)
col_hit(b,a,dd)   
end   
end
end end

-- sort players
ysort(scores,"len")
local pos=1
for sc in all(scores) do 
if not sc.finish then
sc.pos=pos
--pl.tbl.pos=9-pos
end
pos+=1
end 


-- dust detector
for i=1,#players do
local e=players[1+(i+smi)%#players]
if e.thrust then
smi+=1
local x,y=e.x-cos(e.an)*4,e.y-sin(e.an)*4
if not fg(x/8,y/8,5) and not space then
local a,e=e.an+.5+rnd".2"-.1,mk_dust(x,y)   
impulse(e,a,rnd"3")
break   
end		  
end 
end

if finish_count>=#players then
finish_count=-1
wt(16,end_game)
end
end

-- waypoints hhh
local path=path[rc1]
for i=0,#path-1,2 do
local wp={
x=path[i+1],
y=path[i+2],
}
add(wps,wp)  
end

for i=0,#wps-1 do
local wp=wps[i+1]
wp.prev,wp.next,wp.id=wps[(i-1)%#wps+1],wps[(i+1)%#wps+1],i
end
for wp in all(wps) do
local aa,ab=wpa(wp),wpa(wp.prev)
local pa=ab+hmod(aa-ab,.5)/2+.25
wp.pa,wp.px,wp.py=pa,wp.x+cos(pa)*4,wp.y+sin(pa)*4
end
fwp=wps[1]

-- players
local pmax=8
for i=0,pmax-1 do
local f=function(n)
return chars[n*4+ships[i+1][n+1]]+0
end
local e=mke(16)  
e.x,e.y,e.upd,e.cl,e.nwp,e.drs,e.pcol,e.pid,e.z,e.lap,e.an,e.hid=fwp.x-(pmax-i-1)*12,fwp.y+(i%2*2-1)*4+2,upd_car,8+i,fwp.next,mdrs,pcol,i,un_sp"-1,0,0,true"
for sc in all(scores) do
if sc.id==i then
e.tbl,sc.ship,sc.frags,sc.death,sc.finish=sc,e,0,0
end
end
e.acc,e.steer,e.brake,e.cross,e.wcd,e.hull=f"0",f"1",f"2",f"3",f"4",f"5"

reset_weapon(e)
e.weap+=rand"3"-3
e.hull_max,e.dr=e.hull,function (e,x,y)
if e.⧗shield then
local f=e.⧗hit_shield and circfill or circ
f(x+3,y+3,5+t2,e.⧗hit_shield and 7 or 8)
end
--[[ show wp
if e.ttx then
spr(37,e.ttx-4,e.tty-4)
end
--]]
end	 
add(players,e)
end 

--
for w in all(windows) do
w.trg=players[w.sel+1]
w.trg.hum=w.pid
w.trg.weap/=2
end

--
if mode==2 then
for p in all(players) do
if not p.hum then
kl(p)    
end  
end
end 

--
if #windows<3 then
cast_shades(0,0,map_width,32)
end
-- inter
local e=mke()
e.dp,e.dr=10,function()

for w in all(windows) do
local h=w.trg


camera(-w.x,-w.y)
mfunc"spr,5,pal"
?w.trg.tbl.pos,1,1,h.cl

-- weapons	 
if h.weap<0 then
rectfill(w.ww-3,w.hh+h.weap-3,w.ww-8,w.hh-3,h.cl)
else	 
local x,y=w.ww-12,w.hh-12
rectfill(x-1,y-1,x+8,y+8,1)
--rect(x-2,y-2,x+9,y+9,t%2==0 and 7 or h.cl)
rect(x-2,y-2,x+9,y+9,8+t%3)
spr(112+h.weap,x,y)
end  

-- life
for i=1,h.hull do
pal(8,h.cl)
spr(6,3+i*2)
end

-- time
--[[
if mode==2 then
local s=gts(h.t)
print(s,2,win.hh-7,h.cl)
end
--]]

-- start count
if mp.⧗start then
local n,c=mp.⧗start\24,mp.⧗start%24/24
local y=w.hh/4+sin(n>0 and c/2 or c/4+.25)*8
if n*24==mp.⧗start then
if n>1 then
mfunc"sfx,7,-1,18,1"
else
mfunc"sfx,7,-1,19,5"
end
end 
for i=0,1 do 
apal"7"
if i==0 then
apal(11-n)
end
local x=w.ww/2-i-4
if n>0 then
palt(split"0b1011111011111111,0b1101110011111111,0b1111010011111111"[n])
spr(57,x,y-i)
pal()
else
spr(58,x-8,y-i,3,1)
end
pal()
end
end
end
end
end

function out_win(e)
local x,y,m=e.x-cmx,e.y-cmy,8
return x>win.ww+m or y>win.hh+m or x<-m or y<-m
end


function mk_dust(x,y)
local e=mke(7,x-4,y-4)
e.drs,e.scl,e.z,e.vz,e.hid,e.frict,e.life=mdrs,un_sp"13,1,-1,true,.95,16"
e.upd=function()
e.fr=15-e.life/2
end 
return e
end


function cast_shades(sx,sy,xmax,ymax)
local a=split"-1,0,0,-1,-1,-1"
for x=sx,xmax-1 do for y=sy,ymax-1 do
local k=x..","..y
if shades[k] then
kl(shades[k])
end
if not fg(x,y,0) then
local tl
for i=0,2 do
local nx,ny=x+a[1+i*2],y+a[2+i*2]
if fg(nx,ny,0) then
tl=42+i
end
end 
if tl then
local e=mke(tl,x*8-1,y*8-1)
shades[k],e.dr,e.hid,e.nfr=e,drs,true,true

end   
end 
end end

end

function pcol(x,y)
return fg(x/8,y/8,0)
end

function shockwave(x,y,ra,rb,t,pl,hl,light)
local e=mke(0,x,y)
e.life,e.hole,e.mpl=t,hl or .6,8

e.dr=function(e,x,y)
local c=e.life/t
local f,cl=c>e.hole and circfill or circ,sget(c*e.mpl,pl)
f(x,y,ra+(rb-ra)*(1-c*c),cl)

if light then  
local f=function(x)
return x+rnd"20"-10
end  
local x,y=f(x),f(y)
for i=0,5 do
local nx,ny=f(x),f(y)
line(x,y,nx,ny,7)
x,y=nx,ny
end
end



end
return e 
end


function ysort(a,s)
for i=1,#a do
local j=i
while j>1 and a[j-1][s]<a[j][s] do
a[j],a[j-1]=a[j-1],a[j]
j-=1
end
end
end


function rectshade(ax,ay,bx,by)
for x=ax,bx do 
for y=ay,by do
local cl=sget(8+pget(x,y),1)
pset(x,y,cl)
end 
end
end


function drs_basic(e)
if out_win(e) then
return
end
apal(e.scl or 1)
spr(e.fr,e.x+e.drx,e.y+e.dry)
pal()
end

function drs(e)
if out_win(e) then
return
end

for dx=0,e.ww-1 do for dy=0,e.hh-1 do
local x,y,px,py=e.x+dx,e.y+dy,e.fr%16*8,e.fr\16*8
local pcl=sget(px+dx,py+dy)
if pcl>0 then  
x+=1+e.drx
y+=1+e.dry
local gc=pget(x,y)
if gc>0 then
pset(x,y,pcl==15 and (gc<6 and 0 or sget(8+gc,2)) or sget(8+gc,1))
end
--pset(x,y,pcl==15 and 0 or sget(8+pget(x,y),1))
end  
end end
end

function apal(n)
for i=0,15 do pal(i,n) end
end

function col_hit(a,b,dd)

local dx,dy=a.x-b.x,a.y-b.y
local an=atan2(dx,dy)
dx,dy=cos(an)*dd,sin(an)*dd

local wa,wb=a.⧗shield and 100 or 1,b.⧗shield and 100 or 1
local wc=wb/(wa+wb)
pmov(a,dx*wc,dy*wc)

if a.⧗shield then  
a.⧗hit_shield=3
return
end


local dv=sqrt((a.vx-b.vx)^2+(a.vy-b.vy)^2)
if (dv>2 or b.⧗shield) and not a.⧗hit then
sfx(8,-1,rand"4",1)
hit(a,b.⧗shield and 2 or 1,b)
end  

-- shield bounce
if b.⧗shield then
impulse(a,an,2)
end

a.vx+=dx*wc/2
a.vy+=dy*wc/2
end

function hit(e,n,from)
if e.⧗shield then
e.⧗hit_shield=3
else
e.⧗hit,e.⧗burn=8,10+n*6
if not e.tbl.finish then
e.hull,e.killer=max(e.hull-n,0),from
end	 
end
end

function dist(a,b,c,d)
return sqrt((a/100-c/100)^2+(b/100-d/100)^2)
end

function fg(x,y,fl)

if x>=0 and y>=0 and x<map_width and y<32 then
return fget(mget(x+map_xs[rc1],y),fl)
end
end

function upd_car(e)
function bh(n) return bhv[n+e.pid*3] end


local tx,ty,px,py,road=e.nwp.x,e.nwp.y,e.x/8,e.y/8
local road,heal_pad=fg(px,py,5),fg(px,py,3)
if road and e.dp>-1 then
--gpp
local w=e.nwp
local d1,d2,d=dist(e.x,e.y,w.x,w.y),dist(e.x,e.y,w.px,w.py),dist(w.x,w.y,w.px,w.py)  
local t=(d1*d1-d2*d2)/d+d
t/=2
local al=mid(-bh(3),t/d,bh(3)) -- -4
tx,ty=w.px*al+(1-al)*w.x,w.py*al+(1-al)*w.y
e.offroad,e.dp=0,1
elseif space then
e.offroad+=1
if e.offroad>=48 then
e.dp,e.drs=-1
end
if e.offroad>=80 then
explode(e,true)
return
end  
end

e.ttx,e.tty=tx,ty

local dx,dy=tx-e.x,ty-e.y
local dd,sd=sqrt(dx^2+dy^2),gside(e.nwp.x,e.nwp.y,e.nwp.px,e.nwp.py,e.x,e.y)
if sd>0 or (e.nwp!=fwp and dd<10) then
if e.nwp==fwp then
e.lap+=1   
if e.lap==3 then
e.tbl.finish=true
finish_count+=1
end
end
e.nwp,dd=e.nwp.next,128
end


--
e.spd,e.thrust=sqrt(e.vx^2+e.vy^2),false


-- turning
local an=atan2(dx,dy) 
local tsp=e.spd+2
an=atan2(cos(an)*tsp-e.vx,sin(an)*tsp-e.vy)

local da=hmod(an-e.an,.5)

if e.⧗roll then
e.an+=e.⧗roll/128
else
e.an+=mid(-e.steer,da,e.steer) 
end

-- 
local shoot 
if not e.hum or e.tbl.finish then  
-- control
e.thrust=abs(da)<bh(1) and e.spd<sqrt(dd)/bh(2) and not (heal_pad and e.hull<e.hull_max/2 and e.lap<3-1)
-- fire
function e:aim(tda_mind_maxd)
local tda,mind,maxd,res=un_sp(tda_mind_maxd)
for pl in all(players) do if pl!=e then
local dx,dy=pl.x-e.x,pl.y-e.y
if abs(dx)<maxd and abs(dy)<maxd then
local da=hmod(atan2(dx,dy)-e.an,.5)
if abs(da)<tda then
  local dd=sqrt(dx^2+dy^2)
  if dd<mind then
  return
  end  
  if dd<maxd then
  res=true
  end
end
end
end end
return res
end

local eweap=e.weap
if eweap==0 then
shoot=e:aim".02,16,60"
elseif eweap==1 then
shoot=road and e:aim".12,0,32"
elseif eweap==2 then
shoot=e:aim".12,0,32"
elseif eweap==3 then
shoot=dd>40 and abs(da)<.05
elseif eweap==4 then
shoot=e:aim".5,0,32"
elseif eweap==5 then
shoot=not e:aim".12,0,32"
elseif eweap==6 then
shoot=#zone(e,24)>=1 or (e.⧗shocked and e.⧗shocked<42)
end
else
e.thrust,shoot=btn(❎,e.hum),btnp(🅾️,e.hum) and e.weap>=0
end

e.thrust=e.thrust or e.⧗boost
if (mp.⧗start and mp.⧗start>24) or e.⧗shocked then
e.thrust=false
else
--dash pad
if fg(px,py,7) then
e.⧗boost=12
end
end

-- thrust
if e.thrust then
e.vx+=cos(e.an)*e.acc
e.vy+=sin(e.an)*e.acc 
end

-- weapon
if shoot then
if e.weap==0 then
fire_mis(e,0) 
elseif e.weap==1 then
e.minecount,e.last_mine=3
elseif e.weap==2 then
e.⧗machinegun=80
elseif e.weap==3 then
e.⧗boost=12
elseif e.weap==4 then
e.⧗shield=240
elseif e.weap==5 then
fire_mis(e,1) 
elseif e.weap==6 then
e.⧗shocked=nil
mfunc"sfx,6,-1,2,12"
shockwave(e.x,e.y,un_sp"32,32,6,5,0.25,true")

local a=zone(e,32)
for p in all(a) do
if not p.⧗shield then
p.⧗shocked=48
end
end
end

reset_weapon(e)
end

-- boost
if e.⧗boost then
e.vx+=cos(e.an)*.5
e.vy+=sin(e.an)*.5
end

-- frict
local aif= e.hum and .98 or .97-e.lap*.015
e.frict=e.thrust and aif or e.brake
if not road or fg(px,py,1) then
e.frict=e.cross
end 


-- bonus
if e.weap<0 and t%24==0 then
e.weap+=1
if e.weap>=0 then   
e.weap=rnd(sweap[e.pid+1])
--e.weap=0
end
end

-- mine drop
if e.minecount then
local l=e.last_mine
if not l or dist(l.x,l.y,e.x,e.y)>.16 then
mfunc"sfx,8,-1,8,1"
l=mke(33,e.x,e.y,0)
l.from,l.wp,l.cl,l.drx,l.dry,l.br,l.dmg=e,e.nwp,e.cl,un_sp"-3,-3,5,3"
l.upd=function()
if not l.⧗shocked then
chk_blast(l)
end
if not l.life and l.t>48 and #players>0 and scores[1].ship.nwp.prev==l.wp then
l.life,l.blk=48,24
end    
end      
e.last_mine=l
e.minecount-=1
if e.minecount==0 then
e.minecount=nil
end
end
end

--machinegun
if e.⧗machinegun and t%3==0 then
mfunc"sfx,6,-1,0,1"
local ox,oy,p=e.x,e.y,mke(0,e.x,e.y)
p.vx,p.vy,p.life=cos(e.an)*5,sin(e.an)*5,16
p.upd=function()
ox,oy=p.x,p.y
for pl in all(players) do
if pl!=e and ecole(pl,p,4) then
hit(pl,1,e)
kl(p)
return
end
end
end  

p.dr=function(e,x,y)
line(ox,oy,x,y,7)
end  
end

-- frame
e.drx,e.dry,e.fr=-3,-3,128+e.pid*16+flr((e.an*16+.5)%16)
e.z+=(-e.spd*2-e.z)*.15

-- sfx
if e.hum then
poke(0x3200,min(e.spd\0.0625,63)+128)
poke(0x3201,3)
mfunc"sfx,0,0,0,1" 
if e.thrust then
mfunc"sfx,9,1,0,1"
end  

end

-- score
e.tbl.len=e.lap*500+e.nwp.prev.id*5-dd/100

-- explode
if e.hull==0 then
explode(e)
end

-- healing
if e.hull<e.hull_max and t8==0 and heal_pad then
e.hull+=1
e.⧗heal=4
if e==h then mfunc"sfx,7,-1,13,5" end
end
end




function zone(e,r)
local a={}
for p in all(ents) do
if p!=e and p.cl and dist(p.x,p.y,e.x,e.y)<=r/100 then
add(a,p)
end
end
return a
end

function reset_weapon(e)
e.weap=-e.wcd
if not e.hum then e.weap*=2 end
end

function respawn(e,t)
if t>0 then

e.x,e.y=e.nwp.prev.x,e.nwp.prev.y  

wt(24,respawn,e,t-1)  

local cl,x,y,tm=e.cl,e.x,e.y,mke()
tm.dr=function(e)
?t,x-1,y-2,cl
circ(x,y,27-e.t,cl)
end
tm.life=24
else
e.hull,e.vx,e.vy,e.offroad,e.dp,e.killer,e.⧗roll=e.hull_max,un_sp"0,0,0,1"
add(ents,e)
add(players,e) 
end
end

function explode(e,fall)

kl(e)

--e.dead,e.⧗hit=true
e.⧗hit=nil
local x,y=e.x,e.y
e.tbl.death+=1

if e.killer then
e.killer.tbl.frags+=1
end

-- respawn
wt(24,respawn,e,3)

if fall then
return
end

kl(e)
mfunc"sfx,7,-1,24,8"

--
mp.⧗shk=8
-- ground mark
local p=mke(46,x-8,y-8,0)
p.drs,p.invis,p.ww,p.hh,p.life=drs,un_sp"true,16,16,240"
p.upd=function()
if rand(p.life)>160 then
mk_dust(x+rand"5"-2,y+rand"5"-2)
end
end
p.dr=function()
pset(x,y,8+t8)
end
-- shockwave
shockwave(x,y,un_sp"8,16,16,0")
shockwave(x,y,un_sp"8,96,8,0,1")

--
boom(x,y,8)
end

function boom(x,y,pmax)
-- flames
for i=0,7 do
x+=rnd"6"-3
y+=rnd"6"-3
local e=shockwave(x,y,8,1,16+rand"32",0,0)
e.dp=2
e.vy=-rnd()
end

-- parts
for i=1,pmax do
local an,p=i/pmax,mke(38,x,y,2)
p.vz,p.we,p.frict,p.ww,p.hh,p.z=-3-rnd"4",un_sp".2,.96,4,4,-1"
impulse(p,an,2+rnd"4")
p.life,p.drs=24+rand"48",mdrs
p.flx=rnd()<.5
if i>4 then
p.⧗burn=8+rand"16"
end
end
end

function fire_mis(sh,mt)
mfunc"sfx,7,-1,0,2"
local e=mke(0,sh.x,sh.y+sh.z)
local spd=sh.spd+2
e.vx,e.vy=cos(sh.an)*spd,sin(sh.an)*spd 
e.from,e.dmg,e.br=sh,5,8
e.dr=function(e,x,y)
circfill(x,y,1+t2*2,sget(125+t2,8+e.missile))
end
e.missile,e.pcol=mt,pcol

if mt==0 then
e.frict,e.life=1.05,60  
return
end

-- homing
e.dmg=3
e.upd=function(e)

for sc in all(scores) do
local p=sc.ship
if p!=sh then
local dx,dy=p.x-e.x,p.y-e.y
local ta,ca=atan2(dx,dy),atan2(e.vx,e.vy)
ca +=hmod(ta-ca,.5)*.05
e.vx,e.vy=cos(ca)*3,sin(ca)*3
break
end
end
end
end

function impulse(e,a,spd)
e.vx+=cos(a)*spd
e.vy+=sin(a)*spd
end


function chk_blast(e)
for pl in all(players) do
if pl!=e.from and ecole(pl,e,6) then
blast(e)
end
end
end

function trail(x,y,cl,prev)
local e=mke(0,x,y,1)
e.hid,e.life,e.p=true,8,prev

if prev then e.dr=function(e,x,y)
local ex,ey=e.p.x,e.p.y
if e.life<8 then
local c=e.life/8
ex,ey=x+(ex-x)*c,y+(ey-y)*c   
end  

local k=e.double and 1 or 0
for dx=-k,k do for dy=-k,k do
local cl=sget(120+e.life,cl)
line(x+dx,y+dy,ex+dx,ey+dy,cl)
end end 
end end

e.nxt=function()
e.p=nil
end
return e
end


function ecole(a,b,r)
local dx,dy=a.x-b.x,a.y-b.y
if abs(dx)<r and abs(dy)<r then
return sqrt(dx*dx+dy*dy)<r
end
end

function blast(e)
local r=e.br
mfunc"sfx,8,-1,4,4"

kl(e)
-- collision 
for pl in all(players) do
local dx,dy=pl.x-e.x,pl.y-e.y

if abs(dx)<r+3 and abs(dy)<r+3 then
local dd=sqrt(dx*dx+dy*dy) 
if dd<r+3 and not pl.⧗shield then
local an,imp=atan2(dx,dy),(r+3-dd)/2
pl.vx+=cos(an)*imp
pl.vy+=sin(an)*imp
pl.⧗roll=e.dmg*4
hit(pl,e.dmg,e.from)
end 
end
end

-- fx
shockwave(e.x,e.y,r+2,r+8,10,0)
shockwave(e.x,e.y,r+8,un_sp"48,16,3,1")
for i=1,16 do
local f=function()
local e=shockwave(e.x,e.y,2,4,4+rand"8",0,0)
e.we=-.1
e.x+=rnd"16"-8
e.y+=rnd"16"-8
end
wt(i,f)
end
end

function fad(n,nxt) 
local sn=fd 
local f=function(e) 
fd=sn+(n-sn)*e.t/16
end 
loop(f,16,nxt)
end

function fade_to(nxt)
fad(8,function()
ents={}
mfunc"reload,0,0,0x3100"
nxt()
fad"0"
end)
end

function rand(n)
return flr(rnd(n))
end

function dr_flame(e)
if e.thrust then
spr(36+t2,e.trx-3,e.try-3)
end
end

function dre(e)
if e.invis or (e.blk and e.life<e.blk and t42) then
return
end

if e.hid and out_win(e) then
return
end

local fr,x,y=e.fr,e.x+e.drx,e.y+e.dry+e.z

-- sel
if e.sel and t42 then
fr+=1
end

if e.⧗hit and t2==0 then
apal"8"
end

if e.⧗heal then
apal"11"
end

if e.cl then
pal(8,e.cl)
pal(2,sget(e.cl-8,2))
end

if e.weap and e.an%1>=.5 then
dr_flame(e)
end  

if e.offroad>=12 then
for i=0,15 do
pal(i,sget(8+i,min(e.offroad/12,5)))
end

end

-- draw
if fr>0 and not e.nfr then
spr(fr,x,y,e.ww/8,e.hh/8,e.flx)
end
if e.dr then e.dr(e,x,y) end

--
if e.pid and e.an%1<.5 then
dr_flame(e)
end 
if e.⧗shocked then for i=0,e.⧗shocked>>3 do
line(x+rand"8",y+rand"8",x+rand"8",y+rand"8",12)
end end

pal()
end

function starfield(h)
local r,starpal=rnd"ffff.ffff",mspl"1&7,1&7,13,1&7,7,13,1"
srand"1"
for i=1,h/2 do
local siz,x,y=rand"4"+1,rand"256",rand(h)
if win then
x-=cmx*siz/5
y-=cmy*siz/5
else
x+=t*siz\16
end
x,y=x%138-10,y%138-10

pal(starpal[siz])
palt((split"0xbfff,0x9fff,0x8fff,0x87ff")[siz])
spr(99,x,y)
end
pal()
srand(r)
end

-->8
-- engine
function mke(fr,x,y,dp)
return add(ents,{
fr=fr or 0,
x=x or 0,
y=y or 0,
z=z or 0,
dp=dp or 1,
drx=0,dry=0,
t=0,offroad=0,stress=0,
vx=0,vy=0,vz=0,we=0,frict=1,
ww=8,hh=8
})
end

function upe(e)
e.t=e.t+1

if e.upd then e.upd(e) end

-- phys
if e.pcol then
pmov(e)
else
e.x+=e.vx
e.y+=e.vy  
end

e.vz+=e.we
e.z+=e.vz

if e.z>0 then
e.z*=-1
e.vz*=-.75
end
e.vx*=e.frict
e.vy*=e.frict
e.vz*=e.frict

-- counters
for v,n in pairs(e) do
if sub(v,1,1)=="⧗" then
n-=1
e[v]=n>0 and n or nil
end
end

-- trail
if e.pid then 
if e.thrust or e.⧗boost then 
e.trx,e.try=e.x-cos(e.an)*4,e.y+e.z-sin(e.an)*4 
e.ptr=trail(e.trx,e.try,e.pid,e.ptr)
e.ptr.double,e.ptr.dp=e.⧗boost,e.dp
else
e.ptr=nil
end
end 

-- missile
if e.missile then 
chk_blast(e) 
e.ptr=trail(e.x,e.y,8+e.missile,e.ptr)
end

-- burn
if e.⧗burn then
local sz=mid(1,e.⧗burn/6,2)
local e=shockwave(e.x+rand"3"-1,e.y+e.z+rand"3"-1,sz,sz,4,0,0)
e.mpl=6
end

-- life
if e.life then
e.life-=1
if e.life<=0 then
kl(e)
end 
end
end

function kl(e)
del(ents,e)
del(players,e)
if e.nxt then
e.nxt()
e.nxt=nil
end
end

function loop(f,t,nxt)
local e=mke()
e.upd,e.nxt,e.life=f,nxt,t
end

function wt(t,f,a,b,c)
local e=mke()
e.life,e.nxt=t,function() f(a,b,c) end
end

function pmov(e,dx,dy)
if ecol(e) then
return
end

local bnc=not dx

if bnc then
dx,dy=e.vx,e.vy
end

tpx,tpy=nil
local clx,cly

e.x+=dx
while ecol(e) do
e.x-=sgn(dx)
clx=true
end 
e.y+=dy 
while ecol(e) do
e.y-=sgn(dy)
cly=true
end

if bnc then
if clx then
e.vx*=-.5
end
if cly then
e.vy*=-.5
end
if e.missile and (clx or cly) then
blast(e)
end	

if tpx and fg(tpx,tpy,0) then
local dmg=sqrt(dx*dx+dy*dy)\1
if dmg>=2 or e.stress>=30 then
mset(tpx+map_dx,tpy,32)
cast_shades(tpx-1,tpy-1,tpx+2,tpy+2)
boom(tpx*8+4,tpy*8+4,3)
mfunc"sfx,8,-1,4,4"
if e.pid then
hit(e,dmg)
end
else
e.stress+=10
end	  
end
if e.stress>0 then	 
e.stress-=1
end

end
end

function ecol(e,dx,dy)
dx,dy=dx or 0,dy or 0 
local k,a=.25,split"-.25,-.25,-.25,.25,.25,.25,.25,-.25"
for i=0,3 do
local x,y=e.x+a[i*2+1]*(e.ww-1)+dx-3,e.y+a[i*2+2]*(e.hh-1)+dy-3
if e.pcol(x,y) then
tpx,tpy=x\8,y\8
return true 
end
end
end

function _update()
t+=1
t42,t16,t8,t2=t%4<2,t%16,t%8,t%2
foreach(ents,upe)
end

function _draw()
cls(race_count==2 and 0 or 6)
if windows and not mute_win then
foreach(windows,function(w)
win,h,bcl=w,w.trg,7
if not test_win then
clip(w.x,w.y,w.ww,w.hh)
end

if h then
bcl=h.⧗hit and 8 or 7
if h.tbl.finish then
cmx,cmy=fwp.x-w.ww/2,fwp.y-w.hh/2
else
  local m=race_count<2 and 32 or 128
  cmx,cmy=mid(-m,h.x-w.ww/2,map_width*8+m-w.ww),mid(-m,h.y-w.hh/2,256+m-w.hh)
end
-- bg
mfunc"camera,0,0"
--				color(race_count==2 and 0 or 6)
--			 mfunc"rectfill,0,0,127,127"
if space then 
starfield"128"
end

-- camera
camera(cmx-w.x,cmy-w.y)
end

for i=-1,2 do  
dr_ents(i)
end
camera()

rect(w.x,w.y,w.x+w.ww-1,w.y+w.hh-1,bcl)
end)
clip()
else
for i=0,2 do  
dr_ents(i)
end
end

-- inter
camera()
dr_ents(10)
camera()

-- minimap
if windows and #windows==8 then
map_pal(rc1)
mfunc"rectfill,43,43,82,82,6"
local factor=map_ws[rc1]/40
for i=0,31/factor do
local y=64+i-16/factor
tline(43,y,
    82,y,
    map_xs[rc1],i*factor,factor,0)
end
pal()
for p in all(players) do
pset(43+p.x/factor/8,64-16/factor+p.y/factor/8,p.cl)
end
end

-- fade
mfunc"clip,pal"
if fd>0 then
for layer=1,4 do
local c=(fd-layer+4)/16-.25
local sc,lc=-70*sin(c),split"13,5,1,0"[layer]
rectfill(0,0,127,sc,lc)
rectfill(0,127-sc,127,127,lc)
end
end

if scr_pal then
pal(scr_pal,1) 
end

end

function dr_ents(n)
for e in all(ents) do
if n==1 and e.drs then 
e.drs(e)    
end
if e.dp==n then dre(e) end
end
end
-->8
-- data

map_ws,map_xs,path,ships,sweap,chars,bhv,caracs,ship_names,s_desc,pp=split"32,40,56",split"0,32,72",mspl[[
129,17,199,17,215,17,228,24,233,38,226,53,212,58,149,58,133,63,128,77,130,122,141,135,160,145,208,144,225,149,231,162,232,211,228,228,215,237,169,234,121,213,99,213,83,229,22,229,13,211,12,185,18,173,32,175,45,181,62,181,73,168,73,154,67,144,51,135,22,79,20,40,25,24,40,17&
104,17,114,17,123,17,140,37,143,59,142,81,144,102,153,114,169,118,186,114,192,99,191,75,195,57,232,18,262,16,276,23,278,42,265,60,252,79,247,96,248,136,250,178,252,204,263,220,289,221,304,204,304,178,294,158,268,157,207,157,180,186,171,215,159,226,141,226,130,214,128,168,113,158,96,164,57,210,48,216,34,216,22,213,15,198,20,151,28,137,77,94,86,77,81,61,66,55,23,57,9,43,12,24,24,17&
280,168,293,168,305,170,313,181,315,199,307,218,290,228,267,228,169,228,134,230,97,233,66,231,43,223,27,206,22,184,24,156,29,128,25,103,17,78,20,54,34,41,51,35,67,37,81,44,91,61,81,84,85,114,113,124,144,129,184,127,206,120,220,92,229,80,247,72,266,82,276,101,294,108,312,96,329,82,343,76,357,85,359,104,359,150,359,197,367,215,381,224,402,225,417,210,422,192,422,96,419,76,413,61,399,44,376,30,325,26,275,26,249,25,214,16,192,11,174,16,162,32,160,67,155,100,152,140,158,159,178,168
]],mspl[[
2,2,3,3,3,3&
3,2,1,3,1,2&
3,3,1,2,2,1&
1,4,2,3,4,2&

3,4,3,1,2,3&
1,2,2,4,4,4&
4,1,2,3,3,1&
2,1,4,3,2,4
]],mspl[[
0,2,3,4&
0,3,3,4&
2,1,6,4&
0,2,1,1&

5,6,3,4&
0,5,2,1&
0,2,6,4&
5,6,6,3
]],split[[
.13,.15,.18,.21,
.012,.016,.02,.024,
.95,.93,.9,.86,
.6,.75,.85,.92,
20,12,8,6,
9,12,16,20,
]],split[[
.15,2.1,4,
.15,1.4,7,
.1,1,5,
.2,1.75,3,
.1,1.5,1,
.15,1.85,4,
.15,1.2,3,
.1,1.2,5,
]],split"accel,steer,brake,cross,fight,armor",split
[[ fireant
, caramelo
, lemo-8
, rodyle
, dolphish
, g. sigan 
, dark matt
, tb-system
]],split
([[colony worker
#848740241648,
and its only
licensed pilot
;wants to make
his owner
proud
;former racer.
her mind was
merged with
the ship's
system
;wants to
destroy ships
and maybe win
the race in
the process
;ocean planet's
#1 bodybuilder
and best paid
pilot
;special forces
tank expert.
very proud of
his facial
hair
;4d being.
very shy,
only appears
in special
occasions
;ultra-advanced
a.i. with an
old school
hardware
design
]],";"),mspl[[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2&
1,2,3,2,5,5,15,12,4,9,11,12,13,1,5,0&
1,1,3,5,5,5,7,11,13,6,11,12,13,1,3,0&
1,2,3,4,5,6,7,8,9,10,11,12,13,1,2,0]]
-->8
-- menu

function _init()
music"0"

ents,scores,eclr,hh,s,st,t,fd,race_count,rc1,mode={},{},split"0x1.5,0x11,0x1d,0xdd,0xd6,0x66,0x66,0x67,0x67",split"-10,-10,-10,-10,5,9,12,14,16,17,18,20,21,22,23,24,24,25,26,27,27,28,28,29,29,29,30,30,30,30,31,31,31,31,31,31,31,31,31,31,31,31","2222233299192222229999929911921122329192922232929232919292223292222223299199222329999929111999212232912922233299223291292223329922222329192222232999992911919921223299922223321992329992222332192222232912222233299999299919992122322929223339992232292922333999222223299222223321999992999992112223229222332192922322922233219222222322222223339999999229992211222232223332119922223222333211992222223222222332192999999222111122222333332119929222233333211992222222232223332119999999999911112222222222119929222222222211992933292222333332119999999999911111222222991199929292229299119992232222922922222119929292999991119932222229292333292922292999292232922329222991199929222929991119112322222292322222929222229292232929232922229292233332229999111911232292222329922329222922292223299223212222292233333322299911191123222922232929232992222222222322223299229222233222222292991111993222222223229223212922292222222233291922292233299192222999111111222292922222223299922222222222232291922292223299199222329911111122222922222333291929222222222922991929222922329192222232991111112222222229222291929222222222229292929222222232912222233299111111233332222292991929233332222222222223332922223299222223321911111133333322222292929233333322222222223222229222322222223339991111193222222222222929223222222222222223299223292223222222332199111199299192222222222233299192222222222329292329222232223332119911119199199222329222223299199922329222232292232122922333332119991111919192922232929222329192922232929222222232992229222222119999911191912922233299222232912922233299222223332919222292991199999991119199922223321992223299922223321992292222919222292929299999991111912929223339992222322929223339992222929919292222229299999999111119229222332192922223229222332192922222929292222222299999222211111132223332119922222232223332119922222229292222222222999299992111112333332119929222922333332119929222222222222333292299299119921111922222119929222222222222119929222222222222322222929929119992111122991192923333222922991199922222333292222329922329992919999211112929292923333332222222222222222222222922232929232999299999921111222292923322222222292222222222239922329223229223219992999921111122222223329919222292222222222232929232922222223299999922221111112222222329919922232922222222223229223212222333291999999999111111222922232919292223292922222222322223299229222291929999991111992222922223291292223329922333292222333291922292991929299999911229993222922329992222332199322222922222291922222292929292999999321111222222232292922333999329922329922991929222222929222929999221111122222222322922233219232929232929292929222222333333229999931111112223292223222333211993229223212222929222222332222222299993111111222329929233333211992922223299222222222292332991922222999211111122332929292222211992922333291922222222222232991992223299921111112233219292299119992929222291929222222229223291922222329992111111233399292222929292922292991929222222222292329122222332999921111123321992222229292222222292929222333322222232992222233219991211193321192222222222233329222929222233333229223222222233399999119999321192233329222232222292222222232222222222232222223321999991111121199232222292232992232922222233991922222222322233321199999111111999232992232923292923292222233291992223292223333321199999911111929223292923292322922321222223291922222329222222221199999991999929292322922321222222329922222329122222332992229911999999999211113222222222329922233329192222232992222233212922233329999999921111329222233329192922229192222223292222233399922232222299999992111132292922229192229299192922222322222223321929232992232999999211113292229299192922229292922222223222233321199223292923299999119999292222229292922222292922222222233333321199292322922321999991111192922222292922222222222222222222222221199292222222329999999111112922222222222222222222222222222229911999292222233329199999991111222223333222222222222333322222229299929292222922229199999999111122223333332222222222333333222222292929223333229299199999999911112223322222222222222332222222222222929223333332229292999992229111223329919222222222332991922222222222223322222222292999992999221122329919922232922232991992223292","00000333330333331003333333330033333333300333300033330333333333000033333330013333333333003333333330400000000000000000000000000000000003333303333310033333333300333333333103333300333303333333333000333333300133333333330133333333300404040000000000000000000000000000333333333333100333333333103333333331033333003333033331233330003333333301333333333301133333333340404440400000000000000000000000003333333333331033331133331033311333310333333033330333311333300033323333011333322222011333331111040445440404000000000000000000000333333333333110333311333113333113333103333333333303333113333000333113330113333222220113333333330040445444404000000000000000000003333133233331103331133331133331133331033333333333033333333330003333333301133332222101133333333330040445454444040004000000000000333331221333311333311333311333110333113333313333330333333333300333333333311333330000001133333333300000445465444040000000000000003333112213333113333103333113331033331133331133333303333333331003333333333013333300000011333331111400000404566544440400000000000333331100333331133311033311333310333311333311133333033331133330033331133330133333000000113333333333000000404566545440404000000003333310003333313333333333113333333333113333111333330333311333330333311333331133333333330133333333333004000404456545444404000000333331100033333133333333331133333333331033331111333303333113333303333111333311333333333301133333333330000040404454545454444040003333311000333331333333333311333333333310333310113333033330113333033331113333113333333333011333333333330000000404444444440404040022222100002222212222222222112222222222102222001122220222201122220222200122221122222222220012222222222200000000004040404040004004022221000022222022222222221022222222221022220001222202222001222202222001222201222222222200122222222222000000004000040000000000000222200000222220122222222210122222222210222200012222022220002222022220002222012222222221001222222222210000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",un_sp"0,8,0,1,0"
fad(0)
for i=1,8 do
local p={
id=i-1,
len=0,
pos=0,
frags=0,
death=0,
score=0,
}
add(scores,p)  
end
local ready
for i=0,4095 do
sset(i\64+64,i%64+64,tonum(sub(s,i+1,i+1))+4)
sset(i%128,i\128,tonum(sub(st,i+1,i+1)))
end

local sel,stp=0,0
local e=mke()
e.upd=function()
if btnp"5" then
if ready then
mfunc"sfx,0,-1,1,4"
stp+=1    
if stp==3 then
race_count=sel 
rc1,scr_pal=race_count+1    
elseif stp==2 then
mode=sel
if mode==0 then stp+=1 end
end
if stp==3 then
stp,e.upd=0
fade_to(goto_sel)
end    
end   
else
ready=true
end
local inc=function(n)    
sel+=n
sel%=3
mfunc"sfx,6,-1,1,1"
end
if btnp"2" then inc(-1)
elseif btnp"3" then inc(1)
elseif btnp"4" then
stp=max(stp-1,0)
mfunc"sfx,0,-1,5,2"
end

end

e.dr=function()
mfunc"cls,palt,0b0111000000000000"
pal(split"1,2,3,1,2,13,7,8,9,10,11,12,13,14,15,0")
spr(12,(500+t)\16%160-32,un_sp"40,4,2")



--stars
starfield"80"	

--earth
scr_pal=split"1,2,12,140,5,6,7,8,9,10,11,12,13,14,15,0"
mfunc"fillp,0xa5a5,line,0,106,178,80,1.3125,line,0,107,177,81,1.3125,line,0,108,176,82,17,line,0,109,175,83,17,line,0,110,174,84,0x14,line,0,111,173,85,0x14,line,0,112,172,86,0x44,line,0,113,171,87,0x44,line,0,114,170,88,0x43,line,0,115,169,89,0x43,line,0,116,168,90,0x33,line,0,117,167,91,0x33,line,0,118,166,92,0x33,line,0,119,165,93,0x36,line,0,120,164,94,0x36,line,0,121,163,95,0x37,line,0,122,162,96,0x37,line,0,123,161,97,0x37,line,0,124,160,98,119,line,0,125,159,99,119,line,0,126,158,100,119,line,0,127,157,101,119,line,0,128,156,102,119,line,0,129,155,103,119,line,0,130,154,104,119,line,0,131,153,105,119,line,0,132,152,106,119,line,0,133,151,107,119,line,0,134,150,108,119,line,0,135,149,109,119,line,0,136,148,110,119,line,0,137,147,111,119,line,0,138,146,112,119,rectfill,64,114,127,127,fillp,rectfill,0,127,127,127,7,pal"


local tt=t/90
function satel(c)
local r=(sin(tt-.25)*4+8)
for i=0,1 do
local rr=r*(1-i/5)
circfill(sin(tt)*50+60+rr/2,sin(tt)*-10+78+rr/2,rr,split"8,2,1,0"[5-i-r\3.5])
end
end

satel"2"

--moon
local xx=t/10
for i=-31,31 do
local hgt=hh[40-abs(i+6)]
for j=-31,31 do
if j==hgt-20 then
mfunc"pal,6,13"
end
if j==hgt-16 then
pal(7,6)
end
if j==hgt-12 then
pal(13,5)
end
if j==hgt-8 then
pal(5,1)
end
s=(i*i+j*j)/1444
if s<.7 then
local ss,px,py=s*s-.51,i+xx,j
pset(i+63,j+78,
sget(
flr(px+i*ss)%64+64,
flr(py+j*ss)%64+64
)
)
end
end
pal()
end

if (tt+.25)%1<.5 then
satel"8"
end	
--title text
mfunc"pal,3,13,palt,0b1000110000000000,spr,0,14,20,13,2"


-- menu
if stp>0 then
mfunc"rectfill,32,96,96,124,0"
local a=split"tournament,single race,practice,aristarchus,mare nectaris,orbital path"
for i=0,2 do
local s=a[i+stp*3-2]
if not s then
?stp,un_sp"0,0,7"
end   
?s,64-#s*2,100+i*8,sel==i and 7 or 13
end
end
end
end

function goto_sel()
music"14"
cmx,cmy,windows,pool,mute_win=0,0,{},{}
add_window"0"


for i=0,7 do add(pool,i) end

local chk,ready=true,{}
for i=1,7 do add(ready,i) end

-- loop
local f=function()
for k in all(ready) do
if btnp(❎,k) then
add_window(k)
del(ready,k)
end  
end
local go=chk
for w in all(windows) do
go=go and w.ready
end
if go then
for w in all(windows) do
scores[w.sel+1].hum=w.pid
end 
chk=false
wt(16,fade_to,init_game)
end
end
loop(f)
end
-->8
-- tools
function gside(ax,ay,bx,by,x,y)
return sgn((bx-ax)*(y-ay)-(by-ay)*(x-ax))
end

function mfunc(s)
local s,i1,i2,arg=split(s),1,1,{}
while i2<=#s do
i2+=1
if _ENV[s[i2]]~=nil
or i2>#s
then
_ENV[s[i1]](unpack(arg))
i1,arg=i2,{}
else
add(arg,s[i2])
end
end
end


-->8
-- add_window
function shift(a)
return del(a,a[1])
end

function add_window(pid)
local wn={
pid=pid,
sel=0,
sstat=split"0,0,0,0,0",
}
wn.sstat[0]=0

add(windows,wn)
solo=#windows==1
if not solo then
mfunc"memset,0x5f70,0,15"
end

wd=split"0,0,128,128,0,0,64,128,64,0,64,128,0,0,64,64,64,0,64,64,0,64,128,64,0,0,64,64,64,0,64,64,0,64,64,64,64,64,64,64,0,0,64,42,64,0,64,42,0,42,64,42,64,42,64,42,0,84,128,42,0,0,64,42,64,0,64,42,0,42,64,42,64,42,64,42,0,84,64,42,64,84,64,42,0,0,64,42,64,0,64,42,0,42,64,42,64,42,64,42,0,84,42,42,42,84,42,42,84,84,42,42,0,0,42,42,42,0,42,42,84,0,42,42,0,42,42,42,84,42,42,42,0,84,42,42,42,84,42,42,84,84,42,42"
local bi=-1
for i=1,#windows-1 do
bi+=i
end 
for i,w in ipairs(windows) do
local id=(bi+i)*4  
w.x,w.y,w.ww,w.hh=wd[id+1],wd[id+2],wd[id+3],wd[id+4]
end

-- selector  
local sl=mke()
sl.dc,scr_pal=0
sl.upd=function()  
sl.dc*=.75  
local inc=function(n)
if #pool>0 then 
wn.sel=(wn.sel+n)%#pool  
sl.dc+=n
mfunc"sfx,6,-1,1,1"
end
end
if not wn.ready then
if btnp(1,wn.pid) or btnp(🅾️,wn.pid) then 
inc(1)
elseif btnp(0,wn.pid) then 
inc(-1) 
elseif btnp(❎,wn.pid) and sl.t>24 then
wn.sel,wn.ready=pool[1+wn.sel],true
del(pool,wn.sel)
mfunc"sfx,7,-1,2,9"
end
end
end 

sl.dr=function()
function sel_typ(k)
return wn.ready and wn.sel or pool[(wn.sel+k)%#pool+1]
end

if win!=wn then
return
end

camera(-win.x,-win.y)
rectfill(0,0,win.ww,win.hh,1)

pal()
for i=1,8 do
fillp(split"0,0x1000,0x1040,0x1414,0x5a5a,0xbebe,0xfefb,0xfeff,0xffff"[i])
rectfill(0,i*3-3,127,i*3,0x10)
end
fillp() 

local hcol=win.sel
local cl,mdx,mdy,km=8+hcol,win.ww/2,#windows<=2 and 36 or win.hh/2,wn.ready and 0 or #pool

-- ships
for k=-km,km do
for i=0,1 do
hi=sel_typ(k)
local cl=8+hi%8
pal(8,cl)
pal(2,sget(8+cl,1))
if i==0 then
apal(k==0 and cl or 0)    
end
local x,y=mdx+(k+sl.dc)*24-4,mdy-i*(8.5+cos(t/24)*2)
y+=cos((x-mdx)/128)*16-12    
local fr=128+hi*16
if not wn.ready then
fr+=t/2%16
end
spr(fr,x,y)
pal()

end
end  

--
if #windows<=2 then
s=mfunc"rectfill,0,53,127,127,5,rectfill,0,53,127,53,13,rectfill,0,90,127,127,6,rectfill,1,56,2,126,13,rectfill,3,57,3,125,13,rectfill,127,55,127,127,13,rectfill,126,56,125,126,13,rectfill,124,57,124,125,13,line,1,55,3,57,1,line,126,55,124,57,1,rectfill,4,58,123,125,0"

for i=0,1 do
if solo then
?ship_names[hcol+1],23,68-i,13-i*6
end
?s_desc[hcol+1],65,69-i,1+i*12
end

local xx,yy
if solo then
--mugshot
spr(72+hcol%4*2+hcol\4*32,7,62,2,2)
mfunc"poke,0x5f5f,0x10,poke,0x5f77,0xc0,memset,0x5f78,0xff,2"	  
pal(mspl"1,2,130,136,5,6,7,8,142,10,128,129,13,141,15,0&1,132,129,4,5,6,7,137,9,10,11,12,13,14,15,0&1,129,3,130,5,6,7,8,138,10,11,12,13,133,135,0&1,2,3,131,5,6,7,129,9,10,11,130,13,139,4,0&1,130,133,4,5,6,7,2,141,128,140,12,13,14,15,0&1,129,128,4,5,6,7,130,141,132,133,142,13,143,15,0&1,130,3,141,5,6,7,8,9,10,142,143,13,14,15,0&1,2,141,4,5,6,7,134,9,129,133,142,13,143,15,0"[hcol+1],2)

--medals
for o=0,2 do
for i=1,4 do
local lvl=dget(hcol*4+i-1)
pal(pp[lvl+1])
if o<2 then
apal(o)
end
spr(i==4 and 39 or 18,68+i*11-o,46,i\4+1,2)
pal()
end
end
else
xx,yy=camera(-win.x+60,-win.y+43)
end
for i=1,4 do
if i<=2 then
?"weapons",80,106-i,19-i*6
end
rect(55+i*13,112,66+i*13,123,1)
spr(112+sweap[hcol+1][i],57+i*13,114)
end
camera(xx,yy)

--stats
for i=0,5 do
local y=84+i*7
?caracs[i+1],7,y,7
local n=ships[1+hcol][1+i]
wn.sstat[i]=(wn.sstat[i]+n)/2
if (wn.sstat[i]%1>.95) wn.sstat[i]=ceil(wn.sstat[i])
sspr(119+n/1,10,1,5,28,y,wn.sstat[i]*8,5)
end

end
--if not solo then
-- name
local s=sel_typ"0"
local sn=solo and "" or ship_names[s+1]
if wn.ready then
sn=t42 and"" or "ready"
end	  
?sn,mdx-#sn*2,4,s+8
--end
end
end
-->8

menuitem(1,"double control",
function()
obtn,obtnp,km=btn,btnp,mspl[[4,7,7,7,4,5&0,7,7,7,0,1]]
local function b(k,p)
p=p or 0
return km[p\4+1][k+1],p%4
end
btnp=function(k,p)
return obtnp(b(k,p))
end
btn=function(k,p)
return obtn(b(k,p))
end
menuitem(1)
end
)



function map_pal(m)
if m==3 then
mfunc"palt,6,true"
pal(split"8,14,3,4,5,0,7,8,6,7,11,12,13,1,15,0")
for i=1,4 do
pal(split"15,11,4,3"[i],split"9,7,10,15"[(i-t\1.5)%4+1])
end
else
mfunc"pal,14,1"
end
end