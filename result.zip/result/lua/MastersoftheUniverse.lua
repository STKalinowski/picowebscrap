--mASTERS OF THE uNIVERSE v1.5
--THE rOBOz, FOR dORIAN

bg_cmd={"\"&Oひ◆もオ&Ni🅾️⬇️⁴&No🅾️rモ&Ns🅾️vウ&Nw🅾️zな&N{🅾️~🅾️&fh🅾️◆\0&N}🅾️ア\0&u∧v❎³&oW○g\0'qo}▒³'n█v♪³&Oち◆を⁵&Oた◆の 'gそあの▮&Nに🅾️ま…&Mむ♪サや'pろ~わP'Rれbゃ`'Xよhわ∧$NNNNっ'y}🐱★\0'|u♥✽\0'vら░るへ'Lつころハ'Mつあらわ&N~e★きF&あVこ\\²$VN♪Vそ&へ⬅️イ▥@&ね~っ◆…#▒くうく¹#⬇️こあこ■#░し▥しa#█かえか□#⬇️えあえB#Qる_ろ\0#_をfる\0'れゆイりf#pわtり\0#🐱を⬇️り\0#…り∧ん\0#かれせん\0'FめSり●#▥よおろ\0#うるけら\0#とるめり\0#はれほを\0#}る⬅️れ\0#ゃやオら\0#RもVら\0#TゆOよ\0#mらqら\r#sりoわ⁶#●り◆り\r#◆り★ろ⁶'▒ぬ⌂は}&あVう\\²",
"&'H5カc⁷'H<カj7'HAカow'DQス{ツ'D@スuん#N~W⬅️G#_~g🅾️⁷#○~▒☉7'🐱j▤{²'🐱h▤y⁸'🐱g▤x	$m[nN✽&Nむ🅾️わ\0F'{░サ❎♥&E☉ケめ³'{▒サ⬆️シ'v░カˇQ'7○ˇあシ'う░❎かP'9⬇️❎おQ'7♪ˇそs'|⬅️イさ⬇️&M⬆️イせ³'E◆ケもコ'E♪ケむメ\"S◆ウへ●'sいさせテ&るにケゆ³'ははっる²&れぬコよ\0'のひっれ\0\"e∧はぬ	\"f∧ひぬZ'Nはqれ²'Nひpわ\0\"p▥せち:#웃さ}ひJ#★こまちZ#🅾️くやいY#j∧x▤I#n⬆️y∧:#z▥☉か\n#z∧ˇう	'hやへわね'kゆはろメ'xらする😐#Q🅾️V▤G#ゆ♪むˇG#v⬅️x◆⁷'HたRも\0'yてはむひ'✽になみˇ&を∧ウぬ¹&ろきっの¹'を➡️オへ\0'ゆけわす¹$nNNVエ&☉r★⬆️ウ&웃♪➡️こゅ&⬅️r◆こ▥'d♪h◆\0",
"!&N_イuけ&NAイWe&N★イへ…&NLイaろ'▥Rょ⬇️\r\"▤Rょ⬇️P'かSん○▒'しUっzb'😐⬇️ˇ★\0'[⬆️eと\0&Wとイよ\0'Aeサしね-lph░\0&^♪むは\0'▒v🅾️➡️\0'f{k●\0&mn♥⧗\0$○NNNエ&の◆ひ…²&は◆ひ…⁴'てWゃtメ&ひ◆ひ◆	'な➡️ひˇ²#ぬ★ひ⧗ᵉ'SiWn\0'Zm^p\0#UnVoᵉ#WlXm²&Nへウら⁸F'ˇˇかの\0&Nひウめ▤'7む~っ\0'gめヒわ\0'7も~ゅ¹'gやヒん¹'Nりオゃや-せ▤お░\0'え✽そˇ\0",
" 'PIかけ¹'^Pお▤²-idwNス&Mす♪を⁵&Nし♪さ	'vW▤✽⁴'vZい🐱	'x`▥⬇️\n&r⬅️🅾️r\n'█q…⬅️¹'●^★j¹&sこ{⌂\0'wot⌂	'smo웃⁴&|░🅾️▥⁵&}◆♪➡️\0&●t🅾️c¹&aWi♪¹&e`g░⁵&qnr☉웃#Oし🅾️し⁴'c⧗wせ\0'_そくのQ'^🅾️nき…&tき◆こ⁶&uか…お\r&vえ◆う%&z▥◆❎]!▒🅾️🅾️♪¹&⬇️⌂🅾️웃▮&|ˇ◆∧■#}★⬅️➡️¹'🐱█y➡️\0#}_xe⁴#wgvl⁴-🐱♥}◆!#{]xa	#ufsl	#▒Z○[	#nmoe⁴#r`zU⁴#pa🐱S⁴#✽S🅾️U⁴#f`g✽¹#af^n⁸#_p^t⁸#`v_{⁸#zhw🐱	#vt}e	'⬇️x○⬇️\0'MkO●²#RdP{\0#S^Q~\0#RZOg⁴#OnP~⁴&b[a★▮#O★Tえ⁴#O⌂R⬆️²#YjVu\0#UvT░\0#Z}\\░²#`_^d²#\\hZs²#`ねwに▥'✽`★}き'j⌂o★¹'d⌂i★\0'a◆qこ¹'k⬅️n…	&ZPd∧オ$_OUWん'e⧗nく$'fˇlお	'g∧kうJ'l♪m…\n&w✽{♥\0&OOXた…&Nす♪ち0\"mちつは9\"Rすはひ4&Nつ♪にオF'Iまセをメ'Xむをわや'@よnょ⁴'bる{ゃ⁴'@りoイ	'bれzゅ	'きよタイ⁴'かりソエ	#▤⧗けこ¹#♥웃🐱∧\0'ぬdの🐱²$gN➡️[ふ",
"%&OVゃd¹#Neイe\r#ろKれK\r'I<カc♪'I;カb\r'I9カ`😐'I7カ^ᶜ'I4カ[●'I2カY⁶'N6わX♥'O.ウU⁷#VNろN⁶-NeWN\0#VOろO\r#OdWM⁶-エjわN\0-X_Ze\0-__\\e\0-p]le\0-と]ねe\0-⌂]⬇️V⁴-ほYも]⁴-yTwN\0-`TeN\0'ゃRオe\0#WeX^\r#Y^Ze⁶#[e`^\r#`^_e⁶#_O_W⁶#_WfN⁶#⬅️W⬅️e\r#ゅdわO\r#⌂\\⌂e⁴-ゅ`りW\0#★V➡️e\r#★^★e²#odq]\0#q]qe\r#o^ke⁶-zW○]⁴#o]q]\r#🐱U⬅️U⁶#…U⬆️U⁶-mUpN\0#mNlU⁶#qMmV⁶#wOz]⁶#yOyV⁶#yV█]⁵#▥VくV\r#い]こ]⁵#けWこ]\r#▤UけU⁶'そSなW\r'そSとV\0#くOさ]⁶#な]のd⁶#とeて]\r#🐱V웃]⁶#まYゆ]⁶#らWっ^\r#をVよV\r-ほYひ\\R-●Y⬇️VB-|Z○]B#ほ^ふ\\⁶#ひ\\ほX\r#のPへW\r#はPほW⁶-sRoX。-sTqW\0&Nfアm\"F"}

function pal_from_map(y)
  local p,pl = {},{}
  for y=y,y+1 do
    for m = 0,120,8 do
    for i = 0,7 do p[i*2],p[i*2+1] = mget(i+m,y) >>4, mget(i+m,y) &15 end
    add(pl,p) p={}
    end
  end
  return pl
end

d_i,i_t,ease_in_out,roll_k,roll_x,roll_y,o_y,work_ram,screen_ram,leg_frame,offs_x,offs_y,d_out,gore,musics,…, title_comm, c_color_index,c_index,pal_leg, pal_torso, pal_sword, pal_roll = true,split(" _i am adam, prince of eternia_fabulous secret powers were_revealed to me when i raised_my magic sword and said_by the power of grayskull!_i have the power!_i became he-man, the most_powerful man in the universe!_together with my friends_we defend castle greyskull from_the evil forces of skeletor","_"),45, 22.5, 2, 5, -24, 0x4300, 0x6020, {}, 0, 0, false, false, split"0,24,48,48", split, {}, 0,0, pal_from_map(23), pal_from_map(25), pal_from_map(27), pal_from_map(29)

function create_frm_tbl(t)
  local o_t,tbl={},…(t)
  for i=1,#tbl,2 do
    add(o_t,{tbl[i],tbl[i+1]})
  end
  return o_t
end

torso_frame, back_leg, front_leg,special_leg = create_frm_tbl"16,17,18,19,0,1,2,3,25,26,20,-4,21,99,22,99,23,99,24,99,28,29,28,11,-29,29,-11,11,14,15,27,10,30,-30,28,-28,9,10,25,26,", …"32,34,37,39,40,42",…"33,35,41,43", create_frm_tbl"36,0,39,0,60,61,62,63,39,46,39,44,39,35,46,44,44,0,46,0"

function ▤(t,default)
  local o_t,tbl={},…(t)
  for i=1,#tbl,4 do
    o_t[tbl[i]]={}
    for j=1,3 do
    add(o_t[tbl[i]],tbl[i+j])
    end
  end
  o_t[0] = default
  return o_t
end

arms_ofs,plxy_ofs,head_ofs,trso_ofs,swrd_ofs,masters_tbl = ▤("701,,4,,702,,4,,-702,,4,,763,,12,,773,,7,,813,,12,,873,,7,,935,,6,360,1240,,6,360,1264,11,31,360",…"0,0,720"),
 ▤("24,1,,,213,,8,,561,-4,,,653,,8,,658,-10,9,,659,-4,6,,-659,-4,8,,763,,8,,873,,8,,702,,-2,,-702,,-2,,935,,-4,,1643,,8,,1093,,8,,1011,4,,,1154,2,,,1264,2,,,1572,,-8,,1644,,-8,,1754,,-6,,5000,4,8,,5001,3,3,,5015,3,3,,5016,4,8,,",…"0,0,0"),
 ▤("10,5,,,43,,2,,223,5,1,,333,5,1,,263,5,1,,463,1,,,483,2,,,545,1,,,546,0,,,561,0,,340,594,0,,350,593,5,,,653,5,,,658,-6,7,327,659,-6,16,112,1011,10,,13,1093,8,2,30,1572,5,1,,1643,,1,45,1644,5,,,1682,5,1,, 1754,5,,,1871,5,,,1880,5,,,2013,1,,,2023,2,,,2091,3,,",…"4,0,0"),
 ▤("24,-1,,,43,,2,,223,3,,,263,3,,,333,4,,,463,2,,,483,3,,,545,2,,,546,1,,,593,4,,,653,5,,,658,-5,5,,659,-4,12,,-659,-4,12,,935,-1,,,1011,2,,,1682,2,,,1754,2,,, 1871,1,,,1880,1,,,1093,2,1,,1240,1,,,2013,2,,,2023,3,,,2091,3,,",…"0,0,0"),
 ▤("24,7,,,43,7,6,331,113,9,,,153,10,7,280,213,9,,317,223,18,0,334,263,16,1,87,333,18,,48,463,11,2,139,483,14,2,137,545,14,3,331,546,13,3,,561,4,7,104,594,4,6,80,593,14,7,87,653,13,6,86,658,-2,14,96,659,10,18,260,-659,4,18,260,701,9,-8,226,702,11,-8,247,-702,11,-8,247,763,14,-6,167,773,7,-5,87,811,1,1,25,813,14,-6,167,873,4,-7,101,1011,9,,4,1093,10,8,112,1154,16,0,319,1264,14,-8,0,1572,4,6,60,1633,0,7,110,1641,3,6,62,1643,3,6,124,1644,2,8,60,1682,6,1,61,1754,6,1,61,1871,13,8,76,1880,13,8,76,1891,12,8,120,2013,17,3,322,2023,16,3,320,2091,13,1,300",…"8,5,342"),
 ▤"1,64,109,HE-MAN,2,64,109,ADAM,3,67,110,MAN AT ARMS,4,73,110,STRATOS,5,115,79,TEELA,6,112,79,SORCERESS,7,86,110,ZODAC,8,102,109,FISTO,9,99,109,SHE-RA,10,80,79,SKELETOR,11,83,109,MER-MAN,12,70,109,TRI-KLOPS,13,89,110,BEASTMAN,14,83,110,STINKOR,15,76,109,JITSU,16,96,79,EVIL-LYN,17,64,109,FAKER,18,92,79,HORDAK,"

anims,dither_p,d_c,stage_y_line = {{1}, …"12,101,24,1", …"24,101,12,1", …"1572,1644,1754,1682,1", …"43,213,213", …"43,1,1", …"2023,463,2013,483", …"873,873,213,653,653,213", …"701,701,223,333,333,223", …"773,773,2091,263,263,2091", …"811,811,153,593,593,153", …"702,935,-702,773,2091,263,263,2091", …"1,113,1011,113,1", …"545,545,546,545,545,1,1", …"3,773,773", …"773,813,813", …"873,763,763", …"1633, 594, 101, 12, 1", …"561,658,213,43", 1, 1, …"12,1641,1641,1641,1643,1643,1643,1643,1093,-659,-659,-659,-659", …"1643,1643", …"1093,1093", …"658,658", …"659,659", …"10,1880,1871,10", …"1,1891,1154,1264,1264", …"702,935,-702,-773"},…"32768, 32736, 24544, 24416, 23392, 23391, 23135, 23131, 6747, 6731, 2635, 2571, 523, 521, 9, 1",…"rect,oval,line,map,select,rectfill,ovalfill,,,,,,trifill",…"106,114,114,106"

function do_d_cmds(comm)
  for i=1,#comm do
    local cmd = comm[i]
    if (cmd[6]!=0 and cmd[7] !=4) fillp(-dither_p[cmd[6]] +.5)
    _ENV[d_c[cmd[7]]](unpack(cmd))
    fillp()
  end
end

function add_d_comm(bg_comm,fg_comm,string)
  local cmd_table,dest_table,cmd,c_i = string,bg_comm,{},0
  if (#cmd_table>0) bg_color = ord(cmd_table,1)-32
  for i=2,#cmd_table do
    local o = ord(cmd_table,i)
    if c_i==0 and o==70 then dest_table = fg_comm
    else
      if c_i==5 then
        add(cmd, o & 15) add(cmd, (o & 240)>>4)
        if (cmd[7] == 4) cmd[5]+=1 cmd[6]+=1
      else
        if c_i==0 then cmd[7]=o-32 else add(cmd, o-32 + ((c_i>0 and c_i<5) and -46 or 0)) end
      end
        c_i+=1
      if (c_i==6) add(dest_table,cmd) cmd={} c_i=0
    end
  end
end

add_d_comm(title_comm,nil,bg_cmd[5])

function copy_from_ram(start_y,end_y,ofs_line)

  if need_copy then
    for y=start_y,end_y do
      for x=0,63 do
        local ody = y<ofs_line and 1 or 0
        pset(126-x,y+ody,pget(x,y))
      end
    end

    for y=start_y,end_y do
      memcpy(work_ram + y*32, screen_ram + y*64, 32)
    end
    need_copy = false
  else
    for y=start_y,end_y do
      memcpy(screen_ram + y*64, work_ram + y*32, 32)
    end
  end
end

function check_copy_bg()
  if need_copy then
    add_d_comm(bg_shapes,fg_shapes,bg_cmd[stage+1])
    d_stage()
  end
end

function ai(IA)
  local distance, a1, dmgH,dmgN,dmgL = calc_distance(),pl1.action, pl2.dmgH,pl2.dmgN,pl2.dmgL

  function adv()
    return any(IA,"4,5,7")
  end

  function is_near()
    return distance <36 and distance >24
  end

  function is_crouching()
    return any(a1,"5,8")
  end

  function attacks(pl)
  local hit_count,a = pl.hit_count, pl.action
  if any(a,"1,5,6,15,16") or(a == 2 and pl.frm == 1) then
  if hit_count == 0 then
    if adv() and is_near() then
      ⧗(pl,11)
    else
      ⧗(pl,14)
    end
  elseif hit_count == 1 then
    if distance <= 24 then
      ⧗(pl,13)
    elseif adv() then
      ⧗(pl,9)
    else
      auto_idle(pl)
    end
  elseif hit_count == 2 then
    ⧗(pl,7)
  elseif hit_count == 3 then
    if adv() and is_near() then
      ⧗(pl,7)
    elseif adv() then
      ⧗(pl,8)
    else
      auto_idle(pl)
    end
  elseif hit_count == 4 then
    if adv() and is_near() then
      ⧗(pl,9)
    elseif adv() then
      ⧗(pl,8)
    else
      ⧗(pl,5)
    end
  elseif hit_count == 5 then
    if adv() then
      ⧗(pl,2)
    else
      ⧗(pl,8)
    end
  elseif hit_count == 6 then
    ⧗(pl,6)
  elseif hit_count == 7 then
    ⧗(pl,2)
  end
  pl.hit_count+=1
  if (adv()and pl.hit_count == 6) or pl.hit_count == 8 then pl.hit_count = 0 end
  end
  end

  if (pl2.action==7 and pl2.done) ⧗(pl2,1)

  if is_not_busy(pl2) then
  if distance >=60 then
    to_roll_fw(pl2)
  else

  if (distance < 60 and a1 == 12) then
    if IA == 3 then
      if (dmgN > 2) to_crouch(pl2) return
      ⧗(pl2,16) return
    end
    if (IA == 6) ⧗(pl2,8) return
    if (IA == 7) to_roll_fw(pl2) return
  end

  if distance == 48 and a1 == 1 then ⧗(pl2,12) else

  if distance > 36 and distance < 60 then
    if a1 == 3 then
      auto_idle(pl2) return
    else
      ⧗(pl2,2) return
    end
  end

  if distance == 36 then
    if adv() then
      if (a1 == 21) ⧗(pl2,8) return
      if (IA   <7 and not is_not_busy(pl1)) to_roll_fw(pl2) return
      if (IA == 7 and not is_not_busy(pl1)) ⧗(pl2,2) return
    else
      if (a1 == 21) ⧗(pl2,11) return
      if (not is_not_busy(pl1)) ⧗(pl2,2) return
    end
  end

  if is_near() then
  if     a1 == 20 then ⧗(pl2,4)
  elseif a1 == 21 then ⧗(pl2,8)
  elseif a1 ==  3 then ⧗(pl2,7)
  elseif adv() then
    if (IA == 5 and a1 == 9) ⧗(pl2,15) return
    if (dmgL > 4 and (is_crouching() or a1 == 7)) ⧗(pl2,7) return
    if ((dmgL > 2 and (is_crouching() or a1 == 7)) or (dmgN > 2 and IA<7 and a1 == 9)) to_roll_fw(pl2) return
    if (dmgH > 2 and a1 == 10) ⧗(pl2,8) return
  else
    if IA > 1 then
      if (dmgL > 4 and is_crouching()) ⧗(pl2,8) return
      if ((dmgL > 2 and any(a1,"5,21")) or (dmgH > 2 and a1 == 9) or (dmgN > 2 and a1 == 10)) to_roll_fw(pl2) return
    end
  end
  attacks(pl2)
  elseif distance <= 24 then
  if a1 == 4 then to_roll_fw(pl2) return
  elseif any(a1,"5,20")
    then ⧗(pl2,14) return
  elseif adv() then
    if (IA > 4 and a1 == 11) ⧗(pl2,16) return
    if (IA == 5 and a1 == 8) ⧗(pl2,4) return
    if (dmgL > 4 and (is_crouching() or a1 == 7)) ⧗(pl2,7) return
    if (dmgL > 2 and (any(a1,"14,7") or is_crouching())) to_roll_fw(pl2) return
  else
    if (IA == 3 and a1 == 11) ⧗(pl2,16) return
    if (IA == 2 and a1 == 8)  ⧗(pl2,4) return
    if IA > 1 then
      if (dmgL > 4 and is_crouching()) ⧗(pl2,14) return
      if (dmgL > 4 and IA > 2 and a1 == 7) ⧗(pl2,7) return
      if (dmgL > 2 and (a1 == 14 or is_crouching())) to_roll_fw(pl2) return
    end
    end
    attacks(pl2)
  end
  end
  end
end
end

function animate(pl)
  if (is_rolling(pl)) return false
  local any,anims, _ENV = any,anims, pl
  tik = (tik+1) % frm_len
  if tik == 0 then
    frm += 1
    if frm >= #anims[action] then
      if any(action,"2,3,7")
        then frm = 0
      else frm -= 1 end
      return true
    end
  end
end

function auto_idle(pl)
  if(pl.done) ⧗(pl,1,1)
end

function change_outline()
  d_out = not d_out
  menuitem(3,"outline "..(d_out and "off" or "on") ,change_outline)
end

function change_gore()
  gore = not gore
  menuitem(2,"gore "..(gore and "off" or "on") ,change_gore)
end

function add_leg_frames(leg_table,i)
  for b=1,#leg_table do
  local l=i*leg_table[b]
  for f=1,#front_leg do add(leg_frame,{l,front_leg[f]}) end
  for f=1,#back_leg  do add(leg_frame,{l,-back_leg[f]}) end
  end
end

function _init()
  music(0)
  mode, selected_menu, p1_s, p2_s, orco_dy, stage,sword,s_t = exp"0, 0, -1, -10, 0, 0,.25,0"
  set_stage()
end

menuitem(1,"back to title",_init)
change_gore()
change_outline()
add_leg_frames(back_leg,1)
add_leg_frames(front_leg,-1)
for b=1,#special_leg do
  add(leg_frame,special_leg[b])
end

function init_player(...)
  player={}
  ⧗(player,1,1)
  local exp,_ENV = exp,player
  can_decap,x,y,last_step,hit_count,dmgL,dmgN,dmgH,head_X,head_Y,life = true,exp"-16,-24,0,0,0,0,0,0,0,12"
  id,flip,pad = ...
  if (flip) x = 112-x
  return _ENV
end

function pre_init_pl()
  pl1,pl2 = init_player(-p1_s,false,0), init_player(-p2_s, true,1)
end

function init_fight()
  srand(t())
  sword,s_t,orco_x,p2pad = .25, 0, -20, 1
  if mode == 1 then
    p2pad = 9
    stage = starting_p == 9 and diff\2 or (7-diff)\2
  end
  set_stage()
  check_copy_bg()
  pl1,pl2 = init_player(p1_s,false,0), init_player(p2_s, true,p2pad)
  music(musics[stage+1])
end

function check_swap(pl)
  local other = (pl==pl1 and pl2) or pl1
  return (not pl.flip and (pl.x > other.x-8)) or (pl.flip and (pl.x < other.x+8))
end

function check_swap_action()
  local a1,a2 = pl1.action, pl2.action
  return (a1 == 4 and a2 == 20 and pl1.x> 11 and pl1.x<108) or (a1 ==20 and a2 == 4 and pl2.x> 11 and pl2.x<108) or a1 == 29 or a2 == 29
end

function collision(pl)

  if pl1.flip then
    A,B = pl2, pl1
  else
    A,B = pl1, pl2
  end

  if not skip then
    distance = calc_distance()
    if distance<16 then
      if is_moving(pl) then
        plwalk(pl,-pl.last_step) pl.last_step*=-1
      else plwalk(pl,-2) pl.last_step=0
      end
    end
  end

  if (orco_x > -20 or intro) return
  A.x,B.x = mid(0,A.x,128-16), mid(0,B.x,128-16)
end

function calc_distance()
  return abs(pl1.x-pl2.x)
end

function check_damage(A,B)
  local aa,ba,af,bf = A.action, B.action, A.frm,B.frm

  function check_hit(x,y)
    if (ba !=19 and ba !=18 and ba!=22 and A.yAttA == y) and (A.x>B.x and A.xAttA <= x or A.x<B.x and A.xAttA >= x) then
      if (is_rolling(B)) B.y=o_y
      sfx(3) return B
    else
      return nil
    end
  end

  function cling(A,B,frame)
  sfx(8)
  local sx,y = 0,0
  function init_cling(pl)
    local _ENV = pl
    frm,tik=frame,frm_len-1
    sx+=xAttA
    return yAttA
  end
  if A then y = init_cling(A) set_hit_areas(A) end
  if B then y = init_cling(B) set_hit_areas(B) end
  if (A and B and sx>0 and sx!= A.xAttA and sx!= B.xAttA) sx/=2
  if distance<32 then
    if (A) plwalk(A,-4)
    if (B) plwalk(B,-4)
  end
  fx_spark(sx,y)
  end

  if aa == ba and distance < 46 then
    if (is_sword_attack(aa)) and any(af,"3,4") and any(bf,"3,4") then
      cling(A,B,4)
      return true
    elseif aa==12 and any(af,"5,6") and any(bf,"5,6") then
      cling(A,B,6)
      return true
    elseif aa==7 and distance < 34 and (af == 1 or bf == 1) then
      cling(A,B,3)
      return true
    end
  end

  local res = check_hit(B.xHead,B.yHead)

  function blood(y,frm)
    frm = frm or 18
    fx_blood(res.x,y)
    decrease_life(res)
    ⧗(res,frm)
  end

  if not res then
  res = check_hit(B.xNeck,B.yNeck)
  if not res then
    res = check_hit(B.xBody,B.yBody)
    if not res then
    res = check_hit(B.xLeg,B.yLeg)
    if res then
      if any(aa,"14,20") then
        if(aa == 14) res.dmgL+=1 decrease_life(res)
        ⧗(res,19)
      elseif aa == 7 then
        blood(res.yLeg,19) res.dmgL+=1
      else
        blood(res.yLeg) res.dmgL+=1
      end
      return true
    end
    else
      if res.action == 16 then cling(A,nil,4)
      else blood(res.yBody)
      end
      return true
    end
  else
    if aa == 13 then
      res.dmgN+=1 decrease_life(res)
      ⧗(res,19)
    elseif res.action == 16 then
      if aa==12 then blood(B.yNeck) res.dmgN+=1
      else cling(A,nil,4)
      end
    else
      if aa == 12 and gore and res.can_decap and res.life<10 then
        ⧗(B,22,6) trail_x = B.x + (flip and 4 or 12)
        local _ENV = B
        head_X, head_Y, headDy, headRot = x + 8, yNeck-4, -1.5, 0
      else
        blood(B.yNeck) res.dmgN+=1
      end
    end
    return true
  end
  else
    if res.action == 15 then cling(A,nil,4)
    else blood(B.yHead,19) res.dmgH+=1
    end
    return true
  end
end

function decrease_life(pl)
  if(pl.life>0) pl.life-= 1
  --if(pl==pl2 and pl.life>0) pl.life-= 12 --db cheat
end

function check_death(pl)
  if pl.life==0 then
  srand(t())
  local d = rnd(2)
  if (pl.x>16 and pl.x<111) d = rnd(4)
  ⧗(pl,flr(d)+23)
  if pl==pl1 then to_win(pl2)
  else to_win(pl1)
  end
  else auto_idle(pl)
  end
end

function d_throne()
  pal(3,1)
  pal(11,5)

  do_d_cmds(bg_shapes)
  copy_from_ram(0,119,0)
  if (not need_copy) do_d_cmds(fg_shapes)

  local p = 1

  function d_lava (bx,c) oval(bx, 120-ct, 2*bx+32, 132, c) end

  d_lava(ct,10)
  d_lava(80-ct, 10)

  poke(0x5f5e, 0xfc)
  for j=0,48,2 do
    fillp(-dither_p[flr(p)]+0.5)
    rectfill(   j, j,        8+j+ct, j+10+ct, 13)
    rectfill(32+j, j-16+ct, 40+j-ct, j+2*ct)
    p=min(p+.65,15)
  end
  out_off()
  fillp()
end

function d_snake()
  do_d_cmds(bg_shapes)
  copy_from_ram(119,119,0)
  sdy+=.15 if(sdy>8)sdy=0
  for i =-8,128,8 do
    spr(207,80,72+i+sdy)
    spr(207,i+sdy,103)
  end
  fillp(dither_p[10]+.5)
  local c,s=cos(sdy/4),sin(sdy/4)
  circfill(80+c,102+s,3,9)
  circfill(88-c,102+s,3)
  fillp()
  if (not need_copy) do_d_cmds(fg_shapes)
end

function d_eternia()
  do_d_cmds(bg_shapes)
  copy_from_ram(0,119,0)
  if (not need_copy) do_d_cmds(fg_shapes)

  fillp(-dither_p[14]+0.5)
  rectfill(60+ct,40,67-ct,75-2*ct,10)
  fillp()
  ovalfill(30,57+ct,38,72+ct,0)
  ovalfill(20,   ct,30,17+ct)
  map(36,14,16,  ct,4,9)

  local cp = (1-ct)/2
  ovalfill(103,cp,118,20+cp)
  map(46,14,96,cp,3,3)
  ovalfill(12,cp+80,18,cp+88)
  map(35,18,12,cp+72,2,2)
  ct/=2
  ct+=64
  ovalfill(82,ct-1,98,24+ct)
  map(43,20,82,ct,2,3)
end

function d_grayskull()
  do_d_cmds(bg_shapes)
  copy_from_ram(8,119,64)

  poke(0x5f5e, 0x76)

  cloud_h = (cloud_h+.05)%6
  for f=0,14 do
   radius = (f-cloud_h)/2.2
    for i=1,rnd(12)do
    srand(f)
    local c_x, c_y = min(-40 + i + 128/radius, 26), min(30-rnd(3.8)*radius, 26)
    fillp(-23390.5)
    circfill(    c_x,c_y,  radius,4)
    circfill(127-c_x,c_y+1,radius)
   end
  end

  out_off()

  if (not need_copy) do_d_cmds(fg_shapes)

  for r = 0,2 do
  fillp(-dither_p[14-r*3]+0.5)
  circfill(63,60,18+ct-r*4,1)
  fillp(-dither_p[15-r*2]+0.5)
  circfill(63,64,15+ct-r*5,2)
  end

  fillp()

end

function d_thunder()
  srand(c_color_index)
  local rx = rnd(40)-20
  for t=32,96 do
  local x1,x2 = 22+t/1.5 + rx, 40+t/2.5 + -rx/2
  line(t, 24, x1, 56, …"1,12,7,7,7,7,12,1"[t\8-3])
  line(x1, 56, x2, 92)
  line(x2, 92, 46+t/3.5, 112)
  end
end

function d_legs(pl,flip)
  local f = pl.anim_frm<0 and -pl.anim_frm or pl.anim_frm

  if (pl.id == 5) palt(9,true) palt(10,true)
  if (pl.id != 10) palt(1,true)

  local spr_f = leg_frame[(f-1) % #leg_frame + 1]

  vflip = (f == 659) and true or false

  for i=2,1,-1 do
  local sf, hflip, xsize, ysize, ox, oy = spr_f[i], flip, 1, 2, spr_f[2] == 0 and 4 or (i-1)*8, 8
  if (f == 545 and i == 2) ox-=3 oy-=3
  if (sf<0) sf = - sf hflip = not hflip
  if (sf>43) xsize, ysize = 2, 1
  if (flip) ox = 8*(2-xsize)-ox
  if (sf!= 0 and (i != 2 or spr_f[1]<60)) spr(sf+fem, pl.x + pl.fx + ox, pl.y + pl.fy + stage_y + oy, xsize, ysize, hflip, vflip)
  end
end

function d_torso(pl,flip)
  local f = pl.anim_frm<0 and -pl.anim_frm or pl.anim_frm
  if (pl.id == 5) palt(0b1000000000001100)
  local spr_f = torso_frame[(f-1) \ #leg_frame + 1]
  vflip = (f == 659) and true or false

  local x,y = get_part_coords(trso_ofs,pl,0,flip)

  for i = 1,2 do
  local sf, hflip, oox = spr_f[i], flip, spr_f[2] == 99 and 4 or (i-1)*8
  if (sf<0) sf = - sf hflip = not hflip
  if (i==2 and sf == spr_f[1]) oox-=1
  if (flip) oox = 8-oox
  if (i==1 and is_win_frame(pl)) spr(8+fem, x+oox, y+4, 1, 1, flip,true)
  if (sf!= 99) spr(sf+fem, x+oox, y, 1, 1, hflip,vflip)
  if (pl.anim_frm == 811) oox = hflip and 6 or 2 spr(30+fem, x+oox, y-2, 1, 1, hflip)
  end

end

function d_head(pl,hd,flip)
  mset(127,8,hd)

  local h,f,px,x,y = pl.id, pl.anim_frm, pl.x, get_part_coords(head_ofs,pl,7,flip)

  pal_default()
  palt(0b0000000000010000)

  if (h == 14) pal(…"1,14,0,4,1,0,7,8,13,0,11,12,13,14,15") pal(0,10)
  if (h == 17) pal(…"1,2,3,4,5,6,7,8,4,2,11,12,1,13,12")

  if pl.action != 22 then
    if any(f,"935,10") or is_win_frame(pl) then
      local col = 9
      if is_fem(h)>0 then
        col = 1
        if(f == 935 and h != 5) ovalfill(px+2,y,px+12,y+14,pal_leg[h][10])
      end
      if(f == 935) pal_tint(pal_leg[h][col])
      local hh,hx = any(f,"1264,1871") and 2 or 1, flip and 1 or 0
      spr(hd+hh, x+hx, y-8, 1, 1, flip)
    else
      if (f ==659) flip = not flip
      d_rotated_tile(x+4, y, rot, 127, 8, 2,flip)
    end
  else
    local d,_ENV = d_rotated_tile,pl
    d(head_X, head_Y, headRot/360, 127, 7.5, 2,flip)
  end

  palt(0b1000000000000000)
  offs_x, offs_y ,rot = get_ofs_rot(arms_ofs,pl)
  if (f == 1240) flip = not flip
  if (flip) offs_x = (2-rot)*8 - offs_x

  local x, y = px + pl.fx + offs_x, pl.y + pl.fy + stage_y - 8

  if offs_y>0 then
    pal(pal_torso[h])
    spr(offs_y+fem, x, y, rot, 1, flip)
  end

  if f != 935 and f != 1240 and f!=1900 then
    d_sword(pl,flip)
  elseif f != 1240 and f!=1900 then
    offs_x = flip and -7 or 7
    spr(6+fem, x+offs_x, y, rot, 1, not flip)
  end
end

function d_player(pl)
  local sflip,x,h = pl.flip,pl.x,pl.id

  fem = is_fem(h)

  pal_player()

  if not is_rolling(pl) then
    pl.anim_frm = anims[pl.action][pl.frm+1]
    pl.fx,pl.fy = get_ofs_rot(plxy_ofs,pl)
    if (pl.flip) pl.fx*=-1

    if pl.anim_frm<0 then
      sflip = not pl.flip
    end

    local a=pl.anim_frm
    pal(pal_leg[h])
    d_legs(pl,sflip)
    pal_player()
    pal(pal_torso[h])
    d_torso(pl,sflip)
    local head_sp = masters_tbl[h][1]
    d_head(pl,head_sp,sflip)
  else
    local r, py = pl.frm_len , pl.y+stage_y
    pal(pal_roll[h])
    local my = fem>0 and 19.7 or 14.7
    d_rotated_tile(pl.x+8, py,   r/360, 126.4, my, 2)
    d_rotated_tile(pl.x+8, py, 1-r/360, 126.6, my, 2,true,1)
    if(h!=10) palt(1,true)
    if (r < ease_in_out or r > 360 - ease_in_out) pal(pal_leg[h]) spr(60, pl.x, py + plxy_ofs[5000+r\roll_k][2], 2, 1, sflip)
  end
end

function d_rotated_tile(x,y,rot,mx,my,w,flip,scale,o)
  scale = scale or 1
  local halfw, cx = scale*-w/2, mx + .5
  local cs, ss, cy = cos(rot)/scale, -sin(rot)/scale, my-halfw/scale
  local sx, sy, hx, hy = cx + cs*halfw, cy - ss*halfw, w*(flip and -4 or 4)*scale, w*4*scale
  for py = y-hy, y+hy do
    if (not(o and (rot<.25 or rot >.75) and py>y+4)) tline(x-hx, py, x+hx, py, sx + ss*halfw, sy + cs*halfw, cs/8, -ss/8)
    halfw+=1/8
  end
end

function d_stage()
  local df = {d_grayskull,d_eternia,d_snake,d_throne}
  cls(bg_color)
  df[stage+1]()
  if(need_copy) return
  pal_default()
  line(exp"127,0,127,127,0")
  rectfill(exp"0,119,127,127")

  function d_health(pl,x,k,x1)
    local xc = x+k*pl.life*4
    rectfill(x, 120, x+k*48, 126, 4)
    if (pl.life>0) rectfill(x, 120, xc,126,3) rectfill(x,121,xc,124,11)
    ps(masters_tbl[pl.id][3],x1,120,7)
  end

  if intro then
    ps(exp"prepare to fight!,256,121,10")
  elseif pl1 then
    d_health(pl1,0,1,1)
    d_health(pl2,126,-1,510)
  end
end

function d_sword(pl,flip)
  local h,x,y=pl.id, get_part_coords(swrd_ofs,pl,15,flip)
  local ht = masters_tbl[h][2]
  pl.swrd_rot,o = rot,false
  mset(127,0,any(h,"10,18") and 127 or ht)
  mset(127,1,ht+16)
  if any(h,"5,6,10,16,18") then
    mset(127,2,ht+32)
  else
    mset(127,2,0)
    o=true
  end
  pal(pal_sword[h])
  d_rotated_tile(x, y, pl.swrd_rot, 127, 0, 4, flip,1,o)
  pl.sw_y = offs_y
end

function is_fem(i)
  return any(i,"5,6,9,16") and 128 or 0
end

function sword_from(sc)
  local r=(s_t*3)^2.5/20
  if (not sc) sword=mid(.5,sword+.05,2.5) else sword = 2.5
  if (sword%.5>.4 or r >5) pal_tint(7)
  local sw,scale = (2.5-sword)*12, sc or sword/2.5

  function d(r,f)
    d_rotated_tile(63+cos(sword)*sw,71+sin(sword)*sw,r,91.4,0,14,f,scale)
  end

  d(-sword,false) d(sword,true)
  if (sword > 1.5 and sword <1.6) sfx(6)

  if sword== 2.5 and not sc then
    ovalfill(63-r/2,63-r,63+r/2,63+r,7)
  end
end

function exp(c)
  return unpack(…(c))
end

function d_transition_bg()
  function ll(i,c)
    line(i,0,ln-i,ln,c) line(0,ln-i,ln,i,c)
  end

  cls(0)
  srand(t()\.1)
  ln=127
  for i = 1,ln do
  local r = rnd(64)
  if (r < 4) ll(i,8)
  if r>3 and r < 40 then ll(i,4) elseif r>2 and r < 50 then ll(i,2)
  end
  end
  fillp(-2634.5) rectfill(exp"0,24,127,103,4") fillp()
end

function get_ofs_rot(ofs_table,pl)
  offs = ofs_table[pl.anim_frm]
  local def = ofs_table[0]
  if offs then
    for i=1,3 do
      if(offs[i]=="") offs[i]=def[i]
    end
  else
    offs = def
  end
  return offs[1],offs[2],offs[3]/360
end

function get_part_coords(tbl,pl,k,flip)
  offs_x, offs_y ,rot = get_ofs_rot(tbl,pl)
  if (flip) offs_x = k - offs_x
  return pl.x + pl.fx + offs_x, pl.y + pl.fy + offs_y + stage_y
end

function is_rolling(pl) return any(pl.action,"20,21") end

function is_sword_attack(aa) return aa >7 and aa <12 end

function is_not_busy(pl)
  local a = pl.action
  return not (is_rolling(pl) or (a!=7 and a>3 and pl.frm+1 < #anims[a]))
end

function is_moving(pl)
  local a = pl.action
  return a == 2 or a == 3 or a == 12 or is_rolling(pl)
end

function is_win_frame(pl)
  local f=pl.anim_frm
  return any(f,"1154,1240,1264,1871,1880,1891,1900")
end

function pal_default()
  pal()palt(0b0000000000000010)pal( 4, 136, 1)pal(14, 142, 1)pal(15, 143, 1)
end

function to_fw(pl)
  return (btn(➡️,pl.pad) and not pl.flip) or (pl.flip and btn(⬅️,pl.pad))
end

function to_bk(pl)
  return (btn(⬅️,pl.pad) and not pl.flip) or (pl.flip and btn(➡️,pl.pad))
end

function out_off()
  poke(0x5f5e, 0xff)
end

function pal_player()
  pal()palt(0b1000000000000000)
end

function pal_tint(col)
	for i=0,15 do pal(i,col) end
end

function plinput(pl)
  local pad, a = pl.pad, pl.action
  local attacking, defending = btn(🅾️,pad), btn(❎,pad)

  if is_not_busy(pl) then
  if btn(⬇️,pad) then
    ⧗(pl,5)
  else
    if a == 5 then
      ⧗(pl,6)
    elseif ((btn() & (0x003F << pad*8)) == 0) then
      ⧗(pl,1,1)
    elseif a != 5 and a != 8 then
    if to_fw(pl) then
    if attacking then
      sfx(5)
      ⧗(pl,10)
    elseif defending then
      ⧗(pl,13)
    else
      if(a!=2) plwalk(pl,4)
      ⧗(pl,2)
    end
    elseif to_bk(pl) then
    if attacking then
      ⧗(pl,7)
    elseif defending then
      ⧗(pl,14)
    else
      if(a!=3) plwalk(pl,-4)
      ⧗(pl,3)
    end
    elseif btn(⬆️,pad) then
    if attacking then
      ⧗(pl,9)
    elseif defending then
      if a == 16 then ⧗(pl,15,3,2) else ⧗(pl,15) end
    else
      ⧗(pl,4)
    end
    elseif attacking and defending then
      ⧗(pl,12)
    elseif attacking then
      ⧗(pl,11)
    elseif defending then
      ⧗(pl,16)
    end
    end
  end
  end
  pl.done = animate(pl)
end

function plstate(pl)
  local a,pad,flip,f = pl.action, pl.pad, pl.flip,pl.frm
  pl.can_decap = true

  function at_frm(fr)
    local _ENV = pl
      return frm == fr-1 and tik == frm_len-1
  end

  function do_roll()
    pl.y-= 8
    if check_swap(pl) then
      to_reverse(pl)
    elseif btn(⬇️,pad) then
      to_crouch(pl)
    else
      ⧗(pl,6)
    end
  end

  function ccw_roll(step)
    pl.frm_len-=roll_k
    local s = pl.frm_len
    if s < 0 then
      do_roll(pl)
    else
      plwalk(pl,step)
      if (s >= 360 - ease_in_out ) pl.y+=roll_y
      if (s < ease_in_out ) pl.y-=roll_y
    end
  end

  function cw_roll(step)
    pl.frm_len += roll_k
    local s = pl.frm_len
    if s >= 360 + roll_k then
      do_roll(pl)
    else
      plwalk(pl,step)
      if (s <= ease_in_out ) pl.y+=roll_y
      if (s > 360 - ease_in_out ) pl.y-=roll_y
    end
  end

  if a == 20 then
    pl.can_decap = false
    if flip then
      ccw_roll(roll_x)
    else
      cw_roll(roll_x)
    end
  elseif a == 21 then
    pl.can_decap = false
    if flip then
      cw_roll(-roll_x)
    else
      ccw_roll(-roll_x)
    end
  elseif a == 2 then
    if (at_frm(f+1)) plwalk(pl,4)
  elseif a == 3 then
    if (at_frm(f+1)) plwalk(pl,-4)
  elseif a == 4 then
    if (pl.frm <4) pl.can_decap = false
    if is_not_busy(pl) then
      if check_swap(pl) then
        to_reverse(pl)
      else
        auto_idle(pl)
      end
    end
  elseif a == 5 then
    pl.can_decap = false
    if f>1 then
      if btn(⬇️,pad) and (btn(🅾️,pad) or btn(❎,pad)) then
        sfx(4)
        ⧗(pl,8)
      end
    end
    if f>1 then
      if to_fw(pl) then
        to_roll_fw(pl)
      elseif to_bk(pl) then
        local angle = 0
        if (not flip) angle = 360
        sfx(9)
        pl.y+=8
        ⧗(pl,21,angle,angle)
      end
    end
  elseif a == 13 or a == 14 then
      if (at_frm(1)) sfx(2)
      auto_idle(pl)
  elseif a >=23 and a<= 26 then
      if (at_frm(1)) pl.frm-=1
  elseif a ==28 then
      if (at_frm(4)) pl.frm-=1
  elseif is_sword_attack(a) then
    if at_frm(1) then
      if (a == 11) sfx(5)
      if (a == 9) sfx(4)
    end
    if a == 8 then
      if(is_not_busy(pl)) to_crouch(pl)
    else
      auto_idle(pl)
    end
  elseif a == 12 then
    pl.can_decap = false
    if f<4 then
      if f>2 then
        plwalk(pl,4)
      elseif f>0 then
        plwalk(pl,2)
      end
      if(at_frm(2)) sfx(4)
    elseif is_not_busy(pl) then
      if pl==pl1 and pl2.action == 22 then
        to_win(pl)
      elseif pl==pl2 and pl1.action == 22 then
        to_win(pl)
      else
        auto_idle(pl)
      end
    end
  elseif a == 7 then
    if (at_frm(1)) sfx(6)
  elseif a == 18 then
    if (at_frm(f+1)) plwalk(pl,-2)
    if (is_not_busy(pl)) check_death(pl)
  elseif a == 19 then
    if (at_frm(1)) sfx(2) plwalk(pl,-8)
    if (at_frm(3) and pl.life >0 and btn(⬇️,pad)) to_crouch(pl)
    if (is_not_busy(pl)) check_death(pl)
  elseif a == 22 then
    update_head(pl)
    if (at_frm(5)) sfx(5)
    if (at_frm(12)) pl.frm-=1
    local fx_blood,stage_y,_ENV = fx_blood,stage_y,pl

    if (anim_frm == 1641) fx_blood(xNeck,yNeck,-4)
    if (anim_frm == 1643) fx_blood(xBody,yBody)
    if (anim_frm == -659 and frm<10) fx_blood(xLeg,stage_y)

  elseif a == 16 or a == 6 then
    pl.can_decap = false
  elseif a == 29 then
    if  at_frm(3,pl) then
      pl.flip = not pl.flip
      ⧗(pl,1,1)
    else
      plwalk(pl,2)
    end
  end
end

function plwalk(pl,step)
  local _ENV = pl
  last_step = step
  if (flip) step=-step
  x+=step
end

function ps(s,x,y,c)
  if x / 256 ==1 then x -= 192+2*#s elseif x / 256 >= 1 then x -= 384+4*#s end
  ?s,x+1,y,0
  ?s,x+1,y+1
  ?s,x,y+1
  ?s,x,y,c
end

function any(x,s)
  for e in all(…(s)) do
    if (x == e) return true
  end
end

function set_hit_areas(pl)
  if  is_rolling(pl) then
    local assert,dx,adx,stage_y,D_in_out,_ENV = assert,8,20,stage_y,2.5*ease_in_out,pl
    if(flip) dx = 7

    xAttA = x
    if action == 20 then
      if (not flip) and ( frm_len >= D_in_out and frm_len < 360 - D_in_out) then
        xAttA = x + adx
      elseif (flip) and ( frm_len > D_in_out and frm_len <= 360 - D_in_out) then
        xAttA = x-3
      end
    elseif flip then
        xAttA = x + adx
    end

    yAttA,xHead,yHead = y + stage_y -4, x + dx, y + stage_y
    xNeck, xBody, xLeg = xHead, xHead, xHead
    yNeck, yLeg = yHead - 4, yHead + 8
    yBody = yNeck
  else
    pl.anim_frm = anims[pl.action][pl.frm+1]

    function hit_offs(tbl)
      local aofx,aofy = get_ofs_rot(tbl,pl)
      if(pl.flip) aofx= -aofx+15
      return pl.x + aofx, pl.y -8 + stage_y + aofy
    end

    local ▤,…,hit_offs,_ENV=▤,…,hit_offs,pl
    xAttA, yAttA = hit_offs(▤("263,32,8,,333,32,4,,463,22,22,,546,24,22,,593,28,14,,653,32,22,,1011,24,8,",…"0,0,0"))
    xHead, yHead = hit_offs(▤("43,-2,,,113,16,,,1011,16,,,213,-2,,,873,-2,,,653,-2,,,763,-2,,,702,-4,,,-702,-4,,,935,-4,,,",…"14,4,0"))
    xNeck, yNeck = hit_offs(▤("43,-2,,,113,16,,,1011,16,,,213,-2,,,873,-2,,,653,-2,,,763,-2,,,702,-4,,,-702,-4,,,935,-4,,,1641,8,,,",…"14,8,0"))
    xBody, yBody = hit_offs(▤("113,16,,,1011,16,,,763,12,,,463,-4,,,483,-4,,,702,-4,,,-702,-4,,,935,-4,,,1643,8,,,1644,-4,,,2013,-4,,,2023,-4,,",…"14,14,0"))
    xLeg,  yLeg  = hit_offs(▤("113,16,,,1011,16,,,702,-4,,,-702,-4,,,935,-4,,,1572,-4,,,1644,-4,,,1682,-4,,,1754,-4,,",…"14,22,0"))

    if (action == 12 and frm> 4) xAttA-=4
  end
end

function set_stage()
  stage_y,intro,skip,trail_x,orco_y,sdy, cloud_z, cloud_h, need_copy, bg_shapes, fg_shapes, effects = stage_y_line[stage+1],true,true,200,stage_y_line[stage+1]-18, 0, 0, 0, true, {}, {}, {}
end

function ⧗(pl,anim,stp,fr)
  local _ENV = pl
  if action != anim then
    fr = fr or 0
    if anim>7 and anim <18 then stp = 3 elseif not stp then stp = 5 end
    action,frm,tik,frm_len = anim, fr, 0, stp
  end
end

function to_crouch(pl)
  ⧗(pl,5,5,1)
end

function to_reverse(pl)
  ⧗(pl,29,4)
end

function to_roll_fw(pl)
  if pl.action != 20 then
  local angle = pl.flip and 360 or 0
  sfx(9)
  pl.y+=8
  ⧗(pl,20,angle,angle)
  end
end

function to_win(pl)
  if (is_rolling(pl)) pl.y=o_y
  ⧗(pl,28)
  music(-1)
  if mode<3 and pl!=pl1 then
    music(62)
  else
    music(61)
  end
end

function trifill(x1,y1,x2,y2,c)
  local inc=sgn(y2-y1)
  local fy=y2-y1+inc/2
  for i=inc\2,fy,inc do
    line(x1+.5,y1+i,x1+(x2-x1)*i/fy+.5,y1+i,c)
  end
    line(x1,y1,x2,y2)
end

function update_head(pl)
  local abs,min,sfx,stage_y,ox,_ENV = abs,min,sfx,stage_y,orco_x+16,pl

  function step_head(x,r)
    if (ox> -1 and ox+16>=head_X) x=2 head_Y-=.25 r=22.5
    head_X+=x
    if (flip) then headRot-=r else headRot+=r end
  end

  local d = ox >= head_X and 0 or abs(head_X-xNeck)

  if d<=36 then
    if (flip and xHead<127-36) or (not flip and xHead<=36) then
      step_head(1.5,-22.5)
    else
      step_head(-1.5,22.5)
    end
    head_Y+=headDy
    headDy+=.5
    if (head_Y>stage_y-2) headDy=-1 sfx(2)
    head_Y=(min(stage_y-2, head_Y))
  end
end

function boss()
  return any(p1_s,"-9,-18") and 1 or 9
end

function _update()
  pal_default()

  function select_player(p,pl,pad)
    function browse_p()
      sfx(2)
      return init_player(-p,pl == pl2,0)
    end

    if btnp(➡️,pad) then
      p-=1 if (p<-#masters_tbl) p = -1
      pl = browse_p()
    elseif btnp(⬅️,pad) then
      p+=1 if (p>-1) p = -#masters_tbl
      pl = browse_p()
    else
      ⧗(pl,28)
      animate(pl)
    end
    return p,pl
  end

  function is_decapped(pl)
    if (pl.action == 22 and pl.frm > 6) skip = true return pl
    return nil
  end

  if not d_roboz then
    d_roboz = c_color_index >20
    c_color_index+=.25
    return
  end

  function up()
    if(btnp(⬆️,0)) sfx(2) return -1
    if(btnp(⬇️,0)) sfx(2) return 1
    return 0
  end

  if p2_s < 0 then
    if(btnp(❎,0) and mode>0) then
      if (mode == 2 and p1_s>0) p1_s = -p1_s pre_init_pl() return
      _init() return
    end

    pl1.x = 16
    if mode == 0 then
      selected_menu+= up()
      selected_menu %= 3
      if btnp(🅾️,0) then
        pre_init_pl()
        if (d_i) d_i,pl1.y = false,-24 return
        sfx(2) mode,orco_x,stage,diff = selected_menu+1,-20,0,0 starting_p=0
      end
    else
      if (mode == 3 or p1_s >0) then
        local pad = p1_s>0 and 0 or 1
        p2_s,pl2 = select_player(p2_s,pl2,pad)
      end

      if(p1_s <0) p1_s,pl1 = select_player(p1_s,pl1,0)

      if mode == 2 and p1_s>0 then
       diff+=up()
       diff %= 8
      elseif mode > 1 then
       stage+=up()
       stage %= 4
      else
        starting_p = (p1_s >-10) and 9 or 0
        p2_s = -starting_p-1
      end

      if btnp(🅾️,0) then
      sfx(2)
      et,enemy_list = …("2,3,4,5,6,7,8,"..boss()),{}
      for i=1,7 do
        local e = rnd(et)
        add(enemy_list, e+starting_p)
        del(et, e)
      end

      add (enemy_list,10-boss()+starting_p)

      if (mode != 2 or p1_s >0) p2_s = -p2_s orco_x = 200
      if (mode==1) diff = 0 p2_s = enemy_list[1]
      if (p1_s<0) p1_s = -p1_s
      end
    end
    pl1.x = 16
    return
  end

  if orco_x>=128+32 then

    local function ended()
      return mode==1 and diff==7 and pl1.action == 28
    end

    if (ended() and btnp(🅾️,0)) _init()

    if sword == 2.5 then
      if(s_t == 0) sfx(1)
      s_t+=0.5
      if s_t>14 then
        sword,s_t,selected = .25,0,false
        if (mode == 1 and (diff <7 or pl1.action != 28)) or not end_fight() then
          if mode==1 and end_fight() and pl1.life>0 and kp != pl1 then
            diff=diff+1
            p2_s = enemy_list[diff+1]
          end
          init_fight()
        elseif ended() then
          music(0)
        else
          p1_s,p2_s,kp,trail_x = -p1_s, -p2_s, nil, orco_x
          pre_init_pl()
        end
      end
    elseif sword==.5 then
      sfx(6)
      music(63)
    end
  else
  if (not intro) skip = check_swap_action()

  kp = is_decapped(pl1) or is_decapped(pl2)
  check_copy_bg()fx_update(stage_y)
  plstate(pl1)collision(pl1)plstate(pl2)collision(pl2)

  function do_intro(pl)
    if(pl.action!=2) plwalk(pl,4)
    ⧗(pl,2)
    pl.done = animate(pl)
  end

  if intro then
    if pl1.x<36 then
      do_intro(pl1)do_intro(pl2)
    else
      ⧗(pl1,1,1)⧗(pl2,1,1)
      intro,skip,orco_x = false, false, -20
    end
    return
  end

    if end_fight() then
      orco_x+=2
      orco_dy=sin((orco_x%30)/30)
      if kp and orco_x >= kp.x + ((kp.flip and 4) or 12) then
        kp.x +=2
      end
      animate(pl1)animate(pl2)
      return
    end
    plinput(pl1,0)collision(pl1)
    if mode == 3 then
      plinput(pl2,1)
    else
      ai(diff)
      pl2.done = animate(pl2)
    end
    collision(pl2)
    set_hit_areas(pl1)
    set_hit_areas(pl2)
    if not skip and not check_damage(pl1,pl2) then
      check_damage(pl2,pl1)
    end
  end
end

function end_fight()
  return kp or pl1.life == 0 or pl2.life == 0
end

function tv_bg(n)
  if mode == 0 then
    camera(0,-24)check_copy_bg()d_stage()camera(0,0)
    if d_i then
      pl1 = init_player(c_index<7 and 2 or 1)
      pl1.action,pl1.x,pl1.y,pl1.frm  = 28, 56,-16,…"1,1,1,1,1,2,3,3,3,2,1,1,1"[c_index+1]
      local a = any(c_index,"6,7")
      if (a) d_thunder()
      d_outline(pl1)
      if(not a or c_color_index%2==0) d_player(pl1)
      pal_default()
    else
      local menu_y,menu_dy = 74,12
      for y= 1,3 do
        ps(…"arcade mode,p 1 vs cpu,p 1 vs p 2"[y],256,menu_y+menu_dy*(y-1),7)
      end
      menu_dy *=selected_menu
      ps("◆            ◆  ",256,menu_y+menu_dy,7)
      d_orco(16,menu_y+menu_dy-10)
    end
  else
    d_transition_bg()
  end

  do_d_cmds(title_comm)

  ps("o f     t h e    u n i v e r s e",256,25,7)
  if p2_s<0 then
    rectfill(exp"0,120,127,127,0") c_color_index+=.25
    ps((d_i and i_t or …" ,original   idea    ,     john   henderson,music        ,damien hostin   @yourykiki   ,               matt kimball,      geoff   sejai-smith,programming   and gfx    ,    andrea   baldiraghi,       motu tm   by mattel inc.,  barbarian by   palace software, ")[c_index+1],256,121,…"0,0,0,0,1,5,13,6,7,7,7,7,6,13,5,1,0,0,0,0"[flr(c_color_index)])

    if c_color_index >20 then
       c_color_index,c_index=1,(c_index+1)%12
    if(d_i and c_index==0) d_i,pl1.y = false,-24 pre_init_pl()
    end
  end
  if (mode > 0) sword_from(n)
end

function d_shadow(pl)
  if pl.flip then o,o1=1,0 else o,o1=0,1 end
 line(pl.x,   stage_y-o,  pl.x+ 8, stage_y-o,  0)
 line(pl.x+6, stage_y-o1, pl.x+14, stage_y-o1, 0)
end

function d_outline(pl)
  if (not d_out) return
  poke(0x5f5e, 0x0F)
  function d(x,y)
    pl.x+=x pl.head_X+=x pl.y+=y pl.head_Y+=y
    d_player(pl)
  end
  d(-1,0) d(2,0) d(-1,-1) pl.y+=1 pl.head_Y+=1
  out_off()
end

function _draw()
  ct = 3.5*cos(t()/4)
  if (not d_roboz) cls() ps("tHErOBOz PRESENTS",256,61,…"0,0,0,0,1,5,13,6,7,7,7,7,6,13,5,1,0,0,0,0"[flr(c_color_index)]) return
  if p2_s<0 then
    tv_bg(1)
    if (mode == 0) return

    ps(masters_tbl[pl1.id][3],10,88,7)
    if (mode > 1 ) ps("STAGE "..…"castle,eternia,snake,throne"[stage+1], 2,102,7) ps("⬆️ ⬇️",(mode == 2 and p1_s>0) and 94 or 2,109,7)
    pl2.x = 96
    ps(masters_tbl[pl2.id][3],502,88,7)
    ps("vs",256,64,10)
    if (mode == 2) ps("LEVEL "..diff+1, 506,102,7)
    stage_y = 84
    if mode==1 then
      local s = …"2,118,5,108,0,98"
      for t=1,6,2 do
        pl2.id,pl2.x = -p2_s+s[t],s[t+1]
        d_player(pl2)
      end
      pl2.id += 9-boss()
    end
  else
  if orco_x>=128+32 then
    if (mode==1 and diff==7 and pl1.action == 28) then
      cls(0)
      for i = 1,8 do
      pl1 = init_player(i+9-starting_p,false,0)
      pl1.action,pl1.frm, pl1.x = 28, 3 + cos(t())\2, 16 *(i-1) -2
      d_player(pl1)
      end
      local ss = starting_p==0 and "doomed" or "saved"
      ps("eternia is "..ss,256,16,7)
      ps("you have the power",256,32,7)
      return
    end
    tv_bg()
    return
  else
    d_stage()
  end
  end

  if(orco_x>trail_x) ovalfill(trail_x,stage_y,orco_x,stage_y+2,8)

  for pl in all{pl1,pl2} do
  d_shadow(pl)
  d_outline(pl)
  d_player(pl)
  end

  pal_default()

  if kp and orco_x>-20 then
  d_orco()
  end
  fx_draw()
end

function d_orco(ox,oy)
  orco_x,orco_y = ox or orco_x, oy or orco_y
  sp=105+2*(ceil(t()*10)%2)
  if d_out then
  poke(0x5f5e, 0x0F)
  for x=-1,1 do
  local doy = x==0 and 1 or 0
  spr(sp,orco_x+x,orco_y-doy+orco_dy,2,2)
  end
  out_off()
  end
  spr(sp,orco_x,orco_y+orco_dy,2,2)
end

function fx_spark(x,y)
  for i=0, 1 do
    local rw = rnd(2)-1
    fx_add(x+rw, y+rw, 4+rnd(2), rw, rw, 0, 10)
  end
end

function fx_blood(x,y,dy)
  if (not gore) return
  dy = dy or rnd(1)-1
  for i=0, 3 do
    local rw = rnd(2)-1
    fx_add(x+rw, y+rw, 2+rnd(16), rw, dy, .5, 8)
  end
end

function fx_add(...)
  local fx={}
  if(#effects<8) add(effects, fx)
  local _ENV = fx
  t,grow,r,x,y,die,dx,dy,grav,col = 0,-.1,1.2,...
end

function fx_update(stage_y)
  for fx in all(effects) do
    if fx.t>fx.die then
      del(effects,fx)
    else
      local min,_ENV = min,fx
      dy+= grav r += grow x += dx y += dy y = min(y,stage_y) t +=1
    end
  end
end

function fx_draw()
  for fx in all(effects) do
    circfill(fx.x,fx.y,fx.r,fx.col)
  end
end
