--r.i.p. curl
--by ilkke - v1.1

-- cartdata

cartdata("ilkke_ripcurl")
hiscore=dget(0)
charsave=dget(1)

-- statemachine

menustate=0
gamestate=1
charselectstate=2

state=menustate
--state=charselectstate

function setstate(s)
 state=s
 _init()
end

function _init()
 if (state==menustate) then 
  menuinit()
 elseif (state==gamestate) then
  gameinit()
 elseif (state==charselectstate) then
  charselectinit()
 end
end

function _update()
 if (state==menustate) then
  menuupdate()
 elseif (state==gamestate) then
  gameupdate()
 elseif (state==charselectstate) then
  charselectupdate()
 end
end

function _draw()
 if (state==menustate) then
  menudraw()
 elseif (state==gamestate) then
  gamedraw()
 elseif (state==charselectstate) then
  charselectdraw()
 end
end

-- charselect

function charselectinit()
 initplayer()
 charlie=false
end

function charselectupdate()
 if btnp(4) then 
  if player.char==count(characters) then
   charlie=true
   return
  else
   setstate(gamestate)
   dset(1,player.char)
  end
 end
 --
 if btnp(0) then
  player.char-=1
  sfx(12)
  charlie=false
 elseif btnp(1) then
  player.char+=1 
  sfx(12)
  charlie=false
 end
 --
 if player.char > count(characters) then
  player.char=1
 elseif player.char<1 then
  player.char=count(characters)
 end
end

function charselectdraw()
 drawcharselectbg()
 --
 local text = characters[player.char][3]
 etchtext (text,centerx(text),56,13)
 --
 drawchar(characters[player.char][1])
 spr(43,36,86,1,1,true,false)
 spr(43,84,86) 
 --
 if charlie then
  text="charlie don't surf!"
 else
  text="select your character"
 end
 gildedtext (text,centerx(text),118)
 drawcorners()
end

function drawchar(c)
 local x=65
 local y=86
 --shadow
 stencilcolours(13)
 zspr(c,2,2,x,y+3,2)
 --outline
 local stroke=2
 stencilcolours(7)
 zspr(c,2,2,x-stroke,y,2)
 zspr(c,2,2,x,y-stroke,2)
 zspr(c,2,2,x+stroke,y,2)
 zspr(c,2,2,x,y+stroke,2)
 --sprite
 resetstencil()
 zspr(c,2,2,x,y,2)
end

function drawcharselectbg()
 palt(0,false)
 palt(11,true)
 --
 spr(48,0,0,8,8)
 spr(48,64,0,8,8,true,false)
 spr(56,0,64,5,8)
 spr(56,88,64,5,8,true,false)
 --
 block(3,0,4,1,1)
 block(9,0,4,1,1)
 block(3,1,3,2,1)
 block(10,1,3,2,1)
 block(3,3,2,2,1)
 block(11,3,2,2,1)
 block(0,8,4,2,1)
 block(12,8,4,2,1)
 block(1,10,3,1,1)
 block(12,10,3,1,1)
 block(3,11,1,1,1)
 block(12,11,1,1,1)
 block(1,15,2,1,9)
 block(13,15,2,1,9)
 --
 block(7,3,2,1,6)
 block(6,4,4,3,6)
 block(5,7,6,9,6)
 --
 spr(141,72,18,2,3)
 --
 spr(72,109,122,2,1)
end

-- menu

function menuinit()
 flashinterval=15
 flashcounter=0
 flash=true
 music(20)
 sfx(5,1)
end

function menuupdate()
 if btnp(4) then
  sfx(12)
  setstate(charselectstate)
 end
 flashcounter+=1
 if flashcounter>flashinterval then
  flash = not flash
  flashcounter=0
 end
 seagulls()
end

function seagulls()
 if (rnd(150)<1) sfx(5,1)
end

function menudraw()
 cls()
 drawtitlepic()
 drawcorners()
 if (flash) gildedtext ("press button to start",24,118,12)
 drawhiscore()
end

function drawhiscore()
 text=hiscore..""
 etchtext (text,centerx(text),28,13)
end

function drawtitlepic()
 palt(0,false)
 palt(11,true)
 --
 spr(48,0,0,8,8)
 spr(48,64,0,8,8,true,false)
 spr(56,0,64,5,8)
 spr(56,88,64,5,8,true,false)
 --
 block(3,0,4,1,1)
 block(9,0,4,1,1)
 block(3,1,3,2,1)
 block(10,1,3,2,1)
 block(3,3,2,2,1)
 block(11,3,2,2,1)
 block(0,8,4,2,1)
 block(12,8,4,2,1)
 block(1,10,3,1,1)
 block(12,10,3,1,1)
 block(3,11,1,1,1)
 block(12,11,1,1,1)
 block(1,15,2,1,9)
 block(13,15,2,1,9)
 --
 block(7,3,2,1,6)
 block(6,4,4,3,6)
 block(5,7,6,9,6)
 --
 spr(176,9,70,14,5)
 spr(51,32,110,4,1)
 spr(56,64,110,4,1)
 --
 spr(45,40,43,3,3)
 spr(93,64,43,3,3)
 spr(31,64,35,1,2,true,false)
 spr(31,56,35)
 spr(141,72,18,2,3)
 --
 spr(72,109,122,2,1)
end

function block(x,y,w,h,c)
 rectfill(x*8,y*8,(x+w)*8-1,(y+h)*8-1,c)
end

-- game

function gameinit()
 initwaves()
 cloudsx=0
 mountainsx=0
 sploder=0
 splode=false
 spl={}
 board={}
 distance=0
 palt(0,false)
 palt(11,true)
 --
 shark={}
 sharkcounter=0
 bombs={}
 bombs.interval=120
 bombs.minterval=12
 bombs.warningtime=20
 bombs.counter=0
 --
 sfx(-1,1)
 music(12)
end

function gameupdate()
 mountainsx-=1
 if (mountainsx<-88) mountainsx=0
 cloudsx-=0.5
 if (cloudsx<-188) cloudsx=0
 moveplayer()
 movewaves()
 movesplash()
 --
 if shark.active then
  moveshark()
 elseif rnd(100)<sharkcounter then
  addshark(rnd(4)+3)
 end
 sharkcounter+=0.1
 --
 movebombs()
 --
 if (player.alive) distance+=0.1
end

function gamedraw()
 drawbg()
 drawbgwave()
 drawbombs()
 drawsplash()
 if (not player.alive) moveboard()
 drawwaves()
 if (splode) drawsplode()
 if (shark.active) drawshark()
 drawplayer()
 drawscore() 
 drawcorners()
 drawgameover()
-- print (stat(1),0,0,13)--cpu
end

function drawscore()
-- rectfill(0,119,127,127,7)
 local text=flr(distance)..""
 gildedtext(text,centerx(text),120)
end

function drawgameover()
 if not player.alive and player.zoom>14 then
  local text="game over"
  gildedtext(text,centerx(text),63)
 end
end

--bg

function drawcorners()
 spr(21,0,0,1,1,true,true)
 spr(21,120,0,1,1,false,true)
 pal(2,5)
 spr(21,0,120,1,1,true,false)
 spr(21,120,120)
 pal(2,2)
end

function drawbg()
 --horizon
 rectfill(0,0,127,87,4)
 rectfill(0,88,127,127,2)
 --mountains
 drawmountains(mountainsx)
 --sun
 drawsun(80,16)
 drawclouds(cloudsx,32)
end

function drawmountains(x)
 spr(32,x,80,11,1,true,false)
 spr(32,x+88,80,11,1,true,false)
 spr(32,x+88+88,80,11,1,true,false)
end

function drawsun(x,y)
 spr(10,x,y,2,2)
 spr(10,x+16,y,2,2,true,false)
 spr(10,x,y+16,2,2,false,true)
 spr(10,x+16,y+16,2,2,true,true)
end

function drawclouds(x,y)
 map(0,0,x+20,y+10,8,2)
 map(0,2,x+84,y-24,12,3) 
 map(0,0,x+208,y+10,8,2)
 map(0,2,x+84+188,y-24,12,3) 
end

--waves

function initwaves()
 horizon=94
 angle=0
 angle2=0
 maxh=0
 w=8
end

function drawbgwave()
 for i=0,128 do
  local h=(sin(angle+(i/32/w)))*(maxh/2)+horizon
  line(i,cos(angle+(i/32/w))*8+horizon,i,128,3)
 end
end

function drawwaves()
 for i=0,128 do
  local h=(sin(angle+(i/32/w)))*(maxh/2)+horizon
  line(i,h,i,128,12)
  line(i,h,i,h+(sin((i/150+angle2*40)*4)*2),7)
 end
end

function movewaves()
 angle+=abs(sin(angle2)/25)+0.01
 angle2+=0.0075
 maxh=sin((angle2-angle)/100)*48
 w=18+(cos(angle2/2)*10)
end

--player

function initplayer()
 player={}
 player.alive=true
 player.zoom=1
 --
 player.x=32
 player.xspeed=4
 --
 player.y=0
 player.jumpy=0
 player.jumpforce=-10
 player.gravity=1
 player.jumping=false
 player.jumpbase=0
 player.floor=horizon
 --
 initchars()
 charsave = dget(1)
 if charsave==0 then
  player.char=1
 else
  player.char=charsave
 end
end

function initchars()
 -- frame, deathframe
 dudebro={0,6,"dudebro"}
 surfchick={67,99,"salty sista"}
 kilgore={118,150,"col kilgore"}
 doolittle={190,222,"doolittle"}
 charlie={74,74,"charlie"}
 characters={dudebro,surfchick,kilgore,doolittle,charlie}
end

function drawplayer()
 -- alive
 if player.alive then
  -- jump?
  if player.jumping then
   player.y=player.jumpbase+player.jumpy
  else
   player.y=player.floor
  end
  -- draw
  spr(characters[player.char][1],player.x-8,player.y,2,2)
 else
  -- dead
  zspr(characters[player.char][2],2,2,player.x-8,player.y,player.zoom)
 end
end

function moveplayer()
 if player.alive then
  -- move
  if (btn(0)) player.x-=player.xspeed
  if (btn(1)) player.x+=player.xspeed
  if (btnp(4) and not player.jumping and (distance>0)) playerjump()
  player.x=max(16,player.x)
  player.x=min(128-16,player.x)
  -- jump
  if (player.jumping) then
 	 player.jumpy+=player.yspeed
 	 player.yspeed+=player.gravity
 	 if player.jumpy>player.floor-player.jumpbase then
 	  player.jumpy=0
 	  player.yspeed=0
 	  player.jumping=false
 	  makesplash(player.x,player.floor+16,8)
 	 end
 	end
  player.floor=(sin(angle+((player.x/w)/32)))*(maxh/2)+horizon-15
 else
  -- dead
  if player.zoom<15 then
   player.zoom+=0.5
 	 player.y+=player.yspeed
 	 player.yspeed+=player.gravity*2
 	end
 	-- restart
  if btnp(4) 
  and (player.zoom==15)
  then
   setstate(menustate)
  end
	end
end

function playerjump()
 player.jumping=true
 player.jumpbase=player.floor
 player.yspeed=player.jumpforce
 sfx(10)
end

function playerhit()
 if flr(distance)>hiscore then
  hiscore=flr(distance)
  dset(0,hiscore)
 end
 sfx(6)
 player.alive=false
 player.yspeed=player.jumpforce
 exsplode(player.x-8,player.y)
 dropboard(player.x-8,player.y)
-- player.x=128 -- temp
end

--splash

function makesplash(x,y,n)
 splash=true
 for i=1,n do
  makedroplet(x,y)
 end
end

function makedroplet(x,y)
 d={}
 d.x=x
 d.y=y
 d.xs=(rnd(4)-3)*1.5
 d.ys=-rnd(6)-1
 add (spl,d)
 return d
end

function movesplash()
 if (not splash) return
 for d in all(spl) do
  d.x+=d.xs
  d.y+=d.ys
  d.ys+=1
  if (d.y>128) del (spl,d)
 end
end

function drawsplash()
 if (not splash) return
 for d in all(spl) do
  spr(2,d.x,d.y)
 end
end

-- shark

function addshark(speed)
 shark.active=true
 shark.speed=speed
 shark.x=130
end

function moveshark()
 --move
 shark.y=(sin(angle+((shark.x/w)/32)))*(maxh/2)+horizon-10
 shark.x-=shark.speed
 makesplash(shark.x+8,shark.y+20,1)
 --remove
 if shark.x<-8 then
  shark.active=false
  sharkcounter=0
 end
 --collide
 if player.alive
 and abs(shark.x-(player.x-8))<4
 and abs(shark.y-player.y)<16 then
  playerhit()
 end
end

function drawshark()
 spr(3,shark.x,shark.y,2,2)
end

-- bomb

function addbomb(x)
 b={}
 b.x=x
 b.y=-8
 b.yspeed=6
 b.timer=0
 add(bombs,b)
 return b
end

function movebombs()
 bombs.counter+=1
 -- spawn new bomb?
 if bombs.counter>bombs.interval then
  addbomb(rnd(12)-6+player.x)
  bombs.counter=0
 end
 for b in all (bombs) do
  -- move
  b.timer+=1
  if (b.timer>bombs.warningtime) b.y+=b.yspeed
  -- splash
  local dno=(sin(angle+((b.x/w)/32)))*(maxh/2)+horizon
  if b.y>dno then
   del (bombs,b)
   if player.alive then
    sfx(11)
   else
    sfx(13)
   end
   makesplash(b.x,dno,16)
   if (player.alive) bombs.interval*=0.5
   bombs.interval=max(bombs.minterval,bombs.interval)
  end
  -- collision detect
  if player.alive
  and abs(b.x-(player.x-4))<8
  and abs(b.y-(player.y)-4)<8 then
   playerhit()
  end
 end
end

function drawbombs()
 for b in all (bombs) do
  if b.timer<bombs.warningtime then
   spr(18,b.x,(b.timer/3)-1)
  else
   spr(5,b.x,b.y)
  end
 end
end

-- surfboard

function dropboard(x,y)
 board.x=x
 board.y=y
 board.xs=1
 board.ys=-10
 board.gravity=1
 board.show=true
end

function moveboard()
 if (not board.show) return
 local dno=(sin(angle+((board.x/w)/32)))*(maxh/2)+horizon
 if board.y>dno then
  board.show=false
  makesplash(board.x+8,board.y,16)
 end
 board.x+=board.xs
 board.y+=board.ys
 board.ys+=board.gravity
 spr(8,board.x,board.y,2,2) 
end

-- explosion

function exsplode(x,y)
 splode=true
 splodex=x
 splodey=y
 sploder=0
end

function drawsplode()
 circfill(splodex,splodey,sploder,10)
 circfill(splodex,splodey,sploder*0.75,7)
 sploder+=7
 if (sploder>25) splode=false
end

-- helpers

--zoom sprite
function zspr(n,w,h,dx,dy,dz)
 sx = 8 * (n % 16)
 sy = 8 * flr(n / 16)
 sw = 8 * w
 sh = 8 * h
 dw = sw * dz
 dh = sh * dz
 dx-=dz*w*4
 dy-=dz*h*4
 sspr(sx,sy,sw,sh, dx,dy,dw,dh)
end

function gildedtext(text,tx,ty)
 print (text,tx-1,ty,2)
 print (text,tx+1,ty,2)
 print (text,tx,ty-1,8)
 print (text,tx,ty+1,0)
 print (text,tx,ty,10)
end

function etchtext(text,tx,ty)
 print (text,tx-1,ty,7)
 print (text,tx+1,ty,7)
 print (text,tx,ty-1,7)
 print (text,tx,ty,5)
 print (text,tx,ty+1,7)
 clip(0,ty+1,128,ty+5)
 print (text,tx,ty,13)
 clip()
end

function centerx(text)
 return (128-(#text*4))/2
end

function stencilcolours(c)
 for i=0,15 do
  pal(i,c,0)
 end
end

function resetstencil()
 for i=0,15 do
  pal(i,i,0)
 end
end
