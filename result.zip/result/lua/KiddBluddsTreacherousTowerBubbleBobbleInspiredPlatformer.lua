--kid bludd's
--treacherous tower
                
--log
printh("\n\n-------\n-start-\n-------")

--[[

todo:

* spawn gems
* enemies:
	* fire shooting walker
	* snail (walker with shell)
* additional control schemes

bug:
	* game over while dashing doesn't allow restart.
	* remove debug level skip.
	* remove debug sprites.
]]

--name of save game
cartdata("mbh_kidbludd")

--globals
g=
{
	grav=0.15,
}

--sfx
snd=
{
	start=63,
	strike=61,
	jump=60,
	hit=57,
	kill=59,
	death=56,
	lvl_complete=55,
}

mus=
{
	title=28,
	tutorial=26,
	gameplay=0,
	gameover=27,
}

trans=-1
trans_dir=0
tstate=0

function loop_pos(self)
	if current_level!=nil then
		if self.x>current_level.pos.x+64 then
			self.x=current_level.pos.x-64
		elseif self.x<current_level.pos.x-64 then
			self.x=current_level.pos.x+64
		end
		if self.y>current_level.pos.y+64 then
			self.y=current_level.pos.y-56
		elseif self.y<current_level.pos.y-56 then
			self.y=current_level.pos.y+64
		end
	end
end

--collision
--

function intersects_p(px,py,x,y,w,h)

	if flr(px)>=flr(x) and flr(px)<flr(x+w) and
				flr(py)>=flr(y) and flr(py)<flr(y+h) then
		return true
	else
		return false
	end

end

--checks if 2 boxes intersect.
function intersects(
	x1,y1,
	width1,height1,
	x2,y2,
	width2,height2)

	local xd=x1-x2
	local xs=width1*0.5+width2*0.5
	if abs(xd)>=xs then return false end

	local yd=y1-y2
	local ys=height1*0.5+height2*0.5
	if abs(yd)>=ys then return false end


	return true

end

function solidleft(self)
	if self.dx>0 and
		fget(mget((self.x+4)/8,
		(self.y)/8),0) then
		self.dx=0
		self.x=(flr(((self.x+4)/8))*8)-4
		return true
	elseif self.dx<0 and
		fget(mget((self.x-4)/8,
		(self.y)/8),0) then
		self.dx=0
		self.x=(flr((self.x-4)/8)*8)+8+4
		return true
	end

	return false
end

--make
--

--make 2d vector
function m_vec(x,y)
	local v=
	{
		x=x,
		y=y,
		
  --get the length of the vector
		getlength=function(self)
			return sqrt(self.x^2+self.y^2)
		end,
		
  --get the normal of the vector
		getnorm=function(self)
			local l = self:getlength()
			return m_vec(self.x / l, self.y / l),l;
		end,
	}
	return v
end

--make a streak; a line particle
function mkstreak(_x,_y,
	_dx,_dy,_col,_maxhist,_g,_dec)

	local o=
	{
  --position
		x=_x,
		y=_y,
  --velocity
		dx=_dx,
		dy=_dy,
  --deceleration
		decel=_dec,
  --gravity
		g=_g,
  --history of positions
		hist={},
  --max length of history to record
		maxhist=_maxhist,
  --color
		col=_col,
  --has it slowed to a stop
		stopped=false,
  --how long should it live
		lifetime=-1,
	}
	
	add(o.hist,m_vec(o.x,o.y))
	
	--update
	function o:u()
	
  --once stopped, do nothing.
		if self.stopped then
			return
		end
		
  --died of old age?
		if self.lifetime!=-1 then
			self.lifetime-=1
			if self.lifetime<=0 then
				del(streaks,self)
				return
			end
		end

  --fall
		self.dy+=self.g

  --slow down
		self.dx*=self.decel
		self.dy*=self.decel
	
  --detect slow enough to stop.
		if abs(self.dx)<=0.2 and
			abs(self.dy)<=0.2 and
			self.decel!=1 then
			self.stopped=true
			return
		end
		
  --move
		self.x+=self.dx
		self.y+=self.dy
		
  --save history of position
		add(self.hist,m_vec(self.x,self.y))
	
		if #self.hist>self.maxhist then
			del(self.hist,self.hist[1])
		end
		
		--clean up when off bottom.
  --todo: detect offscreen in 
  --general.
		if self.hist[1].y>cam.pos.y+128 then
			del(streaks,self)
			return
		end
	end
	
 --draw
	function o:d()
	
  --draw a line between each 
  --position in history, creating
  --a kind of curve.
		if #self.hist>1 then
			for i=1,#self.hist-1 do
				local p1=self.hist[i]
				local p2=self.hist[i+1]
				line(p1.x,p1.y,p2.x,p2.y,self.col)
--				pset(p1.x,p1.y,self.col)			
			end
		end
	end
	
	add(streaks,o)
	
	return o

end

	function mkparticle(_x,_y,
	_tmin,_tmax,_col)

	local o=
	{
  --position
		x=_x,
		y=_y,
		
  --velocity
		dx=(rnd(4)-2)*0.1,
		dy=(rnd(3)-1)*0.1,
		
  --gravity
		g=0,
		
  --lifetime
		t=rnd(_tmax-_tmin)+_tmin,
		
  --color
		col=_col,
	}
	
 --update
	function o:u()
		local o=self
		o.t-=1
		o.dy+=o.g
		o.x+=o.dx
		o.y+=o.dy
		
		if o.t<=0 then
			del(parts,o)
		end
	end
	
 --draw
	function o:d()
		if o.t>_tmax*0.66 then
			pset(self.x,self.y,self.col)
		elseif o.t>_tmax*0.33 then
			pset(self.x,self.y,self.col-1)
		else
			pset(self.x,self.y,self.col-2)
		end
	end
	
	add(parts,o)
	
	return o
end

----------------------------

--make an air jet particle.
function mkjetpart(d)
	local pr=mkparticle(
		p.x-d,p.y-1,10,20,6)
	pr.dy+=p.dy*speedmod
	pr.dx*=d
end

function m_player(x,y)

	local p=
	{
		x=x,
		y=y,

		dx=0,
		dy=0,

		w=8,
		h=8,
		
		dest=nil,
		teleport_spd=4,
		dest_tick=0,
		post_dest_buffer=15,
		tele_tick=0,
		hit_tick=0,
		tele_max=32,--128,

		mxx=1,--max x speed

		jy=-1.75,--jump veloclity
		acc=0.1, --acceleration
		dcc=0.8,--decceleration
		adcc=1,--air decceleration

		jh=0,--how long jump is held
		mnjh=5,
		mxjh=15,--max time jump can be held

		jrdy=true,--can we jump again?
		grounded=false,

		airtime=0,--time since grounded
		jumpholdtime=0,
		
		dash_count=0,
		
		lives=3,
		took_hit=false,
		
		combo=0,

		anims=
		{
			["stand"]=
			{
				ticks=1,
				frames={2},
			},
			["walk"]=
			{
				ticks=5,
				frames={3,4,5,6},
			},
			["jump"]=
			{
				ticks=1,
				frames={1},
			},
			["slide"]=
			{
				ticks=1,
				frames={7},
			},
		},

		curanim="walk",
		curframe=1,
		animtick=0,
		flipx=false,
		
		hist={},

		setanim=function(self,anim)
			if(anim==self.curanim)return
			local a=self.anims[anim]
			self.animtick=a.ticks
			self.curanim=anim
			self.curframe=1
		end,
		
		onloadlevel=function(self)
		
			self.x,self.y=w2m(16,128-12)
			self.dx=0
			self.dy=0
			self.flipx=false
			
			self.dest=nil
			self.dest_tick=0
			self.tele_tick=0
			self.hit_tick=0
			self.jh=0--how long jump is held

			self.jrdy=true--can we jump again?
			self.grounded=true

			self.airtime=0--time since grounded
			self.jumpholdtime=0
			
			self.dash_count=0		
			self.combo=0
			
			explode(self,m_vec(rnd(5)-2,-2),{1,2,5,6,7,8,9})
		end,

		update=function(self)
		
			--printh(self.dest_tick)
		
			if self.took_hit==true then
			
				--[[
				self.took_hit=false
				self.dest=m_vec(w2m(16,128-32))
				local newd=m_vec(self.x-self.dest.x,self.y-self.dest.y)
				newd,len=newd:getnorm()
				
				local mintele=7
				self.x=self.dest.x+newd.x*(self.teleport_spd*mintele)
				self.y=self.dest.y+newd.y*(self.teleport_spd*mintele)
				
				self.dash_count+=1
				
				--self.dest=m_vec(destx,desty)
				self.dest_tick=self.post_dest_buffer
				self.tele_tick=0
				--]]
				self:onloadlevel()
				self.dest_tick=self.post_dest_buffer*3
				self.took_hit=false
				if current_level_id==1 then
					music(mus.tutorial)
				else
					music(mus.gameplay)
				end
			end
		
			--track button presses
			local bl=btn(0,1) or btn(0,0)
			local br=btn(1,1) or btn(1,0)
			local m1=mouse:btnp(mouse.btn_left) and self.dash_count<1-- and not mouse.on_wall
			
			if m1!=false then				
				--[[
				local newd=m_vec(mouse.pos.x-self.x,mouse.pos.y-self.y)
				newd=newd:getnorm()
				
				local oldd=m_vec(self.dx,self.dy)
				local len=oldd:getlength()
				
				self.dx=newd.x*2
				self.dy=newd.y*2
				
				self.x=mouse.pos.x
				self.y=mouse.pos.y
				--]]
				
				--[[
				local destx=orb.x
				local desty=orb.y
				orb=nil
				--]]
				
				self.dash_count+=1
				
				self.dest=m_vec(mouse.pos.x,mouse.pos.y)
				--self.dest=m_vec(destx,desty)
				self.dest_tick=self.post_dest_buffer
				self.tele_tick=0
				
				sfx(snd.strike)

				--[[
					local h=2
					local f=0.3
					local c=1
					
					
					mkstreak(self.x,self.y,
						-f,-f,c,h,0.1,1)
					mkstreak(self.x,self.y,
						-f,-f-(f*2),c,h,0.2,1)
					mkstreak(self.x,self.y,
						f,-f,c,h,0.2,1)
					mkstreak(self.x,self.y,
						f,-f-(f*2),c,h,0.1,1)
				--]]
							
			end
			
			if self.dest!=nil then
			
				local p=mkparticle(self.x,self.y,60,120,2)
				
				self.tele_tick+=1
				local mintele=7
				--[[
				if self.tele_tick == mintele and false then
					local newd=m_vec(self.x-self.dest.x,self.y-self.dest.y)
					newd,len=newd:getnorm()
					--printh(len)
					self.x=self.dest.x+newd.x*(self.teleport_spd*mintele)
					self.y=self.dest.y+newd.y*(self.teleport_spd*mintele)
				end
				]]
				
				local newd=m_vec(self.dest.x-self.x,self.dest.y-self.y)
				newd,len=newd:getnorm()
				
				self.dx=newd.x*self.teleport_spd
				self.dy=newd.y*self.teleport_spd
				
				if len < self.teleport_spd or self.tele_tick>self.tele_max/self.teleport_spd then
					self:on_end_tele()
				end
				
				--[[
				self.x+=self.dx
				self.y+=self.dy
				newd=m_vec(self.dest.x-self.x,self.dest.y-self.y)
				
				if newd:getlength() < self.teleport_spd then
					self.x=self.dest.x
					self.y=self.dest.y
					self.dest=nil
				end
				--]]				
				--return
			end
			
			
			--kill the goons
			for k,v in pairs(goons) do
				if intersects(self.x,self.y,8,8,v.x,v.y,v.r,v.r) and v.dam_tick==0 then
					if self.dest!=nil or self.dest_tick>0 then
						v:onhit(self)
					elseif not v.thrown and intersects(self.x,self.y,4,4,v.x,v.y,v.r,v.r) then
						self.combo=0
						self.hit_tick=60
						self.took_hit=true
						self.lives-=1
						explode(self,m_vec(-self.dx,-self.dy),{8,9,10})
						if self.lives>0 then
							sfx(snd.death)
						end
						music(-1)
					end
				end
			end
			
			--move left/right
			if bl==true then
				self.dx-=self.acc
				br=false--handle double press
			elseif br==true then
				self.dx+=self.acc
			else
				if self.grounded then
					self.dx*=self.dcc
				else
					self.dx*=self.adcc
				end
			end

			--limit walk speed
			if self.dest==nil then
				self.dx=mid(-self.mxx,self.dx,self.mxx)				
				--reduce the trail over time.
				self.dest_tick=max(0,self.dest_tick-1)
			end

			self.x+=self.dx
			if solidleft(self) then
				--self:on_end_tele()
			end

			--jump

			local jb=btn(2,1) or btn(2,0)

			if jb then

				self.jumpholdtime+=1

				--continuing a jump or
				--starting a new one on
				--the ground
				if self.jh>0
				or ((self.grounded or
							self.airtime<5)
						 and
						 (self.jrdy
						 or self.jumpholdtime<10))
				then
					if(self.jh==0)sfx(snd.jump)
					self.jh+=1
					if self.jh<self.mxjh then
						self.dy=self.jy
					end
				end

				self.jrdy=false
			else
				self.jh=0
				self.jrdy=true
				self.jumpholdtime=0
			end
			
			--y move
			self.dy+=g.grav
			local maxy=4
			if self.dest==nil then
				maxy=2
			end
			self.dy=mid(-maxy,self.dy,maxy)
			self.y+=self.dy

			--floor
			local landed=false
			for i=-2,2,2 do
			local tile=mget((self.x+i)/8,(self.y+4)/8)
			if fget(tile,0) or (fget(tile,1) and self.dy>=0) then
				self.dy=0
				self.y=(flr((self.y+4)/8)*8)-4
				self.grounded=true
				self.airtime=0
				landed=true
				self.dash_count=0
				self.combo=0
				--self:on_end_tele()
			end
			end

			if not landed then
				self:setanim("jump")
				self.grounded=false
				self.airtime+=1
			end

			--roof
			if fget(mget((self.x)/8,(self.y-4)/8),0) then
				self.dy=0
				self.y=flr((self.y-4)/8)*8+8+4
				self.jh=0
				--self:on_end_tele()
			end
			
			loop_pos(self)

			if self.grounded then
				--x anim
				if br then
					if self.dx<0 then
						self:setanim("slide")
					else
						self:setanim("walk")
					end
					self.flipx=false
				elseif bl then
					if self.dx>0 then
						self:setanim("slide")
					else
						self:setanim("walk")
					end
					self.flipx=true
				else
					self:setanim("stand")
				end
			end
			
			if self.dest!=nil then
				self:setanim("jump")
			end

			--flip
			if br or (self.dest!=nil and self.dx>0) then
				self.flipx=false
			elseif bl or (self.dest!=nil and self.dx<0)  then
				self.flipx=true
			end

			--anim tick
			self.animtick-=1
			if self.animtick<=0 then
				self.curframe+=1
				local a=
					self.anims[self.curanim]
				self.animtick=a.ticks
				if self.curframe>#a.frames then
					self.curframe=1
				end
			end
			
			local a=self.anims[self.curanim]
			local frame=a.frames[self.curframe]
			add(self.hist,{ pos=m_vec(self.x,self.y),frame=frame,flipx=self.flipx})
			if #self.hist>5 then
				del(self.hist,self.hist[1])
			end

		end,

		draw=function(self)
			
			if self.dest!=nil then
				--return
			end
			
			if(#self.hist==0) return
			
			if self.dest_tick>0 then
				if self.dest_tick>(self.post_dest_buffer*0.5) or self.dest_tick%2==0 then
					local c=7
					for i=0,15 do
						pal(i,c)
					end
				end
			
				for k,v in pairs(self.hist) do
					local x=v.pos.x
					local y=v.pos.y
					local f=v.frame
					local flipx=v.flipx
					spr(f,
						x-4,
						y-4,
						1,1,
						flipx,
						false)
				end
			end
				
			local v=self.hist[#self.hist]
			local x=v.pos.x
			local y=v.pos.y
			local f=v.frame
			local flipx=v.flipx
			spr(f,
				x-4,
				y-4,
				1,1,
				flipx,
				false)
				
				pal()
				
				--circ(self.x+4,self.y+4,self.tele_max,5)
		end,
		
		on_end_tele=function(self)
			if self.dest!=nil then
				self.dx*=0.55
				self.dy*=0.55
			end
			self.dest=nil
		end,
	}

	return p
end

function m_cam(t)
	local c=
	{
		tar=t,
		pos=m_vec(t.x,t.y),
		pullx=16,

		mn=m_vec(64,64),
		mx=m_vec(127*8,63*8),
		
		shake_remaining=0,
		shake_force=0,

		update=function(self)

			self.shake_remaining=max(0,self.shake_remaining-1)
			--follow target outside of
			--pull range.
			if self:pullmaxx()<self.tar.x+8 then
				--self.pos.x+=1
				self.pos.x+=min(self.tar.x+8-self:pullmaxx(),4)
				--self.pos.x+=(self.tar.x+8-self.pullx)
			end
			if self:pullminx()>self.tar.x then
				self.pos.x+=min((self.tar.x-self:pullminx()),4)
			end

			--lock to edge
			if(self.pos.x<self.mn.x)self.pos.x=self.mn.x
			if(self.pos.x>self.mx.x)self.pos.x=self.mx.x
		end,

		campos=function(self)
			--calculate camera shake.
			local shk=m_vec(0,0)
			if self.shake_remaining>0 then
				shk.x=rnd(self.shake_force)-(self.shake_force/2)
				shk.y=rnd(self.shake_force)-(self.shake_force/2)
			end
			return self.pos.x-64+shk.x,self.pos.y-64+shk.y
		end,

		pullmaxx=function(self)
			return self.pos.x+self.pullx
		end,

		pullminx=function(self)
			return self.pos.x-self.pullx
		end,
		
		shake=function(self,t,force)
			self.shake_remaining=t
			self.shake_force=force
		end
	}

	return c
end

--levels
--
levels=
{
	--intro
	{
		pos=m_vec(64,64),
		enemies=
		{
			{1,128-16,128-12-12,"kill...me...","more...",},
		}
	},
		--bb stage 1
	{
		pos=m_vec(128*3+64,64),
		enemies=
		{
			{1,32,16},
			{1,32+16,16+8},
			{1,32+32,16+16},
		}
	},
	--bb stage 2
	{
		pos=m_vec(128*4+64,64),
		enemies= 
		{
			{1,64+8,3*8},
			{1,64-8,3*8},
			{1,64+16,6*8},
			{1,64-16,6*8},
		}
	},
	--funnel
	{
		pos=m_vec(128*5 +64,64),
		enemies= 
		{
			{1,8+4,2*8+4},
			{1,16+4,2*8+4},
			{1,128-8-4,2*8+4},
			{1,128-16-4,2*8+4},
		}
	},
	--side pyramids
	{
		pos=m_vec(128*6 +64,64),
		enemies= 
		{
			{0,8+4,2*8+4},
			{0,32+4,2*8+4},
			{0,128-8-4,2*8+4},
			{0,128-32-4,2*8+4},
		}
	},
	--remake
	{
		pos=m_vec(128*2+64,64),
		enemies=
		{
			{1,32,128-16},
			{1,96,128-16},
			
			{0,16,64},
			{0,32,64},
			{0,96,64},
			{0,112,64},
		}
	},	
	--original
	{
		pos=m_vec(128*1+64,64),
		enemies=
		{
			{0,64,64},
			{0,32,32},
			{0,96,80},
			{1,96,80},
			{0,88,80},
			{0,80,80},
		}
	},
	--wip
	{
		pos=m_vec(128*7+64,64),
		enemies= 
		{
			{0,5*8+4,2*8+4},
			{0,10*8+4,2*8+4},
			{0,5*8+4,4*8+4},
			{0,10*8+4,4*8+4},
			
			{0,1 *8+4,2*8+4},
			{0,14*8+4,2*8+4}, 
			
			{0,56+4,14*8+4},
			{0,64+4,14*8+4},
			{0,48+4,14*8+4},
			{0,72+4,14*8+4},
		}
	},
	--ending 
	{
		pos=m_vec(128+64,128+64),
		enemies=
		{
		}
	},
}

current_level_id=-1

function load_next_level()
	load_level(current_level_id+1)
end

function load_level(id)

	streaks={}
	parts={}
	goons={}
	
	printh(id)
	
	-- do this before looping to avoid reseting music.
	if id==2 then
		music(mus.gameplay)
	elseif id==1 then
		music(mus.tutorial)
	end
	
	if id>#levels then
		id=1
	end
	
	local lvl=levels[id]
	if lvl!=nil then
		
		cam.mn=m_vec(lvl.pos.x,lvl.pos.y)
		cam.mx=m_vec(lvl.pos.x,lvl.pos.y)
		cam.pos=lvl.pos
		
		local left=lvl.pos.x-64
		local top=lvl.pos.y-64
		
		for k,v in pairs(lvl.enemies) do
			
			local make=nil
			local goon_type=v[1]
			if goon_type==0 then
				make=m_flyer
			elseif goon_type==1 then
				make=m_walker
			end
			
			local e=make(v[2]+left,v[3]+top)
			
			if v[4]!=nil then
						e.msg1=v[4]
			end
			if v[5]!=nil then
						e.msg2=v[5]
			end
			
		end
	
		current_level=lvl
		current_level_id=id
		
		if id==#levels then
			state=3
			updatehiscore()
		end
		
		p1:onloadlevel()
		
	end

end

function m_mouse()
	local o = 
	{
		pos=m_vec(0,0),
		
		btn_left=1,
		btn_right=2,
		btn_mid=4,
		
		on_wall=false,
		
		btn_state=
		{
			[1]=false,
			[2]=false,
			[4]=false,
		},
		
		btn_state_prev=
		{
			[1]=false,
			[2]=false,
			[4]=false,
		},

		update=function(self)
			self.pos.x = stat(32)+cam.pos.x-64
			self.pos.y = stat(33)+cam.pos.y-64
			
			for k,v in pairs(self.btn_state) do
				self.btn_state[k]=band(stat(34),k)!=0
			end
			
			self.on_wall=fget(mget(self.pos.x/8,self.pos.y/8),0) 
				or self.pos.x<=cam.mn.x-64 or self.pos.y<=cam.mn.y-64
				or self.pos.x>=cam.mx.x+64 or self.pos.y>=cam.mx.y+64
		end,
		
		post_update=function(self)
			for k,v in pairs(self.btn_state_prev) do
				self.btn_state_prev[k]=band(stat(34),k)!=0
			end
		end,
		--[[
		todo: knock enemy into air. hit while airborn to kill. maybe bubble bobble style levels.
		fire spit enemy
		electric enemy
		multihit enemy (shell)
		teleporter (attack forward and then behind)
		]]
		draw=function(self)
			--if (p1.dash_count>0) pal(7,8)
			--spr(16,self.pos.x-3,self.pos.y-3)
			
			local v=m_vec(self.pos.x-(p1.x),self.pos.y-(p1.y))
			local d,l=v:getnorm()
			
			local off=2*l*0.1
			self:draw_cursor(off,0,2)
			self:draw_cursor(-off,0,2)
			self:draw_cursor(0,off,2)
			self:draw_cursor(0,-off,2)
			self:draw_cursor(0,0,8)
			--[[
			local v=m_vec(self.pos.x-(p1.x+4),self.pos.y-(p1.y+4))
			local d,l=v:getnorm()
			local ml=p1.tele_max
			local len=min(l,4)
			if l>ml then
				--spr(16,(p1.x+4)+(d.x*ml)-3,(p1.y+4)+(d.y*ml)-3)
				local x=(p1.x+4)+(d.x*ml)
				local y=(p1.y+4)+(d.y*ml)
				line(x,y,x-d.x*len,y-d.y*len,7)
				--line(p1.x,p1.y,self.pos.x,self.pos.y,5)
				--line(self.pos.x+(cos(v.x)),self.pos.y,self.pos.x,self.pos.y,5)
			else
				--line(p1.x+4,p1.y+4,self.pos.x,self.pos.y,1)
				line(self.pos.x,self.pos.y,self.pos.x-d.x*len,self.pos.y-d.y*len,7)
			end
			--]]
			--pal()
			
			--pset(self.pos.x,self.pos.y,8)
			--line(self.pos.x,self.pos.y,p1.x,p1.y,10)
		end,
		
		draw_cursor=function(self,xo,yo,c)
			local v=m_vec(self.pos.x-(p1.x+xo),self.pos.y-(p1.y+yo))
			local d,l=v:getnorm()
			local ml=p1.tele_max
			local len=min(l,4)
			--[[
			if l>ml then
				--spr(16,(p1.x+4)+(d.x*ml)-3,(p1.y+4)+(d.y*ml)-3)
				local x=(p1.x+4)+(d.x*ml)
				local y=(p1.y+4)+(d.y*ml)
				line(x,y,x-d.x*len,y-d.y*len,7)
				--line(p1.x,p1.y,self.pos.x,self.pos.y,5)
				--line(self.pos.x+(cos(v.x)),self.pos.y,self.pos.x,self.pos.y,5)
			else
			--]]
				--line(p1.x,p1.y,self.pos.x,self.pos.y,1)
				pset(p1.x+(d.x*min(l,p1.tele_max)),p1.y+(d.y*min(l,p1.tele_max)),1)
				line(self.pos.x,self.pos.y,self.pos.x-d.x*len,self.pos.y-d.y*len,c)
			--end
		end,
		
		btn=function(self,id)
			return self.btn_state[id]==true
		end,
		
		btnp=function(self,id)
			return self.btn_state[id]==true and self.btn_state_prev[id]==false
		end,
	}
	
	--detect if a button was pressed when this mouse
	--was created.
	for k,v in pairs(o.btn_state_prev) do
		o.btn_state_prev[k]=band(stat(34),k)!=0
	end
	
	return o;
end

function m_score(_x,_y,_score)
	local o=
	{
		x=_x,
		y=_y,
		dx=0,
		dy=-0.1,
		
		score=_score,
		
		lifetime=60,
		
		u=function(self)
			self.x+=self.dx
			self.y+=self.dy
			self.lifetime-=1
			
			if self.lifetime<=0 then
				del(scores,self)
			end
		end,
		
		d=function(self)
			printc(""..self.score,self.x,self.y,7,0,0)
		end,
	}
	
	add(scores,o)
	
	return o
end

function m_walker(_x,_y)
	local o=m_goon(_x,_y,0.1,0)
	o.floating=false
	o.gravity=0.2
	o.anims=
	{
		["move"]=
		{
			ticks=5,
			frames={33,34,35,36,37,38},
		},
		["thrown"]=
		{
			ticks=5,
			frames={36,39,40,41},
		}
	}
	o.score=100
	return o
end

function m_flyer(_x,_y)

	local d={-0.1,0.1}
	local dx=d[flr(rnd(2))+1]
	local dy=d[flr(rnd(2))+1]
	local o=m_goon(_x,_y, dx, dy)
	o.floating=true
	o.gravity=0
	o.score=150
	return o
end

function m_goon(_x,_y,_dx,_dy)
	local o=
	{
		x=_x,
		y=_y,
		
		dx=_dx,
		dy=_dy,
		
		dx_orig=_dx,
		dy_orig=_dy,
		
		r=6,
		
		dam_tick=0,
		
		killed=false,
		thrown=false,
		thrown_ticks=0,
				
		floating=true,
		gravity=0,
		
		angry=false,
		ticks_to_angry=10*60,
		
		msg1=nil,
		msg2=nil,
		
		anims=
		{
			["move"]=
			{
				ticks=5,
				frames={18,19,20,21},
			},
			["thrown"]=
			{
				ticks=5,
				frames={18,22,23,24},
			},
		},

		curanim="move",
		curframe=1,
		animtick=0,
		
		setanim=function(self,anim)
			if(anim==self.curanim)return
			local a=self.anims[anim]
			self.animtick=a.ticks
			self.curanim=anim
			self.curframe=1
		end,
		
		u=function(self)
			self.dam_tick=max(0, self.dam_tick-1)
			
			if self.thrown then
				self.thrown_ticks+=1
				
				local tile=mget((self.x)/8,(self.y)/8)
				if self.thrown_ticks >self.ticks_to_angry and not fget(tile,0) then
					self.thrown=false
					self.thrown_ticks=0
					self:onangry()
				else
					self.dy+=0.02
					self.dx*=0.99
					if current_level!=nil then
						if self.x>=current_level.pos.x+56 then
							self.dx*=-1
							self.x=current_level.pos.x+56
						elseif self.x<=current_level.pos.x-56 then
							self.dx*=-1
							self.x=current_level.pos.x-56
						end
					end
				end
			else
				self.dy+=self.gravity
			end
			
			self.dx=mid(-4, self.dx,4)
			self.dy=min(self.dy,1)
			self.x+=self.dx
			self.y+=self.dy
			
			if not self.thrown then
				if not self.floating then
					local landed=false
					for i=-2,2,2 do
						local tile=mget((self.x+i)/8,(self.y+4)/8)
						if fget(tile,0) or (fget(tile,1) and self.dy>=0) then
							self.dy=0
							self.y=(flr((self.y+4)/8)*8)-4
							--self.grounded=true
							--self.airtime=0
							landed=true
							--self.dash_count=0
							--self:on_end_tele()
						end
					end
				else
					local landed=false
					for i=-2,2,2 do
						local tile=mget((self.x+i)/8,(self.y+4)/8)
						if fget(tile,0) or (fget(tile,1) and self.dy>=0) then
							self.dy*=-1
							self.y=(flr((self.y+4)/8)*8)-4
							--self.grounded=true
							--self.airtime=0
							landed=true
							--self.dash_count=0
							--self:on_end_tele()
						end
					end
					for i=-2,2,2 do
						local tile=mget((self.x+i)/8,(self.y-4)/8)
						if fget(tile,0) and self.dy<=0 then
							self.dy*=-1
							self.y=(flr((self.y-4)/8)*8)+4+8
							--self.grounded=true
							--self.airtime=0
							--landed=true
							--self.dash_count=0
							--self:on_end_tele()
						end
					end
				end
				local olddx=self.dx
				if (solidleft(self)) then
					self.dx=-olddx
				end
			end
			
			loop_pos(self)

			--anim tick
			self.animtick-=1
			if self.angry then
				self.animtick-=1
			end
			if self.animtick<=0 then
				self.curframe+=1
				local a=self.anims[self.curanim]
				self.animtick=a.ticks --todo + self.animtick to account for angry.
				if self.curframe>#a.frames then
					self.curframe=1
				end
			end
			
			if self.killed and self.dam_tick == 0 then
						del(goons,self)
			end
		end,
		
		d=function(self)
			
			if self.msg1 != nil then
				line(self.x,self.y,self.x+6,self.y-12,7)
			end
			
			local sn=(sin(t*0.01)*2)
			local flipx=self.dx<0
			local flipy=false
			if (self.thrown_ticks>0 and ((self.ticks_to_angry*0.75)<self.thrown_ticks)) then
				local td=max(4,((self.ticks_to_angry*0.75)-self.thrown_ticks))
				local c=9
				if td<=4 then
					c=8
				end
				if(t%td<(td*0.5))c=10
				for i=0,15 do
					pal(i,c)
				end
				sn=0
			elseif self.angry then
				for k,v in pairs(pal_map[3]) do
					pal(v[1],v[2])
				end
			end
			
			if not floating then
				sn=0
			end
			
			local a=self.anims[self.curanim]
			local frame=a.frames[self.curframe]
			spr(frame,self.x-4,self.y-4+sn,1,1,flipx,flipy)
			pal()
			
			if self.msg1 != nil then
				local msg=self.msg1
				if self.thrown then
					msg=self.msg2
				end
				
				printc(msg,self.x+8,self.y-16,7,0,0)
			end
		end,
		
		onhit=function(self,hitter)
		
			local dohit=false
			if not self.thrown then
				self.thrown=true
				self.dy=-2
				self.dx=mid(hitter.dx,-2,2)
				self.thrown_ticks=0
				dohit=true
				self.angry=false
				self:setanim("thrown")
				sfx(snd.hit)
			elseif not self.killed and self.thrown_ticks>10 then
				self.dam_tick=2
				self.killed=true
				explode(self,m_vec(hitter.dx,hitter.dy),{8,9,10})
				dohit=true
				sfx(snd.kill)
				hitter.combo+=1
				add_score(self,hitter)
			end
			if dohit then
				cam:shake(5,1)
				hitter.hit_tick=10
				hitter.dash_count=0
			end
		end,
		
		onangry=function(self)
			if not self.angry then
				self.dx=8*self.dx_orig
				self.dy=8*self.dy_orig
				self.angry=true
				self.thrown=false
				self:setanim("move")
			end
		end,
	}
	add(goons,o)
	return o
end

function add_score(goon,hitter)
	local msg=goon.score
	if hitter.combo>1 then
		msg=""..msg.."x"..hitter.combo
	end
	m_score(goon.x,goon.y,msg)
	score+=goon.score
end

function updatehiscore()

	local oldscore=dget(0)
	if oldscore<score then
		dset(0,score)
		hiscore=score
		gothiscore=true
	end

end

function explode(p,vel,cols)
	local s=1
	local h=2
	local g=0.1

	
	function pick_color()
		local i=flr(rnd(#cols))
		local col= cols[i+1]
		return col
	end
	
	local c=pick_color()
	--flying blood
	mkstreak(p.x,p.y,
		vel.x,vel.y,c,h,g*(rnd(1)+0.5),1)
	local c=pick_color()
	mkstreak(p.x,p.y,
		vel.x+1,vel.y,c,h,g*(rnd(1)+0.5),1)
	local c=pick_color()
	mkstreak(p.x,p.y,
		vel.x-1,vel.y*2,c,h,g*(rnd(1)+0.5),1)
	local c=pick_color()
	mkstreak(p.x,p.y,
		vel.x,vel.y,c,h,g*(rnd(1)+0.5),1)
end

--http://www.lexaloffle.com/bbs/?tid=28406
poly= 
{
 xc=64,
 yc=64,
 pts=5, -- points in polygon 
 r=64,  -- radius
 rot=0,
 d=1,
 f=0, --frames
	
	update=function(self)
		self.rot+=self.d/200
		self.f+=1
	end,
	
	draw=function(self)
		local p={}
		local ang=(1/self.pts)
		for i=1,self.pts,1 do
			local x0=self.xc+self.r*cos(ang*i+self.rot)
			local y0=self.yc+self.r*sin(ang*i+self.rot)
			local x1=self.xc+self.r*cos((ang*(i+2)+self.rot))
			local y1=self.yc+self.r*sin((ang*(i+2)+self.rot))
			line(x0,y0,x1,y1,8) --perimeter
			line(self.xc,self.yc,x1,y1,2) --centre out
			circ(self.xc,self.yc,self.r,8)
		end
	end,
}

function _init()
	poke(0x5f2d, 1)
	reset()
end

function reset()

	t=0
	state=0
	tstate=0
	score=0
	streaks={}
	goons={}
	parts={}
	scores={}
	hiscore=dget(0)
	p1=m_player(64,64)
	p1:setanim("walk")
	cam=m_cam(p1)
	mouse=m_mouse()
	--load_level(1)
	music(mus.title)
	
end

function _update60()
	t+=1
	tstate+=1

	mouse:update()
	
	if state==0 then
		if btnp(4,1) or btnp(5,1) or btnp(4,0) or btnp(5,0) or mouse:btnp(mouse.btn_left) then
			state=1
			tstate=0
			sfx(snd.start)
			--music(mus.tutorial)
			load_level(1)
		end
		poly:update()
		for k,v in pairs(streaks) do
			v:u()
		end
		mouse:post_update()
		return
	end
	
	if state==3 then
		if mouse:btnp(mouse.btn_left) then
			reset()
		end
		mouse:post_update()
		return
	end
	
	--skip levels
	--[[
	if btnp(5) then
		--reset()
		load_next_level()
	end
	--]]
	
	if p1.lives==0 then
		if state!=2 then
			music(mus.gameover)
			updatehiscore()
			tstate=0
		end
		state=2
	end
	
	if #goons==0 and trans==-1 then
		--load_next_level()
		trans_dir=1
		trans=0
		sfx(snd.lvl_complete)
	end
		
	if state==2 then
		if btnp(4,1) or btnp(5,1) or btnp(4,0) or btnp(5,0) or mouse:btnp(mouse.btn_left) then
			reset()
		end
		return
	end
	
	if p1.hit_tick>0 then
		p1.hit_tick=max(p1.hit_tick-1,0)
		return
		--if t%4!=0 then return end
	end
	
	p1:update()
	--update streaks.
	for k,v in pairs(streaks) do
		v:u()
	end
	
	for k,v in pairs(parts) do
		v:u()
	end
	
	for k,v in pairs(goons) do
		v:u()
	end
	
	for k,v in pairs(scores) do
		v:u()
	end
	
	--[[
	if (mouse:btnp(mouse.btn_left)) and p1.dest_tick==0 then
		local speed=8
		local newd=m_vec(mouse.pos.x-(p1.x+4),mouse.pos.y-(p1.y+4))
		newd=newd:getnorm()
		orb=mkstreak(p1.x+4,p1.y+4,
		newd.x*speed,newd.y*speed,8,5,0.1,1)
	end
--]]
	
	--the streak
	if (abs(p1.dx)>0.5 or abs(p1.dy)>0.5) and p1.dest_tick>0 then
		local c={1,2,5,6,7,8,9}
		local limit=2--min(p1.dest_tick,6)
		for i=-2,limit do
			local s=mkstreak(p1.x+rnd(4)-2,p1.y+i,
				-p1.dx,-p1.dy,c[flr(rnd(#c))+1],5,0,1)
			s.lifetime=rnd(5)
		end
	end
	
	cam:update()
	mouse:post_update()
end

local d,m,l=5,6,7
pal_map=
{
	{
		{0,0},
		{1,d},
		{2,d},
		{3,d},
		{4,d},
		{5,d},
		{6,m},
		{7,l},
		{8,d},
		{9,m},
		{10,9},
		{11,3},
		{12,1},
		{13,m},
		{14,13},
		{15,14},
	},
	
	{
		{0,0},
		{1,d},
		{2,d},
		{3,d},
		{4,d},
		{5,d},
		{6,m},
		{7,l},
		{8,d},
		{9,m},
		{10,8},
		{11,2},
		{12,d},
		{13,m},
		{14,1},
		{15,2},
	},
	
	{
		{0,0},
		{1,d},
		{2,d},
		{3,d},
		{4,d},
		{5,d},
		{6,m},
		{7,l},
		{8,8},
		{9,m},
		{10,l},
		{11,l},
		{12,l},
		{13,m},
		{14,l},
		{15,l},
	},
	
		--death
	{
		{0,8},
		{1,0},
		{2,0},
		{3,0},
		{4,0},
		{5,0},
		{6,0},
		{7,0},
		{8,0},
		{9,0},
		{10,0},
		{11,0},
		{12,0},
		{13,0},
		{14,0},
		{15,0},
	},
	
	--invert
	{
		{0,7},
		{1,8},
		{2,10},
		{3,4},
		{4,3},
		{5,6},
		{6,5},
		{7,0},
		{8,11},
		{9,2},
		{10,2},
		{11,8},
		{12,8},
		{13,9},
		{14,11},
		{15,2},
	}
}

--print string with outline.
function printo(str,startx,
															 starty,col,
															 col_bg)
	print(str,startx+1,starty,col_bg)
	print(str,startx-1,starty,col_bg)
	print(str,startx,starty+1,col_bg)
	print(str,startx,starty-1,col_bg)
	print(str,startx+1,starty-1,col_bg)
	print(str,startx-1,starty-1,col_bg)
	print(str,startx-1,starty+1,col_bg)
	print(str,startx+1,starty+1,col_bg)
	print(str,startx,starty,col)
end

--print string centered with 
--outline.
function printc(
	str,x,y,
	col,col_bg,
	special_chars)

	local len=(#str*4)+(special_chars*3)
	local startx=x-(len/2)
	local starty=y-2
	printo(str,startx,starty,col,col_bg)
end

txtplt={7,7,10,10,10,9,9,9,9,4,4,2,1}
txtpltb={9,9,4,4,4,4,2,2,2,2,1,1,0,0}
function sqr(a) return a*a end
function round(a) return flr(a+0.5) end
function printtitle(str,x,y)

	--[[
	i=0
	for i=1,#txtplt do
		print(str,(128-(#str*4)-7)+(sin(i*0.1*(t*0.01))*2),64+i,txtplt[i])
	end
	printo(str,128-(#str*4)-7,64+i,6,5,0)
	--printo(str,128-(#str*4)-7,64,6,5,0)
	--]]
	print(str,64-((#str/2)*4),64+1,5)
	print(str,64-((#str/2)*4),64,7)
	--printc(str,64,64,7,5,0)
	
end

function w2m(x,y)
		if current_level!=nil then
			local left=current_level.pos.x-64
			local top=current_level.pos.y-64
			x+=left
			y+=top
		end
		return x,y
end

function easeoutquint(t, b, c, d)
	t /= d;
	t-=1;
	return c*(t*t*t*t*t + 1) + b;
end

function easeoutelastic(t, b, c, d)
	t/=d
	ts=(t)*t;
	tc=ts*t;
	return b+c*(33*tc*ts + -106*ts*ts + 126*tc + -67*ts + 15*t);
end

function _draw()

	cls(0)
	
	if state==0 then
	
		--poly:draw()
		--local text="treacherous tower"
		--printtitle(text,64,64,1)
		local speed=t*0.5
		for i=0,9 do
			--map(16,16,0,(i*128)-speed,16,16)
		end
		for y=0,16 do
			for x=-1,16 do
				--spr(16,(x*8+sin(t*0.005)*8),y*8-flr(speed%8))
			end
		end
		palt(2,true)
		palt(0,false)
		--[[
		for y=0,16 do
			for x=-1,16 do
				if x > 12 or x < 3 then
					spr(17,x*8,y*8)
				elseif x > 10 or x < 5 then
					spr(48,x*8,y*8)
				end
			end
		end
		--]]
		
		--[[
		local x = 0
		local c={7,7,10,10,10,9,9,9,9,4,4,2,1}
		while x < 32 do
			line(x,0,x,128,0)
			x+=x*0.1+1
		end
		--]]
		
		palt()
		
		pal()
		for i=-2,18 do
			for j=-2,18 do
				spr(16,i*8+sin(time()*0.1+j/16)*8-4,j*8+sin(time()*0.1+i/16)*8-4)
			end
		end
		
		--[[
		local s=mkstreak(rnd(128),128,
			rnd(2)-1,rnd(1)-2,0,5,0,1)
		s.lifetime=rnd(10)+120
		--]]
		
		--[[
		local c={7}
		for i=0,20 do
		local s=mkstreak(rnd(128),130,
			rnd(2)-1,-rnd(4),c[flr(rnd(#c))+1],2,0,1)
		s.lifetime=rnd(20)+1
		end
		--]]
		local yease=easeoutelastic(min(t,64),-64,64,64)
		---64+(cos(min(t+32,64)/64)*64)
		map(0,16,0,yease,16,16)     
		
			if t%120<1 then
			local c={8,2}
			local bx={10,18,31,55,64,76,86,96,100,112,114,115}
			local xx=bx[flr(rnd(#bx))+1]
			--local limit=50--min(p1.dest_tick,6)
			--local i=rnd(limit*2)-limit
			--for i=-limit,limit do
			for i=-1,1 do
				local s=mkstreak(xx+i,28,
					0,0,c[flr(rnd(#c))+1],5,rnd(0.01)+0.02,1)
				--s.lifetime=rnd(0)+15
			end
			end
		for k,v in pairs(streaks) do
			v:d()
		end
		
		if t>=100 then
			if t%60<40 then
			printc("click to start",64,85,7,0,0)
			end
			printo(
				"    audio           code          art",
				(sin((t*0.002))*20)-17,128-14,1,0)
			printo(
				"@gruber_music | @matthughson | @siskavard",
				(sin((t*0.002))*20)-17,128-6,1,0)
				
		end
		
		mouse:draw()
		
		if t<64 or (t<100 and t%4<2) then
			p=pal_map[4]
			for k,v in pairs(p) do
				pal(v[1],v[2],1)
			end
		end
		return
	end
	
	
	camera(cam:campos())
	
	if state==3 then
	
		for i=-2,18 do
			for j=-2,18 do
				local x,y=w2m(i*8+sin(time()*0.1+j/16)*8-4,j*8+sin(time()*0.1+i/16)*8-4)
				spr(16,x,y)
			end
		end
	
		local x,y=w2m(64,64)
		printc("thanks for playing!",x,y,7,0,0)
		
		printh(t)
		if t>=100 then
			if t%60<40 then
				local x,y=w2m(64,85)
				printc("click to continue",x,y,7,0,0)
			end
			local x,y=w2m((sin((t*0.002))*20)-17,128-14)
			printo(
				"    audio           code          art",
				x,y,1,0)
			local x,y=w2m((sin((t*0.002))*20)-17,128-6)
			printo(
				"@gruber_music | @matthughson | @siskavard",
				x,y,1,0)
		end		
	end
	
	map(0,0,0,0,128,128)
	for k,v in pairs(streaks) do
		v:d()
	end
	for k,v in pairs(parts) do
		v:d()
	end
		for k,v in pairs(goons) do
		v:d()
	end
	for k,v in pairs(scores) do
		v:d()
	end
	--line(p1.x+4,p1.y+4,mouse.pos.x,mouse.pos.y,1)
	if state!=3 then
		p1:draw()
	end
	mouse:draw()
	--print(stat(34))
	
	if current_level_id==1 and state!=2 then

		function draw_key(x,y,key)
			spr(9,x-2,y-1)
			print(key,x,y+1,13)
			print(key,x,y,7)
		end
		
		local x,y=50,29
		draw_key(x,y,"e")
		draw_key(x-8,y+8,"s")
		draw_key(x,y+8,"d")
		draw_key(x+8,y+8,"f")
		
		printc("move",x+2,y+20,7,1,0)
		printc("attack",80,y+20,7,1,0)
		
		printc("fullscreen recommended",64,y+42,1,0,0)
		
		--[[
		local i=2
		printc("e key to jump",64,i*8,7,0,2)
		i+=1
		printc("s and f keys to move",64,i*8,7,0,2)
		
		i+=2
		printc("mouse to aim",64,i*8,7,0,0)
		i+=1
		printc("click to attack",64,i*8,7,0,0)	
		i+=2
		printc("fullscreen recommended",64,i*8,7,0,0)
		--]]
	end
	
	if p1.dash_count>0 then
		
		--if p1.tele_tick>15 then 
			p=pal_map[3]
		--elseif p1.tele_tick>10 then 
		--	p=pal_map[2]
		--else 
		--	p=pal_map[1] 
		--end
		for k,v in pairs(p) do
			pal(v[1],v[2],1)
		end
	end
	
	if p1.took_hit==true and state!=2 then 
		p=pal_map[4]
		for k,v in pairs(p) do
			pal(v[1],v[2],1)
		end
	end
	
	--hud
	camera(0,0)

	if trans_dir!=0 then
		--for every tile...
		for tx=0,16 do
			for ty=0,16 do
				--and every pixel in that
				--tile...
				
				if trans_dir>0 then
					for y=0,trans-1 do
						for x=0,trans-1-y do
							local nx,ny=tx*8+x,ty*8+y--[[w2m]]
							pset(nx,ny,0)
						end
					end
				elseif trans_dir<0 then
					for y=trans-1,0,-1 do
						for x=trans-1-y,0,-1 do
							local nx,ny=tx*8+x,ty*8+y--[[w2m]]
							pset(nx,ny,0)
						end
					end
				end
			end
		end
		
		trans+=trans_dir
		
		if trans_dir>0 and trans==16 then
			trans_dir=-1
			if state!=3 then
				load_next_level()
			end
		elseif trans_dir<0 and trans==0 then
			trans_dir=0
			trans=-1
		end
	end
	
	for i=0, p1.lives-1 do
		spr(32,52+(i*8),0)
	end

	printo("score:"..score,0,0,7,0)

	local str="best:"..hiscore
	local len=#str*4
	local startx=128-len
	printo(str,startx,0,7,0)
	
	if state==2 then
		local yease=easeoutquint(min(tstate,256),-16,64,256)
		printh(tstate..","..yease)
		--printc("game over",64,64,7,0,0)
		sspr(0*8,14*8,9*8,2*8,64-((9*8)/2),yease)
		printc("click to restart",64,64+8,7,0,0)
		if tstate<126 or (tstate<256 and tstate%4<2) then
			p=pal_map[4]
			for k,v in pairs(p) do
				pal(v[1],v[2],1)
			end
		end
	end
		
end
if(_update60)_update=function()_update60()_update_buttons()_update60()end