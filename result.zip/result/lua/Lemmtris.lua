--lemmtris by movax13h
--music by pizza
--july 2015

f=0
lvl=-1
lock_id=0
lemm={}
ufo={}
block=false
max_fall=15

tet_seq={
  {0,1,2,3,4,5,6},
  {1,3,0,4,2,5,6},
  {5,1,4,6,2,0,3},
  {2,3,1,4,5,6,0}, 
  {0,1,2,3,4,5,6},
  {1,0,2,3,4,5,6},
  {3,3,4,1,0,2,3,1,2,5,6},
  {2,5,6,1,0,3,4,6,1,6,3,3},
}

music_start={9,24,15,5}

game={}
game.state=-1
game.life=false --current lvl has life-up
game.lifes_done={}

player={}
player.lifes=3

anims={}

function _init()
  setup_starfield()
  music(0,0,7)
end

-- update ----------------------
function _update()
  f+=1

  if game.state==-3 then
    if btnp(5) then 
      restart_level()
      game.state=0
    elseif anybtn() then game.state=0 end
    return
  end

  --intro
  if game.state==-1 then
    if anybtn() then 
      music(-1,200,7)
      game.state=0 
      next_level()
    end
    return
  end

  --level transition
  if game.state==-2 then
    f+=4
--double speed
    if f>=127 then 
      game.state=0
      next_level()
    end
    return
  end

  --game
  update_ufo()

  if game.state==0 then
    if btnp(5) then game.state=-3 end
    update_lemm()
    update_tetris()
    update_anims()
  end
  
  --dead
  if game.state==1 then
    update_lemm()
    if anybtn() then
      restart_level()
      game.state=0
    end
  end
  
  -- game over or end of game
  if game.state>=2 then
    if anybtn() then
      run() --restart cartridge
    end
  end
  
end

-- draw ------------------------
function _draw()
  cls()

  --palfade for block drop
  if ufo.mode==4 and ufo.f<8 then
    --for i=0,16 do  
      --pal(i,sget(11*8+4+flr(ufo.f*0.5)%3,16+i),1)
    --end
  elseif (game.state==-1 or lvl==0) and f<6 then
    for i=0,16 do  
      pal(i,sget(11*8+7-flr(f*0.5),16+i),1)
    end
  else pal() end
  
  draw_starfield()
  
  --intro
  if game.state==-1 then
    draw_intro()
    return
  end
  
  --end of game
  if game.state==3 then
    draw_end()
    return
  end
  
  --transition
  if game.state==-2 then
    mapdraw(lvl*16+flr(f/8),0,-f%8-8,0,17,16)
    return
  else --game
    mapdraw(lvl*16,0,0,0,16,16)
  end
  
  draw_anims()
  draw_ufo()
  draw_tetris()
  draw_lemm()

  if game.state==-3 then
    print("restart level?",39,36,7)
    print("press x to confirm!",28,46,7)
  end

--print(lemm.fallctr,10,10,7)

  if game.state==1 then
    if lemm.crushed then
      print("murder!!!",50,46,8)
    else 
      print("lemming lost!",41,46,8)
    end
  end
  
  if game.state==2 then
    print("game over!",48,46,8)
  end
  
  if game.state!=0 then
    print("press button",43,60,f%16)
  end

  for i=1,player.lifes do
    spr(26,50+i*8,118,1,1)
  end
  
  --print(block_id,10,10,7)
  print("next:",7,120,6)
  print("next:",7,119,1)
  print("level "..(lvl+1),94,120,6)
  print("level "..(lvl+1),94,119,1)
end

function anybtn()
  return btnp(0) or btnp(1) or btnp(2) or btnp(3) or btnp(4) or btnp(5)
end

-- logic 
function dead()
  sfx(-1,3)
  music(32,0)
  
  --sfx(-1,2)
  player.lifes-=1
  if player.lifes<=0 then
    game.state=2--game over
  else
    game.state=1--murder or fall
  end
end

-- level -----------------------
function restart_level()
  lvl-=1
  next_level()
end

function level_done()
  sfx(-1)
  sfx(5,3)
  
  if lvl+1>=count(tet_seq) then
    f=0
    game.state=3
    music(31,0)
  else
    f=1
    game.state=-2
  end
end

function next_level()

  f=0
  lvl+=1

  anims={}
  
  block_id=0
  block=false
  
  lemm.f=0
  lemm.ur=3 -- update rate
  lemm.mode=0 -- 0=wlk,1=clmb,2=fall
  lemm.left=false
  lemm.dead=false
  lemm.crushed=false
  lemm.fallctr=0

  ufo.f=0
  ufo.x=200
  ufo.y=10
  ufo.mode=0 --0=out,1=fly-in,2=fly-out
  
  setup_level()
  next_block()
  
  music(music_start[lvl%count(music_start)+1])
end

function next_block()
  block_id+=1
  if block_id>count(tet_seq[lvl+1]) then block_id=1 end
  ufo.f=0
  ufo.mode=1
end

function get_block_type(id)
  if id>count(tet_seq[lvl+1]) then id=1 end
  return tet_seq[lvl+1][id]
end

function setup_level()
  --restore map data from cart
  reload(0x2000,0x2000,0x1000)
  
  game.life=false
  
  --find specific sprites
  for y=0,15 do for x=0,15 do
    if cell_flag(x,y,1) then
      lemm.x=x*8
      lemm.y=(y-1)*8
      cell_set(x,y,40)
    elseif cell_flag(x,y,7) then
      local anim={}
      anim.f=x+y
      anim.spr=144
      anim.len=5
      anim.x=x*8
      anim.y=y*8
      add(anims,anim)
      cell_set(x,y,0)
    elseif cell_flag(x,y,6) then
      if not game.lifes_done["lvl"..lvl] then
        local anim={}
        anim.f=x+y
        anim.spr=179
        anim.len=4
        anim.x=x*8
        anim.y=y*8
        game.life = anim
        add(anims,anim)
      end
      cell_set(x,y,0)
    end
  end end
end


-- animations ------------------
function update_anims()
  for anim in all(anims) do
    anim.f+=0.25
  end
end


-- ufo -------------------------
function update_ufo()
  if (game.state==3) return
  if (ufo.mode==0) return

  ufo.f+=1

  if ufo.mode==1 then --fly-in
    if ufo.f==1 then 
      --sfx(3,3) 
    end
    local dx=56-ufo.x
    ufo.x+=dx*0.2
    if abs(dx)<3 then 
      ufo.f=0
      ufo.x=56
      ufo.mode=2
    end
    return
  end
  
  if ufo.mode==2 then --beam out
    --if ufo.f==1 then sfx(2,3) end--beamsnd
    if ufo.f==20 then
      -- create new block
      local type=tet_seq[lvl+1][block_id]
      new_block(type)
    elseif ufo.f>20 then
      if btn(0) then
        ufo.x-=1
        if(ufo.x<0) ufo.x=0
      end
      if btn(1) then
        ufo.x+=1
        if(ufo.x>104) ufo.x=104
      end
      if (btnp(2)) rot_block(block.rot+1)
      if (btnp(3)) rot_block(block.rot+3)
      if btnp(4) then 
        sfx(0,3) -- block resize
        ufo.mode=3
        block.x=flr(block.x)
        block.tx=flr((block.x-4)/8)*8
      end
    end
    return
  end
  
  if ufo.mode==3 then --dropping
    if not block then
      ufo.f=0
      ufo.mode=4
      --sfx(-2,3)--loop off beamsnd
      sfx(1,3)
    end
    return
  end
  
  if ufo.mode==4 then --waiting
    if ufo.f == 30 then
      sfx(4,3)--flyoutsnd
      ufo.mode=5
    end
  end
  
  if ufo.mode==5 then --fly-out
    local dx=-100-ufo.x
    ufo.x+=dx*0.2

    if lemm.dead and game.state==0 then
      dead()
      return
    end
    
    if not lemm.dead and abs(dx)<3 then 
      ufo.f=0
      ufo.mode=1
      next_block()
    end
    return
  end
  
end

function draw_anims()
  for anim in all(anims) do
    spr(anim.spr+flr(anim.f)%anim.len,anim.x,anim.y,1,1)
  end
end

function draw_ufo()
  if ufo.mode==0 then return end

  local x=ufo.x
  local y=ufo.y

  if ufo.mode==2 or ufo.mode==3 then  
    spr(57+f%2,x+4,y+5,1,1) --beam
    if (ufo.f<19) rectfill(x+2,y+6+ufo.f%19,x+16,y+30,0)
  end
  
  spr(41,x,y,2,1)
  
  --print("ufo mode "..ufo.mode,50,117,2)
end

-- tetris ----------------------
function update_tetris()
  if not block then return end

  if ufo.mode==2 then --place
    block.x=ufo.x+7-block.size
    block.y=ufo.y+16
    block.ds=find_dropspot()
  end
  
  if ufo.mode==3 then --drop
    if block.x>block.tx then block.x-=2 end
    if block.x<block.tx then block.x+=2 end
    if abs(block.x-block.tx)<=2 then block.x=block.tx end
    if block.size<8 then block.size+=1 end
    if block.y<block.ds*8 then 
      if coll_lemm_tet() and not lemm.crushed then 
        lemm.crushed=true
        kill_lemm()
      else
        block.y+=1
      end
    else
      store_block()
      block=false
      if lemm.dead then dead() end
    end
  end
end

function coll_lemm_tet()
  for by=0,3 do for bx=0,3 do
    if sget(32+bx+block.rot*4,32+by+block.type*4)==7 then
      local x=block.x+bx*8
      local y=block.y+by*8
     
      if abs(lemm.x-x) < 4 and
         abs(lemm.y+6-y) < 8 
      then
        return true
      end
    end
  end end
  return false
end

function draw_tetris()
  -- draw preview block
  local bt=get_block_type(block_id+1)
  local bx=30
  local by=118
  if bt==0 then 
    bx-=2
    by-=2 
  end
  if bt==3 then bx-=2 end
  draw_block(bx,by,bt,0,4,true)

  if not block then return end

  -- draw active block
  local dx=0
  if ufo.mode==2 and (block.type==0 or block.type==3) then dx=-2 end
  local data=draw_block(block.x+dx,block.y,block.type,block.rot,block.size,false)

  -- dropspot indicator
  if block.ds>-1 and ufo.mode==2 then
    local i=0
    for by=0,3 do for bx=0,3 do
      i+=1
      if data[i] then
        local x=flr((block.x-4)/8+bx)*8
        local y=block.ds*8+by*8
        rect(x,y,x+7,y+7,1)
      end
    end end
  end
end

function draw_block(x,y,type,rot,size,gui)
  local data={}
  local t=type*4
  if gui then t=16 end
  
  for by=0,3 do for bx=0,3 do
    if sget(32+bx+rot*4,32+by+type*4)==7 then
      add(data,true)      
      sspr(t,48,4,4,x+bx*size,y+by*size,size,size)
    else
      add(data,false)
    end
  end end
  return data
end

function find_dropspot()
  for y=0,16 do
    for by=0,3 do for bx=0,3 do
      if sget(32+bx+block.rot*4,32+by+block.type*4)==7 then
        if cell_flag(flr((block.x-4)/8)+bx,y+by,0) then return y-1 end
      end
    end end
  end
  return -1
end

function new_block(type)
  block={}
  block.type=type
  block.rot=0
  block.x=40
  block.y=40
  block.ds=-1
  block.size=3
end

function rot_block(rot)
  rot=rot%4
  block.rot=rot
end

function store_block()
  for by=0,3 do for bx=0,3 do
    if sget(32+bx+block.rot*4,32+by+block.type*4)==7 then
      local r=flr(rnd(2))
      cell_set(flr(block.x/8)+bx,flr(block.y/8)+by,15+16*r)
    end
  end end
end

-- lemming ---------------------  
function kill_lemm()
  if lemm.dead then return end
  lemm.dead=true
  lemm.f=0
  --lemm.y+=8
end

function draw_lemm()
  if lemm.dead then
    if lemm.fallctr>max_fall then
      spr(118+lemm.f,lemm.x,lemm.y+8,1,1)
    else
      spr(44+lemm.f,lemm.x,lemm.y+8,1,2)
    end
  else -- walking and falling
    local l=8
    if lemm.mode==2 then l=4 end
    spr(lemm.f%l+32*lemm.mode,lemm.x,lemm.y,1,2,lemm.left)
  end
end

function update_lemm()
  if lemm.dead then
    if lemm.fallctr>max_fall then
      if lemm.f<7 then lemm.f+=1 end
    else
      if f%2>0 then return end
      if lemm.f<3 then lemm.f+=1 else
        
      end
    end
    return
  end

 	if f%lemm.ur>0 then return end
  lemm.f+=1 
    
  -- walking
  if lemm.mode==0 then
    
    coll_lemm_life()
    
    lemm.fallctr=0
    if lemm.left then
      -- check falling
      if not px_flag(lemm.x+6,lemm.y+16,0) and
         not px_flag(lemm.x+2,lemm.y+16,0) then
        lemm.f=0
        lemm.ur=2
        lemm.mode=2
      -- check left
      elseif px_flag(lemm.x,lemm.y+8,0) or
             px_flag(lemm.x,lemm.y,0) then
        lemm.f=0 
        if px_flag(lemm.x,lemm.y,0) or
           px_flag(lemm.x,lemm.y-8,0) then
          lemm.left=false
        else
          lemm.mode=1
          lemm.x-=1
        end
      else lemm.x-=1 end
    else
      -- check falling
      if not px_flag(lemm.x+1,lemm.y+16,0) and
         not px_flag(lemm.x+5,lemm.y+16,0) then
        lemm.f=0
        lemm.ur=2
        lemm.mode=2
      -- check right
      elseif px_flag(lemm.x+7,lemm.y+8,0) or
             px_flag(lemm.x+7,lemm.y,0) then
        lemm.f=0 
        if px_flag(lemm.x+7,lemm.y,0) or
           px_flag(lemm.x+7,lemm.y-8,0) then
          lemm.left=true
        else
          lemm.mode=1
          lemm.x+=1
        end
      else lemm.x+=1 end
    end

    if lemm.x>125 then
      level_done()
    end
    
    if lemm.x<-6 then
      kill_lemm()
      dead()
    end
    
  -- climbing
  elseif lemm.mode==1 then
    if lemm.f==7 then 
      if lemm.left then lemm.x-=2
      else lemm.x+=2 end
      lemm.y-=8
      lemm.mode=0 
      lemm.f=0
    end
  -- falling
  else
    lemm.fallctr+=1
    lemm.y+=2
    -- check landing
    if px_flag(lemm.x+4,lemm.y+16,0) then
      lemm.mode=0
      lemm.f=0
      lemm.ur=3
      if lemm.fallctr>max_fall then
        kill_lemm()
        dead()
        sfx(1,3) -- crush
      else
        --sfx(7) -- landing
      end
    end
  end  

end

function coll_lemm_life()
  if game.life == false then return end

  if abs(game.life.x+4-lemm.x)<4 and
     abs(game.life.y-4-lemm.y)<8 
  then
     del(anims,game.life)
     game.life=false
     game.lifes_done["lvl"..lvl]=true
     player.lifes+=1
     sfx(6,3)

  end
end

-- maps ------------------------
function cell_set(x,y,id)
  mset(x+lvl*16,y,id)
end

function cell_flag(x,y,flag)
  local id=mget(x+lvl*16,y)
  return fget(id,flag)
end

function px_flag(x,y,flag)
  if x>127 then return false end
  if x<0 then return false end
  local id=mget(flr(x/8)+lvl*16,flr(y/8))
  return fget(id,flag)
end

-- starfield -------------------
stars={}

function setup_starfield()
  for i=0,20 do
    s={}
    s.spd=rnd(4)+1
    s.type=flr(rnd(4))
    add(stars,s)
  end
end

function draw_starfield()
  local i=0
  for s in all(stars) do
    local x=((f+200)*s.spd)%138-5
    sspr(32+s.type*3,7*8+5,3,3,x,i)
    i+=4
  end
end

-- intro -----------------------

function draw_intro()
  mapdraw(112,48,0,0,16,16)

  print("controls",2,98,9)
  print("c .. drop brick",2,106,9)
  print("x .. restart level",2,113,9)

  for i=0,8 do
    sspr(6*8,6*8+i,40,1,44+max(-34,min(34,80*sin(f*0.01+i*0.01))),6+i)
  end

  if f==900 then sfx(-2,3) end
  if f>3400 then --1600
    f=0 
    intro.s=0
  end

  local c=f%60
  local d=flr(10*c/60)
  
  if c==0 then intro.s+=1 end
  intro_text(intro.s-2,34-d,1)
  intro_text(intro.s-1,44-d,5)
  intro_text(intro.s  ,54-d,7)

  spr(179+flr(f*0.2)%4,0,6,1,1)
  spr(179+(flr(f*0.2)+2)%4,120,6,1,1)
  
  if f<420 then --walk
    spr(flr(f*0.25)%8,-10+f*0.25,72,1,2)
  elseif f<445 then --fall
    spr(64+flr(f*0.25)%4,95,74+f-420,1,2)
  else --dead
    if f==445 then sfx(1,3) end
    spr(118+min(7,f-445),95,104,1,2)
    if f>600 then --lemm2 walk
      spr(flr(f*0.25)%8,-10+(f-600)*0.25,72,1,2)
      if f>800 then --ufo
        if f==801 then sfx(2,3) end
        local x=flr(92+0.25*max(0,840-f)*sin(f*0.04))
        if f>1000 then x-=(f-1000) end
        spr(41,x,58,2,1)
        if f>830 then --beam/block
          if f<890 then spr(57+f%2,x+4,65,1,1) end
          if f%2==0 or f>890 then
            draw_block(92,84,0,0,4,false)
          end
        end
      end
    end
  end
end

function intro_text(id,y,col)
  if id<1 then return end
  if id<=count(intro.text) then
    print(intro.text[id],8,y,col)
  end
end

function draw_end()
  mapdraw(112,48,0,0,16,16)

  for i=0,8 do
    sspr(6*8,6*8+i,40,1,44+max(-44,min(44,80*sin(f*0.01+i*0.01))),6+i)
  end

  print("you win!!",50,45,11)
  print("press button",43,60,f%16)
end

intro={}
intro.s=0
intro.text={
"who would have guessed",
"that this little creature",
"is the last survivor",
"of his species?",
" "," "," ",
"oh crap...",
" ",
"here we go...",
"last survivor...",
" ",
"when all of a sudden",
"this friendly saucer from",
"planet 'tetros' appeared",
"and saved his life!",
" "," "," "," ",
"press button to start",
" "," ",
"========= credits =========",
"        idea  movax13h",
"              goo",
"     artwork  movax13h",
"        code  movax13h",
"       sound  movax13h",
" intro music  movax13h",
"  game music  pizza",
" ",
"========= levels ==========",
"   1,2,3,7,8  movax13h",
"       4,5,6  pizza",
" "," ",
"========= history =========",
"i made the first version of",
"this game in 1996 (dos,asm)",
"later versions were made in",
"c++, c#, flash and unity.",
" ",
"none of them were released.",
" ",
"        thanks zep!",
" "," "," ",
"-end of message",
" "," "," ",
"repeating ..."
}
