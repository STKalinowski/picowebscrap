-- polar panic
-- created by @johanpeitz 
-- audio by @gruber_music

-- 30 = 1 second
game_over_music_delay=40
stop_music_on_game_over=true


-- debug=true  


function _init()
 cartdata("jpppanic")
 load_font(fdat)
 
 letters={
  0,12,24,36,
  42,54,66,78,90
 }
 
 
 dpal={ 0,0,1,1,
        2,1,13,6,
        4,4,9,3,
        14,5,1,14}
        
 bpal={ 0,14,0,0,
        0,0,12,12,
        0,0,0,0,
        14,14,14,0 }
        
 wpal={ 0,7,0,0,
        0,0,7,7,
        0,0,0,0,
        7,7,14,0 }
        

 set_pal()
-- labelmaker()
 
  -- reset best
 best=dget(0)
 if (best==0) then
  reset_best()
 end
 
 
 
 swap_state(play_state)
end

function reset_best()
 dset(0,10) 
 best=dget(0)
end
 



function set_pal()
 pal()
 palt(0,false)
 palt(14,true)
 pal(14,12+128,1)
 
 poke(0x5f2e,0)
end

-->8
-- play
function init_play()
 t=0
 reset_count=0

 diff_t=0
 result=0

 reasons={
  "co2", "warming",
  "trash", "food", 
  "oil"
 }
 shuffle(reasons)
 
 g_state=0 -- title
 g_count=0
 jump_barrier=32
 ticker=nil
 
 entities={}

 -- lanes
 lanes={}
 make_lane(1)
 make_lane(0.5)
 make_lane(1)
 make_lane(0.5)
 make_lane(1)
 make_lane(0.5)
 make_lane(1)
 
 oil_timer=0
 oil=false
 life=0
 
 new_best=false
 
 speech=""
 speech_t=0
 speech_vx=0
 speech_x=0
 speech_y=0
 
 floes={}
 for l in all(lanes) do
  update_lane(l)
 end

 local f=floes[1]
 bear={
  x=f.x+7,
  y=0,
  z=0,
  carrier=nil,
  dx=0,
  dy=0,
  dz=0,
  state=0,
  balance=0,
  dir=1
 }
 
 health=1
 max_health=1
 hunger=0
 go_t=0
 carry(f,bear)
 
 waves={}
 particles={}
 
 music(0)
end

function say(txt,oy)
 speech=txt
 speech_t=1
 speech_x=bear.x
 if bear.carrier then
  speech_vx=bear.carrier.v
 end
 speech_y=bear.y
 if (oy) speech_y+=oy
end

function make_it_harder()
 local what=reasons[1]

 del(reasons,what)
 shuffle(reasons)
 add(reasons,what)
  
 if what=="co2" then  
  for l in all(lanes) do
   l.gap_ratio    += 0.1 --0.05
   l.gap_max_len  += 0.1 --0.05
  end
  launch_ticker("^s^p^e^c^i^a^l ^r^e^p^o^r^t:","^global ^c^o2 emissions causes polar caps to melt faster than expected")
 end
 
 if what=="warming" then  
  for l in all(lanes) do
   l.floe_min_len=max(1,l.floe_min_len-0.5)--0.3
   l.floe_max_len=max(2,l.floe_max_len-0.5)--0.3
  end
  launch_ticker("^s^h^o^c^k^i^n^g ^n^e^w^s:","^ice amounts in arctic reaches record low")
 end
 
 if what=="trash" then  
  launch_ticker("^t^o^p ^s^t^o^r^y:","^ocean garbage continues to rise to new heights")
  for l in all(lanes) do
   l.trash = min(0.5,l.trash+0.1)--0.05
  end
 end
 
 if what=="food" then
  launch_ticker("^a^l^a^r^m^i^n^g ^r^e^p^o^r^t^s:","^arctic sea struggles to sustain life due to over-fertilization")
  for l in all(lanes) do
   l.food = max(0.1,l.food-0.1)
  end
 end

 if what=="oil" then
  launch_ticker("^b^r^e^a^k^i^n^g ^n^e^w^s:","^another oilspill hits the arctic, local fauna at risk")
  oil_timer=0
  oil=true
 end
  
end

function make_lane(spd)
 add(lanes,{
  id=#lanes+1,
  t=0,
  v=spd,
  gap_ratio=0, --0.5
  gap_min_len=1,
  gap_max_len=3,
  floe_min_len=3,
  floe_max_len=5,
  force_floe=true,
  food=0.5,
  trash=0.1
 })
end

function update_lane(l)
 if (g_state==0 and l.id!=4) return
 l.t-=1
 if l.t<=0 then
  if l.force_floe or not chance(l.gap_ratio) then
   local len=flr(l.floe_min_len+rnd(1+l.floe_max_len-l.floe_min_len))
   l.t=len*16/l.v
   make_floe(l,len)
   l.force_floe=false
  else
   local len=l.gap_min_len+flr(rnd(1+l.gap_max_len-l.gap_min_len))
   l.t=len*16/l.v
   l.force_floe=true
  end
 end
end

function carry(floe,e)
 e.carrier=floe
 e.y=floe.y+5
 e.z=0
 add(floe.carry,e)
end

function uncarry(floe,e)
 if floe then
  e.carrier=nil
  del(floe.carry,e)
 end
end

function make_floe(lane,len)
 local f={
  x=128,
  y=lane.id*16,
  len=len,
  carry={},
  t=rnd(8),
  oily=oil and oil_timer<150 and chance(0.6)
 }
 f.v=lane.v
 add(floes,f)
 
 local itm=nil
 if t>30 then
  if chance(lane.food) then
   itm=128 -- eatable
  elseif chance(lane.trash) then
   itm=130 -- trash
  end
 end
 
 if itm then
  local item={
   id=itm,
   x=f.x+16*flr(rnd(len-1))+8,
   y=f.y,
  }
  carry(f,item)
  add(entities,item)
 end
 
 return f
end

function make_wave()
 add(waves,{
  x=flr(rnd(128)+32)-16,
  y=flr(rnd(32)*4),
  life=16+flr(rnd(16)),
  v=flr(rnd(3)+2)/4,
  maxl=flr(rnd(8)+4),
  l=0,
  t=0
 })
end

function get_floe(x,y)
 local retval=nil
 for f in all(floes) do
  if x>f.x and x<f.x+16*f.len-1 and
     y>f.y and y<f.y+9 then
   retval=f
  end
 end
 return retval
end

function update_play()
 t+=1
 if g_state==1 and g_count<256 then
  g_count+=1
 end
 
 if g_state==0 then
  update_bear()
  if bear.state==0 then
   if bear.x<jump_barrier then
	   jump_barrier=32+rnd(64)
	   bear.dx=2-bear.carrier.v
	   bear.state=1  
	  end
	  if bear.state==1 then
	   bear.dz=-3.5
	   bear.y+=get_floe_offset(bear.carrier)
	   uncarry(bear.carrier,bear)
	   sfx(62)
	  end
	 end
	 if btn(❎,1) and btn(⬅️) then
	  reset_count+=1
	  if reset_count>120 then
	   reset_best()
	   reset_count=0
	  end
	 else
	  reset_count=0
	 end
	 if btnp(➡️) or btnp(❎) or btnp(🅾️) then
	  music(2)
	  life=0
	  for l in all(lanes) do
	   l.gap_ratio=0.5
	   if l.id!=4 then
 	   l.t+=16*(8-l.id)+lanes[4].t%32
	   end
	  end
	  g_state=1
	  local greetings={
	   "hello",
	   "sup?",
	   "yo",
	   "heya",
	   "hey",
	   "yeah",
	   "ok",
	   "lets go",
	  }
	  say(rnd_elem(greetings))
	 end
 else
  update_game()
  update_bear()
  update_player_controls()
 end
 
 update_world()
 
end

function update_game()
 diff_t+=1
 
 if go_t>0 then
  go_t+=1
  if go_t>60 and btnp(❎) then
   sfx(52)
   swap_state(transition_state)
  end
 end
 

 if (bear.state<2) then
  hunger=min(1,hunger+0.003)
  if hunger==1 then
   health=max(0,health-0.005)
  elseif hunger<0.5 then
   health=min(max_health,health+0.001)
  end
 
	 if hunger>0.9 then
	  if t%30==15 then
	   sfx(56)
	  end
	 end
	 
	 if health<=0.3 then
	  if t%30==0 then
	   sfx(57)
	  end
	 end

  -- harder every 10 seconds
  local tt=10
  if diff_t%(30*tt)==0 then
   make_it_harder()
  end
 end

 -- update particles
 for p in all(particles) do
  p.uf(p)
 end 
 
end

function update_bear()  

 if bear.state==0 or bear.state==1 then
  life+=1
 end
  
 -- update bear
 if bear.state==0 then
  -- idle
  if health<=0 then
   health=0
   bear.state=3
   sfx(51)
   if stop_music_on_game_over then
    music(-1)
   end
   go_t=1 
   
   record_result()
   
   local txts={
    "ouf",
    "urgh",
    "durr",
    "oh",
   }
   say(rnd_elem(txts))
  end
 
 elseif bear.state==1 then 
  -- in air
  bear.x+=bear.dx
  bear.y+=bear.dy
  bear.z+=bear.dz
  bear.dz+=1
  if bear.dz>0 then
   -- falling
   
   if bear.z>=0 then
	   -- find floe to attach to
	   local lfloe=nil
	   local rfloe=nil
	   for f in all(floes) do
	    if bear.x-1>f.x and bear.x-1<f.x+16*f.len and
	       bear.y>f.y and bear.y<f.y+9 then
	     rfloe=f
	    end
	    if bear.x+3>f.x and bear.x+3<f.x+16*f.len and
	       bear.y>f.y and bear.y<f.y+9 then
	     lfloe=f
	    end
	   end
	
	   local landed=false
	   if lfloe and rfloe then
	    carry(lfloe,bear)
	    bear.balance=0
	    landed=true
	    lfloe.t=32
	    rfloe.t=32
	   elseif lfloe then
	    carry(lfloe,bear)
	    bear.balance=-1
	    landed=true
	    lfloe.t=32	    
	   elseif rfloe then
	    carry(rfloe,bear)
	    bear.balance=1
	    landed=true
	    rfloe.t=32
	   end
	   
	   if landed then
	    bear.dx=0
	    bear.dy=0
	    bear.dz=0
	    bear.state=0
	    -- check for oil
	    if bear.carrier.oily then
	     local txts={
 	     "yuck",
 	     "ouch",
 	     "argh",
 	     "bleargh",
 	     "ick"
	     }
	     say(rnd_elem(txts))
	     max_health=max(0,max_health-0.05)
	     health=min(health,max_health)
	     sfx(60)
	    else
	     -- skip landed sound
	     -- sfx(61)
	    end
	    
	    -- check for items
	    for e in all(bear.carrier.carry) do
	     if e!=bear then
	      if abs(e.x-bear.x)<12 then
	       if e.id==128 then
	        hunger=max(0,hunger-0.3)
	        say("yum")
	        sfx(59)
	       end
	       if e.id==130 then
	        hunger=max(0,hunger-0.15)
	        health=max(0,health-0.2)
	        say("bleh")
	        sfx(58)
	       end
	       del(bear.carrier.carry,e)
	       del(entities,e)
	      end
	     end
	    end
	   elseif bear.z>8 then
	    bear.dx=0
	    bear.dy=0
	    bear.dz=0
	    bear.z=4
	    bear.sinky=bear.y+3
     bear.state=2
     sfx(53)
     if stop_music_on_game_over then
      music(-1)
     end
     local txts={
      "help",
      "bye",
      "blubb",
      "gasp",
      "oh no",
      "no no",
      "rats",
      "oops"
     }
     record_result()
     say(rnd_elem(txts),10)
     go_t=1
     for i=-7,7 do
      add(particles,{
       x=bear.x+i,
       y=bear.y,
       dx=i/10-0.5,
       dy=-2-rnd(2),
       life=10+rnd(6),
       size=1+rnd(2),
       uf=function(p)
           p.x+=p.dx
           p.y+=p.dy
           p.dy+=0.5
           p.life-=1
           if (p.life<=0) del(particles,p)
          end,
       df=function(p)
           circfill(p.x,p.y,p.size,12)
          end,
      })
     end
    end
   
   end
  end
 elseif bear.state==2 then
  -- splash
  health=max(0,health-0.05)
  bear.z+=0.4
  bear.x-=lanes[flr((bear.y+8)/16)].v

  if bear.z<20 then
   local px=rnd(15)-7
   add(particles,{
    x=bear.x+px,
    y=bear.y+2,
    dx=px/10-1,
    dy=-2-rnd(1),
    life=4+rnd(2),
    size=1+rnd(1),
    uf=function(p)
        p.x+=p.dx
        p.y+=p.dy
        p.dy+=0.4
        p.life-=1
        if (p.life<=0) del(particles,p)
       end,
    df=function(p)
        circfill(p.x,p.y,p.size,12)
       end,
   })
  end
  
 elseif bear.state==3 then
  -- fainted
  health=0
 end
end

function update_player_controls()
 -- player controls
 if bear.state==0 then
  local lane_id=flr(bear.y/16)
  if btn(⬆️) and lane_id>1 then
   bear.dy=-2
   bear.state=1
   local lane=lanes[lane_id-1]
   if lane then
    local lanex=lane.v*t
    local box=flr(lanex+bear.x)%16
    bear.dx=-(box-8)/8
    
    -- adjust for lane speed
    bear.dx-=lane.v
   end
  end
  if btn(⬇️) and lane_id<7 then
   bear.dy=2
   bear.state=1
   local lane=lanes[lane_id+1]
   if lane then
    local lanex=lane.v*t
    local box=flr(lanex+bear.x)%16
    bear.dx=-(box-8)/8
    
    -- adjust for lane speed
    bear.dx-=lane.v
   end
  end
  if btn(⬅️) then
   bear.dx=-2-bear.carrier.v
   bear.state=1
   bear.dir=-1
  end
  if (btn(➡️) and bear.x<120) or bear.x<2 then
   bear.dx=2-bear.carrier.v
   bear.state=1
   bear.dir=1
  end

  if bear.state==1 then
   bear.dz=-3.5
   bear.y+=get_floe_offset(bear.carrier)
   uncarry(bear.carrier,bear)
   sfx(62)
  end
 end
 
 
end

function update_world()  
 if (speech_t>0) speech_t+=1
 if (speech_t>30) speech_t=0
 speech_x-=speech_vx
 
 -- update waves
 for w in all(waves) do
  w.x-=w.v
  if w.life<0 then
   w.l-=1
   if w.l==0 then   
    del(waves,w)
   end
  else
   if (w.l<w.maxl) w.l+=1
   w.life-=1
  end
 end
 if (chance(0.5)) make_wave() 

 -- floes
 for f in all(floes) do
  f.t+=1
  local v=-f.v
  f.x+=v
  for e in all(f.carry) do
   e.x+=v
  end
  if (f.x+f.len*16<-10) then
   del(floes,f)
   for itm in all(f.carry) do
    uncarry(f,itm)
    del(entities,itm)
   end

  end
 end
 
 for l in all(lanes) do
  update_lane(l)
 end
 
 sort(floes,"y")
 
end

function draw_oil()
 
 for y=8,127 do
  local len=256
  local x=256-y/2-oil_timer*2
  x -= 8*sin((y+t)/40)
  x += 8*cos((y+t*0.3)/30)
  x += 8*sin((y+t/2)/25)
  line(x,y,len+x,y,1)
  line(10+x+5*sin(t/100),y,
       -10-5*sin(t/80)+len+x-2,y,0)
 end
 
 oil_timer+=1
 if oil_timer>300 then
  oil=false
 end
 
end

function record_result()
 result=flr(life/30)
 if result>best then
  best=result
  new_best=true
  dset(0,best)
 end
end

function draw_play()
 cls(14)
 

 for f in all(floes) do
  draw_floe_sub(f)
 end

 if oil then
  draw_oil()
 end
 
 for w in all(waves) do
  line(w.x-1,w.y,w.x+w.l+1,w.y,12)
  line(w.x,w.y,w.x+w.l,w.y,7)
 end
 
 for f in all(floes) do
  draw_floe(f)
 end

 draw_title()
 draw_hud()

 local str="^best: "..best.."s"
 local len=tlen(str)
 local ox=(reset_count/10)
 local oy=0
 if (ox>8) oy=rnd(ox)-ox/2
 ox*=ox
 pr(str,max(0,g_count-60)+128-len-ox,2+oy,6)

 
 for e in all(entities) do
  local oy=get_floe_offset(e.carrier)
  for i=0,15 do
   if (i!=11) pal(i,e.carrier.oily and 0 or 6)
  end
  spr(e.id,e.x-8,e.y-8+oy,2,2)
  set_pal()
  spr(e.id,e.x-8,e.y-8+oy-1,2,2)
  if debug then
   pset(e.x,e.y,8)
  end
 end
 
 draw_bear(bear)

 -- draw particles
 for p in all(particles) do
  p.df(p)
 end 
 
 if ticker then
  draw_ticker(ticker)
  update_ticker(ticker)
 end
 
 if (go_t>0) draw_ending()
 if (go_t==game_over_music_delay) music(21)

 
 -- ?"∧"..flr(stat(1)*100).."%",1,1,1
 -- ?"▤"..#floes,1,8,1
 debug_str="∧"..flr(stat(1)*100).."%"
 debug_str=debug_str.." ("..max_cpu..")"
 debug_str=debug_str.." ▤"..#floes
 debug_str=debug_str.." ●"..#entities
 debug_str=debug_str.." ☉"..#reasons
end

function draw_ending()
 local y=max(21,160-go_t)
 local h=90
 local small=false
 if result<30 then
  small=true
  h-=30
 end
 rectfill(7,y+16,119,y+h-16,7)
 rectfill(7+16,y,119-16,y+h,7)
 rectfill(8,y+15,118,y+h-15,12)
 rectfill(8+16,y+1,118-16,y+h-1,12)
 
 -- fancy corners
 spr(16,7,y,2,2)
 spr(16,7,y+h-15,2,2,false,true)
 spr(16,104,y,2,2,true)
 spr(16,104,y+h-15,2,2,true,true)
 pal(7,12)
 spr(16,8,y+1,2,2)
 spr(16,8,y+h-16,2,2,false,true)
 spr(16,103,y+1,2,2,true)
 spr(16,103,y+h-16,2,2,true,true)
 set_pal()
 
 -- content
 y+=2
 rectfill(35,y+1,91,y+8,2)
 prc("^g^a^m^e ^o^v^e^r",y+2,15,8)
 
 y+=12
 prc("^you survived for",y,7)
 local sstr="second"
 if (result!=1) sstr=sstr.."s"
 local col=7
 if (new_best) col=10
 prc(result.." "..sstr..".",y+8,col)
 
 y+=20

 if not small then  
  prc("^if only climate change",y,7)
  prc("was a game as well.",y+8,7)
  prc("^it is not.",y+16,14)
  y+=4
  prc("^what can ^you do",y+24,7)
  prc("to slow it down?",y+32,7)
  y+=42
 else
  prc("^try again!",y,7)
  y+=16
 end
 
 if (t%32<24) then
  print("- ❎ -",52,y,14)
 end
end

function draw_bear(b)
 
 local l_edge=false
 local r_edge=false
 if bear.carrier then 
  local xdiff=bear.x-bear.carrier.x
  if xdiff<5 then
   l_edge=true
  end
  if xdiff>10+(b.carrier.len-1)*16 then
   r_edge=true
  end
 end

 local x=b.x
 local y=b.y
 
 if (b.carrier) then
  y+=get_floe_offset(b.carrier)
 else
  --y-=2
 end
 
 if bear.state!=2 then
	 -- cast shadow
	 for sy=0,2 do
	  for sx=0,11 do
	   if sget(sx,sy)>0 then
	    local wy=3+b.y-y
	    if (get_floe(sx+x-5,sy+b.y)) wy=0
	    local c=pget(x+sx-5,y+sy+wy-1)
	    pset(x+sx-5,y+sy+wy-1,dpal[c+1])
	   end
	  end
	 end
	 
	 y+=b.z
	 local frame=96+(flr(t/6)%4*2)
	 if (bear.balance<0) frame=64+(flr(t/8)%2)*2
	 if (bear.balance>0) frame=68+(flr(t/8)%2)*2
	 if bear.state==1 then
	  frame=72
	  if (bear.dz>0) frame=74
	 elseif bear.state==3 then
	  frame=104+min(6,2*flr(go_t/10))
	  if (frame==110) y+=1
	 end
	 
	 
	 spr(frame,x-7,y-15,2,2,bear.dir!=1)
	
 else
	 y+=b.z
  -- splash
	 local frame=74
	 clip(0,0,128,bear.sinky)
	 spr(frame,x-7,y-15,2,2,bear.dir!=1)
  clip()
  if bear.z<18 then
   line(x-5-rnd(2),b.y+3,x+5+rnd(2),b.y+3,12)
  end
 end
 
 if speech_t>0 then
  local txt=speech
  local len=#txt*2
  local y=speech_t/2-8
  for x=speech_x-len,speech_x+len do
   circfill(x,speech_y-27-y,3,6)
  end
  for x=speech_x-len,speech_x+len do
   circfill(x,speech_y-28-y,3,7)
  end
  local c=0
  if (speech_t>24) c=1
  if (speech_t>25) c=5
  if (speech_t>26) c=13
  if (speech_t>27) c=6
  print(txt,speech_x+1-len,speech_y-y-30,c) 
 end

 if debug then
  pset(bear.x,bear.y,8)
 end
 
end

function get_floe_offset(f)
-- return flr(f.t/f.rhythm)%2
 return 1*sin(f.t/50)+0.1-2
end

function draw_bar(x,y,w,p,c,c2)
 rectfill(x,y+1,x+w*p,y+4,c2 and c2 or c)
 rect(x,y,x+w,y+4,c)
 if c2 then
  shade(x+1,y+1,x+min(w-1,w*p),y+1,dpal)
 end
end

function hunger_col(r)
 if (r<0.25) return 11
 if (r<0.5) return 10
 if (r<0.75) return 9
 return 8
end

function health_col(r)
 return hunger_col(1-r)
end

function draw_hud()
 rectfill(0,0,127,7,12)
 if (g_state==0) return 
 
 local y=min(g_count-64,0)
 local y2=min(g_count-256,0)
 
 if hunger<1 or t%8<6 then
  pr("^h^u^n^g^e^r",1,y+1,7,13)
  draw_bar(35,y+2,21,hunger,13)
  draw_bar(35,y+1,21,hunger,7,hunger_col(hunger))
 end
 
 if health>0.25 or t%8<6 then
  pr("^h^e^a^l^t^h",73,y2+1,7,13)
  draw_bar(105,y2+2,21,health,13)
  draw_bar(105,y2+1,21,health,7,health_col(health))
  if max_health<1 then
   local w=19*(1-max_health)
   rectfill(125,2,125-w,4,1)
   line(125,2,125-w,2,0)
  end 
 end
 
 
end

function launch_ticker(head,body)
-- extcmd("rec")
 
 ticker={
  head=head,
  body=body,
  len=tlen(head.." "..body),
  hlen=tlen(head),
  t=0,
  x=128,
  y=128  
 }
 sfx(54)--55?
end

function update_ticker(tkr)
 if tkr.x<-tkr.len then
  tkr.y+=1
 elseif tkr.y>121 then
  tkr.y-=1
 end
 tkr.x-=2
 
 -- kill it
 if (tkr.y>130) ticker=nil
end

function draw_ticker(tkr)
-- rectfill(0,tkr.y,127,tkr.y+7,1)
 shade(0,tkr.y,127,tkr.y+8,dpal)
 pr(tkr.head,tkr.x,tkr.y+1,8,2)
 pr(tkr.body,tkr.x+tkr.hlen+4,tkr.y+1,7,5)
end

function draw_floe_sub(f)
 local x=f.x
 local y=f.y+get_floe_offset(f)
 
 local w=15+(f.len-1)*16
 
 -- submeged bit
 
 rectfill(x+1,y-1,x+w-1,y+16,5)
 rectfill(x+2,y-1,x+w-2,y+16,13)
 
 -- rings
-- line(x+1,f.y+13,x+w-1,f.y+13,7)
-- line(x,f.y+3,x,f.y+12,7)
-- line(x+w,f.y+3,x+w,f.y+12,7)
end

function draw_floe(f)
 local x=f.x
 local y=f.y+get_floe_offset(f)
 
 local w=15+(f.len-1)*16

 -- outline, top, side
 c={12,7,6}
 if f.oily then
  c={0,1,0}
 end

 clip(0,0,128,f.y+13)
 rectfill(x+1,y-1,x+w-1,y+15,c[1])
 rectfill(x+2,y,x+w-2,y+10,c[2])
 rectfill(x+2,y+12,x+w-2,y+15,c[3]) 
 clip()

 --for i=1,f.len-1 do
 -- line(x+i*16,y,x+i*16,y+10,15)
 --end

 
 if debug then
  for i=0,f.len-1 do
   circ(x+i*16+7,y+5,1,14)
  end
 end
 
 
end

play_state={
 name="play",
 init=init_play,
 update=update_play,
 draw=draw_play
}

-->8
-- title helpers
function draw_title()
 if (g_count>88) return
 
 draw_letters(20,15,{3,7,2,1,8}) 
 draw_letters(40,35,{3,1,5,4,6}) 
 
 if not label then
  shade(19,29,92,33,bpal,11)
  shade(19,28,92,28,wpal,11)
  shade(39,49,112,53,bpal,11)
  shade(39,48,112,48,wpal,11)
 end

 local x=-g_count*3
 local str=""
-- str=str.."- ^eat fish, not plastic\n"
 str=str.."- ^eat fish not to starve\n"
 str=str.."- ^stay out of the water\n"
 str=str.."- ^arrows to move"
 pr(str,x+15,81,15,1)
  
 if (t%32<24) then
  if (g_state==0) then
   print("➡️ to start",42,106,1)
   print("➡️ to start",42,105,7)
 --  prc("^t^o ^s^t^a^r^t",103,15,1)
  end
 end
 
 local x=max(0,g_count*2-15)
 pr("^created by @^johan^peitz\n^audio by @^gruber_^music",
   15-x,114,12,1)
   
end

function draw_letters(x,y,a,c)
 local xx=0
 for i=1,#a do
  local l=a[i]
  local sx=letters[l]
  local w=letters[l+1]-letters[l]
  local ty=y+sin((i+y)/8+t/40)+0.5
  ty+=g_count/5
  if (not label) clip(x-1,y-4,100,20+i%2)
  if c then
   for j=0,15 do
    if (not label) pal(j,c)
   end
   sspr(letters[l],112,w,16,xx+x,ty,w,16)
   set_pal()
  else
   sspro(letters[l],112,w,16,xx+x,ty,1)
  end
  clip()
  xx+=w+3
 end
end

-->8
-- utitlity
function sort(a,p)
 for i=1,#a do
  local j = i
  while j > 1 and a[j-1][p] > a[j][p] do       a[j],a[j-1] = a[j-1],a[j]
   j = j - 1
  end
 end
end

function shuffle(a)
 for i=1,#a do
  local tmp=rnd_elem(a)
  del(a,tmp)
  add(a,tmp)
 end
end

function rnd_elem(a)
	return a[flr(rnd(#a)+1)]
end

function shade(x1,y1,x2,y2,shader,bg)
 for x=x1,x2 do
  for y=y1,y2 do
   local c=pget(x,y)
   if c!=bg then
    pset(x,y,shader[c+1])
   end
  end
 end
end



function chance(p)
 return rnd()<p
end

function round(x)
 return flr(x+0.5)
end

function sspro(sx,sy,sw,sh,dx,dy,c)
 for i=0,15 do
  pal(i,c)
 end
 sspr(sx,sy,sw,sh,dx-1,dy,sw,sh)
 sspr(sx,sy,sw,sh,dx+1,dy,sw,sh)
 sspr(sx,sy,sw,sh,dx,dy-1,sw,sh)
 sspr(sx,sy,sw,sh,dx,dy+1,sw,sh)

 set_pal()
 sspr(sx,sy,sw,sh,dx,dy,sw,sh)
end

-- font

-- grab this from fdat.txt.p8l
fdat=[[  0000.0006! 0080.210e" 0000.052c# 057d.5f50$ 011c.4714% 0488.8890& 0bb6.e230' 0000.031e( 0104.2116) 0088.420e* 0014.4504+ 0008.e204, 1100.0006- 0000.e004. 0080.0006/ 0088.88800 0325.29321 0388.43142 0788.89323 03a0.887a4 043d.294a5 03a0.e17a6 0324.e1327 0110.887a8 0324.c9329 0321.c932: 0080.0106; 1100.0206< 0208.2224= 001c.0704> 0088.820c? 0100.c83a@ 0305.ad32^a04bd.2932^b03a4.e93a^c0304.2134^d03a5.293a^e0784.617a^f008c.217a^g0325.a132^h04a5.e94a^i0388.423c^j0325.0842^k0494.654a^l0384.210c^m08c6.bb88^n08e6.b388^o0325.2932^p009d.293a^q8325.2932^r049d.293a^s03a0.c132^t0108.423c^u0325.294a^v0229.5188^w08ee.b188^x04a4.c94a^y0321.c94a^z0784.c87a[ 0184.211e\ 0820.8208] 0188.421e^^0000.0514_ 0780.0002` 0000.020ea 0725.2e02b 03a5.270ac 0304.2604d 0725.2e42e 0305.e602f 0084.6116g 6439.2602h 04a5.270ai 0184.200ej 1108.4016k 0294.650cl 0184.210em 08c6.ab00n 04a5.2702o 0325.2602p 13a5.2702q 8725.2e02r 0084.6504s 0188.2306t 0104.230eu 0725.2902v 0114.a504w 08ee.b100x 0294.4504y 6439.2902z 0788.8f02{ 0308.2234| 1084.210e} 0188.821c~ 0001.ab02^*0220.2202]]


_gl_w=5
_gl_h=6
_glyphs={}
_kerning={}

function load_font(data)
 for i=0,#data/11 do
  local p=1+i*11
  local char=sub(data,p,p+1)
  _glyphs[char]=
   tonum("0x"..sub(data,p+2,p+10))
  _kerning[char]=4
 end
end

function prc(str,y0,c1,c2)
 local len=tlen(str)
 pr(str,64-len/2,y0,c1,c2)
end

function pr(str,x0,y0,c1,c2)
 local x1,i=x0,1
 
 while i<=#str do
  local char=sub(str,i,i)
  
  if char=="\n" then
   y0+=_gl_h+1
   x1=x0
  else
   if char=="^" then
    char=sub(str,i,i+1)
    i+=1
   else
    char=char.." "
   end
   
   local px,k=_glyphs[char],_gl_w+1

   -- handle kerning
   for j=1,2 do
    px=shr(px,1)
    if (band(px,0x0.0001)>0) k-=j
   end

   -- draw glyph
   for y=0,_gl_h-1 do
    for x=0,_gl_w-1 do
     px=shr(px,1)
     if band(px,0x0.0001)>0 then
      pset(x1+x,y0+y,c1)
      if (c2) pset(x1+x,y0+y+1,c2)
     end
    end
   end 
   
   x1+=k
   _kerning[char]=k
  end
  
  i+=1
 end
end

-- custom font text length
-- kerning is calculated on first draw
function tlen(str)
 local l,i=0,1
 while i<=#str do
  local char=sub(str,i,i)
  if char=="^" then
   char=sub(str,i,i+1)
   i+=1
  else
   char=char.." "
  end
  l+=_kerning[char]
  i+=1
 end
 return l
end



-->8
--------------------------------
-- core functions 
--------------------------------
debug_str=""
max_cpu=0

--------------------------------
-- state swapping 
--------------------------------
state, next_state, change_state = {}, {}, false

function swap_state(s)
 next_state, change_state = s, true
end

--------------------------------
-- base functions 
--------------------------------
function _update()
 if (change_state) then
  state, change_state = next_state, false
  state.init()
 end

 state.update() 
end

function _draw()
 state.draw()
 
 -- debug, 175 tokens
 if (debug) then
  camera()
  
  local str = state.name .. " "
    
  if (btn(0)) str = str .. "⬅️"
  if (btn(1)) str = str .. "➡️"
  if (btn(2)) str = str .. "⬆️"
  if (btn(3)) str = str .. "⬇️"
  if (btn(4)) str = str .. "🅾️"
  if (btn(5)) str = str .. "❎"  

  str = str .. " " .. debug_str
  
  local mr = stat(0)/1024
  local cpu= flr(stat(1)*100)
  local ypos = 121
  if (debug_at_top) ypos=0
  rectfill(0,ypos,127,ypos+6,8)
  
  line(1, ypos+2, 8, ypos+2, 1)
  line(1, ypos+2, 1+min(7*stat(1),7), ypos+2, (stat(1)>1 and 8 or 12))
  
  line(1, ypos+4, 8, ypos+4, 2)
  line(1, ypos+4, 1+min(7*mr,7), ypos+4, (mr>1 and 8 or 14))
  print(str,10,ypos+1,15)

  if (cpu>max_cpu) max_cpu=cpu
 end
 
end
-->8
-- transition screen
function init_transition()
 t=0
end

function update_transition()
 t+=1
 if t>32 then
  swap_state(play_state)
 end
end


function draw_transition()
 local t1=min(4*t,64)
 local t2=min(5*t-32,64)
 local t3=min(6*t-64,64)
 
 rectfill(0,0,t1,127,7)
 rectfill(127,0,127-t1,127,7)
 
 rectfill(-1,0,t2,127,12)
 rectfill(128,0,128-t2,127,12)
 
 rectfill(-1,0,t3,127,14)
 rectfill(128,0,128-t3,127,14)
end

transition_state={
 name="transition",
 init=init_transition,
 update=update_transition,
 draw=draw_transition
}

-->8
function labelmaker()
 if (not label) return
 cls(12)
 g_count=0
 t=0
 camera(0,10)
 draw_title()
 rectfill(0,67,127,140,6)
 rectfill(0,68,127,140,7)
 
 spr(102,72-32,60,2,2)
 spr(72,72-8,60,2,2,true)
 
 
 
 
 while true do
  flip()
 end
end
