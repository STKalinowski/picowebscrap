-- pico-8 advent calendar 2021
-- @johanpeitz
-- @markgamed7794
-- @thetomster

-- card sizes
cw=18
ch=18

-- card states
-- 0 - locked
-- 1 - unlocked
-- 2 - opened (not played)
-- 3 - opened (and played)

light_pal={
 1,5,4,11,
 9,13,7,7,
 14,10,7,7,
 7,6,15,7   
}

function _init()
 cartdata("jpadvent2021_1")

 -- current date
 if false then
  d_year=stat(90)
  d_month=stat(91)
  d_day=stat(92)
 else
  d_year=2020+1
  d_month=12
  d_day=25
 end
 
 -- mouse
 poke(0x5f2d, 1)
 use_mouse=false
 mouse_dn=false
 last_mb=0
 
 mouse_movex=false
 last_mx=0
 
 mouse_movey=false
 last_my=0
 camx = 0

 -- font
 load_font(font)
 
 -- counter
 t=0
 show_cursor=false
 
 particles={}
 
 preview=nil
 
 ui_y = 121
 
 -- bg colors
 local bgs={
  14,7,10,0,8,
  3,6,2,13,15,
  12,1,9,3,3,
  7,8,7,2,12,
  0,9,13,0,12,
 }
 
 -- make cards
 cards={}
 local id=1
 for j=0,0 do
	 for y=0,2 do
	  for x=0,3 do
	   local icon=id
	   local s=dget(id)
	   if s==0 then
	    if d_year>=2021 and d_month>=12 then
	     if ((id+13)<=d_day) s=1
	    end
	    if (d_year>2021) s=1
	   end
	   add(cards,{
	    id=id,
	    day=id+13,
	    state=s,
	    icon=icon,
	    bg=bgs[icon],
	    flp=0,
	    rot=0,
	    oz=0,
	    name="^a ^christmas ^dream",
	    author="^random^person",
	    desc="^try to eat the fish without hitting the dog with the apple.",
	    cart="#notnonada7523",
	    altspr=(id<=12)
	   })
	   id+=1
	  end
	 end
 end
 
 -- mix cards
 --[[
 for i=0,99 do
  local id=flr(rnd(#cards))+1
  local c=cards[id]
  del(cards,c)
  add(cards,c)
 end
 --]]
 
 -- set grid coords
 local id=1
 for j=0,0 do
	 for y=0,2 do
	  for x=0,3 do
	   local card=cards[id]
	   card.gx=x       
	   card.gy=y
	   card.ox=-(x-2)*60
	   card.oy=256+y*10
	   card.delay=15+y*12+x*4
	   
	   id+=1       
	  end
	 end 
 end
 
 -- cursor
 cursor_x=2
 cursor_y=2
 cursor_page=0
 cpx,cpy=get_card_pos(cursor_x,cursor_y,cursor_page)


 cls()
 flip()
 extcmd("rec")
 
 cards[1].name = '^accurate ^xmas ^bowling'
 cards[1].author = '^fred^s72'
 cards[1].desc = '^fred^s assured the team that this is totally accurate and how bowling really works.'
 cards[1].cart = '#freds72_bowling'
 cards[1].bg = 0
 
 cards[2].name = '^mitt\'s ^marble ^adventure'
 cards[2].author = '^the^tomster'
 cards[2].desc = '^save the holidays by...          *checks notes*                           playing... marbles??'
 cards[2].cart = '#mitts_marbles'
 cards[2].bg = 0
 
 cards[3].name = '^winter ^wars'
 cards[3].author = '2tie'
 cards[3].desc = '^maybe the skating rink wasn\'t the best choice for a battlefield... but it sure is fun.'
 cards[3].cart = '#twotie_winterwars'
 cards[3].bg = 0
 
 cards[4].name = '^secret ^santa'
 cards[4].author = '^liquidream'
 cards[4].desc = '2018 throwback: ^the advent calendar just wouldn\'t be the same without ^secret ^santa.'
 cards[4].cart = '#secretsanta'
 cards[4].bg = 0
 
 cards[5].name = '^toboggoban'
 cards[5].author = '2darray'
 cards[5].desc = '2019 throwback: ^this cart almost didn\'t make it, because ^i couldn\'t spell toboggoban.'
 cards[5].cart = '#toboggoban'
 cards[5].bg = 0
 
 cards[6].name = '^xmas ^r^p^g'
 cards[6].author = '^bone^volt'
 cards[6].desc = '2020 throwback: ^this super santa ^r^p^g features wonderful art and character design.'
 cards[6].cart = '#xmas_rpg'
 cards[6].bg = 0
 
 cards[7].name = '^coal ^simulator 2021'
 cards[7].author = '^the^tomster'
 cards[7].desc = '^someone was naughty... and all there is in this present is a piece of educational coal.'
 cards[7].cart = '#coal_simulator'
 cards[7].bg = 0
 
 cards[8].name = '^spirit ^solstice'
 cards[8].author = '^jusiv'
 cards[8].desc = '^find the spirits for the solstice ceremony without getting lost! ^you will get lost.'
 cards[8].cart = '#spirit_solstice'
 cards[8].bg = 0
 
 cards[9].name = '^courier + ^ives'
 cards[9].author = 'beepyeah'
 cards[9].desc = '^deliver gifts on time, or it\'s on ^y^o^u^r dime. ^get movin\'.'
 cards[9].cart = '#courier_and_ives'
 cards[9].bg = 0
 
 cards[10].name = '^present ^pop ^d^x'
 cards[10].author = '^mark^gamed7794'
 cards[10].desc = '^a remastered puzzle classic! ^my longest chain is 2! ^i hope you can do better...'
 cards[10].cart = '#present_pop_dx'
 cards[10].bg = 0
 
 cards[11].name = '^e.^l.^f. 1978'
 cards[11].author = '^squirrel^eiserloh'
 cards[11].desc = '^jingles, local elf genius, built a super computer for ^santa. ^programming it should be ^e^z^p^z.'
 cards[11].cart = '#advent_elf_1978'
 cards[11].bg = 0
 
 cards[12].name = '^holiday ^jumper'
 cards[12].author = 'zep'
 cards[12].desc = 'jumper, n. - a wool shirt with long sleeves, no buttons, and a holiday game sewn on the front.'
 cards[12].cart = '#jumper'
 cards[12].bg = 0
end

function get_card_pos(x,y,j)
	if(j) then
		if(j > 0) return 128+19+x*(cw+6),33+y*(ch+4)
 end
 return 19+x*(cw+6),33+y*(ch+4)
end


function _update()

 t+=1
 
 if t>60 then
  show_cursor=true
 else
  if btn(🅾️) and btn(❎) then
   for i=1,24 do
    dset(i,0)
    cards[i].state=0
   end
  end
 end
 
 -- update cards
 for c in all(cards) do
  update_card(c)
 end
 
 if mouse_movex or mouse_movey then
  use_mouse=true
 end
 for i=0,5 do
  if (btn(i)) use_mouse=false
 end
 
 -- get input
 if not use_mouse then
	 if (btnp(⬅️)) cursor_x-=1
	 if (btnp(➡️)) cursor_x+=1
	 if (cursor_x>3) then
	 	cursor_x -= 4
	 end
	 if cursor_x < 0 then
	 	cursor_x += 4
	 end
	 --[[ removing second screen
	 if (cursor_x>3) then
	 	cursor_x-=4
	 	cursor_page = 1-cursor_page
	 end
	 if (cursor_x<0) then
	 	cursor_x+=4
	 	cursor_page = 1-cursor_page
	 end
	 --]]
	
	 if (btnp(⬆️)) cursor_y-=1
	 if (btnp(⬇️)) cursor_y+=1
	 if (cursor_y>2) cursor_y-=3
	 if (cursor_y<0) cursor_y+=3
 else
  if not preview then
   local mx=flr((stat(32)-26+cw/2)/(cw+6))
   local my=flr((stat(33)-44+ch/2)/(ch+4)) 
   cursor_x=mid(3,0,mx)
   cursor_y=mid(2,0,my)
   
   --[[ removing second screen
   if(stat(32) >= 127) then
   	cursor_page = 1
   end
   if(stat(32) <= 0) then
   	cursor_page = 0
   end
   --]]
  end
 end
 
 -- mouse over?
 local btn_1=false
 local btn_2=false
 if use_mouse then
	 if preview then
	  -- hover a button?
	  local mx=stat(32)
	  local my=stat(33)
	  preview.hover=nil
	  if my>=preview.y+38 and my<=preview.y+45 then
	   if mx>=preview.x+8 and mx<=preview.x+48 then
	    preview.hover=1
	    if (mouse_dn) btn_1=true
	   elseif mx>=preview.x+60 and mx<=preview.x+100 then   
	    preview.hover=2
	    if (mouse_dn) btn_2=true
	   end
	  end
	 else
	  if mouse_dn then
	   btn_1=true
	  end
	 end
 end
 
 local ccard=cards[1+cursor_x+cursor_y*4+cursor_page*12]

 if show_cursor and (btn_1 or btnp(🅾️)) then
  if not preview then
   if ccard.state!=1 then
    -- open preview
 	  preview={
 	   x=-128,
 	   y=8,
 	   tx=-128,
 	   ty=8
	   }
	  else
	   -- open animation
	   open_card(ccard)
	  end
	 else
	  if ccard.state==1 then
	   -- open
    preview.ty=-70
	   open_card(ccard)
	  elseif ccard.state>=2 then
	   -- play
	   play_card(ccard)
	  else
	   -- locked!
	  end
	 end
 end
 
 local cx,cy=get_card_pos(cursor_x,cursor_y,cursor_page)

 if preview then
  -- current card
  preview.card=ccard
  if preview.ty>-70 then
   preview.tx=9-(cursor_x-2)*4
   if cursor_y<2 then
    preview.ty=cy+22+4
   else
    preview.ty=max(cy-52-4,8)
   end
  end
  preview.x+=0.3*(preview.tx-preview.x)
  preview.y+=0.3*(preview.ty-preview.y)

  if btn_2 or btnp(❎) then
   preview.ty=-70
  end
  
  if preview.y<-60 then
   preview=nil
  end
  
 end

 cpx+=(cx-cpx)*0.5
 cpy+=(cy-cpy)*0.5
 if (abs(cpx-cx)<0.1) cpx=cx
 if (abs(cpy-cy)<0.1) cpy=cy

 -- mouse
 mouse_dn=last_mb==0 and stat(34)>0
 last_mb=stat(34)
 
 mouse_movex=stat(32)!=last_mx
 last_mx=stat(32)

 mouse_movey=stat(33)!=last_my
 last_my=stat(33)

	-- move bottom text to
	-- make room for the preview
	
	if(preview) then
		if(preview.ty >= 0) then
			ui_y = min(ui_y+1,128)
		else
			ui_y = max(ui_y-1,118)
		end
	else
		ui_y = max(ui_y-1,118)
	end
	
end

function _draw()
 cls(0)
 
 camx += ((cursor_page > 0 and 128 or 0)-camx)/6
	camera(camx,0)
 draw_bg(0,0)
 draw_bg(128,0)
 -- cursor
 if show_cursor then
  rrectfill(cpx-2,cpy-2,
            cpx+cw+1,cpy+ch+2,
            7)
 end
        
 -- current card
 local ccard=cards[1+cursor_x+cursor_y*5]
 
 -- draw cards       
 local id=1
 for j=0,0 do
	 for y=0,2 do
	  for x=0,3 do
	   local c=6
	   if flr((-t+y+x)/4)%16<2 then
	    c=7
	   end
	   
	   card=cards[id]
	   local cid=1+cursor_x+cursor_y*5
	   card.selected=cid==id
	         
	   local cx,cy=get_card_pos(x,y,j)
	   draw_card(cx+card.ox,
	           cy+card.oy,
	           card)   
	           
	   id+=1
	  end
	 end
 end

 -- particles
 for p in all(particles) do
  p.df(p,6,0)
 end
 for p in all(particles) do
  p.df(p,7,-1)
 end
 camera()
 -- preview
 if preview then
  draw_preview(9,8)
 end
 
 -- title
 draw_banner(0,0)

 -- help
 print("⬅️➡️⬆️⬇️+🅾️",5,ui_y+1,2)
 print("⬅️➡️⬆️⬇️+🅾️",5,ui_y,15)
	
 local yyyy=""..d_year
 local mm=""..d_month
 local dd=""..d_day
 
 if (#mm<2) mm="0"..mm
 if (#dd<2) dd="0"..dd
 
 local str=yyyy.."-"..mm.."-"..dd
 print(str,124-#str*4,ui_y+1,2)
 print(str,124-#str*4,ui_y,15)
 -- arrows
 --if(cursor_page == 1) spr(32,3-(time()%1)*2,60)
 --if(cursor_page == 0) spr(33,117+(time()%1)*2,60)
 
 -- mouse
 spr(59,stat(32)-1,stat(33)-1)
end

-->8
-- utility

------------------------------
-- helpers
------------------------------
function set_pal(p)
 for i=0,15 do
  pal(i,p[i+1])
 end
end


------------------------------
-- font
------------------------------
font={
 name="font_lich_king",
 gw=3,
 gh=6,
 data=[[  0000.0004! 0000.824c" 0000.0168# 0000.0204$ 0001.7490% 0002.1508& 0000.2f40' 0000.004c( 0008.9252) 0005.248a* 0000.5540+ 0000.2e80, 0004.8004- 0000.0e00. 0000.8004/ 0004.a5200 0001.5b501 0001.24d22 0003.95183 0001.c5184 0002.4f685 0001.c6786 0001.56507 0001.29388 0001.55509 0001.4d50: 0000.8204; 0004.8204< 0002.22a0= 0000.71c0> 0000.a888? 0001.0518@ 0001.1b50^a0002.fb50^b0001.d758^c0003.1270^d0001.db58^e0003.9678^f0000.b278^g0003.5270^h0002.df68^i0000.924c^j0005.2492^k0002.d768^l0003.9248^m0002.dfe8^n0002.db58^o0001.5b50^p0000.bb58^q0011.5b50^r0002.bb58^s0001.c470^t0001.24b8^u0003.5b68^v0001.5b68^w0002.ff68^x0002.d568^y000a.6b68^z0003.9538[ 000c.925a\ 0012.2448] 000d.249a^^0000.0150_ 0003.8000` 0000.008aa 0003.5b80b 0001.dac8c 0001.1282d 0003.5ba0e 0001.1e80f 0004.b252g 000e.7b80h 0002.dac8i 0000.920cj 0005.2412k 0002.d748l 0000.924cm 0002.dec0n 0002.dac0o 0001.5a80p 0005.dac0q 0013.5b80r 0000.9740s 0001.a2c2t 0001.12cau 0003.5b40v 0001.5b40w 0002.fb40x 0002.a540y 000e.6b40z 0001.94c2{ 0019.22b0| 0004.924c} 000d.2898~ 0000.1f00^*0000.7bc0]]
}

_glyphs={}
_kerning={}
_alphabet="  ! \" # $ % & ' ( ) * + , - . / "..
     "0 1 2 3 4 5 6 7 8 9 : ; < = > ? "..
     "@ ^a^b^c^d^e^f^g^h^i^j^k^l^m^n^o"..
     "^p^q^r^s^t^u^v^w^x^y^z[ \\ ] ^^_ "..
     "` a b c d e f g h i j k l m n o "..
     "p q r s t u v w x y z { | } ~ ^*"


function load_font(fnt)
 _current_font=fnt

 for i=0,#fnt.data/11 do
  local p=1+i*11
  local char=sub(fnt.data,p,p+1)
  _glyphs[char]=
   tonum("0x"..sub(fnt.data,p+2,p+10))
  _kerning[char]=_current_font.gw
 end
end



function pr(str,x0,y0,c1,c2)
 local x1,i=x0,1
 
 while i<=#str do
  local char=sub(str,i,i)
  
  if char=="\n" then
   y0+=_current_font.gh+1
   x1=x0
  else
   if char=="^" then
    char=sub(str,i,i+1)
    i+=1
   else
    char=char.." "
   end
   
   local px=_glyphs[char]
   local k=_current_font.gw+1

   -- handle kerning
   for j=1,2 do
    px=shr(px,1)
    if (band(px,0x0.0001)>0) k-=j
   end
   _kerning[char]=k

   -- draw glyph
   for y=0,_current_font.gh-1 do
    for x=0,_current_font.gw-1 do
     px=shr(px,1)
     if band(px,0x0.0001)>0 then
      pset(x1+x,y0+y,c1)
      if (c2) pset(x1+x,y0+y+1,c2)
     --else
      --if (not c2 and x<k-1) pset(x1+x,y0+y,1)
     end
    end
   end 
   
   x1+=k
  end
  
  i+=1
 end
end

function pr_v(str,x0,y0,c1,c2)
 local x1,i=x0,1
 
 while i<=#str do
  local char=sub(str,i,i)
  
  if char=="\n" then
   y0+=_current_font.gh+1
   x1=x0
  else
   if char=="^" then
    char=sub(str,i,i+1)
    i+=1
   else
    char=char.." "
   end
   
   local px=_glyphs[char]
   local k=_current_font.gw+1

   -- handle kerning
   for j=1,2 do
    px=shr(px,1)
    if (band(px,0x0.0001)>0) k-=j
   end
   _kerning[char]=k

   -- draw glyph
   for y=0,_current_font.gh-1 do
    for x=0,_current_font.gw-1 do
     px=shr(px,1)
     if band(px,0x0.0001)>0 then
      pset(x1+x,y0+y+i-1,c1)
      if (c2) pset(x1+x,y0+y+i,c2)
     --else
      --if (not c2 and x<k-1) pset(x1+x,y0+y,1)
     end
    end
   end 
   
   x1+=k
  end
  
  i+=1
 end
end

function pr_w(str,x0,y0,width,c1,c2)
  -- break str into lines
  local lines={}
  local words={}
  local done=false

  while not done do
   local id=indexof(str," ")
   if (id==0) then 
    done=true
    id=#str+1
   end
   add(words,sub(str,1,id-1))
   str=sub(str,id+1)
  end

  -- render lines
  local lc=0
  local x=x0
  for w in all (words) do
   if (x+tlen(w)-x0 > width) then
    lc+=1
    x=x0
   end
   pr(w,x,y0+lc*_current_font.gh,c1,c2)
   x+=tlen(w.." ")
  end
end

-- custom font text length
-- kerning is calculated on first draw
function tlen(str)
 local l,i=0,1
 while i<=#str do
  local char=sub(str,i,i)
  if char=="^" then
   char=sub(str,i,i+1)
   i+=1
  else
   char=char.." "
  end
  l+=_kerning[char]
  i+=1
 end
 return l
end


function indexof(str,c) 
 for i=1,#str do
  if (sub(str,i,i)==" ") return i
 end
 return 0
end

function suffix(n)
	if(n%100 >= 10 and
				n%100 < 20) then
		return "th"
	end
	if(n%10 == 1) return "st"
	if(n%10 == 2) return "nd"
	if(n%10 == 3) return "rd"
	return "th"
end
-->8
-- card stuff
function open_card(card)
 card.flp=1
 dset(card.id,2)
end

function update_card(card)
 if card.flp>0 then
  card.flp+=1
  if (card.flp>10) card.flp+=4
 end
 
 if t>card.delay then
  card.ox*=0.8
  card.oy*=0.8
  if (abs(card.ox)<0.1) card.ox=0
  if (abs(card.oy)<0.1) card.oy=0
 end
 
 card.oz=10*sin(card.flp/40)
 card.rot=min(card.flp/5,2)

 if card.rot==1 then
  card.state=2
 end
 if card.flp==20 then
  card.flp=0
  for i=1,32 do
   local cx,cy=get_card_pos(card.gx,card.gy,(card.id <= 12 and 0 or 1))
   local f=3+rnd(1)
   local a=rnd()
   add(particles,{
    x=cx+8+f*cos(a),
    y=cy+8+f*sin(a),
    a=a,
    r=3+rnd(6),
    f=f,
    ff=0.6+rnd(2)/10,
    life=30+rnd(30),
    df=function(p,c,dy)
        circfill(p.x,p.y+dy,p.r+dy,c)
        
        p.x+=p.f*cos(p.a)
        p.y+=p.f*sin(p.a)
        
        p.r-=0.2
        p.f*=p.ff
        
        p.life-=1
        if p.life<=0 then
         del(particles,p)
        end
       end
   })
  end
 end

end


function draw_card(px,py,card,skip_shadow)
 if card.selected then
  --rectfill(px-1,py-1,px+18,py+19,7)
 end
 
 -- shadow
 if not skip_shadow then
  rrectfill(px,py+1,
            px+cw-1,py+ch,
            1,1-card.rot)
 end
          
 -- draw card
 if ((flr(t/2+70)-card.gx-card.gy)%100<2) then
  set_pal(light_pal)
 else
  pal()
 end
  
 local str=""..card.day
 local len=tlen(str)

 if card.state==0 then
  -- locked
  -- do nothing
  
  --rrectfill(px,py+card.oz,
  --          px+cw-1,py+ch-1-card.rot,
  --          13)

  sspr(128-cw-32,0,
  					cw,ch,
  					px,py+card.oz,
  					cw,ch-card.rot)
  spr(60,px+7,py+7+card.oz,2,1)
  pr_v(str,px+19-len,py+8+card.oz,0)
 elseif card.state==1 then
  -- unlocked
  --[[
  rrectfill(px,py+card.oz,
            px+cw-1,py+ch-1+card.oz,
            6,1-card.rot)
 	--]]
 	local sr = 1-card.rot
  sspr(128-cw, 0,
  					cw,ch,
  					px-(cw*sr)/2+(cw/2),py+card.oz,
  					cw*sr,ch+card.oz)
  if card.flp==0 then
   spr(60,px+7,py+7+card.oz,2,1)
  	pr_v(str,px+19-len,py+8+card.oz,0)
  end
 else
  -- opened
  rrectfill(px,py+card.oz,
            px+cw-1,py+ch-1+card.oz,
            card.bg,1-card.rot)
  if card.oz==0 then
   local icon=126+card.icon*2
   if (card.icon>8) icon+=16
   if (card.icon>16) icon+=16
   if (card.icon>24) icon+=16
   spr(icon,px+1,py+1+card.oz,2,2)
  else
   if card.rot>1 then
    local sx=16*(card.icon-1)
    local sy=64
    if (card.icon>8) then
     sx-=128
     sy+=16
    end
    if (card.icon>16) then
     sx-=128
     sy+=16
    end
    if (card.icon>24) then
     sx-=128
     sy+=16
    end
    local w=card.rot/2
    sspr(sx,sy,
         16,16,
         px+1+8-8*w,
         py+1+card.oz,
         w*16,16)
   end
  end
 end

 pal()
 
 -- new token
 if card.state==2 or card.state==2 then
  if card.flp==0 then
   circfill(px+16,py+2,2,2)
   circfill(px+16,py+1,2,8)
   circfill(px+16,py,1,14)
  end
 end
end

function play_card(card)
 card.state=3
 dset(card.id,3)

 -- circle
 for r=160,0,-8 do
  for a=0,1,0.01 do
   circfill(preview.x+11+r*cos(a),
            preview.y+11+r*sin(a),
            16,0)
  end
  flip()
 end
 -- present
 do_exit_anim(card)

 -- load it
 load(card.cart,"back to calendar")
 cart_not_found()
end

function do_exit_anim(card)
 -- code by @2darray
 local tt=0
	daynumber=""..card.day
	::_::
	tt+=1/30
	if (btnp(❎)) goto donewithintro
	cls()
	f=4-abs(tt-4)
	for z=-3,3 do
	 for x=-1,1 do
	  for y=-1,1 do
	   b=mid(f-rnd(.5),0,1)
	   b=3*b*b-2*b*b*b
	   a=atan2(x,y)-.25
	   c=8+(a*8)%8
	   if (x==0 and y==0) c=7
	   u=64.5+(x*13)+z
	   v=64.5+(y*13)+z
	   w=8.5*b-abs(x)*5
	   h=8.5*b-abs(y)*5
	   if (w>.5) rectfill(u-w,v-h,u+w,v+h,c) rect(u-w,v-h,u+w,v+h,c-1)
	  end
	 end
	end
	 
	if rnd()<f-.5 then
	 ?daynumber,69-#daynumber*2,65,2
	 draw_card(59,59,card,true)
	end
	 
	if f>=1 then
	 for j=0,1 do
	  for i=1,f*50-50 do
	   x=cos(i/50)
	   y=sin(i/25)-abs(x)*(.5+sin(tt))
	   circfill(65+x*8,48+y*3-j,1,2+j*6)
	  end
	 end
	 
  for i=1,20 do
--   ?sub("pico-8 advent calendar",i),17+i*4,90,mid(-1-i/20+f,0,1)*7
   ?sub("advent calendar day "..card.id,i),17+i*4,90,mid(-1-i/20+f,0,1)*7
  end

	end
	 
	if (tt>=4) goto donewithintro
	 
	flip()
	goto _
	::donewithintro::
end


-->8
-- drawing helpers

function rrectfill(x0,y0,x1,y1,c,ratio)
 local r=ratio and abs(ratio) or 1
 local w=(x1-x0)*r/2
 local xc=x0+(x1-x0)/2
 rectfill(xc-w+1,y0,xc+w-1,y1,c)
 rectfill(xc-w,y0+1,xc+w,y1-1,c)
end

function draw_bg(px,py)
 for x=0,4 do
  for y=0,9 do
   local id=0
   if ((x-y)%5==0) id=4
   spr(id,px+x*32-y%2*16,py+y*16-3,4,2)
  end
 end
end


function draw_banner(x,y)
 rectfill(x,y,x+127,y+6,8)
 rect(x-1,y-1,x+128,y+7,1)
 
 spr(48,x+1,y+1,4,1)
 spr(52,x+104,y+1,3,1)
 pr("^advent ^calendar",
    x+41,y+1,7)
end

function draw_preview()
 local c=preview.card
 local x=flr(preview.x)
 local y=flr(preview.y)-4
 rrectfill(x,y,x+109,y+51,15)
 rrectfill(x+1,y+1,x+108,y+50,7)

 -- day
 local str=""..c.day
 local len=tlen(str)
 rrectfill(x+99,y+2,
           x+107,y+8,15)
 pr(str,x+104-len/2,y+3,7)
 
 -- card
 draw_card(x+2,y+2,c)
 if(c.state == 0) then
 	-- hide name, desc, and
 	-- author if locked
 	pr("^december "..c.day..suffix(c.day),x+24,y+4,5,15)
	 pr("^cartridge locked",x+24,y+13,13)
	 
	 pr_w("^this present hasn't been opened yet! ^come back on the "..c.day..suffix(c.day).." to see what's inside!",x+2,y+23,107,13)
 else
	 pr(c.name,x+24,y+4,5,15)
	 pr("by    "..c.author,x+24,y+13,13)
	 spr(55,x+35,y+13)
	 
	 pr_w(c.desc,x+2,y+23,107,13)
	end

 if c.state==0 then  
  local dl=c.day-d_day
  draw_button("     "..dl.." ^d^a^y^s",x+28,y+42,8,5)
  spr(58,x+13,y+43)
 elseif c.state==1 then
  draw_button("     ^o^p^e^n", x+28,y+42,9,4,preview.hover==1)
  spr(57,x+15,y+43)
 else
  draw_button("     ^p^l^a^y", x+28,y+42,3,5,preview.hover==1)
  spr(57,x+15,y+43)
 end
 draw_button("     ^c^l^o^s^e",x+80,y+42,13,5,preview.hover==2)
 spr(56,x+66,y+43)
 
end

function draw_button(str,x,y,c1,c2,hover)
 if hover then
  c1=light_pal[c1+1]
  c2=light_pal[c2+1]
 end
 rrectfill(x-20,y,
           x+20,y+7,c2) 
 rrectfill(x-20,y,
           x+20,y+6,c1) 
 pr(str,x-tlen(str)/2,y+1,7)
end


