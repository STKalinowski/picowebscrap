--witch n wiz
printh("--")
tsize=16
toff=tsize/8
st_intro=0
st_title=1
st_lvl_sel=2
st_gameplay=3
st_lvl_comp=4
move_delay=16
ml=14
cartdata("mbh_witchnwiz")
ver=4--save game version
function clr_save()
	for i=1,64 do
		dset(i,0)
	end
end
if dget(0)<ver then
	clr_save()
end
dset(0,ver)
--audio
snd=
{
	text=0,
	ok=1,
	cancel=2,
	walk=3,
	jump_on=4,
	beep=5,
	climb_up=6,
	climb_down=7,
	push=8,
	kill=9,
	fall=10,
	cobwebs=11,
	rewind=12,
	switch_char=13,
	portal=15,
	bang0=16,
	bang1=17,
	fin1=60,
	fin2=61,
}
mus=
{
	text=0,
	title=30,
	lvl_sel=47,
	p1a=3,
	p1b=18,
	p2=35,
	m_in=15,
	m_get=17,
	crd=48,
	fin3=53,
}
last_pat=-1
d,m,l=13,6,7
pal_map=
{
	{
		{0,0},
		{1,m},
		{2,d},
		{3,m},
		{4,d},
		{5,d},
		{6,d},
		{7,m},
		{8,m},
		{9,m},
		{10,l},
		{11,l},
		{12,l},
		{13,m},
		{14,l},
		{15,l},
	},
}
function n_lvl(
	min_x,min_y,
	max_x,max_y)
	return
	{
		min={ x=min_x, y=min_y },
		max={ x=max_x, y=max_y },
	}
end
levels=
{
 n_lvl(15,48,30,63),
 n_lvl(31,48,46,63),
 --1p
	n_lvl(30,0,45,15),--e
	n_lvl(118,0,127,15),
	n_lvl(0,0,15,17),--m
 n_lvl(38,16,55,31),
	n_lvl(0,16,15,31),
	n_lvl(54,16,71,31),
	n_lvl(14,30,33,49),
	n_lvl(110,28,127,43),
	n_lvl(66,0,89,19),--h
	n_lvl(88,0,119,23),
	n_lvl(34,30,63,47),
	--mp
	n_lvl(47,48,62,63),--in
	n_lvl(98,48,113,63),--e
 n_lvl(0,48,15,63),
	n_lvl(104,20,119,29),
	n_lvl(118,14,127,29),
	n_lvl(78,20,95,31),--m
	n_lvl(62,32,76,48),
 n_lvl(80,30,95,47),--h
	--2p
	n_lvl(61,48,76,63),--in
	n_lvl(96,22,105,31),--e
	n_lvl(15,0,30,15),
 n_lvl(14,14,39,31),--m
	n_lvl(44,0,67,17),
	n_lvl(0,30,15,49),
	n_lvl(96,30,111,49),
	n_lvl(112,42,127,63),--h
	--end
 n_lvl(77,48,92,63),
}
function is_obj_below(self)
	for v in all(objs) do
		if v!=self then
			if (v.x==self.x
				and v.y==self.y+toff)
				or (self.is_player and v.is_player
				and v.px==self.px
				and v.py==self.py+toff) then
				return true
			end
		end
	end
	return false
end
function is_obj_beside(self,d)
	for v in all(objs) do
		if v!=self then
			if v.x==self.x+d
				and v.y==self.y
				and not v.in_door then
				return true,v
			end
		end
	end
	return false
end
function is_obj_in_dir(self,dx,dy)
	for v in all(objs) do
		if v!=self then
			if v.x==self.x+dx
				and v.y==self.y+dy then
				return true
			end
		end
	end
	return false
end
function is_movable_side(self,d)
	for v in all(objs) do
		if v!=self and v.movable==true then
			if v.x==self.x+d and v.y==self.y then
				return true,v
			end
		end
	end
	return false,nil
end
function is_movable_above(self)
	for v in all(objs) do
		if v!=self and v.movable==true then
			if v.x==self.x and v.y==self.y-toff then
				return true,v
			end
		end
	end
	return false,nil
end
function fall_down(self,t,td)
	a,b,c,max_y=get_level_bounds()
	on_screen=
		self.y*8<max_y-16
	if not fget(t,1) then
		if not fget(td,0)
			and not fget(td,1)
			and not fget(td,2)
			and not is_obj_below(self)
			and on_screen==true then
			self.y+=toff
			self.time_since_move=0
			if not self.block_fall then
				sfx(snd.fall)
				self.block_fall=true
			end
			self:set_anim("fall")
			return true
		end
	end
	return false
end
function move_up(self,t,tu)
	if fget(t,1)
		and not fget(tu,0)
		and not is_obj_in_dir(self,0,-toff)
		then
		self.y-=toff
		self.time_since_move=0
		self:set_anim("climb_up")
		self.flip_x=false
		sfx(snd.climb_up)
		return true
	else
		return false
	end
end
function move_down(self,t,td)
	a,b,c,max_y=get_level_bounds()
	on_screen=
		self.y*8<max_y-tsize
	if on_screen
		and not fget(td,0)
		and not fget(td,2)
		and not is_obj_below(self) then
		self.y+=toff
		self.time_since_move=0
		self:set_anim("climb_down")
		sfx(snd.climb_down)
		self.flip_x=false
		return true
	else
		return false
	end
end
function move_horz(
	self,ht,flipx,dir_mod)
	can_move=not fget(ht,0)
	b,o=is_obj_beside(self,dir_mod*toff)
	if can_move and self.movable==true then
		if b then
			can_move=false
		end
		if fget(ht,1)==true then
			can_move=false
		end
	elseif b and self.is_player==true and o.is_player==true then
		can_move=false
	end
	min_x,max_x=get_level_bounds()
	can_move=can_move and
		self.x*8+dir_mod*tsize>=
		min_x and
		self.x*8+dir_mod*tsize<
		max_x
	if can_move==true then
		b,o=is_movable_side(self,dir_mod*toff)
		if b==true then
			nt=get_tile_in_horz_dir(o,dir_mod)
			if move_horz(o,nt,flipx,dir_mod) then
				self.time_since_move=0
				if fget(mget(self.x,self.y),1) then
					self:set_anim("push_climb")
					sfx(snd.push)
				else
					self:set_anim("push")
					sfx(snd.push)
				end
			end
			self.flip_x=flipx
		else
			if fget(ht,1) then
				self:set_anim("jump_ladder")
				sfx(snd.jump_on)
			elseif is_obj_beside(self,dir_mod*toff) then
				self:set_anim("punch")
				sfx(snd.kill)
			else
				self:set_anim("walk")
				sfx(snd.walk)
			end
			self.x+=dir_mod*toff
			self.time_since_move=0
			self.flip_x=flipx
		end
		return true
	end
	return false
end
function move_right(self,tr)
	return move_horz(self,tr,false,1)
end
function move_left(self,tl)
	return move_horz(self,tl,true,-1)
end
function get_tile_in_horz_dir(self,d)
	t,tl,tr=get_tiles_around(self)
	if(d<0)return tl
	if(d>0)return tr
end
function get_tiles_around(self)
	t=mget(self.x,self.y)
	tl=mget(self.x-toff,
		self.y)
	tr=mget(self.x+toff,
		self.y)
	tu=mget(self.x,
		self.y-toff)
	td=mget(self.x,
		self.y+toff)
	return t,tl,tr,tu,td
end
function clear_map_tile(x,y,id)
	for y2=0,toff-1 do
		for x2=0,toff-1 do
			mset(x+x2,y+y2,id)
		end
	end
end
function get_render_pos(self)
	lerp=self.time_since_move/move_delay
	dx=(self.x*8)-(self.px*8)
	fx=(self.px*8)+(dx*lerp)
	dy=(self.y*8)-(self.py*8)
	fy=(self.py*8)+(dy*lerp)
	return fx,fy
end
function backinquart(t,b,c,d)
	t/=d
	ts=(t)*t
	tc=ts*t
	return b+c*(-11.3475*tc*ts + 19.4475*ts*ts + -7.8*tc + 0.8*ts + -0.2*t)
end
function easeoutquint(t,b,c,d)
	t/=d;
	t-=1;
	return c*(t*t*t*t*t+1)+b;
end
function easeoutelastic(t,b,c,d)
	t/=d
	ts=(t)*t;
	tc=ts*t;
	return b+c*(33*tc*ts+-106*ts*ts+126*tc+-67*ts+15*t);
end
function printo(str,startx,
															 starty,col,
															 col_bg)
	print(str,startx+1,starty,col_bg)
	print(str,startx-1,starty,col_bg)
	print(str,startx,starty+1,col_bg)
	print(str,startx,starty-1,col_bg)
	print(str,startx+1,starty-1,col_bg)
	print(str,startx-1,starty-1,col_bg)
	print(str,startx-1,starty+1,col_bg)
	print(str,startx+1,starty+1,col_bg)
	print(str,startx,starty,col)
end
function printc(
	str,x,y,
	col,col_bg,
	special_chars)
	len=(#str*4)+(special_chars*3)
	startx=x-(len/2)
	starty=y-2
	printo(str,startx,starty,col,col_bg)
end
function find_players()
	p={}
	for o in all(objs) do
		if o.is_player then
			add(p,o)
		end
	end
	return p
end
function restore_copy(o)
	c=o.create(-1,-1)
	for k,v in pairs(o) do
		--don't add the create function
		if type(o)!="function" then
			c[k]=v
		end
	end
	return c
end
function new_fx_spawn_mirror_player(np)
	for i=0,8 do
		add(objs,
			new_fx_push(
				np.x*8+rnd(16),np.y*8+rnd(16)))
		add(objs,
			new_fx_kill_stars(
				np.x*8+8,np.y*8+8))
	end
end
function new_fx_char_switch(_par)
	o=new_fx(_par.x,_par.y)
	o.ticks=move_delay*3
	o.frames={0}
	o.grav=0
	o.par=_par
	o.draw=function(self)
		lerp=self.cur_tick/self.ticks
		w=toff*8*
			sin(lerp)
		rx,ry=get_render_pos(self.par)
		sspr(
			self.par.port_x*8,
			0,
			toff*8,
			toff*8,
			rx+8-(w/2),ry-18,
			w,
			toff*8,true)
	end
	return o
end
function new_fx_push(_x,_y)
	return new_fx(_x,_y)
end
function new_fx_kill(_x,_y)
	o=new_fx(_x,_y)
	o.w,o.h=8,8
	o.frames={10}
	o.ticks=move_delay/2
	o.grav=0
	o.draw=function(self)
		for y=0,1 do
			for x=0,1 do
				spr(self.frames[1],
				self.x+x*8,self.y+y*8,
				self.w/8,self.h/8,
				x>0,y>0)
			end
		end
	end
	return o
end
function new_fx_body(_x,_y,_frames,_dir)	o=new_fx(_x,_y)
	o.w,o.h=16,16
	o.frames=_frames
	o.ticks=move_delay*10
	o.dx=(rnd(1))*_dir
	o.dy=-2
	return o
end
function new_fx_kill_stars(_x,_y)
	o=new_fx(_x,_y)
	o.w,o.h=8,8
	o.frames={26,109}
	o.ticks=move_delay*(rnd(1)+0.5)
	o.dx=(rnd(2)-1)
	o.dy=(rnd(2)*-1)
	return o
end
function new_fx(_x,_y,_dx,_dy)
	if(_dx==nil)_dx=0
	if(_dy==nil)_dy=0
	return
	{
		x=_x,
		y=_y,
		dx=_dx,
		dy=_dy,
		grav=0.05,
		w=8,
		h=8,
		ticks=5,
		frames={124,125},
		cur_frame=1,
		cur_tick=0,
		flip_x=false,
		flip_y=false,
		update=function(self)
			self.cur_tick+=1
			self.x+=self.dx
			self.dy+=self.grav
			self.y+=self.dy
			if self.cur_tick>self.ticks then
				self.cur_frame+=1
				self.cur_tick=0
				if self.cur_frame>#self.frames then
					del(objs,self)
					del(hud_objs,self)
					return
				end
			end
		end,
		draw=function(self)
			spr(self.frames[self.cur_frame],
				self.x-(self.w/2),
				self.y-(self.h/2),
				self.w/8,
				self.h/8,
				self.flip_x,self.flip_y)
		end,
	}
end
function new_player(_x,_y)
	return
	{
		x=_x,
		y=_y,
		px=_x,
		py=_y,
		time_since_move=move_delay-1,
		is_player=true,
		is_clone=false,
		is_cur=false,
		in_door=false,
		block_fall=false,
		anims=
		{
			["idle"]=
			{
				ticks=0,
				frames={2},
			},
			["idle_climb"]=
			{
				ticks=0,
				frames={68},
			},
			["walk"]=
			{
				ticks=move_delay/4,
				frames={2,6,32,6},
			},
			["push"]=
			{
				ticks=0,
				frames={36},
			},
			["push_climb"]=
			{
				ticks=0,
				frames={64},
			},
			["punch"]=
			{
				ticks=move_delay/2,
				frames={96,36},
			},
			["jump_ladder"]=
			{
				ticks=move_delay/2,
				frames={32,36},
			},
			["climb_up"]=
			{
				ticks=5,
				frames={68},
			},
			["climb_down"]=
			{
				ticks=5,
				frames={68},
			},
			["fall"]=
			{
				ticks=0,
				frames={100},
			},
		},
		curanim="idle",
		curframe=1,
		animtick=0,
		flip_x=false,
		port_x=14,
		set_anim=function(self,anim)
			if(anim==self.curanim)return
			a=self.anims[anim]
			self.animtick=a.ticks
			self.curanim=anim
			self.curframe=1
		end,
		update_anim=function(self)
			self.animtick-=1
			if self.animtick<=0 then
				self.curframe+=1
				a=self.anims[self.curanim]
				self.animtick=a.ticks
				if self.curframe>#a.frames then
					self.curframe=1
				end
			end
		end,
		copy=function(self)
			return{
			create=new_player,
			x=self.x,
			y=self.y,
			px=self.px,
			py=self.py,
			is_cur=self.is_cur,
			anims=self.anims,
			curanim=self.curanim,
			curframe=self.curframe,
			animtick=self.animtick,
			flipx=self.flip_x,
			port_x=self.port_x,
			in_door=self.in_door,
			is_clone=self.is_clone,
			}
		end,
		update=function(self)
			bl,br,bu,bd=btn(0),btn(1),btn(2),btn(3)
			self.time_since_move+=1
			if self.time_since_move<move_delay then
				rx,ry=get_render_pos(self)
				if fget(mget(self.x,self.y),2) then
					o=tsize
					if(self.x<self.px)o=0
					add(objs,new_fx_push(rx+o,ry+rnd(tsize)))
					sfx(snd.cobwebs)
				end
				self:update_anim()
				return
			end
			if fget(mget(self.x,self.y),1) then
				self:set_anim("idle_climb")
			else
				self:set_anim("idle")
			end
			self.px=self.x
			self.py=self.y
			t,tl,tr,tu,td=get_tiles_around(self)
			moved=fall_down(self,t,td)
			if not moved then
				self.block_fall=false
			end
			if self.is_cur
				and not moved
				and self.time_since_move==move_delay then
				request_level_save()
			end
			if state!=st_gameplay
				or not self.is_cur
				or self.in_door then
				moved=true
			end
			if bl and not moved then
				moved=move_left(self,tl)
				self.flip_x=true
			end
			if br and not moved then
				moved=move_right(self,tr)
				self.flip_x=false
			end
			if bu and not moved then
				moved=move_up(self,t,tu)
			end
			if bd and not moved then
				moved=move_down(self,t,td)
			end
			--enemy
			for v in all(objs) do
				if v.must_kill == true and
					v.px==self.px and
					v.py==self.py then
					del(objs,v)
					cam:shake(5,2)
					for i=0,5 do
						add(objs,
							new_fx_kill_stars(
								v.x*8+tsize/2,
							 v.y*8+tsize/2))
					end
					add(objs,
						new_fx_kill(
							v.x*8,
						 v.y*8))
					add(objs,
						new_fx_body(
							v.x*8+tsize/2,
						 v.y*8+tsize/2,
						 v.anims["idle"].frames,
						 self.flip_x==true and -1 or 1))
				end
			end
			--sand
			if fget(mget(self.px,self.py),2) then
				clear_map_tile(self.px,self.py,0)
			end
			self:update_anim()
		end,
		draw=function(self)
			if self.in_door then
				return
			end
			if not self.is_cur then
				for c in all(pal_map[1]) do
					pal(c[1],c[2])
				end
			end
			if self.is_clone then
				for c=0,15 do
					nc=0
					if(c==3)nc=10
					pal(c,nc)
				end
			end
			lerp=self.time_since_move/move_delay
			dx=(self.x*8)-(self.px*8)
			fx=(self.px*8)+(dx*lerp)
			dy=(self.y*8)-(self.py*8)
			fy=(self.py*8)+(dy*lerp)
			if self.curanim=="punch" then
					fx=backinquart(
					min(lerp,1),
					self.px*8,dx,
					1)
			elseif self.curanim=="jump_ladder"then
				fx=backinquart(
					min(lerp,1),
					self.px*8,dx,
					1)
				if lerp>0.5 then
					fy-=(lerp-0.5)*6
				end
			end
			if self.curanim=="climb_up"
				or self.curanim=="climb_down"
				or self.curanim=="idle_climb" then
				fy-=2
				if self.curanim!="idle_climb" then
					fy+=sin(tick*0.1)*-1
				end
			elseif fget(mget(self.px,self.py),1) then
				fy-=2
			end
			a=self.anims[self.curanim]
			frame=a.frames[self.curframe]
			flpx=self.flip_x
			if frame<0 then
				flpx=not flpx
				frame*=-1
			end
			if self.curanim=="climb_up"
				or self.curanim=="climb_down" then
				sspr((frame%16)*8,flr((frame/16))*8,
					16,15+((tick*0.2)%2),
					fx,fy,
					16,15,
					flpx)
			else
			spr(frame,fx,fy,
				toff,toff,
				flpx,false)
			end
			if not self.is_cur
				or self.is_clone  then
				for i=0,15 do
					pal(i,i)
				end
			end
		end,
	}
end
function new_enemy(_x,_y)
	return
	{
		x=_x,
		y=_y,
		px=_x,
		py=_y,
		must_kill=true,
		floats=true,
		movable=false,
		squish=
		{
			active=false,
			frames=nil,
			ticks=0,
			cur_frame=1,
			dx=4,
			dy=4,
			update=function(self,owner)
				if self.frames!=nil then
					self.ticks+=1
					if self.ticks>30 then
						self.cur_frame=((self.cur_frame)%#(self.frames))+1
						self.ticks=0
					end
				end
			end,
			draw=function(self,fx,fy)
				frame=self:get_frame()
				if frame!=nil then
					spr(frame,fx+self.dx,fy+self.dy)
				end
			end,
			get_frame=function(self)
				if self.frames!=nil then
					return self.frames[self.cur_frame]
				else
					return nil
				end
			end,
		},
		time_since_move=move_delay-1,
		anims=
		{
			["idle"]=
			{
				ticks=30,
				frames={44,46},
			},
			["walk"]=
			{
				ticks=5,
				frames={44,46},
			},
			--todo
			["fall"]=
			{
				ticks=30,
				frames={44,46},
			},
		},
		curanim="idle",
		curframe=1,
		animtick=0,
		flip_x=false,
		set_anim=function(self,anim)
			if(anim==self.curanim)return
			a=self.anims[anim]
			self.animtick=a.ticks
			self.curanim=anim
			self.curframe=1
		end,
		update_anim=function(self)
			self.animtick-=1
			if self.animtick<=0 then
				self.curframe+=1
				a=self.anims[self.curanim]
				self.animtick=a.ticks
				if self.curframe>#a.frames then
					self.curframe=1
				end
			end
		end,
		--6k
		copy=function(self)
			return {
			create=new_enemy,
			x=self.x,
			y=self.y,
			px=self.px,
			py=self.py,
			must_kill=self.must_kill,
			floats=self.floats,
			movable=self.movable,
			anims=self.anims,
			curanim=self.curanim,
			curframe=self.curframe,
			animtick=self.animtick,
			flip_x=self.flip_x,
			squish=self.squish,
			}
		end,
		update=function(self)
			self.squish:update(self)
			self.time_since_move+=1
			if self.time_since_move<move_delay then
				self:update_anim()
				if self.time_since_move%4==0 and
					self.movable and
					self.x!=self.px then
					rx,ry=get_render_pos(self)
					add(objs,
						new_fx_push(rx+tsize,
							ry+tsize))
					add(objs,
						new_fx_push(rx,
							ry+tsize))
				end
				return
			end
			self.px=self.x
			self.py=self.y
			t,tl,tr,tu,td=get_tiles_around(self)
			if not self.floats then
				moved=fall_down(self,t,td)
			end
			if is_obj_in_dir(self,0,-toff) then
				self.squished=true
			else
				self.squished=false
			end
			self:update_anim()
		end,
		draw=function(self)
			fx,fy=get_render_pos(self)
			a=self.anims[self.curanim]
			frame=a.frames[self.curframe]
			if self.curanim=="walk"
				and self.movable==true then
				lerp=self.time_since_move/move_delay
				fx=easeoutquint(
					min(lerp,1),
					self.px*8,dx,
					1)
			end
			spr(frame,fx,fy,toff,toff)
			if self.squished==true then
				self.squish:draw(fx,fy)
			end
		end,
	}
end
function new_mirror(_x,_y)
	return
	{
		x=_x,
		y=_y,
		copy=function(self)
			return {
			create=new_mirror,
			x=self.x,
			y=self.y,
			}
		end,
		update=function(self)
			players=find_players()
			for p in all(players) do
				if p.px==self.x
					and p.py==self.y
					and p.in_door==false then
					for i=0,5 do
						add(objs,
							new_fx_kill_stars(self.x*8+8,self.y*8+8))
					end
					o=p:copy()
					np=restore_copy(o)
					np.x=np.px
					np.y=np.py
					np.y-=8
					np.py=np.y
					np.is_clone=true
					add(objs,np)
					new_fx_spawn_mirror_player(np)
					music(mus.m_get)
					sfx(-1,3)
					del(objs,self)
				end
			end
		end,
		draw=function(self)
			lerp=sin(tick*0.005)
			spr(27,
			self.x*8,
			self.y*8+lerp*4-3)
			dx=rnd(8)
			dy=rnd(8)
			c={7,12}
			line(self.x*8+dx,self.y*8+15,
				self.x*8+dx,self.y*8+8-dy,
				c[flr(rnd(#c))+1])
			draw_beam(self,1)
		end,
	}
end
function new_portal(_x,_y)
	return
	{
		x=_x,
		y=_y,
		is_door=true,
		copy=function(self)
			return {
			create=new_portal,
			x=self.x,
			y=self.y,
			}
		end,
		update=function(self)
			players=find_players()
			for p in all(players) do
				if p.px==self.x
					and p.py==self.y
					and p.in_door==false then
					p.in_door=true
					for i=0,5 do
						add(objs,
							new_fx_kill_stars(self.x*8+8,self.y*8+8))
					end
					sfx(snd.portal)
				end
			end
		end,
		draw=function(self)
			r=8
			x=self.x*8+7
			y=self.y*8+7
			circfill(
				x,
				y,
				r,0)
			circ(x,y,
				r-(tick%r),
				1)
			circ(x,y,
				r-((tick+1)%r),
				12)
			circ(x,y,
				r-((tick+2)%r),
				7)
		end,
	}
end
function new_sprite(_x,_y,_frame)
	return
	{
		x=_x,
		y=_y,
		frame=_frame,
		copy=function(self)
			return {
			create=new_sprite,
			x=self.x,
			y=self.y,
			frame=self.frame,
			}
		end,
		draw=function(self)
			spr(self.frame,self.x*8,self.y*8)
		end,
	}
end
--make 2d vector
function new_vec(x,y)
	v=
	{
		x=x,
		y=y,
		get_length=function(self)
			return sqrt(self.x^2+self.y^2)
		end,
		get_norm=function(self)
			l = self:get_length()
			return new_vec(self.x / l, self.y / l),l;
		end,
	}
	return v
end
function new_cam(target)
	c=
	{
		tar=target,
		pos=new_vec(target.x*8,target.y*8),
		pull_threshold=16,
		pos_min=new_vec(64,64),
		pos_max=new_vec(64+128,64),
		shake_remaining=0,
		shake_force=0,
		tar_off=new_vec(0,0),
		b_tick=0,
		update=function(self)
			self.b_tick+=1
			if(btn(0,1))then self.tar_off.x=max(self.tar_off.x-1,-32) self.b_tick=0
			elseif(btn(1,1))then self.tar_off.x=min(self.tar_off.x+1,32) self.b_tick=0 end
			if(btn(2,1))then self.tar_off.y=max(self.tar_off.y-1,-32) self.b_tick=0
			elseif(btn(3,1))then self.tar_off.y=min(self.tar_off.y+1,32) self.b_tick=0 end
			if self.b_tick>30 then self.tar_off.y*=0.9 self.tar_off.x*=0.9 end
			self.shake_remaining=max(0,self.shake_remaining-1)
			d=self.pos_max.x-self.pos_min.x
			if d<0 then
				d2=abs(d)*0.5
				self.pos_max.x+=d2
				self.pos_min.x-=d2
			end
			d=self.pos_max.y-self.pos_min.y
			if d<0 then
				d2=abs(d)*0.5
				self.pos_max.y+=d2
				self.pos_min.y-=d2
			end			
			px,py=get_render_pos(self.tar)
			if self:pull_max_x()<px then
				self.pos.x+=min(px-self:pull_max_x(),4)
			end
			if self:pull_min_x()>px then
				self.pos.x+=max((px-self:pull_min_x()),-4)
			end
			if self:pull_max_y()<py then
				self.pos.y+=min(py-self:pull_max_y(),4)
			end
			if self:pull_min_y()>py then
				self.pos.y+=max((py-self:pull_min_y()),-4)
			end
			--lock to edge
			if(self.pos.x<self.pos_min.x)self.pos.x=self.pos_min.x
			if(self.pos.x>self.pos_max.x)self.pos.x=self.pos_max.x
			if(self.pos.y<self.pos_min.y)self.pos.y=self.pos_min.y
			if(self.pos.y>self.pos_max.y)self.pos.y=self.pos_max.y
		end,
		draw=function() end,
		cam_pos=function(self)
			shk=new_vec(0,0)
			if self.shake_remaining>0 then
				shk.x=rnd(self.shake_force)-(self.shake_force/2)
				shk.y=rnd(self.shake_force)-(self.shake_force/2)
			end
			return self.pos.x-64+shk.x+self.tar_off.x,
				self.pos.y-64+shk.y+self.tar_off.y
		end,
		pull_max_x=function(self)
			return self.pos.x+self.pull_threshold
		end,
		pull_min_x=function(self)
			return self.pos.x-self.pull_threshold
		end,
		pull_max_y=function(self)
			return self.pos.y+self.pull_threshold
		end,
		pull_min_y=function(self)
			return self.pos.y-self.pull_threshold
		end,
		shake=function(self,ticks,force)
			self.shake_remaining=ticks
			self.shake_force=force
		end
	}
	return c
end
function set_state(new_state)
	skip_lvl_sel=false
	old_state=state
	if state==st_title then
		clear_title_gfx()
		if lvl==1 then
			skip_lvl_sel=true
		end
	elseif state==st_lvl_sel then
	elseif state==st_lvl_comp then
		cam=nil
	 objs={}
	 hist={}
	 hud_objs={}
 	--reload map data
		reload(0x2000,0x2000,0x1000)
	end
 state=new_state
 tick=0
 if state==st_intro then
 	music(mus.text)
	elseif state==st_title then
		music(mus.title)
		load_title_gfx()
	elseif state==st_lvl_sel then
		if old_state!=st_title then
			music(mus.lvl_sel)
		end
		mus_played=false
		if skip_lvl_sel then
			set_state(st_gameplay)
		end
 elseif state==st_gameplay then
	 if lvl==ml then
	 	music(mus.m_in)
	 	mus_played=false
	 elseif lvl==1 then
	 	music(mus.p1a)
	 	mus_played=true
		elseif lvl==#levels then
			music(mus.crd)
			mus_played=true
	 elseif not mus_played then
	 	if lvl>11 then
	 		music(mus.p1b)
	 	else
		 	music(mus.p1a)
		 end
			mus_played=true
		end
 	srand(0)
 	lvl_tick=0
 	tick_since_rewind=99
 	p1,p2=nil,nil
 	multi=false
 	best=dget(lvl)
 	tfin=0
		for y=levels[lvl].min.y,levels[lvl].max.y  do
			for x=levels[lvl].min.x,levels[lvl].max.x do
				tile=mget(x,y)
				if tile==44 then
					e=new_enemy(x,y)
					e.squish.frames={127}
					add(objs,e)
					clear_map_tile(x,y,0)
				elseif tile==40 then
					e=new_enemy(x,y)
					e.anims["idle"].frames={40,42}
					e.anims["fall"].frames={40,42}
					e.floats=false
					e.squish.frames={126}
					e.squish.dy=0
					add(objs,e)
					clear_map_tile(x,y,0)
				elseif tile==78 then
					e=new_enemy(x,y)
					e.anims["idle"].frames={tile}
					e.anims["fall"].frames={tile}
					e.anims["walk"].frames={tile}
					e.floats=false
					e.movable=true
					e.must_kill=false
					add(objs,e)
					clear_map_tile(x,y,0)
				elseif tile==2
					or tile==4 then
					p=new_player(x,y)
					add(objs,p)
					clear_map_tile(x,y,0)
					if tile==2 then
						if(p1!=nil)p.is_clone=true
						p1=p
						p1.is_cur=true
					else
						p2=p
						for k,v in pairs(p2.anims) do
							for k2,v2 in pairs(v.frames) do
								p2.anims[k].frames[k2]+=toff
							end
						end
						p2.port_x=12
						multi=true
					end
				elseif tile==27 then
					add(objs,new_mirror(x,y))
					mset(x,y,0)
				elseif tile==10 then
					add(objs,new_portal(x,y))
					mset(x,y,0)
				elseif tile==11 then
					add(objs,new_sprite(x,y,tile))
					mset(x,y,0)
				end
			end
		end
		cam=new_cam(p1)
		cam.pos_min=new_vec(
			levels[lvl].min.x*8+64,
			levels[lvl].min.y*8+64)
		cam.pos_max=new_vec(
			(levels[lvl].max.x+1)*8-64,
			(levels[lvl].max.y+1)*8-64)
		save_level_state()
 elseif state==st_lvl_comp then
		if lvl==#levels then
			music(mus.fin3)
			tfin=0
		elseif is_new_best() then
	 	dset(lvl,lvl_tick)
	 	sfx(snd.fin2,3)
	 else
	 	sfx(snd.fin1,3)
		end
 end
end
function restart_puzzle()
	objs={}
	hud_objs={}
	hist={}
	--reload map data
	reload(0x1000, 0x1000, 0x2000)
	set_state(st_gameplay)
end
function goto_level_select()
	cam=nil
	objs={}
	hud_objs={}
	hist={}
	--reload map data
	reload(0x1000, 0x1000, 0x2000)
	set_state(st_lvl_sel)
end
function calc_time(t)
	if t==0 then
		return "--.--"
	end
	r=t%60
	if(r<10)r="0"..r
	h=flr(t/60)
	if(h<10)h="0"..h
	return h.."."..r
end
function draw_time(t)
	str="best:"..calc_time(best)
	printo(str,128-#str*4-2,2,
		7,0)
	str=calc_time(lvl_tick)
	printo("time:"..str,2,2,
		7,0)
end
function draw_scroll_text(intro,d)
	for i=1,#intro do
		s=intro[i]
		t=d*(i-1)
		if lvl_tick>t then
			t_speed=(lvl_tick-t)*0.5
			b=1
			if lvl_tick>t+d*4 then
				b=(lvl_tick*0.5)-(t+d*4)*0.5
			end
			printo(
				sub(s,b,t_speed+1),
				16,64-t_speed*0.2,
				7,0,0)
			last=sub(s,t_speed+1,t_speed+1)
		end
	end
	if last!="" then
		sfx(snd.text)
	end
end
function draw_beam(self,w)
	for c in all(pal_map[1]) do
		pal(c[1],c[2])
	end
	sspr(10*8,0,8,8,
		self.x*8,self.y*8+8,
		8*w,8,
		tick%2<1)
	for c=0,15 do
		pal(c,c)
	end
end
function request_level_save()
	request_save_count+=1
end
function store_level_save()
	t=
	{
		objs=pos_objs,
		mdata=pos_mdata,
	}
	add(hist,t)
	if #hist>100 then
		del(hist,hist[1])
	end
end
pos_objs={}
pos_mdata={}
function save_level_state()
	pos_objs={}
	for o in all(objs) do
		if o.copy!=nil then
			add(pos_objs,o:copy())
		end
	end
	pos_mdata={}
	for y=levels[lvl].min.y,levels[lvl].max.y  do
		for x=levels[lvl].min.x,levels[lvl].max.x do
			tile=mget(x,y)
			if fget(tile,2) then --sand
				add(pos_mdata,{x,y,tile})
			end
		end
	end
end
function restore_mdata(data)
	for t in all(data) do
		mset(t[1],t[2],t[3])
	end
end
function is_new_best()
	return lvl_tick<best or best==0
end
function get_level_bounds()
	l=levels[lvl]
	return l.min.x*8,
		(l.max.x+1)*8,
		l.min.y*8,
		(l.max.y+1)*8
end
function get_cur_pattern()
	for i=1,#pat_map do
		o=pat_map[i]
		p=o[1]
		match=true
		for j=2,#o do
			t=stat(14+j)
			if o[j][2]==-1 then
				if t!=-1 then
					match=false
				end
			elseif o[j][1]!=t then
				match=false
			end
		end
		if(match)return p
	end
	return -1
end
function build_pattern_map()
	pat_map={}
	for p=0,64 do
		new={p}
		found=false
		for c=0,3 do
			data=peek(0x3100+p*4+c)
	 	add(new,{band(data,63),band(data,64)!=0 and -1 or 0})
	 	found=found or band(data,64)==0
	 end
	 if found then
	 	add(pat_map,new)
	 end
	end
end
function _init()
	palt(0,false)
	palt(11,true)
	menuitem(1,
		"restart puzzle",
		restart_puzzle)
	menuitem(2,
		"select level",
		goto_level_select)
	menuitem(3,
		"!clear save data!",
		clr_save)
	build_pattern_map()
	reset()
end
function reset()
	--reload map data
	reload(0x2000, 0x2000, 0x1000)
	objs={}
	hist={}
	hud_objs={}
	tick=0
	lvl=1
	for i=1,64 do
		lvl=min(i,#levels)
		if dget(i)==0 then
			break
		end
	end
	best=0
	lvl_tick=0
	tick_since_rewind=99
	got_best=false
	mus_played=false
	tfin=0
	set_state(st_intro)
end
function _update60()
	tick+=1
	if state==st_intro then
		lvl_tick+=1
		if btnp(5) or tick>1500 then
			set_state(st_title)
			if(btnp(5))sfx(snd.ok)
		end
	elseif state==st_title then
		if btnp(5) then
			set_state(st_lvl_sel)
			sfx(snd.ok)
		end
	elseif state==st_lvl_sel then
		if btnp(0) then
			lvl=lvl-1
			if(lvl<=0)lvl=#levels
			sfx(snd.cancel)
		elseif btnp(1) then
			lvl+=1
			if(lvl>#levels)lvl=1
			sfx(snd.ok)
		elseif btnp(5) then
			set_state(st_gameplay)
			sfx(snd.ok)
		elseif btnp(4) then
			set_state(st_title)
			sfx(snd.cancel)
		end
	elseif state==st_lvl_comp then
		tfin+=1/14
		if tick%60==0 and is_new_best() then
			x,y=rnd(128),rnd(128)
			for i=0,5 do
				add(hud_objs,
					new_fx_kill_stars(x,y))
			end
			sfx(snd["bang"..flr(rnd(2))])
		end
		if (lvl==#levels and tfin>=16)
			or (lvl!=#levels and btnp(5)) then
			if lvl>=#levels then
				set_state(st_title)
			else
				lvl+=1
				set_state(st_gameplay)
				sfx(snd.ok)
			end			
		end
	elseif state==st_gameplay then
		lvl_tick+=1
		tick_since_rewind+=1
		restored=false
		if btnp(4) and #hist>=2 then
			restored=true
			--skip current pos
			del(hist,hist[#hist])
			objs={}
			for o in all(hist[#hist].objs) do
				add(objs,restore_copy(o))
			end
			restore_mdata(hist[#hist].mdata)
			--will get re-added this update
			del(hist,hist[#hist])
			tick_since_rewind=0
			sfx(snd.rewind)
		end
		--do this after restoring
		--so that we resave this frame
		save_level_state()
		players=find_players()
		if (btnp(5) and multi)
			or restored then
			for o in all(players) do
				if o.is_player then
					if not restored then
						o.is_cur=not o.is_cur
					end
					if o.is_cur then
						cam.tar=o
						if not restored then
							add(objs,
								new_fx_char_switch(o))
							sfx(snd.switch_char)
							if lvl!=#levels then
								if last_pat>=mus.p2 then
									music(last_pat-17)
								else
									music(last_pat+17)
								end
							end
						end
					end
				end
			end
		end
		lvl_com=true
		all_in_door=true
		for p in all(players) do
			all_in_door=all_in_door and p.in_door
		end
		for v in all(objs) do
			if v.must_kill==true
				or (v.is_door==true and not all_in_door) then
				lvl_com=false
				break
			end
		end
		if lvl_com then
			set_state(st_lvl_comp)
		end
	end
	request_save_count=0
	for obj in all(objs) do
		if obj.update!=nil then
			obj:update()
		end
	end
	for obj in all(hud_objs) do
		if obj.update!=nil then
			obj:update()
		end
	end
	if cam then
		cam:update()
	end

	--do all players want to save?
	players=find_players()
	if #players>0
			and request_save_count>0 then
		store_level_save()
	end
	t=get_cur_pattern()
	if t!=-1 then
		last_pat=t
	end
end
function _draw()
	cls(5)
	if lvl==2 or lvl==#levels then
		cs={[2]={0,1},[#levels]={12,7}}
		c=cs[lvl]
		pal(5,c[1])
		cls(c[1])
		d_c=function(x,y)
			circfill(x+4,y+4,4,6)
			circfill(x-4,y+2,5,6)
			circfill(x,y,6,7)
			circfill(x+6,y+2,6,7)
		end
		d_w=function(y,l,to)
			nx=128-(((tick*(l/64))+to)%(128+l))
			line(nx,y,nx+l,y,c[2])
		end
		d_c(32-lvl_tick*0.02,32)
		d_c(96-lvl_tick*0.03,64)
		d_c(128-lvl_tick*0.04,20)
		d_w(32,32,10)
		d_w(64,80,32)
		d_w(72,16,64)
		if lvl==#levels and
			state!=st_lvl_comp then
			str={"the end","art:"," nebelstern","audio:"," @gruber_music","code:"," @matthughson"}
			draw_scroll_text(str,120)
		end
	end
	if cam then
		camera(cam:cam_pos())
		map(0,0,0,0,128,128)
	else
		camera(0,0)
	end
	for v in all(objs) do
		v:draw()
	end

	--letter box for small level
	min_x,max_x,min_y,max_y=get_level_bounds()
	rectfill(min_x,min_y-64,min_x-64,max_y+64,0)
	rectfill(max_x,min_y-64,max_x+64,max_y+64,0)
	rectfill(min_x-64,min_y,max_x+64,min_y-64,0)
	rectfill(min_x-64,max_y,max_x+64,max_y+64,0)
	--------------
	--hud
	--------------
	camera(0,0)
	for obj in all(hud_objs) do
		obj:draw()
	end
	if state==st_intro then
		cls(8)
		d=120
		intro={"help...","please help me...","i am a prisoner","in the castle.","the others...     they...","...","only i remain.","","please help me...",}
		draw_scroll_text(intro,d)
	elseif state==st_title then
		--assumes title gfx loaded
		spr(0,0,0,128,128)
		fy=easeoutelastic(
					min(tick-40,60),
					128,-118,
					60)
		if tick<40 then
			fy=-118
		end
		rectfill(0,33-fy,127,33+fy,0)
		fy=easeoutelastic(
					min(tick-40,60),
					128,-118,
					60)
		if tick<40 then
			fy=-118
		end
		rectfill(0,32-fy,127,32+fy,8)
		fx=easeoutquint(
					min(tick,60),
					-64,128,
					60)
		printc("witch n' wiz",fx,32,
			7,0,0)
		if tick%120>60 then
			if tick%120==61 then
				sfx(snd.beep)
			end
			printc("press ❎",128-fx,96,
				7,0,1)
		end
	elseif state==st_lvl_sel then
		xd=levels[lvl].max.x-levels[lvl].min.x
		xd+=1--extra tile
		xd*=8--tile->px
		max_swing=(xd+(32))*0.5
		lerp=(sin(tick*0.001)+1)*0.5
		map(
			levels[lvl].min.x,
			levels[lvl].min.y,
			16-((lerp)*(max_swing)),
			0,
			128,128)
		fx=easeoutelastic(
					min(tick-30,30),
					0,1,
					30)
		l=40-(24*fx)
		r=40+(24*fx)
		rectfill(0,0,l,127,0)
		rectfill(r,0,127,127,0)
		for i=0,127,16 do
			rectfill(l,i,l+8,i+8,0)
			rectfill(r-8,i+8,r,i+16,0)
		end
		fy=easeoutelastic(
					min(tick,60),
					33,31,
					60)
		h=easeoutquint(
					min(tick,60),
					10,5,
					60)
		rectfill(0,fy-h+1,127,fy+h+1,0)
		rectfill(0,fy-h,127,fy+h,8)
		fx=easeoutquint(
					min(tick,60),
					-64,128,
					60)
		printc("witch n' wiz",128+fx,32,
			7,0,0)
		printc("select level",fx,60,
			7,0,0)
		printc("⬅️ "..lvl.." ➡️",128-fx,68,
			10,0,2)
		rectfill(0,fx+32-4,127,fx+32+4,8)
		str="best: "..calc_time(dget(lvl))
		printc(str,64,fx+32,
			7,0,0)
	elseif state==st_gameplay then
		draw_time()
		fy=easeoutquint(
					min(tick,60),
					130,-10,
					60)
		if multi then
		c=btn(5) and 10 or 7
		cb=btn(5) and 9 or 0
		str="❎ switch"
			printo(str,
				128-(#str*4+3)-2,fy,
				c,cb)
		end
		c=btn(4) and 10 or 7
		cb=btn(4) and 9 or 0
		str="🅾️ undo"
		printo(str,
			2,fy,
			c,cb)
	elseif state==st_lvl_comp then
		fy=easeoutelastic(
					min(tick,60),
					0,54,
					60)
		if lvl!=#levels then
		draw_time()
		rectfill(0,fy,127,127-fy,8)
		fx=easeoutquint(
					min(tick,60),
					-64,128,
					60)
		printc("level complete!",fx,60,
			7,0,0)
		printc("press ❎",128-fx,68,
			7,0,1)
		rectfill(0,fx+32-4,127,fx+32+4,8)
		if is_new_best() then
			c={10,9,7}
			str="new best: "..calc_time(lvl_tick)
			printc(str,64,fx+32,
			c[(flr(tick*0.5)%#c)+1],0,0)
		else
			str="time: "..calc_time(lvl_tick)
			printc(str,64,fx+32,
			7,0,0)
		end
		else
			rectfill(0,0,127,fy*2.5,8)
			printc("thanks for playing!",64,fy,7,0,0)
		end
	end
	if tick_since_rewind<10 then
		min_y=(tick%96)
		max_y=min_y+32
		for y=min_y,max_y do
			d=sin(
				((y*cos(tick*0.1))
				+tick*2)*0.01)
				*128
			for x=abs(d),0,-1 do
				x_samp=x-cos(tick*0.1)
				pset(x,y,pget(x_samp,y))
			end
		end
	end
	if lvl==2 or lvl==#levels then
		pal(5,5)
	end
end
title=
"f51d151d151d151d151d151d151d151d15fdfd7d111e1d1e1d1e1d1e1d1e1d1e1dfefefe2ee51d151d151d151d151d151d151d151d15fdfd3d151d25211d1e1d1e1d1e1d1e1d1e1dfefefe3ed51d151d151d151d151d151d151d151d15fdfd9d111e1d1e1d1e1d1e1d1e1dfefe5e678ec51d151d151d151d151d151d151d15fdfdcd111d1e1d1e1d1e1d1e1dfefe5e175d178eb51d151d151d151d151d151d151d15fdfddd111e1d1e1d1e1d1e1dfefe5e173d379ea51d151d151d151d151d151d151d15fdfded111d1e1d1e1d1e1dfefe6e173d379e951d151d151d151d151d151d151d15fdfdfd151e1d1e1d1e1d1e1dfefe6e172d162d178e851d151d151d151d151d151d151d15fdfdfd1d111d1e1d1e1d1e1dfefe8e27262d177e751d151d151d151d151d151d151d15fdfdfd2d111e1d1e1d1e1dfefe7e171d462d177e651d151d151d151d151d151d151d15fdfdfd3d151d1e1d1e1dfefe5e371d463d177e551d151d151d151d151d151d151d15fdfdfd4d111e1d1e1dfefe3e372d251d261d25178e451d151d151d151d151d151d15fdfdfd7d151d1e1dfefe2e27151d963d276e351d151d151d151d151d151d15fdfdfd8d151e1dfefe2e171df61d15175e251d151d151d151d151d151d15fdfdfd9d151d1e1dfefe17f6461d174e151d151d151d151d151d151d15fdfdfdad151e1dfefe17f6661d173e1d151d151d151d151d151d15fdfdfdbd151dfefe17f696172e151d151d151d151d151d15fdfdfdddfefe171df6961d171e1d151d151d151d151d15fdfdfddd15fefe17f6b61517151d151d151d151d15fdfdfdfdfeee171df6b61d171d151d151d15fdfdfd6d1511257d15feee17f6c61d17151d151d15fdfdfdbd1521153d11feee17f6c61d151d151d15fdfdfddd112d2521151d1e1dfe9e171d362df6761d251d15fdfdfded115d11fede171d362df6761d151d15fdfdfdfd155d15fede171d162d2a2da62d861d25fdfdfdfd1d155d11fede1715162d2a2da62d8625fdfdfdfd2d155d15fede17151d262da62d2a2d561d25fdfdfdfd8d15fede1725262da62d2a2d5635fdfdfdfd9dfeee17151df62d6645fdfdfdfd8d15feee17251d3627962d461d4517fdfdfdfd8d15fefe17351d1687761d6517fdfdfdfd9dfefe17652d57462d7517fdfdf"..
"dfdadfefe1d17358d178d5517fdfdfdfdadfefe2d17258d168d5517fdfdfdfd9d15fefe3d17257d167d6517fdfdfdfdadfefe4d1735bd454d1517fdfdfdfd9dfefe5d27b53d254d1517fdfdfdfd9dfefe156d176597153d1517fdfdfdfd9dfefe8d1755178d273517fdfdfdfd9dfefe158d273517ad37fdfdfdfdadfeee1d11ad37fdfdfdfdfd9dfede1d1e11fdfdfdfdfdfd7dfece1d1e1d15fdfdfdfdfdfd7dfebe1d1e1d1efdfdfdfdfdfd8dfeae1d1e1d1e1d15fdfdfd5d464726fdfd7dfe9e1d1e1d1e1d1efdfdfd4d1647265726fdfd5dfe8e1d1e1d1e1d1efdfdfd4d1677166716fdfd4dfe7e1d1e1d1e1d1e1d1efdfdfd3d271667265716fdfd3dfe6e1d1e1d1e1d1e1d1e1d15fdfdfd1d16271667365716fdfd2dfe5e1d1e1d1e1d1e1d1e151e15fdfdfd1d37266716171657167d87fd1dfe4e1d1e1d1e1d1e151e151e15fdfdfd2d37266716271657166d173a57fd3e37ce1d1e1d1e1d1e151e151e151e15fdfdfd1d271629166716272647166d173a371917ed3731279e1d1e1d1e1d1e151e151e151e15fdfdfd2d161716192f671637568d173a173917bd2781177e1d1e1d1e151e151e151e151e151efded1efd3d17161e2f1667163736ad172a59178d27b1175e1d1e1d1e151e151e151e151e151e15fded3efd1d2614221f1667163726bd17191811575d27e1173e1d1e1d1e151e151e151e151e151e151efded5efd161f12142f863716bd1740176d27f121171e1d1e1d1e151e151e151e151e1547fded7edd191f12142f192e2d76bd1740175d17f151171e1d1e151e151e151e151e15173117fded161d151d1531cd8f1e1d86bd172031172d27f16114171e151e151e151e151e274117fded7510cd8f1966fd17104127f161142914171e151e151e376117fded1a1955106d323d146f1966fd1d17104120711d481d6114195a171e379117fded12152935101d14191f191244221012192f291446fd4d17c1191a1948141024198a1417b11715fded451925111d244f1d54227012fd5d17b1193a1948249a1924a11725fded75112d5f1d642250121412fd5d17911d5a58128a499117352d37fd9d3a192a252d293f942220122422fd5d17711018193a1958146a392a198117452d172227fd7d20121519551d391d12f41412fd5d1751301418191a19"..
"784a393a19147117552d17321017fd6d351945114e2012f41412fd6d177014481a193428396a198117652d1732101217fd5d251955114e10225422842d18fd6d174027582954196a198127753d175217fd4d251955104e1264121012444d2912fd7d774864125a198127953d175217fd4d151965104e101224222d10125d191a1932fd7d473148643914912017a52d27103217fd5d1975101d158d152218193a192d4412fd4d277110385410a110321017a51d17223017fd6d197511ae2442301274fd1d27b11d28241d711d3e623765374227fd7d151965119e5442a4ed17f1611032194f2e42172217152715177217fd8d1519759ef44412cd1710f11120724f2011221415202217221742103217fd8d2519658e12f43422cd174011103147308211201e2f211f22191f41922017fd9d351955117e12f43422ddb7321082111e213f211f1e4f4132203227fdad451945117d222d64122012442d10fd7d174210721e111f213f2d1f194f4130173017fdcd1a19251a45118e126d14122e12245d10fd6d2732215214191f1e1f2d6f194f5110171537fddd1012192a1935109e145d144e24fdbd17221012512014296f283f2e811745fded2530222510be22109e10223efd3d1732205120142e5f2e182f1910a11735fded9510ae429d325efd2742177110141e5f3e1f1920a11735fded9510159e2012bd207ecd172210322720611024193e291430b11725fded60211011151d9eedae9d173230171d174061c0a11725fded2e2d151d153d152d351d15fd9d151d257d2742272d17c1401930c11725fded3e1d152d152d152d111dfefe4e3d17221032172d17a13051193120911725fded4e153d151d152d152dfefe5e173230172d17b15031192130911725fded5e3d352d153dfefe4e1752172d17c1901950711735fded6e2d152d151d155dfefe2e1752172d17c1901a5061101735fded7e1d153d254d151dfefe1e174210171d17d190196041101745fded8e5d154d152dfefe1e1730271e17d1a019802755fded9e4d253d153dfefe17202237d1a01a602775fdfd6d254d151d152d155dfede176210c1b01a601785fdfd7d154d152d151d116dfece176210c1b019601785fdfd7d154d152d25116d451d251d15fd3d172210221710d1b01950111775fdfd7d114d1"..
"52d111d156d151dfeae172210271e1710a11031901a50111775fdfd7d114d152d152d254d153dfe8e1722173e171da12051601a30311775fdfd3d151d15214d152d154d153d114dfe7e375e171d814091101a1051101765fdfd7d154d158d152d155dfeee172f1e5170811951201765fdfdcd152d155d251d154d151dfece1714191e2f1ed0511941401765fdfd1db78d151d254d153dfeae17342ff05019803725fdfd27159015276d152d154d154dfe9e4724f05019a01735fddd1715d015475d11153d155dfece17f0601aa01735fddd15f0301527152d111d152d116dfeae171df0601aa01725fd8d254df06015172d152d151d118dfe8e17f0701aa01735fd9d252df07015171d153d259dfe6e171df0701aa0172511fdbd25f0801517155d159dfe5e17f0801a90151735fdcd11d03d8017156d157d151dfe4e17f0801a801d173511fdcd15503d403d9015177d156d153dfe2e17f0801970272d2511fdcd15603df010178d155d154dfe1e17f080196011173e2d15ed25bd15f0a015177d11154d154d451d154d353d171df0c041171d35fd2d259d11f030211021102115176d111d153d154d111dfe171df0701d4731176efd2d257d1510fe2e91176d152d152d114d113dee171df0201d473e1741177efd2d255d1110fe3e211e211e211e6d113d151d114d154dee271dc01d378e1731179efd1d1511153d1110fede5d154d254d155dfe2731601d27be17211017beed112d251d15101dfede4d156d153d156dfe173177de172017eecd154d25101dfeee3d157d152d158dde173117fe4e37fe2ead116d102dfeeebd151d159dce173117fefebe8d116d102dfefe1d159d25adbe171031176efdfe6e6d116d103dfefe1ead259d15be173117fd6dfe8e4d156d103dfefe2e9d151d158d152d8e1d173017fd4dfece2d156d104dfefe2e8d112d157d153d6e3d47fd1dfefe2e7d10153dfefe3e7d153d156d154d5efd3dfefe9e5d105dfefe3e6d114d254d115d6ebdfefefe1e3d10154dfefe4e5d115d253d157dfefefefe3e1d10155dfefe5e3d155d111d152d118dfefefefe3e10115dfefe6e2d155d112d151d119dfefefefe2e10156dfefe6e7d153d25adfefefefe1e10116dfefe7e155d154d15cdfefefeee1011156dfefe6e6d155d15cd351d15fdfdfd"
function hex2num(str)
	return ("0x"..str)+0
end
function load_title_gfx()
	index=0
	for i=1,#title,2 do
		count=hex2num(sub(title,i,i))
		col=hex2num(sub(title,i+1,i+1))
		for j=1,count do
		sset((index)%128,flr((index)/128),col)
		index+=1
		end
	end
end
function clear_title_gfx()
	reload(0x0,0x0,0x2000)
end
if(_update60)_update=function()_update60()_update_buttons()_update60()end