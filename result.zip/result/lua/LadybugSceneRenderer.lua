p={}
depth={}
pos={}
mats={}

allmats={}
allmats["plant"]={10,11,3,1}
allmats["bgtree"]={11,3,2,1}
allmats["shroom"]={15,9,4,2,1}
allmats["darkshroom"]={4,2,1}
allmats["ground"]={15,9,4,2,1}
allmats["red"]={7,8,8,2}
allmats["darkred"]={14,2,1}
allmats["black"]={1,0,0}
allmats["white"]={7,7,6}

groundy=-2.5
horizony=64

lx=1
ly=.7
lz=-1

function getindex(x,y)
	if (x%128!=x or y%128!=y) return nil

	x=flr(x)
	y=flr(y)

	return x*128+y
end

function sampledir(i,count)
	local y=(i-1)/(count-1)
	local r=sqrt(1-y*y)
	local a=i*.618
	local x=cos(a)*r
	local z=sin(a)*r
	return x,y,z
end

function rnddir(ground)
	local a=rnd()
	local y=rnd(2)-1
	local r=sqrt(1-y*y)
	local x=cos(a)*r
	local z=sin(a)*r
	if ground then
		y=abs(y)
	else
		z=-abs(z)
	end
	return x,y,z
end

function worldtoscr(x,y,z)
	local persp=60/z
	
	local u=64+x*persp
	local v=horizony-y*persp
	return u,v,persp
end

function scrtoworld(u,v)
	local y=groundy
	local persp=(horizony-v)/y
	
	local x=(u-64)/persp
	local z=60/persp
	return x,y,z,persp
end

function rotate(x,y,a)
	local c=cos(a)
	local s=sin(a)
	return x*c-y*s,x*s+y*c
end

function rotate3d(x,y,z,rx,ry,rz)
	x,y=rotate(x,y,rz)
	x,z=rotate(x,z,ry)
	y,z=rotate(y,z,rx)
	return x,y,z
end

function nearestdist(x,z,points)
	local output=32000
	for i=1,#points,2 do
		local dx=x-points[i]
		local dz=z-points[i+1]
		local dist=dx*dx+dz*dz
		if dist<output then
			output=dist
		end
	end
	return sqrt(output)
end

dirsx={1,-1,0,0}
dirsy={0,0,1,-1}

function outline(u,v)
	local index=getindex(u,v)
	local dist=depth[index]

	for i=1,#dirsx do
		local u2=u+dirsx[i]
		local v2=v+dirsy[i]
		local index2=getindex(u2,v2)
		if index2 then
			local dist2=depth[index2]
			if dist2 then
				if dist2>dist*1.1 then
					return true
				end
			else
				return true
			end
		end
	end
	
	return false
end

function ssao(point,dist)
	local x=point[1]
	local y=point[2]
	local z=point[3]
	local hits=0
	local totalweight=0
	local raycount=20
	local raysamples=4
	local _,__,persp=worldtoscr(x,y,z)
	local raylen=10/persp
	local step=1/raysamples*raylen
	for i=1,raycount do
		local dx,dy,dz=sampledir(i,raycount)
		local rayhits=0
		local weight=1
		for d=step,raylen,step do
			local u,v=worldtoscr(x+dx*d,y+dy*d,z+dz*d)
			local index=getindex(u,v)
			if index then
				local otherdepth=depth[index]
				if otherdepth and otherdepth<z+dz*d then
					//rayhits+=1/raysamples
					rayhits=1
					break
				end
			else
				break
			end
		end
		hits+=rayhits*weight
		totalweight+=weight
	end
	
	return 1-(hits/totalweight)
end

function sunlight(u,v)
	local pself=pos[getindex(u,v)]
	local px=pself[1]
	local py=pself[2]
	local pz=pself[3]
	local i1=getindex(u+1,v)
	local i2=getindex(u-1,v)
	local i3=getindex(u,v+1)
	local i4=getindex(u,v-1)
	local x1,y1,z1,x2,y2,z2,x3,y3,z3,z4,y4,z4
		if i1 and pos[i1] then
		local p=pos[i1]
		x1=p[1]
		y1=p[2]
		z1=p[3]
	else
		x1=px
		y1=py
		z1=pz+1
	end

	if i2 and pos[i2] then
		local p=pos[i2]
		x2=p[1]
		y2=p[2]
		z2=p[3]
	else
		x2=px
		y2=py
		z2=pz+1
	end

	if i3 and pos[i3] then
		local p=pos[i3]
		x3=p[1]
		y3=p[2]
		z3=p[3]
	else
		x3=px
		y3=py
		z3=pz+1
	end

	if i4 and pos[i4] then
		local p=pos[i4]
		x4=p[1]
		y4=p[2]
		z4=p[3]
	else
		x4=px
		y4=py
		z4=pz+1
	end
	
	local tx=x1-x2
	local ty=y1-y2
	local tz=z1-z2
	local bx=x3-x4
	local by=y3-y4
	local bz=z3-z4
	
	tx,ty,tz=normalize(tx,ty,tz)
	bx,by,bz=normalize(bx,by,bz)
	
	local nx,ny,nz=cross(bx,by,bz,tx,ty,tz)

	if nz>0 then
		nx,ny,nz=-nx,-ny,-nz
	end

	local dot=nx*lx+ny*ly+nz*lz
	
	local lambert=dot*.5+.5
	
	local vx,vy,vz=-px,-py,-pz
	vx,vy,vz=normalize(vx,vy,vz)
	
	local refx,refy,refz=reflect(-lx,-ly,-lz,nx,ny,nz)
	
	local spec=mid(refx*vx+refy*vy+refz*vz,0,1)
	spec*=spec*spec
	
	local shadow=getshadow(px,py,pz)
	
	return (lambert+spec)*shadow
	//return mid(spec,0,1)
end

function getshadow(x,y,z)
	local u,v,persp=worldtoscr(x,y,z)
	local step=1/persp
	
	local index=getindex(u,v)
	while index do
		local depthval=depth[index]
		if depthval and depthval<z and depthval>z-.2 then
			return 0.5
		end
		x+=lx*step
		y+=ly*step
		z+=lz*step
		u,v,persp=worldtoscr(x,y,z)
		step=1/persp
		index=getindex(u,v)
	end
	
	return 1
end

function normalize(x,y,z)
	local dist=sqrt(x*x+y*y+z*z)
	return x/dist,
	       y/dist,
	       z/dist
end

function reflect(dx,dy,dz,nx,ny,nz)
	local dot=dx*nx+dy*ny+dz*nz
	dx-=nx*dot*2
	dy-=ny*dot*2
	dz-=nz*dot*2
	return dx,dy,dz
end

function cross(a1,a2,a3,b1,b2,b3)
	local x=a2*b3-a3*b2
	local y=a3*b1-a1*b3
	local z=a1*b2-a2*b1
	return x,y,z
end

function drawpoint(x,y,z,mat,u,v)
	if (z<0) return
	
	if not u then
		u,v=worldtoscr(x,y,z)
	end
	
	index=getindex(u,v)
	if index then
	 dist=z
	 if not depth[index] or dist<depth[index] then
			//col=sqrt(dist/50)*15
			local i2=flr(sqrt(dist*3)+rnd())%#allmats[mat]+1
			col=allmats[mat][i2]
			pset(u,v,col)
			depth[index]=dist
			mats[index]=mat
			if pos[index] then
				pos[index][1]=x
				pos[index][2]=y
				pos[index][3]=z
			else
				pos[index]={x,y,z}
			end
		end
	end
end

function drawleaf(lx,ly,lz,count,jit,mat)
	local aoffset=rnd()
	for j=1,count do
		local ry=j/count
		local ra=j*.618+aoffset
		local r=sqrt(1-ry*ry)
		local rx=cos(ra)*r
		local rz=-abs(sin(ra)*r)
		x=lx+rx*jit/2
		y=ly+ry*jit/2
		z=lz+rz*jit/2
		
		drawpoint(x,y,z,mat)
	end
end

function makeplant(tx,tz)
	local height=rnd()+1+tz/8
	local density=mid(1-tz/5,.1,1)
	for i=0,40*density do
		local t=i/40/density
		local l=(.3+tz/16)*(1-t*.5)
		local a=i*.618+.1
		local dx=cos(a)
		local dz=sin(a)
		for j=0,l,.015 do
			local t2=j/l
			local x=dx*j+tx
			local y=groundy+t*height+j
			local z=dz*j+tz
			drawleaf(x,y,z,20*density,.04,"plant")
		end
	end
end

function makebgtree(tx,tz)
	local height=rnd(30)+20
	for i=0,10 do
		local t=i/10
		local l=12*(1-t*.5)
		local a=i*.618+.1
		local dx=cos(a)
		local dz=sin(a)
		for j=0,l,1 do
			local t2=j/l
			local x=dx*j+tx
			local y=groundy+t*height+j
			local z=dz*j+tz
			drawleaf(x,y,z,80,5,"bgtree")
		end
	end
end

function makegrass(px,pz)
	local height=rnd(1.5)+1
	local density=mid(1-pz/7,.1,1)
	local dx=rnd(2)-1
	local dz=rnd(2)-1
	for i=0,180*density do
		local t=i/180/density
		local w=(1-t*t)*.1
	
		local x=px+t*t*dx
		local y=groundy+t*height
		local z=pz+t*t*dz
		drawleaf(x,y,z,10*density,w,"plant")
	end
end

function makemushroom(mx,mz,tilt1,tilt2,density)
	local r=.35
	local h=2.6
	local h2=1.5
	local slant=.2
	
	
	local spots={}
	for i=1,20 do
		local sx=rnd(2)-1
		local sz=-sqrt(1-sx*sx)
		local r=sqrt(rnd())*.8
		add(spots,sx*r)
		add(spots,sz*r)
	end
	
	for i=0,40 do
		local t=i/40
		
		local step=.02
		for a=step,1,step do
			local r2=r+sin(a*16)*.05
			local x=mx+cos(a)*r2+slant*t
			local y=groundy+t*h
			local z=mz+sin(a)*r2
			drawleaf(x,y,z,10*density,.05,"shroom")
		end
	end
	
	for i=0,80 do
		local t=i/80
		local r2=sqrt(1-t*t)*h2
		
		local step=.006
		for a=step,1,step do
			local r3=r2*(.97+sin(a*100)*.03)
			local x=cos(a)*r3
			local y=t*h2
			local z=sin(a)*r3
			local mat="shroom"
			if (y<.1) then
				mat="darkshroom"
			end
			if nearestdist(x/h2,z/h2,spots)<.1 then
				mat="darkshroom"
			end
			y+=sin(a*8)*.05*(1-y)
			y,z=rotate(y,z,tilt2)
			x,y=rotate(x,y,tilt1)
			x+=mx+slant
			y+=groundy+h
			z+=mz
			drawleaf(x,y,z,20*density,.1,mat)
		end
	end
end

function makeladybug(bx,by,bz,rx,ry,rz,scale)
	local size=.6*scale
	local headsize=.25*scale
	local headsize2=.12*scale
	local zscale=1.2
	for i=0,1,.01 do
		r=sqrt(1-i*i)
		local step=r/200
		for a=step,1,step do
			local x=cos(a)*r
			local y=i
			local z=sin(a)*r
			local mat="red"
			z*=zscale
			
			local u=((x+z)*1.1+.5)%1
			local v=((x-z)*1.1+.5)%1
			if r<.98 and (u-.5)^2+(v-.5)^2<.12 then
				mat="black"
			end
			if abs(x)<size*.1 then
				mat="darkred"
			end
			
			x,y,z=rotate3d(x,y,z,rx,ry,rz)
			
			x=x*size+bx
			y=y*size+by
			z=z*size+bz
			drawpoint(x,y,z,mat)
		end
	end
	for i=0,1,.01 do
		r=sqrt(1-i*i)
		local step=r/200
		for a=step,1,step do
			local x=cos(a)*r*headsize*1.1
			local y=i*headsize
			local z=sin(a)*r*headsize-size*zscale+headsize*.5
			local mat="black"
			if y<headsize*.5 then
				mat="white"
			end
			x,y,z=rotate3d(x,y,z,rx,ry,rz)
			x+=bx
			y+=by
			z+=bz
			
			drawpoint(x,y,z,mat)
		end
	end
	for i=0,1,.01 do
		r=sqrt(1-i*i)
		local step=r/200
		for a=step,1,step do
			local x=cos(a)*r*headsize2
			local y=i*headsize2
			local z=sin(a)*r*headsize2-size*zscale+headsize*.5-headsize+headsize2*.5
			x,y,z=rotate3d(x,y,z,rx,ry,rz)
			x+=bx
			y+=by
			z+=bz
			
			drawpoint(x,y,z,"black")
		end
	end
	
	local l=.4*scale
	for i=-1,1,2 do
		for j=.15,.25,.05 do
			local dx=cos(.25+j*i)
			local dz=sin(.25+j*i)
			local sx=dx*size
			local sz=dz*size*zscale
			for k=0,50 do
				local t=k/50
				local x=sx+dx*t*l*.7
				local z=sz+dz*t*l*.7
				local y=-t*l
				if (t>.5) then
					y=-.5*l
				end
				
				x,y,z=rotate3d(x,y,z,rx,ry,rz)
				x+=bx
				y+=by
				z+=bz
				drawleaf(x,y,z,5,.01,"black")
			end
		end
	end
end



cls(1)

for u=0,127 do
	for v=horizony+1,127 do
		index=getindex(u,v)
		x,y,z=scrtoworld(u,v)
		drawpoint(x,y,z,"ground",u,v)
	end
end

srand(6)
nextseed=rnd(-1)
for i=-50,50,10 do
	makebgtree(i+rnd(10)-5,40+rnd(10)-5)
	srand(nextseed)
	nextseed=rnd(-1)
end

srand(1)
makeladybug(0.2,0.7,1.7,
            .15,0.07,0.08,
            .5)
srand(1)
makemushroom(-.8,3,-.03,.035,1)
srand(2)
makemushroom(4.5,7,.01,-.01,.2)


srand(0)
nextseed=rnd(-1)
for j=.5,12 do
	
	for i=-1-j,1+j,1 do
		makeplant(i+rnd()-.5,
		          j+rnd()-.5)
		for k=1,3 do
			makegrass(i+rnd()-.5,
			          j+rnd()-.5)
		end
		srand(nextseed)
		nextseed=rnd(-1)
	end
end

lx,ly,lz=normalize(lx,ly,lz)

for u=0,127 do
	for v=0,127 do
		index=getindex(u,v)
		dist=depth[index]
		if dist then
			light=sunlight(u,v)
			light*=.5+.5*ssao(pos[index],dist)
			light=mid(light,0,1)
			mat=allmats[mats[index]]
			pindex=flr(1+(1-light)*(#mat-.01))
			col=mat[pindex]
			//if outline(u,v) then
			//	col=mat[#mat]
			//end
			
			pset(u,v,col)
		end
	end
end

function _update()
end