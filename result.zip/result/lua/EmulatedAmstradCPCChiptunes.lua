--amstradchips1
--carlc27843
function mkzt(n) local t={}for i=1,n do add(t,0) end return t end

ayvols={
 0,
 0.01,
 0x.03b3,
 0x.0564,
 0.0307,
 0x.0ba9,
 0.0645,
 0x.1b7c,
 0x.2068,
 0x.347a,
 0.2922,
 0x.5f72,
 0x.7e16,
 0x.a2a5,
 0x.ce3b,
 1
}

local adjbuf,adjpos,adjsum
function ayupdate(ay,wts)
 local aynoise=ay.noise
 aynoise.counter+=wts
 aynoise.bit^^=(aynoise.counter/aynoise.period)&1
 aynoise.counter%=aynoise.period

 local r=aynoise.rng
 r^^=((r&0x.0001)^^(r>>3&0x.0001))<<17
 r>>=1
 aynoise.rng=r
 local nb=r&aynoise.bit

 local vadj=adjsum/(2*256)
  
 local s=0
 for i=1,3 do
  local chn=ay.chns[i]
  if chn.period==0 then
   chn.bit=1
   chn.counter=0
  else
   chn.counter+=wts
   chn.bit^^=(chn.counter/chn.period)&1
   chn.counter%=chn.period
  end

  -- mix channel volumes
  local cnd=chn.noise_disable
  local v=((chn.bit)&(nb|cnd)==0) and chn.volume or 0
  s+=v

  -- oscilloscope view
  local obit=chn.obit
  chn.obit=chn.bit&(aynoise.bit|cnd)
  if(obit!=chn.obit)chn.lz=chn.osci
  local col=cnd!=0 and chn.col or 2
  local oi=(chn.osci&1023)+1
  chn.oscv[oi]=((v-vadj)&0xffff.ff)|(col>>16)
  chn.oscz[oi]=chn.lz*2+chn.bit
  chn.osci+=1
 end
 s=s*ay.mvol

 -- move offcenter signal to zero-line
 adjsum+=s-adjbuf[adjpos]
 adjbuf[adjpos]=s
 adjpos=(adjpos&255)+1
 s-=adjsum>>8
 return mid(s,-1,1)
end

function ayvol(v)
 ay.mvol=v*2/3
end

function ayinit()
 local newchn=function() 
  return {
   period=0,counter=0,volume=0,bit=0,noise_disable=1,
   osci=0,oscv=mkzt(1024),oscz=mkzt(1024),lz=0,col=0,obit=0} 
 end
 ay={noise={period=1,counter=0,bit=0,rng=1>>15}}
 ay.chns={newchn(),newchn(),newchn()}
 ayvol(1)
 adjbuf=mkzt(256)
 adjpos=1
 adjsum=0
end
local wtss={22.6778,40.2179}
local wtupds={488.2812,865.9409}

function sndlaunch(chni,subi)
 local cmda=%(dr.subs+2*subi)
 if @cmda==241 then
  cmda+=1
  chni=@cmda
  cmda+=1
 end
 local pri=10
 if @cmda==240 then
  cmda+=1
  pri=@cmda
  cmda+=1
 end
 if chni>3 then
  if dr.chns[1].pri==0 then chni=1
  elseif dr.chns[2].pri==0 then chni=2
  else chni=3
  end
 end
 local chn=dr.chns[chni]
 if(pri<chn.pri)return
 chn.pri=pri&127
 chn.a=cmda
 chn.reta=cmda
 chn.cmda=chn.reta
 chn.d=1
 chn.v=0
 chn.pd=0
 chn.pt=0
 chn.tt=0
end

function envreset(env)
 env.e=%(dr.envs+2*env.q)
 env.a=env.e
 env.d=0
 env.c=0
end

function envstep(env)
 env.d+=1
 if(env.d!=@env.a)return 0
 local v=@(env.a+1)-128
 env.d=0
 env.c+=1
 if env.c==@(env.a+2) then
  env.c=0
  env.a+=3
  if(@env.a==255)env.a=env.e
 end
 return v
end

function playnote(chn,p,d)
 chn.p=p
 chn.d=d
 chn.sd=d
 chn.t=%(dr.pitches+2*p)
 chn.v=0
 envreset(chn.venv)
 envreset(chn.penv)
 if chn.ne!=0 then
  chn.ne=0
  envreset(dr.nenv)
  chn.ay.noise_disable=chn.ond
 else
  chn.ay.noise_disable=1
 end
 chn.ay.col=0
end

local rng2t={
 0,3,5,7,10,7,10,12,15,17,12,15,17,19,22,12,
 15,17,19,22,19,22,24,27,29,31,34,24,27,29,0,0 }

function sndchnstep(chn)
 if(chn.pri==0)return
 chn.d-=1
 local i=20
 while chn.d==0 do
  i-=1 if(i==0)break
  local p,d=peek(chn.a,2)
  chn.a+=2
  if p==0 then
   playnote(chn,p,d)
   break
  elseif p<6 then
   sndlaunch(p,d)
  elseif p<101 then
    playnote(chn,p+chn.pd,d)
    break
  elseif p<128 then
    chn.a-=1
    dr.nt=p-101
    chn.ne=1
  elseif p<229 then
    chn.a-=1
    p&=127
    if(p!=0)p+=chn.pd
    playnote(chn,p,chn.sd)
    break
  elseif p==229 then
   chn.pri=0
   chn.v=0
   chn.t=0
   return
  elseif p==238 then
   dr.rng*=41
   dr.pr=(dr.rng>>8&d)+1
  elseif p==239 then
   dr.rng*=21
   dr.pr=rng2t[(dr.rng>>8&d)+1]
  elseif p==230 then
   playnote(chn,chn.pd+dr.pr,d)
   break
  elseif p==231 then
   dr.nt=d
   chn.ne=1
  elseif p==232 then
   chn.reta=chn.a
   chn.a=%(dr.subs+2*d)
  elseif p==233 then
   chn.pd=d
  elseif p==234 then
   chn.venv.q=d
  elseif p==235 then
   chn.penv.q=d
  elseif p==236 then
   dr.nenv.q=d
  elseif p==237 then
   chn.pt=d
  elseif p==243 then
   dr.h=d
  elseif p==242 then
   chn.a=chn.reta
   chn.reta=chn.cmda
  elseif p==244 then
   chn.a-=1
   chn.p=0
   chn.d=1
   chn.t=0
   break
  elseif p==245 then
   for i=1,3 do
    dr.chns[i].ond=(d>>(2+i))&1
   end
  end
 end
 -- process chn note
 chn.v+=envstep(chn.venv)
 if chn.t!=0 then
  if chn.pt==0 then
   chn.t+=envstep(chn.penv)
  else
   chn.tt^^=1
   chn.t=%(dr.pitches+2*(chn.p+chn.tt*chn.pt))
   chn.ay.col=chn.tt
  end
 end
end

function sndupdate()
 local chn1,chn2,chn3=unpack(dr.chns)
 -- process commands and note
 sndchnstep(chn1)
 sndchnstep(chn2)
 sndchnstep(chn3)
 -- process noise
 local nt=dr.nt+envstep(dr.nenv)&dr.ntmsk
 if nt>=dr.ntlim then
  chn1.ay.noise_disable=1
  chn2.ay.noise_disable=1
  chn3.ay.noise_disable=1
  nt=dr.nt
 end
 dr.nt=nt
 dr.ay.noise.period=nt>0 and nt or 1
 -- process overtone
 local h=dr.h
 if h!=8 then
  local hd=(h&15)-8
  local hm=h\32+1
  if h&16!=0 then
   chn3.t=chn1.t*hm+hd
  elseif chn3.pri==0 then
   local t=chn2.pri!=0 and chn2.t or chn1.t
   if t!=0 then
    chn3.t=t*hm+hd
    chn3.v=chn2.v
   end
  end
 end
 -- set ay regs
 for chn in all(dr.chns) do
  chn.ay.period=max(chn.t,0)
  chn.ay.volume=ayvols[1+(chn.v&15)]*dr.vol
 end
 return dr.wtupd
end

function sndinit(addr,ay)
 local newenv=function()
  local env={q=0}
  envreset(env)
  return env
 end
 local newchn=function(i)
  return {id=i,pri=0,p=0,t=0,v=0,penv=newenv(),venv=newenv(),ne=0,ond=0,ay=ay.chns[i]}
 end
 local hw=@(addr+8)
 dr={ay=ay,
  wts=wtss[hw],
  pitches=addr+9,
  envs=%addr,
  subs=%(addr+2),
  wtupd=wtupds[hw]/(@(addr+4)>>8),
  ntmsk=@(addr+5),
  ntlim=@(addr+6),
  vol=@(addr+7)/255,
  rng=0x28b2,
  nt=0,
  h=8}
 dr.nenv=newenv()
 dr.chns={newchn(1),newchn(2),newchn(3)}
 sndlaunch(1,0)
end
-- px9 https://www.lexaloffle.com/bbs/?tid=34058
function px9_decomp(x0,y0,src,vget,vset)
 local function vlist_val(l, val)
  local v,i=l[1],1
  while v!=val do
   i+=1
   v,l[i]=l[i],v
  end
  l[1]=val
 end
 local cache,cache_bits=0,0
 function getval(bits)
  if cache_bits<16 then
   cache+=%src>>>16-cache_bits
   cache_bits+=16
   src+=2
  end
  local val=cache<<32-bits>>>16-bits
  cache=cache>>>bits
  cache_bits-=bits
  return val
 end
 function gnp(n)
  local bits=0
  repeat
   bits+=1
   local vv=getval(bits)
   n+=vv
  until vv<(1<<bits)-1
  return n
 end
 local w,h_1,eb,el,pr,x,y,splen,predict=
  gnp"1",gnp"0",gnp"1",{},{},0,0,0
 for i=1,gnp"1" do
  add(el,getval(eb))
 end
 for y=y0,y0+h_1 do
  for x=x0,x0+w-1 do
   splen-=1
   if(splen<1) then
    splen,predict=gnp"1",not predict
   end
   local a=y>y0 and vget(x,y-1) or 0
   local l=pr[a]
   if not l then
    l={}
    for e in all(el) do
     add(l,e)
    end
    pr[a]=l
   end
   local v=l[predict and 1 or gnp"2"]
   vlist_val(l, v)
   vlist_val(el, v)
   vset(x,y,v)
  end
 end
 return w,h_1+1,src-cache_bits\8
end

games={{a=1525,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY cHRIS wOOD - GAME BY jUKKA tAPANIMAKI (c64) AND cHRIS wOOD (cpc) - (C) 1988 hewson',dbglc=318,dis=split"13,15,15,2,2,12,11,1,10,10,8,14,2,2,0",l=1408,n='netherworld',pal=split"1,2,3,4,5,6,7,8,9,-15,-13,12,13,-8,-3"},{a=1121,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY sTEVE cROW AND mARK jONES - GAME BY mICHAEL cROUCHER AND dOMINIC rOBINSON - (C) 1987 hewson',dbglc=644,dis=split"11,14,3,10,10,6,12,15,1,9,8,13,2,2,0",l=3584,n='zynaps',pal=split"1,2,3,4,5,6,7,8,-15,-13,11,12,-8,-5,-4"},{a=910,c='COMPOSED BY sTEVE tURNER - ARRANGED BY dAVE rOGERS - GRAPHICS BY aNDREW bRAYBROOK - GAME BY aNDREW bRAYBROOK (c64) AND nEIL lATARCHE (cpc) - (C) 1987 hewson',dbglc=233,dis=split"5,15,9,11,2,6,12,13,1,3,8,10,2,2,0",l=1280,n='uridium',pal=split"1,2,-15,-10,-9,6,7,8,9,-8,-7,12,-4,-1,15"},{a=1419,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY rAFAELLE cECCO - GAME BY rAFAELLE cECCO - (C) 1988 hewson',dbglc=436,dis=split"12,15,1,5,5,11,10,9,14,6,8,13,2,2,0",l=2048,n='cybernoid',pal=split"1,2,3,4,-15,-12,7,8,9,10,-9,12,-8,-7,-4"},{a=1098,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY hUGH bINNS - GAME BY rAFAELLE cECCO - (C) 1988 hewson',dbglc=472,dis=split"12,10,9,14,6,11,15,3,5,5,8,13,2,2,0",l=2048,n='cybernoid2',pal=split"1,2,3,4,-13,-12,7,8,9,10,11,-9,-8,-7,-5"},{a=1108,c='COMPOSED BY jOHN m pHILLIPS - ARRANGED BY dAVE rOGERS - GRAPHICS BY cHRIS wOOD - GAME BY jOHN m pHILLIPS (c64) AND cHRIS wOOD (cpc) - (C) 1988 hewson',dbglc=380,dis=split"12,15,1,5,5,11,14,3,7,7,10,9,13,8,0",l=1472,n='nebulus',pal=split"1,2,3,4,-15,6,-13,-12,9,10,11,12,-7,-5,-4"},{a=1210,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY rORY gREEN - GAME BY cASEY bEE gAMES - (C) 1988 hewson',dbglc=227,dis=split"13,15,15,2,2,11,10,9,14,7,8,12,2,2,0",l=1344,n='marauder',pal=split"1,2,3,4,5,6,-12,8,9,10,-9,-8,13,-7,-3"},{a=1275,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY hUGH bINNS - GAME BY rAFAELLE cECCO - (C) 1989 hewson',dbglc=1019,dis=split"12,15,1,4,4,7,6,13,5,11,10,9,14,8,0",l=2240,n='stormlord',pal=split"1,2,3,-15,5,6,7,-12,9,10,-11,12,-10,-7,-4"},{a=1311,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY mARK wASHBROOK - GAME BY rAFAELLE cECCO - (C) 1990 hewson',dbglc=762,dis=split"15,10,9,9,11,13,14,5,12,1,8,2,2,2,0",l=1984,n='stormlord2',pal=split"1,2,-16,-15,5,6,7,8,9,10,-12,-11,13,-10,-9"},{a=911,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY jOHN cUMMING - GAME BY mICHAEL sENTINELLA (c64) AND mICHAEL cROUCHER (cpc) - (C) 1987 hewson',dbglc=221,dis=split"12,15,6,1,4,11,10,9,14,7,8,13,13,2,2",l=1152,n='anarchy',pal=split"1,2,3,-15,-14,-13,-12,8,9,10,-9,12,-8,-7,-4"},{a=1676,c='COMPOSED BY jEROEN tEL - ARRANGED BY dAVE rOGERS - GAME BY j wILDSMITH AND s wELLARD - (C) 1988 rack it/hewson',dbglc=196,dis=split"12,10,9,14,7,8,13,13,2,2,11,15,3,6,6",l=1920,n='battlevalley',pal=split"1,2,3,4,5,-13,-12,8,9,10,11,-9,-8,-7,-5"},{a=782,c='COMPOSED BY nIGEL gRIEVE - ARRANGED BY dAVE rOGERS - GAME BY sTEVEN cOLLINS (c64) AND dAVID wARD (cpc) - (C) 1987 rack it/hewson',dbglc=701,dis=split"11,10,9,14,4,9,14,8,12,2,8,12,12,2,2",l=3136,n='herobotix',pal=split"1,2,3,-12,5,6,7,8,9,10,-9,-8,13,-7,-3"},{a=1574,c="COMPOSED BY dAVE rOGERS - GRAPHICS BY jULIAN wOOD - GAME BY jIM gARDNER - (C) 1988 mIND'S eYE sOFTWARE/silverbird",dbglc=310,dis=split"12,13,5,1,3,8,10,10,2,2,9,15,11,4,7",l=1536,n='turboboat',pal=split"1,2,-15,4,-13,6,-12,8,9,-8,-7,12,-4,14,-2"},{a=1427,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY cHRIS wOOD - GAME BY cHRIS wOOD - PUBLISHED IN sINCLAIR uSER ISSUE 80: mEGATAPE 9',dbglc=330,dis=split"12,15,6,1,5,11,10,9,14,7,8,13,13,2,2",l=1984,n='bearagrudge',pal=split"1,2,3,4,-15,-13,-12,8,9,10,-9,12,-8,-7,-4"},[1]={a=1525,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY cHRIS wOOD - GAME BY jUKKA tAPANIMAKI (c64) AND cHRIS wOOD (cpc) - (C) 1988 hewson',dbglc=318,dis=split"13,15,15,2,2,12,11,1,10,10,8,14,2,2,0",l=1408,n='netherworld',pal=split"1,2,3,4,5,6,7,8,9,-15,-13,12,13,-8,-3"},[2]={a=1121,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY sTEVE cROW AND mARK jONES - GAME BY mICHAEL cROUCHER AND dOMINIC rOBINSON - (C) 1987 hewson',dbglc=644,dis=split"11,14,3,10,10,6,12,15,1,9,8,13,2,2,0",l=3584,n='zynaps',pal=split"1,2,3,4,5,6,7,8,-15,-13,11,12,-8,-5,-4"},[3]={a=910,c='COMPOSED BY sTEVE tURNER - ARRANGED BY dAVE rOGERS - GRAPHICS BY aNDREW bRAYBROOK - GAME BY aNDREW bRAYBROOK (c64) AND nEIL lATARCHE (cpc) - (C) 1987 hewson',dbglc=233,dis=split"5,15,9,11,2,6,12,13,1,3,8,10,2,2,0",l=1280,n='uridium',pal=split"1,2,-15,-10,-9,6,7,8,9,-8,-7,12,-4,-1,15"},[4]={a=1419,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY rAFAELLE cECCO - GAME BY rAFAELLE cECCO - (C) 1988 hewson',dbglc=436,dis=split"12,15,1,5,5,11,10,9,14,6,8,13,2,2,0",l=2048,n='cybernoid',pal=split"1,2,3,4,-15,-12,7,8,9,10,-9,12,-8,-7,-4"},[5]={a=1098,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY hUGH bINNS - GAME BY rAFAELLE cECCO - (C) 1988 hewson',dbglc=472,dis=split"12,10,9,14,6,11,15,3,5,5,8,13,2,2,0",l=2048,n='cybernoid2',pal=split"1,2,3,4,-13,-12,7,8,9,10,11,-9,-8,-7,-5"},[6]={a=1108,c='COMPOSED BY jOHN m pHILLIPS - ARRANGED BY dAVE rOGERS - GRAPHICS BY cHRIS wOOD - GAME BY jOHN m pHILLIPS (c64) AND cHRIS wOOD (cpc) - (C) 1988 hewson',dbglc=380,dis=split"12,15,1,5,5,11,14,3,7,7,10,9,13,8,0",l=1472,n='nebulus',pal=split"1,2,3,4,-15,6,-13,-12,9,10,11,12,-7,-5,-4"},[7]={a=1210,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY rORY gREEN - GAME BY cASEY bEE gAMES - (C) 1988 hewson',dbglc=227,dis=split"13,15,15,2,2,11,10,9,14,7,8,12,2,2,0",l=1344,n='marauder',pal=split"1,2,3,4,5,6,-12,8,9,10,-9,-8,13,-7,-3"},[8]={a=1275,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY hUGH bINNS - GAME BY rAFAELLE cECCO - (C) 1989 hewson',dbglc=1019,dis=split"12,15,1,4,4,7,6,13,5,11,10,9,14,8,0",l=2240,n='stormlord',pal=split"1,2,3,-15,5,6,7,-12,9,10,-11,12,-10,-7,-4"},[9]={a=1311,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY mARK wASHBROOK - GAME BY rAFAELLE cECCO - (C) 1990 hewson',dbglc=762,dis=split"15,10,9,9,11,13,14,5,12,1,8,2,2,2,0",l=1984,n='stormlord2',pal=split"1,2,-16,-15,5,6,7,8,9,10,-12,-11,13,-10,-9"},[10]={a=911,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY jOHN cUMMING - GAME BY mICHAEL sENTINELLA (c64) AND mICHAEL cROUCHER (cpc) - (C) 1987 hewson',dbglc=221,dis=split"12,15,6,1,4,11,10,9,14,7,8,13,13,2,2",l=1152,n='anarchy',pal=split"1,2,3,-15,-14,-13,-12,8,9,10,-9,12,-8,-7,-4"},[11]={a=1676,c='COMPOSED BY jEROEN tEL - ARRANGED BY dAVE rOGERS - GAME BY j wILDSMITH AND s wELLARD - (C) 1988 rack it/hewson',dbglc=196,dis=split"12,10,9,14,7,8,13,13,2,2,11,15,3,6,6",l=1920,n='battlevalley',pal=split"1,2,3,4,5,-13,-12,8,9,10,11,-9,-8,-7,-5"},[12]={a=782,c='COMPOSED BY nIGEL gRIEVE - ARRANGED BY dAVE rOGERS - GAME BY sTEVEN cOLLINS (c64) AND dAVID wARD (cpc) - (C) 1987 rack it/hewson',dbglc=701,dis=split"11,10,9,14,4,9,14,8,12,2,8,12,12,2,2",l=3136,n='herobotix',pal=split"1,2,3,-12,5,6,7,8,9,10,-9,-8,13,-7,-3"},[13]={a=1574,c="COMPOSED BY dAVE rOGERS - GRAPHICS BY jULIAN wOOD - GAME BY jIM gARDNER - (C) 1988 mIND'S eYE sOFTWARE/silverbird",dbglc=310,dis=split"12,13,5,1,3,8,10,10,2,2,9,15,11,4,7",l=1536,n='turboboat',pal=split"1,2,-15,4,-13,6,-12,8,9,-8,-7,12,-4,14,-2"},[14]={a=1427,c='COMPOSED BY dAVE rOGERS - GRAPHICS BY cHRIS wOOD - GAME BY cHRIS wOOD - PUBLISHED IN sINCLAIR uSER ISSUE 80: mEGATAPE 9',dbglc=330,dis=split"12,15,6,1,5,11,10,9,14,7,8,13,13,2,2",l=1984,n='bearagrudge',pal=split"1,2,3,4,-15,-13,-12,8,9,10,-9,12,-8,-7,-4"}}

local wt,sc

function serialupdate(n)
 local wts=dr.wts
 sc+=n
 n=sc\1
 for i=0,n-1 do
  if(wt<wts)wt+=sndupdate()
  local s=ayupdate(ay,wts)*127
  poke(17152+i,s+128)
  wt-=wts
 end
 serial(0x808,17152,n)
 sc-=n
end

function serialinit()
 wt=0
 sc=0
 for i=1,512,128 do serialupdate(128) end
end

function peekstr(a,len) local s=""for i=a,a+len-1 do s..=chr(@i) end return s,a+len end
function pokestr(s,a) for i=1,#s do poke(a+i-1,ord(s,i)) end end

function rominit(a)
 pokestr(binstr,a)
 for g in all(games) do
  g.audio,a=peekstr(a,g.a) 
  local w,h
  w,h,a=px9_decomp(0,0,a,pget,pset)
  g.logo=peekstr(0x6000,64*h)
 end
end

local gi,nextgi,gfade
function gameinit()
 gi=nextgi
 local g=games[gi]
 pokestr(g.logo,8192)
 pokestr(g.audio,12288)
 pal(g.pal,1)
 pal(g.dis)
 ayinit()
 sndinit(12288,ay)
 serialinit()
 local sp="                                "
 cred=g.c..sp.."⬅️/➡️ SWITCH GAMES"..sp.."CART BY @CARLC27843"
 credx=128
 gfade=0
end

local parts={}
local partsfree={}
local partsfreen

function _init()
 memset(0x5f10,0,16)
 poke(0x5f36,16)
 rominit(-#binstr)
 cls()
 for i=1,1120 do add(parts,{x=0,y=0,t=5,vx=0,c=0}) end
 for i=1,1120 do add(partsfree,parts[i]) end
 partsfreen=1120
 nextgi=1 gameinit()
 poke(0x5f2e,1) -- persist palette
end

function _update60()
 if(stat(108)<1024)serialupdate(91.8667)
 if gi==nextgi then
  if(btnp(0))nextgi=(gi-2)%#games+1
  if(btnp(1))nextgi=gi%#games+1
 else
  ayvol(1-gfade/8)
  gfade+=1
  if(gfade==8)gameinit()
 end
end

function _draw()
 -- cpc transition
 if gi!=nextgi then
  for a=24576+64*gfade,32767,512 do
   memset(a,0,64)
  end
  return
 end

 local g=games[gi]

 local a=0x6000
 local o=max(0,22-g.l\128)*64 
 memset(a,0,o)a+=o -- cls above logo
 memcpy(a,8192,g.l)a+=g.l -- logo
 memset(a,0,0x8000-a) -- cls below logo

 if(credx<-#cred*4)credx=128
 credx-=1
 print(cred,credx,123,5)

 for i=1,1120 do
  local p=parts[i]
  local pt=p.t+1
  if pt<5 then
   p.t=pt
   p.x+=p.vx
   p.y+=-2
   pset(p.x,p.y,p.c+pt)
  elseif p.t<5 then
   p.t=5
   partsfreen+=1
   partsfree[partsfreen]=p
  end
 end

 local y=64
 local hw=64
 for aychn in all(ay.chns) do
  local zi=aychn.oscz[((aychn.osci-hw)&1023)+1]
  if(zi&1>0)zi=aychn.oscz[((zi\2-1)&1023)+1]
  local zj=aychn.oscz[((zi\2-1)&1023)+1]
  local i=zi\2+(zj-zi)\4+hw
  for x=127,0,-1 do
   local vc=aychn.oscv[(i&1023)+1]
   local ny=y-(vc&0xffff.ff)*30\1
   local c=((vc<<16)&0xff)*5+1
   if x==127 then
    line(x,ny,x,ny,c)
   else
    line(x,ny,c)
   end
   if partsfreen>=1 and rnd(1)<0.6 then
    local p=partsfree[partsfreen]
    partsfreen-=1
    p.x=x+.5
    p.vx=(rnd(1)-.5)-(x-63.5)/32
    p.y=ny
    p.t=0
    p.c=c
   end
   i-=1
  end
  y+=24
 end
end

binstr='カ0ン0」◝ よ¹\0\0%ᶠLᵉ~\rやᶜ⁶ᶜYᵇへ\n、\n⬅️	²	█⁸⁶⁸⧗⁷&⁷よ⁶^⁶³⁶て⁵[⁵ᵉ⁵わ⁴▒⁴@⁴³⁴ゃ³⧗³`³/³¹³サ²と²♥²c²@² ²²²ハ¹ゃ¹ぬ¹▤¹▒¹k¹W¹C¹1¹ ¹▮¹¹¹ラ\0ハ\0ス\0ア\0ら\0へ\0つ\0け\0▥\0…\0☉\0█\0y\0r\0l\0f\0`\0[\0V\0Q\0L\0H\0D\0@\0=\0009\0006\0003\0000\0-\0+\0(\0&\0$\0"\0 \0゛\0。\0•\0」\0「\0▶\0‖\0⁘\0⁙\0□\0■\0▮\0ᶠ\0ᵉ\0\0\0+1/191L1V1]1m1t1~1☉1★1う1こ1へ1ら1ゅ1ケ1テ1ヌ1レ1⁵2ヤ2ユ2⧗3に3む3わ3ヌ3ロ3⁸4゛494P4`4ね4⁵5#5$5/5C5F5r5🐱5さ5オ5っ█っ◝¹⌂¹²z¹¹|¹◝¹⬅️¹¹○³¹▒³¹○³¹▒³っ█っ◝¹◆¹¹○²っ█っ◝¹♪¹⁘○ᵇ◝¹🅾️¹¹▒¹¹○¹⁵○	っ█っ◝¹⬅️¹⁘○\n◝¹♪¹¹○ᵇっ█っ◝¹♪¹¹○⁷っ█っ◝¹😐¹¹○⁴⁘○⁸◝¹★¹¹~	っ█っ◝¹웃¹(○	◝¹🐱¹¹~²¹🐱¹¹⬇️¹¹}²¹⬇️¹◝¹🐱¹¹|¹¹🐱¹◝¹⬇️¹¹z¹¹⬇️¹◝¹P¹¹▤²っ█っ◝¹█¹¹ひ¹っ█っ◝¹▒っ◝¹♪¹¹🐱¹¹○²²○²³○⁷っ█っ◝¹웃¹¹~³²▒⁶¹~³っ█っ◝ヨ¹ユ⁘²²³¹ルホ\0メ\0ヘ⁷ヘ⁷マ⁵³⁷ヘ⁴³⁶ヘ⁵³⁶ヘ⁴³⁶ヘ⁴³⁶ヘ⁵³	ヘ⁴³⁶ヘ⁴³⁶ヘ⁴³	ヘ⁴³⁸マ⁸ヘ⁴マ⁵ホ\0³⁶ヘ⁴³⁶ヘ⁴³⁶ヘ⁵³⁶ヘ⁴³⁶ヘ⁵³⁶ヘ⁴³	ヘ⁴³⁸マ⁸ヘ⁴³³マ⁶メ⁷ホ	ヘ⁴ヘ⁴ホ⁶ヘ⁴ヘ⁴ホ³ヘ⁴マᵇヘ⁴ヘ⁴ヘ⁴マ	ホ\0ヘ\rマ³ヘ\rマ³メᶜヘ\rマ	ホ⁷ヘ\rマ³ホ\0ヘ\rメᶜマ⁸ヘ▶マ³ホ³ヘ▶ホ\0マ□ヘ⁘ヘ▶ヘ⁘ヘ▶ヘ▶²■( マᵇ(き³¹ヘ□ホ\0ヘ□ヘ□ホ³ヘ□²⁸ヘ□ホ⁶ヘ□ホ	ヘ□ホᶜヘ□ホᶠヘ□²⁙\0,\0²ヘ▮ラハルマ\0\0\\ミᶠ\0³マ²ルヘᵇ\0¹マ²ホᶜ\0ᶜミ\nヘ\nマ⁸ホ⁷ヘ⁴ミ\nホ\0マ²ヘ\nホ⁷マ⁸ヘ⁴メᶜホ	ヘ⁷ヘ⁸ホ⁶ヘ⁷ヘ⁸ホ³マᵇ\0⁸らヘᶜヘᶜヘᶜ<⁴め9⁸4⁴のぬにとメ\0マ⁸ミᵉ\0|Mらホᶜマ⁴ミ\0ヘᵉマ	メᶜ\0⁴ヘᵉマ⁶ホ⁙メ\0\0⁸ヘᵉマ	ホᶜ\0⁴ヘᵉミᶜマ²ヘ⁸ヘ⁸\0 ホᶠヘ「メ「ホᶜマ⁶ヘ‖ヘ「ヘ‖ヘ「ホ「マ	ヘ\rラマ⁶ホ	ヘ⁴ヘ⁴ホ⁶ヘ⁴ヘ⁴ホᶠマᵇヘ⁴ヘ⁴ヘ⁴\0っ█ラミᶜ!「!⁴かう゜ᶜラミᶜ!「#⁴さう゜ᶜラマ⁷メᶜム\0~9⁸~0⁴x█rぬlのfぬのマ⁸tみl7ᶜラマ	ミ\rム▮f<⁸fひfめfひfみfひラマ	ム▮f\0⁸f█f█f█f█f█ラマ	メᶜム▮fH⁸fらfんfらfわfら\0|ラ9゜ミᶜ9 8▮も70ほ6 2▮5 -▮ミ\n00\0¹ラ9⁴みみみまもほほほ7ᶜ6⁸2⁴5⁸-⁴0ᶜラム▮fH⁸fらfんfらfわfらラ³ᶠメᶠ。⁸。▮。⁸゜⁴か゜▮゜⁸³ᶠメ▮き ▮ ⁸メᶠけ"▮"⁸³ᶠメ▮$⁴さ$▮$⁸し%▮$⁸³ᶠメᶠか゜▮゜⁸"⁴け"▮"⁸³ᶠメ▮さ$▮$⁸メ⁷さけきかラ$³)⁴つてさたつてさたさたけたけたさたつてさたつてなしたなてしなたぬなてつそたつそつてつたしせさしけしたつたしけしつしつしたけしけさたつてさたつてさしけさきけか\0¹ラム\0マ¹メ⁵hH⁴█hっ\0ᶜhH⁴█hっhっhっ█なてつたララマ	メᶠ"⁸"▮"⁸ラマ⁙メ³ム▮fC⁸fやfらfむfやfほラヘ□ハ³◀ ⁸ ⁴き ⁸ ⁴ききききき゜⁸゜⁴か³◀。⁸。⁴え。⁸。⁴え。⁸。⁴え。⁸。⁴えラ)⁸(▮せ$ᶜせ+「\'▮$ᶜしラマ⁵ム■f\0▮マ²ミ\r?⁸=⁴よマ⁵f\0▮マ⁸l\0⁸l\0⁴l█\0|ラ³◀」⁸」⁴し」⁸」⁴し」⁸」⁴し▥▥▥し³◀•⁸•⁴せ•⁸•⁴せ、⁸、⁴そ、⁸、⁴そラ\'³%⁴つしせしつしせしつしせしつしせしてしせしてしそしてしそしてし\0¹ラ◝◝◝ユk⁷も!░▮>ユ▒▮Bヲ⁸O★H⁸!IおHノb░⬅️+I$웃❎❎P~ニ#ナGるG▮~"うニ$ュをりAヲX⁸ᵇ○キDヲ{a、もも░◆◆\0ニナナ/る◝%う、ュᶠ8ヲた웃、¹\rニ▶ᵉJCノ◝トユ?\'░▮>ユ▒▮Bヲ⁸O★H⁸!IおHノb░⬅️+ゃ◝◝Oっ@⁸ニ%⬆️▮B⁸゜¹!░▮B⁸!░▮Bま⁸!ュ◝◝⁴\r!、\\░ラ■ᵉᵉ゛F\n!░▮るˇ$□.B⁸◝◝?AB	ニ%⬆️▮B⁸゜¹!|░▮B⁸!░p■Bヲ◝◝	²Fヲ(く░▮るG⁸⁸!M$★$O$□B⁸゜ま★ュ◝◝よ🐱░▮る⁷>▮B⁸゜ニI□	!$ゃ⁙웃\\😐pq%웃$ヨラ□ゅ/|⁴ナ7るG▮~"うニ$ュをりAヲX⁸ᵇ○キDヲ{a、もも░◆◆\0ニナナ/る◝%う、ュᶠ8ヲた웃、¹\rニ▶ᵉJ³ん0タ02ᶠ▮よ¹\0\0゛▮6ᶠ\\ᵉ♪\rょᶜ⁙ᶜeᵇる\n\'\nˇ	ᵇ	⌂⁸ᶠ⁸い⁷.⁷ん⁶e⁶	⁶は⁵a⁵⁘⁵ょ⁴●⁴E⁴⁷⁴ウ³❎³c³3³⁵³セ²ぬ²⌂²e²C²"²⁴²フ¹ょ¹の¹▥¹🐱¹m¹X¹E¹3¹!¹■¹²¹リ\0ヒ\0セ\0イ\0り\0へ\0て\0け\0▥\0➡️\0웃\0▒\0z\0s\0l\0f\0a\0[\0V\0Q\0M\0H\0D\0@\0=\0009\0006\0003\0000\0.\0+\0)\0&\0$\0"\0 \0゛\0。\0•\0¥\0「\0▶\0◀\0⁘\0⁙\0レ0ン0\0001⁷1⁘1゛1%1/161I1S1ら1▮2E2o2な2ホ2⁴3\n3,3<3r3メ3っ█っ◝¹░³っ█っ◝¹♪¹っ█っ◝¹◆¹¹○³¹▒¹っ█っ◝¹◆¹¹○ᵉっ█っ◝¹🅾️¹¹q¹◝¹😐¹¹|³っ█っ◝¹▒³¹○³◝¹▒¹³○¹²▒¹⁴○¹¹▒¹⁵○¹◝¹▒¹2█¹¹●c◝²ᵇ³ᶜム\0マ³ミ	ホ\0!@+らミ⁷ヘ¹ヘ¹ヘ¹ホ¹ヘ¹マ⁴ホ³ヘ¹マ³ミ	ホ⁴ヘ⁴ホ⁵ヘ⁴ホ\0ヘ⁷ヘ\nマ³ヘ¹マ⁴ホ⁵ヘ¹ホ³マ²ヘ¹ヘ¹ヘ¹\0@マ³ミ⁷ホ\0ヘ¹ホ¹ヘ¹ホ⁴ヘ¹マ⁴ヘ¹マ³ホᶜヘ⁴ホ⁙ヘ⁴ホ\0ヘ⁷ラ-⁸くとくsとそさそとくとくsちおちおつかつかsつすさすつかつかsつすさすとくとくsとそkすkそsとくとくsちおちおつかsつかsつiすsさすつかつかsちすさすラ\0▮9⁸めも\0(9⁸め<▮ゆ7@5⁸ほひふのひ0▮0⁸にみめも\0(<⁸ゆB▮ゆC0\0⁸れんれっれゃれJ▮ラ4▮みら4⁸み@ へ2▮ほゆのほゆのほひみらE⁸れE へ2▮ほゆの\0⁸>▮のほ\0⁸ラ&▮すすすすすとと$⁸▤sさ▤ささsささたえsたえたさsなさたえsたえたさsたたsなけなけなたせたsさつsそつpさpさpささラ\0▮9⁸ゆる█れ█るらゆ█み█みめ<▮9⁸█み█みめ<▮A⁸█わ█を█われり█も█もゆよゆもむA @⁸ゆ<▮C「\0⁸ラ\0▮6⁸みゆ█ら█ゆめみ█! 4@90:⁸█<@りれラ゛@あきうラB⁸をろらろるもらゆむゆもへむまひまへぬひのなのぬちなてそてちさそラ6▮ままぬののちててさ& (@ラE⁸█わ█わらもらもみもみへみへの/「4⁸2「9⁸7「<⁸めほのにぬにとのぬにひのぬへひの6▮の7@マ²█ラレ0マ³ミ	ホ⁷-@< ;きミ⁸マ⁴ヘ¹レ\0マ³ホ\0ヘ³ヘ²ホ¹ヘ²ホ³ヘ²ミ	ホ⁴ヘ⁵ホ⁵ヘ⁵マ⁴ホ\0ヘ⁸マ¹ミ⁷ホᶜヘ¹ミ⁶ヘ¹ミ\0マ⁴ホ■ヘ\nホᶠマ⁵ヘ³ヘ¹ヘ\n\0@マ³ミ⁸ホ\0ヘ²ホ¹ヘ²ホ⁴ヘ²マ⁴ヘ\nマ³ミ⁷ホᶠヘ⁴ホᶜヘ⁴ホ\0ヘ⁸ラマ²ミ	ホᶜ9@4 の2█ミ⁷マ¹ヘ¹ホ\0ヘ³ヘ²ホ¹ヘ³ホ³ヘ³マ³ミ	ホ⁴ヘ⁶ホ⁵ヘ⁶ホ\0ヘ	マ¹ミ⁷ホ「ヘ\nマ¹ヘ¹マ⁴ホ■ヘ¹ホᶠマ⁵\0⁸ヘ³ヘ¹ヘ\n\0008マ¹ホ\0ヘ³ホ¹ヘ³ホ⁴ヘ³マ⁴ヘ²マ³ミ⁶ホ⁙ヘ⁴ホ▮ヘ⁴ホ\0ヘ	ラ◝◝◝ユ○o▒?◜エ|ュ◝ワっはイ◝_◆<タュ◝up█◝よᵉᵉユ◝ワまのュ&8らᶠ、I◜◝ょ$んるO🐱cまみ"ノ◝に█cヲEなニ&<Hラよ❎wネ▤まさ\\‖∧ノ▮も⧗L~HラゃOュぬ$oxB#♪<✽NキアᶠvユC8ノせm◜X8▶お…オ웃こ²🅾️$➡️_∧$ロKXヌか웃よ8♥せPp😐░c⁸◝か	웃○&◜ネ、おPpᶜo"、😐◝cノ◝▒✽\'➡️ろ³モD8bIT◜k□◆|Y◜▶▥,<⬅️\\ナ♥Lxヲ▒♥ラCム◝5lニ➡️ᵇ、Hキ$ニヤ$M2な✽◝Sヌ▥8xら■■あヲよ.ヨ◝I<➡️ユウ、⬇️P{	?●⬇️oK◜/웃gb|⁸ハきr●$)○░♥sI◜゜웃g웃⬇️♥░ゅ◝0\\vリよ⁸エpQ∧(◝よユ\rト★ュᶠノ¥なLmュOれ5■>◜⁷\\れ▶ゅ◝7sEᵉ.ンえk8CンYN◜\r▶ᶠ○Gおニ\rハよp0~ᶠWヲか░gまCン-\\░よれ❎yノトユLュ▮ゅ_ニ⁴?♥o8らかナ\0○░ラSまれよニ•ᵉユ\'8ら/くュ⁙◜きュ‖ゆニ\0○🐱³ュ⁙ゅ/웃_「○✽oヌ\0○🐱G◜ヌ…_ヲeI>yれほp█?りト、!<ュへ%ニナ😐|ᵇ⁷ヲ⁙ュウり◝cI.~K<⁙○🐱◝¹⁷◝⧗%yヲ+ヨLュ	◜ᶠ、ュ_∧ノ☉░゜★<⁙○&ン○$¥をヲ•,ュ★ノ」◜トくニニ○AヲB♥³ュエCyる◝³\\くれ¹◜ヤく、ニ◝□おオニ\0◝ャP¥◜?tヘp█◝?▮ゅ□◝#6tヌ\0◝◝ ⬆️ヨ○⧗#ラ█◝よ…(◝G¥゛ユ◝゜Bンよ●gヲ◝⁙くュOれ3ュ◝⬅️0◜せれ¹◜◝F⁸◝クニ\0◝◝#ナ○:、ナ◝◆ᶜ◝[ᵉ◜◝?█ラ◝gノ◝•を◝◝▶▮◜◝◝\0ュ◝○Bヲ◝◝◝²◜○▥1は12◝■の¹\0\0C⁘゜⁙\r□	■‖▮.ᶠSᵉ●\rれᶜᶜᶜ_ᵇも\n!\n…	⁶	✽⁸\n⁸❎⁷*⁷れ⁶b⁶⁶⁶に⁵^⁵■⁵っ⁴⬇️⁴B⁴⁵⁴ょ³ˇ³a³1³³³ス²に²☉²d²B²!²³²ヒ¹ゅ¹ね¹▤¹▒¹l¹W¹D¹2¹!¹■¹¹¹リ\0ハ\0ス\0ア\0り\0へ\0て\0け\0▥\0…\0☉\0▒\0y\0s\0l\0f\0`\0[\0V\0Q\0L\0H\0D\0@\0=\0009\0006\0003\0000\0-\0+\0)\0&\0$\0"\0 \0゛\0。\0•\0¥\0「\0▶\0‖\0⁘\0⁙\0¹¹\0\0⁴\0ᵇ\0ᶠ\0、\0/\0?\0I\0P\0]\0a\0k\0u\0○\0웃\0…\0➡️\0▤\0か\0す\0は\0れ\0イ\0ケ\0テ\0ハ\0レ\0ン\0\0¹\n¹■¹「¹"¹&¹¹¹¹¹\0\0/\0N\0W\0~\0ほ\0ュ\0◀¹G¹R¹]¹d¹k¹x¹▒¹●¹⧗¹あ¹せ¹の¹も¹れ¹ゅ¹カ¹チ¹ャ¹²²ᵇ²「²-²2²9²@²G²N²U²\\²c²n²u²~²♥²…²え²さ²つ²ま²り²っ²ネ²ッ²‖³、³#³っ█っ◝¹█¹¹ひ¹◝¹○¹◝¹◆¹¹~わ1ゃ1オ1ツ1ユ1\0002⁴2ᵉ2「2"2/2?2I2S2○2お2せ2キ2\r3>3W3⬇️3っ█っ◝¹█¹¹ひ¹◝¹◆¹¹~¹¹🐱¹っ█っ◝¹◆¹¹█¹¹○³⁵○⁸⁸○³っ█っ◝¹🅾️¹⁸○³、○⁵0○³っ█っ◝¹∧っ◝¹●¹¹}²っ█っ◝²▒²²○³²▒¹◝¹▒¹¹~¹¹▒¹◝¹◆¹²█¹⁴○ᶠっ█っ◝¹v¹¹⌂¹²○⁸⁴○⁶っ█っ◝¹🅾️¹¹█¹¹r¹◝¹☉¹¹▒⁷¹q¹◝マ	ム\ns\0⁘s█²¹³²ホ⁶マ²ヘ³ヘ³ヘ⁶ホ	ヘ³ヘ³ヘ³リ⁸³⁸ヘ⁶マ\0\0P¹\0ラホ⁶マ⁴ヘ⁴ヘ⁷ホ、マᶜヘ³マᵇホ	ヘ⁴マ⁴\0⁵ヘ⁷マ\0\0チラホ⁶マ³ミ⁵ヘ⁵ラミ⁸¥゛&⁴(▮¥\nすあ¥゛&⁴(▮¥\nすう。゛)⁴+▮。\nたえ)゛)⁴+▮。\nたえラミ⁷2Pみ9⁘7\nみゆもめも9⁘7\nみミ⁶>⁘ミ⁷<\nめミ⁷2Pみミ⁶9⁘ミ⁷7\nみゆもめもわみれみミ⁶りミ⁷ら>⁘ラム\0s\0⁘ム¹リ⁸f>⁵リ、█f██ム\0i\0⁘ム¹f\0⁵f█f█f█ム\0s\0⁘ム¹f\0⁵█f██ラ!゛-\n!⁘と。゛)\n。⁘た¥゛&\n¥⁘す¥(█ラミ⁷@\nれわれE⁵れらもみほひぬ-゛ミ⁶-\n-⁘と-゛-\nミ⁷0⁘ミ⁶5\nミ⁷ひ2(█ラマ³ホ	ヘ⁷マ\0ヘ³ラ◝◝◝ユc○☉⁶へこM◝る?➡️ほ"웃ュ■■■Iノ❎☉☉H*rWDさrキd○ゃ◝っ゛~ネニフアわ⧗ヲ웃◝]ヲ゜♥⬇️+ょ゜░◝8i"L~…&BヲU…0⁶る/ッ◝★◝88ヲ9$✽⁵ュハヲ◝い!🅾️●ユ▶○フゃ\'i"たっO‖ン_░⬇️ラ?ノ◝ヤ░qユ?ᶜ▶ネ◝/⁴<ュハッ=1゛◜◝³゜○ヨ?⁸ゃハ◝Oッヌャ⬇️;➡️ユ⁷○pリᵇ◝/◜▶!ニ◝/をンᵇネ\rゃホgを■◜!ュトやwH^▶◝ヨユ•◝wワᶠ!モラ◝○ン#ュ◝せ、ン?ゃ。ᵉ◜&I◜⬆️トチ◝トユ◝◆rヲ゜ヨK★◝⬇️⬆️゜ン+\0カ0リ02◝■◝¹\0\0ᶜ‖ツ⁙ら□の■ひ▮ろᶠヌᵉᶜᵉB\r░ᶜオᵇ&ᵇ●\nヤ	`	セ⁸Z⁸ヌ⁷q⁷⁶⁷く⁶B⁶ヘ⁵⧗⁵C⁵ワ⁴ぬ⁴m⁴-⁴ヨ³ま³⬇️³P³!³ル²ゅ²く²|²X²6²▶²ン¹チ¹り¹そ¹…¹z¹e¹Q¹>¹,¹•¹ᵇ¹ュ\0モ\0ニ\0ケ\0っ\0や\0の\0そ\0か\0∧\0🅾️\0●\0~\0w\0p\0j\0d\0^\0Y\0T\0O\0K\0G\0C\0?\0<\0008\0005\0002\0/\0-\0*\0(\0%\0#\0!\0 \0゛\0、\0•\0」\0「\0◀\0‖\0⁘\0\0\0#1\'111;1B1O1\\1i1s1}1♥1➡️1い1し1て1ぬ1む1ん1u2v2○2⌂2ぬ2	3\\3x3⬆️3へ3り3わ3ス384J4て4る4シ4モ455:5M5z5っ█っ◝¹▒\r	○	っ█っ◝¹♪¹¹○⁴¹w¹◝¹♥¹っ█っ◝¹😐¹\n○⁸⁘○⁴っ█っ◝¹♪¹²○⁷ᶜ○⁶っ█っ◝¹♪¹¹○ᵇ	○²っ█っ◝¹☉¹¹🐱¹っ█っ◝²▒²²○³²▒¹◝¹▒²¹○⁴¹▒²◝¹웃¹¹y¹っ█っ◝¹🐱²¹~⁴¹🐱²◝¹♥³¹y⁶¹♥³◝¹☉\n¹∧っ◝²○っ◝¹█¹¹ひ¹っ█っ◝¹█¹¹⬅️¹¹ひ¹っ█っ◝ヨ¹マ\0\0000ヘ⁴²²ヘ⁴²³ヘ⁴²⁸\0T²⁴ヘ⁵²⁴ヘ⁶²⁴ヘ⁵²⁴ヘ⁶²¹k\0⁶k█ヘ\rヘᶠヘ\rヘᶠヘ⁸ヘ⁸ヘ⁸ヘᶜ²⁴ヘ⁵²⁴ヘ⁶²⁴ヘ⁵²⁴ヘ⁶²¹メ\0k:⁶kみヘ\rヘᶠヘ\rヘᶠ²‖ヘ◀k\0⁶k█ヘ	ヘ⁷ヘ	ヘ⁸ホ⁙²□ヘ⁙f\0ᶜ²□ヘ⁙f\0ᶜホ‖²⁘ヘ⁙f\0ᶜ²⁘ヘ⁙²ᵉヘ⁵²ᵉヘ⁵²ᵉヘ⁵²ᵉヘ⁵k\0⁶k█ヘ\rヘ\rヘᶠ²‖ヘ◀ヘ⁷ヘᵇラハマ\0\0`ヘ⁷ヘ⁷ラヘ	マ\0\0000ヘ⁷ヘ⁷ラホ⁷マ²ミ	メ\0゜ᶜかけさすメᶠすメᵉすすメ▮けメ\0け∧け∧メ▮さメ\0▤さラホ⁷マ⁵メ「³▶ム▮f0⁶fねfのfぬfのfふム\0k:ᶜム▮f<⁶fみf█f█f█f█ム\0k\0ᶜム▮f\0⁶f█f█f█fなf█ム\0k0ᶜム▮f2⁶fぬf█f█f█f█ム\0k\0ᶜラ³▶ム▮f0⁶fねfのfぬfのfふム\0k:ᶜム▮f<⁶fみf█f█f█f█ム\0k9ᶜム▮f5⁶f█f█f█f█f█ム\0k7ᶜム▮f4⁶f█f█f█f█f█ム\0k\0ᶜラマ⁶ムᶠ³¹f\0⁶f█f█f█ム\0k\0ᶜムᶠf\0⁶f█ラマ⁶ム▮³¹f\0⁶f█f█f█ム\0k\0ᶜム▮f\0⁶f█ラホ⁙マ⁶ム\0ミ\0³¹ム▮fC⁶fりsもfゆム\0k\0ᶜム▮k\0⁶k█ラホ⁙マ³ミᶜ\0ᶜHそハ\0ユ█ラマ⁶ム▮f\0⁶f█f█f█ム\0k\0ᶜラホ⁷マ⁵ミᵇメ「゜⁶メ\0かメ「かメ\0かムᵉk█かメ「かメ\0かメ•おメ\0おメ•おメ\0おk█おメ•おメ\0おメ•かメ\0かメ•かメ\0かムᵉk█かメ•かメ\0かメ。くメ\0くメ。くメ\0くkくくメ•くメ\0くラk\0⁶k█ヘ\rマ³<0H…<0H…ラ²▮メ「"⁶メ\0けメ「けメ\0けム¹k█けメ「けメ\0けメ(えメ\0えメ(えメ\0えk█えメ)kえメ\0え²■ム¹メ!fさメ\0fさメ゜fさメ\0fさメ゜kさメ\0さささメ゜sさoさlさiさメ\0fさiさoたsつラホ゜マ⁷ミ⁸\0ᶜけさす-⁶█と█-ᶜな\0000ハホ゜マ⁷ミ⁸-ᶜ+⁶█つ█+$ミ\rほ\0`ハマ²ミ	$「せつな\'$(ᶜ)「-ᶜ.⁶ぬ\0`ハマ⁴メ\0ミ⁸³▶ム▮f0⁶なfてたム\0kせさfけさム▮fせ█fさ█ム\0kつ█fせせム▮f██f██ム\0kた█fすすム▮f██f██ム\0k██ラホ²ヘ□ラホ⁷マ²ミᵇ H"「#Hマ⁴%xヘ\nハホ⁷マ⁶メᶜ7⁶ほ5ᶜム▮iは0「2ᶜiはiふ6⁶へ5ᶜiは/「1ᶜムᵉkはマ⁴5`メ\0ラホ7マ\nミ\0モ゜ヒ⁶⧗ヒ⁶かヒ⁶ラ◝◝◝ユ○ホ³んかヲ;▶◝○?2)$◀ャ◝クセ□🅾️スノ◝oGll[★ヲ◝タ⬇️%,★ろ◝゜◆▤D$웃◝よ➡️Lへ◝✽ョeゅへᶜな,⧗ᶠ<I"W★ゃ⧗dI$れ◝dねかお,セX□_◀r。ᵇみ★っ\\▒|IH🅾️り◝e	ロ⬇️%□□➡️dYᶜ6ミ`IるるH∧⁴い✽⁴웃%ン◝、&^」!■•▥▒¹⁷²⁴C⁶⬇️ᵇ $∧m[ヲト、K🐱チ◀Dっaり¹i□⁵▶ら`█¹⁶\0	ら◝フZ□ヨソ#➡️ネI●る⁘🐱\n⁶³ᶜ0らpdり◝ヘZ2sソcょB$!O\r[◀1a0ら\0³ᶜんろ◝ミZ□リqス★ハb◀ん5 ▒(「`█¹●³웃◝セふ%ヒヌっ◀つY★Cラ`웃M a³&`█a 웃◝タふ웃y'
