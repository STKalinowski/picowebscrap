-- alfonzo's bowling challenge
-- by kittenm4ster

state_coach = 1
state_pinbot = 2
state_play = 3
state_score = 4
state_credits = 5
state_end = 6

pbstate_present = 1
pbstate_present_done = 2
pbstate_move = 3
pbstate_move_done = 4

coachstate_wait = 1
coachstate_title = 2
coachstate_done = 3

mode_bowl = 1
mode_breakfast = 2
mode_breakout = 3
mode_bb = 4
mode_bj = 5
mode_bird = 6
mode_bro = 7
mode_barber = 8
mode_boss = 9
b_words = {
	"bowling",
	"breakfast",
	"breakout",
	"basketball",
	"blackjack",
	"birdwatching",
	"brother's",
	"barbershop",
	"bossfight",
}
credits = {
	"created by",
	"andrew",
	'"kittenm4ster"',
	"anderson",
	"",
	"with lots of",
	"help from",
	"aubrianne",
	"anderson",
	"",
	"playtesting",
	"by",
	"amos anderson",
	"",
	"5x6 font by",
	"zep"
}

font = "abcdefghijklnopqrstuvw'"
ballr = 4
netw = 12
ranktxt = {
	[1] = 'a',
	[11] = 'j',
	[12] = 'q',
	[13] = 'k'
}
faces = {
	{11, 72},
	{35, 96},
	{51, 96},
	{67, 96},
	{83, 96},
	{99, 96},
	{35, 112},
	{51, 112},
	{67, 112},
	{83, 112},
	{99, 112},
	{35, 64},
}

function _init()
	tutorialon = true
	tutorial = {y = 110, vy = 0}
	platforms = {
		{x = 0, y = 124, vy = 0, oy = 75, w = 32, h = 1},
		{x = 96, y = 124, vy = 0, w = 32, h = 1}
	}

	actors = {}
	vactors = {}
	balls = {}
	bricks = {}
	fixtures = {}
	pins = {}
	sprites = {}
	knockables = {}
	knockers = {}
	players = {}
	bjbtns = {}
	eggs = {}
	yolks = {}
	paneggs = {}
	targets = {}
	clearables = {}

	particles = {}

	player_colors = {12, 8, 9, 10, 11, 14, 4, 7}
	playercount = 0
	totalscore = 0
	score = 0
	message = {timer = new_timer(120)}
	message.timer.expire()
	pitimer = new_timer(180)

	coroutines = {}
	add_cr(run_coach)
	add_cr(run_pinbot)
	add_cr(run_platforms)

	bgoffset = 0
	coach = {x = -32, y = 64, face = 1}
	state = state_coach
	level = 0
	music(0)
end

function add_player(i)
	playercount += 1
	local x = playercount == 1 and 60 or rnd_int(36, 85)
	local c = del(player_colors, player_colors[1])
	local b = add_ball(x, 105, c)
	players[i] = b
	b.pi = i + 1
end

function del_player(i)
	local p = players[i]
	del_actor(p)
	players[i] = nil
	add(player_colors, p.c)
	playercount -= 1
end

function add_ball(x, y, c)
	return add_actor({
		pos = vec2.new(x, y),
		prev = vec2.new(x, y),
		r = ballr,
		rot = 0,
		gravity = .08,
		friction = .999,
		bounce = 0.6,
		isball = true,
		c = c,
		bbstate = 0,
		overlap = circ_rect_overlap,
		get_knock_velocity = function(b) return b.v end,
		knock_slowdown = function(b) b.framefriction = .7 end
	}, {balls, knockers})
end

function btnp_any(b)
	for p = 0, 7 do
		if players[p] then
			if btnp(b, p) then
				return true
			end
		end
	end
end

function add_pin()
	return add_actor({
		x = 1, y = 1, w = 4, h = 8, s = 1, i = #pins + 1,
		offset = {x = -2, y = 0},
		scoreval = 1,
		receive_hit = function(p)
			p.w, p.h = 8, 4
			p.x -= 2
			p.y += 2
			p.s = 2
			p.flip = rnd_int(0, 1) == 0
			p.offset = {x = 0, y = -2}
			add(knockers, p)
		end,
		overlap = overlap,
		get_knock_velocity = function(p) return {x = p.vx, y = p.vy} end
	}, {vactors, pins, knockables, sprites})
end

function position_pins(pins)
	local halfw, i = pins[1].w / 2, 0
	for y = 8, 11 do
		for x = 8, 14 do
			if mget(x, y) == 1 then
				i += 1
				local p = pins[i]
				p.x, p.y = 32 + ((x - 7) * 8) - halfw, (y - 7) * 8
			end
		end
	end
end

function add_actor(a, tables)
	local r = add(actors, a)
	r.tables = {actors}
	if tables then
		for _, t in pairs(tables) do
			add(t, r)
			add(r.tables, t)
			if t == vactors then
				r.vx, r.vy = r.vx or 0, r.vy or 0
			end
		end
	end
	return r
end

function update_input()
	for i = 0, 7 do
		local p = players[i]
		if p then
			if btn(⬅️, i) then
				p.pos.x -= .05
			end
			if btn(➡️, i) then
				p.pos.x += .05
			end
			if btnp(5, i) then
				del_player(i)
				pitimer.reset()
			end
		elseif btnp(4, i) then
			add_player(i)
			pitimer.reset()
		end
	end
end

function level_is_done()
	if mode == mode_bowl or mode == mode_breakout or mode == mode_bird then
		if #targets == 0 then
			return true
		end
	end

	if mode == mode_bowl then
		return score == 10
	elseif mode == mode_bb or mode == mode_bird then
		return pbstate == pbstate_move_done
	elseif mode == mode_breakfast then
		return #eggs == 0 and #yolks == 0
	elseif mode == mode_bj then
		return costatus(blackjack_cr) == 'dead'
	elseif mode == mode_barber then
		return score == 6
	elseif mode == mode_bro then
		return #knockables == 0
	elseif mode == mode_boss then
		return boss.hp == 0 and #particles == 0
	end
end

function end_level()
	if mode == mode_bird then
		music(0, 1000)
		if score >= 0 then
			add_score(10)
		end
	end

	if (level == 0) return

	message.txt = tostr(score)

	if mode ~= mode_bb and score >= maxscore then
		sfx(61, 3)
		message.txt = "strike!"
	end

	if mode == mode_bj then
		message.txt = "please gamble responsibly!"
	elseif mode == mode_barber then
		message.txt = "lookin' sharp!"
	elseif score == 0 then
		sfx(59, 3)
		message.txt = "gutter ball!"
	end

	message.timer.reset()
end

function update_state()
	if state == state_play then
		if level_is_done() then
			end_level()
			state = state_score
		end
	end
	if state == state_score and message.timer.get_value() <= 15 then
		state = state_coach
	end
	if state == state_coach and coachstate == coachstate_done then
		state = state_pinbot
	end
	if state == state_pinbot and pbstate == pbstate_present then
		state = state_play
	end
end

function choose_mode()
	return level < 3 and mode_bowl or mode + 1
end

function init_mode(mode)
	if mode == mode_bowl then
		for i = 1,10 do add_pin() end
		position_pins(pins)
		targets = pins
	elseif mode == mode_breakout then
		create_bricks()
		targets = bricks
	elseif mode == mode_bb then
		hoop={x=57, y=28, h=13, flashtimer=new_timer(10)}
		add_actor({x=hoop.x, y=hoop.y, w=1, h=2, extrabounce=.1}, {fixtures})
		add_actor({x=hoop.x+netw+1, y=hoop.y, w=1, h=2, extrabounce=.1}, {fixtures})
		targets = {fixtures[1], fixtures[2], hoop}
		targetzipy = -19
	elseif mode == mode_bj then
		add_bjbtn(38,9,21,14,19,'hit')
		add_bjbtn(62,18,29,14,24,'stand')
		blackjack_cr = add_cr(run_blackjack)
		targets = bjbtns
		targetzipy = -5
	elseif mode == mode_barber then
		maxtargetoffset = 40
		local x1, y1 = 48, 2
		head={sx=63,sy=0,w=19,h=28,x=x1+7,y=y1+13}
		add(targets, head)
		local hairpos={
			{sx=108,sy=0,w=13,h=3,x=x1+10,y=y1+17},
			{sx=84,sy=12,w=9,h=2,x=x1+12,y=y1+27},
			{sx=101,sy=8,w=3,h=2,x=x1+15,y=y1+31},
			{sx=99,sy=0,w=17,h=12,x=x1+8,y=y1+24},
			{sx=90,sy=0,w=17,h=8,x=x1+8,y=y1+8},
			{sx=73,sy=0,w=33,h=24,x=x1,y=y1},
		}
		for h in all(hairpos) do
			h.scoreval = 1
			h.receive_hit = function(fixture, ball) hit_fixture(ball, fixture) end
			add_actor(h, {vactors, clearables, knockables, targets})
		end
		add(clearables, head)
	elseif mode == mode_breakfast then
		maxtargetoffset = 34
		for i = 1,10 do add_egg() end
		position_pins(eggs)
		targets = eggs
		skillet = {x=49,h=24,t=0,tween=new_tween(-24,64,1,38,ease_out_quad)}
		add(clearables, skillet)
	elseif mode == mode_bird then
		maxtargetoffset = 40
		targetzipy = -5
		for i = 1, 10 do
			add_actor({
				x = 64, y = 10, w = 8, h = 7, s = rnd_int(75, 76), scoreval = -1,
				timer = new_timer(rnd_int(70, 97))
			}, {vactors, sprites, knockables, clearables, targets})
		end
		position_pins(targets)
		music(-1, 1000)
	elseif mode == mode_bro then
		bro = add_actor({
			x = 128, y = 64, w = 32, h = 64, isbro = true,
			receive_hit = function(bro) brointerrupt = true bro.hit = true end
		}, {vactors, knockables})
		add_cr(run_bro)
	elseif mode == mode_boss then
		for i = 1,10 do add(targets, add_pin()) end
		boss = add_actor({
			x = 54, y = 20, w = 24, h = 64, sx = 113, sy = 96, sw = 12, sh = 32,
			extrabounce = .8, hp = 100, shake = 0, t = 0,
			receive_hit = function(f)
				if f.hp > 0 then
					add_score(2)
					f.shake = 2
					f.hp = max(0, f.hp - 4)
					if f.hp == 0 then
						del_actor(boss)
						for i = 1, 580 do
							add_particle(rnd_int(boss.x, boss.x + boss.w - 1), rnd_int(boss.y, boss.y + boss.h - 1), 7)
						end
						music(-1)
						sfx(55)
						f.shake = 4
					else
						sfx(54, 3)
					end
				end
			end
		}, {fixtures, targets})
	end
end

function total_hand(hand)
	local total,acecount = 0,0
	for _, c in pairs(hand) do
		total += min(c.r, 10)
		if c.r == 1 then
			acecount += 1
		end
	end
	for i = 1, acecount do
		if total + 10 <= 21 then
			total += 10
		end
	end
	return total
end

function draw_card(c, x, y, top)
	if c.hidden then
		map(8, 16, x, y, 2, 2)
		return
	end
	local txtx,txty,my
	local tenoffset = (c.r == 10 and 1 or 0)
	local mx = ((c.s - 1) * 2)
	if top then
		my = 16
		txtx = x + 11 - tenoffset
		txty = y + 2
	else
		my = 18
		txtx = x + 4 + tenoffset
		txty = y + 9
	end

	pal(1, 0)
	palt(9, true)
	map(mx, my, x, y, 2, 2)
	pal()

	local col = c.s % 2 == 0 and 8 or 0
	local txt = ranktxt[c.r] or tostr(c.r)
	cprint(txt, txtx, txty, col)
end

function take_card()
	return del(deck, deck[rnd_int(1, #deck)])
end

function give_card(p, hidden)
	local c = add(p.hand, take_card())
	add(bjcardsout, c)
	c.xoffset = 90
	c.hidden = hidden
	p.total = total_hand(p.hand)
	p.bust = p.total > 21
end

function run_blackjack()
	local delay = 12
	repeat
		deck = {}
		for s = 1, 4 do
			for r = 1, 13 do
				add(deck, {s=s, r=r})
			end
		end
		dealer = {hand={}}
		bjplayer = {hand={}}
		bjcardsout = {}
		bjmsg = {}

		while state ~= state_play do yield() end

		for i = 1, 2 do
			give_card(bjplayer)
			wait(delay)
			give_card(dealer, i == 1)
			wait(delay)
		end

		for b in all(bjbtns) do
			b.disabled = false
		end

		local dealerbj = dealer.total == 21
		local playerbj = bjplayer.total == 21

		if dealerbj then
			add(bjmsg, 'dealer has blackjack')
		else
			while not (bjbtns[2].pushed or bjplayer.bust or bjplayer.total == 21
						     or pbstate == pbstate_move_done) do
				if bjbtns[1].pushed then
					give_card(bjplayer)
				end
				yield()
			end
		end

		for b in all(bjbtns) do
			b.disabled = true
		end
		wait(delay)
		dealer.hand[1].hidden = false

		if bjplayer.bust then
			add(bjmsg, 'bust')
		elseif not playerbj then
			while dealer.total <= 16 do
				wait(delay)
				give_card(dealer)
			end
		end
		wait(delay)

		if not dealer.bust then
			if dealer.total > bjplayer.total or bjplayer.bust then
				dealer.win = true
				add(bjmsg, 'dealer wins')
			end
		end

		if not bjplayer.bust then
			if dealer.bust then
				add(bjmsg, 'dealer busts')
			end

			if bjplayer.total > dealer.total or dealer.bust then
				if playerbj then
					add(bjmsg, 'blackjack')
				end
				bjplayer.win = true
				add(bjmsg, 'you win')
				add(bjmsg, bjplayer.total .. ' points')
				add_score(bjplayer.total)
			elseif bjplayer.total == dealer.total then
				bjmsg = {'push'}
			end
		end

		for i = 1, 120 do
			if i % 10 == 0 then
				bjflash = not bjflash
			end
			yield()
		end
		bjplayer.done = true
		dealer.done = true

		for c in all(bjcardsout) do
			c.done = true
			wait(delay)
		end
		wait(60)
	until pbstate == pbstate_move_done
	bjmsg = {}
end

function run_bro()
	repeat yield() until pbstate == pbstate_present
	tween_move(bro, 'x', 128, 95, 30, ease_out_quad)
	local lines = {
		"hi! i'm alfonzo's brother, alonzo!",
		"hey, aren't you jonsey's kid?",
	}
	while true do
		for s in all(lines) do
			if say(s, nil, true) then
				return
			end
		end
		lines = {
			"you seem like you'd get along great with hobart. i'll introduce you!",
			"have you met bridget? she's the one they call the turkey.",
			"fredericka works at the pro shop. she can give you a discount!",
			"stay away from gustav. they don't call him gutterball for nothing!",
			"i heard jimmy bowled a dutch 200 last week!",
			"i can introduce you to darius if you come to scimone's wedding.",
		}
		shuffle(lines)
	end
end

function add_score(n)
	score += n
	totalscore += n
end

function receive_hit_egg(e)
	e.s = 33
	add_actor({
		x = e.x, y = e.y, s = 79, offset = e.offset, w = 8, h = 8,
		vx = -e.vx + rnd_vel(1), vy = e.vy + rnd_vel(1)
	}, {vactors, sprites, clearables})
	add_actor({
		x = e.x, y = e.y, s = 38, gravity = .03,
		offset = {x = -2, y = -1},
		w = 5, h = 6,
	}, {yolks, vactors, sprites, clearables})
end

function add_egg()
	add_actor({
		w = 4, h = 5, s = 34,
		offset = {x = -2, y = -3},
		scoreval = 0,
		receive_hit = receive_hit_egg
	}, {vactors, eggs, knockables, sprites})
end

function run_pinbot()
	while true do
		while state ~= state_coach do yield() end

		local vy = 0
		repeat
			vy -= .1
			for _, a in pairs(clearables) do
				a.y += vy
			end
			yield()
		until all_offscreen(clearables)
		for a in all(actors) do
			if not a.isball then
				del_actor(a)
			end
		end
		clearables = {}

		while state ~= state_pinbot do yield() end
		pbstate = nil

		score = 0
		mode = choose_mode()
		level += 1
		targets = {}
		maxtargetoffset = 75
		targetzipy = nil

		init_mode(mode)
		maxscore = #targets
		pbstate = pbstate_present
		present(targets)

		if state == state_play then
			pbstate = pbstate_present_done
			repeat yield() until (state == state_play and playercount > 0)
					 or state == state_pinbot
			pbstate = pbstate_move
			if mode == mode_boss then
				repeat yield() until boss.hp == 0
			else
				move_targets()
			end
		end
		pbstate = pbstate_move_done
	end
end

function run_platforms()
	repeat yield() until state == state_play and playercount > 0

	local p, p2 = platforms[1], platforms[2]

	repeat
		p.y += .1
		yield()
	until flr(p.y) == 128
	p.enabled = true

	repeat
		local y2 = p.oy + (p.oy - p.y)
		yield()
	until flr(y2) == p2.y
	p2.enabled = true
end

function add_bjbtn(x, y, w, h, mx, txt)
	add_actor({
		x = x, y = y, w = w, h = h, mx = mx,
		extrabounce = .5,
		txt = txt,
		isbjbtn = true,
		pushtimer = new_timer(4),
		disabled = true,
		receive_hit = function(f)
			if not f.disabled then
				sfx(57)
				f.pushed = true
				f.pushtimer.reset()
			end
		end
	}, {bjbtns, fixtures})
end

function add_cr(f)
	return add(coroutines, cocreate(f))
end

function create_bricks()
	local c, row = {8,9,11,10}, 1
	for y = 0, 28, 4 do
		for x = 0, 55, 12 do
			add_brick(35 + x, 8 + y, c[flr(row)])
		end
		row += .5
	end
end

function add_brick(x, y, c)
	add_actor({
		x = x, y = y, w = 10, h = 3, c = c, extrabounce = .05,
		receive_hit = function(f)
			del_actor(f)
			sfx(62, 3, 24, 1)
			add_score(1)
		end
	}, {vactors, bricks, fixtures})
end

function present(targets)
	for a in all(targets) do
		a.origy = a.y
		a.botmoving = true
	end

	local maxy = 0
	for a in all(targets) do
		maxy = max(a.y + a.h - 1, maxy)
	end

	local t = new_tween(-maxy - 2, 0, 1, 40, ease_out_quad)
	for ticks = 1, 40 do
		local offset = t.update(ticks)

		for _, p in pairs(targets) do
			p.y = p.origy + offset
		end
		yield()
	end

	for a in all(targets) do
		a.origy = nil
		a.botmoving = false
	end
end

function move_targets()
	local vy, offset = .075, {x = 0, y = 0}

	if level < 3 then
		vy = 0
	elseif level == 3 then
		vy = 0.09
	elseif mode == mode_bb or mode == mode_bj then
		vy = .05
	end

	repeat
		if offset.y >= maxtargetoffset then
			vy = -abs(vy)
		end

		if targetzipy then
			if vy < 0 and offset.y < targetzipy then
				vy -= .1
			end
		elseif offset.y <= 0 then
			vy = abs(vy)
		end

		offset.y += vy

		for _, t in pairs(targets) do
			if not t.isknocked then
				t.y += vy
			end
		end

		while playercount == 0 do yield() end
		yield()
	until state ~= state_play or all_offscreen(targets)
end

function all_offscreen(t)
	for _, a in pairs(t) do
		if a.y + a.h > 0 then
			return false
		end
	end
	return true
end

function gc_actor(a)
	if not a.botmoving then
		if a.y + a.h < 0 or a.y > 128 or a.x + a.w < 0 or a.x > 128 then
			del_actor(a)
		end
	end
end

function del_actor(a)
	for _, t in pairs(a.tables) do
		del(t, a)
	end
	del(targets, a)
	del(knockers, a)
end

function update_ball_anim(b)
	b.rot += (b.v.x * .2)
	b.rot %= 4
	b.s = 3 + b.rot
end

function _update60()
	update_btnp()
	update_input()

	for c in all(coroutines) do
		if costatus(c) == 'dead' then
			del(coroutines, c)
		else
			assert(coresume(c))
		end
	end

	if mode == mode_bj then
		for _, b in pairs(bjbtns) do
			b.pushed = false
		end
	elseif mode == mode_boss and state == state_play then
		boss.t += .0167
		boss.x = 54 + (sin(boss.t * .4) * 5)
		if pbstate == pbstate_move then
			boss.y = 20 + (cos(boss.t * .3) * 4)
		end
		boss.shake = max(0, boss.shake - .1)
		for p in all(pins) do
			if not p.isknocked then
				p.x = boss.x+boss.w/2+sin(t()/2+p.i/10)*45
				p.y = -4+boss.y+boss.h/2+cos(t()/2+p.i/10)*45
			end
		end
	end

	for _, a in pairs(actors) do a.framehit = false end
	update_physics()
	update_particles()
	foreach(balls, update_ball_anim)

	if mode == mode_bb and hoop then
		update_hoop()
	elseif mode == mode_bj then
		for _, c in pairs(bjcardsout) do
			if c.done then
				c.xoffset -= (1 + abs(c.xoffset))
				c.xoffset = max(-128, c.xoffset)
			else
				c.xoffset -= (c.xoffset / 4)
			end
		end
		for _, b in pairs(bjbtns) do
			b.pushtimer.update()
		end
	elseif mode == mode_breakfast then
		update_breakfast()
	elseif mode == mode_bird then
		for i, b in pairs(targets) do
			if b.timer.update() then
				b.timer = new_timer(rnd_int(70, 97))
				b.s = rnd_int(75, 76)
				if i == 1 and rnd(1) > .5 then
					sfx(5, -1, rnd_int(0, 3) * 8, 8)
				end
			end
		end
	end

	bgoffset += .1667
	bgoffset %= 128

	message.timer.update()
	pitimer.update()
	update_state()
end

function update_hoop()
	for _, b in pairs(balls) do
		if b.pos.x + ballr >= hoop.x + 1 and b.pos.x - ballr <= hoop.x + netw then
			if b.bbstate == 0 then
				b.bbstate = 1
			end
		else
			b.bbstate = 0
		end

		if b.bbstate == 1 and b.pos.y + ballr - 1 <= hoop.y then
			b.bbstate = 2
		end

		if b.bbstate == 2 and b.pos.y - ballr >= hoop.y then
			sfx(58, 1)
			add_score(2)
			b.bbstate = 0
			hoop.flash = true
			hoop.flashtimer.reset()
		end
	end

	if hoop.flashtimer.update() then
		hoop.flash = false
	end
end

function play_hit_sfx(actor, v, edge)
	if (abs(v) < 0.3) return
	if mode == mode_breakout then
		sfx(62, 2, edge and 25 or 26, 1)
	elseif edge then
		sfx(63, 2, 0, 1)
	end
end

function rnd_vel(n, m)
	local v = rnd_int(m or 1, n) / 10
	if rnd_int(0, 1) == 0 then
		v = -v
	end
	return v
end

function add_particle(x, y, c)
	add(particles, {x=x, y=y, c=c, vx=rnd_vel(30), vy=rnd_vel(30), gravity=.03})
end

function update_particles()
	for _, p in pairs(particles) do
		move_vactor(p)
		if p.y > 128 then
			del(particles, p)
		end
	end
end

function draw_sprite(s)
	local offset = s.offset or {x = 0, y = 0}
	spr(s.s, flr(s.x + offset.x), flr(s.y + offset.y), 1, 1, s.flip)
end

function draw_panegg(s)
	clip(pan.x, pan.y, pan.w, pan.h)
	camera(-pan.x, 0)
	draw_sprite(s)
	camera()
	clip()
end

function draw_hoop(h)
	local x1, y1, x2, y2 = h.x - 15, h.y - 25, h.x + netw + 16, h.y + 2
	rect(x1, y1, x2, y2, 6)
	fillp(4680.5)
	rectfill(x1, y1, x2, y2, 6)
	fillp()

	if h.flash then
		pal(7, 10)
	end
	sspr(32, 32, 20, 19, h.x - 3, h.y - 14)
	pal()
end

function draw_bj_cards()
	local x, y = 77, 0
	for c in all(dealer.hand) do
		draw_card(c, x - c.xoffset, y, true)
		x -= 9
	end

	x, y = 38, 112
	for c in all(bjplayer.hand) do
		draw_card(c, x + c.xoffset, y)
		x += 9
	end
end

function draw_bj_txt()
	if #dealer.hand >= 2 and not dealer.hand[1].hidden and not dealer.done then
		if bjflash or not dealer.win then
			cprint(dealer.total, 64, 11, 1, dealer.bust and 8 or 11)
		end
	end

	for i, msg in pairs(bjmsg) do
		cprint(msg, 64, 27 + (i * 8), 1, 10)
	end

	if #bjplayer.hand > 1 and bjplayer.hand[2].xoffset < 1
			and not bjplayer.done then
		if bjflash or not bjplayer.win then
			cprint(bjplayer.total, 64, 112, 1, bjplayer.bust and 8 or 11)
		end
	end
end

function draw_bjbtn(b)
 	local pushed = not b.pushtimer.is_done()

	if b.disabled then
		palt(1, true)
	else
		pal(1, 0)
	end

	if pushed then
		pal(7, 5)
		pal(5, 7)
	end

	map(b.mx, 1, b.x - 7, b.y, 5, 2)
	pal()

	cprint(b.txt, b.x + (b.w / 2) + (pushed and 1 or 0), b.y + (b.h / 2) - 3 + (pushed and 1 or 0), b.disabled and 13 or 0)
end

function coach_leave()
	tween_move(coach, 'x', 14, -32, 26, ease_out_quad)
end

function run_coach()
	while true do
		repeat yield() until state == state_coach

		coach.face = 1
		if level == 1 or level == 2 then
			coach.face = 2
		elseif level == 3 then
			coach.face = 5
		elseif nextmode == mode_bj then
			coach.face = 6
		elseif mode == mode_bird then
			coach.face = score < 0 and 5 or 2
		elseif mode == mode_boss then
			coach.face = 10
		end

		local nextmode, visible = choose_mode(), true
		if nextmode == mode_breakout or nextmode == mode_bb then
			visible = false
		end

		if visible then
			tween_move(coach, 'x', -32, 14, 40, ease_out_quad)
			wait(15)
		end

		if mode == mode_boss then
			say("you...you did it!", 10)
			say("you have avenged my father alfredo's death!")
			wait(30)
			coach.face = 11
			wait(20)

			music(30, 0, 15)
			wait(10)
			tearf = 0
			coach.tearx = 18
			coach.teary = 13
			local vy = 0
			while coach.teary < 384 do
				vy+=.007
				coach.teary += vy
				if coach.teary >= 14 then
					coach.tearx = 19
				end
				tearf+=1
				yield()
			end
			coach.teary = nil

			say("anyway, congratulations!", 1)
			say("we've decided to invite you to join our league!")
			say("practice is on tuesday nights!")
			say("see you then!")
			state = state_credits
			mode = nil
			creditsy = 0
			show_title('bowling', 'credits')
			add_cr(function() wait(100) coach.face = 3 wait(20) coach_leave() end)
			run_credits()
			message.txt = 'thanks for playing!'
			message.timer.reset()
			sfx(61, 3)
			state = state_end
			title = nil
			return
		end

		if level == 1 then
			say("wow! a strike on your first try!")
		elseif level == 2 then
			say("amazing!", 2)
		elseif level == 3 then
			say("incredible!", 5)
			say("it's been a long time since i've seen a newcomer bowl at this level.", 8)
			say("we've got to start your training right away!", 4)
		elseif mode == mode_bird then
			if score >= 0 then
				say("wow! you're a natural@@ist!")
			else
				say("you scared them away!", 5)
			end
		elseif mode == mode_bro then
			say("i think you made an impression on him!", 2)
		end

		if level == 2 then
			say("hey kid, i think you may have some potential!", 7)
			say("let's see how you handle something a little different...", 6)
		elseif nextmode == mode_bj then
		 	say("good.", 6)
		 	say("in a real tournament, however...", 1)
			say("things aren't always so predictable.")
		 	say("but you still have to play the hand you're dealt!", 9)
		elseif nextmode == mode_bird then
			say("a *true* bowler is patient...", 6)
			say("observant...", 12)
			say("study each pin!", 9)
		elseif nextmode == mode_bro then
			say("i'm going to let you in on a little secret, kid.", 6)
			say("it's not how you throw, but who you know.")
			say("i'm talking about networking!", 2)
			say("here, let me introduce you to my brother! he knows everyone!")
		elseif nextmode == mode_barber then
			say("unfortunately, even with the best connections...", 6)
			say("bowling doesn't always pay the bills.")
			say("time to practice for your side-hustle!", 9)
		elseif nextmode == mode_boss then
			say("you're almost ready.")
			say("there's just one last--")
			music(-1)
			say("oh no...", 5)
			say("i didn't think she was going to come back this soon...")
			say("run for your life!!!!!!", 10)
			music(15)
		end

		coachstate = coachstate_title
		local pause = {}
		if level >= 3 and level <= 5 then
			 add_cr(function() show_title(b_words[mode], nil, pause) end)
		else
			 add_cr(function() show_title(b_words[nextmode]) end)
		end

		local erase_and_type = function(a, b, c)
			wait(a)
			erase_title(b)
			wait(15)
			type_title(b_words[nextmode], c)
			wait(120)
			pause.done = true
			wait(30)
		end

		if level == 2 then
			wait(60)
			coach_leave()
			wait(160)
		elseif level == 3 then
			wait(30)
			coach.face = 6
			wait(30)
			coach_leave()
			erase_and_type(15, 6, 2)
		elseif level == 4 then
			erase_and_type(75, 4, 6)
		elseif level == 5 then
			erase_and_type(75, 7, 2)
		elseif nextmode == mode_boss then
			wait(50)
			coach_leave()
			wait(160)
		else
			wait(34)
			coach.face = level > 1 and 3 or 2
			wait(170)
			if visible then
				coach_leave()
			end
			wait(16)
		end

		coachstate = coachstate_done
		repeat yield() until state == state_play
		coachstate = coachstate_wait
	end
end

function erase_title(n)
	local txt = title.word2
	for i = #txt - 1, #txt - n, -1 do
		title.word2 = sub(txt, 1, i)
		sfx(62, -1, 0, 2)
		wait(8)
	end
end

function type_title(txt, start)
	for i = start, #txt do
		title.word2 = sub(txt, 1, i)
		sfx(53)
		wait(10 + rnd_int(1, 5))
	end
end

function run_credits()
	for y = 0, 288 do
		creditsy = y
		wait(8)
	end
end

function draw_credits()
	clip(36, 0, 57, 120)
	for i, c in pairs(credits) do
		cprint(c, 64, 113 + (i * 8), 8, 7)
	end
	clip()
end

function show_title(word2, word3, pause)
	title = {word2 = word2, word3 = word3 or 'challenge'}
	tween_move(title, 'x', -36, 64, 44, ease_out_quad)
	if state == state_credits then
		wait(60)
		music(23)
		return
	end
	if pause then
		repeat yield() until pause.done
	else
		wait(180)
	end
	tween_move(title, 'x', 64, 164, 30, ease_in_quad)
	title = nil
end

function say(txt, face, isbro)
	dialog = {
		txt = wrap(txt, 19),
		len = 0,
		isbro = isbro
	}
	if face then
		coach.face = face
	end

	local skip,sfxframe = false,0
	for i = 1, #txt do
		local c,delay = sub(txt, i, i),2
		if c == ',' then
			delay = 10
		elseif c == '@' or c == '.' or c == '!' then
			delay = 20
		end

		if c ~= '@' then
			dialog.len += 1
			if sfxframe >= 4 then
				sfxframe = 0
				sfx(53, 2)
			end
		end

		for j = 1, delay do
			sfxframe += 1
			yield()

			if btnp_any(4) or (isbro and brointerrupt) then
				skip = true
				dialog.len = #dialog.txt
				break
			end
		end
		if skip then
			break
		end
	end

	if not (isbro and brointerrupt) then
		promptvisible = true
		local i = 0
		repeat
			i += 1
			promptoffset = (i % 60) < 30 and 0 or 1
			yield()
		until btnp_any(4) or (isbro and brointerrupt)
		promptvisible = false
	end

	dialog = nil
	if brointerrupt then
		brointerrupt = false
		return true
	elseif isbro and score < 10 then
		add_score(1)
	end
end

function draw_dialog()
	local d = dialog
	if (not d) return

	local w, h = 81, 29
	local x = d.isbro and bro.x - 84 or coach.x + 28
	local y = coach.y - 15
	local x2, y2 = x + w - 1, y + h - 1

	map(8, 3, x - 1, y - 1, 11, 4)
	print(sub(d.txt, 1, d.len), x + 3, y + 3, 7)
	palt(1, true)
	if d.isbro then
		spr(7, x + w - 4, y + h, 1, 1, true)
	else
		spr(7, x - 2, y + h)
	end
	palt()

	if promptvisible then
		sspr(32, 24, 3, 4, x + w - 7, y2)
		print('🅾️', x + w - 9, y + h - 2 + promptoffset, 7)
	end
end

function font_i(chr)
	for i = 1, #font do
		if sub(font, i, i) == chr then
			return i
		end
	end
end

function font_xy(chr)
	local i = font_i(chr) - 1
	return 64 + ((i % 8) * 8), 64 + (flr(i / 8) * 8)
end

function bigprint(s, x, y)
	for i = 1, #s do
		y += (i % 2 == 0 and 1 or -1)
		rectfill(x - 2, y - 2, x + 6, y + 13, i % 2 == 0 and 9 or 12)
		local sx, sy = font_xy(sub(s, i, i))
		sspr(sx, sy, 5, 6, x, y, 5, 12)
		x += 9
	end
end

function draw_title()
	fillp(20158)
	for w = 39, 0, -1 do
		local y = 138 - title.x - w
		rectfill(64 - w, y, 64 + w, y, 0x31)
	end
	fillp()

	bigprint(title.word2, 67 - #title.word2 * 4.5, title.x - 18, 7)
	cprint(title.word3, 128 - title.x, 63, 8, 7)
	sspr(72, 43, 56, 21, title.x - 28, 23)
end

function draw_alfonzo()
	local x, w, f = 0, 32, faces[coach.face]

	palt(1, true)
	palt(0, false)
	sspr(x, 64, w, 64, coach.x, coach.y)
	sspr(f[1], f[2], 9, 11, coach.x + 11, coach.y + 8)

	if coach.teary then
		pset(coach.x+coach.tearx, coach.y+coach.teary, tearf % 8 < 4 and 7 or 12)
	end
	palt()
end

function sspr_sym(s)
	local sw = s.w / 2
	sspr(s.sx, s.sy, ceil(sw), s.h, s.x, s.y)
	sspr(s.sx, s.sy, flr(sw), s.h, s.x + ceil(sw), s.y, flr(sw), s.h, true)
end

function update_breakfast()
	if not skillet.tween.is_done() then
		skillet.t += 1
		skillet.y = skillet.tween.update(skillet.t)
	end
	skillet.x = flr(49 + (sin(t() / 2.9) * 17))
	pan = {
		x = skillet.x + 4,
		y = skillet.y + 12,
		w = 23,
		h = 6
	}
	local panhitbox = {
		x = pan.x + 4,
		y = pan.y + pan.h + 1,
		w = pan.w - 8,
		h = 1
	}

	for _, yolk in pairs(yolks) do
		if overlap(yolk, panhitbox) then
			del_actor(yolk)
			add_actor({
				x = yolk.x - pan.x, y = flr(yolk.y) + rnd_int(-1, 1),
				s = 21, offset = {x = -1, y = -2},
				w = 7, h = 4,
			}, {paneggs, clearables})
			add_score(1)
			sfx(56, 3)
		end
	end
end

function draw_tutorial()
	if (playercount == 0 or not tutorialon) return

	if tutorial.vy == 0 then
		for b in all(balls) do
			if b.pos.y < 100 then
				tutorial.vy = 0.1
			end
		end
	end

	tutorial.y += tutorial.vy
	local y = tutorial.y
	if (tutorial.vy == 0) y += cos(t()) / 2
	print('⬅️', 39, y, btn(0) and 10 or 7)
	print('➡️', 83, y, btn(1) and 10 or 7)

	if (tutorial.y > 127) tutorialon = false
	if (tutorial.vy > 0) tutorial.vy += .04
end

function get_boss_shake()
	return rnd_int(-boss.shake, boss.shake)
end

function _draw()
	if boss and boss.hp == 0 then
		camera(get_boss_shake(), get_boss_shake())
	end
	map(32, 0, 0, bgoffset - 128, 16, 32)
	map(0, 0, 36, 0, 8, 16)
	for p in all(platforms) do
		map(8, 0, p.x, p.y - 8, 4, 2)
	end

	if mode == mode_breakout then
		for b in all(bricks) do
			pal(9, b.c)
			spr(35, b.x, b.y, 2, 1)
			pal()
		end
	elseif mode == mode_bb and hoop then
		draw_hoop(hoop)
	elseif mode == mode_bj and #bjbtns > 0 then
		foreach(bjbtns, draw_bjbtn)
		draw_bj_cards()
	elseif mode == mode_barber then
		palt(0, false)
		palt(1, true)
		sspr_sym(head)
		foreach(targets, sspr_sym)
		palt()
	elseif mode == mode_breakfast then
		palt(1, true)
		spr(27, skillet.x, skillet.y, 5, 3)
		palt()
		foreach(paneggs, draw_panegg)
		sspr(32, 87, 25, 9, skillet.x + 3, skillet.y + 14)
	elseif mode == mode_boss and boss.hp > 0 then
		local b = boss
		sspr(b.sx, b.sy, b.sw, b.sh, b.x+get_boss_shake(), b.y+get_boss_shake(), b.w, b.h)
	elseif mode == mode_bro then
		palt(1, true)
		palt(0, false)
		pal(2, 5)
		pal(4, 0)
		pal(14, 10)
		pal(8, 3)
		sspr(0, 64, 32, 64, bro.x, bro.y, 32, 64, true)
		pal()
	end

	foreach(sprites, draw_sprite)
	for b in all(balls) do
		pal(1, 0)
		pal(12, b.c)
		if not pitimer.is_done() then
			cprint('p' .. b.pi, b.pos.x, b.pos.y - ballr - 8, b.c, 1)
		end
		spr(b.s, b.pos.x - ballr, b.pos.y - ballr)
		pal()
	end

	if mode == mode_bb and hoop then
		sspr(56, 32, 14, 14, hoop.x, hoop.y)
	end

	for p in all(particles) do
		pset(p.x, p.y, p.c)
	end

	if (level > 0) bprint('frame ' .. level, 2, 2, 10, 1)
	rprint(totalscore, 126, 2, 10, 1)

	if mode == mode_boss then
		rectfill(38, 4, 38 + ((boss.hp / 100) * 51), 5, 8)
		rect(38, 3, 90, 6, 7)
	end

	if state == state_credits then
		camera(0, creditsy)
		draw_credits()
	end
	if (title) draw_title()
	camera()

	draw_alfonzo()
	draw_dialog()
	if (mode == mode_bj) draw_bj_txt()
	if state ~= state_coach and playercount == 0 or not message.timer.is_done() then
		rectfill(0, 56, 127, 64, 8)
		cprint(playercount == 0 and 'press 🅾️ to join' or message.txt, 64, 58, 7)
	end

	draw_tutorial()

	if state == state_end then
		music(-1)
		while true do
			local p=add_pin()
			p.x,p.y=rnd_int(0,120),rnd_int(0,50)
			p.gravity,p.vx=.1,rnd_vel(8,3)
			repeat
				move_vactor(p)
				if p.y>=120 then
					p.y,p.vy=120,-p.vy*.7
				end
				draw_sprite(p) flip()
			until p.x > 128 or p.x < 0
			del_actor(p)
		end
	end
end

ballr = 4
ballr2 = ballr * 2

function bounce_axis(b, axis, hitpoint, extrabounce)
	b.pos[axis] = hitpoint
	b.prev[axis] = hitpoint + (b.v[axis] * (b.bounce + (extrabounce or 0)))
end

function circ_rect_overlap(c, r)
	local distx = abs(c.pos.x - r.x - (r.w / 2))
	local disty = abs(c.pos.y - r.y - (r.h / 2))

	if distx > (r.w / 2) + c.r or disty > (r.h / 2) + c.r then
		return false
	end
	if distx <= r.w / 2 or disty <= r.h / 2 then
		return true
	end

	local dx = distx - (r.w / 2)
	local dy = disty - (r.h / 2)
	return (dx * dx) + (dy * dy) <= c.r * c.r
end

function collide_with_knockables(a)
	local hit = false

	for _, k in pairs(knockables) do
		if k ~= a and a:overlap(k) then
			del(knockables, k)
			k.isknocked = true

			local knockv = a:get_knock_velocity()
			k.vx = knockv.x + rnd_vel(1)
			k.vy = knockv.y + rnd_vel(1)
			if (abs(k.vx) < .5) k.vx = k.vx < 0 and -.5 or .5
			if (abs(k.vy) < .5) k.vy = k.vy < 0 and -.5 or .5

			if k.receive_hit then
				k:receive_hit(a)
			end
			if k.scoreval then
				add_score(k.scoreval)
			end

			hit = true
			sfx(62, 1, 0, 2)
		end
	end

	if hit then
		if a.knock_slowdown then
		  a:knock_slowdown()
		else
		  a.vy += (-a.vy / 3)
		  a.vx += (-a.vx / 3)
		end
	end
end

function hit_fixture(b, f)
	local nearestx = max(f.x, min(b.pos.x, f.x + f.w))
	local nearesty = max(f.y, min(b.pos.y, f.y + f.h))
	local diff = vec2.new(b.pos.x - nearestx, b.pos.y - nearesty)
	local pendepth = diff:mag() - ballr
	local penv = diff:normalized() * pendepth
	local pos = b.pos - penv

	if nearestx == b.pos.x then
		bounce_axis(b, 'y', pos.y, f.extrabounce)
	elseif nearesty == b.pos.y then
		bounce_axis(b, 'x', pos.x, f.extrabounce)
	else
		b.pos = pos
	end
end

function constrain_to_fixtures(b)
	local hit
	for _, f in pairs(fixtures) do
		if circ_rect_overlap(b, f) then
			hit_fixture(b, f)
			if f.receive_hit and not f.framehit then
				f:receive_hit(b)
				f.framehit = true
			end
			hit = true
		end
	end
	return hit
end

function constrain_to_platforms(b)
	for _, p in pairs(platforms) do
		if p.enabled then
			if (p.vy <= 0 and b.prev.y <= p.y) or b.prev.y + ballr <= p.y then
				if circ_rect_overlap(b, p) then
					b.pos.y = p.y - ballr
					play_hit_sfx(b, b.v.y - p.vy)
				end
			end
		end
	end
end

function constrain_to_screen(b)
	local minval, maxval, hit = ballr, 128 - ballr

	for _, axis in pairs({'x', 'y'}) do
		if b.pos[axis] < minval then
			bounce_axis(b, axis, minval)
			play_hit_sfx(b, b.v[axis], true)
			hit = true
		elseif b.pos[axis] > maxval then
			bounce_axis(b, axis, maxval)
			play_hit_sfx(b, b.v[axis], true)
			hit = true
		end
	end
	return hit
end

function move_vactor(a)
	if a.gravity then
		a.vy += a.gravity
	end
	if a.friction then
		a.vx *= a.friction
	end
	a.x += a.vx
	a.y += a.vy
end

function overlap(a, b)
	return a.x + a.w > b.x and a.x < b.x + b.w and a.y + a.h > b.y and a.y < b.y + b.h
end

function resolve_ball_collisions()
	local moved
	local r2sq = ballr2 * ballr2
	for i = 1, #balls do
		for j = i + 1, #balls do
			local a = balls[i]
			local b = balls[j]
			local diff = b.pos - a.pos

			if diff:magsq() < r2sq then
				local offset = diff - diff:normalized(ballr2)
				a.pos += offset
				b.pos -= offset
				moved = true
			end
		end
	end
	return moved
end

function update_physics()
	for _, b in pairs(balls) do
		verlet(b)
		b.pos.y += b.gravity
	end
	foreach(vactors, move_vactor)
	update_platforms()

	for i = 1, 5 do
		local moved = resolve_ball_collisions()

		for _, b in pairs(balls) do
			for func in all(ball_constraints) do
				if func(b) then
					moved = true
				end
			end
		end

		if not moved then
			break
		end
	end

	foreach(knockers, collide_with_knockables)
	foreach(vactors, gc_actor)
end

function update_platforms()
	local p = platforms[1]
	if p.enabled then
		local d = (p.oy - p.y) * .003
		p.vy += d
		p.y += p.vy
	end

	local p2 = platforms[2]
	if p2.enabled then
		p2.y = p.oy + (p.oy - p.y)
		p2.vy = -p.vy
	end
end

function verlet(b)
	local c = b.pos:copy()
	b.v = b.pos - b.prev
	b.v:limit(ballr2)
	if b.framefriction then
		b.v *= b.framefriction
		b.framefriction = nil
	end
	b.pos = b.pos + b.v
	b.prev = c
end

ball_constraints = {
	constrain_to_fixtures,
	constrain_to_platforms,
	constrain_to_screen
}

vec2={}
vec2.__index=vec2
vec2.__add=function(a,b)
	if type(a)=='number' then
		return vec2.new(a+b.x, a+b.y)
	elseif type(b)=='number' then
		return vec2.new(a.x+b, a.y+b)
	else
		return vec2.new(a.x+b.x, a.y+b.y)
	end
end
vec2.__sub=function(a,b)
	if type(a)=='number' then
		return vec2.new(a-b.x, a-b.y)
	elseif type(b)=='number' then
		return vec2.new(a.x-b, a.y-b)
	else
		return vec2.new(a.x-b.x, a.y-b.y)
	end
end
vec2.__mul=function(a,b)
	if type(a) == 'number' then
		return vec2.new(a * b.x, a * b.y)
	elseif type(b) == 'number' then
		return vec2.new(a.x*b, a.y*b)
	else
		return vec2.new(a.x*b.x, a.y*b.y)
	end
end
function vec2.new(x,y)
	return setmetatable({x=x,y=y},vec2)
end
function vec2:magsq()
	return (self.x*self.x) + (self.y*self.y)
end
function vec2:mag()
	return sqrt(self:magsq())
end
function vec2:copy()
	return vec2.new(self.x, self.y)
end
function vec2:norm(n)
	local n = n or 1
	local m = self:mag()
	if m~=0 then
		self.x=(self.x/m)*n
		self.y=(self.y/m)*n
	end
end
function vec2:normalized(n)
	local v=self:copy()
	v:norm(n)
	return v
end
function vec2:limit(mag)
	if self:magsq()>mag*mag then
		self:norm(mag)
	end
end

btnps={}
for b=0,5 do btnps[b]={}end
function btnp(b, p)return btnps[b][p or 0]==1 end
function update_btnp()
	for b=0,5 do
		for p=0,7 do
			local s=btnps[b][p]
			if btn(b,p)then
				if (s<2)s+=1
			else
				s=0
			end
			btnps[b][p]=s
		end
	end
end

function new_timer(len)
	local v = len
	return {
		expire = function() v = 1 end,
		get_value = function() return v end,
		is_done = function() return v == 1 end,
		reset = function() v = len end,
		update = function()
			if v>1 then
				v-=1
			else
				return true
			end
		end
	}
end

function new_tween(src, dst, ticksrc, tickdst, func)
	local ticktotal, v = tickdst-ticksrc, src
	return {
		is_done = function() return v == dst end,
		update = function(ticks)
			ticks = mid(0, ticks-ticksrc, ticktotal)
			v = func(ticks, src, dst-src, ticktotal)
			return v
		end
	}
end
function ease_in_quad(t, b, c, d)
  t=t/d
  return c*(t^2)+b
end
function ease_out_quad(t, b, c, d)
	t=t/d
	return -c*t*(t-2)+b
end
function tween_move(actor, axis, src, dst, frames, easefunc)
	local t = new_tween(src, dst, 1, frames, easefunc)
	for f = 1, frames do
		local v = t.update(f)
		actor[axis] = v
		yield()
	end
end

function txtw(txt)
	txt=tostr(txt)
	local w=0
	for i=1,#txt do
		if sub(txt,i,i)=='🅾️' then
			w+=8
		else
			w+=4
		end
	end
	return max(0,w-1)
end
function cprint(s,x,y,c,b)
	bprint(s,x-flr(txtw(s)/2),y,c,b)
end
function bprint(s,x,y,c,b)
	if b then
		for yo=-1,1 do
			for xo=-1,1 do
				if not (yo==0 and xo==0) then
					print(s,x+xo,y+yo,b)
				end
			end
		end
	end
	print(s,x,y,c)
end
function rprint(s,x,y,c,b)
	bprint(s,x-txtw(s),y,c,b)
end
function rnd_int(a,b)
	return flr(rnd((b+1)-a))+a
end
function shuffle(t)
	for i=#t,1,-1 do
		local j=flr(rnd(i))+1
		t[i],t[j]=t[j],t[i]
	end
end
function wait(n)
	for i=1,n do yield() end
end
function wrap(s,w)
	if #s<=w then
		return s,1
	end
	local new,s2='',''
	for i=1,#s do
		local c=sub(s,i,i)
		if c~='@' then
			s2=s2..c
		end
	end
	s=s2
	local a,b=1,w+1
	while b>a do
		local c=sub(s,b,b)
		if c==' ' or c=='\n' then
			new=new..sub(s,a,b-1)..'\n'
			a=b+1
			b=a+w
		else
			b-=1
		end
		if b>#s then
			b=#s
			new=new..sub(s,a)
			break
		end
	end
	return new
end

