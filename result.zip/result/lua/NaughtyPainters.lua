-- naughty painters 1.2
-- by ryosuke mihara

-- settings
num_players=3
scr_lines=64
bg_addr=0x1000
ddeg=8
pc_spd=1.25
pc_acc=1.5
pc_br=0.8
count_dist=8
clock_x=64-7
clock_y=64-6
ss_mode=false
--
t=0
t_max=2048
actors={}
items={}
time=2
match_time=30
phase=-1
cnt=0
winner=0
shake=0
glitch=0
cam={}
cam.x=0
cam.y=0
freeze=0
fxs={}
objx=16
objy=32
ptcls={}
--

function init_game()
	fxs={}
	ptcls={}
	actors={}
	items={}
	winner=0
	time=match_time
	add_actor(2*8+4,2*8+4,11,0)
	add_actor(128-2*8-4,128-2*8-4,8,0)
	add_actor(2*8+4,128-2*8-4,9,1)
	add_actor(128-2*8-4,2*8+4,7,tag_bot)
end

function count_cols(cols,dist)
	local outs={}
	local pix
	outs={0,0,0,0}--todo
	for y=0,127,dist do
		for x=0,127,dist do
			pix=pget(x,y)
			for i=1,count(cols),1 do
				if pix==cols[i] then outs[i]=outs[i]+1 end
			end
		end
	end
	return outs
end

-- bg drawings

function init_bg()
	memset(bg_addr,0x0077,128*64)
end

--

function create_obj(x,y)
	local obj={}
	obj.x=x
	obj.y=y
	obj.w=8
	obj.h=8
	obj.vx=0
	obj.vy=0
	return obj
end

function add_fx(x,y,r,col)
	local fx=create_obj(x,y)
	fx.r=r
	fx.cr=0
	fx.col=col
	fx.dr=fx.r/4
	fx.t=0
	add(fxs,fx)
end

function add_ptcl(x,y,r,col,large)
	local ptcl=create_obj(x,y)
	local dir=rnd(360)/360
	local spd=r/4
	ptcl.vx=spd*cos(dir)
	ptcl.vy=spd*sin(dir)
	ptcl.col=col
	ptcl.t=0
	ptcl.cr=rnd(2)
	if large then ptcl.cr=rnd(3) end
	local cr=ptcl.cr
	if large then cr=1.45 end
	ptcl.acx=ptcl.vx*-cr/14
	ptcl.acy=ptcl.vy*-cr/14
	add(ptcls,ptcl)
end

function add_actor(x,y,col,tag)
	local act=create_obj(x,y)
	act.dir=flr(rnd(360))
	act.spd=pc_spd
	act.col=col
	act.pts=0
	act.spr=17
	act.si=0
	act.acc=0
	act.br=0
	act.tag=tag
	act.ph=0
	act.hp=5
	if tag==tag_bot then
		act.spr=5
		act.dir=0
		act.spd=1
	end
	add(actors,act)
end

function add_item(x,y,spr)
	local obj=create_obj(x,y)
	obj.spr=spr
	obj.blink=30
	add(items,obj)
end

-- item fx

function splat(x,y,r,col)
	add_fx(x,y,r,col)
	local num_large=flr(rnd(5))
	local large=false
	for i=0,r*3,1 do
		if rnd(2)>1 and num_large>0 then
			num_large-=1
			large=true
		else
			large=false
		end
		add_ptcl(x,y,r,col,large)
	end
end

function bomb(act,item)
 shake=6
	local r=16
	local col=act.col
 sfx(4)
	if item.spr==4 then
		r=32
 end
 splat(item.x,item.y,r,act.col)
	del(items,item)
end

-- update
function col(p,e)
	local chk=0
	if p.x-4<e.x+4 then chk+=1 end
	if e.x-4<p.x+4 then chk+=1 end
	if p.y-4<e.y+4 then chk+=1 end
	if e.y-4<p.y+4 then chk+=1 end
	if chk==4 then
		return true
	else
		return false
	end
end

function collide(act)
	local x=flr(act.x/8)+objx
	local y=flr(act.y/8)+objy
	local spx=sget(x,y)
	local hit=false
	local hit_bot=false
	local pc_dir=-1
	if spx==1 or spx==5 then
		local blk={}
		blk.x=(x-objx)*8+4
		blk.y=(y-objy)*8+4
		if col(act,blk) then
			hit=true
		end
	end
	
	if not hit then
		for pc in all(actors) do
		 if pc~=act then
		 	local h1,h2
				h1=col(act,pc)
				h2=col(pc,act)
				if h1 and h2 then
					hit=true
					pc_dir=pc.dir
				end
				
				-- hit mimic bot
				if hit and act.tag==tag_bot then
					if act.col~=pc.col then
						glitch=3
					end
					act.col=pc.col
					hit_bot=true
					splat(act.x,act.y,12,pc.col)
					
					break
				end
				
		 end
		end
	end
	
	if hit then
		act.dir=(act.dir+180)%360
		act.acc=pc_acc
		if act.tag==tag_bot then 
			act.acc*=1.5
			if pc_dir==-1 then
				act.acc=0.75
			end
			act.x+=act.vx*-1
			act.y+=act.vy*-1
		end
		if hit_bot then
			sfx(9)
		else
			sfx(0)
		end
		
		if act.tag==tag_bot then
			act.hp-=1
			if act.hp<0 then act.hp=0 end
		end
	else
		if act.tag==tag_bot and act.hp<10 then
			act.hp+=1
		end
	end
end

function collide_item(act)
	for item in all(items) do
		if item.blink==0 and col(act,item) then
			if item.spr==5 then
				super_bomb(act,item)
			else
				bomb(act,item)
			end
		end
	end
end

function update_actors()
	for act in all(actors) do
		-- anim
		if act.tag~=tag_bot then
			if t%8==0 then
				act.si=(act.si+1)%2
			end
		end
				
		-- physics
		local spd=act.spd+act.acc-act.br
		act.vx=spd*cos(act.dir/360)
		act.vy=spd*sin(act.dir/360)
		act.x=(act.x+act.vx)%128
		act.y=(act.y+act.vy)%128
		if act.acc>0 then
			act.acc-=0.1
		else
			act.acc=0
		end
		
		-- collision
		collide(act)
		collide_item(act)
	end
end

function update_item(item)
	if item.blink>0 then
		item.blink-=1
	end
	item.x+=item.vx
	item.y+=item.vy
end

function update_fx(fx)
	fx.cr+=fx.dr
	if fx.t>0 then
		del(fxs,fx)
	else
		if fx.cr>=fx.r then
			fx.cr=fx.r
			fx.t=1
		end
	end
end

function update_ptcl(ptcl)
	if ptcl.t<6 then
		ptcl.x+=ptcl.vx
		ptcl.y+=ptcl.vy
		ptcl.vx+=ptcl.acx
		ptcl.vy+=ptcl.acy
		ptcl.t+=1
	else
		ptcl.dr=0
		add(fxs,ptcl)
		del(ptcls,ptcl)
	end
end

function respawn()
	if t%64==0 then
		local trials=3
		local x,y,type,dice
		while trials>0 do
			x=flr(rnd(16))
			y=flr(rnd(16))
			type=3
			dice=rnd(10)
			if dice>7 then
				type=4
			end
			if sget(x+objx,y+objy)==7 then
				add_item(x*8+4,y*8+4,type)
				break
			end
			trials-=1
		end
	end
end

-- controls

function ai(actor)
	local d=ddeg
	if t%128<24 then d=-ddeg end
	actor.dir+=d 
end

function change_dir(act)
	act.vx=flr(act.spd*cos(act.dir/360))
	act.vy=flr(act.spd*sin(act.dir/360))
end

function bot_ai2(act)
	if act.acc>0 then
		return
	end
	local pht=6
	act.spd=0.9
	act.ph=(act.ph+1)%(pht*2+4+pht)
	if act.hp==0 or flr(rnd(30))==15 then
		act.dir=flr(rnd(4))*90
	end
	if act.ph==pht or act.ph==pht+pht+2 then
		act.acc=2.0
		act.vx=0
		act.vy=0
	end
	if act.ph==pht or act.ph==pht+2 then
		act.dir=(act.dir-90)%360
		change_dir(act)
	end
	if act.ph==pht+pht+2 or act.ph==pht+pht+4 then
		act.dir=(act.dir+90)%360
		change_dir(act)
	end
end

function ctrl_actor(actor,cl,cr)

	if actor.tag==tag_bot then
		bot_ai2(actor)
		return
	end
	if actor.col==9 then
		ai(actor)
		return
	end

	local dir=0
	if cl then dir+=-ddeg end
	if cr then dir+=ddeg end
	actor.dir=(actor.dir+dir)%360
	if cl and cr then
		actor.br=pc_br
	else
		actor.br=0
	end
end

function btn_pressed()
	local chk=0
	for i=0,num_players-1,1 do
		for j=0,5,1 do
			if btnp(j,i) then
				chk+=1
			end
		end
	end
	if chk>0 then
		return true
	else
		return false
	end
end

function ctrl()
	if freeze>0 then
		return
	end
	
	if phase==-1 then
		if btnp(4) then
			phase=0
			glitch=8
			return
		end
	end

	if phase==1 and cnt==0 then
		local cl,cr,i
		i=0
		for act in all(actors) do
			cl=btn(1,i)
			cr=btn(0,i)
			ctrl_actor(act,cl,cr)
			i+=1
		end
	end
	if phase==0 then
		local pp=0
		if btnp(0) then pp=-1 end
		if btnp(1) then pp=1 end
		if pp~=0 then
			glitch=2
			sfx(10)
			objx+=16*pp
			if objx<0 then objx=112 end
			if objx>127 then objx=0 end
		else
			if btnp(4) then
				phase=1
				cnt=3
				glitch=10
				init_bg()
				fxs={}
				ptcls={}
			end
		end
		
		local tt=0
		if btnp(2) then tt=5 end
		if btnp(3) then tt=-5 end
		if tt~=0 then
			match_time+=tt
			if match_time<5 then match_time=5 end
			if match_time>120 then match_time=120 end
			if time~=match_time then
				sfx(5)
			end
			time=match_time
		end
	end
	if phase==2 then
		if btnp(4) then
			glitch=10
			init_game()
			phase=0
		end
	end
end

--
tag_pc=0
tag_ai=1
tag_bot=2
function _init()
	objx=0--16*flr(rnd(8))
	init_bg()
	init_game()
	freeze=10
end

function gameover()
	update_pts()
	freeze=40
	local i=1
	local pts=0
	winner=1
	for act in all(actors) do
		if act.tag~=tag_bot and act.pts>pts then
			pts=act.pts
			winner=i
		end
		i+=1
	end
end

function update_pts()
	if t%8==0 then
		local cols={}
		for i=1,count(actors),1 do
			cols[i]=actors[i].col
		end
		local outs=count_cols(cols,count_dist)
		for i=1,count(actors),1 do
			actors[i].pts=outs[i]
		end
	end
end

function update_clock()
	if t%30==0 then
		if cnt==0 then	time-=1 end
		if time==0 then
			phase=2
			sfx(8)
			gameover()
		else
			local snd=5
			if cnt>0 then
				cnt-=1
				snd=11
				if cnt==0 then snd=8 end
			else
				if time<=5 then snd=7 end
			end
			sfx(snd)
		end
	end
end

function update_game()
end

function _update()
	t=(t+1)%t_max
	if freeze>0 then
		freeze-=1
	end
	
	-- noise
	if glitch>0 then
		glitch-=1
	end
	
	-- camera
	if shake>0 then
		if true then--t%2==0 then
			cam.x=flr(rnd(8))-4
			cam.y=flr(rnd(8))-4
			--camera(cam.x,cam.y)
		end
		shake-=1
	else
		cam.x=0
		cam.y=0
		--camera(0,0)
	end
	
	-- clock
	if phase==1 then
		update_clock()
	end
	
	ctrl()
	
	if phase==-1 or phase==0 then
		update_st_scr()
		foreach(fxs,update_fx)
		foreach(ptcls,update_ptcl)
	end
	if phase==1 and cnt==0 then
		update_actors()
		foreach(items,update_item)
		foreach(fxs,update_fx)
		foreach(ptcls,update_ptcl)
		respawn()
	end
end

-- drawings

arrows={37,21,20,19,35,51,52,53}

function fill_bot(act)
	local x=act.x-4
	local y=act.y-4
	for ay=0,7,1 do
		for ax=0,7,1 do
			if pget(x+ax,y+ay)==6 then
				pset(x+ax,y+ay,act.col)		
			end
		end
	end
end

function draw_actor(act)
	local x,y
	x=act.x-4
	y=act.y-4
	spr(act.spr+act.si,x,y)
	--bot body
	if act.tag==tag_bot and act.col~=7 then
		fill_bot(act)
	end
	--eyes
	if act.tag~=tag_bot then
		pset(x+2,y+2,act.col)
		pset(x+5,y+2,act.col)
	end
	--indicator
	if act.tag>0 then return end
	local d=(act.dir+22.5)/45
	d=flr(d)%8+1
	x+=flr(8*cos(act.dir/360))
	y+=flr(8*sin(act.dir/360))
	spr(arrows[d],x,y)
	for ay=0,7,1 do
		for ax=0,7,1 do
			if pget(x+ax,y+ay)==15 then
				pset(x+ax,y+ay,act.col)
			end
		end
	end
end

function draw_item(obj)
	if obj.blink>0 and t%2==0 then

	else
			spr(obj.spr,obj.x-4,obj.y-4)
		
	end
end

function draw_map()
	local yadj=48
	--for y=0,16,1 do
		--for x=0,16,1 do
			mapdraw(x,yadj,0,0,16,16)
		--end
	--end
end

function draw_objs()
	local xadj=objx
	local yadj=objy
	local spix=5
	for y=0,16,1 do
		for x=0,16,1 do
			spix=sget(xadj+x,yadj+y)
			if spix==5 then
				spr(1,x*8,y*8)
			end
			if spix==1 then
				spr(2,x*8,y*8)
			end
		end
	end
end

max_pts=flr(128/count_dist)
max_pts*=max_pts

function perc(act)
	return flr(100*(act.pts/max_pts))
end

function draw_scores()
	local yadj=128-6
	local pts,len
	local w=flr(84/3)+1
	local h=4
	local fig
	for i=0,num_players-1,1 do
		color(0)
		rectfill(20+i*w,yadj,20+i*w+w-1,yadj+h)

		color(actors[i+1].col)
		pts=perc(actors[i+1])
		len=flr(w*(pts/100))
		if len>0 then
			rectfill(20+i*w,yadj,20+i*w+len,yadj+h)
		end
		color(7)
		fig=1
		if pts>=10 then fig+=1 end
		if pts>=100 then fig+=1 end
		print(pts,20+i*w+w-fig*4,yadj)
	end
	
	rectfill(107,yadj,107,yadj+h,0)
end

function draw_clock(x0,y0)
	local fig=2
	if time>=10 then fig-=1 end
	if time>=100 then fig-=1 end
	if cnt>0 then fig=2 end
	rectfill(x0,y0,x0+13,y0+6,0)
	cursor(x0+1+fig*4,y0+1)
	local col=7
	if time<=5 then col=8 end
	if cnt>0 then col=12 end
	color(col)
	if cnt>0 then
		print(cnt)
	else
		print(time)
	end
end

function draw_splash()
	local fil,txt
	fil=0
	txt=actors[winner].col
	if t%24<12 then
		fil=txt
		txt=0
	end

	winfill(20,52,103,69,actors[winner].col)

	color(7)
	rectfill(24,56,103,71,fil)
	print("press z to restart",28,66,txt)

	color(txt)
	if winner==3 then
		print("ai wins!",48,57)
 else
		print("player "..winner.." wins!",36,57)
	end
end

function draw_notice()
	local pi=1
 for act in all(actors) do
		if pi==4 then break end
		color(0)
		local x,y
		x=act.x+6
		if pi%2==0 then
			x-=25
		end
		y=act.y-4
		color(act.col)
		rectfill(x,y,x+12,y+6)
		
 	color(7)
 	if pi<3 then
 		print("p"..pi,x+3,y+1)
 	else
 		print("ai",x+3,y+1)
 	end
 	pi+=1
 end
end

function draw_trace(act)
	if cnt>0 then return end
	local ix=act.x
	local iy=act.y
	if act.tag==tag_bot then
		for dy=-3,2,1 do
			for dx=-3,2,2 do
				if rnd(10)>2 then
					pset(ix+dx,iy+dy,act.col)
					pset(ix+dx+1,iy+dy,act.col)
				end
			end
		end
	else
		local rad=5
		for i=0,10,1 do
			local dx=flr(rnd(rad)-rad/2)
			local dy=flr(rnd(rad)-rad/2)
			pset(ix+dx,iy+dy,act.col)
			pset(ix+dx+1,iy+dy,act.col)
		end
	end
end

function draw_fx(fx)
	circfill(fx.x,fx.y,fx.cr,fx.col)
end

function draw_ptcl(p)
	circfill(p.x,p.y,p.cr,p.col)
end

function camera_fx()
	if shake<1 then
		return
	end
	local i,j,px,py,mem,cplen
	local len=64
	local src_adj
	if cam.x<0 then
		px=0
		cplen=64+cam.x
	else
		px=cam.x
		cplen=64-cam.x
	end
	for page=0,1,1 do
		src_adj=page*len*64
		memcpy(0x4300,0x6000+src_adj,len*64)
		for y=page*len,(page+1)*len-1,1 do
			i=0+y*64
			py=y+cam.y
			if py>=page*len and py<(page+1)*len then
				j=px+(py-page*len)*64
				memcpy(0x6000+i,0x4300+j,cplen)
			end
		end
	end
end

function glitch_fx()
	--glitch=0


	if glitch>0 then
	local buf=0x4300
	local mem
	local i
	local y
	local md=36
	local a=glitch*1.1
	local x=(t/2)%md
	for r=8,120,1 do
		y=flr(cos(((x+r)%md)/md)*a)
		for c=0,64,1 do
			i=r*64+c
			mem=peek(0x6000+i)
			poke(buf+c,mem)
		end
		for c=0,64,1 do
			i=r*64+c
			mem=peek(buf+c)
			poke(0x6000+i-y,mem)
		end
	end
	end

	if glitch>0 then
		for k=0,400,1 do
			local i=flr(rnd(32*64))+((t/2)%64)*64
			poke(0x6000+i,0x0076)
		end
	end
end

cols={8,9,11,8,8,8,8}
st_t=0

function update_st_scr()
	if t%2==0 and rnd(3)>1 then
		st_t+=1
		for i=0,1,1 do
		local x,y,col,r
		x=flr(rnd(128))
		y=flr(rnd(128))
		col=cols[flr(rnd(count(cols)))+1]
		if col==8 then
			r=8+flr(rnd(16))
		else
			r=4+flr(rnd(8))
		end
		splat(x,y,r,col)
		--add_fx(x,y,8+flr(rnd(16)),col)
		end
	end
end

function draw_arena()
	sspr(objx,objy,16,16,40,32,48,48)
end

function winfill(x0,y0,x1,y1,fc)
	rectfill(x0,y0,x1,y1,fc)
	local pix
	for y=y0,y1,8 do
		for x=x0,x1,8 do
			pix=pget(x,y)
			if pix==fc then
				rectfill(x,y,x+7,y+7,(pix-flr(rnd(2)))%16)
			end
		end
	end
end

function draw_st_scr()
	color(7)
	local px,py
	px=16
	py=40
	if phase==-1 then
		--naugty
		local gaps={14,14,12,14,13,9,12}
		for g=1,7,1 do
			spr(94+g*2,px,py,2,2)
			px+=gaps[g]+1
		end
		px=16
		local w=16
		local sprs={110,98,6,96,106,8,10,12}
		gaps={10,14,6,14,10,9,13,10}
		for g=1,8,1 do
			w=16
			if sprs[g]==6 then w=8 end
			spr(sprs[g],px,py+16,2,2)
			px+=gaps[g]+1
		end
		if not ss_mode then
			print("press z to start",31,py+48)
		end
	else
		winfill(32,20,95,107,9)
		
		
		print("arena "..(flr(objx/16)+1),51,23,7)
		local cy0=84
		local upi=32
		local dwi=48
		local lfi=38
		local rgi=54
		if btn(0) then lfi+=1 end
		if btn(1) then rgi+=1 end
		if btn(2) then upi+=1 end
		if btn(3) then dwi+=1 end
		spr(lfi,32,52)
		spr(rgi,88,52)
		
		spr(upi,64-4,cy0)
		draw_clock(clock_x,cy0+8)
		spr(dwi,64-4,cy0+15)
		draw_arena()
		
		color(7)	
		print("press z to start",32,py+76)
	
		
	end
end

function _draw()
	-- paste bg to scr
	memcpy(0x6000,bg_addr,128*64)

	-- draw to scr as bg
	foreach(fxs,draw_fx)
	if phase==1 then
		foreach(actors,draw_trace)
	end
	
	-- copy scr to bg
	memcpy(bg_addr,0x6000,128*64)
	
	if phase==-1 or phase==0 then
		draw_st_scr()
		glitch_fx()
		return
	end

	if phase==1 then
		update_pts()
	end
	
	foreach(ptcls,draw_ptcl)
	draw_objs()
	foreach(items, draw_item)
	foreach(actors, draw_actor)
	--
	draw_clock(clock_x,clock_y)
	draw_scores()
	if phase==1 and cnt>0 then
		draw_notice()
	end
	if phase==2 then
		draw_splash()
	end
	
	camera_fx()
	glitch_fx()
end











