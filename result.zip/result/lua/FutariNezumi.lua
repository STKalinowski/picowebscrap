--futari nezumi!
--bright moth games

--light-cone format (in hex)
--bright_x_offset,bright_width,dim_x_offset,dim_width
--map-format
--mapwidth, theme, #door, #switch, #goose, #box, doors, switches, geese, boxes
cartdata"bmg_futanezu"
logo,title,loading,level,pregame,postgame,ending,attract1,attract2,firststart = 0,1,2,4,8,16,32,64,128,256
speed,framerate,frametime,cam,state,nextstate = 4,4,0,0,logo,logo
statetimer,logotimer,titletime,titleidx,stageindex,deadtime = 0,0,0,0,1,0
walk={9,10,11,12}
roll={60,61,62,63}
punch={23,24}
lift={24,24,23,23}
stand={8}
carry={25,26,27,28}
hold={29}
face={7}
swap={7,7,7,7,7,7}
press={15}
down={14}
invent={49}

gtypes={
  { speed=6, stopson=48, pals={} }, --lazy (stops a lot)
  { speed=5, stopson=64, pals={{7,9},{9,8},{5,7}}}, -- fast (stops some)
  { speed=6, stopson=0, pals={{7,8},{5,14}}}, -- persistent (never stops)
  { speed=0, stopson=0, pals={{7,6},{9,12},{5,13}}}, -- still (never moves)
}
gstand={56}
gturn={39,56}
gwalk={57,58,59,58}
gyawn= {39,40,41,42,41,42,41,42,41,42,41,40,39}
gpreen={39,43,44,45,44,45,44,45,44,45,44,43,39}
ghit={45,55}
gshout={42}
startcolours = { 7, 7, 7, 6, 13, 6}
floors={16,36,56}
dazeanims = { {93,94,95,94},{90,91,92,91},{87,88,89,88} }
catcher = nil
fufu={
 x=12,
 floor=3,
 frame=1,
 ft=0,
 acting=false,
 anim=stand,
 flip=false,
}
minx={
 x=0,
 floor=3,
 frame=1,
 ft=0,
 acting=false,
 anim=stand,
 flip=false,
}
mice = {fufu,minx}

function _init()
 poke(0x5f2c, 3)
 initstars()
end

function _update60()
 commitstate()
 if state == title then
  updatetitle()
  return
 elseif state == logo then return
 elseif state == ending then
  updateending()
  return
 elseif state == pregame then
  statetimer -= 1
  camera(cam,0)
  if titlefade and statetimer < -32 then
   statetimer = 0
   titlefade = false
   statetimer = (sw-64)*2
   cam = sw-64
   return
  end
  if not titlefade and statetimer > 0 then
   statetimer -= 1
   if(statetimer % 2 == 0) cam -= 1
  elseif not titlefade and statetimer <= 0 then
   nextstate = level
   if(prevstate == title or wasgameover) music"8" wasgameover = nil
   startgeese()
  end
 elseif state == postgame then
  statetimer += 1
  if statetimer > 72 then
   stageindex += 1
   if gameover then
    stageindex -= 1
    initmap(stageindex)
    nextstate = pregame
    titlefade = true
    wasgameover = true
   elseif stageindex > #stages then
    -- goto end screen
    nextstate = ending
    music"12"
   else
    initmap(stageindex)
    nextstate = pregame
    titlefade = true
   end
  end
 end

 if state == level then
  updatemouse(curmouse)
  cam = mid(0, curmouse.x - 36, sw - 64)
  if inexit(minx) and inexit(fufu) then
   nextstate = postgame
   statetimer = 0
  elseif catcher then
     deadtime += 1
     if deadtime >= 256 or (deadtime > 64 and btnp() ~= 0) then
      gameover = true
      nextstate = postgame
     end
  end
  for c in all(actions) do
   if costatus(c) ~= 'dead' then
    coresume(c)
   else
    del(actions,c)
   end
  end
  for g in all(geese) do
   updategoose(g)
  end
  updatedazefx()
  camera(cam,0)
 end
end

function _draw()
 poke(0x5f2c, 3)
 cls(0)
 pal()
 if state == title then
  drawtitle()
 elseif state == logo then
  drawlogo()
 elseif state == ending then
  drawending()
 else
  drawgame()
 end

 if state == postgame or titlefade then
  local idx = mid(0, flr(statetimer / 8), 7)
  fadepalette(idx, 1)
 end
end

-->8
function updatemouse(mouse)
 if(mouse.usedoor or mouse.isdown) return
 mouse.ft += 1
 mouse.rolling = false
 local moved = false
 if mouse.ft > framerate then
  mouse.frame += 1
  moved = true
  mouse.ft = 0
  local anim = mouse.anim
  if mouse.frame > #anim then
   mouse.frame = 1
   if mouse.acting then
    mouse.acting = false
    if mouse.anim == punch and not mouse.box then
     local b = hitbox(mouse)
     if b then
      mouse.box = b
      add(actions, cocreate(function()
       liftbox(b,mouse)
       end))
      setanim(mouse, lift, true)
     end
    elseif mouse.box and mouse.anim == lift then
     mouse.box.x = mouse.x
     mouse.box.y = floors[mouse.floor]-14
     setanim(mouse, hold)
    elseif mouse.box and mouse.anim == punch then
     mouse.box.y = floors[mouse.floor]-8
     mouse.box = nil
     setanim(mouse, stand)
    else
     setanim(mouse, stand)
    end
   end
  end
  local f = mouse.anim[mouse.frame]
  if(f == 10 or f == 26) sfx"20"
 end

 -- input
 local left,right,rolling,act,up=btn"0",btn"1",btn"4",btnp"4",btnp"2"
 if(mouse.acting) return
 if up then
  for d in all(doors) do
   local switch = d.switch
   if d.open and not mouse.box and mouse.x >= d.x - 2 and mouse.x <= d.x + 5 and (mouse.floor == d.b.floor or mouse.floor == d.a.floor) then
    add(actions, cocreate(function() usedoor(d,mouse,mouse.floor == d.b.floor) end))
    return
   elseif switch and mouse.floor == switch.floor and mouse.x >= switch.x-2 and mouse.x <= switch.x + 3 then
    add(actions, cocreate(function() useswitch(d, mouse) end))
   end
  end
 elseif (left or right) and rolling and mouse == fufu then
  setanim(curmouse, roll, nil, 10)
  mouse.rolling = true
  for v in all(vents) do
   if (v.topfloor == mouse.floor and mouse.x >= v.topx - 2 and mouse.x <= v.topx + 2)
    or (v.botfloor == mouse.floor and mouse.x >= v.botx - 2 and mouse.x <= v.botx + 2) then
     add(actions, cocreate(function()
       usevent(v,mouse)
       end))
    end
  end
 elseif act then
  if curmouse == minx then
   setanim(curmouse, punch, true)
   local hg = hitgoose(curmouse)
   if curmouse.box then
    add(actions, cocreate(function()
       dropbox(curmouse.box,curmouse)
       end))
   elseif hg then
    add(actions, cocreate(function() strikegoose(curmouse,hg) end))
   end
  end
 elseif (left or right) and not act then
  if(mouse.box) setanim(mouse,carry)
  if(not mouse.box) setanim(mouse, walk)
 elseif not left and not right and not act then
  if(mouse.box) setanim(mouse, hold)
  if(not mouse.box) setanim(mouse, stand)
 end
 local move = 0
 if(left and moved and mouse.x > 0) move -= 1
 if(right and moved and mouse.x < sw - 8) move += 1
 if(mouse.rolling) move *= 2
 if move != 0 then
  if hitbox(mouse, 1) or hitwall(mouse) then
   move = 0
  end
 end
 curmouse.x += move
 if(curmouse.box) curmouse.box.x += move
 curmouse.flip = (left or curmouse.flip) and not right

 if(btnp(5)) swapmouse()
end

function updategoose(g)
 local moved = false
 local gt = gtypes[g.type]
 if(g.acting) return
 g.ft += 1
 -- handle frame change
 local anim = g.anim
 if (anim == gwalk and g.ft > gt.speed) or (anim ~= gwalk and g.ft > 6) then
  g.frame += 1
  moved = true
  g.ft = 0
  if g.frame > #anim then
   g.frame = 1
   if(anim == gyawn) setanim(g, gwalk)
   if(anim == gpreen) setanim(g, gyawn, nil, 11)
  end
  if gt.speed > 0 and moved and anim == gwalk then
   local mx = 1
   if(g.flip) mx = 0xffff
   g.x += mx
   g.steps += 1
   if (g.x + 8 >= sw and not g.flip)
    or (g.x <= 0 and g.flip)
    or hitbox(g)
    or hitwall(g) then
     g.action = add(actions,  cocreate(function() turngoose(g) end))
    end
  end
  if(moved and g.anim[g.frame] == 58) sfx"21"
  if gt.stopson > 0 and g.steps >= gt.stopson then
   local na,nsfx = gpreen, 12
   if(rnd(1) > .5) na,nsfx = gyawn,11
   setanim(g, na, nil, nsfx)
   g.steps = 0
  end
 end
 if gt.speed == 0 and anim == gwalk then
  g.frame = 2
  g.ft = 0
  moved = false
 end
 for m in all(mice) do
  local range,gx,mx  = min(22, abs(g.lightwidth)),g.x,m.x
  leftdist,rightdist = gx-7-mx, mx-7-gx

  if not m.isdown and not m.usedoor and g.floor == m.floor and m.anim ~= invent and not m.door and (
      (not g.flip and gx <= mx-7 and rightdist <= range)
      or (g.flip and mx <= gx-7 and leftdist <= range)) then
      -- in light!
      dist = rightdist
      if(g.flip) dist = leftdist
      if(dist <= 8) add(actions,  cocreate(function() catchmouse(g,m) end))
  end
 end
end

function updatedazefx()
 for i=#dazefx,1,-1 do
  local dfx,moved = dazefx[i],nil
  if dfx.loops < 0 then
   dfx.g.frame -= 1
   yields"4"
   dfx.g.acting = false
   setanim(dfx.g, gyawn, nil, 11)
   del(dazefx,dfx)
  else
   dfx.ft += 1
   if dfx.ft > framerate then
    dfx.frame += 1
    dfx.ft = 0
    moved = 1
    if dfx.frame > #dfx.anim then
     dfx.frame = 1
     dfx.flip = not dfx.flip
     dfx.loops -= 1
    end
   end
   if moved then
    if(dfx.flip) moved = 0xffff
    dfx.x += moved
   end
  end
 end
end

function updatetitle()
 titletime += 1
 if(titletime > 8) titleidx += 1 titletime = 0
 if(titleidx > 6) titleidx = 1
 if titlefade then
  statetimer += 1
  if statetimer >= 72 then
   nextstate = pregame
   statetimer = 72
   initgame()
  end
 elseif btnp"5" or btnp"4" then
  startgame()
 end
end

function updateending()
 if not titlefade and btnp() ~= 0 then
  titlefade = true
  statetimer = 0
 end
end

function drawtitle()
 camera(32,32)
 cls()
 drawstars()
 palt(12,1)
 palt(0,false)
 spr(128,32,32,8,8)
 palt()
 camera(0,0)
 --print("❎ to start", 2, 22, startcolours[titleidx])
end

function drawending()
 camera(0,0)
 cls()
 palt(12,1)
 palt(0,false)
 spr(136,0,0,8,8)
 palt()
 if titlefade then
  statetimer += 1
  if statetimer >= 72 then
   nextstate = title
   titlefade = false
   cls()
  end
 end
end

function drawlogo()
 local fl = false
 if(rnd"4">2) fl = true
 palt(12,true)
 palt(0,false)
 rectfill(0,0,64,64,13)
 spr(30,24,16,2,2,fl)
 spr(104,1,34,8,2)
 print("p r e s e n t s",2,52,0)
 if logotimer == 0 then
  logotimer += 1
  sfx"62" --brightmoth sound
 end
 if logotimer >= 128 then
  titlefade = true
  statetimer += 1
 end
 if logotimer > 200 or btnp() ~= 0 then
  nextstate = title
  titlefade = false
  statetimer = 0
  sfx(0xFFFF,0)
  music"0"
  cls()
  palt()
 else
  logotimer += 1
 end
end

function drawgame()
 --background
 for i = 0, mapwidth - 1, 1 do
  local startx = 0
  if(flr(rnd(2) == 1)) startx = 8
  map(startx,maptheme_y,64*i,0,8,8)
 end

 for vent in all(vents) do
  drawvent(vent)
 end
 for door in all(doors) do
  if(door.switch) drawswitch(door)
  drawdoor(door, 1)
 end
 if(goal) fillp(0b0101101001011010) rectfill(goal.x, get_y(goal)-2, goal.x+16, get_y(goal)+8, 0x07) fillp()
 for box in all(boxes) do
  spr(box.id, box.x, box.y)
 end

 for g in all(geese) do
  drawgoose(g)
 end

 for dfx in all(dazefx) do
  spr(get_frame(dfx), dfx.x-1, get_y(dfx)-4,1,1,dfx.flip)
 end

 drawmouse(othmouse)
 drawmouse(curmouse)
 if(curmouse.door) drawdoor(curmouse.door)

 for wall in all(walls) do
  for y = 0,1,1 do
   local x,y,tile=wall.x,get_y(wall)-y*8,67
   if(maptheme == 1) tile = 3
   spr(tile, x, y)
   line(x,y,x,y+9,7)
   line(x+7,y,x+7,y+9,6)
  end
 end
 for i = 0, mapwidth - 1, 1 do
  local cx,sx = 8*maptheme, 64*i
  map(cx,0,sx,0,8,1)
  map(cx,2,sx,floors[1],8,1)
  map(cx,2,sx,floors[2],8,1)
  map(cx,1,sx,floors[3],8,1)
 end
 if catcher then
  local cm = minx
  if(fufu.isdown) cm = fufu
  circfill(cm.x+4,get_y(cm)+4,min(deadtime/4,64),0)
  drawgoose(catcher)
  drawmouse(minx)
  drawmouse(fufu)
 end
end

function drawstars()
    local speed = 5
    for s in all(stars) do
        pln(vec3(s.x,s.y,s.z),vec3(s.x,s.y,s.z+speed/3),12)
        pln(vec3(s.x,s.y,s.z+speed/3),vec3(s.x,s.y,s.z+2*speed/3),14)
        pln(vec3(s.x,s.y,s.z+2*speed/3),vec3(s.x,s.y,s.z+speed),7)

        --move stars.
        --use a fraction of speed to
        --create effect of star trails
        --being longer than distance
        --the stars actually move.
        s.z += speed/10

        -- reset star once it goes
        -- behind camera
        if s.z > 0 then
            s.x = rnd(40)-20
            s.y = rnd(40)-20
            s.z = -60
            s.col = 5
        end
    end

end

function drawdoor(door, bg)
 if(door.open) pal(8, 11) pal(2,3)
 local sx,aoff,boff,ay,by,dx = maptheme * 8, door.a.offs, door.b.offs, get_y(door.a), get_y(door.b),door.x
 if(bg) rectfill(dx, ay-1, dx+7, ay+7, bg) rectfill(dx, by-1, dx+7, by+7, bg)
 sspr(sx+aoff, 56, 8-aoff, 8, dx+aoff, ay)
 sspr(sx+boff, 56, 8-boff, 8, dx+boff, by)
 pal()
end

function drawswitch(door)
 local switch = door.switch
 local sy = get_y(switch)
 if switch.floor == door.a.floor or switch.floor == door.b.floor then
  rect(switch.x+3, sy-1, switch.x+4, sy-3,14)
  rect(switch.x+3, sy-4, door.x+4, sy-3, 14)
  rect(door.x+3, sy-1, door.x+4, sy-2, 14)
 else

  rect(switch.x+3, sy, door.x+4, get_y(door.a),14)
  rect(switch.x+3, sy, door.x+4, get_y(door.b),14)
 end
 rect(door.x + 3, get_y(door.a), door.x + 4, get_y(door.b), 14)
 if(switch.on) pal(8, 11) pal(2,3)
 spr(1, switch.x, get_y(switch))
 pal()
end

function drawvent(vent)
 local yt,yb,xt,xb = floors[vent.topfloor]-8, floors[vent.botfloor]-8,vent.topx, vent.botx
 local lx,by,rx,ty,bbid,tbid,verts = min(xb,xt), max(yb,yt), max(xb,xt), min(yb,yt),16,18,max((yb - (yt+16))/8,1)
 if(xt < xb) bbid = 34 tbid = 33
 -- middle
 for i=1,(rx-lx)/8-1,1 do
  spr(17,lx+i*8,ty+8)
 end
 --bottom
 for i=0,verts,1 do
  spr(32,xb,yb-i*8)
 end
 spr(32,xt,yt+8)
 if xt ~= xb then
  spr(tbid,xt,yt+8)
  spr(bbid,xb,ty+8)
 else spr(32,xt,ty+8) end
 spr(2,xt,yt)
 spr(48,xb,yb)
end

function drawgoose(g)
 local y,anim,x,r,delta,lwabs = get_y(g),g.anim,g.x + 8 + g.lightwidth, 4, 1,abs(g.lightwidth)
 setgpal(g)
 spr(g.anim[g.frame], g.x, get_y(g), 1, 1, g.flip)
 pal()
 if(g.flip) x = g.x + g.lightwidth delta = -1
 if g.lightwidth ~= 0 and (anim == gwalk or anim == gturn) then
  --line(x, y+5, x+g.lightwidth, y+5, 10)
  for i=lwabs,0,-1 do
   local c = 10
   if(i+r>8) c = 15
   if(i+r>16) c = 9
   addlight(x, y+5, r, c)
   x-=delta
   r-=.15
  end
 end
end

function drawmouse(m)
 setmpal(m)
 spr(m.anim[m.frame], m.x, get_y(m), 1, 1, m.flip)
 pal()
end

-->8
function swapmouse()
 local m,fx = othmouse,17
 if(m == minx) fx = 16
 setanim(curmouse, stand)
 if(curmouse.box) setanim(curmouse, hold)
 othmouse = curmouse
 curmouse = m
 cam = mid(0,m.x+4-32,sw-64)
 setanim(curmouse, swap, true, fx)
end

function setmpal(m)
 pal(12,0)
 if m == minx then
  pal(2,3)
  pal(13,4)
  pal(4,2)
  pal(6,15)
  pal(10,2)
  pal(9,2)
 else
  pal(10,0)
  pal(9,7)
  pal(12,0)
 end
end

function setgpal(g)
 local gt = gtypes[g.type]
 for p in all(gt.pals) do
  pal(p[1],p[2])
 end
end

function setanim(obj, anim, acting, fx)
 if(anim == obj.anim) return
 obj.ft = 0
 obj.frame = 1
 obj.anim = anim
 if(acting) obj.acting = true
 if(fx) sfx(fx)
end

function hitbox(m,range)
 range = range or 2
 for bx in all(boxes) do
  local ldelt,rdelt = m.x - (bx.x + 7),bx.x - (m.x + 7)
  if(bx.floor == m.floor
  and bx ~= m.box
  and not (m == fufu and minx.box == bx and m.rolling)
  and ((m.flip and ldelt >= 0 and ldelt <= range)
   or (not m.flip and rdelt >= 0 and rdelt <= range))) then
   return bx
  end
 end

 return false
end

function hitwall(obj)
 for w in all(walls) do
  local ldelt,rdelt = obj.x - (w.x + 7), w.x - (obj.x + 7)
  if w.floor == obj.floor
   and ((obj.flip and ldelt >= 0 and ldelt <= 1)
   or (not obj.flip and rdelt >= 0 and rdelt <= 1)) then
   return w
  end
 end

 return false
end

function inexit(m)
 if(goal and not m.usedoor and m.anim ~= invent and not m.door and not m.isdown and m.floor == goal.floor and m.x >= goal.x -2 and m.x + 7 <= goal.x + 18) return true
 return false
end

function blockbetween(obja, objb)
 for w in all(walls) do
  if(mid(w.x, obja.x, objb.x) == w.x) return true
 end
 for b in all(boxes) do
  if(mid(b.x, obja.x, objb.x) == b.x) return true
 end
end

-- coroutines
function hitgoose(m)
 for g in all(geese) do
  local ldelt,rdelt = m.x - (g.x + 7),g.x - (m.x + 7)
  if g.floor == m.floor
   and g.anim ~= ghit
   and ((m.flip and g.flip and ldelt >= -6 and ldelt <= 4)
   or (not m.flip and not g.flip and rdelt >= -6 and rdelt <= 4)) then
   return g
  end
 end

 return false
end

function liftbox(b,m)
 local x = -1
 sfx"8"
 if(m.flip) x = 1
 for i=0,3,1 do
  b.y -= 1
  yields"2"
 end
 for i=0,5,1 do
  b.y -= .5
  b.x += x
  yield()
 end
end

function strikegoose(m,g)
 if(g.anim == ghit) return
 if(g.action) del(actions, g.action) g.action = nil
 g.acting = true
 g.steps = 0
 sfx"18"
 yields"4"
 setanim(g, ghit)
 yields"4"
 g.frame += 1
 adddazefx(g)
end

function dropbox(b,m)
 local x = 1
 if(m.flip) x = 0xffff
 b.y -= 1
 b.x += x
 yield()
 for i=0,5,1 do
  b.y += 1
  b.x += x
  yield()
 end
 sfx"19"
end

function usedoor(d,m,fromb)
 local a,b = d.a,d.b
 setanim(m, press, true)
 m.usedoor = true
 if(fromb) a = d.b b = d.a
 opendoor(a)
 m.x = d.x
 m.door = d
 closedoor(a)
 yields"16"
 setanim(m, face, true)
 m.floor = b.floor
 opendoor(b)
 m.door = nil
 m.usedoor = false
 closedoor(b)
end

function usevent(v,m)
 local fx,fy,tx,ty,ver,hor,tf = v.botx,floors[v.botfloor]-8,v.topx,floors[v.topfloor]-8,0xffff,1,v.topfloor
 local lastvdist,firstvdist,reg=8,fy-(ty+8),8
 if m.floor ~= v.botfloor then
  fx=tx
  fy=ty
  tx=v.botx
  ty=floors[v.botfloor]-8
  tf=v.botfloor
 end
 if(fx > tx) hor *= 0xffff
 if(fy < ty) ver *= 0xffff reg=lastvdist lastvdist=firstvdist firstvdist=reg
 m.usedoor=true
 m.acting = true
 m.x = fx
 m.y = get_y(m)
 sfx"22"
 yield()
 setanim(m, invent)

 -- vertical to first branch
 for i=1,firstvdist,1 do
  m.y += ver
  yields"3"
 end
 sfx"23"
 -- horizontal to second branch
 for i=m.x,tx,hor do
  m.x += hor
  yields"3"
 end
 sfx"23"
 m.x = tx
 -- vertical to door
 for i=1,lastvdist,1 do
  m.y += ver
  yields"3"
 end
 m.floor = tf
 m.y = nil
 setanim(m,roll,true,10)
 for i=1,3,1 do
  m.x -= 2
  m.frame += 1
  yields"3"
 end
 setanim(m, stand)
 m.usedoor=false
 m.acting = false
end

function useswitch(d, m)
 setanim(m, press, true)
 local toggle = not d.open
 m.usedoor = true
 sfx"13"
 yields"8"
 d.switch.on = toggle
 d.open = toggle
 m.usedoor = false
end

function opendoor(d)
 sfx"14"
 for i = 0,7,1 do
  d.offs = i
  yields"2"
 end
end

function closedoor(d)
 for i = 8,0,0xffff do
  d.offs = i
  yields"2"
 end
end

function turngoose(g)
 setanim(g, gturn, true)
 local lightdelta = -1
 if(g.flip) lightdelta = 1
 for i=0,15,1 do
  g.lightwidth += lightdelta
  yields"4"
 end
 g.lightwidth = 0
 g.frame += 1
 yields"30"
 g.flip = not g.flip
 g.frame -= 1
 for i=0,15,1 do
  g.lightwidth += lightdelta
  yields"4"
 end

 setanim(g, gwalk)
 yield()
 g.acting = false

end

function catchmouse(g,m)
 g.acting = true
 m.isdown = true
 catcher = g
 music(63)
 setanim(m,down)
 setanim(g,gshout)
end

function startgame()
 titlefade = true
 music(0xffff, 144)
 sfx"63"
end

-->8
function addbox(tile, floor, id)
 add(boxes,{
     id=id or 70+flr(rnd(8)),
     x=tile*8,
     y=floors[floor]-8,
     floor=floor
 })
end

function addgoose(tile, floor, flip, type)
 local lw = 16
 if(flip) lw *= 0xffff

 add(geese,{
     x=tile*8,
     floor=floor,
     flip=flip,
     ft=0,
     frame=1,
     anim=gstand,
     steps=0,
     type=type or 1,
     acting=true,
     lightwidth=lw
 })
end

function adddoor(tile, floor1, floor2, switchtile, switchfloor)
 local d = add(doors, {
     x = tile*8,
     open=true,
     a = {
      floor = floor1,
      offs=0
     },
     b = {
      floor = floor2,
      offs=0
     }
 })
 if switchtile and switchfloor then
     d.switch = {
         x = switchtile*8,
         floor = switchfloor,
         on = false,
     }
     d.open = false
 end
end

function addvent(toptile,topfloor,bottile,botfloor)
 add(vents, {
     topx = toptile*8,
     topfloor = topfloor,
     botx = bottile*8,
     botfloor = botfloor
 })
end

function addlight(x,y,radius,colour)
 fillp(0b0101101001011010.1)
 circfill(x,y,radius,colour)
 fillp()
end

function adddazefx(g)
 add(dazefx, {x=g.x, floor=g.floor, anim=dazeanims[ceil(rnd(#dazeanims))], loops=30, time=0, ft=0, frame=1,flip=false,g=g})
end

function addwall(x, floor)
 add(walls, {x=x*8,floor=floor})
end

function fadepalette(idx, fullscreen)
 pal(1, sget(56 + idx, 49), fullscreen)
 pal(2, sget(56 + idx, 50), fullscreen)
 pal(3, sget(56 + idx, 51), fullscreen)
 pal(4, sget(56 + idx, 52), fullscreen)
 pal(5, sget(56 + idx, 53), fullscreen)
 pal(6, sget(56 + idx, 54), fullscreen)
 pal(7, sget(56 + idx, 55), fullscreen)
 pal(8, sget(56 + idx, 56), fullscreen)
 pal(9, sget(56 + idx, 57), fullscreen)
 pal(10, sget(56 + idx, 58), fullscreen)
 pal(11, sget(56 + idx, 59), fullscreen)
 pal(12, sget(56 + idx, 60), fullscreen)
 pal(13, sget(56 + idx, 61), fullscreen)
 pal(14, sget(56 + idx, 62), fullscreen)
 pal(15, sget(56 + idx, 63), fullscreen)
end

function initstars()
 --initialize table of stars
 --to random positions.
 stars = {}
 for i = 1, 128 do
  add(stars, {
  x = rnd(80)-40,
  y = rnd(80)-40,
  z = -rnd(60),
  col = 5}) --color
 end
 -- camera vector
 starcam = vec3(0,0,0)
 -- perspective line function
 pln = pline(starcam)
end

function setstart(mtile, mfloor, ftile, ffloor)
 minx.x,minx.floor,fufu.x,fufu.floor = mtile*8,mfloor,ftile*8,ffloor
end

function setgoal(tile, floor)
 goal = {x=tile*8,floor = floor}
end

function startgeese()
 for g in all(geese) do
  g.acting = false
  setanim(g, gwalk)
 end
end

function reset()
 --stars={}
 boxes={}
 walls={}
 geese={}
 dazefx={}
 actions={}
 buttons={}
 doors={}
 vents={}
 lights={}
 goal,gameover,catcher=nil,nil,nil
 resetmouse(minx)
 resetmouse(fufu)
 deadtime = 0
 mapwidth,maptheme,maptheme_y=3,flr(rnd(3)),11
end

function resetmouse(m)
 setanim(m, stand)
 m.isdown,m.door,m.acting,m.usedoor,m.box = nil,nil,false,nil,nil
end

function initgame()
 stages={}
 reset()
 stageindex = 1
 add(stages, tutorial1)
 add(stages, tutorial2)
 add(stages, easy1)
 add(stages, stage1)
 add(stages, stage2)

 -- adds a random box sprite on a given floor and x (in tiles)
 --addbox(70+flr(rnd(8)),3,3)
 -- adds a door x (tile), floor 1, floor 2, switch x (tile), switch floor
 --adddoor(5, 2, 3, 4, 2)
 -- adds a goose, x (tile) and floor
 --addgoose(6,2)
 -- adds a vent, top x (tile), top floor, bottom x (tile), bottom floor
 --addvent(7,2,10,3)
 initmap(stageindex)
end

function initmap(index)
 reset()
 maptheme,maptheme_y=flr(rnd(3)),11
 stages[index]()
 if(maptheme == 1) maptheme_y = 3
 sw = mapwidth * 64
 cam = sw-64
 curmouse = fufu
 othmouse = minx
end

-->8
-- stages
function tutorial1()
 mapwidth = 1
 setstart(0,3,1,3)
 addgoose(4,2)
 addbox(1,2)
 addbox(5,2)
 adddoor(2,3,1,1,1)
 addvent(4,1,6,3)
 setgoal(6,1)
 addbox(4,3)
end

function tutorial2()
 mapwidth = 1
 setstart(0,3,1,3)
 setgoal(4,1)
 addbox(6,1)
 addgoose(7,1,true,4)
 addgoose(4,3,false,4)
 adddoor(3,3,1,5,3)
end

function easy1()
 mapwidth = 2
 setstart(0,3,0,1)
 addwall(3,3)
 addwall(9,3)
 addwall(5,1)
 setgoal(4,3)
 adddoor(2,3,2,3,2)
 addvent(3,1,4,2)
 adddoor(6,3,1,10,3)
 addbox(7,2)
 addvent(11,2,12,3)
 addgoose(14,3)
 addgoose(13,2,false,4)
 addgoose(11,1,true,3)
 addbox(8,1)
 adddoor(9,2,1,15,2)
end

function stage1()
 mapwidth = 3
 setstart(0,3,0,1)
 setgoal(0,2)
 addvent(2,1,6,3)
 addvent(2,2,2,3)
 addwall(3,1)
 adddoor(4,1,3,7,3)
 addbox(5,2)
 addvent(13,1,8,3)
 addwall(9,3)
 adddoor(10,1,3,12,1)
 addwall(11,1)
 addbox(14,2)
 adddoor(15,1,2,15,3)
 addbox(18,3)
 addvent(19,1,22,2)
 addbox(20,2)
 addbox(22,3)
 adddoor(23,1,3,23,2)
 addgoose(7,2,true)
 addgoose(12,2,true,2)
 addgoose(20,3,false)
 addgoose(18,2,true,2)
end

function stage2()
 --set mapwidth as needed else 3
 --set maptheme as needed else random
 --set maptheme_y as needed else random
 setstart(1,3,1,1) --(x(minx),floor(minx),x(fufu),floor(fufu))
 --map 1
 addvent(2,1,1,2)
 addvent(5,1,4,3)
 addvent(9,2,10,3)
 addvent(12,1,11,3)
 addvent(16,1,17,2)
 -- tile, floor, (optional tile id)
 addbox(3,3)
 addbox(7,3)
 addbox(14,1)
 addbox(15,3)
 adddoor(2,2,3,3,2)
 adddoor(6,2,3,6,1)
 adddoor(10,1,2,11,1)
 adddoor(19,1,3,19,2)
 -- tile, floor, flip, (optional type)
 addgoose(5,2,true)
 addgoose(9,1,true,2)
 addgoose(13,2,false,3)
 addgoose(13,3,false,4)
 addgoose(18,2,true)
 addwall(5,3) --(x,floor)
 addwall(7,1)
 addwall(15,2)
 addwall(18,1)
 setgoal(20,1) --(x,floor)
end

-->8
function yields(to)
 for i=1,to,1 do
  yield()
 end
end

function get_y(obj, h)
 if(obj.y) return obj.y
 h = h or 8
 return floors[obj.floor]-h
end

function commitstate()
 if(nextstate ~= state) then
  prevstate = state
  state = nextstate
 end
end

function get_frame(obj)
 return obj.anim[obj.frame]
end

function pline(c)
   local function project(x, y, z)
     -- world space to camera space.
     x, y, z = x-c.x, y-c.y, z-c.z

     -- camera space to screen space.
     x, y = -x/z, -y/z

     -- screen space to raster space.
     x, y = x*64+64, -y*64+64

     return flr(x), flr(y)
   end

   return function(p1, p2, col)
     -- ignore if both points are in front of near plane.
     if p1.z > (c.z-0.1) and p2.z > (c.z-0.1) then return end

     -- final line points.
     local x1, y1, x2, y2

     -- if p1 is in front of near plane,
     if p1.z > (c.z-0.1) then
       -- find the point of intersection and update p1.

       -- update x.
       local m = (p1.x - p2.x) / (p1.z - p2.z)
       local x = m*(c.z-0.1) + p2.x

       -- update y.
       m = (p1.y - p2.y) / (p1.z - p2.z)
       local y = m*(c.z-0.1) + p2.y

       -- update z.
       local z = c.z-0.1

       x1, y1 = project(x, y, z)
     else
       x1, y1 = project(p1.x, p1.y, p1.z)
     end

     -- if p2 is in front of near plane,
     if p2.z > (c.z-0.1) then
       -- find the point of intersection and update p2.

       -- update x.
       local m = (p2.x - p1.x) / (p2.z - p1.z)
       local x = m*(c.z-0.1) + p1.x

       -- update y.
       m = (p2.y - p1.y) / (p2.z - p1.z)
       local y = m*(c.z-0.1) + p1.y

       -- update z.
       local z = c.z-0.1

       x2, y2 = project(x, y, z)
     else
       x2, y2 = project(p2.x, p2.y, p2.z)
     end

     line(x1, y1, x2, y2, col)
   end
end

function vec3(x, y, z)
   return {x = x, y = y, z = z}
end
