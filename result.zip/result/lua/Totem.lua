--ld48 totem
--benjamin soule
focus_max=16
hp_max=20
refill_max=32

--from=5

shid=0
--test_seq={6,9,6,9,6,12,5,5,10,13,9} --4

function _init()
 t=0
 logs={} 
 pixels={}
 tipis={}
 first=true
 
 -- spirits 
 spirits={}
 for i=0,5 do add(spirits,32+i) end
 
 --
 --init_title()
 launch()
 --reset()
 --set_arena(0)
 ---

end

function init_title()

 mdr=function()
  sspr(24,96,13*8,24,12,0)
  vis=t%16<12
  if launching then
   vis=t%2==0
  end
  if vis then
   print("press x to start",34,80,7)
  end
 end
 
 mupd=function()
  if launching then
   if t==40 then
    launch()
   end
  else
   if btnp(5)  then
    launching=0
    t=0
    sfx(23)
   end
  end
  
  
 end

end

function launch()
 
 reset()
 set_arena(0)
 mupd=upd_game
 mdr=dr_game
end


function upd_game()
 foreach(ents,upe) 
 if gmo then return end
 
 if boss and boss.dhp<=0 then
  explode(boss)
 elseif hero and hero.dhp<=0 then
  explode(hero)
 end
end


function reset()
 reload()
 
 monsters={}
 ents={}
 t=0
 gmo=nil
 boss=nil
 
 -- hero
 hero=mke(16,32,32)
 hero.upd=upd_hero
 hero.recx=true 
 hero.hid=32 
 hero.hero=true
 hero.ady=0
 init_human(hero)
 refill=0
 
 
 arrows_max=5
 arrows=arrows_max
 
 if test_head then
  hero.hid=test_head
 end


end


function set_arena(k)
 a={ 0, 0, 64,16,0, 				
 				0, 24,16,8, 1,
 				24,16,16,16,0,
 				40,16,24,16,1,
 				64,16,24,8, 0,
 				0, 16,24,8, 0,
  }
 function f(n) return a[k*5+n] end
 arena={
  x=f(1),y=f(2),w=f(3),h=f(4),
  bg=k,roof=f(5)==1
 }
 -- scan
 wps={}

 for x=0,arena.w-1 do
  for y=0,arena.h-1 do
   px=arena.x+x
   py=arena.y+y
			fr=mget(px,py)
			if fr==32 then			
			 hero.x=x*8
			 hero.y=y*8
			 hero.vx=0
			 hero.vy=0
			 hero.jump=true

			 mset(px,py,0)
			end
			if fr<41 and fr>32 then	
			 mk_boss(fr,x*8,y*8+8)	
			 mset(px,py,0)
			end 
			if fr==1 or fr==2 then
			 rep={0,148}
			 mset(px,py,rep[fr])
			 add(wps,{x=x*8,y=y*8})
			end	
			if fr==155 then
			 add(wps,{x=x*8,y=(y-1)*8})
			end		
			if fr==101 and first then
			 add(tipis,{x=x,y=y,n=#tipis,ok=#tipis<5})
			 --add(tipis,{x=x,y=y,n=#tipis,ok=true})
			end					
  end
 end
 first=false
 place_cam()
 secure_swap(0)
 if quiver then kill(quiver) end
 if arena.bg==0 and from!=nil then
  tipi=tipis[from+1]
  hero.x=tipi.x*8+16
  hero.y=tipi.y*8
  hero.flp=true
 end 
 fade(true)
 
end

function init_human(e)
 e.hp=hp_max
 e.dhp=hp_max
 e.pal={11,15}
 e.shade=true
 e.wfr=0
 e.jump=true
 e.col=true
 e.pdr=draw_head
end


-- ents
function mke(fr,x,y)
 e={ fr=fr,x=x,y=y,
  vx=0,vy=0,frict=1,
  we=0,flp=false,size=8,
  ox=x,oy=y,fdx=0,fdy=0,
  recx=true,vis=true,t=0,
  gmo=gmo,
  }
 add(ents,e)
 return e
end

function upe(e)
 if e.gmo!= gmo then return end

 e.t+=1
 if e.upd then e.upd(e) end
 
 -- phys / col
 e.ox=e.x
 e.oy=e.y 
 e.vx*=e.frict
 e.vy*=e.frict
 e.vy+=e.we 

 
 if e.col then
  colphys(e)
 else
  e.x+=e.vx
  e.y+=e.vy 
 end
 
 -- recal
 if e.recx and false then
  oex=e.x
  e.x=mid( 0,e.x,arena.w*8-e.size)
  if oex!=e.x  then
   if e.impact then e.impact() end
  end
 end

 -- life
 if e.life then
  e.life-=1
  if e.blink and e.life<e.blink then
   e.vis=t%2==0
  end
  if e.life <=0 then
   kill(e)
  end
 end 
 
 -- col w opp
 if e.opp then
  opp=e.opp
  dx=abs(e.x-opp.x)
  dy=abs(e.y-opp.y)
  lim=(e.size+opp.size)*0.5
  if dx<lim and dy<lim and not opp.inv then
   hit(opp,e)
   if e.mis then
    kill(e)
   end
  end
 end
 
 -- inv
 if e.inv then
  e.inv-=1
  if e.inv==0 then
   e.inv=nil
  end
 end
 
 -- play anim
 if t%3==0 and fget(e.fr,3) then
  e.fr+=1
  if not fget(e.fr,3) then 
   while fget(e.fr-1,3) do
    e.fr-=1
   end
  end
 end
 
 -- col break
 if e.brk and chkp(e.x+4,e.y+4) then
  kill(e) 
 end
 
 -- pfr
 if e.pfr and t%2==0 then
  e.pfr+=e.pps 
  if e.pfr>=e.fmax then
   kill(e)
  end
 end
 
 -- tween
 if e.twc then
  e.twc=min(e.twc+e.spc,1)
  c=e.curve(e.twc)
  e.x=e.sx+(e.tx-e.sx)*c
  e.y=e.sy+(e.ty-e.sy)*c
  if e.twj then
   e.y+=sin(c*0.5)*e.twj
  end
  
  if e==boss then
   e.flp = e.ox>e.x
   e.fr=19
   if e.oy>e.y then
    e.fr=18
   end
  end

  if e.twc==1 then
   e.twc=nil  
   if e.twnxt then e.twnxt() end
  else
    
  end
 end
 
end

function mkp(apx,apy,sz,fmax,pps)
 e=mke(-1,0,0)
 e.fmax=fmax
 e.pfr=0
 e.pps=pps
 e.dr=function(e)  
  sspr(apx+flr(e.pfr)*sz,apy,sz,sz,e.x-sz*0.5,e.y-sz*0.5)
 end
 return e
end

function ghpo(e)
 local p={x=0,y=0}
 fr=e.fr
 for x=0,7 do
  for y=0,7 do
   pix=sget((fr%16)*8+x,flr(fr/16)*8+y)
   if pix==11 then  
    p.x=x
    p.y=y
   end
  end
 end
 p.x+=e.fdx
 if e.flp then p.x=7-p.x end  
 return p
end

function colphys(e)

 sx=sgn(e.vx)
 sy=sgn(e.vy)
 
 
 stx=abs(flr(e.vx))
 dtx=e.vx/stx 
 for i=1,stx do
  if e.dead then break end
  if chk_col(e,dtx,0) then
   e.vx=0
   if e.impact then 
    e.impact() 
    break
   end
  else
   e.x+=dtx
  end  
  if e.tcol then e.tcol(e) end
 end
 
 sty=abs(flr(e.vy))
 dty=e.vy/sty 
 for i=1,sty do
  if e.dead then break end
  if chk_col(e,0,dty) then   
   if e.jump and e.vy>0 then
    e.jump=false
    if e==hero then
     sfx(12)
    end
   end  
   e.vy=0
   if e.impact then e.impact() end
  else
   e.y+=dty
  end  
  if e.tcol then e.tcol(e) end
  
 end
 

end


function kill(e)
 del(ents,e)
 e.dead=true
 if e.ondeath then e.ondeath() end
end

function hit(e,from)
 dmg=from.dmg
 if from.hid and mget(64+from.hid-33,25)==e.hid then
  dmg*=2
 end
 e.hp-=dmg
 e.inv=24

 if hero.hid==37 and from.hid==37 then
  hero.hp=min(hero.hp+1,hp_max)
 end
 
 if e==hero then
  sfx(19)
 else
  sfx(20)
 end

 
 if from.hid==35 or from.cad==7 then
  e.poison=3
  if e.hid==33 then
   e.poison=6
  end
 end
 
end


function apal(n)
 for i=0,15 do pal(i,n) end
end

function dre(e)
 if not e.vis then return end
 
 if e.inv and t%2==0 then 
  apal(8)
 end

 if e.shade and not e.inv then
  apal(1)
  mdre(e,1,0)
  mdre(e,-1,0)
  mdre(e,0,1)
  mdre(e,0,-1)
  pal()
 end
 mdre(e,0,0)  
 pal()
 
end

function mdre(e,drx,dry)
 
 ddx=drx
 ddy=dry
 if e.pdr then e.pdr(e) end

 fdx=e.fdx
 fdy=e.fdy
 if e.flp then
  fdx*=-1
  fdy*=-1
 end
 
 x=e.x+ddx+fdx
 y=e.y+ddy+fdy
 
 fr=e.fr 

 if fr>=0 then
  spr(fr,x,y,1,1,e.flp)
 end
 if e==hero or e==boss then
  p=ghpo(e)
  pset(p.x+x,p.y+y,15)
 end
 
 if e.dr then e.dr(e) end
 
end


function chk_col(e,cdx,cdy)
 if not e.col then return false end
 if not cdx then cdx=0 end
 if not cdy then cdy=0 end
 sz=e.size-1
 dwn=e.vy>=0
 fly=e.fly
 if sz == 0 then 
  return chkp(e.x+cdx,e.y+cdy)
 end
 
 return 
  (not dwn and chkp(e.x+cdx,e.y+cdy)) or 
  (not dwn and chkp(e.x+cdx+sz,e.y+cdy)) or 
 	chkp(e.x+cdx,e.y+cdy+sz) or 
 	chkp(e.x+cdx+sz,e.y+cdy+sz) 
end

function chkp(x,y) 
 px=flr(x/8)
 py=flr(y/8) 
 
 if (px<0 or px>=arena.w) then return true end
 if py<0 or py>=arena.h then return false end
 
 
 tile=mget(px+arena.x,py+arena.y)
 if fly then 
  return fget(tile,0)
 end
 dwn = dwn and flr((y-1.5)/8)!=py 
 return fget(tile,0) or (dwn and fget(tile,2))
end

-- boss
function mk_boss(fr,x,y)
	boss=mke(16,x,y)
	boss.flp=true
	boss.hid=fr
 boss.seq={1,1,1,2,3}
 boss.sqi=-1
 boss.opp=hero
 boss.dmg=4
 init_human(boss)
 boss.upd=upd_boss
 
 
 if fr==33 then
  boss.seq={4,5,6,6,6}
 end
 
 if fr==34 then
  boss.seq={4,2,7,8,7}
 end
 
 if fr==35 then
  boss.seq={4,9,10,11,4,9}
 end
 
 if fr==36 then
  boss.seq={6,9,6,9,6,12,5,5,10,13,9}
 end
 
 
 if test_seq then
  boss.seq=test_seq
 end
 bnext()
 
end


function bnext()
 boss.sqi=(boss.sqi+1)%#boss.seq
 bplay(boss.seq[1+boss.sqi])
end

function bplay(ev)

 b=boss
 b.fdx=0
 b.wings=false
 -- skel hand
 if ev==1 then
  bshow(skel_hand) 
 end
 
 if ev==2 then
  if b.hid==34 then
   b.vy=-1
  end
  b.fr=26
  b.wings=true
  b.jump=true
  function fly_up(e)
   b.vy-=0.1
   if b.y<-32 then
    b.vy=0
    bnext()
    kill(e)
   end
  end
  loop(fly_up) 
 end
 
 if ev==3 then
  b.wings=true
  b.frict=0.93
  loop(fly_around)
 end
 
 -- run
 if ev==4 then
  loop(run_around)
 end
 
 -- show
 if ev==5 then
 
  bshow(bnext)
 end
 
 -- tomawak
 if ev==6 then
  b.fr=16
  face_hero()
  shoot_tom(b,hero)
  sfx(6)
  dl(32,bnext)
 end
 
 -- fly_random
 if ev==7 then
  b.wings=true
  b.frict=0.93
  dl(120,bnext,fly_random)
 end
 
 -- deathers
 if ev==8 then
  b.fr=29
 
  function pop()
   b.vx*=0.85
   face_hero()
   p=mkp(16,0,3,5,0.5)
   an=rnd()
   impulse(p,an,2)
   p.frict=0.95
   p.x=b.x+4-cos(an)*24
   p.y=b.y+1-sin(an)*24
  end
  
  for i=1,20 do dl(i,pop) end
  
  function go()
   b.wings=true
   b.fr=26
   sfx(6)
   for i=0,15 do 
    shoot_tom(b,hero,i/16)
   end
  end  
  dl(32,go)
  dl(64,bnext)  
 end 
 
 if ev==9 then
  b.vx=0
  b.vy=0  
  wp=wps[1+rand(#wps)]
  tw(boss,wp.x,wp.y,-3,24,bnext)
  sfx(3)
 end

 -- jump_boom
 if ev==10 then
  sfx(3)
  face_hero()
  function f()
   sfx(22)
   shake=4
   b.fr=16
   bnext()
  end 
  tw(b,b.x,b.y,16,8,f)
 end 
 
 -- spawn snake
 if ev==11 then
  for i=0,2 do
   sn=mke(6,rnd(arena.w-1)*8,-8)
   sn.upd=upd_snake
   sn.jump=true
   sn.shade=true
   sn.opp=hero
   sn.dmg=0
   sn.mis=true
   sn.cad=7
   add(monsters,sn)
  end
  dl(32,bnext)
 end
 
 -- target blocks
 if ev==12 then
  a={}
  blocks={}
  for x=0,23 do
   for y=0,7 do
    fr=mget(arena.x+x,arena.y+y)
    if fr==136 then 
     add(a,{x=x,y=y})
     break
    end
    if fr==155 then
     break
    end
   end
  end
  for i=0,2 do
   bl=pick(a)
   if bl then
    add(blocks,bl)
   else
    break
   end
  end
  bnext()  
 end
 
 -- burstb lock
 if ev==13 then
  sfx(7)
  for bl in all(blocks) do
   mset(arena.x+bl.x,arena.y+bl.y,156)
  	for i=1,3 do
  	 x=(bl.x+rnd())*8
  	 y=(bl.y+rnd())*8
  	 p=mke(141+rand(3),x,y)
  	 impulse(p,rnd(),rnd()*2)
  	 p.frict=0.95
  	 p.life=20+rand(20)
  	 p.vy-=3
  	 p.we=0.2*i  	 
  	end
  end
  blocks={}
  dl(10,bnext)
 end

end



function pick(a)
 local n=a[rand(#a)]
 del(a,n)
 return n
end

function upd_snake(e)

 dwn=true
 if e.jump then  
  if chkp(e.x+4,e.y+8) then   
   e.jump=false
   e.fr=8
   e.sens=sgn(96-e.x)
   e.flp=e.sens==-1
  else  
   e.y+=1
  end
 else 
  e.x+=0.5*e.sens
  if not chkp(e.x+4,e.y+9) then
   e.jump=true
  end 
  if e.x<-8 or e.x>arena.w*8 then
   destroy(e)
  end
  
 end
 
end

function fly_random(e)
 tx=60+cos((e.t+t)/280)*40
 ty=cos(e.t/40)*64-32  
 follow(b,tx,ty,0.01,0.2)
end


function run_around(e)
 lim=240
 acc=60
 max_spd=1.5
 
 if b.hid==35 then
  lim=60
  acc=15
 end
 
	if b.hid==33 then 
	 max_spd=3
	end
	
 kk=e.t  
 if e.t>lim-acc then 
  kk=lim-e.t 
 end
	
	spd=min(1+kk/acc,max_spd)
	
 if e.t%50==1 then
  bdir=sgn(hero.x-b.x)*1
 end  
 
 if bdir>0 and b.x>=arena.w*8-9 then
  bdir*=-1   
 end
 
 if bdir<0 and b.x<=1 then
  bdir*=-1
 end 
   
 move(b,bdir,spd)  
 hdy= b.y-8-hero.y
 chance=max(1,60-hdy)
 if hdy>0 and not b.jump and rand(chance)==0 and e.t>40 then
  b.vy=-4
  b.jump=true
  sfx(3)
 end  
  
 if (e.t>=lim and not b.jump) or b.y>arena.h*8 then
  kill(e)
  bnext()
 else
  if b.hid==34 and not b.jump and rand(60)==0 then
		 kill(e)
		 bplay(8)		  
	 end
 end 
  
end


function fly_around(e)
 
 if e.t<120 then
  tx=hero.x+cos(t/60)*24
  follow(b,tx,sin(t/40)*32-32,0.01,0.2)   
 elseif b.jump then
  b.wings=nil
  b.fr=27
  b.vx*=0.5
  b.vy+=2
 else
  kill(e)
  shake=8
  sfx(22)
  dl(40,bnext)
 end 

end


function loop(f)
 e=mke(-1,0,0)
 e.upd=f
end

function bshow(nxt)
 sfx(16)
 function f()
  face_hero()
  b.fdx=2
  b.vx*=0.5
 	b.fr=24+tmod(2,4)
 end
 
 dl(40,nxt,f)
end

function skel_hand()
 	
 hx=flr(hero.x/8)*8
 hy=hero.y
 while not chkp(hx,hy) do
 	hy+=1
 end
 hand=mke(107,hx,hy)
 hand.by=hy
 hand.opp=hero
 hand.dmg=2
	
 	
 tw(hand,hx,hy,40)
 hand.twj=8
 hand.twnxt=function()
  kill(hand)
  bnext()
 end
 	

end

function ending()
 t=0
 mupd=nil
 mdr=function()
  col=sget(min(8+flr(t/12),23),7)
  rectfill(0,0,128,128,col)
  print("congratulations",32,flr(60.5+cos(t/80)*8),1)
 
 end

end


function enter_tipi()

 if tipi.n==5 then
  fade()

  dl(20,ending)
  return
 end

 sfx(5)
 set_arena(tipi.n+1)
 tipi=nil
end


function bnext_old(bw)
 bwait=nil
 bt=0
 if bw then 
  bwait=bw 
 else
  boss.wings=false
  if fbst then
   fbst=nil
  else    
   boss.sqi=(boss.sqi+1)%#boss.seq
  end  
 end 
end

function face_hero()
 boss.flp = hero.x-boss.x<0
end

function upd_boss(b)
 upd_human(b)
end

function tw(e,tx,ty,n,twj,nxt)
 e.sx=e.x
 e.sy=e.y
 e.tx=tx
 e.ty=ty
 e.twc=0
 e.twj=twj
 e.spc=1/n
 if n<0 then
  local dx=tx-e.x
  local dy=ty-e.y
  local dd=sqrt(dx*dx+dy*dy)
  if twj then dd+=twj*1.4 end
  e.spc=-n/dd
 end
 e.twnxt=nxt
 e.curve=function(n) return n end
end

function shoot_tom(b,opp,an)
 
 dx=opp.x-b.x
 dy=opp.y-b.y
 tan=atan2(dx,dy)
  
 spd=1
 e=mke(-1,b.x,b.y)
 e.dmg=1
 e.brk=true
 if b.hid==33 then
  an=tan
  e.fr=58
  e.dmg=2
 end
 
 if b.hid==34 then
  e.fr=176+flr(an*16)
  e.frict=1.05
 end
 
 if b.hid==36 then
  e.fr=157
  e.dmg=2
  spd=0.5
  an=tan
  e.brk=false
 end
 
 impulse(e,an,spd)
 e.opp=hero
 e.life=256
 e.dmg=2
 e.hid=b.hid
 e.mis=true
 e.shade=true
 e.opp=opp
 
 
end

function impulse(e,an,spd)
 e.vx=cos(an)*spd
 e.vy=sin(an)*spd
end


function rand(n)
 return flr(rnd(n))
end

function follow(e,tx,ty,c,lim)
 dx=tx-e.x
 dy=ty-e.y
 e.vx+=mid(-lim,dx*c,lim)
 e.vy+=mid(-lim,dy*c,lim)
end



function dl(t,f,lp)
 e=mke(-1,0,0)
 e.life=t
 e.upd=lp
 e.ondeath=f
 return e
end 

function tmod(n,k)
 return flr((t%(n*k))/k)
end

function move(e,n,spd)

 e.fr=16
 e.vx=n*spd
 if n!=0 then e.flp=n<0 end
 
 if e.jump then
  e.vy += 0.25 
  e.fr=18
  if e.vy>0 then
   e.fr=19
  end 
 
 else 
  if n!= 0 then   
 	 sns=1
   if not e.flp and n==-1 then sns*=-1 end
   if e.flp and  n==1 then sns*=-1 end
   e.wfr=(e.wfr+spd*sns/4)%8
   e.fr = 16+flr(e.wfr)
   
   if t%8==0 then
    
    sfx(13+flr((t%8)/4))
   end
   
   if not chk_col(e,0,1) then
    e.jump=true
   end
  end    
 end
end

--
function upd_human(e)

 if e.poison and t%100==0 then 
  e.poison-=1
  e.hp-=1
  sfx(18)
  function bub()
   p=mkp(32,0,4,4,0.5)
   p.x=e.x+rand(8)
   p.y=e.y-2
   p.we=-0.1
   p.life=32
  end  
  for i=0,3 do
   dl(i*4,bub)
  end
  
  if e.poison==0 then e.poison=nil end
 end
 
 if e.hp!=e.dhp then
  e.dhp+=sgn(e.hp-e.dhp)
 end 
 
end
 
--

 
-- hero
function upd_hero(h)
 if fading then return end
 upd_human(h)
 
 -- enter tipi
 if btn(2) and arena.bg==0 then
  if tipi and pwr then   
   if tipi.ok then
    enter_tipi()
    return
   else
    if tipi.n<5 then
     refill+=1
     if refill==refill_max then
      tipi.ok=true
      add(spirits,tipi.n+33)
      pwr=false
     end
    end
   end
  end
 else
  pwr=true
  refill=0
 end

 --move
 h.vx=0
 spd=2
 if h.hid==33 then spd=3 end
 if focus then spd=1 end
 n=0
 if btn(0) then n=-1 end
 if btn(1) then n=1 end
 move(h,n,spd) 

 -- check jump
 if not h.jump and djp then
  djp=false
 end
 if ( not h.jump or (djp and h.vy>=-1) ) and btnp(4) then
  if djp then
   sfx(4)
   djp=false
   for i=1,3 do
    p=mke(184,h.x+4,h.y+8)
    p.life=50
    p.we=0.1
    p.vy=-1-rnd()*2
    p.vx=rnd(4)-2+h.vx*0.5
    p.t=rand(128)
    p.upd = function(e)
  			fr=flr(188+cos(e.t/20)*6)
     e.fr=mid(184,fr,191)    
    end
    p.blink=20
    p.frict=0.95
    p.shade=true
   end
   
  else
   sfx(3)
   djp=h.hid==34
  end
  
  h.jump=true
  h.vy=-4
  
 end
 
 -- bow
 if focus then 
 
  function inc(n)
   h.ady= mid(-10,h.ady+n,10)
  end
  if btn(2) then inc(-1) end
  if btn(3) then inc(1) end
    
  if btn(5) then
  	focus=min(focus+1,focus_max)		
  else
  	shoot()
  	focus=nil
  	bowbk=4
  end
 else
  if btn(5) then
   focus=0
   h.ady=0
  end
 end
 
 -- shapeshift
 if btnp(3) and not focus then
  
  secure_swap(1)
  sfx(15)
  function pop()
   p=mkp(8,0,3,4,0.1+rnd(0.5))
   p.x=h.x+4+rand(8)-4 
   p.y=h.y+rand(8)-4
   p.frict=0.95
   p.vx=h.vx
   p.vy=h.vy
   p.we=-0.1
  end
  
  for i=0,8 do
   pop()
   dl(i*2,pop)
  end  
 end
 
 -- tipis
 ot=tipi
 tipi=nil

 for tp in atipis() do
  adx=abs(tp.x*8+4-h.x)
  ady=abs(tp.y*8-h.y)
  if adx<8 and ady<1 then
   tipi=tp
 
  end  
 end
 
 if ot!=tipi then
  if tipi then
   sfx(10)
  else
   sfx(11)
  end
 end
 
 
 -- fall dead
 if h.y > arena.h*8 then
  h.hp=0
 end
 
 -- quiver
 --
 if arrows==0 and not quiver then
  quiver=mke(14,0,0)
  quiver.y=-32
  quiver.x=(1+rand(arena.w-2))*8
  quiver.upd=upd_quiver
  quiver.jump=true
  quiver.shade=true  
  quiver.ondeath=function()
   quiver=nil
  end
 end
 
end

function upd_quiver(e)

 if e.jump then  
  dwn=true
  if chkp(e.x+4,e.y+8) then   
   e.jump=false
   e.life=120
   e.blink=40
  else  
   e.y+=1
  end
 else 
      
 end
 
 adx=abs(hero.x-e.x)
 ady=abs(hero.y-e.y)
 if adx<8 and ady<8 then
  sfx(21)
  kill(e)
  arrows=arrows_max
 end
 
end

function secure_swap(n)
 swap(n)

 while boss and hero.hid==boss.hid do
  swap(1)
 end
end
function swap(n)
 shid=(shid+n)%#spirits
 hero.hid=spirits[1+shid]
end

function atipis()
 if arena.bg>0 then return all({}) end
 return all(tipis)
end

function shoot()
 
 if focus <=1 or arrows==0 then 
  return 
 end
 
 sfx(1)
 refill=0
 if arena.bg>0 then 
  arrows-=1
 end
 local e=mke(-1,hero.x+4,hero.y+2)
 e.hid=hero.hid
 e.dmg=1
 e.col=true
 e.shade=true
 e.we=0.3--0.2
 e.size=1
 e.an=gaa(1)+0.5
 impulse(e,e.an,1+focus/2)

 e.ox=e.x-cos(e.an)*4
 e.oy=e.y-sin(e.an)*4
 e.x+=e.vx
 e.life=512
 
 e.tcol=ar_col
 e.blink=40
 e.dr=drar
 e.upd=upd_arrow
 e.fly=true
 
 e.impact=function()
  e.vx=0
  e.vy=0
  e.we=0
  e.col=false
  e.life=120
  e.grab=true
  e.fly=false
  e.impact=nil
  e.tcol=nil
  sfx(2)
 end
 
end

function drar(e)

 dx=cos(e.an)
 dy=sin(e.an)
 if e.bdy and e.flp!=boss.flp then
  dx*=-1
 end  
 local x=e.x+ddx
 local y=e.y+ddy
 sspr(8+(e.hid-32)*3,3,3,3,x+dx*7-1,y+dy*7-1)
 if not e.bdy then
  line(x,y,x+dx*2,y+dy*2,7)
 end
 x+=dx*2
 y+=dy*2
 line(x,y,x+dx*6,y+dy*6,4)
 
 if e.cad then
  spr(e.cad,x+dx*4-4,y+dy*4-4)
 end
 
end

function upd_arrow(e)

 -- fly
 if e.fly then
  dx=e.ox-e.x
  dy=e.oy-e.y
  e.an=atan2(dx,dy)
 end
 
 -- grab
 if e.grab then
  px=e.x+cos(e.an)*4
  py=e.y+sin(e.an)*4
  adx=abs(hero.x+4-px)
  ady=abs(hero.y+4-py)
  if adx<8 and ady<8 then
   sfx(17)
   arrows+=1
   kill(e)
  end 
 end
 
 -- boss 
 if e.bdy then
  p=ghpo(boss)
  e.x=boss.x+p.x+4-3
  e.y=boss.y+e.bdy+p.y
 

 end
 
end



function show_pix(x,y)
 p={x=x,y=y,col=7}
 add(pixels,p)
end

function ar_col(e)
 if not boss then return end
 
 adx=abs(boss.x+4-e.x)
 ady=abs(boss.y-e.y)
 if adx<4 and ady<7 then 
  hit(boss,e)
  e.impact(e)
  e.bdy=e.y-boss.y
  e.flp=boss.flp
  e.vis=boss.hp>0
 end
 
 for m in all(monsters) do
  adx=abs(m.x+4-e.x)
  ady=abs(m.y+4-e.y)  
  if adx<4 and ady<4 then 
   e.cad=m.cad
   e.vx*=0.75
   e.vy*=0.75
   --kill(e)
   destroy(m)
  end  
 end
 
end

function destroy(m)
 del(monsters,m)
 kill(m)
 
end

function get_dmg(hid)
 dmg=1
 return dmg
end




function draw_head(h)

 p=ghpo(h)
  
 p.x+=h.x+ddx-3
 p.y+=h.y+ddy-8

 function ghx(n)
  local sns=1
  local k=0
  if h.flp then 
   sns=-1 
   k=1
  end
  return p.x+n*sns-k
 end
 
 -- draw bow
 if h.hero then 
 if focus then 
  ac=4
  c=(focus-ac)/(focus_max-ac)
  c=max(c,0)
  cc=min(focus/ac,1)
  ac*=cc
  px=ghx(ac+6-(1-cc)*4-c*5)
  
  if arrows>0 then
   draim(h,ac+6-(1-cc)*4-c*5)
  else

  c=0
  end
  px=ghx(ac)
  spr(48+c*3,px,p.y+5+(h.ady/4),1,1,h.flp)

 elseif bowbk then
  bowbk-=0.2
  px=ghx(bowbk)
  spr(48,px,p.y+5,1,1,h.flp)
  if bowbk<=-1 then bowbk=nil end
 end
 end
 -- draw head
	px=ghx(1)
 spr(h.hid,px,p.y,1,1,h.flp) 
 
 -- draw wing
 if h.wings then
 	fr=53+tmod(3,2)
 	if bst==8 then fr=53 end
 	spr(fr,p.x-8,p.y+4,1,1,false)
 	spr(fr,p.x+7,p.y+4,1,1,true)
 end
 
end

function draim(h,dd)
 local an=gaa(0)
 dd+=4
 e={
  hid=hero.hid,
  an=an,
  x=h.x+4-cos(an)*dd,
  y=h.y+1-sin(an)*dd,
 }

 drar(e)
end

function gaa(dy)
 local sns=-1 
 if hero.flp then sns=1 end
 return atan2(sns*8,dy-hero.ady)
end

function explode(e)
 sfx(7)
 sfx(8)
 gmo=1
 kill(e)
 cex=e.x
 cey=e.y
  
 for i=0,15 do 
  an=i/16
  p=mke(173,cex,cey)
  impulse(p,an,3)
  p.life=60
  for k=0,2 do 
   p=mkp(8,0,3,4,0.1+rnd(0.25))
   impulse(p,an+rnd(i/16),3)
   p.frict=0.85+rnd(0.14)
   p.x=cex+4
   p.y=cey+4
  end
 end
 
 if boss.dead then
  tipis[boss.hid-32].ok=false
  del(spirits,boss.hid)
  tipis[6].ok=#spirits==1
 end
 dl(40,fade)
  
end

function fade(enter)
 fading=true
  hero.vx=0
  hero.vy=0
 if gmo and not enter then
  sfx(9)
 end

 local px=64
 local py=0
 function f(e)
  for x=0,15 do
   for y=0,15 do
    an=(atan2(x-8,y-8)-0.25)%1
   	k=an*5+e.t*0.5
			 fr=flr(110+k)
			 if enter then
			  fr=flr(126-k)
			 end
    fr=mid(116,fr,120)
    if fr==116 then 
     fr=0
    end
    mset(px+x,py+y,fr)
   end
  end
 end 
 function nxt()
  fading=false
  if gmo then
   restart()
  end
 end 
 
 d=dl(24,nxt,f)
 d.upd(d)
end

function restart()
 from=boss.hid-33
 reset()
 set_arena(0)

end





function _update()
 msg_a=nil
 msg_b=nil
 t+=1
	if mupd then mupd() end
  
end




function _draw()
 cls() 
 
 if mdr then mdr() end
 
 -- log 
 cursor(0,0)
 color(8+(t%8)) 
 color(8) 
 for l in all(logs) do
  print(l)
 end
end

function draw_spirits()
 if arena.bg!=0 then return end
 ec=20
 x=(128-((#spirits-1)*ec))*0.5
 k=0
 for sp in all(spirits) do
  k+=1
  by=flr(12.5+cos((t+k*8)/40)*4)
 
  function f() return rand(3)-1 end
  for i=0,2 do
   col=sget(24+i,6)
   circfill(x+f(),by+f(),7,col)
  end
  spr(sp,x-4,by-4)
  x+=ec
 end
end

function place_cam()
 roof=-128
 if arena.roof then 
  roof=min(arena.h-16,0)*8
 end
 cx=mid(0,hero.x-64,(arena.w-16)*8)
 cy=min(hero.y-64,(arena.h-16)*8)
 cy=max(roof,cy)
 if shake then  
  cy+=shake
  shake*=-0.75
  if abs(shake)<1 then 
   shake=nil 
  end  
 end 
 camera(cx,cy)
end

function log(str)
 add(logs,str)
 while #logs>20 do
  del(logs,logs[1])
 end
end

function dr_game()
sspr(8*arena.bg,64,8,8,0,0,128,128)
 
 -- camera
	place_cam()
 
 -- map under
 map(arena.x,arena.y,0,0,arena.w,arena.h) 
  
 -- tipis
 for tp in atipis() do
  if not tp.ok then
   for i=0,1 do
    fr=87-i*16
    if tp.n==5 then
     fr+=1
    end
    spr(fr,(tp.x+i)*8,tp.y*8)
   end
  end
 end
 
 -- ents
 foreach(ents,dre)
 
 -- refill
 c=1-refill/refill_max
 if c<1 then
  circ(hero.x+4,hero.y+4,c*64,7)
 end
 -- map above
 map(arena.x,arena.y,0,0,arena.w,arena.h,2) 
 
 -- blocks
 if t%4<2 then
  for bl in all(blocks) do
   spr(140,bl.x*8,bl.y*8)
  end
 end
 
 -- sel tipi
 c=flr(cos(t/32)*4+0.5)
 if tipi then
  fr=33+tipi.n
  msg_a="will you free"
  msg_b=names[tipi.n+1].." ?"
  if tipi.ok then
   fr=12
   msg_a="fight the"
   msg_b=names[tipi.n+1].." spirit"   
  end
  
  if tipi.n==5 then
   if tipi.ok then
    msg_a="you can rest"
    msg_b="for now"
   else
    msg_a="too many"
    msg_b="spirits here"
   end
  else
   for i=0,1 do 
    if i==0 then apal(1) end
    spr(fr,tipi.x*8+4-i,tipi.y*8+c-16-i)
    pal()
   end
  end
 

  
 end
 
 -- debug
 for p in all(pixels) do
  pset(p.x,p.y,8+(t%8))
 end
 pixels={}
 
 camera()
 -- inter
 if boss then
  a={hero,boss}
  for i=0,1 do
   e=a[1+i]
   py=9
   px=2+i*116
   spr(e.hid,px,1,1,1,i==1)   
   palt(14,true)
   palt(0,false)  
  	function f(n,flp)
   	sspr(0,72+n*2,8,2,px,py,8,2,false,flp)
    py+=2
   end
   f(0)
   for k=0,hp_max-1 do
    n=2+i
    if k<hp_max-e.dhp then 
     n=1 
    else
     if e.poison and k-e.poison<hp_max-e.dhp then n=4 end
    end    
    f(n)
   end
   f(0,true)
   palt()
  end
    
  for i=0,arrows_max-1 do
   if i==arrows then 
    apal(1)
   end
   spr(52,11,9+i*4-2)
  end
  pal()
  c=1-refill/refill_max
  if c<1 then
   rectfill(0,9+40*c,0,49,7)
  end
 end
 
 -- msg
 if msg_a then
  my=92
  apal(5)  
  ec =flr(2.5+cos(t/40)*2)
  dy=-ec/2
  map(16,24,32+ec,my+ec,8,4)
  pal()
  map(16,24,32,my+dy,8,4)  
  function prn(str,y)
   x=(128-#str*4)/2
   print(str,x,y+dy)
  end
  prn(msg_a,my+8)
  prn(msg_b,my+16)
 end
 
 -- spirits
 draw_spirits()
 
 -- fade
 if fading then
  map(64,0,0,0,16,16)
 end
 
end

names={"horse","eagle","snake","rabbit","vulture","secret"}