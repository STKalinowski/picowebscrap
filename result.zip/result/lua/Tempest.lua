
-- todo:
-- cancel/resume jobs in progress
--  don't change the tile until the job is complete
-- fire + light, fire will keep animals away
-- can't work in the dark (chopping,building)
-- combat system
-- fishing system
-- vines, used for making nets, strings, bindings for boatbuilding
-- win condition: build a boat and sail home (lots of wood, bindings, a sail somehow?)
--   would require lots of food and freshwater
--   required bits spread around the island, forces you to explore
-- stockpiles and limited carry capacity

function frnd(x)
	return flr(rnd(x))
end

debug=false

drops = {}
max_drops = 300
raining = 40
wind = 20
time = 0
frame = 0
menustack = {}
timeofday = 0
daylength = 60*3
noclip=false
jobs = {}
introfinished=false
tide = 1.0

mapsize_x,mapsize_y=128,64
mapdata = {}

-- objectives
found_water=false
found_food=false
found_shelter=false

function _init()
	cls()
	sfx(6)
	objects = {}
	player_items = {}
	local flask = invadd("flask")
	flask.volume = 8
	invadd("knife")

	player_hp,player_maxhp = 50,100
	player_fp,player_maxfp = 50,100
	player_resting = 0
	player_busy = 0
	player_maxbusy = nil
	player_hunger = 50
	player_thirst = 50
	player_bodytemp = 50 -- 50 = healthy, 0 = frozen, 100 = heatstroke
	objects[1]=player
	load_palettes()
	genmap()
end

function dialog(...)
	local pages = {...}
	for i=#pages,1,-1 do
		pushmenu({items={{pages[i],function() popmenu() end}},nocursor=true,dialog=true})
	end
end

function mset(x,y,t)
	mapdata[flr(y)*mapsize_x+flr(x)] = t
end

function mget(x,y)
	return mapdata[flr(y)*mapsize_x+flr(x)]
end

function _update()
	frame+=1
	if topmenu then
		local menu=topmenu
		if btnp(2) then
			menu.selected-=1
			sfx(2)
		end
		if btnp(3) then
			menu.selected+=1
			sfx(2)
		end
		if btnp(0) then
			menu.selected-=3
			sfx(2)
		end
		if btnp(1) then
			menu.selected+=3
			sfx(2)
		end
		if menu.selected > #menu.items then menu.selected = 1 end
		if menu.selected < 1 then menu.selected = #menu.items end
		if btnp(4) and menu.items[menu.selected] and menu.items[menu.selected][2] then
			-- activate menu item
			menu.items[menu.selected][2](menu.items[menu.selected])
			--sfx(3)
		end
		if btnp(5) then
			-- cancel
			popmenu()
			sfx(4)
		end
		return
	else
		if introfinished then
			-- handle player input
			if player_busy <= 0 and player_resting <= 0 and player_subx==0 and player_suby==0 then
				if btn(0) then player_tgtx=player_x-1
				elseif btn(1) then player_tgtx=player_x+1
				elseif btn(2) then player_tgty=player_y-1
				elseif btn(3) then player_tgty=player_y+1
				elseif btnp(5) then
					pushmenu(main_menu)
					sfx(4)
				elseif btnp(4) then
					pushmenu(action_menu())
				end
			end
		end
	end
	-- update objects
	player_update()
	-- add some drops
	if raining > 0 then
		for i=1,flr(raining) do
			drops[frnd(max_drops)] = {x=rnd(128+16)-16,y=rnd(128+10*8)-40,ttl=10}
			-- chance of filling a well
			for well in all(wells) do
				local r = rnd(10) > 8
				if r then well[3] = min(well[3]+1,20) end
			end
		end
	end
	-- update existing drops
	for i=1,max_drops do
		if drops[i] then
			if drops[i].ttl > 3 then
				drops[i].x = drops[i].x + wind + rnd(2)-1
				drops[i].y = drops[i].y + (timeofday==6 and 1+(rnd(2)-1) or 4)
			end
			drops[i].ttl = drops[i].ttl - 1
			if drops[i].ttl < 0 then
				drops[i] = nil
			end
		end
	end

	local dt = player_resting > 0 and 0.5 or 0.03
	wind += rnd(0.5)-0.25
	wind = clamp(wind,-12,12)
	raining += (rnd(1.0)-0.7) * dt
	raining = clamp(raining,-20,20)
	-- progress time in rest
	if player_resting > 0 then
		player_hunger += dt*0.1
		player_thirst += dt*0.1
		player_resting -= 0.5
		if player_hunger > 75 or player_thirst > 75 then
			player_resting = 0
			if player_hunger > 75 then
				dialog("i'm so hungry, i can't sleep!")
			else
				dialog("i'm so thirsty, i can't sleep!")
			end
		elseif player_resting <= 0 then
			dialog(player_fp > 75 and "ahh i feel much better!" or "i'm still so tired")
		end
		if player_thirst < 75 and player_hunger < 75 then
			player_hp += 0.25
		end
		-- cabin gives +1, shelter gives +0.2
		player_fp += (mget(player_x,player_y) == 108 and 1 or 0.25)

		if btnp(5) then
			player_resting = 0
		end

		-- grow stuff randomly at night
		-- pick a random coord and try to grow it
		for a=1,10 do
			local rx,ry = frnd(mapsize_x),frnd(mapsize_y)
			if is_tree(rx,ry) then
				-- leaves
				add_particle(rx*8+4+rnd(4)-2,ry*8+4-rnd(2),rnd(4)-2,rnd(2)-4,2,{3},true)
			end
		end
		if timeofday >= 2 and timeofday <= 4 then
			for a=1,10 do
				local rx,ry = frnd(mapsize_x),frnd(mapsize_y)
				local rt = mget(rx,ry)
				if rt == 124 then -- planted seed
					mset(rx,ry,104)
				elseif rt == 104 then -- grow seed
					mset(rx,ry,105)
				elseif rt == 105 then -- grow seed
					mset(rx,ry,106)
				elseif rt == 80 then -- grow fruit
					mset(rx,ry,randfromrange(81,83))
				elseif fget(rt,6) then -- is tree
					if rt == 112 then
						-- if it's a sapling, grow into a full tree
						mset(rx,ry,randfromrange(113,115))
					elseif valinrange(rt,113,115) then
						mset(rx,ry,randfromlist(80,87,88))
					else
						-- pick an adjacent grass tile and turn it into a sapling
						local adj = shuffle(adjacent(rx,ry))
						for i=1,#adj do
							if valinrange(adj[i][3],4,8) then
								if frnd(2) == 0 and valin(rt,65,87,84) then
									mset(adj[i][1],adj[i][2],24) -- mushroom
								else
									mset(adj[i][1],adj[i][2],112) -- sapling
								end
								break
							end
						end
					end
				end
			end
		end
	end
	-- progress time based on dt
	time += dt
	tide = (sin(time/daylength/2.0) + 1.0) * 0.5 + (player_resting == 0 and sin(time/daylength*60.0) * 0.125 or 0)
	-- update fires
	for k,v in pairs(fires) do
		if v.lit then
			if v.fuel < 0.5 then
				-- smouldering
				v.fuel -= dt*0.01
				add_particle(v.x*8+4+rnd(4)-2,v.y*8+4-rnd(2),0,0,1,{8,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6},true)
			elseif v.fuel < 1 or raining > 0 then
				v.fuel -= dt*0.21
				add_particle(v.x*8+4+rnd(4)-2,v.y*8+4-rnd(2),rnd(4)-2,rnd(2)-4,2,{9,6,6,6,6,6,6,6,6,6},true)
			else
				v.fuel -= dt*0.1
				add_particle(v.x*8+4+rnd(4)-2,v.y*8+4-rnd(2),rnd(4)-2,rnd(2)-4,4,{10,9,8,6,6,6,6,6,6,6},true)
			end
			if v.fuel <= 0 then
				v.lit = false
				v.fuel = 0
			end
		end
	end
	-- update particles
	for k,v in pairs(particles) do
		v.x+=v.xv*0.03 + (v.wind and wind*0.03 + rnd(0.5)-0.25 or 0)
		v.y+=v.yv*0.03 + (v.wind and rnd(0.5)-0.25 or 0)
		v.ttl -= 0.03
		if v.ttl < 0 then
			del(particles,v)
		end
	end

	player_last_hp = player_hp

	if player_resting > 0 then
		player_hunger += dt/3
		player_thirst += dt/3
		player_fp -= dt/3
	end

	if player_fp <= 0 then
		player_busy -= dt*0.5
	else
		player_busy -= dt
	end

	if player_busy > 0 then
		player_fp -= dt*0.5
		player_busy -= (player_fp > 0 and 0.03 or 0.01)
		update_job(player_x,player_y,player_fp > 0 and 0.03 or 0.01)
	end

	if player_busy <= 0 then
		player_maxbusy = nil
	end

	if player_fp <= 0 then
		player_hp -= 0.01
		player_fp = 0
	end

	-- modify body temperature
	if valin(mget(player_x,player_y),108,109,63) and player_busy <= 0 then
		-- in shelter move towards 50
		player_bodytemp = lerp(player_bodytemp,50,0.03)
	else
		-- moves towards airtemperature
		player_bodytemp = lerp(player_bodytemp,airtemperature(),0.03)
	end

	if player_bodytemp < 25 then
		player_hp -= 0.06
	elseif player_bodytemp < 45 then
		player_hp -= 0.03
	end

	player_hp = clamp(player_hp,0,player_maxhp)
	player_fp = clamp(player_fp,0,player_maxfp)
	if player_hp < 10 and player_last_hp >= 10 then
		dialog("uhh i'm dying!")
	elseif player_hp < 5 and player_last_hp >= 5 then
		dialog("i can't go on!")
	end

	if player_hp == 0 then
		gameover()
	end
end

function gameover()
	_update = function()
		if btnp(4) or btnp(5) then
			reload()
			run()
		end
	end
	_draw = function()
		cls()
		logo()
		pal()
		color(7)
		print("game over",44,20)
		print("you survived "..flr(time/daylength).." days",26,50)
		print("press x to restart",24,113)
	end
end

pal_sprites = {
	[0] = 201,
	201.5,
	202,
	202.5,
	203,
	203.5
}

function load_palettes()
	palettes = {}
	for pal=0,5 do
		local sid,palette = pal_sprites[pal],{}
		local y = flr(sid/16)*8
		if sid%1 == 0.5 then y+=4 end
		sid = flr(sid)
		local x = (sid*8)%128
		for i=0,16 do
			palette[i] = sget(x+(i%8),y+flr(i/8))
		end
		palettes[pal] = palette
	end
end

function setpalette(palid)
	palette = palettes[palid]
	for i=0,15 do
		pal(i,palette[i])
	end
end

function _draw()
	cx = player_x*8+player_subx-64
	cy = player_y*8+player_suby-64
	timeofday = flr((time%daylength)/(daylength/6))
	setpalette(timeofday)
	rectfill(0,0,128,128,12)
	camera(cx,cy)
	local ox = cx%8
	local oy = cy%8
	local x = flr(cx/8)
	local y = flr(cy/8)
	palt(0,false)
	--map(x,y,cx-ox,cy-oy,min(17,128-x),min(17,64-y))
	for my=cy/8,cy/8+16 do
		if my < mapsize_y and my >= 0 then
			for mx=cx/8,cx/8+16 do
				if mx < mapsize_x and mx >= 0 then
					local t = mget(mx,my)
					spr(t, mx*8-ox, my*8-oy)
				end
			end
		end
	end
	palt(0,true)
	-- draw fringes
	if not debug then
		local x,y,f
		local sandfringe,grassfringe
		for ty=flr(cy/8),flr(cy/8)+17 do
			for tx=flr(cx/8),flr(cx/8)+17 do
				x,y=tx*8,ty*8
				if inmap(tx,ty) then
					sandfringe,grassfringe  = fringeget(tx,ty)
					-- draw sandfringe
					if sandfringe then
						pal(7,palette[7])

						pal(12,palette[6])
						pal(13,palette[6])
						pal(14,palette[6])
						pal(15,palette[6])

						palt(12,tide < 0.75)
						palt(13,tide < 0.5)
						palt(14,tide < 0.25)
						palt(15,tide < 0.125)
						spr(sandfringe,x,y)
						palt()
					end
					-- draw grassfringe
					if grassfringe then
						pal(7,palette[3])
						pal(15,palette[5])
						palt(12,true)
						palt(13,true)
						palt(14,true)
						palt(15,true)
						spr(grassfringe,x,y)
						palt()
					end
				end
			end
		end
	end
	-- draw particles
	pal(9,9)
	pal(10,10)
	pal(8,8)
	for v in all(particles) do
		--pset(v.x,v.y,flr(8+rnd(2)))
		local color = v.colors[flr(((v.maxttl-v.ttl)/v.maxttl)*#v.colors)+1]
		pset(v.x,v.y,color)
	end

	setpalette(timeofday)
	-- draw player
	player_draw()
	-- draw drops
	camera()
	if timeofday != 0 then
		pal(12,palette[16])
	end
	for i=1,max_drops do
		if drops[i] then
			if drops[i].ttl < 3 then
				spr(74+drops[i].ttl,drops[i].x+4,drops[i].y+4)
			else
				pset(drops[i].x,drops[i].y,12)
			end
		end
	end
	drawgui()
end

-- characters

function getitem(itemname,qty)
	qty = qty or 1
	for pi in all(player_items) do
		if pi.kind.name == itemname then
			if pi.qty < qty then
				return nil
			else
				printh("found item "..pi.kind.name)
				return pi
			end
		end
	end
	return nil
end

function invadd(itemname,qty)
	qty = qty or 1
	printh("invadd: " .. itemname .. " x ".. qty)
	for kind in all(items) do
		if kind.name == itemname then
			local added = false
			for pi in all(player_items) do
				if pi.kind.name == itemname then
					pi.qty += qty
					printh("found increased qty")
					return pi
				end
			end
			local item = {kind=kind,qty=qty}
			add(player_items, item)
			printh("added new item")
			return item
		end
	end
end

function hasitem(itemname,qty)
	qty = qty or 1
	for pi in all(player_items) do
		if pi.kind.name == itemname then
			if pi.qty >= qty then
				return true
			end
			break
		end
	end
	return false
end

function invconsume(itemname,qty)
	qty = qty or 1
	for pi in all(player_items) do
		if pi.kind.name == itemname then
			if pi.qty >= qty then
				pi.qty -= qty
				if pi.qty <= 0 then
					del(player_items,pi)
				end
				return
			end
			break
		end
	end
end

function busy(howlong)
	player_busy = howlong
	player_maxbusy = howlong
end

function setpos(x,y)
	player_x=flr(x)
	player_y=flr(y)
	player_tgtx=player_x
	player_tgty=player_y
	player_subx=0
	player_suby=0
end

riseanimation = {
	49,
	33,
	17,
	1,
	0,
	2,
	18
}

function player_draw()
	-- first 5 seconds, show us getting up from the sand
	local s = 0
	if not introfinished then
		s = riseanimation[flr(frame/30)+1]
		if frame == 210 then
			dialog("where am i?","what happened to me?","i am starving!","i should find some food","at least i have water...","but not much...")
			introfinished = true
		end
	end
	if player_resting > 0 then
		pal(7,7)
		color(7)
		print(sub("zzz",flr(player_resting/10)),player_x*8,player_y*8)
		return
	end

	if is_water(player_x,player_y) then
		spr(3,player_x*8+player_subx,player_y*8+player_suby-2)
	else
		-- shadow
		palt(0,false)
		palt(8,true)
		spr(110,player_x*8+player_subx,player_y*8+player_suby)
		palt()
		-- sprite
		if (player_subx != 0 or player_suby != 0) then
			-- walking
			s = flr(frame/8)%3 * 16
		end
		spr(s,player_x*8+player_subx,player_y*8+player_suby-2)
	end

	-- draw job progress bar todo: move this to the job gui
	if player_busy > 0 then
		pal(8,8)
		color(8)
		rectfill(player_x*8,player_y*8+6,player_x*8+8-8*(player_busy/player_maxbusy),player_y*8+8)
	end

end

function player_update()
	if abs(player_subx) > 0 or abs(player_suby) > 0 then
		if not noclip and not is_walkable(player_tgtx,player_tgty) then
			setpos(player_x,player_y)
			sfx(0)
			return
		elseif abs(player_subx) == 2 or abs(player_suby) == 2 then
			sfx(1)
		end
	end
	local speed = 1
	local terrain = mget(player_x,player_y)
	if valin(terrain,9,10,11,25,26,27,41,42,43,2) then speed = 2 end
	if player_x+player_subx/8 < player_tgtx then
		player_subx=player_subx+speed
		if player_subx>=8 then
			player_x=player_x+1
			player_subx=0
		end
	elseif player_x-player_subx/8 > player_tgtx then
		player_subx-=speed
		if player_subx<=-7 then
			player_x-=1
			player_subx=0
		end
	elseif player_y+player_suby/8 < player_tgty then
		player_suby+=speed
		if player_suby>=8 then
			player_y+=1
			player_suby=0
		end
	elseif player_y-player_suby/8 > player_tgty then
		player_suby-=speed
		if player_suby<=-7 then
			player_y-=1
			player_suby=0
		end
	end
	if frame % 4 == 0 and player_x ~= player_tgtx or player_y ~= player_tgty then
		if is_sand(player_x,player_y) then
			add_particle(player_x*8+player_subx + 4 + sin(frame / 8),player_y*8+player_suby + 4 + cos(frame / 16),0,0,5,{5},false)
		end
	end
	if abs(player_subx)==8 then player_subx=0 end
	if abs(player_suby)==8 then player_suby=0 end
end

-- menus

main_menu = {
	items={
		{"action",function() pushmenu(action_menu()) end},
		{"items",function() pushmenu(inventory_menu()) end},
		{"build",function() pushmenu(build_menu()) end},
		{"craft",function() pushmenu(craft_menu()) end},
	},
	selected=1
}

-- on_progress is called each update while the job is being worked on
function start_job(x,y,on_progress)
	add(jobs,{x,y,on_progress})
end

function update_job(x,y,dt)
	for job in all(jobs) do
		if player_x == job[1] and player_y == job[2] then
			if job[3](dt) then
				del(jobs,job)
			end
		end
	end
end

function is_thing_buildable(b)
	local tocheck = {{player_x,player_y,mget(player_x,player_y)}}
	local ok_to_build_here = {}
	if b.adjacent then
		for adj in all(adjacent(player_x,player_y)) do
			push(tocheck,adj)
		end
	end
	local buildcheck = b.buildcheck and b.buildcheck or is_buildable
	while #tocheck > 0 do
		local t = pop(tocheck)
		if not buildcheck(t[1],t[2]) then
		else
			add(ok_to_build_here,t)
		end
	end
	if #ok_to_build_here == 0 then return false end
	if b.consumes then
		-- check we can satisfy all the things
		for cons in all(b.consumes) do
			if not getitem(cons[1],cons[2]) then
				return false
			end
		end
	end
	-- return a list of the coords where it can be built
	return ok_to_build_here
end

function is_thing_craftable(i)
	for cons in all(i.craft) do
		local c = getitem(cons[1],cons[2])
		if not c then
			return false
		end
	end
	return true
end

function craft_menu()
	local m={items={}}
	for i in all(items) do
		if i.craft then
			if is_thing_craftable(i) then
				add(m.items,{i.name,function()
					for cons in all(i.craft) do
						invconsume(cons[1], cons[2])
					end
					busy(1.0)
					invadd(i.name)
					popall()
				end})
			else
				add(m.items,{i.name,function()
					local items = {{"requires:"}}
					for cons in all(i.craft) do
						local my = getitem(cons[1])
						add(items,{cons[1].." x "..(my and my.qty or 0).."/"..cons[2]})
					end
					pushmenu({items=items})
				end,disabled=true})
			end
		end
	end
	return m
end

function build_menu()
	local x,y = player_x,player_y
	local m={items={}}
	-- if you're adjacent to a river then see if you can build a bridge
	local adj = adjacent(x,y)
	for b in all(buildables) do
		local can_build = is_thing_buildable(b)
		if can_build then
			for loc in all(can_build) do
				add(m.items,{b[1],function()
					for cons in all(b.consumes) do
						invconsume(cons[1],cons[2])
					end
					player_busy=b.time
					player_maxbusy=b.time
					b.oncomplete(loc[1],loc[2])
					popall()
				end,target={loc[1],loc[2]}})
			end
		else
			add(m.items,{b[1],function()
				local items = {{"requires:"}}
				for cons in all(b.consumes) do
					local my = getitem(cons[1])
					add(items,{cons[1].." x "..(my and my.qty or 0).."/"..cons[2]})
				end
				pushmenu({items=items})
			end,disabled=true})
		end
	end
	if count(m.items) == 0 then
		add(m.items,{"can't build here"})
	end
	return m
end

function add_action(m,name,oncompletion,x,y)
	for i in all(m.items) do
		if i[1] == name then
			add(i.targets,{x,y,oncompletion})
			return
		end
	end
	-- not already there
	local item = {name}
	item[2] = function()
		-- choose from targets if there's more than one
		if  #item.targets == 1 then
			item.targets[1][3]()
			return
		end
		local m2 = {items={}}
		for i in all(item.targets) do
			add(m2.items,{name,i[3],target={i[1],i[2]}})
		end
		pushmenu(m2)
	end
	item.targets={{x,y,oncompletion}}
	add(m.items,item)
end

function action_menu()
	-- check what the tiles around x,y are to determine
	-- context based actions
	local px,py = player_x, player_y
	local m = {items={},title="action"}
	for s in all(adjacent(px,py,true)) do
		local x = s[1]
		local y = s[2]
		local here = x == px and y == py
		local s = s[3]
		if s then
			if here and valin(s,108,109,63) then
				add_action(m,"rest",function()
					pushmenu({items={
						{"rest until morning",function()
							player_resting = daylength-(timeofday+1)*(daylength/6)
							popall()
						end},
						{"rest for 8 hours",function()
							player_resting = daylength/3
							popall()
						end},
						{"rest for 4 hours",function()
							player_resting = daylength/6
							popall()
						end}
					}})
				end,x,y)
			end
			if s == 67 then
				local fire = fires[x..","..y]
				local wood = getitem('log')
				if wood then
					add_action(m,"add wood "..flr(fire.fuel).."/10",function()
						busy(2)
						popall()
						fire.fuel += 1
						invconsume('log')
					end)
				end
				if fire.lit == false then
					add_action(m,"light fire "..flr(fire.fuel)..'/10',function()
						busy(2)
						popall()
						fire.lit = true
					end)
				else
					add_action(m,"put out fire "..flr(fire.fuel)..'/10',function()
						busy(2)
						popall()
						fire.lit = false
					end)
				end
			end
			if here and valinrange(s,58,60) then
				add_action(m,"get stone",function()
					busy(2)
					popall()
					invadd("stone",frnd(1)+1)
					if s==60 then
						-- turn three stones in to two stones
						mset(x,y,59)
					elseif s==59 then
						-- turn two stones into one stone
						mset(x,y,58)
					elseif s==58 then
						-- turn stone into grass
						mset(x,y,randfromlist(4,8))
					end
				end,x,y)
			end
			if getitem("knife") and here and mget(x,y) == 112 then
				add_action(m,"cut vine",function()
					mset(x,y,4+frnd(3))
					sfx(7)
					busy(0.2)
					popall()
					invadd("vine")
				end,x,y)
			end
			if getitem("knife") and here and mget(x,y) == 113 then
				add_action(m,"cut stick",function()
					mset(x,y,4+frnd(3))
					sfx(7)
					busy(0.2)
					popall()
					invadd("stick")
				end,x,y)
			end
			if getitem("axe") and is_tree(x,y) then
				add_action(m,"chop trees",function()
					local t = mget(x,y)
					if t == 65 then
						mset(x,y,84)
					elseif t == 84 then
						mset(x,y,87)
					else
						mset(x,y,40)
					end
					sfx(7)
					busy(4)
					popall()
				end,x,y)
			end
			if getitem("axe") and here and valinrange(s, 56, 57) then
				add_action(m,"clear stumps",function()
					mset(x,y,4+frnd(4))
					sfx(7)
					busy(4)
					popall()
				end,x,y)
			end
			if getitem("hoe") and here and valinrange(s, 4, 8) then
				add_action(m,"till earth",function()
					mset(x,y,103)
					sfx(7)
					busy(2)
					popall()
				end,x,y)
			end
			if getitem("scythe") and valin(s, 106, 107) then
				add_action(m,"harvest",function()
					mset(x,y,103)
					sfx(7)
					busy(2)
					popall()
					invadd("grain",frnd(2)+3)
				end,x,y)
			end
			if here and valin(s,40,109) then
				add_action(m,"get logs",function()
					if getitem("log",10) then
						dialog("i can't carry any more")
					else
						mset(x,y,randfromlist(56,57))
						busy(0.5)
						invadd("log",3)
						popall()
					end
				end,x,y)
			end
			if here and s==93 then
				add_action(m,"salvage",function()
					mset(x,y,71)
					busy(0.5)
					invadd("stick",1+frnd(2))
					popall()
					if frnd(5) == 0 then
						-- get an item!
						local r = frnd(2)
						if r == 0 then
							invadd("grain")
							dialog("you found some grain")
						elseif r == 1 then
							invadd("vine")
							dialog("you found a vine")
						end
					else
						dialog("just some sticks.")
					end
				end,x,y)
			end
			if valinrange(s,81,83) then
				add_action(m,"pick fruit",function()
					mset(x,y,80)
					busy(1)
					invadd("fruit",1)
					popall()
				end,x,y)
			end
			if here and s == 24 then
				add_action(m,"pick mushroom",function()
					mset(x,y,4+frnd(4))
					busy(1)
					invadd("mushroom",1)
					popall()
				end,x,y)
			end
		end
	end
	if count(m.items) == 0 then add(m.items,{"nothing to do"}) end
	return m
end

inventory_menu = function()
	local m = {title="items",items={}}
	for pi in all(player_items) do
		local func = pi.kind.func and function() pi.kind.func(pi) end or nil
		if pi.kind.unique then
			add(m.items,{pi.kind.name, func})
		else
			add(m.items,{pi.kind.name .. " " .. pi.qty, func})
		end
	end
	return m
end

-- gui

function draw9(x,y,w,h)
	-- top row
	spr(128,x,y)
	for ix=x+8,x+w-9,8 do
		spr(129,ix,y)
	end
	spr(130,x+w-8,y)
	-- middle
	for iy=y+8,y+h-9,8 do
		spr(144,x,iy)
		for ix=x+8,x+w-8,8 do
			spr(145,ix,iy)
		end
		spr(146,x+w-8,iy)
	end
	-- bottom
	spr(160,x,y+h-8)
	for ix=x+8,x+w-9,8 do
		spr(161,ix,y+h-8)
	end
	spr(162,x+w-8,y+h-8)
end

function drawhand(x,y)
	palt(8,true)
	palt(0,false)
	spr(126,x+frame/8%2,y)
	palt()
end

function drawmenu(menu,x,y,w,h)
	local rows = max(min(#menu.items,3),1)
	if menu.dialog then
		rows = clamp(flr(#menu.items[1]/10),1,3)
		pal(4,7)
		pal(5,1)
		pal(15,1)
		pal(7,1)
		draw9(x+4,y,w-8,min(h,rows*8+8))
	else
		pal(7,7)
		draw9(x,y,w,min(h,rows*8+8))
	end

	local row = 0
	local col = 0
	-- menu items
	local i=1
	for item in all(menu.items) do
		-- if it's functional show brighter
		if item[2] == nil or item.disabled then color(5) else color(7) end
		print(item[1],8+(col*48)+(menu.dialog and 4 or 0),y+row*8+4)
		if item[3] then
			print(item[3],((col+1)*48)-8,y+row*8+4)
		end
		row+=1
		if row >= rows then
			row = 0
			col+=1
		end
		if i == menu.selected and item.target then
			-- point at target
			if not (item.target[1] == player_x and item.target[2] == player_y) then
				local x,y = item.target[1]*8-cx-6, item.target[2]*8-cy+2
				drawhand(x,y)
			end
		end
		i+=1
	end
	-- hand cursor
	if not menu.nocursor and menu==topmenu then
		col=flr((menu.selected-1)/rows)
		row=(menu.selected-1)%rows
		local x,y = col*48, y+row*8+4
		drawhand(x,y)
	end
end

function airtemperature()
	local t = 50
	if raining >= 1 then t-=5 end
	if raining > 4 then t-=10 end
	if timeofday >= 2 and timeofday <= 4 then t-=5 end
	if timeofday == 3 then t-=10 end
	return t
end

function drawgui()
	draw9(128-34,128-11,40,21)
	color(1)
	rectfill(128-28,128-3,128-28+26,128-4)
	rectfill(128-28,128-6,128-28+26,128-7)
	-- health
	color(player_hp < 10 and frame%4 == 0 and 7 or 8)
	rectfill(128-28,128-3,128-28+26*(player_hp/player_maxhp),128-4)
	-- stamina
	color(11)
	rectfill(128-28,128-6,128-28+26*(player_fp/player_maxfp),128-7)

	pal(8,8)
	pal(9,9)

	if player_hunger > 50 then
		color(player_hunger > 75 and 8 or 9)
		printr("hungry",126,12)
	end
	if player_thirst > 50 then
		color(player_thirst > 75 and 8 or 9)
		printr("thirsty",126,12+8)
	end
	if player_fp < 10 then
		color(player_fp <= 0 and 8 or 9)
		printr("exhausted",126,12+16)
	end
	if player_bodytemp < 45 then
		color(player_bodytemp < 25 and 8 or 9)
		printr("cold",126,12+24)
	end

	draw9(128-30,-3,38,13)
	color(1)
	print("day "..flr(time/daylength)+1,128-25,1)

	local yoff=0
	for menu in all(menustack) do
		drawmenu(menu,0,128-(8*4+(yoff)),128,8*4)
		if not menu.dialog then yoff-=1 end
	end
end

function pushmenu(menu)
	assert(menu)
	add(menustack,menu)
	topmenu = menu
	menu.selected = menu.selected or 1
end

function popmenu()
	if topmenu then
		del(menustack,topmenu)
	end
	topmenu = nil
	for menu in all(menustack) do
		topmenu = menu
	end
end

function popall()
	while topmenu do
		popmenu()
	end
end

-- map

function is_walkable(x,y)
	if tide > 0.5 and mget(x,y) == 31 then
		return true
	end
	return not fget(mget(x,y),0)
end

function is_water(x,y)
	return fget(mget(x,y),1)
end

function is_ocean(x,y)
	local s = mget(x,y)
	return fget(s,1) and not fget(s,3)
end

function is_grass(x,y)
	return fget(mget(x,y),4)
end

function is_tree(x,y)
	return fget(mget(x,y),6)
end

function is_sand(x,y)
	return fget(mget(x,y),5)
end

function is_freshwater(x,y)
	return fget(mget(x,y),3)
end

function is_buildable(x,y)
	return fget(mget(x,y),2)
end

fires = {}

-- all items in game
items = {
	{name="flask",func=function(item)
		-- drink
		-- fill
		local m = {items={}}
		if is_adjacent_to(is_freshwater,player_x,player_y) then
			add(m.items,{"fill",function()
				item.volume = 8
				busy(0.5)
				popall()
			end})
		end
		if item.volume > 0 then
			add(m.items,{"drink "..item.volume.."/8",function()
				item.volume -= 1
				player_thirst -= 10
				busy(0.2)
				popall()
			end})
		else
			add(m.items,{"empty",function() end})
		end
		pushmenu(m)
	end,unique=true},
	{name="knife",unique=true},
	{name="axe",unique=true,craft={{"stick",1},{"stone",1},{"vine",1}}},
	{name="hoe",unique=true,craft={{"stick",1},{"stone",1},{"vine",2}}},
	{name="vine"},
	{name="stick",func=function(item)
		-- sharpen
	end},
	{name="stone",func=function(item)
		-- sharpen
	end},
	{name="log"},
	{name="mushroom",func=function(item)
		pushmenu({items={{
			"eat",function()
				invconsume(item.kind.name)
				busy(0.2)
				player_hunger -= 5
				popall()
			end}}})
	end},
	{name="fruit",func=function(item)
		pushmenu({items={{
			"eat",function()
				invconsume(item.kind.name)
				busy(0.2)
				player_hunger -= 10
				popall()
			end}}})
	end},
	{name="berry",func=function(item)
		pushmenu({items={{
			"eat",function()
				invconsume(item.kind.name)
				busy(0.2)
				player_hunger -= 5
				popall()
			end}}})
	end},
	{name="grain",func=function(item)
		local m = {items={}}
		if mget(player_x,player_y) == 103 then
			add(m.items,{
				"plant",function()
					invconsume(item.kind.name)
					busy(2.0)
					mset(player_x,player_y,124)
					popall()
				end})
		end
		pushmenu(m)
	end},
}

buildables = {
	{"fire",consumes={{"log",3}},time=5,oncomplete=function(x,y)
		mset(x,y,67)
		fires[x..","..y] = {x=x,y=y,fuel=3,lit=false}
	end},
	{"shelter",consumes={{"stick",5}},time=5,oncomplete=function(x,y) mset(x,y,109) end},
	{"cabin",consumes={{"log",10},{"stone",3}},time=10,oncomplete=function(x,y) mset(x,y,108) end},
--	{"road",consumes={{"stone",2}},time=5,oncomplete=function(x,y) mset(x,y,10) end},
--	{"fence",consumes={{"wood",2}},time=5,oncomplete=function(x,y) mset(x,y,38) end},
--	{"gate",consumes={{"wood",3}},time=5,oncomplete=function(x,y) mset(x,y,53) end},
--	{"farm",requires={"hoe"},time=10,oncomplete=function(x,y) mset(x,y,52) end},
	{"well",consumes={{"stone",10}},requires={"shovel"},time=50,oncomplete=function(x,y)
		mset(x,y,116)
		add(wells,{x,y,0})
	end},
	{"bridge",adjacent=true,buildcheck=function(x,y)
		-- check that it's a river and has land on two opposing sides
		local f = fringe(x,y,inv(is_water))
		return valin(mget(x,y),30,46) and valin(f,152,180)
	end,consumes={{"log",10}},time=10,oncomplete=function(x,y)
		local f = fringe(x,y,inv(is_water))
		mset(x,y,f==152 and 89 or 90)
	end}
}

wells = {}

function distance(x,y)
	return abs(x)+abs(y)
	--local dd = x*x+y*y
	--if dd <= 0 then return 0 end
	--return sqrt(dd)
end

function getelevation(x,y)
	local v = fractal_noise_2d(6,0.65,1/40,x+mapseed,y+mapseed)
	local d = distance(x/2-mapsize_x/4,y-mapsize_y/2)
	if x < 2 or x > mapsize_x - 2 then return 0 end
	if y < 2 or y > mapsize_y - 2 then return 0 end
	return v - d*d*0.00015
end

function getlakes(x,y)
	local v = getelevation(x,y)
	if v > 0.2 then
		return fractal_noise_2d(6,0.65,1/4,x+mapseed,y+mapseed) > 0.2
	end
	return false
end

function floodfunc(x,y,comp,action)
	local queue = {vec(x,y)}
	local seen = {}
	while #queue > 0 do
		local v = pop(queue)
		local x,y = vec2xy(v)
		if not (x <= 0 or x >= mapsize_x or y <= 0 or y >= mapsize_y) then
			push(seen,v)
			if action(x,y) == true then break end
			for adj in all(adjacent(x,y)) do
				local ax,ay = adj[1],adj[2]
				local av = vec(ax,ay)
				if not inlist(seen,av) and comp(ax,ay) then
					push(queue,av)
				end
			end
		end
	end
end

function find_starting_island(x,y)
	-- return how many walkable land tiles
	-- are connected to this one
	local land = 0
	local has_wood = false
	local has_stone = false
	local has_freshwater = false
	floodfunc(x,y,inv(is_water),function(x,y)
		local t = mget(x,y)
		land+=1
		if is_adjacent_to(is_freshwater,x,y) then has_freshwater = true
		elseif is_tree(x,y) then has_wood = true
		elseif valin(t,36,53,58) then has_stone = true
		end
		if land > 10 and has_wood and has_stone and has_freshwater then return true end
	end)
	if land > 10 and has_wood and has_stone and has_freshwater then return true end
	return false
end

function adjacent(x,y,incself)
	-- returns all the adjacent tiles
	local adj = {}
	if incself then add(adj,{x,y,mget(x,y)}) end
	local v = {{x-1,y},{x,y-1},{x+1,y},{x,y+1}}
	for i in all(v) do
		if inmap(i[1],i[2]) then
			add(adj,{i[1],i[2],mget(i[1],i[2])})
		end
	end
	return adj
end

particles = {}

function add_particle(x,y,xv,yv,ttl,colors,wind)
	particles[#particles+1] = {
		x=x,y=y,xv=xv,yv=yv,ttl=ttl,maxttl=ttl,colors=colors,wind=wind
	}
end

function fringe(x,y,comp)
	if not inmap(x,y) then return nil end
	local xp1 = x+1
	local xm1 = x-1
	local yp1 = y+1
	local ym1 = y-1
	local n  = comp(x  ,ym1)
	local ne = comp(xp1,ym1)
	local e  = comp(xp1,y)
	local se = comp(xp1,yp1)
	local s  = comp(x  ,yp1)
	local sw = comp(xm1,yp1)
	local w  = comp(xm1,y)
	local nw = comp(xm1,ym1)
	local ne = comp(xp1,ym1)
	-- returns the fringe sprite to use based on surrounding tiles

	-- 4 edges
	if n and e and s and w then
		return 148 -- surrounded

	-- 3 edges
	elseif n and e and w then
		return 136
	elseif e and s and w then
		return 168
	elseif n and w and s then
		return 179
	elseif n and s and e then
		return 181

	-- 2 edges opposite
	elseif e and w then
		return 152 -- open at n-s
	elseif n and s then
		return 180 -- open at e-w

	-- 2 edges adjacent
	elseif n and w then
		if se then
			return 140
		end
		return 134 -- open at s-e
	elseif n and e then
		if sw then
			return 141
		end
		return 135 -- open at s-w
	elseif s and e then
		if nw then
			return 155
		end
		return 151 -- open at n-e
	elseif s and w then
		if ne then
			return 171
		end
		return 150 -- open at n-w

	-- one edge
	elseif n then
		if sw and se then
			return 138
		elseif sw then
			return 170
		elseif se then
			return 143
		else
			return 132
		end
	elseif e then
		if nw and sw then
			return 187
		elseif nw then
			return 186
		elseif sw then
			return 159
		else
			return 149
		end
	elseif s then
		if nw and ne then
			return 184
		elseif nw then
			return 158
		elseif ne then
			return 185
		else
			return 164
		end
	elseif w then
		if ne and se then
			return 153
		elseif ne then
			return 142
		elseif se then
			return 169
		else
			return 147
		end
	-- 4 corners
	elseif ne and se and nw and sw then
		return 188
	-- 3 corners
	elseif nw and ne and sw then
		return 173
	elseif nw and ne and se  then
		return 174
	elseif nw and se and sw  then
		return 189
	elseif ne and se and sw  then
		return 190
	-- 2 corners
	-- opposite
	elseif ne and sw then
		return 137
	elseif nw and se then
		return 139
	-- adjacent
	elseif nw and ne then
		return 156
	elseif nw and sw then
		return 157
	elseif se and sw then
		return 172
	elseif ne and se then
		return 154
	-- single corner
	elseif ne then
		return 133
	elseif se then
		return 165
	elseif sw then
		return 163
	elseif nw then
		return 131
	end
	return nil
end

function logo()
	sspr(0,96,56,32,0,64,128,64)
	palt(8,true)
	palt(0,false)
	sspr(56,96,16,16,128-20,128-20)
	palt()
end

function genmap()
	potential_starts = {}
	color(7)
	flip()
	-- draw logo
	logo()
	fringecache_sand = {}
	fringecache_grass = {}
	mapseed = rnd(1000)
	genperms()
	local watertiles = 0
	local groundtiles = 0
	local freshwatertiles = 0
	local lakes = {}

	color(7)
	print("drifting at sea...",32,113)

	formap(function(x,y)
		local elevation = getelevation(x,y)
		local t
		if elevation <= 0 then
			t = 30 -- ocean
			watertiles+=1
		elseif elevation < 0.05 then
			-- coast
			t = randfromlist(70,71)
			groundtiles+=1
		else
			groundtiles+=1
			-- land
			t = randfromrange(4,8)
			local lake = getlakes(x,y)
			if lake then
				t = 46
				lakes[#lakes+1] = vec(x,y)
				freshwatertiles+=1
			else
				local veg = fractal_noise_2d(6,1,0.07,x+mapseed,y+mapseed)
				if veg > 0.2 then
					t = 65 -- thick
				elseif veg > 0.05 then
					t = randfromrange(112,115) -- thin
				elseif veg > 0 then
					t = randfromrange(80,88) -- thin
				else
					-- no veg, maybe some stone
					local stone = fractal_noise_2d(8,0.7,0.2,x+mapseed,y+mapseed)
					if stone > 0.3 then
						t = randfromlist(61,61,62,62,63)
					elseif stone > 0.2 then
						t = randfromrange(58,60)
					end
				end
			end
		end
		mset(x,y,t)
		if elevation <= 0 then
			pset(x,y+4,15)
		elseif elevation < 0.05 then
			pset(x,y+4,1)
		else
			pset(x,y+4,5)
		end
	end)

	while freshwatertiles < 3 do
		local rx,ry = frnd(mapsize_x),frnd(mapsize_y)
		if is_grass(rx,ry) then
			mset(rx,ry,46)
			freshwatertiles+=1
		end
	end
	-- if not enough land, retry
	if groundtiles / (watertiles+groundtiles) < 0.15 then
		return genmap()
	end

	--draw9(18,74,100,12)
	--color(7)
	--print("filling oceans...",24,77)
	--floodfill(1,1,30) -- convert freshwater to ocean

	placerivers(lakes)


	-- generate a fringecache
	formap(function(x,y)
		-- add in low tide water
		if is_ocean(x,y) then
			if is_adjacent_to(is_sand, x,y) then
				mset(x,y,31)
			end
		end
		-- add in some driftwood
		if is_sand(x,y) and frnd(25) == 0 then
			mset(x,y,93)
			add(potential_starts, {x,y})
		end
		if is_water(x,y) then
			fringeset(x,y,fringe(x,y,is_sand),fringe(x,y,is_grass))
		elseif is_sand(x,y) then
			fringeset(x,y,nil,fringe(x,y,is_grass))
		end
	end)

	if not findstart() then return genmap() end
end

function fringeindex(x,y)
	return flr(y)*mapsize_x+flr(x)
end

function fringeset(x,y,f1,f2)
	local c = fringeindex(x,y)
	fringecache_sand[c] = f1
	fringecache_grass[c] = f2
end
function fringeget(x,y)
	local c = fringeindex(x,y)
	return fringecache_sand[c],fringecache_grass[c]
end

function placerivers(lakes)
	-- place rivers from lakes to ocean
	local queue = {}
	for i=1,#lakes do
		push(queue,lakes[i])
	end
	while #queue > 0 do
		-- pick a basic direction
		local start = pop(queue)
		local x,y = vec2xy(start)
		local dir = frnd(4)
		local tile = mget(x,y)
		local nextdir = dir -- 0 n - 1 e - 2 s - 3 w
		while tile != 30 do
			mset(x,y,46)
			local r = frnd(5)
			if nextdir != dir then nextdir = randfromlist(dir,nextdir) else
				nextdir = randfromlist(dir,dir,dir+1,dir-1)%4
			end
			if nextdir == 0 then y-=1
			elseif nextdir == 1 then x+=1
			elseif nextdir == 2 then y+=1
			else x-=1 end
			tile = mget(x,y)
			if tile == 46 then break end
		end
	end
end

function findstart()

	local attempts = 0
	local function restart()
		attempts+=1
		x = mapsize_x
		y = frnd(mapsize_y)
	end

	rectfill(32,113,96,121,1)
	color(7)
	print("washing ashore...",32,113)

	-- pick a random potential start and explore
	local start = randfromset(potential_starts)
	local x = start[1]
	local y = start[2]
	local bestland = 0
	if find_starting_island(x,y) then
		setpos(x,y)
		mset(x,y,93)
		return true
	else
		restart()
	end
end



-- noise

function fractal_noise_2d(octaves,persistence,scale,x,y)
	local total = 0
	local freq = scale
	local amp = 1
	local maxamp = 0

	for i=1,octaves do
		total += perlin_noise_2d(x * freq, y * freq) * amp
		freq *= 2
		maxamp += amp
		amp *= persistence
	end

	return total / maxamp
end

permutation = {}

function genperms()
	local p = {}
	for i=0,255 do
		add(p,i)
	end
	for i=0,255 do
		add(p,i)
	end
	shuffle(p)
	permutation = p
end

function perlin_noise_2d(x,y)
	local xi = flr(x) % 255
	local yi = flr(y) % 255
	local xf = x-flr(x)
	local yf = y-flr(y)

	local u = fade(xf)
	local v = fade(yf)

	local p = permutation

	local aa = p[p[xi+1]+yi+1]
	local ab = p[p[xi+1]+yi+2]
	local ba = p[p[xi+2]+yi+1]
	local bb = p[p[xi+2]+yi+2]

	local x1,y1,x2,y2

	x1 = lerp(grad(aa,xf,yf),grad(ba,xf-1,yf),u)
	x2 = lerp(grad(ab,xf,yf-1),grad(bb,xf-1,yf-1),u)
	return lerp(x1,x2,v)
end

function grad(hash,x,y)
	local h = band(hash,0x7)
	local v={x+y,-x+y,x-y,-x-y,-x,-y,x,y}
	return v[hash%8+1]
end

function fade(t)
	return t*t*t*(t*(t*6-15)+10)
end

-- utils
--------
function lerp(a,b,t)
	return (1-t)*a+t*b
end

--function assert(a,text)
--	if not a then
--		error(text or "assertion failed")
--		b = nil
--		b+=1
--	end
--end
--
--function error(text)
--	cls()
--	print(text)
--	_update = function() end
--	_draw = function() end
--end


function shuffle(a)
	local n = count(a)
	for i=1,n do
		local k = -flr(-rnd(n))
		a[i],a[k] = a[k],a[i]
	end
	return a
end

function randfromset(set)
	local r = frnd(#set)+1
	return set[r]
end

function randfromlist(...)
	local list = {...}
	local r = frnd(#list)+1
	return list[r]
end
function range(a,b)
	local list = {}
	for i=a,b do
		add(list,i)
	end
	return list
end
function randfromrange(a,b)
	local list = range(a,b)
	local r = frnd(#list)+1
	return list[r]
end


function push(stack,item)
	stack[#stack+1]=item
end
function pop(stack)
	local r = stack[#stack]
	stack[#stack]=nil
	return r
end
function top(stack)
	return stack[#stack]
end

function clamp(input,minval,maxval)
	return min(max(input,minval),maxval)
end

function inv(func)
	return function(...) return not func(...) end
end

function is_adjacent_to(func,x,y)
	return func(x-1,y) or func(x+1,y) or func(x,y-1) or func(x,y+1)
end


function inmap(tx,ty)
	return tx >= 0 and ty >= 0 and tx <= 128 and ty <= 64
end

function valinrange(val,a,b)
	return val >= a and val <= b
end
function valin(val,...)
	-- return true if value is in list, else false
	for v in all({...}) do
		if val == v then return true end
	end
	return false
end

function vec(x,y)
	return flr(y)*256+flr(x)%256
end

function vec2xy(v)
	local y = flr(v/256)
	local x = v-flr(y*256)
	return x,y
end

function inlist(list,x)
	for v in all(list) do
		if v == x then return v end
	end
	return false
end

function printr(text,x,y)
	local len = #text
	print(text,x-len*4,y)
end

function formap(func)
	for y=0,mapsize_y do
		for x=0,mapsize_x do
			func(x,y)
		end
	end
end
