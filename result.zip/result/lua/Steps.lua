-- steps
-- by ahmed khalifa

local player
local entities = {}
local cx,cy=12,12
local dark=false
local steps = 10
local deaths = 0
local flash = 0
local world=nil
function _init()
	palt(0,false)
	palt(8,true)
	poke(0x5f2c, 3)
	world=new_mainmenu()
	world:init()
end

function _update()
	world:update()
end

function _draw()
	world:draw()
end

function new_story()
  return {
    flicker=0,
    page=0,
    init=function(self)
    end,
    update=function(self)
      if btnp(❎) then
        if self.page==1 then
          flash = 1
          sfx(1)
        else
          self.page += 1
          sfx(2)
        end
      end
      if(flash > 0) then
        flash -= 0.2
        if(flash <= 0) world=new_gameplay() world:init() return
      end
    end,
    draw=function(self)
      cls(0)
    	clip(cx,cy,40,40)
      if self.page==0 then
        printc("death is",cx+20,cy+8)
        printc("no escape",cx+20,cy+14)
        printc("it is",cx+20,cy+24)
        printc("cursed",cx+20,cy+30)
      elseif self.page==1 then
        printc("find the",cx+20,cy+8)
        printc("wings",cx+20,cy+14)
        printc("it is the",cx+20,cy+24)
        printc("only way",cx+20,cy+30)
      end
    	clip()
    	rect(cx-3,cy-3,cx+42,cy+42,7)
      if (flash > 0 or flr(self.thunder) % 2 == 1) rectfill(cx,cy,cx+39,cy+39,7)
    	printc("steps",32,4)
      -- print("g\na\nm\ne\n \nb\ny",cx-8,cy)
      -- print("a\nm\ni\nd\no\ns",cx+45,cy+3)
      self.flicker = (self.flicker + 0.1) % 2
      if (flr(self.flicker) == 0) printc("❎ continue",31,59)
    end
  }
end

function new_mainmenu()
  return {
    flicker=0,
    waves=0,
    wave_shift=0,
    cloud_shift=0,
    time=0,
    thunder=0,
    init=function(self)
      self.time = rnd()/2 + 0.5
    end,
    update=function(self)
      if (btnp(❎)) flash = 1 sfx(1)
      if(flash > 0) then
        flash -= 0.2
        if(flash <= 0) world=new_story() world:init() return
      end
      if self.time > 0 then
        self.time -= 0.01
        if (self.time <= 0) self.thunder = 8 sfx(0)

      end
      if self.thunder > 0 then
        self.thunder -= 0.25
        if (self.thunder <= 0) self.time = rnd()/2 + 0.5
      end
    end,
    draw=function(self)
      cls(0)
    	clip(cx,cy,40,40)
      rectfill(cx,cy+30,cx+40,cy+40)
      rectfill(cx,cy,cx+40,cy+6)
      self.waves = (self.waves + 0.1) % 2
      self.wave_shift = (self.wave_shift - 0.2) % 8
      self.cloud_shift = 2*sin(time()/6)
      spr(72,cx,cy+self.cloud_shift+5,5,1)
      spr(90,cx+4,cy+18+sin(self.waves/2),2,2)
      spr(92,cx+26,cy+19,2,1)
      for i=-1,6 do
        spr(88 + flr(self.waves),cx+i*8+self.wave_shift,cy+24)
      end
    	clip()
    	rect(cx-3,cy-3,cx+42,cy+42,7)
      if (flash > 0 or flr(self.thunder) % 2 == 1) rectfill(cx,cy,cx+39,cy+39,7)
    	printc("steps",32,4)
      print("g\na\nm\ne\n \nb\ny",cx-8,cy)
      print("a\nm\ni\nd\no\ns",cx+45,cy+3)
      self.flicker = (self.flicker + 0.1) % 2
      if (flr(self.flicker) == 0) printc("❎ start",31,59)
    end
  }
end



function new_win(game)
  return {
    game=game,
    done=false,
    init=function(self)
    end,
    update=function(self)
      if (btnp(❎)) self.done=true flash = 1
      if(flash > 0) then
        flash -= 0.2
        if(self.done and flash <= 0) sfx(1) world=new_mainmenu() world:init() return
      end
    end,
    draw=function(self)
      cls(0)
    	clip(cx,cy,40,40)
      printc("you",cx+20,cy+8)
      printc("escaped",cx+20,cy+14)
      printc("deaths:"..deaths,cx+20,cy+26)
      printc("coins:"..player.coins.."/4",cx+20,cy+32)
    	clip()
      if (flash > 0) rectfill(cx,cy,cx+39,cy+39,7)
      rect(cx-3,cy-3,cx+42,cy+42,7)
    	self.game:draw_ui()
      rectfill(cx-5,cy+45,cx+50,cy+60,0)
      printc("❎ restart",31,59)
    end
  }
end



function new_gameplay()
  return {
    init=function(self)
    	player = new_player(56,184)
      -- player = new_player(152,16)
      entities = {}
    	for x=0,25 do
    		for y=0,25 do
    			local tile = mget(x,y)
    			if (tile == 49) add(entities, new_checkpoint(x*8,y*8))
    			if (tile == 2 or tile == 3) add(entities, new_cactus(x*8,y*8, tile==2))
    			if (tile == 4) add(entities, new_cutter(x*8,y*8))
    			if (tile == 27) add(entities, new_wave(x*8,y*8))
    			if (tile == 43) add(entities, new_puzzle1(x*8,y*8))
    			if (tile == 45) add(entities, new_puzzle2(x*8,y*8))
    			if tile == 30 then
    				s1 = new_stairs(x*8,y*8)
    				s2 = new_stairs((x+3)*8,y*8)
    				s1.other = s2
    				s2.other = s1
    				add(entities,s1)
    				add(entities,s2)
    			end
    			if tile == 46 then
    				s1 = new_stairs(x*8,y*8)
    				s2 = new_stairs(x*8,(y+3)*8)
    				s1.other = s2
    				s2.other = s1
    				add(entities,s1)
    				add(entities,s2)
    			end
    			if (tile == 23) add(entities, new_spike(x*8,y*8))
    			if (tile == 21) add(entities, new_torch(x*8,y*8))
    			if (tile == 10) add(entities, new_shoe(x*8,y*8))
    			if (tile == 13) add(entities, new_glove(x*8,y*8))
    			if (tile == 8) add(entities, new_key(x*8,y*8))
    			if (tile == 15) add(entities, new_coin(x*8,y*8))
    			if (tile == 6) add(entities, new_door(x*8,y*8))
          if (tile == 61) add(entities, new_wings(x*8,y*8))
    		end
    	end
    	for x=0,25 do
    		for y=0,25 do
    			local tile = mget(x,y)
    			if (tile == 38) add(entities, new_crate(x*8,y*8))
    			if tile == 12 then
    				s1 = new_stairs(x*8,y*8)
    				s2 = new_stairs((x+3)*8,y*8)
    				s1.other = s2
    				s2.other = s1
    				add(entities,s1)
    				add(entities,s2)
    				add(entities, new_crate(x*8,y*8))
    			end
    			if tile == 32 then
    				add(entities, new_crate(x*8,y*8))
    				add(entities, new_puzzle3(x*8,y*8))
    			end
    		end
    	end
    end,
    update=function(self)
      dark=false
    	player:update()
    	for e in all(entities) do
    		e:update()
    	end
    end,
    draw_ui=function(self)
    	printc("steps",32,4)
    	if (player.cutter) spr(4,64-cx+4,13)
    	if (player.torch) spr(21,64-cx+4,23)
    	if (player.glove) spr(13,64-cx+4,33)
    	if (player.key) spr(8,64-cx+4,43)
    	for i=0,player.coins-1 do
    			spr(15,cx-12,13+10*i)
    	end
    	if player.steps <= 0 then
    		printc("❎ restart",31,59)
    	else
    		print(player.steps.."",cx-3,64-cy+5)
    		if player.dash then
    			if player.run then
    				spr(59,64-cx-12,64-cy+3)
    			else
    				spr(60,64-cx-12,64-cy+3)
    			end
    			spr(58,64-cx-4,64-cy+3)
    		end
    	end
    end,
    draw_light=function(self)
    	rectfill(64+cx,64+cy,64+cx+40,64+cy+40,0)
    	local r = 3
    	if player.torch then
    		r = 20
    	end
    	px,py=location(player.x,player.y)
    	circfill(64+px+3,64+py+4,r+2*rnd(),7)
    	for x=0,63 do
    		for y=0,63 do
    			pset(x, y, pget(x, y) & pget(x+64,y+64))
    		end
    	end
    end,
    draw=function(self)
      cls(0)

    	clip(cx,cy,40,40)
    	local map_x,map_y=player:get_quad()
    	map(map_x*5,map_y*5, cx, cy, 5, 5, 0x80)
    	for e in all(entities) do
    		e:draw()
    	end
    	player:draw()
    	map(map_x*5,map_y*5, cx, cy, 5, 5, 1)
    	clip()
    	if (dark) self:draw_light()
    	if (flash > 0) rectfill(cx,cy,cx+39,cy+39,7)
    	flash -= 0.2
    	rect(cx-3,cy-3,cx+42,cy+42,7)
    	self:draw_ui()
    end
  }
end



function new_player(x, y)
  return {
    type="player",
    x=x,
    y=y,
    flip=false,
    anim=0,
    ox=0,
    oy=0,
    rx=x,
    ry=y,
    steps=steps,
    cutter=false,
    dash=false,
    run=false,
    torch=false,
    glove=false,
    key=false,
    coins=0,
    moved=false,
    step_sound=0,
    get_quad=function(self)
      return flr(self.x/40),flr(self.y/40)
    end,
    update=function(self)
      if self.ox != 0 or self.oy != 0 then
        local speed = 0.5
        self.ox,self.oy = lerp(self.ox,0,speed),lerp(self.oy,0,speed)
        if (abs(self.ox) < 1) self.ox = 0
        if (abs(self.oy) < 1) self.oy = 0
        if self.ox == 0 and self.oy == 0 then
          local e = collide(self.x,self.y)
          if(e!=nil and e.type == "stairs" and self.moved) self.x,self.y=e.other.x,e.other.y sfx(13)
        end
        return
      end
      self.moved=false
      if self.steps <= 0 then
        if btn(❎) then
          sfx(8)
          self.x,self.y = self.rx,self.ry
          self.steps = 10
          deaths += 1
        end
      else
        local dx, dy = 0,0
        if (btn(⬆️)) dy -= 1
        if (btn(⬇️)) dy += 1
        if (btn(⬅️)) dx -= 1 self.flip=true
        if (btn(➡️)) dx += 1 self.flip=false
        if (abs(dx) + abs(dy) > 1) dy=0
        if (btnp(❎) and self.dash) self.run = not self.run sfx(2)
        if abs(dx) + abs(dy) > 0 then
          local temp = self:move(dx, dy)
          local e = collide(self.x,self.y)
          if (temp and colltype(self.x,self.y,"checkpoint")) sfx(8)
          if self.run and temp and not colltype(self.x,self.y,"spike") and (e==nil or not e.item) then
            if colltype(self.x,self.y,"checkpoint") then
              player.steps = steps
              player.rx,player.ry = self.x,self.y
            end
            temp = self:move(dx,dy,true)
            if (temp and colltype(self.x,self.y,"checkpoint")) sfx(8)
          end
        end
      end
    end,
    move=function(self, dx, dy, second)
      local tx,ty = flr(self.x/8)+dx,flr(self.y/8)+dy
      local e = collide(tx*8,ty*8)
      local c = colltype(tx*8,ty*8,"cactus")
      local b = colltype(tx*8,ty*8,"crate")
      if not fget(mget(tx,ty), 0) and (c==nil or not c["blocked"]) and b==nil and (e==nil or not e["blocked"]) then
        self.x,self.y=tx*8,ty*8
        self.ox,self.oy=dx*8,dy*8
        if not second then
          self.steps -= 1
          if (self.steps <= 0 and colltype(self.x,self.y,"checkpoint") == nil and not (e != nil and e.item)) sfx(5)
        end
        self.moved=true
        sfx(3+self.step_sound)
        self.step_sound = 1 - self.step_sound
        return true
      else
        local temp_sfx = 10
        if self.cutter and c != nil then
          temp_sfx = 7
          e.blocked = false
        end
        if self.key and e != nil and e.type == "door" then
          temp_sfx = 7
          e.blocked = false
        end
        if self.glove and b != nil then
          temp_sfx=-1
          b:move(dx, dy)
        end
        self.ox,self.oy=-dx*2,-dy*2
        if(temp_sfx>=0) sfx(temp_sfx)
        return false
      end
    end,
    draw=function(self)
      local frame
      if self.ox == 0 and self.oy == 0 and self.steps <= 0 then
        self.anim = 0
        frame = 1
      else
        self.anim = (self.anim + 0.1)%2
        frame = 24
      end
      local px,py=location(self.x,self.y)
      print(px.." "..py, 0, 0, 7)
      spr(frame+flr(self.anim), px-self.ox, py-self.oy, 1, 1, self.flip)
    end
  }
end



function lerp(v1,v2,t)
  return (v2 - v1)*t+v1
end

function printc(string,x,y,c)
  c=c or 7
  print(string,x-#string*2,y-2,c)
end

function sign(value)
  if (value > 0) return 1
  if (value < 0) return -1
  return 0
end

function location(x,y)
  local qx,qy=player:get_quad()
  return x-qx*40+cx,y-qy*40+cy
end

function collide(x,y)
  for e in all(entities) do
    if (e.x == x and e.y == y) return e
  end
  return nil
end

function colltype(x,y,type)
  for e in all(entities) do
    if (e.x == x and e.y == y and e.type == type) return e
  end
  return nil
end



function new_checkpoint(x, y)
  return {
    type="checkpoint",
    x=x,
    y=y,
    anim=0,
    update=function(self)
      if player.x == self.x and player.y == self.y then
        player.steps = steps
        player.rx,player.ry = self.x,self.y
      end
    end,
    draw=function(self)
      self.anim = (self.anim + 0.2)%2
      local frame = 49
      if (player.rx == self.x and player.ry == self.y) frame=51
      local px,py=location(self.x,self.y)
      spr(frame+flr(self.anim),px,py)
    end
  }
end



function new_cactus(x, y, blocked)
  return {
    type="cactus",
    x=x,
    y=y,
    blocked=blocked,
    update=function(self)
    end,
    draw=function(self)
      local frame = 3
      if (self.blocked) frame=2
      local px,py=location(self.x,self.y)
      spr(frame,px,py)
    end
  }
end



function new_cutter(x, y)
  return {
    type="cutter",
    x=x,
    y=y,
    anim=0,
    item=true,
    update=function(self)
      if player.x == self.x and player.y == self.y then
        player.steps = steps
        player.rx,player.ry = self.x,self.y
        add(entities, new_checkpoint(self.x, self.y))
        player.cutter = true
        del(entities, self)
        sfx(9)
      end
    end,
    draw=function(self)
      self.anim = (self.anim + 0.2)%2
      local px,py=location(self.x,self.y)
      spr(4+flr(self.anim),px,py)
    end
  }
end



function new_wave(x, y)
  return {
    type="wave",
    x=x,
    y=y,
    blocked=true,
    anim=0,
    update=function(self)
    end,
    draw=function(self)
      self.anim = (self.anim + 0.2)%2
      local px,py=location(self.x,self.y)
      spr(27+flr(self.anim),px,py)
    end
  }
end



function new_coin(x, y)
  return {
    type="coin",
    x=x,
    y=y,
    anim=0,
    item=true,
    update=function(self)
      if player.x == self.x and player.y == self.y then
        -- player.steps = steps
        -- player.rx,player.ry = self.x,self.y
        -- add(entities, new_checkpoint(self.x, self.y))
        player.coins += 1
        del(entities, self)
        sfx(9)
      end
    end,
    draw=function(self)
      self.anim = (self.anim + 0.2)%2
      local px,py=location(self.x,self.y)
      spr(15+flr(self.anim),px,py)
    end
  }
end



function new_puzzle1(x, y)
  return {
    type="puzzle1",
    x=x,
    y=y,
    update=function(self)
      local c1=collide(self.x-8,self.y)
      local c2=collide(self.x+8,self.y)
      local d1=collide(self.x+8,self.y-8)
      local d2=collide(self.x-8,self.y+8)
      if c1.blocked and c2.blocked and not d1.blocked and not d2.blocked then
        del(entities, self)
        add(entities, new_coin(self.x, self.y))
        flash = 1
        sfx(1)
      end
    end,
    draw=function(self)
    end
  }
end



function new_puzzle2(x, y)
  return {
    type="puzzle2",
    x=x,
    y=y,
    timer=0,
    update=function(self)
      if player.x == self.x and player.y == self.y and player.steps > 0 then
        timer += 1
      else
        timer = 0
      end
      if timer>=120 then
        del(entities, self)
        add(entities, new_coin(self.x+8, self.y))
        flash = 1
        sfx(1)
      end
    end,
    draw=function(self)
    end
  }
end



function new_stairs(x, y)
  return {
    type="stairs",
    x=x,
    y=y,
    other=nil,
    update=function(self)
      -- if player.x==self.x and player.y==self.y then
      --   player.steps=steps
      --   player.rx,player.ry = self.x,self.y
      -- end
    end,
    draw=function(self)
      local px,py=location(self.x,self.y)
      spr(30,px,py)
    end
  }
end



function new_spike(x, y)
  return {
    type="spike",
    x=x,
    y=y,
    other=nil,
    get_quad=function(self)
      return flr(self.x/40),flr(self.y/40)
    end,
    update=function(self)
      if player.x==self.x and player.y==self.y then
        player.steps=0
      end
      local qx,qy = self:get_quad()
      local pqx,pqy=player:get_quad()
      if (qx == pqx and qy == pqy) dark = true
    end,
    draw=function(self)
      local px,py=location(self.x,self.y)
      spr(23,px,py)
    end
  }
end



function new_torch(x, y)
  return {
    type="torch",
    x=x,
    y=y,
    anim=0,
    item=true,
    update=function(self)
      if player.x == self.x and player.y == self.y then
        player.steps = steps
        player.rx,player.ry = self.x,self.y
        add(entities, new_checkpoint(self.x, self.y))
        player.torch = true
        del(entities, self)
        sfx(9)
      end
    end,
    draw=function(self)
      self.anim = (self.anim + 0.2)%2
      local px,py=location(self.x,self.y)
      spr(21+flr(self.anim),px,py)
    end
  }
end



function new_shoe(x, y)
  return {
    type="shoe",
    x=x,
    y=y,
    anim=0,
    item=true,
    update=function(self)
      if player.x == self.x and player.y == self.y then
        player.steps = steps
        player.rx,player.ry = self.x,self.y
        add(entities, new_checkpoint(self.x, self.y))
        player.dash = true
        del(entities, self)
        sfx(9)
      end
    end,
    draw=function(self)
      self.anim = (self.anim + 0.2)%2
      local px,py=location(self.x,self.y)
      spr(10+flr(self.anim),px,py)
    end
  }
end



function new_glove(x, y)
  return {
    type="glove",
    x=x,
    y=y,
    anim=0,
    item=true,
    update=function(self)
      if player.x == self.x and player.y == self.y then
        player.steps = steps
        player.rx,player.ry = self.x,self.y
        add(entities, new_checkpoint(self.x, self.y))
        player.glove = true
        del(entities, self)
        sfx(9)
      end
    end,
    draw=function(self)
      self.anim = (self.anim + 0.2)%2
      local px,py=location(self.x,self.y)
      spr(13+flr(self.anim),px,py)
    end
  }
end



function new_key(x, y)
  return {
    type="key",
    x=x,
    y=y,
    anim=0,
    item=true,
    update=function(self)
      if player.x == self.x and player.y == self.y then
        player.steps = steps
        player.rx,player.ry = self.x,self.y
        add(entities, new_checkpoint(self.x, self.y))
        player.key = true
        del(entities, self)
        sfx(9)
      end
    end,
    draw=function(self)
      self.anim = (self.anim + 0.2)%2
      local px,py=location(self.x,self.y)
      spr(8+flr(self.anim),px,py)
    end
  }
end



function new_crate(x, y)
  return {
    type="crate",
    x=x,
    y=y,
    ox=0,
    oy=0,
    blocked=true,
    update=function(self)
      if self.ox != 0 or self.oy != 0 then
        local speed = 0.5
        self.ox,self.oy = lerp(self.ox,0,speed),lerp(self.oy,0,speed)
        if (abs(self.ox) < 1) self.ox = 0
        if (abs(self.oy) < 1) self.oy = 0
      end
    end,
    move=function(self, dx, dy)
      local tx,ty = flr(self.x/8)+dx,flr(self.y/8)+dy
      local e = collide(tx*8,ty*8)
      if not fget(mget(tx,ty), 0) and (e==nil or not e["blocked"]) and (e==nil or e.type!="cactus") then
        self.x,self.y=tx*8,ty*8
        self.ox,self.oy=dx*8,dy*8
        sfx(11)
      else
        self.ox,self.oy=-dx*2,-dy*2
      end
    end,
    draw=function(self)
      local frame = 38
      local e = collide(self.x, self.y)
      if (mget(self.x/8,self.y/8)==31 or (e != nil and e.type == "stairs")) frame=12
      local px,py=location(self.x,self.y)
      spr(frame,px-self.ox,py-self.oy)
    end
  }
end



function new_door(x, y)
  return {
    type="door",
    x=x,
    y=y,
    blocked=true,
    update=function(self)
    end,
    draw=function(self)
      local frame = 7
      if (self.blocked) frame=6
      local px,py=location(self.x,self.y)
      spr(frame,px,py)
    end
  }
end



function new_wings(x, y)
  return {
    type="wings",
    x=x,
    y=y,
    anim=0,
    item=true,
    update=function(self)
      if player.x == self.x and player.y == self.y then
        flash = 1
        world = new_win(world)
        world:init()
        sfx(1)
      end
    end,
    draw=function(self)
      self.anim = (self.anim + 0.2)%2
      local px,py=location(self.x,self.y)
      spr(61+flr(self.anim),px,py)
    end
  }
end



function new_puzzle3(x, y)
  return {
    type="puzzle3",
    x=x,
    y=y,
    update=function(self)
      local b1=colltype(self.x+8,self.y-8,"crate")
      local b2=collide(self.x+8,self.y+8,"crate")
      if b1 != nil and b2 != nil then
        del(entities, self)
        add(entities, new_coin(self.x, self.y))
        flash = 1
        sfx(1)
      end
    end,
    draw=function(self)
    end
  }
end



