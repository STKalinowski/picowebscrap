--shifttrap v. 1.0
--by sol

cartdata"moe_foxie_sol_ninja"

--variable descriptions
--[[
--persistent vars
lv=current level
deaths=player deaths
scrolls=number scrolls collected
secs,mins=seconds/mins elapsed
ngp=newgame+ (aka hardmode)

--transient variables
mxlv=max/final level of game
flopy=y position of floppy glyph
camy=target y of camera scroll
bary=scrolling of level border
dcnt=count of frames before next
 dust cloud
sex=sensei x (for cinematic)
strtx/y player start x/y
 managed by tiles 1 and 2 being
 present in a level
nrg=hourglass energy
unlocking=timer for gate unlock
unlocking2=ditto,for green gates
slow_rad=radius of hourglass 
 ring effect
shouldclip=when drawing, should
 camera clip to 128x128 coords
frm=number of frames elapsed
lastime=timestamp of last frame
hey_you_are_finally_awake=
 is nina collapsed in level 0?

--implicit variables
elpsd=elapsed time 'tween frames
lfb=output of btn 4 last frame,
 used by btnpp
bdr_scrl=whether level borders
 are scrolling. see tog_bdr_scrl
show_hud=whether persistent
 variable display is shown. see
 tog_hud.
winning=timer for how long
 between winning and next level
dying=timer for how long between
 death and respawn
crack=table with xy of 
 screen crack, if any
g=which frame the gears/treads
 are on
smk=coroutine for smoke anim
]]
lv,mxlv=dget(0),32

deaths,scrolls,
secs,mins,ngp,
flopy,camy,bary,dcnt,
sex,strtx,strty,nrg,
unlocking,unlocking2,slow_rad,
shouldclip,frm,lastime,
hey_you_are_finally_awake=
 dget(1),dget(2),
 dget(3),dget(4),dget(5)==1,
 1,0,0,0,
 55,64,112,1,
 -1,-1,255,
 true,0,0,
 lv!=0
 
function _init()
--player variables
--[[
px/y=player xy
px/yvel=player velocity
cte=coyote time timer
wgrace=grace period for pushing
 away from wall and detachment
psdr=player direction (hflip)
idle=timer for player
 idle animation

--implcit variables
wcling=player is wall clinging
hglass=does player have hourglass
tweight=does player have
 training weight?
has_seen_hglass=has player seen
 hourglass cinematic?
has_seen_tweight=has player seen
 training weight cinematic?
 
--set these only via s_ani()!!!
pfrm=player sprite number
pfrmd=duration, affects speed
 of player animation progres
ps/efrm= start/end sprite of
 animation.
]]
 px,py,pxvel,pyvel,
 cte,wgrace,psdr,idle,
 pfrm,pfrmd,psfrm,pefrm=
  18,70,0,0,
  1,15,1,0,
  1,.2,1,4
 
 cine_intro,
 cine_outro,
 cine=
  m_tro_cine(intro_co),
  m_tro_cine(outro_co),
  cine_logo
 menuitem(
  2,"clear save data",
  function()
   memset(0x5e00,0,256)
   extcmd"reset"
  end
 )
 tog_hud()
end

function s_ani(sfrm,efrm,frmd)
 if (psfrm==sfrm and pefrm==efrm) return
  pfrm,psfrm,pefrm,pfrmd=
  sfrm,sfrm,
  efrm or sfrm,
  frmd or 1
end

function update_player()
 if (cine) return
 if wcling then
  if btn(➡️)and not psdr then
   wgrace-=1
  elseif btn(⬅️) and psdr then
   wgrace-=1
  else
   wgrace=15
  end
  if btnpp(⬇️) or wgrace==0 then
   wcling=false
  end
 end
 
 idle=btn()==0 and idle+1 or 0
 if not wcling then
  pxvel=
   (btn(⬅️) and -2) or
   (btn(➡️) and 2) or 0
  if (tweight) pxvel/=2
  if pxvel!=0 then
   if fget(celat(px,py+8),0)and
      pfrm==4 then
    sfx(tweight and 45 or 35)
   end
   psdr=pxvel>0
   s_ani(1,5,tweight and 
    .25 or .5)
  else
   s_ani(idle%360>240 and 9 or 1)
  end
  
  if not chk_grnd() then
   cte-=1
  else
   cte=1
   pyvel=0
  end   
 else
  pxvel=0
 end
 
 local w,wc=chk(px+pxvel,py)
 if (wc) wc=wc[1]
 if not btn(⬇️) and pyvel!=0 and 
    (btn(⬅️) or btn(➡️)) and 
    w and not fget(wc,2) then
  for y=-2,2,4 do
   if not chk(px+pxvel,py+y) then
    py+=y
    goto slipy
   end
  end  
  wcling=true
  ::slipy::
 elseif cte<0 then
  s_ani(3)
 end
 if cte<=4 then
  pyvel=min(3,pyvel+.25)
 end
  
 --crit=criteria for wcling
 local crit
 if tweight then
  crit=wcling
 else
  crit=wcling or cte>=0
 end
 if crit and btnpp(🅾️) then 
  pyvel=-3.5
  wcling=false
 end
 if wcling then
  s_ani(5)
  pyvel=0
 end
 
 if dcheck() then
  die(1)
  px+=pxvel
  py+=pyvel
  return
 end
 if pyvel<0 and chk(px,py+pyvel) then
  local y=py+pyvel
  if pxvel==0 then
   for x=-2,2,4 do
    if not chk(px+x,y) then
     px+=x
     goto slipx
    end
   end
  end
  pyvel=0
  ::slipx::
 end
 
 if not hey_you_are_finally_awake then
  s_ani(8)
  pxvel,psdr,px=
   0,true,
   btn(➡️) and 25 or
   btn(⬅️) and 23 or 24
 end
 
 local c,cx,cy=
  celat(px+4,py+4)
 if c==32 then
  trans(32,33,
        34,35,
        36,37,
        35,34,
        37,36)
  sfx(36)
  unlocking=15
 elseif c==48 then
  trans(50,51,
        52,53,
        48,49,
        51,50,
        53,52)
  sfx(36)
  unlocking2=15
 elseif c==67 then
  scrolls+=1
  sfx(41)
  mset(cx,cy,0)
 elseif c==65 then
  hglass=true
  sfx(34)
  if not has_seen_hglass then
   cine,has_seen_hglass=
    m_itm_cine(65,hglass_txt),true
  end 
  mset(cx,cy,0)
 elseif c==66 then
  tweight=true 
  sfx(34)
  if not has_seen_tweight then
   cine,has_seen_tweight=
    m_itm_cine(66,tweight_txt),true
  end
  mset(cx,cy,0)
 elseif c==64 then
  sfx(34)
  flopy=0
  if (lv==mxlv) camy=-128
  winning=lv!=0 and 60 or 120
 end
 
 local hitwall
 px+=pxvel
 while chk(px,py) do
  px-=1*sgn(pxvel)
  hitwall=true
 end
 
 py+=pyvel
 while chk(px,py) do
  py-=1*sgn(pyvel)
 end
 
 if pxvel!=0 then
  dcnt=dcnt>3 and 0 or dcnt+1
  if dcnt==3  and not hitwall 
     and chk_grnd() then
   add(dusts,{px,py,12})
  end
 end
end

function u_dusts()
 for d in all(dusts) do
  if d[3]>=13.5 then
   del(dusts,d)
  end
  d[3]+=.1
 end
end

function dcheck()
 local _,cxs=
  chk(px+pxvel,py)
 local _,cys=
  chk(px,py+pyvel)
  
 for axis in all{cxs,cys} do
  for cz in all(axis) do
   if (fget(cz,1)) return true
  end
 end
end

function newgame()
 pal()
 cine=nil
 music(lv==0 and -1 or 0)
 if lv!=0 and not bdr_scrl then
  tog_bdr_scrl()
 end
 loadlevel(lv)
end

function trans(...)
 local t={...}
 local omits={}
 for i=1,#t,2 do
  for x=0,14 do
   for y=0,14 do
    for omit in all(omits) do
     if omit[1]==x and 
        omit[2]==y then
      goto nxt
     end
    end
    if mget(x,y)==t[i] then
     mset(x,y,t[i+1])
     add(omits,{x,y})
    end
    ::nxt::
   end
  end
 end
end

function shift(x,y,ex,ey)
 x,y,ex,ey=
  x or 0, y or 0,
  ex or 16, ey or 16
 for x=x,ex do
  for y=y,ey do
   if mget(x,y)==17 then
    mset(x,y,16)
   elseif mget(x,y)==16 then
    mset(x,y,17)
   end
  end
 end
end

function celat(x,y)
 local x,y=x/8-2,y/8
 return mget(x,y),x,y
end

function chk(x,y)
 local y1,x7,y7=y+1,x+7,y+7

 if x<16 or x>104 then
  return true,{}
 end
 
 local cels={}
 for cel in all
  {celat(x,y1),celat(x7,y1),
   celat(x,y7),celat(x7,y7)} do
  if fget(cel,0) then
   add(cels,cel)
  end
 end
 if #cels>0 then
  return true,cels
 end
end

function chk_grnd()
 return (fget(celat(px,py+8),0)or 
      fget(celat(px+7,py+8),0))
end

function machine_hum()
 poke(15517,32-lv)
 poke(0x5f43,0b00001000)
 if started and stat(19)==-1 then
  sfx(39,3)
 end
end

function _update60()
 frm+=1
 elpsd=time()-lastime
 lastime=time()
 
 slow_rad=min(slow_rad+5,164)
 
 //update camera
 _camy=peek2(0x5f2a)
 if camy!=_camy then
  local shft=
   camy>_camy and 1 or -1
  camera(0,_camy+shft)
 end
 
 if (flopy<1) flopy+=0.0084 
 if (bdr_scrl) bary+=lv*.05+.05
 if (bary>8) bary=0
 g=started and frm%30>15//used by draw_gear, etc.
 
 ::top::
 if (cine) goto cn
 if (not cine) machine_hum()
 if winning and lv==mxlv then
  if peek2(0x5f2a)<-127 then
   cine=cine_outro
  end
  return
 elseif winning and winning>0 then
  if winning<60 then
   if not started then
    started=true
    sfx(32)
    tog_bdr_scrl()
    frm=45 //ensure gears start at same position
   end
  end
  s_ani(7)
  winning-=1
  u_dusts()
  return
 elseif winning then
  winning=false
  crack=nil
  lv+=1
  save_game()
  if lv==1 and stat(24)==-1 then
   music(0)
  end
  if (lv>mxlv) then
   music(14)
  end
  loadlevel(lv)
 elseif dying and dying>0 then
  s_ani(6)
  dying-=1
  u_dusts()
  return
 elseif dying then
  dying,crack,idle=false,nil,0
  loadlevel(lv)
 end
 if unlocking>-1 then
  unlocking-=1
 end
 if unlocking2>-1 then
  unlocking2-=1
 end
 if unlocking==0 then
  trans(35,0,37,0)
 end
 if unlocking2==0 then
  trans(51,0,53,0)
 end
 
 ::cn::
 if cine then
  if btnpp(🅾️) then
   if cine==cine_intro then
    camera(0,0)
    camy=0
    newgame()
   elseif cine==cine_outro then
    camera(0,127)
    camy=0
    cine=cine_end
   end
  end
 else
  if secs!=0 then
   secs+=elpsd
   while secs>60 do
    mins=min(999,mins+1)
    secs-=60
   end
  end
  if hglass and nrg>0 and 
     btn(❎) then
   if btnpp(❎) then
    slow_rad=0
    sfx(40)
    poke(0x5f40,255)
   end
   if frm%4<3 then
    nrg-=0.008
    return
   end
  else
   poke(0x5f40,0)
   sfx(40,-2)
  end
  
  if btnpp(🅾️) then
   hey_you_are_finally_awake=true
   shift()
   sfx(32)
  end
  
  if chk(px,py) then
   //nudge in player's favor
   for padx in all{2,-2} do
    if not chk(px+padx,py) then
     px+=padx 
     goto safe
    end
   end
   for pady in all{2,-2} do
    if not chk(px,py+pady) then
     py+=pady
     goto safe
    end
   end
   die()
   return
  end
  ::safe::

  update_player()
  u_frm()
  u_dusts()
  
  reload(0x0800,
   0x0800+64*flr(time()%2),446)
 end
 lfb=btn()
end

function die(cod)
 dying,crack,pxvel=
  30,{px-3,py-4},0
 if cod==1 then
  crack=nil
 end
 deaths=min(deaths+1,9999)
 scrolls=dget(2)
 sfx(33)
 
 flopy=0
 save_game()
end

function save_game()
 dset(0,lv) 
 dset(1,deaths) 
 dset(2,scrolls)
 dset(3,secs)
 dset(4,mins)
 dset(5,ngp and 1 or 0)
end

function u_frm()
 pfrm+=pfrmd
 if (pfrm>=pefrm) pfrm=psfrm
end

function loadlevel(n)
 --add small amount to secs
 --as signal to start counting
 if (started) secs+=.0001
 
 hglass,tweight=lv>4,lv>34
 hglass=hglass or ngp
 unlocking,unlocking2=-1,-1
 dusts={}
 
 reload(0x1000,0x1000,0x2000)
 for x=0,11 do
  for y=0,16 do
   local nx=n*12
   local ny=flr(lv/10)*16
   nx=nx%120
   local t=mget(nx+x,ny+y)
   if t==1 or t==2 then
    strtx,strty,ssdr,t=
     x*8+16,y*8,t==1,0
   end
   if not ngp then
    if (t==67) t=17
    if (t==28) t=16
    if (t==29) t=17
    if t==35 or t==37 or
       t==51 or t==53 then
     t=0
    end
   else
    if (t==65) t=0
    if (t==29) t=28
   end
   
   mset(x,y,t)
  end
 end
 if hey_you_are_finally_awake then
  sfx(38)
  smk=m_smokeco(strtx+3,strty+7)
 end
 px,py,psdr,pxvel,pyvel,wcling,winning,dying,nrg=
  strtx,strty,ssdr,0,0,false,false,false,1
end

function d_obj(x,y)
 pal() --[[guard against
           rare bug where 
           nina's green 
           hairbead turned 
           white??]]
           
 //palette cycling for
 //nina's eyes
 if wgrace!=15 then
  pal(3,15)
  pal(14,1)
 else
  pal(3,1)
  pal(14,15)
 end
 if not tweight or cine then
  //hide training weight if
  //not equipped
  palt(5,true) 
  palt(6,true)
 end
 
 if (ngp) pal(8,13)pal(2,5)
 spr(pfrm,x or px,
     y or py,1,1,psdr)
 palt()
 pal()
end
function _draw()
 
 cls()
 if shouldclip then
  clip(0,0-peek2(0x5f2a),128,128)
 end
 if cine then
  cine()
 else
  draw_bg()
  map(0,0,16,0,16,16)
  for u=0,1 do
   for x=0,8,8 do
    for y=0,128,8 do
     spr(18,x+112*u,y-bary,1,1,x==8)
    end
   end
  end
  
  if not tweight then
   for d in all(dusts) do
    spr(d[3],d[1],d[2])
   end
  end
  
  d_obj()
  
  if (smk) coresume(smk)
  
  if crack then
   spr(10,crack[1],crack[2],2,2)
  end
  
  if (hglass) draw_hglass()
  spr(106,116,130+12*sin(flopy))
  if (show_hud) draw_hud()
 end
end

function draw_hud()
  local hx=32
  if not ngp then
   clip(hx+17,0,127,7)
  end
  rectfill(hx,0,127,6,2)
  local dx=hx+36
  spr(83,dx,1)
  print(flenstr(deaths,4),
   dx+9,1,7
  )
  local lx=hx+19
  spr(85,lx,1)
  
  print(flenstr(lv,2),
   lx+8,1
  )
  local sx=hx+2
  spr(84,sx,1)
  print(flenstr(scrolls,2),
   sx+8,1
  )
  local tx=hx+62
  spr(86,tx,1)
  print(flenstr(mins,3)..":"..
   flenstr(secs,2),tx+9,1)
end

function draw_gear(x,y,frm)
 local v=g
 if (frm) v=not v
 local s=v and 96 or 98
 local y16=y+16
 for i=y,y16,16 do
  spr(s,x,i,2,2,false,i==y16)
  spr(s,x+16,i,2,2,true,i==y16)
 end
end

function draw_corners()
 pal(1,7)
 sspr(96,48,16,16,95,0,32,32)
 sspr(96,48,16,16,0,0,32,32,1)
 sspr(96,48,16,16,0,95,32,32,1,1)
 sspr(96,48,16,16,95,95,32,32,false,1)
 pal()
end

function draw_tread(x,y,l)
 s=g and 104 or 105
 spr(s,x,y)
 for i=1,l do
  spr(s+16,x,y+8*i)
 end
 spr(s,x,y+8+8*l,1,1,false,true)
end

function draw_bg()
 draw_tread(20,64,1)
 draw_tread(32,40,2)
  
 draw_tread(72,0,3)
  
 draw_gear(20,-10,1)
 draw_gear(100,-10)
  
 draw_gear(0,104,1)
 draw_gear(29,104)
  
 draw_gear(77,68)
 draw_gear(77,97,1)
 draw_gear(50,56,1)
 
 map(112,48,0,0,16,16,128)
end

function draw_hglass()
 rect(2,3,13,30,2)
 line(13,3,13,29,9)
 line(3,3,13,3)
 rectfill(3,4,12,29,4)
 pal(3,7)
 spr(81,4,5)
 spr(82,4,13)
 pal(3,1)
 spr(81,4,21,1,1,false,true)
 pal()
 
 for x=4,12 do
  for y=0,27 do
   local c=pget(x,y)
   if y>=27-20*(nrg) then
    if c==1 then
     pset(x,y,15)
    elseif c==13 then
     pset(x,y,9)
    end
   else
    if (c==1) pset(x,y,4)
   end
  end
 end
 
 slow_ring()
end

function m_tro_cine(co)
 return function()
  u_frm()
  if shake then
   camera(rnd(2),rnd(2))
  end
  coresume(co)
  
  local seq=flr(frm%30/10)+1
  set_pal(({
   {14,8,3,11,11,3,15,7,2,8},
   {14,8,9,14,15,8,2,7},
   {15,7,2,8,15,7,2,8}
  })[seq])
  for i=1,2 do
   map(119,56,28,46,9,4,i)
   pal()
  end
  pal(7,13)
  spr(95,92,54,1,1,1)
  spr(75,92,62,1,2,1)
  pal()
  local qspr
  if ngp then
   //load joke sprites
   qspr=qangry and 70 or 68
  else
   qspr=qangry and 30 or 14
  end
  if (qtalk) qspr+=frm%24/12
  spr(qspr,64,70,1,1,qdr)
  
  local sespr
  //spaghetti code at its finest
  if (co==outro_co) then
   sespr=46
   if (ngp) sespr=62 //joke spr
  end

  if sespr then
   if (setalk) sespr+=frm%24/12
   clip(28,0,127,127)
   spr(sespr,sex,70,1,1,sedr)
  end
  
  clip(28,46,127,127)
  d_obj()
  clip()
  
  if (white) rectfill(28,46,100,78,7)
  if (flr(frm%8)==0) pal(11,7)
  if (green) rectfill(84,60,91,77,11)
 end
end

function m_itm_cine(itm,txt)
 local show=function(s)
  print(s)
  wait(60)
 end
 return 
  function()
   poke(0x5f2f,1) //pause music
   s_ani(7)
   d_obj(60,80)
   spr(itm,60,72)
   draw_corners()
   cursor(5,40)
   for t in all(txt) do
    if type(t)=="number" then
     color(t)
    else //if string
     print(t)
     for _=0,60 do
      flip()
      if (btnpp(🅾️)) goto skip
      lfb=btn()
     end
    end
   end
   wait(60)
   ::skip::
   poke(0x5f2f,0)//resume music
   cine=nil
  end
end

function wait(dur)
 for i=1,dur do
  flip()
 end
end

function tog_bdr_scrl()
 bdr_scrl=not bdr_scrl
 menuitem(5,
  (bdr_scrl and "pause" 
   or "resume").." border",
  tog_bdr_scrl)
end
function tog_hud()
 show_hud=not show_hud
 menuitem(4,
  (show_hud and 
   "hide" or "show").." hud",
  tog_hud)
end

function set_pal(p)
 pal()
 p=p or {}
 for i=1,#p-1,2 do
  pal(p[i],p[i+1])
 end
end

function m_smokeco(x,y)
 return cocreate(
  function()
    smokes={}
   for i=1,12 do
    add(smokes,{
     x=x,
     y=y,
     xdir=rnd(.5)-.25,
     ydir=-.5-rnd(.5),
     l=100+rnd(20),//life
     d=rnd(10),    //delay
     c=5+rnd(3)}   //color
    )  
   end
   
   while true do
    for s in all(smokes) do
     s.d-=1
     if s.d<0 then
      s.x+=s.xdir
      s.y+=s.ydir
      s.l-=1
      if s.l>=0 then
       color(s.c)
       circfill(
        s.x+sin(s.l/60)*5,
        s.y,(s.l-50)/10
       )
      end
     end
    end
    yield()
   end
  end)
end

function slow_ring()
 for x=-slow_rad,slow_rad do
  local y=sqrt(slow_rad^2-x^2)
  local offx,offy=10,18
  x=offx+x
  pset(
   x-1,offy+y-1,
   pget(x,y+offy)
  )
  pset(
   x+1,-y+1+offy,
   pget(x,-y+offy)
  )
 end
end

function btnpp(b)
 return btn(b) and 
  band(shl(1,b),lfb)==0
end
?true and band(shl(1,🅾️),lfb)==0
//fixed length string
function flenstr(n,l)
 local s=
   sub(tostr(flr(n)),1,l)
 while #s<l do
  s="0"..s
 end
 return s
end

function cif(f,...)
 if is(f,"function") then
  return f(...)
 end
end
function whilst(dur,fun,...)
 dur=tonum(dur)
 for i=1,dur do
  cif(fun,...) yield()
 end
end
function is(v,t)
 return type(v)==t
end
-->8
--cine
function say(s)
 whilst(120,print,s,28,80,7) 
end
function lines(s)
 res={}
 local idx=1
 for c=1,#s do
  if sub(s,c,c)=="\n" then
   add(res,sub(s,idx,c))
   idx=c
  end
 end
 add(res,sub(s,idx,#s))
 return res
end
function cam_wait(cy,inter)
 camy=cy
 while peek2(0x5f2a)!=camy do
  if cif(inter) then break end
  yield()
 end
end

function end_card()
 draw_corners()
 print("a game by sol",36,14,9)
 print("thank you for playing!",
  20,20
 )
 cursor(36,41)
 color(7)
 print("statistics:\n")
 print("time:    "..
  flenstr(mins,3)..":"..
  flenstr(secs,2)
 )
 print("deaths:  "..
  flenstr(deaths,4)
 )
 if ngp then
  print("scrolls: "..
   flenstr(scrolls,2)
   .."/30"
  )
  if scrolls==30 then
   cursor(20,72,10)
   print
[[incredible! you found 
all 30 secret scrolls!
you're a true shinobi!!]]
  end
 elseif teaser then
  local msg=
"o patient one! a 2\78\68 quest is\n"..
[[presented to you. reset the
game & find the secret scrolls
to become a true shinobi!!]]
  print(msg,6,67,8)
  color(7)
 end
 palt(4,true)
 pal(1,7)
 sspr(112,48,16,16,40,88,48,32)
 cursor(0,0)
end

//scene control variables
//(bool unless otherwise noted)
--[[
shouldclip=clip to 128 frame
green=is portal active
white=flash/expolosion
qtalk,qdr=for dr. quail
setalk,sedr,sex=for sensei
]]
intro_co=cocreate(
 function()
  shouldclip=true
  qtalk=false
  camera(0,-127)
  cam_wait(0)
  
  music(7)
  qtalk=true
  say
[[at last, my research
is complete!!!]]

  say
[[ze "coplanar gate" 
is fully operational!]]

  say
[[soon, ze whole world 
vill know ze name--]]

  qtalk=false

  say
[[dr von quail!
dr von quail!!]]

  qdr,qtalk=false,true

  say
"vat? who is it?"

  qtalk=false
  while px<28 do
   px+=.5 yield()
  end
   s_ani(0,2,.1)
  say
[[it's just me, nina!
sensei sent me to--]]
 
  s_ani(1) 
  whilst"20"
  s_ani(0,2,.1)
  say
[[ooh, what is that?!]]
  s_ani(1,5,.6)
  while px<84 do
   px+=1
   if (px>64) qdr=true
   yield()
  end
  s_ani(1)
  qtalk=true
  say
[[no! do not touch zat!!]]
  s_ani(6)
  qtalk=false
  white=true
  whilst"5"
  sfx(21)
  say
[[waaaugh!!!]] 
  whilst"30"
  green=true
  px=1000
  white=false
  say"..."
  say"......"
  say"........."
  qtalk=true
  say
[[welp, she's dead]]
  qtalk=false
  cam_wait(160)
  camy=0
  camera(0,-127)
  newgame()
 end
)

outro_co=cocreate(
 function()
  //reset row if "bobbing"
  reload(0x0800,0x0800,512)
  px,py=0,0
  music(-1)
  sfx(-1)
  s_ani(6)
  qdr,qtalk=false,false
  green=true
  
  camera(0,-127)
  cam_wait(0)
  qtalk=true
  say
[[i-i have not seen 
ze girl today!!]]
  qtalk,setalk=false,true
  say
[[what? all i asked was
if the videogame i ]]
  say
[[ordered had arrived??
i had it sent here...]]
  setalk=false
  whilst"15"
  px,py=84,65
  s_ani(6)
  while py>24 do
   px-=4
   py-=1.5
   yield()
  end
  sfx(21)
  sedr=true
  for _=0,90 do
   shake=true
   print("waaaugh!!",28,80,7)
   yield()
  end
  sedr=false
  shake=false
  camera(0,0)
  whilst"60"
  setalk=true
  say
[[so, anyway...]]
  setalk=false
  px,py,psdr=16,70,true
  s_ani(1,4,.5)
  while px<28 do
   px+=.5 yield()
  end
  s_ani(0,2,.1)
  sedr=true
  say
[[i'm back!!!]]
  s_ani(1)
  setalk=true
  say
[[nina, there you are!]]
  say
[[i see you have passed 
my little test!]]
  setalk,qtalk=false,true
  say
[[e-excuse me, vat 
is going on?!]]
  sedr,setalk,qtalk=
   false,true,false
  say
[[forgive me doctor, 
i foresaw all of this...]]
  setalk=false
  whilst"15"
  s_ani(0,2,.1)
  say
[[sensei! ...i see!
you even knew]]
  sedr=true
  say
[[i'd make it 
outta there alive!]]
  s_ani(1)
  say
[[...]]
  setalk=true
  say
[[...sure]]
  setalk,qtalk=false,true
  say
[[vait! zis is not okay! 
you can't just valtz in--]]
  sedr,setalk,qtalk=
   false,true,false
  say
[[anyway, doctor,]]
  say
[[about that copy of 
oolongwatch...]]
  setalk,qtalk=false,true
  say
[[no! your game 
has not arrived!]]
  qangry=true
  say
[[and furthermore, 
get out!!]]
  say
[[i am done dealing 
vith you two today!]]
  setalk=true
  say
[[but i--]]
  psdr,sedr=false,true
  s_ani(1,4,.5)
  while sex>-30 do
   print("out, i say!",28,80,7)
   px-=1
   sex-=1
   yield()
  end
  qtalk,qangry=false,false
  whilst"60"
  qtalk=true
  say
[[vat a headache 
zis has been...]]
  qtalk=false
  cam_wait(-127)
  cine=cine_end
 end
)

cine_logoco=cocreate(
 function()
  decode(3072,512,0)
  music(20)
  whilst(120,draw_ss_logo,10,48)
  reload(0,0,0x800)
  decode(3072+512,256,64)
  memcpy(3072,4096,1024)
  cine=cine_title
 end
)

cine_logo=
 function()
  coresume(cine_logoco)
 end

cine_titleco=cocreate(
 function()
  while true do
   --[[
    note: 
    because this code runs in
    _draw, after lfb is set,
    btnpp will always be false.
    use btnp instead.
   ]]
   if btnp(🅾️) then
    yield()
    shouldclip=false
    cam_wait(148,
     function()return btnp(🅾️)end
    )
    cine=cine_intro
    started=lv!=0
   end
   yield()
  end
 end
)
cine_title=function()
 started=true
 draw_bg()
 //rectfill(0,0,127,147,1)
 coresume(cine_titleco)
 pal(1,6)
 for x=-48,127,48 do
  draw_gear(x,115)
  draw_gear(x+24,98)
 end
 pal()
 if time()%1==0 then
  shift(96,53,110,62)
  sfx(32)
 end
 map(96,53,4,4,16,10)

 //shouldclip happens to
 //get set when 🅾️ is pressed
 if time()%2>1 and shouldclip then
  print("press 🅾️ to start",30,88,7)
 end
end
function draw_old_logo()
 pal(10,9)
 for i=0,1 do
  sspr(96,16,16,16,0,15-i,30,50)
  sspr(96,16,16,16,130,65-i,-30,-50)
  rectfill(30,14,99,64-i,10)
  pal()
 end
 palt()
 pal(8,2)
 for i=0,1 do
  sspr(48,16,48,8,13-i,20,96,16)
  sspr(48,24,39,8,26+i,40,78,16)
  pal()
 end
 pal()
end

cine_endco=cocreate(
 function()
  camera(0,127)
  dset(0,0)
  dset(2,0) 
  whilst"3600"
  //secret secrets
  if scrolls==30 then
   music(15)
  elseif not ngp then
   music(14)
  end
  dset(5,1)
  teaser=true
 end
)
cine_end=function()
 camy=0
 end_card()
 coresume(cine_endco)
end

hglass_txt={
 7,
 "you got the hourglass!",
 11,
 "by holding ❎ you can briefly",
 "slow time itself!",
 7,
 "time is on your side now and",
 "god can't do a thing about it!"
}

tweight_txt={
 7,
 "you got the training weight!",
 "now you can no longer jump!",
 11,
 "(except for wall jumps!!)",
 6,
 "wait, is this even an upgrade??"
}
 

katrinka=
[[meow!!! who's there?
...oh thank god, i've been
lost in these mazes for hours!
my name is katrinka, i'm dr.
quail's assistant.
you're some kinda ninja, huh?
then please, collect all those
cogs with the green gems.
they seem to cause things here
to shift around. if i may 
venture a hypawthesis,
collecting enough should shift
us right meowtta here! probably.
if you really are a ninja, you
should be able to cling to walls
by jumping towards them!
in addition to jumping off 
of walls, you can press ⬇️ to
let go. i can't do it meowself!
so please, get us meowt of here!]]
-->8
--1bitlib
function encode(dest,y,rows)
 bidx=dest
 for y=y,y+rows do
  for x=0,127,8 do
   local data=0
   for i=0,7 do
    data=
     bor(data,
      shl(sget(x+i,y),i)
     )
   end
   poke(bidx,data)
   bidx+=1
  end
 end
 cstore()
end

function decode(strt,len,desty)
 for idx=0,len do
  local bidx=idx+strt
  local cpix=peek(bidx)
  for i=0,7 do
   local dpix=
    shr(band(cpix,shl(1,i)),i)
    sset(
     ((idx%16)*8)+i,
     desty+flr(idx/16),dpix
    )
  end
 end
end

--ss_logo_draw
function draw_ss_logo(x,y)
 sslx=sslx or x-38
 pal(1,9)
 print(
  "\80\82\69\83\69\78\84\69\68\32\66\89",
  x,y-7,9
 )
 spr(0,x,y,14,4)
 pal(1,7)
 spr(14,x+98,y+19,2,2)
 sslx+=4
 pal(1,1+rnd(15))
 clip(sslx,y,16,33)
 spr(0,x,y,14,4)
 spr(14,x+98,y+19,2,2)
 pal()
 clip()
end

