-- picross-8
-- by nbst

-- current screen
-- 0=title
-- 1=level select
-- 2=level play
-- 3=difficulty select
scr=0

-- title blinking
title_blink_in_max=12
title_blink_in=12
title_blink_out_max=4
title_blink_out=4
title_hidden=false

-- level selection
difficulty=0
selected_level=1

-- levels
levels = {}

-- current level data
level_data = {}

-- current cell
cell = {}
cell.x = 1
cell.y = 1

-- drawing/erasing?
drawing=false
erasing=false

-- marking/unmarking?
marking=false
unmarking=false

-- level victory?
victory=false

-- mouse support
mouse = {}
mouse.show=false

-- frame
frame = 0

-- bottom-right x/y of level
br=126


----- init -----
function _init()
 -- cartridge data
 cartdata("picross8_nbst")

 -- default screen
 scr=0
 
 -- levels (easy)
 easy_levels_count=12
 for i=1,easy_levels_count do
  -- definition
  levels[i] = {}
  levels[i].x=0+11*((i-1)%11)
  levels[i].y=0+11*flr(i/11.5)
  levels[i].s=10
  levels[i].slx=10+28*((i-1)%4)
  levels[i].sly=32+28*flr(i/4.5)
 end
 
 -- levels (normal)
 normal_levels_count=15
 for i=1,normal_levels_count do
  j=easy_levels_count+i
  -- definition
  levels[j]={}
  levels[j].x=0+16*((i-1)%8)
  levels[j].y=22+16*flr(i/8.5)
  levels[j].s=15
  levels[j].slx=10+23*((i-1)%5)
  levels[j].sly=38+23*flr(i/5.5)  
 end
 
 -- mouse support
 poke(0x5f2d, 1)
end

----- update -----
function _update()
 if (scr == 0) then
  update_title()
 elseif (scr == 1) then
  update_levelselect()
 elseif (scr == 2) then
  update_level()
 elseif (scr == 3) then
  update_difficultyselect()
 end
 
 -- mouse support
 mouse.prevx = mouse.x
 mouse.prevy = mouse.y
 mouse.prevb = mouse.b
 mouse.x = stat(32)
 mouse.y = stat(33)
 mouse.b = stat(34)
 
  -- count frames
 frame += 1
end

----- update title -----
function update_title()
 -- make text blink
 if (title_hidden == false and title_blink_in > 0) then
  title_blink_in -= 1
 elseif (title_hidden == false and title_blink_in == 0) then
  title_hidden = true
  title_blink_in = title_blink_in_max
 elseif (title_hidden == true and title_blink_out > 0) then
  title_blink_out -= 1
 elseif (title_hidden == true and title_blink_out == 0) then
  title_hidden = false
  title_blink_out = title_blink_out_max
 end
 -- go to level select on press
 if (btnp(4) or btnp(5)) then
  scr=3
 end
end

----- update difficulty select -----
function update_difficultyselect()
 -- move up/down
 if (btnp(2)) difficulty=0
 if (btnp(3)) difficulty=1
  -- go to level select on press
 if (btnp(4) or btnp(5)) then
  if (difficulty==0) selected_level=1
  if (difficulty==1) selected_level=easy_levels_count+1
  scr=1
 end
end

----- update level select -----
function update_levelselect()
 index_min=1
 index_max=easy_levels_count
 index_colmax=4 
 
 if (difficulty == 1) then
  index_min=easy_levels_count+1
  index_max=index_min+normal_levels_count-1
  index_colmax=5
 end
 
 if (btnp(0)) then
  if (selected_level > index_min) then
   selected_level -= 1
  end
 elseif (btnp(1)) then
  if (selected_level < index_max) then
   selected_level += 1
  end
 elseif (btnp(2)) then
  if (selected_level > index_min+index_colmax-1) then
   selected_level -= index_colmax
  end
 elseif (btnp(3)) then
  if (selected_level < index_max-index_colmax+1) then
   selected_level += index_colmax
  end
 elseif (btnp(5)) then
  scr=2
  menuitem(1,"quit puzzle", function() scr=1 menuitem(1) end)
  load_level(selected_level)
 elseif (btnp(4)) then
  scr=3
 end
end

----- update level -----
function update_level()
 -- mouse support
 if (mouse.prevx != mouse.x or mouse.prevy != mouse.y) then
  mouse.show = true
 end
 if (mouse.show == true) then
  if (mouse.x < br and mouse.x > br-#level_data*c and mouse.y < br and mouse.y > br-#level_data*c) then
   cell.x = flr((mouse.x-(br-#level_data*c))/c)+1
   cell.y = flr((mouse.y-(br-#level_data*c))/c)+1
   mouse.inrange = true
  else
   mouse.inrange = false
  end
 end

 -- keys
 if (btnp(0) and cell.x > 1) then
  cell.x -= 1
  mouse.show=false
 elseif (btnp(1) and cell.x < #level_data) then
  cell.x += 1
  mouse.show=false
 elseif (btnp(2) and cell.y > 1) then
  cell.y -= 1
  mouse.show=false
 elseif (btnp(3) and cell.y < #level_data) then
  cell.y += 1
  mouse.show=false
 elseif ((btnp(5) or (mouse.inrange == true and mouse.b == 1)) and drawing == false and erasing == false) then
  if (level_data[cell.x][cell.y].p == 1) then
   erasing=true
  else
   drawing=true  
  end
 elseif (btnp(4) and marking == false and unmarking == false) then
  if (level_data[cell.x][cell.y].p == 2) then
   unmarking=true
  else
   marking=true
  end 
 end
 
 if btn(5) == false and mouse.b != 1 then
  drawing=false
  erasing=false
 end
 
 if btn(4) == false then
  marking=false
  unmarking=false
 end
 
 if drawing then
  set_cell_value(cell.x,cell.y,1)
 end
 if erasing then
  set_cell_value(cell.x,cell.y,0)
 end
 
 if marking then
  set_cell_value(cell.x,cell.y,2)
 end
 if unmarking then
  set_cell_value(cell.x,cell.y,0)
 end 

 if (victory and (btnp(4) or btnp(5))) then
  dset(selected_level,1)
  victory=false
  scr=1
  menuitem(1)
 end
 
 check_victory()
end

----- check victory -----
function check_victory()
 ok=true
 for i=1,#level_data do
  for j=1,#level_data do
   if (level_data[i][j].s == 1 and level_data[i][j].p != 1) then
    ok=false
    break
   end
   if (level_data[i][j].s == 0 and level_data[i][j].p == 1) then
    ok=false
    break
   end
  end
 end
 if (ok) then
  victory=true
 end
end

----- set cell value -----
function set_cell_value(x,y,v)
 if (level_data[x][y].p != 1 and v == 1) sfx(0)
 if (level_data[x][y].p == 1 and v == 0) sfx(1)
 if (level_data[x][y].p != 2 and v == 2) sfx(2)
 if (level_data[x][y].p == 2 and v == 0) sfx(2)
 level_data[x][y].p = v
end

----- draw -----
function _draw()
 if (scr == 0) then
  draw_title()
 elseif (scr == 1) then
  draw_levelselect()
 elseif (scr == 2) then
  draw_level()
 elseif (scr == 3) then
  draw_difficultyselect()
 end
 
 if (_debug != nil) then
  print(_debug,0,0,3) 
 end
end

----- draw title -----
function draw_title()
 -- background
 map(112,48,0,0,16,16)

 -- text
 if (title_hidden == false) then
	 print("push button to start",24,48,15) 
 end
end

----- draw difficulty select -----
function draw_difficultyselect()
 -- background
 rectfill(0,0,128,128,12)
 map(112,61,0,104,16,16)
 
 -- title
 spr(64,22,0,11,2) 
 
 -- options
 print("easy (10x10 puzzles)",24,44,7)
 print("normal (15x15 puzzles)",24,60,7)
 
 -- arrow
 if (frame % 40 > 6) then
  if (difficulty==0) then
   print("\143",12,44,7) 
  else
   print("\143",12,60,7) 
  end 
 end
end

----- draw level select -----
function draw_levelselect()
 -- background
 rectfill(0,0,128,128,1)
 -- title
 spr(64,22,0,11,2)
 -- text
 print("select a level",36,20,6)
 
 -- levels
 if (difficulty==0) then
  levels_count=easy_levels_count 
  start=1
 else
  levels_count=easy_levels_count+normal_levels_count 
  start=easy_levels_count+1
 end
 for i=start,levels_count do
  draw_level_select_box(i,levels[i].slx,levels[i].sly,dget(i)) 
 end
 
 -- selection border
 l = levels[selected_level]
 slm=22
 if (difficulty==1) slm=17
 rect(l.slx-1,l.sly-1,l.slx+slm,l.sly+slm,6)
 
 -- buttons
 spr(7,30,116)
 print("back",42,118)
 spr(6,70,116)
 print("play",82,118)
end

----- draw level -----
function draw_level()
 -- background
 rectfill(0,0,128,128,1)

 -- borders
 line(br-c*#level_data,br,br,br,6)
 line(br,br-c*#level_data,br-c*#level_data,br-c*#level_data,6)
 line(br-c*#level_data,br,br-c*#level_data,br-c*#level_data,6)
 line(br,br-c*#level_data,br,br,6)
 
 -- vertical lines
 for i=1,#level_data do
  if i < #level_data then
   col=13
   if (i%5==0) col=7
   line(br-c*#level_data+i*c,br-c*#level_data+1,br-c*#level_data+i*c,br-1, col)  
  end
  v = 0
  n = 1
  for j=#level_data,1,-1 do
   if (level_data[i][j].s == 1) then
    v += 1
   elseif (v > 0) then
    spr(15+v,br-c*#level_data+i*c-font_offset,br-c*#level_data-(c*n))
    n += 1
    v = 0
   end
   if (j == 1 and v > 0) do
    spr(15+v,br-c*#level_data+i*c-font_offset,br-c*#level_data-(c*n))
   end
  end
  if (n==1 and v==0) then
   spr(31,br-c*#level_data+i*c-font_offset,br-c*#level_data-(c*n))
  end
 end
 -- horizontal lines
 for i=1,#level_data do
  if i < #level_data then
   col=13
   if (i%5==0) col=7
   line(br-c*#level_data+1,br-c*#level_data+i*c,br-1,br-c*#level_data+i*c, col)
  end
		v = 0
  n = 1
  for j=#level_data,1,-1 do
   if (level_data[j][i].s == 1) then
    v += 1
   elseif (v > 0) then
    spr(15+v,br-c*#level_data-(c*n),br-c*#level_data+i*c-font_offset)
    n += 1
    v = 0
   end
   if (j == 1 and v > 0) do
    spr(15+v,br-c*#level_data-(c*n),br-c*#level_data+i*c-font_offset)
   end
  end  
  if (n==1 and v==0) then
   spr(31,br-c*#level_data-(c*n),br-c*#level_data+i*c-font_offset)
  end
 end
 -- cell (selection)
 c1=br-c*#level_data+(cell.x-1)*c
 c2=br-c*#level_data+(cell.y-1)*c
 rect(c1,c2,c1+c,c2+c,8)
 -- cells (content)
 for i=1,#level_data do
  for j=1,#level_data do
   p = level_data[i][j].p
   if (p == 1) then
    p1=br-c*#level_data+(i-1)*c
    p2=br-c*#level_data+(j-1)*c
    rectfill(p1+1,p2+1,p1+c-1,p2+c-1,6)    
   elseif (p == 2) then
    p1=br-c*#level_data+(i-1)*c
    p2=br-c*#level_data+(j-1)*c
    rectfill(p1+c/2,p2+c/2,p1+c/2,p2+c/2,6)        
   end
  end
 end
 
 -- mouse cursor
 if (mouse.show) then
  spr(8,mouse.x,mouse.y)
 end
 
 -- victory message
 if (victory) then
  rectfill(8,8,120,32,13)
  print("congratulations!",32,12,2)
  print("(press a key to continue)",14,24,2)
 end
end

----- draw level select box -----
function draw_level_select_box(n,tx,ty,s)
 size=21
 if (difficulty==1)size=16
 
 mx=10
 my=9
 if (difficulty==1) then
  mx=7
  my=6
 end
 
 r=1
 if (difficulty==1) r=0 
  
 rectfill(tx,ty,tx+size,ty+size,0)
 if (s == 1) then
  draw_level_preview(n,tx-r,ty-r)
 else
  print("?",tx+mx,ty+my,6)
 end
end

----- draw level preview -----
function draw_level_preview(n,tx,ty)
 load_level(n)
 for i=1,#level_data do
  for j=1,#level_data do
   if (level_data[i][j].s == 1) then
    if (difficulty==0) then
     rectfill(tx+i*2,ty+j*2,tx+i*2+1,ty+j*2+1,6)    
    else
     pset(tx+i,ty+j,6)
    end
   end
  end
 end
end

----- load level -----
function load_level(n)
 lvl = levels[n]
 level_data = {}
 
 for i=1,lvl.s do
 level_data[i] = {}
  for j=1,lvl.s do
   level_data[i][j] = {}
   level_data[i][j].p = 0
   v = mget(lvl.x+i-1, lvl.y+j-1)
   if (v == 1) then
	   level_data[i][j].s = 1
   else
	   level_data[i][j].s = 0   
   end
  end
 end
 
 c=8
 if (lvl.s == 15) c=6
 
 font_offset=6
 if (lvl.s == 15) font_offset=5
 
 br=120
 if (difficulty==1)br=126
end