-- sandbox-8 1.0
-- by blokatt
-- 7.8.2016
-- @blokatt | blokatt.net

-- game
palette = {8, 14, 9, 10, 15, 11, 3, 12, 13, 5, 4, 6, 7, 2, 1} 
sand = {} 
cur_x = 64
cur_y = 64
last_x = 64
last_y = 64
any_moved = true 
colour = 1 
lmbp = 0
lmbp2 = 0
brush = 1
sine = 0

-- buttons
do_function = false
b_function = nil

-- intro and fading
fallspeed = 0
state = 0
fade = 1
fadestate = 0
timer = 60

-- mouse support
poke(0x5f2d, 1)

function _init()
	cls()
	sfx(6)
end

-- detect 1-frame button push 
function push()
	if (lmbp == 1) return true
	return false
end


function add_sand(x, y, col)
	x = x - 1 + flr(rnd(3))
	x = max(0, min(x, 127))
	y = y - 1 + flr(rnd(3))
	y = max(9, min(y, 119))

 	-- y-climbing
	local pass = true
	while not is_free(x, y+1) or (y == 119 and not is_free(x, y - 1)) do
		y -= 1
		if (y <= 8) break
	end

	if (y <= 4) pass = false
	if pass then
		local a = {}
		a.x = x
		a.y = y
		a.vy = 1
		a.first = true
		a.col = col
		a.move = 200
		add(sand, a)
	end
end

function is_free(x, y)
	if (sget(x, y) == 0) return true
	return false
end

function sand_update(a) 
	-- clear last position 
	sset(a.x, a.y, 0)

	-- deactivation timer
	if (a.x < last_x - 4 or a.x > last_x + 4 or a.y < last_y - 5 or a.y > last_y + 15) a.move -= 1

	-- physics
	local side = false
	for i = 1, a.vy do
		if is_free(a.x,a.y+1) and a.y < 119 then
			a.y += 1
			if (a.move < 100) a.move = 100
			any_moved = true
		else
			if (a.first) then
				last_x = a.x
 				last_y = a.y 
 				a.first = false
			end
 			if (a.y < 119) side = true
			break
		end
	end
	a.vy += rnd(.5)
	if side then
 		local right = true
		local air = is_free(a.x, a.y + 1)
	 	if (is_free(a.x-1, a.y) and is_free(a.x-1, a.y+1) and a.x > 0 and not air) then
	 		a.x -= 1
	 		a.y += 1
	 		a.move = 140
	 		any_moved = true
		else
			if (is_free(a.x+1, a.y) and is_free(a.x+1, a.y+1) and a.x < 127 and not air) then
	 			a.x += 1
	 			a.y += 1
	 			a.move = 140
	 			any_moved = true
	 		end	
		end
 	end

 	-- draw grain
 	sset(a.x, a.y, a.col)

 	-- sand deactivation
 	if (a.move <= 0 or a.y == 119) then
 		if (a.y != 119) then
	 		del(sand, a)
	 	else
	 		del(sand, a)
	 	end
	end	     	
end

function _update()
	if (fadestate == 0) then
		fade -= fade / 5
	end

	-- intro
	if (state == 0) then
		timer -= 1
		if (timer <= 0) then
			local pass = true
			local nexty, v, offset, multiplier, suboffset, yto
			for x = 8127, 0, -1 do
				offset = 0x6000 + x
				v = peek(offset)
				if (v != 0) then
					pass = false
					multiplier = 1
					suboffset = offset + 64
					if (peek(suboffset) == 0) then
						yto = flr(fallspeed)
						while multiplier < yto do
							if (suboffset + 64 < 0x6000) break
							if (peek(suboffset + 64) != 0) then
								sfx(flr(7 + rnd(1) + .5))
								break
							else
								multiplier += 1
								suboffset += 64 
							end	
						end
						if (rnd(50) <= 1) v = 0
						poke(suboffset, v)
						poke(offset, 0)
					end
				end
			end

			for x = 0, 50 do
				poke(0x7f00 + flr(rnd(0x100)), 0)
				pset(rnd(128), 120 + rnd(8), 0)
			end
			fallspeed += .25
			if (timer <= -60) then
				state = 1
				fade = 1
			end
		end
	end

	-- game
	if (state == 1) then
		sine += .1
		-- ui single button fire 
		if (not btn(4) and stat(34) == 0 and lmbp == 2) then
			lmbp = 0
		end
		if (lmbp == 1) then
			lmbp = 2
		end
		
		if ((btn(4) or stat(34) == 1) and lmbp == 0) then
			lmbp = 1
		end

		-- sand button ui slide fix
		if ((btn(4) or stat(34) == 1) and lmbp2 == 0 and cur_y > 8 and cur_y < 120 and lmbp != 2) then
			lmbp2 = 1
		end
		if (not btn(4) and stat(34) == 0 and lmbp2 == 1) then
			lmbp2 = 0
		end

		if (stat(32) != mx or stat(33) != my) then
			cur_x = stat(32)
			cur_y = stat(33)
		end

		mx = stat(32)
		my = stat(33)

		-- button controls
		local sp = 0
		if (btn(5) and cur_y > 8 and cur_y < 120) sp = 1
		if (btn(1)) cur_x += 1 + sp
		if (btn(0)) cur_x -= 1 + sp
		if (btn(3)) cur_y += 1 + sp
		if (btn(2)) cur_y -= 1 + sp

		-- y-boundary while sanding
		if (lmbp2 == 1) then
			cur_y = min(max(cur_y, 9), 119)
		end

		-- makin sand		
		if ((btn(4) or stat(34) == 1) and lmbp2 == 1 and cur_y > 8) then
		 	local c = palette[colour]
		 	if (colour == 16) c = palette[1 + flr(rnd(8))]
		 	for i = 0, brush do
		 		add_sand(cur_x, cur_y, c)
		 	end
		 	if (push()) music(0, 5000 - brush * 2000)
		else
			music(-1, 100)
		end

		-- colour selection
		if (cur_y <= 8 and push()) then
			for i = 0, 16 do
				if (cur_x >= i*8 and cur_x <= i*8 + 7) then
			 		sfx(1)
			 		colour = i+1 
				end
			end
		end

		-- cursor boundaries
	 	cur_x = max(1, min(128, cur_x))
		cur_y = max(0, min(127, cur_y))

		any_moved = false
		foreach(sand, sand_update)
		if (not any_moved) then
			destroy_sand()
		end
	end
end

function add_button(x, y, str, func)
	local x0 = x
	local y0 = y
	local x1 = x + 4 * #str
	local y1 = y + 5 * #str
	local hover = false

	if (cur_x >= x0 and cur_y >= y0 and cur_x <= x1 and cur_y <= y1) hover = true	
	if (hover) then
		print_fat(x, y, str, 13, 7)
		if (push()) then
			b_function = func
			do_function = true
			sfx(3)
		end
	else
		print_fat(x, y, str, 13, 6)
	end
end

function print_fat(x, y, str, c0, c1)
	print(str, x - 1, y, c0)
	print(str, x - 1, y - 1, c0)
	print(str, x - 1, y + 1, c0)
	print(str, x + 1, y - 1, c0)
	print(str, x + 1, y + 1, c0)
	print(str, x + 1, y, c0)
	print(str, x, y - 1, c0)
	print(str, x, y + 1, c0)
	print(str, x, y, c1)
end

function print_fat_center(x, y, str, c0, c1)
	local xoff = (#str * 4) / 2
	print(str, x - 1 - xoff, y, c0)
	print(str, x - 1 - xoff, y - 1, c0)
	print(str, x - 1 - xoff, y + 1, c0)
	print(str, x + 1 - xoff, y - 1, c0)
	print(str, x + 1 - xoff, y + 1, c0)
	print(str, x + 1 - xoff, y, c0)
	print(str, x - xoff, y - 1, c0)
	print(str, x - xoff, y + 1, c0)
	print(str, x - xoff, y, c1)
end

function _draw()
	
	-- intro
	if (state == 0) then
		if (timer > 0) then
			cls()
			print_fat_center(64 - fade * 150, 55, "sandbox-8 1.1", 13, 6)
			print_fat_center(64 + fade * 150, 63, "by @blokatt", 2, 13)
			print_fat_center(64 - fade * 150, 71, "august 2016", 2, 13)
		end
	end

	-- game
	if (state == 1) then
		cls()

		-- draw canvas
		sspr(0, 8, 128, 119, 0, 8)

		-- colour selection
		rectfill(0, 120, 127, 127, 2)
		rectfill(0, 0, 127, 8, 2)
		palt(0, false)
		spr(3, 120, 0)

		for i = 0, 15 do
			local xo = i * 8
			if (i < 15) then
		 		spr(0, xo, 0)
		 		rectfill(2+xo, 2, 5+xo, 5, palette[i+1])
			end	
			if (colour - 1 == i) then
				rect(1+xo, 1, 6+xo, 6, 6+flr(sin(sine) + .5))
			end
		end
		
		palt()

		line(0, 8, 127, 8, 1)
		line(0, 120, 127, 120, 1)

		-- bottom bar 
		do_function = false
		add_button(3, 122, "-new-", clear_canvas)
		add_button(26, 122, "-save-", save_canvas)
		add_button(54, 122, "-load-", load_canvas)
		add_button(82, 122, "-brush: " .. brush+1 .. "x-", function() brush = (brush + 1) % 3 end)
		
		-- execute selected action
		if (do_function) b_function()

		-- cursor sprites
		if (cur_y <= 8 or cur_y >= 120) then
			spr(2, cur_x-1, cur_y-1)
		else	
			spr(1, cur_x-3, cur_y-3)
		end

		-- fading
		if (fade > .15) then
			palt(7, true)
			palt(0, false)
			for x = 0, 16 do
				for y = 0, 16 do
					spr(4 + 10 * fade, x * 8, y * 8)
				end
			end
			palt()
		end
	end
end

function destroy_sand()
	for a in all(sand) do
		del(sand, a)
	end
end

function save_canvas() 
	sfx(5)
	for a in all(sand) do
		sset(a.x, a.y, 0)
		del(sand, a)
	end
	cstore(0, 0, 0x2000, "sandbox-8")
end

function load_canvas() 
	destroy_sand() 
	reload(0, 0, 0x2000, "sandbox-8")
	sfx(4)
end

function clear_canvas() 
	destroy_sand() 
	sfx(2)
	local done = false
	palt(7, true)
	
	local frame = 0
	while (frame < 12) do
		palt(0, false)
		done = true
		
		for y = 0, 127 do
			for x = 0, 127 do
				sset(x, y + 8, sget(32 + x % 8 + 8 * frame, y % 8))
			end
		end
		
		sspr(0, 9, 128, 111, 0, 9)
		flip()
	
		frame += 1
	end
	palt()
end
