-- snow!
-- by @freds72
function lerp(a,b,t)
return a*(1-t)+b*t
end
function pick(a)
return a[flr(rnd(#a))+1]
end
function clone(src)
local dst={}
for k,v in pairs(src) do
dst[k]=v
end
return dst
end
function make_v(a,b)
return {
b[1]-a[1],
b[2]-a[2],
b[3]-a[3]}
end
function v_clone(v)
return {v[1],v[2],v[3]}
end
function v_dot(a,b)
return a[1]*b[1]+a[2]*b[2]+a[3]*b[3]
end
function v_scale(v,scale)
v[1]*=scale
v[2]*=scale
v[3]*=scale
end
function v_add(v,dv,scale)
scale=scale or 1
v[1]+=scale*dv[1]
v[2]+=scale*dv[2]
v[3]+=scale*dv[3]
end
function v_len(v)
local x,y,z=v[1],v[2],v[3]
local d=max(max(abs(x),abs(y)),abs(z))
x/=d
y/=d
z/=d
return d*(x*x+y*y+z*z)^0.5
end
function v_normz(v)
local d=v_len(v)
v[1]/=d
v[2]/=d
v[3]/=d
end
function v_lerp(a,b,t)
return {
lerp(a[1],b[1],t),
lerp(a[2],b[2],t),
lerp(a[3],b[3],t)
}
end
function v_cross(a,b)
local ax,ay,az=a[1],a[2],a[3]
local bx,by,bz=b[1],b[2],b[3]
return {ay*bz-az*by,az*bx-ax*bz,ax*by-ay*bx}
end
local v_up={0,1,0}
function m_x_v(m,v)
local x,y,z=v[1],v[2],v[3]
return {m[1]*x+m[5]*y+m[9]*z+m[13],m[2]*x+m[6]*y+m[10]*z+m[14],m[3]*x+m[7]*y+m[11]*z+m[15]}
end
function m_x_m(a,b)
local a11,a12,a13,a14=a[1],a[5],a[9],a[13]
local a21,a22,a23,a24=a[2],a[6],a[10],a[14]
local a31,a32,a33,a34=a[3],a[7],a[11],a[15]
local b11,b12,b13,b14=b[1],b[5],b[9],b[13]
local b21,b22,b23,b24=b[2],b[6],b[10],b[14]
local b31,b32,b33,b34=b[3],b[7],b[11],b[15]
return {
a11*b11+a12*b21+a13*b31,a21*b11+a22*b21+a23*b31,a31*b11+a32*b21+a33*b31,0,
a11*b12+a12*b22+a13*b32,a21*b12+a22*b22+a23*b32,a31*b12+a32*b22+a33*b32,0,
a11*b13+a12*b23+a13*b33,a21*b13+a22*b23+a23*b33,a31*b13+a32*b23+a33*b33,0,
a11*b14+a12*b24+a13*b34+a14,a21*b14+a22*b24+a23*b34+a24,a31*b14+a32*b24+a33*b34+a34,1
}
end
function make_m_from_v_angle(up,angle)
local fwd={-sin(angle),0,cos(angle)}
local right=v_cross(up,fwd)
v_normz(right)
fwd=v_cross(right,up)
return {
right[1],right[2],right[3],0,
up[1],up[2],up[3],0,
fwd[1],fwd[2],fwd[3],0,
0,0,0,1
}
end
function m_inv(m)
m[2],m[5]=m[5],m[2]
m[3],m[9]=m[9],m[3]
m[7],m[10]=m[10],m[7]
end
function m_right(m)
return {m[1],m[2],m[3]}
end
function m_up(m)
return {m[5],m[6],m[7]}
end
function m_fwd(m)
return {m[9],m[10],m[11]}
end
function corun(f,arg0,arg1,arg2)
local cs=costatus(f)
if cs=="suspended" then
assert(coresume(f,arg0,arg1,arg2))
return f
end
return nil
end
function sort(data)
local n = #data
if(n<2) return
for i = flr(n / 2) + 1, 1, -1 do
local parent, value, m = i, data[i], i + i
local key = value.key
while m <= n do
if ((m < n) and (data[m + 1].key > data[m].key)) m += 1
local mval = data[m]
if (key > mval.key) break
data[parent] = mval
parent = m
m += m
end
data[parent] = value
end
for i = n, 2, -1 do
local value = data[i]
data[i], data[1] = data[1], value
local parent, terminate, m = 1, i - 1, 2
local key = value.key
while m <= terminate do
local mval = data[m]
local mkey = mval.key
if (m < terminate) and (data[m + 1].key > mkey) then
m += 1
mval = data[m]
mkey = mval.key
end
if (key > mkey) break
data[parent] = mval
parent = m
m += m
end
data[parent] = value
end
end
local fadetable={}
for i=0,15 do
local r={}
fadetable[i]=r
for j=0,4 do
r[j]=sget(24+j,i)
end
end
function whiteout_async(delay,reverse)
for i=1,delay do
yield()
end
for i=0,4 do
i=reverse and (4-i) or i
for c=0,15 do
if flr(i+1)>=5 then
pal(c,7,1)
else
pal(c,fadetable[c][flr(i)],1)
end
end
yield()
end
end
local actors,ground,plyr,cam={}
local k_far,k_near,k_right,k_left,z_near=0,2,4,8,0.2
function make_cam()
local up={0,1,0}
local shkx,shky=0,0
camera()
local clouds,clouds2={},{}
for i=-16,16 do
add(clouds,{i=i,r=max(8,rnd(16))})
add(clouds2,{i=i,r=max(12,rnd(24))})
end
return {
pos={0,0,0},
angle=0,
m=make_m_from_v_angle(v_up,0),
shake=function()
shkx,shkx=min(4,shkx+rnd(8)),min(4,shky+rnd(8))
end,
update=function()
shkx*=-0.7-rnd(0.2)
shky*=-0.7-rnd(0.2)
if abs(shkx)<0.5 and abs(shky)<0.5 then
shkx,shky=0,0
end
camera(shkx,shky)
end,
track=function(self,pos,a,u,power)
pos=v_clone(pos)
self.angle=lerp(self.angle,a,power or 0.8)
up=v_lerp(up,u,0.1)
v_normz(up)
local m=make_m_from_v_angle(up,self.angle)
v_add(pos,m_up(m),1.6)
m_inv(m)
self.m=m_x_m(m,{
1,0,0,0,
0,1,0,0,
0,0,1,0,
-pos[1],-pos[2],-pos[3],1
})
self.pos=pos
end,
project2d=function(self,v)
local w=63.5/v[3]
return 63.5+flr(w*v[1]),63.5-flr(w*v[2]),w
end,
project_poly=function(self,p,c0)
local x0,y0=self:project2d(p[1])
local x1,y1=self:project2d(p[2])
for i=3,#p do
local x2,y2=self:project2d(p[i])
trifill(x0,y0,x1,y1,x2,y2,c0)
x1,y1=x2,y2
end
end,
draw_horizon=function(self,ground_color,sky_color)
cls(sky_color)
local n=m_up(self.m)
v_scale(n,-1)
local x0,y0=self:project2d({0,-n[3]/n[2],1})
n[3]=0
v_normz(n)
v_scale(n,16)
local u,v=n[1],n[2]
fillp(0xf0f0)
circfill(x0-3*u+2*v,y0+3*v+2*u,8,0xc7)
fillp()
circfill(x0-3*u+2*v,y0+3*v+2*u,5,7)
local xl,yl,xr,yr=0,y0-u*x0/v,128,y0+u*(128-x0)/v
if(yl>yr) xl,yl,xr,yr=xr,yr,xl,yl
fillp(0xa5a5.f)
for _,c in pairs(clouds2) do
circfill(x0+c.i*v,y0+c.i*u,c.r,6)
end
fillp()
for _,c in pairs(clouds) do
circfill(x0+c.i*v,y0+c.i*u,c.r,ground_color)
end
rectfill(0,128,128,yr,ground_color)
trifill(xl,yl,xr,yr,xl,yr,ground_color)
end
}
end
function make_body(p)
local up,oldf={0,1,0}
local velocity,angularv,forces,torque={0,0,0},0,{0,0,0},0
local angle,steering_angle,on_air_ttl=0,0,0
local g={0,-4,0}
return {
pos=v_clone(p),
on_ground=false,
height=0,
get_pos=function(self)
return self.pos,angle,steering_angle/0.625,velocity
end,
get_up=function()
local scale=abs(cos(angle))
local u=v_lerp(v_up,up,scale)
local m=make_m_from_v_angle(u,angle)
local right=m_right(m)
v_add(u,right,sin(steering_angle)*scale/2)
v_normz(u)
return u
end,
apply_force_and_torque=function(self,f,t)
v_add(forces,f)
torque+=t
end,
integrate=function(self)
self:apply_force_and_torque(g,0)
if self.on_ground==true then
local n=v_clone(up)
v_scale(n,-v_dot(n,g))
self:apply_force_and_torque(n,0)
end
v_add(velocity,forces,0.5/30)
angularv+=torque*0.5/30
angularv*=0.86
local f=self.on_ground==true and 0.08 or 0.01
v_add(velocity,velocity,-f*v_dot(velocity,velocity))
v_add(self.pos,velocity)
angularv=mid(angularv,-1,1)
angle+=angularv
forces,torque={0,0,0},0
end,
steer=function(self,steering_dt)
steering_angle+=mid(steering_dt,-0.15,0.15)
if self.on_ground==true and v_len(velocity)>0.001 then
local m=make_m_from_v_angle(up,angle-steering_angle/16)
local right,fwd=m_right(m),m_fwd(m)
local sa=-v_dot(velocity,right)
if abs(sa)>0.001 then
local vn=v_clone(velocity)
v_normz(vn)
local grip=1-abs(v_dot(fwd,vn))
sa*=60*grip
sa=mid(sa,-3,3)
local ski_len=0.8
v_scale(right,sa)
self:apply_force_and_torque(right,-steering_angle*ski_len/4)
end
elseif self.on_ground==false then
self:apply_force_and_torque({0,0,0},-steering_angle/4)
end
end,
update=function(self)
steering_angle*=0.8
on_air_ttl-=1
local pos=self.pos
local newf,newpos,gps=ground:find_face(pos)
if newf then
oldf=newf
end
self.gps=gps-angle
self.on_ground=false
local tgt_height=1
if newpos and pos[2]<=newpos[2] then
up=newf.n
tgt_height=pos[2]-newpos[2]
pos[2]=newpos[2]
self.on_ground=true
if(on_air_ttl>5) sfx(12) on_air_ttl=0 sfx(11)
end
if(self.on_ground==false) on_air_ttl=10
self.height=lerp(self.height,tgt_height,0.4)
local pitch=v_len(velocity)*max(48-64*self.height)
for src=0x34ec,0x350a,2 do
local s=peek2(src)
poke2(src,bor(band(0xffc0,s),band(0x3f,flr(pitch+rnd(4)))))
end
end
}
end
function make_plyr(p,params)
local body,hp=make_body(p),3
local body_update=body.update
local hit_ttl,jump_ttl,jump_pressed=0,0
local spin_angle,spin_prev=0
local t,bonus,total_t,total_tricks,reverse_t,air_t=params.total_t,{},0,0,0,-60
local whoa_sfx={5,6,7}
local function add_time_bonus(tb,msg)
t+=tb*30
local ttl=12+rnd(12)
add(bonus,{t="+"..tb.."s",msg=msg,x=rnd(5),ttl=ttl,duration=ttl})
if(msg) sfx(pick(whoa_sfx)) total_tricks+=1
end
body.control=function(self)
local da=0
if(btn(0)) da=1
if(btn(1)) da=-1
local do_jump
if self.on_ground==true then
if air_t>23 then
if reverse_t>0 then
add_time_bonus(2,"reverse air!")
else
add_time_bonus(1,"air!")
end
end
air_t=0
if btn(4) then
if(not jump_pressed) jump_pressed,jump_ttl=true,0
jump_ttl=min(jump_ttl+1,9)
elseif jump_pressed then
do_jump=true
end
else
jump_ttl,jump_pressed,do_jump=0
air_t+=1
end
if do_jump then
self:apply_force_and_torque({0,jump_ttl*7,0},0)
jump_ttl,jump_pressed,do_jump=0
end
self:steer(da/8)
end
body.update=function(self)
t-=1
hit_ttl-=1
total_t+=1
local pos,angle,_,velocity=self:get_pos()
if not spin_prev then
spin_angle,spin_prev=0,angle
else
local da=spin_prev-angle
if(abs(da)>0.5) da+=0.5
if abs(spin_angle)>=abs(spin_angle+da) then
spin_prev=nil
else
spin_angle+=da
spin_prev=angle
end
end
if abs(spin_angle)>1 then
add_time_bonus(2,"360!")
spin_prev=nil
end
local hit_type,hit_actor=ground:collide(pos,0.2)
if hit_type==2 then
cam:shake()
self.dead=true
elseif hit_type==3 then
add_time_bonus(1)
sfx(8)
elseif hit_ttl<0 and hit_type==1 then
sfx(pick(hit_actor.sfx))
cam:shake()
hit_ttl=20
hp-=1
reverse_t,spin_prev=0
end
local slice,slice_extent=ground:get_track(pos)
self.on_track=true
if pos[1]>=slice_extent[1] and pos[1]<=slice_extent[2] then
if slice.is_checkpoint then
if pos[3]>slice_extent[3] then
add_time_bonus(params.bonus_t)
sfx(1)
end
slice.is_checkpoint=nil
end
else
self.on_track=nil
end
if v_dot(velocity,{-sin(angle),0,cos(angle)})<-0.2 then
reverse_t+=1
else
reverse_t=0
end
if reverse_t>30 then
add_time_bonus(3,"reverse!")
reverse_t=0
end
for _,b in pairs(bonus) do
b.ttl-=1
if(b.ttl<0) del(bonus,b)
end
if hp<=0 then
self.dead=true
elseif t<0 then
self.time_over,self.dead=true,true
end
body_update(self)
end
body.score=function()
return t,bonus,total_t,total_tricks
end
return body
end
function make_snowball(pos)
local body=make_body(pos)
local body_update=body.update
body.sx,body.sy=112,0
body.update=function(self)
self:integrate()
body_update(self)
return true
end
return body
end
local states={}
function pop_state()
assert(#states>0,"missing base state")
states[#states]=nil
end
function push_state(state,...)
add(states,state(...))
end
function menu_state()
local cols={
[0]=5,
[1]=12,
[6]=7,
[8]=14}
function draw_box(s,x,y,c,blink,freeride)
palt(0,false)
palt(14,true)
sspr(40,0,8,8,x-4,y-12,8,64)
pal(12,c)
if blink then
if (30*time())%8<4 then
pal(12,cols[c])
pal(c,cols[c])
pal(6,cols[6])
end
end
spr(32,x-24,y-6,7,2)
print(s,x-20,y-2,6)
if freeride==true then
spr(234,x-8,y-29,2,2)
rectfill(x-18,y-13,x+24,y-8,10)
print("FREERIDING",x-16,y-13,0)
end
pal()
end
local records={900,600,450}
for i=0,2 do
local t=dget(i)
records[i+1]=t>0 and t or records[i+1]
end
local tree_prop,bush_prop,cow_prop={sx=112,sy=16,r=1.4,sfx={9,10}},{sx=96,sy=32,r=1,sfx={9,10}},{sx=112,sy=48,r=1,sfx={4}}
local panels={
{text="marmottes",c=1,params={dslot=0,slope=1.5,tracks=1,bonus_t=2,total_t=30*30,record_t=records[1],props={tree_prop},props_rate=0.85}},
{text="biquettes★",c=8,params={dslot=1,slope=2,tracks=2,bonus_t=1.5,total_t=20*30,record_t=records[2],props={tree_prop,bush_prop},props_rate=0.87,}},
{text="chamois★★",c=0,params={dslot=2,slope=3,tracks=3,bonus_t=1.5,total_t=15*30,record_t=records[3],props={tree_prop,tree_prop,tree_prop,cow_prop},props_rate=0.92,}}
}
local sel,sel_tgt,blink=0,0,false
ground=make_ground({slope=0,tracks=0,props_rate=0.6,props={tree_prop}})
reload()
cam=make_cam()
music(0)
sfx(-1)
return {
draw=function()
cam:draw_horizon(1,12)
local out={}
ground:collect_drawables(cam.pos,cam.angle,out,dist)
sort(out)
draw_drawables(out)
local a,da=1/3,-1/3
for i=1,#panels do
local v={8*cos(a),0.8,-8*sin(a)}
v_add(v,cam.pos)
v=m_x_v(cam.m,v)
if v[3]>0 then
local x0,y0=cam:project2d(v)
local p=panels[i]
draw_box(p.text,x0+32,y0,p.c,blink,p.params.tracks>1)
end
a+=da
end
rectfill(0,0,127,27,0)
rectfill(0,92,127,127,0)
palt(14,true)
palt(0,false)
spr(128,64,28,8,9)
spr(128,0,28,8,9,true)
palt()
if sel==sel_tgt then
local s="best⧗: "..time_tostr(panels[sel+1].params.record_t)
print(s,64-2*#s,97,sget(37,16*(time()%1)))
end
printb("⬅️➡️ select track",31,110,7,5)
if((time()%1)<0.5) printb("❎/🅾️ go!",50,120,10,5)
print("▤@freds72 - ♪@gruber",20,2,1)
spr(64,28,8,10,3)
srand(13)
local t=time()
for i=0,256 do
local a,s=rnd(),1+rnd(0.5)
local u,v,x0=s*cos(a),s*abs(2*sin(a)),rnd(128)
local x,y=flr(x0+t*u)%128,8+flr(t*v)%20
if pget(x,y)==12 then
pset(x,y,6+x0%2)
end
end
end,
update=function()
if(start_game_async) start_game_async=corun(start_game_async)
if(btnp(0)) sel-=1
if(btnp(1)) sel+=1
sel=mid(sel,0,#panels-1)
sel_tgt=lerp(sel_tgt,sel,0.18)
if abs(sel_tgt-sel)<0.01 then
sel_tgt=sel
end
if btnp(4) or btnp(5) then
sel_tgt=sel
sfx(8)
start_game_async=cocreate(function()
for i=1,15 do
blink=i%2==0 and true
yield()
end
pop_state()
srand(time())
push_state(zoomin_state,play_state,panels[sel+1].params)
end)
end
cam:track({64,0,64},sel_tgt/3,v_up)
end
}
end
function zoomin_state(next,params)
local ttl,dttl,fade_async=30,0.01,cocreate(whiteout_async)
memcpy(0x0,0x6000,128*64)
return {
draw=function()
local s=3*(30-ttl)/30+1
palt(0,false)
local dx=-abs(64*s-64)
sspr(0,0,128,128,dx,dx,128*s,128*s)
if(fade_async) fade_async=corun(fade_async,15)
end,
update=function(self)
ttl-=dttl
dttl+=0.08
if not fade_async then
pop_state()
reload()
push_state(next,params)
end
end
}
end
function play_state(params)
local fade_async=cocreate(whiteout_async)
music(-1,250)
actors,ground={},make_ground(params)
plyr=make_plyr(ground.plyr_pos,params)
cam=make_cam()
local rot_sprites={
make_rspr(112,32,128),
make_rspr(48,0,128)}
local prev_prop
for _,prop in pairs(params.props) do
if prev_prop!=prop then
add(rot_sprites,make_rspr(prop.sx,prop.sy,128))
prev_prop=prop
end
end
local gps_sprite=make_rspr(96,48,256)
return {
draw=function()
cam:draw_horizon(1,12)
local out={}
ground:collect_drawables(cam.pos,cam.angle,out,dist)
for _,a in pairs(actors) do
local p=m_x_v(cam.m,a.pos)
local ax,ay,az=p[1],p[2],p[3]
if az>z_near and az<64 then
local x,y,w=cam:project2d(p)
out[#out+1]={key=1/(ay*ay+az*az),a=a,x=x,y=y,w=4*w,dist=1}
end
end
local angle=atan2(cam.m[5],cam.m[6])+0.25
for _,f in pairs(rot_sprites) do
f(-angle)
end
sort(out)
draw_drawables(out)
if plyr then
local pos,a,steering=plyr:get_pos()
local dy=plyr.height*24
spr(9,34+3*cos(time()/4),128+dy-steering*14,4,4)
spr(9,74-2*cos(time()/5),128+dy+steering*14,4,4,true)
palt(0,false)
palt(7,true)
spr(140,abs(steering)*16-24,90-dy/3,4,4)
spr(140,96-abs(steering)*16+24,90-dy/3,4,4,true)
palt()
local t,bonus,total_t=plyr:score()
local bk,y_trick=1,110
if t<150 then
if(t%30==0) sfx(2)
if(t%8<4) bk=8
end
printb(time_tostr(t),nil,4,10,9,bk)
for i=1,#bonus do
local b=bonus[i]
if b.ttl/b.duration>0.5 or t%2==0 then
printb(b.t,64+b.x-#b.t/1.5,40+b.ttl,10,9,1)
end
if(b.msg) printb(b.msg,nil,y_trick,6,5,1) y_trick-=9
end
if(plyr.gps) gps_sprite(-plyr.gps)
if plyr.on_track and (32*time())%8<4 then
local dx=plyr.gps-0.75
if dx<-0.1 then
sspr(64,112,16,16,2,32,32,32)
elseif dx>0.1 then
sspr(64,112,16,16,96,32,32,32,true)
end
end
spr(108,56,12,2,2)
if total_t<90 then
printb("🅾️ charge jump",nil,102,6,5,1)
printb("❎ restart",nil,112,8,2,1)
end
end
if(fade_async) fade_async=corun(fade_async,0,true)
end,
update=function()
cam:update()
if plyr then
plyr:control()
plyr:integrate()
plyr:update()
ground:update(plyr.pos)
local pos,a=plyr:get_pos()
cam:track(pos,a,plyr:get_up())
if plyr.dead then
sfx(3)
cam:shake()
local _,_,total_t,total_tricks=plyr:score()
push_state(plyr_death_state,plyr:get_pos(),total_t,total_tricks,params,plyr.time_over)
plyr=nil
else
if btnp(5) then
pop_state()
push_state(zoomin_state,play_state,params)
end
end
end
for a in all(actors) do
if not a:update() then
del(actors,a)
end
end
end
}
end
function plyr_death_state(pos,total_t,total_tricks,params,time_over)
local active_msg,msgs=0,{
"total time: "..time_tostr(total_t),
"total tricks: "..total_tricks}
local msg_colors={
{10,9,1},{7,5,1}
}
local msg_y,msg_tgt_y,msg_tgt_i=-20,{16,-20},0
local snowball_sprite,snowball=make_rspr(112,0,32,0),add(actors,make_snowball(pos))
local turn_side,tricks_rating=pick({-1,1}),{"    meh","rookie","junior🐱","★master★"}
local text_ttl,active_text,text=10,"yikes!",{
"ouch!","aie!","pok!","weee!"
}
if total_t>params.record_t then
dset(params.dslot,total_t)
end
return {
draw=function()
local c=msg_colors[active_msg+1]
printb(msgs[active_msg+1],nil,msg_y,c[1],c[2],c[3])
local x,y=rnd(2)-1,msg_y+8+rnd(2)-1
if(active_msg==0 and total_t>params.record_t) print("★new record★",x+50,y,c[2])
if(active_msg==1) print(tricks_rating[min(flr(total_tricks/5)+1,4)],x+70,y,c[2])
if text_ttl>0 and not time_over then
print(active_text,60,50+text_ttl,8)
end
printb("game over!",nil,38,8,2,7)
if((time()%1)<0.5) printb("❎/🅾️ retry",42,120,10,5,1)
end,
update=function()
msg_y=lerp(msg_y,msg_tgt_y[msg_tgt_i+1],0.08)
if(abs(msg_y-msg_tgt_y[msg_tgt_i+1])<1) msg_tgt_i+=1
if(msg_tgt_i>#msg_tgt_y-1) msg_tgt_i=0 active_msg=(active_msg+1)%2
text_ttl-=1
snowball_sprite(turn_side*time()*2)
local p=snowball.pos
ground:update(p)
if text_ttl<0 and ground:collide(p,0.2) then
active_text,text_ttl=pick(text),10
turn_side*=-1
cam:shake()
end
if time_over then
cam:track(p,0,v_up)
else
cam:track({mid(p[1],8,29*4),p[2],p[3]+16},0.5,v_up,0.2)
end
if btnp(4) or btnp(5) then
pop_state()
pop_state()
push_state(menu_state)
end
end
}
end
function _init()
cartdata("freds2_st8p")
for i=0,15 do
local r={}
fadetable[i]=r
for j=0,4 do
r[j]=sget(24+j,i)
end
end
push_state(menu_state)
end
function _update()
for state in all(states) do
state:update()
end
end
function _draw()
for state in all(states) do
state:draw()
end
end
local dither_pat={0xffff,0x7fff,0x7fdf,0x5fdf,0x5f5f,0x5b5f,0x5b5e,0x5a5e,0x5a5a,0x1a5a,0x1a4a,0x0a4a,0x0a0a,0x020a,0x0208,0x0000}
function create_hexpal(mem,cx)
for i=0,15 do
poke(mem+i,sget(cx,i))
end
poke(mem,0x10)
end
create_hexpal(0x4300,33)
create_hexpal(0x4310,34)
function draw_sprite(actor,x,y,w,dist)
if dist>8 then
memcpy(0x5f00,0x4310,16)
elseif dist>7 then
memcpy(0x5f00,0x4300,16)
end
local sx,sy=actor.sx,actor.sy
if actor.strip then
local strip=actor.strip[flr((actor.speed*time())%#actor.strip)+1]
sx,sy=strip.sx,strip.sy
end
sspr(sx,sy,16,16,x-w/2,actor.y or y-w,w,w)
pal()
end
function draw_drawables(objects)
for i=1,#objects do
local d=objects[i]
if d.a then
draw_sprite(d.a,d.x,d.y,d.w,d.dist)
else
local c0=0x76
if d.f.m==0 then
c0=0x54
if(d.dist>7) c0=0x4d
if(d.dist>8) c0=0xd5
else
if(d.dist>7) c0=0x6d
if(d.dist>8) c0=0xd5
end
fillp(d.f.cf)
cam:project_poly(d.v,c0)
if d.fa then
local m,v0,u=cam.m,d.v0,d.fa.u
local x,y,z=v0[1]+u[1],v0[2]+u[2],v0[3]+u[3]
local az=m[3]*x+m[7]*y+m[11]*z+m[15]
if az>z_near then
local w=63.5/az
draw_sprite(d.fa,63.5+w*(m[1]*x+m[5]*y+m[9]*z+m[13]),63.5-w*(m[2]*x+m[6]*y+m[10]*z+m[14]),4*w,d.dist)
end
end
end
end
fillp()
end
function make_tracks(xmin,xmax,max_tracks)
local seeds={}
local function add_seed(x,u,branch)
local ttl,trick_ttl,trick_type
local function reset_seed_timers()
ttl,trick_ttl,trick_type=12+rnd(20),4+rnd(4),flr(rnd(2))
end
reset_seed_timers()
local angle=0.05+rnd(0.45)
return add(seeds,{
age=0,
h=0,
x=x or xmin+rnd(xmax-xmin),
u=u or cos(angle),
angle=angle,
update=function(self)
if(self.dead) del(seeds,self) return
self.age+=1
trick_ttl-=1
ttl-=1
if branch and trick_ttl<0 then
if trick_type==0 then
self.h+=1.5
elseif trick_type==1 then
self.h=-4
end
if(trick_ttl<-5) self.h=0 ttl=4+rnd(2)
end
if ttl<0 then
reset_seed_timers()
self.u=cos(0.05+rnd(0.45))
if rnd()<0.5 and #seeds<max_tracks then
add_seed(self.x,-self.u,true)
end
end
self.x+=self.u
if self.x<xmin then
self.u=-self.u
self.x=xmin
elseif self.x>xmax then
self.u=-self.u
self.x=xmax
end
end
})
end
add_seed().main=true
return function()
for s in all(seeds) do
s:update()
end
for i=1,#seeds do
local s0=seeds[i]
for j=i+1,#seeds do
local s1=seeds[j]
if s1.age>0 and flr(s0.x-s1.x)==0then
s1=s1.main and s0 or s1
s1.dead=true
end
end
end
return seeds
end
end
function make_ground(params)
local delta_slope=params.slope
local nx,nz,dx,dy,dz=32,32,4,0,4
local slices={}
local next_tracks=make_tracks(8,nx-8,params.tracks or 3)
local v_ground_cache_cls={
__index=function(t,k)
local m,i,j=t.m,k%nx,flr(k/nx)
local s0=slices[j]
local x,y,z=i*dx,s0.h[i]+s0.y-dy,j*dz
local ax,az=m[1]*x+m[5]*y+m[9]*z+m[13],m[3]*x+m[7]*y+m[11]*z+m[15]
local outcode=az>z_near and k_far or k_near
if ax>az then outcode+=k_right
elseif -ax>az then outcode+=k_left
end
t[k]={ax,m[2]*x+m[6]*y+m[10]*z+m[14],az,outcode=outcode}
return t[k]
end
}
local slice_id,slice_y=0,0
local left_pole,right_pole,coin={sx=48,sy=0},{sx=112,sy=32},{speed=3,r=1,score=1,strip={{sx=64,sy=96},{sx=80,sy=96},{sx=96,sy=96},{sx=112,sy=96}}}
local function make_slice(y)
slice_y=lerp(slice_y,y,0.2)
y=slice_y
local tracks=next_tracks()
local h,actors={},{}
for i=0,nx-1 do
h[i]=rnd(2*delta_slope)
if rnd()>params.props_rate then
actors[i]=clone(pick(params.props))
end
end
for k=1,2 do
for i=0,nx-1 do
h[i]=(h[i]+h[(i+1)%nx])/2
end
end
h[0],h[nx-1]=15+rnd(5),15+rnd(5)
local main_track_x,xmin,xmax,is_checkpoint
for _,t in pairs(tracks) do
local ii=flr(t.x)
local i0,i1=ii-2,ii+1
if t.main then
main_track_x,xmin,xmax=t.x,i0*dx,i1*dx
for i=i0,i1 do
h[i]=t.h+h[i]/4
actors[i]=nil
end
if slice_id%8==0 then
is_checkpoint={}
actors[i0]=clone(left_pole)
actors[i1]=clone(right_pole)
end
else
for i=i0,i1 do
h[i]=(t.h+h[i])/2
end
if(slice_id%2==0) actors[ii]=clone(coin)
end
end
slice_id+=1
return {
y=y,
h=h,
x=main_track_x*dx,
xmin=xmin,
xmax=xmax,
actors=actors,
is_checkpoint=is_checkpoint
}
end
local function mesh(j)
local s0,s1=slices[j],slices[j+1]
local sn={0,dz,s0.y-s1.y}
v_normz(sn)
local function with_material(f,i)
local c=5*f.n[2]
local cf=(#dither_pat-1)*(1-c%1)
f.cf=dither_pat[flr(cf)+1]
if(i==0 or i==nx-2) f.m=1 return f
f.m=v_dot(sn,f.n)<0.8 and 0 or 1
return f
end
local f,fi,actor={},0
for i=0,nx-2 do
local v0={i*dx,s0.h[i]+s0.y,j*dz}
local u1={dx,s0.h[i+1]-s0.h[i],0}
local u2={dx,s1.h[i+1]+s1.y-v0[2],dz}
local u3={0,s1.h[i]+s1.y-v0[2],dz}
local n0,n1=v_cross(u3,u2),v_cross(u2,u1)
v_normz(n0)
v_normz(n1)
if v_dot(n0,n1)>0.995 then
f[fi]=with_material({n=n0},i)
else
f[fi]=with_material({n=n0},i)
f[fi+1]=with_material({n=n1},i)
end
local u,t0,t1=v_clone(u2),rnd(),rnd()
v_scale(u,t0)
v_add(u,u3,t1)
v_scale(u,1/(rnd()+t0+t1))
if(s0.actors[i]) s0.actors[i].u=u
fi+=2
end
s0.f=f
end
for j=0,nz-1 do
slices[j]=make_slice(-j*delta_slope)
end
for j=0,nz-2 do
mesh(j)
end
local function collect_face(v0,face,actor,vertices,v_cache,cam_pos,out,dist)
if v_dot(face.n,cam_pos)>v_dot(face.n,v0) then
local z,y,outcode,verts,is_clipped=0,0,0xffff,{},0
for ki,vi in pairs(vertices) do
local a=v_cache[vi]
y+=a[2]
z+=a[3]
outcode=band(outcode,a.outcode)
is_clipped+=band(a.outcode,2)
verts[ki]=a
end
if outcode==0 then
y/=#verts
z/=#verts
if(is_clipped>0) verts=z_poly_clip(z_near,verts)
if #verts>2 then
out[#out+1]={key=1/(y*y+z*z),f=face,fa=actor,v=verts,dist=dist,v0=v0}
end
end
elseif actor then
local m,u=v_cache.m,actor.u
local x,y,z=v0[1]+u[1],v0[2]+u[2],v0[3]+u[3]
local az=m[3]*x+m[7]*y+m[11]*z+m[15]
if az>z_near then
local ay,w=m[2]*x+m[6]*y+m[10]*z+m[14],63.5/az
out[#out+1]={key=1/(ay*ay+az*az),a=actor,x=63.5+w*(m[1]*x+m[5]*y+m[9]*z+m[13]),y=63.5-w*ay,w=4*w,dist=dist}
end
end
end
local angles={}
for i=-16,16 do
add(angles,atan2(8,i))
end
local function visible_tiles(pos,angle)
local x,y=pos[1]/dx,pos[3]/dz
local x0,y0=flr(x),flr(y)
local tiles={[x0+y0*nx]=0}
for i,a in pairs(angles) do
local v,u=cos(a+angle),-sin(a+angle)
local mapx,mapy=x0,y0
local ddx,ddy,mapdx,distx,mapdy,disty=1/u,1/v
if u<0 then
mapdx,ddx=-1,-ddx
distx=(x-mapx)*ddx
else
mapdx,distx=1,(mapx+1-x)*ddx
end
if v<0 then
mapdy,ddy=-1,-ddy
disty=(y-mapy)*ddy
else
mapdy,disty=1,(mapy+1-y)*ddy
end
for dist=0,12 do
if distx<disty then
distx+=ddx
mapx+=mapdx
else
disty+=ddy
mapy+=mapdy
end
if(band(bor(mapx,mapy),0xffe0)!=0) break
tiles[mapx+mapy*nx]=dist
end
end
return tiles
end
local plyr_z_index,max_pz=nz/2-1,-32000
return {
plyr_pos={slices[plyr_z_index].x,0,plyr_z_index*dz},
to_tile_coords=function(self,v)
return flr(v[1]/dx),flr(v[3]/dz)
end,
collect_drawables=function(self,cam_pos,cam_angle,out)
local tiles=visible_tiles(cam_pos,cam_angle)
local v_cache={m=cam.m}
setmetatable(v_cache,v_ground_cache_cls)
for k,dist in pairs(tiles) do
local i,j=k%nx,flr(k/nx)
local s0=slices[j]
if s0 and s0.f then
local v0={i*dx,s0.h[i]+s0.y-dy,j*dz}
local f0,f1=s0.f[2*i],s0.f[2*i+1]
if f1 then
if(f0) collect_face(v0,f0,s0.actors[i],{k,k+1+nx,k+nx},v_cache,cam_pos,out,dist)
if(f1) collect_face(v0,f1,nil,{k,k+1,k+1+nx},v_cache,cam_pos,out,dist)
else
if(f0) collect_face(v0,f0,s0.actors[i],{k,k+1,k+1+nx,k+nx},v_cache,cam_pos,out,dist)
end
end
end
end,
update=function(self,p)
p[3]=max(p[3],8*dz)
local pz=p[3]/dz
if pz>plyr_z_index then
p[3]-=dz
max_pz-=dz
local old_y=slices[0].y
for i=1,nz-1 do
slices[i-1]=slices[i]
slices[i-1].y-=old_y
end
slices[nz-1]=make_slice(slices[nz-2].y-delta_slope*(rnd()+0.5))
mesh(nz-2)
end
if p[3]>max_pz then
dy,max_pz=lerp(slices[0].y,slices[1].y,pz%1),p[3]
end
end,
find_face=function(self,p)
local i,j=self:to_tile_coords(p)
local s0=slices[j]
local f0,f1=s0.f[2*i],s0.f[2*i+1]
local f=f0
if(f1 and (p[3]-dz*j<p[1]-dx*i)) f=f1
local t=-v_dot(make_v({i*dx,s0.h[i]+s0.y-dy,j*dz},p),f.n)/f.n[2]
p=v_clone(p)
p[2]+=t
return f,p,atan2(slices[j+2].x-p[1],2*dz)
end,
get_track=function(self,p)
local i,j=self:to_tile_coords(p)
local s0=slices[j]
return s0,{s0.xmin,s0.xmax,j*dz}
end,
collide=function(self,p,r)
local i0,j0=self:to_tile_coords(p)
if (i0<=0 or i0>=nx-2) return 2
r*=r
for j=j0-1,j0+1 do
local s0=slices[j]
if s0 then
for i=i0-1,i0+1 do
local actor=s0.actors[i]
if actor and actor.r then
local v0={i*dx,s0.h[i]+s0.y-dy,j*dz}
v_add(v0,actor.u)
local d=make_v(p,v0)
d[2]=0
if v_dot(d,d)<r+actor.r*actor.r then
if actor.score then
s0.actors[i]=nil
return 3,actor
end
return 1,actor
end
end
end
end
end
end
}
end
function make_rspr(sx,sy,n,tc)
assert(sx%16==0,"sprite x must be a multiple of 16:"..sx)
tc=tc or sget(sx,sy)
local angles={}
for i=0,n-1 do
local a=i/n-0.25
local ca,sa=cos(a),sin(a)
local dx0,dy0=(sa-ca)*7.5+8,-(ca+sa)*7.5+8
rectfill(0,0,15,15,tc)
local cache={}
local src,dst=0x6000,512*flr(sy/8)+flr(sx%128)/2
for iy=0,15 do
local srcx,srcy=dx0,dy0
for ix=0,15 do
if band(bor(srcx,srcy),0xfff0)==0 then
pset(ix,iy,sget(sx+srcx,sy+srcy))
end
srcx-=sa
srcy+=ca
end
dx0+=ca
dy0+=sa
cache[dst],cache[dst+4]=peek4(src),peek4(src+4)
src+=64
dst+=64
end
angles[i]=cache
end
return function(angle)
angle=(angle%1+1)%1
for k,v in pairs(angles[flr(n*angle)]) do
poke4(k,v)
end
end
end
function padding(n)
n=tostr(flr(min(n,99)))
return sub("00",1,2-#n)..n
end
function time_tostr(t)
local s=padding(flr(t/30)%60).."''"..padding(flr(10*t/3)%100)
if(t>1800) s=padding(flr(t/1800)).."'"..s
return s
end
function printb(s,x,y,cf,cs,cb)
x=x or 64-#s*2
if cb then
for i=-1,1 do
for j=-2,1 do
print(s,x+i,y+j,cb)
end
end
end
print(s,x,y,cs)
print(s,x,y-1,cf)
end
function p01_trapeze_h(l,r,lt,rt,y0,y1)
lt,rt=(lt-l)/(y1-y0),(rt-r)/(y1-y0)
if(y0<0)l,r,y0=l-y0*lt,r-y0*rt,0
for y0=y0,min(y1,128) do
rectfill(l,y0,r,y0)
l+=lt
r+=rt
end
end
function p01_trapeze_w(t,b,tt,bt,x0,x1)
tt,bt=(tt-t)/(x1-x0),(bt-b)/(x1-x0)
if(x0<0)t,b,x0=t-x0*tt,b-x0*bt,0
for x0=x0,min(x1,128) do
rectfill(x0,t,x0,b)
t+=tt
b+=bt
end
end
function trifill(x0,y0,x1,y1,x2,y2,col)
color(col)
if(y1<y0)x0,x1,y0,y1=x1,x0,y1,y0
if(y2<y0)x0,x2,y0,y2=x2,x0,y2,y0
if(y2<y1)x1,x2,y1,y2=x2,x1,y2,y1
if max(x2,max(x1,x0))-min(x2,min(x1,x0)) > y2-y0 then
col=x0+(x2-x0)/(y2-y0)*(y1-y0)
p01_trapeze_h(x0,x0,x1,col,y0,y1)
p01_trapeze_h(x1,col,x2,x2,y1,y2)
else
if(x1<x0)x0,x1,y0,y1=x1,x0,y1,y0
if(x2<x0)x0,x2,y0,y2=x2,x0,y2,y0
if(x2<x1)x1,x2,y1,y2=x2,x1,y2,y1
col=y0+(y2-y0)/(x2-x0)*(x1-x0)
p01_trapeze_w(y0,y0,y1,col,x0,x1)
p01_trapeze_w(y1,col,y2,y2,x1,x2)
end
end
function z_poly_clip(znear,v)
local res,v0={},v[#v]
local d0=v0[3]-znear
for i=1,#v do
local v1=v[i]
local d1=v1[3]-znear
if d1>0 then
if(d0<=0) res[#res+1]=v_lerp(v0,v1,d0/(d0-d1))
res[#res+1]=v1
elseif d0>0 then
res[#res+1]=v_lerp(v0,v1,d0/(d0-d1))
end
v0,d0=v1,d1
end
return res
end