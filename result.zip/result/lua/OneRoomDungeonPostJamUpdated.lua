-- one room dungeon by trasevol_dog 
-- #ld37 - theme was 'one room'

-- post-jam updated


objs={
 to_update={},
 to_draw={},
 
 enemies={},
 tiles={}
}

for i=0,4 do objs.to_draw[i]={} end

col_drk={[0]=0,0,1,1,2,1,5,6,2,4,9,3,1,1,8,9}


tileshin={}
for x=0,31 do
 tileshin[x]={}
 for y=0,31 do
  tileshin[x][y]=8
 end
end

roomw=7

firstinit=true
function _init()
 music(0,0,7)
 if firstinit then
  cls()
  init_anim_info()
  init_spawn_table()
  init_clear_colors()
  init_titlescreen()
 
  for i=1,50 do draw_title_clear() end
 
  --- titlescreen
  add_shake(8)
  sfx(13)
  while not btnp(5) do
   t+=0.01
   
   draw_titlescreen()
   flip()
  
   update_shake()
  end
  
  memcpy(0x1000,0x4300,0x1000)
 end
 firstinit=false
 
 music(-1)
 
 sfx(12)
 
 cls(6)
 flip()
 flip()
 cls(7)
 flip()
 flip()
 cls(6)
 flip()
 flip()
 cls(5)
 flip()
 flip()
 cls(1)
 flip()
 flip()
 cls(0)
 flip()
 
 music(8,0,4)
 
 objs.to_update={}
 for i=0,4 do objs.to_draw[i]={} end
 objs.enemies={}
 objs.tiles={}

 roomx=3.5*8
 roomy=3.5*8
 roomt=0
 
 camx=roomx-64
 camy=roomy-64
 
 for x=0,roomw do
 for y=0,roomw do
  mset(x,y,mget(x+32,y))
 end
 end
 
 player=create_player(roomx,roomy)
 loset=0.2
 
 tiletopress=3
 create_tiles(roomx,roomy)
 
 diff=0
 hppickup=0
 
 create_explosion(roomx,roomy,8,7)
end

t=0
function _update()
 t+=0.01
 roomt+=0.01
 
 update_objects()
 update_camera()
 
 for en in group("enemies") do
  local col=collide_objgroup(en,"enemies")
  if col then
   local a=atan2(col.x-en.x,col.y-en.y)
   en.vx-=0.5*cos(a)
   en.vy-=0.5*sin(a)
  end
  
  if player and collide_objobj(en,player) then
   local a=atan2(player.x-en.x,player.y-en.y)
   en.vx-=0.5*cos(a)
   en.vy-=0.5*sin(a)
  end
 end
 
 
 if not player then
  local ol=loset
  loset=max(loset-0.01,0)
  if loset==0 and ol>0 then
   add_shake(32)
   sfx(13)
   music(6,0,4)
  end
  
  if loset==0 and btnp(5) then _init() end
 end
end

function _draw()
 xmod=camx+shkx
 ymod=camy+shky
 
 camera(0,0)
 
 --rect(0,0,127,127,8)
 draw_clear()
 
 camera(xmod,ymod)
 --draw_room(64+16*cos(t),64+16*sin(t))
 draw_room(roomx,roomy)
 draw_objects()

 pal(14,0)
 spr(88,roomx-roomw*4-4,roomy-roomw*4,8,7) 
 pal(14,14)
 
 camera(0,0)
 draw_gui()
end



--- updates ---

function take_damage(d)
 if player and player.inv==0 then
  player.hp=max(player.hp-d,0)
  player.whiteframe=true
  player.inv=0.3
  add_shake(2)
  sfx(7)
 end
end

function update_player(p)
 p.animt+=0.01
 
 if p.state=="run" and p.animt%0.03<0.01 and animt_to_step(p.animt,"player","run")==2 then
  sfx(17)
 end
 
 p.inv=max(p.inv-0.01,0)
 p.rhppu=max(p.rhppu-0.01,0)
 
 col=collide_objgroup(p,"enemies")
 if col and col.attacking then
  take_damage(1)
 end
 
 if p.ded then
  create_explosion(p.x,p.y,16,7)
  add_shake(16)
  delete_registered(p)
  player=nil
  music(-1)
  sfx(16)
 end
 
 if p.hp<=0 then
  p.ded=true
 end
 
 p.vx*=p.dec
 p.vy*=p.dec
 
 if btn(0) then p.vx-=p.acc end
 if btn(1) then p.vx+=p.acc end
 if btn(2) then p.vy-=p.acc end
 if btn(3) then p.vy+=p.acc end
 
 p.vx=sgn(p.vx)*min(abs(p.vx),p.spdcap)
 p.vy=sgn(p.vy)*min(abs(p.vy),p.spdcap)
 
 p.x+=p.vx
 p.y+=p.vy
 
 stay_in_box(p,
  roomx-roomw*4,
  roomy-roomw*4-2,
  roomx+roomw*4-1,
  roomy+roomw*4-3)
 
 local newstate
 if abs(p.vx)>0.1 or abs(p.vy)>0.1 then
  newstate="run"
 else
  newstate="idle"
 end
 
 if newstate~=p.state then
  p.state=newstate
  p.animt=0
 end

 if abs(p.vx)>0 then
  p.faceleft=(p.vx<0)
 end
 
 if tiletopress<=0 and btnp(5) then
  if     btn(0) then move_room(0)
  elseif btn(1) then move_room(1)
  elseif btn(2) then move_room(2)
  elseif btn(3) then move_room(3)
  end
 end
end


function update_slime(s)

 s.vx*=s.dec
 s.vy*=s.dec

 if s.state=="idle" then
  s.animt+=0.01
  
  if s.animt>=0.2 then
   s.state="jump"
   s.animt=0
   if player then
    s.aimx=player.x
    s.aimy=player.y
   end
  end
 else
  if animt_to_step(s.animt,"slime","jump")<anim_get_steps("slime","jump")-1 then
   s.animt+=0.01
  elseif not s.attacking then
   s.vz=-s.jump
   s.attacking=true
   local a=atan2(s.aimx-s.x,s.aimy-s.y)
   s.vx=s.spdcap*cos(a)
   s.vy=s.spdcap*sin(a)
   s.faceleft=(s.vx<0)
  else
   s.z+=s.vz
   s.vz+=0.5
   
   if s.z>=0 then
    s.z=0
	s.vz=0
	s.animt=rnd(0.5)
	s.state="idle"
	s.attacking=false
   end
  
  end
 
 --- you stopped here
 end
 
 s.x+=s.vx
 s.y+=s.vy
 
 stay_in_box(s,
  roomx-roomw*4,
  roomy-roomw*4-2,
  roomx+roomw*4-1,
  roomy+roomw*4-3)

end


function update_chomp(s)
 s.animt+=0.01
 
 local a
 if player and s.animt%0.1<0.01 then
  s.aimx=player.x
  s.aimy=player.y
 end
 
 a=atan2(s.aimx-s.x,s.aimy-s.y)
 
 s.vx+=s.acc*cos(a)
 s.vy+=s.acc*sin(a)
 
 s.x+=s.vx
 s.y+=s.vy
 
 s.vx*=s.dec
 s.vy*=s.dec
 
 if sqr(s.x-s.rx)+sqr(s.y-s.ry)>sqr(s.reach) then
  a=atan2(s.rx-s.x,s.ry-s.y)
  s.vx+=1*cos(a)
  s.vy+=1*sin(a)
 end
 
 if player then
  s.faceleft=(player.x<s.x)
 end
 
 stay_in_box(s,
  roomx-roomw*4,
  roomy-roomw*4-2,
  roomx+roomw*4-1,
  roomy+roomw*4-3)
 
end


function update_skele(s)
 s.animt+=0.01
 
 local step=animt_to_step(s.animt,"skele")
 if (not s.attacking) and step==0 then
  s.attacking=true
  create_arrow(s.x,s.y,s.aimx,s.aimy)
  sfx(18)
 elseif step==anim_get_steps("skele")-4 and player then
  s.aimx=player.x
  s.aimy=player.y
 elseif step==1 then
  s.attacking=false
 end
 
 s.x+=s.vx
 s.y+=s.vy
 
 s.vx*=s.dec
 s.vy*=s.dec
 
 if player then
  s.faceleft=(player.x<s.x)
 end
 
 stay_in_box(s,
  roomx-roomw*4,
  roomy-roomw*4-2,
  roomx+roomw*4-1,
  roomy+roomw*4-3)
end

function update_arrow(ar)
 ar.x+=ar.vx
 ar.y+=ar.vy
 
 if stay_in_boxb(ar,
     roomx-roomw*4,
     roomy-roomw*4-2,
     roomx+roomw*4-1,
     roomy+roomw*4-3) then
  delete_registered(ar)
  sfx(19)
 end
end


function update_bat(s)
 s.animt+=0.01
 
 local a
 if player then
  a=atan2(player.x-s.x,player.y-s.y)
 else
  a=rnd(1)
 end
 
 s.vx+=s.acc*cos(a)
 s.vy+=s.acc*sin(a)
 
 s.vx=sgn(s.vx)*min(abs(s.vx),s.spdcap)
 s.vy=sgn(s.vy)*min(abs(s.vy),s.spdcap)
 
 s.x+=s.vx
 s.y+=s.vy
 
 s.vx*=s.dec
 s.vy*=s.dec
 
 if player then
  s.faceleft=(s.vx<0)
 end
 
 stay_in_box(s,
  roomx-roomw*4,
  roomy-roomw*4-2,
  roomx+roomw*4-1,
  roomy+roomw*4-3)
end


function update_thrower(s)
 s.animt+=0.01
 
 local step=animt_to_step(s.animt,"thrower")
 if (not s.attacking) and step==anim_get_steps("thrower")-1 then
  s.attacking=true
  local a=rnd(1)
  local spd=0.1+rnd(0.3)
  create_bomb(s.x,s.y,spd*cos(a),spd*sin(a))
  sfx(25)
 elseif step==0 then
  s.attacking=false
 end
 
 s.x+=s.vx
 s.y+=s.vy
 
 s.vx*=s.dec
 s.vy*=s.dec
 
 stay_in_box(s,
  roomx-roomw*4,
  roomy-roomw*4-2,
  roomx+roomw*4-1,
  roomy+roomw*4-3)
end

function update_bomb(s)
 s.animt+=0.01
 
 if s.animt>0.5 and s.animt%0.04<0.01 then sfx(15) end
 
 s.z+=s.vz
 s.vz+=0.5
 if s.z>=-1 then
  s.z=0
  if abs(s.vz)>1 then
   s.vz*=-0.5
  else
   s.vz=0
  end
  s.vx*=s.dec
  s.vy*=s.dec
 end
 
 local step=animt_to_step(s.animt,"bomb")
 if step==anim_get_steps("bomb")-1 then
  sfx(14)
  create_explosion(s.x,s.y,s.reach)
  if player then
   if sqr(player.x-s.x)+sqr(player.y-s.y)<sqr(s.reach+1) then
    take_damage(2)
   end
  end
  delete_registered(s)
 end
 
 s.x+=s.vx
 s.y+=s.vy
 
 stay_in_box(s,
  roomx-roomw*4,
  roomy-roomw*4-2,
  roomx+roomw*4-1,
  roomy+roomw*4-3)
end


function update_shapeshift(s)
 s.animt+=0.01
 s.kt-=0.01
 
 if s.name~="shapeshift" then
  s.shape_update(s)
  s.shape_update(s)
  
  if s.kt<0 then
   s.name="shapeshift"
   s.kt=0.1+rnd(0.08)
   s.state=nil
   s.acc=0
   s.dec=0
   s.spdcap=4
   s.z=0
   s.attacking=true
   s.draw=draw_self
  end
 elseif s.kt<0 then
  s.kt=0.20+rnd(0.10)
  local k=rnd(7)
  if k<1 then
   s.name="slime"
   s.state="idle"
   s.shape_update=update_slime
   s.draw=draw_self
   s.animt=0
   s.acc=0.2
   s.dec=0.8
  elseif k<2 then
   s.name="chomp"
   s.shape_update=update_chomp
   s.draw=draw_chomp
   s.animt=0
   s.rx=s.x
   s.ry=s.y
   s.acc=0.05
   s.dec=0.95
  elseif k<3 then
   s.name="skele"
   s.shape_update=update_skele
   s.draw=draw_self
   s.animt=0
   s.acc=0.1
   s.dec=0.8
  elseif k<4 then
   s.name="bat"
   s.shape_update=update_bat
   s.draw=draw_self
   s.animt=0
   s.acc=0.1
   s.dec=0.97
   s.spdcap=1.1
  elseif k<5 then
   s.name="zombie"
   s.shape_update=update_bat
   s.draw=draw_self
   s.animt=0
   s.acc=0.1
   s.dec=0.8
   s.spdcap=0.2
  elseif k<6 then
   s.name="ghost"
   s.shape_update=update_bat
   s.draw=draw_self
   s.animt=0
   s.acc=0.1
   s.dec=0.9
   s.spdcap=2
  elseif k<7 then
   s.name="thrower"
   s.shape_update=update_thrower
   s.draw=draw_self
   s.animt=0
   s.acc=0.1
   s.dec=0.8
   s.spdcap=3
  end
 else
  s.x+=s.vx
  s.y+=s.vy
  
  stay_in_box(s,
   roomx-roomw*4,
   roomy-roomw*4-2,
   roomx+roomw*4-1,
   roomy+roomw*4-3)
 end
end

function update_tile(ti)
 if ti.pressed then
  ti.animt=min(ti.animt+0.01,7*anim_info.tile.shine.dt)
  return
 end
 
 if player and collide_objobj(ti,player) then
  ti.pressed=true
  mset(flr(ti.x/8)%32,flr(ti.y/8)%32,25+flr(rnd(5)))
  tiletopress-=1
  if tiletopress<=0 then
   sfx(6)
  else
   sfx(5)
  end
 end
end

function update_hptile(ti)
 if player and collide_objobj(ti,player) then
  player.hp=min(player.hp+ti.hp,player.hpmax)
  player.rhppu=0.2
  if player.hp==player.hpmax then
   player.lhppu="hp max"
  else
   player.lhppu="+"..ti.hp.." hp"
  end
  player.whiteframe=true
  mset(flr(ti.x/8)%32,flr(ti.y/8)%32,41)
  delete_registered(ti)
  sfx(11)
 end
end

function update_spawntile(ti)
 if roomt>0.1 and ((not player) or (not collide_objobj(ti,player))) then
  -- spawn
  
  if diff%9>8.8 then
   create_shapeshift(ti.x,ti.y)
  else
   local lvl=min(flr(diff)+1,10)
   local pool=zone_spawns[lvl]
   local tospawn=pool[flr(rnd(#pool))+1]
   local foo=enemy_spawns[tospawn]
   foo(ti.x,ti.y)
  end
  
  mset(flr(ti.x/8)%32,flr(ti.y/8)%32,31)
  delete_registered(ti)
  sfx(10)
 end
end

function update_smoke(s)
 s.x+=s.vx
 s.y+=s.vy
 
 s.vx*=0.95
 s.vy=0.95*s.vy+0.05*(-1)
 
 s.r-=0.05
 if s.r<0 then
  delete_registered(s)
 end
end

function move_room(d)

 sfx(9)

 add_shake(8)
 
 diff+=0.25
 roomt=0

 local dx,dy=0,0
 
 if d==0 then
  dx=-1
 elseif d==1 then
  dx=1
 elseif d==2 then
  dy=-1
 else
  dy=1
 end
 
 for ti in group("tiles") do
  delete_registered(ti)
 end
 
 if diff%9==0 then
  local rmx=roomx+dx*roomw*8
  local rmy=roomy+dy*roomw*8
  local mx=flr(rmx/8-roomw*0.5)%32
  local my=flr(rmy/8-roomw*0.5)%32
  for x=0,roomw do
  for y=0,roomw do
   if diff>9 and mget(x+39,y)==40 then
    mset((mx+x)%32,(my+y)%32,42)
   else
    mset((mx+x)%32,(my+y)%32,mget(x+39,y))
   end
  end
  end
  
  music(16,500,4)

  create_tiles(rmx,rmy)
  
  diff=diff-0.01
 elseif diff%9>0.23 and diff%9<0.25 then
  local rmx=roomx+dx*roomw*8
  local rmy=roomy+dy*roomw*8
  local mx=flr(rmx/8-roomw*0.5)%32
  local my=flr(rmy/8-roomw*0.5)%32
  for x=0,roomw do
  for y=0,roomw do
   mset((mx+x)%32,(my+y)%32,mget(x+46,y))
  end
  end

  create_tiles(rmx,rmy)
  
  player.hpmax+=1
  music(8,500,4)
  
  diff=flr(diff)
 else
  gen_room(roomx+dx*roomw*8,roomy+dy*roomw*8,diff)
  if diff%9==0.25 then
   music(24,500,4)
  elseif diff%9==3 then
   music(32,500,4)
  elseif diff%9==6 then
   music(48,500,4)
  end
 end
 
 player.state="againstwall"
 if abs(dx)==1 then
  player.x=roomx+dx*(roomw*4-5)
  player.animt=0
 else
  player.y=roomy+dy*(roomw*4+1)-3
  player.animt=1
 end
 
 _draw()
 for i=0,4 do
  flip()
 end
 
 local orx,ory,nrx,nry
 orx=roomx
 ory=roomy
 nrx=roomx+dx*roomw*8
 nry=roomy+dy*roomw*8
 
 local i=0
 while roomx~=nrx or roomy~=nry do
  i+=1
  
  roomx+=dx
  roomy+=dy
  player.x+=dx
  player.y+=dy
  
  camx+=0.5*dx
  camy+=0.5*dy
  
  enm=false
  for en in group("enemies") do
   if en.ded then
    if en.update==update_shapeshift then
	 create_explosion(en.x,en.y,20,en.c)
	 flip()
	else
     create_explosion(en.x,en.y,10,en.c)
	end
	
	delete_registered(en)
	sfx(8)
   else
    local burn=stay_in_boxb(en,
     roomx-roomw*4,
     roomy-roomw*4-2,
     roomx+roomw*4-1,
     roomy+roomw*4-3)
    
    if burn then
     en.whiteframe=true
	 en.ded=true
    end
	 
    enm=enm or burn
   end
  end
  
  if diff%9==0.25 then
   --_draw()
  end
  
  if enm or i%16==0 then
   update_shake()
   camera(camx+shkx,camy+shky)
   local ax,ay=orx-roomw*4,ory-roomw*4
   rectfill(ax,ay,ax+roomw*8-1,ay+roomw*8-1,0)
   _draw()
   flip()
  end
 end
 
 add_shake(8)
 
 camx-=8*dx
 camy-=8*dy
end

function gen_room(rmx,rmy,dif)
 local mx=flr(rmx/8-roomw*0.5)%32
 local my=flr(rmy/8-roomw*0.5)%32

 zone=flr(diff/3)
 
 local loopin=false
 if zone>=3 then
  zone=zone%3
  loopin=true
 end
 
 local tileanc=zone*8
 
 for x=0,roomw-1 do
 for y=0,roomw-1 do
  local c=0
  if rnd(10)<1 then c=4+flr(rnd(4))
  else c=flr(rnd(4))
  end
  
  if loopin and rnd(15)<2 then
   c+=flr(rnd(3))*8
  else
   c+=tileanc
  end
  
  mset((mx+x)%32,(my+y)%32,c)
 end
 end
 
 -- hp tile
 if rnd(1)<1 then
  local x=(mx+flr(rnd(7)))%32
  local y=(my+flr(rnd(7)))%32
  
  if mget(x,y)<24 then
   if diff<9 then
    mset(x,y,40)
   elseif diff<18 then
    if rnd(4)<1 then
	 mset(x,y,40)
	else
	 mset(x,y,42)
	end
   else
    hppickup+=1
	if hppickup%2<1 then
     if rnd(4)<1 then
	  mset(x,y,40)
	 else
	  mset(x,y,42)
	 end
	else
     mset(x,y,41)
	end
   end
  end
 end
 
 -- spawn tiles
 local enems=flr(min(2+diff*0.5,min(5+flr(diff/9),9)))
 
 while enems>0 do
  local x=(mx+flr(rnd(7)))%32
  local y=(my+flr(rnd(7)))%32
  
  if mget(x,y)<24 then
   mset(x,y,30)
   enems-=1
  end
 end
 
 -- unlock tiles
 local topress=flr(min(3+diff*1.5,7*7-10))
 while topress>0 do
  local x=(mx+flr(rnd(7)))%32
  local y=(my+flr(rnd(7)))%32
  
  if mget(x,y)<24 then
   mset(x,y,24)
   topress-=1
  end
 end
 
 create_tiles(rmx,rmy)
end

camx=0 camy=0
shkx=0 shky=0
camrx=0 camry=0
function update_camera()
 local ocamx,ocamy=camx,camy
 
 camx=lerp(roomx-64,camx,0.1)
 camy=lerp(roomy-64-4,camy,0.1)
 
 camrx=camx-ocamx
 camry=camy-ocamy

 update_shake()
end


function add_shake(p)
 local a=rnd(1)
 shkx+=p*cos(a)
 shky+=p*sin(a)
end

function update_shake()
 if abs(shkx)<0.5 and abs(shky)<0.5 then
  shkx=0
  shky=0
 else
  shkx*=-0.6-rnd(0.2)
  shky*=-0.6-rnd(0.2)
 end
end



--- draws ---

function draw_player(p)
 if p.inv%0.04>0.02 then
  return
 end

 local foo=function(p)
            draw_anim(p.x,p.y-1,p.name,p.state,p.animt,p.faceleft)
           end
 
 draw_outline(foo,0,p)
 foo(p)
end

function draw_chomp(s)
 pal(1,0)
 for i=0,4 do
  local x,y
  x=lerp(s.x,s.rx,i/5)
  y=lerp(s.y,s.ry,i/5)
  spr(160,x-4,y-4)
 end
 pal(1,1)
 draw_self(s)
end

-- this func works only if there's a name field
function draw_self(s)
 local foo=function(s)
            local state=s.state or "only"
			local z=s.z or 0
            draw_anim(s.x,s.y-1+z,s.name,state,s.animt,s.faceleft)
           end
 local c=0
 if s.whiteframe then c=7 end
 draw_outline(foo,c,s)
 if s.whiteframe then all_colors_to(7) end
 foo(s)
 if s.whiteframe then all_colors_to() s.whiteframe=false end
end

function draw_arrow(ar)
 local foo=function(ar)
  line(ar.x,ar.y,ar.x-ar.vx,ar.y-ar.vy,4)
  pset(ar.x,ar.y,6)  
 end
 
 draw_outline(foo,0,ar)
 foo(ar)
end

function draw_bomb(b)
 if b.animt>0.5 then
  circ(b.x,b.y,b.reach,8+(b.animt*100)%2)
 end
 draw_self(b)
end

function draw_tileshine(ti)
 if not ti.pressed then return end
 
 draw_anim(ti.x,ti.y,"tile","shine",ti.animt)
end

function draw_room(x,y)

 local ax=x-roomw*4
 local ay=y-roomw*4
 
 rectfill(ax-7,ay-11,ax+roomw*8-1+7,ay+roomw*8-1+4,0)
 
 
 local mx=flr(ax/8)
 local my=flr(ay/8)
 local rx=mx*8-ax
 local ry=my*8-ay
 
 if rx==33 and ry==0 then
 
  for x=0,roomw-1 do
  for y=0,roomw-1 do
   spr(mget((mx+x)%32,(my+y)%32),ax+x*8+rx,ay+y*8+ry)
  end
  end
 
 else
 
  for x=0,roomw do
  for y=0,roomw do
   local s=mget((mx+x)%32,(my+y)%32)
   local sx=s%16*8
   local sy=flr(s/16)*8
   
   local xx=ax+x*8+rx
   local yy=ay+y*8+ry
   local xw,yh=8,8
   
   if x==0 then
    local oxx=xx
    xx=max(xx,ax)
    xw-=xx-oxx
    sx+=xx-oxx
   end
   if y==0 then
    local oyy=yy
    yy=max(yy,ay)
    yh-=yy-oyy
    sy+=yy-oyy
   end
   if x==roomw then
    local xx2=min(xx+8,ax+roomw*8)
    xw=xx2-xx
   end
   if y==roomw or y==roomw-1 then
    local yy2=min(yy+8,ay+roomw*8-2)
    yh=yy2-yy
   end
   
   sspr(sx,sy,xw,yh,xx,yy)
  end
  end
 
 end
 
 spr(72,roomx-roomw*4-4,roomy-roomw*4-8,8,8)
end

function draw_smoke(s)
 circfill(s.x,s.y,s.r,s.c)
end

function draw_explosion(e)
 if e.p<1 then
  circfill(e.x,e.y,e.r,0)
 elseif e.p<2 then
  circfill(e.x,e.y,e.r,7)
  if e.r>4 then
   for i=0,2 do
    local x=e.x+rnd(2.2*e.r)-1.1*e.r
    local y=e.y+rnd(2.2*e.r)-1.1*e.r
    local r=0.25*e.r+rnd(0.5*e.r)
    create_explosion(x,y,r,e.c)
   end
   
   for i=0,2 do
    create_smoke(e.x,e.y,1,e.c)
   end
  end
 elseif e.p<3 then
  circ(e.x,e.y,e.r,7)
 
  delete_registered(e)
 end
 
 e.p+=1
end

function init_clear_colors()
clrcols={
[0]={0,1,2,4,9,8},
{0,1,2,4,9},
{0,1,12,13,7},
--{0,1,2,8,9,10},
{0,2,8,9,10},
{0,2,8,14,7}
}
for j=0,#clrcols do
 local plt=clrcols[j]
 local nplt={}
 for i=1,#plt do
  nplt[plt[i]]=plt[i%#plt+1]
 end
 clrcols[j]=nplt
end
end

function draw_clear(k)
 for i=0,999 do
  local x,y=rnd(128),rnd(128)
  local c=pget(x+camrx,y+camry)
  
  
  zone=flr(diff/3)
  plt=clrcols[min(zone,3)+1]
  if plt[c] then
   if rnd(1.1)>=1 then
    c=plt[c]
   end
  else
   c=0
  end
  
  local a=atan2(x-64,y-64)

  circ(x+2*cos(a),y+2*sin(a),1,c)
 end
end

function draw_title_clear()
 for i=0,799 do
  local x,y=rnd(128),rnd(128)
  local c=pget(x+camrx,y+camry)
  
  plt=clrcols[0]
  if plt[c] then
   if rnd(1.2)>=1 then
    c=plt[c]
   end
  else
   c=0
  end
  
  local a=atan2(x-64,y-64)+0.15

  circ(x+2*cos(a),y+2*sin(a),1,c)
 end
end

function draw_gui()

 if player then
  if tiletopress<=0 then
   camera(xmod,ymod)
   local x1,y1,x2,y2
   x1=roomx-roomw*4-8
   x2=roomx+roomw*4+7
   y1=roomy-roomw*4-8-4
   y2=roomy+roomw*4+7-4  
   rect(x1-2,y1-2,x2+2,y2+2,0)
   local k=flr(2*cos(t*4))
   rect(x1+k,y1+k,x2+0.9999-k,y2+0.9999-k,6)
   camera(0,0)
   
   if diff==0 then
    draw_text("hold ⬅️ / ➡️ / ⬆️ / ⬇️    ",64,112+flr(4*cos(t*2)+0.5))
    draw_text("and press ❎ ",64,112+8+4*cos(t*2))
   end
  end
  
  draw_healthbar(3,3,0)
  draw_progression(124,3,2)
  
  if diff==9 then
   local y=112+flr(4*cos(t*2)+0.5)
   if tiletopress>5 then
    draw_text("!! well done !!",64,y,1,true)
   elseif tiletopress>4 then
    draw_text("!!! you beat the game !!!",64,y,1,true)
   elseif tiletopress>3 then
    draw_text("but more adventures await...",64,y,1,true)
   elseif tiletopress>2 then
    draw_text("in the...",64,y,1,true)
	add_shake(1)
   elseif tiletopress>1 then
    draw_text("!!! one room !!!",64,y,1,true)
	add_shake(2)
   elseif tiletopress>0 then
    draw_text("!!!! dungeon !!!!",64,y,1,true)
	add_shake(4)
   end
  end
  
  if player.rhppu>0 then
   draw_text(player.lhppu,4,20,0,true)
  end
  
 elseif loset==0 then
  --draw_healthbar(64,16,1)
  draw_text("g a m e   o v e r",64,38,1,true)
  draw_text("score: "..(flr(diff*4)),64,50,1,true)
  draw_progression(65+flr(2*cos(t*4)),60,1)
  if t%0.2<0.15 then
   draw_text("press ❎ to try again ",64,64+24,1,true)
  end
 end
end

function draw_healthbar(x,y,al)
 local w=48
 if al==1 then x-=w/2
 elseif al==2 then x-=w end
 
 rectfill(x-1,y-1,x+w+1,y+10+2,0)
 rect(x,y,x+w,y+10,7)
 line(x,y+11,x+w,y+11,13)
 
 if player then
  local x2=x+1+(w-2)*player.hp/player.hpmax
  rectfill(x+1,y+1,x2,y+9,2)
  line(x+2,y+2,x2-1,y+2,8)
 end
 
 local txt
 if player then
  txt=player.hp.."/"..player.hpmax
 else
  txt="0/4"
 end
 draw_text(txt,x+24,y+6)
end

function draw_progression(x,y,al)
 local w=58
 if al==1 then x-=w/2
 elseif al==2 then x-=w end
 
 --[[
 local foo=function(ox,oy)
   for i=0,diff/9 do
    spr(200,66+ox,3+oy,8,1)
	oy+=5
   end
   
   if player then
    spr(216,66+ox+ceil((diff/9)%1*57)-3,-1+oy)
   else
    spr(217,66+ox+ceil((diff/9)%1*57)-3,1+oy)
   end
  end
 
 pal(7,0)
 for x=-1,1 do
 for y=-1,2 do
  foo(x,y)
 end end
 pal(7,13)
 foo(0,1)
 pal(7,7)
 foo(0,0)
 --]]
 
 local s
 if player then s=216 else s=217 end
 
 local foo=function(ox,oy)
  for i=0,diff/9 do
   spr(200,x+ox,y+oy,8,1)
   oy+=5
  end
  spr(s,x+ox+ceil((diff/9)%1*57)-3,y-2+oy)
 end
 
 pal(7,0)
 for xx=-1,1 do
 for yy=-1,2 do
  foo(xx,yy)
 end end
 pal(7,13)
 foo(0,1)
 pal(7,7)
 foo(0,0)
end

function draw_text(str,x,y,al,extra)
 local al=al or 1

 if al==1 then x-=#str*2-1
 elseif al==2 then x-=#str*4 end
 
 y-=3
 
 if extra then
  print(str,x,y+3,0)
  print(str,x-1,y+2,0)
  print(str,x+1,y+2,0)
  print(str,x-2,y+1,0)
  print(str,x+2,y+1,0)
  print(str,x-2,y,0)
  print(str,x+2,y,0)
  print(str,x-1,y-1,0)
  print(str,x+1,y-1,0)
  print(str,x,y-2,0)
 end
 
 print(str,x+1,y+1,13)
 print(str,x-1,y+1,13)
 print(str,x,y+2,13)
 print(str,x+1,y,7)
 print(str,x-1,y,7)
 print(str,x,y+1,7)
 print(str,x,y-1,7)
 print(str,x,y,0)

end

function draw_outline(draw,c,arg)
 all_colors_to(c)
 
 camera(xmod-1,ymod)
 draw(arg)
 camera(xmod+1,ymod)
 draw(arg)
 camera(xmod,ymod-1)
 draw(arg)
 camera(xmod,ymod+1)
 draw(arg)
 
 camera(xmod,ymod)
 all_colors_to()
end

function init_titlescreen()
 local yy=1
 pal(7,13)
 sspr(0,96,63,26,0,yy+1,126,52)
 sspr(0,96,63,26,1,yy+2,126,52)
 sspr(0,96,63,26,2,yy+1,126,52)
 
 pal(7,7)
 sspr(0,96,63,26,0,yy,126,52)
 sspr(0,96,63,26,2,yy,126,52)
 sspr(0,96,63,26,1,yy-1,126,52)
 sspr(0,96,63,26,1,yy+1,126,52)
 
 pal(7,1)
 sspr(0,96,63,26,1,yy,126,52)
 pal(7,7)
 
 memcpy(0x4300,0x1000,0x1000)
 memcpy(0x1000,0x6000,0x1000)
 
 cls()
end

function draw_titlescreen()
  draw_title_clear()
  
  xmod=shkx
  ymod=shky
  camera(shkx,shky)
  
  local yy=64-32
  
  --[[
  pal(7,13)
  sspr(0,96,63,26,0,yy+1,126,52)
  sspr(0,96,63,26,1,yy+2,126,52)
  sspr(0,96,63,26,2,yy+1,126,52)
  
  pal(7,7)
  sspr(0,96,63,26,0,yy,126,52)
  sspr(0,96,63,26,2,yy,126,52)
  sspr(0,96,63,26,1,yy-1,126,52)
  sspr(0,96,63,26,1,yy+1,126,52)
  
  pal(7,0)
  sspr(0,96,63,26,1,yy,126,52)
  pal(7,7)
  --]]
  
  local foo=function()
    spr(128,0,yy-1,16,8)
   end
   
  draw_outline(foo,0)
  pal(1,0)
  foo()
  pal(1,1)
  
  draw_text("by trasevol_dog",1,yy+59,0,true)
  draw_text("#ld37",128,yy+59,2,true)
  
  foo=function() draw_anim(70,yy-6,"player","idle",t) end
  draw_outline(foo,0)
  foo()
  
  foo=function(x,y) draw_anim(x,yy,"player","run",t,(yy>64)) end
  for i=-4,4 do
   local xx
   xx=64+i*16+(t*40)%16
   yy=4
   draw_outline(foo,0,xx)
   foo(xx)
   xx=64+i*16-(t*40)%16
   yy=123
   draw_outline(foo,0,xx)
   foo(xx)
  end
  
  if t%0.25<0.15 then
   draw_text("press ❎ to start",64,108,1,true)
  end
  
end


--- creates ---

function create_player(x,y)
 local p={
  inv=0,
  hp=3,
  hpmax=4,
  rhppu=0,
  lhppu="",
  x=x or 64,
  y=y or 64,
  vx=0,
  vy=0,
  acc=0.5,
  spdcap=1,
  dec=0.8,
  w=4,
  h=4,
  name="player",
  state="idle",
  faceleft=true,
  animt=0,
  draw=draw_player,
  update=update_player,
  regs={objs.to_update,objs.to_draw[2]}
 }
 
 register_to_regs(p)
 
 return p
end

function init_spawn_table()

 zone_spawns={
  [1]={"zombie","zombie","slime","slime","skele"},
  [2]={"zombie","bat","skele","slime"},
  [3]={"bat","bat","skele","skele","slime","zombie"},
  [4]={"skele","ghost","ghost","bat"},
  [5]={"skele","ghost","chomp","chomp","bat"},
  [6]={"bomb","chomp","ghost","skele"},
  [7]={"bomb","bat","bat","skele","chomp"},
  [8]={"thrower","bat","skele","chomp"},
  [9]={"thrower","thrower","bat","bat","bat","chomp"},
  [10]={"zombie","bat","bomb","skele","ghost","chomp","slime","thrower"}
 }

 enemy_spawns={
  slime=create_slime,
  chomp=create_chomp,
  skele=create_skele,
  bat=create_bat,
  zombie=create_zombie,
  ghost=create_ghost,
  bomb=create_bomb,
  thrower=create_thrower
 }
end

function create_slime(x,y)
 local en={
  c=11,
  x=x,
  y=y,
  vx=0,
  vy=0,
  z=0,
  vz=0,
  acc=0.2,
  spdcap=4,
  dec=0.8,
  jump=2,
  w=4,
  h=3,
  attacking=false,
  aimx=0,
  aimy=0,
  name="slime",
  state="idle",
  faceleft=false,
  animt=rnd(0.05),
  draw=draw_self,
  update=update_slime,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }
 
 register_to_regs(en)
end

function create_chomp(x,y)
 local en={
  c=6,
  x=x,
  y=y,
  rx=x,
  ry=y,
  vx=0,
  vy=0,
  acc=0.05,
  spdcap=3,
  dec=0.95,
  reach=16,
  w=4,
  h=4,
  aimx=0,
  aimy=0,
  attacking=true,
  name="chomp",
  faceleft=false,
  animt=rnd(1),
  draw=draw_chomp,
  update=update_chomp,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }
 
 register_to_regs(en)
end

function create_skele(x,y)
 local en={
  c=6,
  x=x,
  y=y,
  vx=0,
  vy=0,
  acc=0.1,
  spdcap=3,
  dec=0.8,
  w=4,
  h=4,
  aimx=0,
  aimy=0,
  attacking=false,
  name="skele",
  faceleft=false,
  animt=0.04+rnd(0.12),
  draw=draw_self,
  update=update_skele,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }
 
 register_to_regs(en)
end

function create_arrow(x,y,aimx,aimy)
 local aim=atan2(aimx-x,aimy-y)
 
 local ar={
  c=4,
  x=x,
  y=y,
  vx=6*cos(aim),
  vy=6*sin(aim),
  w=2,
  h=2,
  attacking=true,
  draw=draw_arrow,
  update=update_arrow,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }

 register_to_regs(ar)
end

function create_bat(x,y)
 local en={
  c=13,
  x=x,
  y=y,
  vx=0,
  vy=0,
  acc=0.1,
  spdcap=1.1,
  dec=0.97,
  w=2,
  h=2,
  attacking=true,
  name="bat",
  faceleft=false,
  animt=rnd(1),
  draw=draw_self,
  update=update_bat,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }
 
 register_to_regs(en)
end

function create_zombie(x,y)
 local en={
  c=3,
  x=x,
  y=y,
  vx=0,
  vy=0,
  acc=0.1,
  spdcap=0.2,
  dec=0.8,
  w=4,
  h=4,
  attacking=true,
  name="zombie",
  faceleft=false,
  animt=rnd(1),
  draw=draw_self,
  update=update_bat,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }
 
 register_to_regs(en)
end

function create_ghost(x,y)
 local en={
  c=6,
  x=x,
  y=y,
  vx=0,
  vy=0,
  acc=0.1,
  spdcap=2,
  dec=0.9,
  w=2,
  h=2,
  attacking=true,
  name="ghost",
  faceleft=false,
  animt=rnd(1),
  draw=draw_self,
  update=update_bat,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }
 
 register_to_regs(en)
end

function create_bomb(x,y,vx,vy)
 local en={
  c=6,
  x=x,
  y=y,
  vx=vx or 0,
  vy=vy or 0,
  z=0,
  vz=-3-rnd(0.5),
  dec=0.8,
  w=2,
  h=2,
  reach=12,
  attacking=false,
  name="bomb",
  faceleft=(rnd(2)<1),
  animt=rnd(0.12),
  draw=draw_bomb,
  update=update_bomb,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }
 
 register_to_regs(en)
end

function create_thrower(x,y)
 local en={
  c=8,
  x=x,
  y=y,
  vx=0,
  vy=0,
  acc=0.1,
  spdcap=3,
  dec=0.8,
  w=4,
  h=4,
  attacking=false,
  name="thrower",
  faceleft=(rnd(2)<1),
  animt=rnd(0.16),
  draw=draw_self,
  update=update_thrower,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }
 
 register_to_regs(en)
end

function create_shapeshift(x,y)
 local en={
  c=8,
  x=x,
  y=y,
  vx=0,
  vy=0,
  acc=0,
  spdcap=4,
  dec=0,
  w=4,
  h=4,
  z=0,
  vz=0,
  jump=2,
  reach=16,
  aimx=0,
  aimy=0,
  attacking=true,
  name="shapeshift",
  faceleft=(rnd(2)<1),
  animt=0,
  kt=0.10+rnd(0.08),
  draw=draw_self,
  update=update_shapeshift,
  regs={objs.to_update,objs.to_draw[2],objs.enemies}
 }
 
 register_to_regs(en)
end

function create_tile(x,y)
 local ti={
  x=x,
  y=y,
  w=8,
  h=8,
  pressed=false,
  animt=0,
  draw=draw_tileshine,
  update=update_tile,
  regs={objs.to_update,objs.to_draw[1],objs.tiles}
 }
 
 register_to_regs(ti)
 
 return ti
end

function create_spawntile(x,y)
 local ti={
  x=x,
  y=y,
  w=24,
  h=24,
  update=update_spawntile,
  regs={objs.to_update,objs.tiles}
 }
 
 register_to_regs(ti)
 
 return ti
end

function create_hptile(x,y,hp)
 local ti={
  x=x,
  y=y,
  w=8,
  h=8,
  hp=hp,
  update=update_hptile,
  regs={objs.to_update,objs.tiles}
 }
 
 register_to_regs(ti)
 
 return ti
end

function create_tiles(rmx,rmy)
 local mx=flr(rmx/8-roomw*0.5)%32
 local my=flr(rmy/8-roomw*0.5)%32
 
 tiletopress=0
 for x=0,6 do
 for y=0,6 do
  local c=mget((mx+x)%32,(my+y)%32)
  if c==24 then
   tiletopress+=1
   create_tile(rmx-roomw*4+x*8+4,rmy-roomw*4+y*8+4)
  elseif c==30 then
   create_spawntile(rmx-roomw*4+x*8+4,rmy-roomw*4+y*8+4)
  elseif c==40 then
   create_hptile(rmx-roomw*4+x*8+4,rmy-roomw*4+y*8+4,2)
  elseif c==42 then
   create_hptile(rmx-roomw*4+x*8+4,rmy-roomw*4+y*8+4,1)
  end
 end
 end
end


function create_explosion(x,y,r,c)
 local e={
  x=x,
  y=y,
  r=r,
  p=0,
  c=c or 6,
  draw=draw_explosion,
  regs={objs.to_draw[4]}
 }
 
 register_to_regs(e)
end

function create_smoke(x,y,spd,c)
 local a=rnd(1)
 local spd=0.75*spd+rnd(0.5*spd)
 
 if rnd(2)<1 then c=col_drk[c] end
 
 local s={
  x=x,
  y=y,
  vx=spd*cos(a),
  vy=spd*sin(a),
  c=c,
  r=1+flr(rnd(3)),
  update=update_smoke,
  draw=draw_smoke,
  regs={objs.to_update,objs.to_draw[3]}
 }
 
 register_to_regs(s)
end


--- anim ---

function init_anim_info()
 anim_info={
  player={
   idle={
    sprites={32,32,33,33,32,32,33,33,32,32,33,32,33,34,35,36,37,38,39},
    dt=0.04
   },
   run={
    sprites={48,49,50,51},
    dt=0.03
   },
   againstwall={
    sprites={52,53},
	dt=1
   }
  },
  tile={
   shine={
    sprites={56,57,58,59,60,61,62,63},
	dt=0.03
   }
  },
  slime={
   idle={
    sprites={64,65,66,64},
	dt=0.04
   },
   jump={
    sprites={67,68,69},
	dt=0.04
   }
  },
  chomp={
   only={
    sprites={70,71},
	dt=0.04
   }
  },
  skele={
   only={
    sprites={96,97,96,97,98,99,100,101,101,102,102,102,103},
	dt=0.04
   }
  },
  bat={
   only={
    sprites={112,113,114,115},
	dt=0.03
   }
  },
  zombie={
   only={
    sprites={116,117,118,119},
	dt=0.04
   }
  },
  thrower={
   only={
    sprites={128,129,130,129,130,131,132,131,132,133,133,133,134,135},
	dt=0.04
   }
  },
  ghost={
   only={
    sprites={144,145,146,147,148,149,150,151},
	dt=0.04
   }
  },
  bomb={
   only={
    sprites={80,81,80,81,80,81,82,83,84,83,84,83,84,85,87,86,86,86,87,86,86,87,86,86},
	dt=0.03
   }
  },
  shapeshift={
   only={
    sprites={161,162,163,164,165,166,167},
	dt=0.03
   }
  }
 }
end

function draw_anim(x,y,char,state,t,xflip)
 local sinfo=anim_info[char][state]
 local spri=sinfo.sprites[flr(t/sinfo.dt)%#sinfo.sprites+1]

 local wid=sinfo.width or 1
 local hei=sinfo.height or 1

 local xflip=xflip or false

 spr(spri,x-wid*4,y-hei*4,wid,hei,xflip)

end

function animt_to_step(animt,char,state)
 local state=state or "only"
 return flr(animt/anim_info[char][state].dt)%#anim_info[char][state].sprites
end

function anim_get_steps(char,state)
 local state=state or "only"
 return #anim_info[char][state].sprites
end



--- collisions ---

function collide_objgroup(obj,group)
 for obj2 in all(objs[group]) do
  if obj2~=obj then
   local bl=collide_objobj(obj,obj2)
   if bl then
    return obj2
   end
  end
 end

 return false
end

function collide_objobj(obj1,obj2)
 return (abs(obj1.x-obj2.x)<(obj1.w+obj2.w)/2
     and abs(obj1.y-obj2.y)<(obj1.h+obj2.h)/2)
end

function stay_in_box(obj,x1,y1,x2,y2)
 obj.x=clamp(obj.x,x1+obj.w/2,x2-obj.w/2)
 obj.y=clamp(obj.y,y1+obj.w/2,y2-obj.h/2)
end

function stay_in_boxb(obj,x1,y1,x2,y2)
 local orx,ory=obj.x,obj.y
 obj.x=clamp(obj.x,x1+obj.w/2,x2-obj.w/2)
 obj.y=clamp(obj.y,y1+obj.w/2,y2-obj.h/2)
 return (obj.x~=orx or obj.y~=ory)
end


--- objects handling ---

function update_objects()
 local uobjs=objs.to_update
 
 for obj in all(uobjs) do
  obj.update(obj)
 end
end

function draw_objects()
 for i=0,4 do
  local dobjs=objs.to_draw[i]
 
  --sorting objects by depth
  for i=2,#dobjs do
   if dobjs[i-1].y>dobjs[i].y then
    local k=i
    while(k>1 and dobjs[k-1].y>dobjs[k].y) do
     local s=dobjs[k]
     dobjs[k]=dobjs[k-1]
     dobjs[k-1]=s
     k-=1
    end
   end
  end
 
  --actually drawing
  for obj in all(dobjs) do
   obj.draw(obj)
  end
 end
end

function register_to_regs(o)
 for reg in all(o.regs) do
  add(reg,o)
 end
end

function delete_registered(o)
 for reg in all(o.regs) do
  del(reg,o)
 end
end

function group(name) return all(objs[name]) end



--- utilities ---

function all_colors_to(c)
 if c then
  for i=0,15 do
   pal(i,c)
  end
 else
  for i=0,15 do
   pal(i,i)
  end
 end
end

function ceil(a) return flr(a+0x.ffff) end
function lerp(a,b,i) return i*a+(1-i)*b end
function clamp(a,mi,ma) return min(max(a,mi),ma) end
function sqr(a) return a*a end
