--a dream's command
--an rpg by jusiv

--all assets and code by
--henry stadolnik
--find me on twitter: @jusiv_

function init_ability()
 attack,spell,action = {"poke"},{"glimmer"},{"flee"}
end

function setup()
n1,title,title_menu,intro,intro_text,i_progress,battle = -1,true,{"new game"},false,{"every night","i have the same dream","","i'm adrift","in an empty void","","below me, an island","rises from the darkness","","it's the island","my village calls home","","","as it drifts closer,","i can hear a voice","","","","it comes from","everywhere","and nowhere","all at once","","","it speaks in a tongue","that nothing in this","world can utter","yet i can understand","it perfectly","","the voice calls my name","it beckons me","","","","it commands me to seek","the island's heart","","","","","no one in our village","has dared venture out","deeper than the forest","","the island remains a","wild, dangerous place","","besides, what the sea","does not provide, we","get from the mainland","","but i must go","","i cannot resist it","any longer","","the voice is calling me","i have to know why","","i have to journey","to the heart","of this island",""},0,0
zone,wait,b_wait,notice,mcguff,complete,rel_wait = n1,0,40,0,0,false,0
doors = {2,12.5,8.75,0, 3,4.5,12.75,0, 4,3.5,29.75,n1, 9,13.5,39.75,n1, 11,14.5,15.75,0, 12,2.5,39.75,n1, 13,9.5,16.75,0, 14,11.5,29.75,n1, 28,113.5,35.75,6, 44,68.5,4.75,1, 51,60.5,33.75,4, 60,51.5,14.75,3, 68,44.5,33.75,7, 74,86.5,6.75,5, 86,74.5,36.75,4, 100,120.5,25.75,6, 113,28.5,33.5,7, 120,100.5,8.75,5}
interact,talk,text = 0,{"game saved and health restored!","what!? you're venturing out?","these old legs would never dare","wander into that forest!","i've always thought of dreams","as ominous things. are you sure","you want to head out?","...zzzzzzzz...   ...no fish...","  ...been waiting all day...","        ...zzzzzzzzz...","oh no oh no what am i gonna do?","my boat drifted out of reach","and i don't wanna get wet...","enshrined here lies the","sealing stone, our world's","last hope in dire times.","if the evil imprisoned on","this isle breaks free, use","the stone to put it to rest.","you obtained:","the sealing stone","","[it's an eerie golden idol.","as you examine it, a booming,","familiar voice startles you.]","at long last, you have arrived!","i am known as mol'ojar, and i","was the voice in your dreams.","this place is the island's","heart which i commanded you","to seek.","now you, my puppet, shall earn","the honor of being the one to","free me of this prison!","[you feel unseen tendrils of","something enter your mind...]","","[against your will, you reach","out and touch the idol.","it crumbles away instantly!]","thanks to your efforts and the","power of the sealing stone,","the vile mol'ojar has once","again been sealed away in","eternal slumber.","","with any luck, you shall be the","last to fall prey to its","influence.","","thanks for playing!","","","you've subdued mol'ojar for the","moment, though you have a","nagging sense that the vile","thing won't stay down for long.","","you're not sure you could do it","again when it comes back.","","thanks for playing!","(want a better ending?","search the island!)","",""},{},{}

p_x,p_y,p_face,p_frame,p_hpmax,p_hp,level,xp,xp_next,status,diz,still = 1.75,30.75,3,0,16,16,1,0,5,0,false,0
-- -1=dead, 0=normal, 1=poison, 2=dizzy, 3=panic

e_id,e_name,e_hp,e_hpmax,e_xp,e_res_atk,e_res_spl = 1,{"","ballcrab","grumpsnail","hornmole","sunbloom","shroompuff","battlebug","lurkworm","zippermaw","ominous statue","watcher","boiling chorus","coiled blessing","mol'ojar"},1,{1,10,9,14,12,16,18,20,22,28,25,32,28,50},{0, 2,2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 0},{0, 0,2, 0, 0, 0, 4,n1, 3, 6,n1, 6, 1,10},{0,n1,0, 0, 2, 3,n1, 4, 1, 0, 7, 4, 8,12}

b_mode = n1 -- -2=start, -1=trans., 0=p. turn, 1=trans., 2=p. skill, 3=trans., 4=e. turn
p_hurt,e_hurt,e_skl,damage,heal,tab,sel,r_wait = 0,0,0,0,0,0,0,0

idle,lwr,tab_rot,tab_dir,tab_flip,s_lwr,b_back = 0,64,0,0,1,0,true

pop_list,pop_id,pop_wait,pop_wait2,pops_dmg,pops_heal,parts = {"miss...","ok!","solid!","great!","amazing!","epic!","escape failed...","escape succesful!","poisoned!","dizzied!","panicked!","victory!"},0,0,0,{},{},{}

init_ability()

s_id,s_list,s_var1,s_var2,s_var3,s_var4,src = 0,{},0,0,0,0,stat"102"

--check for save
if dget"8" == 1 then add(title_menu,"continue") end
end
-->8
--actors

function add_actors()
 actors = {}
 add_actor(1,2,29,112,false,48)
 add_actor(1,34,7,112,false,48)
 add_actor(1,52,14,112,false,48)
 add_actor(1,69,4,112,false,48)
 add_actor(1,85,6,112,false,48)
 add_actor(1,100,10,112,false,48)
 add_actor(1,29,33,112,false,48)
 add_actor(2,10,10.5,115,true,32)
 add_actor(3,8.4,19,116,false,32)
 add_actor(4,13,30.8,118,false,32)
 add_actor(5,13,41.8,120,true,32)
 add_actor(6,41,36,124,false,1)
 add_actor(7,47,36,124,false,1)
 --items
 if mcguff == 0 then 
  add_actor(8,44,38,123,false,1)
 end
 add_actor(9,28,37,122,false,1)
end


function add_actor(itype,x,y,sp,mir,fmax)
 a={itype = itype, -- 1=save, 2+=talk
   x = x,
   y = y,
   sp = sp,
   mir = mir,
   f = 0,
   fmax = fmax}
 
 add(actors,a)
end


function update_actor(a)
 a.f = (a.f+1)%a.fmax
 if a.itype == 8 and mcguff != 0 then del(actors,a) end
end


function check_prox(a,num)
 return abs(p_x-a.x-0.3) < num and abs(p_y-a.y-0.4) < num
end


function draw_actor(a)
 if (zone < 0 and check_prox(a,6) != true) or (a.itype == 9 and (interact >= 14 or battle == 2)) then
    return
 end
 local x,y,ff,m = 8*(a.x-p_x+8)-2,8*(a.y-p_y+8)-3,flr(a.f/16),false
 if a.mir then
    ff = 0
    if a.f > a.fmax/2 then m = true end
 end
 spr(a.sp+ff,x,y,1,1,m)
end


function draw_actor1(a)
 if a.y < p_y then draw_actor(a) end
end


function draw_actor2(a)
 if a.y >= p_y then draw_actor(a) end
end


function check_itype(a)
 if check_prox(a,1.2) then
    interact = a.itype
 end
end

-- < vfx functions >

function add_part(char,clr,x,y,dx,dy,ddx,ddy,tmax)
 pt={char = char,
    clr = clr,
    x = x,
    y = y,
    dx = dx,
    dy = dy,
    ddx = ddx,
    ddy = ddy,
    t = 0,
    tmax = tmax}
  
 add(parts,pt)
end


function move_part(pt)
 if pt.t > pt.tmax then
    del(parts,pt)
 end
 pt.x += pt.dx
 pt.y += pt.dy
 pt.dx += pt.ddx
 pt.dy += pt.ddy
 pt.t += 1
end


function draw_part(pt)
 print(pt.char,pt.x,pt.y,pt.clr)
end


function popup(id)
 pop_id,pop_wait = id,40
 if pop_id > #pop_list then pop_id = #pop_list end
 if id < 7 then snd(4+id)
 elseif id == 7 then snd(5)  --fail
 elseif id == 8 then --succeed
    music(n1)
    snd(10)
 elseif id == 12 then snd(12) --victory
 end
end


function popup_num(target,hurt,num)
 local pd_x,pd_y = 58,40
 if target == 0 then
    pd_x,pd_y = 80,80
    if not hurt then pd_x += 8 end
 end
 if hurt then
    add(pops_dmg,pd_x)
    add(pops_dmg,pd_y)
    add(pops_dmg,num)
 else
    add(pops_heal,pd_x)
    add(pops_heal,pd_y)
    add(pops_heal,num)
 end
 pop_wait2 = 20
end


function pops_clear()
 if #pops_dmg > 0 then
    for i=1,#pops_dmg do
       del(pops_dmg,pops_dmg[i])
    end
 end
 if #pops_heal > 0 then
    for i=1,#pops_heal do
       del(pops_heal,pops_heal[i])
    end
 end
end


function part_psn()
 for i=0,4 do
    add_part("●",3+8*ri2(),47+rnd"32",50+rnd"20",2,3,0,-0.05,10+rint(10))
 end
end


function part_psn2()
 for i=0,6 do
    add_part("●",3+8*ri2(),85+rnd"15",105+rnd"10",0,-2,0,0.1,10+rint(10))
 end
end


function part_diz()
 for i=0,5 do
    add_part("◆",12+ri2(),59+rnd"3",47+rnd"3",3,-0.7,-0.15,0.7,14)
 end
end


function part_diz2()
 local d = rnd"30"
 for i=0,2 do
    d += 10
    add_part("★",12+ri2(),87+rnd(6),102+rnd(6),cos(d/30),sin(d/30),0.1*cos(0.4+d/30),0.1*sin(0.4+d/30),10+rint(10))
 end
end

function part_pan()
 for i=0,3 do
    add_part("☉",8+6*ri2(),80+rnd"20",90+rnd"20",rnd"1",rnd"1",0,0,10+rint(10))
 end
end

function part_spl_player(num)
 local n = num*3+3
 for i=0,n do
    add_part("◆",9+3*ri2(),48+rnd"24",80+rnd"20",0,-5,0,-0.2,25)
 end
end

function part_bubble()
 for i=0,4 do
    add_part("●",6+7*ri2(),272-8*p_x+rnd"32",400-8*p_y,0,-0.5,0,-0.05,5+rint(7))
 end
end

function part_cure()
 for i=0,10 do
    local d = rnd"30"/30
    add_part("♥",7+7*ri2(),82+rnd"36",104+rnd"4",cos(d)/2,sin(d)/2,-0.02*cos(d),-0.02*sin(d),20+rint(10))
 end
end

-->8
--utility
function osc_sin(pos,mag,ofst)
 return pos+mag*sin(((idle+ofst)%50)/50)
end


function rint(num)
 return flr(rnd(num))
end

function ri2()
 return rint(2)
end


function snd(n)
 sfx(n,0)
end


function save_data()
 p_hp,status = p_hpmax,0
 dset(0,p_x)
 dset(1,p_y)
 dset(2,level)
 dset(3,xp)
 dset(4,xp_next)
 dset(5,p_hpmax)
 dset(6,mcguff)
 dset(7,zone)
 --create save
 dset(8,1)
end


function load_data()
 p_x,p_y,level,xp,xp_next,p_hpmax,mcguff,zone = dget"0",dget"1",dget"2",dget"3",dget"4",dget"5",dget"6",dget"7"
 init_ability()
 unlock_skills()
 p_hp,status,battle,lwr,rel_wait = p_hpmax,0,0,64,25
 zone_music()
end


function flag(x,y,flag)
 return fget(mget(flr(x),flr(y)),flag)
end


function toggleback()
 b_back = not b_back
end


function skip_intro()
 i_progress,still = 9,0
end
-->8
--main
function act()
 if rel_wait > 0 then
    return false
 else
    return btnp"4" or btnp"5"
 end
end

function p_move()
 local dx,dy,move = 0,0,true
 --get input
 if btn"2" or btn"3" then
    if btn"2" then
       dy -= 0.125
       p_face = 2
    else
       dy += 0.125
       p_face = 3
    end
 elseif btn"0" or btn"1" then
    if btn"0" then
       dx -= 0.125
       p_face = 0
    else
       dx += 0.125
       p_face = 1
    end
 else
    move = false
    p_frame = 0
 end
 --move
 if flag(p_x+dx,p_y+dy,0) then
    dx,dy = 0,0
 end
 if dx != 0 or dy != 0 then
    p_frame = (p_frame+0.25)%4
    p_x += dx
    p_y += dy
    --door
    if flag(p_x,p_y,7) then
       local x = flr(p_x)
       p_face,p_frame,notice,wait = 3,0,2,10
       for i=1,#doors/4 do
          local id = i*4
          if x == doors[id-3] then
             p_x,p_y,zone = doors[id-2],doors[id-1],doors[id]
          end
       end
       if zone > 0 then zone_music() end
    end
    --change zone
    local tile = mget(flr(p_x),flr(p_y))
    if zone > 0 and tile == 13 then
       zone = 0
       zone_music()
    elseif zone != 1 and (tile == 26 or tile == 42 or tile == 80) then
       if zone == 0 then
          zone = 1
          zone_music()
       else
          zone = 1
       end
    elseif zone != 2 and (tile == 24 or tile == 40) then
       zone = 2
    elseif zone != 3 and (tile == 94 or tile == 109) then
       zone = 3
    end
    --start battle
    if b_wait > 0 then b_wait -= 1
    elseif rint(60) == 0 then
       if flag(p_x,p_y,1) then
          b_start(false)
       end
    end
 end
 if move then
    if still > 736 then still -= 32
    else still = 0
    end
 elseif still < 800 then still += 8
 end
end


function zone_music()
 local m = 39
 if zone <= 0 then m = 31
 elseif zone <= 3 then m = 21
 elseif zone == 5 then m = 17
 end
 music(m,1500)
end


function game_over()
 p_hp,pop_id,status,wait = 0,0,n1,180
 snd(n1)
 music"0"
end


function unlock_skills()
 if level >= 2 and #action == 1 then add(action,"recover") end
 if level >= 3 and #attack == 1 then add(attack,"bonk") end
 if level >= 4 and #spell == 1 then add(spell,"spark") end
 if level >= 5 and #attack == 2 then add(attack,"bash") end
 if level >= 6 and #spell == 2 then add(spell,"shine") end
 if level >= 7 and #attack == 3 then add(attack,"crush") end
 if level >= 8 and #spell == 3 then add(spell,"radiance") end
end


function dialogue()
 text = {}
 for i=0,2 do
    add(text,talk[interact*3-4+i])
 end
 wait = 40
 snd(26)
end


-- < basic functions >

function _init()
 cartdata("jusiv_adc_v2")
 menuitem(2, "change backdrop", toggleback)
 setup()
 music"2"
end


function _update()
 if rel_wait > 0 then rel_wait -= 1 end
 idle = (idle+1)%200
 if complete then
    if act() then
       setup()
    end
    return
 end
 foreach(parts,move_part)
 --title screen
 if title then
    if wait > 0 then
       wait -= 1
    --change
    elseif btn(2) or btn(3) then
       sel = (sel+1)%#title_menu
       wait = 5
       snd(40)
    --select 
    elseif act() then
       snd(41)
       if sel == 1 then
          load_data()
          still = 700
       else
          intro,still,wait,mcguff = true,1,100,0
          music(27,1500)
          menuitem(1,"skip intro",skip_intro)
       end
       title,sel = false,0
       add_actors()
    end
    return
 end
 --intro
 if intro then
    if i_progress == 0 then
       still += 1
       if still >= 20 then
          i_progress,wait = 1,310
       end
    elseif i_progress >= 9 then
       still -= 0.25
       if still <= 0 then
          intro = false
          save_data()
          zone_music()
          menuitem(1)
       end
    else
       if act() and wait < 270 then
          wait = min(wait,30)
       end
       if wait <= 0 then
          i_progress += 1
          wait = 310
       elseif mid(wait,31,240) != wait then wait -= 1
       end
    end
    return
 end
 --game over
 if status < 0 then
    if status > -9 then status -= 0.1
    elseif wait <= 0 and (btn(4) or btn(5)) then
       load_data()
    end
 end
 --final sequence
 if interact >= 15 then
    still += 1
    part_bubble()
    if still >= 128 then
       b_start(true)
    end
 end
 --not in battle
 if battle == 0 then
    foreach(actors,update_actor)
    --show notif
    if notice > 0 then
       if notice == 1 and lwr > 0 then lwr -= 8 end
       if wait > 0 then
          if wait == 10 and notice == 2 then snd(25)
          elseif wait == 30 and notice == 1 then snd(24)
          end
          wait -= 1
       --close notif
       elseif act() or notice == 2 then
          if interact > 8 and interact <= 14 then
             interact += 1
             if interact <= 14 then dialogue()
             else
                notice = 0
                music"1"
             end
          else
             if interact == 8 then mcguff = 1 end
             notice = 0
          end
          still = 0
       end
       return
    end
    
    if lwr < 64 then lwr += 8 end
    if interact < 14 then
       p_move()
       --interact
       interact = 0
       foreach(actors,check_itype)
       if interact > 0 then
          if act() then
             if interact == 1 then
                save_data()
                text = {talk[1]}
                snd(27)
             else
                dialogue()
             end
             wait,notice = 30,3
          end
       end
    end
 --in battle
 else
    if pop_wait > 0 then pop_wait -= 1
    else pop_id = 0 end
    if pop_wait2 > 0 then pop_wait2 -= 1
    else pops_clear() end
    if battle == 4 and wait == 100 then
       popup(12)
    end
    if p_hurt > 0 then p_hurt -= 1 end
    if e_hurt > 0 then e_hurt -= 1 end
    if p_hp > 0 and (battle > 2 or battle == -0.5) then
       wait -= 1
       if s_lwr >= 0 then s_lwr -= 8 end
       if wait == 15 then
          if e_id > 13 then
             complete = true
             rel_wait = 150
             music"2"
          else battle = -0.5
          end
       elseif wait <= 0 then battle_end()
       end
    --if battle starting
    elseif b_mode == -2 then
       wait -= 1
       if wait <= 0 then
          parts,wait,b_mode = {},10,n1
       end
    --if changing to player turn
    elseif b_mode == n1 then
       lwr -= 8
       if lwr <= 0 then
          diz = false
          --resolve damage
          if damage > 0 then
             popup_num(0,true,damage)
             p_hp -= damage
             damage,p_hurt = 0,10
          end
          if heal > 0 then popup_num(1,false,heal) end
          e_hp += heal
          if e_hp > e_hpmax[e_id] then e_hp = e_hpmax[e_id] end
          --reduce cooldown
          if r_wait > 0 then r_wait -= 1 end
          --change phase
          heal,b_mode = 0,0
       end
    --if menu open
    elseif b_mode == 0 then
       if wait > 0 then
          wait -= 1
          if tab_dir != 0 then
   	         tab_rot += tab_dir
             if abs(tab_rot) >= 8 then 
                tab,tab_flip = (3+tab+tab_dir)%3,n1
                tab_dir *= n1
             end
          end
       else
          tab_dir,tab_rot,tab_flip = 0,0,1
          local len = 0
          if tab == 0 then len = #attack
          elseif tab == 1 then len = #spell
          elseif tab == 2 then len = #action end
          if p_hp > 0 then
             --change tab
             if btn"0" or btn"1" then
                if btn"0" then tab_dir = n1
                else tab_dir = 1 end
                sel = 0
                wait = 16
                snd(2)
             --change selection
             elseif btn"2" or btn"3" then
                if btn"2" then sel = (sel+len-1)%len
                else sel = (sel+1)%len end
                wait = 5
                snd(1)
             --select
             elseif act() then
                pick_skill()
                pops_clear()
             end
          end
       end
    --menu closing / skill
    elseif b_mode < 3 then
       if wait > 0 then wait -= 1 end
       if b_mode == 1 then
          lwr += 8
          s_lwr += 8
          if lwr >= 64 then b_mode = 2 end
       end   
       if s_id < 4 then skl_atk()
       elseif s_id < 8 then skl_spl()
       elseif s_id == 8 then skl_flee()
       elseif s_id == 9 then skl_rest()
       end
    --change to enemy turn
    elseif b_mode == 3 then
       if s_lwr > -8 then s_lwr -= 8
       else
          wait -= 1
          if wait == 30 then
             if s_id < 4  then snd(17)
             elseif s_id < 8 then snd(21)
             end
          elseif wait <= 0 then
             --resolve damage
             if status == 2 and rint(2) == 0 then
                damage = flr(damage/2)
                diz = true
                part_diz2()
                part_diz2()
                snd(22)
             end
             if s_id < 4 then damage -= e_res_atk[e_id]
             elseif s_id < 8 then damage -= e_res_spl[e_id]
             end
             if s_id < 8 then
                if damage < 0 then damage = 0 end
                popup_num(1,true,damage)
                if damage > 0 then
                   e_hp -= damage
                   if e_hp <= 0 then
                      e_hp = 0
                      if p_hp > 0 then
                         wait = 140
                         battle = 4
                         music(1)
                      end
                      e_hurt = 250
                   else e_hurt = 15
                   end
                   damage = 0
                end
             end
             if heal > 0 then popup_num(0,false,heal) end
             p_hp += heal
             if status == 1 then
                local newhp = flr(p_hp*0.75)
                popup_num(0,true,p_hp-newhp)
                p_hp,p_hurt = newhp,5
                part_psn2()
                snd(23)
             end
             if p_hp > p_hpmax then p_hp = p_hpmax end
             heal = 0
             --change phase
             if battle < 3 then
                wait,b_mode = 70,4
             end
          end
       end
    --enemy turn
    else
       enemy_turn()
    end
 end
 -- die
 if p_hp <= 0 and status >= 0 then
    game_over()
 end
end
-->8
--combat
function b_start(boss)
 if boss then
    e_id,battle = 14,2
 else
    e_id,battle = 2*zone+ri2(),1
 end
 snd(0)
 music(6,500)
 interact,e_hp,b_mode,wait,p_hurt,e_hurt,r_wait,pop_id,pop_wait,pops_dmg,pops_heal,pop_wait2,diz = 0,e_hpmax[e_id],-2,8,0,0,3,0,0,{},{},0,false
end


function pick_skill()
   s_id = sel+4*tab
   if (s_id == 8 and battle == 2) or (s_id == 9 and r_wait > 0) then
      snd(11)
   else
      s_list,s_var1,s_var2,s_var3,s_var4,b_mode = {},0,0,0,0,1
      snd(3)
   end
end


function skl_atk()
 local width = 4+2*s_id
 --initialize
 if b_mode == 1 then
    if s_var3 == 0 then
       for i=0,s_id+1 do add(s_list,width+8+rint(70-2*width)) end
       s_var3 = 1
    end
    return
 end
 --update
 if wait <= 0 then
    --panic status speeds up sliders
    s_var2 = (s_var2+s_id+flr(status/3)+2)%80
    --end
    if s_var3 > 1 then
       b_mode,damage,wait = 3,3*s_var1,60
       popup(1+flr(5*s_var1/(s_id+2)))
       return
    --get input
    elseif btnp(4) or btnp(5) then
       if abs(s_list[s_var1+1]-s_var2) <= width then
          wait,s_var2 = 10,0
          s_var1 += 1
          if s_var1 > s_id+1 then s_var3 = 3 end
          snd(4)
       else
          wait,s_var3 = 20,2
          snd(11)
       end
    end
 end
end


function draw_skl_atk()
 if s_var3 == 0 then return end
 --draw window
 local c = 6
 if status == 3 then c = 14 end
 box(21,127-s_lwr,106,143+8*#s_list-s_lwr,c,5)
 print("stop the sliders!",31+3*sin(idle/50),130-s_lwr,7)
 if idle%25 < 10 then color"6" end
 print("🅾️",osc_sin(60,1.5,10),136+8*#s_list-s_lwr)
 --draw sliders
 local width = 4+2*s_id
 for i=0,#s_list-1 do
    if s_var3 == 3 then color(8+(i+flr(idle/5))%8)
    else color"13" end
    local yy = 8*i-s_lwr
    rect(24,138+yy,103,140+yy)
    if i < s_var1 then color"11"
    elseif s_var3 == 2 then color"8"
    else color"10" end
    rectfill(24+s_list[i+1]-width,137+8*i-s_lwr,24+s_list[i+1]+width,141+8*i-s_lwr)
    if s_var1 == i then line(24+s_var2,136+8*i-s_lwr,24+s_var2,142+8*i-s_lwr,7) end
 end
end


function skl_spl()
 --panic status speeds up timer
 local panic = 0
 if status == 3 then panic = 1 end
 --initialize
 if b_mode == 1 then
    if s_var4 == 0 then
       s_var1,s_var2,s_var3,s_var4 = ri2(),rint(5),160,1
    end
    return
 end
 --update
 if wait <= 0 then
    s_var3 -= 1+(s_id+panic-3)/2
    if s_var3 <= 0 then s_var4 = 3 end
    if s_var4 > 1 then
       s_var1,b_mode,wait = #s_list,3,60
       damage = (s_id-3)*s_var1
       popup(1+s_var1)
       return
    --get input
    elseif btnp(4) or btnp(0) then
       wait = 5
       if s_var1 == 0 then
          spl_rune()
       else
          s_var4 = 2
          snd(11)
          wait += 30
       end
    elseif btnp(5) or btnp(1) then
       wait = 5
       if s_var1 == 1 then
          spl_rune()
       else
          s_var4 = 2
          snd(11)
          wait += 30
       end
    end
 end
end


function spl_rune()
 add(s_list,s_var2)
 if #s_list >= 5 then
    s_var4,wait = 3,15
 end
 s_var1 = ri2()
 s_var2 = (s_var2+1+rint(4))%5
 snd(4)
end


function draw_skl_spl()
 if s_var4 == 0 then return end
 local scale = 28+4*cos(idle/25)
 local xpos = 0
 if s_var4 < 2 and wait > 0 then
    if btn"4" or btn"0" then
       xpos -= 8
       scale *= 0.8
    elseif btn"5" or btn"1" then
       xpos += 8
       scale *= 0.8
    end
 end
 --draw window
 local c = 6
 if status == 3 then c = 14 end
 box(21,127-s_lwr,106,177-s_lwr,c,5)
 print("match the color!",33+3*sin(idle/50),130-s_lwr,7)
 if s_var4 == 2 then color"2"
 else color"9" end
 local ofst = 3.5*cos(idle/50)
 circ(35+ofst,154-s_lwr,7)
 print("⬅️",32+ofst,152-s_lwr)
 if s_var4 == 2 then color"2"
 else color"12" end
 circ(93-ofst,154-s_lwr,7)
 print("➡️",90-ofst,152-s_lwr)
 --draw timer
 rectfill(23,137-s_lwr,104,141-s_lwr,0)
 rectfill(24,138-s_lwr,24+s_var3/2,140-s_lwr,10)
 --draw rune
 if s_var4 == 2 then pal(7,8)
 elseif s_var4 == 3 then pal(7,8+(flr(idle/5))%8)
 else pal(7,9+3*s_var1) end
 sspr(8+8*s_var2,24,8,8,65+xpos-scale/2,155-s_lwr-scale/2,scale,scale)
 pal()
 --draw collected runes
 for i=1,#s_list do
    if s_var4 == 3 then pal(7,8+(flr(i+idle/5))%8) end
    spr(49+s_list[i],36+8*i,osc_sin(168-s_lwr,1.5,i*4))
    pal()
 end
end


function skl_flee()
 --initialize
 if b_mode == 1 then
    if s_var4 == 0 then
       s_list,s_var1,s_var3,s_var4 = {"⬅️","➡️","⬆️","⬇️"},1+rint(4),120,1
    end
    return
 end
 --update
 if wait <= 0 then
    --check if limit reached
    if s_var2 >= 12 and s_var4 < 2 then
       s_var4,wait = 3,10
       return
    end
    --update timer
    if s_var4 < 2 then
       s_var3 -= 1
       --panic status speeds up timer
       if status == 3 then s_var3 -= 0.5 end
    end
    if s_var3 <= 0 then s_var4 = 2 end
    if s_var4 == 2 then
       --fail
       b_mode = 3
       popup(7)
       return
    elseif s_var4 == 3 then
       --succeed
       b_mode,battle,e_id,wait = 3,3,1,50
       popup(8)
       return
    --get input
    else
       for i=0,5 do
          if btnp(i) then
             if s_var1 == i+1 then
                wait = 4
                if s_var2 < 12 then s_var2 += 1 end
                if rint(3) == 0 then s_var1 = 1+rint(4) end
                snd(14)
             else
                snd(15)
             end
          end
       end
    end
 end
end


function draw_skl_flee()
 if s_var4 == 0 then return end
 local xpos = 2*sin(idle/50)
 --draw window
 local c = 6
 if status == 3 then c = 14 end
 box(16,127-s_lwr,111,178-s_lwr,c,5)
 print("mash the button shown!",21+1.5*xpos,130-s_lwr,7)
 --draw timer
 rectfill(33,137-s_lwr,94,140-s_lwr,0)
 rectfill(34,138-s_lwr,34+s_var3/2,139-s_lwr,10)
 --draw meter
 rectfill(47,143-s_lwr,80,175-s_lwr,0)
 rectfill(48,174-s_var2*2.5-s_lwr,79,174-s_lwr,8+flr(s_var2/4))
 circfill(63,159-s_lwr+xpos,8,0)
 if wait > 0 and s_var4 < 2 then color(3)
 else color(5) end
 circfill(63,159-s_lwr+xpos,7)
 circ(63,159-s_lwr+xpos,7,6)
 rectfill(62,158-s_lwr+xpos,64,160-s_lwr+xpos,0)
 if s_var4 == 3 then color(8+flr(idle/5)%8)
 else color(7) end
 print(s_list[s_var1],60,157-s_lwr+2*sin(idle/50))
end


function skl_rest()
 if b_mode == 1 then
    if s_var4 == 0 then
       s_var2,s_var3,s_var4 = 1-2*ri2(),120,1
    end
    return
 end
 if wait <= 0 then
    if s_var3 > 0 then s_var3 -= 1
    else s_var4 = 2 end
    if s_var4 > 1 then
       b_mode = 3
       local res = flr(abs(s_var2)/5)
       if res < 5 then
          if res < 2 then
             status = 0
             part_cure()
          end
       else res = 5 end
       heal = flr(p_hpmax/(2*(res+1)))+1
       popup(6-res)
       r_wait = 3
       return
    else
       if s_var2 == 0 then s_var2 = 1-2*ri2() end
       if btn"4" or btn"0" then s_var2 -= 2 end
       if btn"5" or btn"1" then s_var2 += 2 end
       --panic status makes meter tilt faster
       if status == 3 then s_var2 += s_var2*0.12
       else s_var2 += s_var2*0.1 end
    end
    if abs(s_var2) >= 50 then
       if abs(s_var2) == s_var2 then s_var2 = 50
       else s_var2 = -50 end
       s_var4 = 2
    end
 end
end


function draw_skl_rest()
 if s_var4 == 0 then return end
 --draw window
 local c = 6
 if status == 3 then c = 14 end
 box(21,127-s_lwr,106,177-s_lwr,c,5)
 print("keep it balanced!",32+3*sin(idle/50),130-s_lwr,7)
 --draw timer
 rectfill(23,137-s_lwr,104,141-s_lwr,0)
 rectfill(24,138-s_lwr,24+s_var3/2,140-s_lwr,10)
 --draw meter
 circfill(63,162-s_lwr,14,13)
 rectfill(42,163-s_lwr,84,176-s_lwr,5)
 local res = flr(abs(s_var2)/5)
 if res > 5 then res = 5 end
 line(63,162-s_lwr,63-18*sin(s_var2/200),162-s_lwr-18*cos(s_var2/200),11-res)
 if idle%25 >= 10 then color(7)
 else color(6) end
 print("⬅️",36+3*cos(idle/50),167-s_lwr)
 print("➡️",86-3*cos(idle/50),167-s_lwr)
end

function enemy_turn()
 if wait > 0 then
    local r1,r2,r3 = ri2(),rint(3),rint(4)
    if wait == 30 then
       --pick skill
       e_skl = 1
       if battle == 2 then
          if r2 == 0 then e_skl += r3 end
       elseif r3 == 0 then
          if e_id == 6 or e_id == 8 or e_id == 11 or e_id == 12 then
             e_skl = 2
          elseif e_id == 5 or e_id == 9 or e_id == 13 then
             e_skl = 3
          end
       elseif r2 == 0 then
          if e_id == 11 then e_skl = 3
          elseif e_id == 12 or e_id == 13 then e_skl = 4
          end
       end
       --play sound
       snd(16+e_skl)
    elseif wait == 10 then
       --enemy skill
       if e_skl == 1 then
          if e_id == 2 then
             damage = 2
          elseif e_id == 3 or e_id == 5 then
             damage = 1+r1
          elseif e_id == 4 or e_id == 6 then
             damage = 2+r1
          elseif e_id == 7 then
             damage = 3+r1
          elseif e_id == 8 or e_id == 11 then
             damage = 2+r2
          elseif e_id == 9 then
             damage = 4+r1
          elseif e_id == 10 then
             damage = 3+r2
          elseif e_id == 12 then
             damage = 4+r3
          elseif e_id == 13 then
             damage = rint(7)
          else damage = 2+rint(6)
          end
       else status_effect(e_skl-1)
       end
    end
    wait -= 1
 else 
    e_skl,b_mode = 0,-1
    return
 end
end


function status_effect(num)
 --poison, dizzy, or panic
 status = num
 popup(8+num)
end


function battle_end()
 if p_hp > 0 then
    zone_music()
    battle,b_wait,lwr,still = 0,60,64,300
    xp += e_xp[e_id]
    --level up
    if xp >= xp_next then
       level += 1
       xp -= xp_next
       xp_next = 1+flr(xp_next*1.5)
       p_hpmax += 2
       p_hp,status,notice,wait = p_hpmax,0,1,30
       unlock_skills()
    end
 end
end


function draw_atk(player,clr,y)
 if wait <= 30 then
    local ofst = 0
    if player then
       ofst = 24-y
       pal(8,clr)
    end
    if wait > 25 then
       sspr(48,8,8,8,59,63-ofst,24,24,false,player)
    elseif wait > 20 then
       sspr(56,8,8,8,59,63-ofst,24,24,false,player)
       sspr(48,8,8,8,37,63-ofst,24,24,true,player)
    elseif wait > 15 then
       sspr(48,8,8,8,59,63-ofst,24,24,false,player)
       sspr(56,8,8,8,37,63-ofst,24,24,true,player)
    elseif wait > 10 then
       sspr(48,8,8,8,37,63-ofst,24,24,true,player)
    end
    pal()
 end
end


function draw_spl(id)
 --id: 0-3=player, 4=poison, 5=dizzy, 6=panic
 if wait <= 0 then return
 elseif wait <= 30 and wait%5 == 0 then
    if id == 4 then part_psn()
    elseif id == 5 then
       if wait > 20 then part_diz()
       elseif wait <=16 then part_diz2() end
    elseif id == 6 then
       for i=0,2 do
          line(63,49+i,90,100+i,8+6*ri2())
       end
       if wait <= 18 then part_pan() end
    else part_spl_player(id)
    end
 end
end
-->8
--draw
function notify_level()
 local str = "level up!"
 local ofst = 1.5*lwr
 box(20,42-ofst,106,85-ofst,6,5)
 rect(19,41-ofst,107,86-ofst,7)
 for i=1,#str do
    print(sub(str,i,i),59-4*#str+i*8+2.5*cos(((50+i-idle)%50)/25),45-ofst,8+(flr((idle+2*i)/2))%6)
 end
 str = "you are now level "..level
 print(str,64-2*#str,53-ofst,7)
 str = "hp: "..(p_hpmax-2).." -> "..p_hpmax
 print(str,64-2*#str,61-ofst)
 if wait <= 0 then
    if idle%25 < 10 then color"6"
    else color"7" end
    print("🅾️",osc_sin(60,1.5,10),77-ofst)
 end
 if level == 2 then str = "recover"
 elseif level == 3 then str = "bonk"
 elseif level == 4 then str = "spark"
 elseif level == 5 then str = "bash"
 elseif level == 6 then str = "shine"
 elseif level == 7 then str = "crush"
 elseif level == 8 then str = "radiance"
 else return end
 str = "new skill: "..str
 print(str,64-2*#str,69-ofst,12)
end


function show_stats(ypos)
 local yy = 73+ypos/2
 local xpos = osc_sin(yy,1.5,5)
 local sp = 48
 if battle == 0 then
    box(yy-5,87+ypos,128,128,6)
    rectfill(yy-4,88+ypos,128,ypos+120,5)
    if mcguff == 1 then
       spr(123,yy+40,105+ypos)
    end
 end
 if status > 0 then
    pal(7,10)
    if status == 1 then
       pal(8,3)
       pal(14,11)
    else sp = 36+status
    end
 end
 spr(sp,xpos,90+ypos)
 color(7)
 if p_hp <= p_hpmax/5 then pal(7,8) end
 print("hp: "..p_hp.."/"..p_hpmax,xpos+10,92+ypos)
 pal()
 print("level: "..level,osc_sin(yy,1.5,45),99+ypos)
 local nxp,exp = xp,e_xp[e_id]
 if battle == 4 and pop_id != 12 and wait < 100 then
    nxp += exp
 end
 print("xp: "..nxp.."/"..xp_next,osc_sin(yy,1.5,35),106+ypos)
 if pop_id == 12 then
    print("+"..exp,yy-12,106+ypos,10)
 end
end


function box(x1,y1,x2,y2,c1,c2)
 rectfill(x1,y1,x2,y2,c2)
 rect(x1,y1,x2,y2,c1)
end


function pressz(x,y,c1,c2)
 if flr(idle/50)%2 == 0 then
    rectfill(x+2,y,x+4,y+3,c2)
    print("🅾️",x,y,c1)
 end
end


function draw_intro(xpos)
 for i=0,32 do
    local ii = 5*i
    local ofst = 136-xpos+4.5*sin((idle+10*i)/100)
    print("░▒",ofst-27,ii,12)
    rectfill(ofst-12,ii,128,ii+5)
    print("░▒",ofst,ii,13)
    rectfill(ofst+15,ii,128,ii+5)
 end
 ofst = 200-xpos
 local ofst2,r = 108,0
 if i_progress >= 9 then
    r += 48*cos((still-5)/60)
    if still < 10 then
       ofst,ofst2 = 63,63
       if still <= 5 then
          r = -13-61*sin(max(0,still/20))
       end
    else
       ofst,ofst2 = 53+still,63+46*(still-10)/10
    end
 end
 if still > 0 then r += 2.5*sin(idle/50) end
 circfill(ofst,ofst2,13+r,1)
 circfill(ofst,ofst2,10+r*0.6,0)
 spr(1,ofst-4,ofst2-4)
 if i_progress > 0 then
    color"7"
    if wait < 10 or wait > 300 then return
    elseif wait < 30 or wait > 280 then color(6) end
    for i=1,#intro_text do
       for i=1,8 do
          print(intro_text[i+(i_progress-1)*8],34,10*i)
       end
    end
    if mid(wait,31,240) == wait then
       print("🅾️",119,121,6)
       pressz(119,120,7,13)
    end
 end
end


function fillscreen(trans)
 if trans == 1 then fillp(0b0101101001011010.1)
 elseif trans != 2 then fillp(0b0111110101111101.1)
 end
 rectfill(0,0,127,127)
 fillp()
end


function battleback()
 local ofst = 2.5*sin(idle/100)
 if b_back then
    if p_hp <= p_hpmax/5 then color"2"
    else color"1" end
    rectfill(-10,-10,137,137)
    for i=0,8 do
       for k=0,20 do
          circfill(20*i+idle/5-35+ofst,10*k-ofst,abs(13*cos(((idle/2+5*k+12.5*i)%50)/50)),0)
       end
    end
    for k=0,8 do
       for i=0,20 do
          circfill(10*i+ofst,20*k+idle/5-35-ofst,abs(10*cos(((idle/2+5*i+12.5*k+25)%50)/50)))
       end
    end
 else
    rectfill(-10,-10,137,137,0)
    if p_hp <= p_hpmax/10 then color"2"
    else color"1" end
    rectfill(5,5,122,122)
    rect(8,8,119,119,0)
    rectfill(12,12,115,115)
 end
end


function grayscale()
 pal(1,0)
 pal(8,13)
 pal(9,13)
 for i=2,4 do
    pal(i,5)
 end
 for i=10,15 do
    pal(i,6)
 end
end

function _draw()
 if not (src == 0 or src == "www.lexaloffle.com" or src == "v6p9d9t4.ssl.hwcdn.net") then
    rectfill(0,113,128,128,8)
    print("please play this game on\njusiv.itch.io/a-dreams-command",2,115,7)
    return
 end
 camera()
 pal()
 cls()
 if complete then
    local ii = 13*mcguff
    for i=54,66 do
       print(talk[i-ii],2,i*8-414,7)
    end
    if rel_wait <= 0 then
       print("🅾️",60,122,6)
       pressz(60,121,7,0)
    end
    return
 end
 local ofst,str,xx,yy,xx2,yy2 = 0,"talk? 🅾️",still*8-32,0,0,0
 if title or intro then
    if i_progress < 9 then
       if still < 20 then
          battleback()
          print("a    ream's    ommand",22,30,7)
          print("a game by @jusiv_",31,122)
          circfill(35,32,5)
          circfill(75,32,5)
          print("d         c",34,30,1)
          color"7"
          for i=1,#title_menu do
             if sel+1 == i then print(">",44+cos((idle%25)/50),66+6*i) end
             ofst = flr(((idle-3*i+50)%50)/45)-1
             print(title_menu[i],50+ofst,66+6*i)
          end
       else xx = 128
       end
       if intro then draw_intro(xx) end
       return
    end
 end
 if battle < 1 or b_mode == -2 then
    --draw world
    pal(10,0)
    if zone >= 0 and zone < 4 then color(12)
    else color"0" end
    rectfill(0,0,128,128)
    xx = flr(p_x)-5
    yy = flr(p_y)-5
    xx2 = -8*(p_x-flr(p_x))
    yy2 = -8*(p_y-flr(p_y))
    if zone < 0 then
       map(xx,yy,xx2+22,yy2+25,11,11)
    else
       map(xx-3,yy-4,xx2-2,yy2-6,18,18)
    end
    pal()
    --draw actors
    foreach(actors,draw_actor1)
    local id,xflip = 1+flr(p_frame),false
    if still > 750 then
       if idle/100 >= 1 then id = 125
       else id = 1
       end
    elseif p_face == 2 then
       id += 4
    elseif p_face < 2 then
       id += 8
       if p_face == 0 then xflip = true end
    end
    spr(id,59,59,1,1,xflip)
    foreach(actors,draw_actor2)
    --draw final
    if interact >= 15 or battle == 2 then
       if mcguff == 1 and still >= 64 then
          local pos = osc_sin(49,1.5,0)+max(0,24-still/4)
          circ(62,pos+4,10+3*sin(still/8),3)
          spr(123,59,pos)
       end
       palt(7,true)
       sspr(96,96,32,still/4,275-8*p_x,401-8*p_y-still/4)
       palt()
    end
    --draw parts
    foreach(parts,draw_part)
    --draw popups
    ofst = flr(idle/25)%2
    if interact > 0 and interact <= 9 then
       if interact == 1 then str = "save? 🅾️"
       elseif interact >= 6 then str = "inspect? 🅾️"
       end
       local l = #str*4
       box(-1,119,9+l,128,6,5)
       print(str,1,122)
       pressz(l-3,121,7,5)
    end
    if notice == 3 and b_mode != -2 then
       box(-1,106,128,128,6,5)
       for i=1,#text do
          print(text[i],2,103+6*i,7)
       end
       if wait <= 0 then
          print("🅾️",120,122,6)
          pressz(120,121,7,5)
       end
    elseif notice == 1 or lwr < 64 then notify_level()
    elseif notice == 0 and still >= 700 then show_stats(214-still/4)
    end
    --draw battle trans
    if b_mode == -2 then
       local scl = 8*wait
       rectfill(scl,scl,128-scl,128-scl,0)
    end
    --draw intro closing
    if intro then
       draw_intro(still*8-32)
    end
 end
 --if in battle
 if battle > 0 and b_mode > -2 then
    --screenshake
    if p_hurt >= 0 then
       p_hurt -= 1
       camera(rnd(2)-1,rnd(2)-1)
    end
    battleback()
    --draw enemy
    if e_id > 1 then
       xx,yy = 47,24+sin(idle/50)*2*e_hp/e_hpmax[e_id]
       if e_hurt > 0 then
          e_hurt -= 1
          xx += rnd(4)-2
          yy += rnd(4)-2
       end
       --if attacking
       if e_skl > 0 then yy += 5 end
       --if dead
       if e_hp <= 0 then
          grayscale()
          color(8)
       else color(7) end
       if e_id > 13 then
          sspr(96,96,32,32,xx-16,yy-8,64,64)
       else
          sspr(16*((e_id-2)%6),96+16*flr(e_id/8),16,16,xx,yy,32,32)
       end
       pal()
       str = "hp: "..e_hp.."/"..e_hpmax[e_id]
       print(str,osc_sin(64-#str*2,2,10),9)
       str = e_name[e_id]
       print(str,osc_sin(64-#str*2,2,35),2,7)
    end
    --draw enemy skill
    if e_skl == 1 then draw_atk(false,8,0)
    elseif e_skl > 1 then draw_spl(e_skl+2)
    end
    --draw player skill
    if b_mode == 3 and battle < 3 then
       if s_id < 4 then
          if s_id > 2 then draw_atk(true,4,6) end
          if s_id > 1 then draw_atk(true,9,4) end
          if s_id > 0 then draw_atk(true,15,2) end
          draw_atk(true,10,0)
       elseif s_id < 8 then draw_spl(s_id-4)
       end
    end
    --draw particles
    foreach(parts,draw_part)
    --draw player stats
    show_stats(lwr/4)
    --draw menu
    if b_mode < 2 then
       ofst = 0
       if abs(tab_rot) > 2 then ofst = abs(tab_rot)-2 end
       box(7,92+lwr,65-6*ofst,126-4*ofst+lwr,6,5)
       for i=0,2 do
          local ang = (2-i)/3+tab_flip*tab_rot/48
          local scale = 10+6*cos(ang)
          if i == 2 then pal(6,7) end
          sspr(16*((tab+i+1)%3),8,16,16,17-scale/2+10*sin(ang),osc_sin(81+lwr,2,4*i)+3*cos(ang),scale,scale)
       end
       pal()
       color"7"
       if tab_dir == 0 then
          xx = osc_sin(29,2.5,35)
          if tab == 0 then
             print("attacks",xx,95+lwr)
             for i=1,#attack do
                if sel+1 == i then print(">",10+cos((idle%25)/50),96+6*i+lwr) end
                ofst = flr(((idle-3*i+50)%50)/45)-1
                print(attack[i],16+ofst,96+6*i+lwr)
             end
          elseif tab == 1 then
             print("spells",xx,95+lwr)
             for i=1,#spell do
                if sel+1 == i then print(">",10+cos((idle%25)/50),96+6*i+lwr) end
                ofst = flr(((idle-3*i+50)%50)/45)-1
                print(spell[i],16+ofst,96+6*i+lwr)
             end
          else
             str = ""
             print("actions",xx,95+lwr)
             for i=1,#action do
                if sel+1 == i then print(">",10+cos((idle%25)/50),96+6*i+lwr,7) end
                ofst = flr(((idle-3*i+50)%50)/45)-1
                color"13"
                str = ""
                if i == 1 and battle == 2 then
                   ofst = -1
                   str = "can't "
                elseif i != 2 or r_wait <= 0 then
                   color"7"
                end
                print(str..action[i],16+ofst,96+6*i+lwr)
             end
             if r_wait > 0 and #action >= 2 then
                --draw cooldown
                str = "wait "..r_wait.." turn"
                if r_wait > 1 then str = str.."s" end
                print(str,9,114+lwr,6)
                print("to use recover",9,120)
             end
          end
       end
    end
    --draw minigames
    if b_mode > 0 and b_mode < 4 then
       if s_id < 4 then draw_skl_atk()
       elseif s_id < 8 then draw_skl_spl()
       elseif s_id == 8 then draw_skl_flee()
       elseif s_id == 9 then draw_skl_rest()
       end
    end
    --draw popups
    local c = 0
    if pop_wait > 0 then
       if pop_id > 0 then
          local p = pop_list[pop_id]
          if pop_id > 8 and pop_id < 12 then c -= 4
          elseif pop_id == 12 then c = 1 end
          for i=0,2 do
             if pop_wait > 2*i and pop_wait <= 50-2*i then
                print(p,64-#p*2,67-i+2*sin(idle/25),8+i+c)
             end
          end
       end
    end
    if pop_wait2 > 0 then
       local x,y,n = 0,0,""
       c = 8
       if #pops_dmg > 2 then
          for i=1,flr(#pops_dmg/3) do
             x,y,n = pops_dmg[i*3-2],pops_dmg[i*3-1]+pop_wait2/10,"-"..pops_dmg[i*3]
             --change color if dizzy
             if diz and x < 70 then c = 13 end
             box(x-2,y-2,x+4*#n,y+6,6,c)
             print(n,x,y,c-1)
          end
       end
       if #pops_heal > 2 then
          for i=1,flr(#pops_heal/3) do
             x,y,n = pops_heal[i*3-2],pops_heal[i*3-1]+pop_wait2/10,"+"..pops_heal[i*3]
             box(x-2,y-2,x+4*#n,y+6,6,11)
             print(n,x,y,7)
          end
       end
    else
       pops_clear()
    end
 end
 --draw game over
 if status < 0 then
    color"2"
    if status > -4 then
       fillscreen(0)
    elseif status > -8 then
       fillscreen(1)
    else
       fillscreen(2)
       print("you have perished",31,61,8)
       if status <= -9 and wait <= 0 then
          print("🅾️",61,102)
          pressz(61,101,14,2)
       end
    end
 --draw end transition
 elseif battle > 2 or abs(battle) == 0.5 then
    if battle > 0 then color"6"
    else color"5" end
    if wait <= 25 then
       if wait > 20 then fillscreen(0)
       elseif wait > 15 then fillscreen(1)
       elseif wait > 10 then fillscreen(2)
       elseif wait > 5 then fillscreen(1)
       else fillscreen(0)
       end
    end
 end
 --print(interact.." "..battle,1,1,7)
end