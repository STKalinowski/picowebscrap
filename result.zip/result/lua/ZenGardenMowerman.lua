
player={}
player.damp=.9
player.rad=4

guy={}

clevel=0

levelcount=5

levelnames={}
levelnames[0]="mower alpha"
levelnames[1]="hypno-mower"
levelnames[2]="dial \"s\" for mower"
levelnames[3]="pathway mower"
levelnames[4]="final destination"

records={}
records[0]={name="tp3",
            score="1:10.3"}
records[1]={name="tp3",
            score="1:02.5"}
records[2]={name="tp3",
            score="1:13.5"}
records[3]={name="tp3",
            score="1:12.4"}
records[4]={name="tp3",
            score="1:23.2"}
            
startpos={}
startpos[0]={x=64,y=117}
startpos[1]={x=10,y=117}
startpos[2]={x=80,y=117}
startpos[3]={x=84,y=80}
startpos[4]={x=4,y=123}

lstep=false
steptimer=0
stepfreq=5/30

tracktick=1
flasher=true
gcolor2=10

mspeed=0
primemspeed=0
oldmspeed=0

minmowspeed=1
maxmowspeed=6

mspeedrate=.3
mspeedsmooth=.15

state="none"
transition=1

function _init()
	loadmenu()
end

function loadmenu()
	tstate="menu"
	sfx(-1,0)
	music(0,500)
end

function loadlevel()
	music(4,1000)
	setsfxspeed(8,maxmowspeed)
	sfx(8,0)
	
	menuitem(1,"retry level",function() state="reset" end)
	menuitem(2,"main menu",function() loadmenu() end)
	
	gdots={}
	grasscount=0
	cutcount=0
	mowedpixels=0
	rendermaptosprite()
	started=false
	victory=false
	timer=0
	
	player.x=startpos[clevel].x
	player.y=startpos[clevel].y
	
	player.ang=.25
	player.speed=0
	
	//foot position
	guy.fx1=player.x
	guy.fy1=player.y
	guy.fx2=player.x
	guy.fy2=player.y
	
	//knee position
	guy.kx1=player.x
	guy.ky1=player.y
	guy.kx2=player.x
	guy.ky2=player.y
	
	//target foot position
	guy.tfx1=player.x
	guy.tfy2=player.y
	guy.tfx2=player.x
	guy.tfy2=player.y
	
	//old foot position
	guy.ofx1=player.x
	guy.ofy1=player.y
	guy.ofx2=player.x
	guy.ofy2=player.y
	
	//hip position
	guy.hx=player.x
	guy.hy=player.y
	
	//neck position
	guy.nx=player.x
	guy.ny=player.y
end

function setsfxspeed(track,sp)
	poke(0x3200+65+68*track,sp)
end

function rendermaptosprite()
	cls()
	map(1+16*clevel,1,8,8,16,16)

	local col
	grasscount=0
	for i=8,119 do
		for j=8,119 do
		col=pget(i,j)
			if col==11 then
				grasscount+=1
				if (rnd(1)<.1) then
					pset(i,j,gcolor2)
					if (pget(i,j+1)==11) then
					 if (rnd(1)<.5) then
							pset(i,j+1,gcolor2)
							grasscount+=1
						end
					end
				end
			end
		end
	end
	
	for i=8,119 do
		memcpy(0x4+i*64,0x6004+i*64,56)
	end
	cls()
end

function makegdot()
	gdot={}
	cosa=cos(player.ang+.25)
	sina=sin(player.ang+.25)
	gdot.x=player.x+cosa*5
	gdot.y=player.y+sina*5
	gdot.z=2
	gdot.vx=cosa*4+rnd(2)-1
	gdot.vy=sina*4+rnd(2)-1
	gdot.vz=2+rnd(1)
	rand=flr(rnd(3))
	if (rand==0) then
		gdot.col=10
	elseif (rand==1) then
		gdot.col=3
	else
		gdot.col=11
	end
	add(gdots,gdot)
end

//update functions

function updatemenu()
	if (tstate=="menu") then
		if (btnp(0)) then
			clevel-=1
		end
		if (btnp(1)) then
			clevel+=1
		end
		clevel=mid(clevel,0,levelcount-1)
		if (btnp(4) or btnp(5)) then
			tstate="game"
		end
	end
end

function updatetransition()
	if (state~=tstate) then
		transition+=.06
		if (transition>1) then
			transition=1
			state=tstate
			if (state=="game") then
				loadlevel()
			end
		end
	else
		transition-=.06
		if (transition<0) then
			transition=0
		end
	end
end

function updateplayer()
	if (btn(0)) then
		player.ang+=.4*1/30
		started=true
	end
	if (btn(1)) then
		player.ang-=.4*1/30
		started=true
	end
	player.ang-=flr(player.ang)
	
	if (btn(2)) then
		player.speed+=.15
		started=true
	end
	if (btn(3)) then
		player.speed-=.15
		started=true
	end
	
	player.speed*=player.damp
	
	player.x+=cos(player.ang)*player.speed
	player.y+=sin(player.ang)*player.speed

	player.x=mid(player.x,0,127)
	player.y=mid(player.y,0,127)

	cutcount=0
	local rad=player.rad
	for i=flr(player.x)-rad,
	      -flr(-player.x)+rad do
	 for j=flr(player.y)-rad,
	      -flr(-player.y)+rad do
	  if (i>7 and i<120) then
	  	if (j>7 and j<120) then
					dx=i-player.x
					dy=j-player.y
					if (dx*dx+dy*dy<=rad*rad) then
						gcol=sget(i,j)
						if gcol==11 or gcol==gcolor2 then
							mowedpixels+=1
							cutcount+=1
							sset(i,j,3)
						end
					end
				end
			end
		end
	end
	
	if (mowedpixels==grasscount) then
		victory=true
	end
	
	tracktick+=1
	if (tracktick>2) then
		tracktick=1
		for i=-1,1 do
			gx=flr(player.x+cos(player.ang+.35*i)*4)
			gy=flr(player.y+sin(player.ang+.35*i)*4)
			if (gx>7 and gx<120) then
				if (gy>7 and gy<120) then
					gcol=sget(gx,gy)
					if gcol==11 or gcol==gcolor2 or gcol==3 or gcol==4 then
					 if (gcol==11 or gcol==gcolor2) then
					 	mowedpixels+=1
					 end
					 sset(gx,gy,2)
					end
				end
			end
		end
	end
	
	for i=1,min(4,cutcount) do
		makegdot()
	end

end

function updateguy()
	sina=sin(player.ang)
	cosa=cos(player.ang)
	psina=-cosa
	pcosa=sina
	
	guy.hx+=(player.x-cosa*(10-player.speed*3)-guy.hx)*.2
	guy.hy+=(player.y-sina*(10-player.speed*3)-4-guy.hy)*.2
	
	guy.nx+=(player.x-cosa*(10-player.speed*4)-guy.nx)*.25
	guy.ny+=(player.y-sina*(10-player.speed*4)-8-guy.ny)*.25
	
	kneex=cosa
	kneey=sina
	
	if (lstep) then
		guy.tfx1=player.x-cosa*10+pcosa*2
		guy.tfy1=player.y-sina*10+psina*2
	else
			guy.tfx2=player.x-cosa*10-pcosa*2
			guy.tfy2=player.y-sina*10-psina*2
	end
	if (steptimer==0) then
		if (lstep) then
			guy.ofx1=guy.fx1
			guy.ofy1=guy.fy1
			if (abs(guy.fx1-guy.tfx1)>=1 or
			    abs(guy.fy1-guy.tfy1)>=1) then
			 stepping=true 
			end
		else
			guy.ofx2=guy.fx2
			guy.ofy2=guy.fy2
				if (abs(guy.fx2-guy.tfx2)>1 or
			    abs(guy.fy2-guy.tfy2)>1) then
			 stepping=true 
			end
		end
	end
	
	
	if (stepping) then
		steptimer+=stepfreq
		local t=steptimer
		if (t>1) then
			t=1
			steptimer=1
		end
		t=1-(1-t)*(1-t)
		local stepval=0
		if (lstep) then
			guy.fx1=guy.ofx1+(guy.tfx1-guy.ofx1)*t
			guy.fy1=guy.ofy1+(guy.tfy1-guy.ofy1)*t
			stepval=sin(steptimer*.5)
			guy.fy1+=stepval*2
			kneex=cosa*stepval*(-2-2*abs(player.speed))
			kneey=sina*stepval*(-2-2*abs(player.speed))-stepval
		else
			guy.fx2=guy.ofx2+(guy.tfx2-guy.ofx2)*t
			guy.fy2=guy.ofy2+(guy.tfy2-guy.ofy2)*t
			stepval=sin(steptimer*.5)
			guy.fy2+=stepval*2
			kneex=cosa*stepval*(-2-2*abs(player.speed))
			kneey=sina*stepval*(-2-2*abs(player.speed))
		end
		
		guy.kx1=(guy.fx1*2+guy.hx)/3
		guy.ky1=(guy.fy1*2+guy.hy)/3
		guy.kx2=(guy.fx2*2+guy.hx)/3
		guy.ky2=(guy.fy2*2+guy.hy)/3
		if (stepping) then
			if (lstep) then
				guy.kx1+=kneex
				guy.ky1+=kneey
			else
				guy.kx2+=kneex
				guy.ky2+=kneey
			end
		end
		
		if (t==1) then
			stepping=false
			steptimer=0
			lstep=not lstep
		end
	end
end

function updatemowersound()
	mstarget=mid(cutcount/3,0,1)
	if (abs(primemspeed-mstarget)<mspeedrate) then
		primemspeed=mstarget
	else 
		primemspeed+=mspeedrate*sgn(mstarget-primemspeed)
	end
	mspeed+=(primemspeed-mspeed)*mspeedsmooth
	
	setsfxspeed(8,flr(minmowspeed+(maxmowspeed-minmowspeed)*(1-mspeed)))
end

function updategdots()
	for gdot in all(gdots) do
		gdot.vx*=.85
		gdot.vy*=.85
		gdot.vz-=.15
		gdot.vz*=.93
		
		gdot.ox=gdot.x
		gdot.oy=gdot.y
		gdot.oz=gdot.z
		
		gdot.x+=gdot.vx
		gdot.y+=gdot.vy
		gdot.z+=gdot.vz
		
		if (gdot.z<0) then
			del(gdots,gdot)
		end
	end
end

function updatetimer()
	if (started and not victory) then
		timer+=1/30
	end
end


//drawing functions

function cprint(str,y,col)
	local x=64-#str*2
	print(str,x,y,col)
end

function levelbutton(x,y,level)
	
	if (level==clevel) then
		if ((time()*10)%1<.5) then
			pal(3,11)
			pal(1,13)
			pal(5,6)
		else
			pal(3,10)
			pal(1,13)
			pal(5,7)
		end
	else
		pal()
	end
	
	rect(x-8,y-8,x+7,y+7,5)
	
	for i=1,14 do
		for j=1,14 do
			if (mget(i+16*level,j)==1) then
				pset(x-8+i,y-8+j,3)
			else
				pset(x-8+i,y-8+j,1)
			end
		end
	end
	
	pal()
end

function drawmenu()
	cls()
	cprint("zen-garden mowerman",11,3)
	cprint("zen-garden mowerman",10,11)
	line(26,17,100,17,11)
	cprint("(a game by 2darray)",21,3)
	cprint("(audio by dvgmusic)",29,13)
	
	cprint("⬅️ ➡️  ",46,3)
	cprint("⬅️ ➡️  ",47,3)
	if ((time()*1.1+.5)%1>.5) then
		cprint("   ➡️ ",45,11)
		cprint("⬅️    ",46,11)
	else
		cprint("⬅️    ",45,11)
		cprint("   ➡️ ",46,11)
	end
	
	cprint(levelnames[clevel],76,5)
	
	cprint("press 🅾️ or ❎ to start  ",86,5)
	cprint("press 🅾️ or ❎ to start  ",87,5)
	if (time()%1>.5) then
		cprint("press 🅾️ or ❎ to start  ",85,6)
	else
		cprint("press    or    to start",85,6)	
		cprint("      🅾️    ❎           ",86,6)
	end
	
	cprint("world record holder:",100,13)
	line(23,107,102,107,13)
	cprint(records[clevel].name,111,9)
	cprint(records[clevel].score,118,10)
	
	for i=0,levelcount-1 do
		local sx=64-10*(levelcount-1)
		levelbutton(sx+20*i,64,i)
	end
end

function applytransition()
	pal()
	if (transition>0) then
		for i=0,15 do
			if (i<=6 or transition*20>i) then
				pal(i,i*(1-transition),1)
			end
		end
	end
end

function drawbg()
	rectfill(0,0,127,127,1)
	
	for i=1,15 do
		for j=1,15 do
			if (mget(i+clevel*16,j)!=0) then
				circfill(i*8+4,j*8+4,9,13)
			end
		end
	end
	
	pal()
	//pal(11,9)
	//pal(3,4)
	spr(17,8,8,14,14)
end

function drawhud()
	local t=1-mowedpixels/grasscount
	local y=11+106*t
	if mowedpixels<grasscount then
		y=max(y,12)
	end
	local col=7
	if cutcount>0 then
		if flasher then
			flasher=false
			col=14
		else
			flasher=true
			col=9
		end
	end
	rectfill(122,y,126,117,col)
	rect(122,10,126,117,7)
	
	local minutes=flr(timer/60)
	print(minutes.."",1,1)
	local tx=5
	if (minutes>9) tx+=4
	if (minutes>99) tx+=4
	print(":",tx-1,1)
	seconds=flr(timer%60)
	tx2=tx+9
	if (seconds<10) then
		seconds="0"..seconds
	end
	print(""..seconds,tx+2,1)
	
	print(".",tx2,1)
	
	print(flr(10*(timer-flr(timer))).."",tx2+3,1)
	
	if (victory) then
		cprint("good job, mowerman",57,6)
		cprint("good job, mowerman",56,7)
		cprint("pause/enter to go back",72,6)
	end
	
	//print(ttext,0,0)
end

function drawplayer()
	
	for i=1,4 do
		local ang=player.ang+.125+.25*i
		local cosa=cos(ang)*5
		cosa=-sgn(cosa)*flr(-sgn(cosa)*cosa)
		local sina=sin(ang)*5
		sina=-sgn(sina)*flr(-sgn(sina)*sina)
		if abs(cos(player.ang))>.6 then
			circfill(player.x+cosa,
			         player.y+sina,
			         1,0)
		else
			line(player.x+cosa,
								player.y+sina-1,
								player.x+cosa,
								player.y+sina+1,0)
		end
	end
	circfill(player.x,
	         player.y,
	         4,0)
	circfill(player.x,
	         player.y-1,
	         4,8)
	for i=-2,2 do
		pset(player.x+cos(player.ang+.03*i)*4,
		     player.y-1+sin(player.ang+.03*i)*4,
		     9)
	end
	
	circfill(player.x,
	         player.y-2,
	         3,5)
	         
	local sina=0
	local cosa=0
	
	for i=-2,2 do
		sina=sin(player.ang+.25+.025*i)
		cosa=cos(player.ang+.25+.025*i)
		line(player.x+cosa*4,
		     player.y-2+sina*4,
		     player.x+cosa*5,
		     player.y-2+sina*5,5)
	end
	
	circ(player.x,player.y-3,2,6)
	         
	cosa=cos(player.ang+.58)
	sina=sin(player.ang+.58)
	local cosa2=cos(player.ang+.75)
	local sina2=sin(player.ang+.75)
	
	local x1=player.x+cosa*7
	local y1=player.y-5+sina*7
	line(x1,y1,
	     player.x+cosa2*3,
	     player.y-2+sina2*3,
	     5)
	line(x1,y1-1,
	     player.x+cosa2*3,
	     player.y-3+sina2*3,
	     6)
	     
	cosa=cos(player.ang+.42)
	sina=sin(player.ang+.42)
	cosa2=cos(player.ang+.25)
	sina2=sin(player.ang+.25)
	
	local x2=player.x+cosa*7
	local y2=player.y-5+sina*7
	line(x2,y2,
	     player.x+cosa2*3,
	     player.y-2+sina2*3,
	     5)
		line(x2,y2-1,
	     player.x+cosa2*3,
	     player.y-3+sina2*3,
	     6)
	     
	line(x1,y1,x2,y2,5)
	line(x1,y1-1,x2,y2-1,6)
end

function drawguy(tophalf)
	cosa=cos(player.ang)
	sina=sin(player.ang)
	pcosa=-sina
	psina=cosa
	
	for j=0,2 do
	
		local col=0
		local i=0
		if (j==0) then
			col=5
			i=-1
		elseif (j==1) then
			i=1
			col=5
		end
		
		if not tophalf then
			line(guy.fx1+i,guy.fy1,
			     guy.kx1+i,guy.ky1,col)
			line(guy.fx2+i,guy.fy2,
			     guy.kx2+i,guy.ky2,col)
			     
			line(guy.fx1+i,guy.fy1,
			     guy.fx1+cosa+i,guy.fy1,col)
			line(guy.fx2+i,guy.fy2,
			     guy.fx2+cosa+i,guy.fy2,col)
			
			line(guy.kx1+i,guy.ky1,
			     guy.hx+i,guy.hy,col)
			line(guy.kx2+i,guy.ky2,
			     guy.hx+i,guy.hy,col)
		else
			line(guy.hx+i,guy.hy,
								guy.nx+i,guy.ny,col)
								
			ax=player.x-cosa*5+pcosa*2.5
			ay=player.y-sina*5+psina*2.5-6
			line(guy.nx+i,guy.ny,ax+i,ay,col)
		
			ax=player.x-cosa*5-pcosa*2.5
			ay=player.y-sina*5-psina*2.5-6
			line(guy.nx+i,guy.ny,ax+i,ay,col)
							
							
			circfill(guy.nx+i+cosa*player.speed,
			         guy.ny+sina*player.speed-2,
			         2,col)
		end
	end
end

function drawgdots(sort)
		for gdot in all(gdots) do
			if sgn(gdot.y-player.y)==sort then
				local col=gdot.col
				if (i==1) then
					col=2
				end
				line(gdot.x,gdot.y-gdot.z,
				     gdot.ox,gdot.oy-gdot.oz,
				     col)
			end
	end
end

function _update()
	updatetransition()
	if (state=="menu") then
		updatemenu()
	elseif (state=="game") then
		updateplayer()
		updateguy()
		updatemowersound()
		updategdots()
		updatetimer()
	end
end

function _draw()
	if (state=="menu") then
		drawmenu()
	elseif (state=="game") then
		drawbg()
		drawhud()
		drawgdots(-1)
		drawguy(false)
		drawplayer()
		drawguy(true)
		drawgdots(1)
	
		print(mowedpixels.."/"..grasscount, 40,1)
	end
	
	applytransition()
end