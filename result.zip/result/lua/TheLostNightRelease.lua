function _init()
menuitem(1,"clear game", _af)
_hb,_bt,_l2,_a=0,2492,true,0.0058
debug,parts,c0ls,_g5,_b={},{},{},{},{}
cartdata"the_lost_night" _c=split"0,0,0,0,112,48"
battle_x,battle_y,battle_w,_d=19,78,90,47
_e=split"-1,1,0,0,1,1,-1,-1" _f=split"0,0,-1,1,-1,1,1,-1" _g=_kx[[
31|96|16|22|-7
%64|96|15|21|-6
%47|96|17|21|-8
%79|96|9|25|-5
%88|96|07|23|-6
%104|96|8|24|-8
]]
_bk,_7,_h=_kz(),_kz(),_kz()
_i=_kx[[
1|1|1|3|3|3|5|5|5|5|5|5|7|7|7|7|7|7|9|9|9|9|9|9%
1|1|1|3|3|3|4|4|5|5|6|6|7|7|8|8|9|9|10|10|11|11|12|12%
1|1|1|3|3|3|4|4|5|5|6|6|7|7|8|8|9|9|10|10|11|11|12|12%
1|5|5|5|5|7|7|7|7|7|7|10|10|10|10|10|10|10|16|16|16|16|24|24%
1|1|1|2|2|2|3|3|3|3|3|3|4|4|4|4|5|5|5|5|6|6|6|6%
1|1|1|9|9|9|9|9|9|9|9|9|9|9|9|9|9|9|9|9|9|9|20|20
]]
_j=_kx[[
1|2|2|3|3|3|3|3|3|3|3|3|4|4|4|4|5|5|5|5|5|5|6|6%
1|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|6|6|6|6%
1|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|5|6|6|6|6%
1|5|5|2|2|2|2|2|2|2|2|2|2|2|2|2|2|2|2|2|2|2|2|2%
1|2|2|2|2|2|2|2|2|2|2|2|3|3|3|3|3|3|3|3|3|3|4|4%
1|2|2|3|3|5|5|5|5|7|5|5|5|5|5|6|6|6|6|7|7|8|8|8
]]
_k=split".06,.075,.09,.15,.12"
_l=split"1,2,3,4" _m=split"1,2,3,4,5" _n=split".04,.055,.065,.08,.1" _o=split"1,1.2,1.4,1.6,1.8" _ar()
_a3()
end
function _update60()
_p=time()
_q=sin(_p/2)/2.5
_r=cos(_p)*.2
_x()
_mb()
_le()
end
function _draw()
_w()
clip()
camera()
_l7()
_lx()
for i=0,15 do
pal(i,i+128,1)
end
pal(137,9,1)
clip()
cursor(2,2)
color(8)
for _ao in all(debug) do
print(_ao)
end
end
function _s()
_az()
_au()
_ad()
_9,_cq,_v=_c
_t()
_w,_x=_bb,_ba
music(-1,1000)
_l0()
music(10)
end
function _t(_u)
_y={}
local _z,_0,sx,sy,_1,_2=unpack(_9)
_cd()
for y=_0,_2+_0-1 do
for x=_z,_1+_z-1 do
local _3,_4=mget(x,y)
local _4=fget(_3,1)
local _x,_y=(x-_z)*8+sx,(y-_0)*8+sy
if _3==119 then
_5=v2:_k0(_x,_y-4)
end
if _4 then
_jk(_x,_y)
end
end
end
local _6
if _v then
_6=split(_v[2][5],"|")
end
if _6 then
local x,y=unpack(_6)
_5=v2:_k0(x*8,y*8)
end
_be()
_7=_bk*8
_bd()
_d4()
_ak()
_an()
_ax()
if _u then return end
_ex()
end
function _8()
_b=_cp
_ed(_v)
_9=split(_v[2][1],"|")
_ab=_5+0
_t()
_l0()
end
function _aa()
local x,y=_jm(_bt)
local _ac={
_jo(x,y+1),_b0,_fs,max_hp,acc_lvl,pwr_lvl,rate_lvl,size_lvl,_ah
}
for i=1,#_ac do
dset(i-1,_ac[i])
end
local i=10
for _jq in all(_av) do
dset(i,_jq)
i+=1
end
local i=34
for _bu in all(_ai) do
dset(i,_bu)
i+=1
end
end
function _ad()
local _ae=0
local _ac={
2492,
10,
45,
10,
1,
1,
1,
1,
1
}
for i=1,9 do
local _ag=dget(i-1)
if _ag != 0 then
_ac[i]=_ag
end
end
_ae,_b0,_fs,max_hp,acc_lvl,pwr_lvl,rate_lvl,size_lvl,_ah=unpack(_ac)
local x,y=_jm(_ae)
_5=v2:_k0(x,y)
_5*=8
for i=10,33 do
local _ag=dget(i)
if _ag != 0 then
add(_av,_ag)
end
end
_ai={}
for i=34,64 do
local _ag=dget(i)
if _ag != 0 then
add(_ai,_ag)
end
end
for i in all(_ai) do
_a0[i][2][4]=true
end
_aj=#_av+1
end
function _af()
sfx"52" for i=0,64 do
dset(i,0)
end
end
function _ak()
_al={}
_am=split[[wELCOME BACK MY CHILD.,,dID YOU ENJOY YOURSELF
,AS ONE OF THEM?
,...
,cANDY?
,sURE i'LL HAVE SOME.
,,thanks for playing!
]]
local _ae=[[
61|20|⌂ mY hOME.
%60|23|aaghh!◆... SORRY. i◆MISTOOK YOU FOR A◆HORRIBLE CHILD.◆tAKE THESE.◆dON'T FOLOW ME.
%53|27|hAVE YOU BEEN TO PEPE'S◆PLAZA? THERE IS A NICE◆LADY THAT MAKES◆AN EXCELENT EARTH SOUP!.
%55|34|iF YOU GET KNOCKED OUT◆YOU'LL RETURN TO THE◆LAST VENDING MACHINE◆YOU USED.
%62|38|pUMPKIN hOUSE lOOKOUT->
%57|41|tHE PUMPKIN HOUSE IS◆SCARY,YOU CAN USE THE◆LOOKOUT TO APPRICIATE◆THE ARCHITECTURE THOUGH.
%58|45|wATER.◆IF YOU CAN'T SWIM◆YOU CAN'T CROSS OVER
%45|42|"pEPE pLAZA" ◆A PLACE WHERE EVERYONE◆IS LATE.
%40|41|i WAS LATE.◆SHE'S LATE TOO i GUESS.
%42|35|tHEY SAY cHIPS CAN◆RAISE YOUR HEALTH◆PERMANENTLY.->
%34|37|mY BOY CHUBS LOVED MY◆EARTH SOUP. hE WAS A◆WEIRD ONE.i REMEMBER◆HIM ON NIGHTS LIKE THIS◆hAVE SOME soup.
%39|24|iF YOU'RE NOT FEELIG◆GREAT GET SOME TEA AT A◆VENDING MACHINE.
%36|29|tHE SNACKS IN VENDING◆MACHINES MAKE ME FEEL◆STRONGER AND FASTER.◆mOM DISAGREES
%33|24|i'M TOO TIRED◆TO MOVE. gET ME◆SOME eARTH sOUP◆AND I'LL LET YOU PASS.
%36|21|wHAT A GREAT CHICKEN!
%38|19|cHICKENS FRIGHTEN ME.
%43|26|iT'S LOCKED.◆tHE KEY-HOLE IS SHAPED◆LIKE A BONE.◆THERE'S A DOG ON◆THE OTHER SIDE!
%43|23|bARK!◆yOU PET THE DOG
%21|29|fIND MY DOG!
%24|8|i HOPE TONIGHT◆THE GHOSTS WILL TAKE ME.
%30|9|"fISHING IS◆NOT VERY FUN" ◆◆tHAT'S A QUOTE FROM◆A BOOK I WAS READING.◆I LOST IT THO 😐
%29|10|fROG RIVER ->
%14|11|i FEEL SOMETHING'S OFF◆ABOUT YOU.
%2|5|tHE GREAT PUMPKIN IS ANGRY.◆i CAN FEEL IT.
%2|5|sOMEONE IS LOOKING FOR◆YOU.◆◆aRE YOU LOOKING BACK?
%5|4|☉insight☉ CORNER.
%5|1|a BOOK ABOUT FISHING◆◆eww!! IT'S WET.
%6|14|a HORNED kEY◆WONDER WHO DROPPED IT?
%34|1|yOU LOSE YOURSELF IN◆THE STAR PATTERNED◆BOOTS.
%38|6|we'll be together◆again!♥
%42|4|tHE BRIDGE COLLAPSED◆iM FINE ON THIS◆SIDE THO
%23|35|a BOULDER IS IN YOUR WAY.◆MAYBE YOU CAN BLAST IT◆WITH EXPLOSIVES.
%19|42|aN OLD FURNACE◆"tORTILLA kING" ◆lOOKS A LITTLE OLD BUT◆IT SHOULD STILL WORK.◆
%29|42|aS THE NIGHT PASSES◆THE SPIRITS GET◆STRONGER.
%22|46|...hMM, mUSHROOMS.◆THE SMELL MAKES YOU◆DIZZY
%9|19|i SAW A KEY◆UP THERE.
%3|23|hAhAhA.◆tHAT'S sAD.
%1|23|aND THEN lUISA SAID◆"lOU, I'M LEAVING YOU" %10|33|yO nERD!◆gOT SOME SHROOMS?
%1|38|sMALLEST ONE.◆tAKE MY POWER.◆bE WEIGHTLESS
%13|44|tHE COYOTE STATUE'S EYES◆SHINE.◆"A FEATHERED OFFERING" %7|42|aN OLD hORNED DOOR
%79|1|wE USED TO DRAMA
%89|3|i DON'T HAVE ILLEGAL◆FIREWORKS HIDDEN IN◆MY BACKYARD!
%86|21|i LOVE SHOPPING!
%82|22|wE USED TO DRAMA
%89|28|yOU'RE DOING GREAT!◆◆wHA?  nO◆I'M TALKING TO MYSELF.
%107|5|mAUSOLEUM
%97|1|a pALOMA◆lIGHTING THIS SHOULD BE◆A blast!
%110|43|wE NEVER RETURN◆FROM THE pUMPKIN hOUSE.
%50|4|bOOK HOUSE
%76|19|wEENIE RACE!◆EVERY DAY◆ IN PEPE PLAZA
%74|30|yO! i'VE ALWAYS WANTED◆TO MAKE TORTILLAS◆BY HAND.◆i'D SET UP IN THE PLAZA,◆AND SLOWLY CREATE DEMAND◆AND BOOM!◆JACK-UP THE PRICE.◆HNNN... CAPITALISM♥
%71|25|nEED CANDY REEEEAL BAD◆:SWEATS:
%76|26|aN OLD RUSTED KEY.◆kINDA' LOOKS LIKE A◆SKULL.◆IT'S A sPOO KEY!
%66|25|a bone SHAPED KEY.
%99|28|i'M NOT SELLING CANDY
%108|23|bEING CLOSER MAEKS◆TEH MIND SL...P AWY..
%109|29|sPOOKY gATE
%93|42|dO NOT LET FENCES STOP◆YOU, YOUNG ONE.
%84|37|I..DON'T FEEL TOO GOOD,◆MY FEET ARE ROOTED TO◆THE EARTH
%75|43|pUMPKIN HOUSE◆yOU MADE IT BACK◆COME IN
]]
if _v then
_ae=_v[2][2]
end
_ae=_kx(_ae)
for t in all(_ae) do
local x,y,_ao=unpack(t)
_ji(
x,y,_ao,_al
)
if not _jv(nil,_jo(x,y)) then
_jk(x*8,y*8)
end
end
end
function _an()
_ap={}
_aq={}
local _ae=[[
53|27|1
%60|23|5|
%36|29|2|
%39|24|8|
%21|29|3|
%33|24|04
%34|37|05
%57|41|1|
%42|35|7
%55|34|6
%29|42|8|
%40|41|1
%24|8|2
%10|33|03
%30|09|6|
%2|5|5
%14|11|7|
%9|19|1|
%1|23|6
%3|23|2|
%38|19|5|
%38|6|7
%42|4|4|
%99|28|4|
%86|21|8
%89|28|3
%82|22|1
%89|3|2|
%71|25|6|
%84|37|1|
%110|43|3|
%108|23|7|
%22|46|022
%13|44|024
%36|21|023
%5|1|021
%7|42|016
%6|14|017
%1|38|010
%23|35|027
%19|42|031
%74|30|07
%76|26|029
%109|29|028
%93|42|012
%97|1|030
%66|25|026
%43|23|018
%43|26|025
%34|1|019
%79|1|8|
%-7|12|011|
]]
if _v then
_ae=_v[2][3]
end
_ae=_kx(_ae)
for c in all(_ae) do
_ef(unpack(c))
end
end
function _ar()
_as={}
local _ae=[[
60$18$
112|0|24|24|10|10
>
7|9|uMM...◆wHY ARE YOU HERE?
%10|5|wHY DO PEOPLE◆KEEP BARGING IN?◆I EVEN PUT UP A SIGN◆
%12|7|"tHE ART OF ART" ◆... OK
>
7|9|1
%10|5|4|false
%7|8|14
%10|8|14|false
%9|8|13
%5|4|15
%12|7|15
<60$30$
123|0|45|25|5|10
>
9|6|tHAT GUY...◆gIVES ME THE CREEPS
%6|6|pEOPLE THINK IM CREEPY◆😐
>
9|6|2|false
%6|6|4
>
8|5|5|0|0
<55$27$
112|10|0|40|16|6
>
13|7|tHANKS FOR COMING!◆... NOW LEAVE.
>
13|7|7|false
%4|8|13
%8|8|13
%12|6|14|true
>
10|7|5|0|1
<42$27$
112|0|24|24|10|10
>
10|5|wHERE DID ALL OUR◆FURNNITURE GO?
%7|8|mY TEACHER SAYS GHOSTS◆AREN'T REAL.◆bUT I'VE SEEN SOME SHIT.◆😐
>
10|5|7|false
%7|8|3
<36$23$
112|24|8|32|15|8
>
14|7|tHE TOWN◆WAS BUILT AROUND THE◆OLD pUMPKIN HOUSE.◆gIVEN THAT NAME BECAUSE◆ONCE A YEAR, STRANGE◆PUMPKINS WITH FACES◆GROW AROUND IT.
%4|8|i FEEL WEIRD PRESENCES◆WHEN I'M OUTSIDE.
>
14|7|6|false
%4|8|1
%15|11|20
<45$33$
118|16|24|40|10|7
>
8|7|sHE THINKS SPIRITS◆PASS THROUGH THE TOWN◆DRESSED AS CHILDERN◆ON NIGHTS LIKE THIS.
%6|7|i WAS TEN WHEN I CROSSED◆THE RIVER, JUMPED THE◆FENCE, AND PEEKED◆INTO pUMPKIN HOUSE.
>
8|7|6|
%6|7|7
<35$42$
113|32|8|0|14|16
>
6|7|fEELING PRESSURE◆IN THE ROOM.◆
>
6|7|3
%3|4|20
%4|4|20
%5|4|20
%6|4|20
%7|4|20
%8|4|20
%9|4|20
%10|4|20
%11|4|20
%2|11|20
%3|11|20
%4|11|20
%5|11|20
%6|11|20
%8|11|20
%9|11|20
%10|11|20
%11|11|20
%7|11|15
>
8|12|5|0|1
%5|9|1|1◆0◆2|.6
%12|3|1◆5|8◆0◆2|.5
%12|2|2|2|1
>
2|14
>
4|1|36|39
<37$39$
113|32|8|0|14|16
>
14|10|tHE HOUSE FEELS◆DIFFERENT
>
14|10|3|
%3|4|20
%4|4|20
%5|4|20
%6|4|20
%7|4|20
%8|4|20
%9|4|20
%10|4|20
%11|4|20
%2|11|20
%3|11|20
%4|11|20
%5|11|20
%6|11|20
%8|11|20
%9|11|20
%10|11|20
%11|11|20
%7|11|15
>
8|1|1|0|0
>
4|2
>
2|15|35|42
<55$40$
112|16|45|35|5|8
>
8|6|oNLY THE WIND LIVES HERE.
>
8|6|13
%6|9|14
%9|9|14|true
>
8|7|1|0|1
<22$23$
112|16|45|35|5|8
>
7|8|i SAW A DOG-PERSON◆ROAMING THE WASTELANDS.
>
8|6|13
%7|6|13
%7|8|2
<18$20$
112|16|45|35|5|8
>
9|6|wHEN i WAS A LAD◆kIDS WOULD SOMETIMES◆DISSAPPEAR.◆tHAT'S WHY i'VE NEVER◆LEFT THIS HOUSE.◆sORRY ABOUT THE SMELL.
>
8|8|15
%9|8|15
%9|6|4|true
<28$19$
118|16|24|40|10|7
>
4|7|oUR FAMILY sTOPPED◆A DINER ROBBERY ONCE.◆a WHOMPING BUFFET◆IF YOU WILL.
>
4|7|6
%6|9|20
%6|8|20
%8|8|14
<25$7$
123|0|43|25|5|10
>
9|7|bORK!bORK!◆(fINALLY MY OWN PLACE.)◆
>
9|7|18
<2$2$
118|16|24|40|10|7
>
9|7|gETTING A TASTE OF LIFE?
>
9|7|24
%8|8|27
%9|9|27
<0$28$
112|16|45|35|5|8
>
7|6|gOT MY BUTT KICKED◆AT A BUFFET...◆tWICE.
>
7|6|4
<41$0$
112|0|24|24|10|10
>
10|4|fROG RIVER?◆mORE LIKE ROCK RIVER◆◆aM i RIGHT?
>
10|4|5|
>
7|6|4|0|1
<68$22$
112|24|8|32|15|8
>
13|8|mY TWIN WENT THERE◆SAYING"HE" WAS CALLING◆
>
13|8|1|
<109$5$
112|0|24|24|10|10
>
8|8|sAVE US?
>
8|8|22
%6|10|6
%10|10|5|
<82$26$
112|10|0|40|16|6
>
8|8|LLEGAS AL FINAL◆Y DESPUES QUE?
>
9|8|23
<1$42$
113|32|8|0|14|16
>
5|6|yOU SMELL LIKE◆MUSHROOMS
>
2|6|24|
%5|6|24
%6|6|20
%7|6|20
%8|6|20
%9|6|20
%10|6|20
%11|6|20
%12|6|20
%2|11|20
%3|11|20
%4|11|20
%5|11|20
%6|11|20
>
8|8|2◆1◆4◆3|7◆4◆6◆8◆3◆5|1
>
2|14
>
4|1|4|38
<4$38$
113|32|8|0|14|16
>
5|6|yOU STILL SMELL LIKE◆MUSHROOMS
>
2|6|24|
%5|6|24
%6|6|20
%7|6|20
%8|6|20
%9|6|20
%10|6|20
%11|6|20
%12|6|20
%2|11|20
%3|11|20
%4|11|20
%5|11|20
%6|11|20
>
8|12|2|0|0
>
4|2
>
2|15|1|42
<9$30$
113|32|8|0|14|16
>
11|3|dON'T MIND ME◆I'M JUST CHILLIN
>
2|7|20
%4|8|20
%6|7|20
%8|8|20
%10|7|20
%12|8|20
%4|4|20
%7|11|20
%11|3|23
>
8|12|2|0|0
>
2|14
>
4|1|7|27
<7$27$
113|32|8|0|14|16
>
11|3|jESUS! GET GOING◆WILL YA?
>
2|7|20
%4|8|20
%6|7|20
%8|8|20
%10|7|20
%12|8|20
%4|4|20
%7|11|20
%11|3|23
>
8|12|2|0|0
>
4|2
>
2|15|9|30
<62$45$
112|24|8|32|15|8
>
3|6|tHIS IS THE PATH◆OF MOBILITY, LITTLE ONE
>
12|11|20
%12|10|20
%12|9|20
%12|8|20
%12|7|20
%6|7|20
%5|8|20
%3|6|9
%3|10|20
>
8|12|2|0|0
>
15|10
>
2|11|36|0
<36$0$
112|24|8|32|15|8
>
0|0|
>
12|11|20
%12|10|20
%12|9|20
%12|8|20
%12|7|20
%6|7|20
%5|8|20
%3|10|20
>
8|12|2|0|0
>
2|10
>
15|11|62|45
<51$3$
113|32|8|0|14|16
>
6|2|bOOKS?◆wE GOT 'EM
>
6|2|5|
%6|3|13
%4|4|15
%4|6|15
%4|8|15
%4|10|15
%8|4|15
%8|6|15
%8|8|15
%8|10|15
%12|4|15
%12|6|15
%12|8|15
%12|10|15
>
8|12|2◆4|0◆1◆2◆3|1
>
4|2
>
2|15|54|9
<54$9$
113|32|8|0|14|16
>
6|2|bOOKS?◆wE GOT 'EM
>
6|2|5|
%6|3|13
%4|4|15
%4|6|15
%4|8|15
%4|10|15
%8|4|15
%8|6|15
%8|8|15
%8|10|15
%12|4|15
%12|6|15
%12|8|15
%12|10|15
>
8|12|2|0|0
>
2|14
>
4|1|51|3
<84$22$
113|32|8|0|14|16
>
0|0|
>
2|9|20
%3|9|20
%4|9|20
%5|9|20
%6|9|20
%7|9|20
%8|9|20
%9|9|20
%10|9|20
>
8|12|2|0|0
>
4|2
>
2|15|94|30
<94$30$
113|32|8|0|14|16
>
0|0|
>
2|9|20
%3|9|20
%4|9|20
%5|9|20
%6|9|20
%7|9|20
%8|9|20
%9|9|20
%10|9|20
>
8|12|2|0|0
>
2|14
>
4|1|84|22
<105$41$
112|24|8|32|15|8
>
0|0|
>
4|9|27
>
0|0|0|0|0
>
15|10
>
2|11|93|37
<93$37$
112|24|8|32|15|8
>
0|0|
>
4|9|27
>
0|0|0|0|0
>
2|10
>
15|11|105|41
<22$39$
112|24|8|32|15|8
>
0|0|0
>
3|7|22
%5|8|22|
%12|9|22
>
5|6|4|0|1
>
15|10
>
2|11|18|39
<18$39$
112|24|8|32|15|8
>
0|0|0
>
3|7|22
%5|8|22|
%12|9|22
>
0|0|0|0|0
>
2|10
>
15|11|22|39
<73$41$
113|32|8|0|14|16
>
4|3|yOU'RE BACK◆LET'S GO HOME.
>
4|3|11
%3|6|20
%4|6|20
%5|6|20
%6|6|20
%7|6|20
%8|6|20
%9|6|20
%8|4|20
%8|3|20
%8|2|20
%8|9|13
%5|11|20
%4|11|20
%3|11|20
%2|11|20
%11|11|20
%12|11|20
%13|11|20
%14|11|20
%10|11|15
%6|11|15
>
10|4|6|0◆3◆4|1
%8|11|1◆2◆3◆4◆5◆6|0◆2◆3◆4◆5◆6|1
>
2|14
>
4|1|-10|12
]]
for c in all(split(_ae,"<")) do
local x,y,_at=unpack(split(c,"$"))
_jh(
x,y,_at
)
end
end
function _au()
_av={}
_aw={}
local _ae=_kx[[
60|23|gramps◆yOU GOT 45 SWEETS!%
34|1|dash◆dASH BY PRESSING 🅾️%
01|38|water◆wALK ON WATER%
93|42|fence◆pASS THROUGH THIN FENCES%
43|23|dog◆tHEY FOLOW YOU NOW%
34|37|key1◆yOU GOT EARTH SOUP%
33|24|gate1◆THE GUY FADED. WTF?◆key1%
22|46|key2◆yOU GOT MUSHROOMS%
10|33|gate2◆i'M GONNA TRIP◆key2%
66|25|key4◆gOT BONE KEY%
43|26|gate4◆cLOSER TO DOG◆key4%
97|01|key5◆GOT AN EXPLOSIVE%
23|35|gate5◆bOOM!◆key5%
19|42|key6◆fURNACE ACQUIRED%
74|30|gate6◆hEHE I''LL BE RICH◆key6%
76|26|key7◆GOT THE SKULL KEY%
109|29|gate7◆tHE JAW UNHINGES◆key7%
06|14|key9◆gOT THE HORNED KEY%
07|42|gate9◆iT CLICKS OPEN◆key9%
36|21|key10◆yOU GOT A CHICKEN%
13|44|gate10◆tHE STATUE CRUMBLES◆key10%
05|01|key11◆gOT A WET BOOK%
30|09|gate11◆tHANKS! yOU FOUND IT◆key11]]
for t in all(_ae) do
local x,y,id=unpack(t)
_ji(
x,y,id,_aw
)
end
end
function _ax()
_ay={}
local _ae=[[
38|28|5|0|.9
%37|29|1◆5|0◆3◆2|.1
%59|37|1◆5|0◆2|0.8
%43|42|1◆5|0◆2◆1◆3◆4|.4
%51|41|1◆5|0◆3|.7
%24|26|1◆5◆2|0◆1◆2◆3◆4|.5
%27|38|1◆2|0◆2◆4|.9
%20|9|1◆2◆5|0◆2◆1◆3◆5|.8
%28|6|1◆2◆5|0|.9
%6|3|1◆2|0◆3|1
%13|8|5◆2|0◆1◆3|.9
%6|17|3|0◆2|1
%13|23|1◆2◆3◆5|0◆1◆5|.3
%4|27|2|0◆4◆6◆7|.3
%13|39|1◆3|0◆7|.6
%5|35|2◆5|0◆6|.6
%6|46|4|0|.5
%23|43|4◆3|0◆2|.7
%40|12|1◆2◆5|0◆4◆1|.5
%51|18|5|0◆1◆2|.9
%59|7|4|0◆7|1
%40|17|1|0|1
%65|5|3|0|1
%74|10|1◆2◆3◆4◆5|0◆3◆4◆8◆1◆7|.8
%70|19|2◆4|0◆2|.9
%68|26|1◆2◆3◆4◆5|0◆2◆4◆6|.8
%88|5|1◆2◆3◆4◆5|0|1
%99|19|4|0|1
%102|1|1◆3◆4|0◆7◆6|.8
%102|11|5◆2|0◆6◆4|.6
%107|25|1◆2◆3◆4◆5|0◆4◆7|.7
%87|43|4◆1◆3|0◆1◆2|1
%85|45|4◆2◆5|0◆1◆2◆4◆3|1
%109|39|4◆5◆2|0◆4◆3◆2|1
%73|39|6|0|1
%44|10|1◆5|0◆2|.8
]]
if _v then
_ae=_v[2][4]
end
_ae=_kx(_ae)
for spwn in all(_ae) do
_eu(unpack(spwn))
end
end
function _az()
_a0={}
local _a1=[[hp tea◆1◆63
,chips◆10◆62
,soda◆10◆61
,bacon◆10◆60
,tkyk◆15◆59
,pizza◆15◆58
,pop◆20◆57
]]
_a2=split(_a1)
local _ae=_kx[[
45|36|2
%20|1|2
%101|37|2
%99|24|2
%80|01|2
%56|36|3
%06|19|3
%80|36|3
%52|21|3
%33|28|4
%19|44|4
%87|27|4
%65|45|4
%27|20|5
%51|10|5
%20|39|5
%110|18|5
%26|43|6
%97|08|6
%107|44|6
%78|26|6
%36|38|7
%27|02|7
%32|38|7
]]
for c in all(_ae) do
local x,y,i=unpack(c)
_ji(
x,y,_a2[i],_a0
)
end
end
function _a3()
_a6=.5
_mh()
_x=_a4
_w=_a5
music(13)
end
function _a4()
if btnp(❎) then
_s()
end
end
function _a5()
cls()
_mk()
local x=25
local y=30
circfill(x+38,y+23+_ki(),30,13)
sspr(0,96,31,24,x,y+_ki(),62,48)
y+=66
local _ao="❎start game" x=_ku(_ao)
print(_ao,x-4,y,14)
_ca("an rpg by,@eljovenpaul,@afk_mario",y+10,13)
end
function _a7()
_w=_a9
_x=_a8
_mh()
music(-1,1000)
_l0()
music(8,100)
end
function _a8()
if btnp(❎) or btnp(🅾️) then
_a3()
end
end
function _a9()
_mk()
_ca(
"game over,press ❎ to continue",60+_ki(),14
)
end
function _ba()
_be()
_ce()
if not _cq then
_cv()
_d5()
_fe()
end
end
function _bb()
cls()
_bd()
if not _v then
rect(_bi.x,_bi.y+4,_bj.x+1,_bj.y+5,14)
end
map(unpack(_9))
_lf()
_ei()
_eb()
_db()
_gc()
_jl()
end
function _bc()
local b = _bk*8
local c = _7-b
if c:_k8() > 1 then
_7-=c:_k9()*8
camera(_7.x,_7.y)
else
_ex()
_7=b
_x=_ba
camera(_7.x,_7.y)
end
end
function _bd()
_7+=_h
camera(_7.x,_7.y)
end
function _be(_bf)
local _z,_0,sx,sy,_1,_2=unpack(_9)
local _bh=_bk
_bi=v2:_k0(sx,sy-4)
_bj=v2:_k0(sx+_1*8-2,sy+_2*8-6)
local x,y=(_5.x+4)\8,(_5.y+4)\8
x=x\16
y=y\16
x*=16
y*=16
_bk=v2:_k0(x,y)
if _bh != _bk then
if not _v and not _bf then
_x=_bc
end
end
end
function _bg()
_w=_b2
_x=_bv
sfx"52" _mh()
_br=0
_bs=0
_ed(_b1)
_bt=_b1[1]
local _bu={-1,split(_a2[1],"◆")}
_bw={_bu,_b1}
music(-1,1000)
_l0()
music(8,100)
end
function _bv()
if btnp(⬆️) then _br-=1 end
if btnp(⬇️) then _br+=1 end
_br=_br%3
_bs=max(0,_bs-.125)
if btnp(❎) then
if _br<#_bw then
local _bx=_bw[_br+1]
local _ao,_by,s,_bz=unpack(_bx[2])
if
_bz or
_by>_fs
then
_bs+=1
sfx"53" _me(_bz and"sold out" or"not enough candy",30)
return
end
if s == 63 then
_b0=min(_b0+5,max_hp)
elseif s== 62 then
max_hp+=3
_b0=max_hp
elseif s==61 then
rate_lvl+=1
elseif s==60 then
_ah+=1
elseif s==59 then
acc_lvl+=1
elseif s==58 then
pwr_lvl+=1
elseif s==57 then
size_lvl+=1
end
_fs-=_by
_bx[2][4]=true
sfx"52"
if _bx[1] != -1 then
add(_ai,_bx[1])
end
else
_b1=nil
sfx"52" music(-1,1000)
_l0()
music"10" _aa()
_x=_ba
_w=_bb
end
end
_bw[1][2][4]=_b0==max_hp
end
function _b2()
local x,y,w,h=28,20
y+=_ki()
x-=(2-rnd"4" *_bs)
_mk()
_b3(x+30,y-6,52,66)
_b8(x,y+62,80)
local _x,_y=x-2,y+26
spr(206,_x,_y,2,4)
spr(206,_x+8,_y,2,4,true)
_x+=1
_y-=10
_l5(_x,_y,22,9,14)
spr(5,_x+2,_y+2,2,1)
print(_kr(_fs),_x+13,_y+2)
end
function _b3(x,y,w,h)
local s=0
if _br<#_bw then
s=_bw[_br+1][2][3]
end
_l5(x,y-3,w,h,14)
x+=13
print("YOU",x,y,13)
y+=7
_ac={
{"hp:" .._b0.."/" ..max_hp,63},{"maxhp:" ..max_hp,62},{"move:" ..acc_lvl,59}
}
for stt in all(_ac) do
_b5(x,y,s,unpack(stt))
y+=6
end
y+=4
print("ATTACK",x,y,13)
y+=7
local _ac={
{"size:" ..size_lvl,57},{"power:" ..pwr_lvl,58},{"rate:" ..rate_lvl,61},{"speed:" .._ah,60}
}
for stt in all(_ac) do
_b5(x,y,s,unpack(stt))
y+=6
end
end
function _b5(x,y,s,_ao,ss)
local c=s==ss and 7 or 6
print(_ao,x,y,c)
local _b6=s==63 and"+5" or"+1"
if c==7  then
print(_b6,x-9,y)
end
end
function _b8(x,y,w)
for i=1,#_bw do
local c=i-1==_br and 15 or 6
local bc=i-1==_br and 7 or 14
local _bx=_bw[i]
local _ao,_by,s,_bz=unpack(_bx[2])
_l5(x-2,y-3,w+4,12,bc)
spr(s,x,y-1)
print(_ao,x+10,y+1,c)
local _ao=_bz and"out" or"buy" print(_ao,x+w-12,y+1,c)
if not _bz then
c=i-1==_br and 15 or 14
spr(5,x+w-32,y+1,2,1)
print(_kr(_by),x+w-22,y+1,c)
end
local s=_bx.s
s=63
local _x=x+26
y+=13
end
local c=2==_br and 15 or 6
local bc=2==_br and 7 or 14
x=x+w-18
_l5(x,y-2,19,9,bc)
print("exit",x+2,y,c)
end
function _ca(_cb,y,c)
local _cc=split(_cb)
for _ao in all(_cc) do
x=_ku(_ao)
_kh(_ao,x,y,c)
y+=6
end
end
function _cd()
_cf=v2:_k0(3,3)
_cg=v2:_k0(1,5)
_ch=v2:_k0(4,4)
_ci=_kz()
_cj=_kz()
end
function _ce()
local _ck=_5+_cg
if _j1(_ck,2) then
_v=_ct(_as)
if _v then _8() end
end
if _j1(_ck,3) then
local cx,cy,_cm,_cl=_ck.x\8,_ck.y\8,_v[2][6],true
if _cm then
_cm=_kx(_cm)
for _bu in all(_cm) do
local x1,y1,x2,y2=unpack(_bu)
if x1 == cx and y1 == cy then
_5=v2:_k0(x2*8,y2*8+4)
_cl=false
if x2<0 then
_5.y-=2
music(-1,1000)
_l6(
12,12,105,#_am*7+6,_am
)
end
end
end
end
if _cl then
_5=_ab
end
_ci=_kz()
_cj=_kz()
_v=nil
_9=_c
_be(true)
_t()
if _cl then
_cp=_b
end
_l0()
end
if btnp(❎) then
if _cq then
_cq._mf=15
_cq.onend=_jp
_cq=nil
sfx"60" else
local _ao=_ct(_al)
if _ao then
_mg(_ao[2])
sfx"61" return
end
_b1=_ct(_a0)
if _b1 then  return _bg() end
end
end
end
function _ct(_cu)
local x,y=(_5.x+4)\8,(_5.y+4)\8
local o=_jj(x,y,_cu)
if o then return o end
for i=1,8 do
local _x=x+_e[i]
local _y=y+_f[i]
o=_jj(_x,_y,_cu)
if o then return o end
end
end
function _cv()
local _cw=_cj:_k8()>0
local n=_kz()
local ix,iy,_hi,frc,dsh_spd,_cx=0,0,.085,.815,1.2,0.95
local jp=sin(_p*3)*.04
if btn(➡️) then
ix+=1
_cy=false
_cz=false
end
if btn(⬅️) then
ix-=1
_cy=true
_cz=false
end
if btn(⬆️) then
iy-=1
_cz=true
end
if btn(⬇️) then
iy+=1
_cz=false
end
if ix*iy !=0 then
ix*=0.707
iy*=0.707
end
if
btnp(🅾️) and
not _cw and
_jv"dash" then
_cj.x+=ix*dsh_spd
_cj.y+=iy*dsh_spd
sfx"62" end
_ci.x += ix*_hi
_ci.y += iy*_hi
_ci.x -= ix*jp
_ci.y -= iy*jp
if _jz({
v=_5,_c2=_ch,of=_cg
},_cp)
then
return _g2()
end
local _c3=_di(_5,_ci,_cj,_ch,_cg)
_5=_c3.v
_5+=_ci+_cj
_ci*=frc
_cj*=_cx
if abs(_cj.x)<.2 then _cj.x=0 end
if abs(_cj.y)<.2 then _cj.y=0 end
if abs(_ci.x)<.02 then _ci.x=0 end
if abs(_ci.y)<.02 then _ci.y=0 end
if
_ci:_k8() != 0 and
_p*100%1 == 0 and
_cj:_k8() == 0
then
sfx"63" _lt(_5.x,_5.y)
end
if
_cj:_k8() > .5 and
flr(_p*20)%2==0
then
_lu(_5.x,_5.y,_ci.x,_ci.y)
end
end
function _db()
local s = _cz and 3 or 2
local x,y=_5.x,_5.y
local bx,by,hx,hy=x,y,x,y
local cx,cy=bx+5,by+6
if _cy then
cx=bx-1
bx+=2
hx-=1
end
local _dg=cos(_p*3)
if _ci:_k8()==0 then
hy+=min(0,sin(_p*.9))+1.2
end
if
abs(_ci.y) > 0 and
_ci.x ==0
then
hy+=min(.2,_dg)+1
end
if abs(_ci.x) > 0 then
hy+=1
hx+=min(.2,_dg)+1
end
local _dk={24,8,5,3,bx,by+7,5,3,_cy}
local _dl={s,hx,hy,1,1,_cy}
_km(unpack(_dk))
_kl(unpack(_dl))
sspr(unpack(_dk))
sspr(40,8,3,4,cx,cy)
spr(unpack(_dl))
end
function _di(v,d,_dj,_c2,of)
local w,h=_c2.x,_c2.y
local nx=v.x+d.x+_dj.x
local ny=v.y+d.y+_dj.y
local n=v2:_k0(nx,ny)
local _dm=n+of
local _dn=n+of-1
local _do=n+of
_do.y-=1
_do.x+=2
local _dp=n+of+2
local _dq=n+of
_dq.y+=2
_dq.x-=1
if not _jy(n,_c2,of) then return {v=v,d=d,_dj=_dj} end
local _dy=_dw(
d,_dn,_do,_dp,_dq
)
if _dy > 0 then
v.x+=_e[_dy]*.3
v.y+=_f[_dy]*.3
else
if _jy(
v2:_k0(nx,v.y),_c2,of
) then
d.x *= 0
_dj.x *= -1
end
if _jy(
v2:_k0(v.x,ny),_c2,of
) then
d.y *= 0
_dj.y *= -1
end
end
return {v=v,d=d,_dj=_dj}
end
function _dw(
_dx,a,b,c,d
)
local dx=_dx.x
local dy=_dx.y
local _dz={}
local _a=_jy(a,_cf)
local _b=_jy(b,_cf)
local _c=_jy(c,_cf)
local _d=_jy(d,_cf)
add(_dz,_a)
add(_dz,_b)
add(_dz,_c)
add(_dz,_d)
local _d0=0
for c in all(_dz) do
if c then _d0+=1 end
if _d0>1 then return 0 end
end
if dy < 0 then
if _a then return 2 end
if _b then return 1 end
end
if dx > 0 then
if _b then return 4 end
if _c then return 3 end
end
if dy > 0 then
if _c then return 1 end
if _d then return 2 end
end
if dx < 0 then
if _a then return 4 end
if _d then return 3 end
end
return 0
end
function _d4()
_d6={}
_d7=0
_d8=0
_d9=_5
_ea=false
end
function _d5()
if not _jv"dog" then return end
_d8=max(0,_d8-.1)
if
_5 != _d6[#_d6] and
_d8 == 0
then
_d8=1
add(_d6,_5)
end
local a=_d9
local b=_d6[1]
if b then
local c=b-a
if c:_k8() > 10 then
_ea=b.x>a.x
_d9+=c:_k9()*0.5
if _p*100%20 == 0 then
_lt(v.x+4,v.y-3)
end
else
del(_d6,b)
end
end
end
function _eb()
if not _jv"dog" then return end
local s=_kv({40,41})
local x,y=_d9.x,_d9.y+_ki()
_kl(s,x,y,1,1,_ea)
spr(s,x,y,1,1,_ea)
end
function _ed(_ee)
local _ae=_ee[1]
local x,y=_jm(_ae)
_5=v2:_k0(x*8,((y)*8)+4)
_ci=_kz()
_cj=_kz()
end
function _ef(x,y,_eg,fx)
if _jv(nil,_jo(x,y)) then return end
local _eh=split"48,49,50,53,27,28,29,30,7,8,23,24,121,122,126,56,55,40,20,90,9,10,240,241,242,243,249,246,247,248,244" local _ej=_kx[[
24|24|6|4
%24|28|6|4
%32|24|6|4
%32|28|6|4
%80|8|6|4
%80|12|6|4
%24|24|6|4
%32|24|6|4
%56|16|5|5
%56|16|5|5
%56|16|5|5
%56|16|5|5
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
%100|32|1|1
]]
local _ek={
v=v2:_k0(x,y),fx=fx,_el=_eh[_eg],_dk=_ej[_eg],t=rnd()*10,_eg=_eg
}
local _ae=_jo(x,y)
add(_aq,_ae)
_ap[_ae]=_ek
end
function _ei()
for i in all(_aq) do
local n=_ap[i]
local v,_el,_dk,_eg,t,fx=n.v*8,n._el,n._dk,n._eg,n.t,n.fx
local x,y=v.x,v.y
local sx,sy,sw,sh=unpack(_dk)
local hy=y
if _eg<13 then
hy+=min(0,sin((_p+t)*.8))+1.2
end
_km(sx,sy,sw,sh,x+1,y+7,sw,sh,fx)
_kl(_el,x,hy,1,1,fx)
sspr(sx,sy,sw,sh,x+1,y+7,sw,sh,fx)
spr(_el,x,hy,1,1,fx)
end
end
function _eu(
x,y,_eg,_ev,_ew
)
local point = {
x=x,y=y,_eg=split(_eg,"◆"),_ev=split(_ev,"◆"),_ew=_ew
}
add(_ay,point)
return point
end
function _ex()
local _ez,_e0=_bk.x,_bk.y
_cp={}
for pnt in all(_ay) do
local x,y,_eg=pnt.x,pnt.y,pnt._eg
local _ev,_ew=pnt._ev,pnt._ew
local _e1=_j5(
x,y,_ez,_e0,_ez+16,_e0+16
)
if _e1 then
for loc in all(_ev) do
if rnd() < _ew then
if loc == 0 then
_ey(x*8,y*8,rnd(_eg))
else
local _x,_y=x+_e[loc],y+_f[loc]
_ey(_x*8,_y*8,rnd(_eg))
end
end
end
end
end
end
function _ey(x,y,_eg,mn,mx)
local _eh=split"17,1,35,36,16,23" local _ej=split"32,22,34,37,54,22" local _e9=split"11,13,14,15,12,253" local _fa=split"cHUBS,kUNKY,gUPSY,lUISA,sPOOP,bOSS" local _fb=split"2,2,2,2,2,3"
local _fc=split".006,.005,.008,.007,.006,.008"
local _fd=split"2,2,2,2,2,2" local _fh=_j[_eg][_aj]
local b={
v=v2:_k0(x,y),d=_kz(),_dj=_kz(),of=v2:_k0(1,6),_c2=v2:_k0(4,4),fx=rnd()>0.5,_el=_eh[_eg],_dk=_ej[_eg],_fi=_ff,_fj=0,_fk=0,_fl=v2:_k0(x,y),t=rnd()*10,r=30,_fm=_g[_eg],_fn=_e9[_eg],hp=_fh,_fh=_fh,_eg=_eg,_fo=_fa[_eg],_fp=0,_fq=_fc[_eg],_fr=0,_d0=_fd[_eg],_fs=_fb[_eg]
}
add(_cp,b)
return b
end
function _fe(b)
_kn(_cp,function(a,b)
return a.v.y>b.v.y
end
)
for b in all(_cp) do
b:_fi()
end
end
function _ff(_fg)
local v=_fg.v
local of=_fg.of
local a=v+of
local b=_5+4
local d=_fg.d
local _c2=_fg._c2
local n=v2:_k0(nx,ny)
local _ft=0.32
local mt=(_fg._fl-v):_k8()
local mp=(a-b):_k8()
local _dj=_fg._dj
if mp > _fg.r then
if mt < 1 then
if _fg._fj == 0 then
_fg._fl=_gb(v,32)
_fg._fj=30+rnd"150" else
_fg._fj=max(0,_fg._fj-1)
_ft=0
end
_fg._fk=0
else
if _fg._fk == 120 then
_fg._fl=_gb(v,8)
_fg._fk=0
_fg._fj=30+rnd"150" else
_fg._fk=min(120,_fg._fk+1)
end
end
else
_fg._fl=_5
_fg._fj=0
_fg._fk=0
end
d+=(_fg._fl-v):_k9()*0.09
d.x=mid(-_ft,d.x,_ft)
d.y=mid(-_ft,d.y,_ft)
local _f6=_jz(_fg,_cp)
if _f6 then
_dj=(v-_f6.v):_k9()*0.5
d*=0
end
if _jy(
v2:_k0(v.x+d.x+_dj.x,v.y),_c2,of
)then
d.x*=0
_dj.x*=0
end
if _jy(
v2:_k0(v.x,v.y+d.y+_dj.y),_c2,of
) then
d.y*=0
_dj.y*=0
end
_fg.v+=d+_dj
_fg.d=d*0.9
_fg._dj=_dj*0.9
_fg.fx=_fg._fl.x < _fg.v.x
end
function _gb(v,r)
local _gd=true
local _v=_kz()
local _ez,_e0=_bk.x*8,_bk.y*8
while _gd do
local _ge=rnd()
local _x=v.x+sin(_ge)*r
local _y=v.y+cos(_ge)*r
_x=mid(_ez+8,_x,_ez+112)
_y=mid(_e0+8,_y,_e0+112)
_v=v2:_k0(_x,_y)
_gd=_j1(_v,0)
end
return _v
end
function _gc()
for b in all(_cp) do
local x,y,w,h,fx,_el,_dk=b.v.x,b.v.y,b._c2.x,b._c2.y,b.fx,b._el,b._dk
local hy,by=y+_ki(),y+6
_kl(_dk,x,by,1,1,fx)
_kl(_el,x,hy,1,1,fx)
spr(_dk,x,by,1,1,fx)
spr(_el,x,hy,1,1,fx)
end
end
function _g2()
_g3=split"42,43,44,45,46,47" _g5={}
drones,_g9,battle_candy,ship_v,ship_d,ship_rate,_hm,_hj,_hk,_cq={},{},0,v2:_k0(61,118),_kz(),_n[rate_lvl],0,0,0
_he()
music(63,300)
_x,_w=_g4,_hd
_l0(true)
music()
end
function _g4()
_hf()
_hx()
_i0()
_ig()
_g6=battle_x+battle_w-4
_g7=_kp(
battle_x+1,_g6
,(sin(_p/20)+1)/2
)
if not _jv"dog" then
_g7=-2
elseif _p*100%10 == 0 and
rnd() > .5
then
_hl(
_g7+2,_g6+10,1,0,.6
)
end
if _b0 == 0 then
_a7()
end
for _fg in all(_hg) do
if _fg.hp>0 then return end
end
for _fg in all(_hg) do
battle_candy+=_fg._fs
del(_cp,_fg)
end
_mg(split"yOU SCARED OFF THE,GHOSTS!,tHEY DROPPED SOME CANDY")
_fs+=battle_candy
_g9={}
music"17" _cq.butt=false
_cq.onend=function()
_cq=nil
_x=_ba
_w=_bb
_l0(true)
music(10,100)
end
_hb=1
_x=_ha
end
function _ha()
_hb=max(0,_hb-.015)
if _hb != 0 then return end
_cq.butt=true
if btnp(❎) then
_cq._mf=0
sfx"60" end
end
function _hd()
cls()
_i1()
local x,y,w=ship_v.x,ship_v.y,50
_l4(64-w/2,126,w,_b0,max_hp,7)
_l5(battle_x,battle_y,battle_w,_d,14)
clip(battle_x+1,battle_y+1,battle_w-2,_d-2)
_lf()
_h7()
_ih()
spr(25,_g7,battle_y+_d-6)
if _hj>0 then
pal(5,7)
end
if _hk>0 then _kj"7" end
spr(31,x,y)
pal()
if battle_candy > 0 then
clip()
local x,y=ship_v.x-6,ship_v.y-16
spr(5,x+3,y,2,1)
print(
_kr(_fs-battle_candy),x+14,y,14
)
print(
"+" .._kr(battle_candy),x+10,y+8,14
)
end
end
function _he()
_hg={}
for _fg in all(_cp) do
if
(_fg.v-_5):_k8()<30 and
#_hg < 5
then
add(_hg,_fg)
end
end
end
function _hf()
local ix,iy,_ft,_hh=0,0,1,.9
local _hi=_k[acc_lvl]
_hj=max(0,_hj-.5)
_hk=max(0,_hk-.06)
if btn(➡️) then ix+=1 end
if btn(⬅️) then ix-=1 end
if btn(⬇️) then iy+=1 end
if btn(⬆️) then iy-=1 end
if
btn(❎) and
_hm == 0
then
_hm=1
_hj=3
_hl(
ship_v.x+3,ship_v.y-2,1,_l[size_lvl],_o[_ah]
)
end
if ix*iy != 0 then
ix*=0.707
iy*=0.707
end
ship_d.x+=ix*_hi
ship_d.y+=iy*_hi
ship_d.x=mid(-_ft,ship_d.x,_ft)
ship_d.y=mid(-_ft,ship_d.y,_ft)
if
ship_v.x+ship_d.x<battle_x or
ship_v.x+ship_d.x+6>battle_x+battle_w
then
ship_d.x*=-1
end
if
ship_v.y+ship_d.y<battle_y or
ship_v.y+ship_d.y+4>battle_y+_d
then
ship_d.y*=-1
end
ship_v+=ship_d
ship_d*=_hh
_hm=max(0,_hm-ship_rate)
end
function _hl(x,y,_eg,r,_ft)
local ts={3,0}
local ds={-1,1}
local b = {
v=v2:_k0(x,y),r=r,_eg=_eg,_ft=_ft,d=ds[_eg],t=ts[_eg]
}
sfx"57" add(_g9,b)
return b
end
function _hx()
for b in all(_g9) do
b.v.y+=b.d*b._ft
b.t=max(0,b.t-0.2)
if b._eg == 1 then
for _ii in all(drones) do
local _c=(_ii.v+2)-b.v
if
_c:_k8()<4+_l[size_lvl]
and
_ii.v.y>battle_y
then
sfx"56"
if _ii._fp == 0 then
_ii.hp=max(0,_ii.hp-_m[pwr_lvl])
_ii._fp+=1
end
if _ii.hp == 0 then
local _fg=_ii._fg
_fg.hp=max(0,_fg.hp-1)
_fg._fp+=1
_lv(_ii.v)
del(drones,_ii)
sfx"55" end
del(_g9,b)
end
end
end
if b._eg == 2 then
local of=v2:_k0(3,2)
local c=b.v-(ship_v+of)
if _hk == 0 then
if c:_k8() < b.r + 2 then
_b0=max(0,_b0-1)
_hk+=1
sfx"54" del(_g9,b)
return
end
end
end
if
b.v.y+b.r<battle_y or
b.v.y-b.r>battle_y+_d
then
del(_g9,b)
end
end
end
function _h7()
for b in all(_g9) do
local c=b._eg == 1 and 14 or 6
local x,y,t=b.v.x,b.v.y,b.t
if t>0 then
local r=b.r+3
r-=3-t
circfill(x,y+2,r,14)
end
circ(x,y,b.r,c)
end
end
function _h8(x,y,_fg)
local _fc=split".008,.02,.015,.02,.009,.02" local _if=split"1,1,1,1,1,1" local _eg=_fg._eg
local _ii={
v=v2:_k0(x,y),_fg=_fg,_ft=_if[_eg],_fp=0,_fq=_fc[_eg],_fr=0,t=rnd(),hp=_i[_eg][_aj]
}
add(drones,_ii)
return _ii
end
function _ig()
for _ii in all(drones) do
_ii._fr=max(0,_ii._fr-_ii._fq)
_ii._fp=max(0,_ii._fp-.06)
local _eg=_ii._fg._eg
_ii.v.x+=_jf(_eg)*_ii._ft
_ii.v.y+=_jg(_eg)*_ii._ft
if _ii._fr == 0 then
_ii._fr=1
_hl(
_ii.v.x+3,_ii.v.y+4,2,1,.5
)
end
if
_ii.v.y>141 or
_ii.v.x>115 or
_ii.v.x<5
then
del(drones,_ii)
end
if _ii._fg.hp==0 then
_lv(_ii.v)
del(drones,_ii)
end
end
end
function _ih()
for _ii in all(drones) do
local s=_ii._fg._fn
if _ii._fp > 0 then _kj"7" end
spr(s,_ii.v.x,_ii.v.y)
pal()
end
end
function _i0()
for bttl in all(_hg) do
bttl._fr=max(0,bttl._fr-bttl._fq)
if bttl.hp > 0 then
bttl._fp=max(0,bttl._fp-.06)
if bttl._fr==0 then
local _eg=bttl._eg
local x,y=_i9(_eg),_je(_eg)
bttl._fr=1
for i=1,rnd(bttl._d0)+1 do
_h8(x+i*6,y,bttl)
end
end
end
end
end
function _i1()
clip(0,17,128,57,0)
_kq(_g3[flr(_p*10%#_g3+1)])
clip()
line(0,15,128,15,5)
line(0,75,128,75,5)
local _i2=split"64,38,90,14,114" for i=#_hg,1,-1 do
local b=_hg[i]
if b.hp > 0 then
local x=_i2[i]
local y=35+sin(_p+b.t)*2+.1
if b._fp > 0 then _kj"7" end
local sx,sy,sw,sh,dx=unpack(b._fm)
sspr(sx,sy,sw,sh,x+dx,y)
if b._eg > 4 then
sspr(sx,sy,sw,sh,x+dx+sw,y,sw,sh,true)
end
pal()
x-=11
y=2
local w,h=23,10
rectfill(x+1,y+1,x+w-2,y+h-2,15)
_l5(x,y,w,h,14)
print(b._fo,x+2,y+2,5)
local x+=1
local y+=1+h
_l4(x,y,w-3,b.hp,b._fh,14)
end
end
end
function _i9(_eg)
if _eg==2 then
return 11
elseif _eg==3 then
return 101
end
return rnd(split"22,35,67,83")
end
function _je(_eg)
if _eg==2 or _eg==3 then
return rnd({86,96})
end
return 70
end
function _jf(_eg)
if _eg==1 then
return _q
elseif _eg==2 then
return .1+_q
elseif _eg==3 then
return -.1-_q
elseif _eg==4 then
return 0
elseif _eg==5 then
return _q
elseif _eg==6 then
return _r
end
end
function _jg(_eg)
if _eg==1 then
return .08
elseif _eg==2 then
return sin(_p)*.5
elseif _eg==3 then
return _r
elseif _eg==4 then
return sin(_p)*.3+.05
elseif _eg==5 then
return _r+.08
elseif _eg==6 then
return _q+.08
end
end
function _jh(x,y,_at)
local _ae=_jo(x,y)
local r={}
for i in all(split(_at,">"))do
add(r,i)
end
_as[_ae]={_ae,r}
end
function _ji(x,y,_bx,_cu)
local i=_jo(x,y)
if _jv(nil,i) then return end
_cu[i]={i,split(_bx,"◆")}
end
function _jj(x,y,_cu)
return _cu[_jo(x,y)]
end
function _jk(x,y)
add(_y,v2:_k0(x,y))
end
function _jl()
for v in all(_y) do
local c=(_5+4)-(v+4)
if c:_k7() <= 13 then
spr(112,v.x+1,v.y-5+_ki())
end
end
end
function _jm(_jn)
return _jn%128,_jn\128
end
function _jo(x,y)
return x+y*128
end
function _jp()
local _jq=_ct(_aw)
if not _jq then return end
local _jr,_js=unpack(_jq)
local id,_jt,_ju=unpack(_js)
if _jv(id) then return end
if
_ju and
not _jv(_ju)
then
return
end
_mg({_jt})
sfx"52" add(_av,_jr)
_aj+=1
_aa()
_t(true)
return true
end
function _jv(id,_jw)
for _jq in all(_av)do
local _jx=unpack(_aw[_jq][2])
if
_jx==id
then
return true
end
if _jq == _jw then
return true
end
end
end
function _jy(v,_c2,of)
local of=of or _kz()
if _j4(
v,v+_c2,_bi,_bj
) then
return true
end
if god then
return
end
if _j0(v,_c2,of,0) then return true end
if _j0(v,_c2,of,-1) then return true end
if not _jv"water" then
if _j0(v,_c2,of,6) then return true end
end
if not _jv"fence" then
if _j0(v,_c2,of,7) then return true end
end
end
function _jz(o,_cu)
local v,_c2,of=o.v,o._c2,o.of
local a1,a2=v+of,v+of+_c2
for i in all(_cu) do
local b1,b2=i.v+i.of,i.v+i.of+i._c2
if i != o then
if _j3(a1,a2,b1,b2) then
return i
end
end
end
end
function _j0(v,_c2,of,f)
local v=v+of
local a,b,c,d=v,v+_c2,v2:_k0(v.x+_c2.x,v.y),v2:_k0(v.x,v.y+_c2.y)
local _j6=f==-1 and _j2 or _j1
if _j6(a,f) then return a end
if _j6(b,f) then return b end
if _j6(c,f) then return c end
if _j6(d,f) then return d end
end
function _j1(v,f)
local v=v+0
local _z,_0,sx,sy=unpack(_9)
v.x-=sx
v.y-=sy
local mx=flr(v.x/8)
local my=flr(v.y/8)
mx+=_z
my+=_0
return fget(mget(mx,my),f)
end
function _j2(v)
return _jj(flr(v.x/8),flr(v.y/8),_ap)
end
function _j3 (a1,a2,b1,b2)
return a1.x < b2.x and
a2.x > b1.x and
a1.y < b2.y and
a2.y > b1.y
end
function _j4(a1,a2,b1,b2)
return a1.x<b1.x or
a2.x>b2.x or
a1.y<b1.y or
a2.y>b2.y
end
function _j5(x,y,x1,y1,x2,y2)
return x>x1 and x<x2 and y>y1 and y<y2
end
function _kh(_t,_x,_y,_c)
for i=1,8 do
print(_t,_x+_e[i],_y+_f[i],0)
end
print(_t,_x,_y,_c)
end
function _ki()
return flr(min(0,sin(_p)))
end
function _kj(_kk)
for i=0,15 do
pal(i,_kk)
end
end
function _kl(s,x,y,w,h,fx,fy)
_kj"0" for i=1,4 do
spr(s,x+_e[i],y+_f[i],w,h,fx,fy)
end
pal()
end
function _km(sx,sy,sw,sh,dx,dy,dw,dh,fx,fy)
_kj"0"
for i=1,4 do
sspr(sx,sy,sw,sh,dx+_e[i],dy+_f[i],dw,dh,fx,fy)
end
pal()
end
function _kn(a,_ko)
for i=1,#a do
local j=i
while j>1 and _ko(a[j-1],a[j]) do
a[j],a[j-1]=a[j-1],a[j]
j-=j
end
end
end
function _kp(a,b,t)
return a*(1-t)+b*t
end
function _kq(s)
local _ft,a,b=20,21,13
local sx,sy=flr(s%16)*8,flr(s/16)*8
local t=_p*_ft
local go=sin((t%100)/100)
for y=0,128 do
local lo=sin(((t+y)%100)/100)
for x=0,128,8 do
local _ks=sy+(y+go*a+lo*b*sin(_p/2)-.2)%8
sspr(sx,_ks,8,1,x,y)
end
end
end
function _kr(n)
return n<10 and"0" ..n or n
end
function _kt(x,y,t)
local _dg=sin(t*_p/1.5+.3)*2.5
line(
x-.5+_dg/2,y,x+1.5-_dg/2,y,5
)
line(
x,y-1.5+_dg,x,y+2.5-_dg,5
)
end
function _ku(s)
return 64-#s*2
end
function _kv(_kw)
return _kw[flr(_p*100/15)%#_kw+1]
end
function _kx(s)
if not s then return end
local _cu=split(s,"%")
for i=1,#_cu do
_cu[i]=split(_cu[i],"|")
end
return _cu
end
v2={}
function _kz()
return v2:_k0()
end
function v2:_k0(x,y)
v={}
v.x=x or 0
v.y=y or 0
setmetatable(v,self)
self.__index=self
return v
end
function v2.__add(a,b)
if type(b) =="number" then
return v2:_k0(a.x+b,a.y+b)
end
return v2:_k0(a.x+b.x,a.y+b.y)
end
function v2.__sub(a, b)
if type(b) =="number" then
return v2:_k0(a.x-b,a.y-b)
end
return v2:_k0(a.x-b.x,a.y-b.y)
end
function v2.__mul(a, b)
if type(a) =="number" then
return v2:_k0(b.x*a,b.y*a)
elseif type(b) =="number" then
return v2:_k0(a.x*b,a.y*b)
end
return a.x * b.x + a.y * b.y
end
function v2.__div(a,b)
if type(a) =="number" then
return v2:_k0(b.x/a,b.y/a)
elseif type(b) =="number" then
return v2:_k0(a.x/b,a.y/b)
end
end
function v2.__eq(a,b)
return a.x==b.x and a.y==b.y
end
function v2:_k7()
local nx=self.x*0x0.01
local ny=self.y*0x0.01
return sqrt(nx*nx+ny*ny)*0x100
end
function v2:_k8()
return sqrt(self.x*self.x+self.y*self.y)
end
function v2:_k9()
return self/self:_k8()
end
function _la(
x,y,dx,dy,_lb,_lc,_ld
)
local p = {
x=x,y=y,dx=dx,dy=dy,_lg=0,_lb=_lb,c=_lc[1],_lc=_lc,r=_ld[1],_ld=_ld,}
add(parts,p)
return p
end
function _le()
for part in all(parts) do
part._lg+=1
part.x+=part.dx
part.y+=part.dy
if #part._lc == 1 then
part.c=part._lc[1]
else
local ci=part._lg/part._lb
ci=1+flr(ci*#part._lc)
part.c=part._lc[ci]
end
if #part._ld == 1 then
part.r=part._ld[1]
else
local ri=part._lg/part._lb
ri=1+flr(ri*#part._ld)
part.r=part._ld[ri]
end
if part._lg > part._lb then
del(parts,part)
end
end
end
function _lf()
for part in all(parts) do
circfill(part.x,part.y,part.r,part.c)
end
end
function _lt(x,y)
local _ge=rnd()
local _x,_y=x+6+sin(_ge),y+9
if not _cy then _x-=5 end
_la(
_x,_y,0,0,30,split"6,6,13",split"1,0")
end
function _lu(x,y,dx,dy)
local _ld={rnd(split"1,1,1,2"),1}
local _lc=split"15,14,14,14,5" local _ge=rnd()
local _x=x+4+sin(_ge)*3
local _y=y+6+cos(_ge)*2
_la(
_x,_y,dx*.2,dy*.2,40,_lc,_ld
)
end
function _lv(v)
local _ld=split"3,2,1,1,0" local _lc=split"7,15,14,13" for i=1,3 do
local x,y=v.x+1,v.y
local _ge=rnd()
x+=sin(_ge)*.2
y+=cos(_ge)*.2
_la(
x,y,0,-rnd()*.5,40,_lc,_ld
)
end
end
function _lw()
local t=_a6
local c=0
local w=16
for i=0,8 do
for j=0,8 do
local x=i*w
local _ly=sin(t+i*0.1)
local _lz=sin(t+j*0.03)
local y=j*w+_ly*w
local r=_lz*w
local _x=_l2 and x or y
local _y=_l2 and y or x
circfill(_x,_y,r,c)
if r>4 and _l2 then
circ(_x,_y,r-3,5)
circfill(_x,_y,r/2-3,14)
end
end
end
end
function _lx(_ft)
if _a6>0 then
_a6=max(_a6-_a,0)
_lw()
end
end
function _l0(_l1)
_l2=_l1
_a=_l1 and.0058 or .009
camera()
_a6=1
local _l3=.6
repeat
_a6=max(_a6-_a,_l3)
_lw()
flip()
until _a6==_l3
_a6=_l3
end
function _l4(x,y,w,hp,_fh,c)
local x1=x
local x2=x1+(hp*w/_fh)
line(x1,y,x1+w,y,5)
line(x1,y,x2,y,c)
end
function _l5(x,y,w,h,c)
line(x+1,y,x+w-2,y,c)
line(x+w-1,y+1,x+w-1,y+h-2,c)
line(x+w-2,y+h-1,x+1,y+h-1,c)
line(x,y+1,x,y+h-2,c)
end
function _l6(x,y,w,h,_ao)
local w={
x=x,y=y,w=w,h=h,_ao=_ao
}
add(_g5,w)
return w
end
function _l7()
for w in all(_g5) do
local wx,wy,ww,wh=w.x,w.y,w.w,w.h
rectfill(wx+1,wy+1,wx+ww-2,wy+wh-2,0)
_l5(wx,wy,ww,wh,14)
clip(wx,wy,ww-2,wh-2)
wy+=4
wx+=4
for i=1,#w._ao do
local _ao=w._ao[i]
print(_ao,wx+4,wy,14)
wy+=6
end
clip()
if w._mf == nil and w.butt then
_kh("❎",wx+ww-15,wy+1+_ki(),14)
end
end
end
function _mb()
for w in all(_g5) do
if w._mf!=nil then
w._mf-=1
if w._mf<=0 then
local _mc=w.h/4
w.y+=_mc/2
w.h-=_mc
if w.h<3 then
if w.onend then
w.onend()
end
del(_g5,w)
end
end
end
end
end
function _me(_ao,_mf)
local _mi=(#_ao+2)*4+7
local w=_l6(
63-_mi/2,50,_mi,13,{_ao}
)
w._mf=_mf
end
function _mg(_ao,y)
if not _ao then return end
local y=y or 50
_cq=_l6(
12,y,105,#_ao*7+6,_ao
)
_cq.butt=true
end
function _mh()
_mj={}
for i=1,25 do
add(_mj,{flr(rnd"128"),flr(rnd"128"),rnd()})
end
end
function _mk()
cls()
for s in all(_mj) do
_kt(unpack(s))
end
end