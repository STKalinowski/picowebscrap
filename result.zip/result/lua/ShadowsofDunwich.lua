-- shadows of dunwich
-- by paranoid cactus
function _init()
	poke(0x5f2d,1)
	memcpy(0x5b00,0x2d00,768)
	cartdata("shadowsofdunwich")
	camera_distance,camera_pos,camera_angle,mx,my,blink_time,mstate_c,bitmasks,special_funcs,mission,nsp=120,new_vector3d(),0,matrix_rotate_x(-0.05),matrix_rotate_y(0),0,get_mouse_state(),{0b0101101001011010.1,0b1010010110100101.1},{action_grenade,action_shock,action_heal},1,0
	read_sprites_and_anims()
	music(0)
end

function new_battle()
	cam_x,cam_y,wait,action_mode,grenade,floating_text = 0,0,0,0,{},{}
	gen_map()
	menuitem(3,"abort mission",function() nextmission() music(0) end)
	music(-1)
end

function get_mouse_state()
	return {x=stat(32),y=stat(33),b1=band(stat(34),0x01)==1,b2=band(stat(34),0x02)==2,b3=band(stat(34),0x04)==4}
end

function mouse_on_screen()
	return mstate_c.x>=0 and mstate_c.x<=127 and mstate_c.y>=0 and mstate_c.y<=127
end

function _update60()
	mstate_p,mstate_c,bp0,bp1,bp2,bp3,bp4,bp5=mstate_c,get_mouse_state(),btnp(0),btnp(1),btnp(2),btnp(3),btnp(4),btnp(5)
	if not mouse_on_screen() then
		mstate_c.b1=false
	end
	blink_time,action_cost=(blink_time-1)%40,0
	if game_mode==2 then
		if wait>0 then
			wait-=1
		else
			if gameover then
				nextmission(true)
				return
			end
			if player.p <= 0 then
				if not nextplayer() then
					for p in all(teams[team_i]) do
						p.n_action,p.p,p.shocked=2,2,nil
					end
					player_i,team_i=0,team_i%2+1
					if not nextplayer() then
						music(0)
						gameover,wait=true,60
						return
					end
				end
			end

			menu={}
			if not player.action then
				if team_i==1 then
					player_think()
				else
					ai_think()
				end
			end
		end
		local pm=new_line_table()
		for pr in all(particles) do
			for p in all(pr) do
				p.life-=1
				p.y+=p.vy
				p.x+=p.vx
				if p.life > 0 then
					add(pm[table_row(p.y)],p)
				end
			end
		end
		particles=pm
		
		for f in all(floating_text) do
			f.t-=1
			f.y-=0.25
			if f.t==0 then
				del(floating_text,f)
			end
		end
		
		for i,t in pairs(teams) do
			for p in all(t) do
				if p==player or (p.x>cam_x-10 and p.x<cam_x+130 and p.y>cam_y-10 and p.y<cam_y+130) then
					p:update()
				end
				if #teams[i%2+1]==0 then
					p.p=0
				end
				if p.hp<=0 then
					del(t,del(actors[table_row(p.y)],p))
				end
			end
		end
		cam_xd,cam_yd=flr(max(0,min(mid(cam_x,cam_follow.x-78,cam_follow.x-32),386))),flr(max(-15,min(mid(cam_y,cam_follow.y-74,cam_follow.y-32),145)))
		cam_x,cam_y=flr(cam_x+(cam_xd-cam_x)*0.1),flr(cam_y+(cam_yd-cam_y)*0.1)
		if scroll_wait and (abs(cam_xd-cam_x)>10 or abs(cam_yd-cam_y)>10) then
			mouse_enable=false
		else
			scroll_wait=nil
		end
	elseif game_mode==1 then
		if bp0 then
			cam_x=max(0,cam_x-1)
		elseif bp1 then
			cam_x=min(5,cam_x+1)
		end
		if bp2 then
			cam_y=max(0,cam_y-1)
		elseif bp3 then
			cam_y=min(5,cam_y+1)
		end
		column=flr(cam_x/2)+1
		player,selectedval=teams[1][column],cam_x%2+1
		if bp4 then
			if cam_y==0 then
				game_mode,message=2,nil
				new_battle()
			elseif cam_y<=player.st[6] and player.st[cam_y]==0 then
				player.st[cam_y]=selectedval
				spawn_players()
				--sfx(46)
			end
		end
	else
		if bp4 or bp5 then
			if bp5 then
				memset(0x5e00,0,0x00FF)
			end
			pskills={{},{},{}}
			for i,k in pairs(pskills) do
				for j=1,6 do
					k[j]=dget(j+i*6)
				end
			end
			nextmission()
		end
	end
end

function _draw()
	cls()
	if game_mode==2 then
		local xs,ys,node,gend=max(table_row(cam_x)-9,0),max(flr(cam_y/8),0),get_cursor_node(),grenade.pathend
		local xe,ye,can_move,can_action=min(xs+24,63),min(ys+19,31),node and getmovep(node)<=player.p,team_i==1 and not player.action and not player.pathnode and player.p>0
		camera(cam_x,cam_y)
		map(0,0,0,0,64,32)
		map(64,0,0,0,64,32)

		-- shadows
		for t in all(teams) do
			for a in all(t) do
				sspr(104,32,9,7,a.x-1,a.y+3)
			end
		end
		
		if wait<=0 and can_action then
			if action_mode==0 then
				if can_move then
					fillp(bitmasks[(cam_x+cam_y)%2+1])
					for ml in all(movelines) do
						rectfill(ml[1],ml[2],ml[3],ml[4],ml[5])
					end
					fillp()
					while node.parent ~= nil do
						line(node.x+3,node.y+3,node.parent.x+3,node.parent.y+3,10)
						node=node.parent
					end
				end
			elseif gend then
				circ(gend.x,gend.y,24,8)
			end
			circ(cursor.x+3,cursor.y+3,5,7)
		end
		for y=ys,ye do
			for x=xs,xe do
				local overlay=oget(x,y)
				if overlay>0 and overlay<=#mapspr then
					local sprite=mapspr[overlay]
					sspr(sprite.x,sprite.y,sprite.w,sprite.h,x*8,y*8-sprite.h+8)
				end
			end
			for a in all(actors[y+1]) do
				camera(cam_x+61-a.x,cam_y+57-a.y)
				a:draw()
			end
			camera(cam_x,cam_y)
			for p in all(particles[y+1]) do
				circfill(p.x,p.y,p.size,p.col)
			end
			if gend then
				for gp in all(grenade.path[y+1]) do
					pset(gp.x,gp.y+gp.z,7)
				end
			end
		end

		if wait<=0 then
			if player.action==action_attack_cont then
				draw_attack(player.n_action==3 and 12 or 6)
			elseif can_action and action_mode==0 and can_move then
				for y=cursor.y/8-1,cursor.y/8+1 do
					for x=cursor.x/8-1,cursor.x/8+1 do
						local m,sp=get_bval(x,y),215
						if m and m>=254 then
							if m==255 then
								sp=250
							end
							spr(sp,x*8,y*8)
						end
					end
				end
			end
		end
		if can_action then
			spr(107,player.x,player.y-15) --+sin(blink_time/40)*1.125
		end
		for f in all(floating_text) do
			local x=f.x-(#f.text*2)
			for x1=x-1,x+1 do
				for y1=f.y-1,f.y+1 do
					print(f.text,x1,y1,0)
				end
			end
			print(f.text,x,f.y,f.col)
		end
		
		camera()
		-- ui
		for k,a in pairs(teams[1]) do
			set_colors(a.cols)
			local x,col=k*28,a==player and 7 or 13
			rectfill(x-26,121,x,127,a==player and 12 or 0)
			draw_sprite_part(a.sprite_parts[1],x-21,126,1)
			draw_sprite_part(a.sprite_parts[7],x-21,126,1)
			print(a.hp,x-15,122,col)
			for i=1,a.p do
				rectfill(x-3,119+3*i,x-2,119+3*i+1,(a==player and blink_time<20 and action_cost>=a.p+1-i) and 8 or col)
			end
		end
		pal()
		
		if team_i==1 and player.hp>0 then	
			btns[3].i=player.si
			for i=1,3 do
				local col,bi=(max(0,i-2)==action_mode) and 1 or 0,btns[i]
				if player.n_action==i then
					pal(5,6)
					pal(13,7)
					col=12
				end
				rectfill(bi.x1,bi.y1,bi.x2,bi.y2,col)
				spr(bi.i,bi.x1+2,bi.y1)
				for j=0,player.sa-1 do
					pset(122+flr(j/3)*2,122+2*(j%3),13)
				end
				pal()
			end
			if player.n_action~=0 then
				spr(108,action_mode==0 and 95 or 115,114)
			end
			spr(124,action_mode==1 and 95 or 115,114)
		end

		if mouse_enable then
			spr(127,mstate_c.x,mstate_c.y)
		end
		if menu then
			local x,y,h=cam_follow.x-cam_x-1,cam_follow.y+13-cam_y,#menu*7
			if y+h>115 then
				y-=24+h
			end
			for m in all(menu) do
				local r=x+#m*4
				if r>127 then
					x,r=125-(r-x),125
				end
				rectfill(x,y,r,y+6,0)
				print(m,x+1,y+1,7)
				y+=7
			end
		end
	elseif game_mode==1 then
		print(message or "",34,3,9)
		memset(0x6300,0x55,0x0340)
		print("mission level "..mission,14,16,15)
		rectfill(84,14,112,22,cam_y==0 and 12 or 13)
		print("deploy",87,16,7)
		for i,a in pairs(teams[1]) do
			local x1=i*35
			rectfill(x1-21,40,x1+7,110,1)
			camera(71-x1,19)
			a:draw()
			camera()
			for j,b in pairs(skilltree[i]) do
				for k,s in pairs(b) do
					local v,st,x,y=1,a.st[j],x1-s.x,37+j*12
					if st==k then
						v=3
					elseif st~=0 or a.st[6]<j then
						v=5
					end
					if skilltree[column][cam_y]==b and selectedval==k then
						v+=1
						print(skilltree.text[s.t],14,114,15)
					end
					for i=1,13 do
						pal(i,pals[v][i])
					end
					rectfill(x,y,x+10,y+10,1)
					spr(s.s,x+2,y+1)
					pal()
				end
			end
		end
	else
		memcpy(0x63cc,0x370c,3060)
		if game_mode==3 then
			memcpy(0x7280,0x5b00,768)
		end
		spr(108,41,96)
		print("continue",53,98,15)
		spr(124,41,106)
		print("new game",53,108,8)
	end
end

function nextmission(isgo)
	gameover,game_mode,message,cam_x,cam_y,column,selectedval,prevmission,mission,nsp=nil,1,isgo and (team_i==1 and "mission failure" or "mission success") or nil,0,0,1,1,mission,1,max(nsp,flr(mission/4))
	if isgo and team_i==2 then
		for p in all(teams[1]) do
			p.st[6]=min(5,p.st[6]+1)
		end
	end
	spawn_players()
	for i,p in pairs(teams[1]) do
		mission+=p.st[6]
		menuitem(i)
	end
	--victory
	if prevmission==16 and mission==16 then
		game_mode,nsp,teams=3,0,nil
	end
	sfx(-1,0)
end

function nextplayer()
	found,list,scroll_wait=false,teams[team_i],true
	for i=1,#list do
		player_i=player_i%#list+1
		if list[player_i].p > 0 then
			player,found=list[player_i],true
			if not (team_i==2 and #player.tl == 0) then
				cursor.x,cursor.y,cam_follow=player.x,player.y,cursor
			end
			grenade,action_mode,player.n_action={},0,0
			gen_path_map(flr(player.x/8),flr(player.y/8))
			break
		end
	end
	menuitem(1)
	menuitem(2)
	if team_i==1 then
		menuitem(1,"next member",nextplayer)
		menuitem(2,"end turn",function() for p in all(teams[1]) do p.p=0 end end)
	end
	return found
end

function spawn_players(nosave)
	if teams then
		pskills={}
		for a in all(teams[1]) do
			pskills[a.i]=a.st
		end
	end
	actors,particles,teams=new_line_table(),new_line_table(),{{},{}}
	for i=1,3 do
		ut=unit_types[i]
		local a=new_actor(ut.sx,ut.sy,0.625,ut,teams[1],pskills[i])
		for j=1,6 do
			dset(j+i*6,a.st[j])
		end
	end
end

function add_floating_text(text,a,col,y)
	add(floating_text,{text=text,t=60,col=col,x=a.x+3,y=a.y-12+(y or 0)})
end

function new_actor(x,y,angle,ut,team,st)
	local sprite_parts,sprite_parts_sorted,anim,panims,angle,to_angle={},{},anims[ut.ai],{anims[ut.ai],anims[ut.am],anims[ut.aa]},angle,angle
	for l=1,#models[ut.m] do
		local p,a=models[ut.m][l][1],models[ut.m][l][2]
		add(sprite_parts,{sprites=sprites[models[ut.m][l][3]],pos=p,angle=a,pos_prev=new_vector3d(p.x,p.y,p.z),angle_prev=a})
	end
	local a=add(team,add(actors[table_row(y)],{
		x=x,
		y=y,
		i=#team+1,
		team=team,
		actions={action_move,action_attack,special_funcs[ut.sf]},
		sprite_parts=sprite_parts,
		tl={},
		update=function(p)
			del(actors[table_row(p.y)],p)
			if p.action then
				p.action()
			end
			angle+=(to_angle-angle)*0.2
			add(actors[table_row(p.y)],p)
			if p.shocked then
				add(particles[table_row(p.y)],{x=p.x+rnd(8),y=p.y-rnd_range(-4,11),vx=0,vy=0.25,size=1,col=7,life=2})
			end
			p.at+=1
			sprite_parts_sorted={}
			local m_rotation_x, m_rotation_y,prev_frame,prev_frame_time=matrix_rotate_x(0),matrix_rotate_y(-angle),nil,0
			if p.at>=anim[#anim].t then
				p.at-=anim[#anim].t
				prev_frame,prev_frame_time,anim=anim[#anim],0,anims[anim.on_finish]
			end
			for a in all(anim) do
				if p.at<a.t and p.at>=prev_frame_time then
						if prev_frame then
							for p in all(prev_frame) do
								local limb=sprite_parts[p.l]
								limb.pos_prev,limb.angle_prev=p.p,p.a
							end
						end
						for next_frame in all(a) do
							local limb,t=sprite_parts[next_frame.l],(p.at-prev_frame_time)/(a.t-prev_frame_time)
							v3d_lerp(limb.pos,limb.pos_prev,next_frame.p,t)
							limb.angle=lerp(limb.angle_prev,next_frame.a,t)
						end
					break
				end
				prev_frame,prev_frame_time=a,a.t
			end
			for v in all(sprite_parts) do
				local t=matrix_mul_add(mx,matrix_mul_add(my,v3d_add(camera_pos,matrix_mul_add(m_rotation_x,matrix_mul_add(m_rotation_y,v.pos)))))
				t.z+=192
				v.pos_scr,insert_i=new_vector3d(round(t.z/camera_distance*t.x+64),round(t.z/camera_distance*t.y+64),t.z),0
				for i=1,#sprite_parts_sorted do
					if v.pos_scr.z<=sprite_parts_sorted[i].pos_scr.z then
						insert_i=i
						break
					end
				end
				table_insert(sprite_parts_sorted,v,insert_i)
			end
		end,
		draw=function(p)
			set_colors(p.cols)
			for v in all(sprite_parts_sorted) do
				local sp_count = #v.sprites.sprs
				draw_sprite_part(v,v.pos_scr.x,v.pos_scr.y,flr((0.5+angle+v.angle)*sp_count+0.5)%sp_count+1)
			end
			pal()
		end,
		set_turn_angle=function(p,pos1,pos2)
			to_angle=atan2(-(pos2.y-pos1.y),pos2.x-pos1.x)
			local a,b,c=to_angle-angle,to_angle-1-angle,to_angle+1-angle
			angle=to_angle-(abs(a)<abs(b) and (abs(a)<abs(c) and a or c) or (abs(b)<abs(c) and b or c))
		end,
		set_anim=function(p,v)
			anim,p.at=panims[v],0
		end
	}))
	for k,v in pairs(ut) do
		a[k]=v
	end
	if team==teams[1] then
		if st then
			for i=1,5 do
				if st[i]~=0 then
					for k,m in pairs(skilltree[a.i][i][st[i]].m) do
						a[k]+=m
					end
				end
			end
			a.st=st
		else
			a.st={0,0,0,0,0,nsp}
		end
	end
	a:update()
	return a
end

function player_think()
	tg=false
	if mouse_enable and mouse_on_screen() then
		cursor.x,cursor.y,tg=min(max(flr((cam_x+mstate_c.x)/8)*8,0),504),min(max(flr((cam_y+mstate_c.y)/8)*8,0),248),true
	end
	if mstate_c.x~=mstate_p.x or mstate_c.y~=mstate_p.y then
		mouse_enable=true
	end

	if bp0 then
		cursor.x,tg,mouse_enable=max(cursor.x-8,0),true,false
	end
	if bp1 then
		cursor.x,tg,mouse_enable=min(cursor.x+8,504),true,false
	end
	if bp2 then
		cursor.y,tg,mouse_enable=max(cursor.y-8,0),true,false
	end
	if bp3 then
		cursor.y,tg,mouse_enable=min(cursor.y+8,248),true,false
	end
	
	player.n_action,target=0,get_cursor_actor(2)
	if action_mode==0 then
		movenode=get_cursor_node()
		local mp=getmovep(movenode)
		if movenode and mp<=player.p then
			player.n_action,action_cost=1,mp
		else
			target_message(2,player.p)
		end	
	else
		if player.stt==2 then
			target_message(3,2)
		elseif can_special() then
			player.n_action,action_cost=3,2
		else
			if player.stt==1 and target and v3d_distance2d(target,player)>player.sr then
				add(menu,"too far")
			end
			grenade,player.n_action={},0
		end
	end
	if bp4 or mstate_c.b1 and not mstate_p.b1 then
		if player.n_action>0 then
			grenade,mouse_enable,tg={},false,false
			player.actions[player.n_action]()
		end
	end
	if bp5 or mstate_c.b2 and not mstate_p.b2 then
		action_mode,grenade,tg=(action_mode+1)%2,{},true
	end
	if tg and action_mode==1 and player.stt==0 and can_special() then
		new_grenade(true)
	end
	if btnp(5,1) or mstate_c.b3 and not mstate_p.b3 then
		nextplayer()
	end
end

function target_message(n_action,points)
	if target then
		local hitchance=target.los
		if hitchance>=0 then
			hitchance=min(100,ceil(hitchance*(player.ac+(n_action-2)*player.sac)/100))
			add(menu,"hit "..hitchance.."%")
			player.n_action,action_cost=n_action,points
		elseif hitchance==-1 then
			add(menu,"blocked")
		else
			add(menu,"too far")
		end
		add(menu,"hp "..target.hp)
		player.hitchance=hitchance
	end
end

function get_cursor_actor(ti)
	if ti==0 then
		return cursor
	end
	for e in all(teams[ti]) do
		if e.x==cursor.x and e.y==cursor.y then
			return e
		end
	end
end

function can_special()
	target=get_cursor_actor(player.stt)
	return target and not (player.stt~=1 and player.x==cursor.x and player.y==cursor.y) and v3d_distance2d(cursor,player)<=player.sr and player.sa>0 and player.p>=2
end

function ai_think()
	if movenode then
		if target.los>30 or player.p==1 and target.los>0 then
			player.hitchance=target.los
			if player.actions[3] and rnd(4)<1 then
				player.n_action=3
				player.actions[3]()
			else
				action_attack()
			end
			return
		end
		while movenode.parent~=nil and movenode.f<24 do
			movenode=movenode.parent
		end
		local node=movenode
		while node.parent~=nil do
			if getmovep(node)<2 and find_los(node,target,128)>30 then
				movenode=node
				break
			end
			node=node.parent
		end
		if movenode.parent then
			action_move()
		else
			player.p-=1
		end
	else
		player.p=0
	end
end

function action_move()
	while movenode.parent~=nil do
		movenode.parent.next,movenode=movenode,movenode.parent
	end
	pathlerp,cam_follow,player.action=0,player,action_move_cont
	player:set_anim(2)
	sfx(player.fxm,0)
end

function action_move_cont()
	pathlerp+=0.1
	if movenode.x==movenode.next.x or movenode.y==movenode.next.y then
		pathlerp+=0.04
	end
	if pathlerp>=1 then
		pathlerp-=1
		movenode=movenode.next
	end
	if movenode.next then
		player:set_turn_angle(movenode,movenode.next)
		v3d_lerp(player,movenode,movenode.next,pathlerp)
		if player.team==teams[2] and player.at%3==0 then
			local y=player.y+rnd_range(0,7)
			add(particles[table_row(y)],{x=player.x+rnd_range(0,7),y=y,vx=0,vy=-0.15,size=0.5,col=0,life=14+rnd_range(0,6)})
		end
	else
		player.p-=getmovep(movenode)
		player.x,player.y,cursor.x,cursor.y,cam_follow,player.action=movenode.x,movenode.y,movenode.x,movenode.y,cursor,nil
		player:set_anim(1)
		gen_path_map(flr(player.x/8),flr(player.y/8))
		sfx(-1,0)
	end
end

function init_action(next_func,follow)
	cam_follow,player.action=follow,next_func
	player:set_anim(3)
	player:set_turn_angle(player,target)
	if player.n_action==3 then
		sfx(player.fxs)
	end
end

function action_attack()
	init_action(action_attack_cont,player)
	sfx(player.fxa)
end

function action_attack_cont()
	if player.at>=13 then
		cam_follow=target
		local dmg,threat=rnd_range(player.dmn,player.dmx),1
		if rnd_range(0,100)<=player.hitchance then
			if player.n_action==3 then
				target.p,target.shocked,dmg,threat=0,true,player.sdmg,10
				add_floating_text("shocked",target,12,-6)
			end
			if dmg>0 then
				damage(target,dmg)
			end
		else
			add_floating_text("miss",target,8)
		end
		target.tl[player.i]+=threat
		player.p,player.action,wait=0,nil,60
	end
end

function action_grenade()
	new_grenade()
	init_action(action_grenade_cont,grenade)
	player.sa-=1
end

function action_grenade_cont()
	if grenade:update() then
		for t in all(teams) do
			for a in all(t) do
				local d=v3d_distance2d(v3d_add(a,new_vector3d(3,3,0)),grenade)
				if d<32 then
					damage(a,ceil((32-d)/32*player.sdmg))
				end
			end
		end
		grenade,player.p,player.action,wait={},0,nil,60
	end
end

function action_shock()
	init_action(action_attack_cont,player)
	player.sa-=1
end

function action_heal()
	init_action(nil,player)
	add_floating_text("+"..player.sdmg,target,14)
	target.hp,player.p,player.action,wait=min(target.hp+player.sdmg,100),0,nil,60
	player.sa-=1
end

function damage(a,dmg)
	dmg=flr(max(1,dmg*(100-a.a)/100))
	a.hp-=dmg
	add_floating_text("-"..dmg,a,9)
	if a.team~=player.team then
		a.tl[player.i]=(a.tl[player.i] or 0)+dmg
	end
	if a.hp<=0 then
		die(a)
	end
end

function die(p)
	for t in all(teams) do
		for tm in all(t) do
			if tm.pht==p then
				tm.pht=nil
			end
		end
	end
	if p.si==255 then
		new_actor(p.x,p.y,0.625,unit_types[4],teams[2])
		if p.spwnx then
			new_actor(p.spwnx,p.spwny,-0.625,unit_types[4],teams[2])
		end
		sfx(55)
	else
		for i=1,32 do
			add(particles[table_row(p.y)],{x=p.x+rnd(8),y=p.y-rnd_range(-4,14),vx=0,vy=0.5,size=0.25,col=p.cols[rnd_range(1,2)],life=rnd_range(8,26)})
		end
		sfx(8)
	end
	--del(p.team,del(actors[table_row(p.y)],p))
end

function wall_blocked(bvalc,bvaln,gz)
	return bvaln==255 or (bvalc!=254 and bvaln==254 and gz>-4)
end

function new_grenade(tracer)
	local d=tracer~=true and v3d_distance2d(player,cursor)/8*((100-player.sac)/100) or 0
	local x,y,z,vx,vy,vz,t,sx,sy,sw,sh=player.x+3,player.y+3,-4,(cursor.x-player.x+rnd_range(-d,d))*0.0275,(cursor.y-player.y+rnd_range(-d,d))*0.0275,-1.325,180,104,40,4,4
	grenade={
		x=x,y=y,z=z,
		path=tracer and new_line_table() or nil,
		step=function()
			local mapxc,mapyc,mapxn,mapyn=flr(x/8),flr(y/8),flr((x+vx)/8),flr((y+vy)/8)
			local bvalc,xover,yover=get_bval_actors(mapxc,mapyc),255,255
			if wall_blocked(bvalc,get_bval_actors(mapxn,mapyn),z) and not wall_blocked(bvalc,get_bval_actors(mapxc,mapyn),z) then
				xover=(x+vx)%8
				if vx<0 then
					xover-=8
				end
			end
			if wall_blocked(bvalc,get_bval_actors(mapxn,mapyn),z) and not wall_blocked(bvalc,get_bval_actors(mapxn,mapyc),z) then
				yover=(y+vy)%8
				if vy<0 then
					yover-=8
				end
			end
			
			if abs(xover)<abs(yover) then
				x=x+vx-xover
				vx=-vx
				y+=vy
			elseif abs(yover)<abs(xover) then
				y=y+vy-yover
				vy=-vy
				x+=vx
			elseif xover<255 then
				x,y=x+vx-xover,y+vy-yover
				vx=-vx
				vy=-vy
			else
				y+=vy
				x+=vx
			end
			z+=vz
			local groundz=get_bval(flr(x/8),flr(y/8))==254 and -4 or 0
			if z+vz>groundz then
				if not grenade.path then
					sfx(7)
				end
				z=groundz-(z+vz-groundz)
				vx,vy,vz=vx*0.6,vy*0.6,-vz*0.6
			end
			if abs(vx)+abs(vy)<0.1 then
				vx,vy,vz,z=0,0,0,groundz
			else
				vz=vz+0.125
			end
			grenade.x,grenade.y,grenade.z=x,y,z
		end,
		update=function()
			if t>60 then
				del(actors[table_row(y)],grenade)
				grenade:step()
				if t==61 then
					sfx(6)
				else
					add(actors[table_row(y)],grenade)
				end
			else
				local psize,particle_row=max(1,(t-10)/50*5),particles[table_row(y)]
				if t==60 or t==58 then
					add(particle_row,{x=x,y=y,vx=0,vy=0,size=32,col=10,life=2})
					for i=0,32 do
						add(particle_row,{x=x,y=y,vx=sin(i/32)*(rnd(1)+1),vy=cos(i/32)*(rnd(1)+1),size=1,col=10,life=rnd_range(14,24)})
					end
				end
				if t>40 then
					for i=1,ceil(psize) do
						local a=rnd(1)
						add(particle_row,{x=x+sin(a)*rnd(20-psize),y=y+cos(a)*rnd(20-psize),vx=0,vy=0,size=rnd(psize)+psize,col=rnd_range(8,10),life=1})
					end
				end
				if t<50 then
					for i=1,2 do
						local a=rnd(1)
						add(particle_row,{x=x+sin(a)*rnd_range(28,32),y=y+cos(a)*rnd_range(28,32),vx=0,vy=0.25,size=0.5,col=rnd_range(8,10),life=rnd_range(4,14)})
					end
				end
			end
			t-=1
			return t<=0
		end,
		draw=function()
			camera(cam_x,cam_y)
			local px,py=x-sw/2,y-sh/2
			for i=2,15 do
				pal(i,1)
			end
			sspr(sx,sy,sw,sh,px,py+(get_bval(flr(x/8),flr(y/8))==254 and -3 or 1))
			pal()
			sspr(sx,sy,sw,sh,px,py+z)
		end
	}
	if tracer then
		for i=1,120 do
			grenade:step()
			grenade.pathend=add(grenade.path[table_row(y)],new_vector3d(x,y,z))
		end
	end
end

function draw_attack(col)
	local x1,y1,v=player.x+3,player.y-5,col/3-2
	if player.at>10-v*2 and player.at<14 then
		for i=1,12 do
			local x2,y2=lerp(player.x+3,target.x+3,i/12)+rnd_range(-v,v),lerp(player.y-5,target.y-5,i/12)+rnd_range(-v,v)
			line(x1,y1,x2,y2,col)
			x1,y1=x2,y2
		end
	end
end

function set_colors(cols)
	pal(3,cols[1])
	pal(11,cols[2])
end

function draw_sprite_part(sp,x,y,i)
	local sprites=sp.sprites
	local sprite=sprites.sprs[i]
	sspr(sprite.x,sprite.y,sprites.w,sprites.h,x+sprite.ox,y+sprite.oy,sprites.w,sprites.h,sprite.f~=0)
end

function find_los(origin,dest,maxdist)
	local dist_v=v3d_sub(dest,origin)
	local dist=v3d_length(dist_v)
	if dist>maxdist or abs(dist_v.x)>maxdist or abs(dist_v.y)>maxdist then
		return -2
	end
	
	local mapx,mapy,dir_vector=flr(origin.x/8),flr(origin.y/8),new_vector3d(dist_v.x/dist,dist_v.y/dist,dist_v.z/dist)
	local step,blockm,hitchance,dx,dy=get_intersection_step(3,3,dir_vector),1,min(100,106-dist*0.75),flr(dest.x/8),flr(dest.y/8)
	for i=0,32 do
		mapx+=step[2].x
		mapy+=step[2].y
		step=get_intersection_step(step[1].x+step[2].x*-8,step[1].y+step[2].y*-8,dir_vector)
		if mapx==dx and mapy==dy then
			return flr(hitchance*blockm)
		end
		local m=get_bval(mapx,mapy)
		if m==255 then
			return -1
		elseif m==254 then
			if abs(dx-mapx)<=1 and abs(dy-mapy)<=1 then
				blockm=0.5
			end
		else
			for a in all(actors[mapy+1]) do
				if a~=player and a.x==mapx*8 then
					return -1
				end
			end
		end
	end
	return -2
end

function get_bval(x,y)
	local m=oget(x,y)
	if m>=254 then
		return m
	elseif m>0 and m<=#mapspr then
		return mapspr[m].bval
	end
end

function get_bval_actors(x,y)
	for t in all(teams) do
		for a in all(t) do
			if a~=player and a.x==x*8 and a.y==y*8 then
				return 255
			end
		end
	end
	return (x<0 or y<0 or x>63 or y>31) and 255 or get_bval(x,y)
end

function get_intersection_step(ox,oy,d_vector)
	local tx,ix,stepx = get_time_intersect_step(ox,d_vector.x)
	local ty,iy,stepy = get_time_intersect_step(oy,d_vector.y)
	
	if (tx < ty) then
		iy,stepy=oy+d_vector.y*tx,0
	else
		ix,stepx=ox+d_vector.x*ty,0
	end
	
	return {new_vector3d(ix,iy),new_vector3d(stepx,stepy)}
end

function get_time_intersect_step(p,d)
	if d == 0 then
		return 32761,p,0
	end
	
	local ood = 1 / d
	local t1,t2 = -p * ood, (7-p) * ood
	local t = t1 > t2 and t1 or t2
	return t, round(p+d*t), ood < 0 and -1 or 1
end

-- path finding
function checkn(x,y,parent,mcost)
	if mapgrid[x] then
		local node,g,canadd=mapgrid[x][y],parent.g+mcost,true
		if node and not node.closed and not node.impassable and g<=104 then
			if g<=node.g then
				node.g,node.parent = g,parent
				if target then
					node.f=abs(target.x-node.x)+abs(target.y-node.y)
					if node.f<nodef then
						nodef,movenode=node.f,node
					end
				end
			end
			for o in all(olist) do
				if o==node then
					canadd=false
					break
				end
			end
			if canadd then
				add(olist,node)
			end
			return true
		end
	end
end

function findn(x,y)
	local node=mapgrid[x][y]
	node.closed=true
	local l,r=checkn(x-1,y,node,10),checkn(x+1,y,node,10)
	findnd(x,y-1,node,l,r)
	findnd(x,y+1,node,l,r)
end

function findnd(x,y,node,l,r)
	if checkn(x,y,node,10) then
		if (l) checkn(x-1,y,node,14)
		if (r) checkn(x+1,y,node,14)
	end
end

function gen_path_map(ox,oy)
	target,highest_threat=player.pht,player.pht and player.tl[player.pht.i] or 0
	for e in all(teams[team_i%2+1]) do
		e.los=find_los(player,e,128)
		if e.los>0 then
			player.tl[e.i],e.tl[player.i]=player.tl[e.i] or 1,e.tl[player.i] or 1
		end
		local et=player.tl[e.i]
		if et and et>highest_threat then
			highest_threat,target,player.pht=et,e,e
		end
	end
	mapgrid,mgx,mgy={},max(ox-13,0),max(oy-13,0)
	for x=1,min(ox+11,64)-mgx do
		mapgrid[x]={}
		for y=1,min(oy+11,32)-mgy do
			local mx,my=mgx+x-1,mgy+y-1
			mapgrid[x][y]={x=mx*8,y=my*8,z=0,gx=x,gy=y,g=32761,impassable=oget(mx,my)>7}
			for a in all(actors[my+1]) do
				if a~=player and a.x==mx*8 then
					mapgrid[x][y].impassable=true
					break
				end
			end
		end
	end
	local onode=mapgrid[ox-mgx+1][oy-mgy+1]
	onode.g,olist,movenode,nodef=0,{onode},nil,target and abs(target.x-onode.x)+abs(target.y-onode.y) or 32761
	onode.f=nodef
	while #olist>0 do
		local cur=olist[1]
		del(olist,cur)
		findn(cur.gx,cur.gy)
	end
	movelines={}
	if player.p==2 then
		getmovelines(104,14)
		getmovelines(64,12)
	else
		getmovelines(24,12)
	end
end

function getmovelines(maxval,c)
	local sgmin=16
	for x=1,#mapgrid do
		for y=1,#mapgrid[x] do
			local mg=mapgrid[x][y]
			if mg.g<=maxval then
				if x==1 or mapgrid[x-1][y].g>maxval then
					add(movelines,{mg.x,mg.y,mg.x,mg.y+7,c})
				end
				if y==1 or mapgrid[x][y-1].g>maxval then
					add(movelines,{mg.x,mg.y,mg.x+7,mg.y,c})
				end
				if x==#mapgrid or mapgrid[x+1][y].g>maxval then
					add(movelines,{mg.x+7,mg.y,mg.x+7,mg.y+7,c})
				end
				if y==#mapgrid[x] or mapgrid[x][y+1].g>maxval then
					add(movelines,{mg.x,mg.y+7,mg.x+7,mg.y+7,c})
				end
			end
			if mg.g>0 and mg.g<sgmin then
				sgmin,player.spwnx,player.spwny=mg.g,mg.x,mg.y
			end
		end
	end
end

function get_cursor_node()
	local cur_x,cur_y = flr(cursor.x/8),flr(cursor.y/8)
	if cur_x >= mgx and cur_x < mgx+#mapgrid and cur_y >= mgy and cur_y < mgy+#mapgrid[1] then
		return mapgrid[cur_x-mgx+1][cur_y-mgy+1]
	end
end

function getmovep(node)
	return (node and node.g > 0) and (node.g <= (player.p == 2 and 64 or 24) and 1 or node.g <= 104 and 2) or 3
end

function oset(x,y,val)
	poke(0x4300+y*64+x,val)
end

function oget(x,y)
	return peek(0x4300+y*64+x)
end

function gen_map()
	memset(0x4300,0,4096)
	memset(0x2000,0,4096)
	
	rooms,outside_blockers,cursor={},{},new_vector3d(16,16)
	cam_follow,player_i,team_i,enemy_room = cursor,0,1,0
	for i=0,31 do
		local r=try_place_object(rnd_range(3,4)*3,rnd_range(3,4)*3,2,2,60,27,3,rooms,room_types[max(1,rnd_range(0,#room_types))])
		if r then
			add(outside_blockers,{r[1]-1,r[2]-1,r[3]+2,r[4]+2})
		end
		for x=0,63 do
			mset(x,i,rnd_range(134,140))
		end
	end
	
	for r1 in all(rooms) do
		for y=r1[2],r1[4] do
			for x=r1[1],r1[3] do
				if (x==r1[1] or x==r1[3] or y==r1[2] or y==r1[4]) and oget(x,y)<r1.type.w then
					oset(x,y,r1.type.w)
				end
				if mget(x,y)~=192 then
					mset(x,y,r1.type.f[rnd_range(1,#r1.type.f)])
				end
			end
		end
	end
	for r1 in all(rooms) do 	
		for r2 in all(rooms) do
			if r1 ~= r2 then
				for i=1,2 do
					if r1[i] == r2[i+2] then
						local i1,i2=i%2+1,i%2+3
						local y1,y2 = max(r1[i1],r2[i1]),min(r1[i2],r2[i2])
						if y1 < y2 then
							add_door(r1[i],y1,y2,i==2,r1,r2)
							r1.doors[i],r2.doors[i+2] = true,true
						end
					end
				end
			end
		end
	end
	for r1 in all(rooms) do
		for i=1,4 do
			if not r1.doors[i] then
				add_door(r1[i],r1[i%2+1],r1[i%2+3],i%2==0,r1)
			end
		end
		local prop = props[r1.type.p[1]]
		local proprect = add(r1.blockers,new_rect(r1[1]+flr(r1.w/2-prop.tw/2)+1,r1[2]+flr(r1.h/2-prop.th/2)+1,prop.tw,prop.th))
		place_prop(proprect[1],proprect[2],prop.sprs)
		for i=2,#r1.type.p do
			prop = props[r1.type.p[i]]
			local room_pos = room_positions[prop.rp[rnd_range(1,#prop.rp)]]
			local px,py = room_pos[3],room_pos[4]
			-- mx = 0 or 1 (against left or right)
			-- px = 0 or 1 (edge or center)
			local blocker = try_place_object(prop.tw,prop.th,r1[1]+(r1.w-1-prop.tw)*room_pos[1],r1[2]+(r1.h-1-prop.th)*room_pos[2],r1.w*px-px-prop.tw*(px-1),r1.h*py-py-prop.th*(py-1),1,r1.blockers)
			if blocker then
				place_prop(blocker[1],blocker[2],prop.sprs)
			end
		end
	end
	
	for y=2,31 do
		for x=3,62 do
			local m,x1,y1 = oget(x,y),x+1,y+1
			if m==0 then
				mset(x+64,y,get_shadow_val(x,y)+112)
			else
				local wall_type = get_wall_type(m)
				if wall_type then
					local r,b = oget(x1,y),oget(x,y1)
					if is_wall(r,wall_type) then
						oset(x1,y,r+1)
						m+=4
					end
					if is_wall(b,wall_type) then
						oset(x,y1,b+2)
						m+=8
					end
					oset(x,y,m)
					mset(x,y,0)
				end
			end
			if rnd()<0.05 and try_place_object(1,1,x-1,y-1,1,1,1,outside_blockers) then
				place_prop(x,y,props[rnd_range(21,22)].sprs)
			end
		end
	end
	local el={}
	for i=1,12+mission do
		el[i]=flr(i/29*4)+4
	end
	while #el>0 do
		local r1=rooms[enemy_room+1]
		enemy_room=(enemy_room+1)%#rooms
		local a=try_place_object(1,1,r1[1]+1,r1[2]+1,r1.w-2,r1.h-2,1,r1.blockers)
		if a then
			local ei=del(el,el[rnd_range(1,#el)])
			new_actor(flr(a[1]*8),flr(a[2]*8),0.5,unit_types[ei],teams[2])
		end
	end
	for i=1,4 do
		nextplayer()
	end
end

function table_row(y)
	return round(y/8+1)
end

function new_line_table()
	local t={}
	for i=1,32 do
		t[i]={}
	end
	return t
end

function place_prop(px,py,prop_sprs)
	for j=1,#prop_sprs do
		local sprite = mapspr[prop_sprs[j]]
		for y=0,sprite.th-1 do
			for x=0,sprite.tw-1 do
				oset(px+sprite.gx+x,py+sprite.gy+y,sprite.bval)
			end
		end
		oset(px+sprite.gx,py+sprite.gy+sprite.th-1,prop_sprs[j])
	end
end

function get_shadow_val(x,y)
	local val = 0
	if (oget(x-1,y)>7) val += 1
	if (oget(x,y-1)>7) val += 2
	if (oget(x-1,y-1)>7) val += 4
	return val
end

function get_wall_type(m)
	return (m >= 8 and m <= 23) and 8 or ((m >= 24 and m <= 39) and 24 or nil)
end

function is_wall(m,val)
	return m >= val and m <= val+15
end

function add_door(x,y1,y2,flip,r1,r2)
	if y2-y1 > 3 then
		y1 += 1
		y2 -= 1
	end
	local y,xp,yp = rnd_range(y1+1,y2-2),0,1
	if flip then
		x,y,xp,yp = y,x,yp,xp
	end
	oset(x,y,0)
	oset(x+xp,y+yp,0)
	local r = add(r1.blockers,new_rect(x-yp,y-xp,2+yp,2+xp))
	if r2 then
		add(r2.blockers,r)
	end
end

function rnd_range(vmin,vmax)
	return vmin+flr(rnd(vmax-vmin+1))
end

function new_rect(x,y,w,h,rtype)
	return {x,y,x+w,y+h,w=w,h=h,blockers={},type=rtype,doors={}}
end

function try_place_object(w,h,bx,by,bw,bh,grid_size,list,rtype)
	for i=1,30 do
		local new_r,can_add = new_rect(bx+1+flr(rnd_range(0,bw-1-w)/grid_size)*grid_size,by+1+flr(rnd_range(0,bh-1-h)/grid_size)*grid_size,w,h,rtype),true
		for r in all(list) do
			if not (new_r[3] <= r[1] or new_r[4] <= r[2] or new_r[1] >= r[3] or new_r[2] >= r[4]) then
				can_add = false
				break
			end
		end
		if can_add then
			return add(list,new_r)
		end
	end
end

-- load & save
function read_sprites_and_anims()
	si,bo=0,0x2000
	sprites,anims,models,unit_types,mapspr,props,room_positions,room_types,btns,pals,skilltree=parse_table(),parse_table(),parse_table(),parse_table(),parse_table(),parse_table(),parse_table(),parse_table(),parse_table(),parse_table(),parse_table()
end

function parse_table()
	si+=1
	local key,ti,t=1,1,{}
	while si<=#mapdata do
		local c,w=sub(mapdata,si,si),false
		if c=="@" then
			t[ti],w,key=key,true,ti
		elseif c=="#" then
			t[key],w=peek(bo),true
			bo+=1
		elseif c=="$" then
			t[key],w=(peek(bo)-128)/16,true
			bo+=1
		elseif c=="{" then
			t[key],w=parse_table(),true
		elseif c=="}" then
			break
		else
			key=key==ti and c or key..c
		end
		if w then
			if key==ti then
				ti+=1
			end
			key=ti
		end
		si+=1
	end
	return t
end

-- vector & matrix
function new_vector3d(x,y,z)
	return {x=x and x or 0,y=y and y or 0,z=z and z or 0}
end

function v3d_add(a,b)
	return new_vector3d(a.x+b.x,a.y+b.y,a.z+b.z)
end

function v3d_sub(a,b)
	return new_vector3d(a.x-b.x,a.y-b.y,a.z-b.z)
end

function v3d_dot(a,b)
	local d=new_vector3d(a.x*b.x,a.y*b.y,a.z*b.z)
	return d.x+d.y+d.z
end

function v3d_length(a)
	if a.x+a.y+a.z<256 then
		local d = v3d_dot(a,a)
		if d >= 0 then
			return sqrt(d)
		end
	end
	return 32761
end

function v3d_distance2d(a,b)
	return v3d_length(new_vector3d(a.x-b.x,a.y-b.y,0))
end

function matrix_rotate_x(a)
	return {{1,0,0},{0,sin(a),cos(a)},{0,cos(a),-sin(a)}}
end

function matrix_rotate_y(a)
	return {{cos(a),0,sin(a)},{-sin(a),0,cos(a)},{0,1,0}}
end

function matrix_mul_add_row(m_row,v)
	return m_row[1]*v.x+m_row[2]*v.y+m_row[3]*v.z
end

function matrix_mul_add(m,v)
	return new_vector3d(matrix_mul_add_row(m[1],v),matrix_mul_add_row(m[2],v),matrix_mul_add_row(m[3],v))
end

function table_insert(t,item,index)
	if index<1 or index>#t then
		add(t,item)
	else
		for i=#t,index,-1 do
			t[i+1]=t[i]
		end
		t[index]=item
	end
end

function lerp(a,b,t)
	return a+(b-a)*t
end

function v3d_lerp(c,a,b,t)
	c.x,c.y,c.z=lerp(a.x,b.x,t),lerp(a.y,b.y,t),lerp(a.z,b.z,t)
end

function round(a)
	return a < 0 and ceil(a-0.5) or flr(a+0.5)
end

mapdata="{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy#f#}}w#}{h#sprs{{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy#f#}{x#y#ox$oy#f#}{x#y#ox$oy#f#}{x#y#ox$oy#f#}{x#y#ox$oy#f#}{x#y#ox#oy#f#}{x#y#ox#oy#f#}{x#y#ox#oy#f#}{x#y#ox#oy#f#}{x#y#ox#oy#f#}{x#y#ox#oy#f#}{x#y#ox$oy#f#}{x#y#ox$oy#f#}{x#y#ox$oy#f#}{x#y#ox$oy#f#}{x#y#ox$oy#f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox#oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox#oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}{x#y#ox$oy$f#}}w#}{h#sprs{{x#y#ox$oy$f#}}w#}}{{{l#a#p{x#y$z#}}{l#a#p{x#y$z#}}{l#a#p{x$y$z$}}{l#a#p{x$y#z#}}{l#a#p{x$y#z#}}{l#a#p{x#y$z#}}{l#a#p{x#y$z#}}t#}on_finish#}{{{l#a#p{x$y#z$}}{l#a#p{x$y#z$}}{l#a#p{x#y$z$}}{l#a#p{x$y$z$}}{l#a#p{x#y$z$}}t#}{{l#a#p{x$y#z#}}{l#a#p{x$y$z#}}{l#a#p{x#y$z$}}{l#a#p{x$y$z$}}{l#a#p{x#y$z$}}t#}{{l#a#p{x$y#z$}}{l#a#p{x$y#z$}}{l#a#p{x#y$z$}}{l#a#p{x$y$z$}}{l#a#p{x#y$z$}}t#}{{l#a#p{x$y$z#}}{l#a#p{x$y#z#}}{l#a#p{x#y$z$}}{l#a#p{x$y$z$}}{l#a#p{x#y$z$}}t#}on_finish#}{{{l#a$p{x#y$z$}}{l#a#p{x#y$z$}}t#}{{l#a$p{x#y$z$}}{l#a#p{x#y$z$}}t#}{{l#a$p{x#y$z$}}{l#a#p{x#y$z$}}t#}on_finish#}{{{l#a#p{x#y$z#}}{l#a#p{x#y$z$}}{l#a#p{x#y$z#}}t#}{{l#a#p{x#y$z#}}{l#a#p{x#y$z$}}{l#a$p{x#y$z#}}t#}on_finish#}{{{l#a#p{x#y$z#}}{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a$p{x$y#z$}}{l#a$p{x$y#z$}}{l#a#p{x#y$z$}}t#}{{l#a#p{x#y$z#}}{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a$p{x$y#z$}}{l#a#p{x#y$z$}}t#}{{l#a#p{x#y$z#}}{l#a$p{x$y#z$}}{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a#p{x#y$z$}}t#}{{l#a#p{x#y$z#}}{l#a$p{x$y#z$}}{l#a$p{x$y#z$}}{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}{l#a#p{x#y$z$}}t#}on_finish#}{{{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a#p{x#y$z#}}{l#a#p{x#y$z#}}t#}{{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}{l#a$p{x$y$z#}}{l#a$p{x$y#z#}}{l#a#p{x#y$z#}}{l#a#p{x#y$z#}}t#}{{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}{l#a#p{x#y$z#}}{l#a#p{x#y$z#}}t#}{{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a$p{x$y#z#}}{l#a$p{x$y$z#}}{l#a#p{x#y$z#}}{l#a#p{x#y$z#}}t#}on_finish#}{{{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z#}}{l#a$p{x$y#z$}}{l#a$p{x$y#z$}}t#}{{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z#}}t#}on_finish#}{{{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z#}}{l#a#p{x#y$z$}}{l#a$p{x$y#z$}}t#}{{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z#}}{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}t#}{{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z#}}{l#a$p{x$y#z$}}{l#a#p{x$y$z$}}t#}{{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z$}}{l#a#p{x#y$z#}}{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}t#}on_finish#}{{{l#a#p{x#y$z#}}{l#a#p{x#y$z$}}{l#a$p{x$y$z#}}{l#a$p{x$y$z$}}{l#a$p{x#y$z$}}{l#a#p{x$y$z$}}{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a#p{x$y$z$}}{l#a$p{x$y$z$}}t#}{{l#a$p{x$y$z#}}{l#a$p{x$y$z$}}{l#a$p{x#y$z#}}{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a$p{x$y$z$}}{l#a$p{x$y#z$}}{l#a#p{x$y$z$}}{l#a$p{x#y$z#}}t#}on_finish#}{{{l#a#p{x#y$z#}}{l#a#p{x#y$z$}}{l#a$p{x$y$z#}}{l#a$p{x$y$z$}}{l#a$p{x#y$z$}}{l#a#p{x$y$z$}}{l#a#p{x$y#z$}}{l#a#p{x$y$z$}}{l#a#p{x$y#z$}}{l#a#p{x$y$z$}}{l#a$p{x#y$z#}}t#}on_finish#}}{{{x#y$z#}##}{{x#y$z#}##}{{x$y$z$}##}{{x$y#z#}##}{{x$y#z#}##}{{x#y$z#}##}{{x#y$z#}##}}{{{x#y$z#}##}{{x#y$z$}##}{{x#y$z#}##}}{{{x#y$z#}##}{{x#y$z#}##}{{x$y$z$}##}{{x$y#z#}##}{{x$y#z#}##}{{x#y$z#}##}{{x#y$z#}##}}{{{x#y$z#}##}{{x#y#z$}$#}{{x$y#z$}$#}{{x$y#z$}$#}{{x$y#z$}$#}{{x#y$z$}##}}{{{x#y$z#}##}{{x#y$z#}##}{{x$y$z$}##}{{x$y#z#}##}{{x$y#z#}##}{{x#y$z#}##}{{x#y$z#}##}}{{{x#y$z$}##}{{x#y$z$}##}{{x#y$z$}##}{{x#y$z#}##}{{x$y#z$}$#}{{x$y#z$}$#}}{{{x#y$z#}##}{{x#y$z$}##}{{x$y$z#}$#}{{x$y$z$}$#}{{x#y$z$}$#}{{x$y$z$}##}{{x$y#z$}$#}{{x$y$z$}$#}{{x$y#z$}$#}{{x$y$z$}##}{{x#y$z#}$#}}}{p#stt#cols{##}sdmg#fxs#z#sac#sa#am#sy#a#si#sr#sf#ai#fxm#ac#dmx#dmn#sx#hp#fxa#m#at#aa#}{p#stt#cols{##}sdmg#fxs#z#sac#sa#am#sy#a#si#sr#sf#ai#fxm#ac#dmx#dmn#sx#hp#fxa#m#at#aa#}{p#stt#cols{##}sdmg#fxs#z#sac#sa#am#sy#a#si#sr#sf#ai#fxm#ac#dmx#dmn#sx#hp#fxa#m#at#aa#}{p#stt#cols{##}sdmg#fxs#z#sac#sa#am#a#si#sr#ai#fxm#sf#ac#dmx#dmn#hp#fxa#m#at#aa#}{p#stt#cols{##}sdmg#fxs#z#sac#sa#am#a#si#sr#ai#fxm#sf#ac#dmx#dmn#hp#fxa#m#at#aa#}{p#stt#cols{##}sdmg#fxs#z#sac#sa#am#a#si#sr#ai#fxm#sf#ac#dmx#dmn#hp#fxa#m#at#aa#}{p#stt#cols{##}sdmg#fxs#z#sac#sa#am#a#si#sr#ai#fxm#sf#ac#dmx#dmn#hp#fxa#m#at#aa#}}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}{tw#gx#gy#w#x#y#bval#th#h#}}{rp{#}tw#sprs{#}th#}{rp{#}tw#sprs{#}th#}{rp{###}tw#sprs{#}th#}{rp{###}tw#sprs{#}th#}{rp{##}tw#sprs{#}th#}{rp{##}tw#sprs{#}th#}{rp{#}tw#sprs{####}th#}{rp{#}tw#sprs{#}th#}{rp{##}tw#sprs{#}th#}{rp{##}tw#sprs{#}th#}{rp{#}tw#sprs{#}th#}{rp{####}tw#sprs{#}th#}{rp{#}tw#sprs{##}th#}{rp{#}tw#sprs{##}th#}{rp{#}tw#sprs{#}th#}{rp{#}tw#sprs{##}th#}{rp{#}tw#sprs{#}th#}{rp{#}tw#sprs{##}th#}{rp{#}tw#sprs{#}th#}{rp{###}tw#sprs{#}th#}{rp{}tw#sprs{#}th#}{rp{}tw#sprs{#}th#}}{####}{####}{####}{####}{####}}{p{######}f{##}w#}{p{########}f{##}w#}{p{#######}f{##}w#}{p{####}f{####}w#}{p{#########}f{####}w#}{p{#####}f{####}w#}{p{#####}f{####}w#}}{y2#x2#x1#y1#i#}{y2#x2#x1#y1#i#}{y2#x2#x1#y1#}}{#############}{#############}{#############}{#############}{#############}{#############}}{{{x#m{a#}t#s#}{x#m{sa#}t#s#}}{{x#m{dmn#dmx#}t#s#}{x#m{ac#}t#s#}}{{x#m{sac#sdmg#}t#s#}{x#m{sa#}t#s#}}{{x#m{dmn#dmx#}t#s#}{x#m{a#}t#s#}}{{x#m{sac#sdmg#}t#s#}{x#m{sa#}t#s#}}}{{{x#m{dmn#dmx#}t#s#}{x#m{sa#}t#s#}}{{x#m{ac#}t#s#}{x#m{a#}t#s#}}{{x#m{sac#sdmg#}t#s#}{x#m{sa#}t#s#}}{{x#m{ac#}t#s#}{x#m{dmn#dmx#}t#s#}}{{x#m{sac#sdmg#}t#s#}{x#m{sa#}t#s#}}}{{{x#m{ac#}t#s#}{x#m{sa#}t#s#}}{{x#m{a#}t#s#}{x#m{dmn#dmx#}t#s#}}{{x#m{sdmg#sr#}t#s#}{x#m{sa#}t#s#}}{{x#m{a#}t#s#}{x#m{ac#}t#s#}}{{x#m{sdmg#sr#}t#s#}{x#m{sa#}t#s#}}}text{armour +15%@accuracy +12%@gun damage +7@grenade damage +10\ngrenade accuracy +50%@shock deals +10 damage\nshock accuracy +15%@healing +25\nhealing range +1@1 additional grenade@1 additional shock charge@1 additional medkit@}}"
