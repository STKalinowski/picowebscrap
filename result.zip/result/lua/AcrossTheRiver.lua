-- across the river
-- benjamin soule
spos={4,1,2,0,6,5,3}


function _init()
 t=0
 
 ents={}
 plats={}
 tweens={}
 anims={}
 dls={}
 stars={}
 for i=0,32 do 
  s={}
  s.x,s.y,s.m=rand(128),rand(64),rnd(1)
  add(stars,s)
 end 
 --plats
 left=mkp(0,48,64)
 right=mkp(192,48,64)
 btpl=mkp(64,50,24)

 left.sd=0
 right.sd=1
 
 --
 cx=0
 init_menu()
 
 
end

function init_menu()
 music(0)
 upd=upm
 
 ldr=function()
  print("across the river",29,37,7)
 end 
 
end

function upm()
 r=200
 cx=64+cos((t%r)/r)*64
 if btnp(4) then
  music(-1,2000)
  ldr=nil
  init()
 end
 
end


function init()
 moves=0
 win=nil
 playing=1
 ents={}
 side=0
 from_side=0
 t=0
 for i=0,6 do
  e=mke()
  e.id=i
  e.sd=0
  e.open=0
  e.fr=64+i
  e.x=gix(e)
  e.y=44
 end
 
 h=mke()
 h.fr=48
 h.x=44
 h.dp=1
 h.y=44
 upd=play
 h.pl=left
 
 bt=mke()
 bt.dp=2
 bt.x=68
 bt.y=53
 bt.fr=43
 bt.sw=3
 
 ldr=dri

end

function dri()
 
 for i=0,6 do
  
  if( not git(i,1) ) apal(1)
  dead=true
  for e in all(ents) do if(e.id==i) dead=false end
  if( dead ) apal(2)
  y=23
  if win then
   co=8+((t/4+i)%8)
   apal(co)
   c=cos(((t+i*2)%20)/20)
   c2=cos(((t+i*2)%44)/44)
   c3=cos(((t+i*2)%70)/70)
   y+=c*1+0.5
   ecy=7-i
   ecy*=(1+abs(c3*3))
   print("congratulations",32+c2*(24-i*3)+0.5,96+ecy,co)
  end
  fspr(64+i,73+i*8,y)
  pal()
 end
 
 st="moves:"..moves
 if(win) st=st.." best:27"
 print(st,0,25,10)
 
 if(win) return
 
 -- inst
 ins=nil
 by=97
 
 color(7)
 if h.pl then
  if h.lf then
   n=gnm(h.lf)
   ins="drop "..n
   if it and it.id==2 and is_small(h.lf) then
    ins="put "..n.." in the washing.m"
   end
  else
   if it then
    n=gnm(it)
    ins="grab "..n
   end
  end
 end
 
 if ins then
  sspr(105,8,5,5,1,by)
  print(ins,8,by,7)
  by+=6
 end 
 
 if h.lf and h.lf.id==3 then
  print("(z) shoot",1,by)
  by+=6
 end

 
 
  
end

function gnm(e)
 n={"wolf","hunter","washing machine","gun","cabbage","goat","monkey"}
 return n[1+e.id]
end


function mkp(x,y,w)
 p={}
 p.x,p.y,p.w=x,y,w
 add(plats,p)
 return p
end


function play()
 upd_boat()
 move()
 if(btnp(5)) white(do_load)
 for i=0,3 do if(btn(i)) still=nil end

end

function white(f)
 upd=nil
 sfx(17)
 wh={}
 wh.c=0
 wh.s=5
 wh.f=f
 
 return wh
 
end

function move()
 spd=1
 hdx=0
 if(btn(0)) hdx=-spd
 if(btn(1)) hdx=spd
 if(hdx!=0) h.lk=0.5+hdx/2
 if(pwm and pwm>0 ) hdx=0
 if h.pl then
  move_pl()
 else
  move_jmp()
 end
 
 --
 l=h.lf
 if l!=nil then
  l.x=h.x
  l.y=h.y-7
  s=h.lk*2-1
  if h.gun then
   l.y+=5
   l.x+=s*3
   l.lk=h.lk
  end
 end
 
 -- escape
 if not fear and h.lf!=nill 
 and h.lf.id==1 and h.pl!=nil and h.pl!=btpl
 and abs(bt.x+8-h.x)<36 then escape(h.lf) end
 
 -- fear
 local ht=git(1)
 if ht and fear then
  dx=ht.x-h.x
  s=dx/abs(dx)
  ht.lk=0.5-s/2
  ht.fr=65
  if abs(dx)<12 then
   ht.fear=1
   ox=ht.x
   ht.x=mid(8,ht.x+s,248)
   if(t%8<4 and ox!=ht.x ) ht.fr=113
  end
  if abs(bt.x+8-ht.x) < 32 then
   ht.fear=nil
   sfx(4)
   gtb(ht)
  end
 end
 if ht and ht.fear and not fear then
  back(ht)
 end
 
 -- glob
 for i=0,1 do chk_global(i) end
 
 -- check end
 sum=0
 for i=0,6 do e=git(i,1) if( e and e.y==44 ) sum+=1 end
 if sum==7 then
  music(1)
  upd=outro
 end
 
 -- res
 if(side==0 and bt.x>132) resolve()
 if(side==1 and bt.x<106) resolve()

end

function outro()
 win=1
 
 k=(t%40)/40
 h.y=44-abs(sin(k))*8
 h.fr=20
 if(t%20>10) h.fr=21
 
 upd_boat()
 
end

function chk_global(sd)
 m=git(6,sd)
 c=git(4,sd)
 w=git(0,1-sd)
 if( m and c and w ) then
  wo=w
  upd=nil
  act=m
  trg=c
  f=function() 
   
   take(function() dl(10,wshoot) end) 
  end
  mv(m,c.x,f)
  return true
 end
 return false 
end

function wshoot()
 sfx(19)
 act.ins=nil
 gtf(act,0)
 gtf(trg,0)

 w=twm(trg,wo.x,wo.y-4)
 w.j=16
 w.s=0.05
 w.f=function()
  sfx(20)
  back(act)
  drop(trg,wo.sd)
  mv(wo,128+(wo.sd*2-1)*136, function() kl(wo) upd=play end )
 end
end


function gtb(e)
 if(h.lf==e) release()
 e.sd=-1
 e.dp=0
 f=function() sfx(7) bt.it=e gtf(e,0) end
 jmp(e,bt.x+8,bt.y-6,f)
end

function move_pl()
 sfr(36)
 
 -- walk
 p=h.pl
 ox=h.x
 h.x+=hdx
 h.y=p.y-4 
 h.x=mid(p.x+3,h.x,p.x+p.w-3)
 if(ox!=h.x and t%8<4) then
  if(t%8==0)sfx(5)
  h.fr+=1
 end
 -- move boat
 if hdx!=0 and ox==h.x then 
  if h.pl==btpl and not bt.sink then
   obx=bt.x
   bt.x+=hdx
   
   bt.x=mid(68,bt.x,256-68-16)
   if obx!=bt.x then
    if(t%8==0) sfx(22)
    h.x+=hdx
   end
  end
 end
 
 -- near
 it=seek_itm(3)

 -- lift wm
 ht=git(1)
 if(ht and ht.y!=44) ht=nil
 if it!=nil and it.id==2 and not h.lf 
  and btn(3) and h and not it.ins then
  h.fr=22
  if(t%8<4) h.fr+=1
  if(t%8==0) sfx(12)
  pwm+=1
  if pwm>12 then 
   if h.pl==btpl then
    grab(it)
   else if ht then
    if abs(ht.x-it.x)>4 then
     ht.x+=ht.lk*0.5
     ht.dp=0
    else
     ht.fr=120
     if(t%8<4) ht.fr+=1
    end
    if pwm>60 then
     gtf(ht,0)
     grab(it)
     back(ht)
    end end
   end
  end
 else
  if(ht and pwm and pwm>0 ) back(ht)
  if(not btn(3)) pwm=0
 end

 
 -- lift
 local l=h.lf
 
 if btnp(3) and pwm==0 then	
 
  if l then
   -- insert
   if it!=nil and it.id==2 and is_small(l) then
    swp=it.ins
    it.ins=l
    l.fr=0
    release()
    sfx(11)
    gtf(it,0)
   
    if(swp) grab(swp)    
   end
     
   -- drop
   if l.fr>0 then
    drop(l)
   end

  else
   
   if it!=nil and it.dp==0 then
    if it.id==2 then
     if it.ins then
      grab(it.ins)
					 it.ins=nil
					 gtf(it,0)
					 sfx(10)
     end
    else
     grab(it)
    end
   end
  end
 end
 
 -- action
 if btnp(4) then
  if l then 
   use_itm(l)
  end
 end
 
 -- jump
 if btnp(2) then
  sfx(4)
  h.pl=nil
  h.vy=-4
  h.we=0.4
  for p in all(plats) do p.above=true end
 end 
 
 --
 if h.y>68 then
  white(do_load)
 end
 
end

function back(e)
 gtf(e,0)
 mv(e,gix(e),function() e.lk=1-side end) 
end

function drop(e,sd)
 
 if not sd then
  sfx(9) 
  if h.pl==btpl then
   if( not bt.it ) gtb(e)
   return
  end
  release()
  sd=side
 end
 
 e.sd=sd
 tx=gix(e)
 w=twm(e,tx,44)
 w.j=16
 w.f=function() sfx(7) e.dp=0 gtf(e,0) end
end

function grab(e,qt)
 if( not qt ) sfx(8)
 if(bt.it==e) bt.it=nil
 h.lf=e
 e.dp=2
 gtf(e,1)
 e.sd=-1
	h.gun=e.id==3
end

function is_small(e)
 return fget(64+e.id,0)
end

function use_itm(it)
 
 if it.id==3 then
  fear=1
  shoot(h)
 end
 
end

function sfr(fr)
 h.fr=fr
 if h.lf then 
  h.fr-=16
  if(h.gun) h.fr-=16
 end
 
end

function move_jmp()
 sfr(37)
 if(btnp(4) and h.lf) use_itm(h.lf) 
 h.x=mid(2,h.x+hdx,254)
 
 if(h.y>68 and h.sink) then

  white(do_load)
  
  return
 end
 
 if h.y>53 then
  if( not h.sink ) splash()
  h.sink=1
 end

 -- test plat
 if(h.vy<=0) return
 for p in all(plats) do
  if p.above  then
   if h.y>p.y-4 then 
    p.above=false
    dx=h.x-p.x
    if dx>=0 and dx<p.w then
     sfx(7)
     if p.sd==1-from_side then
      from_side=side
      moves+=1
      do_save()
     end
     
     h.pl=p
     h.y=p.y-4
     if(p==btpl) chk_sink()
     break
    end
   end
  end
 end
 
 -- drowning
 h.f=1
 if h.y>50 then
  h.f=0.5
  h.x=mid(66,h.x,256-66)
 end

end

function splash()
 h.sink=1
 sfx(21)
 for i=0,8 do
  p=mke()
  p.x=h.x
  p.y=h.y
  p.vx=rnd(1)-0.5
  p.vy=-rnd(5)
  p.we=0.2+rnd(0.2)
  p.pix=7
  p.u=function(e)
   if(e.y>48 and e.vy>0) kl(e)
  end
 end
end

function chk_sink()
 sum=0
 if bt.it then
  sum+=1
  if(bt.it.ins) sum+=1
 end
 if h.lf then
  sum+=1
  if(h.lf.ins) sum+=1
 end
 if(sum>1) bt.sink=1
 
end


function seek_itm(lim)
 itm=nil
 for e in all(ents) do
  if e.id!=nil then
   d=dist(e,h)
   if d <= lim then
    lim=d
    itm=e
   end
  end 
 end
 return itm
end

function release()
 fear=nil
 h.lf=nil
 h.gun=nil
end

function escape(e)
 release()
 e.sd=side
 function f()
  mv(e,gix(e),function() e.lk=1-side end )
  e.dp=0
 end 
 gtf(e,0)
 sfx(4)
 jmp(e,e.x+(side*2-1)*8,44,f)
end

function ashoot()
 if(h.dead) return
 shoot(act)
 dl(12,ashoot)
end



function git(id,sd)
 if(sd==nil) sd=side 
 for e in all(ents) do
  if( e.sd==sd and e.id==id and e.fr>0 ) return e end
 return nil
end
function gix(e) 
 px=spos[e.id+1]*9+4
 if(e.sd==1) px=256-px
 return px 
end

function hv(a,b,c)
 cdv+=1
 if(cdv!=cd) return false
 act=git(a)
 trg=git(b)
 if(act) act.dp=1
 ok=act and trg and (c==nil or git(c))
 if ok then
  dlt=20
  hev=1
 end
 return ok
end

function gcx(i) return git(i).x end


function resolve()
 cd=0
 t=0
 dlt=1
 upd=nil
	ures()
end

function ures()

cd+=1
act=nil
hev=nil

for it in all(ents) do
 if it.id then
  it.dp=0
  if(not it.lkl) it.lk=1-it.sd
 end
end

wolf=git(0)
hunter=git(1)
wash=git(2)
cabb=git(4)
goat=git(5)
monkey=git(6)

mup=monkey and monkey.y<44
wmf=wash and wash.ins

cdv=0

if hv(5,4) then
 mv(goat,gcx(4),eat)
end

if hv(0,5) then
 mv(wolf,gcx(5),eat)
end

if hv(6,4) then
 mv(monkey,gcx(4),take)
end

if hv(6,2) then
 jmp(monkey,wash.x,wash.y-8,ures)
 sfx(4)
end

if hv(0,6) then
 nxt=eat
 tx=gcx(6)
 if mup then
  tx=wash.x-8*(act.sd*2-1)
  nxt=function()
   wolf.lk=wolf.sd
   wolf.lkl=1
   gtf(wolf,4)
   ures()
  end 
 end
 mv(wolf,tx,nxt)
end

if hv(1,3) then
 mv(hunter,gcx(3),take)
end

if hv(5,3) then
 mv(goat,gcx(3),eat)
end

if hv(1,0) then
 if hunter.ins !=nil then
  shoot(act)
  dl(10,ures)
 else
  hev=nil
 end
end

if hv(6,2) then
 if wash.ins and not monkey.ins then
  monkey.y+=2
  gtf(monkey,0)
  a=anm(monkey,{4,5,6,7,6,5,4},4,0)
  a.f=function() monkey.y-=2 end
  dl(16,trig_wm)
  dl(32,ures)
 else
  hev=nil
 end
end


if cd>20 then
 dl(dlt,reboot)
else
 if(not hev) ures()
 
end


end


function trig_wm()
 if(wash.ins) kl(wash.ins)
 wash.ins=nil
 gtf(wash,0)
 monkey.shk=1
 wash.shk=1
end

function reboot()

 --
 newm=1
 scl=0
 side=1-side
 fear=nil
 
end

function clean_up()
 
 for e in all(ents) do
  if e.id and e.sd>=0 and e.fr>0 then
   e.shk=nil
   e.x=gix(e)
   e.y=44
   e.lk=1-e.sd
   if(e.ins and e.id!=2) then
    gtf(e.ins,0)
    e.ins=nil
   end
   gtf(e,0)
  end
 end
 
 -- save

 
end

function do_save()
 if(sav) last=sav
 sav={}
 sav.last=last
 sav.items={}
 for i=1,7 do sav.items[i]=-4 end
 sav.side=side
 sav.moves=moves
 for e in all(ents) do
  
  if e.id and e.fr>0 then
   sav.items[1+e.id]=e.sd
   if e.ins then
    sav.items[1+e.ins.id]=10+e.id
   end
  end
 end
end


function do_load()
 init()
 
 if(sav and still) sav=sav.last
 if(sav==nil) return
 still=1
 fear=nil
 
 side=sav.side
 from_side=side
 moves=sav.moves
 bt.x=120+(side*2-1)*48
 if(side==1) h.pl=right
 h.x=128+(side*2-1)*68
 
 for e in all(ents) do
 
  if e.id then
   e.sd=sav.items[e.id+1]
   if e.sd and e.sd>=10 then
    cn=nil
    for c in all(ents) do
     if(c.id==e.sd-10) cn=c
    end
    cn.ins=e
    gtf(cn,0)
    e.fr=0
   end
   
   if e.sd==-4 then
    kl(e)
   else
    if e.sd==-1 then
     grab(e,1)
    else
     e.x=gix(e)
     e.lk=1-e.sd
    end
   end
   
  end
 end
end



function take(f)
 sfx(15)
 act.ins=trg
 trg.fr=0
 gtf(act,0)
 if(f==nil) f=function() dl(4,ures) end
 f()
end

function gtf(e,n)
 e.fr=64+e.id+n*16
 if(e.ins) e.fr+=(e.ins.id-1)*16
 
end

function shoot(from)
 sfx(1)
 trg=nil
 dst=0
 for e in all(ents) do
  d=from.x-e.x
  sns = d*(from.lk*2-1) < 0
  alive = e==h or (e.id!=nil and fget(64+e.id,2))
  if sns and e.y==from.y and e!=from and alive then
   d=abs(d)
   if trg==nil or d<dst then
    dst=d
    trg=e
   end
  end
 end
 
 s=from.lk*2-1
 e=mke()
 e.fr=57
 e.ape=62
 e.apm=2
 e.x=from.x+s*8
 e.y=from.y
 e.lk=from.lk 
 
 if(trg==nil) return
 kl(trg)
 
 for i=0,16 do
  p=mke()
  p.x=trg.x
  p.y=trg.y
  p.pix=8
  p.vx=s*rnd(5)
  p.vy=-rnd(1.5)
  p.we=0.1+rnd(0.1)
  p.f=0.95
  p.u=function(e)
   if(e.y>48) kl(e)
  end
 end
 

end

function eat()
 if(act.id==0) sfx(13)
 if(act.id==5) sfx(14)
 a=anm(act,{2,3},4,4)
 a.f=function()
  kl(trg)
  mv(act,gix(act),ures)
 end
end

function mv(e,tx,f)
 w=twm(e,tx,e.y)
 e.lk=1
 if(tx<e.x) e.lk=0
 w.f=f
end

function jmp(e,tx,ty,f)
 w=twm(e,tx,ty)
 w.j=16
 e.lk=1
 if(tx<e.x) e.lk=0
 w.f=f
end

function kl(e)
 e.dead=1
 del(ents,e)
 if e.id and fget(e.id+64,2) then
  c=mke()
  c.fr=104+e.id-5
  c.x=e.x
  c.y=e.y
 end
 if e==h then
  c=mke()
  anm(c,{6,7,8,9},4,999)
  c.x=e.x
  c.y=e.y
  c.vx=4
  c.we=0.5
  c.vy=-4
  upd=nil
 end
end
function dl(t,f)
 d={} d.t,d.f=t,f
 add(dls,d)
end


function rand(n) return flr(rnd(n))end
function anm(e,sq,m,l)
 a={}
 a.sq,a.m,a.l=sq,m,l
 a.i=0
 e.anm=a
 return a
end

function dist(a,b)
 dx=a.x-b.x
 dy=a.y-b.y
 return abs(dx)+abs(dy)
end

function upd_boat()
 
 if bt.sink then
  bt.y+=0.2
 else
  bt.y = 53+cos((t%50)/50)+0.5
 end
 
 btpl.x=bt.x-4
 btpl.y=bt.y-2
 if bt.it then
  bt.it.x=bt.x+8
  bt.it.y=bt.y-6
 end
end


function mke()
 e={}
 e.x,e.y,e.vx,e.vy=0,0,0,0
 e.fr,e.we,e.dp=0,0,0
 e.f=1
 e.sw,e.sh,e.lk=1,1,1
 add(ents,e)
 return e
end


function upe(e)
 if(e.u!=nil) e.u(e)
 if(e.pl) return
 e.vy+=e.we
 e.vx*=e.f
 e.vy*=e.f
 e.x+=e.vx
 e.y+=e.vy
end

function dre(e)
 if(cdp!=nil and cdp!=e.dp) return

 -- auto anim
 if e.apm then
  if(t%e.apm==0) e.fr+=1
  if e.fr==e.ape then
   kl(e)
   return
  end
 end
 
 --
 fr=e.fr
 ex=e.x
 
 -- shk
 if(e.shk) then
  if(e.id==2 and t%4==0) sfx(18)
  ex+=(t%3)-1
 end
 -- anim
 if e.anm!=nil then
  a=e.anm
  if(t%a.m==0) a.i+=1
  if a.i>=count(a.sq) then
   a.i=0
   if a.l==0 then
    e.anm=nil
    if(a.f!=nil) a.f()
   end
   if(a.l>0) a.l-=1 
  end
  fr=a.sq[a.i+1]
  if(e.id!=nil) fr=64+e.id+fr*16
 end
 
 -- draw pix
 if e.pix then
  pset(e.x,e.y,e.pix)
  return
 end
 
 -- draw sprite
 if e.lk==1 then
  spr(fr,ex-4,e.y-4,e.sw,e.sh)
 else
  fspr(fr,ex-4,e.y-4)
 end
 
 
end

-- tween
function twm(e,ex,ey,h)
 w={}
 w.e=e
 w.sx=e.x
 w.sy=e.y
 w.ex=ex
 w.ey=ey
 w.h=h
 w.c=0
 w.s=0.1
 add(tweens,w)
 return w
 
end

function fspr(fr,ex,ey,sw,sh)
 for x=0,7 do
  sx=8*(fr%16)
  sy=8*(flr(fr/16))
  sspr(sx+7-x,sy,1,8,ex+x,ey)
 end
end

function upw(w)

 w.c=min(w.c+w.s,1)
 w.e.x=w.sx+(w.ex-w.sx)*w.c
 w.e.y=w.sy+(w.ey-w.sy)*w.c
 if(w.j!=nil) w.e.y += sin(w.c*0.5)*w.j
 if w.c==1 then
  del(tweens,w)
  if(w.f!=nil) w.f()
 end
end


function updl(d)
 d.t-=1
 if(d.t>0) return
 d.f()
 del(dls,d)
end

function _update()
 lp=1
 if(btn(5,1)) lp=20
 for i=1,lp do iter() end
 
 
 if playing then
  cx=side*128
  if scl then
   scl=min(scl+0.05,1)
   c=0.5+cos(scl/2)*0.5
   cx+=c*(1-side*2)*128
   if(scl==1) then
    clean_up()
    scl=nil
    upd=play
   end
  end
 end 
 
end

function iter()
 t+=1
 foreach(ents,upe)
 if(upd!=nil) upd()
 foreach(dls,updl)
 foreach(tweens,upw)
 
end

function _draw()
 cls()
 mh=32
 
 
 -- white
 if wh then
  wh.c=min(wh.c+wh.s,100)
  c=-sin(wh.c/200)
  b=flr(c*5)
  for i=0,15 do pal(i,sget(16+i,b)) end
  if(wh.c>=50 and wh.f) wh.f() wh.f=nil
  if(wh.c==100) wh=nil
 end
 
 clip(0,mh,128,64)
 camera(0,-mh)
 
 -- bg
 sspr(16,8,16,16,0,0,128,64)

 if(not wh) apal(8)
 mapdraw(14,8,-cx/16,0,24,8)
 if(not wh) pal() 
 
 if(not wh) apal(2)
 mapdraw(5,8,-cx/8,0,24,8)
 if(not wh) pal() 
 
 mapdraw(0,8,-cx/4,0,24,8)

 --
 camera(cx,-mh)
 
 
 -- map
 mapdraw(0,0,0,0,32,8)
 for i=0,2 do
  cdp=i
  foreach(ents,dre)
 end
 cdp=nil
 
 -- blue
 if not wh then
  clip(64-cx,52+mh,128,12)
  for i=0,15 do pal(i,1) end 
  foreach(ents,dre)
 end

 pal()
 clip()
 camera()
 
 if wh then
  
  
  for s in all(stars) do
   c=0.5-cos(wh.c/200)*0.5
   x=(s.x+c*s.m*128)%128
   y=32+s.y
   co=sget(16+(wh.c/100)*8,6)
   pset(x,y,co)
  end
  
 end
 
 
 if(ldr) ldr()
 
 if(log) print(log,0,0,8)
 
end


function apal(c)
 for i=0,15 do pal(i,c) end 

end




