-- super poulet poulet
-- matt riche


-- todo

-- more music!
-- stage mutators so it goes on forever!
-- play as enemies secret code

function _init()
	game = {}
	game.peaceful = false
	game.titleon = true
	game.debugflag = 0
	game.debugmesg = "debug"
	game.levelnum = (-1)
	game.nasty = false
	game.stage = game.levelnum
	game.playnum = 1
	game.score = 0
	game.mesgon = false
	game.mesgx = 0
	game.mesgy = 0
	game.mesg = ""
	game.mesgtime = 50
	game.multiplier = 1
	game.endlevelticker = 0
	game.levelbeat = false
	game.lives = 0
	game.startlives = 2
	game.hottime = 220
 game.freelives = 0
	game.overcounter = 0
	game.highscore = 0
	game.challenge = false
	game.leveltime = 1000
	game.prizecounter = 0 
	actors = {}

	world = {}
	world.gravity = .7
	world.friction = .14

	player = {}
	-- player things to be established once only
	player.hat = 0

	-- ephemerals are not fully actors
	ephem = {}

	-- run startup code

	next_level(game.stage)

end


function clean_actors(a)
	
	del(actors, a)	
end


function burn_world()
	make_flame((rnd(128) + game.camerax), 126, 7)

end

function alttilepal(profile)
	
	if(profile == 1) then
		pal(3, 2, 0)
		pal(11, 12, 0)


		pal(3, 1, 0)
		pal(8, 13, 0)
	end
end

function altpal(profile)
	
	if(profile == 1) then
		-- greens to blue
		pal(3, 2, 0)
		pal(11, 12, 0)
	
		-- pink to green
		pal(14, 11, 0)
		pal(2, 3, 0)

		pal(4, 13, 0)
		
		pal(12, 2, 0)
		pal(6, 14, 0)	  
		
		pal(10, 14, 0)
		pal(9, 8, 0)	
	end
end


function changecolour(profile)

	-- red to blue
	if(profile == 1) then
		pal(2, 1, 0)
		pal(8, 12, 0)
		pal(14, 6, 0)
	end

	-- red to green
	if(profile == 1) then
		pal(2, 1, 0)
		pal(8, 12, 0)
		pal(14, 6, 0)
	end

	
end


function draw_gamemesg(mx, my, message)

	scoretext (mx, my, message)
end


function stagemutate(profile)
		-- iterate through stage, changing tiles
		local row
		local column
		
		for row = 0, 127 do
			for column = 0, 127 do
				-- different profiles here
				if(game.levelnum >= 8) then
					game.nasty = true
					-- unfair mode
					if((row % 7) == 0 and row > 3 and row < 123) then
						mset(row, column, 0)
						mset(row + 1, column, 0)
					end
					--if((row % 14) == 0) then
					--	mset(row, column, 0)
					--	mset(row + 1, column, 0)
					--end
			  if(mget(row, column) == 79) then
			  	mset(row, column, 91)
			  end 
					
				else
					game.nasty = false
				end
				if(game.levelnum == 7) then
			  if(mget(row, column) == 87) then
			  	mset(row, column, 25)
			  end 
			  if(mget(row, column) == 87) then
			  	mset(row, column, 25)
			  end 
		  
			  if(mget(row, column) == 88) then
			  	mset(row, column, 51)
			  end 
			  if(mget(row, column) == 122) then
			  	mset(row, column, 51)
			  end 
			  if(mget(row, column) == 72) then
			  	mset(row, column, 73)
			  end 
			  if(mget(row, column) == 106) then
			  	mset(row, column, 51)
			  end 
				end
				if(game.levelnum == 6) then
			  if(mget(row, column) == 100) then
			  	mset(row, column, 26)
			  end 
			  if(mget(row, column) == 102) then
			  	mset(row, column, 0)
			  end 
			  if(mget(row, column) == 127) then
			  	mset(row, column, 26)
			  end 
			  if(mget(row, column) == 90) then
			  	mset(row, column, 32)
			  end 
			  if(mget(row, column) >= 52) and (mget(row, column) <= 55) then
			  	mset(row, column, 0)
			  end 
			  if(mget(row, column) == 111) then
			  	mset(row, column, 32)
			  end 
			  if(mget(row, column) == 111) then
			  	mset(row, column, 26)
			  end 
			  if(mget(row, column) == 89) then
			  	mset(row, column, 32)
			  end 
			  if(mget(row, column) == 101) then
			  	mset(row, column, 33)
			  end 
			  if(mget(row, column) == 88) then
			  	mset(row, column, 48)
			  end 
					
				end
			
				if(game.levelnum == 5) then
	 		 if(mget(row, column) == 63) then
			  	mset(row, column, 101)
			  end 
			  if(mget(row, column) == 62) then
			  	mset(row, column, 35)
			  end 
			  if(mget(row, column) == 40) then
			  	mset(row, column, 118)
			  end 
			  if(mget(row, column) == 41) then
			  	mset(row, column, 35)
			  end 
		 	 if(mget(row, column) == 25) then
		 	 	mset(row, column, 100)
		 	 end 
		 	end
		 	if(game.levelnum == 4) then
	 		 if(mget(row, column) == 9) or (mget(row, column) == 10) then
		 	 	mset(row, column, 56)
		 	 end 
				 if(mget(row, column) == 34) or (mget(row, column) == 10) then
				 	mset(row, column, 73)
				 end 
				 if(mget(row, column) == 33) then
				 	mset(row, column, 0)
				 end 
				 if(mget(row, column) == 32) then
				 	mset(row, column, 87)
				 end 
				 if(mget(row, column) == 36) then
				 	mset(row, column, 63)
				 end 
				 if(mget(row, column) == 37) then
				 	mset(row, column, 62)
				 end 
				 if(mget(row, column) == 35) then
				 	mset(row, column, 41)
				 end 
				end
				if(game.nasty == true) then
					mset(row, 15, 72)					
				end
			end
		end
end


function initplayer()
	player.x = 16
	player.y = 16
	player.ax = 0
	player.ay = 0
	player.sprite = 112
	player.accel = .5
	player.speed = 2
	player.grounded = 0
	player.animspeed = 2 -- lower is faster
	player.ticker = 0
	player.frame = 0
	player.currentanim = 0
	player.flip = false -- false is right, true is left
	player.jumppower = 6
	player.headbutt = false
	player.dead = false
	player.defeated = false
	player.deathtimer = 0
	player.hotwings = false
	player.hotticker = 0
	player.blinktime = 0
	player.blinkmax = 90
	player.skid = 0
	player.skidtime = 2
end


function make_ephem(e,x,y,k)
	local e = {}
	-- k for kind!
	e.k = k
	e.x = x
	e.y = y
	e.ax = 0
	e.ay = 0
	-- lower the better
	e.animspeed = 5
	e.frame = 0
	-- randomize the direction
	e.ax += (-(rnd(.5)))
	e.ax += rnd(.5)
	e.ay += (-(rnd(.5)))
	e.ay += rnd(.5)

 -- special case for fire.
	if(e.k == 64) then
		e.ax = (e.ax / 2)
		e.ay -= rnd(.3)
		e.ax += (player.ax / 2)
		e.ay += (player.ay / 3)
	end

	add(ephem, e)	
end


function ephem_update(e)
	e.x += e.ax
	e.y += e.ay

	e.animspeed -= 1
	
	if(e.animspeed <= 0) then
		e.frame += 1
		e.animspeed = 5
	end
	
	if (e.frame > 3) then
		del(ephem, e)	
	end 
	
	spr((e.k + e.frame), e.x, e.y)
end 


function actordie(a)
	a.lethal = false
	a.airborne = false
	
	a.ax = player.ax
	a.ay = -5
	a.defeated = true

	if (a.type == 79) then
		del(actors, a)
	end

end


function playerdied()
	music(-1)
	sfx(2)
	player.deathtimer = 130
	player.dead = true
	player.ax = (-player.ax)
	player.ay = -8
	make_puff(player.x, player.y, 10)
	game.lives -= 1
end


function start_level(level)
 if(game.levelnum > 3) then
 	stagemutate(1)
	end
	add_actors(actors)	
	start_stagemusic()
end


function start_stagemusic()
	if(game.stage == 0) then
		music(1, 0, 7)
	end
	if(game.stage == 1) then
		music(28, 0, 7)
	end

	if(game.stage == 2) then
		music(1, 0, 7)
	end

	if(game.stage == 3) then
		music(34, 0, 7)
	end

	if(game.titleon == true) then
	 	music(28, 0, 7)
	end

end

function scorepadded(value)
	-- i don't know the string-fu of lua
	if(value == 1) then
		return "100"
	end

	if(value == 2) then
		return "200"
	end
	
	if(value == 3) then
		return "300"
	end

	if(value == 4) then
		return "400"
	end

	if(value == 5) then
		return "500"
	end

	if(value == 6) then
		return "600"
	end

	if(value == 7) then
		return "700"
	end
	
	if(value == 8) then
		return "800"
	end

	if(value == 9) then
		return "900"
	end

	if(value == 10) then
		return "1000"
	end

	if(value == 16) then
		return "1600"
	end
	
	if(value == 32) then
		return "3200"
	end

	if(value == 64) then
		return "6400"
	end

	if(value == 128) then
		return "12800"
	end

	if(value == 256) then
		return "25600"
	end

	if(value == 512) then
		return "51200"
	end

end


function takehit()
				if(player.hat > 0) then
					sfx(21)
					game.prizecounter = 0
					player.hat = 0
					player.ay = (-3)
					player.blinktime = player.blinkmax
				end
				
				if(player.hat <= 0) and (player.blinktime <= 0) then
					playerdied()
				end
end


function actor_collide(a)
	
	if(game.levelbeat) then
		return
	end
	
	if(player.dead) then
		return
	end

	local scoring = 0
	--  if the player is hitting this actor
	if (a.x > (player.x - 8)) and (a.x < (player.x + 8)) then
		if (a.y > (player.y - 8)) and (a.y < (player.y + 8)) then
	 	-- true cases
			if (a.lethal) and (player.headbutt == false) and (player.dead == false) and (player.hotwings == false) then
				takehit()
			end
			
			if (a.prize == true) then
				
				if(player.headbutt == true) then
					sfx(19)
					make_puff(a.x, a.y, 6)		
					actordie(a)
					game.prizecounter += 1
					
					if(game.prizecounter < 3) or (game.prizecounter > 3) then
						spawn_bauble(a.x, a.y, 10)
					end

					if(game.prizecounter == 3) then
						make_actor(actors, 49, a.x / 8, a.y / 8)
					end
		
					if(game.prizecounter == 6) then
						make_actor(actors, 69, a.x / 8, a.y / 8)
						game.prizecounter = 0
					end				
				end
			end
	
			if ((a.lethal) and (player.headbutt == true)) then
				player.ay = (-4.7)
				actordie(a)
				game.multiplier = (game.multiplier * 2)
				scoring = (2 * game.multiplier)
				if (scoring > 128) then
					scoring = 128
				end
				if (game.multiplier > 64) then
					game.multiplier = 64
				end
				make_mesg(player.x, player.y, scorepadded(scoring))	
				game.score += scoring
				sfx(16)
			end

			if ((a.lethal) and (player.hotwings)) then
				actordie(a)
				game.multiplier = (game.multiplier * 2)
				scoring = (2 * game.multiplier)
				if (scoring > 128) then
					scoring = 128
				end
				if (game.multiplier > 64) then
					game.multiplier = 64
				end
				make_mesg(player.x, player.y, scorepadded(scoring))	
				game.score += scoring
				sfx(16)
			end		

			if (a.type == 56 or a.type == 59) then
				if (a.ay == 0) then
				 sfx(3)
				 a.type = 0
				 a.alive = false
					make_twinkle(a.x, a.y, 4)
					game.score += 2
				end
			end

			if (a.type == 69) then
				sfx(3)
				a.type = 0
				a.alive = false
				make_flame(a.x, a.y, 30)	
				make_mesg(player.x, player.y, "hotwings!")
				player.hotwings = true
				music(20, 0, 7)
				player.hotticker = game.hottime
				game.score += 5
			end

			if (a.type == 49) then
				sfx(3)
				a.type = 0
				a.alive = false
				make_mesg(player.x, player.y, "toque!")
				sfx(20)
				if(player.hat == 1) then
					spawn_bauble(player.x + 4, player.y - 3, 30)
				end
				player.hat = 1
				game.score += 10
			end

  end
	end
end


function make_actor(a,type,x,y)
 -- add a non-player entity
	if(game.peaceful) then
		return
	end
	local a = {}
	a.type = type
	a.sprite = type
	a.x = (x * 8)
	a.y = (y * 8)
	a.ax = 0
	a.ay = 0
	a.alive = true
	a.relevant = true
	a.airborne = false
	a.grounded = false
	a.animspeed = 3 -- lower is faster
	a.ticker = 0
	a.frame = 0
	a.speed = .2
	a.behave = 0
	a.prize = false
	a.tetherx = 0
	a.tethery = 0

	if ((type == 16) or
	   (type == 20) or
	   (type == 123) or
	   (type == 26)) then
				-- fennec, moxie, etc.
	 a.lethal = true
 else
  a.lethal = false
 end

	if (type == 56) then
		a.airborne = true
		a.frame = rnd(2)
	end

	if (type == 59) then
		-- red bauble
		a.airborne = false
		a.ax += rnd(3)
		a.ay += rnd(3)
		a.ax -= rnd(3)
		a.ay -= rnd(3)
		a.frame = rnd(2)

	end

	if (type == 96) then
		-- burd
		a.airborne = true
		a.lethal = true
	end


	if (type == 112) then
		if(game.levelnum > 2) then
			-- keith, and beese
			a.airborne = true
			a.lethal = true
		end
		
		if(game.levelnum <= 2) then
			del(actors, a)
			a.alive = false
		end

	end


	if (type == 91) then
		if(game.levelnum > 3) then
			-- beese
			a.airborne = true
			a.lethal = true
		end
		
		if(game.levelnum <= 3) then
			del(actors, a)
			a.alive = false
		end
	end


	if (type == 107) then
		-- hopkin 
		a.airborne = false
		a.lethal = true
		if(game.levelnum <= 1) then
			del(actors, a)
			a.alive = false
			a.lethal = false
		end
		
	end

	if (type == 49) then
		-- toque		
		a.airborne = false
		a.y -= 8
		a.ay = -4	
	end
	
	if (type == 79) then
		-- prize balloon
		a.prize = true
		a.airborne = true
		a.tetherx = (a.x + 4)
		a.tethery = (a.y + 24)
  a.ax = 0
  a.ax += rnd(.1)
  a.ax -= rnd(.1)
		a.ay = 0
		a.ay += rnd(.1)
  a.ay -= rnd(.1)
		
	end

 add(actors, a)
	return a
end

function actor_physics(a)
 -- check for falling collision
 checkx = ((a.x + 4) / 8) 
 checky = ((a.y + 8 + a.ay) / 8)
	if solid(checkx, checky) == true then
		a.y += (a.ay)
		a.ay = 0
		a.grounded = 1

		-- dying creatures despawn when hitting the ground
		if(a.defeated == true) then
			a.alive = false
			make_puff(a.x, a.y, 5)
			a.type = 0
			del(actors, a)

		end
		a.y -= (a.y % 8)
	else
		a.grounded = 0
	end

	-- check for falling out of world
 if(a.y > 128) then
			a.alive = false
			a.type = 0
			del(actors, a)
 end

	-- falling "up" has a two tile buffer before despawn.
	if(a.y < -16) then
			a.alive = false
			a.type = 0
			del(actors, a)
	end
	
	-- check for right collision
	checkx = ((a.x + 8 + a.ax) / 8)
	checky = ((a.y + 4) / 8)
	if solid(checkx, checky) == true then
		a.ax = 0
	end

	-- check for left collision
	checkx = ((a.x + a.ax) / 8)
	checky = ((a.y + 4) / 8)
	if solid(checkx, checky) == true then
		a.ax = 0
	end

	-- check upper collision
	checkx = ((a.x + 4) / 8)
	checky = ((a.y) / 8)
	if solid(checkx, checky) == true then
		a.y += abs(a.ay)
		a.ay = (-a.ay / 2)
		--a.y += (a.y % 8)
	end

	-- update actor position
	a.x += a.ax
	a.y += a.ay
	if (a.grounded == 0) and (a.airborne == false) then
		a.ay += world.gravity
	end

	-- add friction
	if (a.grounded == 1) and (a.airborne == false) then
		if a.ax > 0 then
			a.ax -= world.friction
		end
		if a.ax < 0 then
			a.ax += world.friction
		end
		-- a check needs to make sure it doesn't pingpong the value aroudn zero
		if abs(a.ax) < world.friction then
			a.ax = 0
		end
	end
end


function make_flame(x, y, amount)
	for i = 1, amount do
		make_ephem(ephem, x, y, 64)
	end
end


function make_twinkle(x, y, amount)
	for i = 1, amount do
		make_ephem(ephem, x, y, 42)
	end
end


function make_puff(x, y, amount)
	for i = 1, amount do
		make_ephem(ephem, x, y, 27)
	end
end


function actor_behave(a)
	-- run behaviours on given actor id
	if (a.defeated == true) then
		return
	end

	if (a.alive == false) then
	 return
	end

	if (a.x < 32) then
		a.ax += .2
	end

	if (a.prize == true) then
		flr(a.ax, .1)
		flr(a.ay, .1)

		if (a.x > a.tetherx) then
			a.ax -= .1
		end
		if (a.x < a.tetherx) then
			a.ax += .1
		end

		if (a.x == a.tetherx) then
			a.ax += rnd(.1)
			a.ax -= rnd(.1)
		end

		if (a.y > (a.tethery - 24)) then
			a.ay -= .1
		end

		if (a.y < (a.tethery - 24)) then
			a.ay += .1
		end

		a.ax += (rnd(.01))
		a.ax -= (rnd(.01))
		a.ay += (rnd(.01))
		a.ay -= (rnd(.01))

	end

	if ((a.x + 8)< game.camerax) or (a.x > (game.camerax + 128)) then
		a.relevant = false
	else
		a.relevant = true
	end
				
	if a.relevant == false then
		-- if not on screen, skip whole function
		return
	end

	
	if a.type == 16 then
		-- tard cat
		a.currentanim = 1
		if (player.x < a.x) then
			a.ax -= .15
			a.flip = true
		else
			a.ax += .15
			a.flip = false
		end

		if (game.nasty) then
			if (player.x < a.x) then
				a.ax -= .01
				a.flip = true
			else
				a.ax += .01
				a.flip = false
			end
			if (a.grounded == 1) then
				a.ay = -(rnd(3))
			end
			if (a.y >= 120) then
				a.ay = -9
			end
		end
	end
	
	if a.type == 123 then
		-- fennick
		a.currentanim = 1
		if (player.x < a.x) then
			a.ax -= .05
			a.flip = true
		else
			a.ax += .05
			a.flip = false
		end
		if(rnd(50) >= 49) and (a.grounded == 1) then
			a.ay -= 2
		end
		if(game.nasty) then
			if(player.x > a.x) then
				a.ax = .5
			end
			if(player.x < a.x) then
				a.ax = -.5
			end
			if(rnd(50) >= 49) and (a.grounded == 1) then
				a.ay -= 5
			end

		end

	end
	
	
	if a.type == 107 then
		-- hopkin
		a.currentanim = 1
		if(player.x < a.x) then
			a.flip = true
		else
			a.flip = false
		end
	
		if(player.y < a.y) and (a.grounded == 1) then
			a.grounded = 0
			a.ay = -(rnd(4))
			a.ax += rnd(1)
			a.ax -= rnd(1)
		end
		
		if(a.grounded == 0) then
			frame = 2
		end
		
		if (game.nasty) then
	 	a.ax = 0
			if(player.y < a.y) and (a.grounded == 1) then
				a.grounded = 0
				a.ay = -(rnd(8))
				if((flr(player.y) == (a.y - 1)) or (flr(player.y) == (a.y + 1) or (flr(player.y) == (a.y)))) then
					if(player.x < a.x) then
						a.ax = -1.5
					end
					if(player.x < a.x) then
					 a.ax = 1.5
					end
				end
			end
		end
	end

	if a.type == 20 then
		-- squeesh
		a.currentanim = 1
		if(player.x < a.x) then
			a.flip = true
		else
			a.flip = false
		end
		a.ax -= rnd(.3)
		a.ax += rnd(.3)
		
		if (game.nasty) then
			a.type = 112
		end
	end


	if a.type == 96 then
		-- burd
		a.currentanim = 1
		if(a.ax <= 0) then
			a.flip = true
		else
			a.flip = false
		end
		if (a.behave > 50) then
			a.ax -= .02
		end
		if (a.behave <= 50) then
			a.ax += .02
		end
		if (a.behave >= 100) then
			a.behave = 0
		end
		a.behave += 1
	end

	if a.type == 91 then
		-- beese
		a.currentanim = 1
		
		if(player.x <= a.x) then
			a.flip = true
			if(abs(a.ax) < 1) then
				a.ax -= .1
			end
		end
		if(player.x >= a.x) then
			a.flip = false
			if(abs(a.ax) < 1) then
				a.ax += .1
			end
		end

		if(player.y <= a.y) then
			if(abs(a.ay) < 2) then
				a.ay -= .1
			end
		end
		if(player.y >= a.y) then
			if(abs(a.ay) < 2) then
				a.ay += .1
			end
		end
		
		if(game.nasty) then
			if(a.ay > 0) then
				a.ay += .01
			end
			if(a.ay < 0) then
			 a.ay -= .01
			end
		end

	end
	

	if a.type == 112 then
		-- bat
		a.currentanim = 1
		if(a.ax <= 0) then
			a.flip = true
		else
			a.flip = false
		end
		if (a.behave > 50) then
			a.ay -= .02
		end
		if (a.behave <= 50) then
			a.ay += .02
		end
		if (a.behave >= 100) then
			a.behave = 0
		end
		a.behave += 1
	end



	if a.type == 56 then
		a.currentanim = 1
		-- bauble
		if (game.nasty) then
			actordie(a)
		end
 end
	
	if a.type == 59 then
		a.currentanim = 1
		-- green bauble
 end


	if a.type == 69 then
		a.currentanim = 1
		-- hotsauce
	end

	if a.type == 49 then
		a.currentanim = 1
		a.frame = 0
		-- toque
	end


	
end


function player_control()
	if (player.dead == true) then
		return
	end
 --get control input!
 if (btnp(4, 0) == true) and (player.grounded == 1) then
 	player.ay = (-player.jumppower)
		player.headbutt = false
		sfx(0)
 end
 
 --if (btnp(0, 1) == true) then
 --	game.levelbeat = true
 --end

	if (btnp(5, 0) == true) and (player.grounded ~= 1) and (player.headbutt == false) then
		if (btn(2, 0) == true) and (btn(3, 0) == false) then	
			player.headbutt = true
			sfx(1)
	 end
	end

	if (btnp(5, 0) == true) and (player.grounded ~= 1) and (player.headbutt == false) then
		if (btn(2, 0) == false) and (btn(3, 0) == true) then	
	 	player.ay = 6
	 	player.ax = 0
	
			player.headbutt = true
			sfx(1)
	 end
	end

	if (btnp(5, 0) == true) and (player.grounded ~= 1) and (player.headbutt == false) then
		player.ay = 5
		if(player.flip == false) then
			player.ax = 4.6
		else
			player.ax = -4.6
		end
		player.headbutt = true
		sfx(1)
	end

 
 if btn(0, 0) == true then
 	player.flip = true
	 if (player.ax >= (-player.speed)) then
 		player.ax -= player.accel
 	end
 end

 if btn(1, 0) == true then
 	player.flip = false
	 if (player.ax <= player.speed) then 
 		player.ax += player.accel
		end
	
 end

end


function make_mesg(x, y, message)
	
	game.mesg = message
	game.mesgx = x
	game.mesgy = y
	game.mesgtime = 30
	game.mesgon = true
end


function draw_actor(a)
	-- if an actor is "relevant," draw it.
 if(a.alive == false) then
  return
 end
 
	if(a.relevant) then

		if a.currentanim == 1 then
			if a.frame == 0 then 
				a.sprite = a.type
			end 
			if a.frame == 1 then 
				a.sprite = (a.type + 1)
			end 
			if a.frame == 2 then 
				a.sprite = a.type
			end 
			if a.frame == 3 then 
				a.sprite = (a.type + 2)
			end 
		end	
		
		a.ticker += 1
		if a.ticker >= a.animspeed then
			a.ticker = 0
			a.frame += 1
			if a.frame > 3 then
				a.frame = 0
			end
		end 

		if (a.defeated == true) then
			a.sprite = (a.type + 3)
		end


		if (a.type == 49) then
			if(game.levelnum > 3) then 
				changecolour(1)		
			end
			if(game.levelnum > 7) then 
				changecolour(2)		
			end
		end
			
		spr(a.sprite, a.x, a.y, 1, 1, a.flip)

		-- draw tether
		if(a.prize == true) then
			line(a.tetherx, a.tethery, (a.x + 4), (a.y + 8), 7)
		end	

	end
end


function animate_player()
	
	if (player.grounded == 1) then
		if (abs(player.ax) > 0) then
			player.currentanim = 1
		else 
			player.currentanim = 0
		end
	end

	if (player.grounded ~= 1) then
	 player.currentanim = 2
	end
	
	if player.currentanim == 0 then
		-- stand still
		player.sprite = 1
	end
	
	if player.currentanim == 2 then
		if(player.ay <= 0) then 
			player.sprite = 5
		end
		if(player.ay > 0) then
			player.sprite = 6
		end
	end
	
	if player.currentanim == 1 then
		if player.frame == 0 then 
			player.sprite = 1
		end 
		if player.frame == 1 then 
			player.sprite = 2
		end 
		if player.frame == 2 then 
			player.sprite = 1
		end 
		if player.frame == 3 then 
			player.sprite = 3
		end 
	end	
	
	player.ticker += 1
	if player.ticker >= player.animspeed then
		player.ticker = 0
		player.frame += 1
		if player.frame > 3 then
			player.frame = 0
		end
	end 
	
	if (player.headbutt == true) then
		player.sprite = 7
	end

	if (player.dead == true) then
		player.sprite = 4
	end

	if (player.hotwings == true) then
		make_flame(player.x, player.y, 2)
	end

	if (player.hotwings == true) then
		player.sprite += 79
	end

	if(player.blinktime > 0) then	
		player.blinktime -= 1
		if((player.blinktime % 2) == 1) then
			spr(player.sprite, player.x, player.y, 1, 1, (player.flip))
		end
		
	end

	if(player.blinktime <= 0) then	
		spr(player.sprite, player.x, player.y, 1, 1, (player.flip))
	end

	if(player.hat == 1) then
		local offsety = 4
		if (player.frame == 1 or player.frame == 3) and (player.currentanim == 1)then
			offsety = 3
		end 

		if(game.levelnum > 3) then 
			changecolour(1)		
		end
		if(game.levelnum > 7) then 
			changecolour(2)		
		end
		
		spr(49, player.x, player.y - offsety, 1, 1, (player.flip))
		
		pal()
	end

end	


function spawn_bauble(x, y, amount)

	for i = 1, amount do
		make_actor(actors, 59, (x / 8), (y / 8) - 1)
	end
	
end


function check_row(x, y, width)
	-- iterate through a row of pixels looking for collision
	for i = 0,width do
			if solid(((flr(x) + i) / 8), (flr(y) / 8)) == true then
				return true
			end
	end 
end


function check_column(x, y, width)

	for i = 0,width do
			if solid((x / 8), ((y + i) / 8)) == true then
				return true
			end
	end 

end


function player_onground()
		player.ay = 0
		player.grounded = 1
		if(player.headbutt == true) then
			make_puff(player.x, player.y, 3)
			if(player.skid <= 0) then
				player.skid = player.skidtime
			end
			if(player.skid > 0) then
				player.skid -= 1
				if (player.skid <= 0) then
					player.headbutt = false
				end
			else
				player.headbutt = false
				player.skid = 0
			end
		end
		
		if(player.hotwings == false) then
			game.multiplier = 1
		end
		player.y -= (player.y % 8)
	
		-- killertile down
		if(killertile((player.x + 4) / 8, (player.y + 9) / 8)) and (player.dead == false) and (player.blinktime <= 0) then
			player.y -= 8
			takehit()
		end
	
end


function player_phys()
	
	-- skip this function if we are showing the scores
	if(game.levelbeat == true) then
		return
	end
	
	if (player.y > 128) and (player.dead == false) then
		playerdied()
		player.ax = 0
	end

 -- check for falling collision
	-- destination x and y 
	local sx = player.ax<0 and -1 or 1
 local sy = player.ay<0 and -1 or 1

	-- down check	
	for i=1, abs(player.ay), 1 do
		if(player.ay > 0) then
			player.y += sy
		end
		player.grounded = 0
		if(check_row(player.x, player.y + 7, 8) == true) then
			player_onground()
			--player.y -= sy 
			break
		end
	end

	-- up check
	for i=1, abs(player.ay), 1 do
		if(player.ay < 0) then
			player.y += sy
		end
		player.grounded = 0
		if(check_row(player.x, player.y - 1, 8) == true) then
			player.ay = 0
			--player.y -= sy 
			break
		end
	end

	-- left check
	for i=1, abs(player.ax), 1 do
		if(player.ax < 0) then
			player.x += sx
		end

		if(check_column(player.x, player.y, 7) == true) then
			player.ax = 0
			player.x -= sx 
			break
		end
	end

	-- right check
	for i=1, abs(player.ax), 1 do
		if(player.ax > 0) then
			player.x += sx
		end
		if(check_column(player.x + 8, player.y, 7) == true) then
			player.ax = 0
			player.x -= sx 
			break
		end
	end

	player.ay += world.gravity

	-- add friction
	if player.grounded == 1 then
		if (player.ax > 0) then
			player.ax -= world.friction
		end
		if (player.ax < 0) then
			player.ax += world.friction
		end

		-- a check needs to make sure it doesn't pingpong
		if abs(player.ax) < world.friction then
			player.ax = 0
		end
	end

end


function cameraupdate()
	-- check for level borders
	if (player.x < 960) and (player.x > 0) then 
		game.camerax = player.x - 60
	end
	if player.x < 64 then
		game.camerax = 0
	end
	if player.x > 957 then
		game.camerax = 896
	end
	game.cameray = 0
end

function drawstage()

	-- draw the tilemap.
	leveloffset = (game.stage * 128)
 stagecamx = game.camerax
 stagecamy = game.cameray
 blockx = stagecamx / 8
 blocky = (stagecamy + leveloffset) / 8
 offsetx = stagecamx % 8
 offsety = stagecamy % 8
	map (blockx,blocky,stagecamx-offsetx,stagecamy-offsety,17,17)
end


function add_actors()
	-- mgets all tiles, looking for actor flags.
	-- if flagged as actor, empty tile must be written
	-- if actor flag found, is added to the list.
	-- actors without "onscreen" flag set don't move
	del(actors)

	for ix = 0,128 do
		for iy = 0,16 do
			flagval = mget(ix,(iy + (game.stage * 16)))
			if (fget(flagval, 7) == true) then
				make_actor(actors, flagval, ix, iy)
				mset(ix,(iy + (game.stage * 16)), 0)
			end
		end
	end	

end


function solid (x, y)

	-- if the tile is not in this this level call it unsolid.
	if((y * 8) > 127) then
		return 0
	end

	if((y * 8) < 0) then
		return 0
	end
	-- check if a tile is solid
	-- first get the value of the map.
	newy = (y + (game.stage * 16))
	val = mget(x, newy)
	-- then check the flag of the value
	-- flag 0 value is returned
	return fget (val, 0)
		
end


function killertile (x, y)

	-- if the tile is not in this this level call it unsolid.
	if((y * 8) > 128) then
		return 0
	end

	if((y * 8) < 0) then
		return 0
	end
	-- check if a tile is solid
	-- first get the value of the map.
	newy = (y + (game.stage * 16))
	val = mget(x, newy)
	-- then check the flag of the value
	-- flag 0 value is returned
	return fget (val, 6)
		
end


function _update()
	-- this happens every frame	

	-- run this loop if game is in play...
	if(game.titleon == false) then

		if(game.levelbeat == false) and (player.dead == false) then
			if(game.leveltime > 0) then
				game.leveltime -= 1
			end
		end
		
		player_control()
		player_phys()	
		foreach(actors, actor_behave)
		foreach(actors, actor_physics)
		foreach(actors, actor_collide)

		if (game.levelbeat == false) and (player.x > 1024) then
			game.levelbeat = true
			music(19)
		end
	
		if (player.dead == true) then
			player.deathtimer -= 1
	
			if(game.overcounter > 0) then
				player.deathtimer = 9999
			end

			if(player.deathtimer <= 0) then
				player.dead = false
				player.hat = 0
				
				game.levelnum -= 1 
				next_level(game.stage - 1)
			end
		end

		-- hotwings timer
		if (player.hotwings == true) then
			player.hotticker -= 1
			if player.hotticker <= 0 then
				player.hotwings = false
				if(game.levelbeat == false) then 
					start_stagemusic()
				end
			end
		end

	end

	-- run this loop if title is on.
	if(game.titleon == true) then
		-- scroll through a level
		game.camerax += .3
	
		-- show the title
		-- check inputs.
			if(btnp(4)) then
			game.titleon = false
			game.lives = game.startlives
			start_stagemusic()
		end 
		
	end

	awardlives()
	
end


function next_level(level)
	player.x = 32
	player.y = 32

	game.leveltime = 1000

	game.camerax = 0
	game.cameray = 0

	game.stage = (level + 1)
	game.levelnum += 1
	if(game.stage > 3) then
		game.stage = 0
	end

	if(game.levelnum == 0) then 
		game.sky = 12
	end

	if(game.levelnum == 1) then 
		game.sky = 14
	end

	if(game.levelnum == 2) then 
		game.sky = 12
	end

	if(game.levelnum == 3) then 
		game.sky = 0
	end

	if(game.levelnum == 4) then 
		game.sky = 0
	end

	if(game.levelnum == 5) then 
		game.sky = 12
	end

	if(game.levelnum == 6) then 
		game.sky = 14
	end

	if(game.levelnum == 7) then 
		game.sky = 0
	end


	foreach(actors, clean_actors)
	reload()

	start_level(game.stage)
	
	initplayer()
	
end


function droptext(x, y, string)
	-- make pretty dropshadow text
	print(string, (game.camerax + x + 1), (game.cameray + y + 1), 5) 
	print(string, (game.camerax + x), (game.cameray + y), 7) 

end


function scoretext(x, y, string)
	-- make pretty dropshadow text
	print(string, (x + 1), (y + 1), 4) 
	print(string, (x), (y), 7) 

end


function drawhud()

	-- call to the padded score func here
	draw_paddedscore(52,2, game.score)

	-- draw lives
	for i=1,(game.lives) do
		spr(15, ((i * 8) + game.camerax), (game.cameray + 8))
	end

	-- debug droptext goes here
 -- if there was any...
end


function show_endlevel()

	droptext(34, 20, "stage complete!")
	

	if(game.endlevelticker > 90) then
		droptext(40, 52, "stock bonus:")
	end
	if(game.endlevelticker >= 120) then
		if(game.endlevelticker == 120) then
			sfx(3)
			game.score += (10 * game.lives)
		end
		droptext(40, 60, ("1000 x "))
		droptext(72, 60, (game.lives))
	end

	if(game.endlevelticker > 180) then
		droptext(40, 78, "time bonus:")
	end

	if(game.endlevelticker >= 200) then
		if(game.endlevelticker == 200) then
			sfx(3)
			game.score += (1 * game.leveltime)
		end
		droptext(40, 86, "100 x ")
		droptext(64, 86, game.leveltime)
	end

	game.endlevelticker += 1

	if(game.endlevelticker >= 240) then
				game.levelbeat = false
				foreach (actors, clean_actors)
				next_level(game.stage)
				game.endlevelticker = 0

	end

end


function awardlives()

	if(game.score >= 100) and (game.freelives < 1) then
		game.lives += 1
		game.freelives += 1	
		make_mesg(player.x, player.y, "1up")
		sfx(18)
	end	

	if(game.score >= 500) and (game.freelives < 2) then
		game.lives += 1
		game.freelives += 1	
		make_mesg(player.x, player.y, "1up")
		sfx(18)
	end	

	if(game.score >= 1000) and (game.freelives < 3) then
		game.lives += 1
		game.freelives += 1	
		make_mesg(player.x, player.y, "1up")
		sfx(18)
	end	

	if(game.score >= 2000) and (game.freelives < 4) then
		game.lives += 1
		game.freelives += 1	
		make_mesg(player.x, player.y, "1up")
		sfx(18)
	end	

	if(game.score >= 5000) and (game.freelives < 5) then
		game.lives += 1
		game.freelives += 1	
		make_mesg(player.x, player.y, "1up")
		sfx(18)
	end	


end


function showtitle()

	droptext(45, 30, "super")
	spr(75, game.camerax + 40, 40, 4, 1)
	spr(75, game.camerax + 55, 50, 4, 1)
	droptext(40, 70, "push button!")
	droptext(4, 120, "matthew riche  2016")
	droptext(34, 2, "hi score:")
	draw_paddedscore(72, 2, game.highscore)
end

function attractscreen()
end


function draw_paddedscore(x, y, number)
	-- convert the int to a padded score
	local justifier = 0
	
	if (number < 10) then
		justifier = -16
		droptext(x,y,"0000")
	end
	if (number > 9) and (number < 100) then
		justifier = -12
		droptext(x,y,"000")
	end
	if (number > 99) and (number < 1000) then
		justifier = -8
		droptext(x,y,"00")
	end
	if (number > 999) and (number < 10000) then
		justifier = -4
		droptext(x,y,"0")
	end
	if (number > 9999) then
		justifier = 0
	end
	droptext((x) - justifier, y, (number))
	droptext((x + 20),y, "00")
		
end

function gameover()
	game.stage = -1
	game.nasty = false
	game.levelnum = -1
	player.hat = 0
	game.prizecounter = 0
	player.lives = 2
	game.titleon = true
	next_level(game.stage)
	game.lives = 2
	if (game.score >= game.highscore) then
		game.highscore = game.score
	end

	game.freelives = 0	
	game.overcounter = 0
	game.score = 0

end


function showgameover()
	droptext(50, 60, "game over")
end


function _draw()
 -- this also happens every frame
	--cls()

	rectfill(game.camerax, game.cameray, game.camerax + 128, game.cameray + 128, (game.sky))
	if(game.titleon == false) then
		cameraupdate()
	end

	camera (game.camerax, game.cameray)

	if(game.nasty) then
		pal()
		alttilepal(1)
	else
		pal()
	end
	drawstage()
	
	
	if(game.titleon == false) then
		drawhud()
	end
	
	if(game.titleon == false) then
		if(game.nasty) then
			burn_world()
		end

		if(game.nasty) then
			altpal(1)
		end
		foreach(actors, draw_actor)
		
		pal()
		foreach(ephem, ephem_update)
		animate_player()
	end

	if(game.mesgon == true) then
		draw_gamemesg(game.mesgx, game.mesgy, game.mesg)
		game.mesgy -= .5
		game.mesgtime -= 1
		if(game.mesgtime <= 0) then
			game.mesgon = false
		end
	end
	
	if(game.levelbeat == true) then
		show_endlevel()
	end

	if(game.titleon == true) then
		showtitle()
 end

	if(game.lives <= -1) then
		showgameover()
		game.overcounter += 1
		if(game.overcounter >= 200) then
			gameover()
		end
	end

	-- corrupter!
 --for i=1,1 do
 --  poke(rnd(0x8000),rnd(0x100))
 --end

end
