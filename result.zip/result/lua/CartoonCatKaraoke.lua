function _init()

 debug=false
 m=9.946 -- on my machine i had to use: 9.946
 sl=192

 t=-1
 mt=0

 bgcol=2

 step=nil
 lin={}
 llin={}
 flin={}

 l={
{0,'everybody\'s'},
{1,''},
{2,''},
{3,''},
{4,'saying'},
{5,''},
{6,'you\'re'},
{7,'no'},
{8,'good',true},
{10,'for'},
{11,'me,',true},
{12,'',true},
{13,''},
{15,'but'},
{16,'they'},
{17,'don\'t'},
{18,'see'},
{19,'the'},
{20,'dirty'},
{21,''},
{22,'stuff'},
{23,''},
{24,'you',true},--u 23
{25,'do'},--24
{26,'to'},
{27,'me',true},
{28,'',true},
{29,''},
{31,'',true},--31
{32,'tell'},--31
{33,'me'},
{34,'i'},
{35,'should'},
{36,'leave',true},
{38,'nearly'},
{39,''},
{40,'every',true},
{42,''},
{43,'day',true},
{45,'',true},
{46,'',true},
{48,'i\'m'},
{49,'not'},
{50,'gonna'},
{51,''},
{52,'do'},
{53,'it'},
{54,'baby'},
{55,''},
{58,'no',true},
{60,'way!',true},
{61,'',true},
{62,''},
{64,'everybody\'s'},
{65,''},
{66,''},
{67,''},
{68,'saying'},
{69,''},
{70,'you\'re'},
{71,'no'},
{72,'good',true},
{74,'for'},
{75,'me,',true},
{76,'',true},
{77,''},
{79,'but'},
{80,'they'},
{81,'don\'t'},
{82,'see'},
{83,'the'},
{84,'dirty'},
{85,''},
{86,'stuff'},
{87,''},
{88,'you',true},--u 87
{89,'do'},--88
{90,'to'},
{91,'me,',true},
{92,'',true},
{93,''},
{94,'you'},--94
{95,'only',true},--95
{97,''},
{98,'show'},--97
{99,'a'},
{100,'little'},
{101,''},
{102,'but'},
{103,'you'},
{104,'give',true},
{106,'me'},
{107,'more',true},
{109,'',true},
{111,''},
{112,'behind',true},
{113,'',true},
{115,''},
{116,'behind',true},
{117,'',true},
{119,''},
{120,'behind,',true},
{121,'',true},
{123,''},
{124,'behind',true},
{125,''},
{126,'closed',true},
{128,'doors'},
{129,'',true},
{130,'',true},
{155,''},
{156,'behind',true},
{157,''},
{158,'closed',true},
{160,'doors'},
{161,'',true},
{162,'',true},
{999,'oh no!'}
 }


-- music()


end

function _update60()

 tm=t%(sl*m)

  if btnp(3) then
   debug=not debug
  end


  -- start music again in sync with t. the sync between graphics and audio in pico8 drifts on my machine
  if(flr(tm)==0)music(0)


  if btnp(0) then
    ptn = flr((tm-15)/(m*16))%11
    music(ptn)
    t=ptn*(m*16)
  end

  if btnp(1) then
    ptn = flr((tm+(m*16))/(m*16))%11
    music(ptn)
    t=ptn*(m*16)
  end


 if debug then

  --magically slow music down by half
  poke(0x5f40,15) 

  tinc=.5

 else

  --magically slow music down by half
  poke(0x5f40,0) 

  tinc=1

 end

--30fps
--tinc=tinc*2

 t+=tinc
 mt-=tinc

end

function _draw()

-- cls()
 rectfill(0,0,127,127,bgcol)

 tm=t%(sl*m)

 beat=(tm/(m*2))%4
 intp=beat%1
 beat=flr(beat)+1
 beat16=flr((tm/(m/2))%16)

 lin={}
 lint=tm-tm%(m*8)
 local mnow=false
 for i=lint,lint+(m*8-1),m do
  lstep=get_step(i)
  if lstep[2] then
   add(lin,{lstep[1],lstep[3]})
   if (i-lint)/m==(beat16/2) then
    step=lstep
    if lstep[4] then
     mnow=-1
    else
     mnow=true
    end
   end
  elseif lstep[3] then
   add(lin,{{lstep[1][1],''},lstep[3]})
  end
 end

-- flin=lin
-- llin=lin

 if #lin>0 then
  flin=lin
  llin=lin
 else
  flin=llin
 end
  
-- cursor(1,1)
 local textlin=''
 local xs={}
 foreach(flin, function(lini)
--     print(lini[2])
  if #lini[1][2]>0 then
   textlin=textlin..' '..lini[1][2]
  end
  if lini[2] then
   if #textlin>0 then
    add(xs,#textlin-#lini[1][2]/2)
   else
    add(xs,-24)
   end
  end
  add(lini,#textlin)
 end)
 if textlin==' doors' or #textlin==0 then
  --contrive the bouncing
  textlin=' doors'
  xs={3.25,3.25,3.25,3.25,3.25}
 else
  add(xs,32+#textlin/2)
 end
--color(2)
--cursor(0,0)
--print(xs[1]..' '..xs[2]..' '..xs[3]..' '..xs[4]..' '..xs[5])
 textx=64-((#textlin+1)*2)
 color(0)
 cursor(textx+1,41)
 print(textlin)
 color(7)
 cursor(textx,40)
 print(textlin)

-- beat=flr(tm/(m*2))%4+1
-- intp=(tm/20)%1%.99

 if mnow==-1 then
  mt=12
 elseif mnow then
  mt=1
 end

 posx=xs[beat]
 posx+=(xs[beat+1]-xs[beat])*intp

 yoff=abs(sin(intp/2))*.99

--color(2)
--cursor(0,10)
--print(intp)

 -- bouncy ball
 circfill(
 	textx
 	 +posx*4,
  36-yoff*16.9,
  2,
  7
 )


 hxoff=0

 if (
 	 step[1][1]>=58
   and step[1][1]<64
  )
 then
  -- no way!
  hxoff=4
 end 

 -- sincere
 eyesp=68

 if (
   step[1][1]>=16
   and step[1][1]<31
  )
  or (
   step[1][1]>=80
   and step[1][1]<90
  )
 then
  -- sly
  eyesp=132


 elseif (
 	 step[1][1]>=58
   and step[1][1]<64
  )
  or (
 	 step[1][1]>=90
   and step[1][1]<96
  )
 then
  -- xd
  eyesp=100


 elseif (
 	 step[1][1]>=48
   and step[1][1]<58
  )
  or (
 	 step[1][1]>=155
   and tm<1800
  )
 then
  -- fourth wall
  eyesp=136


 elseif (
 	 step[1][1]>=111
   and step[1][1]<123
  )
  or (
 	 tm>=1400
   and step[1][1]<155
  )
  or (
 	 tm>=1800
  )
 then
  -- uwu
  eyesp=164


 end

 
 palt()

 -- shoulders
-- circfill(13,144-yoff*3,30,7)
 circfill(27,132-yoff*3,12,7)

 circfill(24,126-yoff*3,12,7)
 circfill(6,128-yoff*3,14,7)
 circfill(13+hxoff*.25,114-yoff*3,5,7)
 clip(31,122-yoff*3,11,10)
 circ(26,131-yoff*3,10,0)
 clip()

 -- collar
 circfill(17+hxoff*.5,105-yoff*4+hxoff*.25,12,12)



 camera(0-hxoff*.5,yoff*6-hxoff*.5)

 -- head
 circfill(18,92,23,7)
 circfill(31,101,12,7)

 -- ears
 palt(0,false)
 palt(2,true)
 spr(
  72,
  -3,60,
  6,3
 )
 palt()

 -- nose
 clip(30+hxoff*.5,101-yoff*6+hxoff*.5,7,3)
 circfill(33,100,2,0)
 clip()

 palt(0,false)
 palt(7,true)

 -- eyes
 spr(
  eyesp,
  10,84,
  4,2
 )

 -- mouth
 mspr=16
 if(mt>0) mspr+=2
 spr(
  mspr,
  20,104,
  2,2
 )
 palt()

 camera(0,0)

 for py=74,127 do
  for px=0,49 do
   if pget(px,py)==bgcol
    and (
    	pget(px-1,py)==7
    	or pget(px,py+1)==7
    	or pget(px,py-1)==7
--    	or pget(px+1,py)==7
    )
   then
    pset(px,py,0)
   end
  end
 end

 -- mic
 palt(0,false)
 palt(2,true)
 spr(
  64,
--  38+hxoff*.25,106-yoff*4+hxoff*.25,
  38,106-yoff*4,
--  38-hxoff*.25,106-yoff*4-hxoff*.25,
  4,4
 )
 palt()
 

-- color(5)
-- if #step[1]>=2 then
--  if(step[2]) color(7)
--  print(step[1][2],0,95)
-- end

--print(lint,100,110,5)

-- cpu
--print(stat(1),100,120,5)

end

function get_step(t)

 local li=1

 t%=sl*m

 while li<#l and l[li][1]*m<=t do
  li+=1
 end
 li=(li-1)%#l

 local mtype=false
 if #l[li]>=3 and l[li][3] then
  mtype=true
 end

 return {
  l[li],
  l[li][1]*m==t,
  flr(t%(m*2))==0,
  mtype
 }

end
if(_update60)_update=function()_update60()_update_buttons()_update60()end