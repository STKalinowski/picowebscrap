--puroresu no seishin
--by jumalauta
function a(b)
return rnd(100)<b
end
function c(d,e,f,g,h,i)
if i=="x"then return d,e*h-f*g,e*g+f*h end
if i=="y"then return f*g+d*h,e,f*h-d*g end
if i=="z"then return d*h-e*g,d*g+e*h,f end
end
function j(d,e,f)
return{k(-63.5*(d/f)+63.5),k(-63.5*(e/f)+63.5)}
end
function k(l)
return flr(l+0.5)
end
function m(n)
local o,p,q,r="",{},{},1
for r=1,#n do
s=sub(n,r,r)
if s=="_"or s=="|"then
if tonum(o) then o=tonum(o) end
add(p,o)
o=""
else
o=o..s
end
if s=="|"then
add(q,p)
p={}
end
end
if#q==1 then return q[1] end
return q
end
function t(n)
local u=""
r=1
while r<#n do
v=w(n,r)
r+=1
for x=1,v do
u=u..sub(n,r,r)
end
r+=1
end
return u
end
function y(z)
ba,bb,bc,r="",{},"",2
for bd=1,#z do
for be=3,0,0xffff do
ba=ba..band(1,shr(w(z,bd),be))
end
end
function bf(bg)
r+=1
if sub(ba,r,r)=="0"then
for be=1,2 do
add(bg,{})
bf(bg[be])
end
else
bg.bh=sub(tostr(tonum("0b"..sub(ba,r+1,r+8)),true),5,6)
r+=8
end
end
bf(bb)
function bi(bg)
if bg.bh then
bc=bc..bg.bh
else
r+=1
bi(bg[sub(ba,r,r)+1])
end
end
while r<#ba-tonum("0b"..sub(ba,1,2)) do
bi(bb)
end
return bc
end
function bj(bk)
local bl={bm={},bn={}}
function bo(bp,bq)
for r in all(bq) do
add(bp,{r[1],r[2],r[3]})
end
end
bo(bl.bn,bk.bn)
bo(bl.bm,bk.bm)
bl.br,bl.bs,bl.bt=bk.br,bk.bs,bk.bt
return bl
end
function bu(bv)
for x=1,3 do
local be=x
while be>1 and bv[be-1][2]>bv[be][2] do
bv[be],bv[be-1]=bv[be-1],bv[be]
be-=1
end
end
bw,bx,by,bz,ca,cb=bv[1][1],bv[2][1],bv[3][1],bv[1][2],bv[2][2],bv[3][2]
cc=bw+((ca-bz)/(cb-bz))*(by-bw)
cd(bw,bz,bx,ca,cc,1)
cd(by,cb,bx,ca,cc,0xffff)
end
function cd(ce,cf,cg,ch,ci,cj)
ck,cl,cm=(cg-ce)/(ch-cf),(ci-ce)/(ch-cf),ce
for cn=cf,ch,cj do
line(k(ce),cn,k(cm),cn)
ce+=cj*ck
cm+=cj*cl
end
end
function co(bk)
for r=1,#bk.br do
cp,bv,cq,cr={},{},0,cs[bk.bs[r]]
for be=1,3 do
add(cp,bk.bn[bk.br[r][be]])
ct=cp[be]
add(bv,j(ct[1],ct[2],ct[3]))
cq+=ct[3]
end
add(cp,bk.bm[bk.br[r][4]])
if((bv[2][1]-bv[1][1])*(bv[3][2]-bv[1][2])-(bv[3][1]-bv[1][1])*(bv[2][2]-bv[1][2]))/2>0 then
add(cu[bk.bt[r]],{bv[1],bv[2],bv[3],bk.bs[r],cr,mid(1,128,flr((cp[4][3])*cr.cv)+cr.cw),cq})
end
end
end
function cx(bk,cy,i)
if#bk==0 then
cx(bk.bn,cy,i)
cx(bk.bm,cy,i)
return
end
cz,da=sin(cy),cos(cy)
for r in all(bk) do
r[1],r[2],r[3]=c(r[1],r[2],r[3],cz,da,i)
end
end
function db(bk,d,e,f)
for r in all(bk.bn) do
r[1]+=d
r[2]+=e
r[3]+=f
end
end
function dc()
for dd in all(cu) do
for r=1,#dd do
local be=r
while be>1 and dd[be-1][7]>dd[be][7] do
dd[be],dd[be-1]=dd[be-1],dd[be]
be-=1
end
end
for r in all(dd) do
color(r[5].de[r[6]])
bu(r)
end
end
fillp()
end
function df(dg)
local dh={bn={},bm={},br={},bs={},bt={}}
function di(b,dj)
for r=1,#dg[b]-1,12 do
dk,dl={},sub(dg[b],r,r+11)
for be=1,9,4 do
dm=sub(dl,be,be+3)
add(dk,tonum("0x"..sub(dm,1,1).."."..sub(dm,2,4))-8)
end
add(dj,dk)
end
end
di(1,dh.bn)
di(2,dh.bm)
for r=1,#dg[4] do
bd,cp=r*8-7,{}
for be=bd,bd+7,2 do
add(cp,w(dg[3],be,1))
end
add(dh.br,cp)
add(dh.bs,tonum(sub(dg[4],r,r)))
add(dh.bt,tonum(sub(dg[5],r,r)))
end
return dh
end
function dn(dp,dq)
r,x,dr=1,1,{}
while r<dp[1] do
add(dr,dq)
r+=1
end
while r<129 do
ds,dt=x-1+dq,1
if x<#dp then
dt=flr(16/(dp[x+1]-dp[x])*(r-dp[x]))+1
end
add(dr,17*ds+16+du[dt])
r+=1
if r==dp[x+1] then x+=1 end
end
return dr
end
function dv(dq,dw)
u=""
for r=dq,dq+dw-1 do
u=u..sub(tostr(peek(r),true),5,6)
end
return u
end
function dx()
local r=1
while r<#dy[2] do
poke(dy[1],w(dy[2],r,1))
r+=2
dy[1]+=1
end
end
function dz(ea,n)
dy={ea,n}
dx()
end
function w(eb,ec,ed)
ec=ec or 1
ed=ed or 0
return tonum("0x"..sub(eb,ec,ec+ed))
end
function ee(ef)
eg,eh,r,ei,ej={{}},{},1,{},{}
local b=1
while b<=#ef do
ek=sub(ef,b,b+1)
if ek=="ff"then
add(eg[r],eh)
eh={}
if#eg[r]==5 then
ej[r]=false
r+=1
eg[r]={}
end
else
add(ei,w(ek,1,1))
if#ei==7 then
add(eh,ei)
ei={}
end
end
b+=2
end
return eg
end
function el(em,cy)
return em*cos(cy),em*sin(cy)
end
function en()
end
function eo()
for ep=1,32 do
for eq=1,64 do
poke(0x42bf+ep*64+eq,er[b][ep][eq])
end
end
end
function es()
for et=1,35 do
eu,ev,er[et],ew={},{},{},64*ex[et][1]
for ey=1,128 do
add(eu,ex[et][2]+(ey-129)/ew)
end
for ez=0,31 do
fa,fb=ez/ew,{}
for fc=0,127 do
fd,ey,fe,ff,fg=eu[fc+1],0,0,0,0
while ey+fe<=4 and fg<42 do
fh,fi=ey-fe+fd,ff-ey-fe+fa
ey,fe,ff=fh^2,fi^2,(fh+fi)^2
fg+=1
end
add(ev,fg%7)
if#ev==2 then
add(fb,ev[1]+16*ev[2])
ev={}
end
end
add(er[et],fb)
end
end
end
function _init()
du=m("0b1000000000000.0000000000000000_0b1000000000000.1000000000000000_0b1000000000000.1000000000100000_0b1000000000000.1010000000100000_0b1000000000000.1010000010100000_0b1000000000000.1010010010100000_0b1000000000000.1010010010100001_0b1000000000000.1010010110100001_0b1000000000000.1010010110100101_0b1000000000000.1110010110100101_0b1000000000000.1110010110110101_0b1000000000000.1111010110110101_0b1000000000000.1111010111110101_0b1000000000000.1111110111110101_0b1000000000000.1111110111110111_0b1000000000000.1111111111110111|")
fj,fk,fl,fm,fn,ex,er,fo,fp,fq,fr,fs,ft,fu,fv,fw,fx,fy,fz,ga,gb,gc,gd,ge,gf,gg,gh,gi,gj,gk,gl,gm,gn,go="123121121321321323323123143141141341341343343143567565565765765767767567587585585785785787787587597595595795795797797597143163141161341361343363163567161565361765363767183587181585381785383787193597191595391795393797",m("-2_0_2_0.525_-1.8_-0.9_1.8_-0.6_-0.3|"),{},m("0_0_-0.39|-0.27_0_0|0_0_0.37|-0.79_0_0|0_0_-0.12|0.82_0_0|0_0_-0.35|-0.44_0_0|0_0_-0.46|-0.01_0_0|0_0_0.9|0.15_0_0|0_0_0.42|-0.58_0_0|0_0_-0.99|0.06_0_0|0_0_0.82|-0.48_0_0|0_0_0.48|-0.2_0_0|0_0.52_0|0_-0.74_0|0_0.31_0|0_-0.73_0|-1_0_1|-1_0_-1|1_0_-1|1_0_1|-1_0_1|-1_0_-1|1_0_-1|1_0_1|-1_0_1|-1_0_-1|1_0_-1|1_0_1|"),0,m("0.2_4.75_0|0.2461_3.8128_12|0.3029_2.9242_10|0.3728_2.0991_8|0.4589_1.3866_7|0.5648_0.8077_7|0.6951_0.3651_8|0.8555_0.0054_8|1.0529_-0.3051_7|1.2959_-0.5722_6|1.595_-0.8013_5|1.9631_-0.9972_4|2.4162_-1.1644_3|2.9738_-1.3066_2|3.6604_-1.417_3|4.5054_-1.5024_4|5.5454_-1.5683_5|6.8252_-1.6191_6|8.402_-1.658_7|10.3434_-1.6878_8|12.7304_-1.7105_9|15.671_-1.7277_10|19.298_-1.7407_11|23.7621_-1.7504_12|29.2571_-1.7577_13|36.0088_-1.763_14|44.341_-1.767_15|54.6133_-1.7698_16|67.2854_-1.7718_17|82.957_-1.7733_18|102.4_-1.7744_18|126.0308_-1.7755_17|155.2986_-1.7765_16|191.6257_-1.7774_15|237.4493_-1.7783_14|"),{},m("661_3520|667_4544|672_5568|683_6592|"),false,{true},{},{},{},{{},{},{},{}},dn(m("0_32_64_96|"),4),m("627_638_649_682|"),{},{m("128_96_160_96|160_96_192_64|192_64_192_32|192_32_160_32|160_32_160_64|160_64_128_64|128_64_128_96|200_32_200_96|200_96_248_96|248_96_264_80|264_80_264_32|264_32_232_64|232_64_232_32|232_32_200_32|272_96_272_64|272_64_304_32|304_32_304_64|304_64_336_32|336_32_336_96|336_96_272_96|344_96_408_32|408_32_408_96|408_96_344_96|416_32_416_96|416_96_480_96|480_96_480_64|480_64_448_64|448_64_448_32|448_32_416_32|488_96_552_32|552_32_552_96|552_96_488_96|560_32_560_96|560_96_608_96|608_96_624_80|624_80_624_32|624_32_592_64|592_64_592_32|592_32_560_32|632_32_696_32|696_32_696_96|696_96_632_32|704_96_768_32|768_32_768_96|768_96_704_96|"),m("128_48_128_80|128_48_160_48|160_48_144_64|144_64_144_80|144_80_128_80|164_48_164_80|164_80_188_80|188_80_196_72|196_72_196_48|196_48_180_64|180_64_180_48|180_48_164_48|200_48_200_80|200_80_232_48|232_48_200_48|216_64_232_64|232_64_216_80|216_80_216_64|244_48_268_48|268_48_268_72|268_72_260_80|260_80_236_80|236_80_236_56|236_56_244_48|272_48_272_80|272_80_304_48|304_48_272_48|288_64_304_64|304_64_288_80|288_80_288_64|308_48_308_72|308_72_316_80|316_80_340_80|340_80_340_48|340_48_308_48|340_59_324_59|340_69_324_69|352_48_376_48|376_48_344_80|344_64_344_56|344_56_352_48|344_80_368_80|368_80_376_72|376_72_376_64|376_64_344_64|380_48_380_80|380_80_404_80|404_80_412_72|412_72_412_48|412_48_396_64|396_64_396_48|396_48_380_48|428_48_428_80|428_80_444_80|444_48_460_48|460_48_460_80|428_48_460_80|444_48_444_80|472_48_496_48|496_48_496_72|496_72_488_80|488_80_464_80|464_80_464_56|464_56_472_48|520_48_544_48|544_48_512_80|512_64_512_56|512_56_520_48|512_80_536_80|536_80_544_72|544_72_544_64|544_64_512_64|548_48_548_72|548_72_556_80|556_80_580_80|580_80_580_48|580_48_548_48|580_59_564_59|580_69_564_69|584_48_600_48|600_48_600_80|600_80_584_80|584_80_584_48|612_48_636_48|636_48_604_80|604_64_604_56|604_56_612_48|604_80_628_80|628_80_636_72|636_72_636_64|636_64_604_64|640_80_640_56|640_56_648_48|648_48_672_48|672_48_672_72|672_72_664_80|664_80_640_80|656_48_656_59|656_69_656_80|676_48_692_48|692_48_692_80|692_80_676_80|676_80_676_48|696_48_696_80|696_80_712_80|712_48_728_48|728_48_728_80|696_48_728_80|712_48_712_80|")},dn(m("0_32_64_96|"),0),{},{},{},{},m("1_352|2_1496|3_350|4_203|4_379|4_555|5_11|5_659|6_176|6_528|7_46|7_222|7_398|7_574|8_1|9_46|9_222|9_398|9_574|10_616|10_649|10_682|"),m("979_990_1001_1034_1067_1078_1089_1122_1155_1166_1177_1210|"),dn(m("0_66_89_113|"),0),dn(m("0_47_95_110_124|"),0),m("0_4_13_17_21_25_29_33_41_45_52|"),{},m("0_0_0_0_112_54_12_40|8_4_0_0_112_54_9_38|15_9_0_0_112_54_9_37|"),m("0_704_100_91_18_-1_57|0_704_107_69_29_1_64|704_1408_114_70_29_-1_57|704_1408_121_101_13_1_64|"),m("0080850585860d068009070b82028809_0081050600050607800907ff82028809_000506070085860f8009070882028809_000506070085860f8009070882028809|"),m("66_78|52_52|75_54|103_96|"),m("0_15|-22_11|-55_7|-66_3|")
gp,gq=cocreate(es),cocreate(en)
for r=1,256 do
add(fq,false)
add(gc,{d=rnd(128),e=rnd(128),gr=0xffff})
add(gd,r)
add(gj,{})
end
for r=1,216,6 do
gs={}
for be=0,3,3 do
gt={}
for bd=0,2 do
b=r+be+bd
add(gt,fk[sub(fj,b,b)+0])
end
add(gs,gt)
end
add(fl,gs)
end
memset(0x5f10,129,16)
poke(0x5f34,1)
cls()
while#er<22 do
coresume(gp)
end
function gu(gv,gw,gx,gy,gz)
function ha(b)
hb=""
while#hb<b do
hb=hb..gw
end
return hb
end
n,r="",1
while r<#gv do
n=n..ha(gx)..sub(gv,r,r+gy-1)..ha(gz)
r+=gy
end
return n
end
function hc(hd)
he=hf[hd]
if he==nil then
return
end
gv,hg=sub(hg,1,he[1]),sub(hg,he[1]+1)
if he[2]==1 then gv=y(gv) end
if he[3]==1 then gv=t(gv) end
if#he>3 then
hh=he
gv=gu(gv,hi(4,7))
end
if hd<=#hf then
return gv,hc(hd+1)
end
end
hg,hf=dv(0,0x4300).."b6db6db6db662cd80",m("6_0_1|7_1_1|7_1_1|7_1_1|8_0_1|10_1_1|10_0_1|10_0_1|19_1_0|22_1_0|58_1_0_0_96_32_0|97_1_0|120_1_0_0_60_68_0|128_1_0_0_50_78_0|160_1_0_0_16_96_16|183_1_0|206_1_0|228_1_1_0_45_67_16|247_1_1_f_1_99_28|257_1_0|260_1_1_0_13_67_48|284_1_1|320_1_0|321_1_0|395_1_0|413_1_0|417_1_0_0_6_116_6|424_1_0|467_1_0_f_0_40_88|512_0_0|528_0_0|550_1_0|560_1_1|603_1_0|665_1_0_e_0_102_26|666_0_0|716_1_0_0_0_99_29|729_1_0|798_1_0|805_1_0_0_4_120_4|826_1_0_f_64_60_4|854_1_1|908_1_0|975_1_1|1052_1_0_0_0_100_28|1207_1_1_1_62_66_0|1208_1_0|1209_1_1_1_22_58_48|1228_1_0|1278_1_0_0_4_124_0|1641_1_1_1_12_60_56|2965_1_1_0_0_112_16|6746_1_0|1_0_0|")
fu[3][5],ft[5],fu[4][4],fu[4][5],fu[1][5],ft[4],fu[2][4],fu[2][5],fu[3][4],fu[1][4],gb[3],fu[2][2],gb[2],gb[1],hj,fu[3][1],fu[4][2],hk,hl,fu[3][3],hm,fu[1][2],fu[1][1],fu[3][2],ft[1],fu[1][3],hn,ft[2],ho,fu[4][3],fu[2][3],ft[3],hp,fu[2][1],hq,hr,hs,fu[4][1],ht,hu,hv,hw,hx,hy,hz,fr[3],ia,fr[2],ib,ic,fr[1],id,ie=hc(1)
dz(0x3100,ie)
for r=1,2 do
b=r
eo()
memcpy(0,0x0800,2048)
memcpy(0x0800,0x4300,2048)
end
ig=ex[2][3]
ih(0)
clip()
for e=1,29 do
memcpy(0x7000-e*64,0x7000+e*64,64)
end
memcpy(0x1000,0x6800,4096)
hf,hg,ie,ii,ij,b,ik,il,im,io,ip,iq,ir,is,fs,it,iu,iv,iw,eg,fr[4],ix=nil,nil,nil,df(ft),{},1,{},m("1_12_23_34_45_56_67_78_89_100_111_122_133_144_155_166_188_221_227_232_276_309_315_320|"),{},{},m("0_1_2_12_14_15_17|0_1_2_8_9_10_15|0_1_2_12_14_15_17|0_1_2_8_9_10_15|"),0,{},m("616_627_649_682|"),{},0,1,m("high fly_flow|rainmaker|tiger_driver_91|bomaye|"),m("0_78_78_40|0_93_51_80|176_78_105_65|352_78_51_20|352_93_63_37|352_108_21_54|528_78_75_80|"),ee(ht),dv(4032,4160),m("-1_0_-3.5|0_0_-7|1_2_-6|0_0_-10|")
dz(0,ho..hv)
memcpy(0x6000,0,8192)
for r=0,7 do
cls()
memcpy(0x6000,2560+r*640,640)
sspr(0,r*5,64,5,0,0)
add(fs,dv(0x6000,640))
end
for dh in all(fu) do add(ij,df(dh)) end
for r=1,4 do
add(ir,{})
for iy=1,64 do
add(ir[r],mid(0,-7,-7-flr(14*sin(((iy-33)/32+r*0.25)%1))))
end
end
for r=1,5 do
add(ik,{iz=0})
end
for r in all(il) do
im[r]=true
end
for r=1,352 do
add(io,0)
end
for r=1,8 do
for be=1,6 do
io[r*44-be-16],io[171-be]=be,be
end
end
dz(0x6000,id)
for d=0,112 do
for e=0,54 do
function ja(jb,jc)
if pget(d,e+jb)!=0 then add(gj[pget(d,e+jb)+jc],{d,e}) end
end
ja(0,0)
ja(54,15)
end
end
cls()
memset(0,0,8192)
dz(0,hu)
dz(2304,hn)
music()
jd,je,jf,jg,jh,ji,jj=1,0,0,false,0,0,{}
end
function jk()
jl()
dz(0x1900,hs)
end
function jm()
jl()
for r=1,5 do
add(fx,false)
end
jn,jg,ji=m("0.007_0.0044|0.005_0.007|0.008_0.0065|0.0034_0.0073|0_0|"),true,0xfd40
end
function jo()
jp,jq,jr,js,b=0,1,0,"",1
jt=cocreate(eo)
ju=0
end
function jv()
b=2
memset(0,0,8192)
end
function jw(jx)
local cs={}
for b=1,3,2 do
add(cs,{
cv=jx[b][1],
cw=jx[b][2],
de=dn(jx[b+1],jx[b][3]),
jy=jx[b][3]
})
end
return cs
end
function jz()
er,gc,ka,kb,kc,kd=nil,nil,m("1_0_0.0053_0_1_y|1_0.1_-0.001_0_1_z|2_0.1_0.0032_0_1_y|2_-0.08_0.00066_0_1_x|3_0_0.01_0_1_y|3_0_0_0.5_1_z|3_0_0.005_0_1_x|4_0_0.0022_0_0.5_y|"),{m("30_0_0|0_32_64_96|60_30_4|30_60_90|"),m("70_20_0|0_32_64|120_0_4|10_20_50|"),m("70_20_0|0_32_64|60_20_4|0_30_60|"),m("70_20_0|0_32_64|60_20_4|0_30_60|")},{},m(" -0.2884_0.6969_0.4778_-0.595_0.4045_-0.2127_0.589_-0.5385_0.6375_-0.2968_0.2665_0.3572_0.6459_0.4968_-0.2127_0.28_-0.2764_0.3624_0.5723_0.2206_-0.6498_-0.3071_-0.5496_-0.3689_0.5724_-0.5972_0.4967_-0.2355_-0.4511_-0.2286_-0.6888_0.5176_-0.3362_0.4665_0.3199_0.6883_0.3057_-0.6732_-0.4808_0.5877|")
for r in all(kb) do
add(kc,jw(r))
end
dz(0x5f10,"8082058605060789848081018c8b8a00")
dz(4096,hz)
end
function ke()
kf=0
dz(3072,hq)
kg=m("0_44_24_84_2.3_3_0_0_40_200_44_156_40_94_-5.7_9_0_0_0_156|176_220_44_78_3.8_4.3_0_0_216_376_220_332_40_92_-3.6_7.5_0_0_176_332|352_396_74_106_3.9_2.3_0_0_392_552_396_508_84_106_-3.1_4.8_0_0_352_508|528_572_29_75_1.8_3.215_0_0_572_728_572_684_38_83_-6.1_9.8_0_0_528_684|")
function kh()
ki={}
for r=1,150 do
ki[r]=bj(ii)
db(ki[r],0,-1,0)
cx(ki[r],0.25,"y")
cx(ki[r],-r/150,"x")
end
end
gp=cocreate(kh)
end
function kj()
it,iu,iv,iw,kk,cs,kl,km,kn,kf,ko,eg=0,1,m("kamigoye|one winged_angel|destino|burning_hammer|"),m("0_78_93_70|176_78_108_40|176_93_57_75|352_78_75_55|528_78_75_80|528_93_81_97|"),{},jw(m("328_-200_0|0_91_98_105|128_0_4|0_40_80|")),dn(m("0_32_64_96|"),11),m("0.002_0.005|0.003_0.003|0.001_0.0027|0.0022_0.0011|"),false,5,m("7_7_7_8_8|11_8_8_9_9|"),ee(hx)
for r=1,8 do
add(kk,false)
end
pal()
fillp()
for e=68,127 do
kp,kq=11,1024/(e-64)
if e>80 or e%2==0 then kp=7 end
for d=0,128 do
bx,kr=kq-(d*kq/64),0
if bx%14>7 then kr=2 end
color(flr((kq*0.7)%4+kr)%4+kp)
if abs(bx)>14 then color(15) end
pset(d,e)
end
end
memcpy(0x1100,0x7100,3840)
dz(0x5f10,"8082058605060789848081018c8b8a00")
dz(2048,hp..hl)
end
function ks()
pal()
kf,kg=0,m("0_44_24_104_6.3_3.4_0_0_40_200_44_156_25_90_-6.2_9.2_0_0_0_156|178_220_34_78_2.5_4.3_0_0_216_376_220_332_50_82_-5.1_6.2_0_0_176_332|352_396_77_93_1.9_4.3_0_0_392_225_396_508_42_100_-6.5_8.8_0_0_352_508|528_572_29_94_4.8_8.215_0_0_572_728_572_684_30_98_-3.5_4.3_0_0_528_684|")
dz(3072,hq)
end
function kt()
memset(0,0,8192)
end
function ku()
fillp()
end
function _update60()
kv={nil,jk,jm,jo,jv,jz,ke,kj,ks,kt,ku}
for bd,bv in pairs(gi) do if stat(24)>=bv then jd=bd end end
if jd==2 and jh>1377 and jh<1408 then
for iy in all(gj[jh-1377]) do
sset(iy[1],iy[2],15)
end
end
if fq[jd]==false then
cls()
pal()
kv[jd]()
jh,fq[jd]=0,true
end
jh+=1
ji+=1
kw=flr(((stat(24)-gi[jd])*351+stat(26))/2.0026)
if jg==true and jh<kw and kw<jh+5 then jh=kw end
fn-=1
end
function kx()
pal()
memcpy(0x6a00,0,2136*ceil(jh/352))
if jh%11<4 and jh%88>10 then
jb=0x6840
while jb<0x7240 do
ky=flr(2+rnd(1.15))
while a(99.5) do
jb+=1
poke(jb,peek(jb)*ky)
end
jb+=64
end
end
for jb=0x6800,0x76c0 do
if jh<rnd(50) or jh>685-rnd(50) then
poke(jb,0)
end
end
poke4(0x5f11,0x0409.0208)
end
function kz()
if jh>1346 then
for r=1,350 do
la,lb=rnd(128),rnd(54)
if sget(la,lb)==15 then sset(la,lb,14) end
end
end
lc,ld,le,lf,lg,lh=8,sin(jh*0.001),cos(jh*0.001),sin(0.04),cos(0.04),max(0,40/jh-1)
if jh>=1408 then lc=1 end
for ky in all(gc) do
if ky.gr>0.1 then
circfill(ky.d,ky.e,ky.gr,lc)
end
end
for bd,ky in pairs(gc) do
if ky.gr>0.1 then
circfill(ky.d,ky.e+1,ky.gr-1,lc+1)
ky.gr*=0.95
ky.e-=0.1
ky.d+=0.2*(1-rnd(2))
end
if ky.gr<=0.1 and ky.gr>0 then
ky.gr=-1
add(gd,bd)
end
end
camera(0,20)
for r=1,36 do
li={}
for bd=1,2 do
gt={}
for lj=1,3 do
add(gt,fl[r][bd][lj]+lh*fm[r][lj])
end
add(li,gt)
end
lk={}
for be in all(li) do
be[1],be[2],be[3]=c(be[1],be[2],be[3],ld,le,"y")
be[1],be[2],be[3]=c(be[1],be[2],be[3],lf,lg,"x")
add(lk,j(be[1],be[2]+0.8,be[3]-4.5))
end
line(lk[1][1],lk[1][2],lk[2][1],lk[2][2],14)
end
camera()
r=1
while#gd>0 and r<50 do
d,e=rnd(128),rnd(128)
if pget(d,e)==14 then
b=gd[1]
gc[b]={d=d,e=e,gr=2+rnd(max(0,jh/200-1.5))}
del(gd,b)
end
r+=1
end
if jh>1408 then
memcpy(0x6000,0x6004,4092)
memcpy(0x7004,0x7000,4092)
for r=1,30 do
ky,e=rnd(128),63+rnd(2)
line(ky-7,e,ky+7,e,0)
end
end
for ll in all(gk) do
hh=ll
pal(15,hh[1])
pal(14,hh[2])
sspr(hi(3,8))
end
pal()
lm=669
if jh>704 then lm=639 end
ln=jh%704
lo=max(0,100/ln-3)
if ln>lm then lo-=1.15^min(35,ln-lm)-1 end
palt(0,false)
for lp in all(gl) do
if jh>lp[1] and jh<lp[2] then
sspr(0,lp[3],lp[4],7,lp[5]+lp[6]*lo,lp[7])
end
end
palt(0,true)
if jh>=1408 then
sspr(16,110,96,5,16,100)
end
if jh>=1406 and jh<=1418 then
cls()
if jh>=1412 and jh<=1416 then
cls(7)
end
if jh>1414 then
pal(1,0)
pal(2,0)
pal(8,0)
sspr(0,0,112,54,9,37)
for r=1,5 do
memcpy(0x6800+rnd(0x1000),0x6000+rnd(0x1000),64+rnd(200))
end
end
dz(7040,hj)
end
if jh>=1500 and jh%5.5<3 then
cls(7)
end
poke(0x5f1e,7)
if jh>=1408 then poke(0x5f1e,2) end
poke(0x5f1f,7)
end
function lq()
dz(4608,hm)
dz(7680,hk)
gq=cocreate(lr)
end
function lr()
lt=m("1_0|2_1|3_1|8_2|11_3|9_8|10_9|")
for r=1,10 do
for be=0,9 do
for d=0,7 do
for e=0,7 do
lu,lv,lw,lx=be*8+d,72+e,0,(r+1)/0.55+d+e
ly,lz=lu+r*80,lv
if lx>17 then
lu+=32
lv+=48
end
if lx<19 and lx>16 then
lw=1
if lx<18 and lx>17 then lw=2 end
end
while ly>127 do
ly-=128
lz+=8
end
ma=sget(lu,lv)
while lw>0 do
for mb in all(lt) do
if ma==mb[1] then ma=mb[2] end
end
lw-=1
end
sset(ly,lz,ma)
end
end
end
end
end
function mc()
jg=true
md=flr(jh/176)+1
if fx[md]==true then
sspr(64,0,34,34,64,0)
else
dz(0,ic)
sspr(32*md-32,0,32,32,65,1)
rect(64,0,97,33,5)
fx[md]=true
if(md==2) lq()
end
for me=1,35 do
f=35+(jh+3.1*me)%108.5
mf=1.03^f
for mg=1,5 do
if f<jh+70 and f>jh-550 and mf<24 then
cy=mg/5+0.22*(sin(jh*0.003+f*0.01))+me/35
d,e=el(mf,cy)
color(fv[mid(1,128,flr(110-f+min(0,jh-90)))])
circfill(32+d,32+e,f*0.07)
fillp()
end
end
end
memcpy(0,0x6000,4096)
cls()
memset(0x6840,255,0x1000)
for r=1,min(12,(704-jh)*0.5) do
e=rnd(128)
color(0)
if e<32 or e>96 then color(15) end
line(0,e,127,e)
end
for r=1,3 do
cy=r/3+jh*0.0043
d,e=el(13,cy)
sspr(0,0,64,64,32+d,32+e)
end
for r=0,24,8 do
lo=-1
if r%16<8 then lo=1 end
function mh(b)
return 48+32*sin((jh+r)*b)
end
e,d=mh(jn[md][1]),mh(jn[md][2])+lo*1.1^max(0,jh-585)
memcpy(2176,0x6000+flr(e)*64,2240)
dz(0x5f00,"10010203140e050608090a0b0c0d0e00")
sspr(d,34,35,35,d,e)
dz(0x5f00,"100102031400000008090a0b0c0d0e00")
sspr(64,0,34,34,d+2,e+2)
dz(0x5f00,"100102031405060708090a0b0c0d0e0f")
sspr(64,0,34,34,d,e)
end
dz(0x5f10,"0001020304888e0a08090a0b0c0d8280")
if jh%176<rnd(15) and jh<700 then
dz(0x5f10,"8e010203048e0a0708090a0b0c0d8207")
memcpy(0x6000+rnd(6192),0x6000+rnd(6192),2000)
end
if jh>627 then mi(ji) end
for r=1,4 do
if jh>=fw[r] and jh<fw[r]+3 then rectfill(32*r-32,32,32*r-1,96,10) end
end
end
function mi(mj)
mk=0.7*sin(mj*0.003)
for r in all(go) do
if mj<r[1] then ml=r[2] end
end
if mj<0 then rectfill(0,30,10+8*ml,96,0) end
for d=0,ml do
mm,mn,mo=10*k(mid(0,10,-5*(sin((mid(0,10,d-17*(sin(mj*0.0038+0.9))+2)/2+7.5)/10)-1))),0.2*cos(d*0.05-mj*0.0013),0.07*cos(d*0.05-mj*0.0088)
for e=0,7 do
bv=mid(0,9,6+4*cos(e*0.03+mj*0.007+mn)+2*cos(e*0.03+mk+mo))+mm
if mj>=616 then bv=max(0,5+rnd(10)-(mj-616)/5)+100*flr(rnd(2)) end
spr(144+bv,d*8,32+e*8)
end
end
end
function mp()
ca,mq=32,flr(jh/176)
mi(ji)
if jh<616+rnd(80) then
mr=1.08^min(jh,65)-2
line(-1,31,mr,31,7)
line(128-mr,97,128,97,7)
end
if jh>176 and jh<616 then
if jh%176>=22 and jh%176<88 then
if(jh%176<36) camera(-20+rnd(40),0)
for e=0,64 do
if a(100-50*0.5^(jh%176-26)) then
memset(0x5f00,0,16)
poke4(0x5f00,0x0000.1000)
sspr(0,e,128,1,0.07*(jh%176-22),32+e)
pal()
poke4(0x5f00,0x0302.1000)
sspr(0,e,128,1,0,32+e)
end
end
camera()
if jh%176<26 then
if jp<mq then
dz(0,fr[mq]..gb[mq])
jp=mq
end
memset(0x6800,119,4096)
end
sspr(0,65,128,5,0,99)
end
if jh%176>=88 and jh%176<100 then
poke4(0x5f00,0x0302.1000)
poke4(0x5f20,0x6180.2100)
while ca<97 do
ms=min(flr(rnd(6))+2,97-ca)
sspr(0,ca-32,128,ms,6-rnd(12),ca+6-rnd(12))
ca+=ms
end
end
end
if jh>=616 then
pal()
poke4(0x5f00,0x0302.1000)
if jq==4 then
for be=1,7 do
pal(be-0,ip[1][be])
end
camera(0,1)
end
if(a(40)) memset(0x5f02,7,14)
if(a(75)) sspr(0,0,128,65,32-rnd(64),32)
for r=jq,4 do
if jh>=is[r] then
memset(0x6800,119,4096)
flip()
dy={0,fr[jq]}
gq=cocreate(dx)
jq=r+1
end
end
if a(30) then
lj=rnd(8191)
memcpy(0x6000+rnd(0x1fff-lj),0x6000+rnd(0x1fff-lj),lj)
end
end
camera()
end
function ih(mt)
poke4(0x5f20,0x5e80.4000)
mu,mv,mw,mx={mt%21+21,mt%21},{},{},{}
for r=1,2 do
add(mv,ig-(ig/21)*mu[r])
add(mw,103+1.1905*mu[r])
add(mx,26+0.2857*mu[r])
sspr(0,32*r-32,128,32,mv[r],64,mw[r],mx[r])
end
for d=0,127 do
for e=1,3 do
pset(d,90+e,max(0,pget(d,90+e)-e))
end
end
clip()
end
function my()
cls()
pal()
if jh<661 then
palt(0,false)
coresume(jt)
if jh>=ju then
ju+=21
memcpy(0,0x0800,2048)
memcpy(0x0800,0x4300,2048)
ig=ex[b][3]
b+=1
if b>35 then b=1 end
jt=cocreate(eo)
end
ih(jh)
clip()
for e=1,29 do
memcpy(0x7000-e*64,0x7000+e*64,64)
end
memcpy(0x1000,0x6800,4096)
ky=0
if im[jh%352+1]==true then ky=8 end
cls(ky)
if a(44) then
memset(0x6000+flr(rnd(128))*64,136,64)
d=rnd(128)
line(d,rnd(128),d,rnd(128),8)
end
mz,na={},{}
for d=1,128 do
mz[d]=(0.5+0.5*sin(mid(0.25,0.75,(jh-270)*0.003+0.25)))*sin(d*0.0004+jh*0.001)
na[d]=flr((mz[d]%1)*32+1)
end
for r=1,4 do
nb=100
for d=1,128 do
if d%4==1 then nc=ir[r][na[d]] end
if nc==nil then nc=nb end
if(mz[d]+r*0.25)%1<0.5 then
if nc!=nb then
for be=1,7 do
pal(be-0,ip[r][mid(1,7,be+nc+io[jh%352+1])])
end
nb=nc
end
function nd(b)
return flr(64+45*sin(mz[d]+b+r*0.25))
end
bz,ca=nd(0.125),nd(0.375)
sspr(d-1,64,1,64,d-1,bz,1,ca-bz)
end
end
end
else
if fp==false then
ne(hw)
fp=true
end
for r in all(fo) do
if jh>=r[1]+0 then
if jh<r[1]+3 then
poke(0x5f17,0)
poke(0x5f10,7)
end
lj=r[2]
end
end
memcpy(0x6000,0,lj)
end
end
function nf()
ng=min(4,ceil(jh/176))
if ng==4 then
if nh then else
dz(0,ib)
nh=true
end
ni(0,jh-704)
end
function nj(nk,mz)
return sin(0.75+mid(0,nk/2,mz)/nk)
end
b,nl=nj(100,jh-630),33*nj(40,jh-670)
bz=46-16*b
ca=81+17*b
rect(31-nl,bz,97+nl,ca,14)
if nl>-33 then rectfill(32-nl,bz+1,96+nl,ca-1,0) end
clip(32-nl,bz+1,63+2*nl,ca-bz-1)
for r=1,10 do
pal()
if(r<5 or r>6) poke4(0x5f0e,0x0100.0e0d)
if(jh%44<26) poke4(0x5f0e,0x0100.0a0a)
if(jh%44<22 or r<3 or r>8) poke4(0x5f0e,0x0100.0d0c)
nm,nn=gn[ng][r%2+1],r%2-2+ng*2
for d=0-(jh*kd[r-10+ng*10])%nm,127,nm do
sspr(0,64+nn*5,nm-3,5,d,r*6+29)
end
end
if ng<4 then clip() end
pal()
cs=kc[ng]
no=bj(ij[ng])
ix[2]={2+sin(jh*0.0075),3*sin(jh*0.0035+0.3),-7}
for np in all(ka) do
if np[1]==ng then
cx(no,(np[2]+np[3]*jh+np[4]*sin(jh*0.005))%np[5],np[6])
end
end
nq=ix[ng]
db(no,nq[1],nq[2],nq[3])
co(no)
dc()
clip()
dz(0x5f10,gm[ng])
end
function nr(ns,e)
d,nt,nu=0,"abdefghiklmnorstuvwy19","3333333133533333335323"
function nv()
return tonum(sub(nu,b,b)*3)
end
for r=1,#ns do
b,nw,nx=1,0,48
ek=sub(ns,r,r)
if ek==" "then d+=3 else
while sub(ns,r,r)!=sub(nt,b,b) and b<=#nt do
nw+=nv()
b+=1
if nw>98 then
nw,nx=0,63
end
end
sspr(nw,nx,nv(),15,d,e)
d+=nv()+3
end
end
end
function ny(nz,oa,ob,oc,od,oe,of,og)
function oh(ec,ed,oi)
for e=ec,ed do
color(oe[flr((128+e*oi-jh*oc)%128)+1])
oj=jh+rnd(30)
if mid(oj,of,og)==oj then line(0,e,127,e) end
end
end
dz(0x5f10,od)
oh(0,nz,ob)
oh(oa,127,-ob)
for r=-7,0 do
for x=1,r+8 do
d,bx=rnd(128)-8,rnd(128)-8
line(d,nz+r,d+16,nz+r,0)
line(bx,oa-r,bx+16,oa-r,0)
end
end
end
ok=m("0_0_0_0_0_-3_0_5_0|")
function ol(r,jh)
om=ok[jd]
if jh>=r*176-36 and jh<r*176+176 then
for ec in all(eg[r+1][mid(1,5,ceil((jh-r*176)/11))]) do
pal(7,ec[1]-om)
if jh>10 then poke(0x5f1f,2) end
camera(-1.18^(r*176-jh)+1.2^(jh-r*176-126))
if jh%176>44 and jh%176<=72 then
camera(5-rnd(10))
poke(0x5f1f,rnd(16))
end
hh=ec
sspr(hi(2,7))
end
end
camera()
end
function ni(on,jh)
oo,op=jh,jh
if jh>on*176+126 then op-=10 end
if jh<on*176 then oo+=10 end
for be=op,oo,0.5 do
ol(on,be,kf)
end
end
function oq()
fillp()
pal()
if jh>it then
for bd,bv in pairs(iv[iu]) do
nr(tostr(bv),63+15*bd)
end
it+=176
iu+=1
memcpy(4992,29568,2880)
cls()
end
poke4(0x5f1c,0x0f01.8180)
for iy in all(kg) do
iy[7],iy[8],iy[17],iy[18]="00818202",gg,"00018c0c0f",gh
hh=iy
if jh>iy[1] and jh<=iy[2] then ny(hi(3,10)) end
if jh>iy[11] and jh<iy[12] then ny(hi(13,20)) end
end
fillp()
for on=0,3 do
ni(on,jh)
end
function os(ot,ou,nm,ov)
palt(14,true)
ow=jh-ot
if ow>44 and ow<119 then
ox=0.0052*ow-0.1768
for e=0,14 do
if ow>104 and a(44) then camera(8-rnd(16),3-rnd(6)) end
if ow<=104 or a(40) then
for r=0,1 do
oy=8
if a(10) then oy=9 end
if ow<50 then oy=7 end
if r==0 then oy=1 end
pal(15,oy)
sspr(0,ou+e,nm,1,64-0.5*nm-ox*(e-7)+r,ov+e)
end
end
camera()
end
end
end
for oz in all(iw) do
hh=oz
os(hi(1,4))
end
dz(0x5f1c,"80858d")
end
function pa()
cls(15)
pb=0
for r in all(km) do
pb+=sin(jh*r[1])*(0.5+0.5*sin(jh*r[2]))
end
if jh<1300 then
no=bj(ki[jh%150+1])
cx(no,pb*0.1,"y")
db(no,3*pb,4.2+0.4*sin(jh*0.002),-17)
co(no)
dc()
memcpy(0,0x7000,0x0800)
end
memset(0x7100,255,320)
for r=1,5 do
if ik[r].iz<1 and jh<1309 then
cy=rnd(0.5)
ik[r]={
iz=64,
pc=10+rnd(20),
pd=20+rnd(30),
pe=3+rnd(10),
h=cos(cy),
g=sin(cy),
pf=40,
pg=5
}
if jh>704 and jh%44>22 and jh%44<33 then
ik[r].iz=128
ik[r].pc=5+rnd(5)
ik[r].pf=5
ik[r].pg=1
end
end
ph=ik[r]
if ph.iz>1 then
color(kl[flr(ph.iz)])
line(64+ph.pe*ph.h-3*pb,68+ph.pe*ph.g,64+ph.pd*ph.h-3*pb,68+ph.pd*ph.g)
end
ik[r].iz-=ph.pc
ik[r].pd+=ph.pf
ik[r].pe+=ph.pg
end
sspr(0,48,100,5,14,10-0.25*max(0,jh-1316))
if jh%176<154 then
if jh%176>132 then
memset(3392+rnd(640),255,32)
memcpy(3392+rnd(640),3392+rnd(640),32)
end
poke4(0x5f20,0x437f.0000)
sspr(64,53,60,10,34,67-(jh%176)*0.29)
sspr(0,53,39,5,45,77-(jh%176)*0.265)
clip()
end
palt(15,true)
if kn==false then
if jh>1298 then
for r=1,20 do memset(2048+rnd(1020),255,4) end
end
sspr(23,32,105,16,13-4*pb,52)
end
for pi in all(ko) do
for r=1,4 do
pal((r-jh)%4+pi[1],pi[r+1])
end
end
fillp()
palt(15,false)
for e=71+1.03^max(0,jh-1250),127 do
if e>75 or e%2==1 then
sspr(0,e-2,128,1,pb*204.8/(e-64),e)
else
line(0,e,127,e,15)
end
end
palt(15,true)
if jh<1320 then
pj=1.03^max(0,(jh-1150))-1
poke4(0x5f00,0x0302.0100)
poke4(0x5f04,0x0706.0504)
sspr(19,2,96,29,19,69-pj)
memset(0x5f00,15,8)
sspr(19,2,96,29,19-pj,102+pj*0.5,96+2.18*pj,13,false,true)
end
palt(0,true)
for r=0,15 do
pal(r,r)
end
if jh>iq*176 then
iq+=1
dy={3392,fs[iq]}
gp=cocreate(dx)
end
if jh>1342 and kn==false then
kn=true
dy={0,ia}
gp=cocreate(dx)
end
if jh>1372 then
poke4(0x5f12,0x0605.0807)
ni(0,jh-1408)
end
end
function pk()
if jh<979 then
for e=0,127 do
if(a(25)) dz(0x5f00,"1000010204040506")
palt(4,true)
sspr(0,e,128,1,0,e)
pal()
end
if pl then else pl,pm=0,m("0.8_0|1_140|") end
for r,bv in pairs(fy) do
camera(jh*pm[r][1]-pm[r][2],1-rnd(3))
for lj in all(bv) do
hh={}
for ky in all(lj) do
add(hh,ky)
if(a(3)) hh[#hh]+=4-rnd(8)
end
color(fz[mid(1,128,flr(rnd(200)))]+4*r-4)
line(hi(1,4))
end
end
jl()
camera()
dz(0x5f10,"0001028900818c0c")
else
for bd,bv in pairs(gf) do
if jh>bv and pl<bd then
repeat
pn=ceil(rnd(#ga))
until jj[pn]==false
jf,dy,pl,po,jj[pn]=150+rnd(150),{0x0400,ga[pn][1]},bd,64,true
gp=cocreate(dx)
end
end
if costatus(gp)=="dead"and pl>0 then
dz(0x5f10,ga[pn][2])
pp,jb=min(64,po*4),0x6000
while jb<0x7fff do
lj=min(ceil(rnd(200)),0x7fff-jb)
if(a(po/4)) memset(jb,rnd(256),lj)
jb+=lj
end
if(a(po*3)) sspr(0,16,128,112,64-pp,64-po,pp*2,(po*2)-2)
po-=1
if(po<59) po/=1.2
end
end
end
function jl()
memcpy(0,0x6000,8192)
end
function pq(bw,bz,bx,ca,by,cb)
bu({{bw,bz},{bx,ca},{by,cb}})
end
pr,ps,pt=m("3_9_7_13_9_19_9_1|"),m("1_4_3_6_4_10_4_1|"),{color,rectfill,circfill,pq,line,sspr,clip,jl}
function hi(pu,pv)
if pu<=pv then return hh[pu],hi(pu+1,pv) end
end
function ne(n)
r=1
while r<=#n do
pw,hh=sub(n,r,r)+0,{}
for px=r+1,r+15,2 do
add(hh,w(n,px,1))
end
for x=9,10 do
px,hh[x]=r+8+x,false
if sub(n,px,px)=="1"then hh[x]=true end
end
pt[pw](hi(1,ps[pw]))
r+=pr[pw]
end
end
function py()
poke4(0x5f10,0x0302.0700)
ne(hr)
hr=""
if jh>=44 then
ne(hy)
hy=""
end
memcpy(0x6000,0,8192)
if jh<44 then rectfill(0,32+ceil(jh/11)*16,127,127,0) end
if jh%11<6 and jh<55 then
poke4(0x5f10,0x0302.0007)
end
if jh>1000 then jh=1000 end
end
function _draw()
cu={{},{}}
cls()
pz={
kx,
kz,
mc,
mp,
my,
nf,
oq,
pa,
oq,
pk,
py
}
pz[jd]()
if fn<0 then
coresume(gp)
coresume(gq)
if jt then coresume(jt) end
end
for bd,bv in pairs(ge) do
if jd==bv[1] and jh>=bv[2] and je<bd then
je,jf,qa=bd,50+rnd(150),100
if jd==7 or jd==9 then qa=33 end
if a(qa) then
add(ga,{dv(0x6000+flr(rnd(32))*64,0x1800),dv(0x5f10,16)})
add(jj,false)
end
end
end
if jf>1 then
for r=1,jf do
if jd!=8 then pal(flr(rnd(16)),5+rnd(3),1) end
end
jf*=0.7
end
if stat(7)<60 then
fn=5
end
end