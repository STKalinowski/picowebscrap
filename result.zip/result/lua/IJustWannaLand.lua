--i just wanna land!
--by jusiv

--[[
this was originally made for the
2018 gmtk game jam, running for
48 hours from 8/31/2018 to
9/2/2018.

the jam theme is "genre without
mechanic", where you make a game
in a specific genre but missing
a defining mechanic or element
of it. 

version 2 was created for
pax east 2019.
it featured a more detailed
scoring system, clearer
instructions, and more music.

version 3 (this one) was 
released in june 2022.
it fixed a bug where the game
would always report at least 3
retries, refined most hitboxes,
and added a whole bunch of extra
polish details (particularly to
death animations).


all assets and code are my own
work.

if you'd like to follow future
things of mine, check out my
twitter: @jusiv_

(c) 2018-2022 henry "jusiv" stadolnik
]]
function init_all()
 --player
 p_x = 66
 p_y = 72
 p_xv = 0
 p_yv = -1
 p_dir = 0
 p_rdir = 0 -- actual value of angle
 p_rspd = 1 --0.015625 --rotation speed
 p_rf = 64 --rotation factor
 p_hit = false
 p_dead = false
 p_fwait = 10 --delay between flaps
 p_mwait = 0 --delay before moving in certain circumstances
 p_wnd = false --if blown
 p_shk = false --if shocked
 cam_x = 0

 --scoring
 score = 0
 highscore = dget(0)
 highget = false
 star = 0
 stars = {0,0,0,0}
 maxstars = 0
 retries = 0
 twait = 0 --counts steps (60 = second)
 timer = 0 --counts seconds
 sstep = 0 --final scoring step
 sswait = 0 --final scoring wait
 s_target = 0 --final scoring target
 sbonus = 0 --bonus points
 
 --physics
 grav = 0.03125
 res = 0.03125
 ares = res

 --visuals/transitions
 t_pause = 40 --prevents instant restart
 idle = 0
 sshake = 0
 i_start = false
 i_wait = 80 --intro wait
 e_wait = 0 --ending wait
 resetting = false
 r_wait = 0 --respawn wait
 l_wait = 0 --wait between levels
  
 restart = 0
 
 --progress
 intro = 0
 level = 0
 ending = 0

 --music
 mus_wait = 0 --delay before music starts

 --actors
 a_dot = {}
 a_rock = {}
 a_star = {}
 a_hazard = {}
 
 -->> other setup
 place_rock()
 load_level(0)
 music(0)
end
-->8
--actors
--★ dot
function add_dot(x,y,dx,dy)
 local a={}
 a.x = x
 a.y = y
 a.dx = dx
 a.dy = dy
 a.tmax = 20+flr(rnd(20))
 a.t = a.tmax
 add(a_dot,a)
end

function upd_dot(a)
 a.x += a.dx
 a.y += a.dy
 local aa = atan2(a.dx,a.dy)
 a.dx -= 0.1*cos(aa)
 a.dy -= 0.1*sin(aa)
 a.t -= 1
 if a.t <= 0 then
    del(a_dot,a)
 end
end

function draw_dot(a)
 if a.t > a.tmax/2 then
    color(7)
 elseif a.t < a.tmax/5 then
    color(15)
 else
    color(10)
 end
 circ(a.x,a.y,-1.5*sin(a.t/(2*a.tmax)))
 --print(a.dx,a.x+5,a.y)
 --print(a.dx,a.x+5,a.y+8)
end


--★ cloud
function make_cloud(x,y,s,r)
 local a={}
 a.x = x
 a.y = y
 a.s = s --speed
 a.i = flr(rnd(60)) --idle anim.
 a.r = r --radius 
 return a
end

function move_cloud(a)
 a.x -= a.s
 if a.x < -20 then a.x += 180 end
end

function upd_cloud(a)
 a.i = (a.i+0.5)%60
end

function draw_cloud(a)
 circfill(a.x,a.y,a.r+1.5*sin(a.i/60))
end


--★ rock
function add_rock(i)
 local a={}
 a.x = 56+i*2
 a.y = 72
 a.sx = 24+i*2 --spr x
 a.sh = 0 --shake (0=none, 1=shake, 2=fall)
 a.dx = i/8-0.5
 a.dy = -rnd(1.5)
 add(a_rock,a)
end

function shake_rock(a)
 a.sh += 1
 a.dy += rnd(0.5)
end

function upd_rock(a)
 if a.sh == 1 then
    a.y = mid(a.y-0.5+rnd(1),71,73)
 elseif a.sh > 1 then
    a.dy += 2*grav
    a.x += a.dx
    a.y += a.dy
    if a.y > 130 then
       del(a_rock,a)
    end
 end
end

function draw_rock(a)
 sspr(a.sx,6,2,9,a.x,a.y-2)
end

function place_rock()
 for i=0,7 do
    add_rock(i)
 end
end


--★ star
function add_star(x,y)
 local a={}
 a.x = x+4
 a.y = y+4
 a.i = 16-2*(flr(x/8)%8)
 add(a_star,a)
end

function upd_star(a)
 a.i = (a.i+1)%16
 if mid(a.x,p_x-12,p_x+4) == a.x and
    mid(a.y,p_y-12,p_y+4) == a.y then
    star += 1
    for j=0,4 do
       local aa = 0.25+j/5
       add_dot(a.x,a.y,2*cos(aa),2*sin(aa))
    end
    sfx(11)
    del(a_star,a)
 end
end

function draw_star(a)
 spr(32+flr(a.i/4),a.x-3,a.y-3)
end


--★ hazard template
function add_hazard(x,y)
 local a={}
 a.x = x
 a.y = y
 a.upd = function(a)
    if a.x < cam_x+160 and a.x > cam_x-40 then
       if mid(p_x,a.x-4,a.x+10) == p_x and
          mid(p_y,a.y-4,a.y+10) == p_y then
          player_hurt()
       end
    end
 end
 a.draw = function(a)
 end
 add(a_hazard,a)
end


--★ smol bloon
function add_bloon(x,y)
 local a={}
 a.x = x
 a.y = y
 a.sp = 44
 a.pw = 0
 a.upd = function(a)
    if a.x < cam_x+160 and a.x > cam_x-40 then
       if a.sp > 44 then
          a.pw += 1
          if a.pw > 5 then
             del(a_hazard,a)
          end
       elseif mid(p_x,a.x,a.x+12) == p_x and
              mid(p_y,a.y+1,a.y+13) == p_y then
          player_hurt()
          player_smack(a.x,a.y,0.5)
          a.sp = 45
          sfx(14)
       end
    end
 end
 a.draw = function(a)
    spr(a.sp,a.x,a.y)
    spr(60+flr((idle%40)/20),a.x,a.y+8)
 end
 add(a_hazard,a)
end


--★ bird
function add_bird(x,y)
 local a={}
 a.x = x
 a.yi = y
 a.y = y
 a.aa = 0
 a.h = false
 a.upd = function(a)
    if a.x < cam_x+160 and a.x > cam_x-40 then
       a.x -= 0.25
       a.y = a.yi+7.5*cos(idle/80)
       if a.aa > 0 then
          a.aa -= 1
       end
       if mid(p_x,a.x+1,a.x+11) == p_x and
          mid(p_y,a.y-1,a.y+11) == p_y then
          if not a.h then
             player_hurt()
             player_smack(a.x,a.y,0.75)
             a.h = true
          end
          if a.aa <= 0 then
          	  a.aa = 44
             sfx(36)
          end
       end
    end
 end
 a.draw = function(a)
    local sp = 97+flr((idle%20)/5)
    if a.aa > 0 then
     sp = 117+flr(a.aa/4)%2
    end
    spr(sp,a.x,a.y)
 end
 add(a_hazard,a)
end


--★ twister
function add_twister(x,y)
 local a={}
 a.x = x
 a.y = y
 a.dy = -1
 a.h = false
 a.upd = function(a)
    if a.x < cam_x+160 and a.x > cam_x-40 then
       a.y += a.dy
       if mid(a.y,1,120) != a.y then
          a.dy *= -1
       end
       if mid(p_x,a.x+1,a.x+11) == p_x and
          mid(p_y,a.y-1,a.y+11) == p_y then
          if not a.h then
           player_hurt()
           a.h = true
           local rn = 2*flr(rnd(2))-1
           p_xv /= 2
           p_xv += 1.5+rn*(2.5+rnd(2))
           p_yv += rnd(5)-2
           p_mwait = 16
           p_wnd = true
           ares = 0.0125
           sfx(37)
          end
       end
    end
 end
 a.draw = function(a)
    spr(36+flr((idle%20)/10),a.x,a.y)
 end
 add(a_hazard,a)
end


--★ sadcloud
function add_sadcloud(x,y)
 local a={}
 a.x = x
 a.y = y
 a.i = flr(rnd(4))
 a.h = false
 a.upd = function(a)
    if a.x < cam_x+160 and a.x > cam_x-40 then
       a.i = (a.i+0.5)%4
       if mid(p_x,a.x-2,a.x+23) == p_x then
          if not p_dead and p_mwait <= 0 and p_y > a.y then
             p_y += 1
          end
          if mid(p_y,a.y+2,a.y+16) == p_y then
             if not a.h then 
                player_hurt()
                a.h = true
                p_yv = 0
                p_mwait = 24
                p_shk = true
                sfx(38)
             end
          end
       end
    end
 end
 a.draw = function(a)
    --rain
    local rf = 1+(flr(a.i)+flr(cam_x)%4)%4
    fillp(flr(cam_x)%2 == 0 and rain1[rf] or rain2[rf])
    rectfill(a.x-1,a.y+1,a.x+17,128,13)
    fillp()
    --cloud
    local ofst = 0.8*cos((idle%40)/40)
    circfill(a.x,a.y+4,5+ofst,5)
    circfill(a.x+8,a.y+3,7-ofst)
    circfill(a.x+16,a.y+4,5-ofst)
    --face
    spr(113+2*flr((idle%40)/20),a.x,a.y,2,1)
 end
 add(a_hazard,a)
end


--★ hot air balloon
function add_hbloon(x,y,r)
 local a={}
 a.x = x
 a.y = y
 a.r = r
 a.c = 8+flr(rnd(5))
 a.hbl = false
 a.hba = false
 a.hr = 0
 a.upd = function(a)
    if a.x < cam_x+160 and a.x > cam_x-40 then
       if a.hr > 0 then
          a.hr -= 0.25
       end
       local rr = a.r+4
       if mid(p_x,a.x-4-rr,a.x+2+rr) == p_x and
          mid(p_y,a.y-3-rr,a.y+1+rr) == p_y then
          local dx = a.x-p_x+4
          local dy = a.y-p_y+3
          if not a.hbl and sqrt(dx*dx+dy*dy) < rr then
             player_hurt()
             player_smack(a.x,a.y,1.5)
             a.hbl = true
             a.hr += 3
             sfx(40)
          end
       end
       if mid(p_x,a.x-2,a.x+8) == p_x and
          mid(p_y,a.y+a.r+8,a.y+a.r+19) == p_y then
          if not a.hba then
             player_hurt()
             player_smack(a.x,a.y+a.r,0.5)
             a.hba = true
             sfx(41)
          end
       end
    end
 end
 a.draw = function(a)
    spr(101,a.x-4,a.y+8+a.r)
    line(a.x-4,a.y+7+a.r,a.x-3-a.r/2,a.y,4)
    line(a.x+3,a.y+7+a.r,a.x+2+a.r/2,a.y)
    circfill(a.x,a.y,a.r+a.hr,a.c)
 end
 add(a_hazard,a)
end
-->8
--main
function sign(n)
 if n < 0 then return -1
 else return 1
 end
end

function round(n)
 if n >= 0 then
    if n-flr(n) < 0.5 then
       return flr(n)
    else
       return ceil(n)
    end
 else
    if abs(n-ceil(n)) < 0.5 then
       return ceil(n)
    else
       return flr(n)
    end
 end
end


function load_level(l)
 local ly = l*16
 for xx=0,127 do
    for yy=0,15 do
       local tt = mget(xx,yy+ly)
       local xt = xx*8
       local yt = yy*8
       if tt == 32 then
          add_star(xt,yt)
       elseif tt == 36 then
          add_twister(xt,yt)
       elseif tt == 44 then
          add_bloon(xt,yt)
       elseif tt == 97 then
          add_bird(xt,yt)
       elseif tt == 102 then
          add_hbloon(xt,yt,8)
       elseif tt == 103 then
          add_hbloon(xt,yt,16)
       elseif tt == 104 then
          add_hbloon(xt,yt,32)
       elseif tt == 113 then
          add_sadcloud(xt,yt)
       end
    end
 end
 mus_wait = 30
end


function reset_score()
 highscore = 0
 dset(0,highscore)
end


function reset_level()
 cam_x = 0
 p_x = 32
 p_y = 64
 p_xv = 2
 p_yv = -1
 p_dir = 0
 p_rdir = 0
 a_dot = {}
 a_star = {}
 a_hazard = {}
 star = stars[1]+stars[2]+stars[3]+stars[4]
 load_level(level)
 r_wait = 0
 p_dead = false
 p_hit = false
 p_shk = false
 ares = res
 resetting= false
end


function next_level()
 stars[level+1] = star-stars[1]-stars[2]-stars[3]
 level += 1
 reset_level()
end


function player_hurt()
 if not p_hit then
    p_hit = true
    p_yv = max(0,p_yv)
    sshake = 30
    sfx(15)
 end
end

function player_smack(sx,sy,m)
 local sa = atan2(p_x-4-sx,p_y-5-sy)
 p_yv /= 2
 p_xv = 2*m*cos(sa)
 p_yv += m*sin(sa)
 p_mwait += ceil(2*m)
 ares = 0.0175
end

function update_player()
 if not p_hit then
    --aim
    local dd = 0
    if btn(0) then
       dd += p_rspd
    end
    if btn(1) then
       dd -= p_rspd
    end
    p_rdir = (p_rdir+dd+p_rf)%p_rf
    p_dir = p_rdir/p_rf
    --flap
    if p_fwait > 0 then
       p_fwait -= 1
    elseif btn(4) or btn(5) then
       p_xv += 2*cos(p_dir)
       p_yv = min(0,p_yv)+2*sin(p_dir)
       p_fwait = 20
       for i=0,3 do
          add_dot(p_x-5+rnd(4),p_y-6+rnd(4),-p_xv/2,-p_yv/2)
       end
       sfx(8+flr(rnd(3)))
    end
 end
 --physics
 if p_mwait > 0 then
    p_mwait -= 1
    if p_mwait <= 0 then
       p_wnd = false
    end
 else
    --gravity and resistance
    p_yv += grav
    local xv = ares*sign(p_xv)
    if abs(p_xv) < abs(xv) and
       sign(p_xv) != sign(xv) then
       p_xv = 0
    else p_xv -= xv
    end
    --cap velocity
    local vel = sqrt(p_xv*p_xv+p_yv*p_yv)
    if vel > 1.5 and not p_dead then
       local vr = 1.5/vel
       p_xv *= vr
       p_yv *= vr
    end
    --move
    p_x = mid(p_x+p_xv,cam_x,1029)
    p_y += p_yv
    if p_y < 8 then
       p_y = 8
       p_yv = max(p_yv,0)
    end
 end
 --scroll camera
 if p_x > 68 then
    for j=0,1 do
       if p_x-cam_x > 48 then
          cam_x = min(cam_x+1,895)
          if cam_x < 895 then
             for i=0,2 do
                foreach(a_clouds1,move_cloud)
                foreach(a_clouds2,move_cloud)
             end
          end
       end
    end
 end
 
 --die
 if p_y > 136 then
    p_dead = true
    sfx(16)
    sshake = 20
    for i=0,9 do
       add_dot(p_x-5+rnd(4),p_y-6+rnd(4),-1+rnd(2),-3+rnd(1))
    end
 end
end


function _init()
 cartdata("jusiv_ijwl_v3")
 init_all()
 
 --restart
 restarting = false
 
 --patterns
 rain1 = {0b0111011111011101.1,0b1101011101111101.1,0b1101110101110111.1,0b0111110111010111.1}
 rain2 = {0b1110101110111110.1,0b1110111010111011.1,0b1011111011101011.1,0b1011101111101110.1}
 
 --clouds
 c_wait = 0 --duration of cloud wave
 c_cmain = 0 --pal id of front cloud layer
 c_cback = 0 --pal id of back cloud layer
 
 a_clouds1 = {}
 a_clouds2 = {}
 a_cwave1 = {} --cloud wave for resetting
 a_cwave2 = {} --cloud wave for resetting
 
 -->> make background clouds
 for i=0,12 do
    local c = make_cloud(14*i+rnd(2),0,0.25,10+rnd(4))
    add(a_clouds1,c)
    c = make_cloud(14*i+rnd(2),128,0.25,10+rnd(4))
    add(a_clouds1,c)
 end
 for i=0,17 do
    local c = make_cloud(10*i+rnd(4)+4,8,0.125,8+rnd(2))
    add(a_clouds2,c)
    c = make_cloud(10*i+rnd(4)+4,120,0.125,8+rnd(2))
    add(a_clouds2,c)
 end
 -->> make cloud wave
 for yy=0,12 do
    for xx=0,flr(4+2.5*(sin(yy/26))) do
       local c = make_cloud(140-10*xx+rnd(4),yy*10-2+rnd(4),0,8-xx+rnd(6))
       add(a_cwave1,c)
       c = make_cloud(200+10*xx-rnd(4),yy*10-2+rnd(4),0,8-xx+rnd(6))
       add(a_cwave1,c)
       c = make_cloud(268+10*xx-rnd(4),yy*10-2+rnd(4),0,8-xx+rnd(6))
       add(a_cwave2,c)
    end
 end
 
 menuitem(1,"reset score",reset_score)
 
 --[[ debug - count stars
 -- (total: 180)
 highscore = 0
 for xx=0,200 do
    for yy=0,200 do
       if mget(xx,yy) == 32 then
          highscore += 1
       end
    end
 end
 ]]
end


function change_song()
 --change music
 if intro == 0 then return end
 
 local mus = -1
 local musmax = -1
 local musplay = stat(24) --current song
 if level == 0 then
    mus = 10
    musmax = 13
 elseif level == 1 then
    mus = 14
    musmax = 19
 elseif level == 2 then
    mus = 6
    musmax = 9
 elseif level == 3 then
    mus = 21
    musmax = 26
 end
 if musplay != mid(mus,musmax,musplay) then
    --if correct music not playing,
    --then play it
    music(mus,1000)
 end
end


function _update60()
 -->> timers
 if intro == 0 then
    if t_pause > 0 then t_pause -= 1
    elseif restarting then restarting = false end
 end
 
 idle = (idle+1)%80
 if sshake > 0 then sshake -= 1 end
 -- music
 if mus_wait > 0 then
    mus_wait -= 1
    if mus_wait <= 0 then
       change_song()
    end
 end
 
 -- intro
 if i_start and i_wait > 0 then
    i_wait -= 1
    --start game
    if i_wait <= 0 then
       intro = 2
       foreach(a_rock,shake_rock)
    end
 end
 --ending
 if ending == 1 then
    --bird flies onto island
    local xoff = 957-p_x
    local yoff = 104-p_y
    if sqrt(xoff*xoff+yoff*yoff) < 1 then
       p_x = 957
       p_y = 104
       ending = 2
       sfx(13)
    else   
       local aa = atan2(xoff,yoff)
       p_x += cos(aa)/2
       p_y += sin(aa)/2
    end
 elseif ending > 1 then
    --1. slide in
    if e_wait < 40 then
       e_wait += 1
    --2. show results
    elseif sstep < 5 then
       --update score
       if score != s_target then
          local diff = s_target-score
          score += sign(diff)*mid(1,10,flr(abs(diff/20)))
          if diff > 0 then
             sfx(0,0)
          else
             sfx(1,0)
          end
          --correct overcorrection
          if (diff > 0 and score > s_target) or
             (diff < 0 and score < s_target) then
             score = s_target
          end
       elseif sbonus > 0 then
          --score bonus points
          sbonus -= 2
          score += 2
          s_target += 2
          sfx(35,0)
       else
          --if score is updated,
          --wait before next step
          if sswait > 0 then
             sswait -= 1
          else 
             if sstep == 0 then
             		 -- +5 points per star
             		 -- (+100 points if all collected) 
                s_target += 5*star
                if star >= 180 then
                   sbonus = 100
                end
             elseif sstep == 1 then
                -- +600 points - 1 per second
                -- (+100 points if under 4 minutes)
                s_target += max(0,600-timer)
                if timer <= 240 then
                   sbonus = 100
                end
             elseif sstep == 2 then
                -- -20 points per retry
                s_target = max(0,s_target-20*retries)
                if retries <= 0 then
                 sfx(11,0)
                end
             elseif sstep == 3 then
                --check for highscore
                if score > highscore then
                   highscore = score
                   dset(0,highscore)
                   highget = true
                end
                sfx(4)
             elseif sstep == 4 then
                --show result bird
                sshake = 20
             end
             sstep += 1
             sswait = 40
          end
       end
    elseif not restarting then
       --reset game
       if btnp(4) or btnp(5) then
          c_cback = 4
          c_wait = 40
          restarting = true
       end
    end
 end
 -- cloud transition
 if c_wait > 0 then
    --sfx
    if c_wait == 40 then
     sfx(39)
    end
    c_wait -= 1
    --restart game mid-transition
    if restarting and c_wait == 20 then
       init_all()
    end
    --reset cloud colors
    if c_wait <= 0 then
       c_cmain = c_cback%4
    end
 end
 -->> player
 if intro > 1 and ending <= 0 then
    --if dead, reset
    if p_dead then
       if resetting then
          r_wait += 1
       elseif btn(4) or btn(5) then
          resetting = true
       end
       if r_wait == 10 then
          c_wait = 40
       elseif r_wait >= 20 then
          reset_level()
          --mark retry
          retries += 1
       end
    --if level not cleared, play
    elseif l_wait <= 0 then
       --update timer
       twait += 1
       if twait >= 60 then
          twait = 0
          timer += 1
       end
       --update
       update_player()
       --detect if level clear
       if level >= 3 then
          if p_x > 952 then
             ending = 1
             sswait = 60
             music(-1,500)
          end
       elseif p_x >= 1029 then
          l_wait = 20
          c_cback += 1
          music(-1)
          sfx(12)
       end
    --otherwise, load new level
    else
       l_wait -= 1
       if l_wait == 10 then
          c_wait = 40
       elseif l_wait <= 0 then
          next_level()
       end
    end
 end
 -->> updates
 foreach(a_clouds1,upd_cloud)
 foreach(a_clouds2,upd_cloud)
 foreach(a_clouds1,move_cloud)
 foreach(a_clouds2,move_cloud)
 foreach(a_rock,upd_rock)
 foreach(a_dot,upd_dot)
 foreach(a_star,upd_star)
 foreach(a_hazard,function(a) a:upd() end)
 if intro == 0 and t_pause <= 0 then
    if btnp(4) or btnp(5) then
       intro = 1
       foreach(a_rock,shake_rock)
       i_start = true
       sfx(19)
       music(-1)
       --start level 1 music
       mus_wait = 180
    end
 end
 -->> debug
 --if btnp(2) then next_level() end
 --if btnp(3) then level = (level+3)%4 end
end
-->8
--drawing
function cprint(st,y,c)
 print(st,64-2*#st,y,c)
end

function setpal(p)
 pal()
 if p == 1 then
 	  pal(7,15)
 	  pal(15,14)
 	  pal(12,13)
 elseif p == 2 then
 	  pal(7,13)
 	  pal(15,5)
 	  pal(12,1)
 elseif p == 3 then
 	  pal(7,14)
 	  pal(15,13)
 	  pal(12,2)
 end
end


function draw_title()
 local yy = i_wait-57+1.5*sin(idle/80)
 spr(64,40,yy,6,2)
 spr(70,44,yy+12,5,2)
 spr(75,41,yy+24,5,2)
 spr(96,81,yy+24,1,2)
 local cc = 10
 if idle < 50 or idle >= 60 then
    cc = 7
 end
 cprint("⬅️➡️: aim  ",160-i_wait,cc)
 if idle < 60 or idle >= 70 then
    cc = 7
 else
    cc = 10
 end
 cprint("z: flap",166-i_wait,cc)
 cprint("best score: "..highscore,173-i_wait,3)
 if idle < 70 then
    cc = 10
 else
    cc = 7
 end
 cprint("(flap to start!)",183-i_wait+0.7*cos(idle/80),cc)
 cprint("made by @jusiv_",202-i_wait,5)
end


function _draw()
 -->> set camera
 local ss = -sshake/6+rnd(sshake/3)
 camera(0,ss)
 -->> set palette
 setpal(level)

 -->>background
 --draw sky
 rectfill(-4,-4,132,132,12)
 color(15)
 foreach(a_clouds2,draw_cloud)
 color(7)
 foreach(a_clouds1,draw_cloud)
 
 -->> main
 camera(cam_x,ss)
 --draw rock
 foreach(a_rock,draw_rock)
 --draw goal
 if level >= 3 then
    spr(22,944,96,4,3)
 else
    if idle%40 >= 20 then
       pal(3,11)
       pal(11,3)
    end
    spr(26,1000+2.5*sin(idle/80),56,2,2)
 end
 pal()
 --draw particles
 foreach(a_dot,draw_dot)
 --draw objects
 foreach(a_star,draw_star)
 --draw player
 local ofst = flr((idle%40)/20)
 local mm = (mid(p_dir%1,0.25,0.75) == p_dir%1)
 local dspr = 5
 if p_mwait > 0 then
    if idle%4 < 2 then
       if p_shk then
          dspr = 119
       end
       if p_wnd then
          mm = not mm
       end
    end
 elseif p_shk then
    dspr = 120
 end
 if intro == 0 then
    spr(6+ofst,60,64)
 elseif ending > 1 then
    spr(6+ofst,p_x-6,p_y-8)
 elseif intro == 1 then
    spr(8+ofst,60,63-2*ofst)
 elseif p_hit then
    spr(dspr,p_x-6,p_y-8,1,1,mm,false)
 else
    --aim
    if ending <= 0 and not p_dead then
       local aoff = 24 --arrow head angle
       local aang1 = (p_rdir+aoff)/p_rf
       local aang2 = (p_rdir-aoff)/p_rf
       local arr = 3.5 --arrow head length
       local p1x = (p_x-3+9*cos(p_dir))
       local p1y = (p_y-4+9*sin(p_dir))
       local p2x = round(p_x-3+16*cos(p_dir))
       local p2y = round(p_y-4+16*sin(p_dir))
       local p3x = round(p2x+arr*cos(aang1))
       local p3y = round(p2y+arr*sin(aang1))
       local p4x = round(p2x+arr*cos(aang2))
       local p4y = round(p2y+arr*sin(aang2))
       line(p1x,p1y,p2x,p2y,6)
       line(p2x,p2y,p3x,p3y)
       line(p2x,p2y,p4x,p4y)
       --line(p3x,p3y,p4x,p4y)
       --circ(p2x,p2y,2)
    end
    --body
    spr(10+flr((idle%20)/10),p_x-6,p_y-8,1,1,mm,false)
    --wing
    local sp = 12
    if ending == 1 then
       sp = 12+flr((idle%20)/5)
    elseif p_fwait >= 15 then
       sp = 13
    elseif p_fwait >= 10 then
       sp = 14
    elseif p_fwait >= 5 then
       sp = 15
    end
    spr(sp,p_x-6,p_y-8,1,1,mm,false)
 end
 foreach(a_hazard,function(a) a:draw() end)
 
 -->> ui
 camera()
 if intro < 2 then
    draw_title()
 elseif ending > 1 then
    local tyy = e_wait-40
    local scolor = 6
    if sstep >= 4 then scolor = 7 end
    cprint("you got to land!",1+tyy,7)
    if sstep >= 1 then
       --stars and score
       local stcolor = 7
       if star >= 180 then
          stcolor = 10
       end
       cprint("stars: "..star.."/180",10+tyy,stcolor)
       cprint("score: "..score,35+tyy,scolor)
    end
    if sstep >= 2 then
       --time
       local tcolor = 7
       if timer < 240 then
          tcolor = 10
       end
       cprint("time: "..timer,16+tyy,tcolor)
    end
    if sstep >= 3 then
       --retries
       cprint("retries: "..retries,22+tyy,9)
    end
    if sstep >= 4 then
	      --highscore
       local bcolor = 6
       local bstr = "best: "..highscore
       if highget then
          bcolor = 10
          bstr = "new record!"
       end
       cprint(bstr,41+tyy,bcolor)
    end
    if sstep >= 5 then
       local ioff = min(3,flr(abs(4*sin(idle/80))))
       rectfill(-4,62-ioff,132,81+ioff,10)
       rect(38,31+tyy,88,49+tyy)
       rectfill(-4,62-flr(ioff/2),132,81+flr(ioff/2),7)
       rectfill(-4,63,132,80,1)
       spr(105,48,64,4,2)
       local ecolor = 13
       if restart > 20 then
          ecolor = 7
       elseif restart > 10 then
          ecolor = 6
       end
       cprint("(press z to play again)",122-tyy,ecolor)
    end
 else
    print("★"..star,2,2,0)
    local tstr = timer.."⧗ "
    print(tstr,127-4*#tstr,2)
    if p_dead then
       cprint("(press z)",61,7)
    end
 end
 -->> cloud wave
 if c_wait > 0 then
    local cx = 400-(400*c_wait/40)
    --back layer
    camera(cx-20,0)
    if p_dead then
       setpal(c_cmain)
    else
       setpal(c_cback)
    end
    rectfill(180,0,268,127,7)
    foreach(a_cwave2,draw_cloud)
    --front layer
    camera(cx,0)
    setpal(c_cmain)
    rectfill(140,0,200,127,7)
    foreach(a_cwave1,draw_cloud)
 end
 
 --debug
 --print(stat(1),2,120,0)
 --print(cam_x,2,2,0)
 --print(mus_wait,2,2,0)
 --[[ round(n) test cases
 print(".3 -> "..round(0.3),2,2,0)
 print("-.3 -> "..round(-0.3),2,12,0)
 print(".6 -> "..round(0.6),2,22,0)
 print("-.6 -> "..round(-0.6),2,32,0)
 print(".5 -> "..round(0.5),2,42,0)
 print("-.5 -> "..round(-0.5),2,52,0)
 ]]
end