-- rise and shine prof. miggles
-- by zep
-- v1.1: fixed hiscore

function _init()
 mode = 0 -- title
 init_title()
 t = 0
 
 cartdata("miggles")
 hiscore = dget(0)
end

mistake_str=
{
 "no coffee brain died",
 "no shoes!",
 "no trousers",  
 "people can see your nipples",
 "can't see",
 "you forgot your briefcase!",
 "late for work",
}


pl={}
pu={}

days =
{
 "monday",
 "tuesday",
 "wednesday",
 "thursday",
 "friday",
 "saturday"
}

function init_title()
 music(0)
end

function init_game()
 day = 1
 pl.score = 0
 results={}
 music(-1)
 init_day()
 
end

function init_day()

 reload() -- reload map
 
 
 pl.x = 20
 pl.y = 76
 pl.dx = 0
 pl.dy = 0
 pl.frame=0
 pl.coffee=0
 pl.exit_t = 0
 pl.score0 = pl.score
 
 pu={}
 door_open=false
 in_bed = true
 mistake= 0
 t = 30*8
 
 for i=68,73 do

  found=false
  while not found do
   x = rnd(14)+1
   y = rnd(11)
   if (mget(x,y)==20) then
    found=true
    mset(x,y,i)
   end
  end

 end

 sfx(10) -- alarm clock
 
end


function determine_result()
 
 ok = true
 for y=0,15 do
 for x=0,15 do
  val = mget(x,y)
  if (fget(val,0)) then
   ok=false
   
   do_mistake(val)
    
  end
 end
 end
 
 add(results,ok)
 
 if (ok) sfx(13) --sfx(12)
 
end

function is_solid(x, y)

 if (x < 4) return true
 if (x > 125) return true
 if (y < 24) then
  if (x > 86 and x < 100) then
   door_open = true
   pl.exit_t = 0
   determine_result()
  end
  return true
 end
 if (y > 89) return true
 
 return false

end

function pickup(x, y)
 x /= 8
 y /= 8
 val = mget(x,y)
 if fget(val,0) then
 
  sfx(val-68)

  if (val==69) pu.shoes = true
  if (val==70) pu.trousers = true
  if (val==71) pu.shirt = true
  if (val==72) pu.glasses = true
  if (val==73) pu.briefcase = true
  if (val==68) then
   pl.coffee = 1
--   pl.dx *= 3
--   pl.dy *= 3
  end

  mset(x,y,20)
  
 end
end

function do_mistake(val)
 mistake = val
 pl.score = pl.score0
 sfx(15)

end

function _update()

 if (mode != 1) then

  if (btnp(4) or btnp(5)) then
   init_game()
   mode=1
  end
  t += 1
  return

 end
 
 if not door_open and 
  mistake == 0 then
 
 if (not is_solid(pl.x+pl.dx,pl.y))
 then pl.x += pl.dx
 else pl.dx *= -1 sfx(14) end
 
 if (not is_solid(pl.x,pl.y+pl.dy))
 then pl.y += pl.dy
 else pl.dy *= -1 sfx(14) end
 
 end
 
 if in_bed then
  if (band(btn(),0xf)!=0) then
   in_bed = false
   sfx(11)
  end
 end
 
 if in_bed then
  pl.score += 1
 end
 
 if not in_bed then
 
 accel = 0.35--+ 0.3*pl.coffee
 if (btn(0)) pl.dx -= accel
 if (btn(1)) pl.dx += accel
 if (btn(2)) pl.dy -= accel
 if (btn(3)) pl.dy += accel
 
 pl.frame += abs(pl.dx)*0.2
 pl.frame += abs(pl.dy)*0.2
 pl.frame %= 2
 
 pl.dx *= 0.9
 pl.dy *= 0.9
 
 -- collect stuff
 
 pickup(pl.x-4,pl.y-4)
 pickup(pl.x+4,pl.y-4)
 pickup(pl.x-4,pl.y+4)
 pickup(pl.x+4,pl.y+4)
 
 end
 
 if (door_open) then
  pl.x = 92 + pl.exit_t*0.1
  pl.y = 24 - pl.exit_t*0.1
  pl.exit_t += 1
  if (pl.exit_t > 30) then
   pl.x = -100
  end
 end
 
 if (pl.exit_t == 0) then
  t -= 1
  if (t == 0) then
   do_mistake(74)
   add(results,false)
  end
 end
 
 -- late for work
 if (mistake == 74) then
  pl.exit_t += 1
 end
 
end

function draw_player()
-- briefcase goes behind
 if (not door_open) then
  if (pu.briefcase) then
   pal(12,0)
   spr(89, pl.x,
    pl.y+flr(pl.frame))
  end
 end
 

 -- adjust palette according
 -- to posessions
  
 if (pu.trousers) then
  pal(7,4) else pal(4,14) end
 if (pu.shoes) then
  pal(2,9) else pal(2,14) end
 if (pu.glasses) then
  pal(6,7) else pal(6,14) end
 if (not pu.shirt) then
  pal(3,14)
  pal(11,14)
 end
 
 w=4 h=8
 
 if (door_open) then
  w /= (1+pl.exit_t*0.05)
  h /= (1+pl.exit_t*0.05)
 end
 
-- spr(98+pl.frame,
--  pl.x-w, pl.y-h, 1,2)

 sspr(16+flr(pl.frame)*8,48,8,16,
  pl.x-w, pl.y-h, w*2,h*2)
 
 pal()
 
 if (pl.exit_t > 30) then
  if(btnp(4) or btnp(5)) then
   day += 1
   if (day == 6) then
    mode = 2
    hiscore = max(pl.score, hiscore)
    
    dset(0,hiscore)
    
    if (pl.score == hiscore) then
     sfx(16)
    else
     sfx(8)
    end
   else
    init_day()
   end
  end
 end
 
end

function draw_game()

 camera(0,-16)
 map(0,0,0,0,16,16)

 if (door_open) then
  spr(93, 80, 8, 3, 3)
 end
 
 if (in_bed) then
  spr(7,0,8*8,3,4)
 else
  draw_player()
 end
 
 camera()

 --

 print(days[day],4,5)
 
 -- results
 
 for i=1,5 do
  x=38+i*8
  spr(13,x,4)
  if (results[i] != nil) then
   if results[i] then
    spr(14,x,4)
   else
    spr(15,x,4)
   end
  end
 end

 if (mistake > 0) then
  rectfill(2,60,125,71,8+mistake-68)
  s=mistake_str[mistake-68+1]
  print(s,64-(#s*2),64,0)
 end
 
 if (door_open and pl.exit_t>60)
 then
  print("press button",40,118,7)
 else
 
  -- show time left
  
  for i=1,t/12 do
   spr(2,12+i*4,118)
 
  end
 end
 
 s=""..pl.score
 if (pl.score > 0) then
 for i=1,5-#s do
  s="0"..s
 end
 end
 print(s,124-(#s*4),5,7)
 
 
end

function printc(s,x,y,col)
 print(s,x-#s*2,y,col)
end

function draw_title()
 pal()
 printc("rise and shine",
  64,24,7)
 printc("professor miggles",
 64,32,7)
 printc("by zep for ggj16", 
 	64,84,5)
 
 printc("snooze for points",
  64,110,13)
 
 pal(5,0)
 pal(1,0)
 spr(7,64-12,44,3,4)
 
end

function draw_game_over()

 rectfill(0,0,127,127,1)

 pl.x = 64
 pl.y = 64
 door_open = false
 pl.exit_t = 0
 pl.frame = (t*0.2)%2
 
 draw_player()
 
 printc("high score "..hiscore,
  64,4,5)
  
 printc("score "..pl.score,
  64,32,7)
  
 printc("press button to play again",64,100,13)
end

function _draw()
 pal()
 cls()
 if (mode==0) draw_title()
 if (mode==1) draw_game()
 if (mode==2) draw_game_over()
end
