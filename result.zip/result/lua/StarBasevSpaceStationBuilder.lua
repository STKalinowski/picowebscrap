--starbase
--by pixelcod

-- todo:
-- -----

-- shop:
--  -add diff lasers
--  -add diff boosters

-- tutorial:
--  -building section

-- music:
--  -get good
--  -make track

function blink(spd)
 if(b==nil) b=0
 b+=spd
 b%=20
 if(b>10)return true
end

function check_tile(x,y,flag)
 x=flr(x/8)
 y=flr(y/8)
 return fget(mget(x,y),flag)
end

function get_auto_tile(x,y)
	--bitmasking for tiles
	local mask = 0
		
	if mget(x,y-1) > 0 then
		-- north has tile
		mask = mask + 1
	end
	
	if mget(x+1,y) > 0 then
		-- east has tile
		mask = mask + 2
	end
	
	if mget(x,y+1) > 0 then
		-- south has tile
		mask = mask + 4
	end
	
	if mget(x-1,y) > 0 then
		-- west has tile
		mask = mask + 8
	end
	
	return 64 + mask
end

function lerp(startv,endv,per)
 return(startv+per*(endv-startv))
end

function dist(x1,y1,x2,y2)
 return sqrt((x1-x2)^2+(y2-y1)^2)
end

function outline(o)
 for i=0,15 do pal(i,0) end
 spr(o.s,o.x-1,o.y,1,1,o.flipx,o.flipy)
 spr(o.s,o.x+1,o.y,1,1,o.flipx,o.flipy)
 spr(o.s,o.x,o.y-1,1,1,o.flipx,o.flipy)
 spr(o.s,o.x,o.y+1,1,1,o.flipx,o.flipy)
 pal()
end

function dir_pressed()
 return btn(0)or btn(1)or btn(2)or btn(3)
end

--screen shake
function init_shake()
 shake=0
 shakex=0
 shakey=0
end

function do_shake()
 shakex=8-rnd(16)
 shakey=8-rnd(16)
 
 shakex*=shake
 shakey*=shake
 
 camera(camx+shakex,camy+shakey)
 
 shake*=0.8
 if(shake<=0.05)shake=0
end

function create_part(x,y,dx,dy,sprite,life,sz,col)
 local p={
 x=x,
 y=y,
 dx=dx,
 dy=dy,
 sprite=sprite,
 life=life,
 sz=sz,
 col=col
 }
 add(particles,p)
 return p
end

function update_part(p)
 if(p.life<=0)del(particles,p)
 
 if p.sz !=nil then
  p.sz-=0.2
 end
 
 --p.dx*=p.fric
 --p.dy*=p.fric
 p.x+=p.dx
 p.y+=p.dy
 
 p.life-=1
end

function draw_part(p)
 if p.sprite != 0 then
  spr(p.sprite,p.x,p.y)
 else
  circfill(p.x,p.y,p.sz,p.col)
 end
end

--particle presets
function smoke(x,y)
 create_part(x,y,rnd(1)-0.5,rnd(0.5)-1,0,rnd(30)+10,rnd(4)+2,5)
end

function explosion(x,y,sz)
 for i=1,sz*4 do
  create_part(x,y,(rnd(16)-8)*sz/16,(rnd(16)-8)*sz/16,0,rnd(30)+10,rnd(sz)+3,palettes.ex[flr(rnd(#palettes.ex)+1)])
 end
 shake=sz/3
end

function smoke_screen(x,y,amt)
 for i=1,amt do
  create_part(x+rnd(128),y+rnd(128),
              rnd(2)-1,rnd(2)-1,0,
              rnd(60)+30,rnd(10)+10,1)
 end
end

function create_actor(x,y,dx,dy,acc,drag,s)
 return {
  x=x,
  y=y,
  dx=dx,
  dy=dy,
  acc=acc,
  drag=drag,
  s=s,
  timer=0
 }
end

function update_actor(a)
 a.dx*=a.drag
 a.dy*=a.drag
   
 a.x+=a.dx
 a.y+=a.dy
 
 a.timer+=1
end

function update_build()
 --position block
 p.x=flr((p.x+4)/8)*8
 p.y=flr((p.y+4)/8)*8
 
 if p.timer>=10 then
  if(btn(0))p.x-=8
  if(btn(1))p.x+=8
  if(btn(2))p.y-=8
  if(btn(3))p.y+=8
  if(dir_pressed())p.timer=0
 end
 
 --change block
 if(btnp(5))p.block+=1
 if(p.block>#blocks)p.block=1
 
 --can or cannot build?
 if check_tile(p.x+4,p.y+4,0)or
    check_tile(p.x+4,p.y+4,2)or
    check_tile(p.x+4,p.y+4,3)or
    --not enough gold
    gold<blocks[p.block][4] then
  can_build=false
 else
  can_build=true
 end
 
 --build
 if btnp(4) then
  if p.block==1 then
   if check_tile(p.x+4,p.y+4,0) then
    if p.x!=ship.tx or
       p.y!=ship.ty then
     --destroy block
     mset(p.x/8,p.y/8,0)
     explosion(p.x+4,p.y+4,4)
     --get 1 gold back
     gold+=1
     sfx(5)
    end
   end
  elseif can_build then
   --place block at position
   mset(p.x/8,p.y/8,blocks[p.block][1])
   --remove gold from inv
   gold-=blocks[p.block][4]
   sfx(1)
  end
 end
 
 --auto tile blocks
 auto_tile(p.x,p.y,16)
 
 --exit build mode
 if p.x==ship.tx and
    p.y==ship.ty then
  exit_build=true
  if btn(4)and ship.timer>30 then
   ship_launch()
  end
 else
  exit_build=false
 end
end

function auto_tile(_x,_y,rng)
 --auto tile blocks
 for y=(_y/8)-rng,(_y/8)+rng do
  for x=(_x/8)-rng,(_x/8)+rng do
   if check_tile(x*8,y*8,4) then
    mset(x,y,get_auto_tile(x,y))
   end
  end
 end
end

function init_shop()
 p.state="shop"
 shop={
 colours={{8,14},{3,11},{12,6},{9,15},{2,13}}, --red,dgrn,blue,yellow,maroon
 col_desc={"red","dark green","blue","yellow","maroon"},
 
 change=false, --< used to tell
               --  if change
 sel=1,        --  was made to
 selx=0,       --  ship
 sely=0,
 
 x=camx+8,
 y=camy+14
 } 
end

function update_shop()
 local s=shop
 
 s.x,s.y=camx+8,camy+14
 
 if btnp(5) then
  p.state="pilot"
  ship_launch()
  if(shop.change)ship.blink=true
 end
 if(btnp(0))s.selx-=1 s.sel-=1 sfx(3)
 if(btnp(1))s.selx+=1 s.sel+=1 sfx(3)
 if(btnp(2))s.sely-=1 s.sel-=5 sfx(3)
 if(btnp(3))s.sely+=1 s.sel+=5 sfx(3)
 
 --buy from shop
 if btnp(4) then
  sfx(7)
  if s.sel<=5 then
   ship.col[1]=s.colours[s.sel][1]
   ship.col[2]=s.colours[s.sel][2]
   ship.timer=0
   shop.change=true
  end
 end
 
 --restrain cursor to window
 --and set s.sel to correct val
 if(s.selx<0)s.selx=4 s.sel+=5
 if(s.selx>4)s.selx=0 s.sel-=5
 if(s.sely<0)s.sely=4 s.sel+=25
 if(s.sely>4)s.sely=0 s.sel-=25
 
end

function draw_desc(x,y)
 if shop.sel<=5 then
  print("paint your\nship hull",x+56,y+56,7)
  print(shop.col_desc[shop.sel],x+56,y+68,shop.colours[shop.sel][1])
  --ship colour preview
  pal(8,shop.colours[shop.sel][1])
  pal(14,shop.colours[shop.sel][2])
  sspr(16,0,8,8,x+67,y+12,32,32)
  pal()
 end
end

function draw_shop()
 local x,y=camx+8, camy+14
 
 --window setup
 --shop window
 rectfill(x,y,x+112,y+96,0)
 rect(x+1,y+1,x+111,y+95,1)
 --splitter lines
 line(x+54,y+1,x+54,y+95,1)
 line(x+54,y+54,x+111,y+54,1)
 
 --item descriptions
 draw_desc(x,y)
 
 --shop content
 --ship colours
 rectfill(x+3,y+3,x+52,y+9,1)
 print("ship colours",x+4,y+4,0)
 for i=1,#shop.colours do
  --rectfill(x+3+((i-1)*10),y+11,x+3+((i-1)*10)+8,y+19,shop.colours[i])
  pal(8,shop.colours[i][1])
  pal(14,shop.colours[i][2])
  spr(23,x+4+((i-1)*10),y+12)
  pal()
 end
 
 --selecting cursor
 rect(x+(shop.selx*10)+3,y+(shop.sely*18)+11,x+(shop.selx*10)+12,y+(shop.sely*18)+20,7)
 
 --[[print("selx"..shop.selx,x+32,y+64,8)
 print("sely"..shop.sely,x+32,y+72,8)
 print("sel"..shop.sel,x+32,y+80,8)]]--
end

function move(p)
 if(btn(0))p.dx-=p.acc
 if(btn(1))p.dx+=p.acc
 if(btn(2))p.dy-=p.acc
 if(btn(3))p.dy+=p.acc
end

function update_p(p)
 if p.state=="move" then
  move(p)
  
  --footprint particles
  if check_tile(p.x+4,p.y+4,1) and (abs(p.dx)>0.1 or abs(p.dy)>1) then
   if(p.timer%10==0)create_part(p.x,p.y,0,0,22,60) sfx(9)
  end
  
  p.range=dist(p.x+4,p.y+4,ship.x+4,ship.y+4)
  --if close enough, pilot
  if p.range<=10 and
  btnp(4)and p.timer>30 then
   p.state="pilot"
   p.timer=0
   ship.state="fly"
   ship.timer=0
   sfx(1)
   
  --if too far away, pull closer
  elseif p.range>=32 then
   p.dx-=(p.x-ship.x)/p.range
   p.dy-=(p.y-ship.y)/p.range
   --boingy sound
   sfx(3)
  end
  
 elseif p.state=="pilot" then
  p.x=ship.x
  p.y=ship.y
  p.dx=0 --very important for
  p.dy=0 --landing correctly!
 elseif p.state=="build" then
  update_build()
 elseif p.state=="shop" then
  update_shop()
 end
end

function draw_p(p)
 if p.state=="move" then
  --draw oxygen tether
  if p.range>=32 then
   line(p.x+4,p.y+4,ship.x+4,ship.y+4,7)
  elseif p.range<=10 then
   line(p.x+4,p.y+4,ship.x+4,ship.y+4,11)
   circ(ship.x+4,ship.y+4,5+sin(p.timer*0.05)*1,11)
  else
   line(p.x+4,p.y+4,ship.x+4,ship.y+4,1)
  end
  --draw player
  outline(p)
  spr(p.s,p.x,p.y)
 elseif p.state=="shop" then
  draw_shop()
 end
end

function init_land()
 p.timer=0
 ship.state="land"
 ship.timer=0
 ship.tx=flr((ship.x+4)/8)*8
 ship.ty=flr((ship.y+4+ship.z)/8)*8
 sfx(-2,1)
 sfx(2)
end

function pilot_ship()
 move(ship)
 --ship directions
 --l,r,u,d
 if(btn(0))ship.flipx=true  ship.s=4
 if(btn(1))ship.flipx=false ship.s=4
 if(btn(2))ship.flipy=false ship.s=2
 if(btn(3))ship.flipy=true  ship.s=2
 --diagonals
 --lu,ld,ru,rd
 if(btn(0)and btn(2))ship.s=3 ship.flipx=true
 if(btn(0)and btn(3))ship.s=3 ship.flipx=true ship.flipy=true 
 if(btn(1)and btn(2))ship.s=3
 if(btn(1)and btn(3))ship.s=3 ship.flipy=true
 
 --push back into map/world area
 if(ship.x>=world_w)ship.dx-=0.15
 if(ship.x<=0)ship.dx+=0.15
 if(ship.y>=world_h)ship.dy-=0.15
 if(ship.y<=0)ship.dy+=0.15
 
 --ship flight sound loop
 if not ship.move and dir_pressed() then
  ship.move=true
  sfx(0,1)
 elseif ship.move and not dir_pressed() then
  ship.move=false
  sfx(-1,1)
 end
 
 --ship jet booster particles
 if dir_pressed() then
  for i=1,10 do
   create_part(ship.x+4,
               ship.y+4,
        -ship.dx+rnd(0.50)-0.25,
        -ship.dy+rnd(0.50)-0.25,
         0,2,2,9)
  end
 end

 ship.mining=false

 --mining lasers
  if btn(5) then
   for o in all(ores) do
    local dx=ship.x-o.x
    local dy=ship.y-o.y
    if abs(dx)<=16 and abs(dx)>=0  and
       abs(dy)<=16 and abs(dy)>=0  then
     o.dmg+=1
     ship.mining=true
    end
   end
  end
  
  --mining laser sound
  if ship.mining and not lsr_snd then
   lsr_snd=true
   sfx(6,2)
  elseif not ship.mining and lsr_snd then
   lsr_snd=false
   sfx(-2,2)
  end
  
 --can land?
 if check_tile(ship.x+4,ship.y+4+ship.z,3) then
  can_land=true
 else
  can_land=false
 end
 
 --land on station
 if can_land and btn(4) and ship.timer>30 then
  if check_tile(ship.x+4,ship.y+4+ship.z,5) then
   init_land()
   init_shop()
  else
   init_land()
   p.state="build"
   --p.x=ship.tx
   --p.y=ship.ty
  end
 else
  
 --if they cant land on station
 --let them leave the ship
 
  --leave ship
  if btnp(4) then
   if abs(ship.dx)+abs(ship.dy)<=1 and ship.timer>=5 then
    p.state="move"
    ship.state="still"
    ship.timer=0
    sfx(1)
   end
  end
 end
 
end

function ship_land()
 ship.x=lerp(ship.x,ship.tx,0.2)
 ship.y=lerp(ship.y,ship.ty,0.2)
 ship.z=0
 ship.s=lerp(ship.s,2,0.05)
 
 if ship.timer>30 and
 not check_tile(ship.x+4,ship.y+4,3) then
  ship_launch()
 end
end

function ship_launch()
 p.state="pilot"
 ship.state="fly" 
 ship.dy=-0.5
 ship.z=4
 exit_build=false
 ship.timer=0
 sfx(4)
end

function update_ship()
 local s=ship
 
 --stop blinking
 if(s.timer>=30)ship.blink=false
 
 if s.state=="still" then
  --ship.dx=0
  --ship.dy=0
 elseif s.state=="fly" then
  pilot_ship()
 elseif s.state=="land" then
  ship_land()
 end
end

function draw_ship()
 if p.state!="shop" then
  pal(8,ship.col[1])
  pal(14,ship.col[2])
  if ship.blink then
   if(blink(1))spr(ship.s,ship.x,ship.y,1,1,ship.flipx,ship.flipy)
  else
   spr(ship.s,ship.x,ship.y,1,1,ship.flipx,ship.flipy)
  end
  pal()
 end
end

function draw_lasers()
 if btn(5) and p.state=="pilot" then
  for o in all(ores) do
   local dx=ship.x-o.x
   local dy=ship.y-o.y
   if abs(dx)<=16 and abs(dx)>=0  and
      abs(dy)<=16 and abs(dy)>=0  then
    line(ship.x+4,ship.y+4, o.x+4,o.y+4,12)
    line(ship.x+4,ship.y+4, ship.x+4-dx/2,ship.y+4-dy/2,7)
    circfill(o.x+4,o.y+4,rnd(3)+1,7)
   end
  end
 end
end

function create_ore(x,y,s,mat)
 local o={
  x=x,
  y=y,
  s=s,
  mat=mat,
  dmg=0,
 }
 add(ores,o)
 return o
end

function update_ore(o)
 if o.dmg>=100 then
  explosion(o.x+4,o.y+4,3)
  mset(o.x/8,o.y/8,35)
  sfx(5)
  if o.mat=="gold" then
   gold+=2
   create_part(o.x,o.y,0,-0.5,36,20)
  end
  del(ores,o)
 end
end 

function draw_ore(o)
 spr(o.s,o.x,o.y)
end

function gen_ore()
 local chance=10 --1 in n chance
 for y=0,world_h/8 do for x=0,world_w/8 do
  if check_tile(x*8,y*8,1) then
   if flr(rnd(chance))==0 then
    create_ore(x*8,y*8,19,"gold")
   end
  end
 end
 end
end

function draw_shadows()
 for i=0,15 do pal(i,0) end
 --ships shadow
 if ship.blink then
  if(blink(1))spr(ship.s,ship.x,ship.y+ship.z,1,1,ship.flipx,ship.flipy)
 else
  spr(ship.s,ship.x,ship.y+ship.z,1,1,ship.flipx,ship.flipy)
 end
 --oxygen tether shadow
 if(p.state=="move")line(p.x+4,p.y+5,ship.x+4,ship.y+5+ship.z,0)
 pal()
end

function update_cam()
 camx=lerp(camx,p.x-64,0.2)
 camy=lerp(camy,p.y-64,0.2)
end

function display(text,col)
 print(text,camx+shakex+3,camy+shakey+120,col)
end

function draw_status()
 if can_land and ship.state=="fly" then
  display("land ship 'z'",3)
 elseif exit_build then
  display("exit building",3)
  
 elseif p.state=="build" then
  display("build mode",13)
 elseif p.state=="pilot" and ship.state=="fly" then
  display("flight mode",13)
  show_gold(camx+61,camy+119)
 elseif p.state=="move" then
  if p.range<=10 then
   display("enter ship 'z'",11)
  else
   display("explorer mode",13)
  end
 end
end

function draw_build_ui()
 local x=camx+shakex
 local y=camy+shakey
 local w=24
 local h=11
 
 if p.state=="build" then
  --green and red colorize
  if can_build==false then
   pal(7,14)
   pal(6,8)
   pal(13,2)
   pal(12,14)
   pal(1,8)
  else
   pal(7,15)
   pal(6,11)
   pal(2,3)
  end
  --show block at cursor
  spr(blocks[p.block][1],p.x,p.y)
  pal()
  --show block info
  print(blocks[p.block][2],
        x+63,y+120,blocks[p.block][3])
  print(blocks[p.block][4].."g",x+119,y+120,9)
 
  rectfill(x+4,y+8,x+4+w,y+8+h,0)
  rect(x+4,y+8,x+4+w,y+8+h,1)

 	--gold
  show_gold(x+6,y+10)
 end
end

function show_gold(x,y)
 spr(20,x,y)
 print("="..gold,x+8,y+2,7)
end

function draw_ui()
 local x=camx+shakex
 local y=camy+shakey
 --screen border
 rect(x,y,x+127,y+127,1)
 --ui bar
 rectfill(x+0,y+117,x+127,y+127,0)
 rect(x+0,y+117,x+127,y+127,1)
 rect(x+0,y+117,x+60,y+127,1)
 
 draw_status()
 draw_build_ui()
end

------------------------

function init_title()
 init_game()
 particles={}
 
 mode="title"
 title={
  x=camx,
  y=camy,
  ty=camy,
  start=false,
  tut=false,
  t=0
 }
end

function update_title()
 local ti=title
 
 foreach(particles,update_part)

 ti.y=lerp(ti.y,ti.ty,0.1)
 
 if btnp(4) and not ti.start then
  ti.start=true
  sfx(8)
  --music(0,0,3)
  smoke_screen(ti.x,ti.y,60)
 end
 if(btnp(5)and not ti.start)ti.tut=not ti.tut sfx(7)
 if(ti.start==true)ti.t+=1 ti.ty=-128
 if(ti.t>=20)init_game()
end

function draw_title()
 local ti=title
 
 draw_game()
 foreach(particles,draw_part)
 
 rectfill(ti.x,ti.y,ti.x+127,ti.y+127,0)
 --draw_starfield(t.x,t.y)
	--title
 spr(80,ti.x+32,ti.y+16+sin(t)*8,8,2)
 --planet
 draw_planet(ti.x+48,ti.y+40)
 --station
 spr(21,ti.x+64+sin(t/4)*24,ti.y+72+cos(t/4)*24)
 
 if blink(1) then
 	print("press z to start",ti.x+34,ti.y+104,8)
 end
 print("press x for tutorial",ti.x+26,ti.y+112,5)
 print("@pixel_cod",ti.x+1,ti.y+122,1)

 if(ti.tut)draw_tutorial(ti.x,ti.y)
end

function draw_tutorial(x,y)
 rectfill(x,y,x+127,y+127,0)
 rect(x+1,y+1,x+126,y+126,1)
 print("how to play:",x+40,y+8,7)
 line(x+40,y+16,x+82,y+16,7)
 
 print("controls:",x+8,y+24,7)
 print("⬅️➡️⬆️⬇️: move",x+8,y+32,10)
 
 print("z/🅾️:    -exit/enter ship",x+8,y+40,9)
 print("-land on station",x+44,y+48,9)
 print("-build",x+44,y+56,9)
 
 print("x/❎:",x+8,y+64,8)
 print("-mine gold ore",x+44,y+64,8)
 print("-switch block",x+44,y+72,8)

 print("mining:",x+4,y+82,1)
 print("building:",x+65,y+82,1)
 --demo windows
 rect(x+3,y+88,x+62,y+124,1)
 rect(x+64,y+88,x+124,y+124,1)

 --mining demo
 print("hold x",x+21,y+116,1)
 if(blink(0.1))line(x+12,y+100,x+30,y+108,12)
 
 spr(4,x+8,y+96)
 spr(19,x+26,y+104)
 --gold pile
 spr(20,x+48,y+104)
 if(blink(0.1))spr(36,x+48,y+94)
end

function init_game()
 mode="game"
 world_w=96*8
 world_h=32*8
 init_shake()
 palettes={ex={2,5,6,8,9,10}}
 
 --block_id, name, text col, cost
 blocks={{5,"demolish tool",8,0},
         {64,"station block",7,1},
         {8,"reactor core",7,3},
         {9,"ship workshop",3,3},
         {7,"landing pad",3,2},
         {6,"solar panel",7,1},
         {10,"radar dish",7,2}}
 
 gold=6
 
 ores={}
 
 --create_ore(10*8,4*8,19,"gold")
 --create_ore(20*8,10*8,19,"gold")
 --create_ore(30*8,10*8,19,"gold")
 --test_ore=create_ore(40*8,10*8,19,"gold")
 --gen_ore()
 
 colours={smoke={0,5}}
 --particles={}
 
 p=create_actor(88,88,0,0,0.05,0.95,1)
 p.state="pilot"
 p.block=1
 p.range=0
 
 ship=create_actor(88,88,0,0,0.1,0.95,2)
 ship.z=4
 ship.state="fly"
 ship.col={8,14}
 ship.flipx=false
 ship.flipy=false
 ship.move=false
 ship.mining=false
 lsr_snd=false
 
 camx=p.x-64
 camy=p.y-64
end

function update_game()
 update_p(p)
 update_ship()
 foreach(ores,update_ore)
 
 update_actor(p)
 update_actor(ship)
 
 if(#ores<1)gen_ore()
 
 update_cam()
 foreach(particles,update_part)
end

function draw_game()
 do_shake()
 draw_bg()
 map()
 
 foreach(ores,draw_ore)
 draw_shadows()
 
 foreach(particles,draw_part)
 
 draw_lasers()
 draw_p(p)
 draw_ship()
 
 draw_ui()
 
 if debug then
  --print("mem:"..stat(0),camx+8,camy+8,8)
  --print("cpu:"..stat(1),camx+8,camy+16,8)
  --print(p.x,8+camx,8+camy,8)
  --print(p.y,8+camx,16+camy,9)
  
  --print(p.dx,48+camx,8+camy,8)
  --print(p.dy,48+camx,16+camy,9)
  
  --print(ship.x,camx+8,camy+32,8)
  --print(ship.y,camx+8,camy+40,9)
 
  --print(ship.tx,camx+8,camy+56,8)
  --print(ship.ty,camx+8,camy+64,9)
 
  --print(p.state,camx+80,camy+8,8)
  --print(ship.state,camx+80,camy+16,9)
  --print(p.timer,camx+32,camy+8,8)
  --print(ship.timer,camx+32,camy+16,8) 
  --print(ship.mt,camx+32,camy+24,8)
  
  --print(ship.tx,camx+8,camy+52,8)
  --print(ship.ty,camx+8,camy+64,8)
  
  --print(test_ore.x,camx+56,camy+32,15)
  --print(test_ore.y,camx+56,camy+40,15)
  
  print(t,camx+88,camy+2,12)
  
  --print(ship.mining,8+camx,8+camy,8)
  --print(lsr_snd,8+camx,16+camy,9)
  
  if shop!=nil then
   print(shop.sel,camx+80,camy+80,8)
  end
 end
end

-----------------------

function _init()
 debug=false
 
 t=0
 init_title()
end

function _update()
 if mode=="title" then
  update_title()
 elseif mode=="game" then
  update_game()
 end
 
 t+=0.01
end

function draw_starfield(x,y)
 --starfield
 for i=-64,world_w,16 do
  for j=-64,world_h,16 do
   pset(x+i,y+j,1)
  end
 end
end

function draw_bg()
 local x=camx/2
 local y=camy/2
 
 draw_starfield(x,y)
 draw_planet(x,y)
end

function draw_planet(x,y)
 --draw planet
 circfill(x+16,y+32,16,1)
 circfill(x+16,y+32,14,3)
 circfill(x+14,y+30,12,11)
 
 circfill(x+17,y+25,2,3)
 circfill(x+8,y+24,1,3)
 circfill(x+8,y+36,2,3)
 circfill(x+23,y+38,4,3)
end

function _draw()
 cls(0)
 if mode=="title" then
  draw_title()
 elseif mode=="game" then
  draw_game()
 end
end