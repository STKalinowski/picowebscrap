-- omega zone
--

poke(0x5f41,15)
--poke(0x5f42,15)

tick=0
grid=4
gameover=false
startdelay=30
titledelay=0
scoreflash=0
screenflash=0
gridflash=0
scanspeed=0
bonuslimit=20
scores={
	8,15,25,40,4,2,0
}
ecoin={1,2,3,4,1,0,0}
bestscore=0
bonuslevel=false

function dogameover()
	startdelay=0
	add(scorestat,{plr.score,bonuslevel})
	gameover=true
	tick=0
	titledelay=30
	if plr.score > bestscore then
		bestscore=plr.score
		dset(0, bestscore)
	end
end

coll={
	-- sides
	0,0,0,0,0,0,0,0,
	-- box
	0,0,0,0
}

splodes={}
scan=0
parts=1
scanw=32

function addenemy(t,x,y)
	add(enemy,{t=t,x=x,y=y,dx=rnd(0.5)-.25,dy=rnd(0.5)-.25,age=0,shoot=0})
end

function _init()
	cartdata("kb_omegalame")
	bestscore=dget(0)
	if not bestscore then
		bestscore=0
	end
	initgame()
	gameover=true
	splodes={}
	coins={}
end

function initgame()
scorestat={}
coinctr=0
bonuslimit=22
gameover=false
plr={
	shielddelay=0,
	shieldctr=0,
	lives=3,
	level=1,dead=true,
	score=0,x=64,y=16,dx=0,dy=0,a=0.25,shoot=0
}

initlevel(1)

end

function initlevel(l,bonus)
if l>1 and (not plr.dead or bonuslevel) then
	add(scorestat,{plr.score,bonuslevel})
end
--if l%5 == 0 then bonuslevel=true end
bonuslevel=bonus
gridflash=30
leveltime=0
if plr.dead then
	plr.a=0.25
	plr.x = 64
	plr.y = 16
	plr.dx = 0
	plr.dy = 0
	startdelay=90
	splode(plr.x,plr.y,true)
	
	splodes[#splodes].age=0
else
	startdelay=30
end
scanw=0
if bonuslevel then
 scandelay=min(90+600/plr.level,30*7)
	parts=flr(plr.level/9)+1
else
 scandelay=min(60+200/plr.level,30*7)
	parts=flr(plr.level/5)+1
end
plr.dead=false
plrbul={
}

enemybul={
}

enemy={
}

coins={}

--splodes={}

e={6,6,1,2,1,5,2,6,3,1,5,5,
			5,3,2,2,6,4,3,6,6,3,6,3,4,2,1,
			4,2,1,2,3,4,4}
local yo=16
scan=0.75
if plr.y < 64 then
	yo=80
	scan=0.25
end

if bonuslevel then
	local x=64
	local y=plr.y > 64 and 32 or 96
	addenemy(7,x,y)
	enemy[1].dx=0
	enemy[1].dy=0
	splode(x,y,true)
	splodes[#splodes].age=60-startdelay
else
	for i=l,l+flr(2+l*0.15) do
		local x,y=16+rnd(100),yo+rnd(32)
		addenemy(e[(i-1)%#e+1],x,y)
		splode(x,y,true)
		splodes[#splodes].age=60-startdelay
	end
end

end

function splode(x,y,r,t)
	add(splodes,{t=t or 1,x=x,y=y,age=0,r=r})
end

function dosplodes()
	for s in all(splodes) do
		s.age += 1
		local ma=15
		if s.r then ma=60 end
		if s.age > ma then
			del(splodes,s)
		end
	end
end

function colls(plr)
	local hit=false
	if plr.x < 4 then
		hit = true
		if plr.y < 64 then
			coll[1]=10
		else
			coll[2]=10
		end
		plr.x = 4
		plr.dx = -plr.dx
	end
	
	if plr.x > 123 then
		hit = true
		if plr.y < 64 then
			coll[3]=10
		else
			coll[4]=10
		end
		plr.x = 123
		plr.dx = -plr.dx
	end

	if plr.y < 4 then
		hit = true
		if plr.x < 64 then
			coll[5]=10
		else
			coll[6]=10
		end
		plr.y = 4
		plr.dy = -plr.dy
	end
	
	if plr.y > 123 then
		hit = true
		if plr.x < 64 then
			coll[7]=10
		else
			coll[8]=10
		end
		plr.y = 123
		plr.dy = -plr.dy
	end
	
	if plr.x >= 64-32 and 
			 plr.x < 64+32 and 
			 plr.y >= 64-16 and 
			 plr.y < 64+16 then
		hit = true
		if plr.x-plr.dx < 64-32 or
			plr.x-plr.dx >= 64+32 then
			if plr.x > 64 then
				plr.x = 64+32
			else
				plr.x = 64-32-1
			end

			plr.dx = -plr.dx
		else
			if plr.y > 64 then
				plr.y = 64+16
			else
				plr.y = 64-16-1
			end
	
			plr.dy = -plr.dy
		end 
	
	end
	
	return hit
end

function addscore(s)
	if gameover then
		return
	end
	local prev=plr.score
	if (prev < 500 and plr.score >= 500) 
		or (prev < 1200 and plr.score >= 1200) then
		sfx(6)
		plr.lives+=1
	end
	plr.score+=s
	scoreflash=5
end

function docoin(c)
	c.x+=c.dx
	c.y+=c.dy
	colls(c)
	c.dx*=0.994
	c.dy*=0.994
	c.ttl-=1
	if not plr.dead and startdelay <= 30 then
	local dx=plr.x-c.x
	local dy=plr.y-c.y
	local d=dx*dx+dy*dy
	if d<16*16 then
		d=sqrt(d)
		dx/=d
		dy/=d
		c.x+=dx*2
		c.y+=dy*2
	end
	end
end

function ai(e)
	e.age+=1
	if e.shoot > 0 then
		e.shoot -= 1
	end
	
	if e.shoot <= 0 and e.age > 30 and e.t <= 4
		and rnd()<0.001+plr.level/350 then
		e.shoot=60/plr.level+20
		local dx=plr.x-e.x
		local dy=plr.y-e.y
		local r=2/plr.level+0.02
		local a=atan2(dx,dy)+rnd(r*2)-r
		shoot(enemybul,e.x,e.y,cos(a)*2,sin(a)*2)
		sfx(5)
	end
		
	if e.t <=4 or e.t==7 then
	local s=0.01
	if e.t==7 or e.t==4 then
		if leveltime < 18*30 then
			s=0.025
		else
			s=0.1
		end
	end
	if e.x > 64 then
		e.dy -= s
	end
	
	if e.x < 64 then
		e.dy += s
	end
	
	if e.y > 64 then
		e.dx += s
	end
	
	if e.y < 64 then
		e.dx -= s
	end
	
	end
	
	if e.t==5 or e.t==4 then
		local dx=plr.x+rnd(32)-16-e.x
		local dy=plr.y+rnd(32)-16-e.y
		local d=sqrt(dx*dx+dy*dy)
		
		dx/=d
		dy/=d
		
		e.dx -= dx*0.05
		e.dy -= dy*0.05
	end
	
	
	
	if e.dx*e.dx+e.dy*e.dy>9 or e.t==4 then
		local d=sqrt(e.dx*e.dx+e.dy*e.dy)/3
		e.dx/=d
		e.dy/=d
	end
	
	if e.t==4 then
		e.dx*=0.75
		e.dy*=0.75
	end
	
	--e.dx=max(-2,min(2,e.dx))
	--e.dy=max(-2,min(2,e.dy))

	if e.t < 2 then
		e.x+=e.dx
		e.y+=e.dy
	else
		e.x-=e.dx
		e.y-=e.dy
	end
	
	if e.t != 7 then
		e.dx *= 0.99-0.03/plr.level
		e.dy *= 0.99-0.03/plr.level
	else
		e.dx *= 0.9825
		e.dy *= 0.9825
	end
	
	if #enemy < 50 and e.t>=2
	 and e.t <= 4 and e.age > 2*30 and rnd()<0.03 and
  not e.dropped then
		e.todrop=e.t == 3 and 3 or 5
		e.dropped=true
	end
	
	if leveltime > 15*30 and rnd()<0.01 then
		e.dropped=false
	end
	
	if leveltime > 2*30 and tick % 10 == 0 and e.t==7 then
		local s=min(1.5,leveltime/30/30)
		add(coins,{dx=rnd(s*2)-s,dy=rnd(s*2)-s,x=e.x,y=e.y,ttl=90})
		sfx(1)
	end
	
	if e.t==6 and leveltime > 15*30 and rnd()<0.0025*plr.level then
		e.t=5
		sfx(10)
	end
	
	if not gameover and tick % 15 == 0 and e.todrop and e.todrop>0 then
		if e.t==2 then
			addenemy(6,e.x,e.y)
		elseif e.t==3 then
			addenemy(5,e.x,e.y)
		end
		e.todrop-=1
		sfx(1)
	end
	
	colls(e)
	
	if e.t != 7 then
	for b in all(plrbul) do
		if abs(b.x-e.x)<6 and
			abs(b.y-e.y)<6 then
			splode(e.x,e.y)
			sfx(3)
			--extcmd("label")
			del(enemy,e)
			del(plrbul,b)
			addscore(scores[e.t])
			for i=1,ecoin[e.t] do
				add(coins,{x=e.x,y=e.y,dy=rnd()-0.5,dx=rnd()-0.5,ttl=110+rnd(20)})
			end
			break
		end
	end
	end
end

function shoot(arr,x,y,dx,dy)
	add(arr,{x=x+dx*2,y=y+dy*2,dx=dx,dy=dy})
end

function dobul(arr)
	for b in all(arr) do
		b.x += b.dx
		b.y += b.dy
	
		if colls(b) then
			del(arr,b)
		end
	end
end

function drawbul(b)
	line(b.x,b.y,b.x-b.dx*2,b.y-b.dy*2,tick%2*10+2)
end

function drawbule(b)
	line(b.x,b.y,b.x-b.dx*2,b.y-b.dy*2,tick%2*3+8)
end


function plrhit()
	plr.dead=true
	splode(plr.x,plr.y)
	sfx(0)
	screenflash=15
	if bonuslevel then
		plr.level+=1
		coinctr=0
		bonuslimit+=7
		initlevel(plr.level)
	else

		plr.lives-=1
		
		local x,y=plr.x,plr.y
		
		if plr.lives == 0 then
			dogameover()
		else
			initlevel(plr.level)
		end
		
		for i=1,coinctr do
			add(coins,{dx=rnd(2)-1,dy=rnd(2)-1,x=x,y=y,ttl=120+rnd(30)})
		end
		coinctr=0
	end
end

function _update()
	titledelay=max(0,titledelay-1)

	local tg=grid
	if leveltime > 17*30 then
		tg = 8
	elseif gameover then
		tg = 32
	elseif bonuslevel then
		tg = 64
	else
		tg = 16
	end
	
	if grid > tg then
		grid -= 0.2
	elseif grid < tg then
		grid += 0.2
	end
	
	if abs(grid-tg)<0.1 then
		grid=tg
	end
	
	if plr.shielddelay > 0 then
		plr.shielddelay -= 1
	end
	
	if plr.shieldctr > 0 then
		plr.shieldctr -= 1
	end


	if scandelay <= 0 then
			local speedmul = 1.0
			
			if not bonuslevel then
				if plr.level >= 10 then
					speedmul = -sin((leveltime-scandelay)/1200)*16
				end
			else
				speedmul = 1.0
			end
			
			speedmul = max(-1,min(1,speedmul))
	
			if bonuslevel then
				scanspeed =0.005+0.0001*plr.level
			else
				scanspeed = 0.001+0.0005*plr.level/parts
			end
			if leveltime > 20*30 then
	 		scanspeed += (leveltime-20*30)/30000
			end
			if plr.level >= 20 then
				speedmul = -speedmul
			end
			scanspeed *= speedmul
			scan += scanspeed
	elseif startdelay <= 0 then
		scandelay -= 1
		if scanw <= 0 then
			if bonuslevel then
				local e=enemy[1]
				scan = -atan2(e.x-64,e.y-64)+(1/parts)/2
			else
				scan = -atan2(plr.x-64,plr.y-64)+(1/parts)/2
			end
		end
		
		if scandelay < 32 and scanw < 32 then
			scanw += 1
			if scanw==1 then
				sfx(8)
			end
		end
		
		
	end
	if titledelay <= 0 and gameover and btnp(4) and not prev4 then
		initgame()
		sfx(6)
	end
	
	prev4=btn(4)

	if not gameover and not plr.dead and #enemy == 0 and #coins == 0 then
		if not bonuslevel and coinctr >= bonuslimit then
			--coinctr=0
			initlevel(plr.level,true)
		else
			plr.level+=1
			initlevel(plr.level)
		end
		sfx(7)
		
	end

	tick += 1
	
	if startdelay == 0 then
		leveltime+=1
		foreach(enemy,ai)
		if leveltime > 25*30 then

			for e in all(enemy) do
				if e.t == 7 then
					del(enemy,e)
					for i=1,10 do
						add(coins,{dx=rnd(2)-1,dy=rnd(2)-1,x=e.x,y=e.y,ttl=90})
					end
					splode(e.x,e.y)
					sfx(0)
				end
			end
			
		
		end
	elseif not gameover then
		startdelay-=1
		if startdelay==30 then
			sfx(11)
		end
	end
	
	for c in all(coins) do
		docoin(c)
		if c.ttl <= 0 then
			del(coins,c)
			sfx(13)
			splode(c.x,c.y,false,2)
		end
	end
	
	if startdelay < 30 and not gameover then
	if btn(4) then
		if plr.shoot <= 0 then
			shoot(plrbul,plr.x,plr.y,cos(plr.a)*4,-sin(plr.a)*4)
			sfx(2)
			plr.shoot=5
		else
			plr.shoot-=1
		end
	end
	if btn(0) then
		plr.a -= 0.04
	end
	if btn(1) then
		plr.a += 0.04
	end
	if btn(5) then
		if plr.shielddelay <= 0 then
			plr.shielddelay=45
			plr.shieldctr=20
			sfx(9)
		end
	end
	if btn(2) then
		plr.dx += cos(plr.a)*0.2
		plr.dy -= sin(plr.a)*0.2
	end
	
	plr.x+=plr.dx
	plr.y+=plr.dy
	
	plr.dx *= 0.98
	plr.dy *= 0.98

	if (colls(plr)) sfx(4)
	
	if not plr.dead then
	for b in all(coins) do
	 if abs(b.x-plr.x)<5 and
			abs(b.y-plr.y)<5 then
				del(coins,b)
				addscore(bonuslevel and 3 or 1)
				if not bonuslevel then
					coinctr+=1
				end
				sfx(12)
		end
	end
	for b in all(enemybul) do
		if abs(b.x-plr.x)<3 and
			abs(b.y-plr.y)<3 then
			if plr.shieldctr <= 0 then
				del(enemybul,b)
				plrhit()
				break
			else
				sfx(4)
				del(enemybul,b)
			end
		end
	end
	end
	
	if not plr.dead then
	for b in all(enemy) do
		if abs(b.x-plr.x)<=4 and
			abs(b.y-plr.y)<=4 then
			del(enemybul,b)
			plrhit()
			break
		end
	end
	end
	
	if not plr.dead then
	if scanw >= 32 then
	for i=1,parts do
	local a= atan2(cos(scan+(i-1)/parts),-sin(scan+(i-1)/parts))
	
	for c in all(coins) do
		if abs(a-atan2(c.x-64,c.y-64)) <= abs(scanspeed*2)
		 then
		 del(coins,c)
		 sfx(13)
		 splode(c.x,c.y,false,2)
		end
	end
	
	if plr.shieldctr <= 0 and abs(a-atan2(plr.x-64,plr.y-64)) <= abs(scanspeed*2)
		 then
			plrhit()
	end
	end
	end
	end
	
	end
	
	
	dobul(plrbul)
	dobul(enemybul)
	dosplodes()
	
	if scoreflash > 0 then
		scoreflash-=1
	end

	if screenflash > 0 then
		screenflash-=1
	end

	if gridflash > 0 then
		gridflash-=1
	end

	for c=1,8 do
		if (coll[c]>0) coll[c]-=1
	end
end

function drawcoin(c)
	if c.ttl > 30 or tick%4<2 then
	spr(8+tick%2, c.x-4, c.y-4)
	end
end

function drawsplode(s)
	if s.t==1 then
	for i=0,9 do
		local x=cos(i/10)
		local y=-sin(i/10)
		local d=s.age*2
		
		if s.r then
			d=120-d
		end
		
		if d < 30 then
		
		line(s.x+x*d,s.y+y*d,
			s.x+x*(d+2),s.y+y*(d+2),7)
		end
	end
	else
		for i=0,4 do
		local x=cos(i/5)
		local y=-sin(i/5)
		local d=s.age
		
		if d < 15 then
		
		pset(s.x+x*d,s.y+y*d,10)
			
		end
	end
	end
end

chars="0123456789levgamorhuyb nudf"

function ord(s,i)
	for j=1,#chars do
		if sub(chars,j,j)==sub(s,i,i) then
			return j-1
		end
	end
	return nil
end

function drawtext(txt,x,y)
	y = y or 60
	
	for i=1,#txt do
		spr(48+ord(txt,i),i*8+x,y)
	end
	
end

function _draw()
	cls()
	
	local c=gridflash/10+1
	if gridflash % 2 == 0 then	
		if bonuslevel then
			c=3
		else
			c=1
		end
		if leveltime > 18*30 then
			local p=flr(8-(leveltime-18*30)/15)+1
			if p<=1 or tick%p==0 then
				c=2
			end
		end
	end
	
	for i=0,64,grid do
		
		line(i+64,0,i+64,127,c)
		line(0,i+64,127,i+64,c)
		line(64-i,0,64-i,127,c)
		line(0,64-i,127,64-i,c)
	end
	
	if screenflash > 0 then
	rectfill(0,0,127,127,screenflash%10)
	end
	-- plr
	if startdelay <= 30 and not gameover then
	line(plr.x+cos(plr.a)*4,
		plr.y-sin(plr.a)*4,
		plr.x+cos(plr.a+0.35)*3,
		plr.y-sin(plr.a+0.35)*3,7)
	line(plr.x+cos(plr.a)*4,
		plr.y-sin(plr.a)*4,
		plr.x+cos(plr.a-0.35)*3,
		plr.y-sin(plr.a-0.35)*3,7)
		if plr.shieldctr > 0 then
			circ(plr.x,plr.y,3-sin(plr.shieldctr/40)*3,tick%8+5)
		end
	end
	
	for i=1,parts do	
		local sx=cos(scan+(i-1)/parts)
		local sy=-sin(scan+(i-1)/parts)
	
		if scanw > 0 then
			line(64+sx*48,64+sy*48,64+sx*(48+scanw*1.5),64+sy*(48+scanw*1.5), tick%7+4)
			line(64+sx*48,64+sy*48,64+sx*(48-scanw*1.5),64+sy*(48-scanw*1.5), tick%7+4)
		end
	end
	
	rectfill(64-32+4,64-16+4,64+32-4,64+16-4,0)
	rect(64-32+4,64-16+4,64+32-4,64+16-4,7)
	line(0,0,0,64,coll[1]%8)
	line(0,64,0,127,coll[2]%8)
	line(127,0,127,64,coll[3]%8)
	line(127,64,127,127,coll[4]%8)
	line(0,0,64,0,coll[5]%8)
	line(64,0,128,0,coll[6]%8)
	line(0,127,64,127,coll[7]%8)
	line(64,127,128,127,coll[8]%8)

	if startdelay == 0 then	
	for e in all(enemy) do
		if e.t==1 then
			spr(1+(tick/5)%2,e.x-4,e.y-4)
		elseif e.t==2 then
			spr(4,e.x-4,e.y-4)
		elseif e.t==3 then
			spr(5,e.x-4,e.y-4)
		elseif e.t==4 then
			spr(6+tick/2%2,e.x-4,e.y-4)
		elseif e.t==5 then
			spr(13+tick/4%3,e.x-4,e.y-4)
		elseif e.t==7 then
			spr(10+tick/3%3,e.x-4,e.y-4)
		else
			spr(3,e.x-4,e.y-4)
		end
	end
	end

	foreach(coins,drawcoin)	
	foreach(plrbul,drawbul)
	foreach(enemybul,drawbule)
	foreach(splodes,drawsplode)

	
	if startdelay > 60 or startdelay <= 0 then
		local txt
		
		
		if gameover and tick % 90 < 15 then
			txt="game"
			drawtext(txt,40)
		elseif gameover and tick % 90 < 30 then
			txt="over"
			drawtext(txt,40)
		elseif not gameover and leveltime > 15*30 and leveltime < 22*30 then
			drawtext("hurry",36)	
		else
			if scoreflash > 0 then
				pal(7,scoreflash%10)
			end

			txt="000000"..plr.score.."0"
			txt=sub(txt,#txt-5,#txt)
			drawtext(txt,32)
			pal()
		end
	elseif startdelay > 45 then
		drawtext("l1ve5",36)
	elseif startdelay > 30 then
		drawtext(""..plr.lives,52)
	elseif startdelay > 15 then
		if bonuslevel then
			drawtext("bonu5",36)
		else
			drawtext("level",36)
		end
	elseif startdelay > 0 then
		if bonuslevel then
			drawtext("round",36)
		else
		drawtext((plr.level < 10 and "0" or "")..plr.level,48)
		end
	end
	--[[
	if not gameover and not bonuslevel then
		local plops=min(18,flr(coinctr*18/bonuslimit))
		for i=0,plops-1 do
			rect(64-plops/2*3+i*3+1,64+9,64-plops/2*3+i*3+2,64+10,10)
		end
	end
	--]]
	
	--map(0,0,24,12,10,4)		
	
	if gameover then
		map(0,0,24,12,10,4)		
		txt="000000"..bestscore.."0"
		txt=sub(txt,#txt-5,#txt)
			
		drawtext("be57 "..txt, 12, 92)
		if titledelay <= 0 then
			pal(7,tick%3+7)
			drawtext("f1re 7o 57ar7", 4, 112)
			pal()
		end
		
		--[[local x=64-#scorestat/2
		local i=1
		for s in all(scorestat) do
			local c=s[2] and 3 or (i%5==0 and 7 or 12)
			if i==flr(#scorestat*(30-titledelay)/30) then
				c=7
			end
			line(x,96-flr(s[1]*16/plr.score),x,96,c)
			x+=2
			i+=1
		end--]]
	end
	
	
end
