-- cave runners!
-- by guerragames

--[[
todo:
- pick-ups?
- land anim?
- bouncer?
- finish screen?! congratulations + global time
--]]

-------------------
-- globals
-------------------
one_frame = 1/30

t = 0
time_since_press = 100
time_since_release = 100
time_held = 0
button_held = false

max_running_time = 60*100

---------------------------
-- button handling
---------------------------
function button_update()
 time_since_press += one_frame
 time_since_release += one_frame
  
 -- button or mouse button pressed
 if btn(4) or btn(5) or stat(34) != 0 then
  if time_held == 0 then
   button_held = true
   time_since_press = 0
  end
  
  time_held += one_frame
 else
  if time_held > 0 then
   time_since_release = 0
  end
  
  button_held = false
  time_held = 0
 end
end

function button_consume()
 time_since_press = 100
 time_since_release = 100
end

---------------------------
-- vector2d 
---------------------------
function magnitude( x, y )
  return sqrt( x * x + y * y )
end

-------------------

function normalizewithmag( x, y )
  local mag = magnitude( x, y )
  local one_over_mag = 1 / mag

  local normal_x = x * one_over_mag
  local normal_y = y * one_over_mag

  return normal_x, normal_y, mag
end

-------------------

function rotate_point( x, y, cosa, sina )
 return x*cosa - y*sina, x*sina + y*cosa
end

-------------------

function scale_point( x, y, scalex, scaley )
 return scalex*x, scaley*y
end

----------------------------
-- ease_out
----------------------------
function ease_out(time, start, delta, duration)
 time /= duration
 time -= 1 
 return delta*(time*time*time*time*time + 1) + start
end

function lerp(time, start, delta, duration)
 return time*delta/duration + start
end


----------------------------
-- print_outline
----------------------------
align_center = 0
align_left = 1
align_right = 2

function print_outline( text, x, y, color, backc, align )
  local offsetx = 0 
  
  if not align or align == align_center then
   offsetx = (#text * 0.5)*4
  elseif align == align_right then
   offsetx = #text*4
  end
  
  print( text, x - offsetx - 1, y - 0, backc )
  print( text, x - offsetx - 1, y - 1, backc )
  print( text, x - offsetx + 0, y - 1, backc )
  print( text, x - offsetx + 1, y - 1, backc )
  print( text, x - offsetx + 1, y + 0, backc )
  print( text, x - offsetx + 1, y + 1, backc )
  print( text, x - offsetx - 0, y + 1, backc )
  print( text, x - offsetx - 1, y + 1, backc )
  
  print( text, x - offsetx, y, color )
end

----------------------------
-- print_scaled
----------------------------

function scan_text(text)
  cls()
  scan={}
  print(text,0,0,1)
  for y=0,6+1 do
    scan[y]={}
    for x=0,(#text)*4+1 do
      scan[y][x]=pget(x,y)
    end
  end
  cls()
  return scan
end

-----------

function print_scaled(text,x,y,w,h,color)

  tw=#text[0]
  th=#text
  
  pix_w = flr(w/tw)
  pix_h = flr(h/th)
  
  pix_w = (pix_w == 0) and 1 or pix_w
  pix_h = (pix_h == 0) and 1 or pix_h
  
  for j=y,y+h,pix_h do
   v=flr(((j-y)/h)*th)
   row = text[v]
   
   for i=x,x+w,pix_w do
    u=flr(((i-x)/w)*tw)
	c = row and row[u] or c
	if c!=0 then
	 if color!=nil then
	  rectfill(i,j,i+pix_w-1,j+pix_h-1,color)
	 else
	  rectfill(i,j,i+pix_w-1,j+pix_h-1,c)
	 end
	end
   end
  end
end

-----------

function print_outline_scaled( text,x,y,w,h, color, backc )
 
  print_scaled( text, x - 1, y - 0,w,h, backc )
  print_scaled( text, x - 1, y - 1,w,h, backc )
  print_scaled( text, x + 0, y - 1,w,h, backc )
  print_scaled( text, x + 1, y - 1,w,h, backc )
  print_scaled( text, x + 1, y + 0,w,h, backc )
  print_scaled( text, x + 1, y + 1,w,h, backc )
  print_scaled( text, x - 0, y + 1,w,h, backc )
  print_scaled( text, x - 1, y + 1,w,h, backc )
  
  print_scaled( text, x, y,w,h, color )
end

-----------------
-- time_to_text
-----------------
function time_to_text( time )
 local mins = flr(time/60)
 local secs = time%60
 
  if mins >= 100 then
   return "99:59.999"
  elseif mins > 0 then
   if secs < 10 then
    return mins..":0"..secs
   else
    return mins..":"..secs
   end
  else
   return ""..secs
  end
end

------------------------
-- arrow
------------------------
arrow = {}
arrow.size = 5
arrow.scale = 1
arrow.min_scale = 0.8
arrow.max_scale = 0.8
arrow.min_col_scale = 0.5
arrow.max_col_scale = 1.8
arrow.x = 80
arrow.y = 80
arrow.colors = {8,9,10,7,12}
arrow.nx = 1
arrow.ny = 0

arrow.points =
{
 { 0, 0},
 { 2, 2},
 { 1, 2},
 { 1, 4},
 {-1, 4},
 {-1, 2},
 {-2, 2},
 { 0, 0},
}

--------------------------

arrow.draw = function()
 local st = 0.8*sin(t)
 local scale = arrow.scale
 
 if scale < arrow.min_scale then
  scale = arrow.min_scale
 elseif scale > arrow.max_scale then
  scale = arrow.max_scale
 end
 
 local col_scale = arrow.scale
 if col_scale < arrow.min_col_scale then
  col_scale = arrow.min_col_scale
 elseif col_scale > arrow.max_col_scale then
  col_scale = arrow.max_col_scale
 end
 local color_index = 1 + flr( ((col_scale - arrow.min_col_scale)/(arrow.max_col_scale - arrow.min_col_scale) ) * (#arrow.colors-1))
 local color = arrow.colors[color_index]
 
 local x,y = scale_point(arrow.points[1][1], arrow.points[1][2], scale*(arrow.size+st), scale*(arrow.size-st))
 local cosa = arrow.ny
 local sina = arrow.nx
 x,y = rotate_point(x,y,cosa,sina)
 
 for i=2,#arrow.points do
  local px,py = x,y
  x,y = scale_point(arrow.points[i][1], arrow.points[i][2],scale*(arrow.size+st), scale*(arrow.size-st))
  x,y = rotate_point(x,y,cosa,sina)
  
  local ax = arrow.x+x
  local ay = arrow.y+y
  local pax = arrow.x+px
  local pay = arrow.y+py
  line(ax+1,ay,pax+1,pay, 0)
  line(ax-1,ay,pax-1,pay, 0)
  line(ax,ay+1,pax,pay+1, 0)
  line(ax,ay-1,pax,pay-1, 0)

  line(ax+1,ay+1,pax+1,pay+1, 0)
  line(ax-1,ay-1,pax-1,pay-1, 0)
  line(ax-1,ay+1,pax-1,pay+1, 0)
  line(ax+1,ay-1,pax+1,pay-1, 0)
 end 

 for i=2,#arrow.points do
  local px,py = x,y
  x,y = scale_point(arrow.points[i][1], arrow.points[i][2],scale*(arrow.size+st), scale*(arrow.size-st))
  x,y = rotate_point(x,y,cosa,sina)
  line(arrow.x+x,arrow.y+y,arrow.x+px,arrow.y+py, color)
 end 
 
end

--------------------------
-- booms
--------------------------
booms = {}
booms.next = 1
booms.count = 10
booms.max_time = .2

booms.max_spikes = 100
booms.min_size = 8
booms.max_size = 40

for i=1,booms.count do
 local boom = {}
 
 boom.t = 0
 boom.x = 64
 boom.y = 64
 boom.spikes_count = 100
 boom.color = 7
 boom.active = false
 boom.orient = 0
 
 for j=1,booms.max_spikes+1 do
  local b = {}
  b.r = 0
  b.a = 0
  b.max_r = 0
  add( boom, b )
 end
 
 add( booms, boom )
end

----------------------
booms.spawn = function( x, y, color, orient, spikes_count ) -- orient: 0=floor,1=rwall,2=ceiling,3=lwall, 4=360
 local boom = booms[booms.next]
 boom.t = 0
 boom.x = x
 boom.y = y
 boom.color = color
 boom.active = true
 boom.orient = orient
 boom.spikes_count = spikes_count
 
 if boom.spikes_count > booms.max_spikes then
  boom.spikes_count = booms.max_spikes
 end

 for i=1,boom.spikes_count+1 do
  local b = boom[i]
  b.r = 0
  if boom.orient == 4 then
   b.a = i/boom.spikes_count
  else
   b.a = (i-1)/(2*boom.spikes_count) + boom.orient*0.25
  end
  
  b.max_r = booms.min_size + rnd()*((booms.max_size-booms.min_size)*(i%2))
 end
 
 booms.next += 1
 
 if booms.next > booms.count then
  booms.next = 1
 end
end

----------------------------
booms.update = function()
 for i=1,booms.count do
  local boom = booms[i]
  if boom.active then 
   boom.t += one_frame
 
   for j=1,boom.spikes_count+1 do
    local b = boom[j]
    b.r = (boom.t/booms.max_time)*b.max_r
  
    if b.r > b.max_r then
     b.r = b.max_r
    end
   end  
  
   if boom.t >= booms.max_time then
    boom.active = false
   end
  end
 end
end

-------------------------
booms.draw_line = function( cx, cy, b1, b2, c, offset_r )
 local x1 = cx + (b1.r + offset_r) * cos( b1.a )
 local y1 = cy + (b1.r + offset_r) * sin( b1.a ) 
 local x2 = cx + (b2.r + offset_r) * cos( b2.a )
 local y2 = cy + (b2.r + offset_r) * sin( b2.a ) 
 line(x1,y1,x2,y2,c)
end

-------------------------
booms.draw = function()
 for i=1,booms.count do
  local boom = booms[i]
  if boom.active then 
   for j = 2, boom.spikes_count - 1 do
    booms.draw_line(boom.x, boom.y, boom[j], boom[j+1], boom.color, 0 )
   end
   
   if boom.orient == 4 then
    booms.draw_line(boom.x, boom.y, boom[boom.spikes_count], boom[1], boom.color, 0 )
    booms.draw_line(boom.x, boom.y, boom[1], boom[2], boom.color, 0 )
   end
  end
 end
end

-----------------
-- trail
-----------------
trail = {}
trail.max_count = 12
trail.next = 1
trail.spawn_time = 0

for i=1,trail.max_count do
 add(trail, {x=-1,y=-1,spr=-1,flip=false} )
end

-----------------
trail.init = function()
 for i=1,trail.max_count do
  trail[i].x=-1
  trail[i].y=-1
  trail[i].spr=-1
  trail[i].flip=false
 end 
end

-----------------
trail.update = function(nx,ny,spr,flip)
 trail.spawn_time += one_frame

 if trail.spawn_time > 0.08 then
  trail.spawn_time = 0
 
  local node = trail[trail.next]
  node.x = nx
  node.y = ny
  node.spr = spr
  node.flip = flip
 
  trail.next += 1
 
  if trail.next > trail.max_count then
   trail.next = 1
  end
 end
end

-----------------
trail.draw = function()
 local colors={1,5,13,6}
 local trail_count = -1
 
 local pre_index = (trail.next-1 == 0) and (trail.max_count) or (trail.next-1)
 local pre_x = trail[pre_index].x
 local pre_y = trail[pre_index].y
 

 for i = trail.next, trail.max_count do
  trail_count += 1
  if trail[i].x == -1 then
   break
  end
  
  local color = colors[1+flr(#colors*trail_count/trail.max_count)]
  
  for i=1,15 do
   pal( i, color )
  end
  
  spr( trail[i].spr, trail[i].x, trail[i].y, 1, 1, trail[i].flip )
  
  pre_x = trail[i].x
  pre_y = trail[i].y
 end  

 for i = 1, trail.next-1 do
  trail_count += 1
  if trail[i].x == -1 then
   break
  end
  
  local color = colors[1+flr(#colors*trail_count/trail.max_count)]
  
  for i=1,15 do
   pal( i, color )
  end

  spr(trail[i].spr, trail[i].x, trail[i].y, 1, 1, trail[i].flip )
  
  pre_x = trail[i].x
  pre_y = trail[i].y
 end
 
 pal()
end

-----------------
-- collision
-----------------
function solid_floor( x, y )
 local val = mget(flr(x/8), flr(y/8))
 return fget(val, 0)
end

function solid_ceiling( x, y )
 local val = mget(flr(x/8), flr(y/8))
 return fget(val, 2)
end

function solid_lwall( x, y )
 local val = mget(flr(x/8), flr(y/8))
 return fget(val, 3)
end

function solid_rwall( x, y )
 local val = mget(flr(x/8), flr(y/8))
 return fget(val, 1)
end

-- test if a point is solid
function collision_checks( x, y, vx, vy )
 -- walk a pixel at a time until found collision
 
 local new_x = x
 local new_y = y
 
 local on_floor = false
 local on_ceiling = false
 local on_lwall = false
 local on_rwall = false
 
 local nvx, nvy, vel_mag = normalizewithmag( vx, vy )
 
 local keep_looking = true
 
 while keep_looking do
  local temp_x = new_x
  local temp_y = new_y
  
  if vel_mag > 0 then
   local i_vx = (vel_mag >= 1) and nvx or (vel_mag*nvx) 
   local i_vy = (vel_mag >= 1) and nvy or (vel_mag*nvy)
    
    if not on_floor and not on_ceiling then
     if i_vy > 0 then
      -- check floor
      if solid_floor( new_x+1, new_y+7 + i_vy ) and not solid_floor( new_x+1, new_y+7 ) or 
         solid_floor( new_x+7, new_y+7 + i_vy ) and not solid_floor( new_x+7, new_y+7 ) then
       on_floor = true
       temp_y = flr(temp_y)
       nvy = 0
       i_vy = 0
      end
     elseif i_vy < 0 then
      -- check ceiling
      if solid_ceiling( new_x+1, new_y + i_vy ) and not solid_ceiling( new_x+1, new_y ) or
         solid_ceiling( new_x+7, new_y + i_vy ) and not solid_ceiling( new_x+7, new_y ) then
       on_ceiling = true
       temp_y = -flr(-temp_y)
       nvy = 0
       i_vy = 0
      end
     end
    end
    
    if not on_rwall and not on_lwall then
     if i_vx > 0 then
      -- check rwall
      if solid_rwall( new_x+7 + i_vx, new_y+1 ) and not solid_rwall( new_x+7, new_y+1 ) or
         solid_rwall( new_x+7 + i_vx, new_y+7 ) and not solid_rwall( new_x+7, new_y+7 ) then
       on_rwall = true
       temp_x = flr(temp_x)
       nvx = 0
       i_vx = 0
      end
     elseif i_vx < 0 then
      -- check lwall
      if solid_lwall( new_x + i_vx, new_y+1 ) and not solid_lwall( new_x, new_y+1 ) or
         solid_lwall( new_x + i_vx, new_y+7 ) and not solid_lwall( new_x, new_y+7 ) then
       on_lwall = true
       temp_x = -flr(-temp_x)
       nvx = 0
       i_vx = 0
      end
     end
    end
    
    if not on_floor and not on_ceiling and not on_lwall and not on_rwall then
    if not on_floor and not on_ceiling then
     if i_vy > 0 then
      -- check floor
      if solid_floor( new_x+1 + i_vx, new_y+7 + i_vy ) and not solid_floor( new_x+1, new_y+7 ) or 
         solid_floor( new_x+7 + i_vx, new_y+7 + i_vy ) and not solid_floor( new_x+7, new_y+7 ) then
       on_floor = true
       temp_y = flr(temp_y)
       nvy = 0
       i_vy = 0
      end
     elseif i_vy < 0 then
      -- check ceiling
      if solid_ceiling( new_x+1 + i_vx, new_y + i_vy ) and not solid_ceiling( new_x+1, new_y ) or
         solid_ceiling( new_x+7 + i_vx, new_y + i_vy ) and not solid_ceiling( new_x+7, new_y ) then
       on_ceiling = true
       temp_y = -flr(-temp_y)
       nvy = 0
       i_vy = 0
      end
     end
    end
    
    if not on_rwall and not on_lwall then
     if i_vx > 0 then
      -- check rwall
      if solid_rwall( new_x+7 + i_vx, new_y+1 + i_vy ) and not solid_rwall( new_x+7, new_y+1 ) or
         solid_rwall( new_x+7 + i_vx, new_y+7 + i_vy ) and not solid_rwall( new_x+7, new_y+7 ) then
       on_rwall = true
       temp_x = flr(temp_x)
       nvx = 0
       i_vx = 0
      end
     elseif i_vx < 0 then
      -- check lwall
      if solid_lwall( new_x + i_vx, new_y+1 + i_vy ) and not solid_lwall( new_x, new_y+1 ) or
         solid_lwall( new_x + i_vx, new_y+7 + i_vy ) and not solid_lwall( new_x, new_y+7 ) then
       on_lwall = true
       temp_x = -flr(-temp_x)
       nvx = 0
       i_vx = 0
      end
     end
    end
    end
    
    if not on_floor and not on_ceiling then
     temp_y += i_vy
    end
  
    if not on_rwall and not on_lwall then
     temp_x += i_vx
    end    
  
    vel_mag -= 1
  else
   keep_looking = false
  end

  new_x = temp_x
  new_y = temp_y
 end
 
 return { x=new_x, y=new_y, floor=on_floor, lwall=on_lwall, rwall=on_rwall }
end

------------------
-- player
------------------
player={}

player.dude_anims ={}
player.girl_anims = {}
player.dog_anims = {}
player.mouse_anims = {}
player.car_anims = {}
player.alien_anims = {}
player.slime_anims = {}

-- dude
player.dude_anims.set_index = 1
player.dude_anims.run_anim={9,9,1,1,2,2,3,3,4,4,5,5}
player.dude_anims.start_anim={8,8}
player.dude_anims.launch_anim={8,8}
player.dude_anims.land_anim={8,8}
player.dude_anims.wall_slide_anim={6,6,6,6,6,6,7,7}
player.dude_anims.wall_launch_anim={7,7}
player.dude_anims.cheer_anim={9,9,9,9,9,9,8,8,8,8,8,8}
player.dude_anims.target_anims = player.girl_anims
player.dude_anims.starget_anims = player.mouse_anims
player.dude_anims.objective_text = "find the girl!"
player.dude_anims.win_text = "dude found girl"
player.dude_anims.swin_text = "found secret mouse"

-- girl
player.girl_anims.set_index = 2
player.girl_anims.run_anim={16,16,17,17,18,18,19,19,20,20,21,21}
player.girl_anims.start_anim={24,24}
player.girl_anims.launch_anim={24,24}
player.girl_anims.land_anim={24,24}
player.girl_anims.wall_slide_anim={22,22,22,22,22,22,23,23}
player.girl_anims.wall_launch_anim={23,23}
player.girl_anims.cheer_anim={16,16,16,16,16,16,24,24,24,24,24,24}
player.girl_anims.target_anims = player.dog_anims
player.girl_anims.starget_anims = player.slime_anims
player.girl_anims.objective_text = "get the doggy!"
player.girl_anims.win_text = "girl rescued the doggy"
player.girl_anims.swin_text = "found a secret slime"

-- doge
player.dog_anims.set_index = 3
player.dog_anims.run_anim={32,32,33,33,34,34,35,35,36,36,37,37}
player.dog_anims.start_anim={40,40}
player.dog_anims.launch_anim={40,40}
player.dog_anims.land_anim={40,40}
player.dog_anims.wall_slide_anim={38,38,38,38,38,38,39,39}
player.dog_anims.wall_launch_anim={39,39}
player.dog_anims.cheer_anim={32,32,32,32,32,32,40,40,40,40,40,40}
player.dog_anims.target_anims = player.mouse_anims
player.dog_anims.starget_anims = player.alien_anims
player.dog_anims.objective_text = "find the mouse!"
player.dog_anims.win_text = "dog found the mouse"
player.dog_anims.swin_text = "found the secret alien"

-- mouse
player.mouse_anims.set_index = 4
player.mouse_anims.run_anim={48,48,49,49,50,50,51,51,52,52,53,53}
player.mouse_anims.start_anim={56,56}
player.mouse_anims.launch_anim={56,56}
player.mouse_anims.land_anim={56,56}
player.mouse_anims.wall_slide_anim={54,54,54,54,54,54,55,55}
player.mouse_anims.wall_launch_anim={55,55}
player.mouse_anims.cheer_anim={48,48,48,48,48,48,56,56,56,56,56,56}
player.mouse_anims.target_anims = player.car_anims
player.mouse_anims.starget_anims = player.dude_anims
player.mouse_anims.objective_text = "find the car!"
player.mouse_anims.win_text = "mouse found a car"
player.mouse_anims.swin_text = "found a secret dude"

-- car
player.car_anims.set_index = 5
player.car_anims.run_anim={25,25,26,26,25,25,26,26,25,25,26,26}
player.car_anims.start_anim={26,26}
player.car_anims.launch_anim={26,26}
player.car_anims.land_anim={26,26}
player.car_anims.wall_slide_anim={27,27,27,27,27,27,28,28}
player.car_anims.wall_launch_anim={28,28}
player.car_anims.cheer_anim={25,25,25,25,25,25,26,26,26,26,26,26}
player.car_anims.target_anims = player.alien_anims
player.car_anims.starget_anims = player.dog_anims
player.car_anims.objective_text = "find the alien!"
player.car_anims.win_text = "car found a alien"
player.car_anims.swin_text = "found a secret dog"

-- alien
player.alien_anims.set_index = 6
player.alien_anims.run_anim={41,41,42,42,41,41,42,42,41,41,42,42}
player.alien_anims.start_anim={42,42}
player.alien_anims.launch_anim={42,42}
player.alien_anims.land_anim={42,42}
player.alien_anims.wall_slide_anim={43,43,43,43,43,43,44,44}
player.alien_anims.wall_launch_anim={44,44}
player.alien_anims.cheer_anim={41,41,41,41,41,41,42,42,42,42,42,42}
player.alien_anims.target_anims = player.slime_anims
player.alien_anims.starget_anims = player.girl_anims
player.alien_anims.objective_text = "find the slime!"
player.alien_anims.win_text = "alien found a slime"
player.alien_anims.swin_text = "found a secret girl"

-- slime
player.slime_anims.set_index = 7
player.slime_anims.run_anim={57,57,58,58,57,57,58,58,57,57,58,58}
player.slime_anims.start_anim={58,58}
player.slime_anims.launch_anim={58,58}
player.slime_anims.land_anim={58,58}
player.slime_anims.wall_slide_anim={59,59,59,59,59,59,60,60}
player.slime_anims.wall_launch_anim={60,60}
player.slime_anims.cheer_anim={57,57,57,57,57,57,58,58,58,58,58,58}
player.slime_anims.target_anims = player.dude_anims
player.slime_anims.starget_anims = player.car_anims
player.slime_anims.objective_text = "find the dude!"
player.slime_anims.win_text = "slime found a dude"
player.slime_anims.swin_text = "found a secret car"

player.anim_sets = {
 player.dude_anims,
 player.girl_anims,
 player.dog_anims,
 player.mouse_anims,
 player.car_anims,
 player.alien_anims,
 player.slime_anims,
}

player.max_best_time = 99*60 + 99

player.best_times = {
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
}

player.gold_scores = 
{
 43,
 41,
 41,
 17,
 15,
 42,
 17,
}

player.sbest_times = {
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
 player.max_best_time,
}

player.sgold_scores = 
{
 110,
  80,
  40,
  40,
  25,
  25,
  35,
}

player.locked_status = {
 false,
 true,
 true,
 true,
 true,
 true,
 true,
}

-----------------
player.anim_set = player.dude_anims
player.anim = player.anim_set.start_anim
player.anim_index=1
player.anim_flip=false
player.anim_loops=true
player.x = 3*8
player.y = 3*8
player.max_vx = 2
player.vx = 0
player.vy = 0
player.gravity = .4
player.max_vy = 4
player.start_timer = 4
player.start_timer_beeps = 4
player.running_time = 0
player.air_time = 10

player.has_target = false
player.target_found = false
player.target_found_time = 0
player.target_found_after_time = 0
player.target_found_boom_time = 0
player.target_x=-1
player.target_y=-1

player.has_starget = false
player.starget_found = false
player.starget_found = false
player.starget_found_time = 0
player.starget_found_after_time = 0
player.starget_found_boom_time = 0
player.starget_x=-1
player.starget_y=-1

player.last_found = -1
player.just_unlocked = false
player.just_beat_record = false

player.debug_teleports={6,22,38,54,27,43,59}
player.debug_teleport_next = 2

----------------
player.init = function()
 player.anim_index=1
 player.anim_flip=false
 player.anim_loops=true
 player.x = 3*8
 player.y = 3*8
 player.max_vx = 2
 player.vx = 0
 player.vy = 0
 player.gravity = .4
 player.max_vy = 4
 player.start_timer = 4
 player.start_timer_beeps = 4
 player.running_time = 0
 player.air_time = max_running_time

 player.has_target = false
 player.target_found = false
 player.target_found_time = 0
 player.target_found_after_time = 0
 player.target_found_boom_time = 0
 player.target_x=-1
 player.target_y=-1
 
 player.has_starget = false
 player.starget_found = false
 player.starget_found_time = 0
 player.starget_found_after_time = 0
 player.starget_found_boom_time = 0
 player.starget_x=-1
 player.starget_y=-1
 
 player.just_unlocked = false
 player.just_beat_record = false
end

----------------
player.teleport = function()
 local found_teleport = false

 while not found_teleport do
  for i=0,16*8 do
   for j=0,16*4 do
    local map_tile = mget( i, j )
    local flags = fget( map_tile )
    if flags == 0x80 then
     if map_tile == player.debug_teleports[player.debug_teleport_next] then
 	  found_teleport = true
	 
      player.x = i*8
	  player.y = j*8
	 
	  player.debug_teleport_next += 1
	 
	  if player.debug_teleport_next > #player.debug_teleports then
	   player.debug_teleport_next = 1
	  end
	  
	  break
	 end
    end
   end
   
   if found_teleport then
    break
   end
   
  end
 
  if not found_teleport then
   player.debug_teleport_next = 1
  end
 end
end

---------------
player.find_target = function()
 player.has_target = false

 for i=0,16*8 do
  for j=0,16*4 do
   local map_tile = mget( i, j )
    
   if map_tile == player.anim_set.target_anims.cheer_anim[1] then
    player.has_target = true
	 
    player.target_x = i*8 + 4
	player.target_y = j*8 + 4
    break
   end
  end
   
  if player.has_target then
   break
  end
   
 end
end

---------------
player.find_starget = function()
 player.has_starget = false

 for i=0,16*8 do
  for j=0,16*4 do
   local map_tile = mget( i, j )
    
   if map_tile == player.anim_set.starget_anims.cheer_anim[1] then
    player.has_starget = true
	 
    player.starget_x = i*8 + 4
	player.starget_y = j*8 + 4
    break
   end
  end
   
  if player.has_starget then
   break
  end
   
 end
end

---------------
player.find_start = function()
 player.x = 3*8
 player.y = 3*8
 
 local found = false
 
 for i=0,16*8 do
  for j=0,16*4 do
   local map_tile = mget( i, j )
    
   if map_tile == player.anim_set.start_anim[1] then
    player.x = i*8
	player.y = j*8
    
    found = true
    break
   end
  end
   
  if found then
   break
  end
   
 end
end

---------------
player.check_target = function()
 if player.x > player.target_x+4 or
    player.y > player.target_y+4 or
    player.x+8 < player.target_x-4 or
    player.y+8 < player.target_y-4 then
 else
  player.target_found = true
  player.target_found_time = player.running_time
  music(40)
  
  if player.target_found_time < player.best_times[title_screen.selected] then
   -- record broken!
   player.best_times[title_screen.selected] = player.target_found_time
   player.just_beat_record = true
   
   -- save best time
   dset( title_screen.selected, player.best_times[title_screen.selected] )

  end
  
  if player.x+4 > player.target_x then
   player.x = player.target_x+5
   player.anim_flip = true
  else
   player.x = player.target_x-13
   player.anim_flip = false
  end
  
  player.y = player.target_y-4

  player.set_anim( player.anim_set.cheer_anim, true, player.anim_flip )
  player.vx = 0
  player.vy = 0
    
 end
end


---------------
player.check_starget = function()
 if player.x > player.starget_x+4 or
    player.y > player.starget_y+4 or
    player.x+8 < player.starget_x-4 or
    player.y+8 < player.starget_y-4 then
 else
  player.starget_found = true
  player.starget_found_time = player.running_time
  music(40)
  
  if player.starget_found_time < player.sbest_times[title_screen.selected] then
   -- record broken!
   player.sbest_times[title_screen.selected] = player.starget_found_time
   player.just_beat_record = true
   
   -- save best time
   dset( #player.best_times + title_screen.selected, player.sbest_times[title_screen.selected] )

  end
  
  if player.x+4 > player.starget_x then
   player.x = player.starget_x+5
   player.anim_flip = true
  else
   player.x = player.starget_x-13
   player.anim_flip = false
  end
  
  player.y = player.starget_y-4

  player.set_anim( player.anim_set.cheer_anim, true, player.anim_flip )
  player.vx = 0
  player.vy = 0
    
 end
end

---------------
player.anim_end_callback = function()
 if player.anim == player.anim_set.launch_anim or
    player.anim == player.anim_set.wall_launch_anim then
  player.vy = -4.55
  player.vx = player.anim_flip and -player.max_vx or player.max_vx
  player.gravity = .4
  player.max_vy = 4
 end
end

---------------
player.set_anim = function( anim, loops, flips )
 if player.anim != anim then
  player.anim = anim
  player.anim_index = 1
 end
 
 player.anim_loops = loops
 player.anim_flip = flips
end

---------------
player.anim_advance = function()
 player.anim_index += 1
 
 if player.anim_index >= #player.anim+1 then
  player.anim_index = 1
  
  player.anim_end_callback()
  
  if not player.anim_loops then
   player.set_anim( player.anim_set.run_anim, true, sgn(player.vx) != 1 )
  end
 end
end

---------------
player.update = function()
 
 local new_x = player.x + player.vx
 local new_y = player.y + player.vy
 
 local collision_result = collision_checks( player.x, player.y, player.vx, player.vy )
 local colision_x = collision_result.x
 local colision_y = collision_result.y
 
 player.x = colision_x
 player.y = colision_y
 
 player.anim_advance()
 
 if player.start_timer > 0 then
  player.start_timer -= one_frame
  
  if player.start_timer > 3 then
   if player.start_timer_beeps == 4 then
    player.start_timer_beeps -= 1
    sfx(2)
   end
  elseif player.start_timer > 2 then
   if player.start_timer_beeps == 3 then
    player.start_timer_beeps -= 1
    sfx(2)
   end
  elseif player.start_timer > 1 then
   if player.start_timer_beeps == 2 then
    player.start_timer_beeps -= 1
    sfx(2)
   end
  elseif player.start_timer > 0 then
   if player.start_timer_beeps == 1 then
    player.start_timer_beeps -= 1
    sfx(3)
   end
  end  
  
 end
 
 if player.start_timer > 1 then
 elseif player.running_time == 0 and player.start_timer <= 1 then
  -- start running
  music(0)
  
  player.running_time = one_frame
  player.set_anim( player.anim_set.run_anim, true, player.anim_flip )
  player.vx = player.max_vx
  
 elseif not player.target_found and not player.starget_found then

  player.air_time += one_frame
  
  if player.air_time > max_running_time then
   player.air_time = max_running_time
  end
  
  player.running_time += one_frame

  if player.running_time > max_running_time then
   player.running_time = max_running_time
  end
  
  if not collision_result.floor then
   player.vy += player.gravity
  
   if player.vy > player.max_vy then
    player.vy = player.max_vy
   end
  else
   player.vy = 0
  end
 
  -- debug teleport player
  --if btnp(4) then
  -- player.teleport()
  --end
 
  if collision_result.rwall then
    if collision_result.floor then
     -- if we hit the wall on the floor, flip around quickly
     player.anim_flip = not player.anim_flip
     player.vx = player.anim_flip and -player.max_vx or player.max_vx
     player.max_vy = 4
    elseif player.vx >= 0 then
     -- if we hit the wall in the air, slide down the wall slowly
     player.max_vy = 2
     player.set_anim( player.anim_set.wall_slide_anim, true, player.anim_flip )
    end
  elseif collision_result.lwall then
    if collision_result.floor then
     -- if we hit the wall on the floor, flip around quickly
     player.anim_flip = not player.anim_flip
     player.vx = player.anim_flip and -player.max_vx or player.max_vx
     player.max_vy = 4
    elseif player.vx <= 0 then
     -- if we hit the wall in the air, slide down the wall slowly
     player.max_vy = 2
     player.set_anim( player.anim_set.wall_slide_anim, true, player.anim_flip )
    end
  else
   -- not on walls, reset max velocity on y (terminal velocity)
   player.max_vy = 4
  
   if player.anim != player.anim_set.run_anim and
      player.anim != player.anim_set.launch_anim and
      player.anim != player.anim_set.wall_launch_anim then
    player.set_anim( player.anim_set.run_anim, true, player.anim_flip )
   end
  end
 
  if collision_result.floor or 
     collision_result.rwall or 
     collision_result.lwall then
   player.air_time = 0
  end

  if player.air_time < 0.1 then  
   if time_since_press < 0.2 then
     -- fixed jump
     sfx(0)
     
     local orient = 0
     
     if collision_result.floor then
      booms.spawn( player.x+4, player.y+8, 7, 0, 20 )
     elseif collision_result.rwall then
      booms.spawn( player.x+8, player.y+4, 7, 1, 20 )
     elseif collision_result.lwall then
      booms.spawn( player.x, player.y+4, 7, 3, 20 )
     else
      booms.spawn( player.x+4, player.y+8, 7, 0, 20 )
     end
     
     player.vx = 0
     player.vy = 0
     player.gravity = 0
     
     button_consume()
     player.air_time = max_running_time
  
     if collision_result.rwall or collision_result.lwall then
      -- wall jump
      player.set_anim( player.anim_set.wall_launch_anim, false, not player.anim_flip )
     else
      -- regular jump
      player.set_anim( player.anim_set.launch_anim, false, player.anim_flip )
     end
  
   end
  end
  
  if player.has_target then 
   player.check_target()
  end
 
  if player.has_starget then 
   player.check_starget()
  end
  
 else -- target found
  if player.target_found then
   if player.target_found_boom_time <= 0 then
    booms.spawn( 0.5*(player.x+4+player.target_x), player.y+4, 10, 4, 30 )
    player.target_found_boom_time = 0.4
   end
  
   player.target_found_boom_time -= one_frame
   player.target_found_after_time += one_frame
  
   player.last_found = player.anim_set.target_anims.set_index
  
   if player.locked_status[player.anim_set.target_anims.set_index] then
    player.just_unlocked = true
   
    -- save unlocked status
    dset( #player.best_times + #player.sbest_times + player.anim_set.target_anims.set_index, 1 )
   
   end
  
   player.locked_status[player.anim_set.target_anims.set_index] = false
  else
   if player.starget_found_boom_time <= 0 then
    booms.spawn( 0.5*(player.x+4+player.starget_x), player.y+4, 10, 4, 30 )
    player.starget_found_boom_time = 0.4
   end
  
   player.starget_found_boom_time -= one_frame
   player.starget_found_after_time += one_frame
  
   player.last_found = player.anim_set.starget_anims.set_index
  
   if player.locked_status[player.anim_set.starget_anims.set_index] then
    player.just_unlocked = true
   
    -- save unlocked status
    dset( #player.best_times + #player.sbest_times + player.anim_set.starget_anims.set_index, 1 )
   
   end
  
   player.locked_status[player.anim_set.starget_anims.set_index] = false
  end
 end
end

---------------------
player.draw_target = function()
 if player.has_target then
 
  local target_anim_flip = (player.target_x > player.x )
  
  if not player.target_found then
   player.draw_char_sprite( player.anim_set.target_anims.launch_anim[1], player.target_x-4, player.target_y-4, target_anim_flip )
  else
   local anim_len = #player.anim_set.target_anims.cheer_anim
   local target_anim_index = 1 + (player.anim_index + anim_len/2 ) % anim_len 
   player.draw_char_sprite( player.anim_set.target_anims.cheer_anim[target_anim_index], player.target_x-4, player.target_y-4, target_anim_flip )
   
   print_outline( player.anim_set.win_text, cam.x + 64, cam.y + 32, 7, 1 )
   
   print_outline( "in "..time_to_text(player.target_found_time), cam.x + 64, cam.y + 39, 7, 1 )
   
   if player.just_beat_record then
    print_outline( "new record!", cam.x + 64, cam.y + 84, 8 + sin(t), 1 )
   end
   
   if player.just_unlocked then
    print_outline( "new character unlocked!", cam.x + 64, cam.y + 91, 8 + sin(t), 1 )
   end
  end
  
  local cam_bounds_check = (player.target_x+4) >= (cam.x) and
                           (player.target_x-4) <= (cam.x + 127) and
                           (player.target_y+4) >= (cam.y) and
                           (player.target_y-4) <= (cam.y + 127)
  
  if not cam_bounds_check then
   local player_cx = player.x + 4
   local player_cy = player.y + 4
  
   local dist_x = (player.target_x - player_cx)/100
   local dist_y = (player.target_y - player_cy)/100
   
   local nx, ny, dist_mag = normalizewithmag( dist_x, dist_y )

   local to_edge_x = -1
   local to_edge_y = -1   
   
    if nx >= 0 then
     to_edge_x = ((cam.x + 127) - player_cx)/nx
    else
     to_edge_x = (cam.x - player_cx)/nx
    end

    if ny >= 0 then
     to_edge_y = ((cam.y + 127) - player_cy)/ny
    else
     to_edge_y = (cam.y - player_cy)/ny
    end
   
    local to_edge = (abs(to_edge_x) <= abs(to_edge_y)) and to_edge_x or to_edge_y

    local edge_x = player_cx + to_edge*nx
    local edge_y = player_cy + to_edge*ny
    
    arrow.x = flr(edge_x)
    arrow.y = flr(edge_y)
    
    arrow.nx = nx
    arrow.ny = -ny
    arrow.scale = dist_mag*0.4

    arrow.draw()
  end
 end
end

---------------------
player.draw_starget = function()
 if player.has_starget then
 
  local target_anim_flip = (player.starget_x > player.x )
  
  if not player.starget_found then
   player.draw_char_sprite( player.anim_set.starget_anims.launch_anim[1], player.starget_x-4, player.starget_y-4, target_anim_flip )
  else
   local anim_len = #player.anim_set.starget_anims.cheer_anim
   local target_anim_index = 1 + (player.anim_index + anim_len/2 ) % anim_len 
   player.draw_char_sprite( player.anim_set.starget_anims.cheer_anim[target_anim_index], player.starget_x-4, player.starget_y-4, target_anim_flip )
   
   print_outline( player.anim_set.swin_text, cam.x + 64, cam.y + 32, 7, 1 )
   
   print_outline( "in "..time_to_text(player.starget_found_time), cam.x + 64, cam.y + 39, 7, 1 )
   
   if player.just_beat_record then
    print_outline( "new record!", cam.x + 64, cam.y + 84, 8 + sin(t), 1 )
   end
   
   if player.just_unlocked then
    print_outline( "new character unlocked!", cam.x + 64, cam.y + 91, 8 + sin(t), 1 )
   end
  end
 end
end

---------------------
player.draw_char_sprite = function( sprite, x, y, anim_flip )
 for i=1,15 do
  pal( i, 0 )
 end

 spr( sprite, x+1, y, 1, 1, anim_flip )
 spr( sprite, x-1, y, 1, 1, anim_flip )
 spr( sprite, x, y+1, 1, 1, anim_flip )
 spr( sprite, x, y-1, 1, 1, anim_flip )
 
 spr( sprite, x+1, y+1, 1, 1, anim_flip )
 spr( sprite, x-1, y-1, 1, 1, anim_flip )
 spr( sprite, x-1, y+1, 1, 1, anim_flip )
 spr( sprite, x+1, y-1, 1, 1, anim_flip )
 
 pal()
 spr( sprite, x, y, 1, 1, anim_flip )
 --rect( x, y, x+7, y+7, 7)
end
 
---------------------
player.draw_find_text = function( delta, text )
   local offset = ease_out( max( 0, 1 - 10*delta ), 0, 64 + #text*4, 1 )
   local x = cam.x + 64 + offset
   print_outline( text, x, cam.y + 88, 7, 1 )
end

---------------------
player.draw_start_bubble = function( delta, text, size, color )
 local radius = ease_out( 1-delta, 1, size, 1 )
 local offset = ease_out( max( 0, 1 - 1.8*delta ), 0, 64 + size*2, 1 )
 local x = cam.x + 64 + offset
 circfill( x - 1, cam.y + 82, radius, color )
 circ( x - 1, cam.y + 82, radius, 1 )
 print_outline( text, x, cam.y + 80, 7, 1 )
end

---------------------
player.draw = function( delta, text )
 local sprite = player.anim[flr(player.anim_index)]
 
 player.draw_char_sprite( sprite, player.x, player.y, player.anim_flip )
 
 player.draw_target()
 player.draw_starget()
 
 if player.start_timer > 0 then
  if player.start_timer > 3 then
   local delta = player.start_timer - 3
   player.draw_start_bubble( delta, "3", 8, 8 )
  elseif player.start_timer > 2 then
   local delta = player.start_timer - 2
   player.draw_start_bubble( delta, "2", 9, 8 )
  elseif player.start_timer > 1 then
   local delta = player.start_timer - 1
   player.draw_start_bubble( delta, "1", 10, 8 )
  elseif player.start_timer > 0 then
   local delta = player.start_timer
   player.draw_start_bubble( delta, "go!", 16, 11 )
  end
  
  
  local delta = player.start_timer
  player.draw_find_text( delta/4, player.anim_set.objective_text )
  
 end
 
end


---------------------
-- camera
---------------------
cam = {}
cam.x = 0
cam.y = 0
cam.max_x = 8*16*7 -- 8 full screens
cam.max_y = 8*16*3 -- 4 full screens
cam.border = 48

---------------------
cam.init = function()
 cam.x = 0
 cam.y = 0
end

---------------------
cam.snap = function()
 cam.x = player.x + 4 - 64
 cam.y = player.y + 4 - 64

 cam.x = max( 0, min( cam.x, cam.max_x ) )
 cam.y = max( 0, min( cam.y, cam.max_y ) ) 
end

---------------------
cam.update = function()
 if player.x > cam.x + 128-cam.border-8 then
  cam.x += .3* ( player.x - (cam.x + 128-cam.border-8) )
 elseif player.x < cam.x + cam.border then
  cam.x -= .3* ( cam.x + cam.border - player.x )
 end
 
 if player.y > cam.y + 128-cam.border-8 then
  cam.y += .3* ( player.y - (cam.y + 128-cam.border-8) )
 elseif player.y < cam.y + cam.border then
  cam.y -= .3* ( cam.y + cam.border - player.y )
 end
 
 cam.x = max( 0, min( cam.x, cam.max_x ) )
 cam.y = max( 0, min( cam.y, cam.max_y ) )
end


---------------------
-- title_screen
---------------------
title_screen ={}
title_screen.active = true
title_screen.anim_index = 1
title_screen.selected = 1
title_screen.text = scan_text("cave runners!")
title_screen.title_offsetx = 0

---------------------
title_screen.init = function()
 title_screen.active = true
 music(20)
 title_screen.anim_index = 1
 title_screen.selected = 1
 
 if player.last_found != -1 then
  title_screen.selected = player.last_found
 end
 
 title_screen.title_offsetx = 0
end

---------------------
title_screen.start_level = function()
 views.set_current( game_view, 0.25, 0.5 )
end

---------------------
title_screen.update = function()
 
 if time_since_release < 0.1 then

  sfx(0)
  button_consume()
  
  title_screen.selected += 1

  if title_screen.selected > #player.anim_sets then
   title_screen.selected = 1
  end
  
  local locked = player.locked_status[title_screen.selected]
  
  while locked do
   title_screen.selected += 1
   
   if title_screen.selected > #player.anim_sets then
    title_screen.selected = 1
   end
   
   locked = player.locked_status[title_screen.selected]
  end
  
 end
 
 if time_held >= 1.2 then
  title_screen.start_level()
 end

 title_screen.title_offsetx = 0
 
 if t <= 1 then
  title_screen.title_offsetx = ease_out( t, -256, 256, 1 )
 end 
 
end

---------------------
title_screen.draw = function()
 local title_height = 16

 -- main title
 local colors={1,5,13,6,7}
 for i=1, #colors do
  print_scaled( title_screen.text, title_screen.title_offsetx + 2 + i*5, 5 + (2 + 2*i/#colors)*sin(i/#colors + 2*t), 96, title_height, colors[i] )
 end
 
 print_outline_scaled( title_screen.text, title_screen.title_offsetx + 2 + #colors*5, 5 + 4*sin(1 + 2*t), 96, title_height, 7, 1 )

 -- character selection section
 title_screen.anim_index+=1
 
 if title_screen.anim_index > #player.anim_sets[1].run_anim then
  title_screen.anim_index = 1
 end

 local offsetx = 4 + min(90, time_held*90)
 local anim_i = title_screen.anim_index
 for i=#colors,1,-1 do
  anim_i += 1

  if anim_i > #player.anim_sets[1].run_anim then
   anim_i = 1
  end  
  
  local sprite = player.anim_sets[title_screen.selected].run_anim[anim_i]
  
  for c=1,15 do
   pal( c, colors[#colors - i + 1] )
  end
  
  local offx_multiplier = 2 + title_screen.selected*0.1
  
  -- draw the trials
  spr( sprite, title_screen.title_offsetx*offx_multiplier + 58 + offsetx - i*4, 28 + title_screen.selected*10 )
 end
 
 pal()
 
 local one_secret_found = false
 local one_score_set = false
 
 local total_best = 0
 local worst_medal = 1
 local show_total = true
 
 local total_sbest = 0
 local sworst_medal = 0
 local show_stotal = true
 
 local medal_sprites = { 10,11,12,13 }
 local medal_colors = { 10,7,9,6 }
 
 -- draw selectable chars on the title screen
 for i=1,#player.anim_sets do
  local locked = player.locked_status[i]
  
  if not locked then
  
   -- draw some floor tiles
   for j=-1,16 do 
    spr( 100, j*8 + (t*80)%8, 36 + i*10 )
   end
  
   local offsetx = 0
   local best_score_offset = 0
   local best_score_color = 6
   local sbest_score_color = 6
  
   if title_screen.selected == i then 
    offsetx = 4 + min(90, time_held*90 ) 
    best_score_offset = -4
   else
    if time_held > 0.5 then
     offsetx = -(4 + min(60, (max(0, time_held-0.5)*80 )))
    end
   end
   
   local offx_multiplier = 2 + i*0.4
  
   player.draw_char_sprite( player.anim_sets[i].run_anim[title_screen.anim_index], title_screen.title_offsetx*offx_multiplier + 58 + offsetx, 28 + i*10, false )
  
   if player.best_times[i] < player.max_best_time then
    one_score_set = true
    total_best += player.best_times[i]
    
    local medal_index = 1
    
    local time_offset_x = 0
    if player.best_times[i] <= player.gold_scores[i] then
     time_offset_x = -8
     best_score_color = 10
    elseif player.best_times[i] <= player.gold_scores[i]+5 then
     time_offset_x = -8
     best_score_color = 7
     medal_index = 2
    elseif player.best_times[i] <= player.gold_scores[i]+10 then
     time_offset_x = -8
     best_score_color = 9
     medal_index = 3	 
    else
     medal_index = 4
	end
    
    if worst_medal < medal_index then
	 worst_medal = medal_index
	end
    
    spr( medal_sprites[medal_index], title_screen.title_offsetx*offx_multiplier + 121 + best_score_offset, 30 + i*10 ) -- draw medal
    print_outline( time_to_text(player.best_times[i]), title_screen.title_offsetx*offx_multiplier + 128 + time_offset_x + best_score_offset, 31 + i*10, best_score_color, 1, align_right )
   else
    show_total = false
   end

   if player.sbest_times[i] < player.max_best_time then
    one_secret_found = true
    total_sbest += player.sbest_times[i]
    
    
    local smedal_index = 1
    
    local stime_offset_x = 0
    if player.sbest_times[i] <= player.sgold_scores[i] then
     stime_offset_x = 8
     sbest_score_color = 10
    elseif player.sbest_times[i] <= player.sgold_scores[i]+5 then
     stime_offset_x = 8
     sbest_score_color = 7
     smedal_index = 2
    elseif player.sbest_times[i] <= player.sgold_scores[i]+10 then
     stime_offset_x = 8
     sbest_score_color = 9
     smedal_index = 3	 
    else
     smedal_index = 4
	end
    
    if sworst_medal < smedal_index then
	 sworst_medal = smedal_index
	end
    
    spr( medal_sprites[smedal_index], title_screen.title_offsetx*offx_multiplier - best_score_offset, 30 + i*10 ) -- draw medal
    print_outline( time_to_text(player.sbest_times[i]), title_screen.title_offsetx*offx_multiplier + 1 + stime_offset_x - best_score_offset, 31 + i*10, sbest_score_color, 1, align_left )
   else
    show_stotal = false
   end

  end
 end
 
 local msg_offsetx = 128
 
 if t <= 1 then
  msg_offsetx = ease_out( t, 0, 128, 1 )
 end
 
 if one_secret_found then
  print_outline( "secrets found", title_screen.title_offsetx*1.5 + 1, 30, 6, 1, align_left )
 end
 
 if one_score_set then 
  print_outline( "best times", title_screen.title_offsetx*1.5 + 128, 30, 6, 1, align_right )
 end
 
 print_outline( "tap to select! hold to run!", title_screen.title_offsetx + 64, 23, 7, 1 )
 
 if show_total or show_stotal then
  print_outline( "<total>", title_screen.title_offsetx*5 + 64, 110, 7, 1 )
  
  if show_stotal then
   best_score_offset = 0
   
   if sworst_medal != 4 then
    best_score_offset = 8
    spr( medal_sprites[sworst_medal], title_screen.title_offsetx*5, 109 )
   end
   
   print_outline( time_to_text(total_sbest), title_screen.title_offsetx*5 + 1 + best_score_offset, 110, medal_colors[sworst_medal], 1, align_left )  
  end
  
  if show_total then
   best_score_offset = 0
   
   if worst_medal != 4 then
    best_score_offset = -8
    spr( medal_sprites[worst_medal], title_screen.title_offsetx*5 + 121, 109 )
   end
   
   print_outline( time_to_text(total_best), title_screen.title_offsetx*5 + 128 + best_score_offset, 110, medal_colors[worst_medal], 1, align_right )   
  end
 end
 
 print_outline( "guerragames 2016", title_screen.title_offsetx*6 + 66, 120, 7, 1 )
 
 --rect( 0, 0, 127, 127, 7 )
end

---------------------
-- on-load stuff
---------------------
cartdata( "caverunners" )
poke(0x5f2d, 1) -- enable mouse stuff

menuitem( 1, "restart run \129", title_screen.start_level )

-- load best times
for i=1, #player.best_times do
 local best = dget( i )
 if best > 0 then
  player.best_times[i] = best
 end
end

-- load sbest times
for i=1, #player.sbest_times do
 local best = dget( #player.best_times + i )
 if best > 0 then
  player.sbest_times[i] = best
 end
end

-- load unlocked statuses
for i=2, #player.locked_status do
 player.locked_status[i] = ( dget( #player.best_times + #player.sbest_times + i ) == 0 )
end

---------------------
function _init()

 -- init globals
 t = 0
 time_since_press = 100
 time_since_release = 100
 time_held = 0
 button_held = false
 
 trail.init()
 cam.init()
 player.init()
 title_screen.init()
end

---------------------
function screen_fade_out( fade_out_time, max_fade_out_time )
 local px = {}
 
 local end_x = 128 - 128 * ( fade_out_time / max_fade_out_time )
 
 for j = 0, 128 do
  px[j] = end_x
 end

 for j = 0, 128 do
  local vx = 10 + rnd(50)
   
  px[j] += vx
   
  rectfill( cam.x, cam.y + j, cam.x + px[j], cam.y + j + 1, 0 )
 end

end

---------------------
function screen_fade_in( fade_in_time, max_fade_in_time )
 
 local px = {}
 
 local start_x = 128 - 128 * ( fade_in_time / max_fade_in_time )
 
 for j = 0, 128 do
  px[j] = start_x
 end

 for j = 0, 128 do
  local vx = 10 + rnd(50)
   
  px[j] += vx
   
  rectfill( cam.x + px[j], cam.y + j, cam.x + 128, cam.y + j + 1, 0 )
 end
  
end

---------------------
-- views
---------------------

---------------------
-- front end view
---------------------
front_end_view = {}

---------------------
front_end_view.start = function()
 _init()
end

---------------------
front_end_view.update = function()
 title_screen.update()
 booms.update()
end

---------------------
front_end_view.draw = function()
 camera( 0, 0 )
 title_screen.draw()
  
 --print(time_held, cam.x+1, cam.y+1+6, 7)
end


---------------------
-- game view
---------------------
game_view = {}

---------------------
game_view.start = function()
 t = 0
 time_since_press = 100
 time_since_release = 100
 time_held = 0
 button_held = false

 trail.init()
 cam.init()
 player.init()  

 title_screen.active = false
 music(-1)
  
 player.anim_set = player.anim_sets[title_screen.selected]
  
 player.find_start()
 player.find_target()
 player.find_starget() 
 
 cam.snap()
  
 player.set_anim( player.anim_set.start_anim, true, false )
 player.vx = 0
end

---------------------
game_view.update = function()
 booms.update()
 player.update()
 cam.update()
 trail.update(player.x, player.y, player.anim[flr(player.anim_index)], player.anim_flip )

 if player.target_found_after_time > 1 or player.starget_found_after_time > 1 then
  if time_since_release < 0.2 then
   views.set_current( front_end_view, 0.25, 0.5 )
  end
 end 
end

---------------------
game_view.draw = function()
  camera( cam.x, cam.y )
  map( 0, 0, 0, 0, 16*16, 16*16, 0x10 )
 
  if not player.target_found and not player.starget_found then
   trail.draw()
  end
 
  booms.draw()
  player.draw()
 
  --print(player.x..","..player.y, cam.x+1, cam.y+1+6, 7)
  --print(player.vx..","..player.vy, cam.x+1, cam.y+1+12, 7)

  --print(arrow.scale, cam.x+1, cam.y+1+12, 7)

  
  
  local offset_y = 0
  local timer = 1 - (player.start_timer - 3)
  
  if timer > 0 and timer < 1 then
   offset_y = 7 - ease_out( timer, 0, 7, 1 )
  end
  print_outline("time:"..time_to_text(player.running_time), cam.x+1, cam.y+1-offset_y, 7, 1, align_left )
  print_outline("best:"..time_to_text(player.best_times[title_screen.selected]), cam.x+128, cam.y+1-offset_y, 7, 1, align_right )

  --print( "t:"..player.start_timer, cam.x+1, cam.y+1+18, 7 )
  
  --print( "target:"..player.target_x..","..player.target_y, cam.x+1, cam.y+1+18, 7 )
  --print( nx..","..ny..","..dist_mag, cam.x+1, cam.y+1+24, 7 )
end

----------------

views = {}
views.last_view = nil
views.current_view = front_end_view
views.fade_out_time = 0
views.fade_in_time = 0

---------------
views.set_current = function( new_view, fade_out_time, fade_in_time )
 -- do screen transition management here
 views.max_fade_out_time = fade_out_time
 views.max_fade_in_time = fade_in_time
 views.fade_out_time = fade_out_time
 views.fade_in_time = fade_in_time

 views.last_view = views.current_view
 views.current_view = new_view
end

---------------
views.update = function()
 if views.fade_out_time > 0 and views.last_view then
  --views.last_view.update()
  views.fade_out_time -= one_frame
  
  if views.fade_out_time <= 0 then
   views.current_view.start()
   views.current_view.update()
  end
  
 else
  views.current_view.update()
  
  if views.fade_in_time > 0 then
   views.fade_in_time -= one_frame
  end
 end 
end

---------------
views.draw = function()
 if views.fade_out_time > 0 and views.last_view then
  views.last_view.draw()
  screen_fade_out( views.fade_out_time, views.max_fade_out_time )
 else
  views.current_view.draw()
  
  if views.fade_in_time > 0 then
   screen_fade_in( views.fade_in_time, views.max_fade_in_time )
  end
 end
end

---------------------

function _update()
 t += one_frame
 
 button_update()
 
 views.update()
end

---------------------

function _draw()
 cls()

 views.draw()
 
 --[[
 if title_screen.active then
  front_end_view.draw()
 else
  game_view.draw()
 end
 --]]
end
