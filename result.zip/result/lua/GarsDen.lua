--gar's den
--by trasevol_dog


function _init()
 init_anim_info()
 drk=parse"0=0,0,1,1,2,1,5,13,2,4,9,3,1,1,2,4"
 t,shkx,shky,camx,camy,xmod,ymod=0,0,0,0,0,0,0
 
 if not started then
  music(4)
  darkout()
  darkin()
  repeat
   _draw()
   flip()
   t+=0.01
  until btnp(4)
  started=true
 end
 
 objs=parse[[
to_update={},

hittable={},
collect={},
needtile={},

doors={},
stairs={},
plants={},
enemies={}
]]
 
 for i=0,4 do
  objs["to_draw"..i]={}
 end
 
 music(-1)
 sfx(26)
 darkout()

 init_plants()init_enemies()init_props()init_items()init_inventory()

 curlvl,invcur,levels=1,1,{}
 create_player()
 
 player.x,player.y=generate_level()

 camx,camy,floatxts=player.x,player.y,{}
 
 local tilx,tily=tile(player.x,player.y)
 mset(tilx,tily,16)
 
 for i=-1,1 do
  create_prop(tilx+i*1.5,tily-1.5+abs(i),"bc"..i)
 end
 
 uncover_room(player.x,player.y)
 
 music(0)
 darkin()
 sfx(27)
end

function _update()
 t+=0.01

 camx=lerp(camx,player.x+12*player.vx,0.05)
 camy=lerp(camy,player.y+12*player.vy,0.05)
 
 if player.hp<=0 then
  player.vx,player.vy,player.state,player.animt=0,0,"slash",0
  if btnp(4) and t>0.2 then
   _init()
  end
  
  return
 end

 for txt in all(floatxts) do
  txt.y-=txt.t
  txt.t-=0.1
  if txt.t<0 then
   del(floatxts,txt)
  end
 end
 
 update_shake()
 update_objects()
 
-- if btnp(4,1) then
--  for p in group("plants") do
--   p.t=p.td-1
--  end
-- end
end

function _draw()
 oxmod,oymod,xmod,ymod,ar=xmod,ymod,flr(camx-64+shkx),flr(camy-64+shky),parse"{-1,0},{1,0},{0,-1},{0,1}"

 camera()
 
 vxmod,vymod,texts=xmod-oxmod,ymod-oymod,{}
 for i=0,149 do
  local x,y=rnd128(),rnd128()
  local c=chance(5) and 0 or band(pget(x+3*vxmod,y+3*vymod)+rnd(1.001),1)
  local dif=pick(ar,4)
  circ(x+dif[1],y+dif[2],1,c)
 end
 
 if not started then
  draw_text("trasevol_dog presents",64,4,1,true,1,0)
  spr(202,40,16,6,4)
  circfill(32,56,6,0)
  draw_anim(32,56,"gar","dance",t)
  circfill(96,56,6,0)
  draw_anim(96,56,"player","idle",t,true)
  
  draw_text("🅾️ / z ~ action + slash ",60,72,1,true,13,1)
  draw_text("❎ / x ~ inventory control ",66,82,1,true,13,1)
  draw_text("⬅️➡️⬆️⬇️ ~ move around    ",50,92,1,true,13,1)
  
  draw_text("press 🅾️ / z to start ",64,120)
  
  return
 end
 
 if player.hp<=0 then
  draw_text("you died",64,32)
  local str
  if win then
   str="as a winner"
  else
   str="you didn't defeat gar"
  end
  draw_text(str,64,48)
  draw_text("press 🅾️ / z to try again ",64,96)
  
  camera(xmod,ymod)
  
  player:draw()
  return
 end
 
 palt(0,false)
 draw_room()
 palt(0,true)
 all_colors_to()

 camera(xmod,ymod)
 
 if target then
  spr(226,target[1]*8-1,target[2]*8-1,2,2)
 end

 draw_objects()
 all_colors_to()
 
 palt(0,false)
 
 local amx,amy=tile(xmod,ymod)
 for x=amx,amx+16 do
 for y=amy,amy+16 do
  if peek(0x4300+(y-amy)*17+x-amx)==2 then
   local m=mget(x,y)
   local s=48+(m+x+y)%4
   spr(s,x*8,y*8-4)
  end
 end
 end
 
 palt(0,true)

 for data in all(texts) do
  draw_text(data[1],data[2],data[3],1,true,data[4],data[5])
 end
 
 for txt in all(floatxts) do
  local c1,c2=txt.c1,txt.c2
  if txt.t>1.8 then c1,c2=drk[c1],drk[c2] end
  draw_text(txt.str,txt.x,txt.y,1,true,c1,c2)
 end

 camera()
 draw_inventory()
 
 if win and t<4 then
  draw_text("you win the game!",64,32)
  draw_text("this is your den now!",64,48)
  draw_text("!!! thank you for playing !!!",64,96)
 end
 
 --draw_text(""..stat(1),1,4,0,true)
 --draw_text(""..stat(0),1,12,0,true)
end



function update_player(p)
 update_animt(p)
 
 p.inv=max(p.inv-.01,0)
 
 local movx,movy=0,0
 if btn(5) then
  if btnp(0) then invcur=(invcur-2)%invplaces+1 end
  if btnp(1) then invcur=(invcur)%invplaces+1 end
 else
  if btn(0) then movx-=p.acc p.faceleft=true end
  if btn(1) then movx+=p.acc p.faceleft=false end
  if btn(2) then movy-=p.acc end
  if btn(3) then movy+=p.acc end
 end
 
 target=nil
 local data=inventory[invcur]
 if data[2]>=1 then
  if data[1].target=="tile" then
   local f=data[1].tilef
   
   local x,y
   local check=function() return tile_flag(x,y,f) and (not data[1].tilecheck or data[1].tilecheck(x,y)) end
   
   local list,xmul=parse"{6,0},{-2,0},{0,-6},{0,6}",p.faceleft and -1 or 1
   
   for ofs in all(list) do
    x,y=tile(p.x+xmul*ofs[1],p.y+ofs[2])
    
    if check() then
     target={x,y}
     break
    end
   end
   
  end
 end
 
 if btnp(4) and not player.pressin then
  if data[2]>=1 and (target or not data[1].ntarg) then
   local used=data[1].use and data[1].use(target,data[1].hp)

   if used and data[1].consumable then
    data[2]-=1
   end
  end
  
  sfx(24)
  
  p.state="slash"
  p.animt=0
 end
 
 player.pressin=btn(4)
 
 
 update_movement(p,movx,movy,true)
 
 if p.state=="slash" then
  local step,first=anim_step(p)
  if step==1 and first then
   local hit={x=p.x,y=p.y,h=20,w=14}
   if p.faceleft then hit.x-=6 else hit.x+=6 end
   local list=all_collide_objgroup(hit,"hittable")
   
   for o in all(list) do
    o:hit()
   end
   
   p.vx*=0
   p.vy*=0
  end
 end
 
 
 local tx,ty=tile(p.x,p.y)
 local m=mget(tx,ty)
 if fget(m,7) and not p.staircol then
  sfx(26)
  darkout()
 
  cover_room(p.x,p.y)
  
  local mapdata={}
  for x=0,127 do
  for y=0,31 do
   mapdata[y*128+x]=mget(x,y)
  end
  end
  
  levels[curlvl]={
   map=mapdata
  }
  
  for k,grp in pairs(objs) do
   for o in all(grp) do
    if not o.floor then
     o.floor=curlvl
    end
   end
  end
 
  if m==52 then curlvl+=1
  elseif m==53 then curlvl-=1
  end
  
  local data=levels[curlvl]
  if data then
   mapdata=data.map
   for x=0,127 do
   for y=0,31 do
    local mm=mapdata[y*128+x]
    mset(x,y,mm)
    if (m==52 and mm==53) or (m==53 and mm==52) then
     p.x,p.y=untile(x,y)
    end
   end
   end
  else
   p.x,p.y=generate_level()
  end
  
  if curlvl==4 then
   music(4)
  else
   music(-1)
  end
  
  camx,camy,p.vx,p.vy=p.x,p.y,0,0
  
  p.floor=curlvl
  uncover_room(p.x,p.y)
  sfx(27)
  
  darkin()
 end
 p.staircol=fget(m,7)
 
 
 local newstate
 if p.state=="slash" and anim_step(p)<3 then
  newstate="slash"
 elseif abs(p.vx)>0.1 or abs(p.vy)>0.1 then
  newstate="run"
  local step,one=anim_step(p)
  if step==3 and one then sfx(16) end
 else
  newstate="idle"
 end
 
 if newstate~=p.state then
  p.state,p.animt=newstate,0
 end
end

function update_plant(p)
 local tilx,tily=tile(p.x,p.y)
 local til,tt=mget(tilx,tily),0.01

 if til>=2 and til<=4 and rnd(4)<3 then
  tt+=0.04
 end
 
 p.t+=tt
 if p.t%(p.td/p.spk)<tt then
  if on_floor(p) and chance(70) then
   mset(tilx,tily,1)
  end
  
  if p.t>p.td then
   group_add("hittable",p)
  end
 end
 
 p.t=min(p.t,p.td+0.1)
end

function update_enemy(en)
 if en.hidden then return end

 update_animt(en)
 en.faceleft=en.x>player.x
 
 if en.updatetyp=="fireball" then
  en.x+=en.vx
  en.y+=en.vy
  if map_col(en) then
   en:hit()
  end
  en.faceleft=en.vx<0
 else
  
  if en.name=="gar" then
   local step,one=anim_step(en)
   
   if en.state=="teleport" then
    if step==4 and one then
     particles(en.x,en.y,6,en.colors)
     repeat
      en.x,en.y=untile(flrnd(32),flrnd(32))
     until dist(en.x,en.y,player.x,player.y)>64 and tile_flag(en.x/8,en.y/8,6)
     
     en.state="idle"
    end
   else
    if step>=14 and step<27 and en.animt%0.1<0.01 then
    
     for i=0,5 do
      local a=i/6+en.animt*.2
      local xx,yy=0.5*cos(a),0.5*sin(a)
      create_enemy(en.x+16*xx,en.y+16*yy,"fireball",xx,yy)
     end
     sfx(18)
     
    elseif step==34 and one and dist(en.x,en.y,player.x,player.y)<48 then
     en.state="teleport"
    end
   end

  end
 
  local mvx,mvy=0,0
  
  if en.knock==0 then
   local upd
   if en.updatetyp=="follow" then
    upd=update_bat
   elseif en.updatetyp=="slime" then
    upd=update_slime
   end
   
   mvx,mvy=upd(en)
   
   if en.name=="mage" then
    local step,one=anim_step(en)
    if step==7 and one then
     create_enemy(en.x+16*mvx,en.y+16*mvy,"fireball",mvx*2,mvy*2)
     sfx(18)
    end
    
    mvx,mvy=-mvx,-mvy
   end
  else
   en.knock=max(en.knock-1,0)
  end
  
  update_movement(en,mvx,mvy,true,true)
 end

 local cole,colp=collide_objgroup(en,"enemies"),collide_objobj(en,player)
 if cole then
  local a=atan2(en.x-cole.x,en.y-cole.y)
  cole.vx-=en.rep*cos(a)
  cole.vy-=en.rep*sin(a)
 end
 
 if colp and en.dmg and player.inv==0 then
  player.hp-=en.dmg
  player.inv=0.2
  
  local a=atan2(player.x-en.x,player.y-en.y)
  
  player.vx+=6*cos(a)
  player.vy+=6*sin(a)
  
  sfx(31)
  
  if player.hp<=0 then
   t=0
   sfx(35)
  end
 end
end

function update_bat(en)
 local a=atan2(player.x-en.x,player.y-en.y)
 return en.acc*cos(a),en.acc*sin(a)
end

function update_slime(en)
 if en.z<-0.5 then
  en.animt-=0.01
 else
  en.vx*=0.8
  en.vy*=0.8
 end
 
 en.z+=en.vz
 en.vz+=0.5
 
 if en.z>0 then
  en.vz,en.z=0,0
 end
 
 local step,one=anim_step(en)
 if step==en.jstep and one then
  en.vz=en.jump
  sfx(34)
  return update_bat(en)
 end
 
 return 0,0
end

function update_collect(s)
 s.t+=0.01

 local mvx,mvy=0,0
 if s.t>0.15 then
  local a=atan2(player.x-s.x,player.y-s.y)
  mvx,mvy=0.4*cos(a),0.4*sin(a)
 end
 
 update_movement(s,mvx,mvy,true,true)
 
 s.z+=s.vz
 s.vz-=0.4
 
 if s.z<0 then
  s.z=0
  s.vz*=-0.5
  
  if s.vz<1.2 then
   s.vz=0
  end
 end
 
 if s.t>0.03 and collide_objobj(s,player) then
  if add_item(s.item) then
   create_text(player.x,player.y-6,"+"..items[s.item].name,12,1)
   deregister_object(s)
   sfx(19)
  end
 end
end

function update_door(d)
 d.t=abs(d.t+0.01)

 if d.hidden or not on_floor(d) then return end

 local prev=d.colplayer
 d.colplayer=collide_objobj(d,player)
 
 if prev and not d.colplayer then
  darken_room(player.x,player.y,0)
 end
end

function update_particle(s)
 s.t+=0.01
 update_movement(s,0,0)
 
 s.z+=s.vz
 s.vz-=0.4
 
 if s.z<0 then
  s.z=0
  s.vz*=-0.5
  
  if s.vz<1.2 then
   s.vz=0
  end
 end
 
 local tx,ty=tile(s.x,s.y)
 if s.t>0.8 or tile_flag(tx,ty,0) then
  deregister_object(s)
 end
end

function update_animt(o)
 o.animt+=0.01
end

function add_money(v)
 player.money=min(player.money+v,9999)
 add_shake(1)
 particles(player.x,player.y,3,parse"7,10,9")
end

function add_item(name,num)
 local num=num or 1

 local done=false
 for i=1,invplaces do
  local data=inventory[i]
  if data[1]==items[name] then
   data[2]+=num
   return true
  end
 end

 for i=1,invplaces do
  local data=inventory[i]
  if data[2]==0 then
   data[1],data[2]=items[name],num
   return true
  end
 end
 
 return false
end

function sell_item(s)
 local data=inventory[invcur]
 if data[2]>0 then
  data[2]-=1
  local p=data[1].price
  add_money(p)
  
  create_text(player.x,player.y-6,"+"..p.."$",11,3)
  
  sfx(29)
  s.stand.item=data[1].ref
 end
end

function use_hoe(targ)
 local x,y=targ[1],targ[2]
 mset(x,y,1)
 
 x,y=untile(x,y)
 particles(x,y,4+flrnd(2),parse"4,4,9,2")
 sfx(20)
end

function water_tile(targ)
 local x,y=targ[1],targ[2]
 mset(x,y,2+flrnd(3))
 
 x,y=untile(x,y)
 particles(x,y,2,parse"12,12,12,7")
 sfx(21)
end

function plant_seed(targ)
 local data,x,y=inventory[invcur],untile(targ[1],targ[2])
 create_plant(x,y,data[1].plant)
 particles(x,y,3,parse"11,3,4,9,2")
 sfx(22)
 return true
end

function eat(target,hp)
 local str
 
 if not hp then
  player.hpmax+=1
  player.hp+=1
  create_text(player.x,player.y-6,"+1 hp max",14,2)
  sfx(30)
  return true
 end

 local mhp=function() return player.hp>=player.hpmax end

 if mhp() then return false end
 
 player.hp+=hp
 
 str="+"..hp.." hp"
 if mhp() then
  player.hp,str=player.hpmax,"hp max"
 end
 create_text(player.x,player.y-6,str,11,3)

 sfx(30)
 return true
end

function hit_door(d)
 while collide_objobj(d,player) do
  if d.horiz then
   player.y+=sgn(player.vy)
  else
   player.x+=sgn(player.vx)
  end
 end

 sfx(25)
 add_shake(1)
 
 door_change(d,player.x,player.y)
end

function door_change(d,fx,fy)
 d.open=not d.open
 mset(d.tilx,d.tily,d.closesprite-30+(d.open and 2 or 0))

 local x,y
 if d.horiz then
  x,y=d.x,d.y+sgn(d.y-fy)*8
 else
  x,y=d.x+sgn(d.x-fx)*8,d.y
 end
 
 if d.open then
  if d.t>50 then
   local x1,y1,x2,y2=get_room(x,y)
   if x2-x1>32 and y2-y1>32 and mget(x/8,y/8)~=28 then
    local k=curlvl+flrnd(2)
    for i=1,k do
     create_enemy(lerp(x1,x2,.25+rnd(.5)),lerp(y1,y2,.25+rnd(.5)),pick(spawntable[curlvl]))
    end
    sfx(17)
   end
  end
 
  uncover_room(x,y)
 else
  cover_room(x,y)
  d.t=0
  
  d.hidden=false
 end
end

function stand_buy(s)
 if s.item then
  local data=items[s.item]
  if player.money>=data.price then
   create_collect(s.x,s.y,s.item)
   player.money-=data.price
   
   create_text(player.x,player.y-6,"-"..data.price.."$",14,2)
   
   if not s.infi then
    s.item=nil
   end
   
   sfx(28)
   particles(player.x,player.y,3,parse"7,10,9")
  end
 end
end

function uncover_room(x,y)
 local x1,y1,x2,y2=get_room(x,y)
 x,y=(x1+x2)*0.5,(y1+y2)*0.5
 
 for o in group("to_draw2") do
  if in_box(o.x,o.y,x1,y1,x2,y2) and on_floor(o) then
   local prev=o.hidden
   o.hidden=false
   
   if o.is_door and o.open and prev then
    if o.horiz then
     uncover_room(o.x,o.y+sgn(o.y-y)*8)
    else
     uncover_room(o.x+sgn(o.x-x)*8,o.y)
    end
   end
  end
 end
end

function cover_room(x,y)
 local x1,y1,x2,y2=get_room(x,y)
 x,y=(x1+x2)*.5,(y1+y2)*.5
 
 for o in group("to_draw2") do
  if in_box(o.x,o.y,x1,y1,x2,y2) and on_floor(o) then
   local prev=o.hidden
   o.hidden=true
   
   if o.is_door and o.open and not prev then
    if o.horiz then
     cover_room(o.x,o.y+sgn(o.y-y)*8)
    else
     cover_room(o.x+sgn(o.x-x)*8,o.y)
    end
   end
  end
 end
end

function darken_room(x,y,k)
 local x1,y1,x2,y2=get_room(x,y)
 x,y=(x1+x2)*0.5,(y1+y2)*0.5
 
 for o in group("doors") do
  if in_box(o.x,o.y,x1,y1,x2,y2) and on_floor(o) then
   if o.is_door and o.open and not o.done then
   
    if k>=2 then
     door_change(o,x,y)
    else
     o.done=true
     if o.horiz then
      darken_room(o.x,o.y+sgn(o.y-y)*8,k+1)
     else
      darken_room(o.x+sgn(o.x-x)*8,o.y,k+1)
     end
     o.done=nil
    end
    
   end
  end
 end
end

function is_free(x,y)
 for o in group("needtile") do
  local tilx,tily=tile(o.x,o.y)
  if tilx==x and tily==y then
   return false
  end
 end
 return true
end

function end_game()
 sfx(36)
 win,t=true,0
end

function tile_flag(x,y,f) return fget(mget(x,y),f) end

function collect_fruit(s)
 create_collect(s.x,s.y,s.fruit)
 group_rem("hittable",s)
 particles(s.x,s.y,4+flrnd(2),parse"1,11")
 sfx(23)
 
 if s.again then
  s.t=s.td/2
 else
  deregister_object(s)
 end
end

function damage(en,noeffect)
 local a=atan2(player.x-en.x,player.y-en.y)
 en.vx-=4*cos(a)
 en.vy-=4*sin(a)
 en.knock,en.whiteframe=8,true
  
 local dmg,data=1,inventory[invcur]
 if data[2]>=1 then
  dmg=data[1].damage or 1
 end
 
 dmg=round((0.75+rnd(0.5))*dmg)
 
 if not en.noeffect then
  create_text(en.x,en.y-6,-dmg,14,2)
  sfx(33)
 end
 
 en.hp-=dmg
 if en.hp<0 then
  particles(en.x,en.y,6,en.colors)

  if en.name=="gar" then
   music(-1)
  end
  
  if en.noeffect then
   add_shake(1.5)
   sfx(37)
  else
   add_shake(4)
   sfx(32)
  end
  
  if en.loot then
   create_collect(en.x,en.y,en.loot)
  end
  
  deregister_object(en)
 else
  add_shake(2)
 end
end

function destroy_prop(p)
 deregister_object(p)
 
 local data=props[p.name]
 if chance(data.lootchance) then
  create_collect(p.x,p.y,pick(data.loot))
 end
 
 particles(p.x,p.y,3+flrnd(2),data.cols)
 sfx(32)
 add_shake(1)
end

function add_shake(p)
 local a=rnd(1)
 shkx+=p*cos(a)
 shky+=p*sin(a)
end

function update_shake()
 if abs(shkx)+abs(shky)<0.5 then
  shkx,shky=0,0
 else
  shkx*=-0.5-rnd(0.2)
  shky*=-0.5-rnd(0.2)
 end
end

function on_floor(o)
 return not o.floor or o.floor==curlvl
end



function draw_player(p)
 if p.inv%0.04>0.02 then return end
 
 draw_self(p)
 
 if p.state=="slash" then
  local n,s,x,y,flp=anim_step(p),72,p.x-3,p.y-8,false
  
  if n==0 then s=-2 end
  if n==2 then s+=2 end
  if p.faceleft then
   x-=10
   flp=true
  end
  
  spr(s,x,y,2,2,flp,false)
  
  local data=inventory[invcur]
  if data[2]>=1 then
   local sp,ox,oy=255,3,6
   if n==0 then
    sp,ox,oy=data[1].sprite,6,-6
   else
    local s=data[1].sprite
    local sx,sy=s%16*8,flr(s/16)*8
    
    for y=0,7 do
    for x=0,7 do
     sset(127-x,120+y,sget(sx+y,sy+x))
    end
    end
   end
   
   if p.faceleft then ox=-ox end
   local foo=function()
    spr(sp,p.x+ox-4,p.y+oy-4,1,1,p.faceleft)
   end
   draw_outline(foo)
   foo()
   
  end
 end
end

function draw_self(s)
 local foo=function(s)
            local state=s.state or "only"
			local z=s.z or 0
            draw_anim(s.x,s.y-1+z,s.name,state,s.animt,s.faceleft)
           end
 local c
 if s.whiteframe then c=7 end
 draw_outline(foo,c,s)
 if s.whiteframe then all_colors_to(7) end
 foo(s)
 if s.whiteframe then all_colors_to() s.whiteframe=false end
end

function draw_fireball(s)
 pal(11,0)
 draw_anim(s.x,s.y,"fireball","only",s.animt,s.faceleft)
 pal(11,11)
end

function draw_plant(p)
 local s=p.sp+(p.t*p.spk)/p.td
 local foo=function()
  spr(s,p.x-4,p.y-8)
 end
 
 local c
 if p.highlight then
  c,p.highlight=7,false
 else
  c=0
 end
 draw_outline(foo,c)
 
 if p.palmap then
  apply_palmap(p.palmap)
 end
 foo()
end

function draw_shopkeeper(s)
 draw_self(s)
 local hit={x=s.x,y=s.y,w=14,h=14}
 if collide_objobj(hit,player) then
  local data=inventory[invcur]
  if data[2]>=1 then
   add(texts,{"sell:"..data[1].price.."$",s.x,s.y-10,11,3})
  end
 end
end

function draw_stand(s)
 local foo=function()
  spr(44,s.x-4,s.y-6)
 end
 draw_outline(foo)
 foo()
 
 if s.item then
  local foo=function()
   spr(items[s.item].sprite,s.x-4,s.y-11+2*cos(s.animt))
  end
  draw_outline(foo)
  foo()

  local hit={x=s.x,y=s.y,w=14,h=14}
  if collide_objobj(hit,player) then
   local data=items[s.item]
   add(texts,{data.name..": "..data.price.."$",s.x,s.y+2,10,4})
  end
 end
end

function draw_prop(p)
 local foo=function()
  spr(p.s,p.x-4,p.y-6)
 end
 
 draw_outline(foo)
 foo()
end

function draw_door(d)
 local xx,yy=0,0
 if d.open then xx,yy=4,3 end
 local foo=function()
  spr(d.open and d.opensprite or d.closesprite,d.x+xx-4,d.y+yy-8)
 end
 draw_outline(foo)
 foo()
end

function draw_collect(s)
 local foo=function() spr(s.s,s.x-4,s.y-s.z-4) end
 
 if s.t<0.03 then
  draw_outline(foo,7)
  all_colors_to(7)
  foo()
  all_colors_to()
 else
  draw_outline(foo)
  foo()
 end
end

function draw_particle(s)
 local y=s.y-s.z
 circ(s.x,y,1,drk[s.c])
 pset(s.x,y,s.c)
end

function draw_room()
 local dx,dy,amx,amy=flr(xmod%8),flr(ymod%8),tile(xmod,ymod)
 
 memset(0x4300,0,289) --17*17
 
 local px,py=tile(player.x,player.y)
 local uncover
 uncover=function(x,y,k,xm,ym)
  local sx,sy=x-amx,y-amy

  local a=0x4300+sy*17+sx
  if peek(a)>0 or k>2 or not in_box(sx,sy,0,0,17,17) then
   return
  end
  
  local m=mget(x,y)
  spr(m,sx*8-dx,sy*8-dy)
  
  poke(a,fget(m,0) and 2 or 1)
  
  if fget(m,5) and (xm~=0 or ym~=0) then
   if xm~=0 and ym~=0 then
    poke(a,0)
   else
    k+=1
    darken(k>1)
    uncover(x+xm,y+ym,k,xm,ym)
    k-=1
    if k>0 then darken(k>1) else all_colors_to() end
   end
  elseif not fget(m,4) then
   for xx=-1,1 do
   for yy=-1,1 do
    uncover(x+xx,y+yy,k,xx,yy)
   end
   end
  end
 end
 
 uncover(px,py,0,0,0)
end

function draw_inventory()
 color()
 rectfill(41,102,87,111)
 circfill(41,111,9)
 circfill(87,111,9)
 rectfill(0,110,127,127)


 local x=7

 for i=1,invplaces do
  local s
  if i==invcur then
   x+=1
   s=224
  else
   s=192
  end
  spr(s,x-8,112,2,2)
 
  local data=inventory[i]
  
  if data[2]~=0 then
   spr(data[1].sprite,x-4,116)
   
   if data[2]>1 then
    draw_text(""..data[2],x+4,124)
   end
  end
  
  if i==invcur then
   x+=1
  end
  
  x+=14
 end
 
 local str
 local data=inventory[invcur]
 if data[2]==0 then
  str="nothing"
 else
  str=data[1].name
 end
 draw_text(str,64,107)
 
 pal(11,0)

 draw_text("floor "..curlvl.."/4",127,5,2,true)
 
 spr(194,93,8,2,2)
 draw_text(player.money,110,17,0,true)
 
 for i=0,player.hpmax-1 do
  local s
  if i+1<=player.hp then
   s=200
  elseif i+.5<=player.hp then
   s=46
  else
   s=232
  end
  spr(s,i*13,-1,2,2)
 end
 
 pal(11,11)
end

function draw_text(str,x,y,al,extra,c1,c2)
 str=""..str
 local al=al or 1
 local c1=c1 or 7
 local c2=c2 or 13

 if al==1 then x-=#str*2-1
 elseif al==2 then x-=#str*4 end
 
 y-=3
 
 if extra then
  print(str,x,y+3,0)
  print(str,x-1,y+2,0)
  print(str,x+1,y+2,0)
  print(str,x-2,y+1,0)
  print(str,x+2,y+1,0)
  print(str,x-2,y,0)
  print(str,x+2,y,0)
  print(str,x-1,y-1,0)
  print(str,x+1,y-1,0)
  print(str,x,y-2,0)
 end
 
 print(str,x+1,y+1,c2)
 print(str,x-1,y+1,c2)
 print(str,x,y+2,c2)
 print(str,x+1,y,c1)
 print(str,x-1,y,c1)
 print(str,x,y+1,c1)
 print(str,x,y-1,c1)
 print(str,x,y,0)

end

function draw_outline(draw,c,arg)
 local c=c or 0

 all_colors_to(c)
 
 camera(xmod-1,ymod)
 draw(arg)
 camera(xmod+1,ymod)
 draw(arg)
 camera(xmod,ymod-1)
 draw(arg)
 camera(xmod,ymod+1)
 draw(arg)
 
 camera(xmod,ymod)
 all_colors_to()
end



function create_player()
 player=merge_arrays(parse[[
vx=0,
vy=0,
acc=0.7,
spdcap=1.4,
dec=0.7,
w=4,
h=4,
name=player,
state=idle,
faceleft=true,
staircol=true,
animt=0,
money=0,
hp=3,
hpmax=3,
inv=0.1,
regs={to_update,to_draw2}
]],{
  draw=draw_player,
  update=update_player,
 })
 
 register_object(player)
end

function create_plant(x,y,name)
 local p=merge_arrays(parse[[
w=6,
h=8,
t=0,regs={to_update,to_draw2,plants,needtile}
]],{
  x=x+rnd(2)-1,
  y=y+rnd(2),
  update=update_plant,
  draw=draw_plant,
  hit=collect_fruit
 })
 
 merge_arrays(p,plants[name])
 
 register_object(p)
end

function create_shopkeeper(x,y,stand)
 local s=merge_arrays(parse[[
w=6,
h=6,
name=shopkeeper,
animt=0,
hidden=true,
regs={to_update,to_draw2,hittable}
]],{
  x=x,
  y=y,
  update=update_animt,
  draw=draw_shopkeeper,
  hit=sell_item,
  stand=stand,
 })
 
 register_object(s)
end

function create_stand(x,y,item,infi)
 local s=merge_arrays(parse[[
w=4,
h=3,
animt=%1,
hidden=true,
regs={to_update,to_draw2,hittable,doors}
]],{
  x=x,
  y=y,
  item=item,
  infi=infi,
  update=update_animt,
  draw=draw_stand,
  hit=stand_buy
 })
 
 register_object(s)
 
 return s
end

function create_enemy(x,y,name,vx,vy)
 local en=merge_arrays(parse[[
animt=%0.2,
knock=0,
regs={to_update,to_draw2,hittable,enemies}
]],{
  x=x,
  y=y,
  vx=vx or 0,
  vy=vy or 0,
  update=update_enemy,
  draw=name=="fireball" and draw_fireball or draw_self,
  hit=damage
 })
 
 merge_arrays(en,enemies[name])
 
 register_object(en)
end

function create_prop(x,y,name)
 local x,y=untile(x,y)
 local p=merge_arrays(parse[[
hidden=true,
w=6,
h=6,
regs={to_draw2,hittable,needtile}
]],{
  x=x,
  y=y,
  s=props[name].sprite,
  name=name,
  draw=draw_prop,
  hit=destroy_prop
 })
 
 register_object(p)
end

function create_door(tilx,tily,horiz)
 local d=merge_arrays(parse[[
is_door=true,
hidden=true,
open=false,
colplayer=false,
t=999,
horiz=false,
w=4,
h=8,
opensprite=54,
closesprite=55,
regs={to_update,to_draw2,hittable,needtile,doors}
]],{
  tilx=tilx,
  tily=tily,
  update=update_door,
  draw=draw_door,
  hit=hit_door
 })
 
 if horiz then
  merge_arrays(d,parse[[
horiz=true,
w=8,
h=4,
opensprite=55,
closesprite=54
]])
 end
 
 d.x,d.y=untile(tilx,tily)
 
 register_object(d)
end

function create_collect(x,y,item)
 local a,spd=rnd(1),2+rnd(2)
 
 local s=merge_arrays(parse[[
w=6,
h=6,
spdcap=3,
dec=0.8,
z=2,
vz=%3,
t=0,
regs={to_update,to_draw2,collect}
]],{
  x=x,
  y=y,
  vx=spd*cos(a),
  vy=spd*sin(a),
  s=items[item].sprite,
  item=item,
  update=update_collect,
  draw=draw_collect,
 })
 
 register_object(s)
 
 return s
end

function create_text(x,y,str,c1,c2)
 local txt={
  t=2,
  x=x,
  y=y,
  str=str,
  c1=c1,
  c2=c2
 }
 
 add(floatxts,txt)
end

function particles(x,y,n,clrs)
 for i=1,n do
  create_particle(x,y,pick(clrs))
 end
end

function create_particle(x,y,c)
 local a,spd=rnd(1),2+rnd(5)
 
 local s=merge_arrays(parse[[
w=2,
h=2,
spdcap=3,
dec=0.8,
z=%2,
vz=%2.5,
t=%0.4,
regs={to_update,to_draw1}
]],{
  x=x,
  y=y,
  c=c,
  vx=spd*cos(a),
  vy=spd*sin(a),
  update=update_particle,
  draw=draw_particle
 })
 
 register_object(s)
end



function init_plants()
 plants=parse[[berrytree={fruit=berries,td=180,sp=128,spk=7,again=true},bigberrytree={fruit=bigberry,td=180,sp=128,spk=7,palmap={12=8,1=2},again=true},berryberrytree={fruit=berryberry,td=180,sp=128,spk=7,palmap={12=13,1=2},again=true},carrot={fruit=carrot,td=120,sp=144,spk=3,palmap={2=4,14=9,15=10}},beet={fruit=beet,td=120,sp=144,spk=3},potato={fruit=potato,td=120,sp=144,spk=3,palmap={2=4,14=2,15=9,7=10}},heartree={fruit=heart,td=100,sp=160,spk=6},swordtree={fruit=sword,td=120,sp=176,spk=7,palmap={6=4,13=2}},betterswordtree={fruit=bettersword,td=120,sp=176,spk=7,palmap={11=14,3=2}},bestswordtree={fruit=bestsword,td=120,sp=176,spk=7,palmap={11=10,3=9}}]]
end

function init_enemies()
 enemies=parse[[bat={w=3,h=3,acc=0.1,dec=0.97,spdcap=1.3,hp=3,dmg=0.5,rep=0.2,loot=wildberry,name=bat,updatetyp=follow,colors={13,13,13,13,1}},skeleton={w=6,h=6,acc=0.3,dec=0.8,spdcap=0.6,hp=6,dmg=1,rep=2,loot=bone,name=skeleton,updatetyp=follow,colors={6,7,7,9}},golem={w=6,h=6,acc=0.3,dec=0.5,spdcap=1.5,hp=25,dmg=2,rep=3,loot=marbles,name=golem,updatetyp=follow,colors={13,6,13,6,1}},slime={w=4,h=4,acc=3,dec=0.99,spdcap=3,hp=4,dmg=0.5,rep=1,loot=slime,name=slime,updatetyp=slime,jump=-2,jstep=16,z=0,vz=0,colors={11,11,11,3}},bigslime={w=6,h=6,acc=2,dec=0.99,spdcap=2,hp=9,dmg=1,rep=1,loot=slime,name=bigslime,updatetyp=slime,jump=-1,jstep=7,z=0,vz=0,colors={11,11,11,3}},mage={w=6,h=6,acc=0.4,dec=0.8,spdcap=0.6,hp=8,rep=1,loot=powder,name=mage,updatetyp=follow,colors={8,10,2}},fireball={w=2,h=2,hp=0,dmg=1,rep=1,noeffect=true,name=fireball,updatetyp=fireball,colors={8,9,10}},gar={w=6,h=6,acc=0,dec=0.9,spdcap=2,hp=320,rep=1,loot=winningring,name=gar,state=idle,updatetyp=follow,colors={8,8,10,10,14}}]]

 spawntable=parse[[
{bat,slime,slime},
{bat,skeleton,bigslime,bigslime},
{bat,skeleton,golem,golem,mage,mage}
]]
end

function init_props()
 props=parse[[bush={sprite=40,lootchance=20,loot={berryseed,wildberry},cols={3,11}},bush2={sprite=56,lootchance=20,loot={berryseed,wildberry},cols={3,11}},crate={sprite=41,lootchance=40,loot={berries},cols={4,9}},vase1={sprite=57,lootchance=30,loot={berries,slime,berryseed,carrotseed},cols={6,7,11}},vase2={sprite=58,lootchance=30,loot={berries,slime,berryseed,carrotseed},cols={6,7,14}},vase3={sprite=59,lootchance=30,loot={berries,slime,berryseed,carrotseed},cols={6,7,9}},vase4={sprite=60,lootchance=30,loot={berries,slime,berryseed,carrotseed},cols={6,7,12}},bc-1={sprite=41,lootchance=200,loot={hoe},cols={4,9}},bc0={sprite=41,lootchance=200,loot={watcan},cols={4,9}},bc1={sprite=41,lootchance=200,loot={woodsword},cols={4,9}}]]
end

function init_items()
 items=parse[[hoe={name=hoe,sprite=136,target=tile,tilef=1,ntarg=true,use=hoe,price=50},watcan={name=watering can,sprite=137,target=tile,tilef=2,ntarg=true,use=watcan,price=50},woodsword={name=wooden sword,sprite=138,price=50,damage=2},sword={name=sword,sprite=158,price=100,damage=4},bettersword={name=better sword,sprite=159,price=150,damage=8},bestsword={name=best sword,sprite=175,price=250,damage=16},slime={name=slime,sprite=140,price=3},powder={name=magic dust,sprite=141,price=10},marbles={name=marbles,sprite=142,price=12},bone={name=bone,sprite=143,price=5},berryseed={name=berry seeds,sprite=171,plant=berrytree,use=seed,price=5},bigberryseed={name=bigberry seeds,sprite=172,plant=bigberrytree,use=seed,price=15},berryberryseed={name=berryberry seeds,sprite=173,plant=berryberrytree,use=seed,price=50},carrotseed={name=carrot seeds,sprite=168,plant=carrot,use=seed,price=4},beetseed={name=beet seeds,sprite=169,plant=beet,use=seed,price=13},potatoseed={name=potato seeds,sprite=170,plant=potato,use=seed,price=45},swordseed={name=sword seed,sprite=185,plant=swordtree,use=seed,price=150},betterswordseed={name=better sword seed,sprite=186,plant=betterswordtree,use=seed,price=500},bestswordseed={name=best sword seed,sprite=187,plant=bestswordtree,use=seed,price=2000},heartseed={name=life seeds,sprite=184,plant=heartree,use=seed,price=200},wildberry={name=wildberries,sprite=189,hp=0.5,consumable=true,use=fruit,price=2},berries={name=berries,sprite=152,hp=1,consumable=true,use=fruit,price=12},bigberry={name=bigberry,sprite=153,hp=2,consumable=true,use=fruit,price=30},berryberry={name=berryberry,sprite=154,hp=3,consumable=true,use=fruit,price=100},carrot={name=carrot,sprite=155,hp=1,consumable=true,use=fruit,price=14},beet={name=beet,sprite=156,hp=2,consumable=true,use=fruit,price=43},potato={name=potato,sprite=157,hp=3,consumable=true,use=fruit,price=125},heart={name=life fruit,sprite=174,consumable=true,use=fruit,price=500},winningring={name=ring of the winner,sprite=139,consumable=false,use=endgame,price=9999}]]

 local uses={
  hoe=use_hoe,
  watcan=water_tile,
  seed=plant_seed,
  fruit=eat,
  endgame=end_game
 }
 
 for k,it in pairs(items) do
  if it.use=="seed" then
   it.tilecheck=is_free
   
   merge_arrays(it,parse[[
target=tile,
consumable=true,
ntarg=true,
tilef=3
]])
  end
 
  it.use=uses[it.use]
  it.ref=k
 end
end

function init_inventory()
 invplaces,inventory=9,{}
 for i=1,invplaces do
  inventory[i]=parse[[,0]]
 end
end

function generate_level()
 for o in group"hittable" do
  if not o.floor then
   deregister_object(o)
  end
 end

 local rectfilll=function(x1,y1,x2,y2,c)
  for xx=x1,x2 do
  for yy=y1,y2 do
   mset(xx,yy,c)
  end
  end
 end
 
 if curlvl==4 then
  rectfilll(0,0,127,31,36)
 
  for x=9,22 do
   mset(x,8,32+flrnd(4))
   for y=9,22 do
    mset(x,y,16+flrnd(8))
   end
  end
  
  mset(12,12,32)
  mset(12,19,33)
  mset(19,12,34)
  mset(19,19,35)
  create_enemy(128,128,"gar")
  mset(16,11,53)
  return untile(16,11)
 end

 rectfilll(0,0,127,31,2)
 rectfilll(1,1,126,30,0)

 local x,y=48+flrnd(32),8+flrnd(16)
 local sx,sy,dirs,nrooms,dir=x,y,{{-1,0},{1,0},{0,-1},{0,1}},1,nil
 
 rectfilll(x-2,y-2,x+2,y+2,3)
 
 while nrooms<32 do
  mset(x,y,4)
  
  if chance(50) or not dir then
   dir=pick(dirs)
  end
  
  local px,py=x,y
  x+=dir[1]
  y+=dir[2]
  
  local c=mget(x,y)
  
  if c==2 then
   x=px
   y=py
   dir=nil
  elseif c==1 then
   x+=dir[1]
   y+=dir[2]
  elseif c==0 then
   local b=true
   local n=sgn(dir[1])*sgn(dir[2])
   for xx=-dir[2],dir[2]+2*dir[1],n do
   for yy=-dir[1],dir[1]+2*dir[2],n do
    b=b and mget(x+xx,y+yy)==0
   end
   end
  
   if b then
    mset(x,y,1)
    x+=dir[1]
    y+=dir[2]

    local ar,arr,arrr={x,y,x,y},{-1,-1,1,1},parse"0,0,0,0"
    
    repeat
     local n=flrnd(4)+1
     ar[n]+=arr[n]
     
     local b
     for xx=ar[1]-1,ar[3]+1 do
     for yy=ar[2]-1,ar[4]+1 do
      b=b or mget(xx,yy)>1
     end
     end
     
     if b or arrr[n]>5 then
      ar[n]-=arr[n]
      arr[n]=0
     end
     
     arrr[n]+=1
     
     if chance(15) then
      arr[n]=0
     end
    
     b=true
     for i=1,4 do b=b and arr[i]==0 end
    until b
    
    rectfilll(ar[1],ar[2],ar[3],ar[4],3)
    nrooms+=1
   else
    x=px
    y=py
    dir=nil
   end
  end
 end
 
 local maaap={}
 for y=0,31 do
 for x=0,127 do
  local c,a,v=mget(x,y),y*128+x

  if c==1 then v=3
  elseif c<=2 then v=0
  else v=c-2 end
  maaap[a]=v
 end
 end
 
 for y=0,31 do
 for x=0,127 do
  local a=y*128+x
  local c=maaap[a]
  if c==0 then
   local k=0
   for xx=x-1,x+1 do
   for yy=y-1,y+1 do
    if in_box(xx,yy,1,1,127,31) and maaap[yy*128+xx]>0 then
     k+=1
    end
   end
   end

   if k>0 then
    if y<31 and maaap[a+128]~=0 then
     mset(x,y,32+flrnd(4))
    else
     mset(x,y,36)
    end
   else
    mset(x,y,0)
   end
  elseif c==2 and rnd(4)<3 then
   mset(x,y,8+flrnd(3))
   local squa=true
   for xx=0,1 do for yy=0,1 do
    local m=mget(x-xx,y-yy)
    squa=squa and m>=8 and m<=11
   end end

   if squa and chance(50) then
    for i=0,3 do
     mset(x-i%2,y-flr(i/2),15-i)
    end
   end
  elseif c==3 then
   if maaap[a-1]==0 and maaap[a+1]==0 then
    mset(x,y,24)
    create_door(x,y,true)
   elseif maaap[a-128]==0 and maaap[a+128]==0 then
    mset(x,y,25)
    create_door(x,y)
   end
   
  else
   mset(x,y,16+flrnd(8))
  end
 end
 end
 
 local i,x1,y1,x2,y2=0
 repeat
  repeat
   x,y=rnd128(),rnd(32)
  until not tile_flag(x,y,4)
  i+=1
  if i>499 then return generate_level() end
  
  x,y=untile(x,y)
  x1,y1,x2,y2=get_room(x,y)
  x1,y1=tile(x1+8,y1+8)
  x2,y2=tile(x2-12,y2-12)
 until x2-x1>4 and y2-y1>4
 
 rectfilll(x1,y1,x2,y2,28)
 for xx=x1,x2 do
  if tile_flag(xx,y1-1,0) then
   mset(xx,y1-1,38+xx%2)
  end
 end

 local x,y=flr(.5*x1+.5*x2),flr(.5*y1+.5*y2)
 
 mset(x,y,29)
 mset(x,y+2,29)
 local s=create_stand(x*8+4,y*8+20)
 create_shopkeeper(x*8+4,y*8+4,s)
 
 local k,ar,arr=1,parse"{heartseed,swordseed},{heartseed,betterswordseed},{heartseed,bestswordseed}",parse"{carrotseed,berryseed},{beetseed,bigberryseed},{potatoseed,berryberryseed}"
 for i=0,49 do
  local x,y,b=x1+flrnd(x2-x1+1),y1+flrnd(y2-y1+1)
  
  for yy=-1,1 do
   b=b or tile_flag(x,y+yy,4)
  for xx=-1,1 do
   local m=mget(x+xx,y+yy)
   b=b or m==29 or m==24 or m==25 
  end
  end
  
  if not b then
   mset(x,y,29)
   x,y=untile(x,y)
   if k<3 then
    create_stand(x,y,ar[curlvl][k])
   else
    create_stand(x,y,arr[curlvl][k%2+1],true)
   end
   
   k+=1
  end
 end

 for i=0,299 do
  local x,y=flrnd(128),flrnd(32)
  local m=mget(x,y)
  
  if is_free(x,y) then
   if m>=8 and m<16 then
    create_prop(x,y,pick(parse"crate,crate,vase1,vase2,vase3,vase4"))
   elseif m>=16 and m<24 then
    create_prop(x,y,chance(50) and "bush" or "bush2")
   end
  end
 end

 local i=0 
 while mget(x1,y1)~=16 or not is_free(x1,y1) or tile_flag(x1,y1+1,0) or dist(x1,y1,sx,sy)<32 do
  i+=1
  if i>999 then return generate_level() end

  x1,y1=flrnd(128),flrnd(32)
 end
 mset(x1,y1,52)

 mset(sx,sy,53)
 
 return untile(sx,sy) 
end

function get_room(x,y)
 x,y=tile(x,y)
 local lx,hx,ly,hy=x,x,y,y
 
 while tile_flag(lx,y,6) do lx-=1 end
 while tile_flag(hx,y,6) do hx+=1 end hx+=1
 while tile_flag(x,ly,6) do ly-=1 end
 while tile_flag(x,hy,6) do hy+=1 end hy+=1
 
 return lx*8,ly*8,hx*8,hy*8
end



function init_anim_info()
 anim_info=parse[[
player={
idle={
sprites={64,65,66,67,68,69,70,69,68,67,66,65},
dt=0.03
},
run={
sprites={80,81,82,83,84,85},
dt=0.02
},
slash={
sprites={86,87,87,87,87},
dt=0.02
}
},
shopkeeper={
only={
sprites={98,98,96,98,97,98,98,99,100,101,100,99,98,97},
dt=0.06
}
},
bat={
only={
sprites={124,125,126,127},
dt=0.02
}
},
skeleton={
only={
sprites={104,105,106,107},
dt=0.03
}
},
golem={
only={
sprites={120,121,122,123},
dt=0.04
}
},
slime={
only={
sprites={76,77,78,79,76,77,78,79,76,77,78,79,92,92,92,93,93},
dt=0.03
}
},
bigslime={
only={
sprites={108,109,110,111,94,94,94,95,110,111},
dt=0.03
}
},
mage={
only={
sprites={112,113,114,115,112,113,114,115},
dt=0.03
}
},
fireball={
only={
sprites={116,117,118,119},
dt=0.02
}
},
gar={
idle={
sprites={
196,197,198,199,212,
196,197,198,199,212,
213,214,215,228,229,
229,229,229,229,229,
229,229,229,229,229,
229,229,229,230,231,
196,197,198,199,212},
dt=0.03
},
teleport={
sprites={244,245,246,247,247},
dt=0.03
},
dance={
sprites={196,197,198,199,212,231,231,212,199,198,197,196,231,231},
dt=0.03
}
}
]]
end

function draw_anim(x,y,char,state,t,xflip)
 local sinfo=anim_info[char][state]
 local spri,wid,hei,xflip=sinfo.sprites[flr(t/sinfo.dt)%#sinfo.sprites+1],sinfo.width or 1,sinfo.height or 1,xflip or false

 spr(spri,x-wid*4,y-hei*4,wid,hei,xflip)
end

function anim_step(o)
 local state=o.state or "only"
 local info=anim_info[o.name][state]
 
 local v=flr(o.animt/info.dt%#info.sprites)
 
 return v,(o.animt%info.dt<0.01)
end



function update_movement(s,nx,ny,map_walls,bounce)
 s.vx*=s.dec
 s.vy*=s.dec
 
 s.vx+=nx
 s.vy+=ny
 
 s.vx=mid(s.vx,-s.spdcap,s.spdcap)
 s.vy=mid(s.vy,-s.spdcap,s.spdcap)
 
 if map_walls then
  local ox,oy=s.x,s.y
  
  s.x+=s.vx
  if map_col(s) then
   s.x=ox
   
   if bounce then
    s.vx*=-0.6
   else
    s.vx*=0.2
   end
  end
  
  s.y+=s.vy
  if map_col(s) then
   s.y=oy
   
   if bounce then
    s.vy*=-0.6
   else
    s.vy*=0.2
   end
  end
  
 else
  s.x+=s.vx
  s.y+=s.vy
 end
end



function collide_objgroup(obj,groupname)
 for obj2 in group(groupname) do
  if obj2~=obj and not obj2.hidden and on_floor(obj2) and collide_objobj(obj,obj2) then
   return obj2
  end
 end

 return false
end

function collide_objobj(obj1,obj2)
 return (abs(obj1.x-obj2.x)<(obj1.w+obj2.w)/2
     and abs(obj1.y-obj2.y)<(obj1.h+obj2.h)/2)
end

function all_collide_objgroup(obj,groupname)
 local list={}
 for obj2 in group(groupname) do
  if obj2~=obj and not obj2.hidden and on_floor(obj2) and collide_objobj(obj,obj2) then
   add(list,obj2)
  end
 end
 return list
end

function map_col(obj)
 local d,x1,y1,x2,y2=collide_objgroup(obj,"doors"),bounding_box(obj)
 
 return ((d and not d.open) or fget(pmget(x1,y1),0)
      or fget(pmget(x1,y2),0)
      or fget(pmget(x2,y1),0)
      or fget(pmget(x2,y2),0))
end

function pmget(x,y)
 return mget(x/8,y/8)
end

function bounding_box(obj)
 local wh,hh=obj.w/2,obj.h/2
 return obj.x-wh,obj.y-hh,obj.x+wh,obj.y+hh
end



function update_objects()
 local uobjs=objs.to_update
 
 for obj in all(uobjs) do
  obj.update(obj)
 end
end

function draw_objects()
 for i=0,4 do
  local dobjs=objs["to_draw"..i]
 
  --sorting objects by depth
  for i=2,#dobjs do
   if dobjs[i-1].y>dobjs[i].y then
    local k=i
    while(k>1 and dobjs[k-1].y>dobjs[k].y) do
     local s=dobjs[k]
     dobjs[k],dobjs[k-1]=dobjs[k-1],s
     k-=1
    end
   end
  end
 
  --actually drawing
  for obj in all(dobjs) do
   if not obj.hidden and on_floor(obj) then
    obj.draw(obj)
   end
  end
 end
end

function register_object(o)
 for reg in all(o.regs) do
  add(objs[reg],o)
 end
end

function deregister_object(o)
 for reg in all(o.regs) do
  del(objs[reg],o)
 end
end

function group_add(name,o)
 add(objs[name],o)
 add(o.regs,name)
end

function group_rem(name,o)
 del(objs[name],o)
 del(o.regs,name)
end

function group(name) return all(objs[name]) end



function all_colors_to(c)
 if c then
  for i=0,15 do
   pal(i,c)
  end
 else
  for i=0,15 do
   pal(i,i)
  end
 end
end

function apply_palmap(pmap,undo)
 if undo then
  for c1,c2 in pairs(pmap) do
   pal(c1,c1)
  end
 else
  for c1,c2 in pairs(pmap) do
   pal(c1,c2)
  end
 end
end

function darken(double,scrn)
 if double then
  for i=0,15 do
   pal(i,drk[drk[i]],scrn)
  end
 else
  for i=0,15 do
   pal(i,drk[i],scrn)
  end
 end
end

function darkout()
 darken(false,1)
 flip()
 flip()
 
 darken(true,1)
 flip()
 flip()
 
 cls()
 flip()
 flip()
end

function darkin()
 _draw()
 flip()
 flip()
 
 darken(false,1)
 flip()
 flip()
 
 for i=0,15 do
  pal(i,i,1)
 end
end

nums={}
for i=0,9 do nums[""..i]=true end
function parse(str,ar)
 local c,lc,ar,field=1,1,{}
 
 while c<=#str do
  local char=sub(str,c,c)
  
  if char=='{' then
   local sc,k=c+1,0
   while sub(str,c,c)~='}' or k>1 do
    char=sub(str,c,c)
    if char=='{' then k+=1
    elseif char=='}' then k-=1 end
    c+=1
   end
   local v=parse(sub(str,sc,c-1))
   if field then
    ar[field]=v
   else
    add(ar,v)
   end
   lc=c+2
   c+=1
  elseif char=='=' then
   field,lc=sub(str,lc,c-1),c+1
  elseif char==',' or c==#str then
   if c==#str then c+=1 end
   local v,vb=sub(str,lc,c-1),sub(str,lc+1,c-1)
   local fc=sub(v,1,1)
   if nums[fc] then v=v*1
   elseif fc=='%' then v=rnd(vb)
   elseif v=='true' then v=true
   elseif v=='false' then v=false
   end
   
   if field then
    if nums[sub(field,1,1)] then field=field*1 end
    ar[field]=v
   else
    add(ar,v)
   end
   
   field,lc=nil,c+1
  elseif char=='\n' then
   lc+=1
  end
  c+=1
 end
 
 return ar
end

function in_box(x,y,x1,y1,x2,y2)
 return x>=x1 and x<x2 and y>=y1 and y<y2
end

function chance(a) return rnd(100)<a end

function merge_arrays(ard,ars)
 for k,v in pairs(ars) do
  ard[k]=v
 end
 return ard
end

function rnd128() return rnd(128) end
function flrnd(a) return flr(rnd(a)) end
function pick(ar,k) k=k or #ar return ar[flr(rnd(k))+1] end

function dist(x1,y1,x2,y2) return sqrt(sqr(x2-x1)+sqr(y2-y1)) end

function tile(x,y) return flr(x/8),flr(y/8) end
function untile(x,y) return x*8+4,y*8+4 end

function ceil(a) return flr(a+0x.ffff) end
function round(a) return flr(a+0.5) end
function lerp(a,b,i) return (1-i)*a+i*b end
function clamp(a,mi,ma) return min(max(a,mi),ma) end
function sqr(a) return a*a end

