lcw=16
sf=128-32
oxy_max=1000
ldp=20
metal=false

function _init()
 reset()
end


function reset()
 music(10)
 
 inboat=false
 ending=false
 title=true
 grab=nil
 
 oxy=oxy_max
 air=5
 
 ents={}
 depth={}
 bubs={}
 logs={}

 clb=0
 beep=0
 pry=0
 mdp=0
 cdp=0
 t=0

 
 lvl=0
 mvy=0
 print_levels() 
  
 hero=mke(64,64,64)--256
 hero.ww=16
 hero.hh=16
 hero.upd=upd_hero
 hero.bnx=bnx_hero
 hero.we=.5
 hero.ol=true
 hero.ls={ 
  5,3,12,3,12,8,12,15,5,15,5,8,
 } 
 hero.dr=dr_hero

 -- hair
 local par=hero
 for i=0,3 do
  local e=mke(0,0,0)
  e.par=par  
  e.dp=0
  e.ol=true
  e.hair=true
  e.upd=upd_hair
  e.dr=function(e,x,y)
   if not hero.ss then return end
   local cl=(e.par==hero or e.par.y+1.5>y) and 8 or 2
   circfill(x,y,4-i,cl)
      
  end  
  par=e  
 end
 
 -- boat
 boat=mke(0,48,96)
 boat.perm=true
 boat.upd=function()
  boat.vis=lvl==0
  local d=(sf-boat.y)
  if abs(d)<16 then
   boat.vy+=d/10
  end
 end
 
 boat.dr=function(e,x,y)
  map(16,16,x,y-4,4,1) 
 end
 
 --
 inboat=true
 
 -- fad
 fad=4
 local f=function(e)
  fad*=.9
  if fad<1 then
   fad=nil
   kl(e)
  end
 end
 loop(f)
 
 
end

function loop(f,t,nxt)
 local e=mke(0)
 e.perm=true
 e.upd=f
 e.life=t
 e.nxt=nxt
 return e
end

function dr_hero(e,x,y)

 if grab then
  local s=e.flp and -1 or 1
  grab.flp=e.flp
  grab.x=x+4+s*8
  grab.y=y+2
  if e.fr>64 then
   grab.x+=s*2
   grab.y-=2
  end
  if e.fr==68 then grab.y-=1 end
  if e.fr==70 then grab.y+=2 end
  if crouch then
   grab.x-=s*6
  end   
  dre(grab)
 end

end

function upd_hair(e)

 if not hero.ss then
  e.x=hero.x+8
  e.y=hero.y+8
  return
 end

 e.y+=.25  
 --e.x+=cos(t/80+e.y/40)*.25
 --e.x+=cos(e.y/20)*.25
 
 
 local px=e.par.x
 local py=e.par.y
 if e.par==hero then
  px+=8
  py+=4
  if crouch then
   py+=5
  end 
  if hero.upd==upd_climb then
   py-=4
  end
     
 end
 local dx=e.x-px
 local dy=e.y-py
 local dd=sqrt(dx*dx+dy*dy)
 if dd>3 then dd=3 end
 local an=atan2(dx,dy)
-- an+=cos(t/80+i/5)*.04
 e.x=px+cos(an)*dd
 e.y=py+sin(an)*dd   

end


function bnx_hero(e)
 
 k=sgn(e.vx)
 
 e.vx=0 
 if e.vy<0 or ground or e.dead then return end
 
 
 crawl()
	for dy=0,15 do
	 if not ecol(e,k,-dy) and ecol(e,k,1-dy) then
	  sfx(6,nil,3,1)
	  cly=e.y+7-dy
	  clx=e.x+k+1
	  clk=k	  
	  e.upd=upd_climb
	  return
	 end
	end
	uncrawl()
	
	
end

function upd_climb(e)
 
 e.vy=0
 e.x+=(clx-e.x)*.5
 e.y+=(cly-e.y)*.5
 

 
 if clk then
		 
		local cb=flr((clk+1)/2)
		 
	 if btnp(4) or btnp(3) or btn(1-cb) then
	 	hero.upd=upd_hero
	 	hero.nograv=nil
	 	uncrawl()   
	 	while ecol(e) do
	 	 e.x-=clk
	 	end
	 	return
	 end		 
			 
		if btn(cb) then
		 clb+=1
		else
		 clb=0
		end 
 
  e.fr=96
	 if clb>=8 then
	  e.fr=98
	  clx+=clk*4
	  cly-=7
	  clk=nil
	  sfx(6,nil,4,1)
	  clb=0
	  e.ccl=4
	 end 
 elseif not e.ccl then
  e.x=clx
  e.y=cly
  e.upd=upd_hero 
 end
end

function upd_drown(e)
 
 
 
 if e.cdrown then
  local c=e.cdrown/100
  e.flp=flr(c*c*100)%12<6  
  if rnd()<c/2 then
		 local b=bub(e.x,e.y)
		 b.vx*=.3
  end
  if e.cdrown < 4*10 then
   fad=4-e.cdrown/10
  end
 else
  reset()
  return
 end

 e.ss=true
 --e.flp=t%16<8
 e.we=-.1
 e.fr=102
 
 if lvl==0 then
  if e.y<sf+2 then e.y=sf+2 end
 end
 

end

function upd_hero(e)
 
 
 
 
 if title then e.ctit=16 end
 
 local sploosh=function(vy)
  if inboat then return end
  local b=bub(e.x+4+rand(8),e.y)
  b.vy+=rnd(vy)
 end
 
 -- oxygen
 if not ending and lvl+(hero.y-sf)>1 then
	 oxy-=1
	 if oxy<=0 then
	  oxy+=oxy_max
	  if air>0 then
	   air-=1
	  else
	   if not hero.ss then
	    destroy_suit()
	   end
	   gameover()	   
	  end
	 end
 end
 
 e.fr=64
 ground=ecol(e,0,1)
 moving=false
 if ground then e.vy=0 end
 
 function hrun(dx)
  local spd=crouch and .2 or .5
  e.vx+=dx*spd
  moving=true
 end
 
 if btn(0) then hrun(-1,0) end
 if btn(1) then hrun(1,0) end
 
 --
 if inboat then
  e.y=boat.y-16
  e.vy=0
  if e.x<boat.x then
   boat.x=e.x
  end
  if e.x>boat.x+16 then
   boat.x=e.x-16
  end
 end
 
 --jump
 if jumping and not btn(4) then
  jumping=false
 end
 
 if e.cjmp and (btn(4) or (e.cbnc and not btn(3) ) ) then
  
  if e.y+24>sf then
  e.vy-=e.cjmp/6 
  end 
 elseif btnp(4) and not jumping then 
  local ok = ground or inboat
  if not ok and air>0 then
   hero.cbreath=20
   hero.cdjp=8
   ok=true
   for i=0,6 do sploosh(2) end
  end
  if ok and not ending then
   if inboat then
    inboat=false
    boat.vy=3.5
    if title then music(0) end
		  title=nil 
		  
   end
   jump()
   sfx(3,nil,1)
  end
 end
 
 -- crouch
 if not crouch and ground and btn(3) then
  crawl()
 end
 if crouch and (not ground or not btn(3)) then
  uncrawl()
  if ecol(e) then
   crawl()
  end
 end 
 --launch/release
 if btnp(5) and grab then
	  sfx(2)
	  launch() 
 end
 
 -- monster cols
 for m in all(ents) do
  if m.hit then
   if hcol(m) then 
    m.hit(e)
   end
  end
 end
 
 -- frame
 if not ground and not inboat then
  e.fr=e.vy>0 and 70 or 68
 elseif moving or crouch then
  e.fr = crouch and 98 or 64
  e.fr += flr((e.x/8)%2)*2
 end
 e.flp=e.vx<0
 
 -- bub 
 if rand(16)==0 then
  sploosh(0)
 end

 -- chk warp
 if e.y<128 and lvl>0 then
  scroll(-1)
 end
 if e.y>384-64  then
  scroll(1)
 end
 
 -- max depth
 cdp=(lvl*128+hero.y)/10-8
 if cdp<0 then cdp=0 end
 if cdp > mdp then
  mdp=cdp
 end
 
 -- chk boat
 if lvl==0 and e.vy>0 and e.x>boat.x and e.x<boat.x+16then
  local by=boat.y-16
  if e.y<by and e.y+e.vy>by then
   inboat=true
   sfx(18)
   boat.vy+=4
   
   if mdp>=ldp then
    ending=true
    hero.ccong=32
    sfx(17)
    music(-1)
   end
  end 
 end
 
 
end

function gameover()
 music(-1)
 sfx(12)
 hero.dead=true
 hero.upd=upd_drown
 hero.cdrown=80
end

function hcol(e)
 for i=0,#hero.ls/2-1 do
  local x=hero.x+hero.ls[1+i*2]
  local y=hero.y+hero.ls[2+i*2]
  if ept(e,x,y) then return true end
 end
 return false
end

function ept(e,x,y)
 return x>=e.x and x<e.x+e.ww and y>=e.y and y<e.y+e.hh
end


function launch()
 
 local e=grab
 
 e.lpx=false
 e.frict=1
 e.vx=hero.flp and -5 or 5
 e.y=hero.y+4
 
 function bnc()
  impact(e.x,e.y,16,true)
  sfx(4)
  bang(e)
  local x,y =find_shell(e.x,e.y)
  if x then open_shell(x,y) end 
 end  
 
 e.upd=function(e)
  e.fr=170+(t/4)%4
  local b =bub(e.x+4,e.y+4)
  b.vx=rnd()*e.vx
  for m in all(ents) do
   if m.hit and ecole(m,e) then
    m.vx=-e.vx
    bang(m)
    bnc() 
   end
  end 
  
  if e.x<0 or e.x+e.ww>128 then
	  bnc()
  end
   
 end
 add(ents,grab)
 

 e.hit=nil
 e.dr=nil
 e.bnx=bnc
 e.bny=bnc
 grab=nil
 
 if ecol(e) then 
  e.fr=170
  bnc()
 end
 
end

function impact(x,y,r,inv)
 shk=6

 local e=mke(0,x,y)
 e.life=6
 e.dr=function(e,x,y)
  local c=e.life/6
  if inv then c=1-c end
  circfill(x,y,r*c,sget(6-e.life,6))
 end
end


function open_shell(x,y,empty)
 sfx(16)
 
 local sl=lvl+flr(y/16)
 hero["shell_"..sl] = true
 
 for dx=0,1 do for dy=0,1 do  
  mset(x+dx,y+dy-1,136+dx+dy*16)
 end end
 
 if empty then 
  return
 end
 
 local b=mke(0,x*8+8,y*8-4)
 --b.we=-.05
 b.r=7
 
 local kk=32
 b.dr=function(e,x,y)
  local ec=2
  if e.frz then
   ec=3*frz/kk
  end
  circ(x,y+sin(t/40)*ec+.5,e.r,7)
 end
 
 local fill=0
 
 b.upd=function(e)
 
 
  local dx=hero.x+8-e.x
  local dy=hero.y+8-e.y 
 
  if e.frz then
   local c=frz/kk
   e.r=c*7
   oxy+=fill
   
   e.x+=dx/kk
   e.y+=dy/kk
   
   return
  end
  

  if sqrt(dx*dx+dy*dy)<12 then
   frz=kk
   e.frz=true
   e.life=kk
   fill=flr((oxy_max-oxy)/kk)
   sfx(9)
  end 
    
 end
 
 
end


function find_shell(x,y)
 local px=flr(x/8)
 local py=flr(y/8)
 --log("find at "..px..","..py)
 for dx=-2,2 do for dy=-2,2 do
  local x=(px+dx)%16
  local y=py+dy
  local n=mget(x,y)
  if n==168 then
   return x,y
  elseif n==169 then
   return (x-1)%128,y
  end
 end end
 return nil

end



function bang(e)
 e.upd=nil
 e.we=.5
 e.vx*=-1
 e.vy=-1-rnd(2)
 e.life=32
 e.blk=true
 e.frict=.96
 e.ls=nil
 e.flx=false
 e.hit=nil
end

function wait(t,f,a,b,c)
 local e=mke()
 e.life=t
 e.nxt=function() f(a,b,c) end
end

function hit_hero(from)
 
 if metal then return end
 
 if hero.cinv then return end
 hero.cinv=32
 from.ckil=16
 frz=16
 sfx(5)
 
 if hero.ss then
  wait(1,gameover)  
 else
  hero.ctrans=2
  hero.ss=true
  hero.vy=-8

  wait(1,destroy_suit)
  
 end
 
 
end

function destroy_suit()
 sfx(8)
 for i=0,5 do
  local p=mke(138+i,hero.x,hero.y)
  p.life=40+rand(20)
  p.we=.1
  p.ol=true
  --p.frz = true
  p.blk=true
  p.frict=.96
  impulse(p,rnd(),2)
 end
end


function impulse(e,an,spd)
 e.vx=cos(an)*spd
 e.vy=sin(an)*spd
end



function jump()

 jumping=true
	hero.vy=-4
	hero.cjmp=16

end

function ecole(a,b) 
 if a.x>b.x+b.ww or
    a.x+a.ww < b.x or
    a.y > b.y+b.hh or
    a.y+a.hh < b.y
 then
  return false
 else
  return true
 end

end

function kl(e)
 del(ents,e)
end

function crawl()
 crouch=true
 hero.ls={ 
  12,8,12,15,5,15,5,8,
 } 
end
function uncrawl()
 crouch=false
 hero.ls={ 
  5,3,12,3,12,8,12,15,5,15,5,8,
 }  
end



function scroll(n)
 lvl+=n 
 for e in all(ents) do
  e.y-=n*128  
 end 
 for e in all(bubs) do
  e.y-=n*128  
 end  
 --print_levels()
  
 -- offset map
 for oy=0,16*3-1 do
  local y=n>0 and 16+oy or 47-oy
  for x=0,15 do
   mmset(x,y-n*16,mget(x,y))
  end  
 end
 
 -- gen new screen
 
 
 local dy=n>0 and 3 or 0
 local k=depth[1+lvl+dy]
 if not k then
  k=rand(9999)
  if dy+lvl==0 then k=-1 end
  add(depth,k)
 end 
 gen_screen(dy,k)
 
 
end

function bub(x,y)
 sfx(1)
 local b={
  x=x,y=y,sz=1+rand(3),
  we=-.05-rnd(.1),
  vx=rnd(3)-1,vy=0,
 }
 add(bubs,b)
 return b
end


function pmov(e,dx,dy) 
 
 if e.bnx then
  bnx = e.bnx
  bny = e.bny
 end
 
 -- ghost
 if ecol(e) and not e.noghost then
  e.x+=dx
  e.y+=dy
  return
 end
 
 -- x
 e.x+=dx
 while ecol(e) do
  e.x-=sgn(dx)
  if bnx then 
   bnx(e)
   bnx=nil 
  end
 end
 
 -- y
 e.y+=dy
 while ecol(e) do
  e.y-=sgn(dy)
  if bny then 
   bny(e)
   bny=nil 
  end  
 end

end

function ecol(e,dx,dy)
 dx=dx or 0
 dy=dy or 0
 if not e.ls then
  return false
 end
 for i=0,#e.ls/2-1 do 
  local x=dx+e.x+e.ls[i*2+1]
  local y=dy+e.y+e.ls[i*2+2]
  if pcol(x,y) then 
   return true 
  end
 end
 return false
end


function pcol(x,y)
 --if x<0 or x>=128 then return true end
 x=x%128
 return fget(mget(x/8,y/8),0)
end

function rand(n)
 return flr(rnd(n))
end

function print_levels()


 for i=0,3 do 
  local k =depth[i+lvl+1]
  if not k then
   k=rand(9999)
   if i+lvl==0 then
    k=-1
   end
   add(depth,k)
  end  
  gen_screen(i,k)
 end
 
 
end


function mmset(x,y,n)
 mset(x,y,n)
end

function gen_screen(dy,k)

 for x=0,15 do for y=0,15 do
  mmset(x,dy*16+y,0)
 end end
 
 -- log
 local clv = lvl+dy
 --log("gen clv:"..clv.." k:"..k.." dy:"..dy)
 
 
 -- empty
 if k<0 then
  return
 end
 
 -- bborders
 for i=0,1 do
  for y=0,16 do
   mmset(i*15,dy*16+y,mget(16,y))
  end
 end
 srand(k)
 local big=true
 
 local plats=3
 if clv>2 and rand(2)==0 then plats-=1 end
 for i=1,10 do
  if clv>i*5 and rand(4)==0 then 
   plats-=1 
  end
 end
 if plats<0 then plats=0 end

 local free=13-(plats+1)*4
 
 local y=dy*16+2
 
 for j=0,plats do 
  --local sx=rand(12)
  --local ex=sx+rand(min(6,15-sx))
  --local y=dy*16+i*(4+rand(2))  
  local size=1+rand(4)+rand(4)
  sx=rand(16)
 
  for i=0,2 do 
	  for dx=0,size do
	   local x=(sx+dx)%16
	   local y=y+i	   
	   local fr=21
	   
	   -- herbs
	   if mget(x,y-1)==0 then
	    fr=16+rand(5)
	   end
	   	   
	   if i==0 then
		   mmset(x,y,fr) 
		   -- wall
		   
		   --[[
			  local h=0
		   for j=1,12 do
		    if mget(x,y-j)>0 then
		     break
		    end
		    h=j
		   end	   
		   if h<8 then
		    for j=1,h do
		     local fr=9+rand(3)
		     if j==h then fr=9 end
		     mmset(x,y-j,fr)
		    end
		   end
		   --]]
		   
		   -- algae
		   if rand(2)==0 then
		    mmset(x,y-1,32+rand(4))
		   end				      
	   else
	    mmset(x,y,fr)
	   end	
	  end
	  

	  -- shells
	  if i==0  then
	   if big and rand(2)==0 then
	    local px=sx+rand(size-1)
	    if px<15 then
		    for i=0,1 do
		     mmset((px+i)%16,y-1,168+i)
		    end	  
		    if hero and hero["shell_"..clv] then
		     open_shell(px%16,y-1,true)
		    end
		    big=false
	    end
	   elseif rand(2)==0 then
	    mk_shell((sx+rand(size))*8,(y-1)*8)
	   end
	  end  
	  
	  -- size change
   if i==0 and rand(size)==0 then
    size+=2
   else
    size=flr(size/1.5+.5)
   end
   sx+=rand(3)-1
  end
  
  if rand(2)==0 then  
   mk_fish(16+rnd(96),(y+3)*8)
  end
  
  
  y+=4
  if free>0 then
	  local f=rand(free)
	 	free-=f
	 	y+=f
 	end
 end 
 
 -- walls 
 for x=0,15 do 
  local wall=0
	 for y=0,15 do 
	  local by=dy*16+15-y
	  
	  if mget(x,by)==21 then
	   for j=0,1 do
		   if not fget(mget(x-(j*2-1),by),0) and
		      not fget(mget(x,by+1),0) then
		    mset(x,by,23-j) 
		   end 
    end
	   
	  end
	  
	  if fget(mget(x,by),0) then	 
	   if wall>=1 and wall<5 then
	    for ny=1,wall do
	    	local fr=9+rand(3)
			   if ny==1 then fr=9 end
			   if mget(x,ny+by)==0 then
	      mset(x,ny+by,fr)
	     end
	    end
	   end  
	   wall=0
	  else  
	   wall+=1
	  end
	 end 
	 
	 
 end 
 

end

function mk_shell(x,y)

 local e=mke(0,x,y)
 e.flp=rand(2)==0
 e.ls={0,0,0,7,7,7,7,0}
 e.ol=true
 local walk=true

 e.upd=function()
  e.fall=not ecol(e,0,1)
  if e.fall then
   e.y+=1
   return
  end
 
  local dx=hero.x-e.x
  local dy=hero.y-e.y 
  walk=abs(dx)>32 or abs(dy)>16
  if not walk then return end
  local k=e.flp and -1 or 1
  local hdy = hero.y-e.y
  local fall = hdy>0 and hdy<128
  if (ecol(e,k*8,1) or fall) and not ecol(e,k) then
   e.x+=k/3
  else
   e.flp=not e.flp
  end  

 
 end
 
 e.dr=function(e,x,y)
  if walk then
	  sspr(88,72,8,4,x,y+4,8,4,e.flp)
	  y-=2
  end
  spr(154,x,y,1,1,e.flp)  
 end
 
 e.hit=function(h)
  
  if ground and not e.fall then
   if btnp(5) and not grab and not e.clv then
    grab=e
    sfx(6,nil,0,2)
    kl(e)
   end
  elseif h.vy>0 or e.fall then
   hit_hero(e)
  end
  
 end
 
 
 
 
end

function mk_fish(x,y)
  
 local e=mke(0,x,y)
 local s=rand(2)*2-1
 e.ww=16
 e.ol=true
 e.flp=rand(2)==0
 e.upd=function(e)
  if e.cpain then return end
  e.x+=(e.flp and -1 or 1)
  if e.x+e.ww>128 or e.x<0 then
   e.flp= not e.flp
   e.x+= (e.flp and -8 or 8)
  end   
 end
 
 e.dr=function(e,x,y)
 
  for i=0,1 do  	
  	local ki=e.flp and i or 1-i
   local fr=31
   if e.cpain then
    fr+=16
   end   
   if ki==1 then 
    fr=28+flr(t/8)%4
    if fr==31 then fr-=2 end
   end  	
   spr(fr,x+i*8,y,1,1,e.flp)
  end
 end
 
	e.hit=function(h)
  if h.vy>0 and h.y+8<e.y then
   h.cbnc=16
   jump()
   sfx(6,nil,9,2)
	  e.cpain=32
	  e.hit=nil
	  e.life=24
	  e.blk=true 
	  e.vy=8
	  e.we=-.5
  else
   hit_hero(e)
  end
 end
 
end



function mke(fr,x,y)
 local e={
  fr=fr or 0,
  x=x or 0, y=y or 0,
  vx=0,vy=0,
  ww=8, hh=8,
  we=0, frict=.8,
  flp=false, dp=1, vis=true,
  lpx=true
 }
 e.bnx=function() e.vx=0 end
 e.bny=function() e.vy=0 end
 
 add(ents,e)
 return e
end

function upe(e)

 if frz and not e.frz then return end

 if not e.nograv then
  e.vy+=e.we
 end
 e.vx*=e.frict
 e.vy*=e.frict
 
 if e.ls then
  pmov(e,e.vx,e.vy)
 else
  e.x+=e.vx
  e.y+=e.vy
 end
 --
 if e.upd then e.upd(e) end
 
 -- counters
 for v,n in pairs(e) do
  if sub(v,1,1)=="c" then
   n-=1
   if n<=0 then
    e[v]=nil
   else
    e[v]=n
   end
  end
 end  
 
 -- life
 if e.life then
  e.life-=1
  if e.life<16 and e.blk then
   e.vis=t%2==0
  end  
  if e.life<=0 then
   kl(e)
   if e.nxt then
    local f=e.nxt
    e.nxt=nil
    f()
   end
  end
 end  
 
 --boundaries
 if (e.y<e.hh or e.y>512) and not e.perm then
  kl(e)
 end
 
 --specific
 if e.cbreath then oxy-=25 end
 
 --loop
 if e.lpx then e.x=e.x%128 end
  
 
end

function dre(e,ddx,ddy)
 ddx=ddx or 0
 ddy=ddy or 0
 if dpt!=e.dp or not e.vis then return end
 local fr=e.fr
 local x=e.x+ddx  
 local y=e.y+ddy
 
 if fget(fr,1) then
  y-=1
 end
 
 if e.ss and (not e.ctrans or t%4<2) then
  fr+=8
 end 

 
 if e.ckil and t%4<2 and ddx+ddy==0then
  apal(8)
 end
  
 local function f(e,x,y)
	 if fr>0 then
	  spr(fr,x,y,e.ww/8,e.hh/8,e.flp)
	 end 
	 if e.dr then e.dr(e,x,y) end
	end	
	f(e,x,y) 
	if e.lpx then
	 if e.x<0 then
	  f(e,x+128,y)
	 end
	 if e.x+e.ww>=128 then
	  f(e,x-128,y)
	 end
 end
 apal()
  
end

function apal(n)
 
 if lockpal then return end
 if not n then 
   for i=0,15 do 

    pal(i,i) 
   end
   return
 end
 for i=0,15 do pal(i,n) end
end

function upb(e)
 e.vx*=.97
 e.vy*=.97
 e.vy+=e.we
 e.x+=e.vx 
 e.y+=e.vy 
 if lvl==0 and e.y<96 then
  e.y=96
  if not e.sf then
   e.sf=true
   e.life=16
  end
 end
 if e.life then e.life-=1 end
 
 if hero.y-e.y > 64 or e.life==-1 then
  del(bubs,e)
 end
 
 
 
end
function drb(e)
 local r=e.sz
 if bfl==7 then r+=1 end
 local y=e.y
 if bfl==1 and e.sf then
  --y+=1
  --r+=1
 end
 
 
 circfill(e.x,y,r,bfl)

end


mmvy=0

function _update()

 t=t+1
 foreach(ents,upe)
 if frz then
  frz-=1
  if frz==0 then frz=nil end
  return
 end
 
 
 foreach(bubs,upb)
 mvy+=hero.vy
 mvy*=.96
 pry+=hero.vy
 
 
 -- algae
 for y=0,7 do
	 for x=0,32 do
	  local n=sget(x,y+24)
	  local ec=2*(1-y/7)
	  local dx=flr(x/8)
	  sset(x+cos(t/32+y/8+dx/4)*ec,y+16,n)
	 end
 end
 
 -- warning
 local wc= 4*oxy/oxy_max
 if air==0 and  wc<1 and not ending then
  
  beep+=(1-wc)/4
  
  if beep>0 then
   beep-=1
   sfx(6,3,6,1)
  end
 end
 
 --ending=true
 if ending then
  
  if btnp(4) or btnp(5) and not hero.ccong then
   reset()
  end
  
  if t%16==0 then
   firework()
  end

 end
end

function firework()  
 local e=mke(137,64,64)
 e.dp=10
 e.ww=1
 e.hh=1
 impulse(e,.25-(rnd(2)-1)/10,5)
 e.we=.1
 e.frict=.96
 e.perm=true
 e.paint=4+rand(4)
 e.upd=function(e)
  if e.vy>0 and rand(4)==0 then
   exp(e)
   sfx(7)
  end
 end
  
end

function exp(b)
 kl(b)
 for i=0,32 do
  local e=mke(0,b.x,b.y)
  impulse(e,i/32,3)
  e.frict=.8+rnd(.18)
  e.life=10+rand(15)
  e.we=.01+rnd(.1)
  e.perm=true
  e.dp=10
  e.lpx=false
  local ox=b.x
  local oy=b.y
  local lm=e.life
  e.dr=function(e,x,y)
   local cl=sget(7-e.life*7/lm,b.paint)
   line(ox,oy,x,y,cl)
   ox=x
   oy=y
  end
  
 end

end


function drol(e)
 if not e.ol then return end
 dpt=e.dp
 apal(1)
 lockpal=true
 dre(e,-1,0)
 dre(e,1,0)
 dre(e,0,1)
 dre(e,0,-1)
 lockpal=false
 apal()

end


function _draw()
 cls(1)

 
 for i=0,15 do
	 local k=i
	 if fad then
	  k=sget(32+i,fad)
	 end
	 if k==5 then k=131 end
  pal(i,k,1)
 end
 
 if ending then
  mvy=-128
 end
 mmvy+= (mvy-mmvy)*.01
 

 -- parallax
 local hcy=hero.y+8-64+flr(mmvy)
 if hcy<0 then hcy=0 end

 for i=0,2 do 
  for k=0,1 do
   for l=1,2 do
    local py=-(pry/(1+l)%128)
    map(16+l,0,l*8+i*(120-2*l*8),py+k*128,1,16)
   end
  end	 
 end
 
 -- sky
 if lvl==0 then
	 clip(0,-hcy/2,127,2+sf-hcy/2)
	 if mdp<ldp then
	  sspr(24,0,8,8,0,0,127,127)
	 else
		 sspr(16,0,8,8,0,40,127,32)
		 rectfill(0,0,127,40,1)
	 end
 end
 
 
 -- cam 
 local cx=0
 if shk then
  cx=shk
  shk*=-.75
  if abs(shk) < 1 then
   shk=nil
  end
 end
 
 camera(cx,hcy)
 
 -- sky
 if lvl==0 then 
  --clip(0,0,127,sf)
  local hy=max(hcy,24)
  dpt=10
  foreach(ents,dre) 
  for i=0,2 do
   if i==1 then apal(3) end
   y=40+(hy-24)*.1*(5-i)   
   map(48-i*16,17,0,y,16,7)
   apal()
  end  
  clip() 
  rectfill(0,sf,127,sf,7) 
 end 
  
 
 -- bg
 map(0,0,0,0,16,64,2) 
 
 
 -- surface
 
 if lvl==0 then
	 for bx=-1,4 do
	  c=0
	  if hero.y>sf then
	   c=(hero.y-sf)/48
	  end  
	  local hh=24*c	  
	  for y=0,hh do
	   local py=y*16/hh 
	   local dx=cos(t/160+py/8)*flr(8*(1-y/hh))
		   --log(y.." : "..py)
		  local ok = y<8 or y%2==0
	   if ok then
	    sspr(32,64+py,32,1,bx*32+dx,sf+1+y,32,1)
	   end
	  
	   --sspr(64,96,32,16,i*32,sf+1,32,16*c)
	  end
	 end	 
 end
 
 
 
 -- bubbles
 bfl=7
 foreach(bubs,drb)
 bfl=1
 foreach(bubs,drb)

 -- outline
 foreach(ents,drol) 
 

 
 
 

 -- map  
 dpt=0
 foreach(ents,dre)  
 map(0,0,0,0,16,64,1)
 dpt=1
 foreach(ents,dre) 
 
 -- inter
 camera()
 if frz and hero.cinv and t%4<2 then
  rect(0,0,127,127,8)
 end 

 if not title then
  disp_inter()
 end
 
 if hero.ctit then
  disp_title() 
 end

 
 -- log
 cursor(0,0,7)
 for l in all(logs) do
  print(l)
 end
 
end

function disp_title()
 
 local c=mid(0,1-(t-16)/16,1)
 c=c*c 
 if c==1 then return end 
  
 local tc=1-hero.ctit/15
 
  
 local a={0,1,1,2}
 for i=0,3 do
  local x=32+i*18
  local y=16+cos(t/80+i/4)*2+.5-tc*(128)
  local dx=(x+4-64)*(1+c*8)
  sspr(32+a[1+i]*16,96,16,32,64+dx-4,y)
 end
 
 if c==0 and title then
  local str="the merciless"
  print(str,64-#str*2,8,1)
 end
 
 
end

function disp_inter()

 if ending then 
  local an=t/40
  local x=64
  if mdp>=10 then x+=4 end
  if mdp>=100 then x+=4 end
  if mdp>=1000 then x+=4 end
  local y=24
  local k=mdp
  m=true
  while true do  
   local n=k%10
   if m then
    m=false
    n=-1
   else
    k=flr(k/10)
   end
	  spr(182+n,x,y+cos(an)*2+.5)
	  an+=.2
	  x-=8   
   if k==0 then
    break
   end
  end  
 elseif mdp<cdp+10 then
  local s=flr(cdp).." m"
  print(s,64-#s*2,1,7)
 else
  sy=1
  if not ending then
   local c=(1-cdp/mdp)*64  
   rectfill(1+c,1,126-c,2,7)
   sy=4
  end
  local s=flr(mdp).." m"
  print(s,64-#s*2,sy,8+t%3)
 end
 
 
 -- oxygen
 local k=24
 local fl=oxy/oxy_max
 for x=0,k-1 do for y=0,k-1 do
  local dx=x-k/2
  local dy=y-k/2
  local an=(atan2(dx,dy)-.25)%1
  local dd=sqrt(dx*dx+dy*dy)
  if dd>7.5 and dd<12 and an<fl then
   local px=x+2
   local py=126+y-k
   local n=pget(px,py)
   local dp= (flr(an*60)%2==0) and 2 or 1
   pset(px,py,sget(n,1))
  end
 end end 
 if hero.cdjp then
  apal(8+t%3)
 elseif air==0 and fl<.25 and t%4<2 then
  apal(8)  
 end 
 spr(182+min(air,9),k/2-1,122-k/2)
 apal()
 
end


-->8
function log(n)
 add(logs,n)
 if #logs>20 then
  del(logs,logs[1])
 end
end