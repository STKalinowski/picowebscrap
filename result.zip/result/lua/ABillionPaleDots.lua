-- a billion pale dots
--   by jakub wasilewski

-- feel free to play with the
-- variables below to get
-- various results - dig
-- deeper into the
-- implementation to make
-- bigger changes.
-- you can also play with the
-- textures/lighting tables 
-- in the sprite memory.

-- center for 3d projection
center_x,center_y=64,56

------------------------------
-- technobabble
------------------------------

technobabble={
 "reversing polarity",
 "adjusting flux capacitor",
 "calculating flight plan",
 "charging ftl drive",
 "plotting course",
 "optimizing warp factors",
 "cooling element zero",
 "priming fuel pumps",
 "loading dilithium crystals",
 "heating ion clusters",
 "dialing the stargate",
 "consulting starcharts",
 "solving hyperspace equations",
 "scanning subspace radio",
 "triangulating starbases",
 "synchronizing ansibles",
 "decohering quantum state",
 "focusing guidance beam",
 "locating mass relay",
 "accounting for stellar drift"
}
for i=1,#technobabble do
 technobabble[i]={
  text=technobabble[i]
 }
end

------------------------------
-- utilities
------------------------------

-- rounds the number to the
-- nearest integer
function round(x)
 return flr(x+0.5)
end

-- linear interpolation from
-- a to b. t=0->a, t=1->b
function lerp(a,b,t)
 return a+(b-a)*t
end

-- random real number
-- between lo and hi
function rndf(lo,hi)
 return lo+rnd()*(hi-lo)
end

-- random number in range
-- with weighting towards the center
function rndw(lo,hi,center_weight)
 local sign,mag=
  rnd()>0.5 and 1 or -1,
  rnd()
 if center_weight==0.5 then
  fac=0.5+sign*sqrt(mag)*0.5
 else
  fac=0.5+sign*mag^center_weight*0.5
 end
 return lerp(lo,hi,fac)
end

-- picks randomly from a 
-- sequence
function rndpick(seq)
 return seq[flr(rnd(#seq)+1)]
end

-- ceiling to complement floor
function ceil(n)
 return -flr(-n)
end

-- prints some text with
-- a chosen alignment,
-- 0.5 - centre, 1 - right align
function printa(t,x,y,c,align)
 x-=align*4*#t
 print(t,x,y,c) 
end

------------------------------
-- class & entity system
------------------------------

-- object is the master "class"
-- it has one method - extend(),
-- which can be used to make
-- new classes.
-- each class also inherits that
-- method, making hierarchies
-- possible.
--
-- new instances are made by
-- calling my_class:new({...}),
-- and the object passed to
-- new contains all properties
-- for the instance.
--
-- class objects can define a
-- create() method that gets
-- called whenever this happens.
--
object={}
 function object:extend(kob)
  -- remember the hierarchy
  kob=kob or {}
  kob.extends=self
  -- add the constructor method
  kob.new=function(self,ob)
   -- set up inheritance
   ob=setmetatable(ob or {},{__index=kob})
   -- call all create() methods
   -- in inheritance order
   local ko,create_fn=kob
   while ko do
    if ko.create and ko.create~=create_fn then
     create_fn=ko.create
     create_fn(ob)
    end
    ko=ko.extends
   end
   -- object ready
   return ob
 	end
 	-- set up inheritance between
 	-- the class objects themselves
 	return setmetatable(kob,{__index=self})
 end

-- returns a function that will
-- update all entities
-- passed in the parameter
function update_system(entities)
 return function()
  for e in all(entities) do
   e:update()
  end
 end
end

-- returns a function that will
-- render all entities
-- passed in the parameter
function render_system(entities)
 return function()
  -- depth-sort for correct
  -- drawing order
  local ordered={}
  for e in all(entities) do
   local o=flr(e.order)
   if o then
	   local tab=ordered[o] or {}
	   add(tab,e)
	   ordered[o]=tab
	  end
  end
  -- draw in z-order
  for z=-10,10 do
   if ordered[z] then
    for e in all(ordered[z]) do
     if e.render then
      e:render()
     end
    end
   end
  end
 end
end

------------------------------
-- 3d projection
------------------------------

-- sets the projection up,
-- tilted about x axis by
-- the angle provided
function init_projection(tilt)
 pryy,pryz,przy,przz=
  cos(tilt),sin(tilt),
  -sin(tilt),cos(tilt) 
end

-- projects a point (x,y,z) 
-- using an ortographic projection
-- also provides z, for depth
-- sorting purposes.
function project(x,y,z)
 local py,pz=
  pryy*y+przy*z,
  pryz*y+przz*z
 return center_x+x,center_y+py,pz
end

------------------------------
-- computing lighting luts
------------------------------

-- number of lighting levels
-- possible
lut_levels=8
-- the index of the "neutral"
-- lighting level - the one
-- that means "no change"
neutral=5

------------------------------

-- grabs the lighting look-up
-- tables from the sprite memory
-- see sprite memory at (40,64)
function init_blend_luts()
 -- palette table coords
 local blx,bly=40,64
 -- base addresses
 local addr
 local even_base,odd_base=
  0x4300,
  0x4300+lut_levels*0x100

 -- lookup tables for even lines
 for even_lut=0,lut_levels-1 do
  addr=even_base+0x100*even_lut
  for byte=0,255 do
   local c1,c2=
    band(byte,0xf),
    flr(shr(byte,4))
   local l1=sget(blx+even_lut*2,bly+c1)
   local l2=sget(blx+even_lut*2+1,bly+c2)
   poke(addr+byte,l1+l2*16)
  end
 end
 
 -- lookup tables for odd lines
 -- different, to achieve
 -- a cross-hatch pattern in
 -- some light levels
 for odd_lut=0,lut_levels-1 do
  addr=odd_base+0x100*odd_lut
  for byte=0,255 do
   local c1,c2=
    band(byte,0xf),
    flr(shr(byte,4))
   local l1=sget(blx+odd_lut*2+1,bly+c1)
   local l2=sget(blx+odd_lut*2,bly+c2)
   poke(addr+byte,l1+l2*16)
  end
 end
 
 blends={}
 for lut=0,lut_levels*2-1 do
  blends[lut]=fl_blend(lut)
 end
end

------------------------------
-- light blending function
------------------------------

-- returns a function that
-- applies the lighting
-- level "l" to a single
-- horizontal line segment.
function fl_blend(l)
 local lutaddr=0x4300+shl(l,8)
	return function(x1,x2,y)
	 -- this function operates
	 -- on screen memory directly
	 local laddr=lutaddr
	 local yaddr=0x6000+shl(y,6)
	 local saddr,eaddr=
	  yaddr+band(shr(x1+1,1),0xffff),
	  yaddr+band(shr(x2-1,1),0xffff)
	 -- odd pixel on left?
	 if band(x1,1.99995)>=1 then
	  local a=saddr-1
	  local v=peek(a)
	  poke(a,
	   band(v,0xf) +
	   band(peek(bor(laddr,v)),0xf0)
	  )
	 end
	 -- full bytes fast loop
	 for addr=saddr,eaddr do
	  poke(addr,
	   peek(
	    bor(laddr,peek(addr))
	   )
	  )
	 end
	 -- odd pixel on right?
	 if band(x2,1.99995)<1 then
	  local a=eaddr+1
	  local v=peek(a)
	  poke(a,
	   band(peek(bor(laddr,v)),0xf) +
	   band(v,0xf0)
	  )
	 end
	end
end

-------------------------------
-- palette effects
-------------------------------

-- creates palettes from
-- tables in sprite memory
-- (at (0,64))
function init_palettes(n)
 -- we keep palettes as
 -- blocks of memory ready
 -- to copy directly into
 -- pico-8 video state
 local addr=0x5800
 for plt=0,n-1 do
  for c=0,15 do
   poke(addr,sget(plt,64+c))
   addr+=1
  end
 end
end

-- sets palette number "no"
function set_palette(no)
 -- modify the pico-8 video
 -- state directly, fast
 memcpy(0x5f00,
  0x5800+shl(flr(no),4),
  16)
end

function set_scr_palette(no)
 -- modify the pico-8 video
 -- state directly, fast
 memcpy(0x5f10,
  0x5800+shl(flr(no),4),
  16)
end

------------------------------
-- precomputing & drawing
-- the lighting
------------------------------

-- this object will be
-- responsible for applying
-- lighting to a planet
lighting=object:extend()
 function lighting:create()
  -- size to fit the planet
  local p=self.target
  local radius=p.size+1
  -- precalculate for later
  self:prepare(radius)
  self.slices=self:scan(radius)
 end

 -- draws the lighting on screen
 -- using normal drawing operations
 -- with each color corresponding
 -- to a light level 
 function lighting:prepare(radius)
  cls()
	 for c in all(self.def) do
	  circfill(
	   64+c[1]*radius,64+c[2]*radius,
	   c[3]*radius,
	   c[4]+1
	  )
	 end
 end
 
 -- remakes the light's circles
 -- into a set of horizontal
 -- light segments suitable
 -- for use with fl_blend
 function lighting:scan(radius)
	 radius+=2
	 -- to support dimming the moon
	 -- when it's in earth's shadow,
	 -- we have several precomputed
	 -- tables for each "dimming"
	 -- level
	 local dlv=
	  self.target.dim_levels
	 local slices={}
	 for i=0,dlv do
	  slices[i]={}
	 end
	 -- scan the screen looking
	 -- for horizontal stretches
	 -- of similar lighting
	 for y=64-radius,64+radius do
	  local lutb=y%2==0
	   and 0 or lut_levels      
	  local prvc,sx=0  
	  for x=64-radius,64+radius+1 do
	   local c=pget(x,y)
	   if c~=prvc then
	    if prvc~=0 then
	     -- new light segment
	     -- store in all the
	     -- "dimming" level
	     -- tables
		    for i=0,dlv do
		     local lutn=max(prvc-1-i,0)
		     -- each slice gets a
		     -- pre-prepared function
		     -- to light it
		     add(slices[i],{
		      sx=sx-64,ex=x-64-1,y=y-64,
		      fl=blends[lutb+lutn]
		     })
		    end
	    end
	    sx,prvc=x,c
	   end
	  end
	 end
	 return slices
 end
 
 -- applies the lighting, with
 -- additional dimming, and at
 -- the right coordinates
 function lighting:apply(dimming,dx,dy,scale)
  if scale==1 then
   self:fast_apply(dimming,dx,dy)
   return
  end
  local ss=self.slices[dimming]
  local n=#ss
  local px,py=-1000
  for i=1,n do
   local s=ss[i]
   local sx,sy,ex=
    flr(s.sx*scale),
    flr(s.y*scale),
    flr(s.ex*scale)
   if py~=sy or sx>px then
    s.fl(sx+dx,ex+dx,sy+dy)
    px,py=sx,sy
   end
  end
 end
 
 function lighting:fast_apply(dimming,dx,dy)
  local ss=self.slices[dimming]
  local n=#ss
  for i=1,n do
   local s=ss[i]
   s.fl(s.sx+dx,s.ex+dx,s.y+dy)
  end
 end

------------------------------
-- helpers for 3d planet
-- precalc
------------------------------

-- does all the actual 3d
-- calculations for planets
-- fills up a "coords" table
-- that will be used to
-- get texturing info later
function prep_planet(p)
 local s=p.size
 local coords={}
 -- go through all latitudes
 for lat=-0.25,0.25,0.003 do
  -- the horizontal scale of 
  -- this "slice" of the
  -- earth sphere
  local scl=cos(lat)
  local sscl=s*scl
  -- texture coords
  local tox,toy,tw,th=
   p.tex_origin.x,
   p.tex_origin.y,
   p.tex_size.w,
   p.tex_size.h
  local tcy=toy+th/2
  -- go through all longitudes
  for long=-0.5,0.5,0.003/scl do
   -- 3d coordinates of this
   -- lat/long on the sphere
   local x,z,y=
    sscl*cos(long),
    sscl*sin(long),
    s*sin(lat)
   -- same coords, after 3d
   -- projection
   local fx,fy,fz=
    project(x,y,z)
   fx,fy=round(fx),round(fy)
   -- texture u/v coords
   -- for this point
   local tx,ty=
    flr(tox+long*tw%tw),
    flr(tcy-lat*2*th)
   -- visible?
   --  ("back-face culling")
   if fz>0 then
    if not coords[fy] then
     coords[fy]={}
    end
    -- store for scan_slices
    coords[fy][fx]={x=tx,y=ty}
   end
  end
 end
 return coords
end

-- takes the 3d data generated
-- by prep_planet and divides
-- the whole sphere into
-- horizontal line segments
-- that can be textured
-- with one sspr() call.
-- this is the whole trick
-- that makes this fast enough.
function scan_slices(p,coords)
 local s=p.size
 local slices={}
 for y,cc in pairs(coords) do
  local sty,sx,stx,ptx=
   nil,nil,nil
  for x=center_x-s-2,center_x+s+2 do
   local ty=cc[x] and cc[x].y
   if ty~=sty then
    if sty then
     local ssx,ssw=sx,x-sx
     if abs(ptx+128-stx)<abs(ptx-stx) then
      ptx+=128
     end
     if ptx<stx then
      ssx,ssw=ssx+ssw,-ssw
      ptx,stx=stx,ptx
     end
     add(slices,{
      sx=ssx-center_x,sw=ssw,sy=y-center_y,
      tx=stx,ty=sty,
      tw=ptx-stx+1
     })
    end
    sx,stx,sty=
     x,cc[x] and cc[x].x,ty
   end
   ptx=cc[x] and cc[x].x
  end
 end
 return slices
end

------------------------------
-- flight control
------------------------------

flightctrl=object:extend({
 order=5,
 flash=7,
 elapsed=0,
})
 function flightctrl:update()
  -- fly towards planet
  -- (if not yet there)
  local prevz=self.z
  self.z=lerp(self.z,1,0.1)
  if (self.z<1.03) self.z=1
  -- propagate
  self.planet.z=self.z
  self.starfield.vz=max((prevz-self.z)*0.2,0.02)
  -- flash
  if self.flash>0 then
   self.flash-=0.25
  end
  -- timekeeping
  self.elapsed+=1/fps
 end
 function flightctrl:render()
  set_scr_palette(flr(8+self.flash))
  if self.elapsed>6 then
   local pt=max(7-(self.elapsed-6)/0.05,0)
   set_palette(flr(pt))
   printa("press ❎ to warp",63,69+self.planet.size,13,0.5)
  end
 end

------------------------------
-- movable starfield
------------------------------

starfield=object:extend({
 order=0
})
 function starfield:create()
  self.stars={}
 end
 function starfield:update()
  if (not self.vz) return
  for i=1,60 do
   local s=self.stars[i]
   if (not s) or s.oob then
    self.stars[i]=self:new_star()
   else
    s.z-=self.vz
   end
  end
 end
 function starfield:new_star()
  local d,a=rndf(20,80),rnd()
  return {
   x=sin(a)*d,
   y=cos(a)*d,
   z=rndf(3,5)
  }
 end
 function starfield:render()
  if (not self.stars[1]) return
  for i=1,#self.stars do
   local s=self.stars[i]
   local sz=max(s.z,0.01)
   local x,y=
    80+s.x/sz,48+s.y/sz
   if s.px then
    local mx,my=
     shr(x+s.px,1),
     shr(y+s.py,1)
    line(x,y,mx,my,5)
    line(mx,my,s.px,s.py,1)
   end
   s.px,s.py=x,y
   s.oob=x<0 or y<0 or x>128 or y>128
  end
 end

------------------------------
-- planet objects
------------------------------

-- the main object - a planet
-- is a sphere that can texture
-- itself and uses light/cloud
-- object to render aftereffects
planet=object:extend({
 order=1,
 x=0,y=0,dim=0,
 dim_levels=0,
 light_def={
	 {0,0,1.07,1},
	 {-0.02,-0.02,0.95,2},
	 {-0.05,-0.05,0.9,3},
	 {-0.08,-0.08,0.84,4},	 
	 {-0.15,-0.15,0.7,5},
	 {-0.2,-0.2,0.6,6},
	 {-0.3,-0.3,0.4,7},
	}
})
 function planet:create()
  -- initialize lighting
  self.light=lighting:new({
   target=self,
   def=self.light_def
  })
  cls()
  -- create the texturing data
  local crds=prep_planet(self,tlt)
  local slcs=scan_slices(self,crds)
  self.s=slcs
  -- texture mask (depends
  -- on texture width)
  self.tmsk=self.tex_size.w-0x0.0001 
  -- initialize clouds
  -- clouds rotate at different
  -- speed to separate the
  -- layers visually
  if self.cloud_count then
   self.clouds=clouds:new({
    target=self,
    count=self.cloud_count,
    speed=-128*
     self.rot/self.tex_size.w
   })
  end
 end
 
 function planet:update()
  -- rotate self
  self.off+=self.rot
  self.off%=self.tex_size.w
  -- ...and the clouds
  if self.clouds then
   self.clouds:move()
  end
 end
 
 function planet:render()
  if (not self.z) return
  local scale=1/self.z
  if (scale<1/self.size) return
  -- find our 2d center
  -- based on 3d coordinates
  local x,y=project(self.x,self.y,self.z)
  x,y=round(x),round(y)
  camera(-x,-y)  
  -- render all the textured
  -- slices
  local slices=self.s
  for si=1,#slices do
   self:render_slice(slices[si],scale)
  end
  -- add the clouds
  if self.clouds then
   self.clouds:overlay()
  end
  camera()
  -- light everything
  self.light:apply(self.dim,x,y,scale)
 end
 
 function planet:render_slice(s,scale)
  -- find the current texture
  -- coordinates for this slice
  -- they change to give
  -- illusion of rotating
  -- the planet is static,
  -- but the texture moves
  -- over its surface instead.
  local tsx=band(s.tx+self.off,self.tmsk)
  local tex=band(tsx+s.tw,self.tmsk)
  -- texture wrapping
  if tex<tsx then
   -- this slice is an unhappy
   -- case that needs 2 sspr()
   -- calls.
   local tw1,tw2=
    self.tex_size.w-tsx,
    tex+1
   local scaled_w,scaled_x,scaled_y=
    -flr(-s.sw*scale),flr(s.sx*scale),s.sy*scale
   local sw1=round(scaled_w*tw1/(tw1+tw2))
   local sw2=scaled_w-sw1
   local sx1,sx2=scaled_x,scaled_x+sw1
   sspr(tsx,s.ty,tw1,1,
    sx1,scaled_y,sw1,1)
   sspr(0,s.ty,tw2,1,
    sx2,scaled_y,sw2,1)
  else
   -- happy case - the whole
   -- slice fits into a single
   -- texture repetition
   local scaled_w,scaled_x,scaled_y=
    -flr(-s.sw*scale),
    s.sx*scale,
    s.sy*scale
   sspr(tsx,s.ty,tex-tsx+1,1,
    scaled_x,scaled_y,scaled_w,1)
  end
 end

------------------------------
-- main loop
------------------------------

fps=60
debug=false
function _init() 
 init_palettes(16)
 init_blend_luts()
 init_projection(0.05)

 new_planet()
end

function _draw()
 if not debug then
	 cls()
	 set_palette(0)
	 if (render_entities) render_entities()
	end
end

function new_planet()
 cls()
 flip()

 _update60,render_entities=
  nil,nil

 -- reset technobabble 
 for tb in all(technobabble) do
  tb.used=false
 end
 
 -- pick a planet type
 local planet_types={
  {name="earthlike",rng=0.75,generate=generate_earthlike},
  {name="gaseous",rng=1,generate=generate_gaseous}
 }
 local r,planet_type=rnd()
 for pt in all(planet_types) do
  if r<pt.rng then
   planet_type=pt
   break
  end
 end
 
 -- generate the planet
 local pd,renderer=
  planet_type.generate() 
 
 -- sneak peek
 printh("=====================")
 printh(planet_type.name)
 for k,v in pairs(pd) do
  if type(v)~="table" then
   printh(k..": "..v.."    ")
  end
 end

 -- render the texture
 render_texture(
  renderer,
  debug and pset or sset,
  0,0
 )
 --cstore()
 
 -- pass onto the function
 -- that will actually make
 -- entities
 -- this inconvenient handover
 -- is for memory-saving
 -- purposes
 _update60=function()
  actually_make_planet(pd)
 end
end

function actually_make_planet(pd)
 -- adapt to chosen fps
 local multiplier=
  60/fps  
 local entities={}
 
 -- create planet object
 if not debug then
  -- mask preparations
  set_scr_palette(16)
  -- generate entities
	 local gaia=planet:new({
	  size=pd.size,
	  off=0,rot=pd.rotation*multiplier,
	  tex_origin={x=0,y=0},
	  tex_size={w=128,h=64}
	 })  
	 local stars=starfield:new()
  local flight=flightctrl:new({
   planet=gaia,starfield=stars,
   z=1000
  })
  -- add to list
		add(entities,flight)
	 add(entities,gaia)
		add(entities,stars)
	end	
 
 -- create the update/render
 -- loops with these entities
 update_fn=
  make_update_fn(entities)
 render_entities=
  render_system(entities)
 
 -- use the right _update
 -- variant for the fps
 if fps==30 then
  _update=update_fn
 else
  _update60=update_fn
 end
end

function make_update_fn(entities)
 local update_entities=update_system(entities)
 return function()
  update_entities()
  if (btnp(4) or btnp(5)) new_planet()
 end
end

-------------------------------
-- simplex noise
-------------------------------

-- various constants and helpers
-- for the simplex noise gen

function v3d(x,y,z)
 return {x=x,y=y,z=z}
end

function v3ddot(grad,x,y,z)
 return grad.x*x+grad.y*y+grad.z*z
end

grad3={
  [0]=v3d(1,1,0),v3d(-1,1,0),v3d(1,-1,0),v3d(-1,-1,0),
  v3d(1,0,1),v3d(-1,0,1),v3d(1,0,-1),v3d(-1,0,-1),
  v3d(0,1,1),v3d(0,-1,1),v3d(0,1,-1),v3d(0,-1,-1)
}

ps={[0]=151,160,137,91,90,15,
131,13,201,95,96,53,194,233,7,225,140,36,103,30,69,142,8,99,37,240,21,10,23,
190, 6,148,247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,57,177,33,
88,237,149,56,87,174,20,125,136,171,168, 68,175,74,165,71,134,139,48,27,166,
77,146,158,231,83,111,229,122,60,211,133,230,220,105,92,41,55,46,245,40,244,
102,143,54, 65,25,63,161, 1,216,80,73,209,76,132,187,208, 89,18,169,200,196,
135,130,116,188,159,86,164,100,109,198,173,186, 3,64,52,217,226,250,124,123,
5,202,38,147,118,126,255,82,85,212,207,206,59,227,47,16,58,17,182,189,28,42,
223,183,170,213,119,248,152, 2,44,154,163, 70,221,153,101,155,167, 43,172,9,
129,22,39,253, 19,98,108,110,79,113,224,232,178,185, 112,104,218,246,97,228,
251,34,242,193,238,210,144,12,191,179,162,241, 81,51,145,235,249,14,239,107,
49,192,214, 31,181,199,106,157,184, 84,204,176,115,121,50,45,127, 4,150,254,
138,236,205,93,222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180}

perm,perm12={},{}
for i=0,511 do
 perm[i]=ps[band(i,0xff)]
 perm12[i]=perm[i]%12
end
skew,unskew=1/3,1/6
unskew2,unskew3=2*unskew,3*unskew

-- the main noise generator function
function simplex3d(x,y,z)
 local n0,n1,n2,n3
 local s=(x+y+z)*skew
 local i,j,k=
  flr(x+s),flr(y+s),flr(z+s)
 local t=(i+j+k)*unskew
 local xo,yo,zo=i-t,j-t,k-t
 local xd,yd,zd=x-xo,y-yo,z-zo

 local i1,j1,k1,i2,j2,k2
 if xd>=yd then
  if yd>=zd then
   i1,j1,k1,i2,j2,k2=
    1,0,0,1,1,0
  elseif xd>=zd then
   i1,j1,k1,i2,j2,k2=
    1,0,0,1,0,1
  else
   i1,j1,k1,i2,j2,k2=
    0,0,1,1,0,1
  end
 else
  if yd<zd then
   i1,j1,k1,i2,j2,k2=
    0,0,1,0,1,1
  elseif xd<zd then
   i1,j1,k1,i2,j2,k2=
    0,1,0,0,1,1
  else
   i1,j1,k1,i2,j2,k2=
    0,1,0,1,1,0
  end
 end

 local x1,y1,z1=
  xd-i1+unskew,
  yd-j1+unskew,
  zd-k1+unskew
 local x2,y2,z2=
  xd-i2+unskew2,
  yd-j2+unskew2,
  zd-k2+unskew2
 local x3,y3,z3=
  xd-1+unskew3,
  yd-1+unskew3,
  zd-1+unskew3
 local ii,jj,kk=
  band(i,0xff),band(j,0xff),band(k,0xff)
 local gi0,gi1,gi2,gi3=
  perm12[ii+perm[jj+perm[kk]]],
  perm12[ii+i1+perm[jj+j1+perm[kk+k1]]],
  perm12[ii+i2+perm[jj+j2+perm[kk+k2]]],
  perm12[ii+1+perm[jj+1+perm[kk+1]]]
 local t0=0.6-xd*xd-yd*yd-zd*zd
 if t0<0 then
  n0=0
 else
  t0*=t0
  n0=t0*t0*v3ddot(grad3[gi0],xd,yd,zd)
 end
 local t1=0.6-x1*x1-y1*y1-z1*z1
 if t1<0 then
  n1=0
 else
  t1*=t1
  n1=t1*t1*v3ddot(grad3[gi1],x1,y1,z1)
 end
 local t2=0.6-x2*x2-y2*y2-z2*z2
 if t2<0 then
  n2=0
 else
  t2*=t2
  n2=t2*t2*v3ddot(grad3[gi2],x2,y2,z2)
 end
 local t3=0.6-x3*x3-y3*y3-z3*z3
 if t3<0 then
  n3=0
 else
  t3*=t3
  n3=t3*t3*v3ddot(grad3[gi3],x3,y3,z3)
 end
 return 32*(n0+n1+n2+n3)
end

function noisegen(seed,scale_x,octaves,scale_y)
 if (not scale_y) scale_y=scale_x
 local base_m=
  2^(octaves-1)/(2^octaves-1)
 return function(x,y,z)
  local n,m,sx,sy=
   0,base_m,scale_x,scale_y
  for o=1,octaves do
   n+=m*simplex3d(x*sx,y*sy,z*sx+seed)
   sx,sy,m=
    shl(sx,1),shl(sy,1),shr(m,1)
  end
  return n
 end  
end

-------------------------------
-- temperature
-------------------------------

-- simple temperature map
-- hotter at equator
-- colder at poles and high up
function assign_temperature(
 height,pd
)
 local average,variation=pd.temp_average,pd.temp_var
 local equator,pole=average+variation,average-variation
 local water_level=pd.water_level
 local factor,ctr_y={},31.5*(1+pd.temp_ctr)
 for y=0,63 do
  factor[y]=abs(y-ctr_y)/31.5
 end
 return function(x,y)
  local asl=height[x][y]-water_level
  if (asl<0) return average
  local base=lerp(
   equator,pole,factor[y]
  )
  return base-asl*0.5
 end
end

-------------------------------
-- terrain
-------------------------------

-- all terrain types, with
-- texturing, bumpmapping data
t_water,t_deep,t_land,t_forest,
t_desert,t_rock,t_snow,t_shrubland=
 {tx=112,ty=96,bump=-0.5,flat=true},
 {tx=32,ty=96,bump=-0.5,flat=true},
 {tx=96,ty=96,bump=0},
 {tx=80,ty=96,bump=0.1},
 {tx=64,ty=96,bump=0},
 {tx=48,ty=96,bump=0.2},
 {tx=112,ty=112,bump=0.2},
 {tx=96,ty=112,bump=0}

-- assigns terrain to each
-- pixel based on various
-- maps we prepared
function assign_terrain(
 height,vegetation,temperature,
 pd
)
 local water_range=1+pd.water_level
 local rock_limit=
  lerp(1,pd.water_level,pd.rockiness)
 return function(x,y)
  local h=height[x][y]
  if h>pd.water_level then
   local t=temperature[x][y]
   if t<-0.3 then
    return t_snow
   elseif t<-0.1 then
    return t_shrubland
   end
   if h>rock_limit then
    -- mountains more bumpy
    height[x][y]=rock_limit+(h-rock_limit)*2
    -- it's rock anyway
    return t_rock
   end
   local v=vegetation[x][y]*pd.vege_var+
    pd.vege_level
   if v<-0.3 then
    return t_desert
   elseif v>0.3 then
    return t_forest
   else
    return t_land
   end
  else
   local depth=(pd.water_level-h)/(1+pd.water_level)
   local deep_p=depth*0.4
   return rnd()<deep_p and
    t_deep or t_water
  end
 end
end

-------------------------------
-- renderers
-------------------------------

-- renders terrain textures,
-- applies lighting on the fly
function terr_render(
 terrain,light
)
 return function(x,y)
  local t,l=
   terrain[x][y],light[x][y]
  local ox,oy=band(x,15),band(y,15)
  local clr=sget(t.tx+ox,t.ty+oy)
  return sget(8+l,104+clr)
 end
end

-- renders a <-1,1> texture
-- using a simple ramp
function ramp_render(tex,ramp_y)
 return function(x,y)
  local v=tex[x][y]
  return sget(8+v*8,ramp_y)
 end
end

-- renders a gaseous planet
-- uses a table of colors
-- to which values in the
-- base texture are mapped
function gas_render(base,colors)
 local ccount=#colors
 local lo,hi=0.5,ccount+0.5
 return function(x,y)
  local v=base[x][y]+rndf(-0.1,0.1)
  local ci=mid(1,ccount,
   lerp(lo,hi,(v+1)*0.5))
  return colors[round(ci)]
 end
end

-------------------------------
-- emboss
-------------------------------

-- pixels used for the
-- emboss filter
emboss_conv={
 {dx=-1,dy=-1,m=-0.33},
 {dx=-1,dy=0,m=-0.33},
 {dx=0,dy=-1,m=-0.33},
 {dx=1,dy=1,m=0.33},
 {dx=1,dy=0,m=0.33},
 {dx=0,dy=1,m=0.33}
}

-- samples a texture at x,y
-- wrapping/clipping properly
function sample(tex,x,y)
 x,y=
  band(x,127),mid(y,0,63)
 return tex[x][y]
end

-- applies a 3d lighting effect
-- prebaked into a texture
function emboss(height,terrain,starkness)
 return function(x,y)
  local t=terrain[x][y]
  if t.flat then
   return 0
  end
  local here=height[x][y]+t.bump
  local v=0
  for e in all(emboss_conv) do
   local diff=
    sample(height,x+e.dx,y+e.dy)+
    sample(terrain,x+e.dx,y+e.dy).bump-
    here
   v+=diff*e.m*starkness
  end
  return mid(v,-8,8)
 end
end

-------------------------------
-- generation
-------------------------------

color_starters={
 1,2,3,4,8,9,11,14
}
color_neighbours={
 [0]={1},
 {0,2,5,3},
 {1,4,8},
 {5,11},
 {2,9,8},
 {1,3},
 {5,7},
 {6,10,15},
 {9,14,4,2},
 {8,10,4,15},
 {9,7,11,15},
 {3,7,10,15},
 {},
 {},
 {15,8,9},
 {10,7,14}
}
function generate_gaseous_pd()
 local colors={rndpick(color_starters)}
 for i=2,5 do
  colors[i]=rndpick(color_neighbours[colors[i-1]])
 end
 
 local pd={
  colors=colors,
  smear=rndw(0.05,0.45,2),
    
  seed=rnd(255),
  size=round(rndw(30,34,1)),
  rotation=0.5
 }
 return pd
end

function generate_gaseous()
 local pd=generate_gaseous_pd()
 -- generate maps
 local base=texture(
  noise(pd.seed,pd.smear,3,3)
 )
 -- return renderer
 return pd,gas_render(base,pd.colors)
end

function generate_earthlike_pd()
 local pd={
  water_level=rndw(-0.9,0.55,3),
  vege_level=rndw(-1.3,1.3,1),
  vege_var=1-abs(rndw(-1,1,3)),
  rockiness=rndw(0.1,0.9,3),
  temp_average=rndw(-1,1,2),
  temp_var=rndw(0,1,2),
  temp_ctr=rndw(-0.5,0.5,3),
  
  seed=rnd(255),
  size=round(rndw(27,33,1)),
  rotation=0.5,
 }
 return pd
end

function generate_earthlike()
 -- generate planetary data
 local pd=generate_earthlike_pd()
 -- generate maps
 local height=texture(
  noise(pd.seed,0.96,3)
 )
 local vegetation=texture(
  noise(pd.seed+1,0.64,1)
 )
 local temperature=texture(
  assign_temperature(height,pd)
 )
 local terrain=texture(
  assign_terrain(
   height,vegetation,temperature,
   pd
  )
 )
 local light=texture(
  emboss(height,terrain,20)
 )
 
 -- render the final texture
 --return pd,ramp_render(temperature,96)
 return pd,terr_render(
  terrain,light
 ) 
end

-- generates 2d noise texture
-- with proper wrapping
function noise(...)
 local ng=noisegen(...)
 return function(tx,ty)
	 local lng,lat=
	  tx/128,(ty-31.5)/126
	 local y,scl=-sin(lat),cos(lat)
	 local x,z=scl*sin(lng),scl*cos(lng)
	 return ng(x,y,z)
 end
end

-- generates a texture using
-- an f(x,y) function
function texture(fn)
 local tex={}
 cls()
 rectfill(16,64,111,64,1)
 
 local tb
 repeat
  tb=rndpick(technobabble)
 until not tb.used
 printa(tb.text,64,56,13,0.5)
 tb.used=true
 
 for x=0,127 do
  tex[x]={}
  for y=0,63 do
   tex[x][y]=fn(x,y)
  end
  pset(16+x*0.75,64,8)
 end
 return tex
end

-- renders a texture generically
-- using a mapping function and
-- an output function
function render_texture(color_fn,out_fn,xs,ys)
 for x=0,127 do
  for y=0,63 do
   out_fn(xs+x,ys+y,color_fn(x,y))
  end
 end 
end

