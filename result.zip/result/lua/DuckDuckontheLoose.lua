--duck duck on the loose
--sean s leblanc

function range(v)
 return rnd(max(0,v[2]-v[1]))+v[1]
end

function lerp(from,to,t)
 return from+t*(to-from)
end

function ease(t)
 if t >= 0.5 then
  return (t-1)*(2*t-2)*(2*t-2)+1
 else
  return 4*t*t*t
 end
end

function v_add(a,b)
 return {a[1]+b[1],a[2]+b[2]}
end
function v_sub(a,b)
 return {a[1]-b[1],a[2]-b[2]}
end
function v_mul(v,s)
 return {v[1]*s,v[2]*s}
end
function v_div(v,s)
 if s != 0 then
  return {v[1]/s,v[2]/s}
 else
  return {0,0}
 end
end
function v_len2(v)
 return v[1]*v[1]+v[2]*v[2]
end
function v_len(v)
 return sqrt(v_len2(v))
end
function v_lenm(v)
 return abs(v[1])+abs(v[2])
end
function v_normalize(v)
 return v_div(v,v_len(v))
end
function v_lerp(a,b,t)
 return{lerp(a[1],b[1],t),lerp(a[2],b[2],t)}
end
function v_dist(a,b)
 return v_len(v_sub(a,b))
end
function v_distm(a,b)
 return v_lenm(v_sub(a,b))
end
function hex(num)
 if num>9 then
  num-=9
  num=sub("abcdef",num,num)
 end
 return num
end

function add_biome(
 colour,tree_range,bush_props,transition,footprints)
 
 biomes[colour]={
 tree_range=tree_range,
 transition=transition,
 bush_props = bush_props,
 footprints=footprints[1],
 foot_sfx=footprints[2],
 building_freq=0
 }
end

function _init()
 music(0,1000,3+4)
 srand"4"
 seed=rnd()
 palt(0,false)
 palt(14,true)
 
 shadow_offset=v_normalize({2,3})
 
 shadow_offset=v_mul(shadow_offset,0.2)
 
 perspective_offset={64,80}
 height_mult=0.015
 
 cell_size=32
 cells={}
 cell_bounds=128
 cell_bound_str=2
 cell_fill=flr(128/cell_size+0.5)
 
 
 biomes={}
 for i=0,15 do
  add_biome(i,{0,0},{0,0,{}},false,{true,3})
 end
 add_biome(14,{0,0},{0,0,{}},true,{true,0})
 add_biome(1,{0,0},{0,0,{}},true,{false,1})
 add_biome(12,{0,0},{0,0,{}},false,{false,1})
 add_biome(3,{0.25,0.3},{0.5,05,{8,12,13,10}},true,{true,0})
 add_biome(4,{0,0},{0,0,{}},true,{true,3})
 add_biome(5,{0,0},{0,0,{}},false,{false,2})
 add_biome(6,{0,0},{0,0,{}},false,{false,2})
 add_biome(7,{0,0.1},{0.1,0,{}},true,{true,3})
 add_biome(11,{0.1,0.3},{0.5,0.8,{8,12,13,10}},true,{true,0})
 add_biome(15,{0,0.2},{0.2,0.2,{11,13}},true,{true,3})
 add_biome(10,{0,0},{0,0,{}},true,{true,3})

 biomes[10].building_freq=0.8
 biomes[15].building_freq=0.01
 
 trees={
 height_range={10,25},
 girth_range={4,10},
 gap=16
 }
 
 clouds={}
 c_height_range={45,50}
 c_count_range={20,40}
 c_radius_range={5,15}
 c_cluster_range={5,7}
 c_size=256
 
 bushes={}
 bushes_height_range={0.5,1.5}
 bushes_count_range={10,30}
 bushes_radius_range={1,2.5}
 bushes_cluster_range={2,4}
 
 buildings={}
 buildings_height_range={10,35}
 buildings_w_range={8,min(cell_size,cell_size)-16}
 buildings_h_range={8,min(cell_size,cell_size)-16}
 buildings_colours={8,9,6}
 
 p={
 p=v_mul({82,16},32),
 v={0,0},
 speed={0.7,0.7},
 max_speed=3,
 cur_speed=0,
 damping=0.8,
 a=0.75,
 a_o=0,
 stride_w=4,
 stride_l=12,
 stride_alt=false,
 height=4,
 quack_timer=0,
 c={0,0,0},
 duck=-1,
 ducklings={}
 }
 
 ducklings={
 height=3,
 r=2,
 found=0,
 found_timer=0
 }
 
 add(ducklings,{
  p=v_add(v_mul({23,60},32),{rnd(cell_size),rnd(cell_size)})
 })
 add(ducklings,{
  p=v_add(v_mul({118,8},32),{rnd(cell_size),rnd(cell_size)})
 })
 add(ducklings,{
  p=v_add(v_mul({26,105},32),{rnd(cell_size),rnd(cell_size)})
 })
 add(ducklings,{
  p=v_add(v_mul({69,82},32),{rnd(cell_size),rnd(cell_size)})
 })
 add(ducklings,{
  p=v_add(v_mul({118,105},32),{rnd(cell_size),rnd(cell_size)})
 })
 add(ducklings,{
  p=v_add(v_mul({32,19},32),{rnd(cell_size),rnd(cell_size)})
 })
 add(ducklings,{
  p=v_add(v_mul({107,84},32),{rnd(cell_size),rnd(cell_size)})
 })
 
 p.r=4 
 p.r2=p.r*p.r
 cam={
 p=v_sub(p.p,{64,64+128}),
 c={0,0},
 offset={64,64},
 sway={0.25,0.25,8,9}
 }
 cam.p_o=cam.p
 
 cells.current={
  flr(cam.p[1]/cell_size),
  flr(cam.p[2]/cell_size)
 }
 
 mapdata_string=""
 for i=0x2000,0x2fff do
  local a=shr(band(peek(i),0xf0),4)
  local b=hex(band(peek(i),0x0f))
  for j=1,a do
   mapdata_string=mapdata_string..b
  end
 end
 
 mapdata={}
 local x=cell_bounds-1
 local y=-1
 while #mapdata_string > 0 do
  x+=1
  if x==cell_bounds then
   x=0
   y+=1
   if y==cell_bounds then
    break
   end
   mapdata[y]={}
  end
  
  local s=sub(mapdata_string,1,1)
  mapdata[y][x]=("0x"..s)+0
  mapdata_string=sub(mapdata_string,2,#mapdata_string)
 end
 init_cells()
 
 footprints={
  {0,0},
  {0,0},
  max=64,
  remove_delay=0.25,
  remove_last=time()
 }
 for i=3,footprints.max-1,2 do
  footprints[i]=footprints[1]
  footprints[i+1]=footprints[2]
 end
 
 for i=1,range(c_count_range) do
  local x=rnd(c_size*2)
  local y=rnd(c_size*2)
  local r=0
  for j=1,range(c_cluster_range) do
   local c={
    r=range(c_radius_range),
   }
   c.p={
    x+range({1,(c.r+r)/2})-range({1,(c.r+r)/2}),
    y+range({1,(c.r+r)/2})-range({1,(c.r+r)/2})
   }
   
   if rnd() > 0.5 then
    x=c.p[1]
    y=c.p[2]
    r=c.r
   end
   c.height=range(c_height_range)
   c.s=c.p
   
   add(clouds,c)
  end
 end
 
 npcs={
 	{who="drake",spr=1,
 	mouth=-1,mouth_offset=0,
 	c1=4,c2=3,r=3,height=2,
  cell={81,15},
 	lines="duck duck! we need your help!|we lost our babies!!!!!|we had eight before, but now we only have one!|i don't know what happened to the rest!|i'm staying here to keep track of the last one.|please find the other seven!|we're counting on you\nduck duck!|...|if you don't know where to look...|try the city west of us.|"},

 	{who="hen",spr=0,
 	mouth=-1,mouth_offset=0,
 	c1=6,c2=4,r=3,height=2,
  cell={83,15},
 	lines="duck duck! you need to find our babies!|we lost them!!!!!|one's here, but seven are out there all alone!|you've got to find them!|don't let us down duck duck!|...|i wonder if they went to the town east of our lake?|"},

 	{who="duckling",spr=2,
 	mouth=-1,mouth_offset=0,
 	c1=9,c2=10,r=2,height=2,
  cell={81,16},
 	lines="hi duck duck!|are you going to find my brothers and sisters?|they're hiding somewhere around here...|i'll let you know if i see them!|good luck duck duck!|"},

 	{who="chevy",spr=15,
 	mouth=0,mouth_offset=0,
 	c1=3,c2=8,r=5,height=4,
  cell={53,52},
  lines="oi, duck duck.|you seen tom?|i caught the rascal sneaking through winter supplies.|i chased him out of town...|but lost him when he cut through the river.|make sure to let me know if you see him, you hear?|...|he'll have to come back at some point...|"},

 	{who="spooky ghost",spr=14,
 	mouth=7,mouth_offset=0,
 	c1=7,c2=6,r=3,height=4,
  cell={17,77},
  lines="hi duck duck!|how's it going?|keeping busy?|you always were a go-getter.|never could sit still...|that's not really my style, you know?|i tend to stay put.|course, i always appreciate visitors.|drop by anytime!|"},

 	{who="giddy girl",spr=13,
 	mouth=0,mouth_offset=2,
 	c1=10,c2=8,r=3,height=2,
  cell={101,8},
  lines="hey duck duck!|whatcha up to?|are you playing a game?|can i play too?!|i'm really good at games!!|my parents said i can't leave the city though.|does that mean i can't play with you?|...|what's it like outside?|are there lots of kids like me?|or are they all ducks like you?|that'd be weird!|i'm glad i'm not a duck.|...|...|could i go out on my own like you if i was a duck?|"},

 	{who="helenista",spr=12,
 	mouth=0,mouth_offset=0,
 	c1=13,c2=15,r=3,height=4,
  cell={50,39},
  lines="hmph.\nduck duck.|i see you're doing well.|...|...|don't think i've forgotten what happened last time.|things don't just fix themselves overnight.|i certainly haven't forgiven you either.|...|look, i appreciate you're making an effort...|but i can't do this right now.|-you- can't do this right now.|i've heard the rumours.|i see the way you walk through town.|more importantly:\ni know you duck duck.|do you even know how long it's been?|do you care?|of course you don't.|you never did.|maybe someday you'll realize why that matters.|i hope, for your sake, that you do.|until then, i'd really rather not talk to you.|...|...|just... just drop it, duck duck.|"},

 	{who="tommy tim-tom",spr=11,
 	mouth=0,mouth_offset=0,
 	c1=1,c2=15,r=4,height=4,
  cell={58,58},
  lines="duck duck, buddy!|how's it going?|on a noble adventure, i see!|i know how that goes...|but that life's not for your ol' pal tommy!|leave the adventurin' to the birds, i always say!|speaking of birds...|what's up with those ducklings?|i saw one headed out west earlier...|course i didn't follow!|birds know best, as i always say!|or is it \"birds know west\"?|...|well, i'll let you get back to it...|best o' luck duck duck!|"},

 	{who="swimmer",spr=10,
 	mouth=0,mouth_offset=-4,
 	c1=10,c2=13,r=4,height=3,
  cell={28,84},
 	lines="oh! duck duck!|what a great day for a swim.|wouldn't you agree?|i've been doing calisthenics here every day.|i feel so much better for it!|so full of energy!|swimming is such great exercise.|though i'm sure you already knew that!\nha ha!|...|my friends think i'm crazy for doing this.|they say it's dangerous to be out here alone.|they keep telling me but i just ignore them.|it's like water off a duck's back!|ha ha!|...|thanks for the visit...|but i should get back to exercising.|see you around duck duck!|"},

 	{who="chuck",spr=9,
 	mouth=0,mouth_offset=-4,
 	c1=9,c2=15,r=4,height=4,
  cell={42,15},
  lines="duck duck!|what did i tell you last time!?|i don't care what the others say.|no freeloaders allowed!|uh uh, no exceptions!|like 'em or not, those're the rules.|...|don't pretend you don't know what i'm talking about!|think i'm gonna let ducklings lounge in our park?|if they're not gone today, it's your head!|and you bet your butt that's a threat.|look at you, acting all high and mighty...|you ain't mighty duck duck!|you're on thin ice.|thin.\n\nice.|"},

  {who="pupperino",spr=8,
  mouth=0,mouth_offset=0,
  c1=4,c2=4,r=3,height=2,
  cell={23,61},
  lines="greetings duck duck.|your kind is very disruptful.|the peaceful clearing should not be disrupted.|please leave, and take your kin with you.|"},

  {who="pupperoni",spr=8,
  mouth=0,mouth_offset=0,
  c1=4,c2=4,r=3,height=2,
  cell={23,61},
  lines="hello duck duck.|please take your young and leave.|this clearing is a place of peace.|a peace which your kind now disturbs.|begone.|"},

  {who="doggo",spr=8,
  mouth=0,mouth_offset=0,
  c1=4,c2=4,r=3,height=2,
  cell={24,62},
  lines="hey duck duck.|sorry about the others.|they take the \"peaceful clearing\" very seriously.|you don't really need to worry.|they're too lazy to kick you out themselves.|but you should probably head out anyway.|talk to you later duck duck.|"},

 	{who="pen",spr=7,
 	mouth=0,mouth_offset=0,
 	c1=2,c2=4,r=4,height=4,
  cell={91,46},
  lines="duck duck.|sometimes i worry about the future.|things can change so fast...|what will the world be like when i'm gone?|it used to stress me out.|but then i remembered:|i won't even be around to reflect on it!|so why worry?|...|...now that i say that out loud...|i'm realizing that's actually even more worrying.|hmm.|...|i, uh...|i might need a minute to let that one digest.|hmm...|"},

 	{who="barbara",spr=6,
 	mouth=2,mouth_offset=0,
 	c1=8,c2=10,r=4,height=3,
  cell={107,8},
  lines="hi there! you must be duck duck.|are you looking for those ducklings from earlier?|i think most of them left already.|they were super cute!|...|...|do you ever wonder if you waited too late to have kids?|...|ha ha! me neither!|...|...|life here is pretty nice, don't you think?|"},

 	{who="buddy boy",spr=5,
 	mouth=0,mouth_offset=2,
 	c1=12,c2=15,r=3,height=2,
  cell={26,26},
  lines="duck duck!|ha ha!|hey, guess what?|can you guess?|i bet you can't!\nha ha!|you're a duck!|ha ha!|"},

 	{who="ranger",spr=4,
 	mouth=0,mouth_offset=0,
 	c1=3,c2=15,r=4,height=4,
  cell={106,69},
  lines="hoi duck duck!|what's the news from the lake?|anything to report?|it's been pretty quiet in these parts.|couple ruffians came through earlier...|nothing i couldn't handle though!|i sent them packing down south, yes i did!|youngsters like that have no business in these woods!|all running about as if they own the place...|no respect for nature!|not at all like you duck duck.|i can always count on you to get things done right!|...|best let you get back to it duck duck!|"},

 	{who="scarves mcgee",spr=3,
  mouth=0,mouth_offset=0,
  c1=5,c2=4,r=4,height=4,
  cell={37,26},
  lines="hello duck duck!|how are you today?|i'm taking a personal day...|get me some me time, you know?|oh, speaking of which...|i saw a couple ducklings strolling through town.|looked like they were making a day of it!|i doubt they both stuck around though.|not much space around here...|anyway, nice catching up with you.|make sure to hit me up next time you're in town!|...|...|...i wonder if i should get a new scarf...|"},

 {who="mountain climber",spr=16,
  mouth=0,mouth_offset=0,
  c1=1,c2=8,r=4,height=4,
  cell={107,83},
  lines="wow duck duck!|you climbed this mountain too?|impressive!|isn't it great here? we're so far up!|so far away from everything...|it was quite a hike!|one slip and that would've been it for me!|...|i hope we'll have a safe trip back to base camp.|wouldn't want them to send a rescue team after us!|...|*sigh*|i know, duck duck.|i know it's all flat.|but... let me have this moment, okay?|...|thanks duck duck.|...|...|i think i can see my house from here!|"},

 {who="chateau",spr=18,
  mouth=7,mouth_offset=2,
  c1=0,c2=0,r=3,height=2,
  cell={37,32},
  lines="bonjour duck duck!|comment ca va?|bien? bien!|"},

 {who="chatelain",spr=17,
  mouth=0,mouth_offset=2,
  c1=10,c2=9,r=3,height=2,
  cell={115,42},
  lines="salut duck duck!|voulez-vous l'aide?|non?|d'accord, je reste ici!|me parler encore si tu besoin d'aide.|...|voux parlez francais, oui?|"},

 {who="maximillian",spr=19,
  mouth=0,mouth_offset=0,
  c1=0,c2=15,r=4,height=4,
  cell={54,32},
  lines="welcome back duck duck!|i hope things are going well for you.|things here are better than ever!|don't you worry about us.|surely you've got other things to do anyway.|oh!|ducklings!!|we had some duckling guests earlier!|i think one of them is still here...|a couple left to the south a little while ago.|you should probably go check that out.|...|yep, definitely don't need help here right now.|"},

 {who="poctling",spr=20,
  mouth=0,mouth_offset=2,
  c1=0,c2=13,r=4,height=3,
  cell={83,110},
  lines="duck duck.|you were not expected, duck duck.|"},

 {who="poctling",spr=21,
  mouth=0,mouth_offset=0,
  c1=0,c2=13,r=4,height=3,
  cell={96,107},
  lines="duck duck.|you were not invited, duck duck.|"},

 {who="poctling",spr=22,
  mouth=0,mouth_offset=0,
  c1=0,c2=13,r=4,height=4,
  cell={95,113},
  lines="duck duck.|you were not allowed, duck duck.|"},

 {who="poctling",spr=23,
  mouth=0,mouth_offset=0,
  c1=0,c2=13,r=4,height=4,
  cell={102,109},
  lines="duck duck.|you are trespassing, duck duck.|"},

 {who="poctling",spr=22,
  mouth=0,mouth_offset=0,
  c1=0,c2=13,r=4,height=4,
  cell={108,107},
  lines="duck duck.|you are intruding, duck duck.|"},

 {who="poctling",spr=21,
  mouth=0,mouth_offset=0,
  c1=0,c2=13,r=4,height=3,
  cell={112,114},
  lines="duck duck.|you are violating, duck duck.|"},

 {who="poctling",spr=20,
  mouth=0,mouth_offset=2,
  c1=0,c2=13,r=4,height=3,
  cell={118,110},
  lines="duck duck.|this place is not for you, duck duck.|this place is not for your younglings, duck duck.|collect them, duck duck.|collect them and leave, duck duck.|"},

 {who="worker",spr=31,
  mouth=-1,mouth_offset=0,
  c1=10,c2=12,r=4,height=4,
  cell={18,84},
  lines="what's up duck duck?|oh...|oh hey! check it out!|duck duck's on the dock!|heh.|hehe!|ha ha ha ha!|haaa...|man, i crack myself up.|"},

 {who="worker",spr=31,
  mouth=-1,mouth_offset=0,
  c1=10,c2=12,r=4,height=4,
  cell={32,100},
  lines="duck duck?! you shouldn't be out here!|it's really dangerous!|you aren't wearing protective gear or anything!|ohhh - if my supervisor sees you they're gonna flip.|we already had one duck come through here...|that didn't go over well at all!|look, you need to get a move on.|this is no place for ducks!|not even you duck duck!|oh man i'm going to be in sooo much trouble...|"},

 {who="debbie",spr=28,
  mouth=0,mouth_offset=0,
  c1=2,c2=4,r=4,height=4,
  cell={64,88},
  lines="have you seen this garden maze duck duck?|i thought it'd be fun to explore...|but you can just walk between the trees!|it's kind of lame, honestly.|major let-down. a 6/10 at best.|you can quote me on that.|looks like that feathery kid had fun at least.|so not a total waste of space.|...|i wonder who organized this thing...|"},

 {who="curious child",spr=27,
  mouth=0,mouth_offset=2,
  c1=3,c2=4,r=3,height=2,
  cell={106,6},
  lines="um, you're duck duck, right?|my dad said i'm not supposed to talk to strangers...|especially ones from out of town...|but can i ask you something?|um...|do i reaaalllly need to go to bed when the sun goes down?|cause sometimes, i'm just not tired!|...|i think my dad's a liar.|"},

 {who="signpost",spr=24,
  mouth=-1,mouth_offset=0,
  c1=4,c2=4,r=4,height=4,
  cell={71,108},
  lines="the sign says:|new poctridge|"},

 {who="signpost",spr=24,
  mouth=-1,mouth_offset=0,
  c1=4,c2=4,r=4,height=4,
  cell={103,12},
  lines="the sign says:|obblesville|"},

 {who="signpost",spr=24,
  mouth=-1,mouth_offset=0,
  c1=4,c2=4,r=4,height=4,
  cell={31,19},
  lines="the sign says:|ackelsby park|"},

 {who="faded signpost",spr=24,
  mouth=-1,mouth_offset=0,
  c1=4,c2=4,r=4,height=4,
  cell={36,78},
  lines="the sign says:|pol r1 gf|"}
 }
 
 for npc in all(npcs) do
  npc.p={rnd(cell_size),rnd(cell_size)}
  npc.r2=npc.r*npc.r
  
  if npc.cell==nil then
   npc.cell={flr(rnd(cell_bounds)),flr(rnd(cell_bounds))}
  
   -- put unset npcs in top-left
   npc.cell={flr(rnd"6"),flr(rnd"6")}
  end
  
  npc.sfx=flr(rnd"2")+10
  
  npc.lines=npc.lines or "oh hey duck duck!|this is just some test dialog.|it's the same for every character!|i'm just gonna say this now.|"
  
  -- add breaks into lines
  -- (no word breaks)
  local l=npc.lines
  local lw=0
  local ww=0
  local word=""
  npc.lines=""
  while #l > 0 do
   --get next letter
   local c=sub(l,1,1)
   l=sub(l,2,#l)
   word=word..c
   
   -- word ends
   if c==" " or c=="\n" or c=="|" or #l==0 then
    if #word+lw>16 then
     npc.lines=npc.lines.."\n"
     lw=0
    end
    
    npc.lines=npc.lines..word
    lw+=#word
    word=""
    -- newline characters
    if c=="\n" or c=="|" then
     lw=0
    end
   end
  end
  
  -- save the last line for repeating
  local l=#npc.lines
  repeat
   l-=1
  until sub(npc.lines,l,l) == "|"
  npc.lastline = sub(npc.lines,l,#npc.lines)
 end
 
 talk={
  npc=nil,
  bounce=0,
  say="",
  said="",
  offset_target=40
 }
 talk.offset=-talk.offset_target
 
 menu=0
end

function init_cells()
 
 
 cells.a={}
 for a=0,cell_fill do
 cells.a[a]={}
 for b=0,cell_fill do
 local c={}
 cells.a[a][b]=c
 
 local x=a+cells.current[1]
 local y=b+cells.current[2]
 
 -- seed the rng based on cell position
 c.seed=seed+x*(cell_bounds*2)+y
 srand(c.seed)
 
 if x<0 or x>cell_bounds-1 or y<0 or y>cell_bounds-1 then
  c.c=1
 else
  c.c=mapdata[y][x]
 end
 c.c=c.c or 1
 c.biome=biomes[c.c]
 
 -- get colours for edge transition
 c.edges={}
 for u=-1,1 do
  c.edges[u]={}
 for v=-1,1 do
  if x+u<0 or x+u>cell_bounds-1 or y+v<0 or y+v>cell_bounds-1 then
   c.edges[u][v]=1
  else
   c.edges[u][v]=mapdata[y+v][x+u]
  end
  if c.edges[u][v]==14 then
   c.edges[u][v]=3
  end
  c.edges[u][v]=c.edges[u][v] or 1
  
 end
 end
 
 
 c.trees={}
 local tree_freq=ease(range(c.biome.tree_range))
 
 c.bushes={}
 
 if c.c==14 then
  -- boundaries
  c.c=3
  local t={
   height=range(trees.height_range),
   girth=min(cell_size,cell_size)*2/5,
   p={
    cell_size/2,
    cell_size/2
   },
   leaves={{0,0},{0,0},{0,0}}
  }
  t.s=t.p
   
  add(c.trees,t)
 else
  -- normal cell
  
  --trees
  for x=0,cell_size-trees.gap,trees.gap do
  for y=0,cell_size-trees.gap,trees.gap do
   if rnd() < tree_freq then
    local t={
     height=range(trees.height_range),
     girth=range(trees.girth_range),
     p={
      x+rnd(trees.gap),
      y+rnd(trees.gap)
     },
     leaves={{0,0},{0,0},{0,0}}
    }
    t.p={
    mid(t.girth,t.p[1],cell_size-t.girth),
    mid(t.girth,t.p[2],cell_size-t.girth)
    }
    t.s=t.p
    add(c.trees,t)
   end
  end
  end
  
  --bushes
  if rnd() < c.biome.bush_props[1] then
   local x=rnd(cell_size)
   local y=rnd(cell_size)
   local r=0
   local bloom_colours=c.biome.bush_props[3]
   local colour=bloom_colours[flr(rnd(#bloom_colours))%#bloom_colours+1]
   for j=1,range(bushes_cluster_range) do
    local b={
     r=range(bushes_radius_range)
    }
    b.p={
     x+range({1,(b.r+r)})-range({1,(b.r+r)/2}),
     y+range({1,(b.r+r)})-range({1,(b.r+r)/2})
    }
    if rnd() > 0.5 then
     x=b.p[1]
     y=b.p[2]
     r=b.r
    end
    b.height=range(bushes_height_range)
    b.c=colour
    
    if rnd() < c.biome.bush_props[2] then
     local a=rnd()
     local r=rnd(b.r/2)+b.r/4
     local bloom={
      p={
       r*cos(a),
       r*sin(a)
      }
     }
     b.bloom = bloom
    else
     b.bloom=nil
    end
    b.s=b.p
   
    add(c.bushes,b)
   end
  end
 
  -- buildings
  if
   #c.bushes + #c.trees == 0 and
   rnd() < c.biome.building_freq
  then
   c.building={
    size={
     range(buildings_w_range),
     range(buildings_h_range)
    },
    p={cell_size/2,cell_size/2},
    height=range(buildings_height_range),
    c=buildings_colours[flr(rnd(16))%#buildings_colours+1]
   }
   c.building.s=v_sub(c.building.p,p.p)
  end
 
 end
 
 end
 end
end

function add_blob(p,r)
 add(blobs,{
 hit=false,
 p=p,
 r=r,
 r2=r*r
 })
end

function _update()
 
 local v_dif={0,0}
 
 if menu != nil then
  -- menu transition
  if menu==0 then
   if btnp"4" or btnp"5" then
    menu-=1
    sfx(7,1)
    if btnp"4" then
     p.c={4,10,3}
     p.duck=4
    else
     p.c={6,10,4}
     p.duck=5
    end
   end
  else
   menu+=menu/4
   
   if menu < -128 then
    menu=nil
   end
  end
 else
  
  -- movement
  if btn"0" then v_dif[1] -= p.speed[1] end
  if btn"1" then v_dif[1] += p.speed[1] end
  if btn"2" then v_dif[2] -= p.speed[2] end
  if btn"3" then v_dif[2] += p.speed[2] end
  
  -- footstep sfx
  if
   btn"0" != btn"1" or
   btn"2" != btn"3"
  then
   if p.cell!= nil and stat"16" != p.cell.biome.foot_sfx then
    sfx(p.cell.biome.foot_sfx,0)
   end
  else
   sfx(-1,0)
  end
 
 end
 
 
 
 -- quack
 if btnp"4" then
  sfx(5,2)
  p.quack_timer=10
  cam.p=v_add(cam.p,{cos(p.a)*-2,sin(p.a)*-2})
 elseif btnp"5" then
  sfx(6,2)
  p.quack_timer=10
  cam.p=v_add(cam.p,{cos(p.a)*-2,sin(p.a)*-2})
 end
 
 p.quack_timer=max(0,p.quack_timer-1)
 
 perspective_offset={64+sin(time()/9)*4,80+sin(time()/11)*4}
 
 
 if abs(v_dif[1])+abs(v_dif[2]) > 0.01 then
  p.v=v_add(p.v,v_dif)
  p.a_o=p.a
  p.a=atan2(p.v[1],p.v[2])
 end
 
 p.v=v_mul(p.v,p.damping)
 
 if abs(p.v[1]) < 0.01 then
  p.v[1]=0
 end
 if abs(p.v[2]) < 0.01 then
  p.v[2]=0
 end
 
 p.cur_speed=v_len(p.v)
 if p.cur_speed > p.max_speed then
  p.v=v_mul(p.v,p.max_speed/p.cur_speed)
  p.cur_speed=p.max_speed
 end
 
 p.p=v_add(p.p,p.v)
 
 -- camera
 cam.offset=v_add(v_mul(p.v,-15),{64,64})
 if menu!=nil then
  cam.offset[2]+=128+menu*1.5
 end
 
 cam.p_o=cam.p
 local sway={
  cam.sway[1]*cos(time()/cam.sway[3]),
  cam.sway[2]*sin(time()/cam.sway[4])
 } 
 cam.p=v_add(
 v_lerp(cam.p,v_sub(p.p,cam.offset),0.1),
 sway
 )
 cam.v=v_sub(cam.p,cam.p_o)

 cam.c={
 cam.p[1]%cell_size,
 cam.p[2]%cell_size
 }

 local cell={
 flr(cam.p[1]/cell_size),
 flr(cam.p[2]/cell_size)
 }
 if cell[1]!=cells.current[1] or cell[2]!=cells.current[2] then
  cells.current=cell
  init_cells()
 end
 
 
 blobs={}
 
 u_trees()
 u_clouds()
 u_bushes()
 u_buildings()
 u_npcs()
 u_ducklings()
 u_collision()
 
 
 local pcell={
 flr(p.p[1]/cell_size),
 flr(p.p[2]/cell_size)
 }
 
 pcell=v_sub(pcell,cell)
 
 p.cell=cells.a[pcell[1]][pcell[2]]

 u_footprints()
 u_dialog()
end

function u_footprints()
 if p.cell then
 if p.cell.biome.footprints then
  -- footprints
  local fa=p.a
  if p.stride_alt then
   fa+=0.5
  end
  local fw=p.stride_w*(1-p.cur_speed/p.max_speed*0.8)*(1-abs(p.a-p.a_o))
  local fl=p.stride_l*(0.5+p.cur_speed/p.max_speed*0.5)
  local fp={
   p.p[1]+fw*cos(fa+0.25),
   p.p[2]+fw*sin(fa+0.25)
  }
  fp[3]=fp[1]-p.v[1]
  fp[4]=fp[2]-p.v[2]
  
  if v_distm(fp,footprints[footprints.max-1]) > fl then
   -- add footprints
   -- (actually just recycle existing ones)
   for i=1,footprints.max-1 do
    footprints[i]=footprints[i+1]
   end
   footprints[footprints.max]=fp
   p.stride_alt = not p.stride_alt
  end
 end
 end
end


function u_collision()
 -- blobs
 for b in all(blobs) do
  local d=v_sub(p.p,b.p)
  local l2=v_len2(d)
  if l2 < b.r2+p.r2 then
   b.hit=true
   p.v=v_add(p.v,v_div(d,sqrt(l2)))
  else
   b.hit=false
  end
 end
 
 -- boundaries
 local x=p.p[1]/cell_size
 local y=p.p[2]/cell_size
 if x > cell_bounds then
  p.v[1] -= (x-cell_bounds)*cell_bound_str
 elseif x < 0 then
  p.v[1] -= x*cell_bound_str
 end
 
 if y > cell_bounds then
  p.v[2] -= (y-cell_bounds)*cell_bound_str
 elseif y < 0 then
  p.v[2] -= y*cell_bound_str
 end
end

function u_trees()
 
 for x=0,cell_fill do
 for y=0,cell_fill do
 
 local ts=cells.a[x][y].trees
 
 local cellp = {
  cam.p[1]%cell_size-x*cell_size,
  cam.p[2]%cell_size-y*cell_size
 }
 
 for t in all(ts) do
  t.s=v_sub(t.p,v_add(cellp,perspective_offset))
  t.s=v_mul(t.s,t.height*height_mult)
  
  t.s=v_add(t.p,t.s)
  
  t.leaves={
  v_lerp(t.p,t.s,0.5),
  v_lerp(t.p,t.s,0.75),
  t.s
  }
  
  add_blob(v_add({(cells.current[1]+x)*cell_size,(cells.current[2]+y)*cell_size},t.p), t.girth)
  
 end
 
 end
 end
end

function u_clouds()
 for c in all(clouds) do
  c.p[1]+=0.1-cam.v[1]
  c.p[2]+=0.1-cam.v[2]
  
  if c.p[1] > c_size+c_radius_range[2] then
   c.p[1] -= c_size*2+c_radius_range[2]
  elseif c.p[1] < -c_size-c_radius_range[2] then
   c.p[1] += c_size*2+c_radius_range[2]
  end
  if c.p[2] > c_size+c_radius_range[2] then
   c.p[2] -= c_size*2+c_radius_range[2]
  elseif c.p[2] < -c_size-c_radius_range[2] then
   c.p[2] += c_size*2+c_radius_range[2]
  end
  
   
  
  c.s=v_sub(c.p,perspective_offset)
  c.s=v_mul(c.s,c.height*height_mult)
  c.s=v_add(c.p,c.s)
  
  c.ps=v_add(c.p,v_mul(shadow_offset,c.height))
 end
end

function u_bushes()
 for x=0,cell_fill do
 for y=0,cell_fill do
 
 local bs=cells.a[x][y].bushes
 
 local cellp = {
  cam.p[1]%cell_size-x*cell_size,
  cam.p[2]%cell_size-y*cell_size
 }
 
 for b in all(bs) do
  b.s=v_sub(b.p,v_add(cellp,perspective_offset))
  b.s=v_mul(b.s,b.height*height_mult)
  
  b.s=v_add(b.p,b.s)
 end
 
 end
 end
end


function u_buildings()
 for x=0,cell_fill do
 for y=0,cell_fill do
 
 local b=cells.a[x][y].building
 
 if b then
  local cellp = {
   cam.p[1]%cell_size-x*cell_size,
   cam.p[2]%cell_size-y*cell_size
  }
  b.s=v_sub(b.p,v_add(cellp,perspective_offset))
  
  local s1=max(b.size[1],b.size[2])
  local s2=min(b.size[1],b.size[2])
  for i=-s1+s2/2,s1-s2/2,s2 do
   local blob={
    hit = false,
    p = v_add({(cells.current[1]+x)*cell_size,(cells.current[2]+y)*cell_size},b.p),
    r = s2,
    r2=s2*s2
   }
   if s1==b.size[1] then
    blob.p[1]+=i
   else
    blob.p[2]+=i
   end
   add(blobs,blob)
  end
  local blob={
   hit = false,
   p = v_add({(cells.current[1]+x)*cell_size,(cells.current[2]+y)*cell_size},b.p),
   r = s2,
   r2=s2*s2
  }
  if s1==b.size[1] then
   blob.p[1]+=s1-s2/2
  else
   blob.p[2]+=s1-s2/2
  end
  if v_dist(blob.p,blobs[#blobs].p)>2 then
   add(blobs,blob)
  end
 end
 
 end
 end
end

function u_npcs()
 for npc in all(npcs) do
  npc.p2={npc.cell[1],npc.cell[2]}
  
  if v_distm(npc.p2,v_add(cells.current,{2,2})) <= 4 then
  npc.active=true
  npc.p2[1]*=cell_size
  npc.p2[2]*=cell_size
  npc.p2=v_add(npc.p, npc.p2)
  
  npc.s=v_sub(npc.p2,v_add(cam.p,perspective_offset))
  npc.s=v_mul(npc.s,npc.height*height_mult)
  npc.s=v_add(npc.p2,npc.s)
  
  add_blob(npc.p2,npc.r)
  else
  npc.active=false
  end
 end
end

function u_ducklings()
 -- pick em up
 for d in all(ducklings) do
  if v_distm(d.p,p.p) < p.r then
   d.target=p.ducklings[#p.ducklings] or p
   add(p.ducklings,d)
   del(ducklings,d)
   ducklings.found+=1
   ducklings.found_timer=80
   
   if ducklings.found==7 then
    npcs[1].lines="duck duck!|you found\nthem all!|ha ha, it looks\nlike they're not\ndone exploring\nthough!|feel free to\nbabysit them\nfor now.|just be sure you\ndon't lose them!|thanks again\nduck duck!|"
    npcs[2].lines="duck duck!|you found\nthem all!|um...|would you mind\nlooking after\nthem for a bit?|it's just...\nthey're having\nso much fun!|you could take\nthem exploring!|you're great with\nkids, duck duck!|thank you\nso much!|"
    npcs[1].lastline="|thanks again\nduck duck!|"
    npcs[2].lastline="|thank you\nso much!|"
    npcs[3].lines="oh, you found\nthem all\nduck duck!|next time we\nplay hide and\nseek i'll try\nharder...|"
    npcs[3].lastline="|next time we\nplay hide and\nseek i'll try\nharder...|"
   elseif ducklings.found==1 then
    npcs[1].lines="you found one!|but where are\nthe others?|you've got to\nfind them\nduck duck!!|please find\nour babies!|"
    npcs[2].lines="you found one!|but where are\nthe others?|you've got to\nfind them\nduck duck!!|please find\nour babies!|"
    npcs[1].lastline="|please find\nour babies!|"
    npcs[2].lastline="|please find\nour babies!|"
   else
    npcs[1].lines="duck duck!|you found "..#p.ducklings.."\nducklings, but\nthere's still "..(7-#p.ducklings).."\nleft out there!|please find them!|"
    npcs[2].lines="duck duck!|you found "..#p.ducklings.."\nducklings, but\nthere's still "..(7-#p.ducklings).."\nleft out there!|please find them!|"
    npcs[1].lastline="|please find them!|"
    npcs[2].lastline="|please find them!|"
   end
   
   sfx(8,2)
  end
 end
 
 ducklings.found_timer=max(0,ducklings.found_timer-1)
 
 
 
 -- follow the leader
 for d in all(p.ducklings) do
  local v=min(1,v_distm(d.p,d.target.p)/(p.r*2))*0.4
  d.p=v_lerp(d.p,d.target.p,v*v)
  d.a=-atan2(d.target.p[2]-d.p[2],d.target.p[1]-d.p[1])-0.25
 end
end

function u_dialog()
 local prev=talk.npc
 -- find closest npc in range
 talk.r=10000
 for npc in all(npcs) do
  if npc.active then
   local r=v_dist(npc.p2,p.p)
   if r<talk.r and r < (npc.r+p.r)*2.5 then
    talk.npc=npc
    talk.r=r
   end
  end
 end
 
 -- if it's a new npc
 -- get their lines
 if prev!=talk.npc then
  if #talk.npc.lines > 0 then
   talk.say="|"..talk.npc.lines
  else
   talk.say=talk.npc.lastline
  end
  talk.said=""
 end
 
 -- transition view
 if talk.r==10000 then
  talk.offset=lerp(talk.offset,-talk.offset_target,0.25)
  if abs(talk.offset-(-talk.offset_target)) < 1 then
   talk.offset=-talk.offset_target
   talk.npc=nil
   talk.say=""
   talk.said=""
  end
 else
  if abs(talk.offset) < 1 then
   talk.offset=0
  else
   talk.offset=lerp(talk.offset,0,0.25) 
  end
 end
 
 
 local s=sub(talk.say,1,1)
 local skip=btnp"4" or btnp"5"
 
 --skip only applied mid-line
 if s=="|" then
  skip = false
 else
 end
 -- handle text
 if talk.npc!=nil then
  if #talk.say <= 1 then
   talk.say=talk.npc.lastline
  end
  repeat
   s=sub(talk.say,1,1)
   if s!="|" and s!="" then
    
    if stat"17" != talk.npc.sfx then
     sfx(talk.npc.sfx,1)
     talk.bounce=10
    end
    
    -- add letter
    talk.said=talk.said..s
    talk.say=sub(talk.say,2,#talk.say)
   elseif talk.offset==0 and not skip and (btnp"4" or btnp"5") then
    -- go to next line
    talk.said=""
    
    -- remove npc's old line
    while #talk.npc.lines > 0 and sub(talk.npc.lines,1,1) != "|" do
     talk.npc.lines=sub(talk.npc.lines,2,#talk.npc.lines)
    end
    talk.npc.lines=sub(talk.npc.lines,2,#talk.npc.lines)
    
    talk.say=sub(talk.say,2,#talk.say)
   else
    -- reached end of line
    skip=false
   end
  until not skip
 end
 talk.bounce=max(0,talk.bounce-1)
end

function _draw()
 d_bg()
 
 camera(cam.p[1],cam.p[2])
 
 d_footprints()
 
 d_bushes"1"
 d_ducklings"1"
 d_npcs"1"
 d_player"1"
 d_trees"1"
 d_buildings"1"
 d_clouds"1" 
 
 d_bushes()
 d_ducklings()
 d_npcs()
 d_player()
 d_trees()
 d_buildings()
 d_clouds()
 
 if ducklings.found_timer > 0 then
  d_found()
 end
 
 if menu!=nil then
  d_menu()
 elseif talk.offset > -talk.offset_target then
  camera(0,talk.offset)
  d_duckface()
  d_npcface()
  d_dialog()
 end
end

function d_bg()
 camera(cam.p[1],cam.p[2])
 
 for a=0,cell_fill do
 for b=0,cell_fill do
 
 x=(cells.current[1]+a)*cell_size
 y=(cells.current[2]+b)*cell_size
 
 local cell=cells.a[a][b]
 
 rectfill(x,y,x+cell_size,y+cell_size,cell.c)
 
 if cell.biome.transition then
 srand(cell.seed)
 
 local c=cell.edges[1][0]
 if c!=cell.c then
  pal(0,c)
  for v=0,cell_size/8 do
   spr(4+flr(rnd"4")*16,x+cell_size-8, y+v*8)
  end
 end
 c=cell.edges[-1][0]
 if c!=cell.c then
  pal(0,c)
  for v=0,cell_size/8 do
   spr(3+flr(rnd"4")*16,x, y+v*8)
  end
 end
 c=cell.edges[0][-1]
 if c!=cell.c then
  pal(0,c)
  for u=0,cell_size/8 do
   spr(2+flr(rnd"4")*16,x+u*8, y)
  end
 end
 c=cell.edges[0][1]
 if c!=cell.c then
  pal(0,c)
  for u=0,cell_size/8 do
   spr(1+flr(rnd"4")*16,x+u*8, y+cell_size-8)
  end
 end
 
 end
 end
 
 pal(0,0)
 end
 
end

function d_footprints()
 color"5"
 for f=2,#footprints,2 do
  local f1=footprints[f-1]
  local f2=footprints[f]
  
  line(f1[1],f1[2],f1[3],f1[4])
  line(f2[1],f2[2],f2[3],f2[4])
  
  circfill(f1[1],f1[2],1)
  circfill(f2[1],f2[2],1)
 end
end

function d_ducklings(shadow)
 camera(cam.p[1],cam.p[2])
 
 if shadow then
  color"5"
  for d in all(ducklings) do
   circfill(d.p[1]+shadow_offset[1]*ducklings.height,d.p[2]+shadow_offset[1]*ducklings.height,ducklings.r+1)
  end
  for d in all(p.ducklings) do
   circfill(d.p[1]+shadow_offset[1]*ducklings.height,d.p[2]+shadow_offset[1]*ducklings.height,ducklings.r+1)
  end
 else
  for d in all(ducklings) do
   circfill(d.p[1],d.p[2],ducklings.r,9)
   circfill(d.p[1]+1,d.p[2]+1,1,10)
  end
  for d in all(p.ducklings) do
   circfill(d.p[1],d.p[2],ducklings.r,9)
   circfill(d.p[1]+cos(d.a),d.p[2]+sin(d.a),1,10)
  end
 end
end

function d_player(shadow)
 camera(cam.p[1],cam.p[2])
 
 if shadow then
  local c
  if p.cell and p.cell.biome.foot_sfx==1 then
   if time()*2%1 > 0.5 then
   spr(46,
   p.p[1]+shadow_offset[1]*p.height-8,
   p.p[2]+shadow_offset[2]*p.height-8,
   2,2)
   end
  end
  circfill(
  p.p[1]+shadow_offset[1]*p.height,
  p.p[2]+shadow_offset[2]*p.height,
  p.r,5)
 else
  local s=p.cur_speed/p.max_speed*p.r/5+0.5
  local p1={p.p[1],p.p[2]}
  local p2={
   p1[1]+p.height*cos(p.a)*s,
   p1[2]+p.height*sin(p.a)*s
  }
  
  circfill(p1[1],p1[2],p.r*3/4,p.c[1])
  circfill(p2[1],p2[2],p.r/2,p.c[2])
  p2=v_lerp(p1,p2,0.75)
  circfill(p2[1],p2[2],p.r/2,p.c[3])
  p2=v_lerp(p1,p2,0.5)
  pset(p2[1],p2[2],0)
  end
end

function d_trees(shadows)
 for a=0,cell_fill do
 for b=0,cell_fill do
 
 local trees=cells.a[a][b].trees
 camera(
  cam.c[1]-a*cell_size,
  cam.c[2]-b*cell_size
 )
 
 if shadows then
 -- shadows
 color"5"
 for t in all(trees) do
  circfill(
  t.p[1]+shadow_offset[1]*t.height/2,
  t.p[2]+shadow_offset[2]*t.height/2,
  t.girth)
 end
 else
 -- trunks
 color"4"
 for t in all(trees) do
  for x=-1,1 do
  for y=-1,1 do
  if abs(x)+abs(y)!=2 then
   line(t.p[1]+x,t.p[2]+y,t.s[1],t.s[2])
  end
  end
  end
 end
 -- leaves
 c={{3,1},{11,0.7},{7,0.4}}
 for i=1,3 do
 color(c[i][1])
 for t in all(trees) do
  circfill(t.leaves[i][1],t.leaves[i][2],t.girth*c[i][2])
 end
 end
 
 end
 
 end
 end
end

function d_buildings(shadows) 
 for x=0,cell_fill do
 for y=0,cell_fill do
 
 local b=cells.a[x][y].building
 
 if b then
 
 camera(
  cam.c[1]-x*cell_size,
  cam.c[2]-y*cell_size
 )
 
 if shadows then
 color"5"
 for i=0,b.height/2,4 do
  local t={b.s[1],b.s[2]}
  t=v_mul(t,i*height_mult)
  t=v_add(b.p,t)
  rectfill(t[1]-b.size[1],t[2]-b.size[2],t[1]+b.size[1],t[2]+b.size[2])
 end
 else
  color"5"
  for i=b.height/2,b.height-1,4 do
   local t={b.s[1],b.s[2]}
   t=v_mul(t,i*height_mult)
   t=v_add(b.p,t)
   rectfill(t[1]-b.size[1],t[2]-b.size[2],t[1]+b.size[1],t[2]+b.size[2])
  end
 
  local s=v_mul(b.s,b.height*height_mult)
  s=v_add(b.p,s)
  rectfill(s[1]-b.size[1],s[2]-b.size[2],s[1]+b.size[1],s[2]+b.size[2],b.c)
 end
 end
 
 end
 end
end

function d_clouds(shadows)
 camera""
 if shadows then
  color"5"
  for c in all(clouds) do
   circfill(c.ps[1],c.ps[2],c.r)
  end
 else
  color"7"
  for c in all(clouds) do
   circfill(c.s[1],c.s[2],c.r)
  end
 end
end
 
function d_bushes(shadows)
 for a=0,cell_fill do
 for b=0,cell_fill do
 
 local bushes=cells.a[a][b].bushes
 camera(
  cam.c[1]-a*cell_size,
  cam.c[2]-b*cell_size
 )
 
 if shadows then
  color"5"
  for b in all(bushes) do
   circfill(
   b.p[1]+shadow_offset[1]*b.height,
   b.p[2]+shadow_offset[2]*b.height,
   b.r)
  end
 else
  color"3"
  for b in all(bushes) do
   circfill(b.s[1],b.s[2],b.r)
  end
  for b in all(bushes) do
   if b.bloom!=nil then
    local p=v_add(b.s,b.bloom.p)
    pset(p[1],p[2],b.c)
   end
  end
 end
 
 end
 end
end

function d_npcs(shadows)
 camera(cam.p[1],cam.p[2])
 
 if shadows then
  for npc in all(npcs) do
   if npc.active then
    circfill(
     npc.p2[1]+shadow_offset[1]*npc.height,
     npc.p2[2]+shadow_offset[2]*npc.height,
     npc.r,5)
   end
  end
 else
  for npc in all(npcs) do
   if npc.active then
    local s=v_lerp(npc.s,npc.p2,0.75)
    circfill(s[1],s[2],npc.r,npc.c1)
    circfill(npc.s[1],npc.s[2],npc.r-1,npc.c2)
   end
  end
 end
end

function d_title()
 local t=time()
 local t2=t
 local c=2
 if menu != 0 then
  c=8
  t2*=16
 end
 for i=0,3 do
  pal(0,(i+t2)%c+c)
  sspr(40+8*i,16,8,11,12+12*i,10+sin(t+i/3)*1.2,16,22)
 end
 for i=0,3 do
  pal(0,(i+t2+4)%c+c)
  sspr(40+8*i,16,8,11,9+12*(i+4)+8,10+sin(t+(i+1)/3)*1.2,16,22)
 end
 local s=" on the"
 for i=1,#s do
  pal(0,(i+t2)%c+c)
  print_ol(sub(s,i,i),64+(i-1)*4-#s*2+2,35+sin(t/2+i/#s)+2.1,5,5)
  print_ol(sub(s,i,i),64+(i-1)*4-#s*2,35+sin(t/2+i/#s)+0.1,7,0)
 end
 
 for i=0,4 do
  pal(0,(i+t2)%c+c)
  sspr(72+8*i,16,8,11,9+12*(i+2),44+sin(t+(i+2)/3)*1.2,16,22)
 end
 pal(0,0)
end

function d_menu()
 camera(0,menu)
 d_title()
 
 local a=-abs(sin(time()/2))*3
 a=flr(a)
 
 sx=64
 if p.duck==4 then
  sx+=16
 end
 sspr(sx,0,16,16,0,128-32-a,32,32+a)
 sx=96
 
 if p.duck==5 then
  sx+=16
 end
 sspr(sx,0,16,16,128-32,128-32-a,32,32+a,true)

 if p.duck==4 then
  print_ol("🅾️",33,127-16,7,0)
 else
  print_ol("🅾️",33,127-16,0,7)
 end
 if p.duck==5 then
  print_ol("❎",97-8,127-16,7,0)
 else
  print_ol("❎",97-8,127-16,0,7)
 end
 print_ol("ˇ quack ˇ",43,127-16,0,7)
end

function d_duckface()
 local t=p.quack_timer
 local a=abs(sin(t/40))*5-abs(sin(time()/2))*3
 a=flr(a)
 sx=64
 if p.duck==5 then
  sx+=32
 end
 if t > 0 then
  sx+=16
 end
 sspr(sx,0,16,16,0,128-32-a,32,32+a)
end

function d_npcface()
 local a=abs(sin(talk.bounce/40))*5-abs(sin(time()/2))*3
 a=flr(a)sx=0
 sy=32
 local npc=talk.npc
 sx+=npc.spr*16
 while(sx >= 128) do
  sx-=128
  sy+=16
 end
 sspr(sx,sy,16,16,128-32,128-32-a,32,32+a)
 if npc.mouth >= 0 then
  local c=sub(talk.say,1,1)
  if c!="|" and c!="" and time()%0.2 > 0.1 then
   pal(0,npc.mouth)
   sspr(56,0,8,16,128-20,128-32-a+npc.mouth_offset,16,32+a)
   pal(0,0)
  end
 end
end

function d_dialog()
 local a=abs(sin(talk.bounce/40))*5-abs(sin(time()/2))*3
 a=flr(a)
 print_ol(talk.npc.who,127-#talk.npc.who*4-2,127-39-a,0,7)
 print_ol(talk.said,32,127-24,0,7)
end

function d_found()
 local c=ducklings.found_timer/160
 c=c*c*2
 c=-(-sin(c))*128+64
 camera(0,c)
 for i=0,3 do
  pal(0,(i+time()*16)%8+8)
  sspr(40+i*8,16,8,11, 20+i*16,10+sin(time()+i/3)*1.2, 16,22)
 end
 for i=0,5 do
  pal(0,(i+time()*16)%8+8)
  sspr(80+i*8,112,8,11, 20+i*16,30+sin(time()+i/3)*1.2, 16,22)
 end
 pal(0,0)
end

function print_ol(s,x,y,c1,c2)
 for u=x-1,x+1 do
 for v=y-1,y+1 do
  print(s,u,v,c1)
 end
 end
 print(s,x,y,c2)
end