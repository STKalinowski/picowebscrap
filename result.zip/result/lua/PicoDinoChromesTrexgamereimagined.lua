--meta variables and functions

--chrome dino
--by yolwoocle
version = "v1.1"

clock=0
gclock=0
debug=false
framebyframe=true

gravity=0.5
groundy=110
jumpforce=-5
spdcap=-5
speed=-2.7
distance=0
bgcolor=7 --5;6;7 -> █▒░
palette={5,6,7}
gbpal=false
palettes={{5,6,7},{1,3,10+128},
--[[night pals]]
{7,6,5},{10+128,3,1}}

canspawn=true

splash=false
splashframe=0
menuscreen=false

gameover = false
gameovertext = false
gmov_y = 0
deathframe = 0

ltr={
{x=112,y=124},--y
{x=116,y=124},--o
{x=120,y=120},--l
{x=112,y=120},--w
{x=124,y=124},--c
{x=124,y=120},--e
}
if stat(6)=="" then
 highscore=0
else
 highscore=tonum(stat(6))
end

newhighscore=false
score = 0
scoreblink = false
blink = 200

poke(0x5f2d,1)

function changepal()
	gbpal=not gbpal
	palette=palettes[gbpal and 2 or 1]
end

function gameov()
 if gameover then
 	menuitem(1,"skip cutscene", 
	 function() deathframe=111 end) 
 
  d=deathframe
  d=abs(d+1)
  dino.sizex=2
  fdead=35+13*2
  if score>tonum(highscore) then
   highscore=score
   sfx(4)
   newhighscore=true
  end
  
  if d==35 then
  	sfx(2)
  end
  if isbtw(d,35,fdead) then
   dinodeathanim()
  elseif fdead<d then
   dino.x=14
   dino.frame=132
   dino.flipx=false
   dino.flipy=false
   dino.sizex=3
   if gmov_y<127 then
    gameovertext=true
    gmov_y+=1
   end
   if isbtw(d,fdead+1,fdead+2)then
    dino.y+=1
   elseif d==fdead+4 or d==fdead+8 or d==fdead+12 then
    dino.y+=1
   elseif d==fdead+6 or d==fdead+10 then
    dino.y-=1
   elseif d==fdead+18 then
    ringy=dino.y-5
   elseif isbtw(d,fdead+19,fdead+20) then
    ringy+=1
   end
  end
  
  deathframe=d
 end
end


function b2d(bool)
--converts false/true to -1/1
 return bool and 1 or -1
end

function sprcoor(index)
--converts sprite index to  
--spritesheet coordinates
 return {x=index%16*8,y=index\16*8}
end

function sprs(n,x,y,w,h,dw,dh)
--is like spr, but w/ stretch
--doesn't support flipping
 s=sprcoor(n)
 w=(w or 1)*8
 h=(h or 1)*8
 dw=dw or w
 dh=dh or h
 dw*=8*(w/8)
 dh*=8*(h/8)
 x-=(dw-w)/2
 y-=(dh-h)/2
 
 sspr(s.x,s.y,w,h,x,y,dw,dh)
end

function isbtw(var,min,max)
 return mid(min,var,max)==var
end

function updscore()
 if clock % 2 == 0 then
  score += 1
 end
end

function rand(min,max)
 x=flr(rnd(max-min+1)+min)
 return x
end 

function createanim(
         frame,t,i,min,max,snd,
         sndreset)
         --t:speed
         --i:increment	
 if frame<min or frame>max then
  frame=min
 end
 if clock % t == 0 then
 	if(snd!=nil)sfx(snd)
  frame += i
  if frame > max then
   frame = min
   if(sndreset!=nil)sfx(sndreset)
  end
 end
 return frame
end


-->8
--init,update,draw

 function _init()
  menuitem(2,"change palette",
  changepal)
  score=0
  cls()
  sfx(5)
  --clip(0,13,128,107)
  for i=1,16 do
   genhills()
  end
  
  --if score is negative,
  --change to gameboy palette
  if highscore==0 then
   splash=true
  elseif highscore<0 then
  	highscore*=-1
  	changepal()
  end
  
  if flr(rnd(100))==0 then
  	changepal()
  end
  
  local xdist=0
  while xdist<140 do
   add(dusts,{x=xdist,
   y=groundy,t=rand(39,43)})
    
   xdist+=rand(12,19)
  end
 end
 
 ------------
 ---update---
 ------------
 function _update()
  clock += 1
--splash
  if splash then 
   if mid(1,btn(),63)==btn()then
   	splash=false
   	splashframe=0
  	end
  else
  	if splashframe<10 then
   	splashframe+=1
  	end
  end
  
  if not gameover and not splash then
   gclock+=1
   if(gclock% 2 == 0)score += 1
   speed-=0.001
   if speed<spdcap then
    speed=spdcap
   end
   distance-=speed
   
   dinocontrols()
   dino.yvel+=gravity
   dino.y+=dino.yvel
   dinostretch()
   dinoground()
   animatedino()
   
			if mid(1,btnp(),63)==btnp()then
			 canspawn=true
			end
   if distance>200 and canspawn then
	   cactspawn()
	   cactmove()
	   cactdespawn()
	   cactanim()
   end
   
   dustmove()
   dustspawn()
   dustdespawn()
   
   cloudmove()
   cloudspawn()
   clouddespawn()
   
   hillsmove()
   
   --score blinking if it
   --passes 500
   if score%blink == 0 and 
   gclock>10 then
   	sfx(5)
   	scoreblink = true
   end
   if scoreblink and 
   score%blink>50 then
   	scoreblink = false
   end
   
   --sun & moon
   local clk=gclock*sunspd
   sunx=cos((clk+920)/360)*50+64
  	suny=sin((clk+920)/360)*-100+127
   moonx=cos((clk+750)/360)*50+64
   moony=sin((clk+750)/360)*-100+127
   local gy=groundy
   if suny>gy+5 then
   	sunsetphase=1
   elseif isbtw(suny,gy+0,gy+5)then
   	sunsetphase=2
   elseif isbtw(suny,gy-0,gy-5)then
   	sunsetphase=3
   elseif isbtw(suny,gy-5,gy-10)then
   	sunsetphase=4
   elseif suny<gy-10 then
   	sunsetphase=5
   end
   
   if not debug then
    gameover = dinocheckhit()
   end
  end
  
  
  gameov()
  if gameover and btn(❎) and deathframe>100 then
   newhighscore=true
   run(-b2d(gbpal)*highscore)
  end
  
  --small beep after showing 
  --score
  if deathframe == 111 then
  	sfx(6)
  end
  
  if debug then
   --while not btn(🅾️) do 
   --end
   while btn(🅾️) do 
   end
  end
 end
 ------------
 ---update---
 ------------

 ------------
 --- draw ---
 ------------
 function _draw()
  --splash dark bg
  pal()
  delay=10
  incr=5
  if incr+delay<deathframe then
   pal(7,6)
   pal(6,5)
  end
  if incr*2+delay<deathframe then
   pal(7,5)
   pal(6,5)
  end
  
  --sky
  --5 highest 1 lowest
  bl=0b1111111111111111
  local colbk=7
  local colfrt=5
  if(sunsetphase<4)colbk=6
  rectfill(0,0,127,127,colbk)
  local dofill=true
  if sunsetphase==5 then
  	dofill=false
  elseif sunsetphase==4 then
  	fillp(░)
  	colfrt=6
  elseif sunsetphase==3 then
  	fillp(█)
  	colfrt=6
  elseif sunsetphase==2 then
  	fillp(░)
  elseif sunsetphase==1 then
  	fillp(█)
  end
  if(dofill)rectfill(0,0,127,127,colfrt)
  fillp()
  
  --sun
  circ(sunx,suny,sunradius,6)
  --moon
  circfill(moonx,moony,sunradius,6)
  circfill(moonx+sunradius,moony,sunradius,5)
  
  --clouds layer 0
  cloudsdraw(0)
  
  --hills
  hillsdraw(hillsx)
  
  --clouds layer 1
  cloudsdraw(1)
  
  --score
		local sprt=166
		if(sunsetphase<3)sprt=192
  local prnt=tostr(score)
  if scoreblink then
  	if score%10>5 then 
	  	prnt = tostr(score\blink*blink)
  	else 
  		prnt = "nothing"
  	end
  end
  
  if prnt != "nothing" then
	  for i=1,6 do
	  	local char=tonum(sub(prnt,i-7,i-7))
	  	if(char==nil)char=0
	  	spr(sprt+char,i*6+80,20)
	  end
	  
	 end
	 for i=1,6 do
		 spr(156,70,27,3,1) //"high"
  	local prnt=tostr(highscore)
  	local char=tonum(sub(prnt,i-7,i-7))
  	if(char==nil)char=0
  	spr(182+char,i*5+86,27)
  end
	 
  --ground fill
  rectfill(0,107,127,127,7)
  
  --ground
  line(0,groundy-4,127,
  groundy-4,6)
  
  if(debug)then line(0,groundy,127,
  groundy,9)end
  
  dustdraw()
  
  --dust kick when jump
  if dustkicktime<3 then
   spr(55,
   dino.x+4+(dustkicktime*speed),
   groundy-8)
  end
  
  cactdraw()
  
  dinodraw()

  --game over text
  if gameovertext then
   o=0
   for i=0,7 do
    pal(7,5)
    if isbtw(gmov_y-i,24,26) then
     pal(7,6)
    elseif gmov_y-i>= 27 then
     pal()
    end
    wave=cos((clock+i*7)/45)*2*0.95
    
    spr(i+7,26+o+i*9,
    min(gmov_y-i,30)+wave)
    if(i==3)o=4
    pal()
   end 
   s="❎ - replay "
   s2="score: "..score
   s3="highscore: "..highscore
   s4="new highscore !"
   if deathframe > 111 then
    --"replay?"
    show=clock%30<15 
    print(s,64-#s*2,80,6)
    if show then
    	print(s,64-#s*2,79,7)
    end
    
    --score
    print(s2,64-#s2*2,47,7)
    print(s3,64-#s3*2,54,6)
    if newhighscore then
     print(s4,64-#s4*2,61,7)
    end
   end
  end
  
--splash screen
  if(highscore==0 and splash) or
  splashframe<10 then
	   cls(7)
    if isbtw(splashframe,2,5) then
     cls(6)
    elseif splashframe<= 2 then
     cls(5)
    end
   pal()
	  spr(206,56,52,2,3)
	  yol={1,2,3,4,2,2,5,3,6}
	  of=0
	  local px=41
	  local py=81
	  for i in all(yol) do
	   sx=ltr[i].x
	   sy=ltr[i].y
	   sw=4
	   if(i==4)sw=6
	   sspr(sx,sy,sw,4,px,
	   py+cos((clock*2+px*7)/45)*0.5*0.95)
	   px+=5
	   if(i==4)px+=2
  	end
  end
  
--  spr(16,stat(32)-1,stat(33)-1)
--  pset(stat(32),stat(33),8)
  
  --debug text
  if debug then
   print("cpu",5,10,8)
   print(stat(1),20,10,8)
   print("fps",5,20,8)
   print(stat(7),20,20,8)
   
   pset(stat(32),stat(33),9)
   print("x"..stat(32),5,52)
   print("y"..stat(33),5,58)
   
   print("dist  "..distance,10,30,5)
   print("clock "..clock,10,36)
   print("speed "..speed,10,42)
  end
  
--palette
		local n=day and 0 or 2
		palette=palettes[(gbpal and 2 or 1)+n]
		pal(5,palette[1],1)
		pal(6,palette[2],1)
		pal(7,palette[3],1)
		
		
		
		--cartridge cover
 	if false then
 		cls(7)
 		map(16,0)
 		sspr(16,48,16,16,25,50,32,32)
 		rect(0,100,127,101,6)
 		sspr(80,48,16,16,75,74,32,32)
 		sspr(56,16,5*8,8,0,106,5*16,16)
 		sspr(56,16,5*8,8,70,106,5*16,16)
 		sspr(0,104,6*8,2*8,16,10,6*16,2*16)
 	end
 end
-->8
--dino functions
dino = {
 x=15,
 y=96,
 yvel=0,
 timeoffground=0,
 timeground=0,
 frmcrouch=0,
 maxjump=-6,
 maxhold=1,
 timeslide=0,
 
 --hitbox
 hitbx=0,
 hitby=0,
 hitbw=0,
 hitbh=0,
 
 --animation
 frame=1,
 flipx=false,
 flipy=false,
 strch=10,
 sizex=1,
 bop=0, 
 
 --states
 jumped=false,
 jumping=false,
 crouching=false,
 grndpounding=false,
 sliding=false,
 grnded=false,
}
flipcount=1
ringy=0


 function animatedino()
  frame=33
  sizex=2
  if dino.grnded then
   --walk
   frame = createanim(dino.frame,
           2,2,96,98,
           nil,nil)--rnd({0,1}))
			
  else
   frame = 98
  end
  if dino.crouching then
   sizex=3
   --crouch
   frame = createanim(dino.frame,
           2,3,100,103)
   if not dino.grnded then
    frame = 100
   end
  end 
  if dino.grndpounding or 
  dino.sliding then
   frame = 108
  end
  dino.sizex = sizex
  dino.frame = frame
 end

 function dinostretch()
  if dino.strch<10 then
    dino.strch-=flr(dino.strch/-7)
   elseif dino.strch>10 then
    dino.strch-=flr(dino.strch/7)
   end
 end
 
 --controls
 function dinocontrols()
 	up=btn(⬆️)or btn(🅾️)
 	down=btn(⬇️)or btn(❎)
 	
  dustkicktime+=1
  
  if dino.grnded then
   if dino.grndpounding then
    dino.sliding=true
    if dino.timeground==0 then 
     dino.strch=8
     sfx(1)
    end
    if not (down) then
     dino.grndpounding=false
    end
   end
   gravity=0.5
   dino.timeoffground=0
   dino.timeground+=1
  else
   dino.timeoffground+=1
   dino.timeground=0
  end
  
  if (up) and dino.grnded 
  then
   dino.jumped=true
   dino.yvel=dino.maxjump
   sfx(0)
   dino.strch=20
   
   dustkicktime=0
   if (down) then
   --crouch jump
    dino.jumping=true
    dino.yvel*=0.8
   end
  end
  
  --hold for higher jump
  if dino.jumped and not (up) 
  and dino.yvel < 0 and 
  dino.yvel >= dino.maxjump 
  then
   dino.yvel *= 0.6
  end
  
  --prevent ground pound if 
  --jumping on grnd while crouch
  --until ⬇️ is released
  if not (down) then
   dino.jumping=false
   dino.sliding=false
  end
  
  if (down) then
  	if not dino.crouching then
  		sfx(3)
  	end
   dino.crouching=true
   dino.frmcrouch+=1
   if not dino.grnded and 
   not dino.jumping then
    dino.grndpounding=true
    dino.strch+=2
    gravity=2.5
   end
   if dino.frmcrouch==1 and 
   not dino.grndpounding then
    dino.strch=6
   end
  else
   dino.frmcrouch=0
   dino.crouching=false
  end
  
  if dino.crouching then
   dino.hitbx=4
   dino.hitby=6
   dino.hitbw=9
   dino.hitbh=6
  else 
   --walk
   dino.hitbx=4
   dino.hitby=2
   dino.hitbw=7
   dino.hitbh=12
  end
 end
 
 --ground
 function dinoground()
  if dino.y>groundy-16 then
   dino.grnded = true
   dino.yvel = 0
   dino.y=groundy-16
  else
   dino.grnded = false
  end
 end
 
 --collision
 function dinocheckhit()
  hit = false
  
  x1=dino.x + dino.hitbx
  y1=dino.y + dino.hitby
  x2=dino.x + dino.hitbx +
     dino.hitbw
  y2=dino.y + dino.hitby +
     dino.hitbh
  
  for c in all(cact) do
   cx1 = c.x+c.hx
   cy1 = c.y+c.hy
   cx2 = cx1+c.hw
   cy2 = cy1+c.hh
   
   if cx1<x2 and cy1<y2 and
   x1<cx2 and y1<cy2 then
    hit = true
    dino.frame = 3
    deathframe=0
    dino.frame=128
    dino.sizex=2
    dino.strch=10
   end
  end
   
  return hit
 end
 
 
 function dinodeathanim()
  animspeed=2
 
  dino.frame=createanim(dino.frame,animspeed,2,128,131)
  if clock % animspeed == 0 then
   --dino.frame+=2
   flipcount+=1
  end
  if dino.frame>130 then
   --dino.frame=128
  end
  if(flipcount>4)flipcount=1
  
  if flipcount>2 then
   dino.flipx = true
   dino.flipy = true
  else
   dino.flipx = false
   dino.flipy = false
  end
 end
 
 
 function dinodraw()
  --dino outline
   pal()
   pal(5,7)
  for y=-1,1 do
   for x=-1,1 do
    sprs(dino.frame,dino.x+x,dino.y+y,
    dino.sizex,2,
    b2d(not dino.flipx)*(1/(dino.strch/10)),
    b2d(not dino.flipy)*(dino.strch/10))
  
   end
  end
  
  --dino
  pal()
  sprs(dino.frame,dino.x,dino.y,
  dino.sizex,2,
  b2d(not dino.flipx)*(1/(dino.strch/10)),
  b2d(not dino.flipy)*(dino.strch/10))
  
    --hitbox
  x1=dino.x+dino.hitbx
  y1=dino.y+dino.hitby
  x2=dino.x+dino.hitbx+
     dino.hitbw
  y2=dino.y+dino.hitby+
     dino.hitbh
  if(debug)rect(x1,y1,x2,y2,8)

  --dino death ring
  if ringy!=0 then
   spr(5,dino.x-2,ringy)
  end
 end
-->8
--obstacles functions
cact={}
cactdist=20
obstacles={
 --cactus big
 function() return {
 x=127,
 y=groundy-16,
 t="c1",
 s=106,
 sw=2,sh=2,--sprite width and height
 hx=5,hy=4,
 hw=5,hh=10}end,
 --cactus small
 function() return {
 x=127,
 y=groundy-16,
 t="c1",
 s=106,
 sw=2,sh=2,
 hx=5,hy=4,
 hw=5,hh=10}end,
 --cact round
 function() return {
 x=127,
 y=groundy-16,
 t="c3",
 s=111,
 sw=1,sh=2,
 hx=4,hy=6,
 hw=8,hh=8}end,
 --ptero low
 function() return {
 x=140,
 y=groundy-15,
 t="ptero",
 s=78,
 sw=2,sh=2,
 hx=3,hy=6,
 hw=9,hh=3}end,
 --ptero high
 function() return {
 x=140,
 y=groundy-22,
 t="ptero",
 s=78,
 sw=2,sh=2,
 hx=3,hy=6,
 hw=9,hh=3}end,
}

 function cactspawn()
  if cactdist < distance then
   add(cact,rnd(obstacles)())
   cactdist = 
   distance+rand(70,150)
  end
 end
 
 function cactmove()
  for i=1, #cact do
   cact[i].x += speed
   if cact[i].t=="ptero" then
    cact[i].x += speed*0.3
   end
  end
 end
 
 function cactanim()
  for i=1, #cact do
   if cact[i].t=="ptero" then
    cact[i].s=createanim(
     cact[i].s,6,2,160,162)
   end
  end
 end
 
 function cactdespawn()
  for i=#cact-1,1,-1 do
   if cact[i].x < -16 then 
    del(cact,cact[i])
   end
  end
 end
 
 function cactdraw()
 --cactus and obstacles
  for i=1, #cact do
   --spr(17,cact[i],
       --groundy-8)
   spr(cact[i].s,cact[i].x,
       cact[i].y,cact[i].sw,
       cact[i].sh)
   if cact[i].t=="c3" then
    spr(cact[i].s,cact[i].x+8,
       cact[i].y,cact[i].sw,
       cact[i].sh,1)
   end
  end
  
  --debug
  for i=1, #cact do
   cx1 = cact[i].x+cact[i].hx
   cy1 = cact[i].y+cact[i].hy
   cx2 = cx1+cact[i].hw
   cy2 = cy1+cact[i].hh
   if(debug)rect(cx1,cy1,cx2,cy2,11)
  end
 end
-->8
--hills
hills={1}
hillsincr=
--0/ 1\ 2n 3u 4/ 5/ 6n 7\ 8\ 9u 
 {1,-1,-1, 1, 0, 1, -1,0 ,-1,1}
hillsy=80+(5*8)
hillsx=0
hillsgeny=6
hillsgx=0
hillsspeed=0.5

bgcact={29,60,61}


 function drawsun()
  
 end

 function genhills()
 --0/ 1\ 2n 3u 4/ 5/ 6n 7\ 8\ 9u
  if hillsgeny > 14 then
   hillsfinish({2,6})
  elseif hillsgeny < 9 then
   hillsfinish({3,9})
  else
   if hills[#hills]<10 then
    l=hills[#hills]
   else 
    l=hills[#hills-1]
   end
   
   if l==0 or l==5 or l==3 or l==9 then
    hillsfinish({0,2,4,6})
   elseif l==1 or l==8 or l==2 or l==6 then
    hillsfinish({1,3,7,9})
   elseif l==4 then
    hillsfinish({5})
   elseif l==7 then
    hillsfinish({8})
   end
  end
 end

 function hillsfinish(t)
  r=rnd(t)
  add(hills,r)
  if rand(1,5)==1 then 
   add(hills,rnd({29,60,61}))
  end
  
  hillsgeny+=hillsincr[r+1]
 end
 
 function hillsmove()
  hillsx += flr(speed*hillsspeed)
  if hillsx < -8 then
   hillsx = 0
   hillsgx -= 1
   --scrolling
   if hills[1]<10 then
    hillsy-=hillsincr[del(hills,hills[1])+1] * 8     
   end
   if hills[1]>10 then
    del(hills,hills[1])
   end
    --del(hills,hills[1])
   --end
   genhills()
  end
 end
 

 function hillsdraw(sx)
  y=hillsy
  x=sx
  for i=1, #hills do
--0/ 1\ 2n 3u 4/ 5/ 6n 7\ 8\ 9u
   --ground
   ly=y
   for i=1,ceil((127-y)/8)-3 do
    ly+=8
    spr(62,x,ly)
   end
   
   --hill top
   if hills[i]==0 then
    spr(28,x,y)
    y-=8
   elseif hills[i]==1 then
    spr(28,x,y,1,1,1)
    y+=8
   elseif hills[i]==2 then
    spr(31,x,y)
    y+=8
   elseif hills[i]==3 then
    spr(30,x,y)
    y-=8
   elseif hills[i]==4 then
    spr(44,x,y)
   elseif hills[i]==5 then
    spr(45,x,y)
    y-=8
   elseif hills[i]==6 then
    spr(47,x,y)
    y+=8
   elseif hills[i]==7 then
    spr(45,x,y,1,1,1)
    y+=0
   elseif hills[i]==8 then
    spr(44,x,y,1,1,1)
    y+=8
   elseif hills[i]==9 then
    spr(46,x,y)
    y-=8
   else
    spr(hills[i],x,y-1)
    x-=8
   end
   x+=8
  end
 end
 
 
 
-->8
--dust and clouds and sky
dustkicktime=0

clouds={{x=127,
      y=75,
      spd=0.7,
      t=25,
      lyr=1}}
clouddist=30

day=true
sunspd=0.2
sunx=27
suny=30
moonx=0
moony=0
sunradius=7
sunsetphase=0

dust=39
dustdist=30
-- 39->43
dusts={}


 function dustspawn()
  if dustdist < distance then
   add(dusts, 
     {x=127,y=groundy,t=rand(39,43)})
   dustdist = 
   distance+rand(12,19)
  end
 end
 
 function dustmove()
  for i=1, #dusts do
   dusts[i].x += speed
  end
 end
 
 function dustdespawn()
  for i=#dusts-1,1,-1 do
   if dusts[i].x < 0 then 
    del(dusts,dusts[i])
   end
  end
 end
 
 function dustdraw()
  for i=1, #dusts do
   spr(dusts[i].t,
   dusts[i].x,dusts[i].y)
  end
 end
 
 function cloudspawn()
  if clouddist < distance then
   sp=rand(30,70)/100
   l=1
   if sp < hillsspeed then
    l=0
   end 
   r=add(clouds, 
     {x=127,
      y=rand(25,75),
      spd=sp,
      t=rnd({25}),
      lyr=l}) 
   clouddist = 
   distance+rand(30,100)
  end
 end
 
 function cloudmove()
  for i=1, #clouds do
   clouds[i].x += clouds[i].spd
                  * speed
  end
 end
 
 function clouddespawn()
  for i=#clouds-1,1,-1 do
   if clouds[i].x < -16 then 
    del(clouds,clouds[i])
   end
  end
 end
 
 function cloudsdraw(layer)
  for i=1, #clouds do
   if clouds[i].lyr==layer then 
    spr(clouds[i].t,
    clouds[i].x,clouds[i].y,2,1)
   end
  end
 end