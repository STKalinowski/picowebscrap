-- star anise chronicles:
-- oh no wheres twig
local
	total_stars,
	total_glasses,
	g_found_stars,
	g_broke_glasses,
	g_cheez_state,
	g_nyapo_state,
	g_purrl_state,
	g_twig_state
	= 0, 0, 0, 0, 0
-->8
-- utilities
local planck = 0.0000152587890625
local function nop() end
local function rndi0(n)
	return flr(rnd(n))
end
local function rndr(a, b)
	return rnd(b - a) + a
end

local function sort(list, keyfunc)
	for i = 2, #list do
		for j = i, 2, -1 do
			if keyfunc(list[j-1]) > keyfunc(list[j]) then
				list[j], list[j-1] = list[j-1], list[j]
			else
				break
			end
		end
	end
end

local function prints(s, x, y, c1, c2)
	print(s, x, y+1, c2 or 1)
	print(s, x, y, c1)
end
local function spr8(s, x, y, mirror, vflip)
	spr(s, x*8, y*8, 1, 1, mirror, vflip)
end
local _clear_pal = {}
for i = 0, 15 do
	_clear_pal[i] = i
end
local function resetpal()
	pal(_clear_pal)
end
local function fillscr(c, pat)
	fillp(pat)
	rectfill(0, 0, 128, 128, c)
	fillp()
end

local function cowrap(f)
	local coro, done = cocreate(f)
	return function(...)
		if not done then
			assert(coresume(coro, ...))
			done = costatus(coro) == 'dead'
		end
		return done
	end
end
local function yieldn(n)
	for i=1,n do
		yield()
	end
end

-- simple oo
local obj = {init = nop}
obj.__index = obj
function obj:__call(...)
	local o = setmetatable({}, self)
	return o, o:init(...)
end
function obj:extend(proto)
	proto = proto or {}
	proto.__call, proto.__index =
		self.__call, proto
	return setmetatable(proto, self)
end

local vec = obj:extend{}
function vec:init(x, y)
	self.x, self.y =
		x or 0, y or x or 0
end
function vec:clone()
	return vec(self.x, self.y)
end
function vec:__add(v)
	return vec(self.x + v.x, self.y + v.y)
end
function vec:__sub(v)
	return vec(self.x - v.x, self.y - v.y)
end
function vec:__mul(n)
	return vec(self.x * n, self.y * n)
end
function vec:elemx(v)
	return vec(self.x * v.x, self.y * v.y)
end
function vec:unpack()
	return self.x, self.y
end
function vec:iadd(v)
	self.x += v.x
	self.y += v.y
end

local bbox = obj:extend{}
function bbox:init(origin, size)
	local corner = origin + size
	self.x0, self.y0,
	self.x1, self.y1,
	self.w, self.h =
		origin.x, origin.y,
		corner.x, corner.y,
		size:unpack()
end
function bbox:moveby(dx, dy)
	self.x0 += dx
	self.y0 += dy
	self.x1 += dx
	self.y1 += dy
end
function bbox:overlaps(other)
	return self.x0 < other.x1 and other.x0 < self.x1 and self.y0 < other.y1 and other.y0 < self.y1
end
function bbox:itermap()
	local x0 = flr(self.x0)
	local x, y = x0 - 1, flr(self.y0)
	return function()
		x += 1
		if x >= self.x1 then
			x = x0
			y += 1
			if y >= self.y1 then
				return
			end
		end
		return x, y, mget(x, y)
	end
end
local fullmapbox = bbox(
	vec(), vec(128, 64))

-- px9 decompressor
-- from #34058
function px9_decomp(x0,y0,src)
	local function vlist_val(l,val)
		for i=1,#l do
			if l[i]==val then
				for j=i,2,0xffff do
					l[j]=l[j-1]
				end
				l[1]=val
				return i
			end
		end
	end
	local cache,cache_bits=0,0
	function getval(bits)
		if cache_bits<16 then
			cache+=lshr(%src,16-cache_bits)
			cache_bits+=16
			src+=2
		end
		local val=cache<<(32-bits)>>>16-bits
		cache>>>=bits
		cache_bits-=bits
		return val
	end
	function gn1(tot)
		for bits=1,15 do
			local vv=getval(bits)
			tot+=vv
			if (vv<2^bits-1) return tot
		end
	end
	local w,h,b,el,pr,splen,mode=gn1"1",gn1"0",gn1"1",{},{},0
	for i=1,gn1"1" do
		add(el,getval(b))
	end
	for y=y0,y0+h do
		for x=x0,x0+w-1 do
			splen-=1
			if (splen<1) splen,mode=gn1"1",not mode
			local a=y>y0 and pget(x,y-1) or 0
			local l=pr[a]
			if not l then
				l={}
				for e in all(el) do
					add(l,e)
				end
				pr[a]=l
			end
			local v=l[mode and 1 or gn1"2"]
			vlist_val(l,v)
			vlist_val(el,v)
			pset(x,y,v)
			x+=1
			y+=x\w
			x%=w
		end
	end
end
-->8
-- scaffolding
local gravity = 0.046875
local clock = 0

local actor = obj:extend{
	draw = nop,
	onhit = nop,
	z = 0,
	age = -1,
	ttl = nil,
	anchor = vec(),
	--size
}
function actor:init(pos)
	self.pos = pos
	if self.size then
		self.shape = bbox(
			pos - self.anchor, self.size)
	end
end
function actor:update()
	self.age += 1
	if self.ttl and self.age >= self.ttl then
		self:destroy()
	end
end
function actor:drawtile(t)
	spr8(t, self.pos:unpack())
end
function actor:erase(t)
	mset(self.pos.x, self.pos.y, t or 0)
end
function actor:moveby(d)
	self.pos:iadd(d)
	if self.shape then
		self.shape:moveby(d:unpack())
	end
end
function actor:destroy()
	self._doomed = true
end

local mobactor = actor:extend{
	is_mobile = true,
	is_solid = true,
}
function mobactor:init(...)
	actor.init(self, ...)
	self.vel = vec()
end
-- slide along one axis
-- p, q: movement, perp
function mobactor:_slide_axis(
		_p, _q, d, qoff)
	if d == 0 then
		return 0
	end
	-- find leading edge
	local shape, s, near, far =
		self.shape, sgn(d), 0, 1
	if s < 0 then
		near, far = far, near
	end
	local lead = shape[_p..far]
	local goal = lead + d
	local q0, q1 =
		qoff + shape[_q..0],
		qoff + shape[_q..1]

	local obstacles = {}
	if not self.geom_only then
		for actor in all(self._zone.actors) do
			if actor ~= self and actor.shape then
				local coord = actor.shape[_p..near]
				if
					-- only if in p range
					s * lead <= s * coord and
					s * coord <= s * goal and
					-- only if q overlap
					q0 < actor.shape[_q..1] and
					q1 > actor.shape[_q..0]
				then
					add(obstacles, {
						coord = coord,
						actor = actor,
					})
				end
			end
		end
	end
	-- block at the edge of the map
	local zone = self._zone
	local z0 = zone.origin[_p]
	local z1 = z0 + zone.size[_p]
	if goal < z0 then
		add(obstacles, {
			coord = z0,
			edge = true,
		})
	end
	if goal > z1 then
		add(obstacles, {
			coord = z1,
			edge = true,
		})
	end
	-- add dummy entries for rows
	-- or columns of tiles
	local toff, t0, t1 =
		-1, ceil(goal), flr(lead)
	if s > 0 then
		toff, t0, t1 = 0, ceil(lead), flr(goal)
	end
	-- don't check tiles
	-- outside the zone
	for tp = max(z0, t0), min(z1 - 1, t1) do
		add(obstacles, {
			coord = tp,
			tilecoord = tp + toff,
		})
	end
	-- sort in order we hit them
	sort(obstacles, function(ob)
		return s * ob.coord
	end)

	local blocked, blocked_at
	for ob in all(obstacles) do
		if blocked_at and s*ob.coord > s*blocked_at then
			break
		end
		if ob.tilecoord then
			local tp = ob.tilecoord
			for tq = flr(q0), flr(q1 - planck) do
				local t = mget(tq, tp)
				if _p == 'x' then
					t = mget(tp, tq)
				end
				if fget(t) & self._zone.mask ~= 0 then
					blocked = blocked
						or fget(t, 7)
						or (fget(t, 6)
							and _p == 'y' and s > 0)
				end
			end
		elseif ob.actor then
			if self.is_player then
				ob.actor:onhit(self)
			end
			blocked = blocked or ob.actor.is_solid
		else -- edge
			if self.is_player then
				local x, y = 0, 0
				if _p == 'x' then
					x = s
				else
					y = s
				end
				if world:chzone(vec(x, y)) then
					blocked_at = ob.coord
					break
				end
			end
			blocked = true
		end
		if blocked then
			blocked_at = ob.coord
		end
	end
	if blocked_at then
		return blocked_at - lead, blocked
	else
		return d
	end
end
function mobactor:slide(d)
	local dx, bx = self:_slide_axis(
		'x', 'y', d.x, 0)
	local dy, by = self:_slide_axis(
		'y', 'x', d.y, dx)
	return vec(dx, dy), bx, by
end

local particle = actor:extend{}
function particle:init(pos, ...)
	actor.init(self, pos)
	self.vel, self.ttl, self.col, self.z = ...
end
function particle:update()
	actor.update(self)
	self:moveby(self.vel)
end
function particle:draw()
	pset(self.pos.x*8, self.pos.y*8, self.col)
end

--------------------------------
-- game world

local zone = obj:extend{
	size = vec(16),
}
function zone:init(z, indoors, is_toggle)
	self.z, self.actors, self.mapcoords =
		z, {}, vec(z%8, z\8)
	self.origin = self.mapcoords * 16
	self.box = bbox(
		self.origin, self.size)
	self:set_indoors(indoors)

	for x, y, t in self.box:itermap() do
		local tilecls = tile_actors[t]
		if tilecls and
			(not indoors or tilecls.is_door)
		then
			local actor = tilecls(vec(x, y), t)
			if actor.is_door and is_toggle then
				actor:init_toggle()
			end
			self:add(actor)
		end
	end
end
function zone:add(actor)
	if actor._zone then
		actor._zone:del(actor)
	end
	add(self.actors, actor)
	actor._zone = self
end
function zone:del(actor)
	actor._zone = nil
	del(self.actors, actor)
end
function zone:_zsort()
	sort(self.actors, function(a) return a.z end)
end
function zone:neighbor(d)
	local mz = 128 + self.mapcoords.y * 16 + self.mapcoords.x
	if d.x > 0 or d.y > 0 then
		mz += 64
	end
	if d.y == 0 then
		mz += 8
	end
	local z = fget(mz)
	return z < 255 and z
end
function zone:set_indoors(indoors)
	self.indoors = indoors
	self.bg_mask = 1
	if indoors then
		self.bg_mask *= 4
	end
	self.fg_mask, self.mask =
		self.bg_mask * 2,
		self.bg_mask * 3
end
function zone:broadcast(method, ...)
	local found
	for actor in all(self.actors) do
		if actor[method] then
			actor[method](actor, ...)
			found = true
		end
	end
	return found
end
function zone:update()
	for actor in all(self.actors) do
		if actor._doomed then
			self:del(actor)
		else
			actor:update()
		end
	end
end
function zone:draw()
	self:_zsort()
	local x, y = self.origin:unpack()
	map(x, y, x*8, y*8, 16, 16, self.bg_mask)
	for actor in all(self.actors) do
		if actor.z >= 100 then
			break
		end
		if not actor._doomed then
			actor:draw()
		end
	end
	map(x, y, x*8, y*8, 16, 16, self.fg_mask)
	for actor in all(self.actors) do
		if actor.z >= 100 and not actor._doomed then
			actor:draw()
		end
	end
end

local function readaxis(f, neg, pos)
	local ret = 0
	if f(neg) then
		ret -= 1
	end
	if f(pos) then
		ret += 1
	end
	return ret
end
local function draw_box(x0, y0, x1, y1, three)
	for i, c in ipairs{3, 5} do
		rect(x0-i, y0-i, x1+i, y1+i, c)
	end
	rectfill(x0, y0, x1, y1, 7)
	if three then
		rect(x0, y0, x1, y1, 11)
	end
end

local starfield, starcam =
	{}, vec()
for x = 0, 128, 16 do
	for y = 0, 128, 16 do
		add(starfield, {
			pos = vec(
				x + rndi0(16),
				y + rndi0(16)),
			c = rnd{5,6,13,14,15},
			t = 0,
			freq = 150 + rndi0(900),
			parallax = rndi0(4)/16,
		})
	end
end
function starfield:draw()
	for star in all(self) do
		star.t += 1
		star.t %= star.freq
		local c, p =
			star.c,
			star.parallax * 128
		local x, y = (star.pos - starcam * p):unpack()
		x %= 128
		y %= 128
		if star.t < 4 then
			circ(x, y, 1, c)
			c = 7
		end
		pset(x, y, c)
	end
end

local scene = obj:extend{
	update = nop,
	draw = nop,
}

world, player = scene()
function world:configure(zone)
	zone:add(player)
	self.zone = zone
	self.curabil = 0
end
function world:chzone(d)
	local z = self.zone:neighbor(d)
	-- don't transition until
	-- next frame; breaks physics
	if z then
		schedule(0, function()
			self:_chzone(z, d)
		end)
		return true
	end
end
function world:_chzone(z, d)
	self.trans_t = 0
	self.trans_dir = d
	local oldzone = self.zone
	self.oldzone = oldzone
	self.zone = zone(z, oldzone.indoors)
	self.zone:add(player)
	player:moveby(
		self.zone.origin
		- oldzone.origin
		- oldzone.size:elemx(d))
end
function world:update()
	if self.trans_t then
		self.trans_t += 0.125
		starcam:iadd(
			self.trans_dir * 0.125)
		player:moveby(
			self.trans_dir:elemx(
				vec(0.125, 0.25)))
		if self.trans_t >= 1 then
			if self.trans_dir.y == -1 then
				-- boost after jump up
				local v = player.vel
				v.y = min(v.y, -0.5)
			end
			self.oldzone, self.trans_t, self.trans_dir = nil
		end
		return
	end

	if self.abil_t then
		self.abil_t *= 2
		if abs(self.abil_t) >= 1 then
			self.abil_t, self.prevabil = nil
			-- remove dummy entries
			for i, abil in ipairs(player.known) do
				if abil == false then
					del(player.known, false)
					if i <= self.curabil then
						self.curabil -= 1
					end
					break
				end
			end
		end
	end

	player.do_walk = readaxis(btn, ⬅️, ➡️)
	if btnp(🅾️) then
		player.do_jump = 2
	elseif btn(🅾️) then
		player.do_jump = 1
	else
		player.do_jump = 0
	end
	local n = #player.known
	if n > 0 then
		local v = readaxis(btnp, ⬆️, ⬇️)
		if v ~= 0 then
			sfx(0)
			self.prevabil,
			self.abil_t,
			self.curabil =
				self.curabil,
				v * 0.125,
				(self.curabil + v - 1) % n + 1
		end
		if not self.abil_t then
			player.do_abil = btnp(❎) and self.curabil
		end
	end

	self.zone:update()
end
function world:_draw_ui()
	draw_box(110, 8, 119, 17)
	spr(63, 111, 2)
	spr(63, 111, 16, 1, 1, false, true)

	local y = 9
	clip(111, y, 8, 8)
	if self.abil_t then
		y += self.abil_t * 8
		local abil = player.known[self.prevabil]
		if abil then
			spr(abil.tile, 111, y)
		end
		y -= sgn(self.abil_t) * 8
	end
	local abil = player.known[self.curabil]
	if abil then
		spr(abil.tile, 111, y)
	end
	clip()
end
function world:draw()
	cls()
	if self.zone.indoors then
		fillscr(0x12, 0b0111111010111101)
	else
		starfield:draw()
	end
	local cam = self.zone.origin * 8
	if self.trans_t then
		camera((
			self.oldzone.origin * 8
				+ self.trans_dir * self.trans_t * 128
			):unpack())
		self.oldzone:draw()
		cam:iadd(self.trans_dir *
			(self.trans_t * 128 - 128))
	end
	camera(cam:unpack())
	self.zone:draw()
	camera()
	self:_draw_ui()
end

-->8
-- anise scenes

dialogue = obj:extend{}
function dialogue:init(scriptid)
	self.script,
	self.draw,
	self.scroll =
		speeches[scriptid],
		cowrap(self._draw_coro),
		cowrap(self._scroll_coro)
end
function dialogue:_scroll_coro()
	local function wait()
		self.waiting = true
		while self.waiting do
			yield()
		end
	end
	local cc, s, chat_t = 0, 1, 0
	for step in all(self.script) do
		if type(step) == 'string' then
			s, self.line, self.prevline = 1
			for i = 1, #step do
				local o = ord(step, i)
				if o == 10 then
					self.line = sub(step, s, i-1)
					if self.prevline then
						wait()
					end
					self.prevline, self.line, s
						= self.line, '', i+1
				else
					if chat_t <= 0 and o > 96 then
						sfx(18, -1, rndi0(4)*2+self.sfx0*8, 2)
						chat_t = 2
					end
					cc += 1
					if cc > 2 then
						cc -= 2
						self.line = sub(step, s, i)
						yield()
						chat_t -= 1
					end
				end
			end
			--self.line = sub(step, s, i)
			wait()
		elseif type(step) == 'table' then
			for k, v in pairs(step) do
				self[k] = v
			end
		end
	end
	self.closed = true
end
function dialogue:update()
	if btnp(🅾️) or btnp(❎) then
		self.waiting = false
	end
	self:scroll()
end
function dialogue:_draw_coro()
	for y = 128,111,-4 do
		draw_box(0, y, 128, 128)
		yield()
	end
	while not self.closed do
		draw_box(0, 111, 128, 128)
		if self.speaker then
			sspr(self.speaker%16*8, self.speaker\16*8, 16, 16, -1, 112)
			if self.mood then 
				spr(self.mood + clock%16\8, 15, 110)
			end
		end
		local texty = 113
		if self.prevline then
			prints(self.prevline, 24, texty, 1, 6)
			texty += 8
		end
		prints(self.line, 24, texty, 1, 6)
		if self.waiting then
			spr(61, 120, 120 - clock%20\10)
		end
		yield()
	end
	for y = 111,128,4 do
		draw_box(0, y, 128, 128)
		yield()
	end
	pop()
end

local gotmsg = obj:extend{}
function gotmsg:init(ability)
	self.ability = ability
	self.draw = cowrap(self._draw_coro)
end
function gotmsg:update()
	self.update = nop
	sfx(16)
	player:learn(self.ability)
end
function gotmsg:_draw_coro()
	for y = 64, 56, -2 do
		draw_box(-1, y, 129, 128-y, true)
		yield()
	end
	local abil = self.ability
	while not btnp(🅾️) or btnp(❎) do
		draw_box(-1, 54, 129, 74, true)
		spr(abil.tile, 4, 60)
		print("you got: ", 16, 59, 0)
		print(abil.name, 52, 59, 2)
		print(abil.desc, 16, 65, 13)
		yield()
	end
	for y = 56, 64, 2 do
		draw_box(-1, y, 129, 128-y, true)
		yield()
	end

	pop()
	if self.ability.name == 'jump' then
		push(dialogue'jump')
	end
end

local cutscene = obj:extend{
	age = 0,
}
function cutscene:init(
		s0, s1, ...)
	self.tile, self.lose = ...
	self.start = s0
		- world.zone.origin
		- vec(0.5)

	self.vel = (s1 - s0) * 0.03333
	self.vel.y -= 15 * gravity
end
function cutscene:update()
	self.age += 1
	if self.age == 1 then
		sfx(21)
		if self.lose then
			player.known[world.curabil] = false
		end
	end
	if self.age >= 30 then
		pop()
	end
end
function cutscene:draw()
	local s = self.start + self.vel * self.age
	spr8(
		self.tile, s.x,
		s.y + 0.5 * gravity * self.age^2)
end

doorshutter = obj:extend{
	age = 0,
	pattern = 0xffff.8,
}
function doorshutter:update()
	local bit = 1 << self.age*7%16
	if self.age >= 32 then
		pop()
	elseif self.age >= 16 then
		self.pattern |= bit
	else
		self.pattern &= ~bit
	end
	self.age += 1
	if self.age == 16 then
		world.zone = zone(
			world.zone.z,
			not world.zone.indoors,
			true)
		world.zone:add(player)
	end
end
function doorshutter:draw()
	fillscr(2, self.pattern)
end
-->8
-- actors
local puff = actor:extend{
	ttl = 8,
	z = 100,
}
function puff:draw()
	local t, x, y =
		28 + self.age\2,
		self.pos:unpack()
	spr8(t, x + 0.25, y - 1)
	spr8(t, x - 1.25, y - 1, true)
end

local pawprint = actor:extend{
	colors = {7,7,7,6,6,13,14},
	ttl = 7,
	z = 100,
}
function pawprint:draw()
	pal(7, self.colors[self.age+1])
	self:drawtile(0)
	resetpal()
end

local aowr = actor:extend{
	ttl = 20,
	z = 100,
}
function aowr:update()
	actor.update(self)
	self.pos = player.pos
		- vec(1.625, 4.25)
end
function aowr:draw()
	local d, x, y =
		self.age % 4 \ 2 / 8,
		self.pos:unpack()
	spr8(48, x, y + 0.375 + d)
	spr8(49, x + 0.625, y - d)
	spr8(50, x + 1.5, y + d)
	spr8(51, x + 2.125, y + 0.5 - d)
end

local sparkle = actor:extend{
	z = 100,
}
function sparkle:init(pos, ...)
	actor.init(self, pos)
	self.vel, self.ttl, self.age, self.palmap = ...
	self.age *= self.ttl
end
function sparkle:update()
	actor.update(self)
	self.pos:iadd(self.vel)
end
function sparkle:draw()
	pal(9, self.palmap[1] or 9)
	pal(10, self.palmap[2] or 10)
	self:drawtile(44 + abs(self.age)*4\self.ttl)
	resetpal()
end

local luneko = mobactor:extend{
	size = vec(1, 1.75),
	anchor = vec(0.5, 1.75),
	palmap = {},
	is_solid = false,
	--left
}
function luneko:init(pos)
	mobactor.init(self, pos + vec(1, 3))
end
function luneko:draw_at(pos, flip, walk)
	local ti = self.tile
	local y0, tiles =
		pos.y - 3,
		{ti, ti+1, ti+16, ti+17, 33, 34}
	if walk then
		y0 -= 0.125
		if tiles[2] == 2 then
			tiles[2] = 3
		end
		tiles[5] = 19
		tiles[6] = 35
	end
	local x0 = pos.x - 1.125
	local dx = 1
	if flip then
		dx = -1
		x0 += 1.25
	end
	pal(self.palmap)
	for i = 0, 2 do
		spr8(tiles[i*2+1], x0, y0+i, flip)
		spr8(tiles[i*2+2], x0 + dx, y0+i, flip)
	end
	resetpal()
end
function luneko:draw()
	self:draw_at(self.pos, self.left)
end

local function _make_item_cutscene(s1, tile)
	return cutscene(
		world.zone.origin + vec(14.875, 1.625),
		s1, tile, true)
end
local function sparkle_block(x, y, palmap)
	for i = 1, 3 do
		world.zone:add(sparkle(
			vec(x+rnd(), y+rnd()),
			vec(0, -0.03125),
			15, rndr(-0.5, 0), palmap))
	end
end
local function swap_blocks(swaps, palmap)
	local box, any = world.zone.box
	for x, y, from in fullmapbox:itermap() do
		if swaps[from] then
			mset(x, y, swaps[from])
			if palmap and
				box.x0 <= x and x < box.x1 and
				box.y0 <= y and y < box.y1
			then
				any = true
				sparkle_block(x, y, palmap)
			end
		end
	end
	if any then
		sfx(22)
	end
end

local anise = luneko:extend{
	tile = 1,
	is_player = true,
	do_walk = 0,
	do_jump = 0,
	--do_abil
	ground = true,
	walk_cap = 0.375,
	cooldown = 0,
	z = 10,
	--can_jump
}
anise.abilities = {}
local function _define_ability(tile, name, desc, invoke)
	anise.abilities[tile] = {
		tile = tile,
		name = name,
		desc = desc,
		invoke = invoke,
	}
end
_define_ability(
	16, "key",
	"probably opens a lock??",
	function(self)
		for x, y, t in self._zone.box:itermap() do
			if t == 95 then
				push(
					function()
						sfx(2)
						sfx(22)
						for y2 = y-2, y+3 do
							mset(x, y2, 0)
							sparkle_block(x, y2, {})
						end
					end,
					_make_item_cutscene(
						vec(x+0.5, y+1), 16))
				return
			end
		end
		push(dialogue'no_key')
	end)
_define_ability(
	32, "slice of pizza",
	"cold and gross",
	function(self)
		if not self._zone:broadcast'onpizza' then
			push(dialogue'no_pizza')
		end
	end)
_define_ability(
	39, "plastic bag",
	"makes a crinkle sound",
	function(self)
		self.cooldown = 10
		sfx(20)
		schedule(10, function()
			self._zone:broadcast'oncrinkle'
		end)
	end)
_define_ability(
	52, "aoowr",
	"meow to talk or open doors",
	function(self)
		self.cooldown = 20
		sfx(10)
		self._zone:add(aowr(self.pos))
		schedule(20, function()
			if not self._zone:broadcast'onaowr' then
				push(dialogue(rnd{
					'aowr1', 'aowr2',
					'aowr3', 'aowr4',
				}))
			end
		end)
	end)
_define_ability(
	53, "pap",
	"smack with your pest paws",
	function(self)
		self.cooldown = 4
		sfx(13)
		local s = self.left and -1 or 1
		local o = self.pos + vec(s, -1)
		self._zone:add(pawprint(
			o + vec(
				rndr(-0.75, -0.25),
				rndr(-0.75, -0.25))))
		local pawshape = bbox(
			o - vec(0.25), vec(0.5))
		for actor in all(self._zone.actors) do
			if actor.shape
				and actor.shape:overlaps(pawshape)
				and actor.onpap
			then
				actor:onpap(s)
			end
		end
	end)
_define_ability(
	54, "telepawt",
	"zip across the screen",
	function(self)
		self.cooldown = 15
		local nx = 16
			- self.pos.x
			+ self._zone.origin.x * 2
		local newpos = vec(nx, self.pos.y)
		local ourbox = bbox(
			newpos - self.anchor,
			self.size)
		function check()
			for actor in all(self._zone.actors) do
				if actor ~= self and actor.shape and
					actor.is_solid and
					actor.shape:overlaps(ourbox)
				then
					return
				end
			end
			for x, y, t in ourbox:itermap() do
				if fget(t) & self._zone.mask ~= 0 and fget(t, 7) then
					return
				end
			end
			return true
		end
		local sparklepos, sparklepal = self.pos:clone()
		if check() then
			sfx(15)
			self:moveby(vec(nx - self.pos.x, 0))
			self.vel.x *= -1
			self.left, sparklepal =
				not self.left, {12}
		else
			sfx(17)
			sparklepos, sparklepal =
				vec(nx, self.pos.y), {5,6}
		end
		for i = 1, 20 do
			self._zone:add(sparkle(
				sparklepos + vec(
					rndr(-0.75, 0.75),
					-rnd(3)),
				vec(0, -0.015625),
				30, rndr(0.25, 0.875),
				sparklepal))
		end
	end)
_define_ability(
	55, "jump",
	"it's just jumping")

function anise:init(...)
	luneko.init(self, ...)
	self.known = {}
end
function anise:learn(ability)
	if ability.name == 'jump' then
		self.can_jump = true
	else
		add(self.known, ability)
		del(player.known, false)
		world.curabil = #self.known
	end
end
function anise:update()
	mobactor.update(self)
	local vel = self.vel

	if self.sooty then
		self._zone:add(particle(
			self.pos + vec(
				rndr(-0.75, 0.75),
				rndr(-3, -0.5)),
			vec(0, -0.0625),
			20, rnd{0, 1, 14, 13}))
	end

	if self.do_walk ~= 0 then
		self.left = self.do_walk < 0
	end

	if self.can_jump and
		self.do_jump == 2 and
		self.ground
	then
		sfx(8)
		vel.y = -0.59375
	elseif self.do_jump == 0 and not self.ground then
		vel.y = max(-0.1484375, vel.y)
	end

	if self.do_abil and self.cooldown == 0 then
		local abil = self.known[self.do_abil]
		if abil then
			abil.invoke(self)
		end
	elseif self.cooldown > 0 then
		self.cooldown -= 1
	end

	local goal = self.do_walk * self.walk_cap
	local delta, accel, was_ground =
		goal - vel.x, 0.09375, self.ground
	if not self.ground then
		accel /= 2
	end
	vel.x += sgn(delta) * min(accel, abs(delta))
	vel.y += gravity
	vel.y = sgn(vel.y) * min(abs(vel.y), 4)
	local d, bx, by = self:slide(vel)
	self:moveby(d)

	if bx then
		vel.x = 0
	end
	self.ground = false
	if by then
		if vel.y > 0 then
			self.ground = true
			if not was_ground then
				-- landed
				sfx(9)
				self._zone:add(puff(
					self.pos:clone()))
			end
		end
		vel.y = 0
	end
end

function anise:draw()
	if self.sooty then
		pal{
			1,2,13, 4,14,13,7,
			8,6,6,11, 12,14,
		}
	end
	self:draw_at(
		self.pos,
		self.left,
		not self.ground or
			(self.do_walk ~= 0 and self.age % 8 < 4))
	resetpal()
end

local cheezball = luneko:extend{
	tile = 42,
	palmap = {[3]=2, [6]=13, [13]=14},
}
function cheezball:init(...)
	luneko.init(self, ...)
	self.left = g_cheez_state >= 2
end
function cheezball:oncrinkle()
	if g_cheez_state < 2 then
		g_cheez_state = 2
		self.left = true
		push(
			dialogue'cheez_plastic2',
			function()
				swap_blocks({[110]=126}, {14, 13})
				for i = 1, 30 do
					world:update()
					yield()
				end
			end,
			_make_item_cutscene(
				self.pos, 39),
			dialogue'cheez_plastic')
	end
end
function cheezball:onpap()
	push(dialogue'cheez_pap')
end
function cheezball:onaowr()
	push(dialogue'cheez_aowr')
end
function cheezball:update()
	if g_cheez_state == 0 and
		player.ground and
		player.pos.x + 8 > self.pos.x
	then
		g_cheez_state = 1
		push(dialogue'cheez_intro')
	end
end

local nyapoion = luneko:extend{
	tile = 10,
	palmap = {[3]=8, [6]=15, [13]=8, [1]=2},
}
function nyapoion:init(...)
	luneko.init(self, ...)
	self.left = not g_nyapo_state
end
function nyapoion:onpap()
	push(dialogue'nyapo_pap')
end
function nyapoion:onaowr()
	if not g_nyapo_state then
		self.left = false
		push(
			gotmsg(anise.abilities[16]),
			cutscene(self.pos, player.pos, 16),
			dialogue'nyapo_intro')
		g_nyapo_state = 1
	elseif g_nyapo_state == 1 then
		push(dialogue'nyapo_hungry')
	else
		push(dialogue'nyapo_general')
	end
end
function nyapoion:onpizza()
	g_nyapo_state = 2
	push(
		function()
			swap_blocks({[94]=125}, {10, 7})
		end,
		dialogue'nyapo_pizza',
		_make_item_cutscene(
			self.pos, 32))
end

local purrl = luneko:extend{
	tile = 40,
	palmap = {[3]=5},
	left = true,
}
function purrl:onaowr()
	if not g_purrl_state then
		g_purrl_state = 1
		push(
			function()
				swap_blocks({[127]=78}, {12, 13})
			end,
			dialogue'purrl_intro')
	elseif player.sooty then
		push(dialogue'purrl_soot')
	elseif g_purrl_state == 1 then
		g_purrl_state = 2
		push(
			dialogue'purrl_clean2',
			function()
				swap_blocks({[78]=124}, {12, 13})
				for i = 1, 30 do
					world:update()
					yield()
				end
			end,
			dialogue'purrl_clean')
	else
		push(dialogue'purrl_aowr')
	end
end
function purrl:onpap()
	push(dialogue'purrl_pap')
end

local twig = luneko:extend{
	tile = 8,
	palmap = {[3]=2, [6]=15, [13]=8},
}
function twig:update()
	if not g_twig_state and
		player.ground and
		player.pos.x + 4 > self.pos.x
	then
		g_twig_state = 1
		music(-1, 2000)
		push(
			function()
				_scene = toendscene()
			end,
			dialogue'twig')
	end
end

local pickup = actor:extend{
	size = vec(1),
	z = 100,
}
function pickup:update()
	actor.update(self)
	if self.age % 4 == 0 then
		self._zone:add(sparkle(
			self.pos + vec(
				rndr(-0.5,1),
				rndr(-0.5,1)),
			vec(0, -0.1875),
			16, 0, {}))
	end
end

local star = pickup:extend{}
function star:onhit(by)
	if self.got then
		return
	end
	self.got = true

	g_found_stars += 1
	sfx(19)
	push(function()
		for i = 1, 40 do
			yield()
		end
		for a = 0, 1, 0.03125 do
			self._zone:add(sparkle(
				self.pos:clone(),
				vec(cos(a), sin(a))
					* rndr(0.125, 0.375),
				20, rndr(-0.5, 0.25),
				{10, 15}))
		end
		self:erase()
		self:destroy()
	end)
end
function star:draw()
	self:drawtile(38)
end

local powerup = pickup:extend{}
function powerup:init(pos, t)
	pickup.init(self, pos)
	self.ability = anise.abilities[t]
end
function powerup:onhit(by)
	sfx(16)
	push(gotmsg(self.ability))
	self:erase()
	self:destroy()
end
function powerup:draw()
	-- pos is upper left of tile
	local a = self.age
	local x, y = self.pos:unpack()
	y += sin(a/45) * 0.25
	local bg = 60 + flr(a % 15 / 5)
	if a % 15 < 5 then
		pal(10, 9)
		pal(9, 8)
	elseif a % 15 < 10 then
		pal(10, 8)
		pal(9, 10)
	end
	for dx = -0.5, 0.5 do
		for dy = -0.5, 0.5 do
			spr8(62, x + dx, y + dy, dx > 0, dy > 0)
		end
	end
	resetpal()
	spr8(self.ability.tile, x, y)
end

local door = actor:extend{
	size = vec(0.25),
	anchor = vec(-0.75, -2.75),
	z = -1,
	is_door = true,
	progress = 0,
	motion = 0,
}
function door:init_toggle()
	self.progress = 1
	self.motion = -0.125
end
function door:onaowr()
	if self.progress == 0 then
		self.motion = 0.125
	end
end
function door:update()
	actor.update(self)
	self.progress += self.motion
	if self.progress == self.progress\1 then
		self.motion = 0
	end
	if self.progress == 1 and
		self.shape:overlaps(
			player.shape)
	then
		sfx(3)
		player.vel = vec()
		push(doorshutter())
	end
end
function door:draw()
	local ds = self.progress * 3 \ 1
	local x, y = self.pos:unpack()
	spr8(67 + ds, x, y)
	spr8(67 + ds, x + 1, y, true)
	x *= 8
	y *= 8
	y += 8
	local doorx = 24 + ds * 8
	sspr(doorx, 36, 8, 4, x, y, 8, 16)
	sspr(doorx, 36, 8, 4, x + 8, y, 8, 16, true)
end


local smoke = actor:extend{
	z = 50,
	ttl = 240,
}
function smoke:init(pos)
	actor.init(self, pos)
	self.r, self.vr, self.vel =
		rndr(1, 4),
		0.0625,
		vec(
			rndr(-0.015625, 0.015625),
			rndr(-0.09375, -0.046875))
end
function smoke:update()
	actor.update(self)
	self.z = self.age\6 + 50
	self.r += self.vr
	self:moveby(self.vel)
end
function smoke:draw()
	circfill(
		self.pos.x*8, self.pos.y*8, self.r,
		({1,2,14,13})[self.age\60+1])
end

local vent = actor:extend{
  size = vec(1, 16),
  anchor = vec(0.5, 16),
}
function vent:onhit(by)
	by.sooty = true
end
-- no draw; tile is visible
function vent:update()
	actor.update(self)
	if self.age % 4 == 0 then
		self._zone:add(smoke(
			self.pos + vec(0.5, 0)))
	end
end

waterfall = actor:extend{
	size = vec(0.25, 6),
	anchor = vec(0.125, 0),
	z = 100,
	xoff = 0,
	xoff_timer = 1,
}
function waterfall:init(pos)
	actor.init(self, pos + vec(1))
end
function waterfall:onhit(by)
	by.sooty = false
end
function waterfall:update()
	actor.update(self)
	if player.pos.x + 10 > self.pos.x then
		sfx(1, 3)
	else
		sfx(-2, 3)
	end
	local z, height =
		self._zone, self.size.y
	local xoff = self.age*3%16/8-1
	z:add(sparkle(
		self.pos + vec(xoff, height),
		vec(rndr(-0.125, 0.125), -0.0625),
		15, 0, {7, 7}))
	self.xoff_timer -= 1
	if self.xoff_timer <= 0 then
		self.xoff = xoff
		self.xoff_timer = 2 + rndi0(5)
	end
	local p = self.pos + vec(
		self.xoff, 0)
	z:add(particle(
		p, vec(0, 0.125),
		height * 8, 7, 101))
	if rnd() < 0.25 then
		-- add a fast one too; it'll
		-- drip off the edge and look
		-- incredibly cool
		z:add(particle(
			p:clone(), vec(0, 0.1875),
			height * 8, 7, 101))
	end
end
function waterfall:draw()
	local x, y = (self.pos * 8):unpack()
	rectfill(x - 8, y, x + 7, y + self.size.y * 8 - 1, 12)
	line(x - 8, y, x + 7, y, 7)
end


local lever = actor:extend{
	size = vec(2, 1),
	z = 99,
	motion = 0,
}
function lever:init(pos, t)
	actor.init(self, pos)
	self.progress =
		t == 22 and 1 or 0
end
function lever:onpap()
	if self.motion == 0 then
		swap_blocks(
			{[23]=60, [60]=23},
			{11, 6})
		swap_blocks({[20]=22, [22]=20})
		self._zone:broadcast'_lever_toggle'
	end
end
function lever:_lever_toggle()
	self.motion = 0.25 - self.progress / 2
end
function lever:update()
	actor.update(self)
	self.progress += self.motion
	if self.progress == self.progress\1 then
		self.motion = 0
	end
end
function lever:draw()
	local t1, t2 = 22, 22
	if self.progress >= 0.75 then
		t2 = 20
	elseif self.progress >= 0.5 then
		t2 = 21
	elseif self.progress >= 0.25 then
		t1 = 21
	else
		t1 = 20
	end
	self:drawtile(t1)
	spr8(t2, self.pos.x+1, self.pos.y, true)
end

local glass = mobactor:extend{
	size = vec(1),
	geom_only = true,
	z = 20,
	state = 0,
}
function glass:init(...)
	mobactor.init(self, ...)
	self.color = rnd{
		{12,13}, {10,9}, {9,8}, {3,11}
	}
end
function glass:onpap(s)
	if self.state == 0 then
		self.state = 1
		g_broke_glasses += 1
		self:erase()
		self.vel = vec(
			s*rnd(0.5), -0.5)
	end
end
function glass:update()
	mobactor.update(self)
	if self.state == 1 then
		self.vel.y += gravity
		local d, bx, by = self:slide(self.vel)
		if bx or by then
			sfx(14)
			self.state = 2
			schedule(2, function()
				self:destroy()
			end)
			for i = 0, 0.5, 0.125 do
				self._zone:add(particle(
					self.pos + vec(0.5, 1),
					vec(cos(i), sin(i)) * 0.125,
					6, 6))
			end
		else
			self:moveby(d)
		end
	end
end
function glass:draw()
	pal(12, self.color[1])
	pal(13, self.color[2])
	self:drawtile(
		self.state == 2 and 37 or 36)
	resetpal()
end
-->8
-- core game stuff

tile_actors = {
	[8]=twig,
	[10]=nyapoion,
	[20]=lever,
	[22]=lever,
	[36]=glass,
	[38]=star,
	[40]=purrl,
	[42]=cheezball,
	[67]=door,
	[115]=vent,
	[129]=waterfall,
}
for t in pairs(anise.abilities) do
	tile_actors[t] = powerup
end

local _anise, _purrl, _twig,
	_nyapoion, _cheezball =
	{mood=false, speaker=1, sfx0=0},
	{mood=false, speaker=40, sfx0=1},
	{mood=false, speaker=8, sfx0=3},
	{mood=false, speaker=10, sfx0=3},
	{mood=false, speaker=42, sfx0=2}
local _happy, _sweat, _angry =
	{mood=12}, {mood=6}, {mood=14}
speeches = {
	intro = {
		_anise, _happy,
		"wow!! ★★★★★\nwhat a star anise day!!\nevery star's in the sky.",
		"maybe today i'll hang out\nwith my best bff friend,\nbranch commander twig!",
		_anise,
		"i'll just go to the place\nwhere he is, which is...",
		".........................\n............wait.........",
		_sweat,
		"oh no wheres twig!!",
		"i haven't seen him in ten\na million years!!\nthat's almost forever!!",
		_happy,
		"i better go find him!! ★\nstar anise quest time!!",
	},
	jump = {
		_anise, _happy,
		"yeah!!  i was wondering\nwhere i left this!! ★",
	},
	aowr1 = {
		_anise, _happy,
		"wow!!  that was my best\naowr yet!! ★",
	},
	aowr2 = {
		_anise, _happy,
		"aowr, aowr aowr aowr.\naowr, aowr aowr aowr. ★",
	},
	aowr3 = {
		_anise, _happy,
		"hello??  twig???  it's me\nstar anise!! ★★★",
	},
	aowr4 = {
		_anise, _happy,
		"every day is better with\na little aowr!! ★",
	},
	no_pizza = {
		_anise, _sweat,
		"i'm not hungry!!",
		_angry,
		"also, i want kibble!!",
	},
	no_key = {
		_anise, _happy,
		"wow!!\nthis is so shiny!! ★",
	},
	cheez_intro = {
		_anise, _happy,
		"wow!  it's cheezball!!\nhey cheezball!!!",
		_cheezball,
		"...",
		_anise, _happy,
		"cheezball!!!!!!!!!  hey!!\nmove your blocks hey!!!",
		_cheezball,
		"...",
		_anise,
		"i gotta get his attention\nsomehow!! ★",
	},
	cheez_plastic = {
		_cheezball, _happy,
		"oh!!!!  i wana treshur ●",
		_anise,
		"i'll give you this crinkle\nif you move your blocks!",
		_cheezball,
		"o k ●●●",
	},
	cheez_plastic2 = {
		_anise, _happy,
		"thanks cheezball!!\ngreat job!!",
		_cheezball,
		"yea i'ma godd job ! ●",
	},
	cheez_aowr = {
		_cheezball,
		"!!  me 2 met o ●",
		"auuwowuuwowuoowouwoo",
		_anise, _happy,
		"wow cheezball!!  what a\ngreat awoo!!",
	},
	cheez_pap = {
		_cheezball, _happy,
		"yeha less fite!!!  ill go\nfisrt im bite",
		_anise, _sweat,
		"not right now, cheezball!!\ni've gotta find twig!!\nmaybe later ok!",
		_cheezball,
		"auuowowuuo..... ●",
	},
	nyapo_intro = {
		_nyapoion, _angry,
		"who goes there!! ∧",
		_nyapoion,
		"ah, star anise.  just the\nluneko i wanted to see.",
		_anise, _happy,
		"wow really??  what a\ncoincidence!!  i wanted\nto see me too! ★",
		_nyapoion,
		"well, no, not really.\nbut you'll do. ∧",
		"i've been doing some\ninterdimensional travel,\nand have worked up\na sagely appetite.\nfeed me at once!",
		_anise, _happy,
		"why not get something at\nyour friendly local\nstar anise shop?? ★",
		_nyapoion,
		"they do sell the finest\nfloor kibble.  alas, the\nshop seems to be closed.",
		_anise, _sweat,
		"oh!!  that's probably\nbecause of how i'm not\nat it because i'm on a\ncool quest to find twig.",
		_nyapoion,
		"the branch commander?\ni have not seen him in\nquite some time.",
		"but i'll gladly remove\nmy blocks in exchange\nfor a hearty meal. ∧",
		_anise, _happy,
		"i'll do my best!!  star\nanise sidequest time!!",
		_nyapoion,
		"take this key.  it may\nhelp you in your quest.",
	},
	nyapo_hungry = {
		_nyapoion,
		"that's not a hearty meal\nat all!  that's an aowr! ∧",
		_anise,
		"i know!!  i got it just\nfor you, nyapo-ion!!",
	},
	nyapo_pizza = {
		_nyapoion, _happy,
		"ah!!  pizza! ∧∧∧\nthe nectar of the gods!!",
		_anise,
		"normally star anise shop\ndoesn't deliver, but i'm\non a quest!! no charge!",
		_nyapoion, _happy,
		"bless you, star anise.\ni will remove my blocks\nas promised.  good luck!",
	},
	nyapo_pap = {
		_nyapoion, _angry,
		"please do not pap me\nwhile i am contemplating\nthe mysteries of the\ncosmos, star anise! ∧",
	},
	nyapo_general = {
		_nyapoion,
		"i'm satisfied for now.\nplease leave me to my\nastral travel. ∧∧",
	},
	purrl_soot = {
		_purrl, _angry,
		"go away, soot anise!!!",
	},
	purrl_intro = {
		_purrl, _angry,
		"augh!!  get away from me,\nstar anise!!\nwhy are you so gross!!\nbe lovely like me!! ♥",
		_anise,
		"sorry purrl!!  i ran\nthrough a thing!!",
		"hey can you move your\nblocks so i can do a\ncool jump thanks!! ★",
		_purrl, _angry,
		"no go away!!  you'll get\ngross on me!!!!",
		_anise, _sweat,
		"but i gotta find twig\nit's my quest!!!",
		_purrl, _angry,
		"i don't care!!!!",
	},
	purrl_clean = {
		_purrl, _angry,
		"what do you want!!",
		_anise, _happy,
		"i'm all clean now can\nyou move your blocks!!",
		_purrl,
		"only if you ask nicely. ♥",
		_anise,
		"please purrl please!!\nplease please!! ★★★",
		_purrl,
		"mmmmnmnmnm, i dunno.",
		"ask lovelily also. ♥",
		_anise, _happy,
		"pretty please purrl!! ★\n★ ★ ★ ★ ★ ★ ★ ★",
		_purrl,
		"it would be unlovely of\nme to refuse now... ♥",
		"so ok star anise but you\nbetter not pest me!!",
	},
	purrl_clean2 = {
		_anise, _happy,
		"yeah thanks purrl you're\nthe best!! ★★★",
		"that's why you're my best\nbff forever!! ★",
		_purrl, _angry,
		"no i'm not!!\ni'm your emeny!!!",
	},
	purrl_pap = {
		_purrl, _angry,
		"star anise!!\ndon't pest me!!!!!!!",
		_anise, _sweat,
		"aw!! ★",
	},
	purrl_aowr = {
		_purrl, _angry,
		"don't aowr at me,\nstar anise!!",
		"i will accept lovely\nmewos only!!",
	},
	twig = {
		_twig,
		"hello, star anise. ˇ",
		"i hear you have been\nsearching for me.",
		_anise, _happy,
		"twig!!!  at last!!  ★★\nyeah i've been lookin\nall day!!  i did a whole\nquest and everything!!\nlet's party yeah!! ★",
		_twig,
		"i cannot party with you,\nstar anise. ˇ",
		"i came to say goodbye.",
		_anise, _sweat,
		"what!!  but i like hellos\na million better!! ★\nwhere are you going??",
		_twig,
		"the time has come for me\nto explore the universe.\ni must find the other\nlunekos. ˇˇ",
		_anise, _happy,
		"wow that sounds like a\ngreat time!!  i'll come\ntoo!!  star anise shop\ncan go on your ship!! ★",
		_twig,
		"you cannot come with me.\nnot yet.  you are needed\nhere, to watch over the\nothers in my stead. ˇ",
		_anise, _sweat,
		"but i wanna hang out!!\nwhy can't i come!! ★\nyou're my best bff...",
		_twig,
		"it is the way of things.",
		_anise, _angry,
		"that's not fair!!!",
		"...",
		_anise,
		"i don't get it at all.",
		"when can i see you again?",
		_twig,
		"not soon.  but one day.",
		_anise,
		"...",
		"i'll miss you.",
		_twig,
		"i'll miss you too,\nstar anise.",
		"...",
		"i don't have to go\nquite yet.",
		"so for this moment...",
		"will you watch the stars\nwith me, old friend? ˇ",
		_anise, _happy,
		"yeah!!!!! ★★★★★★",
		_anise,
		"anytime, twig.",
	},
}

local _tasks = {}
function schedule(tics, callback)
	add(_tasks, {
		ttl = tics,
		callback = callback,
	})
end

local _overlays = {}
function push(...)
	for ov in all{...} do
		if type(ov) == 'function' then
			local coro = cowrap(ov)
			ov = {
				update = function()
					if coro() then
						pop()
					end
				end,
				draw = nop,
			}
		end
		add(_overlays, ov)
	end
end
function pop()
	_overlays[#_overlays] = nil
end

local screenpal = {
	[0]=129,0,130,3,
	4,131,6,7,
	137,9,10,139,
	12,13,141,15,
}
function _init()
	pal(screenpal, 1)
	-- preserve palette
	poke(0x5f2e, 1)
	-- no btnp repeat
	poke(0x5f5c, 255)

	for x, y, t in fullmapbox:itermap() do
		if t == 1 then
			player = anise(vec(x, y))
			world:configure(
				zone(x\16+y\16*8))
		elseif t == 36 then
			total_glasses += 1
		elseif t == 38 then
			total_stars += 1
		end
	end

	_scene = titlescene()
end

function _update()
	clock += 1
	clock %= 20160
	for handle, task in pairs(_tasks) do
		task.ttl -= 1
		if task.ttl <= 0 then
			task.callback()
			_tasks[handle] = nil
		end
	end

	if #_overlays > 0 then
		_overlays[#_overlays]:update()
		return
	end

	_scene:update()
end

function _draw()
	_scene:draw()

	if #_overlays > 0 then
		_overlays[#_overlays]:draw()
	end
end

titlescene = scene:extend{}
function titlescene:init()
	sfx(47)
	self.draw = cowrap(self._draw)
end
function titlescene:_draw()
	for p = -3.75, 3.75, 0.5 do
		local i = 4 - flr(abs(p))
		local bg, fg =
			({0, 0, 5, 3})[i],
			({5, 3, 11, 10})[i]
		cls(bg)
		circ(110, 20, p * 4 + 12, fg)
		local angle = -0.3125 - p/24
		local dx, dy = 256*cos(angle),
			256*sin(angle)
		line(110-dx, 20-dy, 110+dx, 20+dy, fg)
		line(110-dy, 20+dx, 110+dy, 20-dx, fg)
		yield()
	end

	cls()
	yield()
	px9_decomp(0, 0, 0x3ec0)
	yield()

	for i = 1, 6 do
		local step = 0x80 \ (i\4+1)
		memcpy(0x6000+step, 0x6000, 0x1000)
		yield()
		memcpy(0x6000, 0x6000+step, 0x1080)
		yield()
	end

	yieldn(4)

	local subtitle = "    … oh no wheres twig?? …   "
	for db = 0, 64, 4 do
		prints(subtitle, 0, 76, 7, 1)
		for y = 66, 72 do
			local dst, src =
				0x6000 + y * 64,
				0x6000 + y * 64 + 640
			if y % 2 == 0 then
				dst += 64 - db
			else
				src += 64 - db
			end
			memcpy(dst, src, db)
		end
		rectfill(0, 76, 128, 82, 0)
		yield()
	end

	yieldn(4)

	while 0 do
		prints("press 🅾️ or ❎\n\n   (z or x)", 36, 96,
			clock % 16 < 8 and 9 or 8, 1)
		if btnp(🅾️) or btnp(❎) then
			break
		else
			yield()
		end
	end

	sfx(4, 3)
	local oy, y0, dy = 0, starcam.y
	for p=-1,1,0.03125 do
		-- quad easing
		p = p*(2-abs(p))
		if p < 0 then
			local y = 128-p\-0.0078125
			dy, oy = y - oy, y
			memcpy(0x6000, 0x6000+dy*64,0x2000-dy*64)
			clip(0, 128-y, 128, 128)
		end
		fillscr(0, 0)
		starcam.y = y0 + p - 1
		starfield:draw(starcam)
		camera((world.zone.origin * 8 + starcam * 128):unpack())
		world.zone:draw()
		camera()
		clip()
		yield()
	end

	_scene = world
	push(
		function()
			music(32, 7)
 	end,
 	dialogue'intro')
end

toendscene = obj:extend{
	dy = 0,
}
function toendscene:init()
	self.update = cowrap(self._update)
end
function toendscene:_update()
	local y0 = starcam.y
	for p = 1, -1, -0.015625 do
		-- quad, 0 to -8
		self.dy = 4*sgn(p)*(1-(1-abs(p))^3)-4
		starcam.y = y0 + self.dy
		yield()
	end
	yieldn(30)
	for n = 0, 1, 0.0625 do
		self.starpos = vec(
			16 + 96*n^2, 32 + 48*n^3)
		self.startile = 47 - n*3
		yield()
	end
	for n = 44, 47 do
		self.startile = n
		yieldn(3)
	end
	self.starpos = nil
	yieldn(90)
	_scene = endscene()
end
function toendscene:draw()
	cls()
	starfield:draw()
	camera((world.zone.origin * 8 + vec(0, self.dy * 128)):unpack())
	world.zone:draw()
	camera()
	if self.starpos then
		spr(self.startile, self.starpos:unpack())
	end
end

local _twig_pixel_data = "!o$b'i+N0_1W1b2<3U3c7b<\"<B<D=_?r@^@mB<BbClEVH(HSI1LzQ%QlU!X]Zp\\q_Mbif<h`l,mZqWqtugvPxRyZzR  DbEcF[FsFxG`H\\HxJTJ[LTMTN;NLOMPNQGR1RHT*a3cwu]v_wW  krlklsmfnmofqfrb  RYTZVKX+Y.ZM[![@\\+]A^s`#aobr  TWWKXPZ&ZF[G\\(\\z_!_v"
local _credits = {{
	nick = "forever baby",
	name = "cheezball",
	actor = "cheeseball",
	color = 13,
	class = cheezball,
}, {
	nick = "mysterious sage",
	name = "nyapo-ion",
	actor = "napoleon",
	color = 10,
	class = nyapoion,
}, {
	nick = "loveliest of all",
	name = "purrl",
	actor = "pearl",
	color = 12,
	class = purrl,
}, {
	nick = "we'll never forget you",
	name = "branch commander twig",
	actor = "twigs",
	color = 9,
	class = twig,
}, {
	nick = "our hero",
	name = "star anise",
	actor = "anise",
	color = 11,
	class = anise,
}}
endscene = scene:extend{
	dx = 0,
}
function endscene:init()
	music(40)
	schedule(7188, function() music(0) end)
	self.decor, self.twixels = {}, {}
	self.credits_coro = cowrap(
		self._draw_credits)
	self:_shift_decor()

	c = 1
	for i = 1, #_twig_pixel_data, 2 do
		local n =
			ord(_twig_pixel_data, i) * 90 +
			ord(_twig_pixel_data, i+1)
			- 3003
		if n >= 0 then
			add(self.twixels, {
				x=n%88+16, y=n\88+12,
				c=({13,14,2,5,3})[c],
				t0=rndi0(2000),
			})
		else
			c += 1
		end
	end
end
function endscene:_shift_decor()
	local in_bush
	for i = 0, 15 do
		local t
		if in_bush then
			if rnd() < 0.5 or i == 15 then
				in_bush = false
				t = 122
			else
				t = rnd{120,121}
			end
		elseif i < 15 then
			if rnd() < 0.5 then
				t = rnd{4,5,118,123,119}
			end
			in_bush = t == 119
		end
		self.decor[i], self.decor[i + 16] =
			self.decor[i + 16], t
	end
end
function endscene:update()
	starcam.x += 0.015625
	self.dx += 0.125
	if self.dx > 16 then
		self.dx -= 16
		self:_shift_decor()
	end
end
function endscene:_draw_credits()
	local function draw_credit(p, credit, closing)
		prints("starring", 48, 32, 7, 14)
		local lx, x =
			p * 16 - 14,
			128 - 96*p
		if closing then
			clip(lx*8, 0, 128, 128)
		end
		prints(credit.nick, x, 54, 7)
		prints(credit.name, x, 62, credit.color)
		prints("played by: " .. credit.actor, x, 70, 15)
		clip()
		credit.class:draw_at(vec(lx, 9.5))
		yield()
	end
	yieldn(90)
	for i = 1, 60 do
		draw_credit(0, _credits[1])
	end
	for credit in all(_credits) do
		for i = 0, 4, 0.015625 do
			draw_credit(min(1, i^2), credit)
		end
		for i = 0, 2, 0.015625 do
			draw_credit(1+i^2, credit, true)
		end
	end
	while 0 do
		if not (btn(🅾️) or btn(❎)) then
			prints("thanks for playing! 🐱", 20, 24, 7)
			prints("more lunekos at", 4, 30, 7)
			prints("floraverse.com", 68, 30, 12, 2)
			prints("by eevee", 4, 68, 7)
			prints("eev.ee\n@eevee", 4, 74, 12, 2)
			spr(38, 96, 68)
			prints(
				g_found_stars .. "/" .. total_stars,
				110, 69, 10, 8)
			spr(36, 96, 78)
			prints(
				g_broke_glasses .. "/" .. total_glasses,
				g_broke_glasses < 10 and 110 or 106,
				79, 6, 14)
		end
		yield()
	end
end
function endscene:draw()
	cls()
	starfield:draw()
	for twixel in all(self.twixels) do
		local c = twixel.c
		if (clock - twixel.t0) % 2000 < 4 then
			circ(twixel.x, twixel.y, 1, c)
			twixel.vis = true
			c = 7
		end
		if twixel.vis then
			pset(twixel.x, twixel.y, c)
		end
	end
	anise:draw_at(vec(3, 14), false, clock % 8 < 4)
	local dx = self.dx % 1 * 8
	for x = 0, 128, 8 do
		spr(65, x - dx, 112)
		spr(81, x - dx, 120)
		local t = self.decor[
			x\8 + self.dx\1]
		if t then
			spr(t, x - dx, 104)
		end
	end
	-- text
	prints("star anise chronicles 1.5:\n    oh no wheres twig", 12, 4, 11, 5)
	self:credits_coro()
end