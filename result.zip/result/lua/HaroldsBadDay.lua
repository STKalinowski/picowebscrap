-- harold's bad day
-- by biovoid
-- rob@rmd.com.au
-- inspiration and additional graphics by thefreakar

function shadow_print(s, x, y)
  print(s, x + 1, y, 0)
  print(s, x, y + 1, 0)
  print(s, x + 1, y + 1, 0)
  print(s, x, y, 7)
end

g = {
	grav = 0.2,
  water = -0.3,
  waterfric = .8,
  jumpvel = 2.4,
  runvel = .5,
  runfriction = .8,
  maxvel = 1.5,
  termvel = 3.6,
  drownframes = 155,
  arrowfreq = 60,
  arrowspeed = 3,
  windfreq = 4,
  windspeed = 2,
  windpower = .21,
  wind_c = 7,
  dooropen = false,
  doorclosed = false,
  reset = false,
  fading = false,
  fade_frame = 0,
  fade_lev = 1,
  fireworks_lev = 3,
  prev_lev = 1,
  fade_dir = 0,
  reset_enabled = false,
  resetting = false,
  reset_value = 0,
  reset_released = true,
  muffle_frame = 0,
}

active_player = nil
actors = {}
sprites = {}
players = {}
particles = {}
bg_particles = {}
water_particles = {}
arrows = {}
firetiles = {}
firetiles_by_position = {}
windtiles = {}
fadetiles = {}
fadetiles_by_position = {}
arrowtiles = {}
levels = {}
level = {}

curlevel = 0

corners_erased = false

lives = 0
lives_saved = 0
deaths = 0
resets = 0
final_time_m = 0
final_time_s = 0
start_time = time()

dirs = {
  {x = 0, y = -1},
  {x = 1, y = 0},
  {x = 0, y = 1},
  {x = -1, y = 0},
}
tile_to_dir = {
  [43] = 1,
  [28] = 2,
  [59] = 3,
  [27] = 4
}

fades = {}

--- player ---

function new_player()

  lives -= 1

  local player = {
  	x = level.px,
  	y = level.py,
    oldx = 0,
  	dx = 0,
  	dy = 0,
    sprite = 1,
    runsprite = 0,
    faceleft = false,
    running = false,
  	grounded = false,
    falling = false,
    inwater = false,
    inwind = false,
    onfire = false,
    onsprite = false,
    playeron = false,
    dead = false,
    burnt = false,
    shot = false,
    fell = false,
    respawned = false,
    spawned = true,
    frame = 0,
    fireframe = 0,
    drownframe = 0,
    swimframe = 1,
    blinkframe = 0,
  }

  active_player = player

  add(actors, player)
  add(sprites, player)
  add(players, player)

  function player:update()

    self:start_end_check()

    if self.dead then
      if self.burnt then
        self.sprite = 21
      else
        self.sprite = 20
      end
    else
      self.sprite = 1
    end

    if self.grounded and not self.shot then
      self.dx *= g.runfriction
    end

    if not self.spawned then
      self:handle_input()
    end

    if self.running then
      self.frame += 1
      if self.frame%3 == 0 then
        self.runsprite += 1
        self.runsprite = self.runsprite%4
      end
      self.sprite = self.runsprite + 1
    else
      if self.grounded and not self.inwater and not self.onsprite and abs(self.dx) > 0.2 then
        new_grass_particle(self.x - self.dx*2 + 4, self.y + 8, -self.dx*.5, -abs(self.dx) - rnd(1))
      end
    end

    if self.inwater and not self.shot then
      self.dy += g.water
      self.dy *= g.waterfric
      self.dx *= g.waterfric
      self.drownframe += 1
    elseif self.shot then
      -- no change to velocities
    else
      self.dy += g.grav
    end

    if self.dy < 0 then
      self.grounded = false
    end

  	self.y += self.dy

    if self.y > 120 then
      self.y = 120
      if self.dead then
        self.x = -16
      else
        self.fell = true
        self:die()
        sfx(7)
      end      
    end

    if self.dy > g.termvel then
      self.falling = true
    else
      self.falling = false
    end

    if self.drownframe >= g.drownframes and not self.dead then
      self:die()
    end

    if self.drownframe >= g.drownframes and self.drownframe < g.drownframes + 10 and not self.dead then
      new_bubble_particle(self.x, self.y)
    end

    self:ground_collision()

    self:fire_water_wind_collision()

  	self:ceiling_collision()

    self.x += self.dx

  	self:wall_collision(self.dx)

    if not self.grounded and not self.dead then
      if self.falling then
        self.sprite = 6
      else
        if self.dy > 2 then
          self.sprite = 5
        else
          self.sprite = 91
        end
      end
    end

    if self.inwater and not self.dead then
      self.sprite = 4 + self.swimframe
      if self.drownframe > 60 then
        self.sprite = 7 + self.swimframe
        if self.drownframe < 70 then
          new_bubble_particle(self.x, self.y)
        end
      end
      if self.drownframe > 120 then
        self.sprite = 9 + self.swimframe
        if self.drownframe < 130 then
          new_bubble_particle(self.x, self.y)
        end
      end
    end

    if self.shot then
      if rnd() > .9 then
        new_particle(self.x + 4, self.y + 6, {2, 8, 8, 8}, 100, 0, 0)
      end

      if not self.dead then 
        self.sprite = 16
      end

      if self.dead and self.respawned then
        self.sprite = 19
      end   
    end

    if self.dead and not self.respawned then
      self.frame += 1

      if self.shot then
        if self.frame > 1 then
          self.sprite = 17
        end
        if self.frame > 4 then
          self.sprite = 18
        end
        if self.frame > 7 then
          self.sprite = 19
        end
      end

      if self.frame >= 10 then
        self.respawned = true
        if lives == 0 then
          g.reset = true
        else
          new_player()
          if self.fell then
            del(actors, self)
            del(sprites, self)
          end
        end
      end
    end

    if self.x >= 119 and not self.dead then
      if lives > 0 then
        lives_saved += lives
        sfx(13)
      end
      g.reset_enabled = true
      next_level()
    end
  end

  function player:start_end_check()
    if curlevel == 1 then
      if self.x > 54 and not g.dooropen then
        sfx(5)

        mset(3, 3, 90)
        mset(3, 4, 90)
        mset(3, 5, 90)

        mset(4, 3, 88)
        mset(4, 4, 110)
        mset(4, 5, 126)

        mset(5, 3, 88)
        mset(5, 4, 111)
        mset(5, 5, 127)

        mset(6, 3, 44)
        mset(6, 4, 60)
        mset(6, 5, 60)

        mset(7, 3, 103)
        mset(7, 4, 119)
        mset(7, 5, 119)

        g.dooropen = true
      end
    end

    if curlevel == 32 then
      if self.x > 60 and not g.doorclosed then
        sfx(6)

        mset(115, 51, 87)
        mset(115, 52, 87)
        mset(115, 53, 87)

        mset(116, 51, 105)
        mset(116, 52, 121)
        mset(116, 53, 94)

        mset(117, 51, 105)
        mset(117, 52, 122)
        mset(117, 53, 95)

        mset(118, 51, 102)
        mset(118, 52, 118)
        mset(118, 53, 118)

        mset(119, 51, 63)
        mset(119, 52, 106)
        mset(119, 53, 106)

        g.doorclosed = true
        g.reset_enabled = false
        final_time_m, final_time_s = get_time()
        lives_saved += 1

        music(36)
      end
    end
  end

  function player:handle_input()

    local moving = false

    self.running = false
    self.oldx = self.x

    if not self.dead and not self.shot then
      if btn(0) then
        moving = true

        if not self.inwater then
          self.running = true
        end
  		  self.dx -= g.runvel
        if self.grounded or self.inwater then
          self.dx = max(self.dx, -g.maxvel)
        end
        self.faceleft = true

        if self.grounded and not self.onsprite and not self.inwater and self.dx > .2 then
          new_grass_particle(self.x + self.dx*2 + 4, self.y + 8, self.dx)
        end
      end

      if btn(1) then
        moving = true

        if not self.inwater then
          self.running = true
        end
        self.dx += g.runvel
        if self.grounded or self.inwater then 
          self.dx = min(self.dx, g.maxvel)
        end
        self.faceleft = false

        if self.grounded and not self.onsprite and not self.inwater and self.dx < -.2 then
          new_grass_particle(self.x + self.dx*2 + 4, self.y + 8, self.dx)
        end
      end

      if btn(5) then

        local t1 = level:get_tile(self.x, self.y - 1)
        local t2 = level:get_tile(self.x + 7, self.y - 1)

  	    if not fget(t1, 0) and not fget(t2, 0) then
          if self.grounded and not self.inwater then
            self.grounded = false
            self.dy = -g.jumpvel
            sfx(0)
          end
        end
      end

      if btn(2) and self.inwater then
        moving = true
        self.dy -= g.runvel*.80
      end

      if btn(3) and self.inwater then
        moving = true
        self.dy += g.runvel
      end
    end

    if moving then
      local swimspeed = 4

      if self.drownframe > 60 then
        swimspeed = 3
      end
      if self.drownframe > 120 then
        swimspeed = 2
      end

      self.frame += 1
      if self.frame%swimspeed == 0 then
        self.swimframe = 1 - self.swimframe
      end
    end

    if self.inwind and not self.shot then
      local t1 = level:get_tile(self.x + 4, self.y + 3)
      dir = tile_to_dir[t1]
      if dir then
        local wx = dirs[dir].x
        local wy = dirs[dir].y

        local xmod = 2.5

        if self.dead then
          xmod = .25
        end
      
        self.dx += wx*g.windpower*xmod
        self.dy += wy*g.windpower
        if wy < 0 then
          self.dx *= .9
          self.dy *= .98
        end
        if wy > 0 then
          self.dy *= .96
        end
      end

      self.dx = max(self.dx, -g.maxvel*1.5)
      self.dx = min(self.dx, g.maxvel*1.5)

    else

      self.dx = max(self.dx, -g.maxvel)
      self.dx = min(self.dx, g.maxvel)

    end

  end

  function player:ground_collision()
    local t1 = level:get_tile(self.x, self.y + 8)
    local t2 = level:get_tile(self.x + 7, self.y + 8)
    local sprite
    local olddy = self.dy

  	if self.dy >= 0 then
  		if fget(t1, 0) or fget(t2, 0) then
  			self.y = flr((self.y)/8)*8
  			self.dy = 0

        if self.falling then
          self:die()
        end

        if not self.grounded then
          self.grounded = true
          self.spawned = false
          if olddy > 1 then
            if self.falling then
              sfx(2)
              for i = 0, 20 do
                new_particle(self.x + 4, self.y + 10, {2, 8, 8, 8}, 50, rnd(2) - 1, -rnd(1) - 2)
              end
            else
              sfx(1)
              for i = 0, 6 do
                new_grass_particle(self.x + 4, self.y + 8)
              end
            end
          end
        end
      else
        self.onsprite = false

        for sprite in all(sprites) do
          if self ~= sprite then
            if self.x > sprite.x - 8 and self.x < sprite.x + 8 then
              if self.y < sprite.y then
                if self.y > sprite.y - 8 then
                  self.y = sprite.y - 8
                  self.dy = 0
                  self.onsprite = true
                  if sprite.onfire then
                    self.onfire = true
                  end
                  sprite.playeron = true
                end
              end
            end
          end
        end

        if self.onsprite then
          if not self.grounded then
            self.grounded = true
            if olddy > 1 then
              sfx(2)
              for i = 0, 6 do
                new_particle(self.x + 4, self.y + 12, {2, 8, 8, 8}, 50)
              end
            end
          end
        else
          self.grounded = false
        end
  		end
  	end
  end

  function player:fade_collision()

    local t1 = level:get_tile(self.x, self.y + 8)
    local t2 = level:get_tile(self.x + 7, self.y + 8)

    local tx, ty, fadetile

    if t1 >= 32 and t1 <= 36 then
      tx = flr((self.x)/8)
      ty = flr((self.y + 8)/8)
      fadetile = fadetiles_by_position[ty*16 + tx]
      fadetile.playeron = true
    end

    if t2 >= 32 and t2 <= 36 then
      tx = flr((self.x + 7)/8)
      ty = flr((self.y + 8)/8)
      fadetile = fadetiles_by_position[ty*16 + tx]
      fadetile.playeron = true
    end
  end

  function player:fire_water_wind_collision()
    local t1 = level:get_tile(self.x + 4, self.y + 3)

    self.inwind = false

    if fget(t1, 1) then
      if not self.inwater then
        self.inwater = true
        if self.onfire then
          sfx(12)
          for i = 0, 20 do
            new_steam_particle(self.x + 4, self.y + 4)
          end
        end
        self.drownframe = 0
        if self.dy > 1 then
          if not self.onfire then 
            sfx(3)
          end
          for i = 0, 50 do
            new_water_particle(self.x + 4, self.y + 4)
          end
        end
        self.onfire = false
      end
    elseif fget(t1, 5) then
      self.inwind = true
    else
      if self.inwater then
        self.inwater = false
        self.drownframe = 0
        if self.dy < -1 then
          sfx(4)
          for i = 0, 15 do
            new_water_particle(self.x + 4, self.y + 7)
          end
        end
      end
    end

    if fget(t1, 2) then
      if not self.onfire then
        self.onfire = true
        self.fireframe = 0
      end
    end

    if self.onfire then
      self.fireframe += 1
      local p = 3

      if self.fireframe > 180 then
        p = 2
      end
      if self.fireframe > 220 then
        p = 1
      end

      for i = 0, p do
        new_fire_particle(self.x + rnd(7), self.y + rnd(7))
      end
      if not self.burnt and self.fireframe > 150 then
        self.burnt = true
        self:die()
      end
      if self.fireframe > 260 then
        self.onfire = false
      end
    end
  end

  function player:ceiling_collision()
    local t1 = level:get_tile(self.x, self.y)
    local t2 = level:get_tile(self.x + 7, self.y)

  	if self.dy <= 0 then
  		if fget(t1, 0) or fget(t2, 0) then
  			self.y = flr((self.y + 8)/8)*8
  			self.dy = 0
      else

        for sprite in all(sprites) do
          if self ~= sprite then
            if self.x > sprite.x - 8 and self.x < sprite.x + 8 then
              if self.y > sprite.y then
                if self.y < sprite.y + 8 then
                  self.y = sprite.y + 8
                  self.dy = 0
                  onsprite = true
                end
              end
            end
          end
        end
  		end
  	end
  end

  function player:wall_collision(dir)
    local xoffset = 0
  	if dir > 0 then xoffset = 7 end

  	local t1 = level:get_tile(self.x + xoffset, self.y)
    local t2 = level:get_tile(self.x + xoffset, self.y + 7)

  	if fget(t1, 0) or fget(t2, 0) then
  		self.x = self.oldx
      self.x = flr((self.x + 4)/8)*8
      self.dx = 0

      if self.shot and not self.dead then
        self:die()
      end
  	end

    for sprite in all(sprites) do
      if self ~= sprite then
        if self.y > sprite.y - 8 and self.y < sprite.y + 8 then
          if self.x < sprite.x then
            if self.x > sprite.x - 8 then
              self.x = sprite.x - 8
              self.dx = 0

              if self.shot and not self.dead then
                self:die()
              end
            end
          elseif self.x > sprite.x then
            if self.x < sprite.x + 8 then
              self.x = sprite.x + 8
              self.dx = 0

              if self.shot and not self.dead then
                self:die()
              end
            end
          end
        end
      end
    end
  end

  function player:draw()

     if self.fireframe > 120 and self.fireframe <= 150 then
      pal(4, 2)
      pal(9, 4)
      pal(15, 14)
    end
  
    spr(self.sprite, self.x, self.y, 1, 1, self.faceleft)

    if not self.grounded and not self.falling and not self.dead and not self.inwater and not self.shot then
      pset(self.x - 1, self.y + 4, 0)
      pset(self.x + 8, self.y + 4, 0)
      if self.faceleft then
        line(self.x + 6, self.y + 8, self.x + 7, self.y + 8, 0)
        line(self.x - 1, self.y + 6, self.x - 1, self.y + 7, 0) 
      else
        line(self.x, self.y + 8, self.x + 1, self.y + 8, 0) 
        line(self.x + 8, self.y + 6, self.x + 8, self.y + 7, 0)
      end
    end

    if not self.dead and not self.falling then
      self.blinkframe += 1
      if self.blinkframe > 20 then
        if rnd() > .98 then
          self.blinkframe = 0
          local xoffset = 1
          if self.faceleft then
            xoffset = 0
          end
          pset(self.x + 2 + xoffset, self.y + 2, 14)
          pset(self.x + 4 + xoffset, self.y + 2, 14)
        end
      end
    end

    if self.fireframe > 120 and self.fireframe <= 150 then
      pal(4, 4)
      pal(9, 9)
      pal(15, 15)
    end

  end

  function player:draw_shadow()
    if self.grounded and not self.shot and not self.dead and not self.inwater and g.dooropen then 
      line(flr(self.x) + 1.5, self.y + 8, flr(self.x) + 6.5, self.y + 8, 0)
    end

    if self.dead and not self.shot then
      if self.faceleft then
        line(self.x + 8, self.y + 1, self.x + 8, self.y + 7, 0)
      else
        line(self.x - 1, self.y + 1, self.x - 1, self.y + 7, 0)
      end
    end

    if self.shot and self.dead then
      line(self.x + 1, self.y + 8, self.x + 6, self.y + 8, 0)
    end
  end

  function player:die()
    deaths += 1
    self.frame = 0
    self.dead = true
  end

  function player:shoot(d)
    self.grounded = false
    self.running = false
    self.inwater = false
    self.shot = true
    self.y = flr((self.y + 2)/8)*8
    self.dx = g.arrowspeed*d
    self.dy = 0
    if d > 0 then
      self.faceleft = true
    else
      self.faceleft = false
    end

    for i = 1, 20 do
      new_particle(self.x + 3 - d*5, self.y + 6, {2, 8, 8, 8}, 50, rnd(2)-1, rnd(3) - 2)
    end

  end
end

--- particle ---

function new_grass_particle(x, y, dx, dy) 
  if g.dooropen and not g.doorclosed then
    new_particle(x, y, {3, 4, 11}, 50, dx, dy)
  end
end

function new_water_particle(x, y)
  new_particle(x, y, {1, 7, 12, 13}, 20)
end

function new_fire_particle(x, y)
  new_particle(x, y, {10, 9, 8, 13}, 14, rnd(1) - .5, 0, -.1)
end

function new_particle(x, y, colors, life, dx, dy, grav, bg, water)
  if life then
    life = life/2 + rnd(life/2)
  else
    life = 7 + rnd(7)
  end

  local particle = {
    x = x,
    y = y,
    c = colors[flr(rnd(#colors))+1],
    totalframe = life,
    dx = dx or rnd(2) - 1,
    dy = dy or -rnd(1) - 1,
    grav = grav or g.grav,
    bg = bg or false,
    frame = 0,
    water = water or false,
  }

  if bg then 
    add(bg_particles, particle)
  else
    add(particles, particle)
  end

  function particle:update()
    self.dy += self.grav
    self.x += self.dx
    self.y += self.dy
    self.frame += 1
    if self.frame >= self.totalframe then
      self:die()
    end

    if not self.bg then
      local t = level:get_tile(self.x, self.y)
      if fget(t, 0) then
        self:die()
      end
      if fget(t, 1) and self.dy > 0 and not self.water then 
        self:die()
      end
    end
  end

  function particle:draw()
    pset(self.x, self.y, self.c)
  end

  function particle:die()
    del(particles, self)
    del(bg_particles, self)
  end
end

--- fireworks ---

function new_fireworks(x, y)

  local r = rnd()
  local colors

  if r < .33 then 
    colors = {10, 9, 8}
  elseif r < .67 then
    colors = {11, 3}
  else
    colors = {12, 13, 1}
  end

  for i = 0, 300 do
    local a = rnd()
    local v = rnd()
    local vx = sin(a)*v
    local vy = cos(a)*v - 1
    new_particle(x, y, colors, 50, vx, vy, 0.05, true)
  end

  sfx(11, -1, rnd(3))
end

--- bubble particle ---

function new_bubble_particle(x, y)
  local xoffset = 1
  if active_player.faceleft then
    xoffset = 0
  end
  local colors = {7, 12, 13}

  sfx(10, 3)

  local particle = {
    x = x + 3 + xoffset,
    y = y + 4,
    c = colors[flr(rnd(#colors))+1],
    dy = -rnd(.2),
    grav = -.1,
  }

  function particle:update()
    self.dy += self.grav
    self.x += rnd(1.5)-.75
    self.y += self.dy
    
    local t = level:get_tile(self.x, self.y)
  	if not fget(t, 1) then
      self:die()
    end
  end

  function particle:draw()
    pset(self.x, self.y, self.c)
  end

  function particle:die()
    del(water_particles, self)
  end

  add(water_particles, particle)
end

--- steam particle ---

function new_steam_particle(x, y)

  local colors = {6, 7}

  local particle = {
    x = x + rnd(6),
    y = y,
    c = colors[flr(rnd(#colors))+1],
    dy = rnd(1) - 1,
    grav = -.02,
  }

  function particle:update()
    self.dy += self.grav
    self.x += rnd(1.5)-.75
    self.y += self.dy
    
    local t = level:get_tile(self.x, self.y)
  	if fget(t, 0) then
      self:die()
    end
  end

  function particle:draw()
    pset(self.x, self.y, self.c)
  end

  function particle:die()
    del(particles, self)
  end

  add(particles, particle)
end

--- animtile ---

function new_animtile(x, y, speed, tiles)
  local animtile = {
    x = x,
    y = y,
    speed = speed,
    tiles = tiles,
    frame = 0,
    tile = (x*2)%#tiles,
    dead = false,
  }

  add(actors, animtile)

  function animtile:update()
    self.frame += 1

    if self.frame%self.speed == 0 then
      self.tile += 1
      self.tile = self.tile%#self.tiles
    end
  end

  function animtile:draw()
    if self.dead then
      mset(self.x, self.y, 64)
    else
      mset(self.x, self.y, self.tiles[self.tile + 1])
    end
  end

  function animtile:die()
    del(actors, self)
  end

  return animtile
end

--- firetile ---

function new_firetile(x, y)
  local firetile = new_animtile(x, y, 2, {74, 75, 76, 77, 78, 79})
  
  add(firetiles, firetile)
  firetiles_by_position[firetile.y*16*8 + firetile.x] = firetile

  function firetile:extinguish()
    self.dead = true
  end

  function firetile:die()
    mset(self.x, self.y, self.tiles[1])
    del(actors, self)
    del(firetiles, self)
  end
end

--- arrowtile ---

function new_arrowtile(mapx, mapy, scrx, scry, faceleft)
  local arrowtile = {
    mapx = mapx,
    mapy = mapy,
    scrx = scrx,
    scry = scry,
    faceleft = faceleft,
    frame = 0,
  }

  add(actors, arrowtile)
  add(arrowtiles, arrowtile)

  function arrowtile:update()
    self.frame += 1
    if self.frame >= g.arrowfreq then
      self.frame = 0
      local dx = g.arrowspeed
      if self.faceleft then
        dx = -dx
      end
      new_arrow(self.scrx, self.scry, dx, self.faceleft)
    end
  end

  function arrowtile:draw()

  end

  function arrowtile:die()
    del(actors, self)
    del(arrowtiles, self)
  end

end

--- arrow ---

function new_arrow(x, y, dx, faceleft)
  local arrow = {
    x = x,
    y = y,
    dx = dx,
    faceleft = faceleft,
  }

  add(actors, arrow)
  add(arrows, arrow)
  sfx(8, 3)

  function arrow:update()
    self.x += self.dx

    local xoffset = 1
  	if self.dx > 0 then xoffset = 6 end

  	local t = level:get_tile(self.x + xoffset, self.y)

  	if fget(t, 0) then
      self:shatter()
    end

    for sprite in all(sprites) do
      if self.y + 6 > sprite.y and self.y + 6 < sprite.y + 8 then
        if self.dx < 0 then
          if self.x + 1 > sprite.x and self.x + 1 < sprite.x + 8 then
            if sprite == active_player then
              self:die()
              active_player:shoot(-1)
            else
              self:shatter(true)
            end
          end
        else
          if self.x + 6 > sprite.x and self.x + 6 < sprite.x + 8 then
            if sprite == active_player then
              self:die()
              active_player:shoot(1)
            else
              self:shatter(true)
            end
          end
        end
      end
    end

    if self.x < -8 or self.x > 128 then
      self:die()
    end
  end

  function arrow:draw()
    spr(29, self.x, self.y, 1, 1, self.faceleft)
  end

  function arrow:shatter(blood)
    if blood then
      local offset = 1
      if self.dx > 0 then
        offset = -1
      end
      for i = 1, 10 do
        new_particle(self.x + 3 - offset*5, self.y + 6, {2, 8, 8, 8}, 50, rnd(2)*offset, rnd(3) - 2)
      end
    else
      local t = level:get_tile(self.x - self.dx*4, self.y)
      local grav = g.grav
      local water = false
      if fget(t, 1) then 
        grav = -.02
        water = true
      end
      for i = 1, 6 do
        local yv = rnd(2) - 1
        if fget(t, 1) then 
          yv = rnd(.5) - .25
        end
        new_particle(self.x + i, self.y + 5, {6, 7, 7, 7}, 20, -rnd()*self.dx*.2, yv, grav, false, water)
      end
    end

    sfx(9, 3)
    self:die()
  end

  function arrow:die()
    del(actors, self)
    del(arrows, self)
  end
end

--- windtile ---

function new_windtile(mapx, mapy, scrx, scry, minx, miny, dir)
  local windtile = {
    mapx = mapx,
    mapy = mapy,
    scrx = scrx,
    scry = scry,
    minx = minx,
    miny = miny,
    dir = dir,
    tiles = {43, 28, 59, 27},
    frame = 0,
    dead = false,
  }

  add(actors, windtile)
  add(windtiles, windtile)

  function windtile:update()
    if not self.dead then
      self:set_tiles(true)
      self:set_tiles()
      self:make_particles()
    end
  end
  
  function windtile:set_tiles(clear)
    local dx = dirs[self.dir].x
    local dy = dirs[self.dir].y

    local mx = self.mapx
    local my = self.mapy
    local sx = self.scrx + 4
    local sy = self.scry + 4 - dy*3
    local t, f
    local continue = true

    while(continue) do
      t = mget(mx, my)
      if clear then
        mset(mx, my, 64)
      else
        if t == 64 or (t >= 74 and t <= 79) then
          
          if t >= 74 and t <= 79 then
            firetile = firetiles_by_position[my*16*8 + mx]
            if firetile then
              firetile:extinguish()
            end
          end

          mset(mx, my, self.tiles[self.dir])
        end
      end

      mx += dx
      my += dy
      sx += dx*8
      sy += dy*8
      if mx < self.minx or my < self.miny or mx > self.minx + 16 or my > self.miny + 15 then
        continue = false
        break
      end
      
      t = mget(mx, my)

      if clear then
        if not fget(t, 5) and t != 64 then
          continue = false
          break
        end
      else
        if t != 64 and not (t >= 74 and t <= 79) then
         continue = false
         break
        end
      end

      if not clear then
        for sprite in all(sprites) do
          if sx - dx*8 > sprite.x and sx - dx*8 < sprite.x + 8 then
            if sy - dy*8 > sprite.y and sy - dy*8 < sprite.y + 8 then  
              continue = false
            end
          end
        end
      end
    end
  end

  function windtile:die()
    self.dead = true
    del(actors, self)
    del(windtiles, self)
    self:set_tiles(true)
    mset(self.mapx, self.mapy, self.tiles[self.dir])
  end

  function windtile:make_particles()
    self.frame += 1
    if self.frame >= g.windfreq then
      self.frame = 0
      local dx = dirs[self.dir].x
      local dy = dirs[self.dir].y
      local x = self.scrx + rnd(8) - dx * 4
      local y = self.scry + rnd(8) - dy * 4
      x = min(max(x, self.scrx), self.scrx + 8)
      y = min(max(y, self.scry), self.scry + 8)
      new_windparticle(x, y, dx, dy)
    end
  end

  function windtile:draw()

  end
end

--- wind particle ---

function new_windparticle(x, y, dx, dy)
  local windparticle = {
    x = x,
    y = y,
    ox = x, 
    oy = y,
    dx = dx,
    dy = dy,
  }

  add(actors, windparticle)

  function windparticle:update()
    self.x += self.dx*g.windspeed
    self.y += self.dy*g.windspeed

  	local t = level:get_tile(self.x, self.y)

    for sprite in all(sprites) do
      if self.x > sprite.x and self.x < sprite.x + 8 then
        if self.y > sprite.y and self.y < sprite.y + 8 then
          self:die()
        end
      end
    end

  	if fget(t, 0) or t == 58 then
      self:die()
    end

    if self.x < -8 or self.x > 128 or self.y < -8 or self.y > 128 then
      self:die()
    end
  end

  function windparticle:draw()
    mod = sin((self.x + self.y)*.03)
    line(self.x + mod, self.y + mod, self.ox, self.oy, g.wind_c)
    self.ox = self.x + mod
    self.oy = self.y + mod
  end

  function windparticle:die()
    del(actors, self)
  end
end

--- fadetile ---

function new_fadetile(mapx, mapy)
  local fadetile = {
    mapx = mapx,
    mapy = mapy,
    sprite = 32,
    health = 5,
    playeron = false,
  }

  add(actors, fadetile)
  add(fadetiles, fadetile)
  fadetiles_by_position[fadetile.mapy*16 + fadetile.mapx] = fadetile

  function fadetile:update()
    if self.playeron then
      self.health -= 1

      if self.health <= 0 then
        self.health = 5
        self.sprite += 1
        if self.sprite > 36 then
          self.sprite = 64
        end
      end
    end
  end

  function fadetile:draw()
    mset(self.mapx + level.x, self.mapy + level.y, self.sprite)
  end

  function fadetile:die()
    mset(self.mapx + level.x, self.mapy + level.y, 32)
    del(actors, self)
    del(fadetiles, self)
    del(fadetiles_by_position, self)
  end
end

--- level ---

function new_level(name, x, y, lives, px, py)
  local level = {
    name = name,
    x = x,
    y = y,
    lives = lives,
    px = px,
    py = py,
  }

  add(levels, level)

  function level:init()

    actors = {}
    sprites = {}
    players = {}
    firetiles = {}
    firetiles_by_position = {}
    windtiles = {}
    fadetiles = {}
    fadetiles_by_position = {}
    new_player()

    local x, y

    for y = 0, 14 do
      for x = 0, 15 do
        local t = mget(self.x + x, self.y + y)
        if t >= 66 and t <= 73 then
          new_animtile(self.x + x, self.y + y, 2, {66, 67, 68, 69, 70, 71, 72, 73})
        end
        if fget(t, 2) then
          new_firetile(self.x + x, self.y + y)
        end
        if fget(t, 3) then
          local faceleft = false
          if t == 12 or t == 30 or t == 46 then
            faceleft = true
          end
          new_arrowtile(self.x + x, self.y + y, x*8, y*8, faceleft)
        end
        if fget(t, 5) then
          local dir = tile_to_dir[t]
          new_windtile(self.x + x, self.y + y, x*8, y*8, self.x, self.y, dir)
        end
        if t == 32 then
          new_fadetile(x, y)
        end
      end
    end
  end

  function level:draw(occlude)
    if occlude then
      map(self.x, self.y, 0, 0, 16, 15, 0x80)
    else
      map(self.x, self.y, 0, 0, 16, 15)
    end
  end

  function level:get_tile(x, y)
    return mget(x/8 + self.x, y/8 + self.y)
  end
end

function reset_sky()
  clouds = {}

  for i = 0, 3 do
    local s = flr(rnd(10))
    c = {
      frame = 0,
      size = s + 5,
      speed = 40-s*2,
      x = rnd(128),
      y = rnd(96),
    }

    add(clouds, c)
  end
end

function update_sky()
  for cloud in all(clouds) do
    cloud.frame += 1

    if cloud.frame%cloud.speed == 0 then
      cloud.x -= 1

      if cloud.x + cloud.size*2 < -20 then
        cloud.x = 128 + cloud.size 
        cloud.y = rnd(96)
      end
    end
  end
end

function draw_sky()
  local celestial_y = 16
  local sky_c = 12
  local cloud_c = 6
  local cy = {18, 20, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96}

  if curlevel >= 30 then
    sky_c = 0
    -- draw stars
  elseif curlevel >= 28 then
    g.wind_c = 13
    sky_c = 1
    cloud_c = 5
    celestial_y = 128
  elseif curlevel >= 18 then
    celestial_y = cy[curlevel - 17]
  end

  if curlevel < 30 then
    rectfill(0, 0, 128, 128, sky_c)
  end

  if curlevel < 30 then
    circfill(24, celestial_y, 10, 10)
    for cloud in all(clouds) do
      circfill(cloud.x, cloud.y, cloud.size, cloud_c)
      circfill(cloud.x + cloud.size*.7, cloud.y - cloud.size*.7, cloud.size*.5, cloud_c)
      circfill(cloud.x + cloud.size*1.2, cloud.y + cloud.size*.2, cloud.size*.8, cloud_c)
    end
  else
    circfill(24, celestial_y, 12, 6)
    circfill(24, celestial_y, 11, 7)
  end
end

--- main routines ---

function _init()
  music(0, 0, 2)

  create_fade_palette()
  erase_wind_arrows()

  new_level("harold's bad day", 0, 0, 1, 36, 40)
  new_level("don't fall", 16, 0, 1, 16, -8)
  new_level("come up for air", 32, 0, 1, 16, -8)
  new_level("i'm on fire", 48, 0, 1, 16, -8)
  new_level("arrows", 64, 0, 1, 16, -8)
  new_level("fall on me", 80, 0, 3, 8, -8)
  new_level("let me drown", 96, 0, 3, 8, -8)
  new_level("jump into the fire", 112, 0, 3, 16, -8)
  new_level("arrow through me", 0, 16, 6, 16, -8)
  new_level("firestarter", 16, 16, 6, 16, -8)
  new_level("psychotic precision", 32, 16, 2, 8, -8)
  new_level("bridge over trouble", 48, 16, 8, 8, -8)
  new_level("stairway to heaven", 64, 16, 7, 8, -8)
  new_level("something in the air", 80, 16, 1, 8,  -8)
  new_level("shield wall", 96, 16, 10, 8, -8)
  new_level("against the wind", 112, 16, 2, 8, -8)
  new_level("sky pilot", 0, 32, 2, 16, -8)
  new_level("windshield", 16, 32, 4, 8, -8)
  new_level("blowin' in the wind", 32, 32, 2, 8, -8)
  new_level("close the window", 48, 32, 4, 8, -8)
  new_level("wind beneath my wings", 64, 32, 4, 8, -8)
  new_level("the tempest", 80, 32, 1, 8, -8)
  new_level("jump", 96, 32, 1, 8, 0)
  new_level("don't stop believing", 112, 32, 1, 8, -8)
  new_level("right on time", 0, 48, 2, 16, -8)
  new_level("leap of faith", 16, 48, 2, 8, -8)
  new_level("put out the fire", 32, 48, 1, 8, -8)
  new_level("earth, wind and fire", 48, 48, 1, 8, -8)
  new_level("ride on time", 64, 48, 2, 16, -8)
  new_level("so close", 80, 48, 1, 8, -8)
  new_level("running the gauntlet", 96, 48, 8, 8, -8)
  new_level("home sweet home", 112, 48, 1, 8, -8)

  next_level()
end

function create_fade_palette()
  local c, l, x, y
  for c = 0, 15 do
    fades[c + 1] = {}
    for l = 0, 3 do
      x = 88 + l + flr(c/8)*4
      y = c%8
      fades[c + 1][l + 1] = sget(x, y)
    end
  end
end

function erase_wind_arrows()
  clear_tile(88, 8, 23)
  clear_tile(96, 8, 7)
  clear_tile(80, 24, 7)
end

function clear_tile(xp, yp, h)
  for y = yp, yp + h do
    for x = xp, xp + 7 do
      sset(x, y, 12)
    end
  end
end

function next_level()
  curlevel += 1
  init_level()

  if curlevel == 32 then
    g.reset_enabled = false
  end

  if curlevel >= 28 and not corners_erased then
    sset(0, 40, 1)
    sset(23, 40, 0)
    sset(23, 63, 0)
    sset(112, 12, 0)
    sset(114, 13, 0)
    sset(112, 14, 0)
    sset(125, 13, 0)
    sset(127, 14, 0)

    corners_erased = true
  end
end

function reset_level()
  if g.fading == false then
    g.fading = true
    g.fade_dir = 1
  end
end

function init_level()
  for windtile in all(windtiles) do
    windtile:die()
  end

  for firetile in all(firetiles) do
    firetile:die()
  end

  for fadetile in all(fadetiles) do
    fadetile:die()
  end

  for arrowtile in all(arrowtiles) do
    arrowtile:die()
  end

  for particle in all(particles) do
    particle:die()
  end

  for particle in all(bg_particles) do
    particle:die()
  end

  for particle in all(water_particles) do
    particle:die()
  end

  for arrow in all(arrows) do
    arrow:die()
  end

  reset_sky()

  g.reset = false
  level = levels[curlevel]
  lives = level.lives
  level:init()
end

function draw_hud()
  rectfill(0, 120, 128, 128, 0)
  spr(1, 0, 120, 1, 1)
  pset(9, 124, 7)
  pset(9, 126, 7)
  pset(10, 125, 7)
  pset(11, 124, 7)
  pset(11, 126, 7)

  print(lives, 13, 122, 7)

  local str = level.name

  if g.reset then
    str = "hold \142 to reset"
    g.reset_enabled = true
  end

  if g.reset_value > 0 then
    rectfill(45, 121, 45 + g.reset_value, 128, 8)
    str = "resetting"
  end

  print(str, 64 - #str*2, 122, 7)

  if g.dooropen and not g.doorclosed then
    local m, s = get_time()
    draw_time(m, s, 118, 122)
  end
end

function draw_time(m, s, x, y, left_align)
  if left_align then
    x += #m*4
  end
  shadow_print(m, x - #m*4, y, 7)
  shadow_print(s, x + 2, y, 7)
  shadow_print(":", x - 1, y)
end

function get_time()
  local s = flr(time() - start_time)
  local m = flr(s/60) .. ""
  s = s%60
  if s < 10 then
    s = "0" .. s
  end
  return m, s
end

function _update()

  if btn(4) then
    
    if g.reset_enabled and g.reset_released then
      g.resetting = true
      g.reset_released = false
    end
  else
    g.resetting = false
    g.reset_released = true
  end

  if g.resetting then
    g.reset_value += 1
  else
    g.reset_value -= 5
  end

  g.reset_value = max(g.reset_value, 0)

  if g.reset_value >= 37 then
    g.reset = false
    g.resetting = false
    g.reset_value = 0
    resets += 1
    reset_level()
  end

  if not g.dooropen then
    start_time = time()
  end

  do_fade()

  update_sky()

  for fadetile in all(fadetiles) do
    fadetile.playeron = false
  end

  for player in all(players) do
    player:fade_collision()
  end

  for actor in all(actors) do
    actor:update()
  end

  for particle in all(particles) do
    particle:update()
  end

  for particle in all (water_particles) do
    particle:update()
  end

  for particle in all(bg_particles) do
    particle:update()
  end

  if active_player.inwater and not active_player.dead then
    poke(0x5f41, 15)
    poke(0x5f43, 15)
    g.muffle_frame = 0
  else
    g.muffle_frame += 1
    if g.muffle_frame > 5 then
      poke(0x5f41, 0)
      poke(0x5f43, 0)
      g.muffle_frame = 0
    end
  end

  if g.doorclosed then
    if rnd() > .95 and #bg_particles < 850 then
      new_fireworks(rnd(128), rnd(32))
      g.fireworks_lev = 0
      g.fade_frame = 9
    end

    if g.fade_frame%9 == 0 then
      g.fireworks_lev += 1
      if g.fireworks_lev > 3 then
        g.fireworks_lev = 3
      end
    end
  end
end

function _draw()
  cls()

  pal()

  draw_fade()

  for particle in all(bg_particles) do
    particle:draw()
  end

  if curlevel >= 31 then
    g.prev_lev = 0
    if not g.fading then
      g.fade_lev = 1
    end
    draw_fade()
    draw_sky()
    if not g.fading then
      g.fade_lev = g.fireworks_lev
    end
    draw_fade()
  elseif curlevel >= 30 then
    g.prev_lev = 0
    if not g.fading then
      g.fade_lev = 2
    end
    draw_fade()
    draw_sky()
  else
    draw_sky()
  end

  if curlevel == 1 or curlevel == 32 then
    rectfill(32, 30, 88, 48, 1)
  end

  palt(0, false)
  palt(12, true)

  level:draw()

  for actor in all(actors) do
    actor:draw()
  end

  for player in all(players) do
    player:draw_shadow()
  end

  for particle in all(particles) do
    particle:draw()
  end

  level:draw(true)

  for particle in all(water_particles) do
    particle:draw()
  end

  pal()
  palt(0, false)
  palt(12, true)

  draw_hud()
  
  if g.doorclosed then

    local text_x = 32
    local text_y = 56

    shadow_print("well done!", text_x, text_y)
    shadow_print("harolds killed: " .. deaths, text_x, text_y + 16)
    shadow_print("harolds saved: " .. lives_saved, text_x, text_y + 24)
    shadow_print("resets: " .. resets, text_x, text_y + 32)
    shadow_print("final time:", text_x, text_y + 40)
    draw_time(final_time_m, final_time_s, text_x + 48, text_y + 40, true)
  end

end

function do_fade()
  g.fade_frame += 1

  if g.fade_frame%2 == 0 then
    g.fade_lev += g.fade_dir
  end

  if g.fade_lev != g.prev_lev then
    if g.fade_lev > 8 then
      g.fade_lev = 8
      g.fade_dir = -1
      init_level()
    end

    if g.fade_lev <= 1 then
      g.fade_dir = 0
      g.fade_lev = 1
      g.fading = false
    end
  end
end

function draw_fade()
  local fl = g.fade_lev

  if curlevel == 31 then
    if fl <= 3 then
      fl = 3
    end
  end
  
  if fl != g.prev_lev then
    local c

    for c = 0, 15 do
      if fl >= 5 then
        pal(c, 0)
      elseif fl <= 1 then
        pal()
        palt(0, false)
      else
        pal(c, fades[c + 1][fl])
      end
    end
  end
end
