--cyclo 8
--by nusan

camoffx = 0 camoffy = -64
goalcamx = 0 goalcamy = -64
camadvanx = 0

bikeframe = 0

flaganim = 0
score = 0
retries = 0
timer = 0

totalscore = 0
totalretries = 0
totaltimer = 0
totalleveldone = 0

bikefaceright = true
isdead = false
isfinish = false
restartafterfinish = false
isstarted = false

charx = 0
chary = 0
charx2 = 0
chary2 = 0
chardown = false

-- position of the last checkpoint
last_check_x = 0
last_check_y = 0
has_check = false

dbg_lastcheckidx = 0

-- physics settings :

-- nb of physics substeps
stepnb = 10
-- strengh of rebound
str_reflect = 1.1
str_gravity = 0.06
str_air = 0.99
str_wheel = 0.25
str_wheel_size = 1.0
str_link = 0.5
-- rotation of the bike 
-- according to arrow keys
str_bodyrot = 0.04

-- acceleration factor
base_speedlerp = 0.5
-- max speed front
base_speedfront = 0.18
-- max speed back
base_speedback = 0.03
base_frameadvfront = 0.3
base_frameadvback = 0.15

limit_col = 2.0
limit_wheel = 1.5

bodyrot = 0.0

playeridx = 1

currentlevel = 1
levelnb = 7

timernextlevel = 0
timernextlevel_dur = 30*7

timerlasteleport = 1000

zone = {}

cloudsx = {}
cloudsy = {}
cloudss = {}

-- map zone structure.
-- level is made of several zones
function zone.new (in_startx,in_starty,in_sizex,in_sizey)
	local set = {}
	set.startx = in_startx
	set.starty = in_starty
	set.sizex = in_sizex
	set.sizey = in_sizey
  return set
end

level = {}
    
-- level structure
function level.new (in_name,in_zkill,in_backy,in_camminx,in_cammaxx,in_camminy,in_cammaxy)
	local set = {}
	set.name = in_name
	set.zones = {}
	set.zonenb = 0
	set.zkill = in_zkill
	set.backy = in_backy
	set.camminx = in_camminx
	set.cammaxx = in_cammaxx
	set.camminy = in_camminy
	set.cammaxy = in_cammaxy
	set.startright = true
	return set
end

levels = {}

entity = {}
    
-- entity = the 2 wheels
function entity.new (in_x,in_y)
	local set = {}
	set.x = in_x
	set.y = in_y
	set.vx = 0.0
	set.vy = 0.0
	set.rot = 0.0
	set.vrot = 0.0
	set.isflying = true
	--set.lastcolx = set.x
	--set.lastcoly = set.y
	--set.lastcolnx = 0
	--set.lastcolny = 0
	set.link = nil
	set.linkside = 1
  return set
end

entities = {}

item = {}
itemnb = 0

item_apple = 1
item_checkpoint = 2
item_start = 3
item_finish = 4
item_teleport = 5
    
function item.new (in_x,in_y,in_type)
	local set = {}
	set.x = in_x
	set.y = in_y
	set.type = in_type
	set.active = true
	set.size = 8
  return set
end

items = {}

link = {}

-- a physic link between wheels
function link.new (ent1,ent2)
	local set = {}
	set.ent1 = ent1
	set.ent2 = ent2
	set.baselen = 8.0
	set.length = set.baselen
	set.dirx = 0.0
	set.diry = 0.0
  return set
end

link1 = link.new(1,2)

-- array to link sprite to colision
sdflink = {}
sdflink[1] = 1
sdflink[2] = 2
sdflink[3] = 3
sdflink[12] = 3
sdflink[6] = 4
sdflink[13] = 4
sdflink[8] = 5
sdflink[9] = 6
sdflink[10] = 7
sdflink[11+16] = 8
sdflink[0+16*3] = 9
sdflink[1+16*3] = 10
sdflink[2+16*3] = 11
sdflink[3+16*3] = 12
sdflink[4+16*3] = 13
sdflink[10+16*3] = 14
sdflink[11+16*3] = 15

function lerp(a,b,alpha)
	return a*(1.0-alpha)+b*alpha
end

function saturate(a)
	return max(0, min(1, a))
end

function blur_pass(insdf,outsdf)
	for i=1,14 do
		for j=1,14 do
			local idx = i+j*16
			local sum = 0
			local wei = 0
			for sx=-1,1 do	
				for sy=-1,1 do	
					local lwei = sqrt(sx*sx + sy*sy + 0.01)
					sum += insdf[idx + sx + sy*16] * lwei
					wei += lwei
				end
			end
			outsdf[idx] = sum / wei
		end
	end
end

-- this function is not used at runtime
-- it create a distance field in a 16x16 sprite
-- based on a 8x8 sprite colision
function gen_sdf(ix,iy,num)
	local rx = 8*ix
	local ry = 8*iy

	local wx = 2*8*(num%8)
	local wy = 2*8*flr(num/8) + 8*12

	-- init to 0
	-- we will ping-pong
	-- beetween sdf and sdf2
	local sdf = {}
	local sdf2 = {}
	for i=0,15 do
		for j=0,15 do
			sdf[i+j*16] = 0.0
		end
	end

	-- fill the sdf sprite with the base sprite colision
	for i=0,7 do
		for j=0,7 do
			local sc = sget(rx+i, ry+j, 8)
			local idx = i+4+(j+4)*16
			-- 3 is the transparent color
			if(sc!=3) then
				sdf[idx] = 15.0
			else
				sdf[idx] = 0.0
			end
			--sset(wx+i + 4, wy+j + 4, sc)
		end
	end

	-- first propagation of distance field
	-- along x axis
	for i=0,15 do
		for j=0,15 do
			local idx = i+j*16
			-- we search the nearest colision along x
			local mindist = 15.0
			for s=0,15 do	
				-- if we find a colision on the same row
				if(sdf[s+j*16] >= 8.0) then
					-- set the distance
					local curdist = abs(s-i)
					mindist = min(mindist, curdist)
				end
			end
			sdf2[idx] = mindist
		end
	end

	-- second propagation of distance field
	-- along y axis
	for i=0,15 do
		for j=0,15 do
			local idx = i+j*16
			-- we search the nearest colision along x,y
			local mindist = 15.0
			for s=0,15 do	
				-- we compute the final distance
				-- with pythagore
				local disty = abs(s-j)
				local distx = sdf2[i+s*16]
				local curdist = sqrt(distx*distx+disty*disty + 0.001)
				mindist = min(mindist, curdist)
			end
			sdf[idx] = mindist
		end
	end

	--blur_pass(sdf,sdf2)
	--blur_pass(sdf2,sdf)

	-- we encode the final sdf
	-- in sprites
	-- we want a maximum range of 4
	-- because the wheel is of radius 4
	for i=0,15 do
		for j=0,15 do
			local idx = i+j*16
			sset(wx+i, wy+j, max(0,min(flr(15.0-(sdf[idx]-1)*4.0),15)))
			--sset(wx+i, wy+j, max(0,min(flr(sdf[idx]),15)))
		end
	end

	-- we save everything in the cartridge
	cstore()
end

function gen_all_sdf()
	-- here is the list of all sprites
	-- that will generate a sdf
	gen_sdf(0,1,0)
	gen_sdf(1,0,1)
	gen_sdf(2,0,2)
	gen_sdf(3,0,3)
	gen_sdf(6,0,4)
	gen_sdf(8,0,5)
	gen_sdf(9,0,6)
	gen_sdf(10,0,7)
	gen_sdf(11,1,8)
	gen_sdf(0,3,9)
	gen_sdf(1,3,10)
	gen_sdf(2,3,11)
	gen_sdf(3,3,12)
	gen_sdf(4,3,13)
	gen_sdf(10,3,14)
	gen_sdf(11,3,15)
end

function create_levels()

	local l=1
	levels[l] = level.new("long road", 256, 144, 512,896,-1000,128)
	levels[l].zones[1] = zone.new(64,16,64,16)
	levels[l].zonenb = 1

	l=2
	levels[l] = level.new("easy wheely", 125, 16, 0,400,-1000,58)
	levels[l].zones[1] = zone.new(0,0,64,16)
	levels[l].zones[2] = zone.new(32,16,32,4)
	levels[l].zonenb = 2

	l=3
	levels[l] = level.new("central pit", 256, 144, 0,128,-1000,128)
	levels[l].zones[1] = zone.new(0,16,32,16)
	levels[l].zonenb = 1

	l=4
	levels[l] = level.new("spiral", 125, 16, 834,896,2,2)
	levels[l].zones[1] = zone.new(104,0,24,16)
	levels[l].zonenb = 1

	l=5
	levels[l] = level.new("sky fall", 125, 16, 512,700,-1000,0)
	levels[l].zones[1] = zone.new(64,0,40,16)
	levels[l].zonenb = 1

	l=6
	levels[l] = level.new("here and there",386, 272, 384,896,-1000,256)
	levels[l].zones[1] = zone.new(48,32,64,16)
	levels[l].zones[2] = zone.new(112,32,16,8)
	levels[l].zonenb = 2
	levels[l].startright = false

	l=7
	levels[l] = level.new("ninja rise",386, 256, 0,385,-1000,256)
	levels[l].zones[1] = zone.new(0,32,48,16)
	levels[l].zones[2] = zone.new(32,20,32,12)
	levels[l].zonenb = 2

end

function _init()
	-- uncomment the next line
	-- to regenerate sdf sprite
	--gen_all_sdf()

	pal={5,13,15,11,9,6,7,7,14,10,7,7,7,6,15,7}

	create_entities()
	create_levels()
	create_clouds()
end

function create_clouds()
	local i = 1
	while(i <= 60) do
		cloudsx[i] = rnd(10)
		cloudsy[i] = rnd(5)
		cloudss[i] = rnd(10)
		i+=1
	end
end

function start_level(levelidx)
	currentlevel = levelidx

	items = {}
	itemnb = 0
	has_check = false
	bikefaceright = levels[currentlevel].startright
	
	find_replace_items()
	reset_camera()
	reset_player()
	score = 0
	retries = 0
	timer = 0
	restartafterfinish = false

	sfx(7,2)
end

function find_replace_items_zone(startx, starty, sizex, sizey)
	for i=startx,startx+sizex-1 do
		for j=starty,starty+sizey-1 do

			local col = mget(i,j)
			local flags = fget(col)

			local itemtype = 0
			if(band(flags, 4)>0) then
				itemtype = item_teleport
				if(col == 56) then
					itemtype = item_apple
				end	
			end
			if(band(flags, 8)>0) then
				itemtype = item_checkpoint
				if(col == 67) then
					itemtype = item_start
					last_check_x = 8*i+4
					last_check_y = 8*j+4
				end
				if(col == 68) then
					itemtype = item_finish
				end
			end

			-- if we found an item
			if(itemtype != 0) then
				itemnb += 1
				items[itemnb] = item.new(i*8+3.5,j*8+3.5, itemtype)

				-- remove from the map
				mset(i,j,0)
			end

		end
	end
end

-- find all items
-- insert in the array
-- remove them from the map
function find_replace_items()

	-- here is the list of zones
	-- that make the level
	for i=1,levels[currentlevel].zonenb do

		local curzone = levels[currentlevel].zones[i]
		find_replace_items_zone(curzone.startx,curzone.starty,curzone.sizex,curzone.sizey)

	end
	
	--find_replace_items_zone(0,0,128,16)
	--find_replace_items_zone(32,16,64,8)

end

-- display the level
function draw_map(flags)

	-- here is the list of zones
	-- that make the level

	for i=1,levels[currentlevel].zonenb do

		local curzone = levels[currentlevel].zones[i]
		map(curzone.startx,curzone.starty,curzone.startx*8,curzone.starty*8,curzone.sizex,curzone.sizey, flags)

	end

	--map(0,0,0,0,128,16,flags)
	--map(32,16,32*8,16*8,64,8,flags)
end

-- reset player state
-- after a retry
function reset_player()
	entities[playeridx].x = last_check_x
	entities[playeridx].y = last_check_y
	entities[playeridx].vx = 0
	entities[playeridx].vy = 0
	entities[playeridx].vrot = 0

	entities[playeridx+1].x = last_check_x+8
	entities[playeridx+1].y = last_check_y
	entities[playeridx+1].vx = 0
	entities[playeridx+1].vy = 0
	entities[playeridx+1].vrot = 0

	--camoffx = 0 camoffy = -64
	--goalcamx = 0 goalcamy = -64

	--bikefaceright = true
	isdead = false

	if(isfinish) then
		restartafterfinish = true
	end
	if(not isfinish) then
		retries += 1
	end
end

function reset_camera()

	camoffx = last_check_x-16 -- -64
	camoffy = last_check_y-64 -- -96
	goalcamx = camoffx
	goalcamy = camoffy
end

-- create the 2 wheels
-- and init some variables
function create_entities()
	entities[1] = entity.new(0,0)
	entities[2] = entity.new(0+8,0)
	entities[1].link = link1
	entities[1].linkside = 1
	entities[2].link = link1
	entities[2].linkside = -1
end

-- get the value of sdf
-- at location lx,ly
-- according to a sprite
-- chosen at an offset ox,oy
function get_sdf(lx,ly,ox,oy)
	local sx = flr((lx+ox)/8)
	local sy = flr((ly+oy)/8)

	-- get the sprite at the offset
	local col = mget((lx+ox)/8, (ly+oy)/8)
	local flags = fget(col)
	local isc = band(flags, 1)

	-- check if its a colision
	if(isc==0) then
		return 0
	end

	-- check if its in the level zone
	local inlevelzone = false
	for i=1,levels[currentlevel].zonenb do

		local curzone = levels[currentlevel].zones[i]
		if((sx>=curzone.startx) and (sx<(curzone.startx+curzone.sizex))) then
			if((sy>=curzone.starty) and (sy<(curzone.starty+curzone.sizey))) then
				inlevelzone = true
				break
			end
		end
	end
	if(not inlevelzone) then
		return 0
	end

	-- get the colision profile
	local sdfval = sdflink[col];
	-- if none is found, use the full square
	if(sdfval == nil) then sdfval = 0 end

	-- proper coordinates in sdf
	local wx = 2*8*(sdfval%8) + lx-sx*8 + 4
	local wy = 2*8*flr(sdfval/8) + 8*12 + ly-sy*8 + 4

	-- get distance
	local dist = sget(wx, wy)

	return dist
end

-- get the combined sdf
-- of the 4 closest cells
function is_pointcol(lx,ly)

	local v0 = get_sdf(lx,ly,-3,-3)
	local v1 = get_sdf(lx,ly, 4,-3)
	local v2 = get_sdf(lx,ly, 4, 4)
	local v3 = get_sdf(lx,ly,-3, 4)

	return max(max(v0,v1),max(v2,v3))
end

-- get the colision distance
-- and surface normal
function is_coliding(lx,ly)

	-- we take the 4 points
	-- at the center of the wheel
	local v0 = is_pointcol(lx-0.5,ly-0.5)
	local v1 = is_pointcol(lx+0.5,ly-0.5)
	local v2 = is_pointcol(lx+0.5,ly+0.5)
	local v3 = is_pointcol(lx-0.5,ly+0.5)

	-- we iterpolate the distance
	-- with bilinear
	local llx = lx-0.5-flr(lx-0.5)
	local lly = ly-0.5-flr(ly-0.5)
	local lerp1 = (1.0-llx)*v0 + llx*v1
	local lerp2 = (1.0-llx)*v3 + llx*v2
	local final = (1.0-lly)*lerp1 + lly*lerp2

	-- the normal is a gradient
	local norx = (v0-v1 + v3-v2)*0.5
	local nory = (v0-v3 + v1-v2)*0.5

	-- we ensure normal is normalized
	local len = sqrt(norx*norx+nory*nory + 0.001)
	norx /= len
	nory /= len
	
	--local final = is_pointcol(lx,ly)

	return final, norx, nory
end

-- this take a velocity vector
-- and reflect it by a normal
-- a damping is applyed of the reflection
function reflect(vx, vy, nx, ny)

	local dot = vx*nx + vy*ny
	local bx = dot*nx
	local by = dot*ny

	local rx = vx-str_reflect*bx
	local ry = vy-str_reflect*by

	-- we play some colision sounds
	-- when both vector are opposite
	if(dot<-0.8) then
		sfx(0,3)
	else
		if(dot<-0.2) then
			sfx(6,3)
		end
	end

	return rx, ry
end

-- this update the state of a link
-- between 2 wheels
function up_link(link)

	local dirx = entities[link.ent2].x - entities[link.ent1].x
	local diry = entities[link.ent2].y - entities[link.ent1].y

	link.length = sqrt( dirx*dirx + diry*diry + 0.01)
	link.dirx = dirx/link.length
	link.diry = diry/link.length
end

-- pre physic update of a wheel
function up_start_entity(ent)

	-- apply gravity
	ent.vy += str_gravity
	ent.isflying = true

end

-- do one step of physic on a wheel
function up_step_entity(ent)

	-- apply link force
	if(ent.link != nil) then

		-- force according to base length
		local flink = (ent.link.length - ent.link.baselen) * str_link

		-- add the force
		ent.vx += ent.link.dirx * ent.linkside * flink
		ent.vy += ent.link.diry * ent.linkside * flink

		-- apply the rotation
		-- due to the body
		-- if not on the ground ?
		--if(ent.isflying) then
		if(true) then
			-- force perpendicular
			-- to the link axis
			local perpx = ent.link.diry
			local perpy = -ent.link.dirx

			ent.vx += perpx * bodyrot/stepnb * ent.linkside
			ent.vy += perpy * bodyrot/stepnb * ent.linkside
		end
	end

	-- we test if the new location
	-- is coliding
	local x2 = ent.x + ent.vx/stepnb
	local y2 = ent.y + ent.vy/stepnb

	iscol,norx,nory = is_coliding(x2,y2)

	-- if coliding
	if iscol > limit_col then

		-- debug data
		--ent.lastcolx = ent.x
		--ent.lastcoly = ent.y
		--ent.lastcolnx = norx
		--ent.lastcolny = nory

		-- reflect the velocity by
		-- the surface normal
		ent.vx, ent.vy = reflect(ent.vx,ent.vy,norx,nory)

		-- ensure we are not inside the colision
		ent.x = ent.x + norx * (iscol-limit_col)
		ent.y = ent.y + nory * (iscol-limit_col)
	end

	-- apply the motion
	ent.x = ent.x + ent.vx/stepnb
	ent.y = ent.y + ent.vy/stepnb

	-- if wheel is near the ground
	-- we apply the wheel force
	if iscol > limit_wheel then

		-- force direction
		-- perpendicular to the
		-- surface normal
		local perpx = nory
		local perpy = -norx

		local angfac = 3.1415 * 8 * str_wheel_size
		-- transform wheel speed to force
		local angrot = ent.vrot * angfac
		local wantx = angrot * perpx
		local wanty = angrot * perpy

		local distfactor = 1.0--saturate((iscol - limit_wheel)*1.0)

		-- interpolate between
		-- wheel motion
		-- and entity motion
		local lerpx = lerp(ent.vx, wantx, str_wheel * distfactor)
		local lerpy = lerp(ent.vy, wanty, str_wheel * distfactor)
		
		ent.vx = lerpx
		ent.vy = lerpy

		-- get the wheel speed along the surface
		local dotperp = (ent.vx*perpx + ent.vy*perpy)

		-- the new wheel rotation is
		-- the speed along the surface
		ent.vrot = dotperp / angfac

		-- the wheel touch the ground
		ent.isflying = false
	end
end

-- post physic update of a wheel
function up_end_entity(ent)
	-- apply air friction
	if(not ent.isflying) then
		ent.vx *= str_air
		ent.vy *= str_air
	end

	-- make the wheel turn
	ent.rot += ent.vrot
	-- we could apply a wheel friction
	--ent.vrot *= 0.94
end

-- check if an item
-- is near the player
function check_item(it)

	-- need to be carefull
	-- with squaring because of overflow
	-- so we first divide by the item size
	-- before squaring
	local madx = (it.x - charx) / it.size
	local mady = (it.y - chary) / it.size
	local sqrlen = (madx*madx + mady*mady)

	-- if colision with an item
	if((not isdead) and (sqrlen < 1))  then
		-- apples
		if((it.type == item_apple) and it.active) then
			if(not restartafterfinish) then
				it.active = false
				score += 1
				if(isfinish) then totalscore += 1 end -- special case
				sfx(3,3)
			end
		end
		-- teleports
		if((it.type == item_teleport) and it.active) then
			if((not isfinish) and (not isdead)) then
				sfx(7,2)
				retries -= 1 -- free retry
				timerlasteleport = 0
				reset_player()
			end
		end
		-- checkpoints
		if((it.type == item_checkpoint) or (it.type == item_finish)) then
			if(it.active) then
				it.active = false
				last_check_x = it.x
				last_check_y = it.y
				has_check = true

				if(it.type == item_finish) then
					isfinish = true
					-- cumul total values
					totalscore += score
					totaltimer += timer
					totalretries += retries
					totalleveldone += 1
					sfx(5,2)
				else
					sfx(7,2)
				end
			end
		end
	end
end

-- debug function
-- find the next checkpoint in the list of item

function find_next_checkpoint()
	dbg_curcheckcount = 1
	dbg_checkfound = false
	foreach(items, loop_next_checkpoint)
	if(dbg_checkfound) then
		dbg_lastcheckidx += 1
		retries -= 1
		reset_player()
	else
		dbg_lastcheckidx = 0
	end
end

function loop_next_checkpoint(it)

	local checkfound = false
	if(it.type == item_checkpoint) then
		if(dbg_curcheckcount == dbg_lastcheckidx+1) then
			it.active = true
			last_check_x = it.x
			last_check_y = it.y
			has_check = true
			dbg_checkfound = true
		end
		dbg_curcheckcount += 1
	end
end


-- main update function
function _update()

	-- start menu
	if(not isstarted) then

		-- start the game
		if(btnp(4)) then
			isstarted = true
			start_level(currentlevel)
		end

		-- change current level
		if(btnp(0) or btnp(3)) then
			currentlevel -= 1
			if(currentlevel<=0) then
				currentlevel = levelnb
			end
			sfx(0,3)
		end
		if(btnp(1) or btnp(2)) then
			currentlevel += 1
			if(currentlevel>levelnb) then
				currentlevel = 1
			end
			sfx(0,3)
		end

		-- debug
		--isstarted = true

		return
	end

	-- handle going to the next level
	if(isfinish) then
		
		if(timernextlevel > timernextlevel_dur) then

			if(currentlevel != levelnb) then
				isfinish = false
				start_level(currentlevel +1)
				timernextlevel = 0
			end
		end

		timernextlevel += 1

	end
	
	bodyrot = 0.0

	-- player control
	if((not isdead) and (not isfinish)) then

		-- flip button (c)
		if(btnp(4)) then
			bikefaceright = not bikefaceright
			sfx(8,3)
		end

		local speedlerp = base_speedlerp
		local speedfront = base_speedfront
		local speedback = base_speedback
		local frameadvfront = base_frameadvfront
		local frameadvback = base_frameadvback
		local controlwheel = playeridx
		local otherwheel = playeridx + 1
		local wheelside = 1.0
		-- invert all values if bike face left
		if(not bikefaceright) then
			local tmp = speedback
			speedback = speedfront
			speedfront = tmp

			local tmp = frameadvfront
			frameadvfront = frameadvback
			frameadvback = tmp

			local tmp = otherwheel
			otherwheel = controlwheel
			controlwheel = tmp

			wheelside = -1.0
		end

		-- button left
		if(btn(0)) then
			-- make the body rotate
			bodyrot -= str_bodyrot			
		end
		-- button right
		if(btn(1)) then
			-- make the body rotate
			bodyrot += str_bodyrot			
		end
		-- button up
		if(btn(2)) then
			-- only the back wheel is set in motion
			entities[playeridx].vrot = lerp(entities[controlwheel].vrot, -base_speedfront * wheelside, speedlerp)
			--entities[playeridx].vrot = lerp(entities[otherwheel].vrot, -base_speedfront * wheelside, speedlerp)
			bikeframe -= base_frameadvfront
		end
		-- button down
		if(btn(3)) then			
			-- both wheels are slowed
			entities[playeridx].vrot = lerp(entities[controlwheel].vrot, base_speedback * wheelside, speedlerp)
			entities[playeridx].vrot = lerp(entities[otherwheel].vrot, base_speedback * wheelside, speedlerp)
			bikeframe += base_frameadvback
		end
		
	end

	-- update the physics
	-- using several substep
	-- to improve colision
	foreach(entities, up_start_entity)
	for step=0,stepnb-1 do
		-- update links
		up_link(link1)
		-- update wheels
		foreach(entities, up_step_entity)
	end
	foreach(entities, up_end_entity)

	local isdown = false

	-- compute the body location
	-- according to the 2 wheels
	-- this is the upper body
	charx, chary, chardown = get_bike_rot(entities[1],entities[2], 4.0)
	-- this is the lower body
	charx2, chary2, isdown = get_bike_rot(entities[1],entities[2], 1.0)

	-- make upper body a bit closer
	-- to the lower body
	charx += (charx2-charx)*0.5

	-- check the upper body colision
	local coldist,colnx,colny = is_coliding(charx, chary)
	if(coldist > 1.8) then
		-- if there is a colision
		-- the player is dead
		if(not isdead) then
			isdead = true
			if(not isfinish) then
				sfx(4,2)
			end
		end
	end

	-- check items colision
	foreach(items, check_item)

	local needkillplayer = false
	-- check the killing floor
	if(entities[playeridx].y>levels[currentlevel].zkill) then
		needkillplayer = true
	end

	-- check the killing camera limit
	if(entities[playeridx].x>levels[currentlevel].cammaxx+128) then
		needkillplayer = true
	end
	if(entities[playeridx].x<levels[currentlevel].camminx) then
		needkillplayer = true
	end
	if(entities[playeridx].y>levels[currentlevel].cammaxy+128) then
		needkillplayer = true
	end
	if(entities[playeridx].y<levels[currentlevel].camminy) then
		needkillplayer = true
	end
	
	if(needkillplayer) then
		if((not isfinish) and (not isdead)) then
			sfx(4,2)
		end
		reset_player()
	end

	-- check the retry button (v)
	if(btnp(5) and (not isfinish)) then
		sfx(7,2)
		reset_player()
	end

	-- debug cheating :
	if(false) then
		if(btnp(5,1)) then
			find_next_checkpoint()
		end
	end

	-- update the camera :

	-- make the camer look back
	--if(entities[playeridx].vx<-0.8) then
	if(not bikefaceright) then
		camadvanx = -32
	end
	-- make the camer look front
	--if(entities[playeridx].vx>0.8) then
	if(bikefaceright) then
		camadvanx = 32
	end

	-- update the camera goal
	goalcamx = goalcamx*0.9 + (entities[playeridx].x-64+camadvanx)*0.1
	
	-- in y there is a safe zone
	if(camoffy > entities[playeridx].y-64+32) then
		goalcamy = entities[playeridx].y-64+32
	end
	if(camoffy < entities[playeridx].y-64-32) then
	 goalcamy = entities[playeridx].y-64-32
	end
	-- or else the camera is only updated
	-- when the wheel touch ground
	if not entities[playeridx].isflying then
	 goalcamy = entities[playeridx].y-64
	end

	-- clamp the camera goal to the level limit
	goalcamx = max(goalcamx, levels[currentlevel].camminx)
	goalcamx = min(goalcamx, levels[currentlevel].cammaxx)

	goalcamy = max(goalcamy, levels[currentlevel].camminy)
	goalcamy = min(goalcamy, levels[currentlevel].cammaxy)

	-- the camera location is lerped
	--camoffx = camoffx*0.8 + goalcamx*0.2
	--camoffy = camoffy*0.7 + goalcamy*0.3
	camoffx = lerp(camoffx, goalcamx, 0.2)
	camoffy = lerp(camoffy, goalcamy, 0.3)

	-- increment the timer
	if(not isfinish) then
		timer += 1
	end
		
end

-- draw a wheel entity
function draw_entity(ent)

	local base = 80
	-- the wheel sprite
	-- depend on the wheel rotation
	local	rfr = flr(-ent.rot*4*5)%5
	if(rfr<0) rfr+=5
	local cspr = base+rfr

	--if(abs(ent.vrot) > 0.14) then
	if(false) then
		rfr = flr(-ent.rot*3)%3
		if(rfr<0) rfr+=3
		cspr = base+5+rfr
	end	

	-- to avoid the wheel appearing
	-- to rotate backward
	-- if the speed is too strong
	-- we rotate slower but skip
	-- a frame each time
	if(abs(ent.vrot) > 0.14) then
		rfr = flr(-ent.rot*3)%5
		if(rfr<0) rfr+=5
		rfr *= 2
		if(rfr>5) rfr-=5
		cspr = base+rfr
	end

	spr(cspr,ent.x-3.5,ent.y-3.5,1,1)

	--line(ent.lastcolx,ent.lastcoly,ent.lastcolx+ent.lastcolnx*15,ent.lastcoly+ent.lastcolny*15,8)
	--line(ent.x,ent.y,ent.x+ent.vx*15,ent.y+ent.vy*15,11)

	--circ(ent.lastcolx,ent.lastcoly,3,8)
end

-- debug function to draw
-- the sdf colision
-- around the player
function draw_col()
	local x = entities[playeridx].x
	local y = entities[playeridx].y
	for i=flr(x)-15,flr(x)+15 do
		for j=flr(y)-15,flr(y)+15 do
			local mi = (i%2) == 0
			local mj = (j%2) == 0
			if(mi or mj or true) then
				local mycol = is_pointcol(i,j)
				if(mycol>2.0) then
					pset(i,j, mycol)
				end
				--pset(i,j, mycol)
			end
		end
	end
end

-- take 2 wheel and give
-- a point between
-- with an perpendicular offset
function get_bike_rot(ent1, ent2, offset)

	local dirx = ent2.x - ent1.x
	local diry = ent2.y - ent1.y

	-- average to get the center
	local centx = ent1.x + dirx * 0.5
	local centy = ent1.y + diry * 0.5

	-- normalize the direction
	local length = sqrt( dirx*dirx + diry*diry + 0.01)
	dirx = dirx/length
	diry = diry/length

	-- get the perpendicular
	local perpx = diry
	local perpy = -dirx

	-- offset the point
	-- along the perpendicular
	centx += perpx * offset
	centy += perpy * offset

	-- we want to know
	-- is the point is below the bike
	local isdown = false
	if(perpy > 0.5) then isdown = true end

	return centx, centy, isdown
end

function centertext(posx,posy,text,col)

	local sposx = posx - #text * 2
	local sposy = posy
	print(text, sposx+1,sposy,0)
	print(text, sposx-1,sposy,0)
	print(text, sposx,sposy+1,0)
	print(text, sposx,sposy-1,0)
	print(text, sposx,sposy,col)
end

-- draw an item icon (apple, checkpoint)
function draw_item(it)

	-- only apples can be picked
	local hide = false
	if((it.type == item_apple) and (not it.active)) then
		hide = true
	end

	if(it.type == item_start) then
		hide = true
	end

	if(not hide) then
		local sprite = 56

		if(it.type == item_teleport) then
			sprite = 103 + (flaganim%3)
		end

		if((it.type == item_checkpoint) or (it.type == item_finish)) then
			sprite = 64 + (flaganim%3)

			-- change the flag pole color
			local flagcolor = 12
			if(it.active) then
				if(it.type == item_finish) then
					flagcolor = 11
				else
					flagcolor = 8
				end
			end

			line(it.x -1, it.y-3, it.x -1, it.y + 12, flagcolor)			
		end

		spr(sprite,it.x-3.5,it.y-3.5,1,1)

		--line(it.x, it.y, charx, chary, 12)
	end
end

-- draw the introduction and victory big flag
function draw_big_flag(text, finishx, finishy, col)

	--line(finishx-1,finishy,finishx-1,finishy+15,8)
	--line(finishx+64,finishy,finishx+64,finishy+15,8)
	--line(finishx-1,finishy-1,finishx+64,finishy-1,8)
	--line(finishx-1,finishy+16,finishx+64,finishy+16,8)
	rectfill(finishx,finishy,finishx+63,finishy+15,0)
	for i=0,31 do
		local tmpx = finishx+(i%16)*4
		local tmpy = finishy + (1-i%2) * 4 + flr(i/16)*8
		rectfill(tmpx,tmpy,tmpx+3,tmpy+3,6)
	end

	centertext(finishx+32,finishy+6,text,col)

	--pal(7,10)

	local sprite = (64 + (flr(flaganim*0.7)%3))
	--spr(sprite,finishx-6,finishy,1,1,true)
	--spr(sprite,finishx-2+64,finishy,1,1,false)
	sspr((sprite-64)*8,4*8,8,8,finishx-20,finishy-4,32,32,true)
	sspr((sprite-64)*8,4*8,8,8,finishx-16+64,finishy-4,32,32,false)		

	--pal()
end

function gettimestr(val)
	-- transform timer to min:sec:dec
	local t_cent = flr(val*10/30)%10
	local t_sec = flr(val/30)%60
	local t_min = flr(val/(30*60))

	local fill_sec = ""
	if(t_sec<10) then fill_sec = "0" end

	return t_min..":"..fill_sec..t_sec..":"..t_cent
end

function clampy(v)
	return v--return max(0,min(128,v))
end

function swap(x1,x2)
	return x2,x1
end

function rectlight(x,y,sx,sy,c)
	local mx = min(x,sx)
	local ex = max(x,sx)
	for i=mx,ex do
		pset(i,y,pal[pget(i,y)+1])
	end
end

function otri(x1,y1,x2,y2,x3,y3,c)

	if y2<y1 then
		if y3<y2 then
			y1,y3=swap(y1,y3)
			x1,x3=swap(x1,x3)
		else
			y1,y2=swap(y1,y2)
			x1,x2=swap(x1,x2)
		end
	else
		if y3<y1 then
			y1,y3=swap(y1,y3)
			x1,x3=swap(x1,x3)
		end
	end

	y1 += 0.001

	local miny = min(y2,y3)
	local maxy = max(y2,y3)

	local fx = x2
	if y2<y3 then
		fx = x3
	end

	local cl_y1 = (clampy(y1))
	local cl_miny = (clampy(miny))
	local cl_maxy = (clampy(maxy))

	local steps = (x3-x1)/(y3-y1)
	local stepe = (x2-x1)/(y2-y1)

	local sx = steps*(cl_y1-y1)+x1
	local ex = stepe*(cl_y1-y1)+x1
		
	for y=cl_y1,cl_miny do
		rectlight(sx,y,ex,y,c)
		sx += steps
		ex += stepe
	end

	sx = steps*(miny-y1)+x1
	ex = stepe*(miny-y1)+x1

	local df = 1/(maxy-miny)

	local step2s = (fx-sx) * df
	local step2e = (fx-ex) * df

	local sx2 = sx + step2s*(cl_miny-miny)
	local ex2 = ex + step2e*(cl_miny-miny)

	for y=cl_miny,cl_maxy do
		rectlight(sx2,y,ex2,y,c)
		sx2 += step2s
		ex2 += step2e
	end
end

function wtri(x1,y1,x2,y2,x3,y3,c)
	line(x1,y1,x2,y2,c)
	line(x3,y3,x2,y2,c)
	line(x1,y1,x3,y3,c)
end

function lamp(lampx,lampy,lampdirx,lampdiry,lampperpx,lampperpy,sidefac,lamplen,lampwid)

	local lampp1x = lampx + lampdirx * lamplen*sidefac + lampperpx * lampwid
	local lampp1y = lampy + lampdiry * lamplen*sidefac + lampperpy * lampwid
	local lampp2x = lampx + lampdirx * lamplen*sidefac - lampperpx * lampwid
	local lampp2y = lampy + lampdiry * lamplen*sidefac - lampperpy * lampwid
	otri(flr(lampx),flr(lampy), flr(lampp1x), flr(lampp1y), flr(lampp2x), flr(lampp2y), 10)

end

-- main draw function
function _draw()

	cls()
		
	camera(0, 0)

	-- black will not be translucent
	-- dark green will be
	palt(0,false)
	palt(3,true)
	palt(4,false)

	-- start menu
	if(not isstarted) then

		rectfill(0,0,127,127,1)

		local c = 16

		centertext(64,c,"nusan present",5)
		draw_big_flag("cyclo 8",32,c+12,10)

		c = 58
		centertext(32,c,"up = gas",7)
		centertext(32,c+8,"down = brake",7)
		centertext(64,c+16,"left-right = rotate the bike",7)
		centertext(96,c,"c = flip bike",7)
		centertext(96,c+8,"v = retry",7)

		local flipcol = 6+flr(flaganim*0.5)%2

		c = 94
		centertext(64,c,"starting level :",7)
		centertext(64,c+8,"< "..currentlevel.." - "..levels[currentlevel].name.." >",8)
		centertext(64,c+18,"press c to start",flipcol)

		flaganim += 0.2

		return
	end

	-- background color
	rectfill(0,0,127,127,4)
	
	camera(camoffx, camoffy)

	local treeoff = levels[currentlevel].backy

	-- draw the cloud in background :

	local paral2x = (camoffx)*0.75
	local paral2y = (camoffy-treeoff)*0.75 + treeoff

	i = 1
	while(i <= 30) do
		circfill(paral2x + i * 20 + cloudsx[i], paral2y + 45 + cloudsy[i], 10+cloudss[i], 5)
		i += 1
	end

	i = 1
	while(i <= 30) do
		local b = i-30
		circfill(paral2x + i * 20 + cloudsx[i], paral2y + 62 + cloudsy[i], 10+cloudss[i], 4)
		i += 1
	end

	-- draw the trees :

	local paralx = (camoffx)*0.5
	local paraly = (camoffy-treeoff)*0.5+treeoff
	palt(3,false)
	palt(4,true)
	-- draw the bottom of the trees
	rectfill(camoffx,paraly+64+8,camoffx+128,camoffy+128,2)	

	paralx = paralx%128+flr(paralx/128)*256
	-- draw 2 series of trees
	-- warping infinitly
	map(112,40,paralx,paraly+16,16,8)
	map(112,40,paralx+128,paraly+16,16,8)
	palt(3,true)
	palt(4,false)
	
	-- draw the bottom line
	-- in black to mask bottom
	-- of the level
	rectfill(camoffx,108+treeoff,camoffx+128,110+treeoff,12)
	rectfill(camoffx,109+treeoff,camoffx+128,camoffy+treeoff+128,0)
	
	--draw_col()

	-- draw the all level
	draw_map(0)

	foreach(items, draw_item)

	--draw_entity(entities[1])
	--draw_entity(entities[2])
	foreach(entities, draw_entity)

	-- draw the player :

	local cspr = flr(-bikeframe)%4
	if(cspr<0) cspr+=4
	if(isdead) cspr = 4

	local bodyadv = 0
	if(bodyrot>0) then bodyadv = 1 end
	if(bodyrot<0) then bodyadv = -1 end

	local cspr2 = cspr+16

	if(chardown) then
		cspr = 5
		if(isdead) cspr = 6
	end

	-- player lower body
	spr(96+cspr2,charx2-3.5,chary2-4.5,1,1,not bikefaceright)
	-- player upper body
	spr(96+cspr,charx-3.5 + bodyadv * 2,chary-6,1,1,not bikefaceright)

	local wheelidx = 1
	local sidefac = -1
	if(bikefaceright) then
		wheelidx = 2
		sidefac = 1
	end
	
	local lampdirx = entities[playeridx].link.dirx
	local lampdiry = entities[playeridx].link.diry
	local lampperpx = lampdiry
	local lampperpy = -lampdirx
	local lampx = entities[wheelidx].x + lampperpx*4 + lampdirx * sidefac * 2
	local lampy = entities[wheelidx].y + lampperpy*4 + lampdiry * sidefac * 2

	lamp(lampx,lampy,lampdirx,lampdiry,lampperpx,lampperpy,sidefac,20,10)
	--lamp(lampx,lampy,lampdirx,lampdiry,lampperpx,lampperpy,sidefac,10,5)
	--lamp(lampx,lampy,lampdirx,lampdiry,lampperpx,lampperpy,sidefac,5,2)
	circ(flr(lampx),flr(lampy),1,1)
	pset(flr(lampx),flr(lampy),7)
	
	-- draw the foreground part of the level
	draw_map(bnot(0x2))

	--otri(flr(lampx),flr(lampy), flr(lampp1x), flr(lampp1y), flr(lampp2x), flr(lampp2y), 10)

	--circfill(charx,chary,1, 11)

	--draw_col()
	
	camera(0, 0)

	-- display hud
	if(true) then

		if(timerlasteleport < 30) then
			if((timerlasteleport % 4)<2) then
				centertext(64,64,"teleport",12)
			end
			timerlasteleport += 1
		end

		-- handle going to the next level
		if(isfinish) then
			
			local progress = saturate((timernextlevel/timernextlevel_dur - 0.3)/0.5)
			rectfill(-1,0,128*progress-1,128,1)

			if(progress > 0.9) then
				if(currentlevel>=levelnb) then
					local c = 36

					centertext(64,c,"nusan present",5)
					draw_big_flag("cyclo 8",32,c+12,10)

					centertext(66,72,"thanks for playing",7)
				else
					centertext(64,64,"next level :",7)
					centertext(64,74,(currentlevel+1).." - "..levels[currentlevel+1].name,7)	
				end	
			end

			centertext(64,14,"total over "..totalleveldone.. " levels",12)
			centertext(22,22,"retries:"..totalretries,12)
			centertext(64,24,"score:"..totalscore,12)
			centertext(112,22,gettimestr(totaltimer),12)

		end

		centertext(22,4,"retries:"..retries,8)
		centertext(64,2,"score:"..score,8)
		centertext(112,4,gettimestr(timer),8)

		if(isdead and (not isfinish)) then
			centertext(64,20,"you are dead",8)
			centertext(64,28,"press v to retry",8)
		end

		if(isfinish) then
			draw_big_flag("victory",32,90,8)
		end
	end


	-- debug draw values
	if(false) then
		--[[print(flr(entities[playeridx].x),0,112,4)
		print(flr(entities[playeridx].y),0,120,4)

		print(entities[playeridx].vrot,24,112,4)
		print(entities[playeridx].vx,24,120,4)

		print(flr(camoffx),64,112,4)
		print(flr(camoffy),64,120,4)]]--
		print("cpu "..stat(1),96,112,7)
	end

	flaganim += 0.2
end