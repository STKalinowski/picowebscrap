-- ennuigi
-- by josh millard

state = "logo"

-- defining ennuigi
enn = {}   
enn.x = 64
enn.y = 80
enn.ox = enn.x
enn.dx = enn.x
enn.s = "stand"
enn.left = true
enn.lneg = -1

-- thought stuff
thc = {0,5,6,7,6,5,0}
thinking = false
th = {}
thi = -18

-- smoking anim
frames = {0,0,0,0,0,
1,2,3,4,5,5,6,6,
7,7,7,4,3,2}
frc = 1
exc = 1

-- walking anim
enn.dx = 0
wframe = 0 



fcount = 0

logoanim=1
logostop=31
logofr=6
function logo()
 local cx = 55
 local cy = 45
 local frx=logofr%16*8
 local fry=flr(logofr/16)*8
 for s=0,logoanim do
  for x=0,15 do
   camera(rnd(30/fcount),
          rnd(30/fcount))
   for y=0,15 do
    if(x+y==s) then 
     pset(cx+x,cy+y,7)
    elseif(x+y == s-1) then
     pset(cx+x,cy+y,6)
    elseif(x+y<s-1) then
     pset(cx+x,cy+y,
      sget(frx+x,fry+y))
    end
   end
  end
 end
 if(logoanim<=logostop) logoanim+=1
 if(fcount > 35) then
  print("cortex",51,cy+20,9)
  print("carts",53,cy+26,8)
  if(fcount > 85) then
   state = "title"
   music(0)
  end
 end
end

-- copy a random screen of map
-- onto active screen
function rand_map()
 local dx = 0
 local dy = 0
 local scr = flr(rnd(16))
 local sx = 16*(scr%8)
 local sy = 16*flr(scr/8) 
 ruin_map(scr)
-- local sx = 16*flr(rnd(8))
-- local sy = 16*flr(rnd(2)) 
 for x=0,15 do
  for y=0,15 do
   mset(dx+x,dy+y,mget(sx+x,sy+y))
  end
 end
end

-- do incremental damage to
-- a given map screen
ruins = {
[192]=224,
[193]=225,
[208]=240,
[209]=241,

[201]=250,
[202]=250,
[217]=250,
[218]=250,
[233]=250,
[234]=250,
[249]=250,

[204]=203,
[223]=219,
[205]=235,
[206]=251,
[236]=252,
[237]=253,
[238]=254,
[239]=255,

[230]=246,
[247]=246,

[194]=196,
[211]=197,

[214]=232,
[215]=248,
}
 
function ruin_map(scr)
 local sx = 16*(scr%8)
 local sy = 16*flr(scr/8) 
 local m = 0
 for x=0,15 do
  for y=0,15 do
   if(rnd(1) > 0.95) then
    m = mget(sx+x,sy+y)
    if(ruins[m] != nil) then
     mset(sx+x,sy+y,ruins[m])
    end
   end
  end
 end
end

function draw_smoking()
 frc += 0.1
 if(flr(frc)>count(frames)) then
  -- done with smoking anim,
  -- revert to default
  frc = 1
  exc = 1
  enn.s = "stand"
 end
 local fri = frames[flr(frc)]
 local fr = fri*2
 spr(fr,enn.x,enn.y,2,4,enn.left)

 if(fri == 5 or fri == 6) then
  exc += 0.2
  spr(128+exc,enn.x+4+9*enn.lneg,enn.y+10,1,1,enn.left)
 else
  exc = 0
 end
end

function draw_standing()
 if(enn.up) then
  spr(72,enn.x,enn.y,2,4,enn.left)
 else
  spr(2,enn.x,enn.y,2,4,enn.left)
 end
end


function draw_walking()
 enn.dx += 1 
 if(enn.dx == 1) then
  enn.x += 1 * enn.lneg
  wframe = 64
 elseif(enn.dx == 4) then
  enn.x += 3 * enn.lneg
  wframe = 66
 elseif(enn.dx == 6) then
  enn.x += 2 * enn.lneg
  wframe = 68
 elseif(enn.dx == 11) then
  enn.x += 5 * enn.lneg
  wframe = 70
 elseif(enn.dx == 15) then
  enn.s = "stand"
  enn.x += 5 * enn.lneg
  enn.dx = 0
  wframe = 0
 end
 spr(wframe,enn.x,enn.y,2,4,enn.left)
end



function draw_thought()
 for x=1,count(th) do
  local px = 63 - #th[x]*2
  local py = 20 + x*6 - thi
  local pci = flr((thi+30-x*6)/6)
  local pc = 0
  if(pci>=1 and pci<=count(thc)) then
   pc = thc[pci]
  end
  if(pc != 0) then
   print(th[x],px,py,pc)
  end
 end
 thi += 0.25
 if(thi > count(th)*6 + 12) then
  thinking = false
  thi = -18
 end
end


function have_a_thought()
 thinking = true
-- local i=flr(rnd(count(brain)))+1
 th = brain[bri]
 sfx(2,3)
 bri += 1
 if(bri > count(brain)) bri = 1
end

function draw_ground()
 map(0,0,0,0,16,16)
end

function do_input()
 enn.up = false
 if(state == "title") then
  if(btnp()!=0) then
   state = "play"
  end
 elseif(state == "play") then
  do_input_play()
 end
end

function do_input_play() 
 if(btnp(1)) then
  if(enn.s == "stand") then
   if(enn.left) then
    enn.left = false
    enn.lneg = 1
   else
    if(not check_pipe()) then
     enn.s = "walk"
     sfx(1,3)
    end
   end
  end
 elseif(btnp(0)) then
  if(enn.s == "stand") then
   if(not enn.left) then
    enn.left = true
    enn.lneg = -1
   else
    if(not check_pipe()) then
     enn.s = "walk"
     sfx(1,3)
    end
   end
  end
 elseif(btn(3)) then
  if(enn.s == "stand") then
   enn.s = "smoke"
   sfx(0,3)
  end
 elseif(btn(2)) then
  if(enn.s == "stand") then
   enn.up = true 
   if(not thinking) then
    have_a_thought()
   end
  end
 end

end

function check_pipe()
 local pipemx = (enn.x/8) + 2*enn.lneg
 local pipemy = (enn.y/8) + 2
 local m = mget(pipemx,pipemy)
 if(m != 0) then
  if(fget(m,0)) return true
 end
 return false
end

function move()
 local screen = flr((enn.x+8)/128)
 if(screen != 0) then
  -- screen change, lets do
  -- some magic
  rand_map()
  enn.x = (enn.x+8) % 128 - 8
 end 
end

function draw_title()
 spr(160,40,45,6,2)
 
 print("left/right to walk",
  29,90,5)
 print("up to ruminate",
  37,100,5)
 print("down to smoke",
  39,110,5)
end

function shuffle(a)
	local n = count(a)
	for i = 1, n do
		local k = -flr(-rnd(n))
		a[i], a[k] = a[k], a[i]
	end
	return a
end

function _init()
 shuffle(brain)
end

function _update()
 fcount += 1
 do_input()
 move()
end

function _draw()
 cls()
 if(state == "logo") then
  logo()
 elseif(state == "title") then
  draw_title()
 elseif(state == "play") then 
  draw_ground()
  if(enn.s == "smoke") then
   draw_smoking()
  elseif(enn.s == "walk") then
   draw_walking()
  elseif(enn.s == "stand") then
   draw_standing()
  end
 end
 
 if(thinking) then
  draw_thought()
 end

end

bri = 1
brain = {
{"am i...hungry?",
"",
"no, not hungry. i should",
"eat something, but i'm",
"not hungry at all."},

{"when did i eat last?",
"",
"what did i eat last?"},

{"it all tastes of mushroom.",
"",
"",
"of fungus. of moulder.",
"of damp ash."},

{"maybe it'll rain.",
"",
"",
"who am i kidding.",
"",
"it never rains here."},

{"is this it?",
"",
"is this all there is?",
"",
"",
"is this all there ever was?"},

{"mario.",
"",
"some days i can barely bring",
"myself to say his name.",
"",
"some days i can barely",
"remember my own."
},

{"what am i without you?",
"do i exist apart from you?",
"",
"am i just your shadow,",
"wrought as a dark lack",
"on the pavement by the",
"light of a mad, grinning",
"sun?"
},

{"what do i know of plumbing?",
"",
"do i plumb?",
"",
"have i plumbed?"},

{"some part of me longs to",
"grip the cold metal of a",
"crescent wrench, to feel its",
"weight in my hand.",
"",
"for what purpose?",
"",
"",
"i am afraid to know",
"the answer."},

{"mario. where are you,",
"when you are not here?",
"",
"where am i?"},

{"did i wake here?",
"",
"am i awake?",
"",
"",
"am i here?"},

{"'hold a when you restart',",
"the old man said.",
"",
"i never understood him.",
"",
"hold a what?"},

{"i think i dreamt of",
"brooklyn again.",
"",
"or did i dream brooklyn?"},

{"the princess once whispered",
"to me that she could see a",
"darkness in me, there behind",
"my eyes.",
"",
"",
"i wanted to ask,",
"i was afraid to ask:",
"",
"was it darkness, or just the",
"shadow of my brother?"},

{"another castle.",
"",
"always another castle.",
"",
"",
"and yet we always ask", 
"'where is the princess'",
"and never think to ask",
"whence these castles?"},

{"where are the cities,",
"where are the homes?",
"",
"what is a kingdom with",
"no people to protect?"},

{"quis plumbariet",
"ipsos plumbares?"},

{"i should quit smoking."},

{"note to self: get more",
"cigarettes."},

{"so much depends ",
"upon            ",
"",
"a red koopa     ",
"shell           ",
"",
"glazed with boot",
"marks           ",
"",
"beside the green",
"warp pipe.      "},

{"'you're tall', she",
"told me, 'taller than",
"the other one.'",
"",
"'like a shadow,",
"near sundown.'"},

{"bowser had it right,",
"in the end.",
"",
"find a pretty girl,",
"and hole up somewhere",
"away from all this."},

{"if adulthood is getting",
"to choose your own family,",
"what does that make me?"},

{"the sound of their shells",
"cracking beneath his feet.",
"",
"",
"the grin on his face."},

{"mario would always leap on",
"every pipe he saw. so did i,",
"for a while.",
"",
"i asked him why he did it, and",
"he just said, 'adventure!'",
"he never asked me why i did it,",
"and i never told him.",
"",
"never told him i just wanted",
"one of them to lead home."},

{"'eat this mushroom, lou!'",
"'eat this flower!'",
"",
"how could i make sense of my",
"brother's strange appetites?"},

{"i look at a turtle,",
"and i think,",
"i have done you one better.",
"you wear a shell; i have",
"become one."},

{"bowser, you practically",
"handed him that axe.",
"",
"was that an accident,",
"i wonder."},

{"were there birds here, once?"},

{"am i my brother's keeper?",
"",
"am i, a brother, kept?"},

{"why did i ever follow him",
"down that hole?",
"",
"why couldn't i just, finally,",
"let him go?"},

{"'c'mon, lou! what have we",
"got to lose?'",
"",
"i didn't answer. i didn't put",
"up a fight. i just followed,",
"and the truth died on my",
"lips, unspoken:",
"",
"you. what if i lose you,",
"down there."},

{"he'd lost himself down a",
"hole before. it was an old",
"routine for us. but not",
"like this.",
"",
"it was never this bad."},

{"all these pipes, but only",
"we two plumbers. there's no",
"sense of proportionality",
"in this place."},

{"where are the masons? where",
"are the brick-layers?",
"",
"stone and mortar everywhere,",
"but by whose hands?"},

{"i remember, i stood in awe",
"the first time we saw a block",
"hanging in the sky. awe and",
"terror.",
"",
"and he said:",
"'let's break it.'"},

{"who fixed these blocks to",
"the sky? what being, what",
"force, what god could so",
"casually defy gravity and",
"reason?"},

{"my hands are a ruin, the",
"flesh scorched, the knuckles",
"a shattered clubface.",
"",
"i used to have such nimble",
"fingers.",
"",
"i used to paint."},

{"mario, i..."},

{"the aftermath.",
"",
"the after-math.",
"",
"when it no longer",
"adds up."},

{"didn't i used to care?",
"for things? for people?",
"",
"for myself?"},

{"my lungs rise and fall,",
"but am i breathing?",
"",
"or am i just moving",
"cigarette smoke around?"},

{"i feel like i've lost",
"perspective.",
"",
"like the depth has gone",
"out of the world."},

{"'the doctor is in!', he",
"would shout, as he brought",
"both feet down on the dumb,",
"terrified creature, and as",
"its broken form wriggled in",
"dying panic beneath his feet",
"he would wink at me.",
"",
"'scumectomy successful!'"},

{"is it betrayal to think him",
"a monster?",
"",
"is it monstrous to let my",
"cowardice keep me from",
"telling him so?"},

{"to hide the truth in the",
"guise of a query is an act",
"of cowardice, of abdication."},

{"are we brothers? or are we",
"two lives in parallel, two",
"beings damaged in our own",
"ways, failing our respective",
"copies of this world?"},

{"is this brotherhood, this",
"perverse one-upmanship?"}, 

{"was i here,",
"before this moment?"},

{"a darkness falls",
"over the world.",
"",
"",
"or perhaps, instead,",
"the light has gone out",
"of my eyes?"},

{"burning flowers,",
"slavering plants.",
"",
"how could he not see from",
"the first moments the terror",
"of this place?",
"",
"",
"how could he see this",
"as 'fun'?"},

{"where have you gone?",
"",
"where have you left me?"},

{"i remember their crablike",
"scuffling, the sound of",
"labored breathing as they",
"wandered the stonework.",
"",
"stupid. pitiable. mindless.",
"",
"",
"innocent."},

{"bowser, who filled a world",
"with turtles.",
"",
"bowser, who ruled an empty",
"kingdom.",
"",
"were you mad? or were you",
"playing at madness, to hide",
"from the dark heart of this",
"place?"},

{"he would knock them out of",
"the air, with fire or with",
"his feet, destroying their",
"wings, cursing them to the",
"cold ground, for no reason i",
"could see but that they had",
"something he did not.",
"",
"'some day i'm gonna fly',",
"he'd tell me."}, 

{"i feel unmoored from so",
"many things, like a boat",
"drifting away from life's",
"shore."},

{"why did we chase these",
"strange coins, this unknown",
"currency? where could we hope",
"to spend them?"},

{"to see a coin, and take it,",
"and say 'this is mine'",
"without asking whose it was",
"before. did theft exist here",
"before we arrived? did",
"capitalism?",
"",
"were we the vectors of this",
"ruinous infection?"},

{"you took so much, mario.",
"",
"you took without asking, you",
"took without remorse."},

{"i watched my brother",
"wrestle a man from a cloud",
"and throw him to the earth,",
"to his death.",
"",
"how can someone own a cloud?",
"who would die for one?",
"kill for one?"},

{"i dream of impossible vines",
"climbing into the sky, to a",
"place beyond my vision, to a",
"place beyond this cold flat",
"kingdom. but if i were to",
"climb, what would i find?",
"",
"escape, or just more of",
"this place?"},

{"when some of the mushrooms",
"began to speak to us, i knew",
"we had come too far, knew",
"then that it was already",
"too late to undo this."},

{"this is not my world, and",
"yet: this is the world."},

{"how many worlds are there?"},

{"are we meant to be fixed",
"in place, glued tight to one",
"or another globe in the",
"grand orrery?"},

{"these pipes between worlds,",
"these strange wormholes:",
"",
"i cannot say if they are",
"heaven-sent, or a work of",
"devils, or just a strange",
"error in the fabric of a",
"mute, indifferent universe."},

{"i had a dream, i had a",
"nightmare, of swimming,",
"forever, until at last my",
"arms gave out, my time",
"was up.",
"",
"that moment of release, of",
"letting the water take me,",
"was the dream. the nightmare",
"was that it all",
"started again."},

{"these pipes we are so eager",
"to leap down, these vessels",
"to sewers and sewage."},

{"i smoke and never cough,",
"smoke and never get sick.",
"",
"how many years do i have?",
"how many years has it been?"},

{"i blow the smoke out",
"into a small cloud",
"before me.",
"",
"to watch it",
"as it curls",
"in the death-still",
"air?",
"",
"or just to block some",
"small part of this",
"place from my view,",
"for a moment's",
"brief respite?"},

{"i wonder how my sister",
"is doing. i wonder how",
"ma is."},

{"i don't remember lighting",
"this cigarette."},

{"'smoking's a bad habit',",
"she told me. i looked at",
"her, and over at mario and",
"back.",
"",
"'lotta people have",
"bad habits.'"},

{"i asked her, why do you stay",
"with him. she laughed, the",
"kind of laugh so empty its",
"less funny than a sob.",
"",
"'well, he rescued me,",
"didn't he?'"},

{"sometimes she'd just sit",
"with me and watch the goombas",
"scuttle around, the ones",
"that he hadn't stomped yet."},

{"'i'm sorry, mario', they",
"would say. they'd say it and",
"say it and say it again.",
"",
"but it never occurred to him",
"to do likewise."},

{"'we're the masters of our",
"own destinies, lou!'",
"",
"i think he believed it."},

{"has this place changed,",
"or have i?"},

{"i used to know the way from",
"one place to another. or i",
"used to think i did."},

{"what happened to the",
"geometry of the world? is",
"that just one more thing",
"we shattered?"},

{"we, and he. i don't know",
"anymore if there is",
"a difference."},

{"in time, even stone will",
"crumble. i try to tell myself",
"we were just hurrying the",
"process along."},

{"the only other brothers we",
"ever met here were violent",
"monsters, hurling death.",
"",
"were they any worse?"},

{"i watched the bullet as it",
"flew toward me. mario kicked",
"it out of the air at the",
"last moment.",
"",
"",
"i think he expected me",
"to thank him."},

{"i watched his rampage",
"in mute horror.",
"",
"my muteness was horrifying",
"in its own right."},

{"my brother, my mirror.",
"or am i his?"},

{"a cracked mirror. is the",
"crack in the glass, or",
"in the seer?"},

{"i've lost track of time.",
"",
"",
"i've lost track.",
"",
"",
"",
"i've lost."},

{"'never look back.' he said",
"it as a slogan, as a battle",
"cry, and he stood by it.",
""},

{"the day came that i turned,",
"and walked back to where i",
"had come from before, and",
"that was when i learned",
"the truth:",
"",
"there is no going back."},

{"he boulders forward, a",
"force unstoppable, as i",
"stand back and lose myself",
"in the ghosts of this place."},

{"i remember the smell of",
"new york, the small details",
"the way no matter how close",
"you looked there was always",
"more and more. or i think i",
"remember. maybe just another",
"dream."},

{"i used to run.",
"i used to leap.",
"",
"i've grown so tired."},

{"i used to do everything i",
"saw him do, as if that he",
"chose to do it made it",
"righteous, made it good."},

{"i am alone in my thoughts,",
"as i am alone in all things."},

{"how long have i been",
"walking?"},

{"nothing changes.",
"everything has changed."},

{"in the end, she wouldn't",
"even say his name.",
"",
"'him'. i would understand",
"what she meant."},

{"she would look at me and i",
"could feel her taking the",
"measure of my brother in",
"my own face. i prayed she",
"would see more than him,",
"and none of him."},

{"it's a kind of slow death,",
"being an understudy",
"in someone else's life."},

{"i once tried to put a brick",
"back together, after he had",
"cracked it. it was all just",
"dust and rubble, forever",
"irreperable"},

{"i stood by. i stood by."},

{"i looked down at bowser's",
"broken body, and saw in it",
"a map of a broken world."},

{"there are not enough",
"apologies in the world for",
"the things we have done",
"in this place."},

{"he watched a turtle on its",
"back, beating its legs and",
"trying to turn itself over.",
"",
"of course.",
"",
"",
"of course he didn't help it."},
 
{"do i live?",
"did i live?",
"have i lived?"},

{"i am a stranger,",
"in a strange land."},

{"i am afraid i'll never",
"leave this place. and afraid",
"that i might not have the",
"strength to, if i knew how."},

}--end brain