-- mine! - a cute minesweeper 
-- clone for the pico-8
-- by jakub wasilewski
-- license: cc-by-nc-sa

-- the size of the board we'll
-- be playing on
board_w=16
board_h=15

-- sprites
s_block = 1
s_empty = 2
s_mine = 3
s_flag = 6

-- text colors (for # of mines
text_colors = {3,4,2,0,0,0,0,0}

-- a table of all offsets to
-- a field's neighbours
directions = {
 {x=-1,y=-1},{x=-1,y=0},
 {x=-1,y=1},{x=0,y=-1},
 {x=0,y=1},{x=1,y=-1},
 {x=1,y=0},{x=1,y=1}
}

-- color map for explosion
flash_map = {
 {7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7},
 {6,6,6,6,7,6,7,7,7,7,7,7,7,7,7,7},
 {5,13,8,11,9,6,7,7,14,10,7,11,12,12,15,7},
 {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
}

-----------------------------
-- counters
-----------------------------
counters={}
function start_ctr(name,v)
 counters[name]=v
end
function ctr(name)
 return counters[name]
end
function update_ctrs()
 for n,v in pairs(counters) do
  counters[n]-=1
  if (counters[n]<0) then
   counters[n]=nil
  end
 end
end

-----------------------------
-- various helpers
-----------------------------

function clamp(n,low,high)
 if (n<low) return low
 if (n>high) return high
 return n
end

function printc(t,cx,y,clr)
 local x = cx-(#t)*2
 print(t,x,y,clr)
end

-- gets a random field that
-- fulfils a condition
function random_field(b,cond)
 local x = flr(rnd(board_w))
 local y = flr(rnd(board_h))
 while not cond(b[x][y]) do
  x=flr(rnd(board_w))
  y=flr(rnd(board_h))
 end
 return {x=x,y=y}
end

-- gets a field at coordinates
-- or nil if out of bounds
function safe_get(b,x,y)
 if b[x] and b[x][y] then
 	return b[x][y]
 else
  return nil
 end
end

-- gets all neighbours of the
-- field at x,y
function get_neighbours(b,x,y)
 local ns={}
 for d in all(directions) do
  local n=safe_get(b,
   x+d.x,y+d.y)
  if (n) add(ns, n)
 end
 return ns
end

-----------------------------
-- game logic
-----------------------------

function start_game(mine_count)
 board = make_board(mine_count)
 player = {
  x=flr(board_w/2),
  y=flr(board_h/2)
 }
 game = {
  blown_up=false,
  flags=0,
  mines_found=0,
  mines_needed=mine_count,
  seconds=0
 }
 make_first_visit(board)
 state="game"
end

function status(g)
 if g.blown_up then
   return "lost"
 elseif g.mines_found==g.mines_needed
  and g.flags==g.mines_needed then
   return "won"
 else
   return "playing"
 end 
end

function make_board(mine_cnt)
 -- initialize empty board
 local b = {}
	for x = 0,board_w-1 do
	 b[x] = {}
	 for y = 0,board_h-1 do
	  local f = {}
	  f.mine = false
	  f.visited = false
	  f.flagged = false
	  b[x][y] = f
	 end
	end 
	-- sprinkle mines
	for m = 1,mine_cnt do
		local r = random_field(b,
		 function(field)
		   return not field.mine
		 end
		)
	 b[r.x][r.y].mine = true
	end
	-- calculate how many of each
	-- field's neighbours are
	-- mines
	for x = 0,board_w-1 do
	 for y = 0,board_h-1 do
   local neighbours =
    get_neighbours(b,x,y)
	  -- count mines among them
	  local total = 0
	  for n in all(neighbours) do
	   if (n.mine) total+=1	   
	  end
	  -- store for later
	  b[x][y].mines = total
	 end
	end
	
	-- done!
	return b
end

function make_first_visit(b)
 local r = random_field(b,
  function(f)
   return f.mines==0 and
    not f.mine
  end
 )
 visit(nil,b,r.x,r.y)
end

function visit(g,b,x,y)
 local f=safe_get(b,x,y)
 -- not visitable?
 local skip = (not f) or
  f.visited or f.flagged
 if (skip) return 
 -- safe?
 if not f.mine then
  f.visited=true
  -- when visiting fields with
  -- 0 mine neighbours, we go
  -- recursively visit them
  if f.mines==0 then   
   for d in all(directions) do
    visit(p,b,x+d.x,y+d.y)
   end
   return 1
  else
   return 2
  end
 end
 -- not safe?
 if f.mine then
  blow_up(g)
  return nil
 end
end

function flag(g,b,x,y)
 local f=b[x][y]
 if (f.visited) return
 f.flagged = not f.flagged
 if f.flagged then
  g.flags+=1
  if (f.mine) g.mines_found+=1
  sfx(3)
  if status(g)=="won" then
	  win(g)
	 end
 else
  g.flags-=1
  if (f.mine) g.mines_found-=1
  sfx(4)
 end 
end

function blow_up(g)
 sfx(0)
 start_ctr("shake",20)
 start_ctr("flash",8)
 g.blown_up=true
end

function win(g)
 start_ctr("ditty",6)
 start_ctr("boardwipe",32)
end

------------------------------
-- input
------------------------------
delay=0
prev_input=0
function parse_input()
 -- movement
 -- (only move every 3rd frame)
 local dx=0
 local dy=0
 if delay==0 then
   if (btn(0)) dx-=1
   if (btn(1)) dx+=1
   if (btn(2)) dy-=1
   if (btn(3)) dy+=1
 end
 
 -- actions
 local action=nil
 if prev_input<16 then
  if (btn(4)) action="first"
  if (btn(5)) action="second"
 end
 
 -- handle repeating
 if btn()~=0 and delay==0 then
  if prev_input~=0 then
   delay = 2
  else
   delay = 7
  end
 end
 if (btn()==0) delay=0
 delay = clamp(delay-1,0,8)
 prev_input = btn()

 -- return info
 return {dx=dx,dy=dy,
  action=action}
end

-----------------------------
-- game main loop
-----------------------------

function update_game()
 local st=status(game)
 local inp = parse_input()
  
 -- only quitting possible?
 if (st~="playing") then
  if (inp.action) state="menu"
  return
 end
  
 -- nope, still playing
 local p = player
 p.x = clamp(p.x+inp.dx, 
  0, board_w-1)
 p.y = clamp(p.y+inp.dy,
  0, board_h-1)
  
 if inp.action == "first" then
  local snd=
   visit(game,board,p.x,p.y)
  if (snd) sfx(snd)
 end
 if inp.action == "second" then
  flag(game,board,p.x,p.y)
 end
 
 -- count time
 if (t%30==0) game.seconds+=1
end

-----------------------------
-- drawing the menu
-----------------------------

difficulties={
 {n="easy",m=24},
 {n="normal",m=48},
 {n="hard",m=64},
 {n="unfair",m=96}
}
diff=2

function draw_menu()
 cls()

 --background--
 for f in all(floaters) do
  map(8,0,f.x,f.y,2,2)
 end
 
 --draw logo-- 
 map(0,0,36,15,8,4)
 
 --difficulty chooser
 local d = difficulties[diff]
 printc("difficulty:",
  64,64,13)
 printc(d.n,64,72,15) 
 
 local offset
 offset=(t%16<8)and 0 or 1
 if (diff > 1) spr(16,27-offset,72)
 if (diff < 4) spr(17,96+offset,72)
 
 --intro info
 printc("z to explore, x to flag mines",
  64,105,5)
 printc("pick your difficulty",
  64,111,5)
 printc("then press z or x to start",
  64,117,5)
end

floaters={}
for i=-1,15 do
 add(floaters,{
  x=i*8,y=rnd(140),
  v=rnd(0.5)+0.5
 })
end
function update_floaters()
 for f in all(floaters) do
  if f.y<-16 then
   f.y = 128+rnd(32)
   f.v = rnd(0.5)+0.5
  end
  f.y -= f.v
 end
end

function update_menu()
 update_floaters()
 
 local inp = parse_input()

 if inp.action then
  local d=difficulties[diff]
  start_game(d.m)
 end 
 if inp.dx~=0 then
  diff=clamp(diff+inp.dx,1,4)   
  sfx(2)
 end
end

-----------------------------
-- drawing the game
-----------------------------
function draw_board(g,b)
 local state = status(g) 

 local bw=32 
 if state=="won" then
  bw=ctr("boardwipe") or 0
 end
 
 for x = 0,board_w-1 do
  for y = 0,board_h-1 do  
   local f=b[x][y]
   -- choose the right sprite
   local s
   if state=="lost" and 
    f.mine then
     s=s_mine
   elseif f.visited then
     s=s_empty
   elseif f.flagged then
     s=s_flag
   else
     s=s_block
   end
   
   -- bw implements board wipe
   if x+y<bw then
    --draw tile
    spr(s,x*8,y*8)   
    --print mine number text
    if f.visited and 
     f.mines>0 then
      local clr =
       text_colors[f.mines]    
      print(f.mines,
       x*8+2,y*8+2,clr)
    end
    --draw flag
    if s==s_flag then     
     local frame=32+
      flr((t+x*3+y*2)%12/3)
     spr(frame,x*8-1,y*8-1)
    end
   end 
  end
 end
end

function draw_player(g,p)
 local s = status(g)
 if (s != "playing") return

 local bx=p.x*8
 local by=p.y*8
 spr(21,bx-2,by-2)
 spr(22,bx+2,by-2)
 spr(37,bx-2,by+2)
 spr(38,bx+2,by+2)
end

function draw_hud(g)
 local st = status(g)
 local text
 local clr
 
 if st=="playing" then
 	clr=5
 	text="mines: " ..
 	 g.flags .. "/" ..
 	 g.mines_needed
 elseif st=="lost" then
  clr=8
  text="kablam!"
 elseif st=="won" then
  clr=3
  text="you win!"
 end
 
 local x = 64 - (#text)*2
 rectfill(35,121,92,127,clr)
 rectfill(34,122,93,126,clr)
 print(text,x,122,15)
end

function draw_win()
 local minutes =
  flr(game.seconds/60)
 local secs = game.seconds -
  minutes*60
 local secstr = (secs<10) and
  "0"..secs or secs
 local tstr =
  minutes..":"..secstr
  
 map(11,0,64-8,32,2,2)
 printc("you won!",64,56,15)
 printc("your time:",64,72,13)
 printc(tstr,64,80,12)
end

function draw_game()
 cls()
 
 -- explosion flash
 local fl = ctr("flash")
 if fl then
  fl=flr(clamp((8-fl)/2,0,3))
  local clr = flash_map[fl+1]
  for c=0,15 do
   pal(c,clr[c+1],1)
  end
 end
 
 -- shaking camera
 local shake = ctr("shake")
 if shake then
  local dx = sin(shake*0.2)*
   shake*0.2
  local dy = cos(shake*0.3)*
   shake*0.2
  camera(dx,dy)
 end
 
 -- endgame ditty
 if ctr("ditty")==0 then
  music(0)
 end
 
 -- game interface
 if status(game)=="won" then
  draw_win(game)
  draw_board(game,board)
 else
  draw_board(game,board)
  draw_player(game,player)
  draw_hud(game)
 end
end

-----------------------------
-- main functions
-----------------------------
t=0
function _update()
 t+=1
 update_ctrs()
 
 if state=="game" then
  update_game()
 else
  update_menu()
 end
end

function _draw()
 camera(0,0)
 pal()
	palt(0,false)
	palt(14,true)
 if state=="game" then
  draw_game()
 else
  draw_menu()
 end
end

function _init()
 state="menu"
end
