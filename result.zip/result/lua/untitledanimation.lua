string = " "
lib = { "where are you going?","where can i take you?","what is your destination?","ill just drive until you tell me where we are going...", "youre not the talkative type, are you?", "i could use someone to talk to...", "sometimes life feels horribly awful.", "i could just... let go of the wheel and see what happens, you know?", "id rather not tell you my name, sorry.", "you look like you could use some sleep.", "there is nothing out here...", "youre the silent type, yeah?", "you are allright with me.", "you like music? too bad the radio is broken...", "this night will never end, seems like.", "feel like im talking to myself.", "lets... lets just keep driving.", "where you from?", "i was born near here.","too bad you cant drive... i can barely keep my eyes open.", "you like cats? no?", "whatever...", "hmm...", "so...", "...nevermind.", "...forgot what i was saying.", "ever get that feeling... youre not quite all there? spaced out sort of.", "wish there was something to eat.", "do you get car sick?", "you look a little pale.", "hey, do i know you from somwhere?", "did you hear that sound just then? no? ...gotta get that engine checked.", "isnt the moon supposed to be up?", "i dont really know that many people...", "i hope we dont run out of gas...", "isnt the sun supposed to rise soon?", "you... you eh have a special someone in your life?", "i feel like im just repeating myself. am i?", "my memory is really bad, sorry.", "did you tell me your name?" }
counter = 0
counter2 = 0
counter3 = 0
counter4 = 0
animcounter = 0
a = 0
b = 0
c = 0
t = 0
crv = 0
treewbl = 0
wbldir = 1
jitter = 0
crnt = " "

function draw_road (hrz, b)
 b=flr(b+a)
	sspr(16, 32-flr(c), 32, b, 64+crv-b/2, hrz+b/2, b, b/1.5)
	sspr(16, 32-flr(c), 32, b, 64-b+crv-b/2, hrz+b/2, b, b/1.5, 1)
end

function draw_trees (hrz, b)
 b=flr(b)
	sspr(64-t, 0, 32, 32, 64+crv+b-b/3, hrz-b/2+5, b, b-10)
	sspr(48+t, 0, 32, 32, 64+crv-b*2+b/3, hrz-b/2+5, b, b-10)
	end

function randomizer (t)
 for i = count(t), 2, -1 do
    local r = flr(rnd(i))+1
    t[i], t[r] = t[r], t[i]
	end
end

function state_animation ()

  --sky
  sspr(0,0,16,16,0+crv/2,10,128,31)

  --render tree
  for x=80,1,-16 do
    draw_trees (42,x)
    if t > 16 then t=0 end
    t +=rnd(0.1)
  end

  --end road
  rectfill(0+crv,100,128,128,1)

  --render road
  for x=80,2,-4 do
    crv = (crv+sin(c)*20+jitter)/x
    draw_road (40, x)
    if c > 32 then c=0 end
    c+=0.1
  end
  --rectfill(0,0,128,128,9)

  --car interior
  jitter = rnd(2)
  bumpy = sin(rnd(1))
  sspr(64,32,64,64,0+jitter-5,0+bumpy,140,150)
  --tree
  if treewbl > 3 then
    wbldir = -rnd(jitter/2+1)
  elseif treewbl < 0 then
    wbldir = rnd(jitter/2+1)
  end
  treewbl += wbldir
  line(18+jitter,37+bumpy,17+treewbl,45,1)
  sspr(0,16,16,16,10+treewbl,45, 32-rnd(jitter*2),32)
end

function eyelid (direction, length)
  if direction == 1 then
    rectfill(0,0,128,64-length,0)
    rectfill(0,64+length,128,128,0)
  elseif direction == 0 then
    rectfill(0,0,128,0-length,0)
    rectfill(0,128+length,128,128,0)
  end
end

function textbox ()
  --text box
  if counter2 < #string + 5 then
    if #string < 28 then
      rectfill(10,100,10+4*#string,106,5)
    else
      rectfill(10,100,118,112,5)
    end

    if counter < 27 then
     print(sub(string,0,counter),11,101,0)
    elseif counter > 54 then
     print(sub(string,28,54),11,101,0)
     print(sub(string,55,counter),11,107,0)
    elseif counter > 81 then
      print(sub(string,54,81),11,101,0)
      print(sub(string,82,counter),11,107,0)
    else
     print(sub(string,0,27),11,101,0)
     print(sub(string,28,counter),11,107,0)
    end
  end
end

function _init()
	palt(0,false)
	palt(15,true)
	randomizer(lib)
	music(0,5000,1+2)
end

function _update()
  if counter < #string then
  counter += flr(rnd(1.5))
  else
    counter2 += flr(rnd(1.5))
  end


 total = #string + 30 + rnd(60)
 rlib = 1

 if counter2 >= total then
 		string = lib[rlib]
 		add(lib, string)
 		del(lib, string)
 		counter = 0
    counter2 = 0
  end

  --crosstalk
  if animcounter < 300 then
    if counter < #string then
       if counter ~= counter3 then
         crnt = sub(string, counter)
         if crnt == " " then
           sfx(-1)
           counter3 = counter
         else
           sfx(0)
           counter3 = counter
         end
       end
    end
  end

end

function _draw()
  cls()

  if animcounter < 300 then
    state_animation()
    eyelid(1,counter4)
    if animcounter > 8 then
      counter4 += 0.5
    end
    if animcounter > 4 then
    textbox()
    end
  else
    state_animation()
    eyelid(0,counter4)
    counter4 -= 0.5
  end
  if counter4 > 64 then
    counter4 = 64
  end
  if animcounter < 4 then
    print("animation by ossian boren",0,64,6)
    counter = 0
  end
  animcounter += 0.05
end