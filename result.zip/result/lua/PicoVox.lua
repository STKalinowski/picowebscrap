
build_version = "A2"

function build_num_table(s,zero)
	local t,offset={},0
	if(zero)offset=-1
	for i,row_string in pairs(split(s,"|",false)) do
		t[i+offset]=split(row_string,",",true)
	end
	return t
end

-------------------------rgb system

bayer=build_num_table([[
0,32,8,40,2,34,10,42|
48,16,56,24,50,18,58,26|
12,44,4,36,14,46,6,38|
60,28,52,20,62,30,54,22|
3,35,11,43,1,33,9,41|
51,19,59,27,49,17,57,25|
15,47,7,39,13,45,5,37|
63,31,55,23,61,29,53,21
]])


pico_palette=build_num_table([[
0x.00,0x.00,0x.00|
0x.1d,0x.2b,0x.53|
0x.7e,0x.25,0x.53|
0x.00,0x.87,0x.51|
0x.ab,0x.52,0x.36|
0x.5f,0x.57,0x.4f|
0x.c2,0x.c3,0x.c7|
0x.ff,0x.f1,0x.e8|
0x.ff,0x.00,0x.4d|
0x.ff,0x.a3,0x.00|
0x.ff,0x.ec,0x.27|
0x.00,0x.e4,0x.36|
0x.29,0x.ad,0x.ff|
0x.83,0x.76,0x.9c|
0x.ff,0x.77,0x.a8|
0x.ff,0x.cc,0x.aa
]],true)




function get_ordered_pixel(x,y,c)

	local closest_i,dist=0,100
	local k_offset= shr(bayer[x%8+1][y%8+1],7)-.55 -- ordered dither array with an offset
	
	local red_target,green_target,blue_target =	 	mid(sqrt(c[1]+k_offset)*1.27 ,0,1),mid(sqrt(c[2]+k_offset)*1.27 ,0,1), mid(sqrt(c[3]+k_offset)*1.27 ,0,1)
	for i, palette_color in pairs(pico_palette) do
		local d = color_compare({red_target,green_target,blue_target},palette_color)
		if(d<dist)then closest_i=i dist=d end
	end
	return closest_i
end

function color_compare(rgb1,rgb2)

	local luma1,luma2 = rgb1[1]*.299+rgb1[2]*.587+rgb1[3]*.114, rgb2[1]*.299+rgb2[2]*.587+rgb2[3]*.114
	local lumadiff=luma1-luma2
	local diff = vec3_sub(rgb1,rgb2)
	return (diff[1]*diff[1]*0.299 + diff[2]*diff[2]*.587 + diff[3]*diff[3]*.114)*.75+lumadiff*lumadiff*.25
end	

cur_error_row={}
next_error_row={}
for i=-1,128 do cur_error_row[i]={0,0,0} next_error_row[i]={0,0,0} end

function correct_gamma(c)
	return {mid(sqrt(c[1]) ,0,1),mid(sqrt(c[2]) ,0,1), mid(sqrt(c[3]) ,0,1)}
end

function get_fs_pixel(x,y,c)
	y=flr(y)
	local dir=1
	local start=0
	--if(x%2==0)dir=-1 start=127
	

	--c=vec3_add(c,cur_error_row[x])
	
	local closest_i,dist=0,100
	local target =	correct_gamma(vec3_add(c,cur_error_row[y]))-- 	correct_gamma(c)
	for i, palette_color in pairs(pico_palette) do
		local d = color_compare(target,correct_gamma(palette_color))--color_compare(target,palette_color)
		if(d<dist)then closest_i=i dist=d end
	end
	
	local error=vec3_sub(target,pico_palette[closest_i])
	cur_error_row[y+dir] = vec3_add(  cur_error_row[y+dir]    ,vec3_scale(error,7/15))
	next_error_row[y-dir]=vec3_add(   next_error_row[y-dir]   ,vec3_scale(error,3/15))
	next_error_row[y]  =  vec3_add( next_error_row[y]     ,vec3_scale(error,5/15))
	next_error_row[y+dir]=vec3_add(   next_error_row[y+dir]   ,vec3_scale(error,1/15))
	--
	if(y==127)then
		cur_error_row,next_error_row=next_error_row,cur_error_row
		for i=-1,128 do next_error_row[i]={0,0,0} end
	end
	return closest_i
end

function get_closest_pixel(x,y,c)
	local closest_i,dist=0,100
	for i, palette_color in pairs(pico_palette) do
		local d = color_compare(c,palette_color)
		if(d<dist)then closest_i=i dist=d end
	end
	return closest_i
end

 --get_ordered_pixel = get_closest_pixel
 
--------------------------misc utility
function normalize(x,y,z)
	local length=1/sqrt(x*x+y*y+z*z)
	return x*length,y*length,z*length
end


function vec3_dot(a,b)
	return a[1]*b[1]+a[2]*b[2]+a[3]*b[3]
end

function vec3_unit(v)
	local x1,y1,z1=v[1],v[2],v[3]
	local inv_dist=1/sqrt(x1*x1+y1*y1+z1*z1)
	return {x1*inv_dist,y1*inv_dist,z1*inv_dist}
end

function vec3_length(v)
	local x1=shr(v[1],2)
	local y1=shr(v[2],2)
	local z1=shr(v[3],2)
	return sqrt(x1*x1+y1*y1+z1*z1)
end

--function vec3_abs(v)
--	return {abs(v[1]),abs(v[2]),abs(v[3])}
--end
--
--function vec3_max(v,d)
--	return {max(v[1],d),max(v[2],d),max(v[3],3)}
--
--end
--
--function vec3_flr(a)
--	return {flr(a[1]),flr(a[2]),flr(a[3])}
--end

--function vec3_flip(a)
--	return {-a[1],-a[2],-a[3]}
--end

function vec3_sub(a,b)
	return {a[1]-b[1],a[2]-b[2],a[3]-b[3]}
end
function vec3_add(a,b)
	return {a[1]+b[1],a[2]+b[2],a[3]+b[3]}
end
function vec3_scale(a,s)
	return {a[1]*s,a[2]*s,a[3]*s}
end

function vec3_div(a,s)
	return {a[1]/s,a[2]/s,a[3]/s}
end

function vec3_mult(a,b)
	return {a[1]*b[1],a[2]*b[2],a[3]*b[3]}
end


function pause(t)
	for i=1,t do
		flip()
	end
end

function freeze()
	while(true) do flip() end
end

function center_print(s,x,y,c)
	s=s..""
	print(s,x-#s*2,y,c)
end

function right_print(s,x,y,c)
	s=s..""
	print(s,x-#s*4,y,c)
end

function vertical_print(s,x,y,c)
	s=s.."" -- force a number to a string
	while(#s>=1)do
		local the_char=sub(s,1,1)
		s=sub(s,2)
		print(the_char,x,y,c)
		y+=6
	end
	
end

----------------------------------matrix functions----------------------


function create_identity()
	--return{{1,0,0},{0,1,0},{0,0,1}}
	return build_num_table[[1,0,0|0,1,0|0,0,1]]
end




function create_x_rotate(a)
	return{{1,0,0},
		   {0,cos(a),-sin(a)},
		   {0,sin(a),cos(a)},
		   }
end

function create_y_rotate(a)
	return{{cos(a),0,sin(a)},
	       {0,1,0},
		   {-sin(a),0,cos(a)},
   
		   }
end

function create_z_rotate(a)
	return{{cos(a),-sin(a),0},
		   {sin(a),cos(a),0},
		   {0,0,1}}
end


function matrix_multiply(src1,src2)

	local new_m={{},{},{}}
	for i=1,3 do
		for j=1,3 do
			local sum=0
			for k=1,3 do
				sum+=src1[i][k]*src2[k][j]
			end
			new_m[i][j]=sum
		end
	end
	return new_m

end

function transform_vector(v,m)

	--trasnform vector is used pretty often, so don't shave tokens
	return (v[1]*m[1][1]+v[2]*m[2][1]+v[3]*m[3][1]),
		   (v[1]*m[1][2]+v[2]*m[2][2]+v[3]*m[3][2]),
		   (v[1]*m[1][3]+v[2]*m[2][3]+v[3]*m[3][3])

end

function vec3_transform(v,m)
	--some functions like the vector in matrix form...
	
	return {(v[1]*m[1][1]+v[2]*m[2][1]+v[3]*m[3][1]),
		   (v[1]*m[1][2]+v[2]*m[2][2]+v[3]*m[3][2] ),
		   (v[1]*m[1][3]+v[2]*m[2][3]+v[3]*m[3][3] )}
end

dat= split("2,2,3,3,3,2,2,3,1,3,3,2,1,2,3,3,1,2,2,3,1,3,2,2,2,3,3,1,2,1,3,3,1,1,3,3,1,3,3,1,2,1,1,3,1,1,2,3,2,1,3,2,3,1,2,2,3,1,1,2,1,1,3,2,1,1,2,2,2,1,1,2")
function inverse_matrix(m)
	--I'm not feeling clever enough to reduce the token count here.
	

	local invdet = 1/(m[1][ 1] * (m[2][ 2] * m[3][ 3] - m[3][ 2] * m[2][ 3]) -
					  m[1][ 2] * (m[2][ 1] * m[3][ 3] - m[2][ 3] * m[3][ 1]) +
				      m[1][ 3] * (m[2][ 1] * m[3][ 2] - m[2][ 2] * m[3][ 1]))
	
	
	local k=1
	local new_m={{},{},{}}
	for i=1,3 do
		for j=1,3 do
			new_m[i][j]=(m[ dat[k] ][dat[k+1]]*m[ dat[k+2] ][dat[k+3]]-m[ dat[k+4] ][dat[k+5]]*m[ dat[k+6] ][dat[k+7]])*invdet
			k+=8
		end
	end
	return new_m

end

----------------------------------raymarching functions---------------------

k_direction_light=1
k_point_light=2
k_ambient_light=2
light_type=k_point_light


light_list={}
function new_light(light_type,x,y,z,rgb)
	if(light_type==k_direction_light) x,y,z=normalize(x,y,z)
	if(light_type==k_ambient_light)rgb=x

	return add(light_list,{light_type=light_type,x=x,y=y,z=z,rgb=rgb})
end

function update_light(light)
	light.x,light.y,light.z=normalize(light.x,light.y,light.z)
end

---------------------------------------------------------------------------------

function mix(d1,d2,h)
	return(d1*(1-h)+d2*h)
end


function update_camera()
	if(cam_zoom>.25)cam_zoom=.25
	
	cam_matrix=matrix_multiply(create_x_rotate(cam_ax),create_y_rotate(cam_ay))

	cam_h = vec3_transform({1,0,0},cam_matrix)
	cam_v = vec3_transform({0,1,0},cam_matrix)
	cam_d = vec3_transform({0,0,1},cam_matrix)
	

end

function init_scene()

	cam_x=0
	cam_y=0
	cam_z=0
	k_cam_height=30
	cam_ax=-30/360--30/360
	cam_ay=-.125
	cam_az=0
	cam_target={k_width/2,k_height-2,k_depth/2}
	cam_zoom=1/8
	update_camera()
	draw_cube() -- need to do this before we can use the nice draw function
	--spot=new_light(k_direction_light,.2,-1,-.75,{1,1,1})
	light_x,light_y,light_z=normalize(.2,-1,-.75)
	 init_vox_scene()
end


k_width = 16
k_height = 16
k_depth = 16
function init_vox_scene()

	vox_scene={}
	for i=0,k_width-1 do
		vox_scene[i]={}
		for j=0,k_height-1 do
			vox_scene[i][j]={}
			for k=0,k_depth-1 do
				local d1=i-k_width/2
				local d2=j-k_height/2
				local d3=k-k_depth/2
	
				vox_scene[i][j][k]=0
				
				--if( sqrt(d1*d1+d2*d2+d3*d3)<6) vox_scene[i][j][k]= 12

			    if(j==k_height-1)vox_scene[i][j][k]=7
			end
		end
	end



	--save_scene()

end

function clear_vox()
	vox_scene={}
	for i=0,k_width-1 do
		vox_scene[i]={}
		for j=0,k_height-1 do
			vox_scene[i][j]={}
			for k=0,k_depth-1 do
				vox_scene[i][j][k]=0
			end
		end
	end
end

code_string="in the beginning the universe was created. this has made a lot of people very angry and been widely regarded as a bad move"

function save_scene()
	local temp_zoom=cam_zoom
	
	flip()
	cls(0)
	print("pICOvOX "..build_version,1,120,7)
	right_print("eLECTRIC gRYPHON",127,120,7)
	--print("vERSION",1,80,7)
	--center_print(build_version,15,88,7)
	--
	--
	--vertical_print("eLECTRIC",106,40,7)
	--vertical_print("gRYPHON",114,43,7)

	
	--cam_zoom*=.5
	--update_camera()
	--iso_render(31,32,31+64,31+64)
	--rect(31,32,31+64,31+64,7)
	--
	--flip()
--	--freeze()
	--cam_zoom=temp_zoom
	
	
	--freeze()
	local v=0
	local mem_loc=0x6000
	
	poke(mem_loc,k_width)	mem_loc+=1
	poke(mem_loc,k_height)	mem_loc+=1
	poke(mem_loc,k_depth)	mem_loc+=1
	
	
	local count=0
	for k=0,k_depth-1 do
		for j=0,k_height-1 do
			for i=0,k_width-1 do
				v=vox_scene[i][j][k]
				v+=ord(sub(code_string,count%(#code_string)+1,count%(#code_string)+1))
				v=v%128
				--v=v+flr(rnd(128))
				--v=v%256
					--if(rnd(2)>1)v+=127
				poke(mem_loc,v)
				mem_loc+=1
				--if(mem_loc==0x6000+2048) mem_loc+=4096
				count+=1
			end
		end
	end
	extcmd("screen",1) 
	--freeze()
end


k_user_mem_loc = 0x4300
function check_import()
	local c=0
	local count=0
	srand(12)

	if( stat(121) ) then
		local img_width=read_serial_byte(true)
		local img_height=read_serial_byte(true)
		
		--cls()
		--print(img_width )
		--print(img_height)
		
		local x=0
		local y=0
		local z=0
		
		flip()
		for j=0,127 do
			for i=0,127 do			
				local v=read_serial_byte()
				pset(i,j,v)
			end
		end
		mem_loc=0x6000
		
		k_width =peek(mem_loc)	mem_loc+=1
		k_height = peek(mem_loc)	mem_loc+=1
		k_depth = peek(mem_loc)	mem_loc+=1
		
		for k=0,k_depth-1 do
			for j=0,k_height-1 do
				for i=0,k_width-1 do
				
					--if(rnd(2)>1)v+=127
				v=peek(mem_loc)
				v-=ord(sub(code_string,count%(#code_string)+1,count%(#code_string)+1))
				v=v%128
				--v=v-flr(rnd(128))
				--v=v%256
				vox_scene[i][j][k]=v
				mem_loc+=1
				--if(mem_loc==0x6000+2048) mem_loc+=4096
				count+=1
				end
			end
		end
		
		
		
		clear_serial()
		needs_redraw=true
		
		
	end
	
end

--trashes first 1-2 bytes of user memory area
function read_serial_byte(word)
	--if(not stat(121)) return false
	if(word!=nil)then
		serial(0x802, k_user_mem_loc, 2)
		return peek2(k_user_mem_loc)
	else
		serial(0x802, k_user_mem_loc, 1)
		return peek(k_user_mem_loc)		
	end
end

function clear_serial()
	while(stat(121))do
		 read_serial_byte()
	end
end

------------------------------------------




function vox_dda(px,py,pz,vx,vy,vz,max_depth)


	--for i=0,10 do
	--	for j=0,10 do
	--		rect(i*16,j*16,(i+1)*16,(j+1)*16,3)
	--		
	--	end
	--end
	
	

	local dir_x=1
	local dir_y=1
	local dir_z=1
	local itx,ity,itz
	if(vx<0)then  itx = band(px,0x.ffff)/abs(vx) dir_x=-1 else itx = (1-band(px,0x.ffff))/abs(vx) end
	if(vy<0)then  ity = band(py,0x.ffff)/abs(vy) dir_y=-1 else ity = (1-band(py,0x.ffff))/abs(vy) end
	if(vz<0)then  itz = band(pz,0x.ffff)/abs(vz) dir_z=-1 else itz = (1-band(pz,0x.ffff))/abs(vz) end

	
	local stx = 1/abs(vx)
	local sty = 1/abs(vy)
	local stz = 1/abs(vz)
	local tx=itx
	local ty=ity
	local tz=itz
	
	local cell_x=flr(px)
	local cell_y=flr(py)
	local cell_z=flr(pz)
	
	local cur_cell=0
	if(cell_x>=0 and cell_y>=0 and cell_z>=0 and cell_x<k_width and cell_y<k_height and cell_z<k_depth)then
	 cur_cell=vox_scene[cell_x][cell_y][cell_z]
	end

	
	local max_depth=max_depth or 80
	local done=false
	local depth=0
	
	local hit=false
	
	local side=1
	

	
	--rect(cell_x*16+1,cell_y*16+1,(cell_x+1)*16-1,(cell_y+1)*16-1,11)
	--		line(px*16,py*16,(px+vx*10)*16,(py+vy*10)*16,12)
	 
	
	--local sx=abs(vy/vx )
	--local sy=abs(vx/vy )
	--
	--step_x=0
	--step_y=0
	
		local n
		local t=0
	
	while(not done)do
		--rect(cell_x*16+1,cell_y*16+1,(cell_x+1)*16-1,(cell_y+1)*16-1,11)
		

		
		if(tx<ty)then
		
			if(tx<tz)then
				tx+=stx
				side=1
				cell_x+=dir_x
			else
				tz+=stz
				side=2
				cell_z+=dir_z
			end

			
		else
			
			if(ty<tz)then
				ty+=sty
				side=3
				cell_y+=dir_y
			else
				tz+=stz
				cell_z+=dir_z
				side=2
			end

			
		end
		
		
		
		if(cell_x>=0 and cell_y>=0 and cell_z>=0 and cell_x<k_width and cell_y<k_height and cell_z<k_depth)then
		local v=vox_scene[cell_x][cell_y][cell_z]
		if(v!=0 and v!=cur_cell)then
			--rect(cell_x*16+1,cell_y*16+1,(cell_x+1)*16-1,(cell_y+1)*16-1,8)
			--tx-=stx --go back to the previous intersection point
			--ty-=sty --go back to the previous intersection point
			--tz-=stz --go back to the previous intersection point
			
			
			
			
			if(side==1)then
				t=tx-stx
				if(vx<0) then
					n={1,0,0}
				else
					n={-1,0,0}
				end
			
			elseif(side==2)then
				t=tz-stz
				if(vz<0) then
					n={0,0,1}
				else
					n={0,0,-1}
				end
			elseif(side==3)then
				t=ty-sty
				if(vy<0) then
					n={0,1,0}
						else
					n={0,-1,0}
				end
			end
			
			return v,n,{px+t*vx,py+t*vy,pz+t*vz},t
			
			end
		end
	
		
	
		depth+=1
		if(depth>=max_depth)return false,n,{px+t*vx,py+t*vy,pz+t*vz},t
	end
	

	
	
end

--init_vox_scene()
--function test_dda()
--	
--	
--	
--	
--
--	
--	local a=-.05
--	
--	while(true)do
--	a+=.01
--	cls()
--	local vx=cos(a)
--	local vy=sin(a)
--	
--	vox_dda(4.5,4.9,0,vx,vy,0)
--	flip()
--	end
--	freeze()
--	
--end
--test_dda()



k_ambient=.4
function iso_render(start_x,start_y,end_x,end_y)
	skip_step=1
	
	local start_x=start_x or 0
	local start_y=start_y or 0
	local end_x=end_x or 127
	local end_y=end_y or 127
	
	
	--flip()
	local cam_matrix=matrix_multiply(create_x_rotate(cam_ax),create_y_rotate(cam_ay))
	local cam_h = vec3_transform({1,0,0},cam_matrix)
	local cam_v = vec3_transform({0,1,0},cam_matrix)
	local cam_d = vec3_transform({0,0,1},cam_matrix)	
	local cam_location=vec3_add(cam_target,vec3_scale(cam_d,-k_cam_height))
	
	

	local px,py,pz

	local depth
	local skip_step=skip_step
	local step1=skip_step-1
	local px,py,pz
	
	local v=0
	local nx,ny,nz
	for sx=start_x,end_x,skip_step do
		local v_h=vec3_scale(cam_h,shr(sx-64,6)/cam_zoom)
		for sy=start_y,end_y,skip_step do
			local v_v=vec3_scale(cam_v,shr(sy-64,6)/cam_zoom)
			local ray_start=vec3_add(cam_location,vec3_add(v_h,v_v))
			--local rgb,depth,px,py,pz = trace_ray(ray_start[1],ray_start[2],ray_start[3],cam_d[1],cam_d[2],cam_d[3])
			
			local rgb=trace_ray(ray_start,cam_d)
			local c = get_ordered_pixel(sx,sy,rgb)
						--
			pset(sx,sy,c)
		end
		if(stat(34)!=0 ) return false
	end
end


function vec3_lerp(v1,v2,a)
	local b=1-a
	return{v1[1]*a+v2[1]*b,v1[2]*a+v2[2]*b,v1[3]*a+v2[3]*b}
end


k_mirror_amount=.75
k_transparent_amount=.5
k_ambient=.4

function trace_ray(ray_start,ray_v,last_v)
	local v,n,p=vox_dda(ray_start[1],ray_start[2],ray_start[3],ray_v[1],ray_v[2],ray_v[3])
	
			--pset(sx,sy,12)
		
			if(v!=false)then
			
				local transparent=false
				if(v>15 and v<=32)transparent=true v=v%16
				
				local mirror=false
				local bright=false
				if(v>32 and v<=48)mirror=true v=v%16
				if(v>48)bright=true v=v%16
				
				
				local rgb_bright={0,0,0}
			--	pset(sx,sy,v)
				--rectfill(sx,sy,sx+step1,sy+step1,v)--pset(sx,sy,v)
				
				
		
				local 	light_vx,light_vy,light_vz=light_x,light_y,light_z
				--local diffuse = mid(nx*light_vx+ny*light_vy+nz*light_vz,0,1)*.8+.2
				--local diffuse = mid(vec3_dot({light_vx,light_vy,light_vz},n),0,1)
				local diffuse = (vec3_dot({light_vx,light_vy,light_vz},n)*.5+.5)^2 -- half lambert diffuse
		
				local half_dir = vec3_unit(vec3_add({-light_vx,-light_vy,-light_vz},cam_d))
				local specular = mid(0,1,-vec3_dot(half_dir,n))^4
				

				shadow=trace_shadow({p[1]+n[1]*.01,p[2]+n[2]*.01,p[3]+n[3]*.01},{light_vx,light_vy,light_vz})
				--shadow=vec3_lerp(shadow,{1,1,1},.5)
				if(mirror)shadow=vec3_lerp({1,1,1},shadow,k_mirror_amount)

				
				local material_color=pico_palette[v]
				
				rgb_bright=vec3_mult(vec3_scale(shadow,diffuse),material_color)
				rgb_bright=vec3_lerp(material_color,rgb_bright,k_ambient)
				
				
				local occlusion,glow = find_ambient_occlusion(p,n)
				
				rgb_bright=vec3_scale(rgb_bright,occlusion^.25*.5+.5)
				
				rgb_bright=vec3_add(rgb_bright,vec3_scale(glow,.2))
				
				
				if(bright) rgb_bright= vec3_lerp({pico_palette[v][1],pico_palette[v][2],pico_palette[v][3]},rgb_bright,.75)
				
				if(transparent)then
			
					local next_step_rgb = trace_ray({p[1]+ray_v[1]*.01,p[2]+ray_v[2]*.01,p[3]+ray_v[3]*.01},ray_v)
					next_step_rgb = vec3_mult(next_step_rgb,{pico_palette[v][1],pico_palette[v][2],pico_palette[v][3]})
					 next_step_rgb = vec3_scale(next_step_rgb,k_transparent_amount)
					local cur_step_rgb = vec3_scale(rgb_bright,k_transparent_amount)
					
					return vec3_add(cur_step_rgb,next_step_rgb)
				elseif(mirror)then
					local reflect = vec3_sub(ray_v,vec3_scale(n, 2*vec3_dot(n,ray_v)))
					local next_step_rgb = trace_ray({p[1]+reflect[1]*.01,p[2]+reflect[2]*.01,p[3]+reflect[3]*.01},reflect)
					next_step_rgb =  vec3_mult( rgb_bright,next_step_rgb)
					return vec3_lerp(next_step_rgb,rgb_bright,k_mirror_amount)
				else
				
				
					return rgb_bright
				end
						--c = get_ordered_pixel(sx,sy,rgb_bright)
						--
						--pset(sx,sy,c)
						
				
				
				 
				
			else -- no inteserction
				--local b = abs(vec3_dot(ray_v,vec3_unit(ray_start)))
				
				local b = get_sky_color(ray_start,vec3_scale(ray_v,-1))
				return {b,b,b}
		
				
			end
	end

--https://gamedev.stackexchange.com/questions/96459/fast-ray-sphere-collision-code
--heavily modified sphere intersect
function get_sky_color(p, d) 
	local m = vec3_sub(p,cam_target)
	local b= vec3_dot(m,d)
	local c = vec3_dot(m,m) - 2500
	local n = vec3_unit(vec3_sub(vec3_add(p, vec3_scale(d,-b - sqrt(b*b - c))),cam_target))
	return abs(n[2])*.75+abs(n[3])*.25
end



function trace_shadow(p,v,s)
	local shadow_dist,shadow,shadow_white ,shadow_hit,shadow_n,shadow_p,sd= s or 0,{1,1,1},{1,1,1},vox_dda(p[1],p[2],p[3],v[1],v[2],v[3])
	

	if(shadow_hit)then
		shadow_dist+=sd
		local shadow_fade= 1-mid(0,1,.05*shadow_dist)
		if(shadow_hit>48)return shadow_white
		if( (shadow_hit>=16 and shadow_hit<32))then
			--local next_shadow=trace_shadow(vec3_add(shadow_p,vec3_scale(v,.01)),v)
			--local rgb=pico_palette[shadow_hit%16]
			--shadow = vec3_mult(next_shadow,rgb)
			--shadow = vec3_lerp(shadow,shadow_white,shadow_fade)
			
			--merging to save tokens
			return vec3_lerp(vec3_mult(trace_shadow(vec3_add(shadow_p,vec3_scale(v,.01)),v),pico_palette[shadow_hit%16]),shadow_white,shadow_fade)
		else
			--we hit an opaque block
			return vec3_lerp({0,0,0},shadow_white,shadow_fade)
		
		end
	end
	return shadow
end

function find_ambient_occlusion(p,n)
	-- check the normal direction
	--find vector for u and for v
	local u
	local v
	
	local ud
	local vd
	
	local cx=flr(p[1])
	local cy=flr(p[2])
	local cz=flr(p[3])
	local bright=false
	--local cy=flr(p[2])
	--local cz=flr(p[3])x
	--local cz=flr(p[3])
	
	if( abs(n[1])==1)then
		u={0,0,1}
		ud=3
		v={0,1,0}
		vd=2
	elseif( abs(n[2])==1)then
		u={0,0,1}
		ud=3
		v={1,0,0}
		vd=1
	elseif( abs(n[3])==1)then
		u={1,0,0}
		ud=1
		v={0,1,0}
		vd=2
	end
	
	local min_d=1
	local d=1
	
	local glow_color={0,0,0}
	
	for i=-1,1 do
		for j=-1,1 do
		
			local tx=cx+u[1]*i +v[1]*j
			local ty=cy+u[2]*i +v[2]*j
			local tz=cz+u[3]*i +v[3]*j
		
			if(tx>=0 and tx<k_width and ty>=0 and ty<k_height and tz>=0 and tz<k_depth )then
				d=1
				--if( not (i==0 and j==0) )then --ignore center
				local v=vox_scene[tx][ty][tz]
				if(v>48)bright=true
				
				if(v!=0)then
				
					if(abs(i)!=abs(j))then
						--sides
						
						if(i<0)d=p[ud]%1
						if(i>0)d=1-p[ud]%1
						if(j<0)d=p[vd]%1
						if(j>0)d=1-p[vd]%1
					else
						--diags
						local diag_u,diag_v
						if(i<0)then
							diag_u=p[ud]%1
						else
							diag_u=1-p[ud]%1
						end
						if(j<0)then
							diag_v=p[vd]%1
						else
							diag_v=1-p[vd]%1
						end
				
						d=sqrt(diag_u*diag_u+diag_v*diag_v)
					
					end
					
					--min_color=vec3_mult(

				if(bright)glow_color=vec3_add(glow_color,vec3_scale({pico_palette[v%16][1],pico_palette[v%16][2],pico_palette[v%16][3]},1-d)) d=2
				min_d=min(min_d,d)
				end
			
			end
		end
	end
	


	
	return min_d,glow_color
	
end







--shade list has shadow,dark,mid,highlight
shade_list = build_num_table([[
[0]=0,0,0,1|
0,0,1,13|
0,1,2,4|
0,1,3,11|
1,2,4,9|
0,1,5,6|
0,5,6,7|
1,6,7,7|
2,4,8,14|
2,4,9,10|
4,9,10,15|
1,3,11,10|
1,13,12,7|
0,1,13,12|
2,13,14,15|
2,9,15,7
]],true)

--https://www.iquilezles.org/www/articles/volumesort/volumesort.htm
--how to do quick and easy volume sort
function draw_vox(high_qual)
	
	local vox_scene,shade_list,k_width,k_height,k_depth,splat_r= vox_scene,shade_list,k_width,k_height,k_depth,splat_r

	local cam_d = vec3_transform({0,0,-1},cam_matrix)
	
	local x_inc,y_inc,z_inc,x_start,y_start,z_start = 1,-1,1,0,0,0

	local x_ord,y_ord,z_ord = 1,3,2
	local i_lim,j_lim,k_lim=k_width-1,k_height-1,k_depth-1
	
	--cam_target={7.5,12,7.5}
	local cam_tx=cam_target[1]
	local cam_ty=cam_target[2]
	local cam_tz=cam_target[3]
	
	if(cam_d[1]<0)x_inc*=-1
	if(cam_d[3]<0)z_inc*=-1
	
	if(cam_d[2]>0)x_ord,y_ord,z_ord = 2,1,3 y_inc*=-1 k_lim,i_lim,j_lim=k_width-1,k_height-1,k_depth-1

	if(x_inc<0)x_start=k_width-1
	if(y_inc<0)y_start=k_height-1
	if(z_inc<0)z_start=k_depth-1
	
	local x_loc,y_loc,z_loc=x_start,y_start,z_start
	
	local cam_hx,cam_hy,cam_hz=cam_h[1],cam_h[2],cam_h[3]
	local cam_vx,cam_vy,cam_vz=cam_v[1],cam_v[2],cam_v[3]
	
	local min_draw=-splat_r*2
	local max_draw=127+splat_r*2
	local splat_d=splat_r*2


	local last_v=0
	palt(0,false)
	palt(14,true)
	pal(0,0)

	for j=0,j_lim do
		if(x_ord==2)x_loc=x_start
		if(y_ord==2)y_loc=y_start
		if(z_ord==2)z_loc=z_start
		
		for k=0,k_lim do
			
			
			
			if(x_ord==1)x_loc=x_start
			if(y_ord==1)y_loc=y_start
			if(z_ord==1)z_loc=z_start
			
			for i=0,i_lim do
				local v= vox_scene[x_loc][y_loc][z_loc]
				if(v>0)then
					local sx=(cam_hx*(x_loc-cam_tx+.5)+cam_hy*(y_loc-cam_ty+.5)+cam_hz*(z_loc-cam_tz+.5))*64*cam_zoom+64
					local sy=(cam_vx*(x_loc-cam_tx+.5)+cam_vy*(y_loc-cam_ty+.5)+cam_vz*(z_loc-cam_tz+.5))*64*cam_zoom+64
					
					if(sx>min_draw and sx<max_draw and sy>min_draw and sy<max_draw)then

							if(v!=last_v)then
							local the_shade=shade_list[v%16]
							fillp()
							pal(1,the_shade[1])
							pal(5,the_shade[2])
							pal(6,the_shade[3])
							pal(7,the_shade[4])
							
							if(v>15 and v<=32)fillp(0b0101101001011010.11)
							 if(v>32 and v<=48)fillp(0b1111000011110000.01)
							 if(v>48 and v<=64)fillp(0b0000010110100000.01)
							
							last_v=v
							end
							
							 

							
							if(not high_qual)then
							sspr(16-splat_r,16-splat_r,splat_d,splat_d,sx-splat_r,sy-splat_r)
							else

								splat_cube(sx,sy)
								--
							end
							
					end

				end
				
				if(x_ord==1)x_loc+=x_inc
				if(y_ord==1)y_loc+=y_inc
				if(z_ord==1)z_loc+=z_inc
			end
			
			if(x_ord==2)x_loc+=x_inc
			if(y_ord==2)y_loc+=y_inc
			if(z_ord==2)z_loc+=z_inc
			--flip()
		end
		if(x_ord==3)x_loc+=x_inc
		if(y_ord==3)y_loc+=y_inc
		if(z_ord==3)z_loc+=z_inc
		
	end
	pal()
	fillp()
end

cube_points=build_num_table([[
-0.5,0.5,0.5|
0.5,0.5,0.5|
0.5,-0.5,0.5|
-0.5,-0.5,0.5|
-0.5,0.5,-0.5|
0.5,0.5,-0.5|
0.5,-0.5,-0.5|
-0.5,-0.5,-0.5
]])


cube_faces=build_num_table([[
1,2,3,4,6|
8,7,6,5,5|
2,1,5,6,1|
4,3,7,8,7|
5,1,4,8,5|
2,6,7,3,6
]])


splat_r=8
function draw_cube()
	local cam_d = vec3_transform({0,0,-1},cam_matrix)
	local cam_hx,cam_hy,cam_hz,cam_vx,cam_vy,cam_vz=cam_h[1],cam_h[2],cam_h[3],cam_v[1],cam_v[2],cam_v[3]
	
	for i,p in pairs(cube_points)do
		p[5]=(cam_hx*(p[1])+cam_hy*(p[2])+cam_hz*(p[3]))*64*cam_zoom+16
		p[6]=(cam_vx*(p[1])+cam_vy*(p[2])+cam_vz*(p[3]))*64*cam_zoom+16
	end
	
	quad_list={}
	splat_r=32*cam_zoom*2
	rectfill(0,0,32,32,14)

	for i,face in pairs(cube_faces) do

		--local xa,ya= cube_points[face[1]][5],cube_points[face[1]][6]
		--local xb,yb=cube_points[face[2]][5],cube_points[face[2]][6]
		--local xc,yc = cube_points[face[3]][5],cube_points[face[3]][6]
		--local xd,yd = cube_points[face[4]][5],cube_points[face[4]][6]	
		local xa,ya,xb,yb,xc,yc,xd,yd = cube_points[face[1]][5],cube_points[face[1]][6],cube_points[face[2]][5],cube_points[face[2]][6],cube_points[face[3]][5],cube_points[face[3]][6],cube_points[face[4]][5],cube_points[face[4]][6]

		
		--local vxa=xb-xa
		--local vya=yb-ya
		--local vxb=xc-xb
		--local vyb=yc-yb
		----check winding
		----collapsed
		--if(vxa*vyb-vya*vxb>0)then
		
		--collapsed check winding see above
		if((xb-xa)*(yc-yb)-(yb-ya)*(xc-xb)>0)then
			draw_quad(xa,ya,xb,yb,xc,yc,xd,yd,face[5])
			add(quad_list,{xa-16,ya-16,xb-16,yb-16,xc-16,yc-16,xd-16,yd-16,face[5]})
		end
	
	end
	
	local src,dest=0x6000,0x0000
	for i=0,32 do
		memcpy(dest,src,16)
		dest+=64
		src+=64
	end
	
	rectfill(0,0,32,32,6)
	
end


function draw_quad(xa,ya,xb,yb,xc,yc,xd,yd,c)

	 p01_triangle_163(xa,ya,xb,yb,xd,yd,c)
	 p01_triangle_163(xb,yb,xc,yc,xd,yd,c)

	line(xa,ya,xb,yb,0)
	line(xc,yc)
	line(xd,yd)
	line(xa,ya)
end


--@p01
function p01_triangle_163(x0,y0,x1,y1,x2,y2,col)
 color(col)
 if(y1<y0)x0,x1,y0,y1=x1,x0,y1,y0
 if(y2<y0)x0,x2,y0,y2=x2,x0,y2,y0
 if(y2<y1)x1,x2,y1,y2=x2,x1,y2,y1
 col=x0+(x2-x0)/(y2-y0)*(y1-y0)
 p01_trapeze_h(x0,x0,x1,col,y0,y1)
 p01_trapeze_h(x1,col,x2,x2,y1,y2)
end
function p01_trapeze_h(l,r,lt,rt,y0,y1)
 lt,rt=(lt-l)/(y1-y0),(rt-r)/(y1-y0)
 if(y0<0)l,r,y0=l-y0*lt,r-y0*rt,0
 y1=min(y1,128)
 for y0=y0,y1 do
  rectfill(l,y0,r,y0)
 -- for i=l,r do sset(i,y0,13) end
  l+=lt
  r+=rt
 end
end

function splat_cube(sx,sy)
	local quad_list=quad_list
	for i,q in pairs(quad_list) do
		draw_quad(q[1]+sx,q[2]+sy,q[3]+sx,q[4]+sy,q[5]+sx,q[6]+sy,q[7]+sx,q[8]+sy,q[9])
	end
end

--function quick_box_sdf(px,py,pz,params) 
--	return max(max(abs(px)-params[1],abs(py)-params[2]),abs(pz)-params[3])
--end

--------------gui-------------------------------------------------------------
function init_mouse()
	poke(0x5f2d, 1) --enable mouse
	
	update_mouse()
	mouse_down_x=mouse_x
	mouse_down_y=mouse_y
	last_mouse_x=mouse_x
	last_mouse_y=mouse_y
	last_mouse_down=mouse_down
	last_right_mouse_down=right_mouse_down
	last_middle_mouse_down=middle_mouse_down
	tx=mouse_x
	ty=mouse_y
	last_click_time=0
	last_right_click_time=0
	last_middle_click_time=0
end

function update_mouse()
	last_mouse_x=mouse_x
	last_mouse_y=mouse_y
	mouse_x=stat(32)
	mouse_y=stat(33)
	
	last_mouse_down=mouse_down
	last_right_mouse_down=right_mouse_down
	last_middle_mouse_down=middle_mouse_down
	
	--if(stat(34)!=0)then
	--	cls()
	--	print(stat(34))
	--end
	
	
	if(band(stat(34),1)==1)then
		mouse_down=true
		if(not last_mouse_down) mouse_down_x=mouse_x mouse_down_y=mouse_y last_click_time=cur_frame
	else
		mouse_down=false
	end
	
	if(band(stat(34),2)==2)then
		right_mouse_down=true
		if(not last_right_mouse_down) last_right_click_time=cur_frame
	else
		right_mouse_down=false
	end
	
	if(band(stat(34),4)==4)then
		middle_mouse_down=true
		if(not last_middle_mouse_down) last_middle_click_time=cur_frame
	else
		middle_mouse_down=false
	end
	
end

k_left_mouse=1
k_right_mouse=2
k_middle_mouse=4

function mouse_click(b)
	if(b==nil or b==k_left_mouse) return(mouse_down==true and last_mouse_down==false)
	if(b==k_right_mouse)return(right_mouse_down==true and last_right_mouse_down==false)
	if(b==k_middle_mouse)return(middle_mouse_down==true and last_middle_mouse_down==false)
	
end

k_repeat_delay=15

function check_click_rect(x1,y1,x2,y2,rep)
	--check if last state was mouse down
	--and current state is mouse up
	--and mouse down and mouse up were both in rect
	if( in_rect(mouse_down_x,mouse_down_y,x1,y1,x2,y2))then
		if((last_mouse_down and not mouse_down) or (rep and mouse_down and cur_frame-last_click_time>k_repeat_delay ))then
			return in_rect(mouse_x,mouse_y,x1,y1,x2,y2)
		end
	end
	return false
end

function check_down_rect(x1,y1,x2,y2)
	return(mouse_down and in_rect(mouse_x,mouse_y,x1,y1,x2,y2))
end

function in_rect(x,y,x1,y1,x2,y2)
	if(x2<x1)x1,x2=x2,x1
	if(y2<y1)y1,y2=y2,y1
	return (x>=x1 and x<x2 and y>=y1 and y<y2)
end

function draw_mouse()

	
	
	line(mouse_x-2,mouse_y,mouse_x+2,mouse_y,4)
	line(mouse_x,mouse_y-2,mouse_x,mouse_y+2,5)
	pset(mouse_x,mouse_y,6)


end



k_this_vox=1
k_surface_vox=2
function find_vox(sx,sy,mode)
	local cam_matrix=matrix_multiply(create_x_rotate(cam_ax),create_y_rotate(cam_ay))
	local cam_h ,cam_v,cam_d,cx,cy,cz= vec3_transform({1,0,0},cam_matrix), vec3_transform({0,1,0},cam_matrix),vec3_transform({0,0,1},cam_matrix)
	
	local cam_location=vec3_add(cam_target,vec3_scale(cam_d,-k_cam_height))
	
	local v_v,v_h=vec3_scale(cam_v,shr(sy-64,6)/cam_zoom),vec3_scale(cam_h,shr(sx-64,6)/cam_zoom)
	local ray_start=vec3_add(cam_location,vec3_add(v_h,v_v))
	local v,n,p=vox_dda(ray_start[1],ray_start[2],ray_start[3],cam_d[1],cam_d[2],cam_d[3])

	if(v!=false)then
	
		if(mode==nil or mode==k_this_vox)then
		
			
			cx=flr(p[1]-n[1])
			cy=flr(p[2]-n[2])
			cz=flr(p[3]-n[3])
		elseif(mode==k_surface_vox)then
			cx=flr(p[1])
			cy=flr(p[2])
			cz=flr(p[3])
		end
			
		if(cx<k_width and cx>=0 and cy<k_height and cy>=0 and cz<k_depth and cz>=0)then
				return cx,cy,cz
		else
			return false
		end
	end
	return false
end


function frame_rect(x1,y1,x2,y2,cf,cl)
	rectfill(x1,y1,x2,y2,cf)
	rect(x1,y1,x2,y2,cl)
end

function sprite_button(s,x,y,active)
	if(in_rect(mouse_x,mouse_y,x,y,x+7,y+7))then
		rectfill(x-1,y-1,x+8,y+8,7)
	end
	if(active)frame_rect(x-1,y-1,x+8,y+8,5,7)
	if(check_click_rect(x,y,x+7,y+7))then
		frame_rect(x-1,y-1,x+8,y+8,5,8)
		spr(s,x,y)
		return true
	end
	spr(s,x,y)
	return false
	
end

function rect_button(x1,y1,x2,y2,cf,c1,active)
	frame_rect(x1,y1,x2,y2,cf,cl)
	if(in_rect(mouse_x,mouse_y,x1,y1,x2,y2))then
		rect(x1+1,y1+1,x2-1,y2-1,7)
	end
	if(active)then
		
		rect(x1+1,y1+1,x2-1,y2-1,7)
		rect(x1+1,y1+2,x2-1,y2-2,0)
	--	if(cf==7)rect(x1+1,y1+1,x2-1,y2-1,5)
	end
	
	if(check_click_rect(x1,y1,x2,y2))then
		rect(x1+1,y1+1,x2-1,y2-1,8)
		return true
	end
	
	return false
end


function text_button(x,y,text,cf,c1)

	local x2,y2=x+#text*4+2,y+8

	frame_rect(x,y,x2,y2,cf,cl)
	print(text,x+2,y+2,cl)
	
	if(in_rect(mouse_x,mouse_y,x,y,x2,y2))rect(x+1,y+1,x2-1,y2-1,7)
	if(check_click_rect(x,y,x2,y2))return true
	return false
	
end

k_paint_mode=1
k_add_mode=2
k_fill_mode=3
k_pan_mode=4
k_erase_mode=10
ground_on=true

k_solid_mode=0
k_transparent_mode=1
k_mirror_mode=2
k_bright_mode=3


mouse_mode = k_add_mode
color_mode = k_solid_mode
cur_color=8
function handle_ui()
	--if(check_click_rect(0,0,127,20))click_through=false
	--draw_window

	
	local do_render=false
	local do_anim=false
	local do_info=false
	--frame_rect(xloc,yloc,xloc+width,yloc+height,6,5)
	
	
	frame_rect(0,0,127,20,1,5)
	
	frame_rect(0,0,47,20,6,5)
	palt(0,false)
	palt(14,true)
	if(sprite_button(12,2,2,mouse_mode == k_add_mode))mouse_mode = k_add_mode
	if(sprite_button(13,11,2,mouse_mode == k_paint_mode))mouse_mode = k_paint_mode
	if(sprite_button(14,2,11,mouse_mode == k_fill_mode))mouse_mode = k_fill_mode
	if(sprite_button(07,11,11,mouse_mode == k_pan_mode))mouse_mode = k_pan_mode
	if(sprite_button(15,20,2))do_render=true 
	if(sprite_button(05,20,11))do_anim=true
	if(sprite_button(20,29,2))toggle_ground()
	if(sprite_button(21,38,2))save_scene()
	if(sprite_button(4,38,11))do_info=true
	
	frame_rect(47,0,67,20,6,5)
	palt(0,false)
	palt(14,true)
	if(sprite_button(8,49,2,color_mode==k_solid_mode))then color_mode=k_solid_mode if(cur_color!=0)then cur_color=cur_color%16+16*color_mode end end
	if(sprite_button(9,58,2,color_mode==k_transparent_mode))then color_mode=k_transparent_mode if(cur_color!=0)then cur_color=cur_color%16+16*color_mode end end
	if(sprite_button(10,49,11,color_mode==k_mirror_mode))then color_mode=k_mirror_mode if(cur_color!=0)then cur_color=cur_color%16+16*color_mode end end
	if(sprite_button(11,58,11,color_mode==k_bright_mode))then  color_mode=k_bright_mode if(cur_color!=0)then cur_color=cur_color%16+16*color_mode end end
	--
	frame_rect(67,yloc,127,20,6,5)
	for i=0,15 do
		local column,row=i%8,flr(i/8)
		local x,y=69+7*column,2+9*row

		if(rect_button(x,y,x+7,y+7,i,5,cur_color%16 == i))then
			if(i!=0)then
				cur_color=i+16*color_mode
			else
				cur_color=0 -- erase mode
				mouse_mode=k_add_mode
			end
			--if(i==0)then mouse_mode=k_erase_mode end
		end
		
		if(i==0)line(x+6,y+1,x+1,y+6,8)
	end
	
	if(sprite_button(6,29,11))then
		--if(modal_confirm("clear scene?"))init_vox_scene()
		if(handle_window(80,80,true,new_scene_func))then
			k_width=temp_scene_width
			k_height=temp_scene_height
			k_depth=temp_scene_depth
			cam_target={k_width/2,k_height-1,k_depth/2}
			init_vox_scene()
		end
			  camera_updated=true reload()

	end
	-- modal_content_func(data)
	if(do_render)render_scene()
	if(do_anim)then
		if(modal_confirm("render animation?\n...takes a while"))render_anim()

			camera_updated=true reload()

		
	end
	if(do_info)show_info()camera_updated=true reload()
end

function toggle_ground()
	if(ground_on)then
		for i=0,k_width-1 do
			for k=0,k_depth-1 do
				vox_scene[i][k_height-1][k]=0
			end
		end
		ground_on=false
		
	else
		for i=0,k_width-1 do
			for k=0,k_depth-1 do
				vox_scene[i][k_height-1][k]=7
			end
		end
		ground_on=true
	end
	camera_updated=true reload()
end

function digit_widget(v,x,y,max_v,min_v)
	frame_rect(x,y,x+10,y+8,7,0)
	print(v,x+2,y+2,12)
	if(text_button(x+12,y,"<",6,0))v= mid(min_v,max_v,v-1)
	if(text_button(x+20,y,">",6,0))v= mid(min_v,max_v,v+1)
	return v
end

temp_scene_width=k_width
temp_scene_height=k_height
temp_scene_depth=k_depth
function new_scene_func(data,w,h)
	local x1,y1=flr(64-w/2),flr(64-h/2)
	center_print("new scene",64,y1+6,0)
	print("width",x1+4,y1+16,0) temp_scene_width=digit_widget(temp_scene_width,x1+32,y1+14,4,32)
	print("height",x1+4,y1+26,0) temp_scene_height=digit_widget(temp_scene_height,x1+32,y1+24,4,32)
	print("depth",x1+4,y1+36,0) temp_scene_depth=digit_widget(temp_scene_depth,x1+32,y1+34,4,32)
	
	if(temp_scene_width*temp_scene_height*temp_scene_depth>8000)temp_scene_height-=1 print("height",x1+4,y1+26,8)
	
	print("warning:",x1+4,y1+50,0)
	print("will clear data",x1+4,y1+58,0)
end

info_text="\^w\^tpICOvOX\n\^-w\^-tversion "..build_version.."\n\nrequires mouse\n\n\^wtools\^-w\nblock: add blocks\nbrush: paint color\ncam: render\nfloor: toggle floor\ndisk: save\nbucket: fill color\nhand: pan\nloop: render anim\ndoc: clear scene\n?: info text\n\n\^wblocks\^-w\nsolid block\ntransparent block\nmirror block\nbright block\n\n\^wcolors\^-w\nselect color\nblack is erase\n\n\^wkeys\^-w\narrow keys rotate view\nz+arrow: pan\nshift+up/down: zoom\nx: quick render\n\n\^wmouse\^-w\nleft: add block\nright: del block\nmiddle: rotate\nscroll wheel: zoom\nshift+middle: look at"


function show_info()
	memcpy(0x0000,0x6000,128*64)
	local frame=0
	while(true)do
		memcpy(0x6000,0x0000,128*64)
		
		update_mouse()
		frame_rect(16,16,127-16,127-16,7,0)
		clip(18,18,127-36,78)
		
		
		
		print(info_text,19,18-(frame/1)%360+80,0)
		clip()
		if(text_button(48,98,"  ok  ",6,0))return true --init_vox_scene() camera_updated=true reload()  return true

		draw_mouse()
		flip()
		frame+=1
	end
end


function modal_confirm(s)
	memcpy(0x0000,0x6000,128*64)
	while(true)do
		memcpy(0x6000,0x0000,128*64)
		
		update_mouse()
		frame_rect(16,32,127-16,60,7,0)
		print(s,19,35,0)
		if(text_button(46,50,"yes",6,0))return true --init_vox_scene() camera_updated=true reload()  return true
		if(text_button(64,50,"no",6,0))return false --camera_updated=true reload() return false
		draw_mouse()
		flip()
	end
end

function modal_content_func(data,w,h)
	center_print(data,64,64-h/2+4,0)
end

function handle_window(w,h,show_ok,content_func,data)
	memcpy(0x0000,0x6000,128*64)
	while(true)do
		memcpy(0x6000,0x0000,128*64)
		
		update_mouse()
		frame_rect(64-w/2,64-h/2,64+w/2,64+h/2,7,0)

		if(text_button(64-w/2+4,64+h/2-12,"cancel",6,0))return false --init_vox_scene() camera_updated=true reload()  return true
		if(show_ok)then
			if(text_button(64+w/2-4*2-6,64+h/2-12,"ok",6,0))return true
		end--camera_updated=true reload() return false
		if(content_func!=nil)content_func(data,w,h)
		
		draw_mouse()
		flip()
	end
end

function render_scene()
	flip() 

	not_skip = iso_render()
	
	if(not_skip==nil)extcmd("screen",1)
	print("\#0render saved to desktop.",0,0,7)
	print("\#0click to return.")
	while(true)do
		 flip()
		if(stat(34)!=0 ) return false
	end
end


function render_anim()
	local k_length,cur_frame,start_ay=128,0,cam_ay
	extcmd("rec_frames")
	cls()
	--flip() 

	while (cur_frame<k_length)do
		cam_ay=start_ay+cur_frame/k_length
		update_camera()
		not_skip=iso_render()
		cur_frame+=1
		flip()
		if(stat(34)!=0 ) return false
	end
	if(not_skip==nil)then
	extcmd("video")
	cam_ay=start_ay
	update_camera()
	end

end


function fill_color(x,y,z,c)
	--if(x>=0 and y>=0 and z>=0 and x<k_width and y<k_height and z<k_depth)then
		local run_color = vox_scene[x][y][z]
		if(run_color==c)return false --trying to fill an already right vox
		recursive_fill(x,y,z,c,run_color)
	--end
end

function recursive_fill(x,y,z,c,run_color)
	if(x>=0 and y>=0 and z>=0 and x<k_width and y<k_height and z<k_depth)then
		if(vox_scene[x][y][z]!=run_color)return false
		
		vox_scene[x][y][z]=c
		
		
		
		recursive_fill(x+1,y,z,c,run_color)
		recursive_fill(x-1,y,z,c,run_color)
		recursive_fill(x,y+1,z,c,run_color)
		recursive_fill(x,y-1,z,c,run_color)
		recursive_fill(x,y,z+1,c,run_color)
		recursive_fill(x,y,z-1,c,run_color)
		
	end
	return false
end



function handle_mouse_draw()
	local cx,cy,cz
	if(mouse_y<20)return false
	
	if(mouse_click(k_right_mouse) or (cur_color==0 and mouse_click(k_left_mouse)))then
		cx,cy,cz=find_vox(mouse_x,mouse_y,k_this_vox)
		if(cx!=false)then
				vox_scene[cx][cy][cz]=0
				needs_redraw=true
				return true
		end
	end
	
	if(mouse_mode==k_paint_mode)then
		if(mouse_click(k_left_mouse) )then 
			cx,cy,cz =find_vox(mouse_x,mouse_y)
			--vox_scene[cx][cy][cz]=15
			if(cx!=false)then
				vox_scene[cx][cy][cz]=cur_color
				needs_redraw=true
				return true
			end
		end
	end
	
	if(mouse_mode==k_fill_mode)then
		if(mouse_click(k_left_mouse) )then 
			cx,cy,cz=find_vox(mouse_x,mouse_y)
			if(cx!=false)then
				fill_color(cx,cy,cz,cur_color)
				needs_redraw=true
					return true
			end
		end
	end
	
	if(mouse_mode==k_add_mode)then
		if(mouse_click(k_left_mouse) )then 
			--cls(6)
			cx,cy,cz =find_vox(mouse_x,mouse_y,k_surface_vox)
			--vox_scene[cx][cy][cz]=15
			if(cx!=false)then
				vox_scene[cx][cy][cz]=cur_color
				needs_redraw=true
				return true
			end
		end
	end
	
	if(mouse_mode==k_pan_mode)then
		if(mouse_click(k_left_mouse) )then 
			cx,cy,cz =find_vox(mouse_x,mouse_y)
			if(cx)then 
				cam_target={cx,cy,cz}
				camera_updated=true
			end
		end
		
		if(middle_mouse_down)then

			local rx=(mouse_x-64)/64*k_move_speed*1.5
			local ry=-(mouse_y-64)/64*k_move_speed*1.5
			cam_target=vec3_add(cam_target,vec3_scale(cam_h,rx))
			cam_target=vec3_add(cam_target,vec3_scale(cam_v,-ry))
		
			camera_updated=true
		
		end
	end
	
	--handle rotations
	if(middle_mouse_down and mouse_mode!=k_pan_mode and not btn(4,1) )then
		local rx=(mouse_x-64)/64*k_rotate_speed*1.5
		local ry=-(mouse_y-64)/64*k_rotate_speed*1.5
		
		cam_ay+=-rx
		cam_ax+=-ry
		camera_updated=true
	
	end
	
	if(mouse_click(k_middle_mouse) and btn(4,1) )then 
		cx,cy,cz =find_vox(mouse_x,mouse_y)
		if(cx)then 
			cam_target={cx,cy,cz}
			camera_updated=true
		end
	end
	
	return false
end

k_rotate_speed=.005
k_move_speed=.2
function handle_keys()
	

	
	if(btn(5))then flip() iso_render() while(btn(5))do flip() end end
	
	if(mouse_down and right_mouse_down)cam_target[1]+=-k_move_speed*cam_h[1] camera_updated=true

	
	if(btn(4,0))then
		if(btn(0))then
			cam_target=vec3_add(cam_target,vec3_scale(cam_h,-k_move_speed))
			--
			--cam_target[1]+=-k_move_speed*cam_h[1]
			--cam_target[2]+=-k_move_speed*cam_h[2]
			--cam_target[3]+=-k_move_speed*cam_h[3]
			camera_updated=true
		end
		if(btn(1))then
			cam_target=vec3_add(cam_target,vec3_scale(cam_h,k_move_speed))
			--cam_target[1]+=k_move_speed*cam_h[1]
			--cam_target[2]+=k_move_speed*cam_h[2]
			--cam_target[3]+=k_move_speed*cam_h[3]
			camera_updated=true
		end
		if(btn(2))then
			cam_target=vec3_add(cam_target,vec3_scale(cam_v,-k_move_speed))
			--cam_target[1]+=-k_move_speed*cam_v[1]
			--cam_target[2]+=-k_move_speed*cam_v[2]
			--cam_target[3]+=-k_move_speed*cam_v[3]
			camera_updated=true

			
		end
		if(btn(3))then
			cam_target=vec3_add(cam_target,vec3_scale(cam_v,k_move_speed))
			--cam_target[1]+=k_move_speed*cam_v[1]
			--cam_target[2]+=k_move_speed*cam_v[2]
			--cam_target[3]+=k_move_speed*cam_v[3]
			camera_updated=true
		
		end
		
		--if(btn(1))cam_target[1]+=-k_move_speed camera_updated=true
	elseif(btn(4,1))then
		if( btn(2))cam_zoom+=.005 camera_updated=true
		if(btn(3))cam_zoom+=-.005 camera_updated=true
	else
		if(btn(2))cam_ax+=k_rotate_speed camera_updated=true
		if(btn(3))cam_ax-=k_rotate_speed camera_updated=true
		if(btn(0))cam_ay-=k_rotate_speed camera_updated=true
		if(btn(1))cam_ay+=k_rotate_speed camera_updated=true
	end
	
	local scroll_v=stat(36)*.005
	
	if(scroll_v!=0)cam_zoom+=scroll_v camera_updated=true

	
	
end



-------------------------------------


function _init()

	cls(6)
	
	
	poke(0x5f34, 1) -- set fill pattern mode
	init_mouse()

	cur_frame=0
	init_scene()

	update_camera()
	camera_updated=true
	needs_redraw=false
	is_turning=false
	 
	
end

function _update()

	update_mouse()
	check_import()
	handle_keys()
end

frame_count=100
function _draw()

	fillp()

	if(camera_updated)then
		cls(6)
		update_camera()
		draw_cube()
		draw_vox()
		needs_redraw=true
	--	vox_splat()
	else
		if(needs_redraw)then
			cls(6)
		draw_vox(true)
		memcpy(0x0000+64*16,0x6000+64*16,128*64-64*16)
		needs_redraw=false
		end
		
	end
	
	if(not needs_redraw and not camera_updated)then
		memcpy(0x6000+64*16,0x0000+64*16,128*64-64*16)
	end

	camera_updated=false

	handle_ui()
	handle_mouse_draw()
	draw_mouse()

	cur_frame+=1
end

