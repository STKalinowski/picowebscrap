-- little necromancer
-- by fred osterero

actor = {} 
particle = {} 
explosion = {} 
fx = {} 
attack = {} 
clouds = {} 
aparticle = {} 
item = {} 

-- make an actor
function make_actor(x, y)
return add(actor,{
x = x,
y = y,
still = false,
state = "idle",
life = 1,
dx = 0,
dy = 0,
targ = 1,
flp = false,
spd = 0.07,
inertia = 0.6,
bounce = 0.4,
chest = false,
w = 0.4,
h = 0.4
})
end

function _init()

is_death=false
--player : little mortimer
pl = make_actor (0,0)
pl.role = "player"
pl.acc = 0.08
pl.cooldown = 0
pl.take_cooldown=0
pl.retry_cooldown=0
pl.potion_nb = 5
--pl animations
pl.idle={f=28,n=4,spd=2}
pl.idlet={f=24,n=1,spd=0}
pl.idled={f=20,n=1,spd=0}
pl.walk={f=16,n=4,spd=6}
pl.walkt={f=24,n=4,spd=7}
pl.walkd={f=20,n=4,spd=7}
pl.invoc={f=2,n=3,spd=6}
pl.invoct={f=8,n=3,spd=6}
pl.invocd={f=5,n=3,spd=6}
pl.fail={f=2,n=1,spd=2}
pl.faild={f=5,n=1,spd=2}
pl.failt={f=8,n=1,spd=2}
pl.death={f=11,n=4,spd=6}
pl.victory={f=16,n=8,spd=8}

--screen control
	scr = {}
	scr.x=0
	scr.y=0
	scr.shake=0
	scr.intensity = 2
	
--cloud factory
	cloud_nb= 24
	
--air particules max
 maxapart = 10
 
--particles timer
	particles_timer = 20
	scene_num = 1
	
--block road counter
	block_road = 10	
--first scene
	load_scene (0)
end

function animation (a)
--actor animation manager
return a.state
end

function anim_actor(a)
	return animator(a[a.state])
end

function animator(a)
-- all things animator
frame=a.f+(time()*a.spd)%a.n
return frame
end

function reinit_position (a)
--reinit position
	a.dx = 0
	a.dy = 0
	a.y = flr(a.y)+0.5
	a.x = flr(a.x)+0.5
end

function controls()

--player cooldown
if pl.cooldown>0
then pl.cooldown -= 1
end
if pl.take_cooldown>0 then
	pl.take_cooldown -= 1
end

-- btn detection
if btn(0) 
then 
	if pl.targ !=0 then	
	reinit_position (pl)
	end
	pl.targ=0 
	pl.dx -= pl.acc
	pl.flp = true
	if (pl.take_cooldown ==0) then
	pl.state="walk"
	end
	make_iexplosion (pl.x,pl.y,1,13,1.6,true)
elseif btn(1) 
then 
	if pl.targ !=1 then
	reinit_position (pl)
	end
	pl.targ=1
	pl.dx += pl.acc 
	pl.flp = false 
	if (pl.take_cooldown ==0) then
	pl.state="walk"
	end
	make_iexplosion (pl.x,pl.y,1,13,1.6,true)
elseif btn(2) 
then 
	if pl.targ !=2 then
	reinit_position (pl)
	end
	pl.targ=2
	pl.dy -= pl.acc
	if pl.take_cooldown ==0 then
	pl.state="walkt"
	end
	make_iexplosion (pl.x,pl.y,1,13,1.6,true)
elseif btn(3) 
then 
	if pl.targ !=3 then
	reinit_position (pl)
	end
	pl.targ=3
	pl.dy += pl.acc	
	if (pl.take_cooldown ==0) then
	pl.state="walkd"
	end
	make_iexplosion (pl.x,pl.y,1,13,1.6,true)
elseif (btnp(1) and btn(2))
or (btnp(1) and btn(3))
or (btnp(3) and btn(0))
or (btnp(0) and btn(2))
then
pl.retry_cooldown =0
reinit_position (pl)
elseif (btnp(5) and not btn(4)
and pl.cooldown==0) 
then 
	reinit_position (pl)
	wakeup_zombi ()
elseif (btn(4) ) 
then 
	pl.state="invocd"
	pl.retry_cooldown += 1

else
	pl.retry_cooldown =0
 reinit_position (pl)

--iddle animation set
if (pl.cooldown==0 and pl.take_cooldown==0) then

if (pl.targ==0 or pl.targ==1)
then pl.state="idle"
elseif (pl.targ==2)
then pl.state="idlet"
elseif (pl.targ==3)
then pl.state="idled"
end 
end 
end
end

function pl_death ()
if pl.life <=0
 then
 paralisis = true
 pl.state="death"
 gameover_timer -=1
end
	
if gameover_timer <=0 then
 for a in all(actor) do
 if (a.role!="player") then
 a.life=0
 end
 end
 zombi_nb = 0
 if gameover==false then
 screenshake (9,5)
 end
 gameover=true    
end
end

function end_level ()
if (flr(pl.x)==flr(endx) 
and flr(pl.y)==flr(endy))
 then
 is_death=false
 paralisis = true
 pl.state="victory"
 end_timer -=1
end
	
if end_timer <=0 
 then
 for a in all(actor) do
 if (a.role!="player") then
 del (actor,a)
 sfx (63,3,4,10) 
 end
 for b in all(item) do
 del (item,b)
 end
 zombi_nb = 0
 end_scene=true
 end 
end
end

function load_scene (num)
if num!=0 then
sfx (61,3,0,11) 
end
screenshake (3,0)
scene_num = num
end_scene = false
--pl inventory
pl.zombi_nb = 0
pl.life = 1
pl.orb_nb = 0
pl.orb_max = 0
pl.zombi_max = 3
pl.state="idle"
pl.targ=1
pl.flp = false 
	
--scene state
is_portal=false
is_open=false
particles_timer=20
gameover_timer =15		
end_timer =30
main_timer =30
endtitle_dw=128
paralisis = false
gameover=false

if (num<5 or num>16) then
scene="menu" else scene="game"
end
		
if num == 0 then
cls (0)
screenshake (0,0)
pal ()
t="/a9h.8/ara.h8h8/aqa.8x6h8.6/ah..hb/ada.h8p6x.p/ah..6h/ada.6hbpd..h..6...b.8...6/aaa.8h....8h.h8.6hbhb..hb/a.a.h8....a8.6x..8a6h..8hb/a?..6hb....hb.8..hb.8..x6hb/a?..8h....6h.hb.6h.hb.8.8a/a?..h8.....8.6h..8.6h.hbx/a.a.6hb....hb.8..hb.8.6h8/aaa.8h....6h.hb.6h.hb.8x/aaa.h8...b.8.6h..8.6h.a8/a[..b/ak..6hb.8h.hb.8..hb.8..h8/a-..8h6hb/ak..8h6h8.6h.h8.6hbhb.dh8/a~..h8h8hb/aj..h8h8hb.8.6hb.8h6h..6x/a~..6h8h8h/aj..dqdqda.q.pda.qdpd..pd/a-..8xdh8h..6...6/ag..6.....6/af..hb....h...h...h/a!..h8.6h8..hb..hb.6h6h.h8..hbh8.8...8hb.8.8h..8...8..hbhb/a5..6hbp6hb.8hb.8h8.8h8.8hb.6h8h8h8.6h8hbh8h8.6h8h6h8.6h8h/a6..8h..8h.x6hbx6x.h8hbx6hb.8x6x6hbpda8h6hfhb.fhf.fh8.8h8/a6..h8..h8.8.8a6pd.6xda8p6h.h8.8.8h..8h8.8h6h.hda6h6x.hfq/a6..6hb.6hbhbx.hb...8..hb.8.6hbhbh8.6x6hbh8.8.8...8.f.6h/a8..8h..8h6h8.6h...hb.6h.ab.8h6h6hb.8.8h6hbhbhb..h8h..8/a8..h8..hf.8x..8h..6h..8h.h.h8.8.8h6hbh8.8h6h6hb.6hf..hb/a7..6hb.6h.a8..a8...8..a8.6.6hbhbh8.8h6hbh8.8p6h.p6h..6h/a8..8h..f..h8..h8..hb..h8hb.8h6h6hbh8h8h6hbhb.8h..8h..8/a8..h8.6h8.dh8.dh8h6h..dh8a.h8.8.8hdh8h8.8h6h.a8hba8h.hb/a7..6hb.8hb.6x..6hf.8...6x..6hbhbh8.dxdx.h8.8..h8a.hf.6h/a7..pda.qda.pd..p6a.q...pd..pdadadq..d.d.dq.q..dx..da.pd/a)..p/a4..d/abv.d</a#..6hb/a%..p+?/a!..6h8/a^..dq?c/as..=/bf.l=l...h8hb/a%..pd<o.../bf.@y...~/an..lc.8$hh/a%..dq??..6/be.y@yq...lx/bf.@y@a.9hj86/a@..dqdqd<?c..31@y@y@y@eqda..~pd/bf.@y@al88hbb...hh/a5..dqdqd<??...+3{3g/bd.qd...cqdqd7/bd.y@[m~$h8hh...b8/a4..dqdq?????c..p{3{3/bd.dq...l/bd.dq{3{3{3{.k8hb8..66h.....b/ax..qdq+?????o...p{3/be.dq...ldqdqdqd3{3{3{3c*h86b8..b8....66h/aw..dq+/ag.?o...3{/be.qda..~pdqdqdq+3{3{3{.k8h$hbb.hh8~3..66h/av..qdqdq/af.?o..+3/be.dqd...cqdqdqdq{3{3{3c*h868hhbfhh2{3g.b8/av..dqdqdqd<????....qd..pdqdq.....ldqdqdqd3{3{3{.kb..h8h8yf.{3{a86h/av..q+???oqd<????..{a.2{3....~3g..~pdqdqdq+3{3{3cl.....8x@y{3{3ghh8/av..d<?????sd<??oa.x]ag2~3~3{3@y...cpdqdqdq{3{m..~.....h8y@y{3{366h/av..pd</ah.?o.6y..fx{3#a@y@a..@alhb/ai..h8.c.....x@yh4{3{3/ax..dqd.....???c@y3gq..x6y....pdqdl=6h8h8h86h8h8hblc....6yf8h8{3{3#a/af..h/an..qda/af..??o+3{3{3da...qdqdqdlc..8h8h8hb8h8h8...=l...@7h8{7h4{yf/af..8/an..dqd/ag..??o.3{3g/be.qdac.+3.6h8h8hh8h8.+(y..l..xf8$2g8}y@yf....6hb/an..dq/ah..?sda.+/be.qdq~p{3dqd/ai..+3{31@al.6ybj86h8@yf.....h8hb/an..da/ah..dqda....pdqda....c/be.qdq/bd.{3{m~..@ihjh8hz@ah8h8h886h/an..pd/ah..pdqd.8h8.....dq.abcp/bd.dqd/bd.3{m..c..@hh8h8$yf68hbj8hb8/ao..pd/af..d.qda.hh8.qdq...pdhh=p/bd.dqd3{3{3{..l=...x@hh8$x@y.j8hbj8hhb/ao..pd.....q.dqd.66hbdqo.wadq.hh=/ag..dq+3{m..da~.c...x@h8h@y@y.h8h$h86h/ap..pd.qdqdapd<?c86.q+?~udpda?chcqdapdqd.....daqd.$.c...x@y@y@yf...868hb8/aq..pd.qdqd.q+??c8.d<??gq?sd,o6ld.....pdqda..d.p.l~/af..@y@y/af..$h8hhb/ap..dqd.qdapdq??oh.q/af.?oq??._.pd.{ufpdqpy{q.qp.l=/ap..8h86h/ap..qdqd...dqdq??6./ah.?dqoald~s.3wagqd3e2ga+ca~l~/ap..8hbb/ao..q/bf.dq?c~/ah.?sd..~p.oad3u3dq+u[<jpjd.cj~/ao..h86h/am..dqdqdqo/bd.qd<o.~?o.????da.hbcq.dqdqd<?????&`^p.lcl/ao..6hhb/am..qd.dq+?oqdqdqdq+?6.~?????oq.h8hldq..qd</af.?`b.d.cl=/ap..hb/an..da..+???/bd.dq?c8..,???s.h8h8.ldqd.q/ag.?&pdq.6b.c/ao..6/ao..p....???sdqdqdqd<ohb/ai..8h..l....q?c..?&j....cj$.c/a5..a.tf,??oqdq+?dq+?6.@ye2{auy@a8...lhbb.p????j.66j~6^.~/a6..dt@yf,??dqdq??dq+?.xva.2...xfh....lhb8/af..66$bl.^^.c....p@y@i/aw..!y@y~??sdqd<?sdq+?6ap{~a3{mx/af..lhh8.qdqdhb^.c^^#^.c...0y@y@y@/au..t@a6a??oqdq+??sdq+?p{3cg+q+m/af..=...6....e....$'3^^.c../bd.y@i/as..pyf..,??dqdq??oqdq+c3{3c3ga+q.....lh8hb.qda.8h^b6^{%j~..p/bd.@y@i/ar..ppy..~???dqdq??oqdqd+3{pb3dp{q....~6h86hb..h8h8j~6^^^.c..^@y@y@y8x@....j/an..a!y..???sdqd<??oqdqpc3ci+3.3ga...lh8hh8hb.8h8h8j....~..6^^@y@y@h4w@..6^j/an..a.p~??cdq+sd<??oqdam+3c3{a.3g...c8h86hbh.h6h8h86blclc..^^j8x@yjb4xb..6b/ao..qdq??o.dq?s+???oqp{p{m+3ga+3d.~6h8hh86b..j6h8h,`b6bl.6^^8h4w@%hb8i/av..q+?..d<oq+????c..3c.+3gp{3..c8hb8h86^^bh8h8.<`^.~..^^j8h4x@8hh@/aw..q+c.p+?dq+???oxp{pda+3...6a.c86h8h8...8h8hbd<o.l..$^^8hh8x@86i/a2..q??dq+??c..mdqda+a.@yf~p..6h8hbq.h8h8.....c..6^^j8h8hy@y@/a2..d<??.q+?o,d+....pga....cpdm6h8pdq.h8h.qda~....^^^h8h80y@y@/a1..pd<?cdq+?~s.d3{3c...,oa.aq+/ak..c..l....$^^^h8hy@yby@/a1..q+?o.dq+?..q{m+3dq.~c.coa.h8p.auuuuual=lc.....$^^^^^@y@..yb/a1..q??..dq+cf+3{p{3da..~~??s....dtuuuue~/aj../af.^y@/a6..?c.....xp{m.p{3d6yf~..~c8hbp/ag..c....6b/ag..$^@y@/a@..@a3{a.3{q.@y.~l=.c...d3{3{3cl....$^b/ag..$^@yb/a!..xf+3d6a3gax@y...~ldqdq+3{3{m~.....$/ai..$z@/a!..x@yp{q.f+3gax@a...~pdqd3{3{3{.c/av..j/a5..6y@a...x....6yf....cqdqd3{3{3cl/au..6^j/a5..@yftud6ypuq.@yf..~pdqdqd3{3{m~/av..6b/a6..@ypuq.@aueq.@yf..c/be.qda~/ai1."
bit6to8(t,24576) 
scenex = 0
sceney = 0	
music (3)
end
	
if num == 1 then
--main menu init
tiles = {"start game ","controls","credits"}
numberoftiles = 3
selectedtile = 1
clcol1 = 14
clcol2 = 2
scenex = 16
sceney = 0	
end
	
if num == 2 then
scenex = 16
sceney = 0	
end
	
if num == 3 then
scenex = 16
sceney = 0	
end
	
if num == 4 then
scenex = 16
sceney = 0	
music (-1,18000)
end

if num == 5 then
scenex = 48    
sceney = 0	
track=12
end
	
if num == 6 then
scenex = 64
sceney = 0
end
	
if num == 7 then
scenex = 80
sceney = 0
end
	
if num == 8 then
clcol1 = 12
clcol2 = 1
scenex = 96
sceney = 0
track=0
end
	
if num == 9 then
scenex = 112
sceney = 0
end
	
if num == 10 then
scenex = 0
sceney = 16
end
	
if num == 11 then
clcol1 = 8
clcol2 = 2
scenex = 16
sceney = 16
track=7
end
	
if num == 12 then
scenex = 32
sceney = 16
end
	
if num == 13 then
scenex = 48
sceney = 16
end
	
if num == 14 then
clcol1 = 15
clcol2 = 12
scenex = 64
sceney = 16
track=3
end
	
if num == 15 then
scenex = 80
sceney = 16
end
	
if num == 16 then
scenex = 96
sceney = 16
end
	
if num == 17 then
scenex = 32
sceney = 0
end
	
level_objects (scenex,sceney)	
if num>4 then
music (track,3000)
end
end


-->8
-- collisions and level settings
-- some original code by zep 

-- is tile taken ?
function is_taken (x,y)
for a in all(actor) do
if (flr(a.x)==flr(x) 
and flr(a.y)==flr(y))
then return true
end
end
end

-- is tile with comrade ?
function is_same (a,x,y)
for b in all(actor) do
if (b.role==a.role 
or b.role=="portal" 
or b.role=="obstacle") then
if (flr(b.x)==flr(x) 
and flr(b.y)==flr(y))
then return true
end
end
end
end

-- is tile with enemy ?
function is_enemy (x,y)
for a in all(actor) do
if (a.role=="enemy") then
if (flr(a.x)==flr(x) 
and flr(a.y)==flr(y))
then return true
end
end
end
end

function solid(x, y)
-- grab the cell value
val=mget(x+scenex, y+sceney) 
-- check if flag 1 is set 
return fget(val, 1)
end

-- solid_area
function solid_area(x,y,w,h)
return 
solid(x-w,y-h) or
solid(x+w,y-h) or
solid(x-w,y+h) or
solid(x+w,y+h)
end

function solid_actor(a, dx, dy)
for a2 in all(actor) do
if (a2.subrole!="fireball") 
then	
if a2 != a then
local x=(a.x+dx) - a2.x
local y=(a.y+dy) - a2.y
if ((abs(x) < (a.w+a2.w)) and
(abs(y) < (a.h+a2.h)))
then    
    -- moving together?
if (dx != 0 and abs(x) <
abs(a.x-a2.x)) then
v=a.dx + a2.dy
a.dx = v/2
if (a2.still== false
and a.role=="player") then
a2.dx = v/2
end
return true 
end
    
if (dy != 0 and abs(y) <
abs(a.y-a2.y)) then
v=a.dy + a2.dy
a.dy=v/2
if (a2.still == false
and a.role=="player") then
a2.dy=v/2
end
return true 
end
    
--return true
end
end
end
end
return false
end
 
-- checks both walls and actors
function solid_a(a, dx, dy)
if solid_area(a.x+dx,a.y+dy,
a.w,a.h) then    
return true end
return solid_actor(a, dx, dy)  
end

function move_actor(a)
-- only move actor along x
-- if the resulting position
-- will not overlap with a wall
if not solid_a(a, a.dx, 0) 
then
a.x += a.dx
else 
a.dx *= -a.bounce
end
-- ditto for y
if not solid_a(a, 0, a.dy) 
then
a.y += a.dy
else 
a.dy *= -a.bounce
end   
a.dx *= a.inertia
a.dy *= a.inertia
 
--move the zombis and enemies
move_enemy () 
end

--replace tiles by items/actors
function level_objects (a,b)
for x=0,15 do
for y=0,15 do
 -- player
if mget(x+a, y+b) == 16 then
pl.x = x+0.5
pl.y = y+0.5
mset (x+a,y+b,146)  
end
-- portal 
if mget(x+a, y+b) == 185 then
create_portal (x,y)
mset (x+a,y+b,146)  
end
--end area
if mget(x+a, y+b) == 163 then
endx = x
endy = y
mset (x+a,y+b,146)  
end
-- skull
if mget(x+a, y+b) == 179 then
make_item (a,"skull",179,x+0.5,y+0.5,10)
mset (x+a,y+b,146) 
end
-- potion
if mget(x+a, y+b) == 182 then
if (is_death==false) then
make_item (a,"potion",182,x+0.5,y+0.5,14)
else 
for a in all(item) do
if (a.name=="potion") then
a.y = (flr (a.y))+0.5
end
end
end
mset (x+a,y+b,146) 
end
-- worm
if mget(x+a, y+b) == 112 then
create_worm (x,y)
mset (x+a,y+b,146) 
end
-- sanctuary
if mget(x+a, y+b) == 186 then
create_sanctuary (x,y)
mset (x+a,y+b,146)  
end
-- block
if mget(x+a, y+b) == 164 then
create_block (x,y)
mset (x+a,y+b,146)  
end
-- specter
if mget(x+a, y+b) == 80 then
create_specter (x,y)
mset (x+a,y+b,146) 
end
-- flame
if mget(x+a, y+b) == 166 then
create_flame (x,y)
mset (x+a,y+b,167) 
end
-- fountain
if mget(x+a, y+b) == 86 then
create_fountain (x,y)
mset (x+a,y+b,88) 
end
-- eye
if mget(x+a, y+b) == 67 then
create_eye (x,y)
mset (x+a,y+b,146) 
end
-- gargoyle
if mget(x+a, y+b) == 117 then
create_gargoyle (x,y)
mset (x+a,y+b,246) 
end
end
end
end

	
-->8
--zombis & enemies behaviour

--try a zombi invocation
function wakeup_zombi ()	
--define pl targetted tile
	if (pl.targ == 0) 
	then tx=pl.x-1 ty=pl.y 
 elseif (pl.targ == 1) 
 then tx=pl.x+1 ty=pl.y
 elseif (pl.targ == 2) 
 then tx=pl.x ty=pl.y-1
 elseif (pl.targ == 3) 
 then tx=pl.x ty=pl.y+1
 end
--check if the tile is free
--check is zombi number is fine
if (solid(tx,ty)==false
	and pl.zombi_nb>0 
	and not is_taken (tx,ty)==true)
	then
	
if (pl.targ == 0 or pl.targ == 1) 
 then pl.state="invoc"
 elseif (pl.targ == 2) 
 then pl.state="invoct"
 elseif (pl.targ == 3) 
 then pl.state="invocd"
end
 
--save player position
temp_targ=pl.targ
temp_flp=pl.flp 
pl.cooldown =14
sfx (61,3,0,11) 
--	invocation fx 1
ifx1 = make_actor (tx,ty)
ifx1.role = "fx"
ifx1.subrole = "invocation1"
ifx1.still = true
ifx1.chest = true
ifx1.item = "skull"
ifx1.itcolor = 10
ifx1.itsprite = 179
ifx1.idle={f=39,n=4,spd=8}
	
-- invocation fx 2
ifx2 = make_fx (tx,ty)
ifx2.idle={f=35,n=4,spd=12}	
make_iparticles (tx,ty,8,10,9,26)
	
else	
	if (pl.targ == 0 or pl.targ == 1) 
 then pl.state="fail"
 elseif (pl.targ == 2) 
 then pl.state="failt"
 elseif (pl.targ == 3) 
 then pl.state="faild"
 end
--fail to create a zombi
 sfx (62,3,8,1)
 make_iexplosion (tx,ty,8,6,1.6,true)
	end 	
end
	
function create_zombi () 	
	--create zombi actor
	if (pl.zombi_nb>0) then
	pl.zombi_nb -= 1
	zb ={}
 zb = make_actor (tx,ty) 
 zb.role = "zombi"
 zb.flp= temp_flp
 zb.targ = temp_targ
 zb.orv=0
 zb.head = 32
 zb.headt = 34
 zb.headd = 33
 zb.chest = true
 zb.item = "skull"
 zb.itcolor = 10
 zb.itsprite = 179
 zb.idle={f=50,n=1,spd=0}
 zb.idlet={f=60,n=1,spd=0}
 zb.idled={f=55,n=1,spd=0}
 zb.walk={f=50,n=4,spd=7}
 zb.walkt={f=60,n=4,spd=7}
 zb.walkd={f=55,n=4,spd=7}
 zb.attack={f=49,n=2,spd=8}
 zb.attackt={f=59,n=2,spd=8}
 zb.attackd={f=54,n=2,spd=8}
 end
end 

function move_block ()
for a in all(actor) do
if (a.subrole=="block") then
if (a.x!=flr(a.x)+0.5 
or a.y!=flr(a.y)+0.5) then
if (block_road!=0) then
block_road-=1
else 
block_road = 10 
reinit_position (a)
sfx (62,3,7,1)
end
end
end
end
end

function move_enemy ()
 for a in all(actor) do
	if (a.role=="zombi" 
	or a.subrole=="specter" 
	or a.subrole=="eye"
	or (a.subrole=="gargoyle" and a.still==false)) 
	then
 --define z targetted tile
	if (a.targ == 0) 
	then a.ztx=a.x-0.6 a.zty=a.y 
 elseif (a.targ == 1) 
 then a.ztx=a.x+0.6 a.zty=a.y
 elseif (a.targ == 2) 
 then a.ztx=a.x a.zty=a.y-0.6
 elseif (a.targ == 3) 
 then a.ztx=a.x a.zty=a.y+0.6
 end
 -- move, attack or change direction
	if (not is_taken (a.ztx,a.zty)
	or is_same (a,a.ztx,a.zty))
 then
	deplacement (a)
else

--attack 
reinit_position (a)

for b in all(actor) do
if (flr(b.x)==flr(a.ztx)
	and flr(b.y)==flr(a.zty)
	and b.role!="zombi" 
	and b.role!="obstacle"
	and b.subrole!="invocation1"
	)
 then
if (a.targ == 0) then 
a.flp = true
a.state="attack"
elseif (a.targ==1) 
then 
a.flp = false
a.state="attack" 
elseif (a.targ == 2)
then a.state="attackt"
elseif (a.targ == 3)
then a.state="attackd"
end
if (particles_timer==10) then
sfx (61,3,17,7)
end
anim_attack (a.ztx,a.zty,a.targ,a.flp)
 a.spd = 0
 b.spd = 0
 b.life -= 10
 a.spd = 0.07
end
end
end
end
end
end

function anim_attack (x,y,targ,flp)
--	attack fx
zafx = make_attack (x,y,targ,flp)
zafx.flp = flp
zafx.state="idle"
zafx.idle={f=43,n=3,spd=8}
end

function take_direction (a,x,y,targ)
check_direction (a,x,y)
reinit_position (a)
--zombi choose direction
if (a.targ == 0) then
if (a.tile2==true) then
a.targ=2 
elseif (a.tile3==true) then
a.targ=3 
elseif (a.tile1==true) then
a.targ=1
end

elseif (a.targ == 1) then
if (a.tile3==true) then
a.targ=3 
elseif (a.tile2==true) then
a.targ=2 
elseif (a.tile0==true) then
a.targ=0
end

elseif (a.targ == 2) then
if (a.tile1==true) then
a.targ=1 
elseif (a.tile0==true) then
a.targ=0 
elseif (a.tile3==true) then
a.targ=3
end

elseif (a.targ == 3) then
if (a.tile0==true) then
a.targ=0 
elseif (a.tile1==true) then
a.targ=1 
elseif (a.tile2==true) then
a.targ=2
end

end
end

function check_direction (a,x,y)
--reinit check
a.tile0 = true
a.tile1 = true
a.tile2 = true
a.tile3 = true
--zombi check empty tiles
if (solid_a(a,-1, 0) 
and not is_taken (x-1,y) or is_same (a,x-1,y))
then a.tile0=false
end
if (solid_a(a,1, 0) 
and not is_taken (x+1,y) or is_same (a,x+1,y)) 
then a.tile1=false
end
if (solid_a(a,0, -1) 
and not is_taken (x,y-1) or is_same (a,x,y-1))
then a.tile2=false
end
if (solid_a(a,0, 1) 
and not is_taken (x,y+1) or is_same (a,x,y+1))
then a.tile3=false
end
end

--demon worm 
function move_worm ()
for a in all(actor) do
	if (a.subrole=="worm") 
	then
	--fireball cooldown
	if (a.fireball_cooldown>0)
	then a.fireball_cooldown -= 1
	end
	if (pl.x>=a.x) then
	a.flp=true
	a.firestarter=-1
	a.fireballx = 0.2
	else 
	a.flp=false
	a.firestarter=1
	a.fireballx = -1.2
	end
	for b in all(actor) do
	if (b.role == "zombi"
	or b.role == "player" 
	or b.subrole=="invocation1") then
	if (flr(b.y)==flr(a.y) 
	and (a.x-b.x)*a.firestarter>0
	and a.fireball_cooldown<=0) then
	a.state="attack"
	a.fireball_cooldown=30
	create_fireball 
	(a.x+a.fireballx,a.y-0.8,a.flp)
	end
	if (a.fireball_cooldown<20) then
	a.state="idle"
	end
	end
	end
	end
end
end

function move_fireball ()
for a in all(actor) do
if (a.subrole=="fireball") 
then	
if (a.flp==true) then
if not solid_a(a,0.4,0.4) 
then
a.x += 0.2  
else  
fireball_attack (a.x+0.8,a.y)  
a.life=0
end
else 
if not solid_a(a,-0.4,0.4) 
then
a.x -= 0.2  
else 
fireball_attack (a.x-0.8,a.y)
a.life=0
end
end
end
end
end

function fireball_attack (x,y)
anim_attack (x,y,0,true)
for b in all(actor) do
if (b.role != "enemy"
and b.role!="obstacle") 
then
if ((flr(b.x)==flr(x)
and (flr(b.y-0.5)==flr(y)
or (flr(b.y+0.2)==flr(y))
)))
then
b.life -= 130
end
end
end
end

--deplacement
function deplacement (a)
if (a.targ == 0) then
if not solid_a(a, a.dx, 0) 
then
a.state="walk"
a.flp = true
a.dx = -(a.spd)
else
take_direction (a,a.x,a.y,a.targ) 
end
	
elseif (a.targ == 1) then
if not solid_a(a, a.dx, 0) 
then
a.state="walk"
a.flp = false
a.dx = a.spd
else 
take_direction (a,a.x,a.y,a.targ) 
end
elseif (a.targ == 2) then
if not solid_a(a, 0, a.dy) 
then
a.state="walkt"
a.dy = -(a.spd)
else
take_direction (a,a.x,a.y,a.targ)  
end
	
elseif (a.targ == 3) then
if not solid_a(a, 0, a.dy)  
then
a.state="walkd"
a.dy = a.spd
else 
take_direction (a,a.x,a.y,a.targ) 
end	
end
--eye behaviour
for b in all(actor) do
if (b.subrole == "eye") then
if (flr(b.x)==flr(pl.x)) 
or (flr(b.y)==flr(pl.y)) then		
if (flr(b.x)==flr(pl.x) 
and (flr(b.y)<=flr(pl.y))) then
b.targ=3
elseif
(flr(b.x)==flr(pl.x) 
and (flr(b.y)>=flr(pl.y))) then
b.targ=2
elseif (flr(b.x)<=flr(pl.x) 
and (flr(b.y)==flr(pl.y))) then
b.targ=1
elseif (flr(b.x)>=flr(pl.x) 
and (flr(b.y)==flr(pl.y))) then
b.targ=0
end
if (targetlock==false) then
reinit_position (b)
end
b.spd=0.13
targetlock=true
else
b.spd = 0.07
b.targetlock=false
end
end
end
end

-->8
-- hud,enemies & items creation

--enemies

function enemy_death ()
for a in all(actor) do
if (a.role!="player" and a.life<=0) then
if (a.chest==true) then
--fx stop
if (a.subrole=="invocation1") then
del (fx,ifx2)
end
make_item (a,a.item,a.itsprite,a.x,a.y,a.itcolor)
end
sfx (61,3,17,7)
del (actor,a)
make_iexplosion (a.x,a.y,8,a.color,3,true)
if (pl.life<=0) then
sfx (63,3,0,4)
enemy_extinction=true
end
end
end
end


--create enemies
function create_sanctuary (x,y)
	ensa ={}
 ensa = make_actor (x+0.5,y+0.5) 
 ensa.role = "enemy"
 ensa.subrole= "sanctuary"
 ensa.still=true
 ensa.life = 1400
 ensa.color = 6
 ensa.head = 170
 ensa.idle={f=186,n=1,spd=0}
 ensa.chest = true
 ensa.item = "orb"
 ensa.itcolor = 12
 ensa.itsprite = 177
 pl.orb_max +=1
end

function create_block (x,y)
	obbl ={}
 obbl = make_actor (x+0.5,y+0.5) 
 obbl.role = "obstacle"
 obbl.subrole= "block"
 obbl.color = 6
 obbl.inertia = 0.87
 obbl.w  = 0.4
 obbl.h  = 0.4
 obbl.idle={f=164,n=1,spd=0}
 obbl.chest = false
end

function create_worm (x,y)
	enwo ={}
 enwo = make_actor (x+0.5,y+0.5) 
 enwo.role = "enemy"
 enwo.subrole= "worm"
 enwo.still=true
 enwo.life = 1400
 enwo.fireball_cooldown = 0
 enwo.color = 8
 enwo.head = 96
 enwo.idle={f=112,n=2,spd=2}
 enwo.attack={f=112,n=5,spd=10}
 enwo.chest = false
end

function create_specter (x,y)
	ensp ={}
 ensp = make_actor (x+0.5,y+0.5) 
 ensp.role = "enemy"
 ensp.subrole= "specter"
 ensp.life=1400
 ensp.color = 15
	ensp.head = 64
 ensp.headt = 66
 ensp.headd = 65
 ensp.idle={f=80,n=1,spd=0}
 ensp.walk={f=80,n=2,spd=5}
 ensp.walkd={f=82,n=2,spd=5}
 ensp.walkt={f=84,n=2,spd=5}
 ensp.attack={f=80,n=2,spd=8}
 ensp.attackt={f=82,n=2,spd=8}
 ensp.attackd={f=84,n=2,spd=8}
end

function create_eye (x,y)
	eney ={}
 eney = make_actor (x+0.5,y+0.5) 
 eney.role = "enemy"
 eney.subrole= "eye"
 eney.life=700
 eney.color = 8
 eney.frame = 71
 eney.targetlock=false
 eney.idle={f=67,n=4,spd=5}
 eney.walk={f=67,n=4,spd=5}
 eney.walkd={f=70,n=1,spd=5}
 eney.walkt={f=70,n=1,spd=5}
 eney.attack={f=67,n=4,spd=5}
 eney.attackt={f=67,n=4,spd=5}
 eney.attackd={f=67,n=4,spd=5}
end

function create_gargoyle (x,y)
	enga ={}
 enga = make_actor (x+0.5,y+0.5) 
 enga.role = "obstacle"
 enga.subrole= "gargoyle"
	enga.life=300
 enga.still=true
 enga.color = 8
 enga.frame = 71
 enga.spd=0.1
 enga.head = 101
 enga.idle={f=117,n=1,spd=5}
 enga.walk={f=118,n=2,spd=5}
 enga.walkd={f=120,n=2,spd=5}
 enga.walkt={f=122,n=2,spd=5}
 enga.attack={f=118,n=2,spd=7}
 enga.attackt={f=120,n=2,spd=7}
 enga.attackd={f=122,n=2,spd=7}
end

function create_fireball (x,y,flp)
	enfb ={}
 enfb = make_actor (x+0.5,y+0.5) 
 enfb.role = "enemy"
 enfb.subrole= "fireball"
 enfb.life = 5000
 enfb.w = 0.1
 enfb.h = 0.3
 enfb.color = 9
 enfb.flp = flp
 enfb.idle={f=97,n=2,spd=4}
end

function sanctuary_particles ()
for a in all (actor) do
	if (a.subrole=="sanctuary" 
	and particles_timer==20) then
	make_iparticles (a.x,a.y-0.8,2,12,7,18)
	end
end
particles_timer -=1
if (particles_timer <= 0) then
particles_timer=20
end
end

function create_portal (x,y) 
	is_portal=true
 port ={}
 port = make_actor (x+0.5,y+0.5) 
 port.role = "portal"
 port.still=true
 port.w = 0.4
 port.h = 0.4
 port.color = 12
 port.idle={f=185,n=1,spd=0}
 port.chest = false
end

function open_portal ()
	if (pl.orb_nb >=pl.orb_max 
	and pl.orb_max > 0 
	and is_open==false) then
	is_open=true
	sfx (62,3,0,7)
	make_iexplosion (port.x,port.y,4,12,2.5,true)
	make_iparticles (port.x,port.y,4,12,7,32)
	--gargoyle waking
	for a in all(actor) do
	if (a.subrole=="gargoyle") 
	then
	a.role="enemy"
	a.still=false
	a.head = 102
 a.headt = 106
 a.headd = 104
	end
	end
	del (actor,port)
	end
end

--items
function make_item (e,n,s,x,y,c)
 a={}
 a.x = x
 a.y = y
 a.name = n
 a.sprite= s
 a.color = c
 a.state="idle"
	a.idle={f=a.sprite,n=2,spd=6}
	a.shadowy = y
	a.shadowsy = (a.shadowy * 8) -4
	add (item,a)
end

function draw_item(a)
 a.sx = (a.x * 8)-4
 a.sy = (a.y * 8)-4
	spr (anim_actor (a),a.sx,a.sy-3,1,1,a.flp,false)
end

function move_item ()
	for a in all(item) do
	if (particles_timer>=11) then
	a.y -= 0.04	
	else
	a.y += 0.04	
	end
	end
end

function take_item ()
for a in all(item) do
	if (flr(pl.x)==flr(a.x) and flr(pl.y)==flr(a.y)) then
	if (a.name=="orb") then
	pl.orb_nb += 1
	elseif (a.name=="skull") then
	pl.zombi_nb +=1
	elseif (a.name=="potion") then
	pl.potion_nb +=1
	end	
	pl.take_cooldown=10
 pl.state="invocd"
 sfx (61,3,13,4)
	make_iexplosion (a.x+0.5,a.y-0.9,1,a.color,3,false)
	del (item,a)
 end
 end
end

--hud
function draw_hud ()
--orbs
spr (177,4,4,1,1)
highlighttext (pl.orb_nb.."/"..pl.orb_max,13,4,12)
--skulls
for i=1,pl.zombi_max do
spr (181,28+(i*8),2,1,1)
end
for i=1,(pl.zombi_nb) do
spr (179,28+(i*8),2,1,1)
end
--potion
spr (182,74,2,1,1)
highlighttext (pl.potion_nb,83,4,6)
end







-->8
--fxs

-- text fx
function highlighttext (f,x,y,col)
	print (f,x,y+1,0)
	print (f,x+1,y,0)
	print (f,x,y-1,0)
	print (f,x-1,y,0)
	print (f,x,y,col)
end

function highlightsprite (sx,sy,sw,sh,dx,dy,w,h)
	pal (8,0)
	sspr (sx,sy,sw,sh,dx,dy+1,w,h)
	sspr (sx,sy,sw,sh,dx+1,dy,w,h)
	sspr (sx,sy,sw,sh,dx,dy-1,w,h)
	sspr (sx,sy,sw,sh,dx-1,dy,w,h)
	pal (8,8)
	sspr (sx,sy,sw,sh,dx,dy,w,h)
end

--flame fx
function create_flame (x,y)
	flfx = make_actor (x+0.5,y+0.5)
	flfx.role = "obstacle"
	flfx.still = true
	flfx.idle={f=166,n=3,spd=10}
end

--fountain fx
function create_fountain (x,y)
	flfx = make_actor (x+0.5,y+0.5)
	flfx.role = "obstacle"
	flfx.idle={f=86,n=3,spd=6}
end

--make a fx
function make_fx(x, y)
return add(fx,{
x = x,
y = y,
state="idle",
dx = 0,
dy = 0,
acc= 0.01
}) 
end

--draw fxs
function draw_fx(a)
a.sx = (a.x * 8) - 4
a.sy = (a.y * 8) - 4 
spr (anim_actor (a),a.sx,a.sy,1,1,a.flp,false)
end

function move_ifx ()
	for ifx2 in all(fx) do
	if (ifx2.subrole!="wing") then
	ifx2.dy += ifx2.acc
	ifx2.y -= ifx2.dy
	else
	spr (a.head,a.sx,
	a.hat,1,1,a.flp,false)	
	end
	end
end

--make a attack
function make_attack(x,y,targ,flp)
 a={}
 if (targ == 0) then
 a.x = x+0.2
 a.y = y-0.1
 elseif (targ == 1) then
 a.x = x-0.2
 a.y = y-0.1
 elseif (targ == 2) then
 a.x = x
 a.y = y-0.7
 elseif (targ == 3) then
	a.x = x
 a.y = y-0.6
 end
 a.dx = 0
 a.dy = 0
 a.flp = flp
	a.cooldown = 1

 add(attack,a)
 
	return a
end

function draw_attack(a)
 a.sx = (a.x * 8) - 4
 a.sy = (a.y * 8) - 4
 --fx-- 
spr (anim_actor (a),a.sx,a.sy,1,1,a.flp,false)
a.cooldown -= 1
	if (a.cooldown<= 0) then
	del (attack,a)	
	end
end

function make_iparticles (x,y,nb,c1,c2,f)
--create invocation particles
 	while (nb> 0 ) do
 	ipart = {}
 	ipart.x = ((x* 8))+(flr((rnd(6)-3)))
 	ipart.y = ((y* 8))+(flr((rnd(6)-3)))
 	ipart.col = c1
 	ipart.col2 = c2
 	ipart.dx = 0
 	ipart.dy = (flr(rnd (3)) -4)/6
 	ipart.f = 1
 	ipart.maxf = f
 	add (particle,ipart)
 	nb -=1
 	end	
end

function draw_iparticles ()	
	for ipart in all(particle) do
	if (ipart.f == ipart.maxf-2) then
	ipart.col = ipart.col2
	end
	pset (ipart.x,ipart.y,ipart.col)
	ipart.x += ipart.dx
	ipart.y += ipart.dy
	ipart.f += 1
	if (ipart.f > ipart.maxf) then
	del (particle,ipart)	
	end
	end
end

function make_iexplosion (x,y,nb,c,r,multiple)
--create smoke
	while (nb> 0) do
	iexplo = {}
	if (multiple==true) then
	iexplo.x = ((x* 8))+(flr((rnd(6)-3)))
 iexplo.y = ((y* 8))+(flr((rnd(6)-3)))
	else
	iexplo.x = (x* 8)-4
 iexplo.y = (y* 8)-4
 end
	iexplo.r = r
	iexplo.c = c
	add (explosion,iexplo)
	nb -= 1
	end
end

function draw_iexplosions ()
	for iexplo in all (explosion) do
	circfill (iexplo.x,iexplo.y,iexplo.r,iexplo.c)
	iexplo.r -=0.4
	if (iexplo.r <= 0) then del (explosion,iexplo)
	end
end
end

--create clouds
function make_clouds (cy)
	while (cloud_nb> 0) do
	cloud = {}
	if (cloud_nb>12) 
	then
	cloud.x = flr(rnd(128))
	else
	cloud.x = flr(rnd(110)+140)
	end
 cloud.y = flr(rnd(5)+cy)
	cloud.r = flr(rnd(8)+2)
	add (clouds,cloud)	
	cloud_nb-= 1
	end
end

function draw_clouds ()
	for cloud in all (clouds) do
	circfill (cloud.x,cloud.y,cloud.r,clcol1)
	circfill (cloud.x-2,cloud.y+1,cloud.r,clcol2)
	cloud.x -=0.4
	if (cloud.x <= -cloud.r*2) 
	then del (clouds,cloud)
	cloud_nb+=1	
	end
end
end

--create air particles
function make_aparticles (nb) 
 	if (maxapart>0) then
 	while (nb> 0 ) do
 	apart = {}
 	apart.x = flr(rnd (90))+128
 	apart.y = flr(rnd (90))+32
 	apart.col = 2
 	apart.dx = 1
 	apart.dy = rnd (2)-1
 	add (aparticle,apart)
 	nb-= 1
 	maxapart-= 1
 	end
 	end
end

function draw_aparticles ()	
	for apart in all(aparticle) do
	pset (apart.x,apart.y,apart.col)
	apart.x -= apart.dx
	apart.y += apart.dy
	if (apart.x < 0 or apart.y>128 or apart.y<0) then
	del (aparticle,apart)	
	maxapart += 1
	end
	end
end

--screenshake
function screenshake (nb,intensity)
scr.shake = nb
scr.intensity = intensity
end

function camera_pos ()
if (scr.shake > 0) then
scr.x = (rnd(2)-1)*scr.intensity
scr.y = (rnd(2)-1)*scr.intensity
scr.shake -= 1
bwcolor_fx ()
else
pal ()
palt(14, true)
palt(0, false)
scr.x = 0
scr.y = 0
end
camera (scr.x,scr.y)
end

function bwcolor_fx ()
pal (1,5)
pal (2,5)
pal (3,6)
pal (4,7)
pal (9,6)
pal (10,6)
pal (14,6)
pal (15,7)
end

-->8
-- new data compressor
-- from the lab of dw817

function initglobal()
chr6x,asc6x={},{}
local b6=".abcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()`~-_=+[]{};':,<>?"
local i,c
for i=0,63 do
c=sub(b6,i+1,i+1)
chr6x[i]=c asc6x[c]=i
end
end

function chr6(a)
local r=chr6x[a]
if (r=="" or r==nil) r="."
return r
end

function btst(a,b)
local r=false
if (band(a,2^b)>0) r=true
return r
end

function fnca(a,b)
local r=asc6x[sub(a,b,b)]
if (r=="" or r==nil) r=0
return r
end

function strng(a,b)
local i,r=0,""
for i=1,a do
r=r..b
end
return r
end

function bit6to8(t,m)
local i,d,e,f,n,p=0,0,0,0,0,1
repeat
if sub(t,p,p)=="/" then
d=fnca(t,p+1)
e=fnca(t,p+2)+64*fnca(t,p+3)
t=sub(t,1,p-1)..strng(e,sub(t,p+4,p+4+d-1))..sub(t,p+d+4)
p+=d*e-1
end
p+=1
until p>=#t
p=1 d=0 e=0
for i=1,#t do
c=fnca(t,i)
for n=0,5 do
if (btst(c,n)) e+=2^d
d+=1
if (d==8) poke(m+f,e) d=0 e=0 f+=1
end
end
end

initglobal()

 


-->8
--update & draw
function _update ()
	if (scene=="menu") then
	update_menu ()
	elseif (scene=="game") then
	update_game ()
	end
end

function _draw ()
camera_pos ()
palt(14, true)
palt(0, false)
	if (scene=="menu") then
	draw_menu ()
	elseif (scene=="game") then
	draw_game ()
	end
end

function reset_game ()	
for b in all(item) do
del (item,b) 
end
is_death=false
pl.potion_nb=3
reload()
scene_num=0
load_scene (scene_num)
enemy_extinction=false
end

function draw_actor(a)
 a.sx = (a.x * 8) - 4
 a.sy = (a.y * 8) - 4
 a.hat = a.sy-8
 --actors-- 
 if (a.subrole!="eye") then
spr (anim_actor (a),a.sx,a.sy,1,1,a.flp,false)
else
spr (anim_actor (a),a.sx,a.sy-2,1,1,a.flp,false)
end
end

function draw_eyewings ()
--wings & shadow for eyes			
for a in all(actor) do
	if (a.subrole=="eye") then	
	spr (flr(a.frame),a.sx-8,a.sy-3,1,1,true,false)
	spr (flr(a.frame),a.sx+8,a.sy-3,1,1,false,false)
	
a.frame += 0.025
if a.frame>=74 then
a.frame=71
end
end
end
end

function gargwings(a)
	pal (8,13)
	pal (2,6)
	spr (flr(a.frame),a.sx-5,a.sy-5,1,1,true,false)
	spr (flr(a.frame),a.sx+5,a.sy-5,1,1,false,false)	
	pal (8,8)
	pal (2,2)
a.frame += 0.025
if a.frame>=74 then
a.frame=71
end
end

function draw_gargwings ()
--wings for gargoyles
for a in all(actor) do
if (a.subrole=="gargoyle" and a.still==false and a.state!="walkt") then	
gargwings (a)
end
end
end

function draw_gargwingstop ()
--wings for gargoyles
for a in all(actor) do
if (a.subrole=="gargoyle" and a.still==false and a.state=="walkt") then	
gargwings (a)
end
end
end

function put_head ()
--draw portal columns
	if (is_portal==true) then
	spr (184,port.sx+9,port.sy,1,1,true,false)
	spr (184,port.sx-9,port.sy,1,1,false,false)
end

--here is your head--
for a in all(actor) do
	if (a.head!=nil) then
	if (a.targ == 0 or a.targ == 1) then
	spr (a.head,a.sx,
	a.hat,1,1,a.flp,false)
	elseif (a.targ == 2) then
	spr (a.headt,a.sx,
	a.hat,1,1,a.flp,false)
	elseif (a.targ == 3) then
	spr (a.headd,a.sx,
	a.hat,1,1,a.flp,false)
	end
	end
	end
end

function draw_game ()
cls (1)
--draw moon--
pal (6,clcol1)
spr (155,100,6,1,1)
pal (6,6)
draw_clouds ()

map (scenex,sceney,0,0,16,16)

--item shadow
for a in all (item) do
spr (176,a.sx,a.shadowsy,1,1)
end

--eye shadow
for a in all (actor) do
if  (a.subrole=="eye") then	
a.sx = (a.x * 8) - 4
 a.sy = (a.y * 8) - 4
 a.hat = a.sy-8
	pal (2,0)
	spr (176,a.sx,a.sy+2,1,1)
	pal (2,2)
end
end

--draw explosion
	draw_iexplosions ()
	
--draw gargoyle wings
foreach(actor,draw_gargwings)

--draw actors
foreach(actor,draw_actor)
	
--draw wings
foreach(actor,draw_eyewings)
foreach(actor,draw_gargwingstop)

--draw particles
draw_iparticles ()
	
--draw fx
foreach(fx,draw_fx)

--put head
put_head ()

--draw hero's hat--
spr (1,pl.sx,pl.sy-8,1,1,pl.flp,false)

--draw_item
foreach (item,draw_item)

--draw_item
foreach (item,draw_item)

--draw game over--
if (gameover==true) then
	highlightsprite (0,96,64,8,33,60,64,8)
	if (pl.potion_nb>0) then
	rectfill (0,71,128,89,0)
	sspr (48,88,8,8,83,72,8,8)
	highlighttext ("❎ retry (    )",35,74,8)
	highlighttext ("-1",75,74,6)
	highlighttext ("🅾️+❎ quit",45,82,8)
	else
	rectfill (0,71,128,81,0)
	highlighttext ("🅾️+❎ quit",45,74,8)
	end
end

--draw level clear
if (end_scene==true and gameover==false) then
if (endtitle_dw>72)then 
endtitle_dw=flr(((main_timer^2)/30)*4.8)-44
else
endtitle_dw=72
rectfill (0,71,128,81,0)
highlighttext ("❎ continue",42,74,8)

end
highlightsprite (0,104,72,8,((128-endtitle_dw)/2)+2,(128-(endtitle_dw)/9)/2,endtitle_dw,endtitle_dw/9)
	
end

--air particles
draw_aparticles ()	

--draw attack
if (gameover_timer <=30) then
foreach(attack,draw_attack)
end 
draw_hud ()

--retry system
if (pl.retry_cooldown >0) then
rectfill (0,115,128,125,0)
if (pl.potion_nb>0) then
highlighttext ("hold 🅾️ to quit and retry",7,118,8) 
else
highlighttext ("hold 🅾️ to abandon all hope",7,118,8) 
end
end
palt()
--print ("track "..track,0,8)
end

function update_game ()
-- if player is alive control it
if (paralisis == false) then
controls()
end

--retry system
if (pl.retry_cooldown >60) then
pl.retry_cooldown =0
pl.life=0
end

move_ifx ()
move_item ()
make_clouds (17)
make_aparticles (2)
sanctuary_particles ()
foreach (actor, move_actor)
move_worm ()
move_fireball ()
move_block ()
take_item ()

--delete fx
if (pl.cooldown==1) then
if (ifx1.life>=0) then
del (actor,ifx1)
del (fx,ifx2)
create_zombi ()
else
pl.zombi_nb -= 1
end
end

--check level clear
end_level ()
--portal opened
open_portal ()
--check player death
enemy_death ()
--check player death
pl_death ()

--game over menu
if (gameover==true and enemy_extinction==true) then	
music (-1,5000) 
if (btnp(4) and btnp(5) ) then	
reset_game ()
end
	
if (pl.potion_nb>0) then	
if (btn(5) and not btn (4)) then
	for b in all(item) do
	if (b.name!="potion") then 
 del (item,b)
	end
	end
	is_death=true
	reload()
	pl.potion_nb -= 1
	load_scene (scene_num)
	screenshake (3,0)
	enemy_extinction=false
	end
	end
end

--scene ending cooldown
if (end_scene==true and gameover==false) then
music (-1,5000) 
main_timer -=1
if 	(btn(5)) and main_timer<=20 then
scene_num +=1
if (scene_num==17) then
for a in all(clouds) do
a.y += 72
end	
end
load_scene (scene_num)
screenshake (3,0)
end
end
end

--menu
function update_menu ()
--main screen
if (scene_num==0) then
if 	(btnp(5) 
and end_scene==false)	then
--cloud reinit
for a in all(clouds) do
a.y += 72
end	
end_scene=true
scene_num =1
load_scene (scene_num)
end
--main menu
elseif (scene_num==1) then
if(btnp(2)) then
if selectedtile > 1
then sfx (61,3,13,4) end
selectedtile-=1
elseif(btnp(3)) then
if selectedtile < numberoftiles
then sfx (61,3,13,4) end
selectedtile+=1	
elseif(btnp(5)) then
if(selectedtile==1)then
scene_num=4
elseif(selectedtile==2)then
scene_num=2
elseif(selectedtile==3)then
scene_num=3
end
end_scene=true	
load_scene (scene_num)
	
end
--menu tiles limit
if(selectedtile < 1) then
selectedtile = 1
elseif(selectedtile > numberoftiles) then
selectedtile = numberoftiles
end 
--credits & controls
elseif (scene_num==2 or scene_num==3) then
if 	(btnp(4) 
and end_scene==false)	then
scene_num =1
load_scene (scene_num)
		
end
--introduction
elseif (scene_num==4) then
if 	(btnp(5) 
and end_scene==false)	then
for a in all(clouds) do
a.y -= 72
end
scene_num =5
load_scene (scene_num)	
screenshake (3,0)
end

elseif (scene_num==17) then
if (btn(4) and btn(5)) then	
reset_game ()
end
end
end

function draw_menu ()
if scene_num!=0 then
cls (1)
--draw moon
pal (6,clcol1)
spr (155,100,78,1,1)
pal(6,6)
make_clouds (89)
draw_clouds ()
--air particles
make_aparticles (2)
draw_aparticles ()
end
palt(14, true)
palt(0, false)
map (scenex,sceney,0,0,16,16)
if (scene_num==0) then
print ("press ❎ to start",30,43,8) 
print ("2020-fred osterero",28,111,1)       
print ("musics by nicolas grandgirard",6,118,1)    
elseif (scene_num==1) then

--main menu
highlightsprite (0,112,32,8,48,16,32,8)
for i=1,numberoftiles do
highlighttext (tiles[i],48,24+(12*i),8)    
end
spr(35,36,22+(12*selectedtile))
highlighttext ("❎ select",90,118,8) 
--controls screen
elseif (scene_num==2) then
-- controls
highlighttext ("controls",47,8,8)
highlighttext ("collect skulls and ",8,17,6)
highlighttext ("press ❎ to resurrect",8,24,6)
highlighttext ("the dead ones.they could",8,31,6) 
highlighttext ("destroy foes,pillars",8,38,6) 
highlighttext ("or...you!",8,45,6)
highlighttext ("collect orbs to open",8,54,6)
highlighttext ("the portals of the 12 levels.",8,61,6)					
highlighttext ("if you get stuck,hold 🅾️",8,70,6)
highlighttext ("to quit and retry.",8,77,6)	
highlighttext ("🅾️ back",90,118,8) 
elseif (scene_num==3) then
-- credits
highlighttext ("credits",50,8,8)
highlighttext ("design,art,code",8,17,13) 
highlighttext ("fred osterero",71,17,6)
highlighttext ("musics",8,25,13) 
highlighttext ("nicolas grandgirard",36,25,6)
highlighttext ("testers",8,35,13) 
highlighttext ("thomas dolfini,sam condat",8,42,6) 
highlighttext ("extra thanks to",8,51,13)
highlighttext ("pico-8 month,zep,dw817,",8,58,6)
highlighttext ("kql1n,hop,sara,alex valentin",8,65,6)					
highlighttext ("for your tutorials,technical",8,72,13)
highlighttext ("solutions and help.",8,79,13)	
highlighttext ("🅾️ back",90,118,8)
elseif (scene_num==4) then
	-- introduction
highlighttext ("and lady proserpina said:",16,8,8)
highlighttext ("greetings mortimer!",8,18,6) 
highlighttext ("travel to the necropolis and",8,28,6) 
highlighttext ("pay tribute to our divinity",8,36,6)
highlighttext ("to become a true necromancer.",8,44,6)
highlighttext ("resurrect the dead ones along",8,54,6)
highlighttext ("your pilgrimage.but beware!",8,62,6)					
highlighttext ("they know no more master.",8,70,6)
highlighttext ("❎ start",90,118,8)
elseif (scene_num==17) then
--end
highlightsprite (0,120,40,8,44,64,40,8)
highlighttext ("so the divinity said:",22,8,8) 
highlighttext ("hey! what's up mortimer?",6,18,6) 
highlighttext ("you're a true necromancer now!",6,26,6)
highlighttext ("oh wait... ",6,34,6)
highlighttext ("you're next on my list!",6,42,6)
highlighttext ("lol! i'm kidding bro! see ya!",6,50,6)					
highlighttext ("🅾️+❎ quit",86,118,8)
end
end



