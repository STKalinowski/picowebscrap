-- under construction
-- by glip and eevee

-- this is pretty stripped down
-- to fit the compressed limit.
-- original cart:
-- https://c.eev.ee/under-construction/under-construction.p8

animframedelay = 4

minfrac = 0.0000152587890625

function ceil(n)
	return flr(n + 1 - minfrac)
end

function merge(a, b)
	for k, v in pairs(b) do
		a[k] = v
	end
	return a
end

function sort(l, kf)
	local k = {}
	kf = kf or function(v) return v end
	for i = 1, #l do
		k[i] = kf(l[i])
	end
	for i = 2, #l do
		local j = i
		while j > 1 and k[j - 1] > k[j] do
			k[j], k[j - 1] = k[j - 1], k[j]
			l[j], l[j - 1] = l[j - 1], l[j]
			j -= 1
		end
	end
end

function perlin(xdim, ydim)
	local cos, rnd, sin = cos, rnd, sin
	local function s(t)
		return t * t * t * (6 * t * t - 15 * t + 10)
	end
	local function lerp(t, a, b)
		return a + t * (b - a)
	end
	local s2 = sqrt(0.5)
	local g = {}
	for x = 1, xdim do
		local row = {}
		g[x] = row
		for y = 1, ydim do
			local angle = rnd(1)
			row[y] = {
				cos(angle), sin(angle)}
		end
		row[0] = row[ydim]
	end
	g[0] = g[xdim]

	return function(x, y)
		local x1 = min(flr(x), xdim - 1)
		local y1 = min(flr(y), ydim - 1)
		local x2, y2 = x1 + 1, y1 + 1
		local gx1, gx2 = g[x1], g[x2]
		local dx1, dx2, dy1, dy2 =
			x - x1, x - x2,
			y - y1, y - y2
		local sy = s(dy1)
		local n = lerp(
			s(dx1),
			lerp(sy,
				gx1[y1][1] * dx1 +
				gx1[y1][2] * dy1,
				gx1[y2][1] * dx1 +
				gx1[y2][2] * dy2),
			lerp(sy,
				gx2[y1][1] * dx2 +
				gx2[y1][2] * dy1,
				gx2[y2][1] * dx2 +
				gx2[y2][2] * dy2))
		return s(
			n * s2 + 0.5)
	end
end

font_height = 6
font_width = 4
function printat(lines, anchor, a, c, borderc, bgc)
	local va = sub(a, 1, 1)
	local ha = sub(a, 2, 2)
	local vm = ({t=0, m=0.5, b=1})[va]
	local hm = ({l=0, m=0.5, r=1})[ha]

	if type(lines) == "string" then lines = {lines} end
	local th = #lines * font_height - 1
	local y = anchor.y - th * vm

	if borderc or bgc then
		local maxlen = 0
		for line in all(lines) do
			maxlen = max(maxlen, #line)
		end
		local maxw = font_width * maxlen - 1

		local x = flr(anchor.x - maxw * hm)
		local rx, ry, rw, rh =
			x - 4, y - 4,
			x + maxw + 3, y + th + 3
		if bgc then
			rectfill(rx, ry, rw, rh, bgc)
		end
		if borderc then
			rect(rx, ry, rw, rh, borderc)
		end
	end

	for line in all(lines) do
		local tw = font_width * #line - 1
		local x = anchor.x - tw * hm
		print(line, x, y, c)
		y += font_height
	end
end

function class(base, proto)
	proto = proto or {}
	proto.__index = proto
	local meta = {}
	setmetatable(proto, meta)
	if base then
		meta.__index = base
	end
	function meta:__call(...)
		local this = setmetatable({}, self)
		if this.init then
			this:init(...)
		end
		return this
	end
	return proto
end

vec2 = class()

function vec2:init(x, y)
	self.x = x or 0
	self.y = y or 0
end

function vec2:copy()
	return vec2(self.x, self.y)
end

function vec2:__add(other)
	return vec2(
		self.x + other.x,
		self.y + other.y)
end

function vec2:__mul(n)
	return vec2(
		self.x * n,
		self.y * n)
end

function vec2:__sub(other)
	return self + other * -1
end

function vec2:elemx(other)
	return vec2(
		self.x * other.x,
		self.y * other.y)
end

function vec2:at(anchor)
	return box(
		anchor.x, anchor.y,
		self.x, self.y)
end

function vec2:max()
	return max(self.x, self.y)
end

box = class()

function box:init(l, t, w, h)
	if w < 0 then
		l += w
		w *= -1
	end
	if h < 0 then
		t += h
		h *= -1
	end
	self.l = l
	self.t = t
	self.w = w
	self.h = h
end

function box.__index(self, key)
	if key == "r" then
		return self.l + self.w
	elseif key == "b" then
		return self.t + self.h
	else
		return box[key]
	end
end

function box:__add(offset)
	return box(self.l + offset.x, self.t + offset.y, self.w, self.h)
end

function box:overlaps(other)
	return (
		self.l < other.r and
		self.r > other.l and
		self.t < other.b and
		self.b > other.t
	)
end

function box:dist(other)
	local x, y
	if self.l < other.l then
		x = other.l - self.r
	else
		x = self.l - other.r
	end
	if self.t < other.t then
		y = other.t - self.b
	else
		y = self.t - other.b
	end
	return vec2(x, y)
end

actor = class{
	enabled = true,
	pose = "default",
	poses = {},
	shape = box(0, 0, 1, 1),
}

function actor:init(pos)
	self.pos = pos
	self:reset()
end

function actor:reset()
	self:set_pose"default"
end

function actor:blocks()
	return fget(self.sprite:current(), 7)
end

function actor:coll()
	return self.shape + self.pos
end

function actor:oncollide(other, delta)
end

function actor:update()
end

function actor:draw()
end

function actor:set_pose(pose)
	if self.poses[pose] then
		self.pose = pose
		self:set_sprite(self.poses[pose])
	end
end
function actor:set_sprite(s)
	self.sprite = to_sprite(s)
end

mobactor = class(actor, {
	is_mobile = true,
	min_speed = 0.015625,
	max_speed = 0.25,
	friction = 0.625,
})

function mobactor:init(pos)
	self.pos0 = self.pos0 or pos
	actor.init(self, pos)
end

function mobactor:reset()
	actor.reset(self)

	self.pos = self.pos0
	self.vel = vec2()
	self.facing_right = false
	self.ground = true
end

function mobactor:blocks()
	return true
end

gravity = 1/32
terminal_velocity = 7/8

function mobactor:update()
	local abs, vec2 = abs, vec2

	local v = self.vel
	local friction = self.friction
	if not self.ground then
		friction = 1 - (1 - friction) / 2
	end
	v.x *= friction
	if abs(v.x) > self.max_speed then
		v.x = sgn(v.x) * self.max_speed
	elseif abs(v.x) < self.min_speed then
		v.x = 0
	end
	v.y = min(
		v.y + gravity,
		terminal_velocity)

	local prevx = self.prevx or 0
	self.prevx = v.x
	if v.x ~= 0 then
		self.facing_right = v.x < 0
	end
	if v.y ~= 0 then
		self.ground = false
	end

	local move = v:copy()

	if abs(v.x) < abs(prevx) then
		local goalx = self.pos.x + move.x
		local d1 = goalx - flr(goalx + 0.5)
		if abs(d1) < 1/16 then
			move.x -= d1
		end
	end

	local coll = self:coll()
	local delta = vec2(
		abs(move.x),
		abs(move.y))
	local sign = vec2(
		sgn(move.x),
		sgn(move.y))

	local nearx = sign.x > 0 and "r" or "l"
	local neary = sign.y > 0 and "b" or "t"
	local boundx = abs(curzone.box[nearx] - coll[nearx])
	if delta.x > boundx then
		delta.x = boundx
		v.x = 0
	end
	local boundy = abs(curzone.box[neary] - coll[neary])
	if delta.y > boundy then
		if v.y > 0 then
			self.ground = true
		end
		delta.y = boundy
		v.y = 0
	end

	local blockers = {}
	local moverange = coll + vec2()
	if sign.x > 0 then
		moverange.w += delta.x
	else
		moverange.l -= delta.x
	end
	if sign.y > 0 then
		moverange.h += delta.y
	else
		moverange.t -= delta.y
	end
	local function add_blocker(other)
		if not other.enabled then
			return
		end
		if other.oncollide == actor.oncollide and not other:blocks() then
			return
		end
		local otherbox = other:coll()
		if not coll:overlaps(otherbox) and moverange:overlaps(otherbox) then
			local dist = coll:dist(otherbox)
			local order = dist.x * delta.y + dist.y * delta.x
			add(blockers, {
				actor = other,
				dist = dist,
				order = order,
				coll = otherbox,
			})
		end
	end
	for actor in all(curzone.mobs) do
		if actor ~= self and
			abs(self.pos.x - actor.pos.x) + abs(self.pos.y - actor.pos.y) <= 8
		then
			add_blocker(actor)
		end
	end
	for x = flr(moverange.l), ceil(moverange.r) do
		for y = flr(moverange.t), ceil(moverange.b) do
			add_blocker(curzone:tile(vec2(x, y)))
		end
	end
	sort(blockers, function (blocker)
		return blocker.order
	end)
	local movedby = vec2()

	for blocker in all(blockers) do
		local dist = blocker.dist - movedby
		dist.x = max(0, dist.x)
		dist.y = max(0, dist.y)
		local ymult = delta.y * dist.x
		local xmult = delta.x * dist.y
		local step = dist:copy()
		if dist.x == 0 or dist.y == 0 then
		elseif ymult > xmult then
			step.y = delta.y * dist.x / delta.x
		elseif xmult > ymult then
			step.x = delta.x * dist.y / delta.y
		end

		delta -= step
		movedby += step
		coll += (step:elemx(sign))

		local newdist = coll:dist(blocker.coll)
		local touchx = newdist.x == 0
		local touchy = newdist.y == 0
		if touchx or touchy then
			if touchx and touchy then
				if delta.x > delta.y then
					touchx = false
				else
					touchy = false
				end
			end

			local force = move:copy()
			if not touchx or delta.x == 0 then
				force.x = 0
			end
			if not touchy or delta.y == 0 then
				force.y = 0
			end
			blocker.actor:oncollide(self, force)

			if blocker.actor:blocks() then
				if touchx then
					delta.x = 0
					v.x = 0
				else
					delta.y = 0
					if v.y > 0 then
						self.ground = true
					end
					v.y = 0
				end
			end
		end
	end
	movedby += delta
	self.pos += (movedby:elemx(sign))

	local pose = "default"
	if not self.ground then
		if v.y <= 0 then
			pose = "jumping"
		else
			pose = "falling"
		end
	elseif v.x ~= 0 then
		pose = "walking"
	end
	self:set_pose(pose)
end

function mobactor:draw()
	self.sprite:drawat(self.pos, self.facing_right)
end

playeractor = class(mobactor, {
	is_player = true,

	xaccel = 0.125,
	max_jump_time = 4,
	yaccel = 19/128,
	aircontrol = 0.5,
})

function playeractor:reset()
	mobactor.reset(self)
	self.jumptime = 0
end

function playeractor:update()
	local xmult = 1
	if not self.ground then
		xmult = self.aircontrol
	end
	if btn(0) then
		self.vel.x -= self.xaccel * xmult
	elseif btn(1) then
		self.vel.x += self.xaccel * xmult
	end
	if btn(2) then
		if self.jumptime < self.max_jump_time then
			self.vel.y -= self.yaccel
			self.jumptime += 1
		end
	elseif self.ground then
		self.jumptime = 0
	else
		self.jumptime = 999
	end

	mobactor.update(self)
end

transientactor = class(actor, {
	is_transient = true,
})

function transientactor:init(...)
	actor.init(self, ...)
	if not self.sprite then
		self.sprite = to_sprite(
			mget(self.pos.x, self.pos.y))
	end
	self.enabled = fget(self.sprite:current(), progress.displayact - 1)
end

_tiledefs = {}

function declare_tile(data)
	if data.sprite then
		data.sprite = to_sprite(data.sprite)
	end
	if data.poses then
		for name, sprref in pairs(data.poses) do
			data.poses[name] = to_sprite(sprref)
		end
	end

	local sprite = data.sprite or (data.poses and data.poses.default)
	local for_tiles = data.for_tiles or sprite.frames

	local cls = data.class
	data.class = nil
	if cls then
	elseif data.reset or data.update or
		data.draw or data.poses or
		(sprite and #sprite.frames > 1)
	then
		cls = decoractor
	else
		cls = transientactor
	end

	class(cls, data)

	for _key, tileno in pairs(for_tiles) do
		if not _tiledefs[tileno] then
			_tiledefs[tileno] = class(
				data,
				{ sprite = to_sprite(tileno) })
		end
	end
end

_oneoff_actors = {}
function oneoff_actor(data)
	setmetatable(data, data.class or actor)
	add(_oneoff_actors, data)
	return data
end

decoractor = class(actor, {
	is_decor = true,
	_sprchange = false,
})

function decoractor:set_sprite(s)
	actor.set_sprite(self, s)
	mset(self.pos.x, self.pos.y, self.sprite:current())
	self._sprchange = true
end
function decoractor:reset()
	self.enabled = fget(self.sprite.frames[1], progress.displayact - 1)
	local t = 0
	if self.enabled then
		t = self.sprite:current()
	end
	mset(self.pos.x, self.pos.y, t)
end
function decoractor:update()
	if curtime % animframedelay == 0 or
		self._sprchange
	then
		mset(self.pos.x, self.pos.y, self.sprite:current())
		self._sprchange = false
	end
end

_tiletrans = {}

function declare_transparency(tiles)
	local trans = tiles.trans
	for tileno in all(tiles) do
		_tiletrans[tileno] = trans
	end
end

_spritedefs = {}
_spritedef = class()

function _spritedef:init(frames, skip)
	self.frames = frames
	self.skip = skip
end

function _spritedef:current()
	local time = curtime % (#self.frames * animframedelay)
	local frame = flr(time / animframedelay) + 1

	frame += self.skip
	if frame > #self.frames then
		frame -= #self.frames
	end

	return self.frames[frame]
end

function _spritedef:drawat(pos, hflip, vflip)
	local tileno = self:current()
	local trans = _tiletrans[tileno]
	if trans then
		palt(0, false)
		for c in all(trans) do
			palt(c, true)
		end
	end
	spr(tileno, pos.x * 8, pos.y * 8,
		1, 1, hflip, vflip)
	if trans then
		palt()
	end
end

function declare_sprite(args)
	local skip = 0
	for tileno in all(args) do
		_spritedefs[tileno] = _spritedef(
			args, skip)
		if args.name then
			_spritedefs[args.name] = _sprite[tileno]
		end
		skip += 1
	end

	return _spritedefs[args[1]]
end
function declare_sprites(defs)
	foreach(defs, declare_sprite)
end

function to_sprite(val)
	if type(val) == "number" then
		return _spritedefs[val]
			or declare_sprite{val}
	elseif type(val) == "string" then
		return _spritedefs[val]
	elseif #val > 0 then
		return declare_sprite(val)
	else
		return val
	end
end

function to_ramp(conv)
	local ret = {}
	for color = 0, 15 do
		local ramp = {}
		ret[color + 1] = ramp
		while color do
			add(ramp, color)
			color = conv[color + 1]
		end
	end
	return ret
end

blackramp = to_ramp{
	nil, 0, 0, 1,
	2, 1, 5, 6,
	2, 8, 9, 3,
	13, 5, 8, 14,
}
whiteramp = to_ramp{
	5, 12, 8, 5,
	9, 6, 15, nil,
	14, 10, 15, 10,
	6, 12, 15, 7,
}

function apply_ramp_fade(ramp, proportion)
	pal()
	for color = 0, 15 do
		local colorramp = ramp[color + 1]
		local slot = flr(#colorramp * proportion + 1)
		pal(color, colorramp[slot], 1)
	end
end

mapzone = class()

function mapzone:init(...)
	self.box = box(...)
	self.actors = {}
	self.mobs = {}
	self.decor = {}
end

function mapzone:tile(pos)
	local decor = self.decor[pos.y * 128 + pos.x]
	if decor then return decor end

	local tileno = mget(pos.x, pos.y)
	if _tiledefs[tileno] then
		return _tiledefs[tileno](pos)
	end

	return transientactor(pos)
end

function mapzone:set_tile(pos, tileno)
	local d = pos.y * 128 + pos.x
	if self.decor[d] then
		del(self.actors, self.decor[d])
		self.decor[d] = nil
	end

	mset(pos.x, pos.y, tileno)
end

function mapzone:reset()
	local mset, vec2 = mset, vec2
	if not self.inited then
		self.inited = true

		for x = self.box.l, self.box.r do
			for y = self.box.t, self.box.b do
				local tilecls = _tiledefs[mget(x, y)]
				if tilecls and
					not tilecls.is_transient
				then
					local actor = tilecls(
						vec2(x, y))
					add(self.actors, actor)
					if actor.is_mobile then
						mset(x, y, 0)
					end
				end
			end
		end

		for actor in all(_oneoff_actors) do
			add(self.actors, actor)
		end

		for actor in all(self.actors) do
			if actor.is_decor then
				self.decor[actor.pos.y * 128 + actor.pos.x] = actor
			elseif actor.is_mobile then
				add(self.mobs, actor)
			end
			if actor.is_player then
				player = actor
			end
		end
	end

	if progress.andre == 1 then
		local p = vec2(34, 54)
		self:set_tile(p, 97)
		p.x += 1
		p.y += 1
		self:set_tile(p, 97)
	elseif progress.andre == 2 then
		mset(34, 54, 0)
		mset(35, 55, 0)
		mset(34, 55, 109)
		mset(34, 56, 125)
	end
	mset(127, 16, progress.m and 95 or 0)
	progress.m = false
	mset(96, 58, progress.m2 and 95 or 0)
	progress.m2 = false
end

function mapzone:draw(cam, flag)
	flag = bor(flag or 0, shl(1, progress.displayact - 1))
	camera(cam.l * 8, cam.t * 8)

	local x = flr(cam.l)
	local y = flr(cam.t)
	map(x, y, x * 8, y * 8, 17, 17, flag)
end

scene = class{
	onenter = function() end,
	onexit = function() end,
	get_music = function() end,
}

function scene:init(obj)
	merge(self, obj or {})
end

curtime = 0
function scene:update()
	curtime = (curtime + 1) % 20160

	for layer in all(self.layers) do
		if layer.update then
			layer:update()
		end
	end
end

function scene:draw()
	local pal, camera = pal, camera
	cls()
	for layer in all(self.layers) do
		pal()
		camera()
		layer:draw()
	end
end

scenefader = class(scene)
function scenefader:init(newscene, duration, ramp)
	self.newscene = newscene
	self.oldscene = game.scene
	self.timer = 1
	self.duration = duration
	self.ramp = ramp or blackramp

	if not self.oldscene then
		self.reverse = true
	end
end
function scenefader:onenter()
	game:changemus(self.newscene:get_music(), self.duration)
end
function scenefader:update()
	self.timer += 1
	if self.timer >= self.duration then
		if not self.reverse then
			self.reverse = true
			self.timer = 1
		elseif self.timer > 0 then
			self.timer -= 1
			game:set_scene(self.newscene)
		end
	end
end
function scenefader:draw()
	rectfill(0, 0, 128, 128, 9)
	if self.reverse then
		self.newscene:draw()
	else
		self.oldscene:draw()
	end

	local prop = self.timer / self.duration
	if self.reverse then
		prop = 1 - prop
	end
	apply_ramp_fade(self.ramp, prop)
end

textscene = class(scene)

function textscene:init(texts, color)
	self.texts = texts
	self.color = color or 7
end
function textscene:draw()
	cls()
	pal()
	printat(self.texts, vec2(64, 64), "mm", self.color)
end

cam = box(0, 0, 16, 16)
margin = 6
map_layer = {
	update_camera = function(self)
		local b = curzone.box
		local focus = player:coll()
		cam.l = max(
			min(cam.l, max(b.l, focus.l - margin)),
			min(b.r, focus.r + margin) - cam.w)
		cam.t = max(
			min(cam.t, max(b.t, focus.t - margin)),
			min(b.b, focus.b + margin) - cam.h)
	end,
	reset = function(self)
		curzone:reset()
		for a in all(curzone.actors) do
			a:reset()
		end
		self:update_camera()
	end,
	update = function(self)
		for a in all(curzone.actors) do
			if a.enabled then
				a:update()
			end
		end
		self:update_camera()
	end,
	draw = function(self)
		curzone:draw(cam)
		for a in all(curzone.actors) do
			if a.enabled and
				a:coll():overlaps(cam)
			then
				a:draw()
			end
		end
	end,
}

game = {
	pending_scene = nil,
	scene = nil,
	curmusic = 20,
	taskhdl = 1,
	tasks = {},
}

function game:initialize()
	if self.curmusic then
		self:_music(self.curmusic)
	end

	for tileno, def in pairs(_spritedefs) do
		if type(tileno) == "number" and
			not _tiledefs[tileno] and
			(#def.frames > 1 or _tiletrans[tileno])
		then
			declare_tile{
				class = decoractor,
				sprite = def,
			}
		end
	end

	for t = 0, 127 do
		local flags = fget(t)
		if band(flags, 31) == 0 then
			fset(t, bor(flags, 31))
		end
	end

	map_layer:reset()
end

function game:schedule(tics, callback)
	local handle = self.taskhdl
	self.taskhdl += 1
	self.tasks[handle] = {
		time = tics,
		callback = callback,
	}
	return handle
end

function game:update()
	for handle, task in pairs(self.tasks) do
		task.time -= 1
		if task.time <= 0 then
			task.callback()
			self.tasks[handle] = nil
		end
	end

	if self.pending_scene then
		if self.scene then
			self.scene:onexit()
		end
		self.scene = self.pending_scene
		self.pending_scene = nil
		self.scene:onenter()
	end
	self.scene:update()
end

function game:draw()
	self.scene:draw()
end

function game:set_scene(scene)
	self.pending_scene = scene
end

function game:changemus(track, fadelen)
	track = track or -1
	if track == self.curmusic then
		return
	end
	if self.curmusic ~= -1 and track ~= -1 then
		self:_music(-1, fadelen)
		self:schedule(fadelen, function()
			self:_music(track, fadelen)
		end)
	else
		self:_music(track, fadelen)
	end
	self.curmusic = track
end
function game:_music(track, fadelen)
	if fadelen then
		fadelen = fadelen * 100 / 3
	end
	music(track, fadelen)
end

function _init()
	game:initialize()

	fog = {}
	local w, h = 4, 8
	local foggen = perlin(w, h)
	local fv = {}
	for x = 0, 127 do
		fv[x] = {}
		for y = 0, 127 do
			fv[x][y] = foggen(
				(x + 0.5) / 128 * w,
				(y + 0.5) / 128 * h)
			local fogval = (
				fv[x][y]
				+ fv[x % 64][y % 64] / 2
				+ fv[x % 32][y % 32] / 4
				) / 1.75
			if fogval > 0.5 then
				fog[y * 128 + x] = true
			end
		end
	end
end

function _update()
	game:update()
end

function _draw()
	game:draw()
end

progress = {
	act = 1,
	displayact = 1,
	fires = 0,
	fires0 = 0,
	clarity = 0,
	radios = 0,
	radios0 = 0,
	mr5loss = {0, 0, 0, 0},
	deaths = 0,
	all_deaths = 0,
	andre = 0,
}

acts = {
	{
		music = 0,
		start = "you open your eyes",
		death = function()
			if progress.deaths < 10 then
				return "you open your eyes again"
			else
				return "you open your eyes again?"
			end
		end,
	},
	{
		music = 16,
		start = "your head is pounding",
		death = function()
			local r = progress.radios / progress.radios0
			local l = progress.radios0 - progress.radios
			if progress.deaths < 10 then
				if l == 0 then
					return "your head is clear"
				elseif l <= 2 then
					return "your head is clearing"
				elseif r < 1 then
					return "your head is aching"
				else
					return "your head is pounding"
				end
			else
				if r < 1 then
					return {"you wish for relief", "from this noise"}
				else
					return "death is better than silence"
				end
			end
		end,
	},
	{
		music = 11,
		start = {"bodies around you", "writhe in agony"},
		death = function()
			if progress.deaths < 10 then
				if player.touched then
					return "you stop hurting"
				else
					return {"you don't want", "to feel like this"}
				end
			else
				if player.touched then
					return {"you end yourself", "as you've ended another"}
				else
					return {"each death feels", "more real than the last"}
				end
			end
		end,
	},
	{
		music = 24,
		start = "you smell smoke",
		death = function()
			local s = progress.fires / progress.fires0
			if progress.deaths >= 10 then
				return "your self-sacrifice failed"
			elseif s == 0 then
				return "you cough violently"
			elseif s < 0.5 then
				return "you start coughing"
			elseif s < 1 then
				return "you want to cough"
			else
				return "you can breathe again"
			end
		end,
	},
	{
		music = 0,
		start = "this is really familiar",
		death = function()
			if progress.deaths < 10 then
				return "wait, is it familiar?"
			else
				return "death is familiar"
			end
		end,
	},
}

act5_results = {
	bad = {
		music = 28,
		player_starts = {},
		end_texts = {
			{"don't ever bother", "looking for me"},
			"the static will always be there",
			"i still can't feel anything",
			"i'm suffocating again",
			"again again again again again",
		},
		epilogue = {
			"i hate how hard you tried;",
			"so very hard, and for what?",
			"you belong nowhere",
			"this wretched world is yours",
			"again",
		},
		epilogue_bg = 0,
	},
	ok = {
		music = 7,
		player_starts = {
			nil,
			vec2(24, 21),
			vec2(49, 22),
			vec2(88, 21),
			vec2(110, 21),
		},
		end_texts = {
			"i make out your silhouette",
			{"a scream echoes", "somewhere in your mind"},
			"is my pain yours?",
			"a confused haze lifts",
			"existence tricks us no longer",
		},
		epilogue = {
			"why you are here, i do not know",
			"does it matter?",
			"it must not; it never has",
			"our endless waltz",
				"in this broken city",
			"we've shared this moment before",
		},
		epilogue_bg = 1,
	},
	good = {
		music = 14,
		deathless = true,
		player_starts = {
			vec2(124, 31),
		},
		end_texts = {
			"i see your hopeful face",
			"i hear you whisper, \"this time\"",
			{"this time what?", "", "i am touched, regardless"},
			"startled, i gasp, and i burn",
			{"but it's okay,", "", "because this pain is real,", "", "and so am i"}
		},
		epilogue = {
			"there are no words",
				"for my gratitude",
			"this moment of clarity",
				"is timeless",
			"no malice, no hate",
			"not this time",
			"and i hope, never",
			"",
			"i may live on",
			"my heart touching yours",
			"i am free from this prison",
			"our bond carries us forward",
			"in your memory i dwell",
			"",
			"thank you",
		},
		epilogue_bg = 3,
	},
}

curzone = mapzone(
	0, 0, 128, 64)

function transition(duration, midscene, otherscene, callback)
	game:set_scene(scenefader(
		midscene, duration))
	game:schedule(duration * 2 + 30, function()
		local res
		if callback then
			res = callback()
		end
		if res ~= false then
			game:set_scene(scenefader(
				otherscene, 15))
		end
	end)
end

function die(texts, force)
	if (progress.deathless and not force) or progress.transitioning then
		return
	end
	progress.deaths += 1
	progress.all_deaths += 1
	progress.transitioning = true

	local function pd(x, y)
		return box(x, y, 0, 0):dist(player:coll()):max()
	end
	if progress.andre < 2 and pd(35, 55) <= 8 then
		progress.andre += 1
	end

	progress.m = pd(128, 14) < 2
	progress.m2 = pd(98.5, 59.5) < 4

	if not texts then
		texts = acts[progress.act].death()
	end
	transition(
		30, textscene(texts),
		mainscene, function()
			progress.transitioning = false
			map_layer:reset()
		end)
end

function nextact(texts)
	if progress.transitioning then
		return
	end
	progress.deaths = 0
	progress.transitioning = true
	if not texts then
		if progress.act >= 5 then
			texts = act5_results[progress.ending].end_texts[progress.displayact]
		else
			texts = acts[progress.act + 1].start
		end
	end
	local color = 7
	if progress.act == 5 then
		color = mr5.head_colors[progress.displayact]
	end
	local callback = _advanceact
	if progress.act >= 5 and progress.displayact >= 5 then
		callback = function()
			game:set_scene(scenefader(
				creditscene, 150, whiteramp))
			return false
		end
	end

	transition(
		60, textscene(texts, color),
		mainscene, callback)
end

function _advanceact()
	if progress.act == 5 then
		progress.displayact += 1
	else
		progress.act += 1
		if progress.act == 5 then
			progress.displayact = 1
		else
			progress.displayact = progress.act
		end
	end

	if progress.act >= 5 and not progress.ending then
        local mr5ok = 0
        for act = 1, 4 do
            if progress.mr5loss[act] < 5 then
                mr5ok += 1
            end
        end
        if mr5ok == 0 then
            progress.ending = "bad"
        elseif mr5ok == 4 then
            progress.ending = "good"
        else
            progress.ending = "ok"
        end

        progress.deathless = act5_results[progress.ending].deathless

        acts[2].music = 16

        progress.clarity = 0
        for _pos, decor in pairs(curzone.decor) do
            if decor.act5truereset then
                decor:act5truereset()
            end
        end
	end

	if progress.act == 5 then
		local start = act5_results[progress.ending].player_starts[progress.displayact]
		if start then
			player.pos0 = start
		end
	end

	progress.transitioning = false
	map_layer:reset()
end

mainscene = scene{
	layers = {
		{
			update = function(self)
			end,
			draw = function(self)
				circfill(32, 32, 13, 5)
				circfill(32, 32, 12, 6)
			end,
		},
		map_layer,
		{
			shiftx = 0,
			shifty = 0,
			update = function(self)
				if curtime % 20 == 0 then
					self.shiftx = (self.shiftx + 1) % 128
				end
				if curtime % 70 == 0 then
					self.shifty = (self.shifty + 1) % 128
				end
			end,
			draw = function(self)
				if progress.displayact ~= 4 then return end
				if progress.clarity >= 6 then
					return
				end
				local cl = progress.clarity + 3
				pal(0, 1)
				pal(5, 2)
				pal(6, 5)
				pal(7, 6)
				local fog, pset, pget = fog, pset, pget
				local dx = flr(cam.l * 6.4 + self.shiftx)
				local dy = flr(cam.t * 6.4 + self.shifty)
				local idx, yidx
				for y = 0, 127 do
					yidx = (y + dy) % 128 * 128
					for x = y * ceil(cl / 3) % cl, 127, cl do
						idx = yidx + (x + dx) % 128
						if fog[idx] then
							pset(x, y, pget(x, y))
						end
					end
				end
			end,
		},
	},
}
function mainscene:get_music()
	return acts[progress.displayact].music
end
function mainscene:update()
	scene.update(self)

	if btn(5) then
		die("try, try again", true)
	end
end

titlescene = scene()
titlescene.time = 0
function titlescene:update()
	if btn(4) or btn(5) then
		transition(
			30,
			textscene(acts[progress.act].start),
			mainscene)
	end

	if not self.extra then
		if self.time % 30 == 0 and
			rnd(30 * 60) < self.time
		then
			self.extra = "teeth"
			self.time = 0
		end
	elseif self.extra == "teeth" then
		if self.time > 90 then
			self.extra = nil
			self.time = 0
		end
	end
	self.time += 1
end
function titlescene:draw()
	cls()
	for x = 0, 127, 8 do
		local v = fog[4 * 128 + x + 4]
		if v then
			spr(6, x, 24)
			spr(38, x, 32)
		else
			spr(6, x, 32)
		end
		if x == 24 then
			palt(0, false)
			palt(4, true)
			spr(1, x, v and 16 or 24)
			palt()
		elseif x == 112 then
			spr(31, x, 0)
			spr(v and 31 or 19, x, 8)
			spr(31, x, 16)
			if not v then
				spr(31, x, 24)
			end
		end
		for y = 40, 111, 8 do
			local v = fog[(y + 4) * 128 + x + 4]
			local s
			if y <= 56 then
				if v then s = 38 else s = 22 end
			elseif y <= 80 then
				if v then s = 22 else s = 39 end
			else
				if v then s = 39 else s = nil end
			end
			spr(s, x, y)
		end
	end

	local pt = vec2(0, 128)
	printat({"u d r c n t u t o ", ""}, pt, "bl", 10)
	printat({" n e   o s r c i n", ""}, pt, "bl", 7)
	printat({"", "by glip and eevee"}, pt, "bl", 6)

	pt = vec2(128, 128)
	printat({"press z or x", "x to restart"}, pt, "br", 5)

	if self.extra == "teeth" then
		local tiles = {64, 80}
		if abs(45 - self.time) > 37 then
			pal(7, 5)
		elseif abs(45 - self.time) > 30 then
			pal(7, 6)
		elseif self.time % 10 > 5 then
			tiles = {65, 81}
		end
		spr(tiles[1], 4, 4)
		spr(tiles[2], 4, 12)
		pal()
	end
end
game:set_scene(titlescene)

creditscene = scene()
creditscene.camtop = -128
creditscene.castroll = {
	{
		{110, 126},
		"glitchedpuppet", 13,
		"art, music, concept", 14,
	},
	{
		{111, 127},
		"eevee", 13,
		"code, credits, this sprite", 14,
	},
	{
		{1},
		"mole", 4,
		"really digs this game", 7,
	},
	{
		{121},
		"radio", 1,
		"over and out", 7,
	},
	{
		{104},
		"fire", 9,
		"started from scratch", 7,
	},
	{
		{62, 61, 46},
		"pain tower", 2,
		"scars easily", 7,
	},
	{
		{59, 15, 21},
		"s'mitten", 11,
		"yearns for your touch", 7,
	},
	{
		{18},
		"lil chomper", 3,
		"lurks underfoot", 7,
	},
	{
		{64, 80},
		"gnash", 6,
		"wants you for dinner", 7,
	},
	{
		{66, 96, 53},
		"peeps", 8,
		"saw nothing, honest", 7,
	},
	{
		{84},
		"twinkle", 10,
		"wonders where you are", 7,
	},
	{
		{29, 114, 30},
		"ex-sign", 5,
		"used to mark a spot", 7,
	},
	{
		{48},
		"chair", 4,
		"stylish yet functional", 7,
	},
}
function creditscene:onenter()
	game:changemus(act5_results[progress.ending].music)
	if progress.andre >= 2 then
		add(self.castroll, {
			{109, 125},
			"andre", 14,
			"the ultimate peep", 7,
		})
	end
end
function creditscene:update()
	scene.update(self)
	if btn(2) and self.camtop > -128 then
		self.camtop -= 1
		self.done = false
	elseif not self.done and curtime % 4 == 0 then
		self.camtop += 1
	end
end
function creditscene:draw()
	cls()
	camera(0, self.camtop)
	local p = vec2(8, 8)
	local left = true
	for cast in all(self.castroll) do
		local side = "r"
		if left then
			p.x = 8
			side = "l"
		else
			p.x = 112
		end
		local tiles = cast[1]
		if #tiles < 2 then
			p.y += 4
		end

		for tileno in all(tiles) do
			to_sprite(tileno):drawat(p * 0.125, not left)
			if tileno == 46 or tileno == 62 then
				local n = curtime % 64 / 16
				pset(p.x + 3 + n % 2, p.y + 3 + n / 2, 0)
			end
			p.y += 8
		end

		local anchor = p:copy()
		anchor.y -= 1 + 4 * #tiles
		if left then anchor.x += 12 else anchor.x -= 4 end
		printat(cast[2], anchor, "b" .. side, cast[3])
		anchor.y += 2
		printat(cast[4], anchor, "t" .. side, cast[5])
		left = not left
		p.y += 8
		if #tiles < 2 then
			p.y += 4
		end
	end

	local epilogue = act5_results[progress.ending].epilogue
	rectfill(0, p.y, 128, p.y + font_height * #epilogue + 64, 6)
	p.x = 28
	p.y += 4
	for act = 1, 5 do
		local headidx = 1
		local torso, legs = 85, 101
		if act == 5 then
			if progress.all_deaths < 5 then
				headidx = 4
			elseif progress.all_deaths >= 55 then
				headidx = 5
			elseif progress.ending == "good" then
				headidx = 2
			elseif progress.ending == "bad" then
				headidx = 3
			end
		else
			local loss = progress.mr5loss[act]
			if loss == 0 then
				headidx = 2
			elseif loss >= 5 then
				headidx = 3
			end
		end
		if headidx == 3 then
			torso, legs = 86, 102
		end
		local p8 = p * 0.125
		to_sprite(mr5.head_sprites[act][headidx]):drawat(p8)
		p8.y += 1
		to_sprite(torso):drawat(p8)
		p8.y += 1
		to_sprite(legs):drawat(p8)
		p.x += 16
	end

	local epicolor = act5_results[progress.ending].epilogue_bg
	p.x = 64
	p.y += 28
	printat("m i 5 t e r f i v e", p, "tm", 0)
	p.y += 8
	printat("make5 perfect 5en5e", p, "tm", epicolor)
	p.y += 16
	printat(epilogue, p, "tm", 7, 0, epicolor)
	p.y += #epilogue * font_height

	p.x = 64
	p.y += 80
	printat("thanks for playing!", p, "bm", 7)
	p.y += 4
	printat("floraverse.com", p, "tm", 12)

	p.y += 62
	spr(110, 2, p.y - 16)
	spr(126, 2, p.y - 8)
	spr(111, 118, p.y - 16, 1, 1, true)
	spr(127, 118, p.y - 8, 1, 1, true)

	p.x = 12
	printat({"@glitchedpuppet", "glitchedpuppet.com"}, p, "bl", 1)
	p.x = 116
	printat({"@eevee", "eev.ee"}, p, "br", 1)

	if self.camtop + 128 >= p.y + 2 then
		self.done = true
	end
end

declare_transparency{
	1, 2, 3, 4, 5,
	103,
	69, 70, 73, 74, 75, 76,
	85, 86, 88, 89, 90, 91, 92,
	101, 102, 105, 106, 107, 108,
	117, 118, 122, 123, 124,

	trans = {4},
}

declare_sprites{
	{53, 63},
	{66, 67, 68, 67},
	{96, 112, 113, 112},
	{64, 65},
	{80, 81},
	{84, 100, 116},
	{104, 120},
	{74, 90}, {76, 92}, {69, 70},
}

declare_tile{
	class = playeractor,
	shape = box(0.125, 0, 0.75, 1),
	poses = {
		default = 1,
		walking = {2, 3},
		jumping = 4,
		falling = 5,
	},
	reset = function(self)
		playeractor.reset(self)
		self.touched = false
	end,
}

declare_tile{
	sprite = 7,
	shape = box(0, 0, 0.75, 1),
	oncollide = function(self, actor, d)
		if actor.is_player and d.x < 0 then
			die()
		end
	end,
}
declare_tile{
	sprite = 8,
	shape = box(0.25, 0, 0.75, 1),
	oncollide = function(self, actor, d)
		if actor.is_player and d.x > 0 then
			die()
		end
	end,
}

declare_tile{
	for_tiles = {18, 34},
	poses = {
		default = 18,
		chomping = 34,
	},
	reset = function(self)
		decoractor.reset(self)
		self:set_pose"default"
		self.stander = nil
		self.stand_timer = -1
	end,
	oncollide = function(self, actor, d)
		if actor == self.stander then return end
		if actor.is_player and d.y > 0 then
			self.stander = actor
			self.stand_timer = 30
		end
	end,
	update = function(self, curzone)
		if self.stander then
			if self.stander.pos.y == self.pos.y - 1
				and self.stander.pos.x > self.pos.x - 1
				and self.stander.pos.x < self.pos.x + 1
			then
				self.stand_timer -= 1
				if self.stand_timer <= 0 then
					self.stand_timer = 0
					self:set_pose"chomping"
					die()
				end
			else
				self:reset()
			end
		end
	end,
}

function _draw_iris(pos)
	local iris = pos * 8 + vec2(3, 3)
	if player.pos.x > pos.x then
		iris.x += 1
	end
	if player.pos.y > pos.y then
		iris.y += 1
	end
	pset(iris.x, iris.y, 0)
end

function _eye_try_propagate(pos)
	local below = curzone:tile(pos + vec2(0, 1))
	if below._eyepropagate then
		below:_eyepropagate()
	end
end
function _eye_collide(self, actor, d)
	if actor.is_player and progress.displayact >= 3 then
		actor.touched = true
		if self.pose == "default" then
			self.pain = 1
			self:set_pose(1)
		end
		_eye_try_propagate(self.pos)
	end
end

declare_tile{
	poses = {
		default = 62,
		115,
	},
	reset = function(self)
		self:set_pose"default"
	end,
	oncollide = _eye_collide,
	draw = function(self)
		if self.sprite:current() == 62 then
			_draw_iris(self.pos)
		end
	end,
}

declare_tile{
	poses = {
		default = 46,
		45,
		61,
	},
	reset = function(self)
		self:set_pose"default"
		self.pain = nil
	end,
	oncollide = _eye_collide,
	update = function(self)
		if self.pain and self.pain < 2 then
			if rnd() * (self.pain + 1) < 0.0625 then
				self.pain += 1
				if self.pain == 1 then
					_eye_try_propagate(self.pos)
				end
				self:set_pose(self.pain)
			end
		end
	end,
	_eyepropagate = function(self)
		if not self.pain then
			self.pain = 0
		end
	end,
	draw = function(self)
		if self.pose == "default" then
			_draw_iris(self.pos)
		end
	end,
}
declare_tile{
	for_tiles = {45, 61},
	oncollide = _eye_collide,
	_eyepropagate = function(self)
		_eye_try_propagate(self.pos)
	end,
}

declare_tile{
	poses = {
		default = 119,
		broken = 121,
	},
	shape = box(0, 0.5, 1, 0.5),
	is_radio = true,
	init = function(self, ...)
		actor.init(self, ...)
		progress.radios0 += 1
	end,
	oncollide = function(self, actor, d)
		if progress.act == 2 and self.pose == "default" and actor.is_player and d.y > 0 then
			self:set_pose"broken"
			progress.radios += 1
			local r = progress.radios
			local r0 = progress.radios0
			local m
			if r >= r0 then
				m = -1
			elseif r0 - r <= 2 then
				m = 33
			elseif r * 2 >= r0 then
				m = 31
			end
			if m then
				game:changemus(m, 15)
				acts[2].music = m
			end
		end
	end,
	draw = function(self)
		if self.pose == "default" then
			for d in all{0, 3} do
				local r = (curtime - d * 3) % 45 / 3
				if r < 8 then
					local color = 6
					if r >= 6 then
						color = 5
					end
					circ(self.pos.x * 8 + 1, self.pos.y * 8, r, color)
				end
			end
		end
	end,
	act5truereset = function(self)
		self:set_pose"default"
	end,
}

declare_tile{
	class = mobactor,
	sprite = 103,
	reset = function(self)
		mobactor.reset(self)
		self.enabled = progress.act == 4
	end,
	oncollide = function(self, actor, d)
		if d.x ~= 0 then
			self.vel.x += d.x
		end
	end,
	update = function(self)
		mobactor.update(self)

		local x = flr(self.pos.x + 0.5)
		local y = flr(self.pos.y + 0.5)
		local tile = curzone:tile(vec2(x, y))
		if tile.extinguish then
			tile:extinguish()
		end
	end,
}

function _fatal_to_touch(self, actor, d)
	if actor.is_player then
		die()
	end
end

declare_tile{
	shape = box(0, 0.375, 1, 0.625),
	sprite = to_sprite(104),
	init = function(self, ...)
		decoractor.init(self, ...)
		progress.fires0 += 1
	end,
	reset = function(self)
		if not self.extinguished then
			decoractor.reset(self)
		end
	end,
	oncollide = function(self, actor, d)
		if actor.is_player then
			if progress.act == 4 and progress.deaths >= 10 then
				die{"you wonder if that", "cleanses your soul"}
			else
				die()
			end
		end
	end,
	extinguished = false,
	extinguish = function(self)
		if not self.enabled then return end
		self.enabled = false
		self.extinguished = true
		self:set_sprite(0)
		progress.fires += 1
		progress.clarity = flr(
			6
			* progress.fires
			/ progress.fires0)
	end,
	act5truereset = function(self)
		self.extinguished = false
		self:set_sprite(104)
	end,
}

declare_tile{
	sprite = declare_sprite{21, 37},
	oncollide = _fatal_to_touch,
}
declare_tile{
	sprite = declare_sprite{59, 60},
	oncollide = _fatal_to_touch,
}

function reset_broken_tile(self)
	if progress.displayact == 1 then
		self:set_pose"default"
	else
		self:set_pose"broken"
	end
end
for pair in all{{16, 32}, {28, 44}, {31, 19}, {57, 20}, {58, 49}} do
	declare_tile{
		for_tiles = {pair[2]},
		poses = {
			default = to_sprite(pair[1]),
			broken = to_sprite(pair[2]),
		},
		reset = reset_broken_tile,
		update = function() end,
	}
end

mr5 = oneoff_actor{
	pos = vec2(118, 61),
	shape = box(0, 0, 1, 3),
	is_mobile = true,
	blocks = function(self)
		return true
	end,
	reset = function(self)
		actor.reset(self)
		self.timer = 0
		self.state = "neutral"
	end,
	update = function(self)
		local dist = self:coll():dist(player:coll()):max()
		local near = dist < 3

		local act = progress.act
		local m = "update" .. act
		self[m](self, near)

		self.timer += 1
		if self.state == "appeased" and self.timer > 90 then
			nextact()
		elseif self.state == "angered" and self.timer > 90 then
			progress.mr5loss[act] += 1

			local texts = self.die_texts[act][progress.mr5loss[act]]

			local call = die
			if progress.mr5loss[act] >= 5 then
				call = nextact
			end
			call(texts)
		end
	end,
	update1 = function(self, near)
		if near and (player.pos.x < self.pos.x) == player.facing_right then
			near = false
		end

		if near then
			if self.state == "neutral" or self.state == "relaxing" then
				self.state = "approached"
				self.timer = 0
			end
		else
			if self.state == "approached" then
				self.state = "relaxing"
				self.timer = 0
			end
		end
		if self.state == "approached" and self.timer > 60 then
			self.state = "angered"
			self.timer = 0
		elseif self.state == "relaxing" and self.timer > 150 then
			self.state = "appeased"
			self.timer = 0
		end
	end,
	update_condition = function(self, near, condition)
		if near and self.state == "neutral" then
			if condition then
				self.state = "appeased"
				self.timer = 0
			else
				self.state = "angered"
				self.timer = 0
			end
		end
	end,
	update2 = function(self, near)
		self:update_condition(near, progress.radios == progress.radios0)
	end,
	update3 = function(self, near)
		self:update_condition(near, not player.touched)
	end,
	update4 = function(self, near)
		self:update_condition(near, progress.fires == progress.fires0)
	end,
	update5 = function(self, near)
		self:update_condition(near, true)
	end,
	head_sprites = {
		{73, 105, 89},
		{74, 122, 106},
		{75, 107, 91},
		{76, 124, 108},
		{69, 118, 117, 88, 123},
	},
	head_colors = {14, 11, 9, 8, 12},
	ok_texts = {
		"i see you",
		{"shh", "i hear you"},
		{"wait", "did you feel that?"},
		"ah",
	},
	ng_texts = {
		"it's so dark",
		{"shh", "i can't hear you"},
		"it hurts",
		"i can't breathe",
	},
	die_texts = {
		{
			"weren't you just here?",
			"no, it couldn't be",
			"i've never seen you before",
			"hmm",
			"yes, you were never here",
		}, {
			"weren't you just here?",
			"no, that would be absurd",
			"no one would endure this",
			"hmm",
			"but you did, didn't you?",
		}, {
			"you feel ashamed",
			"why do you keep hurting?",
			"you can't understand it",
			{"do you feel more real", "when you hurt?"},
			{"do you feel more real", "when you hurt others?"},
		}, {
			"you want to hit something",
			{"there's nothing here", "worth hitting"},
			{"there's nothing here", "worth anything"},
			"you want to hit nothing",
			"you want nothing",
		},
	},
	draw = function(self)
		local drawpos = self.pos:copy()
		if self.state == "approached" then
			local v = flr(self.timer % 4 / 2)
			if v == 1 then
				drawpos.x += 0.125
			end
		end

		local head, torso, legs
		local heads = self.head_sprites[progress.displayact]
		local head = heads[1]
		local torso, legs = 85, 101
		if progress.act == 5 then
			if progress.ending == "bad" then
				head = heads[3]
			elseif progress.ending == "good" then
				head = heads[2]
			end
		elseif self.state == "angered" then
			head = heads[3]
		elseif self.state == "appeased" then
			head = heads[2]
		end
		if self.state == "angered" then
			torso, legs = 86, 102
		end
		for _n, sprite in pairs{head, torso, legs} do
			to_sprite(sprite):drawat(drawpos)
			drawpos.y += 1
		end

		local midtop = (self.pos + vec2(self.shape.w / 2, -0.75)) * 8
		local function mr5say(texts, color)
			printat(texts, midtop, "bm", color, 5, 0)
		end

		local state = self.state
		if progress.act == 5 then
			if state == "appeased" then
				mr5say("...", 6)
			end
		elseif state == "angered" then
			mr5say(self.ng_texts[progress.act], 8)
		elseif state == "appeased" then
			mr5say(self.ok_texts[progress.act], 13)
		elseif state == "approached" or state == "relaxing" then
			local color = 14
			if state == "relaxing" then
				color = 2
			end
			mr5say({"don't look", "at me"}, 9)
		end
	end,
}

