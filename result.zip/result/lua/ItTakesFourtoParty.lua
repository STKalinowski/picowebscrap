--it takes four to party 1.3
--by jeb

--debug=""

--[[
 unpack logic, thanks brynolf brothers
]]
str_num={}
function tostr(v)
 return v..""
end
for i=-20,255 do
 str_num[tostr(i)] = i
end
for i=-200,2500,10 do
 str_num[tostr(i)] = i
end

function sfxs(sfx_s)
 sfx(str_num[sfx_s])
end

function unp(data)
 local p,toks,tab = 1,{},{}
 --tokenize
 while #data > 0 do
  while p <= #data do
   local c = sub(data,p,p)
   if c == "," or (c == " " and p <= 1) then
    break
   end
   p += 1
  end

  if p > 1 then
   add(toks, sub(data,1,p-1))
  end
  data = sub(data,p+1)
  p = 1
 end
 --build
 for v in all(toks) do
  if v=="true" then
   add(tab,true)
  elseif v=="false" then
   add(tab,false)
  else
   add(tab, str_num[v] or v)
  end
 end
 return tab
end

function pcpy(vars, data, into)
 into=into or {}
 for i,var in pairs(data) do
  into[vars[i]] = var
 end
 return into
end


local actoroffsets={
 unp "-4,-5",
 unp "-4,-2",
 unp "-5,-4",
 unp "-2,-4",
}
local itemtypes={
}
local classnames=unp "warrior,ranger,wizard,cleric"
local classes={}
local classdata=pcpy(
 unp "charsprite,sprite,maxhp,maxmp",
 {
  unp "10,26,42,58",
  unp "9,25,41,57",
  unp "30,25,15,20",
  unp "10,15,45,30"
 }
)
local powernames=unp "pale,nature,gust,blaze,blood,ether,gloom"
local powers={}
local powerdata=pcpy(
 unp "sprite,textcol,index,palette",
 {
  unp "1,2,3,4,6,7,8",
  unp "6,11,12,10,15,13,5",
  unp "1,2,3,4,5,6,7",
  unp "0,1,2,3,5,6,7",
 }
)
local powergrid=
 unp "shield,root whip,dash,grenade,xp pig,v grenade,deathring,evade,bear trap,piercing,flametail,vampirism,teleport,shadow,3 missile,beeeeeees,lightning,fire wall,bloodrain,levitate,weakness,heal self,thorntree,twister,judgement,potions,blessing,paralysis"

powergriddata=pcpy(
 unp "mpcost,ctime",
 {
  --   warrior-------ranger--------wizard--------cleric----------
  unp "5,1,2,4,5,8,8,2,5,1,8,5,5,5,5,9,9,9,9,9,9,5,9,4,9,15,9,9",
  unp "9,6,9,9,9,9,9,9,9,2,9,9,9,9,9,9,9,9,9,9,9,5,9,9,9,9,9,9",
 }
)
local attacknames=unp "slash,arrow,missile,smite"

function _init()
 gameover=false
 
 for i,c in pairs(classnames) do
  classes[c]={
   name=c,
   index=i,
  }
  for k,v in pairs(classdata) do
   classes[c][k]=v[i]
  end
 end
 for i,c in pairs(powernames) do
  powers[c]={
   name=c,
  }
  for k,v in pairs(powerdata) do
   powers[c][k]=v[i]
  end
 end
 for i,c in pairs(classnames) do
  itemtypes[c]={
   name=c,
   ident="class",
   update=update_char_item,
   pickup=pickup_char,
   sprite=classes[c].sprite,
  }
 end
 for i,p in pairs(powernames) do
  itemtypes[p]={
   ident="power",
   power=powers[p],
   pickup=pickup_power,
   sprite=powers[p].sprite,
  }
 end

 ticker=0
 strictkeys={{},{}}
 latestkey=6

 chars={
 } 
 for name,c in pairs(classes) do
  nc=tcopy(c)
  pcpy(unp "level,xp,maxxp,blessed",unp "1,0,100,0",nc)
  nc.power=powers.pale
  nc.hp=nc.maxhp
  nc.mp=nc.maxmp
  chars[name]=nc
 end
 
 player=pcpy(unp "d,dx,dy,step,nextstep",unp "0,0,0,0,0")
 pchar=chars[classnames[flr(rnd(#classnames))+1]]
 
 worldlevel=nil
 setup_next_room()
 
end

function tcopy(s,d)
 d=d or {}
 for k,v in pairs(s) do
  d[k]=v
 end
 return d
end

function clamp(v,a,b)
 b=b or -a
 return max(a,min(b,v))
end

function update_strict_keys()
 strictkeys[1]=strictkeys[2]
 strictkeys[2]={}
 for i=0,5 do
  strictkeys[2][i]=btn(i)
 end
end

function strict_btnp(key)
 return strictkeys[2][key] and not strictkeys[1][key]
end

function _update()

 if gameover then
  if btn(4) and btn(5) then
   _init()
  end
  return
 end
 if transition then
  if transition.update then
   if transition:update() then
    transition=nil
   end
  end
  if btnp(4) then
   transition=nil
  end
  return
 end
 if startmusic then
  music(startmusic)
  startmusic=nil
 end

 ticker+=1
 update_strict_keys()
 
 if strict_btnp(0) then latestkey=0
 elseif strict_btnp(1) then latestkey=1
 elseif strict_btnp(2) then latestkey=2
 elseif strict_btnp(3) then latestkey=3
 end
 
 if latestkey<6 and not btn(latestkey) then
  latestkey=6
  for i=0,3 do
   if btn(i) then
    latestkey=i
    break
   end
  end
 end
 
 if player.hurt>0 then
  player.hurt-=1
 end
 friction(player)
 if player.hurt<=6 then
   player.dx,player.dy=0,0
   if playerattack>0 then
    playerattack-=1
    else
     local function snap(v) return flr((v+2)/4)*4 end
     if latestkey==0 then
      playerdir=2
      player.y=snap(player.y)
     elseif latestkey==1 then
      playerdir=3
      player.y=snap(player.y)
     elseif latestkey==2 then
      playerdir=0
      player.x=snap(player.x)
     elseif latestkey==3 then
      playerdir=1
      player.x=snap(player.x)
     end
     if latestkey<6 then
      player.dx,player.dy=get_dir_vec(playerdir,1.5)
      player.nextstep-=1
      if player.nextstep<=0 then
       player.step=(player.step+1)%2
       player.nextstep=5
       sfxs "3"
      end  
     else
      player.nextstep=0
     end
   
     if btnp(4) then
      perform_attack()
     elseif btnp(5) then
      perform_special()
     end
    end
  end
 if pspecial then
  pspecialtime-=1
  if pspecialtime<=0 then
   pspecial=nil
  end
  if pspecial=="twister" then
   add_pparticle("whirl",6,-1+rnd(2),-1+rnd(2)).prerender=true
   all_m_pdistance(20,function(m) 
    push_monster(m,5)
    end
   )
   if pspecialtime%4==0 then
    sfxs "4"
   end
  elseif pspecial=="dash" then
   all_m_pdistance(8,function(m)
     hurt_monster(m,15*pchar.level)
    end
   )
  elseif pspecial=="flametail" then
   if pspecialtime%8==0 then
    add_pobject("flame")
   end
  elseif pspecial=="deathring" then
   add_pparticle("shield",0)
   all_m_pdistance(24,function(m)
     hurt_monster(m,3*pchar.level)
    end
   )
  elseif pspecial=="bloodrain" then
   add_object("bloodrain",rnd_free_pos())
   if pspecialtime%25==0 then
    foreach(monsters,function(m) hurt_monster(m,3) end)
   end
  elseif pspecial=="shield" then
   add_pparticle("shield")
  end
 end
 
 drawlist={}
 
 update_map()
 move_actor(player)
 draw_player()
 update_objects()
 update_monsters()
 update_items()
 update_particles()
 
 for i in all(items) do
  draw_item(i)
 end
 
 --debug cheats
 --if btnp(4,1) then
 -- pchar.power=powers[powernames[1+((pchar.power.index)%7)]]
 -- debug=pchar.power.name
 --end
end

function sprint(text,x,y,c)
 print(text,x+1,y+1,0)
 print(text,x,y+1,0)
 print(text,x+1,y,0)
 print(text,x,y,c)
end

function _draw()

 if gameover then
  local y=rnd(128)
  line(0,y,128,y,0)
  sprint("game over",50,60,7)
  sprint("you reached level "..worldlevel,26,70,7)
  sprint("press \x8e+\x97 to restart",22,90,7)
  return
 end
 if transition then
  transition:draw()
  return
 end

 camera(
  min(max(0,player.x-64),((worldwidth*12)+4)*8-128),
  min(max(0,player.y-64),((worldheight*12)+4)*8-112)
 )
  
 set_map_palette()
 map(0,0,0,0,32,32,4)
 
 draw_shadows()
 
 set_map_palette()
 map(0,0,0,0,32,32,2) 

 draw_particles(true)
 draw_actors()
 draw_monster_hp()
 draw_particles()
 
 camera()
 
 draw_game_gui()
 
 --print(debug,0,0,7)
 
end

function set_map_palette()
 pal()
 palt(0,false)
 palt(14,false)
 
 local row=worldpalette
 pal(15,sget(4,row))
 pal(14,sget(5,row))
 pal(8,sget(6,row))
 pal(10,sget(7,row))
end

function set_palette(palette)
 for i=0,15 do
  pal(i,i)
 end
 palette=palette or 8
 if palette==9 then
  for i=0,15 do
   pal(i,7)
  end
 else
  pal(11,sget(0,palette))
  pal(3,sget(1,palette))
  pal(13,sget(2,palette))
  pal(1,sget(3,palette))
 end
end

function rectfill2(x0,y0,x1,y1,c)
 if x0>=x1 or y0>=y1 then
  return
 end
 rectfill(x0,y0,x1-1,y1-1,c)
end

function cprint(str,x,y,c)
 print(str,x-#str*2,y,c)
end

function draw_actors()
 pal()
 palt(0,false)
 palt(14,true)
 
 local maxsd=0
 for o in all(drawlist) do
  maxsd=max(o.sdist+1,maxsd)
 end
 for h=0,maxsd do
   for o in all(drawlist) do
    if o.sdist<=h then
     set_palette(o.palette)
     if o.meth then
      o.meth(o.data)
     else
      local ts=o.tsize or 1
      spr(o.sprite,o.x,o.y,ts,ts,o.flp,o.flp)
     end
     del(drawlist,o)
    end
   end
  end
end

function draw_shadows()
 pal()
 palt(0,false)
 palt(14,true)
 for i=0,15 do
  pal(i,1)
 end
 
 for o in all(drawlist) do
  if not o.meth then
    o.sdist=o.sdist or 1
    local od=o.sdist
    local ts=o.tsize or 1
    spr(o.sprite,o.x+od,o.y+od-1,ts,ts,o.flp,o.flp)
    spr(o.sprite,o.x+od-1,o.y+od,ts,ts,o.flp,o.flp)
   end
 end
end

function draw_bar(x,y,w,h,v,m,vc,mc)

 rectfill(x,y,x+w-1,y+h-1,mc) 
 rectfill2(x,y,x+flr(w*(v/m)),y+h,vc)

end

function draw_game_gui()
 pal()
 palt(0,false)
 palt(14,true)
 rectfill(0,112,128,128,0)
 line(0,112,128,112,7)
 
 local x=0
 local w=32
 for cn in all(classnames) do
  local c=chars[cn]
  if c==pchar then
   rect(x+2,114,x+30,127,10)
  elseif not worldchars[cn] then
   rect(x+2,114,x+30,127,6)
  end
  set_palette(c.power.palette)
  spr(c.sprite,x+4,117)
  set_palette()
  
  local xs,xe=x+14,x+28
  draw_bar(xs,117,15,2,c.hp,c.maxhp,get_hp_colors(c.hp,c.maxhp))
  draw_bar(xs,120,15,2,c.mp,c.maxmp,12,1)
  draw_bar(xs,123,15,2,c.xp,c.maxxp,7,5)
  
  x+=w
 end
 
end

function get_hp_colors(h,m)
 if h/m <.33 then
  if flr(ticker/10)%2==0 then
   return 9,2
  end
  return 8,2
 elseif h/m <.66 then
  return 10,4
 end
 return 11,3
end

function draw_player()
 local s=pchar.charsprite
 if playerattack>0 then
  s+=2
 else
  s+=player.step%2
 end
 local flp=false
 flp,s=get_dir_flp_spr(playerdir,s,s+3)
  
 local palette=pchar.power.palette
 if player.hurt>0 then
  palette=9
 end
 
 local a={
  sprite=s,
  x=player.x+actoroffsets[playerdir+1][1],
  y=player.y+actoroffsets[playerdir+1][2],
  flp=flp,
  palette=palette,
  sdist=player.flying and 3 or 1,
 }
 add(drawlist,a)
 pdraw=tcopy(a)
 pdraw.arrow=fakearrow
 fakearrow=nil
end

--[[

 actor stuff
 
]]

function move_actor(actor)

 local ox,oy=get_pos(actor)
 local tx,ty=actor.dx,actor.dy
 local nx,ny=ox,oy
 local mapmeth=mapgroundblock
 if actor.flying then
  mapmeth=mapwall
 end
 local hit=false
 
 local ps=actor.size or 3
 local ns=-ps+1
 
 while tx~=0 do
  local dx=clamp(tx,-4)
  nx,ny=ox+dx,oy
  
   if dx<0 then
    if mapmeth(nx+ns,ny+ns) or mapmeth(nx+ns,ny+ps) then
     nx=flr(ox/8)*8-ns
     hit=true
    end
   elseif dx>0 then
    if mapmeth(nx+ps,ny+ns) or mapmeth(nx+ps,ny+ps) then
     nx=flr(ox/8)*8+6+ns
     hit=true
    end
   end
   ox=nx
  tx-=dx
 end
 actor.x=nx

 while ty~=0 do
  local dy=clamp(ty,-4)
  ny=oy+dy
  
   if dy<0 then
    if mapmeth(nx+ns,ny+ns) or mapmeth(nx+ps,ny+ns) then
     ny=flr(oy/8)*8-ns
     hit=true
    end
   elseif dy>0 then
    if mapmeth(nx+ns,ny+ps) or mapmeth(nx+ps,ny+ps) then
     ny=flr(oy/8)*8+6+ns
     hit=true
    end
   end
   oy=ny
   ty-=dy
 end
 actor.y=ny
 return hit
end

function get_special_i(c,p)
 return (c.index-1)*7+p.index
end

function get_powers(c,p)
 return attacknames[c.index],powergrid[get_special_i(c,p)]
end

function get_pos(object)
 return object.x,object.y
end

function friction(a)
 a.dx*=.85
 a.dy*=.85
end

function perform_attack()

 playerattack=9
 local power=pchar.power
 local x,y=get_pos(player)
 local level=pchar.level
 
 if pchar==chars.warrior then 
   add_pparticle("slash")
   sfxs "5"
   playerattack=4
   
   foreach(monsters,function(m)
    if actor_touches(m,get_player_front(6,8)) then
     hurt_monster(m,15*level)
    end
   end)
  elseif pchar==chars.cleric then
   playerattack=14
   sfxs "6"
  local o=rnd()
  local c=7+flr(rnd(7))+level
  local dist=12+level*2
  for i=0,c do
   local a=o+i/c
   add_particle("smite",x-4+cos(a)*dist,y-4+sin(a)*dist,power.palette)
   end

   all_m_pdistance(dist+8,function(m,dmg) hurt_monster(m,dmg) end,7+level)
  
  elseif pchar==chars.ranger then
   add_pobject("arrow",playerdir,power.palette,level)
  elseif pchar==chars.wizard then
   add_pobject("missile",playerdir,power.palette,level)
   sfxs "6"
  end
  
  if pchar.blessed>0 then
   add_pparticle("bless")
  end
  fakearrow=playerdir
 
end

specialstable={
 warriorpale=function()
  pspecial="shield"
  pspecialtime=9999
  sfxs "8"
 end,
 warriornature=function()
   add_pparticle("whip")
   sfxs "5"
   
   foreach(monsters,function(m)
    if actor_touches(m,get_player_front(5,24+8*pchar.level)) then
     hurt_monster(m,10*pchar.level)
    end
   end)
 end,
 warriorgust=function()
  local dx,dy=get_dir_vec(playerdir,5)
  player.dx+=dx
  player.dy+=dy
  player.hurt=16
  pspecial="dash"
  pspecialtime=16
  sfxs "5"
 end,
 warriorblaze=function()
  add_pobject("grenade",playerdir,3)
 end,
 warriorblood=function()
  add_monster(monstertypes.pig,player.x,player.y)
  sfxs "8"
 end,
 warriorether=function()
  add_pobject("grenade",playerdir,6)
 end,
 warriorgloom=function()
  pspecial="deathring"
  pspecialtime=pchar.level*90
  sfxs "12"
 end,
 rangerpale=function()
  local dx,dy=get_dir_vec(playerdir,-5)
  player.dx+=dx
  player.dy+=dy
  player.hurt=16
  sfxs "5"
 end,
 rangernature=function()
  add_pobject("beartrap")
  sfxs "13"
 end,
 rangergust=function()
  sfxs "2"
  add_pobject("arrow",playerdir,2,pchar.level).piercing=true
 end,
 rangerblaze=function()
  pspecial="flametail"
  pspecialtime=150*pchar.level
  sfxs "8"
 end,
 rangerblood=function()
  for i=1,pchar.level do
   add_pobject("vampire")
  end
  sfxs "8"
 end,
 rangerether=function()
  player.x,player.y=rnd_free_pos()
  player.hurt=16
  sfxs "4"
 end,
 rangergloom=function()
  add_pobject("shadow")
  sfxs "0"
 end,
 clericpale=function()
  pchar.hp=min(pchar.maxhp,pchar.hp+pchar.level*10)
  add_pparticle("smite",1)
  sfxs "8"
 end,
 clericnature=function()
  sfxs "0"
  add_pobject("tree")
 end,
 clericgust=function()
  pspecialtime=50*pchar.level
  pspecial="twister"
 end,
 clericblaze=function()
  for i=1,pchar.level*5 do
   add_object("flame",rnd_free_pos())
  end
  sfxs "12"
 end,
 clericblood=function()
  add_item("hpotion",get_pos(player))
  sfxs "8"
 end,
 clericether=function()
  add_pparticle("smite",1)
  for n,c in pairs(chars) do
   c.blessed=pchar.level
  end
  sfxs "8"
 end,
 clericgloom=function()
  for m in all(monsters) do
   if m.level<=pchar.level or rnd()<.2 then
    m.paralyzed=pchar.level*90
   end
  end
  sfxs "0"
 end,
 wizardpale=function()
  local x,y=get_pos(player)
  local d=playerdir
  add_pobject("missile",d,0,pchar.level)
  local dx,dy=get_dir_vec(d,3)
  add_object("missile",x+dy,y+dx,d,0,pchar.level)
  add_object("missile",x-dy,y-dx,d,0,pchar.level)
  sfxs "6"
 end,
 wizardnature=function()
  for i=1,pchar.level do
   add_pobject("bees")
  end
  sfxs "14"
 end,
 wizardgust=function()
  local sm=nil
  for m in all(monsters) do
   if actor_touches(m,get_player_front(3,64)) then
    sm=m
    break
   end
  end
  if sm then
   local oa=player
   for l=1,5 do
    hurt_monster(sm,pchar.level*20,get_pos(oa))
    add_particle("bolt",oa.x,oa.y,sm.x,sm.y)
    local ok=false
    for m in all(monsters) do
     if manhattan(sm,m)<64 and m.hurt<=0 then
      oa=sm
      sm=m
      ok=true
      break
     end
    end
    if not ok then
     break
    end
   end
  else
   local ex,ey=get_dir_off(player,playerdir,64)
   add_pparticle("bolt",ex,ey)
  end
  sfxs "12"
 end,
 wizardblaze=function()
  local dx,dy=get_dir_vec(playerdir,7)
  local sx,sy=player.x+dx,player.y+dy
  add_object("flame",sx,sy)
  for i=1,5 do
   local x,y=sx+dy*i,sy+dx*i
   if mapwall(x,y) then
    break
   end
   add_object("flame",x,y)
  end
  for i=1,5 do
   local x,y=sx-dy*i,sy-dx*i
   if mapwall(x,y) then
    break
   end
   add_object("flame",x,y)
  end
  sfxs "12"
 end,
 wizardblood=function()
  pspecialtime=90*pchar.level
  pspecial="bloodrain"
  sfxs "0"
 end,
 wizardether=function()
  player.flying=true
  sfxs "4"
 end,
 wizardgloom=function()
  for m in all(monsters) do
   m.speed*=.5
   m.palette=7
   m.dmg*=.5
  end
  sfxs "0"
 end,
}

function perform_special()
 
 local power=pchar.power
 local pindex=get_special_i(pchar,power)
 local cost=powergriddata.mpcost[pindex]
 
 if pchar.mp<cost then
  return
 end
 playerattack=powergriddata.ctime[pindex]
 pchar.mp-=cost
 specialstable[pchar.name..power.name]()
end

function get_player_front(w,h)
 local x,y=player.x-w/2,player.y-4-h
 if playerdir==1 then
  y=player.y+4
 elseif playerdir==2 then
  w,h=h,w
  x,y=player.x-4-w,player.y-h/2
 elseif playerdir==3 then
  w,h=h,w
  x,y=player.x+4,player.y-h/2
 end
 
 return x,y,x+w,y+h
end

function actor_touches(a,x0,y0,x1,y1)
 local s=a.size or 3
 return a.x+s>=x0 and
  a.x-s<=x1 and
  a.y+s>=y0 and
  a.y-s<=y1
end

--note: not actually manhattan distance
function manhattan(a,b)
 local dx,dy=abs(a.x-b.x),abs(a.y-b.y)
 if dx>dy then return dy*.4+dx end
 return dx*.4+dy
end

function col_check(a,b,d)
 local s=b.size or 3
 return manhattan(a,b)<(d+s)
end

function get_dir_vec(d,len)
 if d==1 then
  return 0,len
 elseif d==2 then
  return -len,0
 elseif d==3 then
  return len,0
 end
 return 0,-len
end

function get_dir_off(a,d,len)
 local dx,dy=get_dir_vec(d,len)
 return a.x+dx,a.y+dy
end

function get_dir_flp_spr(d,vs,hs)
 local flp=d==1 or d==2
 if d==2 or d==3 then
  return flp,hs
 end
 return flp,vs
end

monstermethods={
 rjump=function(m)
  m.jump=m.jump or 30+rnd(60)
  m.jump-=1
  if m.jump<=0 then
   m.jump=(90+rnd(180))/m.speed
   m.dx+=(-1+rnd(3))*m.speed
   m.dy+=(-1+rnd(3))*m.speed
  end
  m.s=m.bsprite
  if m.jump<50 then
   local a=2+flr(m.jump/6)
   if flr(m.jump)%a<=1 then
    m.s+=(m.tsize or 1)
   end
  end
 end,
 bigslime=function(m)
  monstermethods.rjump(m)
  if m.hurt==1 then
   add_monster(monstertypes.minislime,m.x,m.y)
  end
 end,
 rmove=function(m)
  local d=m.d or 0
  m.move=m.move or 0
  m.move-=1
  if m.move<=0 or m.collision then
   m.move=10+rnd(40)
   if m.tracking>rnd(100) then
    local dx,dy=player.x-m.x,player.y-m.y
    if abs(dx)>abs(dy) then
     if dx<0 then
      m.d=2
     else
      m.d=3
     end
    else
     if dy<0 then
      m.d=0
     else
      m.d=1
     end
    end
   else
    m.d=flr(rnd(4))
   end
  end
  m.dx,m.dy=get_dir_vec(m.d,m.speed)
  local s=m.bsprite
  if m.stepping and flr(m.move/4)%2==1 then
   s=m.bsprite+2*(m.tsize or 1)
  end
  m.flp,m.s=get_dir_flp_spr(m.d,s,s+(m.tsize or 1))
 end,
 home=function(m)
  m.move=m.move or 0
  m.target=m.target or player
  if m.move>0 then
   local a=atan2(m.target.x-m.x,m.target.y-m.y)
   m.dx=cos(a)*m.speed*.5
   m.dy=sin(a)*m.speed*.5
  end
  m.move-=1
  if m.move<-30 then
   m.move=30+rnd(30)
  end
  m.s=m.bsprite+(ticker/4)%2
 end,
 sentry=function(m)
  m.wait=m.wait or 90+rnd(30)
  m.wait-=1
  if m.wait<=0 then
   m.wait=(90+rnd(30))/m.speed
   add_object("torpedo",m.x,m.y,5,player.x,player.y)
  end
  m.s=m.wait<20 and m.bsprite+(m.tsize or 1) or m.bsprite
 end,
 bounce=function(m)
  m.s=m.bsprite
  if m.collision or not m.sdx then
   m.sdx=(-1+rnd(2))*m.speed
   m.sdy=(-1+rnd(2))*m.speed
  end
  m.dx,m.dy=m.sdx,m.sdy
 end,
 bsentry=function(m)
  monstermethods.bounce(m)
  monstermethods.sentry(m)
 end,
 magemove=function(m)
  monstermethods.rmove(m)
  local cast=m.cast or 90
  cast-=1
  if cast==0 then
   cast=90+flr(rnd(15))
   if m.tsize then
    for d=0,3 do
     add_object("wave",m.x,m.y,d)
    end
   else
    add_object("wave",m.x,m.y,m.d)
   end
  elseif cast<20 then
   m.dx,m.dy=0,0
   m.move=2
  end
  m.cast=cast
 end,
 daemonmove=function(m)
  monstermethods.rmove(m)
  if not m.cape then
   add_pobject("daemoncape",m)
   m.cape=true
  end
  if flr(m.move)%12==1 then
   local x,y=rnd_free_pos()
   add_object("flame",x,y,150,2,3)
  end
  if flr(m.move)==2 then
   m.speed=1+rnd()
  end
 end,
}
monsternames=unp "daemon,bigeye,master,mage,chomp,eye,minislime,bigslime,pig,slime,scorpion,brute,bat,sentry,skeleton,saw"
monstertypes={}
do
 local monsterdata=pcpy(
  unp "umeth,cvuln,pvuln,level,maxhp,dmg,bsprite,palette,speed,sdist,stepping,tracking,flying",
  {
   unp "daemonmove,bsentry,magemove,magemove,home,bsentry,rjump,bigslime,rmove,rjump,rmove,rmove,home,sentry,rmove,bounce",
   unp "cleric,ranger,wizard,cleric,warrior,ranger,wizard,cleric,warrior,wizard,warrior,ranger,ranger,cleric,cleric,warrior",
   unp "ether,nature,blaze,gust,ether,gloom,blood,blaze,blood,gust,blood,nature,blaze,gloom,ether,nature",
   unp "11,10,9,5,4,4,0,8,12,1,1,2,2,2,3,3",
   unp "750,600,500,80,80,75,20,400,300,30,45,60,40,30,75,60",
   unp "8,8,8,4,7,6,2,6,0,2,2,4,2,2,6,6",
   unp "160,108,100,87,85,83,64,96,81,64,66,68,72,74,76,80",
   unp "8,8,13,10,3,8,12,12,11,1,3,8,7,3,0,8",
   unp "1,2,1,1,2,1,3,6,1,3,1,1,2,1,1,2",
   unp "1,2,1,1,1,1,1,1,1,1,1,1,3,1,1,3",
   unp "true,false,true,true,false,false,false,false,false,false,false,true,false,false,true,false",
   unp "25,0,0,0,0,0,0,0,0,0,0,25,0,0,75,0",
   unp "false,true,false,false,false,true,false,false,false,false,false,false,true,false,false,true",
  }
 )
 for i,n in pairs(monsternames) do
  local nmt={}
  for j,v in pairs(monsterdata) do
   nmt[j]=v[i]
  end
  monstertypes[n]=nmt
  monstertypes[n].update=monstermethods[nmt.umeth]
 end
 function make_big(t)
  pcpy(unp "size,tsize,xo,yo,trample", unp "6,2,-8,-8,true",t)
 end

 make_big(monstertypes.bigslime)
 make_big(monstertypes.master)
 make_big(monstertypes.bigeye)
 make_big(monstertypes.daemon)
end

function add_monster(t,x,y,...)
 local m={
  t=t,
  x=x,
  y=y,
  hp=t.maxhp,
 }
 pcpy(unp "xo,yo,dx,dy,hurt,paralyzed",unp "-3,-3,0,0,15,0",m)
 tcopy(t,m)
 if t.init then
  t.init(m,...)
 end
 add(monsters,m)
 add_particle("ping",x,y,8,10)
 return m
end

function update_monsters()
 for i in all(monsters) do
  friction(i)
  if i.paralyzed>0 then
   i.paralyzed-=1
   if i.paralyzed%8==0 then
    add_particle("whirl",i.x,i.y,7)
   end
  elseif i.hurt<=0 or i.trample then
   i:update()
   if col_check(player,i,4) then
    hurt_player(i)
    push_monster(i,5)
   end
  else
   i.s=i.s or i.bsprite
  end
  i.hurt-=1
  i.collision=move_actor(i)
  draw_monster(i)
  if i.hp<=0 then
   del(monsters,i)
  end
 end
end

function add_xp(xp)
 local c=pchar
 c.xp+=xp
 if c.xp>=c.maxxp then
  c.xp-=c.maxxp
  c.maxxp+=200
  c.level+=1
  c.maxhp+=classes[c.name].maxhp/5
  c.maxmp+=classes[c.name].maxmp/5
  c.hp=c.maxhp
  c.mp=c.maxmp
  sfxs "9"
  add_pparticle("text","lvl up")
 end
end

function hurt_player(m)

 if player.hurt>0 then
  return
 end
 player.hurt=26
 sfxs "10"
 player.dx,player.dy=get_dir_vec(playerdir,-2)
 if pspecial=="shield" then
  pspecial=nil
  return
 end
 
 pchar.hp-=m.dmg
 if pchar.hp<=0 then
  pchar.hp=0
  gameover=true
  music(-1)
 end
 pchar.blessed-=2
 add_pparticle("text","-"..m.dmg,8)
end

function all_m_pdistance(d,meth,...)
 for m in all(monsters) do
  if manhattan(m,player)<d then
   meth(m,...)
  end
 end
end

function hurt_all_monsters(o,dist)
 local hit=false
 for m in all(monsters) do
  if col_check(o,m,dist) then
   hurt_monster(m,o.dmg,o.x,o.y)
   hit=true
  end
 end
 return hit
end

function hurt_monster(m,dmg,sx,sy)
 if m.hp<=0 or m.hurt>16 then
  return false
 end
 if m.cvuln==pchar.name or pchar.blessed>0 then
  dmg*=2
 end
 if m.pvuln==pchar.power.name then
  dmg*=2
 end
 m.hp-=dmg
 sfxs "10"
 
 if m.hp<=0 then
  if m.level>0 then
   add_xp(m.level*10+5)
  end
  for i=1,4 do
   add_particle("blood",m.x,m.y)
  end
 else
  add_particle("blood",m.x,m.y)
 end
 
 push_monster(m,2*dmg/m.maxhp,sx,sy)
 m.hurt=20
 add_particle("text",m.x,m.y,"-"..dmg,2)
 return m.hp<=0
end

function push_monster(m,force,sx,sy)
 if not sx then
  sx,sy=get_pos(player)
 end
 m.hurt=14
 local a=atan2(m.x-sx,m.y-sy)
 m.dx+=cos(a)*force
 m.dy+=sin(a)*force
end

function draw_monster(m)
 add(drawlist, {
  sprite=m.s,
  x=m.x+m.xo,
  y=m.y+m.yo,
  flp=m.flp,
  palette=m.hurt<=0 and m.palette or 9,
  sdist=m.sdist,
  tsize=m.tsize,
 })
end

function draw_monster_hp()

 pal()
 for m in all(monsters) do
  if m.hp<m.maxhp then
   draw_bar(m.x-4,m.y+6,10,2,m.hp,m.maxhp,11,0)
  end
 end
 if pchar.hp<pchar.maxhp then
  draw_bar(player.x-4,player.y+6,10,2,pchar.hp,pchar.maxhp,11,0)
 end

end

function rnd_monster()
 return monsters[1+flr(rnd(#monsters))]
end

--[[

 objects
 
]]

objecttypes={
 arrow={
  datanames="s,sdist,dmg,speed,size,flying",
  data="20,3,10,5,1,true",
  init=function(o,d,pl,level)
   o.palette=pl
   o.level=level
   o.flp,o.s=get_dir_flp_spr(d,o.s,o.s+1)
   o.dx,o.dy=get_dir_vec(d,o.speed)
   sfxs "2"
  end,
  update=function(o)
   local die=move_actor(o)
   for m in all(monsters) do
    if col_check(o,m,3) then
     if m.hurt<=0 or not o.piercing then
       die=not o.piercing
       hurt_monster(m,o.dmg*o.level,get_pos(o))
      break
     end
    end
   end
   return die
  end,
 },
 torpedo={
  datanames="s,sdist,dmg,size,flying",
  data="32,3,6,1,true",
  init=function(o,pl,tx,ty,ally)
   o.palette=pl
   o.anim=0
   local a=atan2(tx-o.x,ty-o.y)
   o.dx,o.dy=cos(a)*2,sin(a)*2
   o.ally=ally
   if ally then o.dmg=pchar.level*5 end
   sfxs "11"
  end,
  update=function(o)
   o.anim+=1
   o.s=32+flr(o.anim/4)%2
   local die=move_actor(o)
   if o.ally then
    die=hurt_all_monsters(o,3) or die
   else
     if col_check(o,player,3) then
      hurt_player(o)
      die=true
     end
    end
   return die
  end,
 },
 wave={
  datanames="sdist,palette,dmg",
  data="3,7,10",
  init=function(o,d)
   o.flp,o.s=get_dir_flp_spr(d,54,55)
   o.dx,o.dy=get_dir_vec(d,4)
   sfxs "15"
  end,
  update=function(o)
   o.x+=o.dx
   o.y+=o.dy
   if o.x<0 or o.y<0 or o.x>256 or o.y>256 then
    return true
    end
   if col_check(o,player,4) then
    hurt_player(o)
    die=true
   end
   return false
  end,
 },
 tree={
  sdist=4,
  init=function(o)
   o.life=0
   o.g=0
  end,
  update=function(o)
   o.life+=1
   o.g+=1
   if o.life%20==0 and #monsters>0 then
    local t=rnd_monster()
    add_object("torpedo",o.x,o.y,1,t.x,t.y,true)
   end
   return o.life<=0
  end,
  draw=function(o)
   local rs=unp "6,4,4,3,3,2,7,5,1,7,5,1,6,2,8,2,7,2"
   for c=1,5 do
    local r=min(o.g,rs[c])
    local x,y=o.x+rs[c+5],o.y+rs[c+10]
    circfill(x-4,y-4,r,3)
    circfill(x-6,y-6,r,11)
   end
  end,
 },
 flame={
  init=function(o,life,pl,dmg)
   o.life=life or 150
   o.palette=pl or 3
   o.dmg=dmg or 2*pchar.level
  end,
  update=function(o)
   o.life-=1
   o.s=48+o.life%2
   if o.palette==2 then
    if col_check(o,player,3) then
     hurt_player(o)
    end
   else
    hurt_all_monsters(o,3)
   end
   return o.life<=0
  end,
 },
 beartrap={
  dmg=150,
  init=function(o)
   o.palette=0
   o.state=30
  end,
  update=function(o)
   o.s=51
   if o.state>0 then
    o.state-=1
   elseif o.state<0 then
    o.state+=1
    return o.state>=0
   end
   o.s=50
   if hurt_all_monsters(o,6) then
    o.state=-30
   end
   return false
  end,
 },
 bees={
  datanames="sdist,bsprite,speed,flying,dmg",
  data="3,52,1,true,2",
  update=function(o)
   monstermethods.bounce(o)
   o.collision=move_actor(o)
   o.flp=not o.flp
   hurt_all_monsters(o,4)
  end,
 },
 vampire={
  datanames="sdist,bsprite,palette,dx,dy,speed,flying",
  data="3,72,5,0,0,3,true",
  update=function(o)
   if not o.target or o.target.hp<=0 then
    o.target=rnd_monster()
   end
   monstermethods.home(o)
   move_actor(o)
   if o.target==player then
    o.target=nil
   elseif o.target and col_check(o,o.target,5) then
    if hurt_monster(o.target,25,get_pos(o)) then
     add_item("hpotion",o.x,o.y).potency=5
    end
    return true
   end
  end,
 },
 shadow={
  init=function(o)
   o.history={}
   for i=1,60 do
    o.history[i]=tcopy(pdraw)
   end
  end,
  update=function(o)
   for i=1,59 do
    o.history[i]=o.history[i+1]
   end
   o.history[60]=tcopy(pdraw)
   pdraw=tcopy(o.history[1])
   add(drawlist,pdraw)
   if pdraw.arrow then
    add_object("arrow",pdraw.x,pdraw.y,pdraw.arrow,7,1)
   end
  end,
 },
 bloodrain={
  datanames="life,s,palette,flp",
  data="35,32,10,true",
  init=function(p)
   p.y-=35
  end,
  update=function(p)
   p.y+=1
   p.life-=1
   p.sdist=p.life
   return p.life<=0
  end,
 },
 grenade={
  life=60,
  s=53,
  init=function(o,d,p)
   o.bp=p
   o.palette=p
   o.dx,o.dy=get_dir_vec(d,5)
   o.dmg=50*pchar.level
  end,
  update=function(o)
   friction(o)
   move_actor(o)
   o.life-=1
   if o.life<=35 then
    o.palette=flr(o.life/5)%2==0 and o.bp or 9
   end
   if o.life<=0 then
    if o.bp==6 then
     add_particle("vortex",o.x,o.y)
    else
     add_particle("expl",o.x,o.y)
     hurt_all_monsters(o,25)
     sfxs "12"
    end
    return true
   end
   return false
  end,
 },
 daemoncape={
  datanames="sdist,tsize,s",
  data="4,2,128",
  offsets=unp "-5,-5,5,-15,5,-15,-5,-5",
  init=function(o,m)
   o.m=m
  end,
  update=function(o)
   local m=o.m
   if m.hp<=0 then
    return true
   end
   local d=m.d
   o.flp,o.s=get_dir_flp_spr(d,128,130)
   o.x,o.y=m.x+o.offsets[d+1],m.y+o.offsets[d+5]
   if flr(m.move/6)%2==1 then
    o.s+=4
   end
  end,
 }
}
do
 local missile=tcopy(objecttypes.arrow)
 missile.data="22,3,15,3,1,true"
 objecttypes["missile"]=missile
 
end


function add_object(tstr,x,y,...)
 local t=objecttypes[tstr]
 local o={
  x=x,
  y=y,
 }
 tcopy(t,o)
 if o.datanames then
  pcpy(unp(o.datanames),unp(o.data),o)
 end
 if o.init then
  o:init(...)
 end
 add(objects,o)
 return o
end

function add_pobject(tstr,...)
 return add_object(tstr,player.x,player.y,...)
end

function update_objects()

 for o in all(objects) do
  if o:update() then
   del(objects,o)
  elseif o.draw then
   add(drawlist,{
    meth=o.draw,
    sdist=o.sdist,
    data=o,
   })
  elseif o.s then
   add(drawlist,{
    sprite=o.s,
    x=o.x-3,
    y=o.y-3,
    flp=o.flp,
    palette=o.palette,
    sdist=o.sdist,
    tsize=o.tsize, 
   })
  end
 end
end


--[[

 items
 
]]

itemtypes.hpotion={
 pickup=function(i)
  if pchar.hp<pchar.maxhp then
   local amount=i.potency or 500
   pchar.hp=min(pchar.maxhp,pchar.hp+amount)
   return true
  end
  return false
 end,
 sprite=24,
 palette=5,
}

function add_item(t,x,y)
 local t=itemtypes[t]
 local i={
  x=x,
  y=y,
  t=t,
  palette=t.palette
 }
 add(items,i)
 add_particle("item",x,y)
 return i
end

function update_items()

 for i in all(items) do
  if i.t.update then
   i.t.update(i)
  end
  if abs(player.x-i.x)<5 and abs(player.y-i.y)<5 then
   if i.t.pickup then
    if i.t.pickup(i) then
     del(items,i)
    end
   end
  end
 end

end

function draw_item(item)
 local t=item.t
 local ox,oy=-3+cos(ticker*.03),-3+sin(ticker*.02)
 add(drawlist, {
  sprite=t.sprite,
  x=item.x+ox,
  y=item.y+oy,
  palette=item.palette,
  sdist=2+cos(ticker*.04),
 })
end

function pickup_power(item)
 player.flying=false
 transit_character(pchar,pchar,pchar.power,item.t.power)
 pchar.power=item.t.power
 pchar.mp=pchar.maxmp
 
 add_monsters()
 return true
end

function pickup_char(item)
 player.flying=false
 transit_character(pchar,chars[item.t.name])
 pchar=chars[item.t.name]
 worldchars[item.t.name]=false
 
 add_monsters()
 return true
end

function update_char_item(item)
 item.palette=chars[item.t.name].power.palette
end

--[[
 
 particles
 
]]

function draw_particle_sprite(p,x,y)
 set_palette(p.palette)
 spr(p.sprite,x,y,1,1,p.flp,p.flp)
end

particletypes={
 item={
  life=30,
  draw=function(p,x,y,l)
   local c=flr(5+l/20)
   line(x,0,x,256,c)
   line(0,y,256,y,c)
   local d=l*2
   rect(x-d,y-d,x+d,y+d,c)
  end,
 },
 ping={
  draw=function(p,x,y,l)
   local d=l*2
   circ(x,y,d,p.c)
  end,
  init=function(p,c,d)
   p.c=c or 11
   p.life=d or 30
  end,
 },
 slash={
  life=3,
  draw=draw_particle_sprite,
  init=function(p)
   local d=playerdir
   p.palette=pchar.power.palette
   p.flp,p.sprite=get_dir_flp_spr(d,17,18)
   local warrioroffsets=unp "-4,-4,-13,6,-13,6,-4,-4"
   p.x+=warrioroffsets[d+1]
   p.y+=warrioroffsets[d+5]
  end,
 },
 whip={
  life=5,
  draw=function(p)
   line(p.x,p.y,p.ex,p.ey,4)
  end,
  init=function(p)
   p.d=playerdir
   local warrioroffsets=unp "2,-2,-6,6,-6,6,-2,1"
   p.x+=warrioroffsets[playerdir+1]
   p.y+=warrioroffsets[playerdir+5]
   p.ex,p.ey=get_dir_off(p,playerdir,24+8*pchar.level)
  end,
 },
 bolt={
  life=10,
  init=function(p,ex,ey)
   p.ex,p.ey=ex,ey
  end,
  draw=function(p)
   line(p.x,p.y,p.ex,p.ey,7)
   local a=atan2(p.ex-p.x,p.ey-p.y)
   local d=(abs(p.ex-p.x)+abs(p.ey-p.y))*.6
   for i=-3,3,2 do
     local b=a+rnd()*.1*sgn(i)
     local x,y=p.x+cos(b)*d,p.y+sin(b)*d
     line(p.x,p.y,x,y,12)
     line(x,y,p.ex,p.ey,12)
    end
  end,
 },
 smite={
  draw=draw_particle_sprite,
  init=function(p,pl)
   p.palette=pl
   p.sprite=19
   p.life=4+rnd(4)
  end
 },
 bless={
  draw=draw_particle_sprite,
  life=9,
  sprite=38,
  update=function(p)
   p.sprite=flr(41-p.life/3)
  end,
 },
 blood={
  draw=function(p,x,y)
   circfill(x+1,y+1,p.size,2)
   circfill(x,y,p.size,8)
  end,
  init=function(p)
   p.life=8+rnd(4)
   p.size=1+rnd(4)
   p.x+=-3+rnd(6)
   p.y+=-3+rnd(6)
  end,
  update=function(p)
   p.x+=-1+rnd(2)
   p.y+=-1+rnd(2)
   if rnd()<.3 then
    p.size-=1
   end
  end,
 },
 shield={
  life=3,
  draw=function(p)
   circ(p.x,p.y,6+p.life,p.pl+p.life)
  end,
  init=function(p,pl)
   p.pl=pl or 4
  end,
 },
 whirl={
  life=10,
  update=function(p)
   p.x+=p.dx
   p.y+=p.dy
  end,
  draw=function(p)
   set_palette(p.pl)
   spr(34+p.life%4,p.x-3,p.y-3)
  end,
  init=function(p,pl,dx,dy)
   p.pl=pl
   p.dx=dx or 0
   p.dy=dy or 0
  end,
 },
 text={
  life=60,
  update=function(p)
   p.y-=p.life*.0075
  end,
  draw=function(p)
   sprint(p.text,p.x,p.y,p.col)
  end,
  init=function(p,text,col)
   p.text=text
   p.col=col or 7
  end
 },
 vortex={
  life=120,
  prerender=true,
  update=function(p)
   if p.life%15==0 then
    for m in all(monsters) do
     push_monster(m,-3,p.x,p.y)
    end
    sfxs "4"
   end
  end,
  draw=function(p)
   circfill(p.x,p.y,min(120-p.life,10),1)
  end,
 },
 expl={
  life=20,
  draw=function(p)
   circfill(p.x,p.y,15,7)
  end,
 },
}

function add_particle(tstr,x,y,...)
 local t=particletypes[tstr]
 local p={
  t=t,
  life=t.life,
  x=x,
  y=y,
 }
 if t.init then
  t.init(p,...)
 end
 add(particles,p)
 return p
end

function add_pparticle(tstr,...)
 return add_particle(tstr,player.x,player.y,...)
end

function update_particles()

 for i in all(particles) do
  if i.t.update then
   i.t.update(i)
  end
  i.life-=1
  if i.life<=0 then
   del(particles,i)
  end
 end
end

function draw_particles(pre)
 pal()
 palt(0,false)
 palt(14,true)
 for p in all(particles) do
  if p.prerender==pre then
   p.t.draw(p,p.x,p.y,p.life)
  end
 end
end

--[[

 map stuff

]]

function update_map()

  worldtick-=1
  if worldtick <=0 then
   worldtick=60
   
   local classremains=false
   for cn in all(classnames) do
    if worldchars[cn] then
     classremains=true
     break
    end
   end
   -- check spawn conditions
   local classitem=false
   local poweritem=false
   for i in all(items) do
    if i.t.ident=="class" then
     classitem=true
    elseif i.t.ident=="power" then
     poweritem=true
    end
   end
   
   if not classitem and classremains then
    local c=nil
    while true do
     c=flr(rnd(#classnames))+1
     if worldchars[classnames[c]] then
      c=classnames[c]
      break
     end
    end
    add_item(c,rnd_free_pos())
   elseif not poweritem and worldnextpower then
    add_item(worldnextpower,rnd_free_pos())
    worldnextpower=nil
   end
   
   if not classitem and not classremains and not exitopen and #monsters==0 then
    exitopen=true
    sfxs "7"
    for x=1,3+worldwidth*12 do
     for y=1,3+worldheight*12 do
      local t=mget(x,y)
      if fget(t,7) then
       mset(x,y,t+4)
      end
     end
    end
   end
   if exitopen then
    add_particle("ping",64,20)
   end
  end

 if exitopen and abs(player.x-64)<3 and abs(player.y-20)<3 then
  if worldroom==4 then
   music(-1)
   transit_level(worldlevel==4)
  end
  setup_next_room()
 end
end

function setup_next_room()

 monsters={}
 items={}
 objects={}
 particles={}
 
 local ww=unp "1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2"
 local wh=unp "1,1,2,2,1,1,2,2,1,1,2,2,1,1,2,2"
 local wx=unp "28,44,60,92,44,96,76,92,96,112,60,92,112,44,76,32"
 local wy=unp "0,0,0,0,0,28,0,0,28,28,0,0,28,0,0,16"

 if not worldlevel then
  worldlevel=1
  worldroom=1
  worldpalette=0
  startmusic=27
 else
  worldroom+=1
  if worldroom>4 then
   startmusic=27
   worldroom=1
   worldlevel+=1
   worldpalette+=1
   if worldlevel>4 then
    worldlevel=1
   end
  end
 end
 local wi=worldroom+(worldlevel-1)*4
 worldwidth=ww[wi]
 worldheight=wh[wi]
 worldmx=wx[wi]
 worldmy=wy[wi]
 
 worldchars={}
 for cn,c in pairs(chars) do
  if c~=pchar then
   worldchars[c.name]=true
  end
 end

 exitopen=false
 worldtick=60
 worldnextpower=powernames[flr(rnd(#powernames-1))+2]
 playerdir=0
 setup_map()
 
 player.x=64
 player.y=worldheight*96+12
 playerattack=0
 player.hurt=0
 
 add_monsters()
 if worldroom==4 then
  local bosses=unp "bigslime,master,bigeye,daemon"
  add_monster(monstertypes[bosses[worldlevel]],112,112)
  startmusic=33
 end

end

function add_monsters()
 local c=worldwidth+worldheight
 local l=worldlevel+flr(worldroom/3)
 for a=1,worldlevel do
   while true do
    local v=monstertypes[monsternames[flr(rnd(#monsternames))+1]]
    local ml=v.level
    if ml>0 and (ml==l or (ml<=l and rnd()<.1)) then
    for i=1,c do
     add_monster(v,rnd_free_pos())
    end
    break
   end
  end
 end
end

function setup_map()

 local mw,mh=worldwidth,worldheight
 local tw,th=mw*12+3,mh*12+3
 
 for x=0,tw do
  for y=0,th do
   local sx,sy=worldmx+x,worldmy+y
   mset(x,y,mget(sx,sy))
  end
 end

 --doors 
 mset(7,th-1,217)
 mset(8,th-1,218)
 mset(7,1,197)
 mset(8,1,198)
 
end

function mapwall(x,y)
 return fget(mget(flr(x/8),flr(y/8)),1)
end

function mapgroundblock(x,y)
 return fget(mget(flr(x/8),flr(y/8)),0)
end

function rnd_free_pos()
 while true do
  local x=(2+flr(rnd(worldwidth*12)))*8+4
  local y=(2+flr(rnd(worldheight*12)))*8+4
  if not mapgroundblock(x,y) and manhattan(player,{x=x,y=y})>20 then
   return x,y
  end
 end
end

--[[

 transitions

]]

function transit_character(from,to,fpower,tpower)

 transition={
  to=to,
  from=from,
  tpower=tpower or to.power,
  fpower=fpower or from.power,
  tick=0,
  update=function(t)
   t.tick+=1
   if t.tick==1 then
    sfxs "0"
   elseif t.tick==26 then
    sfxs "1"
   end
   return false
  end,
  draw=function(t)
   local to=t.to
   local from=t.from
   local tick=t.tick
   local tpower=t.tpower
   local fpower=t.fpower
   
   circfill(63,63,min(tick*3,40),0)
    do
     clip(0,52,128,9)
     local cstr=fpower.name.." "..from.name
     local cstr2=tpower.name.." "..to.name
     local pos=max(-8,min(1,-20+tick))
     cprint(cstr,64,60+pos,fpower.textcol)
     cprint(cstr2,64,52+pos,tpower.textcol)
    clip()
    end
    do
     local a,s=get_powers(to,tpower)
      if t.tick>26 then
       print("\x8e "..a.." lvl"..to.level,30,62,7)
       print("\x97 "..s.." lvl"..to.level,30,70,7)
      end
     end
  end,
 }
end

function transit_level(victory)
 transition={
  tick=0,
  victory=victory,
  update=function(t)
   t.tick+=1
  end,
  draw=function(t)
   rectfill(0,0,128,t.tick*5,0)
   if victory then
    print("you are winner!",34,14,9)
    if t.tick==1 then
     sfxs "9"
    end
   else
    print("level "..(worldlevel-1).."/4 complete",36,14,7)
   end
   local y=25
     for cn in all(classnames) do
      local c=chars[cn]
      set_palette(c.power.palette)
      spr(c.sprite,20,y)
      set_palette()
      print(c.power.name.." "..c.name.." lvl"..c.level,32,y,c.power.textcol)
      print(c.hp.."/"..c.maxhp,34,y+8,11)
      print(c.mp.."/"..c.maxmp,74,y+8,12)
      y+=20
      
     end

  end,
 }
end
