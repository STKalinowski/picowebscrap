-- feed the ducks
-- by kittenm4ster

-- The following source code has
-- been minified to fit within
-- size limits.  The original
-- source code is available at
-- https://github.com/andmatand/feed-the-ducks
fps=30
buttons={}for i=0,5 do
buttons[i]={down=false
}end
function update_buttons()
for i,b in pairs(buttons) do
if btn(i) then
if not b.down then
b.down=true
btn_pushed(i)
end
else
b.down=false
end
end
end
function create_timer(frames)
return {length=frames,value=frames,reset=function(self)
self.value=self.length
end,update=function(self)
if self.value>1 then
self.value-=1
else
return true
end
end
}end
function cprint(s,x,y)
print(s,x-(((#s*4)-1)/2),y)
end
function shallow_copy(t)
local t2={}for k,v in pairs(t) do
t2[k]=v
end
return t2
end
function ease_out_cubic(t,b,c,d)
t=t/d-1
return c*((t^3)+1)+b
end
function ease_in_cubic(t,b,c,d)
t=t/d
return c*(t^3)+b
end
function game1()
function game1_init()
poke(0x5f2c,3)
gamestate=nil
camx=64
camy=-32
screen_w=64
max_velocity_x=1
max_velocity_y=5
default_gravity=.32
ponds={}find_ponds()
actors={}foods={}boatduck=create_actor({anims={default=create_anim({8},0),chomp=create_anim({9,10,9},8)
},canswim=true,pond=ponds[1],drawh=4,gravity=0,maxvx=.4,feetoffsets={1,6}})
boatduck.minx=ponds[1].x1-1
boatduck.maxx=(ponds[1].x2-boatduck.draww)+2
fatduck=create_actor({anims={default=create_anim({8},0),chomp=create_anim({9,10,9},8)
},drawh=4,gravity=0,palette={{4,5}},feetoffsets={1,6},canswim=true,state='wait'
})
goose=create_actor({anims={default=create_anim({11},0),walk=create_anim({11,13,12,14},3,true)
},drawh=10,spriteh=11,bottomoffset=10,feetoffsets={1,7},state='wait',gravity=0,minteleportx=0
})
kitty=create_actor({anims={default=create_anim({1},0),jump=create_anim({5},0),land=create_anim({6},8),crouch=create_anim({6},0),walk=create_anim({4,1},4,true),landwalk=create_anim({24,6},4),turn=create_anim({7},8,true)
},draww=6,drawh=5,dir=1,xhit={offset=2,w=5,},flipoffset=2,feetoffsets={3,6}})
checkpoints={}find_things_on_map()
items={{x=8,y=40,sprite=36
}}local corn=items[1]
corn.box={x1=corn.x,y1=corn.y+2,x2=corn.x+5,y2=corn.y+7
}springplatforms={}boatduck.spring=create_spring_platform(boatduck,{{offset={x=3,y=2},w=5}})
add(springplatforms,boatduck.spring)
fatduck.spring=create_spring_platform(fatduck,{head={offset={x=1,y=4},w=2},bill={offset={x=0,y=3},w=2},back={offset={x=3,y=2},w=5}})
add(springplatforms,fatduck.spring)
act2title={text='where is goose?',x=3,y=40
}player=kitty
for sp in all(springplatforms) do
sp:update_platform_boxes()
end
fatduck.spring.disabled_platforms={head=fatduck.spring.platforms.head,bill=fatduck.spring.platforms.bill
}fatduck.spring.platforms.head=nil
fatduck.spring.platforms.bill=nil
update_act2_title_cr=cocreate(update_act2_title)
end
function _update()
update_buttons()
if player.isenabled then
process_player_input()
end
remove_expired_foods()
update_ponds()
update_npcs()
pre_update_spring_platforms()
update_actors()
save_checkpoint(kitty)
update_spring_platforms()
update_items()
if gamestate=='act2 title' then
coresume(update_act2_title_cr)
end
post_update_actors()
update_camera()
end
function _draw()
cls()
camera(camx,camy)
map(0,0,0,0,128,8,128)
if gamestate=='act2 title' then
draw_act2_title()
end
draw_items()
draw_actors()
draw_ponds()
draw_foods()
map(0,0,0,0,128,8,1)
if gamestate=='act2 title' then
fade_act2_title_bg()
elseif gamestate=='credits' then
color(7)
cprint('thanks for', 96, 6)
cprint('playing', 96, 12)
cprint('feed the ducks', 160, 4)
cprint('by andrew', 160, 16)
cprint('vector art by', 160, 28)
cprint('aubrianne', 160, 34)
end
end
function draw_act2_title()
print(act2title.text,camx+act2title.x,act2title.y,7)
rectfill(goose.x,act2title.y,camx+64,act2title.y+4,0)
end
function fade_act2_title_bg()
local fades={}fades[3]={3,1,0}fades[4]={2,1,0}fades[10]={4,5,0}local i=min(3,flr(39-act2title.y))
if i>0 then
for k,fade in pairs(fades) do
pal(k,fade[i],1)
end
end
end
function round_box_to_pixels(box)
return {x1=flr(box.x1),y1=flr(box.y1),x2=flr(box.x2),y2=flr(box.y2)
}end
function actor_is_on_platform(actor,platform)
local actorbox=round_box_to_pixels(get_actor_y_hitbox(actor))
local platformbox=round_box_to_pixels(platform.box)
return (actorbox.x2>=platformbox.x1 and
actorbox.x1<=platformbox.x2 and
actorbox.y2==platformbox.y1-1)
end
function box_overlap(box1,box2)
return (box1.x2>=box2.x1 and
box1.x1<=box2.x2 and
box1.y2>=box2.y1 and
box1.y1<=box2.y2)
end
function create_actor(props)
local defaults={x=0,y=0,vx=0,vy=0,bottomoffset=7,flipoffset=0,spriteh=8,draww=8,drawh=8,xhit={w=8,offset=0},scale=1,dir=-1,gravity=default_gravity,maxvx=max_velocity_x,maxvy=max_velocity_y,feetoffsets={0,0},friction={air=.8,ground=.3},bounce={},oldstate={support=true},isenabled=true,anim=props.anims.default
}for k,v in pairs(props) do
defaults[k]=v
end
add(actors,defaults)
return defaults
end
function get_actor_x_hitbox(actor)
local box={x1=actor.x+actor.xhit.offset,x2=actor.x+actor.xhit.offset+actor.xhit.w-1,y1=actor.y+actor.bottomoffset-(actor.drawh-1),y2=actor.y+7
}if actor.dir==1 then
box.x1=actor.x+8-(actor.xhit.offset+actor.xhit.w-actor.flipoffset)
box.x2=box.x1+actor.xhit.w-1
end
return box
end
function get_actor_y_hitbox(actor)
local box={x1=actor.x+actor.feetoffsets[1],x2=actor.x+actor.feetoffsets[2],y2=actor.y+actor.bottomoffset
}box.y1=box.y2
return box
end
function create_anim(indexes,delay,loop)
if loop==nil then loop=false end
return {indexes=indexes,i=1,timer=create_timer(delay),loop=loop,update=function(self)
if self.timer:update() then
self.timer:reset()
if self.i<#self.indexes then
self.i+=1
elseif self.loop then
self:restart()
end
end
end,get_index=function(self)
return self.indexes[self.i]
end,restart=function(self)
self.i=1
self.timer:reset()
end,is_done=function(self)
return (self.i==#self.indexes and self.timer.value==1)
end
}end
function create_pond()
return {anim=create_anim({18,19},fps,true),tiles={},offset={x=0,dir=-1,timer=create_timer(fps/2)
}}end
function draw_actor(actor)
local i=actor.anim:get_index()
local xoffset=0
local flipx=false
if actor.dir==1 then
flipx=true
xoffset=actor.flipoffset
end
if actor.palette then
for entry in all(actor.palette) do
pal(entry[1],entry[2])
end
end
if actor.scale==1 and actor.spriteh==8 and false then
spr(i,actor.x+xoffset,actor.y,1,1,flipx)
else
local sx=(i % 16)*8
local sy=flr(i/16)*8
sspr(sx,sy,8,actor.spriteh,actor.x+xoffset,actor.y,8*actor.scale,actor.spriteh*actor.scale,flipx)
end
pal()
end
function draw_foods()
for food in all(foods) do
draw_actor(food)
end
end
function draw_items()
for item in all(items) do
spr(item.sprite,item.x,item.y)
end
end
function draw_actors()
for a in all(actors) do
if a.isenabled and not a.isfood then
draw_actor(a)
end
end
end
function draw_ponds()
for pond in all(ponds) do
local i=pond.anim:get_index()
for xy in all(pond.tiles) do
spr(i,(xy[1]*8)+pond.offset.x,xy[2]*8)
end
end
end
function find_ponds()
local pond=nil
for x=0,128 do
local columnhaswater=false
for y=0,8 do
if fget(mget(x,y),4) then
if not pond then
pond=create_pond()
pond.x1=x*8
end
add(pond.tiles,{x,y})
columnhaswater=true
end
end
if pond and not columnhaswater then
local y1=pond.tiles[1][2]
for tiley=y1,7 do
add(pond.tiles,{x,tiley})
end
pond.x2=(x*8)-1
add(ponds,pond)
pond=nil
end
end
end
function solid_down(x,y,fallthrough)
local index=mget(x/8,y/8)
if fget(index,2) and flr(y) % 8==0 then
if fallthrough and not fget(index,1) then
return false
end
return true
else
return false
end
end
function solid_x(x,y)
if x==-1 then
return true
end
local index=mget(x/8,y/8)
return fget(index,1)
end
function liquid(x,y)
local index=mget(x/8,y/8)
return fget(index,4)
end
function move_actor_to_checkpoint(actor)
if actor.checkpoint then
actor.x=actor.checkpoint.x
actor.y=actor.checkpoint.y
actor.dir=actor.checkpoint.dir
actor.vx=0
actor.vy=0
end
end
function save_checkpoint(actor)
local actorbox=get_actor_y_hitbox(actor)
for checkpoint in all(checkpoints) do
local checkpointbox={x1=checkpoint.x,y1=0,x2=checkpoint.x+7,y2=64
}if box_overlap(actorbox,checkpointbox) then
actor.checkpoint={x=checkpoint.x,y=checkpoint.y,dir=actor.dir
}break
end
end
end
function find_things_on_map()
for x=0,128 do
for y=0,8 do
local s=mget(x,y)
local actor
local xscaled=x*8
local yscaled=y*8
if s==32 then
local checkpoint={x=xscaled,y=yscaled
}add(checkpoints,checkpoint)
end
if s==1 then
actor=kitty
elseif s==8 then
actor=boatduck
elseif s==9 then
actor=fatduck
elseif s==11 then
actor=goose
end
if actor then
actor.x=xscaled
actor.y=yscaled
end
end
end
end
function collide_x(actor,endx)
local startx=actor.x
local dir
if endx>startx then
dir=1
elseif endx<startx then
dir=-1
else
return false
end
local hit=false
for x=startx,endx,dir do
local checkx=flr(x)
local testactor={x=checkx,y=actor.y,dir=actor.dir,xhit=actor.xhit,bottomoffset=actor.bottomoffset,flipoffset=actor.flipoffset,drawh=actor.drawh
}local box=get_actor_x_hitbox(testactor)
if dir==-1 then
if solid_x(box.x1-1,box.y1) or solid_x(box.x1-1,box.y2) then
hit=true
end
elseif dir==1 then
if solid_x(box.x2+1,box.y1) or solid_x(box.x2+1,box.y2) then
hit=true
end
end
if hit then
if actor.isfood and actor.support ~='water' then
actor.bounce.vx=-dir*abs(actor.vx)*.5
end
actor.x=flr(x)
return true
end
end
end
function collide_y(actor,endy)
local starty=actor.y
if endy<starty then
return
end
local leftoffset=actor.feetoffsets[1]
local rightoffset=actor.feetoffsets[2]
local x1=actor.x+leftoffset
local x2=actor.x+rightoffset
local hit=false
for y=starty,endy,1 do
if actor.isfood then
local checky=flr(y)+7
if liquid(x1,checky) or liquid(x2,checky) then
hit=true
actor.y=checky-7
actor.support='water'
end
end
local testactor={x=actor.x,y=y,feetoffsets=actor.feetoffsets,bottomoffset=actor.bottomoffset
}local y2=testactor.y+testactor.bottomoffset
if solid_down(x1,y2+1,actor.isfallingthroughplatform) or
solid_down(x2,y2+1,actor.isfallingthroughplatform) then
hit=true
end
if not hit and not actor.isfallingthroughplatform then
for sp in all(springplatforms) do
if sp.actor ~=actor then
for _,platform in pairs(sp.platforms) do
if actor_is_on_platform(testactor,platform) then
hit=true
actor.y=platform.box.y1-8
actor.support=sp.actor
add(platform.occupants,actor)
if actor==player then
platform.hit={vy=actor.vy}elseif actor.isfood then
actor.bounce.vy=-actor.vy*.5
end
break
end
end
end
end
end
if hit then
if not actor.support then
actor.support=true
actor.y=flr(y)
if actor==kitty and not actor.oldstate.support then
sfx(11)
end
end
return true
end
end
end
function update_items()
local playerbox=get_actor_y_hitbox(player)
playerbox=round_box_to_pixels(playerbox)
local newitems={}for item in all(items) do
if (box_overlap(playerbox,item.box)) then
if item.sprite==36 then
sfx(1)
player.hasfood=true
end
else
add(newitems,item)
end
end
items=newitems
end
function create_spring_platform(actor,platforms)
return {actor=actor,originalposition={x=actor.x,y=actor.y},offset={x=0,y=0},tightness=.15,damping=.3,platforms=platforms,receive_hits=function(self)
for _,platform in pairs(self.platforms) do
if platform.hit then
self.actor.vy+=platform.hit.vy
platform.hit=nil
end
end
end,count_occupants=function(self)
for p in all(self.platforms) do
return #p.occupants
end
return 0
end,apply_spring_force=function(self)
local velocitydelta
velocitydelta=self.tightness*
(self.originalposition.y-self.actor.y)
velocitydelta=velocitydelta-(self.actor.vy*self.damping)
self.actor.vy+=velocitydelta
local gate=.025
if self:count_occupants()>0 then
gate=.01
end
if abs(self.actor.vy)<gate and
abs(self.originalposition.y-self.actor.y)<gate
then
self.actor.vy=0
self.actor.y=self.originalposition.y
end
end,check_for_y_collision=function(self,overridevy)
if self.actor.vy>=0 and not overridevy then
return
end
for _,platform in pairs(self.platforms) do
local newy=platform.box.y1+(overridevy or self.actor.vy)
local testplatformbox=shallow_copy(platform.box)
for y=platform.box.y1,newy,-1 do
for actor in all(actors) do
if actor ~=self.actor and not actor.isfallingthroughplatform then
testplatformbox.y1=y
testplatformbox.x1=flr(testplatformbox.x1)
testplatformbox.x2=flr(testplatformbox.x2)
local actorbox=get_actor_y_hitbox(actor)
actorbox.x1=flr(actorbox.x1)
actorbox.x2=flr(actorbox.x2)
actorbox.y1=actorbox.y2
if box_overlap(testplatformbox,actorbox) then
actor.support=self.actor
actor.y=newy-8
end
end
end
end
end
end,move_occupants=function(self)
for _,platform in pairs(self.platforms) do
for occupant in all(platform.occupants) do
if not occupant.isfallingthroughplatform then
occupant.y=platform.box.y1-8
if self.actor.x ~=self.actor.oldstate.x then
local pixeldelta=flr(self.actor.x)-
flr(self.actor.oldstate.x)
occupant.x+=pixeldelta
end
end
end
end
end,on_direction_change=function(self)
for _,platform in pairs(self.platforms) do
for occupant in all(platform.occupants) do
if self.actor.dir ~=self.actor.oldstate.dir then
occupant.dir=-occupant.dir
local oldoffset=flr(occupant.x)-flr(self.actor.x)
occupant.x=self.actor.x-oldoffset-occupant.flipoffset
end
end
end
end,update_platform_boxes=function(self)
for _,platform in pairs(self.platforms) do
local scale=self.actor.scale
local x=self.actor.x
if self.actor.dir==-1 then
x+=platform.offset.x*scale
end
local y=self.actor.y+(scale*8)-(platform.offset.y*scale)
local w=platform.w*scale
platform.box={x1=x,y1=y,x2=x+(w-1),y2=y
}end
end,update=function(self)
self:update_platform_boxes()
self:receive_hits()
self:apply_spring_force()
self:update_platform_boxes()
self:check_for_y_collision()
end
}end
function apply_x_velocity(actor)
local endx=actor.x+actor.vx
local hit=collide_x(actor,endx)
if hit then
actor.vx=0
if actor.bounce.vx then
actor.vx=actor.bounce.vx
actor.bounce.vx=nil
end
else
actor.x=endx
end
end
function apply_y_velocity(actor)
if actor.spring then
return
end
local endy=actor.y+actor.vy
local hit=collide_y(actor,endy)
if hit then
actor.vy=0
if actor.bounce.vy then
actor.vy=actor.bounce.vy
actor.bounce.vy=nil
end
else
actor.y=endy
end
end
function apply_physics(actor)
if actor.didphysics then
return
end
actor.didphysics=true
actor.vy+=actor.gravity
if not actor.iswalking then
local f
if actor.support then
f=actor.friction.ground
else
f=actor.friction.air
end
actor.vx*=f
if abs(actor.vx)<.01 then
actor.vx=0
end
end
if actor.vx>actor.maxvx then
actor.vx=actor.maxvx
elseif actor.vx<-actor.maxvx then
actor.vx=-actor.maxvx
end
if actor.vy>actor.maxvy then
actor.vy=actor.maxvy
end
apply_x_velocity(actor)
actor.support=nil
apply_y_velocity(actor)
if actor.minx then
if actor.x<actor.minx then
actor.x=actor.minx
end
end
if actor.maxx then
if actor.x>actor.maxx then
actor.x=actor.maxx
end
end
end
function create_food(owner)
local food=create_actor({anims={default=create_anim({16},0)},friction={air=1,ground=.5},x=owner.x+6,y=owner.y-3,vx=owner.dir+owner.vx,vy=-2+owner.vy,dir=owner.dir,flipoffset=-7,draww=1,drawh=1,ttl=create_timer(5*30),isfood=true
})
food.xhit.w=1
if owner.dir==1 then
food.x-=owner.flipoffset+1
end
return food
end
function btn_pushed(b)
if player.isenabled then
if b==4 then
if player==kitty and player.support then
if player.iscrouching then
player.vy=1
player.isfallingthroughplatform=true
else
sfx(0)
player.vy=-3.2
end
elseif player==boatduck then
boatduck.state='chomp'
end
elseif b==5 then
if player.hasfood then
sfx(2)
food=create_food(player)
add(foods,food)
end
end
end
end
function process_player_input()
player.iswalking=false
local delta=.16
if not player.support then
delta=delta*.75
end
if btn(0) then
player.dir=-1
if player.vx>0 then
delta*=1.5
end
player.vx-=delta
player.iswalking=true
elseif btn(1) then
player.dir=1
if player.vx<0 then
delta*=1.5
end
player.vx+=delta
player.iswalking=true
end
if not player.iswalking and btn(3) then
player.iscrouching=true
else
player.iscrouching=false
end
if player.vy<0 and not btn(4) then
if player.vy<-1 then
player.vy=-1
end
end
end
function update_act2_title()
repeat yield() until goose.x==camx+63
music(0)
local frames=0
while frames<6*fps do
frames+=1
if act2title.y>30 then
act2title.y-=.2
end
yield()
end
game2()
game2_init()
end
function update_actors()
for actor in all(actors) do
if actor.isenabled then
apply_physics(actor)
update_anim_state(actor)
end
end
if fatduck.spring.platforms.head then
update_fatduck_platform_positions()
end
end
function remove_expired_foods()
local newfoods={}for food in all(foods) do
if food.ttl:update() or food.iseaten then
if not food.iseaten then
food.isexpired=true
end
del(actors,food)
else
add(newfoods,food)
end
end
foods=newfoods
end
function distance_from_duck_mouth(duck,food)
local d1=abs(food.x-duck.x)
local d2=abs(food.x-(duck.x+7))
if d2<d1 then
return d2,1
else
return d1,-1
end
end
function find_nearest_food(duck)
local nearest={food=nil,dist=99}for food in all(foods) do
if food.support=='water' then
if food.x>=duck.pond.x1 and food.x<=duck.pond.x2 then
local dist=distance_from_duck_mouth(duck,food)
if dist<nearest.dist then
nearest.dist=dist
nearest.food=food
end
end
end
end
return nearest.food
end
function on_camera_moved()
if camx>=448 then
if player.x<goose.x-32 then
local teleportx=camx+16
if teleportx>goose.minteleportx then
goose.x=teleportx
goose.minteleportx=teleportx
end
end
if camx==576 then
goose.x=camx+1
gamestate='act2 title'
player.isenabled=false
end
goose.vx=max_velocity_x
elseif player==boatduck then
kitty.x=0
if gamestate ~='credits' then
gamestate='credits'
music(4)
end
end
end
function update_camera()
if camy<0 then
local speed=-camy*.08
camy+=speed
if camy>=-0.5 then
camy=0
end
end
local edgex=player.x+player.flipoffset
if player.dir==1 then
edgex+=(player.draww-1)
end
if edgex<camx or edgex>camx+screen_w then
camx=edgex-(edgex % screen_w)
on_camera_moved()
end
camx=max(0,camx)
end
function actor_is_within_one_screen_away(actor)
return (actor.x+actor.draww>camx-64 and actor.x<camx+128)
end
function update_npcs()
if actor_is_within_one_screen_away(boatduck) and player ~=boatduck then
update_boatduck()
end
if actor_is_within_one_screen_away(fatduck) then
update_fatduck()
end
if actor_is_within_one_screen_away(goose) then
update_goose()
end
end
function update_boatduck()
boatduck.iswalking=false
boatduck.state='wait'
if boatduck.nearestfood and boatduck.nearestfood.isexpired then
boatduck.nearestfood=nil
end
if boatduck.nearestfood then
local food=boatduck.nearestfood
apply_physics(food)
local dist,targetdir=distance_from_duck_mouth(boatduck,food)
local targetx
for i=1,2 do
targetx=(targetdir==-1 and food.x or food.x-7)
if targetx<boatduck.minx then
targetdir=-1
elseif targetx>boatduck.maxx then
targetdir=1
else
break
end
end
boatduck.dir=targetdir
boatduck.spring:on_direction_change()
boatduck.vx=(targetx-boatduck.x)*.08
if dist<1 then
if boatduck.anim==boatduck.anims.chomp and boatduck.anim.i==2 then
boatduck.nearestfood.iseaten=true
boatduck.nearestfood=nil
boatduck.state='wait'
else
boatduck.state='chomp'
end
end
else
if boatduck.anim ~=boatduck.anims.chomp or boatduck.anim:is_done() then
boatduck.nearestfood=find_nearest_food(boatduck)
end
end
end
function update_goose()
goose.iswalking=false
if goose.state=='wait' then
goose.gravity=0
if player.x>=396 then
goose.state='rise'
sfx(32)
end
elseif goose.state=='rise' then
if goose.y>37 then
goose.y-=1
else
goose.gravity=default_gravity
goose.state='turn'
end
elseif goose.state=='turn' then
goose.dir=1
goose.state='run'
elseif goose.state=='run' then
goose.iswalking=true
local delta=.16
goose.vx+=delta
end
end
function pre_update_spring_platforms()
for sp in all(springplatforms) do
for _,platform in pairs(sp.platforms) do
platform.occupants={}end
end
end
function update_spring_platforms()
for sp in all(springplatforms) do
sp:update()
end
update_spring_platform_actor_positions()
for sp in all(springplatforms) do
sp:update_platform_boxes()
end
for sp in all(springplatforms) do
sp:move_occupants()
end
end
function table_contains(t,value)
for v in all(t) do
if v==value then
return true
end
end
end
function update_spring_platform_actor_positions()
local uniqueactors={}for platform in all(springplatforms) do
if not table_contains(uniqueactors,platform.actor) then
add(uniqueactors,platform.actor)
end
end
for actor in all(uniqueactors) do
actor.y+=actor.vy
end
end
function slow_down_sfx(n)
local sfxaddr=0x3200+(68*n)
for i=0,31 do
local noteoffset=(i*2)
local byte1=peek(sfxaddr+noteoffset)
local pitch=band(byte1,63)
pitch-=2
byte1=band(byte1,64)
byte1=bor(byte1,pitch)
poke(sfxaddr+noteoffset,byte1)
end
local lenaddr=sfxaddr+65
local len=peek(lenaddr)
poke(lenaddr,len+2)
end
function set_duck_scale(duck,scale)
if scale>11 then
return
end
sfx(12)
slow_down_sfx(12)
if not duck.prescale then
duck.prescale={position={x=duck.x,y=duck.spring.originalposition.y
}}duck.spring.prescale={tightness=duck.spring.tightness,damping=duck.spring.damping
}end
duck.scale=scale
if duck.scale>1 then
if not duck.spring.platforms.head then
duck.spring.platforms.head=duck.spring.disabled_platforms.head
duck.spring.platforms.bill=duck.spring.disabled_platforms.bill
duck.spring.platforms.head.occupants={}duck.spring.platforms.bill.occupants={}end
end
duck.x=duck.prescale.position.x-(scale/4)
duck.y=duck.prescale.position.y-((scale-1)*8)
duck.spring.originalposition.y=duck.y
duck.spring.damping=duck.spring.prescale.damping+(scale/25)
duck.spring:update_platform_boxes()
for _,platform in pairs(duck.spring.platforms) do
for occupant in all(platform.occupants) do
occupant.y=platform.box.y1-8
if occupant.x+occupant.feetoffsets[1]<=platform.box.x1 then
occupant.x=platform.box.x1-occupant.feetoffsets[1]
end
end
end
end
function get_food_at_mouth(duck)
for food in all(foods) do
if food.support=='water' then
local foodx=flr(food.x)
if foodx>=duck.x-1 and foodx<=duck.x+(duck.scale-1) then
return food
end
end
end
end
function update_fatduck_platform_positions()
local headoffset=fatduck.spring.platforms.head.offset
local billoffset=fatduck.spring.platforms.bill.offset
local oldbilloffsety=billoffset.y
if fatduck.anim==fatduck.anims.chomp then
if fatduck.anim.i==1 or fatduck.anim.i==3 then
headoffset.y=3
billoffset.y=2
elseif fatduck.anim.i==2 then
headoffset.y=2
billoffset.y=1
end
else
headoffset.y=4
billoffset.y=3
end
if billoffset.y>oldbilloffsety then
fatduck.spring:check_for_y_collision((oldbilloffsety-billoffset.y)*fatduck.scale)
update_anim_state(kitty,true)
end
end
function update_fatduck()
if fatduck.targetfood then
if fatduck.targetfood.iseaten or fatduck.targetfood.isexpired then
fatduck.state='wait'
fatduck.targetfood=nil
else
fatduck.state='chomp'
end
end
if fatduck.targetfood and fatduck.state=='chomp' then
if fatduck.anim==fatduck.anims.chomp and fatduck.anim.i==2 then
fatduck.targetfood.iseaten=true
fatduck.targetfood=nil
set_duck_scale(fatduck,fatduck.scale+1)
end
elseif fatduck.state=='wait' then
fatduck.targetfood=get_food_at_mouth(fatduck)
end
end
function update_anim_state(actor,noupdate)
if actor.iswalking then
if actor.anim ~=actor.anims.walk and
actor.anim ~=actor.anims.turn and
actor.anim ~=actor.anims.landwalk then
if actor.anims.walk then
actor.anim=actor.anims.walk
actor.anim:restart()
end
end
end
if actor.anims.crouch then
if actor.iscrouching then
actor.anim=actor.anims.crouch
elseif actor.anim==actor.anims.crouch then
actor.anim=actor.anims.default
end
end
if actor.anims.walk then
if abs(actor.vx)<actor.maxvx*.25 then
actor.anims.walk.delay=8
else
actor.anims.walk.delay=4
end
end
local suddenturn=false
local sudden_turn_velocity=actor.maxvx*.1
if actor.dir==1 and actor.vx<0 then
suddenturn=true
elseif actor.dir==-1 and actor.vx>0 then
suddenturn=true
end
if suddenturn then
if actor.anims.turn then
actor.anim=actor.anims.turn
actor.anim:restart()
end
end
if not actor.support then
if actor.anims.jump then
actor.anim=actor.anims.jump
actor.anim:restart()
end
end
if not actor.oldstate.support and actor.support then
if actor.anims.land then
actor.anim=actor.anims.land
actor.anim:restart()
end
if actor.iswalking then
if actor.anims.landwalk then
actor.anim=actor.anims.landwalk
actor.anim:restart()
end
end
end
if actor.state=='chomp' and actor.anim ~=actor.anims.chomp then
actor.anim=actor.anims.chomp
actor.anim:restart()
end
if actor.anim==actor.anims.chomp and actor.anim:is_done() then
actor.state='wait'
end
if actor.anim.timer.length ~=0 and actor.anim:is_done() then
actor.anim=actor.anims.default
end
if not noupdate then
actor.anim:update()
end
end
function post_update_actors()
for actor in all(actors) do
actor.oldstate={x=actor.x,y=actor.y,dir=actor.dir,support=actor.support
}actor.isfallingthroughplatform=false
actor.didphysics=false
end
if kitty.y>64 then
sfx(3)
move_actor_to_checkpoint(kitty)
end
end
function update_ponds()
for pond in all(ponds) do
pond.anim:update()
local offset=pond.offset
if offset.timer:update() then
offset.timer:reset()
offset.x+=offset.dir
for food in all(foods) do
if food.support=='water' then
food.vx+=pond.offset.dir
end
end
if offset.x==-8 then
offset.dir=1
elseif offset.x==0 then
offset.dir=-1
end
end
end
end
end
function game2()
textpanew=14
numdecoys=2
painting_x=2
painting_y=27
painting_w=61
painting_h=99
day_names={'sunday','monday','tuesday','wednesday','thursday','friday','saturday'
}function create_menu(name,items,x,y,w)
return {name=name,items=items,x=x,y=y,w=w,sel=1,rowh=7,textoffsetx=0,iswindow=true,autosize=function(self)
local longest=0
for item in all(self.items) do
if #item>longest then
longest=#item
end
end
self.w=(longest*4)+19
if self.icons then
self.w+=10
self.rowh=9
self.textoffsetx=5
end
self.h=(#self.items*self.rowh)+8
end,draw=function(self,top)
if self.iswindow then
draw_window(self.x,self.y,self.x+self.w-1,self.y+self.h-1)
end
local x=self.x+(self.w/2)+self.textoffsetx
local y=self.y+5
local hw=self.w-(self.textoffsetx*2)-10
for i,txt in pairs(self.items) do
if self.icons then
spr(self.icons[i],self.x+5,y-1)
end
if top and i==self.sel and (self.flash==nil or self.flash % 4<=1) then
rectfill(x-(hw/2),y-1,x+(hw/2)-1,y+5,7)
color(0)
else
color(7)
end
cprint(txt,x,y)
y+=self.rowh
end
if self.art then
camera(-self.x-2,-self.y)
local shapes=parse_painting(self.art[1],self.art[2])
render_shapes(shapes)
camera()
end
end
}end
function draw_menus()
local top=#menustack
for i,menu in pairs(menustack) do
menu:draw(i==top)
end
end
function add_menu(m)
m:autosize()
add(menustack,m)
end
function execute_menu_item(menu,i)
if menu.name=='main' then
if i==1 then
local m=create_menu('investigate',{'question witness',here.action.desc,'call tipster'
},13,82)
m.icons={20,(here.action.sprite or 21),22}add_menu(m)
elseif i==2 then
local m=create_menu('notebook', {}, 32, 35, 65)
m.h=81
m.art=notebook_art
add(menustack,m)
elseif i==3 then
local names={}for loc in all(here.destinations) do
add(names,loc.name)
end
local m=create_menu('walk', names, 19, 70, 90)
m.h=22
add_menu(m)
end
elseif menu.name=='investigate' then
if i==1 then
local speaker,cluetext=get_clue()
set_textpane_text(cluetext,speaker)
wait(1)
if here.islastlocation then
local m=create_menu('duck', {'duck', 'duck', 'goose'}, 64, 99)
m.iswindow=false
m.w=63
menustack={m}end
exit_menu()
elseif i==2 then
set_textpane_text(here.action.result)
wait(2)
exit_menu()
elseif i==3 then
local text=tipster_clues[tipster_clue_index]
if tipster_clue_index<#tipster_clues then
tipster_clue_index+=1
else
tipster_clue_index=1
end
set_textpane_text(text, 'tipster')
wait(3)
exit_menu()
end
elseif menu.name=='walk' then
local dest=here.destinations[i]
local correct=false
if dest==suspect.location then
move_suspect()
correct=true
end
set_location(dest)
if correct then
here.showgoose=true
end
wait(flr(rnd(3))+3)
state='wait-walk'
exit_menu()
menustack[1].sel=1
elseif menu.name=='duck' then
state='distort'
end
end
function wrap(s,wrapw)
if not wrapw then
wrapw=textpanew
end
if #s<=wrapw then
return s,1
end
local new=''
local a=1
local b=wrapw+1
local numlines=1
while b>a do
if sub(s, b, b)==' ' then
new=new..sub(s, a, b-1)..'\n'
a=b+1
b=a+wrapw
numlines+=1
else
b-=1
end
if b>#s then
b=#s
new=new..sub(s,a)
break
end
end
return new,numlines
end
function btn_pushed(b)
if state=='menu' then
local menu=menustack[#menustack]
if not menu.flash then
local prevsel=menu.sel
if b==2 then
if menu.sel>1 then
menu.sel-=1
end
elseif b==3 then
if menu.sel<#menu.items then
menu.sel+=1
end
end
if menu.items[menu.sel]=='goose' then
menu.items[menu.sel],menu.items[prevsel]=menu.items[prevsel],menu.items[menu.sel]
end
if b==4 then
menu.flash=fps/2
elseif b==5 then
exit_menu()
end
end
end
end
function update_menus()
local menu=menustack[#menustack]
if menu.flash ~=nil then
if menu.flash>=0 then
menu.flash-=1
else
menu.flash=nil
execute_menu_item(menu,menu.sel)
end
return
end
end
function exit_menu()
if #menustack>1 then
menustack[#menustack]=nil
end
end
function game2_init()
poke(0x5f2c,0)
state='wipe'
wipey=-16
textpane={x=68,y=5,text=''
}menustack={}local main=create_menu('main',{'investigate','notebook','walk'
},64,99,63)
main.iswindow=false
add(menustack,main)
clock={day=3,hour=9
}hourtimer=create_timer(fps/4)
local l
locations={}add_location({name='duck pond',description='did you know: the main difference between a duck and a goose is the number of bones it contains.',witness='park visitor',tryagain='',action={desc='pat the duck',result='please call him by his full name: patrick'
}})
add_location({name='helsinki, finland',description='helsinki was founded in 1550 by king goosetav i.',witness='santa claus',tryagain='sorry, i did not see a goose',action={desc='make a snowman',result='you construct a snowman. you wonder if the snowman has seen any gooses. (no, it has not.)'
},clue='that goose said something about visiting a country with a history of soviet conflict.'
})
add_location({name='hospital',description='did you know: even when dropped from a great height, a goose will not be hurt. this is because gooses have no bones.',witness='nurse',tryagain='of course not. gooses cannot be a doctor. only a nurse.',action={desc='visit gramma',result='but your gramma is in another hospital!'
},clue='the goose looked like it wanted to perform a surgery.'
})
add_location({name='abandoned library',description='did you know: the first book was printed in 1455 by johannes goosenberg, a german.',witness='ghost librarian',witness_ps='btw i am a librarian for ghosts, not the ghost of a librarian.',tryagain='you\'re looking for geese? try the non-fiction section.',action={desc='browse shelves',result='you pick up a book and wipe away a layer of dust, revealing the title: "game programming for gooses".'
},clue='the goose said it needed to look something up in an outdated almanac.'
})
arts={{1536,428},{1964,1384},{3348,1438},{4786,710},{5496,558},{6054,40}}for i=1,4 do
locations[i].art=arts[i]
end
notebook_art=arts[5]
duck_art=arts[6]
tipster_clue_index=1
tipster_clues={'i heard that cindy has a crush on steve omg i know right','lakisha and becky are totally fighting over michael, but like he doesn\'t even know. don\'t tell him i said that.','raquel needs to lose like 20 lbs but like no one wants to tell her.','i heard nina used to be a fish.','mandy is really mad at fat mandy for taking her name.','over summer break, mindy got totally addicted to pills.','lisa said that steve said that donna said he saw rachel kiss mandy.','omg i heard stephanie kissed a moose.',}init_suspect()
move_suspect()
local start=locations[1]
start.nextlocation=suspect.location
set_location(start)
duckx=0
distort_shapes_cr=cocreate(distort_shapes)
distort_phase=0
end
function add_location(props)
add(locations,props)
end
function rnd_choice(t)
return t[flr(rnd(#t))+1]
end
function move_suspect()
local newlocation
if #suspect.unvisited==0 then
suspect.location.islastlocation=true
else
newlocation=rnd_choice(suspect.unvisited)
del(suspect.unvisited,newlocation)
end
if suspect.location then
suspect.location.nextlocation=newlocation
end
suspect.location=newlocation
end
function init_suspect()
suspect={unvisited=shallow_copy(locations)
}del(suspect.unvisited,locations[1])
end
function wait(hours)
waithours=hours
state='wait-menu'
add_hour()
waithours-=1
hourtimer:reset()
end
function add_hour()
sfx(10)
if clock.hour<23 then
clock.hour+=1
else
clock.hour=0
if clock.day<#day_names then
clock.day+=1
else
clock.day=1
end
end
end
function get_clue()
local clue=''
if here.islastlocation then
for i=1,45 do
clue=clue..'duck '
end
elseif here.nextlocation then
clue=here.nextlocation.clue
if here.witness_ps then
clue=clue..' '..here.witness_ps
end
else
clue=here.tryagain
end
return here.witness,clue
end
function draw_corner(x,y,dir)
local sx=72
local sy=8
if dir==2 then
sx=76
x-=3
elseif dir==3 then
sx=76
sy=12
x-=3
y-=3
elseif dir==4 then
sy=12
y-=3
end
sspr(sx,sy,4,4,x,y)
end
function draw_window(x1,y1,x2,y2)
rectfill(x1+2,y1+2,x2+2,y2+2,1)
rectfill(x1,y1,x2,y2,7)
rectfill(x1+2,y1+2,x2-2,y2-2,0)
end
function draw_border(x1,y1,x2,y2)
color(7)
rect(x1,y1,x2,y2)
rect(x1+1,y1+1,x2-1,y2-1)
draw_corner(x1,y1,1)
draw_corner(x2,y1,2)
draw_corner(x2,y2,3)
draw_corner(x1,y2,4)
end
function draw_borders()
draw_border(0,0,64,26)
draw_border(0,25,64,127)
draw_border(63,0,127,100)
draw_border(63,99,127,127)
end
function draw_shape(shape)
local points=shape.points
color(shape.color)
if #points==1 then
pset(points[1].x,points[1].y)
elseif #points==2 then
line(points[1].x,points[1].y,points[2].x,points[2].y)
elseif #points>=3 then
fill_polygon(shape)
end
end
function ceil(n)
return-flr(-n)
end
function find_bounds(points)
local x1=32767
local x2=0
local y1=32767
local y2=0
for point in all(points) do
x1=min(x1,point.x)
x2=max(x2,point.x)
y1=min(y1,point.y)
y2=max(y2,point.y)
end
return x1,x2,y1,y2
end
function find_intersections(points,y)
local xlist={}local j=#points
for i=1,#points do
local a=points[i]
local b=points[j]
if (a.y<y and b.y>=y) or (b.y<y and a.y>=y) then
local x=a.x+(((y-a.y)/(b.y-a.y))*(b.x-a.x))
add(xlist,x)
end
j=i
end
return xlist
end
function fill_polygon(poly)
color(poly.color)
local x1,x2,y1,y2=find_bounds(poly.points)
for y=y2,y1,-1 do
local xlist=find_intersections(poly.points,y)
sort(xlist)
for i=1,#xlist-1,2 do
local x1=flr(xlist[i])
local x2=ceil(xlist[i+1])
line(x1,y,x2,y)
end
end
end
function sort(t)
for i=2,#t do
local j=i
while j>1 and t[j-1]>t[j] do
t[j-1],t[j]=t[j],t[j-1]
j-=1
end
end
end
function render_shapes(shapes)
for shape in all(shapes) do
draw_shape(shape)
end
end
function create_painting_reader(addr,len)
return {offset=0,addr=addr,len=len,get_next_byte=function(self)
local byte=peek(self.addr+self.offset)
self.offset+=1
return byte
end,is_at_end=function(self)
return (self.offset>=self.len)
end
}end
function parse_painting(addr,len)
local shapes={}local reader=create_painting_reader(addr,len)
repeat
local shape={points={}}local pointcount=reader:get_next_byte()
shape.color=reader:get_next_byte()
for i=1,pointcount do
local x=reader:get_next_byte()
local y=reader:get_next_byte()
y-=1
add(shape.points,{x=x,y=y})
end
add(shapes,shape)
until reader:is_at_end()
return shapes
end
function draw_here()
local screenaddr=0x6000+(64*painting_y)
local cacheaddr=0x4300
local screenwidth=0x40
local rowsize=32
local numrows=painting_h
if distort_phase<2 then
clip(painting_x,painting_y,painting_w,painting_h)
end
if artiscached and distort_phase==0 then
local src=cacheaddr
local dest=screenaddr
for y=1,numrows do
memcpy(dest,src,rowsize)
dest+=screenwidth
src+=rowsize
end
elseif here.shapes then
camera(-painting_x+duckx,-painting_y)
render_shapes(here.shapes)
camera()
local src=screenaddr
local dest=cacheaddr
local rowsize=32
for y=1,numrows do
memcpy(dest,src,rowsize)
src+=screenwidth
dest+=rowsize
end
artiscached=true
end
clip()
end
function set_textpane_text(txt,speaker)
textpane.text=wrap(txt)
if speaker then
textpane.speaker, textpane.speakerh=wrap(speaker..':')
textpane.chars=0
else
textpane.speaker=nil
textpane.chars=nil
end
end
function get_destinations(prevloc)
local dests={}if prevloc then
add(dests,prevloc)
end
if suspect.location ~=prevloc then
add(dests,suspect.location)
end
local decoys=get_decoy_locations(prevloc)
for d in all(decoys) do
add(dests,d)
end
return dests
end
function set_location(loc)
local prevloc
if here then
prevloc=here
end
here=loc
if not here.destinations then
here.destinations=get_destinations(prevloc)
end
if here.art then
here.shapes=parse_painting(here.art[1],here.art[2])
end
artiscached=false
set_textpane_text(here.description)
shuffle(here.destinations)
end
function get_decoy_locations(prevloc)
local decoys={}local dests=shallow_copy(locations)
if prevloc then
del(dests,prevloc)
end
del(dests,suspect.location)
del(dests,here)
for i=1,numdecoys do
local choice=rnd_choice(dests)
del(dests,choice)
add(decoys,choice)
if #dests==0 then
break
end
end
return decoys
end
function shuffle(t)
for i=#t,1,-1 do
local j=flr(rnd(i))+1
t[i],t[j]=t[j],t[i]
end
end
function prepare_goose_departure()
update_goose_departure_cr=cocreate(update_goose_departure)
here.showgoose=false
goose.x=576
goose.y=0
goose.vx=max_velocity_x
goose.dir=1
goose.gravity=0
goose.state='run'
music(1)
end
function update_goose_departure()
repeat
update_goose()
goose.didphysics=false
apply_physics(goose)
update_anim_state(goose)
yield()
until goose.x>660
if not showedgoosetext then
showedgoosetext=true
state='goose-text'
textpane.speaker=nil
textpane.chars=nil
textpane.text='\n\n\n\n\n\n\n\n\nthere goes\ngoose!\n\nyou must be on\nthe right\ntrack.'
sleep(fps*4)
set_textpane_text(here.description)
end
state='menu'
end
function _update()
update_buttons()
if state=='menu' then
update_menus()
update_textpane()
elseif sub(state, 1, 4)=='wait' then
if hourtimer:update() then
hourtimer:reset()
if waithours>0 then
waithours-=1
add_hour()
else
if here.showgoose then
prepare_goose_departure()
state='goose'
else
state='menu'
end
end
end
elseif sub(state, 1, 5)=='goose' then
coresume(update_goose_departure_cr)
elseif state=='distort' then
if costatus(distort_shapes_cr)=='dead' then
game1()
game1_init()
player=boatduck
camy=0
else
coresume(distort_shapes_cr)
end
end
end
function distort_shapes()
music(2)
distort_phase=1
local targets=parse_painting(duck_art[1],duck_art[2])
local shapes=here.shapes
local t=1
for i,s in pairs(shapes) do
local target=targets[t]
local tpi=1
if #s.points<3 then
tpi=3
end
s.tc=target.color
s.sc=s.color
for p in all(s.points) do
p.sx=p.x
p.sy=p.y
local tp=target.points[tpi]
p.dx=tp.x+22
p.dy=tp.y+61
if tpi<#target.points then
tpi+=1
end
end
if (#s.points>=4 or i % flr(#shapes/#targets)==0) and t<#targets then
t+=1
end
end
yield()
local length=flr(fps*8)
if here==locations[2] then
length=flr(fps*6)
end
for f=0,length do
for s in all(shapes) do
for p in all(s.points) do
p.x=ease_in_cubic(f,p.sx,(p.dx-p.sx),length)
p.y=ease_in_cubic(f,p.sy,(p.dy-p.sy),length)
end
end
yield()
end
sleep(fps)
distort_phase=2
sleep(fps/2)
distort_phase=3
length=flr(fps*4)
for f=0,length do
duckx=ease_out_cubic(f,0,(-72),length)
if duckx<-25 then
for s in all(shapes) do
s.color=(flr(duckx) % 2==0 and s.tc or s.sc)
end
end
yield()
end
repeat yield() until stat(16)==33 and stat(20)>=2
end
function sleep(frames)
for i=1,frames do
yield()
end
end
function draw_title_and_time()
color(7)
local title,numlines
numlines=1
if state=='wait-walk' then
title='walking...'
else
title,numlines=wrap(here.name)
end
print(title,5,5)
local dow=day_names[clock.day]
local time=clock.hour..':00'
if numlines>1 then
print(sub(dow, 1, 3)..' '..time, 5, 17)
else
print(dow..'\n'..time, 5, 11)
end
end
function update_textpane()
if textpane.chars and textpane.chars<#textpane.text then
textpane.chars+=1
end
end
function draw_textpane()
local x,y=textpane.x,textpane.y
clip(x,y,56,94)
if textpane.speaker then
print(textpane.speaker,x,y,14)
y+=6*textpane.speakerh
end
local text=textpane.text
if textpane.chars then
text=sub(text,1,textpane.chars)
end
print(text,x,y,7)
clip()
end
function draw_goose_departure()
camera(521,-80)
draw_actor(goose)
camera()
end
function _draw()
cls()
pal()
if state=='goose' then
draw_goose_departure()
end
if state ~='wait-walk' then
draw_here()
end
if distort_phase<2 then
draw_borders()
draw_title_and_time()
end
if state=='menu' or state=='wipe' or state=='goose-text' then
draw_textpane()
end
if state=='menu' then
draw_menus()
end
if state=='wipe' then
if wipey<132 then
wipey+=4
else
state='menu'
end
rectfill(0,wipey,127,128,0)
end
end
end
game1()
game1_init()
sfx(31)