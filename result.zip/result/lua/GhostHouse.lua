-- ghost house
-- by kittenm4ster and aubrianne
-- for #spookyseptemberjam

-- constants
fps = 60
state_menu = 1
state_cutscene = 2
state_transition = 3
state_title = 4

function _init()
	-- globals
	art = nil
	coroutines = {}
	sel = 1
	inventory = {}
	titleflicker = 1
	creditcolor1 = 9
	creditcolor2 = 7
	ghostcount = 0

	state = state_title
	showtitle = true
	load_room(10)
	menuy = roomh - 5
	music(6)

	cr(function()
		room.cam = {x = 0, y = -5}

		wait(fps * 3)

		local len = fps * 4
		for i = 1, len do
			room.cam.y = ease_in_out_quad(i, -5, 24, len)
			yield()
		end
		showtitle = false

		repeat yield() until stat(24) == -1
		state = state_cutscene
		wait(fps)
		show_message('you find yourself outside a house on halloween night...')
		wait(20)
		state = state_menu
	end)
end

function load_room(n)
	room = rooms[n]

	local addr = room_art_addr[n][1]
	local len = room_art_addr[n][2]

	local shapes, patterns
	if len > 0 then
		local reader = new_painting_reader(addr, len)
		shapes, patterns = parse_painting(reader)
	else
		shapes = {}
		patterns = {}
	end

  art = {
    shapes = shapes,
    patterns = patterns,
  }

	prevroomh = roomh or 0
	roomh = 0
	for _, s in pairs(shapes) do
		for _, p in pairs(s.points) do
			roomh = max(roomh, p.y + 1)
		end
	end
	menuy = roomh + 4

	room.coroutines = room.coroutines or {}
	room.sprites = room.sprites or {}

	if not room.didinit and room.init then
		room:init()
		room.didinit = true
	end

	if room.post_load then
		room:post_load()
	end

	sel = 1
end

function cr(func)
	add(coroutines, cocreate(func))
end

function room_cr(func)
	add(room.coroutines, cocreate(func))
end

function _update60()
	update_coroutines(coroutines)
	update_coroutines(room.coroutines)

	if state == state_menu then
		update_menu()
	elseif state == state_title then
		titleflicker -= .007
	end
end

function update_coroutines(coroutines)
  for cr in all(coroutines) do
    if costatus(cr) ~= 'dead' then
      assert(coresume(cr))
    else
      del(coroutines, cr)
    end
  end
end

function _draw()
  cls(1)

	draw_room()

	if room.cam then
		camera(room.cam.x, room.cam.y)
	end

	if room == rooms[10] and state ~= state_title then
		rectfill(0, menuy - 2, 127, 150, 1)
	end

	if state == state_menu then
		draw_menu()
	elseif state == state_cutscene and message then
		color(7)
		print(message, 3, menuy)
		if prompt then
			camera()
			print(prompt, 3, 120)
		end
	elseif state == state_transition then
		draw_wipe()
	end

	if room.cam then
		camera(room.cam.x, room.cam.y)
	end

	if state == state_title then
		draw_titles()
	end

	foreach(room.sprites, draw_sprite_speech)
end

function draw_titles()
	if showtitle then
		local title = 'ghost house'
		for i = 1, #title do
			s = sub(title, i, i)
			if rnd() > titleflicker then
				bigprint(s, 5 + ((i - 1) * 11), 3)
			end
		end
	end

	if stat(20) % 2 == 0 and creditcolorn ~= stat(20) then
		creditcolorn = stat(20)
		creditcolor1, creditcolor2 = creditcolor2, creditcolor1
	end

	if creditcolor1 == 7 then
		y1 = 124
		y2 = 125
	else
		y1 = 125
		y2 = 124
	end

	cprint(' y k t e m s e ', 64, y1, creditcolor1)
	cprint(' a k r u d   y a b i n e', 64, y1 + 7, creditcolor1)

	cprint('b   i t n 4 t r', 64, y2, creditcolor2)
	cprint('b c g o n s b   u r a n ', 64, y2 + 7, creditcolor2)
	cprint('for spooky september jam 2019', 64, 139, 9)
end

function show_message(msg)
	message = wrap(msg, 30)
	wait(fps * 2)
	prompt = 'press 🅾️ to continue'
	repeat yield() until btnp(🅾️)
	message, prompt = nil, nil
end

function draw_room()
  for i = 1, #art.shapes do
		if room.cam then
			camera(room.cam.x, room.cam.y)
		end

		for s in all(room.sprites) do
			if i == s.i then
				pal()
				draw_sprite(s)
			end
		end
		if i == room.specdrawi then
			room:specdraw()
		end

		if room.palette then
			apply_palette(room.palette)
		end

    local shape = art.shapes[i]
    draw_shape(shape, true)
		fillp()
		camera()
  end

	pal()
end

function apply_palette(p)
	for c, v in pairs(p) do
		pal(c, v)
	end
end

function draw_sprite(s)
	if room.spritecamy then
		camera(0, room.spritecamy)
	end

	local sx, sy, sw, sh, dx, dy, dw, dh, flipx = get_sspr_params(s)

	if s.clipbox then
		clip(s.clipbox.x, s.clipbox.y, s.clipbox.w, s.clipbox.h)
	end

	if s.palette then
		apply_palette(s.palette)
	end

	sspr(sx, sy, sw, sh, dx, dy, dw, dh, s.flipx)

	if s.palette then
		pal()
	end
	clip()

	camera()
end

function get_sspr_params(s)
	local sx, sy = spr_xy(s.s)
	local dx, dy = add_offset(s, s.offset)
	local sw = (s.sw or 1) * 8
	local sh = (s.sh or 1) * 8
	local dw = sw * (s.scale or 1)
	local dh = sh * (s.scale or 1)

	return sx, sy, sw, sh, dx, dy, dw, dh, s.flipx
end

function draw_sprite_speech(s)
	local sx, sy, sw, sh, dx, dy, dw, dh, flipx = get_sspr_params(s)

	if s.txt then
		cprint(s.txt, dx + (dw / 2), s.y - 7 - (s.scale or 1), 7, 1, 0)
	end
end

function say(sprite, txt)
	for i = 1, #txt do
		sprite.txt = sub(txt, 1, i)
		wait(3)
	end
	wait(max(30, #txt * 10))
	sprite.txt = nil
end

function draw_menu()
	local y1 = menuy
  local h = 8

	if room.name == 'bedroom' then
		y1 -= 1
		h = 7
	end

	cprint(room.name, 64, y1, 7)

	for i, action in pairs(room.actions) do
		local y = y1 + 8 + (h * (i - 1))
		local arrow = '  '
		if i == sel then
			rectfill(0, y - 1, 127, y + 5, 7)
			color(1)
			arrow = '◆'
		else
			color(7)
		end
		print(arrow .. action.txt, 1, y)
	end
end

function do_action(action)
	add(coroutines, cocreate(function()
		state = state_cutscene
		wait(10)

		local r1, r2 = action:func(room)

		for r in all({r1, r2}) do
			if r == true then
				del(room.actions, action)
			elseif type(r) == 'number' then
				load_room(r)
				transition()
			elseif type(r) == 'string' then
				wait(20)
				show_message(r)
			end
		end

		wait(20)

		state = state_menu
	end))
end

function transition()
	state = state_transition
	wipe()

	if room.post_transition then
		state = state_cutscene
		room:post_transition()
	end
end

function update_menu()
	if btnp(2) then
		sel -= 1
	end
	if btnp(3) then
		sel += 1
	end
	sel = mid(1, sel, #room.actions)

	if btnp(🅾️) then
		do_action(room.actions[sel])
	end
end

function add_offset(pos, offset)
	if not offset then
		return pos.x, pos.y
	end
	return pos.x + offset.x, pos.y + offset.y
end

function wipe()
  memcpy(0x4300, 0x6000, 6912)

	wipeh = max(prevroomh, roomh)
	wipeh = min(wipeh, 6912 / 64)
	local midaddr = (wipeh / 2) * 64

	wipeoffset = 0
	while wipeoffset < midaddr do
		wait(2)
		wipeoffset += (64 * 2)
		wipeoffset = min(wipeoffset, midaddr)
	end
end

function draw_wipe()
	local len = (wipeh * 64) - (wipeoffset * 2)

  memcpy(0x6000 + wipeoffset, 0x4300 + wipeoffset, len)

  color(7)
  local y = wipeoffset / 64
  if wipeoffset < (8192 - 6912) then
    rectfill(0, 108, 127, 127 - y, 1)
  end
end

function ease_linear(t, b, c, d)
	return ((t / d) * c) + b
end

function ease_in_quad(t, b, c, d)
	t = t / d
	return c * (t ^ 2) + b
end

function ease_out_quad(t, b, c, d)
	t = t / d
	return -c * t * (t - 2) + b
end

function ease_in_out_quad(t, b, c, d)
  t = t / d * 2
  if t < 1 then
    return c / 2 * (t ^ 2) + b
  else
    return -c / 2 * ((t - 1) * (t - 3) - 1) + b
  end
end

function bezier(path, v)
	local points = {}
	for i = 1, #path - 1 do
		local a, b = path[i], path[i + 1]
		add(points, {
			x = lerp(a.x, b.x, v),
			y = lerp(a.y, b.y, v)
		})
	end

	if #points == 1 then
		return points[1]
	end

	return bezier(points, v)
end

function lerp(a, b, v)
	return a + ((b - a) * v)
end

function lerp_path(path, v)
	-- determine segment
	local segcount = #path - 1
	local i = min(flr(segcount * v) + 1, segcount)

	-- return progress on segment
	local v2 = (v * segcount) - (i - 1)
	local a, b = path[i], path[i + 1]
	return {
		x = lerp(a.x, b.x, v2),
		y = lerp(a.y, b.y, v2)
	}
end

function lerp_path_1d(path, v)
	-- determine segment
	local segcount = #path - 1
	local i = min(flr(segcount * v) + 1, segcount)

	-- return progress on segment
	local v2 = (v * segcount) - (i - 1)
	local a, b = path[i], path[i + 1]
	return lerp(a, b, v2)
end

function play_anim(anim)
	for v = 1, anim.len do
		anim:update(v)
		yield()
	end
end

function update_path_anim(path, v, len, ease, posinterp)
	local w = ease(v, 0, 1, len)
	return posinterp(path, w)
end

function update_1d_path(path, v, len, ease)
	local w = ease(v, 0, 1, len)
	return lerp_path_1d(path, w)
end

-- item sprites
fruit = {i = 80, s = 78, sw = 2, sh = 2, x = 36, y = 64}
handle = {s = 74, x = 0, y = 0}
cookie1 = {i = 110, s = 90, x = 100, y = 72}
cookie2 = {i = 110, s = 90, x = 109, y = 68}
cookie3 = {i = 110, s = 90, x = 112, y = 73}

-- ghost sprites
hallghost = {i = 59, s = 70, x = 0, y = 0, offset = {x = -4, y = -4}}
pianoghost = {
	i = 51, s = 71, x = 0, y = 0, clipbox = {x = 0, y = 0, w = 87, h = 100}
}
diningghost = {i = 56, s = 73, x = 0, y = 0, scale = 2}
showerghost = {i = 44, s = 75, x = 69, y = 8}
bedghost = {i = 5, s = 77, x = 0, y = 0, offset = {x = -4, y = -4}}

hallghost_anim_1 = {
	sprite = hallghost,
	len = 66,
	path = {
		{x = 36, y = 48},
		{x = 41, y = 48},
	},
	update = function(self, v)
		local pos = update_path_anim(self.path, v, self.len, ease_out_quad, bezier)
		self.sprite.x = pos.x
		self.sprite.y = pos.y
	end
}

hallghost_anim_2 = {
	sprite = hallghost,
	len = 200,
	path = {
		{x = 41, y = 48},
		{x = 47, y = 69},
		{x = 110, y = 74},
		{x = 20, y = 21},
		{x = 83, y = 31},
		{x = 79, y = 49},
		{x = 115, y = -1}
	},
	scalepath = {1, 1, 1, .7, .7, .8},
	update = function(self, v)
		local pos = update_path_anim(self.path, v, self.len, ease_linear, bezier)
		self.sprite.x = pos.x
		self.sprite.y = pos.y

		self.sprite.scale = update_1d_path(self.scalepath, v, self.len, ease_linear)
	end
}

pianoghost_anim_1 = {
	sprite = pianoghost,
	len = 220,
	path = {
		{x = 45, y = 43},
		{x = 45, y = 41},
		{x = 45, y = 37},
		{x = 45, y = 31},
		{x = 45, y = 28},
		{x = 45, y = 31},
		{x = 45, y = 28},
		{x = 45, y = 31},
	},
	update = function(self, v)
		local pos = update_path_anim(self.path, v, self.len, ease_linear, lerp_path)
		self.sprite.x = pos.x
		self.sprite.y = pos.y
	end
}

pianoghost_anim_2 = {
	sprite = pianoghost,
	len = 100,
	path = {
		{x = 45, y = 31},
		{x = 40, y = 29},
		{x = 39, y = 28},
		{x = 91, y = 26},
	},
	update = function(self, v)
		local pos = update_path_anim(self.path, v, self.len, ease_linear, bezier)
		self.sprite.x = pos.x
		self.sprite.y = pos.y

		if v > 30 then
			pianoghost.s = 72
		end
	end
}

diningghost_anim_1 = {
	sprite = diningghost,
	len = 182,
	path = {
		{x = 97, y = 34},
		{x = 97, y = 31},
		{x = 97, y = 34},
	},
	update = function(self, v)
		local pos = update_path_anim(self.path, v, self.len, ease_linear, lerp_path)
		self.sprite.x = pos.x
		self.sprite.y = pos.y
	end
}
diningghost_anim_2 = {
	sprite = diningghost,
	len = 126,
	path = {
		{x = 97, y = 34},
		{x = 95, y = 31},
		{x = 30, y = 28},
		{x = -30, y = 70},
	},
	update = function(self, v)
		local pos = update_path_anim(self.path, v, self.len, ease_linear, bezier)
		self.sprite.x = pos.x
		self.sprite.y = pos.y
	end
}

showerghost_anim_1 = {
	sprite = showerghost,
	len = 192,
	path = {
		{x = 70, y = 10},
		{x = 68, y = 11},
		{x = 68, y = 14},
		{x = 68, y = 16},
		{x = 68, y = 16},
		{x = 68, y = 16},
		{x = 68, y = 16},
		{x = 68, y = 16},
		{x = 68, y = 16},
		{x = 68, y = 16},
		{x = 68, y = 20},
		{x = 68, y = 19},
		{x = 68, y = 37},
		{x = 67, y = 40},
	},
	scalepath = {.2, 1, 2, 2, 2, 2},
	update = function(self, v)
		self.sprite.scale = update_1d_path(self.scalepath, v, self.len, ease_linear)

		local pos = update_path_anim(self.path, v, self.len, ease_linear, bezier)
		self.sprite.x = pos.x - (self.sprite.scale * 4)
		self.sprite.y = pos.y - (self.sprite.scale * 4)

		if v == self.len then
			self.sprite.s = 76
		end
	end
}
showerghost_anim_2 = {
	sprite = fruit,
	len = 104,
	path = {
		{x = 72, y = 71},
		{x = 72, y = 71},
		{x = 67, y = 47},
		{x = 67, y = 42},
	},
	scalepath = {1.0, 1.0, 0.9, 0.7},
	update = function(self, v)
		self.sprite.scale = update_1d_path(self.scalepath, v, self.len, ease_linear)

		local pos = update_path_anim(self.path, v, self.len, ease_out_quad, bezier)
		self.sprite.x = pos.x - (self.sprite.scale * 8)
		self.sprite.y = pos.y - (self.sprite.scale * 8)

		if v >= 62 then
			self.sprite.i = 43
		else
			self.sprite.i = 45
		end

		if v >= 80 then
			sset(90, 34, 9)
			sset(93, 34, 9)
			sset(98, 34, 9)
			sset(101, 34, 9)
		end
	end
}
showerghost_anim_3 = {
	sprite = showerghost,
	len = 99,
	path = {
		{x = 67, y = 40},
		{x = 136, y = 22},
		{x = -60, y = 38},
	},
	scalepath = {2, 2, 2, 1.9, 3},
	update = function(self, v)
		self.sprite.scale = update_1d_path(self.scalepath, v, self.len, ease_linear)

		local pos = update_path_anim(self.path, v, self.len, ease_in_quad, bezier)
		self.sprite.x = pos.x - (self.sprite.scale * 4)
		self.sprite.y = pos.y - (self.sprite.scale * 4)

		if v >= 51 then
			self.sprite.i = 42
			fruit.i = 41
		end

		if not fruit.ghostoffset then
			fruit.ghostoffset = {
				x = fruit.x - showerghost.x,
				y = fruit.y - showerghost.y,
				scaleq = showerghost.scale / fruit.scale
			}
		end
		fruit.x, fruit.y = add_offset(self.sprite, fruit.ghostoffset)
		fruit.scale = self.sprite.scale / fruit.ghostoffset.scaleq
	end
}

bed_anim = {
	len = 152,
	path = {
		{x = 0, y = 0},
		{x = 0, y = 1},
		{x = 0, y = -2},
		{x = 0, y = -1},
		{x = 0, y = 1},
		{x = 0, y = -2},
		{x = 0, y = -1},
		{x = 0, y = 1},
		{x = 0, y = -2},
		{x = 0, y = -1},
		{x = 0, y = 1},
		{x = 0, y = -2},
		{x = 0, y = -1},
		{x = 0, y = 0},
		{x = 0, y = 1},
		{x = 0, y = 0},
	},
	update = function(self, v)
		local pos = update_path_anim(self.path, v, self.len, ease_linear, lerp_path)
		local shapes = {
			art.shapes[6],
			art.shapes[35],
			art.shapes[37],
			art.shapes[39],
			art.shapes[40]
		}
		for _, shape in pairs(shapes) do
			shape.offset = {x = 0, y = pos.y}
		end
	end
}

bedghost_anim_1 = {
	sprite = bedghost,
	len = 58,
	path = {
		{x = 44, y = 79},
		{x = 47, y = 88},
		{x = 59, y = 91},
		{x = 60, y = 91},
	},
	update = function(self, v)
		local pos = update_path_anim(self.path, v, self.len, ease_out_quad, bezier)
		self.sprite.x = pos.x
		self.sprite.y = pos.y

		if v >= 36 then
			self.sprite.flipx = true
		end
	end
}

bedghost_anim_2 = {
	sprite = bedghost,
	len = 134,
	path = {
		{x = 59, y = 91},
		{x = 88, y = 121},
		{x = 61, y = 12},
		{x = 132, y = 50},
	},
	update = function(self, v)
		local pos = update_path_anim(self.path, v, self.len, ease_in_quad, bezier)
		self.sprite.x = pos.x
		self.sprite.y = pos.y

		self.sprite.flipx = false
		self.sprite.i = 86
	end
}

font = 'abcdefghijklmnopqrstuvwxyz'

function font_i(chr)
	for i = 1, #font do
		if sub(font, i, i) == chr then
			return i
		end
	end
	return -1
end

function font_xy(chr)
	local i = font_i(chr) - 1
	if i == -2 then
		return nil
	end

	local x = (i % 11) * 11
	local y = flr(i / 11) * 14
	local w = letter_w(x, y)

	return x, y, w
end

function letter_w(x, y)
	for u = x + 9, x, -1 do
		for v = y, y + 12 do
			if sget(u, v) > 0 then
				return u - x + 1
			end
		end
	end
end

function bigprint(s, x, y)
	y += sin(t() * .5) * 2.5

	for i = 1, #s do
		local y2 = y + (cos(t()*.87 + x/12)) * 2
		local sx, sy, w = font_xy(sub(s, i, i))
		if sx then
			sspr(sx, sy, 10, 13, x, y2, 10, 13)
		end
		x = x + (w or 10) + 1
	end
end

function assign(t1, t2)
	for k, v in pairs(t2) do
		t1[k] = v
	end
end

function cprint(s, x, y, c, bg, minx)
	local x = x - flr(txtw(s) / 2)
	if minx then
		x = max(minx, x)
	end

	if bg then
		for yo = -1, 1 do
			for xo = -1, 1 do
				if not (yo == 0 and xo == 0) then
					print(s, x + xo, y + yo, bg)
				end
			end
		end
	end

	print(s, x, y, c)
end

function deep_copy(t)
	local t2 = {}
	for k, v in pairs(t) do
		if type(v) == 'table' then
			t2[k] = deep_copy(v)
		else
			t2[k] = v
		end
	end
	return t2
end

function distance(a, b)
	return sqrt(((a.x - b.x) ^ 2) + (a.y - b.y) ^ 2)
end

function insert(t, v, i)
	for j = #t, i, -1 do
		t[j + 1] = t[j]
	end
	t[i] = v
end

function rnd_int(a, b)
	return flr(rnd((b + 1) - a)) + a
end

function shallow_copy(t)
	local t2 = {}
	for k, v in pairs(t) do
		t2[k] = v
	end
	return t2
end

function spr_xy(s)
  local x = (s % 16) * 8
  local y = flr(s / 16) * 8
  return x, y
end

function txtw(txt)
	txt = tostr(txt)
	local w = 0
	for i = 1, #txt do
		if sub(txt, i, i) == '🅾️' then
			w += 8
		else
			w += 4
		end
	end
	return max(0, w - 1)
end

function wait(frames)
	for i = 1, frames do
		yield()
	end
end

function wrap(s, w)
	if #s <= w then
		return s, 1
	end

	local new = ''
	local a, b = 1, w + 1

	while b > a do
		local c = sub(s, b, b)
		if c == ' ' or c == '\n' then
			new = new .. sub(s, a, b - 1) .. '\n'
			a = b + 1
			b = a + w
		else
			b -= 1
		end
		if b > #s then
			b = #s
			new = new .. sub(s, a)
			break
		end
	end
	return new
end

rooms = {}

room_art_addr = {
	[1] = {0x0f67, 697},
	[2] = {0x1220, 775},
	[3] = {0x1527, 653},
	[4] = {0x17b4, 693},
	[5] = {0x1a69, 567},
	[6] = {0x1ca0, 1009},
	[7] = {0x2091, 739},
	[8] = {0x2374, 0},
	[9] = {0x2374, 1097},
	[10] = {0x27bd, 2115},
}

rooms[1] = {
	name = 'hall',
	post_transition = function(self)
		if not self.didintromusic then
			self.didintromusic = true
			music(0)
			repeat yield() until stat(24) == -1 or (stat(24) == 1 and stat(20) >= 2)
			show_message(
				'what a very old house! i wonder if anyone still lives here...')
		end
	end,
	actions = {
		{
			txt = 'say "hello?"',
			func = function(self, room)
				ghostcount += 1
				music(2)
				add(room.sprites, hallghost)
				play_anim(hallghost_anim_1)

				for v = 1, hallghost_anim_2.len do
					hallghost_anim_2:update(v)
					yield()
				end
				del(room.sprites, hallghost)

				return "oh my! it seems there are ghosts in this house!", true
			end
		},
		{
			txt = 'go through the left door',
			func = function(self)
				self.txt = 'go left to the piano room'
				return 2
			end
		},
		{
			txt = 'go through the right door',
			func = function(self)
				self.txt = 'go right to the dining room'
				return 3
			end
		},
		{
			txt = 'go up the stairs',
			func = function()
				return 5
			end
		}
	}
}

rooms[2] = {
	name = 'piano room',
	actions = {
		{
			txt = 'check behind the curtain',
			func = function()
				return 'there is a spider behind the curtain. you pay no attention to it.'
			end
		},
		{
			txt = 'play the piano',
			func = function(self, room)
				if pianoghost.found then
					return 'great playing! i can tell you have been practicing.'
				end

				music(4)

				ghostcount += 1
				add(room.sprites, pianoghost)
				play_anim(pianoghost_anim_1)
				play_anim(pianoghost_anim_2)
				pianoghost.found = true
				del(room.sprites, pianoghost)

				return 'a ghost came out! it must have enjoyed the music.'
			end
		},
		{
			txt = 'leave the piano room',
			func = function() return 1 end
		}
	}
}

rooms[3] = {
	name = 'dining room',
	init = function(self)
		add(self.sprites, fruit)
	end,
	actions = {
		{
			txt = 'pick up the bowl of fruit',
			func = function(self, room)
				inventory.fruit = true
				fruit.palette = nil
				del(room.sprites, fruit)
				return "you put the bowl of fruit in your pocket.", true
			end,
		},
		{
			txt = 'blow out the candle',
			func = function(self, room)
				ghostcount += 1

				fruit.palette = {
					[2] = 1
				}
				room.palette = {
					[7] = 2,
					[9] = 1,
				}
				del(art.shapes, art.shapes[79])

				add(room.sprites, diningghost)
				sfx(21)
				play_anim(diningghost_anim_1)
				play_anim(diningghost_anim_2)
				del(room.sprites, diningghost)

				return true, 'the ghost ran away! perhaps it was afraid of the dark!'
			end
		},
		{
			txt = 'go to the kitchen',
			func = function() return 4 end
		},
		{
			txt = 'exit to the hall',
			func = function() return 1 end
		},
	}
}

rooms[4] = {
	name = 'kitchen',
	post_load = function(self)
		if inventory.handle and not self.addedhandleaction then
			self.addedhandleaction = true
			insert(self.actions, {
				txt = 'put the handle on the door',
				func = function(self, room)
					sfx(34)
					add(room.sprites, handle)
					handle.i = 29
					handle.x, handle.y = 105, 54
					room.hasdoorhandle = true
					inventory.handle = nil
					return 'the handle fits perfectly!', true
				end
			}, 1)
		end
	end,
	actions = {
		{
			txt = 'open the door on the right',
			func = function(self, room)
				if room.hasdoorhandle then
					if ghostcount == 5 then
						return 'the door opens. behind it are some stairs which lead ' ..
									 'you down into a basement...', 9
					else
						return "hmmm the door still won't open. maybe you need to " ..
						       "explore the house a bit more..."
					end
				else
					return 'there is no handle on that door! what a silly door. it ' ..
					'must be broken.'
				end
			end
		},
		{
			txt = 'go back to the dining room',
			func = function() return 3 end
		}
	}
}

rooms[5] = {
	name = 'landing',
	init = function()
		add(room.sprites, handle)
		handle.i = 50
		handle.x, handle.y = 119, 34
	end,
	actions = {
		{
			txt = 'enter the left door',
			func = function(self)
				self.txt = 'enter the bedroom'
				return 6
			end
		},
		{
			txt = 'enter the middle door',
			func = function(self)
				self.txt = 'enter the bathroom'
				return 7
			end
		},
		{
			txt = 'enter the right door',
			func = function(self, room)
				if room.gothandle then
					return "since the handle broke off, there's no way to open it."
				else
					sfx(34)
					inventory.handle = true
					room.gothandle = true
					del(room.sprites, handle)
					return 'the door handle breaks off! you put it in your pocket in ' ..
					       'case you need it later.'
				end
			end
		},
		{
			txt = 'go down the stairs',
			func = function()
				return 1
			end
		}
	}
}

rooms[6] = {
	name = 'bedroom',
	actions = {
		{
			txt = 'check under the pillows',
			func = function()
				return "there is a tooth under one of the pillows! " ..
				       "you'd better leave it there."
			end
		},
		{
			txt = 'say "are any ghosts here?"',
			func = function(self, room)
				room.speech = 'nope!'

				room.specdrawi = 5
				room.speechx = 31
				room.specdraw = function(self)
					print(self.speech, self.speechx, room.speechy, 7)
				end

				local len = 37
				for i = 1, len do
					room.speechx = ease_out_quad(i, 27, 24, len)
					room.speechy = ease_out_quad(i, 81, 8, len)
					yield()
				end
				wait(fps * 1.33)
				room.specdraw = nil
				room.specdrawi = nil

				insert(room.actions, {
					txt = 'jump on the bed',
					func = function(self, room)
						if not room.ghostleft then
							music(8)
						end

						play_anim(bed_anim)

						if not room.ghostleft then
							ghostcount += 1
							add(room.sprites, bedghost)
							play_anim(bedghost_anim_1)
							play_anim(bedghost_anim_2)
							del(room.sprites, bedghost)
							room.ghostleft = true

							return 'oops! there was a ghost after all, and it did not ' ..
							       'seem to enjoy all the noise.'
						end
					end
				}, 2)

				return 'it sounds like this room does not contain any ghosts.', true
			end
		},
		{
			txt = 'leave the bedroom',
			func = function() return 5 end
		}
	}
}

rooms[7] = {
	name = 'bathroom',
	post_load = function(self)
		if inventory.fruit and not self.addedfruitaction then
			self.addedfruitaction = true
			insert(self.actions, {
				txt = 'put bowl of fruit on toilet',
				func = function(self, room)
					ghostcount += 1
					inventory.fruit = nil
					fruit.i = 36
					fruit.x = 64
					fruit.y = 63
					fruit.scale = 1
					add(room.sprites, fruit)
					wait(40)

					music(10)
					add(room.sprites, showerghost)
					play_anim(showerghost_anim_1)

					room_cr(function()
						local started = false
						while true do
							local v = sin(t() * .8) * 1.2
							if abs(v) < .1 then
								started = true
							end

							if started then
								room.spritecamy = sin(t() * .8) * 1.2
							end
							yield()
						end
					end)

					play_anim(showerghost_anim_2)
					showerghost.s = 75
					wait(14)
					showerghost.s = 76
					wait(14)
					showerghost.s = 75
					wait(20)
					play_anim(showerghost_anim_3)

					return
						'ghost fact: some ghosts like to eat oranges in the shower.',
						true
				end
			}, 2)
		end
	end,
	actions = {
		{
			txt = 'look in the mirror',
			func = function()
				return "lookin' good!"
			end
		},
		{
			txt = 'leave the bathroom',
			func = function() return 5 end
		}
	}
}

rooms[9] = {
	name = 'secret basement',
	init = function(self)
		add(self.sprites, hallghost)
		add(self.sprites, pianoghost)
		add(self.sprites, diningghost)
		add(self.sprites, bedghost)
		add(self.sprites, showerghost)
		add(self.sprites, cookie1)
		add(self.sprites, cookie2)
		add(self.sprites, cookie3)

		assign(hallghost, {i = 30, s = 86, x = 10, y = 54, scale = 2})
		room_cr(function()
			while true do
				hallghost.x = 10 + sin(t() * .2) * 1.5
				hallghost.y = 53 + cos(t() * .3) * 1.6
				yield()
			end
		end)

		assign(pianoghost, {i = 90, s = 87, x = 49, y = 39, scale = 1})
		room_cr(function()
			while true do
				pianoghost.y = 39 + sin(t() * .2) * 1.8
				yield()
			end
		end)

		assign(diningghost, {i = 70, s = 89, x = 96, y = 35, scale = 1})
		room_cr(function()
			while true do
				diningghost.x = 96 + sin(t() * .15) * 1.5
				diningghost.y = 35 + cos(t() * .1) * .9
				yield()
			end
		end)

		assign(showerghost, {i = 110, s = 91, x = 72, y = 68, scale = 2})
		room_cr(function()
			while true do
				showerghost.y = 68 + cos(t() * .2) * 1.6
				yield()
			end
		end)

		assign(bedghost, {i = 110, s = 93, x = 107, y = 49, scale = 1, flipx = true})
		room_cr(function()
			while true do
				bedghost.y = 49 + sin(t() * .25) * .9
				yield()
			end
		end)
	end,
	post_transition = function()
		music(13)
		wait(20)
		say(hallghost, "hey!")
		say(hallghost, "it's you!")
		say(pianoghost, "you're here!")
		say(showerghost, 'we made you cookies!')
		say(diningghost, 'surprise!')
		say(bedghost, '♥ ')
	end,
	actions = {
		{
			txt = 'do a dance',
			func = function()
				show_message('you do a very good dance.')
				say(showerghost, 'sweet moves')
			end
		},
		{
			txt = 'eat a cookie',
			func = function(self, room)
				show_message("you try to share with the ghosts, but they can't eat " ..
				             "any, because they are ghosts. therefore, you eat all " ..
										 "of the cookies.")
				del(room.sprites, cookie1)
				wait(20)
				del(room.sprites, cookie2)
				wait(20)
				del(room.sprites, cookie3)
				wait(90)

				say(pianoghost, "well, that's the end of the game")
				say(diningghost, "happy halloween! ")
				say(hallghost, "feel free to hang out")
				say(hallghost, "as long as you want")

				return true
			end
		},
	}
}

-- title screen
rooms[10] = {
	name = 'spooky house',
	actions = {
		{
			txt = 'go inside the spooky house',
			func = function()
				return 1
			end
		},
		{
			txt = 'run away',
			func = function()
				return 'a mysterious force prevents you from leaving!'
			end
		}
	}
}

-- vector-paint dist library

function draw_shape(shape, enablecache)
	local points = shape.points
	color(shape.col)
	fillp(art.patterns[shape.pi])

	if shape.offset then
		camera(-shape.offset.x, -shape.offset.y)
	end

	if #points == 1 then
		pset(points[1].x, points[1].y)
	elseif #points == 2 then
		line(points[1].x, points[1].y, points[2].x, points[2].y)
	elseif #points >= 3 then
		fill_polygon(shape, enablecache)
	end
end

function find_bounds(points)
	local x1 = 32767
	local x2 = 0
	local y1 = 32767
	local y2 = 0
	for _, point in pairs(points) do
		x1 = min(x1, point.x)
		x2 = max(x2, point.x)
		y1 = min(y1, point.y)
		y2 = max(y2, point.y)
	end

	return x1, x2, y1, y2
end

function find_intersections(points, y)
	local xlist = {}
	local j = #points

	for i = 1, #points do
		local a = points[i]
		local b = points[j]

		if (a.y < y and b.y >= y) or (b.y < y and a.y >= y) then
			local x = a.x + (((y - a.y) / (b.y - a.y)) * (b.x - a.x))

			add(xlist, x)
		end

		j = i
	end

	return xlist
end

function fill_polygon(p, enablecache)
	if not p.linecache then
		p.linecache = {}

		local x1, x2, y1, y2 = find_bounds(p.points)
		for y = y2, y1, -1 do
			local xlist = find_intersections(p.points, y)
			sort(xlist)

			for i = 1, #xlist - 1, 2 do
				local x1 = flr(xlist[i])
				local x2 = ceil(xlist[i + 1])
				add(p.linecache, {x1 = x1, x2 = x2, y = y})
			end
		end
	end

	-- draw the cached scanlines
	for _, l in pairs(p.linecache) do
		rectfill(l.x1, l.y, l.x2, l.y, p.col)
	end

	if not enablecache then
		p.linecache = nil
	end
end

function sort(t)
	for i = 2, #t do
		local j = i
		while j > 1 and t[j - 1] > t[j] do
			t[j - 1], t[j] = t[j], t[j - 1]
			j -= 1
		end
	end
end

function new_painting_reader(addr, len)
	return {
		offset = 0,
		addr = addr,
		len = len,

		get_next_byte = function(self)
			local byte = peek(self.addr + self.offset)
			self.offset += 1
			return byte
		end,

		eof = function(self)
			return self.offset >= self.len
		end,

		end_of_shapes = function(self, patterncount)
			if patterncount > 0 then
				return self.offset == self.len - (patterncount * 2) - 1
			else
				return self:eof()
			end
		end
	}
end

function parse_painting(reader)
	local shapes = {}
	local patterns = {}
	local maxpat = 0

	-- read each shape
	repeat
		local shape = {
			points = {}
		}

		-- read the fill-pattern index and point count
		local b1 = reader:get_next_byte()
		shape.pi = shr(band(b1, 0b11000000), 6)
		local pointcount = band(b1, 0b00111111)

		-- update running pattern count
		maxpat = max(maxpat, shape.pi)

		-- read the color
		shape.col = reader:get_next_byte()

		-- read each point
		for i = 1, pointcount do
			local x = reader:get_next_byte()
			local y = reader:get_next_byte() - 1
			add(shape.points, {x = x, y = y})
		end

		add(shapes, shape)
	until reader:end_of_shapes(maxpat)

	if maxpat > 0 then
		for i = 1, maxpat do
			local b1 = reader:get_next_byte()
			local b2 = reader:get_next_byte()
			local pattern = bor(shl(b1, 8), b2)
			add(patterns, pattern)
		end
		local tb = reader:get_next_byte()
		for i = 1, maxpat do
			local mask = shr(0b10000000, i - 1)
			if band(tb, mask) > 0 then
				patterns[i] += 0x0.8
			end
		end
	end

	return shapes, patterns
end

