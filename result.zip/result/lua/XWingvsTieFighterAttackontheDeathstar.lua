-- xwing vs. tie figther
-- by freds72
local time_t,good_side,bad_side=0,0x1,0x2
local _tok={
['true']=true,
['false']=false}
function nop() return true end
local _g={
good_side=good_side,
bad_side=bad_side,
nop=nop}
local table_delims={['{']="}",['[']="]"}
local function match(s,tokens)
for i=1,#tokens do
if(s==sub(tokens,i,i)) return true
end
return false
end
local function skip_delim(str, pos, delim, err_if_missing)
if sub(str,pos,pos)!=delim then
return pos,false
end
return pos+1,true
end
local function parse_str_val(str, pos, val)
val=val or ''
local c=sub(str,pos,pos)
if(c=='"') return _g[val] or val,pos+1
return parse_str_val(str,pos+1,val..c)
end
local function parse_num_val(str,pos,val)
val=val or ''
local c=sub(str,pos,pos)
if(not match(c,"-xb0123456789abcdef.")) return tonum(val),pos
return parse_num_val(str,pos+1,val..c)
end
function json_parse(str, pos, end_delim)
pos=pos or 1
local first=sub(str,pos,pos)
if match(first,"{[") then
local obj,key,delim_found={},true,true
pos+=1
while true do
key,pos=json_parse(str, pos, table_delims[first])
if(key==nil) return obj,pos
if first=="{" then
pos=skip_delim(str,pos,':',true)
obj[key],pos=json_parse(str,pos)
else
add(obj,key)
end
pos,delim_found=skip_delim(str, pos, ',')
end
elseif first=='"' then
return parse_str_val(str,pos+1)
elseif match(first,"-0123456789") then
return parse_num_val(str, pos)
elseif first==end_delim then
return nil,pos+1
else
for lit_str,lit_val in pairs(_tok) do
local lit_end=pos+#lit_str-1
if sub(str,pos,lit_end)==lit_str then return lit_val,lit_end+1 end
end
end
end
local cockpit_view,cam=false
local plyr_playing,mission_score,invert_y,plyr=false,0,1
local actors,ground_actors,parts,all_parts={},{},{}
local ground_shift,ground_colors,ground_level=2,json_parse'[1,13,6]'
local start_screen,game_screen,gameover_screen,cur_screen={},{},{}
local shkx,shky=0,0
function screen_shake(pow)
shkx,shky=min(4,shkx+rnd(pow)),min(4,shky+rnd(pow))
end
function screen_update()
shkx*=-0.7-rnd(0.2)
shky*=-0.7-rnd(0.2)
if abs(shkx)<0.5 and abs(shky)<0.5 then
shkx,shky=0,0
end
camera(shkx,shky)
end
local all_vol=json_parse'[0x700.0700,0x600.0600,0x500.0500,0x400.0400,0x300.0300,0x200.0200,0x100.0100,0x100.0100]'
function sfx_v(s,pos)
local d=sqr_dist(cam.pos,pos)
local vol=lerparray(all_vol,sqrt(d)/64)
local src,dst=0x3200+68*s,0x3200+68*63
for k=1,16 do
local pair=bor(band(peek4(src),0xf1ff.f1ff),vol)
poke4(dst,pair)
src+=4
dst+=4
end
poke4(dst,peek4(src))
sfx(63)
end
local drawables={}
function zbuf_clear()
drawables={}
end
function zbuf_draw()
local objs={}
for _,d in pairs(drawables) do
local p=d.pos
local x,y,z,w=cam:project(p[1],p[2],p[3])
if z>0 then
add(objs,{obj=d,key=z,x=x,y=y,z=z,w=w})
end
end
sort(objs)
for i=1,#objs do
local d=objs[i]
d.obj:draw(d.x,d.y,d.z,d.w)
end
end
function zbuf_filter(array)
for _,a in pairs(array) do
if not a:update() then
del(array,a)
else
add(drawables,a)
end
end
end
function clone(src,dst)
dst=dst or {}
for k,v in pairs(src) do
if(not dst[k]) dst[k]=v
end
if src.rnd then
for k,v in pairs(src.rnd) do
if not dst[k] then
dst[k]=v[3] and rndarray(v) or rndlerp(v[1],v[2])
end
end
end
return dst
end
function lerp(a,b,t)
return a*(1-t)+b*t
end
function rndlerp(a,b)
return lerp(b,a,1-rnd())
end
function smoothstep(t)
t=mid(t,0,1)
return t*t*(3-2*t)
end
function rndrng(ab)
return flr(rndlerp(ab[1],ab[2]))
end
function rndarray(a)
return a[flr(rnd(#a))+1]
end
function lerparray(a,t)
return a[mid(flr((#a-1)*t+0.5),1,#a)]
end
function sort(data)
for num_sorted=1,#data-1 do
local new_val=data[num_sorted+1]
local new_val_key,i=new_val.key,num_sorted+1
while i>1 and new_val_key>data[i-1].key do
data[i]=data[i-1]
i-=1
end
data[i]=new_val
end
end
function sqr_dist(a,b)
local dx,dy,dz=b[1]-a[1],b[2]-a[2],b[3]-a[3]
if abs(dx)>128 or abs(dy)>128 or abs(dz)>128 then
return 32000
end
local d=dx*dx+dy*dy+dz*dz
return d<0 and 32000 or d
end
function make_rnd_v(scale)
local v={rnd()-0.5,rnd()-0.5,rnd()-0.5}
v_normz(v)
v_scale(v,scale)
return v
end
function make_rnd_pos_v(a,rng)
local p=make_rnd_v(8)
p[3]+=rng
local d,v=0
while d==0 do
v=make_v(p,make_rnd_v(4))
d=v_normz(v)
end
m_x_v(a.m,p)
return p,v
end
function make_v_cross(a,b)
local ax,ay,az=a[1],a[2],a[3]
local bx,by,bz=b[1],b[2],b[3]
return {ay*bz-az*by,az*bx-ax*bz,ax*by-ay*bx}
end
local v_fwd,v_right,v_up={0,0,1},{1,0,0},{0,1,0}
function make_v(a,b)
return {
b[1]-a[1],
b[2]-a[2],
b[3]-a[3]}
end
function v_clone(v)
return {v[1],v[2],v[3]}
end
function v_lerp(a,b,t)
return {
lerp(a[1],b[1],t),
lerp(a[2],b[2],t),
lerp(a[3],b[3],t)}
end
function v_dot(a,b)
return a[1]*b[1]+a[2]*b[2]+a[3]*b[3]
end
function v_normz(v)
local d=v_dot(v,v)
if d>0.001 then
d=sqrt(d)
v[1]/=d
v[2]/=d
v[3]/=d
end
return d
end
function v_clamp(v,l)
local d=v_dot(v,v)
if d>l*l then
v_scale(v,l/sqrt(d))
end
end
function v_scale(v,scale)
v[1]*=scale
v[2]*=scale
v[3]*=scale
end
function v_add(v,dv,scale)
scale=scale or 1
v[1]+=scale*dv[1]
v[2]+=scale*dv[2]
v[3]+=scale*dv[3]
end
function in_cone(p,t,fwd,angle,rng)
local v=make_v(p,t)
if sqr_dist(v,v)<rng*rng then
v_normz(v)
return v_dot(fwd,v)>angle
end
return false
end
function m_x_v(m,v)
local x,y,z=v[1],v[2],v[3]
v[1],v[2],v[3]=m[1]*x+m[5]*y+m[9]*z+m[13],m[2]*x+m[6]*y+m[10]*z+m[14],m[3]*x+m[7]*y+m[11]*z+m[15]
end
function o_x_v(m,v)
local x,y,z=v[1],v[2],v[3]
v[1],v[2],v[3]=m[1]*x+m[5]*y+m[9]*z,m[2]*x+m[6]*y+m[10]*z,m[3]*x+m[7]*y+m[11]*z
end
function m_x_xyz(m,x,y,z)
return {
m[1]*x+m[5]*y+m[9]*z+m[13],
m[2]*x+m[6]*y+m[10]*z+m[14],
m[3]*x+m[7]*y+m[11]*z+m[15]}
end
function make_m(x,y,z)
local m={}
for i=1,16 do
m[i]=0
end
m[1],m[6],m[11],m[16]=1,1,1,1
m[13],m[14],m[15]=x or 0,y or 0,z or 0
return m
end
function make_m_toward(z,up)
local x=make_v_cross(up,z)
if v_dot(x,x)<0.001 then
if abs(up[3])==1 then
z[1]+=0.01
else
z[3]+=0.01
end
v_normz(z)
x=make_v_cross(up,z)
end
v_normz(x)
local y=make_v_cross(z,x)
v_normz(y)
return {
x[1],x[2],x[3],0,
y[1],y[2],y[3],0,
z[1],z[2],z[3],0,
0,0,0,1}
end
function make_q(v,angle)
angle/=2
local s=-sin(angle)
return {v[1]*s,
v[2]*s,
v[3]*s,
cos(angle)}
end
function q_clone(q)
return {q[1],q[2],q[3],q[4]}
end
function q_normz(q)
local d=v_dot(q,q)+q[4]*q[4]
if d>0 then
d=sqrt(d)
q[1]/=d
q[2]/=d
q[3]/=d
q[4]/=d
end
end
function q_x_q(a,b)
local qax,qay,qaz,qaw=a[1],a[2],a[3],a[4]
local qbx,qby,qbz,qbw=b[1],b[2],b[3],b[4]
a[1]=qax*qbw+qaw*qbx+qay*qbz-qaz*qby
a[2]=qay*qbw+qaw*qby+qaz*qbx-qax*qbz
a[3]=qaz*qbw+qaw*qbz+qax*qby-qay*qbx
a[4]=qaw*qbw-qax*qbx-qay*qby-qaz*qbz
end
function m_from_q(q)
local x,y,z,w=q[1],q[2],q[3],q[4]
local x2,y2,z2=x+x,y+y,z+z
local xx,xy,xz=x*x2,x*y2,x*z2
local yy,yz,zz=y*y2,y*z2,z*z2
local wx,wy,wz=w*x2,w*y2,w*z2
return {
1-(yy+zz),xy+wz,xz-wy,0,
xy-wz,1-(xx+zz),yz+wx,0,
xz+wy,yz-wx,1-(xx+yy),0,
0,0,0,1
}
end
function m_inv(m)
m[2],m[5]=m[5],m[2]
m[3],m[9]=m[9],m[3]
m[7],m[10]=m[10],m[7]
end
function m_inv_x_v(m,v)
local x,y,z=v[1]-m[13],v[2]-m[14],v[3]-m[15]
v[1],v[2],v[3]=m[1]*x+m[2]*y+m[3]*z,m[5]*x+m[6]*y+m[7]*z,m[9]*x+m[10]*y+m[11]*z
end
function m_set_pos(m,v)
m[13],m[14],m[15]=v[1],v[2],v[3]
end
function m_fwd(m)
return {m[9],m[10],m[11]}
end
function m_up(m)
return {m[5],m[6],m[7]}
end
local all_models=json_parse'{"logo":{"c":10},"deathstar":{"c":3},"turret":{"c":8,"r":1.1,"wp":{"sfx":1,"part":"ground_laser","dmg":1,"dly":48,"pos":[[-0.4,1.6,1.4],[0.4,1.6,1.4]],"n":[[0,0,1],[0,0,1]]}},"xwing":{"c":7,"r":0.8,"engine_part":"purple_trail","engines":[[-0.57,0.44,-1.61],[-0.57,-0.44,-1.61],[0.57,0.44,-1.61],[0.57,-0.44,-1.61]],"proton_wp":{"dmg":4,"part":"proton","sfx":6,"dly":60,"pos":[0,-0.4,1.5],"n":[0,0,1]},"wp":{"sfx":2,"angle":0.9,"dmg":1,"dly":8,"pos":[[2.1,0.6,1.6],[2.1,-0.6,1.6],[-2.1,-0.6,1.6],[-2.1,0.6,1.6]],"n":[[-0.0452,-0.0129,0.9989],[-0.0452,0.0129,0.9989],[0.0452,0.0129,0.9989],[0.0452,-0.0129,0.9989]]}},"tie":{"c":5,"r":1.2,"engine_part":"blue_trail","engines":[[0,0,-0.5]],"wp":{"sfx":8,"angle":0.92,"dmg":2,"dly":16,"pos":[[0.7,-0.7,0.7],[-0.7,-0.7,0.7]],"n":[[0,0,1],[0,0,1]]}},"tiex1":{"c":13,"r":1.2,"wp":{"sfx":6,"angle":0.9,"dmg":2,"dly":24,"pos":[[0.7,-0.7,0.7],[-0.7,-0.7,0.7]],"n":[[0,0,1],[0,0,1]]}},"junk2":{"c":3,"r":1.2},"generator":{"c":6,"r":2},"mfalcon":{"c":5,"engine_part":"mfalcon_trail","engines":[[0,0,-5.86]],"wp":{"sfx":1,"angle":0,"dmg":1,"dly":45,"pos":[[0.45,1.1,0],[-0.45,1.1,0],[0.45,-1.3,0],[-0.45,1.3,0]],"n":[[0,0,1],[0,0,1],[0,0,1],[0,0,1]]}},"vent":{"c":5,"r":1},"ywing":{"c":7,"r":1,"wp":{"sfx":1,"angle":0.92,"dmg":4,"dly":45,"pos":[[0.13,0,3.1],[-0.13,0,3.1]],"n":[[0,0,1],[0,0,1]]}}}'
local dither_pat=json_parse'[0b1111111111111111,0b0111111111111111,0b0111111111011111,0b0101111111011111,0b0101111101011111,0b0101101101011111,0b0101101101011110,0b0101101001011110,0b0101101001011010,0b0001101001011010,0b0001101001001010,0b0000101001001010,0b0000101000001010,0b0000001000001010,0b0000001000001000,0b0000000000000000]'
function draw_actor(self,x,y,z,w)
if w>1 then
draw_model(self.model,self.m,x,y,z,w)
else
circfill(x,y,1,self.model.c)
end
end
local draw_session_id=0
function draw_model(model,m,x,y,z,w)
draw_session_id+=1
local draw_session_id=draw_session_id
color(model.c)
if w then
fillp(lerparray(dither_pat,w/2)+0.1)
end
local cam_pos=v_clone(cam.pos)
m_inv_x_v(m,cam_pos)
local edges=model.e
for _,f in pairs(model.f) do
if v_dot(f.n,cam_pos)>=f.cp then
for _,ei in pairs(f.ei) do
edges[ei][3]=draw_session_id
end
end
end
local p,verts={},model.v
for _,e in pairs(edges) do
if e[3]==true or e[3]==draw_session_id then
local ak,bk=e[1],e[2]
local a,b=p[ak],p[bk]
if not a then
local v=verts[ak]
local x,y,z,w=v[1],v[2],v[3]
x,y,z,w=cam:project(m[1]*x+m[5]*y+m[9]*z+m[13],m[2]*x+m[6]*y+m[10]*z+m[14],m[3]*x+m[7]*y+m[11]*z+m[15])
a={x,y,z,w}
p[ak]=a
end
if not b then
local v=verts[bk]
local x,y,z,w=v[1],v[2],v[3]
x,y,z,w=cam:project(m[1]*x+m[5]*y+m[9]*z+m[13],m[2]*x+m[6]*y+m[10]*z+m[14],m[3]*x+m[7]*y+m[11]*z+m[15])
b={x,y,z,w}
p[bk]=b
end
if(a[3]>0 and b[3]>0) line(a[1],a[2],b[1],b[2])
end
end
fillp()
end
_g.die_plyr=function(self)
self.disabled=true
plyr_playing,cockpit_view=false,false
cam.flip=false
futures_add(function()
local death_q=make_q(v_fwd,rnd(0.04)-0.08)
wait_async(90,function(i)
q_x_q(plyr.q,death_q)
return true
end)
make_part("blast",self.pos)
screen_shake(4)
del(actors,self)
plyr=nil
end)
end
_g.die_actor=function(self)
make_part("blast",self.pos)
self.disabled=true
del(actors,self)
if(self.on_die) self:on_die(true)
end
_g.update_waypoint=function(self)
if(not plyr) return false
if sqr_dist(self.pos,plyr.pos)<32 then
sfx(0)
del(actors,self)
if (self.on_die) self:on_die(true)
return false
end
return true
end
function follow(pos,other,offset)
local v=v_clone(offset)
m_x_v(other.m,v)
v_add(v,pos,-1)
return v
end
function avoid(self,pos,dist)
local v,n,d2={0,0,0},0,dist*dist
for _,a in pairs(actors) do
if a!=self then
local d=sqr_dist(pos,a.pos)
if d<d2 then
local force=1-smoothstep(d/d2)
v_add(v,pos,force)
v_add(v,a.pos,-force)
n+=1
end
end
end
if(n>0) v_scale(v,1/n)
return v
end
function seek(self,fwd,dist)
for _,a in pairs(actors) do
if not a.disabled and band(a.side,self.side)==0 and in_cone(self.pos,a.pos,fwd,0.5,dist) then
if a.target!=self then
return a
end
end
end
end
function wander(self)
local p=make_rnd_v(1)
p[3]+=15
return p
end
function update_engines(self)
if self.model.engines and time_t%2==0 then
for _,v in pairs(self.model.engines) do
v=v_clone(v)
m_x_v(self.m,v)
local p=make_part(self.model.engine_part,v)
p.m=self.m
end
end
end
_g.update_flying_npc=function(self)
if plyr and sqr_dist(self.pos,plyr.pos)>9216 then
self:on_die()
return false
end
local pos,m={0,0,1},self.m
m_x_v(m,pos)
local can_fire,prev_fwd=false,m_fwd(m)
local force=v_clone(prev_fwd)
v_scale(force,5)
local stamina=1-smoothstep(self.fatigue*self.overg_t)
if self.target and not self.target.disabled then
can_fire,target_pos=true,{0,0,-rnd(15)}
v_add(force,follow(pos,self.target,target_pos),stamina)
else
self.target=seek(self,prev_fwd,24)
end
self.wander_t-=1
if not self.wander or self.wander_t<0 then
self.wander=wander(self)
self.wander_t=120+rnd(60)
end
v_add(force,follow(pos,self,self.wander))
v_add(force,avoid(self,pos,8),4)
v_clamp(force,self.turn_rate)
v_add(pos,force)
v_add(pos,self.pos,-1)
v_normz(pos)
local up=m_up(m)
if self.target then
v_add(up,m_up(self.target.m),stamina*0.2)
v_normz(up)
end
m=make_m_toward(pos,up)
local fwd=m_fwd(m)
v_add(self.pos,fwd,self.acc)
m_set_pos(m,self.pos)
self.m=m
update_engines(self)
local g=1-abs(v_dot(prev_fwd,fwd))
self.overg_t=90*g
self.overg_t*=0.9
local wp=self.model.wp
self.fire_t-=1
if wp and can_fire and self.fire_t<0 and in_cone(self.pos,self.target.pos,fwd,wp.angle,64) then
self:fire(self.target)
end
return true
end
_g.hit_plyr=function(self,dmg)
if(self.disabled or self.safe_t>0) return
self.energy,self.safe_t=0,8
self.hp-=dmg
if self.hp<=0 then
self:die()
end
screen_shake(2)
end
_g.draw_plyr=function(self,x,y,z,w)
if(cockpit_view) return
draw_model(self.model,self.m,x,y,z,w)
end
_g.update_plyr=function(self)
self.safe_t-=1
self.fire_t-=1
self.proton_t-=1
self.energy=min(self.energy+0.005,1)
if self.energy==1 and self.hp!=5 then
self.hp,self.energy=min(self.hp+1,5),0
elseif self.energy==1 and self.proton_ammo!=4 then
self.proton_ammo,self.energy=min(self.proton_ammo+1,4),0
end
self.roll*=0.8
self.turn*=0.9
self.turn_spring*=0.85
self.pitch*=0.85
self.boost*=self.dboost
update_engines(self)
return true
end
_g.hit_npc=function(self,dmg)
if(self.disabled) return
self.hp-=dmg
if self.hp<=0 then
self:die()
end
end
_g.hit_flying_npc=function(self,dmg,actor)
_g.hit_npc(self,dmg)
if actor==plyr then
self.target=plyr
end
end
_g.update_turret=function(self,i,j)
_g.update_ground_actor(self,i,j)
if(not plyr) return true
local dx,dy=self.pos[1]-plyr.pos[1],self.pos[3]-plyr.pos[3]
local angle=atan2(dx,dy)-0.25
local m,c,s=self.m,cos(angle),sin(angle)
m[1],m[3],m[9],m[11]=c,s,-s,c
if time_t-self.local_t>45 then
self.pause_t=30+rnd(30)
end
self.pause_t-=1
if plyr.pos[2]>self.pos[2]+5 and self.pause_t<0 then
self:fire(plyr)
end
self.local_t=time_t
return true
end
_g.update_ground_actor=function(self,i,j)
self.pos[1],self.pos[2],self.pos[3]=shl(i,ground_shift),abs(shl(i,ground_shift))<8 and ground_level-6 or ground_level,shl(j,ground_shift)
m_set_pos(self.m,self.pos)
end
function make_blt(self,wp,pos,u)
local pt=add(parts,clone(all_parts[wp.part or "laser"],{
actor=self,
pos=pos,
u=u,
side=self.side,
dmg=wp.dmg,
die_part=wp.die_part}))
pt.t=pt.dly
sfx_v(wp.sfx,pos)
return pt
end
_g.make_laser=function(self,target)
if(self.fire_t>0) return false
local wp=self.model.wp
local i=self.laser_i%#wp.pos+1
local p=v_clone(wp.pos[i])
m_x_v(self.m,p)
local v=target and v_clone(target.pos) or v_clone(wp.n[i])
if target and self.fire_luck>rnd() then
local target_acc=target.acc
if target_acc then
target_acc+=(target.boost or 0)
local blt=all_parts[wp.part or "laser"]
local lead_t=0
for i=1,2 do
lead_t=sqrt(sqr_dist(v,p))/blt.acc-lead_t
if(lead_t<0) break
v_add(v,m_fwd(target.m),lead_t*target_acc)
end
end
v_add(v,p,-1)
v_normz(v)
else
o_x_v(self.m,v)
end
self.laser_i+=1
local pt=make_blt(self,wp,p,v)
local c=self.side==good_side and 8 or 11
pt.c,self.fire_t=c,wp.dly
make_part("flash",p,c)
end
_g.make_proton=function(self,target)
local wp=self.model.proton_wp
local p=v_clone(wp.pos)
m_x_v(self.m,p)
local v=v_clone(wp.n)
o_x_v(self.m,v)
make_blt(self,wp,p,v).target=target
end
local all_actors=json_parse'{"plyr":{"hp":5,"turn_spring":0,"safe_t":0,"energy":1,"energy_t":0,"boost":0,"dboost":1,"acc":0.2,"model":"xwing","turn":0,"roll":0,"pitch":0,"laser_i":0,"fire_luck":1,"fire_t":0,"fire":"make_laser","lock_t":0,"proton_t":0,"proton_ammo":4,"fire_proton":"make_proton","side":"good_side","draw":"draw_plyr","update":"update_plyr","hit":"hit_plyr","die":"die_plyr"},"patrol":{"hp":10,"turn_rate":0.045,"acc":0.2,"overg_t":0,"fatigue":1,"rnd":{"model":["xwing","xwing","ywing"],"fire_luck":[0.7,0.9]},"side":"good_side","wander_t":0,"lock_t":0,"laser_i":0,"fire_t":0,"fire":"make_laser","update":"update_flying_npc","hit":"hit_npc","die":"die_actor","on_die":"nop"},"tie":{"acc":0.6,"turn_rate":0.04,"fatigue":48,"on_die":"nop","hp":4,"overg_t":0,"model":"tie","side":"bad_side","wander_t":0,"lock_t":0,"laser_i":0,"fire_t":0,"fire":"make_laser","update":"update_flying_npc","hit":"hit_flying_npc","die":"die_actor","fire_luck":0.7},"generator":{"waypt":true,"hp":10,"model":"generator","side":"bad_side","update":"nop","hit":"hit_npc","die":"die_actor"},"vent":{"waypt":true,"hp":12,"model":"vent","side":"bad_side","update":"nop","hit":"hit_npc","die":"die_actor"},"mfalcon":{"on_die":"nop","turn_rate":0.03,"fatigue":8,"hp":8,"acc":0.25,"overg_t":0,"model":"mfalcon","side":"good_side","wander_t":0,"lock_t":0,"laser_i":0,"fire_luck":0.8,"fire_t":0,"fire":"make_laser","update":"update_flying_npc","hit":"hit_npc","die":"die_actor"},"turret":{"hp":2,"model":"turret","side":"bad_side","local_t":0,"pause_t":0,"fire_luck":0.8,"fire_t":0,"laser_i":0,"fire":"make_laser","update":"update_turret","hit":"hit_npc","die":"die_actor"},"ground_junk":{"hp":2,"model":"junk2","side":"bad_side","update":"update_ground_actor","hit":"hit_npc","die":"die_actor"},"waypoint":{"draw":"nop","update":"update_waypoint","waypt":true},"vador":{"turn_rate":0.055,"fatigue":8,"hp":40,"acc":0.6,"overg_t":0,"model":"tiex1","side":"bad_side","wander_t":0,"lock_t":0,"laser_i":0,"fire_luck":0.8,"fire_t":0,"fire":"make_laser","update":"update_flying_npc","hit":"hit_flying_npc","die":"die_actor"}}'
function make_actor(src,p,q)
local a=clone(all_actors[src],{
pos=v_clone(p),
q=q or make_q(v_up,0)
})
a.model,a.draw=all_models[a.model],a.draw or draw_actor
local m=m_from_q(a.q)
m_set_pos(m,p)
a.m=m
return add(actors,a)
end
local rear_q=make_q(v_up,0.5)
function make_cam(focal)
local c={
pos={0,0,3},
q=make_q(v_up,0),
flip=false,
update=function(self)
self.m=m_from_q(self.q)
m_inv(self.m)
end,
track=function(self,pos,q)
self.pos,q=v_clone(pos),q_clone(q)
if self.flip then
q_x_q(q,rear_q)
end
self.q=q
end,
project=function(self,x,y,z)
x-=self.pos[1]
y-=self.pos[2]
z-=self.pos[3]
local v=m_x_xyz(self.m,x,y,z)
v[3]-=1
if(v[3]<0.001) return nil,nil,-1,nil
local w=focal/v[3]
return 64+v[1]*w,64-v[2]*w,v[3],w
end
}
return c
end
function v_project(v)
return cam:project(v[1],v[2],v[3])
end
_g.update_part=function(self)
self.t-=1
if(self.t<0 or self.r<=0) return false
self.r+=self.dr
return true
end
_g.update_blast=function(self)
if self.frame==8 then
self.kind,self.dr=5,0
for i=1,self.sparks do
local v=make_rnd_v(self.r)
v_add(v,self.pos)
make_part("spark",v)
end
end
self.frame+=1
return _g.update_part(self)
end
_g.die_blt=function(self)
make_part(self.die_part or "flash",self.pos,self.c)
return false
end
function blt_obj_col(self,objs)
for _,a in pairs(objs) do
local r=a.model and a.model.r
if r and band(a.side,self.side)==0 then
r*=r
local hit=false
if sqr_dist(self.pos,a.pos)<r or sqr_dist(self.prev_pos,a.pos)<r then
hit=true
else
local ps=make_v(self.pos,a.pos)
local t=v_dot(self.u,ps)
if t>=0 and t<=self.acc then
local p=v_clone(self.u)
v_scale(p,t)
hit=sqr_dist(p,a.pos)<r
end
end
if hit then
make_part("impact",self.pos)
a:hit(self.dmg,self.actor)
return true
end
end
end
return false
end
_g.update_blt=function(self)
self.t-=1
if(self.t<0) return false
if ground_level and self.pos[2]<ground_level then
if abs(self.pos[1])>6 or self.pos[2]<ground_level-6 then
return self:die()
end
end
self.prev_pos=v_clone(self.pos)
v_add(self.pos,self.u,self.acc)
if blt_obj_col(self,actors) or blt_obj_col(self,ground_actors) then
return self:die()
end
return true
end
_g.update_proton=function(self)
if time_t%2==0 then
make_part("trail",self.pos,10)
end
local target=self.target
if target and not target.disabled then
local r=make_v(self.pos,target.pos)
local d=v_dot(r,r)
if d<1 then
target:hit(self.dmg,self.actor)
return self:die()
end
local v=m_fwd(target.m)
v_scale(v,target.acc or 0)
v_add(v,self.u,-self.acc)
local omega=make_v_cross(r,v)
v_scale(omega,1/d)
local a=make_v_cross(v,omega)
v_scale(a,self.n)
v_add(a,self.u,self.acc)
v_normz(a)
self.u=a
end
self.frame+=1
return _g.update_blt(self)
end
_g.draw_part=function(self,x,y,z,w)
if self.kind==0 then
local x1,y1,z1,w1=v_project(self.prev_pos)
if z>0 and z1>0 then
line(x,y,x1,y1,time_t%2==0 and self.c or 10)
end
elseif self.kind==1 then
circfill(x,y,self.r*w,self.c)
elseif self.kind==3 then
fillp(lerparray(dither_pat,1-w/16))
circfill(x,y,(0.5+rnd(1))*w,8)
fillp()
circfill(x,y,(0.1+0.2*rnd())*w,10)
elseif self.kind==5 then
circ(x,y,w*self.r,7)
elseif self.kind==6 then
pset(x,y,rnd(16))
elseif self.kind==7 then
circ(x,y,self.r*w,self.c[flr(3-3*mid(self.r/0.4,0,1))+1])
elseif self.kind==8 then
if w>1 then
color(self.c)
for _,v in pairs(self.e) do
v=v_clone(v)
m_x_v(self.m,v)
local x1,y1,z1,w1=v_project(v)
if z>0 and z1>0 then
line(x,y,x1,y1)
end
end
end
end
end
all_parts=json_parse'{"laser":{"rnd":{"dly":[80,110]},"acc":3,"kind":0,"update":"update_blt","die":"die_blt","draw":"draw_part"},"ground_laser":{"rnd":{"dly":[95,120]},"acc":0.8,"kind":0,"update":"update_blt","die":"die_blt","draw":"draw_part"},"flash":{"kind":1,"rnd":{"r":[0.5,0.7],"dly":[4,6]},"dr":-0.05},"impact":{"kind":1,"c":10,"dr":-0.05,"rnd":{"r":[0.7,1],"dly":[4,6]}},"trail":{"kind":1,"rnd":{"r":[0.2,0.3],"dly":[12,24]},"dr":-0.02},"blast":{"frame":0,"sfx":3,"kind":1,"c":7,"rnd":{"r":[2.5,3],"dly":[12,18],"sparks":[6,12]},"dr":-0.04,"update":"update_blast"},"novae":{"frame":0,"sfx":9,"kind":1,"c":7,"r":30,"rnd":{"dly":[8,12],"sparks":[30,40]},"dr":-0.04,"update":"update_blast"},"proton":{"die_part":"blast","rnd":{"dly":[180,210],"n":[2,5]},"frame":0,"acc":0.8,"kind":3,"update":"update_proton","die":"die_blt","draw":"draw_part"},"spark":{"kind":6,"dr":0,"r":1,"rnd":{"dly":[48,78]}},"purple_trail":{"kind":7,"c":[14,2,5,1],"rnd":{"r":[0.35,0.4],"dly":[2,4],"dr":[-0.08,-0.05]}},"blue_trail":{"kind":7,"c":[7,12,5,1],"rnd":{"r":[0.3,0.5],"dly":[12,24],"dr":[-0.08,-0.05]}},"mfalcon_trail":{"kind":8,"e":[[-3.24,0,-5.04],[3.24,0,-5.04]],"r":1,"dr":0,"rnd":{"c":[12,7,13],"dly":[1,2]}}}'
function make_part(part,p,c)
local pt=add(parts,clone(all_parts[part],{pos=v_clone(p),draw=_g.draw_part,c=c}))
pt.t,pt.update=pt.dly,pt.update or _g.update_part
if(pt.sfx) sfx_v(pt.sfx,p)
return pt
end
local trench_section=json_parse'[[-6,0],[-6,-6],[6,-6],[6,0]]'
function draw_ground(self)
local cy=cam.pos[2]
if not ground_level then
draw_deathstar(-6)
draw_stars()
return
end
cy-=ground_level
if cy>128 then
cy-=64
draw_deathstar(-min(6,cy/32))
draw_stars()
return
end
local scale=4*max(flr(cy/32+0.5),1)
scale*=scale
local x0,z0=cam.pos[1],cam.pos[3]
local dx,dy=x0%scale,z0%scale
local strips={}
for _,xy in pairs(trench_section) do
local tx0,ty0,strip
for j=-4,4 do
strips[j]=strips[j] or {}
local jj=scale*j-dy+z0
local x,y,z,w=cam:project(xy[1],ground_level+xy[2],jj)
if z>0 then
local fp=lerparray(dither_pat,w/2)+0.1
local c=lerparray(ground_colors,2*w)
if tx0 then
fillp(fp)
line(tx0,ty0,x,y,c)
end
add(strips[j],{x,y,fp,c})
tx0,ty0=x,y
end
end
end
for _,strip in pairs(strips) do
local p0=strip[1]
for i=2,#strip do
local p1=strip[i]
fillp(p0[3])
color(p0[4])
line(p0[1],p0[2],p1[1],p1[2])
p0=p1
end
end
fillp()
if(cy<0) return
for i=-4,4 do
local ii=scale*i-dx+x0
if abs(flr(ii-x0+cam.pos[1]))>8 then
for j=-4,4 do
local jj=scale*j-dy+z0
local x,y,z,w=cam:project(ii,ground_level,jj)
if z>0 then
pset(x,y,lerparray(ground_colors,2*w))
end
end
end
end
end
local trench_scale,turrets,trench_actors=6
function make_ground_actor(i,j,src,y)
local x,y,z=shl(i,ground_shift),y or 0,shl(j,ground_shift)
local a=clone(all_actors[src],{
pos={x,y,z},
m=make_m(x,y,z),
draw=draw_actor
})
a.model=all_models[a.model]
turrets[i+shl(j,7)]=a
return a
end
function update_ground()
ground_actors={}
if(not ground_level) return
local pos=plyr and plyr.pos or cam.pos
if(pos[2]>ground_level+96) return
local i0,j0=flr(shr(pos[1],ground_shift)),flr(shr(pos[3],ground_shift))
for i=i0-16,i0+16 do
local cx=band(i,0x7f)
for j=j0-16,j0+16 do
local cy=band(j,0x7f)
local t=turrets[cx+shl(cy,7)]
if t and not t.disabled then
t:update(i,j)
add(drawables,t)
add(ground_actors,t)
end
end
end
end
function plyr_ground_col(pos)
if ground_level and pos[2]<ground_level then
local r,col=rnd()*0.4,false
if abs(pos[1])<=6 then
if pos[1]>=5.9 then
pos[1],col=5.5-r,true
elseif pos[1]<=-5.9 then
pos[1],col=-5.5+r,true
end
if pos[2]<ground_level-6 then
pos[2],col=ground_level-5.5+r,true
end
if(not col) return false
else
pos[2]=ground_level-r
end
sfx(3)
plyr:hit(1)
return true
end
return false
end
local view_changing,cockpit_offset,outside_offset=false,{0,0,0},{0,2,-8}
function set_view(target_view)
if(view_changing or cockpit_view==target_view) return
view_changing=true
futures_add(function()
local c=cockpit_view
cockpit_view=false
wait_async(30,function(i)
view_offset=v_lerp(
c and cockpit_offset or outside_offset,
target_view and cockpit_offset or outside_offset,
smoothstep(i/30))
return true
end)
cockpit_view,view_changing=target_view,false
end)
end
function find_closest_tgt(fwd,objs,min_dist,target)
min_dist=min_dist or 32000
for _,a in pairs(objs) do
if a.hp and band(a.side,plyr.side)==0 then
local d=sqr_dist(a.pos,plyr.pos)
if d>4 and d<min_dist and in_cone(plyr.pos,a.pos,fwd,0.98,96) then
min_dist,target=d,a
end
local r=plyr.model.r+a.model.r
if(d<r*r) sfx(3) plyr:hit(1)
end
end
return min_dist,target
end
function control_plyr(self)
local pitch,roll,input=0,0,false
if plyr_playing then
if(btn(0)) roll=1 input=true
if(btn(1)) roll=-1 input=true
if(btn(2)) pitch=-1
if(btn(3)) pitch=1
pitch*=invert_y
if btnp(2,1) then
set_view(not cockpit_view)
end
cam.flip=btn(3,1)
end
if btn(4) then
self.roll+=roll
else
self.turn+=roll
self.turn_spring=mid(self.turn_spring+roll,-20,20)
end
q_x_q(self.q,make_q(v_fwd,self.roll/512))
q=make_q(v_up,-self.turn/2048)
q_x_q(self.q,q)
self.pitch=mid(self.pitch-pitch/396,-0.005,0.005)
q_x_q(self.q,make_q(v_right,self.pitch))
q_normz(self.q)
local q=q_clone(self.q)
q_x_q(q,make_q(v_fwd,self.turn_spring/128))
local m=m_from_q(q)
local fwd=m_fwd(m)
v_add(self.pos,fwd,self.acc+self.boost)
plyr_ground_col(self.pos)
m_set_pos(m,self.pos)
self.m,self.cam_q=m,q
if plyr_playing then
local prev_target=plyr.target
local min_dist,target=find_closest_tgt(fwd,actors)
min_dist,target=find_closest_tgt(fwd,ground_actors,min_dist,target)
plyr.target=target
if target then
plyr.lock_t+=1
else
plyr.lock_t=0
end
if self.lock_t==30 then
sfx(7)
end
if not input and plyr.proton_ammo>0 and plyr.proton_t<0 and plyr.lock_t>30 and btnp(4) then
plyr:fire_proton(target)
plyr.energy,plyr.proton_t=0,plyr.model.proton_wp.dly
plyr.proton_ammo-=1
end
if self.fire_t<0 and btn(5) and plyr.energy>0.05 then
plyr:fire(target)
plyr.energy=max(plyr.energy-0.05)
end
end
end
local ds_m,ds_scale,ds_enabled=make_m(),0,false
function draw_deathstar(offset)
if ds_enabled then
m_set_pos(ds_m,{cam.pos[1],ds_scale+offset+cam.pos[2],cam.pos[3]})
draw_model(all_models["deathstar"],ds_m)
end
end
local stars,stars_ramp={},json_parse'[1,2,13,12]'
function draw_stars()
local hyper_space=plyr and plyr.boost>0
for _,v in pairs(stars) do
local x,y,z,w=v_project(v)
if z>0 and z<32 then
color(stars_ramp[min(flr(4*w/12)+1,#stars_ramp)])
if hyper_space and v.x and abs(x-v.x)<24 and abs(y-v.y)<24 then
line(v.x,v.y,x,y)
else
pset(x,y)
end
v.x,v.y=x,y
else
local star=make_rnd_v(32)
v[1],v[2],v[3],v.x,v.y=star[1],star[2],star[3]
v_add(v,cam.pos)
end
end
end
local radar_colors,shield_spr=json_parse'[5,11,3]',json_parse'[72,14,45,43,74]'
function draw_radar_dots(objs)
for _,a in pairs(objs) do
if a!=plyr then
local v=v_clone(a.pos)
m_inv_x_v(plyr.m,v)
local x,y,c=64+0.2*v[1],116-0.2*v[3],mid(flr(v[2]/8),-1,1)+2
pset(x,y,radar_colors[c])
end
end
end
local dx,dy=0,0
function draw_instr()
clip(54,105,22,22)
draw_radar_dots(ground_actors)
draw_radar_dots(actors)
clip()
for _,a in pairs(actors) do
if a.waypt then
local x,y,z,w=v_project(a.pos)
if z>0 and w<3 then
x,y=mid(x,4,124),mid(y-2*w,4,124)
spr(41,x-4,y-4)
end
end
end
if plyr.target then
local p=plyr.target.pos
local x,y,z,w=v_project(p)
dx,dy=x-64,64-y
if(plyr.lock_t>30) pal(1,8)
end
spr(110,64+dx-8,64-dy-5,2,2)
pal()
dx*=0.9
dy*=0.9
for i=0,plyr.proton_ammo-1 do
local x,y=77+(i%2)*6,102+6*flr(i/2)
spr(42,x,y)
end
spr(shield_spr[max(plyr.hp,1)],39,104,2,2)
if plyr.hp!=5 and time_t%4<2 then
spr(shield_spr[max(plyr.hp+1,1)],39,104,2,2)
end
end
function set_layer(top)
if top then
poke4(0x5f00,0x0e00.0180)
poke4(0x5f04,0x0e00.0180)
poke4(0x5f08,0x0e00.0180)
poke4(0x5f0c,0x0e00.0180)
else
poke4(0x5f00,0x8080.8080)
poke4(0x5f04,0x0101.0101)
poke4(0x5f08,0x0000.0000)
poke4(0x5f0c,0x0e0e.0e0e)
end
end
local start_screen_starting=false
function start_screen:update()
if not start_screen_starting and (btnp(4) or btnp(5)) then
start_screen_starting=true
sfx(0)
music(-1,500)
futures_add(function()
wait_async(30)
cur_screen=game_screen
time_t,cockpit_view,view_offset,actors,parts,ground_level=0,false,outside_offset,{},{},nil
plyr,plyr_playing=make_actor("plyr",{0,300,0},make_q(v_right,0.25)),false
plyr.boost,plyr.dboost=1,1.01
sfx(10)
wait_async(180,function(i)
ds_enabled,ds_scale=i>80,lerp(-150,0,smoothstep((i-90)/90))
return true
end)
plyr.boost,plyr.dboost=0,0.9
set_view(true)
plyr_playing=true
futures_add(next_mission_async)
start_screen_starting=false
end)
end
end
local title_m=make_m(0,0,0)
function start_screen:draw()
cam.pos[3]+=0.1
cam:update()
draw_stars()
m_set_pos(title_m,{-0.94,0.4,2.1+cam.pos[3]})
draw_model(all_models["logo"],title_m)
?"freds72 presents",32,4,1
?"attack on the death star",20,78,12
if (start_screen_starting and time_t%2==0) or time_t%24<12 then
?"❎|🅾️ to start",38,118,11
end
end
function wait_gameover_async()
wait_async(60)
cur_screen=gameover_screen
wait_async(600,function()
if btnp(4) or btnp(5) then
yield()
return false
end
return true
end)
camera()
music(0)
cam,cur_screen=make_cam(64),start_screen
end
function gameover_screen:update()
q_x_q(cam.q,make_q(v_up,0.001))
game_screen:update()
end
function gameover_screen:draw()
game_screen:draw()
?"game over",46,60,12
?"achieved: "..mission_score.."/4",39,70,10
for i=1,4 do
spr(i<=mission_score and 57 or 108,29+11*i,80,2,1)
end
end
function game_screen:update()
zbuf_clear()
update_msg()
if plyr then
control_plyr(plyr)
if not plyr.disabled then
cam:track(m_x_xyz(plyr.m,view_offset[1],view_offset[2],cam.flip and -view_offset[3] or view_offset[3]),plyr.cam_q)
end
end
update_ground()
zbuf_filter(actors)
zbuf_filter(parts)
cam:update()
end
function game_screen:draw()
draw_ground()
zbuf_draw()
draw_msg()
if plyr then
if cockpit_view then
if not cam.flip then
set_layer(false)
spr(0,0,64,8,8)
spr(0,64,64,8,8,true)
set_layer(true)
spr(64,0,32,8,4)
spr(64,64,32,8,4,true)
pal()
draw_instr()
local x,imax=23,flr(8*plyr.energy)+1
for i=1,8 do
rectfill(x,120,x+1,123,i<imax and 11 or 1)
x+=3
end
for i=82,105,2 do
local h=msg_freq(i)
line(i,122-h,i,121+h,9)
end
else
set_layer(true)
spr(0,0,32,8,4)
spr(0,64,32,8,4,true)
rectfill(0,64,127,127,0)
rect(19,64,108,125,1)
pal()
end
elseif not cam.flip then
draw_instr()
end
end
end
function _update60()
time_t+=1
futures_update(before_update)
cur_screen:update()
screen_update()
end
function _draw()
cls()
cur_screen:draw()
end
function _init()
if cartdata("freds72_xvst") then
invert_y=dget(0)
if(abs(invert_y)!=1) invert_y=1
else
dset(0,1)
end
menuitem(1,"invert y-axis", function()
invert_y=invert_y==-1 and 1 or -1
sfx(0)
dset(0,invert_y)
end)
menuitem(2,"switch view", function()
set_view(not cockpit_view)
sfx(0)
end)
unpack_models()
for i=1,48 do
add(stars,make_rnd_v(32))
end
cam,cur_screen=make_cam(64),start_screen
music(0)
end
local all_msgs=json_parse'{"attack1":{"spr":12,"title":"ackbar","txt":"commence attack\non the deathstar\nclear tie squadrons","dly":300},"ground1":{"spr":12,"title":"ackbar","txt":"destroy shield\ngenerators","dly":300},"ground2":{"spr":12,"title":"ackbar","txt":"shield is down!\nattack reactor vent","dly":300},"getout":{"spr":104,"title":"han solo","txt":"get out kid\nnow!","dly":300},"gethelp":{"spr":104,"title":"han solo","txt":"kid?\nwe could use you!","dly":300},"victory":{"spr":8,"title":"leia","txt":"the rebellion\n thanks you.\nget back home!","dly":300},"help":{"spr":10,"rnd":{"title":["red leader","alpha","delta wing"],"txt":["help!","cover me!","on my six"]},"dly":300},"vador_out":{"spr":106,"title":"d.vador","txt":"i\'ll be back...","dly":300},"low_hp":{"spr":76,"title":"r2d2","txt":"..--.-..","dly":120,"sfx":5,"rnd":{"repeat_dly":[600,900]}}}'
local low_hp_t,cur_msg=0
function make_msg(msg)
local m=clone(all_msgs[msg])
cur_msg,m.t=m,m.dly
if (m.sfx) sfx(m.sfx)
return m
end
function update_msg()
if cur_msg then
cur_msg.t-=1
if(cur_msg.t<0) cur_msg=nil
end
low_hp_t-=1
if plyr and plyr.hp<2 and low_hp_t<0 and rnd()>0.95 then
make_msg("low_hp")
low_hp_t=cur_msg.repeat_dly
end
end
function msg_freq(i)
return cur_msg and (2*cos(time_t/96+i/16+rnd(0.25))) or rnd(1.5)
end
function draw_msg()
if(not cur_msg) return true
rectfill(32,y,49,20,0)
rect(32,y,49,20,1)
spr(cur_msg.spr,33,3,2,2)
print(cur_msg.title,51,2,9)
print(cur_msg.txt,51,9,7)
if time_t%4>2 then
fillp(0b1011000011110100.1)
rectfill(33,2,48,25,0)
fillp()
end
end
_g.create_ground_group=function(self)
local npcs={}
for _,a in pairs(self.actors) do
local p=v_clone(a.pos)
v_add(p,{0,ground_level,0})
add(npcs,make_actor(a.name,p))
end
return npcs
end
_g.create_flying_group=function(self)
local p,v=make_rnd_pos_v(plyr,64)
local target,n,dly=plyr,3,60+rnd(30)
if rnd()>0.8 then
target=make_actor("patrol",p)
make_msg("help")
v_add(p,v,10)
dly,n=0,2
end
local npcs={}
for i=1,1+rnd(n) do
local a=add(npcs,make_actor("tie",p))
a.target,a.fire_t,a.fatigue=target,dly,self.fatigue[min(self.wave,#self.fatigue)]
v_add(p,v,10)
end
return npcs
end
_g.ingress_mission=function()
ground_level=plyr.pos[2]-300
plyr.boost,plyr.dboost=plyr.acc,1
turrets={}
for i=0,127 do
for j=0,127 do
local r=(i%124==2 and j%16==0) and 1 or rnd()
if r>0.998 then
add(ground_npcs,make_ground_actor(i,j,"turret"))
elseif r>0.99 then
make_ground_actor(i,j,"ground_junk")
end
end
end
return {make_actor("waypoint",{cam.pos[1],ground_level+30,cam.pos[3]})}
end
_g.egress_mission=function()
return {make_actor("waypoint",{cam.pos[1],ground_level+300,cam.pos[3]})}
end
_g.victory_mission=function()
cam.flip,plyr_playing,plyr.dboost=true,false,0.9
set_view(false)
wait_async(180)
make_part("novae",{cam.pos[1],cam.pos[2]-32,cam.pos[3]})
ds_enabled,ground_level=false
wait_async(60)
set_view(true)
cam.flip,plyr_playing=false,true
return {}
end
_g.vador_in=function()
local x,y,z=plyr.pos[1],plyr.pos[2],plyr.pos[3]
local npc,wing=make_actor("vador",{x,y+32,z}),make_actor("mfalcon",{x,y+24,z})
wing.target,npc.target=npc,plyr
make_actor("waypoint",{x,y+30,z})
return {npc}
end
local all_missions=json_parse'[{"msg":"attack1","init":"create_flying_group","music":11,"dly":90,"min_kills":15,"fatigue":[48,40,32,24,12]},{"msg":"ground1","music":11,"init":"ingress_mission"},{"init":"create_ground_group","actors":[{"name":"generator","pos":[256,0,256]},{"name":"generator","pos":[-256,0,256]},{"name":"generator","pos":[256,0,-256]},{"name":"generator","pos":[-256,0,-256]}],"min_kills":4},{"msg":"ground2","init":"create_ground_group","actors":[{"name":"vent","pos":[0,-6,96]}],"min_kills":1},{"msg":"getout","init":"egress_mission","dly":90},{"init":"victory_mission","music":11,"dly":30},{"msg":"gethelp","init":"vador_in","no_skip":true,"min_kills":1,"dly":30},{"msg":"vador_out","dly":300},{"msg":"victory","music":14,"dly":720}]'
function next_mission_async()
mission_score=0
for i=1,#all_missions do
time_t=0
local m=all_missions[i]
m.wave=0
music(m.music or -1,500)
if m.msg then
wait_async(make_msg(m.msg).dly)
end
local kills,min_kills=0,m.min_kills or 0
repeat
local npcs=0
m.wave+=1
if m.init then
for _,a in pairs(m:init()) do
npcs+=1
a.on_die=function(killed)
npcs-=1
if(killed) kills+=1
end
end
end
while plyr and npcs>0 do
yield()
end
if(not plyr) goto gameover
if(m.no_skip and kills<min_kills) goto gameover
if(m.dly) wait_async(m.dly)
until kills>=min_kills
mission_score+=mid(min_kills,0,1)
end
::gameover::
if plyr then
plyr.disabled=true
set_view(false)
wait_async(90)
del(actors,plyr)
plyr=nil
end
wait_gameover_async()
end
local futures={}
function futures_update()
for _,f in pairs(futures) do
local cs=costatus(f)
if cs=="suspended" then
assert(coresume(f))
elseif cs=="dead" then
del(futures,f)
end
end
end
function futures_add(fn)
return add(futures,cocreate(fn))
end
function wait_async(t,fn)
local fn=fn or nop
for i=1,t do
if(not fn(i)) return
yield()
end
end
local mem=0x1000
function unpack_int()
local i=peek(mem)
mem+=1
return i
end
function unpack_float(scale)
local f=(unpack_int()-128)/32
return f*(scale or 1)
end
local itoa='_0123456789abcdefghijklmnopqrstuvwxyz'
function unpack_string()
local s=""
for i=1,unpack_int() do
local c=unpack_int()
s=s..sub(itoa,c,c)
end
return s
end
function unpack_array(fn)
for i=1,unpack_int() do
fn(i)
end
end
function unpack_models()
unpack_array(function()
local model,name,scale={v={},f={},e={}},unpack_string(),unpack_int()
unpack_array(function()
add(model.v,{unpack_float(scale),unpack_float(scale),unpack_float(scale)})
end)
unpack_array(function()
local f={v0=unpack_int(),ei={}}
unpack_array(function()
add(f.ei,unpack_int())
end)
add(model.f,f)
end)
unpack_array(function(i)
model.f[i].n={unpack_float(),unpack_float(),unpack_float()}
end)
for i=1,#model.f do
local f=model.f[i]
f.cp=v_dot(f.n,model.v[f.v0])
end
unpack_array(function()
add(model.e,{
unpack_int(),
unpack_int(),
unpack_int()==1 and true or -1
})
end)
all_models[name]=clone(model,all_models[name])
end)
end