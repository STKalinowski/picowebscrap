-- pico lake
-- by pavilion

function _init()

	game={}
	timer=0

	-- save and restore game
	cartdata("pavilion_picolake_1")
	menuitem(2,"save game",save_game)
	menuitem(3,"restore game",restore_game)
	menuitem(5,"clean restart",restart_game)

	-- global scene layers
	title_bg="c6ef7002c07a7006c0017003c0717010c0677019c063701bc062701cc060701ec05e7020c05d7021c05c7022c05b7023c05b7023c05a7024c0027003c0537024c0007006c051702ec04d7032c04b7033c0457002c0017035c0417040c03c7043c0347002c002704ac02c7054c0297056c0277058c025705bc0147005c008705cc010700ac005705fc0027002c0067079c0047055b0007024c0017057b001707db003707bb0087076b00b7073b00e7070b011706db0157069ce7f3001c07d3003c07b3006c0783008a00ec01ca04a3009a075300ba073300fa06f3011a06d3012a06c3012b06c3011b06d3009b5f56036b048603cb0426042b03c6045b0396047b037604ab034604cb032604fb02f6052b02c6054b02a6057b027605ab024605cb04a6036b04f6030b053602db053602db053602cb054602bb054602bb054602cb052602db052602db051602eb050602fb050602fb011"
	tree="efffe26aa003e077a008e073b004a007e071b007a006e06fb009a006e06db00ca005e069b010a005e066b013a004e065b014a004e065b015a004e065b015a004e064b016a003e0633000b016a003e0623001b017a004e05f3002b018a004e05d3002b01aa003e05d3002b01aa003e05d3002b01aa003e05e3002b019a004e05d3002b019a004e05e3001b019a005e05c3002b019a005e05c3003b018a005e05b3004b018a004e05c3005b018a003e05c3006b017a002e05e3006b016a003e05e3005b016a003e05d3007b015a002e05e300cb00fa003e05f300cb00ea002e060300db00da001e061300eb00ca000e0633011b008e0653011b006e0673011b003e06a3013e06c3011e07230075001e0775007e0775007e0053003e0033003e06550044002e0033006e0003005e065500340033011e0533001e0023005e0065002400490003010e05230125001400590003010e05130135001400590003010e04e30165001400590003010e0453004e00130185001400590003010e04330205002400490013010e04230215002400490013010e04130215002400590013010e04030225002400590013010e0413020500340059002300fe042301b500740069002e00a3003e0443015e0055003e0024006e05e3006efffe22a"
	bench="4fff4fff4fff4067f000407de001f001407ae004f00140782000e005f00140772001e005f001407570012001e005f001406a2001e004f0004000700040022001e005f001406a2001e003f00140042001e0064069600070002001e003f00140042001e0035002700140646000700040022001e003f001400370002001e0005000d00470004060300260007000300140022001e004f000400170014000500770004060300740022001e003f001700040015001400450014061300840022001e003f000400150084063300940012001e0035002d00670004064300960007000400170015002d00670004066300760007000400270005002d00670004067300560007000300370005002d00670004069300360007000300340005002d0067000406a300740015002d0067000406d300240035002d006700040745003d0057000407230015003d0057000407130025004d00470004071300350084074300250064384"

	wave_dots={}
	offset_dots={}
	
	-- init hotspots
	hotspots_layer='' -- global string for hotspot data
	hotspots_lookup={} -- expanded data for easy lookup
	current_hotspot=1

	-- init player
	spr_idx=0
	anim_delay=2
	anim_length=7
	delay=anim_delay
	spr_offset=1

	-- new states
	start_state()
	refresh_score()
	refresh_inventory()

	-- starting point
	init_title_screen()
end

function _update()
	game.upd()
end

function _draw()
	game.drw()
end

function start_state()
	scene=0
	player_x=50
	player_y=112
	flip_x=true

	-- warning: spoilers / walkthrough below

	inv={
		{'birdcage',0},
		{'blanket',0},
		{'car_keys',1},
		{'phone',0},
		{'red_wine',0},
		{'sponge',0},
		{'glass_cleaner',0},
		{'wounded_bird',0},
		{'bird_medicine',0},
		{'right_pocket',0}
	}

	world={
		{'look_trash_bin',0,1},
		{'sponge_taken',0,3},
		{'look_behind_tree',0,3},
		{'birdcage_taken',0,5},
		{'red_wine_taken',0,5},
		{'look_business_card',0,5},
		{'open_trunk',0,0},
		{'look_glass_cleaner',0,0},
		{'look_blanket',0,5},
		{'glass_cleaner_taken',0,3},
		{'blanket_taken',0,5},
		{'window_sprayed',0,3},
		{'window_has_spray',0,0},
		{'window_cleaned',0,8},
		{'bird_crashed',0,0},
		{'bird_notification',0,0},
		{'bird_blanket',0,5},
		{'bird_taken',0,5},
		{'go_to_vet',0,7},
		{'wine_stains',0,3},
		{'see_doctor',0,7},
		{'finale',0,7},
		{'phone_found',0,7}
	}
end

-->8
-- scene 1 : park

function init_scene1()
	scene=1
	game.upd=update_scene
	game.drw=draw_scene
	response_func=response_scene1
	events_func=events_scene1
	custom_draw_bg_func=custom_draw_bg_scene1
	custom_draw_fg_func=custom_draw_fg_scene1
	refresh_htspts=refresh_htspts_scene1

	-- layers
	scene_bg=title_bg
	
	-- hotspots
	hotspots_layer="0fff0fff0994602a201a301d20060014602a201a301d20060014602a201a301d20060014102a201a301d20060014102a201a301d20060014102a0054102a004c1033003ee0001041003ce00010588025e00010588025e00010588025e00010588025e00010588025e00010588025e00010588025e00010588025e00010588025e00010588025e00010588025e00010588025e0001057900000118013e0001057900100128011e000105690030013800fe000105690040014800de000105690060014800be0001057900700148009e0001058900800148007e00010589009001be00010599009001ae000105a90090019e000105b90090018e000105d90080017e000105f90070016e000106190070014e0001062900650010012e0001064900450020011e0001066900150040010e00010685006000ee00010695014e00010695014e000106a5013e000106b5012e000106c5011e000103bf0305011"
	refresh_htspts()

	-- wave dots
	wave_dots={9,51,32,51,42,51,58,51,65,51,125,51,24,53,11,54,35,54,48,54,68,55,78,54,11,58,21,58,37,60,51,59,82,58,122,66,5,69,15,68,33,68,49,67,74,67,64,61}
	init_wave_dots()
	update_wave_dots()

	-- reset input
	reset_cmd()

	music(-1,3000)
end

function response_scene1()
	if q=="look tree" then
		return "there's nothing special to see. at least not on this side of the tree."
	elseif q=="look around" then
		return "you're in a nice quiet park near pico lake. a path leads to the restaurant."
	elseif q=="look bench" then
		return "the park bench looks fine, but you don't have time to sit down."
	elseif q=="use bench" then
		return "you'd love to, but you need to find your phone first."
	elseif q=="look lake" then
		return "you enjoy the view over pico lake."
	elseif q=="look behind tree" then
		if get_world('birdcage_taken') then
			return "nothing more behind the tree."
		else
			if not get_world('look_behind_tree') then
				set_world('look_behind_tree',1,true)
				refresh_htspts()
			end
			return "you see an abandoned birdcage behind the bushes."
		end
	elseif q=="get tree" then
		return "it's a small tree, but no, the tree is too large to pick up."
	elseif q=="get behind tree" then
		return "you already are..."
	elseif q=="get birdcage" then
		set_world('birdcage_taken')
		set_inv('birdcage')
		refresh_htspts()
		return "you pick up the birdcage."
	elseif q=="look trash bin" then
		if get_world('sponge_taken') then
			return "nothing more in the bin."
		else
			if not get_world('look_trash_bin') then
				set_world('look_trash_bin',1,true)
				refresh_htspts()
			end
			return "you see a clean sponge in the bin, wrapped in plastic."
		end
	elseif q=="use blanket" then
		return "there's no time for a picnic."
	elseif q=="get sponge" then
		set_world('sponge_taken')
		set_inv('sponge')
		refresh_htspts()
		return "you take the sponge out of the plastic wrap."
	else
		return global_response()
	end
end

function refresh_htspts_scene1()

	set_hotspot_data(hotspots_layer)
	current_hotspot=check_hotspot(player_x,player_y)
	subj_hotspots={}
	subj_hotspots[1]={'lake','tree'}
	subj_hotspots[6]={'lake','tree'}
	subj_hotspots[8]={'tree'}
	subj_hotspots[3]={'behind tree'}
	subj_hotspots[5]={'trash bin'}
	subj_hotspots[9]={'bench'}
	subjects={'around'}

	if get_world('look_behind_tree') and not get_world('birdcage_taken') then
		add(subj_hotspots[3],'birdcage')
	end
	if 	get_world('look_trash_bin') and not get_world('sponge_taken') then
		add(subj_hotspots[5],'sponge')
	end
end

function custom_draw_bg_scene1()
	draw_wave_dots(offset_dots,7)
	draw_layer(tree,14)
	draw_layer(bench,4)
end

function custom_draw_fg_scene1()
	if player_y<90 then
		draw_layer(tree,14)
	end
	if current_hotspot==8 then
		draw_layer(bench,4)
	end
end

function events_scene1()
	if current_hotspot==14 then
		player_x=126
		init_scene2()
	end
	if current_hotspot==15 then
		player_x=90
		player_y=100
		init_scene3()
	end
	if get_world('window_cleaned') and not get_world('bird_crashed') then
		set_world('bird_crashed',1,true)
	end
	update_wave_dots()
end

-->8
-- scene 2 : restaurant

function init_scene2()
	scene=2
	game.upd=update_scene
	game.drw=draw_scene
	response_func=response_scene2
	events_func=events_scene2
	custom_draw_bg_func=custom_draw_bg_scene2
	custom_draw_fg_func=custom_draw_fg_scene2
	refresh_htspts=refresh_htspts_scene2

	-- layers
	scene_bg="cc717005c06a7004c0077009c0667008c004700bc063700cc001700ec060701fc05e7022c0527005c0027023c04f702fc04d7031c04b7033c04a7034c03f7005c0037035c03d7009c0017035c03b7043c039702fb00e7006c038702cb0177001e000c036702ab01b7000e002c0337028b01fe0033005c022702eb023e005300ac01a702ab028e006300ac0187021b032e007300ac010701ab040e0093013c0037016b046e00a30147014b04ae00b30177007b053e00c30177002b057e00e3016c059e00f3016c058e0103015c058e0113015c057e0133015c0552000e0133017c0522000e0143017c0013002c04c2000e016301bc04b2001e016301cc0492001e017301dc0472002e017301dc0462002e019301cc0452003e0193021c03f2003e01a3021c03e2003e01c3026c0372004e01c3027c0352004e01d3027c0342005e01920033026c0342005e01520073027c0332006e00f200c3028c0322006e00b2010302ec02c2006e00620153030c02a2006e002201670003036c026000620157004303ac022000620117008304ac0120006200d7009c0007001304dc00f000620097009c00470013051c00b00062005700ac00770013052c00a00062001700ac002d000c00770013054c008d0067009c005d000c0077001305dd0067005c009d000c0077001305dd0067003c00bd000c0077001305dd0067003c00bd000c0077001305dc004d0017003c00bd000c0077001305dc004d0017003c00bd000c0077001305dc004d0017003c00bd000c0077001603a3022c004d0017003c00bd000c0077001603a3022c004d0017003c00bd000c007700150393023c004d0017003c00bd000c0077001d03a3022c004d0017003c00bd000c0077001d0295001d00e3022c004d0017003c00bd000c000d0007000c0047001d0035001d0215001d0103022c004d0017003c00bd000c000d0007000c0047001d0015001d0015001d01b5001d0143006b007300ab008c004d0017003c008d0007000c000d000c000d0007000c0047001d0315001d0063000b021c004d0017003c008d0007000c000d000c000d0007000c0047001d0335001d004b022c004d0017003c008d0007000c000d000c000d0007000c0047001d03ab022c004d0017003c008d0007000c000d000c0077001d03ab022c004d0017003c008d0007000c000d000c0077001603ab022c004d0017003c00bd000c00770016039d000b022c004d0017003c00bd000c00770016038d001b022c004d0017003c00bd000c00770016037d001b023c004d0017003c00bd000c00770016036d001b024c004d0017003c00bd000c00770006036d001b025c004d0017003c00bd000c0066037d0016026c004d0017003c00bd000c0046038d0016027c004d0017003c00bd000c0026039d0016028c004d0017003c00bd000c000603ad0016029c004d0017003c00b603bd001602ac004d0017003c009603cd001602bc004d0017003c008603cd001602cd0067003c006603dd001602dd0067003c004603ed001602ed0067003c002603fd001602fd0067003c0006040d0016030d00670026041d0016031d00670006042d001603250066042d001b03350046043d001b03450016045d001b0356046d001b0366045d001b0376044d001b038d045b039d044b2ba"
	furn="cfffcfffc14460007000c077700cc06ee0007002e0057002e0037004c065e0027003e0067003e0047005c05fe0047002e0087004e0077004c05ae0047002e00a7005e0097003c057e0037003e00a7008e0087003c055e0027005e00a700ae0077003c053e0027005e00b700ce0067003c05220017004e00d700ce00520016002c05220016003e00e700e20056002c0546003200e600e2003c05d200e600ec07160007000c07d60007000c07d60007000c07d60007000c07d60007000c07d60007000c0215004c05660007000c02260007001c05760007000c02260007001c05760007000c02260007001c042700ac00960007000c02260007001c03f7010c00660007000c02110005003c03d7012c00560007000c02210005001c03e600070106000c00560007000c02210005001c03f6002700a6002c00660007000c02210005001c042600ac00960007000c02210005001c0475000c00e60007000c02210005001c0477000c00e60007000c01e300310005001c0477000c00e60007000c01f300210005001c0477000c00e60007000c068d0037002c004d006700160007002c065d00260007005c000d006700360007004c062d0046004d000c000d00660017007c063d008c001d0086005d001c064d005c004d00dc073d008cc39"

	-- hotspots
	hotspots_layer="0fff0fff0df91004f00000602003400c20021009f00000602003400c20021009f00000602003000c20021009f00000602003000c20021009f00000259017a01f10022003000c20021009f00000259017a01f10022003000c20021009f0000024b0020024a010100220131009f0000024b0020027a00d100220131009f0000024b0020027101020131009f00000238001b0161002000f102ef00000218003b0161002000b1032f000001f8005b0161041f000001d80061059f000001c8005105bf000001a8005105df00000188005105ff000001780051060f000001580051062f00000138005100de008104df00000118005100be0101049f00000108005100ae0141047f000000e8005100be0161046f000000c8005100ce0181045f000100c8003100de00ac005e0091044f000101ee009c007e0081044f000101ee008c009e0071044f000101ee009c007e0081044f000101fe009c005e0081045f0001020e0161046f0001021e0141047f0001023e0101049f0001025e00c104bf0001028e007104df000107ef000107ef000107ef000"
	hotspots_bird_layer="bfffbfffbdfef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000b029e008b04bf000b025e010b047f000b023e014b045f000b022e016b044f000b021e018b043f000b020e00a0005e009b042f000b020e0090007e008b042f000b020e0080009e007b042f000b020e0090007e008b042f000b021e0090005e008b043f000b022e016b044f000b023e014b045f000b025e010b047f000b027e00cb049f000b02ae007b04bf000b07ef000b07ef000b07ef000b07ef000b07ef000b07ef000"
	refresh_htspts()

	-- wave dots
	wave_dots={51,51,67,51,81,54,89,51,96,54,111,52,122,53,70,58,106,59,116,58,94,62,123,63,101,66,120,69}
	init_wave_dots()
	update_wave_dots()

	-- reset input
	reset_cmd()
end

function response_scene2()
	if q=='look around' then
		return "you're at one of your favorite restaurants. especially in summer, pico lake is an excellent place for lunch. too bad it closes so early."
	elseif q=='look table' then
		if get_world('red_wine_taken') then
			return "there's a business card on the table."
		else
			return "there's a bottle of red wine on the table."
		end
	elseif q=='look garden lamp' then
		return "it's a generic garden lamp. the lamp turns on automatically when it's dark."
	elseif q=='use door' then
		return "you can't open the door. you're too late, the restaurant is closed."
	elseif q=='look door' and get_world('window_has_spray') then
		return "you put glass cleaner on the door, but you need something to wipe it clean."
	elseif q=='look door' then
		if get_world('window_cleaned') then
			return "the restaurant is closed. you can see through the window that everybody has gone home."
		else
			return "the door is closed. you can't tell if someone is still inside as the lights are out and the glass is smudged."
		end
	elseif q=='talk door' then
		return "\"hello!?\"... there's no response. the restaurant looks closed."
	elseif q=='talk wounded bird' then
		return "\"hey, i'm sorry\", you mumble... no response, the bird is unconscious."
	elseif q=='use glass cleaner' and not get_world('window_sprayed') and current_hotspot == 8 then
		set_world('window_sprayed',1,true)
		set_world('window_has_spray',1,true)
		sfx(10)
		return "ok, you spray some of the glass cleaner on the glass door."
	elseif q=='use glass cleaner' and get_world('window_sprayed') and current_hotspot == 8 then
		return "you already did."
	elseif q=='use sponge' and not get_world('window_sprayed') and current_hotspot == 8 then
		return "there's nothing you can use to clean the door. maybe you should find something to use."
	elseif q=='use sponge' and get_world('window_has_spray') and current_hotspot == 8 then
		set_world('window_has_spray',0,true)
		set_world('window_cleaned',1,true)
		return "you wipe the door clean with the sponge. you can see through it now."
	elseif q=='use sponge' and get_world('window_cleaned') and current_hotspot == 8 then
		return "no need to use the sponge again."
	elseif q=='get red wine' then
		set_world('red_wine_taken')
		set_inv('red_wine')
		refresh_htspts()
		return "you take the bottle of red wine. finders, keepers. underneath the bottle, you discover a business card on the table."
	elseif q=='look business card' then
		if not get_world('look_business_card') then
			set_world('look_business_card',1,true)
			return "it has the number and address of a local veterinarian. you memorize the address, just in case you would need one."
		else
			return "it has the number and address of a local veterinarian. you know where it is located."
		end
	elseif q=='get business card' then
		return "nah, you don't need it. you can read it, though."
	elseif q=='use blanket' and get_world('bird_crashed') and current_hotspot==14 then
		set_world('bird_blanket',1,true)
		set_inv('blanket',0)
		return "you wrap the bird in the blanket."
	elseif q=='use birdcage' and get_world('bird_blanket') and current_hotspot==14 then
		set_world('bird_taken')
		set_inv('wounded_bird')
		refresh_htspts()
		return "good idea. you put the bird in the cage."
	elseif q=='use birdcage' and not get_world('bird_blanket') and current_hotspot==14 then
		return "good idea, but you don't want to pick up the bird with your bare hands. find something to wrap around it."
	elseif q=='get wounded bird' and get_world('bird_blanket') then
		return "you don't have anything to put the bird in. maybe you should find a safer way to transport it."
	elseif q=='get wounded bird' then
		return "you don't want to pick the bird up with your bare hands. maybe you should find something to wrap around it."
	else
		return global_response()
	end
end

function refresh_htspts_scene2()

	set_hotspot_data(hotspots_layer)

	-- prevent walking over bird by adding hotspot layer
	if get_world('bird_crashed') and not get_world('bird_taken') then
		set_hotspot_data(hotspots_bird_layer,true,11)
	end
	
	subj_hotspots={}
	subj_hotspots[4]={'garden lamp'}
	subj_hotspots[2]={'garden lamp'}
	subj_hotspots[14]={}
	subj_hotspots[9]={'table'}
	subj_hotspots[11]={'table'}
	subj_hotspots[8]={'door'}
	subjects={'around'}

	if get_world('bird_crashed') and not get_world('bird_taken') then
		add(subj_hotspots[14],'wounded bird')
		--sfx(4)
	end
	if not get_world('red_wine_taken') then
		add(subj_hotspots[9],'red wine')
		add(subj_hotspots[11],'red wine')
	end
	if get_world('red_wine_taken') then
		add(subj_hotspots[9],'business card')
		add(subj_hotspots[11],'business card')
	end
end

function custom_draw_bg_scene2()
	draw_wave_dots(offset_dots,7)
	draw_layer(furn,12)
	local reflectionclr=6
	if not get_world('red_wine_taken') then
		spr(62,48,83)
	end
	if get_world('window_has_spray') then
		spr(58,11,90)
	end
	if get_world('bird_crashed') then
		spr(59,12,82)
		if not get_world('bird_taken') then
			if get_world('bird_blanket') then
				spr(61,40,111)
			else
				spr(60,40,111)
			end
		end
	else
		if get_world('window_cleaned') then
			reflectionclr=7
		end
		line(16,84,19,87,reflectionclr)
		line(14,85,18,89,reflectionclr)
	end
end

function custom_draw_fg_scene2()
	if current_hotspot==4 or current_hotspot==9 or current_hotspot==10 then
		draw_layer(furn,12)
		if not get_world('red_wine_taken') then
			spr(62,48,83)
		end
	end
end

function events_scene2()
	if current_hotspot==15 then
		player_x=2
		init_scene1()
	end
	if get_world('bird_crashed') and not get_world('bird_notification') then
		set_world('bird_notification',1,true)
		response_text='a bird crashed into the spotlessly clean window. nice going :('
		action_state=4
		sfx(5)
	end
	update_wave_dots()
end

-->8
-- scene 3 : car parking

function init_scene3()
	scene=3
	game.upd=update_scene
	game.drw=draw_scene
	response_func=response_scene3
	events_func=events_scene3
	refresh_htspts=refresh_htspts_scene3
	custom_draw_bg_func=custom_draw_bg_scene3
	custom_draw_fg_func=custom_draw_fg_scene3

	-- layers
	scene_bg="cb627007c0767009c0707010c06c7014c068701dc0607020c05d7022c05c7023c0597028c0517002c000702bc04e7030c0487002c0017031c0477037c01a7003c0287037c0107004c0027006c0037003c0157003c0047038c00e7019c0127043c00e701ac0107044c00d701cc00a7002c0007045c0027003c004701fc007704bc001702dc003704bc001702fc000702aa0057031b008703db001a004702db00f7039b004a0047029b0127037b007a0027027b0177031b00ba002701eb022702eb00ca002701ab02970293000b00da0017017b02f70263000b00da0027016c0553000b00fa001c06c3000b010a000c06c3001b00fa001c06c3000b00fa001c06b3001b00fa001c06b3002b00ea001c06b3002b00ea001c06b3004b00ca001c06b3006b00aa000c06d3007b008c06e3008b007c06f300ab003c0173000c058300cc0173001c00a3003c04a3009c017301cc0435005c0113026c0405005c0023001c0013033c03e500240023040c0313003c002500140033043c02b30095001400330235001301fa0203012500140029000302370013023a01b3013500040039000302370013024a0193013500140039001302250013023b01b3010500340049001b004301c5001301fb020300cb00350014005b00a3005b0125001b07d5001b055e001b01e3002b00130015001b001300db00a300eb0023006b0202001e003b0033005b011301db002301db0013004b01870002002e003300bb0003005b0003003b0003047b012e004b00220013063b0112002e003b0013065b00e300170003000b0002001e0033066b00e3003b0012001e0003068b00e3004b00120003068b00f3004b000306ab010306e6000b01130015000302c5001303a6004b00f500230255009301c5007301050006008b00c5004302050343002500430035002600cb00950043017504b600fb006500530165035d00350106012b005d001500530135010d0085008d0085003d00d5007d0046014b003d002500530005002300ed0025005d0286002d0156016b001d003500b300bd02f6001d0186017b000d0065009300ad0206001d01b6001d0096018d007500c3006d0226001d0176001d00b6018d00c500b3002d04a6018d01050083001d04a6019d00f500a6066d0076001d00750066068d0076000d0085004606ad0115002606cd0115000606ed00b6001d0026070d00b6000d0016072d00c6074d00a70246051d008602470006052d006602470006054d004602570006055d002602670006056d00060267001607e7000607f7000607f7000607e7001607e7000607f7000607e7001607e7000607f70006050702f607e7001607e7000607f7000607e7001607e7001607e7000604b"
	
	-- hotspots
	hotspots_layer="0fff0fff0ecae0180066e0180066e01800691012006c1013001d20211040001c20211042001a2021104400182021104600162021104800142021104900132021104b00112021104d000f2021104f000d20211051002da004104e002ba004104f002aa00410510028a00410530026a00410550024a00410570022a00410580021a00410580021a00410580021a0041058400d1071400d1071400d13f1"
	refresh_htspts()

	-- wave dots
	wave_dots={14,52,46,52,56,52,78,51,116,53,125,57,114,59,70,54,78,60,61,58,36,57,28,54,6,59}
	init_wave_dots()
	update_wave_dots()

	-- reset input
	reset_cmd()

end

function response_scene3()
	if q=='look around' then
		return "you're standing in a parking lot near the park entrance. your car is parked on the side; it looks like you're the only one here."
	elseif q=='look car' then
		return "this is your car."
	elseif q=='look trunk' then
		if get_world('open_trunk') then
			if not get_world('look_glass_cleaner') then
				set_world('look_glass_cleaner',1,true)
				refresh_htspts()
				return "there's a small bottle with glass cleaner in the trunk."
			elseif not get_world('glass_cleaner_taken') then
				return "there's a small bottle with glass cleaner in the trunk."
			elseif not get_world('look_blanket') and get_world('glass_cleaner_taken') then
				set_world('look_blanket',1,true)
				refresh_htspts()
				return "hey wait, there's also a blanket in the trunk :)"
			else
				return "it's empty now, nothing of interest anymore."
			end
		else
			return "first, you need to open the trunk."
		end
	elseif q=='use trunk' then
		if get_world('open_trunk') then
			set_world('open_trunk',0,true)
			refresh_htspts()
			sfx(2)
			return "you close the trunk."
		else
			return "the trunk is locked."
		end
	elseif q=='use car' or q=='use car keys' and current_hotspot==4 then
		if get_world('look_business_card') and get_world('bird_taken') then
			set_world('go_to_vet',1,true)
			set_inv('birdcage',0)
			set_inv('wounded_bird',0)
			return "you drive to the vet."
		elseif get_world('bird_taken') then
			return "you don't know a place to take the bird."
		else
			return "it would be best to find your phone; you don't want to leave yet unless there's an emergency."
		end
	elseif q=='use car keys' then
		if current_hotspot==10 then
			if get_world('open_trunk') then
				set_world('open_trunk',0,true)
				refresh_htspts()
				sfx(2)
				return "you close the trunk."
			else
				set_world('open_trunk',1,true)
				refresh_htspts()
				sfx(6)
				return "ok, you open the trunk."
			end
		else 
			return "you're not close enough to either the car's front door or the trunk."
		end
	elseif q=='get glass cleaner' then
		set_world('glass_cleaner_taken')
		set_inv('glass_cleaner')
		set_world('open_trunk',0,true)
		sfx(2)
		refresh_htspts()
		return "you take the bottle of glass cleaner and close the trunk."
	elseif q=='get blanket' then
		set_world('blanket_taken')
		set_inv('blanket')
		set_world('open_trunk',0,true)
		sfx(2)
		refresh_htspts()
		return "you take the blanket and close the trunk."
	elseif q=='talk trunk' then
		return "you're glad you don't get any response."
	elseif q=='use birdcage' and current_hotspot==10 then
		return "that isn't necessary. you don't have put stuff in the trunk."
	else
		return global_response()
	end
end

function refresh_htspts_scene3()

	set_hotspot_data(hotspots_layer)
	subj_hotspots={}
	subj_hotspots[4]={'car'}
	subj_hotspots[10]={'trunk'}
	subjects={'around'}

	if get_world('look_glass_cleaner') and not get_inv('glass_cleaner') and get_world('open_trunk') then
		add(subj_hotspots[10],'glass cleaner')
	end
	if get_world('look_blanket') and not get_inv('blanket') and get_world('open_trunk') then
		add(subj_hotspots[10],'blanket')
	end
end

function custom_draw_bg_scene3()
	draw_wave_dots(offset_dots,7)
 	-- draw car
	palt(14,true)
	palt(0,false)
	spr(90,0,95,4,3)
	palt(14,false)
	palt(0,true)
	if get_world('open_trunk') then
		spr(10,20,90,2,1)
	end
end

function custom_draw_fg_scene3()
	if current_hotspot==2 then
		-- draw car
		palt(14,true)
		palt(0,false)
		spr(90,0,95,4,3)
		palt(14,false)
		palt(0,true)
		if get_world('open_trunk') then
			spr(10,20,90,2,1)
		end
	end
end

function events_scene3()
	if current_hotspot==14 then
		player_y=126
		init_scene1()
	end
	if get_world('go_to_vet') and action_state==1 then
		player_x=-10
		text_screen_message="you drive to the address you found on the card. at the vet, you put the wounded bird down on a table in the waiting room."
		text_screen_next=4
		init_circle_transition()
	end
	update_wave_dots()
end

-->8
-- scene 4 : vet

function init_scene4()
	scene=4
	player_x=90
	player_y=95
	flip_x=true
	game.upd=update_scene
	game.drw=draw_scene
	response_func=response_scene4
	events_func=events_scene4
	custom_draw_bg_func=custom_draw_bg_scene4
	custom_draw_fg_func=custom_draw_fg_scene4
	refresh_htspts=refresh_htspts_scene4

	-- layers
	scene_bg="0fff0d13600370506002002160097050600900145001600d7050600e5001000d5001600d7050600e5001000d5001600d7050600e5001000d5001600d7050600e5001000d5001600d7050600e5001000d5001600ac00160007050600e5001000d50016008c00360007050600e5001000d50016005c001d000c00360007050600e5001000d50016003c003d000c00360007050600e5001000d50016001c005d000c003600070506001d000c000600a5001000d50016001c005d000c003600070506001d000c00360075001000d50016001c005d000c003600070506001d000c0017000c00260055001000d50016001c005d000c003600070506001d000c0007000c0017000c00260035001000d50016001c005d000c003600070506001d0007000c0017000c00560015001000d50016001c005d000c00360007015b000300170376001d000c0017000c00660015001000d50016001c005d000c0036000700e30017003b000300170386001d000c0007000c00760015001000d50016001c005d000c0036000700f30017002300170396001d000c00960015001000d50016001c005d000c0036000701030017000b000300170396001d000c0021003c00260015001000d50016001c005d000c0036000700b300270023003703a6001d000c0011005c00160015001000d50016001c005d000c00270006000700cb000300150007001b000300050007001b000703760017000c00290021001c00160015001000d50016001c005d000c0007001d0006000700db00030015000700030017000b000300170376001d0007001c00090031000c00160015001000d50016001c005d0007000d0026000700eb000300170003004500070048013701e6001d002700090021001c00160015001000d50016001c0047000d0046000700fb00030045001700420008014701d6001d003700090011001c00160015001000d50016001c0037000d00450006000701030035000700620008014701d60007001d00370011001c00160015001000d50016001c0017001d0035001c000600070113001700820008014701d6000d0007001d002200170001000c00160015001000d50016001c0007000d0045000c00260007012300070092013701e6001d0007001900120027001c00060015001000d500160017000d0045000c003600070105001300050017008d000600070056000d00070056000d000701f6002d000700220029000d000700060015001000d50016001d0035001d000c0036000700f5001400250017007d000600070056000d00070056000d000701f6003d00070029002d00160015001000d50016001d0025000c001d000c0036000700f60005004d000700680137006d00a700c6004d00070022001d00160015001000d50016001d0005001c002d000c0036012d004600520156004d00c6011d0007003d00160015001000d500160015000c004d000c0036012d0046006d000700060067000d00060067000d0006005700c6012d000700460015001000d50016001c005d000c003f001e00e6001d004e005d000700020077000d00020077000d000e004700ce00c6006d000700360015001000d50016001c005d000c002f005e00b20006001d0022004e001d000700020077000d00020077000d0002000e0037000d0002008d00070002001e00b6006d00360015001000d50016001c005d000c001f00ae0082009e0022015e004200de00c600b5001000d50016001c005d000c000f00ae00c2005e03a600a5001000d50016001c005d000e003f006e004f001e04860095001000d50016001c005f001e005f002e004f005e04660085001000d50016001c004f005e009f009e04460075001000d50016001c003f009e005f00ce04360065001000d50016001c002f00ae008f008e04560055001000d50016001c001f00ae004f001e005f004e04760045001000d50016001c000f00ae004f005e005f000e04960035001000d50016001e002f007e004f009e04e60025001000d50016000e006f003e004f00be04e60015001000d502ee0105031000d502e601050310b05"
	
	-- hotspots
	hotspots_layer="0fff0fff0d9a50011005003cb001003750011005003db00200355001100680113017b015a00100335001100780113017b015a002003150011047a003003050011049a003002e5001104aa004002c5002104ba004002a5002104ca00500285002104ea005002650021050a005002450021051a006002250021053a005004a90100bb7"
	refresh_htspts()

	-- reset input
	reset_cmd()
end

function response_scene4()
	if q=='look around' then
		return "you're in the waiting room of the vet you memorized from the business card. to the right is the reception."
	elseif q=='look receptionist' or q=='use receptionist' or q=='get receptionist' then
		return "the receptionist is here to help, just select \"talk\" from the menu."
	elseif q=='look seating' or q=='use seating' then
		return "you're too impatient to sit down."
	elseif q=='look plant' then
		return "nothing is hidden in the plant."
	elseif q=='get plant' then
		return "no way."
	elseif q=='look vets office' or q=='use vets office' then
		return "the door is closed. you need to go to the reception before you enter."
	elseif q=='look exit' then
		return "you see a fairly busy street outside. your car is parked near the clinic."
	elseif q=='use exit' then
		return "you can't just leave the bird, you do have a sense of responsibility."
	elseif q=='talk receptionist' and get_world('wine_stains') then
		if get_inv('bird_medicine') then
			return "she gives you some instructions on the medication. \"your bird is going to be fine\", she reassures."
		else
			set_world('see_doctor',1,true)
			return "you tell the receptionist you cannot wait any longer. she looks at the bird and is startled by the sight of the 'bloody' stains. \"the doctor will see you now\"."
		end
	elseif q=='talk receptionist' then
		return "you explain to the receptionist what has happened. she's not impressed and kindly asks you to sit down and wait."
	elseif q=='use red wine' and current_hotspot==11 then
		set_world('wine_stains',1,true)
		sfx(11)
		return "you pour the red wine over the cage. it's a bloody-looking mess."
	elseif q=='use red wine' and current_hotspot==10 then
		return "the receptionist isn't interested in the stolen wine bottle."
	elseif q=='get birdcage' then
		return "you don't need to pick it up."
	elseif q=='look birdcage' and get_world('wine_stains') then
		return "the cage is covered with red stains. it looks more urgent now."
	elseif q=='look birdcage' then
		return "you see a birdcage with the wounded bird. it doesn't look too dramatic, though."
	elseif q=='talk birdcage' then
		return "you tell the bird that all will be fine in a couple of minutes."
	elseif q=='use bird medicine' and current_hotspot==11 then
		set_world('finale',1,true)
		return "you feed the bird a pain killer pill from the box. they look strangely appealing... you can't resist yourself and try one too. don't try this at home!"
	elseif q=='use bird medicine' then
		return "you're not close enough to the bird."
	elseif q=='look right pocket' then
		set_world('phone_found')
		return "yes, there you go!"
	else
		return global_response()
	end
end

function refresh_htspts_scene4()
	set_hotspot_data(hotspots_layer)
	subj_hotspots={}
	subj_hotspots[3]={'seating'}
	subj_hotspots[5]={'exit'}
	subj_hotspots[8]={'plant'}
	subj_hotspots[9]={'vets office'}
	subj_hotspots[10]={'receptionist'}
	subj_hotspots[11]={'birdcage'}
	subjects={'around'}
end

function custom_draw_bg_scene4()
	palt(12,true)
	palt(0,false)
	spr(12,80,80,2,2)
	palt(12,false)
	palt(0,true)
	if get_world('wine_stains') then
		spr(63,80,80)
	end
end

function custom_draw_fg_scene4()
end

function events_scene4()
	if get_world('see_doctor') and not get_inv('bird_medicine') and action_state==1 then
		player_x=-10
		text_screen_message="the vet examines the bird. the bird is fine and will fully recover. she hands you some pain killers for birds and sends you on your way."
		set_inv('bird_medicine')
		text_screen_next=4
		init_text_screen()
	end
	if get_world('finale') and not get_inv('right_pocket') and action_state==1 then
		text_screen_message="you feel disorientated in a useful way. you have a lucid daydream and suddenly remember where you put your phone. it's in your right pocket..."
		set_inv('right_pocket')
		text_screen_next=4
		init_text_screen()
	end
	if get_world('phone_found') and action_state==1 then
		init_circle_transition()
	end
end

-->8
-- title screen

function copy_sequence(orig)
	local copy
	copy={}
	for orig_key,orig_value in pairs(orig) do
		copy[orig_key]=orig_value
	end
	return copy
end

function randomize_wave_dots(dots)
	for d=1,#dots,2 do
		dots[d]=dots[d]+flr(rnd(2))-1
	end
end

function init_wave_dots()
	timer=0
	offset_dots=copy_sequence(wave_dots)
	randomize_wave_dots(offset_dots)
end

function update_wave_dots()
	if timer>40 then
		timer=0
		offset_dots=copy_sequence(wave_dots)
		randomize_wave_dots(offset_dots)
	end
	timer+=1
end

function draw_wave_dots(dots,clridx)
	for d=1,#dots,2 do
		pset(dots[d],dots[d+1],clridx)
	end
end

function init_title_screen()
	game.upd=update_title_screen
	game.drw=draw_title_screen

	wave_dots={40,120,90,122,10,112,30,114,55,112,70,111,110,115,90,112}
	init_wave_dots()

	music(0)
end

function update_title_screen()
	update_wave_dots()
	if btnp(4) or btnp(5) then
		text_screen_message="wait! where's your phone? you probably left it at the restaurant near pico lake again..."
		text_screen_next=1
		init_circle_transition()
	end
end

function draw_title_screen()
	cls()
	draw_layer("cfffcdff"..title_bg)

	spr(192,32,12,8,4)
	spr(200,32,40,8,4)
	if time() < 3 then
		outline("by pavilion",42,77,13,7)
	else
		outline("press 🅾️ or ❎ to start",18,77,13,7)
	end 
	draw_wave_dots(offset_dots,7)
end

-->8
-- text screen

function init_text_screen()
	game.upd=update_text_screen
	game.drw=draw_text_screen
	timer=0
end

function update_text_screen()
	timer+=1
	if (btnp(4) or btnp(5)) and timer>15 then
		if text_screen_next==4 then
			init_scene4()
		else
			init_scene1()
		end
	end
end

function draw_text_screen()
	cls()
	draw_message(text_screen_message)
end

-->8
-- end screen

function init_end_screen()
	show_final_message=true
	game.upd=update_end_screen
	game.drw=draw_end_screen
	time=0
	music(0)
end

function update_end_screen()
	timer+=1
	if (btnp(4) or btnp(5)) and timer>15 then
		show_final_message=false
	end
end

function draw_end_screen()
	cls()
	draw_layer(title_bg)
	draw_layer(tree,14)
	draw_layer(bench,4)
	spr(139,97,94,2,3)
	spr(62,116,97)
	spr(44,98,32,2,1)
	outline("the end",50,60,13,7)
	if show_final_message then
		draw_message("you decide to tell no one what has happened and head back to pico lake to enjoy the rest of the afternoon. oh, and thanks for playing!",true)
	end
end

-->8
-- engine

-- verbs
verbs={"look","use","get","talk"}
current_verb_idx=1
current_verb=verbs[1]

action_state=1
-- 1 walk
-- 2 verb
-- 3 subject
-- 4 response

function reset_cmd()
	current_subject_idx=1
	top_subject_idx=1
	current_subject=subjects[1]
	q=''
end

function set_inv(id,value)
	if value==nil then
		value=1
	end
	for i in all(inv) do
		if id==i[1] then
			i[2]=value
		end
	end
	refresh_inventory()
end

function set_world(id,value,silent)
	if value==nil then
		value=1
	end
	if silent==nil then 
		silent=false
	end
	for i in all(world) do
		if id==i[1] then
			i[2]=value
			if (not silent) then
				sfx(1)
			end
			refresh_score()
		end
	end
end

function get_inv(id)
	for i in all(inv) do
		if id==i[1] then
			if i[2]==1 then
				return true
			else
				return false
			end
		end
	end
end

function get_world(id)
	for i in all(world) do
		if id==i[1] then
			if i[2]==1 then
				return true
			else
				return false
			end
		end
	end
end

function replace_underscore(str)
	local res=''
	for i=1,#str do
		if sub(str,i,i)=='_' then
			res=res..' '
		else
			res=res..sub(str,i,i)
		end
	end
	return res
end

function refresh_score()
	current_score=0
	max_score=0
	for i in all(world) do
		max_score+=i[3]
		if (i[2]==1) then
			current_score+=i[3]
		end
	end
	score_message="points: "..current_score.." / "..max_score
end

function refresh_inventory()
	inventory={}
	for i in all(inv) do
		if (i[2]==1) then
			add(inventory, replace_underscore(i[1]))
		end
	end
end

function update_player()
	dx=0
	dy=0

	if (btn(⬅️)) then dx=-1 end
	if (btn(➡️)) then dx=1 end
	if (btn(⬇️)) then dy=1 end
	if (btn(⬆️)) then dy=-1 end

	-- walk
	if (dx==-1 or dx==1 or dy==1 or dy==-1) and (check_hotspot(player_x+dx,player_y+ dy)>0) then
		player_x+=dx
		player_y+=dy
		delay-=1
		current_hotspot=check_hotspot(player_x,player_y) -- update global current_hotspot
		if delay<0 then
			delay=anim_delay
			spr_idx+=1
			if spr_idx>anim_length then
				spr_idx=0
			end
		end
		-- right
		if dx==1 then
			spr_offset=1
			flip_x=true
		-- left
		elseif dx==-1 then
			spr_offset=1
			flip_x=false
		-- up
		elseif dy==-1 then
			spr_offset=65
		-- down
		elseif dy==1 then
			spr_offset=129
			flip_x=false
		end
	else
		-- keep facing last direction
		if spr_offset==65 or spr_offset==64 then 
			spr_offset=64
		elseif spr_offset==129 or spr_offset==128 then 
			spr_offset=128
		else
			spr_offset=0
		end
		spr_idx=0
	end

end

function update_scene()
	events_func()

	-- walk
	if action_state==1 then
		update_player()

		if btnp(🅾️) then
			subjects={}
			current_verb_idx=1
			current_subject_idx=1
			top_subject_idx=1
			current_verb=verbs[current_verb_idx]
			action_state=2
		end
	-- choose verb
	elseif action_state==2 then
		-- cycle up through verbs
		if btnp(⬆️) then
			current_verb_idx-=1
			if current_verb_idx<1 then
				current_verb_idx=1
			end
			current_verb=verbs[current_verb_idx]
		end
		-- cycle down through verbs
		if btnp(⬇️) then
			current_verb_idx+=1
			if current_verb_idx>4 then
				current_verb_idx=4
			end
			current_verb=verbs[current_verb_idx]
		end
		-- choose verb and continue to subject state
		if btnp(🅾️) or btnp(➡️) then
			-- setup subjects
			subjects={}
			if current_verb=='look' then
				subjects={'around'}
			end
			-- add hotspots
			htspt=check_hotspot(player_x,player_y)
			for h in all(subj_hotspots[htspt]) do
				add(subjects,h)
			end
			-- add inventory
			if current_verb=='look' or current_verb=='use' then
				for v in all(inventory) do
					add(subjects,v)
				end
			end
			if subjects[1]==nil  then
				if current_verb=='use' then
					subjects={'nothing'}
				elseif current_verb=='get' then
					subjects={'nothing'}
				elseif current_verb=='talk' then
					subjects={'to yourself'}
				end
			end
			current_subject_idx=1
			top_subject_idx=1
			current_subject=subjects[current_subject_idx]
			action_state=3
		end
		-- cancel and go back to action state 1
		if btnp(❎) then
			current_subject_idx=1
			top_subject_idx=1
			current_verb_idx=1
			action_state=1
		end
	-- choose subject
	elseif action_state==3 then
		-- cycle up through subjects
		if btnp(⬆️) then
			current_subject_idx-=1
			if current_subject_idx<1 then
				current_subject_idx=1
				top_subject_idx=1
			end
			if current_subject_idx<top_subject_idx then
				top_subject_idx=current_subject_idx
			end
			current_subject=subjects[current_subject_idx]
		end
		-- cycle down through subjects
		if btnp(⬇️) then
			current_subject_idx+=1
			if current_subject_idx>#subjects then
				current_subject_idx=#subjects
			end
			if current_subject_idx>top_subject_idx+6 then
				top_subject_idx=current_subject_idx-6
			end
			current_subject=subjects[current_subject_idx]
		end
		-- choose subject and construct response
		if btnp(🅾️) then
			q=current_verb.." "..current_subject
			response_text=response_func()
			current_subject_idx=1
			top_subject_idx=1
			current_verb_idx=1
			current_verb=verbs[current_verb_idx]
			action_state=4
		end
		if btnp(❎) or btnp(⬅️) then
			action_state=2
		end
	-- display reponse
	elseif action_state==4 then
		if btnp(🅾️) then
			action_state=1
		end
	-- close reponse and return to action state 1
	elseif btnp(❎) then
		action_state=1
	end
end

function draw_player()
	spr(spr_idx+spr_offset,player_x-3,player_y-23,1,3,flip_x)
end

function draw_scene()
	cls()
	draw_layer(scene_bg)
	custom_draw_bg_func()
	draw_player()
	custom_draw_fg_func()

	if action_state==2 then
		draw_verb()
	end
	if action_state==3 then
		draw_verb()
		draw_subject()
	end
	if action_state==4 then
		draw_message(response_text,true)
	end
	draw_score()
end

-- render layer datastring to global hotspots_lookup sequence
function set_hotspot_data(s,overlay,chroma)
	local hlidx=0
	if not overlay then
		hotspots_lookup={} -- sequence {8,8,3,5} are color idx at {{0,0},{1,0},{2,0},{3,0}} etc.
	end
	for i=1,#s,4 do
		clridx=tonum('0x'..sub(s,i,i))
		length=tonum('0x'..sub(s,i+1,i+3))
		for j=0,length do
			if not overlay then
				add(hotspots_lookup,clridx)
			elseif (clridx!=chroma) then
				hotspots_lookup[hlidx]=clridx
			end
			hlidx+=1
		end
	end
end

-- check position in global hotspots_lookup sequence
function check_hotspot(cx,cy)
	local position=cy*128+cx
	if cx>128 or cx<1 or cy>127 then -- note: reference is 1px more to the left
		return 0
	end
	return hotspots_lookup[position]
end

-- draw layer with string s and chroma for transparancy
function draw_layer(s,chroma)
	local rowspace=128
	local x=0
	local y=0

	for i=1,#s,4 do
		clridx=tonum('0x'..sub(s,i,i))
		length=tonum('0x'..sub(s,i+1,i+3))
		while length+1>rowspace do
			if clridx!=chroma then
				line(x,y,x+rowspace,y,clridx)
			end
			length=length-rowspace
			rowspace=128
			y=y+1
			x=0
		end
		if clridx!=chroma then
			line(x,y,x+length,y,clridx)
		end
		rowspace=rowspace-length-1
		x=x+length+1
	end
end

-- split string in multiple lines to fit message box
function split_message(message)
	local words=split(message," ",false)
	local lines={}
	local line_row=""
	for word in all(words) do
		if #word+#line_row<25 then
			line_row=line_row..word.." "
		else
			add(lines,line_row)
			line_row=word.." "
		end
	end
	if line_row!='' then
		add(lines,line_row)
	end
	return lines
end

function draw_message(message,boxed)
	local lines=split_message(message)
	local x=15
	local y=62-#lines*4
	text_color=7
	if boxed then
		rectfill(10,y-4,117,y+#lines*8,7)
		rectfill(11,y-5,116,y+1+#lines*8,7)
		line(12,y+2+#lines*8,115,y+2+#lines*8,13)
		text_color=0
	end
	cursor(x,y)
	for l in all(lines) do
		print(l,x,y,text_color)
		y+=8
	end
end

function draw_verb()
	for i=1,#verbs do
		local offset=13*(#verbs-i)
		local text_color=7
		local text_bg=13
		local border_color=5
		if current_verb==verbs[i] then
			text_color=0
			text_bg=7
			border_color=6
		end
		rectfill(11,107-offset,34,117-offset,text_bg)
		rectfill(10,108-offset,35,116-offset,text_bg)
		line(11,118-offset,34,118-offset,border_color)
		pset(10,117-offset,border_color)
		pset(35,117-offset,border_color)
		cursor(15,110-offset)
		print(verbs[i],text_color)
	end
	if action_state==2 then
		outline("⬇️⬆️ select",74,110,13,7)
		outline("❎ cancel",82,102,13,7)
	end
end

function draw_subject()

	if top_subject_idx>1 then
		spr(15,74,23)
	end

	-- max_subjects -> 7
	if top_subject_idx+7<=#subjects then
		spr(14,74,120)
	end

	for i=1,#subjects do
		if i>=top_subject_idx and i<top_subject_idx+7 then -- within range --
			local offset
			local text_color=7
			local text_bg=13
			local border_color=5

			-- determine list height
			if 7<#subjects then
				offset=13*(7-i+top_subject_idx-1)
			else
				offset=13*(#subjects-i)
			end

			-- highlight current subject
			if current_subject==subjects[i] then
				text_color=0
				text_bg=7
				border_color=6
			end
			rectfill(40,107-offset,116,117-offset,text_bg)
			rectfill(39,108-offset,117,116-offset,text_bg)
			line(40,118-offset,116,118-offset,border_color)
			pset(39,117-offset,border_color)
			pset(117,117-offset,border_color)
			cursor(45,110-offset)
			print(subjects[i],text_color)
		end
	end
end

function draw_score()
	print(score_message,123-#score_message*4,7,13)
	print(score_message,123-#score_message*4,6,7)
end

function outline(s,x,y,c1,c2)
	for i=0,2 do
		for j=0,2 do
			if not(i==1 and j==1) then
				print(s,x+i,y+j,c1)
			end
		end
	end
	print(s,x+1,y+1,c2)
end

function init_circle_transition()
	ct_radius=100
	game.upd=update_circle_transition
	game.drw=draw_circle_transition
end

function update_circle_transition()
	ct_radius-=6
	if (ct_radius<-20) then
		if get_world('phone_found') then
			init_end_screen()
		else
			init_text_screen()
		end
	end
end

function draw_circle_transition()
	if ct_radius>-4 then
		for i=0,4 do
			circ(63,63,ct_radius+i,0)
			circ(63,64,ct_radius+i,0)
			circ(64,64,ct_radius+i,0)
			circ(64,63,ct_radius+i,0)
		end
	end
end

function global_response()
	if q=='look car keys' then
		if get_world('go_to_vet') then
			return "your car keys are in your pocket. your car is parked just outside the veterinary clinic."
		else
			return "your car keys are in your pocket. your car is parked near the entrance of the park."
		end
	elseif q=='look sponge' then
		return "it's an ordinary sponge."
	elseif q=='look birdcage' then
		return "the cage is rusty and dented, but still intact."
	elseif q=='look red wine' then
		return "the red wine bottle is dated 2019. it feels like a careless year."
	elseif q=='look wounded bird' then
		return "the bird is unconscious, but it's alive."
	elseif q=='look bird medicine' then
		return "the box with bird pain killers looks strangely appealing to you."
	elseif q=='look glass cleaner' then
		return "it's a glass cleaner spray bottle."
	elseif q=='look blanket' then
		return "it's a cozy green blanket."
	elseif q=='talk to yourself' then
		return "blah blah blah."
	elseif q == 'use red wine' then
		return "not here, not now."
	end

	-- no success
	responses={
		"that doesn't work, i'm afraid.",
		"sounds good, but no.",
		"you try, but don't succeed.",
		"maybe try something else instead.",
		"there's no need for that."
	}
	return responses[flr(rnd(#responses)+1)]
end

function store_state()
	wipe_store()
	dset(0,scene)
	dset(1,player_x)
	dset(2,player_y)
	
	local idx=3
	for i=1,#inv do
		dset(idx,inv[i][2])
		idx+=1
	end
	for i=1,#world do
		dset(idx,world[i][2])
		idx+=1
	end

	dset(63,1) -- used to determine if a save game is available
end

function restore_state()
	scene=dget(0)
	player_x=dget(1)
	player_y=dget(2)

	local idx=3
	for i=1,#inv do
		inv[i][2]=dget(idx)
		idx+=1
	end
	for i=1,#world do
		world[i][2]=dget(idx)
		idx+=1
	end

	refresh_inventory()
	refresh_score()
end

function save_game()
	store_state()
  	action_state=4
	response_text='game saved!'
end

function restore_game()
	if dget(63)==0 then
		action_state=4
		response_text='no save game found!'
	else
		restore_state()
		music(-1)
		if scene==1 then
			init_scene1()
		end
		if scene==2 then
			init_scene2()
		end
		if scene==3 then
			init_scene3()
		end
		if scene==4 then
			init_scene4()
		end
		action_state=4
		response_text='game restored!'
	end
end

function restart_game()
	wipe_store()
	action_state=4
	response_text='game restart! note: save game is erased as well.'
	start_state()
	refresh_score()
	refresh_inventory()
	init_scene1()
end

-- wipe all currently stored data
function wipe_store()
	for idx=0,63 do
		dset(idx,0)
	end
end
