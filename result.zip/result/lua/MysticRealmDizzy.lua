--mystic realm dizzy
--by sophie houlden

scroll=128
img="mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbbbmbmbmbmbbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbggbnbnbnbnbbmmhhhgmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgnnnnnnfffbbmhhhhhhhhmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgggnffnnfnfbhhhhhggmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgnnnnnffffbbhhhhhhhhhhhhgmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhbgnggnnfnnfbbhhhhhhhhhhhhhhhggmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhgggbggnnffffffbbggggggggggggggggmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgngnnfnnfnfbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbnnnnnfffnfbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhggmmmmmmhhhhhhhhhhhghhmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbnggnnnffnfbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbggnnffffffbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhggmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgnnnnfnnfnfbmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhhhhhhhhhhhhhhhhhhgggggghggggggmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgnggnfffffbbmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhhhhhgggggggggggggghggghhhhgggggmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbnnnnnffnnfbbmmmmmmmmmmmmmmmmmmmmmmmmmmmhgggggggggggggggggggggggggggggggggggmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgggnnnffffbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhhmmmmmmmmmmmmmmmmmmmmmmmmbgnnnnnnnffbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhhhhhhhhhmmmmmmmmmmmmmmmmmmbgnggnnfffnfbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhhhhhhhhhhhhhhhhhhhhmmmmmmmmmmmmbggnnnnfnnfbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhhhhgggggggggggghhhhhhhmmmmmmmmmbggnnnfffffbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhhhhhhhhggggggggggggggggggggggghgggmmmmmmbgngnffnfnnfbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmhhgggggggggggggggggggggggggggggggggmmmmmmmmbgnnnnnffffbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgggnfffnnfbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgnnnffffffbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgnggnnnfnnfbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbggnnnnffffbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbggnnffnnfnfbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbggnnnfffffbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgnggnnfnnffbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbggnnnfffffbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbgggnnnnfnnfbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbbbbbbbbbbbmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmbggnnnnffffbbmmmmmmmmmmmmmmmmmmmmmmmmbbbbbbbbbbbbbbbbbbbbbbbbmmmmmmmmmmmmmmmmmmmmbbblllllllllllbbbbbbbbbbmmmmmmmmmmmmmmmmmmmmmmmbgnnnnnfnnfbbmmmmmmmmmmmmmmmmmmmbbbbbllllllllllllllllllllllllbbbmmmmmmmmmmmmmmmbbllllllllllllllllllllllllbbbbbbmmmmmmmmmmmmmmmmmbgnggnffffffbmmmmmmmmmmmmmbbbbbbllllllddlddlllllllllldddddddllllbbbbbmmmmmmmmmmllllllllllllllllllddddddllllllllbbbbmmmmmmmmmmmmmbgnnnnnffffbbmmmmmmmbbbbbblllllllllllllllllllllllllldllldllllllllllddbbbbbbmmmmlllllldlddddlllddllllllddddddlllllldbbbbmmmmmmmmmbgggnnnfnnfbbmmmmbbbllllllddlllllllllllllldddddddddlldddddddddlllllldddddddbbmmdllldlddldddlldddlldddlllddlllddddddllllbbmmmmmmmbgnnnnffffffbbbbblllllldllllldlllllllllldddddllllllblllllllddllddddddddddddddbbldddlddlddlllddddddldbbddddlddddddddddddllbbbmmmmbggnnfnffffblllllllllllllddddllllldddddddlllllllbbbhbbbdddllllddddddddddddddddddddlllddddddddddddbddbbdllllldddbllddddddppllbbbbbggnfffffbbldllllddllllddddlllldddllllllldddddbbhhhhhhhbblddddddddddlddddldddddllddddddllldddddddbddbbbddbddddbbddddddppdddbbdddbbbbffbbblllllddllldlllddllldlddddddlldddddddbhhhhhhhhhhhbdddddddddddddddddddddddlllldddddddbbddbbbblbbbblbbddbdbddddppddddbbdddddddbbllllddllllddlllddddddlllddlddlllllllllbhhhhhhhhhhhhgbddddddddddddddddddddddlllddddbddbllbdbfbbbbbbdbbbdbdlbddjjjbbddblfbddbbbblldlllllllldddlldddddlllldddlddddllldddbhhhhhhhhhhhhhhgbddldddddldddddddddddllddddddbblbbddbbdbldbbdbldbbddbbbjbjdlbbdbdfbbbllllddddlllldlllllddllddlddddddlllllllllllbhhhhhhhhhhhhhhhggbdddddddddddddddddddbddddbbbbllbbdbldfbddffbddbbbbdbbjbdbbdbbbbbblllllllllllddlllllllllldddddllllllllllddddddbhhhhhhhhhhhhhhhhgggbddddddddddddddddddbbddbbldbbbddbbbdbbbdlfblddfbbdbbjblbbfbbbbllllldllldddllldddddddddddlldlldddddlldddddddbhhhhhhhhhhhhhhhhhgggnbddddddddddddddddbblbbbbdfblbfbblbbbbdlbbbddbfbdbbbbldfbdbblllldddlddddllllddllddllllllddddddddddllddddddbhhhhhhhhhhhhhhhhhhhggnnbdddddddddddddddbddbbbdlbbbddbdbbbbdllbfbldbbbbbdbbddbbblllddllllllddllllllldllllldddddddddddddddddddddbhhhhhhhhhhhhhhhhhhhhgggnbdddddddddddddddblbbbbbbbfbdbflbbbbdddfbbdbfdbbbdbbdbblllddllllllldddddlllllldlldlldddddddddddlldddddddbhhhhhhhhhhhhhhhhhhhhgggnnbddddddddddddddbbbbbbbbbbbbddlbbbbbbbdbbbbffbbddbbbllllddddddllllllddllllldddddddddddddddddddddddddddbhhhhhhhhhhhhhhhhhhhhhhgggnnbdddddddddddddbbbbdbbbbbbbbbbbbbbbbbbbbbbbbbbbdbblllddlldddllddddddddddddddddddddddddlllddddddlddddbhhhhhhhhhhhhhhhhhhhhhhhgggnnbdddddddddddddbllllllllllbbbblldbbbbbbbbbbbdbbbldlllllllllldlddllllddddddllddddddllddddddddddlldddbhhhhhhhhhhhhhhhhhhhhhhhgggggnnbddddddddddddddllllldllllllllllllbbbbpppppbbbldddllddddlllldllddlddllddddddddddldddddddddddddddddbhhhhhhhhhhhhhhhhhhhhhhhghgggnnbdddddddddddddllldddldlllldddlllllllpppppppppddddddldddlddddddddddddddddddddddddddddddlddddddlddbhhhhhhhhhhhhhhhhhhhhhhhhhggggnnnbddddddddfdddddddlllllllllllllllllldjpppppppppddddldddddddlldddllddddddldddddddddddllddddddddddbhhhhhhhhhhhhhhhhhhhhhhhhhgggggnnbdddfdddffdddddlldddlddddddlllllllllldpppjpppppppdddddlldddddlddddddddddddddddddddddddddddddllbhhhhbbhhhhhhhhhhhhhhhhhhhhgggggnnbdddddddddddllldlllldddddlllllldddlllldpppppppppjpdddddddlldddddddddllddddddldddddddddddddddddbhhbbgghhhhhhhhhhhhhhhhhhhhhgggggnnbdddddddddddddddlllllldlllllddddddlllddppppjpppppppddddddddlldddlllddddddddddlddddddddddddddbhhbnghhhhhhhhhhhbbbhhhhhhhhggggggnnbdddfffdddfdlldddlllllllldddddddldddddddppppppppppppddfdddddddddddddddllldddddddddddddddddddbhhghbbbhhhhhhhhhgggbbhhhhhhggggggnnnbddddddddfdlldddddddddlllddddddlllldldddppppppjppjpppppdfdddddddddddddddddddddddddddddllddbhhhhbhhhbhhhhhhhhhhggnbhhhhhggggggnnnbddddddffdddddddddddlldddddlllddddddddddddppjppppppppppppfddddddddddddddddddddddddddddddddbhhhbbhhhbhhhhhhhbbbhhgbhhhhhhgggggnnnbdddddddddddddddddddddddddllllldddllldlddddppjppppppjppppppdddfddddddldddddddddddlllddddddbhhhbhhhhgbhhhhhbhhhbhhghhhhhhgggggnnnnbddddddddddddllddddddlddddlldddddldddddddddpppppjpppppjjppppdddddddddddddlldddddddddddddbhhhhbbbhhgbhhhhhbhhhbhhhhhhhhhggggggnnnbddfdffffdddddddddddlldddddddddddddldddddddpppppppppjjpjppjpjjfdddddddddllddddddddddddddbhhhhbbbhhgbhhhhhbhhhgbhhhhhhhhggggggnnnbdddddddfdddddddddddddddddddddddddldddddddddpjppjpppppppjppjjpppddffddddddddddddddddddddbhhhhbbbhhgbhhhhbbbbhgbhhhhhhhhggggggnnnbfddddddddldddddddddddddddddddddddddddddddfddpppjjpppppppppjppppppddddddddddddddddddddfdbhhhhbhhhhgbhhhhbbbbhgbhhhhhhhhhgggggnnnbddddddddddddddddddddddddldddddddddlllddddddddppjppjjjjpjpjjjppjjjjpppfdddffddddfddfdddbhhhhhbhhhgbnhhhgbfbhhgbhhhhhhhhgggggggnnnbdddfdddddddddddddddddddddddddddddddddddddddddpppjppppjjpjpppjjjpppppjjjfdddddddddddddbhhhhhhbggbnghhhgbhhhhgbhhhhhhhhhggggggnnnbddddddddddddddddddddddddddddddddddldddddddddddpppppjjpppjjpppppppppjjppppdfdfddfddffbbhhhhhhhbbbbbbbhgbhhhggbhhhhhhhhgggggggnnnbdddddddddddddddddddddddddddddddddddddddddddddddppjjjpppppjjjjppppjjpppjjjpjdddffdbbbgbhhhhhhhhhbhhhhbhhbgggbnhhhhhhhhgggngggnnfbdfffdffdddddddllddddddddddddddddddddddddddddddddpppjjppjjjppppjjjppjjpjjpjjjjpddbobgbhhhhhhhhhbhhhhhhhhhbbbnhhhhhhhhhgggnnggnnfbddfdfdddddddddddddddddddddddddddddddddddddddddddppppppjjpppjjjjjjjjjjpjpppppjjjboobnbhhhhhhhhbhhhhhhhhhhhhhhhhhhhhhhhhhggnfgnnfbddddffdddddddddddddddddddddllddlddddddddddddddddfpppppppppjjpjjjjppppjjjppppjpboooobbhhhhhhhhbhhhhhhhgghhhhhhhhhhhhhhhhhggfbnnfbdddddfddddddddddddddddddddddddllddddddddddddddddddppjjppjpppppppjppppjppppjjpjbooiocbhhhhhhhbhhhhhhhhgghhhhhhhhhhhhhhhhhhgnfbnfbddfdddddddddddddddddddddddddddddddddddddddddddddddpppppjjpppppppjjjppppjjjppjjbiiiibhhhhhhhhbhhhhhhhggghhhhhhhhhhhhhhhhhhggnfbbbddfddddddddddddddddddddddddddddddddddddddddddddddddppppjjjjjjpjjjjjjjjjjjjjjjjpbccibhhhhhhhhbhhhhhggggghhhhhhhhhhhgnhhhhhggfbboobbddddfdddddddddddddddddddddddddddddddddddddddddddfppjjjjjpppjjpppjpjjpppppjjjboocbbhhhhhhhhhbhggggggnghhhhhhhhhhhhgnnhhhgfoooooiibffffdddddddddddddddddddddddddddddddddddddddddddddppjppppjjppppppjpppppjjjjbooiicbhhhhhhhhhhbbbbbbnghhhhhhhhhhhhhhgnnhgfoooiiiiiibfddddddddddddddddddddddddddddddddddddddddddddddddpppppjppppppppjppjjjjppboocioibhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhggnnfooiiiiccccbdddddddddddddddddddddddddddddddddddddddddddddddddpppppjpjjjjjpjjjpjpppppboibooibhhhhhhhhhbgggghhhhhhhhhhhhhhhhhgggbnboiiiiccbbbbbffdddddddddddddddddddddddddddddddddddddddddddddddpppppjjppppjjjpjjjppjbiobooiiibhhhhhhhhbbbbbbbbbbbbbbbbghhhhhggggboiiiiccbccooobbdddddddddddddddddddddddddddddddddddddddfdddddddpjppjppppjjjppppjjjjjboiboiibbbhhhhhhhhbhhggggggggggnnbghhhhggggbooiicccccooooooodddddddddddddddddddddddddddddddddddddddddddddddfpjjjpppjjppppppjjppboocbiibbcbhhhhhhhhhbhhhhhhggggbbbbhhhhhggggbciicccciiooooooiddddddddddddddddddddddddddddddddddddddddddddddddpppppjjjjjjjpjjppppboocbbbbccbhhhhhhhhhbbbbbbbbbbbbbbhhhhhgggggbccibcociiiooooiidddddddddddddddddddddddddddddddddfdddddddddddddddpppjjjjjjjpjjjppppboicbcioooobhhhhhhhhhbbbbccccccbbhhhhhhggggggbcbccoiiiiooiiiidddddddddddddddddddddddddddddddddfdddddddddddddfdppjjjjjpppjjjjppppboicccooiiibhhhhhhhhhbbccccccbbhhhhhhhgggggggnbccooiicioooiiidddddddddddddddddddddddddddddddddddddddddfdddddfddpjjjppppppjjjjjppbiiccooiccccbhhhhhhhhhhbbbbbbhhhhhhhhhggggggnnbccoiicbiiooiiidddddddddddddddddddddddddddddddddddddddddfddddddfdpppppppppjjjjjjjjbiiiiioccccccbhhhhhhhhhhhhhhhhhhhhhhhgggggggnfbccoiicbiiooiiidddddddddddddddddddddddddddddddddddddddddddddfddffdppppppjjjjjjppjjpbcccccccccccbhhhhhhhhhhhhhhhhhhhhhggggggggnnfbbcooicbiioiiicdddddddddddddddddddddddddddddddddddddddddddddfdddfdpjjjjjjjjjppppppppbcccccccccccbhhhhhhhhhhhhhhhhhhggggggggnnnnbccccoicbciiiiccdddddddddddddddddddddddddddddddddddfdddddddddddddfdfpjjjjjjppppppppjjpbbbccbbbbbbbgghhhhhhhhhhhhhhggggggggnnnnnfbccbccicbiicccccddddddddddddddddddddfdddddddfddddddddfdddddfdddffdfdjjpppjjpppppppjppppppbbbbbbbjjbggghhhhhhhhhgggggggggnnnnnnfffbcobcbbicccccccddddddddddddddddddddfddddddddddddddddddddddfddfddffdpppppjjpppjjjjjjpppppppjjjjpppjbbgggggggggggggggggnnnnnnffffbbciobiiicccccccddddddddddddddddddddddddddddddddddddddddddddddfdddfffpppppjjjjppppjjjjpppjjjjppppppjjbnngggggggggggnnnnnnnnfffbbbjbciioiccccccccdddddddddddddddddddddddddddddddddddddddfdddfdddddddfdppppjjjppppppjjjjjjjjjjjjjpppppjjbbbnnnnnnnnnnnnnnffffbbbjjjppbcciicccccccbddddddddddddddddddddddddddfddddddffdddddfdddddfddffddfppjjppppppppjjjjjjjpppppjjpppppbbnnbbbbbnnfffffbbbbbbffbbjjjjjbbcccccccbbpdddddddddddddddddddddddddddddddddddddddddddfddddddffffdjjppppppppjjjjjjppppppppjjjpjbooggnffibbbbbbbbjbnnnnffiibjjjjjjbbbbbbbpppdddddddddddddddddddddddddddddddddddddfdddddddfffdddfdddppppppppjjjpppppppppppppjjjjboocgggfiiibjjjjjjpboggggfcicbjjjpppjjpjppppjdddddddddddddddddffdddddddddffdddddffdddfffddfdfddffdfdfppjjjjjjjjjjppppppppppjjjjpboioooooiicbjjjjppboocgnnfiicbjjppppppjjpppjjdddddddddddddddddddddddddddddddddddfddddddfdddfdddddfddfjjjjjjjpppjjppppppppppjjjppbiiiiiiiiccbjjppppboioooiiicccbjjpppjjjjjjjjj"
function drawstring(s,x,y,w)
 xx=x yy=y
 for i=1,#s do
  pset(xx,yy,strtocol(sub(s,i,i)))
  xx+=1
  if (xx>=x+w) yy+=1 xx=x
 end
end

function strtocol(s)
 for i=1,16 do
  if (s==sub("abcdefghijklmnop",i,i)) return i-1
 end
 return 0
end

--player stuff
px=0
py=0
fx=0
fy=0
pg=0
pf=false
dead=false
gametitle = true
fadeout=-1
tictoc=false
tictoc2=0

stars=0
score=0
lives=5

airtime=0
stuntime=0

doravar=0
denzilvar=0
dylanvar=0
trollvar=0
dozyvar=0
grandvar=0
zaksvar=0
mermaidvar=0
saveddaisy=false

--checkpoint
cx=900
cy=0
cgx=0
cgy=0
checkinv3={0,0,0}

gameover=false
startgameover=false
gamewon=false


woff=0
yoff=0

kx=0
ky=0


texts={"","","","","","","","","",""}
textx={0,0,0,0,0,0,0,0,0,0}
texty={0,0,0,0,0,0,0,0,0,0}
textw={0,0,0,0,0,0,0,0,0,0}
texth={0,0,0,0,0,0,0,0,0,0}
textcols={0,0,0,0,0,0,0,0,0,0}

placename=""
placetime=0
function showplace()
 placename=""
 placetime=1.5
 
 if woff==0 then
  if (yoff==0) placename="zaks' chamber"
  if (yoff==1) placename="zaks' dark tower"
  if (yoff==2) placename="zaks' dark castle"
  if (yoff==3) placename="zaks' horrid dungeon"
 end
 if woff==1 then
  if (yoff==0) placename="treetops"
  if (yoff==1) placename="yolkfolk villiage"
  if (yoff==2) placename="pleasant woodland"
  if (yoff==3) placename="daisy's prison cell"
 end
 if woff==2 then
  if (yoff==0) placename="treetops"
  if (yoff==1) placename="canopy"
  if (yoff==2) placename="the shore"
  if (yoff==3) placename="dark waters"
 end
 if woff==3 then
  if (yoff==0) placename="tower view"
  if (yoff==1) placename="shining tower"
  if (yoff==2) placename="the castle moat"
  if (yoff==3) placename="murky waters"
 end
 if woff==4 then
  if (yoff==0) placename="cloudy sky"
  if (yoff==1) placename="castle gardens" 
  if (yoff==2) placename="the grand hall"
  if (yoff==3) placename="castle dungeon"
 end
 if woff==5 then  
  if (yoff==0) placename="rainy sky"
  if (yoff==1) placename="castle garden entrance"
  if (yoff==2) placename="castle hallway"
  if (yoff==3) placename="dank cells"
 end
 if woff==6 then
  if (yoff==0) placename="secret tower"
  if (yoff==1) placename="castle gallery"
  if (yoff==2) placename="castle well"
  if (yoff==3) placename="cave pool"
 end
 if woff==7 then
  if (yoff==0) placename="top of the ruins"
  if (yoff==1) placename="ancient ruins"
  if (yoff==2) placename="base of the ruins"
  if (yoff==3) placename="dark cavern"
 end
 if (yoff<0) placename="the sky"
 
end

itemname=""
itemtime=0
function showitem(t)
 itemname=""
 itemtime=1.5
 
 if(t==3)itemname="rusted key"
 if(t==4)itemname="fancy certificate"
 if(t==8)itemname="a snorkel"
 if(t==9)itemname="a sharp axe"
 if(t==10)itemname="a treasure chest"
 if(t==11)itemname="trendy umbrella"
 if(t==12)itemname="loaf of bread"
 if(t==13)itemname="a black cat"
 if(t==14)itemname="bag of rubbish"
 if(t==15)itemname="pristine bucket"
 if(t==16)itemname="gross dungeon apple"
 if(t==17)itemname="a slimy frog"
 if(t==18)itemname="ice cold milk"
 if(t==19)itemname="a heavy rock"
 if(t==21)itemname="enchanted ring"
 if(t==22)itemname="easter egg"
 if(t==23)itemname="a sharp dagger"
 
 if (itemname=="")itemtime=0
end

function actorhere(x,y,ac)
 for i=1,#actors do
  if x==actors[i].x and
     y==actors[i].y and
     ac==actors[i].t then
   return true
  end
 end
 return false
end

function goupdate()
for i=1,#actors do
 actor=actors[i]

 actype=actor.t
 acx=actor.x
 acy=actor.y
 aca=actor.a
 acb=actor.b
 acc=actor.c
 acwoff=actor.woff
 acyoff=actor.yoff
 
 --stars
 if actype==20 then
  if (aca==1) acx=9999
  if getdist(px,py-3,acx+4,acy+4)<7 then
   sfx(56)
   stars+=1
   score+=300
   acx=9999
   aca=1
  end
 end

 --carried objects
  if actor.p then
   if aca==1 then
    acx=px
    acy=py
    acwoff=woff
    acyoff=yoff
   end
  end


 if acwoff==woff and
    acyoff==yoff then

  --fire
  if actype==1 then
   if zaksvar<2 then
    for k=0,3 do
     sparkcol=7
     if (rnd()>0.5) sparkcol=9
     if (rnd()>0.5) sparkcol=10
     addpart(1,acx+2+(rnd()*4),acy+8,sparkcol,acb)
    end
   end
  end


  --spider/bee
  if (actype==2 or actype==30) and texts[1]=="" then
   if acb==false then
    acx+=0.5
    if (actorhere(acx,acy,-27))acb=true
   else
    acx-=0.5
    if (actorhere(acx,acy,-28))acb=false
   end
   
   acc=0
   if(actype==30) acc=sin(time+acy*0.2)*5
   
   if getdist(px,py,acx+4,acy+8+acc)<8 then
    dienow(true)
    if (actype==2) addtext("spider bites are bad!")
    if (actype==30) addtext("oh dear, stung by a bee!")
   end
  end
  
  --sprinkler
  if actype==5 then
   for k=1,2 do
    dropcol=7
    if (rnd()>0.5) dropcol=13
    addpart(2,acx+2+(rnd()*4),acy,dropcol)
   end
  end


 end

 

 actor.t=actype
 actor.x=acx
 actor.y=acy
 actor.a=aca
 actor.b=acb
 actor.c=acc
 actor.woff=acwoff
 actor.yoff=acyoff


end
--keep these outside the loop!
respawning=false

end

function flr8(v)
 return flr(v/8)
end

function godraw()
for i=1,#actors do
 actor=actors[i]
 actype=actor.t
 acx=actor.x
 acy=actor.y
 aca=actor.a

 if actor.woff==woff and
    actor.yoff==yoff then
  
  if actype==71 then
   spr(71,acx,acy,1,1,tictoc2>4)
  end

  --switch
  if actype==99 then
   actor.b=trollvar<2
   ospr2(110,acx,acy,actor.b,1,true)
  end
  
  --switch step
  if actype==88 and trollvar==2 then
   spr(252,acx,acy)
   mset(flr8(acx),flr8(acy),24)
  end
  
  --watergate
  if actype==116 then
   if mermaidvar<3 then
    spr(116,acx,acy)
   else
    mset(flr8(acx),flr8(acy),87)
    spr(87,acx,acy)
   end
  end
  
  --spider
  if actype==2 then
   sframe=23
   if (tictoc2>4) sframe=102
   ospr2(sframe,acx,acy,actor.b,1,true)
  end
  --bee
  if actype==30 then
   bframe=30
   if (tictoc and texts[1]=="") bframe=57
   ospr2(bframe,acx,acy+actor.c,actor.b,1,false)
  end

  --pickupable
  if actor.p and aca==0 then
   ospr2(actor.b,acx,acy,false,1,false)
  end
  
  --star
  if actype==20 and aca==0 then
    ospr2(241,acx+cos(time*0.5+acy*0.1),acy+sin(time+acy*0.1)*2,false,1,false)
  end
  

 end
end
end


function getdist(ax,ay,bx,by)
 a=ax-bx
 b=ay-by
 a*=0.01
 b*=0.01
 a=a*a+b*b
 a=sqrt(a)*100
 --clamp big numbers
 if(a<0) return 32767

 return a
end


function _init()
 music()
 
 for x=0,160 do
 for y=0,55 do
  tilenum=mget(x,y)
  
  if tilenum==116 then
   --watergate
   addactor(116,x,y,82)
  end
  if tilenum==71 then
   --waves
   addactor(71,x,y,mget(x,y-1))
  end
  if tilenum==110 then
   --switch
   addactor(99,x,y,77)
  end
  if tilenum==252 then
   --switch step
   addactor(88,x,y,77)
  end
  if tilenum==27 then
   --mob control
   addactor(-27,x,y,mget(x,y-1))
  end
  if tilenum==28 then
   --mob control
   addactor(-28,x,y,mget(x,y-1))
  end
  if tilenum==23 then
   --spider
   addactor(2,x,y,mget(x,y-1))
  end
  if tilenum==57 then
   --bee
   addactor(30,x,y,mget(x,y-1))
  end
  if tilenum==16 then
   --player
   px=x*8+4 py=y*8
   mset(x,y,13)
  end
  if tilenum==241 then
   --star
   addactor(20,x,y,mget(x,y-1))
  end
  if tilenum==253 then
   --fire
   addactor(1,x,y,237)
  end
  if tilenum==1 then
   --key
   addactor(3,x,y,0,true,1)
  end
  if tilenum==2 then
   --cert
   addactor(4,x,y,0,true,2)
  end
  if tilenum==4 then
   --snorkel
   addactor(8,x,y,77,true,4)
  end
  if tilenum==9 then
   --axe
   addactor(9,x,y,118,true,9)
  end
  if tilenum==63 then
   --treasure
   addactor(10,x,y,13,true,63)
  end
  if tilenum==5 then
   --umbrella
   addactor(11,x,y,0,true,5)
  end
  if tilenum==3 then
   --bread
   addactor(12,x,y,0,true,3)
  end
  if tilenum==6 then
   --cat
   addactor(13,x,y,0,true,6)
  end
  if tilenum==10 then
   --rubbish
   addactor(14,x,y,0,true,10)
  end
  if tilenum==7 then
   --bucket
   addactor(15,x,y,77,true,7)
  end
  if tilenum==8 then
   --apple
   addactor(16,x,y,77,true,8)
  end
  if tilenum==11 then
   --frog
   addactor(17,x,y,0,true,11)
  end
  if tilenum==59 then
   --milk
   addactor(18,x,y,0,true,59)
  end
  if tilenum==53 then
   --rock
   addactor(19,x,y,0,true,53)
  end
  if tilenum==54 then
   --ring
   addactor(21,x,y,87,true,54)
  end
  if tilenum==46 then
   --egg
   addactor(22,x,y,13,true,46)
  end
  if tilenum==26 then
   --dagger
   addactor(23,x,y,0,true,26)
  end
  if tilenum==242 then
   --sprinkler
   addactor(5,x,y,0)
  end
 

 end
 end
end

actors={}
function addactor(t,x,y,replacetile,p,s)
 a={}
 a.t=t
 a.x=x*8
 a.y=y*8
 a.a=0
 a.b=0
 a.c=0
 a.p=p--pickup
 if (s) a.b=s--sprite

 if (t==99) p=true
 a.woff=flr((x*8)/128)
 a.yoff=flr((y*8)/112)


 --mobs
 if t==2 or t==30 then
  a.b=false
  a.d=0
 end


 add(actors,a)

 if (replacetile != -1) mset(x,y,replacetile)
end


parts={}--particles
function addpart(t,x,y,a,b,c,d)
 p={}
 p.t=t
 p.x=x
 p.y=y
 p.a=a
 p.b=b
 p.c=c
 p.d=d
 p.life=10

 if t==1 then
  --spark
  p.fx=rnd()-0.5
  p.fy=(rnd()-1.5)*0.5
  if(b==1) then
   p.y-=8
   p.fy=(rnd()*1.5)*2.5
  end
  p.life=rnd()*15
 end
 if t==2 then
  --drop

  p.fx=(rnd()-0.5)*0.5
  p.fy=0
  p.life=50
  p.c=a
 end


 add(parts,p)
end

function doparticles()
clip(0,16,127,127)
for i=1,#parts do
part = parts[i]
if part then
  --sparks
 if part.t==1 then
  part.x+=part.fx
  part.y+=part.fy
  part.fy-=0.1
  part.fx*=0.9
  part.life-=1*(1+part.fx)
  if(part.life<3)part.a=5
  pset(part.x,part.y,part.a)
 end

 --drops
 if part.t==2 then
  lastx=part.x
  lasty=part.y
  part.x+=part.fx
  part.y+=part.fy

  if solid(part.x,part.y) then
   part.fy*=-0.3
   part.fx=(rnd()-0.5)*5*part.fy
   part.x=lastx
   part.y=lasty
   if solid(part.x,part.y+4) then
    while solid(part.x,part.y)==false do-- and
     part.y+=1
    end
   end
   part.y-=1
   part.life*=rnd()
  end

  part.fy+=0.1
  part.fx*=0.9
  part.life-=1

  line(lastx,lasty,part.x,part.y,part.a)
 end

 
 if part.life<0 then
  del(parts,part)
 end

end
end
clip()
end

inv3={0,0,0}
invhighlight=1

frame=1
anitime=0

stun={48,49}
idle={32,32,33,33}
walk={34,35,36,37}
jump={16,17,18,19,20,21,22,38}
stilljump={52,52,51,51,50,50,32,32}

function pickup(i)
 

 if actors[i].t==17 and dylanvar==2 then
  addtext("  ribbit",3,40,114,43,11)
   
  return
 end

 if (inv3[invhighlight]!=0) dropitem()
 inv3[invhighlight]=i
 actors[i].a=1
 ancl=false
 showitem(actors[i].t)
 return false
end

time=0
timedelta=0.033
function _update()
 tictoc=not tictoc
 
 if (tictoc and texts[1]=="") tictoc2+=1
 if (tictoc2>8) tictoc2=0

 time+=timedelta
 if(fadeout>=0)return

 if(gameover) return

 if gametitle then
  if btn"4" or btn"5" then
   sfx(51)
   fadeout=16
  end
  return
 end

 if(dead) respawnnow()

 goupdate()
 
 
 
 --input
 if texts[1]=="" and pg==1 and stuntime<0 then
  if(btn"0") fx-=0.2 pf=true
  if(btn"1") fx+=0.2 pf=false
 end

 if(stuntime>=0)stuntime-=1
 g=collidesfull(px,py+1,fy>=0,py)
 if fullpmfcheck(5) and fy>=0 then
  g=true
  fy=0.2
 end
 if g then
  --grounded
  checkpointnow(px,py,true)

  if (pg!=1)sfx(54)
  pg=1
  if(airtime>=20) stuntime=30

  if btnp"4" and texts[1]=="" and stuntime<0 then
   fy=-3.1
   sfx(53)
  end
 else
  --not grounded
  pg=0
  fy+=0.2
 end

 --forces
 if pg==1 and (btn"0"==btn"1" or texts[1]!="" or stuntime>0)then
  if fx>0 then
   fx=max(fx-0.6,0)
  else
   fx=min(fx+0.6,0)
  end  
 end
 fx=mid(-1.5,fx,1.5)
 fy=mid(-5,fy,3)
 
 if (fy>=3) airtime+=1
 if (fy<=0) airtime=0
 

 --move player
 moveplayer()


 ancl=true --action not claimed

 actionbtn=btnp"5"
 if (texts[1]!="") actionbtn=false

 
 --pick up actors
 if actionbtn and pg==1 and ancl then
 for i=1,#actors do
  actor = actors[i]
 if pbox(px,py,actor.x,actor.y,8,16) then

   if actor.t==99 then
    addtext("dizzy struggles with the switch, but is not strong enough to move it",0,30,80,70,35)
    addtext("only i can open the way to zaks' chamber",3,50,20,70,22)
    ancl=false
   end

   if actor.p and actor.a==0 and ancl then
    ancl=pickup(i)
   end


 end
 end

  if ancl and inv3[invhighlight]!=0 then
    dropitem()
  end
 end



 --interactions
 ptile1=pmsget()
 
 
 if actionbtn and pg==1 and ancl then
  if ptile1==115 then
   addtext("dizzy finds a small worm perched on a brick",0,30,80,70,28)
   addtext("have you seen daisy, small worm?",6,6,60,50,22)
   addtext("...",3,70,62,20,11)
   addtext("...",3,70,64,20,11)
   addtext("...",3,70,66,20,11)
   addtext("she's probably in another dungeon.",3,52,68,65,22)
   ancl=false
  end
  
  --dozy
  if ptile1==39 then
   if dozyvar==0 then
    addtext("dozy, wake up!",6,30,30,70,11)
    addtext("dizzy tries to wake dozy, but nothing will get him up",0,30,80,70,28)
    dozyvar=1
   end
   if dozyvar==1 then
    addtext("it looks like dozy is sleeping on something...",0,30,80,70,22)
    addtext("but dizzy can't move dozy to get at it",0,30,80,70,22)
   end
   if dozyvar==2 then
    addtext("dozy has gone back to sleeping peacefully",0,30,80,70,22)
   end
   ancl=false
  end
  --daisy
  if ptile1==61 then
   if stars<30 then
    addtext("daisy has been petrified by a spell!",0,30,20,70,28)
    addtext("dizzy will need to find all 30 stars to release her!",0,30,20,70,28)
    
   else
    addtext("all the stars dizzy has collected begin to shine brightly!",0,30,20,70,34)
    addtext("oh dizzy! you saved me!",14,40,32,60,16)
    addtext("i'm so glad you're ok daisy!",6,10,30,50,22)
    
    
    score+=5000
    gamewon=true
    startgameover=true
    saveddaisy=true
   end
   ancl=false
  end
  --denzil
  if ptile1==60 then
   if denzilvar==0 then
    addtext("hi denzil",6,10,30,50,11)
    addtext("yo dizzy! what's up?",1,40,32,60,16)
    addtext("i'm looking for a way to rescue daisy",6,10,34,70,22)
    addtext("i can't help you there diz, i'm just here chilling",1,40,36,70,28)
    denzilvar=1
   end
   if denzilvar==1 then
    addtext("ancient ruins are so cool, totally my scene.",1,40,38,70,28)
    addtext("i doubt they could be any cooler, right diz?",1,40,40,70,28)
    addtext("if you could make it any cooler, i'd gladly give up this cool thing i found.",1,40,42,70,40)
   end
   if denzilvar==2 then
    addtext("thanks dizzy, now i'm cooler than ever!",1,40,30,70,22)
   end
   ancl=false
  end
  --dylan
  if ptile1==55 then
   if dylanvar==1 then
    addtext("hey man, have you found my green buddy yet?",13,50,30,70,22)
    
   end
   if dylanvar==0 then
    addtext("hello dylan",6,10,30,50,11)
    addtext("hey man, have you seen this place?",13,50,30,70,22)
    addtext("it's so green! i really dig it",13,50,32,70,16)
    addtext("i had a green buddy here with me before too",13,50,34,70,22)
    addtext("but they went somewhere",13,50,36,70,16)
    addtext("a green buddy? ok i'll look for them for you.",6,10,38,70,22)
    dylanvar=1
   end
   if dylanvar==2 then
    addtext("ahh man, everything is like, perfect!",13,50,30,70,22)
   end
   
   ancl=false
  end
  
  --grand dizzy
  if ptile1==40 then
   if grandvar==1 then
    addtext("have you found my key yet, young dizzy?",13,50,30,70,22)
   end
   if grandvar==0 then
    addtext("ah young dizzy! i need some help!",13,50,30,70,22)
    addtext("what is it grand dizzy?",6,40,90,50,22)
    addtext("i've lost the key to my house, i'm locked out!",13,50,30,70,22)
    addtext("i'll find your key for you!",6,40,90,50,22)
    grandvar=1
   end
   if grandvar==2 then
    addtext("thank you dizzy, you're such good egg.",13,50,30,70,22)
   end
   ancl=false
  end
  
  --dora
  if ptile1==56 then
   if doravar==0 then
    addtext("hello dora, how are you?",6,10,55,60,16)
    addtext("oh dizzy, it's terrible!",2,50,60,70,16)
    addtext("what is?",6,10,66,60,11)
    doravar=1
   end
   if doravar==1 then
    addtext("i want to go into the garden...",2,50,60,75,16)
    addtext("but it's raining! i'll get drenched!",2,50,62,77,16)
   end
   if doravar==2 then
    addtext("thank you dizzy!",2,50,60,70,11)
   end
   
   ancl=false
  end
  
  --zaks
  if ptile1==125 then
  
   if zaksvar<1 then
    addtext("the evil wizard zaks cackles at dizzy, unafraid!",0,30,20,70,22)
    addtext("haha dizzy, i shall keep daisy trapped forever!",2,10,30,70,22)
   else
    addtext("when i get my magic back dizzy, watch out!",2,10,30,70,28)
   end
   
   ancl=false
  end
  
  --mermaid
  if ptile1==94 or ptile1==62 then
   if mermaidvar==1 or mermaidvar==2 then
    addtext("fair egg, have you found my treasure yet?",13,10,30,70,22)
   end
   if mermaidvar==0 then
    addtext("oh fair egg, woe is me!",13,10,30,70,16)
    addtext("the evil wizard zaks took my treasure!",13,10,32,70,22)
    addtext("if you bring back my treasure, i will give you something special;",13,10,34,70,40)
    addtext("an enchanted ring that removes zaks' magic power!",13,10,36,70,28)
    mermaidvar=1
   end
   if mermaidvar==3 then
    addtext("thank you, fair egg! i love this hat!",13,10,30,70,22)
   end
   ancl=false
  end
  
  --troll
  if ptile1==124 then
   if trollvar==1 then
    addtext("have you not found my certificate yet?",3,50,20,70,22)
    addtext("none shall pass!",3,50,32,70,10)
   end
   if trollvar==0 then
    addtext("none shall pass!",3,50,30,70,10)
    addtext("zaks has ordered me to keep you out!",3,50,22,70,22)
    addtext("why do you work for an evil wizard?",6,4,50,70,22)
    addtext("i'm not qualified for anything else, not anymore",3,50,20,70,28)
    addtext("anymore?",6,4,52,50,11)
    addtext("i had a certificate, but zaks threw it away",3,50,20,78,22)
    addtext("if i find it, will you help me?",6,4,54,70,22)
    addtext("sure, but until then... none shall pass!",3,50,20,70,22)
    trollvar=1
   end
   if trollvar==2 then
    addtext("thanks dizzy, now i can get a job as an interior designer again!",3,2,30,70,34)
   end
   
   ancl=false
  end
  
 end

end

function  dropitem()
 invactor=actors[inv3[invhighlight]]

 kill=false
 ptile1=pmsget()
 
 dontdrop=false
 
 --snorkel
 if invactor.t==8 and fullpmfcheck(4) then
  dontdrop= true
 end
 
 if invactor.t==10 and mermaidvar==1 then
  --treasure chest
  if ptile1==62 or ptile1==94 then
   addtext("what is this? that's just crummy gold. that's not ~my~ treasure!",13,10,30,70,34)
   
   mermaidvar=2
   score+=100
   dontdrop=true
  end
 end
 if invactor.t==15 and mermaidvar<3 and mermaidvar>0 then
  --bucket
  if ptile1==62 or ptile1==94 then
   addtext("oh you found my treasure!",13,10,30,70,16)
   addtext("thank you, fair egg! this is my favourite hat!",13,10,32,70,22)
   addtext("you are welcome to take the enchanted ring.",13,10,34,70,22)
   addtext("but be careful, zaks will be dangerous until he touches the ring!",13,10,36,70,34)
   sfx(55)
   mermaidvar=3
   score+=1000
   kill=true
  end
 end
 
 if invactor.t==21 then
  --ring
  if ptile1==125 then
   addtext("the enchanted ring drains all of zaks' magic!",0,30,20,70,22)
   addtext("the magical fires burn out!",0,30,20,70,16)
   addtext("curse you dizzy! you win this time!",2,10,30,70,22)
   
   zaksvar=2
   score+=5000
   kill=true
  end
 end
 if invactor.t==11 then
  --umbrella
  if ptile1==56 and doravar>0 then
   addtext("hey dora, here's an umbrella",6,10,60,75,16)
   addtext("thanks dizzy!",2,60,64,60,11)
   
   score+=1000
   doravar=2
   kill=true
  end
 end
 if invactor.t==18 then
  --milk
  if ptile1==60 and denzilvar>0 then
   addtext("denzil, i found a way to make this place cooler",6,10,30,70,28)
   addtext("wow seriously?",1,40,32,70,11)
   addtext("here's some ice cold milk!",6,10,34,70,16)
   addtext("wow thanks! ok you can have this",1,40,36,70,22)
   
   addactor(17,flr8(px-4),flr8(py-7),-1,true,11)
   
   score+=1000
   denzilvar=2
   kill=true
  end
 end
 if invactor.t==17 then
  --frog
  if ptile1==55 and dylanvar>0 then
   addtext("woa, dizzy man! you found my green buddy!",13,50,30,70,22)
   addtext("thanks man, right on!",13,50,30,70,16)
   
   addactor(17,flr8(px-14),flr8(py-7),-1,true,11)
   
   score+=1000
   dylanvar=2
   kill=true
  end
 end

 --certificate
 if invactor.t==4 then
  if ptile1==124 and trollvar>0 then
   addtext("wow, with this i can get a better job!",3,50,20,70,22)
   addtext("thank you dizzy, i'll let you pass now.",3,50,20,70,22)
   sfx(55)
   score+=1000
   trollvar=2
   kill=true
  end
 end
 
 --cat
 if invactor.t==13 then
  if ptile1==39 and dozyvar>0 then
   addtext("the cat is irritated by dozy's snoring!",0,30,80,70,22)
   addtext("it leaps at dozy, and starts scratching him before running away!",0,30,80,70,34)
   
   addtext("~yawn~ oh hi dizzy, i was having a nice long sleep",1,60,50,65,28)
   addtext("what woke me up?",1,60,50,65,16)
   addtext("never mind that dozy, can i have that thing you're lying on?",6,10,60,65,34)
   addtext("oh, ok.",1,60,50,45,11)
   addtext("dozy rolls over revealing a trendy umbrella and goes back to sleep.",0,30,80,70,34)
   
   addactor(11,flr8(px+8),flr8(py-7),-1,true,5)
   
   
   score+=1000
   dozyvar=2
   kill=true
  end
 end
 
 --key
 if invactor.t==3 then
  if ptile1==40 and grandvar>0 then
   addtext("here's your key, grand dizzy!",6,40,90,50,22)
   addtext("thank you dizzy!",13,50,30,70,11)
    
   score+=1000
   grandvar=2
   kill=true
  end
 end
 
 if not kill and
   (ptile1==39 or
   ptile1==40 or
   ptile1==55 or
   ptile1==56 or
   ptile1==60 or
   ptile1==61 or
   ptile1==124 or
   ptile1==62 or
   ptile1==94 or
   ptile1==115) then
  return
 end
 
 ancl=false
 if (dontdrop) return

 invactor.x=px-4
 invactor.y=py-7
 invactor.a=0
 invactor.woff=woff
 invactor.yoff=yoff

 inv3[invhighlight]=0
 
 if (kill)invactor.x=-99
 
end


function moveplayer()
 fromx=px
 fromy=py

 px+=fx
 py+=fy
 
 oneway = fromy<py
 
 --foot collision
 if collidesfull(px,py,oneway,fromy) then
  if collidesfull(fromx,py,oneway,fromy) then
   --floor/ceiling
   px=fromx
   py=fromy
   fy=0
  else
   if collidesfull(px,fromy) then
    --wall
    px = fromx
   end
  end

  if collidesfull(px,py) then
   --still collides
   px=fromx
   py=fromy
   fx=0
   fy=0
  end
 end

 --spikes
 if mfget(px,py+1,2) and fy>0 then
  addtext("look out for spikes!")
  dienow()
 end

 --fire
 if not dead and zaksvar<2 then
  if fullpmfcheck(3) then
  
   addtext("poached!")

   dienow(true)
  end
 end

 
 gotsnorkel = false
 if (inv3[1]>0 and actors[inv3[1]].t==8) gotsnorkel = true
 if (inv3[2]>0 and actors[inv3[2]].t==8) gotsnorkel = true
 if (inv3[3]>0 and actors[inv3[3]].t==8) gotsnorkel = true
 if not dead and not gotsnorkel then
  if fullpmfcheck(4) then
   addtext("can't breathe in water!")
   dienow()
  end
 end

end



function checkpointnow(x,y,g)
 if (gametitle) return


 checkinv3=inv3
 if g then
  cgx=x
  cgy=y
 else
  cx=x
  cy=y
 end
end

function dienow(s)
 lives-=1
 
 sfx(50)
 
 spawnatground=true
 if (s) spawnatground=false
 if (woff==2 and yoff==2) spawnatground=true
 
 if lives<0 then
  addtext("run out of lives!",0,30,30,70,11)
  startgameover=false
  gameover=true
  fadeout=16
  dead=false
  lives=0
  return
 end

 fadeout=16
 
 fx=0
 fy=0
 kx=px
 ky=py
 dead=true
end

function respawnnow()
 px=cx+4
 py=cy+8
 if spawnatground then
  px=cgx
  py=cgy
 end
 dead=false
 respawning=true

 inv3=checkinv3
end

--screen mget
function msget(x,y)
 return mget(flr8(x),flr8(y))
end

--player msget
function pmsget(b)
 if (b)return msget(px,py-b)
 return msget(px,py)
end

function mfget(x,y,f)
 maptile=mget(flr8(x),flr8(y))
 return fget(maptile,f)
end

function solid(x,y)
	return mfget(x,y,0)
end

function solidtop(x,y)
 maptile=mget(flr8(x),flr8(y))
 if (fget(maptile,1)) return true
 return false
end

--player flag check
function fullpmfcheck(f,yoff)
 y2=0
 if (yoff) y2=yoff
 x2=2
 while x2>-3 do
  if (mfget(px+x2,py-y2,f)) return true
  x2-=1
 end
 return false
end

--collision checks
function collidesfull(x,y,owc,y2)
 x2=2
 if(btn"3")owc=false
 while x2>-3 do
  if (collides(x+x2,y,owc,y2)) return true
  x2-=1
 end
 return false
end


function collides(x,y,onewaycheck,y2)
 if (solid(x,y) or (onewaycheck and solidtop(x,y) and solidtop(x,y2)==false)) then
  return true
 else
  ycol=7
  if (solid(x,y-ycol)) return true
  return false
 end
end


wfade={1,2,3,5,13,13,15,7,9,10,7,10,6,6,15,7,7}
bfade={0,0,1,5,5,2,15,6,4,4,9,3,13,5,13,14}
function fadepix(col,lookup)
 return lookup[col+1]
end


--pointinbox?
function pbox(x,y,bx,by,w,h)
 if bx>x or
     bx+w<x or
     by>y or
     by+h<y then
  return false
 end

 return true
end

--pointincircle?
function pcirc(x,y,rad,ax,ay)
 if(pbox(x,y,ax-rad,ay-rad,rad*2,rad*2)==false) return false
 distx=ax-x
 disty=ay-y
 distx*=distx
 disty*=disty
 if (distx+disty>rad*rad)return false
 return true
end

function addtext(text,col,x,y,w,h)
 inputwait=0
 for i=1,#texts do
  if texts[i]=="" then
   texts[i]=text
   textcols[i]=0
   if (col) textcols[i]=col
   textx[i]=15
   texty[i]=60
   textw[i]=100
   texth[i]=10
   if (x) textx[i]=x
   if (y) texty[i]=y
   if (w) textw[i]=w
   if (h) texth[i]=h
   return
  end
 end
end

--remove first text in buffer
function removetext()
 tc=#texts
 for i=1,tc-1 do
  texts[i]=texts[i+1]
  textcols[i]=textcols[i+1]
  textx[i]=textx[i+1]
  texty[i]=texty[i+1]
  textw[i]=textw[i+1]
  texth[i]=texth[i+1]
 end
 texts[tc]="" textcols[tc]=0
 textx[tc]=0 texty[tc]=0 textw[tc]=0 texth[tc]=0
end

inputwait=0
function showtext()
 if(gametitle)return
 
 if texts[1]!="" then
  rectfill(textx[1],texty[1],textx[1]+textw[1],texty[1]+texth[1],textcols[1])
  line(textx[1]+2,texty[1]+1,textx[1]+textw[1]-2,texty[1]+1,7)
  line(textx[1]+2,texty[1]+texth[1]-1,textx[1]+textw[1]-2,texty[1]+texth[1]-1,7)
  line(textx[1]+1,texty[1]+2,textx[1]+1,texty[1]+texth[1]-2,7)
  line(textx[1]+textw[1]-1,texty[1]+2,textx[1]+textw[1]-1,texty[1]+texth[1]-2,7)
  print(wwrap(texts[1],(textw[1]/4)-1),textx[1]+3,texty[1]+3,7)
  inputwait+=1
  if btnp"5" and inputwait>5 then
   inputwait=0
   removetext()
  end  
 end
 
end

function wrap(v,max)
 while v>max do v-=max end
 while v<0 do v+=max end
 return v
end


function _draw()

 --fadeout
 camera()
 if startgameover and texts[1]=="" then
  gameover=true
  fadeout=16
  startgameover=false
 end
 if fadeout>=0 then
  kx=wrap(kx,128)
  ky=wrap(ky,111)


  fadeout-=1
  fadey=111
  fade=bfade
  if gameover then
   fade=wfade
   fadey=127
  end
  if(fadeout==0)gametitle=false
  fadey+=16
  for x=0,127 do
   for y=0,fadey do

    pix=pget(x,y)

    if fadeout<8 or gametitle or gameover then
     pix=fadepix(pix,fade)
    else
     if pcirc(x,y,20,kx,ky+6)==false then
      pix=fadepix(pix,fade)
     end
    end
    if(pix>=0) pset(x,y,pix)
   end
  end
  return
 end

 if gameover then
  camera()
  rectfill(0,0,127,127,1)
  line(2,1,125,1,0)
  line(1,2,1,125,0)
  line(2,126,125,126,0)
  line(126,2,126,125,0)
  
  rectfill(15,55,114,105,12)
  line(16,54,113,54,12)
  line(16,106,113,106,12)
  line(17,55,112,55,7)
  line(16,56,16,104,7)
  line(17,105,112,105,7)
  line(113,56,113,104,7)
  
  rectfill(34,9,98,26,12)
  line(35,8,97,8,12)
  line(35,27,97,27,12)
 
  palall(0)
  spr(227,35,10,8,2)
  spr(227,37,10,8,2)
  spr(227,36,9,8,2)
  spr(227,36,11,8,2)
  pal()
  spr(227,36,10,8,2)
  
  ospr(56,24,93,false,0)
  ospr(47,36,93,false,0)
  ospr(60,48,93,false,0)
  ospr(32,60,93,false,0)
  ospr(61,72,93,false,0)
  ospr(40,84,93,false,0)
  ospr(55,96,93,false,0)
  pal()

  if (doravar==2)ospr2(56,24,93,false,0)
  if (dozyvar==2)ospr2(47,36,93,false,0)
  if (denzilvar==2)ospr2(60,48,93,false,0)
  if (saveddaisy)ospr2(61,72,93,false,0)
  if (grandvar==2)ospr2(40,84,93,false,0)
  if (dylanvar==2)ospr2(55,96,93,false,0)



  oprint('game over',47,116,13,5)

  if gamewon then
   oprint('you win!',50,40,7,9)
   ospr2(241,26,40,false,0)
   ospr2(241,96,40,false,0)
   ospr2(32,60,93,false,0)
  else
   oprint('you lose!',48,40,7,5)
  end
  
  sprint("score:",25,62,7,13)
  sprint(score,106-textwidth(score),62,7,13)
  sprint("stars found:",25,70,7,13)
  sprint(stars,106-textwidth(stars),70,7,13)
  sprint("lives left:",25,78,7,13)
  sprint(lives,106-textwidth(lives),78,7,13)

  return
 end

 cls()
 rectfill(0,16,127,111,12)

 lwoff=woff
 lyoff=yoff
 woff=flr(px/128)
 yoff=flr(py/112)
 if (lwoff<woff) checkpointnow(flr8(px+4)*8,py-8)
 if (lwoff>woff) checkpointnow(flr8(px-4)*8,py-8)
 
 if lyoff!=yoff then
  checkpointnow(px-4,py-8)
 end

 srand(time)

 if gametitle then


  woff=0 yoff=1
  camera(0,112)
  savescr()
  loadscr()
  camera(0,0)
 
 
  
  --draw title
  --rectfill(0,0,128,16,12)
  palall(0)
  ty =23+sin(time)*6
  --ty=4
  spr(227,63,ty,8,2)
  spr(227,65,ty,8,2)
  spr(227,64,ty-1,8,2)
  spr(227,64,ty+1,8,2)
  pal()
  spr(227,64,ty,8,2)
  
  scroll-=timedelta*15
  if (scroll<-400) scroll=128
  print("★ sophie houlden  ♪ @gruber_music / matthew simmonds  ♥ inspired by classic dizzy games",scroll,4,5)
  
  if sin(time*2)>0 then
   oprint("press button",10,100,10,1)
  end
  
  camera(0,112)
  return

 else
  --draw stuff above game
  
  invspra=0 invsprb=0 invsprc=0
  
  if (inv3[1]!=0) invspra=actors[inv3[1]].b
  if (inv3[2]!=0) invsprb=actors[inv3[2]].b
  if (inv3[3]!=0) invsprc=actors[inv3[3]].b

  if btnp"2" and texts[1]=="" then
   invhighlight+=1
   if (invhighlight==4)invhighlight=1
   if inv3[invhighlight]!=0 then
    showitem(actors[inv3[invhighlight]].t)
   else
    showitem(0)
   end
  end


  spr(invspra,96,4)
  a=(invhighlight*11)+81
  line(3+a,2,12+a,2,6)
  line(2+a,13,2+a,2,6)
  line(3+a,13,12+a,13,6)
  line(13+a,13,13+a,2,6)
  
  spr(invsprb,107,4)
  spr(invsprc,118,4)
  
  --draw title again
  spr(231,55,-1,4,2)
  
  
  print("★",0,1,6)
  print(stars,9,1,6)
  for i=1,lives do
   print("♥",14+i*6,1,6)
  end
  
  print("score:",0,8,6)
  print(score,25,8,6)
  
 end


 camera(woff*128,(yoff*112)-16)




 savescr()
 loadscr()

 

 --draw actors
 godraw()

 --particles
 doparticles()
 
 

 --anim
 curani={}
 if pg==0 then
  curani=jump
  if (fx==0) curani=stilljump
 else
  curani=idle
  if btn"0" != btn"1" and texts[1]=="" then
   curani=walk
  end
 end
 if (stuntime>0)curani=stun

 lastframe=frame
 anitime+=0.5
 if (anitime>1) anitime=0 frame+=1
 if (frame>#curani) frame=1
 
 animsprite=curani[frame]

 --walk sfx
 if frame==2 and lastframe!=frame then
  if (curani==walk) sfx(52)
 end

 --draw player
 ospr2(animsprite,px-4,py-7,pf,1,true)

 ripple()
 
 camera()
 
 if itemtime>0 then
  clip(0,16,128,128)
  w=#itemname*4
  x=127-w
  y=10+min(6,itemtime*30)
  rectfill(x,y,x+w,y+6,0)
  print(itemname,x+1,y+1,7)
  itemtime-=timedelta
  clip()
 end
 if placetime>0 then
  clip(0,16,128,128)
  w=#placename*4
  x=64-w/2
  y=10+min(6,placetime*30)
  rectfill(x,y,x+w,y+6,0)
  print(placename,x+1,y+1,7)
  placetime-=timedelta
  clip()
 end
 
 showtext()

end

function oprint(s,x,y,col,ocol)
 print(s,x-1,y-1,ocol)
 print(s,x+1,y-1,ocol)
 print(s,x-1,y+1,ocol)
 print(s,x+1,y+1,ocol)
 print(s,x-1,y,ocol)
 print(s,x+1,y,ocol)
 print(s,x,y-1,ocol)
 print(s,x,y+1,ocol)
 print(s,x,y,col)
end
function sprint(s,x,y,col,ocol)
 print(s,x,y+1,ocol)
 print(s,x,y,col)
end

function textwidth(num)
 if (num>=10000) return 20
 if (num>=1000) return 16
 if (num>=100) return 12
 if (num>=10) return 8
 return 4
end


function palall(v)
 pal(1,v)
 pal(2,v)
 pal(3,v)
 pal(4,v)
 pal(5,v)
 pal(6,v)
 pal(7,v)
 pal(8,v)
 pal(9,v)
 pal(10,v)
 pal(11,v)
 pal(12,v)
 pal(13,v)
 pal(14,v)
 pal(15,v)
end

--draw sprite outline
function ospr(s,x,y,f,o,notdown)
 palall(o)
 spr(s,x,y-1,1,1,f)
 spr(s,x-1,y,1,1,f)
 spr(s,x+1,y,1,1,f)
 if (not notdown) spr(s,x,y+1,1,1,f)
end

--draw sprite and outline
function ospr2(s,x,y,f,o,notdown)
 ospr(s,x,y,f,o,notdown)
 pal()
 spr(s,x,y,1,1,f)
end


function ripple()
 if (yoff!=3 or woff<2 or woff>3) return
 o=0
 for i=1,110 do
  o+=0.03
  memcpy(scrnpointer+(i*64),scrnpointer+(i*64)+(sin((time+o)*0.5)*2),62)
 end
end




scrnbffrpointer = 0x4300
scrnpointer = 0x6000+1024
scrnbffrlen = 7168
lastwoff=-1 lastyoff=-1
function savescr()
 if (lastwoff==woff and lastyoff==yoff) return

 showplace()

 lastwoff=woff
 lastyoff=yoff

--bg


--draw clouds
 srand(73+(woff-13)*((yoff*12.3)+58))
 y = yoff*112+16
 x = woff*128
 s = 10
 while y<(yoff*112)+110+16 do
   s = rnd(30)+20
   x = rnd(127)+(woff*128)
   y += rnd(30)+10
  drawcloud(x,y,s)
 end
 srand(time)

 --map outline
 palall(1)
 map(woff*16,yoff*14,(woff*128)+1,yoff*112,16,14)
 map(woff*16,yoff*14,(woff*128)-1,yoff*112,16,14)
 map(woff*16,yoff*14,woff*128,(yoff*112)+1,16,14)
 map(woff*16,yoff*14,woff*128,(yoff*112)-1,16,14)
 pal()


 --draw map
 map(woff*16,yoff*14,woff*128,yoff*112,16,14)

 if gametitle then
  camera()
  rectfill(0,0,128,128,12)
  drawstring(img,0,22,128)
  rectfill(0,120,128,128,0)
 end

 memcpy(scrnbffrpointer,scrnpointer,scrnbffrlen)
end

function drawcloud(x,y,csize)
 
 w = rnd(10)+10
 while w>0 do
   x2 = rnd(csize)
   s2 = rnd((csize-x2)/2)+2
   if(rnd(100)>50)x2=-x2
   circfill(x+x2,y,s2,6)
   circfill(x+x2,y-1,s2-2,7)
   circfill(x+x2-1,y,s2-2,7)
   circfill(x+x2,y,s2-2,6)
   circfill(x+x2+1,y,s2-2,6)
   circfill(x+x2-2,y+2,s2-2,6)
   line(x+x2-s2-0,y+1,x+x2-s2+1,y+1,12)
   line(x+x2+s2-1,y+1,x+x2+s2+0,y+1,12)

   w -=1
 end

 --clear screen below
 rectfill((woff*128),y+2,(woff*128)+128,(yoff*112)+111,12)
end

function loadscr()
 memcpy(scrnpointer,scrnbffrpointer,scrnbffrlen)
end

--word wrap
function wwrap(s,w)
 retstr = ""
 linelen=0
 words = strspl(s," ")
 for k=1, #words do
  wrd=words[k]
  if (linelen+#wrd>w)then
   retstr=retstr.."\n"
   linelen=0
  end
  retstr=retstr..wrd.." "
  linelen+=#wrd+1
 end
 retstr=retstr.."\n"
 return retstr
end
 
function strspl(s,sep)
 ret = {}
 bffr=""
 for i=1, #s do
  if (sub(s,i,i)==sep)then
   add(ret,bffr)
   bffr=""
  else
   bffr = bffr..sub(s,i,i)
  end
 end
 if (bffr!="") add(ret,bffr)
 return ret
end