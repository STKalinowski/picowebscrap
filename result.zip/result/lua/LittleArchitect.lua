dr={1,0,0,1,-1,0,0,-1}
bg_col=0
bsc=6

--fsh=12

levels={10,20,50,100}

shapes={

 -- base
 16,0,1,4,
 17,3,3,2,
 17,0,2,3,
 19,0,2,3,
 21,0,2,3,
 23,0,2,3,
 
 -- level one 
 20,3,1,1,	-- planks
 21,1,4,2, -- flat c
 20,0,2,2, -- square
 
 -- level two
 16,5,5,4, -- small treasure
 16,4,1,1,	-- gob
 28,0,3,3, -- small h						

 
 -- level three
 21,5,7,5, -- big treasure
 20,4,1,1,	-- spikes
 28,5,4,2,	-- side planks

 
 -- level four
 21,3,4,1, -- wall of spikes
 25,0,4,5, -- big h
 28,7,4,2, -- invasion
 
 
 
 21,4,1,1, -- wall eye
 --
}


function _init()
 t=0
 _t=0
 logs={}
  
  
 init_menu()
 --init_game()


end

function both()
 return btnp(4) or btnp(5)
end

function init_menu()
 t=0
 music(0)
 go=nil
 lt=0
 main_upd=function()
  
  if not go and both() then
   go=true
   lt=min(40,lt)
   sfx(18)
   music(-1)
  end
  
  if go then
   lt-=1
   if lt==-1 then
    init_game()
    upd_game()
   end
  else
   lt+=1
  end
  
  
 end
 
 main_dr=function()
  local t=lt
  local fd=max(5-t/8,0)
  for i=0,15 do
   pal(i,sget(i,19+fd))
  end
  rectfill(0,0,127,255,0)
  
  local c=max(1-t/32,0)
  c=c*c
  camera(0,c*64)
  map(32,0,0,0)
  
  local y=cos(t/40)*2+.5
  
  print("----------------",32,y+4,7)
  print("little architect",32,y+12,7)
  print("----------------",32,y+20,7)
  
  -- head
  spr(13,32,100)
  
  
  -- stars
  srand(96)  
  for i=0,128 do
   local c=.1+rnd()
   x=rnd(128)
   y=rnd(128)+t*16*c-c*rnd(512)
   x=(x-64)*(1+t*.05)+64
   spr(96+rnd(3),x,y)
  end
  

  if t%16<8 and not go then
   local s="press ❎ to start"
   print(s,33,91,0)
   print(s,32,90,7)
  end
  
  --
  print("2019 alakajam",68,121,13)
  
 end


end


function init_game()

 music(4)

 t=0
 ents={}
 blocks={} 
 monsters={} 
 curh=64
 toth=0
 diams=0
 planks=5
 hp=3
 hpmax=3
 
 -- clean
 reload()
 gmo=nil
 acid=0
 
 --
 local hy=seek_height()*8

 hero=mke(58,64,hy-8)

 hero.upd=upd_hero
 hero.phys=true
 hero.phys2=true
 hero.head=13
 hero.bnc = bnc_hero
 hero.ww=6
 hero.hh=7
 hero.drx=-1
 hero.dry=-1
 hero.resist_acid=true
 hero.upd(hero)
 wfr=0
 
 main_upd=upd_game
 main_dr=dr_game
 
 
 
end

function morph_mon(e)
 e.mons=true
 e.splashable=true
 add(monsters,e)
end

function bnc_hero(e,v)
 if v then   
		if e.vy<0 then
		 brk(e.px,e.py-1,0,-1)
		end
		e.vy=0
	else
	 e.gdi=sgn(e.vx)
	 e.vx=0   
 end
end


function get_shape(n)
 if fsh then
  n=fsh
  fsh=nil
 end
  
 n*=4
 local a={}
	local sx=shapes[n+1]
	local sy=shapes[n+2]
	local ww=shapes[n+3]
	local hh=shapes[n+4]	
	for dx=0,ww-1 do for dy=0,hh-1	do
		local tx=sx+dx
		local ty=sy+dy
		local tl=mget(tx,ty)
		if tl > 0 then		
		 add(a,{x=dx,y=dy,tl=tl})
		end
	end end	
	return a
end

function pop_block()

 -- height
 local y=seek_height()
	y-=18
	
	-- shape
	local smax=6	
	for l in all(levels) do
	 if toth>l then
	  smax+=3
	 end
	end

	
	local n=rand(smax)
	
		
	local shp=get_shape(n)
	local turn=rand(4)
	if shapes[n*4+1]>4 then 
	 turn = 0 
	end
	
	for d in all(shp) do
	 for i=1,turn do
	  local x=d.x
	  local y=d.y
	  d.x = -y
	  d.y = x	  
	 end
	 if rand(400)==0 then
	  d.tl=55
	 end	 	 
	 if d.tl==55 then
	  if rand(5)==0 then
	   d.tl=52
	  end
	  if rand(5)==0 then
	   d.tl=123
	  end
	  if rand(5)==0 then
	   d.tl=59
	  end

	 end
	 
	end
	
	
	local a={}
	for x=1,15 do
	 local ok=true	
	 for d in all(shp) do
	  local fx=x+d.x
	  ok = ok and fx<15 and fx>0 and mget(fx,y+d.y)==0
	 end
	 if ok then
   add(a,x)
  end 	 
	end
	
		
	-- no space left
	if #a==0 then
	 return
	end
	
	local x=a[1+rand(#a)]	
	
	for d in all(shp) do
	 mk_block(d.tl,x+d.x,y+d.y)
	end

 -- launch
 push(cgr[1],0,1,4)
 cgr=nil
 
end


function mk_block(tl,px,py)

 b=mke(tl,px*8,py*8)
 b.resist_acid=true
 
 b.px=px
 b.py=py 
 add(blocks,b)
 
 
 
 -- group
 if not cgr then
  cgr={}
  b.gr=cgr
 end 
 add(cgr,b)
 b.lead=cgr[1]
 
 
 
end



function gbcol(e,dx,dy)
 local tp=e.mdx==0 and 4 or 5
 for b in all(e.gr) do
  if mcol2(b.px+dx,b.py+dy,tp) then
   return true
  end 
 end
 return false
end



function push(e,dx,dy,spd)

 if not e.mv then e.mv=0 end
 e.mvs=spd
 e.mdx=dx
 e.mdy=dy 
 
 
 -- check print
 local cl=gbcol(e,dx,dy)
 
 for e in all(e.gr) do
  if cl then
	  print_block(e)	  
	 else
	  if dy==1 then 
	   mset(e.px,e.py,0)
	  end 
	  e.px+=dx
	  e.py+=dy
	  if dy==1 then
	   msetf(e.px,e.py,34)
	  end
	 end
 end
 if cl then
  lsfx(3,e)
  for e in all(e.gr) do
   msetf(e.px,e.py+1,0)
  end
 end 
 
 ---
 -- check 
 if e.mono and is_out(e) then
  kl(e)
 end

end

function is_out(e,ma)
 local ma=ma or 32
 local left=min(-ma,cmx-ma)
 local right=min(128+ma,cmx+128+ma)
 return e.x<left or e.x>right
end


function msetf(x,y,tl)

 if not mcol2(x,y,4) and y<64 then
  mset(x,y,tl)
  msetf(x,y+1,tl)
 end


end

function grab(fr)
 if fr==55 then
  diams+=1
  sfx(7)
 elseif fr==59 then
  planks+=2
		sfx(20)
 elseif fr==123 then
  hp=min(hp+1,hpmax)
		sfx(21)		
 end

end

function morph_item(a)
	a.float=2
 a.hcol=function()
  if hero.cfull or a.t<16 then return end
  if hp==3 and a.fr==123 then
   return
  end
  
  kl(a)
  hero.cfull=2  
  grab(a.fr)

  
 end
 
 a.mcol=function(m)
  if m.item then return end
  kl(a)
  m.item=a.fr
 end
 
end




function print_block(e)
 kl(e)
 local tl=e.fr
 
 if not fget(tl,0) and not fget(tl,5) then  
  local a=mke(tl,e.px*8,e.py*8)
  
  if fget(tl,7) then -- gem
   morph_item(a)
  end
  
  if tl==52 then -- gob
   a.px=e.px
   a.py=e.py
   a.di=1
   a.wlk=2 

   morph_mon(a)
   wait(4,run_gob,a)

  end 
  
  tl=6 
 
 end
 
 mset(e.px,e.py,tl)
 
 
 -- blocks
 if tl==42 then
  for i=0,3 do
   local px=e.px+dr[i*2+1]
   local py=e.py+dr[i*2+2]
   
   if not mcol(px,py) then
    mset(px,py,119+i)
   end
  end
 end
 
 if e.ghl then
  splash(e.ghl)
 end
 
 
end



function rand(n)
 return flr(rnd(n))
end


function seek_height()
 for y=0,63 do for x=1,14 do
  if not fget(mget(x,y),4) then
   return y
  end
 end end
 return 63
end



function move(e,dx,dy,n,f)
 moveto(e,e.x+dx,e.y+dy,n,f)
end




function moveto(e,tx,ty,n,f)
 e.sx=e.x
 e.sy=e.y
 e.ex=tx
 e.ey=ty
 e.twc=0
 e.tws=n
 e.twf=f 
 
 if n<0 then
  dx=e.ex-e.sx
  dy=e.ey-e.sy
  e.tws=-sqrt(dx^2+dy^2)/n
 end
 
 if e.inv then
  e.flp=e.sx<e.ex
 end 
 
end


function sbl_col(x,y)
	return x>=sbl.x and y>=sbl.y and x<sbl.x+8 and y<sbl.y+8
end


function blocks_col(x,y) 
 for e in all(blocks) do
  local l=e.lead
  local bx=e.px*8+(l.mv-8)*l.mdx
  local by=e.py*8+(l.mv-8)*l.mdy
		if x>=bx and y>=by and x<bx+8 and y<by+8 then
		 culp=e
		 return true
		end	
 end
 return false
 
end


function ecol(e,dx,dy,f)
 act=e
 f=f or pcol
 
 dx = dx or 0
 dy = dy or 0 
 local a={0,0,0,1,1,1,1,0}
 for i=0,3 do
  local x=e.x+a[i*2+1]*(e.ww-1)+dx
  local y=e.y+a[i*2+2]*(e.hh-1)+dy
  if f(x,y,i) then 
   return true 
  end
 end
 return false
end

function pmov(e,vx,vy)
 e.gdi=nil
 if ecol(e) then
  return
 end
 
 local cf= e==hero and hpcol or pcol
 
 -- x
 e.x+=vx
 cl =e.bnc
 while ecol(e) or ecol(e,0,0,blocks_col) do  
  e.x-=sgn(vx)
  if cl then 
   cl(e,false)
   cl=nil
  end 
 end

 -- y
 e.y+=vy
 cl =e.bnc
 while ecol(e,0,0,cf) or ecol(e,0,0,blocks_col) do
  e.y-=sgn(vy)
  if cl then 
   cl(e,true)
   cl=nil
  end
 end
 
 --

 
 
 
 
end

function mcol(x,y,fl)
 fl=fl or 0
 return y>=64 or fget(mget(x,y),fl)
end

function mcol2(x,y,tp)
 return y>=64 or not fget(mget(x,y),tp)
end



function hit(px,py,di)
 local tl=mget(px,py)
 
 if tl==3 then
 	-- recule
	 hero.fvx=-hero.di*2
	 hero.cwj=12
	  
  if mcol(px+di,py) then
   brk(px,py,di,0)
   
  else
   
 	 
 	 mk_block(tl,px,py)
 	 cgr[1].mono=true
 	 push(cgr[1],di,0,8)
 	 cgr=nil
 	 mset(px,py,6)
	
	  
	  -- anim
	  local e=mke(48,px*8,py*8)
	  e.flp=di==-1  
	  sfx(2,-1,0,2) 	 
 	 
 	end 	
 	
 else
  brk(px,py,di)
 end



end

function brk(px,py,dx,dy)

 dx=dx or 0
 dy=dy or 0
 local tl=mget(px,py)
 
 if tl!=3 then
  return
 end
 
 sfx(5)
 mset(px,py,6)
	fx_stone(px,py)
  
   
 --end
 
end

function fx_stone(px,py)
 local a={0,0,1,0,0,1,1,1}
 for i=0,3 do
  local e=mke(17+i)
  local ddx=a[1+i*2]
  local ddy=a[2+i*2]
  e.x=px*8+2+ddx*4-4
  e.y=py*8+2+ddy*4-4
  e.life=8+rand(8)
  impulse(e,atan2(ddx-.5,ddy-.5),1)
  e.we=.25
  e.frict=.97
  impulse(e,atan2(dx,dy),1+rnd(2))
  e.vy-=1
 end
end

function impulse(e,an,spd)
 e.vx+=cos(an)*spd
 e.vy+=sin(an)*spd
end


function get_fall(px,py)
 if mcol(px,py) then
  return 0
 else
  return get_fall(px,py+1)+1
 end
end


function run_gob(e)

 e.x=e.px*8
 e.y=e.py*8
 --log(e.t..":"..e.px.." "..e.py)
 local again = function() run_gob(e) end
 local spd=8
 e.flp=e.di==-1
 
 -- check fall
 if not mcol(e.px,e.py+1) then
  move(e,0,8,spd,again)
  e.py+=1
  return
 end
 

 local clu=mcol(e.px,e.py-1)
 local clf=mcol(e.px+e.di,e.py)
 local clfb=mcol(e.px+e.di,e.py+1)
 local clfu=mcol(e.px+e.di,e.py-1)

 function go()
	 move(e,e.di*8,0,spd,again)
	 e.px+=e.di
		
 end

	if not clf and clfb then
  go()  
	else
	
	 if e.y<=hero.y and rand(3)==0 and clf and clfb then
	  brk(e.px+e.di,e.py)
	  e.x+=e.di*4
	  move(e,-e.di*4,0,6,again)
	  
	 elseif e.y+4<hero.y and not clf and not clfb then
	  if e.y+get_fall(e.px+e.di,e.py)*8 <= hero.y then 
	   go()
	  else
			 e.di=-e.di
			 wait(10,again)	
	  end
	 elseif e.y-4>hero.y and clf and not clfu and not clu then
		 move(e,e.di*8,-8,spd*2,again)
		 e.jmp=8
		 e.px+=e.di
		 e.py-=1
	 else
		 e.di=-e.di
		 wait(10,again)	 
	 end	
	 

	end 
 
 

end




function upd_hero(e)
 if gmo then 
  return
 end
 -- update pos
 e.px = flr((e.x+3)/8)
 e.py = flr((e.y+3)/8)
 if mcol(e.px,e.py,6) then
  hurt_hero()
 end
 
 
 -- equi
 if e.vy<0 then
  e.eq=false
 elseif not e.ceq and not e.eq and not ecol(e,0,0,eqcol) then
  e.eq=true
 end

 -- grav & ground
 gr=hpcol(e.x,e.y+e.hh) or hpcol(e.x+e.ww-1,e.y+e.hh)
 lad=mcol(e.px,e.py,2) --or mcol(e.px,(e.y+7)/8,2) 
 
 
 
 if lad then gr=true end 
 if not gr then
  if e.vy<4 then
   e.vy+=.5
  end 
  if e.gdi and e.vy>1 then
   e.vy=1
  end  
 else 
  if e.vy>0 then
   e.vy=0
  end 
 end 

 
 -- move
 e.vx=0
 e.di=0
 local spd=3
 function hmov(di)
  e.di=di
  e.vx+=di*2
  if t%4==0 then wfr+=1 end
 end
 
 look_up=btn(2)
 if btn(0) then hmov(-1) end
 if btn(1) then hmov(1) end
 
 
 -- ladder look up
 look_up=false
 if lad then
  hero.vy=0
  if btn(2) then hero.vy=-1 end
  if btn(3) then hero.vy=1 end
 else
  look_up=btn(2)
 end
 
 
 
 if not lad and btnp(3) and e.eq then
  e.eq=false
		e.ceq=4
 end
 
 
 
 -- force look
 if e.cwj and not gr then
  e.di=sgn(e.fvx)
 end
 
 -- jump
 local wg = not gr and e.gdi and e.vy>0
 
 if (gr or wg) and btnp(4) then
  if wg then
   e.fvx=-e.gdi*3
   e.cwj=16
  end
  e.vy=-5
  e.eq=false
  sfx(1,-1,0,1)
 end
 
 -- target
 floor_ready = not mcol(hero.px,hero.py+1) and not mcol(hero.px,hero.py+1,1)
 ladder_ready = gr and look_up

 
 -- hit or use
 if btnp(5) then
  --hurt_hero()
  if e.gdi then
   hit(e.px+e.gdi,e.py, e.gdi)
  else
   use()
  end
 end



 
 -- acid
 local lim=512-acid
 if hero.y>lim then
  if hero.y>lim+16 then
   hero.vy*=.5
  end 
  hurt_hero()
 end
 

 -- frame
 if gr then
  e.fr=28
  if e.di!=0 then
   e.fr+=wfr%4
  end
  
 else
  e.fr=30  
  if wg then
   e.fr=45+e.gdi
  end  
 end
 
end


function use() 
 
 if planks==0 then
 	hero.clack=32
 	sfx(10)
 	return
 end


 if gr and look_up then
  planks-=1
  build_ladder()
 elseif floor_ready  then
  planks-=1
  build_floor()
 end
end

function build_ladder()
 mset(hero.px,hero.py,0)
 local e=dum(hero)
 e.fr=0
 spread(e,27)
 
end

function build_floor()

 mset(hero.px,hero.py+1,0)
 cap=dum(hero)
 cap.fr=0
 cap.py+=1 
 cap.ends=0 

 spread(cap,7) 
 sfx(22)
 
 
 hero.y=hero.py*8 
 
end


function dum(a)
 local b=mke(a.fr,a.x,a.y)
 b.px=a.px
 b.py=a.py
 return b
end

function spread(dm,tp,count)
 count = count or 0
 -- build
 local x=dm.px
 local y=dm.py
 kl(dm)
 
 
 if mcol(x,y) then
  if cap then
   cap.ends+=1
   if cap.ends==2 then
    diam_floor()
   end
  end
  return
 end 
 
 local cur=mget(x,y)
 if cur==tp or cur==27 then
  return
 end
 
 mset(x,y,tp)
 
 -- spread floor 
 
 if tp==7 then
  sfx(2,-1,2,3)
	 for i=-1,1,2 do
	  local a=dum(dm)	  
	  a.px+=i	  
	  local k=a.px>=0 and a.px<16
	  local f=function()	  
		  if k then	  
					spread(a,tp,count+1)				
				else				 
				 sfx(10)
				 rot(a,tp)	
			 end   
	  end  
			wait(4,f) 	
	 end
	elseif tp==27 then
	 sfx(2,-1,2,3) 
	 -- spawn diams
	 if count>2 then
		 for i=-1,1,2 do
		  if not mcol(x+i,y) and mcol(x+i,y+1) then
		   sfx(9,-1,8,15)
		   make_item_at(55,x+i,y)
		   return
		  end
		 end
	 end
	
	 -- again
	 local a=dum(dm)
	 a.py-=1
  local f=function()
	  if a.py>=0 and count<10 then	  
				spread(a,tp,count+1)				
			else
			 sfx(10)
			 rot(a,tp)	
		 end   
  end  
		wait(4,f) 
	end
 
end

function diam_floor()
 local a={}
 
 for k=0,8 do
  
  for i=-1,k==0 and -1 or 1,2 do
   local px=cap.px+i*k
   local py=cap.py-1
   if not mcol(px,py) and mcol(px,py+1,1) then
				add(a,{x=px,y=py})
   end
  end 
 end
 
 if #a<5 then
  return
 end
 sfx(9,-1,0,7)
 for p in all(a) do
  make_item_at(55,p.x,p.y)
 end
 
end

function make_item_at(it,px,py)
 local e=mke(it,px*8,py*8)
	morph_item(e)
end


function rot(dm,tp)
 local x=dm.px
 local y=dm.py
 kl(dm) 
 mset(x,y,0)
 
 local e= mke(8+rand(2),x*8,y*8)
 e.we=.1+rnd(.2)
 e.vy=-rnd()
 e.vx=1-rnd(2)
 e.life=16
 
 
 for i=0,3 do
  local dx=dr[i*2+1]
  local dy=dr[i*2+2]
  if mget(x+dx,y+dy)==tp then
   local a=dum(dm)
   a.px+=dx
   a.py+=dy
   wait(4,rot,a,tp)
  end
 end
 
 --[[
 for i=-1,1,2 do
  if mget(x+i,y)==tp then
   local a=dum(dm)
   a.px+=i
   wait(4,rot,a,tp)
  end
 end
 --]]
end

function pcol(x,y) 
 return mcol(x/8,y/8)
end

function hpcol(x,y) 
 return mcol(x/8,y/8) or (hero.eq and mcol(x/8,y/8,1))
end

function eqcol(x,y,i) 
 return fget(mget(x/8,y/8),1)
end



function mke(fr,x,y)

 local e={
  fr=fr,x=x,y=y,
  vx=0,vy=0,
  ww=8,hh=8,
  drx=0,dry=0,
  flp=false,
  t=0
  
 }
 add(ents,e)
 return e 
 
end

function wait(t,f,a,b,c,d)
 local e=mke(0,0,0) 
 e.life=t
 e.nxt=function() f(a,b,c,d) end 
end


function sg(n)
 return n==0 and 0 or sgn(n)
end

function upe(e)
 e.t+=1
 if e.upd then e.upd(e) end
  
 -- phys
 if e.we then
  e.vy+=e.we
 end
 if e.frict then
  e.vx*=e.frict
  e.vy*=e.frict
 end
 
 -- col
 local vx =e.vx
 local vy =e.vy
 if e.cwj then
  local c=e.cwj/16
  vx=e.fvx*c + vx*(1-c)
 end  
 if e.phys then
  pmov(e,vx,vy)
 else
	 e.x+=vx
	 e.y+=vy
 end
 
 -- monsters
 if e.mons then
  if ecole(e,hero,8) then
   
   if hero.y< e.y and hero.vy>0 then
    splash(e)
    hero.vy=-4
    return
   else
    hurt_hero()
   end
  end 
 end

 -- blocks
 if e.gr then
  mvs=e.mvs
  --if btn(3) then mvs=32 end
  if look_up then mvs=.5 end
  e.mv+=mvs
  while e.mv>8 and not e.dead do
   e.mv-=8
   push(e,e.mdx,e.mdy,e.mvs)
  end   
  for b in all(e.gr) do
  	b.x=b.px*8+(e.mv-8)*e.mdx
  	b.y=b.py*8+(e.mv-8)*e.mdy
  	sbl=b
  	
   while ecol(hero,0,0,sbl_col) do

    local dx=sg(e.mdx)
    local dy=sg(e.mdy)
    
    fset(7,0,true)
    if ecol(hero,dx,dy) then
     hurt_hero()
     destroy_block(e.gr)
     fset(7,0,false)
     return
    else
     hero.x+=dx
     hero.y+=dy
    end
    fset(7,0,false)
   end
  end  
 end 
 
 -- hcol
 if e.hcol then
  if ecole(e,hero,8) then
   e.hcol()
  end  
 end
 -- mcol
 if e.mcol then
  for m in all(monsters) do
   if ecole(e,m,8) then
    e.mcol(m)
   end
  end
 end

 -- splashable
 if e.splashable and ecol(e,0,0,blocks_col)  then
		stick(e)
		return
 end
 
 -- counters
 for v,n in pairs(e) do
  if sub(v,1,1)=="c" then
   n-=1
   e[v]= n>0 and n or nil
  end
 end 
 
 --  tweens
 if e.twc then
  local c=min(e.twc+1/e.tws,1)
  cc=e.twcv and e.twcv(c) or c
  e.x=e.sx+(e.ex-e.sx)*cc
  e.y=e.sy+(e.ey-e.sy)*cc
  if e.jmp then
   e.y+=sin(c/2)*e.jmp
  end  
  e.twc=c  
  if c==1 then
   e.twc=nil
   e.jmp=nil
   e.twcv=nil
   local f=e.twf
   if f then
    e.twf=nil
    f()
   end
  end
 end 
 
 -- dissolve
 if e.y>512+8-acid and not e.resist_acid then
  kl(e)
  for i=0,2 do
   local p=mke(56+i,e.x+rand(8),e.y+rand(8))
   p.resist_acid=true
   p.vy =e.vy
   p.vx =rnd(4)-2
   p.frict=.9
   p.life=10+rand(100)
   p.we=-rnd(.5)
   p.upd=function()
    if p.y<512-acid-2 then
     p.y=512-acid-2
    end
   end
   
  end
 end
 
 -- life
 if e.life then
  e.life-=1
  if e.life<=0 then kl(e) end
 end 
 
end

function stick(e)
 kl(e)
 lsfx(19,e)
 local b=nil
 for bl in all(blocks) do
  sbl=bl
  if ecol(e,0,0,sbl_col) then
   b=bl
  end  
 end 
 b.ghl=e
 b.ghx=e.x-b.x
 b.ghy=e.y-b.y
 
end


function ecole(a,b,ma)
 
 local dx=a.x-b.x
 local dy=a.y-b.y
 return abs(dx)<ma and abs(dy)<ma
end

function hurt_hero()
 if gmo or hero.churt then
  return
 end
 --frz=16
 hero.churt=40
 sfx(6)
 hp-=1
 if hp==0 then
  game_over()
 end 
end

function game_over()
 music(-1)
 hero.vx=0
 hero.vy=0
 
 wait(24,hexp)
 del(ents,hero)
 add(ents,hero)

 gmo=mke(0,0,0)
 gmo.dr=dr_gmo

 
 
end

function dr_gmo(e)
 if e.t<24 then
  return
 end 
 local t=e.t-24
 camera()

 if gmo.diams then
  dt+=1
  local ma=16
  local a={0,7,0}
  for i=1,3 do
   rectfill(ma,ma,127-ma,127-ma,a[i])
   ma+=1
  end
  
  
  fcl=9
  
   if gmo.hh>0 then
   	sfx(23)
    gmo.hh-=1
    gmo.score+=10
   elseif gmo.diams>0 then
    sfx(24)
    gmo.diams-=1
    gmo.score+=5
   elseif gmo.planks>0 then
    sfx(25)
    gmo.planks-=1
    gmo.score+=1
   else
    fcl=8+_t%8
   end	  

  
  
  function feat(a,b,c,y)
   sb=b..""
   print(a,28,y,b==0 and 1 or fcl)
   print(b,92-#sb*4,y,b==0 and 1 or 7)
   if c then
    print("x"..c,96,y,b==0 and 1 or 13)
   end
  end

  feat("height",gmo.hh,10,32)
  feat("gems",gmo.diams,5,42)
  feat("planks",gmo.planks,1,52)
  feat("score",gmo.score,n,80)
  

  
  
  
  
  return
 end
 
 
 for i=0,7 do
  for k=0,1 do
   local x=32+i*9
   local y=40
   local z=1   
   local c=max(1-t/40,0)
   c=c*c
   local an=i/7+c   
   z=2.5+cos(t/40+i/7)   
   x+=cos(an)*sin(c*.5)*128
   y+=sin(an)*sin(c*.5)*128   
   local bx=64+cos(i/7)*48
   local by=64+sin(i/7)*48   
   x+=(bx-x)*c
   y+=(by-y)*c
   if k==0 then
    apal(1)
    x+=z
    y+=z
   else
    y-=z
   end
   sspr(18+i*7,40,7,8,x,y)
   pal()
  end
 end
 
 

 camera(cmx,cy)
end

function count_score()
 
end


function hexp()
 kl(hero)
 sfx(11)
 for i=0,8 do
  local p=mke(96,hero.x,hero.y)
  impulse(p,i/8,5)
  p.life=32
  p.frict=.92
  p.cshk=16    
 end
 hero.chxp=20
 
end


function destroy_block(gr)
 for e in all(gr) do
  msetf(e.px,e.py,0)
  kl(e)
  fx_stone(e.px,e.py)
 end 
end

function apal(n)
 for i=0,15 do pal(i,n) end
end


function mk_flyer()


 local e=mke(0,-128,hero.py*8-16)
	morph_mon(e)
 e.nxt=function()
  wait(500,mk_flyer)
 end
 
 e.upd=function(e)
 
  if ecol(e) then
   splash(e)   
   return
  end  
  
  if ecol(e,e.vx,0,f) then
   e.vx=-e.vx
  end   
  
  local vx=e.x-cmx
  if vx<-32 or vx>160 then
   local minx=min(-32,cmx-32)
   local maxx=max(160,cmx+160)
  
   --e.x=rand(2)*144-16
   e.x=minx+rand(2)*(maxx-minx)
   --e.y=(hero.py+rand(5)-2)*8
   e.y=(hero.py-1-rand(5))*8
   e.vx=sgn(64-e.x)*1 --.5   
  end
 end
 
 e.dr=function(e)
  e.flp=e.vx<0
  local y=e.y+cos(t/40)*2
  for i=0,1 do   
   local x=e.x+i*6*(e.flp and 1 or -1 )
   local fl=e.flp
   if i==0 then 
    fl=not fl 
    apal(4)
   end   
   spr(36+cmod(16)*6,x,y,1,1,fl)
 	 pal()
 	end
 	spr(35,e.x,y,1,1,e.flp)
 end
 

end


function lsfx(k,e)
 local ma=16
 local x=e.x+e.ww/2-cmx
 local y=e.y+e.hh/2-cy 
 if x>=-ma and y>=-ma and x<128+ma and y<128+ma then
  sfx(k)
 end 
end

function splash(e)
 kl(e)
 lsfx(8,e)
 for i=0,3 do
  mke(21,e.x+rand(8)-4,e.y+rand(8)-4,1,1,rand(2)==0,rand(2)==0)
 end
end

function cmod(k)
 return (t/k)%1
end

function kl(e)
 e.dead=true
 del(ents,e)
 del(monsters,e)
 del(blocks,e)
 if e.item then
  make_item_at(e.item,flr(e.x/8),flr(e.y/8))
 end
 
 
 if e.nxt then 
  e.nxt(e)
  e.nxt=nil
 end
 
 
end

function dre(e)
 local fr=e.fr
 local x=e.x+e.drx
 local y=e.y+e.dry
 
 -- block slide
 --[[
 local l=e.lead
 if l then
  x=e.px*8+(l.mv-8)*l.mdx
  y=e.py*8+(l.mv-8)*l.mdy
 end
 --]]
  
 --
 local shk=e.cshk 
 if shk then
  shk/=4
  x+=rand(shk*2)-shk
  y+=rand(shk*2)-shk
 end
  
 -- walk
 if e.wlk then
  fr=fr+(e.x/4)%2
 end
 
 -- float
 if e.float then
  y+=cos(e.t/40)*e.float-.5
 end 
  
 -- jump
 if fget(fr,0) then 
  y-=1
 end
  

 
 -- anim
 if fget(fr,3) and t%2==0 then
  fr=fr+1
  e.fr=e.fr+1
  if not fget(fr,3) then
   kl(e)
   return
  end
 end 
 
 -- pal
 if e.churt and _t%8<4 then
  apal(8)
 end
 
 -- draw
 if fr>0 then
  spr(fr,x,y,1,1,e.flp)
 end 
 
 -- head
 if e.head and e.py then
  local dy=mcol(e.px,e.py-1) and 2 or 0
  local hfr=e.head+e.di
  --if not e.eq then hfr=15 end
  if look_up then
   hfr=15
  end
  if lad then
   hfr=47
  end  
  spr(hfr,x,y+dy-3)  
 end
 
 --
 if e.item then
  spr(e.item,x,y-4)
 end
 
 -- specific
 if e.dr then e.dr(e) end
 
 -- reset pal
 pal()
 
 -- child
 local c=e.ghl
 if c then
  c.x=e.x+e.ghx
  c.y=e.y+e.ghy
  dre(c)
 end
 
end

function upd_game()
 -- acid
 if acid<bsc*8 then
  acid+=(bsc*8-acid)*.1
 end
 if t%4==0 and acid<128 then
  acid+=1
 end 
 
 -- spawn monster
 if t%4000==10 then
  mk_flyer()
 end
 
 -- ents
 foreach(ents,upe)
 

 local y=seek_height() 
 if y < 16 then		--or btnp(5)
  --log("scroll_map"..(t%1000))
 	scroll_map()  
 end
 
 -- check block
 if #blocks<4 and not hero.cblk and not gmo then
  pop_block()
  hero.cblk=20
 end
 
 -- 
 if gmo and gmo.t>40 and both() then
	 if gmo.diams then
	  reload()
	  init_menu()
	 else
			dt=0
			gmo.hh=flr(toth+64-seek_height()-16)		
			gmo.diams=diams
			gmo.score=0
			gmo.planks=planks		
			gmo.diams+=8+rand(32)
			gmo.hh+=16+rand(32)
		end
 end
 
end

function _update() 
 _t+=1
 
 -- freze
 if frz then
  frz-=1
  if frz<=0 then
   frz=nil
  end
  return
 end
 
 -- builder
 
 --[[
 if builder then
  builder=btn(5)
  
  if btnp(2) then
   build_ladder()
  end
  
  return
 end
 --]]
 
 t+=1
 
 main_upd()
 
 
end

function scroll_map()
 toth+=bsc
 curh+=bsc
 local dd=bsc*8 
 cy+=dd
 acid-=dd
 for e in all(ents) do
  e.y += dd
  if e.py then
   e.py += bsc
  end
  if e.tws then
    e.sx += dd
			 e.sy += dd
			 e.ex +=dd
			 e.ey +=dd
  end   
 end  
 for y=63,0,-1 do
  for x=0,15 do
   local tl=mget(x,y-bsc)

   mset(x,y,tl)
  end
 end

end


function dr_game()

 -- camera
 if not cy then cy=hero.y-64 end
 local tcy = min( hero.y-64, 512-128) 
 cy += (tcy-cy)*.2
 cmx=hero.x-64
 camera(cmx,cy) 
 
 -- line
 local y=seek_height() 
 curh+=(y-curh)*.25
 local str=flr(toth+64-curh-16)
 
 local h=curh*8
 line(cmx,h,127+cmx,h,1)
 print(str.." meters",cmx,h-6)
 
 -- main
 map(0,0,0,0,16,64)
 foreach(ents,dre)
 
 -- target
 trg=nil
 if hero.gdi then
  local px=hero.px+hero.gdi
  if mcol(px,hero.py) then 
   trg=0
   if not mcol(px+hero.gdi,hero.py) then
    trg=1
   end 
   spr(112,px*8,hero.py*8)
  end
 end
 
 -- acid
 for ay=0,acid do
  local y=512+ay-acid
  
  --local c=
  --local y=512+(ay/40-1)*acid 
    
  if y>cy+130 then
   break
  end
  
  local pw=ay/10
  local dx=cos(y/40+t/100)*pw
  local k={1,3,3,3, 3,3,10,10, 11,11,10,11,11,11,11,10 }
  
  for px=0,127 do 
   --[[
   local x=px+cmx
   local c=pget(x+dx,y)
   local cx=ay==0 and 4 or 0
   c=sget(cx+c%4,1+c/4)
   --]]
   local x=px+cmx
   local c=k[pget(x+dx,y)+1]
   pset(x,y-1,c)
  end
 end
 


 -- inter
 camera()
 function print_score(x,n,fr)
	 local s=n.."x"
	 print(s,x-#s*4,2,7)
	 spr(fr,x,0)
 end
 print_score(120,diams,55) 
 if hero.clack and t%4<2 then
  apal(8)
 end
 print_score(96,planks,59)
 pal()
 
 -- life
 for i=0,hpmax-1 do
  local x=i<hp and 0 or 9
  sspr(x,40,9,8,16+i*10,0)
 end
  
 -- tool
 rectfill(0,0,15,14,0)
 rect(1,1,13,12,7)

 fr=nil
 if trg then
  fr=103+trg
 elseif ladder_ready then
  fr=105
 elseif floor_ready then
  fr=7
 end

 if fr then
  spr(fr,3,3)
 end
 
 print("😐",4,14,1)
 print("❎",4,14,7)

end

function _draw()
 cls(bg_col)
 
 --
 main_dr()
 
 -- log
 color(7)
 cursor(0,0)
 for str in all(logs) do
  print(str)
 end
 
  

 
 
end

function log(str)
	add(logs,str)
	while #logs>20 do
	 del(logs,logs[1])
	end
end