-- king
-- by: droodlebean

function _init()
	mus=true
	trans=true
	spars={}
	init_start()
	bla=0
end

function init_game()
	mode = "game"
	player()
	text_init()
	map_init()
	
	pars={}
	hide=true
	tog=0
	
	drain="off"
	
	transition()
	
	startcon("wHA..?:32")
end

function tog_drain()
	if drain=="off" then
		drain="on"
	else
		drain="off"
	end
end

-- game state

function update_game()
	if(mus) music(2) mus=false
	
 menuitem(1,"drain mode: "..drain, tog_drain)
 
 if text then
		text_update()
	else
		pl_update()
	end
	
	if(crowns==3) crowns=4 poof(113,31,204) delt(113,30)
	
	if pl.x>1020 then
  init_end()
	end
	
	cam_update()
	
	tog+=1
	if(tog==10) toggle() tog=0
	
	sparc-=1
	if sparc<=0 then
		local x=rnd(127)
		newspar(x,1,80)
		newspar(x+rnd(4)-2,0,65)
		sparc=4
	end
	
	foreach(pars, update)
	foreach(spars, update)
	
	hide=true
	if (pcf>=128)	hide=false
	
end

function draw_game()
	camera(camx,camy)
	background()
	light() 
 map_draw()
 clip()
 foreach(pars, draw)	
 actor(pl)
 frame()
 banner_draw()
 if(text) text_box()
 if not text then
 	local scoot = 0
 	if (onbank() and sequences[pct]) scoot=4
	 if (onbank() or pcf==32)	print("❎",pl.x+1-scoot,pl.y-7,7)
	 if (sequences[pct])	print("🅾️",pl.x+1+scoot,pl.y-7,8)
	end
 
end

function _update()	
	_ENV["update_"..mode]()
end

function _draw()
	cls(0)
 _ENV["draw_"..mode]()
end

function draw(i)
	i:draw(i)
end

function update(i)
	i:update(i)
end

function newspar(x,c,l,y)
	add(spars,{
		x=x,y=y or 148,a=0.25,l=l,c=c,
		spd=1,
		update=function(i)
			bove(i)
			i.a+=rnd(0.01)-0.005
			i.l-=1
			if(i.l<=0) del(spars,i)
		end,
		draw=function(i)
			circfill(i.x+fx,i.y+fy,i.l/4,i.c)
		end
	})
end

function init_end()
 endc = 0
 panx = -1
 pany = 0
 mode = "end"
 camx = 896
 camy = -8
 sparc=0
 music(13)
end

function update_end()
	endc+=1
	
	sparc-=1
	if sparc<=0 then
		local x=rnd(127)
		newspar(x,rnd({2,1,5}),80)
		newspar(x+rnd(4)-2,rnd({15,9,14,8}),65)
		sparc=4
	end
	
	foreach(spars, update)
	
	tog+=1
	if tog>=10 then
		for x=1,127 do
			for y=camy/8,camy/8+8 do
			 local m=mget(x,y)
			 local f=fget(m)
			 if (f==4) mset(x,y,m+1)
			 if (f==8) mset(x,y,m-1)
			end
		end
		tog=0
	end
	
	if(endc>=180 and pany<384) then
	 campan(panx,pany)
	 if(camx<-128 or camx>1028) panx*=-1 pany+=64
	end
	
	if(btnp(5)) reload() _init()
	
end

function draw_end()
 camera(camx,camy)
 
 if(endc>=60) background() map(0,0,0,0,128,96)
 
 if(mid(camx,-96,986)==camx) fillp(▒)
 if(camx<-48 or camx>944) rectfill(camx,camy,camx+128,camy+80,0)
 fillp()
 
 frame()
 
 
	if(endc>=30) mprint("thanks for playing!",64,74,7)
	if(endc>=50) mprint("music, art,",64,82,7)
	if(endc>=70) mprint("and code",64,88,7)
	if(endc>=90) mprint("done by mrgeko",64,96,7)
	if(endc>=110) mprint("thass me :)",64,110,7)
	if(endc>=110) mprint("INSTAGRAM - @DROODLEBEAN",64,118,7)
end

function init_start()
 mode="start"
 sparc=0
 music(0)
 
 camx,camy=7*128,(3*64)-8
 fx,fy=camx,camy
 
 logo={
 	x=camx+22,
 	y=camy+14,
 	sp=96,
 	w=2,
 	h=2,
 	fl=0,
 	fw=0.5,
 }
 king={
  x=48,
  y=27,
  fl=8,
 	fw=0.3
 }
end

function update_start()
 sparc-=1
	if sparc<=0 then
		local x=rnd(127)
		newspar(x,rnd({3,1,11}),80)
		newspar(x+rnd(4)-2,rnd({1,10,12,0}),75)
		sparc=4
	end
	
	foreach({logo, king},float)
 
 foreach(spars, update)
 
 if(btnp(5)) init_game()
end

function draw_start()
 camera(camx,camy)
 
-- foreach(spars, draw)
 
 
 
 dark_pal()
 light(93,40,60)
 clip()
 pal()
 frame()
 
 actor(logo)
 mprint("\^w\^tking",king.x+1,king.y+1,2)
 mprint("\^w\^tking",king.x,king.y,7)
 mprint("  press ❎ to start",64,42,7)
end

function mprint(m,x,y,c)
	print(m,camx+x-#m*2,camy+y,c)
end	

function campan(mx,y)
	camx+=mx
	if(camy~=y) camy=y-8
end
-->8
-- player

function player()
	pl = {
		x=24,y=32,dx=0,dy=0,sp=0,sc=1,flp=false
	}
	posdat()
	hasdeflect=false
	dping=0
	defclock=0
 crowns=1
end

function posdat()
 pcx,pcy=pl.x+3,pl.y+3
 pcm,pct=mget(pcx/8,pcy/8),onbank(true)
 pcf=fget(pcm)
end

function pl_update()
	if(btn(0)) pl.dx-=1 pl.flp=true
	if(btn(1)) pl.dx+=1 pl.flp=false
	
	if btnp(4) then
	 if sequences[pct] then
	 	init_fight()
	 elseif mcol(pl,0,1) or pcf==16 then
	  pl.dy=-3.5
	  sfx(24,3)
	 end
	end

	if(pl.dx~=0) pl.dx -= 0.5 * sgn(pl.dx)
	
	if(abs(pl.dx)>2) pl.dx = 2 * sgn(pl.dx)
	if(not mcol(pl,0,1)) pl.dy+=0.5
	
	if(pl.dy>5) pl.dy=5

 if(pl.dy>0 and pcf==16 and not(btn(3))) pl.dy=0
	move(pl)
	
	posdat()
 
 if btnp(5) then
 	if onbank() then
			startcon(onbank())
		elseif pcf==32 then
			door()
		end
	end
	
	if not mcol(pl,0,1) then
		pl.sp = 4
		if(pl.dy>0) pl.sp = 5
		pl.sc = 1
	elseif pl.dx~=0 then
		animate(pl,{1,2,3,0})
	else
		pl.sp = 0
		pl.sc = 1
	end
	if(pl.sc==3) dust(pl.x,pl.y,1)
	
end

function move(i)
	local mx,my=0,0
	if(i.dx~=0) mx = sgn(i.dx)
	if(i.dy~=0) my = sgn(i.dy)
	
	for k = 0,flr(abs(i.dx)) do
		if not mcol(i,mx,0) then
		 i.x += mx
		else
			i.dx = 0
		end
	end
	
	for k = 0,flr(abs(i.dy)) do
		if not mcol(i,0,my) then
		 i.y += my
		else 
		 if(i.dy>1.5) dust(pl.x,pl.y,3)
			i.dy = 0
		end
	end
end

function animate(i,set)
	i.sc += 0.5
	if(i.sc>#set) i.sc = 1
	i.sp = set[flr(i.sc)]
end

function actor(i)
	spr(i.sp,i.x,i.y,i.w or 1,i.h or 1,i.flp,i.flpy)
end

function nudge(x,y)
	pl.x+=x
	pl.y+=y or 0
end

function deflect()
	if(dping>0) dping-=1
	if btn(4) then
		if defclock<=0 then 
			dping=8
			ping(cr.x+1,cr.y+1)
			defclock=20
			sfx(22,3)
		end
		
	end
	if(defclock>0) defclock-=1
end
-->8
-- map

function cam_update()
	local x,y=flr(pcx/128),flr(pcy/64)
	camx = min(x*128,896)
	camy = y*64-8
end

function toggle()
	for x=camx/8,camx/8+15 do
		for y=camy/8,camy/8+8 do
		 local m=mget(x,y)
		 local f=fget(m)
		 if (f==4) mset(x,y,m+1)
		 if (f==8) mset(x,y,m-1)
		end
	end
end

function map_draw()
 map(camx/8,(camy+8)/8,camx,camy+8,16,8)
	for x=camx/8,camx/8+15 do
		for y=camy/8,camy/8+8 do
		 local xx,yy=x*8,y*8
		 local m=mget(x,y)
		 if (hide and fget(m)>=80) then
		  local sp=30
		  if(camy>0 and camx<800) sp=28
		  spr(sp,xx,yy)
		 end
		end
	end
end

function frame(x,y)
	fx,fy=x or camx, y or camy
 rectfill(fx,fy,fx+127,fy+7,0)
	rectfill(fx,fy+72,fx+127,fy+127,0)
	if(bla>0) bla-=1 cls()
	clip(0,72,128,128)
 foreach(spars, draw)
 clip()
end

function mcol(i,mx,my)
	local x1,y1=i.x+1+mx, i.y+my
	local x2,y2=x1+5, y1+7
	return tcol(x1,y1)
	or tcol(x1,y2)
	or tcol(x2,y1)
	or tcol(x2,y2)
end

function tcol(x,y)
	local f=fget(mget(x/8,y/8))
	return f%2~=0
end

function background(x,y,spd)
	local camx,camy=x or camx, y or camy
	for x=camx/8-1,camx/8+15 do
		for y=camy/8-1,camy/8+8 do
		 local xx,yy=x*8,y*8
		 local m=back[1+(flr(camx/128)+(flr((camy+8)/64))*8)]
		 if(mode=="fight") m=240
		 if(m) spr(m,xx+baxy,yy+baxy)
		end
	end
	baxy+=1/(spd or 32)
	if(baxy>8) baxy=0
end

function nb(x,y,n)
	back[x+y*8]=n
end

function map_init()
	back={}
	baxy=0
	foreach({
	"nb,0,0,224",
	"nb,4,0,226",
	"nb,1,1,227",
	"nb,7,1,241",
	"nb,1,2,225",
	"nb,7,2,241",
	"nb,3,2,227",
	"nb,1,3,225",
	"nb,3,3,227",
	"nb,7,3,241",
	"nb,1,4,225",
	"nb,7,4,241",
	"nb,4,5,225",
	"nb,6,5,241",
	"nb,8,2,243",
	"nb,8,3,243",
	"nb,8,5,242",
	},call)
	for k=1,48 do
		if(back[k]==nil) back[k]=back[k-1]
	end
end

function light(x,y,s)
	local size=(s or 180)+6*(sin(time()/3)+1)
	local x=(x or pcx%128)-size/2
	local y=(y or pcy%64)-size/2+8
 dark_pal()
	map_draw()
	clip(x+size/4,y,size/2,size)
	clip(x,y+size/4,size,size/2,true)
 glow_pal() 
	map_draw()
	size-=16
	x+=8
	y+=8
	clip(x+size/4,y,size/2,size)
	clip(x,y+size/4,size,size/2,true)
	pal()
	map_draw()
end

function dark_pal()
 pal(1,0)
 pal(2,1)
 pal(3,1)
 pal(4,2)
 pal(5,0)
 pal(6,5)
 pal(7,13)
 pal(8,2)
 pal(9,2)
 pal(10,13)
 pal(11,1)
 pal(12,1)
 pal(13,1)
 pal(14,2)
 pal(15,13)
end

function glow_pal()
 pal(1,2)
 pal(2,1)
 pal(3,1)
 pal(4,5)
 pal(5,2)
 pal(6,14)
 pal(7,10)
 pal(8,4)
 pal(9,2)
 pal(10,10)
 pal(11,9)
 pal(12,13)
 pal(13,2)
 pal(14,8)
 pal(15,10)
end
-->8
-- text

function text_update()
	if btnp(5) 
	or btnp(4) then
		tnum = 1
		tkey += 1
		
		text = convo[tkey]
	end
end

function text_box(x,y)
	local camx,camy=x or camx, y or camy
	if type(text)=="string" then
		local scr=split(text,":")
		local scr,icon=scr[1],scr[2]
		
		
		
		local scoot=4
			if icon then
				if (icon<64) scoot=26
			end
		
		print(sub(scr,1,tnum),
			camx+scoot, camy+80,7)
		if tnum<#(scr) then
		 tnum+=1
		 if(sub(scr,tnum,tnum)~=" ") sfx(25)
		end
		
		icon_draw(camx+6,camy+80,icon)
	else -- if text isn't a string
		if text then	
		
			if type(text)=="table" then
				for k=1,#text do
					if text[k]==true then
						bank[pct]=nil
					else
						call(text[k])
					end
				end
		 end
		 
		 --bank[onbank(true)]=nil 
		 text=nil
		end
		
		tnum=1
		tkey=1
	end
end

function icon_draw(x,y,sp)
 if not sp then
  x+=100
 elseif(sp>63) then 
 	x+=100
 end
 
 rectfill(x,y,x+15,y+15,1)
 if not sp or sp==220 then
 	local t=sp or pcm
 	sspr(t%16*8,flr(t/16)*8,
		8, 8, x, y, 16, 16 )
	else
		spr(sp,x,y,2,2)
	end
end

function onbank(num)
	local t = flr(pcx/8)+flr(pcy/8)*128
	
	if num then
 	return t
 else
 	return bank[t]
 end
end

function banner_draw()
	if ban then 
		local y = camy+bany
		rectfill(camx,y,camx+127,y+6,8)
		line(camx+1,y+7,camx+126,y+7,8)
		print("* "..ban,camx+2,y+1,7)
		
		banc-=1
		if (mid(120,banc,112)==banc)	bany+=1
		if (mid(0,banc,16)==banc)	bany-=0.5
		if (banc<1) ban=nil
	end
end

function banner(message,var)
	ban = message
	banc=120
	bany=-8
	if var then
		if not _ENV[var] then
		 _ENV[var]=true  
		else
		 _ENV[var]+=1
		end 
	end
end

function startcon(...)
 if type(...)=="table" then
 	convo=...
 else
  convo={...}
 end
	text=convo[1]
	tkey=1
end
-->8
-- text library

function nt(x,y,...)
	bank[x+y*128]={...}
end

function delt(x,y)
 bank[x+y*128]=nil
end

function ns(x,y,...)
	sequences[x+y*128]={...}
	add(sequence_saves,{...})
end

function text_init()
	tnum=1
	tkey=1
	convo={}
	bank={}
	sequences={}
	sequence_saves={}
	
	nt(2,4,"this is your throne!\nwhere you sit and rule.",
	"you'll probably sit here\nforever.")
	nt(8,6,"good morning king!",
	"ready to rule?",
	"...:32",
	"splendid!")
	nt(45,6,"good morning king!",
	"oUTSIDE...:32",
	"you want something from\noutside?",
	"oUT...:32",
	"that can be arranged! \ntake a seat king, rule!",
	"...:32")
	nt(50,6,"castle!","...:34",
	"there's a 3 fingered hand\nprint near the base of\nthe sign.:34",
	"it looks like your hand.:34",
	"...:32")
	nt(52,30,"i keep this fire lit.",
	"we all need a purpose!",
	"have you come for for a\nlittle warmth king?",
	"...:32")
	-- peon
	nt(92,37,"king!1!",
	"it's very good to have\nyou back!! very!!",
	"you back!",
	"after the incident, i\nwas worried!!!1!",
	"when you were attacked,\ndead!!1! deaad??/?",
	"wHAT... WHO..?:32",
	"deeeaeaaddd?!1!/??!!",
	{true,"nt,92,37,dead dead dead,you're deeeeaaad!!!1!"})
	nt(72,6,"there's a grate here.:34",
	"it looks like it could be\nlifted if you had the\ntool.:34")
	nt(94,34,"it's a maintenance\ntool used for getting\ninto the sewers.",
	{"poof,94,34",
	"banner,maintenance tool get!",
	{"nt,72,6,you hook the maintenance\ntool into the grate and\nlift it out of the way.:34",
	{"poof,72,7,58",true}},true})
	nt(50,46,"oh hey! you're 106 right?",
	"1... 0... 6..?:32",
	"yeaah, the model number,\nor whatever you call it\non a biological being.",
	"i was supposed to forget\nback at 85 or something,",
	"i guess scepter hasn't\ngotten around to me\nyet!",
	{{"nt,50,46,sCEPTER..?:32,yeah! your royal \nengineer!,they're very cool. you\ndid a good job on them!",
	{{"nt,50,46,the 'ol battery ain't\nwhat it used to be.,i better give it a few\ndecades.,wait-:32",
	{"poof,50,46,107",true}}}}})
	nt(55,38,"greetings king.\ni'm afraid you're early.",
	"we're still updating the\nsubjects, come back in a\ncouple years.",
	"...:32")
	nt(69,46,"hello king. i'm sorry\nthat the subjects\naren't ready yet.:221",
	"but you are early,\nafter all.:221",
	"hOW... WHERE IS OUT..?:32",
	"back the way you came, i\nassume. how did you get\nin anyways?:221",
	"nO... OUT OF THE... MY\nKINGDOM.:32",
	"my king, if you were\ngone, who would rule?:221",
	"please, go back to your\nthrone. i'll finish\nrecycling the subjects.:221",
	"...:32")
	nt(90,14,"the table is littered\nwith posters, scrawled\nwith inspiring messages",
	"such as; 'deal!',\n'buy buy buy!' and\n'cat medicine included!'")
	nt(100,14,"what? you think i'm\njust another lever you\ncan push?",
	"just another device to\noperate so you can go on\nyour royal way?",
	"wH..?:32",
 "that's what i thought.")
 nt(6,30,"hOME...:32")
 nt(34,14,"hey there boss! it's me,\njamely the janitor!",
 "..?:32",
 "you... forgot about me?",
 "oPEN... DOOR...:32",
 "jamely! the janitor!?",
 "...:32",
 "typical. they never can\nremember me.",
 "with all those royal\nrules in your head, who\nhas space for a janitor!",
 "...:32",
 "the door? no, i don't\nthink i will.",
 "go hire a new janitor!")
 nt(3,14,"my lord! why did you\nleave your throne!?",
 "you have duties!\nyou have subjects!",
 "...:32",
 "half baked...  \nking, you have a very\nsimple purpouse.",
 "sit, and rule us! lend\nus purpouse!",
 "coming down here at\nyour... age, is highly\niregualar!",
 "this is all wrong...\nnot right at all...",
 "...:32")
 nt(123,14,"ZRMMMRMRMRM...",
 "there's a cat sleeping\nhere.:34",
 "pSSPSSPSS..?:32",
 "mMMROWL",
 "...:32",
 "it seems this can only\nbe resolved with\nviolence.:34")
	nt(59,30,"g'day king! how's that\ncrown treating you?",
	"...:32",
	"i know it's just a\ncheap imitation,",
	"it's just been a while\nsince we got a new\nshipment of crown-stuff",
	"i'm sure you're working\non it though!",
	"...:32")
	nt(91,14,"hey hey hey! you look\nlike an enterprising\nrobot!",
	"???:32",
	"how would you consider a\nsort of trade?",
	"i've got the one, and\nonly! key to the pipe\nroom downstairs.",
	"all i need in return is\na functional arm!",
	"and well, it looks like\nat least one of those\nworks!!",
	"...:32",
	"too attached? that's\nalright, bring me\nsomeone else's!")
	nt(74,38,"there's a functional\nrobot arm resting here.:34",
	"it tries to politely\nshake your hand as you\ntuck it away.:34",
	{"poof,74,37",
		{"nt,91,14,hey hey hey! that's a\nfiiine arm you got there!,let met take a closer\nlook at that.,...:32,*click*\nmuuch better!",
		 {{"nt,91,14,hmm? the key? no i think\ni'll hold onto it thanks.,...:32"},
		 "poof,91,14,114",
		 "dupseq,91,14,9"
		}},
		true
	})
	nt(122,22,"entry #1   \ni've done the impossible,\ntruly cloned myself.:66",
	"memories and everything!\nit's rattled, but it's\nalive.:66",
	"truly,\nalive.:66"
	)
	nt(120,22,"entry #3  \nit's died. my clone.\na strange development,:66",
	"even with the mind intact\nit collapsed into itself.\na human is complex,:66",
	"perhaps i just need to\nsimplify.:64"
	)
	nt(113,27,"entry #9\nthe simpler model works!:66",
	"and it's much faster to\ngrow. it doesn't eat,\ndoesn't sleep,:66",
	"it's much more efficient\na design than a human.\na beautiful thing.:66"
 )
 nt(117,29,"entry #20\nthey're like machines.:66",
 "they don't have any\ninnate purpose,:66",
 "they don't even need to\nsurvive, really.:66",
 "and they know that just\nas well as i do.:66",
 "they just sit and ponder\nuntil they rot. \nsurely...:66",
 "my legacy can be more\nthan this melencholy.:66"
 )
 nt(119,29,"entry #44. #46?\ni'm getting old. but\ni'm also getting close.:66",
 "to rule, what better\na porpouse? a whole\nkingdom of purpose!:66",
 "and subjects to rule,\nrobots with the purpose\nto serve their king.:66",
 "scepter, an instrument to\nmake  and maintain\nthe subjects.:66",
 "the king, scepter, and\nsubjects.:66",
 "beautiful, cyclical,\nsynergy.:66"
 )
 nt(122,29,"my last enry.\ni've made a sort of\n'blueprint'.:66",
 "a clone of me,\nsimplified to be\ncloned ad infinitum.:66",
 "it will rule, thoughts\nof it's own existance\nnowhere to be found.:66",
 "i'm imortal now, in a\nway. my legacy is self\nperpetuating.:66",
 "a piece of myself at\nleast. forever.:66",
 "what a wonderful thing\ni've made:66",
 "...:32")
 nt(123,29,"it's a dusty skeleton.:34",
 "clackclackclack!",
 "it's old prothstetics\nseem to still be\nkicking.:34"
 )
 nt(5,46,"...real, i know it's real.\nand it's mine!\ni found it",
 "wHAT-:32",
 "mine! and you can't have\nit! 'the king need more\ncrown material' they say'",
 "'go on crownfinder, go\nfind some crown-stuff!'\nthey say.",
 "but they don't know\nwhere it is! they\ndon't know...",
 "...:32")
 nt(85,46,"aNOTHER KING? sO SOON?\ntHEY MUST BE DESPERATE.",
 "i'M NOT-:32",
 "lIES WILL GET YOU\nNOWHERE, I'M AFRAID.",
 "tRY TO STRIKE ME DOWN,\ni'VE DOWNED FIVE KINGS\nALREADY.",
 "tHE CYCLE MUST BE BROKEN\nYET, THEY REFUSE TO SEE.",
 "bUT-:32",
 "fight me!  \n106TH in this unending\nchain!",
 {"init_fight"})
 nt(5,22,"greetings king!\nhow can i be of\nassistance?",
 "lOWER... SEWERS...:32",
 "...",
 "PLEASE..?:32",
 "lower sewer system\naccess requested!",
 "please enter your pin!",
 "...K-I-N-G...1-2-3-4..?:32",
 "access denied!")
 nt(77,26,"hehehe, i bet you\nwanna know what's in\nhere huh?",
 "wELL...:32",
 "too bad! it's locked!\nand you haven't had the\nkey in aaages!",
 "...:32")
 nt(55,22,"there's nothing in\nthese pipes!",
 "i checked every one,\ndust, dust, dust.",
 "this can't be safe, you\nbetter come back once\ni resolve this.")
 nt(29,37,"wHAT IS THIS? aNOTHER\nKING COME SEEKING...\nGUIDANCE?",
 "...:32",
 "aWW, OR PERHAPS THE\nKEY TO THAT INFERNAL\nCHEST.",
 "nO, IT BEST REMAIN\nCLOSED i'M AFRAID.",
 "...:32",
 "yOU THINK YOU COULD TAKE\nIT FROM ME?",
 "hAH! i REMEMBER WHEN i\nTHOUGHT i RULED THIS\nPLACE.",
 "tRY! iT WILL BE GOOD TO\nFEEL YOUTH ONCE MORE.")
 nt(113,30,"the grate has three\ncrowns etched into it.:34")
 nt(123,45,"hey! thanks for playing!",
 "i'm the developer,\ndon't think about it\ntoo much, i'm not canon.",
 "looking for a challenge?",
 "i randomly pick from\nthe boss patterns\nevery few seconds",
 "and i heal a couple\npoints too,",
 "try to keep up!")
 
	foreach(
	{"nt,59,6,crown smith",
	"nt,58,30,it's a pile of crowns.,you swap out yours for\none in the pile.:34,fits like a glove.:34",
	"nt,50,30,there's something in the\nfire.:34",
	"nt,93,6,the door is permenently\nrusted shut:34",
	"nt,98,6,the door is permenently\nrusted shut:34",
	{"nt,23,6,the wall is lined with\npaintings of kings:34,they look like you!:34,...:32",{true}},
	"nt,1,6,there's a tightly sealed\ngrate here.:34",
	"nt,87,6,the door is locked",
	"nt,86,6,toolshed",
	"nt,20,30,midden access card\nrequired.",
	"nt,67,6,nursery",
	"nt,114,14,scanning. . .:220,invalid crown makeup.:220",
	"nt,44,22,pipe room",
	"nt,70,6,lovely waeather we're\nhaving!,wouldn't you say?",
	"nt,36,46,'blueprint',whatever is in this\nchamber is more 'you'\nthan you'll ever be.:34,...:32",
	"nt,27,14,the throne has several\nblood stains on it.:34,the back cushion is\nripped.:34",
	"nt,6,38,...:32,the table has a diagram\nof you and you and your\nanatomy.:66,it seems you're missing\na few unnecessary organs:66,that must be why you\nitch where you should\nbe hungry.:34",
	"nt,43,14,lower sewer system"},
	call)
	
--call("nt,x,y,it's a mechanical saw.,you can't get a good hold on it.,must be made for robots.:34")
	
	sequence_init()
end
-->8
-- sequence library

function dupseq(x,y,s)
	sequences[x+y*128]=sequence_saves[s]
end

function sequence_init()
	--1
	ns(45,6,"royal guard,1,5,10",
	{"startcon,let me... get that for\nyou...,king",
	"poof,45,6",
	"poof,47,5",
	"poof,47,6",
	"banner,door opened!"},
	
	{"8,bullet,2,90,44,0.5",
	"8,bullet,2,38,38,1"
	}
	)
	--2
	ns(52,30,"firesetter,1,7,26",
	{"startcon,the fire. . .    \nfades",
	"poof,52,30",
	"poof,50,30",
	"banner,fire extinguished!",
	{"nt,50,30,you pull an old key from\nthe ashes.:34",
	{"banner,old key get!",
	{"nt,87,6,you unlock the door\nwith the old key.",
	{"poof,87,6,63",true}},
	true}}},
	
	{"16,bullet,1,48,20,0.75,8,2,3",
	"16,bullet,1,64,20,0.75,8,2,3",
	"16,bullet,1,80,20,0.75,8,2,3"
	},
	{"32,bullet,3,a,a,a,16,1,1"
	}
	)
	--3
	ns(92,37,"broken peon,1,6,56",
	{"startcon,deEaAAdDD.D!1!1.!.",
	"poof,92,37,54",
	"nudge,-9",
	"banner,step created!"},
	
	{"0,bullet,1,x1,y1,0.875,16,2",
	"0,bullet,1,x2,y1,0.625,16,2",
	"0,bullet,1,x2,y2,0.375,16,2",
	"24,bullet,1,x1,y2,0.125,16,2",
	"16,bullet,4,r,r,4,32,0,4",
	"0,bullet,1,x1,40,1,16,2",
	"0,bullet,1,x2,40,0.5,16,2",
	"0,bullet,1,64,y1,0.75,16,2",
	"24,bullet,1,64,y2,0.25,16,2",
	"16,bullet,4,r,r,4,32,0,4"
	}
	)
	--4
	ns(34,14,"janitor,1,8,25",
	{"startcon,it's me...\njamely",
	"poof,32,12",
	"poof,32,13",
	"poof,32,14",
	"poof,34,14",
	"banner,door opened!"},

 {"36,bullet,5,a,a,a,24,1,3,4"
 },
	{"12,bullet,4,pl,pl,1,24"
	}
	)
	--5
	ns(3,14,"royal advisor,1,8,120",
	{"startcon,not right...\nnot right at all...",
	"poof,1,7,204",
	"poof,1,8,58",
	"poof,1,14,63",
	"poof,3,14",
	"delt,1,6"},
	
	{"12,bullet,3,48,60,0.25,16,1,3",
	"12,bullet,3,64,60,0.25,16,1,3",
	"12,bullet,3,80,60,0.25,16,1,3",
	{20.5,"3,bullet,1,a,a,a2,8,1.5"},
 "40,bullet,1,-4,-4"
 }
	)
	--6
	ns(5,22,"terminal,1,8,118",
	{"startcon,access granted!",
	"poof,38,15",
	"poof,39,15",
	"poof,40,15,58",
	"poof,41,15",
	"poof,42,15",
	"banner,lower sewer access!"},
	
	{"0,bullet,1,49,20,0.75,32",
	"0,bullet,1,53,20,0.75,32",
	"0,bullet,1,76,20,0.75,32",
	"0,bullet,1,80,20,0.75,32",
	"0,bullet,1,49,20,0.75,32",
	"0,bullet,1,53,20,0.75,32",
	"0,bullet,1,76,20,0.75,32",
	"7,bullet,1,80,20,0.75,32"
	},
	{{"14,bullet,1,61,20,0.75,24,1,4",
	"14,bullet,1,68,20,0.75,24,1,4"}
	}
	)
	--7
	ns(55,38,"nursery knight,1,8,41",
	{"startcon,sorry boss.",
	"poof,55,38",
	"poof,57,37",
	"poof,57,38",
	"banner,door opened!"},
	
	{{"0,bullet,4,57,33,1,38,0,10",
 "0,bullet,4,72,33,1,38,0,10"},
 {"20,bullet,4,57,48,1,38,0,10",
 "20,bullet,4,72,48,1,38,0,10"},
	{8,"0,bullet,1,a,a,a2,24,2,2,2.5"},
	{8,"0,bullet,1,a,a,a2,20,2,2,2.5"},
	{8,"0,bullet,1,a,a,a2,18,2,2,2.5"},
	{8,"0,bullet,1,a,a,a2,14,2,2,2.5"},
	"30,bullet,1,4,4"
	}
	)
	--8
	ns(69,46,"scepter,1,7,205",
	{"startcon,an unlikely victory.:221,refactoring and\ndefragmenting:221",
	"poof,69,45",
	"poof,70,45,207",
	"poof,70,46,223",
	"poof,76,45",
	"poof,76,46",
	"poof,66,6,63",
	"banner,door opened!"},
	
	{{8,"0,bullet,1:pl,a,a,pl2"},
	48
	},
	{{6,"96,bullet,7,a,a,a2,0,1,2,5,12"
	}}
	)
	--9
	ns(1,0,"salesman,1,10,115",
	{"startcon,ahh! my arm! i just\ngot that!",
	"nt,91,14,i thought you were\ncool man. then you\nwent all ragey on me!,i don't think you are an\nenterprising robot\nafter all!",
	"banner,pipe key get!",
	"poof,91,14,7",
	{"nt,45,22,you use the pipe room\nkey on the door:34",
	{"poof,46,22",
	"poof,46,21",true}}
	},
	{{4,"0,bullet,1,a,a,a2,16",
	"0,bullet,1,a,a,a2,16",
	"0,bullet,1,a,a,a2,16",
	"0,bullet,1,a,a,a2,16",
	"0,bullet,1,a,a,a2,16",
	"30,bullet,1,a,a,a2,16"}
	},
	{"0,bullet,2,90,31,0.5,24,1,2,0,0",
	"0,bullet,2,90,51,0.5,24,1,2,0,0.25",
	"0,bullet,2,110,31,0.5,24,1,2,0,0.75",
	"60,bullet,2,110,51,0.5,24,1,2,0,0.5",
	"0,bullet,2,90,31,0.5,24,1,2,1,0.5",
	"0,bullet,2,90,51,0.5,24,1,2,1,0.75",
	"0,bullet,2,110,31,0.5,24,1,2,1,0.25",
	"60,bullet,2,110,51,0.5,24,1,2,1,0"
	}
	)
	--10
	ns(55,22,"pipe worker,1,8,99",
	{"startcon,my pipes...",
	"poof,63,21",
	"poof,63,22",
	"poof,55,22",
	"banner,door open!"
	},
	{{10,"1,bullet,1:sc,x1,y1,pl"
	 	},16,
	  {16,"1,bullet,1:sc,x1,y2,pl"
	 	},16,
	 	{16,"1,bullet,1:sc,x2,y1,pl"
	 	},16,
	 	{16,"1,bullet,1:sc,x2,y2,pl"
	 	},16
	 
	},
	{128,
	 "0,bullet,1,128,30,0.5,12,3,5",
		"0,bullet,1,128,52,0.5,12,3,5",
		{32,"0,bullet,1,128,30,0.5,12,3",
		"2,bullet,1,128,52,0.5,12,3"
		}
	}
	)
	
	--11
	ns(100,14,"lever,1,7,255",
	{"startcon,damnit.",
	"poof,101,10",
	"poof,101,11",
	"poof,100,14,254",
	"banner,click!"},

 {{{1,"0,bullet,6:d,64,29,0,14,2.5,3,18,0",
	"0,bullet,6,64,34,0,14,2,2,18,0",
	"0,bullet,6,64,39,0,14,1.5,2,18,0",
	"24,bullet,6,64,44,0,14,1,2,18,0",
	
	"0,bullet,6:d,93,58,0.25,8,5,3,20,1,0.025",
	"0,bullet,6,88,58,0.25,8,4,2,20,1,0.025",
	"0,bullet,6,83,58,0.25,8,3,2,20,1,0.025",
	"20,bullet,6,78,58,0.25,8,2,2,20,1,0.025",
	
	"0,bullet,6:d,36,58,0.25,8,5,3,20,0,0.025",
	"0,bullet,6,41,58,0.25,8,4,2,20,0,0.025",
	"0,bullet,6,46,58,0.25,8,3,2,20,0,0.025",
	"20,bullet,6,51,58,0.25,8,2,2,20,0,0.025"},
	
	
	{1,"0,bullet,6:d,64,29,0.5,14,2.5,3,18,1",
	"0,bullet,6,64,34,0.5,14,2,2,18,1",
	"0,bullet,6,64,39,0.5,14,1.5,2,18,1",
	"24,bullet,6,64,44,0.5,14,1,2,18,1",
	
	"0,bullet,6:d,36,58,0.25,8,5,3,20,0,0.025",
	"0,bullet,6,41,58,0.25,8,4,2,20,0,0.025",
	"0,bullet,6,46,58,0.25,8,3,2,20,0,0.025",
	"20,bullet,6,51,58,0.25,8,2,2,20,0,0.025",
	
	"0,bullet,6:d,93,58,0.25,8,5,3,20,1,0.025",
	"0,bullet,6,88,58,0.25,8,4,2,20,1,0.025",
	"0,bullet,6,83,58,0.25,8,3,2,20,1,0.025",
	"20,bullet,6,78,58,0.25,8,2,2,20,1,0.025"}}
 }
	)
	--12
	ns(85,46,"kingslayer,1,10,68",
	{"startcon,yOU'RE NOT LIKE THE\nOTHERS... ARE YOU.",
	"poof,85,46",
	"poof,87,46,91",
	"banner, midden access get!",
		{"nt,20,30,you swipe the midden\naccess card.:34",
		{"banner, click!",
		"poof,21,31",
		"poof,22,31",
		"poof,23,31,58",
		"poof,24,31",
		"poof,25,31",true}}
	},
	
	{{4,"0,bullet,2,84,pl,pl,12,1,3,0",
	"6,bullet,2,84,pl,pl,8,1,3,1"},
	14,
	{24,"0,bullet,1,pl,20,0.75,4,2",
	"1,bullet,1,pl,60,0.25,4,2"},
	14
	}
	)
	--13
	ns(5,46,"crown finder,1,8,42",
	{"startcon,my treeaaasssureeee!!!,...:32,tHE CROWNSMITH...\nCOULD USE THIS...:32",
	"poof,5,46",
	"banner,crown-stuff get!",
		{"nt,59,30,well i'll be... that's\nsome fiiine frown-stuff\nyou got there king!,let's see if i can't\nwhip something up.,*clink*   \n*clink*      \n*click!*",
			{"poof,61,30,88",
			"banner,true crown get!,hasdeflect",
			{"nt,59,30,with this crown you'll\nhave the royal gusto to\nfight stronger foes!,...with a little work\nof course. this crown\nis hardly finished!,a shinier finish;\nthe points sharpened;\ndetailing an the edge...,it'll only take a couple\nyears!,...:32",
				{"dupseq,59,30,14",
					"nt,59,30,i can't let you leave\nwith that unfinished\ntrash on your head!,even if in it's current\nstate it let's you block\npink projectiles with 🅾️"
				}
			}}
	}},
	{{20,"2,bullet,1:l:40,a,a,a,16,1"
	},
	"12,bullet,4,64,40,1,16,0,5",
	"1,bullet,4,64,40,1,16,0,8",
	"1,bullet,4,64,40,1,16,0,12",
	"1,bullet,4,64,40,1,16,0,16",
	"28,bullet,4,64,40,1,16,0,20",
	
	"0,bullet,1:l:8,x1,y1,0.5,16,0,5",
	"0,bullet,4,x1,y2,0.5,16,0,5",
	"0,bullet,4,x2,y1,0.5,16,0,5",
	"1,bullet,4,x2,y2,0.5,16,0,5",
	
	"0,bullet,4,x1,y1,0.5,16,0,8",
	"0,bullet,4,x2,y1,0.5,16,0,8",
	"0,bullet,4,x1,y2,0.5,16,0,8",
	"1,bullet,4,x2,y2,0.5,16,0,8",
	
	"0,bullet,4,x1,y1,0.5,16,0,12",
	"0,bullet,4,x2,y1,0.5,16,0,12",
	"0,bullet,4,x1,y2,0.5,16,0,12",
	"1,bullet,4,x2,y2,0.5,16,0,12",
	
	"0,bullet,4,x1,y1,0.5,16,0,16",
	"0,bullet,4,x2,y1,0.5,16,0,16",
	"0,bullet,4,x1,y2,0.5,16,0,16",
	"1,bullet,4,x2,y2,0.5,16,0,16",
	
	"0,bullet,1:l:20,x1,y1,0.375,16,0.75,20",
	"0,bullet,1:l:20,x2,y1,0.125,16,0.75,20",
	"0,bullet,1:l:20,x2,y2,0.875,16,0.75,20",
	"24,bullet,1:l:20,x1,y2,0.625,16,0.75,20"
	}
	)

	ns(2,0,"crown smith,1,8,23",
	{"poof,61,30,63",
	"poof,59,30",
	"poof,59,29",
	"banner,door unlocked!",
	{"nt,114,14,scanning. . .:220,hello king:220",
	{"poof,115,14",
	"poof,115,13",true}}
	},
	{120,
	"0,bullet,7:d,95,40,0.5,0,2,2,15,24",
	"0,bullet,7:d,35,40,0,0,2,2,15,24",
	},
	{"0,bullet,1,55,10,0.75,8,0.5,10",
 "60,bullet,1,74,71,0.25,8,0.5,10"
	}
	)

	ns(123,14,"cat,1,9,247",
	{"startcon,meow",
	"poof,123,14",
	"poof,122,15",
	"poof,123,15,58",
	"poof,124,15",
	},
	{"0,bullet,6:hi,66,29,0,0,2,6,40,0,0.025",
	"0,bullet,6:hi,65,29,0,0,2,6,40,0,0.025",
	"0,bullet,6:hi,69,25,0,0,2,3,40,0,0.025",
	"0,bullet,6:hi,62,25,0,0,2,3,40,0,0.025",
	"0,bullet,6:hi,69,22,0,0,2,1,40,0,0.025",
	"0,bullet,6:hi,62,22,0,0,2,1,40,0,0.025",	
	40,
	"0,bullet,6:hi,66,29,0.5,0,2,6,40,1,0.025",
	"0,bullet,6:hi,65,29,0.5,0,2,6,40,1,0.025",
	"0,bullet,6:hi,69,25,0.5,0,2,3,40,1,0.025",
	"0,bullet,6:hi,62,25,0.5,0,2,3,40,1,0.025",
	"0,bullet,6:hi,69,22,0.5,0,2,1,40,1,0.025",
	"0,bullet,6:hi,62,22,0.5,0,2,1,40,1,0.025",	
	40,
	"0,bullet,6:hi,66,29,0.5,0,1,6,80,1,0.0125",
	"0,bullet,6:hi,65,29,0.5,0,1,6,80,1,0.0125",
	"0,bullet,6:hi,69,25,0.5,0,1,3,80,1,0.0125",
	"0,bullet,6:hi,62,25,0.5,0,1,3,80,1,0.0125",
	"0,bullet,6:hi,69,22,0.5,0,1,1,80,1,0.0125",
	"0,bullet,6:hi,62,22,0.5,0,1,1,80,1,0.0125",

	"0,bullet,6:hi,66,29,0,0,1,6,80,0,0.0125",
	"0,bullet,6:hi,65,29,0,0,1,6,80,0,0.0125",
	"0,bullet,6:hi,69,25,0,0,1,3,80,0,0.0125",
	"0,bullet,6:hi,62,25,0,0,1,3,80,0,0.0125",
	"0,bullet,6:hi,69,22,0,0,1,1,80,0,0.0125",
	"80,bullet,6:hi,62,22,0,0,1,1,80,0,0.0125"
	},
	{{8,
		"16,bullet,1:d,a,a,a2"
		}
	})

	ns(29,37,"the dethroned,1,16,20",
	{"startcon,hMPTH.",
	"banner,chest key get!",
	"dupseq,77,26,19",
	"nt,77,26,well look who's got a\nkey! bring it on!"},
	{{40,"0,bullet,1:d,a,a,a2,20,2"},
		40,
	},
	{10,{5,"4,bullet,1,100,40,0.5,0,1,2,5,8"},
	10
	})

	ns(123,29,"pacemaker,1,8,21",
	{"startcon,nO... MORE.:32,clAcLACK.CK,LACK...",
	"poof,123,29,101",
	"banner,blueprint access get!",
	{"nt,36,46,you insert the key into\nthe panel.:34,...:32,it's stuck.:34,tO RULE!:64,the blueprint is holding\nthe chamber closed\nsomehow.:34,wHAT GRAND\nPURPOSE!:64,nO more!:32",
	 {"dupseq,36,46,18",
	 	"nt,36,46,rETURN TO YOUR POST! aND\ni SHALL RETURN TO MINE!:64,oNLY TOGETHER CAN WE\nMAINTAIN THE CYCLE!:64,no more!:32"
	 }
	}
	},
	{"0,bullet,3,x1,y1,0.875,32,1.2",
	"0,bullet,3,x2,y1,0.625,32,1.2",
	"0,bullet,3,x2,y2,0.375,32,1.2",
	"4,bullet,3,x1,y2,0.125,32,1.2",
	38,
	"0,bullet,5,90,40,0.5,0,1,2,10",
	"0,bullet,5,40,40,0,0,1,2,10",
	{8,	"4,bullet,2,64,40,pl,8,0.8",
	"4,bullet,4,pl,pl,2,16"
	},
	{4,"20,bullet,7:d,120,40,0.5,0,4,2,10,8"}
	})
	--18
	ns(3,0,"the blueprint,1,12,197",
	{"startcon,ooOHHHHHH...:64,...:32,fREEDOM.:32",
	"poof,36,43",
	"poof,37,42",
	"poof,37,43,23",
	"poof,36,44,200",
	"poof,37,44,201",
	"poof,36,45,216",
	"poof,37,45,217",
	"poof,36,46,245",
	"poof,37,46,246",
	"dupseq,37,46,20"
	},
 {{16,"0,bullet,2,a,a,a2,230,2"},
		{10,
		"0,bullet,1,pl,y1,0.75,12,1",
		"0,bullet,1,pl,y2,0.25,12,1",
		"0,bullet,1,x1,pl,0,12,1",
		"3,bullet,1,x2,pl,0.5,12,1"
		},
		25,
		{4,"18,bullet,8,100,r2,0.5,0,1,1,25,8",
		"18,bullet,8,100,40,0.5,0,1,1,25,8"},
		60
	}
	)
	
	ns(5,0,"the chest,1,10,253",
	{"startcon,..!\ni've been beat?,fine. take the thing!\nsee if i care!,the box is empty except\nfor a large regal crown.:34,it's bejeweled and\nlined with fur.:34",
	"poof,77,26,253",
	"banner,regal crown get!,crowns"},	
	{"40,bullet,8:d,pl,0,0.75,0,1,2,15,10"},
	{"0,bullet,1,pl,pl,0.75,12,2",
	"20,bullet,1,pl,pl,0.25,12,2"
	})
	
	--20
	ns(4,0,"the feeble,1,1,18",
	{"banner,first crown get!,crowns",
	"poof,105,6,58",
	"poof,105,7,58",
	"poof,105,8,58",
	"poof,105,9,58",
	"poof,105,10,58",
	"poof,105,11,58",
	"poof,105,12,58",
	"poof,37,46,244",
	"clear",
	"door,108,6"
	},
	
	{"120,bullet,1,90,30,0.52,40,0.4"}
	)
	
	ns(123,45,"inkspinner,1,10,84",
	{"startcon,really! thanks for\nplaying.,have a good day c=",
	{"nt,123,45",{"init_end"}}},
	 {"48,inkspin"
	 }
	)
	
	ns(8,0,"",{},{320,"48,inkspin"})
end

function inkspin()
	series={}
	bul={}
	que={}
	sfx(33)
	bla=2
	
	if(en.hp<en.max) en.hp+=2
	
	local seq=sequence_saves[flr(rnd(17))+2]
	for k=3,#seq do
  newser(seq[k])
 end
 newser({320,"48,inkspin"})
end
-->8
-- events / particles

function call(k)	
	if type(k)=="string" then
		k=split(k)
 elseif(type(k)=="table") then
  local k1=split(k[1])
 	for v=2,#k do
 		k1[v+#k1-1]=k[v]
 	end
 	k=k1
 end

	event(unpack(k))
end

function event(t,...)
	_ENV[t](...)
end

pk={
	function(i)
		circfill(i.x,i.y,i.s,i.c)
	end,
	function(self)
		pset(self.x,self.y,self.c)
	end,
	function(i)
		line(i.x-i.s+1,i.y,i.x+i.s,i.y,i.c)
	end
}

function particle(t,x,y,a,c,s,still,spd,l)
	add(pars,{
		x=x,
		y=y,
		a=a,
		
		l=l or (8+rnd(4)),
		
		c=c,
		s=s or 2,
		
		update=function(self)
			if not still then
				self.x+=cos(self.a)* (spd or 0.5)
				self.y+=sin(self.a)* (spd or 0.5)
			end
			self.l-=1
			if (self.l<1) del(pars,self)
		end,
		draw=pk[t]
		})
end

function puff(x,y,s)
	for k=1,10 do
		particle(1,x,y,
		rnd(1),rnd({7,6,15}),s)
	end
end

function pow(x,y)
	for k=1,10 do
		particle(1,x,y,
		k/10,rnd({8,10,14}),rnd(3),false,1,rnd(4)+6)
	end
end

function pop(x,y)
	for k=1,5 do
		particle(1,x,y,
		k/5,rnd({13,10,14}),rnd(2)+1,false,1,rnd(4)+4)
	end
end

function ping(x,y)
	for k=1,15 do
		particle(1,x,y,
		k/15,rnd({7,12,11}),1,false,1,rnd(2)+6)
	end
end

function dust(x,y,l)
	for k=1,l do
		
	 local a=rnd(0.5)-1
	  
	 particle(1,x,y+7,
	 a,rnd({7,6,15}))
	end
end

function poof(x,y,t,s)
	puff((x*8)+3,(y*8)+3,s)
	mset(x,y,t)
end

function transition(x,y)
	local xx=x or camx
	local yy=y or camy
	
	for x=0,16 do
		for y=1,8 do
			local m=0
			if(x>8) m=65
			spr(12,xx+64-x*8+m,yy+y*8)
			spr(12,xx+64+x*8-m-8,yy+y*8)
		end
		if(cr) actor(cr)
		flip()
	end
	baxy=0
	_update()
	_draw()
end

function door(x,y)
	if trans then
		if x or y then
			pl.x=x*8
			pl.y=y*8
		else
			if pl.y<190 then
				pl.y+=192
			else
				pl.y-=192
			end
		end
		sfx(9)
		music(-1)
		trans=false
		transition()
		trans=true
		music(2)
	end
end

function pulse()
	local y,a=y1,-1
	if(cr.y>40) y,a=y2,1
	for k=1,20 do
		particle(3,x1+size/2,y+k*a,0,8,size/2+k,true)
	end
end

function clear()
	pars={}
end
-->8
-- fight

function init_fight()
	he,en,bul={},{},{}
	cr = {
		x=64,
		y=32,
		sp=6,
		i=0,
		hp=3
	}
	for k,v in pairs(pl) do
  he[k] = v
	end
	for k,v in pairs(pl) do
  en[k] = v
	end
	he.flp,en.flp=false,false
	he.sp=0
	he.fl,en.fl=0,0
	he.fw,en.fw=1,1
	
	mode="fight"
	shake=0
	shx,shy=0,0
	
	size=37
	x1,y1=46,22
	x2,y2=x1+size,y1+size
	
	he.x,en.x=10,110
	he.y,en.y=32,32
	
	enemy()
	dam=0
	
	sfx(7)
	music(-1)
	transition()
	music(7)
	
end

function update_fight()
	foreach({he,en}, float)
	
	menuitem(1,"exit battle", end_fight)
	
	crown()
	if(hasdeflect) deflect()
	que={}
	foreach(series, pattern)
	foreach(bul, update)
	foreach(que, queup)
	foreach(bul, hurt)
	if(drain=="off") wbu()
	if(dam>0) dam-=1
	foreach(pars, update)
	foreach(spars, update)
	sparc-=1
	if sparc<=0 then
		local x=rnd(127)
		newspar(x,8,80)
		newspar(x+rnd(4)-2,2,65)
		sparc=2
	end
	
	if(drain=="on") en.hp-=0.015
	-- die \ win
	if cr.hp<=0
	or en.hp<=0 then
		end_fight()
	end
	
	--screenshake
	shx,shy=0,0
	if(shake>0) then
		shake-=1
		shx+=rnd(4)-2
		shy+=rnd(4)-2
	end

end

function end_fight()
	mode="game"
	mus=true
	if(en.hp<=0) then
		bank[pct]=nil
		sequences[pct]=nil
	 foreach(win,call)
	else
		local m=-1
		if(pl.flp) m=1
		pl.dx=6*m
		pl.dy=-1
	end
	music(-1)
	
	sfx(7)
	
	transition(0,0)
	if(cr.hp<=0) sfx(23,3) pop(pcx,pcy)
end

function draw_fight()
	camera(0+shx,0+shy)
	background(0,0,12)
	rectfill(x1,y1,x2,y2,1)
	rect(x1,y1,x2,y2,7)
	
	if(drain=="off") wbd()
	
	foreach({he,en}, actor)
	
	foreach(pars, draw)
	foreach(bul, draw)
	
	if(cr.i%2==0) actor(cr)
	
	frame(0,0)
	
	-- lives
	for x=1,cr.hp do
		spr(6,-4+x*5,9)
	end
	print("king",1,13,7)
	
	rectfill(80,9,127,11,2)
	rectfill(80,9,80+47*(en.hp/en.max),11,8)
	print(name,128-#name*4,13,7)
end

function queup(i)
 add(bul,i)
end
-->8
-- bullets

bk={
	function (i) -- 1 - basic
		bove(i)
	end,
	function (i) -- 2 - twirl
		if(i.var2 and not i.trig) i.a+=i.var2 i.trig=true
		
		if i.var>0 then
			i.a-=0.025
		else
		 i.a+=0.025
		end
		bove(i)
		bove(i,i.aim)
	end,
	function (i) -- 3 - soft home
		i.a=atan2(cr.x-i.x,cr.y-i.y)
		bove(i,nil,0.5)
		bove(i,i.aim)
	end,
	function (i) -- 4 - still
		i.a-=0.1
		if(i.a<=0) del(bul,i)
	end,
	
	function (i) -- 5 - trail
		bove(i)
		i.clock+=1
		if i.clock>4 then
			i.clock=0 
			bullet(4,i.x,i.y,i.var,0,0,1)
		end
	end,
	
	function (i) -- 6 - circle
		if i.var2>0 then
			i.a+=i.var3 or 0.0125
		else
		 i.a-=i.var3 or 0.0125
		end
		bove(i)
		i.var-=1
		if(i.var<=0) del(bul,i)
	end,
	function (i) -- 7 - barrier
		i.a+=0.25
		local d=i.var3 or 1
		if(i.def) d=d..":d"
		
		for k=1,i.var do
			bullet(d..":hi",i.x,i.y,i.aim,i.var2,i.spd,i.s)
			bove(i,i.a,(i.s*2+1)*k)
			i.a+=0.5
		end
		del(bul,i)
	end,
	function (i) -- 8 - hole
		i.a+=0.25
		
		--bove(i,i.a-0.5,(i.s*2+1))
		for k=1,i.var do
		 local d=1
			if(k<4) d=d..":d"
			
			bullet(d..":hi",i.x,i.y,i.aim,i.var2,i.spd,i.s)
			bove(i,i.a,(i.s*2+1)*k)
			i.a+=0.5
		end
		del(bul,i)
	end
}

function bove(i,a,s)
	i.x+=cos(a or i.a)*(s or i.spd)
	i.y+=sin(a or i.a)*(s or i.spd)
end

function bullet(k,x,y,a,c,spd,s,var,var2,var3)
	local b={
		x=x,
		y=y,
		a=a or 0,
		c=(c or 10),
		spd=spd or 1,
		s=s or 2,
		var=var or 0,
		var2=var2 or 0,
		var3=var3,
		clock=0,
		k=k,
	
		
		update=function(i)
			if i.c > 0 then
				i.c-=1
			else
				i:behave()
			end
			
			
			
			if i.x~=mid(i.x,-4,132)
			or i.y~=mid(i.y,-4,90) then
				del(bul,i)
			end
			
			if i.l then
			
			i.l-=1
				if(i.l<=0) del(bul,i)
			end
		end,
	
	 draw=function(i)
	 	local c,c2=7,14
	 	if(i.def) c,c2=14,8
	 	if(i.c>0) c=2
	 	circfill(i.x,i.y,i.s,c)
	 	
		 if(i.c>0) circ(i.x,i.y,min(i.s,0.5+i.s*((i.clo-i.c)/i.clo)),c2) 
		 
		 if(k~=4 and not i.hi) pset(i.x+cos(i.a)*(i.s+1),i.y+sin(i.a)*(i.s+1))
	 end
	}
	getval(b,"x")
	getval(b,"y")
	
	if(b.a=="r") b.a=rnd(1)
	if(b.a=="a2") b.a=seqa
	if(b.a=="pl") b.a=twdcr(b)
	if(b.a=="-pl") b.a=twdcr(b)+0.5
	
	-- tags
	if type(k)=="number" then
		b.behave=bk[k]
	else
		local tags=split(k,":")
		b.behave=bk[tags[1]]
		
		for k=2,#tags do
			local t=tags[k]
			
			if(t=="d") b.def=true 
			if(t=="l")	b.l=tags[k+1]
			if(t=="hi") b.hi=true
			if(t=="sc") b.a+=rnd(0.05)-0.025
			if t=="bo" then
				for k=1,tags[k+1] do bove(b) end
			end
		end
	end
	b.clo,b.aim=b.c,b.a
	add(que,b,1)
end

function getval(i,xy)
	if(i[xy]=="r") i[xy]=rnd(size)+_ENV[xy.."1"]
	if(i[xy]=="r2") i[xy]=rnd(size-8)+_ENV[xy.."1"]+8
	if(i[xy]=="pl") i[xy]=cr[xy]+1
	if i[xy]=="a" then
	 if i.a=="a" then
	 	i.a=rnd(1)
	 elseif i.a=="pl" then
	  i.x=64  i.y=40
	  i.a=twdcr(i)+0.5
	 else
	 	i.a=seqa 
	 end
	 
	 i.x=64+cos(i.a)*25
	 i.y=40+sin(i.a)*25
	 i.a+=0.5
	 if (sub(i.k,0,4)=="1:pl") i.a=twdcr(i)
	end
	if(_ENV[i[xy]]) i[xy]=_ENV[i[xy]]
end

function twdcr(i)
	return atan2(cr.x+1-i.x,cr.y+1-i.y)
end

function hurt(i)
	if dis((cr.x+1)-i.x,(cr.y+1)-i.y)<=i.s+1
	and i.c<=0 then
	 if dping>0
	 and i.def then
		 --damage()
		 defclock=10
		 sfx(21,3)
		 pop(i.x,i.y)
		 del(bul,i)
		elseif cr.i<=0 then
			cr.hp-=1
			cr.i = 20
			sfx(6,3)
			shake=4
			_draw()
		end
	end
end

function crown()
 local s=1
 if dping>0 then 
 	s=0.5
 else
 	cr.x,cr.y=flr(cr.x),flr(cr.y)
 end
	if(btn(0)) cr.x-=s
	if(btn(1)) cr.x+=s
	if(btn(2)) cr.y-=s
	if(btn(3)) cr.y+=s
	cr.x,cr.y=mid(x1+1,cr.x,x2-3),mid(y1+1,cr.y,y2-3)
	if(cr.i>0) cr.i-=1
end

function dis(x,y)
	return abs(sqrt(x*x + y*y))
end

function float(i)
	i.fl -= 1
	if i.fl<0 
	and flr(i.fl/2)==i.fl/2 then
		i.y+=i.fw
	end
	if(i.fl<-8) i.fl=flr(rnd(8)+10) i.fw*=-1
end
-->8
-- enemy

function wbu()
	if cr.y >= y2-4 and trig==0 then
		trig=1
		damage()
	elseif cr.y <= y1+2 and trig==1 then
		trig=0
		damage()
	end
end

function wbd()
	local y=y1+1
	if(trig==0) y=y2-1
	line(x1+1,y,x2-1,y,8)
end

function damage()
	if dam<=0 then
		en.hp-=1
		sfx(8,3)
		shake=4
		
		pulse()
		_draw()
		
		pow(en.x+3,en.y+3)
		dam=8
	end	
end

function enemy()
	series={}
	local seq=sequences[pct]
	name,beh,en.hp,en.sp,en.reg=unpack(split(seq[1]))
	en.max,win=en.hp,seq[2]
	if(en.sp==205 or en.sp==197) en.w,en.h=2,3 en.y-=8
	if(en.sp==23) en.h,en.flp=2,true en.y-=4
	if(en.sp==247) cr.y+=6
 trig=0
	for k=3,#seq do
  newser(seq[k])
 end
end

function newser(s)
 add(series,{
   seq=s,seq2={},seqa==nil,seql=0,snock=10,snum=1
 	}
 )
end

function pattern(i)
	i.snock-=1
	
	if i.snock<=0 then
  
		repeat 
			local pat=i.seq2[1] or i.seq[i.snum]
			
			if(type(pat)=="table") then
				if type(pat[1])=="number" then
					pat=subseq(i,pat)
					if(type(pat)=="table") pat=rnd(pat)
				else
			 	pat=rnd(pat)
			 	if(type(pat)=="table") pat=subseq(i,pat)
			 end
			end
			
			if type(pat)=="number" then
			 i.snock=pat
			else
				local atk = split(pat)
				i.snock=atk[1]
				
				seqa=i.seqa
				call(sub(pat,#tostr(i.snock)+2),i)
			end
			
			if #i.seq2>0 then
				deli(i.seq2,1)
				i.seqa+=1/i.seql
			end
			if(#i.seq2==0) i.snum+=1
			if(i.snum>#i.seq) i.snum=1
			
		until i.snock>0
	end
 
end

function subseq(i,pat)
 for k=1,pat[1] do
		for k=2,#pat do
			add(i.seq2,pat[k])
		end
	end
	i.seqa=pat[1]-flr(pat[1])

	pat=i.seq2[1]
	i.seql=#i.seq2
	return pat
end