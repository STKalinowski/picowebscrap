-- ad astra by ate bit
-- code/music:4mat gfx:ilkke

-- stealth-patch by zep
-- unsupported .e number format
-- (2.e-004 --> 2/10000)

mesh = {}
meshcol = {}
meshsize = {}
mesh[1] =  {-1.000000,-0.665174,-0.98243,1.000000,-0.136674,1.00000,-1.000000,-0.136674,1.00000,-0.758441,0.806152,1.71490,0.419922,0.639004,1.27870,0.758441,0.806152,1.71490,-1.000000,-0.665174,-0.98243,1.000000,-0.665174,-0.98243,1.000000,-0.136674,1.00000,-0.758441,0.806152,1.71490,-0.419922,0.639004,1.27870,0.419922,0.639004,1.27870,-1.000000,-0.136674,1.00000,-1.000000,0.127128,-1.00000,-1.000000,-0.665174,-0.98243,1.000000,0.127128,-1.00000,1.000000,-0.136674,1.00000,1.000000,-0.665174,-0.98243,-1.000000,-0.665174,-0.98243,0.477404,-0.661048,-3.17931,1.000000,-0.665174,-0.98243,1.000000,-0.136674,1.00000,-0.758441,0.057174,1.71490,-1.000000,-0.136674,1.00000,0.758441,0.806152,1.71490,0.419922,0.224321,1.27870,0.758441,0.057174,1.71490,-0.758441,0.057174,1.71490,-0.419922,0.639004,1.27870,-0.758441,0.806152,1.71490,-1.000000,-0.665174,-0.98243,-0.477404,-0.661048,-3.17931,0.477404,-0.661048,-3.17931,1.000000,-0.136674,1.00000,0.758441,0.057174,1.71490,-0.758441,0.057174,1.71490,0.758441,0.806152,1.71490,0.419922,0.639004,1.27870,0.419922,0.224321,1.27870,-0.758441,0.057174,1.71490,-0.419922,0.224321,1.27870,-0.419922,0.639004,1.27870,-1.000000,-0.136674,1.00000,-2.690042,-0.256182,-0.24140,-1.000000,0.127128,-1.00000,1.000000,-0.136674,1.00000,2.690042,-0.256182,-0.24140,2.690042,-0.256182,1.28095,0.000000,2.409044,1.00018,-0.267031,1.002551,1.00018,0.267031,1.002551,1.00018,-1.000000,-0.136674,1.00000,-2.690042,-0.256182,1.28095,-2.690042,-0.256182,-0.24140,1.000000,-0.136674,1.00000,1.000000,0.127128,-1.00000,2.690042,-0.256182,-0.24140,1.000000,1.000000,1.00000,0.758441,0.057174,1.71490,1.000000,-0.136674,1.00000,1.000000,0.127128,-1.00000,0.477404,-0.661048,-3.17931,0.477404,-0.296450,-3.40142,-1.000000,0.127128,-1.00000,-0.477404,-0.661048,-3.17931,-1.000000,-0.665174,-0.98243,-1.000000,1.000000,1.00000,-0.758441,0.057174,1.71490,-0.758441,0.806152,1.71490,1.000000,1.000000,1.00000,0.758441,0.806152,1.71490,0.758441,0.057174,1.71490,1.000000,0.127128,-1.00000,1.000000,-0.665174,-0.98243,0.477404,-0.661048,-3.17931,-1.000000,0.127128,-1.00000,-0.477404,-0.296450,-3.40142,-0.477404,-0.661048,-3.17931,-1.000000,1.000000,1.00000,-1.000000,-0.136674,1.00000,-0.758441,0.057174,1.71490,1.000000,1.000000,-1.00000,-1.000000,1.000000,1.00000,1.000000,1.000000,1.00000,1.000000,1.000000,-1.00000,-1.000000,1.000000,-1.00000,-1.000000,1.000000,1.00000,1.000000,1.000000,-1.00000,-0.477404,-0.296450,-3.40142,-1.000000,1.000000,-1.00000,1.000000,1.000000,-1.00000,0.477404,-0.296450,-3.40142,-0.477404,-0.296450,-3.40142,-1.000000,-0.136674,1.00000,-1.000000,1.000000,1.00000,-2.690042,-0.256182,1.28095,1.000000,1.000000,1.00000,1.000000,-0.136674,1.00000,2.690042,-0.256182,1.28095,-1.000000,1.000000,-1.00000,-1.000000,0.127128,-1.00000,-2.690042,-0.256182,-0.24140,1.000000,0.127128,-1.00000,1.000000,1.000000,-1.00000,2.690042,-0.256182,-0.24140,0.000000,2.409044,0.29770,0.267031,1.002551,1.00018,0.267031,1.002551,-0.53567,0.000000,2.409044,0.29770,-0.267031,1.002551,1.00018,0.000000,2.409044,1.00018,0.000000,2.409044,0.29770,0.000000,2.409044,1.00018,0.267031,1.002551,1.00018,0.000000,2.409044,0.29770,-0.267031,1.002551,-0.53567,-0.267031,1.002551,1.00018,-0.419922,0.639004,1.27870,0.419922,0.224321,1.27870,0.419922,0.639004,1.27870,-0.419922,0.639004,1.27870,-0.419922,0.224321,1.27870,0.419922,0.224321,1.27870,1.000000,1.000000,-1.00000,1.000000,0.127128,-1.00000,0.477404,-0.296450,-3.40142,-1.000000,0.127128,-1.00000,-1.000000,1.000000,-1.00000,-0.477404,-0.296450,-3.40142,0.477404,-0.296450,-3.40142,-0.477404,-0.661048,-3.17931,-0.477404,-0.296450,-3.40142,-1.000000,1.000000,1.00000,0.758441,0.806152,1.71490,1.000000,1.000000,1.00000,0.758441,0.057174,1.71490,-0.419922,0.224321,1.27870,-0.758441,0.057174,1.71490,0.477404,-0.296450,-3.40142,0.477404,-0.661048,-3.17931,-0.477404,-0.661048,-3.17931,-1.000000,1.000000,1.00000,-0.758441,0.806152,1.71490,0.758441,0.806152,1.71490,0.758441,0.057174,1.71490,0.419922,0.224321,1.27870,-0.419922,0.224321,1.27870,-1.000000,1.000000,1.00000,-2.690042,-0.256182,-0.24140,-2.690042,-0.256182,1.28095,1.000000,1.000000,1.00000,2.690042,-0.256182,-0.24140,1.000000,1.000000,-1.00000,0.000000,2.409044,0.29770,0.267031,1.002551,-0.53567,-0.267031,1.002551,-0.53567,-1.000000,1.000000,1.00000,-1.000000,1.000000,-1.00000,-2.690042,-0.256182,-0.24140,1.000000,1.000000,1.00000,2.690042,-0.256182,1.28095,2.690042,-0.256182,-0.24140,0}
meshcol[1] =  {0,0,0,0,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,5,5,5,5,5,5,5,5,6,6,7,7,8,8,8,8,8,8,8,8,9,9,12,12,13,13,13,13,13,13,14,14,14,14,14,0}
meshsize[1] =  54
mesh[2] =  {0.000000,-1.000000,0.00000,0.425323,-0.850654,0.30901,-0.162456,-0.850654,0.49999,0.723607,-0.447220,0.52572,0.425323,-0.850654,0.30901,0.850648,-0.525736,0.00000,0.000000,-1.000000,0.00000,-0.162456,-0.850654,0.49999,-0.525730,-0.850652,0.00000,0.000000,-1.000000,0.00000,-0.525730,-0.850652,0.00000,-0.162456,-0.850654,-0.49999,0.000000,-1.000000,0.00000,-0.162456,-0.850654,-0.49999,0.425323,-0.850654,-0.30901,0.723607,-0.447220,0.52572,0.850648,-0.525736,0.00000,0.951058,0.000000,0.30901,-0.276388,-0.447220,0.85064,0.262869,-0.525738,0.80901,0.000000,0.000000,1.00000,-0.894426,-0.447216,0.00000,-0.688189,-0.525736,0.49999,-0.951058,0.000000,0.30901,-0.276388,-0.447220,-0.85064,-0.688189,-0.525736,-0.49999,-0.587786,0.000000,-0.80901,0.723607,-0.447220,-0.52572,0.262869,-0.525738,-0.80901,0.587786,0.000000,-0.80901,0.723607,-0.447220,0.52572,0.951058,0.000000,0.30901,0.587786,0.000000,0.80901,-0.276388,-0.447220,0.85064,0.000000,0.000000,1.00000,-0.587786,0.000000,0.80901,-0.894426,-0.447216,0.00000,-0.951058,0.000000,0.30901,-0.951058,0.000000,-0.30901,-0.276388,-0.447220,-0.85064,-0.587786,0.000000,-0.80901,0.000000,0.000000,-1.00000,0.723607,-0.447220,-0.52572,0.587786,0.000000,-0.80901,0.951058,0.000000,-0.30901,0.276388,0.447220,0.85064,0.688189,0.525736,0.49999,0.162456,0.850654,0.49999,-0.723607,0.447220,0.52572,-0.262869,0.525738,0.80901,-0.425323,0.850654,0.30901,-0.723607,0.447220,-0.52572,-0.850648,0.525736,0.00000,-0.425323,0.850654,-0.30901,0.276388,0.447220,-0.85064,-0.262869,0.525738,-0.80901,0.162456,0.850654,-0.49999,0.894426,0.447216,0.00000,0.688189,0.525736,-0.49999,0.525730,0.850652,0.00000,0.525730,0.850652,0.00000,0.162456,0.850654,-0.49999,0.000000,1.000000,0.00000,0.525730,0.850652,0.00000,0.688189,0.525736,-0.49999,0.162456,0.850654,-0.49999,0.688189,0.525736,-0.49999,0.276388,0.447220,-0.85064,0.162456,0.850654,-0.49999,0.162456,0.850654,-0.49999,-0.425323,0.850654,-0.30901,0.000000,1.000000,0.00000,0.162456,0.850654,-0.49999,-0.262869,0.525738,-0.80901,-0.425323,0.850654,-0.30901,-0.262869,0.525738,-0.80901,-0.723607,0.447220,-0.52572,-0.425323,0.850654,-0.30901,-0.425323,0.850654,-0.30901,-0.425323,0.850654,0.30901,0.000000,1.000000,0.00000,-0.425323,0.850654,-0.30901,-0.850648,0.525736,0.00000,-0.425323,0.850654,0.30901,-0.850648,0.525736,0.00000,-0.723607,0.447220,0.52572,-0.425323,0.850654,0.30901,-0.425323,0.850654,0.30901,0.162456,0.850654,0.49999,0.000000,1.000000,0.00000,-0.425323,0.850654,0.30901,-0.262869,0.525738,0.80901,0.162456,0.850654,0.49999,-0.262869,0.525738,0.80901,0.276388,0.447220,0.85064,0.162456,0.850654,0.49999,0.162456,0.850654,0.49999,0.525730,0.850652,0.00000,0.000000,1.000000,0.00000,0.162456,0.850654,0.49999,0.688189,0.525736,0.49999,0.525730,0.850652,0.00000,0.688189,0.525736,0.49999,0.894426,0.447216,0.00000,0.525730,0.850652,0.00000,0.951058,0.000000,-0.30901,0.688189,0.525736,-0.49999,0.894426,0.447216,0.00000,0.951058,0.000000,-0.30901,0.587786,0.000000,-0.80901,0.688189,0.525736,-0.49999,0.587786,0.000000,-0.80901,0.276388,0.447220,-0.85064,0.688189,0.525736,-0.49999,0.000000,0.000000,-1.00000,-0.262869,0.525738,-0.80901,0.276388,0.447220,-0.85064,0.000000,0.000000,-1.00000,-0.587786,0.000000,-0.80901,-0.262869,0.525738,-0.80901,-0.587786,0.000000,-0.80901,-0.723607,0.447220,-0.52572,-0.262869,0.525738,-0.80901,-0.951058,0.000000,-0.30901,-0.850648,0.525736,0.00000,-0.723607,0.447220,-0.52572,-0.951058,0.000000,-0.30901,-0.951058,0.000000,0.30901,-0.850648,0.525736,0.00000,-0.951058,0.000000,0.30901,-0.723607,0.447220,0.52572,-0.850648,0.525736,0.00000,-0.587786,0.000000,0.80901,-0.262869,0.525738,0.80901,-0.723607,0.447220,0.52572,-0.587786,0.000000,0.80901,0.000000,0.000000,1.00000,-0.262869,0.525738,0.80901,0.000000,0.000000,1.00000,0.276388,0.447220,0.85064,-0.262869,0.525738,0.80901,0.587786,0.000000,0.80901,0.688189,0.525736,0.49999,0.276388,0.447220,0.85064,0.587786,0.000000,-0.80901,0.000000,0.000000,-1.00000,0.276388,0.447220,-0.85064,0.587786,0.000000,-0.80901,0.262869,-0.525738,-0.80901,0.000000,0.000000,-1.00000,0.262869,-0.525738,-0.80901,-0.276388,-0.447220,-0.85064,0.000000,0.000000,-1.00000,-0.587786,0.000000,-0.80901,-0.951058,0.000000,-0.30901,-0.723607,0.447220,-0.52572,-0.587786,0.000000,-0.80901,-0.688189,-0.525736,-0.49999,-0.951058,0.000000,-0.30901,-0.688189,-0.525736,-0.49999,-0.894426,-0.447216,0.00000,-0.951058,0.000000,-0.30901,-0.951058,0.000000,0.30901,-0.587786,0.000000,0.80901,-0.723607,0.447220,0.52572,-0.951058,0.000000,0.30901,-0.688189,-0.525736,0.49999,-0.587786,0.000000,0.80901,-0.688189,-0.525736,0.49999,-0.276388,-0.447220,0.85064,-0.587786,0.000000,0.80901,0.000000,0.000000,1.00000,0.587786,0.000000,0.80901,0.276388,0.447220,0.85064,0.000000,0.000000,1.00000,0.262869,-0.525738,0.80901,0.587786,0.000000,0.80901,0.951058,0.000000,0.30901,0.850648,-0.525736,0.00000,0.951058,0.000000,-0.30901,0.425323,-0.850654,-0.30901,0.262869,-0.525738,-0.80901,0.723607,-0.447220,-0.52572,0.425323,-0.850654,-0.30901,-0.162456,-0.850654,-0.49999,0.262869,-0.525738,-0.80901,-0.162456,-0.850654,-0.49999,-0.276388,-0.447220,-0.85064,0.262869,-0.525738,-0.80901,-0.162456,-0.850654,-0.49999,-0.688189,-0.525736,-0.49999,-0.276388,-0.447220,-0.85064,-0.162456,-0.850654,-0.49999,-0.525730,-0.850652,0.00000,-0.688189,-0.525736,-0.49999,-0.525730,-0.850652,0.00000,-0.894426,-0.447216,0.00000,-0.688189,-0.525736,-0.49999,-0.525730,-0.850652,0.00000,-0.688189,-0.525736,0.49999,-0.894426,-0.447216,0.00000,-0.525730,-0.850652,0.00000,-0.162456,-0.850654,0.49999,-0.688189,-0.525736,0.49999,-0.162456,-0.850654,0.49999,-0.276388,-0.447220,0.85064,-0.688189,-0.525736,0.49999,0.850648,-0.525736,0.00000,0.425323,-0.850654,-0.30901,0.723607,-0.447220,-0.52572,0.850648,-0.525736,0.00000,0.425323,-0.850654,0.30901,0.425323,-0.850654,-0.30901,0.425323,-0.850654,0.30901,0.000000,-1.000000,0.00000,0.425323,-0.850654,-0.30901,-0.162456,-0.850654,0.49999,0.262869,-0.525738,0.80901,-0.276388,-0.447220,0.85064,-0.162456,-0.850654,0.49999,0.425323,-0.850654,0.30901,0.262869,-0.525738,0.80901,0.425323,-0.850654,0.30901,0.723607,-0.447220,0.52572,0.262869,-0.525738,0.80901,0.262869,-0.525738,0.80901,0.723607,-0.447220,0.52572,0.587786,0.000000,0.80901,0.850648,-0.525736,0.00000,0.723607,-0.447220,-0.52572,0.951058,0.000000,-0.30901,0.587786,0.000000,0.80901,0.951058,0.000000,0.30901,0.688189,0.525736,0.49999,0.951058,0.000000,0.30901,0.894426,0.447216,0.00000,0.688189,0.525736,0.49999,0.951058,0.000000,0.30901,0.951058,0.000000,-0.30901,0.894426,0.447216,0.00000,0}
meshcol[2] =  {0,0}
meshsize[2] =  80
part_duration = {1,10,6,5,4,4,1,3,7,7,9,5,1,255}
part_data = {99,1,0.0,0.0,0.0,0.0,17.0,16.0,0.0,0.0,3.0,0.0,-1.0,0.0,1.0,0.0,-8.0,0.0,9,8.0,true,9,0.0,false,1,66.0,20.0,200.0,68.0,13.0,7.0,180.0,0.0,2.0,0.0,-1.0,0.0,0.0,0.0,-200.0,0.0,1,66.0,20.0,410.0,18.0,13.0,7.0,180.0,0.0,1.0,0.0,-1.0,0.0,0.0,0.0,-300.0,0.0,11,2,0.0,200.0,64.0,64.0,0.0,0.0,0.0,0.0,2/10000,0.0,0.0,0.0,-1.6,1.0,200.0,0.0,1.0,6.0,125.0,13,1,3,1,64.0,1.0,910.0,40.0,16.0,6.0,0.0,0.0,0.0,0.0,-1.0,0.0,0.0,0.0,-1.0,0.0,5,10.0,0.0,40.0,-2.0,76.0,-1.0,40.0,2.0,76.0,1.0,128.0,-2.0,0.0,0.0,-2.0,0.0,128.0,0.0,99,1,96.0,6.0,0.0,-8.0,16.0,17.0,0.0,-8.0,0.0,11.0,0.0,1.0,0.0,-1.0,0.0,0.0,2,0.0,200.0,64.0,64.0,0.0,0.0,0.0,0.004,0.002,-0.003,0.0,0.0,1.6,1.0,200.0,0.0,1.0,43.0,70.0,13,1,1,3,0.0,1.0,64.0,64.0,0.0,0.0,0.0,0.004,0.002,-0.003,500.0,2.0,0.0,0.0,1.0,5,0.0,10.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,1.0,0.0,1.0,128.0,-1.0,128.0,-1.0,99,1,96.0,0.0,0.0,0.0,16.0,16.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,2,1.0,0.004,0.002,-0.003,0.0,0.0,1.6,1.0,200.0,0.0,1.0,35.0,3,1.0,0.0,0.0,0.01,10.0,1.0,0.0,0.0,15,5,0.0,0.0,166.0,-2.0,0.0,0.0,166.0,0.0,128.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,99,1,112.0,16.0,0.0,-8.0,16.0,17.0,0.0,-8.0,0.0,3.0,0.0,1.0,0.0,-1.0,0.0,0.0,3,0.0,900.0,48.0,80.0,-0.25,-0.5,0.0,-4/10000,0.0,0.0,50.0,2.5,0.09,-0.03,1.0,12,0.0,4.0,2.0,10.0,-0.026,-0.014,-0.017,0.005,0.003,-0.007,0.017,0.012,0.0,32.0,0.0,32.0,249.0,5,5.0,0.0,0.0,0.0,129.0,-2.0,129.0,0.0,128.0,0.0,0.0,0.0,0.0,0.0,128.0,0.0,128.0,-2.0,99,6,9,0.0,false,9,8.0,true,8,1.0,0.0,1,80.0,16.0,0.0,0.0,16.0,16.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,5,0.0,5.0,0.0,0.0,129.0,-4.0,129.0,0.0,128.0,0.0,0.0,2.0,0.0,0.0,129.0,0.0,128.0,0.0,99,1,80.0,4.0,0.0,47.0,16.0,12.0,0.0,0.0,0.0,7.0,0.0,-1.0,0.0,0.0,0.0,0.0,3,0.0,50.0,148.0,48.0,0.5,0.0,0.0,0.0,-0.001,3/10000,700.0,4.0,-1.1,0.15,1.0,4,22.0,0x6f00,0x7dc0,9,8.0,true,1,80.0,0.0,0.0,118.0,16.0,4.0,0.0,0.0,0.0,4.0,0.0,-1.0,0.0,0.0,0.0,0.0,99,1,80.0,4.0,0.0,32.0,16.0,12.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,3,1.0,7/10000,0.0,3/10000,1500.0,4.0,1.07,0.03,4,22.0,0x6f00,0x7dc0,12,0.0,3.0,1.0,51.0,-0.026,-0.014,-0.017,0.005,0.003,-0.007,0.017,0.012,96.0,6.0,0.0,32.0,249.0,9,8.0,true,1,80.0,0.0,0.0,96.0,16.0,4.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,99,9,8.0,true,1,80.0,4.0,0.0,32.0,16.0,5.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,1,66.0,20.0,210.0,28.0,13.0,7.0,210.0,0.0,1.0,0.0,-1.0,0.0,0.0,0.0,-200.0,0.0,1,80.0,9.0,0.0,72.0,16.0,7.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,2,0.0,1.0,64.0,128.0,0.0,0.0,0.0,0.004,0.005,-0.007,0.0,0.0,0.0,2.0,250.0,1.0,0.0,34.0,125.0,13,2,3,2,4,22.0,0x6f00,0x7dc0,12,0.0,3.0,1.0,51.0,-0.026,-0.014,-0.017,0.005,0.003,-0.007,0.017,0.012,96.0,6.0,0.0,32.0,249.0,1,80.0,0.0,0.0,96.0,16.0,4.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,5,0.0,0.0,0.0,0.0,0.0,0.0,128.0,0.0,0.0,2.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,99,8,14.0,1.0,9,14.0,true,8,2.0,4.0,7,10,8,5.0,7.0,8,1.0,0.0,9,1.0,false,1,64.0,7.0,0.0,152.0,16.0,4.0,0.0,0.0,0.0,1.0,0.0,-1.0,0.0,0.0,0.0,0.0,1,64.0,12.0,0.0,-228.0,16.0,4.0,0.0,96.0,0.0,1.0,0.0,1.0,0.0,0.0,0.0,97.0,10,11,4,16.0,0x7300,0x7a40,8,5.0,4.0,1,112.0,0.0,0.0,32.0,16.0,12.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,5,1.0,0.0,0.0,0.0,64.0,-1.0,128.0,0.0,64.0,1.0,0.0,2.0,0.0,0.0,128.0,0.0,128.0,0.0,99,1,96.0,16.0,0.0,0.0,16.0,16.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,3,0.0,5000.0,64.0,96.0,0.0,0.0,0.0,0.009,0.011,-0.005,2000.0,40.0,0.0,0.0,2.0,4,23.0,0x7380,0x7fc0,5,7.0,0.0,64.0,-1.0,64.0,-1.0,64.0,1.0,64.0,1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,99,16,2,0.0,150.0,60.0,36.0,0.0,0.0,0.0,0.004,0.005,-0.007,0.0,0.0,0.0,1.0,150.0,0.0,0.0,35.0,125.0,13,2,4,2,17,15,5,0.0,7.0,129.0,-2.0,0.0,0.0,129.0,0.0,128.0,0.0,0.0,1.0,0.0,1.0,128.0,-1.0,128.0,-1.0,99,99}
function _init()


part_ptr=1

displaylist={}
updatelist={}
dlist=1
ulist=1


curtimer = 1
curpart = 1
loopmode = false
init = true
curpattern = true
cursong = 0

--part transitions
transition = false
transpos={}
transadd={}
transtimer = 0
transposbuf={}
transaddbuf={}

--map layer manager
layerxmap={}
layerymap={}
layerxpos={}
layerypos={}
layerxsize={}
layerysize={}
layerxposreset={}
layeryposreset={}
layerxspeed={}
layeryspeed={}
layerxtemp={}
layerytemp={}
layerxposadd={}
layeryposadd={}
layerxmapadd={}
layerymapadd={}
layerxposmax={}
layeryposmax={}
layernumber = 0


-- sun shade
sunx = 0
suny = 0
sundist1 = 0
sundist2 = 0

-- vector bobs/vector arrays
shadestart = 0



threedx ={}
threedy ={}
threedz ={}

artx = {}
arty = {}
artz = {}
artc = {}
artm = {}
artp = {}



tempc = 0
tempm = 0

bobmesh = {}
maxballs = 0
bobmath = {}

-- filled vectors
trilistm = {}
trilistc = {} 
tempx = {}
tempy = {}
tempz = {}
tricol = {}
trimath = {}
trisize = 0

shade = {7,15,10,9,4,5,2,1}
blenk = 0

-- water effect
smain1 = 0
smain2 = 0
sadd1 = 0
sadd2 = 0
waterfig = {}

-- landscape

ydist = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5,6,6,6,6,6,6,6,6,6,7,7,7,7,7,7,7,7,7}
xdist = {0,1,1,1,1,1,2,2,2,2,2,2,2,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4} 
oland = 0

-- vertical rasters
vl = -1
x1 = 0.4
x2 = 0.3
b1 = 0.7
b2 = 0.4
tx = 0
angle = 0
sprx={}
spry={}
sprs={}

-- pallete info
palswapfrom = {}
palswapto = {}
palttable = {}
paltset = {}

-- plasma
plasmax={}
plasmay={}
plasdata={}

ycalc1 = 0
ycalc2 = 0
xcalc1 = 0
xcalc2 = 0
yseed1 = 0
yseed2 = 0
xseed1 = 0
xseed2 = 0

ready = 0

-- scroller
siney = {}

bigx = 0
bigy = 0
bigpix = 7
bigpiy = 0
bigpiy2 = 0.3
bigstart1 = 0.5
bigstart2 = 1.4

-- mirror copy
offsety = 0
offsetpos = 0


-- misc. inits

cc = 0
cn = 1

q = 0
v = 0

 for q=0,7 do
 
  for y=0,7 do

   for x = 0,4 do
  
   poke(0x4300+512*flr((0+q)/16)+(band((0+q),15)*4)+(y*64)+x,peek(0x0000+512*flr((248+q)/16)+(band((248+q),15)*4)+(y*64)+x))
  
   end
  
  end
 
 end
 
music(0,4000)


end


function _draw()

 
 cls()
 pal()
 palt() 

 currentmap = 1    
 currentpal = 0
 currentpalt = 0
 
 
 
 for i=1,dlist do
		
  if (displaylist[i] == 1) then
  mapmanagerdraw(currentmap)
  currentmap = currentmap + 1
  end

  if (displaylist[i] == 2) then
   vectorupdate(1,maxballs,bobmath[4],bobmath[5],bobmath[6],bobmath[1],bobmath[2],bobmath[3])
   bobcalc() 
   if (bobmath[16] == 1) then  
   bobsadd()
   end
   bobsdraw(bobmath[13])
  end
  
  if (displaylist[i] == 3) then
   vectorupdate(starttri,maxtri,trimath[4],trimath[5],trimath[6],trimath[1],trimath[2],trimath[3])
   vectordraw()
   vectorcalc()
  end

  if (displaylist[i] == 4) then
   water()
  end

  if (displaylist[i] == 5) then
  transitionupdate()
  end 
  
  if (displaylist[i] == 6) then
   landscape()  
  end

  if (displaylist[i] == 7) then
   drawvertical()
  end

  if (displaylist[i] == 8) then
   currentpal = currentpal + 1
   pal(palswapfrom[currentpal],palswapto[currentpal])  
  end

  if (displaylist[i] == 9) then
   currentpalt = currentpalt + 1  
   palt(palttable[currentpalt],paltset[currentpalt])
  end
  
  if (displaylist[i] == 10) then
   pal()
  end  

  if (displaylist[i] == 11) then
   palt()
  end

  if (displaylist[i] == 12) then
   plasmadraw()
  end
  
  if (displaylist[i] == 15) then
   drawscroll()
  end

  if (displaylist[i] == 16) then
   mirrorcopystart()
  end
  
  if (displaylist[i] == 17) then
   mirrorcopyend()
  end
   
 end
 
  
 
end





function _update()

 demosystemupdate()

   if (layernumber > 0) then  
   mapmanagerupdate()
   end
   
 for i=1,ulist do
  if (updatelist[i] == 7) then
   updatevertical()
  end
  if (updatelist[i] == 12) then
   plasmaupdate()
  end  
  if (updatelist[i] == 15) then
   updatescroll()
  end
 end


 
end



function demosystemupdate()

 if (stat(20) > 0 and curpattern == true) then
 curpattern = false
 end
	 
	if (stat(20) == 0 and curpattern == false) then
	curtimer = curtimer + 1
	cursong = cursong + 1
	curpattern = true	
		
		if (curtimer > part_duration[curpart]) then
	 curpart = curpart + 1
	 curtimer = 1
	 init = true
  	 
	    if (part_duration[curpart] == 255) then
	    curpart = curpart - 1
	    loopmode = true
	    end	        
	 end 
	end 

 if (init == true and loopmode == false) then
  initpart() 
  for i=1,4 do
	 transpos[i]=transposbuf[i+4]
	 transadd[i]=transaddbuf[i+4]
	 end  
  transtimer=64 
  transcolor = transaddbuf[9]  
 init = false
 end

 if (part_duration[curpart+1] != 255 and part_duration[curpart]-curtimer == 0 and stat(20) > 7 and transition == false) then 
    for i=1,4 do
	   transpos[i]=transposbuf[i]
	   transadd[i]=transaddbuf[i]
	   end 
    transcolor = transposbuf[9] 
				transtimer = 100
				transition = true
 end
 	
end

function water()
 
 for i=0,waterfig[1] do
 p = flr((sin(smain1)*2.3)+(sin(smain2)*2.6))
 

 memcpy(waterfig[3]-(i*64),waterfig[2]+((i+p)*64),64) 
 
 
 smain1 = smain1 + 0.075
 smain2 = smain2 - 0.15
 end
 

 sadd1 = sadd1 + 0.034
 sadd2 = sadd2 + 0.009
 
 smain1 = sadd1
 smain2 = sadd2
 
end


function transitionupdate()
	if (transition == true) then

 for i=1,4 do
 transpos[i]=transpos[i]+transadd[i]
 end
 color(transcolor)
 rectfill(transpos[1],transpos[2],transpos[3],transpos[4])
	
	end 

 transtimer = transtimer -1 
 if (transtimer == 0) then
  transition = false
	end

end

function mapmanagerdraw(cm)
 
  map(layerxmap[cm],layerymap[cm],layerxpos[cm],layerypos[cm],layerxsize[cm],layerysize[cm])

end

function mapmanagerupdate()
 
	for i=1,layernumber do
 
  layerxtemp[i]=layerxtemp[i]+1
  if (layerxtemp[i] > layerxspeed[i]) then
   layerxtemp[i]=0
   layerxpos[i]=layerxpos[i]+layerxposadd[i]
   if (layerxpos[i] == layerxposmax[i]) then
   layerxpos[i]=layerxposreset[i]
   layerxmap[i]=layerxmap[i]+layerxmapadd[i]    
   end  
  end  
  layerytemp[i]=layerytemp[i]+1
  if (layerytemp[i] > layeryspeed[i]) then
   layerytemp[i]=0
   layerypos[i]=layerypos[i]+layeryposadd[i]
   if (layerypos[i] == layeryposmax[i]) then
   layerypos[i]=layeryposreset[i]
   layerymap[i]=layerymap[i]+layerymapadd[i]    
   end  
  end    

 end
 
end

function plasmadraw()
if ready == 1 then

	resgfx = plasdata[3]*4

	ypos = plasdata[13]

 if (plasdata[4] == 51) then
 
 	for y=1,plasdata[14],plasdata[3] do
 	xpos = plasdata[15]

	 	for x=1,plasdata[16],plasdata[3] do
	 	this = (plasmax[x]+plasmay[y])*3				
	  if (this > plasdata[1] and this <= plasdata[2]) then
	  spr (248+this,xpos,ypos)
	 	end
		
	 	xpos = xpos + resgfx
	 	end
 	ypos = ypos + resgfx
 	end
 else
 	for y=1,plasdata[14],plasdata[3] do
 	xpos = plasdata[15]

 		for x=1,plasdata[16],plasdata[3] do
 		this = (plasmax[x]+plasmay[y])*3				
 	 if (this > plasdata[2]) then this = plasdata[2] end
 	 if (this < plasdata[1]) then this = plasdata[1] end
 	 spr (248+this,xpos,ypos)	
 		xpos = xpos + resgfx
 		end
 	ypos = ypos + resgfx
	 end 
 end
 ready = 0
 end
end

function plasmaupdate()
if ready == 0 then
 
	for y=1,plasdata[14] do 
	plasmay[y] = sin(ycalc1)+sin(ycalc2)
	ycalc1 = ycalc1 + plasdata[5]
	ycalc2 = ycalc2 + plasdata[6]
	end
	for x=1,plasdata[16] do 
	plasmax[x] = sin(xcalc1)+sin(xcalc2)
	xcalc1 = xcalc1 + plasdata[7]
	xcalc2 = xcalc2 + plasdata[8]
	end
 xseed1 = xseed1 + plasdata[9]
 xseed2 = xseed2 + plasdata[10]

 yseed1 = yseed1 + plasdata[11]
 yseed2 = yseed2 + plasdata[12]

	xcalc1 = xseed1
	xcalc2 = xseed2
	ycalc1 = yseed1
	ycalc2 = yseed2
	   
 ready = 1
	end

end




function bobsdraw(bobtype)

 -- bobs no z difference
 if (bobtype == 0) then
  for i=maxballs,1,-1 do
 	
 
  spr (artp[artm[i]],artx[artm[i]],arty[artm[i]])
  end
 end

 -- bobs with z distance
 if (bobtype == 1) then
 temp = (bobmath[1]/(bobmath[1]/2.45))
 
  for i=maxballs,1,-1 do

	 	        
	 tempzoom = flr((artz[artm[i]])/3.9) 
  
  	if (tempzoom < 0) then
  	   tempzoom = 0
  	end
  	if (tempzoom > 3) then
     tempzoom = 3
  	end

   spr (artp[artm[i]]+tempzoom,artx[artm[i]],arty[artm[i]])
   end
  
 end

 -- bobs with sun shading   
 if (bobtype == 2) then
  for i=maxballs,1,-1 do

	 tempzoom = -artz[artm[i]]/2 
	 
  
  	if (tempzoom < 0) then
  	   tempzoom = 0
  	end
  	if (tempzoom > 3) then
     tempzoom = 3
  	end
 	
	  
	 sunval = 0
   if (artx[artm[i]] < sunx) then
    sunval = sunx-artx[artm[i]]
   else
    sunval = artx[artm[i]] - sunx
   end
  sunval2 = 0  
   if (arty[artm[i]] < suny) then
    sunval2 = suny-arty[artm[i]]  
   else
    sunval2 = arty[artm[i]] - suny
   end
 
   
   maxdrift = 80 
   if (sunval2 < maxdrift and sunval < maxdrift) then
    sunval2 = sunval2 /6.7  
    sunval = sunval /11.7
    sunval = sunval /tempzoom  
   else
   sunval2 = 7
   sunval = 7
   end

   p = bobmath[17]-(sunval2+sunval)
   if (p< (bobmath[17])-7) then p = bobmath[17]-7 end
     
   spr (p,artx[artm[i]],arty[artm[i]])

   end

 bobmath[2] = 64+sin(bobmath[6])*32
 bobmath[3] = shadestart+sin(bobmath[4])*16
 
 if (shadestart > 64) then
   shadestart = shadestart - 0.5
 end
 
 sunx = 64+sin(bobmath[4])*32
 suny = 48+sin(bobmath[5])*32
 spr(78,sunx,suny)
 
 if (cursong > 37) then
 bobmath[14] = 500
 bobmath[15] = 10
 end
 
 end
   
end

function bobsadd()
	for i=1,maxballs do
	 threedz[i] = threedz[i] + bobmath[12]
	 threedy[i] = threedy[i] + bobmath[11]
	 threedx[i] = threedx[i] + bobmath[10]
 	
 	if (threedz[i] < -20) then
 	  threedz[i] = 20
 	end
 	if (threedz[i] > 20) then
 	  threedz[i] = -20
 	end
 	if (threedx[i] < -20) then
 	  threedx[i] = 20
 	end
 	if (threedx[i] > 28) then
 	  threedx[i] = -28
 	end
 	if (threedy[i] < -28) then
 	  threedy[i] = 28
 	end
 	if (threedy[i] > 30) then
 	  threedy[i] = -30
 	end
 end
end

function bobcalc()

 bobsort()

 if (bobmath[1] < bobmath[14]) then
 bobmath[1] = bobmath[1] + bobmath[15]
 end
 if (bobmath[1] > bobmath[14]) then
 bobmath[1] = bobmath[1] - bobmath[15]
 end

  
 bobmath[4] = bobmath[4] + bobmath[7]
 bobmath[5] = bobmath[5] + bobmath[8]
 bobmath[6] = bobmath[6] + bobmath[9]
  
end

 
function vectorcalc()

 if (trimath[1] < trimath[10]) then
 trimath[1] = trimath[1] + trimath[11]
 end
 if (trimath[1] > trimath[10]) then
 trimath[1] = trimath[1] - trimath[11]
 end

 
 trimath[4] = trimath[4] + trimath[7]
 trimath[5] = trimath[5] + trimath[8]
 trimath[6] = trimath[6] + trimath[9]
 
 trimath[2] = trimath[2] + trimath[12]
 trimath[3] = trimath[3] + trimath[13]

end

function vectordraw() 


 p = starttri
 for i=1,trisize do

 trilistc[i]=(artz[p]+artz[p+1]+artz[p+2])

 trilistm[i]=p
 p = p + 3
 end
 
 vectorsort(1,trisize+1)

  
 
 if (blenk == 0) then
   for i=1,trisize do
    color(tricol[1+(trilistm[i]-starttri)/3])
    drawtriangle(trilistm[i])  
   end
 else
  for i=1,trisize do
   sunval = 0
   if (artx[trilistm[i]] < sunx) then
    sunval = sunx-artx[trilistm[i]]
   else
    sunval = artx[trilistm[i]] - sunx
   end
   sunval = sunval /9.4 
   if (sunval > 7) then
   sunval = 7
   end
   color(shade[1+flr(sunval)])
   drawtriangle(trilistm[i])  
  end 
 end
  
  if (cursong > 50) then 
  blenk = 1
  trimath[11] = 0
  spr(78,sunx,suny)
  sunx = 64+sin(trimath[4])*64
  suny = 64+sin(trimath[6])*64
  trimath[2] = 64+sin(trimath[5])*32
  trimath[3] = 64+sin(trimath[6])*32
  trimath[1] = 1500+sin(trimath[4])*1000
  end
  
end


function vectorupdate(sstart,ssend,lrotx,lroty,lrotz,realzoom,xoffset,yoffset)	
	

	for i=sstart,ssend do
	
	x2 = (threedx[i] * cos(lrotz)) - (threedy[i]*sin(lrotz))
	y2 = (threedx[i] * sin(lrotz)) + (threedy[i]*cos(lrotz))
	z2 = (x2 * sin(lroty)) + (threedz[i] * cos(lroty))
	x3 = (x2 * cos(lroty)) - (threedz[i] * sin(lroty))
	y3 = (y2 * cos(lrotx)) - (z2 * sin(lrotx))
	artz[i] = ((y2 * sin(lrotx)) + (z2 * cos(lrotx))) 
	artx[i] = (realzoom * (x3 / (artz[i]+40)))+xoffset
	arty[i] = (realzoom * (y3 / (artz[i]+40)))+yoffset

 artc[i] = artz[i]
 artm[i] = i
	end

end

function bobsort()
 gap = maxballs
 shrink = 1.25

 swapped = true

 checkout = true

 while (checkout == true) do
  if (gap == 1 and swapped == false) then
  checkout = false
  break
  end

  temp = gap/shrink
  gap = flr(temp)
   if (gap < 1) then
   gap = 1
   end

  i=1
  swapped = false
  checkin = true
  while (checkin == true) do
   if (i+gap >= maxballs) then
   checkin = false
   end 
   if (artc[i] > artc[i+gap]) then
    tempc = artc[i]
    tempm = artm[i]
    artc[i] = artc[i+gap]
    artm[i] = artm[i+gap]
    artc[i+gap] = tempc
    artm[i+gap] = tempm
    swapped = true
   end
  i = i + 1
  end 
 end

end 

function drawtriangle(offset)
 
 drawme = false

 for i =1,3 do
 tempx[i] = artx[(offset-1)+i] 
 tempy[i] = arty[(offset-1)+i]
 tempz[i] = artz[(offset-1)+i]
 end

 
 d1x = tempx[3] - tempx[1]
 d1y = tempy[3] - tempy[1]
 d2x = tempx[3] - tempx[2]
 d2y = tempy[3] - tempy[2]
 
  
 z = (d1x*d2y) - (d1y * d2x)
 

  if z > 0 then 
  drawme = true
 end

 if (drawme == true) then

 if (tempy[2] > tempy[3]) then
  tempx[4] = tempx[2]
  tempy[4] = tempy[2]
  tempx[2] = tempx[3]
  tempy[2] = tempy[3]
  tempx[3] = tempx[4]
  tempy[3] = tempy[4]
 end
 if (tempy[1] > tempy[2]) then
  tempx[4] = tempx[1]
  tempy[4] = tempy[1]
  tempx[1] = tempx[2]
  tempy[1] = tempy[2]
  tempx[2] = tempx[4]
  tempy[2] = tempy[4]
 end
 if (tempy[2] > tempy[3]) then
  tempx[4] = tempx[3]
  tempy[4] = tempy[3]
  tempx[3] = tempx[2]
  tempy[3] = tempy[2]
  tempx[2] = tempx[4]
  tempy[2] = tempy[4]
 end

 trifound = false
 if (tempy[2] == tempy[3]) then
  fillbottomtri(1,2,3)
  trifound = true
 end
 if (tempy[1] == tempy[2] and trifound == false) then 
  filltoptri(1,2,3)
  trifound = true
 end  
 
 if (trifound == false) then

 
  tempx[4] = (tempx[1]+((tempy[2]-tempy[1]) / (tempy[3]-tempy[1])) * (tempx[3]-tempx[1]))
  tempy[4] = tempy[2]
  

  fillbottomtri(1,2,4)
  filltoptri(2,4,3)   
 end

 end


end

function fillbottomtri(v1,v2,v3)
 invslope1 = (tempx[v2]-tempx[v1]) / (tempy[v2]-tempy[v1])
 invslope2 = (tempx[v3]-tempx[v1]) / (tempy[v3]-tempy[v1])
 curx1 = tempx[v1]
 curx2 = tempx[v1]

   
  for i=tempy[v1],tempy[v2] do 
  
  rectfill (curx1,i,curx2,i+1)

  
  curx1 = curx1 + (invslope1)
  curx2 = curx2 + (invslope2)
 
  
  end
 
 

end


function filltoptri(v1,v2,v3)
 invslope1 = (tempx[v3]-tempx[v1]) / (tempy[v3]-tempy[v1])
 invslope2 = (tempx[v3]-tempx[v2]) / (tempy[v3]-tempy[v2])
 curx1 = tempx[v3]
 curx2 = tempx[v3]


  
 for i=tempy[v3],tempy[v1],-1 do 


 rectfill (curx1,i-1,curx2,i+1)

  curx1 = curx1 - invslope1
  curx2 = curx2 - invslope2
 end


end


function vectorsort(sstart,ssend)

 gap = ssend 
 shrink = 1.29 

 swapped = true

 checkout = true

 while (checkout == true) do
  if (gap == sstart and swapped == false) then
  checkout = false
  end

  temp = gap/shrink
  gap = flr(temp)
   if (gap < 1) then
   gap = 1
   end

  
  i=sstart
  swapped = false
  checkin = true
  while (checkin == true) do
   if (i+gap >= ssend) then
   checkin = false
   else
   if (trilistc[i] > trilistc[i+gap]) then
    tempc = trilistc[i]
    tempm = trilistm[i]
    trilistc[i] = trilistc[i+gap]
    trilistm[i] = trilistm[i+gap]
    trilistc[i+gap] = tempc
    trilistm[i+gap] = tempm
    swapped = true
   end
   end
  i = i + 1
  end 
 end
   
end   

function mirrorcopystart()

color(7)
rectfill(0,0,128,128)

  offsety = offsety-1
  if (offsety < -31) then
    offsety = 0
    offsetpos = offsetpos +1
    if (offsetpos > 3) then
    offsetpos = 0
    end
  end  
 
  
     
end


function mirrorcopyend()

  for i=0,63 do
  memcpy(0x1800+(i*64),0x6618+(i*64),16)
  end

map(60,08,0,offsety,4,20)
map(60,09,32,offsety,4,20)
map(60,10,64,offsety,4,20)
map(60,11,96,offsety,4,20)

	bobmath[1] = 224+(sin(bobmath[6])*96) 


end

function landscape()
rectfill(0,0,128,64,12)
p = sin(sundist1)*4
rectfill(0,48+p,128,52+p,13)
rectfill(0,52+p,128,128,1)

layerypos[1]=6-p+(sin(sundist2)*1.6)

sun = 64+((sin(sundist1)*sin(sundist2))*64)
suny = 16+(sin(sundist1)*8)
spr(78,sun,suny)
sundist1 = sundist1 + 0.03
sundist2 = sundist2 + 0.005


 ystart = 48
 d = 0
	for y=1,35 do
	
 xstart1 = 0
 xstart2 = 127
 
   q = 1
	  for x=1,16 do
	   tempfy = ystart
	   h = peek(0x4300+((flr(oland)+y)*16)+q)
	 
	      //v = h 
	      //dl = h
	      v = (((x*16)+64 - sunx) * 2.3) * ((suny/32)/y)/4.1
	      dl = v/1.55  
	      
	      if (v < 1) then 
	      p=6+flr((sunx-128)/32)
	      v = p  end
	      if (v > 7) then v = 7 end
	  	   if (dl < 1) then dl = p*1.3 end
	      if (dl > 7) then dl = 7 end
	  	   
	  	   
	  	   for l=1,h do	   
	  	    
	  	  
	 	   	spr(v+248,xstart1,tempfy)
    	   	  	
      	spr(dl+248,xstart2,tempfy)
   	 
   	   
   	   
   	   
      	tempfy = tempfy - ydist[y]*1.3//(suny/16)
      	end
   	
 xstart1 = xstart1 -(sin(x/32)*6) //*6  	  
 xstart2 = xstart2 +(sin(x/32)*6) 
     q = q + 1
   end
   
	ystart = ystart + ydist[y]
	
	end

  oland = oland - 0.5
  if (flr(oland) < 0) then oland = 148
  end

end 
 
function initpart()

 nextpart = 0
 dlist = 1
 ulist = 1
 layernumber = 0
 palnumber = 0
 paltnumber = 0
 for i=1,16 do
  displaylist[i] = 0
  updatelist[i] = 0
 end
 while (nextpart != 99) do
  nextpart = getpartdata()
	 if (nextpart == 1) then
 	  layernumber = layernumber + 1

  layerxmap[layernumber] = getpartdata()
  layerymap[layernumber] = getpartdata()
  layerxpos[layernumber] = getpartdata()
  layerypos[layernumber] = getpartdata()
  layerxsize[layernumber] = getpartdata()
  layerysize[layernumber] = getpartdata()
  layerxposreset[layernumber] = getpartdata()
  layeryposreset[layernumber] = getpartdata()
  layerxspeed[layernumber] = getpartdata()
  layeryspeed[layernumber] = getpartdata()
  layerxtemp[layernumber] = 0
  layerytemp[layernumber] = 0
  layerxposadd[layernumber]= getpartdata()
  layeryposadd[layernumber]= getpartdata()
  layerxmapadd[layernumber]= getpartdata()
  layerymapadd[layernumber]= getpartdata()
  layerxposmax[layernumber]= getpartdata()
  layeryposmax[layernumber]= getpartdata() 	   
	 setdisplaylist(1)
	 elseif (nextpart == 2) then
   shadestart = 100
   q = 1
	  skip = getpartdata()
	  if (skip == 1) then q = 7
	   -- last minute hardcode... 
	   for i=1,maxballs do
	   artp[i] = 35+(flr(rnd(4))*4) 
	   end
	  
	  end
		 
   for i=q,17 do
   bobmath[i] = getpartdata()
   end
   
   if (skip != 1) then
   
   maxballs = getpartdata()
   bl = 1
  	for i=1,maxballs do
   artx[bl] = 0
   arty[bl] = 0
   artz[bl] = 0
   artm[bl] = 1
   artc[bl] = 0	
   bl = bl + 1	
	  end 
  end
	   setdisplaylist(2)
	 elseif (nextpart == 3) then
   q = 1
	  skip = getpartdata()
	  if (skip == 1) then q = 7 end
		 
   for i=q,13 do
   trimath[i] = getpartdata()
   end
   
   if (skip != 1) then
   meshnum = getpartdata() 
   trisize = meshsize[meshnum]
   starttri = maxballs+1
   maxtri = starttri-1+(trisize*3)
   q = starttri
   v = 0
   foreach(mesh[meshnum],putvecarray)
   q = 1
   foreach(meshcol[meshnum],putveccol)
   end      
	   setdisplaylist(3)
	 elseif (nextpart == 4) then
   	for i=1,3 do
   	waterfig[i] = getpartdata()
    end
 	  setdisplaylist(4)
  elseif (nextpart == 5) then
	   transposbuf[9] = getpartdata()
    transaddbuf[9] = getpartdata()
    for i=1,8 do
    transposbuf[i] = getpartdata()
    transaddbuf[i] = getpartdata()
    end
    setdisplaylist(5)
  elseif (nextpart == 6) then
 for i=0,480 do
 poke(0x1e20+i,0)
 end
 
 for q=0,7 do
 
  for y=0,7 do

   for x = 0,4 do
  
   poke(0x0000+512*flr((248+q)/16)+(band((248+q),15)*4)+(y*64)+x,peek(0x4300+512*flr((0+q)/16)+(band((0+q),15)*4)+(y*64)+x))
  
   end
  
  end
 
 end
  


 p = 36
 z = 2
 for y=0,6000 do 
 p = p + 0.032 
 z = z + 0.029 
 l = (sin(p)*sin(z))*9
 if (l > 9) then l = 9 end
 if (l < 0) then l = 0 end
 
 poke(0x4300+y,l)
 
 end
    setdisplaylist(6)    
  elseif (nextpart == 7) then
  sprx = {16,96,34,119,55,77,11,60}
  spry = {40,100,88,34,97,18,55,26}
  sprs = {1,2,2,1,2,2,1,1}
   for y=0,1023,64 do
	   for x=0,59 do
	   poke (5632+x+y,0x00) 
	   end
   end 
    setdisplaylist(7)
    setupdatelist(7)
  elseif (nextpart == 8) then
    palnumber = palnumber + 1
    palswapfrom[palnumber] = getpartdata()
    palswapto[palnumber] = getpartdata()
    setdisplaylist(8)
  elseif (nextpart == 9) then
    paltnumber = paltnumber + 1
    palttable[paltnumber] = getpartdata()
    paltset[paltnumber] = getpartdata()
    setdisplaylist(9)
  elseif (nextpart == 12) then
 xseed1 = 0
 xseed2 = 0
 yseed1 = 0
 yseed2 = 0

 for i=1,32 do
 plasmax[i] = 0
 plasmay[i] = 0
 end
 
 for i=1,17 do
 plasdata[i] = getpartdata()
 end
 

 for q=0,plasdata[2] do
 
  for y=0,7 do

   for x = 0,4 do
  
   poke(0x0000+512*flr((plasdata[17]+q)/16)+(band((plasdata[17]+q),15)*4)+(y*64)+x,peek(0x0000+512*flr((plasdata[4]+q)/16)+(band((plasdata[4]+q),15)*4)+(y*64)+x))
  
   end
  
  end
 
 end    
    setdisplaylist(12)
    setupdatelist(12)     
  elseif (nextpart == 13) then
  meshtype = getpartdata()
  meshpaint = getpartdata()
  
  if (meshtype == 1) then
  for i = 1,maxballs do
    threedx[i] = -16+rnd(32)
    threedy[i] = -16+rnd(32)
    threedz[i] = -28+rnd(56)
    artp[i] = bobmath[17]
  end
  end

  if (meshtype == 2) then
  meshmul = getpartdata()
  q = 1
   for z=-meshmul,meshmul do
    for y=-meshmul,meshmul do
     for x=-meshmul,meshmul do
     threedx[q] = x
     threedy[q] = y
     threedz[q] = z
     artp[q] = bobmath[17]+(flr(rnd(meshpaint))*4)
     q = q + 1
     end
    end
   end    
  end    
  elseif (nextpart == 15) then
    setdisplaylist(15)
    setupdatelist(15)
    bigx = -20
  else
    setdisplaylist(nextpart)
  end
  
  
 end
 
end









function putvecarray(value)
 v = v + 1
 if (v == 1) then threedx[q] = value end
 if (v == 2) then threedy[q] = value end
  if (v == 3) then 
  threedz[q] = value
  q = q + 1
  v = 0
  end
end

function putveccol(value)
 if (meshnum == 1) then
 tricol[q] = value
 else
  -- yes i'm sorry about this..
  for v=q,q+79 do
  tricol[v] = 1 
  end
 end
 q = q + 1
end
   





function drawvertical()

  rectfill(0,0,127,80+sin(b1)*8,9)
  rectfill(0,68-sin(b2)*4,127,103,8)
  
	 for x=0,59 do
	 poke (5632+x,0xee) 
	 end
  
	 for y=5,8 do
	   spr(41,sprx[y],spry[y])
	 end

  if (cursong > 44) then
  angle = sin(x1)*sin(b2)*0.5
  end
  tx = 0
 
  x1 = b1
  x2 = b2
  for y=vl,-1,-1 do 
	 d = 5660+flr(sin(x1)*sin(x2)*29)		 
		poke (d,0xc1) 
		poke (d+1,0x77)
	 poke (d+2,0x77)
		poke (d+3,0x89)
 

		map (64,0,tx,y,15,1)
		tx = tx + angle
		x1 = x1 - 0.003
		x2 = x2 + 0.014
		end
		b1 = b1 + 0.01
		b2 = b2 - 0.015
	 for y=1,4 do
	   spr(39,sprx[y],spry[y])
	 end 
  	
end

function updatevertical()
 
 for y=1,8 do
	   spry[y] = spry[y] - sprs[y]
				 if (spry[y] < -16) then 
	  		spry[y] = 110
			  sprx[y] = rnd(128)
					end
	end
	if (cursong > 42) then
 if (vl < 90) then
 vl = vl +1
 end
 end
 
end	


function drawscroll()

  for q=0,17 do
  map(bigx+q,16,-8+(q*8)+bigpix,siney[q+1],1,16)
  
  end

  bigpix = bigpix-1
  if (bigpix < 0) then
  bigpix = 7
  bigx = bigx + 1  
  end
end

function updatescroll()
  for q=0,17 do

 siney[q+1] = siney[q+2]
 
  end
  
  
  siney[18] = ((sin(bigpiy)+sin(bigpiy2))*16)

  bigpiy = bigpiy - 0.005 
  bigpiy2 = bigpiy2 + 0.03  
end

  	
function setdisplaylist(ptype)
  displaylist[dlist] = ptype
  dlist = dlist +1
end

function setupdatelist(ptype)
  updatelist[ulist] = ptype
  ulist = ulist +1
end
   
function getpartdata()

   a= part_data[part_ptr]
   part_ptr=part_ptr+1
   
   return a
 
end
