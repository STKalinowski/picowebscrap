-- terrain renderer
-- by j-fry

--do what the fuck you want to public license
--version 2, december 2004
--
--copyright (c) 2015 julien fryer
--
--everyone is permitted to copy and distribute verbatim or modified
--copies of this license document, and changing it is allowed as long
--as the name is changed.
--
--do what the fuck you want to public license
--terms and conditions for copying, distribution and modification
--
--0. you just do what the fuck you want to.

nb_maps = 4
map_names = {}
map_names[1] = "island"
map_names[2] = "cliffs"
map_names[3] = "volcano"
map_names[4] = "atoll"

nb_filters = 5
filter_names = {}
filter_names[1] = "flat"
filter_names[2] = "small noise"
filter_names[3] = "big noise"
filter_names[4] = "small ordered"
filter_names[5] = "big ordered"

nb_palettes = 4
palette_names = {}
palette_names[1] = "tropical"
palette_names[2] = "arctic"
palette_names[3] = "oasis"
palette_names[4] = "mars"

current_map = 0
current_light_filter = 1
current_terrain_filter = 2
current_palette = 0

heightmapy = 0 -- 1 for debug
nb_vertices = 32 -- along an axis
vertices = {}

-- linear z buffer with 8 bits precision (4 pixels per int)
zbuffer = {}
min_z = 0
max_z = 0

scale_xy = 1.0
scale_z = 1.5
inv_scale_z = 1 / scale_z

camera_changed = true
cam_speed_angular = 0.01
cam_speed = 0.3
camera_z = 0
cam_angle_x = 0
cam_angle_y = 0.15

light_changed = true
light_intensity = 0.7 -- not exposed
light_angle_x = -0.25
light_angle_y = 0.05
light_x = 1
light_y = 0
light_z = 0

cam_cos_x = 0
cam_sin_x = 0
cam_cos_y = 0
cam_sin_y = 0

horizon_y = 0
horizon_dist = 200

-- 0 : camera mode
-- 1 : light mode
mode = 0
menuon = false
infoon = true
menu_index = 0

byte_mask = shr(0xff,16)

-- 0 : initialization
-- 1 : computation
-- 2 : blend result
-- 3 : done
rasterizer_mode = 0
-- current triangle rasterized
rasterizer_index = 0
max_pixel_rasterized = 500

-- where to store the raster
frame_chunk_0 = 0x2000 -- map memory
frame_chunk_1 = 0x4300 -- user defined memory

sea_color = 0
sky_color = 0

near_plane = 1

-- todo fetch that from sprite data along with palette ?
-- slope
slope_normal_threshold = 0.5
slope_normal_dispersion = 0.05

-- for low slopes
-- sand then grass the snow
sand_height_threshold = 1.5
sand_height_dispersion = 1.0
snow_height_threshold = 9
snow_height_dispersion = 3

-- for high slopes
-- dirt then rock
rock_height_threshold = 8
rock_height_dispersion = 2

function is_border(x,y)
	return (x == 1) or (x == nb_vertices) or (y == 1) or (y == nb_vertices)
end

function getnormal(indexx0,indexy0,indexx1,indexy1,indexx2,indexy2)
	local x0 = ((indexx0 - 0.5) * 2 - nb_vertices) * scale_xy
	local y0 = ((indexy0 - 0.5) * 2 - nb_vertices) * scale_xy
	local z0 = vertices[indexx0][indexy0].world_z
	
	local x1 = ((indexx1 - 0.5) * 2 - nb_vertices) * scale_xy
	local y1 = ((indexy1 - 0.5) * 2 - nb_vertices) * scale_xy
	local z1 = vertices[indexx1][indexy1].world_z
	
	local x2 = ((indexx2 - 0.5) * 2 - nb_vertices) * scale_xy
	local y2 = ((indexy2 - 0.5) * 2 - nb_vertices) * scale_xy
	local z2 = vertices[indexx2][indexy2].world_z
	
	local v0x = x1 - x0
	local v0y = y1 - y0
	local v0z = z1 - z0
	
	local v1x = x2 - x0
	local v1y = y2 - y0
	local v1z = z2 - z0
	
	local nx = v0y * v1z - v0z * v1y
	local ny = v0z * v1x - v0x * v1z 
	local nz = v0x * v1y - v0y * v1x

	local invlength = 1 / sqrt(nx * nx + ny * ny + nz * nz)
	local normal = {}
	normal.x = nx * invlength
	normal.y = ny * invlength
	normal.z = nz * invlength
	
	return normal
end

function init_app()
	vertices = {}
	for x = 1,nb_vertices do
		vertices[x] = {}
		for y = 1,nb_vertices do
			vertices[x][y] = {}
		end
	end
	
	for x=1,64 do
		zbuffer[x] = {}
		for y=1,64 do
			zbuffer[x][y] = 0
		end
	end	
end

function init_terrain()

	sea_color = sget(current_palette * 2,0)
	sky_color = sget(current_palette * 2,7)

	for x = 1,nb_vertices do
		local verticesx = vertices[x]
		for y = 1,nb_vertices do
			local currentvertex = verticesx[y]
		
			if is_border(x,y) then
				currentvertex.world_z = -scale_z
				currentvertex.min_z = -scale_z
				currentvertex.nx = 0
				currentvertex.ny = 0
				currentvertex.nz = -1
			else
				local zindex = sget(current_map * 32 + x - 1,32 + heightmapy * 32 + y - 1)
				currentvertex.world_z = zindex * scale_z - scale_z
				
				-- used to render vertices as voxels
				currentvertex.rect_x0 = 0
				currentvertex.rect_y0 = 0
				currentvertex.rect_x1 = 0
				currentvertex.rect_y1 = 0
				
				-- normal
				currentvertex.nx = 0
				currentvertex.ny = 0
				currentvertex.nz = 0
			end
			
			-- projected coordinates
			currentvertex.proj_x = 0
			currentvertex.proj_y = 0
			currentvertex.proj_z = 0
			currentvertex.proj_w = 0
			
			-- projection of the bottom of the voxel
			currentvertex.proj_x0 = 0
			currentvertex.proj_y0 = 0
		end
	end
	
	for x = 2,nb_vertices-1 do
		for y = 2,nb_vertices-1 do
			local n0 = getnormal(x,y,x-1,y,x,y-1)
			local n1 = getnormal(x,y,x,y-1,x+1,y-1)
			local n2 = getnormal(x,y,x+1,y-1,x+1,y)
			local n3 = getnormal(x,y,x+1,y,x,y+1)
			local n4 = getnormal(x,y,x,y+1,x-1,y+1)
			local n5 = getnormal(x,y,x-1,y+1,x-1,y)
			
			local nx = n0.x + n1.x + n2.x + n3.x + n4.x + n5.x
			local ny = n0.y + n1.y + n2.y + n3.y + n4.y + n5.y
			local nz = n0.z + n1.z + n2.z + n3.z + n4.z + n5.z
			
			local invlength = 1 / sqrt(nx * nx + ny * ny + nz * nz)
			local currentvertex = vertices[x][y]
			currentvertex.nx = nx * invlength
			currentvertex.ny = ny * invlength
			currentvertex.nz = nz * invlength
						
			currentvertex.color = 0
			
			local minz = currentvertex.world_z
			minz = min(minz,vertices[x-1][y-1].world_z)
			minz = min(minz,vertices[x][y-1].world_z)
			minz = min(minz,vertices[x+1][y-1].world_z)
			minz = min(minz,vertices[x-1][y].world_z)
			minz = min(minz,vertices[x+1][y].world_z)
			minz = min(minz,vertices[x-1][y+1].world_z)
			minz = min(minz,vertices[x][y+1].world_z)
			minz = min(minz,vertices[x+1][y+1].world_z)
			currentvertex.min_z = max(0,minz)

		end
	end
	
	-- this will trigger computations
	camera_changed = true
	light_changed = true
end

offsetproj = nb_vertices * scale_xy * 1.8
function get_w(projz)
	return projz + offsetproj - camera_z
end

scalesize = scale_xy * 1.415 -- size of a diagonal of a tile in the height map

function transform_terrain()

	for x = 1,nb_vertices do
		local verticesx = vertices[x]
		for y = 1,nb_vertices do
		
			local currentvertex = verticesx[y]
			
			local world_x = ((x - 0.5) * 2 - nb_vertices) * scale_xy
			local world_y = ((y - 0.5) * 2 - nb_vertices) * scale_xy
			local world_z = currentvertex.world_z
			local min_z = currentvertex.min_z
			
			local rot_world_x = world_x * cam_cos_x + world_y * cam_sin_x
			local rot_world_y = -world_x * cam_sin_x + world_y * cam_cos_x
			
			local projx = rot_world_x
			local rotworldycosy = rot_world_y * cam_cos_y
			local projy0 = rotworldycosy + min_z * cam_sin_y
			local projy = rotworldycosy + world_z * cam_sin_y
			local rotworldysiny = rot_world_y * cam_sin_y
			local projz = rotworldysiny - world_z * cam_cos_y
			
			local w = get_w(projz)
			local invw = 64 / w
			currentvertex.proj_x = 64 + projx * invw
			currentvertex.proj_y = 64 + projy * invw
			currentvertex.proj_z = 1 / w
			currentvertex.proj_w = w
			
			local invw0 = 64 / get_w(rotworldysiny - min_z * cam_cos_y)
			currentvertex.proj_x0 = 64 + projx * invw0
			currentvertex.proj_y0 = 64 + projy0 * invw0
			
		end
	end

	for x=2,nb_vertices-1 do
		local verticesx = vertices[x]
		for y=2,nb_vertices-1 do
		
			local currentvertex = verticesx[y]
			local projw = currentvertex.proj_w
			
			if (projw <= near_plane) then --cull
				
				currentvertex.rect_x0 = 0
				currentvertex.rect_y0 = 0
				currentvertex.rect_x1 = 0
				currentvertex.rect_y1 = 0
			
			else

				local currentx = currentvertex.proj_x
				local currenty = currentvertex.proj_y
				local currentx0 = currentvertex.proj_x0
				local currenty0 = currentvertex.proj_y0
				
				local size = scalesize * 64 / projw
				
				currentvertex.rect_x0 = min(currentx - size,currentx0) 
				currentvertex.rect_y0 = currenty  --the min can be ignored as an optimization
				currentvertex.rect_x1 = max(currentx + size,currentx0) 
				currentvertex.rect_y1 = max(currenty,currenty0) + size * 2
	
			end
		end
	end
end

function getlighting(nx,ny,nz)
	return light_intensity * (1 - (nx * light_x + ny * light_y + nz * light_z)) * 0.5 -- normalize lambert on [0,1] for more relief
end

function updatelighting()

	local light_cos_x = cos(light_angle_x)
	local light_sin_x = sin(light_angle_x)
	local light_cos_y = cos(light_angle_y)
	local light_sin_y = sin(light_angle_y)
	
	light_x = -light_sin_x * light_cos_y
	light_y = light_cos_x * light_cos_y
	light_z = light_sin_y

	for x=2,nb_vertices-1 do
		local verticesx = vertices[x]
		for y=2,nb_vertices-1 do
			
			local currentvertex = verticesx[y]
			local lighting = getlighting(currentvertex.nx,currentvertex.ny,currentvertex.nz)
			
			local colindexx = 0
			if (lighting >= 0.5) then
				colindexx = 1
			end
			
			local zindex = sget(current_map * 32 + x - 1,32 + heightmapy * 32 + y - 1) - 1
			local colindexy = 0
			if (zindex == -1) then
				colindexy = 0
			else if (zindex == 0) then
				colindexy = 1
			else if (currentvertex.nz > slope_normal_threshold) then
			
				if (zindex <= sand_height_threshold) then
					colindexy = 2
				else if (zindex <= snow_height_threshold) then
					colindexy = 3
				else
					colindexy = 4
				end end
			
			else
			
				if (zindex <= rock_height_threshold) then
					colindexy = 5
				else
					colindexy = 6
				end
			
			end end end
			
			currentvertex.color = sget(current_palette * 2 + colindexx,colindexy)
			
		end
	end
end

function initzbuffer()
	min_z = 0x7fff
	max_z = 0xffff

	-- get the min and max linear z to use the full range in the  8bit z buffer
	for x=1,nb_vertices do
		local verticesx = vertices[x]
		for y=1,nb_vertices do
			local currentz = verticesx[y].proj_w
			min_z = min(min_z,currentz)
			max_z = max(max_z,currentz)
		end
	end
	
	for x=1,64 do
		local zbufferx = zbuffer[x]
		for y=1,64 do
			zbufferx[y] = 0
		end
	end	
end

function depthtest(x,y,depth)
	local xz = flr(x / 2) + 1
	local yz = flr(y / 2) + 1
	local shift = 8 * (band(x,1) * 2 + band(y,1))
	
	local zdepth = shr(254 * (depth - max_z) / (min_z - max_z) + 1,16)
	local packeddepth = zbuffer[xz][yz]
	local mask = shl(byte_mask,shift)
	local storeddepth = band(shr(band(packeddepth,mask),shift),byte_mask)	
	
	if (zdepth > storeddepth) then
		zbuffer[xz][yz] = band(packeddepth,bnot(mask)) + shl(zdepth,shift)
		return true
	else
		return false
	end	
end

function interpolate(value,threshold,dispersion)
	if dispersion != 0 then
		return (value - threshold + dispersion) / (2 * dispersion)
	else if value < threshold then
		return 0
	else 
		return 1
	end end
end

function rasterizetriangle(index,col)
	local line_size = 2 * (nb_vertices - 1)
	local indexy = flr(index / line_size)
	local indexx = index - indexy * line_size

	local v0,v1,v2
	if (band(indexx,1) == 0) then
		indexx = flr(indexx / 2)
		v0 = vertices[indexx+1][indexy+1]
		v1 = vertices[indexx+2][indexy+1]
		v2 = vertices[indexx+1][indexy+2]
	else
		indexx = flr(indexx / 2)
		v0 = vertices[indexx+2][indexy+1]
		v1 = vertices[indexx+2][indexy+2]
		v2 = vertices[indexx+1][indexy+2]
	end
	
	local z0 = v0.proj_w
	local z1 = v1.proj_w
	local z2 = v2.proj_w
	
	-- dont clip, just cull in case one vertex is before near plane
	if (z0 > near_plane and z1 > near_plane and z2 > near_plane) then
		
		local x0 = v0.proj_x
		local y0 = v0.proj_y
		local x1 = v1.proj_x
		local y1 = v1.proj_y
		local x2 = v2.proj_x
		local y2 = v2.proj_y
		
		local const_b0 = x1 * y2 - x2 * y1
		local const_b1 = x2 * y0 - x0 * y2
		
		local denom = const_b0 + const_b1 + x0 * y1 - x1 * y0
		if (denom > 0) then -- back face cull
		
			local minx = flr(max(min(min(x0,x1),x2),0))
			local miny = flr(max(min(min(y0,y1),y2),0))
			local maxx = flr(min(max(max(x0,x1),x2),127))
			local maxy = flr(min(max(max(y0,y1),y2),127))	
			
			local pixelrasterized = 0

			for y=miny,maxy do
				for x=minx,maxx do
					local xp = x + 0.5
					local yp = y + 0.5
					
					-- the rasterization method simply walks through the bounding rectangle of the triangle, computing the barycentric coordinates to determine if the pixel lies within or not
					-- this is not the fastest rasterization method but it is simple and i need the barycentric coordinates to interpolate anyway
					local b0 = const_b0 + xp * y1 + x2 * yp - xp * y2 - x1 * yp
					local b1 = const_b1 + xp * y2 + x0 * yp - xp * y0 - x2 * yp
					
					if (b0 >= 0 and b1 >= 0) then
					
						b0 /= denom
						b1 /= denom
						local b2 = 1 - b0 - b1
						
						if (b2 >= 0) then
							
							-- dont care about perspective correction even with linear z as we know that the grid layout will not cause issue with screen space interpolation							
							local z = b0 * z0 + b1 * z1 + b2 * z2 
													
							if (depthtest(x,y,z)) then
							
								-- perspective correction
								b0 *= v0.proj_z
								b1 *= v1.proj_z
								b2 *= v2.proj_z
								local invperspw = 1 / (b0 + b1 + b2)

								local zindex = (b0 * v0.world_z + b1 * v1.world_z + b2 * v2.world_z) * inv_scale_z * invperspw
								local nx = (b0 * v0.nx + b1 * v1.nx + b2 * v2.nx) * invperspw
								local ny = (b0 * v0.ny + b1 * v1.ny + b2 * v2.ny) * invperspw
								local nz = (b0 * v0.nz + b1 * v1.nz + b2 * v2.nz) * invperspw
								
								local invlength = 1 / sqrt(nx*nx + ny*ny + nz*nz)
								nx *= invlength
								ny *= invlength
								nz *= invlength
											
								-- the dithering filter is offsetted to avoid overlapping with light dithering
								local ditherref = sget(current_terrain_filter * 8 + band(x + 4,7),16 + band(y + 4,7)) / 16
								
								if (zindex <= -0.5 ) then
									colindexy = 0
								else if (zindex <= 0.2) then
									colindexy = 1
								else if interpolate(-nz,-slope_normal_threshold,slope_normal_dispersion) <= ditherref then
									if interpolate(zindex,sand_height_threshold,sand_height_dispersion) <= ditherref then
										colindexy = 2
									else if interpolate(zindex,snow_height_threshold,snow_height_dispersion) <= ditherref then
										colindexy = 3
									else
										colindexy = 4
									end end
								
								else
									if interpolate(zindex,rock_height_threshold,rock_height_dispersion) < ditherref then
										colindexy = 5
									else
										colindexy = 6
									end
								
								end end end
								
								local colindexx = 0
								if (colindexy == 0) then
									if (zindex > 0.000001) then
										colindexx = 1
									end
								else
									local lighting = getlighting(nx,ny,nz)			
									local ditherref = sget(current_light_filter * 8 + band(x,7),16 + band(y,7))
						
									if (lighting * 16 >= ditherref) then
										colindexx = 1
									end
								end
								
								local col = sget(current_palette * 2 + colindexx,colindexy)
								
								-- write the pixel in memory
								local memory = x / 2 + y * 64 
								if (memory >= 0x1000) then
									memory = memory + frame_chunk_1 - 0x1000
								else
									memory = memory + frame_chunk_0
								end
								
								local packedcol = peek(memory)
								if (band(x,0x1) == 0) then
									packedcol = band(packedcol,0xf0) + col
								else
									packedcol = band(packedcol,0xf) + shl(col,4)	
								end
								
								poke(memory,packedcol)
								pixelrasterized += 1
							end
						end
					end
				end
			end
			return pixelrasterized
		end	
	end
	
	return 0
end

function _init()
	init_app()
	init_terrain()
end

function updateangle()
	local deltax = 0
	local deltay = 0
	
	if btn(0) then 
		deltax = -cam_speed_angular 
	end
	
	if btn(1) then 
		deltax = cam_speed_angular 
	end
	
	if btn(2) then 
		deltay = -cam_speed_angular 
	end
	
	if btn(3) then 
		deltay = cam_speed_angular 
	end
	
	local delta = {}
	delta.x = deltax
	delta.y = deltay
	return delta
end

function updatemenu()

	if btnp(2) then
		menu_index -= 1
		if (menu_index < 0) then
			menu_index = 3
		end
	end
	
	if btnp(3) then
		menu_index += 1
		if (menu_index > 3) then
			menu_index = 0
		end
	end
	
	local delta = 0
	if btnp(0) then delta -= 1 end
	if btnp(1) then delta += 1 end
	
	if (delta != 0) then
	
		if (menu_index == 0) then
			
			current_map += delta
			if current_map < 0 then
				current_map = nb_maps - 1
			else if current_map >= nb_maps then
				current_map = 0
			end end
			
			init_terrain()
		
		else if (menu_index == 1) then
		
			current_palette += delta
			if current_palette < 0 then
				current_palette = nb_palettes - 1
			else if current_palette >= nb_palettes then
				current_palette = 0
			end end
			
			init_terrain()
			
		else if (menu_index == 2) then
		
			current_light_filter += delta
			if current_light_filter < 0 then
				current_light_filter = nb_filters - 1
			else if current_light_filter >= nb_filters then
				current_light_filter = 0
			end end
			
		else if (menu_index == 3) then
		
			current_terrain_filter += delta
			if current_terrain_filter < 0 then
				current_terrain_filter = nb_filters - 1
			else if current_terrain_filter >= nb_filters then
				current_terrain_filter = 0
			end end
		
		end end end end
	
		return true
	end
	
	return false
end

-- to profile rasteriazation
-- rasterizer_perf = 0 
function _update()

	local rasterization_frozen = false
	if btnp(4,1) then
		menuon = not menuon
	end
	
	if btnp(5,1) then
		infoon = not infoon
	end

	if menuon then
	
		if updatemenu()	then
			rasterizer_mode = 0
		end
		
	else if not menuon then
	
		if btnp(4,0) then 
			mode = 1 - mode 
		end
		
		local cam_zoom = false
		if btn(5,0) and mode == 0 then
			cam_zoom = true
			
			if btn(2) then 
				camera_z = min(40,camera_z + cam_speed)
				camera_changed = true
			end
		
			if btn(3) then 
				camera_z = max(-40,camera_z - cam_speed)
				camera_changed = true
			end
		end

		local delta = updateangle()
		if (delta.x != 0 or delta.y != 0) then
			if (mode == 0) then
				cam_angle_x += delta.x
				if not cam_zoom then
					cam_angle_y += delta.y
				end
				camera_changed = true
			else
				light_angle_x += delta.x
				light_angle_y -= delta.y
				light_changed = true
			end
		end
		
		if camera_changed or light_changed then
			rasterization_frozen = true
			rasterizer_mode = 0
		end
		
	end end
				
	if camera_changed then
		
		cam_angle_y = mid(0.00,cam_angle_y,0.24)
		if cam_angle_x < 0 then cam_angle_x = 1 + cam_angle_x end
		if cam_angle_x > 1 then cam_angle_x = cam_angle_x - 1 end
	
		cam_cos_x = cos(cam_angle_x)
		cam_sin_x = sin(cam_angle_x)
		cam_cos_y = cos(cam_angle_y)
		cam_sin_y = sin(cam_angle_y)
		
		transform_terrain()
		
		local tmp = -horizon_dist * cam_sin_y
		horizon_y = -horizon_dist * cam_cos_y * 64 / get_w(tmp) + 64
		horizon_y = mid(0,horizon_y,127)
		
		camera_changed = false
		
	end
	
	if light_changed then	
	
		light_angle_y = mid(0.00,light_angle_y,0.2)
		if light_angle_x < 0 then light_angle_x = 1 + light_angle_x end
		if light_angle_x > 1 then light_angle_x = light_angle_x - 1 end
	
		updatelighting()
		light_changed = false
		
	end
	
	if not rasterization_frozen then
	
		if (rasterizer_mode == 0) then
			initzbuffer()
			
			-- write down sky and sea to memory
			local horizonoffset = flr(horizon_y) * 64 
			memset(frame_chunk_0,sky_color + shl(sky_color,4),horizonoffset)
			memset(frame_chunk_0 + horizonoffset,sea_color + shl(sea_color,4),0x1000 - horizonoffset)
			memset(frame_chunk_1,sea_color + shl(sea_color,4),0x1000)
			
			rasterizer_mode = 1
			rasterizer_index = 0
			--rasterizer_perf = 0
		end
		
		if (rasterizer_mode == 1) then
		
			local lasttriangle = (nb_vertices - 1) * (nb_vertices - 1) * 2 - 1
			local pixel_rasterized = 0
		
			while pixel_rasterized < max_pixel_rasterized do
				if (rasterizer_index <= lasttriangle) then
					pixel_rasterized += rasterizetriangle(rasterizer_index)
					rasterizer_index += 1
				else
					pixel_rasterized = max_pixel_rasterized
					rasterizer_index = 0
					rasterizer_mode = 2
				end
			end
		
		else if (rasterizer_mode == 2) then
			rasterizer_index += 1
			if rasterizer_index > 4 then
				rasterizer_mode = 3
			end
			
		end end		
	end
end

function rendervoxelsalongx(startx,endx,incx,starty,endy,incy)
	for x=startx,endx,incx do
		local verticesx = vertices[x]
		for y=starty,endy,incy do
			local currentvertex = verticesx[y]
			rectfill(currentvertex.rect_x0,currentvertex.rect_y0,currentvertex.rect_x1,currentvertex.rect_y1,currentvertex.color)
		end
	end
end

function rendervoxelsalongy(starty,endy,incy,startx,endx,incx)
	for y=starty,endy,incy do
		for x=startx,endx,incx do
			local verticesx = vertices[x]
			local currentvertex = vertices[x][y]
			rectfill(currentvertex.rect_x0,currentvertex.rect_y0,currentvertex.rect_x1,currentvertex.rect_y1,currentvertex.color)
		end
	end
end

function printcenteredstring(str,y,index)
	local length = #str
	local x = 64 - 2 * length
	color(0)
	print(str,x-1,y)
	print(str,x+1,y)
	print(str,x,y-1)
	print(str,x,y+1)
	print(str,x-1,y-1)
	print(str,x+1,y+1)
	print(str,x+1,y-1)
	print(str,x-1,y+1)
	
	if (index == menu_index) then
		
		color(7)
		print(str,x,y)
		
		palt(0,false)
		palt(8,true)
		spr(25,x-10,y-1)
		spr(26,x+4*length+1,y-1)
		palt()
		
	else
		
		color(13)
		print(str,x,y)
	
	end
end

loading_index = 0

function _draw()
	if (rasterizer_mode != 3) then

		color(sky_color)
		rectfill(0,0,127,horizon_y)
		
		color(sea_color)
		rectfill(0,horizon_y,127,127)
				
		local first = 2
		local last = nb_vertices - 1

		if cam_angle_x < 0.125 then
			rendervoxelsalongy(first,last,1,first,last,1)
		else if cam_angle_x < 0.25 then
			rendervoxelsalongx(first,last,1,first,last,1)
		else if cam_angle_x < 0.375 then
			rendervoxelsalongx(first,last,1,last,first,-1)
		else if cam_angle_x < 0.50 then
			rendervoxelsalongy(last,first,-1,first,last,1)
		else if cam_angle_x < 0.625 then
			rendervoxelsalongy(last,first,-1,last,first,-1)
		else if cam_angle_x < 0.75 then
			rendervoxelsalongx(last,first,-1,last,first,-1)
		else if cam_angle_x < 0.875 then
			rendervoxelsalongx(last,first,-1,first,last,1)
		else
			rendervoxelsalongy(first,last,1,last,first,-1)
		end end end end end end	end
		
	end
				
	if (rasterizer_mode == 1) then
	
		palt(8,true)
		spr(16 + loading_index,128 - 10,2)
		loading_index += 1
		if (loading_index > 7) then
			loading_index = 0
		end
		palt()
		--rasterizer_count += stat(1)
		
	else if (rasterizer_mode == 2) then
		
		local currentline = 0
		local step = shl(1,5 - rasterizer_index)
		while (currentline < 64) do
			local lineadress = currentline * 64
			memcpy(0x6000 + lineadress,frame_chunk_0 + lineadress,64)
			memcpy(0x7000 + lineadress,frame_chunk_1 + lineadress,64)
			currentline += step
		end
		
	else if (rasterizer_mode == 3) then
		
		memcpy(0x6000,frame_chunk_0,0x1000)
		memcpy(0x7000,frame_chunk_1,0x1000)
		
		--color(0)
		--cursor(0,64)
		--print(rasterizer_count)
	
	end end end
	
	if menuon then	
		
		printcenteredstring("height map",20,-1)
		printcenteredstring(map_names[current_map+1],28,0)
		
		printcenteredstring("palette",44,-1)
		printcenteredstring(palette_names[current_palette+1],52,1)
		
		printcenteredstring("light filter",68,-1)
		printcenteredstring(filter_names[current_light_filter+1],76,2)
		
		printcenteredstring("terrain filter",92,-1)
		printcenteredstring(filter_names[current_terrain_filter+1],100,3)	
	
	else if (infoon) then
		
		if (mode == 0) then
			printcenteredstring("camera control",2,-1)
		else
			printcenteredstring("lighting control",2,-1)
		end
		
	end end
		
	if (infoon) then
		color(0)
		rectfill(1,1,28,3)
		rectfill(1,5,28,7)
		color(8)
		local mem = min(1,stat(0) / 512)
		rectfill(1,1,mem * 28,3)
		local cpu = min(1,stat(1))
		if (cpu < 1) then color(7) end
		rectfill(1,5,cpu * 28,7)
	end
	
end
