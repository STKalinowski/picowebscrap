-- flying disc
-- @matthughson

-- credits: 
-- sprites inspired by http://seamusaran.tumblr.com/

cartdata("mbh_flyingdisc")

--game states
states=
{
	menu=0,
	wait=1,
	bar=2,
	throw=3,
	catch=4,
	fail=5,
	outro=6,
	intro=7,
}

--globals
g={}
g.groundy=128-32
g.showdebug=false
g.maxx=72*8
g.state=states.menu
g.grav=0.2 -- gravity per frame
g.score=0
g.hiscore=dget(0)
g.gothiscore=false
g.catchoffsetx=g.maxx*0.5
g.tick=0
g.statestart=1
--mapping info
m=
{
	w_t=128,
	h_t=16,
	rows=2,
}
m.w_px=m.w_t*8
m.h_px=m.h_t*8

function make_player(is_user)
	local new_player=
	{
		--position
		x=g.catchoffsetx,
		y=g.groundy-8,
		--velocity
		dx=0,
		dy=0,
		
		--is the player standing on
		--the ground. used to determine
		--if they can jump.
		isgrounded=false,
		
		--has the player picked up the
		--flying disc.
		hasdisc=false,
		
		frame=0,
		cell=1,
		flipx=true,
		
		--tuning constants

		jumpvel=3,
		walkvel=1,

		isuser=is_user,

		-- functions

		update=function(self)
			--
			-- player movement
			--
			
			--remember where we started
			local startx=self.x
			
			local moved=false
			self.dx=0

			--jump 
			--
			
			if self.isuser then
				--if on the ground and the
				--user presses x,c,or,up...
				if (btnp(2) or btnp(4) or btnp(5))
				 and self.isgrounded then
				 --launch the player upwards
					self.dy=-self.jumpvel
					sfx(snd.jump)
				end
			
				--walk
				--
				
				if btn(0) then --left
					self.dx=-self.walkvel
					self.flipx=true
					moved=true
				end
				if btn(1) then --right
					self.dx=self.walkvel
					self.flipx=false
					moved=true
				end
			end
			
			--move the player left/right
			self.x+=self.dx
			
			--hit side walls
			--
			
			--check for walls in the
			--direction we are moving.
			local xoffset=0
			if self.dx>0 then xoffset=7 end
			
			--look for a wall
			local h=mget_looping((self.x+xoffset),(self.y+7))
			if fget(h,0) then
				--they hit a wall so move them
				--back to their original pos.
				--it should really move them to
				--the edge of the wall but this
				--mostly works and is simpler.
				self.x=startx
			end
			
			--accumulate gravity
			self.dy+=g.grav
			
			--fall
			self.y+=self.dy

			--hit floor
			--
			
			--check bottom center of the
			--player.
			local v=mget_looping((self.x+4),(self.y+8))
			
			--assume they are floating 
			--until we determine otherwise
			self.isgrounded=false
			
			--only check for floors when
			--moving downward
			if self.dy>=0 then
				--look for a solid tile
				if fget(v,0) then
					--place p1 on top of tile
					self.y = flr((self.y)/8)*8
					--halt velocity
					self.dy = 0
					--allow jumping again
					self.isgrounded=true
				end
			end
			
			--hit ceiling
			--
			
			--check top center of p1
			v=mget_looping((self.x+4),(self.y))
			
			--only check for ceilings when
			--moving up
			if self.dy<=0 then
				--look for solid tile
				if fget(v,0) then
					--position p1 right below
					--ceiling
					self.y = flr((self.y+8)/8)*8
					--halt upward velocity
					self.dy = 0
				end
			end
			
			--p2 animation
			self.frame+=1
			if self.frame > 2 then
				self.frame=0
				self.cell=self.cell+1
				if self.cell > 3 then
					self.cell=2
				end
			end
			
			if self.isgrounded==false then
				self.cell=34
			elseif not moved then
				self.cell=1
			end
			
			if self.isuser then
				--check for catch
				if not self.hasdisc and 
				 intersects(
					disc.x+4,disc.y+1,8,2,
					self.x+4,self.y+4,8,8)==true then
						self.hasdisc=true
						g.score+=calcdist()
						music(msc.catch)
						g.state=states.catch
				end
			end
		end
	}
	return new_player
end

--player
p1=make_player(false)
p1.x=0
p1.y=g.groundy-8
p1.frame=0
p1.cell=1
p1.flipx=false

--player
p2=make_player(true)

--throw bar
bar={}
bar.x=112
bar.y=112
bar.minx=16
bar.maxx=112
bar.dx=-3
bar.hist={}
bar.angleposx=nil
bar.speedposx=nil
bar.speedperfectx=16+20
bar.angleperfectx=112-20

--disc
disc=
{
	x=4,
	startx=4,
	y=g.groundy-4,
	dx=0,
	dy=0,
	grav=0.01,
	frame=0,
	cell=0,
	isactive=false,

	update=function(self)


		if not self.isactive then
			return
		end
			
		--remember where we started
		local startx=self.x
		
		--move the player left/right
		self.x+=self.dx
		
		--hit side walls
		--
		
		--check for walls in the
		--direction we are moving.
		local xoffset=0
		if self.dx>0 then xoffset=7 end
		
		--look for a wall
		local h=mget_looping((self.x+xoffset),(self.y+2))
		if fget(h,0) then
			--they hit a wall so move them
			--back to their original pos.
			--it should really move them to
			--the edge of the wall but this
			--mostly works and is simpler.
			self.x=startx

			--kill momentum
			self.dx*=-0.1
			self.dy*=0.5
		end
		
		--accumulate gravity
		self.dy+=self.grav
		
		--fall
		self.y+=self.dy

		--hit floor
		--
		
		--check bottom center of the
		--player.
		local v=mget_looping((self.x+4),(self.y+2))
		
		--assume they are floating 
		--until we determine otherwise
		self.isgrounded=false
		
		--only check for floors when
		--moving downward
		if self.dy>=0 then
			--look for a solid tile
			if fget(v,0) then
				--place on top of tile
				self.y = flr((self.y)/8)*8+6
				--halt velocity
				self.dy = 0
				--allow jumping again
				self.isgrounded=true

				self.isactive=false

				g.state=states.fail

				
				--sfx(snd.miss_thump)

				updatehiscore()

				if not g.gothiscore then
					sfx(snd.miss_jing)
				else
					sfx(snd.hiscore_jing)
				end

			end
		end
		
		--hit ceiling
		--
		
		--check top center of p1
		v=mget_looping((self.x+4),(self.y))
		
		--only check for ceilings when
		--moving up
		if self.dy<=0 then
			--look for solid tile
			if fget(v,0) then
				--position p1 right below
				--ceiling
				self.y = flr((self.y+8)/8)*8
				--halt upward velocity
				self.dy = 0
			end
		end
		
		--disc animation
		self.frame+=1
		if self.frame>2 then
			self.frame=0
			self.cell+=1
			if self.cell>=4 then
				self.cell=0
			end
		end
		
		--[[
		self.x+=self.dx
		self.dy+=self.grav
		self.y+=self.dy
		--]]
	end
}

snd=
{
	bar=1,
	miss_jing=4,
	miss_thump=5,
	hiscore_jing=6,
	startgame=8,
	jump=12,
}

msc=
{
	catch=0
}

function _init()
	printh("\n\n============\n== new game\n============\n\n")
	p2.y=findtopplatform(p2.x)
end

--update
function _update()

	g.tick+=1

	if g.state==states.fail then
		if btnp(4) or btnp(5) then
			g.state=states.outro
			g.statestart=g.tick
		end
	end

	if g.state==states.menu then
		if btnp(4) or btnp(5) then
			g.state=states.intro
			g.statestart=g.tick
			sfx(snd.startgame)
		end
	end

	--throw button

	if g.state==states.catch then
		g.state=states.wait
		bar.speedposx=nil
		bar.angleposx=nil
		bar.x=112
		disc.isactive=false
		disc.startx=disc.x
		p2.hasdisc=false
		p1.x,p1.y=p2.x,p2.y
		--p1.x=p2.x
		p1.flipx=p2.flipx
		p1.cell=p2.cell
		p2.x+=g.catchoffsetx
		while fget(mget_looping(p2.x,p2.y),0) do
			p2.y-=8;
		end
	end

	if btnp(4) or btnp(5) then
		if g.state==states.wait then
			g.state=states.bar
			sfx(snd.bar)	
		elseif g.state==states.bar then
			--speed
			if bar.speedposx==nil then
				bar.speedposx=bar.x
				bar.dx*=-1
				sfx(snd.bar)
			--angle
			elseif bar.angleposx==nil then
				bar.angleposx=bar.x
				bar.dx*=-1
				g.state=states.throw
				sfx(snd.bar)				
			end
		end
	end

	--is throw bar still going?
	if g.state==states.bar then
		bar.x+=bar.dx
	end
	
	if g.state==states.throw
	and not disc.isactive then
		disc.isactive=true
		local ds=
			bar.speedposx-
			bar.speedperfectx
		ds=abs(ds)*0.1
		local maxs=2
		local s=max(0,maxs-ds)
		
		local da=
			bar.angleposx-
			bar.angleperfectx
		da=abs(da)*0.1
		local maxa=1.5
		local a=max(0,maxa-da)
						
		disc.dx=s
		disc.dy=-a
	end
	
	--account for cases where
	--bar hits ends
	if bar.x < bar.minx then
		bar.x=bar.minx
		bar.speedposx=bar.x
		bar.dx*=-1
	elseif bar.x > bar.maxx then
		bar.x=bar.maxx
		bar.angleposx=bar.x
		bar.dx*=-1
		g.state=states.throw
	end

--[[
	--save bar position history
	--for trailing effect
	if #bar.hist>=5 then
		del(bar.hist,bar.hist[1])	
	end
	add(bar.hist,bar.x)
--]]

	if g.state!=states.throw then
		return
	end

	disc:update()
	p1:update()
	p2:update()

end

bari=0

views=
{
	{
		clipx_min=0,
		clipy_min=0,--64,
		clipx_max=128,
		clipy_max=128,

		camy=0,
	},
	--[[
	{
		clipx_min=0,
		clipy_min=16,
		clipx_max=128,
		clipy_max=64,

		camy=48,
	}
	]]
}

logoline={x=127,y=50}
logofade={9}--{9,8,7}

--draw
function _draw()

	--if g.state!=states.outro then
		cls()
	--end

	--clear the background
	rectfill(0,16,128,107,12)

	--
	--game
	--

	for i,view in pairs(views) do

	local cam_target_x
	local cam_target_y
	if i==1 then
		cam_target_x=disc.x
		cam_target_y=disc.y
	else
		cam_target_x=p2.x
		cam_target_y=p2.y
	end

	--clip(0, 64, 128, 128)
	--clip(0, 16, 128, 64)

	clip(view.clipx_min, 
		view.clipy_min, 
		view.clipx_max, 
		view.clipy_max-20)

	-- cloud
	--
	--camera(max(0,(cam_target_x-64)*0.05),0)
	--camera(max(0,(cam_target_x-64)*0.05),64-16)
	camera(max(0,(cam_target_x-64)*0.05),view.camy)

	local crad=8
	local cx=64
	local cy=32
	
	local colbg=6
	 
	circfill(cx,cy+1,crad,colbg)
	circfill(cx+crad*.9,
		cy+crad*.75+1,crad/2,colbg)
	circfill(cx-crad,
		cy+1,crad/2,colbg)

 
	circfill(cx,cy,crad,7)
	circfill(cx+crad*.9,cy+crad*.75,crad/2,7)
	circfill(cx-crad,cy,crad/2,7)
	
	--
	-- end cloud
	
	--focus the camera on the disc
	local cam_x=max(0,cam_target_x-64)
	--camera(cam_x,0)
	--camera(cam_x,64-16)
	camera(cam_x,view.camy)
	
	-- draw the main map


	--pal( 4, disc.x%15 )

	-- what level is the player in.
	for count=0,1 do
		drawmapforcampos(cam_x+m.w_px*count)
	end

	pal()

	--map(0,m.h_t,m.w_px,0,m.w_t,m.h_t)
	
	--p1
	spr(p1.cell,p1.x,p1.y,1,1,p1.flipx)
	spr(p2.cell,p2.x,p2.y,1,1,p2.flipx)	

	
	--disc
	sspr(5*8,disc.cell*2,8,2,
				 disc.x,disc.y,
				 8,2,false,false)
				 
 --paralax
	--camera(max(0,(disc.x-64)*1.5),0)
	
	-- draw the foreground
	--map(0,13,0,8*13,(76+8)*1.5,8)

	end

	clip()
 --
 -- hud
 --
	
	--reset camera for the hud
	camera(0,0)
	
	--clear the background
	--rectfill(0,128-16,128,128,0)

	--line(0,63,127,63,0)

	-- draw the throwbar
	map(0,56,16,128-16,12,1)
	
	drawminimap()
	
 --bar (swap with code below for trail)
	if bar.speedposx!=nil then
		sspr(32+4,0,1,8,
				 bar.speedposx,bar.y,
				 1,8,false,false)
	end
	
	if g.state==states.wait then
		bari+=1
		bari%=5
	else
		bari=4
	end
	sspr(32+bari,0,1,8,
				 bar.x,bar.y,
				 1,8,false,false)
--[[debug show perfect spot
	sspr(32+4,0,1,8,
				 bar.speedperfectx,bar.y,
				 1,8,false,false)
	sspr(32+4,0,1,8,
				 bar.angleperfectx,bar.y,
				 1,8,false,false)
--]]			


	--game over
	if g.state==states.fail 
	or g.state==states.outro then

		--game over
		local str="game over"
		local len=#str*4
		local startx=len/2
		print(str,64-(startx)+1,60,0)	 
		print(str,64-(startx),60,7)

		--hiscore
		local col=7
		if g.gothiscore then
			col=(g.tick*0.25)%2+9
		end
		str=""..g.score
		len=#str*4
		startx=len/2
		print(str,64-(startx)+1,68,0)	 
		print(str,64-(startx),68,col)

	end

	print("score:"..g.score,2,17,0)	 
	print("score:"..g.score,1,17,7)

	local distance=calcdist()
	print(distance.."ft",65,17,0)
	print(distance.."ft",64,17,7)

	local str="best:"..g.hiscore
	local len=#str*4
	local startx=128-len-1
	print(str,startx+1,17,0)	 
	print(str,startx,17,7)
	
	print("speed",26,128-8,5)
	print("angle",83,128-8,5)
	--for i=1,#bar.hist do
	--	sspr(31+i,0,1,8,
	--					 bar.hist[i],bar.y,
	--					 1,8,false,false)
	--end

	if g.state==states.outro or
	g.state==states.intro then

		--printh("tick:"..g.tick..","..g.statestart)
		local len=15
		local t=g.tick-g.statestart
		local tnorm=t/len
		local tdist=tnorm*64

		if tnorm>1.0 then
			if g.state==states.outro then
				run()
			else
				g.state=states.wait
			end
		end
		--[[
		local start=64-tdist
		local cond=64+tdist
		for x=start,cond do
			for y=0,128 do
				--if abs(64-x)<=tdist then
					pset(x,y,0)
				--end
			end
		end
		]]

		if g.state==states.outro then
			compare=function(xdist)
				return xdist<=tdist
			end
		else
			compare=function(xdist)
				return xdist>=tdist
			end
		end

		if g.state==states.outro then
			rectfill(0,0,tdist,127,0)
			rectfill(127-tdist,0,127,127,0)
		else
			rectfill(0,0,63-tdist,127,0)
			rectfill(63+tdist,0,127,127,0)
		end


--[[
		local start=0
		local cond=63
		for x=start,cond do
			local xdist=64-x
			if compare(xdist) then
				line(x,0,x,127,0)
				line(127-x,0,127-x,127,0)
			end
		end
--]]
	end



	if g.state==states.menu or g.state==states.intro or g.state==states.outro then

		--clip(0+tdist,0,127-tdist,127)
		if g.state==states.menu then 
			cls(0)
		elseif g.state==states.intro then
			local len=10
			local t=g.tick-g.statestart
			local tnorm=min(1,t/len)
			local tdist=tnorm*64
			clip(0+tdist,0,127-(tdist*2),127)
		elseif g.state==states.outro then
			local len=20
			local t=g.tick-g.statestart
			local tnorm=min(1,t/len)
			local tdist=tnorm*64
			clip(64-tdist,0,(tdist*2),127)
		end

		local len=#logofade*10
		local t=g.tick-g.statestart
		local tnorm=t/len
		local index=min(#logofade,flr(tnorm*(#logofade))+1) 

		local slownorm=(g.tick-g.statestart)/60
		printh(slownorm)
		local d=0--(cos(g.tick/120)+1)
		local dy=63+d
		local col_main=7--10
		local col_sec=6--9
		local col_rim=5--8
		local col_shad=1--2
		circfill(63,dy+1,32,col_shad)
		circfill(63,dy,32,col_rim)
		circfill(63,dy,31,col_sec)
		circfill(63,dy,24,col_main)
		circ(63,dy,26,col_main)
		circ(63,dy,28,col_main)
		--circ(63,63,30,9)

		--[[
		local slownorm=tnorm*0.1
		local norminc=0.005
		local rad=31
		local col=9
		line(63,63,63+cos(slownorm)*rad,63+sin(slownorm)*rad,col)
		slownorm+=norminc
		line(63,63,63+cos(slownorm)*rad,63+sin(slownorm)*rad,col)
		slownorm+=norminc
		line(63,63,63+cos(slownorm)*rad,63+sin(slownorm)*rad,col)
		slownorm+=norminc
		line(63,63,63+cos(slownorm)*rad,63+sin(slownorm)*rad,col)
		]]
		local str="disc relay"
		local len=#str*4
		local startx=len/2
		local col_shad=8
		print(str,64-(startx),60+1,col_shad)
		print(str,64-(startx),60-1,col_shad)
		print(str,64-(startx)-1,60,col_shad)
		print(str,64-(startx)+1,60,col_shad)
		print(str,64-(startx)+1,60+1,col_shad)
		print(str,64-(startx)+1,60-1,col_shad)
		print(str,64-(startx)-1,60+1,col_shad)
		print(str,64-(startx)-1,60-1,col_shad)
		--print(str,64-(startx)-1,60,6)
		print(str,64-(startx),60,10)--logofade[index])

		if (g.tick*0.05)%2>0.5 then
			local str="press x or c to begin"
			local len=#str*4
			local startx=len/2
			--print(str,64-(startx),127-31,1)
			print(str,64-(startx),127-8,6)
		end

		local str="@matthughson - #1gam"
		local len=#str*4
		local startx=len/2
		print(str,64-(startx),0,1)

		if g.state==states.menu then
		return
		end
	end

	drawdebuginfo()
			
end

function drawmapforcampos(cam_x)

	local map_pos_x_px=(flr(cam_x/m.w_px))*m.w_px
	local map_lookup_y_t=((flr(cam_x/m.w_px))%m.rows)*m.h_t
	map(0,map_lookup_y_t,map_pos_x_px,0,m.w_t,m.h_t)

end

function drawminimap()
	--draw the map
	map(0,57,0,0,16,2)

	calc_xy = function(x,y)
		local mapx=(x-disc.startx)/(127*8)--/g.maxx;
		local mapy=y/127;
		return mapx*125+1,mapy*8+4
	end


	local mx=126--g.maxx/8
	local sx=1--125/mx
	local xoffset=disc.startx/8
	for y=0,15 do
		for x=1,mx do
			local t=mget_looping((x+xoffset)*8,y*8)
			if fget(t,0) then
				--x,y=calc_xy(x*8,y*8)
				pset((x*sx),(y/2)+5,4)
			end
		end
	end


	--draw disc on map
	local x,y=calc_xy(disc.x+4,disc.y+2)
	pset(x,y, 7)

	--draw player on map
	x,y=calc_xy(p2.x+4,p2.y+8)
	pset(x,y,8)
end

function drawdebuginfo()
	if g.showdebug then
		local y=17+8
		drawdebugstring("camx:"..disc.x/8,1,y)
		y+=8
		drawdebugstring("disc ["..disc.x..","..disc.y.."]",1,y)
		y+=8
		drawdebugstring("p2 ["..p2.x..","..p2.y.."]",1,y)

	end
end

function drawdebugstring(str,x,y)
	print(str,x+1,y,0)
	print(str,x,y,3)
end

function intersects(x1,y1,width1,height1,x2,y2,width2,height2)

	local xd=x1-x2
	local xs=width1*0.5+width2*0.5
	if abs(xd)>=xs then return false end

	local yd=y1-y2
	local ys=height1*0.5+height2*0.5
	if abs(yd)>=ys then return false end

		
	return true

end

function calcdist()
	return flr((disc.x-disc.startx)/10)
end

function mget_looping(x_px,y_px)

	--looped px x
	local x_px_looped=x_px%m.w_px
	local y_px_looped=y_px+(((flr(x_px/m.w_px)%m.rows)*m.h_px))

	--printh("["..x_px_looped..","..y_px_looped.."]")

	return mget(x_px_looped/8,y_px_looped/8)
end

function updatehiscore()

	local oldscore=dget(0)
	if oldscore<g.score then
		dset(0,g.score)
		g.hiscore=g.score
		g.gothiscore=true
	end

end

function findtopplatform(x)
	local y=13*8
	while fget(mget_looping(x,y),0)==true do
		y-=8;
	end
	return y
end
