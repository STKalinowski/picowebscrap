--bustin'
-- @morningtoast

-- Game design and programming by Brian Vaughn; 2017, 2021
-- Music by @gnarcade_vgm
-- Sprites borrowed from Ghostbusters 2 for Game Boy
-- Additional sprites and art by @morningtoast, @beetleinthebox 


-- Follow @morningtoast on Twitter
-- Please check out my other Pico-8 games
-- https://morningtoast.itch.io


-- History
-- 2.1 - 10/26/21 - Added Gozer and script changes
--                - Made classic characters default. No more locked characters.
--                - Traps no longer unlimited
-- 1.1 - 09/18/17 - Fix for crash after winning with unlocked character
-- 1.0 - 09/17/17 - Initial release


version="2.1"
musicon=true
lanes={3,32,61,90}
unlocked=1
charmode=1 --0=girls,1=boys
p_t=0
p_char="peter"

--#player
function p_update()
    muzzle_x=p_x+16
    muzzle_y=p_y+12
    
    beam_len=muzzle_x+fire_w --x of end of beam

	firing=false
    p_canmove=true
	p_canfire=true

	if p_slimed then p_canmove=false p_canfire=false end
	
	local vert=1

	-- player becomes unslimed
	if p_slimed and p_t>45 then -- time player is disabled by slime
		p_slimed=false
		p_canfire=true
		p_invincible=1
	end
		
	
	
	if btnz then
        firing=true
        p_canmove=false
        fire_speed=8
		
		
        if p_canfire then
			p_power=min(p_power+1.6,100) --speed of overheating
			if p_power>=100 then
				
				--if p_power==100 then sfx(3) end
				
				p_canfire=false
				firing=false 
				fire_w=0
			end
			
            for s in all(slimers) do
                if s.lane==p_lane and s.st!=1 then
                    fire_speed=0
                end
            end
			
			for p in all(portals) do
				if beam_len>=p.x and p.lane==p_lane then 
					p.hit=true 
					fire_speed=0
				end
			end

            
            fire_w+=fire_speed
			if fire_w>110 then fire_w=110 end
            fire_t+=1
        else
            fire_w=0
            fire_t=0
        end
    else
		p_power=max(p_power-3,0) --speed of reducing overheat
		fire_w=0
    end
	
	if btnxp then
		if p_traps>0 and trap_st<=0 then
			trap_create(p_lane)
		end
	end
	
	--switching lanes up/down
	if (btndp or btnup) and p_canmove then
		if btndp then vert=1 end
		if btnup then vert=-1 end
		
		p_power=0
		p_lane+=1*vert
		if p_lane>#lanes then p_lane=#lanes end
		if p_lane<1 then p_lane=1 end
	end

	p_y=lanes[p_lane]
	
	p_t+=1
end

function p_draw()
	if firing then
		draw_sine(rnd(.2)+.05, fire_t*-3, {muzzle_x,muzzle_y-rnd(5)}, {muzzle_x+fire_w,muzzle_y+rnd(4)}, 11,1)
		draw_sine(rnd(.25)+.05, fire_t*-4, {muzzle_x,muzzle_y-rnd(4)}, {muzzle_x+fire_w,muzzle_y+rnd(3)}, 10,1)
		draw_sine(rnd(.3)+.05, fire_t*-2, {muzzle_x,muzzle_y-rnd(4)}, {muzzle_x+fire_w,muzzle_y+rnd(3)}, 12,1)
	end
	
	if p_invincible<1 then
		draw_char(p_char, p_x,p_y)
	else
		if is_even(p_invincible) then
			draw_char(p_char, p_x,p_y)
		end
		
		p_invincible+=1
		
		if p_invincible>50 then p_invincible=0 end -- time when invicinbiility wears off
	end
	
	-- overheated, draw smoke
	if p_power>=100 then
		expl_create(muzzle_x+2,muzzle_y, 1, {
			dur=18, --30
			decay=-.2,
			den=1, --0
			colors={5,6,1,0},
			smin=.2, --1
			smax=.5, --1
			grav=-.2, --.3
			dir=.25, --0 (all directions)
			range=.05
		})
	end
	
	if p_slimed then
		palt(14,true)
		spr(53,p_x,p_y,2,2)
		palt()
	end
	
end

--player sprite
function draw_char(id,x,y)
	palt(0,false)
	palt(14,true)
	
	spr(5,x,y,2,3)
	if id=="holtz" then spr(151,x+1,y+1,2,2) end --holtz
	if id=="abby" then spr(153,x,y,2,2) end --abby
	if id=="erin" then spr(183,x+1,y+1,2,2) end --erin
	if id=="patty" then spr(185,x+2,y+1,2,2) end --patty

	-- boys
	if id=="peter" then spr(155,x+1,y+1,2,2) end --peter
	if id=="ray" then spr(187,x+2,y+1,2,2) end --ray
	if id=="winston" then spr(189,x+3,y+1,2,2) end --zed
	if id=="egon" then spr(157,x+3,y,2,2) end --egon
	
	pal()
end



--#slimers
slimers={}

function slimer_create(lane)
	local from_portal=get_portal(lane)
    
    local obj={
		x=from_portal.x,
		y=lanes[lane]+2,
		lane=lane,
		ang=0,
		speed=level.slimer_speed,
		hp=level.slimer_hp,
		hit=false,
		st=1,
		shrink=0
	}

	if level_kills>=15 and round(rnd()*10)<=1 then 
		obj.super=true 
		obj.hp*=2
		obj.speed+=.1
		level_kills=0
	end

	add(slimers, obj)
end

function slimer_update()
	for s in all(slimers) do
		if s.st!=3 then
			if beam_len>=s.x and s.lane==p_lane and firing and s.x>muzzle_x then 
				s.st=2
			else
				s.st=1
			end
		end
		
		-- normal moving
		if s.st==1 then
			--check if hit by beam
			s.x-=s.speed
			s.ang+=0.03 --distance between crests
			s.y+=sin(s.ang)*.25 --height of wave

			--caught in trap
			if s.lane==trap_lane and s.x<=trap_x+8 and s.x>= trap_x and trap_st==3 then
				s.st=3
			end

			-- slime player
			if s.lane==p_lane and s.x<muzzle_x-8 and s.x>0 and p_invincible<1 then
				if not p_slimed then sfx(4) end
				p_slimed=true
				p_t=0
				
				
			end

			-- slimer makes it off screen
			if s.x<-16 then
				p_slime=min(p_slime+5,100) -- add to slime meter but not to kill count
				del(slimers,s)
			end
		end
		
		
		--hit by beam
		if s.st==2 then
			s.x+=1
			s.hp-=1
			if s.hp<=0 then
                expl_create(s.x+8,s.y+8, 24, {
                    dur=18,
                    den=4,
                    colors={11,3,10},
                    smin=1,
                    smax=4,
                    grav=1,
                })
				slimer_kill(s)
			end
		end

		--trapped
		if s.st==3 then
			s.shrink+=1.5
			if s.shrink>=14 then
				slimer_kill(s,true)
			end
		end

	end
end

	
function slimer_draw()
	for s in all(slimers) do
		palt(0,false)
		palt(14,true)

		if s.super then
			pal(11,9)
			pal(3,4)
		end

		if s.st==2 then --hit by beam, turn red
			if s.super then
				pal(9,8)
				pal(4,2)
			else
				pal(11,8)
				pal(3,2)
				pal(10,14)
			end
			
		end

		if s.st<3 then
			sspr(56,0,16,24, s.x,s.y, 14,18)
		else
			sspr(56,0,16,24, s.x,s.y, 14-s.shrink,18-s.shrink)
			s.y+=1
		end
		
		pal()	
	end	
end

function slimer_kill(obj,bytrap)
	bytrap=bytrap or false
	-- @sound ghost kill
	sfx(0)
	kills+=1	
	if not bytrap then 
		if obj.super then
			p_traps+=1
			sfx(6)
		end

		level_kills+=1
	end
	
	del(slimers,obj)
end




--#portals
--portal_hp=100
portal_explodes={}

function get_portal(lane)
    local pick={}
    for p in all(portals) do
        if p.lane==lane then pick=p end
    end
    return pick
end

function portal_reset()
	portals={}
	for n=1,4 do 
		portal_create(n,level.portal_offset[n]) 
	end
	
	last_portal=0
	portal_spawn=random(15,level.portal_spawn)
	timer_set("portalspawn")
end

function portal_create(lane,xoffset)
    add(portals,{
		x=110-xoffset,
		y=lanes[lane]+10,
		r=5,
		lane=lane,
		hp=level.portal_hp,
		hit=false,t=0,
		jump=false,
		isjumping=false,
		ang=0,
		jt=0
	})
end


function portal_update()
	
    for p in all(portals) do
        if p.hit then 
            p.hp-=1
            
            if p.hp<=0 and p.r>0 then
				p.r-=1
				shake=1
				
				sfx(1)
				
				--portal is dead
                if p.r<=0 then
					-- @sound portal dead
                    expl_create(p.x,p.y, 48,{
                        dur=40,
                        den=5,
                        colors={8,7,10,9,12},
                        smin=3,
                        smax=6,
                        grav=0,
                    })
                    
                    del(portals,p)
					
                    
				else
					--portal shatters once
					-- @sound portal hit
					expl_create(p.x,p.y, 48,{
						dur=15,
						den=5,
						colors={7},
						smin=3,
						smax=8,
						grav=0,
					})
                
                	p.hp=level.portal_hp
					
					if p.jump then -- pick new portal for jumping
						p.jump=false
						portal_jump_pick(p.lane)
					end
                end
            end
            
        else
            p.hit=false 
			
			if p.jump then
				
				if p.x>50 then
					if p.jt==0 then 
						-- @sound of jumping portal
						
					end
					
					if p.jt>45 and p.jt<60 then --
						p.x-=1
						p.ang+=.16 --distance between crests
						p.y+=sin(p.ang)*1 --height of wave
						p.isjumping=true
						
						if p.jt==46 or p.jt==55 then sfx(5) end
					end

					if p.jt==210 then
						p.isjumping=false
						p.jt=0
						p.ang=0
						
					end

					p.jt+=1
				end
			end
			
			
        end
    
		p.hit=false
        p.t+=1
    end
	
	-- portal spawn; randomize from available
	if #portals>0 then
		if timer("portalspawn",portal_spawn,true) then
			local spawnfrom=rnd_table(portals)

			while last_portal==spawnfrom.lane and #portals>1 do
				spawnfrom=rnd_table(portals)
			end

			last_portal=spawnfrom.lane
			portal_spawn=random(15,level.portal_spawn)
			
			if #portals==1 then
				portal_spawn=60
			end

			if not spawnfrom.hit and #slimers<level.slimer_max then
				slimer_create(spawnfrom.lane)
			end
		end
	end
end

function portal_jump_pick(lastlane)
	if #portals>1 then
		local pick={lane=lastlane}
		
		while pick.lane==lastlane do
			pick=rnd_table(portals)
		end
		
		pick.jump=true
		pick.jt=0
	else
		local pick=rnd_table(portals)
		pick.jump=true
		pick.jt=0
	end
end


function portal_draw()
    for p in all(portals) do
        if p.hit then p.c=rnd_table({8,7,10}) else p.c=0 end
    
		local c=rnd_table({3,11})
		palt(14,true)
		palt(0,false)
		pal(0,c)
		pal(8,c)
		pal(12,c)
		pal(9,c)
		pal(15,c)
		
		if p.r<5 then pal(8,0) end
		if p.r<4 then pal(12,0) end
		if p.r<3 then pal(9,0) end
		if p.r<2 then pal(15,0) end
		
		spr(3,p.x,p.y-8,2,2)
		pal()
        
		if p.hit then
			expl_create(p.x,p.y, 8,{
				dur=8,
				den=2,
				colors={10,7,9,8},
				smin=1,
				smax=4,
				grav=0,
			})
		end
    end 
	
	for e in all(portal_explodes) do
		for n=0,e.q do
			circ(e.x,e.y,e.r-n*2,7)
			
			if e.r>200 then del(portal_explodes,e) end
		end
		e.r+=8
	end

end



--#trap
trap_lane=0
trap_x=-100
trap_y=-100
trap_t=0
trap_st=0
function trap_create(lane)
	trap_st=1
	trap_ps={}
	trap_lane=lane
	trap_x=p_x
	trap_y=lanes[lane]
	trap_t=0

	p_traps=max(0,p_traps-1)
end

function trap_update()
		if trap_st==1 then
			trap_x+=2
			if trap_x>30 then trap_st=2 end
		end
		
		if trap_st==2 then
			-- @sound of trap opening, one-timer
			
			for n=0,48 do
				local obj={
					ox=random(trap_x-6,trap_x+16),
					oy=random(trap_y,trap_y+16),
					c=10
				}
				obj.x=obj.ox
				obj.y=obj.oy
				local ang = atan2(trap_x+6-obj.x, trap_y+14-obj.y)	
				obj.dx,obj.dy=dir_calc(ang,1.25)
				
				add(trap_ps,obj)
			end
			
			trap_st=3
		end
		
		if trap_st==3 then
			trap_t+=1

			if trap_t==175 then sfx(2) end

			if trap_t>210 then 
				trap_st=4
				
			end --time to end
			
			for p in all(trap_ps) do
				p.x+=p.dx
				p.y+=p.dy
				p.c=rnd_table({10,7,9,12})
				
				if p.y>trap_y+16 or p.x<trap_x-6 or p.x>trap_x+16 or p.y<trap_y then 
					p.x=p.ox
					p.y=p.oy
				end
				
				
			end
		end
		
		if trap_st==4 then
			trap_x-=2
			if trap_x<-16 then trap_st=0 end
		end
	
end


function trap_draw()
	palt(0,false)
	palt(14,true)
	if trap_st>0 then
		if trap_st<3 or trap_st==4 then spr(57,trap_x,trap_y+13,2,1) end
		if trap_st==3 then
			spr(43,trap_x,trap_y+10,2,2)
		
			for p in all(trap_ps) do
				pset(p.x,p.y, p.c)
			end
		end
	end
	
end



--#puft
function puft_init()
	puft_x=130
	puft_dir=-1
	puft_ang=0
	puft_st=0
	puft_y=lanes[1]
	puft_bottom=lanes[1]+1.8
end


function puft_update()
	if puft_st>0 then
		puft_x+=.15*puft_dir
		puft_ang+=0.01 --distance between crests, higher=closer
		puft_y = lanes[puft_st]+sin(puft_ang)*2
		
		if puft_x<-40 then 
			puft_dir=1
			puft_st+=1
			if puft_st>3 then puft_st=1 end
			puft_bottom=lanes[puft_st]+1.8
		end

		if puft_x>150 then 
			puft_st+=1
			puft_x=130
			if puft_st>3 then puft_st=1 end
			puft_y=lanes[puft_st]
			puft_bottom=lanes[puft_st]+1.8
			
			puft_dir=-1
		end

		if puft_y>puft_bottom and puft_x>0 and puft_x<128 and shake<1 then shake=1 end
	end
end

function puft_draw(s)
	if puft_st==s then
		palt(14,true)
		palt(0,false)
		spr(35,puft_x,puft_y,2,3)
		palt()
	end
end








--#meter
function meter_draw()
		local hpbarx1,hpbarx2=22,58
		local hpbary1,hpbary2=116,124
		local hpbarw=flr((hpbarx2-hpbarx1)*(p_power/100))
		
		rectfill(hpbarx1,hpbary1, hpbarx2,hpbary2, 0)
		rectfill(hpbarx1,hpbary1, hpbarx1+hpbarw,hpbary2, 8)
		rect(hpbarx1,hpbary1, hpbarx2,hpbary2, 7)
		print("overheat",hpbarx1+3,hpbary1+2, 1)
		
		
		local hpbarx1,hpbarx2=62,120
		local hpbary1,hpbary2=116,124
		local hpbarw=flr((hpbarx2-hpbarx1)*(p_slime/100))
		
		rectfill(hpbarx1,hpbary1, hpbarx2,hpbary2, 0)
		rectfill(hpbarx1,hpbary1, hpbarx1+hpbarw,hpbary2, 11)
		rect(hpbarx1,hpbary1, hpbarx2,hpbary2, 7)
		print("slime",hpbarx1+20,hpbary1+2, 1)

		rectfill(4,116, 18,124, 0)
		rect(4,116, 18,124, 7)
		print("t"..p_traps, 6,118, 7)

end








--#charselect



function charselect_init()
	local select_pos=1
	
	if charmode>0 then
		selects={"peter","ray","egon","winston"}
	else
		selects={"holtz","erin","abby","patty"}
	end
	
	
	function charselect_update()
		if btnp(1) then select_pos+=1 end
		if btnp(0) then select_pos-=1 end
		if btndp then select_pos+=2 end
		if btnup then select_pos-=2 end
		
		if select_pos<1 then select_pos=1 end
		if select_pos>4 then select_pos=4 end
		
		p_char=selects[select_pos]
		
		if btnzp then scene_init() end
	end

	function charselect_draw()
		rectfill(0,0,127,127,1)
		
		center_text("select your ghostbuster",5,7)
		
		if charmode>0 then
			draw_char("peter",30,30)
			print("peter",28,55,7)
			
			draw_char("ray",80,30)
			print("ray",82,55,7)
			
			draw_char("egon",30,80)
			print("egon",30,105,7)
			
			draw_char("winston",80,80)
			print("winston",74,105,7)
		else
			draw_char("holtz",30,30)
			print("holtzmann",20,55,7)
			
			draw_char("erin",80,30)
			print("erin",80,55,7)
			
			draw_char("abby",30,80)
			print("abby",30,105,7)
			
			draw_char("patty",80,80)
			print("patty",78,105,7)
			
		end
		
		
		if select_pos==1 then rect(15,20, 60,65, 10) end
		if select_pos==2 then rect(65,20, 110,65, 10) end
		if select_pos==3 then rect(15,70, 60,115, 10) end
		if select_pos==4 then rect(65,70, 110,115, 10) end
	end
	
	
	
	cart_control(charselect_update,charselect_draw)
end





--#game
function game_init()
	slimers={}

	--puft_init()
	rowan_st=1
	foo=0
	foox=130
	fool=p_lane
	fooy=lanes[fool]
	fooang=0
	footrig=-30
	level_kills=0
	
	function game_update()
		
		
		portal_update()
		p_update()
		slimer_update()
		expl_update()
		
		trap_update()
		puft_update()
		
		if current_level==4 then --rowan scales into mirror
			rowan_jump_update()
		end

		if p_slime>=40 and puft_st<1 then
			puft_st=1
		end
		
		if p_slime>=100 then
			gameover_init()
		end
		
		if #portals<=0 then
			p_canfire=false
			
			if wait(45) then
				current_level+=1
				
				if current_level<6 then
					scene_init() --continue	
				else
					victory_init()
				end
				
			end
		end
		
		if current_level==5 then
			if foo>=90 then
				
				foox-=3.5
				fooang+=0.1 --distance between crests
				fooy+=sin(fooang)*1 --height of wave
				
				if fool==p_lane and foox<muzzle_x-8 and foox>0 and p_invincible<1 then
					p_slimed=true
					p_t=0
				end
				
				
				if foox<=footrig then
					foox=130
					
					if rnd()<.4 then
						fool=p_lane
					else
						fool=random(1,4)
					end
					
					fooy=lanes[fool]
					footrig=flr(rnd(90)+60)*-1
				end
			end
			
			foo+=1
		end

	end

	
	

	function game_draw()
		screenshake()
		game_drawbg()
		p_draw()
		trap_draw()
		portal_draw()
		expl_draw()
		slimer_draw()
		
		
		if current_level==4 then
			rowan_jump_draw()
		end
		
		if current_level==5 then
			if foo>=90 then
				palt(0,false)
				palt(13,true)
				zspr(147,4,4,foox,fooy,.9)
				palt()
			end
		end
	end
	
	

	
	cart_control(game_update,game_draw)
end




function game_drawbg() 
		camera(0+cam_x,bglayer1_cy+cam_y)
		puft_draw(1)
		palt(0,false)
		palt(14,true)
		map(0,0, -60,-2, 16,3) --grey city
		map(0,0, 44,-2, 16,3) --grey city
		rectfill(0,20,127,60, 5)
		skyfade(47,4)
		palt()
		
		camera(0+cam_x,bglayer2_cy+cam_y)
		puft_draw(2)
		palt(0,false)
		palt(14,true)
		pal(5,2) --red city
		map(0,0, 0,25, 16,3) --grey city
		rectfill(0,48,127,127, 2)
		skyfade(73,8)
		palt()
		
		camera(0+cam_x,0+cam_y)
		puft_draw(3)
		palt(0,false)
		palt(14,true)
		pal(5,1) --blue city
		rectfill(0,75,127,127, 1)
		map(0,0, -30,56, 16,3)
		map(0,0, 70,53, 16,3)
		
		skyfade(110,0)
		
		
		--layers
		local layer_h=20
		pal(5,5) 
		camera(0+cam_x,bglayer1_cy+cam_y)
		map(0,3, layer1_x,lanes[1]+layer_h, 16,1) --1
		camera(0+cam_x,bglayer2_cy+cam_y)
		
		map(0,3, layer2_x,lanes[2]+layer_h, 16,1) --2
		camera(0+cam_x,0+cam_y)
		map(0,3, 0,lanes[3]+layer_h, 16,1) --3
		map(0,3, 0,lanes[4]+layer_h, 16,1) --4
		
		
		map(0,4, 0,117, 16,1) --4
		map(0,4, 0,125, 16,1) --4
		pal()	
		
		meter_draw()
		
	end




--#victory screen, you win!
function victory_init()
	
	--p_lane=4
	vic_st=1
	
	
	rowan_x,rowan_y,rowan_a=130,p_y,0
	
	function bobbing()
		rowan_a+=0.02
		rowan_y=p_y+sin(rowan_a)*4
	end
	

	function victory_update()
		p_canfire=false
		firing=false
		p_slimed=false
		p_y=lanes[p_lane]
		trap_update()
		expl_update()
		
		if vic_st==1 then
			if t==20 then
				if p_lane==3 then
					rowan_y=p_y
					vic_st=2
				else
					if p_lane==4 then
						p_lane=3
					else
						p_lane+=1
					end
					t=0
				end
			end
		end
		
		if vic_st==2 then
			bobbing()
			rowan_x=max(70,rowan_x-1)
			if rowan_x==70 then
				vic_st=3
				t=0
			end
		end
		
		if vic_st==3 then
			bobbing()
			if t>30 then vic_st=4 end
		end
		
		
		if vic_st==4 then
			trap_create(p_lane)
			vic_st=5 t=0
			rowan_scale=1
			
		end
		
		if vic_st==5 then
			bobbing()
			if t>30 then
				vic_st=6
				t=0
			end
		end
		
		if vic_st==6 then
			if t<30 then
				rowan_x+=1
				rowan_y-=2
				rowan_ang = atan2(trap_x+2-rowan_x, trap_y+12-rowan_y)
				rowan_dx,rowan_dy=dir_calc(rowan_ang,1.5)
			else
				rowan_scale=max(0,rowan_scale-.014)
				rowan_x+=rowan_dx
				rowan_y+=rowan_dy
				
				if t>250 then
					vic_st=7
				end
			end
		end
		
		
		if vic_st==7 then
			if layer1_x>-128 then layer1_x-=5 end
			if layer2_x<128 then layer2_x+=5 end
			
			if layer2_x>=128 then
				if bglayer1_cy>-129 then 
					bglayer1_cy=min(128,bglayer1_cy-1.6)
					bglayer2_cy=min(128,bglayer2_cy-1)
				else 
					vic_st=8
					t=50
					intro_text(";_;thank you ghostbusters!;")
					intro_text(";_;the city is once again safe...;")
					intro_text(";_;...for now;")
					intro_text("design+code;@morningtoast;")
					intro_text("music+sounds;@gnarcade_vgm;")
					intro_text("character art;hal laboratory, 1990;;additional art;@morningtoast;@beetleinthebox;")
					intro_text(";_;you busted "..kills.." ghosts;")
					
					if unlocked<1 then
						
						intro_text(";_;special characters unlocked;please play again;")
					else
						intro_text(";_;thanks for playing;")
						intro_text(";_;please try other games;from @morningtoast;")
					end
					
					intro_init(ef)
				end
			end
		end
		
		if vic_st==8 then
			if t==50 then
				expl_create(rnd(100)+10,rnd(40)+10, 64, {
					colors={2,3,4,7,8,9,10,11,12,13,14,15},
					grav=.2,
					dur=35, --30
					den=2, --0
					smin=1, --1
					smax=2 --1
				})
				t=0
			end
			
			if btnxp or btnzp then
				
				
				if unlocked>0 then
					title_init() 
				else
					unlock_init()
				end
			end
			
		end

	end


	function victory_draw()
		
		rectfill(0,0,128,128,0)
		skyfade(63,2)
		rectfill(0,61,128,128,12)
		skyfade(77,11)
		skyfade(79,3)
		
		pal(5,1)
		spr(80, 31,40, 1,3) --liberty
		pal()
		
		game_drawbg()
		camera(0,0)
		p_draw()
		trap_draw()
		expl_draw()
		
		if vic_st<6 then
			rowan_draw(rowan_x,rowan_y)
		end
		
		if vic_st==6 then
			palt(0,false)
			palt(13,true)
			zspr(147,4,4,rowan_x,rowan_y,rowan_scale)
			palt()
		end
		
		if vic_st==8 then
			intro_draw()
		end
	end

	cart_control(victory_update,victory_draw)
end




-- #unlock - unlock bonus characters
function unlock_init()
	t=0
	unlocked=1
	dset(0,1)

	cart_control(ef,unlock_draw)
end

function unlock_draw()
	rectfill(0,0,128,128,1)
	center_text("who you gonna call?",15,8)
	center_text("classic characters unlocked",30,10)
	center_text("use \131\148 to switch modes",50,7)
	center_text("at the title screen",58,7)
	
	center_text("press \142 to continue",80,6)
	
	draw_char("peter", 10,100)
	draw_char("ray", 40,100)
	draw_char("egon", 70,100)
	draw_char("winston", 100,100)
	
	if t>30 then
		if btnzp or btnxp then title_init() end
	end
end


--#over, game over screen
function gameover_init()
	slimedrop={}
	
	
	function gameover_update()
		slimer_update()
		expl_update()
		trap_update()
		puft_update()
		
		slimedrop_min=999
		for s in all(slimedrop) do
			s.y+=rnd(1)+1
			
			if s.y<slimedrop_min then slimedrop_min=s.y end
			
			if s.y>130 then s.y=130 end
		end
		
		if slimedrop_min>130 then
			if btnzp or btnxp then title_init() end
		end
		
	end


	function gameover_draw()
		game_drawbg()
		p_draw()
		trap_draw()
		portal_draw()
		expl_draw()
		slimer_draw()

		for s in all(slimedrop) do
			circfill(s.x,s.y,s.r,11)
		end

		rectfill(-8,0, 130,slimedrop_min+3, 11)
		
		if slimedrop_min>130 then
			center_text("game over",30,3)
			center_text("you busted "..kills.." ghosts",50,3)
			center_text("press \142 to play again",85,3)
		end
	end
	
	
	cart_control(gameover_update,gameover_draw)
	
	for n=0,16 do
		add(slimedrop,{r=rnd(5)+5,x=8*n,y=rnd(6)*-1})
	end
	
	slimedrop_min=0
end





--#rowan
function rowan_reset()
	rowan_y=-50
	rowan_x=50
	rowan_a=0
	rowan_next=fn	
	rowan_st=1
	rowan_scale=32
end

function rowan_draw(x,y)
	x=x or rowan_x
	y=y or rowan_y

	expl_create(x+16,y+16, 1, {
		dur=15, --30
		den=1, --0
		decay=.1,
		colors={7,14,12,2,10,15},
		smin=1, --1
		smax=3, --1
		grav=0, --.3
		dir=0, --0 (all directions)
		range=0 --0
	})
	
	palt(0,false)
	palt(13,true)
	spr(147, x,y, 4,4)
	palt()
end

function rowan_bob()
	rowan_a+=0.02
	rowan_y = 35+sin(rowan_a)*4
end

-- level 3 jump into mirrors
function rowan_jump_update()

	if rowan_st==1 then
		rowan_pick=rnd_table(portals)
		rowan_stopmin=lanes[rowan_pick.lane]-5
		rowan_stopmax=lanes[rowan_pick.lane]+5
		
		local ang = atan2(rowan_pick.x+8-rowan_x, rowan_pick.y+4-rowan_y)
		rowan_dx,rowan_dy=dir_calc(ang,2.25)
		rowan_scale=32
		
		rowan_st=2
	end
	
	if rowan_st==2 then
	
		rowan_y+=rowan_dy
		rowan_x+=rowan_dx
		rowan_scale-=1
		
		if rowan_scale<=0 then
			rowan_st=2.1
			portals[rowan_pick.lane].jump=true
		end
	end
	
	if rowan_st==3 then
		rowan_bob()
	end
	
	
	
end


function rowan_jump_draw()
	if rowan_scale>0 then
		palt(0,false)
		palt(13,true)
		sspr(24,72, 32,32, rowan_x,rowan_y, rowan_scale,rowan_scale)
		palt()
	end

end


-- scene entrance
function rowan_entrance_update()
	tbx_update()
	
	--rowan comes down
	if rowan_st==1 then
		if rowan_y<35 then rowan_y+=1 else rowan_st=2 end
	end
	
	--bob when it reaches the bottom, wait a bit then talk
	if rowan_st==2 then
		rowan_bob()
		if wait(40,true) then
			rowan_st=3
			textbox(level.rowan_text,14,68,7)
		end
	end
	
	--talk while bobbing
	if rowan_st==3 then
		rowan_bob()
		
		if btnzp then rowan_st=4 end
	end
	
	if rowan_st==4 then
		rowan_bob()
		if wait(25,true) then
			rowan_st=5
		end
	end
	
	if rowan_st==5 then
		if current_level!=4 then --float up out of screen to start play
			if rowan_y>-50 then
				rowan_y-=2
			else
				if current_level==5 then
					portal_jump_pick(99)
				end
			
				game_init()
			end
		else
			game_init()
		end

	end
end

function rowan_entrance_draw()
	rowan_draw()
	
	if rowan_st==3 then
		draw_textbox()
		tbx_draw()
		
		if tbx_finish() then
			print("\142",107,97,7) 
		end
	end
end

function draw_textbox()
	rectfill(10,65, 117,105, 0)
	rect(10,65, 117,105, 7)
end




--#scenes
function scene_reset()
	p_canfire=false
	p_slimed=false
	firing=false
end

--#levels
levels={
	{ -- level 1
		portal_hp=50,
		portal_spawn=60, -- spawn of next slimer is between 30f and this number
		portal_offset={36,24,12,0},
		slimer_hp=10,
		slimer_speed=.5,
		slimer_max=7,
		rowan_text="i am gozer! prepare to meet your doom. these portals will allow my ghost army to conquer your world."
	},
	{ -- level 2
		portal_hp=50,
		portal_spawn=50,
		portal_offset={0,12,24,36},
		slimer_hp=10,
		slimer_speed=.6,
		slimer_max=10,
		rowan_text="you can't stop us all. the end is near, pitiful humans!"
	},
	{ -- level 3
		portal_hp=50,
		portal_spawn=50,
		portal_offset={36,12,36,12},
		slimer_hp=10,
		slimer_speed=.7,
		slimer_max=8,
		rowan_text="impressive but my amry of spirits is endless. you shall all perish!"
	},
	{ -- level 4, jumping mirrrs
		portal_hp=50,
		portal_spawn=50,
		portal_offset={0,0,0,0},
		slimer_hp=10,
		slimer_speed=.8,
		slimer_max=10,
		rowan_text="i shall lead my minions and darkness will consume your world."
	},
	{ -- level 5, boss fight
		portal_hp=50, --50
		portal_spawn=50,
		portal_offset={0,0,0,0},
		slimer_hp=6,
		slimer_speed=.8,
		slimer_max=15,
		rowan_text="gozer the destructor has come! now you must die!"
	}
}

function scene_init()
	level=levels[current_level]
	
	wait_reset()
	scene_reset()
	portal_reset()
	rowan_reset(game_init)

	function scene_update()
		rowan_entrance_update()
		expl_update()
	end

	function scene_draw()
		game_drawbg()
		p_draw()
		
		portal_draw()
		expl_draw()
		
		rowan_entrance_draw()
		rowan_draw()
	end

	cart_control(scene_update,scene_draw)
end













-- #intro
function boot_init()
	play_music(0)
	intro_text("bustin' v"..version..";(c)brian vaughn, 2017-2021;_;_;design+code;brian vaughn;@morningtoast;_;_;music+sound;brian follick;@gnarcade_vgm;")
	intro_text("_;_;_;for penny;")
	intro_init(title_init)

	cart_control(ef,intro_draw)
end




--#title
function title_init()
	t=0
	sspr_wh=12
	logo_xy=60
	
	city1_y=144
	city1_ystop=24
	city2_y=130
	city2_ystop=30
	
	bglayer1_cy=0
	bglayer2_cy=0

	layer1_x=0
	layer2_x=0
	intro_all={}
	intro_st=0
		
	cam_x,cam_y=0,0
	
	cart_control(title_update,title_draw)
	
	p_lane=2
	p_x,p_y,p_dir=2,lanes[p_lane],1
	p_power=0
	p_slime=0
	p_cooldown=0
	p_slimed=false
	p_canmove=true
	p_canfire=true
	p_invincible=0
	p_traps=3
	kills=0

	fire_w=0
	fire_t=0 --needed for sine wave	
	
	puft_init()
	puft_y=25
	
	current_level=1 --debug
end

function title_update() 
	logo_xy-=2
	sspr_wh+=3
	
	if sspr_wh>64 then sspr_wh=64 end
	if logo_xy<26 then logo_xy=26 end
	
	if btnzp then 
		puft_st=0
		charselect_init() 
		--victory_init()
	end
	
	if t>20 then
		if city1_y>city1_ystop then city1_y-=1 end
		if city2_y>city2_ystop then city2_y-=1 end
	end
	
	if t>400 and puft_st==0 then puft_st=1 end
	
	if puft_st==1 then
		puft_x+=.15*puft_dir
		puft_ang+=0.01
		puft_y = 25+sin(puft_ang)*2
		
		if puft_x<-40 then puft_dir=1 end
		if puft_x>140 then puft_st=2 end
	end
	
	if t<1000 then t+=1 end
	
	if (btnup or btndp) and unlocked>0 then
		charmode+=1
		if charmode>1 then charmode=0 end
	end
end

function title_draw()
	puft_draw(1)
	
	pal(5,2) --red city
	palt(14,true)
	rectfill(0,city1_y+18,127,city1_y+18+80, 2)
	map(0,0, -20,city1_y, 16,3)
	map(0,0, 80,city1_y, 16,3)
	pal()
	
	
	
	pal(5,1) --blue city
	palt(14,true)
	rectfill(0,city2_y+22,127,city2_y+22+127, 1)
	map(0,0, -30,city2_y, 16,3)
	map(0,0, 40,city2_y, 16,3)
	pal()
	
	skyfade(city2_y+95,0)
	
	
	
	palt(14,true)
	palt(0,false)
	sspr(24,40, 32,32, logo_xy+4,logo_xy-15, sspr_wh,sspr_wh)
	pal()
	
	if sspr_wh>=64 then
		spr(87, 30,logo_xy+38, 9,3)
		
		if charmode>0 then
			center_text("who you gonna call?",90,8)
		else
			center_text("makes me feel good",90,11)	
		end

		center_text("press \142 to start",108,7)
	end
end



-- #loop

 --load savedata
cartdata("bustin2017")

-- Pause menu options
menuitem(1, "toggle music", function() 
	if musicon then musicon=false music(-1) else musicon=true play_music(0) end
end)

menuitem(2, "clear save data", function()
	dset(0,0)
	unlocked=0
	charmode=0
	title_init()
end)


function _init()
	unlocked=1 --dget(0)
	
	tbx_init()
	boot_init()
	--title_init()
end

function _update()
	btnup=btnp(2)
	btndp=btnp(3)
	btnz=btn(4)
	btnzp=btnp(4)
	btnxp=btnp(5)
	
	cart_update()

	t=min(32000,t+1)
end


b=0
function _draw()
	cls()

	cart_draw()
end







-- #utilities and helpers
ef=function() end
cart_control=function(u,d)
	cart_update,cart_draw=u,d
	t=0
end


function zspr(n,w,h,dx,dy,dz)
  sx = 8 * (n % 16)
  sy = 8 * flr(n / 16)
  sw = 8 * w
  sh = 8 * h
  dw = sw * dz
  dh = sh * dz

  sspr(sx,sy,sw,sh, dx,dy,dw,dh)
end


shake,shake_t=0,0
cam_x=0 cam_y=0
function screenshake()
	cam_x=0 cam_y=0
	if shake>0 then
		
		local shaker=1
		if rnd()<.5 then shaker=-random(1,2) end
		
		cam_x+=shaker*rnd_table({-1,1,-1,1})
		cam_y+=shaker*rnd_table({-1,1,-1,1})

		shake_t+=1
		if shake_t>3 then 
			shake=0
			shake_t=0 
		end
	end
end


function play_music(track)
	if musicon then music(track) end	
end

	
--[[#state
states={}
function st_add(st) add(states,st) end
function st_rm(st) del(states,st) end
function st_chg(st) st_reset() st_add(st) end
function st_reset() states={} end
function st_clear(st)
	local nextst=st+1
	for n in all(states) do
		if n>=st and n<nextst then st_rm(n) end
	end
end
function st_is(st) 
	if in_table(states, st) then return true else return false end
end
function st_debug()
	local t=""
	for n in all(states) do
		t=n.."-"..t
	end
	return t
end
]]

timers={}
function timer_set(t) timers[t]=0 end
function timer_get(t) return timers[t] end
--function timer_rm(t) timers[t]=false end
--[[
function timer_is(t,limit)
	limit=limit or 32000
	
	if timers[t] then
		if timer_get(t)>limit then return true end
	end
	return false
end
]]

function timer(t,limit,reset)
	reset=reset or true
	limit=limit or 32000
	
	if not timers[t] then
		timer_set(t)
	else
		timers[t]+=1
	end
	
	if timer_get(t)>limit then 
		if reset then timer_set(t) end
		return true 
	end
	return false
end
	
	
wait_t=0
function wait(max,reset)
	reset=reset or false
	
	if wait_t<max then 
		wait_t+=1 	
		return false
	else
		if reset then wait_t=0 end
		return true
	end
end
function wait_reset() wait_t=0 end


--text drawing
function tbx_init()
	tbx_counter=1
	tbx_width=26 --characters not pixels
	tbx_lines={}
	tbx_cur_line=1
	tbx_com_line=0
	tbx_text=nil
	tbx_x=nil
	tbx_y=nil
end


function tbx_finish()
	if tbx_com_line+1==#tbx_lines then return true else return false end
end

function tbx_update()
 if tbx_text!=nil then 
 local first=nil
 local last=nil
 local rows=flr(#tbx_text/tbx_width)+2
 
 --split text into lines
 for i=1,rows do
  first =first or 1+i*tbx_width-tbx_width
  last = last or i*tbx_width
			
  --cut off incomplete words
  if sub(tbx_text,last+1,last+1)!="" or sub(tbx_text,last,last)!=" " and sub(tbx_text,last+1,last+1)!=" " then
   for j=1,tbx_width/3 do
    if sub(tbx_text,last-j,last-j)==" " and i<rows then
     last=last-j
     break
    end
   end
  end
  
  --create line
  --if first char is a space, remove the space
  if sub(tbx_text,first,first)==" " then
   tbx_lines[i]=sub(tbx_text,first+1,last)
  else
   tbx_lines[i]=sub(tbx_text,first,last)
  end
   first=last
   last=last+tbx_width
 end
 
 --lines are now made
 
 
 --change lines after printing
 if tbx_counter%tbx_width==0 and tbx_cur_line<#tbx_lines then
  tbx_com_line+=1
  tbx_cur_line+=1
  tbx_counter=1  
 end
 --update text counter
 tbx_counter+=1
 if (sub(tbx_text,tbx_counter,tbx_counter)=="") tbx_counter+=1
 end
end


function tbx_draw()
 if #tbx_lines>0 then
  --print current line one char at a time
  print(sub(tbx_lines[tbx_cur_line],1,tbx_counter),tbx_x,tbx_y+tbx_cur_line*6-6,tbx_col)

 
  --print complete lines
  for i=0,tbx_com_line do
   if i>0 then
    print(tbx_lines[i],tbx_x,tbx_y+i*6-6,tbx_col)
   end
  end
 end 
end


function textbox(text,x,y,col)
	tbx_init()
	tbx_x=x or 4
	tbx_y=y or 4
	tbx_col=col or 7
	tbx_text=text
end

	
--#intro scenes
intro_all={}
function intro_text(txt) add(intro_all, txt) end

function intro_complete()
	if not intro_st then intro_st=1 else intro_st+=1 end
	intro_t=0
	intro_color=0
	
	if intro_st>#intro_all then
		intro_st=0
		intro_all={}
		return true
	else return false end
end

function intro_init(oncomplete)
	
	intro_complete()
	intro_func=oncomplete
	
	for k,txt in pairs(intro_all) do intro_all[k]=split(txt) end
end

function intro_draw()
	intro_y=10
	
	for line in all(intro_all[intro_st]) do
		if line!="_" then
			print(line, 64-(#line*2),intro_y, intro_color) --centers text
		end
		
		intro_y+=7
	end
	
	-- fadein
	if intro_t>3 then intro_color=1 end
	if intro_t>6 then intro_color=5 end
	if intro_t>9 then intro_color=13 end
	if intro_t>12 then intro_color=6 end
	if intro_t>15 then intro_color=7 end
	
	--display as white for ~3s
	
	--fadeout
	if intro_t>100 then intro_color=6 end
	if intro_t>103 then intro_color=13 end
	if intro_t>106 then intro_color=5 end
	if intro_t>109 then intro_color=1 end
	if intro_t>112 then intro_color=0 end
	
	--faded out + wait, load next
	if intro_t>120 then 
		if intro_complete() then intro_func() end
	end
	
	intro_t+=1
	
end


-- split(string, delimter)
function split(s,dc)
	dc=dc or ";"
	local a={}
	local ns=""
	
	
	while #s>0 do
		local d=sub(s,1,1)
		if d==dc then
			add(a,ns)
			ns=""
		else
			ns=ns..d
		end
	
		s=sub(s,2)
	end
	
	return a
end	
	
	

--[[ checks to see if value is in a table
function in_table(tbl, element)
  for _, value in pairs(tbl) do
    if value == element then
      return true
    end
  end
  return false
end
]]
	
function center_text(s,y,c) print(s,64-(#s*2),y,c) end

function skyfade(y,c,inv,rows)
	rows=rows or {0,1,2,4,5,7,10,15}
	inv=inv or -1

	for b in all(rows) do
		line(0,y+b*inv, 127,y+b*inv, c)
	end
end


	
--sine boxrender
--by lumiette

--game
pi=3.14159265359
function sine(amplitude, speed, phase)
  phase=phase or 1
  return amplitude * (sin((t+phase/pi)*speed))
end

function draw_sine(spd,phs,tl,br,colour,thickness, border, bg)
-- params: speed, phase, 
--         top-left xy, bottom-right xy,
--         wave colour, border colour, background colour 
 bg=bg or false  border=border or false  colour=colour or 7  thickness=thickness or 2
 tl=tl or {64-32,64-16} br=br or {64+32, 64+16}
 tx=tl[1] ty=tl[2] bx=br[1] by=br[2]
 x=bx-tx y=by-ty-1+thickness


 for j=1,thickness do
   for i=0,x-2 do
    wave=sine(y/2,spd,phs+i)
    pset(i+tx+1,ty+(y-1)/2-(j/2)+j+wave+1,colour)
   end
  end
end



function dir_calc(angle,speed)
	local dx=cos(angle)*speed
	local dy=sin(angle)*speed
	
	return dx,dy
end

--[[
function distance(ox,oy, px,py)
  local a = ox-px
  local b = oy-py
  return pythag(a,b)
end
]]

function random(min,max)
	n=round(rnd(max-min))+min
	return n
end

-- round number to the nearest whole
function round(num, idp)
  local mult = 10^(idp or 0)
  return flr(num * mult + 0.5) / mult
end


function rnd_table(t)
	local r=flr(rnd(#t))+1
	return(t[r])
end

function is_even(n) 
	if (n%2==0) then return true else return false end
end


--[[
function offscreen(x,y)
	if (x<screen_x or x>screen_w or y<screen_y or y>screen_h) then 
		return true
	else
		return false
	end
end
]]

--[[ returns true if hitbox collision 
function collide(ax,ay,ahb, bx,by,bhb)

    -- get the intersection of p and af
	  local l = max(ax+ahb.x,        bx+bhb.x)
	  local r = min(ax+ahb.x+ahb.w,  bx+bhb.x+bhb.w)
	  local t = max(ay+ahb.y,        by+bhb.y)
	  local b = min(ay+ahb.y+ahb.h,  by+bhb.y+bhb.h)

	  -- they overlapped if the area of intersection is greater than 0
	  if l < r and t < b then
		return true
	  end
					
	return false
end	
]]




--[[
	basic explosion particle library

	in-game use:
	expl_create(x,y, numberofparticles, optoinstable)
	
	optionstable
	{
		dur=durationinframes, --30
		den=startingsizeofparticle, --0
		decay=rateofsizereduction, --.25
		colors=tableofcolors, --{7,10,9}
		smin=minspeedofparticles, --1
		smax=maxspedofparticles, --1
		grav=maxgravity, --.3
		dir=directionofforce, --0 (all directions)
		range=distributionanglearounddirection --0
	}
	
	
	add these functions to your system loops:
	expl_update()
	expl_draw()
		
]]



expl_all={}
function expl_create(x,y, size, options)
	for n=1,size do
		local obj={
			x=x,y=y,
			t=0,
			dur=30,
			den=0,
			decay=.25,
			dia=0,
			colors={7,10,9},
			smin=.25,
			smax=1,
			grav=.3,
			dir=0,
			range=0
		}
		
		if options then
			for k,v in pairs(options) do obj[k] = v end
		end
		
		local c=flr(rnd(#obj.colors))+1
		local sp=rnd(obj.smax-obj.smin)+obj.smin

		if obj.dir>0 then
			if obj.range>0 then
				local dirh=obj.range/2
				local dira=obj.dir-dirh
				local dirb=obj.dir+dirh

				obj.dir=rnd(dirb-dira)+dira
			end
		else
			obj.dir=rnd()	
		end
	
		obj.c=obj.colors[c]
		obj.g=rnd(abs(obj.grav))
		obj.dx=cos(obj.dir)*sp
		obj.dy=sin(obj.dir)*sp
		
		if obj.grav<0 then obj.g*=-1 end
		
		add(expl_all,obj)
	end
end

function expl_update()
	foreach(expl_all, function(o)
		o.dy+=o.g
		o.y+=o.dy
		o.x+=o.dx
		o.t+=1
		o.den-=o.decay
		o.dia=max(o.den,0)

		if o.t>o.dur then del(expl_all, o) end
	end)
end

function expl_draw()
	foreach(expl_all, function(e)
		circfill(e.x,e.y, e.dia, e.c)
	end)
end

