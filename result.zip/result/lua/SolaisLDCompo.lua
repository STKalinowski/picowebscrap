// main game

function _init()
 game_screen=create_screen(
 	create_game,
	 update_game, 
	 draw_game)
	 
	music(0)
	 
	current_screen=game_screen
end

// screens
current_screen=nil

function create_screen(i,u,d)
 local screen={}
 i(screen)
 screen.update=u
 screen.draw=d
 return screen
end

sin_time=0
dt=0.01667
//dt=0.03333

function _update60()
//function _update()
 sin_time+=dt
 if sin_time>100 then
  sin_time-=100
 end
 if current_screen then
  current_screen.update(current_screen)
 end
end



function _draw()
 cls()
 
 if current_screen then
  current_screen.draw(current_screen)
 end
 
 
end
-->8

camerax=0
cameray=0
camerazone=nil

map_anim_time=0

rooms={}
current_room=nil

function create_game(s)
 // setup game screen stuff
 init_particles(64)
 init_lfx(64)
 create_player(28,0)
 player.standby=true
 player.x=55*8
 player.y=26*8
 player.flame.x=player.x
 player.flame.y=player.y 
 //create_player(115*8,2*8)
 //create_player(31*8,34*8)
 //create_player(13*8,35*8)
 camerax=48*8
 cameray=16*8
 refresh_room() 


 s.shadow=0
 s.shadowtime=5
 
 s.time=0
 s.timing=true
end

function room_key(rx,ry)
 return (ry*16+rx)+1
end

was_new=false
function refresh_room()
 local rx=flr(camerax/128)
 local ry=flr(cameray/128)
 local key=room_key(rx,ry)
 // created room already?
 if rooms[key]!=nil then
  current_room=rooms[key]
  was_new = false
 else
	 was_new=true
	 if player.standby==false then
		 room_whisper+=1
		 if room_whisper>=whisp_loc[whisp_loc_i] then
		  whisper()
		  whisp_loc_i+=1
		 end
		end
  current_room={}
  current_room.flames={}
  add(current_room.flames,player.flame)
  current_room.things={}
  add(current_room.things,player)
  // create stuff
	 
	 // special
	 //powerup
	 if rx==4 and ry==0 then
	  create_powerup(72*8,11*8)
	 end
	 
	 for x=0,16 do
	  for y=0,16 do
	   local mx=rx*16+x
	   local my=ry*16+y
	   local t=mget(mx,my)
	   
	   // flames
	   if t==16 then
		   create_flame_source(mx*8+4,my*8+4,current_room.flames)
		   mset(mx,my,50)
		  end
		  
		  // sprongs
		  if t>=59 and t<=62 then
		   create_spring(mx*8+4,my*8+4,t)
		  end
		  
		  // convayers
		  if t==36 or t==39 then
		   create_convayer(mx,my,t==39)
		  end
		  
		  // checkpoint
		  if t==112 then
		   local ch={}
		   ch.x=mx*8+8
		   ch.y=my*8
		   current_room.checkpoint=ch
		  end
		  
		  // eyeballs
		  if t==086 then
		   create_eyeball(mx*8,my*8)
		  end
		  
	  end
	 end
	 rooms[key]=current_room

 end
 
 // update thing list
 flame_sources=current_room.flames
 things=current_room.things
end

show_checkpoint=false
starting=false

function update_game(s)

 show_checkpoint=false
 
 map_anim_time+=dt
 if map_anim_time>0.05 then
  animate_map()
  map_anim_time-=0.05
 end
 
 if player.standby then
  player.dc=2
  player.flame.tpow=1
  if starting==false then
   if btn(4) then
	   starting=true
	   sfx(4)
	  end
  else
   s.shadow+=dt*4
   if s.shadow>=s.shadowtime then
    s.shadow=0
    player.standby=false
    starting=false
    player.x=player.respawnx
    player.y=player.respawny
    player.flame.x=player.x
    player.flame.y=player.y
    player.wrapwarped=true
    update_lfx()
   end
  end
 else
 
	 if (player.flame.pow<=0.2) and player.dead==false and player.showtime==false then
	  s.shadow+=dt
	  s.shadow=min(s.shadowtime,s.shadow)
	 else
	  s.shadow*=0.9
	 end
	 
	 if player.showtime then
	  s.shadow=0
	 end
	 if s.shadow>=s.shadowtime and player.dead==false then
	  kill_player()
	 end
	end


 update_the_show()
	update_things()
	update_collapsers()
	update_flame_sources()
	update_lfx()
	update_pfx()
	update_whisper()
	
	// camera
	local cx=flr(player.x/128)*128
	local cy=flr(player.y/128)*128
	if cx!=camerax or cy!=cameray then
	 camerax=cx
	 cameray=cy
	 refresh_room()
	end
	
	update_message()
	
 if	s.timing then
	 s.time+=dt
	else
	 
	end
	
end

function draw_game(s)
 // draw base
 
 if screen_shake then
	 camera(camerax+sin(sin_time*4)*2,cameray+sin(sin_time*4.4)*2)
	else
 	camera(camerax,cameray)
	end

 if player.showtime then
  pal()
  draw_the_show()
 elseif player.can_slide then
  pal_dark()
 else
		pal_vdark()
	end
 map(camerax/8,cameray/8,camerax,cameray,16,16)
// pal()
 
 if player.showtime==false then
 // draw light (low)
 	pal_dark()
 	draw_light(player.flame.x,player.flame.y,player.flame.l*player.flame.pow)
 
 	// green checkpoint light
 	if current_room.checkpoint then
 	 pal_green()
 	 draw_light(current_room.checkpoint.x,current_room.checkpoint.y,16)
 	end
 
 	// draw lights (high)
 	pal()
 	for l in all(flame_sources) do
 	 draw_light(l.x,l.y,l.l*l.pow*0.8)
 	end
 end
 
 draw_lfx()
 draw_flame_sources()
 draw_things()
 draw_pfx()
 
 if player.showtime == false and s.shadow>0 then
	 draw_shadow(s.shadow,s.shadowtime)
	end

 // debug stuff
 camera()
 draw_message()
 draw_whisper()
 
 if player.standby then
  local tcs={4,9,10}
  local tc=tcs[flr(abs(sin(sin_time)*#tcs))+1]
  printo("solais",64-3*4,24,tc,1)
   printo("by malcolm brown",64-8*4,98,9,0)
   printo("for ld46",64-4*4,106,5,0)
   if starting==false then
	   printo("press z to begin",64-8*4,64,tc,0)
	  end
 end
 
 if stage!=nil and stage==7 then
  local t=current_screen.time
  local mins=flr(t/60)
  local secs=flr(t)%60
  
  if secs<10 then
   print("time: "..mins..":0"..secs,32,96,10)  
  else
   print("time: "..mins..":"..secs,32,96,10)  
  end

 end
end

function draw_light(ilx,ily,ilr)
 local lx=round(ilx)
 local ly=round(ily)
 local lr=ilr
 local hlr=lr/2
 local lsx=lx-lr
 local lsy=ly-lr
 local p=0
 for y=ly-lr,ly+lr do
  // scanline circle!
	 local vx=sqrt((lr*lr)-((y-ly)*(y-ly)))
  local lx1=round(lx-vx+0.5)
  local lx2=round(lx+vx+0.5)
  tline(lx1,
  						y,
  						lx2,
  						y,
  						lx1/8,y/8,1/8,0)
  						
  p+=(1/lr * 0.25)
 end
end

function pal_vdark()
 pal(1,0)
 pal(2,0)
 pal(3,0)
 pal(4,1)
 pal(5,0)
 pal(6,1)
 pal(7,1)
 pal(8,1)
 pal(9,1)
 pal(10,2)
 pal(11,0)
 pal(12,0)
 pal(13,1)
 pal(14,1)
 pal(15,2)
end

function pal_dark()
 pal(1,0)
 pal(2,1)
 pal(3,1)
 pal(4,2)
 pal(5,1)
 pal(6,5)
 pal(7,5)
 pal(8,2)
 pal(9,2)
 pal(10,4)
 pal(11,1)
 pal(12,1)
 pal(13,1)
 pal(14,2)
 pal(15,4)
end

function pal_green()

 pal(1,1)
 pal(2,1)
 pal(3,3)
 pal(4,3)
 pal(5,3)
 pal(6,11)
 pal(7,10)
 pal(8,11)
 pal(9,3)
 pal(10,10)
 pal(11,11)
 pal(12,11)
 pal(13,3)
 pal(14,3)
 pal(15,11)             
end 

function pal_outline(c)
 for i=0,15 do
  pal(i,c)
 end
end

function round(x)
 if x-flr(x)>=0.5 then return ceil(x) else return flr(x) end
end

wooble_time=0

function animate_map()
 local show_wooble=false
 wooble_time+=dt
 if wooble_time>=0.05 then
  show_wooble=true
  wooble_time-=0.05
 end
 
 for x=0,16 do
  for y=0,16 do
   local tx=flr(camerax/8)+x
   local ty=flr(cameray/8)+y
   local t=mget(tx,ty)
   
   // waterfall
   if t>=32 and t<=35 then
    mset(tx,ty,t==35 and 32 or t+1)
   elseif t>=40 and t<=45 then
   // water
    mset(tx,ty,t==45 and 40 or t+1)   
   elseif show_wooble and t>=112 and t<=113 then
    create_pfx(
     tx*8+rnd(8),ty*8,
     pfx_wooble,0.5,
     rrnd(0.1),-rnd(0.2),
     0,-0.001)
   // checkpoint
   end
   
  end
 end
end

function draw_shadow(s,st)
 pal(1,0)
 
 local p=s/st
 local r=168*(1-p)
 local lx=player.x-r
 local rx=player.x+r
 local uy=player.y-r
 local by=player.y+r
 
 //top
 rectfill(player.x-128,player.y-128,player.x+128,uy,1)

 //bot
 rectfill(player.x-128,by,player.x+128,player.y+128,1)
 // left
 rectfill(player.x-128,player.y-128,lx,player.y+128,1)
 // right
 rectfill(rx,player.y-128,player.x+128,player.y+128,1)

 // circle
 sspr(16,32,32,32,lx-1,uy-1,r*2+2,r*2+2)
 pal()
end

function printo(t,x,y,c,co)
 print(t,x-1,y,co)
 print(t,x+1,y,co)
 print(t,x,y-1,co)
 print(t,x,y+1,co)
 print(t,x,y,c)    
end

-->8
// player movement + general entity stuff

things={}
player=nil
grav=0.05
//grav=0.1

function create_player(x,y)
 player=create_thing(x,y,
  update_player,
  draw_player)
 
 // player setup
 player.s=1
 player.fx=false
 player.landed=false
 player.vy=0
 player.vx=0
 player.ax=0.25
 player.maxvxnat=1
 player.maxvx=10
 player.maxvy=10
 player.j=1.2
 player.ctime=0 // coyote time!
 player.ctimemax=0.2
 
 // animation
 player.f_i={1} // idle
 player.f_w={2,3,4,3} // walk
 player.f_j={5} // jump
 player.f_f={6} // fall
 player.f_l={7} // land
 player.f=player.f_i
 player.ft=0
 player.ff=0
 player.fps=0.15
 
 player.sx=1
 player.sy=1
 
 player.dead=false
 player.respawnx=x
 player.respawny=y
 player.respawn_time=0
 player.respawn_time_max=2
 player.respawn_anim=0
 
 player.outline=0

 // player flame
 player.flame=create_flame_source(player.x,player.y)
 player.flame.s=8
 player.flame.r=32
 player.flame.fx=false
 player.flame.outline=0
 player.flame.pow=1
 player.flame.pfall=0.002
 
 player.convayed=false
 player.showtime=false
 
 player.line_t=0
 
 player.can_slide=false
 player.wslidedx=0
  
 // frames disable controls
 player.dc=0
 
 // light
 player.lr=16
 
 return player
end

function update_player(p)

 if p.dead then
  local dfs={12,28}
  p.s=dfs[flr(sin_time*4)%2+1]
  p.sx=1
  p.sy=1
  p.vx+=grav*0.5
  p.y-=abs(p.vx)
  if p.y<cameray then
  	p.dead=false
  	p.x=p.respawnx
  	p.y=p.respawny
  	p.vx=0
  	p.vy=0
  	p.flame.tpow=1
  	p.flame.x=p.x
  	p.flame.y=p.y
  	sfx(4)
   // respawn time.
  end
  return
 end
 
 if p.disabled then
  return
 end
 
 local controls=true
 if p.dc>0 then
	 p.dc-=1
	 controls=false
	end
 
 local dx=0
 if controls then
	 if btn(0) then dx=-1
	 elseif btn(1) then dx=1
		end
 end
 
 if dx!=0 then
  p.fx=dx<0
  if abs(p.vx)<p.maxvxnat or sgn(p.vx)!=dx then
	  p.vx+=dx*p.ax
	 end
  p.f=p.f_w // walk anim
 elseif controls then
  p.f=p.f_i // idle
  // decel
  if p.vx>0 then
   p.vx=max(0,p.vx-p.ax*0.5)
  elseif p.vx<0 then
   p.vx=min(0,p.vx+p.ax*0.5)  
  end
 end
 
 p.vx=max(min(p.maxvx,p.vx),-p.maxvx)
 p.x+=p.vx
 // wall collision
 collide_walls(p)
 
 // falling
 if p.landed==false then
  local ay=grav
  if p.wslidedx != 0 and p.vy>0 then
   ay*=0.25
   spawn_dust_pfx(p.x-p.wslidedx*4,p.y)
  end
  p.vy+=ay
  p.ctime=min(p.ctime+dt,p.ctimemax)
  if p.vy<-0.5 then
   p.f=p.f_j // jump anim
  elseif p.vy>0.5 then
   p.f=p.f_f // fall anim
  else
   p.f=p.f_i // idle 
  end
 else
  p.ctime=0
  p.vy=0
 end
 
 // wall-sliding
 if not p.landed and p.vy>0.1 and p.wslidedx != 0 and btn(4) and controls then
   p.vy=-p.j
   p.vx=p.wslidedx*1.5
	  p.y-=1
	  p.x+=p.wslidedx*2
	  p.ctime=p.ctimemax
	  squish(p,0.5,1.5)
	  sfx(0)
 else
	 // normal jomping!
	 
	 if (p.landed or p.ctime<p.ctimemax) and btn(4) and controls then
	  spawn_dust_cloud(p.x,p.y+4,3)
	  p.vy=-p.j
	  p.y-=2
	  p.ctime=p.ctimemax
	  squish(p,0.5,1.5)
	  sfx(0)
	 end
 end
 
 
 
 p.vy=max(min(p.maxvy,p.vy),-p.maxvy)
 p.y+=p.vy
 
 // wrapwarp
 p.wrapwarped=false
 if p.y>=512 then
  p.y-=512
  p.x+=128
  p.flame.x=p.x
  p.flame.y=p.y
  p.wrapwarped=true
 end
 
 p.convayed=false
 collide_floors(p)
 collide_ceiling(p)
 
 collide_things(p)
 
 // special tiles
 local mapt=mget(flr(p.x/8),flr(p.y/8))
 if fget(mapt,1) then
  if p.flame.tpow>0 then
   sfx(6)
  end
  p.flame.tpow=0
  spawn_splash_pfx(p.x,p.y-4,1)
 end
 
 // kicking off the ending
 if p.showtime==false and p.landed and flr(p.x/128)==7 and flr(p.y/128)==3 then
  begin_the_show()
 end
 
 
 // animate your arse
 animate(p)
 
 // move the flame source
 p.flame.x+=((p.x+(p.fx and 3 or -2))-p.flame.x)*0.4
 p.flame.y+=(p.y-p.flame.y)*0.4
 
 // flame line trail
 p.line_t+=dt
 if p.line_t >= 0.1 then
  create_lfx(p.flame.x,p.flame.y,
   lfx_flame,
   0.7*p.flame.pow,
   rrnd(0.01),-rnd(0.01),
   rrnd(0.01),-0.01)
   p.line_t-=0.1
 end
 
 // check flame source collisions
 local ftx0=flr(p.x/8)
 local fty0=flr(p.y/8)
 for f in all(flame_sources) do
  if f != p.flame and f.active then
   local ftx1=flr(f.x/8)
   local fty1=flr(f.y/8)
   if ftx0==ftx1 and fty0==fty1 then
    // relight
    if p.flame.tpow<0.9 then
     sfx(5)
    end
    p.flame.tpow=1
    
   end
  end
 end

end

function collide_things(t)
 for o in all(things) do
  if o!=t and o.active and o.collide then
   // 
   local lx=flr((t.x-4)/8)
   local rx=flr((t.x+4)/8)
   local uy=flr((t.y-4)/8)
   local by=flr((t.y+4)/8)
   local otx=flr(o.x/8)
   local oty=flr(o.y/8)
   if (otx==lx or otx==rx) and
      (oty==uy or oty==by) then
    o.collide(o,t)
   end
  end
 end
end

function animate(t)
	if t.ft!=nil then
 	t.ft+=t.fps
	 t.ft=t.ft%(#t.f)
	 t.ff=flr(t.ft)
	 t.s=t.f[t.ff+1]
	end
 
 // animate squish
 t.sx=move_to(t.sx,1,0.05)
 t.sy=move_to(t.sy,1,0.05)
end

function move_to(s,d,v)
 if s>d then
  return max(d,s-v)
 elseif s<d then
  return min(d,s+v) 
 end
 return d
end

function squish(t,sx,sy)
 t.sx=sx
 t.sy=sy
end

function draw_player(p)
 draw_spriteso(p)
 
 // draw torch
 draw_spriteo(p.flame)
end


// collision
function collide_floors(t)
 local tx=t.x
 local ty=t.y+5
 local hit=collide_solid(tx,ty)
 if hit and (t.landed or t.vy>=0) then
  t.y=flr(ty/8)*8-5
  if t.landed==false then
   squish(t,1.5,0.5)
   spawn_dust_cloud(t.x,t.y+4,3)
   sfx(1)
  end
  local mtx=flr(tx/8)
  local mty=flr(ty/8)
  // spikes
  if mget(mtx,mty)==55 then
   kill_player()
  // collapsers
  elseif fget(mget(mtx,mty),4) then
   start_collapse(mtx,mty)
  // checkpoint
  elseif mget(mtx,mty)==112 or mget(mtx,mty)==113 then
   local rx=flr(mtx/16)
   local ry=flr(mty/16)
   if t.lastrespawnx!=rx or t.lastrespawny!=ry then
    show_message("checkpoint")
    t.lastrespawnx=rx
    t.lastrespawny=ry
    sfx(2)
   end
   
   t.respawnx=t.x
   t.respawny=t.y
   t.flame.tpow=1
   show_checkpoint=true
  elseif mget(mtx,mty)>=36 and mget(mtx,mty)<=39 then
   // get convayer thing
   for ot in all(things) do
    if ot.convayer and ot.tx==mtx and ot.ty==mty then
     t.x+=(ot.f and -0.5 or 0.5)
     t.convayed=true
    end
   end
  end
  // 
  t.landed=true
  
 else 
  t.landed=false
 end
end

function collide_walls(t)
 local txl=t.x-4
 local txr=t.x+4
 local ty=t.y
 
 t.wslidedx=0
 
 if collide_solid(txl,ty,3) then
  t.x=flr(txl/8)*8+12
  local ml=mget(txl/8,ty/8)
  if ml==57 and (t.vx<0 or t.convayed) then
   kill_player()
  end
  t.vx=0
  if t.can_slide then
   t.wslidedx=1
  end
 elseif collide_solid(txr,ty,3) then
   
  t.x=flr(txr/8)*8-4
  local mr=mget(txr/8,ty/8)
  if mr==56 and (t.vx>0 or t.convayed) then
   kill_player()
  end
  t.vx=0
  if t.can_slide then
   t.wslidedx=-1
  end
 end
end

function collide_ceiling(t)
 local tx=t.x
 local ty=t.y-4
 local hit=collide_solid(tx,ty,3)
 if hit then
  t.vy=0
  t.y=flr(ty/8)*8+12
 end
end

function collide_solid(x,y,im)

 local tile=mget(flr(x/8),flr(y/8))
 local f=fget(tile,0)
 if im!=nil and fget(tile,im)==true then
  return false
 else
	 return f
	end
end



// sprite drawing
function draw_sprite(s)
 spr(s.s,s.x-4,s.y-4,1,1,s.fx,s.fy)
end

function draw_spriteo(s)

 // outline
 pal_outline(s.outline)
 for dx=-1,1 do
  for dy=-1,1 do
   if abs(dx+dy)==1 then
	   spr(s.s,s.x-4+dx,s.y-4+dy,1,1,s.fx,s.fy)
	  end
  end
 end
 
 pal()
 spr(s.s,s.x-4,s.y-4,1,1,s.fx,s.fy)
end

function draw_spriteso(s)
// outline

 local sx=(s.s*8)%128
 local sy=flr(s.s/16)*8
 local sw=8
 local sh=8
 local w=8*s.sx
 local h=8*s.sy
 local hw=w/2
 local hh=h/2
 local oy=-hh+sh/2

 pal_outline(s.outline)
 for dx=-1,1 do
  for dy=-1,1 do
   if abs(dx+dy)==1 then
				sspr	(sx,sy,sw,sh,s.x-hw+dx,s.y-hh+dy+oy,w,h,s.fx,s.fy)   
	  end
  end
 end
 
 pal()
	sspr	(sx,sy,sw,sh,s.x-hw,s.y-hh+oy,w,h,s.fx,s.fy)   
end



// thing stuff

function create_thing(x,y,u,d,ta)
 local t={}
 t.u=u
 t.d=d
 t.x=x
 t.y=y
 t.fx=false
 t.fy=false
 t.sx=1
 t.sy=1
 t.active=true
 if ta==nil then
	 add(things,t)
	else
	 add(ta,t)
 end
 return t
end

function update_things()
 for t in all(things) do
  if t.active and t.u then
	  t.u(t)
	 end
 end
end

function draw_things()
 for t in all(things) do
  if t.active and t.d then
	  t.d(t)
	 end
 end
end

// ---- deaaaaath ----
function kill_player()
 player.dead=true
 player.vx=-1
 spawn_sparkles(player.x,player.y)
 sfx(3)
end

function respawn_player()

end
-->8
// particles

pfx={}
pfx_next=0

// line fx
lfx={}
lfx_next=0

lfx_flame={7,10,9,4,2}

pfx_flames={17,18,19,20,21}
pfx_dust={22,23,24,25}
pfx_sparkles={80,81,96,97}
pfx_splash={70,71,72,73}
pfx_wooble={120,121,122}

// flame sources
flame_sources={}

function init_particles(c)
 for i=0,c do
  local p={}
  p.x=0
  p.y=0
  p.vx=0
  p.vy=0
  p.ax=0
  p.ay=0
  p.l=0
  p.t=0
  p.active=false
  
  // anim
  p.f=nil
  add(pfx,p)
 end
 
end

function create_pfx(x,y,f,l,vx,vy,ax,ay)
 local p = pfx[pfx_next+1]
 p.active=true
 p.t=0
 p.l=l
 p.x=x
 p.y=y
 p.vx=vx
 p.vy=vy
 p.ax=ax
 p.ay=ay
 p.f=f
 p.fx=rnd(1)>0.5
 p.fy=rnd(1)>0.5
 
 pfx_next=(pfx_next+1)%(#pfx)
end

function create_flame(x,y)
  create_pfx(x,y,
   pfx_flames,
   1,
   rrnd(0.125),-rnd(0.15),
   0.0, -0.005)
end

function rrnd(x)
 return rnd(x)-rnd(x)
end

function update_pfx()
 for p in all(pfx) do
  if p.active then
   p.t+=0.01667
   
   if p.t>p.l then
    p.active=false
   else
    p.vx+=p.ax
    p.vy+=p.ay
    p.x+=p.vx
    p.y+=p.vy
    
    local pt=min(1,p.t/p.l)
    local ft=flr(pt*(#p.f))
    p.ff=p.f[ft+1]
   end
  end
 end
end

function draw_pfx()
 for p in all(pfx) do
  if p.active then
   spr(p.ff,p.x-4,p.y-4,1,1,p.fx,p.fy)
  end
 end
end

// particle_source
function create_flame_source(x,y,t)
 local s={}
 s.x=x
 s.y=y
 s.t=0
 s.r=24
 s.l=s.r
 s.tl=s.r
 s.tt=0
 s.active=true
 s.pow=1
 s.tpow=1
 s.pfall=0
 s.s=16
 s.outline=0
 if t==nil then
	 add(flame_sources,s)
	else
	 add(t,s)
	end
 return s
end

function update_flame_sources()
 local hz=0.1
 for s in all(flame_sources) do
  // particles
  s.t+=0.01667*s.pow
  
  s.tpow-=s.pfall
  s.tpow=max(0,s.tpow)
  s.pow+=(s.tpow-s.pow)*0.1
   
  if s.t>hz then
   s.t-=hz
   create_flame(s.x,s.y)
  end
  
  //if s.pfall != 0 then
   
  //end

  
  // light
  s.tt+=dt
  if s.tt>0.1 then
   s.tt-=0.1
   s.tl=s.r+rrnd(1.5)*s.pow
  end
  s.l+=(s.tl-s.l)*0.1
 end 
end

function draw_flame_sources()
 for f in all(flame_sources) do
  if f.active and f!=player.flame then
   draw_spriteo(f)
  end
 end
end

// light fx
function init_lfx(c)
 for i=0,c do
  local l={}
  l.x0=0
  l.x1=0
  l.y0=0
  l.y1=0
  l.l=0
  l.t=0
  l.ct=nil
  l.c=0
  l.active=false
  l.th=1
  add(lfx,l)
 end
end

function create_lfx(x0,y0,c,li,vx,vy,ax,ay)
 local l = lfx[lfx_next+1]
 l.active=true
 l.t=0
 l.l=li
 l.x=x0
 l.y=y0
 l.vx=vx
 l.vy=vy
 l.ax=ax
 l.ay=ay
 l.ct=c
 l.c=l.ct[1]
 
 lfx_next=(lfx_next+1)%(#lfx)
end

function update_lfx()
 for l in all(lfx) do
  if l.active then
   l.t+=dt
   if l.t>=l.l then
    l.active=false
   else
    local pt=min(1,l.t/l.l)
    local ft=flr(pt*(#l.ct))
    l.c=l.ct[ft+1]
    
    // add noise to points?
    l.vx+=l.ax
    l.vy+=l.ay
    l.x+=l.vx
    l.y+=l.vy
    
    if player.wrapwarped then
     l.x+=128
     l.y-=512
    end
   end
  end
 end
end

function draw_lfx()
 local count=#lfx
 for i=0,count do
  local l=lfx[i+1]
  if l and l.active then
   // start
   for j=0,128 do
    local p0=lfx[((i+j+0)%#lfx)+1]
    local p1=lfx[((i+j+1)%#lfx)+1]
    if p1.active then
     line(p0.x,p0.y,p1.x,p1.y,p0.c)
     line(p0.x,p0.y-1,p1.x,p1.y-1,p0.c)
    else
     return
    end
   end

  end
 end
end

// function dust
function spawn_dust_cloud(x,y,n)
 for i=0,n do
  spawn_dust_pfx(x+rrnd(8),y)
 end
end

function spawn_dust_pfx(x,y)
 create_pfx(x+rrnd(2),y+rrnd(2),
   pfx_dust,
   1+rrnd(0.25),
   rrnd(0.125),0,
   0.0, -0.005)
end

// splash
function spawn_splish_pfx(x,y)
 create_pfx(x+rrnd(2),y+rrnd(2),
   pfx_splash,
   0.25+rnd(0.5),
   rrnd(0.2),rrnd(0.2),
   0.0,0.005)
end

function spawn_splash_pfx(x,y,n)
 for i=0,n do
  spawn_splish_pfx(x+rrnd(4),y+rrnd(4))
 end
end

// sparkles
function spawn_sparkle(x,y)
 create_pfx(x,y,
   pfx_sparkles,
   1,
   0,0,
   0.0,0.005)
end

function spawn_sparkles(x,y)
 for i=0,2,0.1 do
  local vx=sin(i)
  local vy=cos(i)
  create_pfx(x,y,
   pfx_sparkles,
   1,
   vx,vy,
   0.0,0.005)
 end
 
end
-->8
// springs


function create_spring(x,y,t)
 local dx=0
 local dy=-1
 if t==60 then
  dx=-1
  dy=0
 elseif t==61 then
  dy=1
 elseif t==62 then
  dx=1
  dy=0
 end
 
 local s=create_thing(x,y,update_spring,draw_spring,current_room.things)
 s.dx=dx
 s.dy=dy
 s.s=t
 s.collide=collide_spring
 mset(x/8,y/8,50)
end

function update_spring(s)
 animate(s)
end

function collide_spring(t,ot)
 // jump player
 spawn_dust_cloud(ot.x,ot.y+4,3)
 local dx=t.dx
 local dy=t.dy
 local sp=2
 ot.vy=dy*sp
 ot.vx=dx*sp
 ot.x+=dx*2
 ot.y+=dy*2
 ot.ctime=ot.ctimemax
 ot.dc=3
 squish(ot,0.5,1.5)
 sfx(8)
 // srpgin squish
 squish(t,dy!=0 and 1.5 or 0.5,dy!=0 and 0.5 or 1.5)
end

function draw_spring(s)
 draw_spriteso(s)
end

// collapses
collapsers={}



function start_collapse(tx,ty)
 for c in all(collapsers) do
  if c.tx==tx and c.ty==ty then
   return
  end
 end
 
 local c={}
 c.tx=tx
 c.ty=ty
 c.l=1
 c.active=true
 c.dustt=0
 c.respawn=false
 c.respawnt=0
 add(collapsers,c)
 sfx(9)
 
end

function update_collapsers()
 local rx=flr(player.x/128)
 local ry=flr(player.y/128)
 for c in all(collapsers) do
  if c.active then
   local crx=flr(c.tx/16)
   local cry=flr(c.ty/16)
   local same_room=rx==crx and ry==cry
   if c.respawn==false then
   	c.l-=dt
   
   	c.dustt+=dt
   	if c.dustt>0.1 then
   	 spawn_dust_pfx(c.tx*8+4,c.ty*8+4)
   	 c.dustt-=0.1
   	end
   
   	if c.l<=0 then
   	 // destroy tile
   	 mset(c.tx,c.ty,49)
   	 spawn_dust_cloud(c.tx*8+4,c.ty*8+4,6)
   	 c.respawn=true
   	  if same_room then
	   	  sfx(10)
	   	 end
   	 //del(collapsers,c)
   	end
   else
    c.respawnt+=dt
    if c.respawnt>5 then
     mset(c.tx,c.ty,54)
   	 spawn_dust_cloud(c.tx*8+4,c.ty*8+4,6)
     del(collapsers,c)
     if same_room then
      sfx(9)
     end
    end
   end
  end
 end
end

// convayers (invisible?)
function create_convayer(tx,ty,f)
 local s=create_thing(tx*8,ty*8,update_convayer,draw_convayer,current_room.things)
 s.f=f
 s.tx=tx
 s.ty=ty
 s.convayer=true
 local forw={36,37,38,39}
 local back={39,38,37,36}
 s.ff=s.f and back or forw
 s.ft=0
 s.sx=1
 s.sy=1

end

function update_convayer(c)
 c.ft+=dt*10
 local f=flr(c.ft)%#c.ff
 c.s=c.ff[f+1]
 mset(c.tx,c.ty,c.s)
end

function draw_convayer(c)
 //draw_sprite(c)
end

function create_powerup(x,y)
 local s=create_thing(x,y,update_powerup,draw_powerup,current_room.things)
 s.collide=collide_powerup
 s.s=26
 s.sx=1
 s.sy=1
 s.oy=y
 s.ox=x
end

function update_powerup(p)
 p.si=sin_time
 p.x=p.ox+sin(p.si*0.2)*4
 p.y=p.oy+sin(p.si*0.4+1.24)*4
end

function collide_powerup(p,po)
 // sparkles
 spawn_sparkles(p.x,p.y)
 po.can_slide=true
 p.active=false
 show_message("learned wall jump")
 sfx(7)
end

function draw_powerup(p)
 draw_spriteso(p)
end

// eyeballs!
function create_eyeball(x,y,a)
 local t=create_thing(x+4,y+4,update_eyeball,draw_eyeball,current_room.things)
 if a==nil then a=false end
 t.a=0
 t.wake=0
 t.outline=0
 t.sx=1
 t.sy=0
 t.s=86
 t.always=a
 if t.always == false then
 	mset(flr(x/8),flr(y/8),74)
 end
 return t
end

function update_eyeball(e)
 // check distance
 local p=player
 if e.always or (p.x>e.x-32 and
    p.x<e.x+32 and
    p.y>e.y-32 and
    p.y<e.y+32) then
   e.wake+=dt*5 
 else
   e.wake-=dt*5
 end
 
 e.wake=max(0,min(1,e.wake))
 e.sy=e.wake
 
 if e.wake>0 then
  e.a=atan2(p.y-e.y,p.x-e.x)
 end
end

function draw_eyeball(e)
 if e.wake>0 then
  draw_spriteso(e)
  
  local vx=sin(e.a)*3
  local vy=cos(e.a)*3-4
  spr(87,e.x+vx*e.wake-4,e.y+vy*e.wake)
 end
end
-->8
// whispers and checkpoints

whispers={
 "...who approaches...",
 "...my love...so near...",
 "...have they all forgotten...?",
 "...come to us...",
 "...you must save us...",
 "...do not look back, my love...",
 "...not long now...",
 "...we shall aid you...",
 "...we must sing...",
 "...my love...are you the last...?",
 "...then it is time...",
 "...thank you...",
 "..."
}

whisp_loc_i=1
// whisper locations
whisp_loc={
 1,
 2,
 5,//empty checkpoint
 7,//convayors
 9,//springs
 11,//top of pit
 13,// bottom of pit
 14,//  powerup room
 16,// descent start
 19,//final pit 
 22, // final room
 25,
 25,
}


// whispers

whisper_index=1
current_whisper=nil
current_whispert=0
room_whisper=0


function whisper()

 current_whisper=nil
 sfx(11)

 current_whispert=5
 current_whisper={}
 current_whisper.t=whispers[whisper_index]
 current_whisper.c={}
 
 local width=#current_whisper.t*5
 local x=64-width/2
 // create letters
 for i =0,#current_whisper.t do
  local c=sub(current_whisper.t,i,i)
  local ci={}
  ci.bx=x
  ci.by=32
  ci.x=ci.bx
  ci.y=ci.by  
  ci.c=c
  ci.vx=rrnd(1)
  ci.vy=rrnd(1)
  ci.t=1
  ci.o=rnd(1)
  add(current_whisper.c,ci)
  x+=5
 end
 
 whisper_index+=1
end

function update_whisper()
 if current_whisper!=nil then
  // animate time
  if current_whispert>0 then
   current_whispert-=dt*2
   
   local t=0
   if current_whispert>4 then
    local lt=(current_whispert-4)
    t=sin(lt*0.25)
   elseif current_whispert<1 then
    local lt=1-current_whispert
    t=sin(lt*0.25)
   end
   
   // update letters
   for c in all(current_whisper.c) do
    c.t=min(1,max(0,abs(t)))
    c.x=c.bx+c.vx*t*64+sin(sin_time*0.91+c.o)*0.5
    c.y=c.by+c.vy*t*64+sin(sin_time*1.07+c.o)*0.5
   end
  else
   current_whisper=nil
  end
  
 end
end

function draw_whisper()
 if current_whisper!=nil then
  local cols={7,6,5,1}
  for c in all(current_whisper.c) do
   local co=cols[flr((c.t)*#cols)+1]
   
   print(c.c,c.x,c.y,co)
  end
  
  //print(current_whisper.t,8,8,7)
 end
end
// text messages
c_mess=""
c_messtime=0

function show_message(t)
 c_mess=t
 c_messtime=5
 
end

function update_message()
 if c_messtime>0 then
  c_messtime-=dt*3
 end
end

function draw_message()
 local x=64-(#c_mess*4)*0.5
 local y=0
 if c_messtime>0 then
  // sliding in
  if c_messtime>=4 then
   y=128-cos((c_messtime-4)*0.25)*32
  elseif c_messtime<=1 then
   y=128-cos((1-c_messtime)*0.25)*32
  else
   y=96
  end
  local c=10
  if (flr(sin_time*10))%2==0 then
   c=7
  end
  for dx=-1,1 do
   for dy=-1,1 do
    print(c_mess,x+dx,y+dy,0)
   end
  end
  
  
  print(c_mess,x,y,c)
 end
 

end
-->8
// final cutscene

//stages={
// 0,//cut_to_position,
// 1,//cut_eyeballs,
// 2,//cut_big_eyeball,
// 3,//cut_teeth_fade_in,
// 4,//cut_teeth_chomp,
// 5,//cut_thanks

stage=nil
function begin_the_show()
 player.showtime=true
 stage=0
end

stage_time=0
eyeball_time=0

function update_the_show()
 if player.showtime then
  player.dc=5
  stage_time+=dt
  
  // part one, get into position
  if stage==0 then
   local tx=120*8
   if player.x<tx-2 then
    player.vx=1
   elseif player.x>tx+2 then
    player.vx=-1   
   else
    player.vx=0
    stage=1
    stage_time=0
    player.disabled=true
   end
   animate(player)
  
  //player rise + eyeballs
  elseif stage==1 then
   player.sx=1
   player.sy=1
   local p=stage_time/5
   player.y=60.5*8+sin(p*0.25)*32
   player.s=stage_time<2.5 and 5 or 13
   if stage_time<0.5 then
   	local ft=stage_time*2
   	player.flame.y=60.5*8-sin(ft*0.25)*4
   end
   if stage_time>=5 then
    stage_time=0
    stage=2
   end
   
   eyeball_time+=dt
   if eyeball_time>0.5 then
    eyeball_time=0
    local left=rnd(1)>=0.5
    local ex=player.x+(left and -48 or 48)
    local ey=54*8
    local e=create_eyeball(ex+rrnd(4),ey+rrnd(58),true)
   end
   
  elseif stage==2 then
   // eye open
   screen_shake=true
   if stage_time>=2 then
    stage_time=0
    stage=3
   end
   
   
   // just chillin'
  elseif stage==3 then
   screen_shake=false
   if stage_time>2 then
    stage=4
    stage_time=0
   end
  
  // teeth appear
  elseif stage==4 then
   if stage_time>5 then
    stage=5
    stage_time=0
   end
  // chomp
  elseif stage==5 then
   if stage_time>=0.4 then
    player.sx=0
    player.sy=0
   end
   if stage_time>=0.5 then
    stage=6
    stage_time=0
   end
  elseif stage==6 then
  
    player.x=108*8
    if stage_time>2 then
     whisper()
     current_screen.timing=false
     stage=7
     stage_time=0
    end
   // end
  elseif stage==7 then
   if stage_time>5 then
    run() // restart
   end
  end
 end
end

function draw_the_show()
 if stage>=2 then
  local sx=(stage==2 and stage_time/2 or 1)
  local ssx=(102*8)%128
  local ssy=flr(102/16)*8
  sspr(ssx,ssy,
     16,16,
     120*8-8*sx,50*8,
     16*sx,16)
     
  local esx=(104*8)%128
  sspr(esx,ssy,
       8,8,
       120*8-4*sx,51*8,
       8*sx,8)
 end
 
 if stage >=4 then
  
  if stage==4 then
   local pt=min(1,max(0,stage_time/3))
   if pt<0.5 then
    pal_vdark()
   elseif pt<1 then
    pal_dark()
   else
    pal()
   end
  else
   pal()
  end
  
  local tx=120*8
  local uty=56*8
  local lty=56*8
  if stage==4 then
   local off=min(1,max(0,stage_time/3))
   uty+=sin(off*0.25)*16
   lty-=sin(off*0.25)*16
  elseif stage==5 then
   local off=1-min(1,max(0,stage_time/0.5))
   uty+=sin(off*0.25)*16
   lty-=sin(off*0.25)*16
  end
  // upper teef
  spr(89,tx-16,uty,2,2,false,false)
  spr(89,tx,uty,2,2,true,false)
  // lower teef
  spr(89,tx-16,lty,2,2,false,true)
  spr(89,tx,lty,2,2,true,true)
  pal()
 end
 
 //if stage==7 then

 //end
end
-->8
// title screen

