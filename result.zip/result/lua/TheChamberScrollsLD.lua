--  the chamber scrolls
--  copyright (c) 2016 sam hocevar <sam@hocevar.net>
image_width, image_height =600,252
facts = {}
big_data = {}
rom = {
[0]=
0x9aed.9c78, 0x451d.684f, 0x6f7f.c71c, 0xfba6.f2fb, 0x1e96.de6c, 0xbc35.43d2,
0xc45e.342e, 0xbe96.a9bb, 0xa351.82b6, 0xd0b6.29bd, 0x4a45.50f4, 0x4324.14cd,
0x8b62.c853, 0x5a9a.1ea7, 0x5d07.7850, 0x40f8.7d41, 0xc721.4143, 0x56bd.0b44,
0x636f.68a9, 0x24b9.fed1, 0x7b06.8c4b, 0x666f.e7d8, 0x7979.9b77, 0x16ee.ecfb,
0xcbef.ea54, 0xccec.ec9b, 0xdf9b.f3ef, 0x7676.66fc, 0x7878.010f, 0xa6ed.5bc4,
0xfcee.4cdd, 0x1b6f.ace6, 0xa214.cdbd, 0x81cc.015b, 0x44ee.4ad3, 0x46ab.cda7,
0xd885.2b6f, 0x8bfd.39a8, 0x07e0.6182, 0x0c07.c00f, 0xefbb.b54b, 0x87f0.f2be,
0x31db.6cf3, 0x6fc1.b2df, 0xc6db.41db, 0xefc3.b896, 0x4be9.c3ce, 0xdfe7.c743,
0x745a.ec79, 0xe63f.8337, 0xe636.6c04, 0x4d8d.8045, 0xabc5.60bc, 0x63c3.aada,
0xa9e1.5266, 0x7657.27f7, 0xb5fa.fa1d, 0x2e54.2ee8, 0x0da2.06ee, 0x9598.1d20,
0xd17c.77cc, 0x7d56.4c92, 0x607c.c3c7, 0x9398.0cc7, 0xdaf0.6082, 0x9e37.87d8,
0x87c7.b858, 0x5551.0b70, 0x874a.eef7, 0x4d60.e6d7, 0xaa12.aa3a, 0xf531.368a,
0x2e87.a7fc, 0xecfe.9f6d, 0x865f.832d, 0xca1a.0ea5, 0xa09d.2925, 0x5659.d4b6,
0x54d4.aabc, 0xa7fe.06c7, 0xbf93.2333, 0xc466.fe1f, 0x7519.aa68, 0x4fe8.9719,
0xdf0e.4e8a, 0xd7ea.38b9, 0xbd23.74ee, 0xa6a7.4cbe, 0xf272.be9e, 0xcc2f.cbd1,
0x7dd3.ed9f, 0xbb3e.dd5f, 0xef89.e6e7, 0xdb31.1d77, 0x6063.e14e, 0xe836.03f7,
0x67f3.23e0, 0xe2fe.9f1e, 0x73e9.a33b, 0x9bae.7201, 0xa73b.6a17, 0xf8ea.fcea,
0x7602.470f, 0x5346.34da, 0x2d23.cdd9, 0x476f.f9d2, 0xd5f1.de3f, 0x5b9f.978b,
0x65b4.096f, 0x1bf9.26d7, 0xf8c9.fabe, 0x7bde.a78f, 0x16f5.e7f2, 0x715a.f5e9,
0xd14a.a3a1, 0x3cdd.2f2f, 0xabeb.fc3a, 0x99a6.8ce7, 0x09be.cb14, 0x8ec2.f378,
0x2f0f.77f9, 0xd7a1.9d98, 0xdf97.da6b, 0x97ed.e572, 0x5726.4657, 0x53d0.b6cd,
0x9bb4.300f, 0xf570.3020, 0x48bc.4704, 0xcf6f.c399, 0xbc1d.9f5c, 0x86f7.717e,
0x6699.10e1, 0x911c.da5f, 0xe6a6.c840, 0x6352.1255, 0x4350.9148, 0x1e18.4282,
0x3c44.1f04, 0xe795.9e03, 0x6a8c.bd4d, 0x968d.98d2, 0x67df.c51d, 0xd02b.750f,
0x7c26.4b7c, 0xca35.6088, 0x7a07.265f, 0x9e25.a1eb, 0xe105.5565, 0xe28a.d1a1,
0x97f3.4c87, 0x5af8.1b1d, 0x3047.420d, 0x63c4.7fcd, 0x0323.a55e, 0x508e.c32f,
0xe1e8.7b8f, 0x076b.a98a, 0x6ac3.1ff7, 0xdbfd.fada, 0x9bae.bbaa, 0x0388.ab14,
0x8452.92e4, 0x5270.38e7, 0xd90c.f10a, 0x45e2.14b8, 0x4b88.9ddd, 0x3042.7e11,
0x78c5.2937, 0x053a.bf51, 0xf8c5.2aae, 0x5130.2a37, 0xc229.5577, 0xe062.9d5f,
0xc989.db6e, 0x8ebf.c82b, 0xa0bb.d789, 0x5f10.b3b4, 0x435b.aa99, 0xfdf5.7147,
0x3ebe.217a, 0x9db0.e751, 0xf331.e515, 0x8500.be15, 0x20dc.4c79, 0x8ac8.381f,
0x7a3d.5fce, 0x0ac7.2bd6, 0x7a55.dfcf, 0x2aa7.fc80, 0xa002.6bf3, 0x4426.bdf7,
0xaf8e.739e, 0x95d3.eb1b, 0x3d96.5bab, 0x259e.1c00, 0x5c28.548e, 0x9efc.c8bb,
0xaf11.f652, 0x9a33.c486, 0xe766.7573, 0x009c.59e0, 0x4be9.df16, 0x1098.1e76,
0x6304.cf31, 0xe5f4.abc8, 0x801c.45e0, 0x64c4.3d9e, 0xc6b1.3e0e, 0x73cc.4598,
0xb9d7.8f91, 0x1fce.3cd3, 0x6bff.d7f3, 0x2c00.5fb1, 0x371c.7d5a, 0x1f27.391e,
0x395e.192f, 0xf1f2.00e8, 0x1d0a.0f7a, 0xe7a1.d707, 0xd0d4.0079, 0x1108.cf7a,
0xffb5.c8b9, 0xbe1b.1923, 0x7fc2.47d8, 0x4482.c3ef, 0x2448.9122, 0x2244.8912,
0x1224.4891, 0x9122.4489, 0x8912.2448, 0x4891.2244, 0x1fe9.1224, 0xfedf.6952,
0x71ff.8d03, 0x6dad.56d9, 0xaed9.b2de, 0x4aac.540c, 0x0ca0.cca9, 0xb160.9416,
0x409c.ca54, 0x59fb.3180, 0x8fa3.61bb, 0xd512.a972, 0xd031.ac1b, 0x3c6b.d4d8,
0xe96f.fe96, 0x2b43.4b7b, 0xaad6.1fd6, 0xa579.67f5, 0x2a5e.5cbc, 0x845a.cd63,
0x990b.5cc5, 0xb68f.b8c7, 0x41f2.0f92, 0xf907.c83e, 0x83e4.1f20, 0xf20f.907c,
0x07c8.3e41, 0xe41f.20f9, 0xf1f4.61e3, 0xa085.9517, 0x.0035,
}
obj = {
  { "painting", 1, false, { }, { }, { }, { { 26, 95, 53, 139 }, { 53, 101, 75, 139} },
    "you look at the painting.\na beautiful painting with\na lot of emotions in it.\nyou can almost smell the\npixels." },
  { "painting", 1, false, { }, { }, { }, { { 209, 112, 228, 129 } },
    "you look at the painting.\nan impressive painting. it\nmust be very expensive.\nit must also be very\npretentious." },
  { "painting", 1, false, { }, { }, { }, { { 422, 115, 455, 137 } },
    "you look at the painting.\nit's ugly. you cannot\nunderstand why people\nbuy these things." },
  { "painting", 1, false, { }, { }, { }, { { 258, 88, 306, 126 } },
    "you look at the painting.\nthere are a lot of such\npaintings in the room." },
  { "painting", 1, false, { }, { }, { }, { { 520, 104, 544, 128 } },
    "why do people buy\npaintings? clearly\nvideo games are a\nlot better. ever seen\na 60 fps painting?" },
  { "flowers",  1, true,  { }, { 3 }, { 3 }, { { 99, 146, 118, 166 } },
    "there was a crowbar hidden\nin the flower pot!\nseriously, what are the\nodds?" },
  { "flowers",  1, false, { 3 }, { }, { }, { { 99, 146, 118, 166 } },
    "these flowers do not\nlook healthy. hard to\ntell in this resolution," },
  { "painting", 1, true,  { }, { 1 }, { 1 }, { { 107, 128, 114, 133 } },
    "you look at the painting.\n\nthere was a safe hidden\nbehind it!\n\nclassic point-n-click\nmechanism, but damn\neffective!" },
  { "safe",     1, false, { 1 }, { 7 }, { }, { { 107, 128, 114, 133 } },
    "the safe is closed.\nyou need the combination." },
  { "open",     2, true, { 7 }, { 2 }, { 2 }, { { 107, 128, 114, 133 } },
    "congratulations! you\nopened the safe and the\ngrand secret will be\nrevealed to you.\n\nthere are no scrolls, the\nscrolls are a lie. the\ngame is called the\nchamber scrolls because\nthe chamber... scrolls." },
  { "painting", 1, true,  { 2 }, { }, { }, { { 107, 128, 114, 133 } },
    "another boring painting." },
  { "pillow",  1, true, { }, { 5 }, { 5 }, { { 51,159,70,176 } }, "you found the key behind\nthe pillow. you're pretty\nsmart it seems!" },
  { "pillow",  1, false, { 5 }, { }, { }, { { 51,159,70,176 } }, "this pillow seems comfy." },
  { "drawer",  1, false, { }, { }, { }, { { 245,146,314,158 } }, "a drawer. it is locked." },
  { "drawer",  1, false, { }, { }, { }, { { 245,158,314,172 } }, "a drawer. it is locked." },
  { "drawer",  1, false, { }, { 3 }, { }, { { 245,172,314,184 } }, "a drawer. it is locked." },
  { "drawer",  1, false, { }, { }, { }, { { 245,184,314,196 } }, "a drawer. it is locked." },
  { "crack open", 2, true,  { 3 }, { 4 }, { 4 }, { { 245,172,314,184 } },
    "you crack the drawer open\nand find a plastic chicken\nwith a pulley. what a\nweird object." },
  { "drawer",  1, false, { 4 }, { }, { }, { { 245,172,314,184 } },
    "a drawer. it was cracked\nopen by a vandal." },
  { "lamp", 1, false, { }, { 6 }, { }, { { 441, 100, 452, 106 }, { 130, 90, 144, 98 } },
    "why are the lights on during\ndaylight? clearly i should\nhave downloaded another\nstock photo on google\nimages." },
  { "use plates", 2, true,  { 6 }, { 7 }, { 7 }, { { 441, 100, 452, 106 }, { 130, 90, 144, 98 } },
    "the photographic plates\nwere hiding the secret\nsafe combination! kudos to\nscience once again!" },
  { "lamp", 1, false, { 7 }, { }, { }, { { 441, 100, 452, 106 }, { 130, 90, 144, 98 } },
    "why are the lights on during\ndaylight? clearly i should\nhave downloaded another\nstock photo on google\nimages." },
  { "look", 1, false, { }, { }, { }, { { 130,118,162,152 }, { 389,114, 402,154 } }, "the weather is beautiful.\nvideo games are too." },
  { "chest", 1, false, { }, { 5 }, { }, { { 503,177, 514,189 } }, "this chest's lock requires\na key of some sort." },
  { "open",  2, true,  { 5 }, { 6 }, { 6 }, { { 503,177, 514,189 } }, "you find old photographic\nplates in the chest.\nwhat could they be good for?" },
  { "chest", 1, false, { 6 }, { }, { }, { { 503,177, 514,189 } }, "the chest is open but there\nis no longer anything\ninteresting in there." },
  { "go outside", 2, false, { }, { }, { }, { { 493,123, 501,156 } }, "why go outside? this isn't\nan escape game." },
}
function u32_to_memory(address,size,data)
  for i=0,size/4-1 do
    poke4(address+i*4,data[i])
  end
end
local reverse = {}
local function bs_init(addr)
  local bs = {
    pos = addr,
    b = 0,
    n = 0,
    out = {},
    outpos = 0,
  }
  function bs:flushb(n)
    self.n -= n
    self.b = shr(self.b,n)
  end
  function bs:getb(n)
    while self.n < n do
      self.b += shr(peek(self.pos),16-self.n)
      self.pos += 1
      self.n += 8
    end
    local ret = shl(band(self.b,shl(0x.0001,n)-0x.0001),16)
    self.n -= n
    self.b = shr(self.b,n)
    return ret
  end
  function bs:getv(hufftable,n)
    while self.n < n do
      self.b += shr(peek(self.pos),16-self.n)
      self.pos += 1
      self.n += 8
    end
    local h = reverse[shl(band(self.b,0x.00ff),16)]
    local l = reverse[shl(band(self.b,0x.ff),8)]
    local v = band(shr(shl(h,8)+l,16-n),2^n-1)
    local e = hufftable[v]
    local len = band(e,15)
    local ret = flr(shr(e,4))
    self.n -= len
    self.b = shr(self.b,len)
    return ret
  end
  function bs:write(n)
    local d = band(self.outpos, 0.75)
    local off = flr(self.outpos)
    if d==0 then
      n=shr(n,16)
    else
      if d==0.25 then
        n=shr(n,8)
      elseif d==0.75 then
        n=shl(n,8)
      end
      n+=self.out[off]
    end
    self.out[off] = n
    self.outpos += 0.25
  end
  function bs:readback(off)
    local d = band(self.outpos + off * 0.25, 0.75)
    local n = self.out[flr(self.outpos + off * 0.25)]
    if d==0 then
      n=shl(n,16)
    elseif d==0.25 then
      n=shl(n,8)
    elseif d==0.75 then
      n=shr(n,8)
    end
    return band(n,0xff)
  end
  return bs
end
local bl_count = {}
local next_code = {}
local function hufftable_create(table,depths,nvalues)
  local nbits = 1
  for i=0,16 do
    bl_count[i] = 0
  end
  for i=1,nvalues do
    local d = depths[i]
    if d > nbits then
      nbits = d
    end
    bl_count[d] += 1
  end
  local code = 0
  bl_count[0] = 0
  for i=1,nbits do
    code = (code + bl_count[i-1]) * 2
    next_code[i] = code
  end
  for i=1,nvalues do
    local len = depths[i] or 0
    if len > 0 then
      local e = (i-1)*16 + len
      local code = next_code[len]
      next_code[len] = next_code[len] + 1
      local code0 = code * 2^(nbits-len)
      local code1 = (code+1) * 2^(nbits-len)
      for j=code0,code1-1 do
        table[j] = e
      end
    end
  end
  return nbits
end
local littable = {}
local disttable = {}
local function inflate_block_loop(bs,nlit,ndist)
  local lit
  repeat
    lit = bs:getv(littable,nlit)
    if lit < 256 then
      bs:write(lit)
    elseif lit > 256 then
      local nbits = 0
      local size = 3
      local dist = 1
      if lit < 265 then
        size += lit - 257
      elseif lit < 285 then
        nbits = flr(shr(lit-261,2))
        size += shl(band(lit-261,3)+4,nbits)
      else
        size = 258
      end
      if nbits > 0 then
        size += bs:getb(nbits)
      end
      local v = bs:getv(disttable,ndist)
      if v < 4 then
        dist += v
      else
        nbits = flr(shr(v-2,1))
        dist += shl(band(v,1)+2,nbits)
        dist += bs:getb(nbits)
      end
      for n = 1,size do
        bs:write(bs:readback(-dist))
      end
    end
  until lit == 256
end
local order = { 17, 18, 19, 1, 9, 8, 10, 7, 11, 6, 12, 5, 13, 4, 14, 3, 15, 2, 16 }
local depths = {}
local lengthtable = {}
local litdepths = {}
local distdepths = {}
local function inflate_block_dynamic(bs)
  local hlit = 257 + bs:getb(5)
  local hdist = 1 + bs:getb(5)
  local hclen = 4 + bs:getb(4)
  for i=1,hclen do
    local v = bs:getb(3)
    depths[order[i]] = v
  end
  for i=hclen+1,19 do
    depths[order[i]] = 0
  end
  local nlen = hufftable_create(lengthtable,depths,19)
  local i=1
  while i<=hlit+hdist do
    local v = bs:getv(lengthtable,nlen)
    if v < 16 then
      depths[i] = v
      i += 1
    elseif v < 19 then
      local nbt = {2,3,7}
      local nb = nbt[v-15]
      local c = 0
      local n = 3 + bs:getb(nb)
      if v == 16 then
        c = depths[i-1]
      elseif v == 18 then
        n += 8
      end
      for j=1,n do
        depths[i] = c
        i += 1
      end
    end
  end
  for i=1,hlit do litdepths[i] = depths[i] end
  local nlit = hufftable_create(littable,litdepths,hlit)
  for i=1,hdist do distdepths[i] = depths[i+hlit] end
  local ndist = hufftable_create(disttable,distdepths,hdist)
  inflate_block_loop(bs,nlit,ndist,littable,disttable)
end
local stcnt = { 144, 112, 24, 8 }
local stdpt = { 8, 9, 7, 8 }
local function inflate_block_static(bs)
  local k = 1
  for i=1,4 do
    local d = stdpt[i]
    for j=1,stcnt[i] do
      depths[k] = d
    end
  end
  local nlit = hufftable_create(littable,depths,288)
  for i=1,32 do
    depths[i] = 5
  end
  local ndist = hufftable_create(disttable,depths,32)
  inflate_block_loop(bs,nlit,ndist,littable,disttable)
end
local function inflate_block_uncompressed(bs)
  bs:flushb(band(bs.n,7))
  local len = bs:getb(16)
  local nlen = bs:getb(16)
  for i=0,len-1 do
    bs:write(peek(bs.pos+i))
  end
  bs.pos += len
end
local function inflate_main(bs)
  bs.pos += 2
  repeat
    local block
    last = bs:getb(1)
    type = bs:getb(2)
    if type == 0 then
      inflate_block_uncompressed(bs)
    elseif type == 1 then
      inflate_block_static(bs)
    elseif type == 2 then
      inflate_block_dynamic(bs)
    end
  until last == 1
  bs:flushb(band(bs.n,7))
  return bs.out
end
function inflate(inaddr)
  return inflate_main(bs_init(inaddr))
end
function blit_bigpic(lines, dst, dstwidth, src, srcwidth, xoff, yoff)
  local data = src[1 - xoff % 2]
  xoff = band(xoff,0xfffe)
  srcwidth /= 8
  dstwidth /= 2
  local dx = band(xoff,7)
  local xoff = flr(xoff/8)
  local srcoff = yoff * srcwidth + xoff
  local w1 = min(max(0, srcwidth - xoff - 1), dstwidth / 4)
  local w2 = dstwidth / 4
  tmp_mem = 0x5e00 + shr(dx,1)
  for line = 0,lines-1 do
    local off = srcoff + srcwidth * line
    for j = 0,w1    do poke4(0x5e00+j*4,data[off + j]) end
    off -= srcwidth
    for j = w1+1,w2 do poke4(0x5e00+j*4,data[off + j]) end
    memcpy(dst + dstwidth * line, tmp_mem, dstwidth)
  end
end
strlen = {}
function _init()
  cls()
  for i=0,255 do
    local k=0
    for j=0,7 do
      if band(i,shl(1,j)) != 0 then
        k += shl(1,7-j)
      end
    end
    reverse[i] = k
  end
  local s = "\151"
  for i=1,#s do strlen[sub(s,i,i)] = true end
    big_data = { [0] = inflate(0x0), {} }
    u32_to_memory(0x0, band(4*#rom+0xff,0x7f00), rom)
    rom = inflate(0x0)
    u32_to_memory(0x0, band(4*#rom+0xff,0x7f00), rom)
  music(0,0,1)
  for n=0,#big_data[0]-1 do
    local off = n - 1
    if n % (image_width / 8) == 0 then off += image_width / 8 end
    big_data[1][n] = shl(big_data[0][n],4) + band(shr(big_data[0][off],28),0x.000f)
  end
  for i=0x2000,0x2010,2 do
    poke(i,16) poke(i+1,17) poke(i+0x80,32) poke(i+0x81,33)
  end
  memcpy(0x2100,0x2000,0x100)
  memcpy(0x2200,0x2000,0x200)
  memcpy(0x2400,0x2000,0x400)
end
world_x, world_y = 0, 0
mouse_x, mouse_y = 0, 0
mouse_speed = 0
mouse_type = 0
mouse_shake = 0
fog_t, fog, fog_dir, fog_color = 0.5, 0, 1, 0
state = 0
function _update60()
  rnd()
  fog_t += shr(1,7)
  local new_fog = 8.0 * (1 - cos(min(fog_t%3.0,1.0))) - 0.5
  fog, fog_dir = new_fog, new_fog > fog and 1 or -1
  mouse_info = nil
  mouse_type = 0
  mouse_shake = max(mouse_shake - 0.25, 0)
  local clicked = false
  if not down then
    clicked = btnp(4) or btnp(5)
  end
  down = btn(4) or btn(5)
  if state==0 then
    world_x = (world_x + 0.125) % image_width
    if fog >= 15 then world_x, world_y = rnd(image_width), rnd(image_height) end
    if clicked then
      sfx(2)
      world_x, world_y = 170, 190
      facts = {}
      state = 1
    end
  elseif state==1 then
    if not btn(0) and not btn(1) and not btn(2) and not btn(3) then
      mouse_speed = 0
    end
    if btnp(0) or btnp(1) or btnp(2) or btnp(3) then
      mouse_speed = max(min(mouse_speed + 0.25, 3), 1)
    end
    if btn(0) then world_x -= mouse_speed end
    if btn(1) then world_x += mouse_speed end
    world_x %= image_width
    if world_y - mouse_speed >= 0 and btn(2) then world_y -= mouse_speed end
    if world_y + mouse_speed < image_height and btn(3) then world_y += mouse_speed end
    for k,v in pairs(obj) do
      local context, mouse, important, facts_wanted, facts_notwanted, facts_activated, coords, message = v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8]
      local wanted = true
      for k,v in pairs(facts_wanted) do
        if not facts[v] then wanted = false end
      end
      for k,v in pairs(facts_notwanted) do
        if facts[v] then wanted = false end
      end
      if wanted then
        local inside = false
        for q in all(coords) do
          if (world_x >= q[1] and world_x <= q[3] and world_y >= q[2] and world_y <= q[4]) inside = true
        end
        if inside then
          mouse_type = mouse
          mouse_info = context
          if clicked then
            sfx(2)
            for k,v in pairs(facts_activated) do
              facts[v] = true
            end
            message_info = message
            if important then
              fog_t, fog, fog_dir, fog_color = 0, 0, 1, 3
              state = 2
            else
              state = 5
            end
            break
          end
        end
      end
    end
    if clicked and state==1 then
      mouse_shake = 5
      sfx(0)
    end
  elseif state==2 then
    if fog_t > 0.5 then state = 3 end
  elseif state==3 then
    if clicked then
      sfx(2)
      fog_t, fog, fog_dir, fog_color = 0.5, 16, 1, 3
      state = 4
    end
  elseif state==4 then
    if fog_t > 1 then state = 1 end
  elseif state==5 then
    if clicked then
      sfx(2)
      state = 1
    end
  end
end
function draw_mouse()
  palt(0,false)
  palt(2,true)
  local x = 64 + rnd(mouse_shake)
  local y = mouse_y + rnd(mouse_shake)
  spr(0x40+mouse_type,x, y)
  spr(0x50+mouse_type,x, y+8)
  palt()
  if mouse_info then
    box("\151 "..mouse_info, -1, mouse_y - 20)
  end
end
function title()
  local blit = function(i, j)
    print("    a pico-8 game", 50+i, 85+j, 7)
    print("  by  sam hocevar", 50+i, 93+j, 7)
    print("for ludum dare 37", 50+i,101+j, 7)
    print("press \151 to start", 53+i, 120+j, 7)
    sspr(24, 0, 80, 32, 5+i, j, 118, 80)
  end
  for i=1,15 do pal(i,0) end
  for i=-1,1 do for j=-1,1 do
    blit(i, j)
  end end
  pal()
  blit(0, 0)
end
function box(text, x, y)
  local l=#text
  local w,lw,h = 0,0,1
  for i=1,l do
    local c = sub(text,i,i)
    if(c=="\n") then
      w=max(lw,w) lw=0 h+=1
    elseif(strlen[c]) then
      lw += 2
    else
      lw += 1
    end
  end
  w=max(lw,w)
  if (x<0) x=60-2*w
  if (y<0) y=55-3*h
  rectfill(x,y,x+4*w+6,y+h*6+6,0)
  rect(x+1,y+1,x+4*w+5,y+h*6+5,7)
  print(text, x+4, y+4)
end
function draw_world()
  local lines = 128
  local dst = 0x6000
  local dstwidth = 0x80
  local srcwidth = image_width
  mouse_x, mouse_y = (flr(world_x + rnd(mouse_shake)) + image_width - 64) % image_width, flr((world_y + rnd(mouse_shake)) * 126 / image_height)
  blit_bigpic(lines, dst, dstwidth, big_data, srcwidth, mouse_x, mouse_y)
end
function draw_fog()
  for i=0,15 do pal(i,fog_color) end
  for n=0,15 do
    for i=0,15 do palt(i,(i+n)/2>fog) end
    map(n%2, 0, (7.5 - (7.5-n) * fog_dir) * 8, 0, 1, 16)
  end
  pal()
end
function _draw()
  if state!=3 then
    draw_world()
  else
    cls(fog_color)
  end
  if state==0 then
    draw_fog()
    title()
  elseif state==1 then
    draw_mouse()
  elseif state==2 or state==4 then
    draw_fog()
  elseif state==3 then
    box(message_info, -1, 20)
    box("\151 continue", 72, 111)
  elseif state==5 then
    box(message_info, -1, -1)
    box("\151 continue", 72, 111)
  end
end