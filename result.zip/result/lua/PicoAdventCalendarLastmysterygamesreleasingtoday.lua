cartdata("picoadvent2020")

function _save(offset,val)
	poke(0x5e00+offset,val)
end
function _load(offset)
	return peek(0x5e00+offset)
end

function _init()
	lightson=true
	mousex,mousey=64,64
	livingroom=1
	toybox=2
	edit=3
	spindle=4
	balltype=0
	balltypes={[0]=192,208,224,240}
	hung=1
	falling=2
	ballcol=4
	gravity=.2
	friction=.01
	sparks={}
	state=livingroom
	carts={{s=128,name=" go:f",id="gof",
									x=16,y=16},
								{s=130,name="sprint\na gift",id="eyn_sprintagift",
									x=16*3,y=16*5},
								{s=132,name="  dr\n santa",id="drsanta",
									x=16*5,y=16*3},
								{s=134,name="jigsaw\n pro",id="jigsaw_xmas",
									x=16*1,y=16*5},
								{s=136,name="gift\n blox",id="giftblox",
									x=16*3,y=16*1},
								{s=138,name="tetrismas",id="tetrismas",
									x=16*1,y=16*3},
								{s=140,name=" coal",id="xmas_coal",
									x=16*5,y=16*1},
								{s=142,name="e♥rth",id="eyn_globe",
									x=16*6.8,y=16*1},
								{s=160,name="  elf\nmountain",id="elfmountain",
									x=16*3,y=16*3},
								{s=162,name=" xmas\n  3x3",id="xmastremetoe",
									x=16*6.8,y=16*5},
								{s=164,name="ataxxmas",id="ataxxmas",
									x=16*4.8,y=16*5},
								{s=166,name="a nice\ncream",id="eyn_nicecream",
									x=16*6.8,y=16*3},
								{s=168,name="present\n  pop",id="presentpop",
									x=16*8.6,y=16*3},
								{s=170,name="frosty\n quest",id="dollarone_frosty_quest",
									x=16*10.6,y=16*1},
								{s=172,name="xmas\n rpg",id="xmas_rpg",
									x=16*10.6,y=16*5},
								{s=199,name="yetis.p8",id="yetisdotbas",
									x=16*10.6,y=16*5},
								{s=231,name="stole coal",id="stolecoal",
									x=16*10.6,y=16*5},
								{s=201,name="winterwood",id="winterwood",
									x=16*10.6,y=16*5},
								{s=233,name="santa_1080",id="santa1080",
									x=16*10.6,y=16*5}
									}
	
	spinoff=#carts
					
									
	stickers={}
	
	for k=128,142,2 do
		local s={x=(k%16)*16
										,y=rnd(100)
										,s=k}
		add(stickers,s)
	end
	ornaments={}
	decobox={s=193,x=-24,y=110}
	presents={}--[[{{s=8,x=60,y=110,timer=12,hinttimer=0,hint="it's shaped\nlike.. adventure..?\nbit cold tho.."},
												{s=10,x=20,y=110,timer=8,hinttimer=0,hint="feels..\nnostalgic?\nannnd\ncollection-y?"},
												{s=40,x=100,y=112,timer=16,hinttimer=0,hint="hmm..sounds like\ndope tricks.\nlike..\nmad dope"}}
	]]
	for k,v in pairs(presents) do
		if stat(83)-5>=v.timer then
			del(presents,v)
		end
	end
	mouse={x=0,y=0}
	pointer=1
	joypad=2
	ctrl=joypad
	
	camx,camy=0,0
	load_ornaments()
	
	stella={ x=56
									,y=17
									,xvel=0
									,yvel=0}
	fc=0
end
function _update60()
	fc+=1
	fc%=60
	updatemouse()
	if btn(⬆️) then
		mousey-=1
	elseif btn(⬇️) then
		mousey+=1
	end
	if btn(⬅️) then
		mousex-=1
	elseif btn(➡️) then
		mousex+=1
	end
	if btn(🅾️) then
		if (btnp(🅾️)) and not lmb then
			lclick=true
		end
		lmb=true
		ctrl=joypad
	end
	if btn(❎) then
		if (btnp(❎)) and not rmb then
			rclick=true
		end
		rmb=true
		ctrl=joypad
	end
	
	if state==livingroom then
		livingroom_update()
	elseif state==toybox then
		toybox_update()
	elseif state==edit then
		edit_update()
	elseif state==spindle then
		spindle_update()
	end
	
	if mousex<camx+32 then
		camx=lerp(camx,mousex-32,.1)
	elseif mousex>camx+128-32-16 then
		camx=lerp(camx,mousex+32+16-128,.1)
	end
end
function _draw()
	camera(camx,camy)
	cls()
	palt(11,true)
	palt(0,false)
	
	
	if state==livingroom then
		livingroom_draw()
	elseif state==toybox then
		toybox_draw()
	elseif state==edit then
		edit_draw()
	elseif state==spindle then
		spindle_draw()
	end
	
end

poke(0x5f2d, 1) -- enable devkit input mode
function updatemouse()
	if ctrl==pointer then
		mousex,mousey=stat(32),stat(33)
	end
	olmb=lmb
	ormb=rmb
	lmb=band(stat(34),1)==1
	rmb=band(stat(34),2)==2
	if not olmb and lmb then
	 lclick=true
	 ctrl=pointer
 else
  lclick=false
 end
 if not ormb and rmb then
  rclick=true
 else
  rclick=false
 end
 mouse.x,mouse.y=mousex,mousey
end

-->8
function toybox_update()
	if lclick then
		for k,v in pairs(carts) do
			if collide(v,mouse) then
				load("#"..v.id,"<-back to advent")
			end
		end
	end
end
function toybox_draw()
	

	for k,v in pairs(carts) do
		
		pspr(v.s,v.x,v.y,2,2,9)
		if v.s==166 then
			pals={10,9,12,1,14,8}
			local a=flr((fc%60)/10)
			for p=1,#pals do
				pal(pals[p],pals[((p+a)%#pals)+1])
			end
			spr(v.s,v.x,v.y,2,2)
			for i=0,15 do pal(i,i) end
		end
		pprint(v.name,v.x-4,v.y+19,1,7)
	end
	
	if lmb then
		spr(66,mousex,mousey,2,2)
	else
		spr(64,mousex,mousey,2,2)
	end
end
-->8
function livingroom_update()
	if lclick then
		local switch={x=-42,y=78,w=8,h=8}
		if collide(switch,mouse) then
			lightson=not lightson
		end
		local shelf={x=150,y=96,w=166+16-150,124-96,7}
		if collide(shelf,mouse) then
			state=spindle
		end
		for k,v in pairs(presents) do
			if collide(v,mouse) then
				sfx(12)
				v.hinttimer=280
				//camera(0,0)
				//state=spindle
				
			end
		end
		for k,v in pairs(ornaments) do
			if collide(v,mouse) then
				if not held then
					sfx(12)
				end
				held=v
			end
		end
		if collide(decobox,mouse) and not held then
			sfx(12)
			held=make_ornament(mousex,mousey,ballcol)
			add(ornaments,held)
		end
		if collide(stella,mouse) then
			sfx(12)
			held=stella
			held.x-=12
		end
	end
	if rclick then
		if collide(decobox,mouse) then
			ballcol=(ballcol+1)%16
			if ballcol==0 then
				balltype+=1
				balltype%=4
			end
		else
			//state=edit
		end
		
	end
	
	for k,v in pairs(sparks) do
		v.xvel-=friction
		v.yvel+=gravity
		
		v.x+=v.xvel
		v.y+=v.yvel
	end
	
	local dels={}
	for k,v in pairs(ornaments) do
		if v.state==falling then
			v.yvel=mid(-v.maxyvel,v.yvel+gravity,v.maxyvel)
			v.y+=v.yvel
			if v.y>=124 then
				add(dels,v)
				sfx(13)
				
				for k=1,16 do
					add(sparks,make_sparks(v))
				end
			end
		end
	end
	
	for k=1,#dels do
		del(ornaments,dels[k])
	end
	if #dels>0 then
		save_ornaments()
	end
	
	
	
	if held then
		held.x=mousex
		held.y=mousey
		if not lmb then
			dropcheck=true
		end
	end
end
function livingroom_draw()
	if lightson then
		cls(1)
		if flr(camx)%2==1 then
			fillp(0b0101101001011010)
		else
			fillp(0b1010010110100101)
		end
		rectfill(-80,110,256,127,0xf4)
		fillp()
		
		
	end
	rectfill(56,80,71,127,4)
	
	
	spr(4,32,32,4,4)
	spr(4,32+32,32,4,4,true)
	spr(4,24,48,4,4)
	spr(4,24+32+8+8,48,4,4,true)
	spr(4,16,64,4,4)
	spr(4,16+32+16+16,64,4,4,true)
	rectfill(48,64,79,95,3)
	camera()
	if #carts>=19 then
		snow()
	end
	camera(camx,camy)
	
	if lightson then
		spr(198,-42,78)
	else
		spr(197,-42,78)
	end
	--check goes here
	if dropcheck then
		for ix=-1,1 do
			for iy=-1,1 do
					c=pget(mousex,mousey)
				if c==3 then
					if held then
						held.state=hung
						held.x-=4
						if held==stella then
							held.x+=12
						end
						save_ornaments()
						held=nil
						
					end
				end
			end
		end
		
		if held then
			held.state=falling
			held.x-=4
			held=nil
		end
		
	end
	dropcheck=false
	
	pspr(decobox.s,decobox.x,decobox.y,2,2,7)
	pal(15,ballcol-1)
	spr(decobox.s,decobox.x,decobox.y,2,2)
	pal(15,15)
	pal(4,ballcol)
	spr(balltypes[balltype],decobox.x+2,decobox.y+7)
	pal(4,4)
	
	
	
	for k,v in pairs(ornaments) do
		if v!=held then
			pal(4,v.c)
			spr(v.s,v.x,v.y)
			pal(4,4)
		end
	end
	
	palt(0,true)
	palt(11,false)
	sspr(8,112,5,5,stella.x,stella.y,15,15)
	palt(11,true)
	palt(0,false)
	
	
	
	for k,v in pairs(sparks) do
		circ(v.x,v.y,v.r,v.c)
	end
	
	spr(84,150,102-8,2,1)
	spr(84,150+16,102-8,2,1,true)
	spr(68,150,102,2,2)
	spr(68,150+16,102,2,2,true)
	spr(68,150,102+16,2,2)
	spr(68,150+16,102+16,2,2,true)
	spr(226,156,102-14)
	
	--add the carts
	for i=0,10 do
		ix=(i%5)*4
		iy=flr(i/5)*16
		rectfill(156+ix,98+iy,158+ix,107+iy,i)
	end
	
	if held then
		if held!=stella then
			pal(4,held.c)
			spr(held.s,held.x-4,held.y)
			pal(4,4)
		end
	end
	
	if lmb then
		spr(66,mousex,mousey,2,2)
	else
		spr(64,mousex,mousey,2,2)
	end

end
--[[
if stat(30) then-- read keyboard had input (bool); repeats every 4 frames after key held for 15 frames
		chars = stat(31) -- read keyboard character
		
		for c=1,#chars do
			local char=sub(chars,c,c)
			if char=='\r' or char=='\n' then
				poke(0x5f30,1)
				if not pwflag then
					text = text..'\n pass: '
					pwflag=1
					cursx = 40
				else
					pwflag+=1
					txty-=6
					cursy-=6
					text=text..'\n'
					cursx=12
				end
				cursy+=6
				
			elseif char=='\b' then
				if #text>0 then
					cursx-=4
				end
				text = sub(text,1,#text-1)
				
			else
				if (pwflag==1) char='*'
				text = text..char
				cursx += 4
			end
		end
		
		
	end]]
	
function make_ornament(x,y,c,s)
	local o = {x=x,y=y,s=s or balltypes[balltype],w=8,h=8,yvel=0,maxyvel=4,c=c or 4}
	return o
end
function make_sparks(v)
	return {x=v.x+3,y=v.y+3,c=v.c,r=1,yvel=-2*max(1,rnd(2)),xvel=flr(rnd(4))-2}
end

-->8
function pspr(s,x,y,w,h,c1,xf,yf)
 for i=0,15 do pal(i,c1) end
 for ix=-1,1 do for iy=-1,1 do
 	spr(s,x+ix,y+iy,w,h,xf,yf)
 end end
 for i=0,15 do pal(i,i) end
 spr(s,x,y,w,h,xf,yf)
end
function collide(a,b)
	local ax,ay,bx,by=a.x,a.y,b.x,b.y
	local aw,ah,bw,bh=a.w or 16,a.h or 16,b.w or 4,b.h or 4
	if ax>b.x+bw
		or ax+aw<bx
		or ay>by+bh
		or ay+ah<by then
	else
		return true
	end
		
end

function pprint(s,x,y,c1,c2)
	for ix=-1,1 do for iy=-1,1 do
		?s,x+ix,y+iy,c1
	end end
	?s,x,y,c2
end

function lerp(a,b,amount)
 return a+(b-a)*amount
end
-->8
	--save all the hung ornaments
	--x,y,c
function save_ornaments()
	//first, clear em out..
	for i=0,255 do
		poke(0x5e00+i,0)
	end
	for k=1,#ornaments do
		local v=ornaments[k]
		if v.state==hung then
			local offset=(k-1)*4
			_save(offset,v.x)
			_save(offset+1,v.y)
			_save(offset+2,v.c)
			_save(offset+3,v.s)
		end
	end
end
function load_ornaments()
	vx=-1
	offset=-1
	while vx!= 0 do
		offset+=1
		
		vx=_load(offset)
		if vx>0 then
			offset+=1
			vy=_load(offset)
			offset+=1
			vc=_load(offset)
			offset+=1
			vs=_load(offset)
			add(ornaments,make_ornament(vx,vy,vc,vs))
		end
	end
end
-->8
--edit mode
--edit mode
function edit_update()
	if lclick then
		
		for k,v in pairs(stickers) do
			if collide(v,mouse) then
				if not held then
					sfx(12)
				end
				held=v
			end
		end
		
	end
	if rclick then
		state=livingroom	
	end
	
	
	if held then
		held.x=mousex
		held.y=mousey
		if not lmb then
			dropcheck=true
		end
	end
end
function edit_draw()
	rectfill(56,80,71,127,4)
	
	spr(4,32,32,4,4)
	spr(4,32+32,32,4,4,true)
	spr(4,24,48,4,4)
	spr(4,24+32+8+8,48,4,4,true)
	spr(4,16,64,4,4)
	spr(4,16+32+16+16,64,4,4,true)
	rectfill(48,64,79,95,3)
	
	spr(197,-42,78)
	--check goes here
	if dropcheck then
		for ix=-1,1 do
			for iy=-1,1 do
				c=pget(mousex,mousey)
				if c==3 then
					if held then
						held.state=hung
						held.x-=4
						if held==stella then
							held.x+=12
						end
						save_ornaments()
						held=nil
						
					end
				end
			end
		end
		
		if held then
			held.state=falling
			held.x-=4
			held=nil
		end
		
	end
	dropcheck=false
	
	pspr(decobox.s,decobox.x,decobox.y,2,2,7)
	pal(15,ballcol-1)
	spr(decobox.s,decobox.x,decobox.y,2,2)
	pal(15,15)
	pal(4,ballcol)
	spr(balltypes[balltype],decobox.x+2,decobox.y+7)
	pal(4,4)
	
	
	
	for k,v in pairs(ornaments) do
		if v!=held then
			pal(4,v.c)
			spr(v.s,v.x,v.y)
			pal(4,4)
		end
	end
	
	palt(0,true)
	palt(11,false)
	sspr(8,112,5,5,stella.x,stella.y,15,15)
	palt(11,true)
	palt(0,false)
	
	for k,v in pairs(presents) do
		pspr(v.s,v.x,v.y,2,2,7)
	end
	for k,v in pairs(stickers) do
		pspr(v.s,v.x,v.y,2,2,7)
	end
	
	for k,v in pairs(sparks) do
		circ(v.x,v.y,v.r,v.c)
	end
	
	spr(84,150,102-8,2,1)
	spr(84,150+16,102-8,2,1,true)
	spr(68,150,102,2,2)
	spr(68,150+16,102,2,2,true)
	spr(68,150,102+16,2,2)
	spr(68,150+16,102+16,2,2,true)
	spr(226,156,102-14)
	
	
	if lmb then
		spr(66,mousex,mousey,2,2)
	else
		spr(64,mousex,mousey,2,2)
	end

end
-->8
--gameselect
function spindle_update()
	if btnp(⬅️) then
		spinoff-=1
	end
	if btnp(➡️) then
		spinoff+=1
	end
	if (spinoff<1) spinoff=#carts
	if (spinoff>#carts) spinoff=1
	
	if btnp(❎) then
		load("#"..carts[spinoff].id,"<-back to advent")
	end
end
function spindle_draw()
	camera(0,0)
	cls()
	
	local k = spinoff-1 
	if spinoff==1 then
		k=#carts
	end
	local v=carts[k]
	local sx=(v.s%16)*8
							
	local sy=flr(v.s/32)*16
	bcolor = sget(sx,sy)+1
	rectfill(-24,22-6,-24+64+4,22+64+4-6,bcolor)
	sspr(sx,sy,16,16,-22,24-6,64,64)
	if v.s==166 then
		pals={10,9,12,1,14,8}
		local a=flr((fc%60)/10)
		for p=1,#pals do
			pal(pals[p],pals[((p+a)%#pals)+1])
		end
		sspr(sx,sy,16,16,-22,24-6,64,64)
		for i=0,15 do pal(i,i) end
	end
	
	k=spinoff
	v=carts[k]
	local sx=(v.s%16)*8
							
	local sy=flr(v.s/32)*16
	bcolor = sget(sx,sy)+1
	rectfill(22,22,22+64+4,22+64+4,bcolor)
	sspr(sx,sy,16,16,24,24,64,64)
	if v.s==166 then
		pals={10,9,12,1,14,8}
		local a=flr((fc%60)/10)
		for p=1,#pals do
			pal(pals[p],pals[((p+a)%#pals)+1])
		end
		sspr(sx,sy,16,16,24,24,64,64)
		for i=0,15 do pal(i,i) end
	end
	pprint(v.name,8,110,1,7)
	k = (spinoff%#carts)+1
	v=carts[k]
	local sx=(v.s%16)*8
							
	local sy=flr(v.s/32)*16
	bcolor=sget(sx,sy)+1
	rectfill(108,22,108+64+4,22+64+4,bcolor)
	sspr(sx,sy,16,16,110,24,64,64)
	if v.s==166 then
		pals={10,9,12,1,14,8}
		local a=flr((fc%60)/10)
		for p=1,#pals do
			pal(pals[p],pals[((p+a)%#pals)+1])
		end
		sspr(sx,sy,16,16,110,24,64,64)
		for i=0,15 do pal(i,i) end
	end

	pprint("press ❎ to load!",32,4,1,14)

end


function snow()
	if not sparts then
		sparts={}
		for i=0,200 do
			add(sparts,{x=camx+rnd(200)-20,y=rnd(128)-16,yvel=max(rnd(2),.2),xvel=max(rnd(.01),.001),a=0,s=max(flr(rnd(2)),1)})
		end
	end
	for k,v in pairs(sparts) do
		v.y+=v.yvel
		v.a+=v.xvel
		circfill(v.x+cos(v.a)*3,v.y,v.s,7)
		if v.y>=130 then
			v.y = -20
		end
	end
end