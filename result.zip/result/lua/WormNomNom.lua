wormspeed=1.5
wormlength = 0
wormseglen = flr(8 / wormspeed)
maxlength = 500*wormseglen
lastname = "..."

ranks={
	{"d.y.e.worm", "do you even worm", 0},
	{"m.wormless", "mostly wormless", 300},
	{"wormless", "wormless", 550},
	{"part worm", "part worm", 800},
	{"n.y.wormin", "now you're worming", 1200},
	{"cert.worm", "certified worm", 2000},
	{"wormtastic","wormtastic", 3000},
	{"worminator","worminator", 4000},
	{"wormlord","wormlord", 5000}
}

toplist={
	{"tic", 2000, 0},
	{"tac", 1500, 0},
	{"tod", 1250, 0},
	{"k.b", 1000, 0},
	{"ilk", 500, 0},
	{"pco", 400, 0},
	{"ate", 300, 0},
	{"o.o", 200, 0},
	{".v.", 100, 0},
	{".x.", 50, 0},
}

leveldata={
	{x=72,y=0,sx=64,sy=64,bonus=400},
	{x=88,y=0,sx=32,sy=64,bonus=500},
	{x=40,y=0,sx=64,sy=64,bonus=650},
	{x=56,y=0,sx=64,sy=64,bonus=800},
	{x=40,y=16,sx=(52-40)*8,sy=(27-16)*8,bonus=1000}
}

local data_hiscore = 0
local data_toplist = 1

local scrolltext = "                               press z or x to start worming"
local s_title = 1
local s_game = 2
local s_gameover = 3
local s_leveldone = 4
local s_newgame = 5
local s_splash = 6

gamestate = s_title

gamestates = {}

local namectab = 
	"abcdefghijklmnopqrstuvwxyz."

function ord(c)
	for i=1,#namectab do
		if sub(namectab,i,i) == c then
			return i
		end
	end
	
	return 0
end

function chr(i)
	return sub(namectab, i, i)
end

function savetoplist()
	for i=1,10 do
		local offs=(i-1)*(3+2)+data_toplist
		-- 3 letters, 2 bytes for score
		dset(offs, ord(sub(toplist[i][1],1,1)))
		dset(offs+1, ord(sub(toplist[i][1],2,2)))
		dset(offs+2, ord(sub(toplist[i][1],3,3)))
		dset(offs+3, toplist[i][2])
		dset(offs+4, toplist[i][3])
	end
end

function loadtoplist()
	for i=1,10 do
		local offs=(i-1)*(3+2)+data_toplist
		-- 3 letters, 2 bytes for score
		--print(dget(offs))
		if dget(offs) > 0 then
			local name = ""
			
			name = chr(dget(offs))..chr(dget(offs+1))..chr(dget(offs+2))
			
			toplist[i][1] = name
			toplist[i][2] = dget(offs+3)
			toplist[i][3] = dget(offs+4)
		end
	end
end

function drawtoplist()
	local x = 18
	local y = 22
	local toplistcol={
		7, 10, 9, 8, 14, 4, 2, 3, 13, 5
	}
	
	local title = "t o p   h a t s"
	
	shadtext(title,
		64-#title*4/2, 9, 10, 2)
	
	for i=1,#toplist do
		local xx = x+4
		if i >= 10 then
			xx -= 4
		end
		
		local sc = 0
		
		if i <= 3 then
			sc = 4
		end
		
		shadtext(i..".", xx, y, toplistcol[i], sc)
		shadtext(toplist[i][1], x + 16-3, y, toplistcol[i], sc)
		
		local score = ""..toplist[i][2]
				
		shadtext(score, x + 14 + 4 * 3 + 2 + 4 * 5 - #score*4, y, toplistcol[i], sc)
		shadtext(getrank(toplist[i][2],true), x + 14 + 4 * 3 + 2 + 4 * 5 + 4, y, 6, sc)
		y+=6
		
		if i == 3 then
			y += 2
		end	
	end
end

function addtopscore(name,score)
	local temp = {}
	local c = 0
	local added = false
	for s in all(toplist) do
		if not added and score > s[2] then
			add(temp,{name,score})
			added = true
			c += 1
		end
		
		if c >= 10 then
			break
		end
		add(temp,s)
		c+=1
	end
	toplist = temp
end

function getrank(score,short)
	local br = ranks[1]
	for r in all(ranks) do
		if r[3] <= score then
			br = r
		end
	end
	
	if short then
		return br[1]
	else
		return br[2]
	end
end

function changestate(state)
	gamestate = state
	
	if gamestates[state].init != nil then
		gamestates[state].init()
	end
end

function doparticles()
	for p in all(particles) do
		p.ttl -= 1
		
		if p.ttl <= 0 then
			del(particles,p)
		end
		
		p.x += p.dx
		p.y += p.dy
		p.z += p.dz
		
		if p.z < 0 then
			p.z = 0
			p.dz *= -0.7
			if abs(p.dz) <= 0.75 then
				p.dz = 0
			end
		else
			p.dz -= 0.3
		end
		
	end
end

function addparticle(t,x,y,z,dx,dy,dz,ttl)
	if not ttl then
	 ttl = rnd()*200+50
	end
	add(particles,{t=t,x=x,y=y,z=z,dx=dx,dy=dy,dz=dz,ttl=ttl})
end

function drawparticles()
	for p in all(particles) do
		zspr(p.t,p.x,p.y,p.z)
	end
end

function _init()
	cartdata("i_k_wormnomnom")
	highscore = dget(data_hiscore)
	loadtoplist()
	changestate(s_splash)
	--toplist[1][1]="abc"
	--savetoplist()
end

function inittitle()
	scrollx = 0	
	frame=0
	music(0)
	dset(data_hiscore,highscore)
	savetoplist()	
end

function initgameover()
	startdelay=30*2
	newtopscore = false
	topscoreletter = 1
	topscorename = lastname	

	for t in all(toplist) do
		if t[2] < points then 
			newtopscore = true
			break
		end
	end
	
	--addtopscore("yay", points)
end


function setstart()
	wormspeed=1.5
	levelcompdelay = 0
	showextend = 0
	playtime=0
	fruitnotify=0
	head={x=leveldata[level].sx-4,
		y=leveldata[level].sy,
		d=0.25,z=256,poop=0}
	worm={}
	for i=0,maxlength do
		add(worm,{x=head.x,y=head.y-8,d=0,z=64,poop=0})
	end
	
	local hat = nil
	
	if not hashat then
		for f in all(fruits) do
			if f.s == 3 then
				hat = f
				break
			end
		end
		if hat != nil then
			fruits={hat}
		end
	else
		fruits={}
	end
	
	
	poop={}
	flowers={}
	killed=false
	startdelay=30*3
	wormidx=1
	
	if neededfruit <= fruitseat then
		changestate(s_leveldone)
	else
		addfruit()
	end
end

function initlevel()
	hashat = true
	addedextend = false
	fruitnotify=0
	fruitseat = 0
	levelbonus = leveldata[level].bonus
	leveloffx=leveldata[level].x
	leveloffy=leveldata[level].y
	scoremultiplier=1
	startdelay = 3 * 30
	killed=false
	particles={}
	startdelay=30*3
	fruits={}
	poop={}
	flowers={}

	setstart()
	
	wormidx=1
	wormlength = 0

	growworm(1)

end

function resetextend()
	extendsprites={
		82,83,84,82,85,86
	}
	extendletters={
		false,false,false,false,false,false
	}
end

function updateextend(l)
	for i=1,6 do
		if l == extendsprites[i] and
			not extendletters[i] then
			extendletters[i] = true
			showextend = 30*1.5
			break
		end
	end
	
	local complete = true
	
	for i=1,6 do
		if not extendletters[i] then 
			complete = false
			break
		end
	end
	
	if complete then
		lives += 1
		resetextend()
		extralifecounter=30*2
	end
end

function initgame()
	extralifecounter=0
	totflowers = 0
	lavactr=0
	jump=0
	tries=0
	appear=0
		
	leveloffx=leveldata[level].x
	leveloffy=leveldata[level].y
	scoremultiplier=1
	
	initlevel()	
	
end

function initnewgame()
	music(-1, 1000)
	
	resetextend()
	lives = 3
	points = 0 
	level = 1
	visuallevel = 1
	neededfruit=12
	
	gameframes = 0
	
	timeline={}

	changestate(s_game)
end

function addfruit(extend)

	if not extend then
		local st = {4,7,8}
		s=st[flr(rnd()*#st)+1]
	else
		while true do
			local i = flr(rnd()*6)+1
			if not extendletters[i] then
				s = extendsprites[i]
				break
			end
		end
	end
	
	local x
	local y
	
	while true do
	 x =  rnd()*112+4
	 y = rnd()*112+4
		
		local tryagain = false
		
		for p in all(poop) do
			if (abs(p.x - x) < 7 and
				abs(p.y - y) < 7)
				 then
				tryagain=true
				break
			end
		end
		
		if (abs(head.x - x) < 16 and
				abs(head.y - y) < 16) then
				tryagain = true
		end
		
		if fget(mget(leveloffx+(x+4)/8,leveloffy+(y+4)/8),0) then
			tryagain = true
		end
		
		if not tryagain then
			break
		end
	end
	
	local ttl = nil
	local dz = 1
	
	if extend then 
		ttl = 30*5
		dz = 2
	end
	
	add(fruits,{x=x,y=y,z=128,dz=dz,s=s,ttl=ttl})
end

function growworm(l)
	wormlength += wormseglen*l
	
	
	if wormlength > maxlength then
		wormlength = maxlength
	end
end


function updatetitle()
	if btnp(4) or btnp(5) then
		changestate(s_newgame)
	end
	
	scrollx += 1
	frame += 1
	
	if scrollx/4 > #scrolltext then
		scrollx= 0 
	end
end

function scroll(dx,dy)
	for f in all(fruits) do
		f.x += dx
		f.y += dy
	end
	
	for f in all(poop) do
		f.x += dx
		f.y += dy
	end
	
	for b in all(worm) do
		b.x += dx
		b.y += dy
	end
	
	head.x += dx
	head.y += dy
end

function zspr(s,x,y,z,_fx,_flash)
	local fx = _fx or false
	local flash = _flash or false
	add(drawq,{s,x,y,z,fx,flash})
	--spr(s,x,y-z,1,1,fx)
end

function nextlevel()
	level += 1
	visuallevel += 1
	neededfruit += 6
	if level > #leveldata then
		level = 1
		neededfruit -= 10
	end
	initlevel()
end


function drawtimeline()
	color(7)
	local y = 0
	local x = 0
	for t in all(timeline) do
		line(t[1]*127/gameframes,127-t[2]/10,
			x,127-y)
		y=t[2]/10
		x = t[1]*127/gameframes
	end
end

function updatefruit()
	for f in all(fruits) do
		if f.ttl != nil then
			f.ttl -= 1
			if f.ttl <= 0 then
				del(fruits,f)
			end
		end
	
		f.z += f.dz
			
		if f.z < 0.7 then 
 		f.z = 0
			f.dz *= -0.3
			if abs(f.dz) > 0.1 then
			sfx(17)
			end
		end
			
		if f.z > 0.7 then
			f.dz -= 0.4
		end
	end
end

function updategame()
	if levelcompdelay > 0 then
		wormspeed *= 0.95
		levelcompdelay -= 1
		if levelcompdelay <= 0 then
			changestate(s_leveldone)
			return
		end
	end

	if showextend > 0 then
		showextend -= 1
	end
	
	if extralifecounter > 0 then
		extralifecounter -= 1
	end
	
	if appear < 128 then
		appear += 1+appear/4
	end
	--scroll(0,0)
	
	if fruitnotify > 30*10 then
		fruitnotify=0
	else
		fruitnotify += 1
	end
	
	if startdelay <= 0 and levelbonus > 0 then
		levelbonus -= 0.2
		if levelbonus < 0 then
			levelbonus = 0
		end
	end
	
	if startdelay > 0 then
		startdelay -= 1
		if startdelay <= 0 then
			music(16, 0, 1+2)
		end
	else
		gameframes+=1/30
	end
	
	scoremultiplier = 1.0 + #flowers / 5

	doparticles()
	dolava()
		
	if not killed then
	
	if startdelay <= 0 then
	head.x += cos(head.d)*wormspeed
	head.y += -sin(head.d)*wormspeed
	end
	
	head.z += jump
	
	if playtime > 30 then
	if head.z < 3 and checkselfcollision() then
		killworm(true)
		return
	end
	end
	
	if startdelay <= 0 then
	playtime += 1
	end
	
	
	if head.z < 2 then
		if fget(mget(leveloffx+(head.x+4)/8,leveloffy+(head.y+4)/8),0) then
			if lavactr > 2 then 
				for i=0,3 do
					addparticle(94,head.x,head.y,0,rnd()*2-1,rnd()*1.5-0.75,rnd()*1.5+0.75,rnd()*20+10)
				end
				killworm()
		
				return
			else
				lavactr+=1
			end
		else
			lavactr=0
		end
	end
	
	updatefruit()
	
	if head.z <= 0 then
		head.z = 0
		jump *= -0.25
		--addparticle(head.x,head.y,0,rnd()*2-1,rnd()*2-1,3)
		if abs(jump) < 0.3 then
			jump = 0
		else
			sfx(1)
		end
		
		for f in all(flowers) do
			if abs(f.x-head.x) < 6 and
				abs(f.y-head.y) < 6 then
				del(flowers,f)
				sfx(14)
				for i=0,3 do
					addparticle(67,f.x,f.y,0,rnd()-0.5,rnd()-0.5,rnd()+1,rnd()*10+10)
				end
			end
		end
		
		local addfruitb = false
		
		for f in all(fruits) do
			if f.z < 4 and abs(f.x-head.x) < 8 and
					abs(f.y-head.y) < 8 then
					del(fruits,f)
					sfx(14)
					updateextend(f.s)
					
					if f.s == 3 then
						hashat = true
						addpoints(-flr(-(20 * scoremultiplier)), true)
					else
						for i=0,3 do
							addparticle(67,f.x,f.y,0,rnd()-0.5,rnd()-0.5,rnd()+1,rnd()*10+10)
						end
										
						if f.s < 82 or f.s > 86 then
							addpoints(-flr(-(10 * scoremultiplier)), true)
							addfruitb = true
							fruitseat += 1
							growworm(1)
						
							if fruitseat >= neededfruit then
								levelcompdelay=30
								music(-1, 1000)
							end
						end
					
					end
			end
		end
		
		if addfruitb and fruitseat < neededfruit then
			fruitnotify=0
			addfruit()
			add(poop,{rock=false,x=head.x,y=head.y,hide=wormlength+4,frame=0})
			head.poop = wormseglen
			
			if not addedextend and rnd() < 0.15 then
				addfruit(true)
				addedextend = true
			end
		end
	else
		jump -= 0.27
	end
	
	for p in all(poop) do
		if p.hide <= 0 then
			if head.z < 3 and abs(p.x - head.x) < 3 and
				abs(p.y - head.y) < 3 then
				for i=0,5 do
					addparticle(68,p.x,p.y,0,rnd()*2-1,rnd()*2-1,rnd()*2,30)
				end
				sfx(2)
				killworm(true)
				return
			end
			if not p.rock then
				p.frame += 0.020
				if p.frame >= 4 then
					del(poop,p)
					add(flowers,{t=flr(rnd()*3),x=p.x, y=p.y})
					totflowers += 1
					if #flowers > 6 and totflowers % 10 == 0 then
						addedextend = false
					end
					sfx(12)
				end
			end
		else
			p.hide -= 1
			if p.hide == 0 then
				for i=0,2 do
					addparticle(68,p.x,p.y,0,rnd()*2-1,rnd()*2-1,rnd()*0.5+1.75,20+rnd()*10)
				end
				sfx(2)
			end
		end
	end
	
	if head.poop > 0 then
		head.poop -= 1
	end
	
	if head.z < 2 then	
	-- makes jumping help
	-- turning when on the edge
	-- of screen -> more fun
	
	if head.x > 126 or head.x < -6 or
		head.y > 126 or head.y < -6 then
		killworm()
		return
	end		
	end
			
	--if btnp(5) then
	--	growworm(1)
	--end
	
	if startdelay <= 0 then	
		if btn(0) or btn(2) then
			head.d -= 0.02
		elseif btn(1) or btn(3) then
			head.d += 0.02
		end
		
		if (btnp(4) or btnp(5)) and head.z <= 2 then
			jump = 3
			sfx(0)
		end
	end
	
	while head.d < 0 do
		head.d += 1
	end
	
	worm[wormidx].x = head.x
	worm[wormidx].y = head.y
	worm[wormidx].z = head.z
	worm[wormidx].d = head.d
	worm[wormidx].poop = head.poop

	wormidx += 1
	if wormidx > #worm then
	 wormidx = 1
	end
		
	end
end

function checkselfcollision()
	local i = wormidx-wormlength-1
	local l = 0
	local wl = #worm
	
	while i < 1 do
		i += wl
	end	
		
	for b in all(worm) do
		if l > 2 then
			if worm[i].z < 4 and abs(worm[i].x-head.x)<3 and
				abs(worm[i].y-head.y)<3
			then
				return true
			end
		end
		
		i += 4
		if i > wl then
			i -= wl
		end
		
		l += 4
		
		if l > wormlength - 16 then
			break
		end
	end
	
	return false
end

function drawtitle()
	camera()
	cls()
	
	palt()
	local yo = 0
	local xo = 0
	local t = frame/100
	for y=0,127 do
		for x=0,127,16 do
		local zo = cos(y/512+x/1024+t*0.1)
		local yo = cos(y/1024+x/512+t*0.25+zo*0.5)*zo*16+16
		local xo = (sin(y/256+x/256+t)*yo+32)%32
		clip(x,y,16,1)
		map(16,y/8,xo-32,y-y%8,24,1)
		end
	end
	clip()
	palt(0,false)
	palt(15,true)
	
	if frame % (10 * 30) < 5 * 30 then
		map(0,0,0,8,16,16)
	else
		map(0,16,0,8,16,16)
		drawtoplist()

	end
	
	--clip(34,89,60,8)
	local offs = flr(scrollx/4)
	local subtext = sub(scrolltext,offs,offs+32)

	-- normal colored center
	clip(10+4,89,100,6)
	color(1)
	print(subtext,6-scrollx%4,90)
	color(10)
	print(subtext,6-scrollx%4,89)
	
	-- dim colored edges
	local ctab = {{2,9},{1,15}}
	local x = 0
	for c in all(ctab) do
	clip(10+x,89,4,6)
	color(c[1])
	print(subtext,6-scrollx%4,90)
	color(c[2])
	print(subtext,6-scrollx%4,89)
	clip(18+100-4-x,89,4,6)
	color(c[1])
	print(subtext,6-scrollx%4,90)
	color(c[2])
	print(subtext,6-scrollx%4,89)
	x+=4
	end
	clip()
	
	--[[if highscore > 0 then
		local text="high score: "..highscore
		shadtext(text,64-((#text)*4/2),98,10,2)
	
		text="("..getrank(highscore,false)..")"
		shadtext(text,64-((#text)*4/2),98+6,9,2)
	end--]]
	
	shadtext("ilkkke", 18, 114,7,0)
	shadtext("kometbomb", 82, 114,7,0)
end

function shadtext(text,x,y,tc,sc)
	color(sc)
	print(text,x,y+1)
	color(tc)
	print(text,x,y)
end

function drawgame()
	cls()
	if gamestate == s_game then
		camera()
		if tries == 0 then
			clip(64-appear/2,64-appear/2,appear,appear)
		else
			clip()
		end
	end
	
	--color(5)
	--rectfill(0,0,127,127)
	palt()
	map(leveloffx,leveloffy,0,0,16,16)

	drawq={}
	
	local fruitflash = fruitnotify > 8*30 and fruitnotify % 2 == 0
	local fruitarrow = fruitnotify > 8*30 
	
	for f in all(fruits) do
		if f.ttl != nil and f.ttl < 30*1.5 and f.ttl % 2 == 0 then
			zspr(f.s,f.x,f.y,f.z,false,true)
		else
			zspr(f.s,f.x,f.y,f.z,false,fruitflash)
		end
		
		if fruitarrow then
			zspr(98,f.x,f.y,f.z+cos(fruitnotify/15)*2+9,false)
		end
	end
	
	for f in all(flowers) do
		local fspr = {65,80,81}
		zspr(fspr[f.t+1],f.x,f.y,0)
	end
	
	for p in all(poop) do
		if not p.rock then
			if p.hide <= 0 then
				zspr(56+flr(p.frame),p.x,p.y,0)
			end
		else
			zspr(66,p.x,p.y,0)
		end
	end
		
	drawparticles()
	
	if not killed then

	local i = wormidx-wormlength-1
	local l = 0
	local wl = #worm
	
	while i < 1 do
		i += wl
	end
	
	
		
	for b in all(worm) do
			if l == wormlength then
				local rt = {
					{12,false},
					{13,false},
					{14,false},
					{13,true},
					{12,true},
					{11,true},
					{10,false},
					{11,false}
				}
				
				local r = rt[1 + flr(8*worm[flr(wormidx-1-1+wl)%wl+1].d+(1/8))%8]
			
				--print(worm[i].d)
				--stop()
				
				local z = worm[(i-2-1)%wl+1].z
				
				if jump > 0 then
					z = worm[i].z
				end
				
				zspr(r[1],worm[i].x,worm[i].y,worm[i].z,r[2])
				if hashat then
					zspr(3,worm[i].x,1+worm[i].y,z+5)
				end
			else
				if worm[i].poop > 0 then
				zspr(9,worm[i].x,worm[i].y,worm[i].z)
				else
				zspr(1,worm[i].x,worm[i].y,worm[i].z)
				end
			end
		
		i += wormseglen
		if i > wl then
			i -= wl
		end
		
		l += wormseglen
		
		if l > wormlength then
			break
		end
	end
	
	end

	sort(drawq)
	
	palt()
	palt(0,false)
	palt(5,true)
	
	for s in all(drawq) do
		if s[1] != 3 and s[1] != 68 and s[1] != 5 and s[1] !=67 and s[1] !=94 then
			local i = flr(s[4] / 32)
			if i < 4 then
				spr(60+3-i,s[2],s[3])
			end
		end
	end
	
	for s in all(drawq) do
		if s[6] then
			for i=1,15 do
				if i != 5 and i != 1 then pal(i,7)
				end
			end
		else
			pal()
			palt()
			palt(0,false)
			palt(5,true)
		end
		spr(s[1],s[2],s[3]-s[4],1,1,s[5])
	end
	pal()
	palt(0,false)
	palt(5,true)
	
	clip()

	if startdelay > 0 and startdelay < 30*2 and gamestate == s_game then
  rectfill(44-4,48,44+45-4,48+8,0)
  spr(96,40-4,46)
  spr(97,86-4,46)
  local text
  if tries == 0 and startdelay > 30*1 then
  text = "level "..visuallevel
  else
  
  text = "get ready!"
  end
		shadtext(text, 64-((#text)*4/2), 50, 10, 0)
	end
	
	--shadtext(-flr(-levelbonus),64-48,0,7,0)

	local mult = scoremultiplier*10

	spr(99,64+40-8+2,0)
	shadtext(neededfruit-fruitseat,64+40+1,1,7,0)
	
	local pointstxt = (""..points)
	
	--shadtext(levelbonus,64-32,1,10,0)
	shadtext(points,64-(#pointstxt*4/2),1,10,0)
	
	spr(100,0,0,2,1)
	shadtext(flr(mult/10).."."..(mult%10),16,1,7,0)
	
	spr(95,116,0)
	shadtext(lives,124,1,7,0)
		
	if showextend > 0 or extralifecounter > 0 then
		for i=1,6 do
			if extendletters[i] or (extralifecounter > 0 and extralifecounter % 4 < 2) then
				spr(extendsprites[i],i*12+64-(6*12/2)-8,119)
			else
				spr(102,i*12+64-(6*12/2)-8,119)
			end
		end
	end
end

function killworm(throwhat) 
	music(-1, 100)
	sfx(13)
	tries += 1
	killed = true
	
	local i = wormidx-wormlength-1
	local l = 0
	local wl = #worm
	
	while i < 1 do
		i += wl
	end
	
	for b in all(worm) do
			for c=0,3 do
			addparticle(5, worm[i].x+rnd()*4-2,worm[i].y+rnd()*4-2,0,rnd()*2-1,rnd()*2-1,rnd()*4,60+rnd()*30)
			end
		
		i += wormseglen
		if i > wl then
			i -= wl
		end
		
		l += wormseglen
		
		if l > wormlength then
			break
		end
	end
	
	--addparticle(3,head.x,head.y,4,0,0,4,1000)
	
	local hat = {s=3,x=head.x,y=head.y,z=4,dx=0,dy=0,dz=4}
	
	if lives == 1 then
		lives = 0
		changestate(s_gameover)
	else
		lives -= 1
		setstart()
	end
	
	if throwhat and hashat then
		add(fruits,hat)
		hashat = false
	end
end

function ribbon(x,y,w,h)
	rectfill(x-4,y,x+w+3,y+h,0)
	spr(96,x-4-4,y-2)
	spr(97,x+w,y-2)
	 
end

function drawgameover()
	camera()
	drawgame()
	if startdelay < 1*30 then
		rectfill(44-4,48+8-16,44+45-4,48+8+8-16,0)
	 spr(96,40-4,46+8-16)
	 spr(97,86-4,46+8-16)
		shadtext("game over", 46, 50+8-16, 10, 0)
		
		local text = getrank(points,false)
		local w = #text*4 + 4
		
		shadtext("rank:", 64-5*4/2+2,48+8,7,0)
		
		rectfill(64-w/2,48+8+24-16,64+w/2,48+8+8+24-16,0)
	 spr(96,64-w/2-4,46+8+24-16)
	 spr(97,64+w/2-3,46+8+24-16)
	 
		shadtext(text, 64-w/2+3, 50+8+24-16, 10, 0)

	end
	
	if startdelay < 1*30 then
		if newtopscore then
			local text = "enter your initials:"
		
			ribbon(64-#text*4/2-8,112,#text*4+16,8)
		
			shadtext(text, 64-(#text+3)*4/2, 112+2, 9, 0)
			shadtext(topscorename, 64+(#text+3)*4/2-3*4, 112+2, 12, 0)
			spr(124,64+(#text+3)*4/2-4*4+topscoreletter*4-2,112-8)
			spr(125,64+(#text+3)*4/2-4*4+topscoreletter*4-2,112+8)
		else
			local text = "press z to continue"
		
			shadtext(text, 64-(#text)*4/2, 112, 7, 1)
		end
	end
	
	--drawtimeline()
end

function dolava()
	local x = flr(rnd()*16)
	local y = flr(rnd()*16)
	
	if rnd() > 0.15 then
		return
	end
	
	if fget(mget(x+leveloffx,leveloffy+y),1) then
		for i=0,3 do
			addparticle(94,x*8+4,y*8+4,0,rnd()*1-0.5,rnd()*1-0.5,1.5+rnd()*2,25+rnd()*15)
		end
	end
end

function initleveldone()
	origdonepoints = flr(levelbonus)
	donepoints = flr(levelbonus * scoremultiplier)
	addtimelinepoints(donepoints)
 pause=30*1.5
 donetimer = 0
 donescroll=0
end

function drawleveldone()
	camera(0,donescroll)
	--pal(5,7)
	drawgame()
	clip()
	
	--rectfill(0,0,127,4,7)
	--rectfill(0,106,127,127,7)
	--rectfill(0,0,4,127,7)
	--rectfill(123,0,127,127,7)
	
	rectfill(44-4,48,44+45-4,48+8,0)
 spr(96,40-4,46)
 spr(97,86-4,46)
	shadtext("right on!", 46, 50, 10, 0)

	rectfill(44-36-3,48+16,44+45+36-4,48+8+16,0)

	spr(96,40-36-3,46+16)
 spr(97,86+36-4,46+16)
 local text = "time bonus "..origdonepoints.." x "..scoremultiplier..
 	" = "..flr(scoremultiplier*origdonepoints)
	shadtext(text, 64-(#text*4/2), 50+16, 10, 0)
end

function addtimelinepoints(p)
	add(timeline,{gameframes,-flr(-(points+p))})
end

function addpoints(p,addtimeline)
	points = -flr(-(points+p))
	if addtimeline then
		addtimelinepoints(p)
	end
	highscore = max(highscore,points)
end

function updateleveldone()
	if pause > 0 then
		pause -= 1
		return
	end
	
	local ps = 5
	
	if btn(4) or btn(5) then
		ps = donepoints
	end
	
	if flr(donepoints) > 0 then
		addpoints(-flr(-(min(ps,donepoints))), false)

		donepoints -= ps
		
		sfx(16)
	else 
		donetimer += 1
		if donetimer > 30 then
			donescroll += donescroll/4+1
		end
		if donetimer > 30*2 then
			nextlevel()
			
			changestate(s_game)
		end
	end
end

function updategameover()
	doparticles()
	dolava()
	
	updatefruit()
	
	if startdelay > 0 then
		startdelay -= 1
	end
	
	if startdelay < 1*30 and not newtopscore then
		if startdelay <= 0 and (btnp(4) or btnp(5)) then
			changestate(s_title)
		end
	else
		if btnp(2) or btnp(3) then
			local tt = {}
			
			for i=1,3 do
				tt[i] = ord(sub(topscorename, i, i))
			end
			
			local d = 1
			
			if btnp(2) then
				d = -1
			end
						
			tt[topscoreletter] = 
				((tt[topscoreletter] - 1 + d + #namectab) % #namectab) + 1
			
			topscorename = chr(tt[1])..chr(tt[2])..chr(tt[3])
			
			sfx(14)
				
		elseif btnp(5) then
			if topscoreletter > 1 then
				topscoreletter -= 1
				
				topscorename = sub(sub(topscorename, 1, topscoreletter).."...", 1, 3)
			end
			sfx(2)
		elseif btnp(4) then
			topscoreletter += 1
			if topscoreletter > 3 then
				addtopscore(topscorename, points)
				
				newtopscore = false
				startdelay = 1
				
				lastname = topscorename
				
				sfx(1)
			else
				sfx(17)
			end
		end
	end
end

function _update()
	gamestates[gamestate].update()
end

function _draw()
	gamestates[gamestate].draw()
end

function sort(a)
  for i=1,#a do
    local j = i
    while j > 1 and 
   		(a[j-1][3] > a[j][3]) do
      a[j],a[j-1] = a[j-1],a[j]
      j = j - 1
    end
  end
end


function updatesplash()
	splashdelay -= 1
	
	if splashdelay <= 0 then
		changestate(s_title)
	end
end

function initsplash()
	splashdelay = 30*2.5
end

function drawsplash()
	cls()
	pal()
	map(104,0,64-7*8/2,64-6*8/2,11,5)
end



gamestates[s_title]={x=1,draw=drawtitle,update=updatetitle,init=inittitle}
gamestates[s_game]={draw=drawgame,update=updategame,init=initgame}
gamestates[s_gameover]={draw=drawgameover,update=updategameover,init=initgameover}
gamestates[s_newgame]={draw=drawgame,update=nil,init=initnewgame}
gamestates[s_leveldone]={draw=drawleveldone,update=updateleveldone,init=initleveldone}
gamestates[s_splash]={draw=drawsplash,update=updatesplash,init=initsplash}
