-- kick wizards
-- by ryan forsythe

-- monster states
asleep = 0
waiting = 1
melee = 2
throwing = 3
-- goat states
sliding = 4
-- boss states
castingpunch = 5
castingkick = 6
summoncreatures = 7
moving = 8
escaping = 9

mapoffset = 0
actorindex = 1

function frnd(x) return flr(rnd(x)) end
function tupdate(a, t)
	if t then
		for k,v in pairs(t) do
			a[k] = v
		end
	end
	return a
end

function newactor(attributes)
	local a = {
		index = actorindex,
		x = 0,
		y = 0,
		z = 0,
		h = 0,
		w = 0,
		vx = 0,
		vy = 0,
		vz = 0,
		dv = 0,
		mass = 1,
		layer = 1,
		friction = 0.56,
		solid = true,
		flipsprite = false,
		spritebase = 127,
		--moveframe = nil, 
		palshift = {},
		draw = function(self) end,
		update = function(self) end,
	}
	tupdate(a, attributes)
	actorindex += 1
	return a
end

function copyactor(a, nospeed)
	local b = newactor({x = a.x,
						y = a.y,
						z = a.z,
						h = a.h,
						w = a.w,
						mass = a.mass,
						layer = a.layer,
						friction = a.friction,
						solid = a.solid,
						flipsprite = a.flipsprite,
						spritebase = a.spritebase,
						moveframe = a.moveframe,
						palshift = a.palshift})
	if (nospeed != true) tupdate(b, {vx = a.vx, vy = a.vy, vz = a.vz, dv = a.dv})	
	return b
end

function newcreature(attributes)
	return tupdate(newactor({kind = 1, -- monster
							 hp = 1,
							 maxhp = 1,
							 stuntime = 0,
							 attacking = false,
							 moveframe = -1,
							 draw = draw1sprite,
							 setstun = stun,
							 damage = basicdamage,
							 statefns = {}}),
				   attributes)
end

function _init()
	gamestate = 0 
	music "0"

	players = {}
	deadplayers = {}
	monstertargets = {}
	actors = {}
	staticactors = {}
	waterfalllocs = {}
	passable = {}
	mapw = 640
	master_spawnpositions = {}
	spawnpositions = {}
	spawning = {}
	
	spritetospawnfn = {
		[16] = spawnkobold;
		[17] = spawnthrowkobold;
		[30] = spawnogre;
		[46] = spawnredogre;
		[7] = spawnsoldier;
		[32] = spawngoat;
		[23] = spawndrake;
		[39] = spawnskel;
		[63] = spawnhealer;
		[4] = spawnevilwzrd;
	}

	l2chargepxs = {}
	l3chargepxs = {}
	for x=0,7 do
		for y=0,7 do
			local c = coloratsprite(61, x, y)
			if (c == 8) add(l2chargepxs, {x, y})
			if (c == 9) add(l3chargepxs, {x, y})
		end
	end
	
	waterfallrows = {}
	for y=1,128 do
		waterfallrows[y] = {}
		for x=1,128 do
			waterfallrows[y][x] = (frnd"2" == 0)
		end
	end

	for mapcol=0,mapw do
		local mapx = mapcol % 128
		local mapy = flr(mapcol / 128) * 8
			
		if (not master_spawnpositions[mapx]) master_spawnpositions[mapx] = {}
			
		for y=mapy,mapy+7 do
			local s = mget(mapx,y)

			if s == 117 then
				waterfalllocs[mapcol] = true
				mset(mapx,y, 0)
			end

			if spritetospawnfn[s] then
				master_spawnpositions[mapx][y] = s
				mset(mapx, y, 67)
			end

			if fget(s, 0) then
				passable[s] = function(px,py)
					local mx,my = mapposfrompx(px,py)
					local spr = mget(mx, my)
					return coloratsprite(spr, px % 8, py % 8) == 4
				end
			end

			if (fget(s, 1)) passable[s] = function(mapx,y) end -- golfed, returns falsy
		end
	end
end

function tocell(px)
	return flr(px / 8)
end

function mapposfrompx(x,y)
	local row = flr(x/1024)
	return tocell(x) - (128 * row),
			row*8 + tocell(y - 40) -- bad, but saves tokens
end

function pxfrommappos(mapx, mapy)
	local row = tocell(mapy) -- bad, but saves tokens
	return 8 * (mapx + 128 * row), 40 + (8 * (mapy - row * 8))
end

function coloratsprite(spr, sprx, spry)
	--local ssx = topx(spr % 16)
	--local ssy = topx(flr(spr / 16))
	return sget(spr % 16 * 8 + sprx, flr(spr / 16) * 8 + spry)
end


movetimeout = 0
function _update()
	local f = ({updateintroscreen, updategame, updategameover, updategameover})[gamestate+1]
	f()
end

function checkaddplayer()
	for p=0,3 do
		if btnp(4, p) and btnp(5, p) then
			for po in all(players) do
				if (po.playerindex == p) goto noplayercreate
			end
			for sp in all(spawning) do
				if (sp == p) goto noplayercreate
			end
			add(spawning, p)
			local x = mapoffset + 32
			for y=58+(p*4), 104 do
				if checkpassable(x, y) then
					newsummon(x, y, 40, 0, function(a)
								  spawnplayer(p, a.x, a.y)
					end)
					added = true
					if (gamestate != 1) music "3"
					gamestate = 1
					return true
				end
			end
			::noplayercreate::
		end
	end
	return false
end

function updateintroscreen()
	local precheckmo = mapoffset + 1
	if (precheckmo >= mapw*8 - 128) precheckmo = 0
	mapoffset = 0
	if checkaddplayer() then
		gamestate = 1
		players = {}
		deadplayers = {}
		actors = {}
		mapoffset = 0
		spawnpositions = {}
		for x,ys in pairs(master_spawnpositions) do
			spawnpositions[x] = {}
			for y,v in pairs(ys) do
				spawnpositions[x][y] = v
			end
		end
	else
		mapoffset = precheckmo
	end
end

function runallupdates()
	foreach(actors, updateactor)
	foreach(staticactors, updateactor)
	foreach(actors, applyvelocity)
	foreach(actors, checklife)
	foreach(staticactors, checkstaticlife)
	foreach(actors, updatesprite)
end

function updategame()
	checkaddplayer()

	if movetimeout == 0 then
		for rawx=mapoffset, mapoffset+152,8 do
			local mapx,mapy = mapposfrompx(rawx, 56)
			for y,s in pairs(spawnpositions[mapx] or {}) do
				if y < mapy+8 then
					spritetospawnfn[s](mapx,y)
					spawnpositions[mapx][y] = nil
				end
			end
		end

		runallupdates()
	else
		movetimeout -= 1
	end

	for p in all(deadplayers) do
		if (p.x < mapoffset - 32) del(deadplayers, p)
	end

	if #players == 0 then
		if (#deadplayers == 0) return
		gamestate = 2
	end

	while #staticactors > 75 do
		del(staticactors, staticactors[1])
	end
end

function updategameover()
	for i=0,1 do
		if btnp(4,i) and btnp(5,i) then
			run()
		end
	end
	runallupdates()
end

function newcreatureat(x,y, attributes)
	local px,py = pxfrommappos(x, y)
	return tupdate(newcreature({x=px+4, y=py+7}), attributes)
end

function sstopalshift(sprite, offset, shiftcount)
	local shift = {}
	for colorpos=offset,offset+((shiftcount-1) * 2),2 do
		shift[coloratsprite(sprite, colorpos % 8, flr(colorpos / 8))] = coloratsprite(sprite, (colorpos+1) % 8, flr((colorpos+1) / 8))
	end
	return shift
end

function newsummon(x, y, life, sprite, completionfn)
	local s = newactor({x = x,
						y = y,
						kind = 3,
						update = updatesummon,
						draw = drawsummon,
						spritebase = sprite,
						lifetime = life,
						completion = completionfn
	})
	add(staticactors, s)
end

function spawnplayer(pidx, x, y)
	for p in all(players) do
		if (p.playerindex == pidx) return
	end
	local p = newcreature({
			x = x,
			y = y,
			kind = 0, -- player
			dv = 0.6,
			hp = 100,
			maxhp = 100,
			spritebase = 0,
			playerindex = pidx,
			palshift =  sstopalshift(196, pidx * 6, 3),
			update = updateplayer,
			damage = function(actor, dhp)
				actor.hp -= dhp
				addhplossscreenshake(dhp)
				if actor.hp <= 0 then
					add(actors,
						newactor({x = actor.x,
								  y = actor.y,
								  kind = 9,
								  palshift = actor.palshift,
								  draw = draw1sprite,
								  spritebase = 31,
								  update = updategravestone,
								  playerindex = actor.playerindex
					}))
					del(players, actor)
					add(deadplayers, actor)
					monstertargets[actor] = nil
					del(actors, actor)
					return
				end

				addhiteffects(actor)
			end,
			score = 0
	})
	add(actors, p)
	add(players, p)
	del(spawning, p)
	return p
end

function spawncreature(x, y, spritebase, hp, dv, pointvalue, statefns, updatefn)
	local adjustedhp = flr(hp * sqrt(max(#players, 1))) 
	local c = newcreatureat(x, y, {
								spritebase = spritebase,
								hp = adjustedhp,
								maxhp = adjustedhp,
								dv = dv,
								statefns = statefns,
								update = function(a) runactorstate(a) end,
								state = asleep,
								w = 8,
								h = 8,
								pointvalue = pointvalue
	})
	add(actors, c)
	return c
end

function newkoboldbase(x,y)
	return spawncreature(x, y, 16, 8, 0.6, 1, {
		[asleep] = koboldsleepstate,
		[waiting] = koboldwaitstate,
		[melee] = koboldmeleestate,
	})
end

function spawnkobold(x, y)
	return newkoboldbase(x, y)
end

function spawnthrowkobold(x, y)
	local k = newkoboldbase(x, y)
	k.palshift = sstopalshift(196, 24, 2)
	k.pointvalue = 2
	k.statefns[waiting] = function(a)
		if (#players == 0) return
		local closestp, closestd = closestplayer(a)
		local dx,dy,distp = dists(a, closestp)
		if distp <= 40 and (abs(dx) > 8 or abs(dy) > 6) then
			a.state = throwing
		elseif abs(dx) <= 8 and abs(dy) <= 6 then
			koboldwaitstate(a)
		else
			movetowards(a, closestp)
		end
	end
	k.statefns[melee] = function(a)
		local meleerangep = nil
		foreach(players, function(p)
			local dx,dy,distp = dists(a, p)
			if abs(dx) <= 8 and abs(dy) <= 6 then
				meleerangep = p
				return
			end
		end)

		if a.windup and a.windup >= 0 or meleerangep then
			koboldmeleestate(a)
		else
			a.state = waiting
		end
	end
	k.statefns[throwing] = function(a)
		if (#players == 0) return
		local closestp, closestd = closestplayer(a)
		if closestd > 40 then
			movetowards(a, closestp)
			return
		end
		
		if a.windup then
			if a.windup > 0 then
				a.windup -= 1
			else
				throwitem(a, closestp, 4, function(s)
							  for p in all(players) do
								  if (not intersects(p,s)) goto continue
								  if checkhits(s, p) then
									  del(actors, s)
									  return
								  end
								  
								  p:damage(2)
								  p:setstun(7)
								  screenshake += 1
								  add(s.hits, p)
								  sfx(4)
								  ::continue::
							  end
											  end, drawstick, 45)
				sfx(5)
			end
		elseif not a.attacktimeout or a.attacktimeout == 0 then
			monsterattacks(a, 30, 15)
		end
	end
	return k
end

function spawnogre(x,y)
	local o = spawncreature(x,y, 48, 100, 0.2, 5, {
		[asleep] = koboldsleepstate,
		[waiting] = function(a) a.state = melee end,
		[melee] = function(a)
			if (#players == 0) return
			local targetp = closestplayer(a)
							
			local dx,dy,distp = dists(a, targetp)
			if a.windup then
				if a.windup >0 then
					a.windup -= 1
				else
					if a.z == 0 then
						foreach(actors, function(other)
							if other != a and other.kind == 1 then
								other.vz += 2
							end
							if other.kind == 0 then
								other.vz += 2
								local odx,ody,disto = dists(a, other)
								if not a.flipsprite then
									odx *= -1
								end
								
								if odx > 0 and odx <= 12 and abs(ody) <= 4 then
									other:setstun(15)
									other:damage(a.damageamt)
								end
							end
						end)
						sfx"7"
						movetimeout = 2
						screenshake += 2
					end
					
					a.windup = nil
				end
			elseif not a.attacktimeout or a.attacktimeout == 0 then
				if abs(dx) <= 12 and abs(dy) <= 4 then
					monsterattacks(a, 45, 5)
					sfx"6"
				else
					movetowards(a, targetp)
				end
			end
		end
	})
	return tupdate(o, {h = 16,
					  mass = 2,
					  maxhp = 75,
					  draw = drawogre,
					  setstun = ogrestun,
					  damageamt = 15
	})
end

function spawnredogre(x, y)
	return(tupdate(spawnogre(x, y), {
					   pointvalue = 15,
					   maxhp = 160,
					   damageamt = 30,
					   palshift = sstopalshift(196, 28, 4)
	}))
end

function spawnsoldier(x,y)
	local s = spawncreature(x, y, 7, 8, 0.4, 3, {
		[asleep] = koboldsleepstate,
		[waiting] = function(a)
			if (#players == 0) return
			local vx, vy, vz = a.vx, a.vy, a.vz
			koboldwaitstate(a)
			
			if a.state == waiting then
				a.vx, a.vy, a.vz = vx, vy, vz
				
				local targetp = closestplayer(a)			
				local dest = a.index % 4 -- map to n/s/e/w
				local destx, desty = targetp.x, targetp.y
				if (dest == 0) desty -= 20 -- north
				if (dest == 1) desty += 20 -- south
				if (dest == 2) destx -= 20 -- east
				if (dest == 3) destx += 20 -- west
				movetowardspoint(a, destx, desty)
			end
		end,
		[melee] = koboldmeleestate,
	})
	s.setstun = function(actor, time)
		if actor.vz > 0 or actor.stuntime > 0 then
			actor.stuntime += time
			sfx"9"
			goto finally
		end
		if not actor.hitcount or actor.lasthitframe - frame > 15 then
			actor.hitcount = 0
		end
		actor.hitcount += 1
		
		if actor.hitcount >= 3 or time > 15 then
			tupdate(actor,
					{stuntime = 40,
					 hitcount = 0,
					 windup = nil,
					 attack = nil})
			sfx"9"
		end

		::finally::
		actor.lasthitframe = frame
		actor.state = waiting	
	end
	s.damage = function(actor, dhp)
		if not actor.stuntime or actor.stuntime == 0 then
			dhp = max(dhp - 7, 0)
		end
		if dhp > 0 then
			basicdamage(actor, dhp)
		end
	end

	return s
end

function shouldnthit(a, b)
	return checkhits(a, b) or not intersects(a, b)
end

function spawngoat(x, y)
	local i = spawncreature(x, y, 32, 4, 0.5, 3, {
		[asleep] = koboldsleepstate,
		[waiting] = function(a)
			a.friction = 0.3
			if a.dest then
				a.friction = 0.9
			elseif a.vx < 0.1 and a.vy < 0.1 then
				local targetp = players[frnd(#players) + 1]
				if (not targetp) return
				local x = mapoffset + ((a.x > mapoffset+64) and 10 or 118)
				local o = atan2(a.x - targetp.x, a.y - (targetp.y + 2))		
				a.dest = {x, (targetp.y + 2) + (-1 * sin(o) * (cos(o) / (a.x - x)))}
			else
				return
			end
			
			local hittableplayer = false
			if abs(a.vx) + abs(a.vy) >= 3 then
				local p = closestplayer(a)
				if p then
					local dx = p.x - a.x
					hittableplayer = (abs(a.y - p.y) < 4 and sgn(dx) == sgn(a.vx) and abs(dx) <= 10)
				end
			end
						
			if hittableplayer or (abs(a.x - a.dest[1]) <= 20) then
				tupdate(a, {state = throwing,
						   attacking = true,
						   windup = 0,
						   vz = a.vz + 2
				})
				a.dest = nil
				return
			end

			movetowardspoint(a, a.dest[1], a.dest[2])

			local nextx = a.x + 1
			local nexty = a.y + 1
			if (a.vx < 0) nextx -= 2
			if (a.vy < 0) nexty -= 2
			if (not checkpassable(nextx, nexty)) a.dest = nil
		end,
		[throwing] = function(a)
			if a.z == 0 then
				a.state = sliding
				a.attacking = false
				a.hits = nil
				sfx(12)
				return
			end
			foreach(players, function(p)
				if (shouldnthit(a, p)) return
				
				p:damage((a.vx+a.vy)^2)
				add(a.hits, p)
				sfx"13"
			end)
		end,
		[sliding] = function(a)
			a.friction = 0.8
			if a.vx <= 0.1 and a.vy <= 0.1 then
				a.state = waiting
				a.stuntime = 20
			end
		end
	})
	i.draw = function(actor)
		if (actor.state == throwing) actor.sprite = actor.spritebase + 5
		if (actor.state == sliding)	actor.sprite = actor.spritebase + 6
		draw1sprite(actor)
	end

	return i
end


function spawndrake(x, y)
	local d = spawnthrowkobold(x, y)
	d.spritebase = 23
	d.pointvalue = 4
	d.palshift = {}
	d.statefns[throwing] = function(a)
		if a.windup then
			if a.windup > 0 then
				a.windup -= 1
			else
				local targetp = players[frnd(#players) + 1]
				-- may be nil if all players just died
				if targetp then
					throwitem(a, targetp, 5,
							  function(f)
								  for p in all(players) do
									  if not shouldnthit(f, p) then
										  p:damage(10)
										  p:setstun(5)
										  add(f.hits, p)
									  end
								  end
							  end, drawflame, 120)
					sfx(10)
				end
			end
		elseif not a.attacktimeout or a.attacktimeout == 0 then
			monsterattacks(a, 60, 30)
			sfx"11"
		end
	end
	return d
end

function spawnhealer(x, y)
	local c = newcreatureat(x, y,
							{kind = 9,
							 spritebase = 63,
							 update = updatehealer})
	add(actors, c)
	return c
end

function spawnevilwzrd(x, y)
	music "6"
	local function hppct(a) return a.hp/a.maxhp end
	local function level(a) return flr(a.x / 1024) end
	local function cast(kind, sprite, vecfn, placefn)
		return function(a)
			a.attack = nil
			a.state = waiting
			
			local intensity = min((5 + level(a)) / hppct(a), 10 + level(a))
			for i=1,intensity do
				local attack = newactor({kind = kind,
										 flipsprite = (frnd"2" == 0),
										 friction = 1,
										 solid = false,
										 layer = 1,
										 spritebase = sprite,						 
										 draw = draw1sprite,
										 y = rnd"40" + 56,
										 update = function(atk)
											 for p in all(players) do
												 if not shouldnthit(atk, p) then
													 vecfn(atk, p)
													 p:damage(intensity)
													 add(atk.hits, p)
												 end
											 end
											 if ((atk.z > 32) or (atk.flipsprite and atk.x < mapoffset - 8) or (not atk.flipsprite and atk.x > mapoffset + 128)) del(actors, atk)
										 end
				})
				placefn(attack)
				newsummon(attack.x, attack.y, 45 - intensity, sprite, function(a) add(actors, attack) end)
			end
		end
	end

	local function wzrdmovestate(a)
		if simpledist(a, a.dest) < 10 then
			a.friction = 0.01
			a.solid = true
			a.state = melee
		else
			a.solid = false
			movetowardspoint(a, a.dest.x, a.dest.y)
		end
	end

	local w = spawncreature(x, y, 0, 100, 5, 1000, {
		[asleep] = koboldsleepstate,
		[waiting] = function(a)
			offsetlock = true
			if (not a.movetimer) a.movetimer = 60 + 60 * hppct(a)
			if a.attack then
				a.attack = nil
				a.movetimer = 1
			end
			a.movetimer -= 1
			if a.movetimer <= 0 then
				a.dest = {x = rnd"96" + 16 + mapoffset,
						  y = rnd"24" + 60}
				a.friction = 0.9
				a.state = moving
				a.movetimer = nil
			end
		end,
		[moving] = wzrdmovestate,
		[melee] = function(a)			
			if (#players == 0) return
			if (not a.attack) a.attack = {chargetime = 0, level = mklevel(10 * hppct(a), 30 * hppct(a))}
			a.attack.chargetime += 1
			
			if (a.attack.chargetime > 30 * hppct(a) + 15) a.state = ({castingpunch, castingkick, summoncreatures})[1+(frnd(2+level(a)) % 3)]
		end,
		[castingpunch] = cast(7, 14,
							  function(atk, player)
								  player.vx += atk.vx * 3
							  end,
							  function(atk)
								  atk.x = mapoffset + (atk.flipsprite and 120 or 8)
								  atk.vx = atk.flipsprite and -1.5 or 1.5
							  end
		),
		[castingkick] = cast(8, 15,
							 function(atk, player)
								 player.vx += (atk.flipsprite and -1 or 1)
								 player.vz += 3
							 end,
							 function(atk)
								 atk.vz = 3
								 atk.x = rnd"112" + mapoffset + 8
							 end
		),
		[summoncreatures] = function(a)
			a.attack = nil
			a.state = waiting

			local intensity = (1 + level(a)) * hppct(a)
			for i=1,intensity do
				local idx = min(1+frnd(2+level(a)), 5)
				local sprs = {16, 16, 7, 32, 23}
				local x = rnd"112" + mapoffset + 8
				local y = rnd"40" + 56
				while x < mapoffset+128 do
					if (checkpassable(x, y)) break
					x+=1
				end
				if x <= mapoffset+128 then
					newsummon(x, y, 45-intensity, sprs[idx],
							  function(a)
								  local k = ({
										  spawnkobold,
										  spawnthrowkobold,
										  spawnsoldier,
										  spawngoat,
										  spawndrake })[idx](0,0)
								  k.x = a.x
								  k.y = a.y
								  k.state = waiting
					end)
				end
			end
		end,
		[escaping] = function(a)
			a.solid = false
			wzrdmovestate(a)
			if a.state == melee then
				offsetlock = false
				othersong = not othersong
                                music(othersong and "8" or "3")
				del(actors, a)
			end
		end,
	})
	w.palshift = sstopalshift(212, 0, 5)
	w.damage = function(actor, dhp)
		if (actor.state == moving or actor.state == escaping) return
		if (actor.movetimer) actor.movetimer = flr(actor.movetimer / 2)

		local level = flr(mapoffset / 1024)

		if actor.hp - dhp <= 0 then
			if level < 4 then
				actor.dest = {x = mapoffset+138, y = actor.y}
				actor.state = escaping
				if #players > 0 then
					for p in all(players) do
						p.score += (level+1)*100
					end
				end
			else
				addhiteffects(actor)
				del(actors, actor)
				gamestate = 3
			end
		else
			basicdamage(actor, dhp)
		end
	end
	w.setstun = function(a, stuntime) end
	w.movetimer = 1 -- make the wizard move immediately upon waking
	return w
end

function updateactor(a)
	if (a.update and (not a.stuntime or a.stuntime == 0)) a:update()
end

function updateplayer(p)
	local l = p.attack and flr(p.attack:level()) or 1
	local dvx = p.dv / l
	local dvy = p.dv / (2*l)
	
	local a = nil
	local function makeattack(kind, spritebase, attacktimeout, levelfn, updatefn, releasebody)
		return { kind = kind,
				 chargetime = 1,
				 level = levelfn,
				 release = function(attack, player)
					 local dmg = copyactor(player, false)
					 tupdate(dmg,
							 {kind = 2, -- spell
							  draw = draw1sprite,
							  x = dmg.x + (dmg.flipsprite and -2 or 2),
							  friction = 1,
							  solid = false,
							  layer = 1,
							  level = flr(attack:level()),
							  spritebase = spritebase,
							  update = updatefn,
							  player = player,
					 })
					 dmg.moveframe = nil
					 player.attacking = true
					 player.attacktimeout = attacktimeout			
					 releasebody(dmg, player)
					 return dmg
				 end,
		}
	end

	local buttonfns = {
		function() -- button 0
			p.vx -= dvx
			p.flipsprite = true
		end,
		function()
			p.vx += dvx
			p.flipsprite = false
		end,
		function()
			p.vy -= dvy
		end,
		function()
			p.vy += dvy
		end,
		function() -- button 4
			a = makeattack(7, 14, 5, mklevel(7, 15),
						   function(player)
							   updateplayerattack(player, 3 * player.level, 0,
												  2 * (player.level ^ 2), 10 * player.level)
						   end,
						   function(attack, player)	   
							   attack.vx += 1 * attack.level * (attack.flipsprite and -1 or 1)
							   attack.vy = 0
							   attack.lifetime = attack.level + 4
			end)
		end,
		function() -- button 5
			a = makeattack(8, 15, 7, mklevel(10, 30),
						   function(k)
							   updateplayerattack(k, k.level, 4 * k.level,
												  4 * (k.level ^ 2), 20 * k.level)
						   end,
						   function(attack, player)
							   attack.x += (player.flipsprite and -4 or 4)
							   attack.vz = player.vz + (2.5*attack.level)
							   attack.lifetime = attack.level
			end)
		end,		
	}

	for i=1,6 do
		if (btn(i-1, p.playerindex)) buttonfns[i]()
	end

	-- attacks
	if p.attacktimeout and p.attacktimeout > 0 then
		p.attacktimeout -= 1
		return
	end

	if not a and p.attack or p.attack and a and a.kind != p.attack.kind then
		local dmg = p.attack:release(p)
		add(actors, dmg)
		addsparkle(dmg)
		sfx(flr(p.attack:level()))
		p.attack = nil
		return
	end
	if (p.attack and a.kind == p.attack.kind) p.attack.chargetime += 1
	if (not p.attack and a) p.attack = a
end

function mklevel(t2, t3)
	return function(atk)
		local ct = atk.chargetime
		if (ct < t2) return 1 + (ct / t2)
		if (ct < t3) return 2 + ((ct - t2) / (t3-t2))
		return 3
	end
end

function addsparkle(attack)
	add(actors, tupdate(copyactor(attack, false),
						{layer = 2,
						 lifetime = attack.lifetime + 3,
						 draw = drawsparkle}))
end

function simpledist(a1, a2) 
	local dx, dy, dist = dists(a1, a2)
	return dist 
end

function dists(a1, a2)
	local dx = a1.x - a2.x
	local dy = a1.y - a2.y
	local dist = sqrt(dx^2 + dy^2)
	return dx,dy,dist
end

function checkhits(attack, actor)
	if (not attack.hits) attack.hits = {}

	for hit in all(attack.hits) do
		if (actor == hit) return true
	end
	return false
end

function updateplayerattack(atk, vx, vz, dmg, stuntime)
	foreach(actors, function(a)
		if (a == atk or shouldnthit(atk, a)) return
		if a.kind == 4 or a.kind == 7 then
			a.vx *= -1
			sfx"15"
		elseif a.kind == 1 then
			a.vx = (atk.flipsprite and -1 or 1) * vx / a.mass
			a.vz += vz / a.mass
			atk.player.score += (atk.level-1) * #atk.hits
			a:damage(dmg)
			if (a.hp == 0) atk.player.score += a.pointvalue
			a:setstun(stuntime)
			sfx"0"
		end	
		add(atk.hits, a)
	end)
end 

lastclosestmonster = {}
lastclosestread = nil
function closestavailablemonster(player)
	if frame == lastclosestread then
		if (lastclosestmonster[player]) return lastclosestmonster[player]
	else
		lastclosestmonster = {}
		lastclosestread = frame
	end
	local mindist = 10000
	local minactor = nil
	foreach(actors, function(a)
		if a.kind == 1 and a.state == waiting then
			local distp = simpledist(a, player)
			if mindist >= distp then
				mindist = distp
				minactor = a
			end
		end
	end)
	lastclosestmonster[player] = minactor
	return minactor
end

function closestplayer(actor)
	local closestp = nil
	local closestd = 32768
	foreach(players, function(p)
		local distp = simpledist(actor, p)
		if not closestp or distp < closestd then
			closestp = p
			closestd = distp
		end
	end)
	return closestp, closestd
end

function koboldsleepstate(a)
	if (a.x > (mapoffset + 128) or a.x < mapoffset) return
	foreach(players, function(p) 
		if abs(p.x - a.x) < 64 then
			a.state = waiting
			return
		end
	end)
end

function cleartargeter(a)
	for p, m in pairs(monstertargets) do
		if (m == a) monstertargets[p] = nil
	end
end

function koboldwaitstate(a)
	cleartargeter(a)
	if (#players == 0) return
	local closestp, closestd = closestplayer(a)
	for p in all(players) do		
		if abs(a.x - p.x) <= 8 and abs(a.y - p.y) <= 6 then
			monstertargets[p] = a
			a.state = melee
			return
		end
		if (monstertargets[p] and monstertargets[p] != a) goto continue

		if a == closestavailablemonster(p) and p == closestp then
			monstertargets[p] = a
			a.state = melee
			return
		end
		::continue::
	end

	if (closestd > 42) movetowards(a, closestp)
end

function gettargetp(a)
	for p, m in pairs(monstertargets) do
		if (a == m) return p
	end
	return nil
end

function monsterattacks(monster, timeout, winduptime)
	monster.attacking = true
	monster.attacktimeout = timeout
	monster.windup = winduptime
end

function koboldmeleestate(a)
	local targetp = gettargetp(a)
	if not targetp then
		a.state = waiting
		return
	end
	local dx,dy,distp1 = dists(a, targetp)
	if a.windup then
		if a.windup >0 then
			a.windup -= 1
		else
			if abs(dx) <= 8 and abs(dy) <= 6 then
				targetp.vx -= sgn(dx) * 3
				targetp:setstun(3)
				targetp:damage(3)
				sfx"4"
			end
			a.windup = nil
			a.state = waiting
		end
	elseif abs(dx) <= 8 and abs(dy) <= 6
		and (not a.attacktimeout
			 or a.attacktimeout == 0) then
			monsterattacks(a, 30, 6)
	else
		if (abs(dx) > 8 or abs(dy) > 6)	movetowards(a, targetp)
	end
end

function runactorstate(actor)
	if (not actor.state) return

	if (actor.attacktimeout and actor.attacktimeout > 0) actor.attacktimeout -= 1

	if actor.stuntime and actor.stuntime > 0 then
		actor.state = waiting
		return
	end

	actor.statefns[actor.state](actor)
end

function throwitem(actor, targetp, kind, updatefn, drawfn, timeout)
	local o = atan2(targetp.x - actor.x, targetp.y - actor.y)
	local p = tupdate(copyactor(actor, true),
					 {kind = kind,
					  solid = false,
					  vx = cos(o) * 3,
					  vy = sin(o) * 3,
					  friction = 1,
					  update = updatefn,
					  draw = drawfn
	})
	add(actors, p)
	actor.windup = nil
	actor.state = waiting
	actor.attacktimeout = timeout
end

function updategravestone(a)
	if (not a.remainingrescharge) a.remainingrescharge = 85
	
	for p in all(players) do
		if (p.playerindex == a.playerindex or not p.attack) return
		if (simpledist(a, p) > 16) return
		a.remainingrescharge -= p.attack:level()
	end

	if a.remainingrescharge <= 0 then
		newsummon(a.x, a.y, 20, 0, function()
					  local p = spawnplayer(a.playerindex, 0, 0)
					  p.x = a.x
					  p.y = a.y
					  foreach(deadplayers, function(other)
								  if (other.playerindex == a.playerindex)	del(deadplayers, other)
					  end)
		end)
		del(actors, a)
		sfx"14"
	end
end

function updatehealer(a)
	if (not a.ticks) a.ticks = {}
	for p in all(players) do
		if (not p.attack) return
		if a.ticks[p] and a.ticks[p] > 0 then
			a.ticks[p] -= 1
			return
		end
		
		if (abs(p.x-a.x) > 6 or abs(p.y-a.y) > 4) return

		local h = flr(p.attack:level())
		a.ticks[p] = flr(30 / h)
		p.hp = min(p.hp + h, p.maxhp)
		sfx"8"
		add(staticactors,
			tupdate(copyactor(p, true),
					{num = h,
					 lifetime = 15,
					 draw = drawhealnum}))
		
	end
end

function updatesummon(a)
	if (a.lifetime == 0) a:completion()
end

function stun(actor, time)
	actor.stuntime = time
	actor.windup = nil
	actor.attack = nil
	actor.dest = nil
	actor.state = actor.state and waiting
end

function ogrestun(actor, time)
	if (not actor.yelltime) actor.yelltime = 0	
	actor.yelltime += 5
end



function basicdamage(actor, dhp)
	actor.hp = max(0, actor.hp - dhp)
	add(staticactors,
		tupdate(copyactor(actor, true),
				{num = dhp,
				 lifetime = 15,
				 draw = drawdamagenum}))
	addhiteffects(actor)
	addhplossscreenshake(dhp)
	if (actor.hp == 0) del(actors, actor)
	for p, m in pairs(monstertargets) do
		if (monstertargets[p] == actor) monstertargets[p] = nil
	end
end

function movetowards(actor, player)
	movetowardspoint(actor, player.x, player.y)
end

function movetowardspoint(actor, destx, desty)
	if actor.z > 0 then return end
	local dx = actor.x - destx
	local dy = actor.y - desty
	-- local distp = sqrt(dx^2 + dy^2)

	if sqrt(dx^2 + dy^2) > 4 then -- if distp > 4 then -- golf :/
		local o = atan2(dx, dy)
		local pvx = cos(o) * actor.dv
		local pvy = sin(o) * actor.dv
		actor.vx -= pvx
		actor.vy -= pvy
		if dx > 4 then			
			actor.flipsprite = true
		elseif dx < -4 then
			actor.flipsprite = false
		end
	end
end

function intersects(a, b)
	return a.layer == b.layer
		and abs(a.x - b.x) <= 4
		and abs(a.y - b.y) <= 4
		and abs(a.z - b.z) <= max(a.h, b.h)
end

function checkpassable(x,y, w)
	if (not w) w = 4
	for i=x-w/2,x+w/2 do
		local mapx,mapy = mapposfrompx(i, y)				
		local f = passable[mget(mapx, mapy)]
		if (f) return f(i, y)
	end
	return true
end

function applyvelocity(actor)
	local nextx = actor.x + actor.vx
	local nexty = actor.y + actor.vy
	local nextz = actor.z + actor.vz
	local nextvx = actor.vx
	local nextvy = actor.vy
	local nextvz = actor.vz
	if actor.solid then
		if flr(nextx) != flr(actor.x) then
			if not checkpassable(nextx, actor.y) then
				nextx = actor.x
				nextvx = 0
			end
		end
		if flr(nexty) != flr(actor.y) then
			if not checkpassable(actor.x, nexty) then
				nexty = actor.y
				nextvy = 0
			end
		end
	else
  if actor.kind != 1 and (nexty >= 104 or nexty <= 56 or nextx <= 0 or nextx > mapw*8) then
			del(actors, actor)
			return
		end
	end

	if actor.friction and actor.z == 0 then
		nextvy *= actor.friction
		nextvx *= actor.friction
	end
	if (abs(nextvx) < 0.001) nextvx = 0
	if (abs(nextvy) < 0.001) nextvy = 0

	local xchg = flr(actor.x) != flr(nextx)
	local ychg = flr(actor.y) != flr(nexty)

	actor.x = nextx
	actor.y = nexty
	if (actor.kind == 0) actor.x = mid(nextx, mapoffset, mapoffset + 127)
	if (actor.solid) actor.y = mid(nexty, 56, 104)

	if nextz <= 0 then
		local p = flr(abs(nextvz) * actor.mass)
		if (p > 4 and actor.hp) actor:damage(p)
		nextz = 0
		nextvz = 0
	elseif actor.kind != 8 then
		nextvz -= 0.8
	end
	
	actor.z = nextz

	if actor.kind == 1 then
		foreach(actors, function(a)
			if ((a == actor) or (a.kind != 1) or (a.z != actor.z)) return
			local dx = a.x - actor.x
			local dy = a.y - actor.y
			if abs(dx) < 3 and abs(dy) < 2 then
				nextvx -= sgn(dx) * 0.4
				nextvy -= sgn(dy) * 0.2
			end
		end)
	end
	
	if actor.moveframe then
		if nextvy == 0 and nextvx == 0 then
			actor.moveframe = -1
		elseif (nextvy != 0 or nextvx != 0) and actor.moveframe == -1 then
			actor.moveframe = 0
		elseif xchg or ychg then
			actor.moveframe = actor.moveframe + 0.5
		end
	end
	
	actor.vx = nextvx
	actor.vy = nextvy
	actor.vz = nextvz
end

function checklife(actor)
	if actor.lifetime then
		if (actor.lifetime <= 0) del(actors, actor)
		actor.lifetime -= 1
	end
	if (actor.stuntime and actor.stuntime > 0) actor.stuntime -= 1
end

function checkstaticlife(actor)
	if actor.lifetime then
		if (actor.lifetime <= 0) del(staticactors, actor)
		actor.lifetime -= 1
	end
	if (actor.kind == 3 and abs(mapoffset - actor.x) > 500) del(staticactors, actor)
end

function updatesprite(actor)
	if (not actor.spritebase) return
	local offset = 0
	if actor.stuntime and actor.stuntime > 0 then
		offset = 6
	elseif actor.moveframe and actor.moveframe >= 0 then
		offset = 1 + (flr(actor.moveframe) % 3)
	elseif actor.attacking and actor.windup and actor.windup > 0 then
		offset = 4
	elseif actor.attacking and actor.windup == 0 then
		offset = 5
	end
	actor.sprite = actor.spritebase + offset
end

function addhiteffects(actor)
	movetimeout = 4

	e = copyactor(actor, false)
	e.kind = 3
	
	if actor.hp > 0 then
		e.layer = 2
		e.lifetime = 2
		e.draw = drawhit
		if (not actor.undamageddraw) actor.undamageddraw = actor.draw		
		actor.draw = drawdamaged
	else
		e.layer = 1
		e.lifetime = nil
		e.friction = 0.75
		e.draw = drawgib
	end
	add(staticactors, e)
end

function addhplossscreenshake(hploss)
	if (hploss >= 12) screenshake += hploss / 6
	screenshake = min(7, screenshake)
end

frame = 0
screenshake = 0
mapoffsetvx = 0
function _draw()
	frame += 1
	drawgame()
	local f = ({drawintro, drawgame, drawgameover, drawwin})[gamestate+1]
	f()
end

function drawintro()
	rectfill(0, 0, 128, 38, 0)
	runpalshift(sstopalshift(196, 18, 3))
	spr(0, 4, 26)
	pal()
	color(15)
	cursor(16,22)
	print "the dark wzrd has stolen the"
	print "amulet of yendor! to return "
	print "it we'll need to call the..."
	
	sspr(0, 96, 32, 16, 16, 48, 96, 48)
	
	restarttext()
	
	centertext("by ryan forsythe", 117, 13)
	centertext("with music by jesse wolfe", 123, 13)
end

function restarttext() centertext("push ❎ and 🅾️ to start", 105, 15) end

function centertext(text, y, textcolor)
	print(text, (128 - #text*4) / 2, y, textcolor)
end

function drawgameover()
	spr(201, 48, 53, 4, 3)
	restarttext()
end

function drawwin()
	spr(205, 52, 53, 3, 3)
	rectfill(0, 76, 128, 104, 0)
	cursor(4, 77)
	color(15)
	print"grasping the amulet of yendor,"
	print" you begin a campaign to take"
	print" over the world. you were the"
	print"    monster the whole time."
	restarttext()
end

maprowpalshifts = {
	nil,
	sstopalshift(196, 36, 7),
	sstopalshift(196, 50, 7),
	sstopalshift(212, 10, 7),
}
offsetlock = false
maxoffset = 0
function drawgame()
	local playercount = #players
	local center = 64
	local avg = 0
	local minp = 32767
	local maxp = 0
		
	if not offsetlock and playercount > 0 then
		local xaccum = 0
		local dirvote = 0
		for p in all(players) do
			local sp = p.x - mapoffset
			minp = min(minp, p.x)
			maxp = max(maxp, p.x)
			xaccum += sp
			dirvote += (p.flipsprite and -1 or 1)
		end
		
		if (dirvote > 0) center = 44
		if (dirvote < 0) center = 84
		avg = xaccum / playercount
		local move = (avg - center) / 15
		if abs(move) > 0.1 then
			move = max(abs(move), 1) * sgn(move)
		end
		
		local next = mapoffset + move
		if next < 0 or
				next > minp - 4 or
				next < maxp - 120 or
				next < maxoffset - 32 then
			next = mapoffset
		end
		mapoffset = next
		maxoffset = max(mapoffset, maxoffset)
	end

	-- camera and camera shaking
	local shakex = 0
	local shakey = 0
	if screenshake > 0 then
		shakex = 3-rnd"6"
		shakey = 3-rnd"6"
		screenshake -= 1
	end
	camera(mapoffset+shakex, shakey)

	--drawmap()
	rectfill(mapoffset, 40, mapoffset+128, 56, 1)
	for x=0,mapw,128 do
		local row = flr(x/128)
		local remaining = min(mapw-x, 128)
		map(0, row*8, row*1024, 40, remaining, 2)
		local shift = maprowpalshifts[row+1]
		if (shift) runpalshift(shift)
		map(0, row*8 + 2, row*1024, 56, remaining, 6)
		pal()
	end
	
	--drawactors()
	local drawn = {}
	local drawtest = function(actor)
		if (actor.draw and (actor.x > mapoffset - 40) and (actor.x < mapoffset+168)) add(drawn, actor)
	end
	foreach(actors, drawtest)
	foreach(staticactors, drawtest)
	heapsort(drawn, actorsort)
	foreach(drawn, function(a) a:draw() end)
	
	--drawwaterfalls()
	local minpx = 32767
	local maxpx = -1
	local palshift = {}

	for cx=tocell(mapoffset-7), tocell(mapoffset + 127) do
		if waterfalllocs[cx] then
			local px = 8 * cx
			minpx = min(px, minpx)
			maxpx = max(px+8, maxpx)
			palshift = maprowpalshifts[flr(cx / 128)+1] or {}
			for y=40,55 do
				local waterfallrow = waterfallrows[1 + ((px + y - flr(frame)) % #waterfallrows)]
				for x=px,px+8 do
					local c = palshift[1] or 1
					if (waterfallrow[1 + (x % #(waterfallrow))]) c = palshift[12] or 12
					pset(x,y,c)
				end
			end
		end
	end

	-- draw spray
	if maxpx != -1 then
		for y=49,59 do
			local d = 56-y
			for x=minpx - d - 2, maxpx + d + 2 do
				if (frnd(max(1, abs(d) * 4)) < 3) pset(x,y, palshift[7] or 7)
			end
		end
	end

	camera()
	rectfill(0, 0, 128, 39, 0)
	rectfill(0,104, 128, 128, 0)
	spr(192, 48, 4, 4, 2)

	for pidx=0,3 do
		--drawplayerinfo(i)
		local p = nil
		local findfn = function(a) if (a.playerindex == pidx) p = a end
		foreach(players, findfn)
		foreach(deadplayers, findfn)	
		
		local xoff = pidx * 32
		spr(197, xoff, 23, 4, 2)
		runpalshift(sstopalshift(196, pidx * 6, 3))
		
		print((pidx+1).."UP", xoff, 23, 2)
		local textindent = xoff+14
		if not p then
			local s1 = "game"
			if gamestate == 1 then
				s1 = "hold"
				print("❎+🅾️", textindent - 4, 32, 13)
			elseif gamestate == 2 then
				print("over", textindent, 32, 13)
			else
				s1 = ""
			end
			print(s1, textindent, 26, 13)
		else
			local s = (min(9999, p.score))..""
			print(s, xoff+(30 - (#s * 4)), 26, 13)
			local sprite = 31
			if p.hp == 0 then
				print("dead", textindent, 32, 1)
			else
				sprite = 0
				local pips = 20 * p.hp / p.maxhp
				for i=1, 20, 2 do
					line(xoff+9+i, 32, xoff+9+i, 36, (i > pips) and 6 or 8)
				end
			end
			spr(sprite, xoff+1, 30)
		end
		
		pal()
	end
end

function runpalshift(shifts)
	for a,b in pairs(shifts) do
		pal(a,b)
	end
end

function actorsort(a,b)
	local d = (a.y + (a.layer * 128)) - (b.y + (b.layer * 128))
	if (d == 0) return a.index - b.index
	return d
end

-- props to overkill: http://www.lexaloffle.com/bbs/?pid=18374#p18374
function heapsort(t, cmp)
	local n = #t
	if (n <= 1) return
	
	local lower = flr(n / 2) + 1
	local upper = n
	while 1 do
		local i, j, temp
		if lower > 1 then
			lower -= 1
			temp = t[lower]
		else
			temp = t[upper]
			t[upper] = t[1]
			upper -= 1
			if upper == 1 then
				t[1] = temp
				return
			end
		end

		i = lower
		j = lower * 2
		while j <= upper do
			if (j < upper and cmp(t[j], t[j+1]) < 0) j += 1
			if cmp(temp, t[j]) < 0 then
				t[i] = t[j]
				i = j
				j += i
			else
				j = upper + 1
			end
		end
		t[i] = temp
	end
end

function drawoutline(sprite, sprx, spry, flip)
	for i=1,15 do
		pal(i,1)
	end
	
	for x=sprx-1,sprx+1 do
		for y=spry-1,spry+1 do
			spr(sprite, x, y, 1, 1, flip, false)
		end
	end
	pal()
end

function drawshadow(actor)
	local level = flr(actor.x / 1024)
	palt(0, false)
	palt(14, true)
	if ((level == 1) or (level == 2)) pal(5, 2)
	spr(62, actor.x-4, actor.y-6-actor.z)
	pal()	
end

function draw1sprite(actor)
	local sprx = actor.x-4
	local spry = actor.y-8-actor.z
	
	drawshadow(actor)
	drawoutline(actor.sprite, sprx, spry, actor.flipsprite)
	runpalshift(actor.palshift)
	spr(actor.sprite, sprx, spry, 1, 1, actor.flipsprite)
	pal()
	
	if actor.attack then
		local xadj = actor.flipsprite and -4 or 3
		pset(actor.x+xadj, actor.y-6, 1+(frame % 15))

		local level = actor.attack:level()

		function fillcircle(circlevel, pxs, basecolor, fullcolors)
			local rem = max(level - circlevel, 0)
			local count = min(#pxs * rem, #pxs)
			
			for i=1,count do
				local pt = pxs[i]
				local c = (count == #pxs) and fullcolors[frnd(#fullcolors) + 1] or basecolor
				xadj = actor.flipsprite and -8 or -1
				pset(actor.x+pt[1]+xadj, actor.y+pt[2]-10, c)
			end
		end

		fillcircle(1, l2chargepxs, 11, {3,11})
		fillcircle(2, l3chargepxs, 9, {9,8})
	end

	if actor.stuntime and actor.stuntime != 0 then
		for i=0,3 do
			local x = actor.x + (3*cos((actor.stuntime + (4*i)) / 16))
			local y = spry - 2 + (sin((actor.stuntime + (4*i))/ 16))
			pset(x, y, 10)
		end
	end
end

function drawogre(actor)
	local normalhead = 46
	local winduphead = 47
	local yellhead = 30

	local head = normalhead
	if actor.yelltime and actor.yelltime > 0 then
		actor.yelltime -= 1
		head = yellhead
	elseif actor.attacking and actor.windup and actor.windup > 0 then
		head = winduphead
	end
	local body = actor.sprite
	local club = nil
	if actor.attacktimeout and actor.attacktimeout > 0 and (not actor.windup or actor.windup <= 0) then
		body = 53
		club = 54
	end
	
	local sprx = actor.x-4
	local sprbodyy = actor.y-8-actor.z
	local sprheady = actor.y-16-actor.z
	local sprclubx = sprx + (actor.flipsprite and -8 or 8)
	drawshadow(actor)
	drawoutline(body, sprx, sprbodyy, actor.flipsprite)
	drawoutline(head, sprx, sprheady, actor.flipsprite)
	if (club) drawoutline(club, sprclubx, sprbodyy, actor.flipsprite)
	pal()
	runpalshift(actor.palshift)
	spr(body, sprx, sprbodyy, 1, 1, actor.flipsprite)
	spr(head, sprx, sprheady, 1, 1, actor.flipsprite)
	if club then
		spr(club, sprclubx, sprbodyy, 1, 1, actor.flipsprite, false)
	end
	pal()
end

function drawsparkle(actor)
	local sprx = actor.x-4
	local spry = actor.y-8-actor.z

	for i=1,2 do
		local x = sprx + frnd"8"
		local y = spry + frnd"8"
		local c = 9
		if frnd"2" == 1 then
			c = 10
		end
		pset(x, y, c)
	end
end

function drawgib(actor)
	if not actor.particles then
		actor.particles = {}
		for i=1,16 do
			local avx = actor.vx
			if abs(avx) < 0.1 then
				avx -= frnd "1"
			else
				avx += frnd "1"
			end
			add(actor.particles, {
					x = actor.x + (4-frnd"8"),
					vx = avx,
					y = actor.y + (3-frnd"6"),
					vy = actor.vy,
					z = actor.z + frnd"8",
					vz = actor.vz,
					c = (frnd"4" == 0) and 6 or 8,
			})
		end
		actor.vx = 0
	end
	local allgrounded = true
	foreach(actor.particles, function(p)
		if p.z > 0 then
			p.x += p.vx
			p.y += p.vy
			p.z += p.vz
			p.z = max(0, p.z)
			p.vz -= 0.8
			p.vx *= 0.7
			p.vy *= 0.7
			allgrounded = false
		else
			-- remove all gibs which land on a impassable location; only do this while some gibs are still moving
			if not checkpassable(p.x, p.y, 0) then
				del(actor.particles, p)
				return
			end
		end
		
		line(p.x, p.y-p.z, p.x+p.vx, p.y-p.z, p.c)
	end)
	if (allgrounded) actor.layer = 0
end

function drawhit(actor)
	local sprx = actor.x-4
	local spry = actor.y-8-actor.z

	if (not actor.hitloc) actor.hitloc = 2 + frnd"4"
	
	y = spry + actor.hitloc
	x = actor.x
	line(x-2, y, x+2, y, 10)
	line(x, y-2, x, y+2, 10)
end

function drawdamaged(actor)
	local sprx = actor.x-4
	local spry = actor.y-8-actor.z

	if actor.sprite != nil then
		for i=0,15 do
			pal(i,7)
		end
		spr(actor.sprite, sprx, spry, 1, 1, actor.flipsprite)
		pal()
		actor.draw = actor.undamageddraw
	end
end

function drawdamagenum(actor)
	drawfloatingnum(actor, {10, 9, 8})
end

function drawhealnum(actor)
	drawfloatingnum(actor, {12, 13, 1})
end

function drawfloatingnum(actor, colors)
	local c = colors[1]
	if actor.lifetime < 2 then c = colors[2]
	elseif actor.lifetime < 4 then c = colors[3] end
	print(actor.num, actor.x-4, actor.y-8-actor.z-sqrt((200-(actor.lifetime ^ 2))), c)
end

function drawstick(actor)
	if frame % 2 == 0 then
		line(actor.x+2, actor.y-2, actor.x-2, actor.y-2, 6)
	else
		line(actor.x, actor.y, actor.x, actor.y-4, 6)
	end
end

function drawflame(actor)
	circfill(actor.x, actor.y-4, 2, 9)
	circfill(actor.x, actor.y-4, (frame % 5)/2, 8)
end

function drawsummon(actor)
	if frame % 3 == 0 then
		runpalshift(actor.palshift)
	else
		local rp = {}
		for i=0,15 do
			rp[i] = frnd(16)
		end
		runpalshift(rp)
	end
	spr(actor.spritebase, actor.x-4, actor.y-8, 1, 1, actor.flipsprite)
	pal()
end
