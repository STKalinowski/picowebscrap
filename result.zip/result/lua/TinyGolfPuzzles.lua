--tiny golf puzzles
--tom brinton

function _init()
 coolmath()
 splashscreen(40)
 
 cartdata("tinygolfpuzzles")
 music()
 
 pars={
 3,6,5,7,3,7,5,4,
 5,5,4,5,6,6,11,4,
 10,8,5,10,5,8,11,
 5,11,5,8,9,7,12,13,20
 }
 
 scores={}
 
 for i = 1,32 do
  scores[i]=dget(i)
 end
 
 sounds="on"
 tunes="on"

 mx,my=0,0

 shake=0
 shakex=0
 shakey=0
 
 gs=0
 grass={}
 for i=1,300 do
  creategrass()
 end

 balls={}
 spd=2

 holes={}
 water={}
 sand={}
 dust={}
 flags={}
 switches={}
 
 
 strokes=0

 wt=0
 level=0
 levelunlocked=dget(0)
 par=3
 
 mode="menu"
 mitem=4
 mhole=levelunlocked+1
 

end

function _update60()
 gs+=.001
 if mode=="menu" then
  if btnp(⬇️) then
   mitem+=1
   if (sounds=="on") sfx(2)
   if (mitem >4) mitem=1
  elseif btnp(⬆️) then
   mitem-=1
   if (sounds=="on") sfx(2)
   if (mitem<1) mitem=4
  end
  if mitem==1 then
   if btnp(➡️) then
    
    if mhole<32 and levelunlocked>mhole-1 then
     mhole+=1
     if (sounds=="on") sfx(4)
    end
   elseif btnp(⬅️) then
    if mhole>1 then
     mhole-=1
     if (sounds=="on") sfx(5) 
    end
   end
  elseif mitem==2 then
   if btnp(❎) then
    
    if tunes == "on" then
     if sounds=="on" then
      sfx(5)
     end
     
     tunes="off"
     music(-1,300)
    else
     if sounds=="on" then
      sfx(4)
     end
     music(0,300)
     tunes="on"
    end 
   end 
  elseif mitem==3 then
   if btnp(❎) then
    if sounds == "on" then
     sounds="off"
    else
     sfx(4)
     sounds="on"
    end 
   end 
  elseif mitem==4 then
   if btnp(❎) then
    if (sounds=="on") sfx(4)
    menuitem(1, "main menu", function() backtomenu()  end)
    menuitem(2, "previous hole", function() prevhole()  end)

    mode="game"
    level = mhole-1
    loadlevel()
   end
  end
 elseif mode=="game" then
	 updateballs()
	 foreach(holes,checkhole)
	 foreach(water,checkwater)
	 foreach(sand,checksand)
	 foreach(switches,checkswitch)
	 opendoors()

  if btnp(❎) and wt==0 then
   loadlevel()
  end

	 if didwin() then
	  if wt==0 then
	   wt=90
	   if (sounds=="on") sfx(3)
	  elseif wt>1 then
	   wt-=1
	  elseif wt==1 then
	   if scores[level+1]==0 then
 	   scores[level+1]=strokes
	    dset(level+1,strokes)
	   else
	    if strokes<scores[level+1] then
  	   scores[level+1]=strokes
	     dset(level+1,strokes)
	    end
	   end
	   
	   restoremap()
	   
	   level+=1
	   
	   if level>levelunlocked then
	    levelunlocked=level
	    dset(0,levelunlocked)
	   end
	   
	   if level==32 then
	    mode="win"
	   else
	    loadlevel()
	   end
	  end
	 end
	elseif mode=="win" then
	 if btnp(❎) then
	  mode="menu"
	  if (sounds=="on") sfx(3)
	 end
	end
end

function _draw()
	cls()
	
	--background grooves
	foreach(grass,drawgrass)
	
	if mode=="menu" then
	 fillp(0b0101101001011010.1)
	 rectfill(0,16,127,28,1)
	 spr(64,48,19,4,1)
	 
	 fillp()
	 rectfill(0,32,127,44,3)
	 spr(68,48,35,4,1)
	 
	 fillp(0b0101101001011010.1)
	 rectfill(0,48,127,60,1)
	 spr(72,36,51,7,1)
	 fillp()
	 
	 local fgc,bgc= 0,1
	 if mitem==1 then
	  fgc,bgc=7,3
	  if mhole <32 and levelunlocked>mhole-1 then 
	   spr(32,88,72)
	  end
	  if mhole>1  then
	   spr(33,32,72)
	  end
	 else
	  fgc,bgc=0,1
	 end 
	 printc("hole "..mhole,64,76,fgc,bgc)
	 if mitem==2 then
	  fgc,bgc=7,3
	  spr(34,88,82)
	 else
	  fgc,bgc=0,1
	 end 	 
	 printc("music: "..tunes,64,86,fgc,bgc)
	 if mitem==3 then
	  fgc,bgc=7,3
	  spr(34,88,92)
	 else
	  fgc,bgc=0,1
	 end 
	 printc("sfx: "..sounds,64,96,fgc,bgc)
	 if mitem==4 then
	  fgc,bgc=7,3
	  spr(34,88,102)
	 else
	  fgc,bgc=0,1
	 end 
	 printc("play",64,106,fgc,bgc)
	 
	 printc("tom brinton's",64,7,3)
	
	
	
	elseif mode=="game" then
		--map
		map(mx,my,0,0,mx+16,my+16)
		
		--balls
		foreach(balls,drawball)
		
		--flags
		foreach(flags,drawflag)
		
		--dust
		foreach(dust,drawdust)
		
		--strokes
		drawpar(strokes,pars[level+1],1,1)
		if scores[level+1] !=0 then
		 printo("best:"..scores[level+1],2,11,6,1)
	 end	
		--hint
		if strokes>pars[level+1]+1 and wt==0 then
		 spr(34,4,118)
		 printo("to reset",14,120,7,3)
		elseif level>0 and level<4 then
		 printc("[enter] menu",64,120,6,1)
		end
		
		--hole 
  spr(91,96,1,2,1)
  drawtext(level+1,112,1)
  
  
	elseif mode=="win" then
	 fillp(0b0101101001011010.1)
	 rectfill(0,8,127,20,1)
	 spr(96,32,11,8,1)
	 fillp()
	 
	 --list all scores
	 local i=1
	 for col = 0,3 do
	  for row = 0,7 do
	   local c1,c2=11,3
	   if scores[i]>pars[i] then
	    c1,c2=8,2
	   end
	   printo(scores[i].."/"..pars[i],13+col*32,24+row*10,c1,c2)
	   printo(i,3+col*32,24+row*10,6,5)

	   i+=1
	  end
	 end
	 
	 --list total score
	 totalscore=0
	 totalpar=0
	 for i=1,32 do
	  totalscore+=scores[i]
	  totalpar+=pars[i]
	 end
	 printc("total: "..totalscore.."/"..totalpar,64,110,7,1)

  --return msg
	 spr(34,31,118)
	 printc("return to menu",68,122,7,3)

	end
end

function backtomenu()
 mode="menu"
 mitem=1
 mhole=level+1
 menuitem(2)
 menuitem(1)
end

function prevhole()
 if level-1 >= 0 then
  level-=1
  loadlevel()
 end
end
-->8
--balls

function createball(bx,by,rock)
 local b={}
 b.x=bx
 b.y=by
 b.s=3
 b.xs=0
 b.ys=0
 b.nx=0
 b.ny=0
 b.onsand=false
 b.lastsand=nil
 if rock then
  b.s=19
  b.rock=true
 end
 add(balls,b)
end

function updateballs()
 
 if not ballsmoving() and wt==0 then
 
	 if btnp(⬆️) then
	  for b in all(balls) do
	   b.ys=-spd
	   b.xs=0
	  end
	  if (sounds=="on") sfx(0)
	  sort(balls,bottomup)
	  strokes+=1
	 elseif btnp(⬇️) then
	  for b in all(balls) do
	   b.ys=spd
	   b.xs=0
	  end
	  if (sounds=="on") sfx(0)
   sort(balls,topdown)
	  strokes+=1
	 elseif btnp(⬅️) then
	  for b in all(balls) do
	   b.ys=0
	   b.xs=-spd
	  end
	  if (sounds=="on") sfx(0)
   sort(balls,rtol)
	  strokes+=1 
	 elseif btnp(➡️) then
	  for b in all(balls) do
	   b.ys=0
	   b.xs=spd
	  end
	  if (sounds=="on") sfx(0)
   sort(balls,ltor)
	  strokes+=1
	 end
	 
	end
	 
 for b in all(balls) do
  
  if b.xs!=0 or b.ys!=0 then
  
	  b.nx=b.x+b.xs
	  b.ny=b.y+b.ys
	  
	  if didcollide(b) then
	   shake=4
    shakex=-b.xs
    shakey=-b.ys
    if (sounds=="on") sfx(2)
    
    
	   --set to nearest grid spot
	   b.x=flr(b.x/8)*8
	   b.y=flr(b.y/8)*8
	   --b.x-=(b.x%8)*(b.xs/2)
	   --b.y-=(b.y%8)*(b.ys/2)
	   
	   --check if another ball's there
	   
	   
	   b.xs=0
	   b.ys=0
	  end
	  
	  b.x+=b.xs
	  b.y+=b.ys
  
  else
   b.lastsand=nil
  end
  
 end

end


function drawball(b)
 spr(b.s,b.x,b.y)
 --print(b.xs.." "..b.ys,b.x+8,b.y)
end


function didcollide(b)
 collided=false

 --top
 tx=b.nx+4
 ty=b.ny+1
 if fget(mget(flr(tx/8)+mx,flr(ty/8)+my),0) then
  collided= true
  createdust(tx,ty,3)
 end
 
 --bottom
 tx=b.nx+4
 ty=b.ny+7
 if fget(mget(flr(tx/8)+mx,flr(ty/8)+my),0) then
  collided= true
  createdust(tx,ty,3)
 end
 
 --left
 tx=b.nx+1
 ty=b.ny+4
 if fget(mget(flr(tx/8)+mx,flr(ty/8)+my),0) then
  collided= true
  createdust(tx,ty,3)
 end
 
 --right
 tx=b.nx+7
 ty=b.ny+4
 if fget(mget(flr(tx/8)+mx,flr(ty/8)+my),0) then
  collided= true
  createdust(tx,ty,3)
 end
  
 bx=b.nx+4
 by=b.ny+4
 for bb in all(balls) do
   if bb==b then
   else
    if bb.xs==0 and bb.ys==0 then
		   bbx=bb.x+4
		   bby=bb.y+4 
			  if abs(bx-bbx)<8 and abs(by-bby)<8 then
			   collided=true
			   createdust((bx+bbx)/2,(by+bby)/2,6)
			  end
		  end 
	  end
 end
 
 return collided
end


function ballsmoving()

 isanyballmoving = false
 
 for b in all(balls) do
  if b.xs!=0 or b.ys!=0 then
   isanyballmoving = true
  end
 end
 
 return isanyballmoving

end
-->8
--special tiles
function createhole(hx,hy,hmx,hmy)
 local h={}
 h.x=hx
 h.y=hy
 h.cx=hx+4
 h.cy=hy+4
 h.mx=hmx
 h.my=hmy
 add(holes,h)
end

function checkhole(h)
 for b in all(balls) do
  if dist(b.x,b.y,h.x,h.y)<4 and not b.rock then
   mset(h.mx,h.my,23)
   createdust(h.cx,h.cy,4)
   del(balls,b)
   del(holes,h)
   if (sounds=="on") sfx(1)
  end
 end
end

function createwater(wx,wy)
 local w={}
 w.x=wx
 w.y=wy
 w.cx=wx+4
 w.cy=wy+4
 add(water,w)
end

function checkwater(w)
 for b in all(balls) do
  bcx=b.x+4
  bcy=b.y+4
  if dist(bcx,bcy,w.cx,w.cy)<3 then
   createdust(w.cx,w.cy,6)
   del(balls,b)
   if (sounds=="on") sfx(6)
  end
 end
end

function createsand(sx,sy)
 local s={}
 s.x=sx
 s.y=sy
 s.cx=sx+4
 s.cy=sy+4
 add(sand,s)
end

function checksand(s)
 for b in all(balls) do
  if b.lastsand==s then
   --do nothing
  else
   bcx=b.x+4
   bcy=b.y+4
	  if dist(bcx,bcy,s.cx,s.cy)<3 then
	   b.xs=0
	   b.ys=0
	   --set to nearest grid spot
	   b.x=round(b.x/8)*8
	   b.y=round(b.y/8)*8
	   b.lastsand=s
	  end
  end
 end
end

function createswitch(hx,hy,hmx,hmy)
 local sw={}
 sw.x=hx
 sw.y=hy
 sw.cx=hx+4
 sw.cy=hy+4
 sw.mx=hmx
 sw.my=hmy
 sw.pressed=false
 add(switches,sw)
end

function checkswitch(sw)
 ballison=false
 for b in all(balls) do
  if dist(b.x,b.y,sw.x,sw.y)<4 then
   ballison=true
   if not sw.pressed then
    if (sounds=="on") sfx(4)
   end
  end
 end
 if not ballison and sw.pressed then
  if (sounds=="on") sfx(5)
 end
 sw.pressed=ballison
end 

function opendoors()
 if allswitchespressed() then
  for i=mx,mx+15 do
  	for j=my,my+15 do
  	 if mget(i,j)==18 then
  	  mset(i,j,20)
  	 end
  	end
  end 
 else
  for i=mx,mx+15 do
  	for j=my,my+15 do
  	 if mget(i,j)==20 then
  	  mset(i,j,18)
  	 end
  	end
  end 
 end
end

function allswitchespressed()
 for sw in all(switches) do
  if not sw.pressed then
   return false
  end
 end

 return true
 
end


-->8
--particles + bg

function creategrass()
 local g={}
 g.x=rnd(127)
 g.y=rnd(136)
 g.h=rnd(4)+4
 g.s=rnd(.2)
 add(grass,g)
end

function drawgrass(g)

g.s+=-.001+rnd(.002)
 for j=0,g.h do
  pset(g.x+cos(gs-g.s+g.y/127)*j/2,g.y-j,1)
 end

end

function createdust(dx,dy,dc)
 for i=1,10 do
  local d={}
  d.x=dx
  d.y=dy
  d.c=dc
  d.xs=-.5+rnd()
  d.ys=-rnd()
  d.t=5+ceil(rnd(10))
  add(dust,d)
 end
end

function drawdust(d)
 d.x+=d.xs
 d.y+=d.ys
 d.ys+=.1
 d.t-=1
 if d.t<=0 then
  del(dust,d)
 end
 
 pset(d.x,d.y,d.c)
 
end

function createflag(fmx,fmy)
 local f={}
 f.x=(fmx-mx)*8
 f.y=(fmy-my-1)*8
 f.s=7+ceil(rnd(4))
 f.at=0
 add(flags,f)

end

function drawflag(f)
 f.at+=1
 if f.at>5 then
  f.at=0
  f.s+=1
  if f.s==12 then
   f.s=8
  end
 end
 spr(f.s,f.x,f.y)
end
-->8
--level

function loadlevel()
 mx=(level%8)*16
 my=flr(level/8)*16
 
 --reset arrays
 balls={}
 holes={}
 water={}
 sand={}
 dust={}
 flags={}
 switches={}
 
 strokes=0
 wt=0
 
 for i=mx,mx+15 do
  for j=my,my+15 do
   if mget(i,j)==35 then
    createball((i-mx)*8,(j-my)*8)
   elseif mget(i,j)==23 then
    mset(i,j,4)
    createhole((i-mx)*8,(j-my)*8,i,j)
   elseif mget(i,j)==36 then
    createball((i-mx)*8,(j-my)*8,true)
   elseif fget(mget(i,j),1) then
    createhole((i-mx)*8,(j-my)*8,i,j)
   elseif mget(i,j)==7 then
    createwater((i-mx)*8,(j-my)*8)
   elseif mget(i,j)==6 then
    createsand((i-mx)*8,(j-my)*8)
   elseif mget(i,j)==17 then
    createswitch((i-mx)*8,(j-my)*8,i,j)
   end
  end
 end
end

function didwin()
 if wt>0 then return true end

	for i=mx,mx+15 do
  for j=my,my+15 do
   if mget(i,j) == 4 then
    return false
   end
  end
 end
 
 --u won
 for i=mx,mx+15 do
  for j=my+15,my,-1 do
   if mget(i,j) == 23 then
    mset(i,j,24)
    createflag(i,j)
   end
  end
 end
 
 return true
end


function restoremap()

 for i=mx,mx+15 do
  for j=my,my+15 do
   if mget(i,j)==24 then
    mset(i,j,4)
   end
  end
 end
end
-->8
--misc

function round(x)
  return x>=0 and flr(x+.5) or ceil(x-.5)
end

function div(a,b)
    return (a - a % b) / b
end

function dist( x1, y1, x2, y2 )
	return sqrt(sqr(x2-x1) + sqr(y2-y1))
end

function sqr(a)
 return a*a
end

function sort(a,cmp)
  for i=1,#a do
    local j = i
    while j > 1 and cmp(a[j-1],a[j]) do
        a[j],a[j-1] = a[j-1],a[j]
    j = j - 1
    end
  end
end

function topdown(a,b)
 return a.y<b.y
end

function bottomup(a,b)
 return a.y>b.y
end

function ltor(a,b)
 return a.x<b.x
end

function rtol(a,b)
 return a.x>b.x
end


function drawpar(txt,pt,dx,dy)
 sstr=tostr(txt)
 pstr=tostr(pt)
 for i=1,#sstr do
  spr(80+tonum(sub(sstr,i,i)),dx+(i-1)*8,dy)
 end
 spr(90,dx+(#sstr*8),dy)
 for i=1,#pstr do
  spr(80+tonum(sub(pstr,i,i)),dx+(i*8)+(#sstr*8),dy)
 end
end

function drawtext(txt,dx,dy)
 sstr=tostr(txt)
 for i=1,#sstr do
  spr(80+tonum(sub(sstr,i,i)),dx+(i-1)*8,dy)
 end
end

function printc(
	str,x,y,
	col,
	special_chars)

	local len=(#str*4)+(special_chars*3)
	local startx=x-(len/2)
	local starty=y-2
	print(str,startx,starty,col)
end

function coolmath()
 for i=1,40 do
  cls(0)
  circfill(64,64,i,12)
  ellipse(64,64,i*1.5,i/2,11)
  printc("cool",64,56,8,10,0)
  printc("math",64,64,8,10,0)
  printc("games",64,72,8,10,0)
  printc("coolmathgames.com",64,120,7,1,0)
  flip()
 end
 if (sounds=="on") sfx(2)
 for i=1,40 do
  cls(0)
  circfill(64,64,40,12)
  ellipse(64,64,40*1.5,40/2,11)
  printc("cool",64,56,8,10,0)
  printc("math",64,64,8,10,0)
  printc("games",64,72,8,10,0)
  printc("coolmathgames.com",64,120,7,1,0)
  flip()
 end
end

function splashscreen(l)
for i=1,30 do
 size=i+8
 cls(7)
 circfill(64,64,size+1,0)
 for a=0,1,1/14 do
  trifill(64+(cos(a)*(size+size/2)),64-(sin(a)*(size+size/2)),64+(cos(a+(1/28))*size),64-(sin(a+(1/28))*size),64+(cos(a-(1/28))*size),64-(sin(a-(1/28))*size),0)
 end
 rectfill(64-size/8,68,64+size/8,64-size*.75,7)
 rectfill(64-size/8,64+size/3,64+size/8,64+size*.6,7)
 
 flip()
end
if (sounds=="on") sfx(2)
for i=1,l do
 print("beep yeah!",87,120,0)
 flip()
end
end

function trifill( x1,y1,x2,y2,x3,y3, color1)

          local min_x=min(x1,min(x2,x3))
         if(min_x>127)return
          local max_x=max(x1,max(x2,x3))
         if(max_x<0)return
          local min_y=min(y1,min(y2,y3))
         if(min_y>127)return
          local max_y=max(y1,max(y2,y3))
         if(max_y<0)return

          local x1=band(x1,0xffff)
          local x2=band(x2,0xffff)
          local y1=band(y1,0xffff)
          local y2=band(y2,0xffff)
          local x3=band(x3,0xffff)
          local y3=band(y3,0xffff)

          local width=min(127,max_x)-max(0,min_x)
          local height=min(127,max_y)-max(0,min_y)

    if(width>height)then --wide triangle  
          local nsx,nex
          --sort y1,y2,y3
          if(y1>y2)then
            y1,y2=y2,y1
            x1,x2=x2,x1
          end

          if(y1>y3)then
            y1,y3=y3,y1
            x1,x3=x3,x1
          end

          if(y2>y3)then
            y2,y3=y3,y2
            x2,x3=x3,x2          
          end

         if(y1!=y2)then  
            local delta_sx=(x3-x1)/(y3-y1)
            local delta_ex=(x2-x1)/(y2-y1)

            if(y1>0)then
                nsx=x1
                nex=x1
                min_y=y1
            else --top edge clip
                nsx=x1-delta_sx*y1
                nex=x1-delta_ex*y1
                min_y=0
            end

            max_y=min(y2,128)

            for y=min_y,max_y-1 do

            rectfill(nsx,y,nex,y,color1)
            nsx+=delta_sx
            nex+=delta_ex
            end

        else --where top edge is horizontal
            nsx=x1
            nex=x2
        end

        if(y3!=y2)then
            local delta_sx=(x3-x1)/(y3-y1)
            local delta_ex=(x3-x2)/(y3-y2)

            min_y=y2
            max_y=min(y3,128)
            if(y2<0)then
                nex=x2-delta_ex*y2
                nsx=x1-delta_sx*y1
                min_y=0
            end

             for y=min_y,max_y do
                rectfill(nsx,y,nex,y,color1)
                nex+=delta_ex
                nsx+=delta_sx
             end

        else --where bottom edge is horizontal
            rectfill(nsx,y3,nex,y3,color1)
        end
    else --tall triangle -----------------------------------<><>----------------
          local nsy,ney

          --sort x1,x2,x3
          if(x1>x2)then
            x1,x2=x2,x1
            y1,y2=y2,y1
          end

          if(x1>x3)then
            x1,x3=x3,x1
            y1,y3=y3,y1
          end

          if(x2>x3)then
            x2,x3=x3,x2
            y2,y3=y3,y2          
          end

         if(x1!=x2)then 
            local delta_sy=(y3-y1)/(x3-x1)
            local delta_ey=(y2-y1)/(x2-x1)

            if(x1>0)then
                nsy=y1
                ney=y1
                min_x=x1
            else --top edge clip
                nsy=y1-delta_sy*x1
                ney=y1-delta_ey*x1
                min_x=0
            end

            max_x=min(x2,128)

            for x=min_x,max_x-1 do

            rectfill(x,nsy,x,ney,color1)
            nsy+=delta_sy
            ney+=delta_ey
            end

        else --where top edge is horizontal
            nsy=y1
            ney=y2
        end

            if(x3!=x2)then
            local delta_sy=(y3-y1)/(x3-x1)
            local delta_ey=(y3-y2)/(x3-x2)

            min_x=x2
            max_x=min(x3,128)
            if(x2<0)then
                ney=y2-delta_ey*x2
                nsy=y1-delta_sy*x1
                min_x=0
            end

             for x=min_x,max_x do

                rectfill(x,nsy,x,ney,color1)
                ney+=delta_ey
                nsy+=delta_sy
             end

          else --where bottom edge is horizontal

                rectfill(x3,nsy,x3,ney,color1)

          end

    end
end

function ellipse(
 cx,cy,xr,yr,c,hlinefunc
)
 xr=flr(xr)
 yr=flr(yr)
 hlinefunc=hlinefunc or rectfill
 local xrsq=shr(xr*xr,16)
 local yrsq=shr(yr*yr,16)
 local a=2*xrsq
 local b=2*yrsq
 local x=xr
 local y=0
 local xc=yrsq*(1-2*xr)
 local yc=xrsq
 local err=0
 local ex=b*xr
 local ey=0
 while ex>=ey do
  local dy=cy-y
  hlinefunc(cx-x,cy-y,cx+x,dy,c)
  dy+=y*2
  hlinefunc(cx-x,dy,cx+x,dy,c)
  y+=1
  ey+=a
  err+=yc
  yc+=a
  if 2*err+xc>0 then
   x-=1
   ex-=b
   err+=xc
   xc+=b
  end
 end

 x=0
 y=yr
 xc=yrsq
 yc=xrsq*(1-2*yr)
 err=0
 ex=0
 ey=a*yr
 while ex<=ey do
  local dy=cy-y
  hlinefunc(cx-x,cy-y,cx+x,dy,c)
  dy+=y*2
  hlinefunc(cx-x,dy,cx+x,dy,c)
  x+=1
  ex+=b
  err+=xc
  xc+=b
  if 2*err+yc>0 then
   y-=1
   ey-=a
   err+=yc
   yc+=a
  end
 end
end

function printo(str,startx,
															 starty,col,
															 col_bg)
	print(str,startx+1,starty,col_bg)
	print(str,startx-1,starty,col_bg)
	print(str,startx,starty+1,col_bg)
	print(str,startx,starty-1,col_bg)
	print(str,startx+1,starty-1,col_bg)
	print(str,startx-1,starty-1,col_bg)
	print(str,startx-1,starty+1,col_bg)
	print(str,startx+1,starty+1,col_bg)
	print(str,startx,starty,col)
end

--print string centered with 
--outline.
function printc(
	str,x,y,
	col,col_bg,
	special_chars)
 
 spc = special_chars or 0
 
	local len=(#str*4)+(spc*3)
	local startx=x-(len/2)
	local starty=y-2
	printo(str,startx,starty,col,col_bg)
end
