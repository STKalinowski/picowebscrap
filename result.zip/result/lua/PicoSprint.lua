-- pico-sprint
-- by rylauchelmi

--todo:
-- uniformiser l'interface
-- perfs sur certaines maps=> nb de skidmarks adaptatifs
-- optim: ne redessiner le pont que si au mins une voiture est potentiellement en dessous

--bug:
-- oil qui appa/disparait sur les ponts

--flags
--0 : waypoints
--1 : bridge markers
--2 : lap flag pos
--3 : road w/ collidable border
--4 : trees
--5 : road
--6 : placeholder (w/ collision)
--7 : start tiles

-- game settings/state
reverse=false
nb_maps=2
cur_time=0
max_lap=2
difficulty=1

-- entities
car_colors={8,11,10,12}
car_colors_shadow={2,3,9,1}
champ={1,2,3,4}

-- tweaks
--max_speed=2.5
max_speed=1.5
min_speed=-1
--turn_factor=0.02
turn_factor=0.015
--turn_factor=0.0075
acceleration=0.1
deceleration=-0.1

-- scenery
scenery=
{
 {-- grass
  color=3,
  particle=11,
  trees=
  {
   {x=2,y=-2,c=29,s=61,o=-8,so=0,w=2},
   {x=-1,y=-2,c=27,s=59,o=0,so=0,w=2}
  }
 },
 {-- snow
  color=6,
  particle=7,
  trees=
  {
   {x=2,y=-2,c=25,s=57,o=-7,so=-7,w=2},
   {x=-1,y=-2,c=31,s=63,o=0,so=5,w=1}
  }
 }
}

bridge=
{
 nil,
 { --2
  box_startx=72,box_starty=40,
  box_endx=96,box_endy=80,
  col_mapx=56,col_mapy=54,
  shadow_startx=96,shadow_starty=40,
  shadow_width=4,shadow_height=40
 },
 { --3
  box_startx=32,box_starty=64,
  box_endx=96,box_endy=80,
  col_mapx=52,col_mapy=48,
  shadow_startx=32,shadow_starty=80,
  shadow_width=64,shadow_height=4
 },
 { --4
  box_startx=32,box_starty=64,
  box_endx=96,box_endy=80,
  col_mapx=52,col_mapy=48,
  shadow_startx=32,shadow_starty=80,
  shadow_width=64,shadow_height=4
 },
 nil,
 nil,
 { --7
  box_startx=24,box_starty=40,
  box_endx=48,box_endy=120,
  col_mapx=48,col_mapy=48,
  shadow_startx=48,shadow_starty=56,
  shadow_width=4,shadow_height=48
 },
 { --8
  box_startx=32,box_starty=40,
  box_endx=128,box_endy=56,
  col_mapx=52,col_mapy=51,
  shadow_startx=56,shadow_starty=56,
  shadow_width=48,shadow_height=4
 },
 { --9
  box_startx=56,box_starty=48,
  box_endx=80,box_endy=88,
  col_mapx=56,col_mapy=54,
  shadow_startx=80,shadow_starty=48,
  shadow_width=4,shadow_height=64
 },
 { --10
  box_startx=24,box_starty=72,
  box_endx=48,box_endy=88,
  col_mapx=56,col_mapy=54,
  shadow_startx=48,shadow_starty=56,
  shadow_width=4,shadow_height=48
 },
 { --11
  box_startx=64,box_starty=88,
  box_endx=88,box_endy=104,
  col_mapx=56,col_mapy=54,
  shadow_startx=88,shadow_starty=80,
  shadow_width=4,shadow_height=32
 },
 { --12
  box_startx=32,box_starty=64,
  box_endx=56,box_endy=96,
  col_mapx=65,col_mapy=48,
  shadow_startx=56,shadow_starty=64,
  shadow_width=4,shadow_height=40
 },
 { --13
  box_startx=72,box_starty=40,
  box_endx=96,box_endy=120,
  col_mapx=65,col_mapy=49,
  shadow_startx=96,shadow_starty=32,
  shadow_width=4,shadow_height=80
 },
 { --14
  box_startx=48,box_starty=24,
  box_endx=72,box_endy=64,
  col_mapx=60,col_mapy=54,
  shadow_startx=72,shadow_starty=40,
  shadow_width=4,shadow_height=24
 },
 { --15
  box_startx=72,box_starty=24,
  box_endx=96,box_endy=40,
  col_mapx=52,col_mapy=54,
  shadow_startx=64,shadow_starty=40,
  shadow_width=40,shadow_height=4
 }
}


-- maths

function dot(a,b)
	return a.x*b.x+a.y*b.y
end


function minus(a,b)
	return { x=a.x-b.x, y=a.y-b.y }
end


function plus(a,b)
	return { x=a.x+b.x, y=a.y+b.y }
end


function plus_in_place(a,b)
	a.x+=b.x
	a.y+=b.y
end


function muls(a,b)
	return { x=a.x*b, y=a.y*b }
end


function muls_in_place(a,b)
	a.x*=b
	a.y*=b
end


function unit(a)
 local len = max(sqrt(dot(a,a)),0.01)
	return { x=a.x/len, y=a.y/len }
end


function distance(a, b)
 local dx = a.x-b.x
 local dy = a.y-b.y
 dx*=dx
 dy*=dy
 local sum=dx+dy
 if (dx<0 or dy<0 or sum<0) return max_val
 return sqrt(sum)
end


function spawn_smoke(pos,color,size)
 local s = {
  -- relative to car sprite
  x=pos.x+4,
  y=pos.y+4,
  dx=rnd(2)-1,
  dy=rnd(0.25)+0.25,
  life=rnd(5)+5,
  color=color
 }
 s.lifestep = s.life/size
 add(smokes,s)
end


function update_smoke(s)
 s.life-=1
 s.x+=s.dx
 s.y-=s.dy
 if (s.life<=0) del(smokes,s)
end


function draw_smoke(s)
 palt(0,false)
 circfill(s.x,s.y,s.life/s.lifestep,s.color)
end


function flr_rnd(i)
 return flr(rnd(i))
end


function create_player()
 return
 {
  skills={0,0,0},
  selected_skill=1,
  nb_wrenches=0
 }
end

function create_car(col)
	local pos=start_tiles[max(col%(#start_tiles+1),1)]
	local wp=reverse and #waypoints or 1
	local start_dir=minus(waypoints[wp],pos)
	return
	{
  x=pos.x,
  y=pos.y,
  vel={x=0,y=0},
  speed=0,
  dir=start_dir,
  a=atan2(start_dir.y,start_dir.x),
  c=car_colors[col],
  cs=car_colors_shadow[col],
  s=0,
  f=false,
  ai=true,
  skid=1,
  waypoint=wp,
  dist_to_wp=1000,
  maybe_hidden=false,
 	lap_time=0,
  lap=0,
  can_lap=false,
  slipping=0,
  wp_time=0,
  i=col,
  on_bridge=true,
  wpc=0,
  score_pos=32*(col-1)+1,
  score_prev=32*(col-1)+1,
  missed=false,
  flag=0,
  flag_flip=0,
  finished=false,
  flag_timer=0,
  p=players[col]
 }
end


function hide_if_needed(c)
 if (not c.on_bridge and c.enter_bridge and should_hide(c,8)) c.on_bridge=true
 if (c.on_bridge) c.on_bridge=should_hide(c,8)
 c.maybe_hidden=not c.on_bridge and not c.enter_bridge
end


function draw_car_shadow(c)
  if (fget(c.s,6)) return
	 spr(c.s,c.x+1,c.y+1,1,1,c.f)
end


function draw_flag(c,pos)
 pal(8,c.c)
 -- spr(50+c.flag,pos.x+c.i,pos.y+c.i,1,1,c.flag_flip)
 spr(50+c.flag,pos.x,pos.y,1,1,c.flag_flip)
 c.flag+=0.5
 if (c.flag>=5) c.flag_flip=(not c.flag_flip) c.flag=0
end


function draw_car(c)
	hide_if_needed(c)
 pal(8,c.c)
 palt(0,false)
 palt(13,true)
 spr(c.s,c.x,c.y,1,1,c.f)

 -- car in shadow
	local	sz=bridge[cur_map]
	if sz!=nil and not c.on_bridge then
	 clip(sz.shadow_startx,sz.shadow_starty,sz.shadow_width,sz.shadow_height)
	 pal(8,c.cs)
	 spr(c.s,c.x,c.y,1,1,c.f)
  clip()
 end

 local wayp=waypoints[c.waypoint]
--	 line(c.x,c.y,wayp.x,wayp.y,9)
 if (c.missed) draw_flag(c,wayp) --draw_arrow(c,waypoints[c.waypoint])
 if (c.flag_timer>0) c.flag_timer-=1 draw_flag(c,flag_pos)
end


function draw_cars()
 foreach(cars, draw_car)

 local hz=bridge[cur_map]
 if hz!=nil then
  for c in all(cars) do
   if should_hide(c,8) and not c.on_bridge then
    clip(hz.box_startx,hz.box_starty-1,hz.box_endx-hz.box_startx,hz.box_endy-hz.box_starty+1)
    draw_map(false)
    pal()
    foreach(skidmarks_bridge,draw_skidmarks)
    foreach(placeholders,draw_placeholder) -- oil
    for i=1,4 do
     local c=cars[i]
     if (not c.maybe_hidden) car_shadows_state() draw_car_shadow(c) pal() draw_car(c)
    end
    clip()
    pal()
    return
   end
  end
 end
end


function screen_transition()
 if transition>0 then
  transition-=0.03
  if transition>0.25 then
   prev_screen.draw()
  else
   cur_screen.draw()
  end
  if (prev_screen!=cur_screen) circfill(64,64,-sin(transition)*92,0)
 else
  cur_screen.draw()
 end
end

function set_screen(s)
 transition=0.5
 prev_screen=cur_screen
 cur_screen=s
 s.init()
end


function _init()
 join_screen.init()
 cur_screen=start_screen
 set_screen(start_screen)
end


function map_index_to_coords(i)
 return flr(i%8),flr(i/8)
end


function read_map()
 skidmarks={}
 skidmarks_bridge={}
 skid_index=1
 skid_b_index=1
	waypoints={}
 start_tiles={}
 trees={}
 smokes={}
 placeholders={}
 puddles={}
 wrenches={}
 draw_ramp=false
 race_over=false
 last_lap=false
 finished={}
 lap=1

 cur_scenery=scenery[flr_rnd(#scenery)+1]

	for yy=0,14 do
 	for xx=0,15 do
   local x,y=map_index_to_coords(cur_map)
   local t=mget(xx+x*16,yy+y*15)
   local cur_pos={x=xx*8,y=yy*8}

   if (fget(t,0)) waypoints[t-239]=cur_pos t=128
   if (fget(t,2)) flag_pos=cur_pos
   if (fget(t,7)) add(start_tiles,cur_pos) 
   if (128==t) add(puddles,cur_pos)

   -- trees
   local is_tree=123<t and t<126
   if is_tree then
    local tree=cur_scenery.trees[t-123]
    add(trees,{x=cur_pos.x+tree.x,y=cur_pos.y+tree.y,c=tree.c,s=tree.s,o=tree.o,w=tree.w,so=tree.so})
   end

   -- placeholders
   local placeholder=fget(t,6)
   if (placeholder) add(placeholders,{x=cur_pos.x,y=cur_pos.y,s=t-1,f=false})
    
   local yyy=yy+48
   local xxx=xx+16
   mset(xx,yyy,0)
   mset(xxx,yyy,0)
   if fget(t,5) or placeholder or is_tree then
    mset(xx,yyy,t)
    mset(xxx,yyy,t)
    if (fget(t,3)) draw_ramp=true
   end

   local hz=bridge[cur_map]
   if should_hide(cur_pos,1) then
    x=xx-hz.box_startx/8
    y=yy-hz.box_starty/8
    t=mget(x+hz.col_mapx,y+hz.col_mapy)
    if (not fget(t,5)) t=128
    mset(xxx,yyy,t)
 		end
 	end
 end

 drop_puddles(2*difficulty-1, puddles, 34)
 drop_puddles(difficulty-1, puddles, 33)
end


function drop_puddles(nb,puddles,t)
 for i=1,min(nb,#puddles) do
  local pos=puddles[flr_rnd(#puddles)+1]
  del(puddles,pos)
  mset(pos.x/8,pos.y/8+48,t)
  if (not should_hide(pos,1)) mset(pos.x/8+16,pos.y/8+48,t)
  add(placeholders,{x=pos.x,y=pos.y,s=t})
 end
end


function drop_wrench()
 local pos=puddles[flr_rnd(#puddles)+1]
 del(puddles,pos)
 add(wrenches,{x=pos.x,y=pos.y,s=35,f=false})
end


function tileidx_to_spritecoord(s)
 local sx=(s%16)*8
 local sy=flr(s/16)*8
 return sx,sy
end


--place_holder_shadow=0
function draw_placeholder(p)
-- spr(p.s,p.x+place_holder_shadow,p.y+place_holder_shadow)
 spr(p.s,p.x,p.y)
end

function draw_map(first_pass)
 pal()
 
 local cx,cy,sx,sy,cw,ch,hz=0,0,0,0,16,15,bridge[cur_map]
 if (not first_pass) cx,cy,sx,sy,cw,ch=hz.box_startx/8, hz.box_starty/8, hz.box_startx, hz.box_starty, (hz.box_endx-hz.box_startx)/8, (hz.box_endy-hz.box_starty)/8

 --debug
-- map(16,48, 0,0, 16,15)
 -- map(0,48, 0,0, 16,15)
 -- if (true) return

 local x,y=map_index_to_coords(cur_map)
 x*=16
 y*=15

 -- dirt
 if not draw_ramp and first_pass then
 -- if not draw_ramp then
  palt(5,true)
  palt(15,true)
  pal(6,4)
  pal(8,4)
  pal(9,4)
  pal(13,4)

  map(x,y, 2,2, 16,15)
 -- map(x*16,y*15, 2,-2, 16,15)
 -- map(x*16,y*15, -2,2, 16,15)
  map(x,y, -2,-2, 16,15)

  --palt()
  pal()
 end

 pal(4,13)
 pal(5,13)
 pal(10,13)
 pal(3,13)
 pal(14,0)
 map(x+cx,y+cy, sx,sy, cw,ch)

 -- pal()
 -- palt()
 -- palt(13,true)
 -- palt(0,false)
 -- foreach(placeholders,draw_placeholder)

 -- col ramp
 if draw_ramp then
  palt(1,true)
  palt(2,true)
  palt(5,true)
  palt(6,true)
  palt(8,true)
  palt(9,true)
  palt(10,true)
  palt(11,true)
  palt(12,true)
  palt(13,true)
  pal(3,1)
  pal(4,1)
  pal(14,0)
  map(cx,48+cy, 1+sx,sy, cw,ch)
  palt(3,true)
  pal(4,6)
  pal(14,13)
  -- map(0,48, 0,-1, 16,15)
  map(cx,48+cy, sx,sy-1, cw,ch)
  palt()
 end

-- if (debug_wp) return
 -- hide waypoint sprites 
 for i in all(waypoints) do
  spr(128,i.x,i.y-1)
 end

 -- local hz=bridge[cur_map]
 -- if (hz!=nil) rect(hz.box_startx, hz.box_starty, hz.box_endx, hz.box_endy, 10)
end


function should_hide(p,start_offset)
	local	hz=bridge[cur_map]
	return hz!=nil and hz.box_startx-start_offset<p.x and p.x<hz.box_endx and hz.box_starty-start_offset<p.y and p.y<hz.box_endy
end


outout=""
engine_sfx_max=0
engine_sfx_timer=0
function engine_sfx(s)
 engine_sfx_timer-=1
 if (engine_sfx_timer<=0 or engine_sfx_max<s) sfx(4+flr(4*s/max_speed/2),2) engine_sfx_timer=20 engine_sfx_max=s outout=flr(4*s/max_speed/2)
end


skid_sfx_timer=0
function skid_sfx()
 skid_sfx_timer-=1
 if (skid_sfx_timer<=0) sfx(flr_rnd(2)+1,3) skid_sfx_timer=20
end


function add_skidmarks(c,n)
 if (rnd(3)<1) return
 local side={x=-c.dir.y, y=c.dir.x*0.5} -- perspective
 local offset=plus(muls(c.dir,-2),muls(side,2.5*c.skid))
 plus_in_place(offset,{x=4,y=6})
 c.skid*=-1
 local c2=plus(c,offset)
 local n2=plus(n,offset)
 
 if (abs(flr(c2.x)-flr(n2.x))+abs(flr(c2.y)-flr(n2.y))==0) return
 
 local skid={c2.x,c2.y,n2.x,n2.y}
 if should_hide(c2,1) or should_hide(n2,1) then
  if (c.maybe_hidden) return
  skidmarks_bridge[skid_b_index]=skid
  skid_b_index=skid_b_index%100+1
 else
  skidmarks[skid_index]=skid
  skid_index=skid_index%750+1
 end
 skid_sfx()
end


function draw_skidmarks(s)
 line(s[1],s[2],s[3],s[4],5)
end


function car_collide(c1,c2)
	local dist=distance(c1,c2)
	if (dist<7 and c1.maybe_hidden==c2.maybe_hidden) then
		-- local strength=8-dist
  -- local delta=unit(minus(c1,c2))
		-- muls_in_place(delta,strength*0.5)
		-- plus_in_place(c1.vel,delta)
		-- muls_in_place(delta,-1)
		-- plus_in_place(c2.vel,delta)
  -- local mid=plus(c1,c2)
  -- muls_in_place(mid,0.5)
  local delta=muls(unit(minus(c1,c2)),(8-dist)*0.5)
  plus_in_place(c1.vel,delta)
  plus_in_place(c2.vel,muls(delta,-1))
  local mid=muls(plus(c1,c2),0.5)
  spawn_smoke(mid,7,4)
	end
end

function wall_collide(c,new_pos)
 local test_points={{1,4},{2,2},{4,1},{5,2},{7,4},{6,6},{4,7},{2,6}}
 local push=false
 c.enter_bridge=false
-- local push_dir={x=0,y=0}
 local push_dir=muls(new_pos,0)
 for tp in all(test_points) do
  local npx=new_pos.x+tp[1]
  local npy=new_pos.y+tp[2]
  
  local offset=c.maybe_hidden and 16 or 0
  local t=mget(npx/8+offset,npy/8+48) 

  local sx,sy=tileidx_to_spritecoord(t)
  local p=sget(sx+npx%8,sy+npy%8)

  -- walls
  if 2<p and p<6 then
  	push=true
 	 plus_in_place(push_dir,{x=4-tp[1],y=4-tp[2]})
  end

  if (fget(t,1)) c.enter_bridge=true

  -- oil
  if (p==11 and c.slipping==0) c.slipping=flr(abs(c.speed)/max_speed*25)
  -- water
  if (p==12) c.speed=min(c.speed,0.5*max_speed) spawn_smoke(c,12,3)
  -- grass or snow
  -- if (t==0 and c.speed>0.25*max_speed) spawn_smoke(plus(c,muls(c.dir,-5)),11,2)
  if (t==0 and c.speed>0.25*max_speed) spawn_smoke(plus(c,muls(c.dir,-5)),cur_scenery.particle,2)
 end
 return push,unit(push_dir)
end


function car_physics(c)
 for j=c.i+1,4 do
  car_collide(c,cars[j])
 end

 local persp_vel={x=c.vel.x,y=c.vel.y*2/3}
-- local persp_vel={x=c.vel.x,y=c.vel.y*0.75}
 local new_pos=plus(c,persp_vel)

 local push,push_dir=wall_collide(c,new_pos)
 if push then
  plus_in_place(new_pos,push_dir)
  local n=dot(c.dir,push_dir)
--  if false and n<-0.5 then
--  	plus_in_place(c.vel, muls(push_dir,2))
  	plus_in_place(c.vel, push_dir)
   local smoke_pos=plus(c,muls(push_dir,-4))
   spawn_smoke(smoke_pos,7,4)
--  else
	 	local side={x=-c.dir.y, y=c.dir.x}
--   local n2=dot(side,push_dir)
  	local tu=turn_factor--*4
--   turn(c,n2>0 and tu or -tu)
   turn(c,dot(side,push_dir)>0 and tu or -tu)
--  end
 end

 -- water/oil
 if (c.slipping>0) c.slipping-=1 turn(c,0.05) spawn_smoke(c,0,3)

	-- screen borders
	if (new_pos.x<0) new_pos.x=0 c.vel.x=0
	if (new_pos.x>120) new_pos.x=120 c.vel.x=0
	if (new_pos.y<0) new_pos.y=0 c.vel.y=0
	if (new_pos.y>120) new_pos.y=120 c.vel.y=0

 c.speed*=0.95
 compute_velocity(c)

 if (c.speed>1 and dot(c.dir,unit(c.vel))<0.95) add_skidmarks(c, new_pos)

	c.x=new_pos.x
	c.y=new_pos.y
end


function skill_factor(c,s,v)
 return v+v*c.p.skills[s]*0.1
end


function accelerate(c,s)
 -- applying skill improvements, last racer bonus, and difficulty
 c.speed+=skill_factor(c,2,s)+(car_order[4]==c.i and s or 0)
 c.speed=max(min(c.speed, skill_factor(c,3,max_speed)*(c.ai and 1-0.1*(3-difficulty) or 1)), min_speed)
 compute_velocity(c)
 engine_sfx(c.speed) 
end


function compute_velocity(c)
	local wanted_vel=muls(c.dir, c.speed*0.05);
	muls_in_place(c.vel,0.95)
	plus_in_place(c.vel,wanted_vel)
end


function turn(c,d)
-- d*=min(abs(c.speed), 1)
 d*=min(c.speed, 1)
 c.a+=skill_factor(c,1,d)
 while c.a>1 do c.a-=1 end
 while c.a<0 do c.a+=1 end
 if c.slipping==0 then
  c.dir.x=sin(c.a)
  c.dir.y=cos(c.a)
 end
 compute_velocity(c)
 c.s = (1-2*abs(c.a-0.5))*12.99
 c.f = c.a>0.5
 c.speed*=0.95
 return c
end


function next_waypoint(w,r)
 if r then
  w-=1
  if (w==0) w=#waypoints
 else
  w=w%#waypoints+1
 end
 return w
end


function set_next_waypoint(c,r)
 c.waypoint=next_waypoint(c.waypoint,r)
end


function car_comp(a,b)
 local c1=cars[a]
 local c2=cars[b]
 return c1.wpc<c2.wpc
end


function score_comp(a,b)
 return scores[a]<scores[b]
end


function bubble_sort(a,c)
 local len=#a
 local active=true
 local tmp=nil
 while active do
  active=false
  for i=1,len-1 do
   if c(a[i],a[i+1]) then
    tmp=a[i]
    a[i]=a[i+1]
    a[i+1]=tmp
    active=true
   end
  end
 end
end


-- function near_waypoint(c,w)
--  local delta=minus(waypoints[w],c)
--  local min_dist=c.ai and 12 or 16
--  return abs(delta.x)<min_dist and abs(delta.y)<min_dist
-- end


function check_waypoint(c)
 local delta=minus(waypoints[c.waypoint],c)
 local min_dist=c.ai and 12 or 16
 --local min_dist=12
 local dist_to_wp=max(abs(delta.x),abs(delta.y))
 c.dist_to_wp=min(c.dist_to_wp,dist_to_wp)
 if dist_to_wp<min_dist then
--	if near_waypoint(c,c.waypoint) then
  c.dist_to_wp=1000
  c.wp_time=cur_time
  set_next_waypoint(c,reverse)
 	if ((reverse and c.waypoint==1) or (not reverse and c.waypoint==#waypoints)) c.can_lap=true
  if (not c.finished) c.wpc+=1
  c.missed=false
-- elseif near_waypoint(c,next_waypoint(c.waypoint,reverse)) then
 elseif not c.ai and dot(delta,c.dir)<0 and dist_to_wp>c.dist_to_wp then
  c.missed=true
 end
 --unblock
 if (c.ai and c.wp_time+180<cur_time) c.wp_time=cur_time set_next_waypoint(c,not reverse) c.wpc-=1
--wrench
 for w in all(wrenches) do
  delta=minus(w,c)
  dist_to_wp=max(abs(delta.x),abs(delta.y))
  if (dist_to_wp<6) del(wrenches,w)  players[c.i].nb_wrenches+=1
 end
 -- lap line
 local x,y=map_index_to_coords(cur_map)
 local t=mget(x*16+c.x/8,y*16+c.y/8)
 -- local x=flr(cur_map%8)*16
 -- local y=flr(cur_map/8)*16
 -- local t=mget(x+c.x/8,y+c.y/8)
 if c.can_lap and fget(t,7) then
  c.flag_timer=30
 	c.lap+=1
  if (c.lap==lap and max_lap>lap) drop_wrench()
  lap=min(max_lap,max(lap,c.lap+1))
 	c.lap_time=cur_time
 	c.can_lap=false
  c.wpc+=1
  if (not last_lap and c.lap==max_lap-1) last_lap=true last_lap_timer=60 
  if not c.finished and c.lap==max_lap then
   add(finished,c.i)
   c.finished=true
   scores[c.i]+=4-#finished
   --c.ai=true
   race_over=true
   race_over_timer=180
  end
 end
 return c.lap>=max_lap and 1 or 0
end


function drive(c)
	local wanted_dir=unit(minus(waypoints[c.waypoint],c))
	local d=dot(c.dir,wanted_dir)
 if d<0.995 then
 	local side={x=-c.dir.y, y=c.dir.x}
  -- if dot(side,wanted_dir)<0 then
	 -- 	turn(c,-turn_factor)
	 -- else
	 -- 	turn(c,turn_factor)
	 -- end
  turn(c,dot(side,wanted_dir)<0 and -turn_factor or turn_factor)
	end
	if (d>0.75 or c.speed<1) accelerate(c,acceleration)
end


function _update()
 cur_screen.update()
end


function print_outlined(t,x,y,c,oc)
	for i=x-1,x+1 do
	 for j=y-1,y+1 do
	  print(t,i,j,oc)
	 end
	end
 print(t,x,y,c)
end


function draw_tree(t)
 spr(t.c,t.x+t.o,t.y-8,t.w,2)
end


function draw_tree_shadow(t)
 spr(t.s,t.x+t.so,t.y+8,t.w,1)
end


function draw_tree_shadow_on_car(t)
 for i=1,4 do
  local c=cars[i]
--  if t.x-4<=c.x and c.x<=t.x+4 and t.y-4<=c.y and c.y<=t.y+4 then
--if true then
   pal(1,car_colors_shadow[i])
   clip(c.x+2,c.y+2,4,4)
--   spr(46,t.x-1,t.y+5,2,1)
   spr(t.s,t.x+t.so-1,t.y+5,t.w,1)
--  end
 end
end


function join(i)
 playing[i]=true set_screen(join_screen)
end


start_screen=
{
 init=function()
  -- timer=0
  demo_timer=150
--  for i=1,4 do
--   playing[i]=false
--  end
  playing={false,false,false,false}
  init_victory()
 end,

 update=function()
  demo_timer-=1
  if (demo_timer<=0) set_screen(demo_screen) return
  -- timer+=1
  update_victory()
  for i=1,4 do
--   if (btnp(4,i-1)) playing[i]=true set_screen(join_screen)
   if (btnp(4,i-1)) join(i)
  end
 end,

 draw=function()
  cls()

  map(0,30,0,16,16,2)
  map(16,30,0,32,16,2)
  map(32,30,0,48,16,2)
  map(48,30,0,64,16,2)
  map(64,30,0,80,16,2)
  map(80,30,0,96,16,2)

  print("press button to start",22,112,demo_timer)
  
  draw_victory()
 end
}


join_screen=
{
 init=function()
  timer=150
  scores={0,0,0,0}
  maps_done=0
  victory=false
  -- players={}
  -- for i=1,4 do
  --  add(players,create_player())
  -- end
  players={create_player(),create_player(),create_player(),create_player()}
 end,

 update=function()
  timer-=1
  local nb_playing=0
  for i=1,4 do
   if btnp(4,i-1) then
    if playing[i] then
     timer=max(0,timer-30)
    else
     playing[i]=true
     timer=150
    end
   end
   nb_playing+=(playing[i] and 1 or 0)
  end
  if (nb_playing==4) timer=0
  if (timer==0) set_screen(options_screen)
 end,

 draw=function()
  my_cls(13)
  for i=1,4 do
   local x,y=draw_player_corner(i)
--   local y=32+i*16
   x+=16
   print_outlined("player "..i,x,y+24,car_colors[i],0)
   y+=40
   if playing[i] then
    print_outlined(" ready!",x,y,car_colors[i],0)
   else
    print_outlined(" join?",x+2,y,car_colors_shadow[i],0)
   end
  end
  print_outlined(flr(timer/30)+1,62,62,7,0)
 end
}


-- circuit_screen=
-- {
--  init=function()
--  end,

--  update=function()
--   for i=1,4 do
--    if (btnp(4,i-1)) set_screen(garage_screen) --set_screen(game_screen)
--   end
--  end,

--  draw=function()
--   cls()
--   draw_all_circuits()
--  end
--  }

function my_cls(c)
  rectfill(0,0,127,127,c)
end

function draw_opt_go(o,sel)
 print_outlined(o.s,54,option_y+10,sel and 10 or 6)
end

function draw_opt(o,sel)
 local option_x=32
 print_outlined(o.s,option_x,option_y,sel and 10 or 6)
 if (sel) spr(48,option_x-8,option_y+option_l,1,1,true) spr(48,94,option_y+option_r)
end

function draw_opt_n(o,sel)
 draw_opt(o,sel)
 -- local value_x=90
 -- if (o.val>9) value_x-=4
 -- local value_x=(o.val>9) and 86 or 90
 print_outlined(o.val,(o.val>9) and 86 or 90,option_y,sel and 10 or 6)
 option_y+=10
end

function draw_opt_b(o,sel)
 draw_opt(o,sel)
 -- local value_x=90
 -- spr(o.val and 159 or 143,value_x-1,option_y)
 spr(o.val and 159 or 143,89,option_y)
 option_y+=10
end

function set_n(o,inc)
 o.val+=inc
 if (o.val>o.max) o.val=1
 if (o.val<1) o.val=o.max
end

function set_b(o)
 o.val=not o.val
end

function set_go()
 difficulty=options[1].val
 max_lap=options[2].val
 nb_maps=options[3].val
 -- reverse=options[4].val
 -- rnd_order=options[5].val
 -- tracks random order
 local all_circuits={}
 for i=0,15 do
  add(all_circuits,i)
 end
 circuits={}
 for i=0,nb_maps-1 do
  local c=all_circuits[flr_rnd(#all_circuits)+1]
  circuits[i]=c
  del(all_circuits,c)
 end
 cur_map=circuits[0]
 reverse=(flr_rnd(2)==1)
-- cur_map=4
-- reverse=true
 set_screen(game_screen)
end

options={
 {s="difficulty",val=2,max=3,set=set_n,d=draw_opt_n},
 {s="laps nb",val=4,max=12,set=set_n,d=draw_opt_n},
 {s="circuits nb",val=4,max=16,set=set_n,d=draw_opt_n},
 -- {s="reverse",val=false,set=set_b,d=draw_opt_b},
 -- {s="random order",val=false,set=set_b,d=draw_opt_b},
 {s="start",val="",set=set_go,d=draw_opt_go}
}

options_screen=
{
 init=function()
  -- cur_time=0
  -- selected=#options
  selected=1
 end,

 update=function()
  -- cur_time+=1
  option_l=0
  option_r=0
  local o=options[selected]
  if (btnp(0)) o:set(-1) option_l+=1
  if (btnp(1)) o:set(1) option_r+=1
  if (btnp(2)) selected-=1
  if (btnp(3)) selected+=1
  if (selected<1) selected=#options
  if (selected>#options) selected=1
--  selected=max(1,min(selected,#options))
  if (btnp(4) and selected==#options) set_go()
 end,

 draw=function()
  my_cls(13)
  print_outlined("settings",48,28,7)
  option_y=48
  for o in all(options) do
   o:d(o==options[selected])
  end
  -- if (cur_time>10) print_outlined("press a to continue",26,100,7)
  -- if (cur_time>20) cur_time=0
 end 
}


  -- local o=options[selected]
  -- if (btnp(0)) o:set(-1)
  -- if (btnp(1)) o:set(1)
  -- if (btnp(2)) selected-=1
  -- if (btnp(3)) selected+=1
  -- if (selected<1) selected=#options
  -- if (selected>#options) selected=1


--skills={"handling","acceleration","max speed","  continue"}
skills={"handling","acceleration","max speed"}

function draw_skill(x,y,i,p)
 local c=p.selected_skill==i and 9 or 5
 if (p.nb_wrenches>0) c+=1
 print_outlined(skills[i],x,y+i/4,c)
 if (i==4) return
 for w=0,4 do
  spr(w<p.skills[i] and 35 or 36,x+w*10,y+6)
 end
end


function draw_player_corner(i)
 local x=((i-1)%2)*64
 local y=flr((i-1)/2)*64
 rect(x,y,x+63,y+63,car_colors[i])
 return x,y
end


function draw_garage(i)
 local x,y=draw_player_corner(i)
 local p=players[i]
 skills[4]=timer>20 and "  continue" or "   "..p.nb_wrenches.." left"
 if (p.nb_wrenches==0) skills[4]="    done"
 for s=1,#skills do
  draw_skill(x+8,y+5,s,p)
  y+=16
 end
end


function spend(p)
 p.skills[p.selected_skill]+=1
 p.nb_wrenches-=1
end


garage_screen=
{
 init=function()
  done={}
  for i=1,4 do
   players[i].selected_skill=1
   done[i]=false
  end
 end,

 update=function()
  timer+=1
  if (timer>40) timer=0
  local nb_done=0
  for i=1,4 do
   local p=players[i]
   local all_maxed=p.handling==5 and p.acceleration==5 and p.max_speed==5
   if (p.nb_wrenches==0 or all_maxed) done[i]=true

   if done[i] then
    nb_done+=1
   elseif playing[i] then
    if (btnp(2,i-1)) p.selected_skill-=1
    if (btnp(3,i-1)) p.selected_skill+=1
    if (p.selected_skill<1) p.selected_skill=#skills
    if (p.selected_skill>#skills) p.selected_skill=1
    if btnp(4,i-1) then
     if p.selected_skill==#skills then
      done[i]=true
     elseif p.nb_wrenches>0 then
      spend(p)
     end
    end
   else
    p.selected_skill=flr_rnd(3)+1
    spend(p)
   end
  end
  if nb_done==4 then
   race_over_timer+=1
   if (race_over_timer>90) set_screen(game_screen)
  end
 end,

 draw=function()
  my_cls(13)
--  print_outlined("settings",48,20,7)
  for i=1,4 do
   draw_garage(i)
  end
 end 
}


function update_confetti(c)
 c.x+=(rnd(10)-2)/10
 if (c.x>127) c.x=-7
 c.y+=rnd(10)/5
 if (c.y>127) c.y=-7
-- c.f=rnd(10)>5
 c.f=flr_rnd(3)+16
end


function draw_confetti(c)
 pal(7,c.c)
-- spr(48,c.x,c.y,1,1,c.f)
 spr(c.f,c.x,c.y)
end


function init_victory()
 victory=true
 confetti={}
 for i=1,50 do
  add(confetti,{x=rnd(127),y=-rnd(127),f=flr_rnd(2),c=flr_rnd(9)+6})
 end
end


function update_victory()
 foreach(confetti,update_confetti)
end


function draw_victory()
 palt(13,true)
 foreach(confetti,draw_confetti)
 pal()
end


function draw_race_result()
 print_outlined("race over",46,40,7) 
 cnt={"1st","2nd","3rd","4th"}
 for i=1,#finished do
  print_outlined(cnt[i], 38, 40+10*i,7)
  print_outlined("p"..finished[i], 54, 40+10*i,car_colors[finished[i]])
  local score=4-i
  print_outlined("+"..score.." = "..scores[finished[i]], 66, 40+10*i,7)
 end
end


function draw_champ_result()
 bubble_sort(champ,score_comp)
 print_outlined("overall",48,40,7) 
 for i=1,4 do
  print_outlined(cnt[i], 38, 40+10*i,7)
  print_outlined("p"..champ[i], 54, 40+10*i,car_colors[champ[i]])
  print_outlined(scores[champ[i]].." pts", 66, 40+10*i,7)
 end
end

function car_shadows_state()
  palt(0,false)
  palt(13,true)
  for i=0,15 do 
   pal(i, 1)
  end
end

game_screen=
{
 init=function()
  cur_time=0
  timer=150
  race_over_timer=0
  read_map()
  cars={}
  car_order={}
  for i=1,4 do
   add(cars, turn(create_car(i),0))
   cars[i].ai=not playing[i]
   add(car_order,i)
  end
 end,

 draw=function()
  pal()

  my_cls(cur_scenery.color)

  draw_map(true)

  car_shadows_state()
  foreach(placeholders,draw_car_shadow)
  foreach(wrenches,draw_car_shadow)
  foreach(cars, draw_car_shadow)
  -- for c in all(cars) do
  --  spr(c.s,c.x+1,c.y+1,1,1,c.f)
  -- end

  pal()

  foreach(skidmarks,draw_skidmarks)
  foreach(skidmarks_bridge,draw_skidmarks)

  pal(11,0) --oil
 -- palt()
  palt(13,true)
  palt(0,false)
  foreach(placeholders,draw_placeholder)
  foreach(wrenches,draw_placeholder)
  
--  palt(13,true)
  foreach(trees,draw_tree_shadow)

  pal() --oil
  foreach(smokes, draw_smoke)

  draw_cars()

  pal()
 -- palt()
   palt(13,true)
  foreach(trees,draw_tree)
  foreach(trees,draw_tree_shadow_on_car)
  clip()

  -- foreach(smokes, draw_smoke)

--  pal()

  if (last_lap and last_lap_timer>0) last_lap_timer-=1 print_outlined("last lap",50,60,7)
  if race_over then
   if (victory) draw_victory()
   race_over_timer-=1
   if race_over_timer>90 then 
    draw_race_result()
    if (#finished<3) race_over_timer+=1
   else
    draw_champ_result()
--if (race_over_timer<2) race_over_timer=180 --debug
   end
  end

--  print("car_order[i] - cars[i].order",0,0,7)
--  for i=1,4 do print(cars[i].slipping,0,7*i,1) end

--  print_outlined("lap"..lap.."/"..max_lap,0,122,7,0)
  print_outlined("t:"..maps_done.."/"..nb_maps.." l:"..lap.."/"..max_lap,0,122,7,0)

  for i=1,4 do
   local c=cars[car_order[i]]
   c.score_pos=((16*(i-1)+60)+c.score_prev)/2
   c.score_prev=c.score_pos
   -- print_outlined("p"..c.i..":"..c.lap,c.score_pos,122,car_colors[c.i],c.ai and 5 or 0)
   print_outlined("l:"..c.lap,c.score_pos,122,car_colors[c.i],c.ai and 5 or 0)
  end

  -- debug bridge
 -- local sz=bridge[cur_map]
 -- if (sz!=nil) rect(sz.shadow_startx, sz.shadow_starty, sz.shadow_startx+sz.shadow_width, sz.shadow_starty+sz.shadow_height, 10)
 print(outout,0,0,7)

  if (timer>0) print_outlined(flr(timer/30)+1,62,60,7,0)

  if (race_over_timer<0) print_outlined("press button to continue",16,100,7,0)

--  if (pause) print_outlined("pause",54,60,7,0)
 end,

 update=function()
  if (timer>0) timer-=1 return
  cur_time+=1
  local nb_finished=0
  for i=0,3 do
   local c=cars[i+1]
   nb_finished+=check_waypoint(c)
   if not c.ai then
    if (btn(0,i)) turn(c,-turn_factor)
    if (btn(1,i)) turn(c,turn_factor)
    if btn(2,i) or btn(4,i) then
     accelerate(c,acceleration)
     if (race_over_timer<0) set_screen(start_screen)
    end
    if (btn(3,i)) accelerate(c,deceleration)
    if (btnp(5,i)) pause=true
   else
    drive(c)
   end
   car_physics(c)
   foreach(smokes, update_smoke)
  end

  bubble_sort(car_order,car_comp)

  if victory then
   update_victory()
--   if (race_over_timer<0) set_screen(start_screen)
  elseif nb_finished>=3 and race_over_timer<=0 then
   maps_done+=1
   if maps_done==nb_maps then
    init_victory()
    race_over_timer+=180
   else
    cur_map=circuits[maps_done]
    reverse=(flr_rnd(2)==1)
    set_screen(garage_screen)
   end
  end
 end,
}


demo_screen=
{
 init=function()
  demo_timer=300
  cur_map=flr_rnd(16)
  game_screen.init()
  timer=0
  victory=false
 end,

 update=function()
  demo_timer-=1
  if (demo_timer<=0) set_screen(start_screen) return
  game_screen.update()
  for i=0,3 do
   if (btnp(4,i)) join(i+1)
   end
 end,

 draw=function()
  game_screen.draw()
  print_outlined("demo",56,60,7)
  print_outlined("press a to start",32,112,demo_timer)
 end
}


result_screen=
{
 init=function()
 end,

 update=function()
 end,

 draw=function()

 end
}


function _draw()
 screen_transition()

 --perf
 --line(0,126,127*(stat(1)-1),127,8)
 --line(0,127,127*stat(1),127,9)
end
