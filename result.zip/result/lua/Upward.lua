--upward
--by matthias

a=true
function _init()
b()
c()
d()
if(e()) f.g="piracy"
h()
i()
j(f.k)
end
function _update()
if(f.g=="start"or f.g=="start_downward") l()
if(f.g=="play") then
foreach(m,n)
foreach(o,p)
q()
r()
s()
end
end
function _draw()
if(f.g=="start"or f.g=="start_downward") t()
if(f.g=="play") u()
if(f.g=="screenshot") v()
if(f.g=="piracy") w()
end
function b()
poke(0x5f2d,1)
end
function c()
palt(0,false)
palt(15,true)
end
function x()
print("level: "..tostr(f.k),0,0,0)
print("entities: "..count(m),0,6,0)
print("x: "..tostr(y.z),0,12,0)
print("y: "..tostr(y.ba),0,18,0)
end
function bb(bc,bd)
rectfill(0,56,127,72,bd)
print(bc,64-#bc*2,62,7)
end
function be(bf,bg,bh,bi)
local bj={
bk=bf,
z=bg,
ba=bh,
spr=bi,
bl=0}
return bj
end
function n(bm)
bm.bk(bm)
end
function bn(bm)
spr(bm.spr,bm.z,bm.ba,1,1,bm.bo==-1)
end
function bp(bq)
bq.z+=bq.br
bq.ba+=bq.bs
end
function bt(bq)
if(bq.bs<0) then
bq.bs+=bq.bu
if(bv(bq)) bq.bs=0
end
if(bq.bs>=0) then
bq.bs+=bq.bw
if(bq.bs>bq.bx) bq.bs=bq.bx
if(not bq.by and bz(bq)) then
if(not bq.ca) then
bq.ca=true
sfx(1)
local cb=cc(bq.z,bq.ba-(bq.ba%8)+7,rnd(.2)*-1-.2,0,1.2,0,7)
local cd=cc(bq.z+7,bq.ba-(bq.ba%8)+7,rnd(.2)+.2,0,1.2,0,7)
add(o,cb)
add(o,cd)
end
bq.bs=0
bq.ba=bq.ba-(bq.ba%8)
end
end
end
function ce(bq,cf,cg,ch,ci,cj)
if(bq.ba<0) return false
ck=fget(mget(flr((bq.z+cf+cl*8)/8),flr((bq.ba+cg+cm*8)/8)),cj)
cn=fget(mget(flr((bq.z+ch+cl*8)/8),flr((bq.ba+ci+cm*8)/8)),cj)
return ck or cn
end
function co(bq,cj)
local cf=-bq.cp
local ch=7+bq.cq
local cg=8
local ci=8
return ce(bq,cf,cg,ch,ci,cj)
end
function bz(bq)
return co(bq,0)
end
function cr(bq)
return co(bq,1)
end
function cs(bq)
return co(bq,2)
end
function ct(bq)
return co(bq,4) and mget(flr((bq.z+cl*8)/8),flr((bq.ba+16+cm*8)/8))!=0
end
function cu(bq,ba)
local cf=-bq.cp
local ch=7+bq.cq
local cg=ba
local ci=ba
local cj=3
return ce(bq,cf,cg,ch,ci,cj)
end
function bv(bq)
return cu(bq,0)
end
function cv(bq)
return cu(bq,-8)
end
function cw(bq,z)
local cf=z
local ch=z
local cg=8
local ci=8
local cj=0
return not ce(bq,cf,cg,ch,ci,cj)
end
function cx(bq)
return cw(bq,8)
end
function cy(bq)
return cw(bq,-1)
end
function cz(bq)
return cw(bq,-1) and cw(bq,8)
end
function da(bq,z)
local cf=z
local ch=z
local cg=0
local ci=7
local cj=3
return ce(bq,cf,cg,ch,ci,cj)
end
function db(bq)
return da(bq,-1)
end
function dc(bq)
return da(bq,8)
end
function dd(de,df)
if((de.z-de.cp<=df.z+8+df.cq) and
(de.z+8+de.cq>=df.z-df.cp) and
(de.ba-de.dg<=df.ba+8+df.dh) and
(de.ba+8+de.dh>=df.ba-df.dg)) then
return true
else
return false
end
end
function di()
m={}
for dj=0,15 do
for dk=0,15 do
dl=dk+cl
dm=dj+cm
if(mget(dl,dm)>=16 and mget(dl,dm)<=19) then
dn=0 dp=16
if(mget(dl,dm)==18 or mget(dl,dm)==19) then
dn=4
dp=18
end
if(not f.dq) then
local dr=ds(dk*8+dn,dj*8)
add(m,dr)
end
mset(dl,dm,dp)
end
if(mget(dl,dm)==29) then
local dt=du(dk*8,dj*8)
add(m,dt)
end
if(mget(dl,dm)==31) then
local dt=dv(dk*8,dj*8)
add(m,dt)
end
if(mget(dl,dm)==44) then
local dw=dx(dk*8,dj*8)
add(m,dw)
end
if(mget(dl,dm)==40) then
local dw=dy(dk*8,dj*8)
add(m,dw)
end
if(mget(dl,dm)>=59 and mget(dl,dm)<=63) then
dz=1
ea=59
if(mget(dl,dm)==62 or mget(dl,dm)==63) then
dz=-1
ea=62
end
if(not f.dq) then
local eb=ec(dk*8,dj*8,dz)
add(m,eb)
end
mset(dl,dm,ea)
end
if(mget(dl,dm)>=54 and mget(dl,dm)<=58) then
dz=1
ea=54
if(mget(dl,dm)==57 or mget(dl,dm)==58) then
dz=-1
ea=57
end
if(not f.dq) then
local eb=ed(dk*8,dj*8,dz)
add(m,eb)
end
mset(dl,dm,ea)
end
if(mget(dl,dm)==48 or mget(dl,dm)==49 or mget(dl,dm)==39) then
local dp=39
if(not f.dq) then
local ee=ef(dk*8,dj*8)
add(m,ee)
dp=48
end
mset(dl,dm,dp)
end
if(mget(dl,dm)==20 or mget(dl,dm)==21) then
if(not f.dq) then
local eg=eh(dk*8,dj*8)
add(m,eg)
end
mset(dl,dm,20)
end
if(mget(dl,dm)>=36 and mget(dl,dm)<=38) then
local dp=38
if(not f.dq) then
local ei=ej(dk*8,dj*8)
add(m,ei)
dp=36
end
mset(dl,dm,dp)
end
if(mget(dl,dm)==22 or mget(dl,dm)==23) then
if(not f.dq) then
local eg=ek(dk*8,dj*8)
add(m,eg)
end
mset(dl,dm,22)
end
if(mget(dl,dm)>=25 and mget(dl,dm)<=27) then
local dp=27
if(not f.dq) then
local ei=el(dk*8,dj*8)
add(m,ei)
dp=25
end
mset(dl,dm,dp)
end
if(mget(dl,dm)==7) then
local em=en(dk*8,dj*8)
add(m,em)
end
if(mget(dl,dm)==13 or mget(dl,dm)==14) then
local eo=ep(dk*8+4,dj*8)
add(m,eo)
mset(dl,dm,13)
end
if(mget(dl,dm)==200) then
local eq=er(dk*8,dj*8)
add(m,eq)
end
end
end
end
function es(et)
for eu=1,count(et) do
if(et[eu].ev=="enemy_black_right") then
local eb=ec(et[eu].z,et[eu].ba,1)
add(m,eb)
end
if(et[eu].ev=="enemy_black_left") then
local eb=ec(et[eu].z,et[eu].ba,-1)
add(m,eb)
end
if(et[eu].ev=="enemy_white_right") then
local eb=ed(et[eu].z,et[eu].ba,1)
add(m,eb)
end
if(et[eu].ev=="enemy_white_left") then
local eb=ed(et[eu].z,et[eu].ba,-1)
add(m,eb)
end
if(et[eu].ev=="broken_ground") then
local ew=ef(et[eu].z,et[eu].ba)
add(m,ew)
mset(flr(et[eu].z/8+cl),flr(et[eu].ba/8+cm),48)
end
if(et[eu].ev=="ms_blob") then
local ew=ex(et[eu].z,et[eu].ba)
add(m,ew)
end
end
end
function e()
local ey={
0,
'',
'127.0.0.1',
'localhost',
'lexaloffle.com',
'www.lexaloffle.com',
'pocketfruit.itch.io',
'playpico.com',
'www.playpico.com'
}
local ez=stat(102)
local fa=true
for de in all(ey) do
if(ez==de) fa=false
end
if(sub(ez,-14)=='.ssl.hwcdn.net') fa=false
return fa
end
function w()
if(not fb) fb=stat(102)
cls()
print("you are playing this game from",0,0,8)
print("an unauthorized website.",0,6,8)
print("please visit",0,18,8)
print("pocketfruit.itch.io",0,24,7)
print("to play a legitimate copy.",0,30,8)
print("please help to avoid piracy",0,42,8)
print("and properly support the author",0,48,8)
print("of this game.",0,54,8)
print("thank you.",0,66,8)
print("domain: "..fb,0,78,9)
end
function d()
f={}
f.k=1
f.fc=31
f.fd=0
f.fe=0
f.ff=0
f.fg=0
f.fh=nil
f.g="start"
f.dq=false
f.x=false
f.fi=false
f.fj=-48
f.fk=false
f.fl=0
f.fm=false
f.bl=0
end
function h()
if(a) then
cartdata("mtths_upward")
a=false
end
f.k=dget(0)
if(f.k>15) f.g="start_downward"
f.fe=dget(1)
if(f.k==nil or f.k==0) fn()
end
function fo()
dset(0,f.k)
dset(1,f.fe)
end
function fn()
f.k=1
dset(0,f.k)
f.fe=0
dset(1,f.fe)
end
function u()
rectfill(0,0,127,127,7)
map(cl,cm)
foreach(m,bn)
if(y.eo) spr(14,y.z-3,y.ba-2)
spr(y.spr,y.z,y.ba)
foreach(o,fp)
if(fq.fr and not fq.fs) bb("oh yeah",8)
if(fq.ft) bb("oh no",0)
if(fq.fu) bb("there must be a way",0)
if(fq.fv and fq.bl<=75) bb("you got medicine",8)
if(fq.fv and fq.bl>75) bb("this is heavy...",8)
if(fq.fw) fq.fx+=1
if(fq.fw and fq.fx>30 and not fq.fu) then
y.bb="   stuck? push ⬅️+➡️"
y.fy=90
fq.fw=false
fq.fx=0
end
if(f.fm) spr(216,4,4)
if(y.bb and not fq.fu) then
fz=y.bb
if(f.k!=31) rectfill(y.z-#fz*2+3,y.ba-8,y.z+#fz*2+3,y.ba-8+4,7)
print(fz,y.z-#fz*2+3,y.ba-8,0)
end
if(fq.ga) bb("the end",0)
if(fq.gb) then
rectfill(0,73,127,89,7)
local fz="deaths: "..tostr(f.fd)
print(fz,64-#fz*2,75,0)
local fz="time: "..f.fh
print(fz,64-#fz*2,83,0)
fz="made with ♥ by matthias falk"
print(fz,64-#fz*2-2,119,6)
end
if(f.fi) x()
end
function t()
rectfill(0,0,127,127,7)
map(cl,cm)
if(y.eo and f.k==15) spr(14,y.z-3,y.ba-2)
spr(y.spr,y.z,y.ba)
local cg=f.fj*1
if(cg>8) cg=8
local ci=f.fj*1
if(ci>16) ci=16
if(f.g=="start_downward") rectfill(22,0+cg,105,16+cg,0)
if(f.g=="start") sspr(0,96,64,16,32,1+cg)
if(f.g=="start_downward") sspr(0,112,80,16,24,1+cg)
fz="jump: 🅾️/⬆️"
if(f.g=="start_downward") fz="down: 🅾️/⬇️"
if(f.fj>60 and f.fl%3==0) then
rectfill(64-#fz*2-3,76,64+#fz*2-3,80,7)
print(fz,64-#fz*2-3,76,0)
end
if(f.k>1 and f.fj>60 and not f.fk) then
fz="new game? push ❎❎❎"
rectfill(64-#fz*2-3,100,64+#fz*2-3,104,7)
print(fz,64-#fz*2-3,100,6)
end
fz="made with ♥ by matthias falk"
print(fz,64-#fz*2-2,135-ci,6)
end
function l()
if(f.fj==0) music(1)
f.fj+=1
if(not f.fk and f.fj>60 and(f.g=="start"and(btnp(2) or btnp(4) or stat(34)==1) or(f.g=="start_downward"and(btnp(3) or btnp(4) or stat(34)==1)))) then
music(-1)
f.fk=true
sfx(8)
end
if(f.fk) then
f.fl+=1
if(f.fl>90) then
if(f.g=="start_downward") then
f.dq=true
y.gc="downward"
end
f.g="play"
f.fj=-64
f.fl=0
f.fk=false
menuitem(1,"retry level",gd)
end
end
if(f.k>1 and f.fj>60 and btnp(5)) fq.ge+=1
if(f.k>1 and f.fj>60 and fq.ge==3) then
fn()
f.k=1
f.dq=false
f.g="start"
j(f.k)
music(-1)
f.fk=true
sfx(8)
end
end
function v()
rectfill(0,0,127,127,7)
map(48,32)
sspr(0,96,64,16,32,56)
fz="made with ♥ by matthias falk"
print(fz,64-#fz*2-2,119,6)
end
function s()
if(f.k==6 and y.z>126) gf()
if((stat(34)==1 and stat(32)<16 and stat(33)<16) or btn(0) and btn(1)) then
if(not fq.fr and not fq.ft and not fq.fu and not fq.gg) gd()
end
if(f.x and btnp(0)) gh()
if(f.x and btnp(1)) gf()
if(fq.fr) then
f.bl+=1
if(f.bl>60) fq.fs=true
if(f.bl>75 and fq.gi==false) then
if(cs(y)) then
y.z+=1
else
fq.gi=true
gj(y.gk)
end
end
if(fq.fs and(y.ba<-24 or y.z>127)) gf()
end
if(y.ba>127) then
if(f.dq and not fq.ft and not fq.fu and not(f.k>=24 and f.k<=27)) then
gf()
else
gl()
end
end
if(f.k>=24 and f.k<=27 and y.z<-2) gf()
if(fq.ft) then
f.bl+=1
if(f.bl>30) then
j(f.k)
f.fd+=1
end
end
if(fq.fv) then
fq.bl+=1
if(fq.bl>180) then
fq.fv=false
fq.bl=0
fq.gm=true
end
end
if(fq.gm) then
fq.gm=false
fq.bl=0
f.g="start_downward"
end
if(fq.gg) then
if(fq.gn==1) then
f.bl+=1
y.gc="cutscene"
if(f.bl==30) y.z=64
if(f.bl==60) then
y.eo=false
y.spr=6
local eo=ep(y.z,y.ba-8)
eo.gc="use"
add(m,eo)
end
end
if(fq.gn==2) then
f.bl+=1
if(f.bl==30) y.spr=2
if(f.bl==90) fq.go.spr=10
if(f.bl==120) fq.go.gc="idle"
if(f.bl>150 and f.bl<180) y.bb="♥  "
if(f.bl==240) fq.go.gc="moving"
if(f.bl>240 and y.z<140) y.z+=.5
if(y.z==140) then
fq.go.br=0
fq.go.gc="idle"
end
if(f.bl==360) fq.ga=true
if(f.bl==420) fq.gb=true
if(f.bl>420 and(btnp(4) or stat(34)==1)) then
music(-1)
fn()
_init()
end
end
end
if(stat(34)==1) f.fm=true
end
function i()
gp={}
local gq={
cl=0,cm=0,
gr=60,gs=96,
}
add(gp,gq)
local gt={
cl=16,cm=0,
gr=60,gs=96,
}
add(gp,gt)
local gu={
cl=32,cm=0,
gr=60,gs=96,
}
add(gp,gu)
local gv={
cl=48,cm=0,
gr=28,gs=96,
m={
{ev="enemy_white_right",
z=64,ba=56},
{ev="enemy_white_left",
z=80,ba=32}
}
}
add(gp,gv)
local gw={
cl=64,cm=0,
gr=4,gs=8,
}
add(gp,gw)
local gx={
cl=80,cm=0,
gr=4,gs=80,
}
add(gp,gx)
local gy={
cl=96,cm=0,
gr=4,gs=80,
}
add(gp,gy)
local gz={
cl=112,cm=0,
gr=60,gs=96,
}
add(gp,gz)
local ha={
cl=0,cm=16,
gr=92,gs=100,
}
add(gp,ha)
local hb={
cl=16,cm=16,
gr=20,gs=100,
}
add(gp,hb)
local hc={
cl=32,cm=16,
gr=60,gs=100,
}
add(gp,hc)
local hd={
cl=48,cm=16,
gr=60,gs=100,
}
add(gp,hd)
local he={
cl=64,cm=16,
gr=16,gs=100,
}
add(gp,he)
local hf={
cl=80,cm=16,
gr=24,gs=100,
}
add(gp,hf)
local hg={
cl=96,cm=16,
gr=60,gs=100,
}
add(gp,hg)
local hh={
cl=80,cm=16,
gr=60,gs=4,
dq=true
}
add(gp,hh)
local hi={
cl=64,cm=16,
gr=104,gs=4,
dq=true,
m={
{ev="enemy_black_right",
z=16,ba=32},
{ev="enemy_white_right",
z=48,ba=32},
{ev="enemy_black_right",
z=80,ba=32},
{ev="enemy_white_right",
z=60,ba=80},
}
}
add(gp,hi)
local hj={
cl=48,cm=16,
gr=88,gs=4,
dq=true,
m={
{ev="enemy_white_right",
z=48,ba=80},
{ev="broken_ground",
z=24,ba=88},
{ev="enemy_white_right",
z=24,ba=80},
}
}
add(gp,hj)
local hk={
cl=32,cm=16,
gr=80,gs=4,
dq=true,
m={
{ev="enemy_white_right",
z=48,ba=80},
{ev="broken_ground",
z=32,ba=64},
{ev="broken_ground",
z=40,ba=64},
{ev="broken_ground",
z=48,ba=64},
{ev="broken_ground",
z=88,ba=64}
}
}
add(gp,hk)
local hl={
cl=16,cm=16,
gr=60,gs=4,
dq=true,
m={
{ev="enemy_white_left",
z=104,ba=56}
}
}
add(gp,hl)
local hm={
cl=0,cm=16,
gr=20,gs=4,
dq=true,
m={
{ev="enemy_white_left",
z=48,ba=80}
}
}
add(gp,hm)
local hn={
cl=112,cm=0,
gr=92,gs=4,
dq=true,
m={
{ev="enemy_white_right",
z=32,ba=56},
{ev="enemy_white_left",
z=88,ba=80}
}
}
add(gp,hn)
local ho={
cl=96,cm=0,
gr=60,gs=4,
dq=true
}
add(gp,ho)
local hp={
cl=112,cm=16,
gr=60,gs=4,
dq=true
}
add(gp,hp)
local hq={
cl=0,cm=32,
gr=120,gs=80,
dq=true,
m={
}
}
add(gp,hq)
local hr={
cl=16,cm=32,
gr=120,gs=80,
dq=true,
m={
{ev="enemy_white_right",
z=6,ba=32}
}
}
add(gp,hr)
local hs={
cl=32,cm=32,
gr=112,gs=32,
dq=true,
m={
{ev="enemy_white_left",
z=120,ba=32}
}
}
add(gp,hs)
local ht={
cl=32,cm=0,
gr=112,gs=32,
dq=true,
m={
{ev="enemy_white_left",
z=120,ba=32},
{ev="enemy_white_right",
z=52,ba=56},
{ev="enemy_black_right",
z=48,ba=80}
}
}
add(gp,ht)
local hu={
cl=16,cm=0,
gr=60,gs=4,
dq=true,
m={
{ev="enemy_black_left",
z=64,ba=32},
{ev="enemy_black_right",
z=48,ba=56}
}
}
add(gp,hu)
local hv={
cl=0,cm=0,
gr=60,gs=4,
dq=true
}
add(gp,hv)
local hw={
cl=48,cm=32,
gr=60,gs=4,
dq=true,
m={
{ev="ms_blob",
z=56,ba=104}
}
}
add(gp,hw)
hx()
end
function j(k)
cl=gp[k].cl
cm=gp[k].cm
gr=gp[k].gr
gs=gp[k].gs
hx()
hy(gr,gs)
f.dq=false
if(gp[k].dq) then
f.dq=true
y.gc="downward"
y.eo=true
end
di()
if(gp[k].m) es(gp[k].m)
end
function hx()
fq={}
fq.fr=false
fq.ft=false
fq.fu=false
fq.fs=false
fq.gi=false
fq.hz=false
fq.ia=false
fq.ib=false
fq.ic=false
fq.id=0
fq.bl=0
fq.gm=false
fq.fv=false
fq.gg=false
fq.gn=1
fq.ga=false
fq.gb=false
fq.go=nil
fq.ie=0
fq.ig=false
fq.fw=false
fq.fx=0
fq.ge=0
fq.m={}
o={}
f.bl=0
end
function r()
if(fq.ib) then
fq.bl+=1
if(fq.bl>3) then
fq.ib=false
fq.bl=0
end
end
if(fq.ic) then
fq.id+=1
if(fq.id>15) then
fq.ic=false
fq.id=0
end
end
if(f.k==24 and fq.ig==false) then
fq.ie+=1
if(fq.ie>120) then
fq.ig=true
local eb=ed(120,32,-1)
add(m,eb)
end
end
end
function gd()
gl()
fq.fu=true
end
function gf()
f.k=mid(1,f.k+1,f.fc)
f.fe+=time()-f.ff
fo()
j(f.k)
f.ff=time()
end
function gh()
f.k=mid(1,f.k-1,f.fc)
j(f.k)
end
function hy(z,ba)
y={}
y.gc="idle"
y.ih=false
y.ii=false
y.by=false
y.z=z
y.ba=ba
y.cp=-1
y.cq=-1
y.dg=-1
y.dh=0
y.br=0
y.bs=0
y.bu=.4
y.bw=.6
y.bx=4
y.gk=-5
y.ij=-5
y.ca=true
y.ik=0
y.bl=0
y.il=0
y.spr=1
y.eo=false
y.bb=nil
y.fy=0
end
function q()
y.ih=btnp(2) or btnp(4) or(stat(34)==1 and stat(32)>16 and stat(33)>16)
y.ii=btnp(3) or btnp(4) or(stat(34)==1 and stat(32)>16 and stat(33)>16)
if(y.gc!="cutscene") im()
if(y.gc=="idle") io()
if(y.gc=="downward") ip()
if(y.gc=="dead") iq()
bp(y)
if(y.br!=0) y.br*=.8
if(y.gc!="dead") bt(y)
if(y.ik>0) y.ik-=1
end
function im()
if(y.bs<0) then
y.bl+=.7
y.spr=(y.bl/3)+3
y.spr=mid(3,y.spr,5)
y.ca=false
elseif(y.bs>0) then
y.bl-=1
y.spr=(y.bl/3)+5
y.spr=mid(3,y.spr,5)
y.ca=false
else
y.bl=0
y.spr=2
end
if(y.gc=="dead") y.spr=6
end
function io()
if(y.ih and bz(y) and y.bs==0) gj(y.gk)
if(not btn(2) and y.bs<y.ij) y.bs=y.ij
ir()
if((btn(0) or btn(1)) and f.k<5) then
y.bb="i can only jump"
y.fy=30
end
if(y.fy>0) y.fy-=1
if(y.fy==0) y.bb=nil
end
function ip()
if(y.il>0) y.il-=1
if(y.il==0) y.by=false
if(y.ii and ct(y) and y.bs==0) then
y.by=true
y.il=5
end
ir()
end
function gj(is)
sfx(0)
if(not cv(y)) then
y.bs=is
else
y.bs=-1
end
end
function ir()
if(cr(y) and y.bs==0) y.z-=1
if(cs(y) and y.bs==0) y.z+=1
end
function gl()
if(not fq.ft==true) then
fq.ft=true
sfx(4)
y.gc="dead"
y.bs=-2.5
end
end
function iq()
y.bs+=.4
if(y.bs>4) y.bs=4
y.ba+=y.bs
end
function ds(bg,bh)
local dr=be(
it,
bg,bh,17)
dr.cp=0
dr.cq=0
dr.dg=0
dr.dh=0
add(m,dr)
end
function it(bm)
if dd(y,bm) then
if(not fq.fr and y.gc!="dead") then
fq.fr=true
y.gc="won"
local cb=cc(bm.z,bm.ba+4,-2,.4,2.4,9,9)
local cd=cc(bm.z+7,bm.ba+4,2,.4,2.4,9,9)
add(o,cb)
add(o,cd)
local cb=cc(bm.z,bm.ba+4,-1,.2,2,9,7)
local cd=cc(bm.z+7,bm.ba+4,1,.2,2,9,7)
add(o,cb)
add(o,cd)
del(m,bm)
music(0)
end
end
end
function dx(bg,bh)
return be(
iu,
bg,bh,44)
end
function iu(bm)
bm.bl+=.5
bm.spr=(bm.bl/4)%4+44
end
function dy(bg,bh)
return be(
iv,
bg,bh,40)
end
function iv(bm)
bm.bl+=.5
bm.spr=(bm.bl/4)%4+40
end
function du(bg,bh)
local iw=be(
ix,
bg,bh,29)
iw.iy=-1
return iw
end
function ix(bm)
bm.bl+=1
if(bm.bl>30) then
if(bm.iy==-1) then
local iz=ja(bm.z-4,bm.ba,bm.iy)
add(m,iz)
else
local iz=ja(bm.z+4,bm.ba,bm.iy)
add(m,iz)
end
bm.bl=0
sfx(7)
end
end
function dv(bg,bh)
local iw=du(bg,bh)
iw.spr=31
iw.iy=1
return iw
end
function ja(bg,bh,bo)
if(bo==-1) then
jb=28
jc=-2
jd=0
je=-3
if(f.k==14) jc=-1
else
jb=30
jc=2
jd=-3
je=0
if(f.k==14) jc=1
end
local iz=be(
jf,
bg,bh,jb)
iz.jg="bullet"..tostr(rnd(128))
iz.jh=jc
iz.cp=jd
iz.cq=je
iz.dg=-2
iz.dh=-2
return iz
end
function jf(bm)
if(dd(bm,y)) gl()
bm.z+=bm.jh
if(bm.z<-10 or bm.z>138) then
for ji in all(m) do
if(ji.jg==bm.jg) del(m,ji)
end
end
end
function ef(bg,bh)
local ee=be(
jj,
bg,bh,49)
ee.jk=false
return ee
end
function jj(bm)
if(y.ba+8==bm.ba and(y.z-y.cp<bm.z+8) and(y.z+8+y.cq>bm.z)) bm.jk=true
if(bm.jk) then
bm.bl+=1
bm.spr=49+(bm.bl*.125)
if(bm.spr>54) bm.spr=54
if(bm.bl>40) then
bm.jk=false
mset(flr(bm.z/8+cl),flr(bm.ba/8+cm),39)
del(m,bm)
end
end
end
function eh(bg,bh)
local eg=be(
jl,
bg,bh,21)
eg.cp=0
eg.cq=0
eg.dg=0
eg.dh=0
return eg
end
function jl(bm)
if dd(bm,y) then
fq.hz=true
fq.ib=true
local cb=cc(bm.z,bm.ba+4,-1,0,2,0,7)
local cd=cc(bm.z+7,bm.ba+4,1,0,2,0,7)
add(o,cb)
add(o,cd)
del(m,bm)
sfx(5)
end
end
function ej(bg,bh)
return be(
jm,
bg,bh,37)
end
function jm(bm)
if(fq.hz) then
local cb=cc(bm.z+4,bm.ba,0,-2,2,0,7)
local cd=cc(bm.z+4,bm.ba+7,0,2,2,0,7)
add(o,cb)
add(o,cd)
mset(flr(bm.z/8+cl),flr(bm.ba/8+cm),38)
del(m,bm)
end
end
function ek(bg,bh)
local eg=be(
jn,
bg,bh,23)
eg.cp=0
eg.cq=0
eg.dg=0
eg.dh=0
return eg
end
function jn(bm)
if dd(bm,y) then
fq.ia=true
fq.ib=true
local cb=cc(bm.z,bm.ba+4,-1,0,2,0,0)
local cd=cc(bm.z+7,bm.ba+4,1,0,2,0,0)
add(o,cb)
add(o,cd)
del(m,bm)
sfx(5)
end
end
function el(bg,bh)
return be(
jo,
bg,bh,26)
end
function jo(bm)
if(fq.ia) then
local cb=cc(bm.z+4,bm.ba,0,-2,2,0,0)
local cd=cc(bm.z+4,bm.ba+7,0,2,2,0,0)
add(o,cb)
add(o,cd)
mset(flr(bm.z/8+cl),flr(bm.ba/8+cm),27)
del(m,bm)
end
end
function en(bg,bh)
local em=be(
jp,
bg,bh,7)
em.cp=-1
em.cq=-1
em.dg=-4
em.dh=0
return em
end
function jp(bm)
if(dd(bm,y)) gl()
end
function ep(bg,bh)
local eo=be(
jq,
bg,bh,14)
eo.br=0
eo.bs=0
eo.cp=0
eo.cq=0
eo.dg=0
eo.dh=0
eo.gc="normal"
eo.jr=false
return eo
end
function jq(bm)
if(bm.gc=="use") then
bm.bs=0
if(bm.ba>92) then
bm.bs=-.25
else
bm.jr=true
end
if(bm.jr) then
bm.bl+=1
if(bm.bl>60) then
js(bm)
sfx(20)
fq.gn=2
f.bl=0
del(m,bm)
end
end
bp(bm)
end
if(bm.gc=="normal") then
if(dd(bm,y)) then
fq.fv=true
y.gc="none"
y.eo=true
js(bm)
sfx(20)
music(11)
del(m,bm)
end
end
end
function js(bm)
local cb=cc(bm.z,bm.ba+4,-2,0,3,8,9)
local cd=cc(bm.z+7,bm.ba+4,2,0,3,8,9)
add(o,cb)
add(o,cd)
local cb=cc(bm.z,bm.ba+4,-1,0,2,8,9)
local cd=cc(bm.z+7,bm.ba+4,1,0,2,8,9)
add(o,cb)
add(o,cd)
local cb=cc(bm.z,bm.ba+4,-3,0,1,8,9)
local cd=cc(bm.z+7,bm.ba+4,3,0,1,8,9)
add(o,cb)
add(o,cd)
end
function ex(bg,bh)
local go=be(
jt,
bg,bh,12)
go.cp=0
go.cq=0
go.dg=-4
go.dh=0
go.gc="lying"
return go
end
function jt(bm)
if(dd(bm,y) and not fq.gg) then
fq.gg=true
local ju=f.fe+time()-f.ff
local jv=flr(ju/60)
local jw=ju-flr(ju/60)*60
f.fh=tostr(jv).." min "..tostr(jw).." sec"
fq.go=bm
music(7)
end
if(bm.gc!="lying") then
bm.bl+=.5
bm.spr=(bm.bl/2%2)+10
end
if(bm.gc=="moving") then
bm.z+=.5
if(not fq.ic) then
fq.ic=true
sfx(6)
local cb=cc(bm.z,bm.ba+7,-.5,0,2,0,7)
add(o,cb)
end
end
end
function er(bg,bh)
local eq=be(
jx,
bg,bh,200)
eq.cp=-1
eq.cq=-1
eq.dg=-4
eq.dh=0
eq.jk=false
return eq
end
function jx(bm)
if(dd(bm,y) and y.gc!="dead") then
gj(-7)
bm.spr=201
bm.jk=true
end
if(bm.jk) then
bm.bl+=1
if(bm.bl>10) then
bm.spr=200
bm.jy=false
bm.bl=0
end
end
end
function ec(bg,bh,iy)
local eb=be(
jz,
bg,bh,60)
eb.ev="black"
eb.cp=-1
eb.cq=-1
eb.dg=-2
eb.dh=0
eb.br=.5*iy
eb.ka=0
eb.bs=0
eb.bw=.6
eb.bx=4
eb.bo=iy
eb.kb=false
eb.ca=true
return eb
end
function kc(bm)
bm.bl+=.5
bm.spr=(bm.bl/2)%2+60
end
function ed(bg,bh,iy)
local eb=ec(bg,bh,iy)
eb.bk=jz
eb.ev="white"
eb.spr=55
return eb
end
function kd(bm)
bm.bl+=.5
bm.spr=(bm.bl/2)%2+55
end
function jz(bm)
if(bm.ev=="black") kc(bm)
if(bm.ev=="white") kd(bm)
if(not cz(bm) and bm.bs==0) then
if((not fq.ib and cx(bm)) or dc(bm)) bm.bo=-1
if((not fq.ib and cy(bm)) or db(bm)) bm.bo=1
bm.br=.5*bm.bo
else
bm.br=0
end
if(bm.bs>0) bm.ca=false
bp(bm)
bt(bm)
if(dd(bm,y)) then
if(y.ba+7<bm.ba+5 and y.bs>0 and not bm.kb and y.gc!="dead") then
bm.kb=true
gj(-2)
y.ik=10
ke=0
if(bm.ev=="white") ke=7
local cb=cc(bm.z,bm.ba+6,-1,0,2.4,0,ke)
local cd=cc(bm.z+7,bm.ba+6,1,0,2.4,0,ke)
add(o,cb)
add(o,cd)
if(bm.ev=="white"and f.k<5) fq.fw=true
del(m,bm)
end
if(bm.ev=="black"and not bm.kb and y.ik==0) gl()
if(bm.ev=="white"and y.bs==0) then
if(bm.z>y.z and bm.br<0) y.br=bm.br
if(bm.z<y.z and bm.br>0) y.br=bm.br
if(not fq.ic) then
fq.ic=true
sfx(6)
local kf=0
if(bm.bo==-1) kf=8
local cb=cc(bm.z+kf,bm.ba+7,-.5*bm.bo,0,2,0,7)
add(o,cb)
end
end
end
end
function cc(z,ba,br,bs,kg,kh,ke)
ki={}
ki.z=z
ki.ba=ba
ki.br=br
ki.bs=bs
ki.kg=kg
ki.kh=kh
ki.ke=ke
return ki
end
function p(kj)
kj.z+=kj.br
kj.ba+=kj.bs
kj.kg-=.1
if(kj.kg<=0) del(o,kj)
end
function fp(kj)
circfill(kj.z,kj.ba,kj.kg,kj.ke)
circ(kj.z,kj.ba,kj.kg,kj.kh)
end