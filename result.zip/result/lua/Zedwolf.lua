--zEDWOLF
--(mILD iNJUSTICE)
function vec_new(x,y,z)
 return {x=x or 0,y=y or 0,z=z or 0}
end

function vec_add(u,v)
 return vec_new(v.x+u.x,v.y+u.y,v.z+u.z)
end

function vec_sub(u,v)
 return vec_new(u.x-v.x,u.y-v.y,u.z-v.z)
end

function vec_mulscalar(v,scalar)
 return vec_new(v.x*scalar,v.y*scalar,v.z*scalar)
end

function vec_dot(u,v)
 return u.x*v.x+u.y*v.y+u.z*v.z
end

function vec_squarelength(v)
 return v.x*v.x+v.y*v.y+v.z*v.z
end

function vec_squarelength2d(v)
 return v.x*v.x+v.z*v.z
end

function vec_normalize(v)
 local mag=sqrt(vec_squarelength(v))
 return mag==0 and vec_new() or vec_new(v.x/mag,v.y/mag,v.z/mag)
end

function vec_clamp(v,maxv)
 v.x,v.y,v.z=mid(v.x,104,0xff98),mid(v.y,104,0xff98),mid(v.z,104,0xff98)
 return vec_squarelength(v)>maxv^2 and vec_mulscalar(vec_normalize(v),maxv) or v
end

function mesh_new()
 local m=
 {
  vertex={},
  vertexcount=0,
  colour={},
  normal={},
  submesh={},
  offset=vec_new()
 }
 meshlist[mesh_count]=m
 mesh_count+=1
 return m
end

function mesh_addvertex(m,x,y,z)
 m.vertexcount+=1
 m.vertex[m.vertexcount]=vec_new(x,y,z)
end

function mesh_addcolour(m,i)
 m.colour[#m.colour+1]=i or 0
end

function mesh_addnormal(m,n)
 m.normal[#m.normal+1]=n
end

function mesh_addsubmesh(m,cull,shadow,wire,part,pos,maxindex)
 add(m.submesh,{
  vmax=maxindex or m.vertexcount,
  cullfaces=cull,
  isshadow=shadow,
  wireframe=wire,
  particle=part,
  pos=pos or vec_new()
 })
end

function entity_new(mesh)
 local m=meshlist[mesh+0]
 local e=
 {
  state=1,
  mesh=m,
  submesh={},
  pos=vec_new(),
  rot=vec_new(),
  terrainheight=0,
  velocity=vec_new(),
  objectiveid=0,
  health=mid(m.height,20,6)+2,
  icon=mesh
 }
 for i=1,#m.submesh do
  e.submesh[i]={rot=vec_new()}
 end
 return add(entitylist,e)
end

function depthbuffer_index(x,y)
 return flr(x%2560/160)+flr(-y%2560/10)*16
end

function depthbuffer_insert(e)
 local prevdepth,index=e.depth_index,depthbuffer_index(e.pos.x,e.pos.z-e.mesh.radius-0x0.ffff)
 if index!=prevdepth then
  local head,prev,next=depthbuffer[index],e.depth_prev,e.depth_next
  if prev then
   prev.depth_next=next
  elseif prevdepth then
   depthbuffer[prevdepth]=next
  end
  if (next) next.depth_prev=prev
  depthbuffer[index],e.depth_index,e.depth_next,e.depth_prev=e,index,head
  if (head) head.depth_prev=e
 end
end

function qsort(first,last,array)
 if first<last then
  local pivot,lastv=first,array[last].sort
  for s=first,last-1 do
   if array[s].sort<lastv then
    array[s],array[pivot]=array[pivot],array[s]
    pivot+=1
   end
  end
  array[last],array[pivot]=array[pivot],array[last]
  qsort(first,pivot-1,array)
  qsort(pivot+1,last,array)
 end
end

function cos_sin(r)
 return cos(r),sin(r)
end

function gfx_submit(e,bufferoffset,length)
 local start,m,erot,epos,esubmesh,drawquad,index,colindex,lightpal=#vertexbuffer+1,e.mesh,e.rot,e.pos,e.submesh,e.quads,#vertexbuffer+1,1,palette[band((0x0.ffff-globallightlevel*e.state)*9,0xf)%9]
 local function getcol(col)
  if (e.state!=1) col+=0x0.a5a5
  return 0x1000+lightpal[flr(col/16)]*16+lightpal[flr(col%16)]+band(col,0x0.ffff)
 end
 local bufferlength,coloverride,sort_centroids,submesh,submesh_vmax,submesh_idx,mcolour,mvertex,mnormal,idx,px,py,pz,rx,ry,rz=length or m.vertexcount,e.coloverride,m.depthsort,m.submesh,0,0,m.colour,m.vertex,m.normal,bufferoffset or 1,epos.x-camerax,epos.y-m.offset.y-cameray,epos.z-cameraz,erot.x,erot.y,erot.z
 local shadowheight,objxrot,objyrot,objzrot,xrcos,xrsin,yrcos,yrsin,zrcos,zrsin,v3x,v3y,v3z,prjv3x,prjv3y,prjv3z,visible,extra,cullfaces,lpx,lpy,lpz,lrx,lry,lxrcos,lxrsin,lyrcos,lyrsin,localxrot,localyrot,localtranslation,projectshadow=max(e.validheight)-cameray,rx!=0,ry!=0,rz!=0
 if (idx>1) colindex=(bufferoffset-1)/2+1
 if (e.paletteid) colindex+=m.vertexcount/3*e.paletteid
 if (objxrot) xrcos,xrsin=cos_sin(rx)
 if (objyrot) yrcos,yrsin=cos_sin(ry)
 if (objzrot) zrcos,zrsin=cos_sin(rz)
 for n=1,bufferlength/(drawquad and 4 or 3) do
  if idx>=submesh_vmax then
   if (projectshadow) start=#vertexbuffer+1
   submesh_idx+=1
   local smdata,renderdata=submesh[submesh_idx],esubmesh[submesh_idx]
   local localrot,localpos=renderdata.rot,smdata.pos
   submesh_vmax,cullfaces=smdata.vmax,smdata.cullfaces
   visible,projectshadow=not renderdata.hidden,smdata.isshadow
   lpx,lpy=localpos.x,localpos.y
   lpz,lrx=localpos.z,localrot.x
   lry=localrot.y
   localxrot,localyrot=lrx!=0,lry!=0
   if (localxrot) lxrcos,lxrsin=cos_sin(lrx)
   if (localyrot) lyrcos,lyrsin=cos_sin(lry)
   extra,localtranslation=smdata.particle and e.pscale or smdata.wireframe,lpx!=0 or lpy!=0 or lpz!=0
  end
  local vert,renderface=mvertex[idx],visible and not cullfaces
  local v0x,v0y,v0z=vert.x,vert.y,vert.z
  if visible then
   if localtranslation then
    v0x-=lpx
    v0y-=lpy
    v0z-=lpz
   end
   if localxrot then
    local ty,tz=v0y,v0z
    v0y=ty*lxrcos-tz*lxrsin
    v0z=ty*lxrsin+tz*lxrcos
   end
   if localyrot then
    local tx,tz=v0x,v0z
    v0x=tx*lyrcos-tz*lyrsin
    v0z=tx*lyrsin+tz*lyrcos
   end
   if localtranslation then
    v0x+=lpx
    v0y+=lpy
    v0z+=lpz
   end
   if objzrot then
    local tx,ty=v0x,v0y
    v0x,v0y=tx*zrcos-ty*zrsin,tx*zrsin+ty*zrcos
   end
   if objxrot then
    local ty,tz=v0y,v0z
    v0y=ty*xrcos-tz*xrsin
    v0z=ty*xrsin+tz*xrcos
   end
   if objyrot then
    local tx,tz=v0x,v0z
    v0x=tx*yrcos-tz*yrsin
    v0z=tx*yrsin+tz*yrcos
   end
   v0x+=px
   v0y+=py
   v0z+=pz
   if cullfaces then
    local normal=mnormal[n]
    local nx,ny,nz=normal.x,normal.y,normal.z
    if localxrot then
     local ty,tz=ny,nz
     ny=ty*lxrcos-tz*lxrsin
     nz=ty*lxrsin+tz*lxrcos
    end
    if localyrot then
     local tx,tz=nx,nz
     nx=tx*lyrcos-tz*lyrsin
     nz=tx*lyrsin+tz*lyrcos
    end
    if objzrot then
     local tx,ty=nx,ny
     nx=tx*zrcos-ty*zrsin
     ny=tx*zrsin+ty*zrcos
    end
    if objxrot then
     local ty,tz=ny,nz
     ny=ty*xrcos-tz*xrsin
     nz=ty*xrsin+tz*xrcos
    end
    if objyrot then
     local tx,tz=nx,nz
     nx=tx*yrcos-tz*yrsin
     nz=tx*yrsin+tz*yrcos
    end
    renderface=renderface or nx*v0x+ny*v0y+nz*v0z>0
   end
  end
  if renderface then
   vert=mvertex[idx+1]
   local v1x,v1y,v1z=vert.x,vert.y,vert.z
   vert=mvertex[idx+2]
   local v2x,v2y,v2z=vert.x,vert.y,vert.z
   if localtranslation then
    v1x-=lpx
    v1y-=lpy
    v1z-=lpz
    v2x-=lpx
    v2y-=lpy
    v2z-=lpz
   end
   if localxrot then
    local ty,tz=v1y,v1z
    v1y=ty*lxrcos-tz*lxrsin
    v1z=ty*lxrsin+tz*lxrcos
    ty=v2y
    tz=v2z
    v2y=ty*lxrcos-tz*lxrsin
    v2z=ty*lxrsin+tz*lxrcos
   end
   if localyrot then
    local tx,tz=v1x,v1z
    v1x=tx*lyrcos-tz*lyrsin
    v1z=tx*lyrsin+tz*lyrcos
    tx=v2x
    tz=v2z
    v2x=tx*lyrcos-tz*lyrsin
    v2z=tx*lyrsin+tz*lyrcos
   end
   if localtranslation then
    v1x+=lpx
    v1y+=lpy
    v1z+=lpz
    v2x+=lpx
    v2y+=lpy
    v2z+=lpz
   end
   if objzrot then
    local tx,ty=v1x,v1y
    v1x,v1y=tx*zrcos-ty*zrsin,tx*zrsin+ty*zrcos
    tx,ty=v2x,v2y
    v2x,v2y=tx*zrcos-ty*zrsin,tx*zrsin+ty*zrcos
   end
   if objxrot then
    local ty,tz=v1y,v1z
    v1y=ty*xrcos-tz*xrsin
    v1z=ty*xrsin+tz*xrcos
    ty=v2y
    tz=v2z
    v2y=ty*xrcos-tz*xrsin
    v2z=ty*xrsin+tz*xrcos
   end
   if objyrot then
    local tx,tz=v1x,v1z
    v1x=tx*yrcos-tz*yrsin
    v1z=tx*yrsin+tz*yrcos
    tx=v2x
    tz=v2z
    v2x=tx*yrcos-tz*yrsin
    v2z=tx*yrsin+tz*yrcos
   end
   v1x+=px
   v2x+=px
   v1y+=py
   v2y+=py
   v2z+=pz
   v1z+=pz
   if projectshadow then
    v0y=shadowheight
    v1y,v2y=v0y,v0y
   end
   v0y,v1y,v2y=v0y*0x0.ec83-v0z*0xffff.9e08,v1y*0x0.ec83-v1z*0xffff.9e08,v2y*0x0.ec83-v2z*0xffff.9e08
   v0z,v1z,v2z=128/(v0y*0xffff.9e08+v0z*0x0.ec83),128/(v1y*0xffff.9e08+v1z*0x0.ec83),128/(v2y*0xffff.9e08+v2z*0x0.ec83)
   v0x=band(v0x*v0z,0xffff)
   v1x=band(v1x*v1z,0xffff)
   v2x=band(v2x*v2z,0xffff)
   v0y=-band(v0y*v0z,0xffff)
   v1y=-band(v1y*v1z,0xffff)
   v2y=-band(v2y*v2z,0xffff)
   if v2y<v0y then
    v0x,v2x=v2x,v0x
    v0y,v2y=v2y,v0y
   end
   if drawquad then
    local quadv0x,quadv0y,quadv2x,quadv2y=v0x,v0y,v2x,v2y
    vert=mvertex[idx+3]
    v3x=vert.x+px
    v3y=vert.y+py
    v3z=vert.z+pz
    v3y=v3y*0x0.ec83-v3z*0xffff.9e08
    v3z=128/(v3y*0xffff.9e08+v3z*0x0.ec83)
    v3x=band(v3x*v3z,0xffff)
    v3y=-band(v3y*v3z,0xffff)
    if v3y<quadv0y then
     quadv0x,v3x=v3x,quadv0x
     quadv0y,v3y=v3y,quadv0y
    end
    if v3y<quadv2y then
     quadv2x,v3x=v3x,quadv2x
     quadv2y,v3y=v3y,quadv2y
    end
    vertexbuffer[index+1]={quadv0x,quadv0y,quadv2x,quadv2y,v3x,v3y,getcol(mcolour[colindex+1])}
   end
   if v1y<v0y then
    v0x,v1x=v1x,v0x
    v0y,v1y=v1y,v0y
   end
   if v2y<v1y then
    v1x,v2x=v2x,v1x
    v1y,v2y=v2y,v1y
   end
   local vb={v0x,v0y,v1x,v1y,v2x,v2y,getcol(coloverride or mcolour[colindex]),extra}
   if (sort_centroids) vb.sort=v0z+v1z+v2z
   vertexbuffer[index]=vb
   index+=(drawquad and 2 or 1)
  end
  if drawquad then
   idx+=4
   colindex+=2
  else
   idx+=3
   colindex+=1
  end
 end
 if (sort_centroids) qsort(start,#vertexbuffer,vertexbuffer)
end

function gfx_draw()
 poke(0x5f34,1)
 for n=1,#vertexbuffer do
  local vbuf=vertexbuffer[n]
  local v0x,v0y,v1x,v1y,v2x,v2y,ex=vbuf[1],vbuf[2],vbuf[3],vbuf[4],vbuf[5],vbuf[6],vbuf[8]
  color(vbuf[7])
  if ex==true then
   line(v0x,v0y,v1x,v1y)
   line(v1x,v1y,v2x,v2y)
   line(v0x,v0y,v2x,v2y)
  elseif ex then
   circfill(v0x,v0y,ex)
  elseif v0y==v1y then
   rasterizetri_top(v0x,v0y,v1x,v2x,v2y)
  elseif v1y==v2y then
   rasterizetri_bottom(v0x,v0y,v1x,v2x,v2y)
  else
   local newx=v0x+(v1y-v0y)*(v2x-v0x)/(v2y-v0y)
   rasterizetri_bottom(v0x,v0y,newx,v1x,v1y)
   rasterizetri_top(v1x,v1y,newx,v2x,v2y)
  end
  --if (btn"5") flip()
 end
 fillp()
end

function rasterizetri_top(v0x,v0y,v1x,v2x,v2y)
 if (v1x<v0x) v0x,v1x=v1x,v0x
 local height=v2y-v0y
 local dx_left,dx_right=(v2x-v0x)/height,(v2x-v1x)/height
 if (v2y>63) v2y=63
 for y=v0y,v2y do
  rectfill(v0x,y,v1x,y)
  v0x+=dx_left
  v1x+=dx_right
 end
end

function rasterizetri_bottom(v0x,v0y,v1x,v2x,v2y)
 if (v2x<v1x) v1x,v2x=v2x,v1x
 local height=v2y-v0y
 local dx_left,dx_right,xend=(v1x-v0x)/height,(v2x-v0x)/height,v0x
 if (v2y>63) v2y=63
 for y=v0y,v2y do
  rectfill(v0x,y,xend,y)
  v0x+=dx_left
  xend+=dx_right
 end
end

function msq_invalidate()
 msqhead_x+=msq_scanx
 msqhead_x%=7
 msqhead_y+=msq_scany
 msqhead_y%=6
 local targetx,targety,index=(msq_scanx<0 and msqhead_x) or (msq_scanx>0 and (msqhead_x-1)%7),(msq_scany<0 and msqhead_y) or (msq_scany>0 and (msqhead_y-1)%6),0
 for y=0,5 do
  for x=0,6 do
   if (x==targetx or y==targety) msqcache[index]=nil
   index+=1
  end
 end
 msq_scanx,msq_scany=0,0
end

function msq_scan()
 for index=0,41 do
  if not msqcache[index] then
   local ftx,fty=flrterrainx+(index-msqhead_x)%7,flrterrainz+((index-index%7)/7-msqhead_y)%6
   local tx,tx1,ty,ty1=ftx%128,(ftx+1)%128,fty%128+251,(fty+1)%128+251
   local tl,tr,bl,br=readpixel(tx,ty),readpixel(tx1,ty),readpixel(tx,ty1),readpixel(tx1,ty1)
   -- wikipedia.org/wiki/marching_squares
   local miny,case,uv=tl,0,ftx*2%4+fty*8%16
   if (miny>tr) miny=tr
   if (miny>br) miny=br
   if (miny>bl) miny=bl
   tl-=miny
   tr-=miny
   br-=miny
   bl-=miny
   if (tl>0) case+=8
   if (tr>0) case+=4
   if (br>0) case+=2
   if (bl>0) case+=1
   local data,minytex,colcase,heightcase,heightindex,colindex,centroid,tedge,bedge,ledge,redge={},miny+0x0.ffff,marchcolourcases[case],marchheightcases[case],0,0,(tl+tr+br+bl)/4,tl>tr and tr or tl,br>bl and bl or br,tl>bl and bl or tl,br>tr and tr or br
   if (case==5 or case==10) centroid=0
   for quad=0,3 do
    local v0,v1,v2,v3=heightcase[heightindex],heightcase[heightindex+1],heightcase[heightindex+2],heightcase[heightindex+3]
    if quad==0 then
     v0*=tl
     v1*=tedge
     v2*=centroid
     v3*=ledge
    elseif quad==1 then
     v0*=tedge
     v1*=tr
     v2*=redge
     v3*=centroid
    elseif quad==2 then
     v0*=centroid
     v1*=redge
     v2*=br
     v3*=bedge
    else
     v0*=ledge
     v1*=centroid
     v2*=bedge
     v3*=bl
    end
    local tex,maxv1,maxv2=terraintextures[uv+offsets[quad]],v2,v0
    if (quad==0 or quad==2) maxv1,maxv2=v3,v1
    if (maxv1<v0) maxv1=v0
    if (maxv1<v1) maxv1=v1
    if (maxv2<v2) maxv2=v2
    if (maxv2<v3) maxv2=v3
    data[quad]={height_lut[flr(v0+miny)],height_lut[flr(v1+miny)],height_lut[flr(v2+miny)],height_lut[flr(v3+miny)],tex[flr(maxv1*colcase[colindex]+minytex)]+0x0.a5a5,tex[flr(maxv2*colcase[colindex+1]+minytex)]+0x0.a5a5}
    heightindex+=4
    colindex+=2
   end
   msqcache[index]=data
  end
 end
 refreshui=refreshui or gamemode==3
end

function getheight(pos)
 local tpx,tpy=band(128+pos.x/20-flrterrainx,0x7f.ffff),band(256-pos.z/20-flrterrainz,0x7f.ffff)
 local bufx,bufy=band(tpx,0x7f),band(tpy,0x7f)
 if bufx>=0 and bufx<7 and bufy>=0 and bufy<6 then
  local lerpx2,lerpz=tpx-bufx,tpy-bufy
  local quad=lerpx2>0.5 and (lerpz>=0.5 and 2 or 1) or max(lerpz>=0.5 and 3)
  local casedata=msqcache[(msqhead_x+bufx)%7+(msqhead_y+bufy)%6*7][quad]
  local sample1,sample2,sample3,sample4=casedata[1],casedata[2],casedata[3],casedata[4]
  lerpx2*=2
  lerpz*=2
  if (quad==1 or quad==2) lerpx2-=1
  if (quad>=2) lerpz-=1
  local lerpx,lerpz2=1-lerpx2,1-lerpz
  if quad%2==1 then
   lerpx2,lerpx=lerpx,lerpx2
   sample2,sample1=sample1,sample2
   sample3,sample4=sample4,sample3
  end
  if (lerpx2+lerpz<=1) return sample1+lerpx2*(sample2-sample1)+lerpz*(sample4-sample1)
  return sample3+lerpx*(sample4-sample3)+lerpz2*(sample2-sample3)
 end
end

function update_terrain()
 local m,lerpx2,lerpz,xoffset,zoffset,idx=terrain.mesh,terrainposx/10,terrainposz/10,terrainx%1*2,terrainz%1*2,1
 local mvertex,mcolour,lerpx,lerpz2,flipquad,znext=m.vertex,m.colour,1-lerpx2,1-lerpz,(xoffset+zoffset+1)%2,zoffset*7
 local samplelookup,caselookup,quadindexcase0,quadindexcase1,tzeroz={0,xoffset,znext+xoffset,znext},zoffset==0 and {xoffset,1-xoffset,2+xoffset,3-xoffset} or {3-xoffset,2+xoffset,1-xoffset,xoffset},{0,4,52,48},{4,0,48,52},0
 for z=0,5 do
  local quadindex,renderidx,idxinc,tzerox=quadindexcase0,idx,8,0
  for x=0,5 do
   if (x==3) renderidx,quadindex,idxinc=renderidx+16,quadindexcase1,0xfff8
   for quad=1,4 do
    local qidx=renderidx+quadindex[quad]
    if qidx<481 then
     local idx1,idx2,idx3,qcidx=qidx+1,qidx+2,qidx+3,(qidx-1)/2+1
     if (quad%2==flipquad) qidx,idx1,idx2,idx3=idx1,idx2,idx3,qidx
     local quadoffset=samplelookup[quad]
     local quadxoffset=quadoffset%7
     local casedata,zerox,zeroz=msqcache[(msqhead_x+x+quadxoffset)%7+(z+msqhead_y+band((quadoffset-quadxoffset)/7,0xffff))%6*7][caselookup[quad]],tzerox,tzeroz
     if (quad==2 or quad==3) zerox+=10
     if (quad==3 or quad==4) zeroz-=10
     local vert0,vert1,vert2,vert3,v0,v1,v2,v3,onex,onez=mvertex[qidx],mvertex[idx1],mvertex[idx2],mvertex[idx3],casedata[1],casedata[2],casedata[3],casedata[4],zerox+10,zeroz-10
     if x==0 and (quad==1 or quad==4) then
      v0*=lerpx2
      v0+=v1*lerpx
      v3*=lerpx2
      v3+=v2*lerpx
      zerox=10-terrainposx
     end
     if x==5 and (quad==2 or quad==3) then
      v1*=lerpx
      v1+=v0*lerpx2
      v2*=lerpx
      v2+=v3*lerpx2
      onex=120-terrainposx
     end
     if z==0 and (quad==1 or quad==2) then
      v0*=lerpz2
      v0+=v3*lerpz
      v1*=lerpz2
      v1+=v2*lerpz
      zeroz=-terrainposz
     end
     if z>=4 and (quad==3 or quad==4 or z==5) then
      v2*=lerpz
      v2+=v1*lerpz2
      v3*=lerpz
      v3+=v0*lerpz2
      onez=0xffa6-terrainposz
     end
     vert0.y,vert1.y=v0,v1
     vert3.y,vert2.y=v3,v2
     vert0.x,vert1.x=zerox,onex
     vert3.x,vert2.x=zerox,onex
     vert0.z,vert1.z=zeroz,zeroz
     vert3.z,vert2.z=onez,onez
     mcolour[qcidx],mcolour[qcidx+1]=casedata[5],casedata[6]
    else
     return
    end
   end
   renderidx+=idxinc
   tzerox+=20
  end
  idx+=96
  tzeroz-=20
 end
end

function rotatepoint(v0,v1,r)
 local rcos,rsin=cos_sin(r)
 return v0*rcos-v1*rsin,v0*rsin+v1*rcos
end

function lookat(dir)
 local y=atan2(dir.x,dir.z)+0.75
 return vec_new(atan2(dir.y,dir.z*cos(y)-dir.x*sin(y))-0.25,y%1)
end

function rotatetowards(t,r,s)
 t-=r
 t%=1
 if (t>0.5) t-=1
 return r+t*(s or 0.15)
end

function zero_v(e)
 if (not e.numwaypoints) e.velocity=vec_new()
end

function seek(e,t,msd)
 local d=vec_sub(t,e.pos)
 d.y=0
 if playeralive and vec_squarelength2d(d)>=msd then
  e.rot.y,d=rotatetowards(lookat(d).y,e.rot.y),vec_mulscalar(vec_normalize(d),2)
  local h=getheight(vec_add(e.pos,d)) or 0
  if (h>0.025 and h<26) return vec_mulscalar(d,0.1)
 end
 zero_v(e)
end

function rndoffset(e)
 return cos(rnd"2.2")*(e==player and 1 or 9)
end

function firebullet(e,pos,target,dir,velocity,func,vel)
 local ndir,espd=vec_normalize(dir),vel or sqrt(vec_squarelength(e.velocity))
 velocity+=espd
 if target then
  local t=(sqrt(vec_squarelength(vec_sub(pos,target.pos)))+espd)/velocity
  ndir=vec_normalize(vec_sub(vec_add(vec_add(target.pos,vec_mulscalar(target.velocity,t)),vec_new(rndoffset(e),1.5+t-rndoffset(e),rndoffset(e))),pos))
 end
 for i=6,20 do
  local p=entitylist[i]
  if not p.state and gamemode>2 then
   p.state,p.inbounds,p.pos,p.velocity,p.rot,p.owner,p.damping,p.update,p.mesh,p.pt,p.paletteid,p.coloverride,p.updatedheight,p.validheight,p.collision=1,true,vec_add(pos,e.velocity),
   vec_mulscalar(ndir,velocity),lookat(ndir),e,1,func or update_bullet,meshlist[func and 1 or 2],rnd"3",e!=player and not func and 1 or 0
   depthbuffer_insert(p)
   if (not func) sfx(36,e==player and 1 or 2)
   return p
  end
 end
end

function splode(e,s,n,f,p)
 for i=0,n or 0 do
  local b=firebullet(e,vec_add(e.pos,vec_new(0,p or rnd(e.mesh.height),-e.mesh.radius)),nil,vec_new(rnd"1"-0.5,1,rnd"1"-0.5),rnd"2.5"+1,update_particle,0)
  if b then
   b.fadetype=f or 0
   update_particle(b)
  end
 end
 if (s) sfx(s,(s==30 or s==33) and 3 or 2)
end

function spawnplayer()
 vertexbuffer,player.health,fadelight,fadetimer,fadetarget,fadecurrent,globallightlevel,player,refreshui,terrainx,terrainz,flrterrainx,flrterrainz,terrainposx,terrainposz={},min(player.health,5),true,0,0.778,0.3334,0.3334,entitylist[nextplayer+1],true,spawnposx,spawnposz,spawnposx,spawnposz,0,0
 nextplayer+=1
 nextplayer%=3
 player.update,player.state,player.mesh,
 player.pos,fuel,player.health,throttle,geardown,
 player.rot,player.yaw,terrain.pos,
 msqcache,msqhead_x,msqhead_y,msq_scanx,msq_scany,spawned,player.submesh[player.mesh.sm3].rot,player.updatedheight,player.dudelist=
 update_player,1,meshlist[0],
 vec_new(65+terrainx*20,0,0xffd3-terrainz*20),9000,55,0,true,
 vec_new(0,spawnrot),spawnrot,vec_new(),
 {},0,0,0,0,0,
 player.submesh[player.mesh.sm0].rot
 msq_scan()
 update_terrain()
 for i=6,20 do
  entitylist[i].state=nil
 end
end

function update_player(e)
 local v,pitch,animrate,y,erot,target,vx,vz,mesh,force,hasfuel=vec_new(),0,0,e.pos.y,e.rot,0xffff,0,0,e.mesh,0,fuel>0
 playerlanded,playeralive=y<=e.terrainheight+0.2,e.health>0 and hasfuel
 if gamemode>=2 then
  local speed,fvy,fvz,fvx=sqrt(vec_squarelength2d(e.velocity))/mesh.maxspeed,rotatepoint(0,0xffff,erot.x)
  fvx,fvz=rotatepoint(0,fvz,erot.y)
  playerforward=vec_normalize(vec_new(fvx,0,fvz))
  if playeralive then
   target,collision,nearestenemy,deathtype,deathtypedelayed=geardown and 0 or 40.5,e.collision,erot.x<0.05 and nearestenemy
   if gamemode>2 then
    if collision and collision!=terrain and (not playerlanded or collision.update) then
     e.health-=speed*3.6
     splode(e,28)
    end
    if spawned==0 then
     if (btnp"4") geardown=not geardown
     if btn"5" then
      if geardown then
       throttle+=0.05
       target=125
      elseif abs(frame-fireframe)>3 then
       firebullet(e,e.pos,nearestenemy,vec_new(fvx,fvy,fvz),6)
       fireframe=frame
      end
     end
     if not playerlanded or not geardown and throttle>0.5 then
      if (btn"0") vx=0xffff
      if (btn"1") vx+=1
      if (btn"3") vz=0xffff
      if (btn"2") vz+=1
     end
    end
    local vbut=vec_normalize(vec_new(vx,0,vz))
    throttle=mid(throttle+(geardown and 0xffff.fdf4 or 0.02),1)
    pitch,animrate,v=(0.125+(1+sin((frame-(sync or frame)+25)/100))*0.07)*speed*min(y/target,1),max(throttle,0.036),vec_mulscalar(vbut,0.25*throttle)
    if (vec_dot(vbut,playerforward)<0xffff.8000) sync,synced=frame
    if vx!=0 or vz!=0 then
     e.yaw,force=lookat(vbut).y,0.7
    else
     sync,synced=frame
    end
    poke(0x39f7,33-animrate*25.5-speed/0.9-force)
    fuel-=max(animrate,0.5)
   end
  else
   if (hasfuel and frame%3==0) splode(e,nil,rnd"2")
   if (not deathtypedelayed) doflash,deathtypedelayed=hasfuel,not hasfuel and playerlanded and 0 or 3
   if (playerlanded and deathtypedelayed==3) erot.x=0.25
   pitch,throttle=deathtypedelayed/12,max(throttle-0.02)
   if playerlanded and not deathtype then
    deathtype,e.update=deathtypedelayed
    zero_v(e)
    if deathtype==3 then
     e.health,e.state=0,0.2223
     splode(e,33,5,3)
    end
   end
  end
  local dy,ery=target-y,rotatetowards(playerlanded and erot.y or e.yaw,erot.y)
  e.submesh[mesh.sm2].hidden,e.damping,animrate,erot.x=not geardown,playerlanded and 0.5,mid(throttle*0.1,0.07,0.014),rotatetowards(pitch,erot.x)
  e.submesh[mesh.sm0].rot.y+=animrate-ery+erot.y
  e.submesh[mesh.sm1].rot.x-=animrate
  if (abs(dy)<1.75 and not synced) sync,synced=frame,true
  local targetvelocity=mid(1,abs(dy)/2)
  if (dy<0) targetvelocity*=0xffff.8000
  v.y,erot.z,erot.y,nearestenemyangle,nearestenemydist,nearestenemy=(targetvelocity-e.velocity.y)*rotatepoint(1,0,erot.x)*max(throttle,0.5),rotatetowards(ery-e.yaw,erot.z)/2*speed,ery,0x0.7fff,0x7fff
  if speed>0.4 and playerlanded then
   if (playeralive) e.velocity,playerlanded=vec_mulscalar(e.velocity,0xffff.2)
   e.health-=2
   splode(e,28)
  end
  return playeralive and v
 end
end

function update_bullet(e)
 e.rot=lookat(e.velocity)
 local c=e.collision
 if c or not e.inbounds then
  if c then
   if c!=terrain then
    c.health-=0.9
    splode(c,c==player and 28 or 40,1,0,e.pos.y-c.pos.y)
   elseif e.terrainheight==0 then
    splode(e,41,2,1)
   else
    splode(e,34,0,2)
   end
  end
  e.state=nil
 end
end

function update_particle(e)
 local s=flr(e.pt*0.4375)
 e.pscale,e.coloverride,e.state=partsizes[e.fadetype][s],partcols[e.fadetype][s],e.pt<=15 and e.inbounds and 1
 e.pt+=1
end

function update_enemy(e,d)
 if e.inbounds then
  local dist=d or vec_sub(e.pos,player.pos)
  local mag=vec_squarelength2d(dist)
  if mag>250 and (mag<=nearestenemydist or e.icon<(nearestenemy and nearestenemy.icon or 0x7fff)) then
   dist.y=0
   local dp=vec_dot(vec_normalize(dist),playerforward)
   if (dp>=0.5 and dp>nearestenemyangle) nearestenemy,nearestenemyangle,nearestenemydist=e,dp,mag
  end
  return vec_new()
 end
end

function update_turret(e)
 local dist=vec_sub(player.pos,e.pos)
 local rot,em=vec_sub(lookat(vec_normalize(dist)),e.rot),e.mesh
 e.submesh[em.sm0].rot,e.submesh[em.sm1].rot.y=rot,rot.y
 if update_enemy(e,vec_mulscalar(dist,0xffff)) then
  if (max(e.fire)==0) e.bullet,e.fire=firebullet(e,vec_add(e.pos,vec_new(0,em.height)),player,dist,8),10
  e.fire-=rnd()
 end
end

function update_turretseek(e)
 update_turret(e)
 return seek(e,player.pos,210)
end

function update_dudetarget(e)
 if geardown and playerlanded then
  local d,dude=player.dudelist,e.dudelist
  if e.inbounds and d and frame%20==0 then
   player.dudelist,d.state,d.target,d.pos,d.validheight=d.dudelist,1,e,vec_add(player.pos,vec_mulscalar(playerforward,0xfffa)),512
   depthbuffer_insert(d)
   spawned+=1
   sfx(34,1)
  end
  rescued=0
  while dude do
   rescued+=1
   dude=dude.dudelist
  end
 end
end

function update_dude(e)
 local target=e.target or player
 local v=seek(e,target.pos,0)
 if playerlanded then
  if e.collision==target then
   e.dudelist,e.state=target.dudelist
   if (e.target) spawned-=1
   if e.objectiveid>0 then
    target.dudelist=e
    sfx(e.target and 38 or 39,3)
   end
  end
  return v
 end
 e.jumpframe=((e.jumpframe or rnd"19")+0.25+rnd"0.1")%20
 if (e.jumpframe>19) return vec_new(0,0.9)
end

function update_repairbot(e)
 if (fuel<=8550 or player.health<55) and playerlanded then
  local v=seek(e,player.pos,0)
  if e.collision==player then
   sfx(35,2)
   fuel+=45
   v,player.health,fuel=vec_mulscalar(v,0.05),min(player.health+0.55,55),fuel>=8550 and 9000 or fuel
  end
  return v
 end
end

function drawmeter(x,percent,warn)
 sspr(95,6,3,20,x,6,3,20)
 sspr(30,6,3,1,x,6,3,20-max(percent)*20)
 if (gamemode==3 and percent<=0.2) printtext(warn,35,8)
end

function printtext(s,y,c)
 text[#text+1]=vec_new(s,y,c or 3)
end

function printmenu(y,s,l,sel)
 for i=0,l do
  local t=1+(i+s)*33
  printtext(sub(texttable,t,t+31),y+i*6,i==sel and 11)
 end
end

function readpixel(x,y)
 local byte=peek(shr(x,1)+shl(y,6))
 return band(0xf,band(x,1)==0 and byte or shr(byte,4))
end

function readbits(bits)
 local val=0
 for i=0,bits-1 do
  if databit==256 then
   readhead-=1
   databit,databyte=1,peek(readhead)
  end
  if (band(databyte,databit)>0) val+=2^i
  databit*=2
 end
 return val
end

function readfixed()
 return bor(readbits"16",band(shr(readbits"16",16),0x0.ffff))
end

function readvector()
 return vec_new(readfixed(),readfixed(),readfixed())
end

function readloc()
 return vec_mulscalar(vec_new(readbits"10",0,readbits"10"),2.5)
end

function readflag()
 return readbits"1">0
end

function readmeshfloat()
 return readbits"5"/31
end

function readnormal()
 return 2*readmeshfloat()-1
end

function px9decomp(y0)
 local function vlist_val(l,val)
  for i=1,#l do
   if l[i]==val then
    for j=i,2,0xffff do
     l[j]=l[j-1]
    end
    l[1]=val
    return i
   end
  end
 end
 local function gn1(tot)
  local bits=1
  while 1 do
   local vv=readbits(bits)
   tot+=vv
   if (vv<2^bits-1) return tot
   bits+=1
  end
 end
 local w,h,b,el,pr,splen,mode=gn1"1",gn1"0",gn1"1",{},{},0
 for i=1,gn1"1" do
  add(el,readbits(b))
 end
 for y=y0+0,y0+h do
  for x=0,w-1 do
   splen-=1
   if (splen<1) splen,mode=gn1"1",not mode
   local a=y>y0+0 and readpixel(x,y-1) or 0
   local l=pr[a]
   if not l then
    l={}
    for e in all(el) do
     add(l,e)
    end
    pr[a]=l
   end
   local v=l[mode and 1 or gn1"2"]
   vlist_val(l,v)
   vlist_val(el,v)
   local paddr,x2=x/2+y*64,x%2==0
   poke(paddr,bor(band(0x0f,x2 and v or peek(paddr)),band(0xf0,x2 and peek(paddr) or v*16)))
   x+=1
   y+=flr(x/w)
   x%=w
  end
 end
 databit=256
end

function loadmesh()
 local hasnormals,numtris,numsubmeshes,bounds,offset,mesh=readflag(),readbits"8",readbits"8",readvector(),readvector(),mesh_new()
 mesh.offset,mesh.height,mesh.sm0,mesh.sm1,mesh.sm2,mesh.sm3,mesh.depthsort,mesh.physbody,mesh.physreact,mesh.maxspeed,mesh.rotationspeed,mesh.radius=
 offset,bounds.y,readbits"4",readbits"4",readbits"4",readbits"4",readflag(),readflag(),readflag(),readfixed(),readfixed(),max(sqrt(vec_squarelength2d(bounds))*0.5,mesh.physreact and 2 or 5)
 for i=1,numsubmeshes do
  mesh_addsubmesh(mesh,readflag(),readflag(),readflag(),readflag(),readflag() and readvector(),readbits"8")
 end
 for i=1,numtris do
  for v=1,3 do
   mesh_addvertex(mesh,readmeshfloat()*bounds.x+offset.x,readmeshfloat()*bounds.y+offset.y,readmeshfloat()*bounds.z+offset.z)
  end
  if (hasnormals) mesh_addnormal(mesh,vec_new(readnormal(),readnormal(),readnormal()))
 end
 for i=1,numtris*readbits"2" do
  mesh_addcolour(mesh,readbits"4")
 end
 databit,mesh.physradius=256,mesh.radius*0.65
end

function loadarray()
 local bitsize,w,h,a=readbits"8",readbits"8",readbits"8",{}
 for y=0,h do
  local t={}
  for x=0,w do
   t[x]=bitsize==32 and readfixed() or readbits(bitsize)
  end
  if (h==0) return t
  a[y]=t
 end
 return a
end

function loadlevel()
 vertexbuffer,readhead,databit,entitylist,depthbuffer,rescued,nonviolent={},levels[level],256,{},{},0,true
 screenmode"3"
 memcpy(0x7000,0,0x1000)
 reload(0,0,readhead)
 local newrh,updatelist=readbits"16",{update_turret,update_repairbot,update_dude,update_enemy,update_dudetarget,update_turretseek}
 px9decomp"251"
 readhead,newrh=newrh,readhead
 terraintextures,readhead=loadarray(),newrh
 px9decomp"251"
 -- players
 entity_new"0"
 entity_new"0"
 entity_new"0"
 reticle,terrain=entity_new"23",entity_new"24"
 -- particles
 for i=5,19 do
  entity_new"2"
 end
 terrain.quads,height_lut,minimappalette,objectives,spawnposx,spawnposz,spawnrot=true,loadarray(),loadarray(),{},readbits"7",readbits"7",readbits"3"*0.125
 for i=1,readbits"10" do
  local e=entity_new(readbits"5")
  e.paletteid,e.pos,e.rot.y=readbits"1",readloc(),readbits"3"*0.125
  if readflag() then
   e.curwaypoint,e.waypoint=0,{}
   for w=0,readbits"5" do
    e.waypoint[w],e.numwaypoints=readloc(),w+1
   end
  end
  e.objectiveid,e.update=readbits"2",updatelist[readbits"3"]
  depthbuffer_insert(e)
 end
 for i=1,3 do
  objectives[i]={count=readbits"8",x=readbits"7",z=readbits"7",active=readbits"8"}
 end
 memcpy(0,0x7000,0x1000)
 screenmode"0"
end

function drawminimap(x,y,size,zoom)
 local halfwidth=size/2
 local halfzoom,sz=3.25-halfwidth*zoom,size-1
 local maxx,u0,v0=x+sz,flrterrainx+halfzoom,flrterrainz+halfzoom
 local pty=v0
 for j=y,y+sz do
  local ptx=u0
  for i=x,maxx do
   pset(i,j,minimappalette[readpixel(band(ptx,0x7f),band(pty,0x7f)+251)])
   ptx+=zoom
  end
  pty+=zoom
 end
 for i=1,3 do
  local o=objectives[i]
  local px,py=(o.x-u0)%128/zoom,(o.z-v0)%128/zoom
  if (px>=0 and px<=size and py>=0 and py<=size and (o.active>0 or i==3)) circfill(px+x,py+y,1,7+i)
 end
 circfill(x+halfwidth,y+halfwidth,1,12)
end

function toggleminimap()
 if gamemode==3 then
  gamemode=4
 elseif gamemode==4 then
  gamemode,refreshui=3,true
 end
end

function screenmode(v)
 cls()
 flip()
 poke(0x5f2c,v)
end

function _init()
 screenmode"3"
 poke(0x5f1e,0x8f)
 -- sprites
 px9decomp"384"
 memcpy(0,0x7000,0x1000)
 for i=0,23 do
  loadmesh()
 end
 -- sfx
 px9decomp"196"
 music()
 level,terrainmesh,levels,offsets,palette,marchcolourcases,marchheightcases,partcols,partsizes=0,mesh_new(),loadarray(),loadarray(),loadarray(),loadarray(),loadarray(),loadarray(),loadarray()
 for i=0,239 do
  mesh_addvertex(terrainmesh)
  mesh_addvertex(terrainmesh)
  mesh_addcolour(terrainmesh)
 end
 mesh_addsubmesh(terrainmesh)
 loadlevel()
 spawnplayer()
 sspr(64,48,64,16,0,0,128,32)
end

function _draw()
 local drawhud=gamemode>0 and gamemode<4
 memset(0x6800,0,0x1800)
 if drawhud then
  palt(0,false)
  spr(48,0,24,16,1)
  if refreshui then
   spr(0,0,0,16,3)
   refreshui=drawminimap(8,8,16,1)
  end
  palt()
  spr(17,8,8,2,2)
 end
 if gamemode==4 then
  memset(0x6000,0,0x0800)
  drawminimap(79,8,48,2.6667)
  rect(78,7,127,56,6)
  camera(0xffc0,0xffa3)
 else
  camera(0xffc0,0xffc0)
 end
 clip(0,25,128,104)
 gfx_draw()
 clip()
 camera()
 if drawhud then
  spr(48,0,24,16,1)
  palt(0,false)
  drawmeter(30,fuel/9000,"  refuel")
  drawmeter(95,player.health/55,"                        repair")
  spr(64+max(nearestenemy and nearestenemy.icon),108,12)
  palt()
 end
 for d in all(text) do
  print(d.x,d.p,d.y,d.z)
 end
 if doflash then
  flip()
  cls"7"
  refreshui,doflash=true
 end
end

function _update()
 if btnp(4,1) then
  toggleminimap()
 end
 if not fadelight and gamemode>2 then
  if deathtype then
   gamemode,refreshui,globallightlevel,player.mesh,text,nearestenemy=1,true,0x0.ffff,meshlist[deathtype]
   sfx(0xffff,0)
  else
   if (objectives[3].count==rescued and nonviolent or objectives[1].active+objectives[2].active<=0) gamemode,refreshui,fadelight,fadetimer,fadetarget,fadecurrent,text=2,true,true,0,0.3334,globallightlevel
  end
 end
 local playerx,playerz=player.pos.x,player.pos.z
 vertexbuffer,text,terrain.pos.x,terrain.pos.z,camerax,cameray,cameraz={},{},playerx+terrainposx-65,playerz+terrainposz+45,playerx,max(gamemode!=4 and 79 or 105,player.pos.y+38),playerz-(gamemode!=4 and 122 or 195)
 -- spatial search
 local zlist,updatelist,total,strip,xoff,zoff={},{player},1,1,depthbuffer_index(playerx-90,0),depthbuffer_index(0,playerz+90)
 local griddist,zidx=(16+depthbuffer_index(playerx+90,0)-xoff)%16,-((depthbuffer_index(0,playerz+45)-zoff)/16%16)
 for z=0,17 do
  local entities,count={},0
  for x=0,griddist do
   local node=depthbuffer[zoff+(xoff+x)%16]
   while node do
    if node.state then
     local npos=node.pos
     local distz,distx=npos.z-playerz,npos.x-playerx
     if (distx>=2505) npos.x-=2560
     if (distx<0xf637) npos.x+=2560
     if (distz>=2515) npos.z-=2560
     if (distz<0xf62d) npos.z+=2560
     distz,distx=abs(npos.z-playerz),abs(npos.x-playerx)
     local inbounds=distz<=45 and distx<=55
     if inbounds and node.validheight then
      count+=1
      node.sort,entities[count]=-npos.z,node
     end
     if node.update and distx+distz<=100 or inbounds or node.inbounds then
      if node!=player then
       total+=1
       updatelist[total]=node
      end
     else
      node.velocity,node.updatedheight,node.validheight,node.terrainheight=vec_new()
      if (node.owner) node.state=nil
     end
     node.inbounds=inbounds
    end
    node=node.depth_next
   end
  end
  if (zidx>=0) zlist[zidx]={e=entities,count=count}
  zoff+=16
  zoff%=4096
  zidx+=1
 end
 -- draw frame
 if #vertexbuffer==0 then
  for z=0,11 do
   if (z<10) gfx_submit(terrain,strip,48)
   strip+=48
   local zslice=zlist[z]
   qsort(1,zslice.count,zslice.e)
   for n=1,zslice.count do
    gfx_submit(zslice.e[n])
   end
  end
 end
 if nearestenemy and playeralive then
  reticle.pos=vec_add(nearestenemy.pos,vec_new(0,(nearestenemy.mesh.height-reticle.mesh.height)/2))
  reticle.rot.z-=0.02
  gfx_submit(reticle)
 end
 -- update next frame
 terrainposx-=player.velocity.x
 terrainposz-=player.velocity.z
 if terrainposx>=10 then
  terrainposx-=10
  terrainx+=127.5
  terrainx%=128
  flrterrainx=flr(terrainx)
  if (terrainx!=flrterrainx) msq_scanx-=1
 elseif terrainposx<0 then
  terrainposx+=10
  terrainx+=0.5
  terrainx%=128
  flrterrainx=flr(terrainx)
  if (terrainx==flrterrainx) msq_scanx+=1
 end
 if terrainposz<0 then
  terrainposz+=10
  terrainz+=127.5
  terrainz%=128
  flrterrainz=flr(terrainz)
  if (terrainz!=flrterrainz) msq_scany-=1
 elseif terrainposz>=10 then
  terrainposz-=10
  terrainz+=0.5
  terrainz%=128
  flrterrainz=flr(terrainz)
  if (terrainz==flrterrainz) msq_scany+=1
 end
 if msq_scanx!=0 or msq_scany!=0 then
  msq_invalidate()
  msq_scan()
 end
 update_terrain()
 for i=1,total do
  local e=updatelist[i]
  local nextpos,speed2,nextv,em=e.pos,0,e.velocity,e.mesh
  if not e.updatedheight then
   local theight=getheight(nextpos)
   e.updatedheight,e.validheight,e.terrainheight=theight,theight,theight or 0
   depthbuffer_insert(e)
  end
  if e.state==1 then
   if e!=player and e.health<=0 then
    doflash,e.state,nonviolent=true,0.2223
    splode(e,30,15,3)
   elseif e.update then
    local accelforce,maxspeed,nvy=e.update(e),em.maxspeed
    if not accelforce and e.numwaypoints then
     -- update waypoints
     local wpdist=vec_sub(e.waypoint[e.curwaypoint%e.numwaypoints],nextpos)
     local dx,dz=wpdist.x%2560,wpdist.z%2560
     if (dx>1280) dx-=2560
     if (dz>1280) dz-=2560
     wpdist=vec_mulscalar(vec_new(dx,0,dz),0.01)
     local dir=vec_normalize(wpdist)
     if vec_squarelength2d(wpdist)<0.00075 then
      if e.numwaypoints==1 then
       maxspeed=0
      else
       e.curwaypoint+=1
      end
     else
      e.rot.y,accelforce=rotatetowards(lookat(dir).y,e.rot.y,em.rotationspeed),vec_mulscalar(dir,maxspeed)
     end
    end
    -- update position
    nextpos,nextv,e.collision=vec_add(nextpos,nextv),vec_add(vec_mulscalar(e.velocity,e.damping or 0.95),accelforce or vec_new())
    nvy,nextv=nextv.y,vec_clamp(nextv,maxspeed)
    nextpos.x%=2560
    nextpos.z%=2560
    speed2,nextv.y=vec_squarelength2d(nextv),nvy-0.5
    if speed2>0.002 then
     e.updatedheight=nil
    else
     nextv.x,nextv.z=0,0
    end
    e.velocity,e.pos=nextv,nextpos
   end
   if (e.state!=1 and e.objectiveid>0) objectives[e.objectiveid].active-=1
  elseif e.update==update_dudetarget then
   rescued=0
  end
  if nextpos.y<=e.terrainheight then
   e.collision,nextpos.y,nextv.y=terrain,e.terrainheight,max(nextv.y)
  end
  -- update collisions
  if speed2>0 or nextv.y!=0 then
   for j=1,total do
    if j!=i then
     local e2=updatelist[j]
     local em2=e2.mesh
     if em2.physbody and e.owner!=e2 then
      local d,h2=vec_sub(nextpos,e2.pos),em2.height
      local dy,sqdist=d.y,vec_squarelength2d(d)
      if dy<=h2 and dy>=-em2.physradius and sqdist>=0 and sqdist<=(em.physradius+em2.physradius)^2 then
       d.y=dy>0 and max(dy-h2+em.height) or dy
       local b=vec_dot(vec_sub(nextv,e2.velocity),d)
       if b<=0 then
        e.collision=e2
        if em.physreact then
         sqdist+=0x0.0001 -- / 0
         h2*=h2 -- h^2 = mass
         e.velocity=vec_clamp(vec_sub(nextv,vec_mulscalar(d,2*h2/(em.height^2+h2)*b/sqdist)),min(2.5,em.maxspeed*2))
        end
       end
      end
     end
    end
   end
  end
 end

 if fadelight then
  fadetimer+=0x0.1110
  fadelight,globallightlevel=fadetimer<0.97,fadecurrent+fadetimer*(fadetarget-fadecurrent)
  if not fadelight and gamemode==2 then
   sfx"0xffff"
   music"21"
  end
 elseif gamemode<3 then
  if menuscr==0 and (btnp"2" or btnp"3") then
   menusel+=1
   menusel%=2
  end
  if btnp"4" then
   if gamemode==0 then
    menuscr+=1
    menuscr%=2
    if (menuscr==1 and menusel==0) gamemode=3
   else
    if gamemode==2 then
     level+=1
     level%=#levels+1
     loadlevel()
    end
    gamemode=3
    spawnplayer()
   end
   if gamemode==3 then
    music"0xffff"
    sfx(29,0)
    menuitem(1, "toggle minimap", toggleminimap)
   end
  elseif gamemode==0 then
   if menuscr==0 then
    printmenu(44,0,1,menusel)
   else
    printmenu(32,2,5,5)
   end
  elseif gamemode==1 then
   poke(0x39f7,33)
   printmenu(48,18+deathtype,2,2)
  else
   printmenu(48,24,2,2)
   local resc,d=rescued,player.dudelist
   while d do
    resc+=1
    d=d.dudelist
   end
   printtext("                        "..resc.."/"..objectives[3].count,60)
  end
  if gamemode==0 then
   printtext("incoming transmission...                                 welcome to z-squadron, commander.   your main objectives are shown in red + orange on the minimap.   pacify all defenses + structures near these locations.   evac friendlies to field stations marked yellow on the map.   good luck. we're counting on you.                                  ★ credits ★ a game by andy green ◆ uses px9 by zep ◆ thanks to sebastian grinke + bob wade",123)
   text[#text].p=147-frame%1900
  end
 elseif gamemode==4 then
  printmenu(12,8+5*level,4,6)
 end
 frame+=1
 frame%=5700
end

meshlist,mesh_count,
frame,fireframe,readhead,databit,gamemode,
menusel,menuscr,player,nextplayer,
texttable=
{},0,
0,0xfffd,0x4300,256,0,
0,0,{},0,
[[
       new game                 
       controls                 
       ⬆️⬇️⬅️➡️ : movement          
       🅾️       : gear up/down   
       ❎       : fire/hover     
       shift/w  : mission log   
                                
       🅾️: back                  
✽mission✽                       
neutralize airbase              
disable oil field               
웃side웃                          
rescue friendlies               
✽mission✽                       
subdue radar site               
liberate depot                  
웃side웃                          
rescue friendlies               
       missing in action        
                                
          🅾️ : continue          
        killed in action        
                                
          🅾️ : continue          
        mission complete        

   friendlies rescued :         

          🅾️ : continue]]