--kelin's delivery: rain
--biolardi "vsio neithr" yoshogi
--twitter.com/vsios

vers,vl,t,f,n="v1.2.1",-1,true,false,nil bla,dbl,dpu,dgr,bro,dgr,ltg,whi,red,ora,yel,gre,blu,ind,pin,pea=0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 b_l,b_r,b_u,b_d,b_o,b_x=0,1,2,3,4,5 s_ui,s_cg_pm,s_mvx,s_got=0,1,2,3 m_ryn,m_hrain=1,2 fc_d,fc_l,fc_r,fc_u,pl_anms,bt,bp=1,2,3,4,{{1,2,1,3},{17,18,17,19},{33,34,33,35},{49,50,49,51}},btn,btnp c_k,c_o="kelin","old man"nth_msg,usto_nth_msg="nothing interesting in front of me.","i don't have any idea what to do with them both."is_dbg_md,is_3=f,t pzm_ap,pzm_oa="abandoned_path","outside_abandoned"

function it_sts()it_gm()it_ttl()it_crd()it_otr()st_to("title")end
function it_iv_itms()dt_ivitm={}local o=o_itm_id o_vr1=192o"the package i must deliver to the client."o"a pack of fried noodle. simple to cook with hot water."o"a map so i can find the client's place easily."o"a sharp dagger to defend myself."o"a long stick."o"a key with blue tag."o"a key with red tag."o"a rusty old shovel."o"an empty bottle."o"a bottle with green liquid. the label says \"soap\"."o"an old bucket."o"a used lantern. it is full of leftover candle on the bottom."o"a note. it says \"whoever sees the back of the sky will be rewarded the next guide\". huh?"o"another note. it says \"seek under the place where useless stuffs gather.\". hmm..."o"a strainer. can be used to split noodle and hot water."o"a strainer with noodle on it."o"a cooking oil bottle."o"a dried instant noodle."o"a seasoning for noodle."o"an opened seasoning pack."o"a cleaned bowl."o"a dirty bowl."o"a small box of matches."o"an empty lantern. it has spot to hold candle tightly in the middle."o"a lantern with a candle."o"a lantern with lit candle."o"a candle."o"a cut sheet."o"a cleaned spoon."o"a dirty spoon."o"a pan."o"a bottle of water."o_vr1=238o"a rusty bronze key."o"a rusty bronze key. a lump is attached to it."o_vr1=254o"a dirty pan."o"a shovel head."iv_o={192,194,195}end

function mk_cb(cb,vls)dt_cb[cb]=vls end
function it_cb_itms()dt_cb={}local m,c,a=o_cb_msg,o_cb_cpy,mk_cb a("193,195",{1,{209,210},"kelin cut the noodle pack. inside were a dried noodle and a seasoning pack."})a("195,210",{2,{211},"kelin cut the seasoning pack open."})a("196,255",{3,{199},"kelin put the shovel head into the stick."})m("203,218","the candle leftover made it hard to put the candle.")m("192,195","kelin: i am curious too... but the client will be upset at me and my boss will cut my pay.")m("201,213","kelin: without water, it will get soapy")c("201,221","201,213")c"201,254"c"201,239"m("213,223","kelin: the dirty thing stays sticking. need some soap.")c("221,223","213,223")c"223,254"o_cb_ev("203,214",{ev_cndl})a("203,214,a",{1,{215},"kelin melted the candle leftover in the lantern."})a("215,218",{3,{216},"kelin put the candle into the lantern."})o_cb_ev("214,216",{ev_lt})a("214,216,a",{2,{217}})m("214,218","kelin: i could light up the candle, but carrying later will be a problem. i need something to carry it.")end

function mk_usto(cb,vls)dt_usto[cb]=vls end
function it_usto_itms()dt_usto={}local c,m,v,b,ew,a,p,em,ea=o_usto_cpy,o_usto_msg,o_usto_ev,bd,o_swc_mj1,mk_usto,o_pckp1,o_msg1,amsg
a("208,411",{0,n,{{vl,"34,1",407}},n,{b(o_msg1_a,"used some oil under the door and pushed the door. it opened.")}})
a("198,517",{1,n,{{vl,"29,17",515,"29,16",vl}},n,{b(o_msg1_a,"unlocked the lock on the trap door.")}})
a("197,413",{1,n,{{vl,"34,1",412}},n,{b(o_msg1_a,"unlocked the door.")}})
a("213,519",{1,n,{{vl,"34,19",523}},"&put the bowl on the table."})
a("212,519",{1,n,{{vl,"34,19",524}},"&put the bowl on the table."})
a("201,321",{1,{200},n,n,{b(ev_bckt,321,322),b(em,"whoops, i accidentally poured all of the liquid. might as well clean it.")}})
a("201,323",{1,{200},n,n,{b(ev_bckt,323,324),b(em,"whoops, i accidentally poured all of the liquid. might as well clean it.")}})
a("213,324",{1,{212},n,"&washed the bowl. it is clean now."})
a("221,324",{1,{220},n,"&washed the spoon. it is clean now."})
a("195,707",{0,{219},{{vl,"36,10",708,"36,11",706}},"&cut some part of the sheet."})
a("195,710",{0,{219},{{vl,"36,10",705,"36,11",706}},"&cut some part of the sheet."})
a("200,324",{0,n,n,"i was gonna fill it for water, but yuck, it's soapy!"})
a("239,816",{0,n,n,"the lump stuff, on the key head, blocked the key from entering."})
a("238,816",{1,{202},{{vl,"48,1",817}},"the key fits. the inside of the chest is... another bucket...?"})
a("239,324",{1,{238},n,"&washed the key and managed to remove the lump stuff."})
a("200,321",{1,{223},n,"&filled the bottle with water."})
a("254,324",{1,{222},n,"&washed the pan."})
a("222,529",{1,n,{{vl,"32,16",530}},"&put the cleaned pan onto the stove."})
a("223,530",{1,n,{{vl,"32,16",531}},"&poured water into the pan."})
a("208,531",{1,n,{{vl,"32,16",532}},"&added oil to the logs in the stove."})
a("214,532",{1,n,{{vl,"32,16",533}},"&lit the stove, boiling the water."})
a("209,533",{1,n,{{vl,"32,16",534}},n,{b(o_msg1_a,"put the noodle into the boiling water."),b(ea,{"now to wait few minutes while the noodle is being cooked."}),wyt,b(em,"..."),wyt,b(ew,"32,16",535),b(ea,{"looks like the noodle is cooked now.","i need something to take it from the hot water."})}})
a("206,535",{1,{207},{{vl,"32,16",536}},"&put the noodle onto a strainer."})
a("211,524",{1,n,{{vl,"34,19",525}},"&poured the seasoning into the bowl."})
a("207,525",{1,n,{{vl,"34,19",537}},"&put the noodle into the bowl with seasoning."})
a("220,537",{0,n,{{vl,"34,19",538}},"&stirred the noodle until it mixed with the seasoning."})
v("204,415",{b(em,"\"see the back of the sky\", huh?"),wyt,b(ea,{"hmm...","i can't find the back of the sky in this painting."}),wyt,b(ea,{"nope, still no clue.","perhaps, it means the back of the painting of sky.","... found it."}),b(p,205),b(o_itm_msg1,"a piece of paper."),b(ew,"36,3",409)})
v("205,526",{b(ea,{"\"useless stuffs gather\", garbage can fits the clue.","let me see under it.","...","there is a broken floor under the garbage can. i can see the key there."},c_k),b(p,197),b(o_itm_msg1,"a key."),b(ew,"35,16",514)})
v("219,322",{b(ev_bckt,322,324),b(o_msg1_a,"put the cut sheet into the bucket.")})
v("219,321",{b(ev_bckt,321,323),b(o_msg1_a,"put the cut sheet into the bucket.")})
v("199,103",{b(em,"finally!"),wyt,b(ew,"23,1",104),b(o_msg1_a,"managed to dig the dirt out the cave. however, the shovel broke at the end."),b(em,"thank you, old shovel!")})
v("192,1203",{b(ea,{"oh, i have been waiting for this!","thank you very much!"},c_o),b(em,"no problem. sign here that you have received your package."),b(em,"here it is.",c_o),b(em,"thank you! i am off now."),wyt,b(mv_chr,fc_d,1),b(mv_chr,fc_l,1),b(mv_chr,fc_d,2),wyt,b(ea,{"finally, job finished today. what a day!","gonna eat spicy fried noodle with fried egg after getting the payment from boss!"},c_k),wyt,b(pkio,3),b(ac_tr,t,b(st_to,"outro"),2)})
v("220,538",{b(pkio,2),b(ea,{"finally, the time for meal!","gonna enjoy the fried noodle while reading my map"},c_k),b(cg_pm_t,"blank",vl,vl,n,vl),b(ea,{"20 minutes later..."}),b(ew,"34,19",539,"kitchen"),b(cg_pm_t,"kitchen",n,n,n,vl),b(ea,{"*gulps gulps*","that was a great meal!"},c_k),ev_rn_stp,wyt,b(ply_msc,-1),wyt,b(ea,{"i no longer hear the rain. it seems the rain has finally stopped.","time to deal with the cave and the delivery."},c_k)})
m("213,520","this part of table is too damaged to put the bowl.")
m("204,409","nothing looks useful on the painting anymore.")
m("205,514","nothing looks useful under the garbage can anymore.")
m("223,528","eww... not gonna eat from dirty water.")
m("214,529","nothing to cook so not gonna waste these woods inside.")
m("209,531","the noodle will be too soggy if i put it early. put it when boiling.")
m("214,531","&tried to light the stove. however, the woods were too tough to burn.")
m("207,523","ewww... not gonna eat with dirty bowl!")
m("209,524","nope, i prefer soft noodle.")
m("207,524","nope, i prefer to put the seasoning first before the noodle. it spreads and tastes better.")
m("210,524","the pack is not opened yet.")
m("213,321","&tried to wash it with just water. it was still dirty.")
m("213,322","&tried to wash it with soapy water. however, some needs to be wiped using things like sheet.")
m("213,323","&tried to wipe it. some dirtiness was too sticky.")
m("202,308","there is no rope to reach the water in the well.")
m("195,517","&tried to break the lock using dagger, but the lock was too tough.")
m("197,517","the key didn't fit.")
c("213,521","213,520")
c("212,520","213,520")
c"212,521"
c"212,522"
c("214,528","214,529")
c"214,530"
c("209,523","207,523")
c"210,523"
c"211,523"
c("209,525","209,524")
c("222,326","213,326")
c"239,321"
c"254,321"
c"221,321"
c("222,322","213,322")
c"239,322"
c"254,322"
c"221,322"
c("222,323","213,323")
c"239,323"
c"254,323"
c"221,323"
c("195,413","195,517")
c("193,532","210,524")
ev_tobckt(317,22,21)
ev_tobckt(318,20,22)
ev_tobckt(319,17,22)
end

function it_mp_cts()y_r,x_r,is_hr=0,0,f g_mp_cts()end
function g_mp_cts()local o00,o01,o10,o11,oc,im,mp=o_mkmj00,o_mkmj01,o_mkmj10,o_mkmj11,c_mj,it_pm,mk_pm local ea,et,es,em,b,ei,ew,ec,p=amsg,cg_pm_t,swc_mj,o_msg1,bd,o_itm_msg1,o_swc_mj1,mv_chr,o_pckp1

im(mp("blank",0,0,0,0,0,0))

im(mp("intro_forest",16,0,16,8,12,9,dr_ryn),1)
o00(1,16,4,n,n,{b(et,pzm_ap,26,13,fc_l)})
o00(2,16,5,n,n,{b(et,pzm_ap,26,14,fc_l)})
o01(3,23,1,86,{b(em,"a pile of dirt is blocking the entrance. i should find an alternative path.")})
o00(4,23,1,70,{b(em,"i can go inside the cave now.")},{b(et,"cave_tunnel",57,8,fc_u)})
o11(5,23,1,86,{b(ea,{"what?!","the cave is blocked at this time?!","...","i should try other path. hope i can find some place to stay before it fully rains."},c_k),b(es,{{vl,"23,1",103,"16,4",101,"16,5",102}})})
o10(6,16,4,n,n,{b(pkio,0),b(em,"no, not this way."),b(ec,fc_r,1)})
oc(7,16,5,6)

im(mp(pzm_ap,14,10,8,24,14,7,dr_ryn),2)
o10(1,27,13,n,n,{b(et,"intro_forest",17,4)})
o10(2,27,14,n,n,{b(et,"intro_forest",17,5)})
o10(3,14,12,n,n,{b(et,pzm_oa,26,22)})
o10(4,14,13, n,n,{b(et,pzm_oa,26,23)})
 
im(mp(pzm_oa,14,17,8,8,14,8,dr_ryn),3)
o10(1,27,22,n,n,{b(et,pzm_ap,15,12)})
o10(2,27,23,n,n,{b(et,pzm_ap,15,13)})
o11(3,20,20,101,{b(ea,{"*knock knock*"}),wyt,b(em,"hello? anyone there?"),b(ew,"20,20",310),wyt,b(ea,{"hmm...","the door isn't locked.","the house looks old too.","seems no one here.","i guess i will stay inside for a while until the rain stops."},c_k)})
o00(4,20,20,102,{b(ew,"20,20",305)},{b(et,"main_house",39,7),b(ev_plymc,m_ryn),b(ev_bckt,320,321)})
o01(5,20,20,101,{b(ew,"20,20",304)})
o01(6,22,19,98,{b(em,"a barrel. it is shut tightly.")})
oc(7,22,20,6)
o11(8,24,20,104,{b(em,"a deep dark mossy well.")})
o11(9,22,21,107,{b(p,202),b(ew,"22,21"),b(ei,"a bucket.")})
o00(10,20,20,102,{b(ew,"20,20",311)},{b(et,"dark_main",44,8),b(es,{{pzm_oa,"20,20",312,"18,20",314}}),wyt,b(ea,{"...","it's so dark here"},c_k)})
o01(11,20,20,101,{b(ew,"20,20",310)})
o00(12,20,20,102,{b(ew,"20,20",313)},{b(et,"dark_main",44,8)})
o01(13,20,20,101,{b(ew,"20,20",312)})
o01(14,18,20,187,{b(ea,{"an empty lantern. seems used to light up the front house.","i guess i need this now to light up the house."},c_k),b(p,203),b(ew,"18,20"),b(ei,"an empty lantern.")})
o11(15,18,20,187,{b(em,"an empty lantern. seems used to light up the front house.")}) 
o11(16,22,19,160,{b(em,"there is a candle on the barrel."),b(p,218),b(ew,"22,19",306),b(ei,"an old candle.")})
o01(17,22,21,n,{b(em,"the rain reaches here. i don't want to move any further.")})
oc(18,20,22,17,f)
oc(19,17,22,17,f)
o01(20,22,21,169,{b(em,"not much water yet. perhaps, i should wait inside.")})
o01(21,22,21,153,{b(ea,{"the bucket is filled. it will mess my bag if i carry it.","i should bring something to here if i want to use the water."},c_k)})
o01(22,22,21,154,{b(em,"a bucket with soapy water.")})
o01(23,22,21,156,{b(em,"a bucket with cut sheet.")})
o01(24,22,21,155,{b(em,"a bucket with soapy water and sheet. can be used to wash something.")})
o11(25,21,22,146,{b(ea,{"looks like a shovel. let me pull it.","...","it was too hard to pull."},c_k)})
o01(26,21,22,146,{b(ea,{"the soil must be softer after raining.","let me pull it again.","..."},c_k),b(p,196),b(ew,"21,22"),b(ei,"a shovel... without its head.")})

im(mp("main_house",29,0,16,8,12,9),4)
o10(1,39,8,102,{b(ew,"39,8",402)},{b(et,pzm_oa,20,21),b(ev_plymc,m_hrain,3)})
o01(2,39,8,101,{b(ew,"39,8",401)})
o10(3,29,6,n,n,{b(et,"kitchen",37,21)})
o10(4,29,7,n,n,{b(et,"kitchen",37,22)})
o10(5,31,1,102,{b(ew,"31,1",406)},{b(et,"bathroom",39,11)})
o01(6,31,1,101,{b(ew,"31,1",405)})
o00(7,34,1,102,{b(ew,"34,1",408)},{b(et,"bedroom",30,11)})
o01(8,34,1,101,{b(ew,"34,1",407)})
o01(9,36,3,113,{b(em,"a painting of sky.")})
o11(10,33,0,114,{b(em,"a painting of gold ore.")})
o01(11,34,1,180,{b(em,"the door is stuck. i can't push it further.")})
o01(12,34,1,101,{b(ew,"34,1",411),wyt,b(em,"huh? stuck?.")})
o01(13,34,1,101,{b(em,"the door is locked.")})
o11(14,34,1,101,{b(ea,{"the door is locked.","hmm, there is a small rolled piece of paper in the keyhole."},c_k),b(p,204),b(ew,"34,1",413),b(ei,"a piece of paper.")})
o11(15,36,3,113,{b(em,"a painting of sky.")})
o11(16,38,5,63,{b(em,"a note. it says..."),b(ea,{"to anyone who read this note.","hi, this is the owner who wrote this. just wanted to inform you this.","i have moved to a new home and i have no use of this house anymore.","so feel free to use or take anything in this house. you can even own this house if you like."},"note")})

im(mp("kitchen",29,15,16,8,10,8),5)
o10(1,38,21,n,n,{b(et,"main_house",30,6)})
o10(2,38,22,n,n,{b(et,"main_house",30,7)})
o11(3,29,20,99,{b(em,"an empty box.")})
oc(4,29,21,3,f)
oc(5,29,22)
oc(6,31,22,3,f)
oc(7,32,22)
o11(8,29,21,99,{b(pk,{193,206}),b(ew,"29,21",504),b(ei,"a noodle pack and a strainer.")})
o00(9,29,17,84,n,{b(et,"warehouse",42,2)})
o01(10,29,17,84,{b(es,{{vl,"29,17",515,"29,18",vl,"29,16",vl}})})
o00(11,29,16,n,n,{b(es,{{vl,"29,17",509,"29,16",vl,"30,16",512}})})
o00(12,30,16,n,n,{b(es,{{vl,"30,16",vl,"29,16",511,"29,17",510}})})
o11(13,31,22,99,{b(p,208),b(ew,"31,22",506),b(ei,"a bottle of cooking oil.")})
o01(14,35,16,123,{b(em,"a garbage can. it is empty.")})
o00(15,29,17,185,{ev_trpdr})
o01(16,29,18,186)
o10(17,29,17,184,{b(em,"the trap door is locked.")})
o10(18,29,16,168)
o01(19,34,19,94)
o11(20,35,19,95)
o11(21,34,20,110)
o11(22,35,20,111)
o11(23,34,19,130,{b(p,213),b(ew,"34,19",519),b(ei,"picked a bowl. it is dirty.")})
o01(24,34,19,129,{b(em,"a cleaned bowl.")})
o01(25,34,19,129,{b(em,"a bowl with seasoning.")})
o11(26,35,16,123,{b(em,"a garbage can. it is empty.")})
o11(27,37,16,131,{b(p,221),b(ew,"37,16"),b(ei,"a spoon. it is dirty.")})
o11(28,32,16,134,{b(p,254),b(ew,"32,16",529),b(ei,"a pan. it is dirty.")})
o01(29,32,16,128,{b(em,"a stove. there are some woods inside.")})
o01(30,32,16,133,{b(em,"a stove with cleaned pan.")})
o01(31,32,16,135,{b(em,"a stove with pan filled with water.")})
o01(32,32,16,135,{b(em,"a stove with pan filled with water. the log also has been added with oil.")})
o01(33,32,16,132,{b(em,"a lit stove and pan filled with boiling water.")})
o01(34,32,16,136)
o01(35,32,16,137,{b(ea,{"a stove with pan filled with boiled noodle.","i need something to take the noodle from the hot water."},c_k)})
o01(36,32,16,135,{b(em,"a stove with used pan.")})
o01(37,34,19,138,{b(em,"a bowl of noodle with seasoning below it.")})
o01(38,34,19,140,{b(em,"a bowl of stirred noodle with seasoning. ready to be eaten.")})
o01(39,34,19,129,{b(em,"a bowl i used to eat noodle. that was tasty meal!")})

im(mp("bathroom",38,10,32,16,3,4),6)
o10(1,40,11,102,{b(ew,"40,11",602)},{b(et,"main_house",32,1)})
o01(2,40,11,101,{b(ew,"40,11",601)})
o11(3,39,10,n,{b(em,"i look cute even from an old mirror.")})
o11(4,38,10,n,{b(em,"it's empty.")})

im(mp("bedroom",29,9,48,16,8,5),7)
o10(1,29,11,102,{b(ew,"29,11",702)},{b(et,"main_house",33,1)})
o01(2,29,11,101,{b(ew,"29,11",701)})
o11(3,35,13,99,{b(em,"an empty box.")})
oc(4,36,13,3)
o01(5,36,10,145,{b(em,"a bed. nothing interesting anymore there.")})
o01(6,36,11,161)
o11(7,36,10,162,{b(ea,{"a bed with stuck sheet.","something is under the pillow."},c_k),b(p,198),b(ei,"a key with red tag."),b(ew,"36,10",710)})
o01(8,36,10,145,{b(ea,{"a bed.","something is under the pillow."},c_k),b(p,198),b(ei,"a key with red tag."),b(es,{{vl,"36,10",705,"36,11",706}})})
o11(9,36,11,178)
o01(10,36,10,162,{b(em,"a bed with stuck sheet.")})

im(mp("warehouse",42,0,16,16,8,6),8)
o10(1,42,1,n,n,{b(et,"kitchen",29,16)})
o01(2,43,1,99,{b(em,"an empty box.")})
o11(3,43,2)
o10(4,43,3,n,n,{b(es,{{vl,"43,2",vl,"42,2",806,"42,3",805,"43,3",vl}})})
o00(5,42,3,n,n,{b(es,{{vl,"43,2",803,"42,2",vl,"43,3",804,"42,3",vl}})})
o01(6,42,2)
oc(7,44,1,2)
oc(8,45,1)
oc(9,46,1)
oc(10,43,4)
oc(11,44,4)
oc(12,45,4)
oc(13,46,4)
oc(14,47,4)
o11(15,46,4,99,{b(p,201),b(ew,"46,4",813),b(ei,"a bottle of green liquid.")}) 
o11(16,48,1,82,{b(em,"an old chest. it is locked.")})
o01(17,48,1,83,{b(em,"an old chest. it is empty.")})
o11(18,43,1,99,{b(p,239),b(ew,"43,1",802),b(ei,"a rusty key with dirt lump.")})
o11(19,49,2,157,{b(p,255),b(ew,"49,2"),b(ei,"a shovel... head only.")})

im(mp("dark_main",42,7,80,56,5,3),9)
o11(1,42,7,53,{b(em,"i won't move any further. it's too dark there.")})
oc(2,42,8,1)
oc(3,43,7,1,f)
oc(4,44,7)
oc(5,45,7)
o10(6,44,9,102,n,{b(et,pzm_oa,20,21)})
o11(7,43,7,53,{b(em,"there is something below the chair."),b(p,214),b(ei,"a box of matches."),b(ew,"43,7",903)})

im(mp("cave_tunnel",50,1,24,8,12,9),10)
o10(1,57,9,n,n,{b(et,"intro_forest",23,2)})
o10(2,53,1,n,n,{b(et,"blank",-1,-1),b(ea,{"after this, kelin goes through the forest by following her map she carry.","there wasn't any significant obstacles."}),wyt,b(ea,{"30 minutes later..."}),b(et,"client_entrance",-1,-1),wyt,b(em,"*huft*"),b(cg_pl_slpos,53,19),wyt,b(em,"finally, here's the place."),b(ec,fc_u,1),wyt,b(em,"now to deliver the package.")})

im(mp("client_entrance",49,11,8,8,14,9),12)
o11(1,54,17,152,{b(ew,"54,17"),b(o_msg1_a,"opened the fence.")})
o11(2,55,14,167,{b(ea,{"*knock knock*"}),b(em,"yes, yes. be right there.","???"),wyt,b(ew,"55,14",1203),wyt,b(em,"oh, a little girl. what are you doing this hour? should you go home now? it is late afternoon.",c_o),b(em,"good afternoon, old man. i have a package delivery for you."),b(em,"oh that package! yes, i have been waiting for it. give it to me.",c_o)})
o01(3,55,14,15,{b(em,"so, where's the package?",c_o)})

intro_evs={b(cg_pl_v,f),wyt,b(ea,{"one day in a forest..."}),wyt,b(em,"*huft*","?????"),wyt,b(cg_pl_v,t),wyt,b(em,"still a long way before i can finish delivering this package."),b(ec,fc_u,2),b(em,"...i feel hungry now..."),b(em,"it is starting to rain now... i have to reach the cave soon.")}cg_pm("intro_forest",22,8,fc_u)
end

function ev_tobckt(id,slx,sly)o_usto_ev("202,"..id,{bd(cg_mj_pos,320,vl,slx,sly),bd(o_swc_mj1,""..slx..","..sly,320),bd(o_msg1_a,"put the bucket on the ground that the rain can reach.")})end
function ev_plymc(id,id2)if(is_hr)then ply_msc(id)elseif(id2)then ply_msc(id2)end nx_ev() end
function ev_trpdr()if(pl_slx==29 and pl_sly==18)then o_msg1("i can't open it from this side.")else swc_mj({{vl,"29,17",510,"29,16",511,"29,18",516}})end end
function ev_rn_stp()local mjs,slx,sly=pms[pzm_oa].a_mjs pms["intro_forest"].wthr,pms[pzm_ap].wthr,pms[pzm_oa].wthr,is_hr=n,n,n,f is_ev=f o_swc_mj1("21,22",326,pzm_oa)if mjs["17,22"].id==319 then slx,sly=17,22 elseif mjs["20,22"].id==318 then slx,sly=20,22 elseif mjs["22,21"].id==317 then slx,sly=22,21 end o_swc_mj1(""..slx..","..sly,n,pzm_oa)wyt()is_ev=t nx_ev()end
function ev_lt()nx_ev()if(cr_pm==pms["dark_main"])then cb_itm(iv_ocbn_ix,iv_oix,"a")iv_mnix,is_hr=-1,t a_evs({bd(pkio,1),bd(o_msg1_a,"lit the candle in the lantern."),bd(swc_mj,{{pzm_oa,"20,20",304,"22,21",317,"20,22",318,"17,22",319}}),bd(cg_pm_t,"main_house",pl_slx-5,pl_sly-1,n,vl),bd(amsg,{"nice. i can see more now.","...","the inside looks old.","need to find something to eat and something to rid the pile."},c_k),bd(ply_msc,m_ryn),bd(amsg,{"?","it seems it rains hard right now."},c_k)})else iv_mnix=0 tlkr=c_k up_crmsg("it's too humid and windy here. i should try to light it inside...",c_k)tlkr=n end end
function ev_cndl()if(cr_pm==pms["dark_main"])then cb_itm(iv_ocbn_ix,iv_oix,"a")else iv_mnix=0 tlkr=c_k up_crmsg("it's too humid and windy here. maybe i will light it inside...")tlkr=n end nx_ev()end
function ev_bckt(id_chk,id_to)if(is_hr)then local mjs,slx,sly=pms[pzm_oa].a_mjs,-1 if(mjs["22,21"].id==id_chk)then slx,sly=22,21 elseif(mjs["20,22"].id==id_chk)then slx,sly=20,22 elseif(mjs["17,22"].id==id_chk)then slx,sly=17,22 end if(slx>0)then is_ev=f cg_mj_pos(id_to,pzm_oa,slx,sly)o_swc_mj1(""..slx..","..sly,id_to,pzm_oa)is_ev=t end end nx_ev()end

function pkio(d)poke(0x5f80+d,1)nx_ev()end

function it_ttl()mk_st("title",dr_ttl,up_ttl)vc,fr,fr_t=#vers,1,0 vx=128-vc*4 end
function dr_ttl()spr(224,8,16,14,2)spr(39,92,34,8,1)ctx("(z) start",96)ctx("(x) credit",104)print(" 2017 biolardi yoshogi / neithr",0,116)print(vers,vx,1)map(18,3,52,56,3,3)line(61,71,66,71,dbl)spr(pl_anms[fc_l][fr],60,64)end
function up_ttl()fr_t+=1 if(fr_t>4)then fr_t=0 fr+=1 if(fr>4)then fr=1 end end if(bp(b_o))then ply_msc(7)ac_tr(t,bd(st_to,"gameplay"),2)a_evs(intro_evs)sfx(s_cg_pm)end if(bp(b_x))then ac_tr(t,bd(st_to,"credit"),2)sfx(s_cg_pm)end end

function it_crd()mk_st("credit",dr_crd,up_crd)end
function dr_crd()local nm={"biolardi y. / neithr"}crd_el("coder",nm,12)crd_el("story writer",nm,28)crd_el("artist",nm,44)crd_el("sound+music",nm,60)crd_el("special thanks to",{"pico-8","notepad++","indiean as tester","you, the player"},76)end
function crd_el(rl,els,y)rect(4,8,123,119,dgr)print(rl,8,y,gre)local ln=#els for i=1,ln do print("- "..els[i],16,y+8*i,whi)end end
function up_crd()if(bp(b_o)or bp(b_x))then sfx(s_cg_pm)ac_tr(t,bd(st_to,"title"),2)end end

function it_gm()mk_st("gameplay",dr_gm,up_gm)rst_gm()end
function rst_gm()it_iv()it_msg()it_mv()frm,frm_f,pl_fc,pl_x,pl_y,pl_slx,pl_sly,pl_selx_s,pl_sely_s,pl_vis=1,0,fc_d,0,0,0,0,0,0,t it_ev()it_mps()end

function it_otr()mk_st("outro",dr_otr,up_otr)gp_ryn,gp_rynlmt=0,31 end
function dr_otr()otr_fx() local r,e=rectfill,rect palt(blk,f)r(56,56,71,71,blk)e(56,56,71,71,dgr)spr(7,60,60)r(4,8,124,48,blk)e(4,8,124,48,dgr)r(4,108,124,120,blk)e(4,108,124,120,dgr)ctx("congratulation!",12)ctx("kelin has finally finished",22)ctx("her delivery job!",28)ctx("thank you for playing!",38)ctx("hold z+x to return to title",112)palt(blk,t)end
function otr_fx()cry=-8 local gp,tx=0 while(cry<128)do for i=0,5 do tx=24*i+gp line(tx,cry+gp_ryn,tx,cry+4+gp_ryn,blu)end gp=-(gp-12)cry+=16 end end
function up_otr()gp_ryn+=1 if(gp_ryn>gp_rynlmt)then gp_ryn=0 end if(bp(b_x)and bp(b_o))then sfx(s_cg_pm)ac_tr(t,bd(st_to,"title"),2)rst_gm()end end

function it_iv()iv_mnix,iv_mntxtix,iv_itm_ix,iv_oix,iv_oslct_ix,iv_oshft,iv_ocbn_ix,iv_mntxts=-1,0,0,0,0,0,0,{"use on front","combine"}it_iv_itms()it_cb_itms()it_usto_itms()end
function dr_iv()local ybs=64 if(iv_mnix>-1)then if(pl_y>=56)then ybs=20 else ybs=64 end if(iv_mnix==1 and iv_mntxtix==0)then if(pl_fc==fc_d)then if(pl_y<65)then spr(48,pl_x,pl_y+8)end elseif(pl_fc==fc_l and pl_x>8)then spr(48,pl_x-8,pl_y)elseif(pl_fc==fc_r and pl_x<104)then spr(48,pl_x+8,pl_y)elseif(pl_fc==fc_u and pl_y>8)then spr(48,pl_x,pl_y-8)end end palt(blk,f)rectfill(0,ybs+8,128,ybs+24,blk)map(0,0,4,ybs+4,16,2)map(0,3,4,ybs+20,16,1)palt(blk,t)dr_iv_itms(ybs)drw_iv_slctn(ybs)end if(iv_mnix==1)then local ln=#iv_mntxts for i=1,ln do print(iv_mntxts[i],12,96+(i-1)*8,whi)end print(">",8,96+(iv_mntxtix)*8,whi)end end
function drw_iv_slctn(ybs)local gp,is_skip=iv_ocbn_ix+iv_oslct_ix-iv_oix if(#iv_o>0)then pal(dgr,blu,0)pal(gre,whi,0)map(0,4,16+iv_oslct_ix*20,ybs+8,2,2)pal()else dr_unslt(17+20*(iv_oslct_ix),ybs+9)end if(iv_mnix==2)then if(gp>-1 and gp<5)then pal(dgr,ora,0)pal(gre,yel,0)map(0,4,16+gp*20,ybs+8,2,2)pal()end end for i=1,5 do is_skip=f if(iv_oslct_ix==i-1)then is_skip=t end if(gp==i-1 and iv_mnix==2)then is_skip=t end if(not is_skip)then dr_unslt(17+20*(i-1),ybs+9)end end end
function dr_iv_itms(ybs)local ln=#iv_o if(ln==0)then return end for i=1,5 do if(iv_o[i+iv_oshft])then spr(iv_o[i+iv_oshft],20*(i),ybs+12)end end end
function dr_unslt(x,y)spr(6,x+6,y)spr(36,x,y+6)spr(4,x,y)spr(38,x+6,y+6)end
function mv_slctr_l()local ln=#iv_o if(ln>0)then iv_oix-=1 if(iv_oix<0)then iv_oix=ln-1 end if(ln>5)then if(iv_oslct_ix>2)then iv_oslct_ix-=1 elseif(iv_oshft>0)then iv_oshft-=1 else if(iv_oslct_ix>0)then iv_oslct_ix-=1 else iv_oshft=ln-5 iv_oslct_ix=4 end end else iv_oslct_ix=iv_oix end end end
function mv_slctr_r()local ln=#iv_o if(ln>0)then iv_oix+=1 if(iv_oix>#iv_o-1)then iv_oix=0 end if(ln>5)then if(iv_oslct_ix<2)then iv_oslct_ix=iv_oix elseif(iv_oshft<ln-5)then iv_oshft+=1 else if(iv_oslct_ix<4)then iv_oslct_ix+=1 else iv_oshft=0 iv_oslct_ix=0 end end else iv_oslct_ix=iv_oix end end end
function slctr_rst()iv_oslct_ix,iv_oix,iv_oshft=0,0,0 end
function up_iv()if(iv_mnix>-1)then if(bp(b_l))then mv_slctr_l()sfx(s_ui)if(iv_mnix==2)then if(iv_oix==iv_ocbn_ix)then mv_slctr_l()end end if(iv_mnix==0 or iv_mnix==1)then up_crmsg(dt_ivitm[iv_o[iv_oix+1]])end elseif(bp(b_r))then mv_slctr_r()sfx(s_ui)if(iv_mnix==2)then if(iv_oix==iv_ocbn_ix)then mv_slctr_r()end end if(iv_mnix==0 or iv_mnix==1)then up_crmsg(dt_ivitm[iv_o[iv_oix+1]])end end end if(iv_mnix==-1)then if(bp(b_x))then if(iv_mnix==-1)then if(not is_mvx)then sfx(s_ui)iv_mnix=0 up_crmsg(dt_ivitm[iv_o[iv_oix+1]])end end end elseif(iv_mnix==0)then if(bp(b_o))then if(#iv_o>0)then iv_mnix=1 up_crmsg("")sfx(s_ui)end elseif(bp(b_x))then iv_mnix=-1 up_crmsg()sfx(s_ui)end elseif(iv_mnix==1)then local ln=#iv_mntxts if(bp(b_u))then iv_mntxtix-=1 if(iv_mntxtix<0)then iv_mntxtix=ln-1 end elseif(bp(b_d))then iv_mntxtix+=1 if(iv_mntxtix>ln-1)then iv_mntxtix=0 end elseif(bp(b_l)or bp(b_r))then iv_mnix=0 elseif(bp(b_o))then if(iv_mntxtix==0)then itm_frnt()elseif(iv_mntxtix==1)then iv_ocbn_ix=iv_oix ln=#iv_o if(iv_oix<ln-1)then mv_slctr_r()else mv_slctr_l()end iv_mnix=2 up_crmsg("which item i should combine with?")end elseif(bp(b_x))then iv_mnix=0 up_crmsg(dt_ivitm[iv_o[iv_oix+1]])end elseif(iv_mnix==2)then if(bp(b_o))then cb_itm(iv_ocbn_ix,iv_oix)elseif(bp(b_x))then iv_mnix=1 up_crmsg""end end end
function add_itm(spr_ix)add(iv_o,spr_ix)end
function rm_itm(itm_ix)local ln=#iv_o-1 if(ln+1==0)then return end itm_ix+=1 iv_o[itm_ix]=n for i=itm_ix,ln do iv_o[i]=iv_o[i+1]end iv_o[ln+1]=n if(itm_ix==ln+1)then iv_oix-=1 if(iv_oix<0)then iv_oix=0 end if(iv_oshft>0)then iv_oshft-=1 else iv_oslct_ix=iv_oix end else if(iv_oshft>0)then iv_oshft-=1 iv_oslct_ix+=1 else iv_oix-=1 iv_oslct_ix=iv_oix end end end
function cb_itm(ix1,ix2,tag)ix1+=1 ix2+=1 local id1,id2,ln,cb=iv_o[ix1],iv_o[ix2],#iv_o if(id1>id2)then local tmp,t_ix=id1,ix1 id1,ix1=id2,ix2 ix2,id2=t_ix,tmp end if(tag==n)then cb=id1..","..id2 else cb=id1..","..id2..","..tag end local rslt=dt_cb[cb]if(rslt)then local dest_typ=rslt[1] or 0 if(dest_typ==1)then rm_itm(ix1-1)elseif(dest_typ==2)then rm_itm(ix2-1)elseif(dest_typ==3)then rm_itm(ix2-1)rm_itm(ix1-1)end if(rslt[2])then pk(rslt[2])sfx(s_got)end if(rslt[4]==n)then up_crmsg(rslt[3])else iv_mnix=-1 a_evs(rslt[4])return end else up_crmsg(c_k..": "..usto_nth_msg)end iv_mnix=0 end

function it_mps()pms,cr_pm,cr_mjs,cr_a_mjs={},0,n,n it_mp_cts()cr_mjs,cr_a_mjs=n,n end
function it_pm(t_pm,id)cr_id,cr_mjs,cr_a_mjs=(id or 0)*100,t_pm.mjs,t_pm.a_mjs end
function mk_pm(nm,slx,sly,posx,posy,slw,slh,wthr)local pm={slx=slx,sly=sly,posx=posx,posy=posy,slw=slw,slh=slh,mjs={},a_mjs={},wthr=wthr}pms[nm]=pm return pm end
function dr_pm()if(cr_pm)then map(cr_pm.slx,cr_pm.sly,cr_pm.posx,cr_pm.posy,cr_pm.slw,cr_pm.slh)local t_a_mjs,t_spr_ix=cr_pm.a_mjs for pos,mj in pairs(t_a_mjs)do t_spr_ix=mj.spr_ix if(t_spr_ix)then spr(t_spr_ix,(mj.slx-cr_pm.slx)*8+cr_pm.posx,(mj.sly-cr_pm.sly)*8+cr_pm.posy)end end end end
function mk_mj(id,is_actv,slx,sly,is_blk,spr_ix,b_evs,s_evs)local mj={id=cr_id+id,slx=slx,sly=sly,is_blk=is_blk,spr_ix=spr_ix,b_evs=b_evs,s_evs=s_evs}if(is_actv)then cr_a_mjs[(""..slx)..(","..sly)]=mj end cr_mjs[mj.id]=mj return mj end
function cg_mj_pos(id,mpnm,nw_slx,nw_sly)local pm=pms[mpnm]or cr_pm local mj=pm.mjs[id]mj.slx,mj.sly=nw_slx,nw_sly nx_ev()end
function c_mj(nw_id,slx,sly,frm_id,is_actv)o_vr2=frm_id or o_vr2 local t_mj=cr_mjs[o_vr2+cr_id]mk_mj(nw_id,is_actv==n,slx,sly,t_mj.is_blk,t_mj.spr_ix,t_mj.b_evs,t_mj.s_evs)end

function get_frnt()local xfc,yfc=0,0 if(pl_fc==1)then yfc+=1 elseif(pl_fc==2)then xfc-=1 elseif(pl_fc==3)then xfc+=1 elseif(pl_fc==4)then yfc-=1 end return cr_pm.a_mjs[(pl_slx+xfc)..","..(pl_sly+yfc)]end
function itm_frnt()local mj=get_frnt()if(mj==n)then tlkr=c_k up_crmsg(usto_nth_msg)tlkr=n iv_mnix=0 return end rslt=dt_usto[iv_o[iv_oix+1]..","..mj.id]if(rslt==n)then tlkr=c_k up_crmsg(usto_nth_msg)tlkr=n else local msgs,evs,ln=rslt[4],rslt[5],0 if(rslt[1]==1)then rm_itm(iv_oix)end if(rslt[2])then pk(rslt[2])sfx(s_got)end if(rslt[3])then swc_mj(rslt[3])end if(evs)then iv_mnix=-1 if(msgs)then up_crmsg(achr(msgs))tlkr=n else a_evs(evs)return end else up_crmsg(achr(msgs))tlkr=n end end iv_mnix=0 end
function achr(msg)if(sub(msg,1,1)=="&")then return c_k.." "..sub(msg,2)else tlkr=c_k return msg end end
function chk_frnt()local mj=get_frnt()if(mj==n)then o_msg1(nth_msg)else if(mj.b_evs==n)then o_msg1(nth_msg)end a_evs(mj.b_evs)end end
function pk(vls)local ln=#vls for i=1,ln do add_itm(vls[i])end slctr_rst()mv_slctr_l() nx_ev()end
function swc_mj(vls)local ln,cr_mjs,len_cr_mjs,pm,pm_nm,t_mj=#vls for i=1,ln do cr_mjs,len_cr_mjs=vls[i],#vls[i]for j=2,len_cr_mjs do pm_nm=cr_mjs[1]if(pm_nm==vl)then pm=cr_pm else pm=pms[pm_nm] end t_mj=pm.mjs[cr_mjs[j+1]]pm.a_mjs[cr_mjs[j]]=t_mj j+=1 end end nx_ev()end
function cg_pm_t(pm_nm,plslx,plsly,plfc,snd_fx)if(snd_fx==n)then sfx(s_cg_pm)else if(snd_fx!=vl)then sfx(snd_fx)end end local func=bd(cg_pm,pm_nm,plslx,plsly,plfc)ac_tr(t,bd(cg_pzbck,func),3,{2,2,15,10})end
function cg_pzbck(fnc)ac_tr(f,nx_ev,3,{2,2,15,10})fnc()end
function cg_pm(pm_nm,plslx,plsly,plfc)cr_pm=pms[pm_nm]if(plslx!=-1)then pl_slx=plslx or pl_slx pl_x=(pl_slx-cr_pm.slx)*8+cr_pm.posx else pl_x=-8 end if(plsly!=-1)then pl_sly=plsly or pl_sly pl_y=(pl_sly-cr_pm.sly)*8+cr_pm.posy else pl_y=-8 end pl_fc=plfc or pl_fc end

function it_mv()n_stp,is_mvx,mvx_gp=0,f,0 end
function mv_chr(fc_dir,stp)n_stp,pl_fc,is_prs=stp or 1,fc_dir,f if(stp==0)then nx_ev() return end if(fc_dir==fc_l)then if(not fget(mget(pl_slx-1,pl_sly),0))then if(get_frnt()==n or not get_frnt().is_blk)then pl_x-=2 is_prs=t end end elseif(fc_dir==fc_r)then if(not fget(mget(pl_slx+1,pl_sly),0))then if(get_frnt()==n or not get_frnt().is_blk)then pl_x+=2 is_prs=t end end elseif(fc_dir==fc_u)then if(not fget(mget(pl_slx,pl_sly-1),0))then if(get_frnt()==n or not get_frnt().is_blk)then pl_y-=2 is_prs=t end end elseif(fc_dir==fc_d)then if(not fget(mget(pl_slx,pl_sly+1),0))then if(get_frnt()==n or not get_frnt().is_blk)then pl_y+=2 is_prs=t end end else return end if(is_prs)then is_mvx=t mvx_gp+=2 end end
function mvx_chr()if(mvx_gp<8)then if(pl_fc==fc_l)then pl_x-=2 elseif(pl_fc==fc_r)then pl_x+=2 elseif(pl_fc==fc_u)then pl_y-=2 elseif(pl_fc==fc_d)then pl_y+=2 end mvx_gp+=2 if(mvx_gp==8)then mvx_gp=0 n_stp-=1 if(pl_fc==fc_l)then pl_slx-=1 elseif(pl_fc==fc_r)then pl_slx+=1 elseif(pl_fc==fc_u)then pl_sly-=1 elseif(pl_fc==fc_d)then pl_sly+=1 end if(n_stp==0)then is_mvx=f local stp_mj=cr_pm.a_mjs[""..pl_slx..","..pl_sly]if(is_ev)then nx_ev() else if(stp_mj)then a_evs(stp_mj.s_evs)end end end end end end
function up_mvx()local ec=mv_chr if(not is_mvx)then if(not is_ev)then if(bt(b_l))then ec(fc_l)elseif(bt(b_r))then ec(fc_r)elseif(bt(b_u))then ec(fc_u)elseif(bt(b_d))then ec(fc_d)end end if(frm!=1 and not is_mvx)then frm,frm_f=1,0 end else frm_f+=0.40 if(frm_f>=1)then frm_f-=1 frm+=1 if(frm>4)then frm=1 end end mvx_chr()end end

function it_msg()tlkr,cr_msg,cr_msgs,is_msgx,msg_ix=n,n,n,f,1 end
function amsg(msgs,itlkr,snd_ix)is_msgx,cr_msgs,tlkr=t,msgs,itlkr up_crmsg(cr_msgs[1])if(snd_ix==n)then sfx(s_ui)else sfx(snd_ix)end end
function nwln_msg(msg)if(msg==n)then return end local nwln_msg,n_chrs,strt_ix,chr_ix,gp_ix,gppd_ix="",#msg,1,29,0,0if(n_chrs>chr_ix-1)then while(chr_ix<n_chrs)do gppd_ix=chr_ix-gp_ix if(sub(msg,gppd_ix,gppd_ix)!=" ")then gp_ix+=1 else nwln_msg=nwln_msg..sub(msg,strt_ix,gppd_ix).."\n"strt_ix=gppd_ix+1 chr_ix,gppd_ix,gp_ix=strt_ix+28,0,0 end end end nwln_msg=nwln_msg..sub(msg,strt_ix,n_chrs)return nwln_msg end
function up_msg()if(is_msgx)then if(bp(b_o))then if(msg_ix<#cr_msgs)then msg_ix+=1 up_crmsg(cr_msgs[msg_ix])else is_msgx,tlkr,msg_ix=f,n,1 up_crmsg()nx_ev()end sfx(s_ui)end end end
function up_crmsg(txt)if(tlkr)then cr_msg=nwln_msg(tlkr..": "..(txt or ""))else cr_msg=nwln_msg(txt)end end
function dr_msg()if(cr_msg)then print(cr_msg,7,96,whi)map(0,0,4,92,15,4)end end

function it_ev()evs,ev_ix,is_ev,wyt_tm,is_wytx=n,0,f,0,f end
function a_evs(nw_evs)if(nw_evs==n)then return end evs,is_ev=nw_evs,t nx_ev()end
function nx_ev()if(is_ev)then local ln=#evs if(ev_ix<ln)then ev_ix+=1 evs[ev_ix]()else ev_ix=0 evs=n is_ev=f end end end
function wyt(dur)local dur=dur or 30 if(is_3)then wyt_tm=dur else wyt_tm=dur*2 end is_wytx=t end
function up_ev()if(is_wytx)then if(wyt_tm>0)then wyt_tm-=1 else is_wytx=f nx_ev()end end end

function up_gm()up_ev()if(not (is_mvx or is_wytx) and iv_mnix==-1)then if(is_msgx)then up_msg()else if(bp(b_o))then chk_frnt()end end end if(not(is_mvx or is_msgx or is_wytx))then up_iv()end if(not (is_msgx or is_wytx) and iv_mnix==-1)then up_mvx()end end
function dr_gm()dr_pm()map(0,0,4,4,15,1)for i=1,7 do map(0,1,4,4+i*8,15,2)end map(0,3,4,76,15,1)dr_msg()if(pl_vis)then line(pl_x+1,pl_y+7,pl_x+6,pl_y+7,dbl)spr(pl_anms[pl_fc][frm],pl_x,pl_y)end if(cr_pm.wthr)then cr_pm.wthr()end dr_iv()end
function dr_ryn()local xlwbs,gpx,gpy,ybs,xlmt,ylmt,ygplm=10,16,16,8,120,72 local xbs=xlwbs while(ybs<ylmt)do if(is_hr)then line(xbs+x_r,ybs+y_r,xbs+1+x_r,ybs+4+y_r,blu)line(xbs+x_r+8,ybs+y_r+8,xbs+1+x_r+8,ybs+4+y_r+8,blu)else line(xbs+6,ybs+y_r,xbs+6,ybs+2+y_r,blu)end xbs+=gpx if(xbs>xlmt)then xbs=xlwbs ybs+=gpy end end if(is_hr)then x_r+=1 y_r+=1.5 ygplm=8 else y_r+=1 ygplm=16 end if(y_r>ygplm)then y_r=0 x_r=0 end end
function cg_pl_v(is) pl_vis=is nx_ev()end
function cg_pl_slpos(slx,sly)pl_slx,pl_sly=slx or pl_slx,sly or pl_sly pl_x,pl_y=(pl_slx-cr_pm.slx)*8+cr_pm.posx,(pl_sly-cr_pm.sly)*8+cr_pm.posy nx_ev()end

function it_st()cr_st,cr_st_nm,sts=n,"",{}end
function mk_st(nm,dr_ev,up_eva)st={dr=dr_ev or no_ev,up=up_eva or no_ev}sts[nm],cr_st_nm=st,nm return st end
function st_to(nwst_nm)ac_tr(f)cr_st_nm,cr_st=nwst_nm,sts[nwst_nm]end
function no_ev()end

function it_tr()frm_tr,frm_tr_spd,tr_ix,anm_tr,is_tr,is_tr_frwd,en_tr_ev,t_ar_x0,t_ar_y0,t_ar_x1,t_ar_y1=0,1,1,{55,54,53,52},f,f,n,1,1,16,16 end
function up_tr()if(is_tr)then frm_tr+=frm_tr_spd if(frm_tr>=10)then frm_tr=0 frm_tr_spd+=0.5 if(is_tr_frwd)then if(tr_ix<4)then tr_ix+=1 else en_tr()end else if(tr_ix>1)then tr_ix-=1 else en_tr()end end end end end
function en_tr()is_tr=f en_tr_ev()end
function dr_tr()if(is_tr)then pal(dbl,blk)for i=t_ar_y0,t_ar_y1 do for j=t_ar_x0,t_ar_x1 do spr(anm_tr[tr_ix],(j-1)*8,(i-1)*8)end end pal()end end
function ac_tr(isfwd,ev,frmspd,ar)frm_tr_spd,en_tr_ev,is_tr_frwd=frmspd or 1,ev or no_ev,isfwd if(ar)then t_ar_x0,t_ar_y0,t_ar_x1,t_ar_y1=ar[1] or 1,ar[2] or 1,ar[3] or 16,ar[4] or 16 else t_ar_x0,t_ar_y0,t_ar_x1,t_ar_y1=1,1,16,16 end if(is_tr_frwd)then tr_ix=1 else tr_ix=#anm_tr end is_tr=t end

function o_msg1(msg,nm)amsg({msg},nm or c_k)end
function o_msg1_a(msg)amsg({c_k.." "..msg})end 
function o_itm_msg1(msg)amsg({c_k.." picked up "..msg},n,s_got)end
function o_itm_id(msg)dt_ivitm[o_vr1]=msg o_vr1+=1 end
function o_swc_mj1(pos,id,pznm)swc_mj({{pznm or vl,pos,id or vl}})end
function o_pckp1(itm_ix)pk({itm_ix})end
function o_usto_ev(cb,evs,itm_typ)dt_usto[cb]={itm_typ or 1,n,n,n,evs}end
function o_usto_msg(cb,msg)dt_usto[cb]={0,n,n,msg}end
function o_usto_cpy(cb1,cb2)o_vr3=cb2 or o_vr3 dt_usto[cb1]=dt_usto[o_vr3]end
function o_cb_ev(cb,evs)dt_cb[cb]={0,n,n,evs}end
function o_cb_msg(cb,msg)dt_cb[cb]={0,n,msg}end
function o_cb_cpy(cb1,cb2)o_vr3=cb2 or o_vr3 dt_cb[cb1]=dt_cb[o_vr3]end
function o_mkmj00(id,cx,cy,s_id,b_evs,s_evs)mk_mj(id,f,cx,cy,f,s_id,b_evs,s_evs)end
function o_mkmj01(id,cx,cy,s_id,b_evs,s_evs)mk_mj(id,f,cx,cy,t,s_id,b_evs,s_evs)end
function o_mkmj10(id,cx,cy,s_id,b_evs,s_evs)mk_mj(id,t,cx,cy,f,s_id,b_evs,s_evs)end
function o_mkmj11(id,cx,cy,s_id,b_evs,s_evs)mk_mj(id,t,cx,cy,t,s_id,b_evs,s_evs)end

function ply_msc(ix)if(cr_msc==ix)then return end cr_msc=ix music(ix)nx_ev()end
function ctx(txt,y,gpx,x)print(txt,(x or 64)-#txt*2+(gpx or 1),y,whi)end
function bd(func,...)local a={...}return function()return func(a[1],a[2],a[3],a[4],a[5],a[6])end end

function _init()ply_msc(6)cr_msc=-1 it_tr()it_st()it_sts()end
function _update()if(not is_tr)then cr_st.up()else up_tr()end end
function _draw()cls()cr_st.dr()dr_tr()end