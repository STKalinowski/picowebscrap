--r-type
--THE rOBOz - FOR dORIAN

brush_s={
"*ゆVTR■*ソtXQ¹&W]Ya\r*あ[ZP!*😐kXP■*░hVO!*ヨNXO□\"{X⬅️d⁵'⬇️`☉e6'●b웃d⁷+NbONき+N🅾️ONぬ+N0ONっ",
"&NNイり¹&Qてaは\0&ihyo\0&は\\るk\0&⧗✽け⬆️\0-の]さk\0#f⬇️⌂⬇️\0#f░⌂░⁵+`hUN█+😐KUY…#NQNj\0#Nkf⬇️\0#y░y😐\0#⬆️h⬆️O\0#y♪█⬆️\0#▒⬆️▒え\0#wおqさ\0#pしpへ\0#qほrま\0+●N_V0#sみくみ\0#イgゆv\0#やwや█\0&▥♥き🅾️タ&ふbもiク&ijxmク&Rなaねキ&∧😐い➡️キ&む^よcキ",
"'fてqこ²-oてxた⁴'rき⌂⌂²'jちvえ²*ogさO¹-vす🐱け⁴*ojえO¹'oし~★²'oたrせ\0'rすvさ\0*も✽♪P□'y▤◆웃t'uこ{き\0'pくzˇ⁘'xお~い\0*oq…O¹'pおw❎.'yう●🅾️ᵉ#q➡️t♪²\"yえ●♪ᶠ'qうt▤ᶠ'|い✽🅾️\0&~▥░…わ#♥あ😐∧⁴'w⌂r◆@#[もkへ⁵#\\やrひ⁶#sの{の⁶#oひwの⁵#yの|ふ⁵#|へzみ⁵#{む○も⁵#~も⌂ほ⁵#♥ほ🅾️ほ⁵#{の○ほ⁶#~ほ{み⁶#{み○め⁶#○も🅾️ふ⁶*ヨ◆なO²+N4mNp#Qみ[も⁵#Rま]も⁶*░NひO1+a1wNぬ+NらPNり",
"'WSqd²'VVgaᵉ'XSnbd'XXd`O+_TON@'O^Zq²-aufj⁴-[`eZ\0*えW[O1'XoP_⁴'VgSoᵉ'Q`Um_-SlYe\0*_TfO¹-`t]r⁶-U`Sd▮#fj_s>*o\\aO¹'_boi^'ZfenP",
"*◜PきR¹*ス░にP\"*◜Z∧R1-⬅️▥iか⁷-nそ♪く\r-웃いpけF+NNQV`-iぬおゆ⁵-fね▤や\r*★N▥P¹'✽▥おぬ\r'☉▥いつ⁶'⬅️あ❎さ⁷-♥く🅾️つ\r'♪かてゆ⁵'…かとも\r'★きつみ⁶&fきvし⁶&hくtさ\0&iくsさっ*ゆRぬQ■*ゆRほQ¹*ゆhへQ1-^ね❎やへ'⧗きこに⁷-❎こ⬆️す⁸'せす∧へ⁵*マ❎せP2*▒いつO¹-さませふ⁸+N✽ONヘ",
"'NなZみ⁷-Vのuや⁷-Qねnゆ⁶-Nのhよ\r'NにWめ⁶'NねWも\r-Oふbゆ⁵#ZはNは⁵#XはOは\0#PめXめ\0#QのVのp#PもXもp#QめUめ☉+mNOVオ+N✽ONヘ",
")\\nON\0)ktON\0)うgON\0)웃くON\0)⬆️よON\0)PむON\0)b😐SN\0)dにSN\0)♥USN\0)XXTN\0)yxUN\0)🅾️ひUN\0+~GONら",
"'`zもこ⁵'_Trx\0'eV➡️う	'Yrxˇ/'`s⬆️おT'iW~xN'jYzt8'kZwp²'eatn⁵*テ^TQ³*キu\\O²+FnUNぬ+えNPTら$れgsfw'y}すきな'✽○いかh'웃⬇️▥あ²'⬅️✽い▤⁵'😐☉▥∧M*テ➡️}P#*キ░♥O\"+➡️)]VP",
"'T\\o♪▒'Q[l♥✽'JRi~¹'IRh~\0+ZYOU@'R○😐ょ1'R○웃ん5'P○✽ろm'Fz░る¹'Ez⬇️る\0+♪?OVき\"MQfw▒\"Q{|ふ▒",
"\"NN^^\r\"OO]]ᶜ\"_No^⁸\"`On]ᵉ\"6KMb⁸\"7LLaᵉ  ",
"!PYX]も'WY]]ᶜ'TZ\\\\⁶#R[Z[7'PZZ\\●&ZZ[\\⁷'YXb^ᶜ'XYb]⁶'YZ`\\⁷']Xi^ᶜ'\\Yg]⁶'\\Zf\\⁷'dWs_ᶜ'dXq^⁶'dYq]⁷",
"&Nをイイ\0!🐱っそア⁷",
"*ヨNNO²*ウVNP¹*∧fNP!+NUPN1",
"*ン^NO\"*ンfNO\"*ヲNNP²+LNOV0",
"*ヲNNP²+-NOV▮",
"-◆◆こ○と'Xいˇ🐱⁵&シkえ🐱⁵-⬆️Tコj³'[Vく♪³&e❎⬅️い-'Nh♥⧗³'Mku…ᵇ'Sffvj'Uno}v+v5UNき*ら▒MP¹&▤lオ}#-▥Yウl•'`Vお🐱ᵇ'][あ{●'_Z∧wj&Mz[⬅️\0&bkなt{'Xcゃk●#😐O█`\0*bきdR¹#~TしT\0#\\imz\0#QsとsS*cbiQ¹*ソb{Q¹#OuUu\0#Vu[z\0#yp⬇️z\0*り░🐱O¹#え○█う\0+NvhN⁸#t웃g∧\0#⬇️{⬇️웃\0*のs`R¹*のお|R■'Xze⌂\0'`ˇ🅾️うP-zV☉Nぬ-`cuV█*ゆなsR¹*ゆなmR■",
"&N|♪🐱⁵#N{♪{M*モF⬇️O²*XN⬇️P#+^NRN@*ツ🅾️{O!+-NQZ`*あKsR¹",
"-ˇおふ~⁴&mあ⬆️✽⁴&p▤⧗⌂	'nlたˇ	'qsし⧗⌂'ZUな☉⁵'JQぬ⬇️³*ソpNP¹'SRさsᵇ*あPpR¹'aT😐[⌂*ゆ🐱rQ¹*ああsP¹*ゆ웃xP¹'█hて♥れ*hてsP²*の`|R■*ワJuQ■*ワbtQ!*b♪█R■+NXZNH*ツp➡️P¹*らJ_P!*ツ…➡️O!#P]け]³#U_▒_⌂",
"*●SUO¹*░QMO¹*✽LMO■*✽LUO¹'RPVT\0#TUWU\r",
"*░TRO¹","*✽ROO■*♥UMO¹*✽RUO¹*♥OMO!","*✽RUO¹*✽RQO■*●OMO¹*●VMO!","*░SMO¹*✽NMO■*✽NUO¹'TPXT\0#VUXU\r","*♥PYO¹*♥NSO¹*♥PMO¹*✽LNO■*✽LUO¹",
"*rQYR1*rJSR■'Ehv➡️¹'Flu…c'Hpw⧗て'Ftu…め*にEvP¹*tC~P1'Lxj⬆️\0&E✽R⬅️\0#KwRq	#RxYu	#EuFq	#GpLo	#KpGq⁸#RrMv⁸#XvRy⁸#_xgoᶠ#`WZ_²#^XX`⁴#bjgnᶠ#`iYZᶠ#XV`g⁴#bihn⁴#ho_y⁴#d[hc⁴#gdWq⁴#c[gcᶠ#fdWpᶠ#Y`Kg²#LhNl²#NlSo²#W`Lf⁴#KgMl⁴#NmRo⁴#LZQf⁴#KZPfᶠ#Rg]r⁴#Qg\\rᶠ+N░ONx*テR○P³*ウb○O¹*エb♥O¹*エb◆O■"
}

dither_p=split"32768,32736,24544,24416,23392,23391,23135,23131,6747,6731,2635,2571,523,521,9,1"
e_data=split("1,8,8,240,0,20 1,8,8,180,0,20 99,144,2,0,100 99,4,4,0,-4,0 99,6,6,90,12,0 1,8,8,160,56,20 1,8,8,150,24,50 24,12,8,120,0,50 26,12,8,90,128,80 6,8,8,240,0,50 1,4,4,150,16,10 1,8,8,110,20,20 1,8,8,60,16,20 30,4,4,200,0,1000 8,12,16,120,12,50 1,4,4,120,16,10 20,16,8,200,32,60 10,8,8,32,0,50 30,6,6,620,0,1200 1,8,8,0,32,40 15,8,8,60,1,130 2,8,8,360,12,220 30,31,8,120,0,80 20,20,8,0,0,60 24,16,8,100,0,80 15,8,4,0,0,18 12,8,4,240,16,60 30,16,8,480,0,600 1,8,8,120,192,40 30,8,12,360,0,1500"," ")
brush_d={split("1,768,0,56,0,0 6,1120,0,88,0,0 5,1504,0,96,0,0 4,1974,4,40,0,0 3,1980,0,64,0,0"," "),split("8,1456,42,64,0,0"," ")}

function trifill(x1,y1,x2,y2,c)
  local inc=sgn(y2-y1)
  local fy=y2-y1+inc/2
  for i=inc\2,fy,inc do
  line(x1+.5,y1+i,x1+(x2-x1)*i/fy+.5,y1+i,c)
  end
  line(x1,y1,x2,y2)
end

function pd_draw(index,cx,cy,s_start,h_flip,v_flip,s_end)
  local cmd
  local function _fillp(p, x, y) --@sparr/@Felice
  local p16, x=p\1, x&3
  local f, p32=(15>>x)\1 * 0x1111, p16 + (p16 >>> 16) >>< (y&3)*4 + x
  return fillp(p-p16 + ((p32&f) + (p32 <<> 4 & 0xffff-f))\1)
  end
  local function _flip(p,f,o,n)
  if n>0 then cmd[n]=not cmd[n] else f=64 end
  for i=0,(o==0 and n>0) and 2 or 0,2 do cmd[p+i]=f-cmd[p+i]-o end
  end
  local ox,ecx,oy,ecy=%0x5f28,round(%0x5f28-cx),%0x5f2a,round(%0x5f2a-cy)
  camera(ecx,ecy)

  if (not brush_c[index]) brush_c[index] = {}

  for i=s_start and s_start*6-5 or 1, s_end and s_end or #brush_s[index],6 do

    if brush_c[index][i] then cmd={unpack(brush_c[index][i])}
    else
      cmd={ord(brush_s[index],i,6)}
      cmd[1]+=46
      for j=1,5 do cmd[j]-=78 end
      cmd[7]=(cmd[6]&240)>>4
      cmd[6]&=15
      if (cmd[1]==10) cmd[8],cmd[7]=cmd[7]%2==1,cmd[7]\2==1
      if (cmd[1]==11) add(cmd,index,2) cmd[6]*=8 cmd[7]*=8 cmd[8]=i-6
      brush_c[index][i] = {unpack(cmd)}
    end

    local cc,c6=deli(cmd,1),cmd[6]
    if cc==10 then
      pdx,pdox,pdoy,pdon=2,cmd[4]*8-1,cmd[5]*8-1,6
    elseif cc==11 then
      f_exp(_ENV,"pdx,5,pdox,0,pdoy,0,pdon,-2")
    else
      f_exp(_ENV,"pdx,1,pdox,0,pdoy,0,pdon,6")
      if (c6>0) _fillp(-dither_p[c6] +.5,-ecx,-ecy)
    end

    if(h_flip and h_flip!=0) _flip(pdx,h_flip,pdox,pdon)
    if(v_flip and v_flip!=0) _flip(pdx+1,v_flip,pdoy,pdon+1)

    _ENV[split("rect,oval,line,map,select,rectfill,ovalfill,tri,pset,spr,pd_draw,,trifill")[cc]](unpack(cmd))
    fillp()
  end
  camera(ox,oy)
end

function pd_rotate(x,y,rot,mx,my,w,flip,scale)
  scale=scale or 1
  rot=rot\.05*.05
  w*=scale*4

  local cs, ss = rot_coord(rot,.125/scale)
  local sx, sy = mx+.5+cs*-w, my+w/8+ss*-w
  local hx = flip and -w or w

  local halfw = -w
  for py=y-w, y+w do
    tline(x-hx, py, x+hx, py, sx-ss*halfw, sy+cs*halfw, cs, ss)
    halfw+=1
  end
end

function round(n)
  return (n+.5)\1
end

function any(x,s)
  for e in all(split(s)) do
  if (x==e) return true
  end
end

function f_exp(e,k) --@freds72/@paranoidcactus
  local kv=split(k)
  for i=1,#kv,2 do
  e[kv[i]]=kv[i+1]=="" and {} or kv[i+1]
  end
end

function a_exp(e,k,...)
  local kv,v=split(k),{...}
  for i=1,#kv do
  e[kv[i]]=v[i]
  end
end

function intersects(a,b)
  local _ENV,d=a,e_delta_y(b)
  return not (x2<b.x1 or x1>b.x2 or y2<b.y1+d or y1>b.y2+d)
end

function rot_coord(a,k)
  return k*cos(a),k*sin(a)
end

function pal_d(s)
  pal(s and split(s) or nil)
  palt(0b000000000010000)
end

function pal_fade(x,out)
  local i=min((cam_x-x)\4,3)
  pal_d(split("0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 0,0,0,1,0,5,5,1,1,4,1,1,1,2,2 0,1,1,2,1,13,6,4,4,9,3,13,1,13,14 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15"," ")[out and 4-i or i+1])
end

function _init()
f_exp(_ENV,"map_tile_w,32,map_tile_h,8,bull_speed,3,beam_speed,4,special_speed,4,laser_speed,3,x,0,y,0,st,0,c_stage,0,r9_lives,4,r9_score,0,cam_x,135,brush_c,")
if not boss_x then
for i=0,818 do
local l=@(0x2830+(i\64)*128+i%64)
for xs=0,l%128 do
sset(x,y,l\128*1)
x+=1
if (x>127) y+=1 x=0
end
end

memset(24336,0,16)
cls(11)
for y=0,2 do
for x=0,3 do
  s=32
  for i=0,3-y*x%4 do
  pal(1,split"4,9,6,10"[i+1])
  sspr(x*32,y*32,32,32,x*32+i,y*32+i,s,s)
  s-=i/2+2
end end end
memcpy(0x4300,0x6000,5008)
memset(0x5680,0xbb,1024)
for y=0,2048,64 do
memcpy(0x5300+y,0x1800+y,16)
end
reload()
end
invincible,boss_x=false,split"1980,1514,1560,1530"
music(61)
end

function bbox(e,ky)
  local ky,_ENV=ky or 0, e
  x1,y1,x2,y2=x-w, y-h+ky, x+w, y+h+ky
  if(x1>x2) ky=x1 x1=x2 x2=ky
  if(y1>y2) ky=y1 y1=y2 y2=ky
  x2-=1
  y2-=1
end

function bull_create(parent,...)
  local b=add(parent,{})
  a_exp(b,"id,x,y,w,h,dx,dy",...)
  if(b.id>90) sfx(4)
  local _ENV=b
  sx,cnt,ox,oy,f=(id==1 or id==3) and 0 or x-w/2,0,dx,dy,true
  return b
end

function bull_def(x,y,sy)
  sy=sy or 0
  local sx=abs(sy)==bull_speed and 0 or bull_speed
  if beam_pwr/9 < 1 then
    bull_create(r9_bullet,0, x, y, sx==0 and 1 or 3, sx==0 and 3 or 1, sx, sy)
  end
end

function bull_draw(b)

  local function bd(id,b,...) spr(id,b.x1,b.y1,...) end

  local bt=b.id

  if any(bt,"0,4,6") then
    if abs(b.dy)==bull_speed then
    sspr(14,8,2,6,b.x1,b.y1)
    else
    if(bt==4) pal_d"1,2,3,4,1,14,8,8,9,10,11,2,8"
    if(bt==6) pal_d"1,2,3,4,1,6,12"
    sspr(10,14,6,2,b.x1,b.y1)
    end
  elseif bt==1 then
    local dir=b.w
    line(b.x-dir,b.y-b.h,b.x+dir,b.y+b.h,12)
  elseif bt==2 then
    local g,_ENV=_ENV,b
    if (dx<0) ex,sx=sx,-w*2
    for i=0,1 do
    for x=sx+22,160,34 do
      clip(x1,y1-4+(i*13),w*2,13)
      if(i==1) g.pal_d"1,2,3,4,5,6,7,13,9,10,11,14,8,12"
      g.pd_draw(10,x,y1,1,0,0,x>sx+22 and 24 or 36)
    end
    end
  elseif bt==3 then
    if (b.f) bd(213,b)

  elseif bt==90 then
    bd(17,b,.5,.5)
  elseif bt==93 then
    bd(35,b,1,1)
  elseif bt==96 then
    bd(205,b)
  elseif any(bt,"5,92") then
    if (bt==5) clip(r9.x,b.y1,b.x2,b.y2)
    pd_draw(11,b.x1-8,b.y1-9,1,(sgn(b.dx)-1)*-14,0,18+b.w\4*18)
  elseif any(bt,"7,91,97") then
    if (bt>7) b.r=atan2(b.dx,b.dy)
    local r=b.r-.25
    circfill(b.x1-sin(r)*5,b.y+cos(r)*5,b.cnt%3,9)
    pd_rotate(b.x1,b.y,-r,bt==97 and 124 or 122,12,1)
  else
    bd(bt,b)
  end
  pal_d()
  clip()
end

function bull_missile(y)
  local b=bull_create(r9_bullet,7,r9.x,r9.y-y,3,3,2,0)
  b.mx,b.my=256,y
  return b
end

function bull_visibility(b)
  local bbox,_ENV=bbox,b
  x+=dx y+=dy
  bbox(b)
  if (x1>132 or x2<-4 or y2<0 or y1>120) w=-128
end

function bull_update(b)
  local function collide_map(x,y)
  local m=mget(bgx+(cam_x+x)\map_tile_w,bgy+y\map_tile_h)
  return y>0 and y<120 and (m>0 and (m<106 or m==107)) or ws_collide(x,y)
  end

  id=b.id

  if id==3 then

  b.x -=cam_sx

  local bull_visibility,_ENV=bull_visibility,b
  f=not f

  if collide_map(x,y+dy) then
  dy,cnt=0,1
  else
  dy,cnt=oy,0
  end

  local c=collide_map(x+ox,y)
  if c or cnt==0 then
    dx=0
    if (cnt==1) oy=-oy
  else
    dx=ox
  end

  bull_visibility(b)

  if c and not collide_map(x+ox,y) then
    if (cnt==0) oy,cnt=-oy,1 x+=ox y+=dy
  else
    dy=oy
  end
  sx+=1

  else
  b.cnt+=1
  b.r=0

if id==91 then b.dy+=.04
elseif id==97 and b.cnt>32 then b.dy,b.dx=b.dy*.92,sgn(b.dx)*1.2
elseif id==7 and b.cnt>8 and b.closest then
  b.r=atan2(b.mx,b.my)
  b.dx,b.dy=rot_coord(b.r,2)
end

bull_visibility(b)

if (id>96) then for fb in all(r9_bullet) do
  if (intersects(fb,b)) b.w=0 fb.w-=1 explo_create(b.x2,b.y,8)
end end

if level_collide(b) then
  if any(id,"0,4,7,6,91,97,90") then
    b.w-=b.w
  elseif id==1 and b.w>-128 then
    sfx(5)
    local cam_x,_ENV=cam_x,b
    if dy==0 or (x+cam_x+w/2)%32<=dx then
    dx,w=-dx,-w x+=dx sx+=1
    else
    dy,h=-dy,-h y+=dy sx+=1
    end
  elseif id==2 then
    b.w-=min(b.w,4)
  elseif id==5 then
    b.w-=min(b.w,8)
    if (b.w<8) explo_create(b.x,b.y,16)
  end
  end
  end

  if force.x1 and b.id==90 and intersects(force,b) then
    b.w=0
  elseif id>40 then
    r9_hit(b,0)
  end

  local t=id>47 and e_bullet or r9_bullet
  if b.w==0 or b.w <=-128 or ((id==1 or id==3) and b.sx>16*id) then
    del(t,b)
    if id==1 then
    lasers-=1
    elseif any(id,"7,91,97") then
    explo_create(b.x,b.y,-16)
    if (id==7) del(missiles,b)
    end
  end
end

function e_def(e,k)
  bbox(e,k)
  if force.x1 and intersects(force,e) then
    e.dmg=1.1
    e_hit(e)
  elseif not ending then
    r9_hit(e)
  end

  local eid,x,y,x1=e_local(e)

  e.atn=atan2(r9.x - x,r9.y-y-e_delta_y(e))

  if (e.hit>0) e.hit-=1

  if e.hp!=0 then
    e.dmg=0

    for b in all(r9_bullet) do --no foreach
      if (eid>1 or e.r<=.2 or e.r>=.8) and intersects(b,e) then
        local g,_ENV=_ENV,b
        if g.any(id,"0,1,2,3,4,6,7") then
          if(id<1 or id>2) w=0
          e.dmg=g.any(id,"0,7") and 1 or g.force_power*1.1
        elseif id==5 then
          w-=e.hp>1 and min(w,8) or 0
          e.dmg=w\4+2
          break
        end
      end
    end

    e_hit(e)

    if eid!=15 and eid!=18 and e.tshot>0 and ((x<128 or eid==23)) and e.hp<99 then
      e.tshot-=1
      if eid==10 or eid==28 then
        for i=0,7 do
          if (e.tshot==i*20) bull_create(e_bullet,eid==10 and 91 or 96,x+(eid==10 and 8 or -16+rnd(24)), y, 3, 3, -.8,-2.4)
        end

      elseif e.tshot==0 then
        local bsx,bsy=rot_coord(e.atn,.85)
        if eid==2 and (y<40 or cam_x<1448) then
          for i=0,1,.25 do
          bull_create(e_bullet,93,x, y, 3, 3, rot_coord(i,1))
          end

        elseif eid==8 then
        bull_create(e_bullet,92, x, y, 8, 4, 2*sgn(bsx),0)

        elseif eid==23 then
        bull_create(e_bullet,92, x1, x>124 and y+e_delta_y(e) or 88, 8,4, -2,0)

        elseif eid==9 then
        for i=3,7 do
        bull_create(e_bullet,97,x, y, 3, 3, e.sgx*cos(i/10),sin(i/10)*1.2)
        end

        elseif eid==14 then
        add(ce,split"5,2000,60,4,0")

        elseif eid==30 then
        add(ce,split"5,1570,60,1,0")

        elseif eid==17 then
        add(ce,{18,e.x+cam_x,e.y,1,2})

        elseif eid==25 then
        for i=0,3 do
        bull_create(e_bullet,96,x, y+shell.delta, 4, 4, -1.5,(i-1)\2)
        end

        elseif eid<23 and eid!=16 then
        bull_create(e_bullet,90,x, y+e_delta_y(e), 2, 2, bsx,bsy)
        end
      end
      if (e.tshot<=0) e.tshot=e.shot
    end

  else
    explo_create(x,y+e_delta_y(e), e.w>6 and 32 or 24)
    r9_score+=e.score
    if (eid==20) bull_create(e_bullet,abs(e.who), x, y, 4, 4, -cam_sx,0)
      for m in all(missiles or {}) do
      if (e==m.closest) m.closest=nil
      end
    if eid>5 then
      if eid==29 and e.i>0 then
      e_set(e)
      else
      del(ce,e)
      end
    else
    e.hp=99
    end
    return true
  end
end

function e_delta_y(e)
  return (e.i and e.id>20 and (e.id!=23 or e.y==110)) and shell.delta or 0
end

function e_draw(e)

  local function e_legs()
  local f,_ENV=e.dx>0,e
  local o=cnt\8%4 if(o==3 or cnt<0) o=1
  spr(f and 248-o or 246+o,x1+(f and 2 or 8)-o,y1+7,1,1,f)
  return o
  end

if e.x1 and not ending then

  if (e.hit%2==1) pal_d"12,6,6,6,6,7,7,7,7,7,7,7,7,7,7"
  local id,x,y,x1,x2,y1,y2,f,r,dx,dy=e_local(e)
  function esd(id,...) spr(id,x1,y1,...) end
local tt={
  nil,
  nil,
  function()
  pal(12,11)
  for i=1,3 do
  pd_draw(15+i,x1+split"-4,128,192"[i], y-45)
  end
  end,
  function() esd(e.i==9 and 34 or 33) end,
  function()
  if c_stage == 4 then pal_d"0,1,0,0,0,12,7,12,13,12,12,12,1,7,7" r=x/25
  else pal_d"2,2,8,0,5,6,0,8,5,5,13,0,13,14,13" end
  pd_rotate(x1+6,y1+6,-r,126.5,3,2,false,.75)
  end,
  function() spr(130,x1,y1-e_legs(e),2,2,f) end,
  function() esd(46,2,2,dx>0) end,
  nil,
  nil,
  function() --10
  e.r+=(e.tshot<160 and e.tshot>110) and -.005 or (e.tshot>190 and e.r<0) and .005 or 0
  pd_rotate(x+(f and 0 or -2), y, e.r, 122.5,2.5,3,f)
  pal_d"1,3,3,12,5,6,7,8,6"
  e_legs(e)
  end,
  function() esd(196,1,1,e.dsx<0,y<64) end,
  function()
  for i=0,1 do
  sspr(96,24,16,8,x1,y1+8+e.s*(i-1)-i,16,e.s,false,i==0)
  end
  end,
  function()
  pd_rotate(x,y1+8,-r/180, 123.5,0,2)
  pd_rotate(x,y1+8, r/180-.5,123.5,0,2,true)
  end,
  function() esd(212)end,
  function()
  local vf=e.r>0
  spr(133,x1,y1+(vf and 24 or 0),3,1,f !=(y1%8<4),vf)
  spr(149,x1,y1+(vf and  0 or 8),3,3,f,vf)
  end,
  function() esd(50)end,
  function()
  esd(236+r,2,2,false,y<64)
  spr(236+r,x1+16,y1,2,2,true,y<64)
  end,
  function() esd(e.hp<7 and 206 or 198 ,2,2,e.x%8<4)end,
  function()
  if (e.hit<=4) pal_d"1,2,3,4,1,13,7,12,9,10,11,12,1,1,12"
  esd(24,2,1)
  pal_d"1,2,3,4,2,8,15,8,9,10,11,12,2,14,14"
  spr(24,x-62+y1,98-y1,2,1)
  spr(24,x+50-y1,98-y1,2,1,true)
  end,
  function() esd(24,2,2,dx>0) end, --20
  function() esd(228,2,2,r>0,y<64) end,
  function() pd_rotate(x1+6,y1+6,.25-(e.atn or 0),123,9,2.5) end,
  function() pd_draw(id-9,x1,y1) end,
  function() pd_draw(id-9,x1,y1) end,
  function()
    if (e.tshot<40) sspr(106,96,6,9,x1,y1,-16-rnd(24),16)
    pd_draw(13,x1,y1)
  end,
  function() esd(12,2,1,true) end,
  function()
    esd(58,2,1,true)
    if (e.tshot<40) r=16+rnd(16) e.h+=r bbox(e) sspr(104,96,8,16,x1+2,y2,12,e.h) e.h-=r
  end,
  function() esd(188,4,1,false,true) spr(188,x1,y1+8,4,1,false,false) end,
  function() pd_rotate(x, y, -r\2*.25, 119.5,x\8%5*3,2.5,f) end,
  function() pd_draw(25,x1,y-62) end, --30
}
  if id<3 then
  if (e.hp==99) pal_d"1,13,5,5,1,5,6,6,5,6,6,6,13,13,6"
  pd_rotate(x1+8,y1+8,-r+(e.i>7 and 1/id or 0),126.5,(id==2 and split"9,12,6,6,6,6,6,6,12,9" or split"0,0,3,0,0,0,0,0,0,0,0")[e.i+1], 2)

  elseif any(id,"8,9") then
  if (x%2 <1 and (dx==.8 or dx==0)) spr(221,x+(f and -15 or 7),y-2)
  if id==9 then palt(4536) elseif e.hit%2==0 then pal_d"1,1,3,3,5,12,7,8,11,6,11,6,3,12,13" end
  esd(202,3,2,f)
  spr(234,x1- 2*sgn(dx-.1),y1+15-3.5*dy,3,1,f)

  elseif id>20 and id<29 and not shell then return

  else
  tt[id]()
  end
  end
  pal_d()
end

function e_hit(e)
  local _ENV,sfx=e,sfx
  if (hit>0 or hp==99) return
  if ((id==30 and dmg>1) or (id!= 30 and dmg>0)) then
    hp=max(hp-dmg)
    if (hp>1) hit=12 sfx(6,2)
  end
end

function e_local(e)
  local round,_ENV=round,e
  return id,x,y,round(x1),x2,round(y1),y2,f,r,dx,dy,cnt
end

function e_set(e)
  local _ENV=e
  x,hp,y=(x+80)%190,1,r>0 and 0 or 120
end

function e_visible(e)
  local edata=split(e_data[e[1]])

  local function e_activate(en,idx)
  f_exp(en,"oa,0,os,1,cnt,0,r,0,hit,0")
  a_exp(en,"id,x,y,copy,who",unpack(e))
  a_exp(en,"hp,w,h,shot,dw,score",unpack(edata))

  local g,_ENV=_ENV,en
  i=id==18 and 1 or idx
  local ws=(2^i & who)
  tshot=ws > 1 and (g.rnd(shot)+1)\1 or ws*shot
  x-=g.cam_x
  if id==20 then
    f=who<0 x-=(f and 132 or 0)
  elseif id==22 then
    y-=i*8*g.sgn(copy)
  end
  end

  if not e.i and (e[2]-edata[2]<cam_x+(e[1]<5 and 160 or 128)) then
    e_activate(e,0)
    if ((e.id==2 and e.i==0) or e.id==3) shell=e shell.delta=0
    if (e.copy==0) e.r=1
    for i=1,abs(e.copy)-1 do
    et=add(ce,{}) e_activate(et,i)
    if (et.id==1 and et.i==2) et.hp,shell=6,et
    local _ENV=et
    if y<0 then
    y-=i*dw
    else
    x+=i*dw
    end
    end
  end

  if (e.x2 and not any(e.id,"20,28") and e.x2<-48) del(ce,e) return
  return not ending and (e.i and (e.i>0 or e.x-e.w < ((e.id<=5 or (c_stage==3 and cam_x==1500)) and 232 or 128)))
end

function e_update(e)
  if e_visible(e) then

    function bull_homing(m)
      local emx,emy,abs,_ENV=e.x-m.x, e.y+e_delta_y(e)-m.y,abs,e
      if (id<5 or x>128 or x < m.x) return
      if (e.x> m.x and (not m.closest or abs(emx+emy)<abs(m.mx+m.my))) m.closest,m.mx,m.my=e,emx,emy
    end

  if (respawn_t==0 and e.id!=2) e.x -=cam_sx

  foreach(missiles,bull_homing)

  local f_exp,g,cam_x,rnd,bbox,map_collide,shell,rot_coord,e_def,_ENV=f_exp,_ENV,cam_x,rnd,bbox,map_collide,shell,rot_coord,e_def,e

  dsx,dsy=x-g.r9.x, y+g.e_delta_y(e)-g.r9.y
  sgx,sgy,adx,ady=g.sgn(dsx),g.sgn(dsy),g.abs(dsx),g.abs(dsy)

  if id<2 then
    if (shell.hp==99 and hp==1) hp=-5*i
    if (hp<0) hp+=1
    r,ox=not x1 and .07*i or (r+.00225)%1, x
    c,s=rot_coord(r,40)
    x,y=ox+c+8,60+s
    e_def(e)
    x=ox

  elseif id==4 then
    c,s=rot_coord(  r+i/28, 2.5*i)
    c1=rot_coord(2*r+i/28, 1.5*i)
    kx,ky=c1+4, s+4-2.5*i

    x +=kx --this could be like other "snakes"
    y +=ky
    e_def(e)
    x -=kx
    y -=ky
    r=(r+.0075)%1

  elseif (id==2 and shell.x) or id==5 then

    hp,mul=(i<2 or i>7) and 255 or (cam_x==1454 and y>64) and 1 or hp,.003

    if id==2 and (i>0 or cam_x>1448) then

      if i==0 then
        mul=cnt%2==0  and .003 or -.003
        pr=(pr+mul)%1
        tr=g.round(100*pr)
        if not gk or (tr==76 and mul <0) or (tr==74 and mul >0) then
          if g.any(cnt,"2,3,6,10,13,15") then
            f_exp(e,"gk,59,gy,64")
          elseif g.any(cnt,"1,4,7,8,12,14") then
            f_exp(e,"gk,44,gy,42")
          else
            f_exp(e,"gk,16,gy,88")
          end
          cnt=(cnt+1)%16
        end

        c,s=rot_coord(pr,gk)
        px,py=66+c,gy+s
      end

      dx,dy=(shell.px-x)/14,(shell.py-y)/14
      r=atan2(dx,dy)
      x+=dx
      if (cam_x==1454) x+=(x<64 and -7 or 7)*mul*min(i,5)
      y+=dy

    elseif id==5 and g.c_stage==1 then
      x-=2
      r=(r+.05)%1
      if (not dy) dy=ady\1>24 and -.75*sgy or 0
      if (x<72) y+=dy

    elseif i==0 then
      if id==5 or cam_x<1430 then
        local sk=os%1/44
        if x<8 or x>158 or y<8 or y>112 then
          os+=.25 r+=sk --@GregodEl
        elseif rnd()<.05 then
          os=rnd(1) r+=sk
        end
      else
        pr,r=r,(r+mul)%1
      end
      x+= (id==5 and -1 or 1) * cos(r)
      y+=sin(r)
    end
    shell.px,shell.py=x,y
    e_def(e)

  elseif id==3 or id>20 and id<29 then
    x+=(cam_x%60<16 and cam_x<1390) and 0 or g.cam_sx

    local w=e_def(e)

    if shell.x1 then
      if id==3 then
        local bd=0
        if (cam_x>1490) r=(r+.00075)%4 bd=8
        local v=g.split"180,310,.075,900,1004,.075,1360,1440,.075,1470,1500,.075,310,900,-.075,1010,1350,-.075"
        for i=1,18,3 do if (v[i]<cam_x and cam_x<v[i+1]) delta+=v[i+2] break end
        delta=mid(-32+4*bd, delta+(cam_x==1500 and -.075*sin(r) or 0),24-bd)
        y=62+delta
      else
        if (id==23 or id==25) and x<62*(id==25 and 1 or 2.2) then
        x-=.15  y=id==25 and 76 or (y>88 and 76 or min(y+.25,88))
        e_def(e)

        else y1+=shell.delta y2+=shell.delta
          if id==28 then
            r=(r+.002)%3
            if(x2<132) x+=cos(r)/6
            if(w) g.do_ending()
          end
        end
      end
      x+=cam_x>1490 and cos(shell.r)/4.5 or 0
    end

  elseif g.any(id,"7,13,16,20") then

    if id==7 then
    dx,dy,s=(adx<90 and dx) or -.5*(sgx-.35), ((adx<64 and ady>4) and -.35*sgy or 0),0
    else
    dx,dy=(id==20 and .75 or 1)*(f and .75 or -1), 0
    end

    x+=dx
    bbox(e)
    if id!= 16 and map_collide(e)then
      x-=dx
      if id==7 then dx=-dx else f=not f end
    end

    r,s=rot_coord(x/128,id==13 and 12 or id\2)
    if id!=7 then
      if(y<32 and id==13) r=65-y x-=dx dy=1.25 dy=max(dy-.25)
      if (id==16 and tshot>0 and tshot < 40) dy=1
    end
    y+=dy
    e_def(e,s)
    if (map_collide(e)) y-=dy

  elseif g.any(id,"8,9") then
    f,dy=dsx<0, ady<1 and 0 or -.3*sgy
    dx=((adx<48 or tshot<15) and .8 or 0) * (f and -1 or 1) + (f and .35 or 0)

    bbox(e)
    if (map_collide(e)) x-=dx
    if (y<96 or adx<=64) y+=dy
    e_def(e)
    if (map_collide(e)) y-=dy
    if y<96 and x<124 then x+=dx else dy=0 end

  elseif g.any(id,"6,10") then
    if(id==6 or r==0) cnt+=1
    dx,dy=dx or -.25, 1
    f=dx<0
    if ((id==10 and r==0) or (y>87 and id==6)) x+=dx
    bbox(e)
    if (map_collide(e) or (x2<0 and dx==-.25)) x-=dx dx=(dx==-.25 and .6 or -.25)
    y+=dy
    e_def(e)
    if map_collide(e) then y-=dy else cnt=0 end

  elseif id==11 then
    e_def(e)
    if (map_collide(e)) y+=y>64 and -8 or 8

  elseif id==12 then
    x-=.75
    c=g.abs(cos(x/26))
    s=max(2,8*c)
    e_def(e,8*sin(x/64))

  elseif g.any(id,"14,19,30") then
    r=(r+.01)%4
    c1,s1=rot_coord(r,.125)
    if id==14 and r<3 then
    x+=c1
    g.brushes[4][2]= 1974+c1*(tshot<50 and 16 or 0)
    elseif r<2 then
    y+=s1
    end
    if (e_def(e)) g.do_ending()

  elseif g.any(id,"15,29") then
    if ((dx or (dsx < (1+i%2*-1)*64) and tshot>0) and hit <2) dx=f and .4 or -.4+g.cam_sx y+=r x+=dx
    if r==0 then
    r,f=(y>10 and -1 or 1)*(id==15 and .8 or .8+g.cam_sx),i%2!=0
    elseif id==29 and dx and ady>104 then
    g.e_set(e)
    end
    e_def(e)

  elseif id==17 then
    r=tshot<30 and 2 or 0
    e_def(e)
    y1 +=(tshot<40 and rnd(2) or 0)

  elseif id==18 then
    if ((not tx and not ty) or adx > 48 or ady > 48) tx=64-sgx*(16+tshot) ty=60-sgy*(16+tshot)
    dx,dy=tx > x and .45 or -.2, (hit>0 and hp<7) and 2 or (ty>y and .2 or -.2)
    x+=dx
    y+=dy
    e_def(e)
  end
  end
end

function do_ending()
  ending=true music(63) sfx(3,-2) if (force_type>0 and force.status>0) force.status=3
end

function explo_create(...)
  if (#explos>=12) return
  local e=add(explos,{})
  sfx(7,2)
  a_exp(e,"x,y,k",...)

  if e.k<0 then
    f_exp(e,"k,16,w,16,d,8,frm,18")
  else
    f_exp(e,"w,32,d,4,frm,0")
  end
end

function explo_draw(e)
--if frm !=last_frame then
--last_frame=frm
  if (e.frm%e.k>7) del(explos,e)
  local _ENV=e
  for y=1,w do
  local c=y*64
  memcpy(0x17C0+c,0x42C0+c+frm\1%d*w\2+frm\d*2048,w\2)
  end
--end
  if (c_stage==4) pal_d"1,2,3,1,5,12,7,8,13,6,11,12,13,14,15"
  sspr(0,96,w,w,x-k/2,y-k/2,k,k)
  frm += .35
end

function r9_explode()
  if (not invincible) explo_create(r9.x-4,r9.y,24) r9.hit=true
end

function r9_hit(e,screen)
  local id=e.id
  if not r9.hit and intersects(r9,e) then
  if screen and id<54 then
  if(id==48 and r9.acc<1.65) r9.acc+=.15 r9_auto=25
  if(id==49) missiles=missiles or {}
  if(id>50) force_type=id-50 force_power=min(force_power+1,2)
  del(e_bullet,e)
  r9_score+=40
  sfx(2)
  else
  r9_explode()
  end
  end
  return r9.hit
end

function r9_init(w)
  level_init(w)
  sfx(3,-2)
  f_exp(_ENV,"beam_pwr,0,lasers,0,respawn_t,0,r9_auto,40,r9,,r9_bullet,,force,,force_type,0,shot_delay,0,force_power,-1,ff,0")
  f_exp(force,"x,-16,y,64,w,4,h,4,sx,2,sy,0,target,96,status,1")
  f_exp(r9,"x,8,y,64,w,2,h,2,sx,0,sy,0,acc,.85,frm,4,b_color,0")
  r9.hit,missiles=false
end

function r9_shoot(m)
  if (missiles and #missiles==0) add(missiles,bull_missile(-8)) add(missiles,bull_missile(8))
  if (m) return
  bull_def(r9.x1,r9.y-r9.frm\2)
  if force_type > 0 then
  if force.status==0 then
  if beam_pwr/9 < 2 and shot_delay==0 and force_power>0 then
  if force_type==1 then
  if(lasers==0) shot_delay=10
  elseif force_type==2 then
  if force_power==2 then
  --sx is x-w/2xz
  bull_create(r9_bullet,force_type,force.x2,force.y,17,8,f_sign*3, 0)
  shot_delay=20
  else
  local sx=force.sx>0 and bull_speed or -bull_speed
  local function red_small(t,x,y) bull_create(r9_bullet,t, force.x+x, force.y+y, 3, 1, sx, 0) end
  red_small(4,6,-6) red_small(4,0,-6) red_small(6,6,4) red_small(6,0,4)
  shot_delay=20
  end
  else
  shot_delay=6*force_power
  end
  sfx(5)
  return
  end
else
  local fx,fy=force.x,force.y
  bull_def(fx+4,fy,force_power>0 and 1)
  if (force_power>1) bull_def(fx,fy, bull_speed) bull_def(fx,fy, -bull_speed)
  if (force_power>0) bull_def(fx+4,fy,-1)
  shot_delay=20
end
  end
  sfx(0)
end

function level_init(w)
  if (w) c_stage,st,s_score=st+1,st+1,r9_score
  if (c_stage>4) _init() return
  if c_stage==4 then
    for y=0,2048,64 do
    memcpy(0x1000+y,0x5300+y,16)
    end
  else
    reload()
  end

  for i=0,12 do memset(10288+i*128,0,64) end
  srand(c_stage)
  f_exp(_ENV,"last_frame,-1,start_brush,1,e_bullet,,explos,,brushes,,shell,,")
  shell.delta,bgy,bgx,ending,level_fade_out_start,level_end,fl=0,c_stage\3*15,(c_stage+1)%2*65,false,boss_x[c_stage]-60,boss_x[c_stage]+(c_stage<4 and 64 or 300), c_stage == 4 and 696 or 64

  for b in all(brush_d[c_stage]) do add(brushes,split(b)) end
  enemies=split("12,260,32,4,8 12,278,80,4,4 13,336,48,5,1 6,330,102,1,1 13,364,80,5,1 12,392,80,3,0 12,430,48,4,2 12,448,80,3,2 12,466,70,3,2 12,478,80,2,0 12,492,40,3,4 20,508,64,1,51 12,508,78,1,0 12,524,82,2,0 12,542,72,1,0 12,562,32,1,0 12,572,80,1,0 6,570,94,4,1 12,580,32,2,0 8,618,64,1,1 10,674,104,1,1 6,724,90,1,1 13,732,-8,5,1 13,780,60,1,1 6,758,-88,1,0 7,836,64,4,9 7,840,16,4,5 7,840,100,4,5 7,900,40,4,5 7,900,76,4,3 6,940,80,2,0 11,937,20,4,10 11,937,100,4,1 10,1054,104,1,1 20,1078,68,1,48 13,1074,-128,5,1 20,1094,52,1,51 11,1097,12,2,0 1,1160,52,11,52 11,1289,12,8,13 6,1300,88,1,1 12,1342,80,3,4 20,1360,64,1,48 10,1368,104,1,1 12,1380,64,2,0 20,1420,56,1,52 13,1428,-8,5,1 6,1416,-128,1,0 6,1440,88,1,1 11,1447,20,2,0 11,1447,100,2,1 20,1532,60,1,49 11,1609,12,6,9 9,1624,98,2,3 20,1756,32,1,51 4,1998,88,10,0 14,2018,60,1,1/20,256,88,1,48 15,256,120,3,2 15,308,0,3,1 15,408,120,3,1 15,428,0,1,1 15,498,120,4,11 15,498,0,3,1 16,560,56,8,69 16,600,86,8,36 16,640,92,8,196 16,680,42,8,85 16,720,62,8,133 16,760,88,8,22 16,800,52,8,0 16,832,108,8,16 20,660,72,1,53 15,560,124,3,3 15,576,0,1,1 17,566,104,1,1 15,620,0,2,0 15,684,0,3,2 15,704,120,2,5 17,748,14,1,1 15,800,120,2,2 15,832,0,3,2 15,864,122,2,1 15,970,120,3,3 20,1008,88,1,51 15,1020,120,1,1 15,1090,0,3,3 15,1100,120,3,2 2,1108,56,10,168 15,1162,0,2,0 20,1178,72,1,51 19,1520,57,1,0/20,252,46,1,53 20,372,68,1,53 24,516,78,1,0 23,772,110,1,1 28,976,53,1,1 3,354,62,1,0 25,210,70,1,1 24,402,95,1,0 26,500,13,1,0 27,760,97,4,15 21,284,87,1,1 22,264,47,3,7 22,326,66,1,1 22,326,74,1,1 22,348,92,-3,7 21,410,19,1,1 21,546,78,0,1 22,616,24,-3,7 21,772,46,0,1 22,980,38,3,7 22,1260,20,-3,7 22,1230,98,3,7 21,1370,36,0,1 21,1372,74,0,1 22,1400,58,1,1 12,732,96,2,1 12,828,92,1,0 20,860,88,1,52 6,880,102,2,1 20,1376,80,1,-51 20,1472,84,1,51/20,836,56,1,53 20,852,64,1,48 5,1080,64,1,0 20,1008,32,1,48 20,1368,92,1,51 20,1374,52,1,52 29,796,120,5,255 29,812,0,5,255 30,1582,64,1,1","/")

  ce=split(enemies[c_stage]," ")
  for i=1,#ce do
    ce[i]=split(ce[i])
  end

  check_p=({split"1400,620,96,0",split"1304,800,0,0",split"0,0,0,0", split"632,632,632,632"})[c_stage]

  for i=1,4 do
    if (cam_x-64+fl>=check_p[i]) cam_x=check_p[i] music(({split"19,24,18,14",split"28,32,28,57",split"42,42,42,42",split"42,42,42,42"})[c_stage][i],0,7) break
  end

  if w then
    cam_x=check_p[4]
  else
    for e in all (ce) do
      if e[1]==2 and cam_x>=1300 then e[2]=1462
      elseif e[2]<cam_x+100 then del(ce,e)
     end
    end
  end

  stat(0)
end

function level_collide(e)
  return not ending and (map_collide(e) or ws_collide(e))
end

function map_collide(e)
  local mx,my,mx2,my2=bgx+(cam_x+e.x1)\map_tile_w, bgy+e.y1\map_tile_h, bgx+(cam_x+e.x2)\map_tile_w, bgy+e.y2\map_tile_h
  return mget(mx,my)+mget(mx2,my)+mget(mx,my2)+mget(mx2,my2)>0
end

function ws_collide(e,y)
  if (y) e={x=e,y=y}
  return c_stage==3 and shell.x and mget((e.x-shell.x1)\map_tile_w+119,(e.y-shell.y+40)\map_tile_h+15)==34
end

function beam_draw(bx)
  bx=bx or 8+(force.sx==12 and 9 or 1)
  palt(0b111110000010000)
  local _ENV=r9
  b_color=(b_color-.4)%8
  for i=0,2 do
  pal(b_color+i,13-(i<2 and i or 12))
  palt(b_color+i,false)
  end
  spr(197,x + bx,y-3,1,1,bx<0)
end

function prlx_draw(b,c)
  for i=0,1 do
  if (c) clip(0,0,c-cam_x,127)
  pd_draw(b,-(cam_x\2%128-128*i),0)
  end
  clip()
end

function _draw()
  cls()
  if c_stage<1 then
    camera()
    pal_d()
    if cam_x ==0 then
      ?"blast off and strike\nthe evil bydo empire\+fh:\+ec,\|j\n\n        ⬅️ stage "..(st+1).." ➡️\n\|h         ❎ cheat "..(invincible and " on" or "off").."\n\n\n\n\n\n\n\n\n\n\|j\*c   1.4\n\n\n\n   @2021 BY  tHErOBOz\n   music BY yOURYkIkI",42,2,12
      ?"press 🅾️ to start",58,44,t()%2+1
    else
      cam_x -=3
    end
    for i=0,5 do camera(-cam_x - i*(16-cam_x/8)-(i>0 and 16 or 22),0)
      pd_draw(19+i,4,72)
    end
  else

    --draw far_bg
    local ef=boss_x[c_stage]-256
    if cam_x<=ef+64 then
      if cam_x<900 then
        pal_fade(0)
        if (c_stage==1) prlx_draw(7,820)
      else
        if cam_x>ef then
        if (stat(24)<56) music(56,0,3)
        pal_fade(ef,true)
        elseif c_stage==1 then
        pal_fade(900)
        end
        if (c_stage==1) prlx_draw(2)
      end
      if (c_stage==2) prlx_draw(9)
      pal_d()
    end

    foreach(e_bullet,bull_draw)
    foreach(ce,e_draw)

    if cam_x< fl then
      pal_fade(check_p[4])
    elseif cam_x> level_fade_out_start then
      pal_fade(level_fade_out_start,true)
    end

    for i=start_brush,#brushes do
    local b,bx=brushes[i],brushes[i][2]
    if bx < 128+cam_x then
    if bx+b[4] > cam_x-8 then
    pd_draw(b[1],-cam_x+bx,b[3])
    else start_brush=i+1 end
    else break end
    end

    camera(round(cam_x),0)

    local cx=cam_x\32+bgx
    for cmy=bgy,bgy+14 do
      for cmx=cx,cx+4 do
        local w,m,mx,my=2,mget(cmx,cmy),cmx-bgx,cmy-bgy
        local x,hflip,m4=mx*map_tile_w,m%4==3,m-m%4

        local function bgs(mo,px,hf) spr(m4+mo,px,my*map_tile_h,w,1,hf,my<10) end

        if m<35 then
        elseif m%4==1 then
        bgs(0,x,hflip)
        bgs(0,x+16,not hflip)
        elseif m%4==2 then
        bgs(2,x,not hflip)
        bgs(2,x+16,hflip)
        else
        w=4
        bgs(0,x,hflip)
        end
      end
    end

    camera()
    pal_d()
    if respawn_t==0 then
      foreach(r9_bullet, bull_draw)
      spr(4+r9.frm\3*2,round(r9.x)-8,round(r9.y)-5,2,1)
      if (beam_pwr>3) beam_draw()
      if (r9_auto>0) beam_draw(-16)
      pal_d()
      if c_stage==4 and ending then
      for i=2,29,6 do
      srand(i)
      pal(12,i)pal(3,5)
      spr(4,28+rnd(70)+min((2+rnd(1.5))*(-boss_x[4]+cam_x)),4*i-8,2,1)
      end
      end
      pal_d()

      if force.x>=0 then
        local fp=force_power==2 and 8 or 4
        spr(249,force.x1,force.y1,1,1)
        sspr(56+2*fp,64+ff\1*14,8,14,force.x-fp,force.y1-3,force_power>0 and 12 or 8,14)
        ff=(ff+.2)%4
      end
    else ?"\^p"..split" game over ,   ready,   ready,   ready"[r9_lives],22,60,9
    end

    foreach(explos,explo_draw)
    if (ending) s_score+=s_score<r9_score and 10 or 0 ?(c_stage==4 and cam_x>1550) and "thanks to your\nbrave fighting\nthe bydo empire\nwas annihilated.\nyour name will\nremain in the\nuniverse forever!\n\nthank you for playing\nthe game to the end\n\ntHErOBOz" or "\n\n stage clear! "..s_score.."0",24,32,12
    pd_draw(12,0,0)
    rectfill(53,123,53+beam_pwr,125,12)
    for i=1,(7*r9_lives-12),7 do
      spr(251,i,121)
    end
    ?"beam\*b \f7"..r9_score.."0",36,122
  end
end

function _update60()
  if c_stage==0 then
    if (btnp(⬅️)) st-=1
    if (btnp(➡️)) st+=1
    st%=4
    if (btnp(❎)) invincible=not invincible
    if (btnp(🅾️)) r9_init(true)
  else

  if respawn_t>0 then
    respawn_t-=.03
    if respawn_t<=0 then
      r9_lives-=1
      r9_init()
      if (r9_lives==0) _init() return
    end
  else
  if r9.hit then music(r9_lives) respawn_t=8-r9_lives
  elseif cam_x>=level_end and s_score==r9_score then level_init(true)
  else
    cam_sx,shot_delay,r9_auto=(cam_x<level_fade_out_start or (ending and cam_x<level_end)) and .25 or 0,max(shot_delay-1),max(r9_auto-1)
    cam_x+=cam_sx
    f_exp(r9,"sx,0,sy,0")
    if ending or cam_x < fl-32 then
      r9.frm,r9.sx,r9.sy=0,min(-sgn(r9.x-3)),abs(r9.y-64) < 1 and 0 or -sgn(r9.y-fl)
      if (cam_x<fl-52) r9.sx=3
      if ending then
        f_exp(_ENV,"beam_pwr,0,r9_auto,40")
        srand(t())
        if (cam_x < boss_x[c_stage]-30) explo_create(16+rnd(104),24+rnd(96),rnd(16)+24)
      end
    else
      if btnp(❎) then
        if beam_pwr==0 then
          sfx(2)
          local _ENV=force
          if (status==2) sx=0
          status +=1-status%2
        end
        r9_shoot()
      elseif btnp(🅾️)then
        r9_shoot(beam_pwr>1)
      elseif btn(🅾️) then
        beam_pwr=min(beam_pwr+1, 36)
        if (beam_pwr==10) sfx(2)
        if (beam_pwr==36) sfx(3)
      else
        if (beam_pwr\9>1) bull_create(r9_bullet,5,r9.x2, r9.y, (beam_pwr\9)*4, 4.5, beam_speed, 0) sfx(3,-2) sfx(4)
        beam_pwr=0
      end

      if(btn(❎))beam_pwr=1
      local fa,ff=r9.acc,r9.frm
      if (btn(⬆️)) r9.sy-=fa r9.frm=min(ff+.5,6)
      if (btn(⬇️)) r9.sy+=fa r9.frm=max(ff-.5,-6)
      if (btn(⬅️)) r9.sx-=fa
      if (btn(➡️)) r9.sx+=fa
      if (not btn(⬆️) and not btn(⬇️) and ff!=0) r9.frm -=sgn(ff)*.5
    end

    do
    local _ENV=r9
    if (sx*sy!=0) sx,sy=sx*.707,sy*.707
    x,y=mid(3,x+sx,112), mid(3,y+sy,112)
    end

    bbox(r9)

force_update()

  foreach(r9_bullet,bull_update)
  foreach(ce,e_update)
  foreach(e_bullet,bull_update)
  end end
end

function force_update()

--force_update
if force_type!=0 then
  f_sign=sgn(force.sx)
  if force.status==0 then
  force.x=round(r9.x)+force.sx
  force.y=round(r9.y)
  if force_power>0 then
  if force_type==1 and shot_delay>10-force_power*2 then
    max_laser_s=laser_speed*2
    for j=-1,1 do
    bull_create(r9_bullet,1,force.x-f_sign*max_laser_s, force.y+j*max_laser_s, f_sign*laser_speed, -j*laser_speed, f_sign*max_laser_s, -j*max_laser_s)
    lasers+=1
    end
  elseif force_type==3 and shot_delay%2==1 then
    for d=-1,1,2 do
    bull_create(r9_bullet,force_type, force.x, force.y, 4, 4, f_sign*special_speed, d*special_speed)
    end
  end
end
else
  force.x+=force.sx
  bbox(force)
  if (level_collide(force)) local _ENV=force x-=sx status=3
  local dx=abs(r9.x-force.x)
  if force.status==1 then
    local abs,fx,_ENV=abs,r9.x,force
    if (abs(sx) !=2) sx=x > fx and 2 or -2
    if x <=0 and sx<0 then
      status,target=2,32
      sx/=-4
    elseif x >=120 and sx >0 then
      status,target=2,96
      sx/=-4
    end
  else
    if force.status==2 then
      local _ENV=force
      if x < target then sx=.5 elseif x > target then sx=-.5 else
      sx=0 if (dx<28) target=target==96 and 32 or 96
      end
    else
      local fx,_ENV=r9.x,force
      if sx <  .5 and x > fx-24 then sx=-.5 else sx=.5 end
      if sx > -.5 and x < fx+24 then sx=.5 else sx=-.5 end
    end

    if (level_collide(force)) force.x-=(force.sx>0 and force.sx or -cam_sx)
    local dy=abs(force.y-r9.y)
    do
      local f,dy,_ENV=r9,dy,force
      if     y> f.y+20 then sy=-.25
      elseif y< f.y-20 then sy=.25
      elseif f.sy==0 and dy<=2 then sy=0
      end
      y +=sy
      if (dy <=6 and dx <=12) status=0 sx=(x > f.x and 12 or -12)
    end
    if (level_collide(force)) force.y-=force.sy
    force.y=mid(4,force.y+force.sy,112)
    bbox(force)
  end
end
bbox(force)
force.x=mid(0,force.x,120)
end

if (not r9.hit and r9_auto==0 and level_collide(r9)) r9_explode()
end
end
