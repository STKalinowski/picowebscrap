-- low knight
--  demake by @krajzeg
gx=false
function du(o_)
if (type(o_)~="table")return o_
local ns={}
setmetatable(ns,getmetatable(o_))for k,v in pairs(o_)do
ns[k]=du(v)end
return ns
end
function dv(oe,ma,ls)
if (not oe[ma])oe[ma]={}
add(oe[ma],ls)end
function jk(e,oo,p1,p2)local fn=e[oo]
if fn then
return fn(e,p1,p2)end
end
function bk(e,ma)local p=e[ma]
if (not p)return nil
if type(p)=="table" and p[e.lc]then
p=p[e.lc]
end
if type(p)=="table" and p[1]then
p=p[1]
end
return p
end
function lb(x)
return flr(x+0.5)end
function mn(a,b,t)
return b*t+a*(1-t)end
function im(a,s,x,...)
x-=#s*a*4
print(s,x,...)end
function on(o,ku)for k,v in pairs(ku or {})do
o[k]=v
end
return o
end
function nf(fn,a)
return fn
and fn(a[1],a[2],a[3],a[4],a[5])or a
end
function ob(og,ku)local is,s,n,jx=
{},1,1,0
es(og,function(c,i)local sc,os=sub(og,s,s),i+1
if c=="(" then
jx+=1
elseif c==")" then
jx-=1
elseif jx==0 then
if c=="=" then
n,s=sub(og,s,i-1),os
elseif c=="," and s<i then
is[n]=sc=='"'and sub(og,s+1,i-2)or sub(og,s+1,s+1)=="("and nf(lw[sc],ob(sub(og,s+2,i-2)..","))or sc!="f"and band(sub(og,s,i-1)+0,0xffff.fffe)s=os
if (type(n)=="number")n+=1
elseif sc!='"'and c==" " or c=="\n" then
s=os
end
end
end)
return on(is,ku)end
function es(og,fn)local rs={}
for i=1,#og do
add(rs,fn(sub(og,i,i),i)or nil)end
return rs
end
je={}
function je:hj(of)if type(of)=="string" then of=ob(of)end
of=of or {}
of.gr=self
for lp in all(of.cp)do
jb.ia[lp]=of
end
return setmetatable(of,{__index=self,__call=function(self,ob)ob=setmetatable(ob or {},{__index=of})local ko,gv=of
while ko do
if ko.mf and ko.mf~=gv then
gv=ko.mf
gv(ob)end
ko=ko.gr
end
return ob
end
})end
function bz()local a=0x5d00
for p=0,15 do
for c=0,15 do
poke(a,bor(sget(p,c),c==14 and 0x80))
a+=1
end
end
end
function cv(no,ow)memcpy(ow or 0x5f00,0x5d00+shl(flr(no),4),16)end
hc={}
hc.__index=hc
function hc:__add(b)
return v(self.x+b.x,self.y+b.y)end
function hc:__sub(b)
return v(self.x-b.x,self.y-b.y)end
function hc:__mul(m)
return v(self.x*m,self.y*m)end
function hc:__div(d)
return v(self.x/d,self.y/d)end
function hc:__unm()
return v(-self.x,-self.y)end
function hc:nr(v2)
return self.x*v2.x+self.y*v2.y
end
function hc:lx()
return self/sqrt(#self)end
function hc:n_()
return v(-self.y,self.x)end
function hc:lb()
return v(lb(self.x),lb(self.y))end
function hc:pb()
return sqrt(#self)end
function hc:__len()
return self.x^2+self.y^2
end
function hc:og()
return self.x..","..self.y
end
function v(x,y)
return setmetatable({x=x,y=y
},hc)end
function nv(ei,kj)
return v(cos(kj)*ei,sin(kj)*ei
)end
ne=je:hj()function ne:dz(v)
return ne({xl=self.xl+v.x,yt=self.yt+v.y,xr=self.xr+v.x,yb=self.yb+v.y
})end
function ne:hi()
return v(self.xl+self.xr,self.yt+self.yb)*0.5
end
function ne:et(b)
return
self.xr>b.xl and
b.xr>self.xl and
self.yb>b.yt and
b.yb>self.yt
end
function ne:fj(p)
return self:et(mz(p,p+v(0.01,0.01)))end
function ne:mk(b,f_)local dr={v(b.xl-self.xr,0),v(b.xr-self.xl,0),v(0,b.yt-self.yb),v(0,b.yb-self.yt)}
if type(f_)~="table" then
f_={true,true,true,true}
end
local ml,mv=32767
for d,v in pairs(dr)do
if f_[d]and #v<ml then
ml,mv=#v,v
end
end
return mv
end
function ne:og()
return self.xl..","..self.yt..":"..self.xr..","..self.yb
end
function nz(xl,yt,xr,yb)
return ne({xl=min(xl,xr),xr=max(xl,xr),yt=min(yt,yb),yb=max(yt,yb)})end
function mz(v1,v2)
return nz(v1.x,v1.y,v2.x,v2.y)end
lw={v=v,b=nz}
v0=v(0,0)jb=je:hj([[
lc="lj",t=0,
gk=1,
ia=o(),
dw=0,
]])function jb:mf()if self.hu then
self.hu=du(self.hu)if not self.i_ then
self.i_=db
end
self.ka=du(self.ka)end
end
function jb:ie(lc)if lc~=self.lc then
self.lc,self.t=lc,0
end
end
function jb:mp(ov)
if (not self.mo)return false
for i=1,#self.mo do
if (self.mo[i]==ov)return true
end
return false
end
function jb:fq(lr)for s in all(lr)do
local p=self.nm+s[2]
spr(s[1],p.x,p.y,1,1,s[3],s[4])end
end
function jb:hx(c,s,r,vl)vl=vl or 0.5
local nj=dd(self)
if (not nj)return
local p=nj.b:hi()for i=1,24*s do
local ot=nv(rnd(vl),rnd())ct:kg({p=p,v=ot,he=rnd(r),oj=c,nh=1-vl*0.03,l=s+rnd(0.5)})end
end
hh=jb:hj([[
gk=f,
]])function db(e)local s,p=e.hu,e.nm
local pa=jk(e,"cz")or e.lc
function jl(ma,ng)local st=s[pa]
if (st~=nil and st[ma]~=nil)return st[ma]
if (s[ma]~=nil)return s[ma]
return ng
end
local sp=p+jl("offset",v0)local w,h=
s.jm or 1,s.hg or 1
local hw,jc
local ib=e.sp
and {e.sp}
or s[pa]
or s.lj
if jl("flips")then
hw,jc=e.gy,e.fh
end
local jq=ib.jq or 1
if (type(ib)~="table")ib={ib}
local ds=flr(e.t/jq)% #ib + 1
local ou=ib[ds]
if (e.nw)cv(e.nw)
spr(ou,lb(sp.x),lb(sp.y),w,h,hw,jc)
if (e.fa)cu(e,p)
end
function cu(self,p)local d,ho=
self.ot.x,bk(self,"head_off")local focus=self.fl and 3 or 0
d=d~=0 and d/1.4 or 0
self.jv=mn(self.jv or ho,ho+v(d,abs(d)+lb(self.ot.y)+focus)*self.ht,0.2
)local hp=p+self.jv
local hf=self.gy
if self.dt then
hf=not hf
end
spr(bk(self,"fa"),lb(hp.x),lb(hp.y),1,1,hf)end
function ch()fe,bs,bd={},{},{}
reload(0x1000,0x1000,0x800)end
function k_(e)add(fe,e)for p in all(ba)do
if (e[p])dv(bs,p,e)
end
if e.mo then
for t in all(e.mo)do
dv(bd,t,e)end
bj(e)end
return e
end
function ez(e)del(fe,e)for p in all(ba)do
if (e[p])del(bs[p],e)
end
if e.mo then
for t in all(e.mo)do
del(bd[t],e)if e.oh then
del(fk(t,e.oh.x,e.oh.y),e)end
end
end
e.oh=nil
end
ba={"gk","i_","dh","ot","br","gl","ka"}
function cc()for pc in all(bs.gk)do
local lc=pc.lc
if pc[lc]then
pc[lc](pc,pc.t)end
if lc~=pc.lc then
pc.t=0
else
pc.t+=1
end
end
end
function bu()for pc in all(bs.gk)do
if pc.mr then
ez(pc)end
end
end
function fr(fn)
if (not ea)ea=fn
end
function ci(ma)local eg={}
for pc in all(bs[ma])do
local jw=pc.c_ or 0
if not eg[jw]then
eg[jw]={}
end
add(eg[jw],pc)end
for o=0,15 do
for pc in all(eg[o])do
gc(ma)pc[ma](pc,pc.nm)end
end
end
function gc(ma)cv()
if (ma~="dh" and js)js:kn()
end
function cj()for pc in all(bs.ot)do
local ev=pc.ot
pc.nm+=ev
if (pc.nn or ev.x~=0 or pc.gy==nil)then
pc.iq=sgn(pc.nn or ev.x)pc.gy=pc.iq<0
end
if pc.ig then
local w=bk(pc,"ig")
pc.ot+=v(0,w)
end
end
end
function ce(e)local p=e.nm
return flr(shr(p.x,4)),flr(shr(p.y,4))end
function fk(t,x,y)local pe=t..":"..x..","..y
if not eq[pe]then
eq[pe]={}
end
return eq[pe]
end
function bb()for e in all(bs.gk)do
bj(e)end
end
function bj(e)
if (not e.nm or not e.mo)return
local bx,by=ce(e)if not e.oh or e.oh.x~=bx or e.oh.y~=by then
if e.oh then
for t in all(e.mo)do
local nq=fk(t,e.oh.x,e.oh.y)del(nq,e)end
end
e.oh=v(bx,by)for t in all(e.mo)do
add(fk(t,bx,by),e)end
end
end
function b_(e,ov)local cx,cy=ce(e)local bx,by=cx-2,cy-1
local oh,lv,bi={},0,1
return function()while bi>lv do
bx+=1
if (bx>cx+1)bx,by=cx-1,by+1
if (by>cy+1)return nil
oh=fk(ov,bx,by)lv,bi=#oh,1
end
local e=oh[bi]
bi+=1
return e
end
end
function bh()eq={}
end
function bw()bb()for e in all(bs.br)do
for ov in all(e.br)do
local il=bd[ov]or {}
local gw=
#il
if gw>4 then
for o in b_(e,ov)do
if o~=e then
local ec,oc=
dd(e),dd(o)if ec and oc then
be(ec,oc)end
end
end
else
for oi=1,gw do
local o=il[oi]
local dx,dy=
abs(e.nm.x-o.nm.x),abs(e.nm.y-o.nm.y)if dx<=32 and dy<=32 then
local ec,oc=
dd(e),dd(o)if ec and oc then
be(ec,oc)end
end
end
end
end
end
end
function gj(nz,mo)local ic={nm=v(nz.xl,nz.yt)}
for ov in all(mo)do
for o in b_(ic,ov)do
local oc=dd(o)if oc and nz:et(oc.b)then
return oc.e
end
end
end
return nil
end
function be(ec,oc)if ec.b:et(oc.b)then
dl(ec,oc)dl(oc,ec)end
end
function dl(ec,oc)local fd,kw=
jk(ec.e,"ge",oc.e)if type(fd)=="function" then
fd(ec,oc,kw)end
end
function dd(pc)if pc.eu then
if pc.fx==iy or not pc.gk then
return pc.eu
end
end
local hb=bk(pc,"ha")
if (not hb)return nil
local li={b=hb:dz(pc.nm),e=pc
}
pc.eu,pc.fx=
li,iy
return li
end
function dq(oc,ec,ca)local e=ec.e
if (e.gq)return
local mk=ec.b:mk(oc.b,ca)
e.nm+=mk
if e.ot then
local ld=e.ot:nr(mk)if ld<0 then
if (mk.y~=0)e.ot.y=0
if (mk.x~=0)e.ot.x=0
end
if e.nc and mk.x~=0 then
e:nc()end
end
ec.b=ec.b:dz(mk)end
function di(oc,ec,f_)
return dq(ec,oc,f_)end
function cq()for e in all(bs.gl)do
local fb=e.gl
if fb then
fb=fb:dz(e.nm)local fy=gj(fb,{"walls"})e.cg=fy
end
end
end
function eh()for e in all(bs.ka)do
for mu,lq in pairs(e.ka)do
e.ka[mu]=max(lq-1,0)e[mu.."_lasts"]=lq>1
end
end
end
bg=jb:hj([[
c_=0,
]])function bg:i_()local nl=0.5
local mh=iv.lz and 10 or 20
for i=0,4,4 do
js:kn(nl)map(109,0,-2,i,19,mh)map(109,0,150,i,19,mh)
nl*=0.5
end
end
kd=jb:hj([[
c_=15,
]])me={}
for i=0,23 do
me[i]=sin(i/40)end
function kd:i_()local t=self.t*0.02
cv(2)local dy=js.p.y-gf.lm.y*8+128
memcpy(0x1000,0x6000+0x40*(72-flr(dy*0.8)),0x800)camera(0,dy)for y=0,23 do
local dx=sin(t+me[y])*(y/6)sspr(0,95-y*1.3,128,1,dx,104+y,128+y,1)end
cv()rectfill(0,103,127,103,13)end
kt=jb:hj([[
c_=2,
]])function kt:mf()ck(self)local s=self.lm
for x=-1,s.x do
for y=-1,s.y do
local oa=mget(x,y)if x<0 or y<0 or
x>=s.x or y>=s.y then
oa=103
end
local hy=jb.ia[oa]
if hy then
local op=(x+self.mw.x).."_"..(y+self.mw.y)local e=hy{nm=v(x,y)*8+(hy.eo or v0),gb=v(x,y),op=op,lp=oa
}
e.hu=e.hu or {lj={oa}}
if e.i_==nil then
e.i_=db
end
if not e.ew then
if not ii.ej[op]and not ii.ip[op]then
k_(e)end
if (not e.bl)mset(x,y,e.dw)
end
oa=0
end
local kx=df(oa)if kx then
local b=kx({nm=v(x,y)*8,gb=v(x,y),od=bt,lt=fget(oa,1)})
if (not b.ew)k_(b)
end
end
end
end
function kt:i_()map(0,0,0,0,self.lm.x,self.lm.y)end
ke=hh:hj([[
mo=o("walls"),
ha=b(0,0,8,8),
gn=0,
]])function ke:mf()local ll=ob[[v(-1,0),v(1,0),v(0,-1),v(0,1),]]
local f_={}
local hr=false
for i=1,4 do
local np=self.gb+ll[i]
local fc=df(mget(np.x,np.y))
if np.x<0 or np.y<0 or np.x>=iv.lm.x or np.y>=iv.lm.y then
fc=ke
end
f_[i]=not fc
hr=hr or f_[i]
end
self.f_=f_
self.ew=not hr
end
function ke:ge(e)
return dq,self.f_
end
function df(oa)
return fget(oa,0)and ke
end
jh=ke:hj([[
cp=o(50,51,52,53,88,90,120,121,122),
bl=1,
i_=f,
mj=o(
d50=v(-1,0),
d51=v(1,0),
d52=v(0,-1),
d53=v(0,1),
d88=v(-1,-1),
d90=v(1,-1),
d120=v(-1,1),
d121=v(0,1),
d122=v(1,1),
),
ov=o("walls"),
ha=b(0,0,7,7),
c_=7,
]])function jh:ge(o)if o:mp("nx")and o.ot:nr(jh.mj["d"..self.lp])<0 then
o:gd()else
return dq
end
end
fg=je:hj([[
nh=1,l=1,
]])eb=jb:hj([[
c_=14,
]])function eb:mf()self.ps={}
end
function eb:lj()for k,p in pairs(self.ps)do
p.p+=p.v
p.v*=p.nh
p.l-=0.016666
if (p.l<=0)self.ps[k]=nil
end
end
function eb:kg(ku)self.ps[rnd()]=fg(ku)end
function eb:i_()for _,p in pairs(self.ps)do
local nm=p.p
if p.he then
circfill(nm.x,nm.y,p.he*p.l,p.oj)end
end
end
l_=je:hj([[
hp=2,
lg=12,
fo=5,
ej=o(),
ip=o(),
]])function l_:iu()
return self.i10 and 6 or 5
end
nx=jb:hj([[
mo=o("nx"),
lc="lf",
ot=v(0,0),
nn=-1,
ig=0.3,gn=1,
ka=o(air=0),
fu=0,
hu=o(
lj=o(78),
cling=o(74),
move=o(76),
dash=o(72),
hq=o(213,offset=v(-8,-6)),
offset=v(-8,-4),
jm=2,
flips=1,
),
bv=o(0.75,0.6),
head_off=o(
v(-4,-12),
nt=v(-4,-10),
),
fa=o(
47,nt=46,hq=225,
),
ht=1,
c_=10,
br=o("walls"),
ha=o(
b(-3,-10,3,0),
ed=b(-256,-256,-257,-257),
),
ex=b(0,0,1,1),
gl=b(-2,0,2,0.1),
]])function nx:mf()self.bm=self.nm
if #cl>0 then
self.ka.float=30
end
end
function nx:hq()for i=0,5 do
if (btn(i))self:ie("lf")
end
end
function nx:lf()local fs=
not self.cg
local er=0
self.fl=not fs and (ks.p3 or (self.fl and ks.b3))
if (ks.b0 or ks.b1)and not self.fl then
local cb=self.ex:dz(self.nm+v(self.nn*4,-1))local cw=gj(cb,{"walls"})if fs and cw and not cw.lt and ii.i35 then
if not self.dt then
self.ka.grip=16
end
self.dt=cw
self.ot=v(0,self.grip_lasts and 0 or 0.125)else
self.dt=nil
end
self.fu=min(self.fu+0.2,1)
if (ks.b0)er-=1
if (ks.b1)er+=1
self.nn=er
local jn=er*self.fu*0.75
self.ot.x+=jn
else
self.fu=0
if self.dt then
local s=sgn(self.nm.x-self.dt.nm.x)self.ot.x=s
self.dt=nil
end
end
if abs(self.ot.y)>4 then
self.ot.y=sgn(self.ot.y)*4
end
if not self.dash_lasts then
self.ot.x*=1/1.5
end
if ks.p5 and ii.i111 and not (self.dt or self.fl or self.cooldown_lasts)then
local sc,sv=kp,v(self.nn*2,0)if ks.b2 then
sc,sv=it,v(0,fs and -0.1 or -2)end
if fs and ks.b3 then
sc,sv=it,v(0,1)end
k_(sc({kr=self,oq=sv:lx(),fh=sv.y>0
}))self.ka.cooldown=14
kp.gt=not kp.gt
self.ot+=sv
if fs and ii.i3 and er~=0 and sc~=it and self.dash then
self.ot=v(sgn(er)*2.25,-0.2)self.ka.dash,self.dash=5
end
end
if self.dt or not fs then
self.jy,self.ka.air,self.dash=
1,30,true
else
self.ig=max(0.3,-0.5*self.ot.y)if self.ka.air<26 and self.jy==1 then
self.jy=2
end
end
local lu=self.bv[self.jy]
if ks.p4 and lu and (ii.i19 or self.jy==1)then
if self.dt then
local s=sgn(self.nm.x-self.dt.nm.x)self.ot.x=2.25*s
end
if self.jy>1 then
k_(j_({kr=self
}))end
self.ot.y=0
self.ka.lift,self.ka.air=5,30
self.jy+=1
self.gm=lu
end
if ks.b4 then
if self.lift_lasts then
self.ot.y-=self.gm
end
if self.air_lasts then
self.ig=0.1
end
end
if self.float_lasts then
self.ig=0.1
end
if not fs and #self.ot<0.01 then
self.bm=du(self.nm)end
local ek=
ii.i7 and 25 or 40
if self.fl and ii.lg>0 and ii.hp<ii:iu()then
ii.lg-=4/ek
if iy%2==0 then
ct:kg({p=self.nm+v(rnd(8)-4,0),v=v(0,-0.5),oj=7,he=1,l=0.4+rnd(0.2)})end
if not self.focus_lasts then
self:hx(7,0.5,5)
ii.hp+=1
gh=1
self.ka.focus=ek
end
else
self.ka.focus=ek
end
ii.lg=mid(ii.lg,0,12)ii.hp=mid(ii.hp,0,ii:iu())end
function nx:nt()self.ig=0
self.ot*=0.75
end
function nx:mq(nk,jr)
if (gx)return
ii.hp-=1
self.ot=jr*5
self.ka.immune,self.fl=
ii.i11 and 100 or 60
self:hx(0,1,5)if ii.hp<=0 then
self:gd()end
jo,fv=5.5,12
end
function nx:gd()
if (gx or self.lc=="ed")return
self:ie("ed")self:mq(1,v0)end
function nx:ed(t)self.ot=v0
if t==60 and ii.hp>0 then
self.nm=self.bm
self.ot=v(0,-2)self:hx(7,0.5,5)self.ka.immune=120
self:ie("lf")end
if t==120 then
ii.hp,ii.lg,ii.ip,dj,bn=
ii:iu(),0,{},ii.da,"nt"fr(bo(v(0,1)))end
end
function nx:cz()
if (self.dt)return "cling"
local ny=abs(self.ot.x)
if (ny>2.25)return "dash"
if (ny>1)return "move"
end
function nx:i_(p)
if (self.lc=="ed")return
if (self.immune_lasts and iy%4<2)return
db(self)end
function nx:dh()for i=1,ii:iu()do
spr(i<=ii.hp and 92 or 91,i*6+11,2)end
spr(66,1,1,2,2)local sh=1+ii.lg*0.834
if sh<5 then
cv(6)end
sspr(0,45-sh,14,sh,1,14-sh)end
ks={}
function ft()for i=0,5 do
local b=btn(i)local n="b"..i
ks["p"..i]=b and not ks[n]
ks[n]=b
end
end
om=je:hj([[
cs=v(20,20),
p=v(0,0),
]])function om:mf()local ws=self.cs
self.hl=mz(-ws*0.5-v(64,64),ws*0.5-v(64,64))self.hz=mz(v0,self.kt.lm*8-v(128,128))end
function om:jp(hs)local gp,w,l=self.focus and self.focus.nm or jz.nm,self.hl,self.hz
gp=v(lb(gp.x),lb(gp.y))local fw=v(mid(self.p.x,gp.x+w.xl,gp.x+w.xr),mid(self.p.y,gp.y+w.yt,gp.y+w.yb))fw.x=mid(fw.x,l.xl,l.xr)fw.y=mid(fw.y,l.yt,l.yb)if #(fw-self.p)>4 then
self.p=mn(self.p,fw,hs or 0.25)else
self.p=fw
end
if gh>0 then
self.p+=nv(gh,iy*0.34)
gh-=0.25
end
end
function om:kn(ei)
if (not ei)ei=1
local d=self.p*ei
camera(d.x,d.y)end
em=ob([[7,7,6,13,5,]])
function ef(ou)
for i=0,13 do
local c=em[abs(i-flr(ou))+1]
palt(i,not c)
pal(i,c)
end
end
kp=jb:hj([[
gq=1,
c_=12,
ot=v(0,0),
ou=0,
hu=o(
offset=v(-8,-4),
lj=o(59),
flips=1,
jm=2,
),
gu=b(-3,-3,3,3),
br=o("ki"),
]])it=kp:hj([[
hu=o(
offset=v(-4,-8),
lj=o(45),
flips=1,
hg=2
),
]])function kp:lj(t)local a=self.oq
local kq=ii.i6 and 2 or 0
self.nn=a.x
self.nm=
self.kr.nm+
v(a.x*(12+kq),a.y*(14+kq)-4)+
self.kr.ot*2
local nu=
3-abs(self.ou-6)self.ha=self.gu:dz(a*nu*2)
self.ou+=1.5-t*0.04
self.mr=self.ou>14
end
function kp:i_(p)ef(self.gt and 13-self.ou or self.ou)db(self)end
function kp:ge(o)for h in all(self.mq)do
if (h==o)return
end
dv(self,"mq",o)mq(self.kr,o,ii.fo+(ii.i9 and 1.5 or 0),self)end
function mq(jd,ik,nk,lh)
if (ik.immune_lasts)return
local sc,tc=
dd(jd),dd(ik)local sm,tm=sc.b:hi(),tc.b:hi()local jr=(tm-sm):lx()if ik:mp("walls")then
if abs(jr.x)>abs(jr.y)then
jr=v(sgn(jr.x),0)else
jr=v(0,sgn(jr.y))end
end
if (ik.mq)ik:mq(nk,jr)
local gn=ik.gn or 0
if lh and lh.oq.y>0 then
gn,jd.ka.float=2,14
end
jd.ot=-jr*gn
end
j_=kp:hj([[
c_=9,
ou=0,
gt=f,
hu=o(
offset=v(-12,-10),
lj=o(27),
jm=3,
),
br=f,
]])function j_:lj(t)self.nm=self.kr.nm
self.mr=t>30
self.ou+=1.5-t/25
end
ij=hh:hj([[
mo=o("walls"),
cp=o(12,13,14,15),
i_=f,
p12=o(ha=b(0,0,2,8),nn=v(-1,0)),
p13=o(ha=b(6,0,8,8),nn=v(1,0)),
p14=o(ha=b(0,0,8,2),nn=v(0,-2)),
p15=o(ha=b(0,6,8,8),nn=v(0,1)),
]])function ij:mf()on(self,self["p"..self.lp])end
function ij:ge(g)if g==jz and self.nn:nr(g.ot)>0 then
dj=iv.mw*8+g.nm+self.nn*9
cl=self.nn*(self.lp==14 and 1.6 or 0.1)fr(bo(self.nn))end
end
mc=je:hj()function mc:mf()self.mi=self.mw+self.lm
end
lw.r=mc
ji=jb:hj([[
c_=10,
]])dc=ob[[
o(t="a loving homage to",y=52,c=13),
o(t="- hollow knight -",y=59,c=6),
o(t="by jakub wasilewski",y=71,c=5),
o(t="original by team cherry",y=78,c=5),
]]
function ji:mf()jo=5.9
end
function ji:dh()cls()spr(160,40,24,6,2)for t in all(dc)do
im(0.5,t.t,64,t.y,t.c)end
cv(mid(abs(iy%60/6-5)-1,0,5))im(0.5,"press [z] to start",64,100,7)if ks.p4 then
dn()end
end
function _init()extcmd("rec")bz()fv,gh,jo,iz=0,0,0,0
ii=l_()hn=v0
ch()bh()k_(ji())end
function dn()dj,cl,bn=v(892,583),v0,"hq"ii.da=v(739,589)bc()end
function bo(nn)local d=nn*16
return cocreate(function()repeat
if (iv)hn+=d
yield()if #hn==16384 then
hn=-hn
fv=16384
bc()fv=iv and 0 or 16384
end
until #hn==0
ea=nil
end)end
function bc()local ts=
dj/8
iv=nil
for r in all(pd)do
if mid(r.mw.x,r.mi.x,ts.x)==ts.x
and mid(r.mw.y,r.mi.y,ts.y)==ts.y then
iv=r
end
end
if not iv then
_init()
return
end
ch()bh()k_(bg())if iv.w then
k_(kd())end
ct=k_(eb())gf=k_(kt(iv))jz=k_(nx({nm=dj-iv.mw*8,ot=cl,lc=bn,nn=sgn(cl.x)}))js=om({nx=jz,kt=gf
})js:jp(1)dj,bn=nil
end
iy=0
function _update60()ft()if ea and costatus(ea)then
assert(coresume(ea))end
if fv==0 then
local tu=stat(1)cc()dk=stat(1)-tu
cj()local tc=stat(1)bw()cr=stat(1)-tc
cq()eh()else
fv-=1
end
bu()
iy+=1
end
function _draw()if ga then
ga:dh()
return
end
if #hn>0 then
cls(0)clip(hn.x,hn.y,128,128)rectfill(0,0,127,127,1)else
cls(1)end
if iz>0 then
cv(10+iz,0x5f10)else
cv(jo,0x5f10)end
if (js)js:jp()
ci("i_")camera()ci("dh")jo=max(jo-0.25,0)iz=max(iz-0.25,0)end
ki=jb:hj[[
mo=o("ki"),
c_=10,
ot=v(0,0),nh=0.9,
ka=o(),
nw=10,
en=1,
jj=9,gg=5,
ey=20,
ep=25,
cn=0.987,cm=1,
br=o("walls","nx"),
]]
function ki:lj(t)self.nw=max(10,self.nw-0.15)if self.lc=="lj" and not self.stun_lasts and not (self.gl and not self.cg)then
if co(self)then
self.ka.aggro=self.ep
end
self:ai(t)end
if self.fw then
self.ot=mn(self.ot,self.fw,0.1)end
self.ot*=self.nh
if self.kc then
local mg=(self.nm+v(self.kc.x*self.nn,self.kc.y))/8
self.bq=not df(mget(mg.x,mg.y))if self.bq and self.en then
self:nc()end
end
end
function ki:ju()self.ka.aggro,self.fw=0
self:ie("lj")end
function ki:nc()
if (not self.cg)return
self.nn*=-1
if (self.d_)self.ot=v0
self.bq=false
self:ju()end
function ki:na(lk,ot)if iy%lk==0 then
if (self.bq)self:nc()
self.ot=v(self.nn*ot,0)end
end
function ki:kl(v,kk,ih)for i=-kk,kk do
local ot=v+v:n_()*i*ih
k_(de({nm=self.nm+self.cf,ot=ot,sp=i~=0 and 195
}))end
end
function ki:mq(nk,jr)fv,gh=4,1.5
ii.lg+=(ii.i8 and 1 or 0.667)
self.hp-=nk
if self.hp<=0 then
self:hx(self.jj,self.gi,self.gg,1)self.mr=true
if (self.op)ii.ip[self.op]=true
else
self:hx(self.jj,0.2,3)end
self.ka.stun,self.ka.aggro=
self.ey,0
self.fw=v0
if self.nn then
self.nn=sgn(jz.nm.x-self.nm.x)end
self.nw=15.9
self.ot+=jr/self.gn
end
function ki:ge(o)
if (o==jz)mq(self,o)
end
oz=ki:hj[[
cp=o(71),
hp=7,
fw=v(0,0),
gn=0.25,
gi=0.56,
cm=1.8,
cn=0,
dp=1,
hu=o(
lj=o(70,68,jq=3),
jm=2,
offset=v(-8,-6),
flips=1,
),
ha=b(-4,-5,4,0),
]]
function oz:ai(t)if t%60==0 or #self.fw==0 then
local iw=self.aggro_lasts and rnd()<0.5
if iw then
self.fw=self.jt:lx()*1.6
else
self.fw=nv(0.6,rnd())end
end
end
pf=oz:hj[[
cp=o(192),
gn=0.75,
cf=v(0,0),
gi=0.7,
hu=o(
lj=o(192),
recoil=o(208),
offset=v(-4,-4),
),
hp=20,
fi=o(
o(
o(193,v(3,-4)),
o(193,v(-10,-4),1),
),
o(
o(193,v(3,-7),f,1),
o(193,v(-10,-7),1,1),
),
),
ha=b(-4,-4,4,4),
nn=1,jg=0,
]]
function pf:ai(t)if rnd()<(t-self.jg)*0.0005 then
self.nn=-self.nn
self.jg=t+45
if rnd()<0.5 then
local d=self.jt.x*0.83
if abs(d)>1 then
d=sgn(d)end
self:kl(v(d,0.1),0,0
)
self.ot-=v(0,3)
self.ka.recoil=15
end
end
local d=v(self.nn*16,jz.nm.y-42-self.nm.y)self.fw=d:lx()end
function pf:cz()
return self.recoil_lasts and "recoil"end
function pf:i_(p)local ou=flr(self.t%4/2)+1
self:fq(self.fi[ou])db(self)end
de=jb:hj([[
gq=1,
c_=12,
ig=0.075,
hu=o(
lj=o(194),
offset=v(-4,-4),
),
ha=b(-2,-2,2,2),
br=o("nx","walls"),
]])function de:ge(o)self.mr=true
self.nm+=self.ot
self:hx(9,0.4,5)mq(self,o)end
mt=ki:hj[[
cp=o(207),
ot=v(0,0),
hp=13,
ig=0.5,
gn=0.425,nh=0.9,
en=f,
nn=1,
jj=3,gi=0.64,gg=2,
hu=o(
lj=o(207),
offset=v(-4,-4),
flips=1,
),
ha=b(-4,-4,4,2),
gl=b(-4,2,4,3),
kc=v(8,8.5),
]]
function mt:i_(p)local ot=self.ot.x
local d=v(-self.nn*0.5-ot*1.5,0)p=p:lb()local p1,p2=p+d,p+d*3
cv(self.nw)spr(205,p2.x-4,p2.y-4,1,1,ot<0)spr(206,p1.x-4,p1.y-4,1,1,ot<0)db(self)end
function mt:ai(t)if self.aggro_lasts then
self:na(1,0.8+sin(iy*0.06)*0.4)else
self:na(60,0.8)end
end
ir=jb:hj[[
c_=10,
cp=o(108),
dw=124,
]]
function ir:lj()if jz.nm.y>self.nm.y and abs(jz.nm.x-self.nm.x-4)<12 then
k_(mt{nm=self.nm+v(0,4),nn=-jz.nn})self.mr=true
end
end
g_=ki:hj[[
cp=o(204),
ig=0.3,
hp=7,gn=2,
gi=0.6,
ey=0,
d_=1,
en=f,
nn=1,
hu=o(
lj=o(203),
offset=v(-8,-8),
jm=2,
flips=1,
),
ha=b(-4,-8,4,-1),
gl=b(-4,-1,4,0),
kc=v(10,0),
]]
function g_:ai(t)self:na(30,0.5)end
h_=ki:hj[[
cp=o(210),
hp=30,ig=0.3,
ey=3,
ep=60,cm=1.6,
dp=1,
cf=v(0,-12),
gn=1,
gi=0.83,
nn=1,nh=0.9,
hu=o(
lj=o(224),
dash=o(226),
jm=2,hg=2,
offset=v(-8,-16),
flips=1,
),
head_off=v(-4,-16),
ht=1.5,
fa=o(
210,mb=209,
),
ha=b(-6,-16,6,0),
gl=b(-6,0,6,1),
kc=v(12,1),
]]
function h_:dash(t)self.fw=v(self.nn*2-t*0.03,0)self:lj(t)
if (t>30)self:ju()
end
function h_:mb(t)self:lj(t)if t==0 then
self.ot=v(-self.nn*0.5,-2)elseif t==40 then
self:kl(v(self.nn,rnd(0.5)-1.35)*0.87,1,0.5)elseif t>80 then
self:ju()end
end
function h_:ai(t)if self.aggro_lasts then
local mb=
rnd()>((jz.cg and self.la>0.99)and 0.75 or 0.05)self.nn=sgn(self.jt.x)self:ie(mb and "mb" or "dash")else
self:na(30,0.5)end
end
fz=ki:hj[[
cp=o(248),
hp=25,ig=0.3,
ey=3,
ep=60,cm=2.1,
dp=1,cn=0.2,
hm=1,
gn=1,
gi=0.83,
nn=1,nh=0.9,
hu=o(
lj=o(230),
jm=2,hg=2,
offset=v(-8,-16),
flips=1,
),
head_off=v(-4,-14),
ht=1.5,
fa=248,
ha=b(-6,-16,6,0),
gl=b(-6,0,6,1),
kc=v(12,1),
]]
function fz:mf()if self.op and ii.ip[self.op]then
return
end
self.mm=k_(self.jf{kr=self,nm=self.nm
})end
function fz:ky(t)self:lj(t)
if (t<10)self.mm.ot*=0.6
if (abs(t-10)<2)self.mm.ot=-self.oq
if (abs(t-22)<8)self.mm.ot=self.oq*3
if (t==15)self.ot+=v(self.oq.x*1.5,self.oq.y*3)
if (t>60)self:ju()
end
function fz:ai()if self.aggro_lasts and self.jt.y<0.16 then
local d=self.jt
self.nn=sgn(d.x)if #d<self.hm then
self.oq=self:ff(d)self:ie("ky")self.t=-rnd(10)else
self:na(15,1)end
else
self:na(60,1)end
end
function fz:ff(d)
return d:lx()*0.85-v(0,0.1)end
mm=jb:hj[[
c_=11,
ot=v(0,0),ig=0,
hu=o(
lj=o(211),
offset=v(-4,-4),
),
ha=b(-3,-3,3,3),
br=o("nx"),
io=0.04,le=0.01,ms=0.91,lo=4,
]]
function mm:lj()local kr=self.kr
if kr then
if kr.mr then
self.mr=true
else
self.nn=kr.nn
local d=kr.nm-v(kr.nn*self.lo,4)-self.nm
self.ot+=d*self.io+d:n_()*self.le
self.d=d
end
end
self.ot*=self.ms
end
function mm:i_()for i=0.25,0.75,0.25 do
local p=self.nm+(self.d or v0)*i-v(4,4)spr(212,p.x,p.y)end
db(self)end
function mm:ge(g)mq(self,g)end
nd=fz:hj[[
cp=o(172),
hp=30,
jj=3,
gn=1,
hm=0.6,
hu=o(
lj=o(172),
dash=o(174),
jm=2,hg=2,
offset=v(-8,-16),
flips=1,
),
cn=0.7,cm=1.8,
fa=f,
]]
function nd:cz()
if (self.lc=="ky" and abs(self.ot.x)>0.3)return "dash"
end
function nd:ky(t)self:lj(t)
if (t==30)self.ot=self.oq*(1.5+rnd())
if (abs(t-35)<5)self.mm.ot=self.oq*3
if (t>60)self:ju()
end
function nd:ff(d)
return v(sgn(d.x),0)end
km=mm:hj[[
hu=o(
lj=o(187),
ky=o(187),
offset=v(-4,-4),
flips=1,
),
io=0.12,le=0.0,ms=0.7,
lo=1,
]]
km.i_=db
fz.jf,nd.jf=
mm,km
function co(e)local w=e.nn or 1
local d=(jz.nm-e.nm)/48
e.la=d:lx().x*w
e.jt=d
if (e.dp)e.la=abs(e.la)
return e.la>e.cn and #d<e.cm
end
el=jb:hj[[
mo=o("el"),
cp=o(66),
lb=1,
i_=f,
83_18=o(
o(o(
t=64,p=v(0,0),
s=o(
m_="you've come far/ little bug.",
),
)),
o(o(
t=64,p=v(0,0),
s=o(
m_="now/ prove yourself.",
),
)),
o(
o(t=71,p=v(16,-35)),
o(t=71,p=v(-16,-35)),
o(t=71,p=v(32,-48)),
o(t=71,p=v(-32,-48)),
o(t=71,p=v(0,-38)),
o(t=172,p=v(40,16),s=o(hp=40)),
o(t=172,p=v(-40,16),s=o(hp=40)),
),
o(),o(),
o(
o(t=210,p=v(40,-16),s=o(hp=50)),
o(t=210,p=v(-40,-16),s=o(hp=50)),
o(t=204,p=v(-24,16)),
o(t=204,p=v(40,16)),
o(t=71,p=v(56,-8)),
o(t=71,p=v(-56,-8)),
),
o(),o(),
o(
o(t=248,p=v(40,-16),s=o(hp=50)),
o(t=248,p=v(-40,-16),s=o(hp=50)),
o(t=192,p=v(-40,-32)),
o(t=192,p=v(40,-32)),
),
o(),
o(o(
t=64,p=v(0,0),
s=o(
m_="go/ vessel.",
),
)),
o(o(
t=64,p=v(0,0),
s=o(
m_="claim your destiny.",
),
)),
),
100_32=o(
o(
o(t=210,p=v(-48,0),s=o(hp=40)),
o(t=248,p=v(24,0),s=o(hp=40)),
),
o(
o(t=35,p=v(-16,0)),
),
),
15_86=o(
o(
o(t=172,p=v(-32,-16)),
),
o(
o(t=172,p=v(40,-16)),
o(t=172,p=v(-32,-16)),
),
),
106_68=o(
o(o(
t=64,p=v(0,0),
s=o(
m_="wake up/ little bug.",
oj=7,
ny=2.5,id=1.75,
),
)),
),
]]
function el:lj()if self.nz:fj(jz.nm)then
js.focus=self
self:ie("kg")end
end
function el:kg(t)if t==60 then
local ia=el[self.op][self.lb]
if not ia then
ii.ej[self.op]=true
self.mr,js.focus=
true,nil
end
self.lb+=1
self.gz={}
for s in all(ia)do
kf=jb.ia[s.t]
local e=k_(kf(on({nm=self.nm+s.p,ot=kf.ig and v(0,-1),lp=s.t
},s.s or {})))if not e.hu then
e.hu={lj={s.t}}
end
add(self.gz,e)e:hx(7,1,3)end
self:ie("hv")end
end
function el:hv()for t in all(self.gz)do
if (not t.mr)return
end
self:ie("kg")end
fp=jb:hj[[
cp=o(83),
i_=f,
]]
function fp:mf()
if (not bd.el)return
local bf=bd.el[1]
bf.nz=
mz(bf.nm,self.nm+v(9,9))bf.nm=bf.nz:hi()end
fm=jb:hj[[
mo=o("walls"),
cp=o(2,18),
c_=1,
hu=o(
lj=o(2),
hg=2,
),
lt=1,
ha=b(0,0,8,16),
]]
fm.ge=ke.ge
function fm:mf()self.bp=self.nm-v(0,15)self.nm=self.bp
self.ln=self.lp==2 and 0 or 16.5
end
function fm:lj()if js.focus and self.ln<15 then
self.ln+=1.5
if (self.ln==15)gh=2
end
if not js.focus and self.ln>0 then
self.ln-=0.5
end
self.nm=self.bp+v(0,self.ln)end
pd=ob([[
r(o(ix=0,hk=0,mw=v(84,64),w=1,lm=v(20,16),)),
r(o(ix=33,hk=1,mw=v(56,64),w=1,lm=v(28,16),)),
r(o(ix=44,hk=3,mw=v(0,58),w=1,lm=v(16,22),)),
r(o(ix=20,hk=6,mw=v(0,42),lm=v(16,16),)),
r(o(ix=88,hk=7,mw=v(36,56),w=1,lm=v(20,24),)),
r(o(ix=15,hk=11,mw=v(16,42),lm=v(20,22),)),
r(o(ix=71,hk=13,mw=v(16,64),lm=v(20,16),)),
r(o(ix=86,hk=15,mw=v(36,36),lm=v(20,20),)),
r(o(ix=85,hk=17,mw=v(56,46),lm=v(48,18),)),
r(o(ix=89,hk=22,mw=v(104,64),w=1,lm=v(16,16),)),
r(o(ix=72,hk=23,mw=v(104,47),lm=v(16,16),)),
r(o(ix=98,hk=23,mw=v(82,30),lm=v(29,16),)),
r(o(ix=70,hk=25,mw=v(56,28),lz=1,lm=v(26,18),)),
r(o(ix=64,hk=27,mw=v(11,80),lm=v(23,16),)),
r(o(ix=34,hk=30,mw=v(0,26),lm=v(16,16),)),
r(o(ix=101,hk=30,mw=v(36,15),lz=1,lm=v(20,21),)),
r(o(ix=12,hk=33,mw=v(56,12),lz=1,lm=v(26,16),)),
r(o(ix=23,hk=35,mw=v(67,6),lm=v(0,0),)),
r(o(ix=24,hk=35,mw=v(82,12),lz=1,lm=v(16,16),)),
]])function e_(ox,oy)local mx,my = ox,oy
return function()local v=mget(mx,my)
mx+=1
if (mx==104)mx,my=0,my+1
return v
end
end
function ck(r)local w,h=r.lm.x,r.lm.y
reload(0x2000,0x2000,0x1000)local kv=e_(r.ix,r.hk)local md=0x4300
local kb=md+w*h
while md < kb do
local ja=kv()if ja > 128 then
local ok,pb=kv(),ja-128
memset(md,ok,pb)
md+=pb
else
for i=1,ja do
poke(md,kv())
md+=1
end
end
end
for l=0,h-1 do
memcpy(0x2000+l*128,0x4300+l*w,w)end
end
ly=jb:hj[[
c_=11,
cp=o(3,19,35,4,5,6,7,8,9,10,11),
eo=v(4,12),
nw=10,ou=0,
ha=o(
b(0,0,8,4),
ej=b(-256,-256,-257,-257),
),
br=o("nx"),
]]
nail=ly:hj[[
cp=o(111),
eo=v(4,20),
hu=o(
lj=o(95),
offset=v(0,-8),
hg=2,
),
]]
kh=ob[[
i6=o(
n="longnail charm",
d=o(
"your nail reaches farther.",
),
),
i7=o(
n="stoutscale charm",
d=o(
"you heal faster.",
),
),
i8=o(
n="soulseek charm",
d=o(
"you gain soul faster.",
),
),
i9=o(
n="goldnail charm",
d=o(
"you hit harder.",
),
),
i10=o(
n="bloodbloom charm",
d=o(
"you have more life.",
),
),
i11=o(
n="ghostshell charm",
d=o(
"you are immune for longer",
"when you get hit.",
),
),
i111=o(
n="discarded nail",
d=o(
"",
"[z] to jump",
"[x] to strike",
"[down] to heal",
"[up] to sit on benches",
),
),
i3=o(
n="windgust",
d=o(
"press left/right+[x]",
"while airborne",
"to dash sideways.",
),
),
i19=o(
n="soulwings",
d=o(
"jump again by pressing",
"[z] while airborne",
),
),
i35=o(
n="heart of rock",
d=o(
"climb vertical walls",
"by jumping onto them",
),
),
nail_st=o(
)
]]
function ly:lj()self.nw=max(self.nw-0.15,10)if iy%100==0 then
self.nw=15.9
self.ou=0
end
end
function ly:ej(t)iz=min(iz+0.5,5)jz.ot=v(0,0)if t>25 then
ga=self
self.nw,self.nm=
10,v(60,32)self:ie("showcase")end
end
function ly:i_(p)if self.lc=="ej" then
circfill(p.x,p.y,self.t*5,7)else
db(self)
self.ou+=1-self.ou*0.04
ef(self.ou)spr(41,p.x-4,p.y-4,2,2)end
end
function ly:dh()if self.lc=="showcase" then
fv=1
self.t+=1
self.ol=self.ol or ks.p4
if self.ol then
jo+=0.25
if jo>=5.75 then
self.mr,iz,ga=
true,0
end
end
cls(0)cv(jo,0x5f10)local t=self.t
local th=mid(0,1,1-t/60)local d=th^3*128
db(self)ee(self.lp,v(64,48),d)local t,b=80-d,48+d
if t<b then
rectfill(0,t,127,b,7)end
end
end
function ly:ge(g)if g==jz then
self:ie("ej")ii["i"..self.lp]=true
if self.op then
ii.ej[self.op]=true
end
end
end
gs=jb:hj[[
cp=o(49),
eo=v(-1,4),
dw=49,
ha=b(-2,-2,2,4),
br=o("nx"),
nb=o(
m_="nail strengthened",
oj=12,
ny=2,id=0,
),
]]
function gs:lj()if rnd()<0.2 then
ct:kg({p=self.nm+v(rnd(4)-2,0),oj=rnd()<0.5 and 7 or 12,v=v(0,-0.3),nh=0.97,he=1,l=rnd(0.5)+0.5,})end
end
function gs:ge()self:hx(12,0.6,5,2)self.mr=true
iz=5.5
ii.fo+=0.5
ii.ej[self.op]=true
k_(hd(du(self.nb)))end
kz=jb:hj[[
cp=o(33),
dw=33,
nz=b(-4,0,12,8),
c_=15,
kj=0,sel=0,
cursor=o(
o(108,v(-3,-33)),
),
i_=f,
]]
function kz:lj()if ks.p2 and jz.lc~="nt" and gj(self.nz:dz(self.nm),{"nx"})then
ii.da=gf.mw*8+jz.nm-v(0,3)jz:ie("nt")jz.ot=v(0,-1)ii.hp=ii:iu()ii.ip={}
jz:hx(7,0.5,2)elseif jz.lc=="nt" then
for i=0,5 do
if ks["p"..i]then
jz:ie("lf")end
end
end
end
dg=ob[[6,7,8,9,10,11,]]
function kz:i_()
if jz.lc=="nt" then
for a,c in pairs(dg)do
local p=jz.nm-
v(4,8)+
nv(min(19,sqrt(jz.t*30)),
0.071*a)
spr(ii["i"..c]and c or 5,p.x,p.y)
end
end
end
function ee(no,p,d)
local m_=kh["i"..no]
im(0.5,m_.n,p.x+d,p.y,9)
for i=1,#m_.d do
im(0.5,m_.d[i],p.x-d,p.y+2+i*7,13)
end
end
hd=jb:hj[[
cp=o(64),
c_=15,
oj=7,id=1.5,
ny=2.5,
td=o(),
]]
function hd:mf()self.nm,self.c=
v(64-#self.m_*2,32),20+self.ny*#self.m_
local d=0
for i=1,#self.m_ do
self.td[i]={o=rnd(),d=d
}
d+=self.ny*(sub(self.m_,i,i)=="/" and 4 or 1)
end
end
function hd:dh(p)local t=self.t
self.mr=t>self.c*3
local d=dm(t,self.c,self.c-15,15)if d>0 then
rectfill(0,p.y+d,127,p.y+4*d,0)end
for i=1,#self.m_ do
local td=self.td[i]
local d=1-dm(t,self.c+td.d,self.c-6,6)if d<1 then
local c=sub(self.m_,i,i)print(c=="/" and "," or c,p.x+i*4-4,p.y-d*6+
self.id*sin(t*0.01+td.o),self.oj
)end
end
end
function dm(t,c,wc,wt)local ni=abs(t-c)
return min(1-(ni-wc)/wt,1)end