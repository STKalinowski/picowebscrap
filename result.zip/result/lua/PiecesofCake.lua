-- pieces of cake
--  by @krajzeg
cartdata("kzgpckv2")goto donewithintro
daynumber="10"::_::
if (btnp()>0)goto donewithintro
cls()f=4-abs(t()-4)for z=-3,3 do
for x=-1,1 do
for y=-1,1 do
b=mid(f-rnd(.5),0,1)b=3*b*b-2*b*b*b
a=atan2(x,y)-.25
c=8+(a*8)%8
if (x==0 and y==0)c=7
u=64.5+(x*13)+z
v=64.5+(y*13)+z
w=8.5*b-abs(x)*5
h=8.5*b-abs(y)*5
if (w>.5)rectfill(u-w,v-h,u+w,v+h,c)rect(u-w,v-h,u+w,v+h,c-1)
end
end
end
if rnd()<f-.5 then
?daynumber,69-#daynumber*2,65,2
end
if f>=1 then
for j=0,1 do
for i=1,f*50-50 do
x=cos(i/50)y=sin(i/25)-abs(x)*(.5+sin(t()))circfill(65+x*8,48+y*3-j,1,2+j*6)end
end
for i=1,20 do
?sub("pico-8 advent calendar",i),17+i*4,90,mid(-1-i/20+f,0,1)*7
end
end
if (t()==8)goto donewithintro
flip()goto _
::donewithintro::
function index_add(idx,prop,elem)idx[prop]=idx[prop]or {}
add(idx[prop],elem)end
function event(e,evt,...)local fn=e and e[evt]
if type(fn)=="function" then
return fn(e,...)end
return fn
end
function set(o,props)for k,v in pairs(props or {})do
o[k]=v
end
return o
end
function clone(o)
return set({},o)end
function merge(t1,t2)
return set(clone(t1),t2)end
function printa(t,x,y,c,a)printt(printa_pat,t,x,y,{c},a)end
function printsh(t,x,y,c,a)printt(printsh_pat,t,x,y,{c,0},a)end
function printdsh(t,x,y,c1,c2,a)printt(printdsh_pat,t,x,y,{c1,c2,0},a)end
function printt(pat,t,x,y,cs,a)
if (a)x-=a*4*#tostr(t)
for d in all(pat)do
print(t,x+d.x,y+d.y,cs[d.c])end
end
function lerp(a,b,t)
return a+(b-a)*t
end
function rndf(l,h)
return l+rnd(h-l)end
function rndi(l,h)
return flr(rndf(l,h+1))end
function round(x)
return flr(x+0.5)end
function cutebox(x1,y1,x2,y2,cbg,chl,cbr)shadow(x1,y2+2,x2,y2+2,2)shadow(x2+1,y2+1,x2+1,y2+1,2)set_palette()rect(x1,y1-1,x2,y2+1,cbr)rect(x1-1,y1,x2+1,y2)rectfill(x1,y1,x2,y2,cbg)rectfill(x1,y1,x2,y1+(y2-y1)/3,chl)end
function filter(seq,pred)local f={}
for e in all(seq)do
if (pred(e))add(f,e)
end
return f
end
function index_of(seq,target)for i,e in pairs(seq or {})do
if (e==target)return i
end
end
function concat(a,b)local t={}
local append=function(e)add(t,e)end
foreach(a,append)foreach(b,append)
return t
end
function min_by(seq,key)local mk,me=32767
for e in all(seq)do
local k=key(e)
if (k<mk)mk,me=k,e
end
return me,mk
end
function sort_by(seq,key)for limit=#seq-1,1,-1 do
for i=1,limit do
local a,b=seq[i],seq[i+1]
if key(b)<key(a)then
seq[i],seq[i+1]=b,a
end
end
end
return seq
end
function call(fn,a)
return fn
and fn(a[1],a[2],a[3],a[4],a[5])or a
end
function ob(str,props)local result,s,n,inpar=
{},1,1,0
each_char(str,function(c,i)local sc,nxt=sub(str,s,s),i+1
if c=="(" then
inpar+=1
elseif c==")" then
inpar-=1
elseif inpar==0 then
if c=="=" then
n,s=sub(str,s,i-1),nxt
elseif c=="," and s<i then
result[n]=sc=='"'and sub(str,s+1,i-2)or sub(str,s+1,s+1)=="("and call(obfn[sc],ob(sub(str,s+2,i-2)..","))or sc!="f"and band(sub(str,s,i-1)+0,0xffff.fffe)s=nxt
if (type(n)=="number")n+=1
elseif sc!='"'and c==" " or c=="\n" then
s=nxt
end
end
end)
return set(result,props)end
function each_char(str,fn)local rs={}
for i=1,#str do
add(rs,fn(sub(str,i,i),i)or nil)end
return rs
end
object={}
function object:extend(kob)kob=ob(kob or "")kob.extends,kob.meta,object[kob.classname or ""]=
self,{__index=kob},kob
return setmetatable(kob,{__index=self,__call=function(self,ob)ob=setmetatable(clone(ob),kob.meta)local ko,init_fn=kob
while ko do
if ko.init and ko.init~=init_fn then
init_fn=ko.init
init_fn(ob)end
ko=ko.extends
end
return ob
end
})end
vector={}
vector.__index=vector
function vector:__add(b)
return v(self.x+b.x,self.y+b.y)end
function vector:__sub(b)
return v(self.x-b.x,self.y-b.y)end
function vector:__mul(m)
return v(self.x*m,self.y*m)end
function vector:__div(d)
return v(self.x/d,self.y/d)end
function vector:__unm()
return v(-self.x,-self.y)end
function vector:dot(v2)
return self.x*v2.x+self.y*v2.y
end
function vector:norm()
return self/self:len()end
function vector:rotr()
return v(-self.y,self.x)end
function vector:__len()
return self:dot(self)end
function vector:len()
return sqrt(#self)end
function vector:str()
return self.x..","..self.y
end
function v(x,y)
return setmetatable({x=x,y=y
},vector)end
function mav(magnitude,angle)
return v(cos(angle),sin(angle))*magnitude
end
obfn={v=v,ln=line,rf=rectfill}
dirs=ob[[
v(-1,0),v(1,0),v(0,-1),v(0,1),
]]
inverse=ob[[2,1,4,3,]]
randomizer=object:extend[[
ctr=0,looseness=0.25,
no_repeats=f,
forced=o(),
]]
function randomizer:init()if self.range then
self.es={}
for i=self.range[1],self.range[2]do
add(self.es,i)end
end
self.last={}
for i,p in pairs(self.es)do
self.last[i]=-1
end
end
function randomizer:next(exclude)if #self.forced>0 then
local v=self.forced[1]
del(self.forced,v)
return v
end
while true do
local i=rndi(1,#self.es)local prob=self.ctr-self.last[i]
if rnd()<prob then
local e=self.es[i]
if e~=exclude then
self.last[i]=self.ctr-(self.no_repeats and self.looseness or 0)
self.ctr+=self.looseness
return e
end
end
end
end
function randomizer:force(values)self.forced=values
end
function force(obj,random_map)for k,f in pairs(random_map)do
obj[k.."rnd"]:force(f)end
end
function init_palettes()local a=0x5000
for p=0,31 do
for c=0,15 do
poke(a,bor(sget(p,c),c==13 and 0x80))
a+=1
end
end
end
function set_palette(no)memcpy(0x5f00,0x5000+shl(flr(no),4),16)end
printa_pat=ob[[
o(x=0,y=0,c=1),
]]
printsh_pat=ob([[
o(x=-1,y=-1,c=2),
o(x=0,y=-1,c=2),
o(x=1,y=-1,c=2),
o(x=-1,y=0,c=2),
o(x=1,y=0,c=2),
o(x=-1,y=1,c=2),
o(x=0,y=1,c=2),
o(x=1,y=1,c=2),
o(x=0,y=0,c=1),
]])printdsh_pat=ob([[
o(x=0,y=2,c=3),
o(x=-1,y=2,c=3),
o(x=-1,y=1,c=3),
o(x=-1,y=0,c=3),
o(x=-1,y=-1,c=3),
o(x=0,y=-1,c=3),
o(x=1,y=-1,c=3),
o(x=1,y=0,c=3),
o(x=1,y=1,c=3),
o(x=1,y=2,c=3),
o(x=0,y=1,c=2),
o(x=0,y=0,c=1),
]])function e_reset()entities,entities_with,entities_tagged={},{},{}
end
function e_add(e)add(entities,e)for p in all(indexed_properties)do
if (e[p])index_add(entities_with,p,e)
end
for t in all(e.tags)do
index_add(entities_tagged,t,e)end
return e
end
function e_remove(e)if e.children then
foreach(e.children,e_remove)end
if e.parent then
del(e.parent.children,e)end
del(entities,e)for p in all(indexed_properties)do
if (e[p])del(entities_with[p],e)
end
for t in all(e.tags)do
del(entities_tagged[t],e)end
end
indexed_properties=ob([[
"r1","r2","r3","r4","r5","r6","r7","r8","r9",
"layout","sz",
]])function e_update_all()for _,ent in pairs(entities)do
local fn=ent[ent.state]
if fn then
fn(ent,ent.t)end
if ent.done then
e_remove(ent)end
ent.t+=1
end
end
entity=object:extend([[
state="idle",t=0,
draw_order=5,
llerp=0.15,
]])entity.init=e_add
function entity:become(state)self.state,self.t=state,0
end
function entity:is_a(tag)
return index_of(self.tags,tag)end
function r_render_all()for z=1,9 do
local prop="r"..z
local ord,mn,mx={},127,0
for _,ent in pairs(entities_with[prop]or {})do
local order=ent.pos and flr(ent.pos.y)or 0
if (ent.pop)order=0
index_add(ord,order,ent)
if (order<mn)mn=order
if (order>mx)mx=order
end
for o=mx,mn,-1 do
for ent in all(ord[o])do
ent[prop](ent,ent.pos)set_palette()end
end
end
end
g_inp=ob[[
mpos=v(64,64),
proceed_keys=o(
"b0press","b1press","b2press","b3press","b4press","b5press",
"mb0press",
),
]]
function i_init_input()poke(0x5f2d,1)i_update_input()end
function i_update_input()for b=0,5 do
i_update_button("b"..b,btn(b))end
if g_inp.mb0rel then
g_inp.mpos=v(127,0)end
for mb=0,2 do
i_update_button("mb"..mb,band(stat(34),shl(1,mb))~=0)end
if (not g_inp.touch)or g_inp.mb0 then
local mpos=v(stat(32),stat(33))g_inp.mmove=#(g_inp.mpos-mpos)>0
g_inp.mpos=mpos
end
g_inp.proceed=false
for k in all(g_inp.proceed_keys)do
if g_inp[k]then
g_inp.proceed=true
end
end
if peek(0x5f80)>0 then
g_inp.touch=true
pointer.mode="mouse"end
end
function i_update_button(nm,current)local prev=g_inp[nm]
g_inp[nm]=current
g_inp[nm.."press"]=current and not prev
g_inp[nm.."rel"]=prev and not current
end
function l_do_layouts()for e in all(entities_with.layout)do
for i,c in pairs(e.children or {})do
e:layout(c,i)end
end
end
function l_apply(e)local lpos=e.lpos or e.pos
e.pos=#(e.pos-lpos)<0.25 and lpos+v(0,0)or lerp(e.pos,lpos,e.llerp)end
function draw_from_template(tpl,trans)for e in all(tpl)do
call(obfn[e.fn],e)end
end
function shadow(x1,y1,x2,y2,plt)if x2-x1>63 then
shadow(x1,y1,x1+63,y2,plt)shadow(x1+64,y1,x2,y2,plt)
return
end
x1,x2,y1,y2=
round(x1),round(x2),round(y1),round(y2)local al,ar=0,0
if x1%2==1 then
x1-=1
al=1
end
if x2%2==0 then
x2+=1
ar=1
end
local memw=(x2-x1+1)/2
local saddr=0x6000+shl(y1,6)+x1/2
local daddr=0x1800
for y=y1,y2 do
memcpy(daddr,saddr,memw)
saddr+=64
daddr+=64
end
set_palette(plt)palt(13,false)local w,h=x2-x1+1-al-ar,y2-y1+1
sspr(al,96,w,h,x1+al,y1)set_palette()end
obfn.sh=shadow
function move(child,parent)local prev=child.parent
if (prev)del(prev.children,child)
if (parent)index_add(parent,"children",child)
child.parent=parent
child.moved_on=g_move_ctr
g_move_ctr+=0x0.001
end
function is_empty(parent)
return #(parent.children or {})==0
end
bg=entity:extend()function bg:r1()palt(13,false)map(0,0,-4,-5,17,17)for y=0,8 do
set_palette((y+8)/4)palt(13,false)sspr(0,88+y*2%8,104,1,12+y,99+y,104-y*2,1)end
rectfill(21,108,106,108,0)set_palette()spr(100,28,109,2,1)spr(116,82,109,2,1)end
pointer=entity:extend[[
pos=v(64,64),
script=o(),
delay=15,
mode="keys",pmode="keys",
]]
function pointer:idle()if not self:in_script()then
if g_inp.mmove then
self.mode,self.pos,self.lpos=
"mouse",g_inp.mpos,g_inp.mpos
end
for b=0,5 do
if g_inp["b"..b.."press"]then
self.mode="keys"end
end
elseif self.mode~="script" then
self.pmode,self.mode=
self.mode,"script"end
local mode=self.mode
if self.options then
if mode=="script" then
self:script_control()elseif mode=="mouse" then
self:mouse_control()elseif mode=="keys" then
self:key_control()end
l_apply(self)end
end
function pointer:in_script()
return #self.script>0
end
function pointer:script_control()if self.prompt then
self.delay=25
if g_inp.proceed then
self.prompt:dismiss()self.prompt=nil
end
end
if self.delay>0 then
self.delay-=1
else
local op=self:s_pop()
if (op)self:s_op(op)
return
end
end
function pointer:key_control()if #self.script==0 then
for d=1,4 do
if g_inp["b"..(d-1).."press"]then
self:move(d)sfx(2)end
end
if g_inp.b5press and self.cancellable then
self:select(nil)self:confirm()elseif g_inp.b4press then
self:confirm()end
end
end
function pointer:mouse_control()self.hovered=nil
local mpos=g_inp.mpos
local h=min_by(self.options,function(e)
return #(mpos-e.pos-e.sz*0.5)end)local d=mpos-h.pos
local close=d.x>=-5 and d.x<h.sz.x+5 and d.y>=-5 and d.y<h.sz.y+5
self.hovered=close and h
if self.hovered~=self.tgt then
self:select(self.hovered)end
local want_confirm=
(self.interaction=="click" and g_inp.mb0press)or
(self.interaction=="drag" and g_inp.mb0rel)if want_confirm then
self:confirm()end
end
function pointer:confirm()if not self.tgt and not self.cancellable then
return
end
self.runner:unblock(self.tgt)self.options=nil
self:select()end
function pointer:choose(r,os,interaction,cancellable)self.runner,self.options,self.interaction,self.cancellable=
r,os,interaction,cancellable
if self.mode~="mouse" then
local tgt=min_by(os,function(o)
return #(self.pos*0.01-o.pos*0.01)end)self:select(tgt)self:snap()end
end
function pointer:move(d)d=dirs[d]
local from=self.tgt and self.tgt.pos+self.tgt.sz*0.5 or self.pos
local tgt,mc=min_by(self.options,function(o)
if (o==self.tgt)return 32767
return move_cost(from,o.pos+o.sz*0.5,d)end)
if (tgt and mc<32767)self:select(tgt)
self:snap()end
function pointer:snap()local tgt=self.tgt
self.lpos=tgt.pos+tgt.sz*0.5+(tgt.pointer_off or v(0,0))end
function pointer:select(option)if self.tgt then
self.tgt.selected=false
event(option,"on_deselect")end
if not index_of(self.options,option)then
option=nil
end
self.tgt=option
if option then
option.selected=true
event(option,"on_select")end
end
function pointer:r9(p)local shown=
self.options or self.mode=="mouse"if g_inp.touch and self.mode~="script" then
shown=false
end
if shown then
spr(4,p.x,p.y)end
end
function move_cost(from,to,d)local delta=to-from
while abs(d.x)~=0 and sgn(delta.x)~=sgn(d.x)do
delta.x+=sgn(d.x)*128
end
while abs(d.y)~=0 and sgn(delta.y)~=sgn(d.y)do
delta.y+=sgn(d.y)*128
end
delta*=0.1
local dot=delta:norm():dot(d)local mul=1+(1-dot)*10
if (dot<=0.5)mul*=100
return #delta*mul
end
function pointer:s_pop()local v=self.script[1]
del(self.script,v)
return v
end
function pointer:s_op(op)if op=="move" then
self:move(self:s_pop())self.delay=25
elseif op=="prompt" then
local n=self:s_pop()local a=clone(anims["prompt"..n])for n=1,n do
local txt=""each_char(self:s_pop(),function(c)txt=txt..(c=="/" and "," or c)end)a[n+2].t=txt
end
self.prompt=animation({dur=30,elems=a,locked=true})elseif op=="wait" then
self.delay=60
elseif op=="reset" then
g_tutorial=false
g_game.score=0
g_game.best_cake=0
e_remove(g_reqs)e_remove(g_recipe)e_remove(g_tray)g_tray=nil
g_reqs=reqs()g_reqs:generate()g_reqs:co_next()foreach(g_hand.children,e_remove)g_chooser.cancellable,g_chooser.tgt=true,nil
g_chooser:confirm()else
self[op](self)self.delay=60
end
end
particle=object:extend([[
drag=1,l=1,d=0.016666,
grav=0,
]])particles=entity:extend([[
]])function particles:init()self.ps={}
end
function particles:idle()for k,p in pairs(self.ps)do
p.p+=p.v
p.v*=p.drag
p.v.y+=p.grav
p.l-=p.d
if (p.l<=0)self.ps[k]=nil
end
end
function particles:spawn(props)self.ps[rnd()]=particle(props)end
function particles:r8()for _,p in pairs(self.ps)do
local pos=p.p
if p.radius then
circfill(pos.x,pos.y,p.radius*p.l,p.clr)end
if p.sradius then
local s=1-abs(p.l-0.5)*2
circfill(pos.x,pos.y,p.sradius*s,p.clr)end
end
end
floater=entity:extend[[
]]
function floater:idle()
self.vel+=v(0,0.15)
self.vel*=0.98
self.pos+=self.vel
self.done=self.pos.y>128
end
function floater:r9(p)local w=#self.text*4
printdsh(self.text,p.x,p.y,self.clr,4,0.5)end
announce_clrs=ob[[6,7,9,10,12,]]
function announce(text,clr,cards,ps)
ps=ps or 1
local t=v(0,0)
for c in all(cards)do
t+=c.pos+v(12,12)
end
t/=#cards
local d=0.05*(64-t.x)/64
floater({
text=text,clr=clr,pos=t,
vel=mav(2,rndf(0.2,0.3)+d)
})
for i=1,ps*g_combo.count*10 do
local v=mav(rndf(0.7,1.2),rndf(0,0.5))
g_particles:spawn({
p=t+v*2,v=v,
radius=rndf(1,3),
clr=announce_clrs[rndi(1,#announce_clrs)],
grav=0.02,drag=0.99,
d=0.02,l=rndf(1,1.3),
})
end
end
fingers=entity:extend[[
pos=v(64,96),
]]
function fingers:layout(c)if g_chooser.mode=="mouse" then
self.pos=g_inp.mpos
c.lpos=
g_chooser.tgt
and g_chooser.tgt.pos
or self.pos-c.sz*0.5
else
self.pos=fingers.pos
c.lpos=self.pos-c.sz*0.5+mav(4,self.t/100)end
end
gravity={}
function gravity:falling()
self.vel+=v(0,0.2)
self.pos+=self.vel
self.done=self.pos.y>150
end
function gravity:fall()local d=(64-self.pos.x)/64*0.4
self.vel=v(rndf(-0.4,0.4)+d,-2)self:become("falling")end
reqs=entity:extend[[
next_value=1,
]]
function reqs:init()self.krnd=randomizer({range={0,5},looseness=0.33,no_repeats=true
})self.ttrnd=randomizer({range={1,#tray_types},looseness=1,no_repeats=true,})end
function reqs:generate()local kind=self.krnd:next()local trayt=tray_types[self.ttrnd:next()]
local u=upcoming({trayt=trayt,value=self.next_value,kind=kind
})move(u,self)
self.next_value+=1
end
function reqs:co_next()g_recipe=recipe(self.children[1])set(g_recipe,recipe)e_remove(self.children[1])self:generate()end
function reqs:layout(c,i)c.lpos=v(18+i*8,0)end
function reqs:r7()cutebox(0,3,34,4,1,5,0)printdsh("next:",3,1,13,1)end
upcoming=entity:extend[[
pos=v(44,-10),
]]
function upcoming:idle()l_apply(self)end
function upcoming:r8(p)set_palette(24+self.kind)spr(174,p.x,p.y)end
recipe=entity:extend[[
pos=v(0,-40),
lpos=v(1,-2),
glow=0,
]]
set(recipe,gravity)function recipe:idle()l_apply(self)end
function recipe:r9(p)camera(-p.x,-p.y)if self.glow>0 then
set_palette(mid(16+self.glow,16,21))
self.glow-=0.5
end
spr(189,-1,0,3,4)if not self.fulfilled then
printa(self:text(),12,19,4,0.5)else
spr(255,7,18)end
set_palette(6)palt(13,false)palt(3,true)spr(64+self.kind*2,4,3,2,2)camera()end
function recipe:recheck()local total=0
for slot in all(g_tray.children)do
local c=slot:card()if c and c.kind==self.kind then
total+=c.score
end
end
local fulfilled=total>=self.value
if fulfilled and not self.fulfilled then
self.glow=12
self:fall()animation({elems=anims.recipe_clear,dur=45,})end
self.fulfilled=fulfilled
end
function recipe:text()
return self.value.."+"end
animation=entity:extend[[
dur=60,at=0,
]]
function animation:idle()
self.at+=1
if self.locked and self.at>self.dur then
self.at=self.dur
end
self.done=self.at>self.dur*2.5
end
function animation:dismiss()self.locked=false
end
function animation:r8()local t=1-self.at/self.dur
t=t^5
for e in all(self.elems)do
local dt=t*128
if (e.sym)dt=abs(dt)
animation[e.fn](e.d*dt,e)end
end
function animation.sh(d,o)local p=o.p+d
local c=p+o.s
p.x=max(round(p.x),0)p.y=max(round(p.y),0)c.x=min(round(c.x),127)c.y=min(round(c.y),127)if p.x~=c.x and p.y~=c.y then
shadow(p.x,p.y,c.x,c.y,o.plt)end
end
function animation.prcd(d,o)o.sp=
g_chooser.pmode=="mouse"and 41 or 25
animation.dspr(d,o)end
function animation.dspr(d,o)
if (o.blink and g_t%(o.blink*2)<o.blink)return
spr(o.sp,o.p.x+d.x,o.p.y+d.y,o.s.x,o.s.y)end
function animation.pdsh(d,o)printdsh(o.t,o.p.x+d.x,o.p.y+d.y,o.c1,o.c2,o.a)end
function animation.bar(d,o)local p=o.p+d
local c=p+o.s
rectfill(p.x,p.y,c.x,c.y,o.c)end
anims={}
anims.recipe_clear=ob[[
o(fn="sh",d=v(-2,0),p=v(0,49),s=v(127,2),plt=3),
o(fn="pdsh",p=v(64,48),d=v(1,0),t="recipe cleared!",c1=7,c2=5,a=0.5),
]]
anims.prompt2=ob[[
o(fn="bar",d=v(2,0),p=v(0,27),s=v(127,22),c=0),
o(fn="bar",d=v(2,0),p=v(0,28),s=v(127,0),c=13),
o(fn="pdsh",p=v(64,31),d=v(-1,0),t="",c1=7,c2=13,a=0.5),
o(fn="pdsh",p=v(64,40),d=v(1,0),t="",c1=7,c2=13,a=0.5),
o(fn="prcd",p=v(118,45),d=v(1,0),s=v(1,1),sp=25,blink=45),
]]
anims.prompt3=ob[[
o(fn="bar",d=v(2,0),p=v(0,23),s=v(127,31),c=0),
o(fn="bar",d=v(2,0),p=v(0,24),s=v(127,0),c=13),
o(fn="pdsh",p=v(64,27),d=v(-1,0),t="",c1=7,c2=13,a=0.5),
o(fn="pdsh",p=v(64,36),d=v(1,0),t="",c1=7,c2=13,a=0.5),
o(fn="pdsh",p=v(64,45),d=v(-1,0),t="",c1=7,c2=13,a=0.5),
o(fn="prcd",p=v(118,50),d=v(1,0),s=v(1,1),sp=25,blink=45),
]]
anims.made_cake=ob[[
o(fn="bar",d=v(-2,0),p=v(0,40),s=v(127,0),c=0),
o(fn="bar",d=v(-2,0),p=v(0,71),s=v(127,0),c=0),
o(fn="sh",d=v(2,0),p=v(0,40),s=v(127,1),plt=2),
o(fn="sh",d=v(2,0),p=v(0,42),s=v(127,29),plt=3),
o(fn="dspr",p=v(48,32),d=v(0,-1),sym=1,sp=134,s=v(4,3)),
o(fn="pdsh",p=v(64,52),d=v(1,0),t="fabulous cake!",c1=7,c2=13,a=0.5),
o(fn="pdsh",p=v(64,61),d=v(-1,0),t="24 points!",c1=10,c2=4,a=0.5),
]]
anims.failed_cake=ob[[
o(fn="bar",d=v(-2,0),p=v(0,46),s=v(127,0),c=0),
o(fn="bar",d=v(-2,0),p=v(0,68),s=v(127,0),c=0),
o(fn="sh",d=v(2,0),p=v(0,46),s=v(127,1),plt=2),
o(fn="sh",d=v(2,0),p=v(0,48),s=v(127,20),plt=4),
o(fn="pdsh",p=v(78,46),d=v(1,0),t="not enough chocolate!",c1=14,c2=2,a=0.5),
o(fn="pdsh",p=v(42,56),d=v(-1,0),t="final score:",c1=10,c2=4,a=0),
o(fn="pdsh",p=v(42,64),d=v(1,0),t="best cake:",c1=10,c2=4,a=0),
o(fn="pdsh",p=v(114,56),d=v(-1,0),t="12345",c1=7,c2=5,a=1),
o(fn="pdsh",p=v(114,64),d=v(1,0),t="123",c1=7,c2=5,a=1),
]]
cake_qualities=ob[[
o(5,"nice"),
o(15,"tasty"),
o(25,"yummy"),
o(40,"delicious"),
o(60,"luscious"),
o(80,"scrumptious"),
o(160,"heavenly"),
o(320,"divine"),
o(640,"unbelievable"),
]]
combo=entity:extend[[
pos=v(64,83),
lpos=v(64,83),
ctr=v(32,51),
count=0,
llerp=0.3,
glow=0,
]]
function combo:idle()l_apply(self)end
function combo:bump(by)
self.count+=by
self.pos-=v(0,10)
end
function combo:reset()self.count=0
self.pos=combo.pos
self.lpos=combo.pos
end
function combo:co_apply()local bonus=self.count-1
self.glow=12
local cs=card.played_in_move_order()for frm=0,30 do
local t=frm/30
local ang=lerp(0,0.6,t)
self.lpos+=mav(lerp(3,12,t),ang)
local crd=cs[frm/5]
if crd then
crd:point_out()
crd.score+=bonus
co_update_state()announce("+"..bonus,10,{crd},0.3)sfx(3)end
g_rnr:delay(1)yield()end
end
function combo:r8(p)local cnt=self.count
set_palette(mid(16,21,self.glow))if cnt>=2 then
spr(128,p.x-19,p.y,5,2)printdsh(cnt,p.x+19,p.y+4,10,4,0.5)end
end
tray_types=ob[[
o(
mx=36,my=0,
grid=o(
v(0,0),v(1,0),
v(0,1),v(1,1),v(2,1),
),
rpos=v(84,21),
),
o(
mx=48,my=0,
grid=o(
v(1,0),v(2,0),
v(0,1),v(1,1),v(2,1),
),
rpos=v(18,18),
),
o(
mx=60,my=0,
grid=o(
v(0,0),v(2,0),
v(0,1),v(1,1),v(2,1),
),
rpos=v(53,13),
),
]]
tray=entity:extend[[
tags=o("tray"),
score=0,
shake=0,
]]
set(tray,gravity)function tray:init()set(self,self.trayt)self.slots={}
for c in all(self.grid)do
local s=
slot({tray=self,coords=c
})self.slots[c:str()]=s
move(s,self)end
end
function tray:idle(t)l_apply(self)if self.shake>0 then
self.pos+=v(sin(t/15)*self.shake,0)
self.shake-=0.15
end
end
function tray:anim_shake()self.shake=5
end
function tray:update_score()local total=0
for s in all(self.children)do
local sc=s:card()
if (sc)total+=sc.score
end
self.score=total
end
function tray:co_complete()local rec=g_recipe
if not rec.fulfilled then
self:co_fail()
return false
end
for s in all(self.children)do
s:card():point_out()end
music(0)g_rnr:delay(15)yield()self:fall()local score=self.score
g_game:score_cake(score)local quality=min_by(cake_qualities,
function(q)return abs(q[1]-score)end)[2]
anims.made_cake[6].t=quality.." cake!"anims.made_cake[7].t=score.." points!"animation({elems=anims.made_cake})g_rnr:delay(90)yield()
return true
end
function tray:co_fail()if g_game.score>dget(0)then
dset(0,g_game.score)end
self:anim_shake()music(1)g_recipe.lpos=v(8,44)e_remove(g_reqs)e_remove(g_game)local f=anims.failed_cake
f[5].t="not enough "..kinds[g_recipe.kind+1].."!"f[8].t=tostr(g_game.score)f[9].t=tostr(g_game.best_cake)local anim=animation({elems=f,locked=1
})g_rnr:waitforbtn()yield()anim:dismiss()g_recipe:fall()self:fall()end
function tray:is_complete()
return #filter(self.children,is_empty)==0
end
function tray:anim_nudge()
self.pos.y+=4
end
function tray:r2(p)palt(3,true)palt(13,false)map(self.mx,self.my,p.x-8,p.y-8,11,9)end
slot=entity:extend[[
tags=o("slot"),
sz=v(24,24),
]]
function slot:idle()self.pos=self.tray.pos+self.coords*24
end
slot.init=slot.idle
function slot:layout(child,i)child.lpos=self.pos
end
function slot:on_select()self:evaluate_drop()end
function slot:evaluate_drop()local fc=g_fingers.children and g_fingers.children[1]
local effects={}
for d=1,4 do
local ns=self:neighbour(d)local nc=ns and ns:card()if nc then
if nc.kind==fc.kind then
add(effects,{d=d,c=12})end
local fl=fc.links[d]
if fl and fl.kind==nc.kind then
add(effects,{d=d,c=9})end
local id=inverse[d]
local nl=nc.links[id]
if nl and nl.kind==fc.kind then
add(effects,{d=d,c=9,inv=true})end
end
end
self.effects=effects
end
function slot:neighbour(direction)local dc=self.coords+dirs[direction]
local slot=self.tray.slots[dc:str()]
return slot
end
function slot:neighbours()local ns={}
for d=1,4 do
add(ns,self:neighbour(d))end
return ns
end
function slot:card()
return self.children and self.children[1]
end
function slot:r3(p)if self.selected then
local d=flr(self.t%30/15)camera(-p.x,-p.y)spr(9,1+d,1+d)spr(9,15-d,1+d,1,1,true)spr(9,15-d,15-d,1,1,true,true)spr(9,1+d,15-d,1,1,false,true)camera()end
end
function slot:r9(p)if self.selected then
camera(-p.x,-p.y)for e in all(self.effects)do
if self.t%10==e.d then
local p=self.pos+v(12+rndf(-1,1),12+rndf(-1,1))local v=dirs[e.d]
if e.inv then
p+=v*24
v*=-1
end
g_particles:spawn({p=p,v=v,d=0.05,radius=2.5,clr=e.c,})end
if self.t%45==0 then
self:neighbour(e.d):card():point_out(6)end
end
camera()end
end
kinds=ob[[
"chocolate","jam",
"raisins","honey",
"dough","nuts",
]]
card=entity:extend[[
tags=o("card"),
t_bg=o(o(1,1,22,22,13,fn="rf")),
t_sides=o(
o(o(0,1,0,22,1,fn="rf"),
o(1,1,1,22,7,fn="rf")),
o(o(23,1,23,22,0,fn="rf"),
o(22,1,22,22,5,fn="rf")),
o(o(1,0,22,0,1,fn="rf"),
o(1,1,22,1,7,fn="rf")),
o(o(1,23,22,23,0,fn="rf"),
o(1,22,22,22,5,fn="rf")),
),
sz=v(24,24),
glow=0,
]]
cardbg=ob[[
o(0,0,23,23,13,fn="rf"),
]]
function card:init()self.icn=64+self.kind*2
end
function card:idle()l_apply(self)end
function card:point_out(n)self.glow=n or 9
end
function card.played_in_move_order()local played=filter(entities_tagged.card,function(c)
return c.parent and c.parent:is_a("slot")end)
return sort_by(played,function(c)
return -c.moved_on
end)end
function card:find_pulls()local ps={}
for d=1,4 do
local l=self.links[d]
if l then
local nc=self:neighbour(d)if nc and nc.kind==l.kind then
add(ps,make_pull(self,l))end
end
end
return ps
end
function card:neighbour(d)local slt=self.parent
if (not slt or not slt:is_a("slot"))return
local ns=slt:neighbour(d)
return ns and ns:card()end
function card:find_fused()local fs={}
for d=1,4 do
local nc=self:neighbour(d)if nc and nc.kind==self.kind then
add(fs,nc)end
end
return fs
end
function card:co_place(slot)self.llerp=0.5
move(self,slot)slot.tray:anim_nudge()g_rnr:delay(8)yield()end
function card:co_fuse_with(cs)self:point_out()for c in all(cs)do
c:point_out()
self.score+=c.score
self.links=merge(c.links,self.links)end
sfx(min(5+g_combo.count,8))announce("fuse!",10,{self,other})g_rnr:delay(15)yield()for c in all(cs)do
c.llerp=0.15
move(c,self.parent)end
g_rnr:delay(12)yield()foreach(cs,e_remove)end
function card:r7(p)local slotted=self.parent:is_a("slot")if not slotted then
for dy=0,2 do
shadow(p.x+dy,p.y+23+dy,p.x+24-dy,p.y+23+dy,2)end
shadow(p.x+24,p.y+2,p.x+24,p.y+22,2)end
set_palette(16+mid(self.glow,0,5))
if (self.glow>0)self.glow-=0.5
camera(-p.x,-p.y)draw_from_template(card.t_bg)for s=1,4 do
draw_from_template(card.t_sides[s])end
for d,l in pairs(self.links)do
local lp=v(8,8)+dirs[d]*12
local n=self:neighbour(d)if n then
if (d==2 and n.links[1])lp.x-=1
if (d==4 and n.links[3])lp.y-=1
end
set_palette(24+l.kind)spr(169+d,lp.x,lp.y)end
set_palette(16+mid(self.glow,0,5))palt(3,true)palt(13,false)spr(self.icn,4,4,2,2)set_palette(self.kind+8)local ln=#tostr(self.score)spr(136+ln*2,5+ln*2,18,2,2)print(self.score,20-2*ln,20,8)camera()end
pull=object:extend[[
]]
function pull:conflicts_with(other)
return #filter(self.cards,function(c)
return index_of(other.cards,c)end
)>0
end
function pull:merge_with(with)local crds=clone(self.cards)for c in all(with.cards)do
if not index_of(crds,c)then
add(crds,c)end
end
local lnks=concat(self.links,with.links
)
return pull({cards=crds,links=lnks
})end
function pull:score()local _,bonus=min_by(self.cards,
function(c)return c.score end
)for c in all(self.cards)do
c:point_out()
c.score+=bonus*(#self.links)
end
for l in all(self.links)do
announce("link +"..bonus.."!",10,{l.crd,l.other})end
end
function pull:swap()for l in all(self.links)do
l.crd.links[l.d]=nil
end
if #self.cards==2 then
local a,b=self.cards[1],self.cards[2]
a.llerp,b.llerp=0.2,0.2
local ap,bp=a.parent,b.parent
move(a,bp)move(b,ap)end
end
function make_pull(card,link)local d=link.direction
local other=card:neighbour(d)
return pull({links={{crd=card,other=other,d=d}},cards={card,other}
})end
function co_execute_pulls(ps)sfx(min(5+g_combo.count,8))foreach(ps,pull.score)g_rnr:delay(12)yield()foreach(ps,pull.swap)g_rnr:delay(12)yield()end
function merge_pulls(ps)local nothing_merged
repeat
nothing_merged=true
for i=1,#ps do
for j=i+1,#ps do
local a,b=ps[i],ps[j]
if a:conflicts_with(b)then
local n=a:merge_with(b)del(ps,a)del(ps,b)add(ps,n)nothing_merged=false
goto retry
end
end
end
::retry::
until nothing_merged
return ps
end
hand=entity:extend[[
rnds=o(
k=o(range=o(0,5)),
ld=o(range=o(1,4),looseness=0.5),
lk=o(range=o(0,5)),
v=o(es=o(1,2,2,3)),
),
]]
function hand:init()self.children={}
for k,v in pairs(self.rnds)do
self[k.."rnd"]=
randomizer(v)end
end
function hand:co_deal_new(force_recipe)local ch=self.children
if (#ch>=5)return
local k
local forced=
force_recipe and
#ch==4 and
#filter(ch,function(c)
return c.kind==g_recipe.kind
end)==0
if forced then
k=g_recipe.kind
end
if not k then
k=self.krnd:next()end
local c=card({pos=v(144,140),lpos=v(144,140),kind=k,score=self.vrnd:next(),links={}
})local link_count=1
for l=1,link_count do
local link_k,link_d
repeat
link_k=
self.lkrnd:next(k)link_d=
self.ldrnd:next()until not c.links[link_d]
c.links[link_d]={direction=link_d,kind=link_k}
end
move(c,self)sfx(1)g_rnr:delay(8)yield()end
function hand:layout(child,i)local n=#self.children
local x=64+(i-1-n/2)*25
child.lpos=v(x,101-(child.selected and 4 or 0))end
anims.logo=ob[[
o(fn="sh",d=v(0,-1),p=v(0,18),s=v(127,2),plt=2),
o(fn="sh",d=v(0,-1),p=v(0,20),s=v(127,22),plt=3),
o(fn="bar",d=v(0,-1),p=v(0,18),s=v(127,0),c=0),
o(fn="bar",d=v(0,-1),p=v(0,43),s=v(127,0),c=0),
o(fn="dspr",d=v(0,1),p=v(44,17),s=v(5,4),sp=10),
]]
function logo()
return animation({dur=45,elems=anims.logo,locked=true
})end
blinker=entity:extend[[
]]
function blinker:r8(p)
if (self.t<60)return
local t=(self.t-60)%90
if t<=45 then
printdsh(self.text,p.x,p.y,10,4,0.5)end
if (t==0)sfx(2)
end
menu_text=entity:extend[[]]
function menu_text:r8()
if dget(0)>0 then
printdsh("best score: "..dget(0),64,111,7,13,0.5)
printdsh("best cake: "..dget(1),64,119,7,13,0.5)
else
printdsh("controls:",64,99,15,4,0.5)
printdsh("use mouse/touch to drag",64,109,6,5,0.5)
printdsh("or arrows+[z]/[x]on keyboard",64,117,6,5,0.5)
end
end
menu_op=entity:extend[[
sz=v(80,10),
pointer_off=v(21,0),
]]
function menu_op:r8(p)local sh=self.selected and 3 or 2
shadow(p.x,p.y-1,p.x+71,p.y+8,sh)printdsh(self.text,p.x+36,p.y+1,10,4,0.5)end
function main_menu(rnr)while true do
local s,htp=
menu_op({text="start game",pos=v(28,61)}),menu_op({text="how to play",pos=v(28,74)})local menu_entities={logo(),menu_text(),s,htp
}
g_chooser.pos=v(64,40)g_rnr:choose({s,htp},"click")local choice=yield()g_tutorial=choice==htp
foreach(menu_entities,e_remove)co_init_game()if g_tutorial then
co_init_tutorial()end
game_logic(rnr)co_end_game()g_rnr:delay(75)yield()end
end
game=entity:extend[[
score=0,best_cake=0,
]]
function game:score_cake(pts)self.best_cake=max(pts,self.best_cake)if pts>dget(1)and not g_tutorial then
dset(1,pts)end
self.score+=pts
end
function game:r8()local w=#tostr(self.score)*4
cutebox(99-w,0,127,7,1,5,0)printdsh(self.score,126,1,7,5,1)printdsh("score:",126-w,1,13,1,1)end
tray_def=ob[[
pos=v(-40,24),
lpos=v(27,28),
]]
function co_update_state()g_tray:update_score()g_recipe:recheck()end
function game_logic(rnr)g_reqs:generate()g_reqs:co_next()while true do
g_combo:reset()if not g_tray then
g_tray=tray(set(tray_def,{trayt=g_recipe.trayt
}))while #g_hand.children<5 do
g_hand:co_deal_new(true)end
end
if is_empty(g_hand)then
return
end
rnr:choose(g_hand.children,"click")local card=yield()if not card then
goto cancelled
end
move(card,g_fingers)card.pop=true
sfx(1)rnr:choose(filter(entities_tagged.slot,is_empty
),"drag",true)local spot=yield()card.pop=false
if not spot then
move(card,g_hand)sfx(1)goto cancelled
end
card:co_place(spot)co_update_state()sfx(0)local triggered
local pulls
repeat
triggered=false
for card in all(card.played_in_move_order())do
local fused=card:find_fused()if #fused>0 then
g_combo:bump(1)card:co_fuse_with(fused)for i=1,#fused do
g_hand:co_deal_new()end
triggered=true
goto reevaluate
end
end
pulls={}
for c in all(card.played_in_move_order())do
pulls=concat(pulls,c:find_pulls())end
pulls=merge_pulls(pulls)if #pulls>0 then
g_combo:bump(#pulls)co_execute_pulls(pulls)if not g_tray:is_complete()then
g_hand:co_deal_new()end
triggered=true
goto reevaluate
end
::reevaluate::
co_update_state()until not triggered
if g_combo.count>=2 then
g_combo:co_apply()end
if g_tray:is_complete()then
local valid=g_tray:co_complete()if not valid then
return
end
g_tray=nil
g_reqs:co_next()end
::cancelled::
end
end
runner=object:extend[[
blocked=f,
]]
function runner:start(logic)self.value=self
self.co=cocreate(logic)end
function runner:process()if not self.blocked then
if (costatus(self.co)=="dead")return
g_rnr=self
assert(coresume(self.co,self.value))g_rnr=nil
self.value=true
end
end
function runner:unblock(value)self.value,self.blocked=value
end
function runner:delay(dur)self.blocked=true
delay({runner=self,dur=dur})end
function runner:waitforbtn()self.blocked=true
waitforbtn({runner=self})end
function runner:choose(...)self.blocked=true
g_chooser:choose(self,...)end
delay=entity:extend()function delay:idle()self.done=self.t>=self.dur
if self.done then
self.runner:unblock()end
end
waitforbtn=entity:extend[[
]]
function waitforbtn:idle()if g_inp.proceed then
self.done=true
self.runner:unblock()end
end
tutorial=ob[[
cards=o(
k=o(0,0,1,3,4,5),
ld=o(1,2,3,4,1,3),
lk=o(1,3,3,2,2,0),
),
recipes=o(
k=o(0),
tt=o(1),
),
script=o(
"prompt",2,
"you're baking cakes",
"for the holidays!",
"prompt",2,
"you do this by putting",
"ingredients into the tray.",
"move",2,
"move",2,
"confirm",
"move",1,
"move",1,
"move",3,
"move",2,
"move",4,
"move",2,
"confirm",
"prompt",2,
"you have to match the recipe",
"in the top-left corner.",
"prompt",3,
"this one means that the total",
"score on chocolate tiles used",
"in your cake must be 1 or more.",
"move",1,
"move",1,
"move",1,
"confirm",
"confirm",
"prompt",2,
"the recipe will fall away",
"when it's finished.",
"prompt",3,
"if you place two identical",
"tiles next to each other/",
"they will fuse.",
"move",1,
"confirm",
"move",3,
"move",1,
"move",2,
"move",4,
"confirm",
"prompt",2,
"tiles with different symbols",
"interact through links.",
"prompt",2,
"see these colored knobs",
"on the sides of your tiles?",
"prompt",3,
"a red knob on the left means",
"you can link to a red tile",
"through that side.",
"move",1,
"confirm",
"wait",
"confirm",
"prompt",2,
"this swaps the tiles and",
"adds bonus points to both.",
"prompt",2,
"forming longer combos adds",
"points to all your tiles.",
"confirm",
"move",1,
"move",2,
"wait",
"confirm",
"prompt",3,
"once the tray fills up/",
"the cake is scored",
"and a new recipe appears.",
"move",1,
"move",1,
"confirm",
"confirm",
"prompt",2,
"you're on your own now!",
"good luck!",
"reset",
),
]]
function grab()set_palette()palt(13,false)for k=0,5 do
sspr(k*16,32,16,16,0,0,8,8)for x=0,7 do
for y=0,7 do
sset(64+k*8+x,120+y,pget(x,y))end
end
end
cstore()end
function _init()init_palettes()i_init_input()e_reset()bg()g_particles=particles()g_chooser=pointer()g_runner=runner()g_runner:start(main_menu)end
function co_init_game()g_move_ctr=0
g_game=game()g_hand=hand()g_combo=combo()g_reqs=reqs()g_fingers=fingers()g_tray=nil
end
function co_end_game()local retiring={g_game,g_hand,g_combo,g_reqs,g_fingers
}
foreach(retiring,e_remove)end
function co_init_tutorial()force(g_hand,tutorial.cards)force(g_reqs,tutorial.recipes)g_chooser.script=clone(tutorial.script)g_chooser.pos=v(64,64)end
g_t=0
function _update60()
g_t+=1
l_do_layouts()i_update_input()e_update_all()g_runner:process()end
function _draw()cls()r_render_all()end