--picokaiju 1.1
--by @spoike 🐱

dirx,diry=split("1,-1,0,0,1,1,-1,-1"),split("0,0,1,-1,1,-1,-1,1")
nextdir=split("4,3,1,2")
debug,last_pressed={},0
map_size_x,map_size_y=54,15
cols=split("0,5,6")
smoke_patterns={░,▒,█}
roars=split("roar,rawr,gawr,grrr,grar,graw,rowr,warr")

menuitem(1,"clear highscore",function ()
 highscore=0
 dset(0,0)
end)

function _init()
 palt(15,true)
 cartdata("spoike_picokaiju_2")
 highscore=dget(0) 
 poke(0x5f2e,1)
 pal(3,133,1)
 pal(4,134,1)
 pal(1,0,1)
 logo_particles,entities,anims,floats,ripples,bq,xoff,xoff_diff,shake,tick,fade,intro_fade,intro_fade_diff,button_released={},{},{},{},{},{},0,0,0,0,0,0,0,true
 for i=1,25 do
  add(logo_particles, 
  {
   rndint(10,118),
   rndint(0,64)
  })
  add(logo_particles, 
   {
    rndint(10,118),
    rndint(65,128)
   })
 end

 start_generate_world()
 start_intro()
 -- testing:
 --_drw,_upd=draw_game,update_game
 --_drw,_upd=draw_game,update_debug
 --[[
 buildings_killed=10
 mobs_killed=20
 trees_killed=10
 level_ups=3
 turns=1
 xp=0xf000.f1ff
 --]]
 --start_game_over()
 --start_level_screen()
end

--[[
function update_debug()
 if btn(1) then
  xoff+=8
 elseif btn(0) then
  xoff-=8
 end
end
]]

stat_labels=split("turns taken,houses destroyed,mobs crushed,trees stomped,power ups grabbed,points")
function start_game_over()
 got_highscore=xp > highscore
 if got_highscore then
  dset(0,xp)
  highscore=xp
 end
 go_x,go_t,go_mov=110,0,false
 stats={turns,buildings_killed,mobs_killed,trees_killed,level_ups,xp}
 music(-1,100)
 add_bq(function ()
  for i=0,20 do
   fade=i*10
   yield()
  end
  music(6,1000)
  _drw,_upd=draw_gameover,update_gameover
  fade=0
 end)
 if player then player.hurt=true end
end

function draw_gameover()
  --rect(0,0,127,10,8)
  print_cs("all things must come to pass",10,7,4)
  draw_player_sprite(flr(go_x),24,false,go_mov,false,true)
  for i, entry in pairs(stats) do
    if go_t > i*20 then
      local t = min((go_t-(i*20))/20,1)
      local l = flr(lerp(0,entry,t)) 
      if i == #stats then
        l=get_score(xp)
      end
      print_c(
        pad_between(stat_labels[i],l),
        40+(8*(i-1)),7)
    end
  end
  --if got_highscore then
  if got_highscore and go_t > (#stats)*20 then
   print("high score!", 83, 88, 8)
  end

  if go_t > (#stats+2)*20 and blink then
    print_cs("press any button to restart", 110, 7, 4)
  end
end

function pad_between(str_a,str_b,width)
 width = width or 30
 width -= #str_a + #(str_b.."") + 2 
 local o = str_a.." "
 for i=0,width do
  o=o.."."
 end
 return o.." "..str_b
end

function update_gameover()
  local d = abs(sin(t()*0.2)*0.25)
  go_x-=d
  go_t+=1
  go_mov = d > 0.1
  if go_x<-8 then go_x=127 end

  if go_t > (#stats+2)*20 and btnp() > 0 then
   button_released=false
   start_intro()
   sfx(5)
  elseif btnp() > 0 then
   go_t=flr((go_t/20)+1)*20
  end
end

function spawn_player(x,y)
 player = {
  x=x,
  y=y,
  tx=flr(x/8),
  ty=flr(y/8),
  sel_dir=2,
  mov=false,
  flip=true,
  draw=draw_player
 }
 add(entities,player)
 add_roar()
 add_splash(player.x,player.y+4)
 add_ripple(flr(player.x/8),flr(player.y/8))
end

function start_generate_world()
 move_map={}
 music(-1,1000)
 -- test new abilities here
 abilities=split("grab,throw")
 abilities_to_level=split("hp_up,regen_up,energy_up,throw_up,zap")
 turns,xp,poison,hp,max_hp,energy,max_energy,regen,level_ups,combo,music_started,next_level_up=-1,0,0,5,5,5,5,1,0,0,false,0x0000.01f4
 xoff,player,entities,anims,bq,mobs,tiledata,mobs_killed,trees_killed,buildings_killed=0,nil,{},{},{},{},{},0,0,0
 mob_civ,mob_cop,mob_tank,mob_heli,mob_mad={},{},{},{},{}
 in_hand,throw_length,throw_strength,zap_range=nil,12,2,5
 procgen=cocreate(generate_world)
end

function generate_world()
 -- Shoreline
 local shore=rndint(3,5)
 for y=0,map_size_y do
  shore=mid(3,7,shore+rndint(-1,1))
  for x=0,map_size_x do
   local t = 0
   if shore>x then
    t=63
   elseif maybe() then
    --trees
    t=rndint(1,3)
   end
   mset(x,y,t)
  end
  yield()
 end
 prettify_tiles(0)

 copy_map(4,rndint(2,9),
  rndint(0,6)*5+1,17,
  3,3
 )
 prettify_tiles(0)
 for sx=7,map_size_x-7,5 do
  if maybe() then
    for i=0,8 do mset(sx,i,76) end
  end
  local y=2
  while y < 13 do
    local h=rndint(3,4)
    copy_map(sx,y,
      rndint(0,6)*5,h == 3 and 16 or 19,
      6,
      min(h+1,14-y)
    )
    yield()
    y+=h
  end
  if maybe(0.6) then
    for i=9,15 do
      mset(sx,i,76)
    end
  end
  prettify_tiles(1)
  yield()
 end
end

function prettify_houses(sx,sy,w,h)
 for x=sx,sx+w do
  for y=sy,sy+h do
   local tile = mget(x,y)
   if tile==1 then
    mset(x,y,rndint(1,3))
   elseif tile==5 then
    mset(x,y,rndint(5,11))
   elseif tile==12 then
    if x > 20 and maybe(0.25) then
      add_building(x,y,
        rndint(5, 8)
      )
    else
    mset(x,y,rndint(10,15))
    end
   elseif tile==112 then
    if x > 20 or maybe(0.25) then
      add_building(x,y,
        rndint(5,
          rndint(6,6+flr(x/5))
        )
      )
    else
      mset(x,y,rndint(5,14))
    end
   end
  end
 end
end

function copy_map(sx,sy,dx,dy,w,h)
  for i=0,h-1 do
   memcpy(0x2000+sx+((sy+i)*128),0x2000+dx+((dy+i)*128),w)
  end
  prettify_tiles(1)
  prettify_houses(sx,sy,w,h)
end

function update_procgen()
 if procgen and costatus(procgen) != "dead" then
  coresume(procgen)
 else
  procgen = nil
 end
end

function prettify_tiles(flag)
 for y=0,map_size_y do
  for x=0,map_size_x do
   local t=flr(mget(x,y)/16)*16
   if fget(t,flag) then
    local sig = tilesig(x,y,flag)
    mset(x,y,t+sig)
   end
  end
 end
end


function _update()
 if procgen then
  update_procgen()
 end
 tick+=1
 shake*=0.6
 last_pressed = btn()==0 and last_pressed+1 or 0
 show_cmds=player and _upd==update_game and last_pressed > 120
 blink=sin(t()*0.5)>=0
 for anim in all(anims) do
  if anim and costatus(anim) != "dead" then
   coresume(anim)
  else
   del(anims,anim)
  end
 end
 update_floats()
 if tick % 3 == 0 then
  update_ripples()
 end
 _upd()
end

function _draw()
 cls()
 _drw()
 camera()
 for idx,line in pairs(debug) do
  print(line,0,(idx-1)*7+1,0)
  print(line,0,(idx-1)*7,15)
 end
 --center_camera()
 --[[debug move_map
 for i,tile in pairs(move_map) do
  spr(137+tile[3], tile[1]*8, tile[2]*8)
  print(tile[4], tile[1]*8, tile[2]*8, 7)
 end
 --]]
end

function update_floats()
 for f in all(floats) do
  f.t+=1
  if f.t >= 30 then
   del(floats, f)
  end
 end
end

function add_float(text,x,y,fgcol,bgcol,bubble)
  text=text..''
  add(floats,{text,x,y,fgcol,bgcol,t=0,bubble=bubble})
end

function add_roar()
 shake=5
 if regen > 0 then
  hp=mid(1,hp+regen,max_hp)
 end
 add(floats, {rnd(roars),
  player.x+4,
  player.y,7,0,
  t=0,bubble=true})
end

function draw_floats()
 for f in all(floats) do
  local maxt,text = 14,f[1]..''
  local offx=#text*2
  if f.bubble then
   maxt = 13
   pal(8,1)
   spr(134,f[2]-3-offx,f[3]-mid(0,f.t,maxt)-3,3,2)
   pal(0)
   spr(134,f[2]-3-offx,f[3]-mid(0,f.t,maxt)-4,3,2)
  end
  print_s(f[1],f[2]-offx,f[3]-mid(0,f.t,maxt),f[4],f[5])
 end
end


-->8
-- main routines

function draw_game(disable_ui)
 center_camera()
 if not disable_ui then
  clip(0,8,128,120)
 end
 map(0,0,0,0,map_size_x,map_size_y)
 draw_water()
 if _upd==update_select_direction then
  local x,y = (player.tx-dirx[player.sel_dir])*8,
   (player.ty-diry[player.sel_dir])*8
  if sin(t()*4) > 0 then
   rectfill(x-1,y-1,x+8,y+8,8)
  end
 end
 for entity in all(entities) do
  entity.draw(entity)
 end
 -- draw ui
 clip()
 camera()
 if disable_ui then
  return
 end
 fillp()
 rectfill(0,0,128,8,0)
 rectfill(0,120,128,128)
 -- draw hp bar
 if max_hp > 0 and turns > 4 then
  spr(162,0,0)
  for i=1,max_hp do
   local x=i*2+6
   rectfill(x,2,x,7,5)
   if i<=hp then
   rectfill(x,2,x,6,7)
   end
  end
  if poison >= 1 then
    print("-"..poison,max_hp*2+10,3,8)
  end
 end
 local command=""
 if hp <= 2 then
  command=blink and "🅾️ roar to\n   heal "..regen.."hp" or ""
 elseif show_cmds then
  command="🅾️ roar"
 end
 print_s(command,1,9,7,2)

 -- draw energy bar
 if max_energy > 0 and turns > 4 then
  spr(163,120,0)
  for i=1,max_energy do
   local x=122-(i*2)
   rectfill(x,2,x,7,5)
   if i<=energy then
    rectfill(x,2,x,6,7)
   end
  end
 end
 command=""
 local cl=0
 if energy<=1 then
  command=in_hand==nil and "grab & chomp ❎" or "chomp    ❎"
  cl=#command
  command=command.."\nto recharge"
  command=blink and command or ""
 elseif show_cmds then
  command="abilities ❎"
  cl=#command
 end
 print_s(command,124-(cl*4),9,7,2)

 --line(64,0,64,128,8) debug center
 if combo >= 2 then
  local c = combo..""
  local s = mid(0,6,(combo/2)-2)
  local yoff=combo > 10 and (sin(t()*6)+sin(t()*8))*0.5 or 0
  if combo > 10 then
   pal(7,8)
  end
  local x 
  for i=1,#c do
    x = flr(58+(i*(8+s))-(#c*(4.5+s)))
    sspr((ord(c,i)-48)*8+32,
      80,
      6,8,
      x,yoff,
      6+s,8+s
    )
  end
  sspr(112,80,6,8,x+(8+s),yoff,6+s,8+s)
  pal(0)
 end
 if turns > 0 then
   print_s('TURN '..turns,1,121,6,5)
 end
 if xp > 0x0000.0000 then
  local xp_label='XP '..get_score(xp)..'/'..get_score(next_level_up)
  print_s(xp_label,128-(#xp_label*4),121,6,5)
 end
 if message then
  local y = player.y>64 and 8 or 110
  rectfill(2,y,125,y+11,1)
  rect(3,y+1,124,y+10,6)
  print_cs(message, y+3, 7, 4)
 end
 if not player and not procgen then
  print_cs("press 🅾️ to roar",121,7,4)
 end

 center_camera()
 draw_floats()

 camera()
 rectfill(0,128-fade,128,128,0)
end

function draw_water()
 -- waves
 for y=0,map_size_y do
  for x=0,map_size_x do
   if has_tile_flag(x,y,0) then
    local p = sin((t()-(x*0.2)-(y*0.15))*0.2)
    fillp(ˇ)
    if p>0.95 then
     fillp(▒)
    elseif p>0.70 then
     fillp(░)
    end
    if p>0.2 then
     rectfill(x*8+1,y*8+1,(x+1)*8-2,(y+1)*8-2,4)
    end
    fillp()
   end
  end
 end
 -- ripples
 for ripple in all(ripples) do
  fillp(░)
  for cell in all(ripple.previous_cells) do
   if has_tile_flag(cell.x,cell.y,0) then
    rectfill(
     cell.x*8+1,cell.y*8+1,
     (cell.x+1)*8-2,(cell.y+1)*8-2,6)
   end
  end
  fillp(▒)
  for cell in all(ripple.cells) do
   if has_tile_flag(cell.x,cell.y,0) then
    rectfill(
     cell.x*8+1,cell.y*8+1,
     (cell.x+1)*8-2,(cell.y+1)*8-2,6)
   end
  end
 end
end
function add_ripple(x,y,dir)
 add(ripples, {x=x,y=y,r=0,dir=dir,cells={}})
end
function update_ripples()
 for ripple in all(ripples) do
  ripple.previous_cells=ripple.cells
  ripple.r+=1
  local cells = {}
  local r=ceil(ripple.r)*8
  for i=0,r do
   local xi,yi=
    flr(sin(i/r)*ripple.r+ripple.x+0.5),
    flr(cos(i/r)*ripple.r+ripple.y+0.5)
   if has_tile_flag(xi,yi,0) and xi >= 0 and xi < map_size_x and yi >= 0 and yi < map_size_y then
    add(cells, {
     x=xi,
     y=yi})
   end
  end
  ripple.cells = cells
  if ripple.r > 10 then
   del(ripples, ripple)
  end
 end
end

function print_s(text,x,y,cfg,cbg)
 print(text,x,y+1,cbg)
 print(text,x,y,cfg)
end
function print_cs(text,y,cfg,cbg)
  print_s(text,64-(#text*2),y,cfg,cbg)
end
function print_c(text,y,cfg)
  print(text,64-(#text*2),y,cfg)
end

function draw_intro()
 center_camera()
 draw_game(true)
 camera()

 -- draw logo smoke particles
 local fade_scale = mid(0,1 - (intro_fade/256),1)
 for p in all(logo_particles) do
  local s = mid(0,p[2]/3,60)*fade_scale
  fillp(░)
  circfill(p[1],p[2],s,5)
 end
 for p in all(logo_particles) do
  local s = mid(0,p[2]/3,60)*fade_scale
  fillp(░)
  circfill(p[1],p[2],s-3,6)
  fillp()
  circfill(p[1],p[2],s-10,6)
 end

 -- for label
 -- big logo
 clip(max(0,(intro_fade*0.5)-20),0,128,128)
 pal(8,2)
 sspr(0,80,16,8,24,12,32,16)
 sspr(0,64,48,16,2,32,76,60)
 pal(0)
 sspr(0,80,16,8,24,10,32,16)
 sspr(0,64,48,16,2,29,76,60)

 -- bar with text
 clip(intro_fade*1.5,0,128,128)
 fillp(▤)
 rectfill(0,30,128,49,0)
 fillp()
 rectfill(0,34,128,43,0)
 print("picokaiju",9,38,8)
 print_s("picokaiju",9,36,7,8)

 -- kaiju dino
 palt(15, true)
 sspr(0,96,32,32,2,10+max(0,sin(t())*5),128,128)

 clip()
 rectfill(0,0,127,8,1)
 rectfill(0,120,127,127,1)

 if highscore > 0 then
  print_cs("highscore "..get_score(highscore),121,7,3)
 end
 if blink then
  print_cs("press any button to start",2,8,3)
 end

end

function update_intro()
 -- scrolling marquee
 xoff=xoff+xoff_diff
 if 
   (xoff_diff > 0 and xoff >= (map_size_x*8)-128) or
   (xoff_diff < 0 and xoff <= 0)
 then
  xoff_diff*=-1
 end
 -- update logo particles
 if button_released and btnp() > 1 then
  intro_fade_diff=6.28
  sfx(5)
 end
 if button_released == false and btn() == 0 then
  button_released=true
 end
 for p in all(logo_particles) do
  p[2]=mid(0,p[2]-1,150)
  if p[2] == 0 then
   p[2] = 200
  end
 end
 intro_fade=mid(0,intro_fade+intro_fade_diff,257)
 if intro_fade > 256 then
  _drw,_upd=draw_game,update_game
  intro_fade,intro_fade_diff=0,0
  start_generate_world()
 end
end

function start_intro()
  music(0)
  _drw,_upd=draw_intro,update_intro
  xoff=0
  xoff_diff=0.20
  intro_fade=255
  intro_fade_diff=-10
end

function rndint(a,b)
 local range = max(a,b)-min(a,b)
 return flr(rnd(range+1))+min(a,b)
end

player_body={16,38}
player_feet={{32,33},{40,41}}
function draw_player(player)
 local on_water = has_tile_flag(player.tx,player.ty,7)
 draw_player_sprite(player.x,player.y,player.flip,player.mov,on_water,player.hurt,player.blinking)
end

function draw_player_sprite(x,y,flip,mov,on_water,hurt,blinking)
 local s=hurt and 2 or 1
 y = y-4
 x = flip and x-9 or x-8--flip and x-5 or x
 if blinking and tick % 4 > 1 then
  pal(hurt and 4 or 7,8)
 end
 if not on_water then
  spr(player_body[s],x+4,y,2,1,flip) -- body
  local f = get_frame(player_feet[s],not mov)
  spr(f,flip and x+9 or x+7,y+8,1,1,flip) -- legs
 else
  spr(player_body[s],x+4,y+2,2,1,flip) -- body
 end
 if blinking then
  pal(0)
 end
end

function has_tile_flag(tx,ty,flag)
 return fget(mget(tx,ty),flag)
end

function add_anim(anim, arg, arg2)
 return add_coroutine(anims, anim, arg, arg2)
end

function add_bq(routine, arg, arg2)
 return add_coroutine(bq, routine, arg, arg2)
end

function add_coroutine(arr, routine, arg, arg2)
 return add(arr, cocreate(function () routine(arg, arg2) end))
end

function co_seq(sequence, start_after)
 local seq={}
 for a in all(sequence) do add(seq,cocreate(a)) end
 return function()
  for i=0,(start_after or 0) do
   yield()
  end
  while #seq>0 do
   local a=seq[1]
   if costatus(a)~="dead" then
    coresume(a)
    yield()
   else
    del(seq,a)
   end
  end
 end
end

function fix_mob_positions()
  for mob in all(mobs) do
    put_entity_at(mob.tx,mob.ty,mob)
  end
end

function move_player(dir)
 sfx(4)
 previous_combo=combo
 local bounce=false
 local ptx,pty=player.tx,player.ty
 local ntx,nty= player.tx-dirx[dir],player.ty-diry[dir]

 local mob = entity_at(ntx,nty)
 mob = mob != nil and mob.d == 0 and mob or nil
 local crushable_tile=is_tile_crushable(ntx,nty)
 player.sel_dir=dir
 if dir<3 then
  player.flip=dir==2
 end 
 if energy < 1 and (
   mob or crushable_tile
 ) then
  -- out of energy
  player.hurt=true
  sfx(24)
  return add_bq(
    co_seq({
      show_message('out of energy', 20),
      function() player.hurt=false end
    })
  )
 end
 local animation = {}
 if mob and mob.hp > 0 then
  -- bounce against building
  mob.hp-=1
  add(animation, do_bounce(player, ptx*8,pty*8,ntx*8,nty*8))
 else
  -- go!
  add(animation, do_move(player, ptx*8, pty*8, ntx*8, nty*8, 8, true))
 end

 check_and_kill(ntx,nty,false)

 queue_ai_turn()
 add_bq(co_seq(animation))
 add_anim(co_seq({
  function ()
   if   
    (has_tile_flag(ptx,pty,7) and not has_tile_flag(ntx,nty,7)) or
    (not has_tile_flag(ptx,pty,7) and has_tile_flag(ntx,nty,7))
   then
    sfx(32)
    add_splash(ptx*8,pty*8+4)
   end
  end
 },4))
end

function is_tile_crushable(tx,ty)
 return fget(mget(tx,ty),6)
end

function kill_tile(ntx,nty,free_energy)
 if not is_tile_crushable(ntx,nty) then return end
 sfx(8)
 combo+=1
 add_anim(function()
  add_splash(ntx*8,nty*8)
  local p=25
  if mget(ntx,nty) >= 5 then -- goal tile is a house or tree
    -- crush a house
    buildings_killed+=1
    mset(ntx,nty,rndint(80,95))
    p=50
    add_smoke(ntx*8,nty*8+4)
    shake+=1
  else
    trees_killed+=1
    mset(ntx,nty,4)
  end
  if not free_energy then energy=max(0,energy-1) end
  add_xp_points(p,{x=ntx*8,y=nty*8})
 end)
end

function kill_mob(mob, free_energy)
  if mob.d != 0 then return end
  sfx(8)
  del(mobs,mob) -- remove before ai turn
  get_points_from(mob)
  add_anim(function()
    mob.destroy(mob)
  end) 
  if not free_energy then energy=max(0,energy-1) end
end

function queue_ai_turn(is_blocking)
 local a = is_blocking and add_bq or add_anim
 a(co_seq({spawn_mob, move_mobs},5))
 turns+=1
 if previous_combo == combo then
  combo=0
 end
 if poison > 0 then
  add_bq(poison_player)
 end
end

function poison_player()
 message="kaiju is poisoned"
 player.blinking,player.hurt = true,true
 local damage = poison*-1
 add_float(damage,player.x+4,player.y,8)
 hp+=damage
 for i=1,20 do
  yield()
 end
 player.blinking,player.hurt=false,false
 message=nil
end

function do_move(entity, from_x, from_y, to_x, to_y, frames, do_calc_tile)
 if do_calc_tile then
  entity.tx,entity.ty=flr(to_x/8),flr(to_y/8)
 end
 return function()
  entity.mov=true
  for i=0,frames do
   local t = i/frames
   entity.x,entity.y=lerp(from_x,to_x,t),lerp(from_y,to_y,t)
   center_on_player()
   yield()
  end
  entity.x,entity.y=to_x,to_y
  entity.mov=false
 end
end

function do_bounce(entity, from_x, from_y, to_x, to_y)
 return function()
  entity.mov=true
 local t
  for i=0,4 do
   t = i/8
   entity.x,entity.y=lerp(from_x,to_x,t),lerp(from_y,to_y,t)
   yield()
  end
  entity.hurt=true
  for i=0,8 do
   t = (8+i)/16
   entity.x,entity.y=lerp(to_x,from_x,t),lerp(to_y,from_y,t)
   yield()
  end
  entity.mov=false
  entity.hurt=false
 end
end

function show_message(text, frames)
  return function ()
    message=text
    for i=0,frames do
      yield()
    end
    message=nil
  end
end

function move_mobs()
 for mob in all(mobs) do
  mob.has_moved=false
 end
 -- do a quick shortest path from the player
 -- run ai on mobs who are found during this process 
 local next,visited={{player.tx,player.ty,0,0}},{}
 local iter=0
 while #next > 0 and iter < 200 do
  iter+=1
  qsort(next, function(a,b) return b[4] > a[4] end)
  local n = deli(next,1)
  local x,y=n[1],n[2]
  visited[as_key(x,y)]=n
  for i=1,4 do 
    local nx,ny=x+dirx[i],y+diry[i]
    if visited[as_key(nx,ny)] == nil and has_tile_flag(x,y,1) then
     local mob = entity_at(nx,ny)
     if mob and mob.tick and not mob.has_moved then
      mob.tick(mob)
     end
     if has_tile_flag(nx,ny,1) and
        nx >= 0 and nx <= map_size_x and ny >= 0 and ny <= map_size_y 
     then
      move_map[as_key(x,y)]=n
      add(next,{nx,ny,i,n[4]+1})
     end
    end
  end
 end
 for mob in all(mobs) do
  if mob.tick and not mob.has_moved then mob.tick(mob) end
 end
end

function as_key(tx,ty)
 return tx..":"..ty
end
function entity_at(tx,ty)
 return tiledata[as_key(tx,ty)]
end
function put_entity_at(tx,ty,entity)
  tiledata[as_key(tx,ty)]=entity
end
function remove_entity(e)
 del(entities,e)
 put_entity_at(e.tx,e.ty,nil)
end
function remove_mob(mob)
 if mob.group then
  del(mob.group,mob)
 end
 del(mobs, mob)
 remove_entity(mob)
end

function spawn_mob()
 --debug[2]=#mob_civ.." "..#mob_cop.." "..#mob_tank
 -- spawn every second turn
 if turns % 2 > 0 then return end

 local roads,map_edges={},{}
 for x=max(0,player.tx-10),min(map_size_x,player.tx+10) do
  for y=1,map_size_y-1 do
   if y==player.y and x==player.x then break end
   if has_tile_flag(x,y,1) and entity_at(x,y) == nil then
    local road={x=x,y=y}
    if y==1 or y==map_size_y-1 then
     add(map_edges,road)
    else
     add(roads,road)
    end
   end
  end
 end
 shuffle(roads)
 shuffle(map_edges)

 local multiplier=ceil((buildings_killed+mobs_killed+trees_killed)/60)

 -- spawn civvies
 if #mob_civ<5*multiplier then
  mob=create_mob("people",mob_civ,roads[1],draw_civilian)
  mob.passive = true
 else
  -- secretly despawn civvies far away
  for civ in all(mob_civ) do
    if (dist(civ,player) > 10) remove_mob(civ)
  end
 end
 
 if (not music_started) return
 local edge,mob=map_edges[1]
 if maybe() and #mob_cop < multiplier*2 then
  create_mob("cop car",mob_cop,edge,draw_cop)
 elseif buildings_killed>20 and maybe() and #mob_heli < multiplier then
  mob = create_mob("copter",mob_heli,edge,draw_heli)
  mob.flying=true
 elseif buildings_killed>40 and maybe() and #mob_tank < (multiplier*2) then
  mob=create_mob("tank",mob_tank,edge,draw_tank)
  mob.str = 2
  mob.range = 5
  mob.points = 300
 elseif buildings_killed > 80 and #mob_mad < 1 then
  mob=create_mob("mad scientist",mob_mad,edge,draw_mad)
  mob.flying = true
  mob.str = 2
  mob.poison = 1
  range = 2
  mob.points = 800
 end
end

function create_mob(label,group,point,draw)
 local x,y=point.x,point.y
 local mob = {
  label=label,
  group=group,
  tx=x,
  ty=y,
  x=x*8,
  y=y*8,
  hp=0,
  dir=1,
  str=1,
  d=0,
  tick=tick_ai,
  destroy=destroy_simple_mob,
  points=150,
  range=1.5,
  draw=draw
 }
 put_entity_at(x,y,mob)
 add(entities,add(mob.group,add(mobs,mob)))
 return mob
end

function destroy_simple_mob(mob)
 mobs_killed+=1
 shake+=3
 add_splash(mob.x,mob.y+4)
 remove_mob(mob)
end
function get_points_from(entity)
 if entity.d and entity.d>0 then return end
 if entity.points then
  combo+=1
  add_xp_points(entity.points,entity)
 end
end
function add_xp_points(p,coords)
  p*=combo
  coords=coords or player
  add_float(p,coords.x+4,coords.y,7)
  xp += p >> 16
end

function add_building(x,y,h)
 local building = {
  x=x*8,
  y=y*8,
  tx=x,ty=y,
  h=h or 8,
  draw=draw_building,
  roof=rndint(96,106),
  wall=rndint(112,122),
  update=update_building,
  destroy=destroy_building,
  points=200+((h-5)*100),
  d=0,
  hp=1,
 }

 put_entity_at(x,y,building)
 mset(x,y,rndint(80,95))
 add(entities, building)
end
function destroy_building(b)
 if b.d != 0 then return end
 shake=7
 b.d=1
 buildings_killed+=1
 b.particles = {}
 for i=1,5 do
  add(b.particles, {
   x=i+b.x,
   py=rndint(1,5),
   radius=2,
   pattern=rnd(smoke_patterns),
   col=rnd(cols)
  })
 end
end
function update_building(b)
 if b.d>0 then
  b.h*=0.9
 end
 for p in all(b.particles) do
  p.py=(p.py+0.5)%5
  p.y=b.y-p.py+6
 end
 if b.h <= 0.1 then
  add_smoke(b.x,b.y)
  remove_entity(b)
 end
end
function draw_building(b)
 if (b.hp == 0) then
  pal(5,3)
 end
 for i=1,ceil(b.h/8) do
  spr(b.wall,b.x,b.y-((i-1)*8))
 end
 spr(b.roof,b.x,b.y-b.h+b.d)
 pal(0)
 if b.particles then draw_particles(b) end
end

function draw_civilian(civilian)
 spr(get_frame{34,34,35,35}, civilian.x, civilian.y)
end
function draw_cop(cop)
 spr(get_frame(cop.dir > 2 and {22,23} or {20,21}), cop.x, cop.y,1,1,true,cop.flip)
end
function bob() return abs(sin(t()*0.2)*2) end
function draw_heli(heli)
 spr(
   get_frame{42,43},
   heli.x,heli.y-2-bob(),1,1,heli.dir%2==0,
   heli.flip
 )
end
function draw_mad(mad)
  spr(
    get_frame{28,29},
    mad.x,mad.y-2-bob(),1,1,mad.dir%2==0,
    mad.flip
  )
end
function draw_tank(tank)
 spr(23+tank.dir,tank.x,tank.y,1,1,false,tank.flip)
end

function can_ai_shoot(entity)
 local distance = dist(entity,player)
 if distance > entity.range then
  return false
 end
 for i=1,(entity.range < 2 and 8 or 4) do
  if check_dir(entity.tx,entity.ty,entity.range,i) then
    return true
  end
 end
 return false
end

function check_dir(sx,sy,range,dir)
 for r=1,range do
  local x,y=sx+(dirx[dir]*r),sy+(diry[dir]*r)
  if entity_at(x,y) != nil or
    is_tile_crushable(x,y) then 
   return false
  end
  if player.tx==x and player.ty==y then
   return true
  end
 end
 return false
end

function tick_ai(entity)
  if entity.passive or entity.has_moved then return end
  -- entity ai
  entity.has_moved=true
  if can_ai_shoot(entity) then
    add_bq(shoot_from_mob, entity, entity.label.." takes a shot")
    return
  end
  local move_tile=move_map[as_key(entity.tx,entity.ty)]
  --debug[1]=move_tile[3]
  local mob = entity_at(entity.tx,entity.ty)
  if move_tile and not entity.flying and (not mob or not mob.has_moved) then
    move_mob(entity,move_tile[3])
    return
  end
  local path=nil
  for i=1,(entity.flying and 8 or 4) do
    local x,y=entity.tx-dirx[i],entity.ty-diry[i]
    local mob = entity_at(x,y)
    if
        not (mob != nil and (mob.draw == draw_building or mob.has_moved))
        and not (x == player.tx and y == player.ty)
        and (has_tile_flag(x,y,1) or entity.flying)
        and (not entity.previous or not (
          entity.previous.x==x and entity.previous.y==y
        ))
    then
      local d=dist(player,{x=x*8,y=y*8})
      if path == nil or (path.d > d and mdist(path, entity.previous) > 0) then
      path = {x=x,y=y,dir=i,d=d}
      end
    end
  end
  entity.previous=path
  if path != nil then
    move_mob(entity,path.dir)
  end
end

function shoot_from_mob(mob, m)
  sfx(23)
  message=m
  local bullet = {x=mob.x,y=mob.y,radius=1,col=8}
  local bullet_emitter = {
    x=mob.x,
    y=128,
    draw=draw_particles,
    particles={bullet}
  }
  add(entities, bullet_emitter)
  local l = 5+(dist(mob,player)*2)
  for i=0,l do
   bullet.x,bullet.y=lerp(mob.x+4,player.x+2,i/l),lerp(mob.y,player.y,i/l)
   yield()
  end
  del(entities, bullet_emitter)
  player.blinking,player.hurt = true,true
  add_float(mob.str*-1,player.x+6,player.y,8)
  hp=max(0,hp-mob.str)
  poison+=mob.poison or 0
  for i=0,30 do yield() end
  message,player.blinking,player.hurt = nil,false,false
end

function move_mob(mob,dir)
  local sx,sy=mob.tx,mob.ty
  local nx,ny=mob.tx-dirx[dir],mob.ty-diry[dir]
  local to_swap = entity_at(nx, ny) or nil
  put_entity_at(sx,sy,to_swap)
  if to_swap then
   to_swap.tx,to_swap.ty=sx,sy
  end
  put_entity_at(nx,ny,mob)
  mob.tx,mob.ty,mob.dir=nx,ny,dir

  return add_anim(function()
    for i=0,7 do
      if to_swap then
       to_swap.has_moved=true
       to_swap.x+=dirx[dir]
       to_swap.y+=diry[dir]
      end
      mob.x-=dirx[dir]
      mob.y-=diry[dir]
      yield()
    end
    if to_swap then
      to_swap.x,to_swap.y=sx*8,sy*8
    end
    mob.x,mob.y=nx*8,ny*8
  end)
end

function perform_throw()
  local x,y,dir=player.x,player.y,player.sel_dir
  local entity=add(entities, {
    x=x,y=y,flip=true,
    dir=dir,draw=in_hand.draw})
  add_bq(function()
    sfx(45)
    local tl=throw_length*4
    local strength_left=throw_strength
    for i=0,tl do
     if strength_left==0 then
      break
     end
     local t=i/tl
     x,y=x-dirx[dir]*2,y-diry[dir]*2
     local b = abs(cos(t))*4
     entity.x=x-2
     entity.y=y-b
     if in_hand.label == "people" and i == 4 then break end
     local tx,ty=flr(x/8),flr(y/8)
     if i%4 == 2 then
      if check_and_kill(tx,ty,true) then
        strength_left-=1
        dir=nextdir[dir]
      elseif tx==player.tx and ty==player.ty and i > 4 then
        add_float("catch",player.x+4,player.y,7)
        del(entities, entity)
        sfx(25)
        return
      end
     end
     if i%4 == 0 and b < 1 then sfx(46) end
     yield()
    end
    sfx(8)
    remove_mob(in_hand)
    in_hand=nil
    abilities[1]="grab"
    destroy_simple_mob(entity)
  end)
  queue_ai_turn(true)
end

function check_and_kill(tx,ty,free_energy)
 local mob,killed = entity_at(tx,ty),false
 
 if mob then
  kill_mob(mob,free_energy)
  killed = true
 end
 if is_tile_crushable(tx,ty) then
  kill_tile(tx,ty,free_energy)
  killed = true
 end
 -- crush road
 local tile = mget(tx,ty)
 if fget(tile) == 2 then
  sfx(47)
  mset(tx,ty,tile+112)
 end
 add_smoke(tx*8,ty*8)
 return killed
end

function add_zap(x,y,dir,length,perform_after)
 local zapper=add(entities,
  {x=x,y=y,tx=x,ty=y,draw=draw_zap}
 )
 shake+=5
 add_bq(function()
  local tl=length*4
  for i=1,tl do
   local t=i/tl
   zapper.tx,zapper.ty=x+4-(dirx[dir]*length*t*8),y+4-(diry[dir]*length*t*8)
   if i%4==0 then
    check_and_kill(flr(zapper.tx/8),flr(zapper.ty/8),true)
   end
   yield()
  end
  del(entities,zapper)
  if perform_after then perform_after() end
 end)
end
function draw_zap(zapper)
  line(
    zapper.x+4,
    zapper.y,
    zapper.tx,
    zapper.ty,
    rnd(split("1,6,7,8,8,8"))
  )
end

function add_smoke(x,y)
 local emitter = add(entities, {x=x,y=y,type="smoke",draw=draw_particles,particles={}})
 local end_turn = turns+5
 add_anim(function()
  for i=0,10 do
   add(emitter.particles, {x=x+rndint(0,4),y=y+rndint(0,5),col=rnd(cols),radius=0,pattern=rnd(smoke_patterns)})
  end
  while end_turn > turns do
   for p in all(emitter.particles) do
     p.y-=0.5
     p.radius *= 0.98
     if p.y < y-10 then
      p.y=y
      p.radius=2
     end
   end
   yield()
  end
  del(entities, emitter)
 end)
end

function add_splash(x,y)
 local emitter = {x=x,y=y,type="splash",draw=draw_particles,particles={}}
 add(entities, emitter)
 add_anim(function ()
  for i=0,20 do
   add(emitter.particles, {x=x,y=y,dx=rnd(2)-1,dy=-1-rnd(3),col=rnd(cols),radius=rnd(1.1)})
  end
  while #emitter.particles > 0 do
   for p in all(emitter.particles) do
    p.dy+=0.4
    p.x+=p.dx
    p.y+=p.dy
    if p.y>y then
     del(emitter.particles, p)
    end
   end
   yield()
  end
  del(entities, emitter)
 end)
end

function draw_particles(emitter)
 for p in all(emitter.particles) do
  fillp(p.pattern)
  circfill(p.x,p.y,p.radius,p.col)
  fillp()
 end
end

function center_on_player()
  if player==nil then return end
  xoff=mid(0,
     flr(player.x-60),
     (map_size_x*8)-120
    )
end
function center_camera()
  camera(
   xoff,
   flr(sin(t()*7)*shake)
  )
end

function get_frame(frames,paused)
 if paused then
  return frames[1]
 end
 return frames[
  1 + flr((tick*0.25) % (#frames))
 ]
end

function update_game()
 zsort_entities()
 for entity in all(entities) do
  if entity.update then entity.update(entity) end
 end
 if #bq>0 then
  local e=bq[1]
  if costatus(e) != "dead" then
    if not coresume(e) then
      del(bq, e)
    end
  else
    del(bq, e)
  end
  if #bq > 0 then
    return
  end
 end
 if not procgen and not player and btn(4) then
  -- spawning player
  spawn_player(8,56)
  --music(10,1000)
 end
 if not music_started and (player and player.tx>10 or buildings_killed >= 2) then
  music(12,100)
  music_started=true
 end
 if not player or player.hurt then
  return
 end
 if hp <= 0 then
  start_game_over()
  sfx(44)
  return
 end
 if xp >= next_level_up then
  start_level_screen()
  return
 end
 if btn()>0 then fix_mob_positions() end
 if btn(4) then
  sfx(3)
  previous_combo=combo
  add_roar()
  queue_ai_turn(true)
  return 
 end
 if btn(5) then
  return start_ability_menu()
 end
 for i=1,4 do
  if btn(i-1) then
   local nx,ny = player.tx-dirx[i], player.ty-diry[i]
   if nx >= 0 and
      nx <= map_size_x-1 and
      ny >= 1 and
      ny <= map_size_y-1
   then
    move_player(i)
    break
   end
  end
 end
end

function start_level_screen()
  _drw=draw_level_screen
  next_level_up,level_screen_fade,selected_powerup,powerups=
   next_level_up+(next_level_up*(next_level_up <= 0x0000.2710 and 2 or 1)),0,1,{}
  local abils = shuffle(abilities_to_level)
  for i=1,min(3,#abils) do
    add(powerups,abils[i])
  end
  -- add to test
  --add(powerups,"zap_up")
  if #powerups < 3 then
   add(powerups,"skip")
  end

  add_bq(function ()
   for i=0,8 do 
    level_screen_fade=(i+1)/8
    yield()
   end
   level_screen_fade=1
   _upd=update_level_screen
  end)
end

function exit_level_screen()
  level_ups+=1
  add_anim(function ()
   for i=0,8 do 
    level_screen_fade=1-((i+1)/8)
    yield()
   end
   level_screen_fade=0
   local p_key = powerups[selected_powerup]
   powerup_perform[p_key]()
   _upd,_drw=update_game,draw_game
  end)
end

function update_level_screen()
  if level_screen_fade < 1 then return end
  if btnp(3) then
    sfx(5)
    selected_powerup=mid(1,#powerups,selected_powerup+1)
  elseif btnp(2) then
    sfx(5)
    selected_powerup=mid(1,#powerups,selected_powerup-1)
  elseif btn(5) then
    sfx(6)
    exit_level_screen()
  end
end

powerup_data={
 hp_up=split("hp up,increases max hp by 5"),
 regen_up=split("hp regen up,increases hp regeneration\nper roar by 1"),
 energy_up=split("energy up,increases max energy by 5"),
 zap=split("zap,shoot laser from your eyes\nagainst enemies along a\ncolumn or row\n\nrange: 5"),
 zap_up=split("zap range up,increases zap range by\n1 tile"),
 --throw=split("throw,throws heavy objects in\nyour hand with each hit\nturning thrown object ccw\n\nrange: 10"),
 throw_up=split("throw str up,throw will hit another mob\nor building and turn\ndirection counterclockwise\n\n...like a boomerang"),
 skip=split("skip,skips this powerup")
}
powerup_perform={
  hp_up=function()
   max_hp+=5
   hp=hp+5
   if max_hp == 20 then del(abilities_to_level,"hp_up") end
  end,
  regen_up=function()
    regen+=1
    if regen == 5 then del(abilities_to_level,"regen") end
  end,
  energy_up=function()
    max_energy+=5
    energy=energy+5
    if max_energy == 20 then del(abilities_to_level,"energy_up") end
  end,
  zap=function() enable_ability("zap","zap_up") end,
  zap_up=function() zap_range+=1 end,
  --[[
  throw=function() enable_ability("throw","throw_up") end,
  ]]
  throw_up=function() throw_strength+=1 end,
  skip=function() end
}
function enable_ability(id,to_add)
  add(abilities,id)
  del(abilities_to_level,id)
  if to_add then add(abilities_to_level,to_add) end
end
function draw_level_screen()
  draw_game()
  local y=min(119,lerp(5,119,level_screen_fade))
  local ky=lerp(-16,4,level_screen_fade)
  clip(0,0,128,y+1)
  rectfill(5,8,122,y,0)
  rect(5,8,122,y,7)
  pal(8,2)
  spr(128,38,ky+1,6,2)
  pal(0)
  spr(128,38,ky,6,2)
  if level_screen_fade >= 1 then
   print_cs('level up',10,7,5)
  end
  print_cs('select a power up',25,7,2)
  print_cs('confirm with ❎',31,6,2)
  for i,p in pairs(powerups) do
   local is_selected=i==selected_powerup
   local powerup = powerup_data[powerups[i]]
   print((is_selected and "●" or "  ")..powerup[1],20,40+(i*8),is_selected and 8 or 7)
  end
  print(powerup_data[powerups[selected_powerup]][2],10,80,6)
end

function start_ability_menu()
  sfx(6)
  _drw=draw_ability_menu
  ability_fade,selected=0,1
  add_bq(function ()
    ability_fade=0
    for i=0,4 do
      local t=(i+1)/5
      ability_fade=lerp(0,103,t)
      xoff=mid(0,map_size_x*8-32,flr(lerp(player.x-58,player.x-32,t)))
      yield()
    end
    _upd=update_ability_menu
  end)
end

function update_ability_menu()
  if ability_fade < 103 then return end
  if btnp(3) then
    sfx(5)
    selected=mid(1,selected+1,#abilities)
  elseif btnp(2) then
    sfx(5)
    selected=mid(1,selected-1,#abilities)
  elseif btnp(4) then
   -- exit
   sfx(7)
   exit_ability_menu()
  elseif btnp(5) then
   -- selected ability
   sfx(6)
   local a = ability_map[abilities[selected]]
   if not can_use_ability(a) then
    return
   end
   if a.skip_selection then
    handle_selected_ability()
   else
    _upd=update_select_direction
   end
  end
end

function update_select_direction()
 for i=1,4 do
  if btnp(i-1) then
    sfx(5)
   player.sel_dir=i
   if i==1 then
    player.flip=false
   elseif i==2 then 
    player.flip=true
   end
  end
 end
 if btnp(4) then
  -- go back
  sfx(7)
  _upd=update_ability_menu
 elseif btnp(5) then
  sfx(6)
  handle_selected_ability()
 end
end

function handle_selected_ability()
  previous_combo = combo
  local a = ability_map[abilities[selected]]
  if a.cost then
    energy=max(0,energy-a.cost)
  end
  add_anim(a.perform,
    player.tx-dirx[player.sel_dir],
    player.ty-diry[player.sel_dir]
  )
  exit_ability_menu()
end

function exit_ability_menu()
  _upd=update_game
  add_bq(function ()
    for i=0,8 do
      local t=(i+1)/8
      ability_fade=lerp(103,0,t)
      xoff=mid(0,map_size_x*8-120,flr(lerp(player.x-32,player.x-58,t)))
      yield()
    end
    center_on_player()
    _drw=draw_game
  end)
end

ability_map={
  chomp={
    perform=function()
      message="chomps "..in_hand.label.." +5 ENERGY"
      local ct=rnd(split("chomp,crunch"))
      shake+=7
      add_float(
       ct,
       player.x+4,
       player.y-8,
       7
      )
      add_splash(player.x,player.y+4)
      sfx(26)
      abilities[1],in_hand.x,in_hand.y="grab",player.x,player.y
      get_points_from(in_hand)
      destroy_simple_mob(in_hand)
      in_hand=nil
      energy=min(max_energy,energy+5)
      for i=0,10 do yield() end
      queue_ai_turn()
      for i=0,30 do yield() end
      message=nil
    end,
    skip_selection=true
  },
  grab={
    perform=function (tx,ty)
     local mob = entity_at(tx,ty)
     if mob and mob.label then
      abilities[1]="chomp"
      remove_entity(del(mobs,mob))
      in_hand=mob
      add_float(rnd(split("grab,yoink")),player.x+4,player.y,7)
      sfx(25)
      queue_ai_turn()
     else
      message="nothing to grab there"
      sfx(24)
      for i=0,50 do yield() end
      message=nil
     end
    end
  },
  throw={
    cost=1,
    needs_in_hand=true,
    perform=perform_throw
  },
  zap={
    cost=2,
    perform=function()
      add_zap(player.x,player.y,player.sel_dir,zap_range,queue_ai_turn)  
      sfx(27)
    end
  }
}
in_hand=nil
function can_use_ability(ability)
  return not (
    (ability.cost != nil and ability.cost > energy) or
    (ability.needs_in_hand) and in_hand == nil
  )
end
function draw_ability_menu()
  draw_game()
  local h=mid(10,10+ability_fade,113)
  clip(0,9,128,h)
  rectfill(64,10,126,h,1) 
  rect(64,10,126,h,7) 

  if _upd== update_ability_menu then
    print_s("select ability",66,12,7,5)
    for i,a in pairs(abilities) do
      local c = i==selected and 8 or 7
      local cs = i==selected and 2 or 4
      local ab = ability_map[a]
      local cost = ab.cost
      local y=8+(14*i)
      if not can_use_ability(ab) then
        c,cs=5,5
      end
      pal(7,c)
      print((i==selected and "●" or "  ")..a,66,y,c)
      local sub=""
      if i==1 then
        sub = in_hand and in_hand.label or "empty handed"
      elseif a=="throw" then
        sub = "hits "..throw_strength.."X"
      elseif a=="zap" then
        sub = zap_range.." tiles"
      end
      print(sub,74,y+6,cs)
      if cost then
        print("\^:04020f0402000000"..cost,113,y,c)
      end
      pal(0)
    end
    --print("HP/ROAR:+"..regen,66,89,6)
    print_s("🅾️EXIT ❎SELECT",66,106,7,1)
  elseif _upd==update_select_direction then
    print_s("select a tile\nto "..abilities[selected],66,12,7,5)
    print_s("🅾️BACK ❎SELECT",66,106,7,1)
  end
  clip()
end

-->8
-- utils
function qsort(a,c,l,r)
    c,l,r=c or ascending,l or 1,r or #a
    if l<r then
        if c(a[r],a[l]) then
            a[l],a[r]=a[r],a[l]
        end
        local lp,rp,k,p,q=l+1,r-1,l+1,a[l],a[r]
        while k<=rp do
            if c(a[k],p) then
                a[k],a[lp]=a[lp],a[k]
                lp+=1
            elseif not c(a[k],q) then
                while c(q,a[rp]) and k<rp do
                    rp-=1
                end
                a[k],a[rp]=a[rp],a[k]
                rp-=1
                if c(a[k],p) then
                    a[k],a[lp]=a[lp],a[k]
                    lp+=1
                end
            end
            k+=1
        end
        lp-=1
        rp+=1
        a[l],a[lp]=a[lp],a[l]
        a[r],a[rp]=a[rp],a[r]
        qsort(a,c,l,lp-1       )
        qsort(a,c,  lp+1,rp-1  )
        qsort(a,c,       rp+1,r)
    end
end

function zcomp(a,b) 
 --print(a.type,0,0,6)
 --assert(a.y != nil)
 --assert(b.y != nil)
 if a.y == b.y then return b == player end
 return a.y < b.y 
end

function zsort_entities() qsort(entities, zcomp) end

function distcomp(a,b)
 return a.d < b.d
end

function tilesig(x,y,flag)
 local sig,digit=0
 for i=1,4 do
  local dx,dy=x-dirx[i],y-diry[i]
  --★
  if dx < 0 or dx > map_size_x or dy < 0 or dy > map_size_y then
   digit=1
  else
   digit = fget(mget(dx,dy),flag) and 1 or 0
  end
  sig|=digit<<i-1
 end
 return sig
end

function shuffle(t)
  -- fisher-yates
  for i=#t,1,-1 do
    local j=flr(rnd(i)) + 1
    t[i],t[j] = t[j],t[i]
  end
  return t
end

function dist(e1,e2)
  local dx,dy=(e1.x-e2.x)/8,(e1.y-e2.y)/8
  return sqrt((dx*dx)+(dy*dy))
end

function mdist(e1,e2)
  if e1 == nil or e2 == nil then
    return 9999
  end
  local dx,dy=(e1.x-e2.x),(e1.y-e2.y)
  return abs(dx)+abs(dy)
end

function lerp(
  a, -- target
  b, -- source
  t  -- percent 0.0-1.0
)
 return (1-t)*a + t*b
end

function get_score(points)
  return tostr(points,0x2)
end

function maybe(chance)
 return rnd(1) <= (chance or 0.5)
end
