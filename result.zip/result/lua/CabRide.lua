-- cab ride
-- by ben jones/@powersaurus
-- music by stephen 'rych-t' jones/@rych-t
--
-- project based on code from 
-- tom mulgrew's/@mot tutorial
-- https://www.lexaloffle.com/bbs/?tid=35767
-- used under cc4-by-nc-sa
-- see https://creativecommons.org/licenses/by-nc-sa/4.0/
-- for more

local building_c,building_c2,
 building_h,
 offset=
 split("5,6,2"), --{4,15,5,12}
 split("4,15,5,12"),
 split("21.5,16.1,10.7,12.5,19.7,12.5,16.1,10.7"),
 split("0.1,1.5,0.25,0.4,0.2,0.8,0.25,0.7,2,0.6,1.1,0.8,3,0.3,0.25,2.5,1.75")

s_sfx,s_music,nil_func=
 sfx,music,function()end

function _init()
 o_rnd_vals,
 o_rnd_ptr=
  {},1

 s_o_rnd()
 
 show_title,
 sound_on,
 only_slightly_chill,
 infinite,
 auto,
 seed=
  true,true,true,true,false,
  frnd(300)--snake eats itself
 
 music(0,1000)
 init_palette_2()
 init_everything()
 
-- _update=update_foo
-- _draw=d_building
 menuitem(1,"toggle sound",function()
  -- yuck
  sound_on=not sound_on
  music(-1)
  music,sfx=nil_func,nil_func
  if sound_on then
   music,sfx=s_music,s_sfx
  end
 end)
end


--126 tokens

 scale=5
 px,py=64,96
 widthb,height=2.3*2,12
 cs={5,6,2}
 colour=13
 
function update_foo()
 time_of_day=2
 srand(time())
 if btnp(❎) then
  scale=2+rnd(6)
  widthb,height=
  --2.3 works nicely for one window
   2.3*(3+frnd(4)),--1.95*(6+frnd(2)),
   3.5+1.8*(3+frnd(6))
--  px,py=64-width/2,64+height/2
  px,py=32,96+height/2
  colour=13--building_c[1+frnd(3)]
 end
end

function d_building()
 cur_clip={0,0,128,128}

-- colour=12
 sprites={}
 
 cls(1)
 building(
  px,py,
  widthb,scale,
  colour,
  height,
  cur_clip,sprites,true)
 
 passenger(
   1,
   px-10,py,0,scale,
   cur_clip,false,sprites)
   
 foreach(sprites,function(s) 
 s()
 end)
end
--]]
function building(
 px,py,
 width,scale,
 colour,
 height,
 cur_clip,sprites,w)
 local s4=scale/8
 
 add(sprites,function()
  set_clip(cur_clip)
  set_palette(time_of_day,5)
  rectfill(
   px,
   py-height*scale,
   px+width*scale,
   py,colour)

  if w then
   local hscale=scale
   if(width<0)hscale=-scale
  
   local wx=px+.8*hscale

   for y=0,flr(height/1.8)-2 do
    for x=0,flr(abs(width)/2.4) do
     if x==0 or x%3~=0 then
     local w_c,win_width=5,.7
     for i=0,0.3,0.3 do
      rectfill(
       wx+(x*2.3)*hscale,
       py-(i+y*2+3)*scale,
       wx+(x*2.3+win_width)*hscale,
       py-(i+y*2+2.2)*scale,
       w_c)
      if time_of_day>=2 then
       w_c=4+((height+y%x)%3)*5
      else
       w_c=12
      end
     end
     end
    end
   end--]]
  end
 end)
end


function init_everything()

 srand(seed)

 -- camz never more than 1
 -- corrupts state if so
 -- update_camera moves along
 -- track when camz>1
 -- use camslice to move within a seg

 camcnr,camslice,
 camx,camy,camz,
 world_ang,
 vel,
 throttle,
 throttle_vis_timer,
 stops_in_seg,
 doors_open,
 passengers,
 boarding,
 disembarking,
 passenger_x,
 last_stop,
 journey_over,
 journey_over_timer,
 auto_timer,
 stops,
 total_score,
 accelerate_tutorial,
 brake_tutorial,
 doors_tutorial,
 journeys_completed,
 signals_obeyed,
 total_signals,
 timer,time_in_seg,
 hours,minutes,seconds,
 ot_seg,ot_end_seg,
 ot_slice,ot_end_slice,ot_z,ot_vel,
 current_note,
 note_len,
 area,
 skx,
 active_palette,last_i,
 build_tracks,
 build_h,
 goal_msg,status_msg=
  1,9,
  0,0,0.3,0,0.0,0,0,0,
  false,{},{},{},
  0,--passenger_x
  false,false,0,0,0,0,0,0,0,0,0,0,0,0,
  o_rnd(24),0,0,--time
  -1,-1,-1,-1,0,0.04,
  -1,0,
  frnd(2),
  0,
  nil,nil,--sky
  frnd(2)+1,--build_tracks
  frnd(6)+3,--build_h
  new_message(64,64,true),
  new_message(19,115,false)

 build_area=area
 
 set_weather()
 
 --hours=12
 set_time_of_day()
 
 init_palette()
 poke(0x5f2e,1)

 track,stations=generate_track()

 generate_terrain()
 generate_city()

 curseg=track[camcnr]
 
 status_msg.cy=-16
 
 status_msg.set_message_with_cat=function(s,m,t,f)
  
  local not_already_there=true
  foreach(s.msgs,function(i)
   if(i.m==m)not_already_there=false
  end)
  if f
  or not_already_there then
   s:set_message(m,t,f)
   sfx(63,0)
   s.cy=s.y+12
  end
 end
 
 status_msg.draw_with_cat=function(s)
  s:draw()
  if #s.msgs>0 then
   spr(174,s.x-19,s.cy,2,2)
  end
 end
 
 status_msg.update_with_cat=function(s)
  s:update()
  if #s.msgs==0 then
   s.cy+=4
  elseif s.cy>s.y-2 then
   s.cy-=4
  end
 end
 
end

function advance(cnr,slice)
 slice+=1
 if slice>track[cnr].len then
  slice=1
  cnr+=1
  -- this will break
  -- if you go past the 
  -- end of the line, should
  -- never happen 
 end
 return cnr,slice
end

function _update()
 tick(8)

 update_controls()
 
 update_camera()
 
 status_msg:update_with_cat()
 goal_msg:update()
 
 update_train()
 update_music()
end

function tunnel_rect(px,py,scale,tracks)
 local w,h=6*scale,4*scale
 local x1,y1=
  ceil(px-w/2),
  ceil(py-h)
 if(tracks==2)w+=4*scale
 local x2,y2=
  ceil(px+w/2),
  ceil(py-1)
 return x1,y1,x2,y2
end

function clip_to_tunnel(px,py,scale,tracks,clp)
 local x1,y1,x2,y2=tunnel_rect(px,py,scale,tracks)
 clp[1],clp[2],clp[3]=
  max(clp[1],x1),
  max(clp[2],y1),
  min(clp[3],x2)
 -- don't think i need this with no slopes
-- clp[4]=min(clp[4],y2)
 return {clp[1],clp[2],clp[3],clp[4]}
end

--[[
 1=x start
 2=y start
 3=x end
 4=y end
]]
function set_clip(clp)
 clip(
  clp[1],
  clp[2],
  clp[3]-clp[1],
  clp[4]-clp[2])
end

function _draw()

-- clip()

 set_palette(time_of_day,7)
 
 --sky
 background()

 local camang=camz*curseg.tu
 local x,y,z=-(camx+camz*-camang),-camy+2,-camz+2
 local cnr,slice=camcnr,camslice
 local ppx,ppy,pscale=project(x,y,z)
 local prev_typ,typ,prev_underground,
  prev_pcnt_in_seg,
  cliprect,col,last_ground,
  sprites,
  cur_tnl_clip,ot_start,ot_end=
  -1,-1,false,(slice-1)/track[cnr].len,
  {0,0,128,128},
  {2,12},
  128,
  {},
  nil,
  ot_seg+ot_slice/100,
  ot_end_seg+ot_end_slice/100

 for i=1,30 do
  local r=track[cnr]
  local tx,ty,
  c,tracks,pcnt_in_seg,typ,
  pal_index
  =
   r.tx or 0,
   r.ty or 0,
   col[(slice*1)%2+1],
   r.tracks,
   slice/r.len,
   r.typ,
   time_of_day
  
  x-=camang
  z+=1
  
  local px,py,scale=project(x,y,z)
 
  local width,r_width,pwidth,pr_width,s4=
   3*scale,3*scale,3*pscale,3*pscale,scale/4
  if tracks==2 then
   r_width,pr_width=
    5*scale,5*pscale
  end
  
  if typ~=prev_typ then
   if typ==3 then
    local face_colour=nil
    if(prev_underground)face_colour=1
    draw_tunnel_face(ppx,ppy,r.start_h,pscale,face_colour,r.tracks)
    cur_tnl_clip=clip_to_tunnel(ppx,ppy,pscale,tracks,cliprect)
    set_clip(cliprect)
   end
   if typ==8 then
    last_ground=ppy
   end
  end

  if typ==3 then
   pal_index=99
  end
  set_palette(pal_index,i)
  draw_ground(py,ppy,px,slice,r,scale)
   
  if (r.station and r.underground)
  or typ==3 then--tunnel
   draw_tunnel(px,py,ppx,ppy,scale,pscale,i,slice,typ,tracks)
  end

  -- track
  if (typ<98 and typ~=8)
  or (typ==98 and slice<3) then    
   --7858 to beat
   draw_track(px,py,
    width,
    ppx,ppy,pwidth,
    scale,pscale,
    tx,ty,tracks,
    pcnt_in_seg,prev_pcnt_in_seg,
    r.points)
  end

  local cur_clip={
    cliprect[1],
    cliprect[2],
    cliprect[3],
    cliprect[4]
   }
  -- scenery
  if typ==0 or typ==5 then
   trackside(
    r,slice,
    px,py,
    c,width,r_width,
    scale,
    cur_clip,sprites)
  elseif r.station then   

   --7095 to beat	, 7082 now,6984 now
   station_stuff(
    px,py,ppx,ppy,width,r_width,
    scale,pscale,
    typ==1,r,slice,
    c,
    cur_clip,sprites
   )
  elseif typ==4 then--level crossing
   local sgn_width,sgn_pwidth=
    width*1.2,pwidth*1.2
   if slice==r.len-1 then
    thing(32,64,
     px,py,sgn_width,scale,
     cur_clip,sprites,true)
    
    --r
    thing(32,64,
     px,py,r_width*-0.47*tracks,scale,
     cur_clip,sprites,true)
   end
   if slice==1 then
    thing(32,64,
     ppx,ppy,sgn_pwidth,pscale,
     cur_clip,sprites,true)
    --r
    thing(32,64,
     ppx,ppy,pr_width*-0.47*tracks,pscale,
     cur_clip,sprites,true)--]]
   end
  elseif typ==8 then--bridge
   -- dup, this probably needs
   -- to live somewhere at the top of the loop
   local px2,
    ppx2,
    py2,
    ppy2,
    pscale2,
    pwidth2,
    scale2,
    tx2,
    ty2,
    t_slice,
    len,
    start_h,
    cur_last_ground,
    density=
     px,
     ppx,
     py,
     ppy,
     pscale,
     pwidth,
     scale,
     tx,
     ty,
     slice,
     r.len,
     r.base_h,
     last_ground+1,
     r.density

   trackside(
    r,slice,
    px,py+10*scale,
    c,width+scale,r_width+scale,
    scale,
    cur_clip,sprites)
    
   add(sprites,function()
    cur_clip[4]=cur_last_ground
    set_clip(cur_clip)
    set_palette(time_of_day,i)
    -- todo - either arched or flat
    local height=(start_h-abs(t_slice-len/2))/2
    if t_slice%density==0 then
    local bys=py2-pscale2*height
    for z=-1,1,2 do
     local drs=pscale2*z
     local bxs,zps2=
      px2+drs*2,z*pscale2
     if z==1 and tracks==2 then
      bxs+=pscale2*2.5
     end
     local bxe=bxs+zps2*0.75
   
      -- uprights
      rectfill(
       bxs,bys,
       bxs+zps2*0.5,
       py2+pscale2*4,
       2+t_slice%2*3)
      rectfill(
       bxe,bys,
       bxe+zps2*0.5,py2+pscale2*4)
       -- horizontals
      rectfill(
       bxs,bys,
       bxe,py2-pscale2*(height-.3))
     end
    end
    draw_track(px2,py2,
     width,
     ppx2,ppy2,
     pwidth2,
     scale2,pscale2,
     tx2,ty2,tracks)
   end)
  elseif typ==9 then
   building_with_wall(px,py,width,scale,r,1,slice,cur_clip,sprites)
   building_with_wall(px,py,r_width,scale,r,-1,slice,cur_clip,sprites)
  elseif typ==10 then
   local x1,y1,x2,y2=
    tunnel_rect(px,py,scale,tracks)
   local c_slice=slice
   add(sprites,function()
    y1-=scale/2
    local cl,w=1,scale
    rectfill(x1-w,y1-w,x2+w,y1,cl)
    if c_slice%3==0 then
     cl=15
     w*=2
     rectfill(x1-w,y1,x1,y2)
     rectfill(x2,y1,x2+w,y2)
    end
   end)
  elseif typ==98 then
   if slice==1 then
    buffers(
     ppx,ppy,width,scale,
     cur_clip,sprites)
    if r.tracks>1 then
     buffers(
      ppx+3.8*scale,ppy,width,scale,
      cur_clip,sprites)
    end
   elseif slice==4
   or slice==3 then
    -- draw some passengers
    for z=0,30 do
     local dr=1-(4-slice)*2
     local pax=
      24*dr+((z*3.5+timer/z/1.5)%50)*-dr
     passenger(
      (z+slice)%8,
      px,py-o_rnd(2),
      0-pax*scale,scale,
      cur_clip,true,sprites)
    end
   elseif slice==5 then
    add(sprites,function()
     set_clip(cur_clip)
     set_palette(min(time_of_day,2),5)
     rectfill(0,py-6.6*scale,127,py,14)
     
     for z=-8,8 do
      local zx=z*3*scale+px
      rectfill(
       zx,py-5.6*scale,
       zx+2*scale,py,15)
     end
    end)
    
   end
  end
  
  --train
  local draw_idx=cnr+slice/100
  if draw_idx>=ot_start
  and draw_idx<=ot_end
  then
   local ot_x,ot_y,ot_scale=
    project(x,y,z+ot_z)

   local t_slice,ot_s4,
    x1,x2,front_of_train=slice,
    ot_scale/4,
    32,12,
    draw_idx==ot_start

   add(sprites,function()
    set_clip(cur_clip)

    if not front_of_train then
     x1,x2=56,6
    end
    sspr(x1,96,x2*2,32,
     ot_x+2.3*ot_scale,
     ot_y-14*ot_s4,
     x2*ot_s4,16*ot_s4)
    if front_of_train
    and (time_of_day>=2 or raining) then
     local lx,ly=
      ot_x+2.9*ot_scale,
      ot_y-5*ot_s4
     light(lx,ly,7)
     light(lx+1.7*ot_scale,ly,7)
    end
   end)
  end
  
  if (typ~=3 and typ<98)
  and slice%4==0 
  and not r.underground then
   mast(
     px,py,
     width*1.15,scale,s4,
     cur_clip,r.flip_mast 
     and tracks<2 and not r.points,sprites)
   
   if tracks>1 or r.points then
    mast(
     px,py,
     width*3,scale,s4,
     cur_clip,true,sprites)  

   end--]]
   
  end
  
  if typ<98 then
  
   for i=0,tracks-1 do
    cable(
     px+i*2.7*scale,py,
     ppx+i*2.7*pscale,ppy,
     scale,pscale,
     cur_clip,sprites)
   end
  end
  
  if r.has_signal then
   local last=r.len-1
   if slice==last then
    signal(
     px,py,width,scale,r,
     cur_clip,sprites)
   end
  end
  
  --rain
  if typ~=3 
  and i<16	
  and raining then
   local rain_y=timer+slice*4
   for z=0,4 do
    local x1,y1=
     32*z+slice%8*6,
     (z*4+rain_y)*6%128

    add(sprites,function()
     rectfill(
      x1,min(y1-s4,py),
      x1,min(y1,py),
      12)
    end)
   end
  end--]]--endrain
  
  if typ==3 then
   cur_tnl_clip=clip_to_tunnel(px,py,scale,tracks,cliprect)
  elseif r.underground then
   -- yuck yuck yuck yuck
   
   -- you gotta fix those walls!
   
   local x1,y1,x2,y2=tunnel_rect(px,py,scale,tracks)
   cur_tnl_clip={
    max(cliprect[1],x1),
    max(cliprect[2],y1),
    min(cliprect[3],x2),
    128
   }
   if r.typ==1 then
    cliprect[1],cliprect[2]=
     cur_tnl_clip[1],
     cur_tnl_clip[2]
   elseif r.typ==2 then
    cliprect[2],cliprect[3]=
     cur_tnl_clip[2],
     cur_tnl_clip[3]
   end
  else
   cliprect[4]=min(cliprect[4],ceil(py))
  end
  
  set_clip(cliprect)
     
  -- turn
  camang-=track[cnr].tu  
  
  -- move along the track
  cnr,slice=advance(cnr,slice)
  
  -- save last pos
  ppx,ppy,pscale,prev_typ,prev_underground,
  prev_pcnt_in_seg=
   px,py,scale,typ,r.underground,
   pcnt_in_seg
  
  if (prev_pcnt_in_seg>0.99)prev_pcnt_in_seg=0
 end
 
 -- todo bring back if weirdness happens
 --init_palette()
 
 clip()
 
 for i=#sprites,1,-1 do
  sprites[i]()
 end
 clip()
 
 pal()
 init_palette()
 
 if(stopped_at_station and doors_open)draw_passengers(curseg)
 
 status_msg:draw_with_cat()

 if show_title then
  title()
 else

	  
	  -- gamey bits
	  if only_slightly_chill then  
	   goal_msg:draw()
	   spr(255,86,1)
	   draw_clock(96,2)
	   --252
	   local to_next,spr_id=to_next_landmark()
	   nice_print(""..to_next,10,2,7,1)
	   spr(spr_id,1,1)
	   
    if throttle_vis_timer>0 then
     spr(218,110,103,2,3)
     spr(202,110,107+throttle*2,2,1)
    end
	   
	   if journey_over then
  	  nice_print("   you finished line no."..
  	   seed.."!\n\noverall station stop rating "..
  	   score_to_string(total_score/stops)..
  	   "\n\n       stations visited "..
  	   stops.."\n\n          signals "..
  	   (signals_obeyed/max(total_signals,1)*100).."%\n\n     passenger journeys "..journeys_completed+#disembarking,
  	   4,44,7,1)
	   end--journey_over
	  end
	  if journey_over then
	   nice_print("press ❎ to start a new journey",
  	  2,104,7,1)
  	end
	 end 
	
	--nice_print(stat(1),0,10,7,1)
	 --print("cpu: "..time_in_slice,0,0,7)
	
end
	
function title()
	-- palt(11,true)
	 if show_credits then
	  nice_print(--looooong line
	   "            credits\n\n\n    programming and art by\n\n    ben jones/@powersaurus\n\n\n            music by\n\n stephen 'rych-t' jones/@rych_t\n\n\n  code based on original work\n      by tom mulgrew/@mot\n\n      for more details see\n\n  https://powersaurus.itch.io",2,6,7,1)
  return
 end
 if(not show_route)sspr(96,96,32,24,2,2,128,96)
 
 local c_msg="very chilled mode"
 if(only_slightly_chill)c_msg="chilled mode     "
 
 nice_print("⬅️ ride on line no."..seed.." ➡️",17,100,7,15)
 nice_print("❎ to depart, 🅾️ to view",17,110,7,15)
 nice_print("⬆️ "..c_msg.." ⬇️ credits",2,120,7,15)
end

function percent_in_seg(camz,camslice,seg)
 return (camz+camslice-1)/
  seg.len
end

function signal(
 px,py,width,scale,r,
 cur_clip,sprites)
    
 local s4,light_col,light_pos=
  scale/8,8,0

 if r.signal_wait<=0
 and not in_last_seg then
  light_pos,light_col=
   -.4*scale,11
 end
 local lx,ly=
  px-width+scale*0.9,
  light_pos+py-10*s4
  
 add(sprites,function()
  set_clip(cur_clip)



  sspr(16,64,8,16,
   px-width+scale*0.5,py-16*s4,
   8*s4,16*s4)

  light(lx,ly,light_col)
 end)
end

function light(lx,ly,light_col)
 pal(0,light_col)
 fillp(0xa5a5.8)
 circfill(lx,ly,7,0)
 fillp(0)
 circfill(lx,ly,4,0)
 pal(0,0)
end
--6327
function thing(sx,sy,
 px,py,width,scale,
 cur_clip,sprites,unlit)
    
 add(sprites,function()
  set_clip(cur_clip)
  if(unlit)set_palette(1,5)
  local s4=scale/8
  
  sspr(sx,sy,8,16,
   px-width+scale*0.5,py-16*s4,
   8*s4,16*s4)
 end)
end

function passenger(
 s,px,py,
 width,scale,
 cur_clip,flip_h,sprites)
 
 if(flip_h)width*=-0.4
 
 thing(s*8,80,px,py,
  width,scale,
  cur_clip,sprites,true)
end

function buffers(
 px,py,width,scale,
 cur_clip,sprites)
    
 local s4=scale/7.5
 add(sprites,function()
  set_clip(cur_clip)
  sspr(96,64,24,16,
   px-12*s4,py-16*s4,
   24*s4,16*s4)
 end)
end

function cable(
 px,py,ppx,ppy,
 scale,pscale,
 cur_clip,sprites)
 
 add(sprites,function()
  set_clip(cur_clip)
  
  draw_trapezium(
   px-scale*.25,py,0,
   ppx-pscale*.25,ppy,0,
   5,true)
 end)
end

function mast(
 px,py,
 width,scale,s4,
 cur_clip,fliph,sprites)

 -- i am sorry
 local h_offx,flip_off=
  width-scale*0.5,0

 if fliph then
  h_offx*=-0.55
  flip_off=scale*2
 end
 add(sprites,function()
  set_clip(cur_clip)
  
  local x1,y1=
   px-h_offx,py-20*s4
  -- top
  sspr(64,64,24,8,
   x1-flip_off,y1,
   12*s4,scale,fliph)
  rectfill(
   x1+s4*1.5,y1,
   x1+s4*2.3,py,5)
  rectfill(
   x1+s4*1.5,y1,
   x1+s4*1.8,py,15)
 end)
end

function tree(
 px,py,s4,off,
 dr,slice,tree_tex,
 cur_clip,sprites)
 add(sprites,function()
  set_clip(cur_clip)
  set_palette(time_of_day,5)
  sspr(80+16*tree_tex,32,16,32,
   px+dr*offset[1+(slice+off)%#offset]*s4*20,py-31*s4,
   dr*16*s4,32*s4)
  end)
end

function building_with_wall(
 px,py,width,scale,r,
 dr,slice,cur_clip,sprites)
 
 --wall
 
 -- fix maybe? the numbers make
 -- no sense any more
 local wall_w,wall_h,wall_s,wall_c=
  dr*2,5,dr*width*2,r.col[slice%2+1]
 if slice==1 then
  wall_w,wall_h,wall_s,wall_c=
   -dr*25,3,
   dr*width*1.6,
   12
 end
 
 building(px-wall_s,py,
  wall_w,scale,
  wall_c,
  wall_h,
  cur_clip,sprites)--]]
 
 if slice%3==0 then
  -- dup?
   local off=flr(slice/3)
   building(px-dr*width*6,py,
    dr*11.5,scale,
    building_c[1+off%#building_c],
    building_h[1+(dr-off)%#building_h],
    cur_clip,sprites,true)
 end
end

--make cutting only one function plz

function cutting(
 px,py,width,height,
 scale,c,dr,slice,r,
 cur_clip,sprites)
 local s4,d_width=
  scale/4,
  dr*width
 if area==0 then
  add(sprites,function()
   set_clip(cur_clip)
   set_palette(time_of_day,5)
   sspr(32,32,32,32,
    px+d_width*1.3,
    py-(height+1.5)*scale,
    dr*32*s4,
    32*s4*0.5)
   end)
  tree(
   px+d_width+dr*2*scale,
   py-height*scale,
   s4,0,dr,slice,r.tree_tex,
   cur_clip,sprites)
 else
  if slice%3==0 then
   -- dup
   local off=flr(slice/3)
   building(
    px+dr*width*5,py,
    dr*11.5,scale,
    building_c2[1+off%#building_c2],
    building_h[1+off%#building_h],
    cur_clip,sprites,true)
  end
 end
 
 building(px+d_width*1.35,py,
  dr*25,scale,
  c,
  height,
  cur_clip,sprites)
end

function trackside(
 r,slice,
 px,py,c,l_width,r_width,scale,cur_clip,sprites)

   local r_typ,l_typ,pcnt_in_seg,s4=
    r.r_typ,r.l_typ,
    slice/r.len,
    scale/4
   
   if(r.typ==1)r_width*=2.1
   if(r.typ==2)l_width*=2.1
   
   if r_typ==0 then
    tree(px+r_width*r.r_dist,py,
     s4,0,1,slice,r.tree_tex,
     cur_clip,sprites)
   elseif r_typ==5 then
   
    -- dup duuuup
    cutting(
     px,py,
     r_width+lerp(r.start_w_r,r.end_w_r,pcnt_in_seg),
     lerp(r.start_h,r.end_h,pcnt_in_seg),
     scale,c,1,slice,r,
     cur_clip,sprites)
   elseif r_typ==9 then
    building_with_wall(
     px,py,r_width,scale,r,
     -1,slice,cur_clip,sprites)
   end
   
   if l_typ==0 then
    tree(px-l_width*2*r.l_dist,py,
     s4,3,-1,slice,r.tree_tex,
     cur_clip,sprites)
   elseif l_typ==5 then   

    -- dup duuuup
    cutting(
     px,py,
     l_width+lerp(r.start_w_l,r.end_w_l,pcnt_in_seg),
     lerp(r.start_h,r.end_h,pcnt_in_seg),
     scale,c,-1,slice,r,
     cur_clip,sprites)
   elseif l_typ==9 then
    building_with_wall(
     px,py,l_width,scale,r,
     1,slice,cur_clip,sprites)
   end
end
   
-->8
-- drawing

function station_stuff(
 px,py,ppx,ppy,width,r_width,
 scale,pscale,lhs,r,slice,
 c,cur_clip,sprites
 )
 local s4=scale/4
 if not r.underground then
  trackside(
   r,slice,
   px,py,
   c,width,r_width*1.2,--todo fiiiix betterrrrrr
   scale,
   cur_clip,sprites)
 end

 local dr=-1
 if(lhs)dr=1
 add(sprites,function()
  set_clip(cur_clip)
  set_palette(time_of_day,-1)

  local stx,stx2=
   px+dr*scale*2.2,
   ppx+dr*pscale*2.2 
  
  rectfill(
   stx+dr*scale,py-scale*5,
   ppx+dr*pscale*3.7,ppy,5+9*(slice%2))
 -- draw_clip(cur_clip)
  local s_tex=32
  if(slice==9)s_tex=48
  
  draw_trapezium2(
   stx,py,scale,
   stx2,ppy,pscale,
   0,s_tex,16,16)
   
  draw_trapezium2(
   stx2,128-ppy,pscale,
   stx,128-py,scale,
   16,48,16,16,true)
  if slice==1 
  and not r.underground then
   local x1,x2=
    ppx+dr*pscale*2.2,
    px+dr*pscale*6
   --wall
   rectfill(
    x1+dr*scale,
    128-ppy,
    x2,ppy,6)
   rectfill(
    x1+dr*scale,
    128-ppy,
    x2,128-ppy+scale*0.2,5)
    --roof
   rectfill(
    x1-dr*pscale,
    128-ppy-0.55*pscale,
    x2,128-ppy,1)
  end
  
 end)
    
 local last=r.len-1
 if slice==last then
  signal(
   px,py,width,scale,r,
   cur_clip,sprites)
 elseif r.busy[slice] then
  passenger(
   r.busy[slice],
   px,py,width,scale,
   cur_clip,lhs,sprites)
 end
end

function draw_trapezium(
 x1,y1,w1,x2,y2,w2,c,rev)
 local h=y2-y1
 
 local xd,wd,x,y,w=
  (x2-x1)/h,(w2-w1)/h,
  x1,y1,w1

 local yadj=ceil(y)-y
 x+=yadj*xd
 y+=yadj
 w+=yadj*wd
 
 while y<y2 do
  local scy=y
  if(rev)scy=128-y
  rectfill(x-w,scy,x+w,scy,c)
  x+=xd
  y+=1
  w+=wd
 end
end	

function draw_trapezium2(
 x1,y1,w1,x2,y2,w2,
 texx,texy,txw,txh,roof)
 
 local h=y2-y1
 
 local xd,wd,x,y,w=
  (x2-x1)/h,(w2-w1)/h,
  x1,y1,w1

 local yadj=ceil(y)-y
 x+=yadj*xd
 y+=yadj
 w+=yadj*wd

 while y<y2 do
  local pcnt=(y-y1)/h
  local ty=
   txh*pcnt%txh+texy
  sspr(
   texx,ty,txw,1,
   x-w,y,w*2,1)
  
  -- station roof
  if roof then 
   local roof_x,roof_y=
    x+w,y-flr(.6*w)
    
   if(x>64)roof_x=x-w
   line(
    roof_x,y,roof_x,
    roof_y,
    1
   )
  end
  x+=xd
  y+=1
  w+=wd
 end
 
end

function draw_tunnel_face(px,py,
 cutting_h,scale,first_slice_col,tracks)
 local x1,y1,x2,y2=tunnel_rect(px,py,scale,tracks)
 first_slice_col=first_slice_col or 6
 
 local wh=4.5*scale
 local wy=ceil(py-wh)

 rectfill(0,min(wy-2*scale,py-(cutting_h)*scale),128,y1-1,2)
 rectfill(0,wy,128,y1-1,6)

 rectfill(0,y1,x1-1,y2-1,first_slice_col)
 rectfill(x2,y1,127,y2-1)
 
end

function draw_ground(py,ppy,cx,slice,typ,scale)
 local lcol,rcol=
  typ.lcol or typ.col,
  typ.rcol or typ.col

 rectfill(0,ppy,cx,py,lcol[slice%#lcol+1])
 rectfill(cx,ppy,127,py,rcol[slice%#rcol+1])
end

--[[function draw_clip(clp)
 rect(clp[1],clp[2],clp[3]-1,clp[4]-1,8)
end]]

function pad_zero(c)
 if(c<10)return "0"..c
 return c
end

function draw_clock(x,y)
 nice_print(pad_zero(hours)..
  ":"..pad_zero(minutes)..
  ":"..pad_zero(seconds),x,y,7,1)
end

function draw_rails(px,py,ppx,ppy,scale,pscale)
 local lt,plt,rw,prw,hrw,phrw=
  scale*0.7,
  pscale*0.7,
  scale*.05,
  pscale*.05,
  scale*.0125,
  pscale*.0125
  
 --7955
 for i=0,1 do
  local dr=i*2-1
  local x1,x2=
   px+dr*lt,
   ppx+dr*plt
   
  draw_trapezium(
   x1,py,rw,
   x2,ppy,prw,
   6)
  draw_trapezium(
   x1+rw,py,hrw,
   x2+prw,ppy,phrw,
   7) 
 end
end

function draw_track(
 px,py,width,
 ppx,ppy,pwidth,
 scale,pscale,
 tx,ty,tracks,pcnt_in_seg,
 prev_pcnt_in_seg,points)
 
 draw_trapezium2(
  px,py,width,
  ppx,ppy,pwidth,
  tx,ty,64,16)

 local x_off,x_off2,
  draw_g,second_track=
  4,4,true,
  tracks==2 or points
 if points then
  local pp,ppp=
   1-pcnt_in_seg,
   1-prev_pcnt_in_seg
  if points==2 then
   pp,ppp=
    pcnt_in_seg,
    prev_pcnt_in_seg
  end
  
  x_off,x_off2,draw_g=
   lerp(0,4,pp),
   lerp(0,4,ppp),
   not(points and pp<0.2)
  if pp>0.16 and pp<0.9
  then
   ty+=16
  end
 end
 x_off*=scale
 x_off2*=pscale
   
 if second_track
 and draw_g then
  draw_trapezium2(
   px+x_off,py,2.25*scale,
   ppx+x_off2,ppy,
   2.25*pscale,
   tx+16,ty,48,16)--]]
 end
 draw_rails(px,py,
  ppx,ppy,
  scale,pscale
 )
 
 -- second track
 if second_track then
  draw_rails(px+x_off*0.8125,py,
   ppx+x_off2*0.8125,ppy,
   scale,pscale
  )
 end
end

function sky_cast(world_ang)

 local camx,camy=
  sin(world_ang),cos(world_ang)
 
 local stx,sty=
  -camx+cos(world_ang),
  -camy+(-sin(world_ang))
 
 pal(6,cloud_c)
 poke(0x5f38,4)
	poke(0x5f39,4)
	poke(0x5f3a,sky_x1)

 for y=0,60 do
  local curdist=128/(2*y-128)

  local d16,j=
   curdist/64,
   y%2*.03

  tline(0,y,127,y,
   j-skx+28+stx*curdist*1.2,
   j+28+sty*curdist*1.2,
   d16*camx,d16*camy)
 end
 skx+=0.0075
end

function background()
 if raining and time_of_day<2 then
  sky_c,cloud_c=14,5
 end
 cls(sky_c)

 rectfill(0,58,127,62,6)
 rectfill(0,63,127,68,7)

 sky_cast(world_ang/360)

 local bg=terrain
 if area==1 then
  bg=city
 end
 local sl,o_bg_c,o_h=
  0,bg_c,0
 for i=0,127 do
  local w=(flr(world_ang)+i)%120
  local h=bg[w+1]
  
  line(i,127,i,h,bg_c)-- 0 for night
  if i>0
  and flr(bg[w])<flr(h) then
   sl+=1
  else
   sl=0
  end
  
  if sl>1 then
   line(i,h+
    (68-h)*0.3,
    i-1.5,h,bg_hic)-- 1 for night
  end
  if area==1
  then
   if time_of_day>=2 then
    pset(i,
     h+25*offset[1+w%#offset],
     4+5*(w%2))
   elseif abs(o_h-h)>5 then
    bg_c=5+9*(h%2)
   end
  end
  
  o_h=h
 end
end

function draw_tunnel(px,py,ppx,ppy,scale,pscale,i,slice,typ,tracks)
 local x1,y1,x2,y2=
  tunnel_rect(px,py,scale,tracks)
 local px1,py1,px2,py2=
  tunnel_rect(ppx,ppy,pscale,tracks)
 if i==29 then
  -- dark in the distance
  rectfill(px1,py1,px2-1,py2,0)
 end
 local cl=slice%2
 --ceiling
 rectfill(px1,py1,px2,y1-1,cl)
 --left
rectfill(px1,y1,x1,py2,cl)
 --right
rectfill(x2,y1,px2,py2,cl)
end
-->8
-- track building

function station(prev)
 local len,busy=10,{}
  --+o_rnd(10)
 for i=1,len-2 do
  if o_rnd(2)==0 then
   busy[i]=o_rnd(8)
  end
 end
 
 if(frnd(8)==0)build_tracks=2
 
 local typ=1+frnd(2)
 if(build_tracks==2)typ=2
 if(tracks==2)typ=2
 
 local new_station={
  len=len,
  tu=(rnd(20)-10)/150,
  typ=typ,
  station=true,
  nm=station_name(),
  col={12,6},
  busy=busy,
  flip_mast=typ==2,
  has_signal=true,
  tracks=build_tracks,
  signal_wait=230+frnd(80)-40
 }
 if(auto)new_station.signal_wait=0
 
 add_trackside_to(new_station,prev)
 set_height_of(new_station,prev)
 
 new_station.underground=
  (not prev or prev.typ==3)
  and build_area==1
  and frnd(2)==0
  
 if not prev then
  new_station.start_h=build_h+rnd(6)-3
 end
 
 if new_station.underground then
  new_station.r_typ,
  new_station.l_typ=
   -1,-1
 end

 new_station.tree_tex=frnd(3)
 
 return new_station
end

-- 0 plain track
-- 1 station right
-- 2 station left
-- 3 * tunnel
-- 4 * level crossing
-- 5 * cutting
-- 8 * bridge
-- 9 tall buildings
-- 10 underpass
-- 98 end of line wall
-- 99 end of line field
-- 11 buildings

--single_sides={0,5,6,9}
next_up={
 [0]={mn=10,l=27,n=split("0,0,0,3,4,5,8,9")},
 [1]={l=10,n=split("0,3,4,5,8,9")},
 [2]={l=10,n=split("0,3,4,5,8,9")},
 [3]={l=27,n=split("0,3,3,5,8,9,10,10")},
 [4]={l=3,n=split("0,8,9")},
 [5]={l=27,n=split("0,3,5,5")},
 [8]={mn=8,l=50,n=split("0,8,8")},
 [9]={mn=10,l=27,n=split("0,3,4,9")},
 [10]={mn=10,l=27,n={0,3}}
}
biomes={
 [0]={
  nm="country",
  ad={0,3,5},
  rm={9,10},
  single_sides=split("5,6,5"),
  min_segs=8
 },
 {
  nm="city",
  ad={9,3,3},
  rm={},
  single_sides=split("0,5,6,9"),
  min_segs=2
 }
}

function pick_typ(n,ad,rm)
 local typs={}

 addall(typs,n)
 addall(typs,ad)
 for _,i in pairs(rm) do
  del(typs,i)
 end
 
 return typs[1+frnd(#typs)]
end

function track_seg(prev)
 local template,biome=
  next_up[prev.typ],
  biomes[build_area]
 local typ=pick_typ(template.n,biome.ad,biome.rm)
 --printh("adding "..typ)

 local len=3+frnd(next_up[typ].l)+(next_up[typ].mn or 0)

 local turn=(frnd(40)-20)/
  (len*32)
 if(len<8)turn=0

 if(prev.underground and frnd(2)==0)typ=3
 local new_seg={
  len=len,
  tu=turn,
  typ=typ,
  tracks=build_tracks,
  col={11,3}
 }--]]

 if frnd(6)<2
 and not prev.has_signal then
  new_seg.has_signal,
  new_seg.signal_wait=
   true,
   frnd(120)
  if(auto)new_seg.signal_wait=0
 end

 -- todo generalize textures
 if typ==0 then
  add_trackside_to(new_seg,prev)
  
  -- switch num tracks?
  if frnd(5)==0 then
   local old_build_tracks=build_tracks
   build_tracks=frnd(2)+1
   if old_build_tracks~=build_tracks then
    new_seg.points,
    new_seg.tracks,
    new_seg.len=
     build_tracks,
     build_tracks,25
   end
  end
 elseif typ==3 then
  if new_seg.len>10
  and frnd(2)==0 then
   build_area,
   build_h=
    frnd(2),
    frnd(6)+3
   new_seg.next_area=build_area
   
  end
 elseif typ==4 then
  new_seg.tx,
  new_seg.col=
   64,
   {13}
 elseif typ==8 then
  new_seg.tx,new_seg.ty,
  new_seg.density,new_seg.col=
   64,16,1+frnd(3),
   {14}
  
  add_trackside_to(new_seg,prev)
 elseif typ==9 then
  -- could this live elsewhere?
  new_seg.col={12,13}
 end
 
 -- deal with cuttings
 set_height_of(new_seg,prev)
 -- finish cuttings
 
 new_seg.flip_mast,
 new_seg.tree_tex=
  frnd(2)==0 and build_tracks==1
  and not new_seg.points,
  frnd(3)

 return new_seg
end

function set_weather()
 sky_x1=o_rnd(21)*4   
 raining=sky_x1>=64 and o_rnd(2)==0
end

function add_trackside_to(new_seg,prev)
  new_seg.l_dist,
  new_seg.r_dist=
   1+frnd(2),
   1+frnd(2)
  
  if prev
  and prev.typ==0
  and frnd(2)==0 then
   new_seg.l_typ,
   new_seg.r_typ=
    prev.l_typ,
    prev.r_typ
  else
   local biome=biomes[build_area]
   local single_sides=biome.single_sides
   new_seg.l_typ,
   new_seg.r_typ=
    pick_typ(single_sides,{},biome.rm),
    pick_typ(single_sides,{},biome.rm)
  end
  
  if new_seg.l_typ==6 then
   new_seg.lcol={14}
  elseif new_seg.r_typ==6 then
   new_seg.rcol={14}
  end
  
  -- could this live elsewhere?
  if new_seg.r_typ==9
  or new_seg.l_typ==9 then
   new_seg.col={12,13}
  end
end

function set_height_of(new_seg,prev)
 new_seg.start_h,
 new_seg.start_w_l,
 new_seg.start_w_r,
 new_seg.end_h,
 new_seg.end_w_l,
 new_seg.end_w_r,
 new_seg.base_h=
  0,0,0,
  build_h+rnd(6)-3,
  rnd(2),
  rnd(2),
  build_h+rnd(6)-3
 
 if new_seg.typ==5 then
  new_seg.r_typ,
  new_seg.l_typ=
   5,5
 end
 if prev and (prev.typ==5
 or prev.r_typ==5
 or prev.l_typ==5
 or prev.typ==3) then
  new_seg.start_h,
  new_seg.start_w_l,
  new_seg.start_w_r
  =
   prev.end_h,
   prev.end_w_l,
   prev.end_w_r
 end

 
 -- if new seg is not a cutting
 -- a tunnel, or a 1-side cutting
 -- set to zero
 if prev
 and new_seg.typ~=3 -- not a tunnel
 and new_seg.typ~=5 -- not a cutting
 and new_seg.r_typ~=5 -- not r cutting
 and new_seg.l_typ~=5 then -- not l cutting
  prev.end_h=rnd(3)
 end
end

function add_segs(station,track)
 local num_segs=
  biomes[build_area].min_segs+frnd(5)
 local prev=station
 for s=1,num_segs do
  local seg=track_seg(prev)
  add(track,seg)
  maybe_add_train_to(seg,#track)
  -- end adding trains
  prev=seg
 end
end

function generate_track()
 printh("\nnew track with seed "..seed)
 local track,stations,num_stations=
  {},{},5+frnd(5)

 if(infinite)num_stations=2

 for i=1,num_stations do
  local station=station(track[#track])
  
  add(track,station)
  add(stations,station)
  
  if i<num_stations
  or infinite then
   add_segs(station,track)
  else
   end_of_the_line(station,track)
  end
 end
 
 return track,stations
end

function end_of_the_line(station,track)
 add(track,{
  len=100,
  tu=0,
  typ=98,
  col={12,6},
  tracks=build_tracks
 })
 station.end_of_the_line=true
end

function add_more_track(oldseg,end_line)
 if end_line
 or (track[oldseg].station and infinite)
 then
  -- dup
  local station=station(track[#track])
  add(track,station)

  if last_stop then
   end_of_the_line(station,track)
  else
   add_segs(station,track)
   local num_to_delete=camcnr-1
   -- clean up
   for i=1,num_to_delete do
    deli(track,1)
   end
   camcnr,
   curseg=
    1,track[1]
   ot_seg-=num_to_delete
   ot_end_seg-=num_to_delete
  end
  return station
 end
 return nil
end

function generate_height_at_midpoint(left,right,randomness)
 terrain[flr((left+right)/2)]=
  (terrain[left]+
   terrain[right])/2
    +(rnd(1)*randomness-(randomness/2))
end

function generate_city()
 width,initial_height,city=
  128,50,{}

 for i=1,width do
  if i%7==0 then
   initial_height+=frnd(25)-12
  end
  city[i]=initial_height
 end
end

function generate_terrain()
 width,initial_height
 ,terrain,
 randomness=
  128,
  72-build_h*7,
  {},build_h*7
 -- low height, less variation

 for i=1,width do
  terrain[i]=initial_height
 end

 local step=flr(width/2)

 while(step>=1) do
  local segmentstart=1
  while(segmentstart<=width) do
   local left=segmentstart
   local right=left+step
   if right>width then
    right-=width
   end
   generate_height_at_midpoint(left,right,randomness)
   segmentstart+=step
  end
  randomness/=2
  step/=2
 end
end
-->8
-- palette stuff

--8010
function init_palette_2()
 for z=0,3 do
  for i=0,15 do
   poke(0x5000+16*z+i,
    sget(96+i,80+z))
  end
 end
end

function init_palette()
 --pal()
 pal(
  split("1,141,3,4,5,6,135,137,9,140,138,134,13,131,133"),
  1)
--[[ pal(2,141,1)
 pal(7,135,1)
 pal(8,137,1)
 pal(10,140,1)
 pal(11,138,1)
 pal(12,134,1)
 pal(14,131,1)
 pal(15,133,1)--]]

 -- winter
--[[ pal(2,13,1)
 pal(3,13,1)
 pal(5,6,1)
 pal(7,135,1)
 pal(8,137,1)
 pal(10,7,1)
 pal(11,7,1)
 pal(12,7,1)
 pal(14,140,1)
 pal(15,7,1)--]]
end

function set_palette(time_of_day,i)
 if time_of_day==active_palette
 and last_i==i then
  return
 end

 if(time_of_day>=3)
 and i>=0 then
  --dark
  set_pal(3,0,1,1,15)

  if(hours>=5 and hours<8)sky_c=2
  -- headlights
  if i<4 then
   pal(7,7)
   pal(13,13)
  elseif i>7 then
   pal(7,5)
   pal(6,1)
  end
 elseif time_of_day==2 then
  --dusk
  set_pal(2,2,4,8,9)
 elseif time_of_day==0 then
  --dawn
  set_pal(0,12,6,7,6)
  if(raining)bg_c=14
 else
  --day
  set_pal(1,14,3,13,6)
 end
 active_palette,last_i=
  time_of_day,i
end

function set_pal(
 i,
 n_bg_c,n_bg_hic,
 n_sky_c,n_cloud_c)
 
 memcpy(0x5f00,0x5000+16*i,16)
 palt(0,true)
 
 bg_c,
 bg_hic,
 sky_c,
 cloud_c=
  n_bg_c,n_bg_hic,
  n_sky_c,n_cloud_c
end

-->8
-- update stuff

function update_controls()
 if show_title then
  if btnp(⬅️) then
   seed-=1
   init_everything()
  elseif btnp(➡️) then
   seed+=1
   init_everything()
  end
  
  if btnp(❎) then
   show_title=false
   music_for_time()
  end
  
  show_credits=false
  if(btn(⬇️))show_credits=true

  if(btnp(⬆️))only_slightly_chill=not only_slightly_chill
  
  show_route=false
  if(btn(🅾️))show_route=true
  return
 end
 
 local a_msg="express service"
 if(auto)a_msg="stopping service"
 if btn(➡️) then
  auto_timer+=1
  goal_msg:set_message(
   a_msg.." in "..60-auto_timer,2,true)
 else
  auto_timer=0
 end
 
 if auto_timer>60 then
  auto=not auto
  auto_timer=0

  status_msg:set_message_with_cat(a_msg.."!",45,true)
 end
 
 if btn(⬅️)
 and not last_stop then
  journey_over_timer+=1
  goal_msg:set_message(
   "announcing last stop in "..60-journey_over_timer,2,true)
 else
  journey_over_timer=0
 end
 
 if journey_over_timer>30
 and not last_stop then
  last_stop=true
  local last_station=add_more_track(-1,true)
  status_msg:set_message_with_cat("last stop is\n"..last_station.nm.."!",60,true)
 end
 
 if btnp(⬆️) then
  throttle,throttle_vis_timer=
   max(throttle-1,-2),30
 end
 if(btnp(⬇️) or auto)
 and not doors_open then
  throttle,throttle_vis_timer=
   min(throttle+1,5),30
 end
 
 if btn(❎) then
  if journey_over then
   show_title=true
   music(0,1000)
   init_everything()
  else
   sfx(59)
   honking=true
  end 
 elseif honking then
  honking=false
  status_msg:set_message_with_cat("honk honk!",15,true)
 end
 
 -- dup
 local r=curseg
 local pcnt_in_seg=percent_in_seg(camz,camslice,r)
 local arrived=in_station(r,vel,pcnt_in_seg)
 if btnp(🅾️)
 and vel==0 then
-- printh(passenger_x)
  if doors_open 
  and (not passenger_x or 
   abs(passenger_x)>=46)
  and not journey_over then
   status_msg:set_message_with_cat(
    "doors closing!",55)
   
   if #disembarking>0 then
    goal_msg:set_message(
     #disembarking.." completed their journey!",55)
    journeys_completed+=#disembarking
    disembarking={}
   end
   if accelerate_tutorial<3 then
    accelerate_tutorial+=1
    goal_msg:set_message(
     "press ⬇️ to accelerate",55)
   end
   addall(passengers,boarding)
   doors_open,boarding=
    false,{}

   sfx(58,1)
  elseif not doors_open
  and arrived then
   local arrive_msg="all aboard!"
   if r.end_of_the_line then
    arrive_msg="this train terminates here!"
    music(55)
   elseif doors_tutorial<3 then
    doors_tutorial+=1
    goal_msg:set_message(
     "press 🅾️ to close doors",45)
   end
   status_msg:set_message_with_cat(arrive_msg,90)
   sfx(62,0,11)
   doors_open=true

   if curseg.station then    
    boarding={}
    addall(boarding,r.busy)
    r.busy={}
   end
  elseif not arrived then
   goal_msg:set_message(
    "can't open doors here!",30)
  end
 end
end

function update_camera()
 camz+=vel
 if camz>1 then
  camz-=1
  local oldcnr=camcnr
  camcnr,camslice=advance(camcnr,camslice)
  if oldcnr~=camcnr then
   time_in_seg,stops_in_seg=
    0,0
   -- do not change this,
   -- things get weird if you do
   -- (area switch happens too late)
   local r=track[camcnr]
   if(r.has_signal)total_signals+=1
   announce_next_station(camcnr+1,camcnr)
   if(not last_stop)add_more_track(oldcnr)
   local next_area=r.next_area
   if next_area then
    area,build_area=
     next_area,next_area
    generate_terrain()
    generate_city()
    
    -- change weather
    if o_rnd(2)==0 then
     set_weather()
    end
   end
  end
 end
 curseg=track[camcnr]
 
 world_ang+=vel*curseg.tu*36
 if(world_ang>=360)world_ang-=360
 if(world_ang<0)world_ang+=360
end

function update_train()

 local ot_next=track[ot_seg-1]
 if ot_next
 and (ot_next.tracks==1 
 or ot_next.points)then
  ot_vel*=0.95
 end
 ot_z-=ot_vel
 if ot_z<0 then
  ot_z+=1
  ot_slice-=1
  if ot_slice<1 then
   ot_seg-=1
   if(ot_seg>0)ot_slice=ot_next.len
  end
  ot_end_slice-=1
  if ot_end_slice<1 then
   ot_end_seg-=1
   if(ot_end_seg>0)ot_end_slice=track[ot_end_seg].len
  end
 end

  -- add a train?
 maybe_add_train_to(track[#track],#track)

 if(show_title)return
 local r=curseg
 local pcnt_in_seg,typ=
  percent_in_seg(camz,camslice,curseg),
  r.typ
 
 --braking - vel*=0.98
 if throttle>=0 then
  --0.001
  vel+=(throttle*0.0003)
 else
  vel*=(1+throttle*0.01)--0.98 is max braking
 end
 vel=min(vel,0.2)
 vel*=0.999 -- friction
 -- slow at last station
 if r.end_of_the_line then
  auto=false
  if(vel>0.05)vel*=0.9825
  throttle,breaking=0,true
  if(pcnt_in_seg>0.8)vel*=0.85
 end
 -- snap to stop at slow speeds
 if throttle<0 and vel<0.005 then
  vel=0
  stops_in_seg+=1
 end
 
-- if(stat(20)<11)sfx(62,-1,0,1)
 
 if pcnt_in_seg>0.90 
 and r.station
 and not r.end_of_the_line then
  -- downgrade score for skipping stations
  if not auto and stops_in_seg==0 then
   stops+=1
   stops_in_seg=1
   total_score+=420
  end
  status_msg:set_message_with_cat("departing\n"..r.nm,90)
  status_msg:set_message_with_cat("next stop\n"..next_s().nm,90)
 end
 
 -- check stop at station
 if in_station(r,vel,pcnt_in_seg)
 and not stopped_at_station
 then
  stopped_at_station=true
  if not r.stopped_at then
   passenger_x,
   disembarking=
    0,{}
   -- who is getting off
   for p in all(passengers) do
    if r.end_of_the_line
    or o_rnd(4)==0 then
     add(disembarking,p)
     del(passengers,p)
    end
   end
  end
  r.stopped_at=true

  stops+=1
  if stops>1 then
   -- calculate score
   local score=time_in_seg --165 is optimal
    +stops_in_seg*10 -- 10 is optimal
    +abs(to_next_landmark())*100  -- 0 is optimal

   total_score+=score
  
   goal_msg:set_message(
    "station stop rating: "..score_to_string(score),20)
  end
  goal_msg:set_message(
   "press 🅾️ to open doors",30)
 elseif vel>0 then
  stopped_at_station=false
 end
 
 if stopped_at_station
 and doors_open then
  passenger_x+=(typ-1)*2-1
  if abs(passenger_x)>=46
  and r.end_of_the_line 
  and not journey_over then
   journey_over=true
   status_msg:set_message_with_cat("all change please!",32000,true)
   end
 end

 if r.has_signal then
  r.signal_wait-=1
  if r.signal_wait==0 then
   status_msg:set_message_with_cat("signal clear!",60,true)
   signals_obeyed+=1
  end 
 end
 throttle_vis_timer=max(throttle_vis_timer-1,0)
end

function maybe_add_train_to(end_seg,len)
 if end_seg.tracks==2
 and end_seg.typ<98
 and end_seg.len>=10
 and not end_seg.points
 and ot_end_seg<camcnr
 and o_rnd(4)==0 then
  ot_seg,ot_end_seg,
  ot_slice,ot_end_slice,
  ot_z,ot_vel=
   len,len,5,14,0,0.2
 end
end

function next_s()
 for i=camcnr+1,#track do
  if track[i].station then
   return track[i]
  end
 end
end

function in_station(r,vel,pcnt_in_seg)
 return r.station
 and vel==0 
 and pcnt_in_seg>=.80
 and pcnt_in_seg<.90
end
-- make a nice timed message
function new_message(x,y,centred)
 local align=0
 if(centred)align=2
 
 return {
--  t=0,
  x=x,
  y=y,
  msgs={},
  set_message=function(s,m,t,f)
   if(f and #s.msgs>0)foreach(s.msgs,function(f)del(s.msgs,f)end)
   add(s.msgs,{m=m,t=t})
  end,
  update=function(s)
   if #s.msgs>0 then
    local cur=s.msgs[1]
    if(cur.t>0)cur.t-=1
    if(cur.t==0)del(s.msgs,cur)
   end
  end,
  draw=function(s)
   if #s.msgs>0 then
    nice_print(s.msgs[1].m,s.x-#s.msgs[1].m*align,s.y,7,1)
   end
  end
 }
end

function to_next_landmark()
 local r=curseg
 local to_next=
  flr(((r.len-1.5)-
  (camz+camslice-1))*100)/100
 if not r.station
 and not r.has_signal then
  for i=camcnr+1,#track do
   r=track[i]
   to_next+=track[i].len
   if(r.station or r.has_signal)break
  end
 end
 if r.station then
  return to_next,252
 elseif r.has_signal then
  return to_next,253
 end
 return 0,0
end

function score_to_string(s)
 if s<188 then
  return "aaa"
 elseif s<197 then
  return "aa"
 elseif s<207 then
  return "a"
 elseif s<220 then
  return "b"
 elseif s<230 then
  return "c"
 elseif s<240 then
  return "d"
 end
 return "e"
end

function announce_next_station(next_t,cursegid)
 if track[next_t].station then
  status_msg:set_message_with_cat("approaching\n"..track[next_t].nm,120)
  if brake_tutorial<3 then
   brake_tutorial+=1
   goal_msg:set_message(
    "press ⬆️ to brake soon!",45)
  end
 elseif track[cursegid].station then
  status_msg:set_message_with_cat("welcome to\n"..track[cursegid].nm,30,true)
 end
end
-->8
-- stations
name_patterns={
 {1,2},
 {2,3},
 {2,3}
}
name_bits={
split("north ,south ,east ,west ,central ,upper ,lower "),
split("noodles,cheese,chips,chilli,hot chips,crisps,kebab,curry,beans,fish"),
split("borough,bourne,bridge, bridge, broadway, central, common, cross, east, end,ford, green,ham, hill, junction, north, park, parkway, road, south, street, town, west, wood,wood")
}
--[[station_names={
 "noodles junction",
 "cheese hill",
 "kebab street",
 "beans cross",
 "beans gate",
 "beans street",
 "kebab junction",
 "cheese common",
 "fish park",
 "fishbourne",
 "fish junction",
 "kebab common",
 "kebab bridge",
 "cheese parkway",
 "kebab wood",
 "west cheese"
}--]]

function station_name()
 local pattern,name=
  name_patterns[frnd(#name_patterns)+1],""
 for p in all(pattern) do
  name=name..name_bits[p][frnd(#name_bits[p])+1]
 end
 return name
end

function draw_passengers(s)
 rectfill(32,16,96,40,1)
 clip(33,17,63,31)
 
 rectfill(32,16,96,39,12)
 rectfill(32,16,96,26,sky_c)
 rectfill(32,27,96,27,6)
 
 local fliph,shift,start,
 platform_x=
  s.typ==1,
  80,
  32,
  72

 if fliph then
  shift,
  start,
  platform_x=
   0,50,41
 end
 spr(153,platform_x,16,2,3,fliph)
 
 local boarding_x=passenger_x
 if(s.end_of_the_line)boarding_x=0
 for i,p in pairs(boarding) do
  spr(160+p,start+boarding_x+i*5,
   23-frnd(2),1,2)
 end
 
 for i,p in pairs(disembarking) do
  spr(160+p,(shift-passenger_x)+32-i*5,
   23-frnd(2),1,2)
 end
 platform_x=88
 if(fliph)platform_x=33
 spr(155,platform_x,16,1,3,fliph)

 clip()
end
	
-->8
-- util


-- pseudo random stuff 
function s_o_rnd()
 for i=1,300 do
  o_rnd_vals[i]=rnd()
 end
end

function o_rnd(n)
 o_rnd_ptr=1+o_rnd_ptr%300
 return flr(o_rnd_vals[o_rnd_ptr]*10000%n)
end

function frnd(n)
 return flr(rnd(n))
end

function addall(dst,src)
 for _,i in pairs(src) do
  add(dst,i)
 end
end

function lerp(a,b,pcnt)
 return a+(b-a)*pcnt
end

function project(x,y,z)
 local scale=64/z
 return x*scale+64,y*scale+64,scale
end

function nice_print(s,x,y,c,shadow)
 print(s,x-1,y,shadow)
 print(s,x+1,y)
 print(s,x,y-1)
 print(s,x,y+1)
 print(s,x,y,c)
end

function tick(t_speed)
 timer+=1
 time_in_seg+=1
 
-- if timer%30==0 then
  seconds+=t_speed
  if seconds>=60 then
   seconds=0
   minutes+=1
   if minutes>=60 then
    minutes=0
    hours+=1
    -- change time of day
    set_time_of_day()
    if hours==6 then
     cue_music(0)
    elseif hours==14 then
     cue_music(16)
    elseif hours==22 then
     cue_music(31)
    end
    
    if hours>=24 then
     hours=0
    end
   end
--  end
  
 end
  
end

function set_time_of_day()
 if hours>=20 
 or hours<6 then
  time_of_day=3
 elseif hours>=17 then
  time_of_day=2
 elseif hours>=10 then
  time_of_day=1
 elseif hours>=6 then
  time_of_day=0
 end
end

-- 
-- music stuff
-- 
function music_for_time()

 if hours>=6 and hours<=14 then
  music(0+(hours-6),7500)
 elseif hours>14 and hours<22 then
  music(16+(hours-14),7500)
 else
  music(31+(hours-22)%24,7500)
 end
end

function cue_music(song)
 next_song=song
end

function update_music()
 local note=stat(21)
 if current_note~=note then
  note_len,current_note=0,note
 else
  note_len+=1
 end
 if next_song 
 and stat(21)==31
 and note_len>=3 
 and not journey_over then
  music(next_song)
  next_song=nil
 end
end
