--init--
function _init()
	--challenge mode
	hard_mode=false
	game_mode = "title"
	--title screen low resolution
	poke(0x5f2c,3)
	sine_timer=0
	code_count=1
	slow_code_count=1
	--camera position
	cam_x = 0
	cam_y = 0
	cam_goal_y=0
	scroll_spd=3
	scroll_dir="verti"
	scroll_lenience=8
	--map size in tiles
	map_w = 128
	map_h = 64
	--room size in tiles
	room_w = 16
	room_h = 8
	--total number of rooms in game
	rooms_num = 64
	--init transition speeds
	init_transitions()
	draw_init()
	save_rooms()

	init_actors()
	init_partics()

	fall_spd=0.3
	max_grav=3

	keys=0
	eggs=0
	deaths=0
	--item_move_down=16
	boss_gate_timer=0

	max_hp=6
	hp=6
	fireball_timer=0
	charge_time=20

	init_plr()
	explored_rooms={}
	for x=0,23 do
		explored_rooms[x]={}
	end
	--respawn position
	check_room_x=2
	check_room_y=8
	check_scroll_dir="verti"
	check_room_pal=0

	--a word on the screen
	word=""
	word_timer=0

	--timer for get item anim
	item_wait=0
	--time to respawn
	respawn_timer=-1
	--a delightful transition
	wipe_transition=0
end

--sets up the actor system
function init_actors()
	actors = {}
end

function new_actor(x,y,s)
	local a = {}
	a.x=x --position
	a.y=y
	a.s=s --sprite
	a.f=false --flip
	return a
end

function add_actor(a)
	add(actors,a)
end

--sets up the particle system
function init_partics()
	partics = {}
end

function new_partic(x,y,c,l)
	local p = {}
	p.x=x --position
	p.y=y
	p.c=c --colour
	p.life=l
	p.lived_for=0
	return p
end

function add_partic(p)
	add(partics,p)
end

function init_plr()
	plr = new_actor(20,48,38)
	plr.egg=true
	plr.mom=0
	plr.acc=0.25
	plr.dcc=0.4
	plr.max_mom=1
	plr.up=0
	plr.anim=0
	plr.grav=0
	plr.spin=-1

	plr.name="plr"
	add_actor(plr)
end

--copies the rooms into memory.
function save_rooms()
	rooms={}
	local room_cur=0
	local room_x=0
	local room_y=0
	while room_cur<=rooms_num do
		active_room={}
		active_room["up"]="open"
		active_room["down"]="open"
		active_room["left"]="wall"
		active_room["right"]="wall"
		active_room["left_stop"]=false
		active_room["right_stop"]=false
		for x=0,room_w-1 do
			active_room[x]={}
			for y=0,room_h-1 do
				tx=room_x*room_w+x
				ty=room_y*room_h+y
				tile=mget(tx,ty)
				active_room[x][y]=tile
				if tile==31 then
					active_room["up"]="wall"
				elseif tile==47 then
					active_room["down"]="wall"
				elseif tile==77 then
					active_room["save"]=true
				elseif tile==48 then
					active_room["item"]=true
				elseif tile==62 then
					active_room["left_stop"]=true
				elseif tile==63 then
					active_room["right_stop"]=true
				elseif x==0 and not fget(tile,0) then
					active_room["left"]="open"
				elseif x==15 and not fget(tile,0) then
					active_room["right"]="open"
				end
				mset(tx,ty,0)
			end
		end
		rooms[room_cur]=active_room
		room_cur+=1
		room_x+=1
		if room_x==8 then
			room_x=0
			room_y+=1
		end
	end
end

function load_room(num,cx,cy,e_lv,door)
	to_play_music=2
	if e_lv==nil then e_lv=0 end
	room=rooms[num]
	if room == nil then
		return false
	end
	for x=0,room_w-1 do
		for y=0,room_h-1 do
			tile=room[x][y]
			if y>0 then
				above_tile=room[x][y-1]
			else
				above_tile=0
			end
			if x>0 then
				next_tile=room[x-1][y]
			else
				next_tile=0
			end
			if above_tile==68 or above_tile==69 then
				above_tile=137-above_tile
			end
			if next_tile==68 or next_tile==69 then
				next_tile=137-next_tile
			end
			act=load_actor(tile,(x+cx)*8,(y+cy)*8,e_lv)
				--already broken blocks
			if door and fget(tile,7) then
				mset(cx+x,cy+y,next_tile)
			elseif door and fget(tile,3) then
			 mset(cx+x,cy+y,85)
			elseif act==nil then
				mset(cx+x,cy+y,tile)
			else
				if act.name=="room_top" or act.name=="room_bottom" or act.name=="slime" then
					mset(cx+x,cy+y,next_tile)
				elseif act.name=="block" then
					mset(cx+x,cy+y,tile)
				else
					mset(cx+x,cy+y,above_tile)
				end
				add_actor(act)
			end
		end
	end
	play_music(to_play_music)
	return true
end

function load_actor(i,x,y,e_lv)
	a=nil
	local item_id=rm_items[room_y][room_x]
	if i==62 then
		a=new_actor(x,y,15)
		a.name="exit_left"
	elseif i==63 then
		a=new_actor(x,y,15)
		a.name="exit_right"
	elseif i==31 then
		a=new_actor(x,y,15)
		a.name="room_top"
	elseif i==47 then
		a=new_actor(x,y,15)
		a.name="room_bottom"
	elseif i==48 then
		a=new_actor(x+4,y,15)
		if (item_id=="h") a.s=48
		if (item_id=="1") a.s=49
		if (item_id=="2") a.s=50
		if (item_id=="3") a.s=51
		if (item_id=="4") a.s=52
		if (item_id=="k") a.s=53
		if (item_id=="e") a.s=54+eggs
		a.name="item"
		to_play_music=8
		if a.s!=15 then
			a.g={}
 		a.g[0]=new_actor(x,y-4,58)
 		a.g[1]=new_actor(x+8,y-4,58)
 		a.g[2]=new_actor(x,y+4,58)
 		a.g[3]=new_actor(x+8,y+4,58)
 		for n=0,3 do
 			a.g[n].f=n%2==1
 			a.g[n].vf=n>1
 			a.g[n].name="glow"
 			add_actor(a.g[n])
 		end
 		a.timer=1
 	end
		if a.s==15 then a.name="" end
	elseif i==77 then
		a=new_actor(x,y+8,93)
		a.name="savepart"
		add_actor(a)
		a=new_actor(x+8,y+8,94)
		a.name="savepart"
		add_actor(a)
		a=new_actor(x+8,y,78)
		a.name="savepart"
		add_actor(a)
		a=new_actor(x,y,77)
		a.name="save"
		to_play_music=8
	elseif i==79 then
		a=new_actor(x,y,79)
		a.name="block"
	elseif i==16 or i==17 then
		a=new_actor(x,y,16)
		--set the direction.
		a.f=i==17
		a.name="beetle"
		a.enemy=true
	elseif i==18 then
		init=y-y%64+53
		a=new_actor(x,init,19)
		a.init=init
		a.hop=y
		a.state="wait"
		a.name="jellyfish"
		a.enemy=true
		a.anim=0
	elseif i>=74 and i<=76 then
		a=new_actor(x+4,y,74)
		a.name="bat"
		a.enemy=true
		a.len=(i-72)*10
		a.pause=10
		a.goal_x=a.x
		a.goal_y=a.y
		a.sine_timer=rnd(100)/100
		to_lock_room=true
		if item_id==0 then
			a.s=15
			a.name="killme"
		else
			to_play_music=9
		end
	elseif i==20 or i==21 then
		a=new_actor(x,y,20)
		--set the direction.
		a.vf=i==21
		a.name="slime"
		a.enemy=true
	elseif i==34 then
		a=new_actor(x,y,35)
		--set the direction.
		a.name="skeleton"
		a.enemy=true
		a.mom=0
		a.anim=0
		a.up=0
		if e_lv>0 then
 		a.skull=new_actor(x,y-5,34)
 		a.skull.name="skull"
 		a.skull.enemy=true
 		a.skull.body=a
 		a.skull.grav=0
 		a.grav=0
 		a.skull.hp=e_lv
 		add_actor(a.skull)
		end
	end
	if a!=nil and a.enemy then
		a.max_hp=e_lv
		a.hp=e_lv
		a.lv=e_lv
		a.damage=e_lv
		if e_lv>2 then
			a.pal="white"
		elseif e_lv>1 then
			a.pal="red"
		elseif e_lv==0 then
			a.name="killme"
			a.s=15
		end
	end
	return a
end

function init_transitions()
	tr_length = 10
	tr_steps =
	{2,2,4,8,16,16,8,4,2,2}
	tr_pos = -1
end

function init_rooms()
	local rooms_list=split_string("006641421047002731144630000000371041425500000000,006500000000000000001100000000000000005400000000,007610404152424041603241562550511041425341420700,000000000000000000000000001100000000000000000000,002102062022252324261031041600371067002741426100,001107000000150000000000001500000065000000007500,001217101314160027333434353240610076415252426400,000000000000150000000000000000150000000000006500,000001020304050206070021026214056325505110407700,000000000000000000000015000000000011000000000000,000000664142550027414245415646300043415256463000,003710640000540000000000000011000015000000110000,000000764142531057703434343532415644002740450700")
	local col_list=split_string("01111104411-000666660000,010000000010000000060000,01111111111-5-6666666660,000000000000050000000000,0233-41111-5550888088880,022000100000050008000080,02211110555555-708888880,000000100000000700000080,0011111111077777-8888880,000000000007000007000000,000999907777-111077-1110,099900900000001007000100,0009999999---11177011110")
	local item_list=split_string("0|--|e0k--|-000e|--|0000,0|00000000|00000000|0000,0|-|---|-!|--|-/|--|--h0,0000000000000|0000000000,0|--|-|---|--|0e-|0h--|0,0|h000|000000|000|0000|0,0|2|--|0h----|-|0|----|0,000000|00000000|000000|0,00|---|--10|---|-|-/|-|0,00000000000|00000|000000,000|--|0k--|--|-0|---|-0,0e-|00|0000000|00|000|00,000|--|-/-----|--|03-|k0")
	local enemy_list=split_string("x00001x01200xxx11111xxxx,x0xxxxxxxx0xxxxxxxx1xxxx,x0012221030100000111220x,xxxxxxxxxxxxx0xxxxxxxxxx,x1111201120120x101x0220x,x10xxx0xxxxxx0xxx1xxxx0x,x111100x02222202x021100x,xxxxxx0xxxxxxxx0xxxxxx0x,xx00000000x022203100011x,xxxxxxxxxxx0xxxxx1xxxxxx,xxx1110x02101000x102010x,x100xx0xxxxxxx0xx1xxx1xx,xxx022100121212012x0220x")

	if hard_mode then
		rooms_list=split_string("002150514700002170343434262502620667000000000000,001500006641601600000000007150516776311446400700,007150517700001100374067000000006500000043300000,002102620640104400000076415252427310070011000000,001241422022255051670000000000000000000012206100,000000000000156630744020415252562570343434351600,000027101314167420734142670000001500000000001100,000000000000157641524267650066405320612731141600,000001020304050206073777650072214142442102044400,000000000037414267000000650072124142074340670000,002761000021505164006640731073572502041600720000,000011000011000076306527414261001100001500720000,000071020432201031067370342632204400001220730700")
		col_list=split_string("011110011111111112000000,0100111100000999922-3330,011110010999000090003300,032222110009999999903000,0333-41aa600000000003-40,0000001666aaaaaaa-----40,0001111666666000a0000040,000000166666606aa-644440,001111111166606aa661--40,000008888000606a66611100,07700788806666-aa1110100,007007008865555010010100,007777--5666555-10011110")
 	item_list=split_string("0|-/e00|-----|---|000000,0|00|-!|00000|-/||--|-k0,0|-/|00|0e-|0000|000|-00,0|---|-|000|----|-k0|000,0|--|-|-/|0000000000|-|0,000000||-|-|----|-----|0,00k|--||-|--|000|00000|0,000000||---||0|-|-|k--|0,00|---|--1e||0||--||--|0,00000e--|000|0||--3|-|00,0k|00|-/|0|-|-|/|--|0|00,00|00|00|-|k--|0|00|0|00,00|--|-|--|---|-|00|-|20")
		enemy_list=split_string("x3002xx33333333332xxxxxx,x3xx3002xxxxx2002233230x,x3003xx2x230xxxx2xxx20xx,x2222302xxx22322200x3xxx,x222022012xxxxxxxxxx323x,xxxxxx02002020300232322x,xxx1100022220xxx0xxxxx2x,xxxxxx0203022x022020222x,xx00000000200x022222330x,xxxxx2222xxx2x02220220xx,x02xx2222x2000002230x0xx,xx3xx2xx2220222x2xx2x0xx,xx222200120223202xx2020x")
	end
	room_x=2
	room_y=8
	lay_w=24
	lay_h=13
	layout={}
	rm_cols={}
	rm_items={}
	rm_enemies={}
	rm_doors={}
	for i=0,lay_h-1 do
		layout[i]={}
		rm_cols[i]={}
		rm_items[i]={}
		rm_enemies[i]={}
		str=rooms_list[i+1]
		col_str=col_list[i+1]
		item_str=item_list[i+1]
		enemy_str=enemy_list[i+1]
		rm_doors[i]={}
		for j=0,lay_w-1 do
			num=to_num(sub(str,j*2+2,j*2+2))
			num+=8*to_num(sub(str,j*2+1,j*2+1))
			layout[i][j]=num
			col=sub(col_str,j+1,j+1)
			rm_cols[i][j]=col
			item=sub(item_str,j+1,j+1)
			rm_items[i][j]=item
			enemy=sub(enemy_str,j+1,j+1)
			rm_enemies[i][j]=to_num(enemy)
			rm_doors[i][j]=false
		end
	end
end

function split_string(s)
	ret={}
	count=1
	str=""
	for i=1,#s do
		char=sub(s,i,i)
		if char=="," then
			ret[count]=str
			str=""
			count+=1
		else
			str=str..char
		end
	end
	ret[count]=str
	return ret
end

function to_num(c)
	for i=1,9 do
		if sub("123456789",i,i)==c then
			return i
		end
	end
	return 0
end
-->8
--update--

function _update60()
	sine_timer+=0.01
	sine_timer=sine_timer%1
	if win then
 	word="you win!        "
 	plr.s=1
 	if deaths==0 then
 		word_col=11
 	end
		return
	end
	if game_mode=="title" then
		update_title()
		return
	end

	if open_gate then
		update_gate()
		return
	end
	explored_rooms[room_x][room_y]=scroll_dir
	if respawn_timer>0 then
		respawn_timer-=1
	elseif respawn_timer==0 then
		respawn_timer=-1
		respawn()
	end
	if wipe_transition>0 then
		wipe_transition-=8
		return
	end
	if item_wait>0 then
		item_wait-=1
		if item_wait==0 then
			if plr.grav<0 then
				plr.grav=0
			end
			play_music(8)
		end
		return
	end
	if update_tr() then
		if update_boss_gate() then
 		update_plr()
 		update_actors()
 		update_cam()
 		update_partics()
		end
	end
end

function update_boss_gate()
	if (boss_gate_timer==0) return true
	boss_gate_timer-=1
	if plr.x>cam_x+64 then
		plr.x-=0.5
	else
		plr.x+=0.5
	end

 lock_room()

	return false
end

function lock_room()
	local cx=cam_x/8
	local cy=cam_y/8
	local i=cy+boss_gate_timer/3
	if mget(cx,i)==85 then
		mset(cx,i,91)
	elseif mget(cx+15,i)==85 then
		mset(cx+15,i,91)
	end
end

function update_title()
	for i=0,7 do
 	x=rnd(64)
 	p=new_partic(x,64+abs(x-32)/8,7,16+rnd(24))
 	p.yv=-0.3-rnd(5)/20
 	p.xv=rnd(10)/20-0.25
 	p.hard=hard_mode
 	add_partic(p)
	end
	if btnp(5) then
		game_mode="game"
		poke(0x5f2c,0)
		partics={}
		init_rooms()
		load_room(layout[room_y][room_x],0,0)
		play_music(8)
	end
	code={3,3,0,3,1}
	if btnp(code[code_count]) then
		code_count+=1
		if code_count>5 then
			sfx(22)
 		hard_mode=not hard_mode
 		code_count=1
 		foreach(partics,fire_go_big)
		end
	elseif btnp(0) or btnp(1) or btnp(2) or btnp(3) then
		code_count=1
	end
	update_partics()
	foreach(partics,colour_fire)
end

function colour_fire(p)
	colour_fire_all(p,10,9,8)
	if p.hard then
	 colour_fire_all(p,10,11,3)
 end
end

function colour_fire_all(p,c1,c2,c3)
 fire_col_check(7,c1,p)
 fire_col_check(16,c2,p)
 fire_col_check(32,c3,p)
end

function fire_go_big(p)
	p.yv=-p.yv/2
end

function fire_col_check(x,c,p)
 if(p.lived_for>x) p.c=c
end

function mom_by_arrows(a)
	if btn(1) and not btn(0) then
		a.mom+=a.acc
	elseif btn(0) and not btn(1) then
		a.mom-=a.acc
	else
		if a.mom>a.dcc then
			a.mom-=a.dcc
		elseif a.mom<-a.dcc then
			a.mom+=a.dcc
		else
			a.mom=0
		end
	end
	if a.mom>a.max_mom then
		a.mom=a.max_mom
	elseif a.mom<-a.max_mom then
		a.mom = -a.max_mom
	end
end

function is_solid(x,y)
	return is_flag_set(x/8,y/8,0)
end

function is_gate(x,y)
	return is_flag_set(x/8,y/8,3)
end

function is_lava(x,y)
	return is_flag_set(x/8,y/8,2)
end

function is_flag_set(x,y,f)
	return fget(mget(x,y),f)
end

function update_mom(a)
	if a.mom == nil then return end
	a.x+=a.mom
	if a.fly!=nil then
		if a.fly<0 then
			a.x-=1
			a.fly+=1
		elseif a.fly>0 then
			a.x+=1
			a.fly-=1
		end
	end
	if is_in_wall(a) then
		while is_in_wall(a) do
			local f=0
			if a.fly!=nil then
				f=a.fly
			end
			if a.mom+f<0 then
				a.x+=1
			else
				a.x-=1
			end
		end
		a.mom=0
		if a.fly!=nil then
			a.fly=0
		end
	end
end

function gravity(a)
if a.grav==nil then return end
	a.grav+=fall_spd
	if a.grav>=max_grav then
		a.grav=max_grav
	end
	a.y+=a.grav
	if is_in_wall(a) then
		while is_in_wall(a) do
			if a.grav>0 then
				a.y-=1
			else
				a.y+=1
			end
		end
		a.grav=0
	end
end

function is_in_wall(a)
	return is_solid(a.x,a.y) or
								is_solid(a.x+7,a.y) or
								is_solid(a.x,a.y+7) or
								is_solid(a.x+7, a.y+7)
end

function is_on_ground(a)
 return is_solid(a.x,a.y+8) or
 							is_solid(a.x+7,a.y+8)
end

function update_cam()
	if tr_pos!=-1 then return end
	if scroll_dir=="horiz" then
		prev_cam_x=cam_x
		local dist=cam_x-plr.x+60
		while dist>scroll_lenience do
			cam_x-=1
 		dist=cam_x-plr.x+60
 	end
		while dist<-scroll_lenience do
			cam_x+=1
 		dist=cam_x-plr.x+60
 	end
 	for a in all(actors) do
 		if a.name=="exit_left" then
 			if cam_x<a.x then
 				cam_x=a.x
 			end
 		elseif a.name=="exit_right" then
 			if cam_x>a.x-120 then
 				cam_x=a.x-120
 			end
 		end
 	end
 	if flr((cam_x+64)/128)!=flr((prev_cam_x+64)/128) then
 		if cam_x>prev_cam_x then
 			room_x+=1
 		else
 			room_x-=1
 		end
 	end
 else
		--save previous cam pos.
		prev_cam_y=cam_y
 	--vertical cam movement
 	if is_on_ground(plr) or
 				plr.y-40>cam_goal_y then
 		cam_goal_y=plr.y-40
 	end
 	if cam_goal_y+scroll_spd<cam_y then
 		cam_y-=scroll_spd
 	elseif cam_goal_y-scroll_spd>cam_y then
 		cam_y+=scroll_spd
 	else
 		cam_y=cam_goal_y
 	end
 	--stop at room top and bottom
 	for a in all(actors) do
 		if a.name=="room_top" then
 			if cam_y<a.y then
 				cam_y=a.y
 			end
 		elseif a.name=="room_bottom" then
 			if cam_y>a.y-56 then
 				cam_y=a.y-56
 			end
 		end
 	end
 	--update room_y
 	if flr((cam_y+32)/64)!=flr((prev_cam_y+32)/64) then
 		if cam_y>prev_cam_y then
 			room_y+=1
 		else
 			room_y-=1
 		end
 	end
	end
end

function cam_out_room_top()
	for i=0,15 do
		if not is_solid(i*8,cam_y+1) then
			return false
		end
	end
	return true
end

function cam_out_room_bottom()
	for i=0,15 do
		if not is_solid(i*8,cam_y+63) then
			return false
		end
	end
	return true
end

--rng for explosions
function explode_rnd()
	return rnd(0.5)+0.75
end

function update_partics()
	for p in all(partics) do
		update_partic(p)
	end
end

function update_partic(p)
	p.life-=1
	p.lived_for+=1
	if p.life<=0 then
		del(partics,p)
	else
		if p.xv!=nil then
			p.x+=p.xv
			if is_solid(p.x,p.y) then
				p.xv=-p.xv/2
				if p.xv>0 and p.xv<1 then
					p.xv=1
				end
				p.x+=p.xv
			end
			p.y+=p.yv
			if is_solid(p.x,p.y) then
				p.yv=-p.yv/2
				if p.yv>0 and p.yv<1 then
					p.yv=1
				end
				p.y+=p.yv
			end
			if is_solid(p.x,p.y) then
				del(partics,p)
			end
			if p.xa!=nil then
				p.xv+=p.xa
				p.yv+=p.ya
			end
		end
	end
end

--update transitions
function update_tr()	--exit if not started
	if tr_pos == -1 then
		return true
	else
	item_move_down=0
		--increase position
		tr_pos+=1
		--move in correct direction
		if tr_dir == "right" then
			cam_x+=tr_steps[tr_pos]*2
		elseif tr_dir == "left" then
			cam_x-=tr_steps[tr_pos]*2
		elseif tr_dir == "down" then
			cam_y+=tr_steps[tr_pos]
		elseif tr_dir == "up" then
			cam_y-=tr_steps[tr_pos]
		end
	end
	--stop at the end.
	load_new_room()
	return false
end

function load_room_special(i,j,x,y)
	return load_room(layout[j][i],x,y,rm_enemies[j][i],rm_doors[j][i])
end

function load_new_room()
	if tr_pos>=tr_length then
		tr_pos = -1
		actors={plr}
		partics={}
		if scroll_dir=="horiz" then
 		if tr_dir == "right" then
 			local i=0
 			local continue=true
 			while continue do
				rm=load_room_special(room_x+i,room_y,room_w*i,0)
				i+=1
 				for a in all(actors) do
 					if a.name=="exit_right" then
 						continue=false
 					end
 					if rm==false then
 						continue=false
 					end
 				end
 			end
  		plr.x=((plr.x+4)%(room_w*8))-4
  		plr.y=((plr.y)%(room_h*8))
  		cam_x=0
  		cam_y=0
  		clear_tr_area()
 		elseif tr_dir == "left" then
 			local i=0
 			local continue=true
 			while continue do
 			rm=load_room_special(room_x+i,room_y,112+room_w*i,0)
 				i-=1
 				for a in all(actors) do
 					if a.name=="exit_left" then
 						continue=false
 					end
 					if rm==false then
 						continue=false
 					end
 				end
 			end
  		plr.x=((plr.x+4)%(room_w*8))-4+112*8
  		plr.y=((plr.y)%(room_h*8))
  		cam_x=112*8
  		cam_y=0
  		clear_tr_area()
  	end
	 else
	 rm=load_room_special(room_x,room_y,0,room_h*3)
 		local origin=3
 		local top=false
 		local bot=false
 		for a in all(actors) do
 			if a.name=="room_top" then
 				origin=0
 				top=true
 				break
 			elseif a.name=="room_bottom" then
 				origin=6
 				bot=true
 				break
 			end
 		end

 		if top or bot then
 			clear_side_row()
 			actors={plr}
 			partics={}
 			rm=load_room_special(room_x,room_y,0,room_h*origin)
 		end

 		if not top then
 			local i=-1
 			local continue=true
 			while continue do
 				if (room_y+i)<0 then continue=false end
 				for a in all(actors) do
 					if a.name=="room_top" then
 						continue=false
 					end
 				end
 				if continue then
 				rm=load_room_special(room_x,room_y+i,0,room_h*(i+origin))
 					if rm==nil then
 						continue=false
 					end
 				end
 				i-=1
 			end
 		end
 		if not bot then
 			local i=1
 			local continue=true
 			while continue do
 				if (room_y+i)<0 then continue=false end
 				for a in all(actors) do
 					if a.name=="room_bottom" then
 						continue=false
 					end
 				end
 				if continue then
 				rm=load_room_special(room_x,room_y+i,0,room_h*(i+origin))
 					if rm==nil then
 						continue=false
 					end
 				end
 				i+=1
 			end
 		end

  	plr.x=((plr.x+4)%(room_w*8))-4
  	plr.y=((plr.y)%(room_h*8))+(origin*8*room_h)
  	cam_x=0
  	cam_y=room_h*origin*8
 		clear_tr_area()
 	end
 end
end

function clear_top_row()
	for i=0,127 do
		for j=0,7 do
			mset(i,j,0)
		end
	end
end

function clear_side_row()
	for i=0,15 do
		for j=0,55 do
			mset(i,j,0)
		end
	end
end

function clear_tr_area()
	for i=16,63 do
		for j=8,15 do
			mset(i,j,0)
		end
	end
end

function tr_start(direct)
	--tr starts
	tr_pos=0
	--set the direction
	tr_dir=direct
	--move camera to tr area
	cam_x=room_w*16
	cam_y=room_h*8
	--move the plr to tr area
	plr.x=((plr.x+4)%(room_w*8))+room_w*16-4
	plr.y=((plr.y)%(room_h*8))+room_h*8
	--copy this room to tr area
	local this_room=layout[room_y][room_x]
	load_room(this_room,room_w*2,room_h,0,true)
	--based on direction...
	if direct=="right" then
		plr.x+=room_w*8
		local next_room=layout[room_y][room_x+1]
		load_room(next_room,room_w*3,room_h,0,true)
		room_x+=1
	else
		plr.x-=room_w*8
		local next_room=layout[room_y][room_x-1]
		load_room(next_room,room_w,room_h,room_h,0,true)
		room_x-=1
	end
	actors={plr}
	partics={}
	if scroll_dir=="horiz" then
		scroll_dir="verti"
		clear_top_row()
	else
		scroll_dir="horiz"
		clear_side_row()
	end
	--clear the checkpoint text
	if word_behaviour=="check" then
		word=""
	end
end

function play_music(num)
	if (current_music!=num) music(num)
	current_music=num
end

function respawn()
	room_x=check_room_x
	room_y=check_room_y
	scroll_dir=check_scroll_dir
	plr.x=60
	plr.y=40
	plr.grav=0
	plr.f=check_flip
	plr.s=0
	cam_x=0
	cam_y=0
	actors={plr}
	hp=max_hp
	clear_top_row()
	rm=load_room(layout[room_y][room_x],0,0,rm_enemies[room_y][room_x],rm_doors[room_y][room_x])
	wipe_transition=131
	wall_pal=check_room_pal
end

function unlock()
	rm_doors[room_y][room_x]=true
end

function update_gate()
	if(gate_counter==nil) gate_counter=0
	if gate_counter>0 then
		gate_counter-=1
		return
	end
	open_gate=false
	local cx=cam_x/8
	local cy=cam_y/8
	for y=cy,cy+16 do
		for x=cx,cx+16 do
			tile=mget(x,y)
			tile2=mget(x,y+1)
			if fget(tile,3) and not fget(tile2,3) then
				if tile==107 then
					mset(x,y,85)
				else
					mset(x,y,107)
				end
				open_gate=true
				gate_counter=5
				sfx(21)
				return
			end
		end
	end
end
-->8
--draw--

function _draw()
	if game_mode=="title" then
		draw_title()
		return
	end
	draw_gui()
	set_room_pal(
		rm_cols[room_y][room_x]
	)
	draw_map()
	--draw_debug()
	--draw_debug_map()
	draw_word()
	draw_hud()
	if (plr.egg)	outline_text("press 🅾️/z!",24,36+sin(sine_timer)*1.5,8)
	if win then
		msg="on the title screen\nenter ⬇️⬇️⬅️⬇️➡️ to\ntry a new challenge"
		if hard_mode then
			msg="  excellent work!\n  you have beaten\n  challenge mode!"
		end
		outline_text(msg,26,40,1)
	end
end

function draw_title()
	cls()
	draw_partics()
	--draw the title
	sin_val=sin(sine_timer)*2-10
	camera(-2,sin_val)
	for i=2,5 do
		spr(i+7,8*i,0)
	end
	for i=1,6 do
		spr(i+22,8*i,8)
	end
	for i=0,7 do
		spr(i+39,8*i,24)
	end
	spr(13,29,16)
	camera()
	if ((sine_timer*2)%1>0.4)	outline_text("press ❎",16,54,1)
	--these label the modes
	--but i don't really like them
	--if (hard_mode)	outline_text("challenge mode",4,35-sin_val,11)
	--if (slow_mode)	outline_text("slow mode",14,35-sin_val,12)
end

function outline_text(str,x,y,c,back_col)
		back_col=back_col or 7
		if back_col!=0 then
  	for i=x-1,x+1 do
  		for j=y-1,y+1 do
  			print(str,i,j,back_col)
  		end
  	end
 	end
 	print(str,x,y,c)
end

function draw_word()
	--if (#word==0) return
	word_timer+=0.25
	if (word_timer>#word)	word_timer=0
	local x=64-#word
	local len=#word/2
	for i=1,len do
		local y=8+v_offset
		local y2=16+v_offset
		if flr(word_timer)==i then
			y+=1
		elseif flr(word_timer)==i-2 then
			y-=1
		end
		if flr(word_timer)==i+len then
			y2+=1
		elseif flr(word_timer)==i-2+len then
			y2-=1
		end
		bc=7
		if (word=="checkpoint") bc=0
		outline_text(sub(word,i,i),x,y,word_col,bc)
		outline_text(sub(word,i+len,i+len),x,y2,word_col,bc)
		x+=4
	end
end

--draw gui elements
function draw_hud()
	draw_hp()
	draw_minimap()
	draw_got_items()
end

function draw_hp()
	local y_pos=72
	for i=0,max_hp-1,2 do
		spr(61,4+i*4,y_pos)
	end
	for i=1,hp do
		if i%2==1 then
			spr(60,i*4,y_pos)
		else
			spr(59,-4+i*4,y_pos)
		end
	end
end

function draw_minimap()
	for i=3,69,3 do
		for j=0,39,3 do
			--draw guide dots.
			pset(55+i,82+j,5)
		end
	end
	for i=0,22 do
		for j=0,13 do
			draw_minimap_room(i,j)
		end
	end
	local plr_x=55+room_x*3+1
	local plr_y=82+room_y*3+1
	if ((sine_timer*2)%1>0.5) rect(plr_x,plr_y,plr_x+1,plr_y+1,11)
end

function draw_minimap_room(x,y)
	local explored=explored_rooms[x][y]
	if (not explored) return
	local room=rooms[layout[y][x]]
	local map_x=55
	local map_y=82
	local x_corner=55+3*x
	local y_corner=82+3*y
	local col=10
	local side_col={}
	for i=0,3 do
		side_col[i]=2
	end
	if (room["save"])	col=12
	if (room["item"])	col=9
	if explored=="verti" then
 	if (room["up"]=="open") side_col[1]=col
 	if (room["down"]=="open") side_col[3]=col
 	if (room["left"]=="open") side_col[2]=8
 	if (room["right"]=="open") side_col[0]=8
	else
		side_col[0]=col
		side_col[2]=col
		if (room["left_stop"]) side_col[2]=8
 		if (room["right_stop"]) side_col[0]=8
		if (room["left"]=="wall") side_col[2]=2
 		if (room["right"]=="wall") side_col[0]=2
	end
	--the centre of the room
	rectfill(x_corner,y_corner,
		x_corner+3,y_corner+3,col)
	--the outside corners
	rect(x_corner,y_corner,
		x_corner+3,y_corner+3,2)
	--top edge
	rectfill(x_corner+1,y_corner,
		x_corner+2,y_corner,
		side_col[1])
	--bottom edge
	rectfill(x_corner+1,y_corner+3,
		x_corner+2,y_corner+3,
		side_col[3])
	--right edge
	rectfill(x_corner+3,y_corner+1,
		x_corner+3,y_corner+2,
		side_col[0])
	--left edge
	rectfill(x_corner,y_corner+1,
		x_corner,y_corner+2,
		side_col[2])
end

function draw_got_items()
	draw_got_item(got_double_jump,85,49,"double jump")
	draw_got_item(got_fireball,95,50,"fireball")
	draw_got_item(got_charge,105,51,"charge")
	--draw_got_item(got_belly_flop,115,52,"belly flop")
	--keys
	spr(53,108,72)
	print(keys,120,73,7)
	--eggs
	for i=1,eggs do
		spr(53+i,49+i*10,71)
	end
end

function draw_got_item(var,y,s,text)
		if (not var) return
		spr(s,3,y)
		print(text,13,y+1,7)
end

function draw_init()
	v_offset=2
	bg_col=0
	--palette info
	wall_pal="grey"
	grass_pal="green"
	stone_pal="grey"
	rm_pals={}
	rm_pals["red"]={2,8,14}
	rm_pals["grey"]={5,6,13}
	rm_pals["green"]={3,11,10}
	rm_pals["blue"]={1,12,13}
	rm_pals["lilac"]={13,6,7}
	rm_pals["lilac2"]={13,7,6}
end

function set_room_pal(p)
	--these are the room palettes
	local pals={}
	--walls, grass, stone
	--pals["1"]={"grey","green","grey"}
	pals["1"]=split_string("grey,green,grey")
	--pals["2"]={"grey","lilac","blue"}
	pals["2"]=split_string("grey,lilac,blue")
	pals["3"]=split_string("lilac,lilac,blue")
	pals["4"]=split_string("lilac,green,grey")
	pals["5"]=split_string("grey,green,lilac2")
	pals["6"]=split_string("blue,green,lilac2")
	pals["7"]=split_string("grey,red,green")
	pals["8"]=split_string("red,red,green")
	pals["9"]=split_string("green,green,grey")
	pals["a"]=split_string("blue,green,grey")
	--get the correct ones
	local palette=pals[p]
	--return if no palette required
	if (palette==nil) return
	--set these palettes
	wall_pal=palette[1]
	grass_pal=palette[2]
	stone_pal=palette[3]
end

function draw_map()
	clip(0,v_offset,128,64)
	camera(cam_x,cam_y-v_offset)
	rectfill(0,0,127,127,bg_col)
	set_map_palette()
	map(0,0,0,0,map_w,map_h)
	pal()
	foreach(actors,draw_actor)
	draw_partics()
	set_map_palette()
	map(0,0,0,0,map_w,map_h,0b00000010)
	draw_wipe()
	pal()
	clip()
	camera()
end

--draw the wipe transition
function draw_wipe()
	if wipe_transition>0 then
		rectfill(128,0,131-wipe_transition,128,0)
	end
end

--draw currently loaded partics
function draw_partics()
	foreach(partics,draw_partic)
end

--draw an actor
function draw_actor(a)
	if a.invul!=nil and a.invul%4>1 then return end
	local y=a.y
	if a.up != nil then
		y-=a.up
	end
	actor_pal(a.pal)
	vf=a.vf
	if (vf==nil) vf=false
	spr(a.s,a.x,y,1,1,a.f,vf)
	pal()
	draw_actor_healthbar(a)
end

function draw_actor_healthbar(a)
	--make sure the actor has health
	if a.hp==nil or a.max_hp==nil then return end
	--don't draw when full.
	if a.hp>=a.max_hp then return end
	--don't draw with no health.
	if a.hp<=0 then return end
	--how full is it?
	size=(a.hp/a.max_hp)*8
	--fill the red bit of the bar
	rectfill(a.x,a.y-4,a.x+size-1,a.y-2,8)
	--draw outside border.
	rect(a.x-1,a.y-4,a.x+8,a.y-2,5)
end

--draw a partic
function draw_partic(p)
	pset(p.x,p.y,p.c)
	--all partics are mirrored on title
	if game_mode=="title" then
		pset(63-p.x,58-p.y,p.c)
	end
end

function set_map_palette()
	set_grass(get_pal(grass_pal))
	set_wall(get_pal(wall_pal))
	set_stone(get_pal(stone_pal))
end

function set_grass(p)
	pal(3,p[1])
	pal(11,p[2])
	pal(10,p[3])
end

function set_wall(p)
	pal(1,p[1])
	pal(12,p[2])
end

function set_stone(p)
	pal(5,p[1])
	pal(6,p[2])
	pal(13,p[3])
end

function get_pal(name)
	return rm_pals[name]
end

function draw_gui()
	--rectfill(0,0,127,127,0)
	cls()
	line(0,v_offset-2,128,v_offset-2,7)
	line(0,v_offset+room_h*8+1,128,v_offset+room_h*8+1,7)
end
-->8

-->8


-->8
--actors--

function update_actors()
	for a in all(actors) do
		local name=a.name
		if name=="killme" then
			a.dead=true
		elseif a.enemy then
			update_enemy(a)
		elseif name=="save" then
			update_save(a)
		elseif name=="item" then
			update_item(a)
		elseif name=="save_recreator" then
			update_save_recreator(a)
		elseif name=="fireball" then
			update_fireball(a)
		else
		end
		if a.dead then
			del(actors,a)
		end
	end
end

--make moving explosion partics
--cx and cy are the centre.
function explode_actor(a,cx,cy,str)
	if cx==nil then
		cx=a.x+3.5
	end
	if cy==nil then
		cy=a.y+3.5
	end
	if str==nil then str=1 end
	rectfill(0,0,7,7,0)
	actor_pal(a.pal)
	spr(a.s,0,0,1,1,a.f)
	pal()
	for x=0,7 do
		for y=0,7 do
			col=pget(x,y)
			if col!=0 then
				p=new_partic(x+a.x,y+a.y,col,24+rnd(16))
				p.xv=(p.x-cx)*str*explode_rnd()
				p.yv=(p.y-cy)*str*explode_rnd()
				p.xa=0
				p.ya=0.1
				add_partic(p)
			end
		end
	end
end

--returns true if they touch
function actors_intersect(a,b)
	if a.x+8<b.x then return false end
	if b.x+8<a.x then return false end
	if a.y+8<b.y then return false end
	if b.y+8<a.y then return false end
	return true
end

--checks exact pixel collisions
function actors_intersect_adv(a,b)
	--must pass simple test first.
	if not actors_intersect(a,b) then return false end
	--scratchpad area
	rectfill(0,0,16,8,0)
	--draw both sprites to screen
	spr(a.s,0,0,1,1,a.f)
	spr(b.s,8,0,1,1,b.f)
	--calculate differences.
	x_dif=b.x-a.x
	y_dif=b.y-a.y
	for x=max(0,x_dif),min(7,7+x_dif) do
		for y=max(0,y_dif),min(7,7+y_dif) do
			a_pix=pget(x,y)
			b_pix=pget(8+x-x_dif,y-y_dif)
			--if two pixels overlap...
			if a_pix!=0 and b_pix!=0 then
				return true
			end
		end
	end
	--no collision
	return false
end

function update_save(a)
	local collide=false
	for b in all(actors) do
		if b.name=="savepart" or b.name=="save" then
			if actors_intersect(b,plr) then
				collide=true
			end
		end
	end
	if collide then
		local cx=a.x+7.5
		local cy=a.y+7.5
		local str=0.4
		for b in all(actors) do
			if b.name=="savepart" or b.name=="save" then
				explode_actor(b,cx,cy,str)
				b.dead=true
			end
		end
		sfx(5)
		word="checkpoint"
		word_col=12
		word_behaviour="check"
 	check_room_x=room_x
 	check_room_y=room_y
 	check_scroll_dir=scroll_dir
 	check_flip=plr.f
 	check_room_pal=wall_pal
 	hp=max_hp
	end
end

function update_item(a)
	if item_move_down>0 then
		a.y+=1
		item_move_down-=1
		play_music(8)
		for i=0,3 do
			a.g[i].y+=1
		end
	end
	if a.timer==0 then
		for i=0,3 do
			--make the glow flicker
			a.g[i].s=95-a.g[i].s
		end
		a.timer=4
	else
		a.timer-=1
	end
	if actors_intersect(a,plr) then
		open_gate=true
		a.dead=true
		for i=0,3 do
			--kill the glowy parts
			a.g[i].dead=true
			a.g[i].s=15
		end
		play_music(1)
		if a.s==48 then
			word="extraheart"
			max_hp+=2
			hp=max_hp
		elseif a.s==49 then
			word="double jump "
			got_double_jump=true
		elseif a.s==50 then
			word="fireball  (❎ )  "
			got_fireball=true
		elseif a.s==51 then
			word="fireball charge "
			got_charge=true
		elseif a.s==52 then
			word="bellyflop!"
			got_belly_flop=true
		elseif a.s==53 then
			word="magic key "
			keys+=1
		else
			word="dragon egg          "
			eggs+=1
			hp=max_hp
			if eggs==4 then
				win=true
				play_music(11)
			end
		end
		word_col=8
		word_behaviour="check"
		item_wait=110
		rm_items[room_y][room_x]=0
	end
end

function new_fireball(x,y,f,big)
	if big==nil then big=false end
	if not big then
		a=new_actor(x+2,y+2,7)
		a.spd=2
		a.w=4
	else
		a=new_actor(x+1,y+1,8)
		a.spd=1.5
		a.w=6
	end
	a.direc=f
	if f then a.x-=4 else a.x+=4 end
	a.big=big
	a.name="fireball"
	return a
end

function update_fireball(a)
	if a.direc then
		a.x-=a.spd
	else
		a.x+=a.spd
	end
	--check what it hits.
	for b in all(actors) do
		if b.name=="block" then
			local x=a.x
			if a.direc then
				a.x-=a.spd
			else
				a.x+=a.spd
			end
			if actors_intersect_adv(a,b) then
				destroy_block(b,a.x+a.w/2,a.y+a.w/2)
				a.dead=true
				sfx(33)
			end
			a.x=x
		elseif b.enemy and actors_intersect_adv(a,b) then
			local damage=1
			if a.big then damage=3 end
			hit_enemy(b,damage,a)
			a.dead=true
		end
	end
	--partic trail
	local x=a.x+rnd(a.w-1)
	local y=a.y+rnd(a.w-1)
	local col=8+rnd(2)
	if a.x+a.w<cam_x or
				a.x-128>cam_x then
		a.dead=true
	end
	if is_solid(a.x,a.y)
	or is_solid(a.x+a.w,a.y)
	or is_solid(a.x,a.y+a.w)
	or is_solid(a.x+a.w,a.y+a.w) then
		a.dead=true
		local cx=a.x
		if not a.direc then
			cx+=a.w
		end
		explode_actor(a,cx,a.y+a.w-1,0.25+rnd(0.5))
	end
	if not a.dead then
		p=new_partic(x,y,col,1+a.w)
		add_partic(p)
	end
end

function destroy_block(a,cx,cy)
	unlock()
	--strength of explosion
	explode_actor(a,cx,cy,0.15)
	a.dead=true
	tilx=a.x/8
	tily=a.y/8
	mset(tilx,tily,mget(tilx-1,tily,0))
	for b in all(actors) do
		if b.name=="block" and not b.dead then
			destroy_block(b,cx,cy)
		end
	end
end

--update all enemies
function update_enemy(a)
	if actors_intersect_adv(a,plr) then
		hit_plr(a,a.damage)
	end
	local name=a.name
	if name=="beetle" then
		update_beetle(a)
	elseif name=="jellyfish" then
		update_jellyfish(a)
	elseif name=="slime" then
		update_slime(a)
	elseif name=="skeleton" then
		update_skeleton(a)
	elseif name=="skull" then
		update_skull(a)
	elseif name=="bat" then
		update_bat(a)
	end
end

--hit an enemy with a fireball
function hit_enemy(a,damage,fb)
	a.hp-=damage
	if a.hp<=0 then
		a.dead=true
		--find the centre for explosion
		local cx=fb.x+fb.w/2
		local cy=fb.y+fb.w/2
		--explode this sprite.
		explode_actor(a,cx,cy,0.2*damage)
		sfx(9)
		num_enemy=0
		for i in all(actors) do
			if i.enemy then
				num_enemy+=1
			end
		end
		if num_enemy<=1 then
			item_move_down=24
		end
	else
		sfx(8)
	end
end

function update_beetle(a)
	if a.timer==nil then a.timer=0 end
	a.timer+=1
	if a.timer>8 then
		a.timer=0
		a.s=33-a.s
		if a.f then
			a.x-=1
		else
			a.x+=1
		end
		if is_in_wall(a)
		or not is_solid(a.x-1,a.y+8)
		or not is_solid(a.x+8,a.y+8) then
			a.f=not a.f
			if a.f then
 			a.x-=1
 		else
 			a.x+=1
 		end
		end
	end
end

function update_slime(a)
	--fall up or down.
	if a.s==22 then
			local fspeed=2^a.lv --fall speed
			if a.vf then
				a.y+=fspeed
			else
				a.y-=fspeed
			end
			if is_solid(a.x+4,a.y) or is_solid(a.x+4,a.y+7) then
				a.y+=fspeed
				if a.vf then
					a.y-=2*fspeed
				end
				a.vf=not a.vf
				a.s=20
			end
		return
	end
	if a.timer==nil then a.timer=0 end
	a.timer+=1
	if a.timer>6-a.lv then
		local d=a.x>plr.x
		a.timer=0
		a.s=41-a.s
		if d then
			a.x-=1
		else
			a.x+=1
		end
		if is_in_wall(a) then
			if d then
 			a.x+=1
 		else
 			a.x-=1
 		end
		end
		--fall on the player
		if a.vf and abs(plr.x-a.x)<16 then
			a.s=22
		elseif not a.vf and abs(plr.x-a.x)<8 and a.lv>1 then
			a.s=22
		else
			addition=8
			if (a.vf) addition=-1
 		if not is_solid(a.x-1,a.y+addition)
 			or not is_solid(a.x+8,a.y+addition) then
 			a.s=22
 		end
		end
	end
end

function update_jellyfish(a)
	if a.state=="wait" then
		if abs(a.x-plr.x)<32-6*a.lv then
			a.state="hop"
		end
		a.anim+=1
		if a.anim==10 then
			a.y+=1
		elseif a.anim>=20 then
			a.y-=1
			a.anim=0
		end
	elseif a.state=="hop" then
		a.y-=4
		a.s=19
		if a.y<=a.hop then
			a.state="float"
			a.anim=0
		end
	else
		a.anim+=1
		if a.anim==10-2*a.lv then
			a.s=18
			a.y+=1
		elseif a.anim>=20-4*a.lv then
			a.s=19
			a.anim=0
			a.y+=1
		end
		if a.y>=53 then
			a.y=53
			a.anim=0
			a.state="wait"
		end
	end
end

function update_skeleton(a)
	a.hp=min(a.hp,a.skull.hp)
	a.skull.hp=a.hp
	a.skull.damage=a.damage
	a.skull.pal=a.pal
	xdif=a.x-plr.x
	max_s=0.15*(a.lv+3)
	if xdif>0 then
		a.mom=max(-max_s,a.mom-0.1)
	else
		a.mom=min(max_s,a.mom+0.1)
	end
	if abs(xdif)>72 then
		a.mom=0
	end
	update_mom(a)
	gravity(a)
	a.skull.f=xdif>0
	a.f=a.mom<=0
	a.skull.x=a.x
	a.skull.y=a.y-5-a.up
	animate_walk(a,35,3)
 --jump code
 local fbdif=64
 local plrdif=64
 for b in all(actors) do
 	if(b.name=="fireball")	fbdif=min(fbdif,abs(b.x-a.x-2))
 	if(b.name=="plr")	plrdif=min(plrdif,abs(b.x-a.x))
 end
	if is_on_ground(a) and (fbdif<12 or plrdif<4) then
		a.grav=-3-a.lv/2
		sfx(3)
	end
	if (a.skull.dead) a.dead=true
end

function update_bat(a)
	if to_lock_room then
		boss_gate_timer=24
		to_lock_room=false
	end
	a.s=74+(a.sine_timer*12)%3
	if a.pause>0 then
		a.pause-=1
		a.pal=nil
		if (a.pause%4<2)	a.pal="flash"
		return
	end
	a.x+=(a.goal_x-a.x)/8
	a.y+=(a.goal_y-a.y)/8
	a.sine_timer+=0.01*a.lv
	if rnd(100)<1 then
		a.sine_timer+=0.5
		a.pause=30
		return
	end
	if (a.sine_timer>=1) a.sine_timer-=1
	a.goal_x=plr.x+sin(a.sine_timer)*a.len
	a.goal_y=plr.y+cos(a.sine_timer)*a.len
end

function update_skull(a)
	if (a.body.dead)	gravity(a)
end

function animate_walk(a,s)
	if (rate==nil) rate=1
	a.anim+=abs(a.mom)*rate
	if a.mom==0 then
		a.anim=0.9
		a.s=s
	end
	if a.anim<5 then
		a.up=a.s-s
	else
		a.up=1+a.s-s
	end
	if a.anim>8 then
		a.anim=0
		a.s=s*2+1-a.s
	end
end

function actor_pal(name)
	if name==nil then return end
	if name=="flash" then
		pal(11,7)
		pal(3,6)
		pal(8,9)
	elseif name=="red" then
		pal(11,14)
		pal(3,8)
		pal(8,9)
	elseif name=="blue" then
		pal(11,13)
		pal(3,1)
		pal(1,2)
	elseif name=="white" then
		pal(11,7)
		pal(3,6)
		pal(1,5)
	end
end
-->8
--player functions--

function update_plr()
	--as an egg
	if plr.egg then
		if btnp(4) then
			explode_actor(plr)
			plr.egg=false
			play_music(2)
		end
		return
	end
	--check for gates
	local rm_i=rm_items[room_y][room_x]
	if (is_gate(plr.x+12,plr.y)
		or is_gate(plr.x-4,plr.y)) then
 	if keys>0	and rm_i == "/" then
 		keys-=1
 		open_gate=true
 		unlock()
 	elseif eggs>=3	and rm_i == "!" then
 		open_gate=true
 		unlock()
 	end
	end
	if hp<=0 then return end
	if plr.invul==nil then
		plr.invul=0
	else
		if plr.invul>0 then
			plr.invul-=1
		end
	end
	plr.prev_x=plr.x
	mom_by_arrows(plr)
	update_mom(plr)
	gravity(plr)
	if btn(4) then
		if jump_pushed==nil then
			jump_pushed=true
 		if is_on_ground(plr) then
 			plr.grav=-4
 			sfx(3)
 		elseif got_double_jump and
 									plr.spin==-1 then
 			plr.grav=-3
 			plr.spin=0
 			sfx(4)
 		end
 	end
	else
		jump_pushed=nil
	end

	--check for fireballs
	shoot_fireballs()

	if is_on_ground(plr) then
		plr.spin=-1
	end

	anim_plr()

	--transition on screen edge
	if plr.x<cam_x-4 then
		tr_start("left")
	elseif plr.x>cam_x+124 then
		tr_start("right")
	end

	if is_lava(plr.x+4,plr.y+8) then
		hit_plr(plr,2)
		plr.grav=-5
	end
end

function shoot_fireballs()
	if (not got_fireball) return
	if btn(5) then
		fireball_timer+=1
		if got_charge and fireball_timer==charge_time then
			sfx(7)
		end
	else
		if fireball_timer>0 then
			if got_charge and fireball_timer>=charge_time then
				a=new_fireball(plr.x,plr.y,plr.f,true)
				sfx(1)
			else
				a=new_fireball(plr.x,plr.y,plr.f)
				sfx(0)
			end
			add_actor(a)
		end
		fireball_timer=0
	end
end

function anim_plr()
	if plr.mom>0 then
		plr.f=false
	elseif plr.mom<0 then
		plr.f=true
	end
	if not is_on_ground(plr) then
		plr.s=1
		if plr.spin!=-1 then
			plr.s=plr.spin+2
			plr.spin+=0.25
			local p=new_partic(plr.x+1+rnd(6),plr.y+1+rnd(6),11,5+rnd(3))
			local p=new_partic(plr.x+1+rnd(6),plr.y+1+rnd(6),10,5+rnd(3))
			add_partic(p)
			if plr.spin>=4 then
				plr.spin=0
			end
		end
	else
		if plr.s>1 then
			plr.s=0
		end
 	animate_walk(plr,0)
	end
	if fireball_timer>=charge_time and got_charge then
		plr.pal=nil
		if (fireball_timer%4<2)	plr.pal="flash"
	else
		plr.pal=nil
	end
end

function hit_plr(a,damage)
	if plr.invul==0 then
		hp-=damage
		plr.invul=60
		sfx(10)
		--fly off when hit! pew!
		if plr.x<a.x then
			plr.fly=-10
		else
			plr.fly=10
		end
		if is_on_ground(plr) then
			plr.grav=-2
		end
		if hp<=0 then
			respawn_timer=120
			plr.fly=0
			plr.invul=0
			plr.grav=0
			explode_actor(plr)
			plr.s=15
			play_music(-1)
			sfx(18)
			deaths+=1
		end
	end
end