-- burger age
-- by owljey
-- 2018-

--lrudox
--⬅️➡️⬆️⬇️🅾️❎



max_actors = 128
gtick=0
actorb={}
actorm={}
actorf={}
sparcle={}
player=nil --obj
cam=nil --obj
pans={} --obj

stage_x={0, 0,32,32,64,64} -- stage 1,2,3,4,5,6
stage_y={0,16, 0,16, 0,16}
stx=0 sty=0
dpal={0,1,1, 2,1,13,6,4,4,9,3, 13,1,13,14}

mes="--"

--- util ----------------------
function ret_value( flag , v1 , v2 )
	if  flag == true  then
	  return v1
	else
	  return v2
	end
end

function intrnd(num)
	return flr(rnd(num))
end

function xspr(pt,px,py,wd,ht,a) ---screen spr
		spr(pt,(px-stx)*8,(py-sty)*8,wd,ht,a.direct)
end
--- sparkle -------------------

	--s.size=1 --- 1:8x8  2:16x16
	--s.motion=0 --- +1 patern timing ,if =5 , motion_t,frame+=(+s.size)

xsparkle = {
		t=0 , max_t=8+intrnd(4),	
		dx=0,dy=0,ddx=0,ddy=0,
		dir=false, size=1, motion=0,col=0
		,drawfunc=function(a)
				if a.col > 0 then
					for i=1,15 do
						pal(i,a.col)
					end
				end
				spr(a.frame, (a.x-stx)*8-4, (a.y-sty)*8-4,a.size,a.size,a.dir)
				if a.col >0 then
					pal()
				end
			end
}

function make_sparkle(x,y,frame)
	local s = {
		x=x , y=y , frame=frame
	}
	setmetatable(s,{__index=xsparkle})
	add(sparkle,s)
	return s
end

function move_sparkle( sp )
	if sp.t > sp.max_t then
		del(sparkle,sp)
	end

	sp.x = sp.x + sp.dx
	sp.y = sp.y + sp.dy
	sp.dy= sp.dy+ sp.ddy
	sp.dx= sp.dx+ sp.ddx
	sp.t = sp.t + 1
end

function draw_sparkle(s)
	s:drawfunc()
end

---- sparkles custom -----
---- explode
function make_sparkles_explode( pl )
    for i=1,10 do
     local s=make_sparkle(pl.x+0.5, pl.y, 57+intrnd(3))
     s.dx = s.dx + rnd(0.4)-0.2
     s.dy = s.dy + rnd(0.4)-0.2
     s.max_t = 30 
     s.ddy = 0.01
    end
end

---- star
function make_sparkles_star( pl )
    for i=1,10 do
		local s=make_sparkle(pl.x+2.0, pl.y+1.0, 57+rnd(3))
		s.dx = s.dx + rnd(0.4)-0.2 --pl.dx
		s.dy = s.dy + rnd(0.4)-0.2 --pl.dy
		s.max_t = 20 
		s.col= ret_value(rnd(2) < 1,10,7)
		
    end
end

--- pl.ddx actor
function make_sparkles_yuge(pl)
	 for i=1,2 do
		local s = make_sparkle(pl.x+rnd(pl.wh), pl.y-0.8, 24)
     	s.dx = 0 --cos(i/32)/2
     	s.dy = -0.05 - rnd(1)/6
	 	s.motion=3
     	s.max_t=90
		s.drawfunc=function(a)
				if a.t<=80 and a.t % 40 == 0 then
					a.frame=a.frame+a.size
				end
				spr(a.frame, (a.x-stx)*8-4, (a.y-sty)*8-4,a.size,a.size,a.dir)
			end
	end
end

---- dead
function make_sparkles_dead(pl) --darumaster
    for i=1,32 do
     local s=make_sparkle( pl.x, pl.y-0.6, 57)
     s.dx = cos(i/32)/2
     s.dy = sin(i/32)/2
     s.max_t = 30 
     s.ddy = 0.01
	 local pt={96,97,98,99}
     s.frame=pt[intrnd(4)+1]
    --s.col = 7
    end
end

---- dead
function make_sparkles_miss(pl) --mychara
    for i=1,32 do
     local s=make_sparkle( pl.x, pl.y-0.6, 57)
     s.dx = cos(i/32)/2
     s.dy = sin(i/32)/2
     s.max_t = 20
     s.ddy = 0.01
	 local pt={57}
     s.frame=57
     s.col = intrnd(16)+1
    end
end


---- hokori in jump
function make_sparkles_jumpdust(a)
     local s=make_sparkle( a.x+1, a.y+2, 58)
     s.dx = a.direct and 0.1 or -0.1
     s.dy = 0
     s.max_t = 10
     s.ddy = 0.02
     s.col = 6 --light gray 5 --dark gray
end

---- hokori in grand
function make_sparkles_granddust(a)
    for i=1,2 do
     local s=make_sparkle( a.x+1, a.y+2.0, 240)
     s.dx =  i==1 and 0.2 or -0.2
     s.dir =  i==1 and true or false
     s.dy = 0
     s.max_t = 5
     s.ddy = -0.01
     s.ddx = s.dx/8
     --s.col = 5 --dark gray
	end
end


---- large-burger rain
function make_sparkles_burgerrain(a)
	-- burger rotate pattern  -- (1*16-4*16,4*16)temp sprite area	
	--ex rotate_ssss(0*16,5*16,2*16,4*16,16,16,0.125+0.25)
	rotate_ssss(0,80,1*16,4*16,16,16,0.125)
	rotate_ssss(0,80,2*16,4*16,16,16,0.125+0.35) -- 0.25
	rotate_ssss(0,80,3*16,4*16,16,16,0.125+0.5)
	rotate_ssss(0,80,4*16,4*16,16,16,0.125+0.70) -- 0.75

    for i=1,15 do
		local sp= 130+intrnd(4)*2
		local s=make_sparkle(stx+rnd(32), sty, sp)
		s.size=2
		local dd=rnd(0.4)+0.2
		s.dx=(dd-0.3)/4 --0-dd
		s.dy=dd
		s.max_t = 150
    end
end


--- actor (base-util)-------------------
function move_empty(a)
	-- empt func
end
function draw_caller(a)
	if a.blct>0 then
		a.blct=a.blct-1
		if a.blct%a.blrt==0 then --blink
			return
		end
	end

	a:drawfunc()
end

function del_sub_actor(a,ar)
		for i=1,count(ar) do
			local x=ar[i]
			if x.parent==a then
				x.stat=99
			end
		end	
end

function del_actor(a)
	if a.haschild then -- a's children is finish stat.
		del_sub_actor(a,actorb)
		del_sub_actor(a,actorm)
		del_sub_actor(a,actorf)	
	end
	a.kind= -1
	a.stat= -1
	if a.zorder==0 then
		del(actorb,a)
	elseif a.zorder==1 then
		del(actorm,a)
	else
		del(actorf,a)
	end
end

xactor = {
	dx=0 ,dy=0 , stat=0 , zorder=1,
	ct=0,blct=0,blrt=0,
	parent=nil , haschild=false , attacker=nil , hide=false,
	movefunc=move_empty
	,drawfunc=move_empty	
	,statdel=move_empty
}

planes={actorb,actorm,actorf}
--- actor (base)-------------------
function make_actor(kind,x,y,direct,z)
	local a = {
		kind = kind , x=x,y=y , diret=direct ,
		zorder=z
	}
	setmetatable(a, {__index=xactor})
	--a.kind = kind -- 0-19 ..deleted obje when gameover , 20- ..  
	--a.stat = 0 -- dead:0 or alive:1- , -1:not use
	if count(actorb)+count(actorm)+count(actorf) < max_actors then
		add(planes[a.zorder+1],a) -- actorbヤやおactorf
 	end
	return a
end

xcharactor = {
	dx=0 ,dy=0 , stat=0 , zorder=1,
	ct=0, blct=0,blrt=0,
	parent=nil , haschild=false , attacker=nil , hide=false,
	movefunc=move_empty
	,drawfunc=function(a)
			if a.stat>0 and a.hide==false then
			 	xspr(a.pt[a.pn],a.x,a.y,2,2,a) --draw
			end	
		end
	,statdel=function(a)
			make_vanish( a.x , a.y ,false )	
		end

	,hitandattack=function(a)
		if  hitcheck_player(a,true)==true then
			make_tilt()
		end

		if  hitcheck_myattack(a)==true then
			a.stat=47
		end
	end		
}


function make_charactor(kind,x,y,direct,z)
	local a = {
		kind = kind , x=x,y=y , diret=direct ,
		zorder=z, stat=1
	}
	setmetatable(a, {__index=xcharactor})
	--a.kind = kind -- 0-19 ..deleted obje when gameover , 20- ..  
	--a.stat = 0 -- dead:0 or alive:1- , -1:not use
	if count(actorb)+count(actorm)+count(actorf) < max_actors then
		add(planes[a.zorder+1],a) -- actorbヤやおactorf
 	end

	return a
end


function move_actor(a)
	if a.stat>=0 then
		a:movefunc()
		a.ct=a.ct+1
		if a.stat==99 then
			a:statdel()
			del_actor(a)
		end
	end
end

--- actor - tilt -------------
function make_tilt(x,y)
	local a = make_actor(21,0,0,false) --tilt
	a.movefunc=function(a)
		if a.ct<15 then
			cdx = (rnd(8)-4 )/4
			cdy = (rnd(8)-4 )/4
		else -- destroy
			cdx = 0
			cdy = 0
			a.stat=99	
		end	
	end
	return a
end

--- actor - flash -------------
function make_flash(col)
	local a=make_actor(20,0,0,false,2) --flash
	-- last order is for flash
	a.drawfunc=function(a)
		--printh( "fal "..a.duration  , "log" , false )
		if  a.ct<4  then
			pal( a.dx , 7 , 1)	
		elseif  a.ct<8  then
			pal( a.dx , 10 , 1)
		elseif  a.ct<10  then
			pal( a.dx , 8 , 1)	
		else -- destroy
			pal()
			a.stat=99
		--printh( "del "..a.duration  , "log" , false )
			return
		end
	end
	a.dx=col
	return a
end

--- actor - title -------------
function make_title(x,y)
	--printh("make_title" , "log") --dbg
	local a=make_actor(22,x,y,false,0) --title
	field_caller=title_field
	a.rad=0
	a.stat=0 -- title animation

--map hokan
	mset(2,9,2)	mset(3,9,3) --pans1
	mset(13,6,1) mset(14,6,2) mset(15,6,2) mset(16,6,3) --pans2


	a.movefunc=function(a)
		local at_max=30
		local at=ret_value( a.ct>at_max , at_max , a.ct)
		if  at==at_max and a.stat==0 then
			make_flash(8)
			make_tilt()
			a.stat=2
		end
		a.y=70-easing_out(at,0,60,at_max)


		if  btnp(4,0)  then -- title scene
			if a.stat~=1 then
				a.stat=1
				sfx(22,3)
			else
				sfx(12,3) -- burgetage start jingle

				a.stat=99
				fade_out()
				round_start()
			end
		end
	end

	a.drawfunc=function(a)
		local bx=camx+18
		local by=camy+20

		if a.stat==1 then
			spr(194,bx,by+a.y,12,2,a.direct) --"burger"
		else
			
			local xx=2.5
			for y=0,15 do
				local rad=(a.rad+x)/100
				local x=xx*sin(rad)
				local x2=xx*cos(rad+0.2)
				--sspr sx sy sw sh dx dy [dw dh] [flip_x] [flip_y]
				sspr(16,96+y,12*8,1, bx-x*2 ,by+y,12*8+x2*4,1) --"burger"
			end
			a.rad=(a.rad+0.5)%100
		end

		spr(228,bx+28,by+a.y+24,7,1,a.direct) --"age"
		textout("push 🅾️ key",bx+24,by+wavepos(1)+60,4) --"push @ key"
		spr(235,bx+14,by+98,3,1,a.direct) --"2018"
		spr(250,bx+40,by+98,5,1,a.direct) --"@owljey"

	end

	make_sparkles_burgerrain(a)
	music(-1,0,7)
	sfx(6,3)
	return a	
end


--- actor - over(gameover) -------------
function make_over(x,y)
	local a = make_actor(23,x,y,false,2) --over
	music(5,0,7)

	a.movefunc=function(a)
		local nowstat=a.stat
		if nowstat==1 then	-- flow up gameover 
			local at_max=30
			local at=ret_value( a.ct>at_max , at_max , a.ct)
			if  at==at_max then
				--make_flash(8)
				a.stat=2
				a.ct=0
			end
			a.y=70-easing_out(at,0,60,at_max)			
		elseif nowstat==2 then	-- wait	
			if  a.ct>70  then
				a.stat=3
				a.ct=0
			end
		elseif nowstat==3 then	-- title after wait
			if a.ct>20 and btnp(4,0) then --gameover
				a.stat=99
				--cam.x=0	cam.y=0 --gameover
				deal_gameover()
			end
		end
	end
	a.drawfunc=function(a)
		local bx = camx+50
		local by = camy+20

		if a.stat<4 then
			textout("game over",bx,by+a.y,9,4)
		end	
	end

	a.stat=1
	return a
end

--- actor - stclear(stageclear) -------------
function make_stclear(x,y)
	local a = make_actor(12,x,y,false,2) --stclear
	a.movefunc=function(a)
		local nowstat=a.stat
		if nowstat==1 then		-- init
			a.stat=2
		elseif nowstat==2 then	-- flow up message
			local at_max=30
			local at=ret_value( a.ct>at_max , at_max , a.ct)
			if  at==at_max then
				--make_flash(9)
				a.stat=3
				a.ct=0
				a.dy=a.y
			end
			a.y=70-easing_out(at,0,40,at_max)	
		
		elseif nowstat==3 then	-- wait
			a.y=a.dy+(1-rnd(2))/10
			if a.ct>70 then
				if stage_cnt>6 then --all clear
					player.stat=99
					local ov=make_over(a.x,a.y)
					ov.stat=2
				end
				--cam.x=stx	cam.y=sty
				a.stat=99
				return
			end	
		end
	end
	a.drawfunc=function(a)
		if a.stat<4 then
			textout(a.mes,camx+45,camy+a.y,9,3)
		end
	end
	a.stat=1
	stage_cnt=stage_cnt+1
	a.mes=ret_value(stage_cnt<6,"stage clear","all complated")
	return a	
end

--- actor - camera -------------
function make_camera(x,y)
	local a = make_actor(25,x,y,false)--camera 25 or 13
	-- a.x = 0*8 ... 32*8
	camx = x
	camy = y
	a.movefunc=function(a)
		if  player~=nil  then
			local diff=(player.x-stx)*8 - a.x

			a.dx=0
			if  diff > 52  then
				a.dx = min( 4.0 , (diff-52)/4 )
				a.x = min( a.x+a.dx , 16*8 )
			elseif  diff < 40  then
				a.dx = max( -4.0 , (diff-40)/4 )
				a.x = max( a.x+a.dx , 0 )
			end
		end
		camx=a.x
		camy=0 --a.y
	end
	return a
end


scsp={}
scsp[100]=32
scsp[200]=33
scsp[300]=34
--- actor - sceffect(add score effect) -------------
function make_sceffect(x,y,addsc)
	local a = make_actor(8,x,y,false,2) --sceffect
	a.movefunc=function(a)
		a.x=a.x+a.dx
		a.y=a.y+a.dy

		if a.stat==1 then
			a.dy=ret_value( a.dy < -0.08 , 0 , a.dy-0.02 )
			if a.ct>15 then
				a.stat=2
				a.dy=0.4
				a.ct=0
			end
		elseif a.stat==2 then
			a.dy = a.dy* -0.9
			if a.ct>30 then
				a.stat=99
			end
		end
	end
	a.drawfunc=function(a)
		if a.stat>0 then
			xspr(a.pn,a.x,a.y,a.wd,1,a) --sceffect
		end
	end

	a.stat=1
	a.x=a.x+0.4
	a.y=a.y-0.4
	a.pn=scsp[addsc]-- 100:32 2000:33 300:140
	a.wd=1
	a.dy= -0.02
	
	return a
end

--- actor - combffect(comb effect) -------------
function make_combeffect(x,y)
	local a = make_sceffect(x,y,100) --sceffect
	a.pn=224
	a.wd=3	
	return a
end
--- actor - scmultieffect(comb x2x3...effect) -------------
function make_scmultieffect(x,y,rate)
	local a = make_sceffect(x,y,100) --sceffect
	a.pn=35+rate
	return a
end




--- actor - vanish -------------
function make_vanish(x,y)
	local a = make_charactor(9,x,y,false) --vanish
	a.movefunc=function(a)
		a.x = a.x + a.dx
		a.y = a.y + a.dy

		if a.ct>10 then
			a.stat=99	
		end 
	end
	a.drawfunc=function(a)
		if a.ct<3 then
			pal( 6 , 6 , 0)
			pal( 10 , 7 , 0)
			pal( 7 , 0 , 0)
		elseif a.ct<6 then
			pal( 10 , 6 , 0)
		elseif a.ct<10 then
			pal( 6 , 0 , 0)
			pal( 10 , 0 , 0)
		end

		if a.stat>0 then
			xspr(78,a.x,a.y,2,2,a) --draw
		end	
		pal()
	end
	a.statdel=move_empty -- not necessary vanish
	a.stat = 1
	return a
end

--- actor - roundmanage(round_management) -------------
function make_roundmanage(x,y) -- round start reborn
	local a = make_actor(11,x,y,false) --roundmanage
	a.ct=1
	a.interval=ret_value(stage_cnt<4,800,350)
	a.interval=ret_value(stage_cnt==6,1600,a.interval) --last stage
		--printh("move_main..init", "log") --dbg

	a.move_main=function(a)
		--printh("move_main", "log") --dbg

		if a.ct%600==0 then
		end
		if a.ct%a.interval==0 then
		end
				
		--printh("move_main"..target_cnt, "log") --dbg
		if  target_cnt >= target_num then--check stage clear
		
			a.movefunc=a.move_stageclear	
		end	
	end
	a.move_stageclear=function(a)
		make_stclear( player.x , player.y )
		a.ct=1
		a.movefunc=a.move_nextstage	
	end	
	a.move_nextstage=function(a)
		if a.ct>70 then
			if stage_cnt<=6 then
				round_start() -- new roundmanage reborn
			end
			a.movefunc=a.move_delete
		end
	end	
	a.move_delete=function(a)
		music(-1,0,7)
		del_actor(a)
		a.movefunc=move_empty
	end
	
	a.movefunc=a.move_main

	return a
end


--- actor - debug marker -------------
function make_marker(x,y)
	local a = make_actor(30,x,y,false) --marker
	a.drawfunc=function(a)
		a.stat = a.stat and	spr(16,a.x,a.y,1,1,a.direct) --debug marker
	end
	return a
end

--- actor - onemiss -------------
function make_onemiss(x,y)
	local a = make_actor(10,x,y,false) --onemiss
	a.stat = 1
	a.pt={9} a.pn=1
	a.hide=true
	a.movefunc=function(a)
		a.x = a.x + a.dx
		a.y = a.y + a.dy

		if a.stat==1  then--- animation:gone
			if a.ct>10 then
				a.stat=2
				a.ct=0
				stock=stock-1
				life=3
				del_actor(player)
			end		
		elseif a.stat==2 then--- animation:span
			if a.ct>60 then
				if  stock < 0  then
					make_over(a.x,a.y)
				else
					player = make_player(player.x0,player.y0,false)
					cam.x=stx	cam.y=sty --miss
				end
				a.stat=99
			end
		end 
	end
	return a
end

--- actor - compburger -------------
function make_compburger(x,y)
	local a = make_actor(7,x,y,false) --compburger
	a.pt=160
	a.rad=0
	a.dy= -0.3
	a.dx= player.x < a.x and 0.3 or -0.3
	sfx(27,3)

	a.movefunc=function(a)
		a.x = a.x + a.dx
		a.y = a.y + a.dy
		a.dy=a.dy+0.03
		a.dx=a.dx+0.01
		a.rad =a.rad+5

		if a.ct>80 then
			a.stat=99	
		end 
	end
	a.drawfunc=function(a)
		local sy= flr(a.pt/16)
		local sx= a.pt % (sy*16)

		rotate_ssss(sx*8,sy*8,16,64,16,16,a.rad/100)
		xspr(130,a.x,a.y,2,2,a) --food
	end

	return a
end

---- stage character -----------
--------------------------------



--- actor - pans  -------------
function make_pans(x,y,direct,wh)
	local a = make_charactor(4,x,y,false,2) --pans
	a.stat=1
	a.pt=1
	a.sc=0
	a.wh=wh
	a.undery=a.y+1.0
	a.ct=intrnd(40)-120 -- minus 120over
	add(pans,a)
	a.movefunc=function(a)
		local nowstat=a.stat
		if nowstat==1 then --wait
			if a.ct>30 then
				a.stat=2 a.jump=-0.5
				a.y=a.undery-0.4
				rate=0 -- combo rate is ended
			end
		elseif nowstat==2 then --normal
			--if rangecheck(a.x+a.dx,a.y)  then
			--	a.dx=0
			--end

			-- falling?
			a.jump=a.jump+0.02
		--printh( "pan.j "..a.j  , "log" , false )

			if a.jump > 0 and a.y +a.jump > a.undery then --docking?
				a.y=a.undery-0.4
				a.stat=1 a.ct=0 a.jump=0
				make_sparkles_star(a)
			end

			--a.jump=ret_value( a.jump>0.4 , -0.4 , a.jump)
			a.dy=a.jump
			a.y=a.y+a.dy
			
		elseif nowstat==10 then --- vanish wait(no use)
			if a.ct>180 then
				a.stat=99
			end
		end --

		if a.ct%80==0 then
			make_sparkles_yuge(a)
		end

		if  hitcheck_player2(a,a.wh,1.0,false) == true  then
			if a.y<player.y and player.y<a.undery then
				player.pressed=120 --- pressed form
				sfx(1,3)
			else
				player.y=a.y-1.2 --- on ride
			end
			--sfx(9,3)
			--a.stat=99
		end

	end

	a.drawfunc=function(a)
		if a.stat==10 and (a.ct/4)%2==1 then
			return
		end
		if a.stat>0 then
			-- draw pans
			local px=(a.x-stx)*8
			local py=(a.y-sty)*8
			spr(a.pt,px,py,1,1,a.direct) -- <
			px=px+8
			for i=1,a.wh-2 do
				spr(a.pt+1,px,py,1,1,a.direct) -- =
				px=px+8
			end
			spr(a.pt+2,px,py,1,1,a.direct) -- >
		end
	end

	return a
end

function sub_jump(a)
	if  a.jump > 0  then --- jumping?
		a.jump= a.jump-1
		a.dy= min(a.dy+0.1 , 0.4)
		a.y=ret_value( a.dy<0 , a.y+a.dy, a.y)
	end
end
function sub_ground(a)
	if a.jump==0 then ---not jump
		-- falling?
		local ongrnd=falling_loop(a)
		if  ongrnd  then
			a.dy=0	
		else--- falling start?
			a.dx = 0 a.ddx = 0
			a.dy = min( a.dy+0.02 , 0.3 ) -- fall
		end
	
		-- let's jump?
		if ongrnd then
			if a:jpcond() then
				--a.ct=0
				a.jump = 14
				a.dy=-0.8
			end
		end
	end
end

--- actor - enemy -------------
function make_enemy1(x,y)
	local a = make_charactor(3,x,y,false) --enemy
	a.jump=0
	a.rad=0
	a.ct=intrnd(80)
	a.stat=2
	a.wh=0
	a.ctu=0 -- under check count
	a.movefunc=function(a)
		if a.stat==2 then -- normal
			sub_jump(a)

			a.ddx = ret_value( a.ddx<0.2 ,a.ddx + 0.02 , 0.1 )
			a.dx = ret_value( a.direct , a.ddx , -a.ddx)

			if a.ctu>0 then
				a.ctu=a.ctu-1
			else
				if hitcheck_under(a,a.dx,0.1, 0,3)==false then
					a.dx=0 a.ddx=0 a.direct=ret_value(a.direct , false , true )
					a.ctu=90
				end
			end

			if  rangecheck(a.x+a.dx,a.y)  then
				local dx=a.dx / abs(a.dx)
				local l=flr(a.dx/dx)
				for i=0,l do
					if  rangecheck(a.x+dx,a.y)==false  then
						a.x=a.x+dx
					end
				end
				a.dx=0	a.ddx=0
				a.direct = ret_value( a.direct , false , true )
				a.wallcount+=1
			end
			sub_ground(a)

			a:hitandattack()
		end
		move_damaged_sub(a) -->stat=47,48,49,50,98
		a.x=a.x+a.dx

		if a.stat==48 then
			a.rad=(a.rad+6.25)%100
		end
	end

	a.drawfunc=function(a)
		if a.stat==10 then
			return
		end

		a.pc=(a.pc+0.1) % 2.0
		a.pn= flr(a.pc) -- index is 1-

		if a.stat > 0 then
			a.palfunc()
		end

		if a.stat > 0 then
			local xx=(a.x-stx)*8
			local yy=(a.y-sty)*8
			local flag=(a.pn==0)

			if a.stat==50 then --food expand
				sspr_scale(a.pt,a.x,a.y,16,16,a.wh*8,8)		
			elseif a.stat<48 then
				spr(96,xx,yy,2,2,flag) --dodai
				spr(a.pt,xx,yy-8.0,2,2,false) --food
			else
				yy+=0.4 --hosei
				--spr(a.pt,xx,yy,2,2,false) --draw
				local sy= flr(a.pt/16)
				local sx= a.pt % (sy*16)
				rotate_ssss(sx*8,sy*8,16,64,16,16,a.rad/100)
				spr(130,xx,yy,2,2,false) --food
			end
			pal()	
		end
	end

	a.pt=98--food pattern
	a.pn=1 a.pc=0
	a.ddx=0
	a.wallcount=0
	a.haschild=true --kizband

	a.sc=100
	a.palfunc = function()
		if a.stat==51 then	
			pal(11,7,0)
			pal(10,6,0)
			pal(3,5,0)
			pal(9,0,0)
		end
	end
	a.jpcond = function(a)
		return false
	end


	return a	
end

--- actor - enemy2(jumping) -------------
function make_enemy2(x,y)
	local a = make_enemy1(x,y) --enemy2

	a.movefunc=function(a)
		if a.stat==1 then
			a.stat=2
		elseif a.stat==2 then
			sub_jump(a)

			if a.ctu>0 then
				a.ctu=a.ctu-1
			else
				if  player~=nil and abs(player.x-a.x)<5  then
					a.direct= player.x>a.x 
				else
					a.direct=rnd(2)<0 and true or false
				end
				a.ctu=90	
			end
			a.ddx = ret_value( a.ddx<0.2 ,a.ddx + 0.02 , 0.1 )
			a.dx = ret_value( a.direct , a.ddx , -a.ddx)

			if  rangecheck(a.x+a.dx,a.y)  then
				a.dx= 0.0-a.dx
				a.ctu=0	
			end
			a:hitandattack()

			sub_ground(a)
		end

		move_damaged_sub(a) -->stat=47,48,49,50,98
		a.x=a.x+a.dx

		if a.stat==48 then
			a.rad=(a.rad+6.25)%100
		end
	end
	a.pt=100
	a.sc=200
	a.palfunc=function() --2
		if a.stat==51 then	
			pal(10,7,0)
			pal(9,6,0)
			pal(4,5,0)
		end
	end
	a.jpcond = function(a)
		if a.stat==2 then 
			local u1 = mget(a.x,a.y-1.5)
			local u2 = mget(a.x,a.y-1.0)
			local onproof=fget(u1,3) or fget(u2,3)
			if a.ct>150 and onproof then
				return true
			end
		end
		return false
	end
	return a
end


--- actor -- enemy3(attacker) -------------
function make_enemy3(x,y)
	local a = make_enemy1(x,y) --enemy3
	a.stat=1

	a.movefunc=function(a)
--mes="to.."..a.stat.." "..a.dy
		if a.stat==1 then
			if  player~=nil and abs(player.x-a.x)<5  then
				a.dx=ret_value( player.x<a.x , -0.2 , 0.2 ) 
			else
				a.dx=ret_value( rnd(10)<5 , -0.2 , 0.2 ) 
			end
			a.stat=2
		elseif a.stat==2 then --- normal
			sub_jump(a)

			a.ddx=ret_value( a.ddx<0.2 ,a.ddx + 0.02 , 0.4 )
			a.dx=ret_value( a.direct , a.ddx , -a.ddx)

			if rangecheck(a.x+a.dx,a.y) then
				a.dx=0	a.ddx=0
				a.direct = ret_value( a.direct , false , true )
				a.wallcount +=1
				if a.wallcount > 5   then
					a.stat=99
					make_enemy3( stx+rnd(30)+2 , sty+0 ,false )
				end
			end
			sub_ground(a)

			a:hitandattack()
		end
		move_damaged_sub(a) -->stat=47,48,49,50,98
		a.x = a.x + a.dx

		if a.stat==48 then
			a.rad=(a.rad+6.25)%100
		end

	end

	a.pt=102
	a.sc=200
	a.palfunc=function() --4
		if a.stat==51 then	
			pal(8,7,0)
			pal(2,6,0)
			pal(3,5,0)
		end
	end
	a.jpcond = function(a)
		return ret_value( a.dx==0 and rnd(5)<3 , true , false )
	end	
	return a
end

--- actor - pig(jammer) -------------
function make_pig(x,y)
	local a = make_charactor(4,x,y,false) --pig
	a.jump=0

	a.movefunc=function(a)
		local nowstat=a.stat

		if nowstat==1 then --stay
			local ct=flr(a.ct/10)
			a.direct= ret_value( ct%2==0, true , false )
			if a.ct>120 then
				a.stat=2
			end
		elseif nowstat==2 then --normal
			sub_jump(a)

			a.ddx=ret_value( a.ddx<0.2 ,a.ddx + 0.02 , 0.1 )
			a.dx=ret_value( a.direct , a.ddx , -a.ddx)

			if  rangecheck(a.x+a.dx,a.y)  then
					a.dx=0	a.ddx=0
					a.direct = ret_value( a.direct , false , true )
					a.wallcount+=1
					if a.wallcount > 5   then
						make_sparkles_explode(a)
						make_pig( a.x , 0 ,false )
						a.stat=99
					end
			end
			sub_ground(a)

			a:hitandattack()
		end --
		move_damaged_sub(a) --.stat=49,50,98
		a.x = a.x + a.dx

		if a.stat==50 then
			make_sparkles_explode(a)
			a.stat=99
		end

		if a.stat==2 then
			a.pc=(a.pc+0.4) % 2.0
		end
		a.pn= flr(a.pc)+1 -- index is 1-
	end

	a.jpcond = function(a)
		return ret_value(a.y>sty+5 and (a.ct % 300 == 0) , true , false) 
	end	

	a.pt={ 140,142 }	a.pn=1 a.pc=0
	a.ddx=0
	a.wallcount=0
	a.sc=0	
	return a
end


--- actor - player -------------
function make_player(x,y)
	local a = make_charactor(1,x,y,false) --player
	a.punch=0
	a.x0=x 	a.y0=y --- init points
	a.pt={ 64, 66 , 68, 70, 74,1,76, 64,68,66,70} -- 1-2:walk 3:jump 4:ouch 5-7:punch 8-11:rolling
	a.pn=1 a.pc=0
	a.mark=nil --make_marker(0,0)

	a.stat=1
	a.jump=0
	a.knockback=0 a.pressed=0
	a.y=sty-1.0 -- syutugen demo pos
	a.drawheart=draw_heart
	player=a

	a.movefunc=function(a)
		local nowstat=a.stat
		if  nowstat==1  then	-- toujyou
			a.y=a.y+0.2
			local idx=flr(a.ct/2)%4		
			a.direct=ret_value(idx==2,true,false)
			a.pn=8+idx --index
			
			if a.y>=a.y0 or (a.y>sty and (btnp(5,p) or btnp(2,p) or btnp(4,p))) then
				a.ct=0
				a.stat=2
				a.direct=false	
				sfx(4,3)	
			end
		elseif  nowstat==2  then --normal move
			sub_move_player_normal(a)
			sub_move_player_attack(a)
			sub_move_player_pattern(a)

--if btnp(5,p) then--debug

--	make_compburger(a.x,a.y)
--	make_combeffect(a.x,a.y)
--end
		elseif  nowstat==49  then --damaged
			a.ct=0
			a.stat=50
			a.punch=0
			a.blct=60 a.blrt=4
			sfx(10,3)
			sub_move_player_pattern(a)
		elseif  nowstat==50  then --damaged wait
			sub_move_player_normal(a)
			if a.ct>20 then
				a.stat=2
				a.dx=0 a.dy=0
				a.knockback=0
			end	
			sub_move_player_pattern(a)
		elseif  nowstat==98  then -- miss
			make_onemiss( a.x , a.y )
			a.punch=0
			a.hide=true
			--make_vanish( a.x , a.y ,false )
			make_sparkles_miss(a)
			a.stat=99
			return	
		end
	end

	a.drawfunc=function(a)

		if a.punch>0.0 then
			local px= ret_value( a.direct , a.x-1.6,a.x+1.6)
			local py=a.y
			local pt=106

			if( a.punch<=1.6) pt+=2
			if( a.punch<=0.8) pt+=2

			xspr(pt,px,py,2,2,a) --punch hitbox
		end

		--if a.punch>0.0 then
		--	printh("a.punch:"..a.punch, "log") --dbg
		--end

		if a.stat==50 then --damaged
			local c=1+6*(flr(a.ct/4) % 2) -- 1 or 7
			pal(10,c,0)
			pal(4,8-c,0)
		end

		if a.stat>0 and a.hide==false then
			if a.pressed==0 then--normal
				xspr(a.pt[a.pn],a.x,a.y,2,2,a)
			else --pressed
				sspr_scale(a.pt[a.pn],(a.x-stx)*8,(a.y-sty)*8+6,16,16,16,10,a.direct)
				a.pressed=a.pressed-1
			end
			pal()
		end

	end	

	return a
end

function sub_move_player_normal(a) --normal move
	local p = 0 --player number
	local left=btn(0,p)
	local right=btn(1,p)

	local dx=a.dx

	local movable= a.punch==0 and a.jump==0 and a.knockback==0
	--printh("nobad:"..nobad, "log") --dbg

	if not movable then
		left=false right=false
	end

	local mdx= a.pressed==0 and 0.3 or 0.1

	if left then
		dx= max(dx-0.02 , 0-mdx ) a.direct=true
	elseif right then
		dx= min(dx+0.02 , mdx) a.direct=false
	else
		dx= ret_value( abs(dx)> 0.02 ,dx*0.8 , 0.0 ) -- gensoku
	end

	a.dx=dx

--	if a.punch==0 and a.jump==0 and a.knockback==0 then
--		a.dx=dx
--	end

	if  a.knockback==1  then --damaged knockback?
		a.knockback=2
		a.jump = 8
		a.dy=-0.4
		a.pn=4
		a.dx=0.0-a.dx*2

		life=life-1
		a.stat=ret_value(life==0,98,49)	
	end

	if  rangecheck(a.x+a.dx,a.y)  then
		a.dx=0
	end

	a.x=a.x+a.dx
	

	if  a.jump > 0  then --- jumping?
		a.jump= a.jump-1
		a.dy= a.dy+0.1
		a.y=ret_value( a.dy<0 , a.y+a.dy, a.y)
	end

	if a.jump==0 then ---not jump
		local ongrnd =false
		local predy=a.dy

		-- falling?
		ongrnd=falling_loop(a)
		if  ongrnd  then
			--a.knockback=0	
			if predy~=0 and a.dy==0 then
				make_sparkles_granddust(a)
			end
		else--- falling start?
			a.dy = min( a.dy+0.02 , 0.3 ) -- fall
		end

		-- let's jump?
		if btnp(2,p) or btnp(4,p) then
			if ongrnd then		
				a.jump = 14
				a.dy=-0.8
				make_sparkles_jumpdust(a)
			end
	--	elseif btnp(3,p) then
	--		if ongrnd then		
	--			a.jump = 7
	--			a.y=a.y+0.8
	--			a.dy=0.8
	--		end
		end

--		if btnp(3,p) then --debug blink
--			a.blct=600 a.blrt=4
--		end

	end
end

function sub_move_player_pattern(a) --sprite pattern
	local pase = ret_value( abs(a.dx)>0.2 , 0.4 , 0.2 )
	pase= a.dx==0 and 0 or pase
	a.pc=(a.pc+pase) % 2.0
	a.pn= flr(a.pc)+1 -- index is 1-
	if a.jump > 0  then
		a.pn=3
	end
	if a.punch>0 then
		a.pn=5
	end
	if a.knockback > 0  then
		a.pn=4
	end
end

function sub_move_player_attack(a) --attack move
	local p = 0 --player number
	local pnc=a.punch

	if  btnp(5,p)  then -- punch motion
		if pnc==0 then
			pnc=2.0
			--printh("punch st", "log") --dbg
		end
	end

	local dx=0
	if pnc>0 then
		pnc=pnc-0.2
		if pnc<=0.0 then --important
			pnc=0
			--printh("punch end", "log") --dbg
		else
			local dir=ret_value( a.direct ,-0.2 , 0.2 )
			dx = pnc>=1.0 and dir or 0-dir
			--printh("punch "..pnc.." "..dx , "log") --dbg
		end
		if a.jump==0 and a.knockback==0 then
			a.dx=dx
		end
	end

	a.punch=pnc
end


function draw_heart(a,pos) --- player heart
	if a.stat>1 and a.stat<99 then
		for i=1,3 do
			local her=ret_value( i<=life , 242,243)
			local xx=camx+94+i*8
			spr( her,xx,wavepos(xx)+pos)		
		end
	end
end
--- utility function ------------------
--	 --.stat=49:damaged,50->2:damaged wait,98:defeat
function move_damaged_sub(a)
			--printh("dx "..dx, "log") --dbg

	if a.stat==47 then --- fly in the sky , init
			sfx(5,3)
			a.jump=1 a.dy= -0.6
			local dx=abs(a.dx)*0.5
			dx= dx<0.2 and 0.2 or dx
			a.dx=ret_value(player.direct,dx,-dx)
			a.ddx=0
			a.stat=48
			make_sparkles_explode( a )
			a:statdel()  --dodai vanish

	elseif a.stat==48 then --- fly in the sky
			if  a.jump>0  then --- jumping?
				a.jump=a.jump-1
				a.dy=a.dy+0.02
				a.jump=ret_value(a.dy>=0.6, 0 , 1)
				a.y=a.y+a.dy
				if rangecheck(a.x+a.dx,a.y) then
					a.dx=0-a.dx	
				end
				if rangecheck(a.x,a.y+a.dy) then
					a.dy=0 a.jump=0	
				end
			else -- jump finished and blink
				a.stat=51 a.ct=0  a.dx=0 a.dy=0
				a.blct=180 a.blrt=4 --blink
				a.stat=60
			end

			if  hitcheck_myattack(a)==true then
				a.stat=47 -- re attack
				a.dx=a.dx*0.5
			end

			if a.dy>=0 and hitcheck_under(a,0.0,0.1, 1,1)==true then
				a.jump=0
				a.stat=51 a.ct=0  a.dx=0 a.dy=0
				a.blct=180 a.blrt=4 --blink
				a.stat=60
			end

			if a.dy>0 and hitcheck_pans(a)==true then
				local p= a.attacker or player
				local puy=(p.y-sty)*8
--mes="hit"				
				if a.y+1.0>puy then --- pressing
					if puy+1.0<p.undery  then ---- sand?
--mes="pressing"				
						a.stat=50 a.ct=0
						a.jump=0
						a.dy= a.dy<0 and 0 or a.dy
					end
				end
			end

	elseif a.stat==50 then --- pans damaged wait
			local p= a.attacker or player
			local puy=(p.y-sty)*8
			if a.ct==1 then --- press init
					a.wh=p.wh
					a.x=(p.x-stx)*8 -- food expand
					a.y=puy+0.5 -- food expand
					a.dy=0.4 a.dx=0
			end

			local pby=(p.undery-sty)*8 --lower pans
			a.y=ret_value( a.y<puy+8.0 , puy+8.0, a.y)
			if a.y+0.5<pby then 
				a.dy = min( a.dy+0.02 , 0.6 ) -- fall
				a.ct=2
			else
				a.y=pby
				a.dy=0
			end

			if a.ct>10 then
				a.x=a.x+a.wh/2
				a.dx=0 a.dy=0
				a.x=a.x/8+stx a.y=a.y/8+sty	
				make_compburger(a.x,a.y)
				a.stat=98 
			end
			a.y=a.y+a.dy

	elseif a.stat==51 then --- fried wait
			sub_ground(a)
			
			if hitcheck_pans(a)==true then
				a.stat=50 a.ct=0
			end
			if a.ct>180 then
				a.stat=2
			end

	elseif a.stat==60 then --- bounding init
				--a.dx=0
				a.dx=a.dx*0.3
				a.ddy=0.1 --max
				a.dy=0-a.ddy a.ct=0
				a.stat=61

	elseif a.stat==61 then --- bounding main
				a.dy=a.dy+0.01
				if rangecheck(a.x+a.dx,a.y) then
					a.dx=0-a.dx	
				end
				if rangecheck(a.x,a.y+a.dy) then
					a.dy=0
				end
				a.y=a.y+a.dy

				-- ground
				if a.dy>=0 and hitcheck_under(a,0.0,0.05, 0,3)==true then
					a.dy=0-a.ddy-0.01
					a.ddy=a.ddy*0.9
				end
				-- pans
				if hitcheck_pans(a)==true then
					a.stat=50 a.ct=0
				end


				if a.ct>200 then
					a.stat=2
				end

	elseif a.stat==98 then --- defeated
			if a.sc>0 then
				make_sceffect( a.x , a.y ,a.sc )
				update_score(a.sc)

				if rate>0 then
--mes="rate="..rate				
					make_combeffect( a.x , a.y-1.2 )
					make_scmultieffect(a.x+1.2,a.y, rate)
					update_score(a.sc*rate)
				end
				rate=ret_value( rate>5 , 5, rate+1 )
				
				target_cnt=target_cnt+1
			end
			a.stat=99
	end

end

--- falling_check_loop , effective : a.dy , a.y
function falling_loop(a)
	local ret=false
	if a.dy > 0 then --- falling?
		local imax=a.dy/0.1
		for i=0,imax do
			if hitcheck_under(a,0.0,0.1, 0,3) then
				a.dy = 0.0
				a.y=flr(a.y+0.1) --adjust(important!)
				ret=true
				break
			end
			a.y=a.y+0.1
		end
	elseif  a.dy==0  then
		ret=hitcheck_under(a,0.0,0.1, 0,3)
	end
	return ret
end

function rangecheck(x,y)
	local ret=false
	if  x<stx+0 or x >stx+32-2  then -- 2x2 chr
		ret=true
	end
	if  y<sty+0 or y >sty+14-2  then -- 2x2 chr
		ret=true
	end

	return ret
end

--- hitcheck_under
function hitcheck_under( a , ddx , ddy , bit1 , bit2 )
	local ret = false
	vl = mget(a.x+ddx+0.1  , a.y+2+ddy)
	vr = mget(a.x+ddx+0.1+1, a.y+2+ddy)
	if fget(vl,bit1) or fget(vr,bit1) then
			ret=true ---- on foot!
	elseif fget(vl,bit2) or fget(vr,bit2) then
			ret=true ---- on foot!
	end
	
	--printh("hitchk b:"..bit , "log") --dbg
	--printh("hitchk >:"..ret_value(fget(vl,bit),1,0 ), "log") --dbg
	--printh("hitchk y:"..(a.y+2+ddy) , "log") --dbg


	local cur=a.mark  --- debug marker
	if cur then
		cur.x=flr((a.x+ddx+0.1)*8)
		cur.y=flr((a.y+2+ddy)*8)
	end
	return ret
end


--- hitcheck
----- use enemy-function
function hitcheck_player( a , knock)
	local flag = false
	if player~=nil then
		if player.stat==2 and player.knockback==0 and player.blct==0 then
			--flag=ret_value( abs( player.x - a.x )<1.0 and abs( player.y - a.y )<1.0  , true , false )
			flag= abs( player.x - a.x )<1.0 and abs( player.y - a.y )<1.0
			if  knock and flag  then
				player.knockback=1
			end
		end
	end
	return flag
end

----- use enemy-function variable size
function hitcheck_player2( a , wd,ht,knock)
	local flag = false
	if player~=nil then
		if player.stat==2 and player.knockback==0 then
			flag= a.x < player.x+2.0 and player.x < a.x+wd and a.y < player.y+2.0 and player.y < a.y+ht
			if  knock and flag  then
				player.knockback=1
			end
			if  flag  then
				rate=0 -- combo rate is ended
			end
		end
	end
	return flag
end


----- use enemy-function
function hitcheck_myattack( a )
	local flag = hitcheck_myattack_sub( a , player )
	return flag
end

function hitcheck_myattack_sub( a , p0 )
	local flag = false
	local p=p0 --p=player
	if p~=nil and p.punch>0 then
--		local px= ret_value( p.direct , p.x-0.5,p.x+1.6)
		local px= ret_value( p.direct , p.x-1.6,p.x+1.6)
		local py=p.y+0.8
		
		--local dx= ret_value( player.direct ,-0.2 , 0.2 )
		flag=ret_value( abs(px-a.x)<1.0 and abs(py-a.y)<1.0 , true , false )
		if flag then
			a.attacker=p
		end
	end		

	return flag
end


function hitcheck_pans( a )
	local flag=false
		for p in all(pans) do
			if hitcheck_pans_sub(a,p) then
				flag=true
			end
		end
	return flag
end

function hitcheck_pans_sub( a , p ) --a:target p:pans
	local flag=false
	--if p~=nil and p.dy>0 then --upper pans:down 
	if p~=nil  then --upper pans:down 
		flag= p.x < a.x+2.0 and a.x < p.x+p.wh and p.y < a.y+0.5 and a.y < p.y+1.0
		if flag then
			a.attacker=p
		end
	end		

	return flag
end


--- map
function cls_square( x , y  ,no , size)
	mset(x,y,no)
	if size==2 then
		mset(x+1,y,no)
		mset(x,y+1,no)
		mset(x+1,y+1,no)
	end
end

round_matrix={}
round_matrix[64]={type=make_player,countflag=false,arg=nil}
round_matrix[98]={type=make_enemy1,countflag=true,arg=nil}
round_matrix[100]={type=make_enemy2,countflag=true,arg=nil}
round_matrix[102]={type=make_enemy3,countflag=true,arg=nil}
round_matrix[140]={type=make_pig,countflag=false,arg=nil}
round_matrix[1]={type=make_pans,countflag=false,arg=3}
round_matrix[2]={type=make_pans,countflag=false,arg=4}
round_matrix[3]={type=make_pans,countflag=false,arg=5}


function round_start()
	--printh("round_start" , "log") --dbg
	foreach(sparkle,clean_sparkle)
	foreach(actorb, clean_actor)
	foreach(actorm, clean_actor)
	foreach(actorf, clean_actor)

	target_cnt=0
	target_num=0
	pans={}

	reload(0x1000, 0x1000, 0x2000) -- map restore

	stx=stage_x[stage_cnt]
	sty=stage_y[stage_cnt]
	--camx=stx	camy=sty
	cam.x=stx cam.y=sty --round making
	rate=0
	local skytbl={14,15,12,1,0}
	skycol=skytbl[stage_cnt%5]

	for y=sty,sty+15 do for x=stx,stx+32 do
		local chip = mget(x,y)
		local rm=round_matrix[chip]
		if rm then
			rm.type(x,y,false,rm.arg)
			local size=ret_value(rm.arg,2,1)
			cls_square(x,y,12,size)
			if rm.countflag==true then
				target_num=target_num+1
			end
		end
	end end
	camera()
  	field_caller = round_field
	make_roundmanage(0,0)
	music(1,0,7)
	
end


function easing_out(tick,start,diff,total)
	tick=tick/total
	return -diff*tick*(tick-2.0)+start
end
-- rotate sprite to sprite
function rotate_ssss(sx0,sy0,x0,y0,wd,ht,rad)
	local hwd=flr(wd/2)
	local hht=flr(ht/2)
	sx0=sx0+hwd
	sy0=sy0+hht

	for y=0,ht do
		for x=0,wd do
			local xx=x-hwd
			local yy=y-hht
			local sx= xx*cos(rad)+yy*sin(rad)
			local sy= -xx*sin(rad)+yy*cos(rad)
			if sx<0-hwd or sx>=hwd then --clipping
			 sx=-hwd sy=-hht
			end
			if sy<0-hht or sy>=hht then -- clipping
			 sx=-hwd sy=-hht
			end
			local c=sget(sx0+sx,sy0+sy)
			sset(x0+x ,y0+y,c)
		end
	end
end

-- scale sprite
function sspr_scale(pt,x,y,wds,hts,wdd,htd,dir)
		local sy= flr(pt/16)
		local sx= pt % (sy*16)
		sspr(sx*8,sy*8,wds,hts,x,y,wdd,htd,dir)
end

-- outline font
function textout(str , x , y , f ,b)
	color(b)
	cursor(x-1,y)	print(str)
	cursor(x+1,y)	print(str)
	cursor(x,y-1)	print(str)
	cursor(x,y+1)	print(str)

	color(f)
	cursor(x,y)		print(str)
end


function fade_out()

	for i=0,40 do
		for j=1,15 do
		col = j
		for k=1,((i+(j%5))/4) do
			col=dpal[col]
		end
		pal(j,col,1)
		end
		flip()
	end

end

-- yet not use
function update_score( add )
	score = score + add
	if  score > hiscore  then
		hiscore=score
	end

end

function dbgfunc(o)
	printh("k:"..o.kind , "log") --dbg
end

-- gamover sub
function deal_gameover()
	--actor , prticles all deleted
	foreach(sparkle,clean_sparkle)
	foreach(actorb, clean_actor)
	foreach(actorm, clean_actor)
	foreach(actorf, clean_actor)

	--printh("gameover del" , "log") --dbg
	--foreach( , dbgfunc ) --dbg
	
	dset(0,hiscore)
	stx=0 sty=0
	deal_start()
	
end

function clean_sparkle(o)
	del(sparkle,o)
end

function clean_actor(o)
	if o.kind<20 then
		del_actor(o)
	end
	
end

--- game start or restart
function deal_start()
	camx=0 camy=0
	cdx=0 cdy=0
	field_caller = title_field

	--actor , prticles all deleted
	foreach(sparkle,clean_sparkle)
	foreach(actorb, clean_actor)
	foreach(actorm, clean_actor)
	foreach(actorf, clean_actor)

	player=nil
	cam=make_camera(0,0)
	make_title(16,5)
	
	--@@x=0
	score=0
	rate=0 --- combo rate
	stock=3
	life=3
	stage_cnt=1 --6 stage
	--@@di=false
	cls()
end

function half_fade()
	--local dpal={0,1,1, 4,1,13,6,4,9,10,11, 13,1,13,14}--for title only pal table

	for j=1,15 do
		pal(j,dpal[dpal[j]],0)
	end
end

--- background and field per frame
function title_field( gtick ) --field_caller

	half_fade() --bg is half fade
	round_field( gtick )
	spr(74,60,98,2,2,true) --"mychr"
	spr(110,44,98,2,2,true) --"pan"

	pal()

end

function round_field( gtick ) --field_caller
	local scx=camx+cdx --- billboard x
	rectfill(scx, 0,scx+128,14*8,skycol) -- sky
	local off=camx/5
	mapdraw(96,0,   0-off,4, 32,16,0x00) -- src(block)-dst(dot)-rect(block)
	mapdraw(96,0,32*8-off,4,off,16,0x00) -- src(block)-dst(dot)-rect(block)
	mapdraw(stx,sty,0,0,32+0,16,0x8f) -- main field
end
----

-- system 
-- called at start by pico-8
function _init()
		--printh("180602", "log") --dbg

	if  cartdata("burgerage") == true  then
		hiscore=dget(0)
		hiscore=ret_value( hiscore<500 , 500 , hiscore)
	else
		hiscore=500
	end

	sparkle = {}
	deal_start()
	target_cnt=0
	target_num=0
	skycol=12
	
end

function _update()
    foreach(actorb, move_actor)
    foreach(actorm, move_actor)
    foreach(actorf, move_actor)
    foreach(sparkle, move_sparkle)
end

function wavepos(x)
	return 1.5*sin(x/32+gtick)
end

function _draw()
	camera(camx+cdx,camy+cdy)
	cls()

	field_caller( gtick )
	gtick +=0.01

	foreach(actorb, draw_caller)
	foreach(actorm, draw_caller)
	foreach(actorf, draw_caller)
	foreach(sparkle, draw_sparkle)

	--information
	--local pos=1.5+sin(gtick)
	textout("score "..score,camx+1,wavepos(1),8,7)
	textout(""..hiscore, camx+56 ,wavepos(56),7,1)

	--stock--
	for i=1,stock do
		local xx=camx+94+i*8
		spr( 241,xx,wavepos(xx))--def:wd1,ht1
		--spr( 241,camx+94+i*8,pos+1)--def:wd1,ht1
	end
	--life--
	if player~=nil then
		player:drawheart(10)
	end

	--debug
	--cursor(camx+5,18)
	--print(mes)
--mes="--"

	--cursor(camx,110)
	--print(">sp:"..#sparkle)
 	--print(">ac:"..#actorb+#actorm+#actorf)
 	--print(">cmx:"..camx)
 	--print(">tg:"..target_cnt)
 	--print(">tn:"..target_num)

--	cursor(camx+35,110)
-- 	if hit3 then 	print(">hit3:t")
--	else	 	print(">hit3:f")
--	end
-- 	if hit0 then	 	print(">hit0:t")
--	else	 	print(">hit0:f")
--	end

end





