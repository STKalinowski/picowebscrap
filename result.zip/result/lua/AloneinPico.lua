--alone in pico
--by nusan

time = 0.0

tele_cam = true
cur_cam = 1
numup = 0

sroom = 0

cpy = 0
csy = 128

room_ram = 0

selectscreen = true
selectpers = false
mainmusic=true
curmusic=0
isintroanim=true
introanim=0
introanimdur=3

function togglemusic()
	mainmusic = not mainmusic
	if curmusic==0 then
		music(mainmusic and 0 or -1,0,1)
	end
end
function setmusic(s)
	curmusic=s
	if mainmusic or curmusic!=0 then
		music(s,0,1)
	else
		music(-1,0,1)
	end
end

menuitem(1, "toggle music", togglemusic)

function clone(t)
  local t2 = {}
  for k,v in pairs(t) do
    t2[k] = v
  end
  return t2
end

function nvt (in_x,in_y,in_z)
	local set = {}
	set.x = in_x
	set.y = in_y
	set.z = in_z
  return set
end

function newtri (tris,in_v1,in_v2,in_v3,in_c)
	local set = {}
	set.v1 = flr(in_v1)
	set.v2 = flr(in_v2)
	set.v3 = flr(in_v3)
	set.c = flr(in_c)
	set.avg = 0.0
	tris[#tris+1] = set
end

function newent (loc)
	local set = {}
	set.ver={}
	set.tri={}
	set.loc=loc
	set.sort = true
	set.avg = 0.0
	set.rot = 0
  return set
end

function addvert(verts,x,y,z,s)
	verts[#verts+1] = nvt((x/256.0 - 0.5) * s,(y/256.0 - 0.5) * s,(z/256.0 - 0.5) * s)
end

function smesh (set,x,y,z,size,verbuf,tribuf)
	if not set then
		set = {}
		set.ver={}
		set.tri={}
		set.loc=nvt(x,y,z)
		set.sort = true
		set.avg = 0.0
		set.rot = 0

		while(#tribuf > 0) do

			local lenstrip = flr("0x"..sub(tribuf,1,2))-2
			local color = flr("0x"..sub(tribuf,3,4))

			local v1 = flr("0x"..sub(tribuf,5,6))
			local v2 = flr("0x"..sub(tribuf,7,8))

			tribuf = sub(tribuf,9,#tribuf)

			for i=1,lenstrip do

				local v3 = flr("0x"..sub(tribuf,1,2))

				if (i%2)==1 then
					newtri(set.tri,v1,v2,v3,color)
				else
					newtri(set.tri,v1,v3,v2,color)
				end

				v1 = v2
				v2 = v3

				tribuf = sub(tribuf,3,#tribuf)
			end
		end


		local maxsize = 5.0*size

		while(#verbuf > 0) do
			local cur = sub(verbuf,1,6)
			verbuf = sub(verbuf,7,#verbuf)
			addvert(set.ver,"0x"..sub(cur,1,2),"0x"..sub(cur,3,4),"0x"..sub(cur,5,6),maxsize)		
		end
	end
	return set
end

function pmesh (set,x,y,z,size,addr,sizev,sizei)
	if not set then
		set = {}
		set.ver={}
		set.tri={}
		set.loc=nvt(x,y,z)
		set.sort = true
		set.avg = 0.0
		set.rot = 0
		
		local vaddr = addr
		local iaddr = addr + sizev

		local runaddr = iaddr
		while((runaddr-iaddr) < sizei) do

			local lenstrip = peek(runaddr)-2
			local color = peek(runaddr+1)

			local v1 = peek(runaddr+2)
			local v2 = peek(runaddr+3)

			runaddr += 4

			for i=1,lenstrip do

				local v3 = peek(runaddr)

				if (i%2)==1 then
					newtri(set.tri,v1,v2,v3,color)
				else
					newtri(set.tri,v1,v3,v2,color)
				end

				v1 = v2
				v2 = v3

				runaddr += 1
			end
		end
		
		local maxsize = 5.0*size

		for i=1,sizev,3 do
			addvert(set.ver,peek(vaddr),peek(vaddr+1),peek(vaddr+2),maxsize)
			vaddr += 3
		end
	end
  return set
end

function cloneent(ent, x,y,z)
	local newent = clone(ent)
	newent.loc = nvt(x,y,z)
	return newent
end

campos = nvt(0,0,-1)
camdir = nvt(0,0,1)
camtar = nvt(0,0,0) 
camup = nvt(0,1,0)
camrottar = nvt(0,0,0) 
camright = nvt(1,0,0)

actions={}

function newact(xx,yy,ss,room,text,s,app,l,atext,isfx)
	local a = {loc=nvt(xx,0,yy),s=ss,r=room,t=text,start=s,apply=app,loop=l,at=atext,sfx=isfx}
	add(actions,a)
	return a
end

function ar1(xx,yy,text)
	newact(xx,yy,4,1,text)
end

function ar2(xx,yy,text)
	return newact(xx,yy,4,2,text)
end

function agrd(e)
	add(bground,e)
end

function abck(e)
	add(sortedback,e)
end

function areal(e)
	add(sortedreal,e)
end

function give(ac,text,need,needtxt)
	ac.search = true
	ac.give = text
	ac.need = need
	ac.needtxt = needtxt
	return ac
end

function auto(ac)
	ac.auto = true
	ac.at = ""
	return ac
end

function sound(xx,yy,s,r,sfx)
	local ac = newact(xx,yy,s,r,"")
	ac.sound = sfx
	return ac
end

ar1(23,-17,"a simple chair")
ar1(8,-6,"an ominous bench")
ar1(27,8,"an empty library")
ar1(27,33,"it's just some lugage")
ar1(-14,35,"the trap doesn't move")
night="a pitch-black night"
ar1(-33,-4,night)
ar1(-27,-10,"the barrel contains oil")
ar1(-27,-14,"it contains water")
ar1(-27,-18,"it contains ... blood?")
nothing="you find nothing here"
ar1(23,-25,nothing)
ar1(23,-8,nothing)
ar1(3,-40,"some old cloth")

sound(15,-24,6,1,10)
sound(16,-15,6,1,10)

ar2(-52,-21,"some old papers")
ar2(-42,-10,"alcohol bottles")
ar2(-42,-20,"vinegar bottles")
ar2(-48,-26,night)
ar2(-57,1,night)

ar2(-30,-16,"a cosy sofa")
ar2(-13,-13,"the lamp is dirty")
ar2(-22,-17,"a bloody carpet")

ar2(-20,24,"the drawer is broken")
ar2(-32,19,"a collection of shoes")
ar2(-33,26,"a nap, maybe?")
ar2(-33,31,"maybe not")
ar2(-26,33,"the garden is dark")

ar2(-0,33,"some old silverware")
ar2(2,25,"the bed is huge")
ar2(14,13,"an empty dark corner")

ar2(10,-14,"drugs and bandages")
ar2(9,-21,"a bath would be great")
ar2(9,-25,"no getting naked here")
ar2(4,-28,"my reflection seems odd")
local statue = "a statue blocks the way"
local statue2 = "i can't pass the statue"
acsta={}
add(acsta,ar2(37,-23,statue))
add(acsta,ar2(31,-28,statue2))
add(acsta,ar2(34,21,statue))
add(acsta,ar2(31,28,statue2))

ac_box1=newact(2.22,34.7,7,1,"you move the chest", function() setcol(0,8,14,4,5) setcol(1,8,9,4,5) del(actions,ac_zomb1) end, function() box1.loc.x -= 0.4 end,nil,"push",12)
ac_box2=newact(-32,20,9,1,"you move the cabinet", function() setcol(0,18,1,10,4) setcol(1,26,1,12,4) del(actions,ac_zomb2) end, function() box2.loc.z -= 0.5 end,nil,"push",12)
ac_horse=newact(-11,-34,5,1,"you shake the horse",nil, function(a) horse.loc.z += cos(a.anim*2)*0.3 end, function() horse.loc.z = -34.58 end,"shake",12)

ac_pianokey=give(newact(-52,-10,4,2,"nothing left"),"you find the piano key")
ac_piano=give(newact(-25,37,5,1,"it's out of tune"),"you find a small key",ac_pianokey,"the piano is locked")
ac_sivlerkey=give(newact(-7,-28,4,2,"the drawer is empty"),"you find a silver key")
ac_goldkey=give(newact(11,33,4,2,"there is nothing left"),"you find a gold key")

ac_door3=newact(-35,2,7,2,"you use the small key", function() setcol(0,112,16,3,2) end, function() r2_door3.rot -= 0.0166 end,nil,"open",14)
ac_door3.need=ac_piano
ac_door2=newact(-25,11,7,2,"you use the silver key", function() setcol(0,106,20,3,1) end, function() r2_door2.rot -= 0.0166 end,nil,"open",14)
ac_door2.need=ac_sivlerkey
ac_door1=newact(5,10,7,2,"you use the gold key", function() setcol(0,88,20,3,2) tele_cam=true need_paste=false end,nil,nil,"open",14)
ac_door1.need=ac_goldkey

ac_mirrorkey=give(newact(-4,21,3,2,"hello teddy bear"),"you find two mirrors")

ac_mir1=give(newact(24,-24,5,2,"nothing happens", function() del(sortedreal,r2_dl) del(sortedreal,r2_dr) areal(r2_mirror) end), "you place a mirror",ac_mirrorkey,"a strange altar")
ac_mir2 = clone(ac_mir1)
ac_mir2.loc = nvt(24,0,22)
add(actions,ac_mir2)

ac_death = auto(newact(-7,6,6,2,"", function() deathtrap1=true setmusic(8) time = 0 end, nil,nil,nil,25))
ac_death2 = clone(ac_death)
ac_death2.loc = nvt(-7,0,-2)
add(actions,ac_death2)
zsound=function() setmusic(9) end
ac_zomb1=auto(newact(-25,37,20,1,"a zombie arrives", zsound, function() trap.loc.z += 0.25 end,nil,nil,12))
ac_zomb2=auto(newact(-27,-26,11,1,"the window broke", zsound,nil,nil,nil,15))
ac_zomb3=auto(newact(-23,-29,11,2,"it's a trap", zsound,nil,nil,nil,15))

for n=1,5 do
	sound(-26+n*8,0,10,2,8)
end
sound(-28,22,12,2,10)
sound(-28,29,12,2,10)
sound(-23,-29,12,2,10)

function v_sub(v1,v2)
	local vf = clone(v1)
	vf.x -= v2.x
	vf.y -= v2.y
	vf.z -= v2.z
	return vf
end

function v_len(p0)
	return sqrt(p0.x*p0.x + p0.y*p0.y + p0.z*p0.z+0.001)
end

function v_mulf(v1,f)
	local vf = clone(v1)
	vf.x *= f
	vf.y *= f
	vf.z *= f
	return vf
end

function v_add(v1,v2)
	local vf = clone(v1)
	vf.x += v2.x
	vf.y += v2.y
	vf.z += v2.z
	return vf
end

function dot(v1,v2)
	return v1.x*v2.x + v1.y*v2.y + v1.z*v2.z
end

function v_cross(v1,v2)
	local vf = clone(v1)
	vf.x = v1.y*v2.z - v1.z*v2.y
	vf.y = v1.z*v2.x - v1.x*v2.z
	vf.z = v1.x*v2.y - v1.y*v2.x
	return vf
end

function v_norm(v1)
	local vf = clone(v1)
	local len = 1.0/sqrt(vf.x*vf.x+vf.y*vf.y+vf.z*vf.z+0.0001)
	vf.x = vf.x*len
	vf.y = vf.y*len
	vf.z = vf.z*len
	return vf
end

function lerp(a,b,alpha)
	return a*(1.0-alpha)+b*alpha
end

function clampy(v)
	return max(cpy-1,min(csy,v))
end

function swap(x1,x2)
	return x2,x1
end

function otri(x1,y1,x2,y2,x3,y3,c)

	if y2<y1 then
		if y3<y2 then
			y1,y3=swap(y1,y3)
			x1,x3=swap(x1,x3)
		else
			y1,y2=swap(y1,y2)
			x1,x2=swap(x1,x2)
		end
	else
		if y3<y1 then
			y1,y3=swap(y1,y3)
			x1,x3=swap(x1,x3)
		end
	end

	y1 += 0.001

	local miny = min(y2,y3)
	local maxy = max(y2,y3)

	local fx = x2
	if y2<y3 then
		fx = x3
	end

	local cl_y1 = clampy(y1)
	local cl_miny = clampy(miny)
	local cl_maxy = clampy(maxy)

	local steps = (x3-x1)/(y3-y1)
	local stepe = (x2-x1)/(y2-y1)

	local sx = steps*(cl_y1-y1)+x1
	local ex = stepe*(cl_y1-y1)+x1
		
	for y=cl_y1,cl_miny do
		rectfill(sx,y,ex,y,c)
		sx += steps
		ex += stepe
	end

	sx = steps*(miny-y1)+x1
	ex = stepe*(miny-y1)+x1

	local df = 1/(maxy-miny)

	local step2s = (fx-sx) * df
	local step2e = (fx-ex) * df

	local sx2 = sx + step2s*(cl_miny-miny)
	local ex2 = ex + step2e*(cl_miny-miny)

	for y=cl_miny,cl_maxy do
		rectfill(sx2,y,ex2,y,c)
		sx2 += step2s
		ex2 += step2e
	end
end

function clearroom1()
	back = nil
	horse = nil
	chair = nil
	box1 = nil
	pilars = {}
	bars = {}
	barils = {}
	window = nil
	bench = nil
	trap = nil
	box2 = nil
	box3 = nil
	table = nil
	library = nil
end

function clearstatic2()
	r2_enter = nil
	r2_center = nil
	r2_hall = nil
	r2_1 = nil
	r2_2 = nil
	r2_3 = nil
	r2_4 = nil
end

function clearroom2()
	r2_win = nil
	r2_ted = nil
	r2_mirtab = nil
	r2_lamp = nil
	r2_lamp2 = nil
	r2_etag = nil
	r2_door =  nil
	r2_door2 = nil
	r2_couch = nil
	r2_carpet = nil
	r2_brok = nil
	r2_box1 = nil
	r2_box2 = nil
	r2_bath = nil
	r2_bar = nil
	r2_bar2 = nil
	r2_arm = nil
	r2_alt = nil
	r2_alt2 = nil

	r2_enter = nil
	r2_center = nil
	r2_hall = nil
	r2_1 = nil
	r2_2 = nil
	r2_3 = nil
	r2_4 = nil
	r2_dl = nil
	r2_dr = nil
end

function acam(x,y,z,i,j,k,r)
	add(cams,{pos=nvt(x,y,z),tar=nvt(i,j,k),room=r})
end

function add_objects()

	cams = {}
	bground = {}
	sortedback = {}
	sortedreal = {}

	clearroom1()
	clearroom2()

	reload()

	if room_number == 1 then
		acam(35,12,-20,0,1,-15,0)
		acam(-1.908,16.321,43.371,-11,4,29,0)
		acam(-26.415,18.96,45.171,-5,4,25.2,0)
		acam(31.581,4,42.31,12,14,17,0)
		acam(-18.658,15.585,-9.15,-24,1,-30,0)
	else
		acam(15.47,8.81,3.53,6,6,2,0)
		acam(-35.9,9.39,5.26,-26,6,2,0)

		acam(20.97,11.18,27.9,8,6,27,2)
		acam(-11.83,8.44,32.587,1,8,27,2)

		acam(-22.1,9.9,36.2,-25,2,25,1)
		acam(-19.6,11.94,12.32,-25,6,25,1)

		acam(-53.9,14.4,6.5,-46,1,-9,5)
		acam(-46.18,17,-9.9,-53,5,0,5)

		acam(-33.5,9.2,-15,-11,3,-24,4)
		acam(-1.41,9.37,-33.21,-11,8,-28,4)

		acam(3.5,3.87,-31.64,11,7,-8,3)
		acam(6.7,9.2,-8.36,12,3,-32,3)

		acam(32.2,11.133,-3.91,29,-6,18,6)
		acam(41.9,14.13,2.4,26,-3,-13,6)

		acam(0.05,9.32,-3.55,-7,5,0,0)
		acam(-20.73,12.394,1.7,-10,10,2,0)

		acam(-8.244,20.552,-1.515,-11,12,-1,0)
	end

	if selectscreen then
		acam(6,10,0,0,10,0,0)

		title=smesh(title, -3,15.05,0.91,2,"80558080ac8080558d80498d80ac8d80b98080556a80ac6a80ac7780557780497780b96a80b97780498080955080ac5080955d80ac5d80b9508055ac80acac8055b980acb980b9b980b9bf8049b98049ac8049a58055a58049998055998063998049e3808be38049f0808bf08096f08096e380bce380bcf080c6e380c6f080c6f78096f780bcd8808bd48096d4808bc88096c880b5c880b5d480c6d28049d480b95d80b96380495d808538809a38808545809a4580b93880494580551a808b1a808b2780961a80962780ac1a80ac2780b91a80491a804906808b0980552780492780ac0780b92780b92d80b9ac80b98d80496a80acbf8063a580bcf7808bf78049c880ac6380495080b94580493880550680960980b90780ac2d","070a2c2c2524222321070a5252191718154f080a080c090d02060550080a0304010e0a0b0751050a1e1f1d2053050a292a282b54030a2c5524070a26262f2e303556050a1336123757070a131210110f3858090a5a5a3e393b3a3c3d59050a4b473f485b090a4b4b4a3f414042495c070a43434544464c5d050a464d454e5e040a05030201040a0809070a070a17171516141a1b050a1e1d1c141b070a2928272526222e090a30312f3233342d2927040a3b3c0f10040a44434241")
	else
		title=nil
		acam(5,9.5,0,0,6.5,0,0)
	end

	if selectpers or selectscreen then
		pers=pmesh(pers, charstart.x,charstart.y,charstart.z, 2 ,8192,435,442)
	end
	if not selectpers or selectscreen then
		fepers=pmesh(fepers, charstart.x,charstart.y,charstart.z, 2 ,9069,411,443)
		if not selectscreen then
			pers = fepers
		end
	end

	pers.loc = charstart
	pers.rot = charstartrot

	if room_number == 1 then
		
		if not back then

			pilars = {}
			bars = {}
			barils = {}

			back=pmesh(back, 0,0,0, 20 ,9923,423,509)
			horse=pmesh(horse, -6.28,4.12,-34.58, 2.04 ,10855,228,289)
			chair=pmesh(chair, 26.91,4,-17.65, 1.5 ,11372,198,274)
			baril=pmesh(baril, -32.7,2.9,-12.2,1.2 ,11844,123,117)
			box2=pmesh(box2, -30.5,8.6,ac_box2.anim and 0.2 or 15.2, 3.5 ,12084,132,98)
			box1=pmesh(box1, ac_box1.anim and -10.78 or 1.22,2.4,34.7, 1.76 ,12314,96,124)

			window=pmesh(window, -34.7,13.3,-1.5, 2.6 ,0,48,48)
			pilar=pmesh(pilar, -19.8,11.3,33.8, 4.5 ,96,24,30)
			bar=pmesh(bar, -19.6,23.5,0.0, 19.45 ,150,96,66)
			bench=pmesh(bench, 8.3,1.8,-6.3, 0.84 ,312,105,90)
			trap=pmesh(trap, -17.2,0,31, 3.37 ,507,24,24)
			box3=pmesh(box3, 23.5,2.9,26.4, 2.33 ,555,72,82)
			library=pmesh(library, 26.7,2.6,6.2, 3.39 ,709,24,24)

			barils[1] = baril
			barils[2] = cloneent(baril,-32.7,2.9,-16.8)
			barils[3] = cloneent(baril,-32.7,2.9,-21.4)

			bars[1] = bar
			bars[2] = cloneent(bar, 1.7,23.5,0.0)
			bars[3] = cloneent(bar, 20.3,23.5,0.0)

			pilars[1] = pilar
			pilars[2] = cloneent(pilar, -19.8,11.3,2.0)
			pilars[3] = cloneent(pilar, -19.8,11.3,-33.2)
			pilars[4] = cloneent(pilar, 1.56,11.3,2.0)
			pilars[5] = cloneent(pilar, 20.2,11.3,33.8)
			pilars[6] = cloneent(pilar, 20.2,11.3,2.0)
			pilars[7] = cloneent(pilar, 20.2,11.3,-33.24)

			table = cloneent(library,32,2,-21)
			table.rot = 0.75

		end
	end

	cur_addr = 0x4100
	dcol(0)
	dcol(64)

	if(not ac_door3.anim) setcol(1,112,15,3,4)
	if(not ac_door2.anim) setcol(1,106,20,3,1)
	if(not ac_door1.anim) setcol(1,88,20,3,2)

	if(ac_box1.anim) ac_box1.start()
	if(ac_box2.anim) ac_box2.start()
end

function fillsorted()

	bground = {}
	sortedback = {}
	sortedreal = {}

	if selectscreen then
		if(isintroanim) then
			areal( title)
		else
			areal( pers)
			areal( fepers)
			abck( title)
		end
		return
	end

	if finalvic then
		areal( pers)
		return
	end

	if (zombi) areal( zombi)

	if deathtrap2 then
		return
	end

	areal( pers)

	zombi2 = smesh(charzombi, 37,0,-35,2,strzombv,strzombi)
	zombi2.rot = 0.65
	if cur_cam == 12 then
		zombi2.loc.z = 35
		zombi2.rot = 0.4
	end

	if room_number == 1 then
		agrd( back)
		if(cur_cam != 4) abck( horse)
		abck( chair)	
		if((cur_cam != 1) and (cur_cam != 2)) abck( box1)
		for i=1,7 do
			abck( pilars[i])
		end
		for i=1,3 do
			abck( bars[i])
		end
		for i=1,3 do
			abck( barils[i])
		end
		abck( window)
		abck( bench)
		if(cur_cam != 1) abck( box2)
		abck( box3)

		abck( library)

		if cur_cam == 0 then
			areal( chair)
			areal( pilars[4])
		end
		if cur_cam == 1 then
			areal( box1)
			areal( box2)
		end
		if cur_cam == 2 then
			areal( box1)
			areal( pilars[1])
			areal( box3)
			abck( table)
		end
		if cur_cam == 3 then
			areal( box3)
		end
		if cur_cam == 4 then
			areal( horse)
		end
	else

		local s = 9

		clearroom2()

		r2_center=pmesh(r2_center, -6.9,6.38,0.72,s/0.785 ,757,594,533)
		r2_1=pmesh(r2_1, -29.6,6,25.2,s ,1884,144,149)
		r2_2=pmesh(r2_2, 4.5,6.12,25,s/1.3 ,2177,108,90)
		r2_3=pmesh(r2_3, 9.44,8.0,-23.58,s/1.56 ,2375,174,176)
		r2_4=pmesh(r2_4, -17,6,-24,s ,2725,96,85)
		r2_enter=pmesh(r2_enter, -48.9,6.3,-5.6,s/0.64 ,2906,306,326)
		r2_hall=pmesh(r2_hall, 41.,1.5,0.5,s/0.56 ,3538,450,423)
		r2_dl=pmesh(r2_dl, 0,0,0,s/0.56 ,4411,33,28)
		r2_dr=pmesh(r2_dr, 0,0,0,s/0.56 ,4472,33,31)

		agrd( r2_enter)
		agrd( r2_center)
		agrd( r2_hall)
		agrd( r2_1)
		agrd( r2_2)
		agrd( r2_3)
		agrd( r2_4)

		if sroom > 0 and sroom < 6 then
			r2_win=pmesh(r2_win, 0,0,0,s/2.56 ,4536,102,86)
			r2_mirtab=pmesh(r2_mirtab, 0,0,0,s/2.12 ,4724,204,192)
			r2_couch=pmesh(r2_couch, 0,0,0,s/2.87 ,5120,105,85)
			
			r2_carpet=pmesh(r2_carpet, 0,0,0,s/2.72 ,5429,180,96)
			r2_box1=pmesh(r2_box1, 0,0,0,s/4.56 ,5705,84,91)
			r2_arm=pmesh(r2_arm, 0,0,0,s/2.89 ,5880,84,95)

			r2_box2 = cloneent(r2_box1, -58,4,-30)
		end
		r2_lamp=pmesh(r2_lamp, -10,10,-8.1,s/9.13 ,6059,87,71)
		r2_lamp2 = cloneent(r2_lamp, 0,0,0)
		r2_lamp2.rot = 0.5
		
		r2_door=pmesh(r2_door, 7.5,0,9.5,s/1.96 ,7729,90,102)
		r2_door.rot = ac_door1.anim and 0.5 or 0
		r2_door2 = cloneent(r2_door, -28,0,11.5)
		r2_door2.rot = ac_door2.anim and 0.18 or 0.5
		if ac_door3.anim then
			r2_door3 = cloneent(r2_door, -35,0,4.5)
		else
			r2_door3 = cloneent(r2_door, -37,1,4.5)
		end
		
		r2_door3.rot = ac_door3.anim and -0.7 or -0.25
		
		if sroom == 0 then
			abck( r2_lamp)
			abck( r2_lamp2)
			r2_lamp2.loc = nvt(-10,10,9)
			r2_brok=pmesh(r2_brok, -8.5,0,1,s/3.18 ,6217,120,88)
			add(cur_cam==16 and sortedreal or sortedback, r2_brok)
			agrd( r2_door)
			add(cur_cam==1 and sortedreal or bground, r2_door2)
			if(cur_cam!=1) abck( r2_door3)
		elseif sroom == 1 then
			areal( r2_mirtab)
			r2_mirtab.loc = nvt(-16,0,24)
			r2_mirtab.rot = 0.75
			areal( r2_couch)
			r2_couch.loc = nvt(-39,0,28)
			abck( r2_win)
			r2_win.loc = nvt(-26.8,7,37.2)
			r2_win.rot = 0.5
			abck( r2_arm)
			r2_arm.loc = nvt(-35,7,14)
			r2_arm.rot = 0.75
			abck( r2_door2)
		elseif sroom == 2 then
			abck( r2_win)
			r2_win.loc = nvt(8.8,7,37.2)
			r2_win.rot = 0.5
			abck( r2_arm)
			r2_arm.loc = nvt(-2,6.5,36.0)
			r2_arm.rot = 0.25
			abck( r2_box1)
			r2_box1.loc = nvt(-9,4,21)
			r2_ted=pmesh(r2_ted, -6.8,6.5,22,s/6.63 ,6425,150,98)
			abck( r2_ted)
			r2_ted.rot = 0.25
			abck( r2_mirtab)
			r2_mirtab.loc = nvt(15,0,36)
			r2_mirtab.rot = 0.5
			r2_bed=pmesh(r2_bed, 11.5,0,25,s/1.4 ,5310,72,47)
			abck( r2_bed)
			r2_bar=pmesh(r2_bar, 4,0,31,s/1.48 ,6673,108,96)
			r2_bar2 = cloneent(r2_bar, 4,0,20)
			areal( r2_carpet)
			r2_carpet.loc = nvt(12.3,2.5,24.1)
			abck( r2_bar)
			abck( r2_bar2)
			abck( r2_carpet)
			agrd( r2_door)
		elseif sroom == 3 then	
			abck( r2_arm)
			r2_arm.loc = nvt(16,7,-13)
			r2_arm.rot = 0.5
			abck( r2_mirtab)
			r2_mirtab.loc = nvt(5,0,-33)
			r2_mirtab.rot = 0
			r2_bath=pmesh(r2_bath, 14,0,-26,s/3.35 ,6877,54,49)
			areal( r2_bath)
		elseif sroom == 4 then
			abck( r2_couch)
			r2_couch.loc = nvt(-29,0,-29)
			abck( r2_carpet)
			r2_carpet.loc = nvt(-16,0,-26)
			areal( r2_mirtab)
			r2_mirtab.loc = nvt(-7,0,-33)
			r2_mirtab.rot = 0
			abck( r2_win)
			r2_win.loc = nvt(-16,7,-36.5)
			r2_win.rot = 0
			abck( r2_lamp2)
			r2_lamp2.loc = nvt(-13,10,-11)
		elseif sroom == 5 then
			r2_etag=pmesh(r2_etag, -38,-1,-20,s/1.5 ,6980,219,239)
			abck( r2_etag)
			abck( r2_arm)
			r2_arm.loc = nvt(-57,6,-10)
			r2_arm.rot = 0
			abck( r2_box1)
			r2_box1.loc = nvt(-58,4,-19)
			abck( r2_box2)
			areal( r2_door3)
		elseif sroom == 6 then
			r2_alt=pmesh(r2_alt, 25,0,-28,s/2.13 ,7438,159,132)
			r2_alt2 = cloneent(r2_alt, 25,0,28)
			r2_alt2.rot = 0.25
			abck( r2_alt)
			abck( r2_alt2)
			r2_mirror=pmesh(r2_mirror, 0,0,0,s/7 ,7921,54,46)
			
			if (finalanim<4) areal(zombi2)
		end

		if cur_cam == 1 then
			r2_dr.loc = nvt(-28.3,1.9,9.1)
			r2_dl.loc = nvt(-28.5,2.2,-7)
			r2_dl.rot = -0.25
			r2_dr.rot = 0.25
			areal( r2_dr)
			areal( r2_dl)
		elseif cur_cam == 2 then
			r2_dr.loc = nvt(6.7,2.3,11.9)
			r2_dr.rot = -0.25
			areal( r2_dr)
		elseif cur_cam == 0 then
			r2_dl.loc = nvt(7.3,2.4,9.2)
			r2_dl.rot = 0.25
			r2_dr.loc = nvt(6.9,2.4,-7.9)
			r2_dr.rot = -0.25
			areal( r2_dr)
		elseif cur_cam == 13 then
			r2_dl.loc = nvt(21.2,1.7,2.4)
			r2_dl.rot = 0
			r2_dr.loc = nvt(21.2,1.7,-1.8)
			r2_dr.rot = 0
			abck( r2_dl)
			abck( r2_dr)
			areal( r2_dl)
			areal( r2_dr)
			r2_mirror.loc = nvt(25,8,-27.9)
			r2_mirror.rot = 0.825
			if (ac_mir1.anim) abck( r2_mirror)
		elseif cur_cam == 12 then
			r2_mirror.loc = nvt(25,8,27.9)
			r2_mirror.rot = 0.125
			if (ac_mir2.anim) abck( r2_mirror)
		elseif cur_cam == 5 then
			r2_dl.loc = nvt(-13.5,1.7,30.5)
			r2_dl.rot = 0.5
			areal( r2_dl)
		end
	end

	room_ram = stat(0)
end

function sorttrisloop(t,n)
	local tv = #t-1
	for j=1,n do
		for i=1,tv do
			local t1 = t[i]
			local t2 = t[i+1]
			if t1.avg < t2.avg then
				t[i] = t2
				t[i+1] = t1
			end
		end
	end
end

function sortalltris(t)
	local tv = #t-1
	local loop = true
	while loop do
		loop = false
		for i=1,tv do
			local t1 = t[i]
			local t2 = t[i+1]
			if t1.avg < t2.avg then
				t[i] = t2
				t[i+1] = t1
				loop = true
			end
		end
	end
end

function compcam(ent)
	local crot = cos(ent.rot)
	local srot = sin(ent.rot)

	local ldecal = v_mulf(rotvec_y(v_sub(campos, ent.loc), crot, srot), -1)
	local lcamright = rotvec_y(camright, crot, srot)
	local lcamup = rotvec_y(camup, crot, srot)
	local lcamdir = rotvec_y(camdir, crot, srot)
	return ldecal,lcamright,lcamup,lcamdir
end

function draw_tris_do(ent,ptable,tverts)
	local tn = #ptable

	if ent.sort then
		for i=1,tn do
			local ct = ptable[i]
			ct.avg = tverts[ct.v1].z + tverts[ct.v2].z + tverts[ct.v3].z
		end

		if tele_cam then
			sortalltris(ptable)
		else
			sorttrisloop(ptable,2)
		end
	end

	if finalanim>2 and ent == zombi2 then
		if not zendsfx and finalanim>2.3 then sfx(25) zendsfx=true end
		local size = (finalanim-2)*4
		size *= size
		size += 1
		for i=1,tn,1 do
			local ct = ptable[i]
			local v1 = tverts[ct.v1]

			circfill(v1.x,v1.y,size,ct.c)
		end

		return
	end


	for i=1,tn do
		local ct = ptable[i]
		local v1 = tverts[ct.v1]
		local v2 = tverts[ct.v2]
		local v3 = tverts[ct.v3]

		local back = (v2.y-v1.y)*(v3.x-v1.x) - (v2.x-v1.x)*(v3.y-v1.y)

		local minx = min(min(v1.x,v2.x),v3.x)
		local maxx = max(max(v1.x,v2.x),v3.x)
		local miny = min(min(v1.y,v2.y),v3.y)
		local maxy = max(max(v1.y,v2.y),v3.y)
		local minz = min(min(v1.z,v2.z),v3.z)

		local clip = maxx < 0 or minx > 128 or maxy < cpy or miny > csy or minz < 0.01

		if back>=0 and not clip then
			otri(flr(v1.x),flr(v1.y),flr(v2.x),flr(v2.y),flr(v3.x),flr(v3.y),ct.c)
		end
	end
end

function draw_tris(ent)

	if ent == table then
		pal(4,3)
		pal(5,1)
	end

	local ldecal,lcamright,lcamup,lcamdir = compcam(ent)

	local vtable = ent.ver
	local ptable = ent.tri

	local tverts = {}
	local tv = #vtable
	for i=1,tv do
		local cur = clone(vtable[i])

		local side = 1
		if(cur.z<0) side = -1

		cur = v_add(cur,ldecal)
		local cur2 = clone(cur)
		cur2.x = dot(cur,lcamright)
		cur2.y = dot(cur,lcamup)
		cur2.z = dot(cur,lcamdir)

		local invz = 64.0*(1.0/max((cur2.z),0.1))
		cur2.x = (-cur2.x * invz + 63.5)
		cur2.y = (-cur2.y * invz + 63.5)

		tverts[i] = cur2
	end
	
	draw_tris_do(ent,ptable,tverts)

	pal()
end

function rotvec_y(vec, cangle, sangle)
	local cur2 = clone(vec)
	cur2.x = vec.x * cangle + vec.z * sangle
	cur2.z = -vec.x * sangle + vec.z * cangle
	return cur2
end

function draw_tris_checkanim(ent)

	if ent == r2_dl or ent == r2_dr then
		if cur_cam == 5 then
			pal(3,13)
		elseif cur_cam == 2 then
			pal(4,3)
		end
	end

	if ent == zombi2 then
		pal(3,6)
		pal(8,13)
	end

	if ent == pers or ent == zombi then
		draw_tris_anim(ent)
	else
		draw_tris(ent)
	end

	pal()
end

function achar()
	local set = {}
	set.isanim = false
	set.str = 0
	set.time = 0
	return set
end

char = achar()
charzomb = achar()

function draw_tris_anim(ent)

	local vtable = ent.ver
	local ptable = ent.tri

	local cc = char
	if(ent == zombi) cc = charzomb

	if cc.isanim then
		cc.str = lerp(cc.str,0.0,0.1)
	else
		cc.str = lerp(cc.str,1.0,0.5)
	end
	if(cc.str>0.99) cc.time = 0.0

	local runtime = cc.time * 0.8
	local anim = sin(runtime)*0.08
	local canim = lerp(cos(anim),1,cc.str)
	local sanim = lerp(sin(anim),0,cc.str)
	local uanim = lerp(max(0,sin(runtime*1.0 + 0.25)),0,cc.str)
	local anim2 = sin(runtime-0.05)*0.08
	local canim2 = lerp(cos(anim2),1,cc.str)
	local sanim2 = lerp(sin(anim2),0,cc.str)
	local uanim2 = lerp(max(0,sin(runtime*1.0 + 0.5 + 0.25)),0,cc.str)

	local oanim = lerp(max(0,sin(runtime*2.0)),0,cc.str)

	local ldecal,lcamright,lcamup,lcamdir = compcam(ent)

	local cv1 = selectpers and 0.98 or 1.02
	local cv2 = selectpers and 0.3 or 0.9

	local tverts = {}
	local tv = #vtable
	for i=1,tv do
		local cur = clone(vtable[i])
		
		local side = 1
		if(cur.z<0) side = -1

		if cur.y<0.0 and abs(cur.z)<0.95 then
			local oldx = cur.x
			local oldy = cur.y
			local can = canim
			local san = sanim
			local uan = uanim
			if cur.y<-2.3 then
				can = canim2
				san = sanim2
			end
			if(cur.z<0) uan = uanim2

			cur.x = oldx * can + side*oldy * san
			cur.y = -oldx * side * san + oldy * can
			cur.y += -(uan) * cur.y * 0.2
		end
	
		if abs(cur.z)>cv1 then
			local oldx = cur.x
			local oldy = cur.y - 2
			local can = canim
			local san = sanim
			local uan = uanim
			 if cur.y<cv2 then
			 	can = canim2
			 	san = sanim2
			 end

			cur.x = oldx * can - side*oldy * san
			cur.y = oldx * side * san + oldy * can + 2
		end
	
		cur.y += -(oanim) * 0.2
	
		cur = v_add(cur,ldecal)
		local cur2 = clone(cur)
		cur2.x = dot(cur,lcamright)
		cur2.y = dot(cur,lcamup)
		cur2.z = dot(cur,lcamdir)

		local invz = 64.0*(1.0/max((cur2.z),0.1))
		cur2.x = (-cur2.x * invz + 63.5)
		cur2.y = (-cur2.y * invz + 63.5)

		tverts[i] = cur2
	end

	draw_tris_do(ent,ptable,tverts)
end

function _init()

	reset()
	setmusic(-1)

end

function reset()

	room_number = 1

	zombi = nil
	ac_zomb1.anim = nil
	ac_zomb2.anim = nil
	ac_zomb3.anim = nil
	ac_death.anim = nil
	ac_death2.anim = nil

	if(room_number == 2) then
		charstart = nvt(36,4.5,-10)
	else
		charstart = nvt(20.0,4.5,-21.0)	
	end
	
	charstartrot = 0
	add_objects()
	deathtrap1 = false
	deathtrap2 = false
	forcecam = false

	deathanim=0
	finalanim=0
	victoryanim=0

	setmusic(0)
end

function getcam(mx,mz)
	local c = 0
	if room_number == 1 then
		if mx<-10 then
			c = mz>-9.7 and 1 or 4
		else
			if mz>4.5 then
				c = mx>0.0 and ((mx>23 and mz>16) and 3 or 2) or 1
			end
		end
		if(forcecam) c = 5
	else
		if mz>9 then
			if mx<-45 then
				c = 7
			elseif mx<-12 then
				c = mz>29 and 5 or 4
			elseif mx<19 then
				c = mx>8 and 3 or 2
			else
				c = 12
			end
		elseif mz<-10 then
			if mx<-35 then
				c = 6
			elseif mx<0 then
				c = mx>-10 and 8 or 9
			elseif mx<19 then
				c = mz<-21 and 11 or 10
			else
				c = 13
			end
		else
			if mx<-35 then
				c = mx<-43 and 7 or 6
			elseif mx<-28 then
				c = 14
			elseif mx<-5 then
				c = 1
			elseif mx<10 then
				c = 0
			elseif mx<20 then
				c = 15
			else
				c = 13
			end
		end
		if(deathtrap1) c = 16
		if(forcecam) c = 17
	end
	return c
end

actmsgtime=0
actmsggoal=0
acttxttime=0
acttxtgoal=0

actiondone = false

function doaction(action)

	if room_number==action.r and not actiondone then

		local dx = (action.loc.x-pers.loc.x)/action.s
		local dz = (action.loc.z-pers.loc.z)/action.s

		if (dx*dx+dz*dz)<1 then
			if action.sound then
				footsound = action.sound
			elseif action.search or not action.anim then
				if btnp(5) or btnp(4) or action.auto then
					if not action.need or action.need.anim then
						if (not deathtrap1) sfx(action.give and 13 or (action.sfx and action.sfx or 17))
						if action.at or action.search then
							if not action.anim then
								action.anim = 1
								if(action.start) action.start(action)
							end
						end
						acttxt=action.give and action.give or action.t
						action.give=nil
					else
						acttxt=action.needtxt and action.needtxt or "you dont have the key"
						sfx(17)
					end
					acttxtgoal=acttxtgoal>50 and 0 or 100
					actiondone = true
				end
				if action.at then
					actmsg=action.at
				else
					actmsg="look"
				end
				actmsggoal=10
			end
		end

		if action.anim then
			if action.anim>0 then
				if(action.apply) action.apply(action)
				action.anim-=dt
			else
				if action.loop then
					action.loop(action)
					action.anim=nil
				end
			end
		end
	end
end

dt = 1.0/30.0

function czombi(zx,zy,zz)
	zombi = smesh(charzombi, zx,zy,zz,2,strzombv,strzombi)
	areal(zombi)
	return zombi
end

function finalcharanim(ent, off, off2)
	ent.loc = nvt(0,4.5,off)
	ent.rot = sin(time*0.3) * 0.1 + off2
end

charfoot = false

function _update()

	if deathtrap2 or finalvic or selectscreen then
		forcecam = true
	else
		forcecam = false
	end

	numup += 1

	if deathtrap1 or deathtrap2 then
		if time>1 and (btnp(4) or btnp(5)) then
			reset()
		end
	end

	if ac_zomb1.anim and trap.loc.z>35 and zombi == nil then
		czombi(-11,0,34)
	end

	if ac_zomb2.anim and zombi == nil then
		czombi(-27,4.5,-9)
	end

	if ac_zomb3.anim and zombi == nil then
		czombi(-27,4.5,-9)
	end

	if zombi and zombi.loc.y<4.5 then
		zombi.loc.y += 0.1
	end

	if ac_mir1.anim and ac_mir2.anim then
		if(finalanim==0) sfx(24) setmusic(-1)
		finalanim += dt
		if finalanim > 3 then
			del(sortedreal,zombi2)
			setcol(0,69,4,5,3)
			setcol(0,69,25,5,3)
			for k=1,#acsta do del(actions,acsta[k]) end
		else
			if zombi2 then
				zombi2.rot += dt*finalanim
			end
		end
	end

	if room_number == 2 and pers.loc.x>40 then
		if not victory then
			if cur_cam == 12 then
				vicpos = nvt(47,4.5,25)
			else
				vicpos = nvt(45,4.5,-25)
			end
		end
		victory = true
	end

	actmsg = ""
	actmsggoal=0
	actiondone = false
	footsound = 6
	foreach(actions, doaction)

	if not zombi then
		if room_number == 1 then
			if pers.loc.x < -21 and pers.loc.z < -38 then
				charstart = nvt(-52,4.5,6.9)
				charstartrot = 0.25
				room_number = 2
				add_objects()
			end
		else
			if pers.loc.x <-49 and pers.loc.z >12 then
				charstart = nvt(-30,4.5,-33)
				charstartrot = -0.25
				room_number = 1
				add_objects()
			end
		end
	end

	local rspeed = 0.01

	local forward = 0.0
	if deathtrap1 then
		local prog = -deathanim*deathanim*0.03
		pers.loc = nvt(-8,4.5+prog,0.85)
		r2_brok.loc.y = prog
		char.isanim = false
		if (deathanim<100) deathanim +=1
	elseif deathtrap2 then
		finalcharanim(zombi,0,0)
		charzomb.time += dt
		charzomb.isanim = true
		char.isanim = false
	elseif victory then
		victoryanim += dt
		if victoryanim>5 then
			if (not finalvic) time = 0 setmusic(6)
			finalvic = true
			finalcharanim(pers,0,0)
			char.isanim = true
		else
			local dir = (cur_cam == 12) and 1 or -1

			pers.rot = (pers.rot+0.5)%1-0.5

			vicpos.z -= dir*dt*3
			pers.rot = lerp(pers.rot, dir*0.25,0.05)
			pers.loc.x = lerp(pers.loc.x, vicpos.x,0.05)
			pers.loc.z = lerp(pers.loc.z, vicpos.z,0.05)
			pers.loc.y -= dt
			char.isanim = true
		end		
	elseif selectscreen then
		if introanim<introanimdur then

			local titlefinal = nvt(-3,15.05,0.91)
			local titleinit = nvt(2,3.5,-4.1)

			local an = min(1,introanim/introanimdur)
			an*=an
			title.loc.x = lerp(titleinit.x,titlefinal.x,an)
			title.loc.y = lerp(titleinit.y,titlefinal.y,an)
			title.loc.z = lerp(titleinit.z,titlefinal.z,an)
			title.rot = lerp(0.125,0,an)

			introanim+=dt
		else
			if isintroanim then
				setmusic(7)
				isintroanim=false
				need_paste=false
				tele_cam=true
			end

			time /=3
			finalcharanim(pers,-3,-0.1)
			finalcharanim(fepers,3,0.1)
			time *=3
			if btnp(0) or btnp(1) then
				sfx(17)
				selectpers = not selectpers
			end
			if btnp(4) or btnp(5) then
				sfx(17)
				selectscreen = false
				reset()
			end
		end
	else
		if(btn(0)) pers.rot += rspeed
		if(btn(1)) pers.rot -= rspeed
		if(btn(2)) forward += 0.3
		if(btn(3)) forward -= 0.15

		if btn(0) or btn(1) or btn(2) or btn(3) then
			char.isanim = true
		else
			char.isanim = false
		end
	end
	char.time += dt

	if char.isanim and not finalvic then
		local runtime = char.time * 0.8
		local anim = abs(sin(runtime))
		if anim>0.75 then
			if not charfoot then
				if (victory) footsound = 8
				sfx(footsound+rnd(2))
				charfoot = true
			end
		else
			charfoot=false
		end
	end

	local crot = cos(pers.rot)
	local srot = sin(pers.rot)

	local iscol = checkcol(pers.loc.x,pers.loc.z)
	local nx = pers.loc.x + crot * forward
	local nz = pers.loc.z + srot * forward
	local ncol = checkcol(nx,nz)
	if ncol and not checkcol(nx,pers.loc.z) then
		nz = pers.loc.z
		ncol = false
	end
	if ncol and not checkcol(pers.loc.x,nz) then
		nx = pers.loc.x
		ncol = false
	end
	
	if not ncol then
		pers.loc.x = nx
		pers.loc.z = nz
	end

	if zombi and not deathtrap2 and zombi.loc.y>4 then
		charzomb.isanim = false
		charzomb.time += dt

		local edx = (pers.loc.x - zombi.loc.x) * 0.1
		local edz = (pers.loc.z - zombi.loc.z) * 0.1
		local edist = sqrt(edx*edx + edz*edz)
		if edist > 0.3 then
			edx /= edist
			edz /= edist

			local ang = (1 - edx) * 0.25
			if(edz >= 0) ang = (edx+3) * 0.25

			zombi.rot = ang
			zombi.loc.x += edx*0.3
			zombi.loc.z += edz*0.3

			charzomb.isanim = true
		else
			deathtrap2 = true
			setmusic(8)
			time = 0
		end
	end

	local lastcam = cur_cam
	cur_cam = getcam(pers.loc.x, pers.loc.z)

	if not (lastcam == cur_cam) then
		need_paste = false
		tele_cam = true
	end

	local curcam = cams[cur_cam+1]

	sroom = curcam.room

	camtar = clone(curcam.tar)
	campos = clone(curcam.pos)
	camup = nvt(0,1,0)

	camdir = v_norm(v_sub(camtar,campos))
	camright = v_norm(v_cross(camup,camdir))
	camup = v_cross(camdir,camright)

	time += dt
end

function ent_compavg2d(ent)
	local p2d = v_sub(campos, ent.loc)
	p2d.x *= 0.1
	p2d.z *= 0.1
	ent.avg = (p2d.x*p2d.x+p2d.z*p2d.z)
end

function setcol(val,x,y,sx,sy)
	for i=x,x+sx-1 do
		for j=y,y+sy-1 do
			mset(i,j,val)
		end
	end
end

function checkcol(x,y)

	local px = 35
	local sx = 35
	local py = 50
	local sy = 50
	local dx = 0
	if room_number == 2 then
		px = 40
		sx = 40
		py = 62
		sy = 55
		dx = 64
		x,y = y,x
	end

	local pi = 64-(y + py) / (2*sy)*64 + 0.5
	local pj = (x + px) / (2*sx) * 32 + 0.5

	if pi<0 or pi>63 or pj<0 or pj>31 then
		return true
	end

	local v = mget(pi+dx,pj)
	return v==1
end

function dcol(offx)
	for j=0,31 do
		for i=0,63,8 do		
			local mul = 1
			for k=0,7 do
				mset(i+offx+k,j, min(band(peek(cur_addr),mul),1))
				mul *= 2
			end
			cur_addr += 1
		end
	end

end

frame_chunk_0 = 0x3E00
frame_chunk_1 = 0x4300

need_paste = false

strzombv = "7d5b907d5b8a768890650e766b1b76780f7081ce8481c88487c88462ad916fae9168c79e87c87e81c87e81ce7e6a41777755706b21767d5570850f7c780e8f6b1b89650e899baf5e9bbc5774bb6468c15e74c86b9bb6517d55777d558a7d55906b21897755906b418a63878163879187db8b8ddb848de18a75c79767c7656ece81638771768871705b706eae717bae77705b8a715b907bae8a6be5857aee857aee7edbb75ddbb150ceb7578ed5838ddb7e87d48487d57e8ed57f87db78e1aa5687d18487d17ecfb6aae2b0b0dbb6a374c7845cad819bbbaa68c0a475ba9e9cafa49cb5b074c87e7ae1748de179e2aaa962ae717d5b707c887d74da8b6ec7846ec77e76887d7d5b7774db787ae18f68ba977688846be57e87c37e88c384850f83705b77"
strzombi = "03022b555603030c0b2903031c2f2a03030c470a03035333030b033132250103025c3124250a040339373840040350454443070358522d2e2c24470303512d2c0503140605041407031113121e1011120503601716156007031f202122231f2113033f3b3d3e3c3a273b284f3536345d594e3f364f090335345a5426073c414209030e0d5e095f084607540703545446594d0f0e03033c272604032835265a06032e612458572d05031d1939181d05034b48434c4b06033c423d0f3f59030359543405030e5e4d5f460303364e5d03033b3a3e0507424109070805070e0f0d42090308240a4705080c0a0b250305084b4a482949070829290c2b47512c05085b4b494c480808191d1b181a191c1b0d085353302d2f512a2b1c563033530308302f1c070803030b3329552b0308565533030a282627030a4f3b3f"

function ptext(x,y,s,t)
	rectfill(x,y,x+s,y+10,1)
	circfill(x+s,y+5,5,1)
	circfill(x,y+5,5,1)
	print(t,x,y+2,7)
end

function _draw()

	if need_paste then

		memcpy(0x6000,frame_chunk_0,0x0400)
		memcpy(0x6400,frame_chunk_1,0x1c00)

	else

		cls()
		if selectscreen then
			rectfill(0,0,128,128,1)
			if not isintroanim then
				rectfill(18,4,114,48,0)
				rectfill(10,64,52,108,5)
				rectfill(10+64,64,52+64,108,5)
			end
		end

		fillsorted()
	
		foreach(bground, ent_compavg2d)
		if(room_number == 2 and cur_cam == 1) r2_1.avg = 10
		sortalltris(bground)
		foreach(bground, draw_tris)

		foreach(sortedback, ent_compavg2d)
		sortalltris(sortedback)
		foreach(sortedback, draw_tris)

		clearstatic2()
		bground = {}
		sortedback = {}

		memcpy(frame_chunk_0,0x6000,0x0400)
		memcpy(frame_chunk_1,0x6400,0x1c00)
		need_paste = true	

	end

	if room_number == 2 then
		if cur_cam == 2 then
			cpy = 40
			csy = 90
			clip(0,cpy,128,csy-cpy)
		end

		del(sortedreal, r2_bar)
		del(sortedreal, r2_bar2)
		if pers.loc.z>24 then
			areal( r2_bar)
		else
			areal( r2_bar2)
			if cur_cam == 3 then
				areal( r2_bar)
			end
		end
	else
		if cur_cam == 1 then
			del(sortedreal, pilars[1])
			del(sortedreal, pilars[2])
			areal( pilars[(pers.loc.z>15) and 1 or 2])
		end
	end

	if room_number == 1 and cur_cam != 0 then
		draw_tris(trap)
	end

	if selectscreen and not isintroanim then
		cpy = 0
		csy = 108
		clip(0,cpy,128,csy-cpy)
	end

	foreach(sortedreal, ent_compavg2d)
	sortalltris(sortedreal)
	foreach(sortedreal, draw_tris_checkanim)

	cpy = 0
	csy = 128
	clip()

	if room_number == 1 and cur_cam == 0 then
		circfill(-1000,10000,10000 - 42,3)
	end
	
	tele_cam = false

	if deathtrap1 or deathtrap2 then
		ptext(4,min(0,time*18-11),119,"you died alone ... in the dark")
		if time>1 then
			print("press x to continue anyway",12,16,flr(time*3)%2+6)
		end
		actmsgtime = actmsggoal
		acttxttime = acttxtgoal
	elseif finalvic then
		ptext(4,min(0,time*18-11),119,"you escaped from the mansion")
		if time>1 then
			print("thank you for playing",20,16,7)
			print("nusan - 2016",40,120,7)
		end
	elseif selectscreen then
		if not isintroanim then
			print("nusan - 2016",40,4,5)
			print("in",94,29,10)
			print("pico",94,38,10)
			local cm = selectpers and 7 or 0
			local cf = selectpers and 0 or 7
			rect(10,64,52,108,cf)
			rect(10+64,64,52+64,108,cm)

			print("emily",24,110,cf)
			print("hartwood",18,116,cf)
			print("edward",84,110,cm)
			print("carnby",84,116,cm)
			print("select your character",24,56,7)
		end
	else
		actmsgtime += min(1,max(-1,actmsggoal-actmsgtime))
		acttxttime += min(1,max(-1,acttxtgoal-acttxttime))
		ptext(0,128-actmsgtime,24,actmsg)
		if(acttxt) ptext(36,128-min(10,50-abs(acttxttime-50)),120,acttxt)
	end
	
	--[[
	if false then
		local debcol = (numup>1) and 8 or 7
		numup = 0
		print("cpu:"..stat(1)*100,96,0,debcol)
	end]]--

end