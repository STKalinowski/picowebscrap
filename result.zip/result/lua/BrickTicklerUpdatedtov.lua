-- bricktickler
-- (c) fistfulofsquid
p={}
scrn={}
balls={}
bricks={}
freeb={}
scores={}
level=0
max_level=5
lvl_tmr=0
shadow={}
go_reason=0

left=8
cam={}

function _init()
	music(0)
	shadow.x=2
	shadow.y=2
	cam.x=0
	cam.y=0
	cam.dx=0
	cam.dy=0
	scrn.draw=draw_titles
	scrn.upd=upd_titles
	make_bg()
end

function _update60()
	scrn.upd()
end

function _update()
 _update60()
 _update_buttons()
 _update60()
end

function _draw()
	rectfill(0,0,127,127,1)
	scrn.draw()
end

function new_game()
	go_reason=0
	level=0
	p.x=58
	p.y=127-8
	p.w=20
	p.dx=0
	p.dy=0
	p.ty=p.y
	p.score=0
	p.balls=3
	new_ball()
	next_level()
end

function next_level()
	level+=1

	if level%2==0 then
		music(10)
	else
		music(4)
 end
 
	if level>max_level then
		level=1
	end
	load_bricks(level)
	lvl_tmr=0
end

function load_bricks(level)
	bricks={}
	n=64
	x=(n%16)*8
	y=flr(n/16)*8

	x+=(level-1)*10

	for sy=0,9 do
		for sx=0,9 do
			c=sget(x+sx,y+sy)
			if c>0 then
				br={}
				br.tx=sx*12+6
				br.ty=sy*4+32
			
				br.x=br.tx
				br.y=br.ty-20
				br.dx=0
				br.dy=0
				br.free=false
			
				br.appear_tmr=60+(sx+(8-sy))*2
				if c==1 then
					br.col=10
					br.sprite=8
			 else
					br.col=c
					br.sprite=4
				end
				
				add(bricks,br)
			end
		end
	end
end

function new_ball()
	b={}
	b.x=p.x+p.w*0.5-2
	b.y=p.y-5
	b.dx=0
	b.dy=0
	b.serve=true
	add(balls,b)
	return b
end

function floaty_score(x,y,value)
	s={}
	s.x=x
	s.y=y
	s.dy=-(0.1+rnd(0.1))
	s.ttl=50
	s.value=value
	add(scores,s)
end

function upd_titles()
	upd_bg()
	if btnp(4) or btnp(5) then
		new_game()
		scrn.upd=upd_game
		scrn.draw=draw_game
	end
end

function draw_titles()
	draw_bg()
	x=30
	t=time()*0.4
	s="brick tickler"
	for i=1,#s do
		y=cos(t+0.07*i)*6
		c=sub(s,i,i)
		print(c,x+2,50+y+2,0)
		print(c,x,50+y,7)
		x+=5
	end

	print("a game by",46+2,86+2,0)
	print("a game by",46,86,14)

	print("@joeyspacerocks",34+2,93+2,0)
	print("@joeyspacerocks",34,93,12)

	print("greatly enhanced music by",14+2,104+2,0)
	print("greatly enhanced music by",14,104,14)

	print("@gruber_music",38+2,111+2,0)
	print("@gruber_music",38,111,12)
end

function upd_game_over()
	upd_bg()
	if btnp(5) then
		scrn.upd=upd_titles
		scrn.draw=draw_titles
		music(0)
	end
end

function draw_game_over()
	draw_game()
	y=80
	if go_reason==1 then
		print("you've dropped all your balls",6+2,y+2,0)
		print("you've dropped all your balls",6,y,7)
	else
		print("you've bricked it",30+2,y+2,0)
		print("you've bricked it",30,y,0)
	end
	print("the game. it's over",26+2,y+7+2,0)
	print("the game. it's over",26,y+7,7)
end

function game_over(r)
	go_reason=r
	scrn.upd=upd_game_over
	scrn.draw=draw_game_over
end

function upd_game()
	upd_bg()
	
	if btn(0) then p.dx=-2.8 end
	if btn(1) then p.dx=2.8 end

	p.x+=p.dx
	p.dx*=0.7

	if p.x<left then
		p.x=left
		p.dx=0
	elseif p.x>128-p.w then 
		p.x=128-p.w
		p.dx=0
	end

	local	f=spring(p.x,p.y,p.dx,p.dy, 25,10,0, p.x,p.ty)
	p.dy+=f.y/60
	p.y+=p.dy

	if zeroish(p.dy) and zeroish(p.y-p.ty) then
		p.dy=0
		p.y=p.ty
	end
	
	for b in all(balls) do
		if b.serve then
			b.x=p.x+p.w*0.5-2

			b.x+=rnd(3)-1
			b.y=p.y-6+rnd(2)

			if btnp(4) or btnp(5) then
				b.serve=false
				b.dx=sgn(rndi(2)-0.5)
				b.dy=-1.5
				p.dy=2
			end
		
		else
			if ball_coll(b,p.x,p.y,p.w+4,6) then
				if b.dy<0 then
					d=(b.x+2-(p.x+p.w*0.5))/p.w*0.5
					b.dx=(d+sgn(d)*0.1)*3
					p.dy+=4
					sfx(0)
				end
			end

			shake_x=0
			shake_y=0
			shake_dx=0
			shake_dy=0
			
			for br in all(bricks) do
				pdx=b.dx
				pdy=b.dy
			 if ball_coll(b,br.x,br.y,12,4) then
					br.dy=-1-rnd(1)
					br.dx=b.dx*0.5
					br.bounces=0
					br.hit_tmr=20
					
			 	add(freeb,br)
			 	del(bricks,br)

			 	add_score(p,50)
					sfx(1)
					shake_x=br.x
					shaky_y=br.y
					shake_dx=pdx
					shake_dy=pdy
					
					if br.sprite==8 then
						b2=new_ball()
						b2.x=b.x
						b2.y=b.y
						b2.dx=sgn(b.dx)*(rnd(1)*0.5+0.5)
						b2.dy=sgn(b.dy)*(rnd(0.3)+1.2)
						b2.serve=false
						sfx(9)
					end
				end
			end

			if shake_x>0 then
		 	shake_bricks(shake_x,shake_y,shake_dx,shake_dy)
			end

			-- ball
			b.x+=b.dx
			b.y+=b.dy

			if b.x<left then
				b.x=left
				cam.dx=b.dx
				b.dx=-b.dx
				sfx(0)
			elseif b.x>127 then
				b.x=127
				cam.dx=b.dx
				b.dx=-b.dx
				sfx(0)
			end

			if b.y<0 then
				cam.dy=b.dy
				b.dy=-b.dy
				sfx(0)

		 elseif b.y>180 then
		 	del(balls,b)
		 end
		end
	end

	if #bricks>0 then
		if bricks[1].appear_tmr==60 then
			sfx(2)
		end

		for br in all(bricks) do
			if br.appear_tmr>0 then
				br.appear_tmr-=1
				if br.appear_tmr<30 then
					if br.y!=br.ty then
						br.y+=(br.ty-br.y)*0.1
						if abs(br.y-br.ty)<1 then
							br.y=br.ty
						end
					end
				end
			
			else
				f=spring(br.x,br.y,br.dx,br.dy, 25,10,0, br.tx,br.ty)
				br.dx+=f.x/60
				br.dy+=f.y/60
				br.x+=br.dx
				br.y+=br.dy

				if zeroish(br.dx) and zeroish(br.dy) and zeroish(br.x-br.tx) and zeroish(br.y-br.ty) then
					br.dx=0
					br.dy=0
					br.x=br.tx
					br.y=br.ty
				end
			end
		end
	end

	for br in all(freeb) do
	 if br.hit_tmr>0 then
 		br.hit_tmr-=1
 	end
		
		br.x+=br.dx
		if (br.x<left or br.x>127) then
			br.dx=-br.dx
		end
		
		br.y+=br.dy
		if br.dy<8 then br.dy+=0.1 end
		
		if br.y>130 then
			del(freeb,br)
			
		elseif coll(br.x,br.y,12,4,p.x,p.y,p.w+4,6) then
			if br.dy>0 and br.dy>2 then
				br.bounces+=1
				br.dy=-br.dy*0.7
				p.dy+=4
				
				add_score(p,br.bounces*5)
				floaty_score(br.x,br.y,br.bounces*5)
				if br.bounces==1 then
					sfx(4)
				else
					sfx(7)
				end
			end
		end
	end
	
	if #balls==0 then
		sfx(6)
		p.balls-=1
		if p.balls<0 then
		 game_over(1)
		else
			new_ball()
		end
	end
	
	lvl_tmr+=1
	if lvl_tmr>600 and lvl_tmr%30==0 then
		sfx(8)
	end
	
	if #bricks==0 then
		next_level()
	
	elseif lvl_tmr>=800 then
		sfx(5)
		lvl_tmr=0
		for br in all(bricks) do
			br.ty+=4
			if br.ty>p.y-4 then
				game_over(2)
			end
		end
	end
	
	for s in all(scores) do
		s.y+=s.dy
		s.x+=sin(s.ttl*0.01)*0.3
		s.ttl-=1
		if s.ttl<0 then
			del(scores,s)
		end
	end
	
	--camera
	local	f=spring(cam.x,cam.y,cam.dx,cam.dy, 25,10,0, 0,0)
	cam.dx+=f.x/60
	cam.x+=cam.dx
	cam.dy+=f.y/60
	cam.y+=cam.dy

	if zeroish(cam.dy) and zeroish(cam.dx) and zeroish(cam.x) and zeroish(cam.y) then
		cam.dx=0
		cam.x=0
		cam.dy=0
		cam.y=0
	end
	
	camera(cam.x,cam.y)
end

function shake_bricks(x,y,dx,dy)
	for br in all(bricks) do
		fx=x-br.x
		fy=y-br.y
		d=fx*fx+fy*fy

		if d<10000 then
			s=50/sqrt(d)
			br.dx=dx*s
			br.dy=dy*s
		end
		
	end
end

function make_bg()
	bg={}
	for i=0,29 do
		d=min(flr(i/10),1)
		c={}
		c.x=(i%15)*15+rndi(4)
		c.y=115+rndi(5+(1-d)*5)+d*12
		c.r=10+rnd(3)-d*1
		c.dx=0.1+d*0.2
		c.col=2+d*12
		add(bg,c)
	end
end

function upd_bg()
	for c in all(bg) do
		c.x+=c.dx
		if c.x>127+c.r then
		 c.x=-c.r+1
		end
	end
end

function draw_bg()
	for c in all(bg) do
		y=c.y+sin(c.x*0.05)*2
		circfill(c.x,y,c.r,c.col)
		circfill(127-c.x,125-y,c.r,c.col)		
	end
end

function draw_bat(x,y,w)
	spr(2,x,y)
	x+=8
	for i=0,w-16-1 do
		spr(10,x,y)
		x+=1
	end
	spr(3,x,y)
end

function draw_game()
	draw_bg()
	
	-- ui

	ppad(p.score,8,48+1,2+1,0)
	ppad(p.score,8,48,2,7)

	for i=1,p.balls do
		pal(7,0)
		spr(1,i*6-2+shadow.x,2+shadow.y)
		pal(7,10)
		spr(1,i*6-2,2)
	end

	if lvl_tmr<600 or lvl_tmr%30<20 then
		y1=20+(lvl_tmr/800)*80
		y2=100	
		pal(7,0)
		line(2+shadow.x,y1+shadow.y,2+shadow.x,y2+shadow.y,7)
		pal(7,7)
		line(2,20,2,y2,2)
		line(2,y1,2,y2,7)
	end
	
	-- game

	pal(7,0)
	--bat
	draw_bat(p.x+shadow.x,p.y+shadow.y,p.w)
	--ball
	for b in all(balls) do
		bx=b.x
		by=b.y
		spr(1,bx+shadow.x,by+shadow.y)
		spr(32,bx+shadow.x-b.dx,by+shadow.y-b.dy)
		spr(33,bx+shadow.x-b.dx*2,by+shadow.y-b.dy*2)
	end
	
	draw_bricks(bricks)

	pal(7,7)
	--bat
	draw_bat(p.x,p.y,p.w)
	--ball
	for b in all(balls) do
		bx=b.x
		by=b.y
		pal(7,12)
		spr(1,bx-b.dx,by-b.dy)
		spr(32,bx-b.dx*2,by-b.dy*2)
		spr(33,bx-b.dx*3,by-b.dy*3)
		pal(7,7)
		spr(1,bx,by)
	end

	for s in all(scores) do
		pal(7,0)
		sp=17+flr(s.value/5)
		spr(16,s.x+shadow.x,s.y+shadow.y)
		spr(sp,s.x+4+shadow.x,s.y+shadow.y)

		pal(7,rndi(8)+8)
		spr(16,s.x,s.y)
		spr(sp,s.x+4,s.y)
	end

	pal(7,7)
end

function sprs(n,x,y,w,h,s)
	sx=(n%16)*8
	sy=flr(n/16)*8
	
	dx=x-(w*8*s-w*8)*0.5
	dy=y-(h*8*s-h*8)*0.5

	sspr(sx,sy,w*8,h*8,dx,dy,w*8*s,h*8*s)
end

function draw_bricks(bricks)
	pal(7,0)
	for br in all(bricks) do
		if br.appear_tmr==0 then
			spr(br.sprite,br.x+shadow.x,br.y+shadow.y,2,1)
		end
	end

	for br in all(bricks) do
		pal(7,br.col)
		s=0
		if br.appear_tmr==0 then
			s=br.sprite
		elseif br.appear_tmr<5 then
			s=8
		elseif br.appear_tmr<25 then
			s=6
		end
		if s>0 then
			spr(s,br.x,br.y,2,1)
		end
	end

	for br in all(freeb) do
		pal(7,0)
		if br.hit_tmr>0 then
		 sf=(br.hit_tmr/20)*1+1
			sprs(br.sprite,br.x+shadow.x,br.y+shadow.y,2,1,sf)
		else
			spr(br.sprite,br.x+shadow.x,br.y+shadow.y,2,1)
		end
	end
	
	for br in all(freeb) do
		pal(7,4)
		spr(6,br.x-br.dx*2,br.y-br.dy*2,2,1)
		spr(6,br.x-br.dx,br.y-br.dy,2,1)

		if br.hit_tmr>0 then
			pal(7,7)
		 sf=(br.hit_tmr/20)*1+1
			sprs(br.sprite,br.x+shadow.x,br.y+shadow.y,2,1,sf)
		else
			pal(7,br.col)
 		spr(br.sprite,br.x,br.y,2,1)
		end
	end
	
	pal(7,7)
end

function rndi(n)
	return flr(rnd(n))
end

function ball_coll(b,x,y,w,h)
	if not coll(b.x,b.y,4,4,x,y,w,h) then return false end

	if b.x<x then
		b.dx=-abs(b.dx)
	elseif b.x>x+w then
		b.dx=abs(b.dx)
	end
	
	if b.y<y then
		b.dy=-abs(b.dy)
	elseif b.y>y then
		b.dy=abs(b.dy)
	end

	return true
end

function coll(x1,y1,w1,h1,x2,y2,w2,h2)
	return x1+w1>x2 and x1<x2+w2 and y1+h1>y2 and y1<y2+h2
end

function rndsgn()
 if rndi(2)==0 then
  return -1
 else
  return 1
 end
end

function palc(c)
	for i=1,15 do pal(i,c) end
end

function palr()
	for i=1,15 do pal(i,i) end
end

-- k:strength, b:friction, d:sep
-- ax,ay:anchor
-- f = - kx - bv

function spring(px,py,dx,dy, k,b,d, ax,ay)
 local x=px-ax
 local y=py-ay

 if d>0 then
  x*=-d
  y*=-d
 end

 local f={}
 f.x=-k*x-b*dx
 f.y=-k*y-b*dy
 return f
end

function zeroish(n)
	return abs(n)<0.5
end

function add_score(p,n)
	p.score+=shr(n,16)
end

function ppad(n,l,x,y,col)
 local s = ""
 local v = abs(n)
 while v>0 do
  s = shl(v % 0x0.000a, 16)..s
  v /= 10
  l-=1
 end

	for i=1,l do
		print("0",x,y,col)
		x+=4
	end

	if n!=0 then
		print(s,x,y,col)
	end
end
if(_update60)_update=function()_update60()_update_buttons()_update60()end