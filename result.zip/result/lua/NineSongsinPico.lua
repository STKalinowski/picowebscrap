--9 songs in pico-8
--by robby duguay
--www.robbyduguay.com

--if you want me to make more
--just buy some stuff from
--robbyduguay.bandcamp.com

--thanks to dann toliver
--for making the visualizer

--thanks to gabby darienzo
--for design help

--thanks to andrew carvalho
--for help with math

--find out how to add this to your game here
--http://www.robbyduguay.com/2015/11/sharing-music-between-pico-8-carts/

composer="robby duguay"
track=1
t=0  --frames for buffering stuff
playing=false
fr=0 --frames since song start
step=0
stepper=stat(20)
beat=0
title=true

--draw the background
cls()
music(-1)

--track metadata
--tracks display in this order
track_listing = {
	{trackname="arpument", 
		artist=composer, 
		start=0,
		finish=10,
		colour=2,
		speed=48,
		mainrate=100,
		altrate=200,
		blackrate=30
		},
	{trackname="walkabout", 
		artist=composer, 
		start=11,
		finish=15,
		colour=4,
		speed=72,
		mainrate=100,
		altrate=200,
		blackrate=30
		},
	{trackname="factory fresh", 
		artist=composer, 
		start=22,
		finish=26,
		colour=5,
		speed=60,
		mainrate=15,
		altrate=25,
		blackrate=8
		},
	{trackname="seaside town", 
		artist=composer, 
		start=16,
		finish=21,
		colour=12,
		speed=50,
		slow=8,
		mainrate=100,
		altrate=100,
		blackrate=30
		},
	{trackname="empire", 
		artist=composer, 
		start=27,
		finish=32,
		colour=8,
		speed=60,
		mainrate=100,
		altrate=10,
		blackrate=30
		},
	{trackname="melancholy", 
		artist=composer, 
		start=33,
		finish=36,
		colour=1,
		speed=80,
		slow=4,
		mainrate=100,
		altrate=1000,
		blackrate=30
		},
	{trackname="mission", 
		artist=composer, 
		start=37,
		finish=42,
		colour=2,
		speed=60,
		mainrate=30,
		altrate=80,
		blackrate=30
		},
	{trackname="hijinx", 
		artist=composer, 
		start=43,
		finish=52,
		colour=3,
		speed=24,
		mainrate=100,
		altrate=100,
		blackrate=30
		},
	{trackname="out of control", 
		artist=composer, 
		start=53,
		finish=62,
		colour=7,
		speed=24,
		mainrate=100,
		altrate=30,
		blackrate=0
		},
	}

function track_control()
	step=0
	beat=0
	cls()
	--looping first to last, last to first 
	if (track==(#track_listing)+1) then
		track=1
		t=0
	end
	if (track==0) then
		track=(#track_listing)
		t=0
	end

	--start the song, already.
	song=track_listing[track]
	if (playing) then
		music(song.start,120) 
		fr=0
	end

end

function get_speed(sfx)
  return peek(0x3200+68*sfx+65)
end

function _update()
	--track change buffer
	t+=1

	--stat20 is current step of ch1
	--step counts "beats so far"
	if (stepper!=stat(20)) then
		step+=1
		stepper=stat(20)
	end
	
	--get info for current track
	song=track_listing[track]
	steps=((song.finish-song.start)+1)*32
	songposition=step/steps

	--reset frame per song counter
	if (songposition>1) then
		fr=0
	end

	--next track
	if (btnp (1,(0))) and title==false then
		track+=1
		track_control()
	end

	--previous track
	if (btnp (0,(0)) and (t<90 or playing==false)) and title==false then
		track-=1
		track_control()
		t=0
	end
	if (btnp (0,(0)) and (t>=90 and playing==true)) then
		track_control()
		t=0
	end

	--play	
	if (btnp (2,(0)) and playing==false) and title==false then
		playing=true
		track_control() 
		step=0
	end

	--stop
	if (btnp (3,(0))) and title==false then
		music(-1,300) 
		playing=false
	end

	--turning off the title screen
	if title==true and btn(0,(0)) then
		title=false
		cls()
		track=1
		elseif title==true and btn(1,(0)) then
			title=false
			cls()
			track=1
		elseif title==true and btn(2,(0)) then
			title=false
			cls()
			track=1
		elseif title==true and btn(3,(0)) then
			title=false
			cls()
			track=1
		elseif title==true and btn(4,(0)) then
			title=false
			cls()
			track=1
		elseif title==true and btn(5,(0)) then
			title=false
			cls()
			track=1
	end

end

function _draw()

	--art
	offset= 4
	width=122-offset
	height=82-offset

	if oldstep!=step then
		-- slow = song.slow or 1
		beatable = not song.slow or step%song.slow==1
		if beatable then
			beat=(beat+1)%3
			if beat == 0 then
			cls()
			beat=1
			end
		end
		oldstep=step
	end

	if playing==true then
			for y=0, height do
				for x=0, width do
					colour=song.colour
					othercolour = song.colour + 10
					--after the beat starts, draw main colour
					if beat==1 then
						if rnd(song.mainrate)<2 then
							pset(offset+x,offset+y,colour)
						end
					--at the same time, draw the alt colour
						if rnd(song.altrate)<2 then
							pset(offset+x,offset+y,othercolour)
						end
					end
					--after the second beat, draw black
					if beat==2 then
						if rnd(song.blackrate)<2 then
							pset(offset+x,offset+y,0)
						end
					end
				end
			end
	end

	if (title) then
		grid=128/8
		--draw title screen 
		rectfill(grid*3,grid*0,grid*5-1,grid*1-1,8)
		rectfill(grid*1,grid*1,grid*7-1,grid*7-1,7)
		rectfill(grid*1,grid*1,grid*3-1,grid*3-1,9)
		rectfill(grid*5,grid*1,grid*7-1,grid*3-1,15)
		rectfill(grid*0,grid*3,grid*1-1,grid*5-1,10)
		rectfill(grid*7,grid*3,grid*8-1,grid*5-1,14)
		rectfill(grid*1,grid*5,grid*3-1,grid*7-1,11)
		rectfill(grid*5,grid*5,grid*7-1,grid*7-1,2)
		rectfill(grid*3,grid*7,grid*5-1,grid*8-1,12)

		print ("nine songs",grid*3-3,grid*3+6,8)
		print ("in pico-8",grid*3-2,grid*4+6,8)
		print ("robby duguay",grid*5+1,grid*7+5,7)
	end

	if not (title) then
		--border
		rect(0,0,127,127,song.colour)

		--background of timing bar
		rect(15,87,113,92,6)
		rectfill(16,88,112,91,0)

		-- d-pad
		rectfill(24,109,36,111,6)
		rectfill(29,104,31,116,6)
		print ("play",23,98,6)
		print ("stop",23,118,6)
		print ("prev",7,108,6)
		print ("next",39,108,6)

		--show track info on screen
		print ("track " .. track,61,98,song.colour)
		print (song.trackname,61,108,song.colour)
		print (song.artist,61,118,song.colour)
	end

	if (playing) then
		--frames since start of song
		fr+=1
		--timing bar
		rectfill(16,88,(((songposition*97)%97)+16),91,song.colour)
	end

end