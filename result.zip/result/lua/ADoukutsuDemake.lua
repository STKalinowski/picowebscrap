-- a doukutsu demake
-- by andrew + timothy miller

objects = {}
message = ''
cam = {x=0,y=0,dir=1,accel=0}
lvl_cam = {x=0,y=0}
char = {x=0,y=0}
weapon = {
	exp = 0,
	lvl = 1
}
crossfade={max=24}
music_on=true
pause_player=false
player_death=nil
text_object={}
t = 0
cartdata('doubt_douk')

collision_types = {
	l45  = {0,1,2,2,3,4,6,7},
	r45  = {6,5,4,4,2,2,1,0},
	r30b = {7,7,6,6,5,5,4,4},
	r30t = {3,3,2,2,1,1,0,0},
	l30b = {4,4,5,5,6,6,7,7},
	l30t = {0,0,1,1,2,2,3,3}
}

angle_tiles = {
	_65 = 'r30b',
	_66 = 'r30t',
	_67 = 'l30t',
	_68 = 'l30b',
	_69 = 'r45',
	_70 = 'l45',
	_97 = 'r30b',
	_98 = 'r30t',
	_99 = 'l30t',
	_100 = 'l30b'
}

scene = {
	active_door = nil,
	name_delay = 60,
	update = function()
		if (crossfade.max_t) then
			local dt = t - crossfade.max_t
			if crossfade.max - flr(dt / 2) > 0 then
				crossfade.size = crossfade.max - flr(dt / 2)
			else
				crossfade.max_t = nil
				crossfade.size = nil
			end
		end

		if (scene.name_t) then
			message = scene.name
			if (scene.name_t + scene.name_delay < t) then
				scene.name_t = nil
				message = nil
			end
		end
	end,
	one = {
		draw = function()
			camera(0,0)

			map(0,0,0,0,128,128)

			-- draw objects
			foreach(objects, function(o)
				draw_object(o)
			end)

			map(0,0,0,0,128,128,2)
		end,
		update = function()
			if (rnd(1) < 0.03) init_object(water_drops,41,48)

			if (rnd(1) < 0.03) init_object(water_drops,73,48)
		end,
		init = function()
			scene.name = "start point"
			scene.name_t = t
			objects = {}
			lvl_cam = {x=0,y=0}

			init_object(door,7*8,3*8)
			init_object(save_disk,12*8,7*8)
			init_object(health_station,11*8,7*8)
			
			if (scene.active_door) then
				init_object(player, 7*8, 3*8)
			else
				init_object(player, 64, 64)
			end

			pause_player = false
		end
	},
	two = {
		draw = function()
			physics_cam()

			map(20,2,-232,-40,96-31,46)
			scene.coords = {20,2,-232,-40,96-31,46}

			foreach(objects, function(o)
				draw_object(o)
			end)
		end,

		update = function()
			if (rnd(1) < 0.03) then
				local drops = {
					{52, 31},
					{47, 32},
					{59, 36},
					{62, 37}
				}
				for i=1,count(drops) do
					local co = get_lvl_coords(drops[i][1]*8, drops[i][2]*8)
					if (co) init_object(water_drops,co.x,co.y)
				end
			end
		end,

		init = function()
			scene.name = "first cave"
			scene.name_t = t
			objects = {}
			-- lvl cam is the tilemap offset. hacky, but functional
			lvl_cam = {x=392,y=56} -- 20*8+232  2*8+40

			local d1_pos = get_lvl_coords(56*8,10*8)
			local d2_pos = get_lvl_coords(72*8,35*8)
			local d3_pos = get_lvl_coords(74*8,8*8)

			init_object(door,d1_pos.x,d1_pos.y)
			init_object(door,d2_pos.x,d2_pos.y)

			init_object(evil_door,d3_pos.x,d3_pos.y)

			local hc = get_lvl_coords(24*8,23*8)
			init_object(heart_cont,hc.x,hc.y)

			local twobats = {
				{33,19},
				{28,22},
				{33,27},
				{43,31},
				{44,32},
				{53,33}
			}
			local twocritters = {
				{65,10},
				{52,39},
				{73,10},
				{72,10},
				{70,11}
			}

			for i=1,count(twobats) do
				local b = get_lvl_coords(twobats[i][1]*8, twobats[i][2]*8)
				init_object(bat, b.x, b.y)
			end

			for i=1,count(twocritters) do
				local c = get_lvl_coords(twocritters[i][1]*8,twocritters[i][2]*8)
				init_object(critter, c.x, c.y)
			end

			--init_object(player, 58, 24) -- 56, 10
			local ad = d1_pos
			if (scene.active_door == '_620') ad = d2_pos
			init_object(player,ad.x, ad.y)
			cam.x = ad.x-32
			cam.y = ad.y-32

			pause_player = false
		end
	},

	three = {
		draw = function()
			camera(0,0)

			map(1,12,0,0,128,128)

			-- draw objects
			foreach(objects, function(o)
				draw_object(o)
			end)

			map(1,12,0,0,128,128,2)
		end,
		update = function()

		end,
		init = function()
			scene.name = "hermit gunsmith"
			scene.name_t = t
			objects = {}
			lvl_cam = {x=8,y=96} -- 1*8, 12*8
			local d1_pos = get_lvl_coords(6*8,20*8)
			init_object(door,d1_pos.x,d1_pos.y)

			local snore_pos = get_lvl_coords(10*8,19*8)
			init_object(snore,snore_pos.x,snore_pos.y)

			local cpos = get_lvl_coords(13*8,20*8)
			init_object(chest,cpos.x,cpos.y)

			init_object(player, 5*8, 8*8)
			pause_player = false
		end
	}
}

function draw_circles(size)
	local maxsize = 8
	
	for x=1,(128 / maxsize) do
		--xsize = size * (x+16) / 16 - 16
		xsize = size
		for y=1,(128 / maxsize) do
			ysize = size * (y + 4) / 8 - 4
			circfill(x * maxsize - (maxsize / 2), y *  maxsize - (maxsize / 2), min(xsize, ysize), 0)
		end
	end
end

current_scene = {
	draw = scene.one.draw,
	update = scene.one.update,
	init = scene.one.init
}

function physics_cam()
	local moving = false

	if (btn(0) or btn(1)) then
		moving = true
		cam.dir = btn(1) and 1 or btn(0) and -1
	end

	if (moving and cam.accel < 2) cam.accel += 0.2
	if (not moving and cam.accel > 0.5) cam.accel -= 0.2

	if (cam.y + 94 < char.y) cam.y = char.y - 94
	if (cam.y + 32 > char.y) cam.y = char.y - 32
	if (cam.y + 64 > char.y) cam.y -= 0.5
	if (cam.y + 64 < char.y) cam.y += 0.5

	local offset = 88
	if (cam.dir == 1) offset = 32

	if (char.x > cam.x + offset) cam.x += cam.accel
	if (char.x < cam.x + offset) cam.x -= cam.accel

	if (scene.coords) then
		local xmax = scene.coords[5]*8 - lvl_cam.x + 32
		local ymax = scene.coords[6]*8 - lvl_cam.y + 32
		if (cam.x < scene.coords[3] + 16) cam.x = scene.coords[3] + 16
		if (cam.y < scene.coords[4]) cam.y = scene.coords[4]
		if (cam.x > xmax) cam.x = xmax
		if (cam.y > ymax) cam.y = ymax
	end

	camera(cam.x,cam.y)
end


player={
	init=function(this) 
		this.p_dash=false
		this.jbuffer=0
		this.grace=0
		this.hitbox = {x=2,y=2,w=4,h=6}
		this.health = 3
		this.maxhealth = 3
		this.polar = {
			lvl=1,
			exp=0,
			speed = 4.5,
			needed_exp={10,20,10},
			life = {5,12,18},
			sprs = {
				{24,25},
				{74,77},
				{122,125}
			}
		}
		this.spr_off=0
		this.was_on_ground=false
		this.maxjump = 4
		this.air = 100
		this.hithead = function(_)
			init_object(sparks,_.x,_.y)
			init_object(sparks,_.x-3,_.y)
			sfx(63,3)
		end
	end,
	update=function(this)
		if (pause_player) return
		
		local input = btn(1) and 1 or (btn(0) and -1 or 0)

		local on_ground=this.is_colliding(0,1)
		local in_water=this.in_water(0,0)
		local in_danger=(this.in_danger(0,0) or this.check_damage()) and not this.invincible

		if not in_water then
			air = 100
			message = ''
		else
			air -= 0.2
			message = 'air '..flr(air)

			if (air < 1) then
				this.spr = 34
				this.drowned = true
				kill_player(this, true)
			end
		end

		if (in_danger) then
			this.health -= 1
			this.invincible = 50
			pain_text('-1', this.x, this.y)
			sfx(63)

			if (this.health < 1) kill_player(this)
		end

		if (this.invincible and this.invincible > 0) then
			this.invincible -= 1
		else
			this.invincible = false
		end

		local jump = btnp(4)
		if (jump) then
			this.jbuffer=4
		elseif this.jbuffer>0 then
			this.jbuffer-=1
		end

		if (on_ground and not this.was_on_ground) sfx(62,3)

		if on_ground then
			this.grace=6
		elseif this.grace > 0 then
			this.grace-=1
		end

		-- move
		local maxrun=0.7
		local accel=0.3
		local deccel=0.1
		
		if not on_ground then
			accel=0.2
		end

		if in_water then
			maxrun=0.3
		end
	
		if abs(this.spd.x) > maxrun then
	 		this.spd.x=appr(this.spd.x,sign(this.spd.x)*maxrun,deccel)
		else
			this.spd.x=appr(this.spd.x,input*maxrun,accel)
		end
			
		--facing
		if this.spd.x!=0 then
			this.flip.x=(this.spd.x<0)
		end

		-- gravity
		local maxfall=1
		local gravity=0.08

		if abs(this.spd.y) <= 0.15 then
 			gravity*=0.5
		end
		if in_water then
			gravity*=0.5
		end

		if not on_ground then
			-- variable jump height
			if (btn(4)) then this.spd.y=appr(this.spd.y,maxfall,gravity)
			else this.spd.y=appr(this.spd.y,maxfall,gravity*2) end
		end

		-- jump
		if this.jbuffer>0 and this.grace>0 then
	  		this.jbuffer=0
	  		this.grace=0
	  		if not in_water then
				this.spd.y=-1.5
			else
				this.spd.y=-0.7
			end
		end

		if (in_danger) then
			this.jbuffer=0
			this.grace=0
			this.spd.y=-1.7
		end
		
		-- animation
		this.spr_off+=0.25
		if not on_ground then
			local air_addition = btn(2) and 16 or 0
			if this.is_colliding(input,0) then
				this.spr=5 + air_addition
			else
				this.spr=3 + air_addition
			end
		elseif btn(3) then -- down
			this.spr=36
			local d = this.interact()

			if d then
				d.type.interact(d)
				pause_player = true
			end
		elseif btn(2) then --up
			this.spr=17
		elseif (this.spd.x==0) or (not btn(0) and not btn(1)) then
			this.spr=1
		else
			this.spr=1+this.spr_off%4
		end

		if (btnp(5) and char.weapon) this.type.fire(this)

		if (char.health_increase) then
			this.health += char.health_increase
			this.maxhealth += char.health_increase
			char.health_increase = 0
		end

		if (this.collide(exp_triangle)) then
			weapon.exp += 1
			if (weapon.exp == this.polar.needed_exp[weapon.lvl]
				 and weapon.lvl < count(this.polar.needed_exp)) then
				weapon.lvl += 1
				weapon.exp = 0
			end
		end
		if (this.collide(health_heart)) then
			this.health = min(this.maxhealth, this.health + 2)
		end
		weapon.maxexp = this.polar.needed_exp[weapon.lvl]
		
		-- was on the ground
		this.was_on_ground=on_ground
		char.x = this.x
		char.y = this.y
		char.health = this.health
		char.maxhealth = this.maxhealth
		
	end, --<end update loop

	fire=function(this)
		local up = btn(2) and 1 or 0
		local po = this.polar

		weapon.spr = po.sprs[weapon.lvl][1+up]
		weapon.speed = po.speed
		weapon.life = po.life[weapon.lvl]
		weapon.dir = this.flip.x and -1 or 1
		weapon.dir_y = up
		
		init_object(polar_shot,this.x,this.y)
	end,
	
	draw=function(this)
		if (char.weapon) then
			if (this.spr>16 and this.spr<22) then --up
				spr(23,this.x,this.y-1,1,1,this.flip.x,this.flip.y)
			else
				spr(22,this.x,this.y,1,1,this.flip.x,this.flip.y)
			end
		end
		if (not this.invincible or this.invincible % 3 == 0) then
			spr(this.spr,this.x,this.y,1,1,this.flip.x,this.flip.y)
		end
		if (this.drowned) spr(34,this.x,this.y,1,1,this.flip.x,this.flip.y)
	end
}

function kill_player(this, drowned)
	message = 'you died.'
	music(-1)
	if (drowned) then
		pause_player = true
	else
		create_smoke(this.x,this.y)
		create_smoke(this.x+4,this.y-4)
		create_smoke(this.x-4,this.y-4)
		destroy_object(this)
	end
	sfx(63)
	sfx(60)
	player_death=t
end

function draw_player_ui()
	local start = 4
	local bar_start = 16

	print('/',start+20,start+2,7)
	print('--',start+34,start,7)
	print('--',start+34,start+4,7)

	local exp_width = (weapon.exp / weapon.maxexp) * (25 / weapon.maxexp) * weapon.maxexp
	print('lv '..weapon.lvl, start+1, start+9, 5)
	print('lv '..weapon.lvl, start, start+8, 7)
	rectfill(start+bar_start,start+8,start+41,start+13,5) -- shadow
	rectfill(start+bar_start,start+8,start+40,start+12,7) -- white border
	rectfill(start+bar_start,start+9,start+40,start+11,2) -- dark purple
	rectfill(start+bar_start,start+9,start+bar_start+exp_width,start+11,4) -- brown experience

	local health_width = (char.health / char.maxhealth) * (25 / char.maxhealth) * char.maxhealth
	print(char.health, start+12, start+14, 7)
	rectfill(start+bar_start,start+14,start+41,start+19,5) -- shadow
	rectfill(start+bar_start,start+14,start+40,start+18,7) -- white border
	rectfill(start+bar_start,start+15,start+bar_start + 24,start+17,2) -- dark pink
	rectfill(start+bar_start,start+15,start+bar_start + flr(health_width),start+17,8) -- pink bar
end

function print_text()
	-- this needs to do lots of extra animation things, but it'll do for now
	rectfill(8,88,120,120,6)
	rectfill(9,89,119,119,1)
	print(text_object[1], 12, 94, 7)
	if (text_object[2]) print(text_object[2], 12, 108, 7)
end

polar_shot={
	init=function(this)
		this.speed = weapon.speed
		this.dir = weapon.dir
		this.dir_y = weapon.dir_y
		this.spr = weapon.spr
		this.start_t = t
		this.life = weapon.life
		this.hurt = 1
		this.finisher = {57,58,59}
		this.hitbox = { x=2,y=5,w=6,h=1 }
		sfx(36)
		if (this.dir_y > 0) then
			this.hitbox = { x=5,y=0,w=1,h=6 }
			this.x -= 3
			this.y -= 5
		end
		this.zaps = {
			{
				x=this.x+4*this.dir,
				y=this.y+2,
				step=9
			},
			{
				x=this.x,
				y=this.y,
				step=9
			}
		}
	end,
	update=function(this)
		local st = t - this.start_t

		local collide = this.collide(bat) or this.collide(critter) or this.collide(evil_door)
		if (collide and not this.collide_cool) then
			this.collide_cool = 10
			collide.type.hurt(collide)
			pain_text('-'..this.hurt, this.x, this.y)
		end
		local cc = this.collide_cool
		if (cc and cc > 0) this.collide_cool -= 1
		if (cc and cc < 1) this.collide_cool = nil

		if (st < 8) then
			this.zaps[1].spr = this.finisher[flr(st/1.5)]
			this.zaps[1].step = flr(st/1.5)
		end

		if (not this.done and this.dir_y < 1) this.x += this.dir * this.speed
		if (not this.done and this.dir_y > 0) then
			-- still need to be able to shoot down
			this.y -= this.speed
		end

		if (st > this.life) then
			this.type.destroy_shot(this)
		end
		if (this.is_colliding(0,0)) then
			local destructable = check_destructable(this.x+this.hitbox.x,this.y+this.hitbox.y,this.hitbox.w,this.hitbox.h)
			if count(destructable) > 0 then
				mset(destructable[1].x, destructable[1].y, 0)
				local sc = get_lvl_coords(destructable[1].x*8, destructable[1].y*8)
				create_smoke(sc.x,sc.y)
			end
			this.type.destroy_shot(this)
			this.final_finish = {196,197,198,199}
		end

		if (this.done and not this.end_time) then
			this.end_time = st
			this.zaps[2].x = this.x
			this.zaps[2].y = this.y+2
		end

		if (this.end_time and this.end_time + 8 > st) then
			local et = st - this.end_time
			local finish = this.final_finish or this.finisher
			this.zaps[2].spr = finish[flr(et/1.5)]
			this.zaps[2].step = flr(et/1.5)
		elseif (this.end_time and this.end_time + 8 < st) then
			sfx(37)
			destroy_object(this)
		end
	end,
	destroy_shot=function(this)
		this.done = true
	end,
	draw=function(this)
		if (not this.done) spr(this.spr,this.x,this.y,1,1,this.flip.x,this.flip.y)
		if (this.zaps) then
			local z1 = this.zaps[1]
			local z2 = this.zaps[2]
			if (z1.step < 4) spr(z1.spr,z1.x,z1.y)
			if (z2.step < 4) spr(z2.spr,z2.x,z2.y)
		end
	end
}

sparks={
	init=function(this)
		this.spr=8
		this.spd.y=-0.1+rnd(0.3)
		this.spd.x=0.3+rnd(0.2)
		this.x+=-1+rnd(2)
		this.y+=-1+rnd(2)
		this.solids=false
		this.t = 0
	end,
	update=function(this)
		this.t += 1
		if this.t > 10 then
			destroy_object(this)
		end
	end
}
red_sparks={
	init=function(this)
		this.spr=62
		this.spd.x=-2+rnd(4)
		this.spd.y=-2+rnd(4)
		this.x+=-1+rnd(2)
		this.y+=-1+rnd(2)
		this.solids=false
		this.t = 0
	end,
	update=function(this)
		this.t += 1
		if (this.t > 3) this.spr = 61
		if (this.t > 8) this.spr = 60
		if this.t > 10 then
			destroy_object(this)
		end
	end
}
smoke={
	init=function(this)
		this.spr = 38
		this.anim = {38,39,40,53,54,55,56}
		this.ai = 1
		this.start_t = t
		this.spd.y=-0.1+rnd(0.3)
		this.spd.x=0.3+rnd(0.2)
		this.x+=rnd(1.5)
		this.y+=rnd(1.5)
	end,
	update=function(this)
		local ht = t - this.start_t + 1

		if (ht < 8) then
			this.spr = this.anim[ht]
		else
			destroy_object(this)
		end
	end
}

function create_smoke(ox,oy)
	init_object(smoke,ox,oy)
	init_object(smoke,ox,oy)
	init_object(smoke,ox,oy)
end

function pain_text(message,x,y,color)
	local obj={}
	obj.message = message
	obj.x = x
	obj.y = y
	obj.delay = 10
	obj.start_t = t
	obj.color = color or 8
	obj.spd = {x=0,y=0}
	obj.type = {}

	obj.type.update=function(this)
		if (t - obj.start_t > obj.delay) then
			del(objects, obj)
		end
	end

	obj.move = function() end

	obj.type.draw=function(this)
		print(obj.message,obj.x,obj.y,this.color)
	end

	add(objects,obj)
	return obj
end

water_drops={
	init=function(this)
		this.size = 1
		this.accel = 0
		this.gravity = 1.2
		this.hitbox.w = 2
		this.hitbox.h = 2
		this.x += flr(rnd(6))
	end,
	update=function(this)
		this.y += min(this.gravity, this.accel)
		this.accel += 0.1

		if this.size < 3 and maybe() then
			this.size += 1
		end
		if this.size > 0 and maybe() then
			this.size -= 1
		end

		if this.is_colliding(0,0) or this.in_water(0,0) then
			destroy_object(this)
		end
	end,
	draw=function(this)
		pset(this.x,this.y,1)
		if (this.size > 1) then
			pset(this.x,this.y,12)
		end
		if this.size > 2 then
			pset(this.x,this.y,7)
		end
	end
}

bat={
	tile = 47,
	init=function(this)
		this.start_t = t
		this.start_y = this.y
		this.range = 4*8
		this.dir_y = 1
		this.accel = 0.2
		this.rndspeed = rnd()*0.15
		this.damage = 1
	end,
	hurt=function(this)
		create_smoke(this.x,this.y)
		destroy_object(this)
		local drop = exp_triangle
		if (rnd(1) < 0.15) drop = health_heart
		init_object(drop,this.x,this.y)
		-- todo: show how much it hurt (same with all hurts)
	end,
	update=function(this)
		--animation
		local ht = t - this.start_t
		if ht % 4 > 2 then
			this.spr = 47
		else
			this.spr = 63
		end

		-- acceleration control
		if (this.dir_y < 0 and this.y - 12 < this.start_y and this.accel > .2) this.accel -= .04
		if (this.dir_y > 0 and this.y - 12 < this.start_y and this.accel < 1) this.accel += .04
		if (this.dir_y > 0 and this.y + 12 > this.start_y + this.range and this.accel > .2) this.accel -= .04
		if (this.dir_y < 0 and this.y + 12 > this.start_y + this.range and this.accel < 1) this.accel += .04
		
		-- direction control
		if (this.y > this.start_y + this.range) this.dir_y = -1
		if (this.y < this.start_y) this.dir_y = 1

		this.y += this.dir_y * this.accel + this.rndspeed
	end
}

critter={
	tile = 50,
	init=function(this)
		this.start_t = t
		this.damage = 1
		this.jbuffer=0
		this.grace=0
		this.health = 2
		this.maxjump = 4
	end,
	hurt=function(this)
		if (not this.invincible and this.health > 1) then
			this.invincible = 0
			sfx(39)
			init_object(red_sparks,this.x,this.y)
			init_object(red_sparks,this.x,this.y)
			init_object(red_sparks,this.x,this.y)
			this.health -= 1
		elseif (this.health == 1) then
			create_smoke(this.x, this.y)
			destroy_object(this)
			local drop = exp_triangle
			if (rnd(1) < 0.15) drop = health_heart
			init_object(drop,this.x,this.y)
		end
	end,
	update=function(this)
		local on_ground=this.is_colliding(0,1)

		if (this.invincible and this.invincible < 10) this.invincible += 1
		if (this.invincible and this.invincible > 9) this.invincible = nil

		this.spr = 50
		if char.x > this.x - 56 and char.x < this.x + 56 then
			this.spr = 51
			if (not on_ground and this.spd.y < 0) this.spr = 52
			if (not on_ground and this.spd.y > 0) this.spr = 50
		end

		if on_ground 
			and char.x > this.x - 28 
			and char.x < this.x + 28 
			and char.y < this.y + 28
			and char.y > this.y - 28 then
			this.spd.y=-1.4
			this.spd.x=-0.2*(this.flip.x and -1 or 1)
			this.spr = 50
			sfx(61)
		end

		this.flip.x = (char.x > this.x)

		local maxrun=0.7
		local accel=0
		local deccel=0.1
		
		if not on_ground then
			accel=0.17
		end
			
		--facing
		if this.spd.x!=0 then
			this.flip.x=(this.spd.x>0)
		end

		-- gravity
		local maxfall=0.8
		local gravity=0.05

		if abs(this.spd.y) <= 0.15 then
 			gravity*=0.3
		end

		this.spd.y=appr(this.spd.y,maxfall,gravity*2)
	end
}

evil_door={
	init=function(this)
		this.frames = {
			{7,16},
			{225,6},
			{226,6},
			{227,243}
		}
		this.hitbox = { h=16, w=8, x=0, y=-8 }
		this.frame = 1
		this.damage = 1
		this.health = 5
		this.maxjump = 4
		this.start_x = this.x
	end,
	hurt=function(this)
		if (not this.invincible and this.health > 1) then
			this.invincible = 0
			sfx(38)
			init_object(red_sparks,this.x,this.y)
			init_object(red_sparks,this.x,this.y)
			init_object(red_sparks,this.x,this.y)
			this.health -= 1
		elseif (this.health == 1) then
			create_smoke(this.x, this.y)
			destroy_object(this)
			init_object(exp_triangle,this.x,this.y)
			init_object(exp_triangle,this.x,this.y)
		end
	end,
	update=function(this)
		local on_ground=this.is_colliding(0,1)
		this.frame = 1

		if char.x > this.x - 56 then
			this.frame = 2
		end

		local it = this.invincible
		if (it and it < 10) then
			this.frame = 4
			this.invincible += 1
		end
		if (it and it == 4 or it == 7) then
			this.frame = 3
			this.x -= 1
		else
			this.x = this.start_x
		end
		if (it and it > 9) this.invincible = nil
	end,
	draw=function(this)
		spr(this.frames[this.frame][1],this.x,this.y-8,1,1)
		spr(this.frames[this.frame][2],this.x,this.y,1,1)
	end
}

door={
	doors = {
		_73 = 'two',
		_5610 = 'one',
		_7235 = 'three',
		_620 = 'two'
	},
	id=function(this)
		local co = get_global_coords(this.x,this.y)
		return '_'.. co.x/8 .. co.y/8
	end,
	init=function(this)
		this.interactable=true
		this.solids=false

		if (door.id(this) == '_7235') then
			this.tiles = {194,210}
		else
			this.tiles = {7,16}
		end
	end,
	interact=function(this)
		this.start_t = t
		if (door.id(this) != '_7235') this.tiles={9,37}
		scene.active_door = door.id(this)
	end,
	update=function(this)
		if (this.start_t) then
			local dt = t - this.start_t

			-- fade out
			crossfade.size = flr(dt / 2)
			if (crossfade.size > crossfade.max) then
				crossfade.max_t = t
				-- go to next level
				local lvl_name = this.type.doors[door.id(this)]
				current_scene.draw = scene[lvl_name].draw
				current_scene.update = scene[lvl_name].update
				current_scene.init = scene[lvl_name].init
				this.start_t = nil
			end
		end
	end,
	draw=function(this)
		rectfill(this.x,this.y-8,this.x+7,this.y+7,0)
		spr(this.tiles[1],this.x,this.y-8,1,1)
		spr(this.tiles[2],this.x,this.y,1,1)
	end
}

heart_cont={
	tile = 13,
	init=function(this)
		this.interactable=true
		this.solids=false
		this.start_t=t
	end,
	interact=function(this)
		this.step = 1
		char.health_increase = 3
	end,
	update=function(this)
		local ht = t - this.start_t
		if ht % 6 > 3 then
			this.spr = 13
		else
			this.spr = 14
		end

		if (this.step) then
			if (this.step == 1) text_object = {'obtained a life capsule'}
			if (this.step == 2) text_object = {'max health increased by 3'}
			this.spr = 0
			if (btnp(4) or btnp(5) and this.step < 3) then
				this.step+=1
			elseif this.step > 2 then
				pause_player = false
				text_object = {}
				destroy_object(this)
			end
		end
	end
}

chest={
	tile = 48,
	init=function(this)
		this.interactable=true
		this.solids=false
		this.start_t=t
		this.animating = -1
		this.empty = false
	end,
	interact=function(this)
		--get the polar star!
		this.empty = true
		this.step = 1
	end,
	update=function(this)
		local ht = t - this.start_t
		if (not this.empty) then
			this.spr = 48

			if (this.animating < 0 and rnd(1) < 0.03) then
				this.animating = ht
			elseif this.animating > 0 then
				this.spr = 33
				if (ht > this.animating + 6) this.spr = 49
				if (ht > this.animating + 16) then
					this.animating = -1
					this.spr = 49
				end
			end
		else
			this.spr = 32

			if (this.step == 1) text_object = {'opened the chest'}
			if (this.step == 2) text_object = {'obtained the polar star.'}
			if (this.step == 3) then
				text_object = {}
				pause_player = false
				char.weapon = 'star'
			end
			if (btnp(4) or btnp(5) and this.step < 4) then
				this.step+=1
			end
		end
	end
}

save_disk={
	animation = {26,27,28,29,30,29,28,27,26},
	init=function(this)
		this.interactable=true
		this.solids=false
		this.start_t = t
		this.frame = 1
		this.step = 0
	end,
	interact=function(this)
		this.step = 1
	end,
	update=function(this)
		local t1 = t - this.start_t
		local delay = 2

		if t1 / delay < count(this.type.animation) - 1 then
			this.frame = flr(t1 / delay) + 1
		else
			this.start_t = t
		end

		if (this.step == 1) text_object = {'game saved'}
		if (this.step == 1 and btnp(4) or btnp(5)) then
			text_object = {}
			this.step+=1
			pause_player = false
		end
	end,
	draw=function(this)
		spr(this.type.animation[this.frame],this.x,this.y,1,1)
	end
}

health_station={
	animation = {10,11,11,12,11,12,11,10},
	init=function(this)
		this.interactable=true
		this.solids=false
		this.start_t = t
		this.frame = 1
		this.step = 0
	end,
	interact=function(this)
		this.step = 1
	end,
	update=function(this)
		if (this.a_time) then
			local t1 = t - this.start_t
			local delay = 3

			if t1 / delay < count(this.type.animation) then
				this.frame = flr(t1 / delay) + 1
				printh(this.frame)
			else
				this.start_t = t
				this.a_time = false
			end
		else
			if (rnd(15) < 1) then
				this.a_time = true
			end
		end

		if (this.step == 1) text_object = {'health refilled'}
		if (this.step == 1 and btnp(4) or btnp(5)) then
			text_object = {}
			this.step+=1
			pause_player = false
		end
	end,
	draw=function(this)
		spr(this.type.animation[this.frame],this.x,this.y,1,1)
	end
}

exp_triangle={
	tile=46,
	init=function(this)
		this.animation={43,44,45}
		this.start_t = t
		this.at = t
		this.spd.y=-0.1+rnd(0.2)
		this.spd.x=-0.3+rnd(0.6)
		this.hitbox = { h=4, w=4, x=2, y=3 }
	end,
	update=function(this)
		local t1 = t - this.start_t
		local ta = t - this.at

		local delay = 2

		if ta / delay < count(this.animation) - 1 then
			this.spr = this.animation[flr(ta / delay) + 1]
		else
			this.at = t
		end

		local maxfall=0.8
		local gravity=0.05

		if abs(this.spd.y) <= 0.15 then
			gravity*=0.3
		end

		this.spd.y=appr(this.spd.y,maxfall,gravity*2)
		if (this.is_colliding(0,1)) then
			this.spd.y -= 0.5
			sfx(35)
		end

		if (t1 > 116) this.spr = this.type.tile
		if (t1 > 120 or this.collide(player)) destroy_object(this)
	end
} 
health_heart={
	tile=15,
	init=function(this)
		this.animation={15,31,15,31}
		this.start_t = t
		this.at = t
	end,
	update=function(this)
		local t1 = t - this.start_t
		local ta = t - this.at

		local delay = 1
		if (t1 > 124) delay = 2

		if ta / delay < count(this.animation) - 1 then
			this.spr = this.animation[flr(ta / delay) + 1]
		else
			this.at = t
		end

		if (t1 > 147) this.spr = 38
		if (t1 > 150 or this.collide(player)) destroy_object(this)
	end
}

snore={
	tile=200,
	init=function(this)
		this.animation={200,201,202}
		this.start_t = t
	end,
	update=function(this)
		local t1 = t - this.start_t

		local delay = 5
		local loop = 10

		if t1 / delay < count(this.animation) then
			this.spr = this.animation[flr(t1 / delay) + 1]
		elseif t1 / delay < count(this.animation) + loop then
			this.spr = 0
		else
			this.start_t = t
		end
	end
}


function init_object(type,x,y)
	local obj = {}
	obj.type = type
	obj.collideable=true
	obj.solids=true

	obj.spr = type.tile
	obj.flip = {x=false,y=false}

	obj.x = x
	obj.y = y
	obj.hitbox = { x=0,y=0,w=8,h=8 }
	obj.health = 1

	obj.spd = {x=0,y=0}
	obj.rem = {x=0,y=0}

	obj.is_colliding=function(ox,oy)
		local c = check_collision(
			obj.x+obj.hitbox.x+ox,
			obj.y+obj.hitbox.y+oy,
			obj.hitbox.w,
			obj.hitbox.h
		)
		if (not c or count(c) > 0) return false
		return true
	end

	obj.check_collision=function(ox,oy)
		return check_collision(
			obj.x+obj.hitbox.x+ox,
			obj.y+obj.hitbox.y+oy,
			obj.hitbox.w,
			obj.hitbox.h
		)
	end

	obj.in_water=function(ox,oy)
		return check_water(obj.x+obj.hitbox.x+ox,obj.y+obj.hitbox.y+oy,obj.hitbox.w,obj.hitbox.h)
	end

	obj.in_danger=function(ox,oy)
		local map_danger = check_danger(obj.x+obj.hitbox.x+ox,obj.y+obj.hitbox.y+oy,obj.hitbox.w,obj.hitbox.h)
		--local enemy_danger = obj.
		return map_danger
	end
	
	obj.collide=function(type,ox,oy)
		local other
		if ox==nil then ox=0 oy=0 end
		for i=1,count(objects) do
			other=objects[i]
			if other ~=nil and other.type.init == type.init and other != obj and other.collideable and obj.check_coords(other,ox,oy) then
				return other
			end
		end
		return nil
	end

	obj.interact=function(ox,oy)
		local other
		if ox==nil then ox=0 oy=0 end
		for i=1,count(objects) do
			other=objects[i]
			if other ~=nil and other != obj and other.interactable and obj.check_coords(other,ox,oy) then
				return other
			end
		end
		return nil
	end
	
	obj.check_damage=function(ox,oy)
		local other
		if ox==nil then ox=0 oy=0 end
		for i=1,count(objects) do
			other=objects[i]
			if other ~=nil and other != obj and other.damage and obj.check_coords(other,ox,oy) then
				return other.damage
			end
		end
		return nil
	end

	obj.check_coords=function(other,ox,oy)
		return other.x+other.hitbox.x+other.hitbox.w > obj.x+obj.hitbox.x+ox and 
				other.y+other.hitbox.y+other.hitbox.h > obj.y+obj.hitbox.y+oy and
				other.x+other.hitbox.x < obj.x+obj.hitbox.x+obj.hitbox.w+ox and 
				other.y+other.hitbox.y < obj.y+obj.hitbox.y+obj.hitbox.h+oy
	end
	
	obj.move=function(ox,oy,rep)
		local amount
		-- [x] get move amount
 		obj.rem.x += ox
		amount = flr(obj.rem.x + 0.5)
		obj.rem.x -= amount
		local movedx = obj.move_x(amount,0)
		
		-- [y] get move amount
		obj.rem.y += oy
		amount = flr(obj.rem.y + 0.5)
		obj.rem.y -= amount
		local movedy = obj.move_y(amount)
	end
	
	obj.move_x=function(amount,start)
		if obj.solids then
			local step = sign(amount)
			for i=start,abs(amount) do
				local col = obj.check_collision(step,0)
				if not col then
					obj.x += step
				elseif col.problem then
					local problem = col.points[col.problem]
					local solution = col.points[col.problem-step]

					if (solution) then
						-- checking for walls
						local col = obj.is_colliding(step,-4)
						if (not col) then
							obj.x += step
							obj.y += problem - solution
						end
					else
						local stepy = -3
						local col = obj.is_colliding(step,stepy)
						if (not col) then
							obj.x += step
							obj.y += stepy
						end
					end
				else
					obj.spd.x = 0
					obj.rem.x = 0
					return false
				end
			end
			if (step != 0) return true
			return false
		else
			obj.x += amount
			return true
		end
	end
	
	obj.move_y=function(amount)
		if obj.solids then
			local step = sign(amount)
			for i=0,abs(amount) do
				local col = obj.check_collision(0,step)
	 			if not col or count(col) < 0 then
					obj.y += step
				else
					if (obj.hithead and obj.spd.y < 0) obj.hithead(obj)
					obj.spd.y = 0
					obj.rem.y = 0
					return false
				end
			end
			if (step != 0) return true
			return false
		else
			obj.y += amount
			return true
		end
	end

	add(objects,obj)
	if obj.type.init~=nil then
		obj.type.init(obj)
	end
	return obj
end

function draw_object(obj)
	if obj.type.draw ~=nil then
		obj.type.draw(obj)
	elseif obj.spr > 0 then
		spr(obj.spr,obj.x,obj.y,1,1,obj.flip.x,obj.flip.y)
	end
end

function destroy_object(obj)
	del(objects,obj)
end

function _init()
	if (music_on) music(2)
end

function _update()
	t += 1
	if current_scene.init then
		current_scene.init()
		current_scene.init=nil
	end

	foreach(objects,function(obj)
		obj.move(obj.spd.x,obj.spd.y)
		if obj.type.update~=nil then
			obj.type.update(obj)
		end
	end)

	current_scene.update()
	scene.update()

	if player_death and t - player_death > 10 then
		if (music_on) music(16,1+2)
		player_death = nil
	end
end

function _draw()
	-- draw dark background
	camera()
	rectfill(0,0,128,128,0)

	current_scene.draw()

	camera()

	draw_player_ui()

	if (count(text_object) > 0) then
		print_text()
	end

	if (crossfade.size) then
		draw_circles(crossfade.size)
	end

	if (message) then
		local center = 64 - #message * 2
		print(message, center, 60, 7)
	end
end


-- helper functions --

function appr(val,target,amount)
 return val > target 
 	and max(val - amount, target) 
 	or min(val + amount, target)
end

function sign(v)
	return v>0 and 1 or v<0 and -1 or 0
end

function clamp(n, min, max)
	if n < min then return min end
	if n > max then return max end
	return n
end

function check_water(x,y,w,h)
	local t = check_tile_flag(x+lvl_cam.x,y+lvl_cam.y,w,h,4)
	if (count(t) > 0) return true
	return false
end

function check_danger(x,y,w,h)
	local t = check_tile_flag(x+lvl_cam.x,y+lvl_cam.y,w,h,7)
	if (count(t) > 0) return true
	return false
end

function check_destructable(x,y,w,h)
	local t = check_tile_flag(x+lvl_cam.x,y+lvl_cam.y,w,h,6)
	return t
end

function check_collision(x,y,w,h)
	x = x + lvl_cam.x
	y = y + lvl_cam.y
	local col_tiles = check_tile_flag(x,y,w,h,0)

	local angle
	if count(col_tiles) > 0 then
		-- checking if custom collision exists for this tile
		angle = check_for_angle(col_tiles)
	end
	if col_tiles and angle then
		-- coordinates are all screwwy
		local px = col_tiles[1].x*8
		local py = col_tiles[1].y*8
		local c = false
		c = c or check_point({x=x+w,y=y}, collision_types[angle], px, py)
		c = c or check_point({x=x,y=y}, collision_types[angle], px, py)
		c = c or check_point({x=x,y=y+h}, collision_types[angle], px, py)
		c = c or check_point({x=x+w,y=y+h}, collision_types[angle], px, py)
		return c
	end
	return col_tiles[1]
end

function check_point(s,points,px,py,edge)
	local collision = false
	for i=1,count(points) do
		local px1 = px + i
		local py1 = py + points[i]

		if px1 == s.x and py1 < s.y then
			collision = {points=points,problem=i}
		end
	end

	return collision
end

function get_lvl_coords(ox, oy)
	if (scene.coords) then
		local new_co = {x=0, y=0}
		new_co.x = ox - lvl_cam.x
		new_co.y = oy - lvl_cam.y
		return new_co
	end
	return {x=ox,y=oy}
end

function get_global_coords(ox, oy)
	if (scene.coords) then
		local new_co = {x=0, y=0}
		new_co.x = ox + lvl_cam.x
		new_co.y = oy + lvl_cam.y
		return new_co
	end
	return {x=ox, y=oy}
end

function check_for_angle(tiles)
	for i=1,count(tiles) do
		if angle_tiles['_'..tiles[i].tile_id] then
			return angle_tiles['_'..tiles[i].tile_id]
		end
	end
	return false
end

function check_tile_flag(x,y,w,h,flag)
	-- checking each point in the next tile length
	local tiles = {}
	for i=max(0,flr(x/8)), (x+w-1) / 8 do
		for j=max(0,flr(y/8)), (y+h-1) / 8 do
			local tile_id = tile_at(i,j)
			if fget(tile_id,flag) then
				add(tiles, {x=i, y=j, tile_id=tile_id})
			end
		end
	end
	return tiles or false
end

function tile_at(x,y)
  return mget(x, y)
end

function maybe()
	return rnd(1)<0.5
end

	
function copy(o)
  local c
  if type(o) == 'table' then
    c = {}
    for k, v in pairs(o) do
      c[k] = copy(v)
    end
  else
    c = o
  end
  return c
end
