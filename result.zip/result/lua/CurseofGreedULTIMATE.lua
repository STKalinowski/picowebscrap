--curse of greed ultimate
--sophie houlden

labelmaking = false
pindex=-1

menu1 = {"play zone 1","play zone 2","play ultimate", "options"}
menu2 = {"camera: dynamic","difficulty: normal","back"}
menu=menu1
mindex=1
sharpcam=false
difficulty=1
easymode=false
hardmode=false
function changecam()
 sharpcam = not sharpcam
 menu2[1] = "camera: dynamic"
 if (sharpcam) menu2[1] = "camera: sharp"
end
function changedifficulty(d)
 difficulty+=d
 if (difficulty<0) difficulty=2
 if (difficulty>2) difficulty=0
 easymode=false
 hardmode=false
 if difficulty==0 then
  easymode=true
  menu2[2] = "difficulty: easy"
 
 elseif difficulty==1 then
  menu2[2] = "difficulty: normal"
 
 else
  hardmode=true
  menu2[2] = "difficulty: impossible"
 
 end
end

gametype=1

pidle={1}
prun={2,4,5,6}
prise={6}
pfall={2}
ppush={3}
pwallslide={7}
pdead={8}
pwon={9}

invisanim={0}

flagdown={38}
flagwave={39,40,41,42,43,44}

coinspin={17,18,19,20,21}
heartanim={33}

dbidle={10}
dbattack={13,12,11}

trampanim={14}
trampbounce={15,15,30,31,14,14,14}

spikeanim={32}
wallspikeanim={23,24,24,24,24,24,25,26,26,26,26,26}

laseremitteranim={51,34,34,34,34,34,34,34,34,34,48,49,50,48,49,50,48,49,50,51,52,53,52,53,52,53,52,53,50}
laseremitteranimb={57,35,35,35,35,35,35,35,35,35,54,55,56,54,55,56,54,55,56,57,58,59,58,59,58,59,58,59,58}

camx=0
camy=0
camoff=-20

hp=100
oldhp=100
maxhp=100
score=00
lives=3
won=false
playtime=0

zone2x=0
zone2y=0

checkx=0
checky=0

screen="title"
screeninputwait=0

hpshaketime=0

loselifetime=0
secondcounter=0


fade={
 0b1111111111111111.1,
 0b0111111111111111.1,
 0b0111111111011111.1,
 0b0101111111011111.1,
 0b0101111101011111.1,
 0b0101101101011111.1,
 0b0101101101011110.1,
 0b0101101001011110.1,
 0b0101101001011010.1,
 0b0001101001011010.1,
 0b0001101001001010.1,
 0b0000101001001010.1,
 0b0000101000001010.1,
 0b0000001000001010.1,
	0b0000001000001000.1,
	0b0000001000000000.1,
	0b0000000000000000.1,
	0b0000000000000000.1}

lasersmade=false
function _init()
 fadeindex=1
 
 screen="title"
 screeninputwait=0
 
 spawnactors()
 initactors(true)
 lasersmade=true
end

dead=false
deadtime=0
function dienow()
 if (dead) return
 dead=true
 deadtime=1
 fadeindex=1
end


function newgame()
 screen="game"
 camx=0
 fadeindex=#fade
 
 maxhp=100
 hp=maxhp
 oldhp=hp
 score=0
 lives=3
 if (easymode) lives = 99
 if (hardmode) lives = 0
 won=false
 playtime=0
 
 dead=false
 
 initactors(true)
 
 if gametype==3 then
  msetall(62,63)
 else
  msetall(63,62)
 end
 
end

function msetall(a,b)
for x=0,128 do
 for y=0,64 do
 
  if mget(x,y)==a then
   mset(x,y,b)
  end
 end
 end
end

function respawnplayer()
 screen="game"
 camx=0
 fadeindex=#fade
 
 hp=maxhp
 
 dead=false
 
 initactors(false)
end
-->8

actors1={}
actors2={}
actors3={}
actors4={}
colliders1={}
colliders2={}
colliders3={}
colliders4={}
function addactor(typ,x,y,dif)
 a={}
 a.startx=x*8
 a.starty=y*8
 a.typ=typ
 a.dif=dif
 add(actors,a)
 mset(x,y,0)
 return a
end

function spawnactors()

 for x=0,128 do
 for y=0,64 do
  checkspawn(x,y,"",0)
 end
 end
 
end
 
function checkspawn(x,y,typ,dif)
 t=mget(x,y)
 if (t==0) return
 
 if t==1 then
  typ="player"
 end
 
 if t==2 then
  zone2x=x*8
  zone2y=y*8
  mset(x,y,0)
 end
 
 if t==17 then
  typ="coin"
 end
 if t==21 then
  typ="coin" dif=2
 end
 
 if t==33 then
  typ="heart"
 end
 
 if t==10 then
  typ="deathball"
 end
 if t==11 then
  typ="deathball" dif=2
 end
 
 if t==14 then
  typ="trampoline"
 end
 
 if t==22 then
  typ="finish"
 end
 
 if t==38 then
  typ="checkpoint" dif=0
 end
 
 if t==39 then
  typ="checkpoint" dif=-1
 end
 
 if t==16 then
  typ="topspike"
 end
 if t==32 then
  typ="spike"
 end
 
 if t==23 then
  typ="wallspike"
 end
 if t==24 then
  typ="wallspike2"
 end
 if t==25 then
  typ="wallspike" dif=2
 end
 if t==26 then
  typ="wallspike2" dif=2
 end
 
 if t==34 then
  typ="emit➡️"
 end
 if t==35 then
  typ="emit⬆️"
 end
 if t==37 then
  typ="emit⬅️"
 end
 if t==36 then
  typ="emit⬇️"
 end
 
 if t==54 then
  typ="emit⬆️" dif=2
 end
 if t==55 then
  typ="emit⬇️" dif=2
 end
 
 if typ!="" then
  a=addactor(typ, x,y ,dif)
  if (t==1) playeractor=a
  
  if a.starty<128 then
   add(actors1,a)
  elseif a.starty<256 then
   add(actors2,a)
  elseif a.starty<384 then
   add(actors3,a)
  else
   add(actors4,a)
  end
  
  cancollide=true
  if (a.typ=="player") cancollide=false
  if (a.typ=="emit⬅️") cancollide=false
  if (a.typ=="emit➡️") cancollide=false
  if (a.typ=="emit⬆️") cancollide=false
  if (a.typ=="emit⬇️") cancollide=false
  
  if cancollide then
   if a.starty<128 then
    add(colliders1,#actors1)
   elseif a.starty<256 then
    add(colliders2,#actors2)
   elseif a.starty<384 then
    add(colliders3,#actors3)
   else
    add(colliders4,#actors4)
   end
  end
  
  
  
 end
 
end

function initactors(isnewgame)
 for i=1,#actors1 do
  initactor(actors1[i],isnewgame)
 end
 for i=1,#actors2 do
  initactor(actors2[i],isnewgame)
 end
 for i=1,#actors3 do
  initactor(actors3[i],isnewgame)
 end
 for i=1,#actors4 do
  initactor(actors4[i],isnewgame)
 end
 initactor(playeractor,isnewgame)
 lasersmade=true
 
 
end

function initactor(a,isnewgame)
  
  a.x=a.startx
  a.y=a.starty
  a.frame=1
  
  wasactive=a.active
  
  a.active=true
  
  a.fx=0
  a.fy=0
  a.grounded=false
  a.hflip=false
  a.vflip=false
  a.otyp=1
  
  if a.typ=="player" then
   a=playeractor
   a.anim=pidle
   a.pushing=false
   a.invul=1
   a.wallframes=0
   a.walldir=0
   
   if isnewgame and gametype==2 then
    a.x=zone2x
    a.y=zone2y
   end
   
   if isnewgame then
    checkx=a.x
  	 checky=a.y
  	else
  	 a.x=checkx+4
  	 a.y=checky
   end
  end
  
  if a.typ=="checkpoint" then
   a.anim=flagdown
   if (hardmode) a.active=false
  end
  
  if a.typ=="trampoline" then
   a.anim=trampanim
   a.bounce=0
  end
  
  if a.typ=="deathball" then
   a.anim=dbidle
   a.mode="patrol"
   a.movedir=1
   a.speed = 0.2
   if not lasersmade then
    cachedb(a)
   end
  end
  
  if a.typ=="finish" then
   a.anim=invisanim
   a.finish=true
   
   if a.y<=256 and gametype>2 then
    a.finish=false
   end
   
  end
  
  if a.typ=="coin" then
   a.anim=coinspin
   a.frame=a.x*2+a.y
   a.otyp=0
   
   if not isnewgame and easymode then
    a.active=wasactive
   end
  end
  if a.typ=="heart" then
   a.anim=heartanim
   
  end
  
  
  if a.typ=="spike" then
   a.anim=spikeanim
   a.otyp=0
   a.hflip=rnd()*2>0.9
  end
  if a.typ=="topspike" then
   a.anim=spikeanim
   a.otyp=0
   a.vflip=true
   a.hflip=rnd()*2>0.9
  end
  if a.typ=="wallspike" then
   a.anim=wallspikeanim
   a.otyp=0
  end
  if a.typ=="wallspike2" then
   a.anim=wallspikeanim
   a.otyp=0
   a.hflip=true
  end
 
  if a.typ=="emit➡️" then
   a.anim=laseremitteranim
   a.otyp=0
   if not lasersmade then
    a.laser=addlaser(a.x+5,a.y+4,"➡️")
   else
    lasers[a.laser].active=false
   end
  end
  if a.typ=="emit⬆️" then
   a.anim=laseremitteranimb
   a.otyp=0
   if not lasersmade then
    a.laser=addlaser(a.x+3,a.y+3,"⬆️")
   else
    lasers[a.laser].active=false
   end
  end
  if a.typ=="emit⬅️" then
   a.hflip=true
   a.otyp=0
   a.anim=laseremitteranim
   if not lasersmade then
    a.laser=addlaser(a.x+3,a.y+4,"⬅️")
   else
    lasers[a.laser].active=false
   end
  end
  if a.typ=="emit⬇️" then
   a.anim=laseremitteranimb
   a.vflip=true
   a.hflip=true
   a.otyp=0
   if not lasersmade then
    a.laser=addlaser(a.x+3,a.y+5,"⬇️")
   else
    lasers[a.laser].active=false
   end
  end
  
  if a.dif>difficulty then
   a.active=false
  end
  if a.dif<0 and difficulty>0 then
   a.active=false
  end

 
 
end

lasers={}
function addlaser(x,y,laserdir)
 l={}
 l.startx=x
 l.starty=y
 l.laserdir=laserdir
 l.active=false
 l.col=11
 
 --find laser end
 l.endx=x
 l.endy=y
 xchange=0
 ychange=0
 if (laserdir=="➡️") xchange=1
 if (laserdir=="⬅️") xchange=-1
 if (laserdir=="⬇️") ychange=1
 if (laserdir=="⬆️") ychange=-1
 while not fget(mget(flr8(l.endx),flr8(l.endy)),0) and
  l.endx>0 and l.endx<1024 and
  l.endy>0 and l.endy<512 do
   l.endx+=xchange
   l.endy+=ychange
 end
 l.endx-=xchange
 l.endy-=ychange
 
 
 if (l.startx>l.endx) l.startx,l.endx=l.endx,l.startx
 if (l.starty>l.endy) l.starty,l.endy=l.endy,l.starty
 
 add(lasers,l)
 return #lasers
end

function cachedb(a)
 --store max positions for deathball
 a.minx=a.startx
 a.maxx=a.startx
 a.x=a.startx
 while not overlapssolid(a.x,a.y,7,7) do
  a.minx=a.x
  a.x-=1
 end
 a.x=a.startx
 while not overlapssolid(a.x,a.y,7,7) do
  a.maxx=a.x
  a.x+=1
 end
 a.x=a.startx
 
end


-->8
--updates
delta30=1/30
tdelta = 1/60
gtime = 0
function _update60()

 gtime+=tdelta
 
 if screeninputwait<1 then
  screeninputwait+=tdelta
 end
 
 if screen!="game" then
 
  if screen=="title" then
   if btnp(⬆️) then
    sfx(10)
    mindex-=1
   end
   if btnp(⬇️) then
    sfx(10)
    mindex+=1
   end
   if btnp(⬅️) or btnp(➡️) then
    sfx(12)
   end
   if (mindex<1)mindex=#menu
   if (mindex>#menu)mindex=1
  end
  
  if (btnp(⬅️) or btnp(➡️)) and screeninputwait>0.3 then
    if screen=="title" then
     if menu==menu2 then
      if mindex==1 then
       changecam()
      elseif mindex==2 then
       if (btnp(⬅️))changedifficulty(-1)
       if (btnp(➡️))changedifficulty(1)
      end
     end
    end
  end
  
  if (btnp(🅾️) or btnp(❎)) and screeninputwait>0.3 then
   gametype=mindex
   
   if screen=="title" then
    screeninputwait=0
    firstmenu=false
    sfx(11)
    if menu==menu1 then
     if mindex<4 then
      newgame()
      
      return
     else
      menu=menu2
      mindex=3
     end
    else
     if mindex==1 then
      changecam()
     elseif mindex==2 then
      changedifficulty(1)
     elseif mindex==3 then
      menu=menu1
      mindex=4
     end
    end
   end
   if screen=="gameover" then
    
    
    newgame()
    fadeindex=1
    screeninputwait=0
    screen="title"
   end
  end
  return
 end
 
 if screen=="game" then
  secondcounter+=tdelta
  if secondcounter>1 then
   playtime+=1
   secondcounter-=1
  end
 end
 
 if (score>10000) score=10000
 scorehp=100-(score*0.01)
 if (maxhp>scorehp) maxhp=flr(scorehp)
 if (hp>maxhp) hp=maxhp
 if (hp<0) hp=0
 
 if (oldhp>hp) oldhp-=tdelta*10
 if (oldhp<hp) oldhp=hp
 
 
 if dead then
  deadtime-=tdelta
  if deadtime<=0 then
   fadeindex+=30*tdelta
   if fadeindex>#fade then
    fadeindex=#fade
    
    if screen=="game" then
     if won or lives==0 or score==10000 then
      screen="gameover"
      screeninputwait=0
      if (won) then
       sfx(9)
      else
       sfx(7)
      end
     else
      lives-=1
      screen="loselife"
      loselifetime=0
      sfx(7)
     end
    end
    
   end
  end
  return
 end
 

 playerupdate(playeractor)
 
 sintime=sin(gtime)
 costime=cos(gtime)
 

 for i=1,#actors1 do
  actoraction(actors1[i],playeractor)
 end
 for i=1,#actors2 do
  actoraction(actors2[i],playeractor)
 end
 for i=1,#actors3 do
  actoraction(actors3[i],playeractor)
 end
 for i=1,#actors4 do
  actoraction(actors4[i],playeractor)
 end
 
 
end

function actoraction(a,p)
  if (a.y<camy) return
 if (a.y>camy+128) return
 if (not a.active) return


 if a.typ=="heart" then
  a.x=a.startx+sintime*2
  a.y=a.starty+costime*3
 end

 if a.typ=="emit➡️" or 
    a.typ=="emit⬅️" or
    a.typ=="emit⬆️" or
    a.typ=="emit⬇️" then
  l = lasers[a.laser]
  lasers[a.laser].active=false
  if a.anim[a.frame]==53 or
     a.anim[a.frame]==58 then
   lasers[a.laser].active=true
   lasers[a.laser].col=11
  end
  if a.anim[a.frame]==52 or
     a.anim[a.frame]==59 then
   lasers[a.laser].active=true
   lasers[a.laser].col=7
  end
 end

 if a.typ=="checkpoint" or a.typ=="easycheckpoint" then
  if a.x==checkx and a.y==checky then
   a.anim=flagwave
  else
   a.anim=flagdown
  end
 end
 
 if a.typ=="trampoline" then
  if a.anim==trampbounce then
   if a.frame>5 then
    a.anim=trampanim
   end
  end
  
 end
 
 if a.typ=="deathball" then
  
 
  a.x+=a.movedir*a.speed
  a.hflip=false
  if (a.movedir<0) a.hflip = true
  
  pintruding=false
  if p.y>=a.starty-6 and
     p.y<a.starty+7 and
     p.x>=a.minx-1 and p.x<=a.maxx+1 then
   pintruding = true
  end
  bounce = false
  if (a.x<a.minx) bounce = true
  if (a.x>a.maxx) bounce = true
  if bounce then
   a.movedir *=-1
   a.x=mid(a.minx,a.x,a.maxx)
   if (a.mode=="attack" and not pintruding) a.mode="patrol"
  end
  
  if a.mode=="patrol" then
   a.anim=dbidle
   a.speed = 0.2
   a.y=a.starty+sin(gtime)*1.3
  elseif a.mode=="attack" then
   a.anim=dbattack
   a.speed = 1
   a.y=a.starty
  end
  if pintruding then
   if a.mode=="patrol" then
    sfx(14)
    a.movedir=1
    if p.x<a.x then
     a.movedir=-1
    end
   end
   a.mode="attack"
  end
 end
  
end
-->8
--drawing
frametick = 0
changeframes = false
flashbool=false
slowflash=0
function _draw()
 
 
 changeframes = false
 frametick+=tdelta*15
 if frametick>1 then
  frametick-=1
  changeframes = true
  flashbool=not flashbool
 end
 
 slowflash+=tdelta
 if slowflash>2 then
  slowflash=0
 end
 
 
 if screen=="loselife" then
  cls(0)
  
  clip(32,50,64,22)
  rectfill(0,0,128,128,1)
  pset(32,50,0)
  pset(32,71,0)
  pset(95,50,0)
  pset(95,71,0)
  
  
  ospr(1,42,57,1,1,false,false,0,1)
  
  oprint("x",62,58,7,0)
  
  lifeoff=38+(loselifetime*25)
  lifeoff=mid(58,lifeoff,78)
  
  oprint(lives+1,78,lifeoff,7,0)
  oprint(lives,78,lifeoff-20,7,0)
 
  clip()
 
  loselifetime+=tdelta*2
  if loselifetime>3.5 then
   respawnplayer()
  end
  
  return
 end
 
 if screen=="gameover" then
  bgcol=5
  bgcol2=1
  if gametype==2 then
   bgcol=9
   bgcol2=4
  end
  if gametype==3 then
   bgcol=8
   bgcol2=2
  end
  cls(bgcol)
  rectfill(3,67,124,96,bgcol2)
  
  pset(3,67,bgcol)
  pset(124,67,bgcol)
  pset(3,96,bgcol)
  pset(124,96,bgcol)
  
  lifestr="lives left: "..lives
  if (hardmode)lifestr=""
  timestr="playtime: "..formattime(playtime)
  oprint2(lifestr,32-((#lifestr*4)/2),3,bgcol,bgcol2)
  oprint2(timestr,64+32-((#timestr*4)/2),3,bgcol,bgcol2)
  
  
  if (easymode) ooprint("~ easy peasy mode ~",26,55,8,9,0)
  if (hardmode) ooprint("! impossible mode !",26,55,8,9,0)
  
  
  gotext=""
  memoriam1=""
  memoriam2=""
  if won and score<=0 then
   gotext="perfect!"
   memoriam1="a wonderful life"
   memoriam2="lived well"
   if lives>=3 then
    if hp==100 then
     gotext="~ absolutely perfect! ~"
     memoriam1="amazing, a better life"
     memoriam2="could not have been lived!"
    else
     gotext="absolutely perfect!"
     memoriam1="it would be almost impossible"
     memoriam2="to have lived better! great!"
    end
   end
  elseif won and score<10000 then
   gotext="you win!"
   memoriam1="we should all hope to"
   memoriam2="live as well as they"
   if score>=9900 then
    gotext="finished!"
    memoriam1="what sliver of a soul remains"
    memoriam2="after a life such as this?"
   elseif score>=5000 then
    gotext="finished!"
    memoriam1="though they reached the end"
    memoriam2="they are more money than man"
   end
  elseif won and score>=10000 then
   gotext="your statue finished!"
   memoriam1="an impossible feat,"
   memoriam2="but for what?"
  elseif score>=10000 then
   gotext="too greedy!"
   memoriam1="learn well, what greed"
   memoriam2="makes of the foolish"
  elseif lives<=0 then
   gotext="ran out of lives!"
   memoriam1="a promising life"
   memoriam2="cut short"
  else
   gotext="you lose"
   memoriam1="we can't all be"
   memoriam2="winners, after all"
  end
  oprint(gotext,64-((#gotext*4)/2),15,7,1)
  
  gospr=8
  if (won) gospr=9
  x,y=60,27
  ospr(gospr,x,y,1,1,false,false,0,1)
  --gold player spr
  pal(2,9)
  pal(3,10)
  pal(12,4)
  goldness=flr(score*(0.00081))
  clip(0,y+8-goldness,128,goldness)
  spr(gospr,x,y,1,1,false,false)  
  clip()
  pal()
  
  oprint("in memoriam:",40,65,bgcol,bgcol2)
  oprint(memoriam1,64-#memoriam1*2,76,6,0)
  oprint(memoriam2,64-#memoriam2*2,84,6,0)
  
  drawhud(40)
  
  
  rectfill(0,100,128,128,0)
  
  pset(0,0,0)
  pset(127,0,0)
  pset(0,99,0)
  pset(127,99,0)
  
  gostr="zone 1: game over"
  if (gametype==2) gostr="zone 2: game over"
  if (gametype==3) gostr="ultimate mode: game over"
  oprint(gostr,64-#gostr*2,104,7,1)
 
  restartstr="press ❎ to continue"
  if (slowflash<1)oprint(restartstr,64-#restartstr*2,121,6,1)
 
  
  return
 end
 
 if (screen=="game") drawgame(screen=="game")
 
 if screen=="title" then
  cls(2)
  --if screen=="title" then
  coinupdate()
  drawcoins()
 --end
 
  vignettecol=2
  --color(vignettecol)
  --fadescrn(8)
  --fadescrn(4)
  
  --grad(0,15,128,16,0,-1,1)
  --grad(0,112,128,112,0,1,1)
  
  tx,ty = 38,19--55
  if (labelmaking) ty=55
  tyb=100
  
  rectfill(0,ty-3,128,ty+7,0)
  rectfill(0,ty-5,128,ty-5,0)
  rectfill(0,ty+9,128,ty+9,0)
  
  if not labelmaking then
   showmenu(60)
  end
  
  
  color(vignettecol)
  
  grad(16,0,16,128,-1,0,1)
  grad(111,0,111,128,1,0,1)
  
  if not labelmaking then
   sintext(115)
  end
  
  
  ooprint("~ ultimate ~",tx+5,ty+8,13,1,0)
  clip(0,ty+9,128,1)
  print("~ ultimate ~",tx+5,ty+8,12)
  clip()
  
  ooprint("curse of greed",tx,ty,9,0,1)
  clip(0,ty,128,1)
  print("curse of greed",tx,ty,7)
  clip(0,ty+1,128,1)
  print("curse of greed",tx,ty,10)
  clip(0,ty+3,128,1)
  print("curse of greed",tx,ty,10)
  clip()
 
  --show version number
  verstr="v.1"
  print(verstr,128-(#verstr/2)*8,min(60-(gtime*15),0),0)

 
 end
 
 if screen=="game" and not dead then
  fadeindex-=tdelta*18
  if (fadeindex<1) fadeindex=1
 end
 
 
 --fade out
 color(0)
 fadescrn(flr(fadeindex))

 --cpupeaks()
 
end

cpupeak=0
cpupeaktime=0
function cpupeaks()
 if cpupeaktime<0.2 then
  cpupeaktime+=tdelta
 else
  cpupeak=0---=tdelta*2
 end

 if cpupeak<stat(1) then
  cpupeak=stat(1)
  cpupeaktime=0
 end
 c=7
 if (cpupeak>0.8) c=14
 if (cpupeak>0.9) c=8
 
 oprint(stat(7).." cpu: "..cpupeak,2,120,c,0)

end

function grad(xa,ya,xb,yb,xch,ych,s)

 for i=1,#fade do
  for a=1,s do
  fillp(fade[i])
  rectfill(xa,ya,xb,yb)
  
  xa+=xch
  xb+=xch
  ya+=ych
  yb+=ych
  end
 end

 fillp()

end

function fadescrn(v)
 fillp(fade[flr(v)])
 rectfill(0,0,128,128)
 fillp()
end

camtrail=0
camlead=128
camtarget=0
pfliptime=0
function drawgame(showhud)
 --draw game
 p=playeractor
 if not sharpcam then
  
  camtrail=mid(p.x-25,camtrail,p.x)
  camlead=mid(p.x,camlead,p.x+20)
  if camtrail==p.x then
   camtarget=-15
  elseif camlead==p.x then
   camtarget=15
  end
  if p.hflip then
   pfliptime=max(0,pfliptime)
   pfliptime+=tdelta
  else
   pfliptime=min(pfliptime,0)
   pfliptime-=tdelta
  end
  if pfliptime<-1 then
   camtarget=15
  elseif pfliptime>1 then
   camtarget=-15
  end
  --camx=lerp(camx,actors[pindex].x-64+camoff,tdelta*4)
  camoff=lerp(camoff,camtarget,tdelta*4)
  camx=lerp(camx,p.x-64+camoff,tdelta*4)
 else
  camx=p.x-64
 end
 camx=mid(0,camx,896)
 camy=flr(p.y/128)*128
 camy=max(camy,0)
 
 
 bgcol=2
 if (camy>=128) bgcol=3
 if (camy>=128*2) bgcol=14
 if (camy>=128*3) bgcol=13
 
 if screen=="title" then
  --camx=(sin(gtime*0.02)*-440)+440
  --camy=(cos(gtime*0.1)*64)+64
  bgcol=2
 end
 
 cls(bgcol)
 
 
 
 camera(camx,camy)
 palt(0,false)
 palt(1,true)
 --map(0,0,0,0,128,64)
 mx=camx%8
 my=camy%8
 map(flr8(camx),flr8(camy),camx-mx,camy-my,17,17)
 palt()
 
 --tutorial text
 if screen=="game" then
  if camy<128 then
   ooprint("⬅️/➡️ = run left/right",15,110,4,9,9)
   ooprint("❎ = jump",40,100,4,9,9)
   oprint("    hold ❎\nto jump higher",220,60,2,1)
   ooprint("⬅️/➡️ + ❎ = wall jump",326,107,4,9,9)
  elseif camy<256 then
   if gametype==1 then
    ooprint("finish",40,194,10,9,9)
   end
   if gametype==3 then
    ooprint("half-way!",35,194,10,9,9)
   end
  elseif camy>380 then
   
   ooprint("★\n\nf\ni\nn\ni\ns\nh\n\n★",5,440,10,9,9)
 
  end
  
 end
 
 
 --actors & lasers
 if camy<128 then
  drawactors(actors1)
 end
 if camy>10 and camy<256 then
  drawactors(actors2)
 end
 if camy>128+10 and camy<384 then
  drawactors(actors3)
 end
 if camy>256+10 then
  drawactors(actors4)
 end
 --drawactors()
 drawlasers()
 
 
 --hud
 camera()
 drawhud(1)
 
 
end
fadeindex=1

function drawhud(hudy)

 hpy=hudy
 
 if hpshaketime>0 then
  hpshaketime-=tdelta*2
  if hpshaketime<0 then
   hpshaketime=0
  else
   hpy=hudy+sin(gtime*10)*hpshaketime*5
  end
 end
 
 
 rect(2,hpy+1,125,hpy+5,0)
 
 x_0=hpspace(0)
 x_hp=hpspace(hp)
 x_oldhp=hpspace(oldhp)
 x_maxhp=hpspace(maxhp)
 scorex = hpspace((10000-score)*0.01)
 x_full = hpspace(100)
 
 --maxhp
 --maxhp=40
 rectfill(x_oldhp,hpy+2,x_maxhp,hpy+4,2)
 fillp(0b0101101001011010)
 color(shl(2,4)+1)
 rectfill(x_oldhp,hpy+2,x_maxhp,hpy+3)
 fillp()
 if (score>0) then
  rectfill(scorex-1,hpy+2,scorex-1,hpy+4,1)
 end
 
 
 --oldhp
 rectfill(x_hp,hpy+2,x_oldhp,hpy+4,8)
 
 --hp
 rectfill(x_0,hpy+3,x_hp,hpy+3,8)
 fillp(0b0101101001011010)
 color(shl(15,4)+14)
 rectfill(x_0,hpy+2,x_hp,hpy+2)
 fillp(0b0101101001011010)
 color(shl(8,4)+2)
 rectfill(x_0,hpy+4,x_hp,hpy+4)
 fillp()
 if (hp>0) rectfill(x_0,hpy+2,x_0,hpy+3,15)
 rectfill(x_hp,hpy+3,x_hp,hpy+4,2)
 rectfill(x_hp+1,hpy+2,x_hp+1,hpy+4,1)
 
 --score
 if (score>0) then
  rectfill(scorex,hpy+2,x_full,hpy+4,9)
  rectfill(hpspace(100),hpy+3,x_full,hpy+4,4)
  fillp(0b0101101001011010)
  color(shl(15,4)+10)
  rectfill(scorex,hpy+2,x_full,hpy+2)
  rectfill(scorex,hpy+2,scorex,hpy+3)
  fillp(0b0101101001011010)
  color(shl(9,4)+4)
  rectfill(scorex+1,hpy+4,x_full,hpy+4)
  fillp()
 end
 
 rectfill(x_full+1,hpy+2,x_full+1,hpy+4,0)

 
 scorestr="gold: "..score
 oprint(scorestr,124-(#scorestr*4),hpy+5,9,0)
 
 
 oprint("hp: "..flr(hp),5,hpy+5,8,0)

 clip(0,hpy+5,128,1)
 print(scorestr,124-(#scorestr*4),hpy+5,15)
 print("hp: "..flr(hp),5,hpy+5,14)
 clip()
 
 
end

function hpspace(v)
 --converts 0-100 vars to
 --hp bar screen space
 return (v*1.22)+3
end

function drawlasers()
 for i=1,#lasers do
  drawlaser(lasers[i])
 end
end

function drawlaser(l)
 if (not l.active) return
 if (l.starty<camy) return
 if (l.starty>camy+128) return
 rectfill(l.startx,l.starty,l.endx,l.endy,l.col)
end

function drawactors(actorlist)

 --player specific stuff
 a=playeractor
 
 draw=true
 if  (a.invul>0 and flashbool) draw=false
 if draw then
  drawactor(a)
  drawgoldenplayer(a)
 end
 if changeframes and
    a.anim[a.frame]==4 then
  --footstep
  sfx(3)
 end
 
 --draw the rest
 for i=1,#actorlist do
  if actorlist[i]!=playeractor then
   drawactor(actorlist[i])
  end
 end
 
 
 
end


function drawactor(a)
  if (a.y<camy) return
  if (a.y>camy+128) return
  if (not a.active) return
 
  if (changeframes)a.frame+=1
  while a.frame>#a.anim do
   a.frame-=#a.anim
  end
  if (a.frame<0) a.frame=0
  
  if (a.x<camx-8) return
  if (a.x>camx+128) return
  
  ospr(a.anim[a.frame],a.x,a.y,1,1,a.hflip,a.vflip,0,a.otyp)
end

function drawgoldenplayer(a)
 pal(2,9)
 pal(3,10)
 pal(12,4)
 goldness=flr(score*(0.00081))
 clip(0,a.y+8-goldness-camy,128,goldness)
 spr(a.anim[a.frame],a.x,a.y,1,1,a.hflip,false)  
 clip()
 pal()
end

--outline types
--0=none 1=full
--2=no bottom
--3=no top
--4=no horizontal
function ospr(s,x,y,w,h,fx,fy,c,otyp)
 
 
 if otyp>0 then
  palall(c)
  if (otyp<4) spr(s,x-1,y,w,h,fx,fy)
  if (otyp<4) spr(s,x+1,y,w,h,fx,fy)
  if (otyp!=2) spr(s,x,y+1,w,h,fx,fy)
  if (otyp!=3) spr(s,x,y-1,w,h,fx,fy)
  pal()
 else
  palt(0,false)
  palt(14,true)
 end
 
 spr(s,x,y,w,h,fx,fy)
 palt()
 
end

function palall(v)
 pal(0,v) pal(1,v) pal(2,v)
 pal(3,v) pal(4,v) pal(5,v)
 pal(6,v) pal(7,v) pal(8,v)
 pal(9,v) pal(10,v) pal(11,v)
 pal(12,v) pal(13,v) pal(14,v)
 pal(15,v)
end

function lerp(a,b,t)
 return (1-t)*a+t*b;
end
-->8

function btnj()
 return btn(⬆️) or btn(❎) or btn(🅾️)
end

jmpreleased=true
jmptime=0
function btnjp()

 if jmpreleased then
  if btnp(⬆️) or btnp(❎) or btnp(🅾️) then
   jmpreleased=false
   return true
  end
 else
  jmpreleased=true
  if btn(⬆️) or btn(❎) or btn(🅾️) then
   jmpreleased=false
  end
 end
 
 if btn(⬆️) or btn(❎) or btn(🅾️) then
  jmptime+=tdelta
  if jmptime < 0.2 then
   --pressed recently enough, lets do it
   return true
  end
 else
  jmptime=0
 end
 
 return false
end

function formattime(t)
 --converts t to 'mm:ss' display
 tstr=""
 mins=0
 while t>=60 do
  t-=60
  mins+=1
 end
 secs=t
 if (t<10) secs="0"..t
 tstr=mins..":"..secs
 
 return tstr
end

function overlapssolid(x,y,w,h)
 --returns true if an object
 --at x,y with w,h(width,height)
 --overlaps a solid tile
 
 if (clampfmget(x,y,0)) return true
 if (clampfmget(x+w,y,0)) return true
 if (clampfmget(x,y+h,0)) return true
 if (clampfmget(x+w,y+h,0)) return true
 
 --if (fget(mget(flr8(x),flr8(y)),0)) return true
 --if (fget(mget(flr8(x+w),flr8(y)),0)) return true
 --if (fget(mget(flr8(x),flr8(y+h)),0)) return true
 --if (fget(mget(flr8(x+w),flr8(y+h)),0)) return true
 
 return false
end

function clampfmget(x,y,f)
 if (x<0) return true--x=0
 if (y<0) y=0
 if (x>1024) return true--x=1024
 if (y>512) y=512
 
 --return fget(mget(flr8(x),flr8(y),f))
 return fget(mget(flr8(x),flr8(y)),f)
end

function getdist(ax,ay,bx,by)
 --get distance between
 --two points
 a=ax-bx
 b=ay-by
 a*=0.01
 b*=0.01
 a=a*a+b*b
 a=sqrt(a)*100
 
 if(a<0) return 32767 --clamp big numbers

 return a
end

function flr8(v)
 --converts a position from
 --game space to map space
 return flr(v/8)
end

function lerp(a,b,t)
 return (1-t)*a+t*b;
end

function ooprint(s,x,y,col,ocol,ocolb)
 --oprint(s,x-1,y,col,ocolb)
 print(s,x-2,y,ocolb)
 print(s,x+2,y,ocolb)
 print(s,x,y-2,ocolb)
 print(s,x,y+2,ocolb)
 
 print(s,x-1,y-1,ocolb)
 print(s,x+1,y-1,ocolb)
 print(s,x-1,y+1,ocolb)
 print(s,x+1,y+1,ocolb)
 
 oprint(s,x,y,col,ocol)
end

function oprint(s,x,y,col,ocol)
 --print text with outline
 print(s,x-1,y,ocol)
 print(s,x+1,y,ocol)
 print(s,x,y-1,ocol)
 print(s,x,y+1,ocol)
 print(s,x,y,col)
end

function oprint2(s,x,y,col,ocol)
 --print text with outline
 print(s,x-1,y,ocol)
 print(s,x+1,y,ocol)
 print(s,x,y-1,ocol)
 print(s,x,y+1,ocol)
 print(s,x-1,y-1,ocol)
 print(s,x+1,y-1,ocol)
 print(s,x+1,y+1,ocol)
 print(s,x-1,y+1,ocol)
 print(s,x,y,col)
end


function playercollisions(p)
 returnlist={}
 if p.y<128 then
  for a=1,#colliders1 do
   if aca(p,actors1[colliders1[a]]) then
    add(returnlist,actors1[colliders1[a]])
   end
  end
 elseif p.y<256 then
  for a=1,#colliders2 do
   if aca(p,actors2[colliders2[a]]) then
    add(returnlist,actors2[colliders2[a]])
   end
  end
 elseif p.y<384 then
  for a=1,#colliders3 do
   if aca(p,actors3[colliders3[a]]) then
    add(returnlist,actors3[colliders3[a]])
   end
  end
 else
  for a=1,#colliders4 do
   if aca(p,actors4[colliders4[a]]) then
    add(returnlist,actors4[colliders4[a]])
   end
  end
 end
 return returnlist
end

--does one actor overlap another
function aca(a,b)
 if (not b.active) return false
 if (a.x<b.x-7) return false
 if (a.x>b.x+7) return false
 if (a.y<b.y-7) return false
 if (a.y>b.y+7) return false
 return true
end

function acollidesallold(actor)
 --returns list of alllll
 --actors touched
 returnlist={}
 for a=1,#actors do
  if actors[a].x>actor.x-7 and
     actors[a].x<actor.x+8 and
     actors[a].y>actor.y-7 and
     actors[a].y<actor.y+8 then
   add(returnlist,actors[a])
  end
 end
 
 return returnlist
end

function movevert(p,my)
 --move player p by my units
 
 
 p.y+=my
 
 --resolve vert collisions
 while overlapssolid(p.x,p.y,7,7) do
  p.y+=-my*0.1
  p.fy=0
  if my>0 then
   --land
   if (not p.grounded and screeninputwait>0.3) sfx(4)
   p.grounded=true
   p.fy=0
  else
   --bump head
   if (my<0) sfx(16)
  end
 end
 
 
end

function movehoriz(p,mx)
 --move player p by mx units
 
 --return if motion is too small
 if (abs(mx)<0.01) return
 
 safex=p.x
 safey=p.y
 targetx=p.x+mx
 
 
 
 while p.x!=targetx do
  p.x += mx*0.1
  --moved far enough
  if (mx>0 and p.x>targetx) or
     (mx<0 and p.x<targetx) then
   p.x=targetx
  end
  
  --check if we can be where we moved to
  bump = false
  if overlapssolid(p.x,p.y,7,7) then
   bump = true
  end
  
  
  if bump then
   p.fx=0
   p.x=targetx
  else
   --can move to here
   safex=p.x
   safey=p.y
  end
  
 end
 
 p.x=safex
 p.y=safey
 
end
-->8
timefrmwall=0
function playerupdate(p)
 
 jumppressed=btnjp()
 
 if screen=="title" then
  p.invul=0
  return
 end
 
 timefrmwall+=tdelta
 
 
 if won and p.grounded then
  dienow()
  return
 end
 
 if hp<=0 and p.grounded then
  dienow()
 end
 
 if (dead) return
 
 
 if p.invul>0 then
  p.invul-=tdelta
 end

 --horizontal input/forces
 dirin=0
 if (btn(⬅️)) dirin=-1
 if (btn(➡️)) dirin=1
 if (btn(⬅️) and btn(➡️)) dirin=0
 
 
 if dirin==-1 and hp>0 and not won then
  p.fx-=tdelta*160
  p.hflip=true
 end
 if dirin==1 and hp>0 and not won then
  p.fx+=tdelta*160
  p.hflip=false
 end
 if (dirin==0) or hp<=0 then
  p.fx = lerp(p.fx,0,tdelta*10)
 end
 p.fx=mid(-60,p.fx,60)
 
 
 --grounded/falling
 if not p.grounded then
  p.fy+=128*tdelta*2
  
  --holding to jump higher
  if p.fy<0 and not btnj() then--and p.invul<=0 then
   p.fy+=128*tdelta*3
  end
  
  p.fy=min(p.fy,90)
  
  --drag when wallslide
  if (p.pushing and hp>0) p.fy=min(p.fy,30)
 end
 
 --walljumping
 if timefrmwall>0.2 and not p.grounded and p.wallframes>0 and jumppressed and hp>0 then
  sfx(0)
  timefrmwall=0
  if p.hflip then
   p.fx=150*p.walldir
  else
   p.fx=150*p.walldir
  end
  if (dirin==0) p.hflip=not p.hflip
  
  p.fy=-27.5*3*1.5
  p.grounded=false
  p.pushing = false
 end
 --jumping
 if screeninputwait>0.3 then
 if p.grounded and jumppressed and hp>0 then
  sfx(0)
  timefrmwall=0
  p.fy=-27.5*3*1.5
  p.grounded=false
 end
 end
 
 --move vert
 movevert(p, p.fy*tdelta)
 
 
 --check grounded
 if not overlapssolid(p.x,p.y+1,7,7) then
  p.grounded=false
 end
 
 --move horiz
 movehoriz(p, p.fx*tdelta)
 
 --collision
 oldfy=p.fy
 collisions=playercollisions(p)--acollidesall(p)
 for i=1,#collisions do
  c=collisions[i]
  if c.typ=="coin" and c.active then
   if getdist(c.x,c.y,p.x,p.y)<6 then
    c.active=false
    if easymode then
     score+=75
    elseif hardmode then
     score+=300
    else
     score+=150
    end
    hpshaketime=0.4
    sfx(1)
   end
   
  end
  
  if c.typ=="heart" and c.active then
   sfx(5)
   c.active=false
   hp=maxhp
  end
  
  if c.typ=="checkpoint" then
   if c.x!=checkx or c.y!=checky then
    checkx=c.x
    checky=c.y
    sfx(8)
   end
  end
  
  if c.typ=="finish" then
   if c.finish then
    won=true
   end
  end
  
  if c.typ=="deathball" then
   if p.y<c.y+6 and p.y>c.y-5 and
      p.x>c.x-5 and p.x<c.x+5 then
    hurtplayer(0,-75,p)
   end
  end
  
  if c.typ=="trampoline" then
   if oldfy>0 and hp>0then
    p.grounded=false
    timefrmwall=-0.2
    p.fy=-180
    c.bounce=0.2
    c.anim=trampbounce
    c.frame=1
    sfx(15)
   end
  end
  
  if c.typ=="spike" then
   if p.y>c.y-5 and p.fy>=0
   and p.x>c.x-5 and p.x<c.x+5 then
    hurtplayer(0,-75,p)
   end
  end
  if c.typ=="topspike" then
   if c.y>p.y-5 and p.fy<=0
   and p.x>c.x-5 and p.x<c.x+5 then
    hurtplayer(0,75,p)
   end
  end
  if c.typ=="wallspike" then
   if p.x<=c.x+1 then
    if p.y>c.y-6 and p.y<c.y+6 then
    hurtplayer(150,0,p)
    end
   end
  end
  if c.typ=="wallspike2" then
   if p.x>=c.x then
    if p.y>c.y-6 and p.y<c.y+6 then
    hurtplayer(-150,0,p)
    end
   end
  end
 end
 
 --lasers
 for i=1,#lasers do
  l=lasers[i]
  if l.active then
  
  if l.laserdir=="⬅️" or
     l.laserdir=="➡️" then
   if l.startx<=p.x+8 and
      l.endx>=p.x and
      l.starty>p.y and
      l.starty<p.y+8 then
       if l.laserdir=="⬅️" then
        hurtplayer(-50,-30,p)
       else
        hurtplayer(50,-30,p)
       end
   end
  elseif l.laserdir=="⬆️" or
     l.laserdir=="⬇️" then
   if l.starty<=p.y+8 and
      l.endy>=p.y and
      l.startx>=p.x+1 and
      l.startx<p.x+5 then
       if l.laserdir=="⬆️" then
        hurtplayer(0,-30,p)
       else
        hurtplayer(0,30,p)
       end
   end
  end 
    
  end
 end
 
 if p.wallframes>0 then
  p.wallframes-=1
 end
 if (p.grounded) p.wallframes=0
 
 --animations
 waspushing = p.pushing
 p.pushing = false
 if dirin!=0 then
  if (p.fx==0) p.pushing = true
 end
 if not p.grounded then
  if overlapssolid(p.x-1,p.y,7,7) then
   p.wallframes=6
   p.walldir=1
  end
  if overlapssolid(p.x+1,p.y,7,7) then
   p.wallframes=6
   p.walldir=-1
  end
 end
 if p.pushing and not waspushing and not p.grounded then
  sfx(6)
 end
 if p.grounded then
  if p.pushing then
   p.anim=ppush
  elseif dirin!=0 then
   p.anim=prun
  else
   p.anim=pidle
  end
 else
  if p.pushing then
   p.anim=pwallslide
  elseif p.fy<0 then
   p.anim=prise
  else
   p.anim=pfall
  end
 end
 if hp<=0 or score>=10000then
  p.anim=pdead
 end
 if won then
  p.anim=pwon
 end
 
end

function hurtplayer(x,y,p)
 if (p.invul>0) return
 if (won) return
 sfx(2)
 p.grounded=false
 p.fx=x
 p.fy=y*1.3
 if easymode then
  hp-=10
 elseif hardmode then
  hp-=20
 else
  hp-=15
 end
 p.invul=1.5
 hpshaketime=1
end

-->8
stindex=0
credits="★  game by sophie houlden ★    "
.."🐱  made with lexaloffle's awesome pico-8 🐱    "
.."◆  vectors possible thanks to gabriel crowe ◆    "
.."♥  shout out to my patrons: ♥  "
.."aeronic ♥  agent v ♥  alan hazelden ♥  alex mole ♥  alex taylor ♥  alice robinson ♥  amazing stace ♥  andrew thorpe ♥  arcadely ♥  ashly ♥  c ♥  calum grace ♥  cb droege ♥  chris hudson ♥  chris ♥  cian booth ♥  claire ♥  clarity ♥  colin strong ♥  connor sherlock ♥  cool ghosts ♥  dan hett ♥  dan sanderson ♥  dan stott ♥  daniel cassidy ♥  darkflux ♥  dave reed ♥  david green ♥  davio cianci ♥  derek carroll ♥  dominick briggs ♥  dorian beaugendre ♥  drew messinger-michaels & lauren villegas ♥  dustin mckenzie ♥  ed key ♥  ed ♥  edderiofer he ♥  edmund lewry ♥  elliott davis ♥  eric schwarzott ♥  evan gale ♥  flout. ♥  francis fernandez ♥  fred alger ♥  gkr ♥  greg v. ♥  gregory avery-weir ♥  harry danby ♥  hayden scott-baron ♥  herve jolly ♥  hodge ♥  ian danskin ♥  ian badcoe ♥  ian walker ♥  israel storey ♥  jake hadley ♥  jamie ♥  jeremy oduber ♥  jonathan wright ♥  josh mathews ♥  keith evans ♥  kemp ♥  kleril ♥  kylie backstrom ♥  lax ♥  le-roy karunaratne ♥  lee ♥  luke robinson ♥  luke ♥  malcolm brown ♥  malky ♥  marcelo perez ♥  max ♥  michael ♥  michael adams ♥  mike watson ♥  miles ranisavljevic ♥  mistodon ♥  neil ♥  nerdi ♥  norgg ♥  oscar paterson ♥  perlamps ♥  piano inky ♥  rav ♥  richard fabian ♥  robert mock ♥  ronja bohringer ♥  royce rogers ♥  sarah mccormack ♥  shane doyle ♥  sigurdur finnsson ♥  simmer.io ♥  stacy read ♥  stephen stagg ♥  stingingnettle ♥  terry ♥  thegamedesigner ♥  thomas shea ♥  tim monks ♥  toby ♥  vincent markusse ♥  vorundor ♥  weeble wilson ♥  willem jager ♥"

stimer=0
function sintext(sty)
 if stindex==0 then
  credits="                                    "..credits
  stindex=1
 end
 stimer+=tdelta*9
 if stimer>1 then
  stindex+=1
  stimer-=1
 end
 if (stindex>#credits) stindex=1
 
 
 str=sub(credits,stindex,stindex+32)
 
 local x,y=0,0
 for i=1,#str do
  x=(i*4.2)-(stimer*4)-4
  y=sty+sin(gtime-(x*0.01))*2
  oprint(sub(str,i,i),x,y,13,0)
  
  
  
 end
 
end

firstmenu = true
function showmenu(my)

 
 fillp(fade[15+flr(sin(gtime*0.5)*4)])
 rectfill(0,my+mindex*8,128,my+4+mindex*8,0)
 fillp()
 
 for i=1,#menu do
  mstr=menu[i]
  moff=#mstr*2
  if firstmenu and i==mindex and slowflash<1 then
   mstr = "❎  "..mstr.."  ❎"
   moff+=16
  end
  
  mcol=4
  if (mindex==i) mcol=9
  
  ooprint(mstr,64-moff,my+i*8,mcol,0,1)
 
  if mindex==i then
   clip(0,my+1+i*8,128,1)
   print(mstr,64-moff,my+i*8,10)
   clip()
  end
  
 end

end

-->8
--vectors based on http://hotmessgames.com/poly/

charhex={}
for i=1,16 do
 charhex[sub("0123456789abcdef",i,i)]=i-1
end

function strtovec(s, i)
 local v={}
 if (i==nil) i=2 -- skip top {
 local i0=i
 
 while true do

  if (sub(s,i,i)=="{") then
   -- add table
   local t,len=strtovec(s,i+1)
   add(v,t)
   i+=len
  elseif (sub(s,i,i)=="}") then
   return v,i-i0+2
  else
   -- add number
   x= charhex[sub(s,i,i)]*16 +
      charhex[sub(s,i+1,i+1)]
   add(v,x)
   i+=2
  end
 end
end




vectordata = strtovec("{{{0a09{4e508040ae524e50ae52c0814e50c081b0b04e50b0b080bf4e5080bf53ae4e5053ae3f80}}{0908{5b5a804f605f5b5a605f4b7e}}{0a0a{9d9eb280a4a69d9ea4a680b1}}}{{0a09{5c587d419e565c589e56aa815c58aa81a2a95c58a2a980be5c5880be5ca95c585ca94f81}}{0908{7b418840a853a853b581abababab89bf7ebeabab7ebea1a8ababa1a8a981a853ababa981a853a9819c577b41a8539c57}}{0908{635e794f6763635e67635780}}{0a0a{919e9c8196a1919e96a181af}}}{{0908{75418c41945b7541945b987f7541987f93a2754193a28abe75418abe75be754175be7080}}{0a09{7280764f794672807946805c7280805c85817280858180aa728080aa78ba}}}{{0908{73418d419280734192808dbe73418dbe75be734175be69a4734169a46181734161816660}}{0909{86458b539081864590818da586458da587ba864587ba7da586457da57682864576827c5b}}}{{0909{53816058804153818041a3575381a357b0815381b081a5a85381a5a881c0538181c061a8}}{0908{76418441635963a884c073bf63a873bf55a9558263a855a9558255a94682635955824682635946825456764163595456}}{0908{6e5c825073626e5c73626280}}{0a09{979ca8819ea2979c9ea281b2}}}}")


coins={}
function addcoin(s)
 c={}
 c.rot=rnd()
 c.spin=rnd()+0.1
 if (rnd()<0.5) c.spin*=-1
 c.spin*=0.5
 c.x=rnd()*128
 c.y=rnd()*128
 c.scale=s
 c.frame=(rnd()*(#vectordata-1))+1
 add(coins,c)
end

ccount=8
if (labelmaking) ccount=15
for i=1,ccount do
 cscale=(i*0.02)+0.1
 addcoin(cscale*0.6)
end

coinwait=0
function drawcoins()
 if coinwait<10 then
  coinwait+=1
  return
 end
 for i=1,#coins do
  c=coins[i]
  if labelmaking then
   sprv(vectordata,flr(c.frame),c.x+5,c.y+8,c.scale*0.6,c.rot,true)
  
  end
  sprv(vectordata,flr(c.frame),c.x,c.y,c.scale,c.rot)
  
 end
end

function coinupdate()
 for i=1,#coins do
  c=coins[i]
  
  c.rot+=c.spin*tdelta
  
  c.y+=c.scale*c.scale*60
  if c.y>128+(128*c.scale) then
   c.y=(128*-c.scale)-(rnd()*20)
   c.x=rnd()*128
  end
  
  c.frame+=0.2
  if c.frame>#vectordata+1 then
   c.frame=1
  end
 end
end

-- 'sprite vector'
function sprv(anim,frame,x,y,scale,rot,shadow)
  x=x-flr(128*scale)
  y=y-flr(128*scale)
  
  s = sin(rot)
  cs = cos(rot)

  tris = 0
  for f=1,#anim[frame] do
   v=anim[frame][f]
  	col = v[1]
   col2 = v[2]
   
   if not shadow then
    fillp(0b1010010110100101)
    color(shl(v[1],4)+v[2])
   else
    fillp(0b1010010110100101.1)
    color(1)
   end
   
   t = v[3]
   for i=1, #t/6 do
    b=(i-1)*6
    
    x0=t[1+b]
    y0=t[2+b]
    x1=t[3+b]
    y1=t[4+b]
    x2=t[5+b]
    y2=t[6+b]
    
    v0 = rotvert(x0,y0,s,cs,128)
    v1 = rotvert(x1,y1,s,cs,128)
    v2 = rotvert(x2,y2,s,cs,128)
    
    x0=v0.x
    x1=v1.x
    x2=v2.x
    y0=v0.y
    y1=v1.y
    y2=v2.y
    
    x0*=scale
    y0*=scale
    x1*=scale
    y1*=scale
    x2*=scale
    y2*=scale
    
    x0=flr(x0)
    y0=flr(y0)
    x1=flr(x1)
    y1=flr(y1)
    x2=flr(x2)
    y2=flr(y2)
      
    tris = tris + 1
    fasttri(x+x0,y+y0,x+x1,y+y1,x+x2,y+y2 )
   end
  end
  return tris
end

function rotvert(x,y,s,c,offset)
 x-=offset
 y-=offset
 v={}
 v.x=x*c-y*s
 v.y=x*s+y*c
 v.x+=offset
 v.y+=offset
 return v
end


function fasttri(x0,y0,x1,y1,x2,y2)
 if (y1<y0) x0,x1=x1,x0; y0,y1=y1,y0
 if (y2<y0) x0,x2=x2,x0; y0,y2=y2,y0
 if (y2<y1) x1,x2=x2,x1; y1,y2=y2,y1
 local hh=y1-y0
 local newx=x0+(hh)*(x2-x0)/(y2-y0)
 if (y0!=y1) trifill(y0,y1,(newx-x0)/hh,(x1-x0)/hh,x0,x0)
 hh=y2-y1
 if (y1!=y2) trifill(y1,y2,(x2-x1)/hh,(x2-newx)/hh,x1,newx)
end

function trifill(t,b,l,r,pl,pr)
 for y=t,b do
  rectfill(pl,y,pr,y)
  pl+=l pr+=r
 end
end