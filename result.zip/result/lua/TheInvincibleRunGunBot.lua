--run-gun-bot
--by guerragames

one_frame,epsilon,max_air_time=.0166667,.001,6000

-- 64x64 screen mode
poke(0x5f2c,3)

--
cartdata("rungunbot")

--
function load_game()
 player_checkpoint_x,player_checkpoint_y,game_time,player_score,player_hits,mirror_mode,gun_types_flags=dget(0),dget(1),dget(2),dget(3),dget(4),dget(5),dget(6)

 if(player_checkpoint_x==0)player_checkpoint_x=16
 if(gun_types_flags==0)gun_types_flags=1

 for i=1,8 do
  pickup_save_masks[i]=dget(50+i)
 end
 
 mirror_mode_bool=mirror_mode==1
 
 if mirror_mode_bool then
  for i=0,127 do
   for j=0,31 do
    poke(0x6000+i+j*128,mget(127-i,j))
    poke(0x7000+i+j*128,mget(127-i,j+32))
   end
  end
  memcpy(0x2000,0x6000,0x1000)
  memcpy(0x1000,0x7000,0x1000)
 end
end

--
function save_game()
 dset(0,player_checkpoint_x)
 dset(1,player_checkpoint_y)
 dset(2,game_time)
 dset(3,player_score)
 dset(4,player_hits)
 dset(5,mirror_mode)

 dset(6,gun_types_flags)
 
 for i=1,8 do
  dset(50+i,pickup_save_masks[i])
 end

 show_hud_timer=3
end

--
function new_game()
 player_checkpoint_x,player_checkpoint_y,game_time,player_score,player_hits,gun_types_flags=16,0,0,0,0,1

 for i=1,8 do
  pickup_save_masks[i]=0
 end
 
 save_game()
 run()
end

--
function reset_game()
 mirror_mode=0
 new_game()
end

--
function reset_game_mirrored()
 mirror_mode=1
 new_game()
end

--
function next_i(l,i)
 i+=1
 if(i>#l)i=1
 return i
end

--
function find_next_i(l,i,active_count)
 if active_count>=#l then
  return nil,0
 end
 
 local o=l[i]
 while o.active do
  i=next_i(l,i)
  o=l[i]
 end
 
 return o,i
end

--
function nl(s)
 local a={}
 local ns=""
 
 while #s>0 do
  local d=sub(s,1,1)
  if d=="," then
   add(a,ns+0)
   ns=""
  else
   ns=ns..d
  end
  
  s=sub(s,2)
 end
 
 return a
end

--
function unpack(y,i)
 i=i or 1
 local g=y[i]
 if(g)return g,unpack(y,i+1)
end

--
function mag(x,y)
  local d=max(abs(x),abs(y))
  local n=min(abs(x),abs(y))/d
  return sqrt(n*n+1)*d
end

--
function normalize(x,y)
  local m=mag(x,y)
  return x/m,y/m,m
end

--
cam_shake_x,cam_shake_y,cam_shake_damp=0,0,0
screen_flash_timer,screen_flash_color=0,7

--
function screenflash(duration,color)
 screen_flash_timer,screen_flash_color=duration,color
end

--
function screenshake(max_radius,damp,cor)
 local a=rnd()
 cam_shake_x,cam_shake_y=max_radius*cos(a),max_radius*sin(a)
 cam_shake_damp,cam_shake_corruption=damp,cor
end

--
function update_screeneffects()
 cam_shake_x*=cam_shake_damp+rnd(.1)
 cam_shake_y*=cam_shake_damp+rnd(.1)
 
 if abs(cam_shake_x)<1 and abs(cam_shake_y)<1 then
  cam_shake_x,cam_shake_y=0,0
 end

 if screen_flash_timer>0 then
  screen_flash_timer-=one_frame
 end
end

--
function screenshake_corruption_draw()
 if cam_shake_corruption then
  if abs(cam_shake_x)<1 and abs(cam_shake_y)<1 then
  else
   for i=0,20 do
    local m1=0x6000+rnd(0x2000-128)
    local m2=m1+rnd(64)
    memcpy(m1,m2,rnd(64))
   end
  end
 end
end

--
align_l,align_r=1,2

function print_outline(t,x,y,c,bc,a)
 local ox=#t*2 
 if a==align_l then
  ox=0
 elseif a==align_r then
  ox=#t*4
 end
 local tx=x-ox
 color(bc)
 print(t,tx-1,y)print(t,tx-1,y-1)print(t,tx,y-1)print(t,tx+1,y-1)
 print(t,tx+1,y)print(t,tx+1,y+1)print(t,tx,y+1)print(t,tx-1,y+1)
 print(t,tx,y,c)
end

--
function time_to_text(time)
 local hours,mins,secs=flr(time/3600),flr(time/60%60),flr(time%60)
 if(hours<0 or hours>9)return "8:59:59"
 local txt=hours>0 and hours..":" or ""
 txt=txt..((mins>=10 or hours==0) and mins or "0"..mins)
 txt=txt..(secs<10 and ":0"..secs or ":"..secs)
 return txt
end

--
function create_button(btn_num)
 return 
 {
  time_since_press=100,
  last_time_held=0,
  time_held=0,
  time_released=0,
  button_number=btn_num,

  button_init=function(b)
   b.time_since_press,b.time_held=100,0
  end,

  button_update=function(b)
   b.time_since_press+=one_frame

   if btn(b.button_number) then
    if b.time_held==0 then
     b.time_since_press=0
    end
  
    b.time_held+=one_frame
   else
    if(b.time_held!=0)b.time_released=0
    b.last_time_held=b.time_held
    b.time_held=0
    b.time_released+=one_frame
   end
  end,

  button_consume=function(b)
   b.time_since_press=100
  end,
 }
end

jump_button=create_button(5)
shoot_button=create_button(4)

--
function round(x) return flr(x+.5) end
 
--
function map_coords(x,y)
 return flr(round(x)/8),flr(round(y)/8)
end

--
function set_tile_if(x,y,ov,nv)
 local mx,my=map_coords(x,y)
 if mget(mx,my)==ov then
   if ov==87 then
    if(flr(x/64)!=flr(player_x/64) or flr(y/64)!=flr(player_y/64))return false
    
    game_finished,game_finished_timer=true,0
    save_game()
   end
   
   mset(mx,my,nv)
   return true
 end
 
 return false
end

--
function s_floor(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx,my-1)
 return fget(val,0) and not fget(val2,2)
end

function s_ceil(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx,my+1)
 return fget(val,2) and not fget(val2,0)
end

function s_lwall(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx+1,my)
 return fget(val,3) and not fget(val2,1)
end

function s_rwall(x,y)
 local mx,my=map_coords(x,y)
 local val,val2=mget(mx,my),mget(mx-1,my)
 return fget(val,1) and not fget(val2,3)
end

--
function collision_checks(x,y,vx,vy,ws,we,hs,he)
 local new_x,new_y=x,y
 
 local on_floor,on_ceiling,on_lwall,on_rwall=false,false,false,false
 
 local nvx,nvy,vel_mag=normalize(vx,vy)
 
 local keep_looking=true
 
 while keep_looking do
  local temp_x,temp_y=new_x,new_y
  
  if vel_mag>epsilon then
   local i_vx=(vel_mag>=1) and nvx or vel_mag*nvx 
   local i_vy=(vel_mag>=1) and nvy or vel_mag*nvy
        
    if not on_floor and not on_ceiling then
     if i_vy>0 then
      if s_floor(new_x+ws+1,new_y+he+1) and not s_ceil(new_x+ws+1,new_y+he-1) or 
         s_floor(new_x+we-1,new_y+he+1) and not s_ceil(new_x+we-1,new_y+he-1) then
       on_floor=true
       temp_y=round(temp_y)
       nvy,i_vy=0,0
      end
     else
      if s_ceil(new_x+ws+1,new_y+hs-1) and not s_floor(new_x+ws+1,new_y+hs+1) or
         s_ceil(new_x+we-1,new_y+hs-1) and not s_floor(new_x+we-1,new_y+hs+1) then
       on_ceiling=true
       temp_y=round(temp_y)
       nvy,i_vy=0,0
      end
     end
    end
    
    if not on_rwall and not on_lwall then
     if i_vx > 0 then
      if s_rwall(new_x+we+1,new_y+hs+1) and not s_lwall(new_x+we-1,new_y+hs+1) or
         s_rwall(new_x+we+1,new_y+he-1) and not s_lwall(new_x+we-1,new_y+he-1) then
       on_rwall=true
       temp_x=round(temp_x)
       nvx,i_vx=0,0
      end
     else
      if s_lwall(new_x+ws-1,new_y+hs+1) and not s_rwall(new_x+ws+1,new_y+hs+1) or
         s_lwall(new_x+ws-1,new_y+he-1) and not s_rwall(new_x+ws+1,new_y+he-1) then
       on_lwall=true
       temp_x=round(temp_x)
       nvx,i_vx=0,0
      end
     end
    end

    if abs(i_vy)>epsilon and abs(i_vx)>epsilon and not on_floor and not on_ceiling and not on_lwall and not on_rwall then
    if not on_floor and not on_ceiling then
     if i_vy > 0 then
      if s_floor(new_x+ws-1,new_y+he+1) and not s_ceil(new_x+ws+1,new_y+he-1) or 
         s_floor(new_x+we+1,new_y+he+1) and not s_ceil(new_x+we-1,new_y+he-1) then
       on_floor=true
       temp_y=round(temp_y)
       nvy,i_vy=0,0
      end
     else
      if s_ceil(new_x+ws-1,new_y+hs-1) and not s_floor(new_x+ws+1,new_y+hs+1) or
         s_ceil(new_x+we+1,new_y+hs-1) and not s_floor(new_x+we-1,new_y+hs+1) then
       on_ceiling=true
       temp_y=round(temp_y)
       nvy,i_vy=0,0
      end
     end
    end
    
    if not on_floor and not on_ceiling and not on_rwall and not on_lwall then
     if i_vx > 0 then
      if s_rwall(new_x+we+1,new_y+hs-1) and not s_lwall(new_x+we-1,new_y+hs+1) or
         s_rwall(new_x+we+1,new_y+he+1) and not s_lwall(new_x+we-1,new_y+he-1) then
       on_rwall=true
       temp_x=round(temp_x)
       nvx,i_vx=0,0
      end
     else
      if s_lwall(new_x+ws-1,new_y+hs-1) and not s_rwall(new_x+ws+1,new_y+hs+1) or
         s_lwall(new_x+ws-1,new_y+he+1) and not s_rwall(new_x+ws+1,new_y+he-1) then
       on_lwall=true
       temp_x=round(temp_x)
       nvx,i_vx=0,0
      end
     end
    end
    end
    
    if not on_floor and not on_ceiling then
     temp_y+=i_vy
    end
  
    if not on_rwall and not on_lwall then
     temp_x+=i_vx
    end    
  
    vel_mag-=1
  else
   keep_looking=false
  end

  new_x,new_y=temp_x,temp_y
  
  if on_floor or on_ceiling then
   new_y=round(new_y/8)*8
  end
 
  if on_rwall or on_lwall then
   new_x=round(new_x)
  end
 end
 
 return {x=new_x,y=new_y,floor=on_floor,lwall=on_lwall,rwall=on_rwall,ceil=on_ceiling}
end

-- camera
cam_res=64

--
function cam_reset()
 local mpx,mpy=flr(player_x/cam_res)*cam_res,flr(player_y/cam_res)*cam_res
 cam_x,cam_y,target_cam_x,target_cam_y=mpx,mpy,mpx,mpy
 enemies_spawn_check()
end

--
function cam_update()
 local pcx,pcy=player_x+4,player_y+4
 
 if pcx>target_cam_x+cam_res then
  target_cam_x+=cam_res
  enemies_spawn_check()
 elseif pcx<target_cam_x then
  target_cam_x-=cam_res
  enemies_spawn_check()
 end
 
 if pcy>target_cam_y+cam_res then
  target_cam_y+=cam_res
  enemies_spawn_check()
 elseif pcy>0 and pcy<target_cam_y then
  target_cam_y-=cam_res
  enemies_spawn_check()
 end

 if abs(cam_x-target_cam_x)>1 then
  cam_x+=.15*(target_cam_x-cam_x)
 else
  cam_x=target_cam_x
 end
 if abs(cam_y-target_cam_y)>1 then
  cam_y+=.15*(target_cam_y-cam_y)
 else
  cam_y=target_cam_y
 end
end

-- part
parts={}
parts_next,parts_blink=1,0

for i=0,400 do
 add(parts,{t=0})
end

parts_flags_floor_bounce,parts_flags_blink,parts_flags_no_outline=0x01,0x02,0x04

--
function parts_spawn(t,x,y,vx,vy,g,d,s,ds,c,bc,f)
 parts_next=next_i(parts,parts_next)
 
 local p=parts[parts_next]
 
 p.t,p.x,p.y,p.vx,p.vy,p.g,p.d,p.s,p.ds,p.c,p.bc,p.f=t,x,y,vx,vy,g,d,s,ds,c,bc,f
end

--
function parts_update()
 parts_blink+=one_frame
 
 for k,p in pairs(parts) do
  if p.t>0 then
   p.t-=one_frame
   
   p.vx*=p.d
   p.vy*=p.d
   
   p.x+=p.vx
   p.y+=p.vy
   
   p.s=max(0,p.s+p.ds)
   
   if p.s<=0 then
    p.t=0
   end
   
   if band(p.f,parts_flags_blink)==parts_flags_blink then
    if parts_blink%.2>.1 then 
     p.c,p.bc=p.bc,p.c
    end
   end
   
   if band(p.f,parts_flags_floor_bounce)==parts_flags_floor_bounce and s_floor(p.x,p.y+p.s) then
    if abs(p.vy)>.2 then
     p.vy=-.8*p.vy
    end
   else
    p.vy+=p.g
   end
  end
 end
end

--
function part_draw(p,o,c)
 local s=p.s+o
 
 if s<=1 then
  pset(p.x,p.y,c)
 else
  circfill(p.x,p.y,s-1,c)
 end
end

--
function parts_draw()
 for k,p in pairs(parts) do
  if p.t>0 then
   if band(p.f,parts_flags_no_outline)!=parts_flags_no_outline then
    part_draw(p,1,p.bc)
   end
  end
 end

 for k,p in pairs(parts) do
  if p.t>0 then
   part_draw(p,0,p.c)
  end
 end
end

-- pbullets
pbullets={}
pbullets_next,pbullets_active_count=1,0

for i=0,50 do
 add(pbullets,{active=false})
end

--
function pbullets_spawn(x,y,vnx,vny)
 local pb,i=find_next_i(pbullets,pbullets_next,pbullets_active_count)
 
 if pb then
  pbullets_next=i
  
  pbullets_active_count+=1
  pb.active=true
  
  local gt=gun_types[player_current_gun]
  pb.t,pb.x,pb.y,pb.vx,pb.vy=gt.maxt,x,y,gt.speed*vnx,gt.speed*vny
  pb.gt=gt
  pb.g=gt.g
  
  sfx(player_current_gun)
 end
end

--
function pbullets_crash(pb)
 pb.active=false
 pbullets_active_count-=1
 
 for i=1,20 do
  local a,r=rnd(),.5+rnd(2)
  local vx,vy=r*cos(a),r*sin(a)
  parts_spawn(2*pb.gt.pt,pb.x+1-rnd(2),pb.y+1-rnd(2),vx,vy,0,.9,rnd(pb.gt.size+1),-.2,7,pb.gt.color)
 end
end

--
function pbullets_update()
 for k,pb in pairs(pbullets) do
  if pb.active then
   pb.t-=one_frame
   
   local pbgt=pb.gt
   
   if pb.t<0 then
    if band(pbgt.f,gt_flag_timeout_explode)!=0 then
     pbullets_crash(pb)
    else
     pb.active=false
     pbullets_active_count-=1
    end
   end
   
   pb.vy+=pb.g
   
   local check_collision=(band(pbgt.f,gt_flag_no_collision)==0)
   
   local replace_tile=pbgt.rtile or 64
   local destroy_tile=pbgt.dtile
   
   local pb_cr=nil
   if check_collision then
    pb_cr=collision_checks(pb.x,pb.y,pb.vx,pb.vy,0,0,1,1)
    pb.x,pb.y=pb_cr.x,pb_cr.y
   else
    pb.x+=pb.vx
    pb.y+=pb.vy
    if(set_tile_if(pb.x,pb.y,destroy_tile,replace_tile))pbullets_crash(pb)
   end
   
   local pbx,pby=pb.x,pb.y
   
   if check_collision and pb_cr and (pb_cr.floor or pb_cr.ceil or pb_cr.lwall or pb_cr.rwall) then
    local destroyed_tile=false
    if destroy_tile then
     if(pb_cr.floor)destroyed_tile=set_tile_if(pbx,pby+1,destroy_tile,replace_tile)
     if(pb_cr.ceil)destroyed_tile=set_tile_if(pbx,pby-1,destroy_tile,replace_tile)
     if(pb_cr.rwall)destroyed_tile=set_tile_if(pbx+1,pby,destroy_tile,replace_tile)
     if(pb_cr.lwall)destroyed_tile=set_tile_if(pbx-1,pby,destroy_tile,replace_tile)
    end
    
    if not destroyed_tile and band(pbgt.f,gt_flag_bounce)!=0 then
     if (pb_cr.floor or pb_cr.ceil)pb.vy*=-.6
     if (pb_cr.lwall or pb_cr.rwall)pb.vx*=-.6
     if (abs(pb.vy)<1)pb.vy=pb_cr.floor and -1 or 1
    else
     pbullets_crash(pb)
    end
   else
    local pb_size=pbgt.size
    
    parts_spawn(pbgt.pt,pbx,pby+1-rnd(2),0,0,pbgt.pg,1,1+rnd(pb_size),pbgt.pds,7,pbgt.color)
    
     -- check for bubblegum gun
    if pbgt.color==14 then
     if pb.t<=pbgt.maxt-.5 then
      if pbx+pb_size<player_x or
         pbx-pb_size>player_x+8 or
         pby+pb_size<player_y or
         pby-pb_size>player_y+8 then
      else
       player_vy=-3
       pbullets_crash(pb)
      end
     end
      
     for k,eb in pairs(ebs)do
      if eb.active then
       local s=eb.s/2
       if pbx+pb_size<eb.x-s or
          pbx-pb_size>eb.x+s or
          pby+pb_size<eb.y-s or
          pby-pb_size>eb.y+s then
       else
        eb.active=false
       end
      end
     end
    end
    
    for k,e in pairs(enemies) do
     if e.active then
      if pbx+pb_size<e.x or
         pbx-pb_size>e.x+8 or
         pby+pb_size<e.y or
         pby-pb_size>e.y+8 then
      else
       enemy_damage(e,pbgt.damage)
       
       pbullets_crash(pb)
      end
     end
    end
   end
  end
 end
end

-- player
player_anim_idle=nl("0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2")
player_anim_run=nl("16,16,16,16,17,17,17,17,18,18,18,18")
player_anim_run_up=nl("48,48,48,48,49,49,49,49,50,50,50,50")
player_anim_run_down=nl("32,32,32,32,33,33,33,33,34,34,34,34")
player_anim_shoot={3}
player_anim_shoot_up={35}
player_anim_shoot_down={19}
player_anim_launch,player_anim_jump,player_anim_fall,player_anim_land={51},{52},{53},{51}

player_anim_crouch_idle={54}

player_jump_state_none,
player_jump_state_launch,
player_jump_state_arc,
player_jump_state_fall,
player_jump_state_land=0,1,2,3,4

--
gt_flag_bounce,gt_flag_timeout_explode,gt_flag_no_collision=0x01,0x02,0x04

--
function make_gun(c,s,d,sp,r,mt,grav,ra,pgrav,ptime,pdspeed,dt,rt,flags)
 return {color=c,size=s,damage=d,speed=sp,rate=r,maxt=mt,g=grav,rnda=ra,pg=pgrav,pt=ptime,pds=pdspeed,dtile=dt,rtile=rt,f=flags}
end

-- 
gun_types={
 -- none: vanilla gun (light gray)
 make_gun(unpack(nl("6,1,1,3,.2,1,0,0,0,.1,-.2,-1,-1,0,"))),
 
 -- granade launcher: bounces around, destroys ground blocks (dark green)
 make_gun(unpack(nl("3,3,3,2,.5,1,.1,0,0,.3,-.2,116,-1,3,"))),
 
 -- grapple: launch player in facing direction (brown)
 make_gun(unpack(nl("4,1,.25,3,.1,1,0,0,0,.1,-.01,-1,-1,0,"))),
 
 -- rocket launcher: allows for "double" jump by shooting down, destroys brick blocks (red)
 make_gun(unpack(nl("8,5,3,2,.8,1,0,0,0,.5,-.2,120,-1,0,"))),
 
 -- flame thrower: burns brambles, hovers, short, powerful range (orange) 
 make_gun(unpack(nl("9,4,1,1,.1,.4,0,.04,0,.4,-.2,115,-1,4,"))),
 
 -- freeze gun: (blue), freezes red hot lava blocks
 make_gun(unpack(nl("12,1,1,3,.2,.5,.2,0,.01,.8,-.02,89,88,4,"))),
  
 -- bubble gum: bounce up on projectile
 make_gun(unpack(nl("14,7,3,.4,1.4,3,0,0,0,.2,-.2,-1,-1,0,"))),
 
 -- green goo power
 make_gun(unpack(nl("11,5,3,3,.2,1,0,0,0,.6,-.1,87,-1,4,"))),

}

--
function player_set_anim(anim)
 player_pre_anim=anim
end

-- 
function player_set_running_anim()
 player_set_anim(btn(2) and player_anim_run_up or btn(3) and player_anim_run_down or player_anim_run)
end

--
function player_commit_anim()
 if player_anim!=player_pre_anim then
  player_anim,player_anim_time,player_anim_next=player_pre_anim,0,1
 end
end

--
function player_reset()
 player_x,player_y=player_checkpoint_x,player_checkpoint_y

 player_cx,player_max_vx=0,1
 
 player_vx,player_vy,player_shoot_nx,player_shoot_ny,player_shoot_ox,player_shoot_oy=0,0,0,0,0,0
 player_gravity=.2
 
 player_current_gun,player_crouched_timer,player_grapple_t=1,0,0
 
 player_cr=nil
 
 player_shooting_cooldown,played_damaged,player_gun_disabled=0,0,0
 
 player_air_time=max_air_time
 player_anim_flip=player_x%64>32
 player_set_anim(player_anim_idle)
 player_commit_anim()
 
 player_jump_state=player_jump_state_none
 player_jump_state_timer=10
 
end

--
function player_damage()
 if played_damaged<=0 then
  sfx(11)
  
  player_hits+=1
  played_damaged,player_gun_disabled=1,2
  
  screenshake(6,.8,true)
  screenflash(.05,8)

  player_vx=player_anim_flip and 3 or -3
 end
end

--
function pickup_check(pu,spr,mask)
 if(pu.spr==spr)gun_types_flags=bor(gun_types_flags,mask)save_game()
end

-- 
function pickup_grab_fx(x,y,size)
 for i=1,10 do
  parts_spawn(.4,x,y,cos(i*.1),sin(i*.1),0,.95,size,-.05,7,10)
 end
end

--
function player_pickup_update()
 if(level_boss_arena)return
 
 for k,pu in pairs(pickups) do
  if pu.active then
   local x,y=pu.x,pu.y
   if x+6<player_x or
      x+2>player_x+8 or
      y+6<player_y or
      y+2>player_y+8 then
   else
    pickups_active_count-=1
    pu.active=false
    
    pickup_check(pu,4, 0x2)
    pickup_check(pu,21,0x4)
    pickup_check(pu,5, 0x8)
    pickup_check(pu,6, 0x10)
    pickup_check(pu,20,0x20)
    pickup_check(pu,22,0x40)
    pickup_check(pu,55,0x80)
    
    if pu.type==pickup_type_coin then
     sfx(9)
     pickup_map_save(x,y)set_tile_if(x,y,7,23)
    else
     sfx(15)
    end
    
    pickup_grab_fx(x+4,y+4,pu.type==pickup_type_coin and 2 or 3)
   end
  end
 end
end

-- 
function player_landp(ox,a)
 parts_spawn(.2,player_x+ox,player_y+8,2*cos(a),2*sin(a),.1,.9,1,0,6,6,parts_flags_no_outline)
end

--
function player_land_particles()
 player_landp(2,.417)
 player_landp(4,.333)
 player_landp(4,.167)
 player_landp(6,.083) 
end

--
function player_dampen_vx()
 player_vx*=.8
 if(abs(player_vx)<epsilon)player_vx=0
end

--
function player_update_shooting()
 if player_grapple_t<=0 then 
  player_max_vx=1 
 else
  player_grapple_t-=one_frame
 end
 
 -- shooting
 player_shoot_nx=btn(0) and -1 or btn(1) and 1 or 0
 player_shoot_ny=btn(2) and -1 or btn(3) and 1 or 0
   
 if player_shoot_nx==0 and player_shoot_ny==0 then
  player_shoot_nx=player_anim_flip and -1 or 1
 end
   
 player_shoot_nx,player_shoot_y=normalize(player_shoot_nx,player_shoot_ny)
 local ox=player_anim_flip and 0 or 1
 player_shoot_ox,player_shoot_oy=ox+5*player_shoot_nx,flr(5*player_shoot_ny)
 player_shoot_ox=player_shoot_ox>0 and -flr(-player_shoot_ox) or flr(player_shoot_ox)
 
 local gt=gun_types[player_current_gun]
 
 if shoot_button.time_released<.2 
    and shoot_button.last_time_held>.2
    then
  if gt.color==4 and player_grapple_t<=0 and (btn(0) or btn(1)) then -- grapple
   player_vy,player_grapple_t,player_max_vx,player_gravity=.1,.1,10,0
   player_vx=player_anim_flip and -player_max_vx or player_max_vx
  end
 else
  player_gravity=.2
 end
 
 if shoot_button.time_held>0 then
  
  if gt.color==9 then -- flame thrower
   if(player_air_time>.1)player_vy=.1 player_max_vx=.25
  end
  
  if player_shooting_cooldown<=0 then
   player_shooting_cooldown=gt.rate
   
   if player_gun_disabled>0 then
    -- no shooting while getting damaged (punishment for getting hit)
    sfx(0)
    
    local a=atan2(player_shoot_nx,player_shoot_ny)
    for i=0,4 do
     parts_spawn(.1,player_x+3+player_shoot_ox,player_y+4+player_shoot_oy,2*cos(a+i/8-.25),2*sin(a+i/8-.25),unpack(nl("0,.95,2,-.2,5,13,")))
    end
   else
    if gt.rnda>0 then
     local a=atan2(player_shoot_nx,player_shoot_ny)
     a+=rnd(2*gt.rnda)-gt.rnda
     player_shoot_nx,player_shoot_ny=cos(a),sin(a)
    end
   
    local pox=player_shoot_ox>0 and -flr(-player_shoot_ox/2) or flr(player_shoot_ox/2)
    pbullets_spawn(player_x+3+pox,player_y+4+flr(player_shoot_oy/2),player_shoot_nx,player_shoot_ny)
   
    if gt.color==8 then -- rocket launcher
     if(player_air_time>.1)player_vy=-2.5
    end
   end
  end
 end 
end

--
function player_select_next_gun()
 repeat
  player_current_gun+=1
  if(player_current_gun>#gun_types)player_current_gun=1
 
  gt_mask=shl(0x1,player_current_gun-1)
 
 until band(gun_types_flags,gt_mask)!=0
end

--
function player_select_prev_gun()
 repeat
  player_current_gun-=1
  if(player_current_gun<1)player_current_gun=#gun_types
  
  gt_mask=shl(0x1,player_current_gun-1)
 
 until band(gun_types_flags,gt_mask)!=0
end

--
function player_update()
 if player_crouched_timer>.2 then
  if btnp(1) then
   player_select_next_gun()
  end
  if btnp(0) then
   player_select_prev_gun()
  end 
 end

 if(player_shooting_cooldown>0)player_shooting_cooldown-=one_frame
 if(played_damaged>0)played_damaged-=one_frame
 if(player_gun_disabled>0)player_gun_disabled-=one_frame

 player_cr=collision_checks(player_x,player_y,player_vx,player_vy,1,6,1,8)
 player_x,player_y=player_cr.x,player_cr.y
 
 player_x,player_y=mid(0,player_x,1016),min(player_y,504) -- 8*128-8,4*128-8
 
 if level_boss_arena or game_finished then
  if(player_x<target_cam_x)player_x=target_cam_x
  if(player_x>target_cam_x+56)player_x=target_cam_x+56
  if(player_y<target_cam_y)player_y=target_cam_y
  if(player_y>target_cam_y+56)player_y=target_cam_y+56
 end

 -- checkpoint checks 
 local mx,my=map_coords(player_x+4,player_y+6)
 if mget(mx,my)==56 then
  local omx,omy=map_coords(player_checkpoint_x,player_checkpoint_y)
  if(mget(omx,omy)==57)mset(omx,omy,56)
  
  mset(mx,my,57)
  player_checkpoint_x,player_checkpoint_y=mx*8,my*8
  save_game()
  sfx(16)
  
  pickup_grab_fx(player_checkpoint_x+4,player_checkpoint_y+6,2)
 end
 
 player_anim_next=next_i(player_anim,player_anim_next)
 player_anim_time+=one_frame
 
 if btn(3) and 
    abs(player_vx)<.1 and 
    shoot_button.time_held<=0 and
    player_air_time<.1 then
  player_crouched_timer+=one_frame
 else
  player_crouched_timer=0
 end

 
 if btn(0) and player_grapple_t<=0 then
  player_cx=-1
  
  if player_crouched_timer>.2 or shoot_button.time_held>.2 and player_air_time<.1 then
   player_dampen_vx()
  else
   player_vx=max(-player_max_vx,player_vx-.2)
  end
 elseif btn(1) and player_grapple_t<=0 then
  player_cx=1
  
  if player_crouched_timer>.2 or shoot_button.time_held>.2 and player_air_time<.1 then
   player_dampen_vx()
  else
   player_vx=min(player_max_vx,player_vx+.2)
  end
 else
  player_cx=0
  player_dampen_vx()
 end

 if not player_cr.floor or player_gravity<=0 then
  player_vy+=player_gravity

  player_air_time+=one_frame
  if player_air_time>max_air_time then
   player_air_time=max_air_time
  end
 else
  if player_air_time>.1 then
   player_land_particles()
  end
  
  player_vy,player_air_time=0,0
 end

 player_pickup_update()
 
 player_update_shooting()
 
 player_jump_state_timer+=one_frame
 if player_jump_state==player_jump_state_none then
  if player_air_time>.1 then
   player_jump_state=player_jump_state_fall
   player_jump_state_timer=0
  end
  
  if player_air_time<.05 and jump_button.time_since_press<.2 then
   sfx(12)
   jump_button:button_consume()
   player_air_time=max_air_time
   player_vy=0
   player_jump_state=player_jump_state_launch
   player_jump_state_timer=0
  end
 elseif player_jump_state==player_jump_state_launch then
  player_vy=0
  if player_jump_state_timer>.05 then
   -- finished launching
   if(player_vy>-1.5)player_vy=-1.5
   player_gravity=0   
   player_jump_state=player_jump_state_arc
   player_jump_state_timer=0
  end
 elseif player_jump_state==player_jump_state_arc then
  if btn(5) and player_jump_state_timer<.1 then
   if(player_vy>-1.5)player_vy=-1.5
   player_gravity=0
  else
   player_gravity=.2
   
   if player_vy>=0 then
    player_jump_state=player_jump_state_fall
    player_jump_state_timer=0
   end
  end
 elseif player_jump_state==player_jump_state_fall then
   if player_cr.floor then
    sfx(10)
    player_jump_state=player_jump_state_land
    player_jump_state_timer=0
   end
 elseif player_jump_state==player_jump_state_land then
  if player_jump_state_timer<.05 then
   player_vy=0
  else
   player_jump_state=player_jump_state_none
   player_jump_state_timer=0
  end
 end
  
 -- anim flip state
 if player_crouched_timer<.2 and player_cx<0 then
  player_anim_flip=true
  player_set_running_anim()
 elseif player_crouched_timer<.2 and player_cx>0 then
  player_anim_flip=false
  player_set_running_anim()
 elseif btn(2) then
  player_set_anim(player_anim_shoot_up)
 elseif btn(3) then
  -- check if the player is not doing anything else but press down.
  if player_crouched_timer>.2 then
   player_set_anim(player_anim_crouch_idle)
  else
   player_set_anim(player_anim_shoot_down)
  end
 else
  player_set_anim(player_anim_idle)
 end

 -- anim state handling
 if abs(player_vx)<.1 and shoot_button.time_held>0 then
  if btn(2) then
   player_set_anim(player_anim_shoot_up)
  elseif btn(3) then
   player_set_anim(player_anim_shoot_down)
  else
   player_set_anim(player_anim_shoot)
  end
 elseif player_jump_pressed then
   player_set_anim(player_anim_launch)
 elseif player_jump_state==player_jump_state_launch then
  player_set_anim(player_anim_launch)
 elseif player_jump_state==player_jump_state_arc then
  player_set_anim(player_anim_jump)
 elseif player_jump_state==player_jump_state_fall then
  player_set_anim(player_anim_fall) 
 elseif player_jump_state==player_jump_state_land then
  player_set_anim(player_anim_land)
 end

 player_commit_anim()
 
 -- check if the level damages the player
 if player_cr.floor then
  local mx,my=map_coords(player_x+4,player_y+9)
  if(mget(mx,my)==89)player_damage() -- standing on lava tile hurts the player
 end
end

--
function pdraw(ox,oy)
 spr(player_anim[player_anim_next],player_x+ox,player_y+oy,1,1,player_anim_flip)
end

--
function draw_hud()
 if show_hud_timer>0 then
  local by=cam_y+58
  local y=(show_hud_timer>2.9) and by+20*(show_hud_timer-2.9) or (show_hud_timer>1) and by or by+10*(1-show_hud_timer)
  if(player_score==128)pal(7,10)
  print_outline(time_to_text(game_time),cam_x+1,y,7,1,align_l)
  print_outline(player_score.."/128",cam_x+64,y,7,1,align_r)
  pal(15,1)
  spr(36,cam_x,y-7)
  spr(7,cam_x+57,y-7)
  pal()
 end
end

--
function player_draw()
 if(played_damaged>0 and played_damaged%.2>.1)return
 
 for i=1,15 do
  pal(i,0)
 end 
 
 if(player_air_time<.1)clip(player_x-1-cam_x,player_y-1-cam_y,10,9)
 pdraw( 1, 0)
 pdraw( 1, 1)
 pdraw(-1, 0)
 pdraw(-1,-1)
 pdraw( 0, 1)
 pdraw(-1, 1)
 pdraw( 0,-1)
 pdraw( 1,-1)
 clip()
 
 pal()
 
 local gt=gun_types[player_current_gun]
 
 local px,py=player_x+3+player_shoot_ox,player_y+4+player_shoot_oy
 
 rect(px-1,py-1,px+1,py+1,0)
 if(player_shooting_cooldown>gt.rate-.1)circfill(px,py,2,7)
 
 local gd=player_gun_disabled>0 and player_gun_disabled%.1>.05
 
 pal(12,gd and 5 or gt.color)

 pset(px,py,12)
 pdraw(0,0)
 pal()
end

-- enemy bullets
ebs={}
ebs_next,ebs_blink,ebs_blink_on=1,0,true

for i=1,100 do
 add(ebs,{})
end

function ebs_reset()
 for k,eb in pairs(ebs)do
  eb.active=false
 end
end

function ebs_make_bullets(x,y,s,speed,count,inc_a,start_a,lifetime)
 if(x<target_cam_x or x>target_cam_x+63 or y<target_cam_y or y>target_cam_y+63)return
 
 sfx(13)
 
 local ia=start_a
 for i=1,count do
  local eb=ebs[ebs_next]
  eb.x,eb.y,eb.s=x,y,s
  eb.velx,eb.vely=speed*cos(ia),speed*sin(ia)
  eb.active,eb.t=true,lifetime or 4
  ebs_next=next_i(ebs,ebs_next)
  
  ia-=inc_a
 end 
end

--
function ebs_check_player(eb)
 local s=eb.s/2
 if player_x+6<eb.x-s or
    player_x+2>eb.x+s or
    player_y+6<eb.y-s or
    player_y+2>eb.y+s then
 else
  eb.active=false
  player_damage()
 end
end

--
function ebs_update()
 if ebs_blink<=0 then
  ebs_blink=.05
  ebs_blink_on=not ebs_blink_on
 else
  ebs_blink-=one_frame
 end

 for k,eb in pairs(ebs)do
  if eb.active then
   if eb.t<=0 then
    eb.active=false
   elseif eb.y<-8 or eb.x<-8 or eb.y>526 or eb.x>1038 then
    eb.active=false
   else
    eb.t-=one_frame
    eb.y+=eb.vely
    eb.x+=eb.velx
    
    local s=eb.s
    if ebs_blink%.05>.03 then
     parts_spawn(.5,eb.x+s/2-rnd(s),eb.y+s/2-rnd(s),0,0,0,0,s,-.05*s,8,10,parts_flags_blink)
    end
    
    ebs_check_player(eb)
   end
  end
 end
end

-- enemies
enemy_types={}

--
function enemy_shooter_init(e,size)
 e.bullet_size,e.bullet_timer=size,0
end

--
function enemy_shooter_update(e,wait,speed,count,angle,check_flip,lifetime)
 e.shoot_bullet_time=wait
 if e.bullet_timer<e.shoot_bullet_time then
  e.bullet_timer+=one_frame
 end
 
 if e.bullet_timer>=e.shoot_bullet_time then
   e.bullet_timer=0
   
   if(check_flip and e.anim_flip)angle+=.5
    if angle<0 then
     angle=atan2(normalize(player_x-e.x,player_y-e.y))
    end
    
    ebs_make_bullets(e.x+4,e.y+4,e.bullet_size,speed,count,1/count,angle,lifetime)
 end
end

--
function enemy_spawner_init(e,time,spawn_type)
 e.spawn_enemy_time,e.spawn_enemy_max_time,e.spawn_timer,e.spawn_type,e.children=time,time,0,spawn_type,0
end 

--
function enemy_spawner_update(e)
 if e.spawn_timer<e.spawn_enemy_time then
  e.spawn_timer+=one_frame
   
  if e.spawn_timer>=e.spawn_enemy_time then
   e.spawn_timer=0
   e.spawn_enemy_time=e.spawn_enemy_max_time+rnd()
   
   local x,y=e.x,e.y
   if(x<target_cam_x or x>target_cam_x+63 or y<target_cam_y or y>target_cam_y+63)return
   
   if e.children<10 then
    e.children+=1
    sfx(18)
    enemy_spawn(e.spawn_type,x,y,0,0,e)
    for i=1,10 do
     parts_spawn(.2,x+4,y+6,1.5*cos(.1*i),1.5*sin(.1*i),unpack(nl("0,.95,3,-.2,11,8,")))
    end
   end
  end
 end
end 

--
function enemy_ledge_behavior_turn(e)
 if e.x+4>e.last_ledge_x then
  e.vx=e.type.vel_x
 else
  e.vx=-e.type.vel_x
 end
end

-- demon flyer
enemy_types[8]=
{
 idle_anim=nl("8,8,8,8,8,8,8,8,8,8,9,9,9,9,9,9,9,9,9,9,"),
 vel_x=.5,
 health=4,
 g=0,
}

-- demon flyer mini-boss
enemy_types[9]=
{
 idle_anim=nl("8,8,8,8,8,8,8,8,8,8,9,9,9,9,9,9,9,9,9,9,"),
 vel_x=.2,
 health=20,
 g=0,

 init=function(e)
  enemy_shooter_init(e,4)
 end,

 update=function(e) 
  enemy_shooter_update(e,3,.3,1,-1)
 end,
}

-- demon dude
enemy_types[24]=
{
 idle_anim=nl("24,24,24,24,24,24,25,25,25,25,25,25,"),
 vel_x=.5,
 health=4,
}

-- demon dude self-destruct
enemy_types[25]=
{
 idle_anim=nl("24,24,24,24,24,24,25,25,25,25,25,25,"),
 vel_x=.5,
 health=2,
 
 init=function(e)
  enemy_shooter_init(e,3)
  e.max_t=.5+rnd(2.5)
 end,
 
 update=function(e)
  if e.t>e.max_t then
   enemy_shooter_update(e,.01,.5,10,-1,false,.6)
   enemy_kill(e)
  end
 end,
}

-- alien dude no stop at ledges
enemy_types[26]=
{
 idle_anim=nl("26,26,26,26,26,26,26,26,26,26,27,27,27,27,27,27,27,27,27,27,"),
 vel_x=.15,
 health=4,
}

-- floating alien dude stop at ledges
enemy_types[10]=
{
 idle_anim=nl("10,10,10,10,10,10,10,10,10,10,11,11,11,11,11,11,11,11,11,11,"),
 vel_x=.05,
 health=4,

 ledge_behavior=enemy_ledge_behavior_turn,
}

--
function create_spread_shooter_enemy(anim,vx,h,bsize,bwait,bspeed,bcount,bangle,bangle_inc,check_flip)
 return
 {
  idle_anim=anim,
  vel_x=vx,
  health=h,

  init=function(e)
   e.a=bangle
   enemy_shooter_init(e,bsize)
   e.jump_cooldown=0
  end,

  update=function(e)
   e.jump_cooldown-=one_frame
   
   e.a+=bangle_inc
   enemy_shooter_update(e,bwait,bspeed,bcount,e.a,check_flip)
  end,
  
  ledge_behavior=enemy_ledge_behavior_turn,
 }

end

-- shooter horned dude
enemy_types[28]=create_spread_shooter_enemy(nl("28,28,28,28,28,28,28,28,28,28,29,29,29,29,29,29,29,29,29,29,"),unpack(nl(".1,6,3,4,.5,1,0,0,1,")))

-- spiral shooter roller
enemy_types[58]=create_spread_shooter_enemy(nl("58,58,58,58,58,58,59,59,59,59,59,59,"),unpack(nl(".05,10,3,.2,.5,1,0,.01,")))

-- 8-way shooter horned roller
enemy_types[60]=create_spread_shooter_enemy(nl("60,60,60,60,60,60,61,61,61,61,61,61,"),unpack(nl(".05,14,3,1,.5,8,0,0,")))

-- miniboss dude #1 - the rabbit
enemy_types[14]=create_spread_shooter_enemy(nl("14,14,14,14,14,14,15,15,15,15,15,15,"),unpack(nl(".5,60,5,1.5,.4,1,-1,0,")))

-- miniboss dude #2 - the ponytail
enemy_types[30]=create_spread_shooter_enemy(nl("30,30,30,30,30,30,31,31,31,31,31,31,"),unpack(nl(".5,60,3,.7,.5,1,-1,0,")))

-- miniboss dude #3 - the skull jr
enemy_types[46]=create_spread_shooter_enemy(nl("46,46,46,46,46,46,46,46,46,46,47,47,47,47,47,47,47,47,47,47,"),unpack(nl(".1,60,3,1,.4,4,0,.005,")))

-- miniboss dude #4 - black death
enemy_types[62]=create_spread_shooter_enemy(nl("62,62,62,62,62,62,62,62,63,63,63,63,63,63,63,63,"),unpack(nl(".2,60,3,2,.5,10,0,0,")))


--
function create_spawner_enemy(anim,h,time,spawn_type)
 return 
 {
 idle_anim=anim,
 vel_x=0,
 health=h,
 
  init=function(e)
   enemy_spawner_init(e,time,spawn_type)
  end,

  update=enemy_spawner_update,
 }
end

-- static spawner head
enemy_types[37]=create_spawner_enemy(nl("37,37,37,37,37,37,37,37,37,37,38,38,38,38,38,38,38,38,38,38,"),20,2,26)

-- static spawner head boss
enemy_types[38]=create_spawner_enemy(nl("37,37,37,37,37,37,37,37,37,37,38,38,38,38,38,38,38,38,38,38,"),30,2,26)

-- static spawner demonhead
enemy_types[40]=create_spawner_enemy(nl("40,40,40,40,40,40,40,40,40,40,41,41,41,41,41,41,41,41,41,41,"),20,1,25)

-- static spawner demonhead boss
enemy_types[41]=create_spawner_enemy(nl("40,40,40,40,40,40,40,40,40,40,41,41,41,41,41,41,41,41,41,41,"),60,1,25)

-- static alien shooter
enemy_types[42]=create_spread_shooter_enemy(nl("42,42,42,42,42,42,42,42,42,42,43,43,43,43,43,43,43,43,43,43,"),unpack(nl("0,4,3,2,1,1,0,0,1,")))

-- static aimed shooter horned head
enemy_types[44]=create_spread_shooter_enemy(nl("44,44,44,44,44,44,44,44,44,44,45,45,45,45,45,45,45,45,45,45,"),unpack(nl("0,6,3,2,.5,1,-1,0,")))

-- static 3-way shooter horned head
enemy_types[12]=create_spread_shooter_enemy(nl("12,12,12,12,12,12,12,12,12,12,13,13,13,13,13,13,13,13,13,13,"),unpack(nl("0,8,3,1,.5,3,0,.005,")))

-- static horned head mini-bosses
enemy_types[45]=create_spread_shooter_enemy(nl("44,44,44,44,44,44,44,44,44,44,45,45,45,45,45,45,45,45,45,45,"),unpack(nl("0,20,4,2,.5,1,-1,0,")))

-- skulldude final boss
enemy_types[39]=
{
 idle_anim={39},
 vel_x=.05,
 vel_y=.03,
 health=100,
 g=0,
 ignorecollision=true,

 init=function(e)
  e.a=0
  enemy_shooter_init(e,4)
 end,

 update=function(e) 
  e.a+=.01
  local bspeed=.4+.4*(1-e.health/e.type.health)
  local bwait=.5+e.health/e.type.health
  
  if e.a%.02>=.01 then
   enemy_shooter_update(e,bwait,bspeed,1,-1)
  else
   enemy_shooter_update(e,bwait,bspeed,5,e.a)
  end
  
  parts_spawn(.2+rnd(.4),e.x+4,e.y+4,-.2+rnd(.4),-.5-rnd(),unpack(nl("0,.95,6,-.2,8,0,")))
 end,
}

--
enemies={}

for i=1,100 do
 add(enemies,{active=false})
end

--
function enemy_spawn(spr,x,y,mx,my,pe)
 
 -- check if we already have an active enemy with those coords.
 if not pe then
  for k,e in pairs(enemies) do
   if(e.active and mx==e.mx and my==e.my)return
  end
 end
 
 local e,i=find_next_i(enemies,enemies_next,enemies_active_count)
 
 if e then
  enemies_next=i
  
  enemies_active_count+=1
  e.active=true
  e.pe=pe
  e.type_i,e.type=spr,enemy_types[spr]
  e.anim,e.health=e.type.idle_anim,e.type.health
  e.x,e.y,e.mx,e.my=x,y,mx,my
  e.vy,e.vx=e.type.vel_y or 0,(rnd()>.5 and 1 or -1)*e.type.vel_x
  e.anim_flip,e.anim_index,e.t=e.type.vel_x<0,1,0
  e.boss,e.damaged_timer=level_boss_arena,0
 
  if(e.type.init)e.type.init(e)
 end
end

--
function enemy_disable(e)
 e.active=false
 enemies_active_count-=1
 
 if(e.pe)e.pe.children-=1
end

--
function enemy_kill(e)
 enemy_disable(e)
 
 if(e.type_i==39)reload()load_game()
 
 if(e.mx!=0 or e.my!=0)mset(e.mx,e.my,64)
 
 
 if level_boss_arena then
  level_boss_arena=false
  for k,ae in pairs(enemies) do
   if(ae.active and ae.boss)level_boss_arena=true
  end
  
  if not level_boss_arena then
   music(0)
  end
 end

 sfx(14)
 screenshake(6,.7)
 screenflash(.025,7) 
end

--
function enemy_damage(e,damage)
 if(e.t<.2)return
 
 e.health-=damage
 e.damaged_timer=.3
 if e.health<=0 then
  
  for i=1,10 do
   parts_spawn(.3,e.x+4,e.y+4,1.5*cos(.1*i),1.5*sin(.1*i),unpack(nl("0,.95,3,-.2,8,9,")))
  end
  
  enemy_kill(e)
 else
  sfx(17)
 end
end

--
function enemy_draw(e,ox,oy)
 if(e.type.g==0)oy+=2*sin(2*e.t)
 spr(e.anim[e.anim_index],e.x+ox,e.y+oy,1,1,e.anim_flip)
end

--
function enemy_check_player(e)
 if player_x+6<e.x or
    player_x+2>e.x+8 or
    player_y+6<e.y or
    player_y+2>e.y+8 then
 else
  player_damage()
 end
end

--
function enemies_spawn_check()
 level_boss_arena=false
 local found_enemies=false

 local start_x,end_x,inc_x=mirror_mode_bool and target_cam_x+63 or target_cam_x,mirror_mode_bool and target_cam_x or target_cam_x+63,mirror_mode_bool and -8 or 8
 
 for x=start_x,end_x,inc_x do
  for y=target_cam_y,target_cam_y+63,8 do
   local mx,my=map_coords(x,y)
   
   local tile_spr=mget(mx,my)
   
   if(tile_spr==65)level_boss_arena=true
   
   if fget(tile_spr,7) then
    enemy_spawn(tile_spr,mx*8,my*8,mx,my)
    found_enemies=true
   elseif fget(tile_spr,6) then
    pickups_spawn(mx*8,my*8,tile_spr)
   end
   
  end
 end
 
 if not found_enemies then
  level_boss_arena=false
 else
  if(level_boss_arena)music(40)
 end
end

--
function enemies_reset()
 for k,e in pairs(enemies) do
  e.active=false
 end
 
 enemies_next,enemies_active_count=1,0
end

--
function enemies_update()
 for k,e in pairs(enemies) do
  if e.active then
   e.t+=one_frame
   
   local damaged=(e.damaged_timer>0)
   
   if(damaged)e.damaged_timer-=one_frame
   
   if not damaged then
    e.anim_index=next_i(e.anim,e.anim_index)
    e.x+=e.vx
    
    if e.type.ignorecollision or not s_floor(e.x+4,e.y+8) then
     e.vy+=(e.type.g or .05)
     e.y+=e.vy
    else
     e.y=flr((e.y+1)/8)*8
    end
    
    local x,y=e.x,e.y
    
    if not e.type.ignorecollision then
     if e.vx<0 then
      if s_lwall(x-1,y+4) or x<=-1 then
       e.vx=-e.vx
      end
     elseif e.vx>0 then
      if s_rwall(x+9,y+4) or x+8>=1024 then
       e.vx=-e.vx
      end
     end
    end
    
    if e.type.ledge_behavior then
     if s_floor(x+4,y+9) then
      if e.vx>0 and not s_floor(x+7,y+9) then
       e.last_ledge_x=x+7
       e.type.ledge_behavior(e)
      elseif e.vx<0 and not s_floor(x-1,y+9) then
       e.last_ledge_x=x-1
       e.type.ledge_behavior(e)
      end
     end
    end
    
    if e.boss then
     if (x<target_cam_x-1)e.vx=abs(e.vx)
     if (x>target_cam_x+56)e.vx=-abs(e.vx)
     if (y<target_cam_y-1)e.vy=abs(e.vy)
     if (y>target_cam_y+56)e.vy=-abs(e.vy)
    elseif (x<target_cam_x or x>target_cam_x+63 or y<target_cam_y or y>target_cam_y+63) then
     if e.t>60 then
      enemy_disable(e)
     end
    end
   
    e.anim_flip=(e.vx==0 and player_x+4<x+4 or e.vx<0)
   end
   
   enemy_check_player(e)
   
   if(e.type.update)e.type.update(e)
  end
 end
end

--
function enemies_draw()
 
 for k,e in pairs(enemies) do
  if e.active then
   for i=1,15 do
    pal(i,e.damaged_timer>.2 and 10 or 0)
   end
   
   local x,y=e.x,e.y
   
   if(not e.type.ignorecollision and s_floor(x+4,y+9))clip(x-1-cam_x,y-1-cam_y,10,9)
   enemy_draw(e, 1, 0)
   enemy_draw(e,-1, 0)
   enemy_draw(e, 0, 1)
   enemy_draw(e, 0,-1)
   enemy_draw(e, 1, 1)
   enemy_draw(e,-1,-1)
   enemy_draw(e,-1, 1)
   enemy_draw(e, 1,-1)
   clip()
   
   if e.damaged_timer>.2 then
    local f=nl("1,2,3,4,5,6,7,8,9,10,11,12,13,14")
    local t=nl("8,8,9,9,8,9,8,10,8,8,8,10,9,8")
    for i=1,#f do
     pal(f[i],t[i])
    end
   else
    pal()
   end
  
   enemy_draw(e,0,0)
   
   if e.damaged_timer>0 then
    local hs=e.health/e.type.health
    line(x+1,y+8,x+6,y+8,0)
    line(x+1,y+8,x-flr(-6*hs),y+8,hs>.25 and 10 or 8)
   end
  end
 end

 pal()
end

--
pickups={}

pickup_type_gun,pickup_type_coin=1,2

for i=1,150 do
 add(pickups,{active=false})
end

--
function pickups_reset()
 for k,pu in pairs(pickups) do
  pu.active=false
 end

 pickups_next,pickups_active_count=1,0
end


pickup_save_masks={0,0,0,0,0,0,0,0}

--
function pickup_map_ids(x,y)
 local rx,ry=flr(round(x)/64),flr(round(y)/64)
 local pickup_save_index=ry+1
 local pickup_mask=shl(0x1,rx)
 return pickup_save_index,pickup_mask
end

--
function pickup_map_save(x,y)
 local pickup_save_index,pickup_mask=pickup_map_ids(x,y)
 pickup_save_masks[pickup_save_index]=bor(pickup_save_masks[pickup_save_index],pickup_mask)
 player_score+=1
 save_game()
end

--
function pickup_map_check(x,y)
 local pickup_save_index,pickup_mask=pickup_map_ids(x,y)
 return band(pickup_save_masks[pickup_save_index],pickup_mask)!=0
end

--
function pickups_spawn(x,y,spr)
 if spr==7 then
  pu_type=pickup_type_coin
  
  if pickup_map_check(x,y) then
   set_tile_if(x,y,7,23)
   return
  end
 else
  pu_type=pickup_type_gun
  
  if(spr==4  and band(gun_types_flags,0x2)!=0)return
  if(spr==21 and band(gun_types_flags,0x4)!=0)return
  if(spr==5  and band(gun_types_flags,0x8)!=0)return
  if(spr==6  and band(gun_types_flags,0x10)!=0)return
  if(spr==20 and band(gun_types_flags,0x20)!=0)return
  if(spr==22 and band(gun_types_flags,0x40)!=0)return
  if(spr==55 and band(gun_types_flags,0x80)!=0)return

 end
 
    
 for k,pu in pairs(pickups) do
  if(pu.active and pu.x==x and pu.y==y)return
 end
    
 local pu,i=find_next_i(pickups,pickups_next,pickups_active_count)

 if pu then
  pickups_next=i
  pickups_active_count+=1
  
  pu.active,pu.t,pu.x,pu.y,pu.spr,pu.type=true,0,x,y,spr,pu_type
 end
end

--
function pickups_update()
 for k,pu in pairs(pickups) do
  if(pu.active)pu.t+=one_frame
 end
end

--
function pickups_draw()
 pal(15,0)
 if(level_boss_arena)pal(9,5)pal(10,6)
 for k,pu in pairs(pickups) do
  if(pu.active)spr(pu.spr,pu.x,pu.y+2*sin(pu.t))
 end
 pal()
end

-- level

show_hud_timer=0

--
function level_restart()
 player_reset()
 ebs_reset()
 pickups_reset()
 enemies_reset()
 
 music(0)
end

--
function level_update()
 if(show_hud_timer>0)show_hud_timer-=one_frame
 if(title_active)show_hud_timer=2.9
end

--
function level_draw()
 local map_y=flr(cam_y/8)
 
 map(0,0,0,0,128,64,0x10)
 
 if level_boss_arena then
  fillp(game_time%.3>.2 and 0xcc33 or game_time%.3>.1 and 0x6996 or 0x33cc)
  rect(cam_x,cam_y,cam_x+63,cam_y+63,8)
  fillp()
 end 
end

--
fe_fade_in,fe_time=3,0
title_active=true

--
function title_update()
 fe_time+=one_frame

 if title_active then
  if(btn()!=0)title_active=false
 else
  fe_fade_in=max(0,fe_fade_in-one_frame)
 end
end

--
function title_draw()
 local oy=fe_fade_in<1 and 30*(1-fe_fade_in*fe_fade_in) or 0
 if(player_score==128)pal(7,10)

 print_outline("run-gun-bot",32,32+2*sin(fe_time*2)-2*oy,7,1)

 print_outline("guerragames",32,2-oy,7,1)
 print_outline("2018",32,8-oy,7,1)
 pal()
end

--
game_finished,game_finished_timer=false,0

--
function game_finished_update()
  show_hud_timer=2.9
  game_finished_timer+=one_frame

  parts_update()
  
  if game_finished_timer%.5>.45 then
   local x,y=cam_x+rnd(64),cam_y+rnd(64)
   for i=0,20 do
    local a,r=rnd(),1+rnd(3)
    parts_spawn(2,x,y,r*cos(a),r*sin(a),.1,.97,4,-.1,mirror_mode_bool and 14 or 11,mirror_mode_bool and 8 or 3,parts_flags_blink)
   end
  end  
end

--
function game_finished_draw()
 draw_hud()
 parts_draw()
 player_draw()
 
 if(player_score==128)pal(7,10)
 local blink=(game_finished_timer%.2>.1)
 local c,bc=blink and 0 or 10,blink and 7 or 8
 
 local a=min(.25,game_finished_timer/2)
 local y=cam_y-24-26*sin(a)

 if(mirror_mode_bool)pal(11,14)pal(3,8)
 local xoffset=mirror_mode_bool and 16 or 40
 spr(blink and 126 or 127,cam_x+xoffset,cam_y+40,1,1,mirror_mode_bool)
 pal()
 
 local txt=mirror_mode_bool and "slimette!" or "your bro!"
 
 print_outline("congratulations",cam_x+32,y,c,bc)
 print_outline("run-gun-bot!",cam_x+32,y+6,c,bc)
 print_outline("you rescued",cam_x+32,y+16,c,bc)
 print_outline(txt,cam_x+32,y+22,c,bc)
 
 print_outline("hit "..player_hits.." times",cam_x+32,y+32,c,bc)
end

--
function game_view_start()
 jump_button:button_init()
 shoot_button:button_init()

 player_reset()
 level_restart()
 cam_reset()
 
end

--
function game_view_update()
 if(not game_finished and not title_active)game_time+=one_frame
 
 update_screeneffects()
 
 jump_button:button_update()
 shoot_button:button_update()
 
 if game_finished then
  player_update()
  pbullets_update()
  game_finished_update()
  return
 end
 
 level_update()
 
 local game_paused=player_crouched_timer>.2
 
 if not game_paused then
  enemies_update()
  ebs_update()
  pickups_update()
 end
 
 player_update()
 cam_update()
 
 if not game_paused then
  pbullets_update()
  parts_update()
 end
end

--
function game_view_draw()
 
 if screen_flash_timer>0 then
  cls(screen_flash_color)
  return
 end
 
 cls()
 camera(cam_x+cam_shake_x,cam_y+cam_shake_y)
 
 if(game_finished)game_finished_draw()return
 
 level_draw()
 pickups_draw()
 draw_hud()
 
 parts_draw()
 
 enemies_draw()
 player_draw()
 
 camera(0,0)
end

--
function _init()
 load_game()
 
 menuitem(1,"\145 next gun",player_select_next_gun)
 menuitem(2,"\139 prev gun",player_select_prev_gun)
 menuitem(3,"reset game!?",reset_game)
 menuitem(4,"reset game+!?",reset_game_mirrored)

 game_view_start()
end

rotating_screen_timer=0

--
function _update60()
 game_view_update() 
 title_update()
end

--
function _draw()
 game_view_draw()
 title_draw()
 
 screenshake_corruption_draw()
end
