--infinite birbs
--by googroker

function _init()
 seed=rnd()--replace rnd() with seed
 newbird(seed)
end

--returns the distance between
--the 2 points
function distance(x1,y1,x2,y2)
	return sqrt(((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1)))
end

--draws a thicc line :weary:
function thickline(x1,y1,x2,y2,r,col)
	dx = x2-x1
	dy = y2-y1
	for i=0,1,1/distance(x1,y1,x2,y2) do
		circfill((dx*i)+x1,(dy*i)+y1,r,col)
 end
end

function newcol()
 return ceil(rnd(0xf))+(ceil(rnd(0xf))*16)
end

function newbird(nseed)
 cl=rnd(24)+8
 for i=0,32,1 do
  poke(0x3200+i,0)
 end
 if nseed!=null then
  srand(nseed)
 else
  seed=rnd()
  srand(seed)
 end
 s=0
 call=0
 off1a=rnd()+1
 off2a=rnd()+1
 off1b=rnd(6)+1
 off2b=rnd(6)+1
 offx=rnd(24)+32
 offy=rnd(24)+32
 col={newcol(),newcol(),newcol()}
 for i=1,3 do
  if col[i]%16==0 then
   col[i]+=1
  end
  if flr(col[i]/16)==0 then
   col[i]+=16
  end
 end
 f1=flr(rnd(0b1111111111111111))
 f2=flr(rnd(0b1111111111111111))
 for i=0,cl,1 do
  poke(0x3200+i,rnd(64))
 end
end

function _update()
 if btnp(4) then
  call=1
  s=cl
  sfx(0)
 end
 s-=1
 if s<0 then
  call=0
 end
 
 if btnp(5) then
  newbird()
 end
end

function _draw()
 cls()
 cp=peek(0x3201+stat(20))/16
 --memcpy(0x6000,0x3200,33)
 b1=sin(t()*(1/off1a))*off1b
 b2=sin(t()*(1/off1a))*off2b
 fillp(f2)
 thickline(60,64+b1,56,104-off1a*8,off1a*1.5,col[2])
 thickline(68,64+b1,72,104-off1a*8,off1a*1.5,col[2])
 fillp(f1)
 palt(0,true)
 circfill(64,64+b1,off1a*8,col[1])
 fillp(f2)
 thickline(offx+cp,offy+b2+cp,60,60+b1,off2a*2,col[2])
 spr(1+call,offx+cp-off2a-8,offy+b2+cp)
 circfill(offx+cp,offy+b2+cp,off2a*4,col[2])
 palt(0,nil)
 fillp()
 circfill(offx+cp,offy+b2+cp,off2a*2,col[3])
 circfill(offx+cp,offy+b2+cp,1,col[3]+2%15)
 --print(s,0,64,5)
 --print(cl,0,70,5)
 --print(flr(col[1]/16),0,80,6)
 --print(col[1]%16,0,86,6)
 --print(stat(1),0,92,6)
 print("seed:"..seed,1,1,5)
end