--space limit
--by nusan

timer = 0
time = 0.0
time3 = 0.0
camtrans = 0.0

tele_cam = true

sumverts = 0
sumtris = 0

camstyle = 1
manrx = 0
manry = 0

current_scene = 1
prev_scene = current_scene
launch_started = false
rocket_speed_y = 0.0
rocket_height = 0.0
explode = false

function newver (in_x,in_y,in_z)
	local set = {}
	set.x = in_x
	set.y = in_y
	set.z = in_z
  return set
end

function newtri (in_v1,in_v2,in_v3,in_c)
	local set = {}
	set.v1 = in_v1
	set.v2 = in_v2
	set.v3 = in_v3
	set.c = in_c
	set.avg = 0.0
  return set
end

function newent (loc)
	local set = {}
	set.ver={}
	set.tri={}
	set.loc=loc
	set.hidden = false
	set.sort = true
	set.avg = 0.0
  return set
end

entities = {}
groundent = {}

rocket = nil
launchpad = nil
rocklaunch = nil
planet = nil
station = nil
road = nil

stars = {}
burn = {}
burn_dir = {}

function v_sub(v1,v2)
	local vf = clone(v1)
	vf.x -= v2.x
	vf.y -= v2.y
	vf.z -= v2.z
	return vf
end

function v_dist2d(p0,p1)
	local dx = (p1.x-p0.x)
	local dy = (p1.y-p0.y)
	return sqrt(dx*dx+dy*dy+0.001)
end

function v_dist2dbig(p0,p1)
	local dx = (p1.x-p0.x)*0.1
	local dy = (p1.y-p0.y)*0.1
	return sqrt(dx*dx+dy*dy+0.001)*10.0
end

function v_len(p0)
	return sqrt(p0.x*p0.x + p0.y*p0.y + p0.z*p0.z+0.001)
end

function v_mulf(v1,f)
	local vf = clone(v1)
	vf.x *= f
	vf.y *= f
	vf.z *= f
	return vf
end

function v_add(v1,v2)
	local vf = clone(v1)
	vf.x += v2.x
	vf.y += v2.y
	vf.z += v2.z
	return vf
end

function v_print(v)
	return flr(v.x).."|"..flr(v.y).."|"..flr(v.z)
end

function v_dot(v1,v2)
	return (v1.x*v2.x + v1.y*v2.y + v1.z*v2.z)
end

function v_cross(v1,v2)
	local vf = clone(v1)
	vf.x = (v1.y*v2.z - v1.z*v2.y)
	vf.y = (v1.z*v2.x - v1.x*v2.z)
	vf.z = (v1.x*v2.y - v1.y*v2.x)
	return vf
end

function v_norm(v1)
	local vf = clone(v1)
	local len = 1.0/sqrt(vf.x*vf.x+vf.y*vf.y+vf.z*vf.z+0.0001)
	vf.x = vf.x*len
	vf.y = vf.y*len
	vf.z = vf.z*len
	return vf
end

campos = newver(0,0,-1)
camdir = newver(0,0,1)
camtar = newver(0,0,0) 
camup = newver(0,1,0)
camrottar = newver(0,0,0) 
camright = newver(1,0,0)

function clone(t)
  local t2 = {}
  for k,v in pairs(t) do
    t2[k] = v
  end
  return t2
end

function lerp(a,b,alpha)
	return a*(1.0-alpha)+b*alpha
end

function clip(v)
	return max(-1,min(128,v))
end

function wtri(x1,y1,x2,y2,x3,y3,c)
	line(x1,y1,x2,y2,c)
	line(x2,y2,x3,y3,c)	
	line(x3,y3,x1,y1,c)
end

function dtri(x1,y1,x2,y2,x3,y3,c)

	if(y2<y1) then
		if(y3<y2) then
			local tmp = y1
			y1 = y3
			y3 = tmp
			tmp = x1
			x1 = x3
			x3 = tmp
		else
			local tmp = y1
			y1 = y2
			y2 = tmp
			tmp = x1
			x1 = x2
			x2 = tmp
		end
	else
		if(y3<y1) then
			local tmp = y1
			y1 = y3
			y3 = tmp
			tmp = x1
			x1 = x3
			x3 = tmp
		end
	end

	y1 += 0.001 -- offset to avoid divide per 0

	local miny = min(y2,y3)
	local maxy = max(y2,y3)

	local fx = x2
	if(y2<y3) then
		fx = x3
	end

	local d12 = (y2-y1)
	if(d12 != 0) d12 = 1.0/d12
	local d13 = (y3-y1)
	if(d13 != 0) d13 = 1.0/d13

	local cl_y1 = clip(y1)
	local cl_miny = clip(miny)
	local cl_maxy = clip(maxy)

	for y=cl_y1,cl_miny do
		local sx = lerp(x1,x3, (y-y1) * d13 )
		local ex = lerp(x1,x2, (y-y1) * d12 )
		rectfill(sx,y,ex,y,c)
	end
	local sx = lerp(x1,x3, (miny-y1) * d13 )
	local ex = lerp(x1,x2, (miny-y1) * d12 )

	local df = (maxy-miny)
	if(df != 0) df = 1.0/df

	for y=cl_miny,cl_maxy do
		local sx2 = lerp(sx,fx, (y-miny) * df )
		local ex2 = lerp(ex,fx, (y-miny) * df )
		rectfill(sx2,y,ex2,y,c)
	end
end

function add_stars(num)

	for i=1,num do

		local spos = newver(rnd(2.0)-1,rnd(2.0)-1,rnd(2.0)-1)
		spos = v_norm(spos)
		spos.x *= 500.0
		spos.y *= 500.0
		spos.z *= 500.0

		stars[#stars+1] = spos

	end

end

local burnpos = newver(0,-2.1,0)

function add_burn(num)

	for i=1,num do

		local dir = newver(rnd(0.5)-0.25,-1.0,rnd(0.5)-0.25)
		
		local spos = v_add(burnpos, v_mulf(v_norm(dir), rnd(2.0)))

		dir = v_mulf((dir), 0.1)

		burn[#burn+1] = spos
		burn_dir[#burn_dir+1] = dir

	end

end

function add_vert(verts,x,y,z,c)
	verts[#verts+1] = newver(x,y,z)
end

function avlist(verts,scale,val)

	local maxsize = 5.0*scale

	while(#val > 0) do
		local cur = sub(val,1,6)
		val = sub(val,7,#val)

		local x = flr("0x"..sub(cur,1,2))
		local y = flr("0x"..sub(cur,3,4))
		local z = flr("0x"..sub(cur,5,6))

		x = (x/256.0 - 0.5) * maxsize
		y = (y/256.0 - 0.5) * maxsize
		z = (z/256.0 - 0.5) * maxsize
		verts[#verts+1] = newver(x,y,z)
	end
end

function avlistoffset(verts,scale,offset,val)

	local maxsize = 5.0*scale

	while(#val > 0) do
		local cur = sub(val,1,6)
		val = sub(val,7,#val)

		local x = flr("0x"..sub(cur,1,2))
		local y = flr("0x"..sub(cur,3,4))
		local z = flr("0x"..sub(cur,5,6))
		--local c = flr("0x"..sub(cur,7,8))

		x = (x/256.0 - 0.5) * maxsize
		y = (y/256.0 - 0.5) * maxsize
		z = (z/256.0 - 0.5) * maxsize
		verts[#verts+1] = v_add(newver(x,y,z),offset)
	end
end

function add_tri(tris,a,b,c,col)
	tris[#tris+1] = newtri(a,b,c,col)
end

function atlist(verts,tris,val)

	local basevert = #verts

	while(#val > 0) do
		local cur = sub(val,1,7)
		val = sub(val,8,#val)

		local v1 = basevert+flr("0x"..sub(cur,1,2))
		local v2 = basevert+flr("0x"..sub(cur,3,4))
		local v3 = basevert+flr("0x"..sub(cur,5,6))
		local col = flr("0x"..sub(cur,7,7))

		tris[#tris+1] = newtri(v1,v2,v3,col)
	end
end

function switch_third_scene()

	groundent = {}
	entities = {}
	road = nil
	rocklaunch = nil
	launchpad = nil

	station = newent(newver(0.0,30.0,0.0))
	atlist(station.ver,station.tri,"01020360405035060103707080350804031090a0410b090850a0c0450d0e0f610110f5120d0fd13140f614100fd15120f50e130f711150f1161718619161a71b191c61d06036020703d1e1f2011f17205171621d1619226191b22d1b232452325261251e260051d03d27282962a292bd2c2b2d52e2d2f12f30315323133d343528736333562f3237528353873533386333138d3130385272a3962e2f3a12c2e3a532363bd2a2c3cd3d3e3f640410e737424353b444554346477483d4963d4a4b64c424d54c484e64f505154a4f4bd484c525423b5315254557565758d3c3a5955a5b1515c400e65d5a1155e4a5f5606162563606256463625656662561656256667625685c0dd41691366a6b6c66d6c6ed6f6e705695d10d6b717275b68125735a5d5745d69d755b5a176685b5775c68d78405c679414077a694166c6b7b671587266e6c7cd706e7c57d707e1577d7e558577fd7c8060d757381082838477374851747a8557978846787786d7a7983d7776875767587145888958a7f67d7b726577e8b621728a656807b6168b7c6457f7e6753e558c634274478d898e1538e4d54d8f90d3e919263f3e2175f3f2265e5f93d919492d9590546969491d424c43d3a37971504f6d542534d55e716b7363444697705914f4a5e6597d5754a3d5fd918c88d9639981399998144969169958716995e935949820598992619a9b9c19d9e9f1a0a1a21a3a4a51a6a7a8ca3a8a41a9a1aa1302d38129283862d2b3852b2938da4abaccad9eae19aaf9b1b0b1afca1a9a6caaa0acc9bb2b3c9eadb0cae9db3cb4b5b61b7b8b91bab8bb1b4bcbd1bebfbccb5bdc0cb8babecbbb7c1c231bc2d171f18dc3c4c51c6c7c81c9cacb1cccdce1cfccd0cccd1d21d3d4d51d1d6d7cd8d9da1c3dbdc1ddc3decd5cfd3cd4d7d6cdbdfdccdaddd8cd9e0dfce1e2e31e4e5e61e7e8e91e1eaeb1ece1edceaeeebce9ece7ce8efeec1f1e095c21c0661e250a1180b02d0cc21dd25230c51a180161c1a017393c9913d483e6503747137506f5376f9750809041070b08518020161a161861c191a7c21b1c6f01e2016c807cd921721d211622675f18711ef026093232618a666562a272962c2a2bd2e2c2d5abf2acc322f315363233d27342873436356324237596273962f373a13c2c3a542323bd392a3cd691413647374358d3b455f3494e7494b4e751464374b514374e4b437f348496493d4b6954c4d5c3f4dec48f34e64f514bd4c955253b8d5313e52557995658d563c595115a1510d5c0e6105d11512680dd2d302f16d6a6c66f6d6ed976f705146910d7b6b727155b12574735d57a7469d73755a175765b5767768d77785c67879407797a416806c7b68e8f4d5708b7e18b707c51b2422d7f577e58a587fd637c60df17581085828178284817848681786878175046515817385117922058379846847886d827a83d86778750c050458d45895668a67d617b6578b64621a8aba4160806167c6364541130e7913e8c62796447538d8e17e62675954d90d213e926223f217245f2265f2493d942092d52955464c4e43d593a9714f6a6d56a5e6b73b36446707d5916a4f5e656595753d3f5fd459188d949698145449165e99716269993598f0205f098261f59a9c1f69d9f1f7a0a21f8a3a51a3a6a8c87f1817a1a0aa1eeefebc9e9dae1b2f9b3c9ab0afca9a7a6cf2aaaccadb1b0cf9aeb3cfab4b61fbb7b91b8b7bb1b5b4bd1b4bebccc1b5c0cbabfbecc0bbc1c0c23c2d1f0b18ddbc3c51dac6c81d5c9cb1d1ccce1fccfd0cd0ccd21d4c9d51d2d1d7cd9c6da1f4c3dc1afb29b1cffcd3cc9d4d6c2393245ddded8cc6d9dfceae1e31e9e4e61e8e4e91ede1eb1fdecedc7a82855ecfde7ce4e8eec0b1f0951dc2066091e0a10b0702d050c1dd0a250c5dfe0dcc061c0173c5699148523e64650471506d6f5588a7268f8e88655548868c558868e898865490886908f886")
	avlist(station.ver,1.0,"f38093f37b93fd7d8ef37b89f37f89f38390f37890f3778ccf768ccf7a88cf7691cf808857f4975ff4975bf98e5ff48558f48552f49264f49264f48b52f48aaf849eaf769ecf7a95af8d94cf8095af8d87cf8491f3838caf6d88af6d95a87492a88197a88692af847ea8868aaf767ea879856b69946b47946b47876b698761477e61697e54477e54697e4b69884b47884b47954b699554479e62699e62479e54699e527d8b5b038e64758a5775855875985f75856486926b84a26f8d9461e69e6be695527d92528b925f7597616da2578b85528b8b5f8697648b9264868a648b8a5886984b84a2588b985f86855786855f8b85628da24b76a2628df76b84f7626d7b626d586b7658546d7b54e67e4be68754e69e62e67e6b847b6f8d87568b00608a005670004d83004e77006883006878006170004be6946be688618d7b618d58548d58548d7b4b84584b847b4b76586b845864812754907e62907e4b90874b909454909e61909e6b90956b90885f8627528127546d585874275f7427578627588b85648b8b648b925f8b985f8b85578b97528b92616df7546df76479275279276b76f7546da24b76f74b84f7548df76b76a2a87997a881856f6d95548da26475924b767b6f6d886b767b8f85a59183a591839c9083a58f84a58f849cbe82a9bb85a9bb859ebc86a9c083a9c0839eb68aa9b68bf0bc86f0bb85f0bf82f0c083f0c67da98f85e89183e88f85e88c87a58c88e89184e89481a559d2a65dcfa65dcf9f5ccda658d1a658d19f58d1dc5ccedc59d3dc5dcfdc51d8a652d9dc65c9dc64c9a6cf848b8f85788f85829183829083789083828f8482be8275be8280bb8580bc8675bc8680c08380b68a75bc862dc08375c0832dbb852dbf822dbb8575c67d75c67e2d8f85359183358f84789183789184358c87788c883594817894813559d27759d27f5dcf7f5ccd775ccd7f58d17f58d1425cce4258d1775dcf775dcf4251d87759d34264c97765c942a8748b528b8ac67ef05f8b978f85358f859c90839cbe829ebc869e9481e859d29f5ccd9fb68b2d52d942")

	tele_cam = true	
end

function add_objects()

	local gz = -1.5

	road = newent(newver(3.3,-3.84+gz,6.56))
	atlist(road.ver,road.tri,"01020340403054050607408070950a0b0c50d0e0f510111251314155161718510191a41a1b1c4040103403060540626074261910407262742610124170d2850b08295191b1a41b2a1c40e0a0f5092712409122c4292c2d42e2d0c40c150f42f0f28429092c42e292d42d150c415180f40f18284141618511132c529080950b2e0c52f0d0f5112c1252d131551728185090727427261240d2f2852e0b2950a0c0f51514185132d2c51d1e1f01f20210212223024232501e201f0202221024212302b24250")
	avlist(road.ver,5.0,"3d82ef5a82ef5a82d13d82d13e82b56382be41828d4482794a82852d824a3e82633d82474b82142e822e3e82359882788a826c83827884825992823c7f823e8a821f68821079822c948296ba829ca282add182c44084ef5484f14484c95984cb4984995e849b6284764d84746684537d82a07182916482224c8270ab82e05184517a8267768251498258518224")
	road.sort = false
	groundent[#groundent+1] = road

	planet = newent(newver(0.0,0.0,0.0))
	atlist(planet.ver,planet.tri,"010203b040506c030204b020705c08090ac0b0c0db0e0f10c11120eb0d1314c131516c151716c0e120fc12180fc191a13b161913c181b1cb1b1d1cc1d1e1fc20211ec1d201ec1b221dc22201db21231ec202421b242521c212523c252623d272829c2a2b27b272b28a2b2c28a2d2e2ac2a2e2bc2e2f2bb2b2f2cb2f302cb2f0830b080a30b30312cc0d0c13c323334c353628c283637c383739b373a393292838c283738c313528c363b373373b3a33c113da3e3f40c0f130cc353d36c410d423410b0d30d1442b0b0f0cc110e3da1c1d1fc151f17c1c1f15c100b41c1a4344345431a3222420b100f0bc171916b032422b3d1041b0e103d33e444631a443e33e463fd3d413b3363d3bc444746d2404063334849c23451ed4a4b45d171a19a1f1a17a133e40c141340c33494cc434d4ed240625c264f4a11f1e1aa0a3c31c131a3eb485049c514248b484250b421450b501440c3c0111c52535415255531495652d5732347011b18c524755158595515a32577545b4c7120118c3f465634758551405649d055c5d75e5f60f5c0702c615e60f6263641110112c4c5b657662967f61685e7685c5e75d62641075c05767325af696a2df692d2af692a29f383932c57346b734336b76b334c7605f6af4d6359153555b7055d25c403f56d010322c015c02c01221bc093c0ac5e095ff1e451ab4f26641564652d293832c2e082fc666929f5f092ec2e0908c2c3128c434e44d325133c3a5132c0a3130c464752d495040c49524cd4c5254d4a634b14b634314a4f631642625d264a23d454b43d686c5c7292a27c234a45d6b4c65754535b7444e47d556d5b74e58471020504c6a5f2df5e5c0970f1c15a181c0fb3c5c01c393a32c3c3d35a0f1513c293267f335148c313c35b3c095cc2d5f2ec626e6314f646315c6c627060525c596f5514d594e14e595816c6e6215c625d7556f6d143634d1255d64d3b423ab3a4251b3b4142b0304243")
	avlist(planet.ver,60.0,"b4bf8dc1b885b1c37dc7b773d5a273c6b462cbad8ea5a7c7d28fada3b1bd61cc8c63cc8352c9807ccb9e7cd07c6ecd9590c7a08bcc965fc85e42c1857ccf6b73cd6280cc5e8bcf7f67c8586cbf439bcc7c90ce6e9acb6b91c1428ac753a0c75fa5c053a8c773a3ba47b4ba58bbb253b3a8377c96dc76a6d26193da8b8edf8e9ddb84adcaa88bd79a94d89ba3cf93afc88bb6c23a97c1239b992390a77cbcbc6dc0b462b8be5eadc750afbd4bb5af64c2ac98c2ac6ec8a451c25f46be623bbb6962ca9646be967bb02d50b9498bb63648b95843af463ab49e2aab7c99ae2e8aaa2b1d958a6ea92a5ead32b39e323cbb8944b7a42ea9602390511d956e357d2f3bb45b235ab951a32f7c53113a63d11b554ed2a096dc946bdd73aac186c9d952b2e55c96dd734eb3611fc89a44115a846e5de7515fdfe8587c985be3bc56d21661a0e55c622e5e32d95246445820")
	planet.sort = false
	groundent[#groundent+1] = planet

	
	local ncenter1 = newent(newver(-3.8,-0.2+gz,18.43))
	atlist(ncenter1.ver,ncenter1.tri,"01020370405015050406707080970a06035090b0c70d0e0f608070d5070c0e70c100e511121360b091270914125150b11516171860c0b177100c1670b151770a02196191a1b7050a1c601051d602011961e1f2001c192051a1d1e51d1c1e7210103721040150a050670908147020a03507090c7220d0f622080d50d070e7100f0e52311136110b127141312523151152416186160c177241016715181771c0a19620191b71d051c61a011d6011a1961b1e2001f1c2051b1a1e51c1f1e7")
	avlist(ncenter1.ver,2.0,"7057a30357a30332a370326c70576c03326c8fa2888f3288dea28803576cdea2498fa2497798887798497732498f3249fb9849fb9888fb3288de3288de32499b8949d38949d332491e61966661966670941e617966617966707b1e707b1e70947032a3773288fb32499b3249")
	entities[#entities+1] = ncenter1
	groundent[#groundent+1] = ncenter1
----
	local ncenter2 = newent(newver(11.3,-0.19+gz,15.8))
	atlist(ncenter2.ver,ncenter2.tri,"01020370405065010307108020950a020810b0c0d502010e707080c701070c50f100d5090e0f50e0b0f70c09117121314607151270807127160817705181951a1b1cd1d1e0561b1d1c71e1f18d1f20187201a216192223d242526d1c0406518272852721285211c25529232a02b2a2c006192962506267222823728242c608090c70519065020e095010b0e7160a081100b0d5020a0370b100f70b010c5110f0d511090f50d0c11717121461513127170812714161771822195211a1cd041d0561d041c7051e18d20271872720216291923d2c2426d251c0652218285212428524212552b292a0262b2c02b06296062b267282a2372a282c60315071")
	avlist(ncenter2.ver,2.0,"cc53a66553eecc28a68a9e20919e3082b12076532b0f53732264656528eeb964b46364384a704a7864e19170cfa070c53b70546a4a336a29331b296b76282b0f28731b4a6ba19e308db138a2290d90290d919e10872920902932a22932ab2920a19e10a5b138a0c52fa5b1088db10891c511a89e20b0b12091c52fa7c5208ac520a1c511")
	entities[#entities+1] = ncenter2
	groundent[#groundent+1] = ncenter2
--
	local nmount = newent(newver(-12.6,-0.6+gz,-3.1))
	atlist(nmount.ver,nmount.tri,"01020340405014050607b0608094060504b08040ab05070b4080604b020c0d4080e09404010f41011124121113b140e104060907b0e08104150103b161703b02160341613174040f0ab18020db01150fb02010cb1410124191213b100a0fb021816b13110fb191316b0f1110b0c050db080a104050b0db01050cb150313b0f151340317134")
	avlist(nmount.ver,3.0,"a99a5ca1911788802c9d67a3ba76a2a487d9c653b68869e8b552e979b3c7f25371b56f4ad5534a8852ff888f8d5a84c734ab8d1e538d34764b3e52e788b5543b53045fb72cb253041e5340")
	entities[#entities+1] = nmount
	groundent[#groundent+1] = nmount
	local nmount2 = clone(nmount)
	nmount2.loc = newver(-1.8,-0.6+gz,-27.6)
	entities[#entities+1] = nmount2
	groundent[#groundent+1] = nmount2
	local nmount3 = clone(nmount)
	nmount3.loc = newver(28.4,-0.6+gz,10.6)
	entities[#entities+1] = nmount3
	groundent[#groundent+1] = nmount3
	local nmount4 = clone(nmount)
	nmount4.loc = newver(31.6,-0.6+gz,27.1)
	entities[#entities+1] = nmount4
	groundent[#groundent+1] = nmount4

	local tlaunch = "0102037020405d0406057010706d050809101060ad0b0c0d707030c103050cd08070bd0e0d0f60c0910d09111270a1314706040a10201151161317618191a01b1c1d61c1316604021961e1b1f0021c1b61a191f019021f62021170130420618161702104226231424a150a237241c252131c247252627828242701c1526015282620d1029710122a6120e2b52c2d2e5102a2962f30318302f32733323483534367373839137393a136343b738363b839383c73d393e837363810701037030205d0608057060708d081109115010ad0e0b0d70b070c105090cd11080bd2b0e0f60d0c10d1009127230a14704130a11c02151021e1f616181a013201761a1c166180419621221701e021b61d1a1f00418226042120622181701b1d1f0282324a28152373f2425214132473f25278243f270251c260282726212402a640122b5412c2e52a4229643442c6452f318333032735333483735367393d3a13c383b83e393c7463d3e81c1a1d60b0e47d110b48d121149d0e1247d480b47d4a1148d114a49d124947d440d29744292d70f0d446430f44629422d641432c6422e2d62c442d7"
	local vlaunch = "9eb4369ebd4d9e864d72bd4d72864d72b4369e86367286365f714d72da40af7121af714daf374daf3721d6164e5f374d5f71215f372172da4d7fe44a9eda407cd1597cca6f7cc15993c15993d1599ec57c9eda4d93ca709eb47c93b87072c57c72b47c7cb86f7fe44390e44a99fe4899fe4595fe4690e4435f378739164ec0160daf37bc5f37bc3916f1664320a6431fa63d1f664820a6481f664f20a64f1f875620a6561f875d20876320a66b1f665620665d20876b2066632095fe474f160dd616f1391687d61687af3787663d20666b20a63d1fa66b1f663d20666b20"

	local trock = "01020350304057060507508070970a090b50b0c0d70e0d0f5100e027110d0e5080a127131415707141621718196070514504021a50c091351b051c61d1e1f80f18205141b15518171d71b2122717131e51a0f207211a2352425265232027e22232781e151fe2028298152a268281d2be2a2224e2c2d2ef0a0b2f50b112f711102d510013070306317060832501033352e34354313236f2f2c37f333138f122f39f2d302ef303338f321236f3a3b35a34383b4363c3d4372e3543e363f43937404383e3f43c39414090742613091621a0243244194560c1744605041c6180d466211b47604214860d0c46649484a74b444c74d4e4f719465074551526484753654525585657588595a5b4584f5c75d535765b5e5fa604a5c6471c617464b5965c4a5671c49626636465763665066564676684c5476764696614f5866a4a4e6616b4d653615774761537626a6c46a4e6d64a485d76e6c6fa70595f46370716496a6275150527704659755666874e4d72473626e44d6b7266b736e44c44457654c68650665566b1c73714131620f1a432020e7460e0f4324b675a764636945a6775419505170204035060305708060750a08097090c0b5110b0d70d180f5011002710110e532081271e1315742071624417196051b14521041a5170c135471b1c62b1d1f818282051b2a15528181d72a1b2271d171e5231a20722212352625765626c6e4292b1f576292652a2426837774042522278252776576202985a5e5b429282be04491c6372c2ef120a2f50c4b4662c112d52d1030733033173106325300133519514563e3136f392f37f6d726fa3c1239f4f605c7343038f15261fe3b3f35a3f3d41a353f41a773541a407741a3a343b4112c2f777373544b5a596291f2653b383f44a604e609421620274432222524e4b0c446207627e191846648214764904486343a3546a494a7674b4c7313e38f467050754455265d4853668545585c56588123c36f4e604f7565d5765e755fa756971a5f7571a1c6b61739404144a5d567731c626666365770635064c656764c4554775676963c413d44f614d661585776a786c4786a6d66c786fa786d6fa595b5f4705f716505552766656876d4e72430342ef6b6f7266f6b6e4740e43263716945e5a754363d3f4"
	local vrock = "88346b88696b9434779475779475889434888869948834947769947734946b34886b75886b757777696b77806b77346b6b34777c2b8877809488809488a0948073a46b81886b81775e817a88806b948188a175856ba08877a0947cbc8777a06b94817794a07788a06b87bc8387bc7c83bc8783bc786ba07778bc7c94a08878bc83772b7c7c2b777a2271772b83832b77882b83832b88882b7c86227178126f86228e7122798e227971228687126f9012787a228e8712908e22869012876f12877812908061b080745b5e81855e9c855e757aa18185a1817aa1757aad9c7a5e7585529c85af3a83af3a7caf9c83529c7a5e9c7a5aa47da19c855aa48255a47da5a47da5a482aba4825e3a7a5e3a855c327daba47da19c7a5c328257327daf9c7cad9c85a13a7a503a7c503a83509c83509c7c523a8555a482563281ad3a7aad3a85a5327dab327ea53282a93282523a7a56327eab3281a13a8580604f5732827cbc786f1278a9327d"

	launchpad = newent(newver(0,2,-3.0))
	atlist(launchpad.ver,launchpad.tri,tlaunch)
	avlistoffset(launchpad.ver,1.1,newver(-0.16,-0.8+gz-2.0,3.0),vlaunch)
	entities[#entities+1] = launchpad
	groundent[#groundent+1] = launchpad

	rocket = newent(newver(0,0,0))
	atlist(rocket.ver,rocket.tri,trock)
	avlist(rocket.ver,1.0,vrock)
	--entities[#entities+1] = rocket

	rocklaunch = newent(newver(0.0,0.0,0.0))
	atlist(rocklaunch.ver,rocklaunch.tri,tlaunch)
	avlistoffset(rocklaunch.ver,1.1,newver(-0.16,-0.8+gz,0.0),vlaunch)
	atlist(rocklaunch.ver,rocklaunch.tri,trock)
	avlist(rocklaunch.ver,1.0,vrock)
	entities[#entities+1] = rocklaunch

	if(current_scene == 2) then
		road.hidden = true
		ncenter1.hidden = true
		ncenter2.hidden = true
		nmount.hidden = true
		nmount2.hidden = true
		nmount3.hidden = true
		nmount4.hidden = true
		launchpad.hidden = true
		rocklaunch.hidden = true
	else
		launchpad.hidden = true
		rocklaunch.hidden = false
	end

	sumverts = 0
	sumtris = 0
	for i=1,#entities do
		sumverts += #(entities[i].ver)
		sumtris += #(entities[i].tri)
	end
	sumverts += #(road.ver)
	sumtris += #(road.tri)
	sumverts += #(planet.ver)
	sumtris += #(planet.tri)

	if(current_scene == 3) then
		planet.loc.y -= 500.0
		switch_third_scene()
	end

end

function sorttris(t)
	local tv = #t-1
	for i=1,tv do
		local t1 = t[i]
		local t2 = t[i+1]
		if(t1.avg < t2.avg) then
			t[i] = t2
			t[i+1] = t1
		end
	end
end

function sorttrisloop(t,n)
	local tv = #t-1
	for j=1,n do
		for i=1,tv do
			local t1 = t[i]
			local t2 = t[i+1]
			if(t1.avg < t2.avg) then
				t[i] = t2
				t[i+1] = t1
			end
		end
	end
end

function sortalltris(t)
	local tv = #t-1
	local loop = true
	while loop do
		loop = false
		for i=1,tv do
			local t1 = t[i]
			local t2 = t[i+1]
			if(t1.avg < t2.avg) then
				t[i] = t2
				t[i+1] = t1
				loop = true
			end
		end
	end
end

function draw_stars()
	local tv = #stars
	for i=1,tv do
		local cur = trans_vert(stars[i])
		if(cur.z > 0.01) then

			local col = 7
			if(rnd(100)<5) col = 10

			pset(cur.x, cur.y, col)
		end
	end
end

function draw_burn()
	local tv = #burn
	for i=1,tv do
		local cur = burn[i]
		local curdir = v_add(cur,burn_dir[i])
		local tcur = trans_vert(cur)
		if(tcur.z > 0.01) then
			local mc = cur.x*cur.x,cur.z*cur.z
			local col = 10.8-mc*50.0
			if(col < 8) col = 5
			local siz = 16.0*(1.0/max(abs(tcur.z),0.01))
			circfill(tcur.x, tcur.y, siz,col)
		end
		if(curdir.y<-4.1) then
			curdir = clone(burnpos)
		end
		burn[i] = curdir
	end
end

function draw_tris(ent)
	if(ent.hidden) then
		return
	end

	local vtable = ent.ver
	local ptable = ent.tri

	local tverts = {}
	local tv = #vtable
	for i=1,tv do
		local cur = clone(vtable[i])
		cur = v_add(cur,ent.loc)
		cur = v_sub(cur,campos)
		local cur2 = clone(cur)
		cur2.x = v_dot(cur,camright)
		cur2.y = v_dot(cur,camup)
		cur2.z = v_dot(cur,camdir)

		local invz = 64.0*(1.0/max((cur2.z),0.1))
		cur2.x = (-cur2.x * invz + 63.5)
		cur2.y = (-cur2.y * invz + 63.5)

		tverts[i] = cur2
	end
	
	local tn = #ptable

	if(ent.sort) then
		for i=1,tn do
			local ct = ptable[i]
			ct.avg = tverts[ct.v1].z + tverts[ct.v2].z + tverts[ct.v3].z
		end

		if(tele_cam) do
			sortalltris(ptable)
		else
			sorttrisloop(ptable,3)
		end
	end

	for i=1,tn do
		local ct = ptable[i]
		local v1 = tverts[ct.v1]
		local v2 = tverts[ct.v2]
		local v3 = tverts[ct.v3]

		local back = (v2.y-v1.y)*(v3.x-v1.x) - (v2.x-v1.x)*(v3.y-v1.y)

		local minx = min(min(v1.x,v2.x),v3.x)
		local maxx = max(max(v1.x,v2.x),v3.x)
		local miny = min(min(v1.y,v2.y),v3.y)
		local maxy = max(max(v1.y,v2.y),v3.y)
		local minz = min(min(v1.z,v2.z),v3.z)

		local clip = maxx < 0 or minx > 128 or maxy < 0 or miny > 128 or minz < 0.01

		if(back>=0 and not clip) then
			dtri(flr(v1.x),flr(v1.y),flr(v2.x),flr(v2.y),flr(v3.x),flr(v3.y),ct.c)

		end
	end	
end


function draw_expl(ent)
	if(ent.hidden) then
		return
	end

	local vtable = ent.ver
	local ptable = ent.tri

	local tverts = {}
	local tv = #vtable
	for i=1,tv do
		local cur = clone(vtable[i])
		cur = v_add(cur,ent.loc)
		cur = v_sub(cur,campos)
		local cur2 = clone(cur)
		cur2.x = v_dot(cur,camright)
		cur2.y = v_dot(cur,camup)
		cur2.z = v_dot(cur,camdir)

		local invz = 64.0*(1.0/max((cur2.z),0.1))
		cur2.x = (-cur2.x * invz + 63.5)
		cur2.y = (-cur2.y * invz + 63.5)

		tverts[i] = cur2
	end
	
	local tn = #ptable

	for i=1,tn do
		local ct = ptable[i]
		local v1 = tverts[ct.v1]
		local v2 = tverts[ct.v2]
		local v3 = tverts[ct.v3]

		local avg = clone(v1)
		avg.x = (avg.x + v2.x + v3.x)*0.333
		avg.y = (avg.y + v2.y + v3.y)*0.333
		avg.z = (avg.z + v2.z + v3.z)*0.333

		local minz = min(min(v1.z,v2.z),v3.z)

		local clip = minz < 0.01

		if(not clip) then
			local siz = 15.0*(1.0/max(abs(avg.z),0.1))
			circfill(avg.x,avg.y,siz,ct.c)
		end
	end	
end

function _init()
	add_stars(100)
	add_burn(30)
	add_objects()
end

function up_groundent(ent)
	ent.loc.y -= rocket_speed_y
end

function _update()

	local dt = 2.0/30.0

	if(time>80) then
		current_scene = 3
	end

	if(current_scene == 3 and prev_scene != current_scene) then
		switch_third_scene()
	end

	if(current_scene == 1 and time>13.0) then
		if(time>13.0) then
			if(not launch_started) then
				tele_cam = true
			end
			launch_started = true

			launchpad.hidden = false
			rocklaunch.hidden = true
		end

		if(rocket_height>75) then
			current_scene = 2	
		end
	end
	
	if(launch_started) then
		local motion = 0.001
		rocket_speed_y += motion
		rocket_speed_y = min(rocket_speed_y, 10.0)
		rocket_height += rocket_speed_y
		foreach(groundent, up_groundent)
	end

	--if(btnp(4)) then
	if(false) then
		if(camstyle == 0) then
			camstyle = 1
		else
			camstyle = 0
		end
		tele_cam = true
	end

	if(camstyle != 0) then
		camstyle = current_scene
	end

	local v1_bob = cos(time * 0.1) * 2 + 5.1
	local v2_bob = cos(time * 0.1) * 1 + 3.1

	local v2_y = sin(time*0.025)*3.0

	if(camstyle == 0) then
		local bob = 6.0
		local speed = 0.005

		if(btn(0)) manrx += speed
		if(btn(1)) manrx -= speed
		if(btn(2)) manry -= speed
		if(btn(3)) manry += speed

		manry = max(-50.0,min(50.0,manry))

		local verpos = sin(manry)
		local verpos2 = cos(manry)

		camtar = clone(camrottar)

		campos.x = camtar.x+sin(manrx)*bob*verpos2
		campos.y = camtar.y+verpos*bob
		campos.z = camtar.z+cos(manrx)*bob*verpos2

		camup = newver(0,1,0)
	else
		if(camstyle == 2) then

			local blend = min(1.0,camtrans/5.0)
			local bob = lerp(v1_bob,v2_bob,blend)
			local vy = lerp(1.0,v2_y,blend)

			campos.x = camrottar.x+sin(time*0.05)*bob
			campos.y = camrottar.y+vy
			campos.z = camrottar.z+cos(time*0.05)*bob
		else
			if (camstyle == 3) then

				local blend = max(0,min(1,8-time3*0.5))

				local v3_bob = cos(time3 * 0.1) * 1 + 5.1
				local v3_y = 3.0

				local loc = station.loc
				camtar = v_mulf(loc,blend*blend)

				campos.x = camtar.x+cos((time3*0.05)+0.8)*v3_bob
				campos.y = camtar.y+v3_y
				campos.z = camtar.z+sin((time3*0.05)+0.8)*v3_bob

				camup = newver(1,0,0)

			else

				campos.x = camrottar.x+sin(time*0.05)*v1_bob
				campos.y = camrottar.y+1.0
				campos.z = camrottar.z+cos(time*0.05)*v1_bob

				camup = newver(0,1,0)
			end
		end
	end

	if(current_scene >= 2) then
		camtrans += dt
	end
	if(current_scene == 3) then
		time3 += dt
	end

	camdir = v_norm(v_sub(camtar,campos))
	camright = v_norm(v_cross(camup,camdir))
	camup = v_cross(camdir,camright)

	time += dt
	timer += dt

	prev_scene = current_scene
end

planet_pos = newver(0,-150,0)

function trans_vert(vert)
	local cur = clone(vert)
	cur = v_sub(cur,campos)
	local cur2 = clone(cur)
	cur2.x = v_dot(cur,camright)
	cur2.y = v_dot(cur,camup)
	cur2.z = v_dot(cur,camdir)

	local invz = 64.0*(1.0/max(abs(cur2.z),0.01))
	cur2.x = (-cur2.x * invz + 64)
	cur2.y = (-cur2.y * invz + 64)

	return cur2
end

function ent_compavg(ent)

	ent.avg = trans_vert(ent.loc).z

end

function draw_planet3()

	local planethor = clone(camdir)

	planethor.y = 0
	planethor = v_mulf(v_norm(planethor),150.0)
	planethor = v_add(planethor,campos)
	planethor.y -= rocket_height

	local pp = trans_vert(planethor)

	planethor.y -= 150.0

	local p2 = trans_vert(planethor)

	local csize = v_dist2d(pp,p2)
	local dx = (p2.x-pp.x) / csize
	local dy = (p2.y-pp.y) / csize

	local curheight = 10000.0
	local small = 1000.0

	local gpx = pp.x + dx * curheight
	local gpy = pp.y + dy * curheight
	local spx = pp.x + dx * small
	local spy = pp.y + dy * small

	planet_pos.y = -40 - rocket_height/10

	local dotplan = v_dot(planet_pos,camdir)
	local chdir = v_mulf(camdir,dotplan)
	local projplan = v_sub(chdir,planet_pos)
	local projsize = 40.0/v_len(projplan)
	local projplan2 = v_mulf(projplan,projsize)
	local projplan3 = v_add(projplan2,planet_pos)

	local p0 = trans_vert(planet_pos)
	local pproj = trans_vert(projplan3)

	local csize2 = v_dist2dbig(p0,pproj)

	local psize2 = 0.0

	local change = max(0,min(1,(rocket_height-50)*0.01))

	local finx = lerp(gpx, p0.x, change)
	local finy = lerp(gpy, p0.y, change)
	local fins = lerp(curheight, psize2, change)
	local fin2x = lerp(spx, p0.x, change)
	local fin2y = lerp(spy, p0.y, change)
	local fin2s = lerp(small-5, psize2/max(1,rocket_height), change)

	circfill(finx,finy,fins,12)
	circfill(fin2x,fin2y,fin2s,3)
end

function explosion(ent)

	local vert = ent.ver
	local vn = #vert
	for i=1,vn do
		local cur = vert[i]
		
		local dir = v_mulf(v_norm(cur),0.1)

		vert[i] = v_add(cur, dir)

	end

end

function centertext(posx,posy,text,col)

	local sposx = posx - #text * 2
	local sposy = posy
	print(text, sposx+1,sposy,13)
	print(text, sposx-1,sposy,13)
	print(text, sposx,sposy+1,13)
	print(text, sposx,sposy-1,13)
	print(text, sposx,sposy,col)
end

sun = newver(0,10,50)

function _draw()

	cls()

	draw_stars()

	local tsun = trans_vert(sun)
	if(tsun.z>0) then
		circfill(tsun.x,tsun.y,8,9)
		circfill(tsun.x,tsun.y,6,10)
	end

	if(current_scene == 1) then
		draw_planet3()

		--if(road != nil) then
			draw_tris(road)
		--end
		foreach(entities, ent_compavg)
		sorttris(entities)
		foreach(entities, draw_tris)
	else

		local objproj = trans_vert(planet.loc)
		local plax = abs(objproj.x-64)
		local play = abs(objproj.y-64)
		if(plax<180 and play<180 and objproj.z>0) then
			draw_tris(planet)
		end

		if(current_scene == 2) then
			

			draw_burn()
			draw_tris(rocket)
		else

			if(station.loc.y > 0.0) then
				station.loc.y -= 0.2
			else
				explode = true
			end 

			if(explode) then

				if(time3<50) then
					explosion(rocket)
					explosion(station)
				end				
				draw_expl(rocket)
				draw_expl(station)
			else
				draw_burn()
				draw_tris(rocket)
				draw_tris(station)
			end
		end
	end


	if(current_scene == 1 and launch_started) then
		draw_burn()
		draw_tris(rocket)
	end
	
	tele_cam = false

	if(time<2) then
		rectfill((time-1) * 128,0,128,128,0)
	end

	if(time<16) then
		centertext(68,10,"launch incoming",6+flr(time)%2)
	end

	if(time>110) then
		local texy = 128-min(118,max(0,(time-110)*5 ))
		centertext(68,texy,"the end",7)
		centertext(68,texy + 12,"nusan",10)
	end


	if(false) then
		local cpu = stat(1)*100

		print("cpu:"..cpu,96,0,8)
		print("ram:"..flr(stat(0)),96,8)
		print("v:"..sumverts,96,24)
		print("t:"..sumtris,96,32)

		print(time .. " " .. camstyle, 0,120,8)

	end

	--time = 24.7

end