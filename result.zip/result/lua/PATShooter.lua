-- pat shooter
-- benjamin soule

bullet_spd = 1.5
scroll_spd = 4
mis_max = 24
jump_to_game = false
planet = 0
seed = 1
cls()

function init()
 ents = {}
 explosions = {}
 stars = {}
 anims = {}
 queues = {}
 delays = {}
 ships = {}
 scores = {}
 gmo = nil
 t = 0
end

function reset()
 reset_m()
 m.upd = upd_menu
 init()
 music(0,1000)
end

----------
-- game --
----------
function launch()
 reset_m()
 init()
 music(8)
 m.upd = upd_game
 m.draw = draw_game
 score = 0
 dif = 0
 make_hero() 
	for i=0,64 do
	 s = {}
	 s.x = rnd(128)
	 s.y = rnd(128)
	 s.c = i/64
	 s.col = 1
	 if( s.c > 0.75 ) then 
	  s.col = 12
	 end
	 add(stars,s)
	end
end

function upd_game()
 foreach(ents,upd_ent)
 
 -- spawner
 if( m.t == 80 or count(ships)==1 )then  
  for y=0,3 do
   k = mget(m.step-1,planet*3+y)
   if( k == 64 ) then make_dima() end
   if( k == 80 ) then make_roll() end
   if( k == 96 ) then make_wav() end
   if( k == 113 ) then make_enforcer() end
  end
  m.step = min(m.step+1,58)
  m.t = 0
 end
end

---------
-- ent --
---------
function make_ent(kind)
	if( kind == nil ) then kind =-1 end
	e = {}
	e.kind = kind
	
	e.x = 0
	e.y = 0
	e.t = 0
	e.cd = 0
	e.vx = 0
	e.vy = 0
	e.frict = 1
	e.fr = 0
	e.ray = 4

 e.flash =  0
 e.bad = 0
 e.bul = 0
 e.life = 1
 e.life_max = 1
 e.shield = 0
 e.inv = 0
 e.step = 0
 e.count = 0
 e.tsh = 0
 e.track = {}
 e.track_i = 1
 e.fam = 0
 e.draws = {} 
 e.cva = 0.1
 e.pierce = 0
 
	add(ents,e)
	return e
end

----------
-- hero --
----------
function make_hero()
	hero = make_ent(0)
	hero.x = 64
	hero.y = 120
	hero.fr = 2
	hero.mis = 1
	hero.upd = upd_hero
	add(hero.draws,draw_reac)
	add(ships,hero)
	hero.fam = 1
	hero.ray = 3
end

function upd_hero(e)

	if( e.mis < mis_max and e.t%60 == 0 ) then
	 e.mis = e.mis+1
	end

	acc = 1.5
	e.vx = 0
	e.vy = 0
 if( btn(0) ) then e.vx = -acc end
 if( btn(1) ) then e.vx = acc end
 if( btn(2) ) then e.vy = -acc end
 if( btn(3) ) then e.vy = acc end
	if( btn(4) and e.cd == 0 ) then 
		e.cd = 8
		for i=0,1 do
		 b = fire(e)
		 b.x = b.x+i*7-4
	 	b.vy = -6
	 	b.anim = {3,3,4,4}
	 end
	end
	 
	if( btnp(5) and e.mis > 0 ) then
		mx = e.mis-1
		for i=0,mx do
		 b = fire(e)
		 b.kind = 0
	  b.fr = -1
	  b.spd = 3+rnd(0.6)
	  b.anim = nil
	  b.fr = -1
	  b.pierce = 1
	  b.cva = 0.1+rnd(0.1)
		 impulse(b,rnd(1),3)
	  b.outlim = 64
	  b.queue = 1
	  b.upd = function(e)
				seek_trg(e)
				follow_trg(e)	  
	  end
	 end
	 e.mis = 0
	end
	-- recal
 r = 4
	e.x = min(max(r,e.x),127-r)
	e.y = min(max(r,e.y),127-r)
end

----------
-- bads --
----------
function make_bad(na,sc,li,sh)
 e = make_ent()
 e.fr = 5
 e.bad = 1
 e.x = 8+rnd(112)
 e.y = -4
 add(ships,e)
 e.fam = 1

 e.score = sc
 e.name = na
 e.life = li
 if( sh ~= null ) then e.shield = sh end
 e.life_max = e.life+e.shield

 return e
end

function make_dima()
 e = make_bad("dimanid",10,3)
 e.fr = 5
 e.t = flr(rnd(80))
 e.fr = 5
 e.vy = 1
 e.vx = ((rnd(10)/10)*2-1)*0.5
 e.upd = function(e)
  k = 40
  if( e.t%k == 0 ) then 
   shoot_target(e,hero)
  end
  bounce_x(e)
  e.inv = flr((e.t%(k*2))/k)
  e.fr = 64+e.inv
 	if( e.y > 136 ) then kill(e) end
 end
 return e
end

function make_roll()
 e = make_bad("roll-volt",20,3,8)
 e.fr = 80
 e.upd = function(e)
  lim = 80
  spd = 1
  if( e.shield <= 0 ) then
   if(e.fr == 80 ) then sfx(7) end
   e.fr = 83+(t%8)/4 
   lim = 40
   spd = 2
  end
  if( e.tw == nil ) then
   if( e.step < 12 ) then
    if( e.t < lim ) then
     tw = move_to(e, 8+rnd(116), 8+rnd(60), spd )
		  else
     e.t = 0
     e.step = e.step+1
     shoot_circ(e,12)
    end
   else
    if( e.y > 0 ) then 
     tw = move_to(e, 8+rnd(116),-8,spd)
    else 
     del(ents,e)
    end
   end
  end  
 end
 d = function(e)
  for i=0,5 do
		 an = i/5+e.x/20 + t/60
   x = e.x + cos(an)*5
   y = e.y + sin(an)*5
   fr = max( 82-e.shield, 81 )
   spr(fr,x-4,y-4) 
  end
 end
 add(e.draws,d)
end

function make_falk()
  e = make_bad("falko",5,2)
  e.fr = -1
  e.anim = {66,66,67,67,68,68,69,69,70,70}
  e.anim.spd = 0.5
  e.upd = follow_track
  --add(e.draws,draw_reac)
  return e
end

function make_enforcer()
 e = make_bad("enforcer",100,12,12)
 e.fr = -1
 e.ray = 8
 d = function(e)
  n = 99
  if( e.vx < -1 ) then n = 97 end
  if( e.vx > 1 ) then n = 101 end
  x = (n%16)*8
  y = flr(n/16)*8
  sspr(x,y,16,16,e.x-8,e.y-8,16,16)
 end
 add(e.draws,d)
 
 e.upd = function(e)
  tx = 64+cos(t%80/80)*40 
  ty = 32+sin(t%113/113)*8 - max(0,64-e.t)
  e.vx = tx-e.x
  e.vy = ty-e.y
  if( e.t%60 == 50 ) then
   local enf = e
   for i=0,min(2+e.t/60,6) do
    f = function()
     if( enf.dead ) then return end
     b = shoot_target(enf,hero)
     b.ray = 4
     b.anim = {9,9,10,10,9,9,11,11}
     set_speed(b,1+i/2)
    end
    delay(4*i,f) 
   end
  end
  
 end
end

function set_speed(e,spd)
 a = atan2(e.vy,e.vx)
 e.vx = cos(a)*spd
 e.vy = sin(a)*spd
end


function make_wav(k)
  local tr = {}
  for i=0,8 do 
   add(tr,rand_pos())
   add(tr,20+rnd(90))
  end
  add(tr,rand_pos())
  add(tr,-8)
  local px = rand_pos()
  f = function()
   e = make_falk()
   e.x = px
   e.y = 136
   e.track = tr
  end
  delay(8,f,6)
end

function upd_ent(e)
 e.t = e.t+1
 if(e.cd > 0 ) then e.cd = e.cd-1 end
 if(e.flash > 0 ) then e.flash = e.flash-1 end
 
 -- tween
 if( e.tw ~= nil ) then
  tw = e.tw
  tw.c = min(tw.c+tw.spc,1)
  c = tw.curve(tw.c)
  tx = tw.sx*(1-c) + tw.ex*c
  ty = tw.sy*(1-c) + tw.ey*c
  e.vx = tx-e.x
 	e.vy = ty-e.y
 	if( tw.c == 1 ) then
 	 e.tw = nil
 	end
 end
 
 -- upd
 if( e.upd ~= nil ) then e.upd(e) end
 
 -- bullets
 if( e.bul == 1 ) then
 	if( e.trg ~= nil and e.mono ) then
 	 if( col(e,e.trg) ) then impact(e,e.trg) end 	 
 	else
 	 for b in all(ships) do
 	  if( col(e,b) ) then impact(e,b) end
   end
  end
 	check_out(e)
 end
 
 -- ships
 if( e.fam==1 )then
  for b in all(ships) do
   if( col(e,b) ) then impact(e,b) end
  end
	end
 -- move
 e.ox = e.x
 e.oy = e.y
 e.x = e.x+e.vx
	e.y = e.y+e.vy
	e.vx = e.vx*e.frict
	e.vy = e.vy*e.frict
	
	-- queue
	if( e.queue ) then
  add_queue(e.x,e.y,e.ox,e.oy,e.queue)
	end	
	
	--
	if( e.life <= 0 ) then 
	 explode(e) 
	end
		
end

function clone_bad(e)
 local c = make_bad()
 c.x = e.x
 c.y = e.y
 c.vx = e.vx
 c.vy = e.vy
 c.upd = e.upd
 c.fr = e.fr
 c.track = copy(e.track)
 c.draws = copy(e.draws)
 return c
end

function copy(a)
 local b = {}
 for p in all(a) do add(b,p) end
 return b
end
function emit(e)
 local b = make_ent()
 b.x = e.x
 b.y = e.y
 return b
end

function follow_track(e)
 
 if( e.tw ~= nil ) then return end
 k = e.track
 i = e.track_i
 e.track_i = i+2
 if( i > count(k) ) then 
  del(ents,e) 
  return
 end
 x = k[i] y = k[i+1] 
 tw = move_to(e,x,y,1)
 tw.curve = function(c) return c end
end

function bounce_x(e)
 	if( e.x <  e.ray or e.x > 127-e.ray ) then
 	 e.vx = -e.vx
 	end
end

-- shoot
function fire(e)
 local b = make_ent()
 b.x = e.x
 b.y = e.y
 b.ray = 1
 b.bad = e.bad
 b.anim = {6,6,7,7,6,6,8,8}
 b.kind = 1+e.bad
 b.bul = 1
 b.outlim = 4
 fx(2+b.bad)
 return b
end

function shoot_target(e,trg)
 b = fire(e)
 a = atan2(trg.y-e.y,trg.x-e.x)
 impulse(b,a,bullet_spd)
 return b
end

function shoot_circ(e,max)
 for i=0,max do
  impulse( fire(e), i/max,bullet_spd)
 end
end

function seek_trg(e)
 if( e.trg ~= nil and not e.trg.dead and e.t%10 > 0 ) then
  return
 end
 e.trg = nil
 best = 128
 for b in all(ships) do
  if( b.bad ~= e.bad ) then
   d = dist_to(e,b)
   if( d < best ) then
    best = d
    e.trg = b
   end  
  end
 end
end

function follow_trg(e)
 if( e.trg == nil ) then return end
 a = atan2(e.vy,e.vx)
 dx = e.trg.x-e.x
 dy = e.trg.y-e.y
 da = atan2(dy,dx) - a
 if( da > 0.5 ) then da = da-1 end
 if( da <-0.5 ) then da = da+1 end
 a = a+da*e.cva 
 e.vx = cos(a)*e.spd
 e.vy = sin(a)*e.spd
end

function dist_to(a,b)
 dx = a.x-b.x
 dy = a.y-b.y
 return sqrt(dx*dx+dy*dy)
end

function impulse(e,an,spd)
 e.vx = cos(an)*spd
 e.vy = sin(an)*spd
end

-- tools ( ent )
function out(e,ma)
 return e.x < ma or e.y < ma or e.x > 127-ma or e.y > 127-ma
end

function check_out(e)
 ma = -e.outlim
 if( out(e,ma) ) then del(ents,e) end
end

function move_to(e,tx,ty,spd)
 tw = {}
 tw.sx = e.x
 tw.sy = e.y
 tw.ex = tx
 tw.ey = ty
 dx = tx-e.x
 dy = ty-e.y
 dist = max(sqrt(dx*dx+dy*dy),0.1)
 tw.spc = spd/dist
 tw.c = 0
 tw.curve = function(c) return 0.5-cos(c/2)*0.5 end 
 e.tw = tw
 return tw 
end

-- collisions / damages
function col(a,b)
 if( a.bad == b.bad
  or a.bul+b.bul == 2 
  or a.ghost or b.ghost ) 
 then return false end 
 adx = abs(a.x-b.x)
 ady = abs(a.y-b.y)
 lim = a.ray+b.ray
 return adx < lim and ady < lim
end

function impact(a,b)
 dmg_a = a.life
 dmg_b = b.life
 if( b.shield <= 0 ) then dmg_a = dmg_a+a.pierce end
 if( a.shield <= 0 ) then dmg_b = dmg_b+b.pierce end
 damage(a,dmg_b,b)
 damage(b,dmg_a,a)
end

function damage(e,dmg,from)

 display = e
 display_t = 30
 
 if( e.pierce == 1 ) then
  add_anim(from.x-4,from.y-4,{42,42,43,43,44,44})

	end
 
 snd = -1
 mute = dmg < 1
 
 if(e.inv==1) then
  fx(5)
  add_anim(from.x,from.y,{12,12})
  return
 end
 
 if( e.shield > 0 ) then
  e.shield = e.shield-dmg
  dmg = -e.shield
  if( dmg < 0 ) then dmg = 0 end
  e.tsh = 1
  snd = 6
 end
 
 if( dmg > 0 ) then
  e.life = e.life-dmg
  e.flash = 4
  if( e.bul == 0 ) then snd = 4 end
 end
 
 if( snd >= 0 and not mute ) then fx(snd) end 
 
end

function explode(e)
 kill(e)
 if( e.bul == 0 ) then
  exp = {}
  exp.x = e.x
  exp.y = e.y
  exp.t = 0
  add(explosions,exp)
  fx(1)
 end
 
 if( e.score~= nil ) then
  score = score + e.score
  s = {}
  s.x = e.x s.y = e.y
  s.s = e.score
  s.t = 0
  add(scores,s)
 end
 
 if( e == hero )then
  music(-1)
  sfx(9,2)
  delay(30,game_over)
  for i=0,12 do
   p = emit(e)
   p.frict = 0.9
   impulse(p,i/12,4)
   p.upd = function(e)
    e.fr = 26+(t/2)%2
    if( e.t > 20 ) then 
     kill(e) 
    end
    for b in all(ships) do
     if( dist_to(b,e) < b.ray+8 ) then
      explode(b)
     end
    end
   end
   
  end
 end
end

function game_over()
 gmo = {}
 gmo.t = 0
end

function delay(t,f,r)
 d = {}
 d.f = f
 d.t = 0
 d.rate = t
 d.r = 0
 if( r~= nil ) then d.r = r end
 add(delays,d)
end

function kill(e)
 if( e.fam == 1 ) then del(ships,e) end
 del(ents,e)
 e.dead = 1
 
end

-- fx
function add_queue(x,y,ex,ey,qt)
 q = {}
 q.x = x
 q.y = y
 q.ex = ex
 q.ey = ey
 q.t = 0
 q.qt = qt
 if( qt == 1 ) then 
  q.ey = q.ey + scroll_spd
 end
 add(queues,q)
end

function add_anim(x,y,frames)
 a = {}
 a.x = x
 a.y = y
 a.frames = frames
 a.i = 1
 a.spd = 1
 add(anims,a)
 return a
end

-- tools
function atan2(dy,dx)
 local q = 0.125
 local a = 0
 local ay = abs(dy)
 if( ay == 0 ) then 
  ay = 0.001
 end 
 if( dx >= 0 ) then
  local r = (dx-ay)/(dx+ay)
  a = q - r*q
 else
  local r = (dx+ay)/(ay-dx)
  a = q*3 - r*q
 end
 if( dy >  0 ) then a = -a end 
 return a
end

function sqrt(n)
 local i = 0
 while(i*i <= n) do
  i = i+1
 end
 i = i-1
 local d = n-i*i
 local p = d/(2*i)
 local a = i+p
 return a -(p*p)/(2*a)
end

function fx(n) sfx(n,3) end


function cyc(n)
 return (t%(n*2))<n
end

-- menu
function upd_menu()
 rectfill(0,0,127,127,0)
 
 -- lines
 cy = 60
 mx = 4
 hy = 100-- + cos(t%177/177)*10
 for i=0,mx do
  c = ((t+i*cy/mx)%cy)/cy
  y = hy+c*c*c*(128-hy)
  line(0,y,127,y,1)
 end
 ec = 8
 mx = 16
 c = 0.5+cos((t%163)/163)*0.1
 for x=0,mx do
  ex = 128*(1-c)+(x*ec-(128*c))*8
  line(x*ec,hy,ex,127,1) 
 end
 
 
 if( m.step == 0 ) then
  cols = {1,1,1,13,12,7}
  for i=0,15 do 
   pal(i,cols[1+flr(m.t/2)]) 
  end
  if( m.t/2 == count(cols) ) then
   m.step = m.step+1
  end
 else
  pal()
 end
 
 function ps (k)
  if(cyc(k)) then
   print("press action to start",22,90,7)
  end
 end
 
 if( m.step == 1 ) then
 	ps(8)
 	if( btnp(4) ) then
 	 m.step = m.step+1
 	 m.t = 0
 	 fx(8)
 	 music(-1,800)
 	end
 end
 if( m.step == 2 ) then
  ps(1)
 	if( m.t == 20 ) then
   launch()
 	end
 end 
 sspr(9*8,4*8,35,16,(128-70)/2,4,70,32)
end

--
function rand_pos(ma)
 if( ma == nil ) then ma = 8 end
 return ma + rnd(128-ma*2)
end

-- mod
function reset_m()
 m = {}
 m.t = 0
 m.step = 0
end

---------------------
----- draw func -----
---------------------
function draw_ent(e)
 if( e.invis ) then return end
 
 if(e.flash > 0 ) then
  for i=0,15 do pal(i,7) end
 end
 
 -- frame
 fr = e.fr
 if( e.anim ~= nil ) then
  fr = e.anim[1+t%count(e.anim)]
 end
 if( fr >= 0 ) then
  spr( fr, e.x-4, e.y-4 )
 end
 
 -- specific draw
 for d in all(e.draws) do d(e) end

 -- shield anim
 if( e.tsh > 0 ) then
 	c = {7,12,1}
  circ(e.x,e.y,e.ray+4,c[flr(e.tsh/2)])
  e.tsh = e.tsh+1
  if( e.tsh == 8 ) then 
   e.tsh = 0
  end
	end
	
 pal()
end

function draw_reac(e)
 k = t%4
 sspr(13*8+(k%2)*4,flr(k/2)*4,4,4,e.x-2,e.y+4,4,4)
end

function draw_game()
 rectfill(0,0,127,127,0)
 -- stars
 for s in all(stars) do
  pset(s.x,(s.y+t*s.c)%128,s.col)
 end
 -- queues
 for q in all(queues) do
  
  c = sget(q.t,30)
  if( q.t >=6 ) then c = 1 end
  if( q.qt == 2 ) then 
   c = sget(t%4,29)
  end
  q.t = q.t+1
  line(q.x,q.y,q.ex,q.ey,c)
  q.y = q.y+scroll_spd
  q.ey = q.ey+scroll_spd
  if( q.t > 20 or q.qt > 1 ) then
   del(queues,q)
  end
 end
 
 -- explosions
 for exp in all(explosions) do
  local fr = flr(exp.t*0.5) 
  sspr(fr*16,8,16,16,exp.x-8,exp.y-8,16,16)
  local c = {7,6,12,13,1,1}
  if( exp.t < 6 ) then 
   local ray = 4+(2-2/(exp.t+1))*16
   circ(exp.x,exp.y,ray,c[exp.t+1])
  end
  exp.t = exp.t+1
  if( exp.t == 10 ) then 
   del(explosions,exp)
  end
 end
  
 -- ents
 foreach(ents,draw_ent)
 
 -- anims
 for a in all(anims) do
  fr = a.frames[flr(a.i)]
  if( fr == nil ) then
   del(anims,a)
  else
   a.i = a.i+a.spd
   spr(fr,a.x,a.y)
  end
 end
 
 -- score
 print(score,64,0,7)
 
 -- scores
 for s in all(scores) do
  s.t = s.t+1
  s.y = s.y - 0.4
  if( s.t == 16 ) then
   del(scores,s)
  else
   if( s.y < 118 ) then
    print(s.s,s.x-4,s.y-2,sget(s.t,31))
   end
  end
 end
 -- game over
 if( gmo ~= nil ) then
  m.t = 0
  gmo.t = gmo.t+1
  c = sget(2+cos(t%40/40)*2,30)
  rectfill(0,61,127,67,1)
  print("game over",46,62,sget(max(16-gmo.t,0),31))
  if( btn(4) ) then
   if( gmo.ok ) then reset() end
  else
   gmo.ok = 1
  end
 end
 -- missiles
 for i=1,mis_max do
  x = 14
  if( i <= hero.mis ) then x = x+1 end
  sspr(x,24,1,5,128-i*2,122,1,5)
 end
 
 -- display bar
 if( display ~= nil ) then
  e = display
  py = 116
  --
  for i=0,e.life_max+1 do
   if( i < e.life+1 ) then 
    fr = 1
   else
    if( i < e.life+e.shield+1 ) then
     fr = 2
    else
     fr = 3
    end
   end
   if( i == e.life_max+1 ) then
    fr = 6
   end
   if( i == 0 ) then fr = 0 end
   sspr(fr*2,24,2,5,1+i*2,122,2,5)
  end
  print(e.name,1,116,7)  
  display_t = display_t-1
  if( display_t == 0 ) then display = nill end
 end
end

-- native
function _init()
 if( jump_to_game ) then
  launch()
 else
  reset()
 end
end

function _update()
 t = t+1
 m.t = m.t+1
 m.upd() 
 for d in all(delays) do
  d.t = d.t+1
  if( d.t == d.rate ) then
   d.f()
   if( d.r > 0 ) then
    d.r = d.r-1
    d.t = 0
   else del(delays,d) end
  end
 end
end

function _draw()
 if(m.draw ~= nil ) then
		m.draw()
 end
 if( log ~= nil ) then
  print(log,0,0,7)
 end
end






