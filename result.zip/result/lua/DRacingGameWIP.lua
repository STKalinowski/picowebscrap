--racer demo

i=0
ply={}
ply[1]={p={0,2,-1},v={0,0,0},r=0.5,s=0,tn={0,1,0},n={0,1,0},cr=0.5}
sprpos={}
play2=false

--viewport globals
vpx=64
vpy=64
vpsx=64
vpsy=64

xbase=-192
xdiv=10
zbase=-256
zdiv=12
divfact=30
allow=25
fcol=false

sqrt0 = sqrt
function sqrt(n)
	if (n <= 0) return 0
	if (n >= 32761) return 181.0
	return sqrt0(n)
end

ac = {}
coldiv = {}
function prepcol()
	rectfill(0,0,128,128,0)
	local j=1
	for i=1,5,1 do
		local m=mdls[i]
		local t=m.t
		for k=1,m.tl,1 do
			if (m.c[k]~=0) do
			local v={v_cln(m.v[t[k][1]]), v_cln(m.v[t[k][2]]), m.v[t[k][3]]}
			v_sub(v[1],v[3])
			v_sub(v[2],v[3])
			local n={v[1][2]*v[2][3]-v[1][3]*v[2][2], (v[1][3]*v[2][1]-v[1][1]*v[2][3]), v[1][1]*v[2][2]-v[1][2]*v[2][1]}
			v_scl(n, 1/128)
			v_nrm(n)
			v_nrm(n)
			ac[j]={m.v[t[k][1]], m.v[t[k][2]], v[3], n, m.c[k]}
			j+=1
			end
		end
	end
	local s=1
	for x=0,xdiv-1,1 do
		for z=0,zdiv-1,1 do
			rectfill(0,0,128,128,0)
			print("loading... ", 0, 0, 15)
			print(s, 44, 0, 15)
			print("/120", 56, 0, 15)
			coldiv[s]={t={},tl=0}
			local rel={xbase+(x+0.5)*divfact, 0, zbase+(z+0.5)*divfact}
			local o=1
			for i=1,j-1,1 do
				t=1
				ellipsevtri({0,6,0}, {0,-10,0}, {v_scl(v_sub(v_cln(ac[i][1]),rel), 1/allow), v_scl(v_sub(v_cln(ac[i][2]),rel), 1/allow), v_scl(v_sub(v_cln(ac[i][3]),rel), 1/allow), ac[i][4]})
				if (t<1) then 
					coldiv[s].t[o]=ac[i]
					o+=1
				end
			end
			coldiv[s].tl=o-1
			s+=1
		end
	end
	fcol=true
end

function _update()
	for j=1,1,1 do
		local p=ply[j]
		if (btn(2,j-1)) then
			p.s+=0.02
		elseif (btn(3,j-1)) then
			p.s-=0.02
		end
		p.s=mid(-0.5,p.s*0.98,0.5)
		if (btn(1,j-1)) then p.r=(p.r+0.01) end
		if (btn(0,j-1)) then p.r=(p.r-0.01) end
		p.cr+=(p.r-p.cr)/7

		p.v[1]=sin(p.r)*p.s
		p.v[3]=cos(p.r)*p.s
		p.v[2]-=0.02

		v_scl(p.n,0.8)
		v_add(p.n,v_scl(v_cln(p.tn),0.2))
		v_nrm(p.n)

		local colset=coldiv[flr((p.p[1]-xbase)/divfact)*zdiv+flr((p.p[3]-zbase)/divfact)+1]
		local c={steps=0,rt=1,vs=v_cln(p.v),ps=v_cln(p.p)}
		while (c.steps<3 and c.rt>0.01) do
			t=1
			colplane = nil
			for c=1,colset.tl,1 do
				ellipsevtri(p.p, p.v, colset.t[c])
			end
			if (colplane ~= nil) do
				v_scl(c.vs,t)
				v_add(c.ps,c.vs)

				local n=v_cln(c.ps)
				v_sub(n,colpoint)
				v_nrm(n)
				local mn=n
				if (colplane[4][2]>0.6) then
					p.tn=n
				else
					local xz=sqrt(n[1]*n[1]+n[3]*n[3])
					mn={n[1]/xz,0,n[3]/xz}
					p.s*=0.9
				end
				local proj=v_dot(mn,p.v)
				v_sub(p.v, v_scl(v_cln(mn), proj))
				c.ps=v_add(v_scl(v_cln(n),1.01),colpoint)

				c.rt-=t*c.rt
				c.vs=v_cln(p.v)
				v_scl(c.vs,c.rt)
			else
				v_add(c.ps,c.vs)
				c.rt=0
			end
			c.steps+=1
		end
		p.p = c.ps
	end
end

function _draw()
	local y=i
	if ((ply[1].p[1]<-45 and ply[1].p[3]>-75) or ply[1].p[3]>28) then
		memset(0x6000, 0x00, 0x2000)
	else
		memset(0x6000, 0xcc, 0x2000)
	end

	viewport(0,0,128,128)
	drawscn(ply[1])
	spr(0,100,74,3,6)
	spr(96,117+ply[1].p[1]*0.14,105+ply[1].p[3]*0.14)
end
tm=0
function drawscn(p)
	local mat=m_new()
	local proj=m_nproj(0.25,vpsx/vpsy,0.1,1)
	m_scale(proj, {vpsx, vpsy, -1})
	m_trans(mat,{0,-0.5,3})
	m_rotx(mat,0.05)
	m_roty(mat, p.cr)

	m_trans(mat, {-p.p[1],-p.p[2],-p.p[3]})
			
	m_mul(proj, mat)

	if (p.p[1]>-45) then
		if (p.p[3]>-190.5 and p.p[3]<-75) rendermdl(mdls[2],proj)
		if (p.p[2]>22) then
			if (p.p[3]<-190.5) rendermdl(mdls[4],proj)
			rendermdl(mdls[3],proj)
		else 
			if (p.p[3]>28) then rendermdl(mdls[5],proj)
			else rendermdl(mdls[1],proj) end
		end 
	else
		if (p.p[3]>-75) then rendermdl(mdls[5],proj)
		else rendermdl(mdls[4],proj) end
	end
	draw3d()
	for j=1,1,1 do
		local p=ply[j]
		local proj=m_nproj(0.25,vpsx/vpsy,0.1,1)
		m_scale(proj, {vpsx, vpsy, -1})
		m_trans(mat, {p.p[1],p.p[2],p.p[3]})
		local g=gramshmidt(p.n,{1,0,0},{0,0,1})
		m_mul(mat, {g[2][1],g[2][2],g[2][3],0,g[1][1],g[1][2],g[1][3],0,g[3][1],g[3][2],g[3][3],0,0,0,0,1})
		m_roty(mat, -p.r)
		m_mul(proj, mat)
		rendermdl(mdls[6],proj)
		rendermdl(mdls[7],proj)
	end
	draw3d()
	tm+=0.04
end

function viewport(x,y,w,h)
	clip(x,y,w,h)
	vpsx=w/2
	vpsy=h/2
	vpx=x+vpsx
	vpy=y+vpsy
end

function readmdl(ptr)
	local tl=(peek(ptr)+peek(ptr+1)*256)/6
	local t={}
	ptr+=2
	for i=1,tl,1 do
		local n={}
		for j=1,3,1 do
			n[j]=peek(ptr)+peek(ptr+1)*256
			ptr+=2
		end
		t[i]=n
	end

	local vl=(peek(ptr)+peek(ptr+1)*256)/9
	local v={}
	ptr+=2
	for i=1,vl,1 do
		local n={}
		for j=1,3,1 do
			n[j]=peek(ptr)/63356+peek(ptr+1)/256+peek(ptr+2)
			if (n[j]>127) n[j]=n[j]-256
			n[j]*=2
			ptr+=3
		end
		v[i]=n
	end

	local cl=(peek(ptr)+peek(ptr+1)*256)
	local c={}
	ptr+=2
	for i=1,cl,1 do
		c[i*2-1] = peek(ptr)%16
		c[i*2] = flr(peek(ptr)/16)
		ptr+=1
	end
return {t=t,tl=tl,v=v,vl=vl,c=c,cl=cl*2,ptr=ptr}
end

map={2,4,4,3,1,1,2}

function genflag(si)
	local out={t={},tl=0,v={},vl=0,c={},cl=0}
	for y=0,5,1 do
		local i=y*0.1+si+0.015
		local c=8+flr(y/2)
		for x=0,9,1 do
			local yx=y*11
			out.t[out.tl+1]={yx+x+1, yx+x+2, yx+x+12}
			out.t[out.tl+2]={yx+x+2, yx+x+12, yx+x+13}
			out.tl+=2
			local shade = (i+0.25)%1>0.5
			if ((x+y)%2==0) then
				nc=map[c-7]
				if (shade) nc=c
			else
				nc=0
				if (shade) nc=5
				c+=1
			end
			out.c[out.cl+1]=nc
			out.c[out.cl+2]=nc
			out.cl+=2
			i+=0.06
		end
	end

	for y=0,6,1 do
		local i=y*0.1+si
		local c=8+y
		for x=0,10,1 do
			out.v[out.vl+1]={x,y,sin(i)*x/5}
			out.vl+=1
			i+=0.06
		end
	end
	return out
end

function _init()
	mdls={};
	ptr=0x1000
	mdlt=peek(ptr)
	ptr+=1
	for i=1,mdlt,1 do
		mdls[i]=readmdl(ptr)
		ptr=mdls[i].ptr
	end
	prepcol()
end

--clipper, heap sort
--heaps with "s" as sort number, anything else as data

function h_new()
	return {h={}, l=0}
end

triheap=h_new()

function h_add(h, i)
	h.l+=1
	h.h[h.l]=i
	local t=h.l
	local p=flr(t/2)
	while (t != 1 and i.s>h.h[p].s) do
		local s=h.h[t]
		h.h[t]=h.h[p]
		h.h[p]=s
		t=p
		p=flr(t/2)
	end
end

function h_get(h)
	local r=h.h[1]
	h.h[1]=h.h[h.l]
	h.l-=1
	h_impose(h,1)
	return r
end

function h_impose(h,i)
	local c=i*2
	if (c>h.l) return
	local lc=h.h[c]
	if (c+1<=h.l and h.h[c+1].s>lc.s) then
		c+=1
		lc=h.h[c]
	end
	if (h.h[i].s<lc.s) then
		h.h[c]=h.h[i]
		h.h[i]=lc
		h_impose(h,c)
	end
end

function rendertxt(m,l,p,c,m4)
	local tp=v_proj(p,m4)
	if (tp[3]<0.25) return
	h_add(triheap, {t={m=m,x=tp[1]/tp[4]+vpx-l*4,y=tp[2]/tp[4]+vpy-4,c=c},m="m",s=tp[3]})
end

function renderspr(p,x,y,w,h,dw,dh,m4)
	tp=v_proj(p,m4)
	dw=-dw/tp[4]
	dh=-dh/tp[4]
	if (tp[3]<0.25) return
	h_add(triheap, {t={x,y,w,h,tp[1]/tp[4]+vpx-dw,tp[2]/tp[4]+vpy-dh,dw*2,dh*2},m="s",s=tp[3]})
end

function rendermdl(mdl,m4)
	--project verts
	local pv={}
	for i=1,mdl.vl,1 do
		pv[i]=v_proj(mdl.v[i],m4)
	end

	--draw tris
	for i=1,mdl.tl,1 do
		local t=mdl.t[i]
		local ct=cliptri({pv[t[1]], pv[t[2]], pv[t[3]]}, 0.25)
		for j=1,ct.l,1 do
			t=ct.t[j]
			local nt={t={t[1][1]/t[1][4]+vpx, t[1][2]/t[1][4]+vpy, t[2][1]/t[2][4]+vpx, t[2][2]/t[2][4]+vpy, t[3][1]/t[3][4]+vpx, t[3][2]/t[3][4]+vpy}, c=mdl.c[i], s=farz(t[1][3], t[2][3], t[3][3]), m="t"}
			if(mdl.c[i]==3)nt.s=20000
			h_add(triheap,nt)
		end
	end
end

cp2sel={{1,2,3},{2,1,3},{3,2,1}}
cp1sel={{2,3,1},{1,3,2},{1,2,3}}

function cliptri(t, nz)
	local c={0,0,0}
	local m=0
	local clp={}
	for i=1,3,1 do
		if (t[i][3]<nz) c[i]=1 m+=1
	end
	if (m==0) then return {t={t}, l=1}
	elseif (m==1) then
		--1 pt out, split into 2 tris
		for i=1,3,1 do
			if (c[i]==1) then
				clp=cp1sel[i]
				clp={t[clp[1]], t[clp[2]], t[clp[3]]}
				break
			end
		end
		local nt={}
		local m1=(nz-clp[1][3])/(clp[3][3]-clp[1][3])
		local m2=(nz-clp[2][3])/(clp[3][3]-clp[2][3])
		nt[1]={
			{clp[1][1]*(1-m1)+clp[3][1]*m1,clp[1][2]*(1-m1)+clp[3][2]*m1,nz,clp[1][4]*(1-m1)+clp[3][4]*m1},
			{clp[2][1]*(1-m2)+clp[3][1]*m2,clp[2][2]*(1-m2)+clp[3][2]*m2,nz,clp[2][4]*(1-m2)+clp[3][4]*m2},
			clp[2]
		}
		nt[2]={clp[1],clp[2],nt[1][1]}
		return {t=nt,l=2}
	elseif (m==2) then
		--2 pts out, just fix single tri
		for i=1,3,1 do
			if (c[i]==0) then
				clp=cp2sel[i]
				clp={t[clp[1]], t[clp[2]], t[clp[3]]}
				break
			end
		end
		local m1=(nz-clp[1][3])/(clp[2][3]-clp[1][3])
		local m2=(nz-clp[1][3])/(clp[3][3]-clp[1][3])
		return {t={{
			{clp[1][1]*(1-m1)+clp[2][1]*m1,clp[1][2]*(1-m1)+clp[2][2]*m1,nz,clp[1][4]*(1-m1)+clp[2][4]*m1},
			{clp[1][1]*(1-m2)+clp[3][1]*m2,clp[1][2]*(1-m2)+clp[3][2]*m2,nz,clp[1][4]*(1-m2)+clp[3][4]*m2},
			clp[1]}
		}, l=1}
	else
		return {t={}, l=0}
	end
end

function farz(z1,z2,z3)
	if (z2>z1) z1=z2
	if (z3>z1) z1=z3
	return z1
end

function draw3d()
	while (triheap.l>0) do
		local t=h_get(triheap)
		if (t.m=="t") then dt(t.t, t.c)
		elseif (t.m=="s") then ds(t.t)
		elseif (t.m=="m") then dm(t.t) end
	end
end

-- mat lib
function m_new()
	return {1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1}
end

function m_scale(m,v)
	for i=1,3,1 do
		for j=0,11,4 do
			m[i+j]*=v[i]
		end
	end
end

function m_mul(m,m2)
	local t=m_cln(m)
	local b={}
	for i=1,16,4 do
		b={m2[i],m2[i+1],m2[i+2],m2[i+3]}
		for j=1,4,1 do
			m[i+j-1]=b[1]*t[j]+b[2]*t[j+4]+b[3]*t[j+8]+b[4]*t[j+12]
		end
	end
end

function m_nproj(fovy,aspect,near,far)
	local f=1/(-tan(fovy/2))
	local nf=1/(near-far)
	return {f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*nf,-1,0,0,2*far*near*nf,0}
end

function m_cln(m)
	local nm={}
	for i=1,16,1 do
		nm[i]=m[i]
	end
	return nm
end

function m_trans(m, v)
	m[13] += m[1]*v[1]+m[5]*v[2]+m[9]*v[3]
	m[14] += m[2]*v[1]+m[6]*v[2]+m[10]*v[3]
	m[15] += m[3]*v[1]+m[7]*v[2]+m[11]*v[3]
	m[16] += m[4]*v[1]+m[8]*v[2]+m[12]*v[3]
end

function m_rotx(m,r)
	local s=sin(r)
	local c=cos(r)
	m5=m[5]
	m6=m[6]
	m7=m[7]
	m8=m[8]
	m[5]=m5*c+m[9]*s
	m[6]=m6*c+m[10]*s
	m[7]=m7*c+m[11]*s
	m[8]=m8*c+m[12]*s
	m[9]=m[9]*c-m5*s
	m[10]=m[10]*c-m6*s
	m[11]=m[11]*c-m7*s
	m[12]=m[12]*c-m8*s
end

function m_roty(m,r)
	local s=sin(r)
	local c=cos(r)
	m1=m[1]
	m2=m[2]
	m3=m[3]
	m4=m[4]
	m[1]=m1*c+m[9]*s
	m[2]=m2*c+m[10]*s
	m[3]=m3*c+m[11]*s
	m[4]=m4*c+m[12]*s
	m[9]=m[9]*c-m1*s
	m[10]=m[10]*c-m2*s
	m[11]=m[11]*c-m3*s
	m[12]=m[12]*c-m4*s
end

-- vec lib
function v_new()
	return {0,0,0}
end

function v_cln(v)
	return {v[1],v[2],v[3]}
end

function v_nrm(v)
	local i=1/sqrt(v_dot(v,v))
	v_scl(v,i)
end

function v_mul(v,v2)
	v[1]*=v2[1]
	v[2]*=v2[2]
	v[3]*=v2[3]
end

function v_scl(v,i)
	v[1]*=i
	v[2]*=i
	v[3]*=i
	return v
end

function v_add(v,v2)
	v[1]+=v2[1]
	v[2]+=v2[2]
	v[3]+=v2[3]
	return v
end

function v_sub(v,v2)
	v[1]-=v2[1]
	v[2]-=v2[2]
	v[3]-=v2[3]
	return v
end

function v_dot(v,v2)
	return v[1]*v2[1]+v[2]*v2[2]+v[3]*v2[3]
end

function v_proj(v,m)
	local w=m[4]*v[1]+m[8]*v[2]+m[12]*v[3]+m[16]
	return {(m[1]*v[1]+m[5]*v[2]+m[9]*v[3]+m[13]), (m[2]*v[1]+m[6]*v[2]+m[10]*v[3]+m[14]), (m[3]*v[1]+m[7]*v[2]+m[11]*v[3]+m[15]), w}
end

function tan(x)
	return sin(x)/cos(x)
end

function ds(t)
	sspr(t[1],t[2],t[3],t[4],t[5],t[6],t[7],t[8])
end

function dm(t)
	print(t.m,t.x,t.y,t.c)
end

function dt(t,c)
	if ((t[1]<0 and t[3]<0 and t[5]<0) or (t[1]>128 and t[3]>128 and t[5]>128)) return
	eqp={}
	ymin=32000
	ymax=-32000
	for i=0,2,1 do
		m1=t[2*i+2]
		if (ymin>m1) then
			ymin=m1
			ymini=i
		end
		if (m1>ymax) then
			ymax=m1
			ymaxi=i
		end
		eqp[i+1]=(t[2*((i+1)%3)+1]-t[2*i+1])/(0.0001+t[2*((i+1)%3)+2]-m1)
	end
	if (ymini~=0 and ymaxi~=0) then
		ymid=t[2]
		ymidi=0
	elseif (ymini~=1 and ymaxi~=1) then
		ymid=t[4]
		ymidi=1
	else
		ymid=t[6]
		ymidi=2
	end

	if (ymid>0) then
		y=ymin
		x1=t[ymini*2+1]
		x2=x1
		m1=eqp[ymini+1]
		m2=eqp[((ymini+2)%3)+1]
		if (0>y) then
			x1 -= m1*y
			x2 -= m2*y
			y=0
		end
		for i=0,min(ymid,128)-y+0.1,1 do
			rectfill(x1,y,x2,y+1,c)
			y+=1
			x1+=m1
			x2+=m2
		end
	end

	if (ymid<128) then
		y=ymax
		x1=t[ymaxi*2+1]
		x2=x1
		m1=-eqp[ymaxi+1]
		m2=-eqp[((ymaxi+2)%3)+1]
		if (y>128) then
			x1 += m1*(y-128)
			x2 += m2*(y-128)
			y=128
		end
		for i=0,y-max(0,ymid)+0.1,1 do
			rectfill(x1,y,x2,y+1,c)
			y-=1
			x1+=m1
			x2+=m2
		end
	end
end

function ellipsevtri(pos, dir, tri)
	local dist = v_dot(tri[4], pos) -v_dot(tri[4], tri[1])
	if (dist < 0) then
		v_scl(tri[4], -1)
		dist *= -1
	end
	local moddir = v_dot(tri[4], dir)
	local t0, t1, embedded = false
	if (abs(moddir) < 1/128) then
		if (abs(dist) < 1) then
			t0 = 0 
			t1 = 1
			embedded = true
		else
			t0 = 1000 
			t1 = 2000
		end
	else
		t0 = (1-dist)/moddir
		t1 = ((-1)-dist)/moddir
	end
	if (t0 > t1) then
		local temp = t1
		t1 = t0
		t0 = temp
	end

	if (not (t0>1 or t1<0)) then
		if (t0 < 0) then 
			embedded = true 
			t0 = 0 
		end
		if (t1 > 1) t1 = 1

		local newt = t0

		local pt = v_cln(pos)
		if (embedded) then
			v_sub(pt, v_scl(v_cln(tri[4]),dist))
		else
			v_add(pt, v_scl(v_cln(dir),newt))
			v_sub(pt, tri[4]) 
		end
		if (pit(tri, pt, 0) and newt<t) then
			t = newt
			colplane = tri
			colpoint = pt
			return
		end

		if(fcol and (tri[5]==15 or tri[5]==7 or tri[5]==3)) return

		for j=1,3,1 do
			local vert = v_cln(pos)
			v_sub(vert, tri[j])
			v_scl(vert,1/8)

			local root = gsr(v_dot(dir, dir)/64, v_dot(dir, vert)/4, (v_dot(vert, vert)-1/64), t)
				
			if (root >= 0) then
				t = root
				colplane = tri
				colpoint = v_cln(tri[j])
			end
		end

		for j=1,3,1 do
			local vert = tri[j]

			local distvert = v_cln(vert)
			v_sub(distvert, pos)
			local distline = v_cln(tri[((j%3)+1)])
			v_sub(distline, vert)
			v_scl(distline,1/8)

			local edgedist = v_dot(distline, distline)
			local edgedotvelocity = v_dot(distline, dir)
			local edgedotvert = v_dot(distvert, distline)

			local root = gsr(
				(edgedist*(-1)*v_dot(dir, dir)+edgedotvelocity*edgedotvelocity), 
				(edgedist*2*v_dot(dir, distvert)-2*edgedotvelocity*edgedotvert), 
				(edgedist*(1-v_dot(distvert, distvert))+edgedotvert*edgedotvert), 
				t
			)

			if (root >= 0) then
				local edgepos = (edgedotvelocity*8*root - edgedotvert*8)/(edgedist*64)
				if (edgepos >= 0 and edgepos <= 1) then
					t = root
					colplane = tri
					v_scl(distline,edgepos*8)
					colpoint = v_cln(vert)
					v_add(colpoint,distline)
				end
			end
		end
	end
end

function gsr(a, b, c, upperlimit)
	local det = (b*b) - 4*(a*c)
	if (det<0) then return -1
	else 
		det = sqrt(det)
		local root1 = ((-b)-det)/(2*a)
		local root2 = ((-b)+det)/(2*a)

		if (root1 > root2) then
			local temp = root1
			root1 = root2
			root2 = temp
		end

		if (root1>0 and root1<upperlimit) then
			return root1
		elseif (root2>0 and root2<upperlimit) then
			return root2
		else
			return -1
		end
	end
end

function pit(tri, point, err) 
	local v0 = v_cln(tri[3])
	v_sub(v0, tri[1])
	local v1 = v_cln(tri[2])
	v_sub(v1, tri[1])
	local v2 = v_cln(point)
	v_sub(v2, tri[1])

	v_scl(v0,1/32)
	v_scl(v1,1/32)
	v_scl(v2,1/32)

	local dot00 = v_dot(v0, v0) 
	local dot01 = v_dot(v0, v1) 
	local dot02 = v_dot(v0, v2)
	local dot11 = v_dot(v1, v1) 
	local dot12 = v_dot(v1, v2)

	local inv = (dot00*dot11 - dot01*dot01)
	local u = (dot11*dot02 - dot01*dot12)/inv
	local v = (dot00*dot12 - dot01*dot02)/inv

	return (u>=-err and v>=-err and (u+v)<1+err)
end

function project(u,v)
	return v_scl(v_cln(u), (v_dot(u, v)/v_dot(u, u)))
end

function gramshmidt(v1, v2, v3)
	local u1 = v_cln(v1);
	local u2 = v_sub(v_cln(v2), project(u1, v2));
	local u3 = v_sub(v_sub(v_cln(v3), project(u1, v3)), project(u2, v3));
	v_nrm(u1)
	v_nrm(u2)
	v_nrm(u3)
	return {u1, u2, u3}
end