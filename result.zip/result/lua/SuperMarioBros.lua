a='130014501E8028121EE00A1EE06F502E8028122CE02C32502C5034003012330034385034223C00280224300300222A80180222200580222480580221980081211600300211500300221180300220C0050050460020124480244AE0241405004811220805012428003004280057280008288008288057253E8018043DC0213DC018440018440021224800580A050400010468010603140C0B400F473"~5!)*~R!)*~N!)*~Y!"!!"~5!9:~D!)*~-!9:~B!)*~+!9:~C!)*~$!-~.!)*!"!!"~\'!)*~R!9:~C!)*~,!9:~O!9:!!+,~.!9:!"!!"~\'!9:~8!~$Z~*!)*A~\'BC~-!~%Z~9!9:~P!)*~0!<~(!tqu~\'!"!)"~?!A~$BC~)!9:!l~%mn~.!ABBC~j!9:~0!<~(!syw~\'!"!9"~-!)*~2!lmn~-!l~%mn~/!ln~/!A~%BC~T!)*~)!%%~)!<~&!tq~$rqu~%!"!!"!t~$qu~\'!9:~2!lmn~\'!)*~%!l~%mn~,!)*!ln~0!lmmn~U!9:~)!%%~)!<~&!szzvzzw~%!"!!"!s~$xw~:!lmn~&!A~%BC!l~%mn~,!9:!ln~0!lmmn~<!A~\'BC~:!~%%~)!<~&!s~&zw~%!"!!"!syxyw~6!A~(BC~%!lmmn!!l~%mn~/!ln~0!lmmn~=!~\'m~&!ABBC!!ABBC~,!~%%~)!<~$!tq~(rqu!!"!!"t~&ru!!$!$!$!$!$!$~)!l~&mn~&!lmmn!!l~%mn!)*~,!ln~(!ABC!!)*!lmmn~/!)*~-!~\'m~\'!ln~%!ln~+!~\'%~)!<~$!s~$zvzv~$zw!!"!!"s~&xw~6!l~&mn~&!lmmn!!l~%mn!9:~*!$!ln~)!o~$!9:!lmmn~/!9:~&!~$Z~%!~\'m~\'!ln~%!ln~+!~\'%~)!<~$!s~*zw!!"!!"sx{v|xw~6!l~&mn!!Z!!lmmn!!l~%mn~/!ln~)!o~\'!lmmn~5!A~$BC~$!~\'m~\'!ln~%!ln~+!~\'%~)!<~$!szzvzvzvzzw!!"!!"sx{v|xw~.!A~$BC~$!l~&mn!ABC!lmmn!!l~%mn~/!ln~)!o~\'!lmmn~6!lmn~%!~\'m~\'!ln~%!ln~+!~\'%~)!%~$!szzvzvzvzzw!!"!!~3#~%!lmn~%!l~&mn!!o!!lmmn!!l~%mn~%!ABBC~%!A~$BC!A~$BC!o~\'!lmmn~6!lmn~%!~\'m!!ABC!ln~%!ln~%!~[#~%!lmn~%!l~&mn!!o!!lmmn!!l~%mn~&!ln~\'!lmn~$!lmn!!o~\'!lmmn~6!lmn~%!~\'m~$!o!!ln~%!ln~%!~I#'b='120124120500481210880580210800600210E80600150E80401131700381221600580221700580122300401152500401221E00580211F806002120806002125002002127004002128004002A34804012A37803812133006002134006002132006002A3A80481124B8040123498058021398060021450040021440048050468068124680664680625046803812468034468032504E0040124E003C4E0039504E0010124E000D4E000AB0590028115Welcome to warp zone!B05900401014B05B00401013B05D004010129052C04810408030A0311300C800F38EUIJ~$!TUT~{Q~IQ~Y!~&"UY~%!TUT~{Q~IQ~Y!~&"U~&!~{T~GTU~%T~8!UUTTU~5T~$!~+TU~&!~1Q!~/Q~2!TT~$!T~&UIJUUTT~\'!UTTUUIJ~)!~/Q~-!~/Q~E!78~&TUUIJ~,!T~+U~\'!~&Q./~%Q~\'!~&Q./~%Q~4!TT~$!~&TUY!U~$T~\'!~&UY~+!~&Q./~%Q~0!~&Q./~%Q~G!78T~\'UY~-!T~+U~)!QQ=>?@QQ~*!QQ=>?@QQ~(!~%Z~(!UT~*!TU~$!T~%!UT~,!~\'Z~$!QQ=>?@QQ~3!QQ=>?@QQ~H!78T~\'U~.!T~+U~*!QMNOPQ~,!QMNOPQ~4!UT~*!TU~$!T~%!UT~6!QMNOPQ~5!QMNOPQ~I!78T~\'U~.!T~+U~+!Q^_Q~.!Q^_Q~(!U!~%T!T~&!UT~*!TU~$!T~%!UT~,!U~%TU~&!Q^_Q~7!Q^_Q~J!78T~\'U~.!T~+U~=!U~*!UZU!!UZT~&!UT~&!~%ZTU~$!TZU!!UT~,!U~&T~X!UTUTT~/!G~$HT~\'U~.!T~+U~*!~&$~)!1!1~.!~$U!!UTT~&!U~$T~$!UU~$TU~$!~$T!!TT!!~$UTT~>!\'(~9!11~<!W~$XT~\'U~.!T~+U~5!1!1!1!1~$!1~7!UT~R!\'(~%!78~,!UU~+!~$1~7!~+T~\'U!\'(!!\'(!!\'(!!T~+U~3!1!1!1!1!1~$!1!1~5!UT~R!78~%!78~%!\'(~&!UU~*!~%1~7!~1U!78!!78!!78!!T~+U~1!1!1!1!1!1!1~$!1!1~h!78~%!78~%!78~&!UU~)!~&1~7!~1U!78!!78!!78!!~+T~s5~$!~F5!!55!!~,5~)!~(5~(!~{5~@5~$!~F5!!55!!~,5~)!~(5~(!~H5'c='110019142080401122800481153000481212A00200212B00200213180600213280600223700580133400481123800281213A80600213B80600214180600213F00600214280600214000600215980600215880600210B80600120B00481211480601211A00600211B00600901D404400804020003111A065400010460020003120C0E100F30A~{!~=!)*~{!~/!"~T!)*~/!)*~4!)*!)*~:!9:~s!-~6!"~5!)*~:!)*!!9:~/!9:~*!)*~)!9:!9:~/!)*~2!)*!)*~\'!)*)*~N!)*)*~,!+,!)*~3!"~5!9:~*!)*!)*~,!9:~:!)*!!9:~<!9:~2!9:!9:~\'!9:9:~N!9:9:~-!<!9:~3!"~@!9:!9:~G!9:~r!)*~C!D~)!<~6!"~(!)*~/!$~[!~)S~$!~$S$~0!$~,!~$S~%!S$$S~7!9:~B!DD~)!<~6!"~(!9:~{!~{!!!~$D~)!<~%!tqqu~.!"~{!~{!~+!~%D~)!<~%!sxxw~.!"~b!$~{!~B!~&D~)!<~%!syyw~.!"~2!$~$!S$S$S~6!\'(~*!\'(~4!S$S~/!S~\'!SS~%!$!!$!!$~&!S~+!SS~\'!D!!D~+!DD!!D~-!SS$S~.!~\'D~)!<~$!t~%ru~-!"~H!\'(~\'!78~*!78~p!DD!!DD~)!~$D!!DD~<!~(D~)!<~$!s~%xw~-!"~>!\'(~)!78~\'!78~*!78~o!~$D!!~$D~\'!~%D!!~$D~&!\'(~0!\'(!~)D~)!<~$!sxvvxw~-!"~$!ghi~,!ghi~\'!ghi78~)!78!ghi!!78!!ghi~%!78!!ghi~)!ghi~1!ghi~;!ghi~.!~%D!!~%Dghi!~&D!!~%Dhi!!78~0!78~*D~$!ghi!!D~$!sxvvxw~&!ghi~%!"~h#!!~0#~$!~S#!!~.#!!~{#~Q#!!~0#~$!~S#!!~.#!!~d#'d='1111019006405D10407A60A03110001000F06F~AQU~$Q~)U~$Q7UQQ~+!QQ7UQ~-!Q7U~%!~&Z~&!7U~/!7U~$!~(Z~%!7U~/!7U~$!~(Z~%!7U~$!~(U~%!7U~$!~(U!!GHHU~$!~(U!!WXX~A5'e='140111B04D0028110thank you mario!B04C0038118but your princess is in B04D004010Fanother castle!2F47803805046802812431028498028120F00301C00F00505C01800305C01D80305C02100305C02600485C02A00485C02C0020BC0280020DC02E0048AC01280301A04A803030818030A0321000AC00F2FA~{!~s!~{3~r3!~g3~=4~(3~84~&3~D4~$3!~;3~,!~B34~*!4~(!4~)!4~(34~.e!!de~%!4~&34~/!44~2d4~$3!~;4~,!~B34~*!4~(!4~)!~*4~.e!!de~%!~(4~/!44d~0ad4~$3~*!de!!de!!de!!de!!d4~,!~C4~C!de~+aee!!de~&!de~3!44da~.!ad4~$3~*!de!!de!!de!!de!!de~%!$~\'!%~+!%~+!%~\'!%~G!deaa~\'!aaee!!de~&!de~4!dda~.!ad4~$3!~&4~$!de!!de!!de!!de!!de~p!dea!!Z!Z!Z!aee!!de~&!de~4!dda~.!ad4~$3!~&34!!de!!de!!de!!dd!!de~p!dea~)!aee!!de~&!de~4!dda~.!ad4~$3!~\'34!de!!de!!de!!dd!!de~*!~E4~&!4~(!4~(!4~-!dea!Z!Z!Z!!aee!!de~&!de~2!~$4da~.!ad4~$3!~(3~(4!!~+4~$!3%3~$!4~C3~E4eaa~\'!aae~\'4~$!~(4~.V434da~.!ad4~$3!~.34!!4~)34~$!~$3~$!4~f34e~+ae4~%34~$!4~&34~.!434d~0ad4~$3!~.34!!4~)34~$!~$3~$!4~f34~-e4~%34~$!4~&34~.!434~2d4~$3!~.34KK4~)34~$K~$3~$K4~f3~/4~%3~&4~&34~.K43~44~$3!~.34[[4~)34~$[~$3~$[4~{3~(34~.[4~83!'f='1130022A0180481A00B300010560030A03130C02300F101""~<!"~&!""~%!)*~.!+,!)*~$!"~&!"~&!9:~/!<!9:~$!"~&!"~6!<~\'!"~&!"~6!<~\'!"~&!"~,!DD~)!<~\'!"~&!"~+!~$D~)!<~%!tqqu~%!"~*!~%D~)!<~%!sxxw~%!"~)!~&D~)!<~%!syyw~%!"~(!~\'D~)!<~$!t~%ru~$!"~\'!~(D~)!<~$!s~%xw~$!"!!\'(!~)D~)!<~$!s{vv|w~$!"!!78~*D~)!%~$!s{vv|w~$!~g#'g='21003324098058040180690180500E00500E0069240E005004068068068050101050101068211280600211C00600211B00600211A00600222080580212C00400212B00400212A00400122A00281120B00401132E80281213080600213180600223380580243C0030143880483880303E00303E0048243C0010143880283880103D80103D8028243A805014360068360050408050408068123B80281214800300214700400214600500214500600214280380214280200224D80180224D80380224F00180224D00580224B80580214F00600215000600215100600124F8048122550038024548050044F00684F005058005058006824510050045000685000505800505800682456805804520068520050580050580068226080180215F00300225D80400215880300215C00600A065400010468030B031102A10004012A13003812A1C804012A21804812A350038116428028100D800F39F~{!~{!~7!-~-!"~=!)*~1!)*~=!)*~3!)*~=!)*~2!)*~9!)*~2!)*~*!+,~-!"!tqqu~8!9:~1!9:!!)*~9!9:!)*)*~.!9:~&!)*)*~+!)*~(!9:!)*~/!9:!!)*~5!9:!)*~/!9:~$!)*~&!<~)!)*!!"!~$x{~.!)*~.!)*!)*~-!9:~/!)*~,!9:9:~5!9:9:~+!9:~+!9:~3!9:~8!9:~4!9:~&!<~)!9:!!"t~%ru~-!9:~.!9:!9:~=!9:~{!~(!)*~D!<~-!"~&x{~o!$~)!~$S~2!SS$~$S$~$S~)!SS$~4!S$S!!S$S~%!9:~:!%%~)!<~-!"xvxvx{~{!~{!~&!~$%~)!<~%!tqqu~%!"~\'ru~{!~P!%~A!%~-!~%%~)!<~%!|xxw~%!"~\'x{~-!$!!$~W!~,p~L!~$S~*!%%~A!%~,!~&%~)!<~%!|yyw~%!"xvxvxx{~*!$~*!~$S~*!\'(~6!S~/!%~,k%!!%~/!\'(~&!~,S~3!~$%~)!S$S!!S$S~(!S$~$S~%!%~+!~\'%~)!<~$!t~%ru~$!"~\'x{~:!\'(~%!78~2!\'(~1!%%~,!%!!%~/!78~B!~%%~@!%%~*!~(%~)!<~$!|~%xw~$!"vxvxvx{~:!78~%!78~2!78~)!\'(~&!~$%~,!%!!%%~.!78~A!~&%~@!%%~)!~)%~)!<~$!|xvvxw~$!"vxvxvx{!!ghi!!~%\\~%!ghi~(!78~%!78~,!ghi~$!78~$!~%\\!78~%!~%%~,]%]]%%~,!gh78~%!~%\\~\'!ghi~/!~\'%~,!ghi!!~%\\~*!gh%%~\'!\\~*%hi~\'!%~$!|xvvxw~$!"~N#~$!~>#~,`#``~H#~%!~,#!!~A#~$!~p#~$!~>#~,`#``~H#~%!~,#!!~A#~$!~C#'h='2112029029006812710A00003210500600481201804B28C04C005700F062~{!~{!~{!~{!~D!~(Z~-!~.Z~2!~3Z~$!~/Z~4!LL~d!L~*!L~\\!L~1!L~*!L~{!~{!~@!;~w!;~w!;~q!~\'L;~lL~,!;~q!'i={c,d,b,f,a,e,g} function j(k) local l={} local m=""for n=1,#k do local o=sub(k,n,n) if o==","then
add(l,m+0) m=""else m=m..o end end add(l,m+0) return l end p=0.0166667 q=6.98 r=0.781 s=1.35 t=1.5 u=0.046875 v=0.03125*2 w=0.078125/2 x=0.15625/2 y=0.046875 z=0.5 ba=nil bb=r bc=false bd=false be=false bf=0 bg=3 bh=nil bi=1 bj=0 bk=true bl=0.75 bm={bn=c,bo=32,bp=88,music=0} bq={} br=0 bs=0 bt=15 bu={} function bv(bw) music(bw==0 and 0 or(bw==1 and 11 or(bw==2 and 24 or 55))) end bv(0) function bx() local by=2 while by<128 do for bz=0,127,by do for ca=0,127,by do rectfill(bz,ca,bz+by-1,ca+by-1,pget(bz+rnd(by),ca+rnd(by))) end end cb(35) by*=2 end end function cc() local by=128 while by>1 do cls() cd() for bz=0,127,by do for ca=0,127,by do rectfill(bz,ca,bz+by-1,ca+by-1,pget(bz+rnd(1)*by,ca+rnd(1)*by)) end end by=flr(by/2) cb(35) end end function ce(cf,bz,ca) if cf<3 then
if ba.bn<1 then
cg(bz,ca) else ch(bz,ca) end elseif cf==3 then ci(bz,ca) elseif cf==4 then cj(bz,ca) elseif cf==5 then ck(bz/8,ca/8,true) elseif cf==6 then cl(bz,ca) end end function cm(bz,ca) local cn=co(bz,ca,8,16,0,0.1,0) cn:cp(1,1) cn.cq=false cn.cr=false cn.cs=false cn.ct=false cn.cu=1 cn.cv=300 cn.cw=0 cn.cx=3 cn.cy=0 cn.bn=1 cn.cz=0 cn.da=0 cn.db=false cn.dc=nil cn.dd=-1 cn.de=false cn.df=true cn.dg=dh(j"129,130,131,132,133",1,1,0.25,1) cn.di=dh(j"97,98,99",1,2,0.25,1) cn.dj=dh({128},1,1,0.25,0) cn.dk=dh({96},1,2,0.25,0) cn.dl=dh({100},1,2,0.25,0) cn.dm=dh({101},1,2,0.25,0) cn.dn=dh({198},1,1,0.25,0) cn.dp=dh({102},1,2,0,0) cn.dq=-1 cn.dr=ds(0.047,{j"1,13,7,8",j"5,7,6,8",j"1,2,5,9",j"2,14,7,11",j"1,2,5,9"}) cn.dt=cn.dk cn.du=dh({175},1,1,0.25,0) cn.dv=dh({111},1,2,0.25,0) cn.dw=false cn.dx=dy(0.1) cn.dz=0 cn.ea=0 cn.cd=function(eb) if not ba.ec then
return end if ba.da>0 then
ba.da-=1 if ba.da%2==0 then
return end end if ba.bn==1 and eb.dq>=0 then
local ed=j"1,2,1,2,1,2,3,1,2,3,1,3"if bh:ee() then
bi=bi>12 and 12 or bi+1 end local dt=ed[bi]==1 and ba.dj or(ed[bi]==2 and ba.dp or ba.dk) dt:cd(ba.bz,ba.ca-(ba.dj!=dt and 8 or 0),be,false) eb.dq-=1 if eb.dq<0 then
bi=1 ba.ca-=8 end else if ba.cz>0 or(ba.bn==2 and ba.dq>=0) then
ba.dr:ef() ba.cz-=1 ba.dq-=1 if ba.cz==30 then
bv(bm.music) end elseif eb.bn==2 then pal(1,5) pal(13,7) pal(7,6) pal(8,8) end local flip=be if ba.cr then
flip=ba.dw end eb.dt:cd(eb.bz,eb.ca,flip,false) pal() end end cn.eg=function(eh) if ba.de then
ba.ca+=8 ba.de=false end local ei=ba.cr and(ba.bn==0 and ba.du or ba.dv) or(ba.bn==0 and(eh.ej==0 and ba.dj or cn.dg) or(ba.ct and ba.dn or(not eh.cs and ba.dm or(eh.db and ba.dl or(eh.ej==0 and ba.dk or ba.di))))) if ei!=ba.dt then
if ei==ba.dn then
ba.ca+=8 elseif ba.dt==ba.dn then ba.ca-=8 end end ba.dt=ei ba.ek=(ba.bn==0 and 8 or(ba.ct and 8 or 16)) ba.dt.cv.el=p*(12/(1+1.5*abs(ba.ej))) ba.dt:eg() local cr=fget(em(flr((ba.bz+4)/8),flr((ba.ca+4)/8)),6) if not ba.cr and cr and btn(2) then
ba.cr=true ba.ea=0 ba.dz=0 elseif ba.cr and not cr then ba.cr=false ba.en=0.01 end if ba.cr then
ba.en=ba.ea ba.ej=ba.dz ba.ek=ba.bn>0 and 16 or 8 if ba.dz!=0 or ba.ea!=0 then
if ba.dx:ee() then
ba.dw=not ba.dw end end end eh:eo() if eh.ca>128 then
ep() end return eh.ec end cn.eq=function(self,er,es,et) if et==32 then
ck(er,es,false);eu(er,es,0);end end cn.ev=function(eh,ew,ex) if ba.en<0 then
local bw=em(ew,ex-1) local et=band(fget(bw),56) local ey=false local ez=bq[(ex-1)*256+ew] if et==16 then
if ez==nil then
ck(ew,ex-1,true) end fa(ew,ex-1,ez,3,4) ey=true elseif et==8 then if ez!=nil then
eu(ew,ex-1,4) ce(ez.cf,ew*8,(ex-1)*8);elseif ba.bn==0 then fa(ew,ex-1,ez,bw,bw) else sfx(8) eu(ew,ex-1,0) local fb=flr(bw/16) local fc=bw-fb*16 local fd=sget(2+fc*8,3+fb*8) fe(ew*8+4,(ex-1)*8+4,fd) end ey=true end if ey then
foreach(ff,function(cn) local fg,fh,fi,fj=fk(cn) if fl(ew*8+1,(ex-2)*8+1,6,6,fg,fh,fi,fj) then
if cn.cf==2 then
fm(cn) else cn.en=-2.85 end return end end) end end end fn(cn) return cn end function ck(er,es,cy) sfx(9) fo(er*8,es*8-8) if cy then
fp(100,er*8,es*8-8) end ba.cw+=1 if ba.cw>99 then
ba.cw=0 ba.cx+=1 sfx(10) end end function fk(fq) return fq.bz+fq.by,fq.ca+fq.fr,fq.fs-fq.by*2,fq.ek-fq.fr*2 end function ft() ba.ct=btn(3) local fu=btn(4) local fv=not ba.ct and btn(0) local fw=not ba.ct and btn(1) local fx=r local fy=u local fz=w if fu then
ba.dd=10 fx=s fy=u fz=x elseif ba.dd>0 and(fv==be or fw==be) then ba.dd-=1 fx=s fy=u fz=x else ba.dd=0 end if bk and not ba.cs then
local ga=s-r local bz=min(ga,2.5*max(0,abs(ba.ej)-r)) bl=bz+r elseif not ba.cs then fx=bl end ba.db=(fv and ba.ej>0) or(fw and ba.ej<0) local gb=(ba.db and fz or(not ba.cs and y or fy)) if fv or fw then
ba.ej+=(fv and-gb or gb) be=fv else local gc=0.999 if ba.cs then
gc=abs(ba.ej)>0.15 and 0.9 or 0 else fx=r end ba.ej*=gc end if fu then
if not gd and ba.bn==2 then
local ge=be and 0xfffa or 6 gf(ba.bz+ge,ba.ca+4,ge/3.5) sfx(13) end end if fx<bb then
bb*=0.95 fx=bb else bb=fx end ba.ej=min(fx,max(-fx,ba.ej)) local gg=btn(5) bj=gg and bj+1 or 0 if ba.cs or ba.gh<5 then
if(bj<5 or not bc) and gg then
gi() end elseif bc and not gg and ba.en<0 then ba.en*=0.25 end if ba.cr then
if fv then
ba.dz=-z elseif fw then ba.dz=z else ba.dz=0 end if btn(2) then
ba.ea=-z elseif btn(3) then ba.ea=z else ba.ea=0 end if not bc and gg then
gi() end end bc=gg gd=fu bk=ba.cs end function gi() bj=5 ba.cr=false ba.gh=5 ba.en=-2.8*(abs(ba.ej)*0.15+1) sfx(3) end function gj(ba,cn) cn.gk=true if ba.cq then
return end if((ba.ct and cn.cf==9 and not cn.gl) or
cn.cf==9 and cn.gl) or cn.cf==10 then for n=1,#i do local bw=sub(i[n],1,3) if bw==cn.gm then
bm={bn=i[n],bo=cn.bo,bp=cn.bp,} if cn.cf==10 then
fp(flr(((104-ba.ca)/104)*10)*500,ba.bz,128) gn=0 ba.cq=true music(-1) else music(-1) sfx(4) cb(300) sfx(4) cb(300) sfx(4) cb(300) ba.df=false go(i[n],cn.bo,cn.bp) end return end end end end function gp(ba,cn) if cn.gq==1 then
ba.dq=60 ba.bn=1 if ba.en<0 then
ba.en=-2.8 end sfx(5) elseif cn.gq==2 then ba.dq=60 ba.bn=2 sfx(5) elseif cn.gq==3 then ba.cz=750 music(24) elseif cn.gq==4 then ba.cx+=1 sfx(10) end fp(1000,ba.bz,ba.ca) gr(cn) end function gs(ba,cn) if cn.gt>0 and cn.ec then
if ba.en>0 and not ba.cs and cn.gu and cn.gv then
gw(cn) ba.ca-=ba.en ba.en=-2 elseif cn.gx!=nil and cn.gx==2 then sfx(12) cn:gy(ba.bz<cn.bz and-2 or 2) elseif ba.cz>0 and cn.gu then fm(cn) elseif ba.da<=0 then ba.ej=0 ba.bn-=1 ba.de=ba.bn==0 if ba.bn<0 then
cb(500) ep() else ba.da=90 gz=30 end end end end function ep() music(-1) ba.ec=false ba.bn=0 ba.cx-=1 local cn=ha(ba.bz,ba.ca,ba.ej/3,-3,4) cn.dt=ba.dt cn.gt=180 cn.hb=function(eh) cn.gt-=1 if cn.gt<=0 then
if ba.cx<0 then
color(0) cls() cursor(44,56) color(7) print("game over") flip() cb(3000) bv(0) ba=nil bm.bn=c bm.bo=32 bm.bp=88 hc=true else local hd=ba.cx go(bm.bn,bm.bo,bm.bp) ba.cx=hd end end end end function cb(he) for n=1,he/1000*60 do flip() end end function gw(cn) if cn.cf!=6 then
fp(cn.cy,ba.bz,ba.ca) end if cn.hf!=nil then
cn:hf() end sfx(12) end function fm(cn) sfx(12) if cn:hg() then
gr(cn) fp(cn.cy,cn.bz,cn.ca) local hh=ha(cn.bz,cn.ca,cn.ej,-2.2,4) hh.dt=cn.dt hh.hi=true end end function hj(hk,hl) if hl.gu then
fm(hl) gr(hk) end end function hm(hk,hl) local cn=ha(hl.bz,hl.ca,hk.ej/3,-2,4) cn.dt=hl.dt hl.hn=false fp(hl.cy,hl.bz,hl.ca) gr(hl) end function ho() for hk in all(ff) do if hk:hp() then
for hq,hr in pairs(hs) do local ht=true if hk.cf==hq then
for hl in all(ff) do if hk!=hl and hl:hp() then
for hu in all(hr) do if hl.cf==hu.cf then
local fg,fh,fi,fj=fk(hk) local hv,hw,hx,hy=fk(hl) if fl(fg,fh,fi,fj,hv,hw,hx,hy) then
hu.hz(hk,hl) end end end end end break end end end end end hs={} function ia(ib,ic,ge) if not hs[ib] then
hs[ib]={} end add(hs[ib],{cf=ic,hz=ge}) end function id(fd) local ie='!"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~'for ig=1,#ie do if sub(ie,ig,ig)==fd then
return ig-1 end end end ih=1 function ii(k) ih=1 return k end function ij(ik) local o=0 for n=1,#ik do for ig=1,#"0123456789ABCDEF"do local fd=sub(ik,n,n) if sub("0123456789ABCDEF",ig,ig)==fd then
o*=16 o+=(ig-1) break end end end return o end function il(ik,im) local k=sub(ik,ih,ih+(im-1)) ih+=im return ij(k) end function io(ik,im) local k=sub(ik,ih,ih+(im-1)) ih+=im return k end function ip(k) bu={} local iq={} local n=1 local ir=function(bw) add(iq,bw) if#iq==bs then
add(bu,iq) iq={} end end while n<=#k do local o=id(sub(k,n,n)) if o+0x21==0x7e then
local is=id(sub(k,n+1,n+1)) local o=id(sub(k,n+2,n+2)) while is>0 do ir(o) is-=1 end n+=3 else ir(o) n+=1 end end end function it(iu) local cy={} local iv=il(iu,1) for iw=1,iv do add(cy,il(iu,3)) add(cy,il(iu,3)) end return cy end function go(iu,bz,ca) music(-1) ix={} ff={} iy={} bq={} ii(iu) il(iu,1) il(iu,1) il(iu,1) bm.music=il(iu,1) local iz=il(iu,2) for n=1,iz do local bw=il(iu,1) local ja=il(iu,1) local bz=il(iu,3) local ca=il(iu,3)+8 local jb=il(iu,1) if bw==2 then
if ja==1 then
jc(bz,ca,jb) elseif ja==2 then jd(bz,ca,jb) elseif ja==4 or ja==5 then local cy=it(iu) je(bz,ca,{cy[3],cy[4]+8,cy[5]-cy[1],cy[2]-cy[4]}) elseif ja==10 then jf(bz,ca) elseif ja==15 then jg(bz,ca) end elseif bw==1 then bq[flr(ca/8)*256+flr(bz/8)]={cf=(ja==2 and 1 or ja)} elseif bw==5 then local cy=it(iu) jh(bz,ca,24,4,-0.5,cy) elseif bw==11 then ji(bz,ca,io(iu,il(iu,2))) elseif bw==9 or bw==10 then local fs=il(iu,2) local ek=il(iu,2) local jj=il(iu,2)*8 local jk=il(iu,2)*8 local jl=il(iu,2) local gm=io(iu,jl) local jm=jn(bz,ca,fs,ek,gm,jj,jk,bw,jb) elseif bw==12 then jo(bz,ca,jb) end end br=il(iu,1) bs=il(iu,3) bt=il(iu,3) local jp=il(iu,3) local jq=io(iu,jp) ip(jq) add(bq,{bz=21,ca=10,cf=6}) if ba==nil then
ba=cm(bz,ca) else ba.bz=bz ba.ca=ca ba.ec=true ba.cq=false ba.df=true ba.ej=0 fn(ba) end if ba.cv<=0 then
ba.cv=300 end bf=max(0,ba.bz-64) bx() color(0) cls() flip() cb(1000) cc() bv(bm.music) end hc=true function _init() ia(0,10,gj) ia(0,9,gj) ia(0,2,gs) ia(0,6,gs) ia(0,1,gp) ia(4,2,hj) ia(6,2,hm) ia(6,6,hm) bh=dy(0.064) end gn=0 jr=0 function js() if gn==0 then
if ba.cs then
gn=2 jr=ba.bz ba.ej=0.5 else ba.ej=0 end elseif gn==2 then if ba.bz-jr>=54 then
ba.ej=0 gn=3 end elseif gn==3 then ba.cv=max(0,ba.cv-1) ba.cy+=1 if ba.cv<=0 then
cb(500) ba.cv=300 go(bm.bn,bm.bo,bm.bp) end end end gz=0 function _update60() if hc then
return end gz-=1 if not ba.cq then
ba.cv-=p if ba.cv<=0 then
ep() end end if ba.dq<0 and gz<=0 then
if ba.cq then
js() else ft() end jt() ho() end if bs>16 then
local ju=bf-(ba.bz-64) if ju>10 then
bf-=(ju-10) elseif ju<-10 then bf-=(ju+10) end bf=min(max(0,bf),bs*8-128) end end jv=0 jw="     graphics/programming: sascha schmidt      sfx: nico gueguen      music: midi-to-pico8" function jx(jy,jz) cursor(-jv+jy,8+jz) print(jw) cursor(-jv+384+jy,8+jz) print(jw) end function cd() if hc then
if btn(5) then
hc=false color(0) cls() go(bm.bn,bm.bo,bm.bp) else rectfill(0,0,127,127,12) rectfill(16,24,104,64,0) map(0,0,0,8,16,15) color(0) jx(1,0) jx(1,1) jx(0,1) color(15) jx(0,0) cursor(20,80) print"press any key to begin" jv+=0.5 if jv>384 then
jv=0 end end else rectfill(0,0,127,8,0) ka() rectfill(0,8,127,127,br) kb() kc() kd() end end function _draw() cd() end function fp(cy,bz,ca) ba.cy+=cy local ke=ha(bz,ca,0,-1.2,4) ke.gt=120 ke.cy=cy ke.df=false ke.cd=function(eb) print(eb.cy,eb.bz-bf,eb.ca,7) end end function fl(fg,fh,fi,fj,hv,hw,hx,hy) return not(fg>hv+hx or hv>fg+fi or fh>hw+hy or hw>fh+fj) end function ka() spr(96,0,0) spr(143,9,0) print(ba.cx,16,2,7) spr(219,24,0) spr(143,33,0) print(ba.cw,40,2,7) print(ba.cy,64,2,7) spr(159,103,0) print(flr(ba.cv),112,2,7) end function dy(el) local eb={el=el,cv=0,ee=function(self) self.cv+=p if self.cv>=self.el then
self.cv-=self.el return true end return false end} return eb end function dh(kf,fs,ek,el,kg) local eb={kf=kf,fs=fs,ek=ek,cv=nil,kh=1,ki=kg,eg=function(self) if self.cv!=nil and self.cv:ee() then
if self.ki>0 then
self.kh+=1 if self.kh>#self.kf then
self.kh=#self.kf-1 self.ki=-1 end elseif self.ki<0 then self.kh-=1 if self.kh<1 then
self.kh=2 self.ki=1 end else self.kh=self.kh%#self.kf+1 end end end,cd=function(self,bz,ca,kj,kk) local kl=self.kf[self.kh] spr(kl,bz-bf,ca,self.fs,self.ek,kj,kk) end} if el>0 then
eb.cv=dy(el) end return eb end ix={} function ha(bz,ca,ej,en,fd) local eb=co(bz,ca,3,3,ej,en,3) eb.df=true eb.gt=60 eb.fd=fd eb.eg=function(eh) km(eh) if eb.df then
eh.en+=(q*p) end eh:hb() eh.gt-=1 return eh.gt>=0 end add(ix,eb) return eb end function km(eh) eh.bz+=eh.ej eh.ca+=eh.en end function kd() foreach(ix,function(cn) if not cn:eg() then
del(ix,cn) else cn:cd() end end) end function fe(bz,ca,fd) ha(bz+4,ca+4,1,-1.5,fd) ha(bz+4,ca-4,1,-2.5,fd) ha(bz-4,ca+4,-1,-1.5,fd) ha(bz-4,ca-4,-1,-2.5,fd) end function fo(bz,ca,en,kn,is) local cn=ha(bz,ca,0,0xfffe,4) cn.dt=dh(j"219,220,221,222,223",1,1,0.032,1) cn.gt=30 return cn end function fa(bz,ca,ko,kp,kq) eu(bz,ca,1) local cn=ha(bz*8,ca*8,0,-1.0,4) cn.kr=ca*8 cn.fs=8 cn.ek=8 cn.er=bz cn.es=ca cn.ks=kp cn.ko=ko cn.hb=function(eb) if eb.ca>eb.kr then
eb.gt=4 eb.ca=eb.kr eb.df=false eb.en=0 eu(eb.er,eb.es,kq) if eb.ko!=nil then
ce(eb.ko.cf,eb.er*8,eb.es*8);end end end end ff={} function co(bz,ca,fs,ek,ej,en,cf) local eh={dt=nil,kt=true,by=0,fr=0,cf=cf,bz=bz,ca=ca,ej=ej,en=en,fs=fs,ek=ek,fd=4,hi=false,ku=false,ec=true,df=false,cs=true,gh=0,cy=0,color=4,kv=q,kw=function(self,ew,ex);end,ev=function(self,ew,ex);end,eq=function(self,ew,ex,et);end,hb=function(self);end,kx=function(eh,bz,ca) eh.fs=bz eh.ek=ca end,cp=function(eh,bz,ca) eh.by=bz eh.fr=ca end,ky=function(eb) eb.ku=eb.ej>0 local kz=eb.bz local la=eb.ca local fs=eb.fs local ek=eb.ek if eb.kt and eb.dt!=nil then
eb.dt:eg() eb.dt:cd(kz,la,eb.ku,eb.hi) elseif eb.ks!=nil then spr(eb.ks,kz-bf,la,1,1,eb.ku,eb.hi) else rectfill(kz-bf,la,kz+fs-bf,la+ek,eb.fd) end end,cd=function(eb) eb:ky() end,eo=function(eh) if eh.df then
lb(eh,eh.ev,eh.kw,eh.eq) end if eh.cs then
eh.gh=0 else eh.gh+=1 end end,eg=function(eh) eh:eo() return eh.ec end,hf=function(eh) gr(eh) end,hp=function(eh) return(eh.bz+eh.fs-bf>-32 and eh.bz-bf<160) end,} return eh end function jt() lc() foreach(ff,function(hk) if not hk:eg() or hk.ca>128 then
gr(hk) end end) if ba.dc!=nil then
local ej=ba.ej local en=ba.en ba.ej=ba.dc.ej ba.en=ba.dc.en ba:eo() ba.ej=ej ba.en=en ba.cs=true end end function kc() foreach(ff,function(hk) if hk:hp() then
hk:cd() end end) end function gr(eh) del(ff,eh) end function fn(eh) add(ff,eh) end function ld(cy) local le={lf=cy,n=1,hc=true,eg=function(eh,eb) local bo=eh.lf[eh.n]-eb.bz local bp=eh.lf[eh.n+1]-eb.ca local lg=bo*bo+bp*bp if eh.hc then
eh.hc=false local hd=sqrt(lg) eb.ej=(bo/hd)/2 eb.en=(bp/hd)/2 end if lg<1 then
eh.n+=2 eh.n=eh.n>#eh.lf and 1 or eh.n eh.hc=true else km(eb) end end} return le end function lh(cy) local le={bz=cy[1],ca=cy[2],fs=cy[3],ek=cy[4],lf=cy,li=-0.5,lj=-0.5,eg=function(eh,eb) eb.ej=eh.li eb.en=eh.lj km(eb) local ku=false local hi=false if eb.ca<eh.ca then
eb.ca=eh.ca hi=eh.ek>12 elseif eb.ca+eb.ek>=eh.ca+eh.ek then eb.ca=eh.ca+eh.ek-eb.ek hi=eh.ek>12 end if eb.bz<eh.bz then
eb.bz=eh.bz ku=eh.fs>12 elseif eb.bz+eb.fs>=eh.bz+eh.fs then eb.bz=eh.bz+eh.fs-eb.fs ku=eh.fs>12 end if ku then
eh.li*=-1 end if hi then
eh.lj*=-1 end eh.lk=eh.li<0 and-1 or 1 end} return le end function lc() local ll=ba.dc!=nil local lm=false ba.dc=nil if ba.ca+ba.ek>8 and(ba.en>0 or ba.cs==true) then
foreach(iy,function(eh) if fl(ba.bz,ba.ca+ba.ek+ba.en,ba.fs,1,eh.bz,eh.ca,eh.fs,2) then
lm=true ba.dc=eh ba.cs=true ba.ca=eh.ca-ba.ek ba.en=0 return end end) end if ba.en==0 and ll and not lm then
ba.en=0.001 end end iy={} function jh(bz,ca,fs,ek,en,cy) local cn=co(bz,ca,fs,ek,0,en,5) cn.df=false local bo=cy[1]-cy[3] local bp=cy[2]-cy[4] local ln=bo*bo+bp*bp if ln<256 then
cn.lo=nil else cn.lo=ld(cy) end cn.ks=253 cn.ky=function(eb) for n=0,2 do spr(253,eb.bz+n*8-bf,eb.ca) end end cn.eg=function(eh) if cn.lo!=nil then
eh.lo:eg(eh) else eh.ca-=0.5 if eh.ca<0 then
eh.ca=128 end end return true end fn(cn) add(iy,cn) return cn end function jn(bz,ca,fs,ek,gm,bo,bp,cf,lp) local cn=co(bz,ca,fs,ek,0,0,cf) cn.gm=gm cn.bo=bo cn.bp=bp cn.ky=function(eb) end cn.gl=lp>0 fn(cn) return cn end function ji(bz,ca,lq) local cn=co(bz,ca,#lq*8,8,0,0,11) cn.lq=lq cn.ky=function(eb) cursor(eb.bz-bf,eb.ca) color(7) print(lq) end fn(cn) return cn end function lr(bz,ca,ks,gt) local eb=co(bz,ca,8,8,0,0.01,1) eb:cp(1,1) eb.cf=1 eb.ks=ks eb.fc=bz eb.fb=ca eb.gq=gt eb.gt=600 eb.lt=function(eh) eh:eo() eh.gt-=1 if eh.gt<0 then
return false end return true end fn(eb) return eb end function cg(bz,ca) local n=lr(bz,ca,205,1) n.lk=0.5 n.lu=0 n.cd=function(self) self:ky() spr(4,self.fc-bf,self.fb) end n.kw=function(self,ew,ex) self.lk*=-1 end n.eg=function(self) self:lv() return self:lt() end n.lv=function(self) self.lu+=0.5 if self.lu<8 then
self.ca-=0.5 else self.df=self.lu>14 end self.ej=self.lk end return n end function cj(bz,ca) local n=cg(bz,ca) n.ks=206 n.gq=4 return n end function ci(bz,ca) local n=cg(bz,ca) n.bz=bz-4 n.fs=16 n.dt=dh({235},2,1,0.25,0) n.gq=3 n.eg=function(self) self:lv() if self.lu==14 then
self.en=-3.5 end return self:lt() end return n end function cl(bz,ca) local eb=lr(bz,ca,4,6) eb.eg=function(eh) eb.gt-=100 if eb.gt<=0 then
eb.gt=600 eb.fb-=8 if eb.fb>=0 then
eu(eb.fc/8,eb.fb/8,26) end end return eb.fb>=0 end fn(eb) return eb end function ch(bz,ca) lw=ds(0.047,{j"2,8,14",j"8,14,10",j"14,10,9",j"10,9,2",j"9,2,8"}) local n=lr(bz,ca,207,2) n.cd=function(self) lw:ef() self:ky() pal() spr(4,self.fc-bf,self.fb) end n.eg=function(self) self.ca=max(self.fb-8,self.ca-0.5) return self:lt() end return n end function lx(bz,ca,cf) local eb=co(bz,ca,8,8,0,0.01,2) eb:cp(1,1) eb.kw=nil eb.gt=600 eb.lk=-0.2 eb.ec=true eb.ly=cf eb.gu=true eb.df=true eb.hf=nil eb.lz=0 eb.gv=true eb.hg=function(eh) return true end eb.gy=function(eh,lp) end eb.kw=function(self,ew,ex) self.lk*=-1 self.ej=self.lk end eb.eg=function(eh) if eh:hp() then
eh:hb() eh:eo() if eh.cs then
eh.ej=eh.lk end if eh.ec==false then
eh.lz-=1 if eh.lz==0 then
eh.gt=0xffff end end end return eh.gt>0 end fn(eb) return eb end function ma() local eh=lx(4096,0,999) eh.df=false eh:cp(2,2) eh.gu=false eh.dr=ds(0.1,{j"10,9,8",j"8,10,9",j"9,8,10"}) eh.cd=function(eh) eh.dr:ef() spr(187,eh.bz-bf,eh.ca) pal() end return eh end function jo(bz,ca,jb) local eh=lx(bz,ca,16) eh.mb=jb*22.5 eh.df=false eh.hf=function(eh) end eh.mc={} for n=0,5 do add(eh.mc,ma()) end eh.cd=function(eh) spr(4,eh.bz-bf,eh.ca) end eh.eg=function(eh) local n=0 local kh=1 local md=eh.mb/360.0 local me=sin(md) local mf=cos(md) while n<=25 do eh.mc[kh].bz=eh.bz+me*n eh.mc[kh].ca=eh.ca-mf*n n+=5 kh+=1 end eh.mb=(eh.mb+361)%360 return true end return eh end function jd(bz,ca,jb) local eh=lx(bz,ca,2) eh.dt=dh(j"103,104",1,2,0.25,0) eh.mg=dh(j"239,255",1,1,0.25,0) eh:kx(8,16) eh.gx=1 eh.cy=200 eh.lo=nil eh.ej=jb==0 and-0.2 or 0.2 eh.gy=function(eh,lp) if eh.gx==2 then
eh.ej=2*(lp<0 and s or-s) eh.gx=3 eh.cf=6 eh:cp(0,0) eh.bz+=eh.ej*2 end end eh.eg=function(eh) if eh:hp() then
if eh.gx==0 then
eh.mg:eg() eh.lo:eg(eh) else if eh.gx==1 then
local mh=flr((eh.bz+4)/8) local mi=flr((eh.ca+17)/8) if not fget(em(mh-1,mi),0) and not fget(em(mh+1,mi),0) then
else if eh.cs and not fget(em(mh,mi),0) then
eh:kw(0,0) end end end local mj=eh.ej eh:eo() if eh.gx!=2 and eh.ej==0 then
eh.ej=-mj end if abs(eh.ej)-s>0.1 then
eh.ej*=0.975 end end end return eh.ec end eh.cd=function(eb) eb:ky() if eh.gx==0 then
eh.mg:cd(eh.bz+(eh.ej>0 and-3 or 3),eh.ca+4,eh.ej>0,false) end end eh.hf=function(eh) if eh.gx==0 then
eh.gx=1 eh.df=true elseif eh.gx==1 or eh.gx==3 then eh:cp(1,1) eh.gx=2 eh.kt=false eh.ej=0 eh.lk=0 eh.ek=8 eh.ks=152 eh.cf=2 eh.bz=flr(eh.bz) elseif eh.gx==2 then eh.ej=2*(ba.bz<eh.bz and s or-s) eh.gx=3 eh.cf=6 end end return eh end function je(bz,ca,cy) local eh=jd(bz,ca) eh.ly=4 eh.lo=lh(cy) eh.gx=0 eh.df=false return eh end function jc(bz,ca,jb) local eh=lx(bz,ca,1) eh.cy=100 eh.dt=dh(j"182,183",1,1,0.25,0) eh.lk=jb==0 and-0.2 or 0.2 eh.hf=function(eh) eh.ec=false eh.kt=false eh.df=false eh.ks=184 eh.bz=flr(eh.bz) eh.lz=120 end return eh end function jf(bz,ca) local eh=lx(bz,ca+16,10) eh:cp(5,2) eh:kx(16,16) eh.fb=ca eh.cy=100 eh.dt=dh(j"105,107",2,2,0.25,0) eh.el=0 eh.mk=60+rnd(120) eh.gv=false eh.hf=function(eh) eh.ec=false end eh.cd=function(eh) clip(eh.bz-bf,eh.fb,16,16) eh:ky() clip(0,0,128,128) end eh.eg=function(eh) eh.df=false eh.el+=1 if eh.el>eh.mk*2+64 then
eh.el=0 elseif eh.el>eh.mk*2+32 then eh.ca+=0.5 elseif eh.el>eh.mk+32 then elseif eh.el>eh.mk then eh.ca-=0.5 else end return eh.ec end return eh end function jg(bz,ca) local eh=lx(bz,ca,15) eh:cp(2,2) eh.cy=5000 eh:kx(16,24) eh.dt=dh(j"137,139,141",2,3,0.25,0) eh.el=0 eh.lk=-0.7 eh.mk=60+rnd(120) eh.ml=bz-72 eh.mm=bz eh.gv=false eh.mn=0 eh.mo=10 eh.hf=function(eh) eh.ec=false stop() end eh.hg=function(eh) eh.mo-=1 return eh.mo<0 end eh.cd=function(eb) eb.dt:cd(eb.bz,eh.ca,false,false) end eh.eg=function(eh) eh.mn+=1 if abs(eh.bz-ba.bz)<256 then
eh.dt:eg() eh:eo() eh.el+=1 if(eh.ej<0 and eh.bz<=eh.ml) or(eh.ej>0 and eh.bz>=eh.mm) then
eh.ej=0 eh.el=0 elseif eh.ej!=0 then if eh.el>eh.mk then
mp(eh.bz,eh.ca+8,-1) eh:mq() end if eh.cs and eh.el%30==0 then
eh.en=rnd(2)-3 end else if eh.el>90 then
eh.lk*=-1 eh.ej=eh.lk eh:mq() end end end return eh.ec end eh.mq=function(eb) eh.mk=40+flr(rnd(30)) eh.el=0 end return eh end function mp(bz,ca,lp) local eh=lx(bz,ca,14) eh.dr=ds(0.1,{j"10,9,8",j"8,10,9",j"9,8,10"}) eh.ks=237 eh.lk=lp eh.df=false eh.gu=false eh.eg=function(eh) eh.bz+=eh.lk return true end eh.cd=function(eb) eb.dr:ef() eb:ky() pal() end return eh end function ds(el,jq) local eh={cv=dy(el),kh=1,mr=jq[1],jq=jq,ef=function(eb) local cn=eb.jq[eb.kh] for n=1,#eb.mr do pal(eb.mr[n],cn[n]) end if eb.cv:ee() then
eb.kh=eb.kh%#eb.jq+1 end end,ms=function(eh) pal() end} return eh end function gf(bz,ca,ej) local eb=co(bz,ca,4,4,ej,1,4) eb.dt=dh(j"187,188,203,204",1,1,0.05,0) eb.dr=ds(0.1,{j"10,9,8",j"8,10,9",j"9,8,10"}) eb.df=true eb.ec=true eb.mt=1 eb.mu=ca eb.cd=function(self) self.dr:ef() self:ky() pal() end eb.eg=function(self) self.en=self.mt self:eo() self.mt=self.ca<self.mu and-self.mt or self.mt return self.ec and self:hp() end eb.kw=function(self,ew,ex) self.ec=false end eb.ev=function(self,ew,ex) self.mt=-self.mt self.mu=self.ca-8 self.ca+=self.mt*2 end fn(eb) return eb end function lb(fq,mv,mw,eq) local ew=0 local ex=0 if fq.en!=0 then
local mx=fq.en>0 and fq.ek or 0 if my(fq.bz,fq.ca+mx,fq.fs,fq.ek,fq.en,
function(er,es,et) ew=er ex=es eq(fq,ew,ex,et);if fq.en>0 then
return band(et,1)==1 else return band(et,2)==2 end end,true) then local mz=-1 if fq.en>0 then
fq.cs=true mz=fq.ek/8 end mv(fq,ew,ex-mz) fq.en=0.01 fq.ca=(ex-mz)*8 else fq.cs=false fq.ca+=fq.en fq.en+=fq.kv*p if fq.en>2.15625 then
fq.en=2.00 end end end if fq.ej!=0 then
local mx=fq.ej>0 and fq.fs or 0 if na(fq.bz+mx,fq.ca,fq.fs,fq.ek,fq.ej,
function(er,es,et) ew=er ex=es eq(fq,ew,ex,et);return band(et,4)==4 end,true) then local mz=fq.ej<0 and fq.fs/8 or-fq.fs/8 fq.ej=0 fq.bz=(ew+mz)*8 mw(fq,ew+mz,ex) else fq.bz+=fq.ej end end end function na(bz,ca,fs,ek,ej,ge,nb) local is=ek/3 for n=ek-1,3,-3 do local er=flr((bz+ej)/8) local es=flr((ca+n+0.999)/8) local nc=fget(em(er,es)) if nc!=0 then
if ge!=nil then
local l=ge(er,es,nc) if nb and l then
return true end end end end return false end function my(bz,ca,fs,ek,en,ge,nb) local nd=en<0 and 3 or 1 local is=(fs/8)-1 local ne={} add(ne,nd) for n=1,is do add(ne,n*8-1) end add(ne,fs-nd) for n in all(ne) do local er=flr((bz+n)/8) local es=flr((ca+en)/8) local nc=fget(em(er,es)) if nc!=0 then
if ge!=nil then
local l=ge(er,es,nc) if nb and l then
return true end end end end return false end function kb() local nf=max(1,flr(bf/8)) local ng=min(bs,nf+17) for lj=1,15 do for li=nf,ng do local n=bu[lj][li] if n>0 then
local cn=n>=80 palt(12,cn) palt(0,not cn) spr(n,li*8-bf-8,lj*8) end end end end function em(bz,ca) bz=flr(bz+1) ca=flr(ca) if ca>=1 and ca<16 and bz>=1 and bz<=bs then
return bu[ca][bz] end return 0 end function eu(bz,ca,nh) bz=flr(bz+1) ca=flr(ca) if ca>=1 and ca<16 and bz>=1 and bz<=bs then
bu[ca][bz]=nh end end
if(_update60)_update=function()_update60()_update_buttons()_update60()end