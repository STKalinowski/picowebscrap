

--added hills and clouds in background

k_title_mode = 1
k_play_mode = 2
k_finish_mode = 3
k_level_select = 4

game_mode=k_title_mode

best_time=18000


camera_x = 64
camera_y = -60
camera_z = 64
f=80 -- focal length
--z_scale = 2

floor_y=10

shift_h=0

camera_angle = .25

rotation_speed =.01


player={}

sprite_list={}


step_size = 1

cur_level = 0

moving=false

screen_center_x=64
screen_center_y=64
screen_height=112
screen_width=120
screen_start_x=8
screen_start_y=75



h_step = 2
v_step = 1


frame_num=0

driver_list={}


level_list={}
function new_level(name,start_x,start_y,num_laps,finish,gate1,gate2,waypoint_list_x,waypoint_list_z)
	a={}
	a.name = name
	a.start_x=start_x
	a.start_y=start_y
	a.num_laps=num_laps
	
	a.finish=finish
	a.gate1=gate1
	a.gate2=gate2
	
	a.waypoint_list_x=waypoint_list_x
	a.waypoint_list_z=waypoint_list_z
	
	a.best_time=9999
	
	add(level_list,a)
	return a
end


cloud_list={}
function new_cloud()
	a={}
	a.x=rnd(256)
	a.y= rnd(32)+16
	a.vx=rnd(1)-.5
	a.sprite=98
	add(cloud_list,a)
end

hill_list={}
function new_hill()
	a={}
	a.x=rnd(256)
	a.y= 64-8
	a.sprite=114
	add(hill_list,a)
end



function draw_clouds()
	for cloud in all(cloud_list) do
		sspr(find_x_index(cloud.sprite),find_y_index(cloud.sprite),16,8,flr((cloud.x-512*camera_angle)%(128+32))-32,cloud.y,32,8)
	end
end

function draw_hills()
	for hill in all(hill_list) do
		sspr(find_x_index(hill.sprite),find_y_index(hill.sprite),16,8,flr((hill.x-512*camera_angle)%(128+32))-32,hill.y,32,8)
	end
end


function new_driver(x,z,waypoint_list_x,waypoint_list_z)

	a={}
	a.vx=0
	a.vz=0
	a.angle = .25
	a.vangle = 0
	a.x=x
	a.y=10
	a.z=z
	a.speed = 0
	a.acel = .05
	a.max_speed = 3
	a.turn_acel = .001
	a.dv_x=1
	a.dv_z=0
	
	a.color = {2,13,7}
	
	collide_wall=false
	collide_car=false



	a.h=1

	a.ai=true

	a.lap_num=1
	a.gate1=false
	a.gate2=false

	a.waypoint_index=1
	a.waypoint_list_x=waypoint_list_x
	a.waypoint_list_z=waypoint_list_z


	a.waypoint_x = a.waypoint_list_x[a.waypoint_index]*8+4
	a.waypoint_z = a.waypoint_list_z[a.waypoint_index]*8+4


	a.lap_start=0
	a.best_lap=0
	a.race_start=0
	
	a.finish=false
	a.time=18000

	add(driver_list,a)

	return a
end




function low_res_mode()
	poke(0x5f2c,1)
	screen_center_x=32
	screen_center_y=64
	screen_height=120
	screen_width=64
	screen_start_y=70
	
	v_step=1
	h_step=1
	
end

function pause(t)
	--flip the screen and draw for t frames
	for i=0,t do flip() end
end

--return the color and the height from the sprite 8 to the right
function get_map_pix(x,y)
	local tile_number = mget(shr(x,3), shr(y,3))

	local tile_y = band(shr(tile_number,1),0xfff8)+y%8
	local tile_x = shl(tile_number%16,3)+x%8

	return sget(tile_x,tile_y) 
end





function plot_3d(px,py,pz)
	

	
	
	cc=cos(-camera_angle)
	cs=sin(-camera_angle)
	

	px = px - camera_x
	pz = pz - camera_z
	py = py - camera_y
	
	mx = px*cc-pz*cs
	mz = pz*cc+px*cs

		
	sx = 64*mx/mz+64
	sy = 64*py/mz+64
	h = .5*64/mz
	

	return sx,sy,h
end

function find_x_index(the_index)
	return (the_index%16*8)
end

function find_y_index(the_index)
	return (flr(the_index/16)*8)
end

function draw_sprite_3d(px,py,pz,index,width,height,sprflip,overide_scale)
	local x,y,h = plot_3d(px,py,pz)
	if(overide_scale!=nil)h=overide_scale
	
	y+=4 --shift the sprite so it looks centered over block
	x+=4
	local new_width=width*h
	local new_height=height*h
	
	if(h>0) then
	sspr(find_x_index(index),find_y_index(index),width,height,x-flr(new_width/2),y-new_height,new_width,new_height,sprflip)
	
	end
	
	return h
end

function quick_cast_map_3d()

	local cc=cos(camera_angle)
	local cs=sin(camera_angle)				
	local camera_x=camera_x
	local camera_y=camera_y
	local camera_z=camera_z

	local offset_table=offset_table
	
	local mem_start=0x6000+64*64
	
	--local floor_cam_y=shl(floor_y-camera_y,5)
	
	for sy=64,127 do
			local pz=shl(floor_y-camera_y,6)/(sy-64)
			local pzcc=pz*cc
			local pzcs=pz*cs

			local dpx = shr(pz,6)

			local mx=-pzcs+camera_x-pzcc
			local mz=pzcc+camera_z-pzcs
			
			local mx_step=cc*dpx
			local mz_step=cs*dpx

			
		for sx=0,127 ,8 do

			--this is unrolled 8 times
			--basically, each mx,my step represents how each pixel moves
			--down on the map as we go one pixel to the right on the screen
			--the c1=blah blah function is just a way to read the pixel from
			--the map
			mx+=mx_step
			mz+=mz_step
			local c1= shr(band(   peek( offset_table[mget(shr(mx,3), shr(mz,3))]+ shr(band(mx,7),1)+shl(band(mz,7),6))  ,shl(0x000f,shl(band(mx,1),2))),shl(band(mx,1),2))

			mx+=mx_step
			mz+=mz_step
			local c2= shr(band(   peek( offset_table[mget(shr(mx,3), shr(mz,3))]+ shr(band(mx,7),1)+shl(band(mz,7),6))  ,shl(0x000f,shl(band(mx,1),2))),shl(band(mx,1),2))

			mx+=mx_step
			mz+=mz_step
			local c3= shr(band(   peek( offset_table[mget(shr(mx,3), shr(mz,3))]+ shr(band(mx,7),1)+shl(band(mz,7),6))  ,shl(0x000f,shl(band(mx,1),2))),shl(band(mx,1),2))

			mx+=mx_step
			mz+=mz_step
			local c4= shr(band(   peek( offset_table[mget(shr(mx,3), shr(mz,3))]+ shr(band(mx,7),1)+shl(band(mz,7),6))  ,shl(0x000f,shl(band(mx,1),2))),shl(band(mx,1),2))

			mx+=mx_step
			mz+=mz_step
			local c5= shr(band(   peek( offset_table[mget(shr(mx,3), shr(mz,3))]+ shr(band(mx,7),1)+shl(band(mz,7),6))  ,shl(0x000f,shl(band(mx,1),2))),shl(band(mx,1),2))

			mx+=mx_step
			mz+=mz_step
			local c6= shr(band(   peek( offset_table[mget(shr(mx,3), shr(mz,3))]+ shr(band(mx,7),1)+shl(band(mz,7),6))  ,shl(0x000f,shl(band(mx,1),2))),shl(band(mx,1),2))

			mx+=mx_step
			mz+=mz_step
			local c7= shr(band(   peek( offset_table[mget(shr(mx,3), shr(mz,3))]+ shr(band(mx,7),1)+shl(band(mz,7),6))  ,shl(0x000f,shl(band(mx,1),2))),shl(band(mx,1),2))

			mx+=mx_step
			mz+=mz_step
			local c8= shr(band(   peek( offset_table[mget(shr(mx,3), shr(mz,3))]+ shr(band(mx,7),1)+shl(band(mz,7),6))  ,shl(0x000f,shl(band(mx,1),2))),shl(band(mx,1),2))

			
			--shr(band(   peek(shl(band(tile_number,0x000f),2)+shr(band(mx,7),1)+shl(band(mz,7),6)+shl(band(shr(tile_number,4),0xffff),9)),shl(0x000f,shl(band(mx,1),2))),shl(band(mx,1),2))


			
			poke4(mem_start,bor(  bor(bor(shr(c1,16),shr(c2,12)),bor(shr(c3,8),shr(c4,4))) ,  bor(bor(c5,shl(c6,4)),bor(shl(c7,8),shl(c8,12)))  ))
			mem_start+=4
			

		end

	end

end

offset_table={}
for tile=0,127 do
	offset_table[tile]=shl(band(tile,0x000f),2)+shl(band(shr(tile,4),0xffff),9)
end


function handle_buttons()
	
	moving=false

	if(btn(2) or btn(5)) then 
		player.speed+=player.acel
		moving=true
	end
	if(btn(3)) then player.speed-=player.acel  end
	if(btn(0)) then player.vangle-=player.turn_acel   end
	if(btn(1)) then player.vangle+=player.turn_acel  end
	
	if(btn(5,1)) then game_mode=k_title_mode end


end

engine_note = 1
engine_playing = false
collide_wall_playing = false
collide_car_playing = false
function handle_sound()
	if(playing_music==false) then music(14) playing_music=true end
	if(moving) then
		
		if(player.speed < player.max_speed*.9) then
			if(engine_note==2 or not engine_playing) then
				--sfx(6)
				engine_note=1
				engine_playing=true
			end
		else
			if(engine_note==1 or not engine_playing) then
				--music(16,0,7)
				engine_note=2
				engine_playing=true
			end
		end
		
	
	else
		--music(-1,500)
		engine_playing=false
	end
	
	if(player.collide_wall and not collide_wall_playing )then
		sfx(4)
		collide_wall_playing=true
	end
		
	if(not player.collide_wall) then collide_wall_playing=false end
	
	if(player.collide_car and not collide_car_playing )then
		sfx(5)
		collide_car_playing=true
	end
		
	if(not player.collide_car) then collide_car_playing=false end



end

function handle_driver(driver)
	
	driver.collide_wall=false
	driver.collide_car=false
	
	driver.angle+=driver.vangle
	--driver.angle%=1
	
	driver.dv_x = -1*sin(driver.angle)
	driver.dv_z = 1*cos(driver.angle)
	
	driver.vx = driver.dv_x * driver.speed
	driver.vz = driver.dv_z * driver.speed
	
	--check collision with walls
	if(check_collide(driver.x+driver.vx,driver.z)) then driver.vx=0 driver.speed*=.8 driver.collide_wall=true end
	if(check_collide(driver.x,driver.z+driver.vz)) then  driver.vz=0 driver.speed*=.8 driver.collide_wall=true end
	--are we stuck? then back out
	if(check_collide(driver.x,driver.z)) then driver.x-=driver.dv_x driver.z-=driver.dv_z end
	
	
	--check collision with other drivers
	for car in all(driver_list) do
		if(car != driver) then
			if( (abs(driver.x+driver.vx-car.x)+abs(driver.z-car.z))<10 ) then driver.vx=0 driver.collide_car=true end
			if( (abs(driver.x-car.x)+abs(driver.z+driver.vz-car.z))<10 ) then driver.vz=0 driver.collide_car=true end
		end
	end
	
	
	driver.x+=driver.vx
	driver.z+=driver.vz
	
	driver.vangle*=.9
	if(check_road(driver.x,driver.z)) then
		driver.speed*=.99
	elseif(check_bumpy(driver.x,driver.z)) then
		driver.speed*=.96
	else
		driver.speed*=.98
	end
	
	if(driver.speed>driver.max_speed)then driver.speed=driver.max_speed end
	
	--check lap mechanism
	
	if(check_lap(driver.x,driver.z) and driver.gate2) then
		driver.lap_num+=1 driver.gate1=false driver.gate2=false 
		if(driver.lap_num>cur_level.num_laps) then
			driver.time=frame_num
		end
		
	end
	if(check_gate1(driver.x,driver.z) ) then driver.gate1=true driver.gate2=false end
	if(check_gate2(driver.x,driver.z) ) then driver.gate2=true driver.gate2=true end
	
end



function handle_camera()
	
	
	
	camera_angle= camera_angle*.75+player.angle*.25
	camera_x= .75*camera_x+(player.x - player.dv_x*22)*.25
	camera_y=-5
	camera_z=  .75*camera_z+(player.z - player.dv_z*22)*.25
	
	
end

function	check_lap(x,z)
	--return(fget(mget(x/8,z/8),3))
	tile_x=flr(x/8)
	tile_y=flr(z/8)
	if(tile_x>=cur_level.finish[1] and tile_x<=cur_level.finish[3] and tile_y>=cur_level.finish[2] and tile_y<=cur_level.finish[4]) then 
	--pal(0,9)
	return true 
	else
	--pal(0,0)
	return false
	end
	
end

function	check_gate1(x,z)
	tile_x=flr(x/8)
	tile_y=flr(z/8)
	if(tile_x>=cur_level.gate1[1] and tile_x<=cur_level.gate1[3] and tile_y>=cur_level.gate1[2] and tile_y<=cur_level.gate1[4]) then 
	--pal(0,9)
	return true 
	else
	--pal(0,0)
	return false
	end
end

function	check_gate2(x,z)
	tile_x=flr(x/8)
	tile_y=flr(z/8)
	if(tile_x>=cur_level.gate2[1] and tile_x<=cur_level.gate2[3] and tile_y>=cur_level.gate2[2] and tile_y<=cur_level.gate2[4]) then 
	--pal(0,9)
	return true 
	else
	--pal(0,0)
	return false
	end
end

function	check_collide(x,z)
	return(fget(mget(x/8,z/8),0))
end

function	check_road(x,z)
	return(fget(mget(x/8,z/8),1))
end

function	check_bumpy(x,z)
	return(fget(mget(x/8,z/8),2))
end


function	handle_driver_ai(driver)
	
	--find angle to way point
	driver.angle%=1
	
	
	way_angle= (atan2(driver.waypoint_x-driver.x,driver.waypoint_z-driver.z)+.25 - driver.angle)--direction vectors are off by 90
	
	
	if(way_angle>0.5) then way_angle= -(1-way_angle) end 
	if(way_angle<-0.5) then way_angle= -(1+way_angle) end 
	
	
	if( way_angle>0 )then driver.vangle+=(driver.turn_acel) end
    if( way_angle<0 )then driver.vangle-=(driver.turn_acel) end

	--driver.vangle=0
	--driver.angle = way_angle
	
	
	driver.speed += driver.acel
	
	if( abs(driver.waypoint_x-driver.x)+abs(driver.waypoint_z-driver.z) < 60 ) then

		driver.waypoint_index+=1
		
		if(driver.waypoint_index>#driver.waypoint_list_x) then driver.waypoint_index=1 end

		
		driver.waypoint_x=driver.waypoint_list_x[driver.waypoint_index]*8+4
		driver.waypoint_z=driver.waypoint_list_z[driver.waypoint_index]*8+4
	end

end

function draw_mouse(x,y,z,angle,overide_scale)
	
	angle=(angle*12)%12
	if(angle<0)then angle+=12 end
	--if(angle>12)then angle-=12 end
	spflip=false
	
	if(angle<.5)then		index=64 spflip=false
	elseif(angle<1)then	index=66 spflip=false
	elseif(angle<1.5)then	index=68 spflip=false
	elseif(angle<2)then	index=70 spflip=false
	elseif(angle<4)then	index=72 spflip=false
	elseif(angle<5)then	index=74 spflip=false
	elseif(angle<6)then	index=76 spflip=false
	elseif(angle<7)then	index=78 spflip=false
	elseif(angle<8)then	index=76 spflip=true
	elseif(angle<9)then	index=74 spflip=true
	elseif(angle<10)then	index=72 spflip=true
	elseif(angle<10.5)then	index=70 spflip=true
	elseif(angle<11.0)then	index=68 spflip=true
	elseif(angle<11.5)then	index=66 spflip=true
	elseif(angle<12)then	index=64 spflip=true
	end
	
	if(check_road(x,z) )then
		h=draw_sprite_3d(x,y,z,index,16,16,spflip,overide_scale)
	elseif(check_bumpy(x,z))then
		h=draw_sprite_3d(x,y-flr((x+z)/4)%5/10,z,index,16,16,spflip,overide_scale)
	else
		h=draw_sprite_3d(x,y-.5,z,index,16,16,spflip,overide_scale)
	end
	
	return h

end



function draw_drivers()
	
	turning=0

	
	for driver in all(driver_list) do
		 turning=driver.vangle*10
		 
		 pal(4,driver.color[1])
		 pal(5,driver.color[2])
		 pal(6,driver.color[3])
		 palt(14,true)
		 palt(0,false)
		 
		if(driver.ai==true)then
			driver.h = draw_mouse(driver.x,10,driver.z,driver.angle+turning-player.angle)
		else
			driver.h = draw_mouse(driver.x,10,driver.z,driver.angle+turning-player.angle)
		end
		
		pal()
	end
	
	
	sort_drivers(driver_list)
end


function sort_drivers(a)
  for i=1,#a do
     j = i
    while j > 1 and a[j-1].h > a[j].h do
      a[j],a[j-1] = a[j-1],a[j]
      j = j - 1
    end
  end
end

function sort_driver_times(a)
  for i=1,#a do
     j = i
    while j > 1 and a[j-1].time > a[j].time do
      a[j],a[j-1] = a[j-1],a[j]
      j = j - 1
    end
  end
end

function draw_background()
	palt(0,false)
	palt(14,true)
	
	cls(12)
	


		quick_cast_map_3d()
		
		draw_clouds()
		draw_hills()
end



driver_colors={{4,5,6},{2,13,7},{9,10,7},{12,1,13}}
function	start_level(level)
	
	driver_list={}
	
	for i=1, #level.start_x do
		driver=new_driver(level.start_x[i]*8+4,level.start_y[i]*8+4,level.waypoint_list_x,level.waypoint_list_z)
		driver.color=driver_colors[i]
		--driver.time=0
	end
	
	player = driver_list[1]
	player.ai=false
	

	frame_num=0
	
	cloud_list={}
	hill_list={}
	for i=1,3 do
	new_cloud()
	end
	
	for i=1,2 do
	new_hill()
	end
	
	cur_level=level
	
	camera_x=cur_level.start_x[1]*8+4
	camera_z=cur_level.start_y[1]*8+4
	camera_waypoint=1
	
end

highlight_level = 1
function	handle_level_select()
	
	if(btnp(3)) then highlight_level+=1 end
	if(btnp(2)) then highlight_level-=1 end
	highlight_level=mid(highlight_level,1,#level_list)

	if(btnp(4)) then start_level(level_list[highlight_level]) game_mode=k_play_mode playing_music=false end
end

function	draw_level_select()
	draw_background()
		camera_angle+=.002
		player.angle=camera_angle
		--quick_cast_map_3d()
		
		rectfill(24,40,104,104,13)
		rectfill(26,42,102,102,0)
		
		pal()
		spr(100,34,42,7,2)
		
		for i=1,#level_list do
			print(level_list[i].name,38,56+i*8,7)
		end
		
		circfill(32,58+highlight_level*8,2,7)
		
		print("z to start",60,96,7)
end

finish_spin=0
function	draw_finish()
		if(playing_music==false)then	music(24) playing_music=true end
	draw_background()
		camera_angle+=.002
		player.angle=camera_angle
		--quick_cast_map_3d()
		
		rectfill(20,40,104,108,13)
		rectfill(22,42,102,106,0)
		
		pal()
		spr(100,34,42,7,2)
		
		if(frame_num-player.race_start<cur_level.best_time)then cur_level.best_time=frame_num-player.race_start end
		
		race_text = "race time: "..flr((frame_num-player.race_start)/1800)..":"..flr((frame_num-player.race_start)/30)%60 ..":"..(frame_num-player.race_start)%30*2

		print(race_text,26,60,7)
		
		race_text = "best time: "..flr((cur_level.best_time)/1800)..":"..flr((cur_level.best_time)/30)%60 ..":"..(cur_level.best_time)%30*2
	
		print(race_text,26,68,7)
		
		sort_driver_times(driver_list)
		
		finish_spin+=.3
		finish_spin%=15
		
		local player_place=0
		
		for i=1,#driver_list do 
			pal(4,driver_list[i].color[1])
			pal(5,driver_list[i].color[2])
			pal(6,driver_list[i].color[3])
			palt(14,true)
			palt(0,false)
		 
			if(finish_spin<=8) then
			spr(64+flr(finish_spin)*2,28+(i-1)*18,75,2,2,false,false)
			else
			spr(64+flr(16-finish_spin)*2,28+(i-1)*18,75,2,2,true,false)
			end
			
			--if(driver_list[i].ai==false)then player_place=i end
		    --
			--
			--print(player_place,32,32,8)
			
			--print(driver_list[i].time,10,i*8+32,7)
			
			
			pal()
		end
		
		
		
		print("z to start",60,96,7)
end


function	camera_tween()

	--camera_angle%=1

	next_x = cur_level.waypoint_list_x[camera_waypoint]*8+4
	next_z = cur_level.waypoint_list_z[camera_waypoint]*8+4
	
	way_angle= (atan2(next_x-camera_x,next_z-camera_z)+.25)
	
	if(way_angle>0.5) then way_angle= -(1-way_angle) end 
	if(way_angle<-0.5) then way_angle= -(1+way_angle) end 
	
	camera_angle = camera_angle*.8+way_angle*.2
	
	--if(camera_angle>way_angle+.01) then camera_angle-= abs(camera_angle-way_angle)*.1
	--	elseif(camera_angle<way_angle-.01) then camera_angle+= abs(camera_angle-way_angle)*.1
	--	end
	
	--camera_angle = (camera_angle + way_angle) /2
	
	
	--camera_angle=way_angle
	
	dv_x = -1*sin(camera_angle)
	dv_z = 1*cos(camera_angle)
	
	camera_vx = dv_x * 2
	camera_vz = dv_z * 2
	
	--camera_x=camera_x*.8+(camera_x+camera_vx)*.2
	--camera_z=camera_z*.8+(camera_z+camera_vz)*.2
	
	
	camera_x+=camera_vx
	camera_z+=camera_vz
	camera_y=sin(cur_frame/600)*5+20
	
	
	if( abs(camera_x-next_x)+abs(camera_z-next_z) < 120) then
		camera_waypoint+=1
		if(camera_waypoint>#cur_level.waypoint_list_x) then camera_waypoint=1 end
	end
	
end


function _init()
	new_level("easy street",{20,20,18,18},{9,11,11,9},4,{21,8,22,12},{46,45,46,48},{45,45,45,48},{41,51,52,49,43,39,39,34,13,7,7,11,19},{10,19,41,46,47,43,31,25,25,20,14,10,10})
	
	new_level("hairpin alley",{42,42,40,40},{53,55,53,55},4,{43,52,44,56 },{45,58,45,62},{41,58,41,62},{56,64,71,76,77,55,12,10,8,4,4,8,13,19,19,23,39},{55,51,52,56,60,60,60,56,51,46,42,39,39,45,53,55,55})
	
	new_level("down and out",{95,95,93,93},{7,9,9,7},4,{96,5,97,11 },{114,56,114,62},{109,55,109,62},{106,113,113,110,110,112,110,110,115,121,122,118,101,98,97,86,80,81,87},{8,15,18,21,28,31,35,45,49,50,56,58,58,53,34,28,19,10,8})

	start_level(level_list[1])
end


playing_music=false
function _update()
	
	if(game_mode==k_level_select) then
		handle_level_select()
	end
	
	if(game_mode==k_play_mode) then
	
		--if(playing_music) then music(-1,1800) playing_music=false end
		--if(not playing_music)then music(14) playing_music=true end
		handle_buttons()
		handle_sound()

	
		for driver in all(driver_list) do
			if(driver.ai) then handle_driver_ai(driver) end
			handle_driver(driver)
		end
	
		handle_camera()	
		
		if(player.lap_num>cur_level.num_laps) then game_mode=k_finish_mode playing_music=false music(-1) end
		
	end
	
	if(game_mode==k_level_select) then
		draw_level_select()
	end
	
	
	if(game_mode==k_title_mode) then
		if(not playing_music) then music(0) playing_music=true end
		if( btnp(4) )then game_mode=k_level_select  pause(10) end
	end
	
	if(game_mode==k_finish_mode) then
		
		if(btnp(4) )then game_mode=k_title_mode  pause(20) playing_music=false end
	end
	


end






cur_frame=0
function _draw()
	cur_frame+=1

	if(game_mode==k_play_mode) then

		draw_background()
		
		draw_drivers()
		
		

		print(stat(1),0,0,7)
		
		rectfill(0,0,54,15,1)
		print("time: "..flr((frame_num-player.race_start)/1800)..":"..flr((frame_num-player.race_start)/30)%60 ..":"..(frame_num-player.race_start)%30*2,2,2,6)
		print("lap:"..player.lap_num.."/"..cur_level.num_laps,2,8,6)
		
		
		
		frame_num+=1
	--pause(5)
	end
	
	--camera_vx=2
	--camera_vz=1
	
	if(game_mode==k_title_mode) then
		camera_tween()
		draw_background()
		--camera_angle+=.002
		--player.angle=camera_angle
		
		
		--quick_cast_map_3d()
		pal()
		rectfill(30-2,48-2,127-30+2,72+2,13)
		rectfill(30,48,127-30,72,0)
		
		spr(100,34,48,7,2)
		
	
		
		
		print("z to start",42,65,5)
		print("z to start",42,64,7)
		
		print("gfx+code: electric gryphon",12,100,5)
		print("gfx+code: electric gryphon",12,99,7)
		print("music: gruber",12,108,5)
		print("music: gruber",12,107,7)
	end
	
	if(game_mode==k_finish_mode) then
	
		draw_finish()
		
		
		
		
	end
	
	
end

