-- to a starling (v1.3)
-- by peteksi and gruber

function _init()
 
 cartdata("to_a_starling_v1_0")
 
 data_exists = dget(0)
 
 debug=false
 startmenu=true
 
 ng=false
 
 music(19) --19
 
 --transparency and color
 palt(9, true)
 palt(0, false)
 
 poke(0x5f2e,1)
 
 poke(0x5f00+92,255)
 
 --player
 p={
  sp=1,
  spawn_x=4*8,
  spawn_y=12*8,
  x=0,
  y=0,
  w=8,
  h=8,
  mid_x=0,
  mid_y=0,
  flp=false,
  dx=0,
  dy=0,
  max_dx=2,
  max_dy=3,
  acc=0.5,
  boost=3.5,
  jump_delay=0,
  coyote=5,
  g_mult=0,
  anim=0,
  running=false,
  jumping=false,
  falling=false,
  sliding=false,
  landed=false,
  freeze=0,
  skill=0,
  large=false,
  dw=0,
  dh=0,
  cl=0,
  berries=0,
  keys=0,
  shopping=false,
  notejump=false
 }
 
 jump_btn = 4
 portal_btn = 5
 btn_swap = false
 
 p.x=p.spawn_x p.y=p.spawn_y
 
 gravity=0.3
 friction=0.8
 
 --simple camera
 cam_x=-128
 cam_y=0
 cam_move_timer=10
 shaketimer=0
 line1=0
 line2=0
 
 --map limits
 map_start=0
 map_end=1024
 
 --visual effects
 g_effect=0
 for i=0,90 do
  make_end_particles()
 end
 
 --rooms
 room={
  num=0,
  new=0,
  old=-1,
  dir=0,
  cam_move=false
 }
  
 level={
  num=0,
  new=0,
  old=0,
  dir=0,
  cam_move=false
 }

 obj_from_map()
 
 for i=0,0.8,0.003 do
  make_background(i)
 end
 
 make_areas()
 
 swap_timer=0
 
 --extra tiles
 tile_off={110,126}
 switch_off={124}
 tp_spawn={116}
 ac_spawn={40}
-- ng_spawn={41,43}
 berry_spawn={23}
 cracked_stone={31}
-- key_spawn={49}
-- chest_spawn={48}
 merchant_spawn={36}
 fire_tp={35}
 
 

  ---test---
 if debug then
  x1r=0 y1r=0 x2r=0 y2r=0
  collide_l=8 collide_r=8 
  collide_u=8 collide_d=8
 end
 ----------
end
-->8
--update and draw

local timeelapsed = 0
local lasttime = time()
local dt = 0

local water_anim=0
local water_y=0

function _update60()

 t = time()
 dt = t - lasttime
 lasttime = t
 timeelapsed += dt
 
 room.num=flr((p.x+4)/128)
 level.num=flr((p.y+4)/128)
 
 if g_effect > 0 then
  g_effect += (-1 - g_effect)*0.01
  make_particles(cam_x,cam_y-128,128,0.2,0,20,4,0.5,0)
 end
 
 if room.cam_move==false
 and level.cam_move==false
 and p.freeze<1
 and p.shopping==false
 and startmenu==false then
  change_room(room)
  change_room(level)
 
  p_update()
  tp_update()
  tp_animate()
  ac_update()
 end
 
 ui_update()
 cl_update()
 
 if room.cam_move then
  cam_update(room)
 elseif level.cam_move then
  cam_update(level)
 end
 
 p_animate()
 background_update()
 
 if p.freeze==1 then
  p.x=p.spawn_x
  p.y=p.spawn_y
  p.dx = 0
  p.dy = 0
  obj_from_map(0)
  if ng==true then
   music(13)
   make_circ_particles(32,96,11,3,30)
  end
 end
 if (p.freeze>0) p.freeze-=1
 
 if level.num==1 and p.skill==0 then
  p.skill=1
-- elseif level.num==3 and p.skill<2 then
--  p.skill=2
 elseif level.num==0 then
  p.skill=0
 end
 
 if room.num==1 and level.num==3 then 
  if p.y > 472 then
   gravity=-0.7
  elseif p.y < 442 then
   gravity=0.3
  end
  if p.y<387 then
   p.y=max(p.y,386)
   p.dy=0.2
  end
 end
 if level.num==4 then
  gravity=0.3
 end
 if p.y>512 then
  p.x -= 128
  p.y = -128
  gravity=0.3
  p.skill=0
  p.spawn_x=4*8
  p.spawn_y=12*8
  ng=true
  d_timer=0
 end
 
 particle_update()
 
 if rnd(7)<1 then
  make_particles(cam_x,cam_y,128,0.2,0,20,4,0.5,0)
 end
 if room.num!=1 and rnd(3)<1 then
  make_particles(30*8,48*8,32,0.8,0,20,4,0.5,0)
 end
 
 if swap_timer>0 then
  swap_timer-=1
 end
 
 local shake_y
 local shake_x
 if shaketimer>0 then
  shake_y=rnd(3)-1
  shake_x=rnd(3)-1
  shaketimer-=0.1
 else
  shake_y=0 shake_x=0
 end
 camera(cam_x+shake_x,cam_y+shake_y)
 
end

function _draw()
 cls(0)
 
 pal(14,5+128,1)
 pal(6,6+128,1)
 pal(4,1+128,1)
 pal(9,0,1)
 pal(12,12+128,1)
-- pal(13,14,1)
 
 if level.num>=0 then
  draw_background()
 elseif level.old==-1 and room.num>2 then
  sfx(57,-1,0,4)
 end
 
 draw_tp_2()
 
 if level.num >=1 and level.num <=2 and room.num <=3 then
  local y=130
  if time()-water_anim>.2 then
   water_anim=time()
   water_y=rnd(16)
  end
  for x=240,241 do
   line(x+cam_x*0.3,128,x+cam_x*0.3,128+128,4)
   line(x+cam_x*0.3,128,x+cam_x*0.3,128+y/1.5+water_y+rnd(16),1)
  end
  for x=150,151 do
   line(x+cam_x*0.3,128,x+cam_x*0.3,128+128,4)
   line(x+cam_x*0.3,128,x+cam_x*0.3,128+y/1.5+water_y+rnd(16),1)
  end
  line(135+cam_x*0.3,128,135+cam_x*0.3,128+128,4)
  line(135+cam_x*0.3,128,135+cam_x*0.3,128+y/1.5+water_y+rnd(16)-30,1)
  for x=76,77 do
   line(x+cam_x*0.3,128,x+cam_x*0.3,255+128,4)
   line(x+cam_x*0.3,128,x+cam_x*0.3,128+y/1.5+water_y+rnd(16)+80,1)
  end
  for x=44,46 do
   line(x+cam_x*0.3,128,x+cam_x*0.3,128+255,4)
   line(x+cam_x*0.3,128,x+cam_x*0.3,128+y/1.5+water_y+rnd(16)-40,1)
  end
  for x=136,136+255 do
  	line(x,sin(x/100)*1.2+250+sin(time()/8),x,260,4)
  	pset(x,sin(x/100)*1.2+250.1+sin(time()/8),1)
  end
  for x=0,127 do
  	line(x,sin(x/100)*1.2+378+sin(time()/8),x,383,4)
   pset(x,sin(x/100)*1.2+378.1+sin(time()/8),1)
  end
 end
 
 draw_particles()
 
 --end background
 rectfill(128,384,256,640,0)
 
 draw_end_particles()
 
 draw_circ_particles()
 
 map(0,0,0,0,128,64)
 
 --replay transition
 map(112,48,128,512,16,16)
 map(112,48,0,512,16,16)
 map(112,48,0,-128,16,16)
 for i=0,120,8 do
  map(18,0,144,-128+i,11,1)
 end
 
 draw_tp()
 draw_ac()
 draw_cl()
 
 draw_shop_ui()
 draw_ui()
 
 sspr((p.sp%16)*8,(p.sp\16)*8,8,8,p.x-p.dw/2,p.y-p.dh*2.49,8+p.dw,8+p.dh,p.flp)
 
 if ng==true then
  if p.freeze>0 then
   rectfill(cam_x+1,cam_y+1,cam_x+126,cam_y+126-p.freeze*4,0)
   rectfill(cam_x+1,cam_y+126,cam_x+126,cam_y+p.freeze*4,0)
  end
  rect(cam_x+1,cam_y+1,cam_x+126,cam_y+126,0)
  rect(cam_x,cam_y,cam_x+127,cam_y+127,2)
  if (p.freeze>0) rect(cam_x,cam_y,cam_x+127,cam_y+127,8)
 end
 
 --slipstream
 if room.num==6 and level.num<=0 then
  for i=0,80,2 do
   pset(823+i,-64-i/2+flr(sin(time()/3+i/1.3)*i/4),2)
  end
  spr(94,814,-62)
 end
 
 --[[if ng then
  print("❎->🅾️",992,118,7)
  print("♥ ◆          ◆ ♥",20,208,13)
  print("      ★ gg ★",20,208,7)
  make_particles(57,208,6,2,0,20,4,0.5,0)
 else]]
  --print("\^i… end of demo …………",19,208,7)
  --print("⬇️ easy mode ⬇️",19,250,6)
-- end
 
 ---test---
 if debug then
  rect(x1r,y1r,x2r,y2r,11)
  print("⬅️",p.x-4,p.y-10,collide_l)
  print("➡️",p.x+4,p.y-10,collide_r)
  print("⬆️",p.x-4,p.y-16,collide_u)
  print("⬇️",p.x+4,p.y-16,collide_d)
  print("p.dw: "..p.dw,p.x-16,p.y-4,7)
 end
 --print(p.landed,p.x,p.y,7)
 --print(level.num,p.x+4,p.y,7)
 ----------
end
-->8
--collision, tile check

function collide_map(obj,aim,flag)
 --obj = table; needs x,y,w,h
 --aim = left,right,up,down
 
 local x=obj.x  local y=obj.y
 local w=obj.w  local h=obj.h
 
 local x1=0  local y1=0
 local x2=0  local y2=0
 
 if aim=="left" then
  x1=x-1  y1=y+2
  x2=x    y2=y+h-3
  
 elseif aim=="right" then
  x1=x+w-1   y1=y+2
  x2=x+w  y2=y+h-3
 
 elseif aim=="up" then
  x1=x+2    y1=y-1
  x2=x+w-3  y2=y
 
 elseif aim=="down" then
  x1=x+2   y1=y+h
  x2=x+w-3  y2=y+h
 end
 
 ---test---
 if debug then
  x1r=x1  y1r=y1
  x2r=x2  y2r=y2
 end
 ----------
 
 --pixels to tiles
 x1/=8  y1/=8
 x2/=8  y2/=8
 
 if fget(mget(x1,y1), flag)
 or fget(mget(x1,y2), flag)
 or fget(mget(x2,y1), flag)
 or fget(mget(x2,y2), flag) then
  return true
 else
  return false
 end
end

function is_tile(tile_type,x,y)
	tile=mget(x,y)
	has_flag=fget(tile,tile_type)
	return has_flag
end

function is_tile2(tile_type,x,y)
	tile=mget(x,y)
	for i=1,#tile_type do
		if (tile==tile_type[i]) return true
	end
	return false
end

function swap_tile(x,y,swap_dir)
	tile=mget(x,y)
	mset(x,y,tile+swap_dir)
end

--only for music block animation
--convenient!
function anim_tile(obj,x,y)
 x=flr(x/8) y=flr(y/8)
 if is_tile(4,x,y) then
  swap_tile(x,y,-1)
 	make_particles(x*8,y*8,0,0,0.85,119,8,1,0)
  make_particles(x*8,y*8-8,0,0,0.8,117,8,1,0)
  obj.dy=-obj.boost*1.4
  sfx(59,-1,0+flr(rnd(4))*8,8)
  if (obj==p) p.large=true p.notejump=true
 end
end
-->8
--player

function p_update()
 --physics
 
 
 if (abs(p.dy)<0.2) p.g_mult=0.5 else p.g_mult=1
 
 p.dy+=(gravity*p.g_mult)/2
 p.dx*=friction
 
 p.large=false
 
 --controls
 if btn(⬅️) then
  p.dx-=p.acc
  p.running=true
  p.flp=true
 end
 if btn(➡️) then
  p.dx+=p.acc
  p.running=true
  p.flp=false
 end
 
 --slide
 if p.running
 and not btn(⬅️)
 and not btn(➡️)
 and not p.falling
 and not p.jumping then
  p.running=false
  p.sliding=true
 end
 
 --jump
 if btnp(jump_btn) and p.landed
 or p.jump_delay>0 and p.landed
 or btnp(jump_btn) and p.coyote>0 then
  p.dy=-p.boost
  p.landed=false
  p.jump_tp=10
 elseif btnp(jump_btn) then
  p.jump_delay=10
 elseif p.jump_delay>0 then
  p.jump_delay-=1
 end

 if (p.landed) p.coyote=10
 if (p.coyote>0) p.coyote-=1
 if (p.dy<0) p.coyote=0
 
--[[ if btnp(❎) and p.jump_tp>0 then
  p.dy=-p.boost
  p.landed=false
 end ]]
-- if (p.jump_tp>0) p.jump_tp-=1
 

 
 
 --check collision ⬆️ and ⬇️
 if p.dy>0 then
  p.falling=true
  p.landed=false
  p.jumping=false
  p.notejump=false
  

  p.dy=limit_speed(p.dy,p.max_dy)


  if collide_map(p,"down",0) and p.y%8 < 5
  --[[ or p.y > 367 and room.num==6 ]]then
   
   if (p.dy>0.1) p.dw=3*p.dy p.dh=-2 
   
   p.large=true
   
   p.landed=true
   p.falling=false
   p.dy=0
   
   local snap_height=1
   if collide_map(p,"down",0) == false then
    snap_height=2
   end
   
   p.y-=((p.y+p.h+1)%8)-snap_height
   
   if ng==false then
    dset(1, p.spawn_x)
    dset(2, p.spawn_y)
   end
   
   if (btn(⬇️) and p.dx==0) p.dw=3 p.dh=-1.5
   
   ---test---
   if debug then
    collide_d=11
   end
  elseif debug then
   collide_d=8
  end
   ----------
  
  if (collide_map(p,"down",4)) launch(p)
  if (collide_map(p,"down",6)) obj_from_map(1) 
  
 elseif p.dy<0 then
  p.jumping=true
  
  p.dw=p.dy
  p.dh=-p.dy
  
  if btn(jump_btn) == false
  and p.notejump == false then
   p.dy += 0.15
  end
  
  if collide_map(p,"up",1) then
   p.dy=0
   
   ---test---
   if debug then
    collide_u=11
   end
  elseif debug then
   collide_u=8
  end
   ----------
   
  if (collide_map(p,"up",6)) obj_from_map(1)
  
  
 end
 
 --check collision ⬅️ and ➡️
 if p.dx<0 then
  p.dx=limit_speed(p.dx,p.max_dx)
 
  if collide_map(p,"left",1)
  or p.y<0 and p.x<16 then
   p.dx=0
  
   ---test---
   if debug then
    collide_l=11
   end
  elseif debug then
   collide_l=8
  end
   ----------
   
  if (collide_map(p,"left",6)) obj_from_map(1)
  
  
 elseif p.dx>0 then
 
  p.dx=limit_speed(p.dx,p.max_dx)
 
  if collide_map(p,"right",1)
  or p.y<0 and p.x>888 then
   p.dx=0
   
   
   ---test---
   if debug then
    collide_r=11
   end
  elseif debug then
   collide_r=8
  end
   ----------
  
  if (collide_map(p,"right",6)) obj_from_map(1)
  
 end
 
 --stop sliding
 if p.sliding then
  if abs(p.dx)<.2
  or p.running then
   p.dx=0
   p.sliding=false
  end
 end
 
 -- fast falling / glide
 
 if p.dy>1 and btn(⬇️) then
  p.dy=p.max_dy+1
  p.dw=-2.5
  p.dh=2.5
  --make_particles(p.x,p.y,8,0,0.7,20)
 end
 
 --if (p.dw>0) p.dw-=0.1
 --if (p.dh>0) p.dh-=0.1
 --if (p.dw<0) p.dw+=0.1
 --if (p.dh<0) p.dh+=0.1
 
 if (p.dw!=0) p.dw += sgn(-p.dw)*0.2*abs(p.dw)
 if (abs(p.dw)<0.1) p.dw = 0
 
 if (p.dh!=0) p.dh += sgn(-p.dh)*0.2*abs(p.dh)
 if (abs(p.dh)<0.1) p.dh = 0
 
 p.x+=p.dx/2
 p.y+=p.dy/2
 
 p.mid_x=p.x+p.w/2
 p.mid_y=p.y+p.h/2
 
 respawn_check()

end

function p_animate()
 if p.freeze>0 then
 
  if time()-p.anim>.09 then
   p.anim=time()
   p.sp-=1
   if p.sp<10 then
    p.sp=11
   end
  end
 elseif p.jumping then
  p.sp=7
 elseif p.falling then
  p.sp=8
 elseif p.sliding then
  p.sp=9
 elseif p.running then
  if time()-p.anim>.09 then
   p.anim=time()
   p.sp+=1
   if p.sp>6 then
    p.sp=3
   end
  end
 else --player idle
  if time()-p.anim>.33 then
   p.anim=time()
   p.sp+=1
   if p.sp>2 then
     p.sp=1
   end
  end
 end
end

function limit_speed(num,maximum)
 return mid(-maximum,num,maximum)
end

function respawn_check()
 if is_tile(2,(p.x+4)/8,(p.y+4)/8)
 or p.large and is_tile(2,(p.x+6)/8,(p.y+4)/8)
 or p.large and is_tile(2,(p.x+2)/8,(p.y+4)/8) then
  respawn_p()
 end
end

function respawn_p()
 p.freeze=30
 if (ng) p.freeze=60
 p.jump_delay=0
 p.dw=0 p.dh=0
 sfx(62,-1)
end

function launch(obj)
 
 anim_tile(obj,(obj.x+obj.w/2)+2,obj.y+obj.w/2+8)
 anim_tile(obj,(obj.x+obj.w/2)-2,obj.y+obj.w/2+8)
  --sfx(63)
 
end
-->8
--rooms


local x=0

function change_room(obj)
 if obj.old != obj.num then
  obj.dir=obj.num-obj.old
  obj.new=obj.dir
  timeelapsed = 0
  
  --check if distance to next
  --room is more than 1 on
  --either axis
  local speed=0.6
  if abs(level.old-level.num)>1
  or abs(room.old-room.num)>1
  or ng==true and p.dy==0 and p.dx==0 then
   speed=0
  end
  
  duration=abs(obj.dir)*speed
 
  obj.cam_move=true
 end
end

-- 2 rooms = 256

function cam_update(obj)
 if timeelapsed<duration then 
  x = outcubic(timeelapsed, obj.old, obj.new, duration+.1)
  
  if obj==room then
   cam_x=x*128
  else
   cam_y=x*128
  end
--   map_end=map_start+128
 else
  
  -- obj.old=obj.num
   
  if obj==room then
   cam_x=room.num*128
   if ng==false and duration>0 then
    p.spawn_x=p.x+room.dir*12
    p.spawn_y=p.y
    while is_tile(0,(p.spawn_x+4)/8,(p.spawn_y+8)/8)==false do
     p.spawn_y+=4
    end
   end
   room.old=room.num
  else
   cam_y=level.num*128
   if ng==false and duration>0 then
    p.spawn_x=p.x
    p.spawn_y=p.y+level.dir*6
    while is_tile(0,(p.spawn_x+4)/8,(p.spawn_y+8)/8)==false and level.num>0 do
     p.spawn_y+=4
    end
   end
   level.old=level.num
  end
  obj_from_map(0)
  obj.cam_move=false
 end
end
-->8
--teleport

teleports = {}

local angle=0

function make_tp(spawn_x,spawn_y,fiery)
 tp={
  x=spawn_x*8,
  y=spawn_y*8,
  room=0,
  level=0,
  orig_y=spawn_y*8,
  dy=0,
  max_dy=3.1,
  w=8,
  h=8,
  sp=13,
  anim=0,
  play=false,
  emit=false,
  fall=false,
  g_mult=0,
  boost=2.2,
  fire=fiery,
  x_sin=0,
  y_cos=0,
  usable=false,
 }
 add(teleports,tp)
end

function draw_tp()
 for tp in all(teleports) do  
  if tp.fire then
   circfill(tp.x_sin,tp.y_cos,2,2)
   circ(tp.x_sin,tp.y_cos,2,8)
   circ(tp.x_sin,tp.y_cos,3,0)
   pset(tp.x_sin-1,tp.y_cos-1,15)
   if tp.usable==false then
    circfill(tp.x_sin,tp.y_cos,2,1)
   end
  end
  spr(tp.sp,tp.x,tp.y)
 end
end

function draw_tp_2()
 for tp in all(teleports) do  
  if tp.fire then
   line(tp.x+4+sin(angle)*-31,tp.y+4+cos(angle)*-31,tp.x+4,tp.y+4,4)
   circ(tp.x+4,tp.y+4,32,4)
   line(tp.x+4,tp.y+4,tp.x_sin,tp.y_cos,2)
  end
 end
end

function tp_update()
 for tp in all(teleports) do
 
  tp.room=flr(tp.x/128)
  tp.level=flr(tp.y/128)
  
  if room.num==tp.room
  and room.old==tp.room
  and level.num==tp.level
  and level.old==tp.level then
  
  angle=atan2(tp.y - p.y, tp.x - p.x)
  tp.x_sin=tp.x+4+sin(angle)*32
  tp.y_cos=tp.y+4+cos(angle)*32
  
  if is_tile(1,tp.x_sin/8,tp.y_cos/8) then
   tp.usable=false
  else
   tp.usable=true
  end
  
   if btnp(portal_btn) then
    if tp.fire==false then
     p.x=tp.x  p.y=tp.y
     
     tp.sp=12
     tp.play=true
     tp.emit=true
     make_circ_particles(tp.x+4,tp.y+4,11,3)
     sfx(63,-1,0,8)
     
     if (p.skill>0)tp.fall=true
     
    elseif tp.usable then
   --  p.firetimer=5
     
     p.x=tp.x_sin-4
     p.y=tp.y_cos-4
     for i=0,15 do
      make_particles(tp.x_sin,tp.y_cos,0,1.5,0.3,32.5,4,0.5,4)
     end 
     make_circ_particles(tp.x_sin,tp.y_cos,8,2)
     sfx(63,-1,8,16)
     --p.x=tp.x  p.y=tp.y
    end
    if (p.notejump) then
     p.dy*=1.13
    else
     p.dy*=1.11
    end
    if (tp.dy>0) tp.dy=0
   elseif tp.fire then
    if rnd(3)<1 then
     make_particles(tp.x,tp.y,6,0.5,0.3,32.5,4,0.5,4)
    -- make_particles(tp.x_sin,tp.y_cos,0,0.2,0.6,32.5,4,0.5,4)
    end
   end
   if (tp.fire) tp.sp=35
  end
  
  if tp.emit then
   make_particles(tp.x,tp.y,8,1.5,0.4,20,4,0.5,0)
  end
  if tp.fall then
   if (abs(tp.dy)<3) tp.g_mult=0.5 else tp.g_mult=1
   tp.dy+=(gravity*tp.g_mult*0.5)/2
   tp.dy=limit_speed(tp.dy,tp.max_dy)
   tp.y+=tp.dy/2
   if rnd(3)<1 then
    make_particles(tp.x,tp.y,8,0.5,0.7,20,4,0.5,0)
   end
   if (collide_map(tp,"down",0)) and tp.dy>0 or (collide_map(tp,"down",2)) then 
    shatter(tp)
   end
   if (collide_map(tp,"down",4)) launch(tp)
  end
 end
end

function tp_animate()
 for tp in all(teleports) do
  if time()-tp.anim>.1 and tp.play then
   tp.anim=time()
   tp.sp+=1
   if tp.sp>15 then
    tp.emit=false
   end
   if tp.sp>19 then
    tp.sp=13
    tp.play=false
   end
  end
 end
end

function shatter(tp)
 make_circ_particles(tp.x+4,tp.y+4,11,3,35)
 for i=0,20 do
  make_particles(tp.x,tp.y,8,2,0.4,20,4,0.5,0)
 end
 shaketimer=1.2
 tp.y+=256 tp.fall=false
 sfx(61,-1,0,12)
end

function reset_tp()
 for tp in all(teleports) do
  tp.y=tp.orig_y
  tp.fall=false
  tp.dy=0
  --tp.fire=false
  --tp.sp=13
  tp.ftimer=0
  tp.x_sin=tp.x+4
  tp.y_cos=tp.y+4
 end
end

-->8
--particles

particles = {}
circ_particles = {}
end_particles = {}

function make_particles(_startx, _starty, _area, _acc, _add_t, _sprite, _width, _sprite_mult, _sprite_y)

 local ptcl = {
   
   x=_startx+rnd(_area),
   y=_starty+rnd(_area),
   
   t = 0+_add_t,
   
   lifetime=(10+rnd(50))*2,
   
   dy = (rnd(_acc)-(_acc/2))/2,
   dx = (rnd(_acc)-(_acc/2))/2,
   
   sp = _sprite,
   first_sp = _sprite,
   w = _width,
   sp_mult = _sprite_mult,
   sp_y = _sprite_y
 }
 
 add(particles,ptcl)
end

function make_circ_particles(_startx,_starty,_col1,_col2,_max_r)
 local circ_ptcl = {
  x=_startx,
  y=_starty,
  r=0,
  max_r=_max_r or 12,
  col=_col1,
  col2=_col2,
 }
 add(circ_particles,circ_ptcl)
end

function make_end_particles()
 local end_ptcl = {
  x=0,
  y=0,
  flicker=rnd(1),
  speed=rnd(10)+15
 }
 add(end_particles,end_ptcl)
end

function particle_update()
 for ptcl in all(particles) do
  ptcl.y += ptcl.dy
  ptcl.x += ptcl.dx
    
  --[[if level.num>2 then
   ptcl.x+=(cam_x-ptcl.x)*0.01
  elseif p.skill==1 then
   ptcl.y+=g_effect
  end]]
 
  ptcl.t += 1/ptcl.lifetime
    
  if ptcl.t > 0.3  then
   ptcl.sp = ptcl.first_sp+ptcl.sp_mult
  end
  if ptcl.t > 0.6 then
   ptcl.sp = ptcl.first_sp+ptcl.sp_mult*2
  end
  if ptcl.t > 0.8  then
   ptcl.sp = ptcl.first_sp+ptcl.sp_mult*3
  end
  if ptcl.t > 0.9 then
   ptcl.sp = ptcl.first_sp+ptcl.sp_mult*4
  end


  if ptcl.t > 1 then
   del(particles,ptcl)
  end
 end
 for circ_ptcl in all(circ_particles) do
  circ_ptcl.r+=(circ_ptcl.max_r+1-circ_ptcl.r)*0.1
  
  if circ_ptcl.r > circ_ptcl.max_r*0.80 then
  	circ_ptcl.col=circ_ptcl.col2
  end
  
  if circ_ptcl.r > circ_ptcl.max_r*0.95 then
   circ_ptcl.col=4
  end
  if circ_ptcl.r > circ_ptcl.max_r then
   del(circ_particles,circ_ptcl)
  end
 end
 
 for end_ptcl in all(end_particles) do
  end_ptcl.x = 182 + cos((time()+240)/end_ptcl.speed*(end_ptcl.flicker+2)/2)*(30+end_ptcl.flicker*60) 
  end_ptcl.y = 398 + sin((time()+240)/end_ptcl.speed*(end_ptcl.flicker+2)/2)*(15+end_ptcl.flicker*30) + end_ptcl.x/2.5
 end
end


function draw_particles()
 for ptcl in all(particles) do  
  sspr((ptcl.sp%16)*8,(ptcl.sp\16)*8+ptcl.sp_y,ptcl.w,ptcl.w,ptcl.x,ptcl.y)
 end
end


function draw_circ_particles()
 for circ_ptcl in all(circ_particles) do
  circ(circ_ptcl.x,circ_ptcl.y,circ_ptcl.r,circ_ptcl.col)
 end
end


function draw_end_particles()
 for end_ptcl in all(end_particles) do
  spr(61,end_ptcl.x,end_ptcl.y)
  if sin(time()+end_ptcl.flicker)>0.5 then
   pset(end_ptcl.x+1,end_ptcl.y+1,12)
  end
 end
end
-->8
-- math


function outcubic(t, b, c, d)
 return c * (pow(t / d - 1, 3) + 1) + b
end

function pow(x,a)
  if (a==0) return 1
  if (a<0) x,a=1/x,-a
  local ret,a0,xn=1,flr(a),x
  a-=a0
  while a0>=1 do
      if (a0%2>=1) ret*=xn
      xn,a0=xn*xn,shr(a0,1)
  end
  while a>0 do
      while a<1 do x,a=sqrt(x),a+a end
      ret,a=ret*x,a-1
  end
  return ret
end

function format_timer(dec)
 local seconds_zero
 
 if (dec % 60)<10 then
  seconds_zero="0"
 else
  seconds_zero=""
 end
 
	return flr(dec / 60)..":"..seconds_zero..flr((dec % 60)).."\f5"..sub(tostr(dec-flr(dec)),2,5)
end
-->8
-- objects from map

-- cases:
-- 0=reload objects
-- 1=swap red tiles

function obj_from_map(case)

 if (case==1) sfx(60,-1)

 local tile_x=room.num*16
 local tile_y=level.num*16
 for x=tile_x,tile_x+15 do
 	for y=tile_y,tile_y+15 do
 	 if case==0 then
 		 if (is_tile(3,x,y)) then
 	 		make_tp(x,y,false)
  			swap_tile(x,y,-1)
  		end
  		if (is_tile2(fire_tp,x,y)) then
  		 make_tp(x,y,true)
  			swap_tile(x,y,-10)
  		end
  	 if (is_tile(5,x,y)) then
  	  swap_tile(x,y,1)
 	  end
 	  if (is_tile2(tile_off,x,y)) then
  	  swap_tile(x,y,1)
 	  end
 	  if (is_tile2(switch_off,x,y)) then
  	  swap_tile(x,y,1)
 	  end
 	  if (is_tile2(ac_spawn,x,y)) then
  	  make_ac(x,y)
 	  end
--[[ 	  if (is_tile2(ng_spawn,x,y)) and ng==true then
  	  swap_tile(x,y,1)
 	  end]]
 	  if (is_tile2(berry_spawn,x,y)) then
  	  make_cl(x,y,23,"berry")
  	  swap_tile(x,y,2)
  	 end
--[[  	 if (is_tile2(key_spawn,x,y)) then
  	  make_cl(x,y,49,"key")
  	  swap_tile(x,y,-24)
  	 end]]
  	 if (is_tile2(merchant_spawn,x,y)) then
  	  make_cl(x,y,36,"merchant")
  	  swap_tile(x,y,-11)
  	 end
 	  reset_tp()
 	 elseif case==1 and swap_timer>=0 then

 	  if (is_tile(7,x,y)) then
 	   swap_tile(x,y,-1)
 	   for i=0,3 do
 	    make_particles(x*8,y*8,8,0.5,0,20,4,0.5,4)
 	   end
 	  end
 	  if (is_tile(6,x,y)) then
 	   for i=0,20 do
 	    make_particles(x*8,y*8,8,2,0.2,20,4,0.5,4)
 	   end
 	   make_circ_particles(x*8+4,y*8+4,8,2,10)
 	   swap_tile(x,y,-1)
 	  end
--[[ 	 elseif case==2 then
 	  if (is_tile2(cracked_stone,x,y)) then
 	   swap_tile(x,y,-6)
 	  end]]
 	 end
  end
	end
end
-->8
--background

local backgrounds = {}
local bg_type = 0

-- speed = 0 to 0.6
function make_background(var_speed)
 local bg = {
  start_x=rnd(1024),
  start_y=rnd(512),
  x=0,
  y=0,
  sp=59+rnd(3),
  speed=0.6-var_speed,
  deco=rnd(3),
 }
 add(backgrounds,bg)
end

function background_update()
 for bg in all(backgrounds) do
  bg.y = bg.start_y
  bg.x = bg.start_x+cam_x*bg.speed
 end
end

function draw_background()
 for bg in all(backgrounds) do
  if level.num>=2 then
   spr(53-bg.deco,bg.x,bg.y+8)
  end
  if (level.num<3) bg_type=level.num
  spr(bg.sp-bg_type*3,bg.x,bg.y)
 end
end


-->8
--anchor

anchors = {}

function make_ac(spawn_x,spawn_y)
 ac={
  x=spawn_x*8,
  y=spawn_y*8,
  sp=38,
  active=true
 }
 add(anchors,ac)
end

function draw_ac()
 for ac in all(anchors) do
  spr(ac.sp,ac.x,ac.y)
 end
end

function ac_update()
 for ac in all(anchors) do
  for tp in all(teleports) do
   if ac.active and ac.x == tp.x and tp.y < ac.y+2 and tp.y > ac.y-1.5 and tp.dy>0then
    tp.fall = false
    tp.y = ac.y-1
    ac.sp=39  ac.active=false
    sfx(61,-1,12,4)
   end
  end
  if btnp(portal_btn) and ac.active==false then
   ac.sp=38
  end
 end
end
--]]
-->8
--collectibles and shop

collects = {}

-- also used in ui tab
sel=0
d_sel=0
d_sel_rounded=0
--

local angle=0

function make_cl(spawn_x,spawn_y,start_sprite,item_id)
 cl={
  x=spawn_x*8,
  y=spawn_y*8,
  start_y=spawn_y*8,
  start_x=spawn_x*8,
  x2=0,
  y2=0,
  start_sp=start_sprite,
  sp=start_sprite,
  anim=0,
  follow=false,
  order=0,
  id=item_id,
  interactable=false,
  interact=false,
  col=0,
  flp=false,
  temp=false
 }
 add(collects,cl)
end

function draw_cl()
 for cl in all(collects) do

  spr(cl.sp,cl.x,cl.y,1,1,cl.flp)
 
 --[[ if cl.temp then
   circ(cl.x+3,cl.y+3,5,12)
  end]]
  
  if cl.id=="berry" and cl.temp==false and p.skill==3 then
   angle=atan2(cl.y - p.y, cl.x - p.x)
   pset(p.x+3+sin(angle)*8+1,p.y+3+cos(angle)*8+1,1)
   rect(p.x+3+sin(angle)*8,p.y+3+cos(angle)*8,p.x+3+sin(angle)*8+2,p.y+3+cos(angle)*8+2,12)
  end

  if cl.id=="merchant"
  and p.mid_x > cl.x
  and p.mid_x<cl.x2+16
  and level.num==flr(cl.y/128)
  and p.landed==true
  and cl.interact==false then
   print("⬆️",cl.x,cl.y-8,7)
   cl.interactable=true
  else
   cl.interactable=false
  end
 end
end

function cl_update()
 for cl in all(collects) do
  if cl.id=="berry" or cl.id=="merchant" then
   if time()-cl.anim>.3 then
    cl.anim=time()
    cl.sp+=1
    if cl.sp>cl.start_sp+1 then
     cl.sp=cl.start_sp
    end
   end
  end
  
  if cl.id=="berry" and cl.follow==false then
   cl.y+=((cl.start_y+flr(2+sin(time()/1.3)*2)-2)-cl.y)*0.1
   cl.x+=(cl.start_x-cl.x)*0.1
  elseif cl.follow==false then
   cl.y=cl.start_y
  end
  
  if cl.id=="merchant" then
   if cl.x>p.x then
    cl.flp=true
   else
    cl.flp=false
   end
  end
  if cl.id=="chest" then
   cl.col=8
  end
  if cl.id=="key" then
   cl.col=-8
  end
  
  if cl.follow==false and cl.id!="merchant" then
   if p.mid_x > cl.x and p.mid_x<cl.x2
   and p.mid_y > cl.y and p.mid_y<cl.y2 then
    cl.follow=true
    cl.temp=true
    if cl.id=="key" or cl.id=="chest" then
     p.keys+=1
    elseif cl.id=="berry" then
     p.berries+=1
     sfx(58,-1,0,8)
    end
    
    p.cl=p.berries+p.keys
    cl.order=p.cl*6
    
    make_circ_particles(cl.x+4,cl.y+4,12,1,10)
    for i=0,10 do
     make_particles(cl.x,cl.y,8,2,0.6,32,4,0.5,0)
    end
   end
  end
  if cl.follow==true then
   cl.y+=(p.y-8-cl.y)*0.1
   cl.flp = not p.flp
   if p.shopping then
    cl.x=875
    cl.y-=16
   else
    cl.x+=(p.x-cl.x)*0.1
   end
  end
  

  if btnp(❎) and cl.interact then
   cl.interact=false
   p.shopping=false
  
  elseif btnp(⬆️) and cl.interactable then
   cl.interact=true
   p.shopping=true
   sel=0
   d_sel=0
   d_sel_rounded=0
  end
  
  cl.x2=cl.x+8
  cl.y2=cl.y+8
  
  if p.freeze>0 then
   if cl.follow and cl.temp then
    cl.follow=false
    cl.temp=false
    p.berries-=1
    cl.flp=false
   end
  end
  
  if room.cam_move or level.cam_move then
   if cl.temp then
    sfx(58,-1,8,8)
    make_circ_particles(cl.x+4,cl.y+4,12,1,25)
    for i=0,10 do
     make_particles(cl.x,cl.y,8,2,0.6,32,4,0.5,0)
    end
    del(collects,cl)
   end
  end
  
 end
end


function delete_cl()
 for cl in all(collects) do
  if p.cl!=0 and cl.col==0
  and cl.order==6 then
   del(collects,cl)
  end
  if cl.col==0 then
   cl.order-=6
  end
 end
end
-->8
--ui

local pos=128
local area_line=0

local current_area = ""

local areas = {}

local btn_hint_y = 110

local sel_rect_x = -97
local sel_rect_y = 62
local sel_max = 2
local sel_hold = 0

local d_timer=0
local end_ui_timer=0

local start_credits = "V1.3 | BY pETEKSI AND gRUBER"

--local sel_rect_x = 799
--local sel_rect_y = 306

function make_areas()
--[[	valley = {
	 x=3,
	 y=0,
	 visited=false,
	 name="vALLEY",
	 music_pat=13,
	}]]
	mines = {
	 x=7,
	 y=1,
	 visited=false,
	 name="mINES",
	 music_pat=6,
	}
	docks = {
	 x=2,
	 y=1,
	 visited=false,
	 name="dOCKS",
	 music_pat=13,
	}
	depths = {
	 x=1,
	 y=2,
	 visited=false,
	 name="dEPTHS",
	 music_pat=6,
	}
	the_end = {
	 x=1,
	 y=3,
	 visited=false,
	 name="eND",
	 music_pat=25,
	}
	later = {
	 x=1,
	 y=4,
	 visited=false,
	 name="COURSE",
	 music_pat=13,
	}
--[[	roots = {
	 x=6,
	 y=3,
	 visited=false,
	 name="rOOTS",
	}]]
	--add(areas,valley)
	add(areas,mines)
	add(areas,docks)
	add(areas,depths)
	add(areas,the_end)
	add(areas,later)
	--add(areas,roots)
end


function draw_ui()
 --print("TITLE",-74,40,7)
-- print("🅾️ AND ❎",-82,112,13)
 spr(36,-87,37,2,1)
 spr(48,-69,37,2,1)
 spr(77,-53,37,2,1)
 
 print("⬇️",188,506,14)
 
 print(start_credits,x_center(start_credits)-132,3,5)
 
 print("nEW GAME",-80,64,7)
 print("cONTINUE",-80,72,5)
 
 if data_exists == 1 then
  print("cONTINUE",-80,72,7)
 end
 
 print("sWAP BUTTONS",-88,80,7)
 if btn_swap == true then
  print("❎ jUMP | 🅾️ tELEPORT",-106,btn_hint_y,13)
  if btn(🅾️) == false then
   print("🅾️",-66,btn_hint_y-1,7)
  else
   print("🅾️",-66,btn_hint_y,6)
  end
  if btn(❎) == false then
   print("❎",-106,btn_hint_y-1,7)
  else
   print("❎",-106,btn_hint_y,6)
  end

  print("🅾️",62,104,13)
  print("🅾️ tELEPORT",62,103,7)
  
 else
  print("❎ tELEPORT | 🅾️ jUMP",-106,btn_hint_y,13)
  if btn(❎) == false then
   print("❎",-106,btn_hint_y-1,7)
  else
   print("❎",-106,btn_hint_y,6)
  end
  if btn(🅾️) == false then
   print("🅾️",-50,btn_hint_y-1,7)
  else
   print("🅾️",-50,btn_hint_y,6)
  end
  
  print("❎",62,104,13)
  print("❎ tELEPORT",62,103,7)
  
  if sel==2 then
   print("(DEFAULT)",-82,btn_hint_y+7,5)
  end
 end
 
--[[ if btnp(⬅️) and startmenu == true or btnp(➡️) and startmenu == true then
  if btn_swap == true then
   jump_btn = 4
   portal_btn = 5
  else
   jump_btn = 5
   portal_btn = 4
  end
  btn_swap = not btn_swap
 end]]
 
 print("❎   🅾️",167,94,13)
 print("❎ + 🅾️",167,93,7)
 
 for x=0,2 do
  for y=0,2 do
   print("mOMENTUM IS CONSERVED",278+x,116+y,0)
  end
 end

 print("mOMENTUM IS CONSERVED",279,117,7)
 
 print("- \#0★\^-# -",cam_x+52,cam_y+6+pos,7)
 line(cam_x+54,cam_y+8+pos,cam_x+54-flr(area_line),cam_y+8+pos,7)
 line(cam_x+72,cam_y+8+pos,cam_x+72+flr(area_line),cam_y+8+pos,7)
 
 if current_area=="\#0eND" then
  print("- \#0⧗\^-# -",cam_x+52,cam_y+6+pos,7)
 elseif current_area=="\#0COURSE" then
  print("- \#0♥\^-# -",cam_x+52,cam_y+6+pos,7)
 end
 if current_area=="\#0dEPTHS" then
  print("\#0fIERY",cam_x+54,cam_y+14+pos,7)
 elseif current_area=="\#0COURSE" then
  print("\#0oF",cam_x+60,cam_y+14+pos,7)
 else
  print("\#0tHE",cam_x+58,cam_y+14+pos,7)
 end
 
 print(current_area,cam_x+x_center(current_area),cam_y+20+pos,7)
 
 spr(36,169,395,2,1)
 spr(48,187,395,2,1)
 spr(77,203,395,2,1)

 print("- ◆ -",180,410,6)

 print("gAME BY pETEKSI",162,417,13)
 print("@pETEKSI1\fd",174,423,7)
 print("mUSIC BY gRUBER",162,434,13)
 print("@GRUBER_MUSIC\fd",166,440,7)
 print("- ◆ -",180,448,6)
 if level.num==3 then
  print(end_ui,x_center(end_ui)+140,479+256-pos*2,15)
  if ng then
   print("pERMADEATH MODE COMPLETED",142,486+256-pos*2,11)
  end
 end
end


function draw_shop_ui()
 if p.shopping or startmenu then
  rectfill(797,300,867,354,0)
  rectfill(798,301,866,353,1)
  rectfill(799,306,865,352,4)
  rectfill(sel_rect_x,sel_rect_y+d_sel_rounded,sel_rect_x+66,sel_rect_y+8+d_sel_rounded,1)
  rectfill(sel_rect_x,sel_rect_y+d_sel_rounded,sel_rect_x+sel_hold,sel_rect_y+8+d_sel_rounded,13)
--[[  print("\^i\#7shop",801,299,13)
  print("\^i\#7🅾️ buy / ❎ exit",801,351,13)
  print("gREEN GRAVITY \#0\fc1b",801,308,7)
  print("??? \fd--------- \#0\fc?b",801,316,7)
  print("??? \fd--------- \#0\fc?b",801,324,7)
  print("    …-◆-…    ",801,332,13)
  print("    …-◆-…    ",801,340,13)]]
  rect(sel_rect_x,sel_rect_y+d_sel_rounded,sel_rect_x+66,sel_rect_y+8+d_sel_rounded,13)
 end
end


function ui_update()

 foreach(areas, area_update)
 if pos<128 then
--[[  if room.num == 1 and level.num == 3
  and end_ui_timer<120 then
   pos=12
  elseif level.num>2 then
   pos*=1.06
  else]]
  pos*=1.0008
  --end
  area_line+=(0-area_line)*0.030
 end
 
 if p.shopping or startmenu then
  if (btnp(⬇️) and sel<5) sel+=1
  if (btnp(⬆️) and sel>-1) sel-=1
  d_sel += (sel - d_sel) * 0.3
  d_sel_rounded = ceil(d_sel*8-0.5)
  if (sel==-1) sel=sel_max
  if (sel>sel_max) sel=0
  if (btn(🅾️) or btn(❎)) then
   sel_hold=mid(0,sel_hold+1.5,66)
  else
   sel_hold=mid(0,sel_hold-4,66)
  end
  if (sel_hold==66) buy() sel_hold=0
 end
 
 if room.num==1 and level.num==3 then
  if (end_ui_timer<120) end_ui_timer+=1
 elseif startmenu then
  --do nothing
 else
  d_timer+=1/60
 end
 end_ui = ("\f7bERRIES: "..p.berries.." \fd| \f7tIME: "..format_timer(d_timer))
end


function buy()
 if p.shopping == true then
  if sel==0 and p.berries>sel and p.skill==0 then
   p.berries-=1
   g_effect=3
   p.skill=1
  end
 else
  if sel==0 then
   startmenu=false
   sel_rect_x = 799
   sel_rect_y = 306
   sel_max=4
   
   dset(0,1)
   
  elseif sel==1 then
   if data_exists == 1 then
    startmenu=false
    p.x = dget(1)
    p.y = dget(2)
    p.spawn_x = dget(1)
    p.spawn_y = dget(2)
   end
   
  elseif sel==2 then
   if btn_swap == true then
    jump_btn = 4
    portal_btn = 5
   else
    jump_btn = 5
    portal_btn = 4
   end
   btn_swap = not btn_swap
  end
 end
end


function area_update(_obj)
	if room.num==_obj.x
 and level.num==_obj.y
 and _obj.visited==false then
  pos=88
  area_line=64
  _obj.visited=true
  current_area="\#0".._obj.name
  music(_obj.music_pat)
 end
 
 if room.num<2 and level.num==0
 and ng then
  for a in all(areas) do
   a.visited=false
  end
 end
end


function x_center(s)
 return 64-(#s-2)*2
end
-->8
 

--[[

still thou are blest,
compared wi' me!

the present only toucheth thee:

but och!
i backward cast my e'e,

on prospects drear!

an' forward, tho' i cannot see,
i guess an' fear!

]]