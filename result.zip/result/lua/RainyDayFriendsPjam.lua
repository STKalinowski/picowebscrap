--rainy day friends
--pico-8 jam #1 "rain" 2015-11-22
--by electric gryphon
fore_grass_list = {}
back_grass_list = {}
k_num_fore_grass = 20
k_num_back_grass = 20
rain_list = {}
k_rain_delay = 8
rain_fx =0
ring_list = {}
is_lightning = false
cur_frame=0


function new_drop()
	a={}
	a.x = rnd(128)
	a.y = -5
	a.ground = 120-rnd(32)
	a.vx = .2
	a.vy = 2.5
	a.splash_frame=0
	spr(10,a.x,a.y+20)
	return a
end

function new_ring(x,y)
	a={}
	a.x = x
	a.y = y
	a.time=0
	return a
end


function handle_ring()
	for ring in all(ring_list) do
		ring.time+=1
		if ring.time>30 then del(ring_list,ring) end
	end
end

function draw_ring()
	for ring in all(ring_list) do
		draw_oval(ring.x,ring.y,10*ring.time/10,3*ring.time/10,13)
		draw_oval(ring.x-1,ring.y,10*ring.time/10,3*ring.time/10,1)
	end
end

k_oval_sides = 10
function draw_oval(x,y,w,h,c)

	for i=0,1,1/k_oval_sides do
		line(x+w/2*cos(i),y+h/2*sin(i),x+w/2*cos(i+1/k_oval_sides),y+h/2*sin(i+1/k_oval_sides),c)
	end

end



function handle_rain()
	if(cur_frame%k_rain_delay==0)
	then
		add(rain_list,new_drop())
	end
	
	for drop in all(rain_list) do
		

		
		if(drop.y<drop.ground and pget(drop.x,drop.y)!=8) then 
			drop.y+=drop.vy
			drop.x+=drop.vx
		else
		if(drop.splash_frame==0 and pget(drop.x,drop.y)!=8) then add(ring_list,new_ring(drop.x,drop.y)) sfx(rain_fx) end
		drop.splash_frame+=1
		if(drop.splash_frame>4) then del(rain_list,drop) end
		end
	end
	
end

function draw_rain()

	for drop in all(rain_list) do
		spr(10+drop.splash_frame,drop.x-4,drop.y-8)
	end
end

function	set_pal_dark()
	pal(0,0)
	pal(1,0)
	pal(2,0)
	pal(3,1)
	pal(4,2)
	pal(5,1)
	pal(6,5)
	pal(7,5)
	pal(8,2)
	pal(9,2)
	pal(10,4)
	pal(11,3)
	pal(12,1)
	pal(13,1)
	pal(14,2)
	pal(15,2)
	palt( 10, true)
	palt( 0, false)
	

end

function	set_pal_lightning()
	pal(0,0)
	pal(1,7)
	pal(2,0)
	pal(3,1)
	pal(4,1)
	pal(5,1)
	pal(6,1)
	pal(7,1)
	pal(8,1)
	pal(9,1)
	pal(10,1)
	pal(11,1)
	pal(12,1)
	pal(13,1)
	pal(14,1)
	pal(15,1)
	palt( 10, true)
	palt( 0, false)
end


function reset_pal()
	pal()
	palt( 10, true)
	palt( 0, false)
	

end


function	handle_lightning()
	is_lightning=false
	if(rnd(100)>90) then
		set_pal_lightning()
		is_lightning=true
	end
end

function	check_lightning()
	if(is_lightning==true) then set_pal_lightning() end
end

function	draw_mouse()
	
	--spr(0,32,96, 8, 7,false,true)
	--draw_reflection first
	set_pal_dark()
	for i=0,63,1
	do
		sspr(0,0+63-i,64,1,32+sin((cur_frame+i*5+10)/50)*(i/32)*2,76+i)-- sx sy sw sh dx dy
	end
	reset_pal()
	spr(0,32,40, 8, 7)
	
		
	


end

function	new_blade(x,y,start_frame,frame_speed)
	a={}
	a.x=x
	a.y=y
	a.start_frame=start_frame
	a.frame_count=5
	a.frame_speed=frame_speed
	return a
end

function	populate_fore_grass()
	for i=0,k_num_fore_grass do
	add(fore_grass_list,new_blade(0+rnd(128),80+rnd(16)-8,flr(rnd(5)),flr(rnd(3)+5)))
	end
end
function	draw_fore_grass()
	for blade in all(fore_grass_list) do
		draw_blade(blade)
	end
end

function	populate_back_grass()
	for i=0,k_num_back_grass do
	add(back_grass_list,new_blade(0+rnd(128),60+rnd(20)-10,flr(rnd(5)),flr(rnd(3)+5)))
	end
end
function	draw_back_grass()
	for blade in all(back_grass_list) do
		draw_blade(blade)
	end
end

function	draw_blade(the_blade)
	set_pal_dark()
	spr(42+ (cur_frame/the_blade.frame_speed+the_blade.start_frame)%the_blade.frame_count,the_blade.x,the_blade.y+16, 1, 1,false,true)
	reset_pal()
	spr(26+ (cur_frame/the_blade.frame_speed+the_blade.start_frame)%the_blade.frame_count,the_blade.x,the_blade.y, 1, 2)

		
end

function	draw_ground()
	map(0,0,0,0,16,16)
	--map cel_x cel_y sx sy cel_w cel_h [layer]
end


function _init()
	populate_back_grass()
	populate_fore_grass()
	music(1,0,1)
end

function _update()

	cur_frame+=1
	handle_rain()
	handle_ring()

end

function _draw()
	cls()
	palt( 10, true)
	palt( 0, false)
	draw_ground()
	draw_ring()
	draw_back_grass()
	draw_mouse()
	draw_rain()
	
	draw_fore_grass()
		palt()
	--print(stat(1),2,2,7)
	


end



