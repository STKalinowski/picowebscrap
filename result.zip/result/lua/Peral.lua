-- peral 1.0
-- by phvli

-- game_cartridge = 'peral/peral_game.p8'
game_cartridge = '#peral_game'

par = { --    par     perfect
 time     = { -9000,  -3600 },
 money    = { 800,    1000 },
 upgrades = { 19,     -10 },
 chests   = { 30,     37 },
 kills    = { 220,    300 },
 deaths   = { -15,    -5 },
}

function build()
 memset(0x6000, 0xcc, 0x2000)
 color(7)
 draw_halo()
 sspr(44, 0, 84, 36, 20, 46)
 outline('phvli 2021', 46, 120, 12, 0)
 draw_dingbats()
 flip()
 -- extcmd('label')
 cls()
 export('-f peral/peral.html peral/peral.p8 peral/peral_game.p8')
 export('peral/peral.bin -i 0 peral/peral.p8 peral/peral_game.p8')

 stop()
end

function build_label()
 local v = 'V1.0'
 local s = 'PHVLI 2021'

 palt(0, false)
 palt(1, true)

 -- memset(0x6000, 0xcc, 0x2000)
 trophy_pal(0)
 local x, y = 20, 10
 for sy = y - 1, y + 1 do
  for sx = x - 1, x + 1 do
   sspr(44, 0, 84, 36, sx, sy)
  end
 end
 trophy_pal(1)
 sspr(44, 0, 84, 36, x, y)
 -- draw_dingbats()
 outline(v, 5, 119, 8, 0)
 outline(s, 125 - 4 * #s, 119, 8, 0)
 cstore(0x0000, 0x6000, 0x2000, 'label.p8')
end

function _init()
 cartdata('phvli_peral_0')
 poke(0x5f2d, 1)
 palt(0, false)
 palt(1, true)

 -- translation bracket: 1 or 2
 dset(63, mid(1, dget(63), 2))

 dither = {
  0b0000000000000000,
  0b1000000000000000,
  0b1000000000100000,
  0b1010000000100000,
  0b1010000010100000,
  0b1010010010100000,
  0b1010010010100001,
  0b1010010110100001,
  0b1010010110100101,
  0b1110010110100101,
  0b1110010110110101,
  0b1111010110110101,
  0b1111010111110101,
  0b1111110111110101,
  0b1111110111110111,
  0b1111111111110111,
  0b1111111111111111,
 }

 local param = stat(6)
 if param == 'label' then
  build_label()
  launch_game()
 end

 if param == 'continue' then
  launch_game()
 elseif param == 'ending' then
  music(48)
  dset(0, 0)
 else
  music(18)
  init_menu()
  logo_size = -1
 end
 bubbles = {}
 shimmer = { hp = 0 }

 for i = 1, 20 do
  add(bubbles, {
   y = 362 + rnd() * 127,
   x = rnd() * 127,
   speed = rnd() + 1,
   sprite = 4 * flr(rnd() * 1.9)
  })
 end

end

function launch_game()
 continue = dget(0) ~= 0
 music(-1, 2000)

 loading_screen()

 -- pass translations as a parameter to save space
 load(game_cartridge, '', get_translations())
end

function _update()

 if btnp(6) then
  poke(0x5f30, 1)
 end

 keyboard = stat(31)
 while stat(30) do
  keyboard = stat(31)
 end

 local enter = btnp(4) or btnp(5) or btnp(6) or keyboard == ' ' or keyboard == '\13'

 if hints then
  if btn(2) then hints -= 4 end
  if btn(3) then hints += 4 end

  if enter then
   hints = nil
  end
 elseif menu then
  if logo_size < 0 then
   if btnp() ~= 0 or keyboard ~= '' then
    logo_size = 0
   end
  elseif logo_size == 1 then
   if btnp(2) then
    repeat
     selection = (selection - 2) % #menu + 1
    until valid_selection()
   end

   if btnp(3) then
    repeat
     selection = selection % #menu + 1
    until valid_selection()
   end

   if menu[selection] == '     ' then
    enter = enter or btnp(0) or btnp(1)
   end

   -- select menu item
   if enter then
    if selection == 1 then
     -- continue game
     launch_game()

    elseif selection == 2 then
     -- new game => reset before continuing
     reset_cart()
     launch_game()

    elseif selection == 3 then
     -- switch language
     dset(63, dget(63) % 2 + 1)
     init_menu()

    elseif selection == 4 then
     -- hints
     hints = 0

    elseif selection == 5 then
     -- quit
     memset(0x6000, 0x00, 0x2000)
     flip()
     extcmd('shutdown')
    end
   end
  end
 end
end

function init_menu()
 menu = translate({
  {
   'continue',
   'new game',
   '     ',
   'hints',
   'quit'
  },
  {
   'jatka',
   'uusi peli',
   '     ',
   'vihjeet',
   'lopeta'
  }
 })

 -- exit only in pc build
 deli(menu, 5)

 continue = dget(0) ~= 0

 while not valid_selection() do
  selection = ((selection or 0) + 1) % #menu
 end
end

function valid_selection()
 if not selection then
  return false
 end

 if selection == 1 and not continue then
  return false
 end

 return selection >= 1 and selection <= #menu
end

function reset_cart()
 memset(0x5e00, 0, 0xfa)
 local cart_data = {
  [0] = 0, -- 0: game active

  -- equipment levels
  1,   -- 1: warhead
  2,   -- 2: torp cap
  1,   -- 3: bulkheads
  1,   -- 4: engine
  0,   -- 5: anti-missile system
  0,   -- 6: searchlight
  1,   -- 7: air compressor

  -- player
  400, -- 8:  x
  80,  -- 9:  y
  0,   -- 10: money
  0,   -- 11: time (s)
  0,   -- 12: kills
  0,   -- 13: deaths
  0,   -- 14: chests opened

  0,   -- 15: (unused)

  -- treasure chests & terrain changes (1 - 200)
  -- ...

  -- 63: language flag
  -- 1 = english, 2 = finnish
 }

 for i = 0, #cart_data do
  dset(i, cart_data[i])
 end
end

function _draw()
 memset(0x6000, 0x11, 0x2000)

 if hints then
  draw_hints()
 elseif menu then
  if logo_size < 0 then
   draw_intro()
  else
   draw_main_menu()
  end
 else
  draw_ending()
 end
end

function draw_intro()
 memset(0x6000, 0x11, 0x2000)

 local display_time = 9.5

 local story = translate({
  {
   'legends tell',
   'of an ancient,',
   'sunken treasure',
   'hidden in these',
   'depths...'
  },
  {
   'tarut kertovat',
   'vanhasta kulta-',
   'aarteesta, joka',
   'upposi na\+cd\x1e\|jihin',
   'vesiin...'
  }
 })

 colors = {
  13, 3, 5, 1, 1, 0, 1, 0,
  0, 1, 1, 0, 0, 1, 1, 0, 1, 0,
  1, 0, 0, 1, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 1, 1, 5, 5, 3, 13
 }

 for y = 0, 127 do
  fillp(dither[mid(1, flr((time() - display_time) * 25 - .1 * y), #dither)])
  line(0, y, 127, y, 0x1d)
 end
 fillp()
 
 draw_bubbles()

 if time() < display_time then
  for i = 1, #story do
   print(story[i], 33, 32 + 10 * i, 0)
  end

  for y = 42, 36 + #story * 10 do
   for x = 33, 96 do
    local p = pget(x, y)
    if p == 0 then
     local c = colors[mid(1, flr((time() - .05 * (y - 30)) * 10 + x % 3), #colors)]
     if c >= 0 then
      pset(x, y, c)
     end
    end
   end
  end
 end

 draw_dingbats()

 if time() > display_time + 1.5 then
  logo_size = 0
 end
end

function draw_hints()
 memset(0x6000, 0x00, 0x2000)
 local s = translate({
  {
   'where to?',
   ' go deeper. side caverns',
   ' provide money for the',
   ' necessary upgrades.',
   '',
   'air keeps running out!',
   ' air consumption increases',
   ' with depth. keep upgrading',
   ' your compressor.',
   '',
   'still lost!',
   ' have you seen a ledge you',
   ' couldn\'t reach before?',
   ' manipulate machinery to',
   ' open new pathways.',
   '',
   'how to dogfight?',
   ' use the reverse gear, and',
   ' upgrade your engine.',
   '',
   'can i upgrade everything?',
   ' yes. farm enemies if',
   ' you\'re short on cash.',
   '',
   'who\'s peral?',
   ' isaac peral designed a sub',
   ' for the spanish navy in the',
   ' late 1800\'S, and now your',
   ' task is to pilot it.',
   '',
   'what\'s the perfect score?',
   ' ◆ finish in one hour',
   ' ◆ collect ' .. par.money[2] .. ' coins',
   ' ◆ buy max ' .. -par.upgrades[2] .. ' upgrades',
   ' ◆ open all ' .. par.chests[2] .. ' chests',
   ' ◆ kill ' .. par.kills[2] .. ' enemies',
   ' ◆ die less than ' .. 1 - par.deaths[2] .. ' times',
   '',
   ' it\'s not possible to do this',
   ' all in one playthrough..?',
  }, {
   'minne menna\+cd\x1e\|j?',
   ' syvemma\+cd\x1e\|jlle. sivuluolista',
   ' saat rahaa tarpeellisia',
   ' ostoksia varten.',
   '',
   'ilma loppuu!',
   ' ilmankulutus kasvaa syvyy-',
   ' den mukana. muista pa\+cd\x1e\|jivit-',
   ' ta\+cd\x1e\|ja\+cd\x1e\|j kompressorisi.',
   '',
   'yha\+cd\x1e\|j eksyksissa\+cd\x1e\|j!',
   ' muistatko na\+cd\x1e\|jhneesi paikkoja,',
   ' joihin et viela\+cd\x1e\|j pa\+cd\x1e\|ja\+cd\x1e\|jssyt?',
   ' vanhojen kojeiden ka\+cd\x1e\|jytto\+cd\x1e\|j',
   ' avaa uusia reitteja\+cd\x1e\|j.',
   '',
   'kuinka va\+cd\x1e\|jistelen?',
   ' ka\+cd\x1e\|jyta\+cd\x1e\|j pakkia ja osta',
   ' nopeampi moottori.',
   '',
   'voinko ostaa kaiken?',
   ' kylla\+cd\x1e\|j. vihollisilta lo\+cd\x1e\|jyda\+cd\x1e\|jt',
   ' lisa\+cd\x1e\|ja\+cd\x1e\|j kolikoita, jos matti',
   ' on kukkarossa.',
   '',
   'kuka peral?',
   ' isaac peral suunnitteli',
   ' 1800-luvun lopulla espan-',
   ' jan laivastolle sukellus-',
   ' veneen, ja nyt on sinun',
   ' vuorosi ajaa silla\+cd\x1e\|j.',
   '',
   'mika\+cd\x1e\|j on ta\+cd\x1e\|jydellinen tulos?',
   ' ◆ maaliin tunnissa',
   ' ◆ ' .. par.money[2] .. ' kolikkoa kera\+cd\x1e\|jtty',
   ' ◆ eninta\+cd\x1e\|ja\+cd\x1e\|jn ' .. -par.upgrades[2] .. ' ostosta',
   ' ◆ kaikki ' .. par.chests[2] .. ' arkkua avattu',
   ' ◆ ' .. par.kills[2] .. ' vihollista tapettu',
   ' ◆ alle ' .. 1 - par.deaths[2] .. ' kuolemaa',
   '',
   ' kaikki ei varmaan onnistu',
   ' yhdella\+cd\x1e\|j pelikerralla..?',
  }
 })

 local row_spacing = 9
 hints = mid(0, hints, row_spacing * #s - 120)
 local y = 5 - hints
 for i = 1, #s do
  outline(s[i], 5, y, sub(s[i], 1, 1) == ' ' and 12 or 7, 1)
  y += row_spacing
 end
end

function calculate_score()
 if score then
  return
 end

 local pad_time = function(f)
  local s = '0' .. flr(f)
  return(sub(s, #s - 1))
 end
 local delim   = translate({ ':', '.' })
 local elapsed = pad_time(dget(11) / 3600) .. delim .. pad_time((dget(11) / 60) % 60) .. delim .. pad_time(dget(11) % 60)

 local money    = dget(10)
 local upgrades = 0
 for item in all(shop.items) do
  for tier = 0, dget(item.i) do
   if item[tier] and item[tier].c then
    money += item[tier].c
    upgrades += 1
   end
  end
 end

 local check_par = function(value, thresholds)
  for i = 2, 1, -1 do
   local threshold = thresholds[i]
   if (threshold > 0 and value >=  threshold)
   or (threshold < 0 and value <= -threshold) then
    return i
   end
  end
  return 0
 end

 score = {
  {
   icon  = 64,
   name  = translate({ 'time:', 'aika:' }),
   grade = check_par(dget(11), par.time),
   [0] = elapsed, -- subpar
   [1] = elapsed, -- par
   [2] = elapsed, -- excellent
   [3] = elapsed, -- loading screen stats
  },
  {
   icon  = 65,
   name  = translate({ 'money:', 'rahat:' }),
   grade = check_par(money, par.money),
   [0] = money .. '/' .. abs(par.money[1]),
   [1] = money .. '/' .. abs(par.money[2]),
   [2] = money,
   [3] = money,
  },
  {
   icon  = 84,
   name  = translate({ 'upgrades:', 'ostokset:' }),
   grade = check_par(upgrades, par.upgrades),
   [0] = upgrades .. '/' .. abs(par.upgrades[1]),
   [1] = upgrades .. '/' .. abs(par.upgrades[1]),
   [2] = upgrades .. '/' .. abs(par.upgrades[1]),
   [3] = upgrades .. '/' .. abs(par.upgrades[1]),
  },
  {
   icon  = 66,
   name  = translate({ 'chests:', 'arkut:' }),
   grade = check_par(dget(14), par.chests),
   [0] = dget(14) .. '/' .. abs(par.chests[2]),
   [1] = dget(14) .. '/' .. abs(par.chests[2]),
   [2] = dget(14),
   [3] = dget(14) .. '/' .. abs(par.chests[2]),
  },
  {
   icon  = 67,
   name  = translate({ 'kills:', 'tapot:' }),
   grade = check_par(dget(12), par.kills),
   [0] = dget(12) .. '/' .. abs(par.kills[1]),
   [1] = dget(12) .. '/' .. abs(par.kills[2]),
   [2] = dget(12),
   [3] = dget(12),
  },
  {
   icon  = 68,
   name  = translate({ 'deaths:', 'kuolemat:' }),
   grade = check_par(dget(13), par.deaths),
   [0] = dget(13),
   [1] = dget(13) .. '/' .. abs(par.deaths[1]),
   [2] = dget(13),
   [3] = dget(13),
  },
 }
end

function draw_main_menu()

 draw_bubbles()
 draw_dingbats()

 -- logo
 logo_size = min(logo_size + .025, 1)
 for y = 0, logo_size * 36 do
  sspr(
   44, y / logo_size,
   84, 1,
   64 - logo_size * 44 + (y > 26 and 0 or .9) * sin(y * .05 + time() * .5),
   54 - 40 * logo_size + y * logo_size,
   84 * logo_size, 1)
 end

 print('2021', 59, 9 * logo_size - 8, 0)
 print(translate({
  'phvli          gruber\nGODE&GFX        MUSIC',
  'phvli          gruber\nPELI         MUSIIKKI' }),
  23, 132 - 16 * logo_size, 0)

 if logo_size < 1 then
  return
 end

 for i = 1, #menu do
  local s = menu[i]
  local w, y =
   2 * #s,
   73 + 10 * (i - #menu / 2)

  -- language selector
  if s == '     ' then
   spr(33 + dget(63), 62 - w, y - 1)
   spr(49 + dget(63), 55 + w, y - 1)
   local x = 61 - w + (w + 3) * (dget(63) - 1)
   rect(x, y - 2, x + 8, y + 6, 0)
  end

  outline(s, 63 - w, y, (continue or i > 1) and 7 or 5)
  if i == selection then
   outline(chr(23), 55 - w, y)
   outline(chr(22), 67 + w, y)
  end
 end
end

function draw_ending()

 calculate_score()

 local chest_size = cos(.25 - min(.25, time() * .05))

 local caret = (time() - 1) * 20
 local crab_y = 30 * cos(time() / 12) - 100 * max(0, 1 - chest_size)

 local credits = translate({
  {
   [0] = {},
   { 'A GAME BY', 'phvli' },
   { 'MUSIC BY', 'gruber (CC)' },
   { 'INSPIRATION', '"sunk cost" BY', 'm2tias, juutis & bradur' },
   { 'AND "swordfish" BY', 'dan lambton-howard' },
   { 'ALSO THANKS TO', 'terttu', 'sooda', 'juutis' },
   { 'AND you!' },
   { 'YOU FOUND', 'the treasure' },
   { 'thanks for playing!' },
  },
  {
   [0] = {},
   { 'PELIN TEKI', 'phvli' },
   { 'MUSIIKKI', 'gruber (CC)' },
   { 'INSPIRAATIO', 'm2tiaksen, juutiksen', 'ja bradurin "sunk cost"' },
   { 'JA dan lambton-howardIN', '"swordfish"' },
   { '      KIITOS MYO\+cd\x1e\|jS', 'terttu', 'sooda', 'juutis' },
   { '      JA sina\+cd\x1e\|j!' },
   { '      lo\+cd\x1e\|jysit uponneen', 'kulta-aarteen' },
   { 'kiitos kun pelasit!' },
  }
 })

 color(12)
 draw_halo(64, 95, s)
 draw_bubbles()

 -- crab & treasure chest
 if crab_y > -20 then
  sspr(0, 40, 14, 10, 36, 75 - min(0, crab_y))
 end
 sspr(0, 70, 128, 58, 64 - chest_size * 64, 95 - 29 * chest_size, 128 * chest_size, 58 * chest_size)
 if crab_y > -20 then
  spr(mid(112, 127 + crab_y, 117), 30, 80)
 end

 draw_dingbats()

 local credit_spacing = 130
 local group_index = max(0, flr(caret / credit_spacing) + 1)
 local group = credits[group_index]
 if group then
  n = caret % credit_spacing
  local y = 40 - #group * 4.5 - 5 * max(0, n + 15 - credit_spacing)
  if group_index == #credits then
   y = max(12, y)
  end

  for i, line in pairs(group) do
   blink(line, 64, y, true, n)
   n -= #line
   y += 9
  end
 else
  local y = 12
  blink(credits[#credits][1], 64, y, true)
  caret -= credit_spacing * #credits
  y += 12
  local trophies = 0
  local perfect_trophies = false
  for i = 1, min(#score, caret / 8) do
   local grade = score[i].grade
   local x, s = 100, '' .. score[i][grade]
   trophies += grade
   perfect_trophies = perfect_trophies or grade == 1

   if caret < 75 or (caret < 100 and time() % .25 < .125) then grade = 0 end

   outline_spr(score[i].icon, x, y, grade)

   if grade == 2 then
    blink(s, x - 4 - 4 * #s, y)
    blink(score[i].name, 17, y)
   else
    local fg = grade > 0 and 11 or 5
    outline(s, x - 4 - 4 * #s, y, fg)
    outline(score[i].name, 17, y, fg)
   end

   y += 9
  end

  -- speech bubble
  if crab_y >= 9 then
   local x0, y0 = 40, 63
   ovalfill(x0, y0, x0 + 20, y0 + 10, 7)
   for x1 = x0 + 2, x0 + 6 do
    line(x0, y0 + 11, x1, y0 + 5, 7)
   end
   local s = trophies .. '/5'
   print(s, x0 + 11 - 2 * #s, y0 + 3, 0)
  end
 end

 if chest_size > 0.9 then
  shimmer.hp -= .033
  if shimmer.hp <= 0 then
   while true do

    if perfect_trophies and rnd() < .6 then
     shimmer = {
      hp = .5 + rnd() / 2,
      -- x  = rnd() * 10 + 99,
      x  = rnd() * 64 + 64,
      y  = rnd() * 60 + 22,
     }
    else
     shimmer = {
      hp = .5 + rnd(),
      x  = rnd() * 128,
      y  = rnd() * 30 + 74,
     }
    end

    local p = pget(shimmer.x, shimmer.y)
    if p == 7 or p == 10 or p == 15 then
     break
    end
   end
  end

  local n = flr(shimmer.hp * 10)
  if n == 4 then
   pal(10, 7)
  else
   pal(10, 10)
  end
  if n < 5 then
   n += 16
   spr(n, shimmer.x - 7, shimmer.y - 7, 1, 1, false, false)
   spr(n, shimmer.x,     shimmer.y - 7, 1, 1, true,  false)
   spr(n, shimmer.x - 7, shimmer.y,     1, 1, false, true)
   spr(n, shimmer.x,     shimmer.y,     1, 1, true,  true)
  end
 end
end

function draw_halo(x, y, s)
 x = x or 64
 y = y or 64
 s = s or 1
 for n = time() * .05, time() * .05 + .99, .33 do
  for a = n, n + s * .07, .001 do
   local cosn, sine = 120 * cos(a), 120 * sin(a)
   line(x - cosn, y - sine, x + cosn, y + sine)
   line(x - cosn, y - sine + 1, x + cosn, y + sine + 1)
  end
 end
end

function draw_bubbles()
 for i = 1, #bubbles do
  local b = bubbles[i]
  b.y -= b.speed
  if b.y < -5 then b.y += 150 end
  sspr(40, b.sprite, 4, 4, b.x + b.speed * sin(time() * b.speed), b.y)
 end
end

function draw_dingbats()
 spr(32, 1,   1, 2, 2,   false, true)
 spr(32, 1,   111, 2, 2, false, false)
 spr(32, 111, 1, 2, 2,   true,  true)
 spr(32, 111, 111, 2, 2, true,  false)
end

function blink(s, x, y, center, len)
 len = len or #s
 if len <= 0 then
  return
 end

 s = sub(s, 1, len)

 if center then
  x -= 2 * #s
 end

 outline(s, x, y, 9, 0)

 for c = 1, #s do
  if ord(sub(s, c, c)) < 32 then return end
 end

 s = '      ' .. s .. '      '
 local n = flr(time() * 50 + y * .1) % 100 + 1
 if n < #s then
  outline(sub(s, n - 3, n + 3), x + 4 * n - 40, y, 10, 0)
  outline(sub(s, n - 1, n + 1), x + 4 * n - 32, y, 7, 2)
 end
end

function loading_screen()
 for t = -1.5, 1.5, .03 do
  for y = 0, 127 do
   fillp(dither[mid(1, flr(t * 25 + .1 * y), #dither)])
   line(0, y, 127, y, 0xc1)
  end

  draw_dingbats()

  if continue then
   calculate_score()
   for i = 1, #score do
    local grade = score[i].grade
    local x, y = 58, 62 + 12 * (i - #score / 2 - .5)

    outline(score[i][3], x, y, 13)
    outline_spr(score[i].icon, x - 14, y, 3)
   end

  else
   local s = translate({ 'bon voyage!', 'onnea matkaan!' })
   outline(s, 64 - 2 * #s, 62)
  end
  flip()
 end
end

function outline(s, x, y, fg, bg)
 color(bg or 0)
 for dx = x - 1, x + 1 do
  print(s, dx, y - 1)
  print(s, dx, y + 1)
 end
 print(s, x - 1, y)
 print(s, x + 1, y)
 print(s, x, y, fg or 7)
end

function trophy_pal(pal_i)
 local trophy_colors = {
  [0] = { 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
  [1] = { 1,  2,  3,  4,  5,  6,  7,  8,  9,  10, 11, 12, 13, 14, 15 },
  [2] = { 4,  4,  9,  9,  4,  9,  7,  10, 10, 7,  10, 10,  9, 10, 7 },
  [3] = { 1,  1,  13, 13, 5,  6,  6,  6,  6,  6,  6,  6,  6,  6,  6 }
 }

 pal(trophy_colors[pal_i])
end

function outline_spr(i, x, y, grade)
 local trophy_colors = {
  [0] = { 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0 },
  [1] = { 1,  2,  3,  4,  5,  6,  7,  8,  9,  10, 11, 12, 13, 14, 15 },
  [2] = { 4,  4,  9,  9,  4,  9,  7,  10, 10, 7,  10, 10,  9, 10, 7 },
  [3] = { 1,  1,  13, 13, 5,  6,  6,  6,  6,  6,  6,  6,  6,  6,  6 }
 }

 if grade > 0 then
  trophy_pal(0)
  for sy = y - 3, y - 1 do
   for sx = x - 1, x + 1 do
    spr(i, sx, sy)
   end
  end
 end
 trophy_pal(grade)
 spr(i, x, y - 2)
 trophy_pal(1)
end

-->8

-- translations

function translate(s)
 return s[$0x5efc]
end

function get_translations()
translations = {
    -- equipment names
    [1] = translate({
        'warhead',
        '      taisteluka\+cd\x1e\|jrki',
    }),
    [2] = translate({
        'torpedo reserves',
        'ammusvarannot',
    }),
    [3] = translate({
        'bulkheads',
        'laipiot',
    }),
    [4] = translate({
        'engine',
        'moottori',
    }),
    [5] = translate({
        'anti-missile system',
        '            ohjuspuolustusja\+cd\x1e\|jrjestelma\+cd\x1e\|j',
    }),
    [6] = translate({
        'searchlight',
        'valaisin',
    }),
    [7] = translate({
        'air compressor',
        'ilmakompressori',
    }),

    -- equipment descriptions
    [11] = translate({
    --   --------------------------|-------------------------|-------------------------|
        'more powerful explosives\ncan destroy tougher\nenemies and obstacles.',
        'tehokkaampi r-aine voi\nlapaista kovemmat esteet\nja panssarit.',
    }),
    [12] = translate({
    --   --------------------------|-------------------------|-------------------------|
        'additional torpedoes\nallow you to fire\nlarger salvos.',
        'isompi reservi mahdol-\nlistaa useamman torpedon\nampumisen samanaikaisesti.',
    }),
    [13] = translate({
    --   --------------------------|-------------------------|-------------------------|
        'reinforcements increase\nyour safe diving depth\nand protect from damage.',
        'kasvattavat turvallista\nsukellussyvyytta ja suo-\njaavat runkoa iskuilta.',
    }),
    [14] = translate({
    --   --------------------------|-------------------------|-------------------------|
        'improves speed, turn rate\nand acceleration.',
        'nopeuttaa alustasi ja\ntekee sen ketterammaksi.',
    }),
    [15] = translate({
    --   --------------------------|-------------------------|-------------------------|
        'automatically destroys\nincoming projectiles.\nneeds time to rearm.',
        'tuhoaa vihollisammukset.\nlatautuu hetken laukausten\nvalissa.',
    }),
    [16] = translate({
    --   --------------------------|-------------------------|-------------------------|
        'lights your way in the\ndarkest abyss.',
        'valaisee tummat vedet.\npaivittaminen parantaa\nlampun valotehoa.',
    }),
    [17] = translate({
    --   --------------------------|-------------------------|-------------------------|
        'increases air capacity\nfor longer dives.',
        'pakkaa ilmavarantojasi\nsyvempia sukelluksia\nvarten.',
    }),

    -- dock ui
    [20] = translate({
        'tier ',
        'taso ',
    }),
    [21] = translate({
        ' cost:',
        'hinta: ',
    }),
    [22] = translate({
        '  fully upgraded',
        'markkinoiden paras',
    }),

    -- welcome
    [0] = translate({
        '   ⬅️➡️/⬆️⬇️: steer\n\n    space/❎: fire\n    shift/🅾️: reverse',
        '    ⬅️➡️/⬆️⬇️: ohjaa\n\nva\+cd\x1e\|jlilyo\+cd\x1e\|jnti/❎: laukaise\n    vaihto/🅾️: pakita',
    }),

    -- dock ui
    [30] = translate({
        'depth',
        '\+efsyvyys',
    }),

    -- death
    [90] = translate({
        '    o u t   o f    \n\n    o x y g e n',
    --   012345678|876543210 \n 012345678|876543210
        '      i l m a      \n\n    l o p p u i',
    }),
    [91] = translate({
        'c r u s h e d   b y\n\n  p r e s s u r e',
    --   012345678|876543210 \n 012345678|876543210
        '   p a i n e e n   \n\n m u s e r t a m a',
    }),

    [98] = translate({
        'retry from dock',
        'palaa telakalle',
    }),

    [99] = translate({
        'back to menu',
        'alkuvalikkoon',
    }),
}



 return pack(translations)
end

function pack(table)
 local s = ''
 for k, v in pairs(table) do
  local t = type(v)
  s ..= '' .. k
  if t == 'number' then
   s ..= '\2' .. v
  elseif t == 'string' then
   s ..= '\3' .. v
  elseif t == 'table' then
   s ..= '\4' .. pack(v)
  else
   cls()
   camera()
   print('unsupported type "' .. t .. '"', 5, 5, 8)
   stop()
  end
  s ..= '\1'
 end

 return s
end

-->8
-- data files
shop = {
-- {
--  cost in coins:
--  c = 42,

--  icon: map_x, map_y, w, h
--  i = { 4, 51, 3, 1 },

--  effect
--  e = { pow = 666 }
-- },


 sel    = 0,
 wheel  = 0,
 typing = 0,

 items = {
  {
   -- warhead
   i = 1,
   {
    i = { 4, 51, 3, 1 },
    e = { pow = 1 }
   },
   {
    c = 30,
    i = { 4, 52, 4, 1 },
    e = { pow = 2 }
   },
   {
    c = 30,
    i = { 4, 53, 4, 2 },
    e = { pow = 3 }
   },
   {
    c = 125,
    i = { 4, 53, 4, 3 },
    e = { pow = 4 }
   },
  },

  {
   -- torpedo
   i = 2,
   --[1] = {
   --  i = { 0, 53, 2, 1 },
   --  e = { tubes = 1 }
   -- },
   [2] = {
    -- c = 8,
    i = { 0, 53, 2, 2 },
    e = { tubes = 2 }
   },
   [3] = {
    c = 10,
    i = { 0, 52, 4, 2 },
    e = { tubes = 3 }
   },
   [4] = {
    c = 15,
    i = { 0, 51, 4, 3 },
    e = { tubes = 4 }
   },
   [5] = {
    c = 25,
    i = { 0, 53, 4, 2 },
    e = { tubes = 5 }
   },
   [6] = {
    c = 35,
    i = { 0, 52, 4, 3 },
    e = { tubes = 6 }
   },
   -- [7] = {
   --  c = 32,
   --  i = { 0, 51, 4, 4 },
   --  e = { tubes = 7 }
   -- },
   -- [8] = {
   --  c = 36,
   --  i = { 0, 53, 4, 3 },
   --  e = { tubes = 8 }
   -- },
   -- [9] = {
   --  c = 42,
   --  i = { 0, 52, 4, 4 },
   --  e = { tubes = 9 }
   -- },
   -- [10] = {
   --  c = 64,
   --  i = { 0, 51, 4, 5 },
   --  e = { tubes = 10 }
   -- },
  },

  {
   -- bulkheads
   i = 3,
   {
    i = { 15, 53, 1, 3 },
    e = {
      armor = 1.0,
      maxy  = 1300
    }
   },
   {
    c = 30,
    i = { 14, 53, 2, 3 },
    e = {
      armor = 1.5,
      maxy  = 2050
    }
   },
   {
    c = 50,
    i = { 12, 53, 3, 3 },
    e = {
      armor = 2.0,
      maxy  = 2500
    }
   },
   {
    c = 75,
    i = { 12, 53, 4, 3 },
    e = {
      armor = 2.5,
      maxy  = 3000
    }
   },
  },

  {
   -- engine
   i = 4,
   {
    i = { 19, 53, 3, 2 },
    e = {
      d_yaw  = 0.007, -- turn rate
      accel  = 0.03,  -- acceleration
      maxspd = 1.5,   -- top speed
    }
   },
   {
    c = 20,
    i = { 19, 53, 4, 3 },
    e = {
      d_yaw  = 0.009, -- turn rate
      accel  = 0.04,  -- acceleration
      maxspd = 2.0,   -- top speed
    }
   },
   {
    c = 65,
    i = { 16, 53, 5, 3 },
    e = {
      d_yaw  = 0.014, -- turn rate
      accel  = 0.07,  -- acceleration
      maxspd = 2.5,   -- top speed
    }
   },
  },

  {
   -- anti-missile system
   i = 5,
   [0] = { e = { aws = 0 } },
   {
    c = 100,
    i = { 31, 53, 3, 3 },
    e = { aws = 0.007 }
   },
   {
    c = 75,
    i = { 34, 53, 4, 3 },
    e = { aws = 0.017 }
   },
  },

  {
   -- searchlight
   i = 6,
   [0] = { e = { light = 0 } },
   {
    c = 50,
    i = { 10, 51, 3, 2 },
    e = { light = 0.085 }
   },
   {
    c = 25,
    i = { 13, 51, 4, 2 },
    e = { light = 0.150 }
   },
   {
    c = 50,
    i = { 8, 52, 4, 4 },
    e = { light = 0.225 }
   },
  },

  {
   -- air filter
   i = 7,
   {
    i = { 23, 53, 2, 3 },
    e = { sac = 2 }
   },
   {
    c = 15,
    i = { 25, 53, 3, 3 },
    e = { sac = 1 }
   },
   {
    c = 30,
    i = { 28, 53, 3, 3 },
    e = { sac = 0 }
   },
  },

 },
}




