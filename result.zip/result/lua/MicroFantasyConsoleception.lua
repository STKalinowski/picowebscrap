local bc=1

local infobar1=""
local infobar2="hi"

local blinkc=0
local blink=true


map(0,0,0,0,16,16)

local rom={}
rom.scroll=0
rom.cursor=0
rom.val={}
rom.stack={}
rom.progc=0
rom.running=false
rom.savec=0
for i=0,256 do
	rom.val[i]={}
	rom.val[i].i=nil
	rom.val[i].p1=nil
	rom.val[i].p2=nil
	rom.val[i].v1=-1
	rom.val[i].v2=-1
	rom.val[i].gval1=function(self)
		return self.p1.gval(self.v1)
	end
	rom.val[i].gval2=function(self)
		return self.p2.gval(self.v2)
	end
	rom.val[i].exec=function(self)
		if (not self.i) return
		self.i.p(self)
	end
end

local ram={}
ram.scroll=0
ram.curx=0
ram.cury=0
ram.val={}
for i=0,256 do
	ram.val[i]=0
end
ram.set=function(i,v)
	while v<0 do
		v+=256
	end
	while v>255 do
		v-=256
	end
	ram.val[i]=v
end

local isel={}
isel.cur=0
isel.exp={}
isel.ind=0
isel.cb=false

local bedit={}
bedit.cur=7
bedit.val=0
bedit.focus=isel

local game={}

local focus=rom

focus=rom


function dbyte(x,y,v)
	if(band(v,128)>0)pset(x+1,y+1,bc)
	if(band(v,64)>0)pset(x+2,y+1,bc)
	if(band(v,32)>0)pset(x+4,y+1,bc)
	if(band(v,16)>0)pset(x+5,y+1,bc)
	if(band(v,8)>0)pset(x+1,y+3,bc)
	if(band(v,4)>0)pset(x+2,y+3,bc)
	if(band(v,2)>0)pset(x+4,y+3,bc)
	if(band(v,1)>0)pset(x+5,y+3,bc)
end


local error={}
error.msg="test error"
error.ofocus=rom
error.d=function()
	rectfill(0,0,128,7,0)
	rectfill(0,0,128,6,8)
	print(error.msg,1,1,7)
end
error.u=function()
	if btnp(5) then
		focus=error.ofocus
	end
	infobar2="❎ close message"
end
function err(msg)
	error.msg=msg
	error.ofocus=focus
	focus=error
end
-->8

local icount=1
local iall={}
function idef(lbl)
	local i={}
	i.lbl=lbl
	i.s=14
	i.w=1
	i.exp1=nil
	i.exp2=nil
	i.v=false
	i.p=function(ins)
		
	end
	i.index=icount
	add(iall,i)
	icount+=1
	local this=i
	i.d=function(x,y,v)
		for i=0,this.w-1 do
			spr(this.s+i,x+i*8,y)
		end
		if this.v then
			dbyte(x,y+1,v)
		end
	end
	return i
end

local vnum=idef("number (number)")
vnum.s=4
vnum.v=true
vnum.gval=function(v)
	return v
end
local vram=idef("number in ram (address)")
vram.s=54
vram.v=true
vram.gval=function(v)
	return ram.val[v]
end
local lram=idef("ram address (address)")
lram.s=20
lram.v=true
lram.gval=function(v)
	return v
end
local lrami=idef("ram address in ram (address)")
lrami.s=53
lrami.v=true
lrami.gval=function(v)
	return ram.val[v]
end

local lrom=idef("rom address")
lrom.s=36
lrom.v=true
lrom.gval=function(v)
	return v
end
local lromi=idef("rom address in ram")
lromi.s=52
lromi.v=true
lromi.gval=function(v)
	return ram.val[v]
end

local expl={lram,lrami}
local expv={vnum,vram}
local exprl={lrom,lromi}

local iset=idef("set")
iset.s=38
iset.exp1=expl
iset.exp2=expv
iset.p=function(ins)
	local l=ins.gval1(ins)
	ram.set(l,ins.gval2(ins))
end

local iadd=idef("add")
iadd.s=6
iadd.exp1=expl
iadd.exp2=expv
iadd.p=function(ins)
	local l=ins.gval1(ins)
	ram.set(l,ram.val[l]+ins.gval2(ins))
end

local isub=idef("subtract")
isub.s=22
isub.exp1=expl
isub.exp2=expv
isub.p=function(ins)
	local l=ins.gval1(ins)
	ram.set(l,ram.val[l]-ins.gval2(ins))
end

local ijmp=idef("jump")
ijmp.s=48
ijmp.w=2
ijmp.exp1=exprl
ijmp.p=function(ins)
	local l=ins.gval1(ins)
	rom.progc=l
end

local ijmpe=idef("jump if 0")
ijmpe.s=16
ijmpe.w=2
ijmpe.exp1=exprl
ijmpe.exp2=expv
ijmpe.p=function(ins)
	local l=ins.gval1(ins)
	if ins.gval2(ins)==0 then
		rom.progc=l
	end
end

local ijmpl=idef("jump if not 0")
ijmpl.s=32
ijmpl.w=2
ijmpl.exp1=exprl
ijmpl.exp2=expv
ijmpl.p=function(ins)
	local l=ins.gval1(ins)
	if ins.gval2(ins)>0 then
		rom.progc=l
	end
end

local icall=idef("call")
icall.s=50
icall.w=2
icall.exp1=exprl
icall.p=function(ins)
	local l=ins.gval1(ins)
	add(rom.stack,rom.progc)
	rom.progc=l
end

local iret=idef("return")
iret.s=34
iret.w=2
iret.p=function(ins)
	if #rom.stack>0 then
 	rom.progc=rom.stack[#rom.stack]
 	local ns={}
 	for i=1,#rom.stack-1 do
 		add(ns,rom.stack[i])
 	end
 	rom.stack=ns
	end
end

local ior=idef("or")
ior.s=55
ior.exp1=expl
ior.exp2=expv
ior.p=function(ins)
	local l=ins.gval1(ins)
	ram.set(l,bor(ram.val[l],ins.gval2(ins)))
end

local iand=idef("and")
iand.s=56
iand.exp1=expl
iand.exp2=expv
iand.p=function(ins)
	local l=ins.gval1(ins)
	ram.set(l,band(ram.val[l],ins.gval2(ins)))
end

local inot=idef("not (invert)")
inot.s=57
inot.exp1=expl
inot.exp2=expv
inot.p=function(ins)
	local l=ins.gval1(ins)
	ram.set(l,bnot(ins.gval2(ins)))
end

local ishiftl=idef("bit shift left (x*2)")
ishiftl.s=58
ishiftl.exp1=expl
ishiftl.exp2=expv
ishiftl.p=function(ins)
	local l=ins.gval1(ins)
	local a=ins.gval2(ins)
	local v=ram.val[l]
	for i=1,a do
		v=v*2
	end
	ram.set(l,v)
end

local ishiftr=idef("bit shift right (x/2)")
ishiftr.s=59
ishiftr.exp1=expl
ishiftr.exp2=expv
ishiftr.p=function(ins)
	local l=ins.gval1(ins)
	local a=ins.gval2(ins)
	local v=ram.val[l]
	for i=1,a do
		v=flr(v/2)
	end
	ram.set(l,v)
end

local vrami=idef("pointer to number in ram (address)")
vrami.s=41
vrami.v=true
vrami.gval=function(v)
	return ram.val[ram.val[v]]
end
add(expv,vrami)

defexp={
	iset,
	iadd,
	isub,
	ijmp,
	ijmpe,
	ijmpl,
	ior,
	iand,
	inot,
	ishiftl,
	ishiftr,
	icall,
	iret
}
-->8

rom.d=function()
	local x=0
	local y=0
	local s = rom.scroll
	spr(5,x*8,(y-s)*8)
	for j=1,5 do
		spr(1,(x+j)*8,(y-s)*8)
	end
	for i=1,256 do
		spr(21,x*8,(y+i-s)*8)
		dbyte(x*8,(y+i-s)*8+1,i-1)
		for j=1,4 do
			spr(2,(x+j)*8,(y+i-s)*8)
			if focus==rom and i-1==rom.cursor then
				spr(3,(x+j)*8,(y+i-s)*8)
			end
		end
		spr(1,(x+5)*8,(y+i-s)*8)
		
		local rv=rom.val[i-1]
		if rv.i then
			rv.i.d(x*8+8,(y+i-s)*8)
			if rv.p1 then
				rv.p1.d((x+rv.i.w)*8+8,(y+i-s)*8,rv.v1)
			end
			if rv.p2 then
				rv.p2.d((x+rv.i.w+1)*8+8,(y+i-s)*8,rv.v2)
			end
		end
	end
	for j=0,5 do
		spr(1,(x+j)*8,(y+257-s)*8)
	end
	
	if focus==rom then
	
		if rom.val[rom.cursor].i==nil then
			spr(29,(x+1)*8,(y+rom.cursor+1-s)*8)
		end
	end
	
	if rom.running then
		spr(37,(x+5)*8,(y+1+rom.progc)*8)
	end
end

rom.u=function()
	local c=rom.cursor
	
	if rom.val[rom.cursor].i==nil then
		
		infobar2="❎ add. "
		
 	if btnp(5) then
 		isel.exp=defexp
 		focus=isel
 	end
 	
	else
	
 	if btn(4) then
 	
 		infobar2="⬆️/⬇️ move. ❎ remove."
 	
			if btnp(5) then
				rom.val[c].i=nil
				rom.val[c].p1=nil
				rom.val[c].p2=nil
				rom.val[c].v1=-1
				rom.val[c].v2=-1
			end
			if btnp(2) and c>0 then
				local t=rom.val[c]
				rom.val[c]=rom.val[c-1]
				rom.val[c-1]=t
			end
			if btnp(3) and c<255 then
				local t=rom.val[c]
				rom.val[c]=rom.val[c+1]
				rom.val[c+1]=t
			end
 	
 	else
			infobar2="❎ edit. hold+🅾️ (re)move."
		end
		
	end
	
	if (btnp(3))c+=1
	if (btnp(2))c-=1
	if (c<0)c=0
	if (c>255)c=255
	rom.cursor=c
	
	local s=rom.scroll
	if c-s>11 then
		s+=1
	end
	if c-s<0 then
		s-=1
	end
	rom.scroll=s
	
	infobar1="line:"..c.."/255    2x⬅️ save."

	rom.savec-=1
	if(rom.savec<0)rom.savec=0
	if btnp(0) then
		if rom.savec==0 then
			rom.savec=16
		else
			rom.savec=0
			rom.save()
		end
	end
	
	if btnp(1) then
		ram.cury=(c-s)*2
		ram.curx=0
		
		focus=ram
		if ram.cury>16 then
			focus=game
		end
	end
end

rom.proceed=function()
	if rom.progc>255 then
		rom.progc=0
		rom.running=false
		return
	end
	local p=false
	local ins
	while not p and rom.progc<256 do
		ins=rom.val[rom.progc]
		p=ins.i!=nil
		rom.progc+=1
	end
	ins.exec(ins)
end

rom.exec=function()
	rom.progc=0
	rom.running=true
	
	for i=0,256 do
		ram.val[i]=0
	end
end

rom.save=function()
	local loc=0x5e00
	--loc=0x4300
	local bytes={}
	
	local gap=0
	
	for i=0,255 do
 	local ins=rom.val[i]
 	if ins.i then
 		if gap>0 then
 			add(bytes,0)
 			add(bytes,gap)
 			gap=0
 		end
 		add(bytes,ins.i.index)
 		if ins.p1 then
  		add(bytes,ins.p1.index)
  		add(bytes,ins.v1)
  		if ins.p2 then
   		add(bytes,ins.p2.index)
   		add(bytes,ins.v2)
  		end
 		end
 	else
 		gap+=1
 	end
	end
	
	for i=0,255 do
		poke(loc+i,0)
	end
	for i=0,#bytes-1 do
		if i>=256 then
			break
		end
		poke(loc+i,bytes[i+1])
	end
	err("program saved. "..#bytes.."/256 bytes")

	--cstore(0x3100,0x5e00,0x0100)
end

rom.load=function(loc)
	local bytes={}
	local lastval=-1
	for i=0,255 do
		local val=peek(loc+i)
		add(bytes,val)
		if val==0 and lastval==0 then
			break
		end
		lastval=val
	end
	
	local rp=0
	local i=1
	while i<=#bytes do
		local index=bytes[i]
		if index==0 then
			i+=1
			if i>#bytes then
				break
			end
			local offset=bytes[i]
			rp+=offset
		else
			local ins=iall[index]
			local rins=rom.val[rp]
			rins.i=ins
			if ins.exp1 then
				i+=1
				rins.p1=iall[bytes[i]]
				i+=1
				rins.v1=bytes[i]
				if ins.exp2 then
 				i+=1
 				rins.p2=iall[bytes[i]]
 				i+=1
 				rins.v2=bytes[i]
				end
			end
			rp+=1
		end
		i+=1
	end
end
-->8

ram.cval=function(x,y)
	return ram.val[x+y*16]
end

ram.d=function()
	local x=6
	local y=0
	
	local s=ram.scroll
	
	map(6,0,(x-s)*8,y*8,18,10)
	
	for i=1,16 do
		dbyte((x+i-s)*8,y*8+3,i-1)
		dbyte((x-s)*8,(y+i)*4+1,i-1)
	
 	for j=1,16 do
 		dbyte((x+i-s)*8,(y+1)*8+(j-1)*4-1,ram.cval(i-1,j-1))
 	end
	end
	
	if focus==ram and blink then
 	spr(9,(x+1-s)*8+ram.curx*8,(y+1)*8+ram.cury*4-1)
	end
end

ram.u=function()
	if (btnp(0))ram.curx-=1
	if (btnp(1))ram.curx+=1
	if (btnp(2))ram.cury-=1
	if (btnp(3))ram.cury+=1
	
	if (ram.curx>15)ram.curx=15
	if (ram.cury<0)ram.cury=0
	if ram.curx<0 then
		ram.curx=0
		rom.cursor=flr(ram.cury/2)+rom.scroll
		focus=rom
	end
	if ram.cury>15 then
		ram.cury=15
		focus=game
	end
	
	local s=ram.scroll
	if (ram.curx-s>7)s+=1
	if (ram.curx-s<0)s-=1
	if (s<0)s=0
	
	ram.scroll=s
	
	infobar1="address:"..ram.curx+ram.cury*16
	infobar2="  value:"..ram.cval(ram.curx,ram.cury)
end
-->8

isel.d=function()
	local x=64-32
	local l=-flr(-#isel.exp/2)
	local y=56-8-l*8/2
	
	rectfill(x,y+1,x+56+2,y+16+l*8+1,0)
	rectfill(x-1,y,x+56+1,y+16+l*8,1)
	spr(46,x-1,y)
	
	if blink then
		if isel.cur<l then
			spr(30,x,y+8+isel.cur*8)
		else
			spr(30,x+24,y+8+(isel.cur-l)*8)
		end
	end
	
	for i=1,#isel.exp do
		local ins=isel.exp[i]
		if i<=l then
			ins.d(x+8,y+i*8)
		else
			ins.d(x+32,y+(i-l)*8)
		end
	end
end

isel.u=function()
	local l=-flr(-#isel.exp/2)
	if(btnp(0))isel.cur-=l
	if(btnp(1))isel.cur+=l
	if(isel.cur<0)isel.cur+=l
	if(isel.cur>=#isel.exp)isel.cur-=l

	if(btnp(3))isel.cur+=1
	if(btnp(2))isel.cur-=1
	if(isel.cur<0)isel.cur=0
	if(isel.cur>=#isel.exp)isel.cur=#isel.exp-1

	if btnp(4) then
		rom.val[rom.cursor].i=nil
		rom.val[rom.cursor].p1=nil
		rom.val[rom.cursor].p2=nil
		rom.val[rom.cursor].v1=-1
		rom.val[rom.cursor].v2=-1
		isel.ind=0
		isel.cb=false
		focus=rom
	end
	if btnp(5)or isel.cb then
		isel.cb=false
		local ins=isel.exp[isel.cur+1]
		focus=rom
		if isel.ind==0 then
			rom.val[rom.cursor].i=ins
 		if ins.exp1 then
 			isel.ind=1
 			isel.indi=ins
 			isel.exp=ins.exp1
 			isel.cur=0
 			focus=isel
 		end
		elseif isel.ind==1 then
			rom.val[rom.cursor].p1=ins
			if rom.val[rom.cursor].v1==-1 then
				rom.val[rom.cursor].v1=0
				bedit.focus=isel
				bedit.val=0
				focus=bedit
				isel.cb=true
 		elseif isel.indi.exp2 then
 			isel.ind=2
 			isel.exp=isel.indi.exp2
 			isel.cur=0
 			focus=isel
 			rom.val[rom.cursor].v1=bedit.val
 		else
 			isel.ind=0
 			rom.val[rom.cursor].v1=bedit.val
 		end
 		
		else
			rom.val[rom.cursor].p2=ins
			if rom.val[rom.cursor].v2==-1 then
				rom.val[rom.cursor].v2=0
				bedit.focus=isel
				bedit.val=0
				focus=bedit
				isel.cb=true
			else
 			rom.val[rom.cursor].v2=bedit.val
 			isel.ind=0
 		end
		end
	end

	infobar1=isel.exp[isel.cur+1].lbl
	infobar2="❎ select"
end
-->8

bedit.curp={
	{8,8},
	{16,8},
	{32,8},
	{40,8},
	{8,24},
	{16,24},
	{32,24},
	{40,24},
}

bedit.d=function()
	local x=36
	local y=36
	rectfill(x+1,y+1,92,76,1)
	map(16,10,x,y,7,5)
	
	if blink then
		local cp=bedit.curp[bedit.cur+1]
		spr(60,x+cp[1],y+cp[2])
	end
	
	for i=1,8 do
			local v=2^(8-i)
			if band(v,bedit.val)>0 then
				local p=bedit.curp[i]
				rectfill(x+p[1]+1,y+p[2]+1,x+p[1]+6,y+p[2]+6,1)
			end
	end
end

bedit.u=function()
		local c=bedit.cur
		if (btnp(1))c+=1
		if (btnp(0))c-=1
		if (c<0)c=0
		if (c>7)c=7
		
		if (btnp(3))c+=4
		if (btnp(2))c-=4
		if (c<0)c+=4
		if (c>7)c-=4
		bedit.cur=c
		
		if btnp(5) then
			local v=2^(7-bedit.cur)
			bedit.val=bxor(bedit.val,v)
		end
		if btnp(4) then
			focus=bedit.focus
		end
		
		infobar1="value:"..bedit.val
		infobar2="❎ toggle bit. 🅾️ apply."
end
-->8

game.d=function()
	map(6,10,48,80,80,32)
	
	if not rom.running then
		if focus!=game or blink then
			spr(88,84,92)
		end
	else
	
		for i=0,31 do
 		local b={
 			band(ram.val[i],1)>0,
 			band(ram.val[i],2)>0,
 			band(ram.val[i],4)>0,
 			band(ram.val[i],8)>0,
 			band(ram.val[i],16)>0,
 			band(ram.val[i],32)>0,
 			band(ram.val[i],64)>0,
 			band(ram.val[i],128)>0,
 		}
 		for j=1,8 do
 			local p=i*8+j-1
 			local y=flr(p/16)
 			local x=p-y*16
 			if b[9-j] then
 				pset(80+x,88+y,3)
 			else
 				pset(80+x,88+y,11)
 			end
 		end
		end
		
		ram.val[32]=0
		if btn(0) then
			ram.val[32]=bor(ram.val[32],1)
		end
		if btn(1) then
			ram.val[32]=bor(ram.val[32],2)
		end
		if btn(2) then
			ram.val[32]=bor(ram.val[32],4)
		end
		if btn(3) then
			ram.val[32]=bor(ram.val[32],8)
		end
		if btn(4) then
			ram.val[32]=bor(ram.val[32],16)
		end
		if btn(5) then
			ram.val[32]=bor(ram.val[32],32)
		end
	end
end

game.u=function()
	infobar1=""
	if btn(5) and btn(4) then
		rom.running=false
	end
	
	if rom.running then
		rom.proceed()
		infobar2="❎🅾️ terminate"
	else
		if btnp(2) then
			focus=ram
			ram.cury=15
		end
		if btnp(0) then
			focus=rom
		end
		if (btnp(5))rom.exec()
		
		--infobar2="❎🅾️ exit game"
		infobar2="❎ run game"
	end
end
-->8

function _init()
	cartdata("oli414_micro8_0_11")
	rom.load(0x3100)
	rom.load(0x5e00)
end

function _update()
	focus.u()
	
	blinkc+=1
	if btn(0)or btn(1)or btn(2)or btn(3) then
		blinkc=0
	end
	if (blinkc>=16)blinkc=0
	blink=blinkc<8
end

function _draw()
	ram.d()
	rom.d()
	game.d()
	if focus==isel then
		isel.d()
	end
	if focus==bedit then
		bedit.d()
	end
	
	--infobar
	rectfill(0,112,128,128,1)
	print(infobar1,1,114,13)
	print(infobar2,1,121,13)
	
	if focus==error then
		error.d()
	end
end