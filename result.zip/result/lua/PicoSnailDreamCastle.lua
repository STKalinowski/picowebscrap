--pico snail : dream castle ★
--floofinator 🐱
function _init()
	ldata={
		{
			{
				button = {59,"garden"},
				spawn = {6,2},
				screen = {0,0,4},
				back = back_garden,
				book = 
				{"the grass is soft, the flowers are so colorful.",
					"isn't it a wonderful day outside?",	
					"oh look!	do you see that over there?",
					"there's a snail on path, let's help it across. ★"}
			},
			{new_guide,7,6,"⬅️ ➡️ to move"},
			{new_guide,19,14,"🅾️ to jump"},
			{new_guide,29,14,"hold for high places"},
			{new_guide,56,14,"jump to the pink balloon!"},
			{new_warp,59,5,2},
			{new_book,36,13}
		},
					
		{
			{
				button = {23,"courtyard"},
				spawn = {6,2},
				screen = {0,0,4},
				back = back_garden,
				book = 
				{"it's getting pretty dark out, maybe we should go inside.",
					"no? you want to stay out? you're right, we can look at the stars!",
					"i'll turn off the lights so we can see better.",
					"maybe if we wait long enough we might see a shooting star. ★"}
			},
			{new_thorn,12,13,4},
			{new_thorn,40,3,1},
			{new_thorn,31,7,4},
			{new_thorn,55,8,4},
			{new_guide,8,6,"❎ to use your wand!"},
			{new_guide,22,13,"collect lots of stars"},
			{new_guide,56,14,"stars let you jump twice!"},
			{new_guide,56,4,"shoot stars with your wand!"},
			{new_warp,24,3,3},
			{new_book,5,13}
		},
					
		{
			{
				button = {122,"entrance"},
				spawn = {70,3},
				screen = {4,0,4},
				back = back_town,
				book = 
				{"do you like going outside?",
					"it's a wonderful day out, we can go into town and see all the buildings.",
					"maybe we'll see a snail again! i know you love those.",
					"just make sure you keep your shoes on, you don't want to get pricked by those seeds again. ★"}
			},
			{new_guide,72,7,"⬇️ to drop down"},
			{new_guide,121,14,"gates have switches!"},
			{new_door,120,8,103,7},
			{new_tie,112,4},
			{new_warp,125,7,4},
			{new_portal,103,2,new_thorn,4},
			{new_book,81,4},
			{new_thorn,80,10,1},
			{new_thorn,84,11,2}
		},
		
		{
			{
				button = {121,"halls"},
				spawn = {2,22},
				screen = {0,1,4},
				ground = 90,
				back = back_castle,
				front = front_pillars,
				book = 
				{"the inside can be great too.",
				 "look at all the wonderful decorations on the walls.",
					"there's all sorts of machines and things to wonder about.",
					"it's amazing to think people made all of it, maybe they used some kind of magic? ★"}
			},
			{new_guide,6,26,"watch out for salt!"},
			{new_guide,57,22,"we lost the story books!"},
			{new_thorn,43,21,3},
			{new_warp,60,26,5},
			{new_door,53,29,39,21},
			{new_book,51,21},
			{new_tar,32,30},
			{new_tar,41,30}
		},
		
		{
			{
				button = {16,"rooftops"},
				spawn = {71,24},
				screen = {4,1,4},
				ground = -1,
				back = back_sky,
				book = 
				{
					"from up on the roof the stars are very clear.",
					"that's one of the benefits of staying here i guess.",
					"hopefully we will be able to leave soon and you can go home.",
					"this thing isn't going to fix itself though, we need them to take care of you.",
					"you have a soft bed here don't you?",
					"i'm sure you'll have the best dreams."
				}
			},
			{new_warp,121,18,6},
			{new_book,68,29},
			{new_thorn,94,17,3},
			{new_portal,106,20,new_tie},
			{new_door,66,29,125,28},
			{new_guide,105,26,"they've gone to the moon!"}
		},
		
		{
			{
				button = {235,"the moon"},
				spawn = {7,40},
				screen = {0,2,4},
				ground = 26,
				back = back_space,
				book = 
				{
					"from on the earth, the moon looks no bigger than the end of your thumb.",
					"some people say the moon is made of cheese.",
					"isn't that silly? it would probably be moldy by now.",
					"what if it got all fuzzy? that would be so gross! ★"
				},
				map_pal = moon_pal,
				grav = 0.1
			},
			{new_warp,58,40,7},
			{new_thorn,13,41,1},
			{new_thorn,25,41,2},
			{new_guide,17,39,"how did i get here"},
			{new_tar,41,45},
			{new_book,61,34}
		},
		
		{
			{
				button = {248,"nightmare"},
				spawn = {68,42},
				screen = {4,2,4},
				ground = 26,
				back = back_space,
				track = -1,
				book = 
				{
					"are you still up? it's very late.",
					"did you have a nightmare about the neighbor's cat again?",
					"you know, you can have a snail help out.",
					"in a dream who says a snail can't stop a big scary cat? ★"
				},
				map_pal = moon_pal,
				grav = 0.1
			},
			{new_cat,90,48},
			{new_book,102,44},
			{new_door,104,44,78,43},
			{new_tar,95,46},
			{new_tar,84,46},
			{new_warp,120,36,8}
		},
		
		{
			{
				button = {58,"the end"},
				spawn = {115,42},
				screen = {7,2,1},
				ground = 26,
				back = back_garden,
				book = 
				{
					"don't worry about yourself, i do that for you.",
					"wherever you go, know that someone is caring for you.",
					"remember to dream and hope, even though you might be lost.",
					"you may be leaving, but i hope you will still be with what you love.",
					"thank you for being here.",
					"even if it wasn't for long. ★"
				}
			},
			{new_warp,125,37,8},
			{new_book,120,36},
			{new_guide,117,41,"creator: floofinator"},
			{new_guide,121,41,"music/character: ujico"}
		}
	}
	--gravity
	grav = 0.125
	--places stars have been taken
	starplaces={}
	--places bricks have been broken
	brickplaces={}
	--setup save data
	cartdata("snail-chan")
	--disable repeat button press
	poke(0x5f5c, 255)
	--back start
	back = back_sky
	--start state
	state = state_start
	--camera
	cam_set()
	--load save data from cart data
	load_save()
	--play music
	play_track(0)
end
--unlock saved levels
function load_save()
	first = true
	for l=0,#ldata do
		if dget(l*4)!=0 then
			add_button(l)
			first = false
		end
	end
	--if no levels unlocked
	if first then
		unlock_level(1)
	end
	set_sel(1)
end
--delete all save data
function clear_save()
	if delete_test==0 then
		for l=0,#ldata do
			for d=0,3 do
				dset(l*4+d,0)
			end
		end
		run()
	else
		menuitem(1,"delete save ("..delete_test..")",clear_save)
	end
	delete_test-=1
	return true
end
--update
function _update60()
	back.up()
	state.up()
	table_up(backfxs)
	table_up(fxs)
	wipe_up()
end
--draw
function _draw()
	back:dr()
 camera(cam_x,cam_y)
	state:dr()
	camera()
	wipe_dr()
	if(run_start)print(timestr(time()-run_start),0,0,8)
	if(final_time)print(timestr(final_time),32,0,11)
end
--level update state
state_level={}
function state_level.up()
 snail_up()
	table_up(actors)
	cam_up()
end
--level draw state
function state_level.dr()
 pal_table(map_pal)
 map_dr()
 pal()
	table_dr(actors)
	snail_dr()
	table_dr(fxs)
	camera()
	--infront
	front()
end
--setup level
function start_level(l)
	level=l
	
 actors = {}
 
 fxs = {}
 backfxs = {}
 starttime = time()
 replace_tiles(starplaces,16)
	replace_tiles(brickplaces,7)
 for i,data in pairs(ldata[level]) do
 	if i!=1 then
	 	data[1](data[2],data[3],data[4],data[5],data[6])
		else
		 spawn = data.spawn
		 new_snail(spawn[1],spawn[2])
			cam_set(data.screen,snail)
			ground = data.ground or 26
			back = data.back or back_sky
			front = data.front or star_count
			play_track(data.track or -1)
			map_pal = data.map_pal or {}
			grav = data.grav or 0.15
		end
	end
	stars = 0
	collected = false
	state=state_level
	menuitem(1,"exit level",exit)
end
--end the level and set scores
function end_level(endtime)
	local timescore = endtime-starttime
	local extra = 0
	if (collected) extra = 1
	save_level(level,stars,timescore,extra)
	grav = 0.15
	to_menu()
end
--go to the level select menu
function to_menu()
	play_track(-1)
	menuy=0
	menux=0
	fxs = {}
 backfxs = {}
	cam_set()
	back=back_sky
	state=state_menu
	--delete save menu item
	delete_test=16
	menuitem(1,"delete save",clear_save)
end
--unlock level and add button
function unlock_level(l)
	dset(l*4,1)
	add_button(l)
	set_sel(l)
end
--add save data for level
function save_level(l,s,t,e)
 local index = l*4
	dset(index+1,max(s,dget(index+1)))
	local lt = dget(index+2)
	if (lt<=0) lt = 9999
	dset(index+2,min(t,lt))
	dset(index+3,max(e,dget(index+3)))
end
--menu function to exit and return to menu
function exit()
	wipe(to_menu,0,16)
end
--call the update function for table
function table_up(tab)
	for o in all(tab) do
		o:up()
	end
end
--call the draw function for table
function table_dr(tab)
	for o in all(tab) do
		o:dr()
	end
end
--play music track
function play_track(index)
		music(index,250,12)
end

-->8
--functions for snail @(o_o)
--
function new_snail(tx,ty)
 snail = {
 	b = {w=8,h=16},
		x = tx*8,
		y = ty*8,
		xv = 0,
		yv = 0
	}
	snail_dir = 0
	snail_jumped = false
	snail_frame = 1
	snail_flip = false
	snail_ground = 0
	snail_step = 0
	snail_wand = 0
	snail_owch = 0
	snail_dead = -1
	snail_play = true
	big_poof(snail.x,snail.y)
	balloon(snail.x,snail.y,0,10)

	//update
	function snail_up()
	 if snail_play then
	 	--shooting stars
		 if btnp(❎) then
		 snail_wand=16
			if snail_flip then
		 	forward = -2
		 else
		 	forward = 2
		 end
		 
		 local t = 128
		 if stars>0 then
		 	sfx(13)
		 	place_star(1)
		 else
		 sfx(18)
		 	t = 4
		 end
		 	new_star(snail.x+(forward*2),snail.y+4,forward,0,t)
			end
			
		 --control
			snail_dir=0
			if(btn(⬅️)) snail_dir-=1
			if(btn(➡️)) snail_dir+=1
			
			if snail_dir!=0 then
				snail_flip=snail_dir<0
				if (touch(snail,flr(3+(snail_dir+1)/2))) then
					snail_dir=0
				end
			end
			
			snail.xv+=snail_dir*0.0625
			
			snail.xv = mid(-1.5,snail.xv,1.5)
			
			if touch(snail,2) or touch(snail,2,1) then
				if snail_ground<256 then
					snail_ground+=1
				end
			else
				snail_ground=0
			end
			
		 //ground check
			if snail_ground>0 then
				//ground friction
				if snail_dir==0 or
					sgn(snail.xv)!=sgn(snail_dir) then
					snail.xv*=0.85
				end
				
				--jump
				snail_jumped=false
				if btnp(🅾️) then
				 snail.yv=-2 sfx(14)
				end
				
				--fall through
				if touch(snail,2,1) and not touch(snail,2) then
			 	if (btn(⬇️)) snail.y+=1
			 end
			 
		 else
		  //air friction
				if snail_dir==0 or
					sgn(snail.xv)!=sgn(snail_dir) then
					snail.xv*=0.95
				end
		 
		 	//air jump
			 if btnp(🅾️) and stars>0 and not snail_jumped then
			  sfx(15)
			  snail.yv=-2
			  snail_jumped=true
			  place_star(1)
			  big_poof(snail.x,snail.y+16)
			 end
			 
				//float
				if btn(🅾️) then
					snail.yv+=grav/2
				else
				 snail.yv+=grav
				end
			end
			
			--move snail position
			snail.x+=snail.xv
			axis_col(snail)
			
			thru=map_col(snail,1)
			snail.y+=snail.yv
			if axis_col(snail,true) or 
						(not thru and snail.yv>0 
							and axis_col(snail,true,1)) then
				sfx(19)
			end
			
			local hazard = map_col(snail,4)
			if hazard and snail.yv>0 then
				snail_hurt(hazard,4)
			end
			
			if (snail.y>(screen[2]+1)*128) snail_die()
			
			--collect stars
			local col = map_col(snail,2)
			if col then
				sfx(17)
				remove_tile(col.x,col.y,starplaces)
				stars+=1
				poof(col.x,col.y)
			end
				
			--actors interaction
			local enemy = tag_col(snail,"enemy")
			if enemy and snail_owch==0 then
			 snail_hurt(enemy)
			end
			
			--animation
		 if snail_ground>0 then
				if snail_dir!=0 then
					snail_ground=1
					if sgn(snail_dir)==sgn(snail.xv) then
						snail_step+=abs(snail.xv)
						if snail_step>=16 then
							snail_step = 0
							sfx(22)
						end
						snail_frame=33+flr(snail_step/4)*2
					else
						snail_frame = 5
					end
				else
					if abs(snail.xv)>0.25 then
						snail_frame = 3
					else
						snail_frame = 1
					end
					if snail_ground==256 then
						snail_frame = 3
					end
				end
				if (snail_wand>0) snail_ground=1
			else
			 if snail.yv<0 then
			 	if snail_jumped then
						snail_frame = 5
					else
				 	snail_frame = 39
				 end
				else
					snail_frame = 35
				end
			end
			if snail_owch>0 then
				snail_frame = 64
				snail_owch -= 1
			end
			if snail_wand>0 then
				if snail_wand<12 then
					snail_frame = 66
				else
				 snail_frame = 64
				end
				snail_wand -= 1
			end
		else
		
		 --respawn
			if snail_dead>0 then
				snail_dead -= 1
			elseif snail_dead==0 then
				snail_dead=-1
				wipe(start_level,level)
			end
		end
	end
	
	--when snail is hurt
	--by something
	function snail_hurt(o,f)
	 big_poof(snail.x,snail.y)
		snail_owch=64
		cam_shake=2
		
		snail_flip = push(snail,o.x,o.y,f or 2)>0
		if (o.xv!=nil) push(o,snail.x,snail.y,8)
		
		if stars<=0 then
			snail_die()
		else
			sfx(8)
			place_star(3)
		end
		
		snail_jumped=false
	end
	
	function snail_die()
		sfx(21)
		snail_ouch(snail.x,snail.y,snail.xv/4,-2)
	 snail_dead = 128
	 snail_play = false
	end
	
	//draw
	function snail_dr()
		local sit = 0
		if (snail_ground==256) sit = 2
	 if snail_play then
		 if collected then
		  local back = -4
		  if (snail_flip) back = 4
		 	spr(251,snail.x+back,snail.y+5+sit,1,1,snail_flip)
		 end
		 spr(snail_frame,snail.x-4,snail.y+sit,2,2,snail_flip)
		end
		pal()
	end
end

-->8
--visual functions *<*
//smooth step interpolation
function step(a,b,t)
	local t =	t * t * (3-2*t)
	return lerp(a,b,t)
end

//linear interpolation
function lerp(a,b,t)
	return (1-t)*a + t*b
end

function pal_table(t)
	for i=1,#t,2 do
		pal(t[i],t[i+1])
	end
end

function cam_set(s,target)
	screen = s or {0,0,0}
	cam_target = target
	cam_x = screen[1]*128
	cam_y = screen[2]*128
	cam_shake=0
end

//update camera position and keep in screen
function cam_up()
 local minx = screen[1]*128
	local maxx = minx+128*(screen[3]-1)
	local targetpos = cam_target.x+cam_target.xv*32-60
	
	local width = 32-abs(cam_target.xv)*8
	
	if(cam_x+width<targetpos) cam_x = targetpos-width
	if(cam_x-width>targetpos) cam_x = targetpos+width
	cam_x = mid(minx,cam_x,maxx)
	
	cam_shake*=0.95
	cam_y=screen[2]*128
	if (abs(cam_shake)>0.125) cam_y+=sin(cam_shake)*cam_shake*7.9
end

//display for number of stars
function star_count()
	if(stars<=0) return
 local y = 124
 local h = mid(0,stars,5)*8
	rectfill(3,y-h-1,12,y+1,10)
	rectfill(4,y-h,11,y,0)
	for i=8,stars*8,8 do
	 if i>h then
			print(stars-5,5,y-i,10)
	 	break
	 else
			spr(16,4,y-i)
		end
	end
end

function back_stars(s,v,g)
 local xside = sidedir[s].x
 local yside = sidedir[s].y
 local startx = 64+xside*72
 local starty = 64+yside*72
 local v = v or 0
 if(startx==64) startx=rnd(256)-128
 if(starty==64) starty=rnd(256)-128
	local xvel = -xside*(rnd(1)+0.5)*v
	local yvel = -yside*(rnd(1)+0.5)*v
	local chance = flr(rnd(8))
	if (chance==1) star(startx,starty,xvel,yvel,g,true,256)
	if (chance>6) spark(startx,starty,xvel/4,yvel/4,g/8,true,256)
end

function space_stars()
 cls()
	for i=0,64 do
		srand(i)
		circfill(rnd(128),rnd(128),sin(time()/8+rnd(1))*1.5,rnd({7,10,12}))
		srand(time())
	end
end

//palettes
moon_pal = {2,9,3,15,11,15,13,1,6,13,1,0}

back_sky={}
function back_sky.dr()
	space_stars()
	pal_table({11,15,12,15,6,9,1,4,13,9,7,15})
	spr(235,98,32)
	pal()
	paralax(0,52,4,4,10,32,nil,nil,nil,12)
	cloud_dr(46,256)
	pal()
	pal_table({10,9,7,6})
	table_dr(backfxs)
	pal()
end
function back_sky.up()
	back_stars(4,4,0.0625)
end

back_garden={}
function back_garden.dr()
	cls(12)
	cloud_dr(-8,16)
	pal_table({10,9,7,6})
	table_dr(backfxs)
	pal()
	paralax(68,51,4,1,8,8,nil,3)
	paralax(68,51,4,1,16,4,nil,3)
	paralax(68,51,4,1,32,2,nil,3)
end
function back_garden.up()
	back_stars(1,2,0.125)
end

back_town={}
function back_town.dr()
	cls(12)
	cloud_dr(-16,16)
	pal_table({10,9,7,6})
	table_dr(backfxs)
	pal_table({5,12,1,12})
 paralax(64,48,4,2,-8,8,nil,12)
 pal()
 pal(5,0)
 paralax(64,48,4,2,0 ,4,nil,1)
 pal()
end
back_town.up = back_garden.up

back_space={}
function back_space.dr()
	space_stars()
	spr(235,98,32)
	palt(0b1010000010100010)
	pal_table({3,4,11,9})
	paralax(68,51,4,1,8,8,nil,3)
	pal_table({3,9,11,15})
	paralax(68,51,4,1,16,4,nil,3)
	paralax(68,51,4,1,32,2,nil,3)
	pal()
	pal_table({10,9,7,6})
	table_dr(backfxs)
	pal()
end
back_space.up = back_garden.up


back_castle={}
function back_castle.dr()
 back_town.dr()
	palt(0b0100000000000000)
	pal_table({6,1,13,0})
	paralax(8,48,8,8,-48,3,nil,0,0)
	pal()
	pal_table({6,13,13,1})
	paralax(4,48,4,8,-48,2)
	paralax(4,48,4,8,16,2)
	pal()
end
back_castle.up = back_garden.up

function cloud_dr(y,m)
 pal_table({7,6,6,13})
 paralax(64,50,4,2,y-12,32,m,6)
 pal()
 paralax(64,50,4,2,y   ,16,m,6)
end

function front_pillars()
	pal_table({6,1,13,0})
	for i=80,-136,-32 do
		paralax(0,48,4,4,i,0.5,nil,nil,nil,32)
	end
	pal()
	star_count()
end

function paralax(mx,my,w,h,y,d,m,fb,ft,g)
	local g = g or 0
	local m = m or 0
	local tw = (w+g)*8
	local x = (cam_x-screen[1]*128+time()*m)/d%tw
	local y = 64+y-(cam_y-screen[2]*128)/d
	for i=0,ceil(128/tw) do
		map(mx,my,i*tw-x-(g*8)/2,y,w,h)
	end
	local fb = fb or -1
	local ft = ft or -1
	if (ft!=-1) rectfill(0,0,128,y,ft)
	if (fb!=-1) rectfill(0,y+h*8,128,128,fb)
end

function star_dr(x,y)
	local s = 16
	local t = flr(time()*8)
	if(t%2==0) s =32
	local h = false
	local v = false
	if t%4>2 then
		h = true
	elseif t%4>1 then
		v = true
	end
	spr(s,x,y,1,1,v,h)
end

function timestr(t)
	return flr(tostr(t/60))..":"..flr(tostr(t%60))
end

function spr_line(x1,y1,x2,y2)
	for i=0,1,1/32 do
	 if i!=0 and i!=1 then
			lx = lerp(x1,x2,i)
			ly = lerp(y1,y2,i)
			spr(0,lx-4,ly-4)
		end
	end
end

function squiggle(x,y,c,n)
 local c = c or 7
 local n = n or 16
	for i=0,n do
	 xp = sin((i+(time()*16))/16)*4*i/n
	 pset(x+xp,y+i,c)
	end
end

function banner(x,y,text,big,c)
	local b = 6
	local w = 4
	local c = c or 7
	local tag = ""
	if (big) b = 11 w = 7 tag = "\^t\^w"
 local textw = #text*w
	local ledge = x-textw/2
	local redge = x+textw/2
	rect(ledge-1,y-6,redge+1,y+b,10)
	rectfill(ledge,y-5,redge,y+b-1,0)
	line(ledge-1,y+b+1,redge+1,y+b+1,9)
	for i=0,#text do
	 local xp = ledge+(i*w)-3
	 if (big) xp-=3
	 local off = sin((i/16)+time())*1.95
	 print(tag..sub(text,i,i),xp,y+off-1,1)
		print(tag..sub(text,i,i),xp,y+off-2,c)
	end
end

function prompt(t,x,y)
 local pos = abs(sin(time()/2))*4
	print(t,x,y-pos+1,1)
	print(t,x,y-pos,10)
end

function map_dr()
	local sx = screen[1]
 local sy = screen[2]
 local sw = screen[3]
	map(sx*16,sy*16,sx*128,sy*128,sw*16,16)
	for x=sx*16,sx*16+sw*16 do
		for y=0,1 do
			spr(ground,x*8,(sy+1)*128+y*8)
		end
	end
	pal()
end

function draw_page(x,middle,y,h)
	for i=0,4 do
	 local newx = x+(middle-x)/2
		rectfill(x,y+i,newx,y+h+i,15)
		x = newx
	end
end

function draw_book(x,y,w,h)
	local half = x+w/2
	local bottom = y+h
	local right = x+w
	rectfill(x,y,right,bottom,2)
	rectfill(half-8,y,half+7,bottom+2)
	for i=0,1 do
		for j=0,1 do
			rectfill(x-2+i*(w-4),y-2+j*(h-4),x+6+i*(w-4),y+6+j*(h-4),10)
		end
	end
	rectfill(x+2,bottom-8,right-2,bottom-2,4)
	
	draw_page(x+2,half,y-8,h)
	draw_page(x+w-2,half,y-8,h)
	rectfill(half-1,y-2,half,bottom-4,4)
	
	print_lines(pages[page],x+4,y-4)
	
	print_lines(pages[page+1],half+4,y-4)
end

function print_lines(text,x,y)
	local index = 0
	local space = 0
	local cut = 0
	local chars = ""
	while index<=#text do
		index+=1
		if sub(text,index,index)==" " then
			chars = chars..sub(text,space+1,index)
			space = index
		end
		if index-cut>=12 then
			cut = space
			print(chars,x,y,1)
			chars = ""
			y += 6
		end
	end
	chars = chars..sub(text,space+1,-1)
	print(chars,x,y,1)
end
-->8
-- random junk (-v-)
-- creates a box table
function new_box(w,h)
	return {w=w,h=h}
end

-- hitbox collide with hitbox?
function box_col(o,o2)
	return not (o.x>o2.x+o2.b.w-1 or
													o.x+o.b.w-1<o2.x or
													o.y>o2.y+o2.b.h-1 or
													o.y+o.b.h-1<o2.y)
end

-- hitbox colliding with 
--something that should stop it?
function map_col(o,t)
	local t = t or 0
	local map_left = screen[1]*128
	local map_right = map_left+screen[3]*128
	local map_top = screen[2]*128
	local map_bottom = map_top+128
	for x=0,o.b.w,8 do
		sx = -1
		if(x==0) sx=0
	 for y=0,o.b.h,8 do
	  sy = -1
	  if(y==0) sy=0
	  px = o.x+x+sx
	  py = o.y+y+sy
			if (fget(mget(flr(px/8),flr(py/8)),t) or 
						(t==0 and (px<map_left or px>map_right))) and 
						not (py<map_top or py>map_bottom) then
				return {x=px,y=py}
			end
		end
	end
	if t==0 then
		local col = tag_col(o,"solid")
		if col then
			return {x=col.x,y=col.y}
		end
	end
	return nil
end

-- collide on axis with tile
function axis_col(o,vert,t)
	local t = t or 0
	col = map_col(o,t)
	if col then
		local shift = 8
		if vert then
			local side = col.y
			if (o.yv>0) side-=o.b.h shift=0
			o.y = flr(side/8)*8+shift
			o.yv=0
		else
		 local side = col.x
			if (o.xv>0) side-=o.b.w shift=0
			o.x = flr(side/8)*8+shift
			o.xv=0
		end
	end
	return col
end

--directions for sides
sidedir = {{x=0,y=-1},
											{x=0,y=1},
											{x=-1,y=0},
											{x=1,y=0}}
--touching side? (not already in)
function touch(o,s,t)
 local t = t or 0
 hit = map_col(o,t)
 if(hit) return false
 local dx = sidedir[s].x
 local dy = sidedir[s].y
 o.x+=dx
	o.y+=dy
	hit = map_col(o,t)
	o.x-=dx
	o.y-=dy
	if hit then
		return true
	else
		return false
	end
end

//hitbox colliding 
//with a object with tag
function tag_col(o,tag)
	for actor in all(actors) do
		if o!=actor and actor[tag]
		and box_col(o,actor) then
			return actor
		end
	end
	return false
end

--call an actors hit function if colliding
function actor_hit(o)
	for actor in all(actors) do
		if o!=actor and actor.hit
		and box_col(o,actor) then
			actor:hit(o)
			return actor
		end
	end
	return false
end

function replace_tiles(l,t)
	for tile in all(l) do
		mset(tile.x,tile.y,t)
		del(l,tile)
	end
end

function remove_tile(x,y,t)
	local tx = flr(x/8)
	local ty = flr(y/8)
	mset(tx,ty,0)
	add(t,{x=tx,y=ty})
end
--place a star back at random
function place_star()
	index = flr(rnd(#starplaces)+1)
 local tile = starplaces[index]
	mset(tile.x,tile.y,16)
	del(starplaces,tile)
	poof(tile.x*8,tile.y*8)
	stars-=1
end
--push object away from point
function push(o,x,y,f)
	local xoff = o.x-x
	o.xv=f*(xoff/abs(xoff))
	
	local yoff = o.y-y
	o.yv=f*(yoff/abs(yoff))
	
	--return direction
	return xoff
end

function brick_break(o)
	local brick = map_col(o,3)
	if brick then
		sfx(10)
		remove_tile(brick.x,brick.y,brickplaces)
		brick_debris(brick.x,brick.y)
		o:hit()
	end
end
-->8
--particle effectssss (*_*)

fxs = {}
backfxs = {}

--functions for fxs
function new_fx(s,x,y,xv,yv,g,life,back,w,f)
	local fx = {
		s = s,
		x = x,
		y = y,
		xv = xv or rnd(2)-1,
		yv = yv or rnd(2)-1,
		g = g or 0.25,
		life = life or 128,
		back = back or false,
		w = w or 1,
		f = f or false
	}
	--update
	function fx:up()
		self.life-=1
		self.yv+=self.g*grav
		self.x+=self.xv
		self.y+=self.yv
		if self.life==0 then
		 if self.back then
				del(backfxs,self)
			else
			 del(fxs,self)
			end
		end
	end
	
	--draw
	function fx:dr()
		spr(self.s,self.x,self.y,self.w,self.w,self.f)
	end	
	
	--which table layer?
	if(back) then
	 add(backfxs, fx)
	else
	 add(fxs, fx)
	end
	
	return fx
end

balloon_col={{14,2},{11,3},{12,1},{10,9},{9,4},{8,2}}
function balloon(x,y,c,sc)
	local balloon = new_fx(nil,x,y,nil,nil,-0.125,256)
	balloon.c = c
	balloon.sc = sc
	function balloon:dr()
	 squiggle(self.x+4,self.y+8,self.sc)
	 local col=balloon_col[self.c+1]
	 pal_table({14,col[1],2,col[2]})
		spr(8,self.x,self.y)
		pal()
	end
end

--single spark
function spark(x,y,xv,yv,g,b,l)
 local spark = new_fx(nil,x,y,xv,yv,g,l,b)
	function spark:dr()
		spr(0,self.x,self.y,1,1,time()*4%1>0.5)
	end
end

function star(x,y,xv,yv,g,b,l)
	local star = new_fx(nil,x,y,xv,yv,g,l,b)
	function star:dr()
		star_dr(self.x,self.y)
	end
end

--poof of 3 sparks
function poof(x,y)
 for i=1,3 do
		spark(x,y)
	end
end

--single dark spark
function dark_spark(x,y)
 local fx = new_fx(nil,x,y,nil,nil,0.5)
	function fx:dr()
		circfill(self.x+4,self.y+4,2,1)
		circfill(self.x+4,self.y+4,1,0)
	end
end

--poof of 3 dark sparks
function dark_poof(x,y)
 for i=1,3 do
		dark_spark(x,y)
	end
end

--poof of 3 sparks and 3 stars
function big_poof(x,y)
 for i=1,3 do
 	spark(x,y)
 	star(x,y)
 end
end

--thorn owchie face fx thing
function thorn_ouch(x,y,xv,yv)
	new_fx(24,x,y,xv+rnd(1)-0.5,yv+rnd(1)-0.5,0.5)
end

--thorn owchie face fx thing
function tie_ouch(x,y,xv,yv)
	thorn_ouch(x,y,xv,yv)
	local tie = new_fx(nil,x,y,xv+rnd(1)-0.5,yv+rnd(1)-0.5,0.5,nil,nil,nil,xv>0)
	function tie:dr()
		palt(1,13,7,8)
		palt(0b1100000110000100)
		spr(96,self.x-4,self.y,2,2,self.f)
		pal()
	end
end

--snail owchie fx thing
function snail_ouch(x,y,xv,yv)
	new_fx(64,x,y,xv+rnd(1)-0.5,yv+rnd(1)-0.5,0.5,512,nil,2,xv>0)
end

--broken brick pieces woahwoah
function brick_debris(x,y)
	local x = flr(x/8)*8
	local y = flr(y/8)*8
	for i=0,1 do
		for j=0,1 do
			new_fx(7,x+(i*4),y+(j*4),0.5*(i*2-1),0.5*(j*2-1),0.5,128,false,0.5)
		end
	end
end
-->8
--moving actors (>_<)

--function for star projectile
function new_star(x,y,dx,dy,t)
	local star={
		b=new_box(8,8),
		x=x,
		y=y,
		dx=dx or 0,
		dy=dy or 0,
		t = t or 128
	}
	--update
	function star:up()
		self.x+=self.dx
		self.y+=self.dy
		
		if (time()%0.125==0) spark(self.x,self.y)
		
		brick_break(self)
		
		if actor_hit(self) or 
		map_col(self,0) or 
		self.t<0 then
			self:hit()
		end
		
		self.t-=1
	end
	
	--draw
	function star:dr()
		star_dr(self.x,self.y)
	end
	
	--when hit
	function star:hit()
		poof(self.x,self.y)
		del(actors,self)
	end
	
	add(actors,star)
end

--function for bubble projectile
function new_bubble(x,y,dx,dy,t)
	local bubble={
		b=new_box(8,8),
		x=x,
		y=y,
		dx=dx or 0,
		dy=dy or 0,
		t = t or 256,
		enemy = true
	}
	--update
	function bubble:up()
		self.x+=self.dx
		self.y+=self.dy
		
		brick_break(self)
		
		if map_col(self,0) or
		self.t<0 then
			self:hit()
		end
		
		self.t-=1
	end
	
	--draw
	function bubble:dr()
		local wobble = abs(sin(self.t/32))*1.75
		circfill(self.x+4,self.y+4,3+wobble,1)
		circfill(self.x+4,self.y+4,2+wobble,0)
		circfill(self.x+5,self.y+3,wobble,13)
	end
	
	--when hit
	function bubble:hit()
		dark_poof(self.x,self.y)
		del(actors,self)
	end
	
	add(actors,bubble)
end

function check_sides(o)
	newsides = {}
	for i=1,4 do
		newsides[i]=touch(o,i) or (i==2 and touch(o,i,1))
	end
	return newsides
end
--function for thorn creature
function new_thorn(xt,yt,d)
	local thorn={
		b=new_box(8,8),
		x=xt*8,
		y=yt*8,
		dx=sidedir[d].x,
		dy=sidedir[d].y,
		enemy = true
	}
	--setup sides
	thorn.sides=check_sides(thorn)
	--update
	function thorn:up()
	 --move
	 self.x+=self.dx
	 self.y+=self.dy
	 --surounding tiles
		local newsides=check_sides(self)
		--what changed?
		for i=1,4 do
			if self.sides[i]!=newsides[i] then
				--obstructed
				local dir = 0
				if newsides[i] then
				--if infront
			 	if sidedir[i].x==self.dx
			 	or sidedir[i].y==self.dy then
			 		--check if open space on sides
			 		for j=1,4 do
			 			if not newsides[j] then
				 			if (self.dy==0 and sidedir[j].y!=0) or
					 					(self.dx==0 and sidedir[j].x!=0) then	
					 			dir = j
					 			break
				 			end
				 		end
			 		end
			 		--reverse
			 		if (not into) self.dx*=-1 self.dy*=-1
				 end
				 --opened
				else
				 --check if floating
				 dir = i
				 for j=1,4 do
				 	if newsides[j] then
				 		dir = 0
				 		break
				 	end
				 end
				end
				--move into opening
				if dir!=0 then
				 self.dx=sidedir[dir].x
					self.dy=sidedir[dir].y
				end
			end
		end
		--set old tiles to new
		for i=1,4 do
		 self.sides[i]=newsides[i]
		end
	end
	--draw
	function thorn:dr()
		spr(23,self.x,self.y,1,1,flr(time()*8)%2==0)
	end
	--when hit
	function thorn:hit(o)
	 sfx(9)
	 dark_poof(self.x,self.y)
		thorn_ouch(self.x,self.y,o.dx/2,o.dy/2)
		self.enemy = false
		del(actors,self)
	end
	--add actor
	add(actors,thorn)
	--return actor
	return thorn
end

//function for floaty bowtie
function new_tie(xt,yt)
	local tie={
		b=new_box(8,16),
		x=xt*8,
		y=yt*8,
		xv=0,
		yv=0,
		health=2,
		enemy=true
	}
	//update
	function tie:up()
	 local xd = snail.x-self.x
		local yd = snail.y-self.y
		local accel = 1/(self.health*16)
		local xaccel = mid(-accel,xd,accel)
		local yaccel = mid(-accel,yd,accel)
		self.xv+=xaccel
		self.yv+=yaccel
		
		self.xv = mid(-1,self.xv,1)
		self.yv = mid(-1,self.yv,1)
		
		self.x+=self.xv
		axis_col(self)
		
		self.y+=self.yv
		axis_col(self,true)
		
		if (time()%(1/128)==0 and self.health<2) dark_spark(self.x,self.y+8)
	end
	
	//draw
	function tie:dr()
		if(self.health<2) pal(7,8)
		
		local index = {98,100,98,96}
		spr(index[flr(time()%1*4)+1],self.x-4,self.y,2,2,self.x-snail.x>0)
		pal()
	end
	
	//when hit
	function tie:hit(o)
	 self.health-=1
	 dark_poof(self.x,self.y)
		push(self,o.x,o.y,16)
		if self.health<=0 then
		 sfx(9)
			dark_poof(self.x,self.y)
			tie_ouch(self.x,self.y,o.dx/2,o.dy/2)
			self["enemy"] = false
			del(actors,self)
		else
			sfx(27)
		end
	end
	
	add(actors,tie)
	
	return tie
end

-->8
--level actors
function new_door(xt,yt,sxt,syt)
	local door = {
		b = new_box(8,16),
		x=xt*8,
		y=yt*8,
		solid=true
	}
	
	function door:up()
		
	end
	
	function door:dr()
	 local s = 120
		if (self.solid) s = 104
		spr(s,self.x,self.y)
		spr(s,self.x,self.y+8,1,1,false,true)
	end
	
	function door:trigger()
		self.solid = not self.solid
		poof(self.x,self.y)
		if self.solid then
			sfx(28)
		else
			sfx(26)
		end
	end
	
	add(actors,door)
	
	new_switch(sxt,syt,door)
	
	return door
end

function new_switch(xt,yt,door)
	local switch = {
		b = new_box(8,8),
		x=xt*8,
		y=yt*8,
		hold = false,
		door = door
	}
	
	function switch:up()
		
	end
	
	function switch:dr()
		spr_line(self.x+4,self.y+8,self.door.x+4,self.door.y+8)
		local closed = self.door.solid
		if(closed) pal(10,14)
		spr(121,self.x,self.y,1,1,closed)
		pal()
	end
	
	function switch:hit(o)
		self.door:trigger()
	end
	
	add(actors,switch)
end

function new_guide(xt,yt,text)
	local guide = {
	 b = new_box(24,24),
	 x=(xt-1)*8,
	 y=(yt-1)*8,
	 text = text,
	 show = false
	}
	
	function guide:up()
		self.show = box_col(self,snail)
	end
	
	function guide:dr()
		local s=0
		if self.show then
			banner(self.x+12,self.y-12,self.text)
			s = flr((time()*4)%2)
	 end
	 spr(122+s,self.x+8,self.y+8,1,1)
	end
	
	add(actors,guide)
end

function new_warp(xt,yt,l)
 local warp = {
	 b = new_box(16,16),
	 x=xt*8,
	 y=yt*8,
	 xv=0,
	 yv=0,
	 endtime=0,
	 l = l or 0
	}
	
	function warp:up()
	 self.x+=self.xv
	 self.y+=self.yv
		if not fly and box_col(snail,self) then
			big_poof(snail.x,snail.y)
			for i=1,4 do
				balloon(self.x+4,self.y+4,flr(rnd(5)+1),7)
			end
			self.xv=snail.xv
			self.yv=snail.yv
			fly=true
			snail_play = false
			endtime = time()
			if (run_start) final_time = time()-run_start
			sfx(20,0)
		elseif not fly then
		 self.y+=cos(time()/4)/16
		elseif fly then
		 local t = time()-endtime
			self.yv+=cos(t/4-0.125)*t/16
			self.xv-=(self.x-cam_x-64)/2048
		 self.xv+=cos(t)/8
		 self.yv*=0.95
		 self.xv*=0.95
		 if self.y<cam_y-32 then
		 	fly = false
			 unlock_level(l)
			 set_sel(l)
			 wipe(end_level,endtime,16)
			 sfx(-1,0)
			end
		end
		if(time()%0.125==0) spark(self.x+4,self.y+4)
	end
	
	function warp:dr()
		if fly then
			if (collected) spr(251,self.x,self.y+4)
			balloon_snail(self.x,self.y)
		else
		 spr(8,self.x+4,self.y-8)
		 squiggle(self.x+8,self.y,10,16)
		end
	end
	
	add(actors,warp)
	
	return warp
end

function new_portal(xt,yt,func,d)
	local portal = {
		b = new_box(8,8),
		x=xt*8,
		y=yt*8,
		func=func,
		wait = 0,
		d=d,
		spawn = nil
	}
	function portal:up()
		if self.wait==512 then
			self.wait=0
			self.spawn = func(self.x/8,self.y/8,self.d)
			dark_poof(self.x,self.y)
			sfx(12)
		end
		if self.spawn==nil or not self.spawn["enemy"] then
			self.wait+=1
		end
		if self.wait==448 then
			dark_poof(self.x,self.y)
		end
	end
	
	function portal:dr()
		local s = 102
		local f = false
		if(flr(time()*4)%2==0) s = 118 f = true
		pal(5,0)
		spr(s,self.x-4,self.y-4,2,1,f,f)
		spr(s,self.x-4,self.y+4,2,1,not f,not f)
		pal()
	end
	
	add(actors,portal)
	
	return portal
end

function new_book(xt,yt)
 local book = {
	 b = new_box(8,8),
	 x=xt*8,
	 y=yt*8
	}
	
	function book:up()
	 if (time()%0.125==0) spark(self.x,self.y)
		self.y+=cos(time()/2)*0.125
		self.x+=cos(time()/4)*0.125
		if box_col(self,snail) then
			collected=true
			big_poof(self.x,self.y)
			sfx(16)
			del(actors,self)
		end
	end
	
	function book:dr()
		spr(251,self.x,self.y)
	end
	
	add(actors,book)
	
	return book
end

function new_tar(xt,yt)
	local tar = {
	 b = new_box(8,8),
	 x=xt*8,
	 y=yt*8,
	 enemy = true
	}
	
	function tar:up()
	 if (time()%2.5==0) then
	  dark_poof(self.x,self.y)
			new_bubble(self.x,self.y,0,-0.5)
			sfx(24)
		end
	end
	
	function tar:dr()
		pal(5,0)
		spr(234.75-time()%2.5,self.x,self.y)
		pal()
	end
	
	add(actors,tar)
	
	return tar
end

-->8
--menu and transitions

buttons={}
sel=1

state_menu={}
function state_menu.up()
	if(btnp(🅾️)) buttons[sel]:play()
	if(btnp(❎)) buttons[sel]:read()
	if(btnp(⬇️)) move_sel(1)
	if(btnp(⬆️)) move_sel(-1)
	menux = 92+cos(time()/8)*7.9
	menuy = 92+sin(time()/4)*15.9
	if(time()%0.125==0) spark(menux+4,menuy+4,-rnd(1)-2)
	cam_y = buttons[sel].l*4
end

function state_menu.dr()
	table_dr(fxs)
	balloon_snail(menux,menuy)
	table_dr(buttons)
end

function move_sel(d)
	local newsel = sel
	repeat
	 newsel+=d
		newbutton = buttons[newsel]
	until(newbutton!=nil or newsel>#buttons or newsel<1)
	if(newbutton!=nil) then
		set_sel(newsel)
		sfx(11)
	end
end

function set_sel(new)
	if(#buttons<=0) return
	buttons[sel].on = false
	sel = new
	buttons[sel].on = true
end

function add_button(l)
	local button = {
	 l=l,
	 s = ldata[l][1].button[1],
	 on=false
	 }

	function button:dr()
		local l = self.l
	 local x = 24-8*(l%2)
	 local y = l*16
	 local s = self.s
		local w = 7
		local edgex = x+w*8
		local edgey = y+10
		local book = dget(l*4+3)!=0
		
		if self.on then
			prompt("🅾️play",edgex+2,y-2)
			if book then
			 prompt("❎read",edgex+9,edgey-4)
			end
		else
		 pal(6,13)
			pal(13,1)
		end
		spr(75,edgex,edgey-6)
		spr(73,x-7,edgey-6,1,1)
		rectfill(x,y,edgex,edgey+1,13)
		rectfill(x+12,y+1,edgex-1,edgey,6)
		rectfill(x+1,y+1,x+10,y+10,0)
		pal()
		
		spr(s,x+2,y+2)
		local ltime = dget(l*4+2)
		if ltime!=0 then
			spr(16,x+21,y+2)
			print(dget(l*4+1),x+14,y+4,10)
			
			print(timestr(ltime),x+31,y+4,7)
			
			if book then
				spr(251,edgex-9,y+2)
			end
		else
		 print("new!",x+14,y+4,10)
		end
	end
	
	function button:play()
		wipe(start_level,self.l,self.s,ldata[self.l][1].button[2])
	end
	
	function button:read()
		if dget(self.l*4+3)!=0 then
			wipe(open_book,ldata[self.l][1].book,251)
		end
	end
	
	buttons[l] = button
end

function balloon_snail(x,y)
	local bx = x+16
	local by = y-4
	local t = flr((time()*2)%2)*2
	squiggle(x+10,y+12,10,8)
	spr(70,bx-7,by-16,2,2)
	spr(66+t,x,y,2,2)
	line(x+13,y+6,bx,by)
	line(x+12,y+8,x+11,y+10)
end

wipet=-1
function wipe(func,parm,sprite,text)
 if wipet<=-1 then
		wipet=1
		wipefunc=func
		wipeparm=parm
		wipespr=sprite or 16
		wipetext=text or ""
		sfx(23)
 end
end

function wipe_up()
	if(wipet>=-1)then
		wipet-=1/64
	end
	if(wipet==0) wipefunc(wipeparm)
end

function wipe_dr()
	if wipet>0 then
		x = step(0,128,wipet)
	else
		x = step(-128,0,(wipet+1))
	end
	if wipet>=-1 then
		rectfill(x,0,x+127,128,10)
		rectfill(x+x/4,0,x+127+x/4,128,7)
		rectfill(x+x/2,0,x+127+x/2,128,0)
		clip(x+x/2,0,128,128)
		for xo=0,7 do
			for yo=0,7 do
				local py = yo*16+4
				local px = x+xo*16+4
				spr(wipespr,px,py)
			end
		end
		local spos = x-x/2+64
		circfill(spos,64,32,10)
		circfill(spos,64,24,7)
		spr(12,spos-16,48,4,8)
		if wipetext!="" then
			banner(spos,16,wipetext,true)
		end
		clip()
	end
end
-->8
--cat boss >:3 🐱
//function for cat boss
function new_cat(xt,yt)
	paw1=new_paw()
	cat={
		b=new_box(24,128),
		x=xt*8,
		y=yt*8+128,
		xv=0,
		yv=0,
		attacking=false,
		owch=0,
		enemy=true,
		solid=true
	}
	add(actors,cat)
	paw2=new_paw()
	//update
	function cat:up()
	 --tracking
	 if self.attacking then
		 self.y += self.yv
		 self.x += self.xv
		 local dif = self.y+16-snail.y
			self.yv -= dif*0.005
			self.yv *= 0.9
			self.xv *=0.8
			--paw movement
			local spincos = cos(time()/4)*8
			local spinsin = sin(time()/4)*8
			local centerx = self.x-16
			local centery = self.y+24+spincos
			paw1.x = centerx-spincos
			paw1.y = centery-spinsin*2.5
			paw2.x = centerx+spincos
			paw2.y = centery+spinsin*2.5
		else
			if cam_x>self.x-128 then
				self.attacking=true
				play_track(0)
			end
		end
		if(self.owch>0) self.owch-=1
	end
	
	//draw
	function cat:dr()
		local rot = sin(time()/2)*1.9
		--paw1
		rectfill(self.x+16,paw1.y,paw1.x+16,paw1.y+11,1)
		--left ear
		pal(5,1)
		spr(250,self.x+2,self.y-4-rot)
		rectfill(self.x+1,self.y+4-rot,self.x+10,self.y+10,1)
		--head
		circfill(self.x+12,self.y+13-rot/2,12,1)
		--body
		rectfill(self.x+4,self.y+13,self.x+24,cam_y+128,1)
		--tie
		spr(200,self.x,self.y+22-rot/2,2,2)
		--right ear
		pal(5,13)
		spr(250,self.x+16,self.y-4+rot,1,1,true)
		rectfill(self.x+16,self.y+4+rot,self.x+24,self.y+32,1)
		--eyes
		if(self.owch>0) pal(7,8)
		spr(248,self.x+8,self.y+8+rot/2,1,1,true)
		spr(248,self.x+2,self.y+8-rot/2,0.5,1,true)
		--mouth
		if self.owch>0 then
		 pal(5,13)
		else
			pal(5,1)
		end
		circfill(self.x+4,self.y+18,3,1)
		spr(249,self.x+1,self.y+14)
		--paw2
		rectfill(self.x+16,paw2.y,paw2.x+16,paw2.y+11,1)
		--end
		pal()
	end
	
	//when hit
	function cat:hit(o)
		if(self.owch>0) return
	 dark_poof(self.x+24,self.y+24)
	 self.owch = 192
	 push(self,o.x,o.y,8)
	 sfx(9)
	end
end

function new_paw()
	local paw={
		b=new_box(16,16),
		x=0,
		y=0,
		enemy=true
	}
	//update
	function paw:up()
		
	end
	
	//draw
	function paw:dr()
		spr(202,self.x,self.y,2,2)
	end
	
	//when hit
	function paw:hit(o)
	 
	end
	
	add(actors,paw)
	
	return paw
end
-->8
--random states 
state_start = {}
start_y = -128
function state_start:up()
	if(btn(❎)) run_start = time() wipe(to_menu)
	if(btn(🅾️)) wipe(to_menu)
	cam_x = sin(time()/8)*7.9+8
	start_y = lerp(start_y,0,0.0625)
	cam_y = start_y
end
--intro update
function state_start:dr()
	spr(12,32,58,4,8)
	prompt("press 🅾️ to start",39,50)
	banner(72,34,"dream castle",false,14)
	banner(72,16,"pico snail!",true,7)
	camera()
	paralax(68,51,4,1,52,0.5,nil,3)
end

--open book with text
function open_book(book)
	cam_set()
	back=back_castle
	state=state_book
	pages=book
	page=1
end
--book state
state_book = {}
--book update
function state_book.up()
	if (btnp(❎)) exit()
	local old = page
	if (btnp(⬅️)) page-=2
	if (btnp(➡️)) page+=2
	page = mid(1,page,#pages-1)
	if(old!=page) sfx(25)
	cam_x+=0.5
end
--book draw
function state_book:dr()
	camera()
	draw_book(12,32,104,72)
	prompt("❎exit",8,120)
	prompt("⬅️➡️turn",90,120)
end