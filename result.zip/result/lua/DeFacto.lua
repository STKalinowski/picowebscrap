--defacto
--by nusan
levelsx,levelsy,inventx,inventy,recipeindex=128,64,1,2,1
cheat,wantcheat,usemusic=false,false,true

function bignum(v1,v2)
	return shr(v1,16)+(v2 and v2 or 0)
end

stars,rando,tconv,tinser,tbridge,tminer,tmcopper,tmiron,tmoil,tfurn,tfact,tlauncher,tfield,tspace,tdel,tlargedel,textradel,tground,tselling={},{},{t=6,s="conveyor",desc="transport products",cost=bignum(5),form=true,rebuild=true},{t=10,s="inserter",desc="pick/drop products",cost=bignum(10),form=true,rebuild=true},{t=26,s="bridge",desc="go over conveyors",cost=bignum(40),form=true,rebuild=true},{t=15,s="miner",desc="exploit raw fields",cost=bignum(60),size=2},{t=50,s="miner",cost=bignum(60),size=2},{t=52,s="miner",cost=bignum(60),size=2},{t=54,s="miner",cost=bignum(60),size=2},{t=55,s="furnace",desc="transform raw products",cost=bignum(200),size=2},{t=56,s="factory",desc="combine products using recipes",cost=bignum(500),size=2},{t=84,s="launcher",desc="send rockets into space",cost=bignum(30784,381),size=4},{t=79,s="field",cost=bignum(60),size=2},{t=0,s="space"},{t=32,s="delete"},{t=32,s="delete",size=2},{t=32,s="delete",size=4},{t=32,s="ground",cost=0},{t=80,s="seller",desc="trade products against money",cost=bignum(300),size=4}
tools={{tconv,tinser,tbridge,tdel,tground},{tminer,tfurn,tfact,tselling,tlauncher}}
curtool=tools[inventy][inventx]

products={{s="oil",f=14,p=bignum(1)},{s="darkblue",p=bignum(1)},{s="articial brains",p=bignum(11160,2.5)},{s="chemical",p=bignum(100)},
					{s="raw copper",f=9,p=bignum(1)},{s="grey",p=bignum(10)},{s="raw iron",f=7,p=bignum(1)},{s="iron plates",p=bignum(5)},
					{s="advanced circuits",p=bignum(1250)},{s="copper plates",p=bignum(5)},{s="robots",p=bignum(16960,15)},{s="basic circuits",p=bignum(100)},
				  {s="processing units",p=bignum(15000)},{s="dirt",p=bignum(10)},{s="refined oil",p=bignum(5)},{s="synthetic skin",p=bignum(10000)},{s="rockets",p=bignum(30784,381)}}

recgreen,recred,recchemical,recblue,recskin,recbrain,recrobot,recrocket={output=11, spr=57, dur=1, p=bignum(1000), input={{9,2},{7,2}}},{output=8, spr=58, dur=4, p=bignum(20000), input={{11,2},{9,4},{14,4}}},{output=3, spr=60, dur=2, p=bignum(17232,0.5), input={{6,3},{14,3}}},{output=12, spr=59, dur=6, p=bignum(27232,0.5), input={{8,2},{7,6},{14,6},{3,4}}},{output=15, spr=61, dur=5, p=bignum(17232,0.5), input={{11,4},{8,1},{3,4}}},{output=2, spr=62, dur=4, p=bignum(13568,12), input={{8,4},{12,2}}},{output=10, spr=63, dur=10, p=bignum(19264,76), input={{15,3},{2,1},{11,4}}},{output=16, spr=100, dur=60, p=0, input={{10,5},{0,9},{9,6},{7,6}}}
recipes,parts={recgreen,recred,recblue,recchemical,recskin,recbrain,recrobot},{}

function addpart(txt,xx,yy,cc,dd)
	local vvx,vvy=rnd()-.5,rnd()-.5
	local sv=1/sqrt(vvx*vvx+vvy*vvy)
	add(parts, {t=txt,x=xx*4,y=yy*4,vx=vvx*sv,vy=vvy*sv,c=cc and cc or 8,d=dd and dd or 10})
end

function getdata(i,j)
	if i<0 or j<0 or i>levelsx-1 or j>levelsy-1 then
		return nil
	end
	return data[i+j*levelsx]
end

function setdata(i,j,v)
	if i<0 or j<0 or i>levelsx-1 or j>levelsy-1 then
		return
	end
	data[i+j*levelsx] = v
end

function getcoord(x,y)
	return flr(x/4),flr(y/4)
end

function island(i,j)
	return fget(mget(i,j),0)
end

function badd(b)
	return b and 1 or 0
end

function basicdraw(s,d,x,y)
 	local size = fget(s,1) and badd(fget(s,5))+1 or 0.5
	spr(s,x,y,size,size)
end

function conveypal(d)
	local c,co,cpal = d.item,d.count,d.act and pali or palo
	palt(13,true)
	pal(2,5)
	pal(cpal[1], co>0 and c or 1)
	for p=2,8 do
		pal(cpal[p], co>=p and c or 1)
	end
end

function conveydraw(s,d,x,y)
	conveypal(d)
	if(d.t==tbridge) y-=1
	if d.corner!=nil and d.corner then
		s+=16
	end
	spr(s,x-1,y-1,0.75,0.875)
	if convedit then -- and not (d.item>=0 or d.count>0) then
		--if abs(px-x-2)+abs(py-y-2)<12 or d.corner then
		if d.corner then --and d.corner then
			spr(s%16+32,x,y,0.625,0.625)
		end
		--end
	end
	pal()
end

function inserdraw(s,d,x,y)
	local c,co,cpal = d.item,d.count,d.act and pali or palo
	local notempty = c>=0 or co>0
	palt(13,true)
	pal(2,5)
	pal(cpal[1], notempty and c or 1)
	pal(cpal[2], (co>=2 or notempty) and c or 1)
	for p=3,8 do
		pal(cpal[p], co>=p and c or 1)
	end
	spr(s,x-1,y-1,0.75,0.875)
	pal()
end

function furnacedraw(s,d,x,y)
	local a,b=3,4
	if(d.act and slowflip) a,b=4,3
	if d.item>=0 and products[d.item+1].f then
		pal(a,d.item)
		pal(b,products[d.item+1].f)
	else
		pal(a,0)
		pal(b,0)
	end
	spr(s,x,y)
	pal()
	--pal(3,3)
	--pal(4,4)
end

function factorydraw(s,d,x,y)
	local a,b=9,4
	if(d.act and slowflip) a,b=4,9
	pal(a,d.counts[1]>0 and d.recipe.input[1][1] or 0)
	pal(b,d.counts[2]>0 and d.recipe.input[2][1] or 0)
	local rc=d.recipe and #d.recipe.input or 0
	if(rc>2) pal(6,d.counts[3]>0 and d.recipe.input[3][1] or 0)
	if(rc>3) pal(7,d.counts[4]>0 and d.recipe.input[4][1] or 0)
	spr(s,x,y)
	--[[pal(9,9)
	pal(4,4)
	pal(6,6)
	pal(7,7)
	]]--
	pal()
end

function minerdraw(s,d,x,y)
	spr(s,x,y)
	local h = d.act and y+1+abs(2.5-(upframe/8)%5) or y+2
	rect(x,h,x+7,h+3,1)
end

function basicget(e,i,vmax)
	if i<0 or e.item==i then
		local q=min(vmax,flr(e.count/2+0.5))
		if e.wait!=nil then
			if q>0 then
				q,e.wait=0,nil
			end
		else
			if e.count==1 then
				e.wait=true
			end
		end
		e.count-=q
		e.act=true
		return q,e.item
	end
	return 0,0
end

function basicadd(e,i,value,b)
	if e.t==tfurn and (b.t==tconv or i<0 or not products[i+1].f) then
		return 0,0
	end
	local q = 0
	if i==e.item or e.item<0 then
		q=min(e.cmax,e.count+value)-e.count
		if q>0 then
			e.count+=q
			e.item,e.act=i,true
		end
	end
	return q
end

function sellingadd(e,i,value,b)
	if b.t!=tconv then
		local v=products[i+1].p*value
		addmoney(v)
		--sfx(flr(rnd(3))+7,3)
		addpart("+"..getscoretext(v),e.x,e.y,11,10)
		return value
	end
	return 0
end

function furnaceget(e,i,vmax)
	if e.item>=0 then
		local ot=products[e.item+1].f
		if ot!=nil and i<0 or ot==i then
			local q=min(vmax,e.count)
			e.count-=q
			return q,ot
		end
	end
	return 0,0
end

function factoryadd(e,i,value,b)
	local q = 0
	if b.t!=tconv and e.recipe!=nil then
		for r=1,#e.recipe.input do
			if e.recipe.input[r][1]==i then
				q=min(e.cmax,e.counts[r]+value)-e.counts[r]
				if q>0 then
					e.counts[r]+=q
				end
				break
			end
		end
	end
	return q
end

function factoryget(e,i,vmax)
	if e.recipe!=nil then
		local ot=e.recipe.output
		if i<0 or ot==i then
			local q=min(vmax,e.count)
			e.count-=q
			return q,ot
		end
	end
	return 0,0
end

function nodrop() return 0 end
function noget() return 0,0 end

function initent(i,j)
	local nent=nil
	local s = mget(i,j)
	if fget(s,3) then
		nent,needprod={x=i,y=j,size=1,spr=s,item=-1,draw=basicdraw,canadd=nodrop,count=0},false
		if s==50 or s==52 or s==54 then
			needprod,nent.prod,nent.item,nent.cmax,nent.t,nent.draw,nent.d,nent.canget=true,12,s==50 and 4 or badd(s==52)*6,24,s==50 and tmcopper or (s==52 and tmiron or tmoil),minerdraw,nodrop,basicget
		elseif s==49 or s==51 or s==53 then
			nent.count,nent.t,nent.mine=nil,tfield,s==49 and tmcopper or (s==51 and tmiron or tmoil)
		elseif s==84 then
			needprod,nent.cmax,nent.t,nent.draw,nent.canadd,nent.canget,nent.recipe,nent.counts,nent.timer,nent.prod,nent.tick=true,9,tlauncher,basicdraw,factoryadd,noget,recrocket,{0,0,0,0},0,0,0
			add(uplaunch,nent)
		elseif s==55 then
			needprod,nent.cmax,nent.t,nent.draw,nent.canadd,nent.canget,nent.prod=true,16,tfurn,furnacedraw,basicadd,furnaceget,0
		elseif s>55 and s<64 then
			needprod,nent.cmax,nent.t,nent.draw,nent.canadd,nent.canget,nent.recipe,nent.counts,nent.prod,nent.tick=true,6,tfact,factorydraw,factoryadd,factoryget,s>56 and recipes[s-56] or nil,{0,0,0,0},0,0
		elseif s==80 then
			needprod,nent.cmax,nent.t,nent.draw,nent.canadd,nent.canget,nent.prod=true,20,tselling,basicdraw,sellingadd,noget,0
		elseif s>5 and s<14 then
			nent.cmax,nent.canget=8,basicget
			if s<10 then
				nent.t,nent.corner,nent.draw,nent.canadd=tconv,true,conveydraw,basicadd
			else
 				nent.t,nent.draw=tinser,inserdraw
			end
			add(s%2==1 and upreg or upinv, nent)
		elseif s>25 and s<30 then
			nent.cmax,nent.t,nent.draw,nent.canget=8,tbridge,conveydraw,basicget
			add(s%2==1 and upreg or upinv, nent)
			add(upbridge,nent)
		else
			nent.count=nil
		end
		if(nent.t and nent.t.size) nent.size=nent.t.size
		if(needprod) add(upprod,nent)
		add(grent,nent)
		if nent.size then
			for ui=0,nent.size-1 do
				for uj=0,nent.size-1 do
					if ui+uj>0 then
						mset(i+ui,j+uj,16)
					end
					setdata(i+ui,j+uj,nent)
				end
			end
		else
			setdata(i,j,nent)
		end
	end
	return nent
end

function initpickdrop(e)
	if e==nil then
		return
	end

	local picker,s,i,j={{s=10,x=-1,y=0},{s=11,x=1,y=0},{s=12,x=0,y=-1},{s=13,x=0,y=1}},e.spr,e.x,e.y
	for p in all(picker) do --conveyor
		local isbridge=((s-16)==p.s)
		local dist=isbridge and 2 or 1
		if s==p.s or isbridge then
			local pickloc = getdata(i+p.x*dist,j+p.y*dist)
			if pickloc and pickloc.count then
				e.pick = pickloc
			end
		end
		if s==p.s or (s+4)==p.s or isbridge then --conveyor, inserter, bridge
			local droploc = getdata(i-p.x*dist,j-p.y*dist)
			if droploc and droploc.count then
				e.drop = droploc
				if e.spr == droploc.spr then
					if droploc.corner then
						droploc.corner=false
					end
				end
			end
		end
	end
end

function sort(t,fromend,side)
	local loop,st,en,step = true,1,#t-1,1
	if(fromend) st,en,step=#t-1,1,-1
	while loop do
		loop = false
		for i=st,en,step do
			local t1,t2 = t[i],t[i+1]
			local c1=t1.x-t2.x
			if c1*side>0 then
				t[i],t[i+1],loop = t2,t1,true
			elseif c1==0 and (t1.y-t2.y)*side>0 then
				t[i],t[i+1],loop = t2,t1,true
			end
		end
	end
end

function screenup(i,j)
	local s = mget(i,j)
	if not island(i,j) then
		local up,down,left,right = island(i,j-1),island(i,j+1),island(i-1,j),island(i+1,j)
		local count = badd(up) + badd(down) + badd(left) + badd(right)
		if count < 3 then
			if up then
				s = down and 36 or (left and 1 or (right and 3 or 2))
			elseif down then
				s = left and 33 or (right and 35 or 34)
			else
				s = left and (right and 37 or 17) or badd(right)*19
			end
		elseif count ==3 then
			s = down and (up and (left and 20 or 5) or 21) or 4
		else
			s = 32
		end
	end
	mset(i,j,s)
end

function uppickdrop(b)
	for e in all(b) do
		e.act=false
	end
	for e in all(b) do
		if e.drop!=nil then
			if e.count!=nil and e.count==0 then
				e.item=-1
			end
			if e.count>0 then
				local q=e.drop.canadd(e.drop,e.item,e.count,e)
				if q>0 then
					e.count-=q
					e.act=true
				end
			end
		end

		if e.pick!=nil then
			local mq=min(e.cmax,e.count+(e.t==tbridge and 4 or 1))-e.count
			if mq>0 then
				local q,it=e.pick.canget(e.pick,e.item,mq)
				if q>0 then
					e.count+=q
					e.item,e.act=it,true
				end
			end
		end
	end
end

-- noise

function noise(sx,sy,startscale,scalemod,featstep)

	local n = {}
	for i=0,sx do
		n[i] = {}
		for j=0,sy do
			n[i][j] = 0.5
		end
	end

	local step,scale = sx,startscale
	while step>1 do
		local cscal = scale
		if(step == featstep) cscal = 1
		for i=0,sx-1,step do
			for j=0,sy-1,step do
				local c1 = n[i][j]
				n[i+step/2][j],n[i][j+step/2] = (c1+n[i+step][j])*0.5 + (rnd()-0.5)*cscal,(c1+n[i][j+step])*0.5 + (rnd()-0.5)*cscal
			end
		end
		for i=0,sx-1,step do
			for j=0,sy-1,step do
				n[i+step/2][j+step/2] = (n[i][j]+n[i+step][j]+n[i][j+step]+n[i+step][j+step])*0.25 + (rnd()-0.5)*cscal
			end
		end
		step /= 2
		scale *= scalemod
	end
	return n
end

function findplace(id,count)
	local maxcount=5000
	while count>0 and maxcount>0 do
		local ra,d=rnd(),rnd()*10
		local ca,sa=cos(ra),sin(ra)
		local x,y=levelsx/2+ca*(16+d),levelsy/2+sa*(16+d)
		if mget(x,y)==32 and mget(x+1,y)==32 and mget(x,y+1)==32 and mget(x+1,y+1)==32 then
			mset(x,y,id)
			mset(x+1,y,16)
			mset(x,y+1,16)
			mset(x+1,y+1,16)
			count-=1
		end
		maxcount-=1
	end

end

function createemptylevel()

	cleandata()

	memset(0x1000,0,0x2000)

	local cur,cur2 = noise(levelsy,levelsy,0.9,0.7,levelsy),noise(levelsy,levelsy,0.9,0.4,16)
	for i=0,levelsy-1 do
		for j=0,levelsy-1 do
			local dist = max((abs(i/levelsy - 0.5) * 2), (abs(j/levelsy - 0.5) * 2))
			mset(i+32,j,(abs(cur[i][j] - cur2[i][j])*4 - dist*dist*dist*4)>0 and 32 or 0) -- ground
		end
	end

	findplace(49,10)
	findplace(51,10)
	findplace(53,10)

	startmap(true,false)
end

onemillion=bignum(16960,15)
function addmoney(m)
	statmoney+=m
	if(cheat) return
	local neg=m<0 and -1 or 1
	money1+=neg*(abs(m)%onemillion)
	money2+=neg*((abs(m)/1000)/1000)
	if money1>=onemillion then
		money1-=onemillion
		money2+=shr(1,16)
	end
	if money1<0 and money2>0 then
		money1+=onemillion
		money2-=shr(1,16)
	end
end

function hasmoney(m)
	if(cheat) return true
	local mil=(m/1000)/1000
	return money2>mil or (money2>=mil and money1>=m%onemillion)
end

function getscoretext(val)
    local s,v = "",abs(val)
    repeat
      s = shl(v % 0x0.000a, 16)..s
      v /= 10
    until (v==0)
    if (val<0)  s = "-"..s
    return s
 end

function cleandata()
	data,grent,upprod,upreg,upinv,upbridge,uplaunch,curpal,frame,upframe,backpaste,recipeelement,laststatmoney,stats={},{},{},{},{},{},{},0,0,0,false,nil,0,{}
end

function startmap(clean,load)

	cleandata()

	if clean then
		if load then
			money1,money2,statmoney,cheat=dget(1),dget(2),0,dget(3)==1
		else
			money1,money2,statmoney,cheat=0,0,0,wantcheat
			addmoney(bignum(500))
		end
	end

	-- create entities
	for i=0,levelsx-1 do
		for j=0,levelsy-1 do
			initent(i,j)
		end
	end
	for e in all(grent) do
		initpickdrop(e)
	end

	-- invert array that need to be traversed backward
	local tmpinv={}
	for e=#upinv,1,-1 do
		add(tmpinv,upinv[e])
	end
	upinv=tmpinv

	sort(upbridge,false,1)

	-- call screen up on everything
	for i=0,levelsx-1 do
		for j=0,levelsy-1 do
			screenup(i,j)
		end
	end

	if clean then
		px,py=levelsx*2-22,levelsy*2-2
		cx,cy,lastmx,lastmy=px-64,py-64,stat(32),stat(33)
	end
end

function _init()

	cartdata("nusan_defacto")
	menuelem=dget(0)*2
	if(usemusic) music(0,500)

	poke(0x5f2d, 1)

	menuitem(1, "help", function() openhelp,helpy=true,0 end)
	--menuitem(1, "restart sim", function() startmap(false,false) end)
	menuitem(2, "new map", createemptylevel)
	menuitem(3, "load", function() if dget(0)==1 then reload() startmap(true,true) end end)
	menuitem(4, "save", function() dset(0,1) dset(1,money1) dset(2,money2) dset(3,badd(cheat)) cstore() end)
	menuitem(5, "toggle music", function() usemusic = not usemusic music(usemusic and 0 or -1,500) end)

	for i=1,300 do
		add(stars,{x=rnd(128),y=rnd(128),c=rnd(100)>96 and 7 or rnd(2)+5})
	end

	for i=0,1023 do
		rando[i]=rnd(100)>60 and rnd(16) or 0
	end
	cx,cy,px,py=0,0,0,0
	cleandata()
end

function build(enttype,ni,nj,show,sprite)
	if enttype.cost then
		addmoney(-enttype.cost)
		if show and enttype.t!=32 then addpart("-"..getscoretext(enttype.cost),ni,nj) sfx(flr(rnd(3)+1),2) end
	end
	if enttype==tconv or enttype==tinser or enttype==tbridge then
		sprite+=lastdir
	end

	if enttype.size then
		for ui=0,enttype.size-1 do
			for uj=0,enttype.size-1 do
				mset(ni+ui,nj+uj,enttype.t==32 and 32 or 16)
			end
		end
	end
	mset(ni,nj,sprite)

	local size,nent=enttype.size and enttype.size or 1,initent(ni,nj)
	if nent!=nil then
		initpickdrop(nent)
	end
	for ui=-2,size+1 do
		for uj=-2,size+1 do
			screenup(ni+ui,nj+uj)
			initpickdrop(getdata(ni+ui,nj+uj))
		end
	end

	sort(upreg,true,1)
	sort(upbridge,false,1)
	sort(uplaunch,false,1)
	sort(upinv,true,-1)
	backpaste=false
end

function destroy(previous,enttype,ni,nj,show)
	addmoney(previous.t.cost)
	if(previous.recipe) addmoney(previous.recipe.p)
	if show then addpart("+"..getscoretext(previous.t.cost),ni,nj,11) sfx(4) end

	setdata(ni,nj,nil)
	if enttype.size!=nil then
		for ui=0,enttype.size-1 do
			for uj=0,enttype.size-1 do
				setdata(ni+ui,nj+uj,nil)
			end
		end
	end

	for dd=1,6 do
		del(({grent,upprod,upreg,upinv,upbridge,uplaunch})[dd],previous)
	end
	--[[
	del(grent,previous)
	del(upprod,previous)
	del(upreg,previous)
	del(upinv,previous)
	del(upbridge,previous)
	del(uplaunch,previous)
	]]
	if previous.corner!=nil then
		if previous.drop!=nil and previous.drop.corner!=nil then
			if previous.drop.spr==previous.spr then
				previous.drop.corner=true
			end
		end
	end

	local size=enttype.size and enttype.size or 1
	for ui=-2,size+1 do
		for uj=-2,size+1 do
			local e=getdata(ni+ui,nj+uj)
			if e!=nil and previous!=nil then
				if(e.drop==previous) e.drop=nil
				if(e.pick==previous) e.pick=nil
			end
		end
	end

	local btype=enttype.t
	if previous.draw==minerdraw then
		enttype,btype=tfield,previous.spr-1
		addmoney(tfield.cost)
	end
	build(enttype,ni,nj,false,btype)
	backpaste=false
end

lasti,lastj,lastmx,lastmy,lastmb1,lastmb2,last4,last5,press,openmenu,openinvent,showinventcursor,openrecipe,recipeelement,lastdir,openhelp,helpy=-100,-100,-100,-100,false,false,false,false,false,true,false,false,false,nil,0,false,0

function trybuild(enttype,i,j,canreb)
	if stat(0)>2020 then
		return
	end
	local marge = enttype.size==nil and 1 or enttype.size
	if i>0 and j>0 and i<levelsx-marge and j<levelsy-marge then
		local previous=getdata(i,j)
		if enttype.t==15 then
			if previous!=nil and previous.mine then
				if hasmoney(enttype.cost) then
					destroy(previous,enttype,previous.x,previous.y,false)
					build(previous.mine,previous.x,previous.y,true,previous.mine.t)
				else
					sfx(6)
				end
			end
		else
			if enttype.size!=nil then
				for ui=0,enttype.size-1 do
					for uj=0,enttype.size-1 do
						if(previous==nil) previous=getdata(i+ui,j+uj)
					end
				end
			end
			if previous!=nil then
				if canreb and previous.t.rebuild!=nil and previous.t==enttype then
					destroy(previous,enttype,i,j,false)
				else
					sfx(6)
				end
			else
				if hasmoney(enttype.cost) then
					build(enttype,i,j,true,enttype.t)
				else
					sfx(6)
				end
			end
		end
	end
end

function _update()

	mx,my=stat(32),stat(33)

	local mb1,mb2,b4,b5=band(stat(34),1)>0,band(stat(34),2)>0,btn(4),btn(5)
	press=mb1 or b4
	local press2,waspress,waspress2 = mb2 or b5,lastmb1 or last4,lastmb2 or last5
	local pressframe=press and not waspress

	if openmenu then
		local mcount,prevelem=2+dget(0),menuelem
		if(btnp(2)) menuelem = (menuelem+(mcount-1))%mcount
		if(btnp(3)) menuelem = (menuelem+1)%mcount

		local mouseclic=false
		if mx>37 and mx<96 then
			for i=1,mcount do
				local h=80+i*13
				if my>h-10 and my<h+2 then
					if lastmx!=mx or lastmy!=my then
						menuelem=i-1
					end
					mouseclic=lastmb1 and not mb1
				end
			end
		end

		if last4 and not b4 or mouseclic then
			sfx(11)
			if menuelem<2 then
				wantcheat,openhelp,helpy=menuelem==1,true,0
				createemptylevel()
			else
				--reload()
				startmap(true,true)
			end
			menuitems,openmenu=nil,false
		end
		if(menuelem!=prevelem) sfx(12)
		lastmb1,lastmb2,last4,last5,lastmx,lastmy = mb1,mb2,b4,b5,mx,my
		return
	elseif openhelp then
		openhelp=press or not waspress
		local movedmouse=lastmx!=mx or lastmy!=my
		if(btn(2) or (movedmouse and my<28)) helpy-=2
		if(btn(3) or (movedmouse and my>100)) helpy+=2
		helpy=min(max(0,helpy),108)
		lastmb1,last4,lastmx,lastmy = mb1,b4,mx,my
		return
	end

	if upframe%30==0 then
		stats[flr(upframe/30)%16+1]=statmoney*0.0625
		laststatmoney,statmoney=0,0
		for i=1,#stats do
			laststatmoney+=stats[i]
		end
	end

	upframe+=1
	if upframe%2==0 then
		curpal=(curpal+1)%8
	end

	slowflip=flr(upframe/12)%2==0

	pressinsert = press and (curtool==tinser or curtool==tbridge)

	local s,isc,previnvx,previnvy,prevrec,lasttool,forcemoved = 4,false,inventx,inventy,recipeindex,curtool,false
	if openinvent then
		if(btnp(0)) inventx-=1
		if(btnp(1)) inventx+=1
		if(btnp(2)) inventy-=1
		if(btnp(3)) inventy+=1
		--inventy=(inventy-1)%#tools+1
		--inventx=(inventx-1)%#tools[inventy]+1
		inventx,inventy=(inventx-1)%5+1,(inventy-1)%2+1
		curtool=tools[inventy][inventx]
		if(lasttool!=curtool) inventmoved=true
	elseif openrecipe then
		if(btnp(2)) recipeindex-=1
		if(btnp(3)) recipeindex+=1
		recipeindex=(recipeindex-1)%7+1--#recipes
	else
		local newdir,npx,npy=lastdir,px,py
		if btnp(0) then npx-=s isc=true newdir=1 end
		if btnp(1) then npx+=s isc=true newdir=0 end
		if btnp(2) then npy-=s isc=true newdir=3 end
		if btnp(3) then npy+=s isc=true newdir=2 end
		if isc then
			if pressinsert then
				forcemoved,lastdir=true,newdir
			else
				px,py=flr(npx/4)*4+2,flr(npy/4)*4+2
			end
		end
		showinventcursor,inventmoved=false,false
	end

	if mx!=lastmx or my!=lastmy or lastmb1 and not mb1 then -- also active when releasing mouse button 1, to fix when moving inserters
		if openinvent then
			local nty,ntx = flr((my-40)/12)+1,flr((mx-37)/11)+1
			if nty>0 and nty<=2 then --#tools
				if ntx>0 and ntx<=5 then --#tools[nty]
					inventy,inventx=nty,ntx
				end
			end
			showinventcursor=true
		elseif openrecipe then
			local nty=flr((my-32)/10)+1
			if abs(14-mx+3)<6 then
				if nty>0 and nty<=7 then --#recipes
					recipeindex=nty
				end
			end
			showinventcursor=true
		end
		if pressinsert then
			local diffx,diffy=mx+cx-px,my+cy-py
			if diffx!=0 or diffy!=0 then
				newdir = abs(diffx)>abs(diffy) and badd(diffx<0) or badd(diffy<0)+2
				if newdir!=lastdir then
					forcemoved,lastdir=true,newdir
				end
			end
			lastmx,lastmy=mx,my
		else
			px,py,lastmx,lastmy=mx+cx,my+cy,mx,my
		end
	end

	if previnvx!=inventx or previnvy!=inventy or prevrec!=recipeindex then
		sfx(flr(rnd(3))+7)
	end

	local ni,nj=getcoord(px,py)
	local hasmoved = lasti!=ni or lastj!=nj

	if openinvent then
		if pressframe or waspress2 and not press2 and inventmoved then
			openinvent = false
			sfx(10)
		end
	elseif openrecipe then
		if pressframe then
			openrecipe=false
			if recipeelement then
				local nrec=recipes[recipeindex]
				if nrec!=recipeelement.recipe then
					local moneyreq = nrec.p - (recipeelement.recipe and recipeelement.recipe.p or 0)
					if hasmoney(moneyreq) then
						addmoney(-moneyreq)
						recipeelement.count,recipeelement.tick=0,0
						for i=1,#recipeelement.counts do
							recipeelement.counts[i] = 0
						end
						recipeelement.recipe=nrec
						mset(recipeelement.x,recipeelement.y,nrec.spr)
						sfx(5)
					else
						openrecipe=true
						sfx(6)
					end
				end
			end
		end
	else
		local curd,badtool=getdata(ni,nj),curtool==tdel or curtool==tground
		if not badtool and curd!=nil and curd.t==tfact and not waspress then
			if press then
				openrecipe,recipeelement=true,curd
				for i=1,7 do --#recipes
					if recipes[i]==curd.recipe then
						recipeindex=i
					end
				end
				sfx(10)
			end
		else
			if press then
				--if curtool.form!=nil then
				if curtool==tconv or curtool==tdel then
					local bx,by=lasti,lastj
					repeat
						local prevx,prevy=bx,by
						if abs(bx-ni)>abs(by-nj) then
							if bx>ni then bx-=1 end
							if bx<ni then bx+=1 end
						else
							if by>nj then by-=1 end
							if by<nj then by+=1 end
						end
						if curtool==tconv then
							if not waspress then
								trybuild(curtool,bx,by,true)
							end
							if hasmoved then

								if(bx-prevx>0) lastdir=0
								if(bx-prevx<0) lastdir=1
								if(by-prevy>0) lastdir=2
								if(by-prevy<0) lastdir=3

								trybuild(curtool,prevx,prevy,true)
								if curtool==tconv then trybuild(curtool,bx,by,false) end
							end
						elseif not waspress or hasmoved then
							local previous=getdata(prevx,prevy)
							if previous!=nil and previous.t!=tfield then
								destroy(previous,({tdel,tlargedel,nil,textradel})[previous.size and previous.size or 1],previous.x,previous.y,true)
							end
						end
					until bx==ni and by==nj

				elseif not waspress or hasmoved or forcemoved then
					trybuild(curtool,lasti,lastj,true)
				end
			end
		end
	end
	if press2 and not waspress2 then
		if openrecipe then
			openrecipe=false
		else
			openinvent=not openinvent
		end
		sfx(10)
	end
	--openinvent=b5

	lastmb1,lastmb2,last4,last5,lasti,lastj = mb1,mb2,b4,b5,ni,nj

	if not openrecipe then
		if cx>px-20 then cx-=2 backpaste=false end
		if cx<px-108 then cx+=2 backpaste=false end
		if cy>py-20 then cy-=2 backpaste=false end
		if cy<py-108 then cy+=2 backpaste=false end
	end

	local step = upframe%8
	if step==0 then

		-- production
		for e in all(upprod) do
			if e.prod!=nil then
				if e.recipe!=nil then
					local isok=true
					for r=1,#e.recipe.input do
						if e.recipe.input[r][2]>e.counts[r] then
							isok=false
							break
						end
					end
					e.act=false
					if isok then
						if e.count<e.cmax then
							e.tick+=1
							e.act=true
							if e.tick>=e.recipe.dur then
								e.tick=0
								for r=1,#e.recipe.input do
									local input=e.recipe.input[r]
									e.counts[r]-=input[2]
								end
								e.count+=1
								--e.recipe.stat+=1
							end
						end
					end
				else
					local q = min(e.cmax,e.count+e.prod)-e.count
					if q>0 then
						e.count+=q
						e.act=true
					else
						e.act=false
					end
					if e.count==0 then
						e.item=-1
					end
				end
			end
		end

	--elseif step==8 then
		uppickdrop(upreg)
	elseif step==4 then
		uppickdrop(upinv)
	end

	for e in all(uplaunch) do
		if e.timer<=0 then
			if e.count>0 then
				e.count-=1
				e.timer=140
			end
		else
			e.timer-=1
			if e.timer==1 then
				sellingadd(e,16,1,e)
			end
		end
	end

end

function dtex(s,x,y,c,f)
	f=f and f or 0
	print(s,x-1,y,f)
	print(s,x+1,y,f)
	print(s,x,y-1,f)
	print(s,x,y+1,f)
	print(s,x,y,c)
end

function drawtool(tool, x,y,dir)

	local cstr,offx,offy=tool.t,0,0
	if fget(cstr,2) then
		if(tool==tground) cstr=18
		if(tool==tdel) cstr=47
		cstr+=dir
		offx,offy=-1,-1
		if(tool==tbridge) offy=-2
		if tool.form then
			pal(2,5)
			for p=1,8 do
				pal(palo[p],1)
			end
		end
	else
		pal(3,0)
		pal(4,0)
	end
	local size=tool.size==4 and 2 or 1
	spr(cstr,x+offx,y+offy,size,size)
	pal()
end

menuitems={}

function drawcross(x,y)
	line(x-2,y,x+2,y,7)
	line(x,y-2,x,y+2,7)
end

function _draw()

	pal()
	cls()
	if openmenu then

		if frame%8==0 and rnd()>0.25 then
			add(menuitems,{x=-8,y=16,vy=0,t=64+({0,2,3,4,6,7,8,9,10,11,12,14,15})[flr(rnd(13))+1]})
		end

		for i=1,#stars do
			local s=stars[i]
			local d=((s.y+frame)%128)/128
			pset(s.x,130-d*d*130,s.c)
		end

		for i=8,11 do
			pal(i,(i%4+4-flr(frame))%4<3 and 13 or 5)
		end

		for i=0,16 do
			spr(120+i%3,i*8,24)
			spr(123+i%3,i*8-4,70)
		end

		pal()
		palt(0,false)
		palt(13,true)
		for i=#menuitems,1,-1 do
			local m=menuitems[i]
			spr(m.t,m.x-4,m.y+2)
			m.x+=(m.y<20 and 1 or -1)
			if m.y<20 then
				if m.x>132 then
					m.y=62
				end
			else
				if m.x<-4 then
					del(menuitems,m)
				end
			end
		end

		pal()
		spr(88,44,40+sin(frame/100)*5-0.01,6,2)

		rectfill(40,4,90,12,1)
		dtex("nusan - 2018",42,6,6)

		local str={"new map","new sandbox"}
		if dget(0)==1 then add(str,"load game") end
		for i=1,#str do
			local h=80+i*13
			rect(37,h-9,96,h+1,1)
			dtex(str[i],46,h-6,menuelem+1==i and 6+flr(frame/10)%2 or 13,1)
		end
		frame+=1
	elseif openhelp then
		----[[ -- helping
		palt(13,true)
		local helplines,y={94,"you are cr_xu39d","a commander robot newly arrived","on asteroid as_f53bz."
		,82,"your goal is to exploit and","transform raw resources to","construct rockets full of robots","and continue to conquer","the galaxy"
		,84,"to build new equipment, you will","need money. you can gain money","by inserting your products into","a trading station."
		,80,"put miners on raw fields, use","inserters and bridges to put","products on conveyor belts.","cook raw resources in furnaces","and combine products in","factories by setting a recipe."
		,102},-helpy
	  for i=1,#helplines do
			local line=helplines[i]
			if type(line)=="number" then
				spr(line,56,y+4,2,2)
				y+=24
			else
		    print(line,64-#line*2,y,6)
				y+=6
			end
	  end
		--]]
	end

	if openmenu or openhelp then
		drawcross(mx,my)
		return
	end

	local scrx,scry=getcoord(cx,cy)
	scrx-=3
	scry-=3
	local scrxmax,scrymax=scrx+35,scry+35

	if backpaste then
		memcpy(0x6000,0x3e00,0x2000)
		camera(cx,cy)
	else

		for st in all(stars) do
			pset(st.x,st.y,st.c)
		end

		camera(cx,cy)

		rect(0,0,levelsx*4,levelsy*4,1)

		-- draw backgrounds
		for j=scry,scrymax do
			for i=scrx,scrxmax do
				local i4,j4=i*4,j*4
				local s = mget(i,j)
				if s!= 0 then
					if fget(s,2) then
						rectfill(i4,j4,i4+3,j4+3,13)
						local tr=rando[i%32+(j%32)*32]
						if tr>0 then
							pset(i4+tr%4,j4+flr(tr/4),2)
						end
					else
						if not fget(s,4) then
							local size = fget(s,1) and badd(fget(s,5))+1 or 0.5
							spr(s,i4,j4,size,size)
						end
					end
				end
			end
		end
		memcpy(0x3e00,0x6000,0x2000)
		backpaste = true
	end

	local cursorx,cursory=px,py
	if lastmb1 and pressinsert then
		cursorx,cursory=mx+cx,my+cy
	end
	circ(cursorx,cursory,5,7)

	palo,pali={1,5,2,6,4,8,3,7},{}
	for p=1,8 do
		pali[p],palo[p]=(curpal+palo[p]+3)%4+3+(p%2)*4,(palo[p]+3)%4+3+(p%2)*4
	end
	convedit=curtool==tconv
	for j=scry,scrymax do
		for i=scrx,scrxmax do
			local s = mget(i,j)
			if s!=0 and s!=32 then
				if fget(s,4) then
					local d=getdata(i,j)
					d.draw(s,d,i*4,j*4)
				end
			end
		end
	end
	pal()
	for i=3,8 do pal(i,1) end
	for b in all(upbridge) do
		if b.x>=scrx and b.x<=scrxmax and b.y>=scry and b.y<=scrymax then
			conveypal(b)
			local bx1,by1,bx2,by2,s,m=-7,0,3,0,42,false
			if b.spr>27 then
				bx1,by1,bx2,by2,s=-2,-7,-2,2,44
			end
			if b.spr%2==1 then
				bx1,bx2,by1,by2,m=bx2,bx1,by2,by1,true
			end
			spr(s,b.x*4+bx2,b.y*4+by2,1,1,m,b.spr==29)
			spr(s+1,b.x*4+bx1,b.y*4+by1,1,1,m,b.spr==29)
		end
	end
	pal()
	for b in all(uplaunch) do
		if b.timer>0 then
			local lval = (140-b.timer)*0.1+0.2
			local bx,by=b.x*4,b.y*4+12-lval*lval
			for p=1,10 do
				circfill(bx+6+rnd(4),by+rnd(4),badd(p<=5)*2+rnd(7),p>5 and 10 or 9)
			end
			spr(82,bx,by-19,2,2)
		end
	end

	local curd,us=getdata(getcoord(px,py)),mget(lasti,lastj)
	local showtool=us==32 or curtool==tground

	local showrotation = curtool.form and (not curd or curd.t==curtool)
	if showrotation then
		local df=abs(flr(upframe/4)%8-4)
		local tmpa={5+df,-8-df,-2,-2}
		for b=1,4 do
			local iscurdir=b-1==lastdir
			if iscurdir or press then
				pal(6,iscurdir and 7 or 12)
				spr(111+b,tmpa[b]+lasti*4,tmpa[(b+1)%4+1]+lastj*4)
			end
		end
		pal()
	end

	if curd!=nil then
		if(not showrotation or not press) rect(curd.x*4-1,curd.y*4-1,curd.x*4+curd.size*4,curd.y*4+curd.size*4,12)
		if(curtool.t==15 and curd.mine) showtool=true
		--if(curd.t==curtool) showtool=true
		--showtool=true
	elseif press then
		local cts=(curtool and curtool.size) and curtool.size or 1
		rect(lasti*4-1,lastj*4-1,lasti*4+cts*4,lastj*4+cts*4,8)
	end
	if showtool then
		palt(13,true)
		drawtool(curtool,lasti*4,lastj*4, curtool.form and lastdir or 0)
	end

	--line(px-2,py,px+2,py,7)
	--line(px,py-2,px,py+2,7)
	--[[
	local cursorx,cursory=px,py
	if lastmb1 and pressinsert then
		cursorx,cursory=mx+cx,my+cy
	end
	circ(cursorx,cursory,5,7)
	--spr(116,cursorx,cursory)
	]]

	for p in all(parts) do
		dtex(p.t,p.x,p.y,p.c)
		p.d-=1
		p.x+=p.vx
		p.y+=p.vy
		if p.d<=0 then
			del(parts,p)
		end
	end

	camera()

	if openinvent then
		rectfill(35,37,93,72,0)
		for j=1,2 do -- #tools
			for i=1,5 do --#tools[j]
				local ct=tools[j][i]
				local tx,ty=27+i*11,28+j*12
				rectfill(tx-1,ty-1,tx+8,ty+9,13)
				if not ct.size then tx+=2 ty+=2 end
				if ct==tlauncher then
					spr(86,tx,ty)
				elseif ct==tselling then
					spr(14,tx,ty)
				else
					drawtool(ct,tx,ty,0)
				end
			end
		end
		local tx,ty=27+inventx*11,28+inventy*12
		rect(tx-1,ty-1,tx+8,ty+9,7)
		dtex(curtool.s,37,65,7)
		if curtool.cost!=nil then
			local pctool=getscoretext(curtool.cost)
			if(curtool.cost>30) pctool=sub(pctool,0,#pctool-6).."m"
			dtex("◆"..pctool,84-#pctool*4,65,7)
		end
		if curtool.desc then
			rectfill(1,120,#curtool.desc*4,128,0)
			dtex(curtool.desc,0,122,7)
		end
	elseif openrecipe then
		rectfill(12,30,114,101,0)
		rectfill(24,31,115,100,1)
		palt(13,true)
		for i=1,7 do --#recipes
			local ct=recipes[i]
			local tx,ty,proditem=14,i*10+22,ct.output
			if i==recipeindex then
				palt(13,false)
				rectfill(tx-1,ty-1,tx+9,ty+8,13)
				spr(46,tx+10,ty)
				palt(13,true)
				print(products[proditem+1].s,30,33,proditem)
				local cc=hasmoney(ct.p) and 13 or 8
				rect(29,42,66,50,cc)
				print("◆"..getscoretext(ct.p),30,44,cc)
				print("duration:"..ct.dur,70,44,13)
				print("ingredients:",29,54,13)
				for r=1,#ct.input do
					local input=ct.input[r]
					local spx,spy=29,52+r*10
					spr(input[1]+64,spx,spy-1)
					print(products[input[1]+1].s.." "..input[2],spx+9,spy,input[1])
				end
			end
			spr(proditem+64,tx,ty)
			--print(products[ct.output+1].s,tx,ty,i==recipeindex and 13 or 7)
		end
		pal()
	else
		if curd!=nil then
			local py,ps=curd.recipe and 110 or 118,curd.t.s
			rectfill(0,py,128,128,1)
			rectfill(0,py,128,py,0)
			if(curd.mine) ps=ps.." of "..products[curd.spr==49 and 5 or (curd.spr==51 and 7 or 1)].s
			dtex(ps,2,py+3,13)
			local proditem=curd.recipe and curd.recipe.output or curd.item
			local pro=products[proditem+1]
			if pro then
				if(proditem==16) proditem=23
				print(pro.s..":"..curd.count.."/"..curd.cmax,44,py+3,proditem)
				palt(0,false)
				palt(13,true)
				spr(proditem+64,34,py+2)
				if curd.recipe then
					local percent,ri=(curd.tick + badd(curd.act)*(upframe%8)/8)/curd.recipe.dur,curd.recipe.input
					rectfill(1,py+13,percent*30+1,py+13,proditem)
					rect(1,py+12,31,py+14,0)
					for r=1,#ri do
						local input,spx=ri[r],34+(r-1)*(#ri>3 and 24 or 32)
						spr(input[1]+64,spx,py+10)
						print(""..curd.counts[r].."/"..input[2],spx+9,py+11,input[1])
					end
				end
				pal()
			elseif curd.t==tfact then
				dtex("- no recipe selected",33,py+3,13)
			end
		end
	end

	if showinventcursor then
		drawcross(lastmx,lastmy)
	end

	if not cheat then
		local score=getscoretext(money1)
		if money2!=0 then
			for i=1,6-#score do
				score="0"..score
			end
			score=getscoretext(money2)..score
		end
		dtex("◆"..score,119-#score*4,1,8)
	end
	dtex("◆"..getscoretext(laststatmoney).."/s",0,1,8)
	--[[for i=1,#stats do
		dtex(getscoretext(stats[i]),32,i*8-8,12)
	end]]

	local ram=stat(0)
	if ram>1900 then
		rectfill(0,0,63,5,0)
		print("ram warning:"..flr(ram),0,0,ram>2020 and frame%2+8 or 7)
	end
	-- tmp
	--[[if false then
		--dtex(curtool.s,80,0,8)
		print("cpu "..stat(1),0,8,8)
		print("ram "..stat(0),0,14,8)
	end]]

	--previzmap()

	frame+=1
end