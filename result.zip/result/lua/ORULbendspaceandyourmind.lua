-- ourl
-- by @egordorichev

local osfx=sfx
c1=0
c2=5
c3=6
plt=1
plts={
{0,5,6},
{1,13,12},
{9,10,7},
{0,1,13},
{0,3,11},
{0,1,3},
{0,1,2},
{2,4,9},
{2,8,15}
}

function sfx(id)
 if (not g_mute_sfx) osfx(id)
end

function play_music(id)
 if (not g_mute_music) music(id)
end

function _init()
 cls()
 --[[spr(68,48,48,4,4)
 coprint("^rexcellent ^games",84,6)
 for i=0,90 do
  flip()
 end]]

 g_time,state,g_index=
 0,ingame,
 0
 
 music(0)

 shk=0
 restart_level()
 g_deaths=0
 g_sec=0
 -- ∧⌂웃⬇️♥★█⬅️⬇️♥⌂★█⬅️
 --m()
end

function _update60()
 state.update()
 tween_update(1/60)
 g_time+=1
 
 if g_index>0 and g_guy and not g_guy.done then
  g_sec+=1/60
 end
 
 if btnp(❎,1) then
  plt=(plt)%#plts+1
  c1=plts[plt][1]
  c2=plts[plt][2]
  c3=plts[plt][3]
 end
end

function _draw() 
 state.draw()
end

function restart_level()
 g_index=mid(0,31,g_index)
 reload(0x2000,0x2000,0x1000)
 reload(0x1000,0x1000,0x1000)
 
 entity_reset()
 collision_reset()
 
 g_level=e_add(level({
  base=v(g_index%8*16,flr(g_index/8)*16),
  size=v(16,16)
 }))
end
-->8
-- oop

function deep_copy(obj)
 if (type(obj)~="table") return obj
 local cpy={}
 setmetatable(cpy,getmetatable(obj))
 for k,v in pairs(obj) do
  cpy[k]=deep_copy(v)
 end
 return cpy
end

function index_add(idx,prop,elem)
 if (not idx[prop]) idx[prop]={}
 add(idx[prop],elem)
end

function event(e,evt,p1,p2)
 local fn=e[evt]
 if fn then
  return fn(e,p1,p2)
 end
end

function state_dependent(e,prop)
 local p=e[prop]
 if (not p) return nil
 if type(p)=="table" and p[e.state] then
  p=p[e.state]
 end
 if type(p)=="table" and p[1] then
  p=p[1]
 end
 return p
end

function round(x)
 return flr(x+0.5)
end

-------------------------------
-- objects
-------------------------------

object={}
 function object:extend(kob)
  -- printh(type(kob))
  if (kob and type(kob)=="string") kob=parse(kob)
  kob=kob or {}
  kob.extends=self
  return setmetatable(kob,{
   __index=self,
   __call=function(self,ob)
	   ob=setmetatable(ob or {},{__index=kob})
	   local ko,init_fn=kob
	   while ko do
	    if ko.init and ko.init~=init_fn then
	     init_fn=ko.init
	     init_fn(ob)
	    end
	    ko=ko.extends
	   end
	   return ob
  	end
  })
 end
 
-------------------------------
-- vectors
-------------------------------

vector={}
vector.__index=vector
 function vector:__add(b)
  return v(self.x+b.x,self.y+b.y)
 end
 function vector:__sub(b)
  return v(self.x-b.x,self.y-b.y)
 end
 function vector:__mul(m)
  return v(self.x*m,self.y*m)
 end
 function vector:__div(d)
  return v(self.x/d,self.y/d)
 end
 function vector:__unm()
  return v(-self.x,-self.y)
 end
 function vector:dot(v2)
  return self.x*v2.x+self.y*v2.y
 end
 function vector:norm()
  return self/sqrt(#self)
 end
 function vector:len()
  return sqrt(#self)
 end
 function vector:__len()
  return self.x^2+self.y^2
 end
 function vector:str()
  return self.x..","..self.y
 end

function v(x,y)
 return setmetatable({
  x=x,y=y
 },vector)
end

-------------------------------
-- collision boxes
-------------------------------

cbox=object:extend()

 function cbox:translate(v)
  return cbox({
   xl=self.xl+v.x,
   yt=self.yt+v.y,
   xr=self.xr+v.x,
   yb=self.yb+v.y
  })
 end

 function cbox:overlaps(b)
  return
   self.xr>b.xl and
   b.xr>self.xl and
   self.yb>b.yt and
   b.yb>self.yt
 end

 function cbox:sepv(b,allowed)
  local candidates={
   v(b.xl-self.xr,0),
   v(b.xr-self.xl,0),
   v(0,b.yt-self.yb),
   v(0,b.yb-self.yt)
  }
  if type(allowed)~="table" then
   allowed={true,true,true,true}
  end
  local ml,mv=32000
  for d,v in pairs(candidates) do
   if allowed[d] and #v<ml then
    ml,mv=#v,v
   end
  end
  return mv
 end
 
 function cbox:str()
  return self.xl..","..self.yt..":"..self.xr..","..self.yb
 end

function box(xl,yt,xr,yb) 
 return cbox({
  xl=min(xl,xr),xr=max(xl,xr),
  yt=min(yt,yb),yb=max(yt,yb)
 })
end

function vbox(v1,v2)
 return box(v1.x,v1.y,v2.x,v2.y)
end

-------------------------------
-- entities
-------------------------------

entity=object:extend({
 state="idle",t=0,
 last_state="idle",
 dynamic=true,
 dtile=2,
 draw_order=3,
 spawns={}
})

 function entity:init()
  if self.sprite then
   self.sprite=deep_copy(self.sprite)
   if not self.render then
    self.render=spr_render
   end
  end
 end
 
 function entity:become(state)
  if state~=self.state then
   self.last_state=self.state
   self.state,self.t=state,0
  end
 end
 
 function entity:is_a(tag)
  if (not self.tags) return false
  for i=1,#self.tags do
   if (self.tags[i]==tag) return true
  end
  return false
 end
 
 function entity:spawns_from(...)
  for tile in all({...}) do
   entity.spawns[tile]=self
  end
 end

static=entity:extend({
 dynamic=false
})

function spr_render(e,ps,x,y)
 local s,p=e.sprite,e.pos
 
 if x then
  p=v(p.x+x,p.y+y)
 end

 function s_get(prop,dflt)
  local st=s[e.state]
  if (st~=nil and st[prop]~=nil) return st[prop]
  if (s[prop]~=nil) return s[prop]
  return dflt
 end

 local sp=p+s_get("offset",v(0,0))

 local w,h=
  s.width or 1,s.height or 1

 local flip_x=false
 local frames=s[e.state] or s.idle
 local delay=frames.delay or 1
 
 if s.turns and type(frames[1])~="number" then
  if e.facing=="up" then
   frames=frames.u
  elseif e.facing=="down" then
   frames=frames.d
  else
   frames=frames.r
  end
  flip_x=(e.facing=="left")
 end
 if s_get("flips") then
  flip_x=e.flipped
 end

 if (type(frames)~="table") frames={frames}
 local frm_index=flr(e.t/delay) % #frames + 1
 local frm=frames[frm_index]
 local f=e.bold and ospr or spr
 f(e.exr_sprite or frm,
 (sp.x),(sp.y),w,h,flip_x,e.vert)

 return frm_index
end

function ospr(s,x,y,...)
 for i=0,15 do pal(i,0) end
 spr(s,x-1,y,...)
 spr(s,x+1,y,...)
 spr(s,x,y-1,...)
 spr(s,x,y+1,...)
 r_reset()
 spr(s,x,y,...)
end

-------------------------------
-- entity registry
-------------------------------

function entity_reset()
 entities,entities_with,
  entities_tagged={},{},{}
end

function e_add(e)
 add(entities,e)
 for p in all(indexed_properties) do
  if (e[p]) index_add(entities_with,p,e)
 end
 if e.tags then
  for t in all(e.tags) do
   index_add(entities_tagged,t,e)
  end
  c_update_bucket(e)
 end
 return e
end

function e_remove(e)
 del(entities,e)
 for p in all(indexed_properties) do
  if (e[p]) del(entities_with[p],e)
 end
 if e.tags then
  for t in all(e.tags) do
   del(entities_tagged[t],e)
   if e.bkt then
    del(c_bucket(t,e.bkt.x,e.bkt.y),e)
   end
  end
 end
 e.bkt=nil
end

indexed_properties={
 "dynamic",
 "render","render_hud",
 "vel",
 "collides_with",
 "feetbox"
}

-- systems

-------------------------------
-- update system
-------------------------------

function e_update_all()
 for ent in all(entities_with.dynamic) do
  local state=ent.state
  if ent[state] then
   ent[state](ent,ent.t)
  end
  if ent.done then
   e_remove(ent)
  elseif state~=ent.state then
   ent.t=0
  else
   ent.t+=1
  end  
 end
end

function schedule(fn)
 scheduled=fn
end

-------------------------------
-- render system
-------------------------------

function r_render_all(prop)
 local drawables={}
 for ent in all(entities_with[prop]) do
  local order=ent.draw_order or 0
  if not drawables[order] then
   drawables[order]={}
  end
  add(drawables[order],ent)  
 end
 for o=0,15 do 
  if o==1 and prop=="render" then
   local a=entities_tagged["part"]
   if a then
    for e in all(a) do
     e:render_top()
    end
   end
  end
   
  for ent in all(drawables[o]) do
   r_reset(prop)
   if not ent.done then ent[prop](ent,ent.pos) end
  end
 end
end

function r_reset()
 pal()
 palt(0,false)
 palt(14,true)
 pal(0,c1)
 pal(5,c1)
 pal(1,c2)
 pal(13,c3)
 pal(2,c3)
end

-------------------------------
-- movement system
-------------------------------

function do_movement()
 for ent in all(entities_with.vel) do
  local ev=ent.vel
  ent.pos+=ev
  if ev.x~=0 then
   ent.flipped=ev.x<0
  end
  if ev.x~=0 and abs(ev.x)>abs(ev.y) then
  
   ent.facing=
    ev.x>0 and "right" or "left"
  elseif ev.y~=0 then
   ent.facing=
    ev.y>0 and "down" or "up"
  end
  if (ent.weight) then
   local w=state_dependent(ent,"weight")
   ent.vel+=v(0,w)
  end
 end
end

-------------------------------
-- collision
-------------------------------

function c_bkt_coords(e)
 local p=e.pos
 return flr(shr(p.x,4)),flr(shr(p.y,4))
end

function c_bucket(t,x,y)
 local key=t..":"..x..","..y
 if not c_buckets[key] then
  c_buckets[key]={}
 end
 return c_buckets[key]
end

function c_update_buckets()
 for e in all(entities_with.dynamic) do
  c_update_bucket(e)
 end
end

function c_update_bucket(e)
 if (not e.pos or not e.tags) return 
 local bx,by=c_bkt_coords(e)
 if not e.bkt or e.bkt.x~=bx or e.bkt.y~=by then
  if e.bkt then
   for t in all(e.tags) do
    local old=c_bucket(t,e.bkt.x,e.bkt.y)
    del(old,e)
   end
  end
  e.bkt=v(bx,by)  
  for t in all(e.tags) do
   add(c_bucket(t,bx,by),e) 
  end
 end
end

function c_potentials(e,tag)
 local cx,cy=c_bkt_coords(e)
 local bx,by=cx-2,cy-1
 local bkt,nbkt,bi={},0,1
 return function()
  while bi>nbkt do
   bx+=1
   if (bx>cx+1) bx,by=cx-1,by+1
   if (by>cy+1) return nil
   bkt=c_bucket(tag,bx,by)
   nbkt,bi=#bkt,1
  end
  local e=bkt[bi]
  bi+=1
  return e
 end 
end

function collision_reset()
 c_buckets={}
end

function do_collisions()
 c_update_buckets()
 for e in all(entities_with.collides_with) do
  for tag in all(e.collides_with) do
   if entities_tagged[tag] then
   local nothers=
    #entities_tagged[tag]  
   if nothers>4 then
    for o in c_potentials(e,tag) do
     if o~=e and not e.nocol and not o.nocol  then
      local ec,oc=
       c_collider(e),c_collider(o)
      if ec and oc then
       c_one_collision(ec,oc,e,o)
      end
     end
    end
   else
    for oi=1,nothers do
     local o=entities_tagged[tag][oi]
     local dx,dy=
      abs(e.pos.x-o.pos.x),
      abs(e.pos.y-o.pos.y)
     if dx<=20 and dy<=20 then
      local ec,oc=
       c_collider(e),c_collider(o)
      if ec and oc then
       c_one_collision(ec,oc,e,o)
      end
     end
    end
   end     
   end
  end 
 end
end

function c_check(box,tags)
 local fake_e={pos=v(box.xl,box.yt)} 
 for tag in all(tags) do
  for o in c_potentials(fake_e,tag) do
   local oc=c_collider(o)
   if oc and not o.nocol and box:overlaps(oc.b) then
    return oc.e
   end
  end
 end
 return nil
end

function c_one_collision(ec,oc,e,o)
 if ec.b:overlaps(oc.b) then
  c_reaction(ec,oc,e,o)
  c_reaction(oc,ec,e,o)
 end
end

function c_reaction(ec,oc,e,o)
 local reaction,param=
  event(ec.e,"collide",oc.e)
  
 if type(reaction)=="function" then
  reaction(ec,oc,param,e,o)
 end
end

function c_collider(ent)
 if ent.collider then 
  if ent.coll_ts==g_time or not ent.dynamic then
   return ent.collider
  end
 end
 local hb=state_dependent(ent,"hitbox")
 if (not hb) return nil
 local coll={
  b=hb:translate(ent.pos),
  e=ent
 }
 ent.collider,ent.coll_ts=
  coll,g_time
 return coll
end

function c_push_out(oc,ec,
 allowed_dirs,e,o)
 local sepv=ec.b:sepv(oc.b,allowed_dirs)
 if (sepv==nil) return
 -- cls() print(ec.b) print(oc.b)
 ec.e.pos+=sepv
 
 if ec.e.vel then
  local vdot=ec.e.vel:dot(sepv)
  if vdot<0 then
   if (sepv.y~=0) ec.e.vel.y=0
   if (sepv.x~=0) ec.e.vel.x=0
  end
 end
 ec.b=ec.b:translate(sepv)
end

function c_move_out(oc,ec,allowed)
 return c_push_out(ec,oc,allowed)
end

-------------------------------
-- support
-------------------------------


function do_supports()
 for e in all(entities_with.feetbox) do  
  local fb=e.feetbox
  if fb then
   fb=fb:translate(e.pos)
   local support=c_check(fb,{"walls"})
-- ) support=nil
   e.supported_by=support
   if support and support.vel then
    if e:is_a("guy") then
     g_guy.pos+=support.vel
     g_guy2.pos+=support.vel
    else
     e.pos+=support.vel
    end
   end
  end
 end
end
local a="0000000000000000000000000000000000000000000000000000000000000000000000000000000000055555555550000000000000000000005555555555550000000000000000000555155555555500000000000000000005551555555555000000000000000000055555555555550000000000000000000555555555555500000000000000000005555555555555000000008888888800055555550000000000000008888888880555555500000000000000008880008888555555555500000000000080000000558888000000000000005000000000005555558000000000000050000000005555555500000000000000550000005555555555555000000000005550000555555555550050000000000055550055555555555500500000000000555555555555555555000000000000005555555555555555550000000000000005555555555555555500000000000000055555555555555550000000000000000055555555555555500000000000000000055555555555550000000000000000000055555555555000000000000000000000055555555500000000000000000000000055550555000000000000000000000000555000550000000000000000000000005500000500000000000000000000000050000005000000000000000000000000555000055500000000000000000000000000000000000000000000"

function b(y,xx,yy) 
 for c=0,31 do
  for d=1,31 do 
   local e=d+c*32 
   local m=tonum(sub(a,e,e))
   if (m~=0) pset(d+48+xx,c-48+y+yy,m)
  end 
 end
end 

function oprint(s,x,y,...)
 s=smallcaps(s)
 prnt(s,x,y,...)
end

function coprint(s,y,c,m,n)
 s=smallcaps(s)
 prnt(s,64-#s*2+(m or 0),y,c,nil,n)
end

function prnt(s,x,y,c,o,n)
 o=c2--if(not o) o=sget(97,c)
 
 for xx=x-1,x+1 do
  for yy=y-1,y+2 do
   print(s,xx,yy,n or 0)
  end
 end
 
 print(s,x,y+1,o)
 print(s,x,y,c)
end
local gt=0
function f(e)
 cls()
 gt=min(0.5,gt+0.03) 
 local y=96+cos(gt)*5
 for xx=-1,1 do
  for yy=-1,1 do
   if abs(xx)+abs(yy)==1 then
    coprint("^rexellent ^games",
     y+yy,0,xx,7)
   end
  end
 end

 coprint("^rexellent ^games",
  y,7)

 for i=0,15 do pal(i,l[e][6]) end
 for xx=-1,1 do
 for yy=-1,1 do
  if(abs(xx)+abs(yy)==1)b(y,xx,yy)
 end
 end
 pl(e)
 b(y,0,0)
 flip()
end 
 
function g(h,i,j) 
 for e=h,i,j do 
  for m=1,5 do
   pl(e)
   f(e) 
  end
 end 
end 

function pl(e)
 local k=l[e]
 pal()
 pal(8,k[1]) 
 pal(1,k[2]) 
 pal(5,k[3]) 
 pal(7,k[4])
 pal(13,k[5]) 
end

l={
 {0,0,0,0,0,1},
 {2,0,1,1,1,5},
 {4,0,1,5,13,5},
 {4,1,5,6,13,6},
 {8,1,5,7,13,7}
} 
 
function m() 
 g(1,#l,1) 
 g(#l,1,-1) 
 pal() 
 fade()
end

function smallcaps(s)
 s=s..""
  local d=""
  local c
  for i=1,#s do
    local a=sub(s,i,i)
    if a!="^" then
      if not c then
        for j=1,26 do
          if a==sub("abcdefghijklmnopqrstuvwxyz",j,j) then
            a=sub("\65\66\67\68\69\70\71\72\73\74\75\76\77\78\79\80\81\82\83\84\85\86\87\88\89\90\91\92",j,j)
          end
        end
      end
      d=d..a
      c=true
    end
    c=not c
  end
  return d
end

function noprint(s,x,y,c)
 s=smallcaps(s)
 prnt(s,x+4-#s*2,y,c)
end

pltt={7,6,5,1,0}
function fade()
 shk=3
 for i=1,#pltt do
  cls(pltt[i])
  flip()-- flip()
 end
end
-->8
-- level

function block_type(blk)
 if (fget(blk,0)) return solid
 if (fget(blk,1)) return support
 if (fget(blk,2)) return sup
 if (fget(blk,3)) return sdown
end

level=entity:extend({
 draw_order=2
})

function level:init()
 local b,s=self.base,self.size
 for x=0,s.x-1 do
  for y=0,s.y-1 do
   local blk=mget(b.x+x,b.y+y)
   local cl=entity.spawns[blk]
   if cl then
    local e=cl({
     pos=v(x,y)*8,
     map_pos=b+v(x,y),
     tile=blk
    })
    mset(b.x+x,b.y+y,1)
    e_add(e)
    blk=0
   end
   local bt=block_type(blk)
   if bt then
    bl=bt({
     pos=v(x,y)*8,
     map_pos=b+v(x,y),
     tile=blk,
     typ=bt
    })
    if (bl.needed) e_add(bl)
   end
  end
 end
end

function level:render()
 map(self.base.x,self.base.y,0,0,16,8)
end
 
solid=static:extend({
 tags={"walls"},
 hitbox=box(0,0,8,8),
 draw_order=2
})
local dirs={v(-1,0),v(1,0),v(0,-1),v(0,1)}

function solid:init()
 local allowed={}
 local needed=false
 for i=1,4 do
  local np=self.map_pos+dirs[i]
  allowed[i]=
   np.x>0 and np.y>0 and
   block_type(mget(np.x,np.y))
    ~=solid
  needed=needed or allowed[i]
 end
 
 self.allowed=allowed
 self.needed=needed
end

function solid:collide(e)
 return c_push_out,self.allowed
end

sup=solid:extend({
 hitbox=box(0,0,8,4),
})

sdown=solid:extend({
 hitbox=box(0,4,8,8),
})

support=solid:extend({
 hitbox=box(0,0,8,1)
})
 
function support:collide(e)
 if (not e.vel) return
 local dy,vy=e.pos.y-self.pos.y,e.vel.y
 if vy>0 and dy<=vy+1 then
  return c_push_out,{false,false,true,false}   
 end
end
-->8
-- entities

spike=entity:extend({
 collides_with={"guy"}
})

spike:spawns_from(22,38)

function spike:init()
 local up=self.tile==38
 self.hitbox=up and box(0,0,4,8) or box(0,5,8,8)
end

function spike:render()
 if self.t%30>14 then
  if self.pos.y>=64 then
   pal(0,c1)
   pal(1,c3)
   pal(2,c2)
  else
   pal(0,c2)
   pal(1,c1)
   pal(2,c1)
  end
 end
 
 spr(self.tile,self.pos.x,self.pos.y)
end

function spike:collide(o)
 g_guy=nil
 g_guy2=nil
 restart_level()
 sfx(17)
 fade()
 g_deaths+=1
 shk=2
end

platform=entity:extend({
 sprite={
  idle={23},
  width=2
 },
 tags={"walls"},
 collides_with={"walls","guy"},
 hitbox=box(0,0,16,8)
})

platform:spawns_from(23,39)

function platform:init()
 self.dir=-1
 self:become("move")
 self.vel=v(0,0)
 self.sprite.idle[1]=self.tile
end

function platform:idle()
 self.vel.x=0
 if self.t>60 then
  self:become("move")
 end
end

function platform:move()
 self.vel.x=self.dir
end

function platform:collide(o)
 if o:is_a("walls") then
  if self.state~="idle" then
   self.dir*=-1
   self:become("idle")
  end
  return c_move_out
 end
 
 return c_push_out
end

invis=entity:extend({
 tags={"walls"},
 hitbox=box(0,0,8,8)
})

function invis:render()
 local dx=g_guy.pos.x-self.pos.x
 local dy=g_guy.pos.y-self.pos.y
 local dx2=g_guy2.pos.x-self.pos.x
 local dy2=g_guy2.pos.y-self.pos.y
 local d=min(sqrt(dx*dx+dy*dy),sqrt(dx2*dx2+dy2*dy2))
 if d<16 then
  spr(d<12 and 26 or 27,self.pos.x,self.pos.y)
 end
end

function invis:collide()
 return c_push_out
end

invis:spawns_from(26)

swap=entity:extend({
 tags={"walls"},
 sprite={
  idle={42},
  hid={43}
 },
 hitbox=box(0,0,8,8)
})

function swap:init()
 self:become(self.tile==42 and "idle" or "hid")
end

function swap:collide()
 if self.state=="idle" then
  return c_push_out
 end
end

function swap:idle()
 if(self.t>60) self:become("hid")
end

function swap:hid()
 if(self.t>60) self:become("idle")
end

swap:spawns_from(42,43)

jump=entity:extend({
 tags={"walls","jump"},
 sprite={
  idle={58},
  hid={59}
 },
 hitbox=box(0,0,8,8)
})

function jump:init()
 self:become(self.tile==58 and "idle" or "hid")
end

function jump:collide()
 if self.state=="idle" then
  return c_push_out
 end
end

function jump:tog()
 if(self.state=="hid") self:become("idle") return
 self:become("hid")
end

jump:spawns_from(58,59)

ex=entity:extend({
 sprite={idle={15,63,delay=30}}
})

ex:spawns_from(15,63)

function ex:render()
 self.vert=self.pos.y>=64
 if self.t%30>14 then
  if self.vert then
   pal(0,c1)
   pal(1,c3)
   pal(2,c2)
  else
   pal(0,c2)
   pal(1,c1)
   pal(2,c1)
  end
 end
 spr_render(self,self.pos)
end
-->8
-- guy

guy=entity:extend({
 sprite={
  move={10,11,12,delay=5},
  idle={2,3,4,5,6,delay=5},
  jump={8},
  fall={9,25,41,delay=5},
  flips=true
 },
 tags={"guy"},
 collides_with={"walls"},
 hitbox=box(1,0,7,8)
})

function guy:init()
 self.sec=self.tile==7
 self.vel=v(0,0)
 local w=0.1
 
 if self.sec then
  if g_guy2 then self.done=true return end
  g_guy2=self
  self.vert=true
  self.weight=-w
  self.feetbox=box(1,-0.5,7,0.5)
 else
  if g_guy then self.done=true return end
  g_guy=self
  self.feetbox=box(1,7.5,7,8.5)
  self.weight=w
 end
end

function guy:render(w)
 if(w) return
 self:sup()
 if self.sec then
  spr_render(self,self.pos)  
 else
  spr_render(self,self.pos) 
 end
end

function guy:idle()
 self:move()
end

function guy:move()
 local sp=0.7
 if btn(⬅️) then
  self.vel.x-=sp
  self:become("move")
 end
 
 if btn(➡️) then
  self.vel.x+=sp
  self:become("move")
 end
 
 self.vel.x*=0.6
 
 if abs(self.vel.x)<=0.1 then
  self.vel.x=0
  if(self.supported_by) self:become("idle")
 end
 
 if (btnp(❎) or btnp(⬆️)) and self.supported_by then
  local s=1.8
  self:become("jump")  
  local a=entities_tagged.jump
  sfx(16)
  if a and not gt then
   gt=true
   for e in all(a) do
    e:tog()
   end
  end
  
  self.vel.y=self.sec and s or -s
 end
end

function guy:jump()
 self:air_move()
 
 if self.sec then
  if self.vel.y<0 then
   self:become("fall")
  end
 else
  if self.vel.y>0 then
   self:become("fall")
  end
 end
end

function guy:fall()
 self:air_move()
end

function guy:air_move()
 if self.supported_by then
  self:become("idle")
  return
 end
 
 local sp=0.6
 if btn(⬅️) then
  self.vel.x-=sp
 end
 
 if btn(➡️) then
  self.vel.x+=sp
 end
 
 self.vel.x*=0.6
end

function guy:sup()
 if self.sec then
  if self.pos.y<=64 then
   self.pos.y=64
   self.vel.y=0
   self.supported_by={}
  end
 else
  if self.pos.y>=56 then
   self.pos.y=56
   self.vel.y=0
   self.supported_by={}
  end
 end
end

guy:spawns_from(2,7)
-->8

-->8
-- tween engine
-- by @egordorichev

local back=1.70158

-- feel free to remove unused functions to save up some space
functions={
["linear"]=function(t) return t end,
["quad_out"]=function(t) return -t*(t-2) end,
["quad_in"]=function(t) return t*t end,
["quad_in_out"]=function(t) t=t*2 if(t<1) return 0.5*t*t
    return -0.5*((t-1)*(t-3)-1) end,
["back_in"]=function(t) local s=back  return t*t*((s+1)*t-s) end,
["back_out"]=function(t) local s=back t-=1 return t*t*((s+1)*t+s)+1 end,
["back_in_out"]=function(t) local s=back t*=2 if (t<1) s*=1.525 return 0.5*(t*t*((s+1)*t-s))
 t-=2 s*=1.525  return 0.5*(t*t*((s+1)*t+s)+2) end
}

local tasks={}

function tween(o,vl,t,fn)
 local task={
  vl={},
  rate=1/(t or 1),
  o=o,
  progress=0,
  delay=0,
  fn=functions[fn or "quad_out"]
 }

 for k,v in pairs(vl) do
  local x=o[k]
  task.vl[k]={start=x,diff=v-x}
 end

 add(tasks,task)
 return task
end

function tween_update(dt)
 for t in all(tasks) do
  if t.delay>0 then
   t.delay-=dt
  else
   t.progress+=dt*t.rate
   local p=t.progress
   local x=t.fn(p>=1 and 1 or p)
   for k,v in pairs(t.vl) do
    t.o[k]=v.start+v.diff*x
   end

   if p>=1 then
    del(tasks,t)
    if (t.onend) t.onend()
   end 
  end
 end
end
-->8
-- states

ingame={}

function ingame.update()
 e_update_all()
 do_movement()
 do_collisions()
 do_supports()
end

function ingame.draw()
 cls(c3)
 
 if shk>0.1 then
  camera(rnd(shk)-shk/2,rnd(shk)-shk/2)
  shk-=0.3
 else
  camera()
 end
 
 r_reset()
 rectfill(0,64,127,127,0)
 pal(0,c2)
 pal(1,c3)
 pal(12,c2)
 pal(13,c1)
 map(g_level.base.x,
  g_level.base.y+8,0,64,16,8)
 r_reset()
 r_render_all("render")

 if g_index~=18 and g_guy and g_guy2 then
  if abs(g_guy.vel.x)<abs(g_guy2.vel.x) then
   g_guy2.vel.x=g_guy.vel.x
   g_guy2.pos.x=g_guy.pos.x
  else
   g_guy.vel.x=g_guy2.vel.x
   g_guy.pos.x=g_guy2.pos.x
  end
  
  if g_guy.vel.y<-g_guy2.vel.y then
   g_guy2.vel.y=-g_guy.vel.y
   g_guy2.pos.y=128-g_guy.pos.y-8
  elseif g_guy.vel.y>-g_guy2.vel.y then
   g_guy.vel.y=-g_guy2.vel.y
   g_guy.pos.y=(128-g_guy2.pos.y)-8
  end
 elseif not g_guy2.done then
  if g_guy2.pos.x>124 then
   g_guy2.done=true
   g_guy.done=true
   music(-1)
   fade()
  end
 end
 
 pal(0,c2)
 if(not g_guy2.done)g_guy2:render()
 r_reset()
 if(not g_guy.done)g_guy:render()
 
 if g_index%8<7 and g_guy.pos.x>=124 then
  local g1=g_guy
  local g2=g_guy2
  g1.pos.x-=128
  g2.pos.x-=128
  g_index+=1
  restart_level()
  e_add(g1)
  e_add(g2)
  return
 end
 
 if g_index>0 and g_guy.pos.x<=-4 then
  local g1=g_guy
  local g2=g_guy2
  g1.pos.x+=128
  g2.pos.x+=128
  g_index-=1
  restart_level()
  e_add(g1)
  e_add(g2)
  return
 end

 if g_index<23 and g_guy2.pos.y>=124 then
  local g1=g_guy
  local g2=g_guy2
  g1.pos.y+=64
  g2.pos.y-=64
  g_index+=1
  restart_level()
  e_add(g1)
  e_add(g2)
  fade()
  return
 end
 
 gt=false
 
 if g_guy.done and g_index==18 then
  coprint("^oh no",60,c3)
  coprint("^thank you",68,c3)
  
  coprint(g_deaths.." fails",80,c3)
  coprint(flr(g_sec+0.5).." seconds",88,c3)
  
  if(btnp(🅾️)) g_guy=nil g_guy2=nil _init()
 end
 
 oprint("^level "..(g_index+1),1,1,c3)
 if(btn(🅾️)) print(stat(1),1,9,7)
end

menu={}

function menu.update()

end

function menu.draw()

end
