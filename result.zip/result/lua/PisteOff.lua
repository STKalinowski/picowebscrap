-- pico ski
-- by @eoinmcg

state = 'splash'
hiscore = 1000

function _init()
	_change_state(state)
end

function _change_state(state)
	camera(0,0)
	state = state
	if state == 'main' then 
	 _init_main()
	else 
	 _init_splash()
	end
end


function _update()
 if state == 'main'then 
  _update_main()
 else 
  _update_splash()
 end
end

function _draw()
 if state == 'main' then 
  _draw_main()
 else 
  _draw_splash()
 end
end

function _init_splash()
	cls()
	fade_in()
	timer = 0
	start_col = 12
	snow = {}
	num_snow = 30
	
	logo = {}
	logo.x = 34
	logo.y = -150
	logo.y_dest = 50
	logo.y_dist = 0
	
	music(1, 15)

 for i=1,num_snow do
  snow_add()
 end
end

function _update_splash()
	timer += 1
 foreach(snow, snow_update)
 logo_update()
 if (btn(2)) then
 	music(-1, -1)
 	sfx(7,0)
  fade_out()
  _change_state('main') 
 end
end

function _draw_splash()
	rectfill(0, 0, 127, 127, 15)
 rectfill(0, 43, 128, 44, 14)
 rectfill(0, 38, 128, 40, 14)
 rectfill(0, 0, 128, 35, 14)
 rectfill(0, 0, 128, 8, 8)
 rectfill(0, 10, 128, 11, 8)

 map(16,0, 0,0, 128,128)
 map(0,0, 0,0, 128,128)

 foreach(snow, snow_draw)
 
 logo_draw()
 print('hi:', 3, 2, 7)
	print(flr(hiscore), 16, 2, 7)

 
 if (timer % 20 == 0) then
 	if (start_col == 12) then
 	 start_col = 1
 	else
 		start_col = 12
 	end
 end
 
 if (start_col == 1) then
  print('press up to start', 30, 110, start_col)
	end
	
end

function _init_main()

	fade_in()
	timer = 0
 dist = 0
 speed = 2

	state = 'main'
	
	new_hiscore = false

 trees = {}
 num_trees = 1
 max_trees = 20

 bg_dots = {}

 particles = {}
 people = {}
 
 yeti = {}
 yeti.anim_tick = 0
 yeti.f = 24
 yeti.y = -70
 yeti.x = 60
 yeti.vy = 0.3
 yeti.howl = false
 yeti_runs = 0
 
 messages = {
  'beware, yeti!',
  --'respect skiers',
  --'stay safe',
  --'yellow snow alert',
  --'wear a helmet!',
  --'be nice!',
 }
 
 sign = {}
 sign.x = 65
 sign.y = 60
 --sign.msg = 'beware yeti!'
 sign.msg = 	messages[flr(rnd(#messages)) + 1]

 p1 = {}
 p1.dir = 2
 p1.anim_tick = 0
 p1.frame_offset = 0
 p1.frame_update = 0
 p1.x = 30
 p1.y = 40
 p1.invincible = 0
 p1.trail = {}
 trail_add()
 p1.dead = false
 shakescreen = 0

 game_over = {}
 game_over.text = 'game over'
 game_over.x = 45
 game_over.y = 220
 game_over.y_dest = 60
 game_over.y_dist = 0
 game_over.col = 8

 for i=1,20 do
  bg_dots[i] = {}
  bg_dots[i].x = flr(rnd(127))
  bg_dots[i].y = flr(rnd(127))
 end

  people_add()

 for i=1,num_trees do
  tree_add()
 end
  
 music(0, 14) 
  
end


function _update_main()

	foreach(particles, particle_move)
 foreach(people, people_update)
	yeti_update()

 if (btn(5)) then 
  music(-1, -1)
 	sfx(7,0)
  fade_out()
  _change_state('splash') 
 	state = 'splash'
 end

	
	p1_update()
	if (p1.dead) then
	 if (btn(2)) then _change_state('main') end
	 return
	end
	
	dist += speed


	bg_update()
	trail_update()
	sign_update()
		
	foreach(trees, tree_update)
	speed += 0.003
	
	if (speed > 4) then speed = 4 end

--	check_collision()
	foreach(trees, player_hit_tree)
	foreach(trees, yeti_hit_tree)
	foreach(people, player_hit_people)
	foreach(people, people_hit_tree)
 yeti_eats_p1()
 
 if (timer % 100 == 0) then
 	tree_add()
 end
 
 timer += 1
 
end

function _draw_main()

	if (shakescreen > 0) 
	then do_shakescreen() 
	else camera(0, 0)
	end

	rectfill(0, 0, 127, 127, 7)

 local hiscore_col = 6

	bg_draw()
	trail_draw()
	if (not p1.dead) then yeti_draw() end
	foreach(trees, tree_draw)
	foreach(people, people_draw)
	p1_draw()
	if (p1.dead) then yeti_draw() end

	foreach(particles, particle_draw)
	sign_draw()

	if (dist > hiscore) then
		hiscore = dist
		new_hiscore = true
	end
	
	if (new_hiscore) hiscore_col = 9

	print('hi:', 5, 7, 7)
	print(flr(hiscore), 17, 7, 7)
	
	print('hi:', 5, 6, hiscore_col)
	print(flr(hiscore), 17, 6, hiscore_col)


	print(flr(dist), 110, 5, 12)

	if (p1.dead) then
			game_over.y_dist = game_over.y_dest - game_over.y
			game_over.y = tween(game_over.y, game_over.y_dist, 900)

	  print(game_over.text, 
	  					game_over.x, game_over.y,
	  					game_over.col)
	end

end

function bg_draw()
 for i=1,20 do
 local n = bg_dots[i]
  rectfill(n.x, n.y, n.x, n.y, 6)
 end
end

function bg_update()
 for i=1,20 do
  bg_dots[i].y -= speed
  if (bg_dots[i].y < 0) then bg_dots[i] = bg_replot() end
 end
end

function bg_replot()
 local n = {}
 n.x = flr(rnd(127))
 n.y = 127
 return n
end


function p1_update()
	local change_dir = p1.dir

 if (timer % 5 == 0) then
  if (p1.frame_offset == 0) then
   p1.frame_offset = 16
  else
   p1.frame_offset = 0
  end
 end

	p1.anim_tick += 0.2
	if (p1.anim_tick >= 1) then 
	 p1.frame_update = 1 
	 p1.anim_tick = 0
	else 
	 p1.frame_update = 0 
	end

	if (p1.dead) then return end

	if (btn(0)) then 
	 p1.x = p1.x - 1.5 
	 p1.dir = 12
	elseif (btn(1)) then 
	 p1.x = p1.x + 1.5 
	 p1.dir = 11
 else p1.dir = 10 end

	if 
	 (p1.dir != change_dir) 
	then 
	 sfx(1,1)
	 trail_add()
	end

	if (p1.x < 0) then p1.x = 0 end
	if (p1.x > 120) then p1.x = 120 end

end

function p1_draw()
	if (p1.eaten) then
 elseif (p1.dead) then
 	spr(p1.dir, p1.x, p1.y)
	 p1.dir += p1.frame_update
	 if (p1.dir > 20) then 
	  p1.dir = 18 
	 end
	else
	 spr(3 + p1.dir, p1.x, p1.y + 3)
	 spr(p1.dir + p1.frame_offset, p1.x, p1.y)
	end
end


function trail_add()
	local pos = {}
	pos.x = p1.x
	pos.y = p1.y
	add(p1.trail, pos)
end

function trail_update()
	for pos in all(p1.trail) do
	 pos.y -= speed
	end
end

function trail_draw()

	local t = p1.trail
 local len = #p1.trail
	local n
	local a
	local b

	for i=1,len do
		n = i + 1
		a = t[i]
		b = t[i+1]
		if (not b) then b = p1 end
		if (b) then
			line (a.x + 2, a.y + 8, b.x + 2, b.y + 8, 6)
			line (a.x + 5, a.y + 8, b.x + 5, b.y + 8, 6)
		end
	end
	

end


function tree_draw(t)
	spr(t.f, t.x, t.y)
end

function tree_update(t)
 if (t.y < -10) then
  del(trees,t)
  tree_add()
 end

  t.y -= speed

end

function tree_add()
 local t = {}
 t.f = flr(rnd(4)) + 5
 t.x = flr(rnd(18)) * 8
 t.y = 127 + (flr(rnd(8)) * 8)
 if (t.f == 5) then t.col = 3
 elseif (t.f == 6) then t.col = 5 end
 add(trees, t)
end

function people_draw(p)

	if (not p.dead) then 
	 spr(3, p.x, p.y + 2)
	else
	 print("+50", p.x+10, p.y, 12) 
	end

	spr(p.f + p.f_offset, p.x, p.y)
	
end

function people_update(p)
 if (p.y < -10) then
  del(people,p)
  people_add()
 end

 if (p.dead) then p.f = 4 p.y -= speed
  else p.y -= speed - 1
 end
 
 p.anim_tick += 0.3
 if (p.anim_tick > 1 and not p.dead) then
 	p.anim_tick = 0
 	if (p.f == (p.f_start + 1)) then
 	 p.f = p.f_start
 	else 
 	 p.f = p.f_start + 1
 	end
 end

end

function people_add()
 local offset = 0
	local p = {}
	
	if (rnd(3) < 1) then
	 offset = 16
	end
	
	 p.dead = false
	 p.x = ( flr(rnd(7)) * 8 ) + 28
	 p.y = 127 + (flr(rnd(8)) * 8)
	 p.f_start = 21
	 p.f_offset = offset
	 p.f = p.f_start
	 p.anim_tick = 0
	 add(people, p)
end

function yeti_update()
	yeti.y += yeti.vy
	if (yeti.howl == false and yeti.y >= -16) then
	 sfx(3, 3)
	 yeti.howl = true
	end
	
	if (p1.x >= yeti.x and not p1.dead) then
	 yeti.x += yeti.vy
	elseif (p1.x < yeti.x and not p1.dead) then
	 yeti.x -= yeti.vy
	end

	if (yeti.y > 150 and not p1.dead) then
		yeti.y = -50
		yeti.howl = false
		yeti.vy += 0.2
		--yeti.runs += 1
	end
	
	yeti.anim_tick += 0.5
	
	if (yeti.anim_tick > 1) then
		yeti.anim_tick = 0
		yeti.f += 1
		if (yeti.f > 33) yeti.f = 32
	end
	
	if (p1.dead and p1.eaten) then
		particle_add(yeti.x + 3, yeti.y + 3, 8, 1) 
	end
	
end

function yeti_draw()

 local offset = 0

 if (p1.eaten) then
  offset = 2
 end
 
 spr(yeti.f + offset,yeti.x,yeti.y)
 spr(yeti.f + offset + 16,yeti.x,yeti.y+8)

end

function particle_add(x, y, col, num)
	
	for i=1,num do
		local p = {}
	 p.x = x
	 p.y = y
	 p.col = col
	 p.dx = rnd(2) -1
	 p.dy = rnd(2) -1	 
	 p.vx = rnd(4) +1
	 p.vy = rnd(4) +1
	 add(particles, p)
	end

end

function particle_move(p)
 if (p.vx < 0 or p.vy < 0) then
  del(particles,p)
 end

	p.vx -= 0.2
	p.vy -= 0.2

 p.x += (p.dx * p.vx)
 p.y += (p.dy * p.vx)
end

function particle_draw(p)
 rectfill(p.x, p.y, p.x + 1, p.y + 1, p.col)
end

function sign_update()
 sign.y -= speed
end

function sign_draw()

	local w = 10
	local h = 2
	local start = 128
	local x
	local y

 for x=0,w-1 do
  for y=0,h-1 do
   spr(x+start + (y * 16), sign.x + (x * 8), sign.y + (y*8))
  end
 end
 
 print(sign.msg, sign.x + 8, sign.y + 5, 15)

end

function do_shakescreen()
	shakescreen -= 1
	if (shakescreen <= 0)
	 then camera(0,0)
	 else camera(flr(rnd(4))-4,flr(rnd(4))-4)
	end
end

function yeti_hit_tree(t)
  if (collides(t, yeti))
   then
    sfx(0,3)
	   particle_add(t.x + 4, t.y + 4, t.col, 5)
    t.y = -150
    shakescreen = 3
  end
end

function player_hit_tree(t)

  if (collides(t, p1))
   then
    if (p1.invincible <= 0) 
    then 
     p1.dead = true
     yeti.vy = speed
     speed = 0
     p1.dir = 18
     p1.y += 4
		  	music(-1)
    end
    sfx(0,0)
	   particle_add(t.x + 4, t.y + 4, t.col, 10)
    t.y = -150
    shakescreen = 15
   end 

end


function player_hit_people(p)

  if (not p.dead and collides(p, p1))
   then
     p.dead = true
     dist += 50
    sfx(2,1)
	   particle_add(p.x + 4, p.y + 4, 6, 4)
    shakescreen = 5
   end 

end

function people_hit_tree(p)
	if (not p.dead and not p.stop)
	then
	end
end

function yeti_eats_p1()
 if (not p1.dead and collides(p1, yeti)) then
   p1.dead = true
   p1.eaten = true
   speed = 0
   yeti.vy = 0
   particle_add(p1.x + 4, p1.y - 8, 8, 12) 
			music(-1)
			sfx(6,1)
 end
end

function collides(a, b)

 -- more forgiving
	local bx1 = b.x +2
	local bx2 = b.x +6
	local by1 = b.y +5
	local by2 = b.y +8

 local hit = (a.y+8<by1) 
		or (a.y>by2)
		or	(a.x+8<bx1) 
		or (a.x>bx2)
		
	return not hit	
			
end

function snow_add()
 local s = {}
 s.r = flr(rnd(3)) + 1
 s.x = flr(rnd(18)) * 8
 s.x_const = s.x
 s.y = -flr(rnd(18)) * 8
 s.vy = s.r / 3
 s.wave = flr(rnd(9)) + s.r
 add(snow, s)
end


function snow_update(s)
  if (s.y > 140) then
  	del(snow,s)
  	snow_add()
  else
   s.y += s.vy 
   s.x = s.wave * sin(timer / 100) + s.x_const 
  end
end

function snow_draw(s)
	circfill(s.x, s.y, s.r, 7)
end

function logo_update()
		logo.y_dist = logo.y_dest - logo.y
		logo.y = tween(logo.y, logo.y_dist, 900)
end

function logo_draw()
	local w = 8
	local h = 4
	local start = 67
	local remap = 115
	local x
	local y
	
 for x=0,w-1 do
  for y=0,h-1 do
   spr(x+start + (y * 16), logo.x + (x * 8), logo.y + (y*8))
  end
 end
	
end

function tween(current, dest, speed)
 local fps = 60
 return dest * fps / speed + current
end

function fade_out()
 dpal={0,1,1, 2,1,13,6,
  4,4,9,3, 13,1,13,14}
          
 -- palette fade
 for i=0,40 do
   for j=1,15 do
     col = j
     for k=1,((i+(j%5))/4) do
      col=dpal[col]
     end
    pal(j,col,1)
   end
  flip()
 end
end

function fade_in()

 cls()
 pal()
 flip()

end