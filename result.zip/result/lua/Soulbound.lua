
wr=8
dd={1,0,0,1,-1,0,0,-1}


function _init()
 ents={} 
 logs={}
 fd=0
 t=0 
 
 init_intro() 
 --init_game()
 --epilogue()
end

function init_intro()

 intro=true
 init_game()
 hero.upd=function()
  if not hero.⧗start and btnp(5) or btnp(4) then
   hero.⧗start=16
   sfx(53)
   music(-1,1500)
 		local f=function()
 		 intro=false
 		 hero.upd=upd_hero
 		end
   wt(16,f)
   
  end
 end
 music(0) 
 
end

function dr_intro()


 local y=sqrt(min(t/16,1))*32-32
 if hero.⧗start then
  local c=(1-hero.⧗start/16)
  y-=c*c*32
 end

 spr(192,0,y,2,1)
 spr(208,0,y+8,16,2) 
 spr(252,96,y+24,2,1)
 
 
 
 local s="press ❎ to start"
 if (t%16>4) and not hero.⧗start then
  function f()
   print(s,64-2*#s,88,15)
  end
  brd(f)
 end
 
end

function brd(f)
 apal(0)
 camera(-1,0) f()
 camera(1,0) f()
 camera(0,-1) f()
 camera(0,1) f()
 pal()
 camera() f()
end



function init_game()
 ents={}
 t=0
 gem=nil
 obj=nil
 snakes={}
 shk=0
 fd=0
 cmx=nil
 cmy=nil
 --
 menuitem(1,"retry",init_game)
 
 --
 upd=function()
	 gtl={}
	 if meca then
	  upe(meca)
	  return  
	 end 
	 foreach(ents,upe) 
	 chk_trigs() 
 end
 mdr=dr_game
 
 -- reload
 reload()
 if state then
	 for t in all(state.tls) do
	  mset(t.x,t.y,t.tl) 
	 end 
 end 

 -- scan
 for x=0,16*8 do for y=0,16*4 do
  local tl=mget(x,y)
  if tl==23 then
   mk_hero(x,y)
   mset(x,y,1)
  end 
  if fget(tl,3) then
   mk_obj(tl,x,y)
   mset(x,y,1)
  end
  if fget(tl,5) then
   mk_mon(tl,x,y)
   mset(x,y,0)
  end   
 end end
 
 -- load
 if state then
	 for o in all(state.obj) do
	  mk_obj(o.id,o.x,o.y)
	 end	 
	 mk_hero(state.hpx,state.hpy)
 end
 
 --
 fd=4
 fad(0,16)
 
end


function mk_mon(n,x,y)
 local e=mke(n,x*8,y*8)
 e.hp=2
 e.hurt=function() end
 e.s=1
 e.frict=.85
 
 -- cobra
 if n==194 then

  e.phys=true
  e.mon=true  
  e.hurt=function()
   e.vx=sgn(e.x-hero.x)*4
  end    
  e.upd=function()
   e.fr=194+(t/8)%2   
			wander(e,.5)   
  end
  --e.brd=0
 end
 
 -- skeleton
 if n==196 then
 	e.fr=0
  e.phys=true
  e.mon=true  
  e.hurt=function()
   e.vx=sgn(e.x-hero.x)*4
  end    
  e.upd=function()    
   if e.⧗prep then  
    if e.⧗prep==1 then
     ske_shoot(e)
     e.vy-=3
    end
   else 
    wander(e,.5)				
    if is_in_cam(e)
       and not e.⧗cd 
       and e.flx==(e.x>hero.x) then
     e.⧗prep=40
     e.⧗cd=80+rand(80)
    end    
   end   
  end
  
  e.dr=function(e,x,y)
   local wfr=flr((e.x/2)%4)
   if not ecol(e,0,1) then
    wfr=1
   end 
   if e.⧗prep then
    wfr=0
   end 
   if wfr>=1 and wfr<3 then
    y-=1
   end   
   spr(197+wfr,x,y,1,1,e.flx)
   spr(196,x+flr(wfr/2)*e.s,y-4,1,1,e.flx)
  end 
 end 
 
 -- clarence hilford
 if n==24 then
  e.fr=0
  e.flx=true
  e.dr=dr_hero
  e.cla=true
  cla=e
  e.upd=function(e)
   e.wfr=(2-e.x/4)%4 
   if not hero.dead then
	   if not gem_active() then
	    e.flx=e.x-hero.x>0
	   end
	   local hgem=obj==32 or gem_active()
	   local hdx=e.x-hero.x
	   if hgem and hdx>0 and hdx<24 then
	    cla_shoot()
	   end	   
	  end 
  end  
 end
 
 -- car
 if n==123 then
  e.hp=nil
  e.fr=0
  e.dp=0
  e.dr=function(e,x,y)
   spr(102,x,y-8,6,2)
  end
  e.upd=function()
   if obj==32 and hero.x-e.x>16 then
    hero.invis=true
    end_game()
   end  
  end 
  car=e
 end 
end

function is_in_cam(e,ma)
 ma=ma or 0
 local dx=e.x-cmx
 local dy=e.y-cmy
 return dx>ma and dx<120-ma and dy>ma and dy<120-ma
end

function ske_shoot(sk)
 sfx(30)
 local e=mke(201,sk.x,sk.y)
 local dx=hero.x-sk.x
 local dy=hero.y-sk.y
 local an=atan2(dx,dy)
 e.vx=cos(an)
 e.vy=sin(an)
 e.alp=4
 e.brd=0
 e.shot=true
 e.life=160
 e.blk=16

end


function wander(e,spd)
 if not ecol(e,0,1) then
  e.y+=1
  return
 end    
 e.x+=e.s*spd
 local npx=flr(e.x/8+.5+e.s*.5)
 local py=flr(e.y/8)
 if fg(npx,py) or not fg(npx,py+1) then
  e.s*=-1
  e.flx=e.s<0
 end 
end

function end_game()
 sfx(1)
 car.y+=1
 meca=mke()
 meca.upd=function(mc)
  
  if mc.t==8 then
   car.y-=1
   
  end
  
  if mc.t==24 then
   sfx(19) 
  end
  
  if mc.t>24 then
   car.x+=(mc.t-24)/4
  end
  
  if mc.t==55 then
			kl(meca)
			meca=nil
   fad(4,16,epilogue)   
  end  
 end 
end

function epilogue()
 music(10)
 t=0
 fd=4
 fad(0,16)
 local sy=128
 local cx=40
 local go=nil
 upd=function()
  if go then
   go+=1
   cx=40+(go*go/2)
   if go==8 then
    state=nil
    fad(4,32,init_intro)
   end 
  elseif t>20 and (btnp(4) or btnp(5)) then
   go=0   
   sfx(20)
  end  
  foreach(ents,upe)
 end
  
 local a={
	 "the soul gem is now yours!",
	 "nobody can stop you from",
	 "raiding ancient shrines",
	 "and burgling rich people",
	 "houses",
	 "",
	 "congratulations!", 
 }
 mdr=function(e)
 
  -- scroll
  if sy>28 then
   sy-=1
  end
  local k=0
  local by=sy
  for s in all(a) do
   local cl=sget(max(sy/8+k-4,0),1)
   for i=1,#s do
    local x=64+i*4-#s*2-2
    local y=sy+k*8
    if k==#a-1 then
     cl=t<100 and 0 or sget((i+t/4)%4,0)
     local an=i/8+t/32
     local ec=max(130-t,2)
     x+=cos(an)*ec
     y+=sin(an)*ec
    end    
    if cl>0 then
     print(sub(s,i,i),x,y,cl)
    end
   end
   k+=1
  end
	 -- decor	 
	 spr(102,cx,96+(t%40<8 and 1 or 0),6,2)
	 for i=0,1 do
	  local x=(-t*2)%128-i*128	  
	 	map(0,0,x,104,16,3)
  end
  
 end
 

 
 
end


function cla_shoot()
 --meca=mke()
 cla.⧗shoot=16
 sfx(18)
 hero.vx=-4 
 meca=nil
 drop()
 gem.fall=true 
 
 
 local grab=function()
  cla.obj=32
  kl(gem)
  gem=nil
  mv(cla,48,0,-1,black)
  cla.flx=false
 end
 local f=function()
  mvt(cla,gem.x,gem.y,-1,grab)
 end

 hero_die()
 wt(32,f)
 
 
end


function mk_hat(fr,from)
 local e=mke(fr)
 e.x=from.x
 e.y=from.y
 e.vx=from.vx*1.4
 e.vy=-3
 e.we=.1
 e.life=24
 e.blk=8
 e.frict=.85
end



function retry()
 if state then
  init_game()
 else
  init_intro()
 end

end
--]]

function wt(t,f)
 local e=mke()
 e.nxt=f
 e.life=t
end

function fad(n,tempo,nxt) 
 local sn=fd 
 local f=function(e) 
  fd=sn+(n-sn)*e.t/tempo
 end 
 loop(f,tempo,nxt)
end


function mk_hero(px,py) 
 hero=mke(0,px*8,py*8)
 hero.hhp=3
 hero.phys=true
 hero.we=.25
 hero.upd=upd_hero
 hero.dr=dr_hero
 hero.lp=true
 hero.wfr=0
 hero.bncx=function(e)
  e.vx=0  
  if e.vy>0 and not obj then
   e.vy=0
   if t%8==0 and not hg then
    sfx(50)
    dust(cpx,cpy,13,1)
   end
  end
 end
 hero.bncy=function(e)
  if e.vy<-1 then
   head_bump(cpx,cpy)
  end
  if e.vy>=1 then
   sfx_step()
  end
  e.vy=0
 end  
 
 set_camera()

 --[[ 
 cmx=gem.x-64
 cmy=gem.y-64
 ctx=cmx
 cty=cmy
 --]]

end



function sfx_step()
 local n=10
 local px=flr(hero.x/8)
 local py=flr(hero.y/8)
 if fget(mget(px,py),4) or fget(mget(px,py+1),4) then
  n=11
 elseif fget(mget(px,py+1),6) then
  n=12
 end
 
 
 sfx(n)
end


function get_tl(e)
 return mget(flr(e.x/8+.5),flr(e.y/8+.5))
end

function trap_shoot(x,y,d)
 
 local e=mke(248+d,x,y)
 local spd=4
 e.vx=dd[1+d*2]*spd
 e.vy=dd[2+d*2]*spd
 e.shot=true 
 local ghost=true
 e.upd=function()  
  local tl =get_tl(e)
  if fget(tl,0) then
   if not ghost then
	   e.upd=nil
	   e.life=16
	   e.vy=-4
	   e.we=.25
	   e.vx*=-.5
	   e.frict=.9
	   e.alp=4
	   e.shot=false
	   e.fr=248
	   sfx(52)
   end
  else
   ghost=false
  end  
 end
 
end


function upd_hero(h)
 if h.⧗frz then
  return
 end
 h.vx*=.85
 if hero.dead then
  return
 end
 hg=ecol(h,0,1)
 hr=ecol(h,1,0) and not obj
 hl=ecol(h,-1,0) and not obj


 -- run
 function hmov(n)
  local k=n*2
  if h.⧗lock then
   k*=1-h.⧗lock/24
  end 
  pmov(h,mid(-2,k,2),0)
  h.flx=n<0
  h.wfr=(h.wfr+1/4)%4
  if hg and flr(h.wfr*4)%8==0 then
   sfx_step()
  end  
 end
 if btn(0) then hmov(-1)
 elseif btn(1) then hmov(1)
 else
  h.wfr=0
 end 
 if not hg then
  h.wfr=h.vy>0 and 3 or 2
 end

 -- jump
 if btnp(4) then
	 if hg then
	  sfx(5)
	  h.vy=-4.25
	 elseif hr or hl then
	  sfx(5)
	  h.vy=-3
	  h.vx=2*(hr and -1 or 1)
	  h.⧗lock=24
	 end
 end
 
 -- hpx
	hpx=flr(h.x/8+.5)
	hpy=flr(h.y/8+.5) 
 
 
 -- traps
 for i=0,3 do
  for k=1,16 do
   local nx=hpx+dd[1+2*i]*k
   local ny=hpy+dd[2+2*i]*k
   local tl=mget(nx,ny)
   
   if not is_in_cam({x=nx*8,y=ny*8},0) then
    break
   end
   
   
   if tl==246 then
   
    local dx=nx*8-cmx
    local dy=ny*8-cmy
    --glow_til(nx,ny,8,15)
    sfx(51)
    mset(nx,ny,247)
    trap_shoot(nx*8,ny*8,(i+2)%4)
   elseif fget(tl,0) then
    break
   end   
  end
 end
 
 
 -- scan action
 action=nil 
 if hg then
	 htl=mget(hpx,hpy)
	 if htl==101 and hg then  
	  action={name="read",f=function() read_tablet(hpx) end }
	 end 
	 for i=0,1 do
	  local tl=mget(hpx,hpy-i)
	  if tl==26 or tl==27 then
	   local n=  tl==26 and "push" or "pull"
	   action={name=n,f=function() lever(hpx,hpy-i) end}
	  end
	 end 
  if ecole(hero,cla,16) and hero.flx!=cla.flx and not cla.dead then
   action={name="talk",f=talk_cla}
  end
  local res=nil  
	 for e in all(ents) do
	  if e.obj and ecole(e,h,6) then
	   res=e
	  end
	 end	
	 if res then
	  action={name="take",f=function()grab(res)end}
	 end
	 
 end 
 
 
 -- use 
 if btnp(5) and not h.⧗sword then
  if action then
   action.f()
   action=nil   
  elseif obj and hg then
   use_obj() 
  else
	  use_machete() 
  end

 end
 
 -- col monster
	chk_hero_col()
 
 -- grab/drop
 if hg and obj and btnp(3) then 
  drop()
 end
 

end

function hit_hero(from)
 hero.hhp-=1
 hero.⧗hurt=40
 hero.⧗show_hearts=80
 hero.vx+=sgn(hero.x-from.x)*4
 hero.vy-=3
 hero.⧗lock=16
 
 if hero.hhp==0 then
  hero.⧗hurt=nil
  hero_die()
	 wt(60,black)
 else
  sfx(27)
 end 
 
end

function chk_hero_col()
 if hero.⧗hurt then
  return
 end
 
 for e in all(ents) do
  if e.mon and ecole(e,hero,6) then
   hit_hero(e)
  end
  if e.shot and ecole(e,hero,6) then
   hit_hero(e)
   kl(e)
  end	  
 end
end

function black()
 fad(4,16,retry)
end

function hero_die(w,nxt)

 sfx(31)
 hero.dead=true 
 local f=function()
  hero.dr=function(e,x,y)
   spr(30,x+4,y+1)
  end
  hero.fr=62
 end 
 wt(14,f) 
 mk_hat(46,hero) 

end

function read_tablet(px)

 local a={"i can't read this"}
 local cl=15
 
 if px==33 then
	 a={
	  "...◆...",
	  "when the four guardians",
	  "share a vision",
	  "the bond might be sealed",
	  "...◆...",
	 }
	elseif px==26 then
	 a={
	  "...◆...",
	  "and in his hands",
	  "the hero's heart",
	  "finally find rest",
	  "...◆...",
	 }
	elseif px==17 then
	 a={
	  "...◆...",
	  "he stoped on the third step",
	  "and turned back to admire",
	  "everything he had built",
	  "...◆...",
	 }	 
	elseif px==49 then
	 a={
	  "...◆...",
	  "the questions and",
	  "the answers are",
	  "on both sides of the door",
	  "...◆...",
	 }
	elseif px==64 then
	 a={
	  ".▥.▤lunar...",
	  "▥..▥ˇ..arodan▤▤",
	  "ˇrˇshrineˇˇ",
	  ".▥.sealed.. for..",
	  "...776 years.. ",
	 }	 	
	 cl=15
	elseif px==86 then
	 a={
	  "...◆...",
	  "what will remain of",
	  "your glories and ideals",
	  "when your true soulmate",
	  "will stab you in the dawn",
	  "...◆...",
	 }	
	 
	   	 
	end 
	

 adv_talk(hero,a,cl)
end


function adv_talk(e,a,tcl)

 local i=1
 local h={""}
 meca=mke() 
 meca.upd=function()   
  local p=a[1]
  if i<#p and t%2==0 then
   i+=1
   if t%4==0 then
    local n=rand(8)
    if tcl==11 then
     n+=8
    end   
    sfx(17,nil,n,1)
   end
   e.⧗talk=4
  end  
  h[#h]=sub(p,1,i)
  --log(i)
  if i==#p then  
   if #a>1 then
	   i=0
	   del(a,p)
	   add(h,"")
   else
    e.⧗talk=nil
    if btn(4) or btn(5) then
	    kl(meca)
	    meca=nil
    end
   end   
  end 
 end
 meca.dr=function()
  local f=function(x,y)
	  for i=1,#h do
	    local s=h[i]
	    print(s,x-#s*2,y+i*6,tcl or 15)
	  end 
  end 
  brd_b(f,e.x,e.y-12-#h*6)  
 end
 
end

function brd_b(f,x,y)
 apal(0)
 f(x+1,y)
 f(x-1,y)
 f(x,y+1)
 f(x,y-1)
 pal()
 f(x,y)
end


function talk_cla()
 local a={}
 if gem_active() then 
  srand(4)
  add(a,"bring the gem !")
  add(a,"quick !")
 else
  add(a,"the gem is in the temple")
  add(a,"the entry is hidden")
  add(a,"in the eastern jungle")
  add(a,"good luck")
 end

 adv_talk(cla,a,15)

end

function loop(f,n,nxt)
 local e=mke()
 e.upd=f
 e.life=n
 e.nxt=nxt
end



function drop()
 sfx(8)
 local hpx=flr(hero.x/8+.5)
 local hpy=flr(hero.y/8+.5)
 local ob=mk_obj(obj,hpx,hpy)
 hero.busy=true

 if obj==32 then
  if mget(hpx,hpy+1)==110 then
   local e=mke()
   local saving=false
   e.upd=function()
    if saving then
     if e.t>32 then
      kl(e)
      meca=nil
      gem.float=true
      save_state()
      hero.hhp=3
      hero.⧗show_hearts=80
      
      
     end
    else
	    if not gem or obj==32 then
	     kl(e)    
	    elseif hg and not ecole(gem,hero,16) then
	     meca=e
	     saving=true
	     gem.float=false
	     e.t=0
	     sfx(16)
	    end
    end
   end

   e.dr=function()
    if saving then
     local c=e.t/32
     r=(1-sqrt(c))*96
     circ(gem.x+3,gem.y+3,r,11)
    end
   end
   
  end
 end



 obj=nil

end





function use_machete()
 
 hero.⧗sword=8
 hero.⧗frz=8 
 local s=hero.flx and -1 or 1
 local px=flr(hero.x/8+.5)+s
 local py=flr(hero.y/8+.5)
 slash(px,py)
 hero.vy=0
 
 -- check mon
 local mon=nil
 for e in all(ents) do
  if e.hp then
   local dx=e.x-px*8
   local dy=e.y-py*8
   if abs(dx)<8 and abs(dy)<8 then
    hit_mon(e)
    mon=e
   end
  end 
 end
  
 -- push back and sound
 if not mon then
	 if fg(px,py) then
	  sfx(14)
	  glow_til(px,py)
	  hero.⧗lock=4
	  hero.vx=-s*.5
	 else
	  sfx(9)
	 end
 end
 
 --show(px,py)
 
 --
 
 
end

function destroy_mon(e)
 kl(e)
 local s=mke(242,e.x,e.y)
 s.upd=function()
  s.fr=242+s.t/2
  s.we=-.2
  if s.t==8 then
   kl(s)
  end
 end
 
 for i=0,3 do
  local p=mke()
  p.dr=function(e,x,y)
   pset(x,y,15)
  end
  p.life=16+rand(8)
  --p.blk=8
  p.we-=.05+rnd(.15)
  p.x=e.x+rnd(8)
  p.y=e.y+rnd(8)
  p.frict=.95
 
 end
 
end


function hit_mon(e)
 
 e.⧗hit=8
 e.hp-=1 
 if e==cla then
  kill_cla()
  return
 end 
 
 if e.hp<=0 then
  sfx(29)
  destroy_mon(e)
 else
  sfx(28)
  e.hurt()
 end

 
 
end

function kill_cla()
 sfx(27)
 cla.dead=true
 cla.upd=nil
 cla.vx=-2
 cla.frict=.8
 cla.t=0
 cla.dr=function(e,x,y)  
  if cla.t>16 then
   spr(61,x,y)
   spr(3,x-4,y+1)
  else
	  spr(56,x,y)
	  spr(3,x-1,y+e.t/8-5)
  end  
 end 
 mk_hat(116,cla)

end


function fg(px,py,fl)
 return fget(mget(px,py),fl or 0)
end


function use_obj()
 
 if obj==33 then -- flute
  sfx(3)
  dx=hero.x-(39*8)
  dy=hero.y-(23*8)
  local an=atan2(dy,dx)
  for i=0,1 do  
   local index=flr(an*4+i+2.5)%4
   local sn=snakes[1+index]
   move_snake(sn)  
  end
  
  local e=mke(74+rand(2))
  e.x=hero.x
  e.y=hero.y
  e.brd=0
  e.life=24
  e.blk=8
  e.we=-.12
  e.frict=.85
  e.vx=(rand(2)+1)*(hero.flx and -1 or 1)
  
 elseif obj==34 then -- rod
  for e in all(ents) do
   if e.fr==32 then
    e.obj=false
    local f=function()
     kl(e)
     mk_obj(34,flr(hero.x/8),flr(hero.y/8))
     obj=32
     hero.busy=true
    end   
    mvt(e,hero.x,hero.y,-4,f)
   end
  end
 end
end

function grab(e)
 sfx(4) 
 if obj then
  e.fr,obj=obj,e.fr
  if e.fr==32 then
   gem=e
  end
 else
  obj=e.fr 
  kl(e) 
 end  
end


function ecole(a,b,ma) 
 local dx=a.x-b.x
 local dy=a.y-b.y
 return abs(dx)<ma and abs(dy)<ma
end


function dr_hero(e,x,y)
 if not e.wfr then
  e.wfr=0
 end
 local s=e.flx and -1 or 1 
 local dy=e.wfr>=2 and -1 or 0
 
 -- swords
 if e.⧗sword then
  local c=(e.⧗sword/8)^3
  clip(x+s*10-4-cmx,y-cmy,16,8)
  spr(58,x-sin(c/2)*8*s,y,1,1,e.flx)
  clip()  
 end 
 
 -- hands
 local ob=obj
 if e.cla then ob =e.obj end
 if ob then
  local a={0,0,-3,-2}
  local b={0,1,1,1}
  local ddx=b[1+flr(e.wfr)]
  local ddy=a[1+flr(e.wfr)]
  spr(ob,x+s*(3+ddx),y+ddy,1,1,e.flx)
 end
 
 -- body
 local hx=0 
 local bfr=39 
  bfr+=e.wfr
 if not hg and (hl or hr) and e.vy>0 then
  bfr=55
 end
 if e.cla then 
  if e.⧗shoot then
   bfr=57
   hx+=2
  else
	  pal(4,1)
	  pal(13,1)
	 end
 end
 spr(bfr,x,y+dy,1,1,e.flx) 
 pal()
 
 -- head
 local hy=0
 for i=1,4 do
  if not ecol(e,0,hy-1) then  
   hy-=1
  else
   break
  end
 end 
 local hfr=e.dead and 30 or 23
 if e.cla then
  hfr=24
 end 
 if e.⧗talk then
  hy+=(t/4)%2
 end 
 spr(hfr,x+hx+s,y+dy+hy,1,1,e.flx)
  
 -- act
 if action and not e.cla then
  local s="❎:"..action.name
  print(s,x+3-#s*2,flr(y)+sin(t/32)-10.5,15)
 end
  
end


function save_state()
 
 local tls={}
 
 -- scan
 for x=0,16*8 do for y=0,16*4 do
  local tl=mget(x,y)
  if fg(x,y,7) then
   add(tls,{x=x,y=y,tl=tl})
  end
 end end
 
 -- zones
 local function add_zone(x,y,ww,hh)
  for px=x,x+ww-1 do for py=y,y+hh-1 do
   add(tls,{x=px,y=py,tl=mget(px,py)})
  end end
 end
 add_zone(38,20,3,4)
 add_zone(62,24,1,6)
 add_zone(60,14,6,2)
 add_zone(22,7,8,4)
 

 -- build state
 state={
  tls=tls,
  obj={},
  hpx=flr(hero.x/8),
  hpy=flr(hero.y/8),
 }

 -- obj 
 for e in all(ents) do
  if e.obj then
			local o={
			 id=e.fr,
			 x=flr(e.x/8),
			 y=flr(e.y/8)
			}
   add(state.obj,o)
  end
 end
 
 --
 talk("game saved")

end

function talk(s)
 local e=mke(0,hero.x,hero.y-10)
 e.dr=function(e,x,y)
  if t%2==0 then
   print(s,x-#s*2,y,7)
  end
 end
 e.vy=-.25
 e.life=40
end





function mke(fr,x,y)
 local e={
  fr=fr or 0,
  x=x or 0,
  y=y or 0,
  ww=8,hh=8,
  vx=0,vy=0,we=0,t=0,
  frict=1,dp=1,
 }
 
 e.bncx=function()
  e.vx*=-.75
 end 
 e.bncy=function()
  e.vy*=-.75
 end 
 
 add(ents,e)
 return e 
end

function upe(e)
 e.t=e.t+1
 if e.upd then e.upd(e) end
 
 -- fall
 if e.fall then
  if not ecol(e,0,1) then
   e.y+=1
  end
 end
 
 
 -- phys
 e.vx*=e.frict
 e.vy*=e.frict
 e.vy+=e.we
 if e.phys then
  pmov(e,e.vx,e.vy)
 else
  e.x+=e.vx
  e.y+=e.vy 
 end
 
 -- counters
 for v,n in pairs(e) do
  if sub(v,1,1)=="⧗" then
   n-=1
   e[v]= n>0 and n or nil
  end
 end 
 
 -- loop
 if e.lp and gem_active() then
 

  local d=8*wr
 
 
  local ccx=flr(cmx+.5)+64
  local ccy=flr(cmy+.5)+64
 
  local dx=((e.x-ccx)+d)%(d*2)-d
  local dy=((e.y-ccy)+d)%(d*2)-d
  e.x=ccx+dx
  e.y=ccy+dy 
 end
 
 --  tweens
 if e.twc then
  local c=min(e.twc+1/e.tws,1)
  cc=e.twcv and e.twcv(c) or c
  e.x=e.sx+(e.ex-e.sx)*cc
  e.y=e.sy+(e.ey-e.sy)*cc
  if e.jmp then
   e.y+=sin(c/2)*e.jmp
  end  
  e.twc=c  
  if c==1 then
   e.twc=nil
   e.jmp=nil
   e.twcv=nil
   local f=e.twf
   if f then
    e.twf=nil
    f()
   end
  end
 end 
 
 -- life
 if e.life then
  e.life-=1
  if e.blk and e.life<=e.blk then
   e.invis=e.life%4<2
  end
  if e.life<=0 then kl(e) end
 end 
end

function mv(e,dx,dy,n,f)
 mvt(e,e.x+dx,e.y+dy,n,f)
end
function mvt(e,tx,ty,n,f)
 e.sx=e.x
 e.sy=e.y
 e.ex=tx
 e.ey=ty
 e.twc=0
 e.tws=n
 e.twf=f  
 if n<0 then
  dx=e.ex-e.sx
  dy=e.ey-e.sy
  e.tws=-sqrt(dx^2+dy^2)/n
 end
end


function dre(e)

 if e.invis or e.dp!=dp or (e.⧗hurt and t%2==0) then
  return
 end

 local fr=e.fr
 local x=e.x
 local y=e.y 
 
 if e.float then
  y+=.5+sin(t/40)
 end
 if e.leaf then
  x+=.5+sin(e.t/16)*2
 end
 if e.alp then
  fr=fr+(t/4)%4
 end 
 
 if e.taint then
  apal(e.taint)
 end
 
 if e.⧗hit and t%4<2 then
  apal(11)
 end
 
 
 
 local dr=function(e,x,y)
	 if fr>0 then
	  spr(fr,x,y,e.ww/8,e.hh/8,e.flx)
	 end 
	 if e.dr then
	  e.dr(e,x,y)
	 end
 end
 
 dr(e,x,y)
 
 
 
 -- post
 if e.brd then
  
  brd_b(function(x,y) dr(e,x,y) end,x,y)
 end
 
 
 if e.lp and gem_active() then
  for dx=-1,1 do for dy=-1,1 do
   dr(e,x+dx*128,y+dy*128)
  end end 
 end
 
 
 pal()
 
end


function pmov(e,vx,vy)
 
 if ecol(e) then
  return
 end
 

 e.x+=vx
 while ecol(e) do
  e.x-=sgn(vx) 
		e.bncx(e)  
 end
 
 e.y+=vy
 while ecol(e) do
  e.y-=sgn(vy)  
		e.bncy(e)
 end 

end

function ecol(e,dx,dy)
 local f=pcol
 if e==hero and gem_active() then
	 f=lpcol
 end


 act=e
 f=f or pcol 
 dx = dx or 0
 dy = dy or 0 
 local a={0,0,0,1,1,1,1,0}
 for i=0,3 do
  local x=e.x+a[i*2+1]*(e.ww-1)+dx
  local y=e.y+a[i*2+2]*(e.hh-1)+dy
  if f(x,y,i) then 
   return true 
  end
 end
 return false
end

function pcol(x,y)
 if x<0 or y<0 or x>=128*8 or y>48*8 then
  return true
 end

 local res=mcol(x/8,y/8)
 if res then
  cpx=flr(x/8)
  cpy=flr(y/8)
 end
 return res
end

function lpcol(x,y)
 local px=flr(x/8)
 local py=flr(y/8)
 local gx=flr(cmx/8+.5)
 local gy=flr(cmy/8+.5) 
 local dx=(px-gx)%16
 local dy=(py-gy)%16
 return pcol((gx+dx)*8,(gy+dy)*8) 
 
 
 
 --[[
 local px=flr(x/8)
 local py=flr(y/8)
 local gx=flr((cmx+60)/8)
 local gy=flr((cmy+60)/8) 
 local dx=px-gx
 local dy=py-gy 
 if dx>=wr then
  return pcol(x,y) or pcol(x-16*wr,y)
 elseif dx<=-wr then
  return pcol(x,y) or pcol(x+16*wr,y)
 elseif dy>=wr then
  return pcol(x,y) or pcol(x,y-16*wr)
 elseif dy<=-wr then
  return pcol(x,y) or pcol(x,y+16*wr)
 else
  return pcol(x,y) 
 end
 --]]

end



function mcol(x,y,fl)
 fl=fl or 0
 return y>=64 or fget(mget(x,y),fl)
end


function impulse(e,an,spd)
 e.vx+=cos(an)*spd
 e.vy+=sin(an)*spd
end

function head_bump(x,y)

 slash(x,y)

 --[[
 if fget(mget(x,y),2) then
  mset(x,y,0)
  sfx(6)
  for i=0,3 do
   local e=mke(14,x*8+4,y*8+4)
   impulse(e,.125+i/4,1.5)
   e.vy-=2
   e.we=.2+rnd(.2)
   e.frict=.97
   e.life=16
   e.blk=8   
  end
  slash(x,y-1)
  return true
 end
 return false
 --]]
end


function slash(x,y)

 -- herb
 if fg(x,y,4) then
  mset(x,y,1)
  for i=0,3 do
   local e=mke(45,x*8+4,y*8+4)
   impulse(e,.125+i/4,1)
   e.vy-=2+rnd(2)
   e.we=.1+rnd(.1)
   e.frict=.97
   e.life=16+rand(16)
   e.blk=8  
   e.t=rand(128)
   e.leaf=true 
   e.flx=i%2==0
  end  
 end
 
 -- stone / dirt
 if fg(x,y,2) then  
  sfx(6)
  for i=0,3 do
   local e=mke(14,x*8+4,y*8+4)
   impulse(e,.125+i/4,1.5)
   e.vy-=2
   e.we=.2+rnd(.2)
   e.frict=.97
   e.life=16
   e.blk=8
   if fg(x,y,6) then
    e.taint=4
   end     
  end
  mset(x,y,1) 
  
 end
 
end

function rand(n)
 return flr(rnd(n))
end

function lever(px,py)
 action=nil

 local on=mget(px,py)-26
 mset(px,py,27-on)
 sfx(1)
 
 -- first door
 if px==39 then
  open_first_door()
 end
 
 
 --
 if px==25 then
  switch(38,13,3,2)
 end 
 
 -- double lever center
 if px==37 then
  switch(38,22)
 end
 if px==41 then
  switch(40,22)
 end
 
 -- block lever
 if px==45 then
  for k=0,1 do
   for x=36+k*5,37+k*5 do for y=17,18 do
    switch(x,y)
   end end  
  end
  for sn in all(snakes) do
   sn_look(sn)
  end   
 end 
 
 -- save door
 if px==21 then
  switch(24,24,1,2)
 end
 
 -- big door
 if px==12 then
  switch(14,35,1,2)
 end 
 
 -- step west
 if px==19 then  
  switch(13,30,2,2)
  switch(14,39,2,2) 
  switch(16,43,2,2) 
  switch(20,45,2,2)   
 end
 
 --
 if px==32 then
  switch(36,28,2,2)
  switch(41,27,2,2)
 end
 
 -- code
 if px>=51 and px<=58 then
  local py=mget(65,28)==27 and 24 or 25
  cycle(px,py)
 end
 
 --[[
 if px==70 then
  switch(66,41,2,2)
 end
 --]]
 
 if px==75 then
  switch(73,34,2)
  switch(78,35,1,3)
  switch(82,35,1,3)
 end
 
 if px==78 then
  switch(70,26,2)
  switch(76,25,2)
 end
 
 if px==81 then
  switch(76,30,3,4)
 end
 

end


function cycle(x,y)
 local tl=mget(x,y)
 if tl!=6 then
  mset(x,y,6)
 else
  tl=96+((x-51)%3)+(y-24)*16
  mset(x,y,tl)
 end

end


function switch(x,y,sx,sy)
 shk=3
 sx=sx or 1
 sy=sy or 1
 for px=x,x+sx-1 do for py=y,y+sy-1 do
	 local tl=mget(px,py)
	 local solid=fget(tl,0)
	 tl=tl+( solid and 16 or -16)
	 mset(px,py,tl)	 
	 if not solid then
	  dust(px,py,13,2)
	 end
 end end  
end

function dust(px,py,cl,m)
 for i=0,m-1 do
  local e=mke(0,px*8+rnd(8),py*8+rnd(y))
  e.dr=function(e,x,y)
   pset(x,y,cl or 13)
  end
  e.brd=0
  e.we=.05+rnd(.1)
  e.frict=.95
  e.life=16+rand(16)  
 end
 
end


function gem_active()
 return gem and obj!= 32
end

function chk_trigs()
 
 -- reveal gem
 if mget(37,22)==26 and mget(41,22)==26 then
  reveal_gem()  
 end 
 
 -- snakes
 if mget(38,20)==54 and chk_snakes() then
  free_gem()  
 end
 
 -- code
 if mget(62,29)==69 then
	 local seek={0,0,1,0,0,1,1,0,1,1,0,0}
	 local ok=0
	 for i=0,11 do
	  local x,y=gcp(i)
	  local tl=mget(x,y)
	  local sk=seek[i+1]
	  if (tl==6 and sk==1) or (tl!=6 and sk==0) then
	   ok+=1
	  end 
	 end
	 if ok==12 then
	  open_code_door()
	 end
 end
 
 -- hidden room
 if (mget(30,8)!=48 or mget(30,9)!=48 ) and mget(29,8)==16 then
  sfx(26)
  copy_zone(0,3,8,4,22,7) 
 end

 
 --
 if dev and btnp(4,1) then
  --free_gem()
  sfx(54)
  init_game()
 end
 
end

function copy_zone(x,y,w,h,tx,ty)
 for dx=0,w-1 do for dy=0,h-1 do
  mset(tx+dx,ty+dy,mget(x+dx,y+dy))
 end end 
end


function gcp(i)
  local x=51+(i%6)
  if x>52 then x+=1 end
  if x>55 then x+=1 end
  return x,24+flr(i/6)
end


function glow_tile(x,y,cl)
 add(gtl,{x=x,y=y,cl=cl or 15})

end

function glow_til(x,y,t,cl)
 local e=mke(mget(x,y),x*8,y*8)
 e.life=t or 4
 e.taint=cl or 15
 return e
end

function open_first_door()
 force_cam(54,7) 
 mset(39,3,6)
 
 local k=0 
 meca=mke()
 meca.upd=function(mc)
  if k<6 and mc.t>32 and mc.t%16==0 then
   sfx(13)
   shk=4
   local x=64-flr(k/2)*2 
   local y=15-(k%2)
   mset(x,y,1)
   --dust(x,y,13,2)
   k+=1
  end
  if mc.t>160 then
   kl(mc)
   meca=nil
   fcam=nil
  end  
 end
 
 
 
end

function force_cam(x,y)
 fcam={x=x*8,y=y*8}
end

function open_code_door()
 force_cam(49,22) 
 sfx(7)
 meca=mke()
 local py=29
 meca.upd=function(mc)
  if mc.t<40 then
   for i=0,11 do
	   local x,y=gcp(i)
	   glow_tile(x,y,11)
   end
  elseif mc.t%8==0 then
   mset(62,py,0)
   mset(62,py-3,69)
   shk=4
   py-=1
   if py==26 then
    kl(meca)
    meca=nil
    fcam=nil
    for x=51,58 do
     if x%3!=2 then
      mset(x,28,6)
     end
    end
   end  
    sfx(1,nil,3)  
  end 
 
 end

end



function apal(n)
 for i=0,15 do pal(i,n) end
end


function hide_snakes()

 if t%10==0 then
  for sn in all(snakes) do
   sn.s=1
   move_snake(sn)  
  end
  if #snakes==0 then
   kl(meca)
   meca=nil
  end
    
 end

end

function free_gem()
 
 sfx(7)
 local py=23
 meca=mke()
 meca.upd=function(mc)  
  if mc.t>40 and t%10==0 then
   if py==19 then
    meca.dr=nil
    meca.upd=hide_snakes
    return
   end
   sfx(2)
   mset(38,py,0)
   mset(40,py,0)
   py-=1
  end  
 end
 
 meca.dr=function() 
  if t%4<2 then
   for sn in all(snakes) do
    local tl=mget(sn.gzx,sn.y)
    apal(15)
    spr(tl,sn.gzx*8,sn.y*8)
    pal()
   end     
  end 
 end
 

end




function chk_snakes()
 local gaze=nil
 for sn in all(snakes) do
  if gaze then
   if gaze!=sn.gaze then
    return false
   end
  else
   gaze=sn.gaze
  end
 end 
 return true
end



function reveal_gem()
 
 meca=mke()
	local py=20
	local usn=0
 meca.upd=function(e)
  if e.t%16==0 then    
   if usn>0 then
    usn-=1
    foreach(snakes,move_snake)
    if usn==0 then
     kl(e)
     meca=nil     
    end
    return
   end    
   sfx(2)
   for px=38,40 do
    mset(px,py,px==39 and 0 or 54)
   end
   py+=1
   shk=4
   if py==24 then 
    sfx(15)
    mk_obj(33,34,18)
    mk_obj(32,39,23)
    mk_snake(31,21,17,0)          
    mk_snake(46,21,17,1)            
    mk_snake(46,29,24,1)  
    mk_snake(31,29,24,0)        
    mset(37,22,6)
    mset(41,22,6)
    usn=4
   end    
  end
 end   
end

function mk_obj(fr,x,y)
 local e=mke(fr,x*8,y*8)
 e.float=true
 e.obj=true
 if fr==32 then
  gem=e
 end
end


function mk_snake(x,y,my,lk)
 local snk={lk=lk,x=x,y=y,s=-1,by=y,my=my}
 add(snakes,snk)
end


function move_snake(sn) 
 if sn==nil then
  return
 end
 
 
 sn.y+=sn.s
  
 -- clean
 for y=sn.my,sn.by-1 do
  mset(sn.x,y,0)
 end 
 
 --
 if sn.y==sn.by then
  del(snakes,sn)
  return
 end
 
 -- move
 if pcol(sn.x*8,(sn.y+sn.s)*8) then
  sn.s*=-1
 end
 
 -- draw
 for dy=1,10 do
  local y=sn.by-dy
  if y==sn.y then
   mset(sn.x,y,19+sn.lk)
  elseif y>sn.y then
   mset(sn.x,y,35)
  end
 end
 
 -- look
 sn_look(sn)
 
 
end

function sn_look(sn)
 local s=1-sn.lk*2
 sn.gaze=-1
 for i=1,32 do  
  sn.gzx=sn.x+i*s
  local tl=mget(sn.gzx,sn.y)
  if fget(tl,0) then
   sn.gaze=tl   
   break
  end  
 end
end


function kl(e)
 del(ents,e)
 if e.nxt then
  local f=e.nxt
  e.nxt=nil
  f()
 end
end



function _update()
 t=t+1 
 upd()
end


function dr_game()
 -- camera
 set_camera()
 
 -- behind
 dp=0
 foreach(ents,dre) 
 
 -- map
 map(0,0,0,0,16*8,16*4)
 
 -- gtl
 if t%4==0 then	 
	 for g in all(gtl) do
	  apal(g.cl)
	  local tl=mget(g.x,g.y)
	  spr(tl,g.x*8,g.y*8) 
	 end
	 pal()
 end
 
 -- ents
 dp=1
 foreach(ents,dre) 
 -- inter
 camera()
 if hero.⧗show_hearts then
 
  local c=hero.⧗show_hearts/80
  local dy=min(-sin(c/2)*4,1)
  local y=128-dy*8
  rectfill(52,y-1,75,y+7,0)
  rectfill(43,y+7,84,y+7,0)
  apal(0)
  for i=0,1 do
   spr(94,44+32*i,y-1,1,1,i==1)
  end
  pal()
  for i=0,2 do
   local fr=hero.hhp>i and 241 or 240
   if hero.hhp==i and hero.⧗hurt then
    fr=240+(t/4)%2
   end   
   spr(fr,64+i*8-12,y)
  end 
  
  
  
 end
 
 
 -- inro
 if intro then
  dr_intro()
 end

 
 --
 
end

function _draw()
 cls() 
 
 mdr()



 -- log 
 color(7)
 cursor(0,0)
 for str in all(logs) do
  print(str)
 end 
 
 -- fade
 if fd>0 then
 
  for i=0,15 do 
   pal(i,sget(112+i,32+fd),1)
  end
 end  
 
end

function set_camera()



 local ctx=hero.x-60
 local cty=hero.y-60
 if fcam then
  ctx=fcam.x
  cty=fcam.y
 elseif gem_active() then
  ctx=gem.x-64
  cty=gem.y-64  
	end	
	
	ctx=mid(0,ctx,128*7)
	cty=mid(0,cty,128*2)
 if not cmx then
  cmx=ctx
  cmy=cty
 else
		cmx+=(ctx-cmx)*.15
		cmy+=(cty-cmy)*.15
 end 

	
	
 camera(cmx,cmy+shk)
  

 if shk!=0 then
  shk=-sgn(shk)*(abs(shk)-1)
 end 
  
end

-->8

function log(str)
	add(logs,str)
	while #logs>20 do
	 del(logs,logs[1])
	end
end
-->8
-- dev

function show(px,py)
 local e=mke(0,px*8,py*8)
 e.life=8
 e.dr=function(e,x,y)
  rect(x,y,x+7,y+7,8)
 end
end
-->8
-- hints


-- let your spirit wander on the third step 
