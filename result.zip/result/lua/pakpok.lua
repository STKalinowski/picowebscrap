--pakpok
--by st33d

--Utils

--globals

--flags
f_player = shl(1, 0)--us
f_wall = shl(1, 1)--hard surface
f_trap = shl(1, 2)--area we scan for ids
f_ledge = shl(1, 3)--hard surface only when going down
f_crate = shl(1, 4)--pushable box, causes bugs
f_puck = shl(1, 5)--kickable box
f_stop = shl(1, 6)--stops crates
--pico 8 doesn't use flags this high, so it works for out-of-bounds
f_outside = shl(1, 8)
--everything except crates ignores these
f_trapstop = bor(f_trap,f_stop)

--physical objects
blokmap = {x=0,y=0,w=16,h=16}--defines room boundaries
dropdamp = 0.98--default falling friction
grav = 0.37--set g on a blok to simulate gravity
minmove = 0.1--avoid micro-sliding, floating point error can lead to phasing
poppwr = 5.6--power of pop-jump

us = nil--the player

levels={
  {x=0,y=32,w=16,h=32},--intro - 1
  {x=0,y=16,w=16,h=16},--spikes - 2
  {x=16,y=0,w=16,h=32},--crumble,slabs - 3
  {x=32,y=16,w=16,h=48},--gliding - 4
  {x=16,y=32,w=16,h=32},--poppa - 5
  {x=32,y=0,w=16,h=16},--crate - 6
  {x=64,y=48,w=16,h=16},--spittas - 7
  {x=64,y=16,w=16,h=32},--poppa tight - 8
  {x=48,y=32,w=16,h=32},--spitta skills - 9
  {x=64,y=0,w=16,h=16},--crate skills - 10
  {x=48,y=0,w=16,h=32},--fast slabs - 11
  {x=128-16,y=48,w=16,h=16}--end - 10
  ,{x=0,y=0,w=16,h=16}--test
}


--add to print out debug
debug = {}
-- the coordinates of the upper left corner of the camera
cam_x,cam_y = 0,0
backcol=12
frames=0
fadep=1
transition=nil--screen fade transition
level=1
--level=#levels

-- screen shake offset
shkx,shky = 0,0
-- screen shake speed
shkdelay,shkxt,shkyt=2,2,2

-- based on https://github.com/jonstoler/class.lua
-- i removed the getter setters, no idea if that
-- broke it but it seems to still work
classdef = {}

-- default (empty) constructor
function classdef:init(...) end

-- create a subclass
function classdef:extend(obj)
  local obj = obj or {}
  local function copytable(table, destination)
    local table = table or {}
    local result = destination or {}
    for k, v in pairs(table) do
      if not result[k] then
        if type(v) == "table" and k ~= "__index" and k ~= "__newindex" then
          result[k] = copytable(v)
        else
          result[k] = v
        end
      end
    end
    return result
  end
  copytable(self, obj)
  obj._ = obj._ or {}
  local mt = {}
  -- create new objects directly, like o = object()
  mt.__call = function(self, ...)
    return self:new(...)
  end
  setmetatable(obj, mt)
  return obj
end

-- create an instance of an object with constructor parameters
function classdef:new(...)
  local obj = self:extend({})
  if obj.init then obj:init(...) end
  return obj
end

function class(attr)
  attr = attr or {}
  return classdef:extend(attr)
end



-- for when you need to send a list of stuff to print
function joinstr(...)
  local args = {...}
  local s = ""
  for i in all(args) do
    if type(i)=="boolean" then
      i = i and "true" or "false"
    end
    if s == "" then
      s = i
    else
      s = s..","..i
    end
  end
  return s
end

function pick1(a,b)
  if rnd(2)>1 then
    return a
  end
  return b
end

--print to debug
function debugp(...)
  add(debug,joinstr(...))
end

function add2(obj, ...)
  local args = {...}
  for table in all(args) do
    add(table, obj)
  end
end

-- method is a function(c,r)
function forinrect(x,y,w,h,method)
  for c=x,(x+w)-1 do
    for r=y,(y+h)-1 do
      method(c,r)
    end
  end
end

function fadepal(_perc)
  local p=flr(mid(0,_perc,1)*100)
  local kmax,col,dpal,j,k
  dpal={0,1,1, 2,1,13,6,
           4,4,9,3, 13,1,13,14}
  for j=1,15 do
   col = j
   kmax=(p+(j*1.46))/22
   for k=1,kmax do
    col=dpal[col]
   end
   if j==12 then backcol=col end--set background col
   pal(j,col)
  end
 end


--transitions
transit=class()

function transit:init(swap,delay)
  self.active,self.dir,self.swap,self.delay,self.t=true,1,swap,delay,0
end

function transit:upd()
  self.t+=self.dir
  if self.t==self.delay then
    self.swap()
    self.dir=-1
  elseif self.t==0 then
    self.active=false
  end
  fadepal(1/self.delay*self.t)
end

--Game
--init----------------------
function _init()
  createlevel(level)
  transition=transit(nil,30)
  transition.dir,transition.t=-1,30--fade in
end

function createlevel(n)
  --setting lists in here for efficient reset
  blox = {}--physics list
  chkpnts = {}--checkpoints
  spikes={}--spike shine
  airspikes={}--air spike shine
  --gfx
  effects={}
  mideffects={}
  backeffects={}
  levelnum=nil
  
  blokmap=levels[n]
  --look for map sprites we can convert to a blok
  local function create(c,r,sp)
    sp = sp or mget(c,r)
    local b = nil
    if sp == 1 then
      mset(c,r,0)
      us = player(c,r)
      b=us
    elseif sp >= 4 and sp <= 7 then
      mset(c,r,0)
      b=slab(c,r,sp)
    elseif sp == 38 or sp==39 then
      mset(c,r,0)
      b=slab(c,r,sp)
    elseif sp == 12 or sp==44 then
      if sp==44 then
        sp=12
        mset(c,r,24)--spikes behind crate
        add(spikes,{x=c*8,y=r*8})
      else mset(c,r,0) end
      --crate
      b=blok(c*8,r*8,8,8,f_crate,bor(f_trap,f_ledge),sp)
      b.pushmask,b.g,b.dy = bor(f_crate,f_player),grav,dropdamp
      b.momignore=f_trap
    elseif sp == 16 then
      b=puck(c,r,sp)
    elseif sp == 56 then
      b=poppa(c,r,sp)
    elseif sp == 19 or sp==20 then
      mset(c,r,0)
      b=spitta(c,r,sp)
    elseif sp == 26 then
      mset(c,r,0)
      add(chkpnts,chkpnt(c,r))
    elseif sp==24 then
      add(spikes,{x=c*8,y=r*8})
    elseif sp==28 then
      add(airspikes,{x=c*8,y=r*8})
    elseif not levelnum and sp==63 then
      levelnum={x=c*8,y=r*8}
    end
    if b then
      add(blox,b)
    end
  end
  forinrect(blokmap.x,blokmap.y,blokmap.w,blokmap.h,create)
  cam_x,cam_y=us:cam()
  
  flrsharps=sharps(spikes,{99,99,100,100,100,101,101,101,101,102,102,103,103})
  airsharps=sharps(airspikes,{88,88,88,104,104,104,104,105,105,106,106,107,107})
  
end

--update----------------------
function _update()
  
  if transition then return end
  
  -- clear colision data
  for a in all(blox) do
    a.touchx,a.touchy = nil,nil
  end
  
  -- simulate
  if(us.active)us:upd()--player 1st for feels
  
  --update checkpoints
  for c in all(chkpnts) do
    c:upd()
  end
  
  for a in all(blox) do
    if(a ~= us and a.active) a:upd()
  end
  
  -- garbage collect
  local good,i = {},1
  for a in all(blox) do
    if a.active then
      good[i] = a
      i += 1
    end
  end
  blox=good
  
  frames+=1
  
end

--draw----------------------
function _draw()
  
  if transition then
    transition:upd()
    if not transition.active then
      transition=nil
      showlevelnum=128
    end
  end
  
  cls(backcol)
  
  -- update camera position
  local x,y = us:cam()
  local f = 0.25
  local scroll_x,scroll_y = (x-cam_x)*f,(y-cam_y)*f
  cam_x += scroll_x
  cam_y += scroll_y
  
  local cx,cy=cam_x+shkx, cam_y+shky
  camera(cx,cy)
  -- cloud lines
  rectfill(cx,cy,cx+127,cy+4,7)
  rectfill(cx,cy+6,cx+127,cy+9,7)
  rectfill(cx,cy+12,cx+127,cy+13,7)
  rectfill(cx,cy+17,cx+127,cy+17,7)
  
  -- draw map
  backeffects=draw_active(backeffects)
  x,y = blokmap.x*8,blokmap.y*8
  
  for c in all(chkpnts) do
    c:draw()
  end
  
  map(blokmap.x,blokmap.y,x,y,blokmap.w,blokmap.h)
  --draw the level number if present
  if levelnum then
    local lvls=#levels-2
    local s = (level<10 and "0"..level or ""..level).."/"..(lvls<10 and "0"..lvls or ""..lvls)
    print(s,levelnum.x+2,levelnum.y+2,1)
    print(s,levelnum.x+1,levelnum.y+1,4)
  end
  flrsharps:draw()
  airsharps:draw()
  --draw a rect of ground under map for screenshake to see
  y += blokmap.h*8
  rectfill(x,y,x+blokmap.w*8,y+8,5)
  mideffects=draw_active(mideffects)
  -- draw blox
  for a in all(blox) do
    if a.active then
      if(a~=us)a:draw()
      --a:drawdbg()
    end
  end
  if(us.active)us:draw()
  
  effects=draw_active(effects)
  
  --update screen shake
  if shkxt > 0 then
    shkxt-=1
    if shkxt == 0 then
      local sn = sgn(shkx)
      if sn > 0 then
        shkx = -shkx
      else
        shkx= -(shkx+1)
      end
      shkxt=shkdelay
    end
  end
  if shkyt > 0 then
    shkyt-=1
    if shkyt == 0 then
      local sn = sgn(shky)
      if sn > 0 then
        shky = -shky
      else
        shky= -(shky+1)
      end
      shkyt=shkdelay
    end
  end
  
  -- print out values added to debug
  pal()
  local total,ty,good=#debug,0,{}
  for i=1,total do
    local s = debug[i]
    print(s,1+cam_x,1+cam_y+ty,0)
    ty += 8
    if(i > total-15) add(good, s)
  end
  debug = good
  
end

-- set screen shake
function shake(x,y)
  if(abs(x)>abs(shkx)) shkx,shkxt=x,shkdelay+1
  if(abs(y)>abs(shky)) shky,shkyt=y,shkdelay+1
end

-- garbage collect drawings on the fly
function draw_active(table)
  local good,i = {},1
  for a in all(table) do
    if a.active then
      a:draw()
      good[i] = a
      i += 1
    end
  end
  return good
end




--Engine
-- aabb recursive moving entity
blok = class()
blokn = 0--track instances of blok for debugging

-- x,y,w,h: bounds
-- flag: a pico 8 map flag
-- ignore: flags we want this blok to ignore
-- sp: sprite
function blok:init(x,y,w,h,flag,ignore,sp)
  self.active,self.x,self.y,self.w,self.h,self.flag,self.ignore,self.sp=
    true,x or 0,y or 0,w or 8,h or 8,flag or 0,ignore or 0,sp or 1
  self.vx,self.vy,self.dx,self.dy,self.touchx,self.touchy=
    0,0,0,0,nil,nil
  self.flipx,self.flipy=false,false
  self.pushmask,self.crushmask,self.momignore = 0,0,nil
  --parent and child carrying, mom and kids
  self.mom,self.kids,self.g = nil,{},0
  blokn+=1
  self.n=blokn
end

--update
function blok:upd()
  --move x, then y, allowing us to slide off walls
  --avoid micro-sliding, floating point error can cause phasing
  if abs(self.vx) > 0.1 then
    self:movex(self.vx)
  end
  if abs(self.vy) > 0.1 then
    self:movey(self.vy)
  end
  --apply damping
  self.vx*=self.dx
  self.vy*=self.dy
  --fall
  if abs(self.g)~=0 then
    if not self.mom then
      self.vy+=self.g
    else
      local m=self.mom
      --check mom is still there
      if not m.movex then
        if mget(m.x/8,m.y/8)~=m.sp then
          self.mom=nil
        end
      end
    end
  end
end

function blok:movex(v)
  local x,y,w,h = self.x,self.y,self.w,self.h
  local edge,obstacles = v>0 and x+w or x,{}
  if v>0 then
    obstacles=getobstacles(x+w,y,v,h,self.ignore,self)
    sort(obstacles,rightwards)
  elseif v<0 then
    obstacles=getobstacles(x+v,y,abs(v),h,self.ignore,self)
    sort(obstacles,leftwards)
  end
  if #obstacles>0 then
    for ob in all(obstacles) do
      local obedge=v>0 and ob.x or ob.x+ob.w
      --break if v reduced to no overlap
      if (v>0 and obedge > edge+v) or (v<0 and obedge < edge+v) then break end
      local shdmove = (edge+v)-obedge--how far should it move?
      self.touchx=ob
      --push?
      if band(ob.flag, self.pushmask)>0 and ob.movex then
        local moved,crush=ob:movex(shdmove),band(ob.flag,self.crushmask)>0
        if abs(moved) < abs(shdmove) then
          if crush then--won't budge, destroy?
            if ob.death then ob:death(self) end
          else v -= shdmove-moved end
        end
      else
        v -= shdmove
      end
      --quit or shdmove will work in reverse
      if(abs(v)<000.1)break
    end
  end
  
  self.x+=v
  
  --have i lost a parent?
  if self.mom then
    local p=self.mom
    if self.x>=p.x+p.w or self.x+self.w<=p.x then
      if p.delkid then
        p:delkid(self)
      else self.mom = nil end
    end
  end
  
  --move children
  if #self.kids>0 then
    local kids=self.kids
    if v>0 then
      for i=#kids,1,-1 do
        kids[i]:movex(v)
      end
    elseif v<0 then
      for i=1,#kids do
        kids[i]:movex(v)
      end
    end
  end
  
  return v
end

--jumping up thru ledges and moving plaforms
--makes this bit very hacky
function blok:movey(v)
  local x,y,w,h = self.x,self.y,self.w,self.h
  local edge,obstacles = v>0 and y+h or y,{}
  if v>0 then
    --ledge landing hack when moving down
    obstacles=getobstacles(x,y+h,w,v,self.momignore or self.ignore,self)
    sort(obstacles,downwards)
  elseif v<0 then
    obstacles=getobstacles(x,y+v,w,abs(v),self.ignore,self)
    sort(obstacles,upwards)
  end
  if #obstacles>0 then
    for ob in all(obstacles) do
      local obedge=v>0 and ob.y or ob.y+ob.h
      --break if v reduced to no overlap
      if (v>0 and obedge > edge+v) or (v<0 and obedge < edge+v) then break end
      --how far should it move?
      local shdmove,skip = (edge+v)-obedge,false
      --is there a special rule for landing on it?
      if v>0 and self.momignore then
        --skip this block if we were below its top
        if y+h>ob.y then skip=true end
      end
      if not skip then
        self.touchy=ob
        local moved,crush=0,band(ob.flag,self.crushmask)>0
        --push?
        if band(ob.flag, self.pushmask)>0 and ob.movey then
          
          moved=ob:movey(shdmove)
          
          --add to children if slower than us
          if v<0 and v<ob.vy and ob.mom ~= self then
            self:addkid(ob)
          end
          if abs(moved) < abs(shdmove) then
            --crush
            if crush then--won't budge, destroy?
              if ob.death then ob:death(self) end
            else
              v -= shdmove-moved
            end
          end
        else v -= shdmove end
        
        --let's say if i can't crush it, it's floor
        if shdmove > 0 and not crush then
          if self.mom then self:delmom() end
          if ob.addkid then ob:addkid(self)
          else
            self.mom=ob
            self.vy=0--cancel velocity
          end
        end
        
        --quit or shdmove will work in reverse
        if(abs(v)<000.1)break
      end
    end
  end
  
  self.y+=v
  
  --have i lost a parent?
  if self.mom then
    if self.y+self.h<self.mom.y then
      self:delmom()
    end
  end
  --move children down? (up is handled by push)
  if v>0 and #self.kids>0 then
    for b in all(self.kids) do
      if b.active then b:movey(v) end
    end
  end
  
  return v
end

function blok:addkid(b)
  if b.mom then b:delmom() end
  b.mom = self
  b.vy = 0
  add(self.kids, b)
  --need to sort children so they're moved without colliding
  sort(self.kids, rightwards)
end

function blok:delkid(b)
  b.mom = nil
  del(self.kids, b)
end

--check there is a parent before calling this
function blok:delmom()
  if self.mom.delkid then self.mom:delkid(self)
  else self.mom = nil end
end

-- clear parent and children - usually called during death()
function blok:divorce()
  if self.mom then self:delmom() end
  for b in all(self.kids) do
    b.mom,b.vy = nil,0
  end
  self.kids = {}
end

function blok:jmp(p)
  self:divorce()
  local s = -p*0.8--magic jumping ratio that i accidentally got stuck on
  self.vy=s
  self.dy=dropdamp
end

function blok:center()
  return self.x+self.w*0.5,self.y+self.h*0.5
end

function blok:intersectsblok(a)
  return not (a.x>=self.x+self.w or a.y>=self.y+self.h or self.x>=a.x+a.w or self.y>=a.y+a.h)
end

function blok:intersects(x,y,w,h)
  return not (x>=self.x+self.w or y>=self.y+self.h or self.x>=x+w or self.y>=y+h)
end

function blok:contains(x,y)
  return x>=self.x and y>=self.y and x<self.x+self.w and y<self.y+self.h
end

function blok:within(x)
  return x>=self.x and x<self.x+self.w
end


--this fails at long distance
--the overflow causes 0,0,0 to be returned, watch for it
function blok:normalto(bx,by)
  local ax,ay = self:center()
  local vx,vy = (bx-ax),(by-ay)
  local len = sqrt(vx*vx+vy*vy)
  if(len > 0) return vx/len,vy/len,len
  return 0,0,0
end

--x,y:position or x is an blok, v:speed, d:damping
function blok:moveto(x,y,v,d)
  local tx,ty,len = self:normalto(x,y)
  if(v > len) v = len
  self.vx,self.vy,self.dx,self.dy = tx*v,ty*v,d,d
end

--check for traps
function blok:trapchk()
  local traps = mapobjects(self.x,self.y,self.w,self.h,bnot(f_trap))
  local endgame = false
  if #traps > 0 then
    -- found traps
    for t in all(traps) do
      local c,r,s = flr(t.x/8),flr(t.y/8),t.sp
      -- floor spikes?
      if s==24 then
        --hit when going down
        if self.y+self.h > t.y+2 and self.y+self.h<=t.y+t.h and blok.within(t,self.x+self.w/2) and
          (self.vy>grav*2 or (self.y+self.h < t.y+t.h-2 and self.vy>0))
        then
          self:death(t)
        end
      -- air spikes?
      elseif s==28 then
        --be nice
        if blok.contains(t,self:center()) then
          self:death(t)
        end
      end
      if not self.active then break end
    end
  end
end

function blok:death(src)--source of death
  self:divorce()
  self.active=false
end

function blok:drawdbg()
  rect(self.x,self.y,self.x+self.w-1,self.y+self.h-1,3)
 if self.mom then
   local m=self.mom
   line(self.x+self.w/2,self.y+self.h/2,m.x+m.w/2,m.y+m.h/2,3)
 end
 print(self.n,self.x,self.y-8,7)
end

function blok:dustx()
  dust((self.flipx and self.x+self.w or self.x),
          self.y+self.h/2+rnd(self.h/2),
          2,pick1(6,7))
end
 
function blok:dusty()
  dust(self.x+self.w/2,self.y+self.h,2,pick1(6,7))
end

function blok:updanim()
  self.anim:draw()
  if not self.anim.active then self.anim=nil end
end

function blok:draw(sp,offx,offy)
  sp,offx,offy = sp or self.sp,offx or -4,offy or -4
  local x,y=offx+self.x+self.w*0.5,offy+self.y+self.h*0.5
  spr(sp,x,y,1,1,self.flipx,self.flipy)
end

-- collision utils

function centertile(c,r,w,h)
  w,h = (w or 0),(h or 0)
  return (4+c*8)-w*0.5,(4+r*8)-h*0.5
end

function lookblokx(x,y,w,h,v,source)
  for b in all(blox) do
    if b~=source and ((v>0 and b:intersects(x+w,y,v,h)) or
      (v<0 and b:intersects(x+v,y,abs(v),h))) then
      return b
    end
  end
  return nil
end

function lookbloky(x,y,w,h,v,source)
  for b in all(blox) do
    if b~=source and ((v>0 and b:intersects(x,y+h,w,v)) or
      (v<0 and b:intersects(x,y+v,w,abs(v)))) then
      return b
    end
  end
  return nil
end

--return a table of objects describing tiles on the map
--ignore: do not return anything with this flag
--result: a table of results to add to
function mapobjects(x,y,w,h,ignore,result)
  result,ignore = result or {},ignore or 0
  local xmin, ymin = flr(x/8),flr(y/8)
  -- have to deduct a tiny amount, or we end up looking at a neighbour
  local xmax, ymax = flr((x+w-0.0001)/8),flr((y+h-0.0001)/8)
  local rxmin,rymin,rxmax,rymax = blokmap.x,blokmap.y,blokmap.x+blokmap.w-1,blokmap.y+blokmap.h-1
  for c=xmin,xmax do
    for r=ymin,ymax do
      --bounds check
      if c<rxmin or r<rymin or c>rxmax or r>rymax then
        add(result, {x=c*8,y=r*8,w=8,h=8,flag=f_outside,sp=0})
      else
        local sp=mget(c,r)
        local f = fget(sp)
        if f > 0 and band(f, ignore) == 0 then
          add(result, {x=c*8,y=r*8,w=8,h=8,flag=f,sp=sp})
        end
      end
    end
  end
  return result
end

function getblox(x,y,w,h,ignore,source)
  local result = {}
  ignore = ignore or 0
  for a in all(blox) do
    if a ~= source and a.active then
      if band(ignore, a.flag)==0 and a:intersects(x,y,w,h) then
        add(result, a)
      end
    end
  end
  return result
end

--return all blox or tiles in an area,
--excluding source from the list and anything with a flag it ignores
--tiles returned are basic versions of blox
function getobstacles(x,y,w,h,ignore,source)
  local result = {}
  ignore = ignore or 0
  mapobjects(x,y,w,h,ignore,result)
  for a in all(blox) do
    if a ~= source and a.active then
      if band(ignore, a.flag)==0 and a:intersects(x,y,w,h) then
        add(result, a)
      end
    end
  end
  return result
end



-- sorting comparators
function rightwards(a,b)
  return a.x>b.x
end
function leftwards(a,b)
  return a.x<b.x
end
function downwards(a,b)
  return a.y>b.y
end
function upwards(a,b)
  return a.y<b.y
end

--insertion sort
function sort(a,cmp)
  for i=1,#a do
    local j = i
    while j > 1 and cmp(a[j-1],a[j]) do
        a[j],a[j-1] = a[j-1],a[j]
    j = j - 1
    end
  end
end

--it's you murphy
player = blok:extend()

function player:init(c,r)
  self.sc, self.sr = c,r -- spawn column & row
  add(chkpnts,chkpnt(c,r))--drop a checkpoint
  c,r = c*8+1,r*8+2
  blok.init(self,c,r,6,6,f_player,bor(f_trapstop,f_ledge),1)
  self.dx,self.dy,self.speed,self.g=
    0.4,dropdamp,0.8,grav
  self.pushmask = bor(f_puck,f_crate)
  --same as our normal self.ignore, but without f_ledge
  --this hack allows us to collide with only the top of
  --an f_ledge and ignore the rest
  --(i would implement all directions, but pico8 m8)
  self.momignore = f_trapstop
  self.coyote=0
  self.jmpheld=false
  self.jmphold=0
  self.camy=self.y+self.h/2
  self.launched=false
  self.exit=false
end

function player:upd()
  
  if self.exit then
    if self.x<self.exit.x+10 then
      self.x+=1
    else
      if not transition then
        transition=transit(function()
          if level<=#levels then
            level+=1
            createlevel(level)
          end
        end,30)
      end
    end
    return
  end
  
  --trap check
  self:trapchk()
  if not self.active then return end
  
  -- move
  if btn(0) then
   self.vx -= self.speed
   self.flipx=true
  end
  if btn(1) then
   self.vx += self.speed
   self.flipx=false
  end
  self.dy=dropdamp
  --jump curve
  --if self.vy<0 and self.jumphold<-0.1 then
  --  self.vy+=self.jumphold
  --  self.jumphold*=0.5
  --end
  local btndwn=(btn(4) or btn(5))
  if btndwn then
    if btndwn~=self.btndwn then
      sfx(3,0)--flap wings
    end
    if self.mom==nil and self.vy>=0 then
      self.dy=0.1
    end
    if self.coyote>0 and not self.jmpheld then
      self:jmp(3.1)
      sfx(2)
    end
  else
    self.jmpheld=false
    if btndwn~=self.btndwn then
      sfx(-1,0)--stop flap wings
    end
  end
  self.btndwn=btndwn
  
  --input lag
  if self.mom then self.coyote=3
  else self.coyote-=1 end
  --if we're about to push a crate, make it feel heavy
  if abs(self.vx) > minmove then
    local ob=lookblokx(self.x,self.y,self.w,self.h,self.vx)
    if ob then
      if band(ob.flag,f_crate)>0 then self.vx*=0.67 end
    end
  end
  
  if self.coyote>0 or self.vy>0 then self.camy=self.y+self.h/2 end
  
  --simulate
  blok.upd(self)
  
  if self.touchx then
    local ob=self.touchx
    if self.mom then
      if band(ob.flag,f_puck)>0 then
        if not ob.charge then
          --kick
           ob:bump(self.flipx,self)
        end
      elseif ob.sp==29 then
         self.exit=ob
         self.y=(ob.y+ob.h)-self.h
         sfx(-1,0)--stop flap wings
         sfx(6)--fanfare
      end
    end
    self.vx=0
  end
  if(self.touchy and self.touchy.mom~=self) self.vy=0
  
  
end

function player:jmp(p)
  blok.jmp(self,p)
  self.coyote=0
  self.jmpheld=true
  if p==poppwr then
    splode(self.x+self.w/2,self.y+self.h/2,5,7,effects,7)
    self.launched=true
    sfx(1)
  end
end

--where does the camera go?
function player:cam()
  local x,y = self:center()
  
  if(not self.active) x,y = centertile(self.sc,self.sr)
  --local s=64--scale of camera steps
  --x,y=flr((x+s/2)/s)*s,flr(y/s)*s
  --handle any size room of 8px units
  x = min(max(x-64, blokmap.x*8), -128+(blokmap.x+blokmap.w)*8)
  y = min(max(y-64, blokmap.y*8), -128+(blokmap.y+blokmap.h)*8)
  return x,y
end

function player:death(src)--src: source of death
  blok.death(self)
  
  --crush pop
  --pop out/in the player if the kill is unfair
  if src.crushmask and band(self.flag,src.crushmask)>0 then
    if src.touchy==self then
      local c=self.x+self.w/2
      local sandwich = {src, self.touchy}
      for b in all(sandwich) do
        --pop if center of filling is outside of bread
        if c<=b.x then
          local v = (b.x-self.w)-self.x
          local m = self:movex(v)
          if m == v and (self.x+self.w<=src.x or self.x>=src.x+src.w) then
            self.active=true
          end
        elseif c>=b.x+b.w then
          local v = (b.x+b.w)-self.x
          local m = self:movex(v)
          if m == v and (self.x+self.w<=src.x or self.x>=src.x+src.w) then
            self.active=true
          end
        end
        if self.active then break end
      end
    end
  end
  --create corpse
  if not self.active then
    self.launched=false
    splode(self.x+self.w/2,self.y+self.h/2,6,8,effects,7)
    add(effects,corpse(self,self.x,self.y,79,0,-3))
    sfx(-1,0)--stop flap wings
    sfx(5)
  end
end

function player:respawn()
  self.x,self.y,self.active,self.vy=self.sc*8,self.sr*8,true,0
  add(blox,self)
end

function player:draw()
  if self.exit then
    blok.draw(self,1+((frames/2)%2),-4,-4)
    local x,y=self.exit.x,self.exit.y
    spr(30,x,y)
    spr(mget(x/8+1,y/8),x+8,y)
  elseif (btn(4) or btn(5)) then
    local f=(frames%6)+73
    blok.draw(self,f,-4,-5)
  else
    blok.draw(self,((btn(1)or btn(0)) and 1+((frames/2)%2) or 1),-4,-4)
  end
  if self.launched then
    self:dusty()
    if self.vy>=0 then self.launched=false end
  end
  if self.anim then self:updanim() end
end




--kickable crate
puck = blok:extend()

function puck:init(c,r,sp)
  self.sc, self.sr = c,r -- spawn column & row
  mset(c,r,25)--spawn marker
  c,r = c*8+1,r*8+2
  blok.init(self,c,r,6,6,f_puck,bor(f_trapstop,f_ledge),sp)
  self.dx,self.dy,self.speed,self.g=
    0,dropdamp,2,grav
  self.pushmask = bor(f_player,f_puck)
  self.momignore = f_trapstop
  self.charge=false
  self.anim=nil
end

function puck:upd()
  --trap check
  self:trapchk()
  if not self.active then return end
  
  if self.charge then
    if self.flipx then
      self.vx -= self.speed
    else
      self.vx += self.speed
    end
  end
  --simulate
  blok.upd(self)
  if self.charge then
    if self.touchx then
      local ob=self.touchx
      local c=ob.x+ob.w/2
      if (self.flipx and c<self.x) or (not self.flipx and c>self.x) then 
        if ob==us then--and us.coyote>0 then
          self:launch(ob)
        elseif ob.sp==self.sp then
          --kick
          self.charge=false
          ob:bump(self.flipx,self)
        else
          --is it crumble?
          if ob.sp>=52 and ob.sp<=54 then
            local x,y=ob.x+ob.w/2,ob.y+ob.h/2
            for i=1,4 do
              add(effects,debris(x,y,pick1(93,94),-1+rnd(2),-2-rnd(2)))
            end
            splode(x,y,5,7,effects,7)
            sfx(9)
            mset(ob.x/8,ob.y/8,0)
          end
          --bump
          self.flipx=(not self.flipx)
          sfx(7)
        end
      end
    end
  else
    if self.mom==us then
      if us.mom then
        self:divorce()
        us.y,self.y=self.y,self.y+us.h
        us:jmp(poppwr)
      end
    end
  end
end

function puck:bump(flipx,bumper)
  --anim:init(x,y,sps,table,t)
  sfx(0)
  self.charge,self.flipx=true,flipx
  bumper.anim=anim((flipx and self.x+self.w or self.x-8), self.y+self.h-8,
  {84,84,85,85,86,86,87,87},6,flipx,bumper)
end

function puck:death()
  blok.death(self)
  self.charge,self.vx,self.vy=false,0,0
  splode(self.x+self.w/2,self.y+self.h/2,6,8,effects,7)
  add(effects,corpse(self,self.x,self.y,95,0,-3))
  sfx(5)
end

function puck:respawn()
  self.x,self.y,self.active,self.vy=self.sc*8,self.sr*8,true,0
  add(blox,self)
end

function puck:launch(ob,flipx)
  flipx=flipx or self.flipx
  ob:movey(self.y-(ob.y+ob.h))--move item to top
  self:movex(flipx and -6 or 6)--slide under
  self.vx=0
  self.charge=false
  shake(0,2)
  ---ob.y=(self.y+self.h)-ob.h--consistent  jump
  ob:jmp(poppwr)
  --splode(self.x+self.w/2,self.y+self.h/2,5,6,effects,7)
end

function puck:draw()
  if self.charge then
    blok.draw(self,self.sp+1+((frames)%2))
    self:dustx()
  else
    blok.draw(self)
  end
  if self.anim then self:updanim() end
end

--walking trap
poppa = blok:extend()

function poppa:init(c,r,sp)
  self.sc, self.sr = c,r -- spawn column & row
  mset(c,r,25)--spawn marker
  c,r = c*8,r*8+4
  blok.init(self,c,r,8,4,f_trap,bor(f_trap,f_ledge),sp)
  self.dx,self.dy,self.speed,self.g=
    0,dropdamp,0.5,grav
  self.pushmask = 0
  self.momignore = f_trapstop
  self.charge=false
end

function poppa:upd()
  --trap check
  self:trapchk()
  if not self.active then return end
  
  local tops = getblox(self.x-4,self.y-4,self.w+8,self.h+4,bor(f_trapstop,f_wall),self)
  
  if self.charge then
    if #tops>0 then
      for b in all(tops) do
        if b.y+b.h==self.y+self.h then
          local c = b.x+b.w/2
          if c>self.x and c<self.x+self.w then
            self.charge=false
            if b==us then shake(0,2)
            else
              splode(self.x+self.w/2,self.y+self.h/2,5,7,effects,7)
            end
            sfx(1)
            b:jmp(poppwr)
            b:movey(-4)--out of sensor, reattach child
          end
        end
      end
    end
  else
    if #tops>0 then
      if not self.charge then sfx(10) end
      self.charge=true
    else
      self.vx += (self.flipx and -self.speed or self.speed)
    end
  end
  --simulate
  blok.upd(self)
  
  if self.touchx then
    self.flipx=(not self.flipx)
  end
  
end

function poppa:death()
  blok.death(self)
  self.charge,self.vx,self.vy=false,0,0
  splode(self.x+self.w/2,self.y+self.h/2,6,8,effects,7)
  add(effects,corpse(self,self.x,self.y,127,0,-3))
  sfx(5)
end

function poppa:respawn()
  self.x,self.y,self.active,self.vy=self.sc*8,self.sr*8,true,0
  add(blox,self)
end


function poppa:draw()
  if self.charge then
    blok.draw(self,self.sp+2)
  else
    blok.draw(self,self.sp+((frames/2)%2))
  end
end

function poppa:drawdbg()
  rect(self.x-4,self.y-4,(self.x-4)+self.w+8,(self.y-4)+self.h+4,10)
  blok.drawdbg(self)
end

--shoots projectile
spitta = blok:extend()
spitframes={20,68,69,70,69,70,69,70,69,70,69,70,69,70,71,72}
spitframetotal=#spitframes
function spitta:init(c,r,sp)
  blok.init(self,c*8,r*8+2,8,6,f_wall,0,sp)
  self.pushmask = 0
  self.momignore = f_trapstop
  self.charge=false
end

function spitta:upd()
  local tops = getblox(self.x,self.y-2,self.w,2,bor(f_trapstop,f_wall),self)
  if #tops>0 then
    if not self.charge and tops[1].mom==self then
      self.charge=true
      sfx(11)
      local b=ball(self.x+4,self.y+2,(self.sp==19 and -2 or 2))
      add(blox,b)
    end
  else
    self.charge=false
  end
end

function spitta:draw()
  if self.charge then
    self.flipx=false
    blok.draw(self,self.sp+2)
  else
    local sp = spitframes[1+flr(frames/4)%spitframetotal]
    self.flipx=self.sp==19
    blok.draw(self,sp,-4,-5)
  end
end

ball = blok:extend()
function ball:init(x,y,vx)
  blok.init(self,x+vx*2,y,4,4,f_trap,bor(f_trapstop,f_ledge),23)
  self.dx,self.dy,self.vx,self.speed=
    1,1,vx,vx
  self.pushmask = 0
  self.momignore = f_trapstop
end
function ball:upd()
  blok.upd(self)
  if self.touchx then
    local ob=self.touchx
    for i=1,4 do
      add(effects,debris(self.x-2,self.y-2,pick1(80,81),-1+rnd(2),-2-rnd(2)))
    end
    splode(self.x+self.w/2,self.y+self.h/2,3,11,effects,10)
    if ob.bump then
      ob:bump(self.speed<0,self)
      local a=self.anim
      a.x,a.y,a.track=self.x+a.x,self.y+a.y,nil
      add(effects,self.anim)
    else
      sfx(12)
    end
    self:death()
  end
end




--all purpose crusher and moving platform
slab = blok:extend()
slabignore=bor(f_trapstop,f_ledge)
slabledgeignore=f_outside-1--ignore everything going down
function slab:init(c,r,sp)
  self.sc, self.sr = c,r -- spawn column & row
  mset(c,r,59)--spawn marker
  self.speed,self.fast=0.5,1
  blok.init(self,c*8,r*8,8,sp>=38 and 2 or 8,fget(sp),slabignore,sp)
  local push=bor(f_puck,bor(f_player,f_crate))
  self.pushmask,self.crushmask = push,push
  --stretch
  local n=c+1
  while mget(n,r)==sp do
    mset(n,r,59)
    self.w+=8
    n+=1
  end
  n=r+1
  while mget(c,n)==sp do
    mset(c,n,59)
    self.h+=8
    n+=1
  end
    
end

function slab:upd()
  --direction command check (top left)
  local traps = mapobjects(self.x,self.y,8,8,bnot(f_trap))
  local endgame = false
  if #traps > 0 then
    -- found a trap
    local t = traps[1]
    local c,r,s = flr(t.x/8),flr(t.y/8),t.sp
    -- is it a dir command?
    if (s>=8 and s<=11) or (s>=40 and s<=43) then
      local fast=1
      if s>=40 and s<=43 then
        fast,s=4,s-32
      end
      -- dir commands start at 8
      local cx,cy = self.x+4,self.y+4
      local tx,ty = centertile(c,r)
      local nsp = s-4
      if(self.sp>=38)nsp+=32
      if(abs(tx-cx)==0 and abs(ty-cy)==0) self.sp,self.fast,sp=nsp,fast,nsp
    end
  end
  -- move
  local sp,speed = self.sp,self.speed*self.fast
  if (sp==4) self.vx -= speed
  if (sp==5) self.vx += speed
  if (sp==6) self.vy -= speed
  if (sp==7) self.vy += speed
  if sp==38 then
    self.vy -= speed
    self.ignore=slabignore
  elseif sp==39 then
    self.vy+=speed
    self.ignore=slabledgeignore
  end
  blok.upd(self)
end

function slab:draw(x,y,big)
  x,y,sp=x or self.x,y or self.y,self.sp
  spr(sp,x,y)
  if (frames/4)%2<1 then
    if sp>=38 then spr(sp+28,x,y-1)
    else spr(sp+60,x,y) end
  end
  if not big and self.w>8 then
    for xb=self.w-8,8,-8 do
      self:draw(x+xb,y,true)
    end
  end
  if not big and self.h>8 then
    for yb=self.h-8,8,-8 do
      self:draw(y,y+yb,true)
    end
  end
end




-- just a sprite from the sheet
anim = class()
function anim:init(x,y,sps,t,flipx,track)
  self.active,self.x,self.y,self.sps,self.i,self.t,self.flipx,self.track=
    true,(track and x-track.x or x),(track and y-track.y or y),sps,1,t or 0,flipx,track
end
function anim:draw()
  local sp = self.sps[self.i]
  if self.track then
    if(sp)spr(sp,self.x+self.track.x,self.y+self.track.y,1,1,self.flipx)
  else
    if(sp)spr(sp,self.x,self.y,1,1,self.flipx)
  end
  self.i+=1
  --if self.i>#self.sps then self.i=1 end
  if self.t > 0 then
    self.t-=1
    if self.t <= 0 then
      self.active=false
    end
  end
end

debris=class()
function debris:init(x,y,sp,vx,vy)
  self.active,self.x,self.y,self.sp,self.vx,self.vy,self.flipx=
    true,x,y,sp,vx,vy,(rnd(2)>1 and true or false)
end
function debris:draw()
  spr(self.sp,self.x,self.y,1,1,self.flipx)
  self.x+=self.vx
  self.y+=self.vy
  --apply damping
  self.vx*=dropdamp
  self.vy*=dropdamp
  self.vy+=grav
  if self.y>cam_y+128 then self.active=false end
end

sharps=anim:extend()
function sharps:init(list,sps)
  anim.init(self,0,0,sps,#sps+30+flr(rnd(60)))
  self.list=list
  self.n=flr(rnd(#list))+1
end
function sharps:next()
  local n,list=self.n,self.list
  if #list>1 then
    repeat
      n+=flr(rnd(#list))+1
      if(n>#list)n=1
    until list[n]~=self.ob
    self.ob,self.x,self.y=list[n],list[n].x,list[n].y
  end
  self.n,self.t,self.active,self.i=n,#self.sps+80+flr(rnd(60)),true,1
end
function sharps:draw()
  if #self.list==0 then return end--safety
  if self.ob then
    anim.draw(self)
    if not self.active then
      self:next()
    end
  else self:next() end
end

corpse=debris:extend()
function corpse:init(body,x,y,sp,vx,vy)
  self.body,self.stg=body,0
  debris.init(self,x,y,sp,vx,vy)
end
function corpse:draw()
  if self.stg==2 then--fly up
    self.y-=4
    self.v*=1.15
    self.x+=self.v
    if self.y<cam_y then
      self.active=false
    end
    spr(108+(frames%4),self.x,self.y,1,1,self.flipx)
  elseif self.stg==1 then--carry body to respawn
    self.y-=2
    local targ=self.body.sr*8
    if self.y>targ+32 then
      self.y-=2
    end
    self.body.y=self.y+6
    if self.y+6<targ then
      self.body:respawn()
      self.stg,self.v=2,rnd(0.6)-0.3
      sfx(8,2)
    end
    self.body:draw()
    spr(108+(frames%4),self.x,self.y,1,1,self.flipx)
  else--fall
    debris.draw(self)
    if not self.active then
      --pull body up screen
      self.stg,self.active=1,true
      self.x,self.y=self.body.sc*8,(cam_y+128<self.body.sr*8 and blokmap.h*8 or cam_y+128)
      self.body.x=self.x
    end
  end
end
    

dust=class()
function dust:init(x,y,r,c)
  self.active,self.x,self.y,self.r,self.c=true,x,y,r,c
  add(mideffects,self)
end
function dust:draw()
  circfill(self.x,self.y,self.r,self.c)
  self.r-=0.2
  self.y+=0.1
  if self.r<=0 then self.active=false end
end

-- bang
splode = class()
function splode:init(x,y,r,col,table,colw)
  self.active,self.x,self.y,self.r,self.t,self.col,self.colw,table=
    true,x or 64,y or 64,r or 8,0,col or 7,colw or 7,table or effects
  -- add to a list for drawing
  add(table, self)
end
function splode:draw()
  local t,x,y,r,col,colw = flr(self.t*0.5),self.x,self.y,self.r,self.col,self.colw
  if t == 0 then
    --black frame to make it pop
    circfill(x,y,r,colw)
    circfill(x,y,r-1,9)
  elseif t < 2 then
    --full
    circfill(x,y,r,col)
    circfill(x,y,r-1,colw)
  else
    --shrink
    if t <= r then
      for rf=t,r do
        if rf==r then
          circ(x,y,rf,col)
        else
          circ(x,y,rf,colw)
        end
      end
    else
      self.active = false
    end
  end
  self.t+=1
end

--checkpoint
chkpnt=class()
function chkpnt:init(c,r)
  self.c,self.r,self.on,self.y=c,r,false,r*8
end

function chkpnt:upd()
  if not self.on then
    if us.active then
      local x,y=us:center()
      if flr(x/8)==self.c and flr(y/8)==self.r then
        self.on=true
        us.sc,us.sr=self.c,self.r
        sfx(4,2)
        for c in all(chkpnts) do
          if c~=self then
            c.on=false
          end
        end
      end
    end
    if self.y<self.r*8 then
      self.y+=1
    end
  else
    if self.y>(self.r-1)*8 then
      self.y-=1
    end
  end
end

function chkpnt:draw()
  local x,y,h=self.c*8,self.y,(self.r+1)*8-self.y
  if h>8 then
    spr(98,x,y+8,1,(h-8)/8)--vine
    h=8
  end
  if self.on then
    spr(27,x,y,1,h/8)
  else
    spr(26,x,y,1,h/8)
  end
end
