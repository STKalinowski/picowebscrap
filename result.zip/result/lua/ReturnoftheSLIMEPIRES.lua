--rETURN OF THE slimepires!
--a sOPHIE hOULDEN GAME

--sophieh.itch.io
--patreon.com/sophiehoulden


--todo:
--block way to lab x if 
--  generators are still on?


cartdata("slimepires_1_0")
--0 to 3 = endings unlocked
--4 = continue data exists
--5,6 = checkpoint x, y
--7 = carnage
--8 = gifted
--9,10,11 = generators off/on
--12+ = switches/levers

--uncomment to reset ending data
--dset(0,0)
--dset(1,0)
--dset(2,0)
--dset(3,0)


function savedata()
 dset(4,1)
 dset(5,savex)
 dset(6,savey)
 dset(7,carnage)
 
 bset(8,gifted)
 
 bset(9,gen1on)
 bset(10,gen2on)
 bset(11,gen3on)
 
 for a in all(actors) do
  if (a.saveid) bset(a.saveid,a.on)
 end
end

function bget(i)
 return dget(i)==1
end
function bset(i,v)
 dset(i,0)
 if (v) dset(i,1)
end

title=true

p_idle,p_aim,p_aim⬆️,p_aim⬆️➡️,p_run,
p_duck,p_slide,p_rise,p_fall,p_hang,p_laddera,
p_ladder
=
{1},{2},{3},{29},split("4,5,6,7"),
{8},{9},{10},{11},{12},{13},
split("13,13,14,15,15,14")

s_idle={24}
s_run=split("24,24,25,26,25")
s_duck={26}
s_slide={27}
s_air=split("16,17,18,19")
s_fall={16}

fuseoff={68}


rooms={}
actors={}
parts={}
savex=-1
savey=-1
carnage=0
tdelta=1/60

menu={"cONTINUE","nEW gAME"}
flashframe=0

lastframe=-1
prompt = ""
coyote=0
shootwait=0

menuindex=2
if (bget(4)) menuindex=1


patrons="tHIS GAME MADE POSSIBLE THANKS TO pico-8 BY lEXALOFFLE, AND MY amazing PATRONS: ♥ aBE gELLIS ♥ aLAN hAZELDEN ♥ aLEX mOLE ♥ aMAZING sTACE ♥ aNDREW lIM ♥ aNDREW sHOULDICE ♥ aNDREW wILLIAMS ♥ aNDY bUSCH ♥ aNDY nOELKER ♥ aNNETTE ♥ aRCADELY ♥ bERIA sANDERS ♥ bOB bUECHLER AND mANDY rOSE nICHOLS ♥ bRIAN vACEK ♥ c ♥ cAT aZAZEL ♥ cb dROEGE ♥ cHARLES mACmULLEN ♥ cHRIS ♥ cHRIS fORBES ♥ cIAN bOOTH ♥ cLAIRE ♥ cLARITY ♥ cOLIN sTRONG ♥ cONNOR sHERLOCK ♥ cOOL gHOSTS ♥ CUBEGHOST ♥ CURIOUSdna ♥ d p ♥ dAN fRIES ♥ dANIEL cASSIDY ♥ dARKFLUX ♥ dAVID hAYWARD ♥ dAVID rYSKALCZYK ♥ dAVIO cIANCI ♥ dEREK cARROLL ♥ dORIAN bEAUGENDRE ♥ dREW mESSINGER-mICHAELS & lAUREN vILLEGAS ♥ DUCK ♥ dREWBOT ♥ eD kEY ♥ EDDERIOFER ♥ eDMUND lEWRY ♥ eDWARD pROSSER ♥ eLLIOTT dAVIS ♥ eRIC sCHWARZOTT ♥ eRIN cONGDEN ♥ eRIN eLDRIDGE ♥ FERNLAGER ♥ fRAGGLEROCK ♥ fRANCIS fERNANDEZ ♥ fREYJA dOMVILLE ♥ fROYOK ♥ gEORGE hARNISH ♥ GKR ♥ gREG v. ♥ gREGORY aVERY-wEIR ♥ hANNAH cAIRNS ♥ hAYDEN sCOTT-bARON ♥ hODGE ♥ iAN dANSKIN ♥ J ♥ jACK mILTON ♥ jAKE hADLEY ♥ jAMIE ♥ jAN kALUZA ♥ JCTWIZARD ♥ jED jOHNSON ♥ JIB ♥ jOAKIM aLMGREN ♥ jOERG fRIEDRICH ♥ jONATHAN sTOLER ♥ jONATHAN wRIGHT ♥ jONES rOSS ♥ jORDI DE pACO ♥ jOSEPH ♥ jOSEPH cHESSUM ♥ jOSH gIESBRECHT ♥ kATHRYN lONG ♥ kEVIN ♥ KLERIL ♥ KNOWN_BLOB ♥ kSHITIJ sOBTI ♥ lANE ♥ lE-rOY kARUNARATNE ♥ lEE ♥ lEMMO pEW ♥ lENNY mORAYNISS ♥ lEONARD wITTE ♥ lIAsAE ♥ lILITH wHITE ♥ lILY v ♥ lOTTIE ♥ lTREON ♥ lUCAS aUGUSTO ♥ lUCY dAVINHART ♥ lUKE ♥ mARTIN hELLQVIST ♥ mATHEW vARKKI ♥ mATTHEW sEELEY ♥ mCrEALZ ♥ mICHAEL ♥ mICHAEL aDAMS ♥ mICHAEL cOOK ♥ mIKE wATSON ♥ mISTODON ♥ MONO ♥ MXKNITS ♥ nEIL ♥ nICA fEE ♥ nICK vER vOORT ♥ nORGG ♥ oWEN rACCUGLIA ♥ pARACHUTING tURTLE ♥ pAT wINCHELL ♥ pERIWINKLE ♥ pERPLAMPS ♥ pETE aLEX hARRIS ♥ pHOEBE sMITH ♥ pIPER gORDON ♥ pYROKA ♥ rAV ♥ rGN ♥ rICHARD fABIAN ♥ rOB cOLVIN ♥ rOB hAINES ♥ rOG dOLOS ♥ rOYCE rOGERS ♥ sARAH mCcORMACK ♥ sEAN dICK ♥ sEAN sONG ♥ sETZEROMUS ♥ sHAUN aDARKAR ♥ sIGNE rHEA gRAU kRISTENSEN ♥ sOREN ♥ sTACY rEAD ♥ sTEPHEN mAXWELL ♥ sTINGINGnETTLE ♥ tAD pATTERSON ♥ tERRY ♥ tHORNAE ♥ tIM mONKS ♥ tOM mClEAN ♥ tOM vINE ♥ tRACE bULLET ♥ vINCE mCKELVIE ♥ vIOLET l ♥ WARBLE WARBLE ♥ wILL tEMPLETON ♥ ZEP ♥ zOEaGXN ♥ zOYA ♥"


emprexlocs={{872,328},
{976,352},
{968,264},
{795,240},
{872,360}}

function addroom(n,xmin,xmax,ymin,ymax,bg)
 r={}
 r.name,
 r.solids,
 r.shootables,
 r.interactors
 =n,{},{},{}
 
 r.xmin,r.xmax,r.ymin,r.ymax
 =xmin,xmax,ymin,ymax
 
 if (not bg) bg=-1
 r.bg,r.w,r.h
 =bg,(xmax-xmin)*8+8,(ymax-ymin)*8+8
 
 add(rooms,r)
end
function getroom(x,y,default)
 for r in all(rooms) do
  if x>=r.xmin*8 and x<r.xmax*8+8 then
  if y>=r.ymin*8 and y<r.ymax*8+8 then
   return r
  end
  end
 end
 
 return default
end
addroom("escape",0,15,0,15)
addroom("entrance",0,15,16,31)
addroom("start",0,15,32,47)
addroom("spikeintro",16,39,32,47)
addroom("tall1",40,47,40,63)
addroom("center",40,71,16,39)
addroom("genny1a",16,39,16,31)
addroom("genny1b",16,39,0,15)
addroom("genny1c",40,55,0,15)
addroom("genny1",56,71,0,15)
addroom("doors",72,87,26,36)
addroom("mgs3",88,91,30,63)
addroom("mgs3b",92,95,33,52)
addroom("genny2",72,87,0,15)
addroom("genny2a",72,99,16,25)
addroom("genny2ab",100,115,16,25)
addroom("genny2b",116,127,0,25)
addroom("genny2c",88,115,0,15)
addroom("genny3",72,87,37,52)
addroom("genny3a",48,71,40,52)
addroom("genny3b",48,87,53,63)
addroom("saferoom",92,105,57,63)
addroom("shrine",88,95,26,29)
addroom("sanctpath",92,105,53,56)
addroom("sanctuary",106,127,53,63)
addroom("boss1",96,127,26,52)
addroom("boss1exit",112,127,0,25)
addroom("labx",32,39,48,55)
addroom("laby",32,39,56,63)
addroom("labz",0,31,48,63,0)



function addactor(typ,x,y,keeptile)
 a={}

 a.typ,a.startx,a.starty
 =typ,x*8,y*8
 
 --print(x)

 a.room = getroom(a.startx,a.starty)
 
 if (not keeptile) mset(x,y,0)
 
 if (typ=="turbine") mset(x,y,mget(x,y+1))
 if (typ=="fuse") mset(x,y,49)
 
 if typ=="egg" 
 or typ=="switch"
 or typ=="door"
 or typ=="emprexwall" then
  add(a.room.solids,a)
 end
 
 
 if typ=="barrel" 
 or typ=="bat"
 or typ=="mob"
 or typ=="emprex"
 or typ=="oblivion" then
  add(a.room.shootables,a)
 end
 
 if typ=="lever" 
 or typ=="checkpoint" then
  add(a.room.interactors,a)
 end
 
 add(actors,a)
 
 return a
end



function makeactors()
 for layer=0,3 do
 for x=0,127 do
 for y=0,63 do
 
  
 
  --bottom layer
  if layer==1 then
   
   if mget(x,y)==31 then
    addactor("checkpoint",x,y,true)
   end
   
   if mget(x,y)==46 then
    addactor("emprexwall",x,y)
   end
   
   if mget(x,y)==125 then
    addactor("oblivion",x,y)
   end
   
   if mget(x,y)==127 then
    addactor("emprex",x,y)
   end
   
   if mget(x,y)==20 then
    addactor("egg",x,y)
   end
   
   if mget(x,y)==72 then
    addactor("fuse",x,y).fuseid=1
   end
   if mget(x,y)==65 then
    addactor("turbine",x,y).fuseid=1
   end
   if mget(x,y)==73 then
    addactor("fuse",x,y).fuseid=2
   end
   if mget(x,y)==66 then
    addactor("turbine",x,y).fuseid=2
   end
   if mget(x,y)==88 then
    addactor("fuse",x,y).fuseid=3
   end
   if mget(x,y)==81 then
    addactor("turbine",x,y).fuseid=3
   end
   
   
   if mget(x,y)==44 then
    addactor("barrel",x,y)
   end
  end
  
  --middle layer
  if layer==2 then
   if mget(x,y)==1 then
    p=addactor("player",x,y)
   end
   
   if mget(x,y)==24 then
    addactor("mob",x,y)
   end
   
   if mget(x,y)==16 then
    addactor("bat",x,y)
   end
  end
  
  --top layer
  if layer==3 then
   --if mget(x,y)==59 then
   -- addactor("bucket",x,y)
   --end
   
   if mget(x,y)==45 then
    addactor("switch",x,y)
   end
   if mget(x,y)==84 then
    addactor("lever",x,y)
   end
   
   if mget(x,y)==47 then
    door=addactor("door",x,y)
    door.doorheight=1
    mset(x,y,35)
    for i=1,2 do
     if mget(x,y+i)==47 then
      mset(x,y+i,35)
      door.doorheight+=1
     else
      goto doorstop
     end
    end
    ::doorstop::
   end
   
  end
  
  
 end
 end
 end
 
end


function initactors(newgame)

 if newgame then
  gen1on,gen2on,gen3on
		=bget(9),bget(10),bget(11)
 end
 
 if newgame then
  gifted=bget(8)
 end
 
 
 saveid=12
 for a in all(actors) do
  a.x,a.y,a.fx,a.fy,a.frame,a.anim
  =a.startx,a.starty,0,0,1,p_idle
  
  if a.typ=="player" then
   if savex!=-1 then
    a.x,a.y=savex*8,savey*8
   end

   
   slimed,
   infected,
   unslime,
   grounded,
   hanging,
   ladder,
   slide,
   px,
   py
   =
   false,
   -1,
   -1,
   true,
   false,
   false,
   0,
   a.x,
   a.y
  
  end
  
  if a.typ=="emprexwall" then
   a.solid=true
  end
  
  if a.typ=="emprex" then
   a.emprex=true
   a.boss=true
   a.invulnerable=true
   a.dialogued=gifted
   a.sin=0
   a.wait=1
   a.dir=0
   
   a.hp=60
   a.flash=0
   a.shootable=true
   a.radius=18
   
   a.gone=false
  end
  
  if a.typ=="oblivion" then
   a.oblivion=true
   a.boss=true
   a.invulnerable=true
   a.dialogued=false
   a.sin=0
   a.sinb=0
   
   a.hp=80
   a.flash=0
   a.shootable=true
   a.radius=15
   
   a.xmin=24
   a.xmax=222
   
   a.gone=false
  end
  
  if a.typ=="barrel" then
   a.anim={44}
   a.hp=3
   a.flash=0
   a.shootable=true
   a.radius=4
   a.flashcol=7
   a.sploded=false
  end
  
  if a.typ=="egg" then
   a.anim=split("20,20,21,22,22,22,21,21")
   a.solid=true
   a.hp=4
   a.flash=0
   a.slimer=true
  end
  
  if a.typ=="fuse" then
   a.anim=fuseoff
  end
  
  if a.typ=="turbine" then
   a.anim=split("1,67,83,-67")
  end
  
  if a.typ=="bat" then
   a.anim=s_air
   a.hp=4
   a.flash=0
   a.shootable=true
   a.radius=5
   a.circ=rnd()
   a.slimer=true
  end
  
  
  if a.typ=="mob" then
   a.anim=split("24,24,25,26,27,26,25")
   a.hp=6
   a.flash=0
   a.shootable=true
   a.radius=5
   a.slimer=true
   
   a.hflip=rnd()<0.5
   if newgame then
    findbounds(a)
   end
  end
  
  if a.typ=="switch" then
   a.saveid=saveid
   if (newgame) a.on=bget(saveid)
   saveid+=1
   
   a.anim={45}
   if (a.on) a.anim={46}
   
   a.hp=1
   a.solid=true
  end
  
  if a.typ=="lever" then
   a.saveid=saveid
   if (newgame) a.on=bget(saveid)
   saveid+=1
   
   a.anim={84}
   a.hflip=a.on
   a.interact=true
  end
  
  if a.solid then
   a.swidth=8
   a.sheight=8
  end
  
  if a.typ=="door" then
   a.anim={47}
   a.solid=true
   a.swidth=8
   a.sheight=8
   if (a.doorheight>1) a.sheight=16
   if (a.doorheight>2) a.sheight=24
  end
  
  if a.typ=="checkpoint" then
   a.anim={31}
   a.interact=true
  end
  
  if (a.anim) a.frame=rnd()*#a.anim+1
  
 end
 
 
 
 --link switches to doors
 for a in all(actors) do
  if a.typ=="door" then
   --a.switchindex=1
   for ab in all(actors) do
    if (ab.typ=="switch" or ab.typ=="lever") and ab.room==a.room then
     a.switchindex=ab
     if ab.on then
      a.y-=8*a.doorheight
     end
    end
   end
  end
 end
end




function addbullet(typ,x,y,fx,fy)
 b={}
 b.typ,b.x,b.y=typ,flr(x),flr(y)
 b.lx,b.ly,b.fx,b.fy,b.life=b.x,b.y,fx,fy,5
 
 add(blts,b)
end


function addpart(typ,x,y,fx,fy)
 part={}
 part.typ=typ
 part.x=x
 part.y=y
 part.fx=fx
 part.fy=fy
 part.life=5
 part.draw=0--circ by default
 part.room=theroom
 
 part.col=7
 part.rad=25
 
 if typ=="goo" or typ=="blood" then
  
  --part.col=rnd{2,2,2,8}
  part.col=rnd(split("2,2,2,8"))
  if typ=="goo" then
   --part.col=rnd{3,3,3,3,3,11,11,11,8}
   part.col=rnd(split("3,3,3,3,3,11,11,11,8"))
  end
  
  part.rad=rnd()*2
  part.life=rnd()*0.5+0.2
 end
 
 if typ=="spark" then
  part.draw=1
  --part.anim={39,40,41,42,42}
  part.anim=split("39,40,41,42,42")
  part.wait=rnd()*0.1
  part.hflip=rnd()>0.5
  part.vflip=rnd()>0.5
  part.frame=0
  part.framewait=1
 end
 
 add(parts,part)
 
 if typ=="flash" then
  xx,yy=part.x,part.y
  for i=1,30 do
   x=xx+(rnd()*part.rad-part.rad*0.5)--*1.5
   y=yy+(rnd()*part.rad-part.rad*0.5)--*1.5
   fx=(rnd()-0.5)*500
   fy=(rnd()-0.5)*500
   addpart("spark",x,y,fx,fy)
  end
 end
 
end


function checkpointnow(cx,cy,mksound)
 
 if mksound!=false then
 if savex!=cx or savey!=cy then
  if (infected<0) sfx(5)
 end
 end
 
 savex=cx
 savey=cy
 
 savedata()
 
end


function dienow()
 sfx(0)
 dead=true
 
 if slimed then
  addsplats("goo",px,py)
 else
  addsplats("blood",px,py)
 end
end

function addsplats(typ,x,y)
 for i=0,30 do
  addpart(typ,x+rnd()*8,y+rnd()*8,(rnd()-0.5)*300,rnd()*-100-50)
 end
end

function spawnnow(newgame)
 blts={}
 dead=false
 deadtime=0
 initactors(newgame)
 setroomatplayer()
 
 spireskilled=0
end

function setroomatplayer()
 p.room = getroom(px+4,py+4,theroom)
 theroom = p.room
 solidactors=theroom.solids
 shootyactors=theroom.shootables
 interactors=theroom.interactors
end

function findbounds(a)
 a.xmin=a.startx-1
 a.xmax=a.startx+1
    
 while not (tilecheck(a.xmin,a.y,0) or tilecheck(a.xmin,a.y,1))
 and tilecheck(a.xmin,a.y+8,0) do
  a.xmin-=8
 end
 
 a.xmin=max(a.xmin,a.room.xmin*8)
 
 while not (tilecheck(a.xmax,a.y,0) or tilecheck(a.xmax,a.y,1))
 and tilecheck(a.xmax,a.y+9,0) do
  a.xmax+=8
 end
 a.xmax-=8
end

function explode(x,y,rad,dmg)
 sfx(18)
 for a in all(actors) do
  if a.room==theroom and a.hp and a.hp>0 then
		 if touches(x,y,a.x+4,a.y+4,rad) then
	   hurtit(a,dmg)
	  end
	 end
	end 
	
	if touches(x,y,px+4,py+4,rad*0.65) then
	 dienow()
	end 
end


function hurtit(a,dmg)
 if a.typ=="switch" then
  deny=false
  if (a.room.name=="doors" and not (gen1on and gen2on and gen3on)) deny=true
  
  if a.on then
   sfx(8)
  else
   if deny then
    sfx(12)
   else
    sfx(7)
    a.on=true
    a.anim={46}
   end
  end
  
  return
 end
 
 if (not a.hp) return
 
 a.hp-=dmg
 a.flash=1
 
 splat=false
 if a.hp<1 and a.typ!="barrel" then
  a.anim={0} 
  splat=true
  if a.typ=="egg" then
   a.solid=false
  	a.anim={23}
  else
   spireskilled+=1
  	carnage=max(spireskilled,carnage)
  end
 else
  sfx(10)
 end
 
 
 if splat then
  sfx(0)
  addsplats("goo",a.x,a.y)
 end
end
-->8


--tdelta=1/30
--function _update()
function _update60()

 if (ending>0) return

 btn🅾️,btn❎,btn⬇️,
 btn⬆️,btn⬅️,btn➡️=
 btn(🅾️),btn(❎),btn(⬇️),
 btn(⬆️),btn(⬅️),btn(➡️)

 if title then
	 if bget(4) then
	  if btnp(⬆️) or btnp(⬇️) then
	   menuindex+=1
	   if (menuindex>2) menuindex=1
	   sfx(17)
	  end
  end
  
  if btnp(❎) or btnp(🅾️) then
   if menu[menuindex]=="nEW gAME" then
    for i=4,63 do
     dset(i,0)
    end
   else
    savex,savey,carnage=dget(5),dget(6),dget(7)
    
   end
   sfx(14)
   makeactors()
   spawnnow(true)
   title=false
  end
 
  return
 end

 playerupdate()
 bulletupdate()
 
 for a in all(actors) do
  if not dead and a.room == theroom then
  
   if a.typ=="checkpoint" then
    a.anim={31}
    if flr8(a.x)==savex
    and flr8(a.y)==savey then
     a.anim={30}
    end
   end
   
   if a.typ=="emprexwall" then
    a.solid=true
    a.anim={85}
    if carnage==0 then
     a.solid=false
     a.anim={0}
    end
   end
   
   if a.typ=="emprex" and not dialogue then
    if a.dialogued then
     if theroom.name!="sanctuary" and a.hp>0 then
	    
		    bosslocation=1
		    --aimspin=0.5
		    if (a.hp<40) bosslocation=2
		    if (a.hp<30) bosslocation=3
		    if (a.hp<20) bosslocation=5
		    if (a.hp<10) bosslocation=4
		    
		    tgtx,tgty=emprexlocs[bosslocation][1],emprexlocs[bosslocation][2]
		    a.x=lerp(a.x,tgtx,tdelta*3)
		    a.y=lerp(a.y,tgty,tdelta*3)
		    if touches(tgtx,tgty,a.x,a.y,10) then
		     a.wait-=tdelta
		     if a.wait<0 then
		      a.invulnerable=false
		      a.wait+=0.15
		      a.dir+=1.3*tdelta
		      a.dir+=0.12
			     for i=0,4 do
			      dir=a.dir+i/4
			      addbullet("e",a.x+4,a.y,sin(dir)*50,cos(dir)*50)
		      end
		     end
		    end
		   end
	   
    else
    
	    if px>a.x-6 then
	     a.dialogued=true
	     bosstalk="foul shell from a foul soul,\nyour vileness knows no bounds!\n\nwe rejected your predecessor,\n\nwe reject you as well!"
	     if theroom.name=="sanctuary" then
	      bosstalk="welcome, pure one.\n\nyou have treasured my kind,\nand preserved your humanity.\n\naccept this gift, become both."
	     end
	     inspectnow()
	     
	    end
    end
   
	   
	   
   end
   
   if a.boss and a.hp<=0 then
    a.hp-=tdelta
    if not a.gone then
     
     a.y+=tdelta*5
     if rnd()>.8 then
      splatty="blood"
      if a.typ=="emprex" then
       splatty = "goo"
      end
      addsplats(splatty,a.x-8+rnd()*16,a.y)
      
     end
     if a.hp<-5 then
      addpart("flash",a.x+4,a.y+4,0,0)
      a.gone=true
      sfx(18)
      sfx(20)
     end
    else
     
     if a.hp<-7 then
      if a.typ=="emprex" then
       setending(1)
      else
       setending(4)
      end
     end
     
    end
   end
   
   if a.typ=="fuse" then
    
    if (a.fuseid==1 and gen1on) or
    (a.fuseid==2 and gen2on) or
    (a.fuseid==3 and gen3on) then
     if a.anim==fuseoff then
      a.anim=split("72,72,73,73,88,88,89,89")
      --a.frame=ceil(rnd()*#a.anim)
      a.frame=rnd()*8+1
     end  
    else
     a.anim=fuseoff
    end
   end
   
   if a.typ=="turbine" then
    
    a.on=(a.fuseid==1 and gen1on)
    or (a.fuseid==2 and gen2on)
    or (a.fuseid==3 and gen3on)
    
   end
   
   if a.typ=="lever" then
    a.hflip = a.on
   end
   
   if a.typ=="door" then
    onisopen = true
    if a.room.name=="saferoom" then
     onisopen=false
    end
    if a.switchindex.on==onisopen then
     a.y=max(a.y-tdelta*8,a.starty-8*a.doorheight)
     if a.y>a.starty-8*a.doorheight then
      sfx(11)
     end
    else
     a.y=min(a.y+tdelta*25,a.starty)
     if a.y<a.starty then
      sfx(9)
     else
      if (not onisopen) setending(2,34)
     end
    end
    
   end
   
   if a.typ=="oblivion" then
    if not a.dialogued then
     if px<a.x then
      a.dialogued=true
	     bosstalk="you were meant to rot. humanity\nand all else are meant to end.\n\n   ...perish!"
	     inspectnow()
     end
    else
     if not dialogue and a.invulnerable then
      a.invulnerable=false
      a.sinb=0.25
     end
    end
   end
   
   if a.typ=="mob" or a.typ=="oblivion" then
    move=10
    if (a.hflip) move=-10
    if (a.typ=="oblivion" and a.invulnerable) move=0
    
    a.x+=move*tdelta
    
    
    for sa in all(solidactors) do
		   if sa.solid and sa.room==theroom and solidactoroverlap(a.x+4,a.y+2,1,1,sa) then
		    a.x-=move*tdelta
		    a.hflip=not a.hflip
		   end
		  end
    
    if (a.x<a.xmin) a.hflip=false
    if (a.x>a.xmax) a.hflip=true
   end
   
   if a.typ=="bat" then
    a.hflip=false
    if (a.circ<0.5) a.hflip=true
    a.y=a.starty+sin(a.circ)*10
    a.x=a.startx+cos(a.circ)*8
    a.circ+=tdelta*0.4
    if (a.circ>1) a.circ-=1
   end
   
   
   if a.flash then
    if (a.flash>0) a.flash-=tdelta*1.5
   end
   
   if a.typ=="barrel" and not a.sploded then
    if a.hp<=0 and a.flash<=0.7 then
     a.sploded=true
     a.hp=-99
     a.anim={0}
     addpart("flash",a.x+4,a.y+4,0,0)

     explode(a.x+4,a.y+4,30,10)
     
    end
   end
   
  end
 end
 
 
 for part in all(parts) do
 	
 	if part then
	 	if part.life<0 then
	   --remove particle
	   del(parts,part)
	  else
	  
	   part.x+=part.fx*tdelta
		 	part.y+=part.fy*tdelta
		 	
		 	part.life-=tdelta
	  
		 	if part.typ=="flash" then
		 	 part.rad-=tdelta*200
		 	 if part.rad<0 then
		 	  part.life=-1
		 	 end
		 	end
		 	
		 	if part.typ=="goo" or part.typ=="blood" then
		 	 part.fx*=0.92
		 	 part.fy+=tdelta*350
		 	end
		 	
		 	if part.typ=="spark" then
		 	 part.wait-=tdelta
		 	 if part.wait<0 then
		 	  part.framewait-=tdelta*10
		 	  if part.framewait<0 then
		 	   part.frame+=1
		 	   part.framewait+=1
		 	  end
		 	  
		 	  part.fx*=0.8
		 	  part.fy*=0.8
		 	  if part.frame>=#part.anim then
		 	   part.life=-1
		 	  end
		 	 end
		 	end
	 	
 	end
 	end
 end
 
end

function bulletupdate()
 if (dead) return
 for b in all(blts) do
  --b=blts[i]
  
  if b then
   if b.life<0 then
    --remove bullet
    del(blts,b)
   else
    --update bullet
    --b.life-=tdelta
    
    
    b.lx=b.x
    b.ly=b.y
    
    b.x+=b.fx*tdelta
    b.y+=b.fy*tdelta
    bx,by=b.x,b.y
    
    hit=false
    if tilecheck(bx,by,0) then
     hit=true
     if tilecheck(bx,by,7) then
	     --hit low wall
	     if by - (flr8(by)*8)>2 then
	      hit=false
	     end
	    end
    end
    
    for a in all(solidactors) do
		   if a.solid and a.room==theroom and solidactoroverlap(bx,by,1,1,a) then
		    hit=true
		    hurtit(a,1)
		   end
			 end
			 
			 for a in all(shootyactors) do
			  
			  if a.room==theroom and a.hp>0 then
			   if touches(bx,by,a.x+4,a.y+4,a.radius) then
			    
			    
			    if not a.invulnerable and a.slimer != gifted and b.typ!="e" then
			     hit=true
			     hurtit(a,1)
			    end
			    
			    if a.typ=="barrel" then
						  sfx(19)
						 end
			    
			   end
			   
		   end
			 end
			 
			 if b.typ=="e" and touches(bx,by,px+4,py+4,2) then
     dienow()
			 end
    
    if hit then
     del(blts,b)
    end
    
   end
  end
  
 end
end
-->8
--drawing



function _draw()
-- if true then
-- cls()
-- spr(0,0,0,16,16)
-- return
-- end
 if ending>0 then
	 if endingbar<64 then
	  endingbar+=tdelta*10
	  rectfill(0,0,127,endingbar,0)
	  rectfill(0,128-endingbar,127,127,0)
  else
   drawprompt()
  end
  return
 end


 cls(0)

 if title then
  print(patrons,160-time()*25,122,1)
  
  print("sOPHIE hOULDEN'S",32,10,1)
  print("rETURN OF THE",38,28,2)
  --print("slimepires",44,35,11)
  otext("slimepires",44,35,10,3)
  
  spr(1,61,60)
  if (dget(0)==1) spr(23,29,60)
  if (dget(1)==1) spr(8,45,60)
  if (dget(2)==1) spr(16,77,60)
  if (dget(3)==1) spr(24,93,60)
  
  menuy=84
  menustart=1
  if (not bget(4)) menustart=2
  for i=menustart,2 do
   menustr=menu[i]
   menucol=6
   if menuindex==i then
    menustr="◆ "..menustr
    menucol=7
   end
   print(menustr,1,98+i*7,menucol)
  end

  print("v1.1",112,112,1)
  
  return
 end


 flashframe-=tdelta*10
 if (flashframe<0) flashframe+=1

 
 xmin=theroom.xmin*8
 xmax=(theroom.xmax-15)*8
 ymin=theroom.ymin*8
 ymax=(theroom.ymax-15)*8
 
 camx=mid(xmin,px-60,xmax)
 camy=mid(ymin,py-60,ymax)
 
 --put the room center screen
 if theroom.w<128 then
  camx=xmin+theroom.w*0.5-64
 end
 if theroom.h<128 then
  camy=ymin+theroom.h*0.5-64
 end
 
 camera(camx,camy)
 
 camclip()
-- if theroom.bg!=-1 then
--  rectfill(camx,camy,camx+128,camy+128,theroom.bg)
-- end
 
 if (theroom.bg!=-1) pal(1,0)
 map(theroom.xmin,theroom.ymin,theroom.xmin*8,theroom.ymin*8,theroom.xmax+1-theroom.xmin,theroom.ymax+1-theroom.ymin)
 
 
 drawactors()
 
 drawbullets()
 
 drawparticles()
 
 if prompt!="" then
  --prx=px-promptoff
		otext(prompt,px-promptoff,py-8,7,0)
 end
 
 if theroom.name=="saferoom" or theroom.name=="doors" then
  otext("safe room >",748,473,13,1)
  otext("safe room >",656,280,13,1)
 end
 
 camera()
 clip()
 
 if dialogue then
  drawprompt()
 end
 
   
 --print(spireskilled,0,0)
 --print(carnage,0,8)
 --print(1+2*flr(bosslocation%2),0,16,7)
end

function camclip()
 clip(theroom.xmin*8-camx,theroom.ymin*8-camy,theroom.w,theroom.h)
end

function drawactors()

 for a in all(actors) do
 	
 	if a.room==theroom then
	 	if (not dead) a.frame+=tdelta*13--90/7
	 	if (a.frame>#a.anim+1) a.frame=1
	 	
	 	s=a.anim[flr(a.frame)]
	 	ax,ay=a.x,a.y
	 	if a.typ=="door" then
	 	 clip(ceil(ax-camx),ceil(a.starty-camy),8,a.doorheight*8)
    spr(47,ax,ay)
    if (a.doorheight>1) spr(47,ax,ay+8)
    if (a.doorheight>2) spr(47,ax,ay+16)
    camclip()
	 	else
	 	 if a.typ=="turbine" then
	 	  if a.on then
	      turbinepal(a.fuseid)
	     else
	      turbinepal(0)
	     end
	     spr(65,ax,ay,2,2)
		    if a.on and s!=1 then
		     --a.hflip=s<0
		     spr(abs(s),ax+4,ay+4,1,1,s<0)
		    end
	 	 else
	 	  if a.emprex and not a.gone then
	 	   if (a.flash>0.9) palall(8)
	 	   
	 	   if (a.hp<=0) ax+=flr(flashframe*2)
	 	   
	 	   --circ(ax+4,ay+4,a.radius,7)
	 	   ax+=1
	 	   ay-=8
	 	   a.sin+=tdelta*0.8
	 	   asin=sin(a.sin)
	 	   asina=sin(a.sin-0.1)*3
	 	   asinb=sin(a.sin-0.2)*4
	 	   spr(112,ax-8,ay+asina)
	 	   spr(112,ax-16,ay+8+asina)
	 	   spr(113,ax+8,ay+asina)
	 	   spr(113,ax+16,ay+8+asina)
	 	   
	 	   spr(108,ax-8,ay+8+asina)
	 	   spr(108,ax,ay+8+asina)
	 	   spr(108,ax+8,ay+8+asina)
	 	   
	 	   spr(124,ax-8,ay+16+asina)
	 	   spr(108,ax,ay+asina)
	 	   
	 	   spr(108,ax,ay+16+asina)
	 	   spr(124,ax+8,ay+16+asina)
	 	   spr(124,ax,ay+24+asina)
	 	   
	 	   spr(111,ax,ay-14+asin*4,1,2)
	 	   spr(0,ax+16+asin*-3,ay+16+asinb,1,1)
	 	   spr(0,ax-16-asin*-3,ay+16+asinb,1,1,true)
	 	   
	 	   
	 	  else
	 	   if a.oblivion and not a.gone then
	 	    --circ(ax+4,ay+4,a.radius,7)
	 	    zapfill(a)
	 	    
	 	    
	 	    if (a.flash>0.9) palall(11)
	 	   
	 	    if a.hp<=0 then
	 	     ax+=flr(flashframe*2)
	 	     --a.sinb=0
	 	     --if (rnd()>0.985) sfx(21)
	 	    
	 	    else
	 	     if (rnd()>0.92 and a.dialogued) sfx(21)
	 	    end
	 	    
	 	    pal (11,0)
	 	    
	 	    ax+=1
	 	    ay+=1
	 	    spr(125,ax,ay)
	 	    
	 	    a.sin+=tdelta*0.5
	 	    if (not dead) a.sinb+=tdelta*0.1
	 	    if (a.sinb>0.5) a.sinb-=0.5
	 	    for i=1,8 do
	 	     spr(125,ax+16*sin(a.sin+i/8)*cos(a.sinb),ay+16*cos(a.sin+i/8)*sin(a.sinb))
	 	    end
	 	    
	 	    
	 	    
	 	   else
	 	    if (s!=0) ospr(s,ax,ay,1,1,a.hflip,a)
	 	   end
	 	  end
	 	 end
	 	end
	 	
	  
	  pal()
  end
	end
	
end

function zapfill(a)
 if a.invulnerable then
  --a.sinb=0
  return
 end
 if (a.hp<1) return
 
 bx,by,horiz=a.x+4,a.y+4,false
 
 if (a.sinb*2>0.25 and a.sinb*2<0.75) horiz=true
 power=abs(0.5-a.sinb*2)*2
 if (horiz) power=1-power
 power^=5
 power*=20
 for w=-power,power do

  col=rnd{2,2,2,8,8,14}
  
  if horiz then
   line(0,by+w,512,by+w,col)
  else
   line(bx+w,0,bx+w,512,col)
  end
 end
 
 if not dead then
  by-=4
  bx-=4
	 if horiz then
	  if py>by-power and py<by+power then
	   dienow()
	  end
	 else
	  if px>bx-power and px<bx+power then
	   dienow()
	  end
	 end
 end
 
end


tpals={split("15,9,4,10,7"),
split("0,1,5,5,13"),
{},
split("14,8,2,15"),
split("11,3,1,12")}
function turbinepal(t)
 t+=2
 for i=1,#tpals[t] do
  pal(tpals[1][i],tpals[t][i])
 end
end

function drawparticles()

 for part in all(parts) do
 	
 	if part then
	 	if part.room==theroom then
		 	
		 	if part.draw==0 then
		 	 --circ
		 	 circfill(part.x,part.y,part.rad,part.col)
		 	else
		 	 --spr
		 	 if part.frame>0 then
		 	  spr(part.anim[part.frame],part.x-4,part.y-4,1,1,part.hflip,part.vflip)
		 	 end
		 	end
		  
		  pal()
		 else
		  --part not in this room
		  del(parts,part)
	  end
  end
	end
	
end

function drawbullets()
 for b in all(blts) do
  if b.typ=="e" then
  	circfill(b.x,b.y,1,11)
  else
	  col=7
	  if gifted then
	   col=11
	  end
	  line(b.x,b.y,b.lx,b.ly,col)
  end
 end
end
-->8
--helper funcs

function lerp(a,b,t)
 return (1-t)*a+t*b;
end



function movevert(my)
 --move player by my units
 if (my==0) return
 
 py+=my
 
 --resolve vert collisions
 while overlapssolid(px+2,py,3,7)
 or overlapsslope(px+2,py,3,7) do
  py+=-my*0.1
  p.fy=0
  if my>0 then
   --land
   if (not grounded) sfx(4)
   grounded=true
   ladder=false
   --p.fy=0
  else
   --bump head
  end
 end
 
 if cangrab(my) and not slimed then
  sfx(1)
  hanging = true
  px=flr8(px)*8+2
  if (p.hflip) px+=4
 end
 
end

function cangrab(my)
 --returns true if can grab onto
 --ledge when moving at my speed
 
 if (my<0) return false
 
 
 local xoff=7
 if (p.hflip) xoff=0
 
 
 if (tilecheck(px+xoff,py,0)) return false
 if (not tilecheck(px+xoff,py+1+my,0)) return false
 if (tilecheck(px+xoff,py-my,0)) return false
 
 py=flr8(py)*8+7
 
 return true
end

function movehoriz(mx)
 --move player p by mx units
 
 --return if motion is too small
 if (abs(mx)<0.01) return
 
 safex=px
 safey=py
 targetx=px+mx
 
 while px!=targetx do
  px+=mx*0.1
  --moved far enough
  if (mx>0 and px>targetx) or
     (mx<0 and px<targetx) then
   px=targetx
  end
  
  --check if we can be where we moved to
  bump = false
  
  if overlapssolid(px+2,py,3,7,slide!=0) then
   bump = true
  end
  
  --move up any slopes we travelled
  while overlapsslope(px+2,py,3,7) 
  and not bump do
   py-=0.1
   grounded=true
   p.fy=0
   --if we can't move up more
   --we should just bump back
   if overlapssolid(px+2,py,3,7) then
    bump = true
   end
  end
  
  --move down any slopes we travelled
  if grounded then
   oldy=py
   while not overlapsslope(px+2,py+1,3,7)
   and not overlapssolid(px+2,py+1,3,7)
   and py-oldy<1 do
    py+=0.5
    p.fy=0
   end
   if py-oldy>=1 then
    --we are walking off a ledge?
    py=oldy
   end
  end
  
  if bump then
   p.fx=0
   px=targetx
  else
   --can move to here
   safex=px
   safey=py
  end
 end
 
 px=safex
 py=safey
 
end

function overlapssolid(x,y,w,h,allowlow)
 --returns true if an object
 --at x,y with w,h(width,height)
 --overlaps a solid tile
 
 if (x<0 or x+w>1024) return true
 
 
-- for thex=x,x+w do
--  for they=y,y+h do
--   if (solidmappixel(thex,they,allowlow)) return true
--  end
-- end
 
  for they=y,y+h,h*0.25 do
   if (solidmappixel(x,they,allowlow)) return true
   if (solidmappixel(x+w,they,allowlow)) return true
  end
 
 
-- if (solidmappixel(x,y,allowlow)) return true
-- if (solidmappixel(x+w,y,allowlow)) return true
-- if (solidmappixel(x,y+h,allowlow)) return true
-- if (solidmappixel(x+w,y+h,allowlow)) return true 	
-- if (solidmappixel(x,y+h*0.33,allowlow)) return true
-- if (solidmappixel(x+w,y+h*0.33,allowlow)) return true 	

 
-- if allowlow then
--  if (tilecheck(x,y,0) and not tilecheck(x,y,7)) return true
--	 if (tilecheck(x+w,y,0) and not tilecheck(x+w,y,7)) return true
--	 if (tilecheck(x,y+h,0) and not tilecheck(x,y+h,7)) return true
--	 if (tilecheck(x+w,y+h,0) and not tilecheck(x+w,y+h,7)) return true
-- else
--	 if (tilecheck(x,y,0)) return true
--	 if (tilecheck(x+w,y,0)) return true
--	 if (tilecheck(x,y+h,0)) return true
--	 if (tilecheck(x+w,y+h,0)) return true 	
-- end
 
 --now check solid actors
 for a in all(solidactors) do
  
  if a.room==theroom and solidactoroverlap(x,y,w,h,a) then
   if (a.slimer) infect()
   return true
  end
 end
 
 return false
end

function solidmappixel(x,y,allowlow)
 if tilecheck(x,y,0) and
 tilecheck(x,y,7) then
  if (allowlow) return false
  return y-flr8(y)*8<3
 else
  return tilecheck(x,y,0)
 end
end

function lowtilecheck(x,y,w,h)
	if (tilecheck(x,y,0) and tilecheck(x,y,7)) return true
 if (tilecheck(x+w,y,0) and tilecheck(x+w,y,7)) return true
 if (tilecheck(x,y+h,0) and tilecheck(x,y+h,7)) return true
 if (tilecheck(x+w,y+h,0) and tilecheck(x+w,y+h,7)) return true
 return false
end



function solidactoroverlap(x,y,w,h,a)
 if (not a.solid) return
-- if x+w>a.x and x<a.x+a.swidth
-- and y+h>a.y and y<a.y+a.sheight then
--  return true   
-- end
-- 
-- return false
 return x+w>a.x and x<a.x+a.swidth and y+h>a.y and y<a.y+a.sheight
end

function tilecheck(x,y,layer)
 if (y<0) y=0
 return fget(mget(flr8(x),flr8(y)),layer)
end

function overlapsslope(x,y,w,h)
 if (pointonslope(x,y)) return true
 if (pointonslope(x+w,y)) return true
 if (pointonslope(x,y+h)) return true
 if (pointonslope(x+w,y+h)) return true
 return false
end

function pointonslope(x,y)
 --returns true if x,y overlaps
 --some slope
 if not tilecheck(x,y,1) then
  --tile isn't a slope
  return false
 end
 
 --define slope of tile
 px1=flr8(x)*8
 px2=px1+8
 py1=flr8(y)*8+8
 py2=py1-8
 
 if tilecheck(x,y,2) then
  --halfstep up
  py2=py1-4
 end
 if tilecheck(x,y,3) then
  --halfstep up 2
  py1-=4
  py2-=1
 end
 if tilecheck(x,y,4) then
  --fullstep up
  --this is default so eh
  py2-=1
 end
 if tilecheck(x,y,5) then
  --fullstep down
  py1=py2
  py2+=8
  py1-=1
 end
 if tilecheck(x,y,6) then
  --halfstep down 2
  py1=py2
  py2+=4
  py1-=1
 end
 if tilecheck(x,y,7) then
  --halfstep down
  py2=py1
  py1-=4
 end
 
 --now check if x,y is below
 --the line between p1 and p2
 ly=lerp(py1,py2,1-(px2-x)/8)
 return ly<=y
end


function flr8(v)
 --converts a position from
 --game space to map space
 return flr(v/8)
end
-->8
--player update


function playerupdate()

 if (py<0) setending(3)

 prompt = ""
 
 if dialogue then
  if btnp(⬇️) then
   dialogue=false
   bosstalk=nil
  end
  return
 end
 
 promptid={}
 
 if dead then
  deadtime+=tdelta
  if (deadtime>1) spawnnow()
  return
 end
 
 if carnage>58
 and theroom.name=="mgs3"
 and py>44*8 then
  px+=4*8
  setroomatplayer()
  sfx(18)
  for i=1,3 do
   addpart("flash",px-8+rnd()*16,py-64+rnd()*128,0,0)
  end
  checkpointnow(94,49,false)
 end

 
 if gifted then
  infected=-1
  if (btn🅾️) slimed=true
  if (btn❎) slimed=false
 end
 
 if infected>0 then--and not p.slimed then
  beepwait-=beeprate*tdelta
  if beepwait<0 then
   beeprate+=0.2
   sfx(12)
   beepwait+=1
  end
 
  infected+=tdelta
  if infected>8.4 then
   sfx(13)
   slimed=true
   infected=-1
  end
 else
  beeprate=1
  beepwait=1
 end
 
 inlowtile=lowtilecheck(px+2,py,3,7)

 --horizontal input/forces
 if slide==0 then
	 if not hanging then
	  if btn⬅️ then
	   p.fx-=tdelta*260
	   p.hflip=true
	  end
	  if btn➡️ then
	   p.fx+=tdelta*260
	   p.hflip=false
	  end
	 end
	 
	 if not btn⬅️ and not btn➡️ then
	  p.fx = lerp(p.fx,0,tdelta*20)
	 end
	 
	 p.fx=mid(-38,p.fx,38)
	 
	 if (p.shooting) p.fx=0
	else
	 --sliding
	 if (btn⬅️) p.hflip=true
	 if (btn➡️) p.hflip=false
	 
	 if not inlowtile or abs(slide)>50 then
   slide = sgn(slide) * (abs(slide)-tdelta*200)
		
		 if (abs(slide)<20) slide=0
  end
  p.fx=slide
 end
 
 --grounded/falling
 if not grounded then
  p.fy=min(p.fy+230*tdelta,90)
 end
 
 if hanging or ladder then
  p.fy=0
  p.fx=0
 end
 
 if ladder then
  if btn⬆️ and tilecheck(px,py,2) then
   p.fy=-25
  end
  if btn⬇️ and tilecheck(px,py+7,2) then
   p.fy=25
  end
 end
 
 --move vertically
 movevert(p.fy*tdelta)
 if slimed then
  hanging=false
  ladder=false
 end
 
 --grab onto ladders
 if not hanging and not btn🅾️
 and not btn❎ and not slimed
 and tilecheck(px+4,py,2)
 and not tilecheck(px+4,py,1)
 then
  if btn⬆️
  or (btn⬇️ and not grounded)
  then
   ladder=true
   crouch=false
   px=flr8(px+4)*8
  end
 end
 
 
 
 --check if not grounded
 if not overlapssolid(px+2,py+1,3,7) and not overlapsslope(px+2,py+1,3,7) then
  grounded=false
 end
 
 
 movehoriz(p.fx*tdelta)
 
 coyote+=tdelta
 if (grounded) coyote=0
 
 --jumping
 if btn🅾️ and (not inlowtile or slide==0) then
	 if slimed then
	  p.fy=-35
	  grounded=false
	 else
		 if coyote<0.12 then
		  sfx(3)
		  p.fy=-70
		  grounded=false
		  coyote=10
		 end
	 end
 end
 
 --climbing from hanging/ladders
 if hanging and (btn⬇️ or btn❎) then
  grounded=false
  hanging = false
  movevert(2)
 end
 if btn🅾️ and (hanging or ladder) then
  sfx(3)
  p.fy=-70
  grounded=false
  hanging = false
  ladder = false
 end
 if btn❎ and ladder then
  ladder=false
 end
 
 
 --crouching/sliding
 crouch=false
 if btn⬇️ and grounded and
 not btn❎ and not ladder
 then
  crouch=true
  if slide==0 then
   if (btn➡️) slide=100
   if (btn⬅️) slide=-100
  end
 end
 
 prect={}
 prect.x=px+2
 prect.x2=px+5
 prect.y=py
 prect.y2=py+7
 prect.y3=py
 
 if not slimed then
  overlaps,o=rectoverlap(prect,31)
  if overlaps then
	  --checkpoint collision
	  if (infected>0) sfx(14)
	  checkpointnow(o.x,o.y)
	  infected=-1
  end
 end
 
 
 if grounded and not btn❎ and slide==0 then
  --readable (tile)
  overlaps,o = rectoverlap(prect,43)
  if not overlaps then
  	overlaps,o = rectoverlap(prect,107)
  end
  if not overlaps then
  	overlaps,o = rectoverlap(prect,126)
  end
  if overlaps then
	  prompt="⬇️ inspect"
	  promptoff=20
	  promptid = o
	  promptid.a=nil
  end
  
  --interactible (actor)
  interactor=getinteractible()
  if interactor!=-1 then
   if interactor.typ!="checkpoint" or slimed then
	  	--actable
		  prompt="⬇️ use"
		  promptoff=8
		  ignore,promptid = rectoverlap(prect,43)
	   promptid.a=interactor
    promptid.x=nil
   end
  end
 end
 
 if prompt!="" and slimed then
  prompt=slimeprompt--"⬇️ glub"
  promptoff=12
 end
 
 if prompt=="" then
  slimeprompt=rnd{"⬇️ glub","⬇️ ooze","⬇️ blub"}
 end
 
 prect.y2=py+1
 if p.fy>0 and not slimed and rectoverlap(prect,32) then
  --spike collision
  dienow()
 end
 
 --becoming infected
 if not gifted and infected<=0 and not slimed then
	 for a in all(shootyactors) do
	  if a.room==theroom and a.slimer and a.hp>0 then
		  if touches(px+4,py+4,a.x+4,a.y+4,a.radius) then
--		   p.infected=1
--		   sfx(12)
     infect()
		  end
	  end
	 end
 end
 
 
 if py>530 then
  --oob
  dienow()
 end
 
 

 --animations
 if grounded then
  if btn⬅️ or  btn➡️ then
   p.anim=p_run
  else
   if crouch then
    p.anim=p_duck
   else
    p.anim=p_idle
   end
  end
 else
  if p.fy<0 then
   p.anim=p_rise
  else
   p.anim=p_fall
  end
 end
 if slide!=0 then
  p.anim=p_slide
 end
 if hanging then
  p.anim=p_hang
 end
 if ladder then
 	if p.fy!=0 then
  	p.anim=p_ladder
  else
   p.anim=p_laddera
  end
 end
 
 
 
 if p.anim==p_run and flr(p.frame)==4 and lastframe!=4 and p.frame!=lastframe then
  if slimed then
   sfx(16)
  else
   sfx(1)
  end
 end
 
 if p.anim==p_slide and grounded then
  if slimed then
   sfx(17)
  else
   sfx(2)
  end
 end
 
 if slimed then
  if (p.anim==p_idle) p.anim=s_idle
  if (p.anim==p_run) p.anim=s_run
  if (p.anim==p_duck) p.anim=s_duck
  if (p.anim==p_slide) p.anim=s_slide
  if (p.anim==p_rise) p.anim=s_air
  if (p.anim==p_fall) p.anim=s_fall
 end
 if p.anim==s_air and flr(p.frame)==3 and 3!=lastframe then
  sfx(15)
 end
 
 
 if btn❎ and grounded then
  p.shooting = true
 else
  p.shooting = false
  shootwait=0
 end
 
 if slimed then
  p.shooting=false
  if btn❎ then
   sfx(10)
   unslime+=tdelta
   if unslime>0.8 then
    p.anim={28}
    dienow()
   end
  else
   unslime=0
  end
 end

 if p.shooting then
  
  if slide==0 then
	  p.anim=p_aim
	  if btn⬆️ then
	   p.anim=p_aim⬆️
	   if btn➡️ or btn⬅️ then
	    p.anim=p_aim⬆️➡️
	   end
	  end
	  if (btn⬇️) p.anim=p_duck
  end
  
  shootwait-=tdelta
  if shootwait<0 then
   shootwait=0.13
	  
	  shootx = 100
	  shooty = 0
	  fromx=px+8
	  fromy=py+1
	  
	  if p.hflip then
	   fromx=px-1
	   shootx = -100
	  end
	  
	  if btn⬆️ then
	   fromx=px+4
	   if (p.hflip) fromx-=1
	   fromy=py-1
	   shootx=0
	   shooty=-100
	   
	   if btn⬅️ then
	    shooty=-75
	    shootx=-75
	    fromx=px+1
	    fromy=py--+1
	   end
	   if btn➡️ then
	    shooty=-75
	    shootx=75
	    fromx=px+6
	    fromy=py--+1
	   end
	   
	  end
	  
	  if btn⬇️ then
	   fromy=py+3
	   if btn⬅️ then
	    shooty=75
	    shootx=-75
	   end
	   if btn➡️ then
	    shooty=75
	    shootx=75
	   end
	  end
	  if slide!=0 then
	  	fromy=py+4
	  end
	  sfx(6)
	 	addbullet("lzr",fromx,fromy,shootx,shooty)
	 end
 end
 
 
 
 if prompt!="" and btnp(⬇️) then
  
  inspectnow()
 end
 
 lastframe=flr(p.frame)
 
 p.x,p.y=px,py
 
 setroomatplayer()
end



function rectoverlap(r,tileid,o)

 o={}
 o.x=flr8(r.x)
 o.y=flr8(r.y)
 if (mget(o.x,o.y)==tileid) return true,o
 o.x=flr8(r.x2)
 if (mget(o.x,o.y)==tileid) return true,o
 o.y=flr8(r.y2)
 if (mget(o.x,o.y)==tileid) return true,o
 o.x=flr8(r.x)
 if (mget(o.x,o.y)==tileid) return true,o
 
 o.y=flr8(r.y3)
 if (mget(o.x,o.y)==tileid) return true,o
 o.x=flr8(r.x2)
 if (mget(o.x,o.y)==tileid) return true,o
 
 return false,o
end


--do actors a and b overlap
--function overlaps(a,b)
--
-- if a.x<b.x-8
-- or a.x>b.x+8
-- or a.y<b.y-8 
-- or a.y>b.y+8 then
--  return false
-- end
-- return true
--end
-->8

function touches(x1,y1,x2,y2,rad)
 if abs(x1-x2)>=rad
 or abs(y1-y2)>=rad then
  return false
 end
 xa,ya=(x1-x2)*0.01,(y1-y2)*0.01
 dist=sqrt(xa*xa+ya*ya)*100
 --if(dist<0) dist=32767 --clamp big numbers
 return abs(dist)<rad
end

function inspectnow()
 p.anim=p_idle
 if (slimed) p.anim=s_idle
 
 if slimed then
  dialogue=true
  return
 end
 if promptid.a!=nil then
  a=promptid.a
  a.on = not a.on
  if a.room.name=="genny1" then
   gen1on=a.on
  end
  if a.room.name=="genny2" then
   gen2on=a.on
  end
  if a.room.name=="genny3" then
   gen3on=a.on
  end
  return
 end
 dialogue=true
end

function getinteractible()
 for a in all(interactors) do
  if touches(a.x,a.y,px-0.4,py,5) then
   return a
  end
 end
 
 return -1
end
-->8
--drawing functions
function otext(s,x,y,c1,c2)
 print(s,x+1,y,c2)
 print(s,x-1,y,c2)
 print(s,x,y-1,c2)
 print(s,x,y+1,c2)
 print(s,x,y,c1)
end

function ospr(s,x,y,w,h,fx,act,o)
 --pal()
 
 if act.flash and act.flash>0.9 then
  palall(8)
  if act.flashcol then
   palall(act.flashcol)
  end
 end
 
 
 if act==p then
  --player sprite
	 if slimed and not dead and unslime>0 then
	  x+=flr(flashframe*2)
	 end
	 
	 if dead and flashframe>0.8 then
	  palall(8)
	 end
	 
	 if carnage>58 then
	  pal(4,8)
	 end
	 if gifted then
	  pal(4,11)
	 end
	 
	 if infected>0 then
	  spr(s,x,y,w,h,fx,false)
	  
	  pal(4,11)
	  pal(5,3)
	  pal(2,3)
	  pal(1,5)
	  cliph=infected
	  if p.grounded and btn(⬇️) or slide!=0 then
	   cliph=4+infected*0.5
	  end
	  
	  clip(ceil(px-camx),flr(py-camy),8,cliph,true)
	  spr(s,x,y,w,h,fx,false)
	  camclip()
	  return
	 end
 end
 
 if (act.typ=="fuse") turbinepal(act.fuseid)

 spr(s,x,y,w,h,fx,false)
end

function palall(v)
 for i=0,15 do pal(i,v) end
end

--{64,"objective:\n\nrestore power and\nreach the safe room!"},

msgs={
{64,"as ordered, i've changed the\nprotocols for the safe room\ncorridor's doors.\n\nthey will remain sealed even\nin case of power loss.\n\nwe can stay secure in there\neven if the horde break in and\ndamage the generators.\n\n~\n\ngood work, hopefully it won't\nbe necessary...\nbut better safe than sorry."},
{97,"maintenance report 2/7/2097:\n\nall systems fine.\nwalls are looking a bit green\nbut it's probably just moss."},
{33,"we've been hiding down here\nfor so long, maybe the horde\nisn't on the surface anymore?\n\n~\n\ndon't be a fool,\nwhere would they have gone!?\n\n~\n\ni don't know, space? where did\nthey even come from anyway?"},
{75,"if the safe room is the only\nplace that is completely\nslimeproof, why don't we\njust all move there?\n\n~\n\nyou want to live even more\ncramped than we do now?\n\n~\n\n...good point."},

{89,"i beckoned the horde,\n\nbut its emprex rejected me.\n\ni shall end it as well.",0},
{90,"the constant chattering.\n\nthe talk, the smiles,\neven in this dark place\nlife continues...\n\n\ni hate it.",0},
{91,"is there anything more\ndetestable than humanity?\n\nit is so close to its end,\nbut still it persists.\n\nit just needs a push...",0},
{92,"the horde is proof that other\nstates of being are possible.\n\nwhat could i become without\nthe bounds of my human shell?",0},

{35,"the others have no clue what\ni am doing, they don't even\nknow the horde is here.\n\ni'll erase all that survive.\n\nand then the horde.\n\nmy research will be my weapon.",0},
{37,"i had thought the horde to be\noblivion for humanity, but they\nare its worst aspects:\n\njoining, connection, 'love'...\n\ni reject it all now.\n\nseverance is the only true way\nforward, the true philosophy.",0},
{36,"my studies are complete, i\nhave acquired the hidden\nknowledge.\n\ni can become\n\n\n\nperfect destruction.",0},
{34,"i shall travel to the area\nabove my lab, and leave the\nlast of my humanity there.\n\nmy new, true, self will sink\n\n...and then grow!",0},

{122,"you are free of the terrible\npsyche that birthed you...\n\nbut it remains a threat.\n\nif it is not stopped, all\nthat is will cease to be.",2}
}

function drawprompt()

 str,strstyl = "",1

 
 if bosstalk then
  str,strstyl=bosstalk,2
  if theroom.name=="labz" then
   strstyl=0
  end
 end
 
 if ending>0 then
  str=endmsg[ending]
  strstyl=4
 else
 
  promptx=promptid.x
--  if promptid.x!=nil then
--   promptx=promptid.x
--  end
 
	 if slimed and not bosstalk and promptx!=122 then
	  if promptx then
	   --console
	   str="the device doesn't respond\nto your slimy inputs."
	  else
	   --interactor
	   if promptid.a.typ=="lever" then
	    str="the lever senses your gooey\nnature and refuses to move."
	   else
	    str="it's a restore point.\n\nit can heal partial infection\nand record a human to ensure\ntheir survival.\n\nit doesn't work for slimepires"
	   end
	  
	  end
	  strstyl=2
	 else
	 
		 for m in all(msgs) do
		  if m[1]==promptx then
		   str=m[2]
		   if (m[3]) strstyl=m[3]
		  end
		 end
		 
		 if (theroom.name=="sanctuary") gifted=true
		 
		 if promptx==78 then
		  if gen1on and gen2on and gen3on then
		   str="safe room access granted\n\nstatus:"
		  else
		   str="safe room access denied\n\ninsufficient power\n\nstatus:"
		  end
		  if gen1on then
		   str..="\ngenerator 1: online"
		  else
		   str..="\ngenerator 1: offline"
		  end
		  if gen2on then
		   str..="\ngenerator 2: online"
		  else
		   str..="\ngenerator 2: offline"
		  end
		  if gen3on then
		   str..="\ngenerator 3: online"
		  else
		   str..="\ngenerator 3: offline"
		  end
		 end
	 end
 
 
 end
 
 msgw,msgh=strsize(str)
 --msgw=msgsize.w*4
 --msgh=msgsize.h*6
 
 msgx=64-msgw/2
 msgy=10
 if ending>0 or bosstalk then
  msgy=64-msgh/2
 end

 --dark
 linecola,
 linecolb,
 fillcol,
 textcol
 = 5,0,0,6
 
 if strstyl==1 then
  --screen
  linecola,
  linecolb,
  fillcol,
  textcol
  =2,4,9,2
 end
 
 if strstyl==2 then
  --slime
	 linecola,
	 linecolb,
	 fillcol,
	 textcol
	 =11,3,1,11
 end

 line(msgx,msgy-2,msgx+msgw,msgy-2,linecola)
 line(msgx,msgy+msgh+2,msgx+msgw,msgy+msgh+2,linecola)
 rect(msgx-1,msgy-1,msgx+msgw+1,msgy+msgh+1,linecolb)
 rectfill(msgx,msgy,msgx+msgw,msgy+msgh,fillcol)
 print(str,msgx+1,msgy+1,textcol)

 if ending==0 then
  print("⬇️",61,msgy+msgh+4,textcol)
 end
end


function strsize(s)
 local w,linew,lines,substr=0,0,1,""
 for i=1,#s do
  substr=sub(s,i,i)
  if substr=="\n" then
   linew=0
   lines+=1
  else
   linew+=1
  end
  if (linew>w) w=linew
 end

 return w*4,lines*6
end
-->8

endingbar=0
ending=0
endmsg={
"           ending a:\n\nwith the slimepire emprex\ndefeated, all other slimepires\nwither away and die off.\n\nyou walk the earth, in solitude.",
"          ending b:\n\nyou live out the remainder of\nyour life here in isolation.\n\nsafe... but alone.",
"           ending c:\n\nyou fly to the surface and live\nhappily among the slimepires\nfor as long as life on earth\ncan continue...",
"          ending d:\n\nthe will of oblivion defeated,\nlife in the universe has been\nassured forever.\n\nyou join with the slimepires\nand begin a life full of love."
}


function setending(v,y)
 ending=v
 if (y) endingbar=y
 dset(v-1,1)
end

function infect()
 if infected<=0 and not slimed and not gifted then
  if (infected<=0) sfx(12)
  infected=1
 end
end