--  wave race legend - #gbjam 2016
--           @matthughson

--original code art and sound by
--matt hughson

--additional art by: 
--dw817
--additional music by:
--gruber_music

--[[
** todo **
* logs (and other obstacles)
* dash (maybe)
--]]

--name of save game
cartdata("mbh_waverace")

--@gruber_music tuning begin
--
--change to true to never die.
--good for testing.
stayalive=false
--add more music patterns here.
--each time the gameplay starts
--the next pattern in the list
--is played, and eventually will
--loop back to the start of the
--list.
patterns=
{
	4,15,26
	--12,
	--20,
	--etc...
}
--
--@gruber_music tuning end

--currently playing pattern
curpattern=0

--authoring palatte.
--do not change
pl=
{
	5,3,11,7
}

--different palatte options.
--will be iterated every 
--5 points.
plo=
{
	{0,5,6,7},
	{5,3,11,7},
	{1,2,13,12},
	{0,1,12,7},
	{1,9,8,15},
	{0,0,0,7},	
}

--current pal index
curpal=1

--stores the currently used
--palette for restore temp 
--pal changes, like enemy color.
pl2=plo[curpal]

--restore palatte to the current
--palette, meaning remove any
--temp changes for things like
--enemy rendering.
function resetpal()
	--reset the palette.
	pal()
	--copy back current palette.
	for i=0,#pl do
		pal(pl[i],pl2[i])
	end
end

--sound fx lookup.
snd=
{
	hit=17,--0,
	land=14,
	sink=16,
	start=18,
}

--0=menu
--1=gameplay
--2=gameover
state=0

--globals
--
minair=15
dive_dy=10
tmus=0
played=false
musinc=1/16
tstate=0
btndelay=15

--checks if 2 boxes intersect.
function intersects(
	x1,y1,
	width1,height1,
	x2,y2,
	width2,height2)

	local xd=x1-x2
	local xs=width1*0.5+width2*0.5
	if abs(xd)>=xs then return false end

	local yd=y1-y2
	local ys=height1*0.5+height2*0.5
	if abs(yd)>=ys then return false end

		
	return true

end

--preforms common jet ski 
--movement logic.
function move_ski(o)
	o.dy+=o.g
	local oldy = o.y
	o.x+=o.dx
	o.y+=o.dy
	
	if not o.offscreen
		and o.alive then
		if o.x<0 then 
			o.x=0
			if(o.hit_edge)	o:hit_edge()
		elseif o.x+o.w>128 then 
			o.x=128-o.w
			if(o.hit_edge)	o:hit_edge()
		end
	elseif o.x>0 and o.x+o.w<128 then
		o.offscreen=false
	end
	
	local newy=findy(o.x+(o.w/2))
	if o.y+o.h>newy then
		o.y=newy-o.h
				
		if not o.grounded then
			if o.airtime>minair then
				sfx(snd.land)
			end
			o.grounded=true
			
			if o.diving then
				if not o.sinking then
					m_sinkfx(o.x,o.y+o.h)
					o.sinking=true
					sfx(snd.sink)
				end
			end
		end
		
		o.airtime=0
		o.diving=false
		
		if not o.sinking then
			local newdy=(o.y-oldy)
			if newdy<0 then
				o.dy=newdy*1
			else
				o.dy=0
			end
		end
	else
			o.grounded=false
			o.airtime+=1
	end
	
	if o.sinking then
		o.sinktime+=1
		if o.sinktime>=30 then
			o.sinking=false
			o.sinktime=0
		end
	end
	
	if o.grounded then
		if o.dx>=0 then
			local rad=5
			if(o.sinking)rad=2
			m_splashfx(o.x,o.y+o.h,rad)
		end
	end
end

--check if o is colliding with
--any other objects with id.
function coll_ski(o,id)

	if not o.alive or 
			 not o.diving then
		return
	end
	
	for k,v in pairs(objs) do
	
		if o!=v and v.id==id
					and v.alive==true then
		
			if intersects(
				o.x,o.y,o.w,o.h,
				v.x,v.y,v.w,v.h) then
				
				if o.y+(o.h*0)<v.y then
					--del(objs,v)
					v.dx=-3
					v.sinking=false
					v.sinktime=0
					v.child.dy=-2
					v.child.parent=nil
					v.alive=false
					return true
				end
			end
		end
	end
end

--make player
function m_player()

	local o=
	{
		x=64,
		y=-32,
		
		dx=0,
		dy=0,
		
		g=0.2,
		spd=2,
		
		w=16,
		h=16,
		
		alive=true,
		
		id=1,
		
		grounded=false,
		airtime=0,
		
		diving=false,
		sinking=false,
		sinktime=0,
	}			
	
	function o:u()
		local o = self
		
		if not o.alive then
			move_ski(o)
			if o.x+o.w<0 then
				del(objs,o)
			end
			return
		end		

		if btn(0) then o.dx=-o.spd
		elseif btn(1) then o.dx=o.spd
		else o.dx=0 end	
		
		if not o.diving 
			and (btnp(3) or btnp(4) or btnp(5)) then
			o.dy=dive_dy
			o.diving=true
		end
		
		move_ski(o)
		
		if o.grounded then
			combo=0
		end
		
		if o.dy>0 then
			if(coll_ski(o,2)) then
				sfx(snd.hit)
				o.dy=-3
				combo+=1
				score+=combo
				tsincekill=0
				o.diving=false
				m_enemy()
				if score%5==0 then
					m_enemy()
					incpal()
				elseif score==1 then
					--just swap pal
					incpal()
				end
			end	
		end
	end
	
	function o:d()
		
		local o = self
		
		if t%2==0 and o.diving then
		pal(pl[1], pl2[4])
		pal(pl[2], pl2[4])	
		pal(pl[3], pl2[4])
		end
		
		if not o.sinking then
			--player
			sspr(8*12,0,o.w,o.h,o.x,o.y)
			if o.y+o.h<0 then 
				spr(2,o.x,0) 
			end
		end
		
		resetpal()
	end
	
	add(objs,o)

	return o

end

--make human rider for jetski.
function m_rider(par)

	local o=
	{
		x=64,
		y=0,
		
		dx=0,
		dy=0,
		
		g=0.2,
		spd=2,
		
		w=8,
		h=16,
		
		id=0,
		
		parent=par,
		
		palswap=false,
	}
	
	par.child=o
	
	function o:u()
		local o = self
		
		if o.parent!=nil then
			o.x=o.parent.x
			o.y=o.parent.y
		else
			o.dy+=o.g
			o.x+=o.dx
			o.y+=o.dy
			
			if o.y>128 then
				del(objs,o)
			end
		end
	end
	
	function o:d()
		
		local o = self
		
		if o.palswap==true then
			pal(pl[2], pl2[4])
			pal(pl[4], pl2[2])		
		end
	
		--player
		if o.y+o.h>=0 then 
			if o.parent==nil then
				sspr(8*12,8*2,o.w,o.h,o.x,o.y)
			elseif par.dy>0 
				and par.airtime>minair then
				sspr(8*14,8*2,16,16,o.x-8,o.y)
			else
				if not o.parent.sinking then
					sspr(8*14,0,o.w,o.h,o.x,o.y)
				else
					sspr(8*14,0,o.w,o.h/2,o.x,o.y+o.h/2)				
				end
			end		
		end
		
		resetpal()
	end

	add(objs,o)

	return o

end

--make enemy jetski.
function m_enemy()

	local o =
	{
		x=128,
		y=0,
		
		dx=-1,
		dy=0,
		
		g=0.2,
		w=2,
	
		w=16,
		h=16,
		spd=2,
		
		id=2,
		
		child=nil,
		alive=true,
		
		offscreen=true,
		
		airtime=0,
		sinking=false,
		sinktime=0,
		
		tdir=0,
	}
	
	--if flr(rnd(2))==1 then
	if p1!=nil and p1.x+p1.w>64 then
		o.x=0-o.w
		o.dx*=-1
	end
	
	local newy=findy(o.x+(o.w/2))
	o.y=newy-o.h
	
	function o:u()
	
		o.tdir-=1
	
		if not o.offscreen 
					and o.alive then
--		if o.x+o.h>p1.x and
--					o.x<p1.x+p1.h then
			local dirmod=0
			local d=p1.x-o.x
			if o.y<p1.y then
				--above the player
				dirmod=1
				if abs(d)<4 then
					if not o.diving then
						o.dy=dive_dy
						o.diving=true
					end
				end
			else
				--below. move away.
				dirmod=rnd(2)-1-- -1
				if d==0 then --stuck
					d=o.x-64 --move to center
														--with -1 dirmod
				end
			end
			if o.tdir<=0 then
				o.tdir=30
				if d==0 then
					o.dx=0
				else
					o.dx=d/abs(d)*dirmod*o.spd
				end
			end
		end
		
		if not o.alive then
			move_ski(o)
			if o.x+o.w<0 then
				del(objs,o)
			end
			return
		end

		move_ski(o)
		
		if o.dy>0 and not stayalive then
			if(coll_ski(o,1)) then
				sfx(snd.hit)
				o.dy=-3
				state=2
				tstate=0
				music(0)
				tmus=0
				updatehiscore()
			end
		end
	end
	
	function o:d()
		if not o.sinking then
			sspr(8*12,0,o.w,o.h,o.x,o.y)
			if self.y+self.h<0 then 
				spr(2,self.x,0) 
			end
		end
	end
	
	function o:hit_edge()
		local o=self
		o.dx*=-1
	end
	
	add(objs,o)
	
	r=m_rider(o)
	r.palswap=true
	
	return o

end

--make speed line fx.
function m_linefx(spd)

	local o=
	{
		x=128,
		y=rnd(128),
		
		len=15*spd,
		
		spd=spd,
	}
	
	function o:u()
		self.x-=self.spd
		if self.x+self.len<0 then
			del(objs,self)
		end
	end
	
	function o:d()
		line(self.x,self.y,
			self.x+self.len,self.y,
			pl[4])
	end
	
	add(objs,o)
	
	return o
end

--make splash fx.
function m_splashfx(x,y,max_rad)

	local o=
	{
		x=x,
		y=y,
		
		dx=rnd(2)-4,
		dy=rnd(2)-3,
		
		g=0.2,
		
		col=pl[4],
		rad=rnd(max_rad-1)+1,
	}
	
	function o:u()
		local o=self
		o.dy+=o.g
		o.x+=o.dx
		o.y+=o.dy
		
		if o.y-o.rad>128 or o.x+o.rad<0 then
			del(objs,o)
		end
	end
	
	function o:d()
		circfill(self.x,self.y,self.rad,
			self.col)
	end
	
	add(objs,o)
	
	return o
end

--make splash fx.
function m_sinkfx(x,y)
	for i=0,20 do
		local o=m_splashfx(x,y,1)
		o.dx=rnd(2)-1
		o.dy=rnd(2)-3
		o.g=0.1
		add(objs,o)
	end
end

function _init()
	music(0)
	reset()
end

--reset game to initial state.
function reset()
	t=0
	--tmus=0
	size=0
	dsize=0.5
	cols={7,7,7,7}
	thick=3
	objs={}
	cen=64+32
	maxsize=32
	speed=3
	score=0
	hiscore=dget(0)
	played=false
	tsincekill=9999
	curpal=1
	pl2=plo[curpal]
	resetpal()	
	gothiscore=false
	combo=0
	waiting=false
	twait=0
end

function _update()

	tmus+=musinc
	tsincekill+=1
	tstate+=1
	
	if t%30==0 then
		m_linefx(rnd(4)+1)
	end

	if state==0 then--menu
		maxsize=8		
		--[[
		if btnp(1) then
			curpal+=1
			if(curpal>#plo)curpal=1
			pl2=plo[curpal]
			resetpal()
		end
		if btnp(0) then
			curpal-=1
			if(curpal<=0)curpal=#plo
			pl2=plo[curpal]
			resetpal()
		end
		--]]
		
		if (btnp(4) or btnp(5)) then
			sfx(snd.start)
			waiting=true
		end
		
		if(waiting==true)twait+=1
		
		if twait>=16 then
		
			state=1
			tstate=0
			--todo:
			m_enemy()
			p1=m_player()
			m_rider(p1)
			maxsize=32
			speed=3
			dsize=0.5
		end			
	elseif state==1 then--game
		if tmus%8==0 and not played then
			music(patterns[curpattern+1])
			--next song
			curpattern=(curpattern+1)%#patterns
			played=true
		end
	elseif state==2 then--over
		if (tstate>btndelay) 
			and (btnp(4) or btnp(5)) then
			state=0
			tstate=0
			reset()
		end
	end

	for k,v in pairs(objs) do
		v:u()
	end
	
	printh(#objs)

end

function findy(x)
	return sin((x+t*speed)/128)*size+cen+4
end

function _draw()

-- does not respect pal swap
--	cls(pl[2])
	camera(0,0)
	bg=pl[2]
	if tsincekill<10 then
		if t%2==0 then
--			bg=pl[3]
			camera(rnd(4)-2,rnd(4)-2)
		end
	end
	rectfill(0,0,128,128,bg)
			
	local h=80
	local r=32
	circfill(64,96,r,pl[4])
	rectfill(0,h,128,128,pl[3])
	
	local numlines=105-h
	for i=h+2,100,3 do
		local p=(1-((i-h)/numlines))
		local x=64-r+((1-p)*r)--+((i%2)*r/2)
		x+=sin(p+(t*0.01))*2
		local w=(r*2)*p
		line(x,i+(i%2*3),x+(w),i+((i+1)%2*3),
			pl[4])
	end
	
--	print(tmus,0,0,7)

	--drawcloud(64,16,8)
	--drawcloud(16,48,4)
	drawcloud(120,24,6)
	
	if state==0 then
	
	--	printc("wave race legend",
	--		64,40,pl[4],pl[1],0)
			
		
		map(0,0,
			64-((8*15)/2),40-((8*5)/2),
			15,5)
		
		--[[
		printc("⬅️ change colors ➡️",
			64,72,pl[4],pl[1],2)
		printc("press ❎ to start!",
			64,88,pl[4],pl[1],0)
		--]]
		
		if not waiting or (twait*0.25)%2>1 then
		local str="press ❎  to start!"
		local len=(#str*4)
		local startx=64-(len/2)
			printsin(str,
				startx,40,pl[4],pl[1],0)				
		end
	elseif state==1 then
		if score==0 then
			printc("press ❎ in air",
				64,32,pl[4],pl[1],0)		
			printc("to slam opponents!",
				64,40,pl[4],pl[1],0)	end
		end
	if state==2 then
		printc("game over",
			64,32,pl[4],pl[1],0)
		local c=pl[4]
		if gothiscore then
			if(flr(t*0.25%2)==0)c=pl[3]
		end
		printc("score:"..score,
			64,40,c,pl[1],0)
		local str="press ❎  continue!"
		local len=(#str*4)
		local startx=64-(len/2)
			printsin(str,
				startx,40,pl[4],pl[1],0)				
			
	end

	printo("score:"..score,2,2,pl[4],pl[1])

	local str="best:"..hiscore
	local len=#str*4
	local startx=128-len-1
	printo(str,startx,2,pl[4],pl[1])
	local str="+"..combo
	local len=#str*4
	local startx=128-len-1
	if p1 and combo>=1 then
	printc(str,p1.x+4,p1.y-4,pl[4],pl[1],0)
	end
--	print(str,startx+1,1,pl[1])	 
--	print(str,startx,1,pl[4])
	
	for k,v in pairs(objs) do
		v:d()
	end
	t+=1

	--t=0
	--size=32
	size+=dsize
	if size>maxsize or size<-maxsize then dsize*=-1 end
	for x=0,128 do
	local xn=x/127
	local yd=xn*(thick/2)
	for y=cen,cen+yd do
		--for x=0,128 do
		local col=pl[4]--cols[flr(x/(128/#cols)+1)]
		line(x,
			sin((x+t*speed)/128)*size+y,
			x,128,pl[3])
		pset(x,
			sin((x+t*speed)/128)*size+y,
			col)
		--pset(x,sin((x+t)/128-0.5)*32+64,7)
		--end
	end
	end
	
	if state==0 then
		printo(
			"@matthughson | @dw817 | @gruber_music",
			(sin((t*0.005))*12)-9,128-6,pl[4],pl[1])
	end

end

function printc(
	str,x,y,
	col,col_bg,
	special_chars)

	local len=(#str*4)+(special_chars*3)
	local startx=x-(len/2)
	local starty=y-2
	if col_bg!=nil then
		print(str,startx+1,starty,col_bg)
		print(str,startx-1,starty,col_bg)
		print(str,startx,starty+1,col_bg)
		print(str,startx,starty-1,col_bg)
		print(str,startx+1,starty-1,col_bg)
		print(str,startx-1,starty-1,col_bg)
		print(str,startx-1,starty+1,col_bg)
		print(str,startx+1,starty+1,col_bg)
	end
	print(str,startx,starty,col)
end

function printo(str,startx,
															 starty,col,
															 col_bg)
	print(str,startx+1,starty,col_bg)
	print(str,startx-1,starty,col_bg)
	print(str,startx,starty+1,col_bg)
	print(str,startx,starty-1,col_bg)
	print(str,startx+1,starty-1,col_bg)
	print(str,startx-1,starty-1,col_bg)
	print(str,startx-1,starty+1,col_bg)
	print(str,startx+1,starty+1,col_bg)
	print(str,startx,starty,col)
end

function printsin(str,x,y,col,col_bg)

	for i=1,#str do
--		printh(sub(str,i,i))
		local s=sub(str,i,i)
		local fx=x+(4*(i-1))
		printo(s,fx,findy(fx)-9,
			col,col_bg,0)
	end

end

function updatehiscore()

	local oldscore=dget(0)
	if oldscore<score then
		dset(0,score)
		hiscore=score
		gothiscore=true
	end

end

function drawcloud(x,y,r)
	local crad=r
	local cx=x-(t*0.01)
	local cy=y
	
	local colbg=pl[3]
	local colfg=pl[4]
	 
	circfill(cx,cy+1,crad,colbg)
	circfill(cx+crad*.9,
		cy+crad*.75+1,crad/2,colbg)
	circfill(cx-crad,
		cy+1,crad/2,colbg)

	circfill(cx,cy,crad,colfg)
	circfill(cx+crad*.9,
		cy+crad*.75,crad/2,colfg)
	circfill(cx-crad,cy,crad/2,colfg)
end

function incpal()
	curpal+=1
	if(curpal>#plo)curpal=1
	pl2=plo[curpal]
	resetpal()
end