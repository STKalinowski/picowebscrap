--puzzle cave - episode i
--raiders of the lost potato
--by christoph 'gizmo' muetze and rick 'gideon' shaikh
--copyright hackefuffel 2015
--version 1.0.15
--2016-05-22
t=0
ts=0
tm=0
dt=0
cs=8
fs=4
cl=1
st=0
ctrl=0
key=0
pc=0
door=2
title={}
intro={}
outro={}
bonus={}
level={}
bunny={}
enemy={}
state={}
state[1]=title
state[2]=intro
state[3]=level
state[4]=outro
state[5]=bonus

function title:update()
	if (ctrl==0 and (btn(4) or btn(5))) then
		ctrl=fs
		changestate(2)
	end
end

function title:draw()
	cls()
	local ox=8
	local oy=8
	local title={16,17,18,18,19,20,0,21,22,23,20,64,64,24,22,25,26,20,24,27,0,28,29,0,30,31,20,80,19,28,27,30,0,16,28,30,22,30,28}
	for s in all(title) do
		ox+=8
		oy+=flr(8*flr(s/64))
		if (s>=64) then ox=abs(64-s) end
		spr(s,ox,oy)
	end
	spr(8+flr(dt/16),16,32)
	spr(6+flr(dt/16),104,7,1,1,true)
	print("episode 1",44,17,12) 
	print("a pico-8 game by",32,50,1)
	print("christoph 'gizmo' muetze",15,60,1)
	print("and",55,70,1)
	print("rick 'gideon' shaikh",23,80,1)
	if dt<15 then
		print("press x button to play",18,98,12)
	end
	print("v1.0 2015 - www.hackefuffel.com",4,118,1)
end

function intro:update()
	if (ctrl==0 and (btn(4) or btn(5))) then
		ctrl=fs
		changestate(3)
	end
end

function intro:draw()
	cls()
	print("potatomonsters stole all",18,0,3)
	print("potatoes from pinkbunnyland",10,10,3)
	print("help pinkbunny and explore",12,30,8)
	print("the puzzle cave",34,40,8)
	print("retrieve all stolen potatoes and",0,60,1)
	print("save pinkbunnyland",27,70,1)
	if dt<=15 then
		print("press x to continue",27,110,12)
	end
	spr(35+flr(dt/16),60,90)
	spr(37+flr(dt/2.72),66,90)
	spr(37+flr(dt/2.72),54,90,1,1,true)
end

function outro:init()
	ctrl=-1
	outro.p=0
	bunny:init(20,5)
end

function outro:update()
	if bunny.x>7 and dt%cs==0 then
		bunny.x-=1
		sfx(1)	
	end
	if bunny.x==7 and outro.p==0 then
		sfx(2)
		outro.p=1
	end
	bunny:update()
end

function outro:draw()
	cls()
	if outro.p==0 then
		spr(5,56,40)
	end
	bunny:draw()
	if (outro.p>0) then
		print("congratulations",32,8,12)
		if dt>=15 then
	 	spr(15,50,32)
	 end
	 if tm<=60 then
	 	local min=""
			local sec=""
			local ttime=""
			if (ts<10) sec="0"
			if (tm<10) min="0"
			ttime=min..tm..":"..sec..ts
			print("total play time: "..ttime,18,20,15)
		end		
	 print("you found all potatoes",20,60,12)
	 print("and saved pinkbunnyland,",16,70,12)
	 print("the universe and everything...",5,80,12)
	 print("pinkbunny loves you!",22,90,12) 
	 print("thank you for playing",20,110,12)
	end
end

function bonus:init()
	ctrl=-1
	bonus.t=t
	bonus.r=0
	bonus.p=0
	bunny:init(20,5)
end

function bonus:update()
	if bunny.x>7 and dt%cs==0 then
		bunny.x-=1
		sfx(1)	
	end
	if bunny.x==7 and bonus.p==0 then
		sfx(2,1)
		sfx(7,2)
		bonus.p=1
		bonus.t=t
	end
	if bonus.p>0 and bonus.p<6 and t-bonus.t>60 then
		bonus.p+=1
		bonus.t=t
	end
	if (bonus.p>=6 and (btn(4) or btn(5))) then
		ctrl=fs
		changestate(1)
	end
	bunny:update()
end

function bonus:draw()
	cls()
	if bonus.p==0 then
		spr(4,56,40)
	end
	bunny:draw()
	if bonus.p==1 then
		bonus.r+=1
		circ(60,44,bonus.r*2,1)
		circ(60,44,bonus.r*2.5,1)
		circ(60,44,bonus.r*3.5,13)
		circ(60,44,bonus.r*6,12)
	end
	if bonus.p>=1 then
		if dt>=15 then
	 	spr(15,50,32)
	 end
	end
	if bonus.p>=2 then
		print("you beat the game",30,12,12)
		print("in under 5 minutes!",27,20,12)
	end
	if bonus.p>=3 then
		print("pinkbunny is very proud of you",4,55,14)
	end
	if bonus.p>=4 then
		--for i=0,128,8 do
			--rectfill(i,0,i+8,1,rnd(8)+8)
			--rectfill(i,4,i+8,8,rnd(8)+8)
			--rectfill(i,120,i+8,121,rnd(8)+8)
			--rectfill(i,124,i+8,128,rnd(8)+8)
		--end
		spr(48,32,75,8,1,false)
		line(33,83,87,83,7)
		print("visit us at hackefuffel.com",10,100,1)
		print("and stay tuned for our next game",0,110,1)
	end
end

function changestate(s)
	st=s
	if state[st].init then
		state[st]:init()
	end
end

function loadlevel(l)
	local o=flr((l-1)/8)
	local x2=(l-1)*16-(o*128)
	local y2=o*16
	map={}
	for y=0,15 do
		map[y]={}
		for x=0,15 do
			local c=mget(x+x2,y+y2)
			map[y][x]=c
			if c==6 then
				bunny:init(x,y)
				map[y][x]=0
			elseif c==5 then
				pc+=1
			elseif c==8 then
				enemy:init(x,y,1)
			elseif c==9 then
				enemy:init(x,y,-1)
			end
		end
	end
end

function control()
	if (ctrl>0) then	ctrl-=1	end
end

function bunny:die()
	if bunny.d==0 then
		ctrl=60
	 sfx(4,3)
		bunny.d=1
		bunny.s=12
		bunny.f=12
	end
end

function bunny:init(x,y)
	bunny.x=x
	bunny.y=y
	bunny.s=6
	bunny.f=6
	bunny.d=0
end

--changed to global func from
--bunny hop to avoid bug in
--webplayer
function hop(x2,y2)
	if (bunny.d==1) return
	local x1=bunny.x
	local y1=bunny.y
	if (fget(map[y1+y2][x1+x2])==1) then
		return 0
	elseif (map[y1+y2][x1+x2]==2) then
		if door>0 then
			return 0		
		end
	elseif (map[y1+y2][x1+x2]==3) then
		if key>0 then
			sfx(6)
			fset(door,0)
			door=0
			key=0
			map[y1+y2][x1+x2]=0
		end
	elseif (map[y1+y2][x1+x2]==4) then
		x1+=x2
		y1+=y2
		if (map[y1+y2][x1+x2]==0) then
			map[y1][x1]=0
			map[y1+y2][x1+x2]=4
			sfx(0)
			return 1
		else
			return 0
		end
	elseif (map[y1+y2][x1+x2]==5) then
		pc-=1
		map[y1+y2][x1+x2]=0
		sfx(2)
	elseif (map[y1+y2][x1+x2]==8 or map[y1+y2][x1+x2]==9) then
		return 0
	end
	sfx(1)
	return 1
end

function bunny:update()
	if bunny.d==1 then
		bunny.f=bunny.s+flr(dt/10)
		if ctrl==0 then
			sfx(5,1)
			changestate(3)
		end
	else
		bunny.f=bunny.s+flr(dt/16)
		if (btn(0) and ctrl==0) then
			bunny.x-=hop(-1,0)
			ctrl=fs
		end
		if (btn(1) and ctrl==0) then
			bunny.x+=hop(1,0)
			ctrl=fs
		end
		if (btn(2) and ctrl==0) then
		 bunny.y-=hop(0,-1)
		 ctrl=fs
		end
		if (btn(3) and ctrl==0) then
	 	bunny.y+=hop(0,1)
	 	ctrl=fs
		end
	end
end

function bunny:draw()
	spr(bunny.f,bunny.x*cs,bunny.y*cs)
end

function enemy:init(x,y,d)
	local e={}
	e.a=0
	e.f=8
	e.s=8
	e.d=d
	e.x=x
	e.y=y
	add(enemy, e)
end

function enemy:attack(e)
	if (e.p==0) then 
		sfx(3,2)
		e.p=1
	end
	e.f=10
	for x=e.x+e.d, bunny.x-e.d, e.d do
		if map[e.y][x]==0 then
			spr(11,x*cs,e.y*cs)
		else
			break
		end
	end
end

function enemy:update()
	for i=1, count(enemy) do
		local e=enemy[i]
		if (bunny.y==e.y and
						((e.d>0 and bunny.x>e.x)
						or (e.d<0 and bunny.x<e.x))) then
		 e.a=1
		 e.f=10
		 local hit=1
			for x=e.x+e.d,bunny.x,e.d do
				if fget(map[e.y][x])==1 then
					e.a=0
					if e.d==1 then
						e.f=e.s+flr(dt/16)
					else
						e.f=e.s+1-flr(dt/16)
					end
					break
				end
				if map[e.y][x]>0 then
					hit=0
				end
				if hit==1 and x==bunny.x then
					bunny:die()
				end
			end
		else
			if (e.p==1) sfx(10,2)
				e.a=0
				e.p=0
				if e.d==1 then
					e.f=e.s+flr(dt/16)
				else
					e.f=e.s+1-flr(dt/16)
				end
			end
	end
end

function enemy:draw()
	for i=1, count(enemy) do
		if (enemy[i].a==1) then
			enemy:attack(enemy[i])
		end
		spr(enemy[i].f,enemy[i].x*cs,enemy[i].y*cs,1,1,(enemy[i].d!=1))
	end
end

function level:init()
	pc=0
	key=0
	door=2
	if (ctrl<=4) ctrl=4
	fset(door,1)
	for e in all(enemy) do
		del(enemy,e)
	end
	sfx(10,2)
	loadlevel(cl)
end

function level:update()
	if pc<=0 then
		key=3
	end
	if (map[bunny.y][bunny.x]==2) then
		if (door==0) then
			if cl<15 then
				cl+=1
				changestate(3)
			else
				if tm<=4 then
					changestate(5)
				else
					changestate(4)
				end
			end
		end
	end
	if (ctrl==0 and (btn(4) or btn(5))) then
		ctrl=24
		sfx(5,1)
		changestate(3)
	end
	bunny:update()
	enemy:update()
end

function level:draw()
	cls()
	for y=0,15 do
		for x=0,15 do
			local c=map[y][x]
			if c<6 then
				if c==2 then
					c=door
				elseif c==3 then
					c=key
				end
			end
			if (fget(c)>0) then
				spr(c,x*cs,y*cs)
			end
		end
	end
	if (cl==3) then
		if dt<15 then
			print("got stuck?",45,20,12)
			print("press x to reset level",20,30,12)
		end
	end
	bunny:draw()
	enemy:draw()
	level:info()
end
	
function _init()
	changestate(1)
end

function _update()
	t+=1
	dt+=1
	if dt>=30 then 
		dt=0
		if st==3 then
			if ts>=59 then
				ts=0
				tm+=1
			else	
				ts+=1
			end
		end
 end
	control()
	state[st]:update()
end

function _draw()
	state[st]:draw()
end

function level:info()
	local min=""
	local sec=""
	if (ts<10) sec="0"
	if (tm<10) min="0"
	spr(60,99,0)
	print("level "..cl.."/15",0,1,12)
	if tm>=60 then
		print("zzzzz",109,1,12)
	else
		print(min..tm..":"..sec..ts,109,1,12)
	end
end











