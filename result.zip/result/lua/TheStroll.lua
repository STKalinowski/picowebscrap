--stroll
player = {}
player.x = 5
player.y = 96
player.tspr = 0
player.mspd = 1
player.spd = 0
player.moving = false
player.aspd = 4
player.afr = 1
player.left = false
player.acc = .2
player.f = .65
player.examining = false
player.exiting = false
player.lcol = false
player.lcol = false
curscreen = {}
curscreen.x = 0
curscreen.y = 0
monster = {}
monster.x = 96
monster.y = 98
monster.spr = 128
monster.aspd = 4
monster.afr = 0
monster.looking = false
monster.scream = false
game = {}
game.title = false
game.ending = false
game.intro = true
game.run = false
game.screentimer = 0
game.screenchange = 100

val = 0
lval = 0
rval = 0
music(0, 0, 7)

function psfx(num)
	sfx(-1)
	sfx(num)
end

function move()
		player.examining = false
		player.exiting = false
		player.moving = true
		if stat(19) != 0 then
			psfx(0)
		end
		if player.afr == player.aspd then
			player.tspr += 1
			if player.tspr > 4 then
				player.tspr = 1
			end
			
			player.afr = 0
		end
		player.afr += 1	
end

function examine()
	valx = (player.x+4+(128*curscreen.x))/8
	valy = ((player.y+8+(128*curscreen.y)))/8
	val = mget(valx, valy)
	if val == 116 or val == 117 then
		curscreen.y += 1 
		player.y -= 6
		psfx(1)
	end
	if val == 94 then
		opengates(val, valx, valy, true)
	elseif val == 109 then
		opengates(val, valx, valy, true)
	end
end

function opengates(id, x, y, t)
	if id == 94 then
		mset(x, y, 109)
		mset(x, y-17, 82)
		mset(x, y-16,82)
		mset(x, y-15, 98)
		mset(x, y-14, 68)
		mset(x, y-13, 68)
	end
	if id == 109 then
		mset(x, y, 94)
		mset(x, y-17, 76)
		mset(x, y-16,92)
		mset(x, y-15, 123)
		mset(x, y-14, 124)
		mset(x, y-13, 124)
	end
	if mget(x+1, y) == 15 then
		if mget(x+3, y) == 109 then
			mset(x+3, y, 94)
			mset(x+3, y-17, 76)
			mset(x+3, y-16, 92)
			mset(x+3, y-15, 123)
			mset(x+3, y-14, 124)
			mset(x+3, y-13, 124)
		elseif mget(x+3, y) == 94 then
			mset(x+3, y, 109)
			mset(x+3, y-17, 82)
			mset(x+3, y-16,82)
			mset(x+3, y-15, 98)
			mset(x+3, y-14, 68)
			mset(x+3, y-13, 68)
		end
	end
	if mget(x-2, y) == 15 then
		if mget(x-3, y) == 109 then
			mset(x-3, y, 94)
			mset(x-3, y-17, 76)
			mset(x-3, y-16, 92)
			mset(x-3, y-15, 123)
			mset(x-3, y-14, 124)
			mset(x-3, y-13, 124)
		elseif mget(x-3, y) == 94 then
			mset(x-3, y, 109)
			mset(x-3, y-17, 82)
			mset(x-3, y-16,82)
			mset(x-3, y-15, 98)
			mset(x-3, y-14, 68)
			mset(x-3, y-13, 68)
		end
	end
	psfx(2)
end

function isexit()
	val = mget((player.x+4+(128*curscreen.x))/8, ((player.y+(128*curscreen.y))+16)/8)
	if val == 106 then
		curscreen.y -= 1 
		player.y += 6
		psfx(1)
	end
end

function checkcol()
	lval = mget((player.x-player.mspd+player.spd+(128*curscreen.x))/8, ((player.y+(128*curscreen.y))+12)/8)
	if fget(lval) == 1 then
		player.lcol = true
	else
		player.lcol = false
	end
	rval = mget((player.x+8+player.mspd+player.spd+(128*curscreen.x))/8, ((player.y+(128*curscreen.y))+12)/8)
	if fget(rval) == 1 then
		player.rcol = true
	else
		player.rcol = false
	end
	if curscreen.x == 0 and player.x <= 1 then
		player.lcol = true
	end
end

function _update()
	if game.run == true then
		player.moving = false
		if curscreen.x != 7 then
			if btn(0) then
				checkcol()
				if not player.lcol then
					if player.spd > player.mspd*-1 then
						player.spd -= player.acc
					end		
			 	player.left = true 
					move() 
				end
			end
			if btn(1) then
				checkcol()
				if not player.rcol then
					if player.spd < player.mspd then
						player.spd += player.acc
					end 
				
					player.left = false 
					move()
				end
			end
		else
			if player.x < 40 then
				if btn(0) then
					checkcol()
					if not player.lcol then
						if player.spd > player.mspd*-1 then
							player.spd -= player.acc
						end		
			 		player.left = true 
						move() 
					end
				end
				if btn(1) then
					checkcol()
					if not player.rcol then
						if player.spd < player.mspd then
							player.spd += player.acc
						end 
					
						player.left = false 
						move()
					end
				end
			else
				music(-1)
				monster.looking = true
			end
		end
		if not player.moving then
			player.tspr = 0
			if player.examining then
				player.tspr = 5
			end
			if player.exiting then
				player.tspr = 6
			end
			player.spd *= player.f
			if player.spd < .1 then
				player.spd = 0
			end
			if btnp(2) then
				player.examining = true
				player.exiting = false
				examine()
			end
			if btnp(3) then
				player.exiting = true
				player.examining = false
				isexit()
			end
		end
		
		player.x += player.spd
		
		if player.x > 128 then
			player.x = 0
			curscreen.x += 1
		end
		if player.x < 0 then
			player.x = 120
			curscreen.x -= 1
		end
		if monster.looking == false then
			if monster.spr < 132 then
				if monster.afr == monster.aspd then
					monster.spr += 2
					monster.afr = 0
				else
					monster.afr += 1
				end
			else
				monster.spr = 128
			end
		else
			if monster.afr >= 24 and monster.scream == false then
				monster.spr = 160
				monster.afr += 1
			else
				monster.afr += 1
			end
			if monster.afr >= 48 and monster.scream == false then
				monster.scream = true
				monster.afr = 0
				psfx(04)
			end
		end
		if monster.scream == true then
			if monster.afr >= 8 and monster.spr < 164 then
				monster.spr += 2
			else
				monster.afr +=1
			end
			if monster.afr >= 60 then
				game.ending = true
				game.run = false
			end
		end
	end
	if game.intro == true then
		if game.screentimer < game.screenchange then
			game.screentimer += 1
		else
			game.intro = false
			game.title = true
			game.screentimer = 0
		end
	end
	if game.title == true then
		if btn(1) then
			game.title = false
			game.run = true
		end
	end
end

function _draw()
	cls()
	if game.intro == true then
		rectfill(0,0,128,128, 15)
		spr(134, 48, 48, 4, 4)
		print("parlor interactive",28,80,5)
	end
	if game.title == true then
		spr(player.tspr,player.x,player.y,1,2,player.left, false)
		print("stroll", 16, 106, 7)
		print("the", 16, 98, 7)
		print("start game", 80, 106, 5)
	end
	if game.run == true then
		mapdraw (16*curscreen.x,16*curscreen.y,0,0,128,128)
		spr(player.tspr,player.x,player.y,1,2,player.left, false)
		if curscreen.x == 7 then
			spr(monster.spr,monster.x,monster.y,2,2,false, false)
		end
	end
	if game.ending == true then
		psfx(05)
		print("the end",100, 106, 7)
	end
	--print(fget(rval),18,10,8)
	--print(monster.afr)
end