-- by ivy sly
-- https://ivysly.com
------------------------------------
-- yes there is a lot of 
-- dead code and shit i need 
-- to remove and im terrible 
-- just dont look at it

obj_array = {}
introframes = 0
keys_acquired = 0

update_states = {
	function() -- title()
		local colors = {}
		local n = 0
		for k,v in pairs(player_palette_swaps) do
			n+=1
			colors[n]=k
		end
		d = controls.rp and 1 or controls.lp and -1 or 0
		if (d != 0 and not title_transitioning) then 
			sfx"52"
			palette_choice = ((palette_choice + d) % #colors)
		end
		player_palette = colors[palette_choice + 1]
		if (btnp(🅾️) and not title_transitioning) start_game()
		
	end,

	function() -- game()
		update_time()
		objects_in_camera_level = objects_in_same_level(c, not cutscene)
		c:update()
		if (c.cutscene) return
		if not end_transitioning then
			update_player(p)
			update_game_state()
		end
	end,

	function() -- end()
		-- c:update()
		-- if (controls.o or controls.x) stop()
		if (btnp(🅾️)) run()
	end,

	function() -- intro()
		introframes += 1
		if introframes > 10 then
		 music(21)
		 state = 1
		end
	end,
}

draw_states = {
	function() -- title()
		-- cls(1)
		t1, ty, titlerect = time() / 2, 0, {30, 25, 97, 63}
		if (not title_transitioning) ty = sin(t1)
-- 		drawtext([[titlescreen under construction
-- untitled climbing game 
-- v0.3.11]], 1, 1)
		dust(24, 4)
		print([[by ivy sly]], 44, 66, 13, 1)
		-- local x, y = 35, 50

		set_player_palette()
		fillp(▒)
		color(1)
		rectfill(unpack(titlerect))
		
		fillp(█)
		
	
		print([[  🅾️: start
⬅️➡️: color
		]], 35, 49, 7)
		
		color(14)
		rect(unpack(titlerect))
		spr(75, 35, 30, 5, 2)
		sspr(114, 32, 10, 16, 72, 30)
		sspr(104, 48, 10, 16, 83, 30)
		spr(1, p.x, p.y + ty, 1.57, 1.42)
		p.face_x, p.face_y = p.x + 6, p.y + ty
		draw_player_face()
		pal()

	end,

	function() -- game()
		follow_player()
		map(0, 0, 0, 0, 128, 64, 128)
		dust(24, 4)
			-- follow_player()
		map(0, 0, 0, 0, 128, 64, 127)
		drawtext("NO ENTRY", 40, 360, 6, 1)
		drawtext("DON'T SAY WE\nDIDN'T WARN YOU", 240, 480,  6, 1)
		for i, o in ipairs(objects_in_same_level(c, true)) do 
			o:draw()
		end
		
		draw_player()
		-- follow_player()
		
	end,
	
	function() -- end
		-- camera(923, 283)
		follow_player()
		local function go()
			circfill(987, 347, lerp(10, 50, ease_out(end_timer / 30)) + sin(time()) + 0.5, 12)
		end
		fillp(█)
		go()
		
		
		for i=2, 15 do pal(i, 1) end
		map(0, 0, 0, 0, 128, 64)
		draw_player(true)
		fillp(▒)
		go()
		camera(0, 0)
		rectfill(0, 119, 127, 127, 1)
		
		
		
		if (end_timer < 30) end_timer += 1
	end,
	
	function() -- intro
	
	end,
}

function dust(amt, col)
	x,y = (c and level_quantize(c.x - 64, c.y - 64)) or 0, 0
	for i=1, amt do
		local t = time() * 20
		srand(i)
		circfill(x + (rnd(384) - t * (- 0.5 + rnd(1))) % 384, (y + rnd(384) + t) % 384, 0.8 - sin(time() / (2 + rnd(4))), col)
	end
end

function kickup_dust(frames, height, r, num_particles, pos, c1, c2, c3, c4, spread)
	play_effect(function()
		seed = rnd()
		for i=1, frames do
			for j=1, num_particles do
				srand(j + seed)
				local x, y = pos.x - spread/2 + rnd(spread), pos.y - spread/2 + rnd(spread)
				y, x = lerp(y, y - rnd(height), ease_out(i/frames)), lerp(x, x - 8 + rnd(16), ease_out(i/frames))
				local length = frames - rnd(frames/2)
				color(c1)
				if (i <= frames * 0.75) color(c4)
				if (i > length / 3) then
					color(c2)
					fillp(▒)
				end
				if (i > length / 2) color(c3)
				-- dbg("len", length)
				srand(x)
				if (length <= frames)  circfill(x, y, r * flp(i/frames))
				fillp(█)
			end
			yield()
		end
	end)
end

function drawtext(t, x, y, c1, c2)
	local c1, c2 = c1 or 7, c2 or 2
	print(t, x, y+1, c2)
	print(t, x, y, c1)
end

function follow_player()
	camera(c.x, c.y + c.shake)
end

p_arms_length = 34
toggle = false

objects_in_camera_level = {}

-- flags

-- player = 2

-- stringify (https://github.com/benwiley4000/pico8-table-string/pull/1/files)
-----------------------------------
-----------------------------------
-----------------------------------

function table_from_string(str)
  local tab, is_key = {}, true
  local key,val,is_on_key
  local function reset()
    key,val,is_on_key = '','',true
  end
  local function parse(key)
    return tonum(key) or key
  end
  reset()
  local i, len = 1, #str
  while i <= len do
    local char = sub(str, i, i)
    if char == '\31' then
      if is_on_key then
        is_on_key = false
      elseif val=='\6' or val=='\21' then
        tab[parse(key)] = (val=='\6')
        reset()
      else
        tab[parse(key)] = parse(val)
        reset()
      end
    elseif char == '\29' then
      local j,c,l = i,'',0
      while (c ~= '\30' or l ~= 0) do
        if c == '\29' then l += 1
        elseif c == '\30' then l -= 1 end
        j = j + 1
        c = sub(str, j, j)
      end
      tab[parse(key)] = table_from_string(sub(str,i+1,j-1))
      reset()
      i = j
    else
      if is_on_key then
        key = key..char
      else
        val = val..char
      end
    end
    i = i + 1
  end
  return tab
end


mouth_spr_positions = table_from_string'closed。1゜0゜2゜8゜3゜8゜4゜3゜5゜6゜゛smiling。1゜8゜2゜20゜3゜8゜4゜4゜5゜6゜゛open。1゜8゜2゜11゜3゜10゜4゜9゜5゜3゜゛'

-- mouth_spr_positions = {
-- 	closed = {0, 8, 8, 3, 6},
-- 	open = {8, 11, 10, 9, 3},
-- 	smiling = {8, 20, 8, 4, 6},
-- }

eye_spr_positions = table_from_string'open。1゜19゜2゜13゜3゜3゜4゜2゜5゜1゜゛happy。1゜0゜2゜13゜3゜3゜4゜2゜5゜3゜゛idle。1゜4゜2゜13゜3゜3゜4゜2゜5゜3゜゛'
-- eye_spr_positions = {
-- 	idle = {4, 13, 3, 2, 3},
-- 	open = {19, 13, 3, 2, 1},
-- 	happy = {0, 13, 3, 2, 3},
-- }

hand_sprites = table_from_string'se゜22゜s゜21゜nw゜7゜ne゜6゜n゜5゜w゜36゜sw゜23゜e゜35゜'

-- hand_sprites = {
--   n  = 5,
--   ne = 6,
--   e  = 35,
--   se = 22,
--   s  = 21,
--   sw = 23,
--   w  = 36,
--   nw = 7,
-- }

fist_sprites = table_from_string'se゜39゜s゜38゜nw゜51゜ne゜52゜n゜19゜w゜37゜sw゜40゜e゜20゜'

-- fist_sprites = {
--   n  = 19,
--   ne = 52,
--   e  = 20,
--   se = 39,
--   s  = 38,
--   sw = 40,
--   w  = 37,
--   nw = 51,
-- }

cardinals = table_from_string'0゜e゜1゜ne゜2゜n゜3゜nw゜4゜w゜5゜sw゜6゜s゜7゜se゜'

-- cardinals = {
-- 	[4] = "w",
-- 	[3] = "nw",
-- 	[2] = "n",
-- 	[1] = "ne",
-- 	[0] = "e",
-- 	[7] = "se",
-- 	[6] = "s",
-- 	[5] = "sw",
-- }

cardinal_dxy = table_from_string'w。1゜-1゜2゜0゜゛sw。1゜-1゜2゜1゜゛e。1゜1゜2゜0゜゛ne。1゜1゜2゜-1゜゛s。1゜0゜2゜1゜゛nw。1゜-1゜2゜-1゜゛se。1゜1゜2゜1゜゛n。1゜0゜2゜-1゜゛'

-- cardinal_dxy = {
-- 	ne = {1, -1},
-- 	n = {0, -1},
-- 	nw = {-1, -1},
-- 	w = {-1, 0},
-- 	sw = {-1, 1},
-- 	s = {0, 1},
-- 	se = {1, 1},
-- 	e = {1, 0},
-- }


obj_table = table_from_string'checkpoint゜86゜lock゜46゜key゜53゜h_ring゜101゜h_zap゜73゜crumbler゜90゜v_zap゜74゜door゜30゜lever゜14゜v_ring゜102゜'

-- obj_table = {
-- 	key = 53,
-- 	door = 30,
-- 	lock = 46,
-- 	lever = 14,
-- 	checkpoint = 86,
-- 	h_ring = 101,
-- 	v_ring = 102,
-- 	h_zap = 73,
-- 	v_zap = 74,
-- 	crumbler = 90
-- }


sprite_hitboxes = table_from_string'70。1゜0゜2゜0゜3゜4゜4゜4゜゛71。1゜0゜2゜0゜3゜4゜4゜4゜゛72。1゜0゜2゜0゜3゜4゜4゜4゜゛73。1゜0゜2゜0゜3゜4゜4゜4゜゛106。1゜6゜2゜7゜3゜0゜4゜0゜゛11。1゜7゜2゜6゜3゜0゜4゜0゜゛12。1゜6゜2゜7゜3゜0゜4゜0゜゛14。1゜7゜2゜5゜3゜0゜4゜1゜゛15。1゜6゜2゜6゜3゜0゜4゜0゜゛84。1゜0゜2゜0゜3゜4゜4゜4゜゛118。1゜7゜2゜6゜3゜0゜4゜0゜゛87。1゜0゜2゜0゜3゜4゜4゜4゜゛88。1゜0゜2゜0゜3゜4゜4゜4゜゛122。1゜6゜2゜6゜3゜0゜4゜0゜゛74。1゜0゜2゜0゜3゜4゜4゜4゜゛104。1゜0゜2゜0゜3゜4゜4゜4゜゛103。1゜0゜2゜0゜3゜4゜4゜4゜゛62。1゜0゜2゜0゜3゜4゜4゜4゜゛86。1゜48゜2゜48゜3゜-21゜4゜-21゜゛'


-- sprite_hitboxes = {
--     [11] = {7, 6, 0, 0},
--     [118] = {7, 6, 0, 0},
--     [12] = {6, 7, 0, 0},
--     [106] = {6, 7, 0, 0},
--     [15] = {6, 6, 0, 0},
--     [122] = {6, 6, 0, 0},
--     [14] = {7, 5, 0, 1},
--     [86] = {48, 48, -21, -21},
--     [62] = {0, 0, 4, 4},
--     [70] = {0, 0, 4, 4},
--     [71] = {0, 0, 4, 4},
--     [72] = {0, 0, 4, 4},
--     [87] = {0, 0, 4, 4},
--     [88] = {0, 0, 4, 4},
--     [103] = {0, 0, 4, 4},
--     [104] = {0, 0, 4, 4},
--     [74] = {0, 0, 4, 4},
--     [73] = {0, 0, 4, 4},
--     [84] = {0, 0, 4, 4},
-- }

-- for sp in all{62, 70, 71, 72, 87, 88, 103, 104} do
-- 	sprite_hitboxes[sp] = {1, 1, 4, 4}
-- end

map_state = table_from_string'objs。゛unlocked゜‖゜opened゜‖゜id゜0゜'


-- map_state = {
-- 	id = 0,
-- 	unlocked = false,
-- 	opened = false,
-- 	objs = {}
-- }

player_palette = "red"

player_palette_swaps = table_from_string   'green。1゜11゜2゜3゜3゜13゜4゜10゜5゜11゜゛blue。1゜12゜2゜1゜3゜13゜4゜7゜5゜12゜゛yellow。1゜10゜2゜9゜3゜15゜4゜10゜5゜9゜゛red。1゜8゜2゜2゜3゜14゜4゜8゜5゜2゜゛orange。1゜9゜2゜4゜3゜15゜4゜9゜5゜4゜゛'
-- 	red = { 8, 2, 14 }, -- grippy
-- 	blue = { 12, 1, 13 }, -- clamper
-- 	green = { 11, 3, 13 }, -- palmer
-- 	yellow = { 10, 9, 15 }, -- fingers
-- 	orange = { 9, 4, 15 }, -- jack (the gripper)
-- }

cursor_palette_swaps = table_from_string'orange。1゜8゜2゜12゜゛red。1゜9゜2゜12゜゛blue。1゜9゜2゜10゜゛yellow。1゜14゜2゜12゜゛green。1゜9゜2゜12゜゛'


-- cursor_palette_swaps = { -- used in conjunction with previous 
-- 	red = { 9, 12 },
-- 	blue = { 9, 10 },
-- 	green = { 9, 12 },
-- 	yellow = { 14, 12 },
-- 	orange = { 8, 12 },
-- }

-- which keys open which door 
-- done by level id; a key from one room will unlock all doors in its target room.
-- if a key isnt specified, it opens its own room
key_unlocks = table_from_string'32゜23゜9゜12゜10゜2゜3゜11゜28゜29゜22゜13゜4゜7゜'


-- key_unlocks = { 
-- 	[10] = 2,
-- 	[3] = 11,
-- 	[9] = 12,
-- 	[28] = 29,
-- 	[22] = 13,
-- 	[4]  = 7,
--  [32] = 23,
-- }

menuitem(1, "switch ❎/🅾️", function() 
		if (left_hand_button == 🅾️) then 
			left_hand_button, right_hand_button = ❎,  🅾️
		else
			left_hand_button, right_hand_button = 🅾️,  ❎
		end
end)

-- menuitem(3, "win game", function() end_game() end)


function toggleoff() 
	toggle = false
	menuitem(2, "grab: hold", toggleon)
	return true
end

function toggleon()
	toggle = true
	menuitem(2, "grab: toggle", toggleoff)
	return true
end
toggleoff()

obj = {}
obj.__index = obj
function obj:__call(...)
	local o = setmetatable({}, self)
	return o, o:init(...)
end
function obj:extend(p)
	p = p or {}
	p.__call, p.__index = self.__call, p
	return setmetatable(p, self)
end

function obj:combine(...)
	for i=1, select("#", ...) do
		for k, v in pairs(select(i, ...)) do self[k] = v end
	end
end

function obj:draw()
	spr(self.sp, unpack_xy(self))
end

function obj:associated()
	return { self }
end

function obj:update()
end

function init_title()
	get_controls()
	save_state()
	-- music(21)

	new_player(81, 49.5)
end

function start_game()
	music(-1)
	p.mouth_state, p.eye_state, title_transitioning, p.y = "open", "open", true, p.y + ty
	bubble_effect(p, 7)
	play_effect(function()
		delay_frames"16"
		fade"16"
	end)
	sfx"57"
	add_routine(function() 
		delay_frames"24"
		state = 2 
		init_game()
	end)
	-- init_game()
end

function update_time()
	local current = (time() - start_time)
	local s=flr(current) % 60
    local m = (current \ 60)
    local h=m\60 % 99
	camera(0, 0)
	current_time = (h<10 and "0"..h or h)..":"..(m%60<10 and "0"..m%60 or m%60)..":"..(s<10 and "0"..s or s)
end

function draw_time()
	-- stealing from 

    print(current_time .. "    keys: " .. keys_acquired .. "/15",20,1,7)
end

function init_game()
	start_time = time()
	cursor = {
		angle = 0.5,
	}
	title_transitioning = false
	obj_array:init()
	debug_items = {}
	for i=0, 255 do
		if (sprite_hitboxes[i] == nil) sprite_hitboxes[i] = {7, 7, 0, 0} -- init hitboxes
	end
	
	p_x, p_y = player_start()
	new_player(p_x, p_y)
	finish_line = game_obj(987, 347, 8, 8)
	finish_line.draw = function()
		local midx, midy = midpoint(finish_line) 
		local offs = sin(time())
		local function go(r) 
			fillp"█"
			if (offs < -0.5) fillp(▒)
			circ(midx, midy, r + offs + .2, 2.4 + offs / 2)
		end
		go"12"
		go"10"
		fillp"█"
		
	end
	finish_line.update = function()
		if (overlaps(finish_line, p)) end_game()
	end
	obj_array:add(finish_line)
	c = cam(p.levelx * 128, p.levely * 128, 0, 0)
	
	level_sides_open = {}
	
	init_map()
	save_state()
	

	-- print(recursive_count(obj_array))
	-- stop()
	music(0, 0, 2)
end

function end_game()
	end_transitioning, end_time, end_timer = true, current_time, 0
	
	music"-1"
	sfx"3"
	-- sfx"57"
	add_routine(function()
		-- c:show_unlock(p.x, p.y)
		delay_frames"40"
		state = 3
		music"12"
		
	end)
	c:screenshake(2)
	play_effect(function()
		fade"5"
		delay_frames(10, function() 
			for i=1, 7 do pal(i, 7, 1) end
		end)
		delay_frames"23"
		fade"12"
		delay_frames"3"
		
		
		delay_frames(4, function() 
			fillp(▒) 
			camera(0, 0)
			rectfill(0, 0, 127, 127, 1) 
		end)
		
		fillp() 
		yield()
		
		play_effect(function()
			local text = "       you're home free\n     finish time: " .. end_time .. "\n          deaths: " .. deaths .. "\n          keys: " .. keys_acquired .. "/15\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n    press 🅾️ to play again!"
			delay_frames"5"
			for i=1, 4 do
				print(text, 3, 1, 2)
				yield()
			end
			while true do
				drawtext(text, 3, 1, 7, 8)
				yield()
			end
		end)
	end)
	
end

function add_routine(callback)
	add(update_routines, cocreate(callback))
end

function iterate_update_routines()
	local empty = true
	for routine in all(update_routines) do
		if costatus(routine) ~= "dead" then
			empty = false
			coresume(routine)
		else
			del(update_routines, routine)
		end
	end
	return empty
end

function init_map()
	-- obj_map:init()
	for i=1, 32 do
		level_sides_open[i] = {}
		get_level_transitions(i)
	end
	for x=0, 127 do
		for y=0, 63 do
			local cell = mget(x, y)
			for type, sp in pairs(obj_table) do
				if (cell == sp) then 
					mset(x, y, 0)
					-- print(x .. ", " .. y .. ": " .. type)
					load_obj(x, y, type, sp)
				end
			end
		end
	end

end

function get_level_transitions(id)
	function go(x, y) -- check for any object with 0 flag here
		return not fget(mget(x, y), 0)
	end
		local open = {}
		local x, y = id_level(id)
		local startx, starty = x * 16, y * 16 
		for i=0, 15 do
			-- dbg("i", i)
			if (go(startx, starty + i)) open.w = true
			if (go(startx + 15, starty + i)) open.e = true
			if (go(startx + i, starty)) open.n = true
			if (go(startx + i, starty + 15)) open.s = true
		end
		level_sides_open[id] = open
end

function obj_array:init()
	for id=1, 32 do
		self[id] = {}
		if (key_unlocks[id] == nil) key_unlocks[id] = id
	end
end

function obj_array:add(o)
	add(self[o.levelid], o)
	-- dbg("thing", #self[o.levelid])
end

function _init()
	level_doors_unlocked = {}
	level_doors_opened = {}
	deaths = 0
	state = 4
	controls = {}

	effect_routines = {}
	update_routines = {}
	title_transitioning = false
	end_transitioning = false
	left_hand_button = ❎
	right_hand_button = 🅾️
	palette_choice = 0
	init_title()
	fade"15"
	
	pos = game_obj(0, 0, 8, 8, 0)
end

function save_state()
	map_state = {
		unlocked = copy(level_doors_unlocked),
		opened = copy(level_doors_opened),
		objs = copy(obj_array),
		level_objs = copy(objects_in_camera_level)
	}
	keys_acquired_saved = keys_acquired
end

function player_start()
	for x=0, 127 do
		for y=0, 63 do
			if mget(x, y) == 1 then
				mset(x, y, 0)
				return x * 8, y * 8
			end
		end
	end
end

function get_controls()
	lh_prev = controls.lh
	rh_prev = controls.rh
	controls = {
		u = btn(⬆️),
		d = btn(⬇️),
		l = btn(⬅️),
		r = btn(➡️),
		up = btnp(⬆️),
		dp = btnp(⬇️),		
		lp = btnp(⬅️),
		rp = btnp(➡️),
		lh = btn(left_hand_button),
		rh = btn(right_hand_button),
		lhp = btnp(left_hand_button),
		rhp = btnp(right_hand_button),
	}
end

function new_player(x, y)
	p = new_actor(game_obj(x, y, 11, 10, 1, "player"), 4, 0.05, 0.3, 0.125)

	p.eye_state, p.mouth_state, p.face_x, p.face_y = "idle", "closed", x, y
	p.checkpoint_x, p.checkpoint_y = p.x, p.y
	p.dead = false
	p.l_hand, p.r_hand = new_hands(p)
	p.dink_timer = 0
	p.keys = {}
end

function new_hands(p)
	function make_hand(side)
		return new_hand(new_actor(game_obj(p.x, p.y, 7, 7), 3, 0.2, 0.03, 0.125), side)
	end
	return make_hand"left", make_hand"right"
end

function new_hand(a, side)
	a.side = side
	-- states:
	-- "idle"
	-- "launch"
	-- "returning"
	-- "grabbing_wall"
	a.state = "returning"
	a.launch_timer = 0
	a.grabbing = { }
	a.angle_timer = 0
	a.anchor = vec()
	return a
end

function level_id(levelx, levely) -- for keys and doors
	-- print(levelx .. ", " .. levely)
	return 1 + levelx + levely * 8
end

function id_level(id)
	local id = id - 1
	local y = id \ 8
	local x = id - (y * 8)
	return x, y
end

cam = obj:extend{}

function cam:init(x, y)
	self.shake = 0
	local o = game_obj(x, y, 0, 0)
	local s = table_from_string(
 		'swoosh_time゜10゜timer゜0゜can_transition゜‖゜transition_length゜40゜swap_back_length゜14゜transitioning゜‖゜startx゜0゜starty゜0゜cutscene゜‖゜'
	)
	s.target = vec()

	self:combine(o, s)
end

function cam:show_unlock(x, y)
	self.cutscene = true
	local start = vec(self.x, self.y)
	
	-- dbg("xy", x, y)
	function show()
		self:end_transition()
		-- update_game_state()
		
		yield()
		delay_frames"15"
		add(effect_routines, cocreate(function()
			for i=1, 130 do 
				local h = i/20
				local max = (i > 20 and i < 110)
				if (max) h = 1.0
				if (i >= 110) h = flp((i - 110)/20)
				local height = flr(ease_in_out(h) * 11)
				camera(0, 0)
				rectfill(0, 0, 128,  height, 0)
				rectfill(0, 128 - height, 128, 128, 128)
				if (i > 10 and i < 120) draw_time()
				yield()
			end
		end))
		
		self:start_transition(vec(x * 128, y * 128))
		repeat
			-- self:update()
			yield() 
		until not self.transitioning
			-- stop()
		-- update_game_state()
		-- end
		-- objects_in_camera_level = objects_in_same_level(self, false)
		self:end_transition() 
		for i=1, 45 do
			update_game_state()
			-- move_to(self, x * 128, y * 128)
			-- freeze_frames(10)
			
			yield()
		end
		
		self:start_transition(start)
		repeat yield() until not c.transitioning
		self.cutscene = false
	end
	add(effect_routines, cocreate(show))
end

function cam:start_transition(target)
	self:end_transition()
	self.startx = self.x
	self.starty = self.y
	self.target = target
	self.transitioning = true
	self.can_transition = false
end

function cam:end_transition()
	self.transitioning = false
	self.timer = 0
end

function level_quantize(x, y)
	return x \ 128 * 128, y \ 128 * 128
end

function cam:update()
	local swap_back_zone = self.swap_back_zone
	local target = self.target
	pos:combine(avg_pos(player_hands()))
	local vpos = vec(pos.x, pos.y) + vec(-pos.xoffs, -pos.yoffs)
	pos.x, pos.y = unpack_xy(vpos + vec:from_angle(cursor.angle) * 24)
	local level_sides = level_sides_open[p.levelid]
	-- clamp boundaries
	local mid_screen = vec(p.levelx * 128 + 64, p.levely * 128 + 64)
	local vertical = abs(mid_screen.x - pos.x) < abs(mid_screen.y - pos.y)
	function go(a, b, p1, p2)
		return mid(p1 and 0 or b * 128 + 60, a, p2 and 960 or b * 128 + 61)
	end
	pos.x, pos.y = go(pos.x, p.levelx, level_sides.w, level_sides.e), go(pos.y, p.levely, level_sides.n, level_sides.s)
	local midx, midy = level_quantize(pos.x, pos.y)
	midx += 64
	midy += 64
	-- local level_midpoint = vec(midx, midy) + vec(60, 60)
	
	if vec(pos.x, pos.y):dist(vec(midx, midy)) < 40 then
		pos.x, pos.y = midx - 3, midy - 3
	end

	if not (self.cutscene) then
		move_to(self, unpack_xy(lerp(self.pos, vec(pos.x, pos.y) - vec(60, 60), 0.08)))
	end
	if (self.transitioning) return self:transition()
	-- if (not self.cutscene and free_cam[c.levelid]) return self:free_cam(pos)
	
	if self.shaking and costatus(self.shaking) then
	  coresume(self.shaking)
    else
      self.shaking = false
    end
	if (current_lvl ~= self.levelid) self.prev = current_lvl
	-- dbg("prev, lvlid", self.prev, self.levelid)
end

function cam:transition()
	if self.transitioning then
		if self.timer < self.transition_length then
			self.timer += 1
			function go(a, b) 
				return lerp(a, b, ease_in_out(self.timer / self.transition_length)) 
			end
			move_to(self, unpack_xy(go(vec(self.startx, self.starty), self.target)))
			if (self.timer >= self.transition_length) self:end_transition()
		end
	end
end

function cam:screenshake(times, amount, delay)
	amount, delay = amount or 1, delay or 5
	local c = cocreate(function()
		for i=1, times do
			local amt = 1 * amount
			if (i % 2 == 1) amt = -1 * amount
			self.shake = amt
			delay_frames(delay)
		end
		self.shake = 0
		yield()
	end)
	self.shaking = c
	self.shake = 0
	
end

function _draw()
	cls(0)
	draw_states[state]()
	-- draw_states[1]()
	play_effects()
end

function play_effects()
	for i, effect in ipairs(effect_routines) do
		if costatus(effect) ~= "dead" then
			coresume(effect)
		else
			del(effect_routines, effect)
		end
	end
end

function play_effect(callback)
	add(effect_routines, cocreate(callback))
end

function draw_cursor()
	local cursor_heading = vec:from_angle(cursor.angle)
	local lcol, rcol = unpack(cursor_palette_swaps[player_palette])
	for hand in all{p.l_hand, p.r_hand} do
		local r = 5
		if (hand.side == "left") then color(lcol) else color(rcol) end
		local aiming = controls.d and hand.state ~= "grabbing_wall"
		local hx, 
			  hy = 				
			hand.x + hand.w/2, 
			hand.y + hand.h/2
		local pos, 
			  bpos = 
				vec(hx, hy) + cursor_heading * r, 
				vec:from_angle(0.25 + cursor.angle) * 5
		
		
		local vxa, 
			  vxb, 
			  vxc =
			pos + bpos,
			pos -bpos,
			pos + cursor_heading * 6
		if aiming then
			circ(vxc.x, vxc.y, r / 2)
		else 
			line(vxa.x, vxa.y, vxc.x, vxc.y)
			line(vxb.x, vxb.y, vxc.x, vxc.y)
		end

		launch_colors = {
			launch = 13,
			returning = 5,
			grabbing_wall = 7,
		}
		if (launch_colors[hand.state]) color(launch_colors[hand.state])
		if (aiming) color"2"
		circ(hx, hy, r)
	end
end

function objects_in_same_level(o, surrounding)
	local os = {}
	local id = o.levelid
	function go(id_)
		if not (c.cutscene and id_ == p.levelid) then
			for i, r in ipairs(obj_array[id_]) do
				for j, q in ipairs(r:associated()) do
					os[#os+1] = q
				end
			end
		end
	end
	counter = 1
	go(id)
	if surrounding then
		for k, v in pairs(cardinal_dxy) do
			local levelx, levely = id_level(id)
			local leveldx, leveldy = unpack(v)
			go(level_id(levelx + leveldx, levely + leveldy))
			counter += 1 
		end
	end
	-- dbg("size", #os)
	return os
end

function _update60()
	if (loaded) update_routines = {}
	get_controls()
	if not p.dead and not title_transitioning then 
		p.mouth_state = toggle and "smiling" or "closed"
		p.eye_state = toggle and "happy" or "idle"
	end
	update_states[state]()
	loaded = false
	iterate_update_routines()
	
end

function update_game_state()
	foreach(objects_in_camera_level, function(o) o:update() end)
	cursor.angle = cursor.angle - flr(cursor.angle)
end

game_obj = obj:extend{}

function game_obj:init(x, y, w, h, --[[optional]] sp, --[[optional]] type, xoffs, yoffs)
	local o = {
		x = x,
		y = y,
		sp = sp or 0,
		w = w,
		h = h,
		nearby = {},
		near_last = vec(0, 0),
		type = type or "object",
		xoffs = xoffs or 0,
		yoffs = yoffs or 0,
	}
	self:combine(o)
	update_map_coords(self)
end

function game_obj:draw()
	spr(self.sp, self.x, self.y)
end

function load_obj(mapx, mapy, type_, sp)

	local w, h, xoffs, yoffs = unpack(sprite_hitboxes[sp])
	-- print(h)
	local o = game_obj(mapx * 8, mapy * 8, w, h, sp, type_, xoffs, yoffs)

	types = {
		key = key,
		door = door,
		lock = lock,
		checkpoint = checkpoint,
		v_ring = mover,
		h_ring = mover,
		v_zap = zapper,
		h_zap = zapper,
		crumbler = crumbler
	}

	q = types[type_](o)
	-- dbg("q", type(q))

	if q then
		q:update()
		obj_array:add(q)
	end
end

function anim(o, ...)
	for i=1, select("#", ...), 2 do
		o.sp = select(i, ...)
		for i=1, select(i+1, ...) do yield() end
		-- stop()
	end
	
end

crumbler = obj:extend{}
function crumbler:init(o)
	self:combine(o)
	self.crumbling = false
end

function crumbler:draw(o)
	spr(self.sp, self.x + self.shake, self.y)
end

function crumbler:update()
	if loaded then
		self.crumbling = false
		self.sp = 90
	end
	if not self.crumbling then 
		self.shake = 0
		foreach(player_parts(), function(part)
			check_box = game_obj(self.x, self.y, self.w, self.h+1)
			check_box.yoffs = -1
			if (overlaps(check_box, part)) self:crumble() 
		end)
	end
end

function crumbler:crumble()
	
	-- stop()
	self.crumbling = true
	add_routine(function() 
		if (not self.crumbling) return
		self.sp = 105
		sfx"59"
		delay_frames"20"
		for i=1, 30 do 
			self.shake = (i\2%2) - 1 
			yield() 
		end
		sfx"55"
		anim(self,
			121, 5,
			115, 5,
			0, 60,
			89, 5
		)
		local can_respawn
		repeat 
			can_respawn = true
			foreach(player_parts(), function(part) 
				if (overlaps(self, part)) can_respawn = false 
			end)
			yield() 
		until can_respawn or p.dead 

		anim(self,
			90, 0
		)

		self.crumbling = false
	end)
end

mover = obj:extend{}
function mover:init(o)
	self:combine(o)
	self.vertical = self.sp == obj_table.v_ring or self.sp == obj_table.v_zap
	if (self.sp == obj_table.v_ring or self.sp == obj_table.h_ring) then 
		if self.vertical then self.h *= 2 else self.w *=2 end
	end
	self.dir = 1
	self.timer = 0
	local bgtile = self.vertical and 13 or 112
	mset(self.mapx, self.mapy, bgtile)
	if (self.sp == 74) self.sp = 73
end

function mover:update()
	dx, dy = self.vertical and 0 or self.dir, self.vertical and self.dir or 0 
	for hand in all(player_hands()) do
		if (hand.grabbing == self and not p.dead) then 
			hand.x += dx
			hand.y += dy
		end
	end
	local midx, midy = midpoint(self)
	if (check_map(self, dx, dy, 6) or level_id((midx + dx * 2) \ 128, (midy + dy * 2) \ 128) ~= self.levelid) then
		self.dir = -self.dir
		-- dbg("lvl", level_id((self.x + dx) \ 128, (self.y + dy) \ 128))
	end
	move(self, dx, dy)
	self.timer += 1
end

function mover:draw()
	game_obj.draw(self)
	local dx, dy = self.vertical and 0 or 8, self.vertical and 8 or 0 
	spr(self.sp, self.x + dx, self.y + dy)
end

function mover:associated()
	if (self.twin) return { self, self.twin }
	return { self }
end

zapper = mover:extend{}

function zapper:draw()
	local sp = self.timer\3 % 2 == 0 and self.sp or self.sp + 1 
	spr(sp, self.x, self.y)
end

function zapper:update()
	mover.update(self)
	if (overlaps(self, p)) kill_player(self)
end


key = obj:extend{}

function key:init(o)
	self:combine(o)
	local room = level_id(self.levelx, self.levely)
	self.acquired = false
	if (key_unlocks[room] ~= nil) then
		self.id = key_unlocks[room]
	else
		self.id = room
	end
end

function key:draw()
	if (not self.acquired) spr(self.sp, self.x, self.y + 1 + (sin(time() / 2) * 1.5))
end

function key:update()
	self.acquired = level_doors_unlocked[self.id]
	if (not self.acquired) then
		for obj in all(player_parts()) do
			if (overlaps(self, obj)) self:acquire()
		end
	end
end

function bubble_effect(o, color)
    play_effect(function()
        local seed, x, y = rnd(), midpoint(o)
        for i=1, 15 do
			
            r = lerp(4, 15, ease_out(i/15)) 

            circ(x, y, r, color)
            for j=1, 15 do
                srand(j + seed) 
				local heading = vec:from_angle(flr(rnd(20)) / 20)
				local len = rnd"10" + 7

				local line_end = vec(x, y) + heading * (r + len - i/15) 
				local line_start = line_end - heading * (len * flp(ease_out(i/15))) 
				line(line_start.x, line_start.y, line_end.x, line_end.y, color)
            end
            yield()
        end
    end)
end

function key:acquire()
	sfx"52"
	for o in all(objects_in_camera_level) do
		if (o.type == "checkpoint") o.active = false
	end


	local id = self.id
	level_doors_unlocked[id], level_doors_unlocked[self.levelid], p.keys[id] = true, true, true
	if key_unlocks[id] ~= self.levelid then
		c:show_unlock(id_level(key_unlocks[id]))
	end
	bubble_effect(self, 10)

end

lever = obj:extend{}

function lever:init(x, y)
	local sp = obj_table["lever"]
	local width, height, xoffs, yoffs = unpack(sprite_hitboxes[sp])
	local o = game_obj(x, y, width, height, sp, "lever", xoffs, yoffs)
	self:combine(o)
	self.grabbed = false
	self.grabbed_previous = false
	self.colliding = false
	self.start = self.pos
end

function lever:draw()
	spr(self.sp, self.x, self.y, 1, 1, self.owner.flip_h)
end

function lever:update()
	if (self.levelx ~= p.levelx or self.levely ~= p.levely) return
	self.grabbed_previous = self.grabbed
	self.grabbed = p.l_hand.grabbing.type == "lever" or p.r_hand.grabbing.type == "lever" and self.levelx == p.levelx and self.levely == p.levely
	local just_grabbed = self.grabbed and not self.grabbed_previous
	if (self.pos:dist(self.start) > 10) level_sides_open[self.levelid][self.owner.side] = true
	if (just_grabbed and not is_level_opened(self)) then
		if is_level_unlocked(self) then
			sfx"53"
			self:unlock()
		else
			sfx"58"
		end
	end
	-- locked = p.keys[key_unlocks[]
end

function lever:unlock()
	-- self.owner:unlock()
	self.can_beep = false
	move(self.owner, 0, 1)
	self.owner.opened = true
	level_doors_opened[self.levelid] = true
	
end

function is_level_unlocked(o)
	return level_doors_unlocked[level_id(o.levelx, o.levely)] != nil
end
function is_level_opened(o)
	return level_doors_opened[level_id(o.levelx, o.levely)] != nil
end

door = obj:extend{}

function door:init(o)
	local flip_h = false
	local o = new_actor(o, 2.0, 0.04, 0.07, 0.00, true)
	self:combine(o)
	self.side = "e"
	mset(self.mapx, self.mapy, 13)
	if (self.x - (self.levelx) * 128 < 64) then 
		flip_h = true
		self.side = "w"
	end
	level_sides_open[self.levelid][self.side] = nil
	local s = {
		id = self.levelid,
		lever = lever(self.x, self.y),
		flip_h = flip_h,
		wall = door_wall(unpack_xy(self)),
		bottom = self:get_bottom(),
		locked = true,
		opened = false,
		-- self.yoffs = 1
		can_move = true,
		h = 1,
	}
	self:combine(s)
	self.lever.owner = self
	self.wall.owner = self
	-- self:update()

	
end

function door:dist_to_bottom()
	return abs(self.bottom - self.y)
end

function door:get_bottom()
	for i=0, 127 do
		if (check_map(self, 0, i, 1)) return(self.y + i)
	end
	return 0
end

function door:update()
	self.wall.h = 1
	if (self.locked and level_doors_unlocked[self.levelid] and c.levelid == self.levelid) self:unlock()
	local lever_offs = -self.w
	if (self.flip_h) lever_offs = self.w
	move_to(self.lever, self.x + lever_offs, self.y)
	move_to(self.wall, unpack_xy(self))
	local lever_grabbed = false
	-- self.h = self:dist_to_bottom()
	if (self.lever.grabbed and not self.locked and not check_map(self, 0, self.h, 0)) then
		lever_grabbed = true
		self.colliding = false
		if (p.l_hand.grabbing.type == "lever") p.l_hand.y = self.y
		if (p.r_hand.grabbing.type == "lever") p.r_hand.y = self.y
		
		accel_towards(self, 0, 1)
		
		if (check_map(self, 0, 1, 0)) then 
			self.colliding = true
			self.can_move = false
		elseif (flr(self.y) % 4 == 0) and not self.colliding then
			sfx"54"
			-- c:screenshake(2)
		end
	elseif check_map(self, 0, self.h, 0) and (not self.slammed) then
		self:slam()	
	end
	door_pos = vec(self.mapx, self.mapy)
	update_actor(self)
	self.colliding = false
	self.wall.h = self:dist_to_bottom()
end

function door:unlock()
	self.locked = false
	sfx"62"
	self.wall.timer = 25
	if (self.levelid ~= 22) keys_acquired += 1
	
end

function door:slam()
	self.slammed = true
	sfx(54, -1)
	sfx"57"
	self.colliding = true
	c:screenshake"3"
end

function door:draw()
	spr(self.sp, self.x, self.y, 1, 1, self.flip_h)
end

function door:associated()
	return { self.lever, self.wall, self}
end

door_wall = obj:extend{}

function door_wall:init(x, y)
	local o = game_obj(x, y, 7, 0, 28, "door_wall")
	self.timer = 25
	self:combine(o)
end

function door_wall:draw()
	
	if (c.levelid == self.levelid or self.timer == 0) and not self.owner.locked and (self.timer\4) % 2 == 0 then 
		pal(5, 11)
		pal(2, 3)
	end
	for i=1, self.h\8 do
		spr(self.sp, self.x, self.y + i * 8)
	end
	
	pal()
	-- local h = 8 - (flr(self.h) - self.h)
	-- sspr(96, 8, 8, h, self.x, self.y + self.h - h)
end

function door_wall:update()
	if (self.timer > 0 and not c.transitioning and not self.owner.locked) then 
		self.timer -= 1
	end
end

lock = obj:extend{}

function lock:init(o)
	self:combine(o)
	self.locked = true
	self.timer = 0
end

function lock:draw()
	if (not self.locked) and self.timer <= 4 then 
		pal(5, 11)
		pal(2, 3)
		pal(14, 6)
	end
	spr(self.sp, self.x, self.y)
	pal()
end

function lock:update()
	if (self.locked and level_doors_unlocked[self.levelid]) self:unlock()
	if (self.timer > 0) self.timer -= 1
end 

function lock:unlock()
	self.locked = false
	self.timer = 25
end

checkpoint = obj:extend{}
function checkpoint:init(o)
	self:combine(o)
	self.active = false
end

function checkpoint:update()
	if overlaps(p, self) and not p.dead then 
		if (not self.active) then 
			self:set_checkpoint()
			
		end
	end
	if p.checkpoint_x ~= self.x and p.checkpoint_y ~= self.y then
		self.active = false
	end
	
	-- dbg("checkpoint", p.checkpoint_x, p.checkpoint_y)
end

function checkpoint:draw()
	if self.initiated then 
		if self.active then pal(2, 11)
		else pal(2, 3)
		end
	end
	spr(self.sp, self.x, self.y)
	pal()
end

function checkpoint:effect()
	sfx"61"
	kickup_dust(60, 40, 4, 20, vec(self.x + 4, self.y + 4), 11, 3, 1, 7, 7)
end

function checkpoint:set_checkpoint()
	self:effect()
	save_state()
	self.active, self.initiated = true, true
	
	p.checkpoint_x, p.checkpoint_y, p.checkpoint = self.x, self.y, self

end

function update_player()
	if (p.dead) return
	-- for i=1, 30 do flip() end
	local dx = 0
	p.can_jump = true
	
	if (p.dink_timer > 0) p.dink_timer -= 1
	if(controls.l) dx -= 1
	if(controls.r) dx += 1
	if(controls.d) dx /= 2.5
	cursor.angle += (dx / 45)
	-- if(x) debug = (debug + 1) % 3

	update_actor(p)
	-- death 
	foreach(player_parts(), function(o) 
		if (fget(o.colliding_with, 5)) then
			kill_player(o)
			return
		end
	end)
	p.facing = -1
	if (cursor.angle > 0.5) p.facing = 1
	if (controls.u and p.can_jump) jump(p)
	local grabbing = p.l_hand.state == "grabbing_wall" or p.r_hand.state == "grabbing_wall"
	
	if grabbing then
		p_arms_length = 34 * 0.75
		local avghands = avg_pos(player_hands())
		local dist = (avghands - p.pos)
		local dl = dist:mag()
		local dxy = dist:norm()
		if (dl >= 1) accel_towards(p, dxy.x, dxy.y)

		if ((avghands - p.pos - p.vel):mag() > dl) apply_fric(p, 0.4)
	else 
		p_arms_length = 34
	end
	update_hand(p.l_hand)
	update_hand(p.r_hand)
	p.face_x, p.face_y, p.facing = p.prev.x + 6, p.prev.y, sgn(cursor.angle - 0.5)
end

function kill_player(o)	
	if (p.dead) return
	deaths += 1
	local cp = p.checkpoint
	p.dead = true
	add_routine(function()
		p.eye_state, p.mouth_state = "open", "open"
		
		sfx"60"
		c:screenshake(3, 1, 6)
		play_effect(function() 
				for i=1, 6 do 
					pal(0, 0, 1)
					pal(1, 1, 1)
					for i=0, 2 do 
						pal(i, 2,1) 
					end 
				yield() 
			end 
			pal()
		end)
		music(-1)
		bubble_effect(o, 7)
		for i=1, 45 do
			if (i == 40) fade(10)
			yield()
		end
		p.checkpoint:effect()
		music(0, 0, 2) 
		new_player(p.checkpoint_x, p.checkpoint_y)	
		p.checkpoint = cp
		c:end_transition()
		move_to(c, level_quantize(p.x, p.y))
		load_state()
	end)

end 

function fade(t)
	play_effect(function() for i=1,t do
		fillp(▒)
		if (i > 4 and i <= t - 4) fillp(█)
		camera(0, 0)
		rectfill(0, 0, 128, 128, 0)
		fillp(█)
		yield()
		end 
	end)
end

function load_state() 
	local id = p.levelid
	local map_state = copy(map_state)
	level_doors_unlocked, level_doors_opened, obj_array, objects_in_camera_level, keys_acquired, loaded  
		= map_state.unlocked, map_state.opened, map_state.objs, map_state.objects_in_same_level, keys_acquired_saved, true
	
end

function player_parts()
	return {p, p.l_hand, p.r_hand}
end 

function player_hands()
	return {p.l_hand, p.r_hand}
end 

function update_hand(hand)
	-- hand.grabbing = { sp = 0 }
	local hold_btn, launch_button, prev_hold_btn = controls.lh, controls.lhp, lh_prev
	
	local hands_x_target = p.x + ceil(p.w/2)
	local hand_x_target = hands_x_target + 10 - 7
	if (hand.side == "right") then 
		hold_btn, launch_button, prev_hold_btn = controls.rh, controls.rhp, rh_prev
		hand_x_target = hands_x_target - 10
	end
	local hands_y_target = p.y + 3  
	local dx, dy = hand_x_target - hand.x, hands_y_target - hand.y

	local max_dist = false
	local shoulder_pos, overlapping_wall = vec(hand_x_target, hands_y_target), check_map(hand, 0, 0, 0)
	if (overlapping_wall) shoulder_pos = vec(midpoint(p))
  	hand.anchor = shoulder_pos
	local p_pos, hand_pos = vec(unpack_xy(p)), vec(unpack_xy(hand))
	local arm_length = shoulder_pos:dist(hand_pos)
	local too_long = arm_length >= p_arms_length
	if (too_long) then 
		local vel = hand.vel
		transferred = (vel:norm() - (hand_pos - shoulder_pos):norm()) * vel:mag()
		reset_vel(hand)
		-- apply_force(hand, transferred)
		-- reset_vel(p)
		accel_towards(hand, p.x - hand.x, p.y - hand.y)
		if (p.grounded) apply_force(p, vec(hand.x - p.x, hand.y - p.y):norm() * 0.15)
	end

	-- "state machine" here
	local hand_states = {
		idle = function()
			if (too_long) then
				hand_change_state(hand, "returning")
				return
			end 
			if (not overlapping_wall) hand.colliding = true
			-- check for launch
			if (launch_button) hand_change_state(hand, "launch")	
				accel_towards(hand, shoulder_pos.x - hand.x, shoulder_pos.y - hand.y)
				update_actor(hand)
		end,


		launch = function()
			local p_launch_time_min = 6
			if (toggle) p_launch_time_min = 12
			-- dbg("velx", hand.accel.x)
			local heading = vec:from_angle(cursor.angle)
			if too_long then
				if (hand.launch_timer > p_launch_time_min) then
					local new_hand_pos = (hand_pos - shoulder_pos):norm() * p_arms_length + shoulder_pos
					if (not hold_btn or toggle) hand.colliding = true
	
					-- TODO: subtract from heading to get just the rotational vector if
					-- arms are too long
					local r = (hand_pos - shoulder_pos)
					local e = (r + heading)
					local d = e - e:norm() * (e:mag() - p_arms_length) - r

					heading = d
			end
			else 
				
				apply_force(hand, heading * hand.accel_spd * 30)

			end

			apply_force(hand, heading * abs(p.vel.y))
			local dx, dy = unpack_xy(hand.vel)
			local dxy = vec(dx, dy)
			function about_to(type)
				return check_map(hand, dx, dy, type)
			end
			local time_passed = 300 - hand.launch_timer
			local about_to_hit, about_to_die, about_to_grab = about_to(0), about_to(5), about_to(1)
			local about_to_dink = about_to_hit and not about_to_grab
			if (not about_to_dink and p.l_hand.state ~= "grabbing_wall" and p.r_hand.state ~= "grabbing_wall") move(hand, 0, p.vel.y / 2)
			if (about_to_die) return kill_player(hand)
			if (about_to_hit and not about_to_grab) hand.colliding = true
			
			if ((about_to_hit and time_passed >= 2) or (time_passed >= 3)) and (hold_btn or toggle) and not controls.d and about_to_grab then
				move(hand, dx, dy)
				hand_change_state(hand, "grabbing_wall")
				return
			end
			if about_to_dink then
				if (p.dink_timer <= 0) then
					sfx"56"
					p.dink_timer = 2 + rnd(4)
				end
				if (dx == 0 and dy == 0) then
					hand_change_state(hand, "returning")
					return
				end
			end
			if (hand.launch_timer <= 0) or (hand.launch_timer <= 300 - p_launch_time_min and not hold_btn) then 
				hand_change_state(hand, "returning")
				return
			end
			update_actor(hand)
			hand.launch_timer -= 1
		end,


		grabbing_wall = function()
			local end_grab = ((launch_button and not prev_hold_btn) and toggle) or not (hold_btn or toggle)
			if (end_grab or not fget(hand.grabbing.sp, 1)) hand_change_state(hand, "returning")
			local about_to_die =  check_map(hand, 0, 0, 5)
			-- if about_to_die then
			-- 	hand.colliding_with = about_to_die
			-- 	kill_player(hand)
			-- end
		end,


		returning = function()
			local diff = (shoulder_pos - hand)
			local dx, dy = diff.x, diff.y
			move_towards(hand, shoulder_pos)
			local dist = vec(unpack_xy(hand)):dist(shoulder_pos)
			if (dist < 16) then
				reset_vel(hand)
				apply_force(hand, diff:norm())
				hand_change_state(hand, "idle")
			end
			-- update_actor(hand)
		end,
	}
	hand_states[hand.state]()
end

function hand_change_state(hand, state)
	if (hand.state == "grabbing_wall") then 
		hand.grabbing = {}
	end

	if (hand.state == "launch") then 
		hand.launch_timer = 0
		sfx(49, -2)
	end

	hand.state = state

	if state == "idle" then
	elseif state == "launch" then
		sfx"49"
		hand.launch_timer = 300
		hand.vel = vec()
		hand.colliding = false
		local dxy = vec:from_angle(cursor.angle) * hand.spd
		apply_force(hand, dxy)
	elseif state == "grabbing_wall" then
		
		hand.grabbing = check_grab(hand)
		sfx"50"
		reset_vel(hand)
	elseif state == "returning" then
		hand.colliding = false
	end
end

function jump(a)
	a.y -= 1
	a.can_jump = false
	sfx"51"
	apply_force(a, vec(p.facing * 0.26, -0.86))
end

function set_player_palette()
	c1, c2, c3, c4, c5 = unpack(player_palette_swaps[player_palette])
	pal(8, c1)
	pal(2, c2)
	pal(14, c3)
	pal(11, c4)
	pal(3, c5)
end

function draw_player(palette)
	if (not palette) set_player_palette()
	foreach(player_hands(), draw_player_arm)
	spr(1, p.x, p.y, 1.57, 1.43, p.facing <= 0)
	draw_player_face()
	foreach(player_hands(), draw_player_hand)
	pal()
	if (not palette) draw_cursor()
	
end

function draw_player_arm(hand)
	local x_offset = 10/2
	if (hand.side == "right") x_offset = -x_offset
	for i=1, 15 do
		local p_midx, p_midy = midpoint(p)
		local h_midx, h_midy = midpoint(hand)
		local x = lerp(p_midx + x_offset, h_midx, i/15)
		local y = lerp(p_midy, h_midy, i/15)
		circfill(x, y, (sin(1 - i/15)/2 + 3), 8)
	end
end

function draw_player_hand(hand)
	-- local hspr = 4 -- default
	local flip_h, flip_v = false, false

   		local dir = vec(unpack_xy(hand)) - vec(unpack_xy(hand.anchor))
		if (hand.side == "right") then 
     		 dir.x = -dir.x
      		flip_h = true
    	end
		if (hand.state == "idle") then
		dir.x = -dir.x
		-- fist = true
		end
			local angle = dir:to_angle()
		hand.angle = angle
		local draw_angle
		if hand.angle_timer > 0 then 
			draw_angle = hand.draw_angle
		else 
			draw_angle = determine_draw_angle(angle)
			hand.draw_angle = draw_angle
			hand.angle_timer = 10
		end
			-- local sp = () 
		if (hand.state == "grabbing_wall" or hand.state == "grabbing_object") then
		hspr = fist_sprites[draw_angle]
		else
		hspr = hand_sprites[draw_angle]
		end

	spr(hspr, hand.x, hand.y, 1, 1, flip_h, flip_v)
	-- dbg("hangletimer", hand.angle_timer)
	if (hand.angle_timer > 0) hand.angle_timer -= 1
end

function determine_draw_angle(angle)
	return cardinals[flr(angle * 8)]
end

function draw_player_face()
	local face_x, face_y = p.face_x, p.face_y
	
	function go(t, x, fl)
		spx, spy, spw, sph, yoffs = unpack(t)
		sspr(spx, spy, spw, sph, x, face_y + yoffs, spw, sph, fl)
	end
	-- mouth
	local mouth_t = mouth_spr_positions[p.mouth_state]
	go(mouth_t, face_x + -(mouth_t[3])\2)
	

	-- eyes
	local eye_t = eye_spr_positions[p.eye_state]
	local elx, erx = face_x - p.w/2 + 1, face_x + p.w/2 - 1 - eye_t[3]
	go(eye_t, elx)
	go(eye_t, erx, true)
end

function new_actor(o, spd, fric, accel_spd, grav, colliding)
	if (colliding == nil) colliding = true
	a = {
		spd = spd,
		vel = vec(),
		accel = vec(),
		fric = fric,
		grav = grav,
		accel_spd = accel_spd,
		grounded = false,
		facing = 0,
		colliding = colliding,
		platform_colliding = false,
		prev = vec()
	}


	o:combine(a)
	return o
end

function accel_towards(a, dx, dy)
	local accel = a.accel_spd
	if (abs(a.vel.x) < a.spd) apply_force(a, vec(dx * accel, dy * accel))

end

function apply_force(a, f)
	a.accel = a.accel + f
end

function apply_fric(a, mag)
	local fric = a.vel:norm() * -mag
	if (a.type == "player" or a.type == "hand") fric.y = fric.y/4
	apply_force(a, fric)
end

function update_actor(a)

	if (not a.colliding) a.grounded = false
	a.can_jump = a.grounded
	local mag = a.vel:mag()
	if mag >= 0.02 then 
		apply_fric(a, a.fric)
	else
		a.vel = vec()
	end
	if (not a.grounded) apply_force(a, vec(0, a.grav))
	a.vel += a.accel
	a.prev = vec(unpack_xy(a))
	local spd = a.vel:mag()
	local nv = a.vel / spd -- normalized
	if (spd > a.spd) then 
		a.vel = nv * a.spd
	end
	-- apply remainder of floored velocity first
	-- so we can apply the rest of the integer
	-- velocity in sub-steps
	move_and_slide(a, unpack_xy(a.vel))
	a.accel = vec()

end

function reset_vel(a)
	a.vel = vec()
	a.accel = vec()
end

function move_and_slide(a, dx, dy)
	if (a.colliding) then
		local grounded = (check_map(a, 0, abs(a.vel.y), 0))
		if (a.type == "player") then
			local collision
			if (a.grounded) then 
				collision = check_map(a, dx, 1)
			else 
				collision = check_map(a, dx, dy)
			end
			if (collision) a.colliding_with = collision
			if grounded and not a.grounded and a.vel.y >= a.spd - 1 then 
				a.grounded = grounded
				kickup_dust(50, 30, 3, 7, vec(midpoint(a)), 4, 5, 1, 7, 15)
				sfx"48"
				c:screenshake(2)
			end
		end
		a.grounded = grounded
		
		if (not grounded or dy <= 0) and try_move(a, dx, dy) then 
			return true
		elseif not grounded and dy ~= 0 and try_move(a, 0, dy) then 
			if (abs(a.vel.x) > a.accel_spd) a.vel.x = a.vel:norm().x * 0.05
			return true
		elseif dx ~= 0 and try_move(a, dx, 0) then 
			if (abs(a.vel.y) > a.accel_spd) a.vel.y = 0
			return true
		end
		a.vel = vec()
		return false
	else 
		move(a, dx, dy)
		return true
	end
end

function move_towards(o1, o2)
	-- unconditionally move thru obj_map
	dx = (o2.x - o1.x) / 4 -- idk why 4
	dy = (o2.y - o1.y) / 4
	move_and_slide(o1, dx, dy)
end

function try_move(o, dx, dy)
	local can_move = not check_map(o, dx, dy, 0)
	if (can_move) move(o, dx, dy)
	return can_move
end


function check_map(o, dx, dy, flag)
	-- if (o.levelid ~= p.levelid) return false
	-- local start = stat(1)
	local o_dest = {
		x = o.x + dx, 
		y = o.y + dy, 
		w = o.w, 
		h = o.h,
		xoffs = o.xoffs,
		yoffs = o.yoffs,
	}
	-- o.checked = o.dest
	update_map_coords(o_dest)
	
	-- don't fetch nearby walls again
	-- if we've already checkeds for this tile
	if o.near_last.x ~= o_dest.x or o.near_last.y ~= o_dest.y then
		o.nearby = nearby(o_dest)
		o.near_last = o_dest
	end
	for i=1, #o.nearby do 
		local sp = o.nearby[i].sp
		if fget(sp, flag) and overlaps(o_dest, o.nearby[i]) then
			return sp
		end
	end
	
	return false
end

function check_grab(o)
	for i, w in ipairs(o.nearby) do 
		if fget(w.sp, 1) and overlaps(o, w) then
			return w
		end	
	end
	local o = game_obj(0, 0, 0, 0)
	return o
end

function move(o, dx, dy)
	local dest_x = o.x + dx
	local dest_y = o.y + dy
	if (dest_x >= 0 and dest_x < 1024) o.x = dest_x
	if (dest_y >= 0 and dest_y < 512) o.y = dest_y
	update_map_coords(o)
	if (dx ~= 0) o.facing = sgn(dx)
end

function move_to(o, x, y)
	o.x = x
	o.y = y
	update_map_coords(o)
end 

function overlaps(o1, o2)
	local o1x = o1.x + o1.xoffs 
	local o1y = o1.y + o1.yoffs 
	local o2x = o2.x + o2.xoffs 
	local o2y = o2.y + o2.yoffs 
	return (o1x < o2x + o2.w) 
	      and (o1x + o1.w > o2x) 
	      and (o1y < o2y + o2.h) 
	      and (o1y + o1.h  > o2y)
end

function tile_at(x, y)
	return game_obj(x,y, 8, 8, mget(x \ 8, y \ 8))
end


function nearby(o)

	local ws = {}
	local mapx, mapy = o.mapx, o.mapy
	local ox, oy, ow, oh, omw, omh
	= o.x, o.y, o.w, o.h, o.x + o.w/2, o.y + o.h/2
	local points = {
		ox, oy,
		ox + ow, oy,
		ox + ow, oy + oh,
		ox, oy + oh,
 		omw, omh,

	}
	if ow > 7 then
		add(points, omw)
		add(points, oy + oh)
		add(points, omw)
		add(points, oy)
	end
	if oh > 7 then
		add(points, ox + ow)
		add(points, omh)
		add(points, ox)
		add(points, omh)
	end
	
	
	for i= 1, #points, 2 do
		
		local x, y = points[i], points[i + 1]
		local cx, cy = x \ 8, y \ 8
		local sp = mget(cx, cy)
		local width, height, xoffs, yoffs = unpack(sprite_hitboxes[sp])
		-- TODO: make this a lookup table?
		local w = game_obj(cx * 8 + xoffs, cy * 8 + yoffs, width, height, sp)
		if (fget(w.sp) ~= 0x0) add(ws, w)
		
	end
	
	local os = objects_in_same_level(o)
	for i=1, #os do
		if (os[i] ~= o and os[i].levelid == o.levelid) add(ws, os[i])
	end
	if o.type ~= "player" then 
		foreach(player_parts(), function(x) add(ws, x) end)
	end
	
	return ws
end

function update_map_coords(o)
	o.mapx = (o.x + o.w\2 + o.xoffs) \ 8
	o.mapy = (o.y + o.h\2 + o.xoffs) \ 8
	o.levelx = (o.mapx) \ 16
	o.levely = (o.mapy) \ 16
	o.levelid = level_id(o.levelx, o.levely)
	o.pos = vec(o.x, o.y)
end


vec = obj:extend{x = 0, y = 0}

function vec:init(x, y)
	self.x, self.y = x or 0, y or 0
end

function vec:__add(v)
	return vec(self.x + v.x, self.y + v.y)
end

function vec:__sub(v)
	return self + vec(-v.x, -v.y)
end

function vec:__mul(sc)
	return vec(self.x * sc, self.y * sc)
end

function vec:__div(sc)
	return self * (1/sc)
end

function vec:mag()
	return (self:dist(vec()))
end

function vec:norm()
	return (self / self:mag())
end

function vec:dist(v)
	return sqrt((self.x - v.x)^2 + (self.y - v.y)^2)
end

function vec:from_angle(theta)
	return vec(sin(theta), cos(theta))
end

function vec:to_angle()
	return atan2(unpack_xy(self))
end

function lerp(a,b,t) 
	return a + (b - a) * t 
end

function flp(x) -- flip
	return 1 - x
end

function ease_in_out(t)
	return lerp(t^2, flp(flp(t)^2), t)
end

function ease_out(t)
	return lerp(t, flp(flp(t)^5), t)
end

function unpack_xy(o) 
	return o.x, o.y
end

function delay_frames(f, callback)
	for i=1, f do
		if (callback) callback()
		yield()
	end
end

function freeze_frames(f)
		for i=1, f do flip() end
end

function avg_pos(t)
	local sum
	for i, o in ipairs(t) do
		local pos = vec(o.x, o.y)
		if sum == nil then sum = pos else sum += pos end
	end
	return sum / #t
end

function midpoint(o)
	return o.x + o.w/2, o.y + o.h/2
end

function copy(obj, seen)
  -- https://stackoverflow.com/a/26367080
  if (type(obj) ~= 'table') return obj
  if (seen and seen[obj]) return seen[obj]
  local s, res = seen or {}, setmetatable({}, getmetatable(obj))
  s[obj] = res
  for k, v in pairs(obj) do res[copy(k, s)] = copy(v, s) end
  return res
end
-- function sin(theta)
-- 	return sin(theta/360)
-- end
-- function sin(theta)
-- 	return cos(theta/360)
-- end