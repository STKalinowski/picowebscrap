-- 2 and 1/2 men
-- by virgill, cons, slimey

--------------------------------
-- alcatraz : 2 and 1/2 men 
-- code by virgill
-- graphics by cons
-- music by slimey
--------------------------------

timer = 0.1
--music
musicflag1 = 0
musicflag2 = 0

--rotsprites
t = 0
t2= 0

--vector
vectimer = 0
veccoltab = {1,5,1,2,6,7,7}

--sinescroll
sin_mii = 0
sin_timer = 0
sin_timer2 =0

--raster
linex1 = 0
liney1 = 0
linex2 = 127
liney2 = 127
rottimer = 0.25
flashtimer = 0
copytimer = 0
rastertimer = 0

--rotzoom
rotzoomtimer = 0

--towers
towtimer = 0

--chaoszoom
chtimer = 0
chaoscoltab= {1,2,1,2,1,2,5,6,5,6,5,6,2,1,2,1}
chflag = false
chcam = 90

--logo
beat = 0
beatflag = 0
beatnu = 0

--borders
borderx = 16
bordery = 111
bordertime = 0

-- timing
scene0 = 1.0 --logo
scene1 = 2.0 --vector
scene2 = 3.0 --flash+filling rasters
scene3 = 3.55--spare
scene4 = 3.75--spare
scene5 = 4.5 --rotate rasters
scene6 = 5.5 --rotate rasters 3d
scene7 = 7.0 --rotate rasters with fadeout
scene8 = 7.5 --rotzoom with fade in
scene9 = 9.5 --todo:transition
scene10=11.0	--rotsprites layer1
scene11=12.0 --rotsprites layer2
scene12=13.5 --todo:transition
scene13=14.0 --towers
scene14=16.5 --chaoszoom1
scene15=19.0	--chaoszoom2
scene16=20.97--end

-- rotobar colors
r_space = {}
r_bar   = {0,0,1,0,1,5,12,13,7,7,13,12,5,1,0,1,0,0}
r_back  = {0,0,
5,8,5,8,9,10,7,7,10,9,8,5,8,5,0,0,
5,8,5,8,9,10,7,7,10,9,8,5,8,5,0,0,
5,8,5,8,9,10,7,7,10,9,8,5,8,5,0,0,
5,8,5,8,9,10,7,7,10,9,8,5,8,5,0,0,
5,8,5,8,9,10,7,7,10,9,8,5,8,5,0,0,
5,8,5,8,9,10,7,7,10,9,8,5,8,5,0,0,
5,8,5,8,9,10,7,7,10,9,8,5,8,5,0,0,
5,8,5,8,9,10,7,7,10,9,8,5,8,5,0,0,
5,8,5,8,9,10,7,7,10,9,8,5,8,5}


circtab={0,0,0,0,1,0,1,1,1,1,5,1,5,5,5,5,2,5,2,2,2,2,6,2,6,6,6,6,7,6,7,7,7,7}

cube = {{{-1,-1,-0.1}, 
         {-1,-1, 0.1},
         { 1,-1, 0.1},
         { 1,-1,-0.1},
         {-1, 1,-0.1},
         {-1, 1, 0.1},
         { 1, 1, 0.1},
         { 1, 1,-0.1}},
        {{1,2},                    
         {2,3}, 
         {3,4},
         {4,1},
         {5,6},
         {6,7},
         {7,8},
         {8,5},
         {1,5},
         {2,6},
         {3,7},
         {4,8}}}

local fadetable={
 {0,0,1,1,5,5,5,13,13,13,6,6,6,6,7},
 {1,1,5,5,13,13,13,13,13,6,6,6,6,6,7},
 {2,2,2,13,13,13,13,13,6,6,6,6,6,7,7},
 {3,3,3,3,13,13,13,13,6,6,6,6,6,7,7},
 {4,4,4,4,4,14,14,14,15,15,15,15,15,7,7},
 {5,5,13,13,13,13,13,6,6,6,6,6,6,7,7},
 {6,6,6,6,6,6,6,6,7,7,7,7,7,7,7},
 {7,7,7,7,7,7,7,7,7,7,7,7,7,7,7},
 {8,8,8,8,14,14,14,14,14,14,15,15,15,7,7},
 {9,9,9,10,10,10,15,15,15,15,15,15,15,7,7},
 {10,10,10,10,10,15,15,15,15,15,15,15,7,7,7},
 {11,11,11,11,11,11,6,6,6,6,6,6,6,7,7},
 {12,12,12,12,12,12,6,6,6,6,6,6,7,7,7},
 {13,13,13,13,6,6,6,6,6,6,6,6,7,7,7},
 {14,14,14,14,14,15,15,15,15,15,15,7,7,7,7},
 {15,15,15,15,15,15,15,7,7,7,7,7,7,7,7}
}

fadetimer  = 16
fadetimer2 = 16 
fadetimer3 = 0
fadetimer4 = 16
fadetimer5 = 16
----------------------------------
function fade(i) --from the pico-8 forum
 for c=0,15 do
  if flr(i+1)>=16 then
   pal(c,7)
  else
   pal(c,fadetable[c+1][flr(i+1)])
  end
 end
end


function drawlogo()
 spr(128,2,50*-cos(timer)+4*sin(towtimer),32,4)
end


logocirctab = {1,2,5,13,6,13,7,13,6,13,5,2,1,0}
function logocircles()
 for x=0,63 do
  circfill(63+59*sin(4*timer+x/32),20+50*-cos(timer)+4*sin(towtimer)+19*sin(timer*2.2+x/22),2*sin(x/12+timer*3)+3,logocirctab[(flr(timer*100)+x)%15+1])
 end
end

function drawlogo2()
	spr(128,2,52-20*cos(timer)+4*sin(towtimer),32,4)
end

function credits()
	spr(224,0,114,32,2)
end


function sline(x1,y1,x2,y2,col)
	line(x1,y1,x2,y2,col)
	line(x1+1,y1,x2+1,y2,col)
	line(x1,y1+1,x2,y2+1,col)
	line(x1-1,y1,x2-1,y2,col)
	line(x1,y1-1,x2,y2-1,col)
end

function copytable()
	copytimer+=1
	for i=1,copytimer do
		r_space[i]=r_back[i]
 end
end

function cleartable()
	for i=1,128 do
		r_space[i]=0
	end
end

function copybar(pos)
	for i=1,18 do
		r_space[pos+i]=r_bar[i]
	end
end

function rotatetable()
 merk = r_back[1]
 for v=1,128 do
  r_back[v]=r_back[v+1]
	end
	r_back[128]=merk
end

function drawborder(x,y)
	rectfill(0,0,x,127,1)
	rectfill(0,0,127,x,1)
	rectfill(127,127,y,0,1)
	rectfill(127,127,0,y,1)
 line(x,x,x,y,7)
 line(x,x,y,x,7)
 line(y,x,y,y,7)
 line(x,y,y,y,7)
end

function drawflash()
 flashtimer = flashtimer +1
	rectfill(17,17,110,110,r_bar[flashtimer+7])
end

function draw_shape(s,col)
	for l in all(s[2]) do -- for each line in the shape
		draw_line(s[1][l[1]],s[1][l[2]],col)
	end
end

function draw_line(p1,p2,c)
	x0,y0=project(p1) --get the 2d location of the 3d points..
	x1,y1=project(p2)
	line(x0,y0,x1,y1,c) --draw line
end	
	
function project(p)
	x=(p[1]-cam[1])*mult/(p[3]-cam[3])+127/2
	y=-(p[2]-cam[2])*mult/(p[3]-cam[3])+127/2
	return x,y
end


function rotate_shape(s,a,r)
	ns = {{},s[2]}
	for p in all(s[1]) do -- for each point in the original shape...
 	add(ns[1], rotate_point(p,a,r))
	end
	return ns 
end

function rotate_point(p,a,r) -- from the pico-8 magazine
	 x,y,z = 1,3,2
	_x = cos(r)*(p[x]) - sin(r) * (p[y])
	_y = sin(r)*(p[x]) + cos(r) * (p[y])
	np = {}
	np[x] = _x
	np[y] = _y
	np[z] = p[z]
	return np 
end


function rotzoom()
 local stimer = sin(timer)
 local ctimer = cos(timer)
	local sintimer=sin(timer*1.4)+1.1
 for zx=8,55 do
 	local zxdouble =zx*2
  local zxsin=zx*stimer
  local zxcos=zx*ctimer
  for zy=17,110 do
  	local zyperc=zy%2
  	local zydif =zy/2
  	local u = (zxcos+zydif*-stimer)*sintimer
  	local v = (zxsin+zydif* ctimer)*sintimer
  	u = u%64
  	v = v%64
 	 local col=sget(u,v)
  	pset(zxdouble+zyperc,zy,col)
  	pset(zxdouble-zyperc+1,zy,col/4)
  end
	end
end

-- rotate sprite (from the pico-8 forums)
function spra(angle,n,x,y,w,h,flip_x,flip_y)
 if w==nil or h==nil then
  w,h=8,8
 else
  w=w*8
  h=h*8
 end
 local diag,w,h=flr(sqrt(w*w+h*h))/2,w/2,h/2
 flip_x,flip_y=flip_x and -1 or 1,flip_y and -1 or 1
 local cosa,sina,nx,ny=cos(angle),sin(angle),n%16*8,flr(n/16)*8
 for i=-diag,diag do
  for j=-diag,diag do
   local ox,oy=(cosa*i + sina*j),(cosa*j - sina*i)
   if ox==mid(-w,ox,w) and oy==mid(-h,oy,h) then
    local col=sget(ox+w+nx,oy+h+ny)
    if col!=0 then
     sset(x+flip_x*i+w,y+flip_y*j+h,col)
    end
   end   
  end
 end
end


function rotsprites()
 t+=0.003+0.02*(sin(t2*0.7))
 t2+=0.003
	for x=0, 31 do
		for y=0, 31 do
			sset(x,y,0)
		end
	end
 spra(t,8,4,4,3,3)
--lower layer  
	if timer>=scene11 then
	pal(3,1)
	pal(5,5)
	pal(6,5)
	pal(7,6)
	pal(11,5)
	yv=sin(t2*5)*26
	xv=cos(t2*3)*26
	spr(0,48+yv,48+xv,4,4)
	spr(0,48+yv+sin(t)*23,48+xv-cos(t)*23,4,4)
	spr(0,48+yv+sin(t)*46,48+xv-cos(t)*46,4,4)
	spr(0,48+yv-sin(t)*23,48+xv+cos(t)*23,4,4)
	spr(0,48+yv-sin(t)*46,48+xv+cos(t)*46,4,4)
	spr(0,48+yv+sin(t+0.25)*23,48+xv-cos(t+0.25)*23,4,4)
	spr(0,48+yv+sin(t+0.25)*46,48+xv-cos(t+0.25)*46,4,4)
	spr(0,48+yv-sin(t+0.25)*23,48+xv+cos(t+0.25)*23,4,4)
	spr(0,48+yv-sin(t+0.25)*46,48+xv+cos(t+0.25)*46,4,4)
	spr(0,48+yv+sin(t+0.375)*33,48+xv-cos(t+0.375)*33,4,4)
	spr(0,48+yv+sin(t+0.375)*65,48+xv-cos(t+0.375)*65,4,4)
	spr(0,48+yv-sin(t+0.375)*33,48+xv+cos(t+0.375)*33,4,4)
	spr(0,48+yv-sin(t+0.375)*65,48+xv+cos(t+0.375)*65,4,4)
	spr(0,48+yv+sin(t-0.375)*33,48+xv-cos(t-0.375)*33,4,4)
	spr(0,48+yv+sin(t-0.375)*65,48+xv-cos(t-0.375)*65,4,4)
	spr(0,48+yv-sin(t-0.375)*33,48+xv+cos(t-0.375)*33,4,4)
	spr(0,48+yv-sin(t-0.375)*65,48+xv+cos(t-0.375)*65,4,4)
	spr(0,48+yv-sin(t-0.325)*52,48+xv+cos(t-0.325)*52,4,4)
	spr(0,48+yv-sin(t+0.325)*52,48+xv+cos(t+0.325)*52,4,4)
	spr(0,48+yv+sin(t-0.325)*52,48+xv-cos(t-0.325)*52,4,4)
	spr(0,48+yv+sin(t+0.325)*52,48+xv-cos(t+0.325)*52,4,4)
	spr(0,48+yv-sin(t-0.425)*52,48+xv+cos(t-0.425)*52,4,4)
	spr(0,48+yv-sin(t+0.425)*52,48+xv+cos(t+0.425)*52,4,4)
	spr(0,48+yv+sin(t-0.425)*52,48+xv-cos(t-0.425)*52,4,4)
	spr(0,48+yv+sin(t+0.425)*52,48+xv-cos(t+0.425)*52,4,4)
-- shadow layer 
 pal(3,0)
	pal(5,0)
	pal(6,0)
	pal(7,0)
	pal(11,0)
	yv=sin(t2*5+0.11)*26
	xv=cos(t2*3+0.11)*26
	spr(0,48+yv,48+xv,4,4)
	spr(0,48+yv+sin(t)*23,48+xv-cos(t)*23,4,4)
	spr(0,48+yv+sin(t)*46,48+xv-cos(t)*46,4,4)
	spr(0,48+yv-sin(t)*23,48+xv+cos(t)*23,4,4)
	spr(0,48+yv-sin(t)*46,48+xv+cos(t)*46,4,4)
	spr(0,48+yv+sin(t+0.25)*23,48+xv-cos(t+0.25)*23,4,4)
	spr(0,48+yv+sin(t+0.25)*46,48+xv-cos(t+0.25)*46,4,4)
	spr(0,48+yv-sin(t+0.25)*23,48+xv+cos(t+0.25)*23,4,4)
	spr(0,48+yv-sin(t+0.25)*46,48+xv+cos(t+0.25)*46,4,4)
	spr(0,48+yv+sin(t+0.375)*33,48+xv-cos(t+0.375)*33,4,4)
	spr(0,48+yv+sin(t+0.375)*65,48+xv-cos(t+0.375)*65,4,4)
	spr(0,48+yv-sin(t+0.375)*33,48+xv+cos(t+0.375)*33,4,4)
	spr(0,48+yv-sin(t+0.375)*65,48+xv+cos(t+0.375)*65,4,4)
	spr(0,48+yv+sin(t-0.375)*33,48+xv-cos(t-0.375)*33,4,4)
	spr(0,48+yv+sin(t-0.375)*65,48+xv-cos(t-0.375)*65,4,4)
	spr(0,48+yv-sin(t-0.375)*33,48+xv+cos(t-0.375)*33,4,4)
	spr(0,48+yv-sin(t-0.375)*65,48+xv+cos(t-0.375)*65,4,4)
	spr(0,48+yv-sin(t-0.325)*52,48+xv+cos(t-0.325)*52,4,4)
	spr(0,48+yv-sin(t+0.325)*52,48+xv+cos(t+0.325)*52,4,4)
	spr(0,48+yv+sin(t-0.325)*52,48+xv-cos(t-0.325)*52,4,4)
	spr(0,48+yv+sin(t+0.325)*52,48+xv-cos(t+0.325)*52,4,4)
	spr(0,48+yv-sin(t-0.425)*52,48+xv+cos(t-0.425)*52,4,4)
	spr(0,48+yv-sin(t+0.425)*52,48+xv+cos(t+0.425)*52,4,4)
	spr(0,48+yv+sin(t-0.425)*52,48+xv-cos(t-0.425)*52,4,4)
	spr(0,48+yv+sin(t+0.425)*52,48+xv-cos(t+0.425)*52,4,4)
 end 
-- upper layer
	pal(3,3)
	pal(5,5)
	pal(7,7)
	pal(6,6)
	pal(11,11)
	yv=sin(t2*5+0.1)*26
	xv=cos(t2*3+0.1)*26
	spr(0,48+yv,48+xv,4,4)
	spr(0,48+yv+sin(t)*23,48+xv-cos(t)*23,4,4)
	spr(0,48+yv+sin(t)*46,48+xv-cos(t)*46,4,4)
	spr(0,48+yv-sin(t)*23,48+xv+cos(t)*23,4,4)
	spr(0,48+yv-sin(t)*46,48+xv+cos(t)*46,4,4)
	spr(0,48+yv+sin(t+0.25)*23,48+xv-cos(t+0.25)*23,4,4)
	spr(0,48+yv+sin(t+0.25)*46,48+xv-cos(t+0.25)*46,4,4)
	spr(0,48+yv-sin(t+0.25)*23,48+xv+cos(t+0.25)*23,4,4)
	spr(0,48+yv-sin(t+0.25)*46,48+xv+cos(t+0.25)*46,4,4)
	spr(0,48+yv+sin(t+0.375)*33,48+xv-cos(t+0.375)*33,4,4)
	spr(0,48+yv+sin(t+0.375)*65,48+xv-cos(t+0.375)*65,4,4)
	spr(0,48+yv-sin(t+0.375)*33,48+xv+cos(t+0.375)*33,4,4)
	spr(0,48+yv-sin(t+0.375)*65,48+xv+cos(t+0.375)*65,4,4)
	spr(0,48+yv+sin(t-0.375)*33,48+xv-cos(t-0.375)*33,4,4)
	spr(0,48+yv+sin(t-0.375)*65,48+xv-cos(t-0.375)*65,4,4)
	spr(0,48+yv-sin(t-0.375)*33,48+xv+cos(t-0.375)*33,4,4)
	spr(0,48+yv-sin(t-0.375)*65,48+xv+cos(t-0.375)*65,4,4)
	spr(0,48+yv-sin(t-0.325)*52,48+xv+cos(t-0.325)*52,4,4)
	spr(0,48+yv-sin(t+0.325)*52,48+xv+cos(t+0.325)*52,4,4)
	spr(0,48+yv+sin(t-0.325)*52,48+xv-cos(t-0.325)*52,4,4)
	spr(0,48+yv+sin(t+0.325)*52,48+xv-cos(t+0.325)*52,4,4)
	spr(0,48+yv-sin(t-0.425)*52,48+xv+cos(t-0.425)*52,4,4)
	spr(0,48+yv-sin(t+0.425)*52,48+xv+cos(t+0.425)*52,4,4)
	spr(0,48+yv+sin(t-0.425)*52,48+xv-cos(t-0.425)*52,4,4)
	spr(0,48+yv+sin(t+0.425)*52,48+xv-cos(t+0.425)*52,4,4)
end

function towers()
 local offsa=0
 local spread=0.2*sin(towtimer*0.1) -- spread of sinewaves 
 local speed=16
 local offsy=16
 local offsx=(towtimer*speed)%15
 local fact=16    -- amp of y movenemt
 offsa+=spread 
 for x=-1,8 do
  for y=8,0,-1 do
   spr(12,(x*15+offsx),y*7+sin(1.4*towtimer+(x-offsx)/8+offsa)*fact+offsy,2,2)
  end
 end
 offsy=32
 offsx=(7+towtimer*speed)%15
 offsa+=spread
 for x=-1,8 do
  for y=8,0,-1 do
   spr(12,(x*15+offsx),y*7+sin(1.4*towtimer+(x-offsx)/8+offsa)*fact+offsy,2,2)
  end
 end
 offsy=48
 offsx=(14+towtimer*speed)%15
 offsa+=spread
 for x=-1,8 do
  for y=8,0,-1 do
   spr(12,(x*15+offsx),y*7+sin(1.4*towtimer+(x-offsx)/8+offsa)*fact+offsy,2,2)
  end
 end
 offsy=64
 offsx=(21+towtimer*speed)%15
 offsa+=spread
 for x=-1,8 do
  for y=8,0,-1 do
   spr(12,(x*15+offsx),y*7+sin(1.4*towtimer+(x-offsx)/8+offsa)*fact+offsy,2,2)
  end
 end
 offsy=80
 offsx=(28+towtimer*speed)%15
 offsa+=spread
 for x=-1,8 do
  for y=8,0,-1 do
   spr(12,(x*15+offsx),y*7+sin(1.4*towtimer+(x-offsx)/8+offsa)*fact+offsy,2,2)
  end
 end
 offsy=96
 offsx=(35+towtimer*speed)%15
 offsa+=spread
 for x=-1,8 do
  for y=8,0,-1 do
   spr(12,(x*15+offsx),y*7+sin(1.4*towtimer+(x-offsx)/8+offsa)*fact+offsy,2,2)
  end
 end
end

function chaoszoom1()
	local cost=0.25*cos(chtimer/1.5)-0.6
	local sint=0.25*sin(chtimer/1.5)-0.6
	local offs =40
	for x=0,79 do
	 local xcost = (offs-x)*cost
	 local xsint = (offs-x)*sint
		for y=0,78 do
			local u = (xcost+(offs-y)*-sint)*0.895
			local v = (xsint+(offs-y)* cost)*0.85
			u = u%80
			v = v%80
			pset(x,y,sget(u,v))
		end
	end
 circfill (28+16*sin(chtimer),28+10*cos(1.8*chtimer),3,0)
 circfill (28+16*sin(chtimer),28+10*cos(1.8*chtimer),2,13)
 circfill(40+7*sin(chtimer*2),40+7*cos(chtimer*2),6,0)
 circfill(40+7*sin(chtimer*2),40+7*cos(chtimer*2),4,chaoscoltab[flr(timer*20%16+1)]  )
	for i=0,39 do
		local p=64*i
		memcpy(0x0000+p,0x7020+p,20)
		memcpy(0x0014+p,0x700c+p,20)
		memcpy(0x0a00+p,0x6620+p,20)
		memcpy(0x0a14+p,0x660c+p,20)
 end
end


function chaoszoom2()
poke (0x5f2c,7)
	local cost=cos(0.49)+0.09*cos(chtimer)
	local sint=sin(0.51)+0.09*sin(chtimer)
	local offs =31.5+3*sin(chtimer/2)
	for x=0,63 do
	 local xcost = (offs-x)*cost
	 local xsint = (offs-x)*sint
		for y=0,63 do
			local u = (xcost+(offs-y)*-sint)*1.02
			local v = (xsint+(offs-y)* cost)*1.02
			u = u%64
			v = v%64
			pset(x,y,sget(u,v))
		end
	end
for x=0,3 do
for y=0,3 do
colorr=flr(chtimer*20)%15+1
pset(0+x,0+y,colorr)
end
end
	for i=0,31 do
		local p=64*i
		memcpy(0x0800+p,0x6010+p,16)
		memcpy(0x0810+p,0x6000+p,16)
  memcpy(0x0000+p,0x6810+p,16)
  memcpy(0x0010+p,0x6800+p,16)
 end
 for x=0,3 do
  for y=0,3 do
   pset(0+x,0+y,0)
  end
 end
 rect(0,0,127,127,7)
end

---------------------------------------------------------
---------------------------------------------------------
---------------------------------------------------------
---------------------------------------------------------
function _init()
cam = {-0.01,0.01,-2.5} 
mult = 113
end

---------------------------------------------------------

function _update()
	timer   +=0.005
 towtimer+=0.03
 chtimer +=0.01

--music on
	if timer >= scene0 and musicflag1 == 0 then
		musicflag1=1
		music(0)
	end

--music off
	if timer >= scene16 and musicflag2 == 0 then
		musicflag2=1
		music(-1,4000)
	end

--vector
	if timer>=scene1 and timer < scene2 then
  cam[3] =10-(timer-scene1)*10+2.5
  cube = rotate_shape(cube,a,0.01)--rotate cube
 end

--rasters
	if timer>=scene2 and timer<scene8 then
	sin_timer +=1
	sin_timer2 -=0.06
	if timer>=scene5 then rottimer+=0.005 end
		linex1= sin(rottimer)*64+63.5
		liney1= cos(rottimer)*64+63.5
		linex2=-sin(rottimer)*64+63.5
		liney2=-cos(rottimer)*64+63.5
		cx= cos(rottimer)
		cy= -sin(rottimer)
		if timer>=scene6 then cy= -sin(rottimer*2+0.75) end
		cleartable() 
		copytable()
		if timer>=scene4 then copybar(flr(-abs(sin(1.5707*timer+0.05)*82)+98)) end
		if timer>=scene3 then rotatetable() end
	end
end
---------------------------------------------------------

function _draw()
	rectfill(0,0,127,127,0)

--beatcircle
		if timer<scene2 and timer >=scene0 then
		 beat =stat(23)%8
	  if beat==3 then
		  circfill(63,63,32,1)
		  circ(63,63,32,7)
		  beatnu=3
   end
   if beatnu==3 and beat != 3 then
    circ(63,63,34,6)
	   beatnu=2
	  end
	  if beatnu==2 and beat != 3 then
    circ(63,63,36,2)
	  beatnu=1
	  end
	  if beatnu==1 and beat != 3 then
    circ(63,63,38,1)
	  beatnu=0
	  end
  end
	  
--startlogo
 if timer<scene1 and timer >= scene0 then
  logocircles()
  drawlogo()
 end	
	
--vector -- from the pico-8 magazine
	if timer>=scene1 and timer<scene2 then
  vectimer+=0.5
  if vectimer <= 6 then 
   veccolor=veccoltab[flr(vectimer+1)] 
  end
  draw_shape(cube,veccolor)
	end
	
--rasters
	if timer>=scene2 and timer<=scene8 then
	 if timer>=scene7 then 
   rastertimer+=2 
   camera(0,rastertimer)
		end
 	for i=0,128 do
 		sline (linex1+(i-64)*cx,liney1+(i-64)*cy,linex2+(i-64)*cx,liney2+(i-64)*cy,r_space[i])
 	end
	 drawborder(16,111)
	 camera(0,0)
	 rectfill(0,127-rastertimer,127,127,1)	  
	 if timer < (scene2+0.04) then
   drawflash()
	 end
	 if (timer>=scene4 and timer <scene5) then 	print("✽ rasterbars ftw ✽",25,flr(-abs(sin(1.5707*timer+0.05)*82)+103),r_bar[flr(abs(sin(5*timer))*16)]) end
	end


--sinescroll
 if timer>=scene2 and timer <scene7 then
 print("                    alcatraz at nordlicht 2017. with a little pico-8 production called    2 and 1/2 men     this platform is so much fun!!"
 ,-sin_timer+128,119,7)
 for sin_x=0,127 do
 	for sin_y=114,123  do
 	  sincalc=sin_y+((sin((sin_x)/40+sin_timer2)+1)*3)
 		 if sincalc>127 then sincalc=127 end
 		 pset(sin_x,sin_y,  pget(sin_x,sincalc))
 		end
 	end
 end

--rotzoom
 if timer>=scene8 and timer<scene10 then 
  rectfill(0,0,127,127,1)
  if rotzoomtimer >= -127 then rotzoomtimer-=1 end
  camera(0,128+rotzoomtimer)
  rotzoom() 
  if timer>=(scene8+3.26) then
   borderx+=1
   bordery-=1
   drawborder(borderx,bordery)
  else
   borderx=16
   bordery=111
   drawborder(borderx,bordery)
  end
  if timer>=(scene8+2.1) then poke (0x5f2c,7) end
	end 

--rotsprites
 if timer>=scene10 and timer <scene13 then 
  poke (0x5f2c,0)
  rotsprites()
   if timer<=(scene10+0.24) then
  		borderx-=1
  		bordery+=1
   end
   if timer>=scene12 then 
    bordertime+=0.16
    borderx=16-bordertime*-sin(timer*7+0.28)
    bordery=111+bordertime*-sin(timer*7+0.28)
		 end
		drawborder(borderx,bordery)
	end 

--towers
 if timer>=scene13 and timer <scene14 then
-- fade in
  if fadetimer>0 then
   fade(flr(fadetimer))
   fadetimer-=1.5
  end
  -- fade out
  if timer>(scene14-0.1) and fadetimer3<16 then
   fade(flr(fadetimer3))
   fadetimer3+=1.5
  end
  rectfill(0,0,127,127,1) 
  towers() 
  drawlogo2()
		drawborder(0,127)
  credits()
	end 

 if timer>=scene14 and fadetimer4>0 then	
  rectfill(0,0,127,127,1)
	 fade(flr(fadetimer4))
  fadetimer4-=1.5
 end 
--chaoszoom1
 if timer>=(scene14+0.06) and timer<scene15 then
  if chflag==false then 
   cls(1)
   chflag=true
  end
  if chcam>-24 then
   rectfill(0,0,127,127,1)
   camera(chcam,-24)
   rectfill(0,0,80,80,0) 
   rect(0,0,80,80,7)
  	chcam-=1
  end
  if timer>=(scene14+0.63) then 
  	if fadetimer2>0 then
  		fade(flr(fadetimer2))
  		rectfill(-24,-24,127,127,1) 
  		fadetimer2-=2.1
  		if fadetimer2<=0 then
   		fadetimer2=0 
  		end
  	end	
   chaoszoom1() 
   drawborder(0,79)
  end
 end

-- chaoszoom2
if timer>=scene15 and timer<scene16 then
camera(0,0)
chaoszoom2()
end

if timer>=scene16 then
poke (0x5f2c,4)

  -- fade out
  if fadetimer5>0 then
   fade(flr(fadetimer5))
   fadetimer5-=1.5
  end
  local xpos=32
  local ypos=40
  spr(192,xpos,ypos)
  spr(203,xpos+8,ypos)
  spr(194,xpos+16,ypos)
  spr(192,xpos+24,ypos)
  spr(211,xpos+32,ypos) 
  spr(209,xpos+40,ypos) 
  spr(192,xpos+48,ypos) 
  spr(217,xpos+56,ypos) 
  
  xpos=29
  spr(205,xpos,ypos+16)  
  spr(206,xpos+8,ypos+16)
  spr(209,xpos+16,ypos+16)
  spr(195,xpos+24,ypos+16)
  spr(203,xpos+32,ypos+16) 
  spr(200,xpos+40,ypos+16)
  spr(194,xpos+48,ypos+16)
  spr(199,xpos+56,ypos+16)
  spr(211,xpos+64,ypos+16)
  
  xpos=43
  spr(204,xpos,ypos+32) 
  spr(204,xpos+8,ypos+32)
  spr(215,xpos+16,ypos+32) 
  spr(213,xpos+24,ypos+32)                            
  spr(200,xpos+32,ypos+32) 
  spr(200,xpos+36,ypos+32) 
end

if timer>(scene16+0.5) then cls() end

--status
--print("cpu "..stat(1)*100.0, 0, 0,7)
--print("time "..timer, 64, 0,7)
--print("row "..stat(23)%8,64,0,7)
end

---------------------------------------------------------


     
         


