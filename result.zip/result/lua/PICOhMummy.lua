-- oh mummy pico8 remake
-- by hokutoy (adria estrades celma)
-- dedicated to axel, aina, mireia, eric i jan!

function _init()

_shex={["0"]=0,["1"]=1,
["2"]=2,["3"]=3,["4"]=4,["5"]=5,
["6"]=6,["7"]=7,["8"]=8,["9"]=9,
["a"]=10,["b"]=11,["c"]=12,
["d"]=13,["e"]=14,["f"]=15}
_pl={[0]="00000015d67",
     [1]="0000015d677",
     [2]="0000024ef77",
     [3]="000013b7777",
     [4]="0000249a777",
     [5]="000015d6777",
     [6]="0015d677777",
     [7]="015d6777777",
     [8]="000028ef777",
     [9]="000249a7777",
    [10]="00249a77777",
    [11]="00013b77777",
    [12]="00013c77777",
    [13]="00015d67777",
    [14]="00024ef7777",
    [15]="0024ef77777"}
_pi=0-- -100=>100, remaps spal
_pe=0-- end pi val of pal fade
_pf=0-- frames of fade left
function fade(from,to,f)
    _pi=from _pe=to _pf=f
end

	w=128
	h=128

	//para que el cofre se abra solo 1 vez
	ches1=0 ches2=0 ches3=0 ches4=0 ches5=0 ches6=0 ches7=0 ches8=0 ches9=0 ches10=0
	ches11=0 ches12=0 ches13=0 ches14=0 ches15=0 ches16=0 ches17=0 ches18=0 ches19=0 ches20=0

	music(1)
	sorteo=0
	p1={}
	p1.x=56
	p1.y=0
	p1.s=1
	p1.m=5
	p1.look=false
	frameskip=0
	click=0

	score=0
	topscore=0
	lives=5
	floor=1
	open=false 
	intro=true
	velocidad=1
	glevel=0
	topglevel=0
	mazmorra=0
	topmazmorra=0
	onlyone=0
	button=0
	buttonold=0
	scount=0
	cobrar=0
	
	
	
	
	tablero = {} // donde van las pisadas
	piramide = {}
	demons = {}
	dust = {}
	prize = {}
	

	ejex={0,24,48,72,96,120}
	ejey={16,40,64,88,112}

	
	//primera fila
	chest1 = {3,4,5,6,19,22,35,38,51,52,53,54}
	chest2 = {51,52,53,54,67,70,83,86,99,100,101,102}
	chest3 = {99,100,101,102,115,118,131,134,147,148,149,150}
	chest4 = {147,148,149,150,163,166,179,182,195,196,197,198}
	chest5 = {195,196,197,198,211,214,227,230,243,244,245,246}

	//segunda fila
	chest6 = {6,7,8,9,22,25,38,41,54,55,56,57}
	chest7 = {54,55,56,57,70,73,86,89,102,103,104,105}
	chest8 = {102,103,104,105,118,121,134,137,150,151,152,153}
	chest9 = {150,151,152,153,166,169,182,185,198,199,200,201}
	chest10= {198,199,200,201,214,217,230,233,246,247,248,249}

	//tercena fila
	chest11 = {9,10,11,12,25,28,41,44,57,58,59,60}
	chest12 = {57,58,59,60,73,76,89,92,105,106,107,108}
	chest13 = {105,106,107,108,121,124,137,140,153,154,155,156}
	chest14 = {153,154,155,156,169,172,185,188,201,202,203,204}
	chest15 = {201,202,203,204,217,220,233,236,249,250,251,252}

	//cuarta fila
	chest16 = {12,13,14,15,28,31,44,47,60,61,62,63}
	chest17 = {60,61,62,63,76,79,92,95,108,109,110,111}
	chest18 = {108,109,110,111,124,127,140,143,156,157,158,159}
	chest19 = {156,157,158,159,172,175,188,191,204,205,206,207}
	chest20 = {204,205,206,207,220,223,236,239,252,253,254,255}


 	
	
	palt (11,true) --color negro si
palt(0,false) -- color verde trans

level(0)
end
		
		
function level (l)

while click<200 do click+=1 end
//if fade(0,-100,32) -- a oscuro

fade(-100,0,32) -- a claro



	//lista de premios

for a in all(prize) do
				 del(prize,a)  end
prize = {"nada1","nada2","nada3","nada4","nada5","nada6","key","cofre","vida","demon","coin1","coin2","coin3","coin4","coin5","coin6","coin7","coin8","coin9","coin10"}


//glevel=l
--anular a false


//para que el cofre se abra solo 1 vez
	ches1=0 ches2=0 ches3=0 ches4=0 ches5=0 ches6=0 ches7=0 ches8=0 ches9=0 ches10=0
	ches11=0 ches12=0 ches13=0 ches14=0 ches15=0 ches16=0 ches17=0 ches18=0 ches19=0 ches20=0

--limpiamos tablas

for a in all(demons) do
				 del(demons,a)  end
for a in all(piramide) do
				 del(piramide,a)  end
for a in all(tablero) do
				 del(tablero,a)  end
-------------------------
	
-- el tablero se llena de pisadas
		for z=0,15 do
			ws=z+(z*7)
				for zy=0,15 do
					wy=zy+(zy*7)
				    pisadas(45,ws,wy)	
				end
	    end
---------------------------------
open=false
	
	
	


	if l==0 then intro=true glevel=0 
	if onlyone==3 then
		for a=1,3 do 
			mummy(ejex[flr(rnd(6)+1)],16,1)
			mummy(ejex[flr(rnd(6)+1)],16,0.5)
			mummy(ejex[flr(rnd(6)+1)],120,1)
			mummy(ejex[flr(rnd(6)+1)],120,0.5)
			//mummy(ejex[flr(rnd(6)+1)],120,0.7)
		 end
		end

		else intro=false	
		-- formula de creacion enemigos
		for a=1,l*(2+mazmorra) do enemy(ejex[flr(rnd(6)+1)],ejey[flr(rnd(5)+1)],flr(rnd(100)))	 end
	end

	

end

function polvo ()

	dust.x=p1.x-7
	dust.y=p1.y
	//anim(dust,60,4,6,false) 
	end

function shake ()

	if scount>0 then camera(rnd(5),rnd(5)) scount-=1 end 
	if scount==0 then camera() end
end

function sarcofago (qual,cuant)
	unlock=0
 	for a=1,cuant do
 		b=qual[a]	
 		if tablero[b].s!=45	then unlock=unlock+1   end
	end
 	
 	if unlock==cuant then 
 	
 		return true
 	end
end

function loteria (size,ta,tb,tc,td)
	spe=0
	sorteo=0
	if #prize==1 then sorteo=1 end
	while (sorteo==0) do
	sorteo=flr(rnd(#prize))
	end
	


	if prize[sorteo]=="key" then 
		sfx(10)
		if mazmorra==0 or mazmorra==4 then ai=136 bi=152 ad=137 bd=153 end
		if mazmorra==1 or mazmorra==5 then ai=204 bi=220 ad=205 bd=221 end
		if mazmorra==2 or mazmorra==6 then ai=168 bi=184 ad=169 bd=185 end
		if mazmorra==3 or mazmorra==7 then ai=238 bi=254 ad=239 bd=255 end
		
		open=true; 
		tablero[98].s=115
		sfx(13)
		
	end
	if prize[sorteo]=="cofre" then
		sfx(10) 
		if mazmorra==0 or mazmorra==4 then ai=134 bi=150 ad=135 bd=151 end
		if mazmorra==1 or mazmorra==5 then ai=202 bi=218 ad=203 bd=219 end
		if mazmorra==2 or mazmorra==6 then ai=166 bi=182 ad=167 bd=183 end
		if mazmorra==3 or mazmorra==7 then ai=236 bi=252 ad=237 bd=253 end
		
		score+=100 print (score, 76,1,10) print (score, 77,0,8)
	end
	if prize[sorteo]=="vida" then 
		
		if mazmorra==0 or mazmorra==4 then ai=130 bi=146 ad=131 bd=147 end
		if mazmorra==1 or mazmorra==5 then ai=198 bi=214 ad=199 bd=215 end
		if mazmorra==2 or mazmorra==6 then ai=162 bi=178 ad=163 bd=179 end
		if mazmorra==3 or mazmorra==7 then ai=232 bi=248 ad=233 bd=249 end
		
		
		if lives>=10 then score+=250 scount=10 sfx(14) print (score, 76,1,10) print (score, 77,0,8) else sfx(10) lives+=1*(mazmorra+1) if lives>10 then lives=10 end end
	
	end
	
		if prize[sorteo]=="demon" then 
			sfx(11)
		
		if mazmorra==0 or mazmorra==4 then ai=140 bi=156 ad=141 bd=157 end
		if mazmorra==1 or mazmorra==5 then ai=128 bi=144 ad=129 bd=145 end
		if mazmorra==2 or mazmorra==6 then ai=160 bi=176 ad=161 bd=177 end
		if mazmorra==3 or mazmorra==7 then ai=174 bi=190 ad=175 bd=191 end
						
		if p1.x<60 then xm=120 else xm=0 end
		if p1.y<60 then ym=112 else ym=16 end
				mummy(xm,ym,1)
				mummy(xm,ym,0.3)
				mummy(xm,ym,0.5)
	end
	
	if prize[sorteo]=="coin1" then 

		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
		
	end
	if prize[sorteo]=="coin2" then 
		
		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
	end
	if prize[sorteo]=="coin3" then 
		
		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
	
	end
	if prize[sorteo]=="coin4" then 
		
		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
	end
	if prize[sorteo]=="coin5" then 
	
		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
	end
	if prize[sorteo]=="coin6" then 
		
		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
	end
	if prize[sorteo]=="coin7" then 
		
		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
	end
	if prize[sorteo]=="coin8" then 
		
		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
	end
	if prize[sorteo]=="coin9" then 
		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
	end
	if prize[sorteo]=="coin10" then 
		
		if mazmorra==0 or mazmorra==4 then ai=132 bi=148 ad=133 bd=149 end
		if mazmorra==1 or mazmorra==5 then ai=200 bi=216 ad=201 bd=217 end
		if mazmorra==2 or mazmorra==6 then ai=164 bi=180 ad=165 bd=181 end
		if mazmorra==3 or mazmorra==7 then ai=234 bi=250 ad=235 bd=251 end
		score+=10 sfx(4) print (score, 76,1,10) print (score, 77,0,8)
	end
	if prize[sorteo]=="nada1" then 
		if mazmorra==0 or mazmorra==4 then ai=138 bi=154 ad=139 bd=155 end
		if mazmorra==1 or mazmorra==5 then ai=206 bi=222 ad=207 bd=223 end
		if mazmorra==2 or mazmorra==6 then ai=170 bi=186 ad=171 bd=187 end
		if mazmorra==3 or mazmorra==7 then ai=142 bi=158 ad=143 bd=159 end
		sfx(8)
	end
	if prize[sorteo]=="nada2" then 
		
		if mazmorra==0 or mazmorra==4 then ai=138 bi=154 ad=139 bd=155 end
		if mazmorra==1 or mazmorra==5 then ai=206 bi=222 ad=207 bd=223 end
		if mazmorra==2 or mazmorra==6 then ai=170 bi=186 ad=171 bd=187 end
		if mazmorra==3 or mazmorra==7 then ai=142 bi=158 ad=143 bd=159 end
		sfx(8)
	end
	if prize[sorteo]=="nada3" then 
		
		if mazmorra==0 or mazmorra==4 then ai=138 bi=154 ad=139 bd=155 end
		if mazmorra==1 or mazmorra==5 then ai=206 bi=222 ad=207 bd=223 end
		if mazmorra==2 or mazmorra==6 then ai=170 bi=186 ad=171 bd=187 end
		if mazmorra==3 or mazmorra==7 then ai=142 bi=158 ad=143 bd=159 end
		sfx(8)
	end
	if prize[sorteo]=="nada4" then 
		
		if mazmorra==0 or mazmorra==4 then ai=138 bi=154 ad=139 bd=155 end
		if mazmorra==1 or mazmorra==5 then ai=206 bi=222 ad=207 bd=223 end
		if mazmorra==2 or mazmorra==6 then ai=170 bi=186 ad=171 bd=187 end
		if mazmorra==3 or mazmorra==7 then ai=142 bi=158 ad=143 bd=159 end
		sfx(8)
	end
	if prize[sorteo]=="nada5" then 
		
		if mazmorra==0 or mazmorra==4 then ai=138 bi=154 ad=139 bd=155 end
		if mazmorra==1 or mazmorra==5 then ai=206 bi=222 ad=207 bd=223 end
		if mazmorra==2 or mazmorra==6 then ai=170 bi=186 ad=171 bd=187 end
		if mazmorra==3 or mazmorra==7 then ai=142 bi=158 ad=143 bd=159 end
		sfx(8)
	end
	if prize[sorteo]=="nada6" then 
		
		if mazmorra==0 or mazmorra==4 then ai=138 bi=154 ad=139 bd=155 end
		if mazmorra==1 or mazmorra==5 then ai=206 bi=222 ad=207 bd=223 end
		if mazmorra==2 or mazmorra==6 then ai=170 bi=186 ad=171 bd=187 end
		if mazmorra==3 or mazmorra==7 then ai=142 bi=158 ad=143 bd=159 end
		sfx(8)
	end
	


	tablero[ta].s=ai 
	tablero[tb].s=bi
	if size==4 then 
		tablero[tc].s=ad 
		tablero[td].s=bd 
	end	
		
	del(prize,prize[sorteo])
	return
end

-- decide para donde ir
function padonde(a,direc)

		//for a in all(demons) do
			// si te pillan una vida menos
				if collide(a,p1) then scount=5 lives-=1 sfx(3)
				 del(demons,a)  end
				
			//end

		indeciso=flr(rnd(100))
		//vertical
		if a.x==0 or a.x==24 or a.x==48 or a.x==72 or a.x==96 or a.x==120 then
			
			if direc<=10 then
			a.d=3
			a.y+=a.s end
			if direc>=10 and direc<=20 then
			a.d=2
			a.y-=a.s end
			end
		
		//horizontal
		if a.y==16 or a.y==40 or a.y==64 or a.y==88 or a.y==112 then
			
			if direc>=20 and direc<=30 then
			a.d=0
			a.x-=a.s end
			if direc>=30 and direc<=40 then
			a.d=1
			a.x+=a.s end
		end
		
		if a.x<0 then a.x=0 end
		if a.x>120 then a.x=120 end
		if a.y<16 then a.y=16 end
		if a.y>112 then a.y=112 end
		
		if indeciso>50 then
		if a.x==0 and ( a.y==16 or a.y==40 or a.y==64 or a.y==88 or a.y==112) then a.dire=flr(rnd(100)) end
		if	a.x==24 and ( a.y==16 or a.y==40 or a.y==64 or a.y==88 or a.y==112) then a.dire=flr(rnd(100)) end
		if	a.x==48 and ( a.y==16 or a.y==40 or a.y==64 or a.y==88 or a.y==112) then a.dire=flr(rnd(100)) end
		if	a.x==72 and ( a.y==16 or a.y==40 or a.y==64 or a.y==88 or a.y==112) then a.dire=flr(rnd(100)) end
		if	a.x==96 and ( a.y==16 or a.y==40 or a.y==64 or a.y==88 or a.y==112) then a.dire=flr(rnd(100)) end
		if	a.x==120 and ( a.y==16 or a.y==40 or a.y==64 or a.y==88 or a.y==112) then a.dire=flr(rnd(100)) end
		end
	end
	
	
	
//	end

-- dibuja pisadas

function pisadas(s,x,y)
	a={}
	a.x=x
	a.y=y
	a.t=false

	
		if(s~=a.s) then a.s=s	 end
	
	if p1.y<=8 then a.s=45 end
	

	
	if (flr(p1.x/8)==p1.x/8) and (flr(p1.y/8)==p1.y/8)  then
	add(tablero,a)  
	return a
	end
	
	end

function enemy(x,y,dire)
 
 
 b=rnd(30)
 if b<10 then c=0.1 end
 if b>10 and b<20 then c=0.3 end
 if b>20 and b<30 then c=0.5 end
	
	a={}
	a.x=x
	a.y=y
	a.s=c
	a.m=5
	a.ms=0
	a.d=0
	a.dire=dire
	
	add (demons,a) //return a
	end

function mummy(x,y,vel)
 
 

 
 
	
	a={}
	a.x=x
	a.y=y
	a.s=vel
	a.m=8
	a.ms=0
	a.d=0
	
	add (piramide,a) return a
	end
	
	
	
function apply_ramp_fade(ramp, proportion)
	pal()
	for color = 0, 15 do
		local colorramp = ramp[color + 1]
		local slot = flr(#colorramp * proportion + 1)
		pal(color, colorramp[slot], 1)
	end  
end

function _update60()

	shake()
	click+=1 if click>=200 then click=0 end
	
	if (open==true and collide (tablero[241],p1) or lives==0) or (btn(4) and intro==true and onlyone==3) then p1.x=-10 
		onlyone=4
		fade(0,-100,36)
		if lives>0 then sfx(6)  glevel+=1 else sfx(9) end
		if glevel==6 then glevel=1 mazmorra+=1 cobrar=1 end -- sfx(14) score+=mazmorra*500 print (score, 76,1,10) print (score, 77,0,8)
		if lives==0 then 
			if topscore<score then topscore=score topglevel=glevel topmazmorra=mazmorra end
			glevel=0 mazmorra=0 lives=5 p1.x=56 p1.y=64 
			score=0 onlyone=2
		else 
				p1.x=0
				p1.y=0
				p1.look=false
		end
		level(glevel)  
	end
	if #prize==0 then scount=10 sfx(14) score+=250 print (score, 76,1,10) print (score, 77,0,8) add(prize,"relleno") end
	 // pone reja al final nivel
	 if open==true and p1.y<8 then tablero[241].s=127 end
	
		drw()
	--escalera
	if not intro then tablero[209].s=45 else 

		if (onlyone==1 and btn(5)) then  fade(0,-100,32) fade(-100,0,32) sfx(4) onlyone=2 end
		if (onlyone==0 and btn(4)) then  fade(0,-100,32) fade(-100,0,32) sfx(4) onlyone=1 end
	
		if onlyone==3 then	

			print ("highscore:", 13,1,8)
			print ("highscore:", 13,0,7)
				print (topscore, 53,1,5)
				print (topscore, 53,0,7)
			
			print ("tomb:", 76,1,8)
			print ("tomb:", 76,0,7)
			
			print ("-", 101,1,5)
			print ("-", 101,0,7)
				
				
				print (topglevel, 106,1,5)
				print (topglevel, 106,0,7)
				
				print (topmazmorra+1, 97,1,5)
				print (topmazmorra+1, 97,0,7)
		end
	end
	
	// ponemos los corazones de vida
	
		if lives<0 then lives=0 end
	if not intro then
	
		if lives>0 and p1.y>8 then tablero[1].s=172 else if not open then tablero[1].s=99 else tablero[1].s=45 end end
		
		if  p1.y>8 then
			if lives>1 then tablero[17].s=172 else tablero[17].s=173 end
			if lives>2 then tablero[33].s=172 else tablero[33].s=173 end
			if lives>3 then tablero[49].s=172 else tablero[49].s=173 end
			if lives>4 then tablero[65].s=172 else tablero[65].s=173 end

			if lives>5 then tablero[1].s=188 end
			if lives>6 then tablero[17].s=188 end
			if lives>7 then tablero[33].s=188 end
			if lives>8 then tablero[49].s=188 end
			if lives>9 then tablero[65].s=188 end
			if lives>10 then tablero[65].s=188 end
		else
			tablero[17].s=45 
			tablero[33].s=45 
			tablero[49].s=45 
			tablero[65].s=45  

		end
	
	end
	
		
		--if open==true then tablero[98].s=115 else if intro==true then tablero[98].s=45 else tablero[98].s=57  if cobrar==1 and p1.y>17 then sfx(14) score+=mazmorra*500 print (score, 76,1,10) print (score, 77,0,8) cobrar=0 end end end
		if open==true then tablero[98].s=115 else if intro==true then tablero[98].s=45 else tablero[98].s=57   end end
		
		if (open==false and p1.y<16  and onlyone>2) then tablero[98].s=115 end
		if p1.y==14 and not open then sfx(13) end
	pupd(p1)
	for a in all(demons) do
		
		padonde(a,a.dire)
		
	end
	for a in all(piramide) do
		eupd(a,p1)
	end
	
	
	
	frameskip=frameskip+1
if frameskip==20 then frameskip=0
	if p1.y>=16 or p1.y<=40 then 
			// primera fila
			if sarcofago(chest1,10)==true and ches1==0 then
			ches1=1
			loteria (4,20,21,36,37)
			end
			if sarcofago(chest2,12)==true and ches2==0 then
			ches2=1
			loteria (4,68,69,84,85)
			end
			if sarcofago(chest3,12)==true and ches3==0 then
			ches3=1
			loteria (4,116,117,132,133)
			end
			if sarcofago(chest4,12)==true and ches4==0 then
			ches4=1
			loteria (4,164,165,180,181)
			end
			if sarcofago(chest5,10)==true and ches5==0 then
			ches5=1
			loteria (4,212,213,228,229)
			end
	end

	if p1.y>=40 or p1.y<=64 then	
			// segunda fila
			if sarcofago(chest6,10)==true and ches6==0 then
			ches6=1 loteria (4,23,24,39,40)
			end
			if sarcofago(chest7,12)==true and ches7==0 then
			ches7=1 loteria (4,71,72,87,88)
			end
			if sarcofago(chest8,12)==true and ches8==0 then
			ches8=1 loteria (4,119,120,135,136)
			end
			if sarcofago(chest9,12)==true and ches9==0 then
			ches9=1 loteria (4,167,168,183,184)
			end
			if sarcofago(chest10,10)==true and ches10==0 then
			ches10=1 loteria (4,215,216,231,232)
			end
	end
	
	if p1.y>=64 or p1.y<=88 then
			// tercera fila
			if sarcofago(chest11,10)==true and ches11==0 then
				ches11=1 loteria (4,26,27,42,43)
			end
			if sarcofago(chest12,12)==true and ches12==0 then
				ches12=1 loteria (4,74,75,90,91)
			end
			if sarcofago(chest13,12)==true and ches13==0 then
				ches13=1 loteria (4,122,123,138,139)
			end
			if sarcofago(chest14,12)==true and ches14==0 then
				ches14=1 loteria (4,170,171,186,187)
			end
			if sarcofago(chest15,10)==true and ches15==0 then
				ches15=1 loteria (4,218,219,234,235)
			end
		end
end
	if p1.y>=88 or p1.y<=112 then
			// cuarta fila
			if sarcofago(chest16,10)==true and ches16==0 then
				ches16=1 loteria (4,29,30,45,46)
			end
			if sarcofago(chest17,12)==true and ches17==0 then
				ches17=1 loteria (4,77,78,93,94)
			end
			if sarcofago(chest18,12)==true and ches18==0 then
				ches18=1 loteria (4,125,126,141,142)
			end
			if sarcofago(chest19,12)==true and ches19==0 then
				ches19=1 loteria (4,173,174,189,190)
			
			end
			if sarcofago(chest20,10)==true and ches20==0 then
				ches20=1 loteria (4,221,222,237,238)
			
			end
		end
		
			if(_pf>0) then --pal fade
    if(_pf==1) then _pi=_pe
    else _pi+=((_pe-_pi)/_pf) end
    _pf-=1
end

	
	end

function drw()

	
	
			
	conta = rnd (50)
	if(conta<10) then 
	luck = rnd(2) else luck=2 end

	cls() 
	if cobrar==1 and p1.y>17 then scount=10 sfx(14) score+=mazmorra*500 print (score, 76,1,10) print (score, 77,0,8) cobrar=0 end


	if intro==true then 
		-- credits
		-- pantalla intro oh mummy
		if onlyone==2 then 
			for a=1,3 do 
				mummy(ejex[flr(rnd(6)+1)],16,1)
				mummy(ejex[flr(rnd(6)+1)],16,0.5)
				mummy(ejex[flr(rnd(6)+1)],120,1)
				mummy(ejex[flr(rnd(6)+1)],120,0.5)
			end 
			p1.x=56 p1.y=64 onlyone=3 end 
		if onlyone==3 then map(16,0,0,0,16,16) end 
		--credits
		if onlyone==0 then
			print ("pic-oh mummy!",39,1,4)
			print ("pic-oh mummy!",39,0,9)

			print ("code + graphics",34,21,1)
			print ("code + graphics",34,20,12)

			print ("hokutoy (aka adria estrades)",09,28,2)
			print ("hokutoy (aka adria estrades)",09,27,14)

			print ("music 'the streets of cairo'",09,41,1)
			print ("music 'the streets of cairo'",09,40,12)

			print ("tyroney",49,48,2)
			print ("tyroney",49,47,14)

			print ("awesome runing mario animation",04,61,1)
			print ("awesome runing mario animation",04,60,12)
			print ("and aditional gfx taken from",08,68,1)
			print ("and aditional gfx taken from",08,67,12)

			print ("johan vinet",42,75,2)
			print ("johan vinet",42,74,14)

			print ("some snippets sounds and sprites",00,88,1)
			print ("some snippets sounds and sprites",00,87,12)
			print ("http://www.lexaloffle.com/bbs/ ",3,95,2)
			print ("http://www.lexaloffle.com/bbs/",3,94,14)

			print ("dedicated to my future son",12,108,1)
			print ("dedicated to my future son",12,107,12)
			print ("axel",57,115,5)
			print ("axel",57,114,6)

			
		end
		-- howto
		if onlyone==1 then
			map(34,0,0,0,16,16)

			print ("how to play",44,1,4)
			print ("how to play",44,0,9)

			print ("10",12,66,5)
			print ("10",12,65,7)
			print ("100",34,66,5)
			print ("100",34,65,7)

			print ("extra points",39,79,4)
			print ("extra points",39,78,9)
			
			print ("overheal +10  :",19,91,8)
			print ("overheal +10  :",19,90,7)
			print ("250",93,91,5)
			print ("250",93,90,7)
			print ("unlock all level:",19,101,8)
			print ("unlock all level:",19,100,7)
			print ("250",93,101,5)
			print ("250",93,100,7)
			print ("finish tomb:      x lv tomb",9,111,8)
			print ("finish tomb:      x lv tomb",9,110,7)
			print ("500",63,111,5)
			print ("500",63,110,7)

		
		end	

		
	else 
		if mazmorra==0 or mazmorra==4 then map(0,0,0,0,16,16) 
		elseif mazmorra==1 or mazmorra==5 then map(16,16,0,0,16,16) 
		elseif mazmorra==2 or mazmorra==6 then map(0,16,0,0,16,16) 
		elseif mazmorra==3 or mazmorra==7 then map(32,16,0,0,16,16)
		end
		
	end

	
	
	for a in all(tablero) do
		
		spr(a.s,a.x,a.y)
	end
	
	
	
	if not intro then
		
		if p1.y>8 then
		//print ("lives:", 5,0,10)
		//print (lives, 30,0,9)
		
		
		print ("score:", 48,1,8)
		print ("score:", 48,0,7)
		
		print (score, 75,1,5)
		print (score, 75,0,7)
		
		print ("tomb:", 94,1,8)
		print ("tomb:", 94,0,7)
		
		print ("-", 119,1,5) 
		print ("-", 119,0,7)

		print (glevel, 124,1,5)
		print (glevel, 124,0,7)
		print (mazmorra+1, 115,1,5)
		print (mazmorra+1, 115,0,7)
	end

	else
		if onlyone==3 then
		print("by hokutoy",44,77,4)
		print("by hokutoy",44,76,10)
	end
	
end
	
	
if onlyone>2 then
	if btn(0)  then
				// polvo()
				buttonold=1
				
				p1.look=true
				for a in all(tablero) do
					if p1.y>8 and collide(a,p1) then a.s=31 end
				end		
				
				anim (p1,3,6,10,true)
				
	elseif btn(1) then
				buttonold=2
				// polvo()
				p1.look=false
				
				for a in all(tablero) do
					if p1.y>8 and collide(a,p1) then a.s=14 end
				end
			 anim (p1,3,6,10,false)
	--up
	elseif btn(2)  then
				buttonold=3
				 //polvo()	
	   				//if (open==false and p1.x==48 and p1.y<=15) then p1.y=16 end 
	   				for a in all(tablero) do
					if p1.y>8 and collide(a,p1) then a.s=15 end
					end
			 anim(p1,32,6,10,p1.look)
	--down
	elseif btn(3) then
				buttonold=4
				// polvo()
				for a in all(tablero) do
					if p1.y>8 and collide(a,p1) then a.s=30 end
				end
				anim(p1,16,6,10,p1.look) 
	else
			
			spr(luck,p1.x,p1.y,1,1,p1.look,false)

	end
end
	if button!=buttonold then sfx(12) polvo()  button=buttonold end

	if (open==false and p1.x==48 and p1.y==15) then p1.y=16 end 
for a in all(piramide)  do	
 if a.d==0 then 	anim(a,80,3,6,true)
  elseif a.d==1 then 	anim(a,80,3,6,false)
	 elseif a.d==2 then 	anim(a,64,3,6,false)
	 elseif a.d==3 then 	anim(a,67,3,6,false)
 end
end
 for a in all(demons)  do	
 if a.d==0 then 	anim(a,208,3,6,true)
  elseif a.d==1 then 	anim(a,208,3,6,false)
	 elseif a.d==2 then 	anim(a,192,3,6,false)
	 elseif a.d==3 then 	anim(a,195,3,6,false)
 end
end

	local pix=6+flr(_pi/20+0.5)
if(pix!=6) then
    for x=0,15 do
        pal(x,_shex[sub(_pl[x],pix,pix)],1)
    end
else pal() palt (11,true) --color negro si
 palt(0,false) -- color verde trans
end

	
end

function colm(fx,tx,fy,ty)
	alargo=0
	if intro then alargo=16 else alargo=0 end
	local a=fget(mget((fx/8)+alargo,fy/8),0)
	local b=fget(mget((fx/8)+alargo,ty/8),0)
	local c=fget(mget(tx/8,ty/8),0)
	local d=fget(mget(tx/8,fy/8),0)
	local e=fx<0 or fx+8>w
	local f=fy<0 or fy+8>h
	return (a or b or c or
         d or e or f)


end

	

function collide(obj, other)
    if
      (other.x+1+2>obj.x+1) and 
      (other.y+1+2>obj.y+1) and
      (other.x+1<obj.x+1+2) and
      (other.y+1<obj.y+1+2)
   	   then
       return true
    end
end

function pupd(p)
	local c
	local lx=p.x -- last x
	local ly=p.y -- last y

	if(btn(0)) then p.x-=p.s 
	elseif(btn(1)) then p.x+=p.s 
	elseif(btn(2)) then p.y-=p.s  
	elseif(btn(3)) then p.y+=p.s  
	end 

	-- collision, move back
	c=colm(p.x,p.x+7,p.y,p.y+7)
	if(c) p.x=lx p.y=ly

	-- no collision, set moving dir
	if(p.x<lx) p.m=0
	if(p.x>lx) p.m=1
	if(p.y<ly) p.m=2
	if(p.y>ly) p.m=3

	-- collision, move in last dir
	if(c) then
		if(p.m==0) p.x-=p.s
		if(p.m==1) p.x+=p.s
		if(p.m==2) p.y-=p.s
		if(p.m==3) p.y+=p.s
	end

	c=colm(p.x,p.x+7,p.y,p.y+7)
	if(c) p.x=lx p.y=ly
end

function eupd(e,t)
	e.ms+=e.s

	// cohque entre enemigos

		//for a in all(piramide) do
			// si te pillan una vida menos
	if collide(e,p1) then lives-=1 scount=5 sfx(3) del(piramide,e)  end
				//if e!=a and collide(e,a) then del(piramide,e) del(piramide,a) end
			//end

		
	
	// fin choque entre

	if(flr(e.ms)==1) then
		local ex=e.x
		local ey=e.y
		local em=e.m
		local tx=t.x
		local ty=t.y
		local cl=colm(ex-1,ex-1,ey,ey+7)
		local cr=colm(ex+8,ex+8,ey,ey+7)
		local ct=colm(ex,ex+7,ey-1,ey-1)
		local cb=colm(ex,ex+7,ey+8,ey+8)
		local ld=dst(ex-4,tx+4,ey+4,ty+4)
		local rd=dst(ex+11,tx+4,ey+4,ty+4)
		local td=dst(ex+4,tx+4,ey-4,ty+4)
		local bd=dst(ex+4,tx+4,ey+11,ty+4)
		local lo=not cl and em!=1
		local ro=not cr and em!=0
		local to=not ct and em!=3
		local bo=not cb and em!=2
		local sd=w

		if(lo)           sd=ld em=0
		if(ro and rd<sd) sd=rd em=1
		if(to and td<sd) sd=td em=2
		if(bo and bd<sd) em=3

		if(em==0) e.x-=1 e.d=0 
		if(em==1) e.x+=1 e.d=1 
		if(em==2) e.y-=1 e.d=2 
		if(em==3) e.y+=1 e.d=3 

		e.m=em
		e.ms=0
	end
end

function dst(fx,tx,fy,ty)
 return sqrt((fx-tx)^2+(fy-ty)^2)
end

--object, start frame,
--num frames, speed, flip
function anim(o,sf,nf,sp,fl)
	if(not o.a_ct) then o.a_ct=0 end
	if(not o.a_st)	then o.a_st=0 end

	o.a_ct+=2

	if(o.a_ct%(30/sp)==0) then
		o.a_st+=1
		if(o.a_st==nf) then o.a_st=0 
	 		//if o==p1 then sfx(7) end
	 		if o==dust then o.x=0 end
		end
	end
	o.a_fr=sf+o.a_st
	spr(o.a_fr,o.x,o.y,1,1,fl)
end



if(_update60)_update=function()_update60()_update_buttons()_update60()end